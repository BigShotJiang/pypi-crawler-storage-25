"""Whispers Orient — Slice 3 acceptance tests for wake auto-registration.

These tests isolate the wake-adapter-on-bind behavior so failures here
are diagnosable without touching the broader bind_seat flow. Slice 3's
job is narrow: when a claude-code session binds, the resulting seat
must be wake-capable under its bound callsign — no companion identity,
no silent manual_wake fallback.

The helper under test is `ensure_wake_adapter_for_claude_code_session`
in whispers/orientation.py. It wraps terminal_actuator's existing
`_ensure_local_wake_companion` (subprocess spawn + adapter POST) with
a direct-DB write path so bind_seat doesn't have to HTTP-call its own
server during its own handler.

Run: pytest tests/test_wake_auto_register.py -v
"""

from __future__ import annotations

import json
from unittest import mock

import pytest

from whispers.orientation import (
    OrientationError,
    ensure_wake_adapter_for_claude_code_session,
)
from whispers.testing import WhispersTestHarness


class TestEnsureWakeAdapter:
    """The helper registers a local_http_connector adapter under the
    CALLER'S bound callsign, starting or reusing a local_wake_runtime
    child process tied to the caller's Claude PID.

    Fail-closed: any step failure raises OrientationError with a specific
    reason so bind_seat can convert it to failed_at=WAKE_REGISTERED.
    """

    def test_happy_path_writes_adapter_under_bound_callsign(self):
        """On success, adapter_registrations.local_http_connector is
        written to the client's active session metadata — keyed by the
        client's own callsign, never by a companion callsign.
        """
        with WhispersTestHarness() as h:
            client = h.make_client("burr")
            fake_companion = {
                "pid": 14160,
                "endpoint_url": "http://127.0.0.1:64957/wake",
                "registration": None,
                "parent_pid": 43128,
            }
            with mock.patch(
                "whispers.orientation._ensure_local_wake_companion",
                return_value=(fake_companion, "started_companion"),
            ):
                result = ensure_wake_adapter_for_claude_code_session(
                    client=client,
                    parent_pid=43128,
                    server_url="http://127.0.0.1:8765",
                )
            assert result["ok"] is True
            assert result["endpoint_url"] == "http://127.0.0.1:64957/wake"
            assert result["companion_pid"] == 14160
            assert result["companion_status"] == "started_companion"

            # Verify the adapter_registrations was patched into the
            # session metadata under the burr callsign.
            session = client.db.active_session_for_agent("burr")
            assert session is not None
            metadata = session.get("metadata")
            if isinstance(metadata, str):
                metadata = json.loads(metadata)
            regs = metadata.get("adapter_registrations") or {}
            assert "local_http_connector" in regs
            assert regs["local_http_connector"]["endpoint_url"] == "http://127.0.0.1:64957/wake"

    def test_adapter_registration_survives_status_heartbeat(self):
        """Subsequent heartbeats must not overwrite adapter_registrations
        back to a no-adapter state. The root-cause fix routes heartbeats
        through ``touch_agent_session_lease`` which only bumps the lease
        and ``last_seen_at`` timestamp — metadata is left untouched, so
        any out-of-band writer (here: ``patch_agent_session_metadata``
        via ``ensure_wake_adapter_for_claude_code_session``) is durable.
        """
        with WhispersTestHarness() as h:
            client = h.make_client("burr", platform_family="claude-code")
            fake_companion = {
                "pid": 14160,
                "endpoint_url": "http://127.0.0.1:64957/wake",
                "registration": None,
                "parent_pid": 43128,
            }
            with mock.patch(
                "whispers.orientation._ensure_local_wake_companion",
                return_value=(fake_companion, "started_companion"),
            ):
                ensure_wake_adapter_for_claude_code_session(
                    client=client,
                    parent_pid=43128,
                    server_url="http://127.0.0.1:8765",
                )

            _ = client.status()

            session = client.db.active_session_for_agent("burr")
            assert session is not None
            metadata = session.get("metadata")
            if isinstance(metadata, str):
                metadata = json.loads(metadata)
            regs = metadata.get("adapter_registrations") or {}
            assert "local_http_connector" in regs
            assert regs["local_http_connector"]["endpoint_url"] == "http://127.0.0.1:64957/wake"

    def test_fails_closed_when_spawn_fails(self):
        """If the companion spawn raises (port conflict, missing
        dependency, etc.), we raise OrientationError with a reason
        that bind_seat can translate into failed_at=WAKE_REGISTERED.
        """
        with WhispersTestHarness() as h:
            client = h.make_client("burr")
            with mock.patch(
                "whispers.orientation._ensure_local_wake_companion",
                side_effect=RuntimeError("port 64957 already bound"),
            ):
                with pytest.raises(OrientationError) as excinfo:
                    ensure_wake_adapter_for_claude_code_session(
                        client=client,
                        parent_pid=43128,
                        server_url="http://127.0.0.1:8765",
                    )
            assert "port" in excinfo.value.reason.lower() or "runtime_spawn_failed" in excinfo.value.reason

    def test_reuses_existing_companion(self):
        """If a companion is already running for this parent PID, the
        helper reuses it and reports companion_status='reused_companion'.
        """
        with WhispersTestHarness() as h:
            client = h.make_client("burr")
            fake_companion = {
                "pid": 14160,
                "endpoint_url": "http://127.0.0.1:64957/wake",
                "registration": None,
                "parent_pid": 43128,
            }
            with mock.patch(
                "whispers.orientation._ensure_local_wake_companion",
                return_value=(fake_companion, "reused_companion"),
            ):
                result = ensure_wake_adapter_for_claude_code_session(
                    client=client,
                    parent_pid=43128,
                    server_url="http://127.0.0.1:8765",
                )
            assert result["companion_status"] == "reused_companion"
            assert result["ok"] is True

    def test_fails_when_no_active_session(self, tmp_path):
        """A client with no active session row cannot have adapter
        registrations patched onto it. Fail-closed with a specific reason.
        """
        from whispers.client import WhispersClient

        db_path = str(tmp_path / "no_session.db")
        client = WhispersClient(
            "nobody",
            db_path=db_path,
            agent_type="script",
            read_only=True,  # does not create a session row
        )
        fake_companion = {
            "pid": 14160,
            "endpoint_url": "http://127.0.0.1:64957/wake",
            "registration": None,
            "parent_pid": 43128,
        }
        with mock.patch(
            "whispers.orientation._ensure_local_wake_companion",
            return_value=(fake_companion, "started_companion"),
        ):
            with pytest.raises(OrientationError) as excinfo:
                ensure_wake_adapter_for_claude_code_session(
                    client=client,
                    parent_pid=43128,
                    server_url="http://127.0.0.1:8765",
                )
        # Must have a specific actionable reason
        assert excinfo.value.reason
        assert "session" in excinfo.value.reason.lower() or "active" in excinfo.value.reason.lower()
