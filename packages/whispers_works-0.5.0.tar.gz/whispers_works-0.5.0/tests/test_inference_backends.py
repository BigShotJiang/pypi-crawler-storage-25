"""W1 — InferenceBackend Protocol + 3 backends + mock + factory.

Active-listening v6 per `.planning/active/ACTIVE-LISTENING-REBUILD-2026-04-17.md`.

Tests cover:
  * Protocol conformance (MockBackend satisfies InferenceBackend, real
    backends do too)
  * Response dataclass shape
  * Factory dispatch (known kind, unknown kind, missing kind)
  * MockBackend — records calls, returns canned, supports fail_with
  * Real backends — happy-path HTTP mocked; auth failure without key;
    HTTP error classification (429, 401, 500); malformed JSON

Each real-backend test injects a fake `http_opener` so no network is
touched in CI.

Run: pytest tests/test_inference_backends.py -v
"""

from __future__ import annotations

import io
import json
from contextlib import contextmanager
from typing import Any, Dict

import pytest

from whispers.listeners.backends import (
    AnthropicBackend,
    BackendError,
    GoogleBackend,
    InferenceBackend,
    MockBackend,
    OpenAIBackend,
    Response,
    backend_from_config,
)
from whispers.listeners.engine import StreamEvent


# --- helpers ---------------------------------------------------------------


def make_event(
    *,
    sender: str = "peer",
    subject: str = "hi",
    priority: str = "routine",
    body: str = "hello world",
    kind: str = "wake",
) -> StreamEvent:
    """Build a StreamEvent in the canonical wake-packet shape."""
    return StreamEvent(
        kind=kind,
        event_id=1,
        payload={
            "packet": {
                "sender": sender,
                "subject": subject,
                "priority": priority,
                "body": body,
                "msg_type": "inform",
            },
        },
    )


class _FakeHttpResponse:
    """Mimics the context-manager returned by urllib.request.urlopen."""

    def __init__(self, body: bytes | str):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self._buf = io.BytesIO(body)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False

    def read(self) -> bytes:
        return self._buf.read()


def _fake_opener(canned_json: Dict[str, Any], *, captured: list | None = None):
    """Return an opener-like callable that returns canned JSON.

    If `captured` is provided, records the outgoing Request object so
    tests can assert on the headers / body the backend would have sent.
    """
    payload = json.dumps(canned_json)

    def opener(request, timeout=None):
        if captured is not None:
            captured.append(request)
        return _FakeHttpResponse(payload)

    return opener


def _fake_http_error(code: int, reason: str = "err"):
    import urllib.error

    def opener(request, timeout=None):
        raise urllib.error.HTTPError(
            request.full_url, code, reason, hdrs=None, fp=None,
        )

    return opener


# --- Protocol conformance + Response dataclass ------------------------------


class TestProtocolConformance:
    def test_mock_satisfies_protocol(self):
        assert isinstance(MockBackend(), InferenceBackend)

    def test_anthropic_satisfies_protocol(self):
        assert isinstance(AnthropicBackend(api_key="fake"), InferenceBackend)

    def test_google_satisfies_protocol(self):
        assert isinstance(GoogleBackend(api_key="fake"), InferenceBackend)

    def test_openai_satisfies_protocol(self):
        assert isinstance(OpenAIBackend(api_key="fake"), InferenceBackend)

    def test_response_dataclass_defaults(self):
        r = Response(text="x", backend_name="b", model_id="m")
        assert r.text == "x"
        assert r.usage == {}
        assert r.latency_ms == 0.0
        assert r.trace_id is None


# --- Factory ---------------------------------------------------------------


class TestFactory:
    def test_builds_mock(self):
        b = backend_from_config({"kind": "mock", "canned_text": "hi"})
        assert b.name == "mock"
        assert isinstance(b, MockBackend)

    def test_builds_anthropic_with_model_override(self):
        b = backend_from_config({
            "kind": "anthropic",
            "model_id": "claude-opus-4-7",
            "api_key": "fake",
        })
        assert isinstance(b, AnthropicBackend)
        assert b.model_id == "claude-opus-4-7"

    def test_builds_google_and_openai(self):
        g = backend_from_config({"kind": "google", "api_key": "fake"})
        o = backend_from_config({"kind": "openai", "api_key": "fake"})
        assert isinstance(g, GoogleBackend)
        assert isinstance(o, OpenAIBackend)

    def test_unknown_kind_raises_with_known_list(self):
        with pytest.raises(ValueError, match="Known kinds:"):
            backend_from_config({"kind": "imaginary"})

    def test_missing_kind_raises(self):
        with pytest.raises(ValueError, match="missing required 'kind'"):
            backend_from_config({})

    def test_non_dict_config_raises(self):
        with pytest.raises(ValueError, match="must be a dict"):
            backend_from_config("anthropic")  # type: ignore[arg-type]

    def test_case_insensitive_kind(self):
        b = backend_from_config({"kind": "Mock"})
        assert isinstance(b, MockBackend)


# --- MockBackend -----------------------------------------------------------


class TestMockBackend:
    def test_returns_canned_response(self):
        mock = MockBackend(canned_text="acknowledged")
        resp = mock.respond(make_event(sender="burr", body="ping"))
        assert resp.text == "acknowledged"
        assert resp.backend_name == "mock"
        assert resp.usage == {"tokens_in": 10, "tokens_out": 20}

    def test_records_all_calls(self):
        mock = MockBackend()
        for i in range(3):
            mock.respond(make_event(body=f"msg-{i}"))
        assert len(mock.calls) == 3
        assert mock.calls[0].body == "msg-0"
        assert mock.calls[2].body == "msg-2"

    def test_prefix_is_prepended(self):
        mock = MockBackend(canned_text="world", prefix="hello ")
        resp = mock.respond(make_event())
        assert resp.text == "hello world"

    def test_fail_with_raises_backend_error(self):
        mock = MockBackend(fail_with="rate_limited")
        with pytest.raises(BackendError) as exc:
            mock.respond(make_event())
        assert exc.value.reason == "rate_limited"

    def test_on_call_side_effect(self):
        seen: list[str] = []
        mock = MockBackend(on_call=lambda ev: seen.append(ev.sender))
        mock.respond(make_event(sender="alpha"))
        mock.respond(make_event(sender="beta"))
        assert seen == ["alpha", "beta"]

    def test_trace_id_increments(self):
        mock = MockBackend()
        r1 = mock.respond(make_event())
        r2 = mock.respond(make_event())
        assert r1.trace_id != r2.trace_id
        assert r1.trace_id == "mock-trace-1"
        assert r2.trace_id == "mock-trace-2"


# --- AnthropicBackend ------------------------------------------------------


class TestAnthropicBackend:
    def test_auth_failure_without_key(self):
        b = AnthropicBackend(api_key=None, api_key_env="NONEXISTENT_KEY")
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "auth_failed"

    def test_happy_path_parses_response(self):
        canned = {
            "id": "msg_01ABC",
            "model": "claude-sonnet-4-6",
            "content": [{"type": "text", "text": "hello back"}],
            "usage": {"input_tokens": 12, "output_tokens": 5},
        }
        b = AnthropicBackend(api_key="sk-fake", http_opener=_fake_opener(canned))
        resp = b.respond(make_event(body="hi"))
        assert resp.text == "hello back"
        assert resp.backend_name == "anthropic"
        assert resp.model_id == "claude-sonnet-4-6"
        assert resp.usage == {"tokens_in": 12, "tokens_out": 5}
        assert resp.trace_id == "msg_01ABC"
        assert resp.latency_ms >= 0

    def test_rate_limit_surfaces_as_backend_error(self):
        b = AnthropicBackend(api_key="sk-fake", http_opener=_fake_http_error(429))
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "rate_limited"

    def test_401_surfaces_as_auth_failed(self):
        b = AnthropicBackend(api_key="sk-fake", http_opener=_fake_http_error(401))
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "auth_failed"

    def test_500_surfaces_with_http_code_reason(self):
        b = AnthropicBackend(api_key="sk-fake", http_opener=_fake_http_error(500))
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "http_500"

    def test_non_json_response_surfaces_bad_response(self):
        def non_json_opener(request, timeout=None):
            return _FakeHttpResponse("<html>not json</html>")

        b = AnthropicBackend(api_key="sk-fake", http_opener=non_json_opener)
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "bad_response"

    def test_request_carries_required_headers_and_body(self):
        captured: list = []
        canned = {"content": [{"type": "text", "text": "ok"}], "usage": {}}
        b = AnthropicBackend(
            api_key="sk-pretend",
            http_opener=_fake_opener(canned, captured=captured),
        )
        b.respond(make_event(sender="burr", body="hi there"))
        req = captured[0]
        assert req.get_header("X-api-key") == "sk-pretend"
        assert req.get_header("Anthropic-version") == "2023-06-01"
        body = json.loads(req.data.decode("utf-8"))
        assert body["model"] == "claude-sonnet-4-6"
        assert "burr" in body["messages"][0]["content"]
        assert "hi there" in body["messages"][0]["content"]

    def test_empty_content_returns_empty_text(self):
        canned = {"content": [], "usage": {}}
        b = AnthropicBackend(api_key="sk-fake", http_opener=_fake_opener(canned))
        resp = b.respond(make_event())
        assert resp.text == ""


# --- GoogleBackend ---------------------------------------------------------


class TestGoogleBackend:
    def test_auth_failure_without_key(self):
        b = GoogleBackend(api_key=None, api_key_env="NONEXISTENT_KEY")
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "auth_failed"

    def test_happy_path_parses_response(self):
        canned = {
            "candidates": [
                {"content": {"parts": [{"text": "gemini says hi"}]}},
            ],
            "usageMetadata": {"promptTokenCount": 7, "candidatesTokenCount": 4},
            "responseId": "gm-resp-1",
        }
        b = GoogleBackend(api_key="fake", http_opener=_fake_opener(canned))
        resp = b.respond(make_event())
        assert resp.text == "gemini says hi"
        assert resp.backend_name == "google"
        assert resp.usage == {"tokens_in": 7, "tokens_out": 4}
        assert resp.trace_id == "gm-resp-1"

    def test_rate_limit_classified(self):
        b = GoogleBackend(api_key="fake", http_opener=_fake_http_error(429))
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "rate_limited"

    def test_missing_candidates_yields_empty_text(self):
        canned = {"candidates": [], "usageMetadata": {}}
        b = GoogleBackend(api_key="fake", http_opener=_fake_opener(canned))
        resp = b.respond(make_event())
        assert resp.text == ""

    def test_request_url_includes_model_and_key(self):
        captured: list = []
        canned = {"candidates": [], "usageMetadata": {}}
        b = GoogleBackend(
            model_id="gemini-2.5-pro",
            api_key="abc123",
            http_opener=_fake_opener(canned, captured=captured),
        )
        b.respond(make_event())
        url = captured[0].full_url
        assert "gemini-2.5-pro:generateContent" in url
        assert "key=abc123" in url


# --- OpenAIBackend ---------------------------------------------------------


class TestOpenAIBackend:
    def test_auth_failure_without_key(self):
        b = OpenAIBackend(api_key=None, api_key_env="NONEXISTENT_KEY")
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "auth_failed"

    def test_happy_path_via_output_text_convenience(self):
        """Responses API emits `output_text` as a flat convenience field."""
        canned = {
            "id": "resp_01",
            "model": "gpt-4.1-mini",
            "output_text": "openai reply here",
            "usage": {"input_tokens": 9, "output_tokens": 6},
        }
        b = OpenAIBackend(api_key="sk-fake", http_opener=_fake_opener(canned))
        resp = b.respond(make_event())
        assert resp.text == "openai reply here"
        assert resp.backend_name == "openai"
        assert resp.usage == {"tokens_in": 9, "tokens_out": 6}
        assert resp.trace_id == "resp_01"

    def test_happy_path_via_structured_output(self):
        """When output_text isn't present, parse the structured output array."""
        canned = {
            "id": "resp_02",
            "output": [
                {
                    "content": [
                        {"type": "output_text", "text": "structured reply"},
                    ]
                }
            ],
            "usage": {"input_tokens": 5, "output_tokens": 3},
        }
        b = OpenAIBackend(api_key="sk-fake", http_opener=_fake_opener(canned))
        resp = b.respond(make_event())
        assert resp.text == "structured reply"

    def test_auth_header_is_bearer(self):
        captured: list = []
        canned = {"output_text": "x", "usage": {}}
        b = OpenAIBackend(
            api_key="sk-proj-fake",
            http_opener=_fake_opener(canned, captured=captured),
        )
        b.respond(make_event())
        assert captured[0].get_header("Authorization") == "Bearer sk-proj-fake"

    def test_http_429_classified(self):
        b = OpenAIBackend(api_key="sk", http_opener=_fake_http_error(429))
        with pytest.raises(BackendError) as exc:
            b.respond(make_event())
        assert exc.value.reason == "rate_limited"


# --- Cross-cutting: _build_user_message shape ------------------------------


class TestUserMessageShape:
    def test_user_message_includes_sender_subject_priority_body(self):
        from whispers.listeners.backends.anthropic_backend import _build_user_message

        ev = make_event(sender="moss", subject="check-in", priority="flash", body="wakey")
        msg = _build_user_message(ev)
        assert "From: moss" in msg
        assert "Subject: check-in" in msg
        assert "Priority: flash" in msg
        assert "wakey" in msg

    def test_user_message_handles_flat_payload_no_packet_wrapper(self):
        from whispers.listeners.backends.anthropic_backend import _build_user_message

        ev = StreamEvent(
            kind="wake",
            event_id=1,
            payload={"sender": "flat", "body": "no packet wrapper"},
        )
        msg = _build_user_message(ev)
        assert "From: flat" in msg
        assert "no packet wrapper" in msg
