"""Slice 12 — daemon supervisor with file-watch auto-restart.

Every code change to whispers/*.py currently requires a manual
daemon kill + relaunch. Four times today this friction hit. The
DaemonSupervisor wraps the server subprocess and restarts it when any
watched Python file changes, with debouncing to avoid thrashing on
multi-file edits.

Run: pytest tests/test_daemon_supervisor.py -v
"""

from __future__ import annotations

import time

import pytest


class TestSnapshot:
    def test_snapshot_returns_empty_for_empty_dir(self, tmp_path):
        from whispers.daemon_supervisor import DaemonSupervisor

        sup = DaemonSupervisor(watch_paths=[tmp_path], restart_command=["true"])
        snap = sup._snapshot()
        assert snap == {}

    def test_snapshot_finds_py_files(self, tmp_path):
        from whispers.daemon_supervisor import DaemonSupervisor

        (tmp_path / "a.py").write_text("x = 1")
        (tmp_path / "b.py").write_text("y = 2")
        (tmp_path / "ignore.txt").write_text("z = 3")

        sup = DaemonSupervisor(watch_paths=[tmp_path], restart_command=["true"])
        snap = sup._snapshot()
        names = {p.rsplit("/", 1)[-1].rsplit("\\", 1)[-1] for p in snap.keys()}
        assert "a.py" in names
        assert "b.py" in names
        assert "ignore.txt" not in names

    def test_snapshot_skips_pycache_and_test_artifacts(self, tmp_path):
        """__pycache__/ and .pytest_cache/ dirs generate constant churn
        from the interpreter. The supervisor must ignore them or every
        import triggers a restart loop.
        """
        from whispers.daemon_supervisor import DaemonSupervisor

        (tmp_path / "a.py").write_text("x = 1")
        cache = tmp_path / "__pycache__"
        cache.mkdir()
        (cache / "a.cpython-314.pyc").write_text("bytes")
        (cache / "a.py").write_text("noise")  # even if somehow a .py lives here

        sup = DaemonSupervisor(watch_paths=[tmp_path], restart_command=["true"])
        snap = sup._snapshot()
        paths = list(snap.keys())
        assert any(p.endswith("a.py") for p in paths)
        assert not any("__pycache__" in p for p in paths)


class TestChangeDetection:
    def test_detect_change_after_file_edit(self, tmp_path):
        from whispers.daemon_supervisor import DaemonSupervisor

        file_a = tmp_path / "a.py"
        file_a.write_text("x = 1")

        sup = DaemonSupervisor(watch_paths=[tmp_path], restart_command=["true"])
        sup._last_snapshot = sup._snapshot()

        # Sleep briefly so mtime granularity (1s on some filesystems) sees
        # the edit as distinct.
        time.sleep(1.1)
        file_a.write_text("x = 2")

        changed = sup._changed_paths()
        assert any(p.endswith("a.py") for p in changed)

    def test_no_change_when_nothing_edited(self, tmp_path):
        from whispers.daemon_supervisor import DaemonSupervisor

        (tmp_path / "a.py").write_text("x = 1")
        sup = DaemonSupervisor(watch_paths=[tmp_path], restart_command=["true"])
        sup._last_snapshot = sup._snapshot()

        assert sup._changed_paths() == []

    def test_detect_new_file_as_change(self, tmp_path):
        from whispers.daemon_supervisor import DaemonSupervisor

        sup = DaemonSupervisor(watch_paths=[tmp_path], restart_command=["true"])
        sup._last_snapshot = sup._snapshot()

        (tmp_path / "new.py").write_text("print('hello')")
        changed = sup._changed_paths()
        assert any(p.endswith("new.py") for p in changed)


class TestSubprocessLifecycle:
    def test_spawn_and_stop_subprocess_cleanly(self, tmp_path):
        """Supervisor spawns a subprocess via restart_command and can
        stop it cleanly via _stop_subprocess without leaving zombies.
        """
        import sys
        from whispers.daemon_supervisor import DaemonSupervisor

        # Use a Python one-liner that loops forever so we have a real
        # subprocess to manage. Uses stdlib only.
        sup = DaemonSupervisor(
            watch_paths=[tmp_path],
            restart_command=[sys.executable, "-c", "import time\nwhile True: time.sleep(0.1)"],
        )
        sup._spawn()
        assert sup.subprocess is not None
        assert sup.subprocess.poll() is None, "subprocess should be alive after spawn"

        sup._stop_subprocess()
        assert sup.subprocess.poll() is not None, "subprocess should be dead after stop"

    def test_stop_is_idempotent(self, tmp_path):
        """Calling stop on an already-dead or never-spawned supervisor
        must not raise.
        """
        from whispers.daemon_supervisor import DaemonSupervisor

        sup = DaemonSupervisor(
            watch_paths=[tmp_path],
            restart_command=["true"],
        )
        sup._stop_subprocess()  # never spawned
        sup._stop_subprocess()  # twice in a row


class TestDebouncing:
    def test_debounce_suppresses_rapid_successive_changes(self, tmp_path):
        """Two quick changes within the debounce window should count as
        one restart trigger, not two. Prevents restart thrashing on
        multi-file saves.
        """
        from whispers.daemon_supervisor import DaemonSupervisor

        file_a = tmp_path / "a.py"
        file_a.write_text("x = 1")
        sup = DaemonSupervisor(
            watch_paths=[tmp_path],
            restart_command=["true"],
            debounce_seconds=0.5,
        )
        sup._last_snapshot = sup._snapshot()

        # Rapid edits
        time.sleep(1.1)
        file_a.write_text("x = 2")
        time.sleep(0.05)
        file_a.write_text("x = 3")

        changed_first = sup._changed_paths()
        assert changed_first, "first call must see the change"
        # If we immediately ask again (still within debounce_seconds since
        # the last check), should return [] — the supervisor has seen it.
        sup._last_snapshot = sup._snapshot()
        changed_second = sup._changed_paths()
        assert changed_second == []
