"""Issuer keypair + /identity/keys/<issuer> endpoint tests (T4.21).

Stage A slice P1. Pure infrastructure: persist + load an Ed25519
issuer keypair, serve its public key + key_id over HTTP so verifiers
can fetch it. No bind integration here.

Tests cover:
  * Fresh dir → keypair is generated and persisted
  * Subsequent load → same keypair (same key_id) — idempotent
  * Override path via WHISPERS_KEYS_DIR / explicit kwarg
  * Endpoint response shape + roundtrip through public-key (de)serialize
"""

from __future__ import annotations

import os
import threading
import time
from http.client import HTTPConnection
from pathlib import Path
from typing import Iterator

import pytest

from whispers.pollen import (
    IssuerKeypair,
    deserialize_public_key,
    load_or_generate_issuer_keypair,
)
from whispers.pollen.keys import (
    DEFAULT_KEYS_DIR_ENV,
    PRIVATE_KEY_FILENAME,
    PUBLIC_KEY_FILENAME,
)
from whispers.pollen.signing import compute_key_id


# ----------------------------------------------------------------------
# load_or_generate_issuer_keypair — disk persistence
# ----------------------------------------------------------------------


def test_first_run_generates_keypair(tmp_path):
    keys_dir = tmp_path / "keys"
    assert not keys_dir.exists()

    keypair = load_or_generate_issuer_keypair(keys_dir=keys_dir)

    assert isinstance(keypair, IssuerKeypair)
    assert keys_dir.exists()
    assert (keys_dir / PRIVATE_KEY_FILENAME).exists()
    assert (keys_dir / PUBLIC_KEY_FILENAME).exists()
    assert len(keypair.public_key_raw) == 32
    assert len(keypair.key_id) == 16


def test_subsequent_run_reuses_same_keypair(tmp_path):
    keys_dir = tmp_path / "keys"

    first = load_or_generate_issuer_keypair(keys_dir=keys_dir)
    second = load_or_generate_issuer_keypair(keys_dir=keys_dir)

    assert first.key_id == second.key_id
    assert first.public_key_raw == second.public_key_raw
    assert first.private_key_pem == second.private_key_pem


def test_different_dirs_produce_different_keypairs(tmp_path):
    a = load_or_generate_issuer_keypair(keys_dir=tmp_path / "a")
    b = load_or_generate_issuer_keypair(keys_dir=tmp_path / "b")

    # Two independently-generated keypairs MUST differ.
    assert a.key_id != b.key_id
    assert a.public_key_raw != b.public_key_raw


def test_env_var_override(tmp_path, monkeypatch):
    keys_dir = tmp_path / "from_env"
    monkeypatch.setenv(DEFAULT_KEYS_DIR_ENV, str(keys_dir))

    keypair = load_or_generate_issuer_keypair()  # no explicit override

    assert (keys_dir / PRIVATE_KEY_FILENAME).exists()
    assert (keys_dir / PUBLIC_KEY_FILENAME).exists()
    assert keypair.keys_dir == keys_dir


def test_explicit_kwarg_wins_over_env(tmp_path, monkeypatch):
    env_dir = tmp_path / "from_env"
    explicit_dir = tmp_path / "explicit"
    monkeypatch.setenv(DEFAULT_KEYS_DIR_ENV, str(env_dir))

    keypair = load_or_generate_issuer_keypair(keys_dir=explicit_dir)

    assert keypair.keys_dir == explicit_dir
    assert (explicit_dir / PRIVATE_KEY_FILENAME).exists()
    assert not env_dir.exists()  # env var was overridden


def test_public_key_roundtrip_through_serialize(tmp_path):
    keypair = load_or_generate_issuer_keypair(keys_dir=tmp_path / "k")

    encoded = keypair.public_key_b64u
    decoded = deserialize_public_key(encoded)

    assert decoded == keypair.public_key_raw


def test_key_id_matches_compute_key_id(tmp_path):
    keypair = load_or_generate_issuer_keypair(keys_dir=tmp_path / "k")
    assert keypair.key_id == compute_key_id(keypair.public_key_raw)


def test_corrupt_public_key_file_raises(tmp_path):
    """If the .pub.b64u file is hand-edited to garbage, refuse to load."""
    keys_dir = tmp_path / "k"
    keys_dir.mkdir()
    # Create a broken pair: private exists, public is garbage
    keypair = load_or_generate_issuer_keypair(keys_dir=keys_dir)
    pub_path = keys_dir / PUBLIC_KEY_FILENAME
    pub_path.write_text("not-a-valid-base64url-32-byte-key", encoding="utf-8")

    with pytest.raises(ValueError):
        load_or_generate_issuer_keypair(keys_dir=keys_dir)


# ----------------------------------------------------------------------
# /identity/keys/<issuer> endpoint
# ----------------------------------------------------------------------


@pytest.fixture
def isolated_keys_dir(tmp_path, monkeypatch):
    keys_dir = tmp_path / "endpoint_keys"
    monkeypatch.setenv(DEFAULT_KEYS_DIR_ENV, str(keys_dir))
    yield keys_dir


@pytest.fixture
def live_server(isolated_keys_dir, tmp_path) -> Iterator[str]:
    """Spin up the real Whispers FastAPI app on a random port for HTTP testing."""
    import uvicorn

    from whispers.server import create_app
    from whispers.client import WhispersClient

    db_path = str(tmp_path / "endpoint_test.db")
    # Ensure schema exists
    WhispersClient(agent_name="endpoint-bootstrap", db_path=db_path)
    app = create_app(db_path=db_path)

    config = uvicorn.Config(
        app, host="127.0.0.1", port=0, log_level="error", access_log=False
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    # Wait for server to be ready
    for _ in range(50):
        if server.started and server.servers:
            break
        time.sleep(0.05)
    if not server.started or not server.servers:
        pytest.fail("Server failed to start within 2.5s")

    sockets = list(server.servers[0].sockets)
    port = sockets[0].getsockname()[1]

    yield f"127.0.0.1:{port}"

    server.should_exit = True
    thread.join(timeout=5)


def test_endpoint_returns_expected_shape(live_server, isolated_keys_dir):
    host_port = live_server
    conn = HTTPConnection(host_port, timeout=5)
    conn.request("GET", "/identity/keys/whispers-daemon")
    response = conn.getresponse()
    assert response.status == 200

    import json
    payload = json.loads(response.read().decode("utf-8"))
    conn.close()

    assert payload["issuer_callsign"] == "whispers-daemon"
    assert payload["algorithm"] == "ed25519"
    assert isinstance(payload["key_id"], str)
    assert len(payload["key_id"]) == 16
    assert isinstance(payload["public_key_b64u"], str)

    # Round-trip the public key through deserialize → 32 bytes raw
    raw = deserialize_public_key(payload["public_key_b64u"])
    assert len(raw) == 32
    assert compute_key_id(raw) == payload["key_id"]


def test_endpoint_consistent_across_calls(live_server, isolated_keys_dir):
    host_port = live_server
    payloads = []
    import json
    for _ in range(3):
        conn = HTTPConnection(host_port, timeout=5)
        conn.request("GET", "/identity/keys/whispers-daemon")
        response = conn.getresponse()
        payloads.append(json.loads(response.read().decode("utf-8")))
        conn.close()

    assert payloads[0]["key_id"] == payloads[1]["key_id"] == payloads[2]["key_id"]
    assert payloads[0]["public_key_b64u"] == payloads[1]["public_key_b64u"]


def test_endpoint_resolves_any_issuer_callsign_to_local_keypair(live_server, isolated_keys_dir):
    """v6 single-daemon scope: any issuer callsign returns the local keypair."""
    host_port = live_server
    import json
    results = {}
    for issuer in ("whispers-daemon", "burr", "some-other-name"):
        conn = HTTPConnection(host_port, timeout=5)
        conn.request("GET", f"/identity/keys/{issuer}")
        response = conn.getresponse()
        payload = json.loads(response.read().decode("utf-8"))
        results[issuer] = payload
        conn.close()
        assert payload["issuer_callsign"] == issuer

    # All three responses carry the same key_id (single daemon, single keypair)
    key_ids = {r["key_id"] for r in results.values()}
    assert len(key_ids) == 1
