from __future__ import annotations

from whispers.testing import WhispersTestHarness

class TestTwoAckDeadLetterSenderReplay:
    def test_binding_sender_replays_dead_letters_to_sender(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")

            # Alice sends a message to Bob, who isn't online or doesn't exist
            sent = alice.send("bob", "Hello Bob", body="sender replay please")
            assert sent["status"] == "dead_lettered"

            # Right now, only Bob gets the replay on bind. 
            # Invariant: Sender gets symmetric dead-letter replay on their next bind.
            
            # Alice does another bind (or whoami), which should trigger the replay to sender.
            alice_reconnect = h.make_client("alice")
            
            # Now, Alice's inbox should contain her dead-lettered message.
            inbox = alice_reconnect.check_inbox(mark_seen=False)
            dead_lettered = [item for item in inbox if item["message_id"] == sent["message_id"]]
            
            # Verify Alice actually received the dead letter receipt in her inbox
            assert len(dead_lettered) == 1
            assert dead_lettered[0]["subject"] == "Hello Bob"
            assert dead_lettered[0]["status"] == "dead_lettered"
            # It's still from Alice to Bob, but Alice is receiving it
            assert dead_lettered[0]["sender"] == "alice"
            assert dead_lettered[0]["recipient"] == "bob"

            # Check the DB manually to verify we added a message_recipients row for Alice
            with alice.db.get_connection() as conn:
                recipients = conn.execute(
                    "SELECT COUNT(*) AS c FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
                    (sent["message_id"], "alice"),
                ).fetchone()
            assert int(recipients["c"] or 0) == 1
