"""Crawl #11: server_reload_clients MCP tool.

Trust-tier-5 agents can evict all in-memory MCP seat bindings.
Agents below tier 5 are rejected.
"""
from __future__ import annotations

import json
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Tuple

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client

from whispers.client import WhispersClient
from whispers.server import create_app
from whispers.testing import WhispersTestHarness


def _tool_json(result) -> dict:
    assert result, "empty tool result"
    item = result[0]
    text = getattr(item, "text", "") or ""
    assert text, f"tool result has no text content: {item!r}"
    return json.loads(text)


@asynccontextmanager
async def _mcp_session(
    app,
    callsign: str,
    *,
    rebind: bool = False,
) -> AsyncGenerator[Tuple[ClientSession, dict], None]:
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://127.0.0.1") as http_client:
        async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as streams:
            read, write, _ = streams
            async with ClientSession(read, write) as session:
                await session.initialize()
                bound = await session.call_tool(
                    "bind_seat",
                    {
                        "requested_callsign": callsign,
                        "participant_profile": "desktop_ide_agent",
                        "rebind": rebind,
                    },
                )
                payload = _tool_json(bound.content)
                assert payload["bound"] is True, f"bind_seat failed for {callsign}: {payload}"
                yield session, payload


@pytest.mark.asyncio
async def test_server_reload_clients_tier5_succeeds():
    """A tier-5 agent can reload the server client cache."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            # Pre-register admin at tier 5 via direct client
            setup = WhispersClient("apex", db_path=h.db_path, participant_profile="desktop_ide_agent")
            setup.trust_set(new_tier=5, actor="apex", reason="test setup")

            async with _mcp_session(app, "apex", rebind=True) as (session, _):
                result = await session.call_tool("server_reload_clients", {})
                payload = _tool_json(result.content)
                assert payload["reloaded"] is True
                assert isinstance(payload["evicted_sessions"], int)


@pytest.mark.asyncio
async def test_server_reload_clients_below_tier5_rejected(monkeypatch):
    """An agent below tier 5 is rejected without side effects.
    Post-2026-04-17 trust_baseline default flipped 1→5; force
    multi-tenant mode so 'lowbie' actually lands below tier 5.
    """
    monkeypatch.setenv("WHISPERS_MULTI_TENANT", "1")
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            async with _mcp_session(app, "lowbie") as (session, _):
                result = await session.call_tool("server_reload_clients", {})
                payload = _tool_json(result.content)
                assert payload["reloaded"] is False
                assert "tier" in payload.get("error", "").lower()


@pytest.mark.asyncio
async def test_server_reload_clients_evicts_bound_sessions():
    """After reload, previously bound session keys are cleared from the manager."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            setup = WhispersClient("apex", db_path=h.db_path, participant_profile="desktop_ide_agent")
            setup.trust_set(new_tier=5, actor="apex", reason="test setup")
            WhispersClient("peer", db_path=h.db_path, participant_profile="desktop_ide_agent")

            async with _mcp_session(app, "peer", rebind=True) as (peer_session, _):
                async with _mcp_session(app, "apex", rebind=True) as (admin_session, _):
                    # Two sessions are active; admin evicts both
                    result = await admin_session.call_tool("server_reload_clients", {})
                    payload = _tool_json(result.content)
                    assert payload["reloaded"] is True
                    assert payload["evicted_sessions"] == 2
