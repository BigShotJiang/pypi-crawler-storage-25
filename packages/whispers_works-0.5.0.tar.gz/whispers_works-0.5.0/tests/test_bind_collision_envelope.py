"""Slice 6 Phase B — bind-time collision envelope helper tests.

Library-level unit tests for the two helpers that Phase C will wire into
the `bind_seat` MCP tool:

    build_collision_envelope(db_path, requested_callsign, platform_family,
                             conflict) -> dict
    apply_collision_resolution(db_path, requested_callsign, platform_family,
                               resolve, actor=None) -> dict

See SLICE-6-BIND-COLLISION-CHOICE-2026-04-17.md for the design doc and
envelope schema. Tests intentionally work against the library boundary,
not the MCP tool surface — Phase C adds integration tests on top.

Run: pytest tests/test_bind_collision_envelope.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.storage.db import WhispersDB


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _seed_anchor_mismatch(db_path: str, *, with_live_session: bool = False) -> dict:
    """Seed a collision where callsign 'burr' already maps to a card with
    anchor A, but an incoming bind would derive anchor B. Mirrors the
    live scenario that prompted this whole slice.
    """
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            "INSERT INTO agent_cards (agent_id, callsign, trust_tier, platform_family, "
            "stable_subject_id, continuity_anchor, registered_at, last_seen) "
            "VALUES (?, ?, ?, ?, ?, ?, datetime('now','-1 hour'), datetime('now','-30 minutes'))",
            ("agent-burr-existing", "burr", 5, "claude-code",
             "subj-burr-existing", "anchor:existing-one"),
        )
        conn.execute(
            "INSERT INTO callsign_ledger (callsign, stable_subject_id, agent_id, status, "
            "first_seen_at, last_bound_at) VALUES (?, ?, ?, 'current', "
            "datetime('now','-1 hour'), datetime('now','-1 hour'))",
            ("burr", "subj-burr-existing", "agent-burr-existing"),
        )
        if with_live_session:
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_id, agent_name, session_kind, "
                "created_at, last_seen_at, lease_expires_at) VALUES (?, ?, ?, 'mcp_http', "
                "datetime('now'), datetime('now'), datetime('now','+30 minutes'))",
                ("sess-live", "agent-burr-existing", "burr"),
            )
        conn.commit()
    finally:
        conn.close()
    return {
        "kind": "anchor_mismatch",
        "requested_anchor": "anchor:would-derive-different",
        "existing_agent_id": "agent-burr-existing",
        "existing_continuity_anchor": "anchor:existing-one",
    }


def _seed_ledger_reservation(db_path: str) -> dict:
    """Ledger row lingers but no card. Today's dead-state after a prior
    session closed without clean unbind (pre-Slice-5.5 scenario).
    """
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            "INSERT INTO callsign_ledger (callsign, stable_subject_id, agent_id, status, "
            "first_seen_at, last_bound_at) VALUES (?, ?, ?, 'current', "
            "datetime('now','-2 hours'), datetime('now','-2 hours'))",
            ("orphan", "subj-gone", "agent-gone"),
        )
        conn.commit()
    finally:
        conn.close()
    return {
        "kind": "ledger_reservation",
        "reserved_stable_subject_id": "subj-gone",
    }


# ---------------------------------------------------------------------------
# build_collision_envelope — shape & choices
# ---------------------------------------------------------------------------


class TestEnvelopeShape:
    def test_anchor_mismatch_no_live_session_offers_take_over(self, tmp_path):
        """When callsign is anchored to an orphaned card (no live session),
        the envelope MUST include take_over as a valid choice — it's the
        reason this slice exists.
        """
        from whispers.orientation import build_collision_envelope

        db_path = str(tmp_path / "env.db")
        WhispersDB(db_path=db_path)
        conflict = _seed_anchor_mismatch(db_path, with_live_session=False)

        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            conflict=conflict,
        )

        assert envelope["bound"] is False
        assert envelope["reason"] == "callsign_collision"
        assert envelope["requested_callsign"] == "burr"
        assert envelope["collision"]["kind"] == "anchor_mismatch"
        assert envelope["collision"]["live_sessions"] == 0
        assert envelope["collision"]["ledger_status"] == "current"

        choice_ids = [c["id"] for c in envelope["choices"]]
        assert "take_over" in choice_ids
        assert "sibling" in choice_ids
        assert "fresh" in choice_ids

        take_over = next(c for c in envelope["choices"] if c["id"] == "take_over")
        assert take_over["precondition_ok"] is True
        assert take_over["resolution_payload"]["resolve"] == "take_over"

    def test_anchor_mismatch_with_live_session_blocks_take_over(self, tmp_path):
        """When the colliding card has a live session, take_over MUST be
        marked precondition_ok=False. A fresh session does not get to steal
        a live peer's seat — that's a security/coordination failure, not a
        feature.
        """
        from whispers.orientation import build_collision_envelope

        db_path = str(tmp_path / "env_live.db")
        WhispersDB(db_path=db_path)
        conflict = _seed_anchor_mismatch(db_path, with_live_session=True)

        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            conflict=conflict,
        )

        assert envelope["collision"]["live_sessions"] >= 1
        take_over = next(c for c in envelope["choices"] if c["id"] == "take_over")
        assert take_over["precondition_ok"] is False
        assert "live_session" in take_over.get("precondition_reason", "").lower() \
            or "live_session" in " ".join(take_over.get("risks", []))

    def test_ledger_reservation_offers_take_over_but_not_sibling(self, tmp_path):
        """Ledger-only reservation (no active card) — sibling makes no
        sense because there's no active sibling pool to inherit tier from.
        take_over and fresh are offered; sibling is NOT.
        """
        from whispers.orientation import build_collision_envelope

        db_path = str(tmp_path / "env_ledger.db")
        WhispersDB(db_path=db_path)
        conflict = _seed_ledger_reservation(db_path)

        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="orphan",
            platform_family="claude-code",
            conflict=conflict,
        )

        assert envelope["collision"]["kind"] == "ledger_reservation"
        choice_ids = [c["id"] for c in envelope["choices"]]
        assert "take_over" in choice_ids
        assert "fresh" in choice_ids
        assert "sibling" not in choice_ids

    def test_envelope_includes_operator_hint(self, tmp_path):
        """Operator hint is a plain-language summary of the typical pick.
        It does not force a choice — just names what the usual resolution
        would be given the state.
        """
        from whispers.orientation import build_collision_envelope

        db_path = str(tmp_path / "env_hint.db")
        WhispersDB(db_path=db_path)
        conflict = _seed_anchor_mismatch(db_path, with_live_session=False)

        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            conflict=conflict,
        )

        assert isinstance(envelope.get("operator_hint"), str)
        assert len(envelope["operator_hint"]) > 10

    def test_envelope_exposes_history_summary(self, tmp_path):
        """Operator needs to see whether the orphan card had activity —
        otherwise "take over burr" is an ambiguous choice. History summary
        counts the messages and workspaces associated with the stale card.
        """
        from whispers.orientation import build_collision_envelope

        db_path = str(tmp_path / "env_history.db")
        WhispersDB(db_path=db_path)
        conflict = _seed_anchor_mismatch(db_path, with_live_session=False)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, subject, body, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, datetime('now','-1 hour'))",
                ("m1", "burr", "spark", "inform", "x", "y"),
            )
            conn.execute(
                "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, subject, body, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, datetime('now','-30 minutes'))",
                ("m2", "spark", "burr", "inform", "x", "y"),
            )
            conn.commit()
        finally:
            conn.close()

        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            conflict=conflict,
        )

        history = envelope["collision"].get("history_summary", {})
        assert history.get("messages_as_sender", 0) == 1
        assert history.get("messages_as_recipient", 0) == 1


# ---------------------------------------------------------------------------
# apply_collision_resolution — side-effects & next-step contract
# ---------------------------------------------------------------------------


class TestApplyResolution:
    def test_take_over_releases_ledger_and_card(self, tmp_path):
        """take_over on an orphaned anchor_mismatch runs release_callsign(),
        removing the blocker so a subsequent bind_seat succeeds.
        Returns next_step='retry_bind' to signal the caller to re-invoke.
        """
        from whispers.orientation import apply_collision_resolution

        db_path = str(tmp_path / "apply_take.db")
        WhispersDB(db_path=db_path)
        _seed_anchor_mismatch(db_path, with_live_session=False)

        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "take_over"},
            actor="test-operator",
        )

        assert result["ok"] is True
        assert result["resolved"] == "take_over"
        assert result["next_step"] == "retry_bind"

        conn = sqlite3.connect(db_path)
        try:
            ledger = conn.execute(
                "SELECT * FROM callsign_ledger WHERE callsign=?", ("burr",)
            ).fetchone()
            card = conn.execute(
                "SELECT * FROM agent_cards WHERE callsign=?", ("burr",)
            ).fetchone()
        finally:
            conn.close()
        assert ledger is None
        assert card is None

    def test_take_over_blocked_when_live_session_present(self, tmp_path):
        """Live session on the colliding anchor → take_over must fail.
        ok=False, reason names the blocker, no side effects.
        """
        from whispers.orientation import apply_collision_resolution

        db_path = str(tmp_path / "apply_live.db")
        WhispersDB(db_path=db_path)
        _seed_anchor_mismatch(db_path, with_live_session=True)

        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "take_over"},
            actor="test-operator",
        )

        assert result["ok"] is False
        assert "live_session" in result.get("reason", "").lower()

        conn = sqlite3.connect(db_path)
        try:
            ledger = conn.execute(
                "SELECT * FROM callsign_ledger WHERE callsign=?", ("burr",)
            ).fetchone()
        finally:
            conn.close()
        assert ledger is not None, "take_over must not release ledger when live session present"

    def test_cancel_is_a_clean_noop(self, tmp_path):
        """Resolve cancel returns next_step='cancelled' with ok=True and
        does not touch any ledger/card/presence rows.
        """
        from whispers.orientation import apply_collision_resolution

        db_path = str(tmp_path / "apply_cancel.db")
        WhispersDB(db_path=db_path)
        _seed_anchor_mismatch(db_path, with_live_session=False)

        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "cancel"},
        )

        assert result["ok"] is True
        assert result["resolved"] == "cancel"
        assert result["next_step"] == "cancelled"

        conn = sqlite3.connect(db_path)
        try:
            ledger = conn.execute(
                "SELECT * FROM callsign_ledger WHERE callsign=?", ("burr",)
            ).fetchone()
        finally:
            conn.close()
        assert ledger is not None, "cancel must not release anything"

    def test_sibling_returns_label_for_bind_retry(self, tmp_path):
        """Sibling resolution validates the payload and returns a label
        the caller must pass as sibling_label on the retry bind. Does not
        touch any rows on its own — the actual allocation happens when
        connect() runs with sibling_label.
        """
        from whispers.orientation import apply_collision_resolution

        db_path = str(tmp_path / "apply_sibling.db")
        WhispersDB(db_path=db_path)
        _seed_anchor_mismatch(db_path, with_live_session=False)

        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "sibling", "label": "a3f1"},
        )

        assert result["ok"] is True
        assert result["resolved"] == "sibling"
        assert result["next_step"] == "sibling_bind"
        assert result["sibling_label"] == "a3f1"

    def test_unknown_resolve_verb_is_rejected(self, tmp_path):
        """Unknown verbs (typos, future verbs the server doesn't implement
        yet) must fail loudly rather than silently no-op.
        """
        from whispers.orientation import apply_collision_resolution

        db_path = str(tmp_path / "apply_unknown.db")
        WhispersDB(db_path=db_path)
        _seed_anchor_mismatch(db_path, with_live_session=False)

        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "destroy_everything"},
        )

        assert result["ok"] is False
        assert "unknown" in result.get("reason", "").lower() \
            or "invalid" in result.get("reason", "").lower()

    def test_take_over_writes_identity_event(self, tmp_path):
        """Every resolution path must emit an identity_events audit row
        so the operator can reconstruct who released what and when.
        """
        from whispers.orientation import apply_collision_resolution

        db_path = str(tmp_path / "apply_audit.db")
        WhispersDB(db_path=db_path)
        _seed_anchor_mismatch(db_path, with_live_session=False)

        apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "take_over"},
            actor="operator-zack",
            reason="reclaim orphaned session",
        )

        conn = sqlite3.connect(db_path)
        try:
            events = conn.execute(
                "SELECT event_type, outcome, callsign FROM identity_events "
                "WHERE callsign=? ORDER BY event_id DESC LIMIT 1",
                ("burr",),
            ).fetchall()
        finally:
            conn.close()
        assert len(events) >= 1
        event_row = events[0]
        assert event_row[2] == "burr"
