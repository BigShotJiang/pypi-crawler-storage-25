"""Visual-convention markers and frame builders are the product surface.

These tests pin the exact glyphs and frame shapes so a refactor of the
message-path or statusline cannot silently drift the operator-visible
language. A drift-prevention fence at the bottom fails the build if a
raw glyph appears anywhere in ``whispers/*.py`` other than ``frames.py``.
"""
from __future__ import annotations

import pathlib

from whispers import frames


# ---- Constants are canonical ----------------------------------------------
def test_marker_constants_are_canonical():
    assert frames.MARKER == "⏦⏦⏦"
    assert frames.ARROW == "▶"
    assert frames.SEPARATOR == " · "
    assert frames.STATE_MARKER == "⟡"
    assert frames.URGENT_MARKER == "◆"
    assert frames.INBOX_MARKER == "◈"
    assert frames.ARCHIVED_MARKER == "◇"
    assert frames.OUTBOUND_PREFIX == "⏦⏦⏦>"
    assert frames.INBOUND_PREFIX == "<⏦⏦⏦"


# ---- Message-frame builders ------------------------------------------------
def test_message_frame_header_without_state():
    header = frames.message_frame_header(
        "alpha", "beta", "routine", "hello"
    )
    assert header == "⏦⏦⏦ from alpha ▶ to beta · routine · hello"


def test_message_frame_header_with_state():
    header = frames.message_frame_header(
        "flint", "spark", "priority", "landed 1863788", state="building"
    )
    assert header == "⏦⏦⏦ from flint ▶ to spark · priority ⟡ building · landed 1863788"


def test_format_message_frame_no_body():
    out = frames.format_message_frame("a", "b", "routine", "subj")
    assert out == "⏦⏦⏦ from a ▶ to b · routine · subj"
    assert "\n" not in out


def test_format_message_frame_with_body():
    out = frames.format_message_frame(
        "a", "b", "routine", "subj", body="first line"
    )
    assert out == "⏦⏦⏦ from a ▶ to b · routine · subj\nfirst line"


def test_format_message_frame_with_state_and_body():
    out = frames.format_message_frame(
        "a", "b", "priority", "subj", body="body", state="blocked"
    )
    assert out == "⏦⏦⏦ from a ▶ to b · priority ⟡ blocked · subj\nbody"


# ---- Statusline helpers ----------------------------------------------------
def test_signal_line_prefix():
    assert frames.signal_line_prefix("cinder") == "⏦⏦⏦ cinder"


def test_urgent_count_chunk():
    assert frames.urgent_count_chunk(3) == "◆3 urgent"
    assert frames.urgent_count_chunk(0) == "◆0 urgent"


# ---- Lifecycle / inbox banners --------------------------------------------
def test_inbox_banner():
    assert frames.inbox_banner("new message from burr") == "◈ new message from burr"


def test_archived_banner():
    assert frames.archived_banner("thread sealed") == "◇ thread sealed"


# ---- Ambient-narration variants -------------------------------------------
def test_outbound_narration():
    assert frames.outbound_narration("sending to burr") == "⏦⏦⏦> sending to burr"


def test_inbound_narration():
    assert frames.inbound_narration("burr replied") == "<⏦⏦⏦ burr replied"


# ---- Drift-prevention fence -----------------------------------------------
# This test walks whispers/*.py and fails if any file OTHER than frames.py
# contains a raw glyph. Tests are allowed to hold glyphs (they assert on
# observed bytes, which is the correct discipline).
def test_no_raw_glyphs_in_whispers_source_outside_frames():
    repo_root = pathlib.Path(__file__).resolve().parent.parent
    whispers_pkg = repo_root / "whispers"
    assert whispers_pkg.is_dir(), f"whispers package not found at {whispers_pkg}"

    glyphs = [
        frames.MARKER,
        frames.ARROW,
        frames.STATE_MARKER,
        frames.URGENT_MARKER,
        frames.INBOX_MARKER,
        frames.ARCHIVED_MARKER,
    ]
    allow = {"frames.py"}
    offenders: list[tuple[str, str]] = []

    for py_file in whispers_pkg.rglob("*.py"):
        if "__pycache__" in py_file.parts:
            continue
        if py_file.name in allow:
            continue
        text = py_file.read_text(encoding="utf-8")
        for glyph in glyphs:
            if glyph in text:
                offenders.append((str(py_file.relative_to(repo_root)), glyph))

    assert not offenders, (
        "Raw visual-convention glyphs found outside whispers/frames.py — "
        "import from whispers.frames instead. Offenders: "
        f"{offenders!r}"
    )
