"""Crawl #9: Two agents, one room — real HTTP MCP sessions, message exchange, identity verification,
and mid-thread rebind continuity.

Two sessions (alpha_agent="rho", beta_agent="tau") are spun up against the same in-process ASGI
app, send 10 messages each direction, and each verifies that every received message carries the
expected sender stable_subject_id.  A mid-thread rebind is performed and the conversation
continues, proving that message continuity survives a session restart.
"""
from __future__ import annotations

import asyncio
import json
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Tuple

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client

from whispers.server import create_app
from whispers.testing import WhispersTestHarness
from whispers.twoack import preflight_decision, validate_envelope


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _tool_json(result) -> dict:
    assert result, "empty tool result"
    item = result[0]
    text = getattr(item, "text", "") or ""
    assert text, f"tool result has no text content: {item!r}"
    return json.loads(text)


@asynccontextmanager
async def _mcp_session(
    app,
    callsign: str,
    *,
    rebind: bool = False,
) -> AsyncGenerator[Tuple[ClientSession, dict], None]:
    """Context manager that yields (session, whoami_payload) for the given callsign."""
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://127.0.0.1") as http_client:
        async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as streams:
            read, write, _ = streams
            async with ClientSession(read, write) as session:
                await session.initialize()
                bound = await session.call_tool(
                    "bind_seat",
                    {
                        "requested_callsign": callsign,
                        "participant_profile": "desktop_ide_agent",
                        "rebind": rebind,
                    },
                )
                payload = _tool_json(bound.content)
                assert payload["bound"] is True, f"bind_seat failed for {callsign}: {payload}"
                yield session, payload


async def _send(session: ClientSession, *, to: str, subject: str, body: str) -> dict:
    result = await session.call_tool("send", {"to": to, "subject": subject, "body": body})
    return _tool_json(result.content)


async def _inbox(session: ClientSession, *, limit: int = 20) -> list[dict]:
    result = await session.call_tool("inbox", {"limit": limit, "mark_seen": True})
    payload = _tool_json(result.content)
    if isinstance(payload, list):
        return payload
    return payload.get("messages", [])


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_two_agents_bind_and_have_distinct_identities():
    """Both agents bind successfully and have different stable_subject_ids."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            async with _mcp_session(app, "rho") as (_, spark_payload):
                async with _mcp_session(app, "tau") as (_, flint_payload):
                    spark_who = spark_payload["whoami"]
                    flint_who = flint_payload["whoami"]

                    assert spark_who["callsign"] == "rho"
                    assert flint_who["callsign"] == "tau"
                    assert spark_who["stable_subject_id"] != flint_who["stable_subject_id"]


@pytest.mark.asyncio
async def test_ten_messages_each_direction_with_identity_verification():
    """rho and tau exchange 10 messages each direction; every received message has
    the correct sender stable_subject_id."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            async with _mcp_session(app, "rho") as (spark_session, spark_payload):
                async with _mcp_session(app, "tau") as (flint_session, flint_payload):
                    spark_ssid = spark_payload["whoami"]["stable_subject_id"]
                    flint_ssid = flint_payload["whoami"]["stable_subject_id"]

                    # spark -> flint: 10 messages
                    for i in range(10):
                        await _send(
                            spark_session,
                            to="tau",
                            subject=f"spark->flint #{i}",
                            body=f"message {i} from rho",
                        )

                    # flint -> spark: 10 messages
                    for i in range(10):
                        await _send(
                            flint_session,
                            to="rho",
                            subject=f"flint->spark #{i}",
                            body=f"message {i} from tau",
                        )

                    # Verify flint received 10 messages from spark
                    flint_inbox = await _inbox(flint_session)
                    spark_to_flint = [m for m in flint_inbox if m.get("from_agent") == "rho"]
                    assert len(spark_to_flint) == 10, (
                        f"Expected 10 messages from rho, got {len(spark_to_flint)}"
                    )
                    for msg in spark_to_flint:
                        assert msg.get("from_agent") == "rho", (
                            f"Message {msg.get('subject')} has wrong sender: {msg}"
                        )

                    # Verify spark received 10 messages from flint
                    spark_inbox = await _inbox(spark_session)
                    flint_to_spark = [m for m in spark_inbox if m.get("from_agent") == "tau"]
                    assert len(flint_to_spark) == 10, (
                        f"Expected 10 messages from tau, got {len(flint_to_spark)}"
                    )
                    for msg in flint_to_spark:
                        assert msg.get("from_agent") == "tau", (
                            f"Message {msg.get('subject')} has wrong sender: {msg}"
                        )


@pytest.mark.asyncio
async def test_mid_thread_rebind_preserves_message_continuity():
    """rho sends 5 messages, rebinds (new session), then sends 5 more.
    tau receives all 10 in order."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            # Phase 1: spark sends first 5
            async with _mcp_session(app, "tau") as (flint_session, _):
                async with _mcp_session(app, "rho") as (spark_session, spark_payload):
                    spark_ssid = spark_payload["whoami"]["stable_subject_id"]
                    for i in range(5):
                        await _send(
                            spark_session,
                            to="tau",
                            subject=f"pre-rebind #{i}",
                            body=f"batch 1 message {i}",
                        )
                # rho session ends here (simulates disconnect)

                # Phase 2: spark rebinds (same agent reconnecting) and sends 5 more
                async with _mcp_session(app, "rho", rebind=True) as (spark2_session, spark2_payload):
                    spark2_ssid = spark2_payload["whoami"]["stable_subject_id"]
                    for i in range(5):
                        await _send(
                            spark2_session,
                            to="tau",
                            subject=f"post-rebind #{i}",
                            body=f"batch 2 message {i}",
                        )

                    # flint reads all messages
                    flint_inbox = await _inbox(flint_session, limit=20)
                    from_spark = [
                        m for m in flint_inbox
                        if m.get("from_agent") in ("rho",)
                        or (m.get("sender_agent_id") in (spark_ssid, spark2_ssid))
                    ]
                    assert len(from_spark) == 10, (
                        f"Expected 10 total messages from rho, got {len(from_spark)}"
                    )

                    pre = [m for m in from_spark if "pre-rebind" in m.get("subject", "")]
                    post = [m for m in from_spark if "post-rebind" in m.get("subject", "")]
                    assert len(pre) == 5, f"Expected 5 pre-rebind messages, got {len(pre)}"
                    assert len(post) == 5, f"Expected 5 post-rebind messages, got {len(post)}"


@pytest.mark.asyncio
async def test_two_agents_exchange_2ack():
    """Crawl #13: rho and tau exchange 5 messages each direction.
    Every received message carries a valid 2ACK envelope, preflight returns 'accept',
    and the inbox frame includes the ⟡ state tag."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            async with _mcp_session(app, "rho") as (rho_session, _):
                async with _mcp_session(app, "tau") as (tau_session, _):
                    # rho -> tau: 5 messages
                    for i in range(5):
                        await _send(
                            rho_session,
                            to="tau",
                            subject=f"rho-to-tau-{i}",
                            body=f"rho body {i}",
                        )
                    # tau -> rho: 5 messages
                    for i in range(5):
                        await _send(
                            tau_session,
                            to="rho",
                            subject=f"tau-to-rho-{i}",
                            body=f"tau body {i}",
                        )

                    # --- Verify tau's inbox (5 from rho) ---
                    tau_inbox = await _inbox(tau_session, limit=10)
                    from_rho = [m for m in tau_inbox if m.get("from_agent") == "rho"]
                    assert len(from_rho) == 5, f"Expected 5 from rho, got {len(from_rho)}"

                    for msg in from_rho:
                        twoack = (msg.get("payload") or {}).get("twoack")
                        assert isinstance(twoack, dict), f"No twoack envelope: {msg.get('subject')}"
                        errors = validate_envelope(twoack)
                        assert not errors, f"2ACK invalid for {msg.get('subject')}: {errors}"
                        assert preflight_decision(msg) == "accept", (
                            f"preflight rejected {msg.get('subject')}"
                        )
                        frame = msg.get("frame", "")
                        assert "⟡" in frame, f"No state tag in frame: {frame!r}"

                    # --- Verify rho's inbox (5 from tau) ---
                    rho_inbox = await _inbox(rho_session, limit=10)
                    from_tau = [m for m in rho_inbox if m.get("from_agent") == "tau"]
                    assert len(from_tau) == 5, f"Expected 5 from tau, got {len(from_tau)}"

                    for msg in from_tau:
                        twoack = (msg.get("payload") or {}).get("twoack")
                        assert isinstance(twoack, dict), f"No twoack envelope: {msg.get('subject')}"
                        errors = validate_envelope(twoack)
                        assert not errors, f"2ACK invalid for {msg.get('subject')}: {errors}"
                        assert preflight_decision(msg) == "accept", (
                            f"preflight rejected {msg.get('subject')}"
                        )
                        frame = msg.get("frame", "")
                        assert "⟡" in frame, f"No state tag in frame: {frame!r}"
