"""Slice 10c — `whispers adopt` refuses to step on a live peer.

Before this slice, `whispers adopt <callsign>` walked the process tree for
the Claude Code session and wrote the statusline bind file unconditionally.
Operators could type `whispers adopt burr` and silently overlay the lead
agent's callsign on their terminal — a failure observed live on 2026-04-17
when a fresh Claude Code session accidentally adopted 'burr' because nothing
warned about the collision.

This slice adds a guard: before writing the bind file, adopt checks whether
another live agent_session holds the target callsign. If so, the command
refuses with a clear message. The operator can override with --force to
support intentional takeovers (e.g., reclaiming your own orphaned seat).

Run: pytest tests/test_cli_adopt_guards.py -v
"""

from __future__ import annotations

import sqlite3

import pytest
from click.testing import CliRunner

from whispers.cli import main as cli_main
from whispers.storage.db import WhispersDB


def _seed_live_peer(db_path: str, callsign: str, *, minutes_ago: int = 1) -> None:
    """Create an agent_card + live agent_session for a peer."""
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
            "stable_subject_id, continuity_anchor) VALUES (?, ?, 5, ?, ?)",
            (f"{callsign}-id", callsign, f"{callsign}-id", f"anchor:{callsign}"),
        )
        conn.execute(
            "INSERT INTO agent_sessions (session_id, agent_name, agent_id, "
            "session_kind, process_id, created_at, last_seen_at, "
            "lease_expires_at, metadata) VALUES (?, ?, ?, 'mcp_http', 1000, "
            "datetime('now', ?), datetime('now', ?), "
            "datetime('now', '+30 minutes'), '{}')",
            (
                f"session:{callsign}",
                callsign,
                f"{callsign}-id",
                f"-{minutes_ago} minutes",
                f"-{minutes_ago} minutes",
            ),
        )
        conn.commit()
    finally:
        conn.close()


class TestCallsignLiveCollisionGuard:
    """The adopt-side guard that rejects collisions with live peers."""

    def test_refuses_live_peer_collision(self, tmp_path):
        """Helper refuses when the callsign belongs to an agent with a live session."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peer(db_path, "burr", minutes_ago=1)

        from whispers.cli import check_adopt_collision

        verdict = check_adopt_collision(callsign="burr", db_path=db_path)
        assert verdict["safe"] is False
        assert verdict["reason"] == "live_session_present"
        assert "burr" in verdict["message"]

    def test_allows_free_callsign(self, tmp_path):
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)

        from whispers.cli import check_adopt_collision

        verdict = check_adopt_collision(callsign="freshname", db_path=db_path)
        assert verdict["safe"] is True
        assert verdict["reason"] == "no_live_session"

    def test_allows_stale_session(self, tmp_path):
        """A callsign with only an expired / stale session is safe to adopt."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        # Seed a stale session — 30+ minutes old.
        _seed_live_peer(db_path, "stalename", minutes_ago=45)

        from whispers.cli import check_adopt_collision

        verdict = check_adopt_collision(callsign="stalename", db_path=db_path)
        assert verdict["safe"] is True

    def test_case_insensitive(self, tmp_path):
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peer(db_path, "burr", minutes_ago=1)

        from whispers.cli import check_adopt_collision

        # "BURR" collides with the lowercase live peer.
        verdict = check_adopt_collision(callsign="BURR", db_path=db_path)
        assert verdict["safe"] is False

    def test_force_bypass_surfaces_as_allowed_but_flagged(self, tmp_path):
        """When --force is set, the helper returns safe=True but flags the takeover."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peer(db_path, "burr", minutes_ago=1)

        from whispers.cli import check_adopt_collision

        verdict = check_adopt_collision(callsign="burr", db_path=db_path, force=True)
        assert verdict["safe"] is True
        assert verdict["reason"] == "forced_takeover"
