"""Slice 9 — anchor derivation must be platform-stable.

Root cause of today's collision flood: `derive_continuity_anchor` hashes
`platform_family` as an input. The same agent bound once as "claude-code"
and once without specifying (fallback "script") produces two different
anchors for what the operator considers the same participant. Collision.
Envelope-return-path (Slice 6) is a UX fix; this slice addresses the
underlying cause.

Contract after this slice:
    anchor(callsign=X, owner=Y, host=Z) == anchor(X, Y, Z)
    regardless of platform_family. Platform is a "how", not a "who".

Sibling disambiguation (`sibling_label`) still changes the anchor —
legitimate parallel presentations of the same agent get their own
continuity streams.

Run: pytest tests/test_anchor_stability.py -v
"""

from __future__ import annotations

import pytest

from whispers.continuity import ContinuityService
from whispers.storage.db import WhispersDB


class TestAnchorStability:
    def test_same_callsign_different_platform_same_anchor(self, tmp_path):
        """The fix: platform_family must NOT affect anchor derivation.
        Same callsign → same anchor whether platform is claude-code,
        codex, script, or None.
        """
        db = WhispersDB(db_path=str(tmp_path / "s.db"))
        svc = ContinuityService(db)

        a1 = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
        )
        a2 = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="script",
        )
        a3 = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family=None,
        )
        a4 = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="codex",
        )

        assert a1 == a2 == a3 == a4, (
            f"Platform drift should be gone but got: {a1}, {a2}, {a3}, {a4}"
        )

    def test_different_callsign_different_anchor(self, tmp_path):
        """Callsign IS part of identity — different callsigns MUST
        produce different anchors.
        """
        db = WhispersDB(db_path=str(tmp_path / "d.db"))
        svc = ContinuityService(db)

        a_burr = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
        )
        a_spark = svc.derive_continuity_anchor(
            requested_callsign="spark", platform_family="claude-code",
        )
        assert a_burr != a_spark

    def test_sibling_label_diverges_anchor(self, tmp_path):
        """Legitimate parallel presentations of the same callsign (two
        concurrent Claude sessions as 'burr' say) must produce distinct
        anchors when a sibling_label is passed. Otherwise they'd
        overwrite each other's continuity.
        """
        db = WhispersDB(db_path=str(tmp_path / "sib.db"))
        svc = ContinuityService(db)

        a_main = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
        )
        a_sib = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
            sibling_label="alt",
        )
        assert a_main != a_sib

    def test_owner_id_diverges_anchor(self, tmp_path):
        """Different owners using the same callsign are different
        participants. owner_id MUST remain an anchor input.
        """
        db = WhispersDB(db_path=str(tmp_path / "own.db"))
        svc = ContinuityService(db)

        a_default = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
            owner_id=None,
        )
        a_alice = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
            owner_id="alice@example.com",
        )
        a_bob = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
            owner_id="bob@example.com",
        )
        assert a_default != a_alice != a_bob
        assert a_alice != a_bob

    def test_explicit_anchor_wins_over_derivation(self, tmp_path):
        """Operator-supplied anchor continues to bypass derivation —
        that's the escape hatch for known continuity.
        """
        db = WhispersDB(db_path=str(tmp_path / "ex.db"))
        svc = ContinuityService(db)

        a = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
            explicit_anchor="anchor:operator-specified",
        )
        assert a == "anchor:operator-specified"

    def test_anchor_format_unchanged(self, tmp_path):
        """Anchor format stays `anchor:<24hex>` — changing format would
        invalidate all existing agent_cards.continuity_anchor values.
        """
        db = WhispersDB(db_path=str(tmp_path / "f.db"))
        svc = ContinuityService(db)

        a = svc.derive_continuity_anchor(
            requested_callsign="burr", platform_family="claude-code",
        )
        assert a.startswith("anchor:")
        hex_part = a.removeprefix("anchor:")
        assert len(hex_part) == 24
        assert all(c in "0123456789abcdef" for c in hex_part)
