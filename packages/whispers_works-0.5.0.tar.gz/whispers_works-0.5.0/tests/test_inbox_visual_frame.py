"""Visual protocol stamping on inbox messages.

Every message returned by inbox() carries a canonical 'frame' field stamped
at read time. The DB envelope is untouched — framing is a render-layer concern.

Frame format:
    ⏦⏦⏦ from {sender} ▶ to {recipient} · {priority} · {subject}
    {body}
"""
from __future__ import annotations

import json
from contextlib import asynccontextmanager
from typing import AsyncGenerator, Tuple

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client

from whispers.server import create_app
from whispers.testing import WhispersTestHarness


def _tool_json(result) -> dict | list:
    assert result, "empty tool result"
    item = result[0]
    text = getattr(item, "text", "") or ""
    assert text, f"tool result has no text content: {item!r}"
    return json.loads(text)


@asynccontextmanager
async def _mcp_session(
    app,
    callsign: str,
    *,
    rebind: bool = False,
) -> AsyncGenerator[Tuple[ClientSession, dict], None]:
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(transport=transport, base_url="http://127.0.0.1") as http_client:
        async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as streams:
            read, write, _ = streams
            async with ClientSession(read, write) as session:
                await session.initialize()
                bound = await session.call_tool(
                    "bind_seat",
                    {
                        "requested_callsign": callsign,
                        "participant_profile": "desktop_ide_agent",
                        "rebind": rebind,
                    },
                )
                payload = _tool_json(bound.content)
                assert payload["bound"] is True, f"bind_seat failed for {callsign}: {payload}"
                yield session, payload


async def _inbox(session: ClientSession, *, limit: int = 10) -> list[dict]:
    result = await session.call_tool("inbox", {"limit": limit, "mark_seen": True})
    payload = _tool_json(result.content)
    if isinstance(payload, list):
        return payload
    return payload.get("messages", [])


@pytest.mark.asyncio
async def test_inbox_message_has_frame_field():
    """Every inbox message includes a 'frame' key with canonical visual framing."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            async with _mcp_session(app, "rho") as (sender, _):
                async with _mcp_session(app, "tau") as (receiver, _):
                    await sender.call_tool(
                        "send",
                        {"to": "tau", "subject": "hello world", "body": "the body text"},
                    )
                    messages = await _inbox(receiver)
                    assert len(messages) == 1
                    frame = messages[0].get("frame", "")
                    assert "⏦⏦⏦" in frame
                    assert "from rho" in frame
                    assert "to tau" in frame
                    assert "hello world" in frame
                    assert "the body text" in frame


@pytest.mark.asyncio
async def test_inbox_frame_includes_priority():
    """The frame includes the priority token."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            async with _mcp_session(app, "rho") as (sender, _):
                async with _mcp_session(app, "tau") as (receiver, _):
                    await sender.call_tool(
                        "send",
                        {"to": "tau", "subject": "urgent thing", "body": "act now", "priority": "flash"},
                    )
                    messages = await _inbox(receiver)
                    assert len(messages) == 1
                    frame = messages[0].get("frame", "")
                    assert "flash" in frame


@pytest.mark.asyncio
async def test_inbox_frame_db_envelope_unchanged():
    """The 'frame' field is not stored in the DB — raw message fields are clean."""
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            async with _mcp_session(app, "rho") as (sender, _):
                async with _mcp_session(app, "tau") as (receiver, _):
                    await sender.call_tool(
                        "send",
                        {"to": "tau", "subject": "clean envelope", "body": "test"},
                    )
                    messages = await _inbox(receiver)
                    msg = messages[0]
                    # Raw envelope fields untouched
                    assert msg.get("from_agent") == "rho"
                    assert msg.get("to_agent") == "tau"
                    assert msg.get("subject") == "clean envelope"
                    assert msg.get("body") == "test"
                    # Frame is additive
                    assert "frame" in msg
