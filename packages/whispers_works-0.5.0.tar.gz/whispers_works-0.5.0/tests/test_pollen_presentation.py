"""Pollen presentation — header serialize/parse + client + server (T4.23).

Stage A slice P3. Pollen leaves the issuer surface and rides every
authenticated call as an RFC 7230 multi-value list header.

Tests cover:
  * serialize/parse round-trip (1 envelope, 2 envelopes, empty)
  * RFC 7230 tolerance — whitespace, trailing commas, consecutive commas
  * malformed elements raise on the offending element
  * WhispersClient stores its issued pollen at construction
  * pollen_header_value() builds the wire shape from cached envelopes
  * Server middleware parses incoming X-Whispers-Pollen → request.state
  * Round-trip: client builds header → server parses → /pollen/presented
    returns the same envelope list
  * 2-element synthetic header (Stage B forward-compat) parses cleanly
"""

from __future__ import annotations

import base64
import json
import threading
import time
from http.client import HTTPConnection
from typing import Iterator

import pytest

from whispers.client import WhispersClient
from whispers.pollen import (
    POLLEN_HEADER_NAME,
    parse_pollen_list_header,
    serialize_pollen_list_header,
)
from whispers.pollen.keys import DEFAULT_KEYS_DIR_ENV
from whispers.pollen.presentation import (
    _b64u_decode_envelope,
    _b64u_encode_envelope,
)


# ----------------------------------------------------------------------
# Pure header serialize/parse
# ----------------------------------------------------------------------


def test_serialize_empty_returns_empty_string():
    assert serialize_pollen_list_header([]) == ""


def test_serialize_single_envelope_no_commas():
    env = {"claims": {"x": 1}, "signature": "abc"}
    out = serialize_pollen_list_header([env])
    assert "," not in out
    parsed = parse_pollen_list_header(out)
    assert parsed == [env]


def test_serialize_two_envelopes_comma_separated():
    """Stage B forward-compat — list-from-day-one must handle 2+ envelopes."""
    envs = [
        {"claims": {"kind": "identity"}, "signature": "sig1"},
        {"claims": {"kind": "membership"}, "signature": "sig2"},
    ]
    out = serialize_pollen_list_header(envs)
    assert ", " in out
    parsed = parse_pollen_list_header(out)
    assert parsed == envs


def test_parse_none_returns_empty_list():
    assert parse_pollen_list_header(None) == []


def test_parse_empty_string_returns_empty_list():
    assert parse_pollen_list_header("") == []


def test_parse_tolerates_whitespace_around_elements():
    env = {"claims": {"x": 1}, "signature": "abc"}
    encoded = _b64u_encode_envelope(env)
    weird = f"  {encoded}  ,   {encoded}  "
    parsed = parse_pollen_list_header(weird)
    assert len(parsed) == 2
    assert parsed[0] == env
    assert parsed[1] == env


def test_parse_drops_consecutive_commas_silently():
    env = {"claims": {"x": 1}, "signature": "abc"}
    encoded = _b64u_encode_envelope(env)
    weird = f"{encoded},,{encoded},"  # consecutive comma + trailing comma
    parsed = parse_pollen_list_header(weird)
    assert len(parsed) == 2


def test_parse_raises_on_malformed_element():
    """A garbage element surfaces a specific reason rather than dropping silently."""
    env = {"claims": {"x": 1}, "signature": "abc"}
    encoded = _b64u_encode_envelope(env)
    bad_input = f"{encoded}, ###not-base64-url###"
    with pytest.raises(ValueError):
        parse_pollen_list_header(bad_input)


def test_parse_raises_when_decoded_value_is_not_dict():
    """Pollen envelope MUST be a JSON object — array or string is malformed."""
    raw = json.dumps([1, 2, 3]).encode("utf-8")
    encoded = base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")
    with pytest.raises(ValueError, match="dict"):
        parse_pollen_list_header(encoded)


# ----------------------------------------------------------------------
# WhispersClient stores pollen at construction
# ----------------------------------------------------------------------


@pytest.fixture
def isolated_keys_dir(tmp_path, monkeypatch):
    keys_dir = tmp_path / "presentation_keys"
    monkeypatch.setenv(DEFAULT_KEYS_DIR_ENV, str(keys_dir))
    yield keys_dir


def test_whispers_client_caches_identity_pollen_after_bind(tmp_path, isolated_keys_dir):
    db_path = str(tmp_path / "client_pollen.db")
    client = WhispersClient(agent_name="cache-tester", db_path=db_path)

    assert client.pollen_identity is not None
    assert "claims" in client.pollen_identity
    assert "signature" in client.pollen_identity
    assert client.pollen_identity["claims"]["callsign"] == "cache-tester"


def test_whispers_client_pollen_envelopes_starts_with_identity(tmp_path, isolated_keys_dir):
    db_path = str(tmp_path / "client_envelopes.db")
    client = WhispersClient(agent_name="env-tester", db_path=db_path)

    assert isinstance(client.pollen_envelopes, list)
    assert len(client.pollen_envelopes) == 1
    assert client.pollen_envelopes[0] is client.pollen_identity


def test_whispers_client_pollen_header_value_serializes_cached_list(
    tmp_path, isolated_keys_dir
):
    db_path = str(tmp_path / "client_header.db")
    client = WhispersClient(agent_name="header-tester", db_path=db_path)

    header = client.pollen_header_value()
    assert isinstance(header, str)
    assert header  # non-empty for a freshly-bound client

    # Round-trip the header back through the parser
    parsed = parse_pollen_list_header(header)
    assert len(parsed) == 1
    assert parsed[0]["claims"]["callsign"] == "header-tester"


# ----------------------------------------------------------------------
# Server middleware extracts header → request.state → endpoint reads it back
# ----------------------------------------------------------------------


@pytest.fixture
def live_server(isolated_keys_dir, tmp_path) -> Iterator[str]:
    import uvicorn
    from whispers.server import create_app

    db_path = str(tmp_path / "presentation.db")
    WhispersClient(agent_name="bootstrap-pres", db_path=db_path)
    app = create_app(db_path=db_path)
    config = uvicorn.Config(
        app, host="127.0.0.1", port=0, log_level="error", access_log=False
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    for _ in range(50):
        if server.started and server.servers:
            break
        time.sleep(0.05)
    if not server.started or not server.servers:
        pytest.fail("Server failed to start within 2.5s")
    port = list(server.servers[0].sockets)[0].getsockname()[1]
    yield f"127.0.0.1:{port}"
    server.should_exit = True
    thread.join(timeout=5)


def _http_get(host_port: str, path: str, headers: dict | None = None) -> dict:
    conn = HTTPConnection(host_port, timeout=5)
    conn.request("GET", path, headers=headers or {})
    response = conn.getresponse()
    raw = response.read().decode("utf-8")
    conn.close()
    return json.loads(raw)


def test_endpoint_reports_zero_pollen_when_header_absent(live_server):
    payload = _http_get(live_server, "/pollen/presented")
    assert payload["presented_count"] == 0
    assert payload["envelopes"] == []
    assert payload["parse_error"] is None


def test_endpoint_reports_pollen_when_header_present(live_server):
    env = {"claims": {"kind": "identity", "callsign": "wire-tester"}, "signature": "s1"}
    header_value = serialize_pollen_list_header([env])
    payload = _http_get(
        live_server, "/pollen/presented",
        headers={POLLEN_HEADER_NAME: header_value},
    )
    assert payload["presented_count"] == 1
    assert payload["envelopes"] == [env]
    assert payload["parse_error"] is None


def test_endpoint_handles_two_element_list_stage_b_forward_compat(live_server):
    """The Stage B forward-compat invariant — server MUST accept >1 pollen
    on a single request even though Stage A only sends one."""
    env_id = {"claims": {"kind": "identity", "callsign": "fwd-tester"}, "signature": "id-sig"}
    env_member = {"claims": {"kind": "membership", "space_id": "pair_x"}, "signature": "m-sig"}
    header_value = serialize_pollen_list_header([env_id, env_member])
    payload = _http_get(
        live_server, "/pollen/presented",
        headers={POLLEN_HEADER_NAME: header_value},
    )
    assert payload["presented_count"] == 2
    assert payload["envelopes"][0]["claims"]["kind"] == "identity"
    assert payload["envelopes"][1]["claims"]["kind"] == "membership"


def test_endpoint_surfaces_parse_error_on_malformed_header_without_blocking(live_server):
    payload = _http_get(
        live_server, "/pollen/presented",
        headers={POLLEN_HEADER_NAME: "###not-base64-anything###"},
    )
    # Stage A discipline: malformed header logs but does NOT block
    assert payload["presented_count"] == 0
    assert payload["envelopes"] == []
    assert payload["parse_error"] is not None
    assert "pollen_header_parse_failed" in payload["parse_error"]


def test_endpoint_does_not_block_when_header_is_garbage(live_server):
    """Stage A invariant: a tampered/garbage pollen header MUST NOT
    cause the request to fail. Verification is informational this slice."""
    payload = _http_get(
        live_server, "/pollen/presented",
        headers={POLLEN_HEADER_NAME: "totally-garbage-not-base64"},
    )
    # Test passes if HTTP returned 200 with parse_error set
    assert payload["parse_error"] is not None


def test_round_trip_client_pollen_to_server(live_server, tmp_path, isolated_keys_dir):
    """Real client builds its header → real server parses it → endpoint
    returns the same envelope list. Closes the round-trip invariant."""
    # Build a client in-process (it issues + caches its identity pollen)
    db_path = str(tmp_path / "rt.db")
    client = WhispersClient(agent_name="round-trip", db_path=db_path)
    header = client.pollen_header_value()
    assert header

    # Submit it to the live server
    payload = _http_get(
        live_server, "/pollen/presented",
        headers={POLLEN_HEADER_NAME: header},
    )

    assert payload["presented_count"] == 1
    server_seen_envelope = payload["envelopes"][0]
    # The envelope at the server side must equal the one the client cached
    assert server_seen_envelope == client.pollen_identity
