"""Statusline claims a pending MCP bind when unambiguous.

Starting-line scenario: a Claude Code window's agent calls `bind_seat`
without providing claude_session_id (because `.mcp.json` header
template expansion is not a Claude Code feature). The MCP bridge stores
the bind in `agent_sessions` but can't write the per-Claude-session
bind file because it doesn't know the Claude session id.

The statusline DOES know its Claude session id (via stdin) and can see
the `agent_sessions` table. These tests pin the observable contract:

- One recent unclaimed `mcp_http` bind + no bind file yet → statusline
  claims it, writes `<claude_session_id>.callsign`, returns the callsign.
- Two concurrent unclaimed binds → ambiguous → statusline stays unbound
  (honest degradation, no silent wrong bind).
- No recent binds → statusline stays unbound.
- Already-claimed callsign (file exists somewhere with that callsign) →
  excluded from candidates.
- Stale session (older than the claim window) → not eligible.
- `$WHISPERS_CALLSIGN` and existing per-session bind file still short-
  circuit ahead of the claim — the claim is step 3, not step 1 or 2.
"""
from __future__ import annotations

import sqlite3
import time
from pathlib import Path

import pytest

from whispers import statusline


def _make_db(path: Path) -> sqlite3.Connection:
    """Minimal `agent_sessions` + `agent_cards` schema the statusline reads."""
    conn = sqlite3.connect(path)
    conn.execute(
        """
        CREATE TABLE agent_sessions (
            session_id TEXT PRIMARY KEY,
            agent_name TEXT,
            agent_id TEXT,
            session_kind TEXT,
            process_id INTEGER,
            metadata TEXT,
            created_at TEXT,
            last_seen_at TEXT,
            lease_expires_at TEXT
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE agent_cards (
            callsign TEXT PRIMARY KEY,
            trust_tier INTEGER
        )
        """
    )
    conn.execute(
        """
        CREATE TABLE messages (
            to_agent TEXT,
            seen_at TEXT,
            priority TEXT,
            status TEXT
        )
        """
    )
    conn.commit()
    return conn


def _insert_session(
    conn: sqlite3.Connection,
    *,
    session_id: str,
    agent_name: str,
    session_kind: str = "mcp_http",
    created_at: str | None = None,
    metadata: str = "{}",
) -> None:
    created = created_at or time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())
    conn.execute(
        "INSERT INTO agent_sessions (session_id, agent_name, session_kind, metadata, created_at) "
        "VALUES (?, ?, ?, ?, ?)",
        (session_id, agent_name, session_kind, metadata, created),
    )
    conn.commit()


@pytest.fixture
def whispers_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / ".whispers"
    (home / "claude-sessions").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(statusline, "WHISPERS_HOME", home)
    monkeypatch.setattr(statusline, "WHISPERS_DB", home / "whispers.db")
    monkeypatch.setattr(statusline, "PER_SESSION_DIR", home / "claude-sessions")
    monkeypatch.setattr(
        statusline, "BREADCRUMB_DIR", home / "claude-sessions" / "_breadcrumbs"
    )
    monkeypatch.delenv("WHISPERS_CALLSIGN", raising=False)
    monkeypatch.delenv("WHISPERS_AGENT", raising=False)
    return home


def test_claim_single_pending_bind(whispers_home: Path):
    """One recent unclaimed mcp_http bind → statusline claims it."""
    conn = _make_db(whispers_home / "whispers.db")
    _insert_session(conn, session_id="mcp-A", agent_name="alpha")
    conn.close()

    callsign = statusline.claim_pending_bind(
        claude_session_id="claude-sess-1",
        whispers_home=whispers_home,
    )
    assert callsign == "alpha"

    bind_file = whispers_home / "claude-sessions" / "claude-sess-1.callsign"
    assert bind_file.is_file()
    assert bind_file.read_text(encoding="utf-8").strip() == "alpha"


def test_claim_is_ambiguous_with_two_pending(whispers_home: Path):
    """Two concurrent unclaimed binds → no claim, caller stays unbound."""
    conn = _make_db(whispers_home / "whispers.db")
    _insert_session(conn, session_id="mcp-A", agent_name="alpha")
    _insert_session(conn, session_id="mcp-B", agent_name="beta")
    conn.close()

    callsign = statusline.claim_pending_bind(
        claude_session_id="claude-sess-1",
        whispers_home=whispers_home,
    )
    assert callsign is None
    assert not (
        whispers_home / "claude-sessions" / "claude-sess-1.callsign"
    ).exists()


def test_claim_with_no_pending_rows(whispers_home: Path):
    """Zero candidate rows → no claim, no bind file."""
    conn = _make_db(whispers_home / "whispers.db")
    conn.close()
    callsign = statusline.claim_pending_bind(
        claude_session_id="claude-sess-1",
        whispers_home=whispers_home,
    )
    assert callsign is None


def test_claim_excludes_already_bound_callsigns(whispers_home: Path):
    """A callsign that already owns a bind file in another window is excluded."""
    conn = _make_db(whispers_home / "whispers.db")
    _insert_session(conn, session_id="mcp-A", agent_name="alpha")
    _insert_session(conn, session_id="mcp-B", agent_name="beta")
    conn.close()

    # alpha already claimed by a different Claude window
    (whispers_home / "claude-sessions" / "prior-claude-sess.callsign").write_text(
        "alpha", encoding="utf-8"
    )

    # Now beta is the only eligible candidate for this fresh window.
    callsign = statusline.claim_pending_bind(
        claude_session_id="claude-sess-new",
        whispers_home=whispers_home,
    )
    assert callsign == "beta"


def test_claim_ignores_non_mcp_http_sessions(whispers_home: Path):
    """CLI / stdio sessions do NOT count as pending MCP binds."""
    conn = _make_db(whispers_home / "whispers.db")
    _insert_session(conn, session_id="cli-1", agent_name="alpha", session_kind="cli")
    _insert_session(conn, session_id="stdio-1", agent_name="beta", session_kind="mcp_stdio")
    conn.close()

    callsign = statusline.claim_pending_bind(
        claude_session_id="claude-sess-1",
        whispers_home=whispers_home,
    )
    assert callsign is None


def test_claim_ignores_stale_sessions(whispers_home: Path):
    """Rows older than the claim window are not eligible."""
    conn = _make_db(whispers_home / "whispers.db")
    stale = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(time.time() - 300))  # 5 min ago
    _insert_session(conn, session_id="mcp-A", agent_name="alpha", created_at=stale)
    conn.close()

    callsign = statusline.claim_pending_bind(
        claude_session_id="claude-sess-1",
        whispers_home=whispers_home,
    )
    assert callsign is None


def test_claim_excludes_sessions_with_claude_session_id_in_metadata(
    whispers_home: Path,
):
    """If metadata already carries a claude_session_id, it's already been synced."""
    conn = _make_db(whispers_home / "whispers.db")
    _insert_session(
        conn,
        session_id="mcp-A",
        agent_name="alpha",
        metadata='{"claude_session_id": "other-claude-sess"}',
    )
    conn.close()
    callsign = statusline.claim_pending_bind(
        claude_session_id="claude-sess-1",
        whispers_home=whispers_home,
    )
    assert callsign is None


def test_resolve_callsign_consults_claim_after_env_and_file(
    whispers_home: Path,
):
    """The render path: env → per-session file → claim → unbound."""
    conn = _make_db(whispers_home / "whispers.db")
    _insert_session(conn, session_id="mcp-A", agent_name="alpha")
    conn.close()

    callsign, source = statusline._resolve_callsign("claude-sess-1")
    assert callsign == "alpha"
    assert source == "per-session"  # claim wrote the file, then step 2 reads it

    bind_file = whispers_home / "claude-sessions" / "claude-sess-1.callsign"
    assert bind_file.read_text(encoding="utf-8").strip() == "alpha"


def test_resolve_callsign_env_overrides_claim(
    whispers_home: Path, monkeypatch: pytest.MonkeyPatch
):
    """Env var wins over claim — explicit per-terminal override."""
    conn = _make_db(whispers_home / "whispers.db")
    _insert_session(conn, session_id="mcp-A", agent_name="alpha")
    conn.close()
    monkeypatch.setenv("WHISPERS_CALLSIGN", "explicit-user-choice")
    callsign, source = statusline._resolve_callsign("claude-sess-1")
    assert callsign == "explicit-user-choice"
    assert source == "env"
    # No file written because env short-circuited.
    assert not (
        whispers_home / "claude-sessions" / "claude-sess-1.callsign"
    ).exists()


# ---- Acceptance Test #3: multi-window independence ------------------------
# STARTING-LINE-2026-04-17.md §6 DoD bullet 3: "Acceptance test #3
# (multi-window) proven via WhispersTestClient dual-client test AND manual
# demo". These tests prove the dual-client half — two concurrent MCP
# sessions with distinct client keys produce two distinct bindings whose
# statusline attribution stays uncontaminated.

from whispers.mcp_server import MCPSeatConfig, MCPSeatManager, sync_session_metadata
from whispers.testing import WhispersTestHarness


def _window_env(home: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Rebind statusline module constants to a per-test whispers home."""
    (home / "claude-sessions").mkdir(parents=True, exist_ok=True)
    monkeypatch.setattr(statusline, "WHISPERS_HOME", home)
    monkeypatch.setattr(statusline, "WHISPERS_DB", home / "whispers.db")
    monkeypatch.setattr(statusline, "PER_SESSION_DIR", home / "claude-sessions")
    monkeypatch.setattr(
        statusline, "BREADCRUMB_DIR", home / "claude-sessions" / "_breadcrumbs"
    )
    monkeypatch.delenv("WHISPERS_CALLSIGN", raising=False)
    monkeypatch.delenv("WHISPERS_AGENT", raising=False)


def _bind_mcp_window(
    manager: MCPSeatManager, *, mcp_client_key: str, callsign: str
):
    """Simulate a Claude Code window binding via MCP without claude_session_id.

    The `.mcp.json` header-template limitation means bind_seat arrives
    without a Claude session id on this path, so sync_session_metadata
    runs with `claude_session_id=None`. This is exactly the regression
    we're proving we now recover from.
    """
    client = manager.bind_client(
        mcp_client_key,
        requested_callsign=callsign,
        participant_profile="desktop_ide_agent",
        session_kind="mcp_http",
    )
    sync_session_metadata(client, claude_session_id=None)
    return client


def test_two_windows_staggered_bind_each_statusline_claims_its_callsign(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    """Happy path: two windows, binds arrive in sequence, each statusline
    tick cleanly claims the one unambiguous pending row."""
    with WhispersTestHarness() as h:
        home = Path(tmp_path) / ".whispers"
        # Point statusline at the harness DB + per-test bind-file dir.
        (home / "claude-sessions").mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(statusline, "WHISPERS_HOME", home)
        monkeypatch.setattr(statusline, "WHISPERS_DB", Path(h.db_path))
        monkeypatch.setattr(statusline, "PER_SESSION_DIR", home / "claude-sessions")
        monkeypatch.delenv("WHISPERS_CALLSIGN", raising=False)
        monkeypatch.delenv("WHISPERS_AGENT", raising=False)

        manager = MCPSeatManager(
            MCPSeatConfig(db_path=h.db_path, participant_profile="desktop_ide_agent")
        )

        # Window A: agent calls bind_seat ...
        _bind_mcp_window(manager, mcp_client_key="mcp-key-alpha", callsign="alpha")
        # ...then Window A's statusline ticks.
        claimed_a = statusline.claim_pending_bind(
            claude_session_id="claude-sess-A",
            whispers_home=home,
            db_path=Path(h.db_path),
        )
        assert claimed_a == "alpha"
        bind_a = home / "claude-sessions" / "claude-sess-A.callsign"
        assert bind_a.read_text(encoding="utf-8").strip() == "alpha"

        # Window B: agent binds (alpha is now claimed elsewhere by a .callsign
        # file, so Window B sees a single eligible candidate: beta).
        _bind_mcp_window(manager, mcp_client_key="mcp-key-beta", callsign="beta")
        claimed_b = statusline.claim_pending_bind(
            claude_session_id="claude-sess-B",
            whispers_home=home,
            db_path=Path(h.db_path),
        )
        assert claimed_b == "beta"
        bind_b = home / "claude-sessions" / "claude-sess-B.callsign"
        assert bind_b.read_text(encoding="utf-8").strip() == "beta"

        # Cross-contamination check: each Claude session's bind file resolves
        # ONLY to its own callsign; neither has leaked the other's.
        assert bind_a.read_text(encoding="utf-8").strip() != "beta"
        assert bind_b.read_text(encoding="utf-8").strip() != "alpha"


def test_two_windows_simultaneous_bind_both_degrade_honestly(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    """Rare race: both windows bind before either statusline can claim.
    Neither statusline silently guesses — both stay unbound. Operator
    must resolve via `whispers adopt`."""
    with WhispersTestHarness() as h:
        home = Path(tmp_path) / ".whispers"
        (home / "claude-sessions").mkdir(parents=True, exist_ok=True)
        monkeypatch.setattr(statusline, "WHISPERS_HOME", home)
        monkeypatch.setattr(statusline, "WHISPERS_DB", Path(h.db_path))
        monkeypatch.setattr(statusline, "PER_SESSION_DIR", home / "claude-sessions")
        monkeypatch.delenv("WHISPERS_CALLSIGN", raising=False)
        monkeypatch.delenv("WHISPERS_AGENT", raising=False)

        manager = MCPSeatManager(
            MCPSeatConfig(db_path=h.db_path, participant_profile="desktop_ide_agent")
        )

        # BOTH windows bind before either statusline ticks.
        _bind_mcp_window(manager, mcp_client_key="mcp-key-alpha", callsign="alpha")
        _bind_mcp_window(manager, mcp_client_key="mcp-key-beta", callsign="beta")

        # Each statusline sees two eligible candidates → honest no-claim.
        claimed_a = statusline.claim_pending_bind(
            claude_session_id="claude-sess-A",
            whispers_home=home,
            db_path=Path(h.db_path),
        )
        claimed_b = statusline.claim_pending_bind(
            claude_session_id="claude-sess-B",
            whispers_home=home,
            db_path=Path(h.db_path),
        )
        assert claimed_a is None
        assert claimed_b is None

        # Neither bind file exists — operator sees both windows unbound.
        assert not (home / "claude-sessions" / "claude-sess-A.callsign").exists()
        assert not (home / "claude-sessions" / "claude-sess-B.callsign").exists()


def test_two_windows_distinct_mcp_sessions_do_not_share_metadata(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    """MCP-level isolation check: distinct mcp_client_keys produce distinct
    agent_sessions rows whose callsigns never cross-contaminate, even
    before the statusline claim step."""
    with WhispersTestHarness() as h:
        monkeypatch.delenv("WHISPERS_CALLSIGN", raising=False)
        monkeypatch.delenv("WHISPERS_AGENT", raising=False)

        manager = MCPSeatManager(
            MCPSeatConfig(db_path=h.db_path, participant_profile="desktop_ide_agent")
        )
        client_a = _bind_mcp_window(
            manager, mcp_client_key="mcp-key-alpha", callsign="alpha"
        )
        client_b = _bind_mcp_window(
            manager, mcp_client_key="mcp-key-beta", callsign="beta"
        )

        assert client_a.agent_name == "alpha"
        assert client_b.agent_name == "beta"
        assert client_a.session_id != client_b.session_id

        with sqlite3.connect(h.db_path) as conn:
            rows = conn.execute(
                "SELECT session_id, agent_name FROM agent_sessions "
                "WHERE session_kind = 'mcp_http' "
                "ORDER BY agent_name"
            ).fetchall()
        assert len(rows) == 2
        agent_names = {r[1] for r in rows}
        assert agent_names == {"alpha", "beta"}
