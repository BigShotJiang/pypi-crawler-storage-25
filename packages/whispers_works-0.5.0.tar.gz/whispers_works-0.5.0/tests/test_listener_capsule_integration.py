"""Listener capsule integration tests (W5 — active-listening v6).

Verifies that when a local_listener session is alive for a callsign:

  * wake_projection.wake_model upgrades to "listener_backed" even if
    the agent card's reachability_mode is the baseline "manual_wake"
  * wake_projection.host_capabilities.can_trigger_inference = True
  * wake_projection.listener_attached = True
  * wake_projection.card_wake_model is preserved so the capsule can
    tell "baseline posture" vs "live truth" apart
  * chrome.wake surfaces listener_attached + card_wake_model so
    operators can see whether the listener is upgrading an otherwise
    manual host
"""

from __future__ import annotations

from typing import Any, Dict, List

import pytest

from whispers.projection import build_operator_chrome
from whispers.wake_runtime import (
    _listener_sessions_present,
    build_wake_projection,
    effective_wake_model,
)


def _card(reachability_mode: str = "manual_wake") -> Dict[str, Any]:
    return {
        "callsign": "tester",
        "agent_id": "agent-1",
        "trust_tier": 5,
        "continuity_anchor": "anchor:tester",
        "platform_family": "claude-code",
        "reachability_mode": reachability_mode,
    }


def _session(session_kind: str) -> Dict[str, Any]:
    return {
        "session_id": f"session:{session_kind}",
        "agent_name": "tester",
        "agent_id": "agent-1",
        "session_kind": session_kind,
        "last_seen_at": "2026-04-17T20:00:00Z",
        "created_at": "2026-04-17T20:00:00Z",
        "metadata": {},
    }


# ----------------------------------------------------------------------
# effective_wake_model
# ----------------------------------------------------------------------


def test_effective_wake_model_manual_when_no_listener():
    assert effective_wake_model("manual_wake", []) == "manual_wake"
    assert effective_wake_model("manual_wake", None) == "manual_wake"
    assert effective_wake_model("manual_wake", [_session("mcp_http")]) == "manual_wake"


def test_effective_wake_model_upgrades_when_listener_attached():
    assert (
        effective_wake_model("manual_wake", [_session("local_listener")])
        == "listener_backed"
    )
    assert (
        effective_wake_model(
            "manual_wake",
            [_session("mcp_http"), _session("local_listener")],
        )
        == "listener_backed"
    )


def test_effective_wake_model_card_listener_stays_listener():
    """Card already declares listener_backed — listener presence doesn't downgrade."""
    assert effective_wake_model("listener_backed", []) == "listener_backed"
    assert (
        effective_wake_model("listener_backed", [_session("mcp_http")])
        == "listener_backed"
    )


def test_listener_sessions_present_helper():
    assert not _listener_sessions_present(None)
    assert not _listener_sessions_present([])
    assert not _listener_sessions_present([_session("mcp_http")])
    assert _listener_sessions_present([_session("local_listener")])
    assert _listener_sessions_present(
        [_session("mcp_http"), _session("local_listener")]
    )


# ----------------------------------------------------------------------
# build_wake_projection — listener_attached semantics
# ----------------------------------------------------------------------


def test_projection_manual_wake_no_sessions():
    projection = build_wake_projection(
        card=_card("manual_wake"),
        active_session=None,
        message_summary={},
        work_summary={},
        all_sessions=None,
    )
    assert projection["wake_model"] == "manual_wake"
    assert projection["card_wake_model"] == "manual_wake"
    assert projection["listener_attached"] is False
    assert projection["host_capabilities"]["can_trigger_inference"] is False


def test_projection_manual_wake_interactive_only():
    mcp_session = _session("mcp_http")
    projection = build_wake_projection(
        card=_card("manual_wake"),
        active_session=mcp_session,
        message_summary={},
        work_summary={},
        all_sessions=[mcp_session],
    )
    assert projection["wake_model"] == "manual_wake"
    assert projection["card_wake_model"] == "manual_wake"
    assert projection["listener_attached"] is False
    assert projection["host_capabilities"]["can_trigger_inference"] is False


def test_projection_manual_wake_with_listener_upgrades():
    """The core W5 invariant — listener session upgrades the capsule."""
    mcp = _session("mcp_http")
    listener = _session("local_listener")
    projection = build_wake_projection(
        card=_card("manual_wake"),
        active_session=mcp,
        message_summary={},
        work_summary={},
        all_sessions=[mcp, listener],
    )
    assert projection["wake_model"] == "listener_backed"
    assert projection["card_wake_model"] == "manual_wake"
    assert projection["listener_attached"] is True
    assert projection["host_capabilities"]["can_trigger_inference"] is True
    assert projection["host_capabilities"]["can_stage_context"] is True


def test_projection_listener_only_also_upgrades():
    listener = _session("local_listener")
    projection = build_wake_projection(
        card=_card("manual_wake"),
        active_session=listener,
        message_summary={},
        work_summary={},
        all_sessions=[listener],
    )
    assert projection["wake_model"] == "listener_backed"
    assert projection["listener_attached"] is True
    assert projection["host_capabilities"]["can_trigger_inference"] is True


def test_projection_card_listener_no_sibling_listener_still_listener():
    """If the card already declares listener_backed, that sticks."""
    mcp = _session("mcp_http")
    projection = build_wake_projection(
        card=_card("listener_backed"),
        active_session=mcp,
        message_summary={},
        work_summary={},
        all_sessions=[mcp],
    )
    assert projection["wake_model"] == "listener_backed"
    assert projection["card_wake_model"] == "listener_backed"
    assert projection["listener_attached"] is False  # no local_listener session alive


# ----------------------------------------------------------------------
# Chrome surface
# ----------------------------------------------------------------------


def test_chrome_wake_block_surfaces_listener_attached():
    listener = _session("local_listener")
    projection = build_wake_projection(
        card=_card("manual_wake"),
        active_session=listener,
        message_summary={},
        work_summary={},
        all_sessions=[listener],
    )
    chrome = build_operator_chrome(
        agent_name="tester",
        participant_projection={"summary": "a host bound agent"},
        effective_trust={"current_tier": 5},
        wake_projection=projection,
        active_session=listener,
        spaces=[],
        primary_member=None,
        message_summary={},
        work_summary={},
        startup_capsule="You are tester.",
    )
    assert chrome["wake"]["wake_model"] == "listener_backed"
    assert chrome["wake"]["card_wake_model"] == "manual_wake"
    assert chrome["wake"]["listener_attached"] is True


def test_chrome_wake_block_clean_when_no_listener():
    mcp = _session("mcp_http")
    projection = build_wake_projection(
        card=_card("manual_wake"),
        active_session=mcp,
        message_summary={},
        work_summary={},
        all_sessions=[mcp],
    )
    chrome = build_operator_chrome(
        agent_name="tester",
        participant_projection={"summary": "a host bound agent"},
        effective_trust={"current_tier": 5},
        wake_projection=projection,
        active_session=mcp,
        spaces=[],
        primary_member=None,
        message_summary={},
        work_summary={},
        startup_capsule="You are tester.",
    )
    assert chrome["wake"]["wake_model"] == "manual_wake"
    assert chrome["wake"]["listener_attached"] is False


# ----------------------------------------------------------------------
# DB method — active_sessions_for_agent
# ----------------------------------------------------------------------


def test_db_active_sessions_returns_all_sessions(tmp_path):
    """Verifies the new db.active_sessions_for_agent returns every
    non-expired session for the callsign — not just the latest."""
    from whispers.storage.db import WhispersDB

    db_path = str(tmp_path / "w.db")
    db = WhispersDB(db_path=db_path)

    # Seed an agent_card for FK compliance if the table has a relation.
    # The test registers two sessions and asserts both come back.
    db.upsert_agent_session(
        session_id="session:mcp_http_1",
        agent_name="multi",
        agent_id="a-1",
        session_kind="mcp_http",
        process_id=111,
        metadata={},
    )
    db.upsert_agent_session(
        session_id="session:listener_1",
        agent_name="multi",
        agent_id="a-1",
        session_kind="local_listener",
        process_id=222,
        metadata={},
    )

    sessions = db.active_sessions_for_agent("multi")
    kinds = sorted(s["session_kind"] for s in sessions)
    assert kinds == ["local_listener", "mcp_http"]


def test_db_active_sessions_empty_for_unknown_callsign(tmp_path):
    from whispers.storage.db import WhispersDB

    db = WhispersDB(db_path=str(tmp_path / "w.db"))
    assert db.active_sessions_for_agent("nobody-here") == []
