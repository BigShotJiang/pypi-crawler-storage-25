from __future__ import annotations

from fastapi.testclient import TestClient

from whispers.server import create_app
from whispers.testing import WhispersTestHarness


class TestDeadLetterReplay:
    def test_binding_recipient_replays_recipient_not_found_dead_letters(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")

            sent = alice.send("bob", "Hello Bob", body="auto replay please")
            assert sent["status"] == "dead_lettered"

            bob = h.make_client("bob")
            inbox = bob.check_inbox(mark_seen=False)
            delivered = [item for item in inbox if item["message_id"] == sent["message_id"]]
            assert len(delivered) == 1
            assert delivered[0]["subject"] == "Hello Bob"
            assert delivered[0]["body"] == "auto replay please"
            assert delivered[0]["delivery_status"] == "delivered"

            with bob.db.get_connection() as conn:
                dead = conn.execute(
                    "SELECT COUNT(*) AS c FROM dead_letters WHERE uuid = ?",
                    (sent["message_id"],),
                ).fetchone()
                recipients = conn.execute(
                    "SELECT COUNT(*) AS c FROM message_recipients WHERE message_uuid = ? AND recipient_callsign = ?",
                    (sent["message_id"], "bob"),
                ).fetchone()
            assert int(dead["c"] or 0) == 0
            assert int(recipients["c"] or 0) == 1

    def test_identity_connect_endpoint_replays_dead_letters_on_bind(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            alice = client.post(
                "/identity/connect",
                json={"requested_callsign": "alice", "platform_family": "claude-code", "context_hint": "sender"},
            )
            assert alice.status_code == 200

            sent = client.post(
                "/messages/send",
                json={"sender": "alice", "recipient": "bob", "subject": "API hello", "body": "from server bind"},
            )
            assert sent.status_code == 200
            assert sent.json()["status"] == "dead_lettered"
            message_id = sent.json()["message_id"]

            bob = client.post(
                "/identity/connect",
                json={"requested_callsign": "bob", "platform_family": "codex", "context_hint": "receiver", "session_id": "bob-session"},
            )
            assert bob.status_code == 200

            inbox = client.get("/agents/bob/inbox", params={"limit": 20, "mark_seen": False})
            assert inbox.status_code == 200
            delivered = [item for item in inbox.json()["messages"] if item["message_id"] == message_id]
            assert len(delivered) == 1
            assert delivered[0]["subject"] == "API hello"
            assert delivered[0]["delivery_status"] == "delivered"
