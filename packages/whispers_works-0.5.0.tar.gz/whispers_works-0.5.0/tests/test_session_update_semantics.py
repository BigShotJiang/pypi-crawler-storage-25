from __future__ import annotations

import sqlite3

from fastapi.testclient import TestClient

from whispers.server import create_app
from whispers.testing import WhispersTestHarness


class TestSessionUpdateSemantics:
    def test_same_process_rebind_reuses_existing_client_session_row(self):
        with WhispersTestHarness() as h:
            first = h.make_client("alice")
            first.status()
            first_session_id = first.session_id

            with sqlite3.connect(h.db_path) as conn:
                conn.row_factory = sqlite3.Row
                before = conn.execute(
                    "SELECT session_id FROM agent_sessions WHERE agent_name = ?",
                    ("alice",),
                ).fetchall()
            assert len(before) == 1
            assert before[0]["session_id"] == first_session_id

            rebound = h.make_client("alice")
            rebound.status()

            with sqlite3.connect(h.db_path) as conn:
                conn.row_factory = sqlite3.Row
                after = conn.execute(
                    "SELECT session_id, lease_expires_at FROM agent_sessions WHERE agent_name = ?",
                    ("alice",),
                ).fetchall()
            assert rebound.session_id == first_session_id
            assert len(after) == 1
            assert after[0]["session_id"] == first_session_id
            assert after[0]["lease_expires_at"] is not None

    def test_identity_connect_reuses_session_row_for_same_process(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            first = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "platform_family": "codex",
                    "context_hint": "reviewworktree",
                    "session_kind": "http_client",
                    "process_id": 4242,
                },
            )
            assert first.status_code == 200
            first_session_id = first.json()["session_id"]

            second = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "platform_family": "codex",
                    "context_hint": "reviewworktree",
                    "session_kind": "http_client",
                    "process_id": 4242,
                },
            )
            assert second.status_code == 200
            assert second.json()["session_id"] == first_session_id

            with sqlite3.connect(h.db_path) as conn:
                conn.row_factory = sqlite3.Row
                rows = conn.execute(
                    "SELECT session_id FROM agent_sessions WHERE agent_name = ?",
                    ("alice",),
                ).fetchall()
            assert len(rows) == 1
            assert rows[0]["session_id"] == first_session_id
