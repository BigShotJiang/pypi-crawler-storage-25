from __future__ import annotations

import pytest

from whispers.testing import WhispersTestHarness


@pytest.fixture(autouse=True)
def _multi_tenant_posture(monkeypatch):
    """These tests assert tier-1 default behavior. Post-2026-04-17
    trust_baseline default flipped 1→5 for single-operator posture;
    force multi-tenant posture so these tests still see the tier-1
    baseline they were written against."""
    monkeypatch.setenv("WHISPERS_MULTI_TENANT", "1")
    monkeypatch.delenv("WHISPERS_TRUSTED_ENV", raising=False)
    monkeypatch.delenv("WHISPERS_DEFAULT_TRUST_TIER", raising=False)


class TestTrustContinuity:
    def test_trust_follows_stable_subject_across_rebind(self):
        with WhispersTestHarness() as h:
            alice = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )
            set_result = alice.trust_set(new_tier=4, actor="operator", reason="Sustained high-trust collaboration")
            assert set_result["trust"]["current_tier"] == 4

            rebound = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )
            status = rebound.status()
            assert status["effective_trust"]["current_tier"] == 4
            assert status["identity_resolution"]["outcome"] == "rebind_accepted"

            who = rebound.whoami()
            assert who is not None
            assert who["effective_trust"]["current_tier"] == 4
            events = rebound.trust_status()["events"]
            assert events[0]["new_tier"] == 4
            assert events[0]["reason"] == "Sustained high-trust collaboration"

    def test_trust_does_not_leak_to_sibling_instance(self):
        with WhispersTestHarness() as h:
            primary = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )
            primary.trust_set(new_tier=5, actor="operator", reason="Core authority")

            sibling = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="review-worktree",
                sibling_label="review",
            )
            assert sibling.agent_name.isalpha()
            assert sibling.status()["effective_trust"]["current_tier"] == 1
            assert primary.status()["effective_trust"]["current_tier"] == 5

    def test_startup_capsule_carries_trust_and_attention_compactly(self):
        with WhispersTestHarness() as h:
            alice = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )
            bob = h.make_client(
                "bob",
                owner_id="zack",
                platform_family="codex",
                context_hint="review-worktree",
            )
            alice.trust_set(new_tier=3, actor="operator", reason="Established collaborator")
            alice.work_offer("bob", "Review startup capsule", description="Make it agent-caring and compact")

            status = bob.status()
            capsule = status["startup_capsule"]
            assert "trust tier 1" in capsule
            assert "messages waiting" in capsule
            assert "work offers waiting" in capsule
