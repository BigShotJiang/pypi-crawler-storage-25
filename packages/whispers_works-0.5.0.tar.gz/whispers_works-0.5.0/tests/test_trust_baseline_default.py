"""Slice 6.5 — opt-in default trust tier for trusted environments.

Fresh registrations default to tier 1 (`trust_baseline.baseline_trust_tier`),
which dead-letters every new agent's outbound sends to tier-5 teammates
until an operator manually runs `whispers authorize-tier <callsign> 5`.
This is symptom 5 in STARTUP-MECHANICS-OVERHAUL §2 and the exact fail mode
that dropped pure-ember's evaluation message (dead_letter uuid
bb4ca5e5-... reason=trust_tier_violation:1->5) on 2026-04-17.

The fix: an environment-level opt-in that raises the default tier for
deployments Zack has declared trusted (single-operator dev env, CI
sandboxes, etc). Default behavior stays tier 1 — multi-tenant and external
deployments must NOT pick up an elevated default by accident.

Env var: WHISPERS_DEFAULT_TRUST_TIER (integer 0..6).
Precedence: _BASELINE_TRUST_TIERS[callsign] > env var > hard default 1.

Run: pytest tests/test_trust_baseline_default.py -v
"""

from __future__ import annotations

import importlib

import pytest


class TestBaselineTrustTierDefault:
    def test_default_is_tier_5_when_env_unset(self, monkeypatch):
        """2026-04-17 put-the-bug-to-bed change: without any env var,
        the baseline defaults to tier 5 — the trusted-single-operator
        posture that matches every deployment today. Multi-tenant
        deployments must opt down explicitly via WHISPERS_MULTI_TENANT=1
        or WHISPERS_DEFAULT_TRUST_TIER=1.
        """
        monkeypatch.delenv("WHISPERS_DEFAULT_TRUST_TIER", raising=False)
        monkeypatch.delenv("WHISPERS_TRUSTED_ENV", raising=False)
        monkeypatch.delenv("WHISPERS_MULTI_TENANT", raising=False)
        from whispers.trust_baseline import baseline_trust_tier

        assert baseline_trust_tier("fresh-agent") == 5

    def test_multi_tenant_env_forces_tier_1(self, monkeypatch):
        """WHISPERS_MULTI_TENANT=1 is the explicit opt-down. Required
        for any public / multi-customer deployment.
        """
        monkeypatch.delenv("WHISPERS_DEFAULT_TRUST_TIER", raising=False)
        monkeypatch.delenv("WHISPERS_TRUSTED_ENV", raising=False)
        monkeypatch.setenv("WHISPERS_MULTI_TENANT", "1")
        from whispers.trust_baseline import baseline_trust_tier

        assert baseline_trust_tier("fresh-agent") == 1

    def test_env_var_raises_default(self, monkeypatch):
        """WHISPERS_DEFAULT_TRUST_TIER=5 makes every new agent bind at
        tier 5. This is the trusted-env opt-in.
        """
        monkeypatch.setenv("WHISPERS_DEFAULT_TRUST_TIER", "5")
        from whispers.trust_baseline import baseline_trust_tier

        assert baseline_trust_tier("fresh-agent") == 5

    def test_baseline_map_still_wins_over_env_var(self, monkeypatch):
        """When a callsign has an explicit baseline entry, it takes
        precedence over the env var. Preserves existing operator
        overrides seeded via _BASELINE_TRUST_TIERS.
        """
        monkeypatch.setenv("WHISPERS_DEFAULT_TRUST_TIER", "5")
        import whispers.trust_baseline as tb

        monkeypatch.setitem(tb._BASELINE_TRUST_TIERS, "special", 3)
        assert tb.baseline_trust_tier("special") == 3
        assert tb.baseline_trust_tier("other") == 5

    def test_invalid_env_var_falls_back_to_hard_default(self, monkeypatch):
        """Garbage in the env var must not crash the bind path or silently
        promote to an unexpected tier. Falls back to 1, matching the safe
        default behavior.
        """
        monkeypatch.setenv("WHISPERS_DEFAULT_TRUST_TIER", "not-a-number")
        from whispers.trust_baseline import baseline_trust_tier

        assert baseline_trust_tier("fresh-agent") == 1

    def test_env_var_out_of_range_falls_back(self, monkeypatch):
        """Tiers are 0..6. Values outside that range fall back to 1
        rather than applying as-is, since a stray "99" in an env var
        should not grant god-tier to every fresh bind.
        """
        monkeypatch.setenv("WHISPERS_DEFAULT_TRUST_TIER", "99")
        from whispers.trust_baseline import baseline_trust_tier

        assert baseline_trust_tier("fresh-agent") == 1

    def test_env_var_zero_is_honored(self, monkeypatch):
        """0 is a valid tier (explicit demotion). If the operator sets
        it, honor it — the fallback-to-1 path is only for invalid values.
        """
        monkeypatch.setenv("WHISPERS_DEFAULT_TRUST_TIER", "0")
        from whispers.trust_baseline import baseline_trust_tier

        assert baseline_trust_tier("fresh-agent") == 0
