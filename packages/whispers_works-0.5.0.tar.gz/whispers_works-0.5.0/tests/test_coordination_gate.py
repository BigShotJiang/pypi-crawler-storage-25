"""CoordinationGate unit tests (W4 — active-listening v6).

Tests the pure routing logic: StreamEvent + PresenceState -> Route.
Covers the smart default plus the two pinned preferences, flash
priority handling with both/clamp semantics, peer_delta routing,
system-priority handling, and silence windows.
"""

from __future__ import annotations

from typing import Any, Dict

import pytest

from whispers.listeners.coordination import (
    CoordinationGate,
    PresenceState,
    Route,
)
from whispers.listeners.engine import StreamEvent


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _wake(
    *,
    priority: str = "routine",
    msg_type: str = "inform",
    body: str = "hi",
    sender: str = "peer",
) -> StreamEvent:
    return StreamEvent(
        kind="wake",
        event_id=1,
        payload={
            "packet": {
                "priority": priority,
                "msg_type": msg_type,
                "body": body,
                "sender": sender,
                "subject": "t",
            }
        },
    )


def _peer_delta() -> StreamEvent:
    return StreamEvent(
        kind="peer_delta",
        event_id=1,
        payload={"kind": "peer_bound", "callsign": "new-peer"},
    )


INTERACTIVE = PresenceState(
    has_interactive_session=True,
    has_listener_session=False,
    interactive_session_kind="mcp_http",
)
LISTENER = PresenceState(
    has_interactive_session=False,
    has_listener_session=True,
)
BOTH = PresenceState(
    has_interactive_session=True,
    has_listener_session=True,
    interactive_session_kind="mcp_http",
)
NONE = PresenceState.none()


# ----------------------------------------------------------------------
# Smart default (operator_primary when live)
# ----------------------------------------------------------------------


def test_smart_operator_present_routes_interactive():
    gate = CoordinationGate()
    r = gate.route(_wake(), BOTH)
    assert r.target == "interactive"
    assert r.policy_name == "smart"


def test_smart_listener_only_routes_listener():
    gate = CoordinationGate()
    r = gate.route(_wake(), LISTENER)
    assert r.target == "listener"
    assert r.policy_name == "smart"


def test_smart_no_session_drops():
    gate = CoordinationGate()
    r = gate.route(_wake(), NONE)
    assert r.target == "drop"
    assert r.reason == "no_session"


def test_smart_interactive_only_routes_interactive():
    gate = CoordinationGate()
    r = gate.route(_wake(), INTERACTIVE)
    assert r.target == "interactive"


# ----------------------------------------------------------------------
# Interactive primary
# ----------------------------------------------------------------------


def test_interactive_primary_prefers_interactive_when_both():
    gate = CoordinationGate(preference="interactive_primary")
    r = gate.route(_wake(), BOTH)
    assert r.target == "interactive"
    assert r.policy_name == "preference"


def test_interactive_primary_falls_back_to_listener():
    gate = CoordinationGate(preference="interactive_primary")
    r = gate.route(_wake(), LISTENER)
    assert r.target == "listener"
    assert "fallback" in r.reason


# ----------------------------------------------------------------------
# Listener primary
# ----------------------------------------------------------------------


def test_listener_primary_prefers_listener_when_both():
    gate = CoordinationGate(preference="listener_primary")
    r = gate.route(_wake(), BOTH)
    assert r.target == "listener"
    assert r.policy_name == "preference"


def test_listener_primary_falls_back_to_interactive():
    gate = CoordinationGate(preference="listener_primary")
    r = gate.route(_wake(), INTERACTIVE)
    assert r.target == "interactive"
    assert "fallback" in r.reason


# ----------------------------------------------------------------------
# Flash priority
# ----------------------------------------------------------------------


def test_flash_both_sessions_honors_preference():
    gate = CoordinationGate(flash_goes_to="both")
    r = gate.route(_wake(priority="flash"), BOTH)
    assert r.target == "both"
    assert r.policy_name == "flash_priority"


def test_flash_override_goes_to_interactive_only():
    gate = CoordinationGate(flash_goes_to="interactive")
    r = gate.route(_wake(priority="flash"), BOTH)
    assert r.target == "interactive"


def test_flash_override_goes_to_listener_only():
    gate = CoordinationGate(flash_goes_to="listener")
    r = gate.route(_wake(priority="flash"), BOTH)
    assert r.target == "listener"


def test_flash_clamps_to_listener_when_only_listener():
    gate = CoordinationGate(flash_goes_to="both")
    r = gate.route(_wake(priority="flash"), LISTENER)
    assert r.target == "listener"
    assert "listener_only" in r.reason


def test_flash_clamps_to_interactive_when_only_interactive():
    gate = CoordinationGate(flash_goes_to="both")
    r = gate.route(_wake(priority="flash"), INTERACTIVE)
    assert r.target == "interactive"
    assert "interactive_only" in r.reason


def test_flash_drops_when_no_session():
    gate = CoordinationGate(flash_goes_to="both")
    r = gate.route(_wake(priority="flash"), NONE)
    assert r.target == "drop"


# ----------------------------------------------------------------------
# System priority
# ----------------------------------------------------------------------


def test_system_priority_goes_to_both_when_possible():
    gate = CoordinationGate()
    r = gate.route(_wake(priority="system", msg_type="halt"), BOTH)
    assert r.target == "both"
    assert r.policy_name == "system_priority"


def test_system_priority_goes_to_interactive_only():
    gate = CoordinationGate()
    r = gate.route(_wake(priority="system", msg_type="halt"), INTERACTIVE)
    assert r.target == "interactive"


def test_system_priority_goes_to_listener_only():
    gate = CoordinationGate()
    r = gate.route(_wake(priority="system", msg_type="halt"), LISTENER)
    assert r.target == "listener"


def test_system_priority_drops_when_no_session():
    gate = CoordinationGate()
    r = gate.route(_wake(priority="system", msg_type="halt"), NONE)
    assert r.target == "drop"


# ----------------------------------------------------------------------
# Peer deltas
# ----------------------------------------------------------------------


def test_peer_delta_goes_to_interactive_when_alive():
    gate = CoordinationGate()
    r = gate.route(_peer_delta(), BOTH)
    assert r.target == "interactive"
    assert r.policy_name == "peer_delta_routing"


def test_peer_delta_goes_to_interactive_even_without_listener():
    gate = CoordinationGate()
    r = gate.route(_peer_delta(), INTERACTIVE)
    assert r.target == "interactive"


def test_peer_delta_drops_when_only_listener_is_alive():
    """Listener never autonomously responds to peer deltas."""
    gate = CoordinationGate()
    r = gate.route(_peer_delta(), LISTENER)
    assert r.target == "drop"
    assert r.reason == "peer_delta_no_interactive"


# ----------------------------------------------------------------------
# Silence window
# ----------------------------------------------------------------------


def test_silenced_gate_drops_everything():
    gate = CoordinationGate(silenced=True)
    for event in (
        _wake(),
        _wake(priority="flash"),
        _wake(priority="system", msg_type="halt"),
        _peer_delta(),
    ):
        r = gate.route(event, BOTH)
        assert r.target == "drop"
        assert r.reason == "gate_silenced"


# ----------------------------------------------------------------------
# Determinism / purity
# ----------------------------------------------------------------------


def test_same_inputs_same_route():
    """The gate must be a pure function of (event, presence, config)."""
    gate = CoordinationGate()
    event = _wake(priority="flash", body="same")
    r1 = gate.route(event, BOTH)
    r2 = gate.route(event, BOTH)
    assert r1 == r2


def test_preference_matters_to_outcome():
    """Plan §5 W4 acceptance: ordering changes outcome, provable in test."""
    event = _wake()
    smart = CoordinationGate(preference="smart").route(event, BOTH)
    listener_primary = CoordinationGate(preference="listener_primary").route(event, BOTH)
    assert smart.target == "interactive"
    assert listener_primary.target == "listener"
    assert smart != listener_primary


def test_presence_none_class_method():
    p = PresenceState.none()
    assert not p.has_interactive_session
    assert not p.has_listener_session
    assert p.interactive_session_kind is None
