"""Phase 3 Slice 9 — delta capsule over SSE.

When a peer binds, disbinds, or otherwise changes state that matters to
currently-bound peers, the server emits a structured delta event on the
wake stream. Clients subscribed to /wake/{agent}/stream receive these
alongside the existing wake events, with event-type labels distinguishing
them.

This is the keystone slice for the Phase-2 starting line — without it,
every existing agent is blind to team changes until it re-queries.

Run: pytest tests/test_delta_capsule.py -v
"""

from __future__ import annotations

import pytest


class TestDeltaEventBroker:
    def test_broadcast_fans_to_all_subscribers(self):
        from whispers.delta_stream import DeltaEventBroker

        broker = DeltaEventBroker()
        sub_a = broker.subscribe("alice")
        sub_b = broker.subscribe("bob")

        event = {"kind": "peer_bound", "callsign": "carol"}
        broker.broadcast(event)

        assert sub_a.get_nowait() == event
        assert sub_b.get_nowait() == event

    def test_broadcast_excludes_unsubscribed_agents(self):
        """Agents who unsubscribed before the broadcast do NOT receive
        the event.
        """
        from whispers.delta_stream import DeltaEventBroker

        broker = DeltaEventBroker()
        sub_a = broker.subscribe("alice")
        broker.unsubscribe("alice", sub_a)

        broker.broadcast({"kind": "peer_bound", "callsign": "bob"})

        import queue as _queue
        with pytest.raises(_queue.Empty):
            sub_a.get_nowait()

    def test_targeted_publish_only_reaches_that_agent(self):
        """publish(agent_name, event) — single-recipient path, distinct
        from broadcast."""
        from whispers.delta_stream import DeltaEventBroker

        broker = DeltaEventBroker()
        sub_a = broker.subscribe("alice")
        sub_b = broker.subscribe("bob")

        broker.publish("alice", {"kind": "direct_for_alice"})

        assert sub_a.get_nowait() == {"kind": "direct_for_alice"}
        import queue as _queue
        with pytest.raises(_queue.Empty):
            sub_b.get_nowait()


class TestPeerBoundEvent:
    def test_emit_peer_bound_shape(self):
        """emit_peer_bound builds a canonical event shape from a card dict.
        """
        from whispers.delta_stream import build_peer_bound_event

        card = {
            "callsign": "alice",
            "agent_id": "alice-id",
            "stable_subject_id": "alice-subject",
            "continuity_anchor": "anchor:alice",
            "trust_tier": 5,
            "platform_family": "claude-code",
            "registered_at": "2026-04-17 17:42:29",
        }
        event = build_peer_bound_event(card)

        assert event["kind"] == "peer_bound"
        assert event["callsign"] == "alice"
        assert event["trust_tier"] == 5
        assert event["continuity_anchor"] == "anchor:alice"
        assert event["platform_family"] == "claude-code"
        assert "at" in event
        assert "event_type" in event
        assert event["event_type"] == "peer_delta"

    def test_emit_peer_gone_shape(self):
        from whispers.delta_stream import build_peer_gone_event

        event = build_peer_gone_event(
            callsign="alice",
            agent_id="alice-id",
            reason="session_expired",
        )
        assert event["kind"] == "peer_gone"
        assert event["callsign"] == "alice"
        assert event["reason"] == "session_expired"
        assert "at" in event
        assert event["event_type"] == "peer_delta"


class TestIntegrationWithBroker:
    def test_emit_peer_bound_broadcasts_via_broker(self):
        """The emit helper takes a broker + card, broadcasts the shaped
        event to all subscribers.
        """
        from whispers.delta_stream import DeltaEventBroker, emit_peer_bound

        broker = DeltaEventBroker()
        sub = broker.subscribe("observer")

        card = {
            "callsign": "new-peer",
            "agent_id": "np-id",
            "trust_tier": 5,
            "continuity_anchor": "anchor:np",
            "platform_family": "claude-code",
        }
        emit_peer_bound(broker, card)

        received = sub.get_nowait()
        assert received["kind"] == "peer_bound"
        assert received["callsign"] == "new-peer"

    def test_emit_peer_bound_skips_self(self):
        """A peer binding under its OWN subscription shouldn't receive
        its own peer_bound event — only other subscribers see it.
        """
        from whispers.delta_stream import DeltaEventBroker, emit_peer_bound

        broker = DeltaEventBroker()
        # alice is subscribed and is ALSO the agent binding
        alice_sub = broker.subscribe("alice")
        bob_sub = broker.subscribe("bob")

        card = {
            "callsign": "alice",
            "agent_id": "alice-id",
            "trust_tier": 5,
            "continuity_anchor": "anchor:alice",
        }
        emit_peer_bound(broker, card)

        # Bob should see alice bind
        received = bob_sub.get_nowait()
        assert received["callsign"] == "alice"

        # Alice should NOT see her own bind event
        import queue as _queue
        with pytest.raises(_queue.Empty):
            alice_sub.get_nowait()
