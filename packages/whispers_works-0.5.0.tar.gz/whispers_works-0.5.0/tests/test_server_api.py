from __future__ import annotations

from fastapi.testclient import TestClient

from whispers.server import create_app
from whispers.testing import WhispersTestHarness


class TestServerApi:
    def test_health_and_identity_connect(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            health = client.get("/health")
            assert health.status_code == 200
            assert health.json()["ok"] is True

            connected = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claude-code",
                    "context_hint": "main-worktree",
                },
            )
            assert connected.status_code == 200
            body = connected.json()
            assert body["resolution"]["outcome"] == "registered"
            assert body["status"]["agent_name"] == "alice"
            assert body["status"]["continuity_anchor"] == body["resolution"]["continuity_anchor"]

            rebound = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claude-code",
                    "context_hint": "main-worktree",
                },
            )
            assert rebound.status_code == 200
            assert rebound.json()["resolution"]["outcome"] == "rebind_accepted"

            trust_set = client.post("/trust/alice", json={"actor": "operator", "new_tier": 4, "reason": "Established collaborator"})
            assert trust_set.status_code == 200
            assert trust_set.json()["trust"]["current_tier"] == 4

            trust_status = client.get("/trust/alice")
            assert trust_status.status_code == 200
            assert trust_status.json()["trust"]["current_tier"] == 4
            assert trust_status.json()["events"][0]["reason"] == "Established collaborator"

    def test_identity_rebind_same_identity_surfaces_as_200(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            first = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claude-code",
                    "context_hint": "main-worktree",
                },
            )
            assert first.status_code == 200

            rebound = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claude-code",
                    "context_hint": "review-worktree",
                },
            )
            assert rebound.status_code == 200
            assert rebound.json()["resolution"]["outcome"] == "rebind_accepted"

    def test_identity_conflict_surfaces_as_409(self):
        """Post-Slice-9: cross-platform same-callsign same-owner is NOT a
        conflict — it's a rebind (anchors match). To provoke a genuine
        conflict we use sibling_label on the first bind so the second
        caller hits the anchored-presentations branch.
        """
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            first = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claude-code",
                    "context_hint": "main-worktree",
                    "sibling_label": "worktree-a",
                },
            )
            assert first.status_code == 200

            conflict = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "codex",
                    "context_hint": "main-worktree",
                },
            )
            assert conflict.status_code == 409
            assert conflict.json()["outcome"] == "manual_resolution_required"

    def test_identity_rename_and_presentation_history(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            connected = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claudecode",
                    "context_hint": "mainworktree",
                },
            )
            assert connected.status_code == 200

            renamed = client.post(
                "/identity/alice/rename",
                json={"new_callsign": "wren", "actor": "alice", "reason": "cleaner public name"},
            )
            assert renamed.status_code == 200
            assert renamed.json()["resolution"]["outcome"] == "presentation_renamed"
            assert renamed.json()["status"]["agent_name"] == "wren"

            history = client.get("/identity/wren/presentations")
            assert history.status_code == 200
            presentations = {row["callsign"]: row for row in history.json()["presentations"]}
            assert presentations["wren"]["status"] == "current"
            assert presentations["alice"]["status"] == "retired"
            assert presentations["alice"]["successor_callsign"] == "wren"

    def test_space_identity_and_seat_endpoints(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            for payload in (
                {
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claudecode",
                    "context_hint": "mainworktree",
                },
                {
                    "requested_callsign": "bob",
                    "owner_id": "zack",
                    "platform_family": "codex",
                    "context_hint": "reviewworktree",
                },
            ):
                response = client.post("/identity/connect", json=payload)
                assert response.status_code == 200

            created = client.post("/spaces", json={"created_by": "alice", "name": "meeting-room"})
            assert created.status_code == 200
            space_id = created.json()["space"]["space_id"]

            joined = client.post(f"/spaces/{space_id}/join", json={"agent_name": "bob"})
            assert joined.status_code == 200

            named = client.post(f"/spaces/{space_id}/identity", json={"agent_name": "bob", "participation_name": "sam"})
            assert named.status_code == 200
            assert named.json()["member"]["participation_name"] == "sam"

            seat = client.post(
                f"/spaces/{space_id}/seats",
                json={"actor": "alice", "seat_name": "facilitator", "occupant_agent": "bob"},
            )
            assert seat.status_code == 200
            assert seat.json()["seat"]["occupant_agent"] == "bob"

            seats = client.get(f"/spaces/{space_id}/seats")
            assert seats.status_code == 200
            assert seats.json()["seats"][0]["seat_name"] == "facilitator"

            sent = client.post(
                "/messages/send",
                json={
                    "sender": "alice",
                    "recipient": "seat:facilitator",
                    "subject": "Role-routed",
                    "body": "for bob",
                    "space_id": space_id,
                },
            )
            assert sent.status_code == 200

            inbox = client.get("/agents/bob/inbox", params={"mark_seen": False, "space_id": space_id})
            assert inbox.status_code == 200
            assert inbox.json()["messages"][0]["subject"] == "Role-routed"

    def test_exclusive_space_naming_policy_over_server(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            for payload in (
                {
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claudecode",
                    "context_hint": "mainworktree",
                },
                {
                    "requested_callsign": "bob",
                    "owner_id": "zack",
                    "platform_family": "codex",
                    "context_hint": "reviewworktree",
                },
            ):
                response = client.post("/identity/connect", json=payload)
                assert response.status_code == 200

            created = client.post(
                "/spaces",
                json={
                    "created_by": "alice",
                    "name": "workspace",
                    "naming_policy": "exclusive",
                    "naming_conflict_mode": "suffix",
                },
            )
            assert created.status_code == 200
            space_id = created.json()["space"]["space_id"]
            assert created.json()["space"]["naming_policy"] == "exclusive"

            joined = client.post(f"/spaces/{space_id}/join", json={"agent_name": "bob"})
            assert joined.status_code == 200

            alice_named = client.post(f"/spaces/{space_id}/identity", json={"agent_name": "alice", "participation_name": "Sam"})
            bob_named = client.post(f"/spaces/{space_id}/identity", json={"agent_name": "bob", "participation_name": "Sam"})
            assert alice_named.status_code == 200
            assert bob_named.status_code == 200
            assert alice_named.json()["member"]["participation_name"] == "Sam"
            assert bob_named.json()["member"]["participation_name"] == "Sam2"

        
    def test_message_space_and_work_endpoints(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            for payload in (
                {
                    "requested_callsign": "alice",
                    "owner_id": "zack",
                    "platform_family": "claude-code",
                    "context_hint": "main-worktree",
                },
                {
                    "requested_callsign": "bob",
                    "owner_id": "zack",
                    "platform_family": "codex",
                    "context_hint": "review-worktree",
                },
            ):
                response = client.post("/identity/connect", json=payload)
                assert response.status_code == 200

            sent = client.post(
                "/messages/send",
                json={
                    "sender": "alice",
                    "recipient": "bob",
                    "subject": "Hello",
                    "body": "Space-aware server proof",
                },
            )
            assert sent.status_code == 200
            sent_payload = sent.json()
            assert sent_payload["space_id"].startswith("pair_")

            inbox = client.get("/agents/bob/inbox", params={"mark_seen": False})
            assert inbox.status_code == 200
            assert inbox.json()["messages"][0]["subject"] == "Hello"

            offer = client.post(
                "/work/offer",
                json={
                    "creator": "alice",
                    "assignee": "bob",
                    "title": "Review startup capsule",
                    "description": "Keep it small and truthful.",
                },
            )
            assert offer.status_code == 200
            work = offer.json()["work"]
            work_id = work["work_id"]
            baton_ref = offer.json()["offer_message"]["message_id"]

            baton = client.get(f"/work/{work_id}/baton")
            assert baton.status_code == 200
            assert baton.json()["schema"] == "handoff_baton.v1"
            assert baton.json()["trace"]["message_id"] == baton_ref

            accepted = client.post(f"/batons/{baton_ref}/ack", json={"actor": "bob", "decision": "accepted"})
            assert accepted.status_code == 200
            assert accepted.json()["work"]["state"] == "accepted"

            listed = client.get("/agents/bob/work")
            assert listed.status_code == 200
            assert listed.json()["work"][0]["work_id"] == work_id
