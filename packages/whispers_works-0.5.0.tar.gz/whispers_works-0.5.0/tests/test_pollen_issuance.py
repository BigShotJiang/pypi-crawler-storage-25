"""Pollen issuance + bind-response integration (T4.22).

Stage A slice P2. The first slice where pollen actually leaves the
module surface and rides a live bind response.

Tests cover:
  * IssuerSigner Protocol surface — KeypairBackedIssuerSigner satisfies it
  * issue_identity_pollen produces verifiable envelopes that round-trip
    through verify -> from_claims -> check_not_expired
  * The signed envelope's claims match the inputs exactly
  * /identity/connect response carries pollen.identity for a fresh bind
  * The pollen on the bind response verifies against the public key
    served at /identity/keys/<issuer>
  * Pollen carries the resolved identity (callsign, tier, anchor)
  * Stage A discipline: a forced issuance failure does NOT break bind
"""

from __future__ import annotations

import json
import threading
import time
from datetime import datetime, timedelta, timezone
from http.client import HTTPConnection
from typing import Iterator

import pytest

from whispers.client import WhispersClient
from whispers.pollen import (
    IdentityPollen,
    IssuerKeypair,
    IssuerSigner,
    KeypairBackedIssuerSigner,
    PollenSigner,
    PollenVerifier,
    deserialize_public_key,
    generate_issuer_keypair,
    issue_identity_pollen,
    load_or_generate_issuer_keypair,
    signer_from_keypair,
)
from whispers.pollen.keys import DEFAULT_KEYS_DIR_ENV


# ----------------------------------------------------------------------
# IssuerSigner Protocol — duck-type surface
# ----------------------------------------------------------------------


def test_keypair_backed_signer_satisfies_protocol(tmp_path):
    keypair = load_or_generate_issuer_keypair(keys_dir=tmp_path / "k")
    signer = signer_from_keypair(keypair)

    # runtime_checkable — isinstance check exercises the Protocol
    assert isinstance(signer, IssuerSigner)
    assert signer.key_id == keypair.key_id
    assert signer.public_key_b64u == keypair.public_key_b64u


def test_signer_from_keypair_round_trip_signs_and_verifies(tmp_path):
    keypair = load_or_generate_issuer_keypair(keys_dir=tmp_path / "k")
    signer = signer_from_keypair(keypair)
    verifier = PollenVerifier()

    claims = {
        "callsign": "burr",
        "stable_subject_id": "sid",
        "continuity_anchor": "anchor:x",
        "trust_tier": 5,
        "issued_at": "2026-04-17T00:00:00Z",
        "expires_at": "2026-04-18T00:00:00Z",
        "issuer": "whispers-daemon",
        "key_id": signer.key_id,
        "schema_version": 1,
        "kind": "identity",
    }
    envelope = signer.sign_claims(claims)
    verified = verifier.verify_envelope(envelope, public_key_raw=keypair.public_key_raw)
    assert verified == claims


# ----------------------------------------------------------------------
# issue_identity_pollen — the unit
# ----------------------------------------------------------------------


def test_issue_identity_pollen_produces_verifiable_envelope(tmp_path):
    keypair = load_or_generate_issuer_keypair(keys_dir=tmp_path / "k")
    signer = signer_from_keypair(keypair)
    verifier = PollenVerifier()

    envelope = issue_identity_pollen(
        callsign="burr",
        stable_subject_id="sid-burr",
        continuity_anchor="anchor:burr",
        trust_tier=5,
        signer=signer,
    )

    verified = verifier.verify_envelope(envelope, public_key_raw=keypair.public_key_raw)
    pollen = IdentityPollen.from_claims(verified)
    assert pollen.callsign == "burr"
    assert pollen.stable_subject_id == "sid-burr"
    assert pollen.continuity_anchor == "anchor:burr"
    assert pollen.trust_tier == 5
    assert pollen.key_id == signer.key_id
    assert pollen.issuer == "whispers-daemon"
    pollen.check_not_expired()


def test_issued_pollen_has_default_24h_ttl(tmp_path):
    keypair = load_or_generate_issuer_keypair(keys_dir=tmp_path / "k")
    signer = signer_from_keypair(keypair)
    fixed_now = datetime(2026, 4, 17, 12, 0, 0, tzinfo=timezone.utc)

    envelope = issue_identity_pollen(
        callsign="burr",
        stable_subject_id="sid",
        continuity_anchor="anchor:x",
        trust_tier=5,
        signer=signer,
        now=fixed_now,
    )
    pollen = IdentityPollen.from_claims(envelope["claims"])
    issued = datetime.fromisoformat(pollen.issued_at.replace("Z", "+00:00"))
    expires = datetime.fromisoformat(pollen.expires_at.replace("Z", "+00:00"))
    assert (expires - issued).total_seconds() == 24 * 60 * 60


def test_issued_pollen_carries_schema_version(tmp_path):
    keypair = load_or_generate_issuer_keypair(keys_dir=tmp_path / "k")
    signer = signer_from_keypair(keypair)
    envelope = issue_identity_pollen(
        callsign="burr", stable_subject_id="sid",
        continuity_anchor="a", trust_tier=5, signer=signer,
    )
    assert envelope["claims"]["schema_version"] == 1


def test_issuance_can_use_a_protocol_satisfying_mock_signer():
    """Cinder's duck-type discipline: issuance must NOT depend on
    KeypairBackedIssuerSigner specifically — any IssuerSigner works.
    """

    class _MockSigner:
        key_id = "mock-key-id-0123"
        public_key_b64u = "fake-pubkey-b64u"

        def sign_claims(self, claims):
            return {"claims": claims, "signature": "fake-sig"}

    mock = _MockSigner()
    assert isinstance(mock, IssuerSigner)  # runtime_checkable
    envelope = issue_identity_pollen(
        callsign="b", stable_subject_id="s", continuity_anchor="a",
        trust_tier=3, signer=mock,
    )
    assert envelope["signature"] == "fake-sig"
    assert envelope["claims"]["key_id"] == "mock-key-id-0123"


# ----------------------------------------------------------------------
# Live HTTP — pollen rides the bind response
# ----------------------------------------------------------------------


@pytest.fixture
def isolated_keys_dir(tmp_path, monkeypatch):
    keys_dir = tmp_path / "issuance_keys"
    monkeypatch.setenv(DEFAULT_KEYS_DIR_ENV, str(keys_dir))
    yield keys_dir


@pytest.fixture
def live_server(isolated_keys_dir, tmp_path) -> Iterator[str]:
    import uvicorn
    from whispers.server import create_app

    db_path = str(tmp_path / "issuance.db")
    WhispersClient(agent_name="bootstrap", db_path=db_path)
    app = create_app(db_path=db_path)

    config = uvicorn.Config(
        app, host="127.0.0.1", port=0, log_level="error", access_log=False
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    for _ in range(50):
        if server.started and server.servers:
            break
        time.sleep(0.05)
    if not server.started or not server.servers:
        pytest.fail("Server failed to start within 2.5s")

    port = list(server.servers[0].sockets)[0].getsockname()[1]
    yield f"127.0.0.1:{port}"

    server.should_exit = True
    thread.join(timeout=5)


def _http_post_json(host_port: str, path: str, body: dict) -> dict:
    conn = HTTPConnection(host_port, timeout=5)
    payload = json.dumps(body).encode("utf-8")
    conn.request("POST", path, payload, {"Content-Type": "application/json"})
    response = conn.getresponse()
    raw = response.read().decode("utf-8")
    conn.close()
    if response.status >= 400:
        raise AssertionError(f"HTTP {response.status}: {raw}")
    return json.loads(raw)


def _http_get_json(host_port: str, path: str) -> dict:
    conn = HTTPConnection(host_port, timeout=5)
    conn.request("GET", path)
    response = conn.getresponse()
    raw = response.read().decode("utf-8")
    conn.close()
    return json.loads(raw)


def test_bind_response_carries_pollen_identity(live_server):
    host_port = live_server
    bind_response = _http_post_json(
        host_port,
        "/identity/connect",
        {
            "requested_callsign": "burr",
            "agent_type": "infrastructure",
            "session_kind": "local_listener",
            "process_id": 12345,
        },
    )

    assert bind_response.get("pollen") is not None
    pollen_block = bind_response["pollen"]
    assert "identity" in pollen_block

    identity_envelope = pollen_block["identity"]
    assert "claims" in identity_envelope
    assert "signature" in identity_envelope

    claims = identity_envelope["claims"]
    assert claims["kind"] == "identity"
    assert claims["callsign"] == "burr"
    assert claims["schema_version"] == 1


def test_bind_pollen_verifies_against_public_key_endpoint(live_server):
    host_port = live_server
    bind_response = _http_post_json(
        host_port,
        "/identity/connect",
        {
            "requested_callsign": "verify-tester",
            "agent_type": "infrastructure",
            "session_kind": "local_listener",
            "process_id": 99999,
        },
    )

    envelope = bind_response["pollen"]["identity"]
    issuer_callsign = envelope["claims"]["issuer"]

    # Fetch the public key from the keys endpoint
    keys_response = _http_get_json(host_port, f"/identity/keys/{issuer_callsign}")
    pubkey_raw = deserialize_public_key(keys_response["public_key_b64u"])

    # The pollen must verify against the public key endpoint's response
    verifier = PollenVerifier()
    verified_claims = verifier.verify_envelope(envelope, public_key_raw=pubkey_raw)
    assert verified_claims["callsign"] == "verify-tester"

    # And the key_id in the pollen claims must match the keys endpoint
    assert envelope["claims"]["key_id"] == keys_response["key_id"]


def test_bind_pollen_carries_resolved_identity_fields(live_server):
    host_port = live_server
    bind_response = _http_post_json(
        host_port,
        "/identity/connect",
        {
            "requested_callsign": "resolved-fields",
            "agent_type": "infrastructure",
            "session_kind": "local_listener",
            "process_id": 4242,
        },
    )

    resolution = bind_response["resolution"]
    pollen_claims = bind_response["pollen"]["identity"]["claims"]

    # Pollen MUST carry the same identity the resolution surfaced —
    # not "what was requested," but "what was resolved." This is the
    # invariant that closes the flux→torch silent-rename hazard:
    # pollen cannot drift from the resolution because it's built from
    # the resolution's fields.
    assert pollen_claims["callsign"] == resolution["callsign"]
    assert pollen_claims["continuity_anchor"] == resolution["continuity_anchor"]
    assert pollen_claims["stable_subject_id"] == resolution["stable_subject_id"]


def test_bind_pollen_tier_matches_effective_trust(live_server):
    host_port = live_server
    bind_response = _http_post_json(
        host_port,
        "/identity/connect",
        {
            "requested_callsign": "tier-tester",
            "agent_type": "infrastructure",
            "session_kind": "local_listener",
            "process_id": 7777,
        },
    )

    pollen_claims = bind_response["pollen"]["identity"]["claims"]
    tier = pollen_claims["trust_tier"]

    # Cross-check against /trust/<callsign> for honesty
    trust_response = _http_get_json(host_port, f"/trust/{pollen_claims['callsign']}")
    assert tier == trust_response["trust"]["current_tier"]


def test_pollen_signature_holds_through_serialization(live_server):
    """Round-trip the envelope through JSON to confirm canonicalization
    is stable across serialize boundaries — what comes out of the bind
    response must verify after a JSON round-trip."""
    host_port = live_server
    bind_response = _http_post_json(
        host_port,
        "/identity/connect",
        {
            "requested_callsign": "ser-tester",
            "agent_type": "infrastructure",
            "session_kind": "local_listener",
            "process_id": 8888,
        },
    )

    envelope_pre = bind_response["pollen"]["identity"]
    # Serialize and parse again — what would happen on the wire
    envelope_round_trip = json.loads(json.dumps(envelope_pre))

    keys_response = _http_get_json(
        host_port, f"/identity/keys/{envelope_round_trip['claims']['issuer']}"
    )
    pubkey_raw = deserialize_public_key(keys_response["public_key_b64u"])

    verifier = PollenVerifier()
    # Must verify after JSON round-trip
    verifier.verify_envelope(envelope_round_trip, public_key_raw=pubkey_raw)
