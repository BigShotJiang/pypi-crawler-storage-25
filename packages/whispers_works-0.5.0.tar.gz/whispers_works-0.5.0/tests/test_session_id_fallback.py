"""Slice 8 — session-ID fallback via breadcrumb scan.

When Claude Code's MCP HTTP request arrives at the Whispers bridge
without a session-ID header, query param, or env var, and the bridge's
own ppid breadcrumb misses (the bridge is a daemon, not a child of
Claude Code), the bridge must fall back to scanning
~/.whispers/claude-sessions/_breadcrumbs/ for breadcrumbs whose PID is
alive. In the dominant single-Claude-window case, exactly one
breadcrumb points to a live claude.exe process — use that.

Multi-window: if two live Claude PIDs are present, return None (can't
know which window this request came from without per-request routing).
Post-restart daemon regression this slice fixes: every fresh
bind_seat(platform_family="claude-code") hitting claude_session_id_unavailable.

Run: pytest tests/test_session_id_fallback.py -v
"""

from __future__ import annotations

import os

import pytest


class TestBreadcrumbFallback:
    def _setup_fake_home(self, tmp_path, breadcrumbs: dict[int, str]) -> None:
        """Create ~/.whispers/claude-sessions/_breadcrumbs/<pid> files."""
        bc_dir = tmp_path / "claude-sessions" / "_breadcrumbs"
        bc_dir.mkdir(parents=True, exist_ok=True)
        for pid, session_id in breadcrumbs.items():
            (bc_dir / str(pid)).write_text(session_id, encoding="utf-8")

    def test_single_live_breadcrumb_is_returned(self, tmp_path, monkeypatch):
        """One breadcrumb in the directory pointing to a live PID → that
        breadcrumb's session ID is returned. The dominant single-window
        case.
        """
        from whispers.mcp_server import scan_breadcrumbs_for_live_claude_session

        live_pid = os.getpid()
        self._setup_fake_home(tmp_path, {live_pid: "session-alpha"})

        result = scan_breadcrumbs_for_live_claude_session(
            whispers_home=tmp_path,
        )
        assert result == "session-alpha"

    def test_dead_pid_breadcrumb_is_ignored(self, tmp_path):
        """Breadcrumbs whose PID is not alive must NOT be returned —
        that's a prior Claude window's stale crumb.
        """
        from whispers.mcp_server import scan_breadcrumbs_for_live_claude_session

        self._setup_fake_home(tmp_path, {999999: "session-dead"})

        result = scan_breadcrumbs_for_live_claude_session(
            whispers_home=tmp_path,
        )
        assert result is None

    def test_multiple_live_breadcrumbs_returns_none(self, tmp_path, monkeypatch):
        """Two (or more) live Claude PIDs means the bridge can't know
        which window this HTTP request came from without per-request
        routing. Return None; let the guard fire honestly.
        """
        import psutil

        from whispers.mcp_server import scan_breadcrumbs_for_live_claude_session

        live_pid_a = os.getpid()
        # Find a second PID that's actually alive (cross-platform safe).
        live_pid_b = None
        try:
            for p in psutil.process_iter(["pid"]):
                pid = p.info.get("pid")
                if pid is not None and pid != live_pid_a and pid > 0:
                    try:
                        if psutil.pid_exists(pid):
                            live_pid_b = pid
                            break
                    except Exception:
                        continue
        except Exception:
            pass
        if live_pid_b is None:
            pytest.skip("Could not locate a second live PID for the test")

        self._setup_fake_home(tmp_path, {
            live_pid_a: "session-a",
            live_pid_b: "session-b",
        })

        result = scan_breadcrumbs_for_live_claude_session(
            whispers_home=tmp_path,
        )
        assert result is None

    def test_live_plus_dead_returns_the_live_one(self, tmp_path):
        """Mix of one live and one dead: the live one wins."""
        from whispers.mcp_server import scan_breadcrumbs_for_live_claude_session

        live_pid = os.getpid()
        self._setup_fake_home(tmp_path, {
            live_pid: "session-live",
            999999: "session-dead",
        })

        result = scan_breadcrumbs_for_live_claude_session(
            whispers_home=tmp_path,
        )
        assert result == "session-live"

    def test_empty_breadcrumb_dir_returns_none(self, tmp_path):
        """No breadcrumbs = nothing to fall back to."""
        from whispers.mcp_server import scan_breadcrumbs_for_live_claude_session

        # Don't create anything
        result = scan_breadcrumbs_for_live_claude_session(
            whispers_home=tmp_path,
        )
        assert result is None


class TestResolverIntegration:
    """resolve_claude_session_id() wires the fallback in as the final
    step, after header/query/env/direct-ppid-breadcrumb all miss.
    """

    def test_resolver_falls_back_to_breadcrumb_scan_when_all_else_fails(
        self, tmp_path, monkeypatch
    ):
        """With no header/env/ppid match, resolver returns the scan result."""
        from whispers.mcp_server import resolve_claude_session_id

        bc_dir = tmp_path / "claude-sessions" / "_breadcrumbs"
        bc_dir.mkdir(parents=True, exist_ok=True)
        (bc_dir / str(os.getpid())).write_text("session-via-scan", encoding="utf-8")

        monkeypatch.delenv("WHISPERS_CLAUDE_SESSION_ID", raising=False)
        result = resolve_claude_session_id(
            ctx=None,
            env={},
            whispers_home=tmp_path,
            parent_pid=999999,  # force direct ppid miss
        )
        assert result == "session-via-scan"

    def test_resolver_prefers_direct_ppid_over_scan(
        self, tmp_path, monkeypatch
    ):
        """If the caller's ppid has a direct breadcrumb, scan doesn't
        run — direct match wins. Protects the two-window case where the
        bridge's ppid and scan-target diverge.
        """
        from whispers.mcp_server import resolve_claude_session_id

        bc_dir = tmp_path / "claude-sessions" / "_breadcrumbs"
        bc_dir.mkdir(parents=True, exist_ok=True)
        # Direct ppid match
        (bc_dir / "11111").write_text("session-direct", encoding="utf-8")
        # Scan would find this one (live)
        (bc_dir / str(os.getpid())).write_text("session-scan", encoding="utf-8")

        monkeypatch.delenv("WHISPERS_CLAUDE_SESSION_ID", raising=False)
        result = resolve_claude_session_id(
            ctx=None,
            env={},
            whispers_home=tmp_path,
            parent_pid=11111,
        )
        assert result == "session-direct"
