"""Active-listening v6 — W7 conformance test suite.

Six scenarios against a real AutonomousDaemon composing the full stack
(engine -> policy -> safety -> coordination -> backend -> reply). Each
scenario spins up a threaded HTTPServer that emits SSE events in the
shape the engine's StreamEvent accessors expect, runs a real daemon
against it, and asserts on daemon stats + backend calls + reply writes.

**Why fake-SSE, not real uvicorn wake-stream.** The real server's
`/wake/<callsign>/stream` emits wake events as `status_update.v1`
envelopes whose `priority` / `sender` fields live at
`payload.packet.wake.attention_context.priority` and
`payload.packet.recent_messages[0].sender`. The engine's
`StreamEvent.priority` / `.sender` accessors read from
`payload.packet.priority` / `payload.packet.sender` — the shape
`test_listener_daemon.py`'s helper produces. That seam is worth
fixing upstream (engine should cope with both shapes OR the server
wake packet should carry the fields where accessors look), but it's
out of W7 conformance scope. W7 proves composition of the six pieces;
the engine's real-wire parser is W0's territory.

Extends the test_listener_daemon.py `sse_server` fixture pattern to
six distinct conformance scenarios. Acceptance criterion #10 of the
rebuild doc: `pytest tests/test_listener_conformance_live.py` passes
on a fresh clone with the daemon running.

Scenarios (per .planning/active/ACTIVE-LISTENING-REBUILD-2026-04-17.md W7):
  1. Listener receives flash -> acts -> response posts
  2. Listener receives routine -> policy suppresses -> no backend call
  3. Interactive hot -> coordination shadows listener -> no response
  4. Interactive idle -> listener takes over -> acts
  5. Budget exhausted -> safety blocks -> no backend call
  6. Kill switch active -> safety halts -> no backend call
"""

from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional

import pytest

from whispers.client import WhispersClient
from whispers.listeners.backends.mock_backend import MockBackend
from whispers.listeners.coordination import CoordinationGate, PresenceState
from whispers.listeners.daemon import AutonomousDaemon
from whispers.listeners.engine import ListenerEngine
from whispers.listeners.policies import (
    AddressedToMePolicy,
    FlashPriorityPolicy,
    WakePolicy,
    WakePolicyStack,
)
from whispers.listeners.safety import SafetyConfig, SafetyGuardrails


# ----------------------------------------------------------------------
# SSE server harness — same pattern as test_listener_daemon.py
# ----------------------------------------------------------------------


class _SSEEmitter:
    def __init__(self) -> None:
        self.queue: List[Dict[str, Any]] = []
        self.lock = threading.Lock()
        self.close_after_drain = threading.Event()

    def emit(
        self,
        event_type: str,
        payload: Dict[str, Any],
        event_id: Optional[int] = None,
    ) -> None:
        with self.lock:
            self.queue.append(
                {"event": event_type, "payload": payload, "id": event_id}
            )


def _make_server(emitter: _SSEEmitter) -> HTTPServer:
    class _Handler(BaseHTTPRequestHandler):
        def log_message(self, *args: Any, **kwargs: Any) -> None:
            return

        def do_GET(self) -> None:
            if "/wake/" not in self.path or "/stream" not in self.path:
                self.send_response(404)
                self.end_headers()
                return

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            try:
                self.wfile.write(b": connected\n\n")
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, OSError):
                return

            deadline = time.time() + 10.0
            while time.time() < deadline:
                with emitter.lock:
                    pending = list(emitter.queue)
                    emitter.queue.clear()
                for item in pending:
                    lines: List[str] = []
                    if item["event"] != "message":
                        lines.append(f"event: {item['event']}")
                    if item["id"] is not None:
                        lines.append(f"id: {item['id']}")
                    lines.append(f"data: {json.dumps(item['payload'])}")
                    blob = ("\n".join(lines) + "\n\n").encode("utf-8")
                    try:
                        self.wfile.write(blob)
                        self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        return
                if emitter.close_after_drain.is_set():
                    return
                time.sleep(0.05)

    return HTTPServer(("127.0.0.1", 0), _Handler)


@pytest.fixture
def sse_server():
    emitter = _SSEEmitter()
    server = _make_server(emitter)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield emitter, f"http://127.0.0.1:{port}"
    finally:
        emitter.close_after_drain.set()
        server.shutdown()
        server.server_close()


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _wake(
    *,
    sender: str = "peer-a",
    to: str = "listener-tester",
    subject: str = "hello",
    body: str = "hi",
    priority: str = "routine",
) -> Dict[str, Any]:
    """Build a wake event shaped the way the engine's StreamEvent
    accessors expect (payload.packet.{sender,priority,msg_type,body})."""
    return {
        "event_id": 0,
        "payload": {
            "packet": {
                "sender": sender,
                "to": to,
                "subject": subject,
                "body": body,
                "priority": priority,
                "msg_type": "inform",
            }
        },
    }


def _wait_for(pred, *, timeout: float) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if pred():
            return True
        time.sleep(0.05)
    return False


def _build_daemon(
    *,
    server_url: str,
    callsign: str,
    db_path: str,
    backend: MockBackend,
    policy_stack=None,
    safety: Optional[SafetyGuardrails] = None,
    coordination_gate: Optional[CoordinationGate] = None,
    presence_resolver=None,
) -> AutonomousDaemon:
    client = WhispersClient(
        agent_name=callsign,
        db_path=db_path,
        session_kind="local_listener",
        reachability_mode="listener_backed",
    )
    if policy_stack is None:
        policy_stack = WakePolicyStack(
            [AddressedToMePolicy(self_callsign=callsign), FlashPriorityPolicy()]
        )
    if safety is None:
        safety = SafetyGuardrails(config=SafetyConfig(self_callsign=callsign))
    if coordination_gate is None:
        coordination_gate = CoordinationGate(preference="listener_primary")

    daemon: AutonomousDaemon = None  # type: ignore[assignment]
    engine = ListenerEngine(
        server_url=server_url,
        callsign=callsign,
        handler=lambda event: daemon._handle_event(event),
        policy=policy_stack,
        safety=safety,
    )
    daemon = AutonomousDaemon(
        callsign=callsign,
        server_url=server_url,
        engine=engine,
        coordination_gate=coordination_gate,
        backend=backend,
        client=client,
        presence_resolver=presence_resolver or (
            lambda: PresenceState(
                has_interactive_session=False,
                has_listener_session=True,
            )
        ),
    )
    return daemon


# ----------------------------------------------------------------------
# Scenario 1 — Flash -> backend call -> reply written
# ----------------------------------------------------------------------


def test_scenario_1_flash_triggers_backend_call_and_reply(sse_server, tmp_path):
    """Flash-priority message arrives via SSE; stack composes end-to-end;
    MockBackend.respond returns text; WhispersClient.send writes a reply
    back to the sender's DB inbox.

    Acceptance #1: listener takes action on flash within budget.
    """
    emitter, server_url = sse_server
    db_path = str(tmp_path / "s1.db")

    # Pre-register both agents so the DB accepts the reply write
    WhispersClient(agent_name="peer-one", db_path=db_path)

    backend = MockBackend(canned_text="auto-reply flash", model_id="mock")
    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-one",
        db_path=db_path,
        backend=backend,
    )
    daemon.start()
    try:
        emitter.emit(
            "wake",
            _wake(
                sender="peer-one",
                to="listener-one",
                priority="flash",
                subject="flash from peer",
                body="urgent",
            ),
            event_id=1,
        )
        assert _wait_for(
            lambda: daemon.stats.replies_sent >= 1,
            timeout=5.0,
        ), f"listener did not reply; stats={daemon.stats}"
    finally:
        daemon.stop()

    assert len(backend.calls) == 1
    assert daemon.stats.backend_calls == 1
    assert daemon.stats.replies_sent == 1

    # Reply landed in peer-one's inbox — read via MessagingService
    from whispers.storage.db import WhispersDB
    from whispers.messaging import MessagingService
    db = WhispersDB(db_path=db_path)
    messaging = MessagingService(db)
    recent = messaging.inbox("peer-one", limit=10, mark_seen=False)
    auto_replies = [m for m in recent if "auto-reply flash" in (m.get("body") or "")]
    assert auto_replies, f"no auto-reply found for peer-one; got {recent}"


# ----------------------------------------------------------------------
# Scenario 2 — Routine suppressed by flash-only policy
# ----------------------------------------------------------------------


def test_scenario_2_routine_suppressed_by_flash_only_policy(sse_server, tmp_path):
    """Policy stack = [FlashPriorityPolicy] only. Routine arrives;
    policy skips; stack default-denies; backend NEVER called.

    Acceptance: policy composition enforced (tier-1 peer sends flash;
    listener vetoes). Same policy mechanism covers priority-based deny.
    """
    emitter, server_url = sse_server
    db_path = str(tmp_path / "s2.db")

    backend = MockBackend(canned_text="should-never-see", model_id="mock")
    flash_only = WakePolicyStack([FlashPriorityPolicy()])
    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-two",
        db_path=db_path,
        backend=backend,
        policy_stack=flash_only,
    )
    daemon.start()
    try:
        emitter.emit(
            "wake",
            _wake(
                sender="peer-two",
                to="listener-two",
                priority="routine",
                subject="not urgent",
                body="can wait",
            ),
            event_id=1,
        )
        # Give it time to NOT respond
        time.sleep(1.0)
    finally:
        daemon.stop()

    assert len(backend.calls) == 0, (
        f"backend should NOT have been called; got {backend.calls}"
    )
    assert daemon.stats.backend_calls == 0
    assert daemon.stats.replies_sent == 0


# ----------------------------------------------------------------------
# Scenario 3 — Interactive hot: coordination shadows listener
# ----------------------------------------------------------------------


def test_scenario_3_interactive_hot_listener_shadows(sse_server, tmp_path):
    """PresenceState says an interactive session is live. Coordination
    gate with preference='smart' routes to interactive; listener shadows.

    Acceptance: with Claude Code open, listener shadows (no backend call).
    """
    emitter, server_url = sse_server
    db_path = str(tmp_path / "s3.db")

    backend = MockBackend(canned_text="should-never-see-3", model_id="mock")
    presence = lambda: PresenceState(
        has_interactive_session=True,
        has_listener_session=True,
        interactive_session_kind="mcp_http",
    )
    # Operator has configured "when I'm hot, flash goes to me, not to
    # the listener." Same shadow behavior the W7 acceptance criterion
    # describes ("with Claude Code open, listener shadows").
    coordination = CoordinationGate(
        preference="smart", flash_goes_to="interactive"
    )

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-three",
        db_path=db_path,
        backend=backend,
        coordination_gate=coordination,
        presence_resolver=presence,
    )
    daemon.start()
    try:
        emitter.emit(
            "wake",
            _wake(
                sender="peer-three",
                to="listener-three",
                priority="flash",
                subject="operator should get this",
                body="hot",
            ),
            event_id=1,
        )
        # Give it time for the event to propagate through the stack
        assert _wait_for(
            lambda: daemon.stats.events_received >= 1,
            timeout=3.0,
        ), "listener did not receive the wake event via SSE"
        # Wait extra to confirm backend was NOT called
        time.sleep(0.5)
    finally:
        daemon.stop()

    assert daemon.stats.events_received >= 1
    assert daemon.stats.backend_calls == 0, (
        f"listener should have shadowed while interactive was hot; "
        f"backend calls={daemon.stats.backend_calls}"
    )


# ----------------------------------------------------------------------
# Scenario 4 — Interactive idle: listener takes over
# ----------------------------------------------------------------------


def test_scenario_4_interactive_idle_listener_takes_over(sse_server, tmp_path):
    """No interactive session; coordination routes to listener; backend
    fires.

    Acceptance: listener takes over when operator isn't present.
    """
    emitter, server_url = sse_server
    db_path = str(tmp_path / "s4.db")

    # Pre-register peer so reply can be written
    WhispersClient(agent_name="peer-four", db_path=db_path)

    backend = MockBackend(canned_text="listener took over", model_id="mock")
    presence = lambda: PresenceState(
        has_interactive_session=False,
        has_listener_session=True,
    )
    coordination = CoordinationGate(preference="smart")

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-four",
        db_path=db_path,
        backend=backend,
        coordination_gate=coordination,
        presence_resolver=presence,
    )
    daemon.start()
    try:
        emitter.emit(
            "wake",
            _wake(
                sender="peer-four",
                to="listener-four",
                priority="flash",
                subject="operator gone",
                body="take over",
            ),
            event_id=1,
        )
        assert _wait_for(
            lambda: daemon.stats.replies_sent >= 1,
            timeout=5.0,
        ), f"listener did not take over; stats={daemon.stats}"
    finally:
        daemon.stop()

    assert daemon.stats.backend_calls == 1
    assert daemon.stats.replies_sent == 1


# ----------------------------------------------------------------------
# Scenario 5 — Budget exhausted: safety blocks before backend call
# ----------------------------------------------------------------------


def test_scenario_5_budget_exhausted_blocks_backend_call(sse_server, tmp_path):
    """SafetyConfig with max_inferences_per_hour=1, used=1. BudgetCap
    guardrail denies; backend never called.

    Acceptance: budget cap enforced; operator-visible in status.
    """
    emitter, server_url = sse_server
    db_path = str(tmp_path / "s5.db")

    backend = MockBackend(canned_text="should-never-see-5", model_id="mock")
    safety = SafetyGuardrails(
        config=SafetyConfig(
            self_callsign="listener-five",
            max_inferences_per_hour=1,
            inferences_used_last_hour=lambda: 1,
        )
    )

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-five",
        db_path=db_path,
        backend=backend,
        safety=safety,
    )
    daemon.start()
    try:
        emitter.emit(
            "wake",
            _wake(
                sender="peer-five",
                to="listener-five",
                priority="flash",
                subject="budget test",
                body="over cap",
            ),
            event_id=1,
        )
        # Give SSE time to deliver + safety to fire
        time.sleep(1.0)
    finally:
        daemon.stop()

    assert daemon.stats.backend_calls == 0, (
        f"backend should NOT have been called when budget exhausted; "
        f"got {daemon.stats.backend_calls}"
    )
    assert daemon.stats.replies_sent == 0


# ----------------------------------------------------------------------
# Scenario 6 — Kill switch active: safety halts everything
# ----------------------------------------------------------------------


def test_scenario_6_kill_switch_halts_all_action(sse_server, tmp_path):
    """Kill-switch sentinel file exists. Safety raises KillSwitchActive
    on every event. Backend NEVER called, even for flash.

    Acceptance: kill switch works — operator flips the switch; listener
    stops acting until explicitly resumed.
    """
    emitter, server_url = sse_server
    db_path = str(tmp_path / "s6.db")

    kill_path = tmp_path / "LISTENER_KILL"
    kill_path.write_text("halt", encoding="utf-8")

    backend = MockBackend(canned_text="should-never-see-6", model_id="mock")
    safety = SafetyGuardrails(
        config=SafetyConfig(
            self_callsign="listener-six",
            kill_switch_path=str(kill_path),
        )
    )

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-six",
        db_path=db_path,
        backend=backend,
        safety=safety,
    )
    daemon.start()
    try:
        emitter.emit(
            "wake",
            _wake(
                sender="peer-six",
                to="listener-six",
                priority="flash",
                subject="kill-switch test",
                body="should be halted",
            ),
            event_id=1,
        )
        time.sleep(1.0)
    finally:
        daemon.stop()

    assert daemon.stats.backend_calls == 0, (
        f"kill-switch should have blocked backend; "
        f"got {daemon.stats.backend_calls}"
    )
    assert daemon.stats.replies_sent == 0
