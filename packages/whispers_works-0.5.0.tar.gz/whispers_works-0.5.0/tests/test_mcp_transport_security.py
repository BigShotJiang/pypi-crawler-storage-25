from __future__ import annotations

import json
import socket
import threading
import time
import urllib.request
from contextlib import contextmanager

import uvicorn

from whispers.mcp_server import build_transport_security_settings
from whispers.server import create_app
from whispers.testing import WhispersTestHarness


@contextmanager
def _running_server(db_path: str):
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]

    app = create_app(db_path=db_path)
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    try:
        for _ in range(50):
            if server.started:
                break
            time.sleep(0.1)
        else:
            raise AssertionError("uvicorn server did not start in time")
        yield port
    finally:
        server.should_exit = True
        thread.join(timeout=5)



def test_transport_security_defaults_allow_loopback_hosts_with_ports(monkeypatch):
    monkeypatch.delenv("WHISPERS_MCP_ENABLE_DNS_REBINDING_PROTECTION", raising=False)
    settings = build_transport_security_settings(listen_host="127.0.0.1")
    assert settings.enable_dns_rebinding_protection is True
    assert "127.0.0.1:*" in settings.allowed_hosts
    assert "localhost:*" in settings.allowed_hosts
    assert "http://127.0.0.1:*" in settings.allowed_origins



def test_transport_security_can_be_disabled_by_env(monkeypatch):
    monkeypatch.setenv("WHISPERS_MCP_ENABLE_DNS_REBINDING_PROTECTION", "0")
    settings = build_transport_security_settings(listen_host="127.0.0.1")
    assert settings.enable_dns_rebinding_protection is False



def test_real_http_initialize_accepts_host_header_with_port():
    with WhispersTestHarness() as h:
        with _running_server(h.db_path) as port:
            body = json.dumps(
                {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "initialize",
                    "params": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {},
                        "clientInfo": {"name": "probe", "version": "1.0"},
                    },
                }
            ).encode("utf-8")
            request = urllib.request.Request(
                f"http://127.0.0.1:{port}/mcp/?agent_type=claude-code",
                data=body,
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json, text/event-stream",
                    "Authorization": "Bearer token-123",
                },
                method="POST",
            )
            with urllib.request.urlopen(request, timeout=10) as response:
                payload = response.read().decode("utf-8")
                assert response.status == 200
                assert '"serverInfo":{"name":"Whispers"' in payload
