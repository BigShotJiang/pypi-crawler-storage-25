from __future__ import annotations

from whispers.composition import CompositionEdge


def test_composition_edge_structural_relation():
    edge = CompositionEdge(source="harness:desktop", relation="contains", target="worker:lint", basis="observed")
    assert edge.is_structural() is True
    assert edge.is_grouping_only() is False
    assert edge.suggests_whole_escalation() is False


def test_composition_edge_grouping_relation_is_not_participant_whole():
    edge = CompositionEdge(source="agent:gear", relation="selected_by", target="all_codex_windows")
    assert edge.is_grouping_only() is True
    assert edge.is_structural() is False


def test_composition_edge_delegate_relation_suggests_whole_escalation():
    edge = CompositionEdge(source="assistant:zack-helper", relation="delegate_of", target="human:zack")
    assert edge.suggests_whole_escalation() is True
