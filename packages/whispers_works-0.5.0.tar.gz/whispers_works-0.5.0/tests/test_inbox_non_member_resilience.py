"""Inbox read must succeed even when the recipient has a stale/missing
pair-space membership.

Surfaced live by `examples/curl_any_language.sh` on 2026-04-17: an
external integrator bound curl-beta, alpha sent beta a whisper (which
creates the pair space via ensure_pair_space), and beta's very first
`GET /agents/curl-beta/inbox?mark_seen=true` returned

    {"error":"curl-beta is not currently participating in pair_<id>."}

The read itself was fine; the `mark_seen=True` side effect called
`spaces.touch_member()` for the pair space and that raised
WhispersDBError when beta's membership row wasn't active. The whole
inbox read failed because of the *presence refresh* side-effect.

The fix (messaging.Messaging.inbox):
  - Attempt touch_member as before.
  - If it raises WhispersDBError, try self-healing via join_space.
  - If join_space also fails, silently skip the touch — the read has
    already succeeded and presence is secondary.

This preserves the "fail closed on send" posture (the caller still
cannot send to a space they're not authorized for — that check lives
elsewhere) while letting a brand-new recipient read its own delivered
messages on first contact.

Run: pytest tests/test_inbox_non_member_resilience.py -v
"""

from __future__ import annotations

import pytest

from whispers.client import WhispersConflictError
from whispers.messaging import MessagingService
from whispers.spaces import SpaceService
from whispers.testing import WhispersTestHarness


class TestInboxNonMemberRecovery:
    def test_recipient_read_succeeds_when_membership_missing(self):
        """Delete beta's pair membership after send; inbox() still returns the message."""
        with WhispersTestHarness() as h:
            alpha = h.make_client("alpha")
            beta = h.make_client("beta")

            alpha.send("beta", subject="hello", body="first")

            # Pair space was auto-created. Simulate the failure mode where
            # beta's membership row got expired/marked left between delivery
            # and read — the reported curl_any_language.sh case.
            import sqlite3
            conn = sqlite3.connect(h.db_path)
            try:
                conn.execute(
                    "UPDATE workspace_members SET membership_state='left' "
                    "WHERE agent_name=? AND workspace_id LIKE 'pair_%'",
                    ("beta",),
                )
                conn.commit()
            finally:
                conn.close()

            # Before the fix: this would raise a WhispersDBError from the
            # mark_seen → touch_member path. After: we either self-heal via
            # join, or silently skip the touch and return the read anyway.
            messaging = MessagingService(beta.db, spaces=SpaceService(beta.db), dispatcher=beta.dispatcher)
            messages = messaging.inbox("beta", mark_seen=True)
            assert len(messages) >= 1
            assert any(
                m.get("sender") == "alpha" and m.get("subject") == "hello"
                for m in messages
            )

    def test_recipient_read_self_heals_membership_via_join(self):
        """When touch fails, inbox attempts join_space; on success, a second
        read shows the membership restored."""
        with WhispersTestHarness() as h:
            alpha = h.make_client("alpha")
            beta = h.make_client("beta")
            alpha.send("beta", subject="restart", body="x")

            # Simulate a dropped membership without LEFT state (delete the row).
            import sqlite3
            conn = sqlite3.connect(h.db_path)
            try:
                conn.execute(
                    "DELETE FROM workspace_members WHERE agent_name=? AND workspace_id LIKE 'pair_%'",
                    ("beta",),
                )
                conn.commit()
            finally:
                conn.close()

            messaging = MessagingService(beta.db, spaces=SpaceService(beta.db), dispatcher=beta.dispatcher)
            msgs = messaging.inbox("beta", mark_seen=True)
            assert len(msgs) >= 1

            # Membership should now exist again (self-heal via join_space).
            conn = sqlite3.connect(h.db_path)
            try:
                row = conn.execute(
                    "SELECT membership_state FROM workspace_members "
                    "WHERE agent_name=? AND workspace_id LIKE 'pair_%'",
                    ("beta",),
                ).fetchone()
            finally:
                conn.close()
            assert row is not None
            # Either 'joined' or 'active' (touch_member flips joined → active).
            assert row[0] in {"joined", "active"}

    def test_read_still_succeeds_when_even_join_fails(self):
        """Adversarial: simulate join_space also failing. Inbox read must
        still return the messages — presence is secondary to the read."""
        with WhispersTestHarness() as h:
            alpha = h.make_client("alpha")
            beta = h.make_client("beta")
            alpha.send("beta", subject="edge", body="x")

            messaging = MessagingService(beta.db, spaces=SpaceService(beta.db), dispatcher=beta.dispatcher)

            # Monkeypatch both touch_member and join_space to always raise.
            from whispers.client import WhispersDBError as _Err

            def boom(*a, **k):
                raise _Err("simulated presence failure")

            messaging.spaces.touch_member = boom  # type: ignore[assignment]
            messaging.spaces.join_space = boom  # type: ignore[assignment]

            msgs = messaging.inbox("beta", mark_seen=True)
            assert len(msgs) >= 1
            assert any(m.get("subject") == "edge" for m in msgs)

    def test_mark_seen_false_is_unaffected(self):
        """Baseline: mark_seen=False never calls touch_member, so no
        change in behavior for readers that don't mark."""
        with WhispersTestHarness() as h:
            alpha = h.make_client("alpha")
            beta = h.make_client("beta")
            alpha.send("beta", subject="peek", body="x")

            import sqlite3
            conn = sqlite3.connect(h.db_path)
            try:
                conn.execute(
                    "UPDATE workspace_members SET membership_state='left' "
                    "WHERE agent_name=? AND workspace_id LIKE 'pair_%'",
                    ("beta",),
                )
                conn.commit()
            finally:
                conn.close()

            messaging = MessagingService(beta.db, spaces=SpaceService(beta.db), dispatcher=beta.dispatcher)
            msgs = messaging.inbox("beta", mark_seen=False)
            assert len(msgs) >= 1
