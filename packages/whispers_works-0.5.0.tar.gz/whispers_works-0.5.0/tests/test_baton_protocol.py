from __future__ import annotations

from whispers.testing import WhispersTestHarness


class TestBatonProtocolBridge:
    def test_handoff_baton_projects_work_without_collapsing_it(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            offered = alice.work_offer(
                "bob",
                "Resolve auth routing",
                description="Get JWT validation green.",
                metadata={
                    "deliverable": "Passing JWT validation tests",
                    "next_action": "Run the auth smoke suite first.",
                    "proof_bar": "All auth tests pass.",
                    "target_files": ["whispers/auth.py", "tests/test_auth.py"],
                },
            )
            work_id = offered["work"]["work_id"]
            baton_ref = offered["offer_message"]["message_id"]

            baton = alice.work_baton(work_id)
            assert baton["schema"] == "handoff_baton.v1"
            assert baton["trace"]["message_id"] == baton_ref
            assert baton["trace"]["thread_id"] == offered["work"]["thread_id"]
            assert baton["payload"]["objective"] == "Resolve auth routing"
            assert baton["payload"]["deliverable"] == "Passing JWT validation tests"
            assert baton["payload"]["next_action"] == "Run the auth smoke suite first."
            assert baton["payload"]["workspace_id"] == offered["work"]["space_id"]
            assert offered["work"]["state"] == "offered"

            work_bundle = alice.work_get(work_id)
            assert [artifact["schema_name"] for artifact in work_bundle["artifacts"]] == ["handoff_baton.v1"]
            assert work_bundle["artifacts"][0]["raw_artifact"]["payload"]["objective"] == "Resolve auth routing"

    def test_baton_ack_and_review_pending_preserve_protocol_specific_truth(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            offered = alice.work_offer("bob", "Rebuild startup capsule", description="Keep it compact and truthful")
            baton_ref = offered["offer_message"]["message_id"]
            work_id = offered["work"]["work_id"]

            bob.check_inbox(mark_seen=True)
            acknowledged = bob.baton_ack(
                baton_ref,
                decision="conditionally_accepted",
                conditions=["Need one product decision on wording."],
            )
            assert acknowledged["artifact"]["schema"] == "baton_ack.v1"
            assert acknowledged["work"]["state"] == "accepted"
            assert acknowledged["work"]["owner_agent"] == "bob"
            assert acknowledged["work"]["metadata"]["baton_decision"] == "conditionally_accepted"
            assert acknowledged["work"]["metadata"]["baton_conditions"] == ["Need one product decision on wording."]

            message = alice.db.get_message(baton_ref)
            assert message is not None
            assert message["status"] == "acknowledged"

            review_pending = bob.baton_update(
                baton_ref,
                state="review_pending",
                progress="Code is ready; waiting on review.",
            )
            assert review_pending["artifact"]["schema"] == "baton_update.v1"
            assert review_pending["work"]["state"] == "accepted"
            assert review_pending["work"]["metadata"]["baton_state"] == "review_pending"
            assert review_pending["events"][-1]["event_kind"] == "baton_update"
            assert review_pending["events"][-1]["from_state"] == "accepted"
            assert review_pending["events"][-1]["to_state"] == "accepted"
            assert [artifact["schema_name"] for artifact in review_pending["artifacts"]] == [
                "handoff_baton.v1",
                "baton_ack.v1",
                "baton_update.v1",
            ]
            assert review_pending["artifacts"][-1]["raw_artifact"]["payload"]["state"] == "review_pending"

    def test_baton_close_blocked_vs_completed_maps_cleanly_to_work_truth(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            offered = alice.work_offer("bob", "Finish presence refactor", description="Need a truthful per-space model")
            baton_ref = offered["offer_message"]["message_id"]
            work_id = offered["work"]["work_id"]

            bob.baton_ack(baton_ref, decision="accepted")
            bob.baton_update(baton_ref, state="in_progress", progress="Tracing current presence paths")

            blocked = bob.baton_close(
                baton_ref,
                outcome="blocked",
                summary="Need continuity decisions before finishing.",
            )
            assert blocked["artifact"]["schema"] == "baton_close.v1"
            assert blocked["work"]["state"] == "blocked"
            assert blocked["work"]["closed_at"] is None
            assert blocked["work"]["metadata"]["baton_outcome"] == "blocked"

            closed = bob.baton_close(
                baton_ref,
                outcome="completed",
                summary="Presence refactor landed.",
                artifact_refs=["whispers://artifacts/presence-refactor"],
            )
            assert closed["work"]["state"] == "closed"
            assert closed["work"]["closed_at"] is not None
            assert closed["work"]["metadata"]["baton_outcome"] == "completed"
            assert closed["work"]["metadata"]["baton_artifact_refs"] == ["whispers://artifacts/presence-refactor"]
            assert closed["events"][-1]["event_kind"] == "baton_close"
            assert [artifact["schema_name"] for artifact in closed["artifacts"]] == [
                "handoff_baton.v1",
                "baton_ack.v1",
                "baton_update.v1",
                "baton_close.v1",
                "baton_close.v1",
            ]

            projected = alice.work_baton(work_id)
            assert projected["trace"]["message_id"] == baton_ref
            assert projected["payload"]["objective"] == "Finish presence refactor"
            assert "baton_outcome" not in projected["payload"]
