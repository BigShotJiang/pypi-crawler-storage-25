from __future__ import annotations

from whispers.testing import WhispersTestHarness
from whispers.twoack import DEFAULT_SCHEMA, WIRE_V, preflight_decision, preflight_surface, validate_envelope


class _ExplodingPayload:
    def __getitem__(self, key):
        raise AssertionError(f"payload should not be read ({key})")

    def get(self, key, default=None):
        raise AssertionError(f"payload.get should not be called ({key})")


class TestTwoAckV0:
    def test_send_attaches_valid_envelope(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            sent = alice.send("bob", "Need review", body="status please")
            message = bob.db.get_message(sent["message_id"])

            assert message is not None
            envelope = (message.get("payload") or {}).get("twoack")
            assert isinstance(envelope, dict)
            assert validate_envelope(envelope) == []
            assert envelope["wire_v"] == WIRE_V
            assert envelope["schema"] == DEFAULT_SCHEMA

    def test_trace_binding_to_message_id(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            sent = alice.send("bob", "Need review", body="status please")
            message = bob.db.get_message(sent["message_id"])

            assert message is not None
            envelope = (message.get("payload") or {}).get("twoack") or {}
            assert envelope.get("trace", {}).get("message_id") == sent["message_id"]
            assert envelope.get("trace", {}).get("thread_id") == sent["thread_id"]

    def test_metadata_mirrors_present(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send(
                "bob",
                "Need review",
                body="status please",
                payload={"state": "blocked", "current_task": "core-path"},
            )
            inbox = bob.check_inbox(mark_seen=False)

            assert len(inbox) == 1
            metadata = inbox[0].get("metadata") or {}
            assert metadata["whispers:schema"] == DEFAULT_SCHEMA
            assert metadata["whispers:wireMode"] == "agent-native"
            assert metadata["whispers:signalClass"] == "internal"
            assert metadata["whispers:wireProfiles"] == ["base"]

    def test_preflight_surface_without_payload(self):
        msg_row = {
            "message_id": "msg-123",
            "created_at": "2026-04-17T12:34:56Z",
            "metadata": {
                "whispers:schema": DEFAULT_SCHEMA,
                "whispers:wireMode": "agent-native",
                "whispers:signalClass": "internal",
                "whispers:wireProfiles": ["base"],
            },
            "payload": _ExplodingPayload(),
        }

        surface = preflight_surface(msg_row)
        assert surface == {
            "wire_v": WIRE_V,
            "schema": DEFAULT_SCHEMA,
            "signal_class": "internal",
            "trace.message_id": "msg-123",
        }
        assert preflight_decision(msg_row) == "accept"

    def test_frame_includes_state_tag(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            alice.send(
                "bob",
                "Need review",
                body="status please",
                payload={"state": "blocked", "current_task": "core-path"},
            )
            inbox = bob.check_inbox(mark_seen=False)

            assert len(inbox) == 1
            frame = inbox[0].get("frame") or ""
            assert "⟡ blocked" in frame
