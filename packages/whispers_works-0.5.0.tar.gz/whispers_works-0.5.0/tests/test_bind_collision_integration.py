"""Slice 6 Phase C — bind_seat integration with the collision envelope.

These tests exercise the wiring between the MCPSeatManager's bind path
and the orientation.py envelope/resolution helpers. Two paths matter:

  1. WhispersConflictError carries ContinuityConflictError.details so
     bind_seat can classify the collision kind without re-detecting.
  2. The full operator flow: first bind returns envelope; second bind
     with resolve={take_over} unblocks and succeeds.

Run: pytest tests/test_bind_collision_integration.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.client import WhispersConflictError
from whispers.mcp_server import (
    MCPSeatConfig,
    MCPSeatManager,
    _classify_conflict_kind,
)
from whispers.orientation import (
    apply_collision_resolution,
    build_collision_envelope,
)
from whispers.storage.db import WhispersDB
from whispers.testing import WhispersTestHarness


# ---------------------------------------------------------------------------
# WhispersConflictError details propagation
# ---------------------------------------------------------------------------


class TestConflictErrorDetails:
    def test_whispers_conflict_error_preserves_outcome_and_details(self):
        """The ContinuityConflictError raised inside connect() carries a
        rich details dict. WhispersConflictError must preserve it so
        bind_seat can build an envelope without re-querying state.

        Induced by pre-seeding a card with a different continuity_anchor
        than what the current bind would derive — matching the real live
        pattern that dead-ended today's burr reclaim before Slice 5.5.
        """
        with WhispersTestHarness() as h:
            # Initialize the schema before raw SQL writes.
            WhispersDB(db_path=h.db_path)
            # Pre-seed a 'burr' card under a fixed anchor different from
            # whatever connect() would derive in this process.
            conn = sqlite3.connect(h.db_path)
            try:
                conn.execute(
                    "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                    "platform_family, stable_subject_id, continuity_anchor) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    ("seeded-burr", "burr", 5, "claude-code",
                     "seeded-burr", "anchor:unlikely-to-match-derivation"),
                )
                conn.commit()
            finally:
                conn.close()

            manager = MCPSeatManager(MCPSeatConfig(
                db_path=h.db_path,
                participant_profile="desktop_ide_agent",
            ))
            with pytest.raises(WhispersConflictError) as exc_info:
                manager.bind_client(
                    "fresh-client",
                    requested_callsign="burr",
                    participant_profile="desktop_ide_agent",
                    session_kind="mcp_http",
                )

            exc = exc_info.value
            assert exc.outcome is not None, "outcome must be preserved"
            assert isinstance(exc.details, dict) and exc.details, \
                "details dict must be preserved and non-empty"
            assert "existing_agent_id" in exc.details \
                or "existing_continuity_anchor" in exc.details, \
                "details must name the colliding card so envelope can be built"


# ---------------------------------------------------------------------------
# Conflict kind classification
# ---------------------------------------------------------------------------


class TestClassifier:
    def test_classify_ledger_reservation(self):
        details = {
            "requested_callsign": "orphan",
            "reserved_stable_subject_id": "subj-x",
            "reserved_successor_callsign": None,
        }
        assert _classify_conflict_kind(details) == "ledger_reservation"

    def test_classify_anchor_mismatch(self):
        details = {
            "requested_callsign": "burr",
            "existing_agent_id": "agent-x",
            "existing_continuity_anchor": "anchor:old",
            "requested_continuity_anchor": "anchor:new",
        }
        assert _classify_conflict_kind(details) == "anchor_mismatch"

    def test_classify_anchor_has_presentations(self):
        details = {
            "requested_callsign": "X",
            "anchored_presentations": ["a", "b"],
            "active_presentations": [],
        }
        assert _classify_conflict_kind(details) == "anchor_has_presentations"

    def test_classify_falls_back_to_anchor_mismatch_on_unknown_shape(self):
        assert _classify_conflict_kind({}) == "anchor_mismatch"
        assert _classify_conflict_kind({"random_key": 1}) == "anchor_mismatch"


# ---------------------------------------------------------------------------
# Full operator flow: envelope → take_over → retry → success
# ---------------------------------------------------------------------------


class TestFullFlow:
    def test_take_over_then_retry_bind_succeeds(self, tmp_path):
        """End-to-end flow mirroring today's burr reclaim:
           1. Seed orphan burr card + ledger
           2. First bind attempt → envelope returned
           3. apply_collision_resolution(take_over) clears state
           4. Retry bind → succeeds with a fresh card
        """
        db_path = str(tmp_path / "fullflow.db")
        WhispersDB(db_path=db_path)

        # 1. Seed orphan burr
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, platform_family, "
                "stable_subject_id, continuity_anchor) VALUES (?, ?, ?, ?, ?, ?)",
                ("old-burr", "burr", 5, "claude-code", "old-burr", "anchor:old"),
            )
            conn.execute(
                "INSERT INTO callsign_ledger (callsign, stable_subject_id, agent_id, status, "
                "first_seen_at, last_bound_at) VALUES (?, ?, ?, 'current', "
                "datetime('now','-1 hour'), datetime('now','-1 hour'))",
                ("burr", "old-burr", "old-burr"),
            )
            conn.commit()
        finally:
            conn.close()

        # 2. Envelope should be constructable
        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            conflict={"kind": "anchor_mismatch", "existing_agent_id": "old-burr"},
        )
        assert envelope["bound"] is False
        assert any(c["id"] == "take_over" and c["precondition_ok"]
                   for c in envelope["choices"])

        # 3. Apply take_over
        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "take_over"},
            actor="test-operator",
        )
        assert result["ok"] is True
        assert result["next_step"] == "retry_bind"

        # 4. State cleared — ledger and card gone
        conn = sqlite3.connect(db_path)
        try:
            ledger = conn.execute(
                "SELECT * FROM callsign_ledger WHERE callsign=?", ("burr",)
            ).fetchone()
            card = conn.execute(
                "SELECT * FROM agent_cards WHERE callsign=?", ("burr",)
            ).fetchone()
        finally:
            conn.close()
        assert ledger is None
        assert card is None

        # A fresh bind_client using the same db would now succeed
        # (full bind involves statusline, wake registration, etc —
        # those are out of scope for this integration test. The contract
        # proven here: ledger+card cleared so the blocker is gone.)


class TestSiblingFlow:
    def test_sibling_resolution_names_label_for_retry(self, tmp_path):
        """Sibling resolution returns a label. The caller retries bind
        with sibling_label set. We assert the label plumbing without
        invoking connect() itself (which requires heavier harness setup).
        """
        db_path = str(tmp_path / "sibling.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, platform_family, "
                "stable_subject_id, continuity_anchor) VALUES (?, ?, ?, ?, ?, ?)",
                ("live-burr", "burr", 5, "claude-code", "live-burr", "anchor:live"),
            )
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_id, agent_name, session_kind, "
                "created_at, last_seen_at, lease_expires_at) VALUES (?, ?, ?, 'mcp_http', "
                "datetime('now'), datetime('now'), datetime('now','+30 minutes'))",
                ("sess-live", "live-burr", "burr"),
            )
            conn.commit()
        finally:
            conn.close()

        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            conflict={"kind": "anchor_mismatch", "existing_agent_id": "live-burr"},
        )
        # Live session blocks take_over, sibling is still offered
        take_over = next(c for c in envelope["choices"] if c["id"] == "take_over")
        assert take_over["precondition_ok"] is False
        sibling = next(c for c in envelope["choices"] if c["id"] == "sibling")
        assert sibling["precondition_ok"] is True

        # Operator picks sibling with an explicit label
        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "sibling", "label": "a3f1"},
        )
        assert result["ok"] is True
        assert result["next_step"] == "sibling_bind"
        assert result["sibling_label"] == "a3f1"

    def test_sibling_resolution_auto_generates_label_if_missing(self, tmp_path):
        """If the operator doesn't pass a label, the server generates a
        short hex suffix so the caller can still retry bind immediately.
        """
        db_path = str(tmp_path / "sibling_auto.db")
        WhispersDB(db_path=db_path)
        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "sibling"},
        )
        assert result["ok"] is True
        assert result["sibling_label"]
        assert len(result["sibling_label"]) >= 2
