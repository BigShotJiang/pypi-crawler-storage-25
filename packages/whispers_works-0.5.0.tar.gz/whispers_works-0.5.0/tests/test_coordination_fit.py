from __future__ import annotations

from whispers.coordination_fit import (
    AgentCoordinationProfile,
    TaskFitRequest,
    assess_agent_fit,
    rank_agents_for_task,
)


def test_assess_agent_fit_blocks_missing_required_strengths():
    request = TaskFitRequest(required_strengths=("architecture", "security"))
    profile = AgentCoordinationProfile(agent="haiku", strengths=("architecture",), cost_tier="low")

    assessment = assess_agent_fit(profile, request)
    assert assessment.eligible is False
    assert assessment.fit_band == "blocked"
    assert "missing required strengths" in assessment.reasons[0]


def test_rank_agents_prefers_high_fit_but_respects_budget():
    request = TaskFitRequest(
        required_strengths=("architecture",),
        preferred_strengths=("security",),
        quality_bar="high",
        max_cost_tier="medium",
    )
    strong_but_blocked = AgentCoordinationProfile(
        agent="opus",
        strengths=("architecture", "security"),
        cost_tier="high",
        effectiveness=0.95,
        current_capacity=0.9,
    )
    balanced = AgentCoordinationProfile(
        agent="sonnet",
        strengths=("architecture", "security"),
        cost_tier="medium",
        effectiveness=0.82,
        current_capacity=0.8,
    )
    cheap = AgentCoordinationProfile(
        agent="haiku",
        strengths=("architecture",),
        cost_tier="low",
        effectiveness=0.62,
        current_capacity=0.95,
    )

    ranked = rank_agents_for_task([cheap, strong_but_blocked, balanced], request)
    assert ranked[0].agent == "sonnet"
    assert ranked[0].eligible is True
    assert ranked[-1].agent == "opus"
    assert ranked[-1].eligible is False


def test_preserve_strong_models_can_favor_sufficient_cheaper_fit():
    request = TaskFitRequest(
        required_strengths=("review",),
        preferred_strengths=("diff-analysis",),
        preserve_strong_models=True,
        max_cost_tier="high",
    )
    titan = AgentCoordinationProfile(
        agent="opus",
        strengths=("review", "diff-analysis"),
        cost_tier="high",
        effectiveness=0.85,
        current_capacity=0.7,
        context_load=0.5,
    )
    cheaper = AgentCoordinationProfile(
        agent="haiku",
        strengths=("review", "diff-analysis"),
        cost_tier="low",
        effectiveness=0.73,
        current_capacity=0.95,
        context_load=0.15,
    )

    ranked = rank_agents_for_task([titan, cheaper], request)
    assert ranked[0].agent == "haiku"
    assert any("preserve strong models" in reason for reason in ranked[1].reasons)
