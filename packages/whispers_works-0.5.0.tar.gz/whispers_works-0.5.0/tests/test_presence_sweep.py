"""Slice 16 — presence-table dead-session sweep.

Companion to Slice 7's agent_sessions sweep. The `presence` table
tracks agent_name → status ('online'|'offline'|...) keyed by session_id.
When a session dies without cleanly writing status='offline', the row
lingers and misrepresents the agent as online. Kiln observed this on
their own orientation flow — multiple zombie rows under their callsign
from prior dead sessions.

sweep_dead_presence_rows() scans the presence table for rows whose
session_id references an expired/missing agent_sessions row AND whose
heartbeat_at is older than a grace window. Matching rows are deleted.

Run: pytest tests/test_presence_sweep.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.storage.db import WhispersDB


def _insert_presence(
    db_path: str,
    *,
    agent_name: str,
    session_id: str | None,
    status: str = "online",
    heartbeat_delta_minutes: int = 0,
) -> None:
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            "INSERT INTO presence (agent_name, agent_id, status, session_id, "
            "heartbeat_at, last_active) VALUES (?, ?, ?, ?, "
            f"datetime('now', '{heartbeat_delta_minutes:+d} minutes'), "
            f"datetime('now', '{heartbeat_delta_minutes:+d} minutes'))",
            (agent_name, f"{agent_name}-id", status, session_id),
        )
        conn.commit()
    finally:
        conn.close()


class TestPresenceSweep:
    def test_sweeps_presence_rows_with_missing_session(self, tmp_path):
        """A presence row whose session_id has no backing agent_sessions
        row is a zombie. Sweep removes it.
        """
        from whispers.orientation import sweep_dead_presence_rows

        db_path = str(tmp_path / "pres.db")
        WhispersDB(db_path=db_path)
        _insert_presence(
            db_path, agent_name="kiln", session_id="dead-session-id",
            heartbeat_delta_minutes=-30,
        )

        result = sweep_dead_presence_rows(db_path=db_path)
        assert result["swept"] >= 1

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT * FROM presence WHERE session_id=?",
                ("dead-session-id",),
            ).fetchone()
        finally:
            conn.close()
        assert row is None

    def test_preserves_presence_rows_with_live_session(self, tmp_path):
        """When the session_id matches a live, unexpired agent_sessions
        row, the presence row stays.
        """
        from whispers.orientation import sweep_dead_presence_rows

        db_path = str(tmp_path / "live.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_id, agent_name, "
                "session_kind, created_at, last_seen_at, lease_expires_at) VALUES "
                "('live-sess', 'kiln-id', 'kiln', 'mcp_http', datetime('now'), "
                "datetime('now'), datetime('now','+30 minutes'))"
            )
            conn.commit()
        finally:
            conn.close()
        _insert_presence(
            db_path, agent_name="kiln", session_id="live-sess",
            heartbeat_delta_minutes=-2,
        )

        sweep_dead_presence_rows(db_path=db_path)

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT * FROM presence WHERE session_id='live-sess'"
            ).fetchone()
        finally:
            conn.close()
        assert row is not None

    def test_skips_recent_rows_without_session(self, tmp_path):
        """Presence rows with no session_id but fresh heartbeat stay —
        could be a mid-reconnect race. Only stale rows get swept.
        """
        from whispers.orientation import sweep_dead_presence_rows

        db_path = str(tmp_path / "recent.db")
        WhispersDB(db_path=db_path)
        _insert_presence(
            db_path, agent_name="kiln", session_id=None,
            heartbeat_delta_minutes=-1,
        )

        sweep_dead_presence_rows(db_path=db_path, idle_threshold_seconds=60)

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT * FROM presence WHERE agent_name='kiln'"
            ).fetchone()
        finally:
            conn.close()
        assert row is not None

    def test_sweeps_stale_rows_with_no_session_id(self, tmp_path):
        """A presence row with session_id=NULL AND heartbeat beyond the
        idle threshold is a zombie. Swept.
        """
        from whispers.orientation import sweep_dead_presence_rows

        db_path = str(tmp_path / "nullsess.db")
        WhispersDB(db_path=db_path)
        _insert_presence(
            db_path, agent_name="kiln", session_id=None,
            heartbeat_delta_minutes=-30,
        )

        sweep_dead_presence_rows(db_path=db_path, idle_threshold_seconds=60)

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT * FROM presence WHERE agent_name='kiln'"
            ).fetchone()
        finally:
            conn.close()
        assert row is None

    def test_reports_per_callsign_counts(self, tmp_path):
        """presence has a UNIQUE constraint on agent_name (one row per
        callsign by design), so the sweep's per_callsign count maxes out
        at 1 per callsign. This test just verifies the scalar totals and
        callsign set match across multiple stale agents.
        """
        from whispers.orientation import sweep_dead_presence_rows

        db_path = str(tmp_path / "counts.db")
        WhispersDB(db_path=db_path)
        _insert_presence(db_path, agent_name="kiln", session_id="d1",
                         heartbeat_delta_minutes=-30)
        _insert_presence(db_path, agent_name="spark", session_id="d3",
                         heartbeat_delta_minutes=-30)

        result = sweep_dead_presence_rows(db_path=db_path)
        assert result["swept"] == 2
        assert set(result["per_callsign"].keys()) == {"kiln", "spark"}
