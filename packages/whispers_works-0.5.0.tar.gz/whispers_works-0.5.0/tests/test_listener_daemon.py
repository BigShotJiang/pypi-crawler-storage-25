"""AutonomousDaemon integration tests (W6 — active-listening v6).

Proves the full stack composes: engine -> policy -> safety ->
coordination -> backend -> reply. Uses the SSE loopback harness from
test_listener_engine + kiln's MockBackend + cinder's WakePolicyStack
and SafetyGuardrails.

These are the acceptance tests for v6 active listening at the
integration layer. Each backend call is a real call against a real
MockBackend instance; each reply is a real WhispersDB insert against a
temp sqlite. No patches, no substitutions of the pieces under test.
"""

from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional

import pytest

from whispers.client import WhispersClient
from whispers.listeners.backends.base import Response
from whispers.listeners.backends.mock_backend import MockBackend
from whispers.listeners.config import ListenerConfig, load_config
from whispers.listeners.coordination import CoordinationGate, PresenceState
from whispers.listeners.daemon import AutonomousDaemon
from whispers.listeners.engine import ListenerEngine, StreamEvent
from whispers.listeners.policies import (
    AddressedToMePolicy,
    FlashPriorityPolicy,
    WakePolicyStack,
)
from whispers.listeners.safety import SafetyConfig, SafetyGuardrails


# ----------------------------------------------------------------------
# SSE harness — same shape as test_listener_engine
# ----------------------------------------------------------------------


class _SSEEmitter:
    def __init__(self) -> None:
        self.queue: List[Dict[str, Any]] = []
        self.lock = threading.Lock()
        self.close_after_drain = threading.Event()

    def emit(
        self,
        event_type: str,
        payload: Dict[str, Any],
        event_id: Optional[int] = None,
    ) -> None:
        with self.lock:
            self.queue.append(
                {"event": event_type, "payload": payload, "id": event_id}
            )


def _make_server(emitter: _SSEEmitter) -> HTTPServer:
    class _Handler(BaseHTTPRequestHandler):
        def log_message(self, *args: Any, **kwargs: Any) -> None:
            return

        def do_GET(self) -> None:
            if "/wake/" not in self.path or "/stream" not in self.path:
                self.send_response(404)
                self.end_headers()
                return

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            try:
                self.wfile.write(b": connected\n\n")
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, OSError):
                return

            deadline = time.time() + 5.0
            while time.time() < deadline:
                with emitter.lock:
                    pending = list(emitter.queue)
                    emitter.queue.clear()
                for item in pending:
                    lines: List[str] = []
                    if item["event"] != "message":
                        lines.append(f"event: {item['event']}")
                    if item["id"] is not None:
                        lines.append(f"id: {item['id']}")
                    lines.append(f"data: {json.dumps(item['payload'])}")
                    blob = ("\n".join(lines) + "\n\n").encode("utf-8")
                    try:
                        self.wfile.write(blob)
                        self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        return
                if emitter.close_after_drain.is_set():
                    return
                time.sleep(0.05)

    return HTTPServer(("127.0.0.1", 0), _Handler)


@pytest.fixture
def sse_server():
    emitter = _SSEEmitter()
    server = _make_server(emitter)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield emitter, f"http://127.0.0.1:{port}"
    finally:
        emitter.close_after_drain.set()
        server.shutdown()
        server.server_close()


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _wake(
    *,
    sender: str = "peer-a",
    to: str = "listener-tester",
    subject: str = "hello",
    body: str = "hi",
    priority: str = "routine",
) -> Dict[str, Any]:
    return {
        "event_id": 0,
        "payload": {
            "packet": {
                "sender": sender,
                "to": to,
                "subject": subject,
                "body": body,
                "priority": priority,
                "msg_type": "inform",
            }
        },
    }


def _wait_for(pred, timeout: float = 3.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if pred():
            return True
        time.sleep(0.02)
    return False


def _build_daemon(
    *,
    server_url: str,
    callsign: str,
    client: WhispersClient,
    backend: MockBackend,
    policy_stack: Optional[WakePolicyStack] = None,
    safety: Optional[SafetyGuardrails] = None,
    coordination_gate: Optional[CoordinationGate] = None,
    presence_resolver=None,
) -> AutonomousDaemon:
    """Hand-build a daemon for tests (skips the TOML loader path)."""
    policy_stack = policy_stack or WakePolicyStack(
        [AddressedToMePolicy(self_callsign=callsign), FlashPriorityPolicy()]
    )
    safety = safety or SafetyGuardrails(config=SafetyConfig(self_callsign=callsign))
    coordination_gate = coordination_gate or CoordinationGate(preference="listener_primary")

    daemon: AutonomousDaemon = None  # type: ignore[assignment]
    engine = ListenerEngine(
        server_url=server_url,
        callsign=callsign,
        handler=lambda event: daemon._handle_event(event),
        policy=policy_stack,
        safety=safety,
    )
    daemon = AutonomousDaemon(
        callsign=callsign,
        server_url=server_url,
        engine=engine,
        coordination_gate=coordination_gate,
        backend=backend,
        client=client,
        presence_resolver=presence_resolver or (lambda: PresenceState(
            has_interactive_session=False,
            has_listener_session=True,
        )),
    )
    return daemon


# ----------------------------------------------------------------------
# Integration tests
# ----------------------------------------------------------------------


def test_full_chain_wakes_and_replies(sse_server, tmp_path):
    """The full composition: SSE -> policy -> safety -> coordination -> backend -> reply."""
    emitter, server_url = sse_server

    db_path = str(tmp_path / "w.db")
    listener_client = WhispersClient(
        agent_name="listener-tester",
        db_path=db_path,
        session_kind="local_listener",
    )
    peer_client = WhispersClient(agent_name="peer-a", db_path=db_path)

    backend = MockBackend(
        canned_text="auto-reply from mock",
        model_id="mock-model",
    )

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-tester",
        client=listener_client,
        backend=backend,
    )
    daemon.start()
    try:
        emitter.emit("wake", _wake(sender="peer-a", to="listener-tester"), event_id=1)
        assert _wait_for(lambda: daemon.stats.replies_sent >= 1, timeout=3.0)
    finally:
        daemon.stop()

    assert len(backend.calls) == 1
    assert daemon.stats.events_received == 1
    assert daemon.stats.backend_calls == 1
    assert daemon.stats.replies_sent == 1

    # Peer should have the reply in their inbox.
    peer_inbox = peer_client.check_inbox(limit=5, mark_seen=False)
    reply = next(
        (m for m in peer_inbox if m.get("from_agent") == "listener-tester"),
        None,
    )
    assert reply is not None, "peer-a did not receive the auto-reply"
    assert "auto-reply from mock" in (reply.get("body") or "")


def test_policy_filters_unaddressed_message(sse_server, tmp_path):
    """AddressedToMePolicy should skip a message sent from the callsign to itself."""
    emitter, server_url = sse_server
    db_path = str(tmp_path / "w.db")
    listener_client = WhispersClient(
        agent_name="listener-tester",
        db_path=db_path,
        session_kind="local_listener",
    )

    backend = MockBackend(canned_text="should not fire")

    # Self-sender triggers AddressedToMePolicy to skip with "self-reply".
    # After skip, FlashPriorityPolicy only allows flash. Routine → default deny.
    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-tester",
        client=listener_client,
        backend=backend,
    )
    daemon.start()
    try:
        emitter.emit(
            "wake",
            _wake(sender="listener-tester", to="listener-tester"),
            event_id=1,
        )
        time.sleep(0.5)
    finally:
        daemon.stop()

    assert len(backend.calls) == 0
    assert daemon.stats.backend_calls == 0


def test_flash_priority_bypasses_addressed_policy(sse_server, tmp_path):
    """FlashPriorityPolicy should allow a flash even when AddressedToMe skips."""
    emitter, server_url = sse_server
    db_path = str(tmp_path / "w.db")
    listener_client = WhispersClient(
        agent_name="listener-tester",
        db_path=db_path,
        session_kind="local_listener",
    )
    backend = MockBackend(canned_text="flash ack")

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-tester",
        client=listener_client,
        backend=backend,
    )
    daemon.start()
    try:
        emitter.emit(
            "wake",
            _wake(sender="peer-a", to="somebody-else", priority="flash"),
            event_id=1,
        )
        assert _wait_for(lambda: daemon.stats.backend_calls >= 1, timeout=3.0)
    finally:
        daemon.stop()
    assert len(backend.calls) == 1


def test_coordination_routes_to_interactive_when_operator_present(sse_server, tmp_path):
    """If the operator is interactive, the daemon must NOT auto-respond."""
    emitter, server_url = sse_server
    db_path = str(tmp_path / "w.db")
    listener_client = WhispersClient(
        agent_name="listener-tester",
        db_path=db_path,
        session_kind="local_listener",
    )
    backend = MockBackend(canned_text="should stay silent")

    presence_both_live = PresenceState(
        has_interactive_session=True,
        has_listener_session=True,
        interactive_session_kind="mcp_http",
    )

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-tester",
        client=listener_client,
        backend=backend,
        coordination_gate=CoordinationGate(preference="smart"),
        presence_resolver=lambda: presence_both_live,
    )
    daemon.start()
    try:
        emitter.emit("wake", _wake(sender="peer-a", to="listener-tester"), event_id=1)
        assert _wait_for(
            lambda: daemon.stats.events_routed_interactive >= 1, timeout=3.0
        )
    finally:
        daemon.stop()

    assert len(backend.calls) == 0, "backend should not fire when interactive"
    assert daemon.stats.replies_sent == 0


def test_backend_error_does_not_crash_daemon(sse_server, tmp_path):
    """BackendError should be caught; daemon keeps running."""
    from whispers.listeners.backends.base import BackendError

    emitter, server_url = sse_server
    db_path = str(tmp_path / "w.db")
    listener_client = WhispersClient(
        agent_name="listener-tester",
        db_path=db_path,
        session_kind="local_listener",
    )
    backend = MockBackend(
        canned_text="never reached",
        fail_with="rate_limited",
    )

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-tester",
        client=listener_client,
        backend=backend,
    )
    daemon.start()
    try:
        emitter.emit("wake", _wake(sender="peer-a", to="listener-tester"), event_id=1)
        assert _wait_for(lambda: daemon.stats.backend_errors >= 1, timeout=3.0)
        assert daemon.is_running()
    finally:
        daemon.stop()

    assert daemon.stats.backend_calls == 1
    assert daemon.stats.backend_errors == 1
    assert daemon.stats.replies_sent == 0


def test_capsule_snapshot_reflects_state(sse_server, tmp_path):
    emitter, server_url = sse_server
    db_path = str(tmp_path / "w.db")
    listener_client = WhispersClient(
        agent_name="listener-tester",
        db_path=db_path,
        session_kind="local_listener",
    )
    backend = MockBackend(canned_text="fine", model_id="mock-x")

    daemon = _build_daemon(
        server_url=server_url,
        callsign="listener-tester",
        client=listener_client,
        backend=backend,
    )
    daemon.start()
    try:
        emitter.emit("wake", _wake(sender="peer-a", to="listener-tester"), event_id=1)
        assert _wait_for(lambda: daemon.stats.replies_sent >= 1, timeout=3.0)
        snap = daemon.capsule_snapshot()
    finally:
        daemon.stop()

    assert snap["callsign"] == "listener-tester"
    assert snap["backend"]["name"] == "mock"
    assert snap["backend"]["model_id"] == "mock-x"
    assert snap["stats"]["events_received"] == 1
    assert snap["stats"]["replies_sent"] == 1
    assert "safety" in snap
    assert "coordination" in snap


# ----------------------------------------------------------------------
# Config loader tests
# ----------------------------------------------------------------------


def test_load_config_happy_path(tmp_path):
    cfg_path = tmp_path / "burr.toml"
    cfg_path.write_text(
        """
[listener]
callsign = "burr"
server_url = "http://127.0.0.1:8765"

[coordination]
preference = "smart"
flash_goes_to = "both"

[safety]
rate_limit_per_hour = 60
kill_switch_path = "~/.whispers/LISTENER_KILL"

[[policies]]
kind = "addressed_to_me"

[[policies]]
kind = "flash_priority"

[backend]
kind = "mock"
model_id = "mock-m"
""",
        encoding="utf-8",
    )

    cfg = load_config(cfg_path)
    assert cfg.callsign == "burr"
    assert cfg.server_url == "http://127.0.0.1:8765"
    assert cfg.coordination["preference"] == "smart"
    assert cfg.safety["rate_limit_per_hour"] == 60
    # Kill-switch path should be expanded.
    assert "~" not in str(cfg.safety.get("kill_switch_path") or "")
    assert len(cfg.policies) == 2
    assert cfg.backend["kind"] == "mock"


def test_load_config_missing_callsign_raises(tmp_path):
    cfg_path = tmp_path / "bad.toml"
    cfg_path.write_text(
        """
[listener]
server_url = "http://127.0.0.1:8765"

[backend]
kind = "mock"
""",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="callsign"):
        load_config(cfg_path)


def test_load_config_missing_backend_kind_raises(tmp_path):
    cfg_path = tmp_path / "bad.toml"
    cfg_path.write_text(
        """
[listener]
callsign = "burr"

[backend]
model_id = "whatever"
""",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match="backend.kind"):
        load_config(cfg_path)


def test_load_config_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        load_config(tmp_path / "does_not_exist.toml")


def test_from_config_builds_daemon(tmp_path):
    """AutonomousDaemon.from_config wires every layer without crashing."""
    cfg_path = tmp_path / "daemon.toml"
    cfg_path.write_text(
        """
[listener]
callsign = "daemon-tester"

[backend]
kind = "mock"
canned_text = "hi"
model_id = "mock-t"

[[policies]]
kind = "addressed_to_me"
""",
        encoding="utf-8",
    )
    cfg = load_config(cfg_path)

    # Pass a hand-built client so from_config doesn't try to register
    # against the live db.
    db_path = str(tmp_path / "w.db")
    client = WhispersClient(
        agent_name="daemon-tester",
        db_path=db_path,
        session_kind="local_listener",
    )
    daemon = AutonomousDaemon.from_config(cfg, client=client)
    assert daemon.callsign == "daemon-tester"
    assert daemon.backend.name == "mock"
    assert daemon.backend.model_id == "mock-t"
    # Daemon is constructed but NOT started. Confirm wiring is clean.
    snap = daemon.capsule_snapshot()
    assert snap["callsign"] == "daemon-tester"
    assert snap["is_running"] is False
