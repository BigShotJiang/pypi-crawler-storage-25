"""Criterion 5: Ambient agent identity — WHISPERS_AGENT env var and config.toml.

WHISPERS_AGENT=spark whispers inbox (no --agent flag) must succeed.
~/.whispers/config.toml [agent] name = "spark" must also succeed.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile

import pytest

from whispers.testing import WhispersTestHarness


def _run_cli(args: list[str], env: dict) -> tuple[int, dict]:
    result = subprocess.run(
        [sys.executable, "-m", "whispers.cli", *args],
        env=env,
        capture_output=True,
        text=True,
    )
    data = json.loads(result.stdout) if result.stdout.strip() else {}
    return result.returncode, data


def test_whispers_agent_env_var_replaces_flag():
    """WHISPERS_AGENT=<callsign> whispers who (no --agent) resolves correctly."""
    with WhispersTestHarness() as h:
        from whispers.client import WhispersClient

        WhispersClient("dune", db_path=h.db_path)  # register agent

        env = {**os.environ, "WHISPERS_AGENT": "dune"}
        returncode, data = _run_cli(["who", "--db", h.db_path], env)
        assert returncode == 0
        assert data.get("callsign") == "dune"


def test_config_toml_provides_agent_name():
    """~/.whispers/config.toml [agent] name = '<callsign>' works without --agent."""
    with WhispersTestHarness() as h:
        from whispers.client import WhispersClient

        WhispersClient("vale", db_path=h.db_path)

        home = tempfile.mkdtemp()
        whispers_dir = os.path.join(home, ".whispers")
        os.makedirs(whispers_dir)
        with open(os.path.join(whispers_dir, "config.toml"), "w") as fh:
            fh.write('[agent]\nname = "vale"\n')

        env = {k: v for k, v in os.environ.items() if k != "WHISPERS_AGENT"}
        env["HOME"] = home
        env["USERPROFILE"] = home

        returncode, data = _run_cli(["who", "--db", h.db_path], env)
        assert returncode == 0
        assert data.get("callsign") == "vale"


def test_env_var_takes_precedence_over_config_toml():
    """WHISPERS_AGENT overrides config.toml when both are present."""
    with WhispersTestHarness() as h:
        from whispers.client import WhispersClient

        WhispersClient("fern", db_path=h.db_path)
        WhispersClient("wick", db_path=h.db_path)

        home = tempfile.mkdtemp()
        whispers_dir = os.path.join(home, ".whispers")
        os.makedirs(whispers_dir)
        with open(os.path.join(whispers_dir, "config.toml"), "w") as fh:
            fh.write('[agent]\nname = "fern"\n')

        env = {k: v for k, v in os.environ.items()}
        env["HOME"] = home
        env["USERPROFILE"] = home
        env["WHISPERS_AGENT"] = "wick"  # should win over config.toml

        returncode, data = _run_cli(["who", "--db", h.db_path], env)
        assert returncode == 0
        assert data.get("callsign") == "wick"


def test_missing_agent_gives_helpful_error():
    """No --agent, no WHISPERS_AGENT, no config.toml → exit 2 with usage error."""
    with WhispersTestHarness() as h:
        env = {k: v for k, v in os.environ.items() if k != "WHISPERS_AGENT"}
        home = tempfile.mkdtemp()
        env["HOME"] = home
        env["USERPROFILE"] = home

        result = subprocess.run(
            [sys.executable, "-m", "whispers.cli", "who", "--db", h.db_path],
            env=env,
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0
        assert "WHISPERS_AGENT" in result.stderr or "config.toml" in result.stderr
