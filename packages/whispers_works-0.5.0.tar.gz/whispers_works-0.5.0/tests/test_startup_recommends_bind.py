"""Slice 10b — MCP `startup` tool gives unbound callers a path forward.

Before this slice, the `startup` MCP tool returned `{bound: false, seat: null}`
and nothing else — a dead end. A fresh agent calling `startup` on first touch
got no signal about (a) what to do next or (b) who else is here.

Slice 10b adds two novel blocks when `bound=False`:

- `recommended_action`: a concrete {action, suggested_callsign, reason} packet
  the caller can act on without operator mediation.
- `discovered_peers`: the top-N currently-live peers in the Whispers network,
  so a fresh agent sees the population it is joining BEFORE picking a callsign.

This is the first agent-infra surface that gives a newly-joining participant
immediate situational awareness. Once bound, these blocks disappear — the
caller already has the richer peer view via bind_seat's capsule.

Run: pytest tests/test_startup_recommends_bind.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.mcp_server import (
    MCPSeatConfig,
    MCPSeatManager,
    _build_discoverable_peers,
    _suggest_unused_callsign,
)
from whispers.storage.db import WhispersDB


def _seed_live_peers(db_path: str, peers: list[tuple[str, int, int]]) -> None:
    """Seed agent_cards + agent_sessions rows for a live peer roster.

    peers: list of (callsign, trust_tier, minutes_since_last_seen).
    Sessions with minutes < 10 count as live for discovery purposes.
    """
    conn = sqlite3.connect(db_path)
    try:
        for callsign, tier, minutes_ago in peers:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "stable_subject_id, continuity_anchor, participant_shape, "
                "last_seen) VALUES (?, ?, ?, ?, ?, 'atomic', "
                "datetime('now', ?))",
                (
                    f"{callsign}-id",
                    callsign,
                    tier,
                    f"{callsign}-id",
                    f"anchor:{callsign}",
                    f"-{minutes_ago} minutes",
                ),
            )
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_name, agent_id, "
                "session_kind, process_id, created_at, last_seen_at, "
                "lease_expires_at, metadata) VALUES "
                "(?, ?, ?, 'mcp_http', 1000, datetime('now', ?), "
                "datetime('now', ?), datetime('now', '+30 minutes'), '{}')",
                (
                    f"session:{callsign}",
                    callsign,
                    f"{callsign}-id",
                    f"-{minutes_ago} minutes",
                    f"-{minutes_ago} minutes",
                ),
            )
        conn.commit()
    finally:
        conn.close()


class TestDiscoverablePeers:
    """_build_discoverable_peers returns top-N live peers, ranked by salience."""

    def test_empty_db_returns_empty_list(self, tmp_path):
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        result = _build_discoverable_peers(db_path=db_path, budget=5)
        assert result["peers"] == []
        assert result["live_count"] == 0

    def test_returns_live_peers_only(self, tmp_path):
        """Peers with stale sessions (last_seen > 10 minutes) are NOT surfaced."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peers(
            db_path,
            [("freshly", 5, 2), ("recently", 4, 7), ("stalely", 3, 30)],
        )
        result = _build_discoverable_peers(db_path=db_path, budget=5)
        callsigns = {p["callsign"] for p in result["peers"]}
        assert "freshly" in callsigns
        assert "recently" in callsigns
        assert "stalely" not in callsigns

    def test_peers_ranked_by_salience(self, tmp_path):
        """Higher tier + more recent = higher rank."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peers(
            db_path,
            [("lowtier-fresh", 2, 1), ("hightier-fresh", 5, 1), ("hightier-older", 5, 9)],
        )
        result = _build_discoverable_peers(db_path=db_path, budget=5)
        peers = result["peers"]
        assert peers[0]["callsign"] == "hightier-fresh"
        # lowtier-fresh vs hightier-older: salience = tier * activity_weight
        # hightier-older: 5 * weight(9min)  vs  lowtier-fresh: 2 * weight(1min)
        # weight(1min) ~ 1.0 / (1 + 1/60) ~ 0.98
        # weight(9min) ~ 1.0 / (1 + 9/60) ~ 0.87
        # 5*0.87 = 4.35  vs  2*0.98 = 1.96  → hightier-older wins
        assert peers[1]["callsign"] == "hightier-older"
        assert peers[2]["callsign"] == "lowtier-fresh"

    def test_budget_caps_result(self, tmp_path):
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peers(
            db_path, [(f"peer{i}", 5, 1) for i in range(10)]
        )
        result = _build_discoverable_peers(db_path=db_path, budget=3)
        assert len(result["peers"]) == 3
        assert result["live_count"] == 10

    def test_each_peer_carries_public_fields(self, tmp_path):
        """Peers surface recognition-basis-relevant fields only — no internal state."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peers(db_path, [("solo", 5, 2)])
        result = _build_discoverable_peers(db_path=db_path, budget=5)
        peer = result["peers"][0]
        assert peer["callsign"] == "solo"
        assert peer["trust_tier"] == 5
        assert peer["participant_shape"] == "atomic"
        assert "last_seen_at" in peer
        assert "salience" in peer
        # These stay INSIDE the product — never surfaced to an unbound caller.
        assert "agent_id" not in peer
        assert "stable_subject_id" not in peer
        assert "continuity_anchor" not in peer


class TestCallsignSuggester:
    """_suggest_unused_callsign picks a friendly, collision-free name."""

    def test_returns_non_empty_string(self, tmp_path):
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        suggestion = _suggest_unused_callsign(db_path=db_path)
        assert isinstance(suggestion, str)
        assert len(suggestion) >= 3

    def test_suggestion_does_not_collide_with_live_peer(self, tmp_path):
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        # Seed MANY peers to force the picker to hop over collisions.
        _seed_live_peers(db_path, [(f"fixed{i}", 5, 1) for i in range(3)])
        for _ in range(20):
            suggestion = _suggest_unused_callsign(db_path=db_path)
            assert not suggestion.startswith("fixed"), (
                f"Suggester returned colliding name {suggestion!r}"
            )

    def test_suggestion_is_ledger_clean(self, tmp_path):
        """If every friendly-pool name is held, the suggester falls back to a
        randomized suffix so the caller always has a usable callsign."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        # Seed the entire friendly pool so the picker is forced to invent.
        from whispers.mcp_server import _FRIENDLY_CALLSIGN_POOL

        conn = sqlite3.connect(db_path)
        try:
            for name in _FRIENDLY_CALLSIGN_POOL:
                conn.execute(
                    "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                    "stable_subject_id, continuity_anchor) VALUES "
                    "(?, ?, 1, ?, ?)",
                    (f"{name}-id", name, f"{name}-id", f"anchor:{name}"),
                )
            conn.commit()
        finally:
            conn.close()

        suggestion = _suggest_unused_callsign(db_path=db_path)
        assert suggestion not in _FRIENDLY_CALLSIGN_POOL
        assert len(suggestion) >= 3


class TestStartupSurfaceUnbound:
    """When bound=False, startup_surface includes recommended_action + discovered_peers."""

    def test_unbound_includes_recommended_action(self, tmp_path):
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        manager = MCPSeatManager(MCPSeatConfig(db_path=db_path))
        result = manager.startup_surface(client_key="fresh-caller")
        assert result["bound"] is False
        ra = result["recommended_action"]
        assert ra["action"] == "bind_seat"
        assert isinstance(ra["suggested_callsign"], str)
        assert ra["suggested_callsign"]
        assert "reason" in ra

    def test_unbound_includes_discovered_peers(self, tmp_path):
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peers(db_path, [("nova", 5, 1), ("ember", 4, 3)])
        manager = MCPSeatManager(MCPSeatConfig(db_path=db_path))
        result = manager.startup_surface(client_key="fresh-caller")
        dp = result["discovered_peers"]
        callsigns = {p["callsign"] for p in dp["peers"]}
        assert callsigns == {"nova", "ember"}
        assert dp["live_count"] == 2

    def test_suggested_callsign_does_not_collide_with_live_peers(self, tmp_path):
        """The suggester must avoid names that appear in discovered_peers."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        _seed_live_peers(db_path, [(f"held{i}", 5, 1) for i in range(4)])
        manager = MCPSeatManager(MCPSeatConfig(db_path=db_path))
        for _ in range(10):
            result = manager.startup_surface(client_key="fresh-caller")
            suggested = result["recommended_action"]["suggested_callsign"]
            live = {p["callsign"] for p in result["discovered_peers"]["peers"]}
            assert suggested not in live

    def test_bound_caller_gets_no_recommendation_blocks(self, tmp_path):
        """Once bound, the caller already has the richer peer view. Don't duplicate."""
        db_path = str(tmp_path / "w.db")
        WhispersDB(db_path=db_path)
        manager = MCPSeatManager(MCPSeatConfig(db_path=db_path))
        # Force a bound client into the manager so bound=True.
        manager.bind_client(
            client_key="fresh-caller",
            requested_callsign="tester",
            platform_family="script",
        )
        result = manager.startup_surface(client_key="fresh-caller")
        assert result["bound"] is True
        assert "recommended_action" not in result
        assert "discovered_peers" not in result
