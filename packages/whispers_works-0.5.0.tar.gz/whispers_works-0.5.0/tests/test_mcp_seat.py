from __future__ import annotations

from fastapi.testclient import TestClient

from whispers.mcp_server import MCPSeatConfig, MCPSeatManager, create_mcp
from whispers.server import create_app
from whispers.testing import WhispersTestHarness


class TestMCPSeat:
    def test_fixed_mcp_seat_starts_bound(self):
        with WhispersTestHarness() as h:
            _, manager = create_mcp(
                db_path=h.db_path,
                fixed_agent_name="gear",
                participant_profile="desktop_ide_agent",
                session_kind="mcp_stdio",
            )
            startup = manager.startup_surface()
            assert startup["bound"] is True
            assert startup["fixed_seat"] is True
            assert startup["seat"]["agent_name"] == "gear"
            assert startup["seat"]["participant_kind"] == "host_bound_agent"

    def test_http_mcp_seat_can_bind_ambient_client(self):
        with WhispersTestHarness() as h:
            manager = MCPSeatManager(MCPSeatConfig(db_path=h.db_path, participant_profile="desktop_ide_agent"))
            bound = manager.bind_client(
                "claude-session-1",
                requested_callsign="gear",
                participant_profile="desktop_ide_agent",
                session_kind="mcp_http",
            )
            assert bound.status()["agent_name"] == "gear"
            startup = manager.startup_surface("claude-session-1")
            assert startup["bound"] is True
            assert startup["seat"]["chrome"]["identity"]["agent_name"] == "gear"

    def test_server_mounts_mcp_and_root_reports_it(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            with TestClient(app) as client:
                root = client.get("/")
                assert root.status_code == 200
                assert root.json()["mcp"] == "/mcp/"

                doctor = client.get("/doctor")
                assert doctor.status_code == 200
                assert doctor.json()["health"]["mcp"] == "/mcp/"

                probe = client.get("/mcp")
                assert probe.status_code in {200, 307, 405, 406, 421}
