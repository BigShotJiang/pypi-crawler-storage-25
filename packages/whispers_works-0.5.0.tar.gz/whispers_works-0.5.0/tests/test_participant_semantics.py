from __future__ import annotations

import pytest

from whispers.participant_semantics import ParticipantDescriptor


def test_participant_descriptor_interrogative_summary_for_device_surface():
    descriptor = ParticipantDescriptor(
        presentation_name="front-doorbell",
        participant_kind="device",
        participant_shape="cored_envelope",
        agency_relation="instrument",
        boundary_provenance="observer_asserted",
        recognition_basis="registration",
        what_do_you_do=("emit button presses", "publish camera snapshot refs"),
        differentiators=("surface:doorbell", "low-latency event source"),
        attached_resources=("camera", "home-network"),
        interaction_asks=("notify", "observe"),
    )

    summary = descriptor.interrogative_summary()
    assert summary["what_are_you"]["participant_kind"] == "device"
    assert "emit button presses" in summary["what_do_you_do"]
    assert "surface:doorbell" in summary["how_are_you_different"]
    assert summary["what_do_you_want_from_me"] == ["notify", "observe"]


def test_participant_descriptor_interrogative_summary_for_person():
    descriptor = ParticipantDescriptor(
        presentation_name="zack-public",
        participant_kind="human",
        participant_shape="drift_anchor",
        agency_relation="self",
        boundary_provenance="self_asserted",
        recognition_basis="attestation",
        what_do_you_do=("operator", "approver"),
        differentiators=("consequence owner", "product direction"),
        attached_resources=("memory-system",),
        interaction_asks=("review", "approve"),
    )

    summary = descriptor.interrogative_summary()
    assert summary["what_are_you"]["participant_kind"] == "human"
    assert "consequence owner" in summary["how_are_you_different"]
    assert summary["what_do_you_want_from_me"] == ["review", "approve"]


def test_participant_descriptor_rejects_unknown_ask():
    with pytest.raises(ValueError, match="interaction_ask"):
        ParticipantDescriptor(
            presentation_name="weird",
            participant_kind="gateway",
            participant_shape="federated_facade",
            agency_relation="representative",
            boundary_provenance="observer_asserted",
            recognition_basis="observation",
            interaction_asks=("befriend",),
        )
