from __future__ import annotations

import pytest

from whispers.scope_contracts import (
    ScopeRelationship,
    WorkingScopeContract,
    compare_working_scopes,
    normalize_working_scope_contract,
    serialize_working_scope_contract,
)


def test_normalize_scope_contract_from_string():
    scope = normalize_working_scope_contract("whispers.foundation")
    assert scope == WorkingScopeContract(scope_name="whispers.foundation")


def test_normalize_scope_contract_from_mapping():
    scope = normalize_working_scope_contract(
        {
            "scope_name": "whispers.foundation.identity",
            "description": "Identity continuity lane",
            "parent_scope": "whispers.foundation",
            "policy_hint": "no_silent_widening",
        }
    )
    assert scope == WorkingScopeContract(
        scope_name="whispers.foundation.identity",
        description="Identity continuity lane",
        parent_scope="whispers.foundation",
        policy_hint="no_silent_widening",
    )


def test_normalize_scope_contract_requires_scope_name_for_mapping():
    with pytest.raises(ValueError, match="scope_name"):
        normalize_working_scope_contract({"description": "missing name"})


def test_serialize_scope_contract_round_trips():
    serialized = serialize_working_scope_contract(
        WorkingScopeContract(
            scope_name="whispers.foundation",
            description="foundation lane",
            parent_scope="whispers",
        )
    )
    assert serialized == {
        "scope_name": "whispers.foundation",
        "description": "foundation lane",
        "parent_scope": "whispers",
        "policy_hint": None,
    }


def test_compare_working_scopes_same():
    relation = compare_working_scopes("whispers.foundation", "whispers.foundation")
    assert relation == ScopeRelationship("same", "whispers.foundation", "whispers.foundation")
    assert relation.changed is False
    assert relation.widening is False


def test_compare_working_scopes_narrower_and_wider():
    contracts = {
        "whispers": {"scope_name": "whispers"},
        "whispers.foundation": {"scope_name": "whispers.foundation", "parent_scope": "whispers"},
        "whispers.foundation.identity": {
            "scope_name": "whispers.foundation.identity",
            "parent_scope": "whispers.foundation",
        },
    }

    narrower = compare_working_scopes("whispers.foundation", "whispers.foundation.identity", contracts=contracts)
    wider = compare_working_scopes("whispers.foundation.identity", "whispers.foundation", contracts=contracts)

    assert narrower.relation == "narrower"
    assert narrower.changed is True
    assert narrower.widening is False

    assert wider.relation == "wider"
    assert wider.changed is True
    assert wider.widening is True


def test_compare_working_scopes_cross():
    contracts = {
        "whispers.foundation": {"scope_name": "whispers.foundation", "parent_scope": "whispers"},
        "whispers.console": {"scope_name": "whispers.console", "parent_scope": "whispers"},
    }
    relation = compare_working_scopes("whispers.foundation", "whispers.console", contracts=contracts)
    assert relation.relation == "cross"
    assert relation.changed is True
    assert relation.widening is True


def test_compare_working_scopes_unset_when_missing():
    relation = compare_working_scopes(None, "whispers.foundation")
    assert relation.relation == "unset"
    assert relation.changed is False
