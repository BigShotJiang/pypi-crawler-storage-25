"""Startup acceptance tests — overhaul doc §5 automated subset.

The overhaul doc (.planning/active/STARTUP-MECHANICS-OVERHAUL-2026-04-17.md)
defines 8 acceptance tests that gate the startup-mechanics tranche.
5 of 8 are automatable at library level given the slices shipped
today (5.5/6/6.5/7/8/9/10/11/16). Tests #3, #5, #6 require real
subprocess orchestration of multiple Claude Code windows or a live
wake-runtime kill — marked skipped with clear reasons.

Test mapping to shipped slices:
  #1 cold bind → 4 surfaces in sync   ← covered by Slice 6.5 + 9 + 11
  #2 shutdown/relaunch clean rebind    ← covered by Slice 7 + 9
  #3 two Claude windows independent   ← SKIP (needs live subprocess)
  #4 no-sibling first bind → tier 0    ← covered by Slice 6.5 default
  #5 peer flash → autonomous wake     ← SKIP (needs wake adapter + peer)
  #6 wake runtime killed → degraded   ← SKIP (needs runtime process)
  #7 callsign collision → envelope    ← covered by Slice 6 A/B/C
  #8 30-second full startup gate      ← holistic; tracked at §sess level

Run: pytest tests/test_startup_acceptance_live.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.storage.db import WhispersDB


class TestAcceptance1_ColdBind:
    """Acceptance #1: fresh bind → identity + trust + wake + statusline
    all agree on the bound callsign.
    """

    def test_fresh_bind_produces_consistent_identity(self, tmp_path):
        from whispers.testing import WhispersTestHarness

        with WhispersTestHarness() as h:
            client = h.make_client("accept1")
            assert client.agent_name == "accept1"
            assert client.identity_resolution is not None
            assert client.identity_resolution["callsign"] == "accept1"
            assert client.identity_resolution["outcome"] in (
                "registered", "rebind_accepted", "sibling_instance_allocated"
            )

    def test_fresh_bind_uses_trusted_env_default_tier(self, monkeypatch, tmp_path):
        """When WHISPERS_TRUSTED_ENV=1 is set, fresh agents bind at tier 5."""
        monkeypatch.setenv("WHISPERS_TRUSTED_ENV", "1")
        monkeypatch.delenv("WHISPERS_DEFAULT_TRUST_TIER", raising=False)

        from whispers.trust_baseline import baseline_trust_tier

        assert baseline_trust_tier("fresh-agent") == 5

    def test_fresh_bind_applies_explicit_tier_over_umbrella(self, monkeypatch):
        monkeypatch.setenv("WHISPERS_TRUSTED_ENV", "1")
        monkeypatch.setenv("WHISPERS_DEFAULT_TRUST_TIER", "3")

        from whispers.trust_baseline import baseline_trust_tier

        assert baseline_trust_tier("fresh-agent") == 3


class TestAcceptance2_ShutdownRelaunch:
    """Acceptance #2: kill the bridge/daemon, relaunch, rebind the same
    callsign → clean rebind (no phantom session, anchor preserved).
    """

    def test_rebind_after_session_death_succeeds(self, tmp_path):
        """Simulates session death by deleting the session row, then
        verifies a fresh bind reclaims cleanly via the same anchor.
        """
        from whispers.testing import WhispersTestHarness

        with WhispersTestHarness() as h:
            first = h.make_client("relaunch", platform_family="codex")
            anchor = first.identity_resolution["continuity_anchor"]
            first_agent_id = first.agent_id

            conn = sqlite3.connect(h.db_path)
            try:
                conn.execute(
                    "DELETE FROM agent_sessions WHERE agent_id=?", (first_agent_id,)
                )
                conn.commit()
            finally:
                conn.close()

            second = h.make_client("relaunch", platform_family="codex")
            assert second.identity_resolution["continuity_anchor"] == anchor
            assert second.identity_resolution["outcome"] in (
                "rebind_accepted", "registered"
            )

    def test_dead_pid_sweep_clears_stale_sessions(self, tmp_path):
        """Slice 7 dead-PID sweep is the cleanup mechanism that makes
        #2 robust.
        """
        from whispers.orientation import sweep_dead_pid_sessions

        db_path = str(tmp_path / "sweep.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_id, agent_name, "
                "session_kind, process_id, last_seen_at, created_at, "
                "lease_expires_at) VALUES ('s1', 'a1', 'ghost', 'mcp_http', "
                "999999, datetime('now','-10 minutes'), "
                "datetime('now','-10 minutes'), datetime('now','+30 minutes'))"
            )
            conn.commit()
        finally:
            conn.close()

        result = sweep_dead_pid_sessions(db_path=db_path)
        assert result["swept"] == 1


class TestAcceptance3_MultiWindow:
    """Acceptance #3: two concurrent Claude windows bind different
    callsigns; no cross-contamination. Requires real Claude Code
    subprocess orchestration.
    """

    @pytest.mark.skip(reason="Requires real multi-Claude-Code subprocess orchestration — not library-testable")
    def test_two_windows_independent(self):
        pass


class TestAcceptance4_NoSiblingFirstBind:
    """Acceptance #4: fresh host, no sibling → tier-0 bind with
    unknown_requires_authorization OR tier-5 via trusted-env umbrella.
    """

    def test_no_sibling_resolves_as_unknown_or_umbrella_tier(self, tmp_path):
        from whispers.orientation import resolve_trust_tier

        # No card + no siblings → tier 0 + unknown_requires_authorization
        resolved = resolve_trust_tier(card=None, siblings=[])
        assert resolved["value"] == 0
        assert resolved["basis"] == "unknown_requires_authorization"

    def test_authorize_tier_unblocks_the_card(self, tmp_path):
        from whispers.orientation import authorize_trust_tier
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "auth.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (callsign, trust_tier, platform_family) "
                "VALUES ('fresh', 0, 'claude-code')"
            )
            conn.commit()
        finally:
            conn.close()

        result = authorize_trust_tier(db_path=db_path, callsign="fresh", tier=5)
        assert result["ok"]
        assert result["tier"] == 5


class TestAcceptance5_FlashWake:
    """Acceptance #5: a peer sends a flash-priority message; the recipient's
    registered wake adapter receives a dispatch within the 5-second budget.

    Library-level proof: replaces the prior skip ("not library-testable").
    A WhispersTestHarness + a real loopback HTTPServer adapter + the existing
    `/wake/{agent}/dispatch` endpoint cover the full path end-to-end without
    spawning Claude Code subprocesses.

    Design calls made explicit (so reviewers can evaluate them, not just
    the code):

    1. **Real loopback HTTPServer, not an in-process callback.** The mock
       adapter listens on a real localhost port and POSTs come through the
       same ``urllib.request.urlopen`` path production uses. An in-process
       callback would be faster to write but would hide HTTP-layer
       regressions. Mirrors ``test_local_http_connector_receives_real_loopback_wake``.

    2. **5-second budget is the assertion bound; real latency should be
       sub-second.** The test records and asserts against the STARTING-LINE
       doc §2.2 budget. A latency measurement is attached to the assertion
       so the actual time lands in the pytest output — useful as a
       regression signal if the path ever grows slow.

    3. **Dispatch is triggered explicitly, not automatically.** The test
       sends the flash message, then calls ``/wake/{agent}/dispatch`` to
       fire. The auto-trigger mechanism (flash arrival → dispatch fire)
       lives in burr's Slice 9 territory; this test does not cover that
       link. What it DOES cover: given a dispatch fires, it reaches the
       adapter under budget with the correct flash-trigger payload.
    """

    FLASH_WAKE_BUDGET_SECONDS = 5.0

    def test_peer_flash_triggers_autonomous_wake(self):
        import json
        import threading
        import time
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from fastapi.testclient import TestClient

        from whispers.server import create_app
        from whispers.testing import WhispersTestHarness

        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            client.post("/identity/connect", json={"requested_callsign": "alice"})
            client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "desk",
                    "participant_profile": "desktop_ide_agent",
                },
            )

            received: dict[str, object] = {}
            received_event = threading.Event()

            class _WakeHandler(BaseHTTPRequestHandler):
                def do_POST(self):  # noqa: N802
                    length = int(self.headers.get("Content-Length") or "0")
                    raw = self.rfile.read(length)
                    received["path"] = self.path
                    received["packet"] = json.loads(raw.decode("utf-8"))
                    received["at"] = time.monotonic()
                    received_event.set()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(b'{"status":"ok"}')

                def log_message(self, format, *args):  # noqa: A003
                    return

            server = HTTPServer(("127.0.0.1", 0), _WakeHandler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()

            try:
                endpoint_url = f"http://127.0.0.1:{server.server_port}/wake"
                registered = client.post(
                    "/wake/desk/adapters",
                    json={
                        "adapter_kind": "local_http_connector",
                        "supported_actions": ["notify"],
                        "fallback_action": "notify",
                        "state": "supported",
                        "endpoint_url": endpoint_url,
                    },
                )
                assert registered.status_code == 200

                t_send = time.monotonic()
                sent = client.post(
                    "/messages/send",
                    json={
                        "sender": "alice",
                        "recipient": "desk",
                        "subject": "All-hands flash",
                        "body": "wake me, this is urgent",
                        "priority": "flash",
                    },
                )
                assert sent.status_code == 200

                dispatched = client.post("/wake/desk/dispatch")
                assert dispatched.status_code == 200
                body = dispatched.json()
                assert body["event"]["dispatch_status"] == "dispatched", (
                    f"expected dispatched, got {body['event']}"
                )
                # The wake packet should reflect the flash-arrival trigger.
                trigger = (
                    body["packet"]["wake"]["wake_projection"]
                    .get("attention_context", {})
                    .get("trigger")
                )
                assert trigger == "flash_message", (
                    f"expected flash_message trigger, got {trigger!r}"
                )

                assert received_event.wait(
                    timeout=self.FLASH_WAKE_BUDGET_SECONDS
                ), (
                    f"wake adapter did not receive the flash dispatch within "
                    f"{self.FLASH_WAKE_BUDGET_SECONDS}s budget"
                )

                elapsed = received["at"] - t_send
                assert elapsed < self.FLASH_WAKE_BUDGET_SECONDS, (
                    f"flash-to-adapter path took {elapsed:.3f}s, "
                    f"budget is {self.FLASH_WAKE_BUDGET_SECONDS}s"
                )

                # Emit the measured latency into the test output — useful
                # as a regression signal without failing on headroom.
                print(
                    f"\n  [flash-wake] send → adapter received in "
                    f"{elapsed * 1000:.1f} ms "
                    f"(budget {self.FLASH_WAKE_BUDGET_SECONDS * 1000:.0f} ms)"
                )

                packet = received.get("packet")
                assert isinstance(packet, dict)
                assert packet["wake"]["agent_name"] == "desk"
                assert received.get("path") == "/wake"

            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=1)


class TestAcceptance6_WakeRuntimeDegraded:
    """Acceptance #6: wake runtime killed → chrome degrades.

    Canonical spec (STARTUP-MECHANICS-OVERHAUL §5 test #6):
      "Start the wake runtime, then kill it manually → statusline renders
       wake:NONE within 2 statusline ticks; whoami chrome says wake degraded."

    Library-level honest version. The previous skip ("not library-testable")
    was wrong — a real HTTPServer registered as the wake adapter CAN be
    killed mid-flight via server.shutdown(), and the live dispatch path
    already detects the dead endpoint (URLError caught in server.py
    dispatch_wake) and records dispatch_status="dispatch_failed" into
    the wake_events table.

    What this test proves (live-path, no mock substitution):
      * A real loopback HTTPServer registered as local_http_connector.
      * Chrome reports wake adapter healthy while the server runs.
      * Server killed → next wake dispatch returns dispatch_failed within
        the 2-second budget.
      * wake_events records the failure with the right reason.

    What this test does NOT prove (documented gap, not a gloss):
      * Chrome proactively detecting a dead adapter WITHOUT a dispatch
        attempt. The current chrome read path
        (whispers.wake_runtime.build_wake_projection) reads from
        session metadata only — it does not probe adapter liveness or
        read wake_events for freshness. So chrome only reflects
        "wake:NONE" after a wake was actually attempted and failed.
        Closing that gap requires a chrome change (out of my scope this
        session).

    Regression-scope captured in the commit trailer.
    """

    # The spec says "within 2 statusline ticks" — a tick is ~2s, so 4s
    # is the honest budget reading. The dominant latency term is
    # server.py's urlopen(timeout=2) when the adapter is a killed-but-
    # not-yet-refused socket; the actual dispatch-failure detection
    # settles in ~2.0–2.1s on a local dead server.
    BUDGET_SECONDS = 4.0

    def test_wake_runtime_death_records_dispatch_failure_under_budget(self):
        import json
        import threading
        import time
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from fastapi.testclient import TestClient

        from whispers.server import create_app
        from whispers.testing import WhispersTestHarness

        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            client.post("/identity/connect", json={"requested_callsign": "alice"})
            client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "desk",
                    "participant_profile": "desktop_ide_agent",
                },
            )

            class _WakeHandler(BaseHTTPRequestHandler):
                def do_POST(self):  # noqa: N802
                    length = int(self.headers.get("Content-Length") or "0")
                    self.rfile.read(length)
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(b'{"status":"ok"}')

                def log_message(self, format, *args):  # noqa: A003
                    return

            wake_server = HTTPServer(("127.0.0.1", 0), _WakeHandler)
            thread = threading.Thread(target=wake_server.serve_forever, daemon=True)
            thread.start()

            endpoint_url = f"http://127.0.0.1:{wake_server.server_port}/wake"
            registered = client.post(
                "/wake/desk/adapters",
                json={
                    "adapter_kind": "local_http_connector",
                    "supported_actions": ["notify"],
                    "fallback_action": "notify",
                    "state": "supported",
                    "endpoint_url": endpoint_url,
                },
            )
            assert registered.status_code == 200

            # Sanity: while the runtime is alive, dispatch succeeds.
            client.post(
                "/messages/send",
                json={
                    "sender": "alice",
                    "recipient": "desk",
                    "subject": "health-check",
                    "body": "are you up",
                    "priority": "flash",
                },
            )
            healthy = client.post("/wake/desk/dispatch")
            assert healthy.status_code == 200
            assert healthy.json()["event"]["dispatch_status"] == "dispatched"

            # === Kill the wake runtime mid-flight ===
            # server.shutdown() returns after the serve_forever loop has
            # exited; that's the live subprocess-death moment.
            wake_server.shutdown()
            wake_server.server_close()
            thread.join(timeout=2)

            # Send another flash so there's something to dispatch.
            client.post(
                "/messages/send",
                json={
                    "sender": "alice",
                    "recipient": "desk",
                    "subject": "post-kill probe",
                    "body": "is the runtime dead",
                    "priority": "flash",
                },
            )

            # Dispatch must detect the dead adapter and record failure
            # within the 2-second budget. The real dispatch path in
            # server.py catches urllib.error.URLError + TimeoutError
            # and sets dispatch_status="dispatch_failed".
            t_dispatch = time.monotonic()
            dead = client.post("/wake/desk/dispatch")
            elapsed = time.monotonic() - t_dispatch

            assert dead.status_code == 200, (
                f"dispatch endpoint should return 200 even when adapter dead, "
                f"got {dead.status_code}"
            )
            body = dead.json()
            event = body["event"]
            assert event["dispatch_status"] == "dispatch_failed", (
                f"expected dispatch_failed, got {event['dispatch_status']!r}"
            )
            assert elapsed < self.BUDGET_SECONDS, (
                f"dispatch-to-dead-adapter took {elapsed:.3f}s, "
                f"budget is {self.BUDGET_SECONDS}s"
            )

            print(
                f"\n  [wake-runtime-kill] dispatch → dispatch_failed in "
                f"{elapsed * 1000:.1f} ms "
                f"(budget {self.BUDGET_SECONDS * 1000:.0f} ms)"
            )

            # Verify the failure is recorded in wake_events (the audit
            # trail the chrome-proactive-health gap would read from IF
            # that integration existed).
            events = client.get("/wake/desk/events")
            assert events.status_code == 200
            failed_events = [
                e for e in events.json()["events"]
                if e.get("dispatch_status") == "dispatch_failed"
            ]
            assert failed_events, (
                "wake_events should record the dispatch_failed event — "
                "this is the audit trail a future chrome-proactive-health "
                "integration would consume."
            )

    def test_dispatch_status_endpoint_exposes_failure_reason(self):
        """Confirms the wake dispatch response includes structured reason.

        Informational for a future chrome integration — the reason
        (usually 'URLError' or connection refused) is what a chrome
        degradation surface would need to say WHY wake is failing,
        not just that it is.
        """
        import threading
        from http.server import BaseHTTPRequestHandler, HTTPServer

        from fastapi.testclient import TestClient

        from whispers.server import create_app
        from whispers.testing import WhispersTestHarness

        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            client.post("/identity/connect", json={"requested_callsign": "alice"})
            client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "desk",
                    "participant_profile": "desktop_ide_agent",
                },
            )

            # Register an adapter pointing at a port we will NEVER bind.
            # This skips the "start server, kill server" dance and goes
            # straight to the dead-endpoint case.
            import socket

            sock = socket.socket()
            sock.bind(("127.0.0.1", 0))
            dead_port = sock.getsockname()[1]
            sock.close()

            client.post(
                "/wake/desk/adapters",
                json={
                    "adapter_kind": "local_http_connector",
                    "supported_actions": ["notify"],
                    "fallback_action": "notify",
                    "state": "supported",
                    "endpoint_url": f"http://127.0.0.1:{dead_port}/wake",
                },
            )
            client.post(
                "/messages/send",
                json={
                    "sender": "alice",
                    "recipient": "desk",
                    "subject": "dead port probe",
                    "priority": "flash",
                },
            )

            response = client.post("/wake/desk/dispatch")
            assert response.status_code == 200
            body = response.json()
            result = body["dispatch_result"]
            assert result["status"] == "dispatch_failed", (
                f"expected dispatch_failed, got {result}"
            )
            # The reason string varies by OS ('Connection refused',
            # 'No connection could be made', etc.) — just assert it's
            # non-empty and structured.
            assert "error" in result
            assert result["error"], "dispatch_failed should carry a reason"


class TestAcceptance7_CallsignCollision:
    """Acceptance #7: second caller asks for a bound callsign →
    envelope with 3 choices returned, NOT silent sibling allocation.
    """

    def test_collision_returns_envelope_with_take_over_option(self, tmp_path):
        from whispers.orientation import build_collision_envelope

        db_path = str(tmp_path / "coll.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "platform_family, stable_subject_id, continuity_anchor) "
                "VALUES ('old-id', 'burr', 5, 'claude-code', 'old-id', 'anchor:old')"
            )
            conn.execute(
                "INSERT INTO callsign_ledger (callsign, stable_subject_id, "
                "agent_id, status, first_seen_at, last_bound_at) VALUES "
                "('burr', 'old-id', 'old-id', 'current', "
                "datetime('now','-1 hour'), datetime('now','-1 hour'))"
            )
            conn.commit()
        finally:
            conn.close()

        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            conflict={"kind": "anchor_mismatch", "existing_agent_id": "old-id"},
        )
        assert envelope["bound"] is False
        choice_ids = [c["id"] for c in envelope["choices"]]
        assert "take_over" in choice_ids
        assert "sibling" in choice_ids
        assert "fresh" in choice_ids
        take_over = next(c for c in envelope["choices"] if c["id"] == "take_over")
        assert take_over["precondition_ok"] is True, (
            "no live session → take_over should be precondition_ok"
        )

    def test_collision_blocks_take_over_when_live_session(self, tmp_path):
        from whispers.orientation import build_collision_envelope

        db_path = str(tmp_path / "live.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "platform_family, stable_subject_id, continuity_anchor) "
                "VALUES ('live-id', 'burr', 5, 'claude-code', 'live-id', "
                "'anchor:live')"
            )
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_id, agent_name, "
                "session_kind, created_at, last_seen_at, lease_expires_at) VALUES "
                "('sess-live', 'live-id', 'burr', 'mcp_http', datetime('now'), "
                "datetime('now'), datetime('now','+30 minutes'))"
            )
            conn.commit()
        finally:
            conn.close()

        envelope = build_collision_envelope(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            conflict={"kind": "anchor_mismatch", "existing_agent_id": "live-id"},
        )
        take_over = next(c for c in envelope["choices"] if c["id"] == "take_over")
        assert take_over["precondition_ok"] is False

    def test_take_over_resolution_frees_the_callsign(self, tmp_path):
        from whispers.orientation import apply_collision_resolution
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "resolve.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "platform_family, stable_subject_id, continuity_anchor) VALUES "
                "('orphan-id', 'burr', 5, 'claude-code', 'orphan-id', 'anchor:orphan')"
            )
            conn.execute(
                "INSERT INTO callsign_ledger (callsign, stable_subject_id, "
                "agent_id, status, first_seen_at, last_bound_at) VALUES "
                "('burr', 'orphan-id', 'orphan-id', 'current', "
                "datetime('now','-1 hour'), datetime('now','-1 hour'))"
            )
            conn.commit()
        finally:
            conn.close()

        result = apply_collision_resolution(
            db_path=db_path,
            requested_callsign="burr",
            platform_family="claude-code",
            resolve={"resolve": "take_over"},
        )
        assert result["ok"]
        assert result["next_step"] == "retry_bind"

        conn = sqlite3.connect(db_path)
        try:
            ledger = conn.execute(
                "SELECT * FROM callsign_ledger WHERE callsign='burr'"
            ).fetchone()
            card = conn.execute(
                "SELECT * FROM agent_cards WHERE callsign='burr'"
            ).fetchone()
        finally:
            conn.close()
        assert ledger is None
        assert card is None


class TestAcceptance8_FullStartupGate:
    """Acceptance #8: cold claude launch → bind → peer exchange in <30s.
    Holistic gate; covered by session-level live-demo walkthrough
    rather than a single pytest case.
    """

    @pytest.mark.skip(reason="Holistic session-level gate — tracked via live operator walkthrough")
    def test_full_cold_to_peer_under_30_seconds(self):
        pass
