from __future__ import annotations

import json

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client

from whispers.server import create_app
from whispers.testing import WhispersTestHarness



def _tool_json(result):
    assert result
    text = result[0].text
    return json.loads(text)


@pytest.mark.asyncio
async def test_streamable_http_mcp_initializes_lists_tools_and_binds_seat():
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(transport=transport, base_url="http://127.0.0.1") as http_client:
                async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as streams:
                    read_stream, write_stream, _ = streams
                    async with ClientSession(read_stream, write_stream) as session:
                        init = await session.initialize()
                        assert init.serverInfo.name == "Whispers"

                        tools = await session.list_tools()
                        tool_names = {tool.name for tool in tools.tools}
                        assert {"startup", "bind_seat", "whoami", "status", "send", "inbox", "wake", "chrome"}.issubset(tool_names)

                        bound = await session.call_tool(
                            "bind_seat",
                            {
                                "requested_callsign": "gear",
                                "participant_profile": "desktop_ide_agent",
                            },
                        )
                        bound_payload = _tool_json(bound.content)
                        assert bound_payload["bound"] is True
                        assert bound_payload["status"]["agent_name"] == "gear"

                        who = await session.call_tool("whoami", {})
                        who_payload = _tool_json(who.content)
                        assert who_payload["callsign"] == "gear"

                        chrome = await session.call_tool("chrome", {})
                        chrome_payload = _tool_json(chrome.content)
                        assert chrome_payload["chrome"]["identity"]["agent_name"] == "gear"


@pytest.mark.asyncio
async def test_non_utf8_body_returns_parse_error():
    """Criterion 3: MCP server returns -32700 Parse Error on non-UTF-8 body.

    Windows-1252 em-dash (0x96) is not valid UTF-8. The MCP handler uses
    json.loads() which raises UnicodeDecodeError (not json.JSONDecodeError)
    for such inputs. Without the Utf8BodyMiddleware this surfaces as -32603
    internal error instead of -32700 parse error.
    """
    with WhispersTestHarness() as h:
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(transport=transport, base_url="http://127.0.0.1") as http_client:
                # Windows-1252 em-dash embedded in otherwise-valid JSON-like bytes
                non_utf8_body = b'{"text": "hello\x96world"}'
                response = await http_client.post(
                    "/mcp/",
                    content=non_utf8_body,
                    headers={
                        "Content-Type": "application/json",
                        "Accept": "application/json, text/event-stream",
                    },
                )
                assert response.status_code == 400
                payload = response.json()
                assert payload["jsonrpc"] == "2.0"
                assert payload["error"]["code"] == -32700
