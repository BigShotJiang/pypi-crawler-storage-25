"""Slice 10a — Trusted-env tier-5 default via WHISPERS_TRUSTED_ENV umbrella.

A fresh Claude Code session binding against a locally-operator-trusted daemon
must arrive at tier 5 by default, not tier 1. Tier 1 dead-letters cross-tier
sends and silently breaks team routing — confirmed 3x on 2026-04-17 per memory.

Slice 6.5 introduced WHISPERS_DEFAULT_TRUST_TIER=5. Slice 10a adds the
umbrella env var WHISPERS_TRUSTED_ENV=1 that acts as a single switch for the
"this daemon is on a trusted operator host" posture, so operators don't have
to know the specific tier-knob name.

Resolution order (unchanged at the floor, umbrella added):

    1. _BASELINE_TRUST_TIERS[callsign]                  explicit per-callsign
    2. WHISPERS_DEFAULT_TRUST_TIER env var               operator-declared exact tier
    3. WHISPERS_TRUSTED_ENV=1 umbrella                   → implies tier 5
    4. Hard default (tier 1)                             safe for external deployments

Malformed values at any layer must fail closed to the hard default so a typo
cannot silently grant privilege.

Run: pytest tests/test_trusted_env_defaults.py -v
"""

from __future__ import annotations

import importlib
import os

import pytest


@pytest.fixture
def clean_env(monkeypatch):
    """Clear both tier-related env vars so each test starts from the hard default."""
    monkeypatch.delenv("WHISPERS_DEFAULT_TRUST_TIER", raising=False)
    monkeypatch.delenv("WHISPERS_TRUSTED_ENV", raising=False)
    return monkeypatch


def _fresh_trust_baseline():
    """Re-import trust_baseline so module-level caches (if any) re-read env."""
    import whispers.trust_baseline as tb
    return importlib.reload(tb)


class TestResolverUmbrella:
    """trust_baseline.baseline_trust_tier honors WHISPERS_TRUSTED_ENV=1."""

    def test_hard_default_without_any_env(self, clean_env):
        """2026-04-17: hard default flipped 1→5. Single-operator trusted
        posture is the baseline; multi-tenant deployments opt down
        explicitly via WHISPERS_MULTI_TENANT=1.
        """
        tb = _fresh_trust_baseline()
        assert tb.baseline_trust_tier("newbie") == 5

    def test_multi_tenant_env_forces_tier_1(self, clean_env):
        clean_env.setenv("WHISPERS_MULTI_TENANT", "1")
        tb = _fresh_trust_baseline()
        assert tb.baseline_trust_tier("newbie") == 1

    def test_multi_tenant_downgrade_overrides_umbrella(self, clean_env):
        """If both umbrella and multi-tenant are set, multi-tenant wins
        because the operator explicitly declared untrusted posture."""
        clean_env.setenv("WHISPERS_TRUSTED_ENV", "1")
        clean_env.setenv("WHISPERS_MULTI_TENANT", "1")
        tb = _fresh_trust_baseline()
        assert tb.baseline_trust_tier("newbie") == 1

    def test_umbrella_alone_promotes_to_tier_5(self, clean_env):
        clean_env.setenv("WHISPERS_TRUSTED_ENV", "1")
        tb = _fresh_trust_baseline()
        assert tb.baseline_trust_tier("newbie") == 5

    def test_explicit_tier_wins_over_umbrella(self, clean_env):
        """If an operator set both, the explicit tier takes precedence."""
        clean_env.setenv("WHISPERS_TRUSTED_ENV", "1")
        clean_env.setenv("WHISPERS_DEFAULT_TRUST_TIER", "3")
        tb = _fresh_trust_baseline()
        assert tb.baseline_trust_tier("newbie") == 3

    def test_explicit_tier_alone_still_works(self, clean_env):
        clean_env.setenv("WHISPERS_DEFAULT_TRUST_TIER", "4")
        tb = _fresh_trust_baseline()
        assert tb.baseline_trust_tier("newbie") == 4

    def test_umbrella_non_one_values_do_not_promote(self, clean_env):
        """Only WHISPERS_TRUSTED_ENV=1 is the umbrella opt-in.
        Post-2026-04-17, the hard default is already 5, so non-'1'
        umbrella values fall through to the hard default (tier 5).
        Confirm the umbrella parser still rejects soft-truthy spellings
        — they fall through to the default rather than following the
        explicit-opt-in path.
        """
        clean_env.setenv("WHISPERS_MULTI_TENANT", "1")  # force tier 1 if umbrella didn't match
        for value in ("true", "yes", "on", "2", "0", "", "false"):
            clean_env.setenv("WHISPERS_TRUSTED_ENV", value)
            tb = _fresh_trust_baseline()
            # Multi-tenant is set; only exact "1" umbrella could promote,
            # and even then multi-tenant takes precedence. So all these
            # soft-truthy values should give tier 1.
            assert tb.baseline_trust_tier("newbie") == 1, (
                f"WHISPERS_TRUSTED_ENV={value!r} must NOT be the umbrella "
                f"opt-in — only the exact string '1' qualifies, and "
                f"WHISPERS_MULTI_TENANT=1 (set here) must not be bypassed."
            )

    def test_baseline_map_override_wins_over_umbrella(self, clean_env, monkeypatch):
        """Per-callsign override in _BASELINE_TRUST_TIERS still takes precedence."""
        tb = _fresh_trust_baseline()
        monkeypatch.setitem(tb._BASELINE_TRUST_TIERS, "pinned", 2)
        clean_env.setenv("WHISPERS_TRUSTED_ENV", "1")
        assert tb.baseline_trust_tier("pinned") == 2
        assert tb.baseline_trust_tier("unpinned") == 5

    def test_invalid_explicit_tier_fails_closed_past_umbrella(self, clean_env):
        """Malformed explicit tier must NOT fall back to umbrella — fail to hard default.

        A typo in the explicit var is the operator's bug; we must not quietly
        paper over it with the umbrella default. Fail closed to tier 1 so the
        operator notices.
        """
        clean_env.setenv("WHISPERS_TRUSTED_ENV", "1")
        clean_env.setenv("WHISPERS_DEFAULT_TRUST_TIER", "not-a-number")
        tb = _fresh_trust_baseline()
        assert tb.baseline_trust_tier("newbie") == 1

    def test_out_of_range_explicit_tier_fails_closed_past_umbrella(self, clean_env):
        clean_env.setenv("WHISPERS_TRUSTED_ENV", "1")
        clean_env.setenv("WHISPERS_DEFAULT_TRUST_TIER", "99")
        tb = _fresh_trust_baseline()
        assert tb.baseline_trust_tier("newbie") == 1


class TestStartBootstrap:
    """~/.whispers/_start.py must honor WHISPERS_TRUSTED_ENV=1 at server start.

    The daemon is invoked via `from whispers.server import start; start()` from
    _start.py. If an operator sets WHISPERS_TRUSTED_ENV=1 in their shell, the
    daemon process must read that and enter the bootstrap with effective
    tier-5 default behavior, without the operator having to know the tier-knob
    name directly.
    """

    def test_bootstrap_helper_promotes_umbrella_to_explicit_tier(self, clean_env):
        """Expose a callable bootstrap helper that _start.py invokes.

        The helper examines env and normalizes:
        WHISPERS_TRUSTED_ENV=1 → WHISPERS_DEFAULT_TRUST_TIER=5 (if not set)
        so the running daemon process has the explicit tier for other callers
        (clients that import trust_baseline in-process) to see.
        """
        clean_env.setenv("WHISPERS_TRUSTED_ENV", "1")
        from whispers.trust_baseline import apply_trusted_env_bootstrap

        apply_trusted_env_bootstrap()
        assert os.environ.get("WHISPERS_DEFAULT_TRUST_TIER") == "5"

    def test_bootstrap_does_not_override_explicit_tier(self, clean_env):
        """If the operator set an explicit tier, the umbrella must not clobber it."""
        clean_env.setenv("WHISPERS_TRUSTED_ENV", "1")
        clean_env.setenv("WHISPERS_DEFAULT_TRUST_TIER", "3")
        from whispers.trust_baseline import apply_trusted_env_bootstrap

        apply_trusted_env_bootstrap()
        assert os.environ.get("WHISPERS_DEFAULT_TRUST_TIER") == "3"

    def test_bootstrap_no_op_when_umbrella_not_set(self, clean_env):
        """Without the umbrella, the daemon runs as before — safe for external deployments."""
        from whispers.trust_baseline import apply_trusted_env_bootstrap

        apply_trusted_env_bootstrap()
        assert "WHISPERS_DEFAULT_TRUST_TIER" not in os.environ

    def test_bootstrap_ignores_non_one_umbrella_values(self, clean_env):
        for value in ("true", "yes", "on", "0", "2", ""):
            clean_env.setenv("WHISPERS_TRUSTED_ENV", value)
            clean_env.delenv("WHISPERS_DEFAULT_TRUST_TIER", raising=False)
            from whispers.trust_baseline import apply_trusted_env_bootstrap

            apply_trusted_env_bootstrap()
            assert "WHISPERS_DEFAULT_TRUST_TIER" not in os.environ, (
                f"Bootstrap must NOT set tier on WHISPERS_TRUSTED_ENV={value!r}"
            )
