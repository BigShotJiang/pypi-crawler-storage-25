from __future__ import annotations

import json
import sqlite3
from pathlib import Path

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client

import whispers.mcp_server as mcp_server
from whispers.mcp_server import (
    MCPSeatConfig,
    MCPSeatManager,
    clear_statusline_binding,
    resolve_claude_session_id,
    resolve_mcp_client_key,
    sync_session_metadata,
    write_statusline_binding,
)
from whispers.server import create_app
from whispers.testing import WhispersTestHarness


def _tool_json(result):
    assert result
    return json.loads(result[0].text)


class _FakeRequest:
    def __init__(self, headers: dict[str, str] | None = None):
        self.headers = headers or {}


class _FakeRequestContext:
    def __init__(self, request=None, session=None):
        self.request = request
        self.session = session


class _FakeContext:
    def __init__(self, *, client_id=None, headers: dict[str, str] | None = None, session=None):
        self.client_id = client_id
        self.request_context = _FakeRequestContext(
            request=_FakeRequest(headers=headers) if headers is not None else None,
            session=session,
        )


def test_resolve_claude_session_id_prefers_request_header():
    ctx = _FakeContext(
        headers={
            "x-whispers-claude-session-id": "claude-session-abc",
            "mcp-session-id": "mcp-session-123",
        }
    )
    assert resolve_claude_session_id(ctx=ctx) == "claude-session-abc"


def test_resolve_claude_session_id_falls_back_to_env_then_breadcrumb(tmp_path):
    breadcrumb_dir = Path(tmp_path) / ".whispers" / "claude-sessions" / "_breadcrumbs"
    breadcrumb_dir.mkdir(parents=True, exist_ok=True)
    (breadcrumb_dir / "999").write_text("breadcrumb-session", encoding="utf-8")

    assert (
        resolve_claude_session_id(
            env={"WHISPERS_CLAUDE_SESSION_ID": "env-session"},
            whispers_home=Path(tmp_path) / ".whispers",
            parent_pid=999,
        )
        == "env-session"
    )
    assert (
        resolve_claude_session_id(
            env={},
            whispers_home=Path(tmp_path) / ".whispers",
            parent_pid=999,
        )
        == "breadcrumb-session"
    )


def test_resolve_claude_session_id_safe_only_blocks_scan_fallback(tmp_path):
    """Regression: `safe_only=True` must NOT return a session ID whose
    only provenance is the scan-all-alive-breadcrumbs fallback.

    Without this guard, any subprocess (pytest, bash script, third-party
    tool) running while a single Claude Code window is alive inherits
    that window's session ID for user-level writes — silently overwriting
    the operator's statusline binding. The failure mode this test pins:

        # From a bash shell inside Claude Code:
        pytest tests/test_mcp_bind_controls.py  # binds 'gear'
        # => operator's statusline flips from 'helm' to 'gear'

    The fix is that every code path that WRITES to user-level state
    keyed by ``claude_session_id`` must pass ``safe_only=True``, and
    the resolver must return None rather than a scan-derived ID.
    """
    import os as _os
    breadcrumb_dir = Path(tmp_path) / ".whispers" / "claude-sessions" / "_breadcrumbs"
    breadcrumb_dir.mkdir(parents=True, exist_ok=True)
    # Our own pid is "alive" by definition, so writing a breadcrumb for
    # ourselves is the simplest way to produce a single-alive-Claude
    # condition the scan fallback would latch onto.
    (breadcrumb_dir / str(_os.getpid())).write_text("scan-only-session", encoding="utf-8")

    # safe_only=False (default): scan finds our fake alive breadcrumb
    # and returns its content. This proves the scan IS active and would
    # have returned a session ID to any bind-time caller.
    assert (
        resolve_claude_session_id(
            env={},
            whispers_home=Path(tmp_path) / ".whispers",
            parent_pid=1,  # wrong ppid on purpose — forces scan path
        )
        == "scan-only-session"
    )

    # safe_only=True: scan fallback disabled — resolver returns None.
    # Callers that would have written statusline state fall through to
    # the statusline_sync_degraded warning path, prompting the operator
    # to run `whispers adopt <callsign>` explicitly.
    assert (
        resolve_claude_session_id(
            env={},
            whispers_home=Path(tmp_path) / ".whispers",
            parent_pid=1,
            safe_only=True,
        )
        is None
    )


def test_resolve_mcp_client_key_prefers_claude_session_id_over_mcp_session_id():
    ctx = _FakeContext(
        headers={
            "x-whispers-claude-session-id": "claude-session-xyz",
            "mcp-session-id": "mcp-session-123",
        }
    )
    assert resolve_mcp_client_key(ctx) == "claude-session:claude-session-xyz"


def test_write_and_clear_statusline_binding_manage_per_session_file(tmp_path):
    whispers_home = Path(tmp_path) / ".whispers"
    write_statusline_binding(
        claude_session_id="session-abc",
        callsign="burr",
        whispers_home=whispers_home,
    )
    bind_file = whispers_home / "claude-sessions" / "session-abc.callsign"
    assert bind_file.read_text(encoding="utf-8") == "burr"

    clear_statusline_binding("session-abc", whispers_home=whispers_home)
    assert not bind_file.exists()


@pytest.mark.asyncio
async def test_bind_seat_warns_when_claude_session_id_unresolvable(tmp_path, monkeypatch):
    """Slice 8 refinement: bind_seat no longer BLOCKS when the Claude
    session ID can't be resolved — it binds anyway and flags the
    statusline sync as degraded. Blocking was worse than degraded:
    claude-code binds from a non-Claude-Code caller (or a freshly-
    restarted daemon that hasn't learned any session IDs yet) were
    getting uniformly rejected.
    """
    with WhispersTestHarness() as h:
        monkeypatch.setattr(mcp_server, "WHISPERS_HOME", Path(tmp_path) / ".whispers")
        # Stub wake registration so the happy path completes in tests.
        from whispers import orientation as _orient

        def _fake_wake_register(**kwargs):
            return {"ok": True, "endpoint_url": "http://127.0.0.1:0/wake",
                    "companion_pid": None, "registration": {"adapter_kind": "local_http_connector",
                    "supported_actions": ["notify"], "state": "supported"}}

        monkeypatch.setattr(_orient, "ensure_wake_adapter_for_claude_code_session", _fake_wake_register)
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://127.0.0.1",
            ) as http_client:
                async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as streams:
                    read_stream, write_stream, _ = streams
                    async with ClientSession(read_stream, write_stream) as session:
                        await session.initialize()
                        bound = await session.call_tool(
                            "bind_seat",
                            {
                                "requested_callsign": "gear",
                                "display_name": "Codex Desktop",
                                "session_name": "codex-link",
                                "participant_profile": "desktop_ide_agent",
                                "platform_family": "claude-code",
                            },
                        )
                        payload = _tool_json(bound.content)
                        assert payload["bound"] is True
                        warnings = payload.get("warnings", [])
                        assert any(
                            w.get("kind") == "statusline_sync_degraded"
                            for w in warnings
                        ), f"expected statusline_sync_degraded warning, got: {warnings}"


@pytest.mark.asyncio
async def test_bind_seat_writes_and_unbind_clears_per_session_file(tmp_path, monkeypatch):
    with WhispersTestHarness() as h:
        monkeypatch.setattr(mcp_server, "WHISPERS_HOME", Path(tmp_path) / ".whispers")
        # Exercise the real wake-registration helper with a stubbed
        # companion launch so bind_seat, whoami, status, and dispatch all
        # touch the same adapter-registration state.
        from whispers import orientation as _orient

        def _fake_companion(**kwargs):
            return (
                {
                    "pid": 14160,
                    "endpoint_url": "http://127.0.0.1:9/wake",
                    "registration": None,
                    "parent_pid": kwargs.get("parent_pid"),
                },
                "stubbed_for_test",
            )

        monkeypatch.setattr(
            _orient,
            "_ensure_local_wake_companion",
            _fake_companion,
        )
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(
                transport=transport,
                base_url="http://127.0.0.1",
                headers={"x-whispers-claude-session-id": "claude-session-abc"},
            ) as http_client:
                async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as streams:
                    read_stream, write_stream, _ = streams
                    async with ClientSession(read_stream, write_stream) as session:
                        await session.initialize()
                        bound = await session.call_tool(
                            "bind_seat",
                            {
                                "requested_callsign": "gear",
                                "display_name": "Codex Desktop",
                                "session_name": "codex-link",
                                "participant_profile": "desktop_ide_agent",
                                "platform_family": "claude-code",
                            },
                        )
                        payload = _tool_json(bound.content)
                        assert payload["bound"] is True
                        assert payload["status"]["session_name"] == "codex-link"
                        assert payload["status"]["chrome"]["identity"]["session_name"] == "codex-link"
                        assert payload["status"]["chrome"]["signal_line"].startswith("⏦⏦⏦ gear · session:codex-link")
                        bind_file = Path(tmp_path) / ".whispers" / "claude-sessions" / "claude-session-abc.callsign"
                        assert bind_file.read_text(encoding="utf-8") == "gear"

                        with sqlite3.connect(h.db_path) as conn:
                            row = conn.execute(
                                "SELECT metadata FROM agent_sessions WHERE agent_name = ? ORDER BY last_seen_at DESC LIMIT 1",
                                ("gear",),
                            ).fetchone()
                        assert row is not None
                        metadata = json.loads(row[0])
                        assert metadata["claude_session_id"] == "claude-session-abc"
                        assert metadata["display_name"] == "Codex Desktop"
                        assert metadata["session_name"] == "codex-link"
                        regs = metadata.get("adapter_registrations") or {}
                        assert "local_http_connector" in regs
                        assert regs["local_http_connector"]["endpoint_url"] == "http://127.0.0.1:9/wake"

                        sent = await http_client.post(
                            "/messages/send",
                            json={
                                "sender": "alice",
                                "recipient": "gear",
                                "subject": "All-hands flash",
                                "body": "wake me, this is urgent",
                                "priority": "flash",
                            },
                        )
                        assert sent.status_code == 200

                        dispatch = await http_client.post("/wake/gear/dispatch")
                        assert dispatch.status_code == 200
                        dispatch_payload = dispatch.json()
                        assert dispatch_payload["event"]["dispatch_status"] != "staged_no_adapter"
                        assert dispatch_payload["event"]["dispatch_status"] in {"dispatch_failed", "dispatched"}
                        assert dispatch_payload["event"]["adapter_kind"] == "local_http_connector"

                        unbound = await session.call_tool("unbind_seat", {})
                        unbound_payload = _tool_json(unbound.content)
                        assert unbound_payload["bound"] is False
                        assert not bind_file.exists()


def test_sync_session_metadata_records_claude_session_id_on_session_row():
    with WhispersTestHarness() as h:
        manager = MCPSeatManager(MCPSeatConfig(db_path=h.db_path, participant_profile="desktop_ide_agent"))
        client = manager.bind_client(
            "claude-session:abc",
            requested_callsign="gear",
            participant_profile="desktop_ide_agent",
            session_kind="mcp_http",
        )

        sync_session_metadata(client, claude_session_id="claude-session-abc")

        with client.db.get_connection() as conn:
            row = conn.execute(
                "SELECT metadata FROM agent_sessions WHERE session_id = ?",
                (client.session_id,),
            ).fetchone()
        assert row is not None
        metadata = json.loads(row["metadata"])
        assert metadata["claude_session_id"] == "claude-session-abc"
