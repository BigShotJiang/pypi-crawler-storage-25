from __future__ import annotations

import time
from whispers.testing import WhispersTestHarness

class TestTwoAckDeliveryInvariant:
    def test_failure_mode_1_no_optimistic_delivery(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            # Bob binds an active session, making him "online"
            bob.whoami()

            # Alice sends an envelope to Bob
            res = alice.send("bob", "Test invariant", body="Please read me")
            msg_id = res["message_id"]

            # Query the DB directly to check the raw truth BEFORE bob reads inbox
            status_before = alice.db.get_message_status(msg_id)
            assert status_before is not None

            # INVARIANT: An envelope is NEVER marked delivered without proof the recipient received it.
            # Even though Bob is online, he hasn't fetched it yet. It must remain queued.
            assert status_before["delivery_status"] == "queued"
            assert status_before["delivered_at"] is None
            assert status_before["seen_at"] is None

            # Now Bob actively pulls his inbox (proof of receipt)
            bob.check_inbox(mark_seen=True)

            # Query DB again
            status_after = alice.db.get_message_status(msg_id)
            assert status_after is not None

            # Now it should be marked delivered AND seen
            assert status_after["delivery_status"] == "delivered"
            assert status_after["delivered_at"] is not None
            assert status_after["seen_at"] is not None
            
            # The test will fail initially because the current db.py enthusiastically marks
            # things 'delivered' at insertion time if there's an active session.
