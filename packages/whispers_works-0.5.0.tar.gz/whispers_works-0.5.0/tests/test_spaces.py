from __future__ import annotations

import pytest

from whispers.client import WhispersException
from whispers.testing import WhispersTestHarness


class TestSpaceAwareKernel:
    def test_direct_send_creates_pair_space_and_updates_presence(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            result = alice.send("bob", "Hello Bob", body="pair-space proof")
            space_id = result["space_id"]
            assert space_id.startswith("pair_")

            alice_spaces = alice.spaces_list()
            bob_spaces = bob.spaces_list()
            assert any(space["space_id"] == space_id for space in alice_spaces)
            assert any(space["space_id"] == space_id for space in bob_spaces)
            assert next(space for space in alice_spaces if space["space_id"] == space_id)["boundary_type"] == "pair"

            before_presence = {row["agent_name"]: row["membership_state"] for row in alice.space_presence(space_id)}
            assert before_presence["alice"] == "active"
            assert before_presence["bob"] in {"joined", "active"}

            inbox = bob.check_inbox(mark_seen=True)
            assert inbox[0]["space_id"] == space_id

            after_presence = {row["agent_name"]: row["membership_state"] for row in bob.space_presence(space_id)}
            assert after_presence["bob"] == "active"

    def test_explicit_space_membership_required_for_send(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            charlie = h.make_client("charlie")

            snapshot = alice.space_create("exec-room")
            space_id = snapshot["space"]["space_id"]
            bob.space_join(space_id)

            result = alice.send("bob", "Inside room", body="allowed", space_id=space_id)
            assert result["space_id"] == space_id

            with pytest.raises(WhispersException):
                charlie.send("bob", "Boundary break", body="not allowed", space_id=space_id)

    def test_threads_stay_together_across_replies(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            first = alice.send("bob", "Question", body="Can you review this?")
            reply = bob.respond(first["message_id"], "Yes — looking now.")

            thread = alice.message_thread(first["thread_id"])
            assert len(thread) == 2
            assert {item["thread_id"] for item in thread} == {first["thread_id"]}
            assert thread[1]["reply_to"] == first["message_id"]

            original = alice.db.get_message(first["message_id"])
            assert original is not None
            assert original["status"] == "answered"
            assert reply["thread_id"] == first["thread_id"]

    def test_status_is_space_scoped_not_registry_scoped(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            h.make_client("charlie")

            result = alice.send("bob", "Scoped status")
            status = alice.status()

            assert len(status["spaces"]) == 1
            assert status["spaces"][0]["space_id"] == result["space_id"]
            assert "charlie" not in status["startup_capsule"]
            assert "messages waiting" in status["startup_capsule"]

    def test_duplicate_participation_names_are_allowed_but_ambiguous_for_routing(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            charlie = h.make_client("charlie")

            snapshot = alice.space_create("meeting-room")
            space_id = snapshot["space"]["space_id"]
            bob.space_join(space_id)
            charlie.space_join(space_id)

            alice.space_name_self(space_id, "sam")
            bob.space_name_self(space_id, "sam")

            members = {member["agent_name"]: member for member in alice.space_members(space_id)}
            assert members["alice"]["participation_name"] == "sam"
            assert members["bob"]["participation_name"] == "sam"

            with pytest.raises(WhispersException):
                charlie.send("sam", "Who exactly?", body="ambiguous on purpose", space_id=space_id)

    def test_space_seats_route_and_can_swap_without_identity_mutation(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            charlie = h.make_client("charlie")

            snapshot = alice.space_create("design-review")
            space_id = snapshot["space"]["space_id"]
            bob.space_join(space_id)
            charlie.space_join(space_id)

            alice.space_bind_seat(space_id, "facilitator", occupant_agent="bob")
            first = charlie.send("seat:facilitator", "First turn", body="for bob", space_id=space_id)
            bob_inbox = bob.check_inbox(mark_seen=False, space_id=space_id)
            assert any(message["message_id"] == first["message_id"] for message in bob_inbox)

            alice.space_bind_seat(space_id, "facilitator", occupant_agent="alice")
            second = charlie.send("seat:facilitator", "Second turn", body="for alice", space_id=space_id)
            alice_inbox = alice.check_inbox(mark_seen=False, space_id=space_id)
            assert any(message["message_id"] == second["message_id"] for message in alice_inbox)

    def test_exclusive_space_names_can_reject_duplicates(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            snapshot = alice.space_create(
                "exclusive-room",
                naming_policy="exclusive",
                naming_conflict_mode="reject",
            )
            space_id = snapshot["space"]["space_id"]
            bob.space_join(space_id)

            alice.space_name_self(space_id, "Sam")
            with pytest.raises(Exception):
                bob.space_name_self(space_id, "Sam")

    def test_exclusive_space_names_can_auto_suffix_duplicates(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            charlie = h.make_client("charlie")

            snapshot = alice.space_create(
                "team-room",
                naming_policy="exclusive",
                naming_conflict_mode="suffix",
            )
            space_id = snapshot["space"]["space_id"]
            bob.space_join(space_id)
            charlie.space_join(space_id)

            assert alice.space_name_self(space_id, "Sam")["participation_name"] == "Sam"
            assert bob.space_name_self(space_id, "Sam")["participation_name"] == "Sam2"
            assert charlie.space_name_self(space_id, "Sam")["participation_name"] == "Sam3"

            delivered = alice.send("Sam3", "Hello third Sam", body="unique local route", space_id=space_id)
            charlie_inbox = charlie.check_inbox(mark_seen=False, space_id=space_id)
            assert any(message["message_id"] == delivered["message_id"] for message in charlie_inbox)

    def test_reconnect_returns_agent_to_familiar_persistent_space(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice", owner_id="zack", platform_family="claudecode", context_hint="mainworktree")
            bob = h.make_client("bob", owner_id="zack", platform_family="codex", context_hint="reviewworktree")

            snapshot = alice.space_create("ops-room")
            space_id = snapshot["space"]["space_id"]
            bob.space_join(space_id)
            bob.space_name_self(space_id, "sam")
            alice.space_bind_seat(space_id, "scribe", occupant_agent="bob")

            rebound = h.make_client("bob", owner_id="zack", platform_family="codex", context_hint="reviewworktree")
            status = rebound.status()
            assert any(space["space_id"] == space_id for space in status["spaces"])
            assert "appear as sam" in status["startup_capsule"]
            assert "hold scribe" in status["startup_capsule"]
