from __future__ import annotations

from whispers.testing import WhispersTestHarness


class TestIdentityContinuity:
    def test_same_anchor_rebind_preserves_stable_subject_and_callsign(self):
        with WhispersTestHarness() as h:
            first = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )
            second = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )

            assert first.agent_name == "alice"
            assert second.agent_name == "alice"
            assert first._agent_id() == second._agent_id()
            assert first.identity_resolution is not None
            assert second.identity_resolution is not None
            assert first.identity_resolution["continuity_anchor"] == second.identity_resolution["continuity_anchor"]
            assert second.identity_resolution["outcome"] == "rebind_accepted"

            who = second.whoami()
            assert who is not None
            assert who["stable_subject_id"] == first._agent_id()
            assert who["continuity_anchor"] == first.identity_resolution["continuity_anchor"]
            assert who["platform_family"] == "claude-code"

    def test_context_hint_does_not_change_anchor_for_same_host_user_platform_and_callsign(self):
        with WhispersTestHarness() as h:
            first = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )
            second = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="review-worktree",
            )

            assert first.identity_resolution is not None
            assert second.identity_resolution is not None
            assert first.identity_resolution["continuity_anchor"] == second.identity_resolution["continuity_anchor"]
            assert second.identity_resolution["outcome"] == "rebind_accepted"

    def test_same_owner_same_family_can_allocate_sibling_presentation(self):
        with WhispersTestHarness() as h:
            primary = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )
            sibling = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="review-worktree",
                sibling_label="review",
            )

            assert sibling.agent_name != "alice"
            assert sibling.agent_name.isalpha()
            assert sibling.identity_resolution is not None
            assert sibling.identity_resolution["outcome"] == "sibling_instance_allocated"
            assert sibling._agent_id() != primary._agent_id()

            status = sibling.status()
            assert status["requested_agent_name"] == "alice"
            assert status["agent_name"] == sibling.agent_name
            assert status["continuity_anchor"] == sibling.identity_resolution["continuity_anchor"]

    def test_identity_events_are_recorded_for_continuity_outcomes(self):
        with WhispersTestHarness() as h:
            primary = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="main-worktree",
            )
            sibling = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claude-code",
                context_hint="review-worktree",
                sibling_label="review",
            )

            events = primary.db.list_identity_events(limit=10)
            outcomes = {event["outcome"] for event in events}
            assert "registered" in outcomes
            assert "sibling_instance_allocated" in outcomes
            assert any(event.get("callsign") == sibling.agent_name for event in events)
