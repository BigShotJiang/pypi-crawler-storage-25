from __future__ import annotations

from fastapi.testclient import TestClient

from whispers.server import create_app
from whispers.testing import WhispersTestHarness


class TestParticipantBringIn:
    def test_local_client_carries_descriptor_reachability_and_capability_provenance(self):
        with WhispersTestHarness() as h:
            agent = h.make_client(
                "desktop-claude",
                participant_kind="host_bound_agent",
                participant_shape="atomic",
                agency_relation="self",
                boundary_provenance="self_asserted",
                recognition_basis="registration",
                reachability_mode="manual_wake",
                interaction_asks=["review", "handoff"],
                capability_claims=[
                    {"provenance_kind": "native", "capability": "reason_about_code", "basis": "declared"},
                    {"provenance_kind": "attached", "capability": "git_diff", "provider": "tool:git"},
                    {"provenance_kind": "reachable", "capability": "legal_review", "provider": "agent:counsel"},
                ],
                composition_hints=[
                    {"source": "desktop-claude", "relation": "attached_to", "target": "tool:git", "basis": "declared"},
                ],
            )

            who = agent.whoami()
            assert who is not None
            assert who["participant_kind"] == "host_bound_agent"
            assert who["reachability_mode"] == "manual_wake"
            assert who["interaction_asks"] == ["review", "handoff"]
            assert who["capability_claims"][0]["provenance_kind"] == "native"
            assert who["capability_claims"][2]["provenance_kind"] == "reachable"
            assert who["composition_hints"][0]["relation"] == "attached_to"

            status = agent.status()
            assert status["participant_kind"] == "host_bound_agent"
            assert status["reachability_mode"] == "manual_wake"
            assert status["capability_claims"][1]["provenance_kind"] == "attached"

    def test_server_identity_connect_and_descriptor_update_surface_bring_in_truth(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            connected = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "doorbell",
                    "participant_kind": "device",
                    "participant_shape": "cored_envelope",
                    "agency_relation": "instrument",
                    "boundary_provenance": "observer_asserted",
                    "recognition_basis": "observation",
                    "reachability_mode": "event_emit_only",
                    "interaction_asks": ["notify", "observe"],
                    "capability_claims": [
                        {
                            "provenance_kind": "native",
                            "capability": "emit_button_press",
                            "basis": "observed",
                        }
                    ],
                    "composition_hints": [
                        {
                            "source": "doorbell",
                            "relation": "backed_by",
                            "target": "bridge:homeassistant",
                            "basis": "observed",
                        }
                    ],
                },
            )
            assert connected.status_code == 200
            body = connected.json()
            assert body["status"]["participant_kind"] == "device"
            assert body["status"]["reachability_mode"] == "event_emit_only"
            assert body["status"]["interaction_asks"] == ["notify", "observe"]
            assert body["status"]["capability_claims"][0]["capability"] == "emit_button_press"

            updated = client.post(
                "/identity/doorbell/descriptor",
                json={
                    "reachability_mode": "read_only_status",
                    "interaction_asks": ["monitor"],
                    "composition_hints": [
                        {
                            "source": "doorbell",
                            "relation": "backed_by",
                            "target": "bridge:homeassistant",
                            "basis": "attested",
                        }
                    ],
                },
            )
            assert updated.status_code == 200
            assert updated.json()["card"]["reachability_mode"] == "read_only_status"
            assert updated.json()["card"]["interaction_asks"] == ["monitor"]
            assert updated.json()["status"]["composition_hints"][0]["basis"] == "attested"

    def test_guided_profile_projects_into_status_startup_capsule_and_space_members(self):
        with WhispersTestHarness() as h:
            desk = h.make_client("desk", participant_profile="desktop_ide_agent")
            approval = h.make_client("approval-pane", participant_profile="approval_surface")

            created = desk.space_create("review-room")
            space_id = created["space"]["space_id"]
            approval.space_join(space_id)
            desk.space_bind_seat(space_id, "approver", occupant_agent="approval-pane")

            status = desk.status()
            assert "host bound agent" in (status.get("participant_summary") or "")
            assert "manual wake" in status["startup_capsule"]

            members = desk.space_members(space_id)
            approval_row = next(member for member in members if member["agent_name"] == "approval-pane")
            assert approval_row["participant"]["participant_kind"] == "approval_surface"
            assert "operator console" in approval_row["participant"]["summary"]
            assert approval_row["held_seats"] == ["approver"]

    def test_server_connect_accepts_guided_profile_defaults(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            connected = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "listener-one",
                    "participant_profile": "listener_agent",
                },
            )
            assert connected.status_code == 200
            payload = connected.json()
            assert payload["status"]["participant_kind"] == "primary_agent"
            assert payload["status"]["reachability_mode"] == "listener_backed"
            assert payload["status"]["capability_claims"][0]["capability"] == "continuous_listen"
            assert "listener" in (payload["status"].get("participant_summary") or "")
