"""Slice 11 — wake runtime deadlock fix.

When bind_seat (in-process, MCP-tool handler) spawns local_wake_runtime
to register a wake adapter, the old code had the subprocess POST to
the SAME server that was currently blocked handling bind_seat — classic
self-HTTP deadlock. Symptom: bind_seat returns bound:"partial" with
`runtime_spawn_failed:TimeoutError: timed out`.

Fix shape:
    (1) Subprocess prints its endpoint_url to stdout FIRST, before any
        HTTP register. Parent's readline() unblocks immediately.
    (2) New --skip-http-register flag lets the in-server path decline
        the HTTP round-trip entirely, since ensure_wake_adapter writes
        the adapter_registrations into the DB directly.

Run: pytest tests/test_wake_runtime_no_deadlock.py -v
"""

from __future__ import annotations

import json
import subprocess
import sys
import time

import pytest


class TestWakeRuntimeNoDeadlock:
    def test_subprocess_with_skip_http_register_emits_endpoint(self):
        """The subprocess, when invoked with --skip-http-register and
        pointed at an unresponsive server URL, still emits its endpoint
        payload to stdout and keeps running. The HTTP registration is
        skipped so no network dependency blocks startup.
        """
        # Use an unresponsive dummy server URL — if the runtime ignores
        # --skip-http-register, this test will hang waiting for the
        # subprocess to time out on urlopen.
        proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "whispers.local_wake_runtime",
                "--server", "http://127.0.0.1:1",  # black-hole port
                "--agent", "test-agent",
                "--host", "127.0.0.1",
                "--port", "0",
                "--skip-http-register",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            # Wait up to 3s for the first stdout line. If skip flag works,
            # this returns near-instantly.
            start = time.time()
            line = None
            while time.time() - start < 3.0:
                if proc.stdout and proc.stdout.readable():
                    line = proc.stdout.readline().strip()
                    if line:
                        break
                time.sleep(0.05)
            assert line, "subprocess should emit endpoint line under 3s with --skip-http-register"
            payload = json.loads(line)
            assert payload.get("endpoint_url", "").startswith("http://127.0.0.1:"), \
                f"expected endpoint_url in first line, got: {line}"
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()

    def test_subprocess_prints_endpoint_before_register_attempt(self):
        """Even without --skip-http-register, the startup payload must
        be emitted BEFORE the HTTP register attempt so the parent's
        readline() unblocks quickly (the register itself may succeed
        or fail; parent doesn't care).
        """
        proc = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "whispers.local_wake_runtime",
                "--server", "http://127.0.0.1:1",  # black-hole port
                "--agent", "test-agent-2",
                "--host", "127.0.0.1",
                "--port", "0",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            start = time.time()
            line = None
            while time.time() - start < 3.0:
                if proc.stdout and proc.stdout.readable():
                    line = proc.stdout.readline().strip()
                    if line:
                        break
                time.sleep(0.05)
            assert line, (
                "subprocess should emit endpoint line under 3s even without "
                "--skip-http-register (HTTP register attempt happens AFTER print)"
            )
            payload = json.loads(line)
            assert "endpoint_url" in payload
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()
