"""Plan-Phase-2 Slice 7 — context section (recent messages + obligations).

Composes the `context` capsule section from inbox + scope events +
pending obligations. Residue/drive_signals stubbed per plan doc §6
("Stub in Phase 1 returns []; Phase 2 wires real capture").

Run: pytest tests/test_context_section.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.storage.db import WhispersDB


def _seed(db_path: str) -> None:
    conn = sqlite3.connect(db_path)
    try:
        # self + 3 peers
        for cs, tier in [("me", 5), ("alice", 5), ("bob", 4), ("carol", 3)]:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "stable_subject_id, continuity_anchor) VALUES (?, ?, ?, ?, ?)",
                (f"{cs}-id", cs, tier, f"{cs}-id", f"anchor:{cs}"),
            )
        # Four messages with varied priority + recency
        for i, (frm, to, priority, subj, age_min, status) in enumerate([
            ("alice", "me", "flash", "URGENT: production is down", 5, "delivered"),
            ("me", "alice", "routine", "Re: handoff notes", 15, "delivered"),
            ("bob", "me", "routine", "daily standup", 60, "delivered"),
            ("carol", "me", "priority", "review request", 10, "delivered"),
        ]):
            conn.execute(
                "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, "
                "priority, subject, status, created_at) VALUES (?, ?, ?, "
                "'inform', ?, ?, ?, datetime('now', ?))",
                (f"m{i}", frm, to, priority, subj, status, f"-{age_min} minutes"),
            )
        # A flash message still unread — pending obligation
        conn.execute(
            "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, priority, "
            "subject, status, created_at) VALUES (?, ?, ?, 'inform', 'flash', "
            "'STOP the world', 'delivered', datetime('now','-3 minutes'))",
            ("m-flash-pending", "alice", "me"),
        )
        conn.execute(
            "INSERT INTO message_recipients (message_uuid, recipient_callsign, "
            "recipient_agent_id, delivery_status, created_at) VALUES "
            "(?, ?, ?, 'delivered', datetime('now','-3 minutes'))",
            ("m-flash-pending", "me", "me-id"),
        )
        conn.commit()
    finally:
        conn.close()


class TestRecentMessages:
    def test_recent_messages_surface_inbound_traffic(self, tmp_path):
        from whispers.orientation import build_context_section

        db_path = str(tmp_path / "ctx.db")
        WhispersDB(db_path=db_path)
        _seed(db_path)

        section = build_context_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        senders = {m.get("from") for m in section["recent_messages"]}
        assert "alice" in senders
        assert "carol" in senders

    def test_salience_orders_flash_priority_first(self, tmp_path):
        """flash > priority > routine; within the same priority, more
        recent outranks older."""
        from whispers.orientation import build_context_section

        db_path = str(tmp_path / "sal.db")
        WhispersDB(db_path=db_path)
        _seed(db_path)

        section = build_context_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        priorities = [m.get("priority") for m in section["recent_messages"]]
        flash_idx = next((i for i, p in enumerate(priorities) if p == "flash"), None)
        routine_idx = next((i for i, p in enumerate(priorities) if p == "routine"), None)
        assert flash_idx is not None and routine_idx is not None
        assert flash_idx < routine_idx, (
            f"flash must outrank routine; got: {priorities}"
        )

    def test_budget_truncates_messages_and_reports_omitted(self, tmp_path):
        from whispers.orientation import build_context_section

        db_path = str(tmp_path / "bud.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "stable_subject_id, continuity_anchor) VALUES "
                "('me-id', 'me', 5, 'me-id', 'anchor:me')"
            )
            for i in range(20):
                conn.execute(
                    "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                    "stable_subject_id, continuity_anchor) VALUES (?, ?, 3, ?, ?)",
                    (f"p{i}-id", f"p{i}", f"p{i}-id", f"anchor:p{i}"),
                )
                conn.execute(
                    "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, "
                    "priority, subject, status, created_at) VALUES (?, ?, ?, "
                    "'inform', 'routine', ?, 'delivered', datetime('now', ?))",
                    (f"m{i}", f"p{i}", "me", f"subj{i}", f"-{i*5} minutes"),
                )
            conn.commit()
        finally:
            conn.close()

        section = build_context_section(
            db_path=db_path,
            self_callsign="me",
            budget=5,
        )
        assert len(section["recent_messages"]) == 5
        assert section["recent_messages_omitted"]["count"] == 15
        assert "inbox" in section["recent_messages_omitted"]["discoverable_via"].lower()

    def test_message_entry_shape(self, tmp_path):
        """Each entry has from, subject, at, priority, status, age."""
        from whispers.orientation import build_context_section

        db_path = str(tmp_path / "shape.db")
        WhispersDB(db_path=db_path)
        _seed(db_path)

        section = build_context_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        for msg in section["recent_messages"]:
            for field in ("from", "subject", "at", "priority", "status"):
                assert field in msg, f"message missing field '{field}': {msg}"


class TestPendingObligations:
    def test_unread_flash_surfaces_as_obligation(self, tmp_path):
        """A flash-priority inbound message that the recipient hasn't
        acted on (no read_at, no acked_at) is a pending obligation.
        """
        from whispers.orientation import build_context_section

        db_path = str(tmp_path / "obl.db")
        WhispersDB(db_path=db_path)
        _seed(db_path)

        section = build_context_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        obligations = section["pending_obligations"]
        # seeded: one flash "STOP the world" from alice still unread
        assert any(
            o.get("kind") == "flash_awaiting" and o.get("from") == "alice"
            for o in obligations
        ), f"expected flash_awaiting obligation from alice; got {obligations}"

    def test_no_obligations_when_inbox_clear(self, tmp_path):
        from whispers.orientation import build_context_section

        db_path = str(tmp_path / "clean.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "stable_subject_id, continuity_anchor) VALUES "
                "('me-id', 'me', 5, 'me-id', 'anchor:me')"
            )
            conn.commit()
        finally:
            conn.close()

        section = build_context_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        assert section["pending_obligations"] == []


class TestResiduesAndDrive:
    def test_residue_is_stubbed_empty_list(self, tmp_path):
        """Phase 1 contract: recent_residue stays [] until the residue
        pipeline ships (planned as a separate slice).
        """
        from whispers.orientation import build_context_section

        db_path = str(tmp_path / "res.db")
        WhispersDB(db_path=db_path)
        _seed(db_path)

        section = build_context_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        assert section["recent_residue"] == []

    def test_drive_signals_is_stubbed_empty_list(self, tmp_path):
        from whispers.orientation import build_context_section

        db_path = str(tmp_path / "drive.db")
        WhispersDB(db_path=db_path)
        _seed(db_path)

        section = build_context_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        assert section["drive_signals"] == []


class TestCapsuleWiring:
    def test_capsule_includes_context_section(self, tmp_path):
        from whispers.orientation import assemble_bind_capsule
        from whispers.testing import WhispersTestHarness

        with WhispersTestHarness() as h:
            client = h.make_client("burr-ctx-test")
            capsule = assemble_bind_capsule(client=client)
            assert "context" in capsule
            ctx = capsule["context"]
            assert "recent_messages" in ctx
            assert "pending_obligations" in ctx
            assert "as_of" in ctx
