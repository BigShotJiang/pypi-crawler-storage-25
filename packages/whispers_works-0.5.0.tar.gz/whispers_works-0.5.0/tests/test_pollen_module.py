"""Pollen module unit tests (T4.20 — Stage A slice P0).

Proves the skeleton: schemas round-trip, canonicalize produces stable
bytes, signing + verification behave correctly including the three
negative paths (wrong key, tampered claims, tampered signature).

No integration with bind / trust / spaces here. This file tests the
pollen module in isolation so the contract is pinned before any code
above depends on it.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone

import pytest

from whispers.pollen import (
    IdentityPollen,
    MembershipPollen,
    PollenExpiredError,
    PollenSigner,
    PollenVerificationError,
    PollenVerifier,
    RelationPollen,
    canonicalize_json,
    deserialize_public_key,
    generate_issuer_keypair,
    serialize_public_key,
)
from whispers.pollen.signing import compute_key_id


# ----------------------------------------------------------------------
# Fixtures
# ----------------------------------------------------------------------


@pytest.fixture
def issuer_keypair():
    private_pem, public_raw = generate_issuer_keypair()
    return private_pem, public_raw


@pytest.fixture
def signer(issuer_keypair):
    private_pem, _ = issuer_keypair
    return PollenSigner(private_key_pem=private_pem)


@pytest.fixture
def verifier():
    return PollenVerifier()


def _iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _fresh_identity(
    *,
    callsign: str = "burr",
    trust_tier: int = 5,
    ttl_minutes: int = 60,
    issuer: str = "whispers-daemon",
    key_id: str = "test-key-id-0000",
) -> IdentityPollen:
    now = datetime.now(timezone.utc)
    return IdentityPollen(
        callsign=callsign,
        stable_subject_id="sid-" + callsign,
        continuity_anchor="anchor:" + callsign,
        trust_tier=trust_tier,
        issued_at=_iso(now),
        expires_at=_iso(now + timedelta(minutes=ttl_minutes)),
        issuer=issuer,
        key_id=key_id,
    )


# ----------------------------------------------------------------------
# canonicalize_json
# ----------------------------------------------------------------------


def test_canonicalize_key_ordering_is_stable():
    a = {"z": 1, "a": 2, "m": 3}
    b = {"a": 2, "m": 3, "z": 1}
    assert canonicalize_json(a) == canonicalize_json(b)


def test_canonicalize_nested_keys_sorted():
    obj = {"outer": {"z": 1, "a": 2}}
    out = canonicalize_json(obj).decode("utf-8")
    # inner keys must also be sorted
    assert '"outer":{"a":2,"z":1}' in out


def test_canonicalize_separators_have_no_whitespace():
    out = canonicalize_json({"a": 1, "b": [1, 2, 3]}).decode("utf-8")
    assert " " not in out
    assert out == '{"a":1,"b":[1,2,3]}'


def test_canonicalize_refuses_nan():
    with pytest.raises(ValueError):
        canonicalize_json({"x": float("nan")})


def test_canonicalize_utf8_passthrough():
    out = canonicalize_json({"name": "héllo"})
    # Not ASCII-escaped; UTF-8 bytes passed through
    assert "héllo".encode("utf-8") in out


# ----------------------------------------------------------------------
# Schema round-trip
# ----------------------------------------------------------------------


def test_identity_pollen_to_from_claims_roundtrip():
    original = _fresh_identity()
    claims = original.to_claims()
    assert claims["kind"] == "identity"
    rebuilt = IdentityPollen.from_claims(claims)
    assert rebuilt == original


def test_identity_pollen_from_wrong_kind_raises():
    claims = _fresh_identity().to_claims()
    claims["kind"] = "membership"
    with pytest.raises(PollenVerificationError) as exc_info:
        IdentityPollen.from_claims(claims)
    assert exc_info.value.reason == "wrong_kind"


def test_identity_pollen_missing_field_raises():
    claims = _fresh_identity().to_claims()
    claims.pop("trust_tier")
    with pytest.raises(PollenVerificationError) as exc_info:
        IdentityPollen.from_claims(claims)
    assert exc_info.value.reason == "missing_fields"
    assert "trust_tier" in str(exc_info.value)


def test_identity_pollen_expiry_check_ok_when_future():
    pollen = _fresh_identity(ttl_minutes=10)
    # Should NOT raise
    pollen.check_not_expired()


def test_identity_pollen_expiry_check_raises_when_past():
    pollen = _fresh_identity(ttl_minutes=-5)  # already expired
    with pytest.raises(PollenExpiredError):
        pollen.check_not_expired()


def test_membership_pollen_roundtrip():
    now = datetime.now(timezone.utc)
    pollen = MembershipPollen(
        callsign="burr",
        space_id="pair_abc",
        role="member",
        joined_at=_iso(now - timedelta(hours=2)),
        issued_at=_iso(now),
        expires_at=_iso(now + timedelta(hours=24)),
        issuer="whispers-daemon",
        key_id="k1",
    )
    claims = pollen.to_claims()
    assert claims["kind"] == "membership"
    assert MembershipPollen.from_claims(claims) == pollen


def test_relation_pollen_roundtrip():
    now = datetime.now(timezone.utc)
    pollen = RelationPollen(
        from_callsign="flux",
        to_callsign="burr",
        affordance="see_me",
        issued_at=_iso(now),
        expires_at=_iso(now + timedelta(days=1)),
        key_id="k2",
    )
    claims = pollen.to_claims()
    assert claims["kind"] == "relation"
    assert RelationPollen.from_claims(claims) == pollen


# ----------------------------------------------------------------------
# Key generation + serialization
# ----------------------------------------------------------------------


def test_keypair_generation_produces_valid_shapes(issuer_keypair):
    private_pem, public_raw = issuer_keypair
    assert b"BEGIN PRIVATE KEY" in private_pem or b"BEGIN ED25519" in private_pem
    assert len(public_raw) == 32


def test_public_key_serialize_roundtrip(issuer_keypair):
    _, public_raw = issuer_keypair
    encoded = serialize_public_key(public_raw)
    assert isinstance(encoded, str)
    decoded = deserialize_public_key(encoded)
    assert decoded == public_raw


def test_public_key_serialize_rejects_wrong_length():
    with pytest.raises(ValueError):
        serialize_public_key(b"short")


def test_public_key_deserialize_rejects_wrong_length():
    # 8 bytes encoded
    bad = serialize_public_key(b"A" * 32)
    # corrupt it by truncating
    with pytest.raises(ValueError):
        deserialize_public_key(bad[:4])


def test_compute_key_id_stable(issuer_keypair):
    _, public_raw = issuer_keypair
    assert compute_key_id(public_raw) == compute_key_id(public_raw)
    # And differs from a different key
    _, other_raw = generate_issuer_keypair()
    if other_raw != public_raw:
        assert compute_key_id(other_raw) != compute_key_id(public_raw)


# ----------------------------------------------------------------------
# Sign + verify — happy path
# ----------------------------------------------------------------------


def test_sign_and_verify_identity_pollen(signer, verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    pollen = _fresh_identity(key_id=signer.key_id)
    envelope = signer.sign_claims(pollen.to_claims())

    verified_claims = verifier.verify_envelope(envelope, public_key_raw=public_raw)
    rebuilt = IdentityPollen.from_claims(verified_claims)
    assert rebuilt == pollen


def test_sign_and_verify_membership_pollen(signer, verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    now = datetime.now(timezone.utc)
    pollen = MembershipPollen(
        callsign="burr",
        space_id="pair_xyz",
        role="member",
        joined_at=_iso(now - timedelta(minutes=30)),
        issued_at=_iso(now),
        expires_at=_iso(now + timedelta(hours=6)),
        issuer="whispers-daemon",
        key_id=signer.key_id,
    )
    envelope = signer.sign_claims(pollen.to_claims())
    verified = verifier.verify_envelope(envelope, public_key_raw=public_raw)
    assert MembershipPollen.from_claims(verified) == pollen


def test_sign_and_verify_relation_pollen(signer, verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    now = datetime.now(timezone.utc)
    pollen = RelationPollen(
        from_callsign="flux",
        to_callsign="burr",
        affordance="see_me",
        issued_at=_iso(now),
        expires_at=_iso(now + timedelta(days=1)),
        key_id=signer.key_id,
    )
    envelope = signer.sign_claims(pollen.to_claims())
    verified = verifier.verify_envelope(envelope, public_key_raw=public_raw)
    assert RelationPollen.from_claims(verified) == pollen


# ----------------------------------------------------------------------
# Sign + verify — negative paths
# ----------------------------------------------------------------------


def test_verify_with_wrong_public_key_fails(signer, verifier):
    pollen = _fresh_identity(key_id=signer.key_id)
    envelope = signer.sign_claims(pollen.to_claims())

    _, other_public_raw = generate_issuer_keypair()
    with pytest.raises(PollenVerificationError) as exc_info:
        verifier.verify_envelope(envelope, public_key_raw=other_public_raw)
    assert exc_info.value.reason == "signature_mismatch"


def test_verify_with_tampered_claims_fails(signer, verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    pollen = _fresh_identity(key_id=signer.key_id)
    envelope = signer.sign_claims(pollen.to_claims())

    # Tamper with the claims after signing
    envelope["claims"]["trust_tier"] = 6
    with pytest.raises(PollenVerificationError) as exc_info:
        verifier.verify_envelope(envelope, public_key_raw=public_raw)
    assert exc_info.value.reason == "signature_mismatch"


def test_verify_with_tampered_signature_fails(signer, verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    pollen = _fresh_identity(key_id=signer.key_id)
    envelope = signer.sign_claims(pollen.to_claims())

    # Corrupt one byte of the signature (keep length valid)
    sig = envelope["signature"]
    # base64url flip the first char
    flipped = ("B" if sig[0] != "B" else "C") + sig[1:]
    envelope["signature"] = flipped
    with pytest.raises(PollenVerificationError):
        verifier.verify_envelope(envelope, public_key_raw=public_raw)


def test_verify_malformed_envelope_missing_claims(verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    with pytest.raises(PollenVerificationError) as exc_info:
        verifier.verify_envelope({"signature": "abc"}, public_key_raw=public_raw)
    assert exc_info.value.reason == "missing_claims"


def test_verify_malformed_envelope_missing_signature(verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    with pytest.raises(PollenVerificationError) as exc_info:
        verifier.verify_envelope({"claims": {"x": 1}}, public_key_raw=public_raw)
    assert exc_info.value.reason == "missing_signature"


def test_verify_malformed_envelope_not_a_dict(verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    with pytest.raises(PollenVerificationError) as exc_info:
        verifier.verify_envelope("not a dict", public_key_raw=public_raw)  # type: ignore[arg-type]
    assert exc_info.value.reason == "malformed_envelope"


def test_verify_bad_signature_encoding(verifier, issuer_keypair):
    _, public_raw = issuer_keypair
    envelope = {"claims": {"x": 1}, "signature": "!!!not-base64-url!!!"}
    with pytest.raises(PollenVerificationError):
        verifier.verify_envelope(envelope, public_key_raw=public_raw)


# ----------------------------------------------------------------------
# End-to-end — the full shape P2 will use
# ----------------------------------------------------------------------


def test_full_roundtrip_sign_to_wire_to_verify_to_claims(signer, verifier, issuer_keypair):
    """The end-to-end flow pollen uses:
    pollen → claims → sign → JSON-serialize → [wire] → JSON-deserialize → verify → claims → pollen.
    """
    _, public_raw = issuer_keypair
    original = _fresh_identity(trust_tier=5, key_id=signer.key_id)

    # Producer side
    envelope = signer.sign_claims(original.to_claims())
    wire_bytes = json.dumps(envelope).encode("utf-8")

    # Consumer side
    received = json.loads(wire_bytes.decode("utf-8"))
    verified_claims = verifier.verify_envelope(received, public_key_raw=public_raw)
    rebuilt = IdentityPollen.from_claims(verified_claims)

    assert rebuilt == original
    rebuilt.check_not_expired()  # still valid


def test_signer_key_id_matches_computed_key_id(signer, issuer_keypair):
    _, public_raw = issuer_keypair
    assert signer.key_id == compute_key_id(public_raw)


def test_two_signers_with_different_keys_produce_different_signatures(issuer_keypair):
    private_pem_a, _ = issuer_keypair
    private_pem_b, _ = generate_issuer_keypair()
    signer_a = PollenSigner(private_key_pem=private_pem_a)
    signer_b = PollenSigner(private_key_pem=private_pem_b)

    claims = _fresh_identity(key_id=signer_a.key_id).to_claims()
    env_a = signer_a.sign_claims(claims)
    env_b = signer_b.sign_claims(claims)
    assert env_a["signature"] != env_b["signature"]


# ----------------------------------------------------------------------
# schema_version — easy-now-painful-later guard
# ----------------------------------------------------------------------


def test_identity_pollen_carries_schema_version_in_claims():
    pollen = _fresh_identity()
    claims = pollen.to_claims()
    assert claims["schema_version"] == 1


def test_membership_pollen_carries_schema_version_in_claims():
    from datetime import datetime, timedelta, timezone

    now = datetime.now(timezone.utc)
    pollen = MembershipPollen(
        callsign="burr", space_id="pair_x", role="member",
        joined_at=_iso(now), issued_at=_iso(now),
        expires_at=_iso(now + timedelta(hours=1)),
        issuer="whispers-daemon", key_id="k1",
    )
    assert pollen.to_claims()["schema_version"] == 1


def test_relation_pollen_carries_schema_version_in_claims():
    from datetime import datetime, timedelta, timezone

    now = datetime.now(timezone.utc)
    pollen = RelationPollen(
        from_callsign="flux", to_callsign="burr", affordance="see_me",
        issued_at=_iso(now), expires_at=_iso(now + timedelta(days=1)),
        key_id="k1",
    )
    assert pollen.to_claims()["schema_version"] == 1


def test_from_claims_accepts_missing_schema_version_for_back_compat():
    """Pollen issued by a transitional code path that hasn't started
    emitting schema_version yet should still parse — default = current.
    """
    pollen = _fresh_identity()
    claims = pollen.to_claims()
    claims.pop("schema_version")
    rebuilt = IdentityPollen.from_claims(claims)
    assert rebuilt.schema_version == 1


def test_from_claims_rejects_future_schema_version():
    """Verifier from before a breaking schema bump must fail closed."""
    pollen = _fresh_identity()
    claims = pollen.to_claims()
    claims["schema_version"] = 99  # future version this verifier doesn't know
    with pytest.raises(PollenVerificationError) as exc_info:
        IdentityPollen.from_claims(claims)
    assert exc_info.value.reason == "unsupported_schema_version"


def test_from_claims_rejects_non_integer_schema_version():
    pollen = _fresh_identity()
    claims = pollen.to_claims()
    claims["schema_version"] = "not-a-number"
    with pytest.raises(PollenVerificationError) as exc_info:
        IdentityPollen.from_claims(claims)
    assert exc_info.value.reason == "bad_schema_version"


def test_signed_envelope_carries_schema_version_through_round_trip(
    signer, verifier, issuer_keypair
):
    _, public_raw = issuer_keypair
    pollen = _fresh_identity(key_id=signer.key_id)
    envelope = signer.sign_claims(pollen.to_claims())

    # The schema_version is part of the signed claims — tampering with
    # it after signing must fail signature verification.
    envelope["claims"]["schema_version"] = 2
    with pytest.raises(PollenVerificationError) as exc_info:
        verifier.verify_envelope(envelope, public_key_raw=public_raw)
    assert exc_info.value.reason == "signature_mismatch"
