from __future__ import annotations

from whispers.drive_signals import (
    DriveCue,
    derive_drive_cues,
    summarize_drive_cues,
)


def test_summarize_drive_cues_prefers_approach_when_fit_is_strong():
    cues = [
        DriveCue("approach", "fit", 0.8, "strong fit for task"),
        DriveCue("approach", "cost", 0.4, "cheap sufficient route"),
        DriveCue("avoid", "overload", 0.2, "slight interruption cost"),
    ]
    assessment = summarize_drive_cues(cues)
    assert assessment.dominant_polarity == "approach"
    assert assessment.recommended_action == "prefer"
    assert "strong fit for task" in assessment.reasons


def test_summarize_drive_cues_recoils_from_strong_avoid_signal():
    cues = [
        DriveCue("approach", "novelty", 0.4, "new capability may help"),
        DriveCue("avoid", "boundary_breach", 0.9, "scope widening without approval"),
    ]
    assessment = summarize_drive_cues(cues)
    assert assessment.dominant_polarity == "avoid"
    assert assessment.recommended_action == "recoil"


def test_summarize_drive_cues_escalates_high_unknown_investigation_need():
    cues = [
        DriveCue("investigate", "unknown_agent", 0.8, "new participant with unclear differentiator"),
    ]
    assessment = summarize_drive_cues(cues)
    assert assessment.dominant_polarity == "investigate"
    assert assessment.recommended_action == "escalate"


# -----------------------------------------------------------------------------
# derive_drive_cues — the derivation pass that turns context primitives into
# DriveCues. These tests match the theory doc §3 signal families.
# -----------------------------------------------------------------------------


class TestDeriveDriveCuesEmptyInputs:
    def test_no_inputs_returns_empty_list(self):
        assert derive_drive_cues() == []

    def test_all_none_inputs_are_safe(self):
        out = derive_drive_cues(
            recent_messages=None,
            pending_obligations=None,
            residue=None,
            recent_scope_events=None,
        )
        assert out == []

    def test_empty_iterables_are_safe(self):
        out = derive_drive_cues(
            recent_messages=[],
            pending_obligations=[],
            residue=[],
            recent_scope_events=[],
        )
        assert out == []


class TestOverloadCues:
    def test_three_unread_flash_obligations_fires_avoid_overload(self):
        pending = [
            {"kind": "flash_awaiting", "from": "a", "subject": "x"},
            {"kind": "flash_awaiting", "from": "b", "subject": "y"},
            {"kind": "flash_awaiting", "from": "c", "subject": "z"},
        ]
        out = derive_drive_cues(pending_obligations=pending)
        avoid = [c for c in out if c["polarity"] == "avoid"]
        assert avoid, f"expected avoid cue, got {out}"
        assert any(c["cue_kind"] == "attention_overload" for c in avoid)

    def test_two_flash_does_not_fire_overload(self):
        """Threshold is 3 — two pending flash stays below the overload bar."""
        pending = [
            {"kind": "flash_awaiting", "from": "a", "subject": "x"},
            {"kind": "flash_awaiting", "from": "b", "subject": "y"},
        ]
        out = derive_drive_cues(pending_obligations=pending)
        assert not any(c["cue_kind"] == "attention_overload" for c in out)

    def test_mixed_priority_backlog_fires_without_flash_overload(self):
        """5+ unread priority messages (no flash overload) triggers backlog cue."""
        pending = [
            {"kind": "flash_awaiting", "from": "a", "subject": "x"},
            {"kind": "priority_awaiting", "from": "b", "subject": "y"},
            {"kind": "priority_awaiting", "from": "c", "subject": "z"},
            {"kind": "priority_awaiting", "from": "d", "subject": "w"},
            {"kind": "priority_awaiting", "from": "e", "subject": "v"},
        ]
        out = derive_drive_cues(pending_obligations=pending)
        assert any(c["cue_kind"] == "priority_backlog" for c in out)

    def test_overload_intensity_scales_with_count(self):
        """More pending flashes → higher intensity, capped at 1.0."""
        many = [{"kind": "flash_awaiting", "from": f"a{i}", "subject": "x"} for i in range(8)]
        out = derive_drive_cues(pending_obligations=many)
        overload = next(c for c in out if c["cue_kind"] == "attention_overload")
        assert overload["intensity"] >= 0.9


class TestResidueCues:
    def test_aversive_residue_pattern_fires_avoid(self):
        residue = [
            {"pattern": "build failed", "pattern_count": 5},
            {"pattern": "test error", "pattern_count": 4},
        ]
        out = derive_drive_cues(residue=residue)
        avoid_patterns = [c for c in out if c["cue_kind"] == "stale_or_failing_pattern"]
        assert len(avoid_patterns) == 2
        assert all(c["polarity"] == "avoid" for c in avoid_patterns)

    def test_appetitive_residue_pattern_fires_approach(self):
        residue = [
            {"pattern": "slice shipped", "pattern_count": 4},
            {"pattern": "tests passing", "pattern_count": 3},
        ]
        out = derive_drive_cues(residue=residue)
        approach_patterns = [c for c in out if c["cue_kind"] == "productive_rhythm"]
        assert len(approach_patterns) == 2
        assert all(c["polarity"] == "approach" for c in approach_patterns)

    def test_neutral_residue_does_not_fire(self):
        """Patterns that aren't in the aversive or appetitive vocabulary are silent."""
        residue = [
            {"pattern": "zack said", "pattern_count": 5},
            {"pattern": "whispers project", "pattern_count": 4},
        ]
        out = derive_drive_cues(residue=residue)
        residue_cues = [c for c in out if c.get("basis") == "residue"]
        assert residue_cues == []

    def test_higher_repetition_raises_intensity(self):
        low = derive_drive_cues(residue=[{"pattern": "build failed", "pattern_count": 2}])
        high = derive_drive_cues(residue=[{"pattern": "build failed", "pattern_count": 7}])
        low_intensity = low[0]["intensity"]
        high_intensity = high[0]["intensity"]
        assert high_intensity > low_intensity


class TestNovelSenderCues:
    def test_message_from_unknown_sender_fires_investigate(self):
        msgs = [{"from": "stranger", "to": "me", "subject": "hi"}]
        out = derive_drive_cues(
            recent_messages=msgs,
            self_callsign="me",
            known_peers=["ally", "mate"],
        )
        assert any(c["cue_kind"] == "novel_sender" and c["polarity"] == "investigate" for c in out)

    def test_message_from_known_peer_does_not_fire_novel_sender(self):
        msgs = [{"from": "ally", "to": "me", "subject": "ping"}]
        out = derive_drive_cues(
            recent_messages=msgs,
            self_callsign="me",
            known_peers=["ally", "mate"],
        )
        assert not any(c["cue_kind"] == "novel_sender" for c in out)

    def test_self_messages_do_not_fire_novel_sender(self):
        """Messages from self should never trigger a novel-sender cue."""
        msgs = [{"from": "me", "to": "ally", "subject": "thinking out loud"}]
        out = derive_drive_cues(
            recent_messages=msgs,
            self_callsign="me",
            known_peers=["ally"],
        )
        assert not any(c["cue_kind"] == "novel_sender" for c in out)

    def test_multiple_messages_from_same_novel_sender_dedupe(self):
        msgs = [
            {"from": "stranger", "to": "me", "subject": "x"},
            {"from": "stranger", "to": "me", "subject": "y"},
            {"from": "stranger", "to": "me", "subject": "z"},
        ]
        out = derive_drive_cues(
            recent_messages=msgs,
            self_callsign="me",
            known_peers=["ally"],
        )
        novel = [c for c in out if c["cue_kind"] == "novel_sender"]
        assert len(novel) == 1


class TestApproachSignals:
    def test_active_scope_fires_on_multiple_events(self):
        events = [
            {"kind": "lifecycle", "subject": "joined"},
            {"kind": "lifecycle", "subject": "joined"},
            {"kind": "message", "subject": "exchanged"},
        ]
        out = derive_drive_cues(recent_scope_events=events)
        assert any(c["cue_kind"] == "active_scope" and c["polarity"] == "approach" for c in out)

    def test_single_event_does_not_fire_active_scope(self):
        """Threshold is 2 — one scope event is not a rhythm."""
        events = [{"kind": "lifecycle", "subject": "joined"}]
        out = derive_drive_cues(recent_scope_events=events)
        assert not any(c["cue_kind"] == "active_scope" for c in out)


class TestCueOrderingAndBudget:
    def test_cues_sorted_by_intensity_desc(self):
        out = derive_drive_cues(
            pending_obligations=[{"kind": "flash_awaiting", "from": f"a{i}"} for i in range(5)],
            residue=[{"pattern": "slice shipped", "pattern_count": 3}],
        )
        intensities = [c["intensity"] for c in out]
        assert intensities == sorted(intensities, reverse=True)

    def test_budget_caps_output(self):
        """Many cues beyond budget are truncated to the cap."""
        # Aversive residue patterns that actually tokenize into our trigger set
        # (the splitter is whitespace-only, so each bigram needs a real trigger word).
        aversive_words = ["error", "failed", "broken", "stale", "timeout", "blocked"]
        residue = [
            {"pattern": f"{w} step-{i}", "pattern_count": 3 + i}
            for i, w in enumerate(aversive_words * 4)
        ]
        out = derive_drive_cues(residue=residue, budget=3)
        assert len(out) == 3

    def test_cues_are_json_serializable_dicts(self):
        """The derived list must be capsule-ready (dict form, not dataclass)."""
        import json

        out = derive_drive_cues(
            pending_obligations=[{"kind": "flash_awaiting", "from": "a"} for _ in range(3)],
        )
        serialized = json.dumps(out)
        assert isinstance(serialized, str)
        # Each cue carries the expected shape.
        for cue in out:
            assert set(cue.keys()) >= {"polarity", "cue_kind", "intensity", "reason", "basis"}


class TestDerivationEndToEnd:
    def test_summarize_roundtrip_from_derived_cues(self):
        """Derived cues can be rehydrated into DriveCue and fed to summarize_drive_cues."""
        out = derive_drive_cues(
            pending_obligations=[{"kind": "flash_awaiting", "from": f"a{i}"} for i in range(4)],
            residue=[{"pattern": "build failed", "pattern_count": 5}],
        )
        rehydrated = [
            DriveCue(c["polarity"], c["cue_kind"], c["intensity"], c["reason"], c.get("basis"))
            for c in out
        ]
        assessment = summarize_drive_cues(rehydrated)
        assert assessment.dominant_polarity == "avoid"
        assert assessment.recommended_action in {"recoil", "protect"}
