"""ListenerEngine unit tests (W0 — active-listening v6).

The engine consumes SSE from `/wake/<callsign>/stream`. Tests stand up a
tiny loopback HTTPServer that speaks SSE in the shape the real server
emits (wake + peer_delta events), then assert the engine:

  * Parses both event kinds and tags them correctly.
  * Runs the kill-switch -> policy -> safety -> handler pipeline in order.
  * Stops cleanly when cancelled.
  * Survives handler exceptions.
  * Respects deliver_peer_deltas=False.
"""

from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, Dict, List, Optional

import pytest

from whispers.listeners import (
    LoopDetected,
    RateLimitExceeded,
    SafetyGuardrails,
    WakePolicy,
)
from whispers.listeners.engine import ListenerEngine, StreamEvent


# ----------------------------------------------------------------------
# Test fixtures — tiny SSE emitter
# ----------------------------------------------------------------------


class _SSEEmitter:
    """Drives a loopback HTTPServer that emits queued SSE events.

    Tests push `(event_type, payload, event_id)` triples via `.emit(...)`.
    The HTTP handler serves any connected client those events in order
    and then holds the connection open briefly so the engine can cancel
    cleanly.
    """

    def __init__(self) -> None:
        self.queue: List[Dict[str, Any]] = []
        self.lock = threading.Lock()
        self.close_after_drain = threading.Event()
        self.served_requests = 0

    def emit(
        self,
        event_type: str,
        payload: Dict[str, Any],
        event_id: Optional[int] = None,
    ) -> None:
        with self.lock:
            self.queue.append(
                {"event": event_type, "payload": payload, "id": event_id}
            )


def _make_server(emitter: _SSEEmitter) -> HTTPServer:
    class _Handler(BaseHTTPRequestHandler):
        def log_message(self, *args: Any, **kwargs: Any) -> None:
            return

        def do_GET(self) -> None:
            if "/wake/" not in self.path or "/stream" not in self.path:
                self.send_response(404)
                self.end_headers()
                return

            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            emitter.served_requests += 1
            try:
                self.wfile.write(b": connected\n\n")
                self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, OSError):
                return

            deadline = time.time() + 5.0
            while time.time() < deadline:
                with emitter.lock:
                    pending = list(emitter.queue)
                    emitter.queue.clear()

                for item in pending:
                    lines: List[str] = []
                    if item["event"] != "message":
                        lines.append(f"event: {item['event']}")
                    if item["id"] is not None:
                        lines.append(f"id: {item['id']}")
                    data_blob = json.dumps(item["payload"])
                    lines.append(f"data: {data_blob}")
                    blob = ("\n".join(lines) + "\n\n").encode("utf-8")
                    try:
                        self.wfile.write(blob)
                        self.wfile.flush()
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        return

                if emitter.close_after_drain.is_set():
                    return
                time.sleep(0.05)

    server = HTTPServer(("127.0.0.1", 0), _Handler)
    return server


@pytest.fixture
def sse_server():
    emitter = _SSEEmitter()
    server = _make_server(emitter)
    port = server.server_address[1]
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield emitter, f"http://127.0.0.1:{port}"
    finally:
        emitter.close_after_drain.set()
        server.shutdown()
        server.server_close()


# ----------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------


def _wait_for(pred, timeout: float = 2.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        if pred():
            return True
        time.sleep(0.02)
    return False


def _wake_payload(
    *,
    priority: str = "routine",
    msg_type: str = "inform",
    body: str = "hello",
    sender: str = "peer-a",
) -> Dict[str, Any]:
    """Shape of a wake event body as emitted by the real server.

    Real server emits {"payload": {"packet": {...message...}, ...}}.
    The engine hoists payload.payload-or-self to event.payload.
    """
    return {
        "event_id": 0,
        "payload": {
            "packet": {
                "priority": priority,
                "msg_type": msg_type,
                "body": body,
                "sender": sender,
                "subject": "test",
            }
        },
    }


# ----------------------------------------------------------------------
# Tests
# ----------------------------------------------------------------------


def test_engine_dispatches_wake_event(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    def handler(event: StreamEvent) -> None:
        received.append(event)

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=handler,
    )
    engine.start()
    try:
        emitter.emit("wake", _wake_payload(body="hello"), event_id=1)
        assert _wait_for(lambda: len(received) >= 1, timeout=3.0)
    finally:
        engine.stop()
    assert received[0].kind == "wake"
    assert received[0].body == "hello"
    assert received[0].event_id == 1


def test_engine_dispatches_peer_delta_event(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    def handler(event: StreamEvent) -> None:
        received.append(event)

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=handler,
    )
    engine.start()
    try:
        emitter.emit(
            "peer_delta",
            {"kind": "peer_bound", "callsign": "new-peer", "trust_tier": 5},
        )
        assert _wait_for(lambda: len(received) >= 1, timeout=3.0)
    finally:
        engine.stop()
    assert received[0].kind == "peer_delta"
    assert received[0].payload.get("callsign") == "new-peer"


def test_peer_deltas_skipped_when_disabled(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: received.append(e),
        deliver_peer_deltas=False,
    )
    engine.start()
    try:
        emitter.emit("peer_delta", {"kind": "peer_bound", "callsign": "ignored"})
        emitter.emit("wake", _wake_payload(body="kept"), event_id=2)
        assert _wait_for(lambda: len(received) >= 1, timeout=3.0)
        time.sleep(0.3)  # let any stray peer_delta arrive
    finally:
        engine.stop()
    assert len(received) == 1
    assert received[0].kind == "wake"
    assert received[0].body == "kept"


def test_kill_switch_halts_engine(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: received.append(e),
    )
    engine.start()
    try:
        emitter.emit(
            "wake",
            _wake_payload(priority="system", msg_type="halt", body="halt"),
            event_id=1,
        )
        assert _wait_for(lambda: not engine.is_running(), timeout=3.0)
    finally:
        engine.stop()

    assert not engine.is_running()
    # Handler must NOT have been invoked — kill-switch short-circuits.
    assert received == []


def test_policy_blocks_dispatch(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    class DenyAll(WakePolicy):
        def evaluate(self, event):
            return False

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: received.append(e),
        policy=DenyAll(),
    )
    engine.start()
    try:
        emitter.emit("wake", _wake_payload(body="filtered"), event_id=1)
        time.sleep(0.5)
    finally:
        engine.stop()
    assert received == []


def test_policy_allows_dispatch(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    class AddressedToMe(WakePolicy):
        def evaluate(self, event):
            payload = event.get("payload", {})
            packet = payload.get("packet") if isinstance(payload, dict) else {}
            return str(packet.get("to", "")).lower() == "tester"

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: received.append(e),
        policy=AddressedToMe(),
    )
    engine.start()
    try:
        # First event: NOT for us -> dropped
        wrong = _wake_payload(body="not-for-me")
        wrong["payload"]["packet"]["to"] = "somebody-else"
        emitter.emit("wake", wrong, event_id=1)
        # Second event: for us -> kept
        right = _wake_payload(body="for-me")
        right["payload"]["packet"]["to"] = "tester"
        emitter.emit("wake", right, event_id=2)
        assert _wait_for(lambda: len(received) >= 1, timeout=3.0)
        time.sleep(0.3)
    finally:
        engine.stop()
    assert len(received) == 1
    assert received[0].body == "for-me"


def test_safety_rate_limit_blocks(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    class RateLimiter(SafetyGuardrails):
        def __init__(self):
            self.calls = 0

        def verify(self, event):
            self.calls += 1
            if self.calls > 1:
                raise RateLimitExceeded("cap=1/hour")

    safety = RateLimiter()
    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: received.append(e),
        safety=safety,
    )
    engine.start()
    try:
        emitter.emit("wake", _wake_payload(body="first"), event_id=1)
        emitter.emit("wake", _wake_payload(body="second"), event_id=2)
        assert _wait_for(lambda: len(received) >= 1, timeout=3.0)
        time.sleep(0.4)
    finally:
        engine.stop()
    assert len(received) == 1
    assert received[0].body == "first"


def test_safety_loop_detect_blocks(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    class LoopDetector(SafetyGuardrails):
        def verify(self, event):
            raise LoopDetected("self-reply loop")

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: received.append(e),
        safety=LoopDetector(),
    )
    engine.start()
    try:
        emitter.emit("wake", _wake_payload(body="loopy"), event_id=1)
        time.sleep(0.5)
    finally:
        engine.stop()
    assert received == []


def test_handler_exception_does_not_kill_engine(sse_server):
    emitter, server_url = sse_server
    calls = {"count": 0}

    def broken_handler(event: StreamEvent) -> None:
        calls["count"] += 1
        if calls["count"] == 1:
            raise RuntimeError("boom")

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=broken_handler,
    )
    engine.start()
    try:
        emitter.emit("wake", _wake_payload(body="first"), event_id=1)
        assert _wait_for(lambda: calls["count"] >= 1, timeout=3.0)
        assert engine.is_running()
        emitter.emit("wake", _wake_payload(body="second"), event_id=2)
        assert _wait_for(lambda: calls["count"] >= 2, timeout=3.0)
    finally:
        engine.stop()
    assert calls["count"] == 2
    assert not engine.is_running()


def test_engine_stops_cleanly(sse_server):
    emitter, server_url = sse_server

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: None,
    )
    engine.start()
    assert engine.is_running()
    engine.stop(timeout=2.0)
    assert not engine.is_running()


def test_start_twice_raises(sse_server):
    _, server_url = sse_server

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: None,
    )
    engine.start()
    try:
        with pytest.raises(RuntimeError):
            engine.start()
    finally:
        engine.stop()


def test_tracks_last_event_id(sse_server):
    emitter, server_url = sse_server
    received: List[StreamEvent] = []

    engine = ListenerEngine(
        server_url=server_url,
        callsign="tester",
        handler=lambda e: received.append(e),
    )
    engine.start()
    try:
        emitter.emit("wake", _wake_payload(body="a"), event_id=10)
        emitter.emit("wake", _wake_payload(body="b"), event_id=17)
        assert _wait_for(lambda: len(received) >= 2, timeout=3.0)
        time.sleep(0.2)
    finally:
        engine.stop()
    assert engine.last_event_id == 17
