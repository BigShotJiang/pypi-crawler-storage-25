from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import threading
import time
import urllib.request
from contextlib import contextmanager
from pathlib import Path

import uvicorn

import whispers.terminal_actuator as terminal_actuator
from whispers.server import create_app
from whispers.testing import WhispersTestHarness
from whispers.twoack import DEFAULT_SCHEMA, WIRE_V, validate_envelope


@contextmanager
def _running_server(db_path: str):
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]

    app = create_app(db_path=db_path)
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    try:
        for _ in range(50):
            if server.started:
                break
            time.sleep(0.1)
        else:
            raise AssertionError("uvicorn server did not start in time")
        yield port
    finally:
        server.should_exit = True
        thread.join(timeout=5)



def _post_json(base_url: str, path: str, payload: dict[str, object]) -> dict[str, object]:
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        f"{base_url}{path}",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        assert response.status == 200
        return json.loads(response.read().decode("utf-8"))



def test_profile_name_and_context_hint_include_session_scope(tmp_path):
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    profile_name = terminal_actuator.build_terminal_profile_name(
        harness="pi",
        role="session",
        mode="work",
        preset="default",
        workspace_root=str(workspace),
        session_discriminator="sess1234",
    )
    context_hint = terminal_actuator.build_terminal_context_hint(
        identity_platform="plain_terminal",
        harness="pi",
        role="session",
        mode="work",
        preset="default",
        workspace_root=str(workspace),
        session_discriminator="sess1234",
    )

    assert profile_name.startswith("terminal.pi.workspace.")
    assert ".work.default.session.session.sess1234" in profile_name
    assert context_hint.startswith("plain_terminal/session:pi:workspace:")
    assert context_hint.endswith(":work:default:session:sid:sess1234")



def test_ensure_terminal_actuator_reuses_session_binding_without_companion(tmp_path, monkeypatch):
    workspace = tmp_path / "repo"
    workspace.mkdir()
    state_dir = tmp_path / "state"
    monkeypatch.setenv("WHISPERS_TERMINAL_ACTUATOR_STATE_DIR", str(state_dir))
    monkeypatch.setattr(terminal_actuator, "generate_callsign", lambda: "reed-river")

    with WhispersTestHarness() as h:
        with _running_server(h.db_path) as port:
            base_url = f"http://127.0.0.1:{port}"
            first = terminal_actuator.ensure_terminal_actuator(
                harness="pi",
                role="session",
                workspace_root=str(workspace),
                server_url=base_url,
                session_discriminator="sess1234",
                jolt_adapter_kind="managed_pty",
                jolt_can_notify=True,
                jolt_can_stage_context=True,
            )
            second = terminal_actuator.ensure_terminal_actuator(
                harness="pi",
                role="session",
                workspace_root=str(workspace),
                server_url=base_url,
                session_discriminator="sess1234",
                jolt_adapter_kind="managed_pty",
                jolt_can_notify=True,
                jolt_can_stage_context=True,
            )

            assert first.agent_name == "reed-river"
            assert first.agent_name == second.agent_name
            assert first.profile_name == second.profile_name
            assert first.session_discriminator == "sess1234"
            assert first.session_id
            assert first.session_id == second.session_id
            assert first.bootstrap_status == "bound"
            assert first.companion_pid is None
            assert first.env()["WHISPERS_BINDING_KIND"] == "interactive_session"
            assert first.env()["WHISPERS_SESSION_DISCRIMINATOR"] == "sess1234"



def test_ensure_terminal_actuator_starts_and_reuses_local_wake_companion(tmp_path, monkeypatch):
    workspace = tmp_path / "repo"
    workspace.mkdir()
    state_dir = tmp_path / "state"
    monkeypatch.setenv("WHISPERS_TERMINAL_ACTUATOR_STATE_DIR", str(state_dir))
    monkeypatch.setattr(terminal_actuator, "generate_callsign", lambda: "reed-river")

    with WhispersTestHarness() as h:
        with _running_server(h.db_path) as port:
            base_url = f"http://127.0.0.1:{port}"
            first = terminal_actuator.ensure_terminal_actuator(
                harness="pi",
                role="session",
                workspace_root=str(workspace),
                server_url=base_url,
                session_discriminator="sesswake1",
                jolt_adapter_kind="local_http_connector",
                jolt_can_notify=True,
                jolt_can_stage_context=True,
                jolt_can_trigger_inference=True,
            )
            try:
                assert first.bootstrap_status == "bound_with_local_wake"
                assert first.companion_status == "started_companion"
                assert first.companion_pid is not None
                assert first.companion_endpoint_url
                assert first.env()["WHISPERS_LOCAL_WAKE_COMPANION_PID"] == str(first.companion_pid)
                assert first.env()["WHISPERS_LOCAL_WAKE_ENDPOINT_URL"] == first.companion_endpoint_url

                second = terminal_actuator.ensure_terminal_actuator(
                    harness="pi",
                    role="session",
                    workspace_root=str(workspace),
                    server_url=base_url,
                    session_discriminator="sesswake1",
                    jolt_adapter_kind="local_http_connector",
                    jolt_can_notify=True,
                    jolt_can_stage_context=True,
                    jolt_can_trigger_inference=True,
                )
                assert second.agent_name == first.agent_name
                assert second.profile_name == first.profile_name
                assert second.companion_status == "reused_companion"
                assert second.companion_pid == first.companion_pid

                _post_json(base_url, "/identity/connect", {"requested_callsign": "alice"})
                _post_json(
                    base_url,
                    "/messages/send",
                    {"sender": "alice", "recipient": first.agent_name, "subject": "Need review", "body": "please check"},
                )
                dispatched = _post_json(base_url, f"/wake/{first.agent_name}/dispatch", {})
                assert dispatched["event"]["dispatch_status"] == "dispatched"
                assert dispatched["packet"]["wire_v"] == WIRE_V
                assert dispatched["packet"]["schema"] == DEFAULT_SCHEMA
                assert validate_envelope(dispatched["packet"]) == []
            finally:
                terminal_actuator.stop_terminal_companion(first.profile_name)



def test_cli_ensure_matches_pi_contract_and_reuses_session_child(tmp_path):
    workspace = tmp_path / "repo"
    workspace.mkdir()
    state_dir = tmp_path / "state"
    repo_root = Path(__file__).resolve().parents[1]

    with WhispersTestHarness() as h:
        with _running_server(h.db_path) as port:
            base_url = f"http://127.0.0.1:{port}"
            env = os.environ.copy()
            env["WHISPERS_TERMINAL_ACTUATOR_STATE_DIR"] = str(state_dir)
            env["WT_SESSION"] = "wtsession1234"
            args = [
                sys.executable,
                "-m",
                "whispers.terminal_actuator",
                "ensure",
                "--harness",
                "pi",
                "--role",
                "session",
                "--mode",
                "work",
                "--preset",
                "default",
                "--workspace-root",
                str(workspace),
                "--server-url",
                base_url,
                "--agent-type",
                "script",
                "--display-name",
                "Pi Session",
                "--identity-platform",
                "plain_terminal",
                "--jolt-host-kind",
                "plain_terminal",
                "--jolt-adapter-kind",
                "local_http_connector",
                "--jolt-can-notify",
                "true",
                "--jolt-can-stage-context",
                "true",
                "--jolt-can-trigger-inference",
                "true",
                "--json-output",
            ]
            first = subprocess.run(args, cwd=str(repo_root), env=env, capture_output=True, text=True, check=True)
            first_payload = json.loads(first.stdout)
            try:
                second = subprocess.run(args, cwd=str(repo_root), env=env, capture_output=True, text=True, check=True)
                second_payload = json.loads(second.stdout)

                assert first_payload["agent_name"] == second_payload["agent_name"]
                assert first_payload["profile_name"] == second_payload["profile_name"]
                assert first_payload["session_id"] == second_payload["session_id"]
                assert first_payload["session_discriminator"] == "wtsession1234"
                assert second_payload["companion_status"] == "reused_companion"

                binding_env = first_payload["env"]
                assert binding_env["WHISPERS_AGENT_NAME"] == first_payload["agent_name"]
                assert binding_env["WHISPERS_CALLSIGN"] == first_payload["agent_name"]
                assert binding_env["WW_AGENT_NAME"] == first_payload["agent_name"]
                assert binding_env["WW_PROFILE_NAME"] == first_payload["profile_name"]
                assert binding_env["WHISPERS_BINDING_KIND"] == "interactive_session"
                assert binding_env["WHISPERS_IDENTITY_PLATFORM"] == "plain_terminal"
                assert binding_env["WHISPERS_JOLT_HOST_KIND"] == "plain_terminal"
                assert binding_env["WHISPERS_JOLT_ADAPTER_KIND"] == "local_http_connector"
                assert binding_env["WHISPERS_JOLT_CAN_NOTIFY"] == "true"
                assert binding_env["WHISPERS_JOLT_CAN_STAGE_CONTEXT"] == "true"
                assert binding_env["WHISPERS_JOLT_CAN_TRIGGER_INFERENCE"] == "true"
                assert binding_env["WHISPERS_SESSION_DISCRIMINATOR"] == "wtsession1234"
                assert binding_env["WHISPERS_IDENTITY_CONTEXT_HINT"].endswith(":sid:wtsession1234")
                assert binding_env["WHISPERS_LOCAL_WAKE_COMPANION_PID"] == str(first_payload["companion_pid"])
                assert binding_env["WHISPERS_LOCAL_WAKE_ENDPOINT_URL"] == first_payload["companion_endpoint_url"]
            finally:
                terminal_actuator.stop_terminal_companion(first_payload["profile_name"])
