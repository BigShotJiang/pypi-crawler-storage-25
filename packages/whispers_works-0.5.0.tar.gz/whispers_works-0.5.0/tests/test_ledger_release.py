"""Slice 5.5 — ledger release acceptance tests.

Covers the `release_callsign()` admin helper + `whispers ledger release <callsign>`
CLI command that unblock rebinding an orphaned callsign (no live session,
prior card gone or stale, but the callsign_ledger row still reserving it).

Context: STARTUP-MECHANICS-OVERHAUL-2026-04-17.md §2 (stack A/B split) names
"nobody's job" as the root cause of partial-bind states. Today's failure mode
is narrower and more painful: after a prior session closes, its callsign
becomes unrebinddable because `get_callsign_ledger_entry()` returns the
row regardless of status, so `continuity.py` rejects the new bind as
"reserved by another participant history." No CLI, no MCP tool exists to
release the reservation. Operators end up editing SQLite by hand — the exact
"operator is the relay" failure the overhaul is meant to eliminate.

Run: pytest tests/test_ledger_release.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.storage.db import WhispersDB


def _seed_retired_burr(db_path: str, *, with_session: bool = False) -> None:
    """Seed a db with a callsign_ledger row, orphan agent_card, and optional session."""
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            "INSERT INTO agent_cards (agent_id, callsign, trust_tier, platform_family, "
            "stable_subject_id, continuity_anchor) VALUES (?, ?, ?, ?, ?, ?)",
            ("agent-burr-1", "burr", 5, "claude-code", "subj-burr-1", "anchor:old"),
        )
        conn.execute(
            "INSERT INTO callsign_ledger (callsign, stable_subject_id, agent_id, status, "
            "first_seen_at, last_bound_at) VALUES (?, ?, ?, 'current', "
            "datetime('now','-1 hour'), datetime('now','-1 hour'))",
            ("burr", "subj-burr-1", "agent-burr-1"),
        )
        if with_session:
            conn.execute(
                "INSERT INTO agent_sessions (session_id, agent_id, agent_name, session_kind, "
                "created_at, last_seen_at, lease_expires_at) VALUES (?, ?, ?, 'mcp_http', "
                "datetime('now'), datetime('now'), datetime('now','+30 minutes'))",
                ("sess-live", "agent-burr-1", "burr"),
            )
        conn.commit()
    finally:
        conn.close()


class TestReleaseCallsign:
    """release_callsign() unblocks rebind by clearing ledger + orphan card + presence."""

    def test_release_orphan_callsign_succeeds(self, tmp_path):
        """A callsign with a card + ledger row but no live sessions can be released.

        After release, a fresh bind_seat for the same callsign must succeed —
        which in practice means the callsign_ledger row is gone (so
        get_callsign_ledger_entry returns None) and the orphan card is
        either gone or has been otherwise decoupled.
        """
        from whispers.orientation import release_callsign

        db_path = str(tmp_path / "release.db")
        WhispersDB(db_path=db_path)
        _seed_retired_burr(db_path, with_session=False)

        result = release_callsign(db_path=db_path, callsign="burr")
        assert result["ok"] is True
        assert result["callsign"] == "burr"

        conn = sqlite3.connect(db_path)
        try:
            ledger = conn.execute(
                "SELECT * FROM callsign_ledger WHERE callsign=?", ("burr",)
            ).fetchone()
            card = conn.execute(
                "SELECT * FROM agent_cards WHERE callsign=?", ("burr",)
            ).fetchone()
        finally:
            conn.close()
        assert ledger is None, "ledger row must be gone so continuity.py stops rejecting new binds"
        assert card is None, "orphan card must be removed so anchor derivation is unconstrained"

    def test_release_blocks_when_live_session_exists(self, tmp_path):
        """Releasing a callsign that still has a live agent_sessions row must fail —
        that's a live participant, not an orphan. Force is required to override.
        """
        from whispers.orientation import release_callsign

        db_path = str(tmp_path / "release_live.db")
        WhispersDB(db_path=db_path)
        _seed_retired_burr(db_path, with_session=True)

        result = release_callsign(db_path=db_path, callsign="burr")
        assert result["ok"] is False
        assert "live_session" in result.get("reason", "")

        conn = sqlite3.connect(db_path)
        try:
            ledger = conn.execute(
                "SELECT status FROM callsign_ledger WHERE callsign=?", ("burr",)
            ).fetchone()
        finally:
            conn.close()
        assert ledger is not None, "live-session guard must refuse to touch the ledger"

    def test_release_force_bypasses_session_guard(self, tmp_path):
        """force=True is the operator override for when a session row is stale
        (common: bridge died without releasing the lease). Use with intent.
        """
        from whispers.orientation import release_callsign

        db_path = str(tmp_path / "release_force.db")
        WhispersDB(db_path=db_path)
        _seed_retired_burr(db_path, with_session=True)

        result = release_callsign(db_path=db_path, callsign="burr", force=True)
        assert result["ok"] is True

        conn = sqlite3.connect(db_path)
        try:
            ledger = conn.execute(
                "SELECT * FROM callsign_ledger WHERE callsign=?", ("burr",)
            ).fetchone()
            session = conn.execute(
                "SELECT * FROM agent_sessions WHERE agent_name=?", ("burr",)
            ).fetchone()
        finally:
            conn.close()
        assert ledger is None
        assert session is None, "force=True also clears the stale session row"

    def test_release_nonexistent_callsign_is_idempotent(self, tmp_path):
        """Releasing a callsign that doesn't exist is a successful no-op —
        safe to script, safe to re-run after partial failure.
        """
        from whispers.orientation import release_callsign

        db_path = str(tmp_path / "release_nop.db")
        WhispersDB(db_path=db_path)

        result = release_callsign(db_path=db_path, callsign="ghost")
        assert result["ok"] is True
        assert result.get("released", {}).get("ledger", 0) == 0
        assert result.get("released", {}).get("card", 0) == 0

    def test_release_preserves_message_history(self, tmp_path):
        """Release clears ledger/card/presence. It must NOT delete the messages
        table — old conversations remain auditable, even after the callsign is
        reissued to a new subject.
        """
        from whispers.orientation import release_callsign

        db_path = str(tmp_path / "release_msg.db")
        WhispersDB(db_path=db_path)
        _seed_retired_burr(db_path, with_session=False)

        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, subject, body, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, datetime('now'))",
                ("msg-1", "burr", "spark", "inform", "hello", "from old burr"),
            )
            conn.commit()
        finally:
            conn.close()

        release_callsign(db_path=db_path, callsign="burr")

        conn = sqlite3.connect(db_path)
        try:
            msg = conn.execute("SELECT * FROM messages WHERE uuid=?", ("msg-1",)).fetchone()
        finally:
            conn.close()
        assert msg is not None, "message history must survive callsign release"


class TestReleaseCallsignCLI:
    """The CLI wrapper is a thin click surface around release_callsign()."""

    def test_cli_ledger_release_invokes_helper(self, tmp_path, monkeypatch):
        """`whispers ledger release <callsign>` calls release_callsign with the
        right arguments and exits 0 on success, 1 on failure.
        """
        from click.testing import CliRunner

        from whispers.cli import main

        db_path = str(tmp_path / "cli.db")
        WhispersDB(db_path=db_path)
        _seed_retired_burr(db_path, with_session=False)

        runner = CliRunner()
        result = runner.invoke(main, ["ledger", "release", "burr", "--db", db_path])
        assert result.exit_code == 0, result.output
        assert "burr" in result.output

    def test_cli_ledger_release_exits_1_on_live_session(self, tmp_path):
        """Without --force, the CLI must exit non-zero when a live session blocks."""
        from click.testing import CliRunner

        from whispers.cli import main

        db_path = str(tmp_path / "cli_live.db")
        WhispersDB(db_path=db_path)
        _seed_retired_burr(db_path, with_session=True)

        runner = CliRunner()
        result = runner.invoke(main, ["ledger", "release", "burr", "--db", db_path])
        assert result.exit_code != 0
