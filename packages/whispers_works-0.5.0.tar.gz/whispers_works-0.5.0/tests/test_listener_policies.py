"""Tests for W2 — WakePolicyStack + concrete wake policies.

Pins the composition semantics and each concrete policy's behavior in
isolation. The hard-bar acceptance from burr's W2 assignment is:

  * Each concrete policy unit-tested in isolation.
  * Stack short-circuit semantics: first non-skip decision wins.
  * Order-determinism: given the same event, reversing the stack
    produces a different decision. Provable in a test.

Design judgment calls made explicit (so a reviewer can evaluate them):

1. **Three-state Decision (allow / deny / skip), first non-skip wins.**
   Pure AND would make reverse-order-= different-decision impossible to
   prove as a test. Three-state + first-match gives policies real
   authority over order.

2. **Default on unanimous skip: deny.** Conservative. Matches the
   state-of-the-art anti-goal "pretending a manual-wake seat is an
   autonomous listener-backed seat" — prefer no-wake over fake-wake
   when no policy has an opinion.

3. **Stack adapts to the engine's `evaluate(event) -> bool` duck type.**
   The engine doesn't see Decision objects; it sees a bool. Reason
   tracing is internal to the stack for debuggability.
"""
from __future__ import annotations

import pytest

from whispers.listeners.policies import (
    AddressedToMePolicy,
    ContinuationPolicy,
    Decision,
    FlashPriorityPolicy,
    SilenceWindowPolicy,
    TierFloorPolicy,
    WakePolicy,
    WakePolicyStack,
)


def _make_event(**overrides) -> dict:
    """Build a StreamEvent.to_dict()-shaped dict for testing."""
    event = {
        "kind": "wake",
        "event_id": 1,
        "priority": "routine",
        "msg_type": "inform",
        "body": "",
        "sender": "peer",
        "payload": {},
    }
    event.update(overrides)
    return event


# ---- Decision dataclass ---------------------------------------------------


class TestDecision:
    def test_allow_carries_wake_true_and_reason(self):
        d = Decision.allow("matched my callsign", "AddressedToMePolicy")
        assert d.wake is True
        assert d.skip is False
        assert d.policy_name == "AddressedToMePolicy"
        assert "matched" in d.reason

    def test_deny_carries_wake_false(self):
        d = Decision.deny("tier below floor", "TierFloorPolicy")
        assert d.wake is False
        assert d.skip is False

    def test_skip_is_neither_allow_nor_deny(self):
        d = Decision.skipped("TierFloorPolicy")
        assert d.skip is True
        assert d.wake is False  # convention: skip reads as wake=False


# ---- Concrete policies in isolation --------------------------------------


class TestAddressedToMePolicy:
    def test_allows_when_sender_is_peer_and_msg_type_inform(self):
        policy = AddressedToMePolicy(self_callsign="burr")
        decision = policy.evaluate(_make_event(msg_type="inform", sender="alice"))
        assert decision.wake is True

    def test_skips_when_msg_type_is_ack(self):
        policy = AddressedToMePolicy(self_callsign="burr")
        decision = policy.evaluate(_make_event(msg_type="ack", sender="alice"))
        assert decision.skip is True

    def test_skips_when_sender_is_self(self):
        """Self-replies should not be counted as 'addressed to me' — loop risk."""
        policy = AddressedToMePolicy(self_callsign="burr")
        decision = policy.evaluate(_make_event(sender="burr"))
        assert decision.skip is True


class TestFlashPriorityPolicy:
    def test_allows_on_flash(self):
        policy = FlashPriorityPolicy()
        decision = policy.evaluate(_make_event(priority="flash"))
        assert decision.wake is True
        assert "flash" in decision.reason.lower()

    def test_skips_on_routine(self):
        policy = FlashPriorityPolicy()
        decision = policy.evaluate(_make_event(priority="routine"))
        assert decision.skip is True

    def test_skips_on_priority_below_flash(self):
        policy = FlashPriorityPolicy()
        decision = policy.evaluate(_make_event(priority="priority"))
        assert decision.skip is True


class TestContinuationPolicy:
    def test_allows_on_thread_in_active_set(self):
        policy = ContinuationPolicy(active_thread_ids={"thread-123"})
        payload = {"thread_id": "thread-123"}
        decision = policy.evaluate(_make_event(payload=payload))
        assert decision.wake is True

    def test_skips_on_thread_not_in_active_set(self):
        policy = ContinuationPolicy(active_thread_ids={"thread-123"})
        payload = {"thread_id": "thread-999"}
        decision = policy.evaluate(_make_event(payload=payload))
        assert decision.skip is True

    def test_skips_on_empty_active_set(self):
        policy = ContinuationPolicy(active_thread_ids=set())
        decision = policy.evaluate(_make_event())
        assert decision.skip is True


class TestSilenceWindowPolicy:
    def test_denies_when_window_active(self):
        policy = SilenceWindowPolicy(is_silent=lambda: True)
        decision = policy.evaluate(_make_event(priority="flash"))
        assert decision.wake is False
        assert decision.skip is False
        assert "silence" in decision.reason.lower()

    def test_skips_when_window_not_active(self):
        policy = SilenceWindowPolicy(is_silent=lambda: False)
        decision = policy.evaluate(_make_event())
        assert decision.skip is True


class TestTierFloorPolicy:
    def test_denies_when_sender_tier_below_floor(self):
        def tier_of(sender):
            return 1 if sender == "intruder" else 5

        policy = TierFloorPolicy(floor=3, tier_of=tier_of)
        decision = policy.evaluate(_make_event(sender="intruder"))
        assert decision.wake is False
        assert "tier" in decision.reason.lower()

    def test_skips_when_sender_tier_at_or_above_floor(self):
        def tier_of(sender):
            return 5

        policy = TierFloorPolicy(floor=3, tier_of=tier_of)
        decision = policy.evaluate(_make_event(sender="burr"))
        assert decision.skip is True

    def test_skips_when_tier_unknown(self):
        """Unknown tier should skip, not deny — deferred to next policy."""
        policy = TierFloorPolicy(floor=3, tier_of=lambda s: None)
        decision = policy.evaluate(_make_event())
        assert decision.skip is True


# ---- WakePolicyStack composition -----------------------------------------


class TestWakePolicyStackComposition:
    def test_empty_stack_denies(self):
        """Conservative default: unanimous skip → deny."""
        stack = WakePolicyStack([])
        assert stack.evaluate(_make_event()) is False

    def test_single_allow_wakes(self):
        stack = WakePolicyStack([FlashPriorityPolicy()])
        assert stack.evaluate(_make_event(priority="flash")) is True

    def test_single_skip_denies_by_default(self):
        stack = WakePolicyStack([FlashPriorityPolicy()])
        assert stack.evaluate(_make_event(priority="routine")) is False

    def test_first_non_skip_wins_allow_first(self):
        """FlashPriority allows before TierFloor can deny."""
        def tier_of(sender):
            return 1

        stack = WakePolicyStack(
            [FlashPriorityPolicy(), TierFloorPolicy(floor=3, tier_of=tier_of)]
        )
        decision = stack.evaluate(_make_event(priority="flash", sender="intruder"))
        assert decision is True

    def test_first_non_skip_wins_deny_first(self):
        """TierFloor denies before FlashPriority can allow — reverse order."""
        def tier_of(sender):
            return 1

        stack = WakePolicyStack(
            [TierFloorPolicy(floor=3, tier_of=tier_of), FlashPriorityPolicy()]
        )
        decision = stack.evaluate(_make_event(priority="flash", sender="intruder"))
        assert decision is False

    def test_reverse_order_produces_different_decision(self):
        """Hard-bar acceptance from burr's W2: reverse order ⇒ different
        decision for the same event. This is THE test that proves stack
        composition is non-trivial.
        """
        def tier_of(sender):
            return 1  # tier-1, below the floor of 3

        flash_event = _make_event(priority="flash", sender="intruder")

        # Stack A: FlashPriority first → allows flash even from low tier
        stack_a = WakePolicyStack(
            [FlashPriorityPolicy(), TierFloorPolicy(floor=3, tier_of=tier_of)]
        )
        decision_a = stack_a.evaluate(flash_event)

        # Stack B: TierFloor first → denies low-tier before flash is consulted
        stack_b = WakePolicyStack(
            [TierFloorPolicy(floor=3, tier_of=tier_of), FlashPriorityPolicy()]
        )
        decision_b = stack_b.evaluate(flash_event)

        assert decision_a != decision_b, (
            "Stack ordering must produce different decisions for the same event — "
            "otherwise policy ordering is meaningless."
        )

    def test_skip_defers_to_next_policy(self):
        """TierFloor skips when tier unknown; FlashPriority then decides."""
        stack = WakePolicyStack(
            [TierFloorPolicy(floor=3, tier_of=lambda s: None), FlashPriorityPolicy()]
        )
        assert stack.evaluate(_make_event(priority="flash")) is True
        assert stack.evaluate(_make_event(priority="routine")) is False


class TestWakePolicyStackReasonTracing:
    """Decision reasons trace through the stack for debuggability.

    The engine takes a bool, but a debugger / log consumer should be able
    to pull the structured reason out of the stack's last decision.
    """

    def test_last_decision_records_deciding_policy(self):
        stack = WakePolicyStack([FlashPriorityPolicy()])
        stack.evaluate(_make_event(priority="flash"))
        assert stack.last_decision is not None
        assert stack.last_decision.policy_name == "FlashPriorityPolicy"
        assert stack.last_decision.wake is True

    def test_last_decision_on_unanimous_skip(self):
        stack = WakePolicyStack([FlashPriorityPolicy()])
        stack.evaluate(_make_event(priority="routine"))
        assert stack.last_decision is not None
        assert stack.last_decision.wake is False
        assert "default" in stack.last_decision.reason.lower()


# ---- Engine-contract compatibility ---------------------------------------


class TestEngineContract:
    """WakePolicyStack must be a drop-in for the engine's .evaluate(event) -> bool."""

    def test_evaluate_returns_bool(self):
        stack = WakePolicyStack([FlashPriorityPolicy()])
        result = stack.evaluate(_make_event(priority="flash"))
        assert isinstance(result, bool)

    def test_preserved_WakePolicy_stub_still_evaluates(self):
        """Backwards-compat: the permissive WakePolicy stub's evaluate still works."""
        policy = WakePolicy()
        assert policy.evaluate(_make_event()) is True
