"""Slice 6 (plan Phase 2) — peers section with scale-bounded selection.

Implements the four-layer selection algorithm from the orient plan
(glittery-shimmying-tome.md §5):

  Layer 1: Agents in same spaces as me (live members)
  Layer 2: Agents sharing any pair_space active in last 72h
  Layer 3: Agents referenced in continuity anchors / prior-bind memory
  Layer 4: Agents who touched artifacts in working scope recently

Budget cap: 10 unique, sorted by salience = recent_activity × trust_tier ×
collaboration_edge_strength. Remainder surfaces as peers_omitted with a
discoverable_via pointer.

This is the "scale-critical" section — the feature that demonstrates
Whispers is not just a messaging queue but a scope-aware social graph.

Run: pytest tests/test_peers_section.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.storage.db import WhispersDB


def _seed_minimal_world(db_path: str) -> None:
    """Seed 3 peers + self in a shared workspace, with varied activity."""
    conn = sqlite3.connect(db_path)
    try:
        # Self
        conn.execute(
            "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
            "stable_subject_id, continuity_anchor) VALUES "
            "('self-id', 'me', 5, 'self-id', 'anchor:self')"
        )
        # Peers
        for cs, tier in [("alice", 5), ("bob", 4), ("carol", 3)]:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "stable_subject_id, continuity_anchor) VALUES (?, ?, ?, ?, ?)",
                (f"{cs}-id", cs, tier, f"{cs}-id", f"anchor:{cs}"),
            )
        # Shared workspace
        conn.execute(
            "INSERT INTO workspaces (workspace_id, name, purpose, status, created_by, "
            "created_at, last_delta_at, boundary_type, pair_key) VALUES "
            "('ws-1', 'shared', 'test pair', 'active', 'me', "
            "datetime('now','-1 hour'), datetime('now','-5 minutes'), "
            "'pair', 'me::alice')"
        )
        for cs in ("me", "alice"):
            conn.execute(
                "INSERT INTO workspace_members (workspace_id, agent_name, "
                "membership_role, membership_state, joined_at, last_active_at, "
                "expires_at) VALUES (?, ?, 'lead', 'active', "
                "datetime('now','-1 hour'), datetime('now','-5 minutes'), "
                "datetime('now','+1 hour'))",
                ("ws-1", cs),
            )
        # Messages — recent activity signals
        for i, (frm, to, priority, age_minutes) in enumerate([
            ("alice", "me", "priority", 5),
            ("me", "alice", "routine", 10),
            ("bob", "me", "routine", 40),
        ]):
            conn.execute(
                "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, "
                "priority, subject, created_at) VALUES (?, ?, ?, 'inform', ?, "
                "?, datetime('now', ?))",
                (f"m{i}", frm, to, priority, f"msg-{i}", f"-{age_minutes} minutes"),
            )
        conn.commit()
    finally:
        conn.close()


class TestFourLayerSelection:
    def test_layer_1_shared_space_members_surface_first(self, tmp_path):
        """Peers sharing a live workspace with self MUST appear in the
        peers array. Layer 1 is the strongest signal.
        """
        from whispers.orientation import build_peers_section

        db_path = str(tmp_path / "p1.db")
        WhispersDB(db_path=db_path)
        _seed_minimal_world(db_path)

        section = build_peers_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        callsigns = [p["callsign"] for p in section["peers"]]
        assert "alice" in callsigns, (
            "alice shares ws-1 workspace with me — must be surfaced"
        )

    def test_self_is_excluded_from_peers(self, tmp_path):
        """Self is never a peer of self."""
        from whispers.orientation import build_peers_section

        db_path = str(tmp_path / "self.db")
        WhispersDB(db_path=db_path)
        _seed_minimal_world(db_path)

        section = build_peers_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        callsigns = [p["callsign"] for p in section["peers"]]
        assert "me" not in callsigns

    def test_layer_4_message_activity_surfaces_peers(self, tmp_path):
        """bob has exchanged messages with me within the activity window
        → must appear in peers even without a shared workspace.
        """
        from whispers.orientation import build_peers_section

        db_path = str(tmp_path / "l4.db")
        WhispersDB(db_path=db_path)
        _seed_minimal_world(db_path)

        section = build_peers_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        callsigns = [p["callsign"] for p in section["peers"]]
        assert "bob" in callsigns

    def test_budget_cap_respected(self, tmp_path):
        """With 50 eligible peers and budget=5, peers array must have
        exactly 5 entries and peers_omitted.count must reflect the rest.
        """
        from whispers.orientation import build_peers_section

        db_path = str(tmp_path / "budget.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "stable_subject_id, continuity_anchor) VALUES "
                "('self-id', 'me', 5, 'self-id', 'anchor:self')"
            )
            for i in range(50):
                cs = f"peer{i:02d}"
                conn.execute(
                    "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                    "stable_subject_id, continuity_anchor) VALUES (?, ?, ?, ?, ?)",
                    (f"{cs}-id", cs, 3 + (i % 3), f"{cs}-id", f"anchor:{cs}"),
                )
                # Each has a recent message with me — qualifies for Layer 4
                conn.execute(
                    "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, "
                    "priority, subject, created_at) VALUES (?, ?, ?, 'inform', "
                    "'routine', ?, datetime('now', ?))",
                    (f"m{i}", cs, "me", f"s{i}", f"-{i*2} minutes"),
                )
            conn.commit()
        finally:
            conn.close()

        section = build_peers_section(
            db_path=db_path,
            self_callsign="me",
            budget=5,
        )
        assert len(section["peers"]) == 5
        assert section["peers_omitted"]["count"] == 45
        assert "presence_who" in section["peers_omitted"]["discoverable_via"]

    def test_salience_orders_higher_tier_and_recent_activity_first(self, tmp_path):
        """alice (tier 5, most recent msg) should rank higher than carol
        (no messages). bob (tier 4, older msg) lands between.
        """
        from whispers.orientation import build_peers_section

        db_path = str(tmp_path / "sal.db")
        WhispersDB(db_path=db_path)
        _seed_minimal_world(db_path)

        section = build_peers_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        callsigns = [p["callsign"] for p in section["peers"]]
        # alice must appear before bob (tier + recent activity)
        if "alice" in callsigns and "bob" in callsigns:
            assert callsigns.index("alice") < callsigns.index("bob"), (
                f"alice (tier 5, recent) should outrank bob (tier 4, older); "
                f"got order: {callsigns}"
            )

    def test_peer_entry_has_required_fields(self, tmp_path):
        """Every peer entry must carry callsign, trust_tier, presence,
        collaboration_edge, and last_seen_at per the spec.
        """
        from whispers.orientation import build_peers_section

        db_path = str(tmp_path / "shape.db")
        WhispersDB(db_path=db_path)
        _seed_minimal_world(db_path)

        section = build_peers_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        assert section["peers"], "expected at least one peer in seeded world"
        required = {
            "callsign", "trust_tier", "presence",
            "collaboration_edge", "last_seen_at", "shared_spaces",
        }
        for peer in section["peers"]:
            missing = required - set(peer.keys())
            assert not missing, f"peer {peer.get('callsign')} missing fields: {missing}"

    def test_selection_basis_is_declared(self, tmp_path):
        """peers_selection_basis is a mandatory top-level string so the
        operator can see WHY these peers were picked.
        """
        from whispers.orientation import build_peers_section

        db_path = str(tmp_path / "basis.db")
        WhispersDB(db_path=db_path)
        _seed_minimal_world(db_path)

        section = build_peers_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        assert isinstance(section.get("peers_selection_basis"), str)
        assert section["peers_selection_basis"]

    def test_empty_world_returns_empty_peers(self, tmp_path):
        """No peers, no workspace, no messages → peers=[] with clean
        omitted.count=0.
        """
        from whispers.orientation import build_peers_section

        db_path = str(tmp_path / "empty.db")
        WhispersDB(db_path=db_path)
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (agent_id, callsign, trust_tier, "
                "stable_subject_id, continuity_anchor) VALUES "
                "('self-id', 'me', 5, 'self-id', 'anchor:self')"
            )
            conn.commit()
        finally:
            conn.close()

        section = build_peers_section(
            db_path=db_path,
            self_callsign="me",
            budget=10,
        )
        assert section["peers"] == []
        assert section["peers_omitted"]["count"] == 0


class TestCapsuleIntegration:
    """assemble_bind_capsule now emits a peers section when the helper is
    available. Previously the capsule topped out at four sections
    (identity/truths/center/anchors); peers brings the total to five.
    """

    def test_capsule_includes_peers_section(self, tmp_path):
        from whispers.orientation import assemble_bind_capsule
        from whispers.testing import WhispersTestHarness

        with WhispersTestHarness() as h:
            client = h.make_client("burr-test")
            capsule = assemble_bind_capsule(client=client)
            assert "peers" in capsule, (
                "Slice 6 wired build_peers_section into assemble_bind_capsule"
            )
            peers_section = capsule["peers"]
            assert "peers" in peers_section
            assert "peers_omitted" in peers_section
            assert "peers_selection_basis" in peers_section
            assert "as_of" in peers_section
