from __future__ import annotations

from whispers.capability_provenance import CapabilityClaim


def test_native_capability_lives_inside_self():
    claim = CapabilityClaim(capability="review_code", provenance_kind="native", basis="observed")
    assert claim.lives_inside_self() is True
    assert claim.depends_on_external_boundary() is False
    assert claim.requires_provider() is False


def test_reachable_capability_depends_on_external_boundary():
    claim = CapabilityClaim(
        capability="legal_review",
        provenance_kind="reachable",
        basis="declared",
        durability="conditional",
        provider="agent:counsel",
    )
    assert claim.lives_inside_self() is False
    assert claim.depends_on_external_boundary() is True
    assert claim.requires_provider() is True


def test_attached_capability_is_not_native_even_when_available():
    claim = CapabilityClaim(
        capability="search_docs",
        provenance_kind="attached",
        basis="attested",
        provider="tool:search-api",
    )
    assert claim.lives_inside_self() is False
    assert claim.depends_on_external_boundary() is True
