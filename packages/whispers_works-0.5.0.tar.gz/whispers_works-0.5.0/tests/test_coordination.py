from __future__ import annotations

from whispers.testing import WhispersTestHarness


class TestCoordinationWorkLifecycle:
    def test_work_offer_is_distinct_from_message_state(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            offered = alice.work_offer("bob", "Review auth patch", description="Look at the JWT edge case")
            work_id = offered["work"]["work_id"]
            message_id = offered["offer_message"]["message_id"]

            bob.check_inbox(mark_seen=True)

            work = alice.work_get(work_id)
            message = alice.db.get_message(message_id)

            assert work["work"]["state"] == "offered"
            assert work["work"]["thread_id"] == offered["offer_message"]["thread_id"]
            assert work["work"]["space_id"] == offered["offer_message"]["space_id"]
            assert message is not None
            assert message["status"] == "seen"
            assert bob.status()["work_summary"]["incoming_offers"] == 1

    def test_accept_progress_block_close_do_not_collapse_into_message_truth(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            offered = alice.work_offer("bob", "Implement startup capsule", description="Keep it small and truthful")
            work_id = offered["work"]["work_id"]
            message_id = offered["offer_message"]["message_id"]

            bob.check_inbox(mark_seen=True)
            accepted = bob.work_accept(work_id, note="Taking this.")
            assert accepted["work"]["state"] == "accepted"
            assert accepted["work"]["owner_agent"] == "bob"

            message_after_accept = alice.db.get_message(message_id)
            assert message_after_accept is not None
            assert message_after_accept["status"] == "acknowledged"

            started = bob.work_start(work_id, note="Beginning implementation.")
            assert started["work"]["state"] == "in_progress"

            blocked = bob.work_block(work_id, note="Need one decision on startup copy.")
            assert blocked["work"]["state"] == "blocked"

            closed = bob.work_close(work_id, note="Done.")
            assert closed["work"]["state"] == "closed"
            assert closed["work"]["closed_at"] is not None

            message_after_close = alice.db.get_message(message_id)
            assert message_after_close is not None
            assert message_after_close["status"] == "acknowledged"
            assert bob.status()["work_summary"]["owned_open"] == 0

    def test_handoff_transfers_ownership_without_breaking_thread(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")
            charlie = h.make_client("charlie")

            room = alice.space_create("execution room")
            space_id = room["space"]["space_id"]
            bob.space_join(space_id)
            charlie.space_join(space_id)

            offered = alice.work_offer("bob", "Take over presence model", description="Need a cleaner per-space story", space_id=space_id)
            work_id = offered["work"]["work_id"]
            original_thread = offered["work"]["thread_id"]

            bob.work_accept(work_id)
            bob.work_start(work_id)
            handed_off = bob.work_handoff(work_id, to="charlie", note="You have the right context for this.")
            assert handed_off["work"]["state"] == "handoff_requested"
            assert handed_off["work"]["owner_agent"] == "bob"
            assert handed_off["work"]["proposed_owner"] == "charlie"

            charlie_inbox = charlie.check_inbox(mark_seen=False, space_id=space_id)
            assert any(item["thread_id"] == original_thread for item in charlie_inbox)

            accepted = charlie.work_accept(work_id, note="I'll take it.")
            assert accepted["work"]["state"] == "accepted"
            assert accepted["work"]["owner_agent"] == "charlie"
            assert accepted["work"]["thread_id"] == original_thread
