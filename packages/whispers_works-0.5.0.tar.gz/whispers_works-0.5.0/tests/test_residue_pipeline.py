"""Residue pipeline — plan-Phase-2 Slice 7 follow-on.

Scans recent messages for recurring friction patterns: repeated subjects,
repeated phrases, repeated senders hitting the same topic. Surfaces as
residue entries with noticed_at + basis so operators see accumulated
themes without reading the full inbox.

Minimal viable implementation: word/bigram frequency across recent
subjects. Extends naturally to body-text and multi-scope aggregation.

Run: pytest tests/test_residue_pipeline.py -v
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.storage.db import WhispersDB


def _seed_messages(db_path: str, messages: list[tuple[str, str, str, str, int]]) -> None:
    """Insert message rows. Tuple: (from, to, subject, body, age_minutes)."""
    conn = sqlite3.connect(db_path)
    try:
        for i, (frm, to, subj, body, age) in enumerate(messages):
            conn.execute(
                "INSERT INTO messages (uuid, from_agent, to_agent, msg_type, "
                "priority, subject, body, status, created_at) VALUES (?, ?, ?, "
                "'inform', 'routine', ?, ?, 'delivered', datetime('now', ?))",
                (f"r{i}", frm, to, subj, body, f"-{age} minutes"),
            )
        conn.commit()
    finally:
        conn.close()


class TestPatternExtraction:
    def test_repeated_phrase_surfaces_as_residue(self, tmp_path):
        """A phrase appearing in 3+ subject lines in the window surfaces
        with pattern_count reflecting the repetition.
        """
        from whispers.residue import detect_residue

        db_path = str(tmp_path / "res.db")
        WhispersDB(db_path=db_path)
        _seed_messages(db_path, [
            ("alice", "me", "Slice 10 review needed", "body1", 10),
            ("bob",   "me", "Slice 10 progress update", "body2", 20),
            ("carol", "me", "Slice 10 status", "body3", 30),
            ("alice", "me", "daily standup", "body4", 40),
        ])

        residue = detect_residue(
            db_path=db_path,
            self_callsign="me",
            window_days=1,
            min_repetitions=3,
        )
        patterns = [r["pattern"] for r in residue]
        assert any("slice 10" in p.lower() for p in patterns)

    def test_single_mention_does_not_surface(self, tmp_path):
        """Phrases appearing only once never qualify as residue."""
        from whispers.residue import detect_residue

        db_path = str(tmp_path / "single.db")
        WhispersDB(db_path=db_path)
        _seed_messages(db_path, [
            ("alice", "me", "one-off question", "body", 10),
            ("bob",   "me", "unrelated topic", "body", 20),
        ])

        residue = detect_residue(
            db_path=db_path,
            self_callsign="me",
            window_days=1,
            min_repetitions=3,
        )
        assert residue == []

    def test_residue_entry_shape(self, tmp_path):
        """Each residue entry carries pattern, noticed_at, basis,
        challengeable per plan doc §6.
        """
        from whispers.residue import detect_residue

        db_path = str(tmp_path / "shape.db")
        WhispersDB(db_path=db_path)
        _seed_messages(db_path, [
            ("alice", "me", "wake adapter failing", "body", 5),
            ("bob",   "me", "wake adapter status", "body", 15),
            ("carol", "me", "wake adapter question", "body", 25),
        ])

        residue = detect_residue(
            db_path=db_path,
            self_callsign="me",
            window_days=1,
            min_repetitions=3,
        )
        assert residue
        for r in residue:
            for field in ("pattern", "noticed_at", "basis", "challengeable"):
                assert field in r, f"missing {field}: {r}"
            assert isinstance(r["challengeable"], bool)

    def test_stopwords_are_filtered(self, tmp_path):
        """Common English words like 'the', 'and', 'for' repeated across
        subjects must NOT surface as residue — they're noise.
        """
        from whispers.residue import detect_residue

        db_path = str(tmp_path / "stop.db")
        WhispersDB(db_path=db_path)
        _seed_messages(db_path, [
            ("alice", "me", "the report for you", "body", 10),
            ("bob",   "me", "the update for review", "body", 20),
            ("carol", "me", "the summary for team", "body", 30),
        ])

        residue = detect_residue(
            db_path=db_path,
            self_callsign="me",
            window_days=1,
            min_repetitions=3,
        )
        patterns_lower = [r["pattern"].lower() for r in residue]
        for noise in ("the", "for", "and", "of"):
            assert noise not in patterns_lower, (
                f"stopword '{noise}' should not surface as residue"
            )

    def test_window_excludes_ancient_messages(self, tmp_path):
        """Messages older than the window are ignored even if their
        pattern repeats."""
        from whispers.residue import detect_residue

        db_path = str(tmp_path / "win.db")
        WhispersDB(db_path=db_path)
        _seed_messages(db_path, [
            ("alice", "me", "ancient topic", "body", 60 * 24 * 30),  # 30d old
            ("bob",   "me", "ancient topic", "body", 60 * 24 * 30),
            ("carol", "me", "ancient topic", "body", 60 * 24 * 30),
        ])

        residue = detect_residue(
            db_path=db_path,
            self_callsign="me",
            window_days=7,
            min_repetitions=3,
        )
        assert residue == []

    def test_empty_inbox_returns_empty_list(self, tmp_path):
        from whispers.residue import detect_residue

        db_path = str(tmp_path / "empty.db")
        WhispersDB(db_path=db_path)

        residue = detect_residue(
            db_path=db_path, self_callsign="me",
        )
        assert residue == []


class TestScopeBoundary:
    def test_only_messages_involving_self_are_considered(self, tmp_path):
        """Residue is scope-local to the requesting agent — messages
        between OTHER parties don't contribute to MY residue."""
        from whispers.residue import detect_residue

        db_path = str(tmp_path / "scope.db")
        WhispersDB(db_path=db_path)
        # 3 messages between alice and bob, none involving me
        _seed_messages(db_path, [
            ("alice", "bob", "external topic", "body", 10),
            ("bob", "alice", "external topic", "body", 20),
            ("alice", "bob", "external topic", "body", 30),
        ])

        residue = detect_residue(
            db_path=db_path,
            self_callsign="me",
            window_days=1,
            min_repetitions=3,
        )
        assert residue == [], (
            "residue must be scope-local to the requesting self; "
            "inter-third-party traffic should not surface"
        )
