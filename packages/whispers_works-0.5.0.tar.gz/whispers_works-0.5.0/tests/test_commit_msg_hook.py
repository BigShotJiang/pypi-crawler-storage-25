"""Tests for the DoD-trailer commit-msg hook checker.

Covers detection (which commits trigger the gate), validation (whether
trailers are present + well-formed), and the CLI entry point that
actually runs as the git hook.

Ships alongside scripts/git-hooks/commit_msg_check.py so the check is
exercisable without a real git commit.
"""

from __future__ import annotations

import importlib.util
import subprocess
import sys
from pathlib import Path

import pytest

# Load the hook script as a module so we can exercise its functions
# directly. The script lives outside whispers/ and isn't on sys.path.
_HOOK_DIR = Path(__file__).resolve().parents[1] / "scripts" / "git-hooks"
_HOOK_SCRIPT = _HOOK_DIR / "commit_msg_check.py"


def _load_hook_module():
    spec = importlib.util.spec_from_file_location(
        "commit_msg_check_under_test", _HOOK_SCRIPT,
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # type: ignore[union-attr]
    return module


hook = _load_hook_module()


# --- Helpers ---------------------------------------------------------------

VALID_TRAILERS = (
    "DoD-Outcome: Flash message from A to B causes B's handler to receive "
    "the dispatch within 5 seconds.\n"
    "Live-Path-Tested: yes\n"
    "Regression-Scope: if the SSE dispatcher regresses, the handler never "
    "fires and the operator falls back to manual relay.\n"
)


def make_commit(subject: str, body: str = "", *, include_trailers: bool = False) -> str:
    parts = [subject]
    if body:
        parts.append("")
        parts.append(body)
    if include_trailers:
        parts.append("")
        parts.append(VALID_TRAILERS.rstrip())
    return "\n".join(parts) + "\n"


# --- _is_dod_closing -------------------------------------------------------


class TestIsDoDClosing:
    def test_release_subject_triggers(self):
        assert hook._is_dod_closing("Release v0.6.0 — pollen identity")

    def test_release_subject_case_insensitive(self):
        assert hook._is_dod_closing("RELEASE V0.6.0")

    def test_acceptance_test_subject_triggers(self):
        assert hook._is_dod_closing("Acceptance Test #6: wake runtime kill")

    def test_closes_dod_in_subject_triggers(self):
        assert hook._is_dod_closing("Fixes bug: closes DoD for Slice 12")

    def test_any_trailer_present_opts_in(self):
        msg = make_commit(
            "Refactor: regroup utility helpers",
            body="DoD-Outcome: structural rename; callers unchanged.\nLive-Path-Tested: yes\nRegression-Scope: none.",
        )
        assert hook._is_dod_closing(msg)

    def test_plain_commit_does_not_trigger(self):
        assert not hook._is_dod_closing("Fix typo in README")

    def test_chore_subject_does_not_trigger(self):
        assert not hook._is_dod_closing("chore: bump version pin in CI config")

    def test_comment_lines_ignored(self):
        # Git leaves # comment lines in the template. They must NOT trigger.
        msg = "Commit\n\n# Release v0.7.0 instructions:\n# Acceptance Test #6 should be green\n"
        assert not hook._is_dod_closing(msg)


# --- _extract_trailers -----------------------------------------------------


class TestExtractTrailers:
    def test_extracts_all_three(self):
        msg = make_commit("Release v0.6.0", include_trailers=True)
        found = hook._extract_trailers(msg)
        assert "DoD-Outcome" in found
        assert "Live-Path-Tested" in found
        assert "Regression-Scope" in found

    def test_missing_trailers_return_absent(self):
        msg = make_commit("Release v0.6.0")
        found = hook._extract_trailers(msg)
        assert found == {}

    def test_first_occurrence_wins_on_duplicate(self):
        msg = (
            "Release v0.6.0\n\n"
            "DoD-Outcome: first value of the outcome trailer here and longer.\n"
            "DoD-Outcome: second value should be ignored per spec.\n"
        )
        found = hook._extract_trailers(msg)
        assert found["DoD-Outcome"].startswith("first value")


# --- _validate_live_path_value ---------------------------------------------


class TestLivePathValue:
    def test_yes_passes(self):
        assert hook._validate_live_path_value("yes") is None

    def test_no_passes(self):
        assert hook._validate_live_path_value("no") is None

    def test_partial_with_long_description_passes(self):
        assert hook._validate_live_path_value(
            "partial — test substitutes a mock HTTP adapter, side-stepping the "
            "auto-registration call site in ensure_wake_adapter_for_claude_code."
        ) is None

    def test_bare_partial_fails(self):
        err = hook._validate_live_path_value("partial")
        assert err is not None
        assert "too short" in err

    def test_partial_with_short_description_fails(self):
        err = hook._validate_live_path_value("partial — mock")
        assert err is not None
        assert "too short" in err

    def test_unknown_value_fails(self):
        err = hook._validate_live_path_value("sorta")
        assert err is not None
        assert "must be 'yes', 'no', or start with 'partial'" in err

    def test_case_insensitive(self):
        assert hook._validate_live_path_value("YES") is None
        assert hook._validate_live_path_value("No") is None


# --- validate_message (integration of all checks) ---------------------------


class TestValidateMessage:
    def test_non_dod_commit_passes_without_trailers(self):
        msg = make_commit("Fix typo in README")
        assert hook.validate_message(msg) == []

    def test_release_with_all_three_trailers_passes(self):
        msg = make_commit("Release v0.6.0 — pollen identity", include_trailers=True)
        assert hook.validate_message(msg) == []

    def test_release_without_trailers_fails_three_times(self):
        msg = make_commit("Release v0.6.0 — pollen identity")
        violations = hook.validate_message(msg)
        assert len(violations) == 3
        assert all("Missing required trailer" in v for v in violations)

    def test_acceptance_commit_without_trailers_fails(self):
        msg = make_commit("Acceptance Test #6: wake runtime kill proof")
        violations = hook.validate_message(msg)
        assert len(violations) == 3

    def test_partial_trailer_set_still_fails(self):
        msg = (
            "Release v0.6.0\n\n"
            "DoD-Outcome: The release ships the pollen identity floor.\n"
            "Live-Path-Tested: yes\n"
            # Regression-Scope missing
        )
        violations = hook.validate_message(msg)
        assert any("Regression-Scope" in v for v in violations)
        assert len(violations) == 1

    def test_empty_trailer_value_fails(self):
        msg = (
            "Release v0.6.0\n\n"
            "DoD-Outcome: \n"
            "Live-Path-Tested: yes\n"
            "Regression-Scope: if dispatcher regresses the handler never fires.\n"
        )
        violations = hook.validate_message(msg)
        assert any("empty value" in v for v in violations)

    def test_short_outcome_fails(self):
        msg = (
            "Release v0.6.0\n\n"
            "DoD-Outcome: ships things\n"
            "Live-Path-Tested: yes\n"
            "Regression-Scope: if dispatcher regresses the handler never fires.\n"
        )
        violations = hook.validate_message(msg)
        assert any("DoD-Outcome" in v and "too short" in v for v in violations)

    def test_short_regression_fails(self):
        msg = (
            "Release v0.6.0\n\n"
            "DoD-Outcome: Ships the pollen identity floor under active listening.\n"
            "Live-Path-Tested: yes\n"
            "Regression-Scope: nope\n"
        )
        violations = hook.validate_message(msg)
        assert any("Regression-Scope" in v and "too short" in v for v in violations)

    def test_malformed_live_path_fails(self):
        msg = (
            "Release v0.6.0\n\n"
            "DoD-Outcome: Ships the pollen identity floor under active listening.\n"
            "Live-Path-Tested: sorta\n"
            "Regression-Scope: if dispatcher regresses the handler never fires.\n"
        )
        violations = hook.validate_message(msg)
        assert any("Live-Path-Tested" in v for v in violations)


# --- Cinder's worked example from CONTRIBUTING.md should pass --------------


class TestCinderWorkedExample:
    """The exact commit message shape CONTRIBUTING.md teaches must validate."""

    def test_contributing_md_example_passes(self):
        msg = (
            "Acceptance Test #5: flash wake under 5s — live proof\n\n"
            "Body text describing the change in prose.\n\n"
            "DoD-Outcome: Flash message from A -> B causes B's adapter to "
            "receive a dispatch POST within 5 seconds.\n"
            "Live-Path-Tested: partial -- test registers its own HTTP "
            "adapter via POST /wake/desk/adapters, side-stepping "
            "ensure_wake_adapter_for_claude_code_session. Proves the "
            "dispatch path once an adapter is registered; does NOT prove "
            "the auto-registration path fires during a real Claude Code "
            "bind_seat.\n"
            "Regression-Scope: if "
            "ensure_wake_adapter_for_claude_code_session breaks, this "
            "test stays green but the operator experience fails silently.\n"
        )
        violations = hook.validate_message(msg)
        assert violations == [], f"CONTRIBUTING.md example must pass: {violations}"


# --- CLI entry point --------------------------------------------------------


class TestCliEntryPoint:
    """Run the script as a subprocess against a temp file, like git would."""

    def _run(self, message: str, tmp_path: Path) -> tuple[int, str, str]:
        msg_file = tmp_path / "COMMIT_EDITMSG"
        msg_file.write_text(message, encoding="utf-8")
        result = subprocess.run(
            [sys.executable, str(_HOOK_SCRIPT), str(msg_file)],
            capture_output=True, text=True,
        )
        return result.returncode, result.stdout, result.stderr

    def test_non_dod_commit_exits_zero(self, tmp_path):
        rc, _, _ = self._run("Fix typo in README\n", tmp_path)
        assert rc == 0

    def test_valid_dod_commit_exits_zero(self, tmp_path):
        msg = make_commit("Release v0.6.0", include_trailers=True)
        rc, _, _ = self._run(msg, tmp_path)
        assert rc == 0

    def test_invalid_dod_commit_exits_one_with_hint(self, tmp_path):
        rc, _, stderr = self._run("Release v0.6.0\n", tmp_path)
        assert rc == 1
        assert "CONTRIBUTING.md" in stderr
        assert "DoD-Outcome" in stderr

    def test_missing_argument_exits_two(self, tmp_path):
        result = subprocess.run(
            [sys.executable, str(_HOOK_SCRIPT)],
            capture_output=True, text=True,
        )
        assert result.returncode == 2

    def test_unreadable_file_exits_two(self, tmp_path):
        result = subprocess.run(
            [sys.executable, str(_HOOK_SCRIPT), str(tmp_path / "does-not-exist")],
            capture_output=True, text=True,
        )
        assert result.returncode == 2
