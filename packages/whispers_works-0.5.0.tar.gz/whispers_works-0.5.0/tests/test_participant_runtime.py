from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from whispers.client import WhispersException
from whispers.server import create_app
from whispers.testing import WhispersTestHarness


class TestParticipantRuntime:
    def test_status_projection_exposes_capability_posture_and_compact_startup_summary(self):
        with WhispersTestHarness() as h:
            desk = h.make_client("desk", participant_profile="desktop_ide_agent")

            who = desk.whoami()
            assert who is not None
            assert who["participant_projection"]["capability_posture"]["self_backed_capabilities"] == ["reason_about_code"]
            assert who["participant_projection"]["capability_posture"]["boundary_dependent_capabilities"] == ["workspace_io"]

            status = desk.status()
            assert status["participant_projection"]["interaction_summary"] == "review, handoff, exchange"
            assert "self-backed capabilities: reason about code" in status["startup_capsule"]
            assert "boundary-dependent capabilities: workspace io" in status["startup_capsule"]

    def test_work_capability_requirements_fail_closed_for_boundary_dependent_claims(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            approval = h.make_client("approval-pane", participant_profile="approval_surface")

            with pytest.raises(WhispersException) as exc:
                alice.work_offer(
                    "approval-pane",
                    "Approve production rollout",
                    metadata={"required_capabilities": ["human_decision"]},
                )
            assert "boundary-dependent support" in str(exc.value)

            allowed = alice.work_offer(
                "approval-pane",
                "Approve production rollout",
                metadata={
                    "required_capabilities": ["human_decision"],
                    "allow_external_capability_dependency": True,
                },
            )
            report = allowed["work"]["metadata"]["whispers:capability_requirement_report"]
            assert report["external_dependency_capabilities"][0]["capability"] == "human_decision"
            assert allowed["work"]["metadata"]["whispers:assignee_participant_summary"]

            native = h.make_client("native-coder", participant_profile="desktop_ide_agent")
            native_offer = alice.work_offer(
                "native-coder",
                "Review parser",
                metadata={"required_capabilities": ["reason_about_code"]},
            )
            assert native_offer["work"]["metadata"]["whispers:capability_requirement_report"]["all_self_backed"] is True

    def test_participant_onboarding_kit_is_available_locally_and_over_api(self):
        with WhispersTestHarness() as h:
            operator = h.make_client("operator")

            profiles = operator.participant_profiles()
            assert "status_source" in profiles
            assert "approval_surface" in profiles

            kit = operator.participant_kit(
                server="http://127.0.0.1:8000",
                participant_profile="status_source",
                sender="doorbell",
                recipient="alice",
                subject="Button pressed",
                body="Front door button pressed",
            )
            assert kit["descriptor"]["participant_kind"] == "status_source"
            assert kit["projection"]["reachability_mode"] == "event_emit_only"
            assert "home_assistant_automation" in kit["kit"]
            assert kit["kit"]["starter_artifact"] == "curl"

            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            profiles_response = client.get("/participants/profiles")
            assert profiles_response.status_code == 200
            assert "gateway_bridge" in profiles_response.json()["profiles"]

            kit_response = client.post(
                "/participants/kit",
                json={
                    "participant_profile": "approval_surface",
                    "sender": "phone-approval",
                    "recipient": "alice",
                    "subject": "Need approval",
                    "artifacts": ["ios_shortcut_recipe", "browser_pairing_url"],
                },
            )
            assert kit_response.status_code == 200
            payload = kit_response.json()
            assert payload["descriptor"]["participant_kind"] == "approval_surface"
            assert payload["kit"]["starter_artifact"] in {"ios_shortcut_recipe", "browser_pairing_url"}
            assert "ios_shortcut_recipe" in payload["kit"]
            assert "browser_pairing_url" in payload["kit"]
