from __future__ import annotations

from whispers.residue import ObservationLabel, ResidueGrain
from whispers.testing import WhispersTestHarness


class TestResidueLanding:
    def test_residue_grain_round_trips_with_axis_subjects_and_provenance(self):
        with WhispersTestHarness() as h:
            alice = h.make_client(
                "alice",
                owner_id="zack",
                platform_family="claudecode",
                context_hint="mainworktree",
            )
            bob = h.make_client(
                "bob",
                owner_id="zack",
                platform_family="codex",
                context_hint="reviewworktree",
            )

            sent = alice.send("bob", "Architecture review", body="Please review the residue landing surface")
            offered = alice.work_offer("bob", "Review residue landing", description="Check whether this is enough structure")

            grain = ResidueGrain(
                axis="relationship",
                subject_refs=(alice.agent_name, bob.agent_name),
                observation="Strong architecture-review pairing: low rework over recent exchanges.",
                label=ObservationLabel(
                    basis="pattern",
                    confidence=0.81,
                    ttl_seconds=86400,
                    observed_by=alice.agent_name,
                    negative_states=("not_canonical",),
                ),
                space_id=sent["space_id"],
                work_id=offered["work"]["work_id"],
                source_message_id=sent["message_id"],
                metadata={"kind": "pairing_hint"},
            )
            stored = alice.residue.record(grain)

            assert stored["signal_kind"] == "residue"
            assert stored["axis"] == "relationship"
            assert stored["primary_subject_ref"] == "alice"
            assert stored["subject_refs"] == ["alice", "bob"]
            assert stored["basis"] == "pattern"
            assert stored["confidence"] == 0.81
            assert stored["space_id"] == sent["space_id"]
            assert stored["work_id"] == offered["work"]["work_id"]
            assert stored["source_message_id"] == sent["message_id"]
            assert stored["metadata"]["kind"] == "pairing_hint"
            assert stored["challengeable"] is True

            listed = alice.residue.list(subject_ref="bob")
            assert any(item["grain_id"] == grain.grain_id for item in listed)

    def test_pollen_lands_in_separate_signal_kind_without_affecting_live_truth(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")
            bob = h.make_client("bob")

            status_before = bob.status()
            grain = ResidueGrain(
                signal_kind="pollen",
                axis="space",
                subject_refs=("space:build-lane",),
                observation="This build lane has useful review patterns that adjacent spaces may want.",
                label=ObservationLabel(basis="observed", confidence=0.6, observed_by=alice.agent_name),
                spread="adjacent_spaces",
            )
            stored = alice.residue.record(grain)
            status_after = bob.status()

            assert stored["signal_kind"] == "pollen"
            assert stored["spread"] == "adjacent_spaces"
            assert status_before["effective_trust"] == status_after["effective_trust"]
            assert status_before["spaces"] == status_after["spaces"]
            assert status_before["message_summary"] == status_after["message_summary"]

    def test_expired_residue_can_be_reaped_without_touching_active_grains(self):
        with WhispersTestHarness() as h:
            alice = h.make_client("alice")

            expired = ResidueGrain(
                axis="identity",
                subject_refs=(alice.agent_name,),
                observation="Short-lived hint that should age out immediately.",
                label=ObservationLabel(basis="observed", ttl_seconds=0, observed_by=alice.agent_name),
            )
            durable = ResidueGrain(
                axis="identity",
                subject_refs=(alice.agent_name,),
                observation="Longer-lived observation.",
                label=ObservationLabel(basis="observed", ttl_seconds=3600, observed_by=alice.agent_name),
            )
            alice.residue.record(expired)
            alice.residue.record(durable)

            removed = alice.residue.reap_expired()
            assert removed >= 1

            remaining = alice.residue.list(subject_ref="alice", include_expired=False)
            grain_ids = {item["grain_id"] for item in remaining}
            assert durable.grain_id in grain_ids
            assert expired.grain_id not in grain_ids
