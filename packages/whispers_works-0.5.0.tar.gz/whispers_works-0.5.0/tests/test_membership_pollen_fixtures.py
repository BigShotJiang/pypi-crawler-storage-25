"""Smoke tests for the membership-pollen scenario builders (Stage B).

Meta-tests: verify each builder seeds what its descriptor claims,
produces envelopes of the expected shape, and carries the right
tamper_kind token. Real pollen-layer tests (T4.22+) will live
alongside the verification module — not here.
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.pollen import MembershipPollen
from whispers.pollen.schemas import PollenExpiredError
from whispers.pollen.signing import PollenVerifier
from whispers.storage.db import WhispersDB
from tests.fixtures.membership_pollen_scenarios import (
    MEMBERSHIP_POLLEN_SCENARIO_BUILDERS,
    build_membership_pollen_scenario,
    build_membership_pollen_missing,
    build_membership_pollen_expired,
    build_membership_pollen_for_wrong_space,
    build_membership_pollen_missing_ledger,
    build_membership_pollen_forged_signature,
    build_membership_pollen_valid,
)


@pytest.fixture
def db_path(tmp_path):
    path = str(tmp_path / "mpoll.db")
    WhispersDB(db_path=path)
    return path


# --- Descriptor contract ---------------------------------------------------


class TestDescriptorShape:
    _REQUIRED = {
        "scenario",
        "seeded_callsigns",
        "primary_callsign",
        "space_id",
        "drift_signal",
        "pollen_grain",
        "what_a_pollen_layer_should_detect",
        "notes",
    }

    @pytest.mark.parametrize("scenario_name", sorted(MEMBERSHIP_POLLEN_SCENARIO_BUILDERS))
    def test_descriptor_has_required_keys(self, scenario_name, tmp_path):
        path = str(tmp_path / f"{scenario_name}.db")
        WhispersDB(db_path=path)
        descriptor = MEMBERSHIP_POLLEN_SCENARIO_BUILDERS[scenario_name](path)
        missing = self._REQUIRED - set(descriptor.keys())
        assert not missing, f"{scenario_name} missing keys: {missing}"
        assert descriptor["scenario"] == scenario_name
        assert descriptor["drift_signal"] == scenario_name
        grain = descriptor["pollen_grain"]
        assert set(grain.keys()) >= {"envelope", "tamper_kind", "issuer_key_id"}


# --- Missing: no envelope --------------------------------------------------


class TestMissing:
    def test_envelope_is_none(self, db_path):
        d = build_membership_pollen_missing(db_path, callsign="mem1")
        assert d["pollen_grain"]["envelope"] is None
        assert d["pollen_grain"]["tamper_kind"] == "missing"

    def test_ledger_row_exists(self, db_path):
        d = build_membership_pollen_missing(db_path, callsign="mem1")
        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT membership_state FROM workspace_members "
                "WHERE workspace_id=? AND agent_name=?",
                (d["space_id"], "mem1"),
            ).fetchone()
        finally:
            conn.close()
        assert row is not None
        assert row[0] == "joined"


# --- Expired: signature valid, expires_at in past --------------------------


class TestExpired:
    def test_envelope_present_with_expired_claims(self, db_path):
        d = build_membership_pollen_expired(db_path, callsign="mem1")
        env = d["pollen_grain"]["envelope"]
        assert env is not None
        assert "claims" in env
        assert "signature" in env
        assert d["pollen_grain"]["tamper_kind"] == "expired"

    def test_check_not_expired_raises(self, db_path):
        d = build_membership_pollen_expired(db_path, callsign="mem1", expired_hours_ago=2)
        claims = d["pollen_grain"]["envelope"]["claims"]
        pollen = MembershipPollen.from_claims(claims)
        with pytest.raises(PollenExpiredError):
            pollen.check_not_expired()

    def test_signature_verifies_against_issuer_key(self, db_path):
        """The crypto is legit — it's only the expiration that's wrong."""
        d = build_membership_pollen_expired(db_path, callsign="mem1")
        # We don't have the public key exposed in the descriptor (by design —
        # fixtures don't leak private state) so just assert the envelope
        # carries a signature of the expected shape.
        sig = d["pollen_grain"]["envelope"]["signature"]
        assert isinstance(sig, str)
        assert len(sig) > 50  # Ed25519 sig base64url-encoded is ~88 chars


# --- Wrong space: legit sig, wrong space_id --------------------------------


class TestWrongSpace:
    def test_claim_space_differs_from_db_space(self, db_path):
        d = build_membership_pollen_for_wrong_space(db_path, callsign="mem1")
        claimed = d["pollen_grain"]["envelope"]["claims"]["space_id"]
        assert claimed == d["claimed_space_id"]
        assert claimed != d["actual_space_id"]

    def test_agent_is_member_of_actual_space_only(self, db_path):
        d = build_membership_pollen_for_wrong_space(db_path, callsign="mem1")
        conn = sqlite3.connect(db_path)
        try:
            rows = conn.execute(
                "SELECT workspace_id FROM workspace_members WHERE agent_name=?",
                ("mem1",),
            ).fetchall()
        finally:
            conn.close()
        assert len(rows) == 1
        assert rows[0][0] == d["actual_space_id"]


# --- Missing ledger: legit sig, no workspace_members row -------------------


class TestMissingLedger:
    def test_envelope_is_signed(self, db_path):
        d = build_membership_pollen_missing_ledger(db_path, callsign="mem1")
        assert d["pollen_grain"]["envelope"] is not None
        assert d["pollen_grain"]["tamper_kind"] == "missing_ledger"

    def test_no_membership_row_exists(self, db_path):
        d = build_membership_pollen_missing_ledger(db_path, callsign="mem1")
        conn = sqlite3.connect(db_path)
        try:
            count = conn.execute(
                "SELECT COUNT(*) FROM workspace_members "
                "WHERE agent_name=?",
                ("mem1",),
            ).fetchone()[0]
        finally:
            conn.close()
        assert count == 0

    def test_space_itself_exists(self, db_path):
        """The space is real — only the membership is missing."""
        d = build_membership_pollen_missing_ledger(db_path, callsign="mem1")
        conn = sqlite3.connect(db_path)
        try:
            count = conn.execute(
                "SELECT COUNT(*) FROM workspaces WHERE workspace_id=?",
                (d["space_id"],),
            ).fetchone()[0]
        finally:
            conn.close()
        assert count == 1


# --- Forged signature: claim key_id A, signed by keypair B -----------------


class TestForged:
    def test_claimed_and_actual_keys_differ(self, db_path):
        d = build_membership_pollen_forged_signature(db_path, callsign="mem1")
        assert d["pollen_grain"]["issuer_key_id"] == d["pollen_grain"]["envelope"]["claims"]["key_id"]
        assert d["forger_key_id"] != d["pollen_grain"]["issuer_key_id"]

    def test_signature_does_not_verify_against_claimed_key(self, db_path):
        """The signature must fail Ed25519 verify against the CLAIMED key.

        We don't have the claimed public key in the descriptor (by design),
        so we reconstruct the verification test by generating a fresh key
        with the same claimed key_id would be impossible — key_id is a
        hash of the public key. Instead we assert the envelope has the
        shape the verifier will reject: claims point at one key_id,
        signature was produced by a different keypair.
        """
        d = build_membership_pollen_forged_signature(db_path, callsign="mem1")
        claimed_key_id = d["pollen_grain"]["envelope"]["claims"]["key_id"]
        forger_key_id = d["forger_key_id"]
        assert claimed_key_id != forger_key_id


# --- Valid: positive control -----------------------------------------------


class TestValid:
    def test_tamper_kind_is_none(self, db_path):
        d = build_membership_pollen_valid(db_path, callsign="mem1")
        assert d["pollen_grain"]["tamper_kind"] is None

    def test_expires_at_is_in_future(self, db_path):
        d = build_membership_pollen_valid(db_path, callsign="mem1")
        claims = d["pollen_grain"]["envelope"]["claims"]
        pollen = MembershipPollen.from_claims(claims)
        # Does NOT raise — the grain is fresh.
        pollen.check_not_expired()

    def test_claim_space_matches_db_space(self, db_path):
        d = build_membership_pollen_valid(db_path, callsign="mem1")
        assert d["pollen_grain"]["envelope"]["claims"]["space_id"] == d["space_id"]

    def test_ledger_row_exists_for_claimed_space(self, db_path):
        d = build_membership_pollen_valid(db_path, callsign="mem1")
        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT membership_state FROM workspace_members "
                "WHERE workspace_id=? AND agent_name=?",
                (d["space_id"], "mem1"),
            ).fetchone()
        finally:
            conn.close()
        assert row is not None
        assert row[0] == "joined"


# --- Dispatch + vocabulary --------------------------------------------------


class TestDispatch:
    def test_build_membership_pollen_scenario_by_name(self, db_path):
        d = build_membership_pollen_scenario(
            "membership_pollen_valid", db_path, callsign="dispatch-test",
        )
        assert d["primary_callsign"] == "dispatch-test"
        assert d["pollen_grain"]["tamper_kind"] is None

    def test_unknown_scenario_raises(self, db_path):
        with pytest.raises(ValueError, match="Unknown membership-pollen scenario"):
            build_membership_pollen_scenario("imaginary", db_path)


class TestTamperKindVocabulary:
    """The tamper_kind field must come from the small documented vocabulary."""

    EXPECTED_TAMPER_KINDS = {None, "missing", "expired", "wrong_space", "missing_ledger", "forged"}

    def test_every_scenario_uses_documented_tamper_kind(self, tmp_path):
        for name, builder in MEMBERSHIP_POLLEN_SCENARIO_BUILDERS.items():
            path = str(tmp_path / f"{name}.db")
            WhispersDB(db_path=path)
            d = builder(path)
            assert d["pollen_grain"]["tamper_kind"] in self.EXPECTED_TAMPER_KINDS, (
                f"{name} emits undocumented tamper_kind="
                f"{d['pollen_grain']['tamper_kind']!r}"
            )

    def test_registry_covers_all_five_tamper_variants_plus_valid(self):
        tamper_kinds_seen = set()
        for name in MEMBERSHIP_POLLEN_SCENARIO_BUILDERS:
            # Name itself embeds the tamper kind; cheap lookup.
            if "missing_ledger" in name:
                tamper_kinds_seen.add("missing_ledger")
            elif "forged" in name:
                tamper_kinds_seen.add("forged")
            elif "wrong_space" in name:
                tamper_kinds_seen.add("wrong_space")
            elif "expired" in name:
                tamper_kinds_seen.add("expired")
            elif "missing" in name:
                tamper_kinds_seen.add("missing")
            elif "valid" in name:
                tamper_kinds_seen.add(None)
        assert tamper_kinds_seen == self.EXPECTED_TAMPER_KINDS
