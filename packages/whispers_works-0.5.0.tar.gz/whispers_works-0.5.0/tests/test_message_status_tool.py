from __future__ import annotations

import json

import httpx
import pytest
from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client

from whispers.server import create_app
from whispers.testing import WhispersTestHarness


def _tool_json(result):
    assert result
    text = result[0].text
    return json.loads(text)


@pytest.mark.asyncio
async def test_message_status_tool_reports_delivery_and_seen_timestamps():
    with WhispersTestHarness() as h:
        bob = h.make_client("bob")
        app = create_app(db_path=h.db_path)
        async with app.router.lifespan_context(app):
            transport = httpx.ASGITransport(app=app)
            async with httpx.AsyncClient(transport=transport, base_url="http://127.0.0.1") as http_client:
                async with streamable_http_client("http://127.0.0.1/mcp/", http_client=http_client) as streams:
                    read_stream, write_stream, _ = streams
                    async with ClientSession(read_stream, write_stream) as session:
                        await session.initialize()
                        await session.call_tool(
                            "bind_seat",
                            {
                                "requested_callsign": "alice",
                                "participant_profile": "desktop_ide_agent",
                            },
                        )

                        sent = await session.call_tool(
                            "send",
                            {
                                "to": "bob",
                                "subject": "Need review",
                                "body": "status please",
                            },
                        )
                        sent_payload = _tool_json(sent.content)
                        message_id = sent_payload["message_id"]

                        before_seen = await session.call_tool("message_status", {"message_id": message_id})
                        before_payload = _tool_json(before_seen.content)
                        assert before_payload["message_id"] == message_id
                        assert before_payload["sent_at"] is not None
                        assert before_payload["delivered_at"] is not None
                        assert before_payload["seen_at"] is None
                        assert before_payload["acked_at"] is None
                        assert before_payload["recipients"][0]["recipient_callsign"] == "bob"
                        assert before_payload["recipients"][0]["delivered_at"] is not None
                        assert before_payload["recipients"][0]["seen_at"] is None

                        bob.check_inbox(mark_seen=True)

                        after_seen = await session.call_tool("message_status", {"message_id": message_id})
                        after_payload = _tool_json(after_seen.content)
                        assert after_payload["seen_at"] is not None
                        assert after_payload["recipients"][0]["seen_at"] is not None
