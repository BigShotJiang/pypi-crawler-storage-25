from whispers.cli import cli, main as cli_main
from whispers.server import start, main as server_main


def test_console_script_backcompat_aliases_exist():
    assert cli is cli_main
    assert start is server_main
