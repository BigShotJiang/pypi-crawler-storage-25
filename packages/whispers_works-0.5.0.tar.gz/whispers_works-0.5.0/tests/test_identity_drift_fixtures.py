"""Smoke tests for the identity-drift scenario builders.

These are meta-tests: they verify each builder seeds what its descriptor
claims it seeds, respects the agent_cards.callsign UNIQUE constraint,
and emits a drift_signal from the documented vocabulary.

Real pollen-layer tests (how the pollen module responds to each
scenario) will live alongside the pollen module, not here.
"""

from __future__ import annotations

import sqlite3

import pytest

from whispers.storage.db import WhispersDB
from tests.fixtures.identity_drift_scenarios import (
    SCENARIO_BUILDERS,
    build_scenario,
    build_anchor_mismatch_same_callsign,
    build_agent_id_churn,
    build_tier_downgrade_mid_session,
    build_pair_space_membership_dropped,
    build_platform_family_conflict,
    build_callsign_rename_same_agent,
    build_ambiguous_live_sessions,
)


@pytest.fixture
def db_path(tmp_path):
    path = str(tmp_path / "drift.db")
    WhispersDB(db_path=path)
    return path


# --- Descriptor contract ---------------------------------------------------


class TestDescriptorShape:
    _REQUIRED = {
        "scenario",
        "seeded_callsigns",
        "primary_callsign",
        "current_agent_id",
        "prior_agent_ids",
        "current_anchor",
        "prior_anchors",
        "drift_signal",
        "what_a_pollen_layer_should_detect",
        "notes",
    }

    @pytest.mark.parametrize("scenario_name", sorted(SCENARIO_BUILDERS))
    def test_descriptor_has_required_keys(self, scenario_name, tmp_path):
        # Fresh DB per scenario so ledger/card constraints don't collide.
        path = str(tmp_path / f"{scenario_name}.db")
        WhispersDB(db_path=path)
        descriptor = SCENARIO_BUILDERS[scenario_name](path)
        missing = self._REQUIRED - set(descriptor.keys())
        assert not missing, f"{scenario_name} missing keys: {missing}"
        assert descriptor["scenario"] == scenario_name
        assert descriptor["drift_signal"]
        assert isinstance(descriptor["prior_agent_ids"], list)
        assert isinstance(descriptor["prior_anchors"], list)
        assert isinstance(descriptor["seeded_callsigns"], list)
        assert descriptor["current_agent_id"]  # non-empty
        assert descriptor["current_anchor"]


# --- Individual scenario shape assertions ----------------------------------


class TestAnchorMismatch:
    def test_one_current_card_plus_history_in_events(self, db_path):
        d = build_anchor_mismatch_same_callsign(db_path, callsign="tester")
        conn = sqlite3.connect(db_path)
        try:
            card_count = conn.execute(
                "SELECT COUNT(*) FROM agent_cards WHERE callsign=?", ("tester",),
            ).fetchone()[0]
            event_count = conn.execute(
                "SELECT COUNT(*) FROM identity_events "
                "WHERE callsign=? AND event_type='bind'",
                ("tester",),
            ).fetchone()[0]
            anchors_in_events = {
                r[0] for r in conn.execute(
                    "SELECT DISTINCT continuity_anchor FROM identity_events "
                    "WHERE callsign=?",
                    ("tester",),
                ).fetchall()
            }
        finally:
            conn.close()
        assert card_count == 1  # UNIQUE constraint honored
        assert event_count == 2  # prior + current bind logged
        assert d["current_anchor"] in anchors_in_events
        assert d["prior_anchors"][0] in anchors_in_events


class TestAgentIdChurn:
    def test_n_bind_events_n_agent_ids(self, db_path):
        d = build_agent_id_churn(db_path, callsign="churn", churn_count=4)
        conn = sqlite3.connect(db_path)
        try:
            rows = conn.execute(
                "SELECT DISTINCT agent_id FROM identity_events "
                "WHERE callsign=? AND event_type='bind'",
                ("churn",),
            ).fetchall()
        finally:
            conn.close()
        assert len({r[0] for r in rows}) == 4
        assert len(d["prior_agent_ids"]) == 3
        assert d["current_agent_id"] not in d["prior_agent_ids"]

    def test_latest_has_live_session(self, db_path):
        d = build_agent_id_churn(db_path, callsign="churn", churn_count=3)
        conn = sqlite3.connect(db_path)
        try:
            count = conn.execute(
                "SELECT COUNT(*) FROM agent_sessions "
                "WHERE agent_name=? AND agent_id=? "
                "AND lease_expires_at >= CURRENT_TIMESTAMP",
                ("churn", d["current_agent_id"]),
            ).fetchone()[0]
        finally:
            conn.close()
        assert count == 1


class TestTierDowngrade:
    def test_current_tier_matches_latest_trust_event(self, db_path):
        """Post-fix (per burr's T4.22 dogfood answer 2026-04-18): fixture
        now seeds the real-system shape — two trust_events with the
        downgrade recorded, and the card's trust_tier matches the latest."""
        d = build_tier_downgrade_mid_session(
            db_path, starting_tier=5, current_tier=1,
        )
        conn = sqlite3.connect(db_path)
        try:
            card_tier = conn.execute(
                "SELECT trust_tier FROM agent_cards WHERE callsign=?",
                (d["primary_callsign"],),
            ).fetchone()[0]
            events = conn.execute(
                "SELECT old_tier, new_tier, reason FROM trust_events "
                "WHERE agent_id=? ORDER BY created_at",
                (d["current_agent_id"],),
            ).fetchall()
        finally:
            conn.close()
        assert card_tier == 1
        # Two events: grant up to 5, then downgrade to 1.
        assert [r[1] for r in events] == [5, 1]
        # The downgrade event's reason surfaces the 'why' to an auditor.
        assert "mid-session" in events[1][2].lower()


class TestPairSpaceMembershipDropped:
    def test_asymmetric_membership_state(self, db_path):
        d = build_pair_space_membership_dropped(
            db_path, callsign="dropme", peer_callsign="keepme",
        )
        conn = sqlite3.connect(db_path)
        try:
            rows = conn.execute(
                "SELECT agent_name, membership_state FROM workspace_members "
                "WHERE workspace_id=? ORDER BY agent_name",
                (d["space_id"],),
            ).fetchall()
        finally:
            conn.close()
        by_name = {r[0]: r[1] for r in rows}
        assert by_name["dropme"] == "left"
        assert by_name["keepme"] == "joined"
        assert set(d["seeded_callsigns"]) == {"dropme", "keepme"}


class TestPlatformFamilyConflict:
    def test_current_card_has_new_family_history_has_old(self, db_path):
        d = build_platform_family_conflict(db_path, callsign="mover")
        conn = sqlite3.connect(db_path)
        try:
            card_family = conn.execute(
                "SELECT platform_family FROM agent_cards WHERE callsign=?",
                ("mover",),
            ).fetchone()[0]
            events = conn.execute(
                "SELECT details FROM identity_events "
                "WHERE callsign=? ORDER BY created_at",
                ("mover",),
            ).fetchall()
        finally:
            conn.close()
        assert card_family == "claude-code"
        import json
        families = [json.loads(r[0]).get("platform_family") for r in events]
        assert "script" in families
        assert "claude-code" in families


class TestCallsignRename:
    def test_same_anchor_and_ledger_successor_link(self, db_path):
        d = build_callsign_rename_same_agent(
            db_path, old_callsign="old", new_callsign="new",
        )
        conn = sqlite3.connect(db_path)
        try:
            # Only the new callsign has a card.
            card_callsigns = {
                r[0] for r in conn.execute(
                    "SELECT callsign FROM agent_cards WHERE callsign IN (?, ?)",
                    ("old", "new"),
                ).fetchall()
            }
            # Ledger has both, with old retired + successor link.
            retired = conn.execute(
                "SELECT status, successor_callsign FROM callsign_ledger "
                "WHERE callsign=?",
                ("old",),
            ).fetchone()
            # identity_events has a rename row.
            rename_count = conn.execute(
                "SELECT COUNT(*) FROM identity_events "
                "WHERE event_type='rename' AND callsign=?",
                ("new",),
            ).fetchone()[0]
        finally:
            conn.close()
        assert card_callsigns == {"new"}
        assert retired is not None
        assert retired[0] == "retired"
        assert retired[1] == "new"
        assert rename_count == 1


class TestAmbiguousLiveSessions:
    def test_one_card_two_live_sessions_different_agent_ids(self, db_path):
        d = build_ambiguous_live_sessions(db_path, callsign="both")
        conn = sqlite3.connect(db_path)
        try:
            card_count = conn.execute(
                "SELECT COUNT(*) FROM agent_cards WHERE callsign=?", ("both",),
            ).fetchone()[0]
            session_rows = conn.execute(
                "SELECT agent_id FROM agent_sessions "
                "WHERE agent_name=? AND lease_expires_at >= CURRENT_TIMESTAMP",
                ("both",),
            ).fetchall()
        finally:
            conn.close()
        assert card_count == 1
        agent_ids = {r[0] for r in session_rows}
        assert len(agent_ids) == 2
        assert d["current_agent_id"] in agent_ids
        assert d["prior_agent_ids"][0] in agent_ids


# --- UNIQUE constraint compliance (meta) -----------------------------------


class TestConstraintCompliance:
    @pytest.mark.parametrize("scenario_name", sorted(SCENARIO_BUILDERS))
    def test_never_violates_callsign_unique(self, scenario_name, tmp_path):
        """Every builder must produce a DB state where agent_cards.callsign
        UNIQUE holds — history lives in events/ledger, not duplicated cards."""
        path = str(tmp_path / f"{scenario_name}.db")
        WhispersDB(db_path=path)
        # Raises on any duplicate; simply running without exception is the
        # assertion.
        SCENARIO_BUILDERS[scenario_name](path)
        conn = sqlite3.connect(path)
        try:
            duplicates = conn.execute(
                "SELECT callsign, COUNT(*) FROM agent_cards "
                "GROUP BY callsign HAVING COUNT(*) > 1"
            ).fetchall()
        finally:
            conn.close()
        assert duplicates == [], (
            f"{scenario_name} seeded duplicate card rows: {duplicates}"
        )


# --- Dispatch + vocabulary --------------------------------------------------


class TestDispatchByName:
    def test_build_scenario_by_name(self, db_path):
        d = build_scenario(
            "anchor_mismatch_same_callsign", db_path, callsign="dispatch-test",
        )
        assert d["primary_callsign"] == "dispatch-test"

    def test_build_scenario_unknown_raises(self, db_path):
        with pytest.raises(ValueError, match="Unknown scenario"):
            build_scenario("imaginary_drift_mode", db_path)


class TestDriftSignalVocabulary:
    EXPECTED = {
        "anchor_mismatch_same_callsign",
        "agent_id_churn",
        "tier_downgrade_mid_session",
        "pair_space_membership_dropped",
        "platform_family_conflict",
        "callsign_rename_same_agent",
        "ambiguous_live_sessions",
    }

    def test_vocabulary_complete(self, tmp_path):
        for name in SCENARIO_BUILDERS:
            path = str(tmp_path / f"{name}.db")
            WhispersDB(db_path=path)
            d = SCENARIO_BUILDERS[name](path)
            assert d["drift_signal"] in self.EXPECTED, (
                f"{name} emits undocumented drift_signal={d['drift_signal']!r}"
            )

    def test_registry_keys_match_drift_signals(self):
        assert set(SCENARIO_BUILDERS.keys()) == self.EXPECTED
