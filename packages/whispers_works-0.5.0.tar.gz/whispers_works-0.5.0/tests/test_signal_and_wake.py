from __future__ import annotations

import contextlib
import json
import socket
import threading
import time
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer

import uvicorn
from fastapi.testclient import TestClient

from whispers.local_wake_runtime import LocalWakeRuntime
from whispers.testing import WhispersTestHarness
from whispers.server import _select_registered_wake_adapter, create_app
from whispers.twoack import DEFAULT_SCHEMA, WIRE_V, validate_envelope
from whispers.wake_bridge import WakeStreamBridge


@contextlib.contextmanager
def _running_server(db_path: str):
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]

    app = create_app(db_path=db_path)
    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    try:
        for _ in range(50):
            if server.started:
                break
            time.sleep(0.1)
        else:
            raise AssertionError("uvicorn server did not start in time")
        yield port
    finally:
        server.should_exit = True
        thread.join(timeout=5)


class TestSignalAndWake:
    def test_client_wake_and_chrome_projection_follow_reachability_and_attention(self):
        with WhispersTestHarness() as h:
            sender = h.make_client("sender")
            desk = h.make_client("desk", participant_profile="desktop_ide_agent")

            idle = desk.wake_status()
            assert idle["wake_projection"]["reachability_mode"] == "manual_wake"
            assert idle["wake_projection"]["recommended_action"]["action"] == "suppress"

            sender.send("desk", "Review this", body="need your eyes")
            active = desk.wake_status()
            assert active["wake_projection"]["recommended_action"]["action"] == "notify"
            assert active["chrome"]["wake"]["recommended_action"] == "notify"
            assert active["chrome"]["identity"]["session_name"] == "desk"
            assert active["chrome"]["signal_line"].startswith("⏦⏦⏦ desk · session:desk")
            assert "wake:notify" in active["chrome"]["signal_line"]

    def test_client_status_promotes_live_adapter_reachability_without_faking_listener_mode(self):
        with WhispersTestHarness() as h:
            desk = h.make_client("desk", participant_profile="desktop_ide_agent")

            desk.wake_register_adapter(
                adapter_kind="local_http_connector",
                supported_actions=["notify"],
                fallback_action="notify",
                state="ready",
                endpoint_url="http://127.0.0.1:9/wake",
            )

            status = desk.status()
            assert status["reachability_mode"] == "local_http_connector"
            assert status["wake_projection"]["reachability_mode"] == "local_http_connector"
            assert status["wake_projection"]["wake_model"] == "manual_wake"
            assert status["wake_projection"]["adapter"]["adapter_kind"] == "local_http_connector"
            assert status["wake_projection"]["adapter"]["state"] == "ready"
            assert status["chrome"]["wake"]["reachability_mode"] == "local_http_connector"
            assert status["chrome"]["wake"]["adapter_state"] == "ready"

    def test_server_status_exposes_wake_projection_and_chrome(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            connected = client.post(
                "/identity/connect",
                json={
                    "requested_callsign": "listener-one",
                    "participant_profile": "listener_agent",
                },
            )
            assert connected.status_code == 200
            status = connected.json()["status"]
            assert status["wake_projection"]["wake_model"] == "listener_backed"
            assert status["chrome"]["identity"]["agent_name"] == "listener-one"

            wake = client.get("/wake/listener-one")
            assert wake.status_code == 200
            assert wake.json()["wake_projection"]["adapter"]["fallback_action"] in {"notify", "stage_context", "suppress"}

            chrome = client.get("/chrome/listener-one")
            assert chrome.status_code == 200
            assert chrome.json()["chrome"]["identity"]["session_name"] == "listener-one"
            assert chrome.json()["chrome"]["signal_line"].startswith("⏦⏦⏦ listener-one · session:listener-one")
            assert "wake:" in chrome.json()["chrome"]["signal_line"]

            dashboard = client.get("/dashboard/listener-one")
            assert dashboard.status_code == 200
            assert "listener-one" in dashboard.text
            assert "Recent messages" in dashboard.text

    def test_signal_endpoint_registers_participant_and_delivers_message(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            recipient = client.post("/identity/connect", json={"requested_callsign": "alice"})
            assert recipient.status_code == 200

            signaled = client.post(
                "/signal",
                json={
                    "from": "doorbell",
                    "to": "alice",
                    "subject": "Button pressed",
                    "body": "Front door button pressed",
                    "participant_profiles": ["status_source"],
                    "basis": "observed",
                    "severity": "high",
                },
            )
            assert signaled.status_code == 200
            payload = signaled.json()
            assert payload["guided_profile"] == "status_source"
            assert payload["participant"]["participant_kind"] == "status_source"
            assert payload["delivery"]["delivery_status"] in {"delivered", "queued"}

            inbox = client.get("/agents/alice/inbox", params={"mark_seen": False})
            assert inbox.status_code == 200
            message = inbox.json()["messages"][0]
            assert message["subject"] == "Button pressed"
            assert message["msg_type"] == "participant_state"
            stored = client.get(f"/messages/{message['message_id']}")
            assert stored.status_code == 200
            assert stored.json()["message"]["metadata"]["whispers:signal"] is True

    def test_select_registered_wake_adapter_prefers_exact_support_over_fallback(self):
        adapter, action = _select_registered_wake_adapter(
            [
                {
                    "adapter_kind": "fallback-first",
                    "supported_actions": ["stage_context"],
                    "fallback_action": "notify",
                    "state": "supported",
                    "endpoint_url": "http://fallback.invalid/wake",
                },
                {
                    "adapter_kind": "exact-second",
                    "supported_actions": ["notify"],
                    "fallback_action": "suppress",
                    "state": "supported",
                    "endpoint_url": "http://exact.invalid/wake",
                },
            ],
            action="notify",
        )

        assert adapter is not None
        assert adapter["adapter_kind"] == "exact-second"
        assert action == "notify"

    def test_wake_adapter_registration_and_dispatch_records_events(self, monkeypatch):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            client.post("/identity/connect", json={"requested_callsign": "alice"})
            client.post(
                "/identity/connect",
                json={"requested_callsign": "desk", "participant_profile": "desktop_ide_agent"},
            )
            client.post(
                "/wake/desk/adapters",
                json={
                    "adapter_kind": "fallback-first",
                    "supported_actions": ["stage_context"],
                    "fallback_action": "notify",
                    "state": "supported",
                    "endpoint_url": "http://fallback.invalid/wake",
                },
            )
            client.post(
                "/wake/desk/adapters",
                json={
                    "adapter_kind": "local_http_connector",
                    "supported_actions": ["notify"],
                    "fallback_action": "notify",
                    "state": "supported",
                    "endpoint_url": "http://exact.invalid/wake",
                },
            )

            wake = client.get("/wake/desk")
            assert wake.status_code == 200
            assert wake.json()["wake_projection"]["reachability_mode"] == "local_http_connector"
            assert wake.json()["wake_projection"]["wake_model"] == "manual_wake"
            assert wake.json()["wake_projection"]["adapter"]["adapter_kind"] == "local_http_connector"
            assert wake.json()["wake_projection"]["adapter"]["state"] == "ready"
            assert wake.json()["chrome"]["wake"]["reachability_mode"] == "local_http_connector"
            assert wake.json()["chrome"]["wake"]["adapter_state"] == "ready"

            status = client.get("/status/desk")
            assert status.status_code == 200
            assert status.json()["reachability_mode"] == "local_http_connector"

            sent = client.post(
                "/messages/send",
                json={"sender": "alice", "recipient": "desk", "subject": "Need review", "body": "please check"},
            )
            assert sent.status_code == 200

            captured = {}

            class _Response:
                status = 200

                def __enter__(self):
                    return self

                def __exit__(self, exc_type, exc, tb):
                    return False

                def read(self):
                    return b'{"status":"ok"}'

            def _fake_urlopen(request, timeout=2):
                captured["url"] = request.full_url
                captured["timeout"] = timeout
                return _Response()

            monkeypatch.setattr(urllib.request, "urlopen", _fake_urlopen)

            dispatched = client.post("/wake/desk/dispatch")
            assert dispatched.status_code == 200
            body = dispatched.json()
            assert body["event"]["dispatch_status"] == "dispatched"
            assert body["packet"]["wire_v"] == WIRE_V
            assert body["packet"]["schema"] == DEFAULT_SCHEMA
            assert validate_envelope(body["packet"]) == []
            assert body["packet"]["wake"]["agent_name"] == "desk"
            assert captured["url"] == "http://exact.invalid/wake"

            events = client.get("/wake/desk/events")
            assert events.status_code == 200
            assert len(events.json()["events"]) >= 1

            adapters = client.get("/wake/desk/adapters")
            assert adapters.status_code == 200
            adapter_kinds = {adapter["adapter_kind"] for adapter in adapters.json()["adapters"]}
            assert {"fallback-first", "local_http_connector"}.issubset(adapter_kinds)

    def test_local_http_connector_receives_real_loopback_wake(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            client.post("/identity/connect", json={"requested_callsign": "alice"})
            client.post(
                "/identity/connect",
                json={"requested_callsign": "desk", "participant_profile": "desktop_ide_agent"},
            )

            received: dict[str, object] = {}
            received_event = threading.Event()

            class _WakeHandler(BaseHTTPRequestHandler):
                def do_POST(self):  # noqa: N802
                    length = int(self.headers.get("Content-Length") or "0")
                    raw = self.rfile.read(length)
                    received["path"] = self.path
                    received["packet"] = json.loads(raw.decode("utf-8"))
                    received_event.set()
                    self.send_response(200)
                    self.send_header("Content-Type", "application/json")
                    self.end_headers()
                    self.wfile.write(b'{"status":"ok"}')

                def log_message(self, format, *args):  # noqa: A003
                    return

            server = HTTPServer(("127.0.0.1", 0), _WakeHandler)
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()

            try:
                endpoint_url = f"http://127.0.0.1:{server.server_port}/wake"
                registered = client.post(
                    "/wake/desk/adapters",
                    json={
                        "adapter_kind": "local_http_connector",
                        "supported_actions": ["notify"],
                        "fallback_action": "notify",
                        "state": "supported",
                        "endpoint_url": endpoint_url,
                    },
                )
                assert registered.status_code == 200

                sent = client.post(
                    "/messages/send",
                    json={"sender": "alice", "recipient": "desk", "subject": "Need review", "body": "please check"},
                )
                assert sent.status_code == 200

                dispatched = client.post("/wake/desk/dispatch")
                assert dispatched.status_code == 200
                assert dispatched.json()["event"]["dispatch_status"] == "dispatched"

                assert received_event.wait(timeout=2), "local_http_connector did not receive a real loopback wake"
                packet = received.get("packet")
                assert received.get("path") == "/wake"
                assert isinstance(packet, dict)
                assert packet["wire_v"] == WIRE_V
                assert packet["schema"] == DEFAULT_SCHEMA
                assert validate_envelope(packet) == []
                assert packet["wake"]["agent_name"] == "desk"
            finally:
                server.shutdown()
                server.server_close()
                thread.join(timeout=1)

    def test_wake_stream_pushes_live_event(self):
        with WhispersTestHarness() as h:
            with _running_server(h.db_path) as port:
                base_url = f"http://127.0.0.1:{port}"

                def _post_json(path: str, payload: dict[str, object]) -> dict[str, object]:
                    body = json.dumps(payload).encode("utf-8")
                    request = urllib.request.Request(
                        f"{base_url}{path}",
                        data=body,
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    with urllib.request.urlopen(request, timeout=10) as response:
                        assert response.status == 200
                        return json.loads(response.read().decode("utf-8"))

                _post_json("/identity/connect", {"requested_callsign": "alice"})
                _post_json(
                    "/identity/connect",
                    {"requested_callsign": "desk", "participant_profile": "desktop_ide_agent"},
                )

                received: dict[str, object] = {}
                stream_ready = threading.Event()
                stream_received = threading.Event()

                def _consume_stream() -> None:
                    request = urllib.request.Request(
                        f"{base_url}/wake/desk/stream",
                        headers={"Accept": "text/event-stream"},
                        method="GET",
                    )
                    with urllib.request.urlopen(request, timeout=10) as response:
                        assert response.status == 200
                        stream_ready.set()
                        while True:
                            raw_line = response.readline()
                            if not raw_line:
                                break
                            line = raw_line.decode("utf-8").strip()
                            if not line or not line.startswith("data: "):
                                continue
                            payload = json.loads(line[6:])
                            if payload.get("agent_name") == "desk":
                                received["event"] = payload
                                stream_received.set()
                                break

                consumer = threading.Thread(target=_consume_stream, daemon=True)
                consumer.start()
                assert stream_ready.wait(timeout=2), "wake stream did not connect"

                _post_json(
                    "/messages/send",
                    {"sender": "alice", "recipient": "desk", "subject": "Need review", "body": "please check"},
                )
                dispatched = _post_json("/wake/desk/dispatch", {})
                event = dispatched["event"]

                assert stream_received.wait(timeout=2), "wake stream did not receive live wake event"
                streamed = received.get("event")
                assert isinstance(streamed, dict)
                assert streamed["event_id"] == event["event_id"]
                assert streamed["dispatch_status"] == event["dispatch_status"]
                assert streamed["agent_name"] == "desk"
                consumer.join(timeout=1)

    def test_wake_stream_bridge_forwards_packet_to_local_connector(self):
        with WhispersTestHarness() as h:
            with _running_server(h.db_path) as port:
                base_url = f"http://127.0.0.1:{port}"

                def _post_json(path: str, payload: dict[str, object]) -> dict[str, object]:
                    body = json.dumps(payload).encode("utf-8")
                    request = urllib.request.Request(
                        f"{base_url}{path}",
                        data=body,
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    with urllib.request.urlopen(request, timeout=10) as response:
                        assert response.status == 200
                        return json.loads(response.read().decode("utf-8"))

                _post_json("/identity/connect", {"requested_callsign": "alice"})
                _post_json(
                    "/identity/connect",
                    {"requested_callsign": "desk", "participant_profile": "desktop_ide_agent"},
                )

                received: dict[str, object] = {}
                received_event = threading.Event()

                class _WakeHandler(BaseHTTPRequestHandler):
                    def do_POST(self):  # noqa: N802
                        length = int(self.headers.get("Content-Length") or "0")
                        raw = self.rfile.read(length)
                        received["path"] = self.path
                        received["packet"] = json.loads(raw.decode("utf-8"))
                        received_event.set()
                        self.send_response(200)
                        self.send_header("Content-Type", "application/json")
                        self.end_headers()
                        self.wfile.write(b'{"status":"ok"}')

                    def log_message(self, format, *args):  # noqa: A003
                        return

                server = HTTPServer(("127.0.0.1", 0), _WakeHandler)
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                thread.start()

                try:
                    bridge = WakeStreamBridge(
                        base_url,
                        "desk",
                        f"http://127.0.0.1:{server.server_port}/wake",
                        after_event_id=0,
                        read_timeout=10.0,
                    )
                    bridge_thread = threading.Thread(
                        target=bridge.run_until_forwarded,
                        kwargs={"max_events": 1},
                        daemon=True,
                    )
                    bridge_thread.start()

                    _post_json(
                        "/messages/send",
                        {"sender": "alice", "recipient": "desk", "subject": "Need review", "body": "please check"},
                    )
                    dispatched = _post_json("/wake/desk/dispatch", {})

                    assert dispatched["event"]["dispatch_status"] == "staged_no_adapter"
                    assert received_event.wait(timeout=3), "wake stream bridge did not forward packet to local connector"
                    bridge_thread.join(timeout=1)
                    packet = received.get("packet")
                    assert received.get("path") == "/wake"
                    assert isinstance(packet, dict)
                    assert packet["wire_v"] == WIRE_V
                    assert packet["schema"] == DEFAULT_SCHEMA
                    assert validate_envelope(packet) == []
                    assert packet["wake"]["agent_name"] == "desk"
                    assert bridge.last_event_id == dispatched["event"]["event_id"]
                finally:
                    server.shutdown()
                    server.server_close()
                    thread.join(timeout=1)

    def test_local_wake_runtime_auto_registers_and_receives_dispatch(self):
        with WhispersTestHarness() as h:
            with _running_server(h.db_path) as port:
                base_url = f"http://127.0.0.1:{port}"

                def _post_json(path: str, payload: dict[str, object]) -> dict[str, object]:
                    body = json.dumps(payload).encode("utf-8")
                    request = urllib.request.Request(
                        f"{base_url}{path}",
                        data=body,
                        headers={"Content-Type": "application/json"},
                        method="POST",
                    )
                    with urllib.request.urlopen(request, timeout=10) as response:
                        assert response.status == 200
                        return json.loads(response.read().decode("utf-8"))

                _post_json("/identity/connect", {"requested_callsign": "alice"})
                _post_json(
                    "/identity/connect",
                    {"requested_callsign": "desk", "participant_profile": "desktop_ide_agent"},
                )

                runtime = LocalWakeRuntime()
                runtime.start()
                try:
                    registration = runtime.register_adapter(base_url, "desk")
                    adapter_kinds = {adapter["adapter_kind"] for adapter in registration["adapters"]}
                    assert "local_http_connector" in adapter_kinds

                    _post_json(
                        "/messages/send",
                        {"sender": "alice", "recipient": "desk", "subject": "Need review", "body": "please check"},
                    )
                    dispatched = _post_json("/wake/desk/dispatch", {})
                    assert dispatched["event"]["dispatch_status"] == "dispatched"

                    packet = runtime.wait_for_packet(timeout=2)
                    assert isinstance(packet, dict)
                    assert packet["wire_v"] == WIRE_V
                    assert packet["schema"] == DEFAULT_SCHEMA
                    assert validate_envelope(packet) == []
                    assert packet["wake"]["agent_name"] == "desk"
                finally:
                    runtime.stop()

    def test_signal_browser_surface_exists(self):
        with WhispersTestHarness() as h:
            app = create_app(db_path=h.db_path)
            client = TestClient(app)

            response = client.get(
                "/signal/browser",
                params={
                    "from": "phone-approval",
                    "to": "alice",
                    "subject": "Need approval",
                    "participant_profiles": ["approval_surface"],
                },
            )
            assert response.status_code == 200
            assert "Whispers browser signal" in response.text
            assert "phone-approval" in response.text
