from __future__ import annotations

import pytest

from whispers.disclosure import DisclosureLabel, disclosure_ring_rank, is_more_public, normalize_disclosure_ring
from whispers.operator_descriptor import (
    ContactPath,
    PublicOperatorDescriptor,
    PublicPresentation,
    VerificationMethod,
    operator_descriptor_from_dict,
)


def test_disclosure_ring_normalization_and_ranking():
    assert normalize_disclosure_ring("Public") == "public"
    assert disclosure_ring_rank("vault") < disclosure_ring_rank("public")
    assert is_more_public("trusted", "public") is True


def test_disclosure_label_requires_valid_ring():
    label = DisclosureLabel(ring="trusted", basis="declared")
    assert label.to_dict()["ring"] == "trusted"
    with pytest.raises(ValueError):
        DisclosureLabel(ring="not-a-ring")


def test_public_operator_descriptor_round_trips_and_projects_cards():
    descriptor = PublicOperatorDescriptor(
        public_handle="zturner",
        stable_anchor_ref="did:whispers:zack",
        display_name="Zack Turner",
        description="Builder of Whispers",
        presentations=(
            PublicPresentation(surface="profile", address="https://whispers.works/@zturner", protocol="https"),
        ),
        verification_methods=(
            VerificationMethod(kind="dns", ref="_whispers.zacharyturner.com"),
        ),
        contact_paths=(
            ContactPath(kind="intro_form", address="https://whispers.works/contact/zturner", policy_ref="policy:public-intro"),
        ),
        policy_refs=("policy:public-intro",),
        supported_proof_kinds=("signature", "domain_proof"),
    )

    payload = descriptor.to_dict()
    assert payload["public_handle"] == "zturner"
    assert payload["disclosure_tier"] == "public"
    assert payload["presentations"][0]["surface"] == "profile"

    scan = descriptor.as_operator_card(card_kind="scan")
    compact = descriptor.as_operator_card(card_kind="compact_agent")
    human = descriptor.as_operator_card(card_kind="human_public")

    assert "presentations" not in scan
    assert compact["supported_proof_kinds"] == ["signature", "domain_proof"]
    assert human["contact_paths"][0]["kind"] == "intro_form"

    rebuilt = operator_descriptor_from_dict(payload)
    assert rebuilt.public_handle == descriptor.public_handle
    assert rebuilt.presentations[0].address == descriptor.presentations[0].address


def test_public_operator_descriptor_rejects_non_public_like_ring():
    with pytest.raises(ValueError, match="disclosure_tier"):
        PublicOperatorDescriptor(
            public_handle="zturner",
            stable_anchor_ref="did:whispers:zack",
            display_name="Zack Turner",
            description="Builder of Whispers",
            disclosure_tier="private",
        )
