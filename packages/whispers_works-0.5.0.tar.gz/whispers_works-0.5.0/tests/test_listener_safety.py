"""Tests for W3 — SafetyGuardrails.

Guards between WakePolicyStack and backend dispatch. Four independent
checks from a single SafetyGuardrails instance:

  * rate_limit — per-hour cap on handler invocations
  * loop_detect — self-reply within a short window
  * budget_cap — inferences_used_last_hour vs max_inferences_per_hour
  * kill_switch — external file flag, rechecked per verify() call

Hard-bar acceptance from burr's brief:

  * Each guardrail independently togglable.
  * Each emits a blocked_reason the capsule surfaces.
  * Flipping kill-switch file pauses all listener inference globally
    within 1 SSE tick.
  * Budget exhaustion → capsule reports budget_limited=true and
    recommended_action="suppress".

Design decisions made explicit:

1. **SafetyBlocked base class.** Engine currently catches
   (RateLimitExceeded, LoopDetected). New blocks (BudgetExhausted,
   KillSwitchActive) need engine awareness. Cleanest: introduce a
   SafetyBlocked base, subclass all four under it, one-line engine
   catch-clause update. Preserves the contract while allowing extension.

2. **Dataclass config, TOML loader is a follow-on.** The brief names
   TOML as the config source. For the initial ship, SafetyConfig is a
   plain dataclass with explicit fields. A TOML → SafetyConfig loader
   is trivial follow-on work and keeps the initial implementation
   testable without TOML parsing in the hot path.

3. **Kill-switch re-reads file on every verify() call.** Not cached.
   This is the 1-SSE-tick responsiveness burr's hard-bar demands — the
   file system IS the sync point, polled at handler frequency.
"""
from __future__ import annotations

import time
from pathlib import Path

import pytest

from whispers.listeners.safety import (
    BudgetExhausted,
    KillSwitchActive,
    LoopDetected,
    RateLimitExceeded,
    SafetyBlocked,
    SafetyConfig,
    SafetyGuardrails,
)


def _make_event(**overrides) -> dict:
    event = {
        "kind": "wake",
        "event_id": 1,
        "priority": "routine",
        "msg_type": "inform",
        "body": "hello",
        "sender": "peer",
        "payload": {},
    }
    event.update(overrides)
    return event


# ---- Exception hierarchy --------------------------------------------------


class TestExceptionHierarchy:
    def test_all_blocks_inherit_SafetyBlocked(self):
        assert issubclass(RateLimitExceeded, SafetyBlocked)
        assert issubclass(LoopDetected, SafetyBlocked)
        assert issubclass(BudgetExhausted, SafetyBlocked)
        assert issubclass(KillSwitchActive, SafetyBlocked)

    def test_exceptions_carry_blocked_reason(self):
        exc = RateLimitExceeded("60/hour cap hit")
        assert exc.blocked_reason == "60/hour cap hit"


# ---- Rate limit -----------------------------------------------------------


class TestRateLimit:
    def test_passes_under_cap(self):
        config = SafetyConfig(rate_limit_per_hour=10)
        safety = SafetyGuardrails(config=config)
        for _ in range(5):
            safety.verify(_make_event())  # should not raise

    def test_raises_when_cap_hit(self):
        config = SafetyConfig(rate_limit_per_hour=3)
        safety = SafetyGuardrails(config=config)
        for _ in range(3):
            safety.verify(_make_event())
        with pytest.raises(RateLimitExceeded) as excinfo:
            safety.verify(_make_event())
        assert "rate" in excinfo.value.blocked_reason.lower()

    def test_togglable_off_via_config(self):
        config = SafetyConfig(rate_limit_per_hour=None)
        safety = SafetyGuardrails(config=config)
        for _ in range(100):
            safety.verify(_make_event())  # should not raise


# ---- Loop detect ----------------------------------------------------------


class TestLoopDetect:
    def test_passes_on_peer_traffic(self):
        config = SafetyConfig(
            loop_window_seconds=30, self_callsign="burr"
        )
        safety = SafetyGuardrails(config=config)
        safety.verify(_make_event(sender="alice"))
        safety.verify(_make_event(sender="alice"))

    def test_raises_on_rapid_self_reply(self):
        config = SafetyConfig(
            loop_window_seconds=30, self_callsign="burr"
        )
        safety = SafetyGuardrails(config=config)
        safety.verify(_make_event(sender="burr"))
        with pytest.raises(LoopDetected):
            safety.verify(_make_event(sender="burr"))

    def test_passes_on_self_reply_outside_window(self):
        config = SafetyConfig(
            loop_window_seconds=1, self_callsign="burr"
        )
        safety = SafetyGuardrails(config=config, now=lambda: 100.0)
        safety.verify(_make_event(sender="burr"))
        # Advance time past the window.
        safety._now = lambda: 102.0  # noqa: SLF001
        safety.verify(_make_event(sender="burr"))

    def test_togglable_off_via_config(self):
        config = SafetyConfig(
            loop_window_seconds=None, self_callsign="burr"
        )
        safety = SafetyGuardrails(config=config)
        for _ in range(10):
            safety.verify(_make_event(sender="burr"))


# ---- Budget cap -----------------------------------------------------------


class TestBudgetCap:
    def test_passes_when_budget_usage_below_cap(self):
        def usage():
            return 5

        config = SafetyConfig(
            max_inferences_per_hour=10, inferences_used_last_hour=usage
        )
        safety = SafetyGuardrails(config=config)
        safety.verify(_make_event())

    def test_raises_when_budget_exhausted(self):
        def usage():
            return 10

        config = SafetyConfig(
            max_inferences_per_hour=10, inferences_used_last_hour=usage
        )
        safety = SafetyGuardrails(config=config)
        with pytest.raises(BudgetExhausted) as excinfo:
            safety.verify(_make_event())
        assert "budget" in excinfo.value.blocked_reason.lower()

    def test_togglable_off_via_config(self):
        config = SafetyConfig(max_inferences_per_hour=None)
        safety = SafetyGuardrails(config=config)
        for _ in range(100):
            safety.verify(_make_event())


# ---- Kill switch ----------------------------------------------------------


class TestKillSwitch:
    def test_passes_when_file_absent(self, tmp_path: Path):
        ks = tmp_path / "LISTENER_KILL"
        config = SafetyConfig(kill_switch_path=str(ks))
        safety = SafetyGuardrails(config=config)
        safety.verify(_make_event())

    def test_raises_when_file_present(self, tmp_path: Path):
        ks = tmp_path / "LISTENER_KILL"
        ks.write_text("halt", encoding="utf-8")
        config = SafetyConfig(kill_switch_path=str(ks))
        safety = SafetyGuardrails(config=config)
        with pytest.raises(KillSwitchActive) as excinfo:
            safety.verify(_make_event())
        assert "kill" in excinfo.value.blocked_reason.lower()

    def test_hard_bar_pause_then_resume(self, tmp_path: Path):
        """Flipping the file pauses all inference; removing un-pauses.
        Must resolve within one verify() call — the file IS the sync
        point, not a cached flag."""
        ks = tmp_path / "LISTENER_KILL"
        config = SafetyConfig(kill_switch_path=str(ks))
        safety = SafetyGuardrails(config=config)

        safety.verify(_make_event())  # file absent, pass

        ks.write_text("halt", encoding="utf-8")
        with pytest.raises(KillSwitchActive):
            safety.verify(_make_event())  # file present, block — immediate

        ks.unlink()
        safety.verify(_make_event())  # file gone, resume — immediate

    def test_togglable_off_via_config(self, tmp_path: Path):
        ks = tmp_path / "LISTENER_KILL"
        ks.write_text("halt", encoding="utf-8")
        config = SafetyConfig(kill_switch_path=None)
        safety = SafetyGuardrails(config=config)
        safety.verify(_make_event())  # kill-switch disabled, pass


# ---- Blocked-reason surface for the capsule ------------------------------


class TestBlockedReasonSurface:
    """Each guardrail emits a blocked_reason the capsule surfaces honestly.
    The reason is on the exception itself so callers (engine, capsule
    builder) can read it uniformly."""

    def test_rate_limit_reason_is_structured(self):
        config = SafetyConfig(rate_limit_per_hour=1)
        safety = SafetyGuardrails(config=config)
        safety.verify(_make_event())
        with pytest.raises(SafetyBlocked) as excinfo:
            safety.verify(_make_event())
        reason = excinfo.value.blocked_reason
        assert isinstance(reason, str)
        assert len(reason) > 0

    def test_budget_limited_flag_readable_after_block(self):
        """After BudgetExhausted fires, the capsule should be able to read
        `budget_limited: true` from the SafetyGuardrails instance."""
        def usage():
            return 10

        config = SafetyConfig(
            max_inferences_per_hour=10, inferences_used_last_hour=usage
        )
        safety = SafetyGuardrails(config=config)
        with pytest.raises(BudgetExhausted):
            safety.verify(_make_event())
        assert safety.capsule_snapshot()["budget_limited"] is True
        assert safety.capsule_snapshot()["recommended_action"] == "suppress"

    def test_capsule_snapshot_honest_when_unblocked(self):
        config = SafetyConfig(max_inferences_per_hour=10,
                              inferences_used_last_hour=lambda: 3)
        safety = SafetyGuardrails(config=config)
        safety.verify(_make_event())
        snap = safety.capsule_snapshot()
        assert snap["budget_limited"] is False


# ---- Engine contract preservation ----------------------------------------


class TestEngineContract:
    def test_default_permissive_SafetyGuardrails_never_raises(self):
        """Engine's existing default (no config) must stay permissive so
        tests that don't care about safety still pass."""
        safety = SafetyGuardrails()
        for _ in range(20):
            safety.verify(_make_event())

    def test_RateLimitExceeded_name_preserved(self):
        """Engine imports this name specifically. Must not rename."""
        from whispers.listeners.safety import RateLimitExceeded as _rl
        assert _rl.__name__ == "RateLimitExceeded"

    def test_LoopDetected_name_preserved(self):
        from whispers.listeners.safety import LoopDetected as _ld
        assert _ld.__name__ == "LoopDetected"
