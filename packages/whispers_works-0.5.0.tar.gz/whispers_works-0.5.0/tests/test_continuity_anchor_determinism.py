from __future__ import annotations

import pytest

from whispers.client import WhispersConflictError
from whispers.testing import WhispersTestHarness


class TestDeterministicContinuityAnchor:
    def test_same_host_user_platform_and_callsign_reuse_same_anchor(self, monkeypatch):
        monkeypatch.setenv("WHISPERS_CONTINUITY_HOST_ID", "host-a")
        monkeypatch.setenv("WHISPERS_CONTINUITY_USER_ID", "zack")

        with WhispersTestHarness() as h:
            first = h.make_client(
                "alice",
                platform_family="codex",
                context_hint="main-worktree",
            )
            second = h.make_client(
                "alice",
                platform_family="codex",
                context_hint="review-worktree",
            )

            assert first.identity_resolution is not None
            assert second.identity_resolution is not None
            assert first.identity_resolution["continuity_anchor"] == second.identity_resolution["continuity_anchor"]
            assert second.identity_resolution["outcome"] == "rebind_accepted"

    def test_different_callsigns_derive_different_anchors(self, monkeypatch):
        monkeypatch.setenv("WHISPERS_CONTINUITY_HOST_ID", "host-a")
        monkeypatch.setenv("WHISPERS_CONTINUITY_USER_ID", "zack")

        with WhispersTestHarness() as h:
            alice = h.make_client("alice", platform_family="codex")
            bob = h.make_client("bob", platform_family="codex")

            assert alice.identity_resolution is not None
            assert bob.identity_resolution is not None
            assert alice.identity_resolution["continuity_anchor"] != bob.identity_resolution["continuity_anchor"]

    def test_different_platform_family_shares_anchor_post_slice_9(self, monkeypatch):
        """Slice 9: platform_family is no longer an anchor-derivation input.
        Same (host, owner, callsign) → same anchor regardless of platform.
        This reverses the pre-Slice-9 behavior where the same agent binding
        via codex one day and claude-code another produced a collision.
        Legitimate concurrent presentations still use sibling_label.
        """
        monkeypatch.setenv("WHISPERS_CONTINUITY_HOST_ID", "host-a")
        monkeypatch.setenv("WHISPERS_CONTINUITY_USER_ID", "zack")

        with WhispersTestHarness() as h:
            codex = h.make_client("alice", platform_family="codex")
            claude = h.make_client("alice", platform_family="claude-code")

            assert codex.identity_resolution is not None
            assert claude.identity_resolution is not None
            assert (
                codex.identity_resolution["continuity_anchor"]
                == claude.identity_resolution["continuity_anchor"]
            )
            assert claude.identity_resolution["outcome"] == "rebind_accepted"
            assert claude.agent_name == "alice"

            sibling = h.make_client(
                "alice",
                platform_family="claude-code",
                sibling_label="claude",
            )
            assert sibling.identity_resolution is not None
            assert sibling.identity_resolution["outcome"] == "sibling_instance_allocated"
            assert sibling.agent_name != "alice"

    def test_cross_host_requires_explicit_continuation_workflow(self, monkeypatch):
        monkeypatch.setenv("WHISPERS_CONTINUITY_HOST_ID", "host-a")
        monkeypatch.setenv("WHISPERS_CONTINUITY_USER_ID", "zack")

        with WhispersTestHarness() as h:
            first = h.make_client("alice", platform_family="codex")
            assert first.identity_resolution is not None
            original_anchor = first.identity_resolution["continuity_anchor"]

            monkeypatch.setenv("WHISPERS_CONTINUITY_HOST_ID", "host-b")
            with pytest.raises(WhispersConflictError):
                h.make_client("alice", platform_family="codex")

            continued = h.make_client(
                "alice",
                platform_family="codex",
                continuity_anchor=original_anchor,
            )
            assert continued.identity_resolution is not None
            assert continued.identity_resolution["outcome"] == "rebind_accepted"
            assert continued.identity_resolution["continuity_anchor"] == original_anchor
