from __future__ import annotations

from whispers.agent_portfolio import AgentPortfolioEntry, assess_portfolio_novelty


def test_assess_portfolio_novelty_detects_new_capability_surface_and_resource():
    existing = [
        AgentPortfolioEntry(
            agent="claude",
            declared_competencies=("architecture",),
            observed_competencies=("architecture",),
            cost_tier="high",
            latency_tier="medium",
            surfaces=("claude-code",),
            attached_resources=("repo",),
            observed_effectiveness=0.9,
        )
    ]
    candidate = AgentPortfolioEntry(
        agent="new-agent",
        declared_competencies=("retrieval",),
        observed_competencies=("retrieval",),
        cost_tier="low",
        latency_tier="fast",
        surfaces=("ide-pane",),
        attached_resources=("memory-system",),
    )

    assessment = assess_portfolio_novelty(candidate, existing)
    assert "capability_novelty" in assessment.novelty_kinds
    assert "cost_advantage" in assessment.novelty_kinds
    assert "latency_advantage" in assessment.novelty_kinds
    assert "surface_novelty" in assessment.novelty_kinds
    assert "resource_novelty" in assessment.novelty_kinds
    assert "retrieval" in assessment.differentiators
    assert "surface:ide-pane" in assessment.differentiators
    assert "resource:memory-system" in assessment.differentiators


def test_assess_portfolio_novelty_preserves_unknowns_when_not_enough_is_known():
    existing = [AgentPortfolioEntry(agent="claude", declared_competencies=("architecture",))]
    candidate = AgentPortfolioEntry(agent="mystery", declared_competencies=("architecture",))

    assessment = assess_portfolio_novelty(candidate, existing)
    assert assessment.novelty_kinds == ("no_clear_differentiator_yet",)
    assert "cost profile unknown" in assessment.open_questions
    assert "latency profile unknown" in assessment.open_questions
    assert "effectiveness unproven" in assessment.open_questions
    assert "observed competencies not established" in assessment.open_questions
