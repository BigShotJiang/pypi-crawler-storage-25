"""Whispers Orient — startup-mechanics acceptance tests.

Covers the state machine + fail-closed bind contract that underpins the
orientation feature (see .planning/active/STARTUP-MECHANICS-OVERHAUL-2026-04-17.md
and C:/Users/Zachary Turner/.claude/plans/glittery-shimmying-tome.md).

Slice 0 (this file, this commit) exercises the state machine skeleton only.
Subsequent slices (1..5) will add tests for identity/truths composition,
Claude-session-ID plumbing, wake auto-registration, trust inheritance, and
center/anchors — each slice lands its own tests before implementation.

Run: pytest tests/test_startup_mechanics.py -v
"""

from __future__ import annotations

import pytest

from whispers.orientation import (
    OrientationError,
    OrientationResult,
    OrientationState,
    OrientationStateMachine,
    STATE_ORDER,
    build_anchors_section,
    build_center_section,
    build_identity_section,
    build_truths_section,
    find_reference_docs,
    find_sibling_agents,
    resolve_trust_tier,
    resolve_working_scope,
)


# ---------------------------------------------------------------------------
# State machine — happy path
# ---------------------------------------------------------------------------


class TestHappyPath:
    """Full UNBOUND → ORIENTED traversal with no handler failures."""

    def test_fresh_machine_starts_unbound(self):
        """A newly-constructed machine reports state=UNBOUND before run().

        FIX: check OrientationStateMachine.__init__ — must initialize
        self.state = OrientationState.UNBOUND.
        """
        m = OrientationStateMachine()
        assert m.state == OrientationState.UNBOUND

    def test_run_with_no_handlers_reaches_oriented(self):
        """With no handlers registered, run() advances through every state
        and returns bound=True, orientation_state='ORIENTED'.

        The skeleton must not require handlers to exist — later slices will
        register real work; Slice 0 must still be runnable end-to-end as an
        empty machine.
        FIX: OrientationStateMachine.run() — handler lookup must tolerate
        None/missing handlers and advance anyway.
        """
        m = OrientationStateMachine()
        result = m.run()
        assert result.bound is True
        assert result.orientation_state == OrientationState.ORIENTED.value
        assert result.failed_at is None
        assert result.reason is None

    def test_run_advances_state_observably(self):
        """After run() succeeds, the machine's .state reflects ORIENTED.

        The observable-state invariant is critical: operators reading status
        must see exactly where orientation is (or got stuck).
        FIX: OrientationStateMachine.run() must update self.state AFTER each
        successful handler, not before.
        """
        m = OrientationStateMachine()
        m.run()
        assert m.state == OrientationState.ORIENTED

    def test_run_is_idempotent_when_already_oriented(self):
        """Calling run() on an already-ORIENTED machine is a no-op.

        FIX: OrientationStateMachine.run() — current_idx lookup must handle
        the ORIENTED case without IndexError.
        """
        m = OrientationStateMachine()
        m.run()
        result = m.run()
        assert result.bound is True
        assert result.orientation_state == OrientationState.ORIENTED.value


# ---------------------------------------------------------------------------
# State machine — ordering and handler invocation
# ---------------------------------------------------------------------------


class TestOrdering:
    """Handlers are called in STATE_ORDER, exactly once per state, in sequence."""

    def test_handlers_called_in_state_order(self):
        """Handlers fire in the canonical STATE_ORDER sequence.

        The plan's state machine table is load-bearing — bind must complete
        identity before statusline, statusline before wake, etc. Out-of-order
        invocation breaks the plan's atomic-surface-sync guarantee.
        FIX: OrientationStateMachine.run() — iterate STATE_ORDER from
        current_idx+1; do not reorder.
        """
        calls: list[OrientationState] = []
        m = OrientationStateMachine()
        for state in STATE_ORDER[1:]:  # skip UNBOUND (starting state has no handler)
            m.set_handler(state, lambda s=state: calls.append(s))
        m.run()
        expected = [s for s in STATE_ORDER if s != OrientationState.UNBOUND]
        assert calls == expected

    def test_handler_invoked_exactly_once(self):
        """A handler registered for a state is invoked exactly once in run()."""
        counter = {"n": 0}
        m = OrientationStateMachine()
        m.set_handler(OrientationState.BINDING, lambda: counter.__setitem__("n", counter["n"] + 1))
        m.run()
        assert counter["n"] == 1

    def test_state_order_contains_nine_states(self):
        """STATE_ORDER must have exactly the 9 plan-specified states.

        If this fails, the plan's state machine table is out of sync with
        the code.
        FIX: update STATE_ORDER in whispers/orientation.py to match
        glittery-shimmying-tome.md §"State machine" table.
        """
        assert len(STATE_ORDER) == 9
        assert STATE_ORDER[0] == OrientationState.UNBOUND
        assert STATE_ORDER[-1] == OrientationState.ORIENTED


# ---------------------------------------------------------------------------
# Fail-closed — every failure mode returns bound=partial + failed_at + reason
# ---------------------------------------------------------------------------


class TestFailClosed:
    """Any handler raising OrientationError halts forward progress and
    returns a structured failure payload. State remains observable at the
    last-successful state.

    This is the core contract from the plan's design principle #2:
    'Fail closed, never fake. No {bound: true} when any surface is not in
    sync. Partial-bind is an error state, not a default.'
    """

    def test_failure_at_binding(self):
        """A BINDING-phase failure returns failed_at=BINDING,
        orientation_state=UNBOUND, bound='partial'.
        """
        m = OrientationStateMachine()
        m.set_handler(
            OrientationState.BINDING,
            lambda: (_ for _ in ()).throw(OrientationError("continuity_anchor_unresolvable")),
        )
        result = m.run()
        assert result.bound == "partial"
        assert result.failed_at == OrientationState.BINDING.value
        assert result.orientation_state == OrientationState.UNBOUND.value
        assert result.reason == "continuity_anchor_unresolvable"

    def test_failure_at_wake_registered(self):
        """A WAKE_REGISTERED failure leaves orientation_state at
        STATUSLINE_SYNCED (the prior success), failed_at=WAKE_REGISTERED.
        """
        m = OrientationStateMachine()

        def fail_at_wake():
            raise OrientationError("local_wake_runtime_unavailable")

        m.set_handler(OrientationState.WAKE_REGISTERED, fail_at_wake)
        result = m.run()
        assert result.bound == "partial"
        assert result.failed_at == OrientationState.WAKE_REGISTERED.value
        assert result.orientation_state == OrientationState.STATUSLINE_SYNCED.value
        assert result.reason == "local_wake_runtime_unavailable"

    def test_state_observable_after_failure(self):
        """After a failure, machine.state reflects where it got stuck.

        Operators reading status mid-session need to see the failure point.
        FIX: run() must not revert self.state on failure.
        """
        m = OrientationStateMachine()

        def fail_at_peers():
            raise OrientationError("peer_lookup_timeout")

        m.set_handler(OrientationState.PEERS_RESOLVED, fail_at_peers)
        m.run()
        # WAKE_REGISTERED succeeded, PEERS_RESOLVED failed; state stays at WAKE.
        assert m.state == OrientationState.WAKE_REGISTERED

    def test_each_state_failure_reports_correct_failed_at(self):
        """Parametric test: failing at each state reports that state
        in failed_at and the prior state in orientation_state.
        """
        states_to_test = [s for s in STATE_ORDER if s != OrientationState.UNBOUND]
        for target in states_to_test:
            m = OrientationStateMachine()
            reason = f"simulated_fail_at_{target.value}"

            def failer(r=reason):
                raise OrientationError(r)

            m.set_handler(target, failer)
            result = m.run()
            target_idx = STATE_ORDER.index(target)
            prior = STATE_ORDER[target_idx - 1]

            assert result.bound == "partial", f"failed at {target.value}"
            assert result.failed_at == target.value
            assert result.orientation_state == prior.value
            assert result.reason == reason

    def test_orientation_error_requires_reason(self):
        """OrientationError must carry a machine-readable reason string.

        'Failure without reason' is banned by the plan's truth-gate principle:
        the operator and the agent must know WHY the bind failed closed.
        FIX: OrientationError.__init__ — require reason param; store on instance.
        """
        with pytest.raises(TypeError):
            OrientationError()  # must require reason

        e = OrientationError("testing")
        assert e.reason == "testing"


# ---------------------------------------------------------------------------
# Result payload shape
# ---------------------------------------------------------------------------


class TestResultShape:
    """OrientationResult must carry the exact fields the bind_seat contract
    requires so downstream callers can rely on the shape.
    """

    def test_success_result_shape(self):
        m = OrientationStateMachine()
        result = m.run()
        # Success: bound=True, no failed_at, no reason
        assert result.bound is True
        assert result.orientation_state == "ORIENTED"
        assert result.failed_at is None
        assert result.reason is None
        # capsule field exists (Slice 0 leaves it None; Slices 1+ populate)
        assert hasattr(result, "capsule")

    def test_partial_result_shape(self):
        m = OrientationStateMachine()
        m.set_handler(
            OrientationState.IDENTITY_ESTABLISHED,
            lambda: (_ for _ in ()).throw(OrientationError("tier_unknown")),
        )
        result = m.run()
        # Partial: bound="partial", failed_at set, reason set
        assert result.bound == "partial"
        assert result.failed_at == "IDENTITY_ESTABLISHED"
        assert result.orientation_state == "BINDING"
        assert result.reason == "tier_unknown"


# ---------------------------------------------------------------------------
# Slice 1 — Identity section composer
# ---------------------------------------------------------------------------


def _sample_card(**overrides):
    """Standard test card for section builders. Overrides replace defaults."""
    card = {
        "callsign": "burr",
        "display_name": "Burr Session",
        "agent_id": "93ba392e-0e12-40e8-a14a-53ea8efefbc7",
        "continuity_anchor": "anchor:63f8ee9d0bbaf8c4c5ca146b",
        "platform_family": "claude-code",
        "participant_kind": "host_bound_agent",
        "participant_shape": "atomic",
        "agency_relation": "self",
        "recognition_basis": "registration",
        "boundary_provenance": "self_asserted",
        "reachability_mode": "manual_wake",
        "trust_tier": 5,
        "registered_at": "2026-04-17 11:46:12",
        "interaction_asks": ["review", "handoff", "exchange"],
        "capability_claims": [
            {"capability": "reason_about_code", "provenance_kind": "native", "basis": "declared"},
        ],
    }
    card.update(overrides)
    return card


class TestIdentitySection:
    """Slice 1 — build_identity_section composes identity facts from an
    agent_card with basis+freshness annotations. Shallow: no sibling lookup
    (that's Slice 4), no continuity event history (that's Slice 5).
    """

    def test_fields_pass_through_from_card(self):
        """All declared identity fields appear in the section, taken from
        the card as-is.
        """
        section = build_identity_section(_sample_card())
        assert section["callsign"] == "burr"
        assert section["display_name"] == "Burr Session"
        assert section["agent_id"] == "93ba392e-0e12-40e8-a14a-53ea8efefbc7"
        assert section["continuity_anchor"] == "anchor:63f8ee9d0bbaf8c4c5ca146b"
        assert section["platform_family"] == "claude-code"
        assert section["participant_kind"] == "host_bound_agent"
        assert section["participant_shape"] == "atomic"
        assert section["agency_relation"] == "self"
        assert section["recognition_basis"] == "registration"
        assert section["boundary_provenance"] == "self_asserted"

    def test_trust_tier_wrapped_with_basis_when_declared(self):
        """Slice 1 trust_tier.basis is 'declared' when the card has a tier.

        Later slices (MI-2 inheritance in Slice 4) will emit
        'inherited_from:<callsign>' or 'operator_authorized' or
        'unknown_requires_authorization'. Slice 1 only knows 'declared'
        vs 'unknown'.
        """
        section = build_identity_section(_sample_card(trust_tier=5))
        assert section["trust_tier"] == {"value": 5, "basis": "declared"}

    def test_trust_tier_unknown_when_missing(self):
        """If the card has no trust_tier (None), basis is 'unknown'.

        Per plan principle #9: unknown is first-class. The capsule must
        report missing data explicitly rather than guessing a default tier.
        """
        section = build_identity_section(_sample_card(trust_tier=None))
        assert section["trust_tier"] == {"value": None, "basis": "unknown"}

    def test_claimed_at_from_registered_at(self):
        """claimed_at comes from card.registered_at (the bind timestamp)."""
        section = build_identity_section(_sample_card())
        assert section["claimed_at"] == "2026-04-17 11:46:12"

    def test_session_name_is_optional_but_passes_through_when_provided(self):
        section = build_identity_section(_sample_card(), session_name="codex-link")
        assert section["session_name"] == "codex-link"

    def test_as_of_is_iso8601_timestamp(self):
        """as_of must be present and look like an ISO-8601 timestamp.

        Freshness is non-negotiable per plan principle #1.
        """
        section = build_identity_section(_sample_card())
        as_of = section["as_of"]
        assert isinstance(as_of, str)
        # Permissive ISO check — must contain T and either Z or +offset
        assert "T" in as_of
        assert as_of.endswith("Z") or "+" in as_of or "-" in as_of[10:]

    def test_as_of_override_is_respected(self):
        """Caller may pin as_of for deterministic tests / replay."""
        section = build_identity_section(
            _sample_card(), as_of="2026-04-17T12:00:00Z"
        )
        assert section["as_of"] == "2026-04-17T12:00:00Z"

    def test_none_card_produces_unknown_identity(self):
        """If no card is provided (e.g., pre-bind), the section still
        builds with all fields set to None/unknown — never crashes.

        Supports the fail-closed contract: even in the worst case,
        orientation returns a structured response, not an exception.
        """
        section = build_identity_section(None)
        assert section["callsign"] is None
        assert section["agent_id"] is None
        assert section["trust_tier"]["basis"] == "unknown"
        assert section["as_of"] is not None


# ---------------------------------------------------------------------------
# Slice 1 — Truths section composer
# ---------------------------------------------------------------------------


class TestTruthsSection:
    """Slice 1 — build_truths_section composes what-I-can-and-cannot-do
    from wake_projection + capability_claims with honest reachability +
    basis annotations. Shallow: no authority_ceiling resolution from
    dispatcher rules (deferred), just observe what the existing
    projections return.
    """

    def test_reachability_reflects_card(self):
        """reachability_mode pulls from the card, unmodified."""
        section = build_truths_section(
            _sample_card(reachability_mode="manual_wake"),
            active_session=None,
        )
        assert section["reachability_mode"] == "manual_wake"

    def test_manual_wake_requires_unavailable_reason(self):
        """If reachability is manual_wake AND no wake_adapter is
        registered, wake_unavailable_reason must be non-empty.

        Plan principle #2: no silent degradation. PF-burr-03 dies here —
        a manual_wake seat must say WHY it isn't listener_backed.
        """
        section = build_truths_section(
            _sample_card(reachability_mode="manual_wake"),
            active_session=None,
        )
        assert section["wake_adapter"] is None
        assert section["wake_unavailable_reason"] is not None
        assert len(section["wake_unavailable_reason"]) > 0

    def test_wake_adapter_populated_when_registered(self):
        """If the session metadata has an adapter_registrations entry,
        wake_adapter is non-null and reachability reflects listener mode.
        """
        active_session = {
            "session_id": "f09230fd-dbdc-405c-97ef-54b6a89a021b",
            "session_kind": "mcp_http",
            "last_seen_at": "2026-04-17 12:00:00",
            "metadata": '{"adapter_registrations": {"local_http_connector": {"endpoint_url": "http://127.0.0.1:64957/wake", "state": "ready"}}}',
        }
        section = build_truths_section(
            _sample_card(reachability_mode="local_http_connector"),
            active_session=active_session,
        )
        assert section["wake_adapter"] is not None
        assert section["wake_adapter"]["kind"] == "local_http_connector"
        assert section["wake_unavailable_reason"] is None

    def test_capability_claims_pass_through(self):
        """capability_claims are preserved from the card for the
        capsule. Slice 1 does not modify them.
        """
        section = build_truths_section(_sample_card(), active_session=None)
        assert isinstance(section["capability_claims"], list)
        assert len(section["capability_claims"]) == 1
        assert section["capability_claims"][0]["capability"] == "reason_about_code"

    def test_can_send_block_present(self):
        """can_send block exists with flash/routine/system booleans.

        These feed directly from trust tier + dispatcher rules; Slice 1
        returns shallow defaults (tier-5 → all true, tier < 5 → system false).
        """
        section = build_truths_section(_sample_card(trust_tier=5), active_session=None)
        assert "can_send" in section
        assert isinstance(section["can_send"], dict)
        assert "flash" in section["can_send"]
        assert "routine" in section["can_send"]
        assert "system" in section["can_send"]

    def test_as_of_is_iso8601_timestamp(self):
        """Section-level freshness marker present."""
        section = build_truths_section(_sample_card(), active_session=None)
        as_of = section["as_of"]
        assert isinstance(as_of, str)
        assert "T" in as_of

    def test_unknown_reachability_preserved(self):
        """If a card has reachability_mode='unknown' or missing, the
        section preserves the unknown (does not guess 'manual_wake').
        """
        section = build_truths_section(
            _sample_card(reachability_mode=None),
            active_session=None,
        )
        assert section["reachability_mode"] == "unknown"
        # unknown reachability with no adapter also requires a reason
        assert section["wake_unavailable_reason"] is not None


# ---------------------------------------------------------------------------
# Jolt integration at startup — truths.jolt block
# ---------------------------------------------------------------------------


class TestJoltBlock:
    """Jolt is a core Whispers feature — not a post-bind addendum. The
    truths section must carry full Jolt truth (host_capabilities, budget,
    attention_context, recommended_action) so an agent reading its own
    capsule, or a peer reading this agent's chrome, sees exactly what
    wake posture this seat has.

    The jolt block is always present. When wake_projection is provided,
    it carries the live Jolt decision. When not provided, it carries
    honest no-adapter defaults with recommended_action=suppress and
    reasons naming the gap.
    """

    def test_jolt_block_always_present(self):
        """Every truths section has a 'jolt' top-level key, even
        pre-adapter. No exceptions to the fully-integrated rule.
        """
        section = build_truths_section(_sample_card(), active_session=None)
        assert "jolt" in section
        assert isinstance(section["jolt"], dict)

    def test_jolt_block_has_four_required_fields(self):
        """host_capabilities, budget, attention_context, recommended_action."""
        section = build_truths_section(_sample_card(), active_session=None)
        jolt = section["jolt"]
        required = {"host_capabilities", "budget", "attention_context", "recommended_action"}
        assert required.issubset(jolt.keys()), (
            f"missing jolt fields: {required - jolt.keys()}"
        )

    def test_jolt_defaults_to_suppress_when_no_projection_given(self):
        """Without a wake_projection, Jolt cannot make a live decision.
        The honest posture is recommended_action=suppress + a reason
        naming the gap — never a silent 'notify' that isn't backed by
        real machinery.
        """
        section = build_truths_section(_sample_card(), active_session=None)
        action = section["jolt"]["recommended_action"]
        assert action["action"] == "suppress"
        assert "no_wake_projection_available" in action.get("reasons", [])

    def test_jolt_populates_from_wake_projection_when_given(self):
        """When a live wake_projection is supplied, the jolt block
        carries its decision verbatim.
        """
        live_projection = {
            "host_capabilities": {
                "host_kind": "local_http",
                "can_notify": True,
                "can_stage_context": True,
                "can_trigger_inference": False,
            },
            "budget": {"max_inferences_per_hour": 10, "inferences_used_last_hour": 0},
            "attention_context": {
                "trigger": "flash_message",
                "interruptibility": "defer",
                "priority": "flash",
                "explicitly_addressed": True,
                "blocking": False,
                "already_hot": True,
            },
            "recommended_action": {
                "action": "notify",
                "reasons": ["flash_priority_explicit_address"],
                "budget_limited": False,
                "fallback_used": False,
            },
        }
        section = build_truths_section(
            _sample_card(),
            active_session=None,
            wake_projection=live_projection,
        )
        assert section["jolt"]["recommended_action"]["action"] == "notify"
        assert section["jolt"]["host_capabilities"]["can_notify"] is True

    def test_jolt_host_capabilities_honest_when_no_adapter(self):
        """No-adapter default: host_capabilities reflect 'cannot notify,
        cannot stage, cannot trigger' — no fake capability claims.
        """
        section = build_truths_section(_sample_card(), active_session=None)
        caps = section["jolt"]["host_capabilities"]
        assert caps["can_notify"] is False
        assert caps["can_stage_context"] is False
        assert caps["can_trigger_inference"] is False


# ---------------------------------------------------------------------------
# Authority ceiling + context budget (Slice 1 shallow completions)
# ---------------------------------------------------------------------------


class TestTruthsCompletions:
    """The plan's truths schema includes authority_ceiling and
    context_budget. Slice 1 supplies shallow values; later slices may
    enrich.
    """

    def test_authority_ceiling_present(self):
        section = build_truths_section(_sample_card(), active_session=None)
        assert "authority_ceiling" in section
        ac = section["authority_ceiling"]
        assert "max_trust_tier_recipient" in ac
        assert "scope_widening_policy" in ac

    def test_authority_ceiling_reflects_tier(self):
        """Dispatcher rule: sender_tier < recipient_tier - 1 is blocked.
        So a tier-5 sender can reach tier 6 (5 >= 6 - 1); tier 5 max.
        Slice 1 shallow: max = trust_tier + 1.
        """
        section = build_truths_section(_sample_card(trust_tier=5), active_session=None)
        assert section["authority_ceiling"]["max_trust_tier_recipient"] == 6

    def test_context_budget_present(self):
        section = build_truths_section(_sample_card(), active_session=None)
        assert "context_budget" in section
        cb = section["context_budget"]
        assert "nominal_limit" in cb
        assert "current_load" in cb
        assert "policy" in cb

    def test_context_budget_defaults_honest(self):
        """Slice 1 stubs: nominal unknown, current unknown, policy
        'progressive_loading'. Later slices may sample actual load.
        """
        section = build_truths_section(_sample_card(), active_session=None)
        cb = section["context_budget"]
        assert cb["current_load"] == "unknown"
        assert cb["policy"] == "progressive_loading"


# ---------------------------------------------------------------------------
# Slice 1 — Schema / contract invariants
# ---------------------------------------------------------------------------


class TestSectionSchemas:
    """Schema contracts that apply across the Slice 1 section builders.

    These enforce the plan's truth-gate principle: every section has the
    declared top-level keys; no section silently omits a required field.
    """

    def test_identity_section_schema_complete(self):
        """Identity section returns the full declared key set."""
        section = build_identity_section(_sample_card())
        required = {
            "callsign", "display_name", "session_name", "agent_id", "continuity_anchor", "platform_family",
            "participant_kind", "participant_shape", "agency_relation",
            "recognition_basis", "boundary_provenance",
            "trust_tier", "claimed_at", "as_of",
        }
        assert required.issubset(section.keys()), (
            f"missing keys: {required - section.keys()}"
        )

    def test_truths_section_schema_complete(self):
        """Truths section returns the full declared key set.

        After Jolt integration: jolt, authority_ceiling, and
        context_budget are required top-level keys.
        """
        section = build_truths_section(_sample_card(), active_session=None)
        required = {
            "reachability_mode", "wake_adapter", "wake_unavailable_reason",
            "jolt", "capability_claims", "can_send", "authority_ceiling",
            "context_budget", "as_of",
        }
        assert required.issubset(section.keys()), (
            f"missing keys: {required - section.keys()}"
        )


# ---------------------------------------------------------------------------
# Slice 4 — Trust tier resolution (MI-2 sibling inheritance)
# ---------------------------------------------------------------------------


class TestTrustTierResolver:
    """resolve_trust_tier() is the MI-2 fix for PF-burr-05.

    A new bind for a callsign that has no prior agent_card must not land
    at tier 1 and be silently filtered by the dispatcher. Instead:
    - Re-bind of an existing callsign → reuse the declared tier
    - Fresh callsign with siblings on the same platform/owner/host →
      inherit the highest-verified tier from a named sibling
    - Fresh callsign with no siblings → tier 0, basis='unknown_requires_
      authorization' so the bind flow can block and surface the gap
    """

    def test_declared_tier_from_card_wins(self):
        """If the card already has a tier (re-bind case), use it as
        'declared'. Sibling inheritance does not override operator
        intent captured in the card.
        """
        result = resolve_trust_tier(
            card={"trust_tier": 5}, siblings=[{"callsign": "spark", "trust_tier": 5}]
        )
        assert result == {"value": 5, "basis": "declared"}

    def test_declared_tier_zero_from_card_is_declared(self):
        """A declared tier of 0 is still 'declared' — operator may have
        intentionally set it and sibling inheritance must not silently
        promote it.
        """
        result = resolve_trust_tier(
            card={"trust_tier": 0},
            siblings=[{"callsign": "spark", "trust_tier": 5}],
        )
        assert result == {"value": 0, "basis": "declared"}

    def test_inherits_single_sibling_tier(self):
        """A fresh bind with one sibling inherits that sibling's tier."""
        siblings = [{"callsign": "spark", "trust_tier": 5}]
        result = resolve_trust_tier(card=None, siblings=siblings)
        assert result == {"value": 5, "basis": "inherited_from:spark"}

    def test_inherits_highest_of_multiple_siblings(self):
        """When multiple siblings exist, inherit the highest verified
        tier and name the sibling in the basis for audit trail."""
        siblings = [
            {"callsign": "pine", "trust_tier": 3},
            {"callsign": "spark", "trust_tier": 5},
            {"callsign": "cove", "trust_tier": 4},
        ]
        result = resolve_trust_tier(card=None, siblings=siblings)
        assert result["value"] == 5
        assert result["basis"] == "inherited_from:spark"

    def test_no_siblings_fails_closed_at_tier_zero(self):
        """A fresh bind with no siblings does NOT land at tier 1.

        This is the direct PF-burr-05 fix: rather than silently defaulting
        to a tier that will be filtered by the dispatcher, the resolver
        reports an explicit unknown state so the bind flow can surface
        'trust_authorization_required' to the operator.
        """
        result = resolve_trust_tier(card=None, siblings=[])
        assert result == {"value": 0, "basis": "unknown_requires_authorization"}

    def test_card_without_tier_field_falls_through_to_inheritance(self):
        """A card that exists but lacks a trust_tier (malformed or
        partial) still triggers sibling inheritance. An absent tier is
        'unknown', not 'declared: None'.
        """
        siblings = [{"callsign": "spark", "trust_tier": 5}]
        result = resolve_trust_tier(card={"callsign": "burr"}, siblings=siblings)
        assert result["value"] == 5
        assert result["basis"] == "inherited_from:spark"

    def test_siblings_with_null_tier_are_skipped(self):
        """Siblings without a numeric tier cannot contribute to inheritance.

        A malformed sibling card must not silently propagate its
        uncertainty as a real tier. Only numeric tiers count.
        """
        siblings = [
            {"callsign": "noop", "trust_tier": None},
            {"callsign": "spark", "trust_tier": 5},
        ]
        result = resolve_trust_tier(card=None, siblings=siblings)
        assert result["value"] == 5
        assert result["basis"] == "inherited_from:spark"


class TestSiblingLookup:
    """find_sibling_agents() narrows a pool of agent_cards to potential
    inheritance sources. The key join is (platform_family, owner_id, or
    host_fingerprint) — same host + same platform = same trusted context.
    """

    def test_filters_by_platform_family(self):
        """Siblings must share platform_family. A pi agent cannot
        inherit from a claude-code agent.
        """
        cards = [
            {"callsign": "spark", "platform_family": "claude-code", "trust_tier": 5},
            {"callsign": "swift-crane", "platform_family": "pi", "trust_tier": 5},
        ]
        siblings = find_sibling_agents(
            cards, platform_family="claude-code", exclude_callsign="burr"
        )
        assert len(siblings) == 1
        assert siblings[0]["callsign"] == "spark"

    def test_excludes_self_callsign(self):
        """A bind can never inherit from its own prior incarnation via
        sibling lookup. Re-bind goes through the declared path.
        """
        cards = [{"callsign": "burr", "platform_family": "claude-code", "trust_tier": 5}]
        siblings = find_sibling_agents(
            cards, platform_family="claude-code", exclude_callsign="burr"
        )
        assert siblings == []

    def test_filters_by_owner_id_when_given(self):
        """If owner_id is provided, only match siblings owned by the
        same operator. Prevents cross-operator trust leakage.
        """
        cards = [
            {"callsign": "spark", "platform_family": "claude-code", "owner_id": "zack", "trust_tier": 5},
            {"callsign": "alien", "platform_family": "claude-code", "owner_id": "other", "trust_tier": 5},
        ]
        siblings = find_sibling_agents(
            cards, platform_family="claude-code", owner_id="zack"
        )
        assert len(siblings) == 1
        assert siblings[0]["callsign"] == "spark"

    def test_empty_pool_returns_empty(self):
        """A bind on a fresh host (no cards in registry) yields no
        siblings — the caller must then surface
        'unknown_requires_authorization'.
        """
        siblings = find_sibling_agents([], platform_family="claude-code")
        assert siblings == []


class TestIdentitySectionWithResolvedTier:
    """Slice 4 integration — build_identity_section accepts a pre-resolved
    trust_tier dict so the bind flow can plug in MI-2 results without
    composers doing their own DB lookups.
    """

    def test_accepts_resolved_tier_override(self):
        """When trust_tier={'value', 'basis'} is passed, use it verbatim.

        The bind flow runs resolve_trust_tier() first, then hands the
        resolved dict to the section builder — composers stay pure.
        """
        card = _sample_card(trust_tier=None)
        resolved = {"value": 5, "basis": "inherited_from:spark"}
        section = build_identity_section(card, trust_tier=resolved)
        assert section["trust_tier"] == resolved

    def test_falls_back_to_card_when_no_override(self):
        """Slice 1 callers continue to work — no override means
        derive basis from the card as before.
        """
        section = build_identity_section(_sample_card(trust_tier=5))
        assert section["trust_tier"] == {"value": 5, "basis": "declared"}

    def test_override_carrying_authorization_gap_is_preserved(self):
        """If the resolver said 'unknown_requires_authorization', the
        capsule must carry that signal verbatim so the operator sees
        exactly why the bind is blocked.
        """
        resolved = {"value": 0, "basis": "unknown_requires_authorization"}
        section = build_identity_section(_sample_card(trust_tier=None), trust_tier=resolved)
        assert section["trust_tier"]["basis"] == "unknown_requires_authorization"


# ---------------------------------------------------------------------------
# Slice 4 — authorize_trust_tier (operator-approval DB write path)
# ---------------------------------------------------------------------------


class TestAuthorizeTrustTier:
    """authorize_trust_tier() writes a new tier onto an agent_card row
    and returns a structured result. It is the CLI-backing helper for
    `whispers authorize-tier <callsign> <tier>`.

    After this runs, the next bind's resolver will find a declared tier
    on the card and report basis='declared' — the authorization path is
    a write now, a read-back later. Simple.
    """

    def test_authorize_updates_existing_card(self, tmp_path):
        """Writing a new tier onto an existing card succeeds and is
        readable back via a plain SELECT.
        """
        import sqlite3
        from whispers.orientation import authorize_trust_tier
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "auth.db")
        db = WhispersDB(db_path=db_path)
        # Seed a tier-0 card representing the no-sibling bind case
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                "INSERT INTO agent_cards (callsign, trust_tier, platform_family) "
                "VALUES (?, ?, ?)",
                ("newbie", 0, "claude-code"),
            )
            conn.commit()
        finally:
            conn.close()

        result = authorize_trust_tier(db_path=db_path, callsign="newbie", tier=5)
        assert result["ok"] is True
        assert result["callsign"] == "newbie"
        assert result["tier"] == 5

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT trust_tier FROM agent_cards WHERE callsign=?", ("newbie",)
            ).fetchone()
        finally:
            conn.close()
        assert row[0] == 5
        del db

    def test_authorize_rejects_unknown_callsign(self, tmp_path):
        """Authorizing a callsign that has no agent_card must fail
        loudly — we never create a card via this path, only promote one.
        """
        from whispers.orientation import authorize_trust_tier
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "auth2.db")
        WhispersDB(db_path=db_path)
        result = authorize_trust_tier(db_path=db_path, callsign="ghost", tier=5)
        assert result["ok"] is False
        assert "ghost" in result.get("reason", "")

    def test_authorize_rejects_invalid_tier(self, tmp_path):
        """Invalid tiers (non-integer, out of 0-6 range) are rejected
        with a specific reason. Prevents fat-finger tier promotions.
        """
        from whispers.orientation import authorize_trust_tier
        from whispers.storage.db import WhispersDB

        db_path = str(tmp_path / "auth3.db")
        WhispersDB(db_path=db_path)
        result = authorize_trust_tier(db_path=db_path, callsign="any", tier=99)
        assert result["ok"] is False
        assert "tier" in result.get("reason", "")


# ---------------------------------------------------------------------------
# Slice 5 — Center section composer
# ---------------------------------------------------------------------------


class TestCenterSection:
    """build_center_section answers 'what my center is' — the working
    scope, declared role/task, and drive signature that define what a
    fresh agent is focused on in this session.

    Per the plan's design principle #9 (unknown is first-class): all
    fields may be None. An agent bound with no declared center still
    gets a valid section — the capsule is diagnostic, not fictional.
    """

    def test_schema_complete(self):
        """All declared top-level keys present, even when values are None."""
        section = build_center_section()
        required = {
            "working_scope", "declared_role", "declared_task",
            "drive_signature", "as_of",
        }
        assert required.issubset(section.keys())

    def test_working_scope_wraps_string_as_name_only(self):
        """A bare scope name is wrapped into the canonical
        {name, parent, policy_hint} shape with None parent/policy.
        """
        section = build_center_section(working_scope="whispers.orient")
        ws = section["working_scope"]
        assert ws["name"] == "whispers.orient"
        assert "parent" in ws
        assert "policy_hint" in ws

    def test_working_scope_dict_preserved(self):
        """An already-shaped working_scope dict is preserved verbatim."""
        scope = {
            "name": "whispers.orient",
            "parent": "whispers",
            "policy_hint": "no_silent_widening",
        }
        section = build_center_section(working_scope=scope)
        assert section["working_scope"] == scope

    def test_declared_role_and_task_pass_through(self):
        section = build_center_section(
            declared_role="designer", declared_task="write startup plan"
        )
        assert section["declared_role"] == "designer"
        assert section["declared_task"] == "write startup plan"

    def test_drive_signature_defaults_to_empty_list(self):
        """Unknown drive signature is an empty list, not None — tests
        and downstream consumers iterate the field safely.
        """
        section = build_center_section()
        assert section["drive_signature"] == []

    def test_drive_signature_passes_through(self):
        section = build_center_section(drive_signature=["epistemic", "coordinative"])
        assert section["drive_signature"] == ["epistemic", "coordinative"]

    def test_all_none_when_nothing_provided(self):
        """An agent bound with no center info still gets a valid section.
        The section is honest about the lack of data.
        """
        section = build_center_section()
        assert section["working_scope"] is None
        assert section["declared_role"] is None
        assert section["declared_task"] is None


# ---------------------------------------------------------------------------
# Slice 5 — Anchors section composer
# ---------------------------------------------------------------------------


class TestAnchorsSection:
    """build_anchors_section answers 'what I'm grounded on' — continuity
    events, memory pointer, prior pairs, and reference docs. Phase 1
    keeps pending_residue stubbed; Phase 2 (Slice 7) wires real capture.
    """

    def test_schema_complete(self):
        section = build_anchors_section()
        required = {
            "continuity_events", "memory_attachment", "prior_pairs",
            "pending_residue", "reference_docs", "as_of",
        }
        assert required.issubset(section.keys())

    def test_empty_defaults_are_empty_lists_not_none(self):
        """All collection fields default to [] so downstream callers
        iterate safely. Only memory_attachment is None-able (it's a
        single pointer, not a collection).
        """
        section = build_anchors_section()
        assert section["continuity_events"] == []
        assert section["prior_pairs"] == []
        assert section["reference_docs"] == []
        assert section["pending_residue"] == []
        assert section["memory_attachment"] is None

    def test_continuity_events_pass_through(self):
        events = [{"kind": "first_bind", "at": "2026-04-17T11:46:12Z"}]
        section = build_anchors_section(continuity_events=events)
        assert section["continuity_events"] == events

    def test_memory_attachment_is_a_pointer(self):
        """memory_attachment is {path, kind} — a pointer, never the
        content itself. The capsule stays small; the agent fetches
        content on demand.
        """
        attachment = {
            "path": "C:/Users/Zachary Turner/.claude/projects/..."
                    "/memory/MEMORY.md",
            "kind": "claude_memory_index",
        }
        section = build_anchors_section(memory_attachment=attachment)
        assert section["memory_attachment"] == attachment

    def test_prior_pairs_pass_through(self):
        pairs = [
            {
                "peer": "spark", "space_id": "pair_86b4492c0b57",
                "basis": "auto_created_on_first_send",
                "last_interaction_at": "2026-04-17T12:01:00Z",
            }
        ]
        section = build_anchors_section(prior_pairs=pairs)
        assert section["prior_pairs"] == pairs

    def test_reference_docs_pass_through(self):
        docs = [{"path": "README.md", "relevance": "project_root"}]
        section = build_anchors_section(reference_docs=docs)
        assert section["reference_docs"] == docs


# ---------------------------------------------------------------------------
# Slice 5 — Working scope resolver
# ---------------------------------------------------------------------------


class TestWorkingScopeResolver:
    """resolve_working_scope() returns a {name, parent, policy_hint}
    dict from (optional explicit hint) + (optional cwd) + workspace
    registry lookup. The goal: agents don't need to explicitly declare
    scope every bind — a sensible default materializes from the
    environment, with an audit trail (basis) for what produced it.
    """

    def test_explicit_scope_name_wins(self):
        """An explicit scope arg is authoritative; no lookup performed."""
        result = resolve_working_scope(explicit="whispers.orient", cwd=None)
        assert result["name"] == "whispers.orient"
        assert result["basis"] == "explicit"

    def test_cwd_fallback_maps_via_registry(self, tmp_path, monkeypatch):
        """With no explicit scope and a cwd, the resolver checks
        `.whispers/workspace-scope.json` in the cwd for a mapping.
        """
        import json as _json
        whispers_dir = tmp_path / ".whispers"
        whispers_dir.mkdir()
        mapping = {"scope": "whispers.orient", "parent": "whispers",
                   "policy_hint": "no_silent_widening"}
        (whispers_dir / "workspace-scope.json").write_text(
            _json.dumps(mapping), encoding="utf-8"
        )
        result = resolve_working_scope(explicit=None, cwd=str(tmp_path))
        assert result["name"] == "whispers.orient"
        assert result["parent"] == "whispers"
        assert result["policy_hint"] == "no_silent_widening"
        assert result["basis"] == "workspace_registry"

    def test_falls_through_to_cwd_leaf_when_no_registry(self, tmp_path):
        """No explicit arg + no registry file → scope name = cwd leaf.

        A pragmatic default: if the operator is in ~/dev/whispers/
        and hasn't declared anything, `whispers` is a reasonable scope.
        """
        result = resolve_working_scope(explicit=None, cwd=str(tmp_path))
        # tmp_path has a leaf name auto-generated by pytest (always unique)
        assert result["name"] == tmp_path.name
        assert result["basis"] == "cwd_leaf"

    def test_final_fallback_is_default_scope(self):
        """No explicit, no cwd → the sentinel 'whispers.default' with
        basis 'no_cwd_or_registry'. Never returns None.
        """
        result = resolve_working_scope(explicit=None, cwd=None)
        assert result["name"] == "whispers.default"
        assert result["basis"] == "no_cwd_or_registry"


# ---------------------------------------------------------------------------
# Slice 5 — Reference doc discovery
# ---------------------------------------------------------------------------


class TestReferenceDocFinder:
    """find_reference_docs() looks for a short list of canonical files
    in the workspace that a fresh agent would benefit from knowing
    exist. Returns pointers with relevance labels; never loads content.
    """

    def test_finds_readme_when_present(self, tmp_path):
        (tmp_path / "README.md").write_text("# test", encoding="utf-8")
        docs = find_reference_docs(workspace_root=str(tmp_path))
        paths = [d["path"] for d in docs]
        assert any(p.endswith("README.md") for p in paths)

    def test_finds_planning_readme(self, tmp_path):
        (tmp_path / ".planning").mkdir()
        (tmp_path / ".planning" / "README.md").write_text("# plan", encoding="utf-8")
        docs = find_reference_docs(workspace_root=str(tmp_path))
        paths = [d["path"] for d in docs]
        assert any(p.endswith(".planning/README.md") or p.endswith(".planning\\README.md") for p in paths)

    def test_returns_empty_when_workspace_empty(self, tmp_path):
        """No recognizable reference docs → empty list, never crash."""
        docs = find_reference_docs(workspace_root=str(tmp_path))
        assert docs == []

    def test_each_result_has_path_and_relevance(self, tmp_path):
        """Schema: every result is {path, relevance} — the relevance
        label lets the agent know whether to load it eagerly.
        """
        (tmp_path / "README.md").write_text("", encoding="utf-8")
        docs = find_reference_docs(workspace_root=str(tmp_path))
        for d in docs:
            assert "path" in d
            assert "relevance" in d
