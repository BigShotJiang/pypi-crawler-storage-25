# Dcc-Json Toolkit

This package is a rework of [**dccXMLJSONConv**](https://gitlab1.ptb.de/digitaldynamicmeasurement/dcc-and-dsi/dccxmljsonconv).

`DccJsonToolkit` offers a set of tools for both users and developers.

![pipeline status](https://gitlab1.ptb.de/digitaldynamicmeasurement/dcc-and-dsi/dcc-2-json-conv/badges/main/pipeline.svg)
![coverage](https://gitlab1.ptb.de/digitaldynamicmeasurement/dcc-and-dsi/dcc-2-json-conv/badges/main/coverage.svg)
[![Docs](https://img.shields.io/badge/Read_the_docs-blue)](https://gitlab-pages.ptb.de/dcc-2-json-conv-19ba77/)

## User Tools

**File conversion** DCC —> JSON
```commandline
dcc2json <INPUT_FILE> [-o <OUTPUT>] [--no-cache]
```

**File conversion** JSON —> DCC
```commandline
json2dcc <INPUT_FILE> [-o <OUTPUT>] [--no-cache]
```

**DCC Validation** (schematron)
```commandline
dcc-validate <DCC_FILE> [-v VERSION] [--ignore-cache]
```

**Cache Manager**
```commandline
dcc-cache [<VERSION>] <--show | --add | --update | --clean>
```

## Developer Tools

If you plan to integrate some of the functionality onto your own code, all functionalities can be recreated with the use of `DccSchema`.

```python
from dcc_json_toolkit import DccSchema

schema = DccSchema("3.3.0")
```

After initializing a schema, you can convert any DCC file into a dictionary:

```python
dcc_path = "./path/to/dcc.xml"
dcc_as_dict = schema.to_dict(dcc_path)
```

Or you can scan all errors within a specific file:

```python
if not schema.is_valid(dcc_path):
    errors_in_dcc = schema.validate_dcc(dcc_path, concise=True)
    print("Errors found at the DCC:")
    print("\t* " + "\n\t* ".join(errors_in_dcc))
```

