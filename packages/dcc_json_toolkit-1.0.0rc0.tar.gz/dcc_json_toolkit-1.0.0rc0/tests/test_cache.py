"""Module with tests for the basics of the cache."""

import pytest
from _helpers import ALL_DCC_VERSIONED_FILES

from dcc_json_toolkit.cache import (
    CACHE_DIR_PATH,
    XSD_PTB_URL_TEMPLATE,
    CacheManager,
    check_schema_online_file,
)

DCC_XSD_RELEASES = {file.parent.name.lstrip("v") for file in ALL_DCC_VERSIONED_FILES}


@pytest.mark.parametrize("_iteration", range(2))
@pytest.mark.parametrize("release", DCC_XSD_RELEASES)
def test_local_cache_files(release: str, _iteration: int):
    """Creating and purging cache files for each example release.

    The test runs in two iterations for each release and behaves based on if the
    cache folder already exists or not. At one iteration, the cache is purged, at other
    the cache is created.

    Purge Cache: The expected result is that a cache folder (no matter if it is empty
    or not) is completely deleted.

    Create Cache: It is expected for a cache folder to be created and for this to
    contain a 'dcc.xsd' file.
    """
    cache_manager = CacheManager(release)
    if (xsd_cache_folder := CACHE_DIR_PATH / release).exists():
        cache_manager.purge(remove_folder=True)
        assert not xsd_cache_folder.exists(), (
            f"Issue with version '{release}' when purging the cache"
        )
        cache_manager.purge()  # This should run without any error.
    else:
        cache_manager.cache_xsd_file(
            XSD_PTB_URL_TEMPLATE.format(version=release), verbose=True
        )
        assert xsd_cache_folder.exists(), (
            f"Cache folder was not created for version '{release}'"
        )
        assert (xsd_cache_folder / "dcc.xsd").exists(), (
            f"Cache file 'dcc.xsd' was not created for version '{release}'"
        )


@pytest.mark.parametrize(
    ("version", "exists"), [*((v, True) for v in DCC_XSD_RELEASES), ("3.3.3", False)]
)
def test_valid_xsd_links(version: str, exists: bool):
    """Checking different schema releases if they are reached properly when existed."""
    if exists:
        check_schema_online_file(version)
    else:
        with pytest.raises(FileNotFoundError):
            check_schema_online_file(version)
