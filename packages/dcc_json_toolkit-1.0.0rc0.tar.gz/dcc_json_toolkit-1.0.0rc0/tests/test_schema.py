"""Tests over the DccSchema functionalities."""

from tempfile import TemporaryDirectory

from _helpers import *
from xmlschema import XMLSchemaValidationError

from dcc_json_toolkit import DccSchema
from dcc_json_toolkit.cache import XSD_PTB_URL_TEMPLATE


@pytest.mark.parametrize("dcc_file_path", ALL_DCC_VERSIONED_FILES)
def test_xml_back_and_forth(dcc_file_path: Path):
    """Loading an XML (DCC) file and transforming the data to check noting is lost.

    The conversion goes from the DCC file, to a python dictionary, to an XML string,
    to a new file. The data is then checked is the same through converting it again
    into a python dict. Due to newlines, tabulations and the order of attributes,
    IN/OUT strings are never the same.
    """
    version = dcc_file_path.parent.name.lstrip("v")
    schema = DccSchema(version)
    scanned_version = DccSchema.get_scanned_version(dcc_file_path)
    assert version == scanned_version, (
        f'The scanned version at "{dcc_file_path}" is different than {version}'
    )

    assert schema.get_schema_uri(no_cache=True) == XSD_PTB_URL_TEMPLATE.format(
        version=version
    )

    dcc_data = schema.to_dict(dcc_file_path)
    dcc_xml_data = schema.to_xml_string(dcc_data)
    with TemporaryDirectory() as temp_dir:
        fpath = Path(temp_dir, "out_test_dcc.xml")
        with open(fpath, "w", encoding="utf-8") as file:
            file.write(dcc_xml_data)

        dcc_reloaded = schema.to_dict(fpath)
        assert_dict(dcc_data, dcc_reloaded)


@pytest.mark.parametrize(
    ("dcc_file_path", "version", "subschema"),
    [
        *((f, "3.3.0", False) for f in DCC_FILES_330),
        *((f, "3.4.0-rc.2", False) for f in DCC_FILES_340),
        *((f, "3.3.0", True) for f in SUBSCHEMA_FILES_330),
        *((f, "3.4.0-rc.2", True) for f in SUBSCHEMA_FILES_340),
    ],
)
def test_dcc_validation(dcc_file_path: Path, version: str, subschema: bool):
    """Asserting all test files are valid.

    This is not a test exactly, but a validation test. All example files should have
    no errors based on the release version of their XSD. This test will print all
    issues any non-valid file has, so they can be fixed.
    """
    schema = DccSchema(version)
    errs = schema.validate_dcc(dcc_file_path, is_subschema=subschema)
    assert len(errs) == 0, (
        f"Found errors at provided file '{dcc_file_path.name}':\n  * "
        + "\n  * ".join(errs)
    )
    assert schema.is_valid(dcc_file_path, is_subschema=subschema), (
        "Valid schema was not identified as correct."
    )


@pytest.mark.parametrize("dcc_file_path", DCC_FILES_340)
def test_schema_comparison(dcc_file_path: Path):
    """Comparing (validate) the latest version with the immediate previous version."""
    file_version = DccSchema.get_scanned_version(dcc_file_path)
    prev_version = "3.3.0"

    assert file_version != prev_version, (
        "The comparison test was defined for different versions."
    )
    assert DccSchema(file_version).is_valid(dcc_file_path), (
        "Invalid DCC data provided. No comparison was performed."
    )

    schema = DccSchema(prev_version)
    errs = schema.validate_dcc(dcc_file_path, concise=True)
    assert len(errs) > 0, (
        "Comparison among versions should at least raise one error: "
        "'The version is not the expected one'"
    )
    assert errs[0].startswith("value doesn't match any pattern")

    errs = schema.validate_dcc(dcc_file_path, concise=False)
    assert all(isinstance(e, XMLSchemaValidationError) for e in errs)
