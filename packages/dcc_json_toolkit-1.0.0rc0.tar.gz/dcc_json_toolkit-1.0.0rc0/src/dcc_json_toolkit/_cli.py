"""Functions to work as entry points for the Command Line Interface."""

from __future__ import annotations

import json
import os.path
import sys
from argparse import ArgumentParser, Namespace
from pathlib import Path
from typing import Optional

from dcc_json_toolkit._metadata import __pkg_name__, __version__
from dcc_json_toolkit.cache import (
    CACHE_DIR_PATH,
    XSD_PTB_URL_TEMPLATE,
    CacheManager,
    check_schema_online_file,
)
from dcc_json_toolkit.dcc_schema import DccSchema


def cache_files(usr_args: Optional[list[str]] = None):
    """Call for caching XSD-versioned files."""
    parser = ArgumentParser(
        prog="dcc-cache",
        description="Cache manager related with DCC-XSD files. It creates a simple"
        " terminal UI to cache new files, show the current cache or clean the cache.",
    )
    parser.add_argument(
        "version",
        nargs="?",
        help="Specific DCC version to work over. If not specified, the tool will"
        " operate over all cached versions. Any specified version should follow "
        "the structure 'X.Y.Z'.",
    )
    parser.add_argument(
        "--uri",
        help="Link to where the released 'dcc.xsd' is stored. If not provided, this "
        "link is set to 'https://ptb.de/dcc/v{version}/dcc.xsd'.",
    )
    parser.add_argument(
        "-s",
        "--show",
        action="store_true",
        help="Displays a list of all cached DCC versions.",
    )
    parser.add_argument(
        "-c",
        "--clean",
        action="store_true",
        help="Removes all cached files and the version folder.",
    )
    parser.add_argument(
        "-a",
        "--add",
        action="store_true",
        help="Adds new files to the cached for non-cached DCC versions.",
    )
    parser.add_argument(
        "-U",
        "--update",
        action="store_true",
        help="Updates all cached files of already cached versions with the "
        "released online files.",
    )
    args = parser.parse_args(usr_args or sys.argv[1:])

    args_count = sum([args.show, args.clean, args.add, args.update])
    if args_count == 0:
        raise ValueError(
            "No action was specified. Write `dcc-cache -h` to see the help."
        )
    if args_count > 1:
        raise ValueError(
            "Multiple actions were specified, but only one action at a time can "
            "be invoked."
        )
    dcc_xsd_version = None if args.version is None else args.version.lower().lstrip("v")
    dcc_uri = args.uri or XSD_PTB_URL_TEMPLATE.format(version=dcc_xsd_version)

    def get_cache_folder_path(not_found_ok: bool = False) -> Path:
        """Returns the Path instance to the cache folder.

        Parameters
        ----------
        not_found_ok :
            If `False` (default) raises an error when a specific version was provided
            and the folder of this version was not found. If `True`, no error is
            raised.
        """
        if dcc_xsd_version is None:
            return CACHE_DIR_PATH
        folder_path = CACHE_DIR_PATH / dcc_xsd_version
        if not not_found_ok and not folder_path.exists():
            raise FileNotFoundError(
                f"DCC version {dcc_xsd_version} was not found within the cached files."
            )
        return folder_path

    if args.show:
        for path in get_cache_folder_path().glob("*"):
            print(path)
    elif args.clean:
        version_folders = (
            get_cache_folder_path().glob("*")
            if dcc_xsd_version is None
            else [get_cache_folder_path()]
        )
        for v in version_folders:
            CacheManager(v.name).purge(remove_folder=True)
            print()  # Adding a new line for better TUI print.
    else:
        if dcc_xsd_version is None:
            raise ValueError(
                "The version must be specified for 'add' and 'update' actions."
            )
        if args.uri is None:
            check_schema_online_file(dcc_xsd_version)

        version_folder = get_cache_folder_path(not_found_ok=True)
        data_was_cached = (
            version_folder.exists() and len(list(version_folder.glob("*"))) > 0
        )
        if args.add and data_was_cached:
            raise ValueError(f"Version {dcc_xsd_version} was already cached.")
        if args.update and not data_was_cached:
            raise ValueError(
                f"Version {dcc_xsd_version} is not cached and cannot be updated."
            )

        CacheManager(dcc_xsd_version).cache_xsd_file(
            uri=dcc_uri, update_cache=args.update, verbose=True
        )


def validate_schema(usr_args: Optional[list[str]] = None):
    """Call to validate DCC files based on their used XSD version."""
    parser = ArgumentParser(
        prog="dcc-validate",
        description="Validation tool to check a DCC file complies to all rules of its "
        "XSD schema file.",
    )
    parser.add_argument("dcc_file", help="Local path to the DCC file to check.")
    parser.add_argument(
        "-v",
        "--version",
        help="Specific version of the XSD. The argument is optional, but its use "
        "is recommended.",
    )
    parser.add_argument(
        "--ignore-cache",
        action="store_true",
        help="When provided, any cache file related to the XSD version is ignored.",
    )
    args = parser.parse_args(usr_args or sys.argv[1:])

    dcc_file_path = Path(args.dcc_file)
    dcc_xsd_version = args.version or DccSchema.get_scanned_version(dcc_file_path)

    schema = DccSchema(dcc_xsd_version, no_cache=args.ignore_cache)
    schema_errors = schema.validate_dcc(dcc_file_path)

    if len(schema_errors) == 0:
        print("No errors found.")
    else:
        print(f'The file "{dcc_file_path}" contains the following errors:')
        print("   —> " + "\n   —> ".join(schema_errors))


def _io_file_arguments(parser: ArgumentParser) -> ArgumentParser:
    """Function to add just the I/O arguments to a parser."""
    parser.add_argument("input_file", help="Local path to the input file to convert.")
    parser.add_argument(
        "-o",
        "--output-path",
        help="Local path to the output file. If not provided, the output is by default"
        " a file with the same name as the input at the current working directory.",
        default=".",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Argument to ignore all cache files and work directly with "
        "online imports.",
    )
    return parser


def _analyze_args_paths(args: Namespace, dcc2json: bool) -> Path:
    """Sanitation over the input/output path."""
    input_ext = os.path.splitext(args.input_file)[-1].lower()

    if dcc2json and input_ext != ".xml":
        raise ValueError(
            f'The provided input file "{args.input_file}" is not a DCC file. '
            "All DCC files have the .xml extension."
        )
    if not dcc2json and input_ext != ".json":
        raise ValueError(
            f'The provided input file "{args.input_file}" is not a JSON file.'
        )

    if (output_path := Path(args.output_path)).is_dir():
        if not output_path.exists():
            res = input(
                "A folder was specified for the output path, but the folder was not "
                f'found.\nSpecified path: "{output_path}"\nCreate the folder(s) for '
                f"this output? [Y/n]"
            ).lower()
            if res in {"y", "yes"}:
                output_path.mkdir(parents=True)
            else:
                print(
                    "Cannot export a file to a non-existing path. Closing the program."
                )
                sys.exit(0)

        file_name = args.input_file.rsplit(os.path.sep, maxsplit=1)[-1]
        file_name = (
            file_name.replace(".xml", ".json")
            if dcc2json
            else file_name.replace(".json", ".xml")
        )
        output_path /= file_name

    out_ext = ".json" if dcc2json else ".xml"
    if output_path.suffix.lower() != out_ext:
        output_path = output_path.parent / (output_path.name + out_ext)

    return output_path


def dcc_to_json(usr_args: Optional[list[str]] = None):
    """Entry point to convert DCC—>JSON."""
    parser = ArgumentParser(
        prog="dcc2json", description="Exports a DCC (.xml) file into a .json file."
    )
    parser = _io_file_arguments(parser)
    args = parser.parse_args(usr_args or sys.argv[1:])
    output_path = _analyze_args_paths(args, dcc2json=True)

    dcc_xsd_version = DccSchema.get_scanned_version(args.input_file)
    schema = DccSchema(dcc_xsd_version, no_cache=args.no_cache)
    dcc_as_dict = schema.to_dict(args.input_file)

    with output_path.open(mode="w", encoding="utf-8") as out_file:
        json.dump(dcc_as_dict, out_file, indent=3)

    print(f'Data exported to "{output_path}"')


def json_to_dcc(usr_args: Optional[list[str]] = None):
    """Entry point to convert JSON—>DCC."""
    parser = ArgumentParser(
        prog="json2dcc", description="Creates a DCC file from .json data."
    )
    parser = _io_file_arguments(parser)
    args = parser.parse_args(usr_args or sys.argv[1:])
    output_path = _analyze_args_paths(args, dcc2json=False)

    with open(args.input_file, mode="r", encoding="utf-8") as file:
        dcc_dict_data = json.load(file)

    schema = DccSchema(dcc_dict_data["@schemaVersion"], no_cache=args.no_cache)
    dcc_xml_data = schema.to_xml_string(dcc_dict_data)

    with output_path.open(mode="w", encoding="utf-8") as out_file:
        out_file.write('<?xml version="1.0" encoding="UTF-8"?>\n' + dcc_xml_data)

    print(f'Data exported to "{output_path}"')


if __name__ == "__main__":
    print("\n" + "=" * 50)
    print(f"{__pkg_name__} version {__version__}")
    print("=" * 50, end="\n\n")

    print(
        "Write the name of the tool you want to use (followed by its arguments):\n"
        "   1. dcc-validate : Validate existing DCC files.\n"
        "   2. dcc-cache : Manage the local cache.\n"
        "   3. dcc2json : Exports a DCC (.xml) file into a JSON file.\n"
        "   4. json2dcc : Creates a DCC file from JSON data.\n"
        "\nIf you don't know what the tool does, write '-h' after its name. "
        "For example, 'dcc-validate -h'. Then press ENTER.\n"
    )

    usr_input = input()
    command, *usr_input = list(filter(lambda cmd: len(cmd) > 0, usr_input.split(" ")))

    print()
    if (command := command.lower()) == "dcc-validate":
        validate_schema(usr_input)
    elif command == "dcc-cache":
        cache_files(usr_input)
    elif command == "dcc2json":
        dcc_to_json(usr_input)
    elif command == "json2dcc":
        json_to_dcc(usr_input)
    else:
        print("Unknown command. Exiting program.")
