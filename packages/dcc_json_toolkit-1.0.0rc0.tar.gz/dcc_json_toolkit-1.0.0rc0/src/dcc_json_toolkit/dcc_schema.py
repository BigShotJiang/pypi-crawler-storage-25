"""Schema for DCC files."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Iterator, Optional, overload
from xml.etree import ElementTree as ET

import xmlschema
from xmlschema import XMLSchemaValidationError, XsdElement

from dcc_json_toolkit.cache import XSD_PTB_URL_TEMPLATE, CacheManager


class DccSchema:
    """XML schema manager to work directly with DCC files.

    `DccSchema` has the purpose communicating/converting any type of data that follows
    a correct DCC schema. In other words, it allows the direct and bidirectional
    conversion XML <——> Python dict. It is structured as a wrapper to
    `xmlschema.XMLSchema`, encapsulating only those required methods.

    To fulfill its task it requires to be initialized with the correct version
    number of the schema.
    """

    def __init__(
        self,
        xsd_schema_version: str,
        no_cache: bool = False,
        schema_url: Optional[str] = None,
    ):
        """The schema requires of internet connexion for both validating and operating
        with the released XSD schema.

        Parameters
        ----------
        xsd_schema_version :
            Version of the released XSD schema. E.G.: '3.3.0' or '3.4.0-rc.2'.
        schema_url :
            URL path to where the schema is published. If not provided, it is
            considered that the XSD file is accessible at
            `https://ptb.de/dcc/v{VERSION}/dcc.xsd`
        no_cache :
            If `True`, the instance works directly with the hosted 'dcc.xsd' file,
            requiring of internet connexion to initialize the schema.
        """
        self._cache = CacheManager(xsd_schema_version)
        self._version = xsd_schema_version

        if schema_url is None:
            schema_url = XSD_PTB_URL_TEMPLATE.format(version=xsd_schema_version)
        self.schema_url = schema_url

        self._schema = xmlschema.XMLSchema(self.get_schema_uri(no_cache=no_cache))

        for prefix, uri in filter(lambda n: n != "", self._schema.namespaces.items()):
            ET.register_namespace(prefix, uri)

    def is_valid(self, xml_source: str, is_subschema: bool = False) -> bool:
        """Check whether an XML file is a valid DCC schema."""
        xpath = None
        if is_subschema:
            xml_source, xpath = self._process_subschema(xml_source)
        return self._schema.is_valid(xml_source, schema_path=xpath)

    @overload
    def validate_dcc(
        self, xml_source: str, concise: bool = True, is_subschema: bool = ...
    ) -> list[str]: ...
    @overload
    def validate_dcc(
        self, xml_source: str, concise: bool = False, is_subschema: bool = ...
    ) -> list[XMLSchemaValidationError]: ...

    def validate_dcc(
        self, xml_source: str, concise: bool = True, is_subschema: bool = False
    ) -> list[str] | list[XMLSchemaValidationError]:
        """Validates an XML data against the XSD schema/component instance.

        The function assumes the provided XML source is a valid XML. Any error raised
        by this function defines the source is not a valid XML.

        Parameters
        ----------
        xml_source :
            Input to validate, which can be either:
            <ul>
                <li>A string with all the XML contents.</li>
                <li>A path to the XML file to validate.</li>
            </ul>
            If the source corresponds to a subschema, the first line must define the
            type of element with the correct XML structure. For example, considering
            a table, the first line of the `xml_source` must be `<dcc:list ...`.
        concise :
            Flag to define the output format of the errors. If `True`, each error is
            formated into a one-liner string. If `False`, the complete error instance
            is returned.
        is_subschema :
            Flag defining whether the provided `xml_source` is actually a snippet and
            not a complete DCC file content.

        Returns
        -------
        errors :
            List of all the errors obtained through the validation. If the file is
            valid, the return should be an empty list.
        """

        def simplify_err_msg(e: XMLSchemaValidationError) -> str:
            """Fits the error in one line message."""
            if len(e.args) > 2:
                return f"{e.args[2]}: `{e.args[1]}`"
            return e.reason

        if is_subschema:
            xml_source, first_xpath = self._process_subschema(xml_source)
            err_iter = self._schema.iter_errors(
                xml_source, schema_path=first_xpath, validation="lax"
            )
        else:
            err_iter = self._schema.iter_errors(xml_source)

        return [simplify_err_msg(err) if concise else err for err in err_iter]

    def to_dict(self, xml_source: str) -> dict:
        """Conversion of the file's content to a dictionary."""
        return self._schema.to_dict(xml_source)

    def to_xml_string(self, data: dict) -> str:
        """Encoding data from a dictionary into an XML string."""
        element = self._schema.encode(data)
        return ET.tostring(element).decode()

    def get_schema_uri(self, no_cache: bool) -> str:
        """URI path to the released XSD schema.

        Based on the `no_cache` parameter, the method return either the URL where the
        XSD file is published (no_cache=True) or the local path to the cached file
        (no_cache=False).
        """
        if no_cache:
            return self.schema_url
        return self._cache.cache_xsd_file(self.schema_url)

    @staticmethod
    def get_scanned_version(dcc_file_path: str, nof_search_lines: int = 10) -> str:
        """Scans the DCC document to find out which XSD version it follows.

        Given a full DCC document, the version scans for the `schemaVersion` attribute
        within the `dcc:digitalCalibrationCertificate` section. The function assumes
        this attribute is contained within the `X` top lines of the document, where
        the value of `X` is defined by the parameter `nof_search_lines`.

        Parameters
        ----------
        dcc_file_path :
            Local path to the XML file which composes the DCC.
        nof_search_lines :
            Number of lines at the top of the document where the version is usually
            specified. This number reduces the load for the regex to search for the
            version.

        Returns
        -------
        version :
            The used released version of the schematron XSD used for the provided
            DCC file.
        """
        with open(dcc_file_path, "r", encoding="utf-8") as file:
            dcc_header_text = "".join(file.readlines()[:nof_search_lines])
        if not (version_match := re.search(r'schemaVersion="(.*)"', dcc_header_text)):
            raise ValueError(
                "Could not find any version specified in the header of the file."
            )
        return version_match.group(1)

    @overload
    def find_valid_xpaths(
        self, target_element: str, as_iterator: bool = False
    ) -> list[str]: ...
    @overload
    def find_valid_xpaths(
        self, target_element: str, as_iterator: bool = True
    ) -> Iterator[str]: ...

    def find_valid_xpaths(
        self, target_element: str, as_iterator: bool = False
    ) -> list[str] | Iterator[str]:
        """Generator of all possible XPaths for any element.

        Parameters
        ----------
        target_element :
            Name of the element to find out, starting with the corresponding namespace.
            Examples: 'dcc:list', 'si:real', 'dcc:name'.
        as_iterator :
            Flag to control whether the return value is either a list with all the
            possible XPaths or an iterator for each XPath.
        """
        try:
            ns, target_element = target_element.split(":", maxsplit=1)
        except ValueError as err:
            raise ValueError(
                "The element name must be defined with its namespace. E.G.: 'dcc:list'"
            ) from err
        if ns not in self._schema.namespaces:
            raise ValueError(f"Unknown namespace '{ns}' specified for the element.")
        target_element = f"{{{self._schema.namespaces[ns]}}}{target_element}"

        def _replace_namespaces(path: str) -> str:
            """Given a path as '{https://ptb.de/dcc}...' returns 'dcc:...'."""
            namespaces = iter(self._schema.namespaces.items())
            ns, link = next(namespaces)
            path = path.replace(link, f"{ns}:")
            for ns, link in namespaces:
                path = path.replace(f"{{{link}}}", f"{ns}:")
            return path

        def traverse(
            root_element: XsdElement, current_path: str, visited_nodes: set
        ) -> Iterator[str]:
            """Traversing the whole schema with DFS algorithm."""
            if root_element.type is None or len(root_element.content) == 0:
                return
            for el in root_element.content.iter_elements():
                if el.name in visited_nodes:
                    continue
                el_path = f"{current_path}/{el.name}"
                if el.name == target_element:
                    yield _replace_namespaces(el_path)
                else:
                    visited_nodes.add(el.name)
                    yield from traverse(el, el_path, visited_nodes)
                visited_nodes.discard(el.name)

        def _iter_all() -> Iterator[str]:
            visited_nodes = set()
            for top_el in self._schema.elements.values():
                yield from traverse(top_el, f"/{top_el.name}", visited_nodes)

        return _iter_all() if as_iterator else list(_iter_all())

    def _process_subschema(self, xml_source: str) -> tuple[str, str]:
        """Processing an XML source to extract the subschema information.

        This processing is mostly used for validation methods.

        Parameters
        ----------
        xml_source :
            Either a path to a file or the string with the XML data. The first line
            must be defined with the subschema element.

        Returns
        -------
        xml_source :
            Updated source to include all required imports.
        first_xpath :
            First encountered XPath to the element representing the subschema.
            Any XPath should work for validating subschemas.
        """
        if (file_path := Path(xml_source)).is_file():
            xml_source = file_path.open(encoding="utf-8").read()

        xml_lines = xml_source.splitlines()
        dcc_element = (first_line := xml_lines[0]).split(" ")[0].strip("<>")
        first_xpath = next(self.find_valid_xpaths(dcc_element, as_iterator=True))

        # Adding all required (missing) imports into the subschema
        for ns, link in self._schema.namespaces.items():
            if ns != "" and f"xmlns:{ns}=" not in first_line:
                first_line = first_line.replace(
                    dcc_element, f'{dcc_element} xmlns:{ns}="{link}"'
                )
        xml_source = "\n".join((first_line, *xml_lines[1:]))

        return xml_source, first_xpath
