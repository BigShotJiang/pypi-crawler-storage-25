"""Internal module to interact with cache."""

import re
from pathlib import Path

import requests
from platformdirs import PlatformDirs

from dcc_json_toolkit._metadata import __pkg_name__

CACHE_DIR_PATH: Path = PlatformDirs(__pkg_name__, "PTB").user_cache_path
CACHE_DIR_PATH.mkdir(parents=True, exist_ok=True)

_REGEX_XS_IMPORT = r'xs:import(?:[^>]*?\n)*?[^>]*?schemaLocation="([^"]*)"'
XSD_PTB_URL_TEMPLATE = "https://ptb.de/dcc/v{version}/dcc.xsd"


def check_schema_online_file(version: str):
    """Checking existence of the URL for the specific XSD version.

    Each versioned XSD is published at a URL `https://ptb.de/dcc/v{version}/dcc.xsd`,
    where `version` is specified as following the Semantic Versioning rules.
    If an incorrect version is specified, leading to a non-existing page, the link is
    always redirected to 'https://www.ptb.de/cms/'.

    Raises
    ------
    FileNotFoundError
        If the specified version file is not found at the URL.
    """
    url = XSD_PTB_URL_TEMPLATE.format(version=version)
    res = requests.get(url)

    url_not_found = res.status_code != 200
    # If an invalid internal URL is provided, this is redirected automatically
    # to the one displayed.
    redirected_url = res.url == "https://www.ptb.de/cms/"

    if url_not_found or redirected_url:
        raise FileNotFoundError(
            f"Release '{version}' was not found. Please, make sure that "
            f"the XSD is published at '{url}'."
        )


class CacheManager:
    """Object with the purpose of managing cache files of the same version.

    It is assumed that each called version has at least one file named 'dcc.xsd'
    stored at `https://www.ptb.de/dcc/v{version}/dcc.xsd`.
    """

    def __init__(self, version: str):
        """
        The constructor creates a new folder with the same name as the value defined
        at the parameter 'version'. No file is automatically cached.

        Parameters
        ----------
        version :
            String following the Semantic Versioning v2.0.0 rules to specify a version.
        """
        if not re.match(r"^\d+\.\d+\.\d+", version):
            raise ValueError(
                "The provided version does not match the structure 'X.Y.Z' or "
                "'X.Y.Z-modifier'."
            )
        self._version_cache_path = CACHE_DIR_PATH / version

    @property
    def version(self) -> str:
        """Initialized version, equivalent to the name of the cache folder."""
        return self._version_cache_path.name

    def cache_xsd_file(
        self, uri: str, update_cache: bool = False, verbose: bool = False
    ) -> Path:
        """Caching an XSD file, as well as all imports it has.

        Explores a URI of an XSD file to locally cache the file and the imports to
        other files.
        The caching of any 'dcc.xsd' file is automatically done at the constructor.

        Parameters
        ----------
        uri :
            Link to the file to cache. This is either an online link starting by
            'https://' or a local link starting by 'file://'.
        update_cache :
            Flag to update any cache file. Updating the cache correlates to overwrite
            all its contents with the latest provided by the URI.
        verbose :
            When enabled, prints over the terminal the path of each cached file.
            Disabled by default.

        Returns
        -------
        file_path :
            The Path instance pointing to the cached file.
        """
        self._version_cache_path.mkdir(exist_ok=True)
        file_path = self._version_cache_path / Path(uri).name

        if not file_path.exists() or update_cache:
            file_text = (
                requests.get(uri).text
                if uri.lower().startswith("http")
                else Path(uri).read_text(encoding="utf-8")
            )
            imports_uri = re.findall(_REGEX_XS_IMPORT, file_text)

            for import_uri in imports_uri:
                import_path_local = self.cache_xsd_file(
                    import_uri, update_cache=update_cache, verbose=verbose
                )
                file_text = file_text.replace(import_uri, str(import_path_local))

            with file_path.open(mode="w", encoding="utf-8") as xsd_file:
                xsd_file.write(file_text)

            if verbose:
                print(f"[Cache Added]: {file_path}")

        return file_path

    def purge(self, remove_folder: bool = False, verbose: bool = True):
        """Removes all files stored in the cache.

        Parameters
        ----------
        remove_folder :
            If set to `True`, the folder created by the constructor is also removed.
            Beware that this might break any further use of the class.
        verbose :
            Allows printing on the terminal the path of each file that was removed.
        """
        if not self._version_cache_path.exists():
            print("No cache found")
            return

        if verbose:
            print(
                f"Removing cache from DCC version {self.version}\n"
                "------------------------------------------"
            )
        for file_path in self._version_cache_path.glob("*"):
            file_path.unlink()
            if verbose:
                print(f"[Cache Removed]: {file_path}")

        if remove_folder:
            self._version_cache_path.rmdir()
            if verbose:
                print(f"[Cache Removed]: {self._version_cache_path}")
