"""Unit tests for the CortexDB sync and async clients.

Uses httpx.MockTransport so no real server or third-party mock library is needed.
"""

from __future__ import annotations

import json
import os
import uuid
from typing import Any

import httpx
import pytest

from cortexdb.client import (
    AsyncCortex,
    Cortex,
    _build_headers,
    _is_retryable,
    _raise_for_status,
)
from cortexdb.exceptions import (
    CortexAPIError,
    CortexAuthError,
    CortexConnectionError,
    CortexRateLimitError,
)
from cortexdb.models import (
    Actor,
    ActorType,
    EpisodeType,
    IngestEpisodeRequest,
)

EPISODE_ID = "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
BASE_URL = "http://cortexdb.test:3141"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _json_response(body: dict[str, Any], status_code: int = 200, headers: dict | None = None):
    """Return an httpx.Response with a JSON body."""
    return httpx.Response(
        status_code=status_code,
        json=body,
        headers=headers or {},
    )


def _make_transport(responses: list[httpx.Response] | httpx.Response):
    """Create a MockTransport that returns responses in sequence.

    If a single response is given it is returned for every request.
    If a list is given, responses are popped in order; the last one repeats.
    """
    if isinstance(responses, httpx.Response):
        responses = [responses]
    responses = list(responses)  # copy

    def handler(request: httpx.Request) -> httpx.Response:
        if len(responses) > 1:
            return responses.pop(0)
        return responses[0]

    return httpx.MockTransport(handler)


def _capturing_transport(
    response: httpx.Response,
    captured: list[httpx.Request],
):
    """MockTransport that records every request for later inspection."""

    def handler(request: httpx.Request) -> httpx.Response:
        # Read content before it might be consumed
        _ = request.content
        captured.append(request)
        return response

    return httpx.MockTransport(handler)


def _make_client(transport: httpx.MockTransport, **kwargs) -> Cortex:
    """Build a Cortex client backed by a MockTransport."""
    defaults = {"base_url": BASE_URL, "api_key": "test-key", "max_retries": 1}
    defaults.update(kwargs)
    client = Cortex(**defaults)
    # Replace internal httpx.Client with one using our transport
    client._client = httpx.Client(
        base_url=defaults["base_url"],
        headers=_build_headers(defaults["api_key"]),
        timeout=30.0,
        transport=transport,
    )
    return client


# ---------------------------------------------------------------------------
# 1. Initialization
# ---------------------------------------------------------------------------


class TestClientInit:
    def test_default_base_url(self):
        """Client defaults to the hosted API when no URL is provided."""
        client = Cortex()
        assert client._base_url == "https://api.cortexdb.ai"
        client.close()

    def test_custom_base_url(self):
        """Client strips trailing slash from custom URL."""
        client = Cortex(base_url="http://my-server:9000/")
        assert client._base_url == "http://my-server:9000"
        client.close()

    def test_api_key_from_constructor(self):
        """API key passed to constructor takes precedence."""
        client = Cortex(api_key="explicit-key")
        assert client._api_key == "explicit-key"
        client.close()

    def test_api_key_from_env(self, monkeypatch):
        """API key falls back to CORTEXDB_API_KEY env var."""
        monkeypatch.setenv("CORTEXDB_API_KEY", "env-key-123")
        client = Cortex()
        assert client._api_key == "env-key-123"
        client.close()

    def test_api_key_constructor_overrides_env(self, monkeypatch):
        """Constructor API key takes precedence over env var."""
        monkeypatch.setenv("CORTEXDB_API_KEY", "env-key")
        client = Cortex(api_key="explicit-key")
        assert client._api_key == "explicit-key"
        client.close()

    def test_custom_max_retries(self):
        """max_retries is stored correctly."""
        client = Cortex(max_retries=7)
        assert client._max_retries == 7
        client.close()


# ---------------------------------------------------------------------------
# 2. remember()
# ---------------------------------------------------------------------------


class TestRemember:
    def test_remember_constructs_correct_request(self):
        """remember() sends POST /v1/remember with correct JSON body."""
        captured: list[httpx.Request] = []
        transport = _capturing_transport(
            _json_response({"event_id": "evt-abc123"}),
            captured,
        )
        client = _make_client(transport)

        result = client.remember(
            "Deploy succeeded at 14:32.",
            tenant_id="acme",
            scope="deploys",
            metadata={"env": "prod"},
        )

        assert result.event_id == "evt-abc123"
        assert len(captured) == 1

        req = captured[0]
        assert req.method == "POST"
        assert req.url.path == "/v1/remember"

        body = json.loads(req.content)
        assert body["content"] == "Deploy succeeded at 14:32."
        assert body["tenant_id"] == "acme"
        assert body["scope"] == "deploys"
        assert body["metadata"] == {"env": "prod"}
        client.close()

    def test_remember_minimal(self):
        """remember() works with only content (defaults applied)."""
        transport = _make_transport(
            _json_response({"event_id": "evt-minimal"})
        )
        client = _make_client(transport)

        result = client.remember("simple text")
        assert result.event_id == "evt-minimal"
        client.close()


# ---------------------------------------------------------------------------
# 3. recall()
# ---------------------------------------------------------------------------


class TestRecall:
    def test_recall_constructs_correct_request(self):
        """recall() sends POST /v1/recall with the right parameters."""
        captured: list[httpx.Request] = []
        transport = _capturing_transport(
            _json_response({
                "context": "The deploy succeeded at 14:32 UTC.",
                "confidence": 0.95,
                "latency_ms": 42,
            }),
            captured,
        )
        client = _make_client(transport)

        result = client.recall("deploy status", tenant_id="acme", max_tokens=2048)

        assert result.context == "The deploy succeeded at 14:32 UTC."
        assert result.confidence == 0.95
        assert result.latency_ms == 42

        body = json.loads(captured[0].content)
        assert body["query"] == "deploy status"
        assert body["tenant_id"] == "acme"
        client.close()

    def test_recall_empty_results(self):
        """recall() handles empty context."""
        transport = _make_transport(
            _json_response({"context": "", "confidence": 0.0, "latency_ms": 5})
        )
        client = _make_client(transport)

        result = client.recall("nonexistent")
        assert result.context == ""
        assert result.confidence == 0.0
        client.close()


# ---------------------------------------------------------------------------
# 4. forget()
# ---------------------------------------------------------------------------


class TestForget:
    def test_forget_constructs_correct_request(self):
        """forget() sends POST /v1/forget with query and reason."""
        captured: list[httpx.Request] = []
        transport = _capturing_transport(
            _json_response({"forgotten_entities": 5, "forgotten_edges": 3, "audit_id": "aud-123"}),
            captured,
        )
        client = _make_client(transport)

        result = client.forget(query="old logs", reason="cleanup")

        assert result.forgotten_entities == 5
        assert result.forgotten_edges == 3
        assert result.audit_id == "aud-123"

        body = json.loads(captured[0].content)
        assert body["query"] == "old logs"
        assert body["reason"] == "cleanup"
        assert body["tenant_id"] == "default"
        client.close()


# ---------------------------------------------------------------------------
# 5. store() dispatch
# ---------------------------------------------------------------------------


class TestStoreDispatch:
    def test_store_string_dispatches_to_remember(self):
        """store() with a string delegates to remember()."""
        transport = _make_transport(
            _json_response({"event_id": "evt-store-str"})
        )
        client = _make_client(transport)

        result = client.store("plain text memory")
        assert result.event_id == "evt-store-str"
        client.close()

    def test_store_dict_dispatches_to_ingest_episode(self):
        """store() with a dict delegates to ingest_episode()."""
        captured: list[httpx.Request] = []
        transport = _capturing_transport(
            _json_response({"episode_id": "ep-123", "event_id": "evt-456", "ingested_at": "2026-03-19T00:00:00Z"}),
            captured,
        )
        client = _make_client(transport)

        result = client.store({
            "content": "PR merged",
            "type": "event",
            "source": "github",
        })
        assert result.episode_id == "ep-123"

        # Should have hit /v1/episodes
        assert captured[0].url.path == "/v1/episodes"
        client.close()

    def test_store_invalid_type_raises(self):
        """store() with non-str, non-dict raises TypeError."""
        transport = _make_transport(_json_response({}))
        client = _make_client(transport)

        with pytest.raises(TypeError, match="store\\(\\) expects a str or dict"):
            client.store(42)  # type: ignore[arg-type]
        client.close()


# ---------------------------------------------------------------------------
# 6. Error handling — _raise_for_status
# ---------------------------------------------------------------------------


class TestRaiseForStatus:
    def test_success_does_not_raise(self):
        """200 response passes through without raising."""
        response = httpx.Response(200, json={"ok": True})
        _raise_for_status(response)  # should not raise

    def test_401_raises_auth_error(self):
        """401 raises CortexAuthError."""
        response = httpx.Response(
            401,
            json={"message": "Invalid API key", "code": "AUTH_FAILED"},
        )
        with pytest.raises(CortexAuthError) as exc_info:
            _raise_for_status(response)
        assert exc_info.value.status_code == 401
        assert exc_info.value.error_code == "AUTH_FAILED"

    def test_429_raises_rate_limit_error(self):
        """429 raises CortexRateLimitError with retry_after parsed."""
        response = httpx.Response(
            429,
            json={"message": "Too many requests"},
            headers={"Retry-After": "10"},
        )
        with pytest.raises(CortexRateLimitError) as exc_info:
            _raise_for_status(response)
        assert exc_info.value.status_code == 429
        assert exc_info.value.retry_after == 10.0

    def test_429_without_retry_after(self):
        """429 without Retry-After header still works (retry_after is None)."""
        response = httpx.Response(429, json={"message": "slow down"})
        with pytest.raises(CortexRateLimitError) as exc_info:
            _raise_for_status(response)
        assert exc_info.value.retry_after is None

    def test_500_raises_api_error(self):
        """500 raises CortexAPIError."""
        response = httpx.Response(
            500,
            json={"message": "Internal server error"},
        )
        with pytest.raises(CortexAPIError) as exc_info:
            _raise_for_status(response)
        assert exc_info.value.status_code == 500

    def test_403_raises_auth_error(self):
        """403 raises CortexAuthError (same as 401)."""
        response = httpx.Response(403, json={"message": "Forbidden"})
        with pytest.raises(CortexAuthError) as exc_info:
            _raise_for_status(response)
        assert exc_info.value.status_code == 403

    def test_422_raises_api_error(self):
        """422 (validation error) raises generic CortexAPIError."""
        response = httpx.Response(422, json={"message": "Validation failed"})
        with pytest.raises(CortexAPIError) as exc_info:
            _raise_for_status(response)
        assert exc_info.value.status_code == 422

    def test_error_with_no_json_body(self):
        """Error response with non-JSON body still raises cleanly."""
        response = httpx.Response(500, text="Gateway timeout")
        with pytest.raises(CortexAPIError):
            _raise_for_status(response)


# ---------------------------------------------------------------------------
# 7. Retry logic — _is_retryable
# ---------------------------------------------------------------------------


class TestIsRetryable:
    def test_rate_limit_is_retryable(self):
        """CortexRateLimitError is always retryable."""
        exc = CortexRateLimitError(message="too fast", retry_after=1.0)
        assert _is_retryable(exc) is True

    def test_503_is_retryable(self):
        """503 Service Unavailable is retryable."""
        exc = CortexAPIError(message="unavailable", status_code=503)
        assert _is_retryable(exc) is True

    def test_502_is_retryable(self):
        """502 Bad Gateway is retryable."""
        exc = CortexAPIError(message="bad gateway", status_code=502)
        assert _is_retryable(exc) is True

    def test_504_is_retryable(self):
        """504 Gateway Timeout is retryable."""
        exc = CortexAPIError(message="timeout", status_code=504)
        assert _is_retryable(exc) is True

    def test_connection_error_is_retryable(self):
        """CortexConnectionError is retryable."""
        exc = CortexConnectionError("connection refused")
        assert _is_retryable(exc) is True

    def test_400_is_not_retryable(self):
        """400 Bad Request is not retryable."""
        exc = CortexAPIError(message="bad request", status_code=400)
        assert _is_retryable(exc) is False

    def test_401_is_not_retryable(self):
        """401 Unauthorized is not retryable."""
        exc = CortexAuthError(message="unauthorized", status_code=401)
        assert _is_retryable(exc) is False

    def test_500_is_not_retryable(self):
        """500 Internal Server Error is not retryable (only 502/503/504 are)."""
        exc = CortexAPIError(message="internal error", status_code=500)
        assert _is_retryable(exc) is False

    def test_generic_exception_is_not_retryable(self):
        """Non-Cortex exceptions are not retryable."""
        exc = ValueError("something else")
        assert _is_retryable(exc) is False


# ---------------------------------------------------------------------------
# 8. _build_headers
# ---------------------------------------------------------------------------


class TestBuildHeaders:
    def test_headers_with_api_key(self):
        """Headers include Authorization when API key is provided."""
        headers = _build_headers("my-secret-key")
        assert headers["Authorization"] == "Bearer my-secret-key"
        assert headers["User-Agent"] == "cortexdb-python/0.2.0"
        assert headers["Accept"] == "application/json"

    def test_headers_without_api_key(self):
        """Headers omit Authorization when API key is None."""
        headers = _build_headers(None)
        assert "Authorization" not in headers
        assert "User-Agent" in headers


# ---------------------------------------------------------------------------
# 9. search()
# ---------------------------------------------------------------------------


class TestSearch:
    def test_search_with_filters(self):
        """search() sends filters in request body."""
        captured: list[httpx.Request] = []
        transport = _capturing_transport(
            _json_response({
                "context": "Deploy failed.",
                "confidence": 0.9,
                "latency_ms": 42,
                "episodes": [],
                "total_episodes": 0,
            }),
            captured,
        )
        client = _make_client(transport)

        result = client.search("deploy failure", source="github", time_range="24h")

        assert result.context == "Deploy failed."
        assert result.confidence == 0.9

        body = json.loads(captured[0].content)
        assert body["query"] == "deploy failure"
        assert body["filters"]["source"] == "github"
        assert body["filters"]["time_range"]["end"] > body["filters"]["time_range"]["start"]
        client.close()


# ---------------------------------------------------------------------------
# 10. entity()
# ---------------------------------------------------------------------------


class TestEntity:
    def test_entity_lookup(self):
        """entity() fetches entity details with correct path."""
        captured: list[httpx.Request] = []
        transport = _capturing_transport(
            _json_response({
                "id": "entity-123",
                "name": "payments-service",
                "entity_type": "service",
                "first_seen": "2026-01-01T00:00:00Z",
                "last_seen": "2026-03-16T12:00:00Z",
                "episode_count": 42,
                "relationships": [],
                "recent_episodes": [],
            }),
            captured,
        )
        client = _make_client(transport)

        result = client.entity("entity-123", tenant_id="acme")

        assert result.id == "entity-123"
        assert result.name == "payments-service"
        assert result.episode_count == 42
        assert captured[0].url.path == "/v1/entities/entity-123"
        client.close()


# ---------------------------------------------------------------------------
# 11. Context manager
# ---------------------------------------------------------------------------


class TestContextManager:
    def test_sync_context_manager(self):
        """Sync client works as a context manager."""
        transport = _make_transport(
            _json_response({"status": "healthy"})
        )
        with Cortex(base_url=BASE_URL, api_key="key") as client:
            client._client = httpx.Client(
                base_url=BASE_URL,
                headers=_build_headers("key"),
                timeout=30.0,
                transport=transport,
            )
            result = client.health()
            assert result.status == "healthy"


# ---------------------------------------------------------------------------
# 12. Retry integration
# ---------------------------------------------------------------------------


class TestRetryIntegration:
    def test_retry_on_503_then_success(self):
        """Client retries on 503 and succeeds on second attempt."""
        responses = [
            _json_response({"message": "unavailable"}, status_code=503),
            _json_response({"event_id": "evt-retry-ok"}),
        ]
        transport = _make_transport(responses)
        client = _make_client(transport, max_retries=3)

        result = client.remember("retry me")
        assert result.event_id == "evt-retry-ok"
        client.close()


# ---------------------------------------------------------------------------
# 13. Async client basics
# ---------------------------------------------------------------------------


class TestAsyncClient:
    @pytest.mark.asyncio
    async def test_async_remember(self):
        """AsyncCortex.remember() works with MockTransport."""
        transport = httpx.MockTransport(
            lambda req: _json_response({"event_id": "evt-async"})
        )
        client = AsyncCortex(base_url=BASE_URL, api_key="key", max_retries=1)
        client._client = httpx.AsyncClient(
            base_url=BASE_URL,
            headers=_build_headers("key"),
            timeout=30.0,
            transport=transport,
        )

        result = await client.remember("async memory")
        assert result.event_id == "evt-async"
        await client.close()

    @pytest.mark.asyncio
    async def test_async_recall(self):
        """AsyncCortex.recall() returns context and confidence."""
        transport = httpx.MockTransport(
            lambda req: _json_response({
                "context": "found it in async",
                "confidence": 0.88,
                "latency_ms": 15,
            })
        )
        client = AsyncCortex(base_url=BASE_URL, api_key="key", max_retries=1)
        client._client = httpx.AsyncClient(
            base_url=BASE_URL,
            headers=_build_headers("key"),
            timeout=30.0,
            transport=transport,
        )

        result = await client.recall("find something")
        assert result.context == "found it in async"
        assert result.confidence == 0.88
        await client.close()

    @pytest.mark.asyncio
    async def test_async_context_manager(self):
        """AsyncCortex works as an async context manager."""
        transport = httpx.MockTransport(
            lambda req: _json_response({"status": "healthy"})
        )
        async with AsyncCortex(base_url=BASE_URL, api_key="key") as client:
            client._client = httpx.AsyncClient(
                base_url=BASE_URL,
                headers=_build_headers("key"),
                timeout=30.0,
                transport=transport,
            )
            result = await client.health()
            assert result.status == "healthy"


# ---------------------------------------------------------------------------
# 14. IngestEpisodeRequest.from_dict
# ---------------------------------------------------------------------------


class TestIngestEpisodeFromDict:
    def test_from_dict_basic(self):
        """from_dict creates a valid request with minimal keys."""
        req = IngestEpisodeRequest.from_dict({
            "content": "PR merged",
            "type": "deployment",
            "source": "github",
        })
        assert req.content == "PR merged"
        assert req.episode_type == EpisodeType.DEPLOYMENT
        assert req.source is not None
        assert req.source.connector == "github"

    def test_from_dict_missing_content_raises(self):
        """from_dict raises ValueError when content is missing."""
        with pytest.raises(ValueError, match="content"):
            IngestEpisodeRequest.from_dict({"type": "deployment"})

    def test_from_dict_extra_keys_go_to_metadata(self):
        """Unknown keys are folded into metadata."""
        req = IngestEpisodeRequest.from_dict({
            "content": "test",
            "custom_field": "value",
        })
        assert req.metadata is not None
        assert req.metadata["custom_field"] == "value"
