"""Shared test fixtures for the CortexDB Python SDK test suite."""

from __future__ import annotations

import pytest

from cortexdb.client import AsyncCortex, Cortex

TEST_BASE_URL = "http://cortexdb.test:3141"
TEST_API_KEY = "test-api-key-000"


@pytest.fixture()
def base_url() -> str:
    """Base URL used across tests."""
    return TEST_BASE_URL


@pytest.fixture()
def api_key() -> str:
    """API key used across tests."""
    return TEST_API_KEY


@pytest.fixture()
def sync_client(base_url: str, api_key: str) -> Cortex:
    """A synchronous Cortex client configured for testing (max_retries=1 to
    keep tests fast)."""
    client = Cortex(base_url=base_url, api_key=api_key, max_retries=1)
    yield client
    client.close()


@pytest.fixture()
async def async_client(base_url: str, api_key: str) -> AsyncCortex:
    """An asynchronous Cortex client configured for testing."""
    client = AsyncCortex(base_url=base_url, api_key=api_key, max_retries=1)
    yield client
    await client.close()
