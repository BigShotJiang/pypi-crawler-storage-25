"""CortexDB v1 Python SDK.

The v1 API surface uses scope paths (``org:foo/user:bar``), the
``ExperienceEnvelope`` shape on write, the stratified ``StratifiedPack``
shape on recall, and PASETO/JWT bearer auth (with ``X-Cortex-Actor``
required on every request).

Quick start:

.. code-block:: python

    from cortexdb.v1 import V1Client

    client = V1Client(
        api_url="https://api.cortexdb.ai",  # or http://localhost:3142 for v1 surface
        actor="user:alice",
        bearer="eyJ...",  # PASETO v4 public or JWT (RS256/ES256)
    )

    # Ingest
    client.experience_bulk("org:initech/user:alice", [
        {"role": "user", "text": "I love coffee in the morning"},
    ])

    # Recall
    pack = client.recall("org:initech/user:alice", query="What does Alice drink?")

    # Answer
    out = client.answer(
        "org:initech/user:alice",
        question="What does Alice drink?",
        question_type="single-session-user",
    )
    print(out["answer"])
"""

from cortexdb.v1.client import AsyncV1Client, V1Client
from cortexdb.v1.exceptions import (
    V1APIError,
    V1AuthError,
    V1ConnectionError,
    V1Error,
    V1NotConfiguredError,
    V1PolicyDeniedError,
    V1RateLimitError,
    V1TimeoutError,
)

__all__ = [
    "V1Client",
    "AsyncV1Client",
    "V1Error",
    "V1APIError",
    "V1AuthError",
    "V1ConnectionError",
    "V1TimeoutError",
    "V1RateLimitError",
    "V1NotConfiguredError",
    "V1PolicyDeniedError",
]
