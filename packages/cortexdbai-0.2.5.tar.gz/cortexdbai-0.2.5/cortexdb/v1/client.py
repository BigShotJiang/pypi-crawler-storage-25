"""Synchronous and asynchronous v1 clients.

The two classes share request-shape semantics; only the transport differs
(``requests`` vs ``httpx.AsyncClient``). All public methods document the
exact endpoint they call so callers can debug at the wire level.
"""

from __future__ import annotations

import json
from typing import Any, Iterable, Mapping, Optional, Sequence
from uuid import uuid4

try:
    import requests  # type: ignore
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "cortexdb.v1 requires the `requests` package; install with "
        "`pip install requests` or `pip install cortexdb[sync]`"
    ) from e

try:
    import httpx  # type: ignore
    _HAS_HTTPX = True
except ImportError:
    _HAS_HTTPX = False

from cortexdb.v1.exceptions import (
    V1APIError,
    V1ConnectionError,
    V1TimeoutError,
)


DEFAULT_TIMEOUT_SECONDS = 60.0
DEFAULT_API_URL = "http://localhost:3142"


# ── Internal helpers ────────────────────────────────────────────────────────

def _build_headers(
    actor: str,
    bearer: Optional[str],
    extra: Optional[Mapping[str, str]] = None,
) -> dict:
    """Construct the request headers every v1 call needs.

    * ``X-Cortex-Actor`` is required on every authenticated v1 request and
      must match the token's ``sub`` claim (when a bearer is present).
    * Bearer is omitted when running against a ``dev_local`` server with
      unsigned-actor mode enabled.
    """
    h = {
        "Content-Type": "application/json",
        "X-Cortex-Actor": actor,
        "User-Agent": "cortexdb-python/v1 (+ https://cortexdb.ai)",
    }
    if bearer:
        h["Authorization"] = f"Bearer {bearer}"
    if extra:
        h.update(extra)
    return h


def _raise_for_response(status: int, text: str) -> None:
    """If the response is non-2xx, raise the most-specific V1APIError
    subclass derived from the v1 error envelope. Otherwise return None."""
    if 200 <= status < 300:
        return
    try:
        body = json.loads(text) if text else {}
    except json.JSONDecodeError:
        body = {"error_code": "UNKNOWN", "message": text[:500]}
    raise V1APIError.from_response(status, body)


def _envelope(
    scope: str,
    *,
    role: Optional[str] = None,
    text: Optional[str] = None,
    json_data: Optional[Any] = None,
    observed_at: Optional[str] = None,
    labels: Optional[Sequence[str]] = None,
    idempotency_key: Optional[str] = None,
    observed_actor: Optional[Mapping[str, str]] = None,
) -> dict:
    """Build a v1 ``ExperienceEnvelope`` for the bulk-ingest endpoint.

    Exactly one of ``text`` / ``json_data`` must be provided (Message vs
    Json content kinds). Defaults are filled in for ``observed_at``
    (current UTC) and ``idempotency_key`` (UUID v4).
    """
    if (text is None) == (json_data is None):
        raise ValueError("provide exactly one of `text` or `json_data`")
    if text is not None:
        content = {"kind": "message", "role": role or "user", "text": text}
    else:
        content = {"kind": "json", "data": json_data}

    ctx: dict = {}
    if observed_at:
        ctx["observed_at"] = observed_at
    else:
        from datetime import datetime, timezone
        ctx["observed_at"] = (
            datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")
        )
    if labels:
        ctx["labels"] = list(labels)

    env = {
        "scope": scope,
        "modality": "conversation",
        "content": content,
        "context": ctx,
        "idempotency_key": idempotency_key or f"sdk-{uuid4().hex}",
    }
    if observed_actor:
        env["observed_actor"] = dict(observed_actor)
    return env


# ── Synchronous client ──────────────────────────────────────────────────────


class V1Client:
    """Synchronous v1 client backed by ``requests.Session``.

    Construct with the v1 surface URL, an actor id, and (in production)
    a bearer token issued by your IdP or by the server's ``/v1/auth/tokens``
    mint endpoint. ``dev_local`` deployments may omit the bearer.

    All methods raise subclasses of :class:`V1Error` on failure; check the
    ``exceptions`` module for the typed hierarchy.
    """

    def __init__(
        self,
        api_url: str = DEFAULT_API_URL,
        *,
        actor: str = "user:default",
        bearer: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ):
        self.api_url = api_url.rstrip("/")
        self.actor = actor
        self.bearer = bearer
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(_build_headers(actor, bearer))

    # ── auth ──────────────────────────────────────────────────────────

    @classmethod
    def signup(
        cls,
        api_url: str = "https://api-v1.cortexdb.ai",
        *,
        display_name: Optional[str] = None,
        email: Optional[str] = None,
        source: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> "V1Client":
        """One-call signup: hits ``POST /v1/auth/signup`` and returns a
        ``V1Client`` already configured with the freshly-minted free-tier
        PASETO and the user's actor id. No prior credentials required.

        Example::

            from cortexdb.v1 import V1Client
            client = V1Client.signup()
            client.experience(client.actor, text="hello memory!")
            print(client.recall(client.actor, query="what did I say?"))
        """
        body: dict = {}
        if display_name:
            body["display_name"] = display_name
        if email:
            body["email"] = email
        if source:
            body["source"] = source
        url = api_url.rstrip("/") + "/v1/auth/signup"
        # We can't call self._post yet — we have no client. One-shot request.
        resp = requests.post(
            url,
            json=body,
            timeout=timeout,
            headers={"Content-Type": "application/json"},
        )
        if not resp.ok:
            raise V1APIError.from_response(resp.status_code, resp.text)
        data = resp.json()
        return cls(
            api_url=api_url,
            actor=data["user_id"],
            bearer=data["token"],
            timeout=timeout,
        )

    def whoami(self) -> dict:
        """``GET /v1/auth/whoami`` — returns the caller, tenant, effective
        capabilities and the deployment preset name. Cheap auth healthcheck."""
        return self._get("/v1/auth/whoami")

    def mint_token(
        self,
        *,
        subject: str,
        scope: Optional[str] = None,
        ttl_seconds: int = 3_600,
        caps: Optional[Sequence[str]] = None,
        scopes: Optional[Sequence[str]] = None,
    ) -> dict:
        """``POST /v1/auth/tokens`` — mint a short-lived PASETO v4 public
        token for M2M / SDK examples.

        The caller must hold ``auth.mint``. If ``scope`` is provided, the
        capability check is scoped to that path; otherwise it is checked
        deployment-wide.
        """
        body: dict = {"subject": subject, "ttl_seconds": ttl_seconds}
        if scope:
            body["scope"] = scope
        if caps:
            body["caps"] = list(caps)
        if scopes:
            body["scopes"] = list(scopes)
        return self._post("/v1/auth/tokens", body)

    # ── write path ────────────────────────────────────────────────────

    def experience(
        self,
        scope: str,
        *,
        text: Optional[str] = None,
        json_data: Optional[Any] = None,
        role: str = "user",
        labels: Optional[Sequence[str]] = None,
        observed_at: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        wait: Optional[str] = None,
    ) -> dict:
        """``POST /v1/experience`` — single envelope. ``wait`` selects sync
        semantics: ``captured``, ``indexed``, ``consolidated``."""
        env = _envelope(
            scope,
            role=role,
            text=text,
            json_data=json_data,
            labels=labels,
            observed_at=observed_at,
            idempotency_key=idempotency_key,
        )
        path = "/v1/experience" + (f"?wait={wait}" if wait else "")
        return self._post(path, env)

    def experience_bulk(
        self,
        scope: str,
        items: Iterable[Mapping[str, Any]],
    ) -> dict:
        """``POST /v1/experience/bulk`` — accepts up to 1000 envelopes per
        request. ``items`` is a sequence of dicts with at least ``text``
        (or ``json_data``) plus optional ``role`` / ``observed_at`` /
        ``labels`` / ``idempotency_key`` keys."""
        envelopes = [
            _envelope(
                scope=str(item.get("scope", scope)),
                role=item.get("role"),
                text=item.get("text"),
                json_data=item.get("json_data"),
                labels=item.get("labels"),
                observed_at=item.get("observed_at"),
                idempotency_key=item.get("idempotency_key"),
                observed_actor=item.get("observed_actor"),
            )
            for item in items
        ]
        return self._post("/v1/experience/bulk", {"items": envelopes})

    # ── recall + answer ───────────────────────────────────────────────

    def recall(
        self,
        scope: str,
        *,
        query: Optional[str] = None,
        view: str = "holistic",
        include: Optional[Sequence[str]] = None,
        diagnostics: str = "none",
        budgets: Optional[Mapping[str, Any]] = None,
        temporal: Optional[Mapping[str, Any]] = None,
    ) -> dict:
        """``POST /v1/recall`` — returns a ``StratifiedPack``.

        ``diagnostics`` defaults to ``"none"`` so free-tier tokens — which
        do not carry the ``diagnostics.read`` capability — succeed on the
        first call. Pass ``diagnostics="summary"`` (or ``"full"``) when
        you hold the elevated capability and want pipeline provenance.
        """
        body: dict = {"scope": scope, "view": view, "diagnostics": diagnostics}
        if query:
            body["query"] = query
        if include:
            body["include"] = list(include)
        if budgets:
            body["budgets"] = dict(budgets)
        if temporal:
            body["temporal"] = dict(temporal)
        return self._post("/v1/recall", body)

    def answer(
        self,
        scope: str,
        question: str,
        *,
        view: str = "holistic",
        question_type: Optional[str] = None,
        question_date: Optional[str] = None,
        answer_model: Optional[str] = None,
        answer_max_tokens: Optional[int] = None,
        use_pack_id: Optional[str] = None,
        temporal: Optional[Mapping[str, Any]] = None,
    ) -> dict:
        """``POST /v1/answer`` — runs recall + LLM render."""
        body: dict = {"scope": scope, "view": view, "question": question}
        if question_type:
            body["question_type"] = question_type
        if question_date:
            body["question_date"] = question_date
        if answer_model:
            body["answer_model"] = answer_model
        if answer_max_tokens is not None:
            body["answer_max_tokens"] = answer_max_tokens
        if use_pack_id:
            body["use_pack_id"] = use_pack_id
        if temporal:
            body["temporal"] = dict(temporal)
        return self._post("/v1/answer", body)

    # ── layer reads ───────────────────────────────────────────────────

    def events(
        self,
        scope: str,
        *,
        view: str = "local",
        limit: int = 50,
        cursor: Optional[str] = None,
        since: Optional[str] = None,
        labels: Optional[Sequence[str]] = None,
        modality: Optional[str] = None,
    ) -> dict:
        """``GET /v1/events`` — paged events for a scope."""
        params: dict = {"scope": scope, "view": view, "limit": limit}
        if cursor:
            params["cursor"] = cursor
        if since:
            params["since"] = since
        if labels:
            params["labels"] = ",".join(labels)
        if modality:
            params["modality"] = modality
        return self._get("/v1/events", params=params)

    def episodes(self, scope: str, *, view: str = "local") -> dict:
        return self._get("/v1/episodes", params={"scope": scope, "view": view})

    def build_episodes(self, scope: str) -> dict:
        """``POST /v1/episodes/build`` — manual session-clustering trigger.
        Stability: ``experimental``."""
        return self._post("/v1/episodes/build", {"scope": scope})

    def beliefs(self, scope: str, *, view: str = "local") -> dict:
        return self._get("/v1/beliefs", params={"scope": scope, "view": view})

    def build_beliefs(self, scope: str) -> dict:
        """``POST /v1/beliefs/build`` — manual fact aggregation trigger.
        Stability: ``experimental``."""
        return self._post("/v1/beliefs/build", {"scope": scope})

    def belief_why(self, belief_id: str) -> dict:
        return self._get("/v1/beliefs/why", params={"belief_id": belief_id})

    def facts(
        self,
        scope: str,
        *,
        view: str = "local",
        subject: Optional[str] = None,
        predicate: Optional[str] = None,
    ) -> dict:
        params: dict = {"scope": scope, "view": view}
        if subject:
            params["subject"] = subject
        if predicate:
            params["predicate"] = predicate
        return self._get("/v1/facts", params=params)

    def understanding(self, scope: str, *, view: str = "local") -> dict:
        return self._get(
            "/v1/understanding", params={"scope": scope, "view": view}
        )

    def synthesize(
        self,
        scope: str,
        *,
        topics: Optional[Sequence[str]] = None,
    ) -> dict:
        """``POST /v1/understanding/synthesize`` — Generative-Agents-style
        reflection pass. Returns 503 if the server isn't configured with
        an LLM router. Stability: ``beta``."""
        body: dict = {"scope": scope, "topics": list(topics) if topics else []}
        return self._post("/v1/understanding/synthesize", body)

    # ── forget + erasures ─────────────────────────────────────────────

    def forget(
        self,
        scope: str,
        *,
        layers: Optional[Sequence[str]] = None,
        about_subject: Optional[str] = None,
        about_entity: Optional[str] = None,
        predicate: Optional[str] = None,
        memory_ids: Optional[Sequence[str]] = None,
        cascade: str = "derived_only",
        confirm_all: bool = False,
        reason: Optional[str] = None,
    ) -> dict:
        body: dict = {
            "scope": scope,
            "cascade": cascade,
            "confirm_all": confirm_all,
        }
        if layers:
            body["layers"] = list(layers)
        selector: dict = {}
        if about_subject:
            selector["about_subject"] = about_subject
        if about_entity:
            selector["about_entity"] = about_entity
        if predicate:
            selector["predicate"] = predicate
        if memory_ids:
            selector["memory_ids"] = list(memory_ids)
        if selector:
            body["selector"] = selector
        if reason:
            body["reason"] = reason
        return self._post("/v1/forget", body)

    # ── audit + admin ─────────────────────────────────────────────────

    def audit_list(
        self,
        *,
        actor: Optional[str] = None,
        capability: Optional[str] = None,
        decision: Optional[str] = None,
        limit: int = 100,
    ) -> dict:
        params: dict = {"limit": limit}
        if actor:
            params["actor"] = actor
        if capability:
            params["capability"] = capability
        if decision:
            params["decision"] = decision
        return self._get("/v1/audit", params=params)

    def audit_verify(self, audit_id: str, body: str) -> dict:
        return self._post(
            "/v1/audit/verify", {"audit_id": audit_id, "body": body}
        )

    def layer_stats(self) -> dict:
        """``GET /v1/admin/layers/stats`` — per-tenant scheduler counters.
        Requires ``diagnostics.read``. Stability: ``experimental``."""
        return self._get("/v1/admin/layers/stats")

    # ── low-level transport ──────────────────────────────────────────

    def _get(
        self,
        path: str,
        *,
        params: Optional[Mapping[str, Any]] = None,
    ) -> dict:
        try:
            r = self._session.get(
                f"{self.api_url}{path}", params=params, timeout=self.timeout
            )
        except requests.Timeout as e:
            raise V1TimeoutError(str(e)) from e
        except requests.ConnectionError as e:
            raise V1ConnectionError(str(e)) from e
        _raise_for_response(r.status_code, r.text)
        return r.json() if r.text else {}

    def _post(self, path: str, body: Any) -> dict:
        try:
            r = self._session.post(
                f"{self.api_url}{path}",
                json=body,
                timeout=self.timeout,
            )
        except requests.Timeout as e:
            raise V1TimeoutError(str(e)) from e
        except requests.ConnectionError as e:
            raise V1ConnectionError(str(e)) from e
        _raise_for_response(r.status_code, r.text)
        return r.json() if r.text else {}

    def close(self) -> None:
        self._session.close()

    def __enter__(self) -> "V1Client":
        return self

    def __exit__(self, *_) -> None:
        self.close()


# ── Async client ────────────────────────────────────────────────────────────


class AsyncV1Client:
    """Asynchronous v1 client backed by ``httpx.AsyncClient``.

    Same surface as :class:`V1Client`; every method is ``async``. Requires
    the ``httpx`` extra: ``pip install cortexdb[async]``.
    """

    def __init__(
        self,
        api_url: str = DEFAULT_API_URL,
        *,
        actor: str = "user:default",
        bearer: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ):
        if not _HAS_HTTPX:
            raise ImportError(
                "AsyncV1Client requires httpx; install with `pip install httpx`"
            )
        self.api_url = api_url.rstrip("/")
        self.actor = actor
        self.bearer = bearer
        self.timeout = timeout
        self._client = httpx.AsyncClient(
            timeout=timeout,
            headers=_build_headers(actor, bearer),
        )

    @classmethod
    async def signup(
        cls,
        api_url: str = "https://api-v1.cortexdb.ai",
        *,
        display_name: Optional[str] = None,
        email: Optional[str] = None,
        source: Optional[str] = None,
        timeout: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> "AsyncV1Client":
        """Async one-call signup. Same shape as :meth:`V1Client.signup`."""
        if not _HAS_HTTPX:
            raise ImportError(
                "AsyncV1Client.signup requires httpx; install with `pip install httpx`"
            )
        body: dict = {}
        if display_name:
            body["display_name"] = display_name
        if email:
            body["email"] = email
        if source:
            body["source"] = source
        url = api_url.rstrip("/") + "/v1/auth/signup"
        async with httpx.AsyncClient(timeout=timeout) as one_shot:
            resp = await one_shot.post(
                url, json=body, headers={"Content-Type": "application/json"}
            )
        if resp.status_code >= 400:
            raise V1APIError.from_response(resp.status_code, resp.text)
        data = resp.json()
        return cls(
            api_url=api_url,
            actor=data["user_id"],
            bearer=data["token"],
            timeout=timeout,
        )

    async def whoami(self) -> dict:
        return await self._get("/v1/auth/whoami")

    async def mint_token(
        self,
        *,
        subject: str,
        scope: Optional[str] = None,
        ttl_seconds: int = 3_600,
        caps: Optional[Sequence[str]] = None,
        scopes: Optional[Sequence[str]] = None,
    ) -> dict:
        body: dict = {"subject": subject, "ttl_seconds": ttl_seconds}
        if scope:
            body["scope"] = scope
        if caps:
            body["caps"] = list(caps)
        if scopes:
            body["scopes"] = list(scopes)
        return await self._post("/v1/auth/tokens", body)

    async def experience_bulk(
        self, scope: str, items: Iterable[Mapping[str, Any]]
    ) -> dict:
        envelopes = [
            _envelope(
                scope=str(item.get("scope", scope)),
                role=item.get("role"),
                text=item.get("text"),
                json_data=item.get("json_data"),
                labels=item.get("labels"),
                observed_at=item.get("observed_at"),
                idempotency_key=item.get("idempotency_key"),
                observed_actor=item.get("observed_actor"),
            )
            for item in items
        ]
        return await self._post("/v1/experience/bulk", {"items": envelopes})

    async def recall(
        self,
        scope: str,
        *,
        query: Optional[str] = None,
        view: str = "holistic",
        diagnostics: str = "none",
    ) -> dict:
        """``POST /v1/recall``. ``diagnostics`` defaults to ``"none"`` so
        free-tier tokens succeed on the first call (no ``diagnostics.read``
        capability required)."""
        body: dict = {"scope": scope, "view": view, "diagnostics": diagnostics}
        if query:
            body["query"] = query
        return await self._post("/v1/recall", body)

    async def answer(
        self,
        scope: str,
        question: str,
        *,
        question_type: Optional[str] = None,
        question_date: Optional[str] = None,
        view: str = "holistic",
    ) -> dict:
        body: dict = {"scope": scope, "view": view, "question": question}
        if question_type:
            body["question_type"] = question_type
        if question_date:
            body["question_date"] = question_date
        return await self._post("/v1/answer", body)

    async def _get(
        self,
        path: str,
        *,
        params: Optional[Mapping[str, Any]] = None,
    ) -> dict:
        try:
            r = await self._client.get(
                f"{self.api_url}{path}", params=params
            )
        except httpx.TimeoutException as e:
            raise V1TimeoutError(str(e)) from e
        except httpx.HTTPError as e:
            raise V1ConnectionError(str(e)) from e
        _raise_for_response(r.status_code, r.text)
        return r.json() if r.text else {}

    async def _post(self, path: str, body: Any) -> dict:
        try:
            r = await self._client.post(f"{self.api_url}{path}", json=body)
        except httpx.TimeoutException as e:
            raise V1TimeoutError(str(e)) from e
        except httpx.HTTPError as e:
            raise V1ConnectionError(str(e)) from e
        _raise_for_response(r.status_code, r.text)
        return r.json() if r.text else {}

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncV1Client":
        return self

    async def __aexit__(self, *_) -> None:
        await self.aclose()
