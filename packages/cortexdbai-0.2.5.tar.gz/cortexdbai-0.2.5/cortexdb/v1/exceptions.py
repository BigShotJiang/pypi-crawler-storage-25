"""v1 exception hierarchy.

Mirrors the v1 error envelope (`error_code`, `message`, `request_id`,
`retriable`, optional `details`). Specific subclasses map common
`error_code` values to typed exceptions so callers can `except
V1NotConfiguredError` instead of pattern-matching on a string.
"""

from __future__ import annotations

from typing import Any, Optional


class V1Error(Exception):
    """Base class for all v1 SDK errors."""


class V1ConnectionError(V1Error):
    """Network failure reaching the v1 surface."""


class V1TimeoutError(V1Error):
    """Request exceeded the configured client timeout."""


class V1APIError(V1Error):
    """Server returned a non-2xx response with a v1 error envelope."""

    def __init__(
        self,
        status: int,
        error_code: str,
        message: str,
        request_id: Optional[str] = None,
        details: Optional[Any] = None,
        retriable: bool = False,
    ):
        super().__init__(f"[{status} {error_code}] {message}")
        self.status = status
        self.error_code = error_code
        self.message = message
        self.request_id = request_id
        self.details = details
        self.retriable = retriable

    @classmethod
    def from_response(cls, status: int, body: dict) -> "V1APIError":
        """Build the most-specific subclass that matches the body's
        `error_code`. Falls back to the base class for unknowns."""
        code = str(body.get("error_code", ""))
        message = str(body.get("message", ""))
        request_id = body.get("request_id")
        details = body.get("details")
        retriable = bool(body.get("retriable", False))
        target = _CODE_MAP.get(code, cls)
        return target(
            status=status,
            error_code=code,
            message=message,
            request_id=request_id,
            details=details,
            retriable=retriable,
        )


class V1AuthError(V1APIError):
    """401 — missing/invalid token, actor mismatch, revoked token, wrong tenant."""


class V1PolicyDeniedError(V1APIError):
    """403 — capability check failed under the deployment/tenant/scope/actor policy stack."""


class V1RateLimitError(V1APIError):
    """429 — rate limit exceeded for this tenant/actor."""


class V1NotConfiguredError(V1APIError):
    """503 — server is missing required configuration (e.g. SYNTHESIZER_UNCONFIGURED)."""


_CODE_MAP = {
    "MISSING_TOKEN": V1AuthError,
    "ACTOR_MISMATCH": V1AuthError,
    "EXPIRED_TOKEN": V1AuthError,
    "REVOKED_TOKEN": V1AuthError,
    "WRONG_TENANT": V1AuthError,
    "INVALID_TOKEN_SIGNATURE": V1AuthError,
    "POLICY_DENIED": V1PolicyDeniedError,
    "SYNTHESIZER_UNCONFIGURED": V1NotConfiguredError,
    "STORAGE_UNWIRED": V1NotConfiguredError,
}
