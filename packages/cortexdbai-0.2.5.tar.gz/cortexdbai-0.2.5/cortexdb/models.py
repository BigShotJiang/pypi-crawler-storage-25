"""Pydantic models for the CortexDB Python SDK.

These models mirror the Rust-side Episode schema and API request/response types.
All models use snake_case field names with camelCase JSON serialization for
wire compatibility.
"""

from __future__ import annotations

import enum
from datetime import datetime
from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field


def _to_camel(name: str) -> str:
    """Convert snake_case to camelCase for JSON serialization."""
    parts = name.split("_")
    return parts[0] + "".join(word.capitalize() for word in parts[1:])


_SHARED_CONFIG = ConfigDict(
    populate_by_name=True,
    alias_generator=_to_camel,
    use_enum_values=True,
)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class EpisodeType(str, enum.Enum):
    """Classification of an episode's content type."""

    MESSAGE = "message"
    CODE_CHANGE = "code_change"
    INCIDENT = "incident"
    DEPLOYMENT = "deployment"
    ISSUE = "issue"
    DOCUMENT = "document"
    REVIEW = "review"
    MEETING = "meeting"
    ALERT = "alert"
    DECISION = "decision"
    CUSTOM = "custom"


class ActorType(str, enum.Enum):
    """The kind of actor that produced an episode."""

    PERSON = "person"
    BOT = "bot"
    SYSTEM = "system"
    SERVICE = "service"


class VisibilityLevel(str, enum.Enum):
    """Access level for an episode."""

    ORGANIZATION = "organization"
    RESTRICTED = "restricted"
    PRIVATE = "private"
    PUBLIC = "public"


# ---------------------------------------------------------------------------
# Core domain models
# ---------------------------------------------------------------------------


class Actor(BaseModel):
    """Represents the entity that produced an episode."""

    model_config = _SHARED_CONFIG

    id: str
    name: str = ""
    actor_type: ActorType = ActorType.PERSON
    email: str | None = None


class Source(BaseModel):
    """Provenance information for an episode."""

    model_config = _SHARED_CONFIG

    connector: str
    external_id: str = ""
    url: str | None = None
    channel: str | None = None


class Visibility(BaseModel):
    """Access control specification for an episode."""

    model_config = _SHARED_CONFIG

    level: VisibilityLevel = VisibilityLevel.ORGANIZATION
    allowed_groups: list[str] = Field(default_factory=list)
    allowed_users: list[str] = Field(default_factory=list)


class EntityRef(BaseModel):
    """A reference to a named entity mentioned in an episode."""

    model_config = _SHARED_CONFIG

    name: str
    entity_type: str = ""
    role: str | None = None


class Episode(BaseModel):
    """A single episode of memory stored in CortexDB.

    An episode represents a discrete unit of information — a message,
    document, code snippet, decision, or any other event worth remembering.
    """

    model_config = _SHARED_CONFIG

    id: UUID | None = None
    tenant_id: str = "default"
    episode_type: EpisodeType = EpisodeType.MESSAGE
    content: str
    actor: Actor | None = None
    source: Source | None = None
    visibility: Visibility | None = None
    entities: list[EntityRef] | None = None
    metadata: dict[str, Any] | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


# ---------------------------------------------------------------------------
# API request / response models
# ---------------------------------------------------------------------------


class IngestEpisodeRequest(BaseModel):
    """Request body for POST /v1/episodes."""

    model_config = _SHARED_CONFIG

    content: str
    tenant_id: str = "default"
    episode_type: EpisodeType = EpisodeType.MESSAGE
    actor: Actor | None = None
    source: Source | None = None
    visibility: Visibility | None = None
    entities: list[EntityRef] | None = None
    metadata: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> IngestEpisodeRequest:
        """Create an IngestEpisodeRequest from a plain dictionary.

        Accepts a simplified dict with the following keys:

        - ``content`` (str, required): The episode text content.
        - ``type`` (str, optional): Episode type name (default ``"message"``).
        - ``source`` (str, optional): Connector/system name (default ``"sdk"``).
        - ``actor`` (str, optional): Actor name (default ``"sdk"``).
        - ``tenant_id`` (str, optional): Tenant namespace (default ``"default"``).
        - ``metadata`` (dict, optional): Arbitrary key-value metadata.

        Any other keys are folded into the ``metadata`` dict so that callers
        can pass domain-specific fields without worrying about the schema.

        Returns:
            A fully-formed ``IngestEpisodeRequest`` ready for ingestion.

        Raises:
            ValueError: If ``content`` is missing from the dict.
        """
        data = dict(data)  # shallow copy to avoid mutating caller's dict

        content = data.pop("content", None)
        if content is None:
            raise ValueError(
                "The 'content' key is required when constructing an "
                "IngestEpisodeRequest from a dict."
            )

        episode_type_raw = data.pop("type", "message")
        try:
            episode_type = EpisodeType(episode_type_raw)
        except ValueError:
            episode_type = EpisodeType.MESSAGE

        source_name = data.pop("source", "sdk")
        actor_name = data.pop("actor", "sdk")
        tenant_id = data.pop("tenant_id", "default")
        metadata = data.pop("metadata", None)

        # Remaining unknown keys get merged into metadata so nothing is lost.
        if data:
            if metadata is None:
                metadata = {}
            metadata.update(data)

        return cls(
            content=content,
            episode_type=episode_type,
            tenant_id=tenant_id,
            actor=Actor(id=actor_name, name=actor_name, actor_type=ActorType.SERVICE),
            source=Source(connector=source_name, external_id="sdk"),
            metadata=metadata if metadata else None,
        )


class IngestEpisodeResponse(BaseModel):
    """Response from POST /v1/episodes."""

    model_config = _SHARED_CONFIG

    episode_id: str
    event_id: str
    ingested_at: str


class ContentType(str, enum.Enum):
    """Content modality type for multimodal memories."""

    TEXT = "text"
    IMAGE = "image"
    AUDIO = "audio"
    VIDEO = "video"
    DOCUMENT = "document"
    SENSOR = "sensor"
    MIXED = "mixed"


class ProcessingStatus(str, enum.Enum):
    """Processing lifecycle status for multimodal content."""

    PENDING = "pending"
    COMPLETE = "complete"
    FAILED = "failed"


class BlobRef(BaseModel):
    """Reference to a stored blob (binary large object)."""

    model_config = _SHARED_CONFIG

    blob_id: str
    mime_type: str
    size_bytes: int
    original_filename: str | None = None


class RememberRequest(BaseModel):
    """Request body for POST /v1/remember.

    For multimodal content, set ``content_type`` to the appropriate modality
    and provide the blob data as base64 in ``blob_base64``, or use
    :meth:`CortexDBClient.upload` for multipart uploads.
    """

    model_config = _SHARED_CONFIG

    content: str
    tenant_id: str = "default"
    scope: str | None = None
    metadata: dict[str, Any] | None = None
    content_type: ContentType | None = None
    blob_base64: str | None = None
    mime_type: str | None = None


class RememberResponse(BaseModel):
    """Response from POST /v1/remember."""

    model_config = _SHARED_CONFIG

    event_id: str
    processing_status: ProcessingStatus | None = None
    content_type: ContentType | None = None


class RecallRequest(BaseModel):
    """Request body for POST /v1/recall."""

    model_config = _SHARED_CONFIG

    query: str
    tenant_id: str = "default"
    max_tokens: int = 4096
    min_confidence: float = 0.0
    modality_filter: list[ContentType] | None = None


class RecallMemory(BaseModel):
    """A single recalled memory with structured metadata."""

    model_config = _SHARED_CONFIG

    event_id: str
    content: str
    score: float
    content_type: ContentType = ContentType.TEXT
    blob_ref: BlobRef | None = None
    processing_status: ProcessingStatus = ProcessingStatus.COMPLETE


class RecallResponse(BaseModel):
    """Response from POST /v1/recall."""

    model_config = _SHARED_CONFIG

    context: str
    confidence: float
    latency_ms: int = 0
    memories: list[RecallMemory] = Field(default_factory=list)


class ForgetRequest(BaseModel):
    """Request body for POST /v1/forget."""

    model_config = _SHARED_CONFIG

    query: str | None = None
    reason: str = ""
    tenant_id: str = "default"


class ForgetResponse(BaseModel):
    """Response from POST /v1/forget."""

    model_config = _SHARED_CONFIG

    forgotten_entities: int = 0
    forgotten_edges: int = 0
    audit_id: str = ""


class EpisodeBrief(BaseModel):
    """Summary of an episode returned by GET /v1/episodes.

    This matches the ``EpisodeSummary`` struct in the Rust API which returns
    a lightweight representation without the full content body.
    """

    model_config = _SHARED_CONFIG

    id: str
    actor_name: str = ""
    source_connector: str = ""
    episode_type: EpisodeType = EpisodeType.MESSAGE
    content_preview: str = ""
    occurred_at: str = ""
    entity_count: int = 0


class ListEpisodesResponse(BaseModel):
    """Response from GET /v1/episodes."""

    model_config = _SHARED_CONFIG

    episodes: list[EpisodeBrief] = Field(default_factory=list)
    total: int = 0
    has_more: bool = False


class HealthResponse(BaseModel):
    """Response from GET /v1/admin/health."""

    model_config = _SHARED_CONFIG

    status: str
    storage: str | None = None
    version: str | None = None


class MetricsResponse(BaseModel):
    """Response from GET /v1/admin/metrics."""

    model_config = _SHARED_CONFIG

    requests_total: int = 0
    requests_active: int = 0
    errors_total: int = 0
    rate_limited_total: int = 0


# ---------------------------------------------------------------------------
# Entity / Link / Search models
# ---------------------------------------------------------------------------


class EntityRelationship(BaseModel):
    """A relationship edge associated with an entity."""

    id: str
    source_entity_id: str
    target_entity_id: str
    relationship: str
    fact: str
    confidence: float
    created_at: str


class EpisodeBrief(BaseModel):
    """A lightweight summary of an episode."""

    id: str
    actor_name: str
    source_connector: str
    episode_type: str
    content_preview: str
    occurred_at: str


class EntityResponse(BaseModel):
    """Response from GET /v1/entities/{entity_id}."""

    id: str
    name: str
    entity_type: str
    first_seen: str
    last_seen: str
    episode_count: int
    relationships: list[EntityRelationship] = []
    recent_episodes: list[EpisodeBrief] = []


class LinkResponse(BaseModel):
    """Response from POST /v1/link."""

    id: str
    created_at: str


class SearchResponse(BaseModel):
    """Response from POST /v1/search."""

    context: str
    confidence: float
    latency_ms: int
    episodes: list[EpisodeBrief] = []
    total_episodes: int = 0
