"""Exception hierarchy for the CortexDB Python SDK."""

from __future__ import annotations


class CortexError(Exception):
    """Base exception for all CortexDB SDK errors."""

    def __init__(self, message: str = "") -> None:
        self.message = message
        super().__init__(message)


class CortexAPIError(CortexError):
    """Raised when the CortexDB API returns an error response.

    Attributes:
        status_code: HTTP status code from the server.
        error_code: Application-level error code returned by the API, if any.
        message: Human-readable error description.
    """

    def __init__(
        self,
        message: str,
        status_code: int,
        error_code: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.error_code = error_code
        super().__init__(message)

    def __str__(self) -> str:
        parts = [f"[HTTP {self.status_code}]"]
        if self.error_code:
            parts.append(f"[{self.error_code}]")
        parts.append(self.message)
        return " ".join(parts)


class CortexConnectionError(CortexError):
    """Raised when the SDK cannot connect to the CortexDB server."""


class CortexTimeoutError(CortexConnectionError):
    """Raised when a request to the CortexDB server times out."""


class CortexAuthError(CortexAPIError):
    """Raised when authentication fails (HTTP 401 or 403)."""


class CortexRateLimitError(CortexAPIError):
    """Raised when the API returns HTTP 429 Too Many Requests.

    Attributes:
        retry_after: Number of seconds to wait before retrying, parsed from
            the Retry-After header. None if the header was absent.
    """

    def __init__(
        self,
        message: str,
        status_code: int = 429,
        error_code: str | None = None,
        retry_after: float | None = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message=message, status_code=status_code, error_code=error_code)
