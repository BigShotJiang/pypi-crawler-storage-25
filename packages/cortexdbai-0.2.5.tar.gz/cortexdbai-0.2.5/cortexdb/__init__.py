"""CortexDB Python SDK — The Long-Term Memory Layer for AI Systems.

Two API surfaces are available:

* The top-level :class:`Cortex` / :class:`AsyncCortex` clients target the
  legacy v0 endpoints (``/v1/remember``, ``/v1/recall``, ``/v1/answer``
  with the v0 request shape) served on port 3141 by default. Used by
  existing integrations.
* The :mod:`cortexdb.v1` submodule targets the new v1 surface
  (``/v1/experience``, stratified-pack recall, layered ``/v1/answer``,
  ``/v1/episodes``, ``/v1/beliefs``, ``/v1/understanding``,
  ``/v1/admin/layers/stats``, ``/v1/audit``, ``/v1/forget``) served on
  port 3142 in dual-port deployments, with PASETO/JWT bearer auth.
  New apps should use :class:`cortexdb.v1.V1Client`.

Quick start (v1):

.. code-block:: python

    from cortexdb.v1 import V1Client

    with V1Client("https://api.cortexdb.ai", actor="user:alice", bearer=token) as c:
        c.experience_bulk("org:initech/user:alice", [{"text": "hello"}])
        out = c.answer("org:initech/user:alice", "what did I say?",
                       question_type="single-session-user")
        print(out["answer"])
"""

from cortexdb.client import AsyncCortex, Cortex
from cortexdb import v1  # re-export the v1 namespace
from cortexdb.exceptions import (
    CortexAPIError,
    CortexAuthError,
    CortexConnectionError,
    CortexError,
    CortexRateLimitError,
    CortexTimeoutError,
)
from cortexdb.models import (
    Actor,
    ActorType,
    BlobRef,
    ContentType,
    EntityRef,
    EntityRelationship,
    EntityResponse,
    Episode,
    EpisodeBrief,
    EpisodeType,
    ForgetRequest,
    ForgetResponse,
    HealthResponse,
    IngestEpisodeRequest,
    IngestEpisodeResponse,
    LinkResponse,
    ListEpisodesResponse,
    MetricsResponse,
    ProcessingStatus,
    RecallMemory,
    RecallRequest,
    RecallResponse,
    RememberRequest,
    RememberResponse,
    SearchResponse,
    Source,
    Visibility,
    VisibilityLevel,
)

__version__ = "0.2.5"
__all__ = [
    # v1 surface (recommended for new apps)
    "v1",
    # Legacy v0 clients
    "Cortex",
    "AsyncCortex",
    # Enums
    "EpisodeType",
    "ActorType",
    "VisibilityLevel",
    "ContentType",
    "ProcessingStatus",
    # Core models
    "Actor",
    "Source",
    "Visibility",
    "EntityRef",
    "Episode",
    "BlobRef",
    "RecallMemory",
    # Request models
    "IngestEpisodeRequest",
    "RememberRequest",
    "RecallRequest",
    "ForgetRequest",
    # Response models
    "IngestEpisodeResponse",
    "RememberResponse",
    "RecallResponse",
    "ForgetResponse",
    "ListEpisodesResponse",
    "HealthResponse",
    "MetricsResponse",
    "EntityResponse",
    "EntityRelationship",
    "EpisodeBrief",
    "LinkResponse",
    "SearchResponse",
    # Exceptions
    "CortexError",
    "CortexAPIError",
    "CortexConnectionError",
    "CortexTimeoutError",
    "CortexAuthError",
    "CortexRateLimitError",
]
