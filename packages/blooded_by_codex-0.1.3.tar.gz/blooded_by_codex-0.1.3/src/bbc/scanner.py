from __future__ import annotations

import json
import re
from pathlib import Path

from .models import ChallengeState


FLAG_RE = re.compile(r"HTB\{[^}\s]+\}")
URL_RE = re.compile(r"https?://[^\s\"'<>]+")


def should_collect_flags(rel_path: str) -> bool:
    normalized = rel_path.replace("\\", "/")
    if normalized.startswith("artifacts/") and normalized.endswith("/flag.txt"):
        return False
    return True


def scan_files(state: ChallengeState) -> ChallengeState:
    root = Path(state.root)
    findings = {key: list(values) for key, values in state.findings.items()}

    files: list[str] = []
    candidate_flags: set[str] = set()
    urls: set[str] = set()

    for path in root.rglob("*"):
        if not path.is_file() or path.name in {".bbc.json", "findings.json"}:
            continue
        rel = str(path.relative_to(root))
        files.append(rel)
        if path.stat().st_size > 2_000_000:
            continue
        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if should_collect_flags(rel):
            candidate_flags.update(FLAG_RE.findall(text))
        urls.update(URL_RE.findall(text))

    findings["files"] = sorted(set(files))
    findings["candidate_flags"] = sorted(candidate_flags)
    findings["urls"] = sorted(urls)
    state.findings = findings

    (root / "findings.json").write_text(
        json.dumps(findings, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return state
