from __future__ import annotations

import subprocess
from datetime import datetime, timezone
from pathlib import Path


def append_note(root: Path, text: str) -> None:
    with (root / "notes.md").open("a", encoding="utf-8") as handle:
        handle.write(f"\n{text.rstrip()}\n")


def log_command(root: Path, command: list[str], result: subprocess.CompletedProcess[str]) -> None:
    timestamp = datetime.now(timezone.utc).isoformat()
    with (root / "command.log").open("a", encoding="utf-8") as handle:
        handle.write(f"\n[{timestamp}] $ {' '.join(command)}\n")
        handle.write(f"exit={result.returncode}\n")
        if result.stdout:
            handle.write("--- stdout ---\n")
            handle.write(result.stdout)
            if not result.stdout.endswith("\n"):
                handle.write("\n")
        if result.stderr:
            handle.write("--- stderr ---\n")
            handle.write(result.stderr)
            if not result.stderr.endswith("\n"):
                handle.write("\n")
