from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Config:
    repo_root: Path
    challenges_dir: Path
    skills_dir: Path
    templates_dir: Path
    ctf_venv: Path


def find_repo_root(start: Path | None = None) -> Path | None:
    current = (start or Path.cwd()).resolve()
    for path in (current, *current.parents):
        if (path / "pyproject.toml").exists() and (path / "src" / "bbc").exists():
            return path
    return None


def default_data_dir() -> Path:
    base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    return base / "bbc"


def load_config() -> Config:
    repo_root = find_repo_root()
    package_root = Path(__file__).resolve().parent
    data_dir = default_data_dir()

    if repo_root is not None:
        challenges_dir = Path(os.environ.get("BBC_CHALLENGES_DIR", repo_root / "challenges"))
        skills_dir = Path(os.environ.get("BBC_SKILLS_DIR", repo_root / "skills"))
        templates_dir = Path(os.environ.get("BBC_TEMPLATES_DIR", repo_root / "templates"))
        root = repo_root
    else:
        challenges_dir = Path(os.environ.get("BBC_CHALLENGES_DIR", data_dir / "challenges"))
        skills_dir = Path(os.environ.get("BBC_SKILLS_DIR", package_root / "skills"))
        templates_dir = Path(os.environ.get("BBC_TEMPLATES_DIR", package_root / "templates"))
        root = package_root

    return Config(
        repo_root=root,
        challenges_dir=challenges_dir,
        skills_dir=skills_dir,
        templates_dir=templates_dir,
        ctf_venv=Path(os.environ.get("BBC_CTF_VENV", Path.home() / "ctf-venv")),
    )
