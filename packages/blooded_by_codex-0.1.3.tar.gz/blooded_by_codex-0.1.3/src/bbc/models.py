from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class InstanceState:
    started: bool = False
    host: str | None = None
    target: str | None = None


@dataclass
class SubmissionState:
    valid: bool = False
    flag: str | None = None
    attempts: list[str] = field(default_factory=list)


@dataclass
class ChallengeState:
    name: str
    htb_id: int | None = None
    category: str | None = None
    description: str = ""
    status: str = "new"
    mode: str = "assist"
    root: str = ""
    artifacts: str = ""
    extracted: str = ""
    writeup: str = ""
    instance: InstanceState = field(default_factory=InstanceState)
    findings: dict[str, list[str]] = field(default_factory=lambda: {
        "urls": [],
        "ports": [],
        "users": [],
        "hashes": [],
        "candidate_flags": [],
        "files": [],
    })
    submission: SubmissionState = field(default_factory=SubmissionState)

    def to_json(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> "ChallengeState":
        instance = InstanceState(**data.get("instance", {}))
        submission = SubmissionState(**data.get("submission", {}))
        known = {**cls(name=data.get("name", "")).findings, **data.get("findings", {})}
        return cls(
            name=data["name"],
            htb_id=data.get("htb_id"),
            category=data.get("category"),
            description=data.get("description", ""),
            status=data.get("status", "new"),
            mode=data.get("mode", "assist"),
            root=data.get("root", ""),
            artifacts=data.get("artifacts", ""),
            extracted=data.get("extracted", ""),
            writeup=data.get("writeup", ""),
            instance=instance,
            findings=known,
            submission=submission,
        )


def challenge_paths(challenges_dir: Path, name: str) -> dict[str, Path]:
    root = challenges_dir / name
    return {
        "root": root,
        "state": root / ".bbc.json",
        "notes": root / "notes.md",
        "command_log": root / "command.log",
        "findings": root / "findings.json",
        "artifacts": root / "artifacts",
        "extracted": root / "extracted",
        "prompts": root / "prompts",
        "writeup_draft": root / "writeup_draft.md",
        "writeup": root / f"{name}.md",
    }
