from __future__ import annotations

from pathlib import Path


CATEGORIES = {"web", "crypto", "reversing", "pwn", "forensics", "misc"}

KEYWORDS = {
    "web": ("http", "website", "web", "api", "xss", "sqli", "jwt", "cookie", "flask", "node"),
    "crypto": ("crypto", "cipher", "rsa", "aes", "xor", "hash", "encrypt", "decrypt", "signature"),
    "reversing": ("reverse", "reversing", "binary", "decompile", "license", "crackme"),
    "pwn": ("pwn", "overflow", "rop", "libc", "heap", "shellcode", "canary"),
    "forensics": ("forensic", "pcap", "memory", "image", "stego", "metadata", "wireshark"),
}

EXTENSIONS = {
    "web": (".html", ".js", ".php", ".ts", ".jsx", ".tsx", ".vue", ".jar"),
    "crypto": (".sage", ".pem", ".pub", ".key"),
    "reversing": (".so", ".dll", ".exe", ".apk", ".class"),
    "pwn": (".c",),
    "forensics": (".pcap", ".pcapng", ".evtx", ".eml", ".raw", ".mem", ".img"),
}


def normalize_category(value: str | None) -> str | None:
    if not value:
        return None
    category = value.strip().lower()
    aliases = {
        "rev": "reversing",
        "reverse engineering": "reversing",
        "forensic": "forensics",
        "pwnable": "pwn",
    }
    category = aliases.get(category, category)
    return category if category in CATEGORIES else None


def classify(description: str, root: Path, current: str | None = None) -> str:
    normalized = normalize_category(current)
    if normalized:
        return normalized

    text = description.lower()
    scores = {category: 0 for category in CATEGORIES}
    for category, words in KEYWORDS.items():
        scores[category] += sum(1 for word in words if word in text)

    for path in root.rglob("*"):
        if not path.is_file():
            continue
        suffix = path.suffix.lower()
        name = path.name.lower()
        for category, extensions in EXTENSIONS.items():
            if suffix in extensions:
                scores[category] += 2
        if name in ("dockerfile", "package.json", "app.py", "server.py"):
            scores["web"] += 2
        if name in ("chall", "challenge", "vuln"):
            scores["pwn"] += 1

    best, score = max(scores.items(), key=lambda item: item[1])
    return best if score > 0 else "misc"
