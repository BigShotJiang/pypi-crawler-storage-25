from __future__ import annotations

from pathlib import Path


def load_skill(skills_dir: Path, category: str) -> str:
    path = skills_dir / f"{category}.md"
    if not path.exists():
        path = skills_dir / "misc.md"
    return path.read_text(encoding="utf-8") if path.exists() else ""
