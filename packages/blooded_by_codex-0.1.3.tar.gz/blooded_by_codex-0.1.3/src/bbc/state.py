from __future__ import annotations

import json
from pathlib import Path

from .models import ChallengeState, challenge_paths


def validate_challenge_name(name: str) -> str:
    if not name or name in {".", ".."}:
        raise ValueError("Challenge name must be a non-empty plain name.")
    if "/" in name or "\\" in name:
        raise ValueError("Challenge name must not contain path separators.")
    return name


def ensure_challenge_dirs(challenges_dir: Path, name: str) -> dict[str, Path]:
    validate_challenge_name(name)
    paths = challenge_paths(challenges_dir, name)
    for key in ("root", "artifacts", "extracted", "prompts"):
        paths[key].mkdir(parents=True, exist_ok=True)
    for key, default in (
        ("notes", f"# {name}\n\n"),
        ("command_log", ""),
        ("findings", "{}\n"),
    ):
        if not paths[key].exists():
            paths[key].write_text(default, encoding="utf-8")
    return paths


def new_state(challenges_dir: Path, name: str) -> ChallengeState:
    validate_challenge_name(name)
    paths = ensure_challenge_dirs(challenges_dir, name)
    return ChallengeState(
        name=name,
        root=str(paths["root"]),
        artifacts=str(paths["artifacts"]),
        extracted=str(paths["extracted"]),
        writeup=str(paths["writeup"]),
    )


def load_state(challenges_dir: Path, name: str) -> ChallengeState:
    validate_challenge_name(name)
    path = challenge_paths(challenges_dir, name)["state"]
    if not path.exists():
        raise FileNotFoundError(f"No state found for {name!r}. Run: bbc init {name!r}")
    return ChallengeState.from_json(json.loads(path.read_text(encoding="utf-8")))


def save_state(challenges_dir: Path, state: ChallengeState) -> None:
    paths = ensure_challenge_dirs(challenges_dir, state.name)
    paths["state"].write_text(
        json.dumps(state.to_json(), indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
