from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from .models import ChallengeState


def writeup_path(state: ChallengeState) -> Path:
    return Path(state.root) / f"{state.name}.md"


def _existing_local_files(state: ChallengeState) -> list[str]:
    root = Path(state.root)
    ordered = []
    for rel in state.findings.get("files", []):
        path = root / rel
        if path.exists():
            ordered.append(rel)
    return ordered


def _local_flag_bait_files(state: ChallengeState) -> list[str]:
    return [rel for rel in _existing_local_files(state) if rel.replace("\\", "/").startswith("artifacts/") and rel.endswith("/flag.txt")]


def copy_to_clipboard(text: str) -> bool:
    commands = (
        ("wl-copy",),
        ("xclip", "-selection", "clipboard"),
        ("xsel", "--clipboard", "--input"),
        ("pbcopy",),
        ("clip",),
    )
    for command in commands:
        if shutil.which(command[0]) is None:
            continue
        try:
            subprocess.run(command, input=text, text=True, check=True)
            return True
        except (OSError, subprocess.CalledProcessError):
            continue
    return False


def render_writeup(state: ChallengeState, skill_text: str = "") -> str:
    notes_path = Path(state.root) / "notes.md"
    command_log_path = Path(state.root) / "command.log"
    notes = notes_path.read_text(encoding="utf-8") if notes_path.exists() else ""
    command_log = command_log_path.read_text(encoding="utf-8") if command_log_path.exists() else ""
    flag = state.submission.flag or ""
    target = state.instance.target or state.instance.host
    local_files = _existing_local_files(state)
    local_flag_baits = _local_flag_bait_files(state)

    commands_section = command_log.strip() or "No commands were logged."
    lessons = "Review the solve path, note the reusable technique, and add the key lesson here."
    if skill_text:
        lessons = "Category playbook used during solving. Keep the reusable technique explicit and remove dead-end noise."

    local_files_section = "No local files were inventoried yet."
    if local_files:
        local_files_section = "\n".join(f"- `{rel}`" for rel in local_files)

    target_section = "No remote instance is currently recorded for this challenge."
    flag_guidance = "Document where the final validated HTB flag was recovered."
    if target:
        target_section = f"Remote target: `{target}`"
        flag_guidance = (
            "A remote target exists, so the final flag must be recovered from the remote service or remote instance behavior, "
            "not from local bait files."
        )

    local_bait_section = "No local bait flag file was detected."
    if local_flag_baits:
        bait_list = "\n".join(f"- `{rel}`" for rel in local_flag_baits)
        local_bait_section = (
            "Local bait flag file(s) detected:\n"
            f"{bait_list}\n\n"
            "Treat any HTB-looking flag string in those local files as a fake local marker. If a remote target exists, the real flag is the one recovered remotely."
        )

    return f"""# {state.name}

## Overview

{state.description.strip() or "Challenge description was not captured."}

Category: `{state.category or "unknown"}`

## Local Files

{local_files_section}

## Remote Context

{target_section}

## Flag Expectations

{flag_guidance}

{local_bait_section}

## Enumeration

{notes.strip() or "Initial notes were not captured yet."}

## Solve Path

Document the successful path here in first person, keeping only the meaningful steps and decisions.

## Commands

```bash
{commands_section}
```

## Flag

```text
{flag}
```

## What I Learned

{lessons}
"""


def write_writeup(state: ChallengeState, skill_text: str = "") -> Path:
    path = writeup_path(state)
    path.write_text(render_writeup(state, skill_text), encoding="utf-8")
    return path
