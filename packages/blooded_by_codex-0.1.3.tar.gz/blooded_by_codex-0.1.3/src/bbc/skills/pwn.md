# Pwn Skill

## Scope

Use this for native exploitation, memory corruption, shellcode, heap bugs, ROP, format strings, and remote binary services.

## Mindset

Work from primitives, not vibes. A pwn solve is a chain: control surface, memory effect, information leak or bypass, and final control-flow redirection. Keep the exploit deterministic and explainable. If you cannot state the primitive precisely, you are not ready to rely on it.

## First Pass

1. Identify binary architecture, mitigations, libc, and how input reaches memory.
2. Reproduce the service locally before touching the remote instance when possible.
3. Find the crash or leak primitive and record exact offsets.
4. Keep exploit scripts small and deterministic.
5. Save remote host, port, libc details, offsets, and final exploit command.

## Deep Checks

1. Map the input surface carefully: read size, write size, signedness, allocation pattern, and where user data lands.
2. Inspect mitigations as constraints, not blockers. NX changes payload shape; PIE and ASLR mean you need a leak; RELRO affects overwrite targets.
3. For glibc-backed targets, track version-specific behavior before assuming a published technique will transfer cleanly.
4. When the primitive is unstable, minimize the program path to the exact interaction that triggers it and remove unnecessary menu noise from the exploit.
5. Treat every leak as structured data. Validate what region it comes from and what it unlocks before building the final chain on top of it.

## Common Pivots

Check buffer overflow, format string, integer bugs, use-after-free, double free, ret2win, ret2libc, one gadget constraints, stack pivoting, and partial overwrite.

## Workflow

1. Run `checksec`, identify the architecture, and determine whether the task is likely stack, heap, or logic driven.
2. Reproduce the bug locally with the smallest possible harness.
3. Lock down offsets, gadget addresses, and leak parsing in a script rather than in a debugger transcript.
4. Add reliability checks so the exploit fails loudly when assumptions change.
5. Only then point the script at the remote service and keep remote-specific values isolated.

## Pitfalls

Do not mix local and remote assumptions casually. Do not ship a one-gadget payload without proving the constraints hold. Do not leave pwntools scripts full of manual pauses or debugger-only state if the end goal is a reproducible solve.

## Useful Tools

`checksec`, `file`, `gdb`, `pwndbg`, `gef`, `pwntools`, `ROPgadget`, `one_gadget`, `patchelf`, `pwninit`.

## Writeup Notes

Explain the primitive, the exact offset or corruption target, the leak or bypass if any, and the final control-flow path. Include the final exploit structure rather than a raw debugger diary.
