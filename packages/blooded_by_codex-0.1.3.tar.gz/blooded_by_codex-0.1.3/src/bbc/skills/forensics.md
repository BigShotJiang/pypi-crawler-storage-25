# Forensics Skill

## Scope

Use this for disk images, memory dumps, packet captures, archives, steganography, metadata, email, logs, and document analysis.

## Mindset

Treat the challenge like evidence handling. Preserve originals, keep extraction steps reversible, and build a timeline of how one artifact leads to the next. The usual failure mode is not missing a fancy trick; it is losing track of where a derived file came from or modifying the only clean copy.

## First Pass

1. Inventory every file and preserve originals.
2. Identify file types using content, not just extensions.
3. Extract archives recursively and record passwords or keys.
4. Search for flags, encodings, timestamps, metadata, and hidden streams.
5. Avoid modifying evidence files; write outputs to `extracted/`.

## Deep Checks

1. Compare file names, MIME types, magic bytes, and entropy. Mismatches usually matter.
2. Pull easy metadata early: timestamps, author fields, EXIF, PDF objects, email headers, and archive comments.
3. For packet captures or logs, define the communication story first: who talked to whom, over what protocol, and when the interesting action happened.
4. For memory or disk artifacts, identify the operating system, filesystem, user accounts, and likely working directories before running broad carving.
5. When a file looks clean, assume there may be embedded or appended content and verify with carving or structure-aware tools.

## Common Pivots

Check deleted files, embedded files, EXIF, alternate data streams, base64/hex blobs, packet credentials, DNS exfiltration, carved files, and stego channels.

## Workflow

1. Create a clean inventory with hashes or at least stable filenames.
2. Extract recursively into `extracted/`, keeping subdirectories named after the source artifact.
3. Run broad triage tools first, then focus on the one artifact family that keeps producing anomalies.
4. Record commands and passwords as you go so the chain of extraction is reproducible.
5. Once the flag source is identified, rebuild the minimal path from original artifact to final flag.

## Pitfalls

Do not rely only on `strings`. Do not trust file extensions. Do not open everything in GUI tools first and lose a command trail. If you carve aggressively, keep track of which results are real and which are noise from generic signatures.

## Useful Tools

`file`, `strings`, `binwalk`, `exiftool`, `foremost`, `steghide`, `zsteg`, `tshark`, Wireshark, Volatility, `bulk_extractor`.

## Writeup Notes

Keep the chain of extraction clear and chronological. Include the commands that transformed the original artifact into the flag and name the exact artifact that actually contained it.
