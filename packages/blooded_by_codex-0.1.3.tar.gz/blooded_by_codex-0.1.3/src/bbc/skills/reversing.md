# Reversing Skill

## Scope

Use this for binaries, bytecode, mobile apps, license checks, crackmes, obfuscated scripts, and compiled validation logic.

## Mindset

Reverse engineering is model building. The target already contains the answer logic; the task is to recover enough of that logic to derive the required input or flag. Stay disciplined about separating observed behavior, inferred semantics, and guessed intent.

## First Pass

1. Identify file type, architecture, protections, strings, and imported functions.
2. Run safely only when appropriate; prefer static analysis first for unknown binaries.
3. Locate input validation, comparison points, crypto routines, and success/failure branches.
4. Rename important functions and variables in notes.
5. Extract the minimal condition needed to recover the flag.

## Deep Checks

1. Start with the cheapest signals: strings, imports, symbols, section layout, and startup code.
2. Identify where user-controlled data first enters the program and where it is transformed before comparison.
3. Distinguish dispatcher or framework noise from the few routines that actually implement challenge logic.
4. If obfuscation is present, ask what property it protects: constants, control flow, environment checks, or serialized payloads.
5. When the logic is algebraic or stateful, translate it into a Python model early instead of manually reasoning through assembly longer than necessary.

## Common Pivots

Check hardcoded strings, XOR loops, base64/hex transforms, anti-debug checks, packed sections, VM-like dispatchers, and symbolic constraints.

## Workflow

1. Triage the binary or package statically and identify likely validation or decryption routines.
2. Rename and annotate those routines until the data flow is legible.
3. Confirm uncertain semantics dynamically with the smallest possible breakpoint or trace.
4. Reimplement the critical logic in a script to recover the expected input or invert the transform.
5. Keep the solve focused on the minimal logic that mattered instead of documenting every function visited.

## Pitfalls

Do not spend an hour exploring every function when one comparison routine decides success. Do not trust decompiler types blindly. Do not overuse dynamic tracing when a five-line Python model would make the transformation obvious.

## Useful Tools

`file`, `strings`, `readelf`, `objdump`, `ltrace`, `strace`, `gdb`, `radare2`, Ghidra, Binary Ninja, `jadx`, `apktool`, `z3`.

## Writeup Notes

Show how the validation logic works, what parts were noise, and how the required input or flag was derived from the recovered model.
