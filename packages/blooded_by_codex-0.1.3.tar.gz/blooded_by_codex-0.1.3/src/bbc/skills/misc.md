# Misc Skill

## Scope

Use this when the challenge does not clearly fit another category or mixes scripting, programming, puzzle, cloud, AI, or infrastructure behavior.

## Mindset

Misc challenges are usually not truly miscellaneous. They are category-blended tasks with one dominant mechanic hidden behind noise. The goal is to collapse ambiguity fast: inventory the moving parts, identify what the challenge actually lets you influence, and reclassify once the core mechanic reveals itself.

## First Pass

1. Read the description carefully and list constraints.
2. Inventory files, inputs, outputs, and any remote service.
3. Look for automation opportunities before doing repetitive manual work.
4. Record assumptions and rule out simple encodings or hidden content.
5. Reclassify to a specific category once the core mechanic is clear.

## Deep Checks

1. Distinguish between presentation detail and enforcement logic. Many misc tasks wrap a simple parser, scheduler, or state machine in extra story text.
2. Identify any time-dependent behavior, retries, queueing, caching, or race windows.
3. If the challenge exposes an API, CLI, or service, map the full input grammar and error behavior before brute forcing ideas.
4. Check whether the challenge combines two domains, such as crypto plus web, or reversing plus pwn. If so, split the problem and solve the easier half first.
5. When AI, cloud, or infra behavior is involved, focus on permissions, boundaries, and what component is making trust decisions.

## Common Pivots

Check encodings, protocol quirks, race conditions, weird parsers, scheduling, cloud permissions, sandbox escapes, and small custom programs.

## Workflow

1. Build a minimal reproduction or driver script as soon as the interface is understood.
2. Reduce the challenge to one crisp question: what state transition or trust boundary do I need to violate?
3. Probe that question with small deterministic experiments.
4. Once a pattern emerges, reframe the task under the specific category it most resembles and apply that playbook.
5. Keep notes tight so the final writeup does not read like unrelated guessing.

## Pitfalls

Do not let the `misc` label justify random thrashing. Do not overfit on the first weird detail you notice. If manual interaction becomes repetitive, automate it immediately so you can reason from outputs instead of memory.

## Useful Tools

`python`, `jq`, `curl`, `nc`, `tmux`, `docker`, shell utilities.

## Writeup Notes

Explain the actual mechanic once discovered and make the narrative converge quickly onto it. Avoid presenting the solve as a grab bag of unrelated attempts.
