# Web Skill

## Scope

Use this for HTTP services, source code for web apps, APIs, browser-side logic, auth flows, cookies, JWTs, templates, file upload, and server-side request behavior.

## Mindset

Model the application before attacking it. The fastest solves usually come from understanding how requests move through routing, auth, data access, and rendering, then identifying where trust is misplaced. Fuzzing is useful, but source-guided reasoning is better whenever code is available.

## First Pass

1. Identify the framework, routes, entrypoints, config files, and dependencies.
2. Read server-side code before fuzzing when source is available.
3. Inspect client-side JavaScript for hidden routes, API schemas, tokens, and assumptions.
4. Track authentication, authorization checks, serialization, template rendering, and file handling.
5. Save endpoints, parameters, credentials, cookies, and interesting responses in `notes.md`.

## Deep Checks

1. Trace one request end to end: entrypoint, middleware, controller, data fetch, template or JSON response.
2. Identify every place the app converts types or crosses trust boundaries, especially headers, path params, query params, uploaded files, and server-side fetches.
3. Compare frontend assumptions with backend enforcement. Hidden buttons are not authorization.
4. Inspect configuration for debug modes, secret management, storage backends, proxies, and internal service URLs.
5. Look for multi-step exploit chains, because HTB web challenges often require combining a low-severity primitive with a second trust mistake.

## Common Pivots

Check SQL injection, command injection, SSTI, path traversal, SSRF, insecure deserialization, JWT mistakes, IDOR, prototype pollution, weak upload validation, and debug endpoints.

## Workflow

1. Map routes, features, and state transitions manually or from source.
2. Reproduce promising requests with `curl` or Burp so the exploit path is scriptable.
3. Confirm the primitive in the simplest possible request before expanding the chain.
4. Build the exploit from stable request/response behavior, not browser click history.
5. Preserve the exact payloads, cookies, and headers that made the difference.

## Pitfalls

Do not brute force directories before reading the available code. Do not confuse reflected input with actual code execution. Do not lose session state details; many web solves fail because one header, cookie, or CSRF token was omitted in the reproduced request.

## Useful Tools

`curl`, `httpie`, `ffuf`, `feroxbuster`, `nuclei`, `jq`, browser devtools, Burp Suite, `python`.

## Writeup Notes

Describe the application behavior first, then the misplaced trust or vulnerability, then the exploit chain. Include only the requests or commands needed to reproduce the solve cleanly.
