# Crypto Skill

## Scope

Use this for ciphers, signatures, key exchange, hashes, encodings, number theory, custom protocols, and challenge scripts that generate ciphertexts.

## Mindset

Treat every primitive as an implementation of assumptions. The job is not to admire the math; it is to identify which assumption the author broke, what information leaks because of that break, and how to turn the leak into a deterministic recovery path. Keep the algebra grounded in the exact bytes, integers, and transcripts present in the challenge.

## First Pass

1. Identify inputs, outputs, secret material, and attacker-controlled values.
2. Read the challenge script and rewrite the math in plain language.
3. Check for reused nonces, weak randomness, small parameters, oracle behavior, and leaked structure.
4. Preserve all given ciphertexts, public keys, and transcripts.
5. Build a small solver script once the weakness is clear.

## Deep Checks

1. Normalize every value into a reproducible form: integers, hex, byte strings, endianness, and block boundaries.
2. Separate what is public from what only looks public. A debug print, timing difference, or malformed error path is often the real leak.
3. Inspect randomness sources, seeding, counters, timestamps, and challenge restarts. Many HTB crypto tasks fail because the random source is predictable or reused.
4. Compare the implementation against the textbook primitive. Most breaks come from padding, nonce handling, parameter selection, subgroup mistakes, or homegrown glue logic between otherwise sound components.
5. If there is an oracle, define the exact question you can ask it and what one response bit tells you. Then turn that into a loop or search strategy instead of ad hoc probing.

## Common Pivots

Try XOR known plaintext, RSA small exponent, common modulus, factorable modulus, LCG recovery, padding oracle, length extension, nonce reuse, ECB patterns, and bad custom crypto.

## Workflow

1. Reproduce the transform locally from the provided script or samples.
2. Annotate the data flow so each ciphertext component has a meaning.
3. Prove a candidate weakness with a tiny local example before scaling it to the challenge data.
4. Write the shortest solver that recovers the secret or flag reliably in one run.
5. Save intermediate recovered values so you can explain the solve path later without recomputing everything manually.

## Pitfalls

Do not jump straight into Sage or symbolic tools before verifying the byte-level mechanics. Do not assume an RSA challenge is about factoring; many are about padding, CRT misuse, or leakage. Do not leave conversions implicit, because half of crypto debugging is realizing one side is treating ASCII hex as raw bytes.

## Useful Tools

`python`, `sage`, `openssl`, `xxd`, `CyberChef`, `RsaCtfTool`, `hashcat`.

## Writeup Notes

Explain the broken assumption first, then the observable consequence, then the recovery step. Include either the final solver or the critical equations and conversions needed to reproduce it.
