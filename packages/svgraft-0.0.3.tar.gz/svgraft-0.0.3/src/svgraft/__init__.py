__version__ = "0.0.3"
__author__ = "Derek Baier"
__email__ = "derek.m.baier@gmail.com"