"""作业模型定义。

提供作业数据模型和创建工具：
- Job: 作业数据模型
- JobType: 作业类型
- create_callable_job: 创建 Callable 作业
- create_dag_job: 创建 DAG 作业
"""

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable

from pydantic import BaseModel, Field, PrivateAttr

from epscheduler.dag import DAG
from epscheduler.exceptions import JobConfigError
from epscheduler.state import JobStatus
from epscheduler.triggers import Trigger

__all__ = [
    "Job",
    "JobType",
    "create_callable_job",
    "create_dag_job",
]


class JobType(str, Enum):
    """作业类型。

    Attributes:
        CALLABLE: 普通可调用任务，直接执行一个函数。
        DAG: DAG 任务，执行一个 DAG 工作流。
    """

    CALLABLE = "callable"
    DAG = "dag"


class Job(BaseModel):
    """作业数据模型。

    作业是调度框架的核心实体，封装了触发器、执行逻辑和运行状态。

    支持两种类型：
    - Callable 任务：直接执行一个函数
    - DAG 任务：执行一个 DAG 工作流

    内部持有触发器、可执行函数或 DAG 实例（不参与序列化），
    通过 trigger、callable、dag 属性访问。

    Attributes:
        job_id: 作业唯一标识。
        name: 作业名称。
        job_type: 作业类型。
        params: 任务执行参数。
        max_runs: 最大运行次数，None 表示无限制。
        run_count: 已运行次数。
        next_run_time: 下次运行时间。
        last_run_time: 上次运行时间。
        last_run_result: 上次运行结果。
        status: 作业状态。
        created_at: 创建时间。
        updated_at: 更新时间。
    """

    job_id: str = Field(..., description="作业唯一标识")
    name: str = Field(..., description="作业名称")
    job_type: JobType = Field(default=JobType.CALLABLE, description="作业类型")
    params: dict[str, Any] = Field(default_factory=dict, description="任务执行参数")
    max_runs: int | None = Field(default=None, ge=1, description="最大运行次数")
    run_count: int = Field(default=0, ge=0, description="已运行次数")
    next_run_time: datetime | None = Field(default=None, description="下次运行时间")
    last_run_time: datetime | None = Field(default=None, description="上次运行时间")
    last_run_result: Any = Field(default=None, description="上次运行结果")
    status: JobStatus = Field(default=JobStatus.PENDING, description="作业状态")
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc), description="创建时间"
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc), description="更新时间"
    )

    # 私有字段，不参与序列化
    _trigger: Trigger | None = PrivateAttr(default=None)
    _callable: Callable[..., Any] | None = PrivateAttr(default=None)
    _dag: DAG | None = PrivateAttr(default=None)

    def model_post_init(self, __context: Any) -> None:
        """Pydantic 模型初始化后的处理。"""
        # 确保 next_run_time 在首次创建时被计算
        if self.next_run_time is None and self._trigger is not None:
            self.next_run_time = self._trigger.next_fire_time(None)

    @property
    def trigger(self) -> Trigger | None:
        """获取触发器。"""
        return self._trigger

    def set_trigger(self, trigger: Trigger) -> None:
        """设置触发器并计算下次运行时间。

        Args:
            trigger: Trigger 实例。
        """
        self._trigger = trigger
        self.next_run_time = trigger.next_fire_time(None)
        self.updated_at = datetime.now(timezone.utc)

    @property
    def callable(self) -> Callable[..., Any] | None:
        """获取可执行函数。"""
        return self._callable

    def set_callable(self, fn: Callable[..., Any]) -> None:
        """设置可执行函数。

        Args:
            fn: 可执行函数。

        Raises:
            JobConfigError: 作业类型不是 CALLABLE 时抛出。
        """
        if self.job_type != JobType.CALLABLE:
            raise JobConfigError("只有 CALLABLE 类型作业可以设置 callable")
        self._callable = fn
        self.updated_at = datetime.now(timezone.utc)

    @property
    def dag(self) -> DAG | None:
        """获取 DAG 实例。"""
        return self._dag

    def set_dag(self, dag: DAG) -> None:
        """设置 DAG 实例。

        Args:
            dag: DAG 实例。

        Raises:
            JobConfigError: 作业类型不是 DAG 时抛出。
        """
        if self.job_type != JobType.DAG:
            raise JobConfigError("只有 DAG 类型作业可以设置 DAG")
        self._dag = dag
        self.updated_at = datetime.now(timezone.utc)

    def is_callable_job(self) -> bool:
        """检查是否为 Callable 任务。"""
        return self.job_type == JobType.CALLABLE

    def is_dag_job(self) -> bool:
        """检查是否为 DAG 任务。"""
        return self.job_type == JobType.DAG

    def is_due(self, now: datetime) -> bool:
        """检查作业是否到期执行。

        Args:
            now: 当前时间。

        Returns:
            是否到期执行。
        """
        # PAUSED 和 COMPLETED 状态不执行
        if self.status in (JobStatus.PAUSED, JobStatus.COMPLETED):
            return False

        if self.next_run_time is None:
            return False

        if self.max_runs is not None and self.run_count >= self.max_runs:
            return False

        return self.next_run_time <= now

    def mark_running(self) -> None:
        """标记作业为运行状态。"""
        self.status = JobStatus.RUNNING
        self.updated_at = datetime.now(timezone.utc)

    def mark_completed(self, result: Any = None) -> None:
        """标记作业完成。

        Args:
            result: 执行结果。
        """
        self.run_count += 1
        self.last_run_time = datetime.now(timezone.utc)
        self.last_run_result = result

        # 计算下次运行时间
        if self._trigger is not None:
            self.next_run_time = self._trigger.next_fire_time(self.last_run_time)

        # 检查是否达到最大运行次数
        if self.max_runs is not None and self.run_count >= self.max_runs:
            self.status = JobStatus.COMPLETED
        else:
            self.status = JobStatus.SUCCESS

        self.updated_at = datetime.now(timezone.utc)

    def mark_failed(self, error: Exception | None = None) -> None:
        """标记作业失败。

        Args:
            error: 错误信息。
        """
        self.status = JobStatus.FAILED
        self.run_count += 1
        self.last_run_time = datetime.now(timezone.utc)
        self.last_run_result = str(error) if error else None
        self.updated_at = datetime.now(timezone.utc)

    def pause(self) -> None:
        """暂停作业。

        Raises:
            JobConfigError: 运行中或已完成的作业不能暂停。
        """
        if self.status == JobStatus.RUNNING:
            raise JobConfigError("运行中的作业不能暂停")
        if self.status == JobStatus.COMPLETED:
            raise JobConfigError("已完成的作业不能暂停")
        self.status = JobStatus.PAUSED
        self.updated_at = datetime.now(timezone.utc)

    def resume(self) -> None:
        """恢复作业。

        恢复后状态为 PENDING，表示重新激活等待下次触发。

        Raises:
            JobConfigError: 只有暂停状态的作业可以恢复。
        """
        if self.status != JobStatus.PAUSED:
            raise JobConfigError("只有暂停状态的作业可以恢复")
        self.status = JobStatus.PENDING
        self.updated_at = datetime.now(timezone.utc)

    def reset(self) -> None:
        """重置作业状态。

        重置为初始状态 PENDING，清空运行记录。
        """
        self.run_count = 0
        self.next_run_time = (
            self._trigger.next_fire_time(None) if self._trigger else None
        )
        self.last_run_time = None
        self.last_run_result = None
        self.status = JobStatus.PENDING
        self.updated_at = datetime.now(timezone.utc)

    def can_run(self) -> bool:
        """检查作业是否可以运行。

        Returns:
            是否可以运行。
        """
        # PAUSED 和 COMPLETED 状态不能运行
        if self.status in (JobStatus.PAUSED, JobStatus.COMPLETED):
            return False

        if self.max_runs is not None and self.run_count >= self.max_runs:
            return False

        if self.job_type == JobType.CALLABLE and self._callable is None:
            return False

        if self.job_type == JobType.DAG and self._dag is None:
            return False

        return True

    def to_dict(self) -> dict[str, Any]:
        """转换为字典（用于序列化）。

        注意：callable 和 dag 不参与序列化，需要单独处理。

        Returns:
            作业配置字典。
        """
        data = {
            "job_id": self.job_id,
            "name": self.name,
            "job_type": self.job_type.value,
            "params": self.params,
            "max_runs": self.max_runs,
            "run_count": self.run_count,
            "next_run_time": (
                self.next_run_time.isoformat() if self.next_run_time else None
            ),
            "last_run_time": (
                self.last_run_time.isoformat() if self.last_run_time else None
            ),
            "last_run_result": self.last_run_result,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
        }

        # 序列化触发器
        if self._trigger is not None:
            data["trigger"] = self._trigger.model_dump()

        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Job":
        """从字典创建作业实例。

        Args:
            data: 作业配置字典。

        Returns:
            Job 实例。

        Raises:
            JobConfigError: status 字段无效时抛出。

        Note:
            trigger、callable、dag 需要在创建后单独设置。
        """
        # 解析时间字段
        next_run_time = None
        if data.get("next_run_time"):
            next_run_time = datetime.fromisoformat(data["next_run_time"])

        last_run_time = None
        if data.get("last_run_time"):
            last_run_time = datetime.fromisoformat(data["last_run_time"])

        created_at = datetime.now(timezone.utc)
        if data.get("created_at"):
            created_at = datetime.fromisoformat(data["created_at"])

        updated_at = datetime.now(timezone.utc)
        if data.get("updated_at"):
            updated_at = datetime.fromisoformat(data["updated_at"])

        # 解析并校验 status
        status_str = data.get("status", "pending")
        try:
            status = JobStatus(status_str)
        except ValueError:
            valid_statuses = [s.value for s in JobStatus]
            raise JobConfigError(
                f"无效的 status 值: {status_str}，有效值为: {valid_statuses}"
            )

        return cls(
            job_id=data["job_id"],
            name=data["name"],
            job_type=JobType(data.get("job_type", "callable")),
            params=data.get("params", {}),
            max_runs=data.get("max_runs"),
            run_count=data.get("run_count", 0),
            next_run_time=next_run_time,
            last_run_time=last_run_time,
            last_run_result=data.get("last_run_result"),
            status=status,
            created_at=created_at,
            updated_at=updated_at,
        )


def create_callable_job(
    job_id: str,
    name: str,
    trigger: Trigger,
    fn: Callable[..., Any],
    params: dict[str, Any] | None = None,
    max_runs: int | None = None,
) -> Job:
    """创建 Callable 类型作业。

    Args:
        job_id: 作业唯一标识。
        name: 作业名称。
        trigger: 触发器实例。
        fn: 可执行函数。
        params: 任务执行参数。
        max_runs: 最大运行次数。

    Returns:
        Job 实例。

    Example:
        >>> from epscheduler.triggers import IntervalTrigger
        >>> trigger = IntervalTrigger(seconds=10)
        >>> job = create_callable_job("job_1", "test", trigger, lambda: print("hello"))
    """
    job = Job(
        job_id=job_id,
        name=name,
        job_type=JobType.CALLABLE,
        params=params or {},
        max_runs=max_runs,
    )
    job.set_trigger(trigger)
    job.set_callable(fn)
    return job


def create_dag_job(
    job_id: str,
    name: str,
    trigger: Trigger,
    dag: DAG,
    params: dict[str, Any] | None = None,
    max_runs: int | None = None,
    validate_dag: bool = False,
) -> Job:
    """创建 DAG 类型作业。

    Args:
        job_id: 作业唯一标识。
        name: 作业名称。
        trigger: 触发器实例。
        dag: DAG 实例。
        params: DAG 初始参数。
        max_runs: 最大运行次数。
        validate_dag: 是否验证 DAG 有效性，默认 False（允许空 DAG）。

    Returns:
        Job 实例。

    Raises:
        JobConfigError: validate_dag=True 且 DAG 无效时抛出。

    Example:
        >>> from epscheduler.triggers import CronTrigger
        >>> from epscheduler.dag import DAG
        >>> trigger = CronTrigger("0 9 * * *")
        >>> dag = DAG()
        >>> job = create_dag_job("dag_1", "daily_report", trigger, dag)
    """
    # 可选验证 DAG
    if validate_dag and not dag.validate():
        raise JobConfigError("DAG 配置无效")

    job = Job(
        job_id=job_id,
        name=name,
        job_type=JobType.DAG,
        params=params or {},
        max_runs=max_runs,
    )
    job.set_trigger(trigger)
    job.set_dag(dag)
    return job
