"""数据库作业存储实现。"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Sequence

from sqlalchemy import delete, or_, select
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)

from epscheduler.exceptions import JobConfigError
from epscheduler.job import Job
from epscheduler.triggers import create_trigger

from .base import JobStore
from .db_models import create_job_model


class DBJobStore(JobStore):
    """数据库作业存储。

    使用 SQLAlchemy 2.0 异步支持，兼容多种数据库。

    支持的数据库（通过不同的连接 URL）：
    - SQLite: sqlite+aiosqlite:///path/to/database.db
    - PostgreSQL: postgresql+asyncpg://user:pass@host/db
    - MySQL: mysql+aiomysql://user:pass@host/db

    Example:
        >>> # SQLite
        >>> store = DBJobStore("sqlite+aiosqlite:///jobs.db")
        >>>
        >>> # PostgreSQL
        >>> store = DBJobStore("postgresql+asyncpg://user:pass@localhost/epscheduler")
        >>>
        >>> # 使用现有引擎
        >>> store = DBJobStore(engine=my_async_engine)
    """

    def __init__(
        self,
        url: str | None = None,
        *,
        engine: Any | None = None,
        session_factory: async_sessionmaker[AsyncSession] | None = None,
        table_name: str = "epscheduler_jobs",
        echo: bool = False,
        **engine_kwargs: Any,
    ) -> None:
        """初始化数据库存储。

        Args:
            url: 数据库连接 URL。
                - SQLite: sqlite+aiosqlite:///path/to/db.db
                - PostgreSQL: postgresql+asyncpg://user:pass@host/db
                - MySQL: mysql+aiomysql://user:pass@host/db
            engine: 现有的异步引擎实例（与 url 二选一）。
            session_factory: 现有的会话工厂（可选，用于更精细控制）。
            table_name: 表名，默认 "epscheduler_jobs"。
            echo: 是否输出 SQL 日志。
            **engine_kwargs: 传递给 create_async_engine 的额外参数。

        Raises:
            ValueError: url 和 engine 都未提供时抛出。
        """
        if engine is not None:
            self._engine = engine
            self._owns_engine = False
        elif url is not None:
            self._engine = create_async_engine(url, echo=echo, **engine_kwargs)
            self._owns_engine = True
        else:
            raise ValueError("必须提供 url 或 engine 参数")

        if session_factory is not None:
            self._session_factory = session_factory
        else:
            self._session_factory = async_sessionmaker(
                self._engine, class_=AsyncSession, expire_on_commit=False
            )

        # 创建动态模型
        self._JobModel = create_job_model(table_name)
        self._initialized = False

    async def _ensure_tables(self) -> None:
        """确保表已创建。"""
        if self._initialized:
            return
        async with self._engine.begin() as conn:
            # 只创建当前模型的表
            await conn.run_sync(self._JobModel.__table__.create, checkfirst=True)
        self._initialized = True

    def _model_to_job(self, model: Any) -> Job:
        """将 ORM 模型转换为 Job 实例。

        Args:
            model: JobModel 实例。

        Returns:
            Job 实例。
        """

        # 处理时区问题：SQLite 不保留时区，读取后假设为 UTC
        def ensure_utc(dt: datetime | None) -> datetime | None:
            if dt is None:
                return None
            if dt.tzinfo is None:
                return dt.replace(tzinfo=timezone.utc)
            return dt

        next_run_time = ensure_utc(model.next_run_time)
        last_run_time = ensure_utc(model.last_run_time)
        created_at = ensure_utc(model.created_at)
        updated_at = ensure_utc(model.updated_at)

        # 构建字典，时间字段转为 ISO 字符串（复用 Job.from_dict 的逻辑）
        data = {
            "job_id": model.job_id,
            "name": model.name,
            "job_type": model.job_type,
            "params": json.loads(model.params) if model.params else {},
            "max_runs": model.max_runs,
            "run_count": model.run_count,
            "next_run_time": next_run_time.isoformat() if next_run_time else None,
            "last_run_time": last_run_time.isoformat() if last_run_time else None,
            "last_run_result": model.last_run_result,
            "status": model.status,
            "created_at": created_at.isoformat() if created_at else None,
            "updated_at": updated_at.isoformat() if updated_at else None,
        }

        job = Job.from_dict(data)

        # 恢复触发器（不使用 set_trigger，避免覆盖 next_run_time）
        if model.trigger:
            trigger_data = json.loads(model.trigger)
            trigger = create_trigger(trigger_data)
            job._trigger = trigger

        return job

    def _job_to_model(self, job: Job, model: Any | None = None) -> Any:
        """将 Job 实例转换为 ORM 模型。

        Args:
            job: Job 实例。
            model: 现有模型实例（用于更新），为 None 则创建新实例。

        Returns:
            JobModel 实例。
        """
        job_dict = job.to_dict()

        if model is None:
            model = self._JobModel()

        model.job_id = job_dict["job_id"]
        model.name = job_dict["name"]
        model.job_type = job_dict["job_type"]
        model.params = json.dumps(job_dict.get("params", {}))
        model.max_runs = job_dict.get("max_runs")
        model.run_count = job_dict["run_count"]
        model.next_run_time = job.next_run_time
        model.last_run_time = job.last_run_time
        model.last_run_result = (
            str(job_dict.get("last_run_result")) if job_dict.get("last_run_result") else None
        )
        model.status = job_dict["status"]
        model.trigger = json.dumps(job_dict["trigger"]) if job_dict.get("trigger") else None
        model.created_at = job.created_at
        model.updated_at = job.updated_at

        return model

    async def add(self, job: Job) -> str:
        """添加作业到存储。

        Args:
            job: Job 实例。

        Returns:
            作业 ID。

        Raises:
            JobConfigError: 作业 ID 已存在时抛出。
        """
        await self._ensure_tables()

        async with self._session_factory() as session:
            # 检查是否存在
            existing = await session.get(self._JobModel, job.job_id)
            if existing:
                raise JobConfigError(f"作业 ID 已存在: {job.job_id}")

            model = self._job_to_model(job)
            session.add(model)
            await session.commit()

        return job.job_id

    async def get(self, job_id: str) -> Job | None:
        """根据 ID 获取作业。

        Args:
            job_id: 作业 ID。

        Returns:
            Job 实例，不存在则返回 None。
        """
        await self._ensure_tables()

        async with self._session_factory() as session:
            model = await session.get(self._JobModel, job_id)
            if model:
                return self._model_to_job(model)
            return None

    async def list_all(self) -> Sequence[Job]:
        """列出所有作业。

        Returns:
            所有 Job 实例列表。
        """
        await self._ensure_tables()

        async with self._session_factory() as session:
            stmt = select(self._JobModel).order_by(self._JobModel.created_at)
            result = await session.execute(stmt)
            models = result.scalars().all()
            return [self._model_to_job(model) for model in models]

    async def remove(self, job_id: str) -> bool:
        """删除作业。

        Args:
            job_id: 作业 ID。

        Returns:
            删除成功返回 True，不存在返回 False。
        """
        await self._ensure_tables()

        async with self._session_factory() as session:
            stmt = delete(self._JobModel).where(self._JobModel.job_id == job_id)
            result = await session.execute(stmt)
            await session.commit()
            return result.rowcount > 0

    async def update(self, job: Job) -> bool:
        """更新作业。

        Args:
            job: Job 实例。

        Returns:
            更新成功返回 True，不存在返回 False。
        """
        await self._ensure_tables()

        async with self._session_factory() as session:
            model = await session.get(self._JobModel, job.job_id)
            if model is None:
                return False

            self._job_to_model(job, model)
            await session.commit()
            return True

    async def get_due_jobs(self, now: datetime) -> Sequence[Job]:
        """获取当前时间需要触发的作业列表。

        Args:
            now: 当前时间。

        Returns:
            到期执行的 Job 列表。
        """
        await self._ensure_tables()

        # 处理时区问题：某些数据库（如 SQLite）不保留时区信息
        # 查询时使用 naive datetime 比较
        query_time = now.replace(tzinfo=None) if now.tzinfo else now

        async with self._session_factory() as session:
            # 查询到期作业
            stmt = (
                select(self._JobModel)
                .where(self._JobModel.status.not_in(["paused", "completed"]))
                .where(self._JobModel.next_run_time.is_not(None))
                .where(self._JobModel.next_run_time <= query_time)
                .where(
                    or_(
                        self._JobModel.max_runs.is_(None),
                        self._JobModel.run_count < self._JobModel.max_runs,
                    )
                )
                .order_by(self._JobModel.next_run_time)
            )
            result = await session.execute(stmt)
            models = result.scalars().all()
            jobs = [self._model_to_job(model) for model in models]

            # 使用 Job.is_due 方法进行二次校验
            return [job for job in jobs if job.is_due(now)]

    async def count(self) -> int:
        """获取作业总数。

        Returns:
            作业数量。
        """
        await self._ensure_tables()

        async with self._session_factory() as session:
            stmt = select(self._JobModel.job_id)
            result = await session.execute(stmt)
            return len(result.all())

    async def clear(self) -> None:
        """清空所有作业。"""
        await self._ensure_tables()

        async with self._session_factory() as session:
            stmt = delete(self._JobModel)
            await session.execute(stmt)
            await session.commit()

    async def get_jobs_by_status(self, status: str) -> Sequence[Job]:
        """按状态获取作业列表。

        Args:
            status: 作业状态值。

        Returns:
            指定状态的 Job 实例列表。
        """
        await self._ensure_tables()

        async with self._session_factory() as session:
            stmt = (
                select(self._JobModel)
                .where(self._JobModel.status == status)
                .order_by(self._JobModel.created_at)
            )
            result = await session.execute(stmt)
            models = result.scalars().all()
            return [self._model_to_job(model) for model in models]

    async def close(self) -> None:
        """关闭存储，释放资源。

        仅当本实例创建了引擎时才会关闭。
        """
        if self._owns_engine:
            await self._engine.dispose()
