"""文件作业存储（Pickle 持久化）。"""

import pickle
from datetime import datetime
from pathlib import Path
from typing import Any, Sequence

from epscheduler.exceptions import JobConfigError
from epscheduler.job import Job
from epscheduler.triggers import create_trigger

from .base import JobStore


class FileJobStore(JobStore):
    """文件作业存储。

    将作业数据持久化到本地 pickle 文件。
    适合简单场景的持久化需求。

    重要限制：
    - **callable（可执行函数）不参与序列化**：从文件加载后，Job 的 callable 属性为 None，
      需要手动通过 `job.set_callable(fn)` 重新设置才能执行。
    - **dag（DAG 实例）不参与序列化**：从文件加载后，Job 的 dag 属性为 None，
      需要手动通过 `job.set_dag(dag)` 重新设置才能执行 DAG 作业。
    - trigger（触发器）会自动序列化和恢复。
    - 使用 pickle 存储，存在安全风险，勿加载不可信数据。

    Example:
        >>> store = FileJobStore("jobs.pkl")
        >>> job = create_callable_job("job_1", "测试", trigger, my_func)
        >>> await store.add(job)
        >>> # 加载后需要重新设置 callable
        >>> loaded = await store.get("job_1")
        >>> if loaded:
        >>>     loaded.set_callable(my_func)  # 必须重新设置
    """

    def __init__(self, filepath: str | Path = "jobs.pkl") -> None:
        """初始化文件存储。

        Args:
            filepath: pickle 文件路径。
        """
        self.filepath = Path(filepath)
        self._jobs: dict[str, Job] = {}
        self._load()

    def _load(self) -> None:
        """从文件加载作业数据。"""
        if self.filepath.exists():
            try:
                with open(self.filepath, "rb") as f:
                    data: dict[str, Any] = pickle.load(f)

                for job_id, job_dict in data.items():
                    job = Job.from_dict(job_dict)

                    # 恢复触发器
                    if "trigger" in job_dict:
                        trigger = create_trigger(job_dict["trigger"])
                        job.set_trigger(trigger)

                    self._jobs[job_id] = job
            except Exception:
                # 加载失败时使用空存储
                self._jobs = {}

    def _save(self) -> None:
        """保存作业数据到文件。"""
        data = {job_id: job.to_dict() for job_id, job in self._jobs.items()}

        with open(self.filepath, "wb") as f:
            pickle.dump(data, f)

    async def add(self, job: Job) -> str:
        """添加作业到存储。

        Args:
            job: Job 实例。

        Returns:
            作业 ID。

        Raises:
            JobConfigError: 作业 ID 已存在时抛出。
        """
        if job.job_id in self._jobs:
            raise JobConfigError(f"作业 ID 已存在: {job.job_id}")

        self._jobs[job.job_id] = job
        self._save()
        return job.job_id

    async def get(self, job_id: str) -> Job | None:
        """根据 ID 获取作业。

        Args:
            job_id: 作业 ID。

        Returns:
            Job 实例，不存在则返回 None。
        """
        return self._jobs.get(job_id)

    async def list_all(self) -> Sequence[Job]:
        """列出所有作业。

        Returns:
            所有 Job 实例列表。
        """
        return list(self._jobs.values())

    async def remove(self, job_id: str) -> bool:
        """删除作业。

        Args:
            job_id: 作业 ID。

        Returns:
            删除成功返回 True，不存在返回 False。
        """
        if job_id in self._jobs:
            del self._jobs[job_id]
            self._save()
            return True
        return False

    async def update(self, job: Job) -> bool:
        """更新作业。

        Args:
            job: Job 实例。

        Returns:
            更新成功返回 True，不存在返回 False。
        """
        if job.job_id in self._jobs:
            self._jobs[job.job_id] = job
            self._save()
            return True
        return False

    async def get_due_jobs(self, now: datetime) -> Sequence[Job]:
        """获取当前时间需要触发的作业列表。

        Args:
            now: 当前时间。

        Returns:
            到期执行的 Job 列表。
        """
        due_jobs = [job for job in self._jobs.values() if job.is_due(now)]
        due_jobs.sort(key=lambda j: j.next_run_time or now)
        return due_jobs

    async def count(self) -> int:
        """获取作业总数。

        Returns:
            作业数量。
        """
        return len(self._jobs)

    async def clear(self) -> None:
        """清空所有作业。"""
        self._jobs.clear()
        self._save()
