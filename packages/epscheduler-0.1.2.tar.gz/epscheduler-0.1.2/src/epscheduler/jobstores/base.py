"""作业存储抽象基类。"""

from abc import ABC, abstractmethod
from datetime import datetime
from typing import Sequence

from epscheduler.job import Job


class JobStore(ABC):
    """作业存储抽象基类。

    管理 Job 的 CRUD 操作和查询到期作业。
    存储是 Scheduler 和 Job 之间的存储层。
    """

    @abstractmethod
    async def add(self, job: Job) -> str:
        """添加作业到存储。

        Args:
            job: Job 实例。

        Returns:
            作业 ID。

        Raises:
            JobConfigError: 作业 ID 已存在时抛出。
        """
        ...

    @abstractmethod
    async def get(self, job_id: str) -> Job | None:
        """根据 ID 获取作业。

        Args:
            job_id: 作业 ID。

        Returns:
            Job 实例，不存在则返回 None。
        """
        ...

    @abstractmethod
    async def list_all(self) -> Sequence[Job]:
        """列出所有作业。

        Returns:
            所有 Job 实例列表。
        """
        ...

    @abstractmethod
    async def remove(self, job_id: str) -> bool:
        """删除作业。

        Args:
            job_id: 作业 ID。

        Returns:
            删除成功返回 True，不存在返回 False。
        """
        ...

    @abstractmethod
    async def update(self, job: Job) -> bool:
        """更新作业。

        Args:
            job: Job 实例。

        Returns:
            更新成功返回 True，不存在返回 False。
        """
        ...

    @abstractmethod
    async def get_due_jobs(self, now: datetime) -> Sequence[Job]:
        """获取当前时间需要触发的作业列表。

        Args:
            now: 当前时间。

        Returns:
            到期执行的 Job 列表。
        """
        ...

    @abstractmethod
    async def count(self) -> int:
        """获取作业总数。

        Returns:
            作业数量。
        """
        ...

    @abstractmethod
    async def clear(self) -> None:
        """清空所有作业。"""
        ...
