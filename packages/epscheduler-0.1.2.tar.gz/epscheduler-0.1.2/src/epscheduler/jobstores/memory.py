"""内存作业存储。"""

from datetime import datetime
from typing import Sequence

from epscheduler.exceptions import JobConfigError
from epscheduler.job import Job

from .base import JobStore


class MemoryJobStore(JobStore):
    """内存作业存储。

    使用字典存储作业，适合开发、测试和临时调度场景。
    作业数据不持久化，进程结束后丢失。
    """

    def __init__(self) -> None:
        """初始化内存存储。"""
        self._jobs: dict[str, Job] = {}

    async def add(self, job: Job) -> str:
        """添加作业到存储。

        Args:
            job: Job 实例。

        Returns:
            作业 ID。

        Raises:
            JobConfigError: 作业 ID 已存在时抛出。
        """
        if job.job_id in self._jobs:
            raise JobConfigError(f"作业 ID 已存在: {job.job_id}")

        self._jobs[job.job_id] = job
        return job.job_id

    async def get(self, job_id: str) -> Job | None:
        """根据 ID 获取作业。

        Args:
            job_id: 作业 ID。

        Returns:
            Job 实例，不存在则返回 None。
        """
        return self._jobs.get(job_id)

    async def list_all(self) -> Sequence[Job]:
        """列出所有作业。

        Returns:
            所有 Job 实例列表。
        """
        return list(self._jobs.values())

    async def remove(self, job_id: str) -> bool:
        """删除作业。

        Args:
            job_id: 作业 ID。

        Returns:
            删除成功返回 True，不存在返回 False。
        """
        if job_id in self._jobs:
            del self._jobs[job_id]
            return True
        return False

    async def update(self, job: Job) -> bool:
        """更新作业。

        Args:
            job: Job 实例。

        Returns:
            更新成功返回 True，不存在返回 False。
        """
        if job.job_id in self._jobs:
            self._jobs[job.job_id] = job
            return True
        return False

    async def get_due_jobs(self, now: datetime) -> Sequence[Job]:
        """获取当前时间需要触发的作业列表。

        Args:
            now: 当前时间。

        Returns:
            到期执行的 Job 列表。
        """
        due_jobs = [job for job in self._jobs.values() if job.is_due(now)]
        # 按下次运行时间排序
        due_jobs.sort(key=lambda j: j.next_run_time or now)
        return due_jobs

    async def count(self) -> int:
        """获取作业总数。

        Returns:
            作业数量。
        """
        return len(self._jobs)

    async def clear(self) -> None:
        """清空所有作业。"""
        self._jobs.clear()
