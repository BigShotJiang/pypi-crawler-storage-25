"""数据库作业模型。"""

from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Index, Integer, String, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    """ORM 基类。"""

    pass


# 模型类型缓存，避免重复创建同名类
_model_cache: dict[str, type] = {}


def create_job_model(table_name: str = "epscheduler_jobs") -> type:
    """动态创建 Job 模型类（带缓存）。

    Args:
        table_name: 表名，默认 "epscheduler_jobs"。

    Returns:
        JobModel 类。
    """
    # 使用缓存避免重复创建
    if table_name in _model_cache:
        return _model_cache[table_name]

    class JobModel(Base):
        """Job 数据库模型。"""

        __tablename__ = table_name
        __table_args__ = (
            Index(f"ix_{table_name}_next_run_time", "next_run_time"),
            Index(f"ix_{table_name}_status", "status"),
        )

        job_id: Mapped[str] = mapped_column(String(255), primary_key=True)
        name: Mapped[str] = mapped_column(String(500), nullable=False)
        job_type: Mapped[str] = mapped_column(String(50), nullable=False, default="callable")
        params: Mapped[str] = mapped_column(Text, nullable=False, default="{}")
        max_runs: Mapped[int | None] = mapped_column(Integer, nullable=True)
        run_count: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
        next_run_time: Mapped[datetime | None] = mapped_column(
            DateTime(timezone=True), nullable=True
        )
        last_run_time: Mapped[datetime | None] = mapped_column(
            DateTime(timezone=True), nullable=True
        )
        last_run_result: Mapped[str | None] = mapped_column(Text, nullable=True)
        status: Mapped[str] = mapped_column(String(50), nullable=False, default="pending")
        trigger: Mapped[str | None] = mapped_column(Text, nullable=True)
        created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
        updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)

        def __repr__(self) -> str:
            return f"<JobModel(job_id={self.job_id!r}, name={self.name!r}, status={self.status!r})>"

    # 设置类名便于调试
    JobModel.__name__ = f"JobModel_{table_name}"
    _model_cache[table_name] = JobModel
    return JobModel


# 默认模型（用于导出）
JobModel = create_job_model()
