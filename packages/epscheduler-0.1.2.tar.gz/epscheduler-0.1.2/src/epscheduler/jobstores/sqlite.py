"""SQLite 数据库作业存储。"""

from __future__ import annotations

from pathlib import Path

from sqlalchemy import create_engine

from .db import DBJobStore


class SQLiteJobStore(DBJobStore):
    """SQLite 数据库作业存储。

    使用 SQLite 数据库持久化作业数据。
    这是 DBJobStore 的 SQLite 便捷封装，自动配置 SQLite 连接。

    特点：
    - 自动配置 aiosqlite 异步驱动
    - 使用传统 `jobs` 表名（兼容旧版本）
    - 支持事务，数据安全可靠
    - 初始化时同步创建数据库文件

    Example:
        >>> store = SQLiteJobStore("jobs.db")
        >>> # 等同于 DBJobStore("sqlite+aiosqlite:///jobs.db", table_name="jobs")
    """

    def __init__(
        self,
        db_path: str | Path = "jobs.db",
        *,
        echo: bool = False,
        **engine_kwargs: str,
    ) -> None:
        """初始化 SQLite 存储。

        Args:
            db_path: 数据库文件路径，默认 "jobs.db"。
            echo: 是否输出 SQL 日志。
            **engine_kwargs: 传递给 SQLAlchemy 引擎的额外参数。
        """
        db_path = Path(db_path)

        # 先创建数据库文件（兼容旧版本行为）
        if not db_path.exists():
            # 使用同步引擎创建表
            sync_url = f"sqlite:///{db_path}"
            sync_engine = create_engine(sync_url)
            from .db_models import create_job_model

            job_model = create_job_model("jobs")
            job_model.__table__.create(sync_engine, checkfirst=True)
            sync_engine.dispose()

        # 转换为 SQLAlchemy 异步 URL
        url = f"sqlite+aiosqlite:///{db_path}"
        super().__init__(url, table_name="jobs", echo=echo, **engine_kwargs)
