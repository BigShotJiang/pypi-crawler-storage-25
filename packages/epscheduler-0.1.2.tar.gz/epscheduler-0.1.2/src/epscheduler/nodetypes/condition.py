from __future__ import annotations

from typing import Any

from epscheduler.nodetypes.base import BaseNode


class ConditionNode(BaseNode):
    """条件分支节点，根据上下文值选择下游执行路径。

    执行时返回 {"_branch": "匹配的分支名"}，DAG 根据此值跳过未选中的条件下游边。
    若无匹配分支，返回 {"_branch": None}。

    Attributes:
        key: context 中用于判断的键名。
        branches: 值到分支名的映射字典。
    """

    def __init__(self, key: str, branches: dict[Any, str], id: str = "", name: str = "") -> None:
        """初始化条件节点。

        Args:
            key: context 中用于判断的键名，节点执行时读取此键的值。
            branches: 值到分支名的映射。key 的值精确匹配 branches 的键时，返回对应分支名。
            id: 节点唯一标识。
            name: 节点名称。
        """
        super().__init__(id, name)
        self.key = key
        self.branches = branches

    async def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """执行条件判断，返回匹配的分支名。

        Args:
            context: DAG 共享上下文。

        Returns:
            {"_branch": 分支名}，无匹配时 {"_branch": None}。
        """
        value = context.get(self.key)
        branch = self.branches.get(value)
        return {"_branch": branch}
