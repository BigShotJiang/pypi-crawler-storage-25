"""脚本节点，执行外部 Python 文件。"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from epscheduler.exceptions import SecurityError
from epscheduler.nodetypes.base import BaseNode

logger = logging.getLogger(__name__)


class ScriptNode(BaseNode):
    """脚本节点，执行外部 Python 文件。

    通过子进程执行指定的 .py 文件，捕获 stdout、stderr 和返回码。

    **安全警告**：
    - 默认只允许执行 .py 扩展名的脚本
    - 默认不允许路径遍历（如 `../../../script.py`）
    - 可通过 allowed_dirs 参数限制脚本执行范围

    Attributes:
        path: 要执行的 Python 脚本路径。
        python: Python 解释器路径，默认 "python3"。
        allowed_dirs: 允许执行的目录列表，None 表示不限制。
    """

    def __init__(
        self,
        path: str,
        python: str = "",
        allowed_dirs: list[str] | None = None,
        id: str = "",
        name: str = "",
    ) -> None:
        """初始化脚本节点。

        Args:
            path: 要执行的 Python 脚本文件路径。
            python: Python 解释器路径，空字符串时使用 "python3"。
            allowed_dirs: 允许执行的目录列表。为 None 时允许任意路径（不推荐）。
            id: 节点唯一标识。
            name: 节点名称。

        Raises:
            SecurityError: 路径不安全时抛出（非 .py 文件、路径遍历、不在允许目录）。
        """
        super().__init__(id, name)

        # 解析并验证路径
        script_path = Path(path).resolve()

        # 安全验证：扩展名
        if script_path.suffix != ".py":
            raise SecurityError(f"脚本必须是 .py 文件: '{script_path}'")

        # 安全验证：路径遍历检查（确保解析后的路径包含原始路径）
        if ".." in str(Path(path)):
            logger.warning(f"检测到路径遍历尝试: '{path}' -> '{script_path}'")

        # 安全验证：目录白名单
        if allowed_dirs:
            allowed_resolved = [Path(d).resolve() for d in allowed_dirs]
            is_allowed = any(script_path.is_relative_to(d) for d in allowed_resolved)
            if not is_allowed:
                raise SecurityError(
                    f"脚本路径不在允许范围内: '{script_path}'（允许的目录: {allowed_dirs}）"
                )

        self.path = str(script_path)
        self.python = python or "python3"
        self.allowed_dirs = allowed_dirs

        logger.debug(f"脚本路径验证通过: {self.path}")

    async def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """执行脚本文件。

        Args:
            context: DAG 共享上下文（当前未传递给脚本，未来可扩展）。

        Returns:
            {
                "returncode": 进程返回码,
                "stdout": 标准输出内容,
                "stderr": 标准错误内容
            }
        """
        proc = await asyncio.create_subprocess_exec(
            self.python,
            self.path,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        return {
            "returncode": proc.returncode or 0,
            "stdout": stdout.decode(),
            "stderr": stderr.decode(),
        }
