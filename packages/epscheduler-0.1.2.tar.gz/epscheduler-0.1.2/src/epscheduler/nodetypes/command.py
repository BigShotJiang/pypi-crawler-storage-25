"""命令节点，执行终端命令。"""

from __future__ import annotations

import asyncio
import logging
import shlex
from typing import Any

from epscheduler.exceptions import SecurityError
from epscheduler.nodetypes.base import BaseNode

logger = logging.getLogger(__name__)

# shell 模式下的危险字符（可能导致命令注入）
DANGEROUS_SHELL_CHARS = [";", "|", "&", "$", "`", "\n", "\r", "(", ")"]


class CommandNode(BaseNode):
    """命令节点，执行终端/shell 命令。

    通过子进程执行 shell 命令，捕获 stdout、stderr 和返回码。
    支持 shell 模式（字符串命令）和 exec 模式（命令 + 参数列表）。

    **安全警告**：
    - shell=True 模式存在命令注入风险，请确保命令来源可信
    - 使用 allow_shell_injection=True 可绕过安全检查（仅限受控环境）
    - 生产环境推荐使用 shell=False 的 exec 模式

    Attributes:
        command: 要执行的命令（字符串或列表）。
        shell: 是否使用 shell 模式执行。True 时命令作为 shell 字符串执行；
               False 时命令作为程序路径，args 作为参数列表。
        cwd: 工作目录，None 时使用当前目录。
        env: 环境变量字典，None 时继承当前环境。
        timeout: 执行超时秒数，None 时无限制。
        allow_shell_injection: 是否允许 shell 模式下的危险字符（默认 False）。
    """

    def __init__(
        self,
        command: str | list[str],
        shell: bool = True,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        timeout: float | None = None,
        allow_shell_injection: bool = False,
        id: str = "",
        name: str = "",
    ) -> None:
        """初始化命令节点。

        Args:
            command: 要执行的命令。shell=True 时为字符串（如 "ls -la"）；
                     shell=False 时为列表（如 ["ls", "-la"]）。
            shell: 是否使用 shell 执行。shell=True 支持管道、重定向等 shell 特性。
            cwd: 工作目录。
            env: 环境变量。
            timeout: 执行超时秒数。
            allow_shell_injection: 是否允许危险 shell 字符。
                - False（默认）: 检测并拒绝危险字符，抛出 SecurityError
                - True: 允许所有字符（用于受控环境，如管道操作）
            id: 节点唯一标识。
            name: 节点名称。

        Raises:
            SecurityError: shell=True 且命令包含危险字符时抛出（除非 allow_shell_injection=True）。
        """
        super().__init__(id, name)
        self.command = command
        self.shell = shell
        self.cwd = cwd
        self.env = env
        self.timeout = timeout
        self.allow_shell_injection = allow_shell_injection

        # 安全检查：shell 模式下验证命令
        if shell and not allow_shell_injection:
            self._validate_shell_command()

    def _validate_shell_command(self) -> None:
        """验证 shell 命令的安全性。

        Raises:
            SecurityError: 命令包含危险字符时抛出。
        """
        cmd_str = self.command if isinstance(self.command, str) else shlex.join(self.command)

        for char in DANGEROUS_SHELL_CHARS:
            if char in cmd_str:
                logger.warning(f"命令包含潜在危险字符: '{char}'")
                raise SecurityError(
                    f"shell 模式下命令包含危险字符 '{char}'，可能导致命令注入。"
                    f"如需使用管道/重定向等特性，请设置 allow_shell_injection=True "
                    f"或使用 shell=False 的 exec 模式。"
                )

        logger.debug(f"命令安全验证通过: {cmd_str}")

    async def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """执行命令。

        Args:
            context: DAG 共享上下文（可用于参数替换，当前未实现）。

        Returns:
            {
                "returncode": 进程返回码,
                "stdout": 标准输出内容,
                "stderr": 标准错误内容,
                "success": 返回码是否为 0
            }

        Raises:
            asyncio.TimeoutError: 执行超时。
        """
        if self.shell:
            # shell 模式：直接执行命令字符串
            proc = await asyncio.create_subprocess_shell(
                self.command if isinstance(self.command, str) else shlex.join(self.command),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.cwd,
                env=self.env,
            )
        else:
            # exec 模式：直接执行程序
            cmd_list = self.command if isinstance(self.command, list) else shlex.split(self.command)
            proc = await asyncio.create_subprocess_exec(
                *cmd_list,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=self.cwd,
                env=self.env,
            )

        try:
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=self.timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            raise

        returncode = proc.returncode or 0
        return {
            "returncode": returncode,
            "stdout": stdout.decode(),
            "stderr": stderr.decode(),
            "success": returncode == 0,
        }
