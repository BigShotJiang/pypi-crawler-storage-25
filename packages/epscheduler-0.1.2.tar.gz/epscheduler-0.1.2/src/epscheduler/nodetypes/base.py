from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import Any

from epscheduler.state import NodeState


class BaseNode(ABC):
    """节点抽象基类，定义节点的身份标识和执行行为。

    所有具体节点类型（FuncNode、ConditionNode 等）都继承此类。
    调度器统一通过 node.execute(context) 调用节点执行逻辑。

    Attributes:
        id: 节点唯一标识符，未指定时自动生成 UUID。
        name: 节点名称，用于日志和调试，未指定时使用 "node_{id}"。
        state: 节点运行时状态（pending/success/failed/skipped）。
    """

    def __init__(self, id: str = "", name: str = "") -> None:
        """初始化节点。

        Args:
            id: 节点唯一标识，空字符串时自动生成 UUID。
            name: 节点名称，空字符串时使用默认格式。
        """
        self.id = id or uuid.uuid4().hex
        self.name = name or f"node_{self.id}"
        self.state: NodeState = NodeState.PENDING

    def __call__(self, context: dict[str, Any] | None = None) -> Any:
        """同步执行节点，用于独立运行或测试。

        用法: result = node({"x": 1})

        Args:
            context: 执行上下文，None 时使用空字典。

        Returns:
            执行结果。若结果仅包含 "_result" 键，则返回该值；否则返回完整字典。
        """
        import asyncio

        result = asyncio.run(self.execute(context or {}))
        if tuple(result.keys()) == ("_result",):
            return result["_result"]
        return result

    @abstractmethod
    async def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """执行节点逻辑（async，由框架或 run 方法调用）。

        Args:
            context: 共享上下文，包含 DAG 参数和上游节点的输出。

        Returns:
            执行结果字典，合并到共享上下文中传递给下游节点。
        """
        ...
