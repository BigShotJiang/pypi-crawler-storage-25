from collections.abc import Callable
from typing import Any

from epscheduler.nodetypes.command import CommandNode
from epscheduler.nodetypes.condition import ConditionNode
from epscheduler.nodetypes.func import FuncNode, func_node
from epscheduler.nodetypes.loop import LoopNode, loop_node
from epscheduler.nodetypes.script import ScriptNode


def inject(*keys: str) -> Callable[..., Any]:
    """装饰器：声明函数需要从 context 注入的参数。

    用于 FuncNode，执行时自动从 DAG 共享上下文中提取指定键的值作为函数参数。

    用法:
        @inject("x", "y")
        def process(x, y):
            return x + y

        node = FuncNode(fn=process)
        node.execute({"x": 1, "y": 2})  # 自动注入 x=1, y=2

    Args:
        *keys: 需要从 context 注入的参数名。

    Returns:
        装饰器函数，在原函数上添加 _context_keys 属性。
    """

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        fn._context_keys = keys  # type: ignore[attr-defined]
        return fn

    return decorator


__all__ = [
    "FuncNode",
    "ConditionNode",
    "LoopNode",
    "ScriptNode",
    "CommandNode",
    "inject",
    "func_node",
    "loop_node",
]
