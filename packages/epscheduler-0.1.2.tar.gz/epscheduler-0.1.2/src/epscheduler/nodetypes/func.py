from __future__ import annotations

import inspect
from typing import Any, Callable

from epscheduler.nodetypes.base import BaseNode


class FuncNode(BaseNode):
    """函数节点，封装可调用对象作为执行单元。

    最通用的节点类型，支持同步和异步函数。
    非 dict 返回值自动包装为 {"_result": value}。

    Attributes:
        fn: 被封装的可调用对象。
        args: 传递给 fn 的位置参数。
        kwargs: 传递给 fn 的关键字参数，可覆盖 context 注入。
    """

    def __init__(
        self, fn: Callable[..., Any], id: str = "", name: str = "", *args: Any, **kwargs: Any
    ) -> None:
        """初始化函数节点。

        Args:
            fn: 要执行的函数，支持同步和异步。
            id: 节点唯一标识。
            name: 节点名称。
            *args: 传递给 fn 的位置参数。
            **kwargs: 传递给 fn 的关键字参数，优先级高于 context 注入。
        """
        super().__init__(id, name)
        self.fn = fn
        self.args = args
        self.kwargs = kwargs

    async def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """执行封装的函数。

        自动从 context 注入 @inject 声明的参数，kwargs 中已有的参数不被覆盖。
        同步函数自动转换为异步执行。

        Args:
            context: DAG 共享上下文，包含上游节点的输出。

        Returns:
            执行结果字典。若 fn 返回非 dict，包装为 {"_result": value}。
        """
        kwargs = dict(self.kwargs)
        keys = getattr(self.fn, "_context_keys", ())
        for key in keys:
            if key in context and key not in kwargs:
                kwargs[key] = context[key]
        result = self.fn(*self.args, **kwargs)
        if inspect.isawaitable(result):
            result = await result
        if isinstance(result, dict):
            return result
        return {"_result": result}


def func_node(
    fn: Callable[..., Any] | None = None,
    *,
    id: str = "",
    name: str = "",
    **kwargs: Any,
) -> FuncNode | Callable[[Callable[..., Any]], FuncNode]:
    """装饰器：将函数直接包装为 FuncNode。

    支持两种用法：
        @func_node
        def my_func(): ...

        @func_node(id="step1", name="步骤一", x=10)
        def my_func(x): ...

    Args:
        fn: 要包装的函数，直接调用时提供。
        id: 节点唯一标识。
        name: 节点名称。
        **kwargs: 传递给 FuncNode 的固定参数。

    Returns:
        FuncNode 实例，或返回装饰器的 callable（未提供 fn 时）。
    """

    def decorator(f: Callable[..., Any]) -> FuncNode:
        return FuncNode(fn=f, id=id, name=name, **kwargs)

    if fn is not None:
        return decorator(fn)
    return decorator
