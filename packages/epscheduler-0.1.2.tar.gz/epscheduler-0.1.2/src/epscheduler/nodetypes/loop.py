from __future__ import annotations

import inspect
from typing import Any, Callable

from epscheduler.nodetypes.base import BaseNode


class LoopNode(BaseNode):
    """循环节点，对列表中每个元素重复执行子任务。

    从 context 中取出可迭代对象，对每个元素调用 fn 函数。
    执行完毕后返回 {"_results": [所有元素的处理结果]}。

    Attributes:
        items_key: context 中包含可迭代对象的键名。
        fn: 对每个元素调用的处理函数。
        item_key: 当前元素注入 context 时使用的键名。
    """

    def __init__(
        self,
        items_key: str,
        fn: Callable[..., Any],
        id: str = "",
        name: str = "",
        item_key: str = "item",
    ) -> None:
        """初始化循环节点。

        Args:
            items_key: context 中包含可迭代对象的键名，如 "items"、"numbers"。
            fn: 对每个元素调用的函数，签名为 fn(item, **kwargs)。
            id: 节点唯一标识。
            name: 节点名称。
            item_key: 当前元素注入 context 时使用的键名，默认 "item"。
        """
        super().__init__(id, name)
        self.items_key = items_key
        self.fn = fn
        self.item_key = item_key

    async def execute(self, context: dict[str, Any]) -> dict[str, Any]:
        """执行循环处理。

        对 context[items_key] 中的每个元素调用 fn，收集结果。

        Args:
            context: DAG 共享上下文，包含待处理的列表。

        Returns:
            {"_results": [每个元素的处理结果]}。
        """
        items = context.get(self.items_key, [])
        results: list[Any] = []
        for item in items:
            ctx = {**context, self.item_key: item}
            r = self.fn(**ctx)
            if inspect.isawaitable(r):
                r = await r
            results.append(r)
        return {"_results": results}


def loop_node(
    fn: Callable[..., Any] | None = None,
    *,
    items_key: str = "items",
    id: str = "",
    name: str = "",
    item_key: str = "item",
) -> LoopNode | Callable[[Callable[..., Any]], LoopNode]:
    """装饰器：将函数包装为 LoopNode。

    支持两种用法：
        @loop_node
        def process(item): ...

        @loop_node(items_key="numbers", item_key="n")
        def process(n): ...

    Args:
        fn: 要包装的函数，直接调用时提供。
        items_key: context 中可迭代对象的键名。
        id: 节点唯一标识。
        name: 节点名称。
        item_key: 当前元素注入 context 的键名。

    Returns:
        LoopNode 实例，或返回装饰器的 callable（未提供 fn 时）。
    """

    def decorator(f: Callable[..., Any]) -> LoopNode:
        return LoopNode(items_key=items_key, fn=f, id=id, name=name, item_key=item_key)

    if fn is not None:
        return decorator(fn)
    return decorator
