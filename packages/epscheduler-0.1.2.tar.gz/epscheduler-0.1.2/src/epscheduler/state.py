"""状态枚举定义。

包含：
- NodeState: DAG 节点运行时状态
- JobStatus: 作业状态
"""

from enum import Enum


class NodeState(str, Enum):
    """DAG 节点的运行时状态。

    用于追踪节点在 DAG 执行过程中的生命周期。

    Attributes:
        PENDING: 待执行，节点尚未开始。
        RUNNING: 执行中（当前未使用，预留）。
        SUCCESS: 执行成功，节点正常完成。
        FAILED: 执行失败，节点抛出异常或被标记为失败。
        SKIPPED: 被跳过，条件分支未选中时自动标记。
    """

    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    SKIPPED = "skipped"


class JobStatus(str, Enum):
    """作业状态。

    用于追踪作业的调度生命周期。

    Attributes:
        PENDING: 初始状态，刚创建尚未执行。
        RUNNING: 运行中，正在执行任务。
        SUCCESS: 上次执行成功，等待下次触发。
        FAILED: 上次执行失败，等待下次触发。
        PAUSED: 已暂停，不会自动触发。
        COMPLETED: 已完成，达到最大运行次数或一次性任务完成。
    """

    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    PAUSED = "paused"
    COMPLETED = "completed"
