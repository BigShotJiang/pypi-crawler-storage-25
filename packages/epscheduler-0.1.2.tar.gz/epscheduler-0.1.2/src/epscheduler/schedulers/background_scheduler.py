"""后台调度器（Background Thread 模式）。"""

import asyncio
import logging
import threading
from typing import Any, Callable, Union

from epscheduler.dag import DAG
from epscheduler.executors import Executor
from epscheduler.job import Job, create_callable_job, create_dag_job
from epscheduler.jobstores import JobStore
from epscheduler.schedulers.async_scheduler import AsyncScheduler
from epscheduler.triggers import Trigger

logger = logging.getLogger(__name__)


class BackgroundScheduler(AsyncScheduler):
    """后台调度器。

    在独立后台线程中运行调度循环，不阻塞主线程。

    注意：此类继承 AsyncScheduler，但启动/停止方法签名不同：
    - start_background() 是同步方法，启动后台线程，不阻塞
    - stop_background() 是同步方法，停止后台线程
    - start() 是 async 方法（兼容基类），内部调用 start_background()

    其他异步方法通过 _run_async 包装为同步调用，可在任何线程使用。

    Example:
        >>> scheduler = BackgroundScheduler(store, executor)
        >>> scheduler.add_job("job_1", "测试", trigger, fn=my_func)
        >>> scheduler.start_background()  # 启动后台线程
        >>> scheduler.stop_background()   # 停止
    """

    def __init__(
        self,
        jobstore: JobStore,
        executor: Executor,
        poll_interval: float = 1.0,
    ) -> None:
        """初始化后台调度器。"""
        super().__init__(jobstore, executor, poll_interval)
        self._thread: threading.Thread | None = None
        self._event_loop: asyncio.AbstractEventLoop | None = None
        self._stop_event = threading.Event()
        self._loop_lock = threading.Lock()  # 保护事件循环访问
        self._loop_ready = threading.Event()  # 标记事件循环已就绪

    def add_job(
        self,
        job_or_id: Union[Job, str],
        name: str | None = None,
        trigger: Trigger | None = None,
        *,
        fn: Callable[..., Any] | None = None,
        dag: DAG | None = None,
        params: dict[str, Any] | None = None,
        max_runs: int | None = None,
    ) -> str:
        """添加作业（可在任何线程调用，自动判断类型）。

        Args:
            job_or_id: Job 实例 或 作业唯一标识。
            name: 作业名称（创建模式时需要）。
            trigger: 触发器实例（创建模式时需要）。
            fn: 可执行函数（创建 Callable 作业）。
            dag: DAG 实例（创建 DAG 作业）。
            params: 任务执行参数。
            max_runs: 最大运行次数。

        Returns:
            作业 ID。
        """
        if isinstance(job_or_id, Job):
            return self._run_async(super().add_job(job_or_id))

        job_id = job_or_id
        if name is None or trigger is None:
            raise ValueError("创建作业时必须提供 name 和 trigger")

        if fn is not None and dag is not None:
            raise ValueError("fn 和 dag 不能同时提供")

        if fn is not None:
            job = create_callable_job(job_id, name, trigger, fn, params, max_runs)
        elif dag is not None:
            job = create_dag_job(job_id, name, trigger, dag, params, max_runs)
        else:
            raise ValueError("必须提供 fn 或 dag 参数")

        return self.add_job(job)

    def remove_job(self, job_id: str) -> bool:
        """移除作业（可在任何线程调用）。"""
        return self._run_async(super().remove_job(job_id))

    def get_job(self, job_id: str) -> Job | None:
        """获取作业（可在任何线程调用）。"""
        return self._run_async(super().get_job(job_id))

    def list_jobs(self) -> list[Job]:
        """列出作业（可在任何线程调用）。"""
        return self._run_async(super().list_jobs())

    async def start(self) -> None:
        """启动调度器（异步接口，兼容 BaseScheduler）。"""
        self._start_background()

    def start_background(self) -> None:
        """启动后台线程（同步接口，不阻塞）。"""
        self._start_background()

    def _start_background(self) -> None:
        """实际启动逻辑。"""
        if self._running:
            logger.warning("调度器已在运行")
            return

        self._running = True
        self._paused = False
        self._stop_event.clear()
        self._loop_ready.clear()

        # 启动后台线程
        self._thread = threading.Thread(
            target=self._run_in_thread,
            name="BackgroundScheduler",
            daemon=False,
        )
        self._thread.start()

        # 等待事件循环就绪（最多等待 5 秒）
        if self._loop_ready.wait(timeout=5.0):
            logger.info("BackgroundScheduler 已在后台线程启动")
        else:
            logger.warning("BackgroundScheduler 启动超时")
            self._running = False

    async def stop(self, timeout: float | None = None) -> None:
        """停止调度器。"""
        self._stop_background(timeout)

    def stop_background(self, timeout: float | None = None) -> None:
        """停止后台线程（同步接口）。"""
        self._stop_background(timeout)

    def _stop_background(self, timeout: float | None = None) -> None:
        """实际停止逻辑。"""
        if not self._running:
            logger.warning("调度器未运行")
            return

        self._running = False
        self._stop_event.set()

        # 等待线程结束
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=timeout or 5.0)
            if self._thread.is_alive():
                logger.warning("后台线程未能在超时时间内停止")
            self._thread = None

        logger.info("BackgroundScheduler 已停止")

    def pause(self) -> None:
        """暂停调度。"""
        if not self._running:
            logger.warning("调度器未运行，无法暂停")
            return
        self._paused = True
        logger.info("后台调度已暂停")

    def resume(self) -> None:
        """恢复调度。"""
        if not self._running:
            logger.warning("调度器未运行，无法恢复")
            return
        self._paused = False
        logger.info("后台调度已恢复")

    def is_running(self) -> bool:
        """检查是否运行中。"""
        return self._running and (self._thread is not None and self._thread.is_alive())

    def is_paused(self) -> bool:
        """检查是否暂停。"""
        return self._paused

    def run_job_now(self, job_id: str) -> Any:
        """立即执行作业（可在任何线程调用）。"""
        return self._run_async(super().run_job_now(job_id))

    # ── 后台线程逻辑 ───────────────────────────────────────────────────────────

    def _run_in_thread(self) -> None:
        """在后台线程中运行事件循环。"""
        with self._loop_lock:
            self._event_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._event_loop)
            self._loop_ready.set()  # 标记事件循环已就绪

        try:
            self._event_loop.run_until_complete(self._run_forever())

        except Exception as e:
            logger.error(f"后台线程出错: {e}")
        finally:
            with self._loop_lock:
                if self._event_loop:
                    self._event_loop.run_until_complete(self.executor.shutdown())
                    self._event_loop.close()
                    self._event_loop = None

    async def _run_forever(self) -> None:
        """永久运行调度循环。"""
        task = asyncio.create_task(self._run_loop())

        try:
            while self._running and not self._stop_event.is_set():
                await asyncio.sleep(0.1)
        finally:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    # ── 跨线程调用 ─────────────────────────────────────────────────────────────

    def _run_async(self, coro: Any) -> Any:
        """在后台线程的事件循环中运行协程。

        使用线程锁保护事件循环访问，避免竞态条件。
        等待事件循环就绪后再执行跨线程调用。
        """
        # 如果调度器正在启动，等待事件循环就绪
        if self._running and not self._loop_ready.is_set():
            self._loop_ready.wait(timeout=5.0)

        with self._loop_lock:
            if self._event_loop and self._event_loop.is_running():
                # 跨线程调用
                future = asyncio.run_coroutine_threadsafe(coro, self._event_loop)
                return future.result(timeout=30.0)
            elif self._running:
                # 调度器已启动但循环未运行（启动瞬间或关闭瞬间）
                loop = asyncio.new_event_loop()
                try:
                    return loop.run_until_complete(coro)
                finally:
                    loop.close()
            else:
                # 调度器未启动，创建临时循环
                loop = asyncio.new_event_loop()
                try:
                    return loop.run_until_complete(coro)
                finally:
                    loop.close()
