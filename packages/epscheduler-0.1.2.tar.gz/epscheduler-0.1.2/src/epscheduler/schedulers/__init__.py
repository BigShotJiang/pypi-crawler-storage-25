"""调度器模块。

提供多种调度器实现：
- BaseScheduler: 抽象基类
- AsyncScheduler: 异步调度器（需要 asyncio）
- BlockingScheduler: 阻塞调度器（占用主线程）
- BackgroundScheduler: 后台调度器（独立线程）

选择指南：
- 已有 asyncio 应用 → AsyncScheduler
- 简单脚本/独立进程 → BlockingScheduler
- Web/GUI/长期服务 → BackgroundScheduler
"""

from .async_scheduler import AsyncScheduler
from .background_scheduler import BackgroundScheduler
from .base import BaseScheduler
from .blocking_scheduler import BlockingScheduler

# 别名，方便使用
Scheduler = AsyncScheduler

__all__ = [
    "BaseScheduler",
    "AsyncScheduler",
    "BlockingScheduler",
    "BackgroundScheduler",
    "Scheduler",  # 别名，默认 AsyncScheduler
]
