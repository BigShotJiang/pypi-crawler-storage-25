"""阻塞调度器（Blocking 模式）。"""

import asyncio
import logging
import threading
from typing import Any, Callable, Union

from epscheduler.dag import DAG
from epscheduler.executors import Executor
from epscheduler.job import Job, create_callable_job, create_dag_job
from epscheduler.jobstores import JobStore
from epscheduler.schedulers.async_scheduler import AsyncScheduler
from epscheduler.triggers import Trigger

logger = logging.getLogger(__name__)


class BlockingScheduler(AsyncScheduler):
    """阻塞调度器。

    占用主线程运行调度循环，适合独立进程场景。
    start() 方法是同步方法，会阻塞主线程，直到调用 stop()。

    注意：此类继承 AsyncScheduler，但 start()/stop() 方法签名不同：
    - start() 是同步方法，阻塞主线程
    - stop() 是同步方法，可从其他线程调用

    其他异步方法（如 add_job、remove_job 等）通过 _run_async 包装为同步调用。

    Example:
        >>> scheduler = BlockingScheduler(store, executor)
        >>> scheduler.add_job("job_1", "测试", trigger, fn=my_func)
        >>> scheduler.start()  # 阻塞主线程
    """

    def __init__(
        self,
        jobstore: JobStore,
        executor: Executor,
        poll_interval: float = 1.0,
    ) -> None:
        """初始化阻塞调度器。"""
        super().__init__(jobstore, executor, poll_interval)
        self._event_loop: asyncio.AbstractEventLoop | None = None
        self._stop_event = threading.Event()
        self._loop_lock = threading.Lock()  # 保护事件循环访问

    def add_job(
        self,
        job_or_id: Union[Job, str],
        name: str | None = None,
        trigger: Trigger | None = None,
        *,
        fn: Callable[..., Any] | None = None,
        dag: DAG | None = None,
        params: dict[str, Any] | None = None,
        max_runs: int | None = None,
    ) -> str:
        """添加作业（阻塞调用，自动判断类型）。

        Args:
            job_or_id: Job 实例 或 作业唯一标识。
            name: 作业名称（创建模式时需要）。
            trigger: 触发器实例（创建模式时需要）。
            fn: 可执行函数（创建 Callable 作业）。
            dag: DAG 实例（创建 DAG 作业）。
            params: 任务执行参数。
            max_runs: 最大运行次数。

        Returns:
            作业 ID。
        """
        if isinstance(job_or_id, Job):
            return self._run_async(self._add_job_async(job_or_id))

        job_id = job_or_id
        if name is None or trigger is None:
            raise ValueError("创建作业时必须提供 name 和 trigger")

        if fn is not None and dag is not None:
            raise ValueError("fn 和 dag 不能同时提供")

        if fn is not None:
            job = create_callable_job(job_id, name, trigger, fn, params, max_runs)
        elif dag is not None:
            job = create_dag_job(job_id, name, trigger, dag, params, max_runs)
        else:
            raise ValueError("必须提供 fn 或 dag 参数")

        return self.add_job(job)

    def remove_job(self, job_id: str) -> bool:
        """移除作业（阻塞调用）。"""
        return self._run_async(self._remove_job_async(job_id))

    def get_job(self, job_id: str) -> Job | None:
        """获取作业（阻塞调用）。"""
        return self._run_async(self._get_job_async(job_id))

    def list_jobs(self) -> list[Job]:
        """列出作业（阻塞调用）。"""
        return self._run_async(self._list_jobs_async())

    def start(self) -> None:
        """启动调度器（阻塞主线程）。"""
        if self._running:
            logger.warning("调度器已在运行")
            return

        self._running = True
        self._paused = False
        self._stop_event.clear()

        logger.info("BlockingScheduler 启动，阻塞主线程")

        try:
            self._event_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._event_loop)

            # 运行调度循环
            self._event_loop.run_until_complete(self._run_forever())

        except KeyboardInterrupt:
            logger.info("收到 KeyboardInterrupt，停止调度器")
        finally:
            self._event_loop.run_until_complete(self.executor.shutdown())
            self._event_loop.close()
            self._event_loop = None
            self._running = False
            logger.info("BlockingScheduler 已停止")

    def stop(self, timeout: float | None = None) -> None:
        """停止调度器（可从其他线程调用）。"""
        if not self._running:
            logger.warning("调度器未运行")
            return

        self._stop_event.set()

        # 如果在事件循环线程，直接停止
        if self._event_loop and self._event_loop.is_running():
            self._event_loop.call_soon_threadsafe(self._do_stop)

    def _do_stop(self) -> None:
        """实际停止逻辑（在事件循环中执行）。"""
        self._running = False

    async def _run_forever(self) -> None:
        """永久运行调度循环。"""
        task = asyncio.create_task(self._run_loop())

        try:
            while self._running and not self._stop_event.is_set():
                await asyncio.sleep(0.1)
        finally:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass

    def run_job_now(self, job_id: str) -> Any:
        """立即执行作业（阻塞调用）。"""
        return self._run_async(self._run_job_now_async(job_id))

    # ── 异步包装器 ─────────────────────────────────────────────────────────────

    async def _add_job_async(self, job: Job) -> str:
        """异步添加作业。"""
        return await super().add_job(job)

    async def _remove_job_async(self, job_id: str) -> bool:
        """异步移除作业。"""
        return await super().remove_job(job_id)

    async def _get_job_async(self, job_id: str) -> Job | None:
        """异步获取作业。"""
        return await super().get_job(job_id)

    async def _list_jobs_async(self) -> list[Job]:
        """异步列出作业。"""
        return await super().list_jobs()

    async def _run_job_now_async(self, job_id: str) -> Any:
        """异步立即执行。"""
        return await super().run_job_now(job_id)

    def _run_async(self, coro: Any) -> Any:
        """在事件循环中运行协程（阻塞）。

        使用线程锁保护事件循环访问，避免竞态条件。
        """
        with self._loop_lock:
            if self._event_loop and self._event_loop.is_running():
                # 如果循环正在运行，使用 run_coroutine_threadsafe
                future = asyncio.run_coroutine_threadsafe(coro, self._event_loop)
                return future.result()
            elif self._running:
                # 调度器正在启动但循环未完全运行
                # 创建临时循环执行
                loop = asyncio.new_event_loop()
                try:
                    return loop.run_until_complete(coro)
                finally:
                    loop.close()
            else:
                # 调度器未启动，创建临时循环
                loop = asyncio.new_event_loop()
                try:
                    return loop.run_until_complete(coro)
                finally:
                    loop.close()
