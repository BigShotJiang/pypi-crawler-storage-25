"""调度器抽象基类。"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Union

from epscheduler.dag import DAG
from epscheduler.executors import Executor
from epscheduler.job import Job
from epscheduler.jobstores import JobStore
from epscheduler.triggers import Trigger


class BaseScheduler(ABC):
    """调度器抽象基类。

    定义调度器的核心接口。不同实现提供不同的运行模式：
    - AsyncScheduler: 异步调度，需要配合 asyncio 使用
    - BlockingScheduler: 阻塞调度，同步方法，占用主线程
    - BackgroundScheduler: 后台线程调度，同步方法，不阻塞主线程

    注意：基类方法不强制 async 签名，子类根据运行模式决定：
    - AsyncScheduler: 提供 async 版本方法
    - BlockingScheduler/BackgroundScheduler: 提供同步版本方法

    Attributes:
        jobstore: 作业存储。
        executor: 执行器。
        poll_interval: 轮询间隔（秒）。
    """

    def __init__(
        self,
        jobstore: JobStore,
        executor: Executor,
        poll_interval: float = 1.0,
    ) -> None:
        """初始化调度器。"""
        self.jobstore = jobstore
        self.executor = executor
        self.poll_interval = poll_interval

        self._running = False
        self._paused = False

    # ── 作业管理接口 ─────────────────────────────────────────────────────────

    @abstractmethod
    def add_job(
        self,
        job_or_id: Union[Job, str],
        name: str | None = None,
        trigger: Trigger | None = None,
        *,
        fn: Callable[..., Any] | None = None,
        dag: DAG | None = None,
        params: dict[str, Any] | None = None,
        max_runs: int | None = None,
    ) -> str:
        """添加作业到调度器。

        支持两种方式：
        1. 传入 Job 实例：add_job(job)
        2. 传入参数创建：add_job(job_id, name, trigger, fn=... 或 dag=...)

        Args:
            job_or_id: Job 实例 或 作业唯一标识。
            name: 作业名称（创建模式时需要）。
            trigger: 触发器实例（创建模式时需要）。
            fn: 可执行函数（创建 Callable 作业）。
            dag: DAG 实例（创建 DAG 作业）。
            params: 任务执行参数。
            max_runs: 最大运行次数。

        Returns:
            作业 ID。
        """
        ...

    @abstractmethod
    def remove_job(self, job_id: str) -> bool:
        """移除作业。

        Args:
            job_id: 作业 ID。

        Returns:
            移除成功返回 True，不存在返回 False。
        """
        ...

    @abstractmethod
    def get_job(self, job_id: str) -> Job | None:
        """获取作业。

        Args:
            job_id: 作业 ID。

        Returns:
            Job 实例，不存在则返回 None。
        """
        ...

    @abstractmethod
    def list_jobs(self) -> list[Job]:
        """列出所有作业。

        Returns:
            所有 Job 实例列表。
        """
        ...

    # ── 执行控制接口 ─────────────────────────────────────────────────────────

    @abstractmethod
    def start(self) -> None:
        """启动调度器。

        - AsyncScheduler: async 方法，需配合 asyncio.run() 或 await
        - BlockingScheduler: 同步方法，阻塞主线程
        - BackgroundScheduler: 同步方法，启动后台线程不阻塞
        """
        ...

    @abstractmethod
    def stop(self, timeout: float | None = None) -> None:
        """停止调度器。

        Args:
            timeout: 最大等待时间（秒），None 表示无限等待。
        """
        ...

    @abstractmethod
    def pause(self) -> None:
        """暂停调度。"""
        ...

    @abstractmethod
    def resume(self) -> None:
        """恢复调度。"""
        ...

    @abstractmethod
    def is_running(self) -> bool:
        """检查调度器是否运行中。"""
        ...

    @abstractmethod
    def is_paused(self) -> bool:
        """检查调度器是否暂停。"""
        ...

    @abstractmethod
    def run_job_now(self, job_id: str) -> Any:
        """立即执行指定作业（无视触发时间）。

        Args:
            job_id: 作业 ID。

        Returns:
            执行结果。
        """
        ...
