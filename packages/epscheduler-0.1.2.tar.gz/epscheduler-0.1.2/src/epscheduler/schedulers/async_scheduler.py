"""异步调度器（AsyncIO 模式）。"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Callable, Union

from epscheduler.dag import DAG
from epscheduler.executors import Executor
from epscheduler.job import Job, create_callable_job, create_dag_job
from epscheduler.jobstores import JobStore
from epscheduler.schedulers.base import BaseScheduler
from epscheduler.triggers import Trigger

logger = logging.getLogger(__name__)

DEFAULT_POLL_INTERVAL = 1.0


class AsyncScheduler(BaseScheduler):
    """异步调度器。

    使用 asyncio 事件循环运行调度。
    需要在 async 函数中调用 start()，或使用 asyncio.run()。

    适用场景：
    - 已有 asyncio 应用
    - 需要与其他异步代码协同
    - I/O 密集型任务

    Example:
        >>> scheduler = AsyncScheduler(store, executor)
        >>> await scheduler.add_job("job_1", "测试", trigger, fn=my_func)
        >>> await scheduler.add_job(job)  # 或传入 Job 实例
        >>> await scheduler.start()
    """

    def __init__(
        self,
        jobstore: JobStore,
        executor: Executor,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
    ) -> None:
        """初始化异步调度器。"""
        super().__init__(jobstore, executor, poll_interval)
        self._scheduler_task: asyncio.Task | None = None

    async def add_job(
        self,
        job_or_id: Union[Job, str],
        name: str | None = None,
        trigger: Trigger | None = None,
        *,
        fn: Callable[..., Any] | None = None,
        dag: DAG | None = None,
        params: dict[str, Any] | None = None,
        max_runs: int | None = None,
    ) -> str:
        """添加作业到调度器。

        支持两种方式：
        1. 传入 Job 实例：add_job(job)
        2. 传入参数创建：add_job(job_id, name, trigger, fn=... 或 dag=...)

        Args:
            job_or_id: Job 实例 或 作业唯一标识。
            name: 作业名称（创建模式时需要）。
            trigger: 触发器实例（创建模式时需要）。
            fn: 可执行函数（创建 Callable 作业）。
            dag: DAG 实例（创建 DAG 作业）。
            params: 任务执行参数。
            max_runs: 最大运行次数。

        Returns:
            作业 ID。

        Raises:
            ValueError: 参数不完整或 fn/dag 都未提供。

        Example:
            >>> await scheduler.add_job("job_1", "测试", trigger, fn=my_func)
            >>> await scheduler.add_job(job)  # 传入 Job 实例
        """
        # 传入 Job 实例时直接添加
        if isinstance(job_or_id, Job):
            job = job_or_id
            job_id = await self.jobstore.add(job)
            logger.info(f"添加作业: {job_id} ({job.name})")
            return job_id

        # 传入参数时创建 Job
        job_id = job_or_id
        if name is None or trigger is None:
            raise ValueError("创建作业时必须提供 name 和 trigger")

        if fn is not None and dag is not None:
            raise ValueError("fn 和 dag 不能同时提供")

        if fn is not None:
            job = create_callable_job(job_id, name, trigger, fn, params, max_runs)
        elif dag is not None:
            job = create_dag_job(job_id, name, trigger, dag, params, max_runs)
        else:
            raise ValueError("必须提供 fn 或 dag 参数")

        return await self.add_job(job)

    async def remove_job(self, job_id: str) -> bool:
        """移除作业。"""
        result = await self.jobstore.remove(job_id)
        if result:
            logger.info(f"移除作业: {job_id}")
        return result

    async def get_job(self, job_id: str) -> Job | None:
        """获取作业。"""
        return await self.jobstore.get(job_id)

    async def list_jobs(self) -> list[Job]:
        """列出所有作业。"""
        jobs = await self.jobstore.list_all()
        return list(jobs)

    async def start(self) -> None:
        """启动调度器。"""
        if self._running:
            logger.warning("调度器已在运行")
            return

        self._running = True
        self._paused = False

        self._scheduler_task = asyncio.create_task(self._run_loop())
        logger.info("AsyncScheduler 已启动")

    async def stop(self, timeout: float | None = None) -> None:
        """停止调度器。"""
        if not self._running:
            logger.warning("调度器未运行")
            return

        self._running = False

        if self._scheduler_task:
            self._scheduler_task.cancel()
            try:
                await self._scheduler_task
            except asyncio.CancelledError:
                pass
            self._scheduler_task = None

        await self.executor.shutdown(timeout)
        logger.info("AsyncScheduler 已停止")

    def pause(self) -> None:
        """暂停调度。"""
        if not self._running:
            logger.warning("调度器未运行，无法暂停")
            return
        self._paused = True
        logger.info("调度器已暂停")

    def resume(self) -> None:
        """恢复调度。"""
        if not self._running:
            logger.warning("调度器未运行，无法恢复")
            return
        self._paused = False
        logger.info("调度器已恢复")

    def is_running(self) -> bool:
        """检查是否运行中。"""
        return self._running

    def is_paused(self) -> bool:
        """检查是否暂停。"""
        return self._paused

    async def run_job_now(self, job_id: str) -> Any:
        """立即执行作业。"""
        job = await self.jobstore.get(job_id)
        if job is None:
            raise ValueError(f"作业不存在: {job_id}")

        if not job.can_run():
            raise ValueError(f"作业无法执行: {job_id}")

        await self._execute_job(job)
        return job.last_run_result

    # ── 内部方法 ─────────────────────────────────────────────────────────────

    async def _run_loop(self) -> None:
        """主调度循环。"""
        while self._running:
            try:
                if not self._paused:
                    await self._process_due_jobs()

                await asyncio.sleep(self.poll_interval)

            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"调度循环出错: {e}")
                await asyncio.sleep(self.poll_interval)

    async def _process_due_jobs(self) -> None:
        """处理到期作业。"""
        now = datetime.now(timezone.utc)
        due_jobs = await self.jobstore.get_due_jobs(now)

        if due_jobs:
            logger.debug(f"发现 {len(due_jobs)} 个到期作业")

        for job in due_jobs:
            try:
                await self._execute_job(job)
            except Exception as e:
                logger.error(f"执行作业 {job.job_id} 失败: {e}")
                job.mark_failed(e)
                await self.jobstore.update(job)

    async def _execute_job(self, job: Job) -> None:
        """执行单个作业。"""
        if not job.can_run():
            logger.warning(f"作业 {job.job_id} 无法执行")
            return

        job.mark_running()
        await self.jobstore.update(job)

        logger.info(f"开始执行作业: {job.job_id}")

        try:
            if job.is_callable_job():
                result = await self._execute_callable_job(job)
            elif job.is_dag_job():
                result = await self._execute_dag_job(job)
            else:
                raise ValueError(f"未知的作业类型: {job.job_type}")

            job.mark_completed(result)
            logger.info(f"作业 {job.job_id} 执行成功")

        except Exception as e:
            job.mark_failed(e)
            logger.error(f"作业 {job.job_id} 执行失败: {e}")

        await self.jobstore.update(job)

    async def _execute_callable_job(self, job: Job) -> Any:
        """执行 Callable 作业。"""
        if job.callable is None:
            raise ValueError(f"作业 {job.job_id} 没有设置 callable")

        return await self.executor.submit(job.callable, **job.params)

    async def _execute_dag_job(self, job: Job) -> Any:
        """执行 DAG 作业。

        直接调用 DAG.run()，支持并行执行和完整的生命周期钩子。
        """
        if job.dag is None:
            raise ValueError(f"作业 {job.job_id} 没有设置 DAG")

        dag: DAG = job.dag
        dag.reset()

        if job.params:
            dag.params = job.params.copy()

        return await dag.run()
