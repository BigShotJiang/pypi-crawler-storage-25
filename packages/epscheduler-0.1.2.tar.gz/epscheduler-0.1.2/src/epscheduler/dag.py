from __future__ import annotations

import logging
from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Any, Callable

from epscheduler.exceptions import DAGCycleError, DAGError
from epscheduler.nodetypes.base import BaseNode
from epscheduler.state import NodeState

logger = logging.getLogger(__name__)


@dataclass
class DAGHooks:
    """DAG 生命周期钩子，所有回调均可选。

    用于在节点执行前后插入自定义逻辑，如日志记录、通知等。
    钩子异常不影响 DAG 正常运行。

    Attributes:
        on_node_start: 节点开始执行前的回调，接收 BaseNode 参数。
        on_node_complete: 节点执行完成后的回调，接收 BaseNode 参数。
        on_dag_complete: DAG 全部执行完成后的回调，无参数。
    """

    on_node_start: Callable[[BaseNode], None] | None = None
    on_node_complete: Callable[[BaseNode], None] | None = None
    on_dag_complete: Callable[[], None] | None = None


class DAG:
    """有向无环图，管理拓扑结构 + 节点运行时状态。

    DAG 是具体类，不提供抽象基类。扩展性通过 DAGHooks 回调实现。
    max_parallelism 是配置项，并行控制留给调度器处理。

    Attributes:
        params: DAG 初始参数，会作为初始上下文传递给节点。
        max_parallelism: 最大并行度，-1 表示无限制。
        hooks: 生命周期钩子配置。
    """

    def __init__(
        self,
        params: dict[str, Any] | None = None,
        max_parallelism: int = -1,
        hooks: DAGHooks | None = None,
    ) -> None:
        """初始化 DAG。

        Args:
            params: 初始上下文参数，所有节点执行时可访问。
            max_parallelism: 最大并行执行节点数，-1 表示无限制。
            hooks: 生命周期钩子，用于插入自定义回调逻辑。
        """
        self.params: dict[str, Any] = params or {}
        self.max_parallelism = max_parallelism
        self.hooks = hooks or DAGHooks()

        self._nodes: dict[str, BaseNode] = {}
        # from_id → {to_id: condition}
        self._edges: dict[str, dict[str, str | None]] = defaultdict(dict)
        # to_id → {from_id}
        self._reverse_edges: dict[str, set[str]] = defaultdict(set)

    # ── 拓扑管理 ──────────────────────────────────────────────

    def add_node(self, node: BaseNode) -> None:
        """添加节点到 DAG。

        Args:
            node: 要添加的节点实例。

        Raises:
            DAGError: 节点 ID 已存在。
        """
        if node.id in self._nodes:
            raise DAGError(f"节点 {node.id} 已存在")
        self._nodes[node.id] = node

    def add_edge(self, from_id: str, to_id: str, condition: str | None = None) -> None:
        """添加一条有向边，建立节点间的依赖关系。

        Args:
            from_id: 上游节点 ID。
            to_id: 下游节点 ID。
            condition: 条件标识，用于 ConditionNode 分支路由。非条件边传 None。

        Raises:
            DAGError: 节点不存在。
            DAGCycleError: 添加边会形成环路。
        """
        if from_id not in self._nodes:
            raise DAGError(f"节点 {from_id} 不存在")
        if to_id not in self._nodes:
            raise DAGError(f"节点 {to_id} 不存在")

        if to_id not in self._edges[from_id]:
            self._edges[from_id][to_id] = condition
            self._reverse_edges[to_id].add(from_id)
            try:
                self._check_cycle()
            except DAGCycleError:
                del self._edges[from_id][to_id]
                self._reverse_edges[to_id].discard(from_id)
                raise

    def remove_node(self, node_id: str) -> None:
        """删除节点及其关联的所有边。

        Args:
            node_id: 要删除的节点 ID。

        Raises:
            DAGError: 节点不存在。
        """
        if node_id not in self._nodes:
            raise DAGError(f"节点 {node_id} 不存在")
        del self._nodes[node_id]

        for to_id in list(self._edges.pop(node_id, {})):
            self._reverse_edges[to_id].discard(node_id)

        for from_id in list(self._reverse_edges.pop(node_id, set())):
            self._edges[from_id].pop(node_id, None)

    def upstream_ids(self, node_id: str) -> set[str]:
        """获取节点的所有直接上游节点 ID。

        Args:
            node_id: 目标节点 ID。

        Returns:
            上游节点 ID 集合。
        """
        return set(self._reverse_edges.get(node_id, set()))

    def downstream_ids(self, node_id: str) -> set[str]:
        """获取节点的所有直接下游节点 ID。

        Args:
            node_id: 目标节点 ID。

        Returns:
            下游节点 ID 集合。
        """
        return set(self._edges.get(node_id, {}).keys())

    def edge_condition(self, from_id: str, to_id: str) -> str | None:
        """获取边的条件标识。

        Args:
            from_id: 上游节点 ID。
            to_id: 下游节点 ID。

        Returns:
            条件标识字符串，非条件边返回 None。
        """
        return self._edges.get(from_id, {}).get(to_id)

    def topological_sort(self) -> list[str]:
        """按依赖顺序排列节点 ID（拓扑排序）。

        使用 Kahn 算法，确保上游节点始终排在下游节点之前。

        Returns:
            按执行顺序排列的节点 ID 列表。
        """
        in_degree = self._build_in_degree()
        queue: deque[str] = deque(id for id, deg in in_degree.items() if deg == 0)
        result: list[str] = []

        while queue:
            node_id = queue.popleft()
            result.append(node_id)
            for downstream in self._edges.get(node_id, {}):
                in_degree[downstream] -= 1
                if in_degree[downstream] == 0:
                    queue.append(downstream)

        return result

    def validate(self) -> bool:
        """检查 DAG 是否合法。

        合法的 DAG 必须有至少一个节点，且无孤立节点。

        Returns:
            True 表示合法，False 表示不合法。
        """
        if len(self._nodes) == 0:
            return False
        sorted_ids = self.topological_sort()
        return len(sorted_ids) == len(self._nodes)

    # ── 运行时状态管理 ────────────────────────────────────────

    def get_ready_nodes(self) -> list[BaseNode]:
        """获取当前可执行的就绪节点列表。

        就绪节点是指：所有上游节点已完成（success/skipped），自身状态为 pending。

        Returns:
            就绪节点实例列表。
        """
        ready: list[BaseNode] = []
        for node in self._nodes.values():
            if node.state != NodeState.PENDING:
                continue
            upstreams = self.upstream_ids(node.id)
            if all(
                self._nodes[uid].state in (NodeState.SUCCESS, NodeState.SKIPPED)
                for uid in upstreams
            ):
                ready.append(node)
        return ready

    def mark_completed(
        self, node_id: str, result: dict[str, Any] | None = None
    ) -> None:
        """标记节点执行成功，并处理条件路由。

        Args:
            node_id: 节点 ID。
            result: 节点执行返回的结果字典，包含 _branch 时触发分支路由。
        """
        node = self._nodes[node_id]
        node.state = NodeState.SUCCESS

        # 条件路由：根据 _branch 跳过未选中的下游分支
        if result and "_branch" in result:
            branch = result["_branch"]
            for to_id in self.downstream_ids(node_id):
                cond = self.edge_condition(node_id, to_id)
                if cond is not None and cond != branch:
                    self._propagate_skip(to_id)

        self._invoke_hook(self.hooks.on_node_complete, node)
        if self.is_complete():
            self._invoke_hook(self.hooks.on_dag_complete)

    def mark_failed(self, node_id: str) -> None:
        """标记节点执行失败。

        Args:
            node_id: 节点 ID。
        """
        node = self._nodes[node_id]
        node.state = NodeState.FAILED
        self._invoke_hook(self.hooks.on_node_complete, node)

    def mark_skipped(self, node_id: str) -> None:
        """标记节点被跳过（条件分支未选中）。

        Args:
            node_id: 节点 ID。
        """
        node = self._nodes[node_id]
        node.state = NodeState.SKIPPED

    def is_complete(self) -> bool:
        """检查 DAG 是否执行完毕。

        所有节点到达终态（success/failed/skipped）时视为完成。

        Returns:
            True 表示完成，False 表示未完成。
        """
        return all(
            node.state in (NodeState.SUCCESS, NodeState.FAILED, NodeState.SKIPPED)
            for node in self._nodes.values()
        )

    def is_success(self) -> bool:
        """检查 DAG 是否成功完成（无失败节点）。

        Returns:
            True 表示成功完成，False 表示有节点失败。
        """
        return all(
            node.state in (NodeState.SUCCESS, NodeState.SKIPPED)
            for node in self._nodes.values()
        )

    def reset(self) -> None:
        """重置所有节点状态为 pending，准备重新执行。"""
        for node in self._nodes.values():
            node.state = NodeState.PENDING

    # ── 执行 ──────────────────────────────────────────────────

    async def run(self) -> dict[str, Any]:
        """异步执行整个 DAG。

        按拓扑顺序逐步执行节点，上游节点完成后才执行下游节点。
        同一层级的就绪节点并行执行（受 max_parallelism 限制）。
        任一节点失败则终止执行。

        Returns:
            最终上下文字典，包含所有节点执行结果的累积。
        """
        import asyncio

        ctx: dict[str, Any] = dict(self.params)
        self.reset()

        # 创建信号量控制并发
        semaphore: asyncio.Semaphore | None = None
        if self.max_parallelism > 0:
            semaphore = asyncio.Semaphore(self.max_parallelism)

        async def _run_node_with_semaphore(
            node: BaseNode,
        ) -> tuple[BaseNode, dict[str, Any] | Exception]:
            """在信号量控制下执行单个节点。"""
            if semaphore:
                async with semaphore:
                    result = await node.execute(ctx)
            else:
                result = await node.execute(ctx)
            return node, result

        while not self.is_complete():
            nodes = self.get_ready_nodes()
            if not nodes:
                break

            results = await asyncio.gather(
                *(_run_node_with_semaphore(n) for n in nodes),
                return_exceptions=True,
            )

            for item in results:
                if isinstance(item, Exception):
                    # gather 返回异常本身
                    # 需要找到对应的节点标记失败
                    for n in nodes:
                        if n.state == NodeState.PENDING:
                            self.mark_failed(n.id)
                    break
                else:
                    node, result = item
                    if isinstance(result, Exception):
                        self.mark_failed(node.id)
                        break
                    elif isinstance(result, dict):
                        self.mark_completed(node.id, result)
                        ctx.update(result)
                    else:
                        self.mark_completed(node.id)

            if any(n.state == NodeState.FAILED for n in self._nodes.values()):
                break

        return ctx

    def __call__(self) -> dict[str, Any]:
        """同步执行整个 DAG。

        用法: result = dag()

        Returns:
            最终上下文字典。
        """
        import asyncio

        return asyncio.run(self.run())

    # ── 内部方法 ──────────────────────────────────────────────

    def _propagate_skip(self, node_id: str) -> None:
        """递归将节点及其所有下游标记为 skipped。"""
        if self._nodes[node_id].state != NodeState.PENDING:
            return
        self._nodes[node_id].state = NodeState.SKIPPED
        for downstream in self.downstream_ids(node_id):
            self._propagate_skip(downstream)

    def _build_in_degree(self) -> dict[str, int]:
        """构建入度表。"""
        in_degree: dict[str, int] = {nid: 0 for nid in self._nodes}
        for from_id, targets in self._edges.items():
            for to_id in targets:
                in_degree[to_id] += 1
        return in_degree

    def _check_cycle(self) -> None:
        """Kahn 算法检测环路，存在环路时抛 DAGCycleError。"""
        in_degree = self._build_in_degree()
        queue: deque[str] = deque(id for id, deg in in_degree.items() if deg == 0)
        visited_count = 0

        while queue:
            node_id = queue.popleft()
            visited_count += 1
            for downstream in self._edges.get(node_id, {}):
                in_degree[downstream] -= 1
                if in_degree[downstream] == 0:
                    queue.append(downstream)

        if visited_count != len(self._nodes):
            raise DAGCycleError("检测到环路，无法添加该边")

    @staticmethod
    def _invoke_hook(
        hook: Callable[[BaseNode], None] | Callable[[], None] | None,
        node: BaseNode | None = None,
    ) -> None:
        """安全调用钩子，记录异常但不中断 DAG 运行。

        Args:
            hook: 钩子函数，接受 BaseNode 参数或无参数。
            node: 传递给钩子的节点参数，None 时调用无参数钩子。
        """
        if hook is None:
            return
        try:
            if node is not None:
                hook(node)  # type: ignore[call-arg]
            else:
                hook()  # type: ignore[call-arg]
        except Exception as e:
            # 钩子异常不影响 DAG 运行，但需要记录以便调试
            logger.warning(
                f"钩子执行失败: {type(e).__name__}: {e}",
                exc_info=True,
            )
