"""固定间隔触发器。"""

from datetime import datetime, timedelta, timezone

from epscheduler.exceptions import TriggerConfigError

from .base import Trigger


class IntervalTrigger(Trigger):
    """固定间隔触发器。

    按固定时间间隔重复触发，支持秒、分、时、天的组合。

    Example:
        >>> trigger = IntervalTrigger(seconds=30)  # 每 30 秒
        >>> trigger = IntervalTrigger(minutes=5)  # 每 5 分钟
        >>> trigger = IntervalTrigger(hours=1, minutes=30)  # 每 1.5 小时
    """

    def __init__(
        self,
        seconds: int = 0,
        minutes: int = 0,
        hours: int = 0,
        days: int = 0,
        weeks: int = 0,
        start_time: datetime | None = None,
    ) -> None:
        """初始化间隔触发器。

        Args:
            seconds: 间隔秒数。
            minutes: 间隔分钟数。
            hours: 间隔小时数。
            days: 间隔天数。
            weeks: 间隔周数。
            start_time: 首次触发时间，默认为当前时间。

        Raises:
            TriggerConfigError: 总间隔时间为 0 或负数时抛出。
        """
        self.seconds = seconds
        self.minutes = minutes
        self.hours = hours
        self.days = days
        self.weeks = weeks
        self.start_time = start_time

        # 计算总间隔
        self._interval = timedelta(
            weeks=weeks,
            days=days,
            hours=hours,
            minutes=minutes,
            seconds=seconds,
        )

        if self._interval.total_seconds() <= 0:
            raise TriggerConfigError("间隔时间必须大于 0")

    @property
    def interval(self) -> timedelta:
        """获取间隔时间。"""
        return self._interval

    def next_fire_time(self, last_fire_time: datetime | None) -> datetime | None:
        """计算下次触发时间。

        Args:
            last_fire_time: 上次触发时间，首次触发时为 None。

        Returns:
            下次触发时间（时区感知）。
        """
        if last_fire_time is None:
            # 首次触发：直接返回 start_time 或当前时间
            if self.start_time is not None:
                base_time = self.start_time
            else:
                base_time = datetime.now(timezone.utc)

            # 确保 base_time 是时区感知的
            if base_time.tzinfo is None:
                base_time = base_time.replace(tzinfo=timezone.utc)

            return base_time

        # 后续触发：在上次触发时间基础上加间隔
        base_time = last_fire_time

        # 确保 base_time 是时区感知的
        if base_time.tzinfo is None:
            base_time = base_time.replace(tzinfo=timezone.utc)

        next_time = base_time + self._interval

        # 确保返回时区感知的时间
        if next_time.tzinfo is None:
            next_time = next_time.replace(tzinfo=timezone.utc)

        return next_time

    def model_dump(self) -> dict:
        """序列化触发器配置。

        Returns:
            包含间隔配置的字典。
        """
        return {
            "type": "interval",
            "seconds": self.seconds,
            "minutes": self.minutes,
            "hours": self.hours,
            "days": self.days,
            "weeks": self.weeks,
            "start_time": self.start_time.isoformat() if self.start_time else None,
        }

    @classmethod
    def model_validate(cls, data: dict) -> "IntervalTrigger":
        """从配置字典反序列化。

        Args:
            data: 包含间隔参数的字典。

        Returns:
            IntervalTrigger 实例。

        Raises:
            TriggerConfigError: 间隔时间无效时抛出。
        """
        # 解析 start_time
        start_time = None
        start_time_str = data.get("start_time")
        if start_time_str:
            try:
                start_time = datetime.fromisoformat(start_time_str)
            except ValueError as e:
                raise TriggerConfigError(f"无效的 start_time 格式: {start_time_str}") from e

        return cls(
            seconds=data.get("seconds", 0),
            minutes=data.get("minutes", 0),
            hours=data.get("hours", 0),
            days=data.get("days", 0),
            weeks=data.get("weeks", 0),
            start_time=start_time,
        )
