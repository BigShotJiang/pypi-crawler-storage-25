"""一次性日期触发器。"""

from datetime import datetime, timezone

from epscheduler.exceptions import TriggerConfigError

from .base import Trigger


class DateTrigger(Trigger):
    """一次性触发器。

    在指定的具体时间点触发一次，触发后不再触发。

    Example:
        >>> from datetime import datetime, timedelta
        >>> trigger_time = datetime.now(timezone.utc) + timedelta(hours=1)
        >>> trigger = DateTrigger(trigger_time)  # 1 小时后触发一次
    """

    def __init__(self, run_date: datetime) -> None:
        """初始化一次性触发器。

        Args:
            run_date: 触发时间点。

        Raises:
            TriggerConfigError: run_date 为 None 时抛出。
        """
        if run_date is None:
            raise TriggerConfigError("run_date 不能为 None")

        # 确保是时区感知的时间
        if run_date.tzinfo is None:
            run_date = run_date.replace(tzinfo=timezone.utc)

        self.run_date = run_date

        # 内部标记是否已触发
        self._has_fired = False

    def next_fire_time(self, last_fire_time: datetime | None) -> datetime | None:
        """计算下次触发时间。

        Args:
            last_fire_time: 上次触发时间，首次触发时为 None。

        Returns:
            如果未触发且时间未过，返回 run_date；否则返回 None。
        """
        if self._has_fired:
            return None

        # 标记已触发
        self._has_fired = True

        # 如果 run_date 已经过去，返回 None
        now = datetime.now(timezone.utc)
        if self.run_date <= now:
            return None

        return self.run_date

    def model_dump(self) -> dict:
        """序列化触发器配置。

        Returns:
            包含触发时间的字典。
        """
        return {
            "type": "date",
            "run_date": self.run_date.isoformat(),
        }

    @classmethod
    def model_validate(cls, data: dict) -> "DateTrigger":
        """从配置字典反序列化。

        Args:
            data: 包含 run_date 的字典。

        Returns:
            DateTrigger 实例。

        Raises:
            TriggerConfigError: 缺少 run_date 或格式无效时抛出。
        """
        run_date_str = data.get("run_date")
        if not run_date_str:
            raise TriggerConfigError("缺少必要字段: run_date")

        try:
            run_date = datetime.fromisoformat(run_date_str)
        except ValueError as e:
            raise TriggerConfigError(f"无效的 run_date 格式: {run_date_str}") from e

        return cls(run_date)
