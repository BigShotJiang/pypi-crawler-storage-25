"""Cron 表达式触发器。"""

from datetime import datetime, timezone

from croniter import croniter

from epscheduler.exceptions import TriggerConfigError

from .base import Trigger


class CronTrigger(Trigger):
    """基于 cron 表达式的触发器。

    使用 croniter 解析标准 cron 表达式，计算下次触发时间。

    Example:
        >>> trigger = CronTrigger("0 9 * * 1-5")  # 每个工作日 9:00
        >>> next_time = trigger.next_fire_time(None)
    """

    def __init__(self, cron_expression: str, timezone_name: str | None = None) -> None:
        """初始化 Cron 触发器。

        Args:
            cron_expression: 标准 cron 表达式（5 或 6 字段）。
            timezone_name: 时区名称，如 "Asia/Shanghai"，默认 UTC。

        Raises:
            TriggerConfigError: cron 表达式无效时抛出。
        """
        self.cron_expression = cron_expression
        self.timezone_name = timezone_name

        # 验证 cron 表达式有效性
        try:
            croniter(cron_expression)
        except (ValueError, KeyError) as e:
            raise TriggerConfigError(f"无效的 cron 表达式: {cron_expression}") from e

    def next_fire_time(self, last_fire_time: datetime | None) -> datetime | None:
        """计算下次触发时间。

        Args:
            last_fire_time: 上次触发时间，首次触发时为 None。

        Returns:
            下次触发时间（时区感知）。
        """
        # 确定基准时间
        if last_fire_time is not None:
            base_time = last_fire_time
        else:
            base_time = datetime.now(timezone.utc)

        # 确保 base_time 是时区感知的
        if base_time.tzinfo is None:
            base_time = base_time.replace(tzinfo=timezone.utc)

        # 创建 croniter 实例并计算下次时间
        cron = croniter(self.cron_expression, base_time)
        next_time = cron.get_next(datetime)

        # 确保返回时区感知的时间
        if next_time.tzinfo is None:
            next_time = next_time.replace(tzinfo=timezone.utc)

        return next_time

    def model_dump(self) -> dict:
        """序列化触发器配置。

        Returns:
            包含 cron 表达式和时区配置的字典。
        """
        return {
            "type": "cron",
            "cron_expression": self.cron_expression,
            "timezone_name": self.timezone_name,
        }

    @classmethod
    def model_validate(cls, data: dict) -> "CronTrigger":
        """从配置字典反序列化。

        Args:
            data: 包含 cron_expression 和可选 timezone_name 的字典。

        Returns:
            CronTrigger 实例。

        Raises:
            TriggerConfigError: 缺少必要字段或表达式无效时抛出。
        """
        cron_expression = data.get("cron_expression")
        if not cron_expression:
            raise TriggerConfigError("缺少必要字段: cron_expression")

        timezone_name = data.get("timezone_name")
        return cls(cron_expression, timezone_name)
