"""手动触发器。"""

from datetime import datetime

from .base import Trigger


class ManualTrigger(Trigger):
    """手动触发器。

    不自动触发，仅支持手动触发。适用于需要人工干预的任务。

    Example:
        >>> trigger = ManualTrigger()
        >>> trigger.next_fire_time(None)  # 始终返回 None
        None
    """

    def next_fire_time(self, last_fire_time: datetime | None) -> datetime | None:
        """计算下次触发时间。

        Args:
            last_fire_time: 上次触发时间（忽略）。

        Returns:
            始终返回 None，表示不会自动触发。
        """
        return None

    def model_dump(self) -> dict:
        """序列化触发器配置。

        Returns:
            包含类型标识的字典。
        """
        return {"type": "manual"}

    @classmethod
    def model_validate(cls, data: dict) -> "ManualTrigger":
        """从配置字典反序列化。

        Args:
            data: 配置字典（忽略内容）。

        Returns:
            ManualTrigger 实例。
        """
        return cls()
