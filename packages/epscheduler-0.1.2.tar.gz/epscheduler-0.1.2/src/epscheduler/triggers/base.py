"""触发器抽象基类。"""

from abc import ABC, abstractmethod
from datetime import datetime


class Trigger(ABC):
    """触发器抽象基类。

    封装"何时触发"的逻辑，对外暴露计算下次触发时间的接口。
    """

    @abstractmethod
    def next_fire_time(self, last_fire_time: datetime | None) -> datetime | None:
        """计算下次触发时间。

        Args:
            last_fire_time: 上次触发时间，首次触发时为 None。

        Returns:
            下次触发时间，如果没有更多触发机会则返回 None。
        """
        ...

    @abstractmethod
    def model_dump(self) -> dict:
        """序列化触发器配置。

        Returns:
            包含触发器配置的字典，用于仓库持久化。
        """
        ...

    @classmethod
    @abstractmethod
    def model_validate(cls, data: dict) -> "Trigger":
        """从配置字典反序列化触发器。

        Args:
            data: 触发器配置字典。

        Returns:
            触发器实例。

        Raises:
            TriggerConfigError: 配置无效时抛出。
        """
        ...
