"""触发器模块。

提供多种触发器实现：
- Trigger: 抽象基类
- CronTrigger: 基于 cron 表达式
- IntervalTrigger: 固定间隔
- DateTrigger: 一次性触发
- ManualTrigger: 手动触发
"""

from typing import Literal

from epscheduler.exceptions import TriggerConfigError

from .base import Trigger
from .cron import CronTrigger
from .date import DateTrigger
from .interval import IntervalTrigger
from .manual import ManualTrigger

__all__ = [
    "Trigger",
    "CronTrigger",
    "IntervalTrigger",
    "DateTrigger",
    "ManualTrigger",
    "create_trigger",
    "TriggerType",
]

TriggerType = Literal["cron", "interval", "date", "manual"]


def create_trigger(data: dict) -> Trigger:
    """根据配置字典创建触发器实例。

    工厂方法，根据 type 字段自动选择对应的触发器类。

    Args:
        data: 触发器配置字典，必须包含 type 字段。

    Returns:
        对应类型的触发器实例。

    Raises:
        TriggerConfigError: type 字段缺失或无效时抛出。

    Example:
        >>> config = {"type": "cron", "cron_expression": "0 9 * * *"}
        >>> trigger = create_trigger(config)
        >>> isinstance(trigger, CronTrigger)
        True
    """
    trigger_type = data.get("type")
    if not trigger_type:
        raise TriggerConfigError("触发器配置缺少 type 字段")

    trigger_map: dict[str, type[Trigger]] = {
        "cron": CronTrigger,
        "interval": IntervalTrigger,
        "date": DateTrigger,
        "manual": ManualTrigger,
    }

    trigger_class = trigger_map.get(trigger_type)
    if not trigger_class:
        raise TriggerConfigError(f"未知的触发器类型: {trigger_type}")

    return trigger_class.model_validate(data)
