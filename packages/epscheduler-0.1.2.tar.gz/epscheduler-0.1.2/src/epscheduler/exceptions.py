class SchedulerError(Exception):
    """调度框架根异常类。

    所有框架内自定义异常都继承此类，便于统一捕获。
    """


class DAGError(SchedulerError):
    """DAG 相关异常。

    用于 DAG 拓扑操作错误，如节点不存在、节点重复等。
    """


class DAGCycleError(DAGError):
    """DAG 环路检测异常。

    添加边时检测到会形成环路，抛出此异常。
    """


class TriggerError(SchedulerError):
    """触发器相关异常。

    用于触发器配置错误或计算下次触发时间时的错误。
    """


class TriggerConfigError(TriggerError):
    """触发器配置异常。

    触发器参数配置无效时抛出。
    """


class JobError(SchedulerError):
    """作业相关异常。

    用于作业配置错误或执行时的错误。
    """


class JobConfigError(JobError):
    """作业配置异常。

    作业参数配置无效时抛出。
    """


class JobNotFoundError(JobError):
    """作业未找到异常。

    查询或操作不存在的作业时抛出。
    """


class JobExecutionError(JobError):
    """作业执行异常。

    作业执行过程中出错时抛出。
    """


class SecurityError(SchedulerError):
    """安全相关异常。

    用于安全验证失败，如命令注入检测、路径遍历检测等。
    """
