"""执行器抽象基类。"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Coroutine


class Executor(ABC):
    """执行器抽象基类。

    封装"如何执行"的逻辑，对外暴露提交接口。

    执行器负责：
    - 提交任务并返回结果
    - 控制并发度
    - 优雅关闭
    """

    @abstractmethod
    async def submit(
        self,
        fn: Callable[..., Any] | Coroutine[Any, Any, Any],
        *args,
        **kwargs,
    ) -> Any:
        """提交一个可调用对象并返回结果。

        支持同步函数和协程。

        Args:
            fn: 可调用对象或协程。
            *args: 位置参数。
            **kwargs: 关键字参数。

        Returns:
            执行结果。

        Raises:
            JobExecutionError: 执行过程中出错时抛出。
        """
        ...

    @abstractmethod
    async def shutdown(self, timeout: float | None = None) -> None:
        """优雅关闭执行器，等待运行中的任务完成。

        Args:
            timeout: 最大等待时间（秒），None 表示无限等待。
        """
        ...

    @abstractmethod
    def is_running(self) -> bool:
        """检查执行器是否正在运行。

        Returns:
            是否正在运行。
        """
        ...
