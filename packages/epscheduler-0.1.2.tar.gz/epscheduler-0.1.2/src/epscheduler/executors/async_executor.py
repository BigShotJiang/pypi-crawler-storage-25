"""异步执行器（协程池）。"""

import asyncio
import inspect
from typing import Any, Callable, Coroutine

from epscheduler.exceptions import JobExecutionError

from .base import Executor


class AsyncExecutor(Executor):
    """异步执行器。

    使用 asyncio 并发控制执行协程任务。
    适合 I/O 密集型任务。

    Attributes:
        max_concurrency: 最大并发数，None 表示无限制。
    """

    def __init__(self, max_concurrency: int | None = None) -> None:
        """初始化异步执行器。

        Args:
            max_concurrency: 最大并发数，None 表示无限制。
        """
        self.max_concurrency = max_concurrency
        self._running = True
        self._semaphore: asyncio.Semaphore | None = None
        self._tasks: set[asyncio.Task] = set()

    def _ensure_semaphore(self) -> None:
        """确保信号量已初始化（需要在运行的事件循环中）。"""
        if self.max_concurrency is not None and self._semaphore is None:
            self._semaphore = asyncio.Semaphore(self.max_concurrency)

    async def submit(
        self, fn: Callable[..., Any] | Coroutine[Any, Any, Any], *args, **kwargs
    ) -> Any:
        """提交一个可调用对象并返回结果。

        Args:
            fn: 可调用对象或协程。
            *args: 位置参数。
            **kwargs: 关键字参数。

        Returns:
            执行结果。

        Raises:
            JobExecutionError: 执行过程中出错时抛出。
        """
        self._ensure_semaphore()

        # 如果已经是协程，直接使用
        if asyncio.iscoroutine(fn):
            coro = fn
        # 如果是协程函数，调用它
        elif inspect.iscoroutinefunction(fn):
            coro = fn(*args, **kwargs)
        # 如果是同步函数，包装为协程
        else:
            coro = asyncio.to_thread(fn, *args, **kwargs)

        async def _run_with_semaphore() -> Any:
            """在信号量控制下执行任务。"""
            if self._semaphore:
                async with self._semaphore:
                    return await coro
            return await coro

        # 创建任务并追踪
        task = asyncio.create_task(_run_with_semaphore())
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

        try:
            return await task
        except Exception as e:
            raise JobExecutionError(f"任务执行失败: {e}") from e

    async def shutdown(self, timeout: float | None = None) -> None:
        """优雅关闭执行器，等待运行中的任务完成。

        Args:
            timeout: 最大等待时间（秒），None 表示无限等待。
        """
        self._running = False

        if self._tasks:
            # 等待所有任务完成
            if timeout is not None:
                try:
                    await asyncio.wait_for(
                        asyncio.gather(*self._tasks, return_exceptions=True),
                        timeout=timeout,
                    )
                except asyncio.TimeoutError:
                    # 超时后取消剩余任务
                    for task in self._tasks:
                        task.cancel()
                    await asyncio.gather(*self._tasks, return_exceptions=True)
            else:
                await asyncio.gather(*self._tasks, return_exceptions=True)

        self._tasks.clear()

    def is_running(self) -> bool:
        """检查执行器是否正在运行。

        Returns:
            是否正在运行。
        """
        return self._running
