"""同步执行器（阻塞执行）。"""

import asyncio
import inspect
from typing import Any, Callable, Coroutine

from epscheduler.exceptions import JobExecutionError

from .base import Executor


class SyncExecutor(Executor):
    """同步执行器。

    直接同步执行任务，不使用并发控制。
    适合简单测试或单线程场景。

    注意：提交协程时会阻塞当前线程运行事件循环。
    """

    def __init__(self) -> None:
        """初始化同步执行器。"""
        self._running = True

    async def submit(
        self, fn: Callable[..., Any] | Coroutine[Any, Any, Any], *args, **kwargs
    ) -> Any:
        """提交一个可调用对象并返回结果。

        Args:
            fn: 可调用对象或协程。
            *args: 位置参数。
            **kwargs: 关键字参数。

        Returns:
            执行结果。

        Raises:
            JobExecutionError: 执行过程中出错时抛出。
        """
        try:
            # 如果是协程，直接运行
            if asyncio.iscoroutine(fn):
                return await fn
            # 如果是协程函数，调用并运行
            elif inspect.iscoroutinefunction(fn):
                return await fn(*args, **kwargs)
            # 同步函数直接执行
            else:
                return fn(*args, **kwargs)
        except Exception as e:
            raise JobExecutionError(f"任务执行失败: {e}") from e

    async def shutdown(self, timeout: float | None = None) -> None:
        """优雅关闭执行器。

        同步执行器无需等待，直接标记关闭。

        Args:
            timeout: 最大等待时间（秒），忽略此参数。
        """
        self._running = False

    def is_running(self) -> bool:
        """检查执行器是否正在运行。

        Returns:
            是否正在运行。
        """
        return self._running
