"""执行器模块。

提供多种执行器实现：
- Executor: 抽象基类
- AsyncExecutor: 协程池（适合 I/O 密集型）
- ThreadExecutor: 线程池（适合 CPU 密集型）
- SyncExecutor: 同步执行（适合测试）
"""

from .async_executor import AsyncExecutor
from .base import Executor
from .sync_executor import SyncExecutor
from .thread_executor import ThreadExecutor

__all__ = [
    "Executor",
    "AsyncExecutor",
    "ThreadExecutor",
    "SyncExecutor",
]
