"""线程池执行器。"""

import asyncio
import inspect
from concurrent.futures import ThreadPoolExecutor as _ThreadPoolExecutor
from typing import Any, Callable, Coroutine

from epscheduler.exceptions import JobExecutionError

from .base import Executor


class ThreadExecutor(Executor):
    """线程池执行器。

    使用 ThreadPoolExecutor 执行同步任务。
    适合 CPU 密集型任务或需要线程隔离的场景。

    Attributes:
        max_workers: 最大线程数，None 表示自动选择。
    """

    def __init__(self, max_workers: int | None = None) -> None:
        """初始化线程池执行器。

        Args:
            max_workers: 最大线程数，None 表示自动选择（CPU 数量 * 5）。
        """
        self.max_workers = max_workers
        self._pool: _ThreadPoolExecutor | None = None
        self._running = True

    def _ensure_pool(self) -> None:
        """确保线程池已初始化。"""
        if self._pool is None:
            self._pool = _ThreadPoolExecutor(max_workers=self.max_workers)

    async def submit(
        self, fn: Callable[..., Any] | Coroutine[Any, Any, Any], *args, **kwargs
    ) -> Any:
        """提交一个可调用对象并返回结果。

        Args:
            fn: 可调用对象或协程。
            *args: 位置参数。
            **kwargs: 关键字参数。

        Returns:
            执行结果。

        Raises:
            JobExecutionError: 执行过程中出错时抛出。
        """
        self._ensure_pool()

        # 如果是协程，需要在事件循环中运行
        if asyncio.iscoroutine(fn) or inspect.iscoroutinefunction(fn):
            # 创建协程
            if inspect.iscoroutinefunction(fn):
                coro = fn(*args, **kwargs)
            else:
                coro = fn

            # 在线程中运行事件循环来执行协程
            def run_coro_in_thread() -> Any:
                """在线程中运行协程。"""
                try:
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    return loop.run_until_complete(coro)
                finally:
                    loop.close()

            future = self._pool.submit(run_coro_in_thread)
        else:
            # 同步函数直接提交到线程池
            future = self._pool.submit(fn, *args, **kwargs)

        try:
            return await asyncio.wrap_future(future)
        except Exception as e:
            raise JobExecutionError(f"任务执行失败: {e}") from e

    async def shutdown(self, timeout: float | None = None) -> None:
        """优雅关闭执行器，等待运行中的任务完成。

        Args:
            timeout: 最大等待时间（秒），None 表示无限等待。
        """
        self._running = False

        if self._pool is not None:
            self._pool.shutdown(wait=True, cancel_futures=False)
            self._pool = None

    def is_running(self) -> bool:
        """检查执行器是否正在运行。

        Returns:
            是否正在运行。
        """
        return self._running
