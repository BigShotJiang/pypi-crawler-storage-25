from __future__ import annotations

import pytest

from epscheduler.dag import DAG, DAGHooks
from epscheduler.exceptions import DAGCycleError, DAGError
from epscheduler.nodetypes import ConditionNode, FuncNode, LoopNode, inject
from epscheduler.nodetypes.base import BaseNode
from epscheduler.state import NodeState


def _make_func_node(nid: str, name: str = "") -> FuncNode:
    """快捷创建 FuncNode 节点。"""
    return FuncNode(id=nid, fn=lambda: None, name=name or f"node_{nid}")


class TestTopology:
    """拓扑管理相关测试。"""

    def test_add_node(self):
        dag = DAG()
        node = _make_func_node("a")
        dag.add_node(node)
        assert "a" in dag._nodes

    def test_add_duplicate_node_raises(self):
        dag = DAG()
        node = _make_func_node("a")
        dag.add_node(node)
        with pytest.raises(DAGError, match="已存在"):
            dag.add_node(node)

    def test_add_edge(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.add_node(_make_func_node("b"))
        dag.add_edge("a", "b")
        assert dag.upstream_ids("b") == {"a"}
        assert dag.downstream_ids("a") == {"b"}

    def test_add_edge_missing_node_raises(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        with pytest.raises(DAGError, match="不存在"):
            dag.add_edge("a", "b")
        with pytest.raises(DAGError, match="不存在"):
            dag.add_edge("b", "a")

    def test_topological_sort_linear(self):
        dag = DAG()
        for nid in ("a", "b", "c"):
            dag.add_node(_make_func_node(nid))
        dag.add_edge("a", "b")
        dag.add_edge("b", "c")
        assert dag.topological_sort() == ["a", "b", "c"]

    def test_topological_sort_diamond(self):
        """A → B, A → C, B → D, C → D"""
        dag = DAG()
        for nid in ("a", "b", "c", "d"):
            dag.add_node(_make_func_node(nid))
        dag.add_edge("a", "b")
        dag.add_edge("a", "c")
        dag.add_edge("b", "d")
        dag.add_edge("c", "d")
        result = dag.topological_sort()
        assert result[0] == "a"
        assert result[-1] == "d"
        assert set(result[1:3]) == {"b", "c"}

    def test_remove_node(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.add_node(_make_func_node("b"))
        dag.add_edge("a", "b")
        dag.remove_node("b")
        assert "b" not in dag._nodes
        assert dag.downstream_ids("a") == set()

    def test_validate_empty_dag(self):
        dag = DAG()
        assert dag.validate() is False

    def test_validate_valid_dag(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.add_node(_make_func_node("b"))
        dag.add_edge("a", "b")
        assert dag.validate() is True

    def test_edge_condition(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.add_node(_make_func_node("b"))
        dag.add_edge("a", "b", condition="pass")
        assert dag.edge_condition("a", "b") == "pass"
        assert dag.edge_condition("a", "c") is None  # 不存在的边


class TestCycleDetection:
    """环路检测相关测试。"""

    def test_simple_cycle_raises(self):
        dag = DAG()
        for nid in ("a", "b", "c"):
            dag.add_node(_make_func_node(nid))
        dag.add_edge("a", "b")
        dag.add_edge("b", "c")
        with pytest.raises(DAGCycleError, match="环路"):
            dag.add_edge("c", "a")
        # 环路边不应残留在图中
        assert dag.downstream_ids("c") == set()
        assert dag.upstream_ids("a") == set()

    def test_self_loop_raises(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.add_node(_make_func_node("b"))
        dag.add_edge("a", "b")
        with pytest.raises(DAGCycleError, match="环路"):
            dag.add_edge("a", "a")


class TestRuntimeState:
    """运行时状态管理相关测试。"""

    def test_get_ready_nodes_initial(self):
        dag = DAG()
        for nid in ("a", "b", "c"):
            dag.add_node(_make_func_node(nid))
        dag.add_edge("a", "b")
        dag.add_edge("b", "c")
        ready = dag.get_ready_nodes()
        assert len(ready) == 1
        assert ready[0].id == "a"

    def test_progressive_execution(self):
        dag = DAG()
        for nid in ("a", "b", "c"):
            dag.add_node(_make_func_node(nid))
        dag.add_edge("a", "b")
        dag.add_edge("b", "c")

        ready = dag.get_ready_nodes()
        assert [n.id for n in ready] == ["a"]
        dag.mark_completed("a")

        ready = dag.get_ready_nodes()
        assert [n.id for n in ready] == ["b"]
        dag.mark_completed("b")

        ready = dag.get_ready_nodes()
        assert [n.id for n in ready] == ["c"]
        dag.mark_completed("c")

        assert dag.is_complete()
        assert dag.is_success()

    def test_multiple_upstream_dependencies(self):
        dag = DAG()
        for nid in ("a", "b", "c"):
            dag.add_node(_make_func_node(nid))
        dag.add_edge("a", "c")
        dag.add_edge("b", "c")

        ready = dag.get_ready_nodes()
        assert {n.id for n in ready} == {"a", "b"}

        dag.mark_completed("a")
        ready = dag.get_ready_nodes()
        assert {n.id for n in ready} == {"b"}

        dag.mark_completed("b")
        ready = dag.get_ready_nodes()
        assert {n.id for n in ready} == {"c"}

    def test_mark_failed(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.mark_failed("a")
        assert dag._nodes["a"].state == NodeState.FAILED
        assert dag.is_complete()
        assert not dag.is_success()

    def test_mark_skipped(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.mark_skipped("a")
        assert dag._nodes["a"].state == NodeState.SKIPPED
        assert dag.is_complete()
        assert dag.is_success()

    def test_reset(self):
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.add_node(_make_func_node("b"))
        dag.add_edge("a", "b")
        dag.mark_completed("a")
        dag.mark_completed("b")
        assert dag.is_complete()

        dag.reset()
        assert dag._nodes["a"].state == NodeState.PENDING
        assert dag._nodes["b"].state == NodeState.PENDING
        assert not dag.is_complete()


class TestConditionRouting:
    """条件路由相关测试。"""

    def test_branch_selection_skips_other_branch(self):
        """条件节点选择 pass 分支时，fail 分支被跳过。"""
        dag = DAG()
        dag.add_node(_make_func_node("a"))
        dag.add_node(ConditionNode(
            id="cond", name="判断",
            key="score", branches={80: "pass", 50: "fail"},
        ))
        dag.add_node(_make_func_node("pass_action"))
        dag.add_node(_make_func_node("fail_action"))

        dag.add_edge("a", "cond")
        dag.add_edge("cond", "pass_action", condition="pass")
        dag.add_edge("cond", "fail_action", condition="fail")

        dag.mark_completed("a")

        # cond 就绪，模拟执行返回 _branch: pass
        ready = dag.get_ready_nodes()
        assert {n.id for n in ready} == {"cond"}
        dag.mark_completed("cond", {"_branch": "pass"})

        # pass_action 应就绪，fail_action 应被跳过
        assert dag._nodes["pass_action"].state == NodeState.PENDING
        assert dag._nodes["fail_action"].state == NodeState.SKIPPED
        ready = dag.get_ready_nodes()
        assert {n.id for n in ready} == {"pass_action"}

        dag.mark_completed("pass_action")
        assert dag.is_complete()
        assert dag.is_success()

    def test_no_matching_branch_skips_all(self):
        """没有匹配的分支时，所有条件边下游被跳过。"""
        dag = DAG()
        dag.add_node(ConditionNode(
            id="cond", name="判断",
            key="x", branches={1: "one", 2: "two"},
        ))
        dag.add_node(_make_func_node("one_action"))
        dag.add_node(_make_func_node("two_action"))

        dag.add_edge("cond", "one_action", condition="one")
        dag.add_edge("cond", "two_action", condition="two")

        dag.mark_completed("cond", {"_branch": None})

        assert dag._nodes["one_action"].state == NodeState.SKIPPED
        assert dag._nodes["two_action"].state == NodeState.SKIPPED
        assert dag.is_complete()

    def test_skip_propagates_downstream(self):
        """被跳过的分支，其下游节点也递归被跳过。"""
        dag = DAG()
        dag.add_node(ConditionNode(
            id="cond", name="判断",
            key="go", branches={True: "yes"},
        ))
        dag.add_node(_make_func_node("yes"))
        dag.add_node(_make_func_node("yes_child"))
        dag.add_node(_make_func_node("no"))
        dag.add_node(_make_func_node("no_child"))

        dag.add_edge("cond", "yes", condition="yes")
        dag.add_edge("cond", "no", condition="no")
        dag.add_edge("yes", "yes_child")
        dag.add_edge("no", "no_child")

        dag.mark_completed("cond", {"_branch": "yes"})

        assert dag._nodes["no"].state == NodeState.SKIPPED
        assert dag._nodes["no_child"].state == NodeState.SKIPPED
        assert dag._nodes["yes"].state == NodeState.PENDING
        assert dag._nodes["yes_child"].state == NodeState.PENDING


class TestNodeTypes:
    """NodeType 执行测试。"""

    @pytest.mark.asyncio
    async def test_func_node_execute(self):
        fn = FuncNode(id="a", fn=lambda x, y: {"sum": x + y}, x=1, y=2)
        result = await fn.execute({})
        assert result == {"sum": 3}

    @pytest.mark.asyncio
    async def test_func_node_no_context_injection(self):
        """未使用 @inject 时，context 不注入。"""
        fn = FuncNode(id="a", fn=lambda: {"ok": True})
        result = await fn.execute({"unused": 42})
        assert result == {"ok": True}

    @pytest.mark.asyncio
    async def test_func_node_inject(self):
        """@inject 声明的键从 context 注入。"""

        @inject("x")
        def step(x):
            return {"result": x + 1}

        fn = FuncNode(id="a", fn=step)
        result = await fn.execute({"x": 5, "unused": 99})
        assert result == {"result": 6}

    @pytest.mark.asyncio
    async def test_func_node_kwargs_override_context(self):
        """FuncNode 的 kwargs 覆盖 context 中同名键。"""

        @inject("x")
        def step(x):
            return {"result": x}

        fn = FuncNode(id="a", fn=step, x=10)
        result = await fn.execute({"x": 5})
        assert result == {"result": 10}

    @pytest.mark.asyncio
    async def test_func_node_non_dict_return(self):
        fn = FuncNode(id="a", fn=lambda: 42)
        result = await fn.execute({})
        assert result == {"_result": 42}

    @pytest.mark.asyncio
    async def test_func_node_async(self):
        async def add(x: int, y: int) -> dict:
            return {"sum": x + y}

        fn = FuncNode(id="a", fn=add, x=3, y=4)
        result = await fn.execute({})
        assert result == {"sum": 7}

    @pytest.mark.asyncio
    async def test_condition_node_execute(self):
        cn = ConditionNode(id="cond", key="status", branches={200: "ok", 500: "err"})
        result = await cn.execute({"status": 200})
        assert result == {"_branch": "ok"}

    @pytest.mark.asyncio
    async def test_condition_node_no_match(self):
        cn = ConditionNode(id="cond", key="status", branches={200: "ok"})
        result = await cn.execute({"status": 404})
        assert result == {"_branch": None}

    @pytest.mark.asyncio
    async def test_loop_node_execute(self):
        ln = LoopNode(id="loop", items_key="items", fn=lambda item, **ctx: item * 2)
        result = await ln.execute({"items": [1, 2, 3]})
        assert result == {"_results": [2, 4, 6]}


class TestHooks:
    """钩子机制相关测试。"""

    def test_on_node_complete_hook(self):
        completed: list[str] = []

        def track(node: BaseNode) -> None:
            completed.append(node.id)

        hooks = DAGHooks(on_node_complete=track)
        dag = DAG(hooks=hooks)
        dag.add_node(_make_func_node("a"))
        dag.add_node(_make_func_node("b"))

        dag.mark_completed("a")
        assert completed == ["a"]

        dag.mark_completed("b")
        assert completed == ["a", "b"]

    def test_on_dag_complete_hook(self):
        completed = False

        def on_done() -> None:
            nonlocal completed
            completed = True

        hooks = DAGHooks(on_dag_complete=on_done)
        dag = DAG(hooks=hooks)
        dag.add_node(_make_func_node("a"))
        assert not completed
        dag.mark_completed("a")
        assert completed

    def test_hook_does_not_affect_dag(self):
        def bad_hook(node: BaseNode) -> None:
            raise RuntimeError("钩子异常")

        hooks = DAGHooks(on_node_complete=bad_hook)
        dag = DAG(hooks=hooks)
        dag.add_node(_make_func_node("a"))
        dag.mark_completed("a")
        assert dag._nodes["a"].state == NodeState.SUCCESS
        assert dag.is_complete()


class TestParams:
    """参数传递相关测试。"""

    def test_params_default_empty(self):
        dag = DAG()
        assert dag.params == {}

    def test_params_passed(self):
        dag = DAG(params={"timeout": 30, "retries": 3})
        assert dag.params == {"timeout": 30, "retries": 3}

    def test_params_none(self):
        dag = DAG(params=None)
        assert dag.params == {}
