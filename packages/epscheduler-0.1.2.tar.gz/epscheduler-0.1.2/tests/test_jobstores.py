"""作业存储单元测试。"""

import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from epscheduler.exceptions import JobConfigError
from epscheduler.job import JobStatus, create_callable_job
from epscheduler.jobstores import FileJobStore, MemoryJobStore
from epscheduler.triggers import IntervalTrigger, ManualTrigger


class TestMemoryJobStore:
    """MemoryJobStore 测试类。"""

    @pytest.mark.asyncio
    async def test_add_job(self) -> None:
        """测试添加作业。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        job_id = await store.add(job)
        assert job_id == "job_1"
        assert await store.count() == 1

    @pytest.mark.asyncio
    async def test_add_duplicate_job_raises_error(self) -> None:
        """测试添加重复 ID 作业抛出异常。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        await store.add(job)

        with pytest.raises(JobConfigError):
            await store.add(job)

    @pytest.mark.asyncio
    async def test_get_job(self) -> None:
        """测试获取作业。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        await store.add(job)

        result = await store.get("job_1")
        assert result is not None
        assert result.job_id == "job_1"
        assert result.name == "测试"

    @pytest.mark.asyncio
    async def test_get_nonexistent_job(self) -> None:
        """测试获取不存在的作业返回 None。"""
        store = MemoryJobStore()

        result = await store.get("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_list_all(self) -> None:
        """测试列出所有作业。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()

        job1 = create_callable_job("job_1", "作业1", trigger, lambda: 1)
        job2 = create_callable_job("job_2", "作业2", trigger, lambda: 2)

        await store.add(job1)
        await store.add(job2)

        jobs = await store.list_all()
        assert len(jobs) == 2
        job_ids = [j.job_id for j in jobs]
        assert "job_1" in job_ids
        assert "job_2" in job_ids

    @pytest.mark.asyncio
    async def test_remove_job(self) -> None:
        """测试删除作业。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        await store.add(job)

        result = await store.remove("job_1")
        assert result is True
        assert await store.count() == 0

    @pytest.mark.asyncio
    async def test_remove_nonexistent_job(self) -> None:
        """测试删除不存在的作业返回 False。"""
        store = MemoryJobStore()

        result = await store.remove("nonexistent")
        assert result is False

    @pytest.mark.asyncio
    async def test_update_job(self) -> None:
        """测试更新作业。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "原始", trigger, lambda: 1)

        await store.add(job)

        # 更新名称
        job.name = "更新后"
        result = await store.update(job)
        assert result is True

        updated = await store.get("job_1")
        assert updated is not None
        assert updated.name == "更新后"

    @pytest.mark.asyncio
    async def test_update_nonexistent_job(self) -> None:
        """测试更新不存在的作业返回 False。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        result = await store.update(job)
        assert result is False

    @pytest.mark.asyncio
    async def test_get_due_jobs(self) -> None:
        """测试获取到期作业。"""
        store = MemoryJobStore()

        # 创建到期作业
        trigger1 = IntervalTrigger(seconds=1)
        job1 = create_callable_job("due_job", "到期", trigger1, lambda: 1)

        # 创建未到期作业（暂停状态）
        trigger2 = ManualTrigger()
        job2 = create_callable_job("paused_job", "暂停", trigger2, lambda: 2)
        job2.pause()

        await store.add(job1)
        await store.add(job2)

        now = datetime.now(timezone.utc) + timedelta(seconds=2)
        due_jobs = await store.get_due_jobs(now)

        assert len(due_jobs) == 1
        assert due_jobs[0].job_id == "due_job"

    @pytest.mark.asyncio
    async def test_get_due_jobs_sorted_by_next_run_time(self) -> None:
        """测试到期作业按下次运行时间排序。"""
        store = MemoryJobStore()

        # 创建两个到期作业
        trigger1 = IntervalTrigger(seconds=1)
        job1 = create_callable_job("job_1", "作业1", trigger1, lambda: 1)

        trigger2 = IntervalTrigger(seconds=2)
        job2 = create_callable_job("job_2", "作业2", trigger2, lambda: 2)

        await store.add(job1)
        await store.add(job2)

        now = datetime.now(timezone.utc) + timedelta(seconds=10)
        due_jobs = await store.get_due_jobs(now)

        # 按下次运行时间排序
        assert due_jobs[0].next_run_time <= due_jobs[1].next_run_time

    @pytest.mark.asyncio
    async def test_count(self) -> None:
        """测试获取作业总数。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()

        assert await store.count() == 0

        job1 = create_callable_job("job_1", "作业1", trigger, lambda: 1)
        await store.add(job1)
        assert await store.count() == 1

        job2 = create_callable_job("job_2", "作业2", trigger, lambda: 2)
        await store.add(job2)
        assert await store.count() == 2

    @pytest.mark.asyncio
    async def test_clear(self) -> None:
        """测试清空存储。"""
        store = MemoryJobStore()
        trigger = ManualTrigger()

        job1 = create_callable_job("job_1", "作业1", trigger, lambda: 1)
        job2 = create_callable_job("job_2", "作业2", trigger, lambda: 2)

        await store.add(job1)
        await store.add(job2)

        await store.clear()
        assert await store.count() == 0


class TestFileJobStore:
    """FileJobStore 测试类。"""

    @pytest.mark.asyncio
    async def test_add_and_get_job(self) -> None:
        """测试添加和获取作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "jobs.pkl"
            store = FileJobStore(filepath)

            trigger = IntervalTrigger(seconds=10)
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)

            await store.add(job)

            # 获取作业
            result = await store.get("job_1")
            assert result is not None
            assert result.job_id == "job_1"
            assert result.trigger is not None

    @pytest.mark.asyncio
    async def test_persistence(self) -> None:
        """测试持久化到文件。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "jobs.pkl"

            # 创建存储并添加作业
            store1 = FileJobStore(filepath)
            trigger = IntervalTrigger(seconds=10)
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)
            job.mark_running()
            job.mark_completed("done")

            await store1.add(job)

            # 创建新存储加载文件
            store2 = FileJobStore(filepath)
            result = await store2.get("job_1")

            assert result is not None
            assert result.job_id == "job_1"
            assert result.status == JobStatus.SUCCESS
            assert result.last_run_result == "done"

    @pytest.mark.asyncio
    async def test_remove_persistence(self) -> None:
        """测试删除操作持久化。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "jobs.pkl"

            store1 = FileJobStore(filepath)
            trigger = ManualTrigger()
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)
            await store1.add(job)

            await store1.remove("job_1")

            # 新存储验证删除
            store2 = FileJobStore(filepath)
            result = await store2.get("job_1")
            assert result is None

    @pytest.mark.asyncio
    async def test_update_persistence(self) -> None:
        """测试更新操作持久化。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "jobs.pkl"

            store1 = FileJobStore(filepath)
            trigger = ManualTrigger()
            job = create_callable_job("job_1", "原始", trigger, lambda: 1)
            await store1.add(job)

            # 更新
            job.name = "更新后"
            await store1.update(job)

            # 新存储验证更新
            store2 = FileJobStore(filepath)
            result = await store2.get("job_1")
            assert result is not None
            assert result.name == "更新后"

    @pytest.mark.asyncio
    async def test_get_due_jobs(self) -> None:
        """测试获取到期作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "jobs.pkl"
            store = FileJobStore(filepath)

            trigger = IntervalTrigger(seconds=1)
            job = create_callable_job("due_job", "到期", trigger, lambda: 1)

            await store.add(job)

            now = datetime.now(timezone.utc) + timedelta(seconds=2)
            due_jobs = await store.get_due_jobs(now)

            assert len(due_jobs) == 1
            assert due_jobs[0].job_id == "due_job"

    @pytest.mark.asyncio
    async def test_clear_persistence(self) -> None:
        """测试清空操作持久化。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "jobs.pkl"

            store1 = FileJobStore(filepath)
            trigger = ManualTrigger()
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)
            await store1.add(job)

            await store1.clear()

            # 新存储验证清空
            store2 = FileJobStore(filepath)
            assert await store2.count() == 0

    @pytest.mark.asyncio
    async def test_callable_not_serialized(self) -> None:
        """测试 callable 不参与序列化。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "jobs.pkl"

            store1 = FileJobStore(filepath)
            trigger = IntervalTrigger(seconds=10)
            job = create_callable_job("job_1", "测试", trigger, lambda x: x + 1)
            await store1.add(job)

            # 新存储加载后 callable 为 None
            store2 = FileJobStore(filepath)
            result = await store2.get("job_1")

            assert result is not None
            assert result.callable is None  # callable 不序列化


class TestJobStoreComparison:
    """存储对比测试。"""

    @pytest.mark.asyncio
    async def test_both_stores_same_interface(self) -> None:
        """测试两种存储接口一致。"""
        trigger = ManualTrigger()
        job = create_callable_job("test", "测试", trigger, lambda: 1)

        # 内存存储
        mem_store = MemoryJobStore()
        await mem_store.add(job)
        mem_result = await mem_store.get("test")
        assert mem_result is not None

        await mem_store.remove("test")
        assert await mem_store.get("test") is None

        # 文件存储
        with tempfile.TemporaryDirectory() as tmpdir:
            filepath = Path(tmpdir) / "jobs.pkl"
            file_store = FileJobStore(filepath)

            await file_store.add(job)
            file_result = await file_store.get("test")
            assert file_result is not None

            await file_store.remove("test")
            assert await file_store.get("test") is None
