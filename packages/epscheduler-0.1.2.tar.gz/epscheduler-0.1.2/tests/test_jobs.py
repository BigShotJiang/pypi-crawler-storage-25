"""作业模块单元测试。"""

from datetime import datetime, timedelta, timezone

import pytest

from epscheduler.dag import DAG
from epscheduler.exceptions import JobConfigError
from epscheduler.job import Job, JobType, create_callable_job, create_dag_job
from epscheduler.nodetypes import FuncNode
from epscheduler.state import JobStatus
from epscheduler.triggers import IntervalTrigger, ManualTrigger


class TestJobModel:
    """Job 模型测试类。"""

    def test_create_callable_job_basic(self) -> None:
        """测试创建基本 Callable 作业。"""
        trigger = IntervalTrigger(seconds=10)
        job = create_callable_job(
            job_id="test_job",
            name="测试作业",
            trigger=trigger,
            fn=lambda: "hello",
        )

        assert job.job_id == "test_job"
        assert job.name == "测试作业"
        assert job.job_type == JobType.CALLABLE
        assert job.status == JobStatus.PENDING
        assert job.run_count == 0
        assert job.next_run_time is not None
        assert job.callable is not None

    def test_create_callable_job_with_params(self) -> None:
        """测试创建带参数的 Callable 作业。"""
        trigger = ManualTrigger()
        job = create_callable_job(
            job_id="param_job",
            name="参数作业",
            trigger=trigger,
            fn=lambda x, y: x + y,
            params={"x": 1, "y": 2},
            max_runs=5,
        )

        assert job.params == {"x": 1, "y": 2}
        assert job.max_runs == 5

    def test_create_dag_job(self) -> None:
        """测试创建 DAG 作业。"""
        dag = DAG()
        node1 = FuncNode(node_id="node1", fn=lambda: 1)
        dag.add_node(node1)

        trigger = IntervalTrigger(minutes=5)
        job = create_dag_job(
            job_id="dag_job",
            name="DAG 作业",
            trigger=trigger,
            dag=dag,
        )

        assert job.job_type == JobType.DAG
        assert job.dag is not None
        assert job.is_dag_job()

    def test_set_callable_on_dag_job_raises_error(self) -> None:
        """测试 DAG 作业设置 callable 抛出异常。"""
        dag = DAG()
        trigger = ManualTrigger()
        job = create_dag_job("dag_job", "DAG", trigger, dag)

        with pytest.raises(JobConfigError):
            job.set_callable(lambda: None)

    def test_set_dag_on_callable_job_raises_error(self) -> None:
        """测试 Callable 作业设置 DAG 抛出异常。"""
        trigger = ManualTrigger()
        job = create_callable_job("call_job", "Callable", trigger, lambda: None)

        with pytest.raises(JobConfigError):
            job.set_dag(DAG())

    def test_is_due_true(self) -> None:
        """测试作业到期判断正确返回 True。"""
        trigger = IntervalTrigger(seconds=1)
        job = create_callable_job("due_job", "到期作业", trigger, lambda: None)

        # next_run_time 应该是当前时间附近，检查是否到期
        now = datetime.now(timezone.utc) + timedelta(seconds=2)
        assert job.is_due(now)

    def test_is_due_paused_job(self) -> None:
        """测试暂停作业返回 False。"""
        trigger = IntervalTrigger(seconds=1)
        job = create_callable_job("paused_job", "暂停作业", trigger, lambda: None)
        job.pause()

        now = datetime.now(timezone.utc) + timedelta(seconds=2)
        assert not job.is_due(now)

    def test_is_due_completed_job(self) -> None:
        """测试已完成作业返回 False。"""
        trigger = IntervalTrigger(seconds=1)
        job = create_callable_job("comp_job", "完成作业", trigger, lambda: None, max_runs=1)
        job.mark_running()
        job.mark_completed()

        now = datetime.now(timezone.utc) + timedelta(seconds=2)
        assert not job.is_due(now)

    def test_is_due_success_job(self) -> None:
        """测试成功状态作业可以再次触发。"""
        trigger = IntervalTrigger(seconds=1)
        job = create_callable_job("success_job", "成功作业", trigger, lambda: None)
        job.mark_running()
        job.mark_completed()

        # SUCCESS 状态应该可以再次执行
        # next_run_time 是 last_run_time + 1秒，所以需要等待足够时间
        now = datetime.now(timezone.utc) + timedelta(seconds=10)
        assert job.is_due(now)

    def test_is_due_failed_job(self) -> None:
        """测试失败状态作业可以再次触发。"""
        trigger = IntervalTrigger(seconds=1)
        job = create_callable_job("failed_job", "失败作业", trigger, lambda: None)
        job.mark_failed(ValueError("error"))

        # FAILED 状态应该可以再次执行
        now = datetime.now(timezone.utc) + timedelta(seconds=2)
        assert job.is_due(now)

    def test_is_due_max_runs_reached(self) -> None:
        """测试达到最大运行次数返回 False。"""
        trigger = IntervalTrigger(seconds=1)
        job = create_callable_job("max_job", "最大次数", trigger, lambda: None, max_runs=1)
        job.run_count = 1

        now = datetime.now(timezone.utc) + timedelta(seconds=2)
        assert not job.is_due(now)

    def test_mark_running(self) -> None:
        """测试标记运行状态。"""
        trigger = ManualTrigger()
        job = create_callable_job("run_job", "运行", trigger, lambda: None)

        job.mark_running()
        assert job.status == JobStatus.RUNNING

    def test_mark_completed(self) -> None:
        """测试标记完成状态。"""
        trigger = IntervalTrigger(seconds=10)
        job = create_callable_job("comp_job", "完成", trigger, lambda: None)

        job.mark_running()
        job.mark_completed(result="success")

        assert job.status == JobStatus.SUCCESS
        assert job.run_count == 1
        assert job.last_run_result == "success"
        assert job.last_run_time is not None
        assert job.next_run_time is not None

    def test_mark_completed_reaches_max_runs(self) -> None:
        """测试完成达到最大次数后状态变为 COMPLETED。"""
        trigger = ManualTrigger()
        job = create_callable_job("max_comp", "最大", trigger, lambda: None, max_runs=1)

        job.mark_running()
        job.mark_completed()

        assert job.status == JobStatus.COMPLETED
        assert job.run_count == 1

    def test_mark_failed(self) -> None:
        """测试标记失败状态。"""
        trigger = ManualTrigger()
        job = create_callable_job("fail_job", "失败", trigger, lambda: None)

        error = ValueError("test error")
        job.mark_failed(error)

        assert job.status == JobStatus.FAILED
        assert job.run_count == 1
        assert job.last_run_result == "test error"

    def test_pause_and_resume(self) -> None:
        """测试暂停和恢复。"""
        trigger = ManualTrigger()
        job = create_callable_job("pause_job", "暂停", trigger, lambda: None)

        job.pause()
        assert job.status == JobStatus.PAUSED

        job.resume()
        assert job.status == JobStatus.PENDING

    def test_pause_success_job(self) -> None:
        """测试成功状态的作业可以暂停。"""
        trigger = IntervalTrigger(seconds=10)
        job = create_callable_job("success_pause", "成功暂停", trigger, lambda: None)
        job.mark_running()
        job.mark_completed()

        assert job.status == JobStatus.SUCCESS
        job.pause()
        assert job.status == JobStatus.PAUSED

    def test_pause_completed_job_raises_error(self) -> None:
        """测试已完成作业暂停抛出异常。"""
        trigger = ManualTrigger()
        job = create_callable_job("comp_pause", "完成暂停", trigger, lambda: None, max_runs=1)
        job.mark_running()
        job.mark_completed()

        with pytest.raises(JobConfigError):
            job.pause()

    def test_pause_running_job_raises_error(self) -> None:
        """测试暂停运行中的作业抛出异常。"""
        trigger = ManualTrigger()
        job = create_callable_job("run_pause", "运行暂停", trigger, lambda: None)
        job.mark_running()

        with pytest.raises(JobConfigError):
            job.pause()

    def test_resume_non_paused_job_raises_error(self) -> None:
        """测试恢复非暂停状态作业抛出异常。"""
        trigger = ManualTrigger()
        job = create_callable_job("non_pause", "非暂停", trigger, lambda: None)

        with pytest.raises(JobConfigError):
            job.resume()

    def test_reset(self) -> None:
        """测试重置作业状态。"""
        trigger = IntervalTrigger(seconds=10)
        job = create_callable_job("reset_job", "重置", trigger, lambda: None)

        # 模拟执行几次
        job.mark_running()
        job.mark_completed()
        job.pause()

        # 重置
        job.reset()

        assert job.run_count == 0
        assert job.status == JobStatus.PENDING
        assert job.last_run_time is None
        assert job.last_run_result is None

    def test_can_run_true(self) -> None:
        """测试 can_run 返回 True。"""
        trigger = ManualTrigger()
        job = create_callable_job("can_run", "可运行", trigger, lambda: None)

        assert job.can_run()

    def test_can_run_paused(self) -> None:
        """测试暂停作业 can_run 返回 False。"""
        trigger = ManualTrigger()
        job = create_callable_job("paused", "暂停", trigger, lambda: None)
        job.pause()

        assert not job.can_run()

    def test_can_run_completed(self) -> None:
        """测试已完成作业 can_run 返回 False。"""
        trigger = ManualTrigger()
        job = create_callable_job("completed", "完成", trigger, lambda: None, max_runs=1)
        job.mark_running()
        job.mark_completed()

        assert not job.can_run()

    def test_can_run_success(self) -> None:
        """测试成功状态作业 can_run 返回 True。"""
        trigger = IntervalTrigger(seconds=10)
        job = create_callable_job("success", "成功", trigger, lambda: None)
        job.mark_running()
        job.mark_completed()

        assert job.can_run()

    def test_can_run_failed(self) -> None:
        """测试失败状态作业 can_run 返回 True。"""
        trigger = IntervalTrigger(seconds=10)
        job = create_callable_job("failed", "失败", trigger, lambda: None)
        job.mark_failed(ValueError("error"))

        assert job.can_run()

    def test_can_run_no_callable(self) -> None:
        """测试没有 callable 的作业 can_run 返回 False。"""
        job = Job(job_id="no_call", name="无函数", job_type=JobType.CALLABLE)

        assert not job.can_run()

    def test_to_dict(self) -> None:
        """测试序列化为字典。"""
        trigger = IntervalTrigger(seconds=30)
        job = create_callable_job("dict_job", "字典", trigger, lambda: None)

        data = job.to_dict()

        assert data["job_id"] == "dict_job"
        assert data["name"] == "字典"
        assert data["job_type"] == "callable"
        assert data["status"] == "pending"
        assert "trigger" in data
        assert data["trigger"]["type"] == "interval"

    def test_from_dict(self) -> None:
        """测试从字典反序列化。"""
        trigger = IntervalTrigger(seconds=30)
        original_job = create_callable_job("orig", "原始", trigger, lambda: None)
        original_job.mark_running()
        original_job.mark_completed("done")

        data = original_job.to_dict()
        restored_job = Job.from_dict(data)

        assert restored_job.job_id == "orig"
        assert restored_job.name == "原始"
        assert restored_job.job_type == JobType.CALLABLE
        assert restored_job.run_count == 1
        assert restored_job.last_run_result == "done"
        # 注意：trigger、callable 需要单独设置
        assert restored_job.trigger is None

    def test_from_dict_with_trigger_set(self) -> None:
        """测试反序列化后设置触发器。"""
        trigger = IntervalTrigger(seconds=30)
        original_job = create_callable_job("trig", "触发器", trigger, lambda: None)

        data = original_job.to_dict()
        restored_job = Job.from_dict(data)

        # 从数据中恢复触发器
        from epscheduler.triggers import create_trigger

        if "trigger" in data:
            restored_job.set_trigger(create_trigger(data["trigger"]))

        assert restored_job.trigger is not None
        assert restored_job.next_run_time is not None


class TestJobStatus:
    """JobStatus 枚举测试类。"""

    def test_status_values(self) -> None:
        """测试状态值。"""
        assert JobStatus.PENDING.value == "pending"
        assert JobStatus.RUNNING.value == "running"
        assert JobStatus.SUCCESS.value == "success"
        assert JobStatus.FAILED.value == "failed"
        assert JobStatus.PAUSED.value == "paused"
        assert JobStatus.COMPLETED.value == "completed"


class TestJobType:
    """JobType 枚举测试类。"""

    def test_type_values(self) -> None:
        """测试类型值。"""
        assert JobType.CALLABLE.value == "callable"
        assert JobType.DAG.value == "dag"

    def test_type_string_conversion(self) -> None:
        """测试类型字符串转换。"""
        assert JobType("callable") == JobType.CALLABLE
        assert JobType("dag") == JobType.DAG
