"""触发器模块单元测试。"""

from datetime import datetime, timedelta, timezone

import pytest

from epscheduler.exceptions import TriggerConfigError
from epscheduler.triggers import (
    CronTrigger,
    DateTrigger,
    IntervalTrigger,
    ManualTrigger,
    create_trigger,
)


class TestCronTrigger:
    """CronTrigger 测试类。"""

    def test_init_valid_cron(self) -> None:
        """测试有效的 cron 表达式初始化。"""
        trigger = CronTrigger("0 9 * * *")
        assert trigger.cron_expression == "0 9 * * *"

    def test_init_invalid_cron(self) -> None:
        """测试无效的 cron 表达式抛出异常。"""
        with pytest.raises(TriggerConfigError):
            CronTrigger("invalid cron")

    def test_next_fire_time_first_call(self) -> None:
        """测试首次触发返回下次执行时间。"""
        trigger = CronTrigger("0 9 * * *")  # 每天 9:00
        next_time = trigger.next_fire_time(None)

        assert next_time is not None
        assert next_time.hour == 9
        assert next_time.minute == 0
        assert next_time.tzinfo is not None

    def test_next_fire_time_subsequent_call(self) -> None:
        """测试后续触发返回递增的执行时间。"""
        trigger = CronTrigger("0 * * * *")  # 每小时

        first_time = trigger.next_fire_time(None)
        assert first_time is not None

        second_time = trigger.next_fire_time(first_time)
        assert second_time is not None
        assert second_time > first_time

    def test_model_dump(self) -> None:
        """测试序列化。"""
        trigger = CronTrigger("0 9 * * *", "Asia/Shanghai")
        data = trigger.model_dump()

        assert data["type"] == "cron"
        assert data["cron_expression"] == "0 9 * * *"
        assert data["timezone_name"] == "Asia/Shanghai"

    def test_model_validate(self) -> None:
        """测试反序列化。"""
        data = {"type": "cron", "cron_expression": "0 9 * * *"}
        trigger = CronTrigger.model_validate(data)

        assert isinstance(trigger, CronTrigger)
        assert trigger.cron_expression == "0 9 * * *"

    def test_model_validate_missing_expression(self) -> None:
        """测试反序列化缺少 cron_expression 时抛出异常。"""
        data = {"type": "cron"}
        with pytest.raises(TriggerConfigError):
            CronTrigger.model_validate(data)


class TestIntervalTrigger:
    """IntervalTrigger 测试类。"""

    def test_init_valid_interval(self) -> None:
        """测试有效的间隔初始化。"""
        trigger = IntervalTrigger(seconds=30)
        assert trigger.seconds == 30

    def test_init_combined_interval(self) -> None:
        """测试组合间隔初始化。"""
        trigger = IntervalTrigger(hours=1, minutes=30, seconds=15)
        assert trigger.hours == 1
        assert trigger.minutes == 30
        assert trigger.seconds == 15

    def test_init_zero_interval(self) -> None:
        """测试零间隔抛出异常。"""
        with pytest.raises(TriggerConfigError):
            IntervalTrigger(seconds=0)

    def test_init_negative_interval(self) -> None:
        """测试负间隔抛出异常。"""
        with pytest.raises(TriggerConfigError):
            IntervalTrigger(seconds=-10)

    def test_next_fire_time_first_call(self) -> None:
        """测试首次触发。"""
        trigger = IntervalTrigger(minutes=5)
        next_time = trigger.next_fire_time(None)

        assert next_time is not None
        assert next_time.tzinfo is not None

    def test_next_fire_time_with_start_time(self) -> None:
        """测试指定开始时间的首次触发。"""
        start = datetime(2026, 1, 1, 9, 0, 0, tzinfo=timezone.utc)
        trigger = IntervalTrigger(hours=1, start_time=start)

        next_time = trigger.next_fire_time(None)
        assert next_time == start

    def test_next_fire_time_subsequent_call(self) -> None:
        """测试后续触发间隔正确。"""
        trigger = IntervalTrigger(minutes=5)

        first_time = trigger.next_fire_time(None)
        assert first_time is not None

        second_time = trigger.next_fire_time(first_time)
        assert second_time is not None

        interval = second_time - first_time
        assert interval == timedelta(minutes=5)

    def test_model_dump(self) -> None:
        """测试序列化。"""
        trigger = IntervalTrigger(hours=2, minutes=30)
        data = trigger.model_dump()

        assert data["type"] == "interval"
        assert data["hours"] == 2
        assert data["minutes"] == 30
        assert data["seconds"] == 0

    def test_model_validate(self) -> None:
        """测试反序列化。"""
        data = {"type": "interval", "hours": 1, "minutes": 30}
        trigger = IntervalTrigger.model_validate(data)

        assert isinstance(trigger, IntervalTrigger)
        assert trigger.hours == 1
        assert trigger.minutes == 30


class TestDateTrigger:
    """DateTrigger 测试类。"""

    def test_init_valid_date(self) -> None:
        """测试有效的日期初始化。"""
        run_date = datetime(2026, 12, 31, 23, 59, 59, tzinfo=timezone.utc)
        trigger = DateTrigger(run_date)
        assert trigger.run_date == run_date

    def test_init_naive_datetime(self) -> None:
        """测试无时区日期自动添加 UTC。"""
        run_date = datetime(2026, 12, 31, 23, 59, 59)
        trigger = DateTrigger(run_date)

        assert trigger.run_date.tzinfo == timezone.utc

    def test_init_none_date(self) -> None:
        """测试 None 日期抛出异常。"""
        with pytest.raises(TriggerConfigError):
            DateTrigger(None)  # type: ignore

    def test_next_fire_time_future(self) -> None:
        """测试未来时间触发。"""
        future = datetime.now(timezone.utc) + timedelta(hours=1)
        trigger = DateTrigger(future)

        next_time = trigger.next_fire_time(None)
        assert next_time == future

    def test_next_fire_time_past(self) -> None:
        """测试过去时间返回 None。"""
        past = datetime.now(timezone.utc) - timedelta(hours=1)
        trigger = DateTrigger(past)

        next_time = trigger.next_fire_time(None)
        assert next_time is None

    def test_next_fire_time_only_once(self) -> None:
        """测试只触发一次。"""
        future = datetime.now(timezone.utc) + timedelta(hours=1)
        trigger = DateTrigger(future)

        # 第一次返回触发时间
        first = trigger.next_fire_time(None)
        assert first == future

        # 第二次返回 None
        second = trigger.next_fire_time(first)
        assert second is None

    def test_model_dump(self) -> None:
        """测试序列化。"""
        run_date = datetime(2026, 12, 31, 23, 59, 59, tzinfo=timezone.utc)
        trigger = DateTrigger(run_date)
        data = trigger.model_dump()

        assert data["type"] == "date"
        assert "2026-12-31T23:59:59" in data["run_date"]

    def test_model_validate(self) -> None:
        """测试反序列化。"""
        data = {"type": "date", "run_date": "2026-12-31T23:59:59+00:00"}
        trigger = DateTrigger.model_validate(data)

        assert isinstance(trigger, DateTrigger)
        assert trigger.run_date.year == 2026
        assert trigger.run_date.month == 12
        assert trigger.run_date.day == 31


class TestManualTrigger:
    """ManualTrigger 测试类。"""

    def test_next_fire_time_always_none(self) -> None:
        """测试始终返回 None。"""
        trigger = ManualTrigger()

        assert trigger.next_fire_time(None) is None
        assert trigger.next_fire_time(datetime.now(timezone.utc)) is None

    def test_model_dump(self) -> None:
        """测试序列化。"""
        trigger = ManualTrigger()
        data = trigger.model_dump()

        assert data == {"type": "manual"}

    def test_model_validate(self) -> None:
        """测试反序列化。"""
        data = {"type": "manual"}
        trigger = ManualTrigger.model_validate(data)

        assert isinstance(trigger, ManualTrigger)


class TestCreateTrigger:
    """create_trigger 工厂函数测试类。"""

    def test_create_cron_trigger(self) -> None:
        """测试创建 CronTrigger。"""
        data = {"type": "cron", "cron_expression": "0 9 * * *"}
        trigger = create_trigger(data)

        assert isinstance(trigger, CronTrigger)

    def test_create_interval_trigger(self) -> None:
        """测试创建 IntervalTrigger。"""
        data = {"type": "interval", "seconds": 30}
        trigger = create_trigger(data)

        assert isinstance(trigger, IntervalTrigger)

    def test_create_date_trigger(self) -> None:
        """测试创建 DateTrigger。"""
        data = {"type": "date", "run_date": "2026-12-31T23:59:59+00:00"}
        trigger = create_trigger(data)

        assert isinstance(trigger, DateTrigger)

    def test_create_manual_trigger(self) -> None:
        """测试创建 ManualTrigger。"""
        data = {"type": "manual"}
        trigger = create_trigger(data)

        assert isinstance(trigger, ManualTrigger)

    def test_create_trigger_missing_type(self) -> None:
        """测试缺少 type 字段抛出异常。"""
        data = {"cron_expression": "0 9 * * *"}
        with pytest.raises(TriggerConfigError):
            create_trigger(data)

    def test_create_trigger_unknown_type(self) -> None:
        """测试未知类型抛出异常。"""
        data = {"type": "unknown"}
        with pytest.raises(TriggerConfigError):
            create_trigger(data)
