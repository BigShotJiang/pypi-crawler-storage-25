"""DBJobStore 单元测试。"""

from datetime import datetime, timedelta, timezone

import pytest

from epscheduler.exceptions import JobConfigError
from epscheduler.job import JobStatus, create_callable_job
from epscheduler.triggers import IntervalTrigger, ManualTrigger


@pytest.fixture
async def db_store():
    """创建内存 SQLite 数据库存储。"""
    pytest.importorskip("sqlalchemy")
    pytest.importorskip("aiosqlite")

    from epscheduler.jobstores import DBJobStore

    store = DBJobStore("sqlite+aiosqlite:///:memory:")
    yield store
    await store.close()


class TestDBJobStore:
    """DBJobStore 测试类。"""

    @pytest.mark.asyncio
    async def test_add_job(self, db_store) -> None:
        """测试添加作业。"""
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        job_id = await db_store.add(job)
        assert job_id == "job_1"
        assert await db_store.count() == 1

    @pytest.mark.asyncio
    async def test_add_duplicate_job_raises_error(self, db_store) -> None:
        """测试添加重复 ID 作业抛出异常。"""
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        await db_store.add(job)

        with pytest.raises(JobConfigError, match="已存在"):
            await db_store.add(job)

    @pytest.mark.asyncio
    async def test_get_job(self, db_store) -> None:
        """测试获取作业。"""
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)
        await db_store.add(job)

        result = await db_store.get("job_1")
        assert result is not None
        assert result.job_id == "job_1"
        assert result.name == "测试"

    @pytest.mark.asyncio
    async def test_get_nonexistent_job(self, db_store) -> None:
        """测试获取不存在作业返回 None。"""
        result = await db_store.get("nonexistent")
        assert result is None

    @pytest.mark.asyncio
    async def test_list_all_jobs(self, db_store) -> None:
        """测试列出所有作业。"""
        trigger = ManualTrigger()
        job1 = create_callable_job("job_1", "测试1", trigger, lambda: 1)
        job2 = create_callable_job("job_2", "测试2", trigger, lambda: 2)

        await db_store.add(job1)
        await db_store.add(job2)

        jobs = await db_store.list_all()
        assert len(jobs) == 2
        assert {j.job_id for j in jobs} == {"job_1", "job_2"}

    @pytest.mark.asyncio
    async def test_remove_job(self, db_store) -> None:
        """测试删除作业。"""
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)
        await db_store.add(job)

        result = await db_store.remove("job_1")
        assert result is True
        assert await db_store.count() == 0

    @pytest.mark.asyncio
    async def test_remove_nonexistent_job(self, db_store) -> None:
        """测试删除不存在作业返回 False。"""
        result = await db_store.remove("nonexistent")
        assert result is False

    @pytest.mark.asyncio
    async def test_update_job(self, db_store) -> None:
        """测试更新作业。"""
        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)
        await db_store.add(job)

        job.run_count = 5
        job.status = JobStatus.SUCCESS
        result = await db_store.update(job)
        assert result is True

        updated = await db_store.get("job_1")
        assert updated is not None
        assert updated.run_count == 5
        assert updated.status == JobStatus.SUCCESS

    @pytest.mark.asyncio
    async def test_update_nonexistent_job(self, db_store) -> None:
        """测试更新不存在作业返回 False。"""
        trigger = ManualTrigger()
        job = create_callable_job("nonexistent", "测试", trigger, lambda: 1)
        result = await db_store.update(job)
        assert result is False

    @pytest.mark.asyncio
    async def test_get_due_jobs(self, db_store) -> None:
        """测试获取到期作业。"""
        now = datetime.now(timezone.utc)

        # 到期作业（使用 ManualTrigger 避免 IntervalTrigger 自动计算时间）
        trigger1 = ManualTrigger()
        job1 = create_callable_job("due_job", "到期", trigger1, lambda: 1)
        job1.next_run_time = now - timedelta(seconds=10)
        await db_store.add(job1)

        # 未到期作业
        trigger2 = ManualTrigger()
        job2 = create_callable_job("future_job", "未到期", trigger2, lambda: 2)
        job2.next_run_time = now + timedelta(hours=1)
        await db_store.add(job2)

        # 已暂停作业（也到期，但不应被返回）
        trigger3 = ManualTrigger()
        job3 = create_callable_job("paused_job", "暂停", trigger3, lambda: 3)
        job3.next_run_time = now - timedelta(seconds=10)
        job3.status = JobStatus.PAUSED
        await db_store.add(job3)

        due_jobs = await db_store.get_due_jobs(now)
        assert len(due_jobs) == 1
        assert due_jobs[0].job_id == "due_job"

    @pytest.mark.asyncio
    async def test_trigger_serialization(self, db_store) -> None:
        """测试触发器正确序列化和恢复。"""
        trigger = IntervalTrigger(hours=1, minutes=30)
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)
        await db_store.add(job)

        result = await db_store.get("job_1")
        assert result is not None
        assert result.trigger is not None
        assert result.trigger.hours == 1
        assert result.trigger.minutes == 30

    @pytest.mark.asyncio
    async def test_clear_jobs(self, db_store) -> None:
        """测试清空所有作业。"""
        trigger = ManualTrigger()
        job1 = create_callable_job("job_1", "测试1", trigger, lambda: 1)
        job2 = create_callable_job("job_2", "测试2", trigger, lambda: 2)

        await db_store.add(job1)
        await db_store.add(job2)

        await db_store.clear()
        assert await db_store.count() == 0

    @pytest.mark.asyncio
    async def test_get_jobs_by_status(self, db_store) -> None:
        """测试按状态获取作业。"""
        trigger = ManualTrigger()
        job1 = create_callable_job("job_1", "测试1", trigger, lambda: 1)
        job1.status = JobStatus.PENDING
        job2 = create_callable_job("job_2", "测试2", trigger, lambda: 2)
        job2.status = JobStatus.SUCCESS

        await db_store.add(job1)
        await db_store.add(job2)

        pending_jobs = await db_store.get_jobs_by_status("pending")
        assert len(pending_jobs) == 1
        assert pending_jobs[0].job_id == "job_1"


class TestDBJobStoreInit:
    """DBJobStore 初始化测试类。"""

    def test_missing_url_and_engine(self) -> None:
        """测试缺少 url 和 engine 参数抛出异常。"""
        pytest.importorskip("sqlalchemy")

        from epscheduler.jobstores import DBJobStore

        with pytest.raises(ValueError, match="必须提供"):
            DBJobStore()

    @pytest.mark.asyncio
    async def test_with_url(self) -> None:
        """测试使用 url 初始化。"""
        pytest.importorskip("sqlalchemy")
        pytest.importorskip("aiosqlite")

        from epscheduler.jobstores import DBJobStore

        store = DBJobStore("sqlite+aiosqlite:///:memory:")
        assert store is not None
        await store.close()
