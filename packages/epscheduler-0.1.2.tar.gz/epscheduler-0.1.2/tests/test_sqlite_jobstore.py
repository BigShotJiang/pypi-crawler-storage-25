"""SQLiteJobStore 单元测试。"""

import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from epscheduler.exceptions import JobConfigError
from epscheduler.job import JobStatus, create_callable_job
from epscheduler.jobstores import MemoryJobStore, SQLiteJobStore
from epscheduler.triggers import IntervalTrigger, ManualTrigger


class TestSQLiteJobStore:
    """SQLiteJobStore 测试类。"""

    @pytest.mark.asyncio
    async def test_init_creates_database(self) -> None:
        """测试初始化创建数据库文件。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            SQLiteJobStore(db_path)

            assert db_path.exists()

    @pytest.mark.asyncio
    async def test_add_job(self) -> None:
        """测试添加作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = ManualTrigger()
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)

            job_id = await store.add(job)
            assert job_id == "job_1"
            assert await store.count() == 1

    @pytest.mark.asyncio
    async def test_add_duplicate_job_raises_error(self) -> None:
        """测试添加重复 ID 作业抛出异常。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = ManualTrigger()
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)

            await store.add(job)

            with pytest.raises(JobConfigError, match="已存在"):
                await store.add(job)

    @pytest.mark.asyncio
    async def test_get_job(self) -> None:
        """测试获取作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = IntervalTrigger(seconds=10)
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)

            await store.add(job)

            result = await store.get("job_1")
            assert result is not None
            assert result.job_id == "job_1"
            assert result.name == "测试"
            assert result.trigger is not None

    @pytest.mark.asyncio
    async def test_get_nonexistent_job(self) -> None:
        """测试获取不存在的作业返回 None。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            result = await store.get("nonexistent")
            assert result is None

    @pytest.mark.asyncio
    async def test_list_all(self) -> None:
        """测试列出所有作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = ManualTrigger()

            job1 = create_callable_job("job_1", "作业1", trigger, lambda: 1)
            job2 = create_callable_job("job_2", "作业2", trigger, lambda: 2)

            await store.add(job1)
            await store.add(job2)

            jobs = await store.list_all()
            assert len(jobs) == 2
            job_ids = [j.job_id for j in jobs]
            assert "job_1" in job_ids
            assert "job_2" in job_ids

    @pytest.mark.asyncio
    async def test_remove_job(self) -> None:
        """测试删除作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = ManualTrigger()
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)

            await store.add(job)

            result = await store.remove("job_1")
            assert result is True
            assert await store.count() == 0

    @pytest.mark.asyncio
    async def test_remove_nonexistent_job(self) -> None:
        """测试删除不存在的作业返回 False。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            result = await store.remove("nonexistent")
            assert result is False

    @pytest.mark.asyncio
    async def test_update_job(self) -> None:
        """测试更新作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = ManualTrigger()
            job = create_callable_job("job_1", "原始", trigger, lambda: 1)

            await store.add(job)

            # 更新名称和状态
            job.name = "更新后"
            job.status = JobStatus.RUNNING
            result = await store.update(job)
            assert result is True

            updated = await store.get("job_1")
            assert updated is not None
            assert updated.name == "更新后"
            assert updated.status == JobStatus.RUNNING

    @pytest.mark.asyncio
    async def test_update_nonexistent_job(self) -> None:
        """测试更新不存在的作业返回 False。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = ManualTrigger()
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)

            result = await store.update(job)
            assert result is False

    @pytest.mark.asyncio
    async def test_get_due_jobs(self) -> None:
        """测试获取到期作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            # 创建到期作业
            trigger1 = IntervalTrigger(seconds=1)
            job1 = create_callable_job("due_job", "到期", trigger1, lambda: 1)

            # 创建未到期作业（暂停状态）
            trigger2 = ManualTrigger()
            job2 = create_callable_job("paused_job", "暂停", trigger2, lambda: 2)
            job2.pause()

            await store.add(job1)
            await store.add(job2)

            now = datetime.now(timezone.utc) + timedelta(seconds=2)
            due_jobs = await store.get_due_jobs(now)

            assert len(due_jobs) == 1
            assert due_jobs[0].job_id == "due_job"

    @pytest.mark.asyncio
    async def test_get_due_jobs_sorted_by_next_run_time(self) -> None:
        """测试到期作业按下次运行时间排序。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            # 创建两个到期作业
            trigger1 = IntervalTrigger(seconds=1)
            job1 = create_callable_job("job_1", "作业1", trigger1, lambda: 1)

            trigger2 = IntervalTrigger(seconds=2)
            job2 = create_callable_job("job_2", "作业2", trigger2, lambda: 2)

            await store.add(job1)
            await store.add(job2)

            now = datetime.now(timezone.utc) + timedelta(seconds=10)
            due_jobs = await store.get_due_jobs(now)

            # 按下次运行时间排序
            assert due_jobs[0].next_run_time <= due_jobs[1].next_run_time

    @pytest.mark.asyncio
    async def test_count(self) -> None:
        """测试获取作业总数。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            assert await store.count() == 0

            trigger = ManualTrigger()

            job1 = create_callable_job("job_1", "作业1", trigger, lambda: 1)
            await store.add(job1)
            assert await store.count() == 1

            job2 = create_callable_job("job_2", "作业2", trigger, lambda: 2)
            await store.add(job2)
            assert await store.count() == 2

    @pytest.mark.asyncio
    async def test_clear(self) -> None:
        """测试清空存储。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = ManualTrigger()

            job1 = create_callable_job("job_1", "作业1", trigger, lambda: 1)
            job2 = create_callable_job("job_2", "作业2", trigger, lambda: 2)

            await store.add(job1)
            await store.add(job2)

            await store.clear()
            assert await store.count() == 0

    @pytest.mark.asyncio
    async def test_persistence(self) -> None:
        """测试持久化到数据库。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"

            # 创建存储并添加作业
            store1 = SQLiteJobStore(db_path)
            trigger = IntervalTrigger(seconds=10)
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)
            job.mark_running()
            job.mark_completed("done")

            await store1.add(job)

            # 创建新存储加载同一个数据库
            store2 = SQLiteJobStore(db_path)
            result = await store2.get("job_1")

            assert result is not None
            assert result.job_id == "job_1"
            assert result.status == JobStatus.SUCCESS
            assert result.last_run_result == "done"

    @pytest.mark.asyncio
    async def test_callable_not_serialized(self) -> None:
        """测试 callable 不参与序列化。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"

            store1 = SQLiteJobStore(db_path)
            trigger = IntervalTrigger(seconds=10)
            job = create_callable_job("job_1", "测试", trigger, lambda x: x + 1)
            await store1.add(job)

            # 新存储加载后 callable 为 None
            store2 = SQLiteJobStore(db_path)
            result = await store2.get("job_1")

            assert result is not None
            assert result.callable is None  # callable 不序列化

    @pytest.mark.asyncio
    async def test_trigger_serialization(self) -> None:
        """测试触发器正确序列化和恢复。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"

            store1 = SQLiteJobStore(db_path)
            trigger = IntervalTrigger(hours=1, minutes=30)
            job = create_callable_job("job_1", "测试", trigger, lambda: 1)
            await store1.add(job)

            # 新存储加载后触发器应恢复
            store2 = SQLiteJobStore(db_path)
            result = await store2.get("job_1")

            assert result is not None
            assert result.trigger is not None
            assert result.trigger.hours == 1
            assert result.trigger.minutes == 30

    @pytest.mark.asyncio
    async def test_get_jobs_by_status(self) -> None:
        """测试按状态获取作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = ManualTrigger()

            job1 = create_callable_job("job_1", "作业1", trigger, lambda: 1)
            job1.status = JobStatus.SUCCESS

            job2 = create_callable_job("job_2", "作业2", trigger, lambda: 2)
            job2.status = JobStatus.FAILED

            job3 = create_callable_job("job_3", "作业3", trigger, lambda: 3)
            job3.status = JobStatus.PENDING

            await store.add(job1)
            await store.add(job2)
            await store.add(job3)

            success_jobs = await store.get_jobs_by_status("success")
            assert len(success_jobs) == 1
            assert success_jobs[0].job_id == "job_1"

            failed_jobs = await store.get_jobs_by_status("failed")
            assert len(failed_jobs) == 1
            assert failed_jobs[0].job_id == "job_2"

    @pytest.mark.asyncio
    async def test_max_runs_limit(self) -> None:
        """测试 max_runs 限制正确过滤到期作业。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            store = SQLiteJobStore(db_path)

            trigger = IntervalTrigger(seconds=1)
            job = create_callable_job("limited_job", "限制", trigger, lambda: 1, max_runs=2)

            # 模拟已运行 2 次
            job.run_count = 2
            job.status = JobStatus.SUCCESS

            await store.add(job)

            now = datetime.now(timezone.utc) + timedelta(seconds=10)
            due_jobs = await store.get_due_jobs(now)

            # 达到 max_runs 后不应再触发
            assert len(due_jobs) == 0


class TestSQLiteJobStoreComparison:
    """SQLite 存储与其他存储对比测试。"""

    @pytest.mark.asyncio
    async def test_same_interface_as_memory_store(self) -> None:
        """测试 SQLite 存储接口与内存存储一致。"""
        trigger = ManualTrigger()
        job = create_callable_job("test", "测试", trigger, lambda: 1)

        # 内存存储
        mem_store = MemoryJobStore()
        await mem_store.add(job)
        mem_result = await mem_store.get("test")
        assert mem_result is not None

        await mem_store.remove("test")
        assert await mem_store.get("test") is None

        # SQLite 存储
        with tempfile.TemporaryDirectory() as tmpdir:
            db_path = Path(tmpdir) / "test.db"
            sqlite_store = SQLiteJobStore(db_path)

            await sqlite_store.add(job)
            sqlite_result = await sqlite_store.get("test")
            assert sqlite_result is not None

            await sqlite_store.remove("test")
            assert await sqlite_store.get("test") is None
