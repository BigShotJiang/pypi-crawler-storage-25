"""CommandNode 单元测试。"""

import asyncio

import pytest

from epscheduler.exceptions import SecurityError
from epscheduler.nodetypes import CommandNode


class TestCommandNode:
    """CommandNode 测试类。"""

    @pytest.mark.asyncio
    async def test_shell_mode_echo(self) -> None:
        """测试 shell 模式执行 echo 命令。"""
        node = CommandNode(command="echo hello", shell=True, id="test_echo")
        result = await node.execute({})

        assert result["returncode"] == 0
        assert result["success"] is True
        assert "hello" in result["stdout"]

    @pytest.mark.asyncio
    async def test_exec_mode_echo(self) -> None:
        """测试 exec 模式执行 echo 命令。"""
        node = CommandNode(command=["echo", "world"], shell=False, id="test_exec")
        result = await node.execute({})

        assert result["returncode"] == 0
        assert result["success"] is True
        assert "world" in result["stdout"]

    @pytest.mark.asyncio
    async def test_command_with_pipe_allowed(self) -> None:
        """测试 shell 模式支持管道（需要 allow_shell_injection）。"""
        node = CommandNode(
            command="echo abc | tr a-z A-Z",
            shell=True,
            allow_shell_injection=True,
            id="test_pipe",
        )
        result = await node.execute({})

        assert result["returncode"] == 0
        assert "ABC" in result["stdout"]

    @pytest.mark.asyncio
    async def test_command_with_pipe_blocked_by_default(self) -> None:
        """测试默认情况下管道命令被阻止。"""
        with pytest.raises(SecurityError, match="危险字符"):
            CommandNode(command="echo abc | tr a-z A-Z", shell=True, id="test_pipe_blocked")

    @pytest.mark.asyncio
    async def test_command_injection_blocked(self) -> None:
        """测试命令注入被阻止。"""
        with pytest.raises(SecurityError, match="危险字符"):
            CommandNode(command="ls ; rm -rf /", shell=True, id="test_injection")

    @pytest.mark.asyncio
    async def test_failed_command(self) -> None:
        """测试执行失败的命令。"""
        node = CommandNode(command="ls /nonexistent_dir_12345", shell=True, id="test_fail")
        result = await node.execute({})

        assert result["returncode"] != 0
        assert result["success"] is False
        assert len(result["stderr"]) > 0

    @pytest.mark.asyncio
    async def test_command_with_cwd(self) -> None:
        """测试指定工作目录。"""
        node = CommandNode(command="pwd", shell=True, cwd="/tmp", id="test_cwd")
        result = await node.execute({})

        assert result["returncode"] == 0
        assert "/tmp" in result["stdout"]

    @pytest.mark.asyncio
    async def test_command_with_timeout_success(self) -> None:
        """测试超时设置（命令正常完成）。"""
        node = CommandNode(command="sleep 0.1", shell=True, timeout=2.0, id="test_timeout_ok")
        result = await node.execute({})

        assert result["returncode"] == 0
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_command_with_timeout_exceeded(self) -> None:
        """测试超时设置（命令超时）。"""
        node = CommandNode(command="sleep 5", shell=True, timeout=0.2, id="test_timeout_fail")

        with pytest.raises(asyncio.TimeoutError):
            await node.execute({})

    @pytest.mark.asyncio
    async def test_command_with_env(self) -> None:
        """测试环境变量设置。"""
        node = CommandNode(
            command="echo $MY_VAR",
            shell=True,
            env={"MY_VAR": "test_value"},
            allow_shell_injection=True,
            id="test_env",
        )
        result = await node.execute({})

        assert result["returncode"] == 0
        assert "test_value" in result["stdout"]

    def test_sync_call(self) -> None:
        """测试同步调用（__call__）- 非 async 环境。"""
        # 同步调用需要在没有 event loop 的环境中运行
        # 这里直接验证 execute 的结果
        import asyncio

        node = CommandNode(command="echo sync", shell=True, id="sync_test")
        result = asyncio.run(node.execute({}))

        assert result["success"] is True
        assert "sync" in result["stdout"]

    @pytest.mark.asyncio
    async def test_list_command_shell_false(self) -> None:
        """测试 shell=False 时使用列表形式。"""
        node = CommandNode(command=["ls", "-la"], shell=False, id="test_list")
        result = await node.execute({})

        assert result["returncode"] == 0
        assert result["success"] is True

    @pytest.mark.asyncio
    async def test_string_command_shell_false(self) -> None:
        """测试 shell=False 时使用字符串（自动 shlex.split）。"""
        node = CommandNode(command="ls -la", shell=False, id="test_str_exec")
        result = await node.execute({})

        assert result["returncode"] == 0
        assert result["success"] is True
