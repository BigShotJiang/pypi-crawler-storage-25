"""调度器单元测试。"""

import asyncio
import time

import pytest

from epscheduler.dag import DAG
from epscheduler.executors import AsyncExecutor, SyncExecutor
from epscheduler.job import create_callable_job
from epscheduler.jobstores import MemoryJobStore
from epscheduler.nodetypes import FuncNode
from epscheduler.schedulers import AsyncScheduler, BackgroundScheduler, BlockingScheduler
from epscheduler.state import JobStatus
from epscheduler.triggers import IntervalTrigger, ManualTrigger


class TestAsyncScheduler:
    """AsyncScheduler 测试类。"""

    @pytest.mark.asyncio
    async def test_add_job_with_job_instance(self) -> None:
        """测试传入 Job 实例添加作业。"""
        store = MemoryJobStore()
        executor = SyncExecutor()
        scheduler = AsyncScheduler(store, executor)

        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        job_id = await scheduler.add_job(job)
        assert job_id == "job_1"

        result = await scheduler.get_job("job_1")
        assert result is not None
        assert result.job_id == "job_1"

        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_add_job_with_fn_param(self) -> None:
        """测试直接传入参数创建 Callable 作业。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = AsyncScheduler(store, executor)

        trigger = IntervalTrigger(seconds=1)

        # 直接传入参数创建作业（关键字参数形式）
        job_id = await scheduler.add_job(
            "callable_job",
            "Callable作业",
            trigger,
            fn=lambda x, y: x + y,
            params={"x": 1, "y": 2},
            max_runs=2,
        )
        assert job_id == "callable_job"

        result = await scheduler.get_job("callable_job")
        assert result is not None
        assert result.name == "Callable作业"
        assert result.max_runs == 2
        assert result.is_callable_job()

        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_add_job_with_dag_param(self) -> None:
        """测试直接传入参数创建 DAG 作业。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = AsyncScheduler(store, executor)

        trigger = ManualTrigger()
        dag = DAG()

        node1 = FuncNode(fn=lambda: {"data": 1}, id="step1")
        dag.add_node(node1)

        # 直接传入参数创建 DAG 作业
        job_id = await scheduler.add_job(
            "dag_job",
            "DAG作业",
            trigger,
            dag=dag,
            params={"input": 100},
        )
        assert job_id == "dag_job"

        result = await scheduler.get_job("dag_job")
        assert result is not None
        assert result.name == "DAG作业"
        assert result.is_dag_job()

        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_add_job_missing_fn_or_dag(self) -> None:
        """测试缺少 fn 或 dag 参数时报错。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = AsyncScheduler(store, executor)

        trigger = ManualTrigger()

        with pytest.raises(ValueError, match="必须提供 fn 或 dag 参数"):
            await scheduler.add_job("job_1", "测试", trigger)

        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_add_job_both_fn_and_dag(self) -> None:
        """测试同时提供 fn 和 dag 时报错。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = AsyncScheduler(store, executor)

        trigger = ManualTrigger()
        dag = DAG()

        with pytest.raises(ValueError, match="fn 和 dag 不能同时提供"):
            await scheduler.add_job(
                "job_1",
                "测试",
                trigger,
                fn=lambda: 1,
                dag=dag,
            )

        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_start_and_stop(self) -> None:
        """测试启动和停止。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = AsyncScheduler(store, executor)

        assert not scheduler.is_running()

        await scheduler.start()
        assert scheduler.is_running()

        await scheduler.stop()
        assert not scheduler.is_running()

    @pytest.mark.asyncio
    async def test_execute_callable_job(self) -> None:
        """测试执行 Callable 作业。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = AsyncScheduler(store, executor)

        trigger = IntervalTrigger(seconds=1)
        job = create_callable_job(
            "test_job",
            "测试作业",
            trigger,
            lambda x, y: x + y,
            params={"x": 1, "y": 2},
        )

        await scheduler.add_job(job)
        await scheduler.start()

        await asyncio.sleep(2.5)

        result = await scheduler.get_job("test_job")
        assert result is not None
        assert result.status == JobStatus.SUCCESS
        assert result.run_count >= 1
        assert result.last_run_result == 3

        await scheduler.stop()

    @pytest.mark.asyncio
    async def test_pause_and_resume(self) -> None:
        """测试暂停和恢复。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = AsyncScheduler(store, executor)

        await scheduler.start()

        scheduler.pause()
        assert scheduler.is_paused()

        scheduler.resume()
        assert not scheduler.is_paused()

        await scheduler.stop()


class TestBlockingScheduler:
    """BlockingScheduler 测试类。"""

    def test_add_job_with_instance_blocking(self) -> None:
        """测试传入 Job 实例添加作业（阻塞调用）。"""
        store = MemoryJobStore()
        executor = SyncExecutor()
        scheduler = BlockingScheduler(store, executor)

        trigger = ManualTrigger()
        job = create_callable_job("job_1", "测试", trigger, lambda: 1)

        job_id = scheduler.add_job(job)  # 阻塞调用
        assert job_id == "job_1"

        result = scheduler.get_job("job_1")
        assert result is not None

    def test_add_job_with_fn_param_blocking(self) -> None:
        """测试直接传入参数创建 Callable 作业（阻塞调用）。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = BlockingScheduler(store, executor)

        trigger = ManualTrigger()

        # 直接传入参数创建作业
        job_id = scheduler.add_job(
            "callable_job",
            "Callable阻塞",
            trigger,
            fn=lambda: "result",
            max_runs=1,
        )
        assert job_id == "callable_job"

        result = scheduler.get_job("callable_job")
        assert result is not None
        assert result.name == "Callable阻塞"

    def test_add_job_with_dag_param_blocking(self) -> None:
        """测试直接传入参数创建 DAG 作业（阻塞调用）。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = BlockingScheduler(store, executor)

        trigger = ManualTrigger()
        dag = DAG()
        dag.add_node(FuncNode(fn=lambda: {"data": 1}, id="step1"))

        # 直接传入参数创建 DAG 作业
        job_id = scheduler.add_job("dag_job", "DAG阻塞", trigger, dag=dag)
        assert job_id == "dag_job"

        result = scheduler.get_job("dag_job")
        assert result is not None
        assert result.is_dag_job()

    def test_run_job_now_blocking(self) -> None:
        """测试立即执行（阻塞调用）。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = BlockingScheduler(store, executor)

        trigger = ManualTrigger()
        job = create_callable_job("manual_job", "手动", trigger, lambda: "result")

        scheduler.add_job(job)

        result = scheduler.run_job_now("manual_job")  # 阻塞调用
        assert result == "result"

        job_result = scheduler.get_job("manual_job")
        assert job_result is not None
        assert job_result.status == JobStatus.SUCCESS


class TestBackgroundScheduler:
    """BackgroundScheduler 测试类。"""

    def test_add_job_with_instance_background(self) -> None:
        """测试传入 Job 实例添加作业（后台调度器）。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = BackgroundScheduler(store, executor)

        trigger = IntervalTrigger(seconds=1)
        job = create_callable_job("bg_job", "后台", trigger, lambda: 1)

        scheduler.add_job(job)  # 不阻塞

        scheduler.start_background()  # 启动后台线程，不阻塞
        assert scheduler.is_running()

        # 等待作业执行
        time.sleep(3)

        result = scheduler.get_job("bg_job")
        assert result is not None
        assert result.run_count >= 1

        scheduler.stop_background()
        assert not scheduler.is_running()

    def test_add_job_with_fn_param_background(self) -> None:
        """测试直接传入参数创建 Callable 作业（后台调度器）。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = BackgroundScheduler(store, executor)

        trigger = IntervalTrigger(seconds=1)

        scheduler.start_background()

        # 直接传入参数创建作业
        job_id = scheduler.add_job(
            "callable_bg",
            "Callable后台",
            trigger,
            fn=lambda: "bg_result",
            max_runs=2,
        )
        assert job_id == "callable_bg"

        result = scheduler.get_job("callable_bg")
        assert result is not None
        assert result.name == "Callable后台"

        time.sleep(3)

        scheduler.stop_background()

    def test_add_job_with_dag_param_background(self) -> None:
        """测试直接传入参数创建 DAG 作业（后台调度器）。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = BackgroundScheduler(store, executor)

        trigger = ManualTrigger()
        dag = DAG()
        dag.add_node(FuncNode(fn=lambda: {"data": 1}, id="step1"))

        scheduler.start_background()

        # 直接传入参数创建 DAG 作业
        job_id = scheduler.add_job("dag_bg", "DAG后台", trigger, dag=dag)
        assert job_id == "dag_bg"

        result = scheduler.get_job("dag_bg")
        assert result is not None
        assert result.is_dag_job()

        scheduler.stop_background()

    def test_add_job_from_main_thread(self) -> None:
        """测试从主线程添加作业。"""
        store = MemoryJobStore()
        executor = AsyncExecutor()
        scheduler = BackgroundScheduler(store, executor)

        scheduler.start_background()

        # 从主线程添加作业（使用统一 add_job）
        scheduler.add_job(
            "main_job",
            "主线程",
            IntervalTrigger(seconds=2),
            fn=lambda: "done",
        )

        time.sleep(5)

        result = scheduler.get_job("main_job")
        assert result is not None
        assert result.run_count >= 1

        scheduler.stop_background()


class TestSchedulerComparison:
    """调度器对比测试。"""

    def test_all_schedulers_execute_job(self) -> None:
        """测试所有调度器都能执行作业（使用统一 add_job）。"""
        # AsyncScheduler - 在同步测试中用 asyncio.run
        async def test_async_scheduler() -> None:
            store1 = MemoryJobStore()
            executor1 = AsyncExecutor()
            async_scheduler = AsyncScheduler(store1, executor1)

            trigger = ManualTrigger()

            # 使用统一 add_job
            await async_scheduler.add_job("test", "测试", trigger, fn=lambda: "async_result")
            result = await async_scheduler.run_job_now("test")
            assert result == "async_result"
            await async_scheduler.stop()

        asyncio.run(test_async_scheduler())

        # BlockingScheduler - 同步调用
        store2 = MemoryJobStore()
        executor2 = AsyncExecutor()
        blocking_scheduler = BlockingScheduler(store2, executor2)

        trigger = ManualTrigger()
        blocking_scheduler.add_job("test", "测试", trigger, fn=lambda: "blocking_result")
        result = blocking_scheduler.run_job_now("test")
        assert result == "blocking_result"

        # BackgroundScheduler - 同步调用
        store3 = MemoryJobStore()
        executor3 = AsyncExecutor()
        background_scheduler = BackgroundScheduler(store3, executor3)

        background_scheduler.add_job("test", "测试", trigger, fn=lambda: "bg_result")
        background_scheduler.start_background()
        result = background_scheduler.run_job_now("test")
        assert result == "bg_result"
        background_scheduler.stop_background()
