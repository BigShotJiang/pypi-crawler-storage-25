"""执行器模块单元测试。"""

import asyncio

import pytest

from epscheduler.exceptions import JobExecutionError
from epscheduler.executors import AsyncExecutor, SyncExecutor, ThreadExecutor


class TestAsyncExecutor:
    """AsyncExecutor 测试类。"""

    @pytest.mark.asyncio
    async def test_submit_sync_function(self) -> None:
        """测试执行同步函数。"""
        executor = AsyncExecutor()

        def add(a: int, b: int) -> int:
            return a + b

        result = await executor.submit(add, 1, 2)
        assert result == 3

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_submit_async_function(self) -> None:
        """测试执行协程函数。"""
        executor = AsyncExecutor()

        async def async_add(a: int, b: int) -> int:
            await asyncio.sleep(0.01)
            return a + b

        result = await executor.submit(async_add, 1, 2)
        assert result == 3

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_submit_coroutine(self) -> None:
        """测试直接提交协程对象。"""
        executor = AsyncExecutor()

        async def async_task() -> str:
            await asyncio.sleep(0.01)
            return "done"

        coro = async_task()
        result = await executor.submit(coro)
        assert result == "done"

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_submit_with_exception(self) -> None:
        """测试执行出错抛出 JobExecutionError。"""
        executor = AsyncExecutor()

        def raise_error() -> None:
            raise ValueError("test error")

        with pytest.raises(JobExecutionError):
            await executor.submit(raise_error)

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_concurrency_limit(self) -> None:
        """测试并发限制。"""
        executor = AsyncExecutor(max_concurrency=2)

        # 记录并发执行的任务数
        concurrent_count = 0
        max_concurrent = 0

        async def track_concurrency() -> int:
            nonlocal concurrent_count, max_concurrent
            concurrent_count += 1
            max_concurrent = max(max_concurrent, concurrent_count)
            await asyncio.sleep(0.05)
            concurrent_count -= 1
            return 1

        # 提交5个任务，并发数应不超过2
        tasks = [executor.submit(track_concurrency) for _ in range(5)]
        results = await asyncio.gather(*tasks)

        assert max_concurrent <= 2
        assert sum(results) == 5

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_shutdown_wait_for_tasks(self) -> None:
        """测试关闭时等待任务完成。"""
        executor = AsyncExecutor()

        completed = False

        async def slow_task() -> None:
            await asyncio.sleep(0.1)
            nonlocal completed
            completed = True

        await executor.submit(slow_task)
        await executor.shutdown(timeout=1.0)

        assert completed

    @pytest.mark.asyncio
    async def test_shutdown_timeout(self) -> None:
        """测试关闭超时取消任务。"""
        executor = AsyncExecutor()

        async def slow_task() -> None:
            await asyncio.sleep(10)

        # 提交一个长时间任务
        await executor.submit(slow_task)

        # 等待任务开始执行
        await asyncio.sleep(0.01)

        # 短超时关闭，应该取消任务
        await executor.shutdown(timeout=0.1)

    @pytest.mark.asyncio
    async def test_is_running(self) -> None:
        """测试 is_running 方法。"""
        executor = AsyncExecutor()
        assert executor.is_running()

        await executor.shutdown()
        assert not executor.is_running()


class TestThreadExecutor:
    """ThreadExecutor 测试类。"""

    @pytest.mark.asyncio
    async def test_submit_sync_function(self) -> None:
        """测试执行同步函数。"""
        executor = ThreadExecutor(max_workers=2)

        def add(a: int, b: int) -> int:
            return a + b

        result = await executor.submit(add, 1, 2)
        assert result == 3

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_submit_async_function(self) -> None:
        """测试执行协程函数（在线程中运行事件循环）。"""
        executor = ThreadExecutor(max_workers=2)

        async def async_add(a: int, b: int) -> int:
            await asyncio.sleep(0.01)
            return a + b

        result = await executor.submit(async_add, 1, 2)
        assert result == 3

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_submit_with_exception(self) -> None:
        """测试执行出错抛出 JobExecutionError。"""
        executor = ThreadExecutor()

        def raise_error() -> None:
            raise ValueError("test error")

        with pytest.raises(JobExecutionError):
            await executor.submit(raise_error)

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_is_running(self) -> None:
        """测试 is_running 方法。"""
        executor = ThreadExecutor()
        assert executor.is_running()

        await executor.shutdown()
        assert not executor.is_running()


class TestSyncExecutor:
    """SyncExecutor 测试类。"""

    @pytest.mark.asyncio
    async def test_submit_sync_function(self) -> None:
        """测试执行同步函数。"""
        executor = SyncExecutor()

        def add(a: int, b: int) -> int:
            return a + b

        result = await executor.submit(add, 1, 2)
        assert result == 3

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_submit_async_function(self) -> None:
        """测试执行协程函数。"""
        executor = SyncExecutor()

        async def async_add(a: int, b: int) -> int:
            await asyncio.sleep(0.01)
            return a + b

        result = await executor.submit(async_add, 1, 2)
        assert result == 3

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_submit_coroutine(self) -> None:
        """测试直接提交协程对象。"""
        executor = SyncExecutor()

        async def async_task() -> str:
            await asyncio.sleep(0.01)
            return "done"

        coro = async_task()
        result = await executor.submit(coro)
        assert result == "done"

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_submit_with_exception(self) -> None:
        """测试执行出错抛出 JobExecutionError。"""
        executor = SyncExecutor()

        def raise_error() -> None:
            raise ValueError("test error")

        with pytest.raises(JobExecutionError):
            await executor.submit(raise_error)

        await executor.shutdown()

    @pytest.mark.asyncio
    async def test_is_running(self) -> None:
        """测试 is_running 方法。"""
        executor = SyncExecutor()
        assert executor.is_running()

        await executor.shutdown()
        assert not executor.is_running()


class TestExecutorComparison:
    """执行器对比测试。"""

    @pytest.mark.asyncio
    async def test_all_executors_same_result(self) -> None:
        """测试所有执行器返回相同结果。"""
        executors = [
            AsyncExecutor(),
            ThreadExecutor(max_workers=2),
            SyncExecutor(),
        ]

        def compute(x: int) -> int:
            return x * 2

        for executor in executors:
            result = await executor.submit(compute, 5)
            assert result == 10
            await executor.shutdown()

    @pytest.mark.asyncio
    async def test_all_executors_handle_async(self) -> None:
        """测试所有执行器都能处理协程。"""
        executors = [
            AsyncExecutor(),
            ThreadExecutor(max_workers=2),
            SyncExecutor(),
        ]

        async def async_compute(x: int) -> int:
            await asyncio.sleep(0.01)
            return x * 2

        for executor in executors:
            result = await executor.submit(async_compute, 5)
            assert result == 10
            await executor.shutdown()
