"""
Type definitions for MetricsFirst SDK
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Dict, Any


class InteractionType(str, Enum):
    MESSAGE = "message"
    CALLBACK_QUERY = "callback_query"
    INLINE_QUERY = "inline_query"
    COMMAND = "command"
    PHOTO = "photo"
    VIDEO = "video"
    DOCUMENT = "document"
    VOICE = "voice"
    STICKER = "sticker"
    OTHER = "other"


class ErrorSeverity(str, Enum):
    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class PurchaseStatus(str, Enum):
    INITIATED = "initiated"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"


@dataclass
class CommandEventData:
    """Data for tracking bot commands"""
    user_id: int
    command: str
    command_args: Optional[str] = None
    response_time_ms: Optional[int] = None
    is_success: bool = True
    error_message: Optional[str] = None


@dataclass
class InteractionEventData:
    """Data for tracking user interactions"""
    user_id: int
    interaction_type: InteractionType = InteractionType.MESSAGE
    content_preview: Optional[str] = None
    callback_data: Optional[str] = None
    response_time_ms: Optional[int] = None


@dataclass
class ServiceEventData:
    """Data for tracking services provided"""
    user_id: int
    service_name: str
    service_type: Optional[str] = None
    is_free: bool = True
    price: float = 0.0
    currency: str = "USD"
    duration_ms: Optional[int] = None
    is_success: bool = True
    error_message: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ErrorEventData:
    """Data for tracking errors"""
    error_type: str
    error_message: str
    user_id: Optional[int] = None
    error_stack: Optional[str] = None
    error_code: Optional[str] = None
    severity: ErrorSeverity = ErrorSeverity.ERROR
    context: Dict[str, Any] = field(default_factory=dict)


@dataclass
class PurchaseEventData:
    """Data for tracking purchases"""
    user_id: int
    purchase_id: str
    price: float
    status: PurchaseStatus = PurchaseStatus.INITIATED
    tariff_id: Optional[str] = None
    tariff_name: Optional[str] = None
    currency: str = "USD"
    is_recurrent: bool = False
    recurrence_period: Optional[str] = None  # "daily", "weekly", "monthly", "yearly"
    payment_method: Optional[str] = None
    payment_provider: Optional[str] = None
    discount_percent: float = 0.0
    coupon_code: Optional[str] = None
    error_message: Optional[str] = None
    saved_payment_method_id: Optional[str] = None  # ID of saved payment method (for recurring)
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class RecurringChargeEventData:
    """Data for tracking recurring subscription charges"""
    user_id: int
    subscription_id: str
    amount: float
    is_success: bool = True
    currency: str = "USD"
    payment_method: Optional[str] = None
    charge_attempt: int = 1
    error_code: Optional[str] = None
    error_message: Optional[str] = None
    next_retry_at: Optional[str] = None
    # Additional fields for unified purchase tracking
    purchase_id: Optional[str] = None  # External payment ID for deduplication
    tariff_id: Optional[str] = None
    tariff_name: Optional[str] = None
    saved_payment_method_id: Optional[str] = None  # ID of saved payment method (card UUID)


@dataclass
class RefundEventData:
    """Data for tracking refunds"""
    user_id: int
    refund_id: str  # YooKassa refund ID
    original_purchase_id: str  # Original payment ID that was refunded
    amount: float
    currency: str = "USD"
    reason: Optional[str] = None
    tariff_id: Optional[str] = None
    tariff_name: Optional[str] = None
    payment_method: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class UserIdentifyData:
    """Data for identifying users"""
    user_id: int
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    language_code: Optional[str] = None
    is_premium: bool = False
    properties: Dict[str, Any] = field(default_factory=dict)


# ============================================
# FUNNEL TRACKING TYPES
# For tracking anonymous users before registration
# ============================================

@dataclass
class UtmParams:
    """
    UTM parameters for attribution tracking.
    
    Example:
        utm = UtmParams(
            utm_source="google",
            utm_medium="cpc",
            utm_campaign="spring_sale"
        )
    """
    utm_source: Optional[str] = None
    utm_medium: Optional[str] = None
    utm_campaign: Optional[str] = None
    utm_term: Optional[str] = None
    utm_content: Optional[str] = None


@dataclass
class FunnelEventData:
    """
    Funnel event data for anonymous tracking.
    Use this when tracking users before they have a user_id (e.g., landing page visitors).
    
    The ad_id should be a unique identifier generated on first visit and stored
    in cookie/localStorage. Later, when the user registers, call link_identity()
    to connect their ad_id to their user_id.
    
    Example:
        # Track landing page visit
        mf.track_funnel(FunnelEventData(
            ad_id="visitor_abc123",
            event_name="page_view",
            properties={"page": "/landing"},
            utm=UtmParams(utm_source="google", utm_campaign="spring_sale")
        ))
    """
    ad_id: str
    event_name: str
    properties: Dict[str, Any] = field(default_factory=dict)
    utm: Optional[UtmParams] = None


@dataclass
class IdentityLinkData:
    """
    Identity link data for connecting anonymous ad_id to registered user_id.
    Call this when a user registers or logs in after visiting your landing page.
    
    This creates an identity_link event that allows the funnel analytics to
    connect pre-registration activity (tracked with ad_id) to the user's account.
    
    Example:
        # When user starts the bot after clicking landing page CTA
        mf.link_identity(IdentityLinkData(
            ad_id="visitor_abc123",
            user_id=123456789,
            properties={"registration_source": "landing_cta"}
        ))
    """
    ad_id: str
    user_id: int
    properties: Dict[str, Any] = field(default_factory=dict)
