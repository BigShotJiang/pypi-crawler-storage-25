"""
MetricsFirst SDK for Python
Track analytics for your Telegram bots and web funnels
"""

from .client import MetricsFirst
from .async_client import AsyncMetricsFirst
from .types import (
    ServiceEventData,
    ErrorEventData,
    ErrorSeverity,
    PurchaseEventData,
    PurchaseStatus,
    RecurringChargeEventData,
    RefundEventData,
    UserIdentifyData,
    # Funnel tracking types
    UtmParams,
    FunnelEventData,
    IdentityLinkData,
)

__version__ = "0.2.1"
__all__ = [
    "MetricsFirst",
    "AsyncMetricsFirst",
    "ServiceEventData",
    "ErrorEventData",
    "ErrorSeverity",
    "PurchaseEventData",
    "PurchaseStatus",
    "RecurringChargeEventData",
    "RefundEventData",
    "UserIdentifyData",
    # Funnel tracking types
    "UtmParams",
    "FunnelEventData",
    "IdentityLinkData",
]

