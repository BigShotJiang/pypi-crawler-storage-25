from dataclasses import dataclass

        
@dataclass
class RenderConfig:
    """
    The configuration of the rendering process,
    which includes information such as:
    - The `size` we want for the output
    - The `fps` we want for the output
    - If we want to use GPU or not
    """

    def __init__(
        self,
        size:  tuple[int, int],
        fps: float,
        audio_fps: int,
        do_use_gpu: bool
    ):
        self.size: tuple[int, int] = size
        """
        The size that will be used for the output of the
        rendering process.
        """
        self.fps: float = fps
        """
        The fps for the output of the rendering process.
        """
        self.audio_fps: int = audio_fps
        """
        The audio fps for the output of the rendering process.
        """
        self.do_use_gpu: bool = do_use_gpu
        """
        Boolean flag to indicate the intention of rendering
        by using the GPU (if `True`) or the CPU (if `False`).
        This is the intention, but it could be not available
        in the nodes about to use.
        """

    def use_cpu(
        self
    ) -> 'RenderConfig':
        """
        Activate the desire to use CPU (and not GPU) by
        setting the `do_use_gpu` parameter to `False`.
        """
        self.do_use_gpu = False

        return self

    def use_gpu(
        self
    ) -> 'RenderConfig':
        """
        Activate the desire to use GPU (and no CPU) by
        setting the `do_use_gpu` parameter to `True`.
        """
        self.do_use_gpu = True

        return self