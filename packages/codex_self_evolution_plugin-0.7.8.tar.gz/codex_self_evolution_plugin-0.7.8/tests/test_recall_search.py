import json

from codex_self_evolution.recall.search import search_recall
from codex_self_evolution.recall.workflow import (
    build_focused_recall,
    evaluate_recall_trigger,
    evaluate_session_recall,
    render_focused_recall_markdown,
)
from codex_self_evolution.storage import repo_fingerprint



def test_recall_search_ranks_same_repo_and_cwd_first(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    state = tmp_path / "state"
    recall_dir = state / "recall"
    recall_dir.mkdir(parents=True)
    recall_dir.joinpath("index.json").write_text(
        json.dumps(
            {
                "records": [
                    {
                        "id": "same-repo",
                        "summary": "pytest workflow",
                        "content": "Run focused pytest first",
                        "source_paths": ["tests/test_x.py"],
                        "repo_fingerprint": repo_fingerprint(repo),
                        "cwd": str(repo),
                    },
                    {
                        "id": "global",
                        "summary": "generic workflow",
                        "content": "Use rg for search",
                        "source_paths": ["README.md"],
                        "repo_fingerprint": "other",
                        "cwd": "/elsewhere",
                    },
                ]
            }
        ),
        encoding="utf-8",
    )
    results = search_recall(query="pytest workflow", cwd=repo, state_dir=state)
    assert results[0]["id"] == "same-repo"



def test_recall_trigger_and_focused_recall_helpers(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    state = tmp_path / "state"
    recall_dir = state / "recall"
    recall_dir.mkdir(parents=True)
    recall_dir.joinpath("index.json").write_text(
        json.dumps(
            {
                "records": [
                    {
                        "id": "same-repo",
                        "summary": "pytest workflow",
                        "content": "Run focused pytest first",
                        "source_paths": ["tests/test_x.py"],
                        "repo_fingerprint": repo_fingerprint(repo),
                        "cwd": str(repo),
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    trigger = evaluate_recall_trigger("remember previous pytest workflow")
    assert trigger["triggered"] is True
    focused = build_focused_recall("pytest workflow", cwd=repo, state_dir=state)
    assert "pytest workflow" in focused["focused_recall"]
    markdown = render_focused_recall_markdown(focused)
    assert markdown.startswith("## Focused Recall")
    assert "Status: matched" in markdown
    assert "Run focused pytest first" in markdown


def test_session_recall_bridge_uses_injected_skill_and_policy(tmp_path):
    repo = tmp_path / "repo"
    repo.mkdir()
    state = tmp_path / "state"
    recall_dir = state / "recall"
    recall_dir.mkdir(parents=True)
    recall_dir.joinpath("index.json").write_text(
        json.dumps(
            {
                "records": [
                    {
                        "id": "same-repo",
                        "summary": "pytest workflow",
                        "content": "Run focused pytest first",
                        "source_paths": ["tests/test_x.py"],
                        "repo_fingerprint": repo_fingerprint(repo),
                        "cwd": str(repo),
                    }
                ]
            }
        ),
        encoding="utf-8",
    )
    session_payload = {
        "recall": {
            "policy": "Recall is available when current turn references previous workflow context.",
            "skill": {
                "skill_id": "session_recall",
                "content": "Trigger recall on remember/previous cues and prefer same-repo, then same-cwd, then global fallback.",
            },
        }
    }
    result = evaluate_session_recall(
        query="remember previous pytest workflow",
        cwd=repo,
        state_dir=state,
        session_payload=session_payload,
    )
    assert result["triggered"] is True
    assert result["skill_id"] == "session_recall"
    assert result["results"][0]["id"] == "same-repo"


def test_focused_recall_markdown_soft_fails_on_empty_result():
    markdown = render_focused_recall_markdown({"query": "missing topic", "count": 0, "results": []})
    assert "Status: no_match" in markdown
    assert "Do not invent prior context" in markdown
