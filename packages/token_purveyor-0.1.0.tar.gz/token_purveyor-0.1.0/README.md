# token_purveyor

Drop-in LLM cost tracker, deduplicator, cluster analyzer, and optimizer. One line of setup.
```python
import openai
from token_purveyor import CostAwareClient

client = CostAwareClient(openai.OpenAI())
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello"}],
)
```