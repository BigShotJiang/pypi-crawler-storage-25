"""
token_purveyor.pricing
~~~~~~~~~~~~~~~~~~~~~~
Accurate hardcoded OpenAI pricing + capability matrix.
Source: OpenAI pricing page (2025-Q1).

Priority chain (highest → lowest):
  1. Fresh disk cache  (< ttl_hours old)
  2. Network fetch     (LiteLLM registry on GitHub)
  3. Stale disk cache  (any age, used when offline)
  4. This hardcoded dict (always works, no network)
"""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from token_purveyor.models import PricingEntry

if TYPE_CHECKING:
    from token_purveyor.config import TokenPurveyorConfig

logger = logging.getLogger("token_purveyor")

LITELLM_PRICING_URL = (
    "https://raw.githubusercontent.com/BerriAI/litellm/main/"
    "model_prices_and_context_window.json"
)

# ---------------------------------------------------------------------------
# Canonical pricing + capability data  (per-token USD, accurate 2025-Q1)
# ---------------------------------------------------------------------------
_REGISTRY: dict[str, dict] = {
    # ── GPT-4o family ─────────────────────────────────────────────────────
    "gpt-4o": {
        "input_cost_per_token": 2.50e-6,
        "output_cost_per_token": 10.00e-6,
        "context_window": 128_000,
        "quality_score": 5,
        "speed_score": 4,
        "cost_tier": 3,
        "supports_vision": True,
        "supports_functions": True,
        "best_for": ["complex_reasoning", "vision", "code", "analysis", "creative"],
    },
    # gpt-4o-2024-05-13 had higher pricing before the July 2024 price cut
    "gpt-4o-2024-05-13": {
        "input_cost_per_token": 5.00e-6,
        "output_cost_per_token": 15.00e-6,
        "context_window": 128_000,
        "quality_score": 5,
        "speed_score": 4,
        "cost_tier": 4,
        "supports_vision": True,
        "supports_functions": True,
        "best_for": ["complex_reasoning", "vision", "code"],
    },
    "gpt-4o-mini": {
        "input_cost_per_token": 0.150e-6,
        "output_cost_per_token": 0.600e-6,
        "context_window": 128_000,
        "quality_score": 3,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": True,
        "supports_functions": True,
        "best_for": [
            "simple_qa",
            "classification",
            "extraction",
            "chat",
            "summarization",
        ],
    },
    # ── o1 family ─────────────────────────────────────────────────────────
    "o1": {
        "input_cost_per_token": 15.00e-6,
        "output_cost_per_token": 60.00e-6,
        "context_window": 200_000,
        "quality_score": 5,
        "speed_score": 1,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["math", "complex_reasoning", "research", "science"],
    },
    "o1-mini": {
        "input_cost_per_token": 3.00e-6,
        "output_cost_per_token": 12.00e-6,
        "context_window": 128_000,
        "quality_score": 4,
        "speed_score": 2,
        "cost_tier": 3,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["math", "coding", "reasoning"],
    },
    "o1-preview": {
        "input_cost_per_token": 15.00e-6,
        "output_cost_per_token": 60.00e-6,
        "context_window": 128_000,
        "quality_score": 5,
        "speed_score": 1,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["math", "complex_reasoning"],
    },
    # ── o3 family ─────────────────────────────────────────────────────────
    "o3-mini": {
        "input_cost_per_token": 1.10e-6,
        "output_cost_per_token": 4.40e-6,
        "context_window": 200_000,
        "quality_score": 4,
        "speed_score": 3,
        "cost_tier": 2,
        "supports_vision": False,
        "supports_functions": True,
        "best_for": ["coding", "math", "reasoning", "science"],
    },
    "o3": {
        "input_cost_per_token": 10.00e-6,
        "output_cost_per_token": 40.00e-6,
        "context_window": 200_000,
        "quality_score": 5,
        "speed_score": 1,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["math", "research", "complex_reasoning"],
    },
    # ── GPT-4 Turbo ───────────────────────────────────────────────────────
    "gpt-4-turbo": {
        "input_cost_per_token": 10.00e-6,
        "output_cost_per_token": 30.00e-6,
        "context_window": 128_000,
        "quality_score": 4,
        "speed_score": 3,
        "cost_tier": 4,
        "supports_vision": True,
        "supports_functions": True,
        "best_for": ["complex_reasoning", "code", "analysis", "vision"],
    },
    # ── GPT-4 (legacy) ────────────────────────────────────────────────────
    "gpt-4": {
        "input_cost_per_token": 30.00e-6,
        "output_cost_per_token": 60.00e-6,
        "context_window": 8_192,
        "quality_score": 4,
        "speed_score": 2,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": True,
        "best_for": ["complex_reasoning", "code"],
    },
    "gpt-4-32k": {
        "input_cost_per_token": 60.00e-6,
        "output_cost_per_token": 120.00e-6,
        "context_window": 32_768,
        "quality_score": 4,
        "speed_score": 2,
        "cost_tier": 5,
        "supports_vision": False,
        "supports_functions": True,
        "best_for": ["long_document_analysis"],
    },
    # ── GPT-3.5 Turbo ─────────────────────────────────────────────────────
    "gpt-3.5-turbo": {
        "input_cost_per_token": 0.50e-6,
        "output_cost_per_token": 1.50e-6,
        "context_window": 16_385,
        "quality_score": 2,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": False,
        "supports_functions": True,
        "best_for": ["simple_chat", "classification", "simple_extraction"],
    },
    "gpt-3.5-turbo-instruct": {
        "input_cost_per_token": 1.50e-6,
        "output_cost_per_token": 2.00e-6,
        "context_window": 4_096,
        "quality_score": 2,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["simple_completion", "legacy_apps"],
    },
    # ── Embedding models ──────────────────────────────────────────────────
    "text-embedding-3-small": {
        "input_cost_per_token": 0.020e-6,
        "output_cost_per_token": 0.0,
        "context_window": 8_191,
        "quality_score": 3,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["embeddings", "search", "clustering"],
    },
    "text-embedding-3-large": {
        "input_cost_per_token": 0.130e-6,
        "output_cost_per_token": 0.0,
        "context_window": 8_191,
        "quality_score": 5,
        "speed_score": 4,
        "cost_tier": 2,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["embeddings", "semantic_search", "high_accuracy"],
    },
    "text-embedding-ada-002": {
        "input_cost_per_token": 0.100e-6,
        "output_cost_per_token": 0.0,
        "context_window": 8_191,
        "quality_score": 2,
        "speed_score": 5,
        "cost_tier": 1,
        "supports_vision": False,
        "supports_functions": False,
        "best_for": ["embeddings", "legacy_apps"],
    },
}

# Maps date-versioned names to their canonical model.
# gpt-4o-2024-05-13 is intentionally NOT here since it has different pricing.
_CANONICAL_MAP: dict[str, str] = {
    "gpt-4o-2024-11-20": "gpt-4o",
    "gpt-4o-2024-08-06": "gpt-4o",
    "gpt-4o-mini-2024-07-18": "gpt-4o-mini",
    "o1-2024-12-17": "o1",
    "o1-mini-2024-09-12": "o1-mini",
    "o1-preview-2024-09-12": "o1-preview",
    "gpt-4-turbo-2024-04-09": "gpt-4-turbo",
    "gpt-4-turbo-preview": "gpt-4-turbo",
    "gpt-4-0125-preview": "gpt-4-turbo",
    "gpt-4-1106-preview": "gpt-4-turbo",
    "gpt-4-0613": "gpt-4",
    "gpt-4-0314": "gpt-4",
    "gpt-4-32k-0613": "gpt-4-32k",
    "gpt-3.5-turbo-0125": "gpt-3.5-turbo",
    "gpt-3.5-turbo-1106": "gpt-3.5-turbo",
    "gpt-3.5-turbo-0613": "gpt-3.5-turbo",
    "gpt-3.5-turbo-16k": "gpt-3.5-turbo",
    "gpt-3.5-turbo-16k-0613": "gpt-3.5-turbo",
}

# Regex to strip trailing date stamps (e.g. -2024-08-06 or -20241120)
_DATE_SUFFIX_RE = re.compile(r"-\d{4}-\d{2}-\d{2}$|-\d{8}$")


def resolve_model(model: str) -> str:
    """Resolve a model name to its canonical form via alias map + suffix stripping."""
    if model in _REGISTRY:
        return model
    if model in _CANONICAL_MAP:
        return _CANONICAL_MAP[model]
    stripped = _DATE_SUFFIX_RE.sub("", model)
    if stripped in _REGISTRY:
        return stripped
    if stripped in _CANONICAL_MAP:
        return _CANONICAL_MAP[stripped]
    return model  # return as-is; caller handles missing


def _build_pricing_dict() -> dict[str, PricingEntry]:
    result: dict[str, PricingEntry] = {}
    for model_id, data in _REGISTRY.items():
        result[model_id] = PricingEntry(model=model_id, **data)
    return result


def _parse_litellm_response(raw: dict) -> dict[str, PricingEntry]:
    """Extract OpenAI-provider entries from the LiteLLM pricing JSON."""
    result: dict[str, PricingEntry] = {}
    for model_id, data in raw.items():
        if not isinstance(data, dict):
            continue
        if data.get("litellm_provider") != "openai":
            continue
        inp = data.get("input_cost_per_token")
        out = data.get("output_cost_per_token")
        ctx = data.get("max_tokens") or data.get("max_input_tokens", 4096)
        if inp is None:
            continue
        try:
            # LiteLLM doesn't have quality/speed scores — fall back to ours
            base = _REGISTRY.get(resolve_model(model_id), {})
            result[model_id] = PricingEntry(
                model=model_id,
                input_cost_per_token=float(inp),
                output_cost_per_token=float(out or 0),
                context_window=int(ctx),
                quality_score=base.get("quality_score", 3),
                speed_score=base.get("speed_score", 3),
                cost_tier=base.get("cost_tier", 3),
                supports_vision=bool(base.get("supports_vision", False)),
                supports_functions=bool(base.get("supports_functions", False)),
                best_for=base.get("best_for", []),
            )
        except (ValueError, TypeError):
            continue
    return result


def _load_cache(
    cache_path: Path, ttl_hours: int, *, ignore_ttl: bool = False
) -> dict[str, PricingEntry] | None:
    if not cache_path.exists():
        return None
    try:
        raw = json.loads(cache_path.read_text(encoding="utf-8"))
        fetched_at = datetime.fromisoformat(raw["fetched_at"])
        if not ignore_ttl:
            if datetime.now(timezone.utc) - fetched_at > timedelta(hours=ttl_hours):
                return None
        return {k: PricingEntry(**v) for k, v in raw["pricing"].items()}
    except Exception as exc:
        logger.warning(f"[token_purveyor] Cannot read pricing cache ({exc})")
        return None


def _save_cache(cache_path: Path, pricing: dict[str, PricingEntry]) -> None:
    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "fetched_at": datetime.now(timezone.utc).isoformat(),
            "pricing": {k: v.model_dump() for k, v in pricing.items()},
        }
        cache_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except Exception as exc:
        logger.warning(f"[token_purveyor] Cannot save pricing cache: {exc}")


def fetch_pricing(
    config: "TokenPurveyorConfig",
    *,
    force_refresh: bool = False,
) -> dict[str, PricingEntry]:
    if not force_refresh:
        cached = _load_cache(config.pricing_cache_path, config.pricing_cache_ttl_hours)
        if cached:
            return cached

    try:
        import httpx

        with httpx.Client(timeout=10.0) as http:
            resp = http.get(LITELLM_PRICING_URL)
            resp.raise_for_status()
            pricing = _parse_litellm_response(resp.json())
            if pricing:
                _save_cache(config.pricing_cache_path, pricing)
                logger.info(
                    f"[token_purveyor] Pricing refreshed: {len(pricing)} models."
                )
                return pricing
    except Exception as exc:
        logger.warning(
            f"[token_purveyor] Pricing fetch failed ({exc}). Using local data."
        )

    stale = _load_cache(config.pricing_cache_path, 0, ignore_ttl=True)
    if stale:
        logger.warning("[token_purveyor] Using stale pricing cache.")
        return stale

    logger.warning(
        "[token_purveyor] Using hardcoded pricing. Run `token_purveyor update-prices`."
    )
    return _build_pricing_dict()
