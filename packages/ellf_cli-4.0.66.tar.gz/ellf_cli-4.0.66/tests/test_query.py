"""Tests for ellf_cli.query — helper functions that don't need auth."""

from __future__ import annotations

from ellf_cli.query import get_not_found_error


class TestGetNotFoundError:
    def test_task(self):
        err = get_not_found_error("task")
        assert err.__name__ == "TaskNotFound"

    def test_action(self):
        err = get_not_found_error("action")
        assert err.__name__ == "ActionNotFound"

    def test_project(self):
        err = get_not_found_error("project")
        assert err.__name__ == "ProjectNotFound"

    def test_cluster(self):
        err = get_not_found_error("cluster")
        assert err.__name__ == "ClusterNotFound"

    def test_dataset(self):
        err = get_not_found_error("dataset")
        assert err.__name__ == "DatasetNotFound"

    def test_secret(self):
        err = get_not_found_error("secret")
        assert err.__name__ == "SecretNotFound"

    def test_cluster_path(self):
        err = get_not_found_error("cluster_path")
        assert err.__name__ == "ClusterPathNotFound"
