"""Tests for ellf_cli.ty — ClusterStatusCheck enum."""

from __future__ import annotations

from ellf_cli.ty import ClusterStatusCheck


class TestClusterStatusCheck:
    def test_values(self):
        assert ClusterStatusCheck.CREATING == "creating"
        assert ClusterStatusCheck.RUNNING == "running"
        assert ClusterStatusCheck.NOT_FOUND == "not_found"
        assert ClusterStatusCheck.INVALID_ADDRESS == "invalid_address"
        assert ClusterStatusCheck.REQUEST_ERROR == "request_error"
        assert ClusterStatusCheck.RESPONSE_ERROR == "response_error"
        assert ClusterStatusCheck.ISSUES == "issues"

    def test_str(self):
        assert str(ClusterStatusCheck.RUNNING) == "running"
        assert str(ClusterStatusCheck.CREATING) == "creating"

    def test_from_value(self):
        assert ClusterStatusCheck("running") == ClusterStatusCheck.RUNNING
