<!-- This file is auto-generated -->

# Ellf CLI

Before using Ellf CLI you need to have an **Ellf** account. You also need a deployed cluster and Python 3.6+. To see all available commands or subcommands, you can use the `--help` flag, e.g. `ellf --help`.

## `ellf`

Ellf Command Line Interface.

### `ellf actions`

Interact with actions on the cluster

#### `ellf actions create`

Create a new action. The available action recipes are fetched from your cluster and are added as dynamic subcommands. You can see more details and available arguments by calling the subcommand with --help, e.g. create [name] --help

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--no-start` | `bool` | Don't start {noun} after creation | `False` |
| `--no-wait` | `bool` | Don't wait for the action to be ready after starting | `False` |
| `--help`, `-h` | `bool` | Show help message | `False` |
| `_extra` | `str` |  | `[]` |

#### `ellf actions list`

List the actions on the cluster. By default, this includes their ID, name and current state, e.g. created or completed

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'cluster_id', 'name', 'project_id', 'job_type', 'plan', 'cli_command', 'stats', 'state'] | `['id', 'name', 'state', 'project_name']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf actions info`

Print information about an action on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the action |  |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'cluster_id', 'name', 'project_id', 'job_type', 'plan', 'cli_command', 'stats', 'recipe_name', 'recipe_title', 'evaluation', 'project_name', 'error', 'executions', 'last_execution_id', 'url_logs', 'url', 'related_tasks', 'created_by_user'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf actions logs`

Get logs for an action on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the action (or the last action if not set) | `None` |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--errors` | `bool` | Show structured error information instead of full logs | `False` |
| `--query` | `str` | Filter log lines matching this text (requires Loki) | `None` |

#### `ellf actions start`

Start an action on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the action (or the last action if not set) | `None` |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--worker-class` | `str` | Worker class to launch the action on. Generally one of: ['medium', 'large', 'gpu'] | `None` |
| `--no-wait` | `bool` | Don't wait for the action to be ready after starting | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf actions stop`

Stop an action on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the action (or the last action if not set) | `None` |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf actions delete`

Delete an Action by name or ID

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the action |  |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf todo`

Manage todos for handoff between web assistant and local Claude Code

#### `ellf todo list`

List todos

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `project_id` | `UUID` | Filter by project | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'project_id', 'conversation_id', 'creator_id', 'assigned_to', 'description', 'context_summary', 'resolution', 'status'] | `['id', 'project_id', 'status', 'description']` |
| `--status` | `Status` | Filter by status | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf todo info`

Get detailed info for a todo

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `id` | `UUID` | ID of the todo |  |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'project_id', 'conversation_id', 'creator_id', 'assigned_to', 'description', 'context_summary', 'resolution', 'status'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf todo pull`

Pull planned todos and mark them as in-progress

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `project_id` | `UUID` | Filter by project | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf todo latest`

Get the most recently updated non-done todo.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf todo context`

Fetch conversation messages for a todo's linked conversation.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `id` | `UUID` | ID of the todo |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf todo update`

Update a todo

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `id` | `UUID` | ID of the todo |  |
| `--status` | `str` | New status (planned, in_progress, done, cancelled) | `None` |
| `--description` | `str` | New description for the todo | `None` |
| `--resolution` | `str` | What was done (or why nothing was done). Set when closing a todo. | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf todo delete`

Delete a todo

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `id` | `UUID` | ID of the todo |  |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf agents`

Interact with agents on the cluster

#### `ellf agents create`

Create a new agent. The available agent recipes are fetched from your cluster and are added as dynamic subcommands. You can see more details and available arguments by calling the subcommand with --help, e.g. create [name] --help

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--no-start` | `bool` | Don't start {noun} after creation | `False` |
| `--no-wait` | `bool` | Don't wait for the agent to be ready after starting | `False` |
| `--help`, `-h` | `bool` | Show help message | `False` |
| `_extra` | `str` |  | `[]` |

#### `ellf agents assign`

Assign an agent to a task as an annotator

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the agent |  |
| `--task` | `Union[str, UUID]` | Task name or ID to assign the agent to |  |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf agents list`

List the agents on the cluster. By default, this includes their ID, name and current state, e.g. created or completed

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'cluster_id', 'name', 'project_id', 'job_type', 'plan', 'cli_command', 'state'] | `['id', 'name', 'state', 'project_name']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf agents info`

Print information about an agent on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the agent |  |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'cluster_id', 'name', 'project_id', 'job_type', 'plan', 'cli_command', 'recipe_name', 'recipe_title', 'project_name', 'error', 'last_execution_id', 'related_tasks', 'created_by_user'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf agents logs`

Get logs for an agent on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the agent (or the last agent if not set) | `None` |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--errors` | `bool` | Show structured error information instead of full logs | `False` |
| `--query` | `str` | Filter log lines matching this text (requires Loki) | `None` |

#### `ellf agents start`

Start an agent on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the agent (or the last agent if not set) | `None` |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--worker-class` | `str` | Worker class to launch the agent on. Generally one of: ['medium', 'large', 'gpu'] | `None` |
| `--no-wait` | `bool` | Don't wait for the agent to be ready after starting | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf agents stop`

Stop an agent on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the agent (or the last agent if not set) | `None` |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf agents delete`

Delete an agent by name or ID

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the agent |  |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf assets`

View and manage assets on the cluster

#### `ellf assets list`

List all assets on the cluster registered with Ellf

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster-id` | `UUID` | ID of the cluster to search for asset name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'cluster_id', 'name', 'version', 'kind', 'path', 'meta'] | `['id', 'name', 'kind']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf assets info`

Get detailed info for an asset uploaded to the cluster and registered with Ellf

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the asset |  |
| `project_id` | `UUID` | ID of asset's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for asset name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'cluster_id', 'name', 'version', 'kind', 'path', 'meta', 'tasks', 'actions'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf assets create`

Create an asset on the cluster and register it with Ellf. Assets point to files or directories you control. The Ellf server only has a reference to them. This command doesn't transfer any data. See `ellf files` for utilities to transfer files to and from your cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the asset |  |
| `--kind` | `str` | Kind of the asset. Generally one of: ['Input', 'Model', 'Patterns] |  |
| `path` | `str` | Path of the asset |  |
| `--version` | `str` | Version of the asset | `'0.0.0'` |
| `--meta` | `str` | Asset meta, formatted as a JSON string | `'{}'` |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf assets delete`

Delete an asset registered with Ellf

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the asset |  |
| `project_id` | `UUID` | ID of asset's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for asset name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf clusters`

Interact with clusters

#### `ellf clusters list`

List resources on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'name', 'address', 'state'] | `['id', 'name', 'status', 'address']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf clusters info`

Get detailed info for a cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the cluster |  |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'name', 'address', 'state', 'cloud'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf clusters update`

Update the cluster info

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the cluster |  |
| `--new-name` | `str` | New name of the cluster | `None` |
| `--address` | `str` | New address of the cluster | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf clusters delete`

Delete a cluster from PAM. This only removes PAM's record of it. The cluster itself will continue to exist - you need to shut it down separately.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the cluster |  |

#### `ellf clusters check`

Check the health of a cluster deployment. Runs CLI-side connectivity checks against the cluster and PAM. Use --deep to also trigger cluster-side deployment checks (K8s API, NFS, database, etc.).

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster` | `str` | Name or ID of the cluster | `None` |
| `--s3-bucket` | `str` | Run checks involving the S3 storage | `None` |
| `--nfs-path` | `str` | Run checks involving the NFS storage | `None` |
| `--recipe` | `str` | Run checks that need to operate over a recipe. This argument only makes sense when used with --recipe-args | `None` |
| `--recipe-args` | `str` | Run checks that need to operate over a recipe. This argument only makes sense when used with --recipe | `None` |
| `--deep` | `bool` | Run cluster-side deployment checks (K8s, NFS, DB) | `False` |

#### `ellf clusters nodes`

List cluster nodes with capacity and utilization.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['name', 'status', 'cpu', 'memory', 'gpu', 'pod_count'] | `['name', 'status', 'cpu', 'memory', 'gpu', 'pod_count']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf clusters rotate-key`

Rotate the cluster RSA keypair. Generates a new keypair, updates the cluster record in PAM with the new public key, patches the K8s secret with the new private key, and restarts the cluster deployment.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster` | `str` | Name or ID of the cluster | `None` |
| `--infra-secret` | `str` | Name of the K8s secret holding ELLF_PRIVATE_KEY | `'ellf-infra'` |
| `--namespace` | `str` | K8s namespace | `'ellf'` |

#### `ellf clusters settings`

Show cluster settings (auto-update, cleanup, target versions).

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster` | `str` | Name or ID of the cluster | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf clusters settings-update`

Update cluster settings.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster` | `str` | Name or ID of the cluster | `None` |
| `--auto-update-cluster` | `bool` | Enable/disable auto-update for cluster | `False` |
| `--auto-update-cpl` | `bool` | Enable/disable auto-update for CPL | `False` |
| `--auto-update-recipes` | `bool` | Enable/disable auto-update for recipes | `False` |
| `--cleanup-orphaned-jobs` | `bool` | Enable/disable cleanup of orphaned jobs | `False` |
| `--target-cluster-version` | `str` | Set target cluster version to install | `None` |
| `--target-cpl-version` | `str` | Set target CPL version to install | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf clusters releases`

List available releases.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf config`

Configure the CLI

#### `ellf config reset`

Reset all caching and configuration.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf config project`

Set the default project.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the project |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf config task`

Set the default task.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the task |  |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf config action`

Set the default action.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the action |  |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf config agent`

Set the default agent.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the agent |  |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf config set-cluster-host`

Set the cluster cluster host.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `host` | `str` | Host or URL of the cluster |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf config set-pam-host`

Set the PAM host.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `host` | `str` | Host or URL of the Prodigy Annotation Manager (PAM) app |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf config set-recipes-file`

Set or clear a local recipes file for PAM-free recipe discovery.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `path` | `str` | Path to a local recipes YAML file | `None` |
| `--clear` | `bool` | Clear the recipes file setting | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf datasets`

View and manage Prodigy datasets on the cluster

#### `ellf datasets list`

List all Datasets

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster-id` | `UUID` | ID of the cluster to search for dataset name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'cluster_id', 'kind'] | `['id', 'name', 'kind']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf datasets info`

Get detailed info for a Dataset

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the dataset |  |
| `cluster_id` | `UUID` | ID of the cluster to search for dataset name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'cluster_id', 'kind', 'tasks', 'actions'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf datasets create`

Create a new dataset

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the dataset |  |
| `--kind` | `str` | Kind of the dataset, used to filter in recipes to only allow specific types |  |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf datasets delete`

Delete a dataset

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the dataset |  |
| `cluster_id` | `UUID` | ID of the cluster to search for dataset name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf datasets export`

Export all the examples from a dataset and save it in the designated file as JSONL (newline-delimited JSON).

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the dataset |  |
| `--output`, `-o` | `str` | JSON output path for data | `'-'` |

### `ellf files`

Manage files on the cluster. Your files are only ever sent to servers or buckets you control. They are never sent to our servers.

#### `ellf files cp`

Copy files to and from the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `str` | Remote or local path of the source |  |
| `dest` | `str` | Remote or local path of the destination |  |
| `--recurse`, `-r` | `bool` | Copy whole directory recursively | `False` |
| `--make-dirs` | `bool` | Create parent directories if they don't exist | `False` |
| `--overwrite` | `bool` | Overwrite if exists | `False` |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf files ls`

List the files under `remote`

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `remote` | `str` | Remote location path |  |
| `--recurse`, `-r` | `bool` | List files recursively | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--expand-path-aliases` | `bool` | Expand path aliases when displaying remote paths | `False` |

#### `ellf files rm`

Remove files from the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `remote_path` | `str` | Remote location path |  |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--missing-ok` | `bool` | If missing, don't raise an error | `False` |
| `--recurse`, `-r` | `bool` | Delete the whole directory recursively | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf files rsync`

Rsync files to and from the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `str` | Remote or local path of the source |  |
| `dest` | `str` | Remote or local path of the destination |  |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf files stats`

Get the stats for a file located in `remote_path`

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `remote_path` | `str` | Remote location path |  |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf gcp`

Configure, deploy and monitor cloud resources under your Google Cloud account

### `ellf jobs`

Run jobs directly on the cluster

#### `ellf jobs run`

Run a job directly on the cluster from a YAML spec file, bypassing PAM.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `spec_path` | `str` | Path to a YAML job spec file |  |

### `ellf packages`

View and manage Python packages on the cluster

#### `ellf packages list`

List all packages

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'version', 'container', 'recipe_count'] | `['id', 'name', 'version', 'recipe_count', 'num_used_by']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf packages info`

Get detailed info for a package

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the package |  |
| `cluster_id` | `UUID` | ID of the cluster to search for package name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'version', 'container', 'recipe_count', 'org_id', 'cluster_id', 'filename', 'meta', 'tasks', 'actions', 'author'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf packages create`

Create a new package

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the package |  |
| `--kind` | `str` | Kind of the package, used to filter in recipes to only allow specific types |  |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf packages delete`

Delete a package

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the package |  |
| `cluster_id` | `UUID` | ID of the cluster to search for package name (or the last cluster if not set) | `None` |
| `--force` | `bool` | Delete related actions or tasks as well | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf plans`

Manage project plans

#### `ellf plans list`

List all plans for a project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `project_id` | `UUID` | ID of plan's project (or the last project if not set) |  |
| `--name` | `str` | Filter by name (substring) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf plans read`

Read a plan for a project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Plan name or UUID (defaults to 'project_plan') | `None` |
| `project_id` | `UUID` | ID of plan's project (or the last project if not set) | `None` |
| `--version` | `int` | Specific revision to read (default: head) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf plans write`

Create or update a plan for a project (upsert)

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Plan name or UUID (defaults to 'project_plan') | `None` |
| `project_id` | `UUID` | ID of plan's project (or the last project if not set) | `None` |
| `--content` | `str` | Plan content (markdown). Use --file to read from a file. | `None` |
| `--file` | `Path` | Path to a file containing the plan content | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf plans revisions`

List revisions for a plan, newest first

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Plan name or UUID |  |
| `project_id` | `UUID` | ID of plan's project (or the last project if not set) | `None` |
| `--size` | `int` | Page size (1-100) | `50` |
| `--after` | `UUID` | Cursor returned by a previous page | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf plans delete`

Delete a plan

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Plan name or UUID |  |
| `project_id` | `UUID` | ID of plan's project (or the last project if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf paths`

View and manage path aliases on the cluster

#### `ellf paths list`

List all cluster path aliases

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'cluster_id', 'name', 'path'] | `['created', 'id', 'name', 'path']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf paths info`

Get detailed info for a path alias

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the path |  |
| `cluster_id` | `UUID` | ID of the cluster to search for path name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'cluster_id', 'name', 'path'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf paths create`

Create a new path alias

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the path |  |
| `path` | `str` | Path of the cluster directory |  |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf paths delete`

Delete a path alias

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the path |  |
| `cluster_id` | `UUID` | ID of the cluster to search for path name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf projects`

View and manage Ellf projects

#### `ellf projects list`

List all projects

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'name', 'description', 'default_job_name_template'] | `['id', 'name']` |
| `--name` | `str` | Filter by name | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf projects info`

Get detailed info for a project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the project |  |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'name', 'description', 'default_job_name_template'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf projects create`

Create a new project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the project |  |
| `description` | `str` | Description of the project |  |
| `--default-job-name-template` | `str` | Default name template for new jobs (e.g. '{recipe}_{date}') | `None` |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf projects update`

Update a project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the project |  |
| `--name` | `str` | New name for the project | `None` |
| `--description` | `str` | New description for the project | `None` |
| `--default-job-name-template` | `str` | Default name template for new jobs (e.g. '{recipe}_{date}') | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf projects delete`

Delete a project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the project |  |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf recipes`

View and manage annotation recipe packages on the cluster

#### `ellf recipes list`

List all recipes

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'package_id', 'name', 'title', 'description', 'job_type', 'is_action', 'is_latest', 'entry_point'] | `['id', 'name', 'package']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf recipes export`

Export recipes from the cluster to a local YAML or JSON file.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `output_path` | `str` | Output path for the recipes file |  |
| `--json` | `bool` | Write JSON instead of YAML | `False` |

#### `ellf recipes info`

Show info about a recipe

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the recipe |  |
| `cluster_id` | `UUID` | ID of the cluster to search for recipe name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'package_id', 'name', 'title', 'description', 'job_type', 'is_action', 'is_latest', 'entry_point', 'form_schema', 'cli_schema', 'meta', 'tasks', 'actions', 'package'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf recipes init`

Generate a new recipes Python package

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `output_dir` | `Path` | Output directory for the recipe package |  |
| `--name` | `str` | Name of the package (e.g. custom_recipes) | `None` |
| `--version` | `str` | Version of the package | `'0.1.0'` |
| `--description` | `str` | Description of the package | `''` |
| `--author` | `str` | Name of the package author | `''` |
| `--email` | `str` | Email of the package author | `''` |
| `--url` | `str` | URL of the package | `''` |
| `--license` | `str` | License of the package | `''` |

### `ellf secrets`

View and manage named pointers to secrets on the cluster

#### `ellf secrets list`

List all named pointers to secrets on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster-id` | `UUID` | ID of the cluster to search for secret name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'cluster_id'] | `['created', 'id', 'name']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf secrets info`

Show info about a secret on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the secret |  |
| `cluster_id` | `UUID` | ID of the cluster to search for secret name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'cluster_id'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf secrets create`

Create a secret on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the secret |  |
| `--value` | `str` | The secret value. Omit to be prompted interactively. | `None` |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf secrets delete`

Delete a secret by name or ID

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the secret |  |
| `cluster_id` | `UUID` | ID of the cluster to search for secret name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf tasks`

Interact with annotation tasks on the cluster

#### `ellf tasks create`

Create a new task. The available task recipes are fetched from your cluster and are added as dynamic subcommands. You can see more details and available arguments by calling the subcommand with --help, e.g. create [name] --help

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--no-start` | `bool` | Don't start {noun} after creation | `False` |
| `--no-wait` | `bool` | Don't wait for the task to be ready after starting | `False` |
| `--help`, `-h` | `bool` | Show help message | `False` |
| `_extra` | `str` |  | `[]` |

#### `ellf tasks list`

List the tasks on the cluster. By default, this includes their ID, name and current state, e.g. created or completed

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'project_id', 'cluster_id', 'name', 'recipe_name', 'recipe_title', 'project_name', 'error', 'plan', 'job_type', 'cli_command', 'state'] | `['id', 'name', 'state', 'project_name']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf tasks info`

Print information about a task on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the task |  |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'project_id', 'cluster_id', 'name', 'recipe_name', 'recipe_title', 'project_name', 'error', 'plan', 'job_type', 'cli_command', 'last_execution_id', 'related_actions', 'url_logs', 'url', 'created_by_user'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf tasks logs`

Get logs for a task on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the task (or the last task if not set) | `None` |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--errors` | `bool` | Show structured error information instead of full logs | `False` |
| `--query` | `str` | Filter log lines matching this text (requires Loki) | `None` |

#### `ellf tasks start`

Start a task on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the task (or the last task if not set) | `None` |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--worker-class` | `str` | Worker class to launch the task on. Generally one of: ['medium', 'large', 'gpu'] | `None` |
| `--no-wait` | `bool` | Don't wait for the task to be ready after starting | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf tasks stop`

Stop a task on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the task (or the last task if not set) | `None` |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf tasks delete`

Delete a task by name or ID

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the task |  |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf publish`

Publish

#### `ellf publish code`

Upload and advertise a recipes package from your Python environment.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_path` | `str` | Path or name of importable module with the recipes |  |
| `--is-module`, `-m` | `bool` | Code to publish is an importable module | `False` |
| `--is-path`, `-p` | `bool` | Code to publish is a path | `False` |
| `--package-version` | `str` | Version identifier for the package | `None` |

#### `ellf publish data`

Transfer data to the cluster, and advertise it to Ellf. These steps can also be done separately. See `ellf files` to transfer data to the cluster without creating an Asset record for it, and `ellf assets create` to create an Asset without transfer.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `Path` | File or directory to publish |  |
| `dest` | `str` | Destination path to copy the data to | `None` |
| `--name` | `str` | Name of the asset | `None` |
| `--version` | `str` | Version of the asset | `None` |
| `--kind` | `str` | Kind of the asset. Generally one of: ['Input', 'Model', 'Patterns] |  |
| `--loader` | `str` | Loader to convert data for Prodigy | `None` |
| `--meta` | `str` | Asset meta, formatted as a JSON string | `'{}'` |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |

### `ellf login`

Log in to your Ellf account. You normally don't need to call this manually. It will automatically authenticate when needed.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--no-cluster` | `bool` | Don't use a cluster | `False` |
| `--no-browser` | `bool` | Don't open a browser, just print the login URL | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--claude` | `bool` | Install Ellf Claude Code skills and transcript hook into ~/.claude/ | `False` |

### `ellf info`

Print information about the CLI

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `field` | `str` | Field to select and show in output | `None` |

### `ellf get-auth-token`

Return an auth token for the current user

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `token_type` | `str` | The token type | `None` |

### `ellf version`

Show version info for the CLI and running services.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ellf export`

Save the state of the current app JSON file. If an assets directory is provided, assets will be downloaded and referenced in the JSON accordingly.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `output` | `Path` | JSON output path for data |  |
| `assets_dir` | `Path` | Local directory to download assets to | `None` |
| `--include` | `str` | Comma-separated items to include | `['tasks', 'actions', 'assets', 'datasets', 'paths']` |

### `ellf import`

Populate Ellf with data for projects, tasks, actions, assets and paths.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `data` | `Path` | JSON file to import |  |
| `--strict`, `-S` | `bool` | Error if items already exist and don't skip or overwrite anything | `False` |

### `ellf infra`

#### `ellf infra deploy`

Deploy or upgrade the Ellf Helm chart. Creates the namespace, image pull secret, cluster keypair secret, then runs helm upgrade --install with the provided values.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--values` | `Path` | Path to values.yaml for Helm deployment |  |
| `--chart` | `Path` | Path to local chart directory (default: OCI chart from registry) | `None` |
| `--latest` | `bool` | Fetch and use the latest image tags before deploying | `False` |
| `--namespace` | `str` | Kubernetes namespace | `'ellf'` |
| `--wait` | `bool` | Wait for pods to be ready after deploying | `False` |

#### `ellf infra init-values`

Generate a values.yaml for Helm deployment from credentials and provider defaults.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--creds` | `Path` | Path to cluster-creds.json from 'infra register' |  |
| `--cloud-provider` | `str` | Cloud provider: gcp, k3s, aws |  |
| `--domain` | `str` | Public address the cluster is reached on, host or host:port (e.g. 'cluster.example.com' or 'localhost:8443'). Match what was passed to 'infra register' — it flows into ELLF_BROKER_HOST so the cluster emits matching OIDC / token URLs. |  |
| `--out` | `Path` | Output path for generated values.yaml | `'values.yaml'` |
| `--acme-email` | `str` | Email for Let's Encrypt certificates | `None` |

#### `ellf infra provision`

Provision NFS wheelhouse on a cluster (runs provision hook).

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `Path` | Path to cluster definition files | `'.'` |
| `config_path` | `Path` | Path to config yaml | `None` |
| `--config-key` | `str` | Top-level key for the cluster config. | `None` |

#### `ellf infra register`

Register a new cluster with PAM and write credentials to cluster-creds.json.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--name` | `str` | Human-readable name for the cluster |  |
| `--domain` | `str` | Public address the cluster is reached on, host or host:port (e.g. 'cluster.example.com' for a hosted cluster on port 443, or 'localhost:8443' for a workstation cluster behind an SSH tunnel). Stored verbatim as the cluster address; the chart derives the bare hostname for K8s ingress / cert SAN where a port isn't allowed. |  |
| `--cloud-provider` | `str` | Cloud provider: gcp, k3s, aws |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ellf infra setup`

Install cluster infrastructure prerequisites (Traefik, cert-manager). These operations are idempotent and safe to re-run.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--traefik` | `bool` | Install Traefik ingress controller | `False` |
| `--cert-manager` | `bool` | Install cert-manager with Let's Encrypt | `False` |
| `--acme-email` | `str` | Email for ACME/Let's Encrypt certificate registration | `None` |
| `--public-ip` | `str` | Static IP for the Traefik load balancer | `None` |

#### `ellf infra start`

Start a cluster on infrastructure configured under your own cloud account.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `Path` | Path to cluster definition files | `'.'` |
| `config_path` | `Path` | Path to config yaml | `None` |
| `--config-key` | `str` | Top-level key for the cluster config. | `None` |
| `--offline` | `Path` | Path to a credentials JSON file. Deploys without connecting to PAM. | `None` |

#### `ellf infra get-terraform`

Download terraform files for cluster infrastructure.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--dest` | `Path` | Directory to save terraform files to | `'.'` |
| `--cloud-provider` | `str` | Cloud provider: gcp, k3s, aws | `'gcp'` |

#### `ellf infra terraform`

Apply terraform to create or update cluster infrastructure.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `Path` | Path to cluster definition files | `'.'` |
| `config_path` | `Path` | Path to config yaml | `None` |
| `--config-key` | `str` | Top-level key for the cluster config. | `None` |
| `--tf-init` | `bool` | Force run 'terraform init' | `False` |
| `--tf-apply` | `bool` | Apply the terraform changes | `False` |
| `--tf-auto-accept` | `bool` | Accept the terraform changes without interaction | `False` |

#### `ellf infra tls`

Manage TLS certificates for local cluster access. Use --self-signed when you have direct kubectl access to the cluster. Use --setup HOST to do everything from your laptop over SSH. Use --trust HOST to fetch and install an existing CA from a remote cluster.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--self-signed` | `bool` | Create a self-signed CA and certificate | `False` |
| `--trust` | `str` | SSH host to fetch CA from and install into local trust store | `None` |
| `--setup` | `str` | SSH host: create certs remotely, then fetch and trust the CA locally | `None` |
| `--status` | `bool` | Show current TLS configuration | `False` |
| `--fqdn` | `str` | Certificate FQDN (default: localhost) | `'localhost'` |
| `--namespace` | `str` | Kubernetes namespace | `'ellf'` |
| `--output` | `str` | Output format for trust commands: human, json, shell | `'human'` |

### `ellf support`

#### `ellf support create`

Send a support request to the Ellf team.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--message` | `str` | The user's support request or issue description |  |
| `--summary` | `str` | Optional support-ready summary of the issue and current state | `None` |
| `--project` | `UUID` | ID of support request's project (or the last project if not set) | `None` |
| `--no-project` | `bool` | Explicitly send the request without any project association | `False` |
| `--conversation` | `UUID` | Conversation ID to attach from PAM when available | `None` |
| `--session-id` | `str` | Claude Code session ID to use for transcript/debug attachment lookup | `None` |
| `--transcript-path` | `str` | Path to a Claude transcript .jsonl file to attach explicitly | `None` |
| `--transcript-consent` | `str` | Explicit transcript consent mode: 'summary_only' or 'attach_full_transcript' | `'summary_only'` |
| `--json` | `bool` | Output the result as JSON | `False` |