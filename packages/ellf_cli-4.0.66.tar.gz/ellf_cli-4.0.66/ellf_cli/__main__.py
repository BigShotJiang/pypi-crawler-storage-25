import os
import sys
from pathlib import Path

import truststore

# Use the OS native trust store (macOS Keychain, /etc/ssl/certs on Linux,
# Windows certificate store) for every httpx/urllib/requests call this
# CLI makes — instead of httpx's default certifi bundle. This collapses
# three trust stores into one: a `sudo security add-trusted-cert
# ~/.prodigy-teams/ca.crt` (or the Linux equivalent) makes the browser,
# curl, AND the CLI all trust the cluster's self-signed CA from one
# install. No SSL_CERT_FILE, no combined ca.pem, no per-cluster bundle.
# Must run before any code constructs an ssl.SSLContext, so it sits at
# module top.
truststore.inject_into_ssl()

FILE = Path(__file__).parent / "ellf.json"
IS_DEBUG = "_ELLF_DEBUG" in os.environ

# IMPORTANT: This is the function exposed via the console_scripts entry point to
# register the "ellf" command and it's also referenced in the Dockerfile.all.
# Do not change its name unless necessary, and double-check that
# ellf_cli.__main__.main is updated everywhere else.


def _normalize_legacy_args(args: list[str]) -> list[str]:
    """Normalize deprecated top-level command names."""
    normalized = list(args)
    if normalized and normalized[0] == "cluster":
        normalized[0] = "clusters"
    if normalized and normalized[0] == "plan":
        normalized[0] = "plans"
    if normalized and normalized[0] in ("coding-requests", "coding-request"):
        normalized[0] = "todo"
    return normalized


def main() -> None:
    from radicli import StaticRadicli

    from .about import __prog__

    args = _normalize_legacy_args(sys.argv[1:])
    argv = [__prog__, *args]
    static = StaticRadicli.load(FILE, debug=IS_DEBUG)
    static.run(list(argv))

    from . import config
    from .commands._state import ROOT_CONFIG
    from .main import cli

    if ROOT_CONFIG.get(None) is None:
        ROOT_CONFIG.set(config.RootConfig(config_dir=config.global_config_dir()))

    try:
        cli.run(list(argv))
    except Exception:
        if IS_DEBUG:
            import pdb

            pdb.post_mortem()
        raise


if __name__ == "__main__":
    main()
