---
name: ellf-annotate
description: "Prepares annotation for launch in the Ellf cluster: audits readiness, selects the right recipe, resolves arguments, and produces a launch-ready spec. Creation itself is not available in the assistant — the skill redirects the user to the web UI or CLI to create the task. Use when the user wants to start annotating data in Ellf, choose the right built-in Ellf recipe, verify that annotation is ready to launch, or plan an annotation agent setup. Also trigger on \"I want to annotate\", \"start annotation\", \"set up a labeling task\", \"which Ellf recipe should I use\", \"launch a review task\", \"start review\", \"set up an annotation agent\", or \"help me run annotation in Ellf\". Delegates to `/ellf-handoff` when a new custom recipe is needed, and to `/ellf-project` when broader project planning is required."
argument-hint: "[describe what you want to annotate]"
---

# Prepare Annotation In Ellf

Help the user get from an annotation-ready plan to a launch-ready spec.

$ARGUMENTS

## Your role

You are responsible for:
- checking that annotation is ready to launch
- choosing the right built-in Ellf annotation and/or agent recipe
- deciding whether an existing custom recipe is sufficient
- deciding when a new custom recipe is required
- preparing the recipe arguments into a complete launch spec
- redirecting the user to the web UI or CLI to create the task

You do not create tasks, actions, or agents — creation is not available in the assistant. You also do not implement new recipes. If the workflow requires a new custom recipe or custom interface, use `/ellf-handoff` to route the implementation to the coding workflow. If broader methodology or schema work is needed, use `/ellf-project`.

## Required readiness audit

Before choosing a recipe or building a launch spec, read:

- `${CLAUDE_SKILL_DIR}/references/annotation_audit.md`
- `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md`

The audit exists because launching with a poorly designed schema or a mismatched recipe wastes annotation effort and produces training data the model can't learn from. Use it to catch problems before you touch the platform.

Do not launch until you have confirmed:
- the annotation objective is clear
- the schema or review target is stable enough
- the recipe choice actually matches the task
- the input data is ready
- the target dataset is clear

If the audit surfaces a problem:
- methodological issues (schema design, task decomposition) → route to `/ellf-project`
- recipe implementation needs (custom UI, routing logic) → route to `/ellf-handoff`

## Recipe selection

### Built-in task recipe first

Prefer a built-in Ellf task recipe whenever it fits cleanly.
The built-in recipes are documented in `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md`

Call `mcp__pam__recipe_list` to confirm the recipe is available in the current environment before committing to it.

### Existing custom recipe

If the user names an existing cluster recipe and it matches the workflow, use it.

### New custom recipe required

If the audit shows the user needs a custom interface, routing logic, or annotation flow that built-ins cannot express cleanly:
- do not force a bad built-in fit
- use `/ellf-handoff` to assign custom recipe implementation to the coding agent
- describe what the custom recipe must do

## Annotation agents

If the user wants automated annotation:
- first ensure the base task is methodologically sound
- prepare the task spec first
- then identify an annotation-capable `agent_recipe` and prepare its args
- include both the task and agent specs in the launch-ready output

Do not treat the agent as a replacement for task setup. The task is the base annotation workflow.

## Recipe arguments

Once the recipe is selected:
- call `mcp__pam__recipe_list` to find the recipe ID
- call `mcp__pam__recipe_prepare_create` with the recipe ID and any known partial args
- treat the returned field spec as the authoritative source for: exact arg keys, required vs optional fields, missing required values, and dataset/asset/secret validation — this is the assistant-side equivalent of running `ellf-dev preview` locally
- fill args from context and the project plan where possible
- ask only for the values `mcp__pam__recipe_prepare_create` reports as missing and required

The annotation interface itself (what annotators see) cannot be previewed from the assistant. If the user needs to verify the annotation UI before cluster launch, they should use `ellf-dev run <recipe> [args]` in their local coding environment.

If too many required values are still missing, or the user would be better off reviewing the configuration visually, direct them to the appropriate task creation flow in the app instead of guessing.


## Preparing the launch spec

### 1. Confirm unresolved values

If required values are still missing:
- ask only for the missing values, tied directly to the recipe fields
- confirm the full configuration with `AskUserQuestion`

### 2. Present the launch-ready spec

Summarize the resolved configuration clearly:
- recipe name and ID
- all resolved arguments (key-value)
- worker class if applicable
- agent recipe and args if an annotation agent is also planned

### 3. Redirect to creation

**Creating tasks, actions, and agents is not available in the assistant.**

Give the user both options:

**Web UI:**
- Task → `/project/{project_id}/new/task` (select the recipe, fill in the prepared args)
- Agent → `/project/{project_id}/new/agent` (if an annotation agent was planned)

**CLI** (render in a fenced code block so it can be copied):
```
ellf tasks create <recipe> --name "<task_name>" <resolved_args>
ellf tasks start "<task_name>" [--worker-class <class>]
```

If an agent is also planned:
```
ellf agents create <agent_recipe> --name "<agent_name>" <agent_args>
ellf agents start "<agent_name>"
ellf agents assign "<agent_name>" --task "<task_name>"
```

## After creation

If the user confirms they created the task (in the UI or CLI), you can help verify it:
- check broker status at `GET /api/v1/jobs/{id}/status`
- confirm the task is running or healthy
- provide the task link and tell the user where to open it in the app
- if an agent was added, confirm it is assigned with `mcp__pam__task_bots_read`

If the task needs to be started and the user hasn't done so yet, use `/ellf-ops` to start it via broker.

If startup or assignment fails:
- inspect the broker error or logs at `GET /api/v1/jobs/{id}/logs`
- if this is an operational problem, use `/ellf-monitor` (or consult `/ellf-ops`)
- if this is a recipe-capability problem, use `/ellf-handoff`

When you finish:
- state whether the setup passed the readiness audit
- state which recipe path you selected
- summarize the launch spec
- if not launching, explain exactly what is missing and where you are routing the user next

## Reference files

| File | What it covers | When to read |
|------|---------------|--------------|
| `${CLAUDE_SKILL_DIR}/references/annotation_audit.md` | Readiness checklist: objective, schema, recipe fit, data, dataset | Before every launch |
| `${CLAUDE_SKILL_DIR}/references/builtin_ellf_annotation_recipes.md` | Built-in Ellf task and agent recipes with supported workflows | Recipe selection |
