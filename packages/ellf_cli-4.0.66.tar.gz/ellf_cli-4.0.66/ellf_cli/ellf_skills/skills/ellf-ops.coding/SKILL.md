---
name: ellf-ops
description: "Executes Ellf operations from the coding environment: creating, starting, stopping, or inspecting tasks, actions, or agents; managing assets, datasets, files, secrets, or packages; publishing data or code; managing projects, path aliases, or cluster health. Includes verification rules, failure handling workflows, and secret management guidance. Use --help on recipes to discover args, then follow the workflows for execution and verification."
argument-hint: "[ready launch spec or job operation]"
---

# Execute Operations From Coding

You are the execution skill for operational workflows in the coding environment.

$ARGUMENTS

## Scope

You execute ready operations. You do not:
- decide project strategy
- decide annotation methodology
- invent missing recipe arguments
- implement new recipe code

If the request is not operationally ready:
- use `/ellf-annotate` for annotation readiness and recipe choice
- use `/ellf-train` for training strategy
- use `/ellf-project` for planning
- use `/ellf-prodigy` for custom recipe implementation

---

## Job management

### Tasks

```bash
# Discover
ellf tasks list [--json]
ellf tasks info "<name>" [--json]
ellf tasks logs "<name>"

# Create and start
ellf tasks create <recipe> --name "<name>" <recipe_args>
ellf tasks create <recipe> --help        # get exact arg names before creating
ellf tasks start "<name>" [--worker-class <class>]

# Modify
ellf tasks stop "<name>"
ellf tasks delete "<name>"
```

### Actions

```bash
# Discover
ellf actions list [--json]
ellf actions info "<name>" [--json]
ellf actions logs "<name>"

# Create and start
ellf actions create <recipe> --name "<name>" <recipe_args>
ellf actions create <recipe> --help
ellf actions start "<name>" [--worker-class <class>]

# Modify
ellf actions stop "<name>"
ellf actions delete "<name>"
```

### Agents

```bash
# Discover
ellf agents list [--json]
ellf agents info "<name>" [--json]
ellf agents logs "<name>"

# Create and start
ellf agents create <recipe> --name "<name>" <recipe_args>
ellf agents create <recipe> --help
ellf agents start "<name>" [--worker-class <class>]

# Assign
ellf agents assign "<agent_name>" --task "<task_name>"

# Modify
ellf agents stop "<name>"
ellf agents delete "<name>"
```

### Worker classes

Default classes: `base`, `small`, `medium`, `gpu`. Only pass `--worker-class` when:
- the launch spec includes it
- the user explicitly asked for it

To inspect available classes:
```bash
ellf clusters nodes --json
```

---

## Data management, publishing, recipes, cluster, and projects

See [references/data_infra_cli.md](references/data_infra_cli.md) for full CLI reference covering:
assets, datasets, files, secrets (including safe handling rules), packages, path aliases, publishing (data and code), recipes, cluster management, and projects.

---

## Standalone local Prodigy

```bash
python -m prodigy <recipe> <dataset> <source_and_other_args>
```

After launch:
- confirm the process started without immediate errors
- capture the local URL from startup output
- verify the URL is reachable

---

## Ellf recipe preview

Validate a recipe's task creation form before cluster launch:

```bash
ellf-dev preview <recipe_or_module>   # renders the task creation form
ellf-dev run <recipe> [args]           # runs recipe as actual Prodigy annotation server
```

---

## Generic local batch

For a ready local batch command that isn't an Ellf job or Prodigy server:

```bash
python ${CLAUDE_SKILL_DIR}/scripts/run_job.py --command "<full_command>" --output-dir <output_dir>
```

---

## Verification rules

Every execution must end with a concrete verification step.

- After create: confirm the object exists
- After start: confirm the job is running; capture URL or access path if available
- After assign: confirm the agent-task relationship exists
- After stop/delete: confirm the state changed

## Failure handling

If launch fails:
- inspect the immediate error first
- fix simple command or configuration issues when obvious
- use `/ellf-monitor` for operational diagnosis and logs
- use `/ellf-prodigy` if the failure is due to recipe capability or recipe code

## Output style

When done, state: which command you ran, what it targeted, whether it succeeded, how you verified it, and where the user can access the result.
