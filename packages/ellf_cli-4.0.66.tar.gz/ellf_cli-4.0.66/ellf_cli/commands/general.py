import json
import shutil
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional

import httpx
from radicli import Arg
from wasabi import msg

from .. import about
from ..auth import AuthState
from ..cli import cli
from ..config import SavedSettings, global_config_dir
from ..errors import CLIError, EllfError
from ..messages import Messages
from ..ui import print_as_json, print_mutation_result
from ._state import get_auth_state, get_root_cfg


def _ellf_claude_plugin_dir() -> Path | None:
    package_root = Path(__file__).resolve().parents[1]
    plugin_dir = package_root / "ellf_skills"
    if (plugin_dir / "skill_variants.json").exists() and (
        plugin_dir / "bin" / "write-current-session.py"
    ).exists():
        return plugin_dir
    return None


def _ellf_skill_variants(plugin_dir: Path) -> dict[str, dict[str, str]]:
    manifest_path = plugin_dir / "skill_variants.json"
    return json.loads(manifest_path.read_text(encoding="utf-8"))


def _install_claude_skills() -> None:
    plugin_dir = _ellf_claude_plugin_dir()
    if plugin_dir is None:
        msg.warn(
            "Packaged ellf Claude plugin not found. "
            "Install the ellf-skills plugin assets to use --claude."
        )
        return
    claude_dir = Path.home() / ".claude"
    dest = claude_dir / "skills"
    dest.mkdir(parents=True, exist_ok=True)
    selected_skills = {
        canonical_name: plugin_dir / "skills" / variants["coding"]
        for canonical_name, variants in _ellf_skill_variants(plugin_dir).items()
        if "coding" in variants
    }
    for canonical_name, skill_dir in sorted(selected_skills.items()):
        dst = dest / canonical_name
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(skill_dir, dst)
    integration_dir = claude_dir / "ellf"
    integration_dir.mkdir(parents=True, exist_ok=True)
    hook_script_src = plugin_dir / "bin" / "write-current-session.py"
    hook_script_dst = integration_dir / "write_current_session.py"
    shutil.copy2(hook_script_src, hook_script_dst)
    _ensure_claude_hook(
        settings_path=claude_dir / "settings.json",
        hook_script_path=hook_script_dst,
    )
    msg.good(f"Installed {len(selected_skills)} Claude Code skills to {dest}")
    msg.good(f"Installed Claude transcript hook to {hook_script_dst}")
    for canonical_name in sorted(selected_skills):
        print(f"  - {canonical_name}")


def _ensure_claude_hook(*, settings_path: Path, hook_script_path: Path) -> None:
    if settings_path.exists():
        settings = json.loads(settings_path.read_text(encoding="utf-8"))
    else:
        settings = {}
    hooks = settings.setdefault("hooks", {})
    command = f'python3 "{hook_script_path}"'
    for event_name in ("SessionStart", "UserPromptSubmit", "PreToolUse"):
        event_hooks = hooks.setdefault(event_name, [])
        for group in event_hooks:
            for hook in group.get("hooks", []):
                if hook.get("type") == "command" and hook.get("command") == command:
                    break
            else:
                continue
            break
        else:
            event_hooks.append(
                {
                    "matcher": "",
                    "hooks": [
                        {
                            "type": "command",
                            "command": command,
                        }
                    ],
                }
            )
    settings_path.write_text(json.dumps(settings, indent=2) + "\n", encoding="utf-8")


@cli.command(
    "login",
    no_cluster=Arg("--no-cluster", help=Messages.no_cluster),
    no_browser=Arg("--no-browser", help=Messages.no_browser),
    as_json=Arg("--json", help=Messages.as_json),
    claude=Arg("--claude", help=Messages.claude),
)
def login(
    no_cluster: bool = False,
    no_browser: bool = False,
    as_json: bool = False,
    claude: bool = False,
) -> None:
    """
    Log in to your Ellf account. You normally don't need to call this
    manually. It will automatically authenticate when needed.
    """
    auth = get_auth_state()
    auth.no_browser = no_browser
    auth._ensure_readable_secrets()
    auth.get_api_token(force_refresh=True)
    if not no_cluster:
        try:
            auth.get_cluster_token(force_refresh=True)
        except EllfError as e:
            err = Messages.E116.format(command=f"{cli.prog} login --no-cluster")
            raise CLIError(err, e)
    print_mutation_result(
        {"status": "ok"},
        Messages.T012,
        as_json=as_json,
    )
    if claude:
        _install_claude_skills()


@cli.command("info", field=Arg(help=Messages.select_field))
def info(field: Optional[Literal["config-dir", "code", "defaults"]] = None) -> Any:
    """Print information about the CLI"""
    settings = SavedSettings.from_file(get_root_cfg().saved_settings_path)
    info = {
        "config-dir": str(global_config_dir().absolute()),
        "code": __file__,
        "defaults": settings.to_json(),
    }
    if field:
        print(info[field])
        return info[field]
    else:
        print_as_json(info)
        return info


@cli.command(
    "get-auth-token",
    token_type=Arg(help="The token type"),
)
def get_auth_token(
    token_type: Optional[Literal["api", "cluster", "id", "ci"]] = None,
) -> AuthState:
    """
    Return an auth token for the current user
    """
    auth = get_auth_state()
    if token_type == "api":
        print(auth.get_api_token().access_token)
    elif token_type == "cluster":
        print(auth.get_cluster_token().access_token)
    elif token_type == "id":
        print(auth.get_id_token())
    elif token_type == "ci":
        # this uses a dev endpoint because we don't want to give CI
        # a full access token. Once we can create and revoke limited
        # tokens, remove this.
        response = auth.client._sync_client.post(
            "/api/v1/dev/create-ci-token",
            json={},
        )
        response.raise_for_status()
        print(response.json()["access_token"])
    else:
        raise CLIError(Messages.E117.format(token_type=token_type))
    return auth


def _fetch_version(client: httpx.Client, path: str) -> Optional[Dict[str, str]]:
    """Fetch version info from a service endpoint, returning None on failure."""
    try:
        response = client.get(path)
        response.raise_for_status()
        return response.json()
    except Exception:
        return None


def _print_version_table(rows: List[Dict[str, str]]) -> None:
    """Print version info for all services in a readable format."""
    for row in rows:
        msg.divider(row["service"])
        for key in (
            "package_version",
            "repo_sha",
            "service_sha",
            "container_sha",
            "build_date",
        ):
            value = row.get(key, "")
            if value:
                print(f"  {key}: {value}")
            else:
                print(f"  {key}: -")


@cli.command(
    "version",
    as_json=Arg("--json", help=Messages.as_json),
)
def version(as_json: bool = False) -> None:
    """Show version info for the CLI and running services."""
    auth = get_auth_state()
    rows: List[Dict[str, str]] = []

    pam_version = _fetch_version(auth.client._sync_client, "/api/v1/version")
    if pam_version:
        rows.append(pam_version)
    elif not as_json:
        msg.warn("Could not reach PAM service")

    try:
        broker_version = _fetch_version(
            auth.broker_client._sync_client, "/api/v1/version"
        )
        if broker_version:
            rows.append(broker_version)
        elif not as_json:
            msg.warn("Could not reach Cluster service")
    except EllfError:
        if not as_json:
            msg.warn("Could not reach Cluster service (no cluster configured)")

    if as_json:
        import json

        result = {"cli": {"package_version": about.__version__}, "services": rows}
        print(json.dumps(result, indent=2, default=str))
    else:
        msg.divider("cli")
        print(f"  package_version: {about.__version__}")
        print()
        _print_version_table(rows)
