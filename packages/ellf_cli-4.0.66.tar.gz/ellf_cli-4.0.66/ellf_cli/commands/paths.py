import builtins
from collections.abc import Sequence
from typing import Optional, Union
from uuid import UUID

from radicli import Arg
from wasabi import msg

from ellf_pam_sdk.models import ClusterPathDetail, ClusterPathSummary

from ..cli import cli
from ..errors import CLIError, EllfErrors
from ..messages import Messages
from ..query import resolve_path, resolve_path_id
from ..ui import print_info_table, print_mutation_result, print_table_with_select
from ..util import resolve_remote_path
from ._state import get_auth_state


@cli.subcommand(
    "paths",
    "list",
    select=Arg(
        "--select",
        help=Messages.select.format(
            opts=builtins.list(ClusterPathSummary.model_fields)
        ),
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def list(
    select: builtins.list[str] = ["created", "id", "name", "path"],
    as_json: bool = False,
) -> Sequence[ClusterPathSummary]:
    """List all cluster path aliases"""
    client = get_auth_state().client
    items = builtins.list(client.cluster_path.all())
    print_table_with_select(items, select=select, as_json=as_json)
    return items


@cli.subcommand(
    "paths",
    "info",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="path")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="path")),
    select=Arg(
        "--select",
        help=Messages.select.format(opts=builtins.list(ClusterPathDetail.model_fields)),
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def info(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[UUID] = None,
    select: Optional[builtins.list[str]] = None,
    as_json: bool = False,
) -> ClusterPathDetail:
    """Get detailed info for a path alias"""
    res = resolve_path(name_or_id, cluster_id=cluster_id)
    print_info_table(res, as_json=as_json, select=select)
    return res


@cli.subcommand(
    "paths",
    "create",
    name=Arg(help=Messages.name.format(noun="path")),
    path=Arg(help=Messages.path.format(noun="cluster directory")),
    exists_ok=Arg("--exists-ok", help=Messages.exists_ok),
    as_json=Arg("--json", help=Messages.as_json),
)
def create(
    name: str, path: str, exists_ok: bool = False, as_json: bool = False
) -> UUID | None:
    """Create a new path alias"""
    auth = get_auth_state()
    client = auth.client
    cluster_id = auth.cluster_id
    path = resolve_remote_path(client, path, default_cluster=auth.broker_host)
    try:
        res = client.cluster_path.create(name=name, path=path, cluster_id=cluster_id)
    except EllfErrors.ClusterPathExists:
        if exists_ok:
            msg.info(Messages.T001.format(noun="path", name=name))
            return None
        raise CLIError(Messages.E002.format(noun="path", name=name))
    except EllfErrors.ClusterPathInvalid:
        raise CLIError(Messages.E004.format(noun="path", name=name))
    except EllfErrors.ClusterPathForbiddenCreate:
        raise CLIError(Messages.E003.format(noun="path", name=name))
    print_mutation_result(
        {"id": str(res.id), "name": res.name},
        Messages.T002.format(noun="path", name=res.name),
        as_json=as_json,
    )
    if not as_json:
        print_info_table(res)
    return res.id


@cli.subcommand(
    "paths",
    "delete",
    name_or_id=Arg(help=Messages.name_or_id.format(noun="path")),
    cluster_id=Arg(help=Messages.cluster_id.format(noun="path")),
    as_json=Arg("--json", help=Messages.as_json),
)
def delete(
    name_or_id: Union[str, UUID],
    cluster_id: Optional[UUID] = None,
    as_json: bool = False,
) -> UUID:
    """Delete a path alias"""
    path_id = resolve_path_id(name_or_id, cluster_id=cluster_id)
    auth = get_auth_state()
    try:
        auth.client.cluster_path.delete(id=path_id)
    except (
        EllfErrors.ProjectForbiddenDelete,
        EllfErrors.ProjectNotFound,
    ):
        raise CLIError(Messages.E006.format(noun="path", name=name_or_id))
    else:
        print_mutation_result(
            {"id": str(path_id), "deleted": True},
            Messages.T003.format(noun="path", name=name_or_id),
            as_json=as_json,
        )
    return path_id
