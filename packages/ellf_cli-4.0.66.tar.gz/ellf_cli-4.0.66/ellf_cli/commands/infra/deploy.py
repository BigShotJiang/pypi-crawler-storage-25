import base64
import json
import subprocess
import tempfile
from pathlib import Path
from typing import Optional
from uuid import UUID

import srsly
from radicli import Arg
from wasabi import msg

from ellf_pam_sdk.models import (
    ClusterUpdating,
)

from ...cli import cli
from ...helm import (
    HelmChartOverrides,
    preflight_test,
    upgrade,
    upgrade_from_ref,
)
from ...key_pair import generate_key_pair
from .._state import get_auth_state

DEFAULT_NAMESPACE = "ellf"
DEFAULT_RELEASE = "ellf"


@cli.subcommand(
    "infra",
    "deploy",
    values_file=Arg("--values", help="Path to values.yaml for Helm deployment"),
    chart=Arg(
        "--chart",
        help="Path to local chart directory (default: OCI chart from registry)",
    ),
    latest=Arg(
        "--latest",
        help="Fetch and use the latest image tags before deploying",
    ),
    namespace=Arg("--namespace", help="Kubernetes namespace"),
    wait=Arg("--wait", help="Wait for pods to be ready after deploying"),
)
def deploy(
    values_file: Path,
    chart: Optional[Path] = None,
    latest: bool = False,
    namespace: str = DEFAULT_NAMESPACE,
    wait: bool = False,
) -> None:
    """Deploy or upgrade the Ellf Helm chart.

    Creates the namespace, image pull secret, cluster keypair secret,
    then runs helm upgrade --install with the provided values.
    """
    values = srsly.read_yaml(values_file)
    assert isinstance(values, dict)
    # Optionally update to latest version from PAM
    if latest:
        cluster_id = values.get("cluster", {}).get("clusterId", "")
        if not cluster_id:
            msg.fail("Cannot use --latest: values.yaml missing cluster.clusterId")
            raise SystemExit(1)
        auth = get_auth_state()
        creds = auth.client.cluster.credentials(cluster_id=UUID(cluster_id))
        msg.info(
            f"Using versions from PAM: cluster={creds.image.broker_version}"
            f" cpl={creds.image.cpl_version}"
        )
        values.setdefault("image", {})
        values["image"]["brokerVersion"] = creds.image.broker_version
        values["image"]["cplVersion"] = creds.image.cpl_version
        srsly.write_yaml(values_file, values)
    # 1. Create namespace
    msg.info(f"Ensuring namespace {namespace}...")
    subprocess.run(
        ["kubectl", "create", "namespace", namespace, "--dry-run=client", "-o", "yaml"],
        capture_output=True,
        text=True,
        check=True,
    )
    subprocess.run(
        ["kubectl", "create", "namespace", namespace],
        capture_output=True,
        text=True,
    )
    # 2. Ensure the cluster nodeSelector label exists on a node. For single-node
    # clusters (typical k3s) we label the sole node; on multi-node clusters we
    # refuse to guess and surface a clear error instead.
    cluster_selector = values.get("cluster", {}).get("nodeSelector", {}) or {}
    for key, val in cluster_selector.items():
        _ensure_node_label(key, str(val))
    # 3. Create image pull secret (for non-GKE clusters using SA key)
    image_pull_secrets = values.get("imagePullSecrets", [])
    container_sa_key = values.get("secrets", {}).get("containerSaKey", "")
    registry = values.get("image", {}).get("registry", "")
    if image_pull_secrets and container_sa_key:
        if not registry:
            msg.fail("image.registry is empty in values.yaml")
            raise SystemExit(1)
        secret_name = image_pull_secrets[0]["name"]
        _create_image_pull_secret(
            secret_name=secret_name,
            sa_key_b64=container_sa_key,
            namespace=namespace,
            registry=registry,
        )
    # 4. Create cluster RSA keypair secret (if infra secret configured)
    # and register the public key with PAM for token verification.
    infra_secret_name = values.get("secrets", {}).get("infraSecretName", "")
    if infra_secret_name:
        # Resolve the database password from postgresql subchart or explicit config.
        pg = values.get("postgresql", {})
        database_password = (
            pg.get("auth", {}).get("password", "")
            if pg.get("enabled")
            else values.get("secrets", {}).get("databasePassword", "")
        )
        public_key_pem = _ensure_cluster_keypair_standalone(
            infra_secret_name, namespace, database_password=database_password
        )
        cluster_id = values.get("cluster", {}).get("clusterId", "")
        if cluster_id:
            auth = get_auth_state()
            cluster = auth.client.cluster.read(id=UUID(cluster_id))
            auth.client.cluster.update(
                ClusterUpdating(
                    id=cluster.id,
                    name=cluster.name,
                    address=cluster.address,
                    public_key=public_key_pem,
                    cloud_provider=None,
                    cloud=None,
                    state=None,
                )
            )
            msg.good("Registered cluster public key with PAM")
    # 5. Helm upgrade --install
    if chart is None:
        # Use OCI chart from the registry
        if not registry:
            msg.fail("image.registry is empty in values.yaml")
            raise SystemExit(1)
        if container_sa_key:
            _helm_registry_login(registry, container_sa_key)
        chart_ref = f"oci://{registry}/ellf"
        msg.info(f"Installing from {chart_ref}...")
        upgrade_from_ref(
            chart_ref, HelmChartOverrides(**values), namespace=namespace, wait=wait
        )
    else:
        msg.info(f"Installing from local chart {chart}...")
        upgrade(chart, HelmChartOverrides(**values), namespace=namespace, wait=wait)
    msg.good("Deployment complete")
    if wait:
        msg.info("Running verification checks...")
        preflight_test(release=DEFAULT_RELEASE, namespace=namespace)


def _create_image_pull_secret(
    secret_name: str, sa_key_b64: str, namespace: str, registry: str
) -> None:
    """Create a dockerconfigjson pull secret from a base64-encoded SA key.

    The manifest is built in-process and piped to ``kubectl apply`` so the SA
    key never appears on a command line (where ``ps`` would expose it).
    """
    sa_key_json = base64.b64decode(sa_key_b64, validate=True).decode("utf-8")
    host = registry.split("/", 1)[0]
    auth = base64.b64encode(f"_json_key:{sa_key_json}".encode()).decode()
    dockerconfig = json.dumps({"auths": {host: {"auth": auth}}})
    manifest = json.dumps(
        {
            "apiVersion": "v1",
            "kind": "Secret",
            "type": "kubernetes.io/dockerconfigjson",
            "metadata": {"name": secret_name, "namespace": namespace},
            "data": {
                ".dockerconfigjson": base64.b64encode(dockerconfig.encode()).decode(),
            },
        }
    )
    subprocess.run(
        ["kubectl", "apply", "-f", "-"],
        input=manifest,
        check=True,
        text=True,
    )
    msg.info(f"Image pull secret '{secret_name}' created/updated")


def _ensure_cluster_keypair_standalone(
    secret_name: str, namespace: str, database_password: str = ""
) -> str:
    """Ensure the infra K8s secret has a cluster RSA keypair, return the public PEM.

    The cluster uses ``ELLF_PRIVATE_KEY`` (base64-encoded PEM) for
    signing, so we read/write that key rather than the legacy
    ``cluster_private_key`` field.  The public key returned here is registered
    with PAM so it can verify cluster-signed tokens.

    When *database_password* is provided it is also stored in the secret as
    ``ELLF_DATABASE_PASSWORD`` so the cluster and CPL containers can
    authenticate with the database.
    """

    check = subprocess.run(
        [
            "kubectl",
            "get",
            "secret",
            secret_name,
            "-n",
            namespace,
            "-o",
            "jsonpath={.data.ELLF_PUBLIC_KEY}",
        ],
        capture_output=True,
        text=True,
    )
    if check.returncode == 0 and check.stdout.strip():
        # ELLF_PUBLIC_KEY is base64-encoded PEM (double-encoded in k8s)
        public_pem = base64.b64decode(base64.b64decode(check.stdout.strip())).decode(
            "utf-8"
        )
        msg.info(f"Using existing cluster keypair from secret {secret_name}")
        # Ensure the database password is present even if the keypair already
        # exists (it may have been created before this fix).
        if database_password:
            _patch_secret_field(
                secret_name,
                namespace,
                "ELLF_DATABASE_PASSWORD",
                database_password,
            )
        return public_pem
    msg.info("Generating new cluster RSA keypair...")
    kp = generate_key_pair()
    # The cluster expects base64-encoded PEM values in its environment.
    string_data = {
        "ELLF_PRIVATE_KEY": base64.b64encode(kp.private_pem.encode()).decode(),
        "ELLF_PUBLIC_KEY": base64.b64encode(kp.public_pem.encode()).decode(),
    }
    if database_password:
        string_data["ELLF_DATABASE_PASSWORD"] = database_password
    # Build the manifest in-process so the private key and DB password never
    # appear on a command line. stringData lets k8s do the outer base64 at
    # admission time, matching the .data shape kubectl create would produce.
    manifest = json.dumps(
        {
            "apiVersion": "v1",
            "kind": "Secret",
            "type": "Opaque",
            "metadata": {"name": secret_name, "namespace": namespace},
            "stringData": string_data,
        }
    )
    subprocess.run(
        ["kubectl", "apply", "-f", "-"],
        input=manifest,
        check=True,
        text=True,
    )
    msg.good(f"Created cluster keypair in secret {secret_name}")
    return kp.public_pem


def _patch_secret_field(secret_name: str, namespace: str, key: str, value: str) -> None:
    """Ensure a single field exists in an existing K8s secret.

    The patch body goes through ``--patch-file`` (a short-lived tempfile) so
    the value never appears on the kubectl command line, where ``ps`` would
    expose it.
    """
    patch = json.dumps({"stringData": {key: value}})
    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".json", delete=True
    ) as patch_file:
        patch_file.write(patch)
        patch_file.flush()
        subprocess.run(
            [
                "kubectl",
                "patch",
                "secret",
                secret_name,
                f"--namespace={namespace}",
                "--type",
                "merge",
                "--patch-file",
                patch_file.name,
            ],
            check=True,
            text=True,
            capture_output=True,
        )


def _helm_registry_login(registry: str, sa_key_b64: str) -> None:
    """Authenticate the local Helm client to an OCI registry.

    The image pull secret only covers the kubelet; Helm's chart pull runs on
    the workstation and needs its own login. Creds persist in
    ~/.config/helm/registry/config.json, and the login is idempotent.
    """
    host = registry.split("/", 1)[0]
    sa_key_json = base64.b64decode(sa_key_b64, validate=True).decode("utf-8")
    result = subprocess.run(
        ["helm", "registry", "login", host, "-u", "_json_key", "--password-stdin"],
        input=sa_key_json,
        text=True,
        capture_output=True,
    )
    if result.returncode != 0:
        msg.fail(f"helm registry login failed for {host}: {result.stderr.strip()}")
        raise SystemExit(1)
    msg.info(f"Authenticated Helm to {host}")


def _ensure_node_label(key: str, value: str) -> None:
    """Ensure at least one node carries ``key=value``.

    On a single-node cluster (typical k3s), the sole node is labeled
    automatically. On multi-node clusters we refuse to guess and require the
    operator to label the intended node themselves.
    """
    selector = f"{key}={value}"
    matched = subprocess.run(
        ["kubectl", "get", "nodes", "-l", selector, "-o", "name"],
        capture_output=True,
        text=True,
        check=True,
    )
    if matched.stdout.strip():
        return
    all_nodes = subprocess.run(
        ["kubectl", "get", "nodes", "-o", "jsonpath={.items[*].metadata.name}"],
        capture_output=True,
        text=True,
        check=True,
    )
    names = all_nodes.stdout.split()
    if not names:
        msg.fail("No nodes found — is kubectl pointing at the right context?")
        raise SystemExit(1)
    if len(names) > 1:
        msg.fail(
            f"No node is labeled {selector}, and the cluster has "
            f"{len(names)} nodes. Label the intended node with:\n"
            f"  kubectl label node <name> {selector}"
        )
        raise SystemExit(1)
    msg.info(f"Labeling node '{names[0]}' with {selector}")
    subprocess.run(
        ["kubectl", "label", "node", names[0], selector, "--overwrite"],
        check=True,
        text=True,
        capture_output=True,
    )
