"""ellf infra register — register a cluster with PAM."""

import json
from pathlib import Path

import srsly
from radicli import Arg
from wasabi import msg

from ellf_pam_sdk.models import ClusterCreating, ClusterUpdating

from ...cli import cli
from ...messages import Messages

CLOUD_PROVIDERS = ("gcp", "k3s", "aws")


@cli.subcommand(
    "infra",
    "register",
    name=Arg("--name", help="Human-readable name for the cluster"),
    domain=Arg(
        "--domain",
        help=(
            "Public address the cluster is reached on, host or host:port "
            "(e.g. 'cluster.example.com' for a hosted cluster on port 443, "
            "or 'localhost:8443' for a workstation cluster behind an SSH tunnel). "
            "Stored verbatim as the cluster address; the chart derives the "
            "bare hostname for K8s ingress / cert SAN where a port isn't allowed."
        ),
    ),
    cloud_provider=Arg(
        "--cloud-provider",
        help=f"Cloud provider: {', '.join(CLOUD_PROVIDERS)}",
    ),
    as_json=Arg("--json", help=Messages.as_json),
)
def register(
    name: str,
    domain: str,
    cloud_provider: str,
    as_json: bool = False,
) -> None:
    """Register a new cluster with PAM and write credentials to cluster-creds.json."""
    from .._state import get_auth_state, get_root_cfg, get_saved_settings

    if cloud_provider not in CLOUD_PROVIDERS:
        msg.fail(
            f"Unknown cloud provider '{cloud_provider}'. "
            f"Choose from: {', '.join(CLOUD_PROVIDERS)}"
        )
        raise SystemExit(1)
    auth = get_auth_state()
    client = auth.client
    org_id = auth.org_id
    # Idempotent on (org_id, name): list and filter client-side rather than
    # `cluster.read(name=...)`, which has historically returned the wrong record
    # when the name doesn't disambiguate (no LIMIT 1 / ORDER BY guarantees in
    # the PAM-side query). Address-based lookup also doesn't work as a
    # disambiguator because two clusters with the same human-readable domain
    # are valid (e.g. two `localhost`-served dev clusters in the same org).
    # page_size is capped at 100 server-side; iterate pages so this still
    # works in larger orgs.
    existing = next(
        (
            b
            for b in client.cluster.all(page_size=100)
            if b.name == name and b.org_id == org_id
        ),
        None,
    )
    if existing is None:
        body = ClusterCreating(
            name=name,
            org_id=org_id,
            address=domain,
            cloud_provider=cloud_provider,
            public_key="",
            state="creating",
            cloud={},
        )
        cluster = client.cluster.create(body)
    else:
        update_body = ClusterUpdating(
            id=existing.id,
            name=name,
            address=domain,
            cloud_provider=cloud_provider,
            state="creating",
            cloud={},
        )
        cluster = client.cluster.update(update_body)
    creds = client.cluster.credentials(cluster_id=cluster.id)
    creds_data = {
        "cluster_id": str(creds.cluster_id),
        "container_sa_key": creds.secrets.container_sa_key,
        "container_registry": creds.image.registry,
        "prodigy_license_key": creds.secrets.prodigy_license_key,
        "target_broker_version": creds.image.broker_version,
        "target_cpl_version": creds.image.cpl_version,
    }
    creds_path = Path("cluster-creds.json")
    srsly.write_json(creds_path, creds_data)
    # Persist the cluster id locally so subsequent `ellf` commands resolve the
    # cluster identity from saved-defaults instead of looking it up by address
    # (which is brittle when the user later sets `broker_host` to a tunnel URL
    # like `https://localhost:8443` that doesn't match the registered domain).
    settings = get_saved_settings()
    prior_cluster_id = settings.cluster_id
    settings.cluster_id = cluster.id
    settings.save(get_root_cfg().saved_settings_path)
    # Any cached cluster access token from a previous cluster_id is now stale.
    # The cache is keyed by broker_host; if the cluster behind that host has
    # changed identity (re-registered cluster, name reused, tear-down + redeploy),
    # the cached token will be rejected with 401 by the new cluster.
    if prior_cluster_id is not None and prior_cluster_id != cluster.id:
        secrets = auth.secrets
        secrets.broker_tokens.clear()
        secrets.save(get_root_cfg().secrets_path)
        msg.info("  Cleared stale cluster token cache (cluster_id changed)")
    if as_json:
        print(json.dumps(creds_data, indent=2))
    else:
        action = "updated existing" if existing else "registered new"
        msg.good(f"Cluster {action} with PAM")
        msg.info(f"  Cluster ID:    {creds.cluster_id}")
        msg.info(f"  Wrote credentials to {creds_path}")
