#!/usr/bin/env python3
import argparse
import os
import platform
import sys
import requests
import json
import re
import subprocess
import tempfile
import shlex
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.live import Live
from rich.text import Text

console = Console()

def apply_patch(filepath, diff_content):
    """Applies a unified diff to a file using the system patch utility."""
    try:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.diff', delete=False) as tmp:
            tmp.write(diff_content)
            tmp_path = tmp.name
        
        # -u treats it as unified diff, -N allows new files
        result = subprocess.run(['patch', '-u', filepath, tmp_path], capture_output=True, text=True)
        os.unlink(tmp_path)
        
        if result.returncode == 0:
            return f"Successfully applied patch to {filepath}."
        else:
            return f"Patch failed:\n{result.stderr}"
    except Exception as e:
        return f"Error applying patch: {e}"

def summarize_history(history, api_key, model_name):
    """Calls the LLM to summarize interaction history into a concise project state."""
    url = "https://ollama.com/api/generate"
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    history_text = "\n".join([f"User: {h['q']}\nAgent: {h['a']}" for h in history])
    summary_prompt = f"Summarize this interaction history into a single concise paragraph describing the current 'State of the Project'. Mention key accomplishments and current file states.\n\n[HISTORY]\n{history_text}"
    
    payload = {"model": model_name, "prompt": summary_prompt, "stream": False}
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        return response.json().get("response", "Summary unavailable.")
    except Exception:
        return "Summary generation failed."

def log_execution(command, returncode, duration, session="default"):
    """Records execution details to a session log file."""
    log_dir = ".askme/logs"
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f"{session}.log")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(log_path, "a") as f:
        f.write(f"[{timestamp}] CMD: {command} | EXIT: {returncode} | DUR: {duration:.2f}s\n")

def load_history(history_file):
    """Loads conversation history from the specified file."""
    try:
        with open(history_file, "r") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return []
    except Exception as e:
        console.print(f"[yellow]Warning: Could not load history: {e}[/yellow]")
        return []

def save_history(history, history_file):
    """Saves the last 10 interactions to maintain project context."""
    with open(history_file, "w") as f:
        json.dump(history[-10:], f)

def get_directory_tree(path=".", prefix="", depth=0, max_depth=2):
    """Generates a visual directory tree string."""
    if depth > max_depth:
        return []
    tree = []
    try:
        items = sorted(os.listdir(path))
        # Filter out common junk and hidden files except history
        items = [i for i in items if not i.startswith('.') or i == '.askme']
        for i, item in enumerate(items):
            connector = "└── " if i == len(items) - 1 else "├── "
            tree.append(f"{prefix}{connector}{item}")
            full_path = os.path.join(path, item)
            if os.path.isdir(full_path):
                extension = "    " if i == len(items) - 1 else "│   "
                tree.extend(get_directory_tree(full_path, prefix + extension, depth + 1))
    except Exception: pass
    return tree

def get_system_context():
    """Gathers environment info to improve agent awareness."""
    return {
        "os": platform.system(),
        "os_version": platform.release(),
        "python_version": sys.version.split()[0],
        "cwd": os.getcwd()
    }

def is_dangerous(command):
    """Checks if a command contains potentially destructive operations using regex."""
    dangerous_patterns = [
        r"rm\s+-rf\s+/", r"rm\s+-rf\s+\*", r"rm\s+-rf\s+\.", 
        r"> /dev/sd", r"mkfs", r"chmod\s+-R\s+777", 
        r"dd\s+if=", r":\(\)\{\s+:\|:&\s+\};:",
        r"mv\s+.*\s+/dev/null", r"shutdown", r"reboot"
    ]
    return any(re.search(pattern, command) for pattern in dangerous_patterns)

def is_filesystem_modifying(command):
    """Checks if a command is likely to modify the directory structure."""
    modifiers = ["mkdir", "touch", "rm", "mv", "cp", "git", ">>", ">"]
    return any(mod in command for mod in modifiers)

def is_path_safe(command):
    """Prevents directory traversal and access to absolute system paths."""
    # Basic jail: block climbing up or absolute paths that don't start with CWD
    return ".." not in command and not (command.startswith("/") and not command.startswith(os.getcwd()))

def get_current_context():
    """Refreshes the directory tree and system info for the prompt."""
    try:
        tree = get_directory_tree()
        sys_ctx = get_system_context()
        return (
            f"Environment: {sys_ctx['os']} {sys_ctx['os_version']}, Python {sys_ctx['python_version']}\n"
            f"CWD: {sys_ctx['cwd']}\nProject Structure:\n" + "\n".join(tree)
        )
    except Exception:
        return "Unknown directory context."

def main():
    # 1. Setup argument parsing
    parser = argparse.ArgumentParser(description="askme - The Professional CLI AI Agent")
    parser.add_argument("-p", "--prompt", type=str, nargs='+', help="The prompt to send to the model")
    parser.add_argument("-s", "--session", type=str, default="default", help="Session name for the history")
    parser.add_argument("-m", "--model", type=str, default="gemma4:31b-cloud", help="Ollama model to use")
    parser.add_argument("-d", "--dry-run", action="store_true", help="Show proposed commands without executing them")
    args = parser.parse_args()

    # 2. Configuration for Ollama
    api_key = os.getenv("OLLAMA_API_KEY")
    url = "https://ollama.com/api/generate"

    console.print("[bold blue]Verifying Environment...[/bold blue]")
    
    if not api_key:
        console.print("[bold yellow]OLLAMA_API_KEY not found in environment.[/bold yellow]")
        api_key = Prompt.ask("[bold cyan]Please enter your Ollama API Key[/bold cyan]", password=True)
        if not api_key:
            console.print("[bold red]Error: API Key is required to proceed.[/bold red]")
            return

        # Prompt for model selection if key was missing
        console.print("\n[bold white]Select an AI Model to use:[/bold white]")
        console.print("1. gemma4:31b-cloud (Default)")
        console.print("2. llama3")
        console.print("3. mistral")
        choice = Prompt.ask("Choose a number or type a custom model name", default="1")
        
        if choice == "1": args.model = "gemma4:31b-cloud"
        elif choice == "2": args.model = "llama3"
        elif choice == "3": args.model = "mistral"
        else: args.model = choice
    
    try:
        requests.head(url.rsplit('/', 1)[0], timeout=5)
        console.print(f"[green]✔[/green] OLLAMA_API_KEY detected and endpoint reachable.")
        console.print(f"[green]✔[/green] Using model: [bold cyan]{args.model}[/bold cyan]\n")
    except Exception as e:
        console.print(f"[bold yellow]![/bold yellow] Warning: Connectivity check to {url} failed: {e}\n")

    # 2.1 Define Agent behavior for iterative reasoning
    system_instruction = (
        "You are an iterative CLI Agent. Solve user requests by planning and executing shell commands.\n"
        "1. Analyze context and provide reasoning.\n"
        "2. For standard execution, use <execute>command</execute> (shlex-safe).\n"
        "3. For complex commands with pipes or redirects, use <execute_shell>command</execute_shell>.\n"
        "4. For large files, prefer using 'grep', 'head', or 'tail' to read specific sections.\n"
        "5. Use command output to decide your next step.\n"
        "6. Use <patch file=\"path\">unified diff content</patch> to modify files precisely without overwriting.\n"
        "7. When finished, provide a final response."
    )

    # 2.2 Setup Session and Load History
    session_dir = ".askme/sessions"
    os.makedirs(session_dir, exist_ok=True)
    history_path = os.path.join(session_dir, f"{args.session}.json")
    history = load_history(history_path)

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    session_vars = {} # Maintain environment variables across interactive turns

    # 3. Determine if we are in one-shot or interactive mode
    if args.prompt:
        user_prompt = " ".join(args.prompt) if isinstance(args.prompt, list) else args.prompt
        run_agent_loop(user_prompt, system_instruction, url, headers, args, history, history_path, api_key, session_vars, args.model)
    else:
        console.print(Panel("[bold cyan]Entering Interactive Mode[/bold cyan]\nType [bold red]'exit'[/bold red] or [bold red]'quit'[/bold red] to stop.", border_style="blue"))
        while True:
            user_prompt = Prompt.ask("[bold yellow]Query[/bold yellow]")
            if user_prompt.lower() in ["exit", "quit"]:
                break
            
            run_agent_loop(user_prompt, system_instruction, url, headers, args, history, history_path, api_key, session_vars, args.model)

def run_agent_loop(user_prompt, system_instruction, url, headers, args, history, history_path, api_key, session_vars, model_name):
    # Refresh context and summary at the start of every loop turn
    project_context = get_current_context()
    summary_block = ""
    if len(history) >= 10:
        console.print("[dim]Session history is long. Generating semantic summary to save tokens...[/dim]")
        summary = summarize_history(history[:-3], api_key, model_name)
        summary_block = f"[PROJECT SUMMARY]\n{summary}\n\n"
        # Update history reference to keep the most recent 3 for immediate context
        history[:] = history[-3:] 

    history_str = "\n".join([f"User: {h['q']}\nAgent: {h['a']}" for h in history])
    current_prompt = f"{system_instruction}\n\n[PROJECT CONTEXT]\n{project_context}\n\n{summary_block}[RECENT HISTORY]\n{history_str}\n\nUser: {user_prompt}"
    all_agent_responses = []
    iteration = 0
    max_iterations = 5
    tree_dirty = False

    total_prompt_tokens = 0
    total_completion_tokens = 0
    start_session_time = datetime.now()

    try:
        while iteration < max_iterations:
            iteration += 1
            payload = {
                "model": model_name, 
                "prompt": current_prompt, 
                "stream": True,
                "options": {
                    "num_ctx": 8192,
                    "temperature": 0.2  # Lower temperature for more precise CLI commands
                }
            }
            response = requests.post(url, headers=headers, json=payload, stream=True)
            response.raise_for_status()
            
            console.print(f"\n[bold cyan] askme Agent[/bold cyan]: ", end="")
            full_content = ""
            for line in response.iter_lines():
                if line:
                    chunk = json.loads(line.decode("utf-8"))
                    if "response" in chunk:
                        token = chunk["response"]
                        console.print(token, end="", style="italic green")
                        full_content += token
                    if chunk.get("done"):
                        total_prompt_tokens += chunk.get("prompt_eval_count", 0)
                        total_completion_tokens += chunk.get("eval_count", 0)
            print()
            all_agent_responses.append(full_content)
            
            # Parse for the command to execute
            # Uses regex to find commands even inside code blocks or with trailing spaces
            command = None
            use_shell = False
            
            shell_match = re.search(r"<execute_shell>(.*?)</execute_shell>", full_content, re.DOTALL)
            exec_match = re.search(r"<execute>(.*?)</execute>", full_content, re.DOTALL)
            patch_match = re.search(r"<patch file=['\"](.*?)['\"]>(.*?)</patch>", full_content, re.DOTALL)

            if shell_match:
                command = shell_match.group(1).strip()
                use_shell = True
            elif patch_match:
                filepath, diff_content = patch_match.groups()
                res = apply_patch(filepath, diff_content)
                current_prompt += f"\nAgent: {full_content}\n[SYSTEM: Patch Result]\n{res}\nNext step:"
                tree_dirty = True
                continue
            elif exec_match:
                command = exec_match.group(1).strip()
                use_shell = False

            if not command:
                break
            
            # The Shield: Safety check for dangerous commands
            if is_dangerous(command) or not is_path_safe(command):
                console.print(Panel(
                    f"[bold red]SECURITY ALERT:[/bold red] Unsafe command or path detected!\n"
                    f"Command: [bold cyan]{command}[/bold cyan]\n\n"
                    "Execution blocked for safety.",
                    title="[blink red]SECURITY BLOCK[/blink red]",
                    border_style="bold red"
                ))
                if not Confirm.ask("[bold red]Are you absolutely sure you want to run this?[/bold red]", default=False):
                    console.print("[bold yellow]! High-risk execution blocked by user.[/bold yellow]")
                    break

            if args.dry_run:
                console.print(Panel(f"DRY RUN: Would execute [bold cyan]{command}[/bold cyan]", border_style="yellow"))
                break

            mode_str = " (SHELL MODE)" if use_shell else ""
            if Confirm.ask(f"\n[bold yellow]󰆍 Agent suggests{mode_str}:[/bold yellow] [bold blue]{command}[/bold blue]\n[dim]Execute?[/dim]"):
                console.print(Panel(f"Executing: [bold white]{command}[/bold white]", border_style="blue", title="System" if not use_shell else "System (Shell)"))
                
                output_text = ""
                try:
                    if use_shell:
                        cmd_args = command
                    else:
                        cmd_args = shlex.split(command)

                    start_time = datetime.now()
                    # Merge system env with session variables
                    env = os.environ.copy()
                    env.update(session_vars)

                    process = subprocess.Popen(
                        cmd_args, shell=use_shell, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, 
                        text=True, bufsize=1, env=env
                    )
                    
                    console.print("[dim]Command Output:[/dim]")
                    with Live(Text(""), refresh_per_second=4) as live:
                        for line in process.stdout:
                            output_text += line
                            display_text = "\n".join(output_text.splitlines()[-10:])
                            live.update(Text(display_text)) # Show last 10 lines
                    
                    process.wait(timeout=30) # Prevent hanging on interactive commands
                    duration = (datetime.now() - start_time).total_seconds()
                    
                    log_execution(command, process.returncode, duration, args.session)
                    
                    if process.returncode == 0:
                        console.print("[bold green]✔ Success.[/bold green]")
                        system_status = "Command result"
                    else:
                        console.print(f"[bold red]✘ Failed with code {process.returncode}[/bold red]")
                        system_status = f"Command failed with exit code {process.returncode}. Analyze the error below."
                    
                    tree_dirty = is_filesystem_modifying(command)

                except subprocess.TimeoutExpired:
                    process.kill()
                    console.print("[bold red]✘ Command timed out (30s).[/bold red]")
                    output_text += "\n[ERROR: Process terminated due to timeout]"
                    system_status = "Command timed out. Use a more targeted command."
                except Exception as e:
                    console.print(f"[bold red]✘ Execution error:[/bold red] {e}")
                    output_text += f"\n[ERROR: {e}]"
                    system_status = "Execution error"
                
                # Token Optimization: Truncate very long outputs in the prompt
                if len(output_text) > 4000:
                    output_text = output_text[:2000] + "\n... [Output truncated for brevity] ...\n" + output_text[-2000:]

                # Update context with output for the next reasoning step
                current_prompt += f"\nAgent: {full_content}\n[SYSTEM: {system_status}]\n{output_text}"
                
                if tree_dirty:
                    new_tree = get_directory_tree()
                    current_prompt += f"\n[UPDATED PROJECT STRUCTURE]\n" + "\n".join(new_tree)
                
                current_prompt += "\nNext step:"
            else:
                console.print("[bold yellow]! Execution skipped by user.[/bold yellow]")
                break

        if iteration >= max_iterations:
            console.print(Panel("[yellow]Maximum iteration limit reached for this request.[/yellow]", border_style="yellow"))

        # Display Metadata Summary
        end_session_time = datetime.now()
        total_duration = (end_session_time - start_session_time).total_seconds()
        
        summary_text = Text()
        summary_text.append(f"Total Iterations: ", style="bold white")
        summary_text.append(f"{iteration}\n", style="cyan")
        summary_text.append(f"Prompt Tokens: ", style="bold white")
        summary_text.append(f"{total_prompt_tokens} ", style="cyan")
        summary_text.append(f"| Completion Tokens: ", style="bold white")
        summary_text.append(f"{total_completion_tokens}\n", style="cyan")
        summary_text.append(f"Total Time: ", style="bold white")
        summary_text.append(f"{total_duration:.2f}s", style="cyan")

        console.print(Panel(summary_text, title="[bold magenta]Session Metadata[/bold magenta]", border_style="magenta"))

        # Save the cumulative interaction
        history.append({"q": user_prompt, "a": "\n".join(all_agent_responses)})
        save_history(history, history_path)

    except KeyboardInterrupt:
        console.print("\n[bold red]Operation cancelled by user.[/bold red]")
    except Exception as e:
        console.print(f"\n[bold red]Error occurred:[/bold red] {e}")

if __name__ == "__main__":
    main()
