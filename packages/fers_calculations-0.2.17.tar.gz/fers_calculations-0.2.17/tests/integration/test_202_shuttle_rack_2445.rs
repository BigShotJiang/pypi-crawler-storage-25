// test_202_shuttle_rack_2445.rs
// ─────────────────────────────────────────────────────────────────────────────
// Integration tests for configuration 2445 (large shuttle rack, 6-deep).
//
// Model overview:
//   - 6 bays × 6 upright frames (Z = 0, 1500, 3000, 4500, 6000, 7500 mm)
//   - 36 support nodes at base (Y = 0)
//   - ~1058 members, 15 load cases, 25 load combinations (35 total)
//   - Section 6 (Rail 3.0mm): principal_axis_angle = -20.6°, i_yz = 1897954
//   - Section 21 (C90-12): z_s = 44.17mm (uprights)
//   - include_shear_center_coupling = false  (matches SkyCiv BLS behaviour)
//   - Stiffness curve on base Rz springs, depends_on: Vy (vertical reaction)
//
// SkyCiv baseline was generated with matched inputs and include_shear_center_coupling=false.
// ─────────────────────────────────────────────────────────────────────────────

use fers_calculations::analysis::calculate_from_json_internal_with_tier;
use fers_calculations::limits::LicenseTier;

fn load_full_model() -> String {
    let path = std::path::Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests")
        .join("shuttle_rack_2445.json");
    std::fs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("Failed to read {}: {e}", path.display()))
}

fn run_full_model(json: &str) -> serde_json::Value {
    let result = calculate_from_json_internal_with_tier(json, LicenseTier::Premium);
    let res_json = match &result {
        Ok(s) => s.clone(),
        Err(e) => panic!("FERS solve failed: {e}"),
    };
    serde_json::from_str(&res_json).expect("parse result JSON")
}

// ─────────────────────────────────────────────────────────────────────────────
// 202a — All 35 LCs / combos must converge
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_202a_all_combos_converge() {
    let json = load_full_model();
    let t0 = std::time::Instant::now();
    let result = run_full_model(&json);
    let elapsed = t0.elapsed();

    let mut ok_count = 0;
    let mut fail_count = 0;

    if let Some(lcs) = result["results"]["loadcases"].as_object() {
        for (name, lc) in lcs {
            if lc.get("error").is_some() {
                eprintln!("  ❌ LC {name}: {}", lc["error"]);
                fail_count += 1;
            } else {
                ok_count += 1;
            }
        }
    }
    if let Some(combos) = result["results"]["loadcombinations"].as_object() {
        for (name, lc) in combos {
            if lc.get("error").is_some() {
                eprintln!("  ❌ Combo {name}: {}", lc["error"]);
                fail_count += 1;
            } else {
                ok_count += 1;
            }
        }
    }

    eprintln!(
        "202a (all combos): {ok_count} OK, {fail_count} FAIL in {:.1}s",
        elapsed.as_secs_f64()
    );
    assert_eq!(fail_count, 0, "{fail_count} load case(s) failed");
    assert!(ok_count >= 15, "Expected ≥15 results, got {ok_count}");
}

// ─────────────────────────────────────────────────────────────────────────────
// 202b — Dead_load_rack: fy reactions at 36 supports (SkyCiv baseline)
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_202b_dead_load_rack_reactions() {
    let json = load_full_model();
    let result = run_full_model(&json);

    let lc = &result["results"]["loadcases"]["Dead_load_rack"];
    assert!(!lc.is_null(), "Dead_load_rack not found");
    let reactions = &lc["reaction_nodes"];

    // Representative subset: 6 nodes across Z positions, X = 0 (left edge)
    // SkyCiv baseline values for fy (N)
    let checks: &[(&str, f64)] = &[
        ("11",  216.56),  // Z=0
        ("18",  537.93),  // Z=1500
        ("40",  410.26),  // Z=3000
        ("47",  410.41),  // Z=4500
        ("69",  538.40),  // Z=6000
        ("76",  216.11),  // Z=7500
        // X = 1540 (second row)
        ("170", 417.34),  // Z=0
        ("177", 790.68),  // Z=1500
    ];

    let tol_pct = 5.0;
    let tol_abs = 20.0;
    let mut failures = Vec::new();

    for &(nid, expected) in checks {
        let fers = reactions[nid]["nodal_forces"]["fy"]
            .as_f64()
            .unwrap_or(f64::NAN);
        let diff_pct = if expected.abs() > 1.0 {
            ((fers - expected) / expected.abs() * 100.0).abs()
        } else {
            (fers - expected).abs()
        };
        if diff_pct > tol_pct && (fers - expected).abs() > tol_abs {
            failures.push(format!(
                "N{nid}: FERS={fers:.1} SkyCiv={expected:.1} Δ={diff_pct:.1}%"
            ));
        }
    }

    assert!(
        failures.is_empty(),
        "Dead_load_rack reaction mismatches:\n{}",
        failures.join("\n")
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 202c — Product_load: fy reactions (SkyCiv baseline)
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_202c_product_load_reactions() {
    let json = load_full_model();
    let result = run_full_model(&json);

    let lc = &result["results"]["loadcases"]["Product_load"];
    assert!(!lc.is_null(), "Product_load not found");
    let reactions = &lc["reaction_nodes"];

    // SkyCiv baseline (fy in N)
    let checks: &[(&str, f64)] = &[
        ("11",  1095.40),   // Z=0, X=0
        ("18",  5581.44),   // Z=1500, X=0
        ("40",  3687.99),   // Z=3000, X=0
        ("47",  3686.49),   // Z=4500, X=0
        ("69",  5590.56),   // Z=6000, X=0
        ("76",  1088.33),   // Z=7500, X=0
        ("170", 3718.06),   // Z=0, X=1540
        ("177", 9063.27),   // Z=1500, X=1540
        ("264", 9020.12),   // Z=1500, X=3080
        ("518", 1095.40),   // Z=0, X=7700 (symmetric)
    ];

    let tol_pct = 5.0;
    let tol_abs = 50.0;
    let mut failures = Vec::new();

    for &(nid, expected) in checks {
        let fers = reactions[nid]["nodal_forces"]["fy"]
            .as_f64()
            .unwrap_or(f64::NAN);
        let diff_pct = if expected.abs() > 1.0 {
            ((fers - expected) / expected.abs() * 100.0).abs()
        } else {
            (fers - expected).abs()
        };
        if diff_pct > tol_pct && (fers - expected).abs() > tol_abs {
            failures.push(format!(
                "N{nid}: FERS={fers:.1} SkyCiv={expected:.1} Δ={diff_pct:.1}%"
            ));
        }
    }

    assert!(
        failures.is_empty(),
        "Product_load reaction mismatches:\n{}",
        failures.join("\n")
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 202d — Dead_load_shuttle: fy reactions (SkyCiv baseline)
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_202d_dead_load_shuttle_reactions() {
    let json = load_full_model();
    let result = run_full_model(&json);

    let lc = &result["results"]["loadcases"]["Dead_load_shuttle"];
    assert!(!lc.is_null(), "Dead_load_shuttle not found");
    let reactions = &lc["reaction_nodes"];

    // SkyCiv baseline — only nodes with |fy| > 50 N (exclude tiny forces)
    let checks: &[(&str, f64)] = &[
        ("11",   295.21),
        ("18",   888.98),
        ("40",   -97.39),
        ("47",   -57.86),
        ("170", 1017.70),
        ("177", 1195.10),
        ("199",   87.94),
        ("206",  -74.49),
        ("257",  986.50),
        ("264", 1183.34),
        ("286",   52.29),
        ("293",  -52.64),
        ("518",  295.21),
        ("525",  888.98),
    ];

    let tol_pct = 10.0; // Wider tolerance — small forces amplify % errors
    let tol_abs = 20.0;
    let mut failures = Vec::new();

    for &(nid, expected) in checks {
        let fers = reactions[nid]["nodal_forces"]["fy"]
            .as_f64()
            .unwrap_or(f64::NAN);
        let diff_pct = if expected.abs() > 1.0 {
            ((fers - expected) / expected.abs() * 100.0).abs()
        } else {
            (fers - expected).abs()
        };
        if diff_pct > tol_pct && (fers - expected).abs() > tol_abs {
            failures.push(format!(
                "N{nid}: FERS={fers:.1} SkyCiv={expected:.1} Δ={diff_pct:.1}%"
            ));
        }
    }

    assert!(
        failures.is_empty(),
        "Dead_load_shuttle reaction mismatches:\n{}",
        failures.join("\n")
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 202e — Performance: full solve should complete within 30 seconds
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_202e_performance() {
    let json = load_full_model();
    let t0 = std::time::Instant::now();
    let _result = run_full_model(&json);
    let elapsed = t0.elapsed();

    eprintln!("202e: full solve in {:.1}s", elapsed.as_secs_f64());
    assert!(
        elapsed.as_secs_f64() < 30.0,
        "Full 2445 solve took {:.1}s — expected < 30s",
        elapsed.as_secs_f64()
    );
}

// ─────────────────────────────────────────────────────────────────────────────
// 202f — Symmetry check: left/right edge nodes should mirror
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_202f_symmetry() {
    let json = load_full_model();
    let result = run_full_model(&json);

    let lc = &result["results"]["loadcases"]["Dead_load_rack"];
    assert!(!lc.is_null());
    let reactions = &lc["reaction_nodes"];

    // Symmetric pairs: (X=0, X=7700) at same Z
    let pairs: &[(&str, &str)] = &[
        ("11", "518"),   // Z=0
        ("18", "525"),   // Z=1500
        ("40", "547"),   // Z=3000
        ("47", "554"),   // Z=4500
        ("69", "576"),   // Z=6000
        ("76", "583"),   // Z=7500
    ];

    for &(a, b) in pairs {
        let fy_a = reactions[a]["nodal_forces"]["fy"].as_f64().unwrap_or(0.0);
        let fy_b = reactions[b]["nodal_forces"]["fy"].as_f64().unwrap_or(0.0);
        assert!(
            (fy_a - fy_b).abs() < 1.0,
            "Symmetry N{a}/N{b} fy: {fy_a:.2} vs {fy_b:.2}"
        );
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// 202k — Full diagnostic: print all reactions for key load cases
// ─────────────────────────────────────────────────────────────────────────────

#[test]
fn test_202k_diagnostic_reactions() {
    let json = load_full_model();
    let result = run_full_model(&json);

    // Left-edge nodes only (X=0)
    let nodes = ["11", "18", "40", "47", "69", "76"];
    let dofs = ["fx", "fy", "fz", "mx", "my", "mz"];

    for lc_name in &["Dead_load_shuttle", "Dead_load_rack", "Product_load"] {
        let lc = &result["results"]["loadcases"][*lc_name];
        if lc.is_null() { continue; }
        let reactions = &lc["reaction_nodes"];
        eprintln!("\n=== {lc_name} Reactions (left edge X=0) ===");
        for &nid in &nodes {
            let rn = &reactions[nid];
            let forces: Vec<f64> = dofs.iter()
                .map(|d| rn["nodal_forces"][*d].as_f64().unwrap_or(0.0))
                .collect();
            eprintln!("  Node {nid}: fx={:>10.2} fy={:>10.2} fz={:>10.2} mx={:>10.2} my={:>10.2} mz={:>10.2}",
                forces[0], forces[1], forces[2], forces[3], forces[4], forces[5]);
        }
    }
}
