#include "_hex_pairs.h"

#if defined(_MSC_VER)
static_assert(sizeof(uint16_t) == 2U, "uint16_t must be 16-bit");
#else
_Static_assert(sizeof(uint16_t) == 2U, "uint16_t must be 16-bit");
#endif

#if defined(__BYTE_ORDER__) && __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
#define HEX_U16(a, b) ((uint16_t)((uint16_t)(a) << 8 | (uint16_t)(b)))
#else
#define HEX_U16(a, b) ((uint16_t)((uint16_t)(a) | (uint16_t)(b) << 8))
#endif

const uint16_t HEX_PAIRS[256] = {
    HEX_U16('0', '0'), HEX_U16('0', '1'), HEX_U16('0', '2'), HEX_U16('0', '3'), HEX_U16('0', '4'),
    HEX_U16('0', '5'), HEX_U16('0', '6'), HEX_U16('0', '7'), HEX_U16('0', '8'), HEX_U16('0', '9'),
    HEX_U16('0', 'a'), HEX_U16('0', 'b'), HEX_U16('0', 'c'), HEX_U16('0', 'd'), HEX_U16('0', 'e'),
    HEX_U16('0', 'f'), HEX_U16('1', '0'), HEX_U16('1', '1'), HEX_U16('1', '2'), HEX_U16('1', '3'),
    HEX_U16('1', '4'), HEX_U16('1', '5'), HEX_U16('1', '6'), HEX_U16('1', '7'), HEX_U16('1', '8'),
    HEX_U16('1', '9'), HEX_U16('1', 'a'), HEX_U16('1', 'b'), HEX_U16('1', 'c'), HEX_U16('1', 'd'),
    HEX_U16('1', 'e'), HEX_U16('1', 'f'), HEX_U16('2', '0'), HEX_U16('2', '1'), HEX_U16('2', '2'),
    HEX_U16('2', '3'), HEX_U16('2', '4'), HEX_U16('2', '5'), HEX_U16('2', '6'), HEX_U16('2', '7'),
    HEX_U16('2', '8'), HEX_U16('2', '9'), HEX_U16('2', 'a'), HEX_U16('2', 'b'), HEX_U16('2', 'c'),
    HEX_U16('2', 'd'), HEX_U16('2', 'e'), HEX_U16('2', 'f'), HEX_U16('3', '0'), HEX_U16('3', '1'),
    HEX_U16('3', '2'), HEX_U16('3', '3'), HEX_U16('3', '4'), HEX_U16('3', '5'), HEX_U16('3', '6'),
    HEX_U16('3', '7'), HEX_U16('3', '8'), HEX_U16('3', '9'), HEX_U16('3', 'a'), HEX_U16('3', 'b'),
    HEX_U16('3', 'c'), HEX_U16('3', 'd'), HEX_U16('3', 'e'), HEX_U16('3', 'f'), HEX_U16('4', '0'),
    HEX_U16('4', '1'), HEX_U16('4', '2'), HEX_U16('4', '3'), HEX_U16('4', '4'), HEX_U16('4', '5'),
    HEX_U16('4', '6'), HEX_U16('4', '7'), HEX_U16('4', '8'), HEX_U16('4', '9'), HEX_U16('4', 'a'),
    HEX_U16('4', 'b'), HEX_U16('4', 'c'), HEX_U16('4', 'd'), HEX_U16('4', 'e'), HEX_U16('4', 'f'),
    HEX_U16('5', '0'), HEX_U16('5', '1'), HEX_U16('5', '2'), HEX_U16('5', '3'), HEX_U16('5', '4'),
    HEX_U16('5', '5'), HEX_U16('5', '6'), HEX_U16('5', '7'), HEX_U16('5', '8'), HEX_U16('5', '9'),
    HEX_U16('5', 'a'), HEX_U16('5', 'b'), HEX_U16('5', 'c'), HEX_U16('5', 'd'), HEX_U16('5', 'e'),
    HEX_U16('5', 'f'), HEX_U16('6', '0'), HEX_U16('6', '1'), HEX_U16('6', '2'), HEX_U16('6', '3'),
    HEX_U16('6', '4'), HEX_U16('6', '5'), HEX_U16('6', '6'), HEX_U16('6', '7'), HEX_U16('6', '8'),
    HEX_U16('6', '9'), HEX_U16('6', 'a'), HEX_U16('6', 'b'), HEX_U16('6', 'c'), HEX_U16('6', 'd'),
    HEX_U16('6', 'e'), HEX_U16('6', 'f'), HEX_U16('7', '0'), HEX_U16('7', '1'), HEX_U16('7', '2'),
    HEX_U16('7', '3'), HEX_U16('7', '4'), HEX_U16('7', '5'), HEX_U16('7', '6'), HEX_U16('7', '7'),
    HEX_U16('7', '8'), HEX_U16('7', '9'), HEX_U16('7', 'a'), HEX_U16('7', 'b'), HEX_U16('7', 'c'),
    HEX_U16('7', 'd'), HEX_U16('7', 'e'), HEX_U16('7', 'f'), HEX_U16('8', '0'), HEX_U16('8', '1'),
    HEX_U16('8', '2'), HEX_U16('8', '3'), HEX_U16('8', '4'), HEX_U16('8', '5'), HEX_U16('8', '6'),
    HEX_U16('8', '7'), HEX_U16('8', '8'), HEX_U16('8', '9'), HEX_U16('8', 'a'), HEX_U16('8', 'b'),
    HEX_U16('8', 'c'), HEX_U16('8', 'd'), HEX_U16('8', 'e'), HEX_U16('8', 'f'), HEX_U16('9', '0'),
    HEX_U16('9', '1'), HEX_U16('9', '2'), HEX_U16('9', '3'), HEX_U16('9', '4'), HEX_U16('9', '5'),
    HEX_U16('9', '6'), HEX_U16('9', '7'), HEX_U16('9', '8'), HEX_U16('9', '9'), HEX_U16('9', 'a'),
    HEX_U16('9', 'b'), HEX_U16('9', 'c'), HEX_U16('9', 'd'), HEX_U16('9', 'e'), HEX_U16('9', 'f'),
    HEX_U16('a', '0'), HEX_U16('a', '1'), HEX_U16('a', '2'), HEX_U16('a', '3'), HEX_U16('a', '4'),
    HEX_U16('a', '5'), HEX_U16('a', '6'), HEX_U16('a', '7'), HEX_U16('a', '8'), HEX_U16('a', '9'),
    HEX_U16('a', 'a'), HEX_U16('a', 'b'), HEX_U16('a', 'c'), HEX_U16('a', 'd'), HEX_U16('a', 'e'),
    HEX_U16('a', 'f'), HEX_U16('b', '0'), HEX_U16('b', '1'), HEX_U16('b', '2'), HEX_U16('b', '3'),
    HEX_U16('b', '4'), HEX_U16('b', '5'), HEX_U16('b', '6'), HEX_U16('b', '7'), HEX_U16('b', '8'),
    HEX_U16('b', '9'), HEX_U16('b', 'a'), HEX_U16('b', 'b'), HEX_U16('b', 'c'), HEX_U16('b', 'd'),
    HEX_U16('b', 'e'), HEX_U16('b', 'f'), HEX_U16('c', '0'), HEX_U16('c', '1'), HEX_U16('c', '2'),
    HEX_U16('c', '3'), HEX_U16('c', '4'), HEX_U16('c', '5'), HEX_U16('c', '6'), HEX_U16('c', '7'),
    HEX_U16('c', '8'), HEX_U16('c', '9'), HEX_U16('c', 'a'), HEX_U16('c', 'b'), HEX_U16('c', 'c'),
    HEX_U16('c', 'd'), HEX_U16('c', 'e'), HEX_U16('c', 'f'), HEX_U16('d', '0'), HEX_U16('d', '1'),
    HEX_U16('d', '2'), HEX_U16('d', '3'), HEX_U16('d', '4'), HEX_U16('d', '5'), HEX_U16('d', '6'),
    HEX_U16('d', '7'), HEX_U16('d', '8'), HEX_U16('d', '9'), HEX_U16('d', 'a'), HEX_U16('d', 'b'),
    HEX_U16('d', 'c'), HEX_U16('d', 'd'), HEX_U16('d', 'e'), HEX_U16('d', 'f'), HEX_U16('e', '0'),
    HEX_U16('e', '1'), HEX_U16('e', '2'), HEX_U16('e', '3'), HEX_U16('e', '4'), HEX_U16('e', '5'),
    HEX_U16('e', '6'), HEX_U16('e', '7'), HEX_U16('e', '8'), HEX_U16('e', '9'), HEX_U16('e', 'a'),
    HEX_U16('e', 'b'), HEX_U16('e', 'c'), HEX_U16('e', 'd'), HEX_U16('e', 'e'), HEX_U16('e', 'f'),
    HEX_U16('f', '0'), HEX_U16('f', '1'), HEX_U16('f', '2'), HEX_U16('f', '3'), HEX_U16('f', '4'),
    HEX_U16('f', '5'), HEX_U16('f', '6'), HEX_U16('f', '7'), HEX_U16('f', '8'), HEX_U16('f', '9'),
    HEX_U16('f', 'a'), HEX_U16('f', 'b'), HEX_U16('f', 'c'), HEX_U16('f', 'd'), HEX_U16('f', 'e'),
    HEX_U16('f', 'f'),
};
