
from __future__ import annotations

import html
from pathlib import Path
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial


class LupiWebError(Exception):
    pass


class HTMLElement:
    def __init__(self, tag, text=None, attrs=None, children=None, self_closing=False):
        self.tag = str(tag)
        self.text = None if text is None else str(text)
        self.attrs = attrs or {}
        self.children = children or []
        self.self_closing = self_closing

    def add(self, child):
        self.children.append(child)
        return self

    def attr(self, key, value):
        self.attrs[str(key)] = str(value)
        return self

    def cls(self, value):
        self.attrs["class"] = str(value)
        return self

    def style(self, value):
        self.attrs["style"] = str(value)
        return self

    def id(self, value):
        self.attrs["id"] = str(value)
        return self

    def _render_attrs(self):
        if not self.attrs:
            return ""
        parts = []
        for k, v in self.attrs.items():
            parts.append(f' {html.escape(str(k), quote=True)}="{html.escape(str(v), quote=True)}"')
        return "".join(parts)

    def render(self):
        attrs = self._render_attrs()
        if self.self_closing:
            return f"<{self.tag}{attrs}>"
        inner = ""
        if self.text is not None:
            inner += html.escape(self.text)
        for child in self.children:
            if hasattr(child, "render"):
                inner += child.render()
            else:
                inner += html.escape(str(child))
        return f"<{self.tag}{attrs}>{inner}</{self.tag}>"


class HTMLPage:
    def __init__(self, title="Lupi Site"):
        self.title = str(title)
        self.head_items = []
        self.body_items = []

    def add(self, element):
        self.body_items.append(element)
        return self

    def head(self, element):
        self.head_items.append(element)
        return self

    def save(self, path):
        path = Path(str(path))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.render(), encoding="utf-8")
        return str(path)

    def render(self):
        head_html = f"<title>{html.escape(self.title)}</title>"
        for item in self.head_items:
            head_html += item.render() if hasattr(item, "render") else html.escape(str(item))
        body_html = ""
        for item in self.body_items:
            body_html += item.render() if hasattr(item, "render") else html.escape(str(item))
        return "<!DOCTYPE html><html><head><meta charset=\"UTF-8\"><meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">" + head_html + "</head><body>" + body_html + "</body></html>"


class WebRuntime:
    def page(self, title="Lupi Site"):
        return HTMLPage(title)

    def text(self, value):
        return str(value)

    def css(self, content):
        return HTMLElement("style", text=str(content))

    def script(self, content):
        return HTMLElement("script", text=str(content))

    def raw(self, content):
        class RawHTML:
            def __init__(self, value):
                self.value = str(value)
            def render(self):
                return self.value
        return RawHTML(content)

    def element(self, tag, text=None):
        return HTMLElement(tag, text=text)

    def div(self, text=None):
        return HTMLElement("div", text=text)

    def span(self, text=None):
        return HTMLElement("span", text=text)

    def p(self, text=None):
        return HTMLElement("p", text=text)

    def h1(self, text=None):
        return HTMLElement("h1", text=text)

    def h2(self, text=None):
        return HTMLElement("h2", text=text)

    def h3(self, text=None):
        return HTMLElement("h3", text=text)

    def a(self, text, href):
        return HTMLElement("a", text=text, attrs={"href": str(href)})

    def img(self, src, alt=""):
        return HTMLElement("img", attrs={"src": str(src), "alt": str(alt)}, self_closing=True)

    def button(self, text=None):
        return HTMLElement("button", text=text)

    def input(self, type="text", placeholder=""):
        return HTMLElement("input", attrs={"type": str(type), "placeholder": str(placeholder)}, self_closing=True)

    def form(self):
        return HTMLElement("form")

    def ul(self):
        return HTMLElement("ul")

    def li(self, text=None):
        return HTMLElement("li", text=text)

    def nav(self):
        return HTMLElement("nav")

    def section(self):
        return HTMLElement("section")

    def header(self):
        return HTMLElement("header")

    def footer(self):
        return HTMLElement("footer")

    def main(self):
        return HTMLElement("main")

    def serve(self, directory=".", port=8000):
        directory = str(directory)
        port = int(port)
        handler = partial(SimpleHTTPRequestHandler, directory=directory)
        server = ThreadingHTTPServer(("0.0.0.0", port), handler)
        print(f"[Lupi web] Servindo {directory} em http://127.0.0.1:{port}")
        server.serve_forever()
