
from __future__ import annotations

import json
from pathlib import Path
from copy import deepcopy


class LupiDBError(Exception):
    pass


class RowWrapper(dict):
    def __getattr__(self, item):
        try:
            return self[item]
        except KeyError as e:
            raise AttributeError(item) from e


class TableWrapper:
    def __init__(self, database, name: str):
        self.db = database
        self.name = str(name)

    def insert(self, row):
        return self.db.insert(self.name, row)

    def all(self):
        return self.db.all(self.name)

    def find(self, where=None):
        return self.db.find(self.name, where)

    def find_one(self, where=None):
        return self.db.find_one(self.name, where)

    def update(self, where, values):
        return self.db.update(self.name, where, values)

    def delete(self, where=None):
        return self.db.delete(self.name, where)

    def count(self):
        return self.db.count(self.name)


class DBConnection:
    def __init__(self, path: str):
        self.path = Path(str(path))
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if not self.path.exists():
            self._data = {"tables": {}, "_meta": {"version": 1}}
            self._save()
        else:
            self._load()

    def _load(self):
        try:
            self._data = json.loads(self.path.read_text(encoding="utf-8"))
            if "tables" not in self._data:
                self._data = {"tables": {}, "_meta": {"version": 1}}
        except Exception as e:
            raise LupiDBError(f"Falha ao abrir banco: {e}")

    def _save(self):
        self.path.write_text(json.dumps(self._data, ensure_ascii=False, indent=2), encoding="utf-8")

    def close(self):
        self._save()

    def commit(self):
        self._save()

    def rollback(self):
        self._load()

    def create_table(self, name):
        name = str(name)
        if name not in self._data["tables"]:
            self._data["tables"][name] = {"auto_id": 1, "rows": []}
            self._save()
        return TableWrapper(self, name)

    def table(self, name):
        return self.create_table(name)

    def tables(self):
        return list(self._data["tables"].keys())

    def drop_table(self, name):
        name = str(name)
        if name in self._data["tables"]:
            del self._data["tables"][name]
            self._save()
            return True
        return False

    def _ensure_table(self, table):
        table = str(table)
        if table not in self._data["tables"]:
            self._data["tables"][table] = {"auto_id": 1, "rows": []}
        return self._data["tables"][table]

    def _to_plain(self, value):
        if isinstance(value, dict):
            return {str(k): self._to_plain(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self._to_plain(v) for v in value]
        return value

    def _matches(self, row, where):
        if where is None:
            return True
        if not isinstance(where, dict):
            raise LupiDBError("Filtro where deve ser um mapa/dict")
        for key, expected in where.items():
            if row.get(str(key)) != expected:
                return False
        return True

    def insert(self, table, row):
        tbl = self._ensure_table(table)
        if not isinstance(row, dict):
            raise LupiDBError("insert espera um mapa/dict")
        plain = self._to_plain(deepcopy(row))
        if "id" not in plain:
            plain["id"] = tbl["auto_id"]
            tbl["auto_id"] += 1
        else:
            if isinstance(plain["id"], int) and plain["id"] >= tbl["auto_id"]:
                tbl["auto_id"] = plain["id"] + 1
        tbl["rows"].append(plain)
        self._save()
        return RowWrapper(deepcopy(plain))

    def all(self, table):
        tbl = self._ensure_table(table)
        return [RowWrapper(deepcopy(r)) for r in tbl["rows"]]

    def find(self, table, where=None):
        tbl = self._ensure_table(table)
        return [RowWrapper(deepcopy(r)) for r in tbl["rows"] if self._matches(r, where)]

    def find_one(self, table, where=None):
        tbl = self._ensure_table(table)
        for row in tbl["rows"]:
            if self._matches(row, where):
                return RowWrapper(deepcopy(row))
        return None

    def update(self, table, where, values):
        tbl = self._ensure_table(table)
        if not isinstance(values, dict):
            raise LupiDBError("update espera values como mapa/dict")
        values = self._to_plain(values)
        count = 0
        for row in tbl["rows"]:
            if self._matches(row, where):
                for k, v in values.items():
                    row[str(k)] = v
                count += 1
        self._save()
        return count

    def delete(self, table, where=None):
        tbl = self._ensure_table(table)
        original = len(tbl["rows"])
        tbl["rows"] = [r for r in tbl["rows"] if not self._matches(r, where)]
        removed = original - len(tbl["rows"])
        self._save()
        return removed

    def count(self, table):
        tbl = self._ensure_table(table)
        return len(tbl["rows"])


class DBRuntime:
    def open(self, path):
        return DBConnection(str(path))
