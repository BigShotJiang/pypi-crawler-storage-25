
from __future__ import annotations

import argparse
import importlib
import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .discord_runtime import DiscordRuntime
from .game_runtime import GameRuntime
from .game3d_runtime import Game3DRuntime
from .db_runtime import DBRuntime
from .web_runtime import WebRuntime

class LupiError(Exception):
    pass

class ReturnSignal(Exception):
    def __init__(self, value: Any): self.value = value
class BreakSignal(Exception): pass
class ContinueSignal(Exception): pass

@dataclass
class Token:
    type: str
    value: Any
    line: int
    col: int

KEYWORDS = {
    'if','elif','else','while','for','in','fn','return','let',
    'true','false','nil','and','or','not','import','from','as',
    'pyimport','frompy','break','continue'
}

class Lexer:
    def __init__(self, source: str):
        self.source = source.replace('\r\n', '\n').replace('\r', '\n')

    def tokenize(self) -> list[Token]:
        tokens = []
        lines = self.source.split('\n')
        indent_stack = [0]
        bracket_depth = 0

        for line_no, raw in enumerate(lines, start=1):
            if raw.strip() == '':
                continue

            indent = len(raw) - len(raw.lstrip(' '))

            if bracket_depth == 0:
                if indent % 4 != 0:
                    raise LupiError(f'Indentacao deve usar multiplos de 4 espacos (linha {line_no})')
                if indent > indent_stack[-1]:
                    indent_stack.append(indent)
                    tokens.append(Token('INDENT', None, line_no, 1))
                while indent < indent_stack[-1]:
                    indent_stack.pop()
                    tokens.append(Token('DEDENT', None, line_no, 1))
                if indent != indent_stack[-1]:
                    raise LupiError(f'Indentacao inconsistente (linha {line_no})')

            i = indent if bracket_depth == 0 else 0
            line = raw

            while i < len(line):
                ch = line[i]
                col = i + 1

                if ch in ' \t':
                    i += 1
                    continue
                if ch == '#':
                    break

                matched = False
                for text, typ in [
                    ('..=', 'RANGE_INCL'), ('..', 'RANGE'), ('=>', 'ARROW_FN'),
                    ('==', 'EQ'), ('!=', 'NE'), ('<=', 'LE'), ('>=', 'GE'),
                    ('//', 'FLOORDIV'), ('+=', 'PLUSEQ'), ('-=', 'MINUSEQ'),
                    ('*=', 'STAREQ'), ('/=', 'SLASHEQ'), ('%=', 'PERCENTEQ'),
                ]:
                    if line.startswith(text, i):
                        tokens.append(Token(typ, text, line_no, col))
                        i += len(text)
                        matched = True
                        break
                if matched:
                    continue

                single = {
                    '(': 'LPAREN', ')': 'RPAREN',
                    '[': 'LBRACKET', ']': 'RBRACKET',
                    '{': 'LBRACE', '}': 'RBRACE',
                    ',': 'COMMA', ':': 'COLON',
                    '+': 'PLUS', '-': 'MINUS', '*': 'STAR', '/': 'SLASH',
                    '%': 'PERCENT', '=': 'ASSIGN', '<': 'LT', '>': 'GT', '.': 'DOT'
                }
                if ch in single:
                    tok_type = single[ch]
                    tokens.append(Token(tok_type, ch, line_no, col))
                    if ch in '([{':
                        bracket_depth += 1
                    elif ch in ')]}':
                        bracket_depth -= 1
                        if bracket_depth < 0:
                            raise LupiError(f'Agrupamento fechado sem abertura na linha {line_no}')
                    i += 1
                    continue

                if ch in ('"', "'"):
                    quote = ch

                    # suporte a string multilinha com aspas triplas
                    if line.startswith(quote * 3, i):
                        start_line = line_no
                        start_col = col
                        i += 3
                        value = ''
                        closed = False

                        while True:
                            if i >= len(line):
                                value += '\n'
                                line_no += 1
                                if line_no > len(lines):
                                    break
                                line = lines[line_no - 1]
                                i = 0
                                continue

                            if line.startswith(quote * 3, i):
                                i += 3
                                closed = True
                                break

                            if line[i] == '\\':
                                if i + 1 >= len(line):
                                    value += '\\'
                                    i += 1
                                    continue
                                esc = line[i + 1]
                                mapping = {'n': '\n', 't': '\t', '"': '"', "'": "'", '\\': '\\'}
                                value += mapping.get(esc, esc)
                                i += 2
                                continue

                            value += line[i]
                            i += 1

                        if not closed:
                            raise LupiError(f'String multilinha nao fechada perto da linha {start_line}')

                        tokens.append(Token('STRING', value, start_line, start_col))
                        continue

                    i += 1
                    start_pos = i
                    value = ''
                    while i < len(line):
                        if line[i] == '\\':
                            if i + 1 >= len(line):
                                raise LupiError(f'Escape incompleto na linha {line_no}')
                            esc = line[i + 1]
                            mapping = {'n': '\n', 't': '\t', '"': '"', "'": "'", '\\': '\\'}
                            value += mapping.get(esc, esc)
                            i += 2
                            continue
                        if line[i] == quote:
                            break
                        value += line[i]
                        i += 1
                    else:
                        raise LupiError(f'String nao fechada na linha {line_no}')
                    tokens.append(Token('STRING', value, line_no, start_pos))
                    i += 1
                    continue

                if ch.isdigit():
                    start_num = i
                    has_dot = False
                    while i < len(line) and (line[i].isdigit() or (line[i] == '.' and not has_dot and not line.startswith('..', i))):
                        if line[i] == '.':
                            has_dot = True
                        i += 1
                    text = line[start_num:i]
                    tokens.append(Token('NUMBER', float(text) if '.' in text else int(text), line_no, start_num + 1))
                    continue

                if ch.isalpha() or ch == '_':
                    start_ident = i
                    while i < len(line) and (line[i].isalnum() or line[i] == '_'):
                        i += 1
                    text = line[start_ident:i]
                    tok_type = text.upper() if text in KEYWORDS else 'IDENT'
                    tokens.append(Token(tok_type, text, line_no, start_ident + 1))
                    continue

                raise LupiError(f'Caractere inesperado {ch!r} na linha {line_no}, coluna {col}')

            if bracket_depth == 0:
                tokens.append(Token('NEWLINE', None, line_no, len(line) + 1))

        if bracket_depth != 0:
            raise LupiError('Agrupamentos nao fechados no fim do arquivo')

        while len(indent_stack) > 1:
            indent_stack.pop()
            tokens.append(Token('DEDENT', None, len(lines), 1))
        tokens.append(Token('EOF', None, len(lines) + 1, 1))
        return tokens

@dataclass
class Program: body: list
@dataclass
class Block: statements: list
@dataclass
class Number: value: Any
@dataclass
class String: value: str
@dataclass
class Boolean: value: bool
@dataclass
class Nil: pass
@dataclass
class Var: name: str
@dataclass
class ListLiteral: items: list
@dataclass
class MapLiteral: items: list
@dataclass
class Assign: name: str; expr: Any; constant: bool = False
@dataclass
class AugAssign: name: str; op: str; expr: Any
@dataclass
class Binary: left: Any; op: str; right: Any
@dataclass
class Unary: op: str; expr: Any
@dataclass
class Call: callee: Any; args: list
@dataclass
class GetAttr: obj: Any; name: str
@dataclass
class RangeExpr: start: Any; end: Any; inclusive: bool
@dataclass
class Index: obj: Any; index: Any
@dataclass
class IfStmt: branches: list; else_block: Optional[Block]
@dataclass
class WhileStmt: condition: Any; block: Block
@dataclass
class ForStmt: var_name: str; iterable: Any; block: Block
@dataclass
class FnDecl: name: str; params: list; block: Block
@dataclass
class ReturnStmt: expr: Any | None
@dataclass
class ExprStmt: expr: Any
@dataclass
class ImportStmt: module: str; alias: str | None = None
@dataclass
class FromImportStmt: module: str; names: list[str]
@dataclass
class PyImportStmt: module: str; alias: str | None = None
@dataclass
class FromPyImportStmt: module: str; names: list[str]
@dataclass
class BreakStmt: pass
@dataclass
class ContinueStmt: pass

class Parser:
    def __init__(self, tokens: list[Token]):
        self.tokens = tokens
        self.pos = 0
    def current(self): return self.tokens[self.pos]
    def peek(self, offset=1): return self.tokens[min(self.pos + offset, len(self.tokens)-1)]
    def match(self, *types):
        if self.current().type in types:
            tok = self.current(); self.pos += 1; return tok
        return None
    def expect(self, type_, msg=''):
        tok = self.current()
        if tok.type != type_:
            raise LupiError(f'Esperado {type_}, encontrado {tok.type} na linha {tok.line}' + (f': {msg}' if msg else ''))
        self.pos += 1
        return tok
    def skip_newlines(self):
        while self.match('NEWLINE'): pass
    def parse(self):
        body = []
        self.skip_newlines()
        while self.current().type != 'EOF':
            body.append(self.parse_statement())
            self.skip_newlines()
        return Program(body)
    def parse_statement(self):
        tok = self.current()
        if tok.type == 'LET': return self.parse_assignment(True)
        if tok.type == 'IF': return self.parse_if()
        if tok.type == 'WHILE': return self.parse_while()
        if tok.type == 'FOR': return self.parse_for()
        if tok.type == 'FN': return self.parse_fn_decl()
        if tok.type == 'RETURN': return self.parse_return()
        if tok.type == 'IMPORT': return self.parse_import()
        if tok.type == 'FROM': return self.parse_from_import()
        if tok.type == 'PYIMPORT': return self.parse_pyimport()
        if tok.type == 'FROMPY': return self.parse_frompy_import()
        if tok.type == 'BREAK': self.expect('BREAK'); return BreakStmt()
        if tok.type == 'CONTINUE': self.expect('CONTINUE'); return ContinueStmt()
        if tok.type == 'IDENT' and self.peek().type in ('ASSIGN','PLUSEQ','MINUSEQ','STAREQ','SLASHEQ','PERCENTEQ'):
            if self.peek().type == 'ASSIGN': return self.parse_assignment(False)
            name = self.expect('IDENT').value
            op = self.current().type
            self.pos += 1
            return AugAssign(name, op, self.parse_expression())
        return ExprStmt(self.parse_expression())
    def parse_dotted_name(self):
        parts = [self.expect('IDENT').value]
        while self.match('DOT'):
            parts.append(self.expect('IDENT').value)
        return '.'.join(parts)
    def parse_import(self):
        self.expect('IMPORT')
        module = self.parse_dotted_name()
        alias = None
        if self.match('AS'): alias = self.expect('IDENT').value
        return ImportStmt(module, alias)
    def parse_from_import(self):
        self.expect('FROM')
        module = self.parse_dotted_name()
        self.expect('IMPORT')
        names = [self.expect('IDENT').value]
        while self.match('COMMA'):
            names.append(self.expect('IDENT').value)
        return FromImportStmt(module, names)
    def parse_pyimport(self):
        self.expect('PYIMPORT')
        module = self.parse_dotted_name()
        alias = None
        if self.match('AS'): alias = self.expect('IDENT').value
        return PyImportStmt(module, alias)
    def parse_frompy_import(self):
        self.expect('FROMPY')
        module = self.parse_dotted_name()
        self.expect('IMPORT')
        names = [self.expect('IDENT').value]
        while self.match('COMMA'):
            names.append(self.expect('IDENT').value)
        return FromPyImportStmt(module, names)
    def parse_assignment(self, constant=False):
        if constant: self.expect('LET')
        name = self.expect('IDENT').value
        self.expect('ASSIGN')
        return Assign(name, self.parse_expression(), constant)
    def parse_if(self):
        self.expect('IF')
        branches = []
        cond = self.parse_expression()
        self.expect('COLON')
        branches.append((cond, self.parse_block()))
        while self.current().type == 'ELIF':
            self.expect('ELIF')
            cond = self.parse_expression()
            self.expect('COLON')
            branches.append((cond, self.parse_block()))
        else_block = None
        if self.current().type == 'ELSE':
            self.expect('ELSE'); self.expect('COLON')
            else_block = self.parse_block()
        return IfStmt(branches, else_block)
    def parse_while(self):
        self.expect('WHILE')
        cond = self.parse_expression(); self.expect('COLON')
        return WhileStmt(cond, self.parse_block())
    def parse_for(self):
        self.expect('FOR')
        name = self.expect('IDENT').value
        self.expect('IN')
        iterable = self.parse_expression()
        self.expect('COLON')
        return ForStmt(name, iterable, self.parse_block())
    def parse_fn_decl(self):
        self.expect('FN')
        name = self.expect('IDENT').value
        self.expect('LPAREN')
        params = []
        if self.current().type != 'RPAREN':
            params.append(self.expect('IDENT').value)
            while self.match('COMMA'):
                params.append(self.expect('IDENT').value)
        self.expect('RPAREN')
        if self.match('ARROW_FN'):
            return FnDecl(name, params, Block([ReturnStmt(self.parse_expression())]))
        self.expect('COLON')
        return FnDecl(name, params, self.parse_block())
    def parse_return(self):
        self.expect('RETURN')
        if self.current().type in ('NEWLINE','DEDENT','EOF'):
            return ReturnStmt(None)
        return ReturnStmt(self.parse_expression())
    def parse_block(self):
        self.expect('NEWLINE')
        self.expect('INDENT')
        body = []
        self.skip_newlines()
        while self.current().type not in ('DEDENT','EOF'):
            body.append(self.parse_statement())
            self.skip_newlines()
        self.expect('DEDENT')
        return Block(body)
    def parse_expression(self): return self.parse_range()
    def parse_range(self):
        expr = self.parse_or()
        if self.current().type in ('RANGE','RANGE_INCL'):
            inclusive = self.current().type == 'RANGE_INCL'
            self.pos += 1
            return RangeExpr(expr, self.parse_or(), inclusive)
        return expr
    def parse_or(self):
        expr = self.parse_and()
        while self.match('OR'):
            expr = Binary(expr, 'or', self.parse_and())
        return expr
    def parse_and(self):
        expr = self.parse_equality()
        while self.match('AND'):
            expr = Binary(expr, 'and', self.parse_equality())
        return expr
    def parse_equality(self):
        expr = self.parse_comparison()
        while self.current().type in ('EQ','NE'):
            op = self.current().value; self.pos += 1
            expr = Binary(expr, op, self.parse_comparison())
        return expr
    def parse_comparison(self):
        expr = self.parse_term()
        while self.current().type in ('LT','LE','GT','GE'):
            op = self.current().value; self.pos += 1
            expr = Binary(expr, op, self.parse_term())
        return expr
    def parse_term(self):
        expr = self.parse_factor()
        while self.current().type in ('PLUS','MINUS'):
            op = self.current().value; self.pos += 1
            expr = Binary(expr, op, self.parse_factor())
        return expr
    def parse_factor(self):
        expr = self.parse_unary()
        while self.current().type in ('STAR','SLASH','FLOORDIV','PERCENT'):
            op = self.current().value; self.pos += 1
            expr = Binary(expr, op, self.parse_unary())
        return expr
    def parse_unary(self):
        if self.current().type in ('MINUS','NOT'):
            op = self.current().value; self.pos += 1
            return Unary(op, self.parse_unary())
        return self.parse_call()
    def parse_call(self):
        expr = self.parse_primary()
        while True:
            if self.match('LPAREN'):
                args = []
                self.skip_newlines()
                if self.current().type != 'RPAREN':
                    args.append(self.parse_expression())
                    self.skip_newlines()
                    while self.match('COMMA'):
                        self.skip_newlines()
                        args.append(self.parse_expression())
                        self.skip_newlines()
                self.expect('RPAREN')
                expr = Call(expr, args)
            elif self.match('DOT'):
                name = self.expect('IDENT').value
                expr = GetAttr(expr, name)
            elif self.match('LBRACKET'):
                self.skip_newlines()
                idx = self.parse_expression()
                self.skip_newlines()
                self.expect('RBRACKET')
                expr = Index(expr, idx)
            else:
                break
        return expr
    def parse_primary(self):
        tok = self.current()
        if self.match('NUMBER'): return Number(tok.value)
        if self.match('STRING'): return String(tok.value)
        if self.match('TRUE'): return Boolean(True)
        if self.match('FALSE'): return Boolean(False)
        if self.match('NIL'): return Nil()
        if self.match('IDENT'): return Var(tok.value)
        if self.match('LBRACKET'):
            items = []
            self.skip_newlines()
            if self.current().type != 'RBRACKET':
                items.append(self.parse_expression())
                self.skip_newlines()
                while self.match('COMMA'):
                    self.skip_newlines()
                    items.append(self.parse_expression())
                    self.skip_newlines()
            self.expect('RBRACKET')
            return ListLiteral(items)
        if self.match('LBRACE'):
            items = []
            self.skip_newlines()
            if self.current().type != 'RBRACE':
                items.append(self.parse_map_item())
                self.skip_newlines()
                while self.match('COMMA'):
                    self.skip_newlines()
                    items.append(self.parse_map_item())
                    self.skip_newlines()
            self.expect('RBRACE')
            return MapLiteral(items)
        if self.match('LPAREN'):
            expr = self.parse_expression()
            self.expect('RPAREN')
            return expr
        raise LupiError(f'Expressao invalida na linha {tok.line}, coluna {tok.col}')
    def parse_map_item(self):
        if self.current().type == 'IDENT' and self.peek().type == 'COLON':
            key = String(self.expect('IDENT').value)
        else:
            key = self.parse_expression()
        self.expect('COLON')
        return key, self.parse_expression()

class Env:
    def __init__(self, parent=None):
        self.parent = parent
        self.values = {}
        self.constants = set()
    def define(self, name, value, constant=False):
        self.values[name] = value
        if constant: self.constants.add(name)
    def get(self, name):
        if name in self.values: return self.values[name]
        if self.parent: return self.parent.get(name)
        raise LupiError(f'Variavel indefinida: {name}')
    def set(self, name, value):
        if name in self.values:
            if name in self.constants:
                raise LupiError(f'Nao pode alterar constante: {name}')
            self.values[name] = value
            return
        if self.parent:
            self.parent.set(name, value)
            return
        self.values[name] = value

class AttrDict(dict):
    def __getattr__(self, item):
        try: return self[item]
        except KeyError as e: raise AttributeError(item) from e
    def __setattr__(self, key, value): self[key] = value

class LupiModule:
    def __init__(self, name, values):
        self.__name__ = name
        self.__dict__.update(values)

class UserFunction:
    def __init__(self, name, params, block, closure):
        self.name = name
        self.params = params
        self.block = block
        self.closure = closure
    def __call__(self, interp, args):
        if len(args) != len(self.params):
            raise LupiError(f'Funcao {self.name} esperava {len(self.params)} argumentos, recebeu {len(args)}')
        local = Env(self.closure)
        for p, a in zip(self.params, args):
            local.define(p, a)
        try:
            interp.exec_block(self.block, local)
        except ReturnSignal as rs:
            return rs.value
        return None

COLOR_MAP = {
    'black': '\033[30m', 'red': '\033[31m', 'green': '\033[32m', 'yellow': '\033[33m',
    'blue': '\033[34m', 'magenta': '\033[35m', 'cyan': '\033[36m', 'white': '\033[37m',
    'bright_red': '\033[91m', 'bright_green': '\033[92m', 'bright_yellow': '\033[93m',
    'bright_blue': '\033[94m', 'bright_magenta': '\033[95m', 'bright_cyan': '\033[96m'
}
RESET = '\033[0m'

class Interpreter:
    def __init__(self, module_search_dir: str | None = None):
        self.global_env = Env()
        self.env = self.global_env
        self.module_cache = {}
        self.py_module_cache = {}
        self.module_search_dir = Path(module_search_dir or os.getcwd())
        self.discord_runtime = DiscordRuntime(self)
        self.game_runtime = GameRuntime()
        self.game3d_runtime = Game3DRuntime()
        self.db_runtime = DBRuntime()
        self.web_runtime = WebRuntime()
        self._install_builtins()
        self.global_env.define('discord', self.discord_runtime, constant=True)
        self.global_env.define('game', self.game_runtime, constant=True)
        self.global_env.define('game3d', self.game3d_runtime, constant=True)
        self.global_env.define('db', self.db_runtime, constant=True)
        self.global_env.define('web', self.web_runtime, constant=True)
    def _install_builtins(self):
        builtins = {
            'print': self.builtin_print, 'input': self.builtin_input,
            'len': len, 'str': str, 'int': int, 'float': float,
            'color': self.builtin_color, 'printc': self.builtin_printc,
            'range': self.builtin_range,
        }
        for name, fn in builtins.items():
            self.global_env.define(name, fn, constant=True)
    def builtin_print(self, *args): print(*args)
    def builtin_input(self, prompt=''): return input(str(prompt))
    def builtin_color(self, text, color_name='white'):
        return f"{COLOR_MAP.get(str(color_name), '')}{text}{RESET}"
    def builtin_printc(self, text, color_name='white'):
        print(self.builtin_color(text, color_name))
    def builtin_range(self, start, end=None, step=1):
        if end is None: return list(range(start))
        return list(range(start, end, step))
    def run(self, program):
        self.exec_block(Block(program.body), self.global_env)
    def exec_block(self, block, env):
        prev = self.env
        self.env = env
        try:
            for stmt in block.statements:
                self.exec_stmt(stmt)
        finally:
            self.env = prev
    def exec_stmt(self, stmt):
        if isinstance(stmt, Assign):
            value = self.eval_expr(stmt.expr)
            if stmt.constant: self.env.define(stmt.name, value, constant=True)
            elif stmt.name in self.env.values: self.env.set(stmt.name, value)
            else: self.env.define(stmt.name, value)
            return
        if isinstance(stmt, AugAssign):
            current = self.env.get(stmt.name)
            value = self.eval_expr(stmt.expr)
            mapping = {
                'PLUSEQ': current + value, 'MINUSEQ': current - value,
                'STAREQ': current * value, 'SLASHEQ': current / value,
                'PERCENTEQ': current % value,
            }
            self.env.set(stmt.name, mapping[stmt.op]); return
        if isinstance(stmt, ExprStmt): self.eval_expr(stmt.expr); return
        if isinstance(stmt, IfStmt):
            for cond, block in stmt.branches:
                if self.truthy(self.eval_expr(cond)):
                    self.exec_block(block, Env(self.env)); return
            if stmt.else_block: self.exec_block(stmt.else_block, Env(self.env))
            return
        if isinstance(stmt, WhileStmt):
            while self.truthy(self.eval_expr(stmt.condition)):
                try: self.exec_block(stmt.block, Env(self.env))
                except BreakSignal: break
                except ContinueSignal: continue
            return
        if isinstance(stmt, ForStmt):
            for item in self.eval_expr(stmt.iterable):
                loop_env = Env(self.env); loop_env.define(stmt.var_name, item)
                try: self.exec_block(stmt.block, loop_env)
                except BreakSignal: break
                except ContinueSignal: continue
            return
        if isinstance(stmt, FnDecl): self.env.define(stmt.name, UserFunction(stmt.name, stmt.params, stmt.block, self.env)); return
        if isinstance(stmt, ReturnStmt): raise ReturnSignal(self.eval_expr(stmt.expr) if stmt.expr is not None else None)
        if isinstance(stmt, BreakStmt): raise BreakSignal()
        if isinstance(stmt, ContinueStmt): raise ContinueSignal()
        if isinstance(stmt, ImportStmt):
            internal = {'discord': self.discord_runtime, 'game': self.game_runtime, 'game3d': self.game3d_runtime, 'db': self.db_runtime, 'web': self.web_runtime}
            if stmt.module in internal:
                self.env.define(stmt.alias or stmt.module, internal[stmt.module], constant=True); return
            mod = self.load_lupi_module(stmt.module)
            self.env.define(stmt.alias or stmt.module.split('.')[-1], mod); return
        if isinstance(stmt, FromImportStmt):
            internal = {'discord': self.discord_runtime, 'game': self.game_runtime, 'game3d': self.game3d_runtime, 'db': self.db_runtime, 'web': self.web_runtime}
            mod = internal.get(stmt.module) or self.load_lupi_module(stmt.module)
            for name in stmt.names:
                if not hasattr(mod, name): raise LupiError(f'Modulo {stmt.module} nao exporta {name}')
                self.env.define(name, getattr(mod, name))
            return
        if isinstance(stmt, PyImportStmt):
            mod = self.load_py_module(stmt.module)
            self.env.define(stmt.alias or stmt.module.split('.')[-1], mod); return
        if isinstance(stmt, FromPyImportStmt):
            mod = self.load_py_module(stmt.module)
            for name in stmt.names:
                if not hasattr(mod, name): raise LupiError(f'Modulo Python {stmt.module} nao exporta {name}')
                self.env.define(name, getattr(mod, name))
            return
        raise LupiError(f'Statement nao suportado: {stmt}')
    def eval_expr(self, expr):
        if isinstance(expr, Number): return expr.value
        if isinstance(expr, String): return expr.value
        if isinstance(expr, Boolean): return expr.value
        if isinstance(expr, Nil): return None
        if isinstance(expr, Var): return self.env.get(expr.name)
        if isinstance(expr, ListLiteral): return [self.eval_expr(x) for x in expr.items]
        if isinstance(expr, MapLiteral): return AttrDict({self.eval_expr(k): self.eval_expr(v) for k, v in expr.items})
        if isinstance(expr, Unary):
            value = self.eval_expr(expr.expr)
            if expr.op == '-': return -value
            if expr.op == 'not': return not self.truthy(value)
        if isinstance(expr, Binary):
            left = self.eval_expr(expr.left)
            if expr.op == 'and': return self.eval_expr(expr.right) if self.truthy(left) else left
            if expr.op == 'or': return left if self.truthy(left) else self.eval_expr(expr.right)
            right = self.eval_expr(expr.right)
            ops = {
                '+': lambda a,b: a+b, '-': lambda a,b: a-b, '*': lambda a,b: a*b,
                '/': lambda a,b: a/b, '//': lambda a,b: a//b, '%': lambda a,b: a%b,
                '==': lambda a,b: a==b, '!=': lambda a,b: a!=b,
                '<': lambda a,b: a<b, '<=': lambda a,b: a<=b, '>': lambda a,b: a>b, '>=': lambda a,b: a>=b
            }
            return ops[expr.op](left, right)
        if isinstance(expr, Call):
            callee = self.eval_expr(expr.callee)
            args = [self.eval_expr(a) for a in expr.args]
            if isinstance(callee, UserFunction): return callee(self, args)
            if callable(callee): return callee(*args)
            raise LupiError('Tentativa de chamar algo que nao e funcao')
        if isinstance(expr, GetAttr):
            obj = self.eval_expr(expr.obj)
            if isinstance(obj, dict) and expr.name in obj: return obj[expr.name]
            if hasattr(obj, expr.name): return getattr(obj, expr.name)
            raise LupiError(f'Atributo nao encontrado: {expr.name}')
        if isinstance(expr, Index):
            obj = self.eval_expr(expr.obj)
            idx = self.eval_expr(expr.index)
            try:
                return obj[idx]
            except Exception as e:
                raise LupiError(f'Indexacao invalida: {e}')
        if isinstance(expr, RangeExpr):
            start = self.eval_expr(expr.start); end = self.eval_expr(expr.end)
            if not isinstance(start, int) or not isinstance(end, int):
                raise LupiError('Ranges exigem inteiros')
            step = 1 if end >= start else -1
            return list(range(start, end + step, step)) if expr.inclusive else list(range(start, end, step))
        raise LupiError(f'Expressao nao suportada: {expr}')
    def truthy(self, value): return not (value is None or value is False)
    def load_lupi_module(self, module_name):
        if module_name in self.module_cache: return self.module_cache[module_name]
        path = self.module_search_dir / f'{module_name}.lp'
        if not path.exists(): raise LupiError(f'Modulo Lupi nao encontrado: {path}')
        source = path.read_text(encoding='utf-8')
        sub = Interpreter(module_search_dir=str(path.parent))
        sub.run(Parser(Lexer(source).tokenize()).parse())
        exported = {k:v for k,v in sub.global_env.values.items() if not k.startswith('_')}
        mod = LupiModule(module_name, exported); self.module_cache[module_name] = mod; return mod
    def load_py_module(self, module_name):
        if module_name in self.py_module_cache: return self.py_module_cache[module_name]
        try: mod = importlib.import_module(module_name)
        except ImportError as e:
            raise LupiError(f"Modulo Python '{module_name}' nao encontrado. Instale a dependencia com: lupi install {module_name}") from e
        self.py_module_cache[module_name] = mod; return mod

def run_lupi_file(path: str):
    p = Path(path)
    if not p.exists(): raise LupiError(f'Arquivo nao encontrado: {path}')
    program = Parser(Lexer(p.read_text(encoding="utf-8")).tokenize()).parse()
    Interpreter(module_search_dir=str(p.parent)).run(program)

def lupi_install(packages: list[str]):
    if not packages: raise LupiError('Informe pelo menos um pacote')
    cmd = [sys.executable, '-m', 'pip', 'install', *packages]
    print('Executando:', ' '.join(cmd))
    raise SystemExit(subprocess.run(cmd).returncode)

def build_cli():
    parser = argparse.ArgumentParser(prog='lupi', description='Lupi CLI')
    sub = parser.add_subparsers(dest='command', required=True)
    runp = sub.add_parser('run', help='Executa arquivo .lp'); runp.add_argument('file')
    inst = sub.add_parser('install', help='Instala dependencias Python'); inst.add_argument('packages', nargs='+')
    sub.add_parser('version', help='Mostra versao')
    return parser

def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv and argv[0].endswith('.lp'): argv = ['run', *argv]
    parser = build_cli(); args = parser.parse_args(argv)
    try:
        if args.command == 'run': run_lupi_file(args.file)
        elif args.command == 'install': lupi_install(args.packages)
        elif args.command == 'version': print('Lupi v1.6.9')
    except LupiError as e:
        print(f'[Erro Lupi] {e}', file=sys.stderr)
        raise SystemExit(1)
