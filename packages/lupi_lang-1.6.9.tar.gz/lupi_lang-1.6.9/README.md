
# Lupi 1.6.9

Lupi é uma linguagem de script experimental com:

- `discord` interno com comandos, embeds, botões, selects, modais e slash commands
- `game` para 2D (stub)
- `game3d` para 3D via Ursina (bridge inicial)
- `pyimport` / `frompy`
- `input`, `color`, `printc`
- execução por `lupi arquivo.lp`

## Instalação

```bash
python -m pip install .
```

Extras opcionais:

```bash
python -m pip install ".[discord]"
python -m pip install ".[game3d]"
```
