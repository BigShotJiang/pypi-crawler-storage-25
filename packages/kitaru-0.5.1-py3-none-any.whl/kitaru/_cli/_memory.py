"""Memory CLI commands."""

from __future__ import annotations

import json
from typing import Annotated, Any, Literal

from cyclopts import Parameter

from kitaru._interface_errors import run_with_cli_error_boundary
from kitaru.cli_output import CLIOutputFormat

from . import memory_app
from ._helpers import (
    DEFAULT_LIST_PAGE,
    DEFAULT_LIST_SIZE,
    OutputFormatOption,
    PaginationPageOption,
    PaginationSizeOption,
    SnapshotSection,
    _emit_json_item,
    _emit_json_items,
    _emit_pagination_note,
    _emit_snapshot_sections,
    _emit_table,
    _emit_warning,
    _exit_with_error,
    _facade_module,
    _format_table_timestamp,
    _paginate_items,
    _print_success,
    _resolve_output_format,
    _validate_pagination,
)


def _require_scope(
    scope: str | None,
    *,
    command: str,
    output: CLIOutputFormat,
) -> str:
    """Validate that ``--scope`` was provided, or exit with a helpful hint."""
    if scope is not None:
        return scope
    _exit_with_error(
        command,
        "Missing required option `--scope`. "
        "Run `kitaru memory scopes` to see available scopes.",
        output=output,
    )
    raise SystemExit(1)  # unreachable; satisfies type checker


def _require_scope_type(
    scope_type: Literal["namespace", "flow", "execution"] | None,
    *,
    command: str,
    output: CLIOutputFormat,
) -> Literal["namespace", "flow", "execution"]:
    """Validate that ``--scope-type`` was provided for typed memory identity."""
    if scope_type is not None:
        return scope_type
    _exit_with_error(
        command,
        "Missing required option `--scope-type`. "
        "Run `kitaru memory scopes` to see available typed scopes.",
        output=output,
    )
    raise SystemExit(1)  # unreachable; satisfies type checker


def _memory_scope_label(scope: str, scope_type: str) -> str:
    """Render a memory scope label that includes its type."""
    return f"{scope} ({scope_type})"


def _memory_timestamp(value: str | None) -> str:
    """Render an optional serialized timestamp for CLI output."""
    if not value or not value.strip():
        return "not available"
    return _format_table_timestamp(value)


def _memory_execution_label(execution_id: str | None) -> str:
    """Render the producing execution label for one memory entry."""
    return execution_id or "detached"


def _memory_flow_label(flow_value: str | None) -> str:
    """Render optional flow-context values for CLI output."""
    return flow_value or "not indexed"


def _stringify_memory_value(value: Any, *, value_format: str) -> str:
    """Render one loaded memory value for text-mode CLI output."""
    if value_format == "json":
        rendered = json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False)
    else:
        rendered = str(value)
    return rendered.replace("\n", "\n    ")


def _parse_memory_cli_value(raw_value: str) -> Any:
    """Parse a CLI value as JSON when possible, else preserve the raw string."""
    try:
        return json.loads(raw_value)
    except json.JSONDecodeError:
        return raw_value


def _memory_entry_rows(entry: dict[str, Any]) -> list[tuple[str, str]]:
    """Build metadata rows for one serialized memory entry."""
    rows = [
        ("Key", str(entry["key"])),
        ("Scope", str(entry["scope"])),
        ("Scope type", str(entry["scope_type"])),
        ("Version", str(entry["version"])),
        ("Value type", str(entry["value_type"])),
        ("Deleted", "yes" if entry["is_deleted"] else "no"),
        ("Created", _memory_timestamp(entry.get("created_at"))),
        ("Execution", _memory_execution_label(entry.get("execution_id"))),
    ]
    if (
        entry.get("scope_type") == "execution"
        or entry.get("flow_id")
        or entry.get("flow_name")
    ):
        rows.extend(
            [
                ("Flow ID", _memory_flow_label(entry.get("flow_id"))),
                ("Flow Name", _memory_flow_label(entry.get("flow_name"))),
            ]
        )
    rows.append(("Artifact ID", str(entry["artifact_id"])))
    return rows


def _memory_list_rows(entries: list[dict[str, Any]]) -> list[list[str]]:
    """Build table rows for `kitaru memory list`."""
    return [
        [
            str(entry["key"]),
            str(entry["value_type"]),
            str(entry["version"]),
            _memory_timestamp(entry.get("created_at")),
            str(entry["scope_type"]),
            _memory_execution_label(entry.get("execution_id")),
        ]
        for entry in entries
    ]


def _memory_history_rows(entries: list[dict[str, Any]]) -> list[list[str]]:
    """Build table rows for `kitaru memory history`."""
    return [
        [
            str(entry["version"]),
            "yes" if entry["is_deleted"] else "no",
            str(entry["value_type"]),
            _memory_timestamp(entry.get("created_at")),
            _memory_execution_label(entry.get("execution_id")),
            str(entry["artifact_id"]),
        ]
        for entry in entries
    ]


def _memory_value_section(payload: dict[str, Any]) -> SnapshotSection:
    """Build the value section for `kitaru memory get` text output.

    Handles three cases:
        - ``value_available is False``: metadata is present but the backing
          artifact could not be loaded from the current environment; render
          structured diagnostics from ``value_unavailable``.
        - legacy payloads missing ``value`` / ``value_format``: surface a
          generic "unavailable" placeholder so downstream formatters don't
          crash. Retained for compatibility with older transport payloads.
        - a value is present: render format + stringified value.
    """
    if payload.get("value_available") is False:
        diagnostics = payload.get("value_unavailable") or {}
        rows: list[tuple[str, str]] = [
            ("Status", "unavailable"),
            (
                "Error",
                str(diagnostics.get("error_type", "unknown")),
            ),
            (
                "Cause",
                str(diagnostics.get("cause_type", "unknown")),
            ),
            (
                "Reason",
                str(
                    diagnostics.get(
                        "message",
                        (
                            "Memory value exists but its artifact could not "
                            "be loaded from this environment."
                        ),
                    )
                ),
            ),
        ]
        return SnapshotSection(title="Value", rows=rows)

    value_format = payload.get("value_format")
    if value_format is None or "value" not in payload:
        return SnapshotSection(
            title="Value",
            rows=[
                ("Status", "unavailable"),
                (
                    "Reason",
                    (
                        "The backend returned memory metadata without a "
                        "materialized value."
                    ),
                ),
            ],
        )

    return SnapshotSection(
        title="Value",
        rows=[
            ("Format", str(value_format)),
            (
                "Value",
                _stringify_memory_value(
                    payload["value"],
                    value_format=str(value_format),
                ),
            ),
        ],
    )


def _memory_scopes_rows(scopes: list[dict[str, Any]]) -> list[list[str]]:
    """Build table rows for `kitaru memory scopes`."""
    return [
        [
            str(s["scope"]),
            str(s["scope_type"]),
            str(s["entry_count"]),
        ]
        for s in scopes
    ]


def _memory_source_mode_label(payload: dict[str, Any]) -> str:
    """Render a human-readable compaction source mode label."""
    source_mode = payload.get("source_mode")
    if source_mode is not None:
        return str(source_mode)
    if payload.get("operation") == "compact":
        return "legacy"
    return "-"


def _memory_reindex_mode_label(payload: dict[str, Any]) -> str:
    """Render the effective reindex mode for text output."""
    return "dry-run" if payload.get("dry_run", True) else "apply"


def _memory_reindex_status_label(payload: dict[str, Any]) -> str:
    """Summarize what the reindex result means for the operator."""
    if payload.get("dry_run", True):
        if payload.get("versions_needing_updates", 0) == 0:
            if payload.get("issues_count", 0) == 0:
                return "up to date; no action needed"
            return "no tag updates needed; inspect issues below"
        return "preview only; rerun with --apply to persist tag additions"
    if payload.get("issues_count", 0) == 0:
        return "completed"
    return "completed with issues; rerun is safe"


def _memory_reindex_issue_rows(payload: dict[str, Any]) -> list[tuple[str, str]]:
    """Build text rows for sampled reindex issues."""
    rows: list[tuple[str, str]] = []
    for index, issue in enumerate(payload.get("issue_samples", []), start=1):
        scope = issue.get("scope")
        key = issue.get("key")
        if scope and key:
            location = f"{scope}/{key}"
        else:
            location = str(issue.get("artifact_name", "unknown artifact"))
        rows.append(
            (
                f"Issue {index}",
                (
                    f"{location} ({issue.get('artifact_id', 'unknown id')}) — "
                    f"{issue.get('reason', 'unknown issue')}"
                ),
            )
        )
    return rows


@memory_app.command(name="scopes")
def scopes_(
    *,
    output: OutputFormatOption = "text",
) -> None:
    """List all discovered memory scopes."""
    command = "memory.scopes"
    output_format = _resolve_output_format(output)
    facade = _facade_module()
    scopes = run_with_cli_error_boundary(
        lambda: facade.scopes_memory_payload(
            facade.KitaruClient(),
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_items(command, scopes, output=output_format)
        return

    _emit_table(
        "Kitaru memory scopes",
        ["Scope", "Scope Type", "Entries"],
        _memory_scopes_rows(scopes),
        empty_message="no memory scopes found",
    )


@memory_app.command
def list_(
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope to inspect. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(help="Memory scope type to inspect. [required]", show_default=False),
    ] = None,
    page: PaginationPageOption = DEFAULT_LIST_PAGE,
    size: PaginationSizeOption = DEFAULT_LIST_SIZE,
    output: OutputFormatOption = "text",
) -> None:
    """List active memory entries for one explicit scope."""
    command = "memory.list"
    output_format = _resolve_output_format(output)
    page, size = _validate_pagination(
        page=page,
        size=size,
        command=command,
        output=output_format,
    )
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    facade = _facade_module()
    entries = run_with_cli_error_boundary(
        lambda: facade.list_memory_payload(
            facade.KitaruClient(),
            scope=scope,
            scope_type=scope_type,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    visible_entries = _paginate_items(entries, page=page, size=size)

    if output_format == CLIOutputFormat.JSON:
        _emit_json_items(command, visible_entries, output=output_format)
        return

    empty_message = (
        f"none found for scope `{_memory_scope_label(scope, scope_type)}`. "
        "Run `kitaru memory scopes` to see available scopes."
    )
    if entries and not visible_entries:
        empty_message = f"no items on page {page}"

    _emit_table(
        f"Kitaru memory ({_memory_scope_label(scope, scope_type)})",
        ["Key", "Type", "Version", "Updated", "Scope Type", "Execution"],
        _memory_list_rows(visible_entries),
        empty_message=empty_message,
    )
    _emit_pagination_note(
        page=page,
        size=size,
        returned_count=len(visible_entries),
        total_count=len(entries),
        output=output_format,
    )


@memory_app.command(name="get")
def get_(
    key: Annotated[
        str,
        Parameter(
            help="Memory key to read.",
            allow_leading_hyphen=True,
        ),
    ],
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope to read from. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(
            help="Memory scope type to read from. [required]", show_default=False
        ),
    ] = None,
    strict: Annotated[
        bool,
        Parameter(
            help=(
                "Fail with a typed error when the memory value exists but "
                "its artifact cannot be loaded from this environment. "
                "Default behavior returns metadata with a "
                "`value_available: false` marker instead."
            ),
        ),
    ] = False,
    output: OutputFormatOption = "text",
) -> None:
    """Read the latest value for one memory key in one explicit scope."""
    command = "memory.get"
    output_format = _resolve_output_format(output)
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    facade = _facade_module()
    payload = run_with_cli_error_boundary(
        lambda: facade.get_memory_payload(
            facade.KitaruClient(),
            key=key,
            scope=scope,
            scope_type=scope_type,
            strict=strict,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if payload is None:
        _exit_with_error(
            command,
            (
                f"No memory entry found for key `{key}` in scope "
                f"`{_memory_scope_label(scope, scope_type)}`."
            ),
            output=output_format,
        )

    if payload.get("value_available") is False:
        diagnostics = payload.get("value_unavailable") or {}
        _emit_warning(
            "Memory value is unavailable; showing metadata only.",
            output=output_format,
            detail=str(
                diagnostics.get(
                    "message",
                    (
                        "Memory entry exists but its artifact could not be "
                        "loaded from this environment."
                    ),
                )
            ),
        )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_item(command, payload, output=output_format)
        return

    _emit_snapshot_sections(
        "Kitaru memory",
        [
            SnapshotSection(title="Metadata", rows=_memory_entry_rows(payload)),
            _memory_value_section(payload),
        ],
    )


@memory_app.command(name="set")
def set_(
    key: Annotated[
        str,
        Parameter(
            help="Memory key to write.",
            allow_leading_hyphen=True,
        ),
    ],
    value: Annotated[
        str,
        Parameter(
            help=(
                "Memory value. Parsed as JSON when possible; otherwise stored as a "
                "raw string."
            ),
            allow_leading_hyphen=True,
        ),
    ],
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope to write into. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(
            help="Memory scope type to write into. [required]",
            show_default=False,
        ),
    ] = None,
    output: OutputFormatOption = "text",
) -> None:
    """Write one memory value into one explicit scope."""
    command = "memory.set"
    output_format = _resolve_output_format(output)
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    facade = _facade_module()
    payload = run_with_cli_error_boundary(
        lambda: facade.set_memory_payload(
            facade.KitaruClient(),
            key=key,
            value=_parse_memory_cli_value(value),
            scope=scope,
            scope_type=scope_type,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_item(command, payload, output=output_format)
        return

    _print_success(
        f"Saved memory: {payload['key']}",
        detail=(
            f"Scope: {payload['scope']} ({payload['scope_type']}) | "
            f"Version: {payload['version']} | Type: {payload['value_type']}"
        ),
    )


@memory_app.command(name="delete")
def delete_(
    key: Annotated[
        str,
        Parameter(
            help="Memory key to soft-delete.",
            allow_leading_hyphen=True,
        ),
    ],
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope to delete from. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(
            help="Memory scope type to delete from. [required]", show_default=False
        ),
    ] = None,
    output: OutputFormatOption = "text",
) -> None:
    """Soft-delete one memory key from one explicit scope."""
    command = "memory.delete"
    output_format = _resolve_output_format(output)
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    facade = _facade_module()
    payload = run_with_cli_error_boundary(
        lambda: facade.delete_memory_payload(
            facade.KitaruClient(),
            key=key,
            scope=scope,
            scope_type=scope_type,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if payload is None:
        _exit_with_error(
            command,
            (
                f"No memory entry found for key `{key}` in scope "
                f"`{_memory_scope_label(scope, scope_type)}`."
            ),
            output=output_format,
        )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_item(command, payload, output=output_format)
        return

    _print_success(
        f"Deleted memory: {payload['key']}",
        detail=(
            f"Scope: {payload['scope']} ({payload['scope_type']}) | "
            f"Tombstone version: {payload['version']}"
        ),
    )


@memory_app.command(name="purge")
def purge_(
    key: Annotated[
        str,
        Parameter(
            help="Memory key to purge old versions of.",
            allow_leading_hyphen=True,
        ),
    ],
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(help="Memory scope type. [required]", show_default=False),
    ] = None,
    keep: Annotated[
        int | None,
        Parameter(
            help=("Number of newest versions to retain. Omit to delete all versions."),
        ),
    ] = None,
    output: OutputFormatOption = "text",
) -> None:
    """Physically delete old versions of one memory key.

    Omit --keep to delete all versions (including the current value).
    Use --keep N to retain the newest N versions and delete the rest.
    An audit record is written to the compaction log when versions are deleted.
    """
    command = "memory.purge"
    output_format = _resolve_output_format(output)
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    facade = _facade_module()
    payload = run_with_cli_error_boundary(
        lambda: facade.purge_memory_payload(
            facade.KitaruClient(),
            key=key,
            scope=scope,
            scope_type=scope_type,
            keep=keep,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_item(command, payload, output=output_format)
        return

    _print_success(
        f"Purged memory: {key}",
        detail=(
            f"Scope: {_memory_scope_label(payload['scope'], payload['scope_type'])} | "
            f"Versions deleted: {payload['versions_deleted']} | "
            f"Keys affected: {payload['keys_affected']}"
        ),
    )


@memory_app.command(name="purge-scope")
def purge_scope_(
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope to purge. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(help="Memory scope type to purge. [required]", show_default=False),
    ] = None,
    keep: Annotated[
        int | None,
        Parameter(
            help=(
                "Number of newest versions to retain per key. "
                "Omit to delete all versions."
            ),
        ),
    ] = None,
    include_deleted: Annotated[
        bool,
        Parameter(
            help="Also purge tombstoned (soft-deleted) keys entirely.",
        ),
    ] = False,
    output: OutputFormatOption = "text",
) -> None:
    """Purge old versions across all keys in one scope.

    Active keys retain the newest --keep versions; older versions are physically
    deleted. Tombstoned (soft-deleted) keys are skipped unless --include-deleted
    is set, in which case all their versions are removed entirely.
    The internal compaction audit log is never purged by this command.
    """
    command = "memory.purge-scope"
    output_format = _resolve_output_format(output)
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    facade = _facade_module()
    payload = run_with_cli_error_boundary(
        lambda: facade.purge_scope_memory_payload(
            facade.KitaruClient(),
            scope=scope,
            scope_type=scope_type,
            keep=keep,
            include_deleted=include_deleted,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_item(command, payload, output=output_format)
        return

    _print_success(
        f"Purged scope: {_memory_scope_label(scope, scope_type)}",
        detail=(
            f"Versions deleted: {payload['versions_deleted']} | "
            f"Keys affected: {payload['keys_affected']}"
        ),
    )


@memory_app.command(name="reindex")
def reindex_(
    *,
    apply: Annotated[
        bool,
        Parameter(
            help=(
                "Persist missing scope-type and flow-membership tags for "
                "historical memory artifacts. By default this command runs "
                "as a dry-run preview."
            ),
        ),
    ] = False,
    output: OutputFormatOption = "text",
) -> None:
    """Backfill indexing tags for historical memory artifacts.

    New execution-scope writes are indexed automatically at write time. This
    command is for older data that was created before that behavior shipped.
    By default it performs a dry-run preview; rerun with --apply to persist any
    missing tags in the active project. The reindex is additive only: it adds
    missing discovery tags and does not rewrite stored values or metadata.
    """
    command = "memory.reindex"
    output_format = _resolve_output_format(output)
    facade = _facade_module()
    payload = run_with_cli_error_boundary(
        lambda: facade.reindex_memory_payload(
            facade.KitaruClient(),
            apply=apply,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_item(command, payload, output=output_format)
        return

    sections = [
        SnapshotSection(
            title="Summary",
            rows=[
                ("Mode", _memory_reindex_mode_label(payload)),
                ("Versions scanned", str(payload["versions_scanned"])),
                (
                    "Execution-scope versions",
                    str(payload["execution_scope_versions_scanned"]),
                ),
                ("Already indexed", str(payload["already_indexed"])),
                (
                    "Versions needing updates",
                    str(payload["versions_needing_updates"]),
                ),
                ("Versions updated", str(payload["versions_updated"])),
                (
                    "Scope-type tags identified",
                    str(payload["scope_type_tags_identified"]),
                ),
                ("Flow tags identified", str(payload["flow_tags_identified"])),
                ("Scope-type tags added", str(payload["scope_type_tags_added"])),
                ("Flow tags added", str(payload["flow_tags_added"])),
                ("Issues", str(payload["issues_count"])),
            ],
        ),
        SnapshotSection(
            title="Status",
            rows=[("Result", _memory_reindex_status_label(payload))],
        ),
    ]
    issue_rows = _memory_reindex_issue_rows(payload)
    if issue_rows:
        sections.append(SnapshotSection(title="Issue samples", rows=issue_rows))

    _emit_snapshot_sections("Kitaru memory reindex", sections)


@memory_app.command(name="compact")
def compact_(
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(help="Memory scope type. [required]", show_default=False),
    ] = None,
    key: Annotated[
        str | None,
        Parameter(
            help=(
                "Single key to compact. Defaults to summarizing the current "
                "value; use --source-mode history for full version history."
            ),
            allow_leading_hyphen=True,
        ),
    ] = None,
    keys: Annotated[
        tuple[str, ...] | None,
        Parameter(
            help=(
                "Multiple keys whose current values should be merged into one summary."
            ),
            allow_leading_hyphen=True,
        ),
    ] = None,
    source_mode: Annotated[
        Literal["current", "history"],
        Parameter(
            help=(
                "Source selection for single-key compaction: current (default) "
                "or history. Multi-key compaction supports current only."
            ),
        ),
    ] = "current",
    target_key: Annotated[
        str | None,
        Parameter(
            help=(
                "Key to write the summary into. "
                "Defaults to the source key in single-key mode."
            ),
            allow_leading_hyphen=True,
        ),
    ] = None,
    instruction: Annotated[
        str | None,
        Parameter(
            help="Custom instruction for the LLM summarization.",
        ),
    ] = None,
    model: Annotated[
        str | None,
        Parameter(
            help="LLM model to use for summarization.",
        ),
    ] = None,
    max_tokens: Annotated[
        int | None,
        Parameter(
            help="Maximum response tokens for the LLM summarization.",
        ),
    ] = None,
    output: OutputFormatOption = "text",
) -> None:
    """Summarize memory values using an LLM and write the result as a new version.

    Use --key for single-key mode (defaults to summarizing the current value of
    that key) or --keys for multi-key mode (summarizes the current value of
    each listed key). Use --source-mode history with --key to summarize the
    full non-deleted version history of one key instead. --key and --keys are
    mutually exclusive. Multi-key mode requires --target-key and supports only
    --source-mode current. In single-key mode, the summary is written to the
    source key unless --target-key is specified. Source entries are not deleted;
    run purge separately if you want to reclaim old history.
    """
    command = "memory.compact"
    output_format = _resolve_output_format(output)
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    keys_list = list(keys) if keys else None
    facade = _facade_module()
    payload = run_with_cli_error_boundary(
        lambda: facade.compact_memory_payload(
            facade.KitaruClient(),
            scope=scope,
            scope_type=scope_type,
            key=key,
            keys=keys_list,
            source_mode=source_mode,
            target_key=target_key,
            instruction=instruction,
            model=model,
            max_tokens=max_tokens,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_item(command, payload, output=output_format)
        return

    entry = payload["entry"]
    _print_success(
        f"Compacted memory into: {entry['key']}",
        detail=(
            f"Scope: {_memory_scope_label(entry['scope'], entry['scope_type'])} | "
            f"Version: {entry['version']} | "
            f"Sources read: {payload['sources_read']} | "
            f"Source mode: {_memory_source_mode_label(payload['compaction_record'])}"
        ),
    )


@memory_app.command(name="compaction-log")
def compaction_log_(
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope to inspect. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(help="Memory scope type to inspect. [required]", show_default=False),
    ] = None,
    output: OutputFormatOption = "text",
) -> None:
    """Show the compaction audit log for one scope.

    Displays all compact and purge audit records for the given scope,
    newest first. Each record shows what operation was performed, which
    keys were involved, and the resulting target or deletion counts.
    """
    command = "memory.compaction-log"
    output_format = _resolve_output_format(output)
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    facade = _facade_module()
    entries = run_with_cli_error_boundary(
        lambda: facade.compaction_log_memory_payload(
            facade.KitaruClient(),
            scope=scope,
            scope_type=scope_type,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_items(command, entries, output=output_format)
        return

    _emit_table(
        f"Kitaru compaction log ({_memory_scope_label(scope, scope_type)})",
        [
            "Operation",
            "Source Mode",
            "Timestamp",
            "Source Keys",
            "Target Key",
            "Versions Deleted",
            "Model",
        ],
        [
            [
                str(e["operation"]),
                _memory_source_mode_label(e),
                _memory_timestamp(e.get("timestamp")),
                ", ".join(e.get("source_keys", [])),
                str(e.get("target_key") or "-"),
                str(e["versions_deleted"]),
                str(e.get("model") or "-"),
            ]
            for e in entries
        ],
        empty_message=(
            f"no compaction records found for scope "
            f"`{_memory_scope_label(scope, scope_type)}`."
        ),
    )


@memory_app.command(name="history")
def history_(
    key: Annotated[
        str,
        Parameter(
            help="Memory key whose version history to inspect.",
            allow_leading_hyphen=True,
        ),
    ],
    *,
    scope: Annotated[
        str | None,
        Parameter(help="Memory scope to inspect. [required]", show_default=False),
    ] = None,
    scope_type: Annotated[
        Literal["namespace", "flow", "execution"] | None,
        Parameter(help="Memory scope type to inspect. [required]", show_default=False),
    ] = None,
    output: OutputFormatOption = "text",
) -> None:
    """Show all versions for one memory key in one explicit scope."""
    command = "memory.history"
    output_format = _resolve_output_format(output)
    scope = _require_scope(scope, command=command, output=output_format)
    scope_type = _require_scope_type(
        scope_type,
        command=command,
        output=output_format,
    )
    facade = _facade_module()
    entries = run_with_cli_error_boundary(
        lambda: facade.history_memory_payload(
            facade.KitaruClient(),
            key=key,
            scope=scope,
            scope_type=scope_type,
        ),
        command=command,
        output=output_format,
        exit_with_error=_exit_with_error,
    )

    if not entries:
        _exit_with_error(
            command,
            (
                f"No memory history found for key `{key}` in scope "
                f"`{_memory_scope_label(scope, scope_type)}`."
            ),
            output=output_format,
        )

    if output_format == CLIOutputFormat.JSON:
        _emit_json_items(command, entries, output=output_format)
        return

    _emit_table(
        f"Kitaru memory history ({_memory_scope_label(scope, scope_type)}/{key})",
        ["Version", "Deleted", "Type", "Updated", "Execution", "Artifact ID"],
        _memory_history_rows(entries),
    )
