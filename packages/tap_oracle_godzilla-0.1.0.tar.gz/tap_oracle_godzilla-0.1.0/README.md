# tap-oracle

Singer tap for Oracle, built with the Meltano Singer SDK.

This connector is intended as a modern replacement path for legacy Oracle taps.
It supports Python 3.10+ and uses `oracledb` with SQLAlchemy reflection.

## Features

- Automatic stream discovery from Oracle schemas and tables.
- Oracle connection support with either `service_name` (preferred) or `sid`.
- Schema and table filtering for faster discovery on large instances.
- Oracle-aware type mapping for common types such as `NUMBER`, `CLOB`, and `BLOB`.
- Compatible with Meltano pipelines and standard Singer targets.

## Requirements

- Python 3.10+
- Network access to Oracle listener (VPN may be required in corporate networks)
- Oracle credentials with read access to the target schema(s)

## Installation

### Local editable install (recommended for development)

```bash
pip install -e .
```

### Verify installation

```bash
tap-oracle --about
```

## Configuration

### Required settings

- `host`: Oracle hostname or IP
- `user`: Oracle username
- `password`: Oracle password
- one of:
	- `service_name` (recommended)
	- `sid` (legacy)

### Optional settings

- `port` (default: `1521`)
- `filter_schemas` (comma-separated schemas)
- `filter_tables` (array of `SCHEMA-TABLE` strings)
- `cursor_array_size` (default: `1000`)
- `thick_mode` (default: `false`)
- `https_proxy`
- `start_date`

### Environment variable names

- `TAP_ORACLE_HOST`
- `TAP_ORACLE_PORT`
- `TAP_ORACLE_USER`
- `TAP_ORACLE_PASSWORD`
- `TAP_ORACLE_SERVICE_NAME`
- `TAP_ORACLE_SID`
- `TAP_ORACLE_FILTER_SCHEMAS`
- `TAP_ORACLE_FILTER_TABLES`
- `TAP_ORACLE_CURSOR_ARRAY_SIZE`
- `TAP_ORACLE_THICK_MODE`

## Usage

### Discover catalog

```bash
tap-oracle --config config.json --discover > catalog.json
```

### Run sync

```bash
tap-oracle --config config.json --catalog catalog.json
```

## Meltano usage

Add this extractor from a local checkout:

```bash
meltano add extractor tap-oracle --custom
```

Example project-level invocation:

```bash
meltano invoke tap-oracle --about
meltano invoke tap-oracle --discover > catalog.json
```

Select schema streams:

```bash
meltano select tap-oracle "nightly_platerforme-*" "*"
```

Run pipeline with a target loader:

```bash
meltano run tap-oracle target-postgres
```

## Oracle notes

- If you see `DPY-6003` / `ORA-12505`, verify whether your database expects `service_name` or `sid`.
- `service_name` is preferred and supported explicitly by this connector.
- Warnings for unknown Oracle-specific types (for example `XMLTYPE`, `SDO_GEOMETRY`) during discovery are usually non-fatal.

## Development

Install development dependencies:

```bash
uv sync
```

Run tests:

```bash
uv run pytest
```

Run type checks:

```bash
uv run mypy tap_oracle tests
```

## License

Apache-2.0
