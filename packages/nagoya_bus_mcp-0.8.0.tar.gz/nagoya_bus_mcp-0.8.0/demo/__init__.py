"""Module for demo scripts."""
