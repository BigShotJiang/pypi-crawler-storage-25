#
# SPDX-FileCopyrightText: Dumpyara Project
# SPDX-License-Identifier: GPL-3.0-or-later
#

from os import chmod, walk, unlink

try:
    from os import chflags  # type: ignore
except Exception:

    def chflags(*args, **kwargs):
        pass


from pathlib import Path
from shutil import rmtree
from typing import Callable, TypeVar

T = TypeVar("T")


def get_recursive_files_list(
    path: Path,
    relative: bool = False,
    cast_func: Callable[[Path], T] = Path,
):
    for currentpath, _, files in walk(path):
        for file in files:
            file_path = Path(currentpath) / file
            if relative:
                file_path = file_path.relative_to(path)

            yield cast_func(file_path)


def rmtree_recursive(name: Path):
    def onerror(func, path, exc_info):
        if issubclass(exc_info[0], PermissionError):

            def resetperms(path):
                chflags(path, 0)
                chmod(path, 0o700)

            try:
                if path != name:
                    resetperms(name.parent)
                resetperms(path)

                try:
                    unlink(path)
                # PermissionError is raised on FreeBSD for directories
                except (IsADirectoryError, PermissionError):
                    rmtree_recursive(path)
            except FileNotFoundError:
                pass
        elif issubclass(exc_info[0], FileNotFoundError):
            pass
        else:
            raise

    rmtree(str(name), onerror=onerror)
