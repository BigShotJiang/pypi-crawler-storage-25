"""Character-level vocabulary with NFKC normalization."""

from __future__ import annotations

import unicodedata
from dataclasses import dataclass

import torch

PAD = 0
SOS = 1
EOS = 2
SPECIAL_TOKENS = ["<pad>", "<sos>", "<eos>"]


def normalize_text(text: str) -> str:
    return unicodedata.normalize("NFKC", text)


@dataclass
class CharVocab:
    stoi: dict[str, int]
    itos: list[str]

    @property
    def size(self) -> int:
        return len(self.itos)

    @classmethod
    def from_texts(cls, texts: list[str]) -> CharVocab:
        chars = sorted({char for text in texts for char in normalize_text(text)})
        itos = SPECIAL_TOKENS + [char for char in chars if char not in SPECIAL_TOKENS]
        stoi = {char: idx for idx, char in enumerate(itos)}
        return cls(stoi=stoi, itos=itos)

    def encode(
        self, text: str, *, max_len: int, device: torch.device | None = None,
    ) -> torch.Tensor:
        """Encode *text* into a padded long tensor ``[SOS, ...chars, EOS, PAD...]``."""
        text = normalize_text(text)
        token_ids = [SOS] + [self.stoi[char] for char in text if char in self.stoi] + [EOS]
        token_ids = token_ids[:max_len]
        padding_length = max_len - len(token_ids)
        if padding_length > 0:
            token_ids.extend([PAD] * padding_length)
        tensor = torch.tensor(token_ids, dtype=torch.long)
        return tensor if device is None else tensor.to(device)

    def encode_ids(self, text: str, max_len: int) -> list[int]:
        text = normalize_text(text)
        token_ids = [SOS] + [self.stoi[char] for char in text if char in self.stoi] + [EOS]
        token_ids = token_ids[:max_len]
        padding_length = max_len - len(token_ids)
        if padding_length > 0:
            token_ids.extend([PAD] * padding_length)
        return token_ids

    def decode(self, token_ids: list[int]) -> str:
        chars: list[str] = []
        for token_id in token_ids:
            if token_id in (PAD, SOS):
                continue
            if token_id == EOS:
                break
            if 0 <= token_id < len(self.itos):
                chars.append(self.itos[token_id])
        return "".join(chars)

    def to_dict(self) -> dict:
        return {"stoi": self.stoi, "itos": self.itos}

    @classmethod
    def from_dict(cls, data: dict) -> CharVocab:
        return cls(stoi=data["stoi"], itos=data["itos"])
