# chartoken

Character-level vocabulary and morphological feature encoding for NLP pipelines.

## Installation

```bash
pip install chartoken
```

Requires Python >= 3.14 and PyTorch >= 2.0.

## Features

- **CharVocab** — character-level tokenizer with NFKC normalization, SOS/EOS/PAD tokens
- **FeatureVocab** — morphological feature encoder (UniMorph tag set) with padding masks
- Encode text to padded tensors or plain ID lists
- Serialize/deserialize vocabularies for checkpoint compatibility

## Quick Start

```python
from chartoken import CharVocab, FeatureVocab

# Build vocab from texts
vocab = CharVocab.from_texts(["hello", "world"])
ids = vocab.encode("hello", max_len=32)
print(vocab.decode(ids.tolist()))  # "hello"

# Feature vocab
feat_vocab = FeatureVocab.from_tags([["V", "IND", "PRS"], ["N", "SG"]])
feat_ids, feat_mask = feat_vocab.encode(["V", "IND"], max_features=12)
```

## License

See LICENSE file in the repository root.
