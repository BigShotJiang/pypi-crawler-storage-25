from __future__ import annotations

from collections import namedtuple

from .constants import NUMBER_BYTE_LENGTH
from .security.errors import ValidationError

# coincurve (libsecp256k1 bindings) is imported lazily inside the
# functions that need it. This keeps the ``curve`` namedtuple constant
# at module top-level importable from ``pyrxd.utils`` without dragging
# in coincurve — which has no pure-Python wheel and so can't install
# under Pyodide. The browser-hosted inspect tool imports
# ``pyrxd.utils.encode_int`` etc. but never touches the elliptic-curve
# arithmetic paths below.

Point = namedtuple("Point", "x y")

EllipticCurve = namedtuple("EllipticCurve", "name p a b g n h")
curve = EllipticCurve(
    name="Secp256k1",
    p=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F,
    a=0,
    b=7,
    g=Point(
        0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798,
        0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8,
    ),
    n=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141,
    h=1,
)


def on_curve(point: Point | None) -> bool:
    """
    :returns: True if the given point lies on the elliptic curve
    """
    if point is None:
        # None represents the point at infinity.
        return True
    x, y = point
    return (y * y - x * x * x - curve.a * x - curve.b) % curve.p == 0


def curve_negative(point: Point | None) -> Point | None:
    """
    :returns: -point
    """
    if not on_curve(point):
        raise ValidationError("point is not on the curve")
    if point is None:
        # -0 = 0
        return None
    x, y = point
    r = Point(x, -y % curve.p)
    if not on_curve(r):
        raise ValidationError("computed negative point is not on the curve")
    return r


def curve_add(p: Point | None, q: Point | None) -> Point | None:
    """
    :returns: the result of p + q according to the group law
    """
    if not on_curve(p):
        raise ValidationError("point p is not on the curve")
    if not on_curve(q):
        raise ValidationError("point q is not on the curve")
    if p is None:
        # 0 + q = q
        return q
    if q is None:
        # p + 0 = p
        return p
    if p == curve_negative(q):
        # p == -q
        return None
    # p != -q
    from coincurve import PublicKey as CcPublicKey  # lazy: see module docstring

    r = Point(*CcPublicKey.from_point(*p).combine([CcPublicKey.from_point(*q)]).point())
    if not on_curve(r):
        raise ValidationError("computed sum point is not on the curve")
    return r


def curve_multiply(scalar: int, point: Point | None) -> Point | None:
    """
    multiply the given point by a scalar
    """
    if not on_curve(point):
        raise ValidationError("point is not on the curve")
    if scalar % curve.n == 0 or point is None:
        return None
    if scalar < 0:
        # k * point = -k * (-point)
        return curve_multiply(-scalar, curve_negative(point))
    from coincurve import PublicKey as CcPublicKey  # lazy: see module docstring

    r = Point(*CcPublicKey.from_point(*point).multiply((scalar % curve.n).to_bytes(NUMBER_BYTE_LENGTH, "big")).point())
    if not on_curve(r):
        raise ValidationError("computed product point is not on the curve")
    return r


def curve_get_y(x: int, even: bool) -> int:
    """
    point (x, y) lies on the curve, calculate y from the given x and the parity of y
    """
    y_square = (x * x * x + curve.a * x + curve.b) % curve.p
    y = pow(y_square, (curve.p + 1) // 4, curve.p)
    return y if (y + (0 if even else 1)) % 2 == 0 else -y % curve.p
