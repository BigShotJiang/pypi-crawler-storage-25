from __future__ import annotations

import sys
from importlib.metadata import PackageNotFoundError, version as package_version

__all__ = ["main"]


def _resolve_cli_version() -> str:
    try:
        return package_version("acw")
    except PackageNotFoundError:
        return "0.0.0-dev"


def _print_lightweight_help() -> None:
    print("usage: acw [-h] [-V] {generate,config,prompt,doctor} ...")
    print()
    print("Generate commit messages from git changes with AI.")
    print()
    print("positional arguments:")
    print("  {generate,config,prompt,doctor}")
    print("    generate            Generate commit messages from git changes.")
    print("    config              Manage ACW configuration.")
    print("    prompt              Manage prompt templates.")
    print("    doctor              Check local provider connectivity.")
    print()
    print("options:")
    print("  -h, --help            show this help message and exit")
    print("  -V, --version         show program's version number and exit")


def main() -> int:
    argv = sys.argv[1:]
    if argv[:1] in (["-V"], ["--version"]):
        print(f"acw {_resolve_cli_version()}")
        return 0
    if argv[:1] in (["-h"], ["--help"]):
        _print_lightweight_help()
        return 0

    from acw.cli import main as cli_main

    return cli_main()
