"""Module seed for the compta_esms plugin.

Demonstrates :func:`piilot.sdk.modules.register_module` — idempotent
upsert on ``modules.modules`` keyed on ``module_slug``. Re-installs
refresh the row's descriptive columns (name, icon, description, …)
while preserving the UUID so user grants / bookmarks stay stable.

Agent templates (``register_template``) and tools come in v0.3+ /
v0.4+. Stays out of v0.1 — KISS.
"""

from __future__ import annotations

from piilot.sdk.modules import register_module


def wire_seeds() -> None:
    """Register the plugin's module(s).

    Called from ``Plugin.register()``. Buffered by the SDK and upserted
    by the plugin loader after ``register()`` returns — safe to call on
    every boot.
    """
    # NB: ``config`` (JSONB) isn't passed here — psycopg2's
    # default-adapter path in the SDK's _upsert_module doesn't wrap
    # dicts in Json(), so handing one would fail at the cursor with
    # ``can't adapt type 'dict'``. Same workaround as
    # piilot-pack-compta 0.2.1. Frontend resolves the module by slug
    # via ``registerModuleView('compta_esms.hello', ...)``.
    register_module(
        {
            "slug": "compta_esms.hello",
            "module_name": "Compta ESMS — Hello",
            "description": (
                "Module hello-world du plugin compta-ESMS — counter de clics "
                "persistant en PG. Sera remplacé par les modules métier (M22, "
                "dossier ESMS, balance) dans les releases v0.5+."
            ),
            "icon": "hand",
            "category": "vertical",
            "status": "published",
        }
    )
