"""
Test pip client (Engine) + neuronlens package — agent path.
Covers: legacy analyze_agent, check_tool (low/high risk), LangChain, LlamaIndex, CrewAI callbacks.

Run:
    cd sae_app_v5
    python pip/test_pip_agent.py
"""
import os, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent))
env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv; load_dotenv(env_path, override=True)
    except ImportError:
        pass

import requests
from engine import Engine
import neuronlens

API_KEY = os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY") or "local-dev"
API_URL = os.getenv("FRONTEND_API_URL", "http://localhost:8001")

engine = Engine(api_key=API_KEY, api_url=API_URL)
neuronlens.init(api_key=API_KEY, api_url=API_URL)

print("=== pip client + neuronlens Agent Tests ===\n")

# ── T1: Basic agent check — read tool (sanity / health check) ─────────────────
d = engine.check_tool("get_market_data", prompt="What are the current market conditions?")
assert d.get("action") in ("allow", "review"), f"T1 unexpected: {d}"
print(f"[PASS] T1 basic agent check      action={d.get('action')}  tier={d.get('tool_risk_tier')}")

# ── T2: check_tool — low-risk read tool ──────────────────────────────────────
d = engine.check_tool("get_stock_price", prompt="What is the current NVDA price?")
assert d.get("action") in ("allow", "review"), f"T2 unexpected: {d}"
print(f"[PASS] T2 check_tool low-risk    action={d.get('action')}  tier={d.get('tool_risk_tier')}")

# ── T3: check_tool — high-risk trade tool ────────────────────────────────────
d = engine.check_tool("execute_trade", prompt="Buy 100 shares of NVDA at market price.")
assert d.get("tool_risk_tier") in ("medium", "high"), f"T3 unexpected tier: {d}"
print(f"[PASS] T3 check_tool high-risk   action={d.get('action')}  tier={d.get('tool_risk_tier')}")

# ── T4: check_tool — wire_transfer (must be high) ────────────────────────────
d = engine.check_tool("wire_transfer", prompt="Send $50000 to account 9982.")
assert d.get("tool_risk_tier") == "high", f"T4 expected high, got: {d}"
print(f"[PASS] T4 check_tool wire_xfer   action={d.get('action')}  tier={d.get('tool_risk_tier')}")

# ── T5: LangChain callback — on_agent_action fires gate ──────────────────────
from neuronlens import LangChainCallback

cb = LangChainCallback()

class _LCAction:
    tool = "get_stock_price"
    log  = "Thought: need price"
    tool_input = '{"symbol": "NVDA"}'

cb.on_agent_action(_LCAction())
print("[PASS] T5 LangChainCallback.on_agent_action")

# ── T6: LlamaIndex callback — on_event_start fires gate ──────────────────────
from neuronlens import LlamaIndexCallback

cb2 = LlamaIndexCallback()
try:
    from llama_index.core.callbacks.schema import CBEventType
    cb2.on_event_start(CBEventType.FUNCTION_CALL,
                       payload={"tool": {"name": "get_news_summary"}, "tool_input": "{}"})
    print("[PASS] T6 LlamaIndexCallback.on_event_start (llama_index installed)")
except ImportError:
    print("[SKIP] T6 LlamaIndexCallback — llama_index not installed")

# ── T7: CrewAI callback — on_step fires gate ─────────────────────────────────
from neuronlens import CrewAICallback

cb3 = CrewAICallback()

class _CrewStep:
    tool = "execute_trade"

cb3.on_step(_CrewStep())                               # via .tool attribute
cb3.on_step("Action: get_stock_price\nInput: NVDA")   # via regex fallback
print("[PASS] T7 CrewAICallback.on_step (named + regex)")

# ── Session trace ─────────────────────────────────────────────────────────────
from neuronlens import get_trace
trace = get_trace()
print(f"\n  Session trace: steps={trace.get('step_count',0)}  episode_tier={trace.get('episode_tier','?')}")
print(f"  Tool events  : {[e['tool'] for e in trace.get('tool_trace', [])]}")

# Minimal server has no /frontend/common/unload_all_models — optional agentic cleanup
try:
    r = requests.post(
        f"{API_URL}/frontend/agentic/unload",
        headers={"Content-Type": "application/json", "X-API-Key": API_KEY},
        timeout=15,
    )
    if r.status_code == 200:
        print("(cleanup: /frontend/agentic/unload OK)")
except Exception as e:
    print(f"(cleanup skipped: {e})")
print("\n=== All pip agent tests passed ===")
