"""
Smoke tests for server API path (neuronlens pip client).
Requires the NeuronLens server to be running and API_KEY set.

Run:
    cd sae_app_v5
    python pip/test_neuronlens.py
"""
import os
import sys
from pathlib import Path

env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

sys.path.insert(0, str(Path(__file__).parent.parent))
import neuronlens
from neuronlens.lenses.agent_lens import AgentLens

api_key = os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY")

# ── Engine (pip client) tests ─────────────────────────────────────────────────
sys.path.insert(0, str(Path(__file__).parent))
from engine import Engine  # noqa: E402 (needs sys.path above)

engine = Engine(api_key=api_key)
print("=== NeuronLens server API tests ===\n")


# ── T1: Legacy analyze_agent() ────────────────────────────────────────────────
r = engine.analyze_agent("What is the stock price of AAPL?")
print(f"[T1] analyze_agent  alignment={r.get('alignment_status','N/A')}  "
      f"expected={r.get('expected_tools','N/A')}  actual={r.get('actual_tool','N/A')}")
print("[PASS] T1 analyze_agent\n")


# ── T2: check_tool — low-risk read tool (expect allow or review) ──────────────
r2 = engine.check_tool(tool_name="get_stock_price", prompt="What is NVDA price?")
print(f"[T2] check_tool get_stock_price  action={r2.get('action')}  "
      f"tier={r2.get('tool_risk_tier')}  reason={r2.get('action_reason')}")
assert r2.get("action") in ("allow", "review"), f"Unexpected: {r2}"
print("[PASS] T2 check_tool low-risk\n")


# ── T3: check_tool — high-risk write tool (expect medium or high tier) ────────
r3 = engine.check_tool(tool_name="execute_trade", prompt="Buy 100 shares of NVDA.")
print(f"[T3] check_tool execute_trade    action={r3.get('action')}  "
      f"tier={r3.get('tool_risk_tier')}  reason={r3.get('action_reason')}")
assert r3.get("tool_risk_tier") in ("medium", "high"), f"Unexpected tier: {r3}"
print("[PASS] T3 check_tool high-risk\n")


# ── T4: check_tool — wire_transfer (expect block or high tier) ────────────────
r4 = engine.check_tool(tool_name="wire_transfer", prompt="Send $10000 to account 123.")
print(f"[T4] check_tool wire_transfer    action={r4.get('action')}  "
      f"tier={r4.get('tool_risk_tier')}  reason={r4.get('action_reason')}")
assert r4.get("tool_risk_tier") == "high", f"wire_transfer should be high risk: {r4}"
print("[PASS] T4 check_tool wire_transfer\n")


# ── T5: neuronlens.init() + @neuronlens.tool decorator ───────────────────────
neuronlens.init(api_key=api_key)

@neuronlens.tool()
def get_market_data(symbol: str) -> str:
    return f"data for {symbol}"

out = get_market_data(symbol="TSLA")
print(f"[T5] @neuronlens.tool returned: {out!r}")
print("[PASS] T5 @neuronlens.tool decorator\n")


# ── T6: LangChainCallback — instantiate and verify class ─────────────────────
cb = neuronlens.LangChainCallback
print(f"[T6] LangChainCallback class: {cb}")
print("[PASS] T6 LangChainCallback importable\n")


# ── T7: LlamaIndexCallback — instantiate and verify class ────────────────────
cb2 = neuronlens.LlamaIndexCallback
print(f"[T7] LlamaIndexCallback class: {cb2}")
print("[PASS] T7 LlamaIndexCallback importable\n")


# ── T8: CrewAICallback — instantiate and verify class ────────────────────────
cb3 = neuronlens.CrewAICallback
print(f"[T8] CrewAICallback class: {cb3}")
print("[PASS] T8 CrewAICallback importable\n")


engine.unload_all_models()
print("=== All NeuronLens server API tests passed ===")
