"""
Test neuronlens Search & Steer functions (Neuronpedia-backed).
Connects to the local unified server (default: http://localhost:8001).
NEURONPEDIA_API_KEY must be set in .env or the environment.
"""
import os
import sys
from pathlib import Path

# Ensure this pip/ directory is first on sys.path so 'import neuronlens'
# resolves to pip/__init__.py (which exports Engine), not sae_app_v5/neuronlens/.
_pip_dir = str(Path(__file__).parent.resolve())
if sys.path[0] != _pip_dir:
    sys.path.insert(0, _pip_dir)

# Load .env from project root before importing neuronlens
env_path = Path(__file__).parent.parent / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

import neuronlens

# ── Engine init ──────────────────────────────────────────────────────────────
# Use NEURONLENS_API_KEY / API_KEY if set; fall back to "local" for auth-disabled servers.
_api_key = os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY") or "local"
_api_url = os.getenv("NEURONLENS_API_URL", "http://localhost:8001")
engine = neuronlens.Engine(api_key=_api_key, api_url=_api_url)

NP_KEY = os.getenv("NEURONPEDIA_API_KEY")

# ── Test constants ────────────────────────────────────────────────────────────
MODEL_ID    = "gemma-2-9b-it"
TEST_QUERY  = "stock market investing and trading"
TEST_PROMPT = "What is the outlook for the stock market this quarter?"

# Known stable finance feature on Gemma-2-9B-IT (layer 9, feature 6824 = "stock market investing")
STEER_FEATURE = {
    "modelId": MODEL_ID,
    "layer":   "9-gemmascope-res-131k",
    "index":   6824,
    "strength": 150,
}

# ── Helpers ───────────────────────────────────────────────────────────────────
def section(title: str):
    print(f"\n{'─' * 60}")
    print(f"  {title}")
    print('─' * 60)

def show_feature(f: dict, prefix: str = "  "):
    """Print a Neuronpedia feature entry in a readable way."""
    index  = f.get("index",  f.get("feature_id", f.get("id", "?")))
    layer  = f.get("layer",  "?")
    # explanation text can live in different keys depending on the API response shape
    expl   = (f.get("description")
              or (f.get("explanations") or [{}])[0].get("description", "")
              or f.get("label", ""))
    score  = f.get("score")
    score_str = f"  score={score:.3f}" if isinstance(score, float) else ""
    print(f"{prefix}index={index}  layer={layer}{score_str}")
    if expl:
        print(f"{prefix}  └─ {str(expl)[:80]}")

# ═════════════════════════════════════════════════════════════════════════════
# 1. Environment check
# ═════════════════════════════════════════════════════════════════════════════
section("1 · Neuronpedia API key")
if NP_KEY:
    print(f"  ✓ NEURONPEDIA_API_KEY loaded  ({NP_KEY[:8]}...)")
else:
    print("  ✗ NEURONPEDIA_API_KEY not set — steering / search will fail on the server")

# ═════════════════════════════════════════════════════════════════════════════
# 2. Available models
# ═════════════════════════════════════════════════════════════════════════════
section("2 · Available Neuronpedia models  (engine.get_searchsteer_models)")
try:
    resp   = engine.get_searchsteer_models()
    models = resp.get("models", [])
    print(f"  {len(models)} models available:")
    for m in models:
        marker = " ◀ default" if m["id"] == MODEL_ID else ""
        print(f"    {m['id']:<40}  {m['name']}{marker}")
    assert any(m["id"] == MODEL_ID for m in models), f"{MODEL_ID} missing from model list"
    print(f"\n  ✓ {MODEL_ID} confirmed present")
except Exception as e:
    print(f"  ✗ {e}")

# ═════════════════════════════════════════════════════════════════════════════
# 3. Finance presets  — show feature activations (strength values)
# ═════════════════════════════════════════════════════════════════════════════
section("3 · Finance presets + feature activation strengths  (engine.get_searchsteer_presets)")
try:
    resp    = engine.get_searchsteer_presets()
    presets = resp.get("presets", [])
    print(f"  {len(presets)} presets:\n")
    for p in presets:
        print(f"  [{p['name']}]")
        for f in p.get("features", []):
            print(f"    model={f['modelId']}  layer={f['layer']}  index={f['index']}")
            print(f"    explanation : {f.get('explanation', 'N/A')}")
            print(f"    strength    : {f['strength']}  ← SAE activation magnitude for steering")
            print()
    print("  ✓ presets loaded")
except Exception as e:
    print(f"  ✗ {e}")

# ═════════════════════════════════════════════════════════════════════════════
# 4. Feature search — Neuronpedia semantic search
# ═════════════════════════════════════════════════════════════════════════════
section(f"4 · Feature search  (engine.search_features)  query='{TEST_QUERY}'")
searched_features = []
try:
    searched_features = engine.search_features(TEST_QUERY, k=5, model_id=MODEL_ID)
    raw = searched_features
    if isinstance(raw, dict):
        raw = raw.get("features", raw.get("results", []))
    print(f"  {len(raw)} features returned:\n")
    for i, f in enumerate(raw):
        show_feature(f, prefix=f"  [{i+1}] ")
    print(f"\n  ✓ search returned {len(raw)} results")
    searched_features = raw
except Exception as e:
    print(f"  ✗ {e}")

# ═════════════════════════════════════════════════════════════════════════════
# 5. Steer with a known finance feature — show activation effect on text
# ═════════════════════════════════════════════════════════════════════════════
section("5 · Steer features  (engine.steer_features)  — activation effect on output")
print(f"  Model  : {MODEL_ID}")
print(f"  Feature: index={STEER_FEATURE['index']}  layer={STEER_FEATURE['layer']}")
print(f"  Prompt : {TEST_PROMPT}")
print(f"  Strength (SAE activation magnitude) : {STEER_FEATURE['strength']}")
print()
try:
    result = engine.steer_features(
        prompt=TEST_PROMPT,
        features=[STEER_FEATURE],
        model=MODEL_ID,
    )
    orig    = result.get("original_text", "")
    steered = result.get("steered_text",  "")
    metrics = result.get("metrics", {})

    print(f"  original_text : {orig[:120]}")
    print(f"  steered_text  : {steered[:120]}")
    print(f"  has_steering  : {result.get('has_steering')}")
    print()
    print("  ── Word-diff metrics (activation effect on vocabulary) ──")
    print(f"  word_overlap   : {metrics.get('word_overlap', 'N/A'):.3f}" if isinstance(metrics.get("word_overlap"), float) else f"  word_overlap   : {metrics.get('word_overlap', 'N/A')}")
    print(f"  text_len_diff  : {metrics.get('text_length_diff', 'N/A')} chars")
    added   = metrics.get("added_words",   [])
    removed = metrics.get("removed_words", [])
    print(f"  words added    : {added[:10]}{'...' if len(added)   > 10 else ''}")
    print(f"  words removed  : {removed[:10]}{'...' if len(removed) > 10 else ''}")
    print(f"\n  ✓ steer completed  has_steering={result.get('has_steering')}")
except Exception as e:
    print(f"  ✗ {e}")

# ═════════════════════════════════════════════════════════════════════════════
# 6. Steer with a search result feature (if search succeeded)
# ═════════════════════════════════════════════════════════════════════════════
if searched_features:
    section("6 · Steer with top search result feature")
    top = searched_features[0]
    # Build a valid Neuronpedia steer feature from search result
    steer_f = {
        "modelId": top.get("modelId", MODEL_ID),
        "layer":   top.get("layer",   "9-gemmascope-res-131k"),
        "index":   top.get("index",   top.get("feature_id", 0)),
        "strength": 120,
    }
    print(f"  Feature: index={steer_f['index']}  layer={steer_f['layer']}  strength={steer_f['strength']}")
    expl = (top.get("description") or
            (top.get("explanations") or [{}])[0].get("description", "") or
            top.get("label", ""))
    if expl:
        print(f"  Explanation: {str(expl)[:80]}")
    print()
    try:
        result = engine.steer_features(
            prompt=TEST_PROMPT,
            features=[steer_f],
            model=MODEL_ID,
        )
        metrics = result.get("metrics", {})
        print(f"  original : {result.get('original_text','')[:100]}")
        print(f"  steered  : {result.get('steered_text', '')[:100]}")
        overlap = metrics.get("word_overlap")
        print(f"  word_overlap={overlap:.3f}" if isinstance(overlap, float) else f"  word_overlap={overlap}")
        print(f"  ✓ steer from search result OK")
    except Exception as e:
        print(f"  ✗ {e}")

# ═════════════════════════════════════════════════════════════════════════════
print("\n" + "═" * 60)
print("  Search & Steer (Neuronpedia) tests complete")
print("═" * 60 + "\n")
