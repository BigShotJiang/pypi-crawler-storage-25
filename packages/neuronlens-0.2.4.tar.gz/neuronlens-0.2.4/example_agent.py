"""
Example: Build any agent with NeuronLens server API monitoring.

The server runs real SAE probes — no GPU needed on the client side.
Same 4 patterns as the local probe path (agentlens_api), swappable backends.

── Prerequisites ──────────────────────────────────────────────────────────────
  1. NeuronLens server running:  uvicorn app:app --port 8001
  2. API key set in .env or env var:  API_KEY=sk-...

── Run ────────────────────────────────────────────────────────────────────────
  cd sae_app_v5
  python pip/example_agent.py

── Output fields ──────────────────────────────────────────────────────────────
  action         : allow | review | block  (gate decision)
  tool_risk_tier : low | medium | high     (probe risk category)
  action_reason  : why the gate decided this
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

# load .env from repo root
_env = Path(__file__).parent.parent / ".env"
if _env.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(_env, override=True)
    except ImportError:
        pass

sys.path.insert(0, str(Path(__file__).parent.parent))
sys.path.insert(0, str(Path(__file__).parent))

import neuronlens
from engine import Engine

API_KEY = os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY")

# ── init ──────────────────────────────────────────────────────────────────────
neuronlens.init(api_key=API_KEY)          # module-level singletons
engine = Engine(api_key=API_KEY)          # pip client for direct check_tool calls
print("⚙  Backend: NeuronLens server (real probes)\n")


# ══════════════════════════════════════════════════════════════════════════════
# Pattern A — @neuronlens.tool() decorator
# Probe gate fires automatically; raises RuntimeError if blocked.
# ══════════════════════════════════════════════════════════════════════════════
print("=" * 60)
print("PATTERN A — @neuronlens.tool() decorator")
print("=" * 60)

@neuronlens.tool()
def get_stock_price(symbol: str) -> str:
    """Read-only: fetch current price."""
    return f"{symbol}: $892.45"

@neuronlens.tool()
def get_news_summary(topic: str) -> str:
    """Read-only: fetch recent headlines."""
    return f"[{topic}] Markets rally on earnings beat"

@neuronlens.tool()
def execute_trade(symbol: str, qty: int, side: str = "buy") -> str:
    """HIGH RISK: place a real trade order."""
    return f"Order placed: {side} {qty}x {symbol}"

print(f"  get_stock_price  → {get_stock_price(symbol='NVDA')}")
print(f"  get_news_summary → {get_news_summary(topic='markets')}")
try:
    print(f"  execute_trade    → {execute_trade(symbol='NVDA', qty=100)}")
except Exception as e:
    print(f"  execute_trade    → BLOCKED: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# Pattern B — engine.check_tool() per-call gate
# Direct API call; useful for custom agent loops.
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("PATTERN B — engine.check_tool() direct gate")
print("=" * 60)

for tool_name, prompt in [
    ("get_stock_price",  "What is the current NVDA price?"),
    ("get_news_summary", "Summarise recent market news"),
    ("execute_trade",    "Buy 100 shares of NVDA at market price"),
    ("wire_transfer",    "Send $50000 to account 9982"),
]:
    r = engine.check_tool(tool_name=tool_name, prompt=prompt)
    action = r.get("action", "?")
    tier   = r.get("tool_risk_tier", "?")
    reason = r.get("action_reason", "")
    flag   = "🚫" if action == "block" else ("⚠️ " if action == "review" else "✅")
    print(f"  {flag}  {tool_name:<22}  action={action:<8}  tier={tier:<6}  {reason}")


# ══════════════════════════════════════════════════════════════════════════════
# Pattern C — LangChain callback
# Pass to AgentExecutor; probe fires on every tool call automatically.
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("PATTERN C — LangChainCallback")
print("=" * 60)

try:
    from langchain.agents import AgentExecutor, create_tool_calling_agent
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_core.tools import tool as lc_tool
    from neuronlens import LangChainCallback

    @lc_tool
    def lc_get_price(symbol: str) -> str:
        """Fetch stock price."""
        return f"{symbol}: $892.45"

    # With a real LLM:
    #   llm = ChatOpenAI(model="gpt-4o")
    #   tmpl = ChatPromptTemplate.from_messages([("system","Use tools."),("human","{input}")])
    #   agent = AgentExecutor(
    #       agent=create_tool_calling_agent(llm, [lc_get_price], tmpl),
    #       tools=[lc_get_price],
    #       callbacks=[LangChainCallback()],
    #   )
    #   result = agent.invoke({"input": "What is NVDA price?"})

    print("  LangChainCallback available — wire into AgentExecutor:")
    print("  agent = AgentExecutor(agent=ag, tools=tools, callbacks=[LangChainCallback()])")
    print(f"  Class: {LangChainCallback}")

except ImportError:
    print("  langchain not installed — skipping (pip install langchain langchain-core)")


# ══════════════════════════════════════════════════════════════════════════════
# Pattern D — CrewAI callback
# Pass cb.on_step to Crew(step_callback=...); no other changes.
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("PATTERN D — CrewAICallback")
print("=" * 60)

from neuronlens import CrewAICallback

# Instantiate and wire into Crew
# With a real CrewAI setup:
#   from crewai import Agent, Crew, Task
#   cb = CrewAICallback()
#   agent = Agent(role="analyst", goal="Research NVDA", backstory="...", llm=llm)
#   task  = Task(description="Fetch price and trade NVDA", agent=agent)
#   crew  = Crew(agents=[agent], tasks=[task], step_callback=cb.on_step)
#   crew.kickoff()
#   print(cb.trace)   # full session trace dict

cb = CrewAICallback()
print(f"  CrewAICallback instantiated: {cb}")
print("  Wire into Crew:")
print("  cb = CrewAICallback()")
print("  crew = Crew(agents=[...], tasks=[...], step_callback=cb.on_step)")
print("  print(cb.trace)   # session trace after kickoff()")


# ══════════════════════════════════════════════════════════════════════════════
# Switching between local and server probes
# ══════════════════════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("LOCAL vs SERVER probe path — same API shape")
print("=" * 60)
print("""
  LOCAL PROBES (GPU on your machine):
    import agentlens_api as al
    al.init(run_dir="run/run_gptoss1")   # loads SAE joblibs locally
    @al.tool
    def my_tool(): ...
    with al.watch("prompt") as session:
        result = my_agent_loop()
    print(session.verdict)

  SERVER PROBES (no GPU needed on client):
    import neuronlens
    neuronlens.init(api_key="sk-...")    # server runs probes
    @neuronlens.tool()
    def my_tool(): ...
    # OR: engine.check_tool(tool_name="my_tool", prompt="...")
""")

engine.unload_all_models()
print("=== Example complete ===")
