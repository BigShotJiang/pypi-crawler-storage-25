"""
Configuration management for NeuronLens package.
Handles API URL, timeout, and environment variable settings.
"""
import os
import json
from pathlib import Path
from typing import Optional


def _get_config_file_path() -> Path:
    """Get path to neuronlens config.json file"""
    return Path(__file__).parent / "config.json"


def _load_config() -> dict:
    """Load configuration from config.json file"""
    config_file = _get_config_file_path()
    if config_file.exists():
        try:
            with open(config_file) as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def get_default_api_url(api_key: Optional[str] = None) -> str:
    """
    Get default API URL based on whether API key is provided.
    When API key is provided, defaults to cloud API.
    
    Args:
        api_key: Optional API key. If provided, assumes cloud API.
    
    Returns:
        API URL string
    """
    # If API key provided, use cloud API URL
    if api_key:
        return "https://api.neuronlens.com"
    
    # No API key = local mode (frontend server on port 8001)
    return "http://localhost:8001"


def get_api_timeout() -> int:
    """
    Get API timeout from config file, environment variable, or default.
    
    Returns:
        Timeout in seconds
    """
    # Priority 1: Config file
    config = _load_config()
    timeout = config.get('timeout')
    if timeout:
        return int(timeout)
    
    # Priority 2: Environment variable
    return int(os.environ.get('NEURONLENS_API_TIMEOUT', '30'))


def get_api_key_from_env() -> Optional[str]:
    """
    Get API key from environment variable.
    
    Returns:
        API key string or None
    """
    # Check NEURONLENS_API_KEY first
    api_key = os.environ.get('NEURONLENS_API_KEY')
    if api_key:
        return api_key
    
    # Fallback to API_KEY for backward compatibility
    return os.environ.get('API_KEY')
