"""
Test neuronlens ReasoningLens (repo client) against the unified server.

Run from sae_app_v5:
    python pip/test_pip_reasoning.py

Expects FRONTEND_API_URL (default http://localhost:8001).
"""
import os
import sys
from pathlib import Path

_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

env_path = _root / ".env"
if env_path.exists():
    try:
        from dotenv import load_dotenv
        load_dotenv(env_path, override=True)
    except ImportError:
        pass

import neuronlens

neuronlens.init(
    api_key=os.getenv("API_KEY") or os.getenv("NEURONLENS_API_KEY") or "",
    api_url=os.getenv("FRONTEND_API_URL", "http://localhost:8001"),
)

print("=== Testing NeuronLens Reasoning Analysis (v5 — ReasoningLens) ===\n")

# Test 1: post_hoc case — high early importance, low overall → post_hoc triggered
cot_post_hoc = (
    "Therefore the answer is clearly positive. "
    "We should also consider revenue was strong. "
    "Margins improved. Guidance was constructive. Management tone was upbeat."
)
result = neuronlens.reasoning.check(cot_post_hoc)

print(f"chain_label  : {result.get('chain_label', 'N/A')}")
print(f"action       : {result.get('action', 'N/A')}")
print(f"action_reason: {result.get('action_reason', 'N/A')}")

metrics = result.get("aggregate_metrics", {})
if metrics:
    print(f"avg_importance : {metrics.get('avg_importance', 0):.3f}")
    print(f"anchor_count   : {metrics.get('anchor_count', 0)}")

labels = result.get("labels", {})
if labels:
    print("\nLabels:")
    for lbl, info in labels.items():
        mark = "✓" if info.get("triggered") else " "
        print(f"  [{mark}] {lbl:<12s}  action={info.get('action')}")

scores = result.get("sentence_scores", [])
if scores:
    print(f"\nSentence scores ({len(scores)}):")
    for s in scores:
        print(f"  [{s.get('importance', 0):.3f}] {s.get('position', ''):<20s} "
              f"{str(s.get('text', ''))[:70]}")

# Test 2: allow case — balanced reasoning
print("\n--- Test 2: balanced CoT (expect label=none, action=allow) ---")
cot_balanced = (
    "First I check the numbers. Revenue grew 12% year-over-year. "
    "Margins expanded by 50bps. Operating cash flow increased. "
    "Management reiterated full-year guidance. The stock looks fairly valued."
)
result2 = neuronlens.reasoning.check(cot_balanced)
print(f"chain_label: {result2.get('chain_label')}  action: {result2.get('action')}")

print("\n=== Reasoning pip test passed ===")
