"""Structured logging configuration — call once at startup.

Configures structlog for the process. All modules use ``structlog.get_logger()``
for operational logging; probe adapters get structured output for free.
"""

from __future__ import annotations

import logging

import structlog


def configure_logging(log_format: str = "console", log_level: str = "info") -> None:
    """Configure structlog for the process. Call once at startup."""
    shared_processors: list[structlog.types.Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
    ]
    if log_format == "json":
        # format_exc_info converts exceptions to strings for JSON output.
        # ConsoleRenderer handles exceptions natively and warns if
        # format_exc_info runs first, so only add it for JSON.
        shared_processors.append(structlog.processors.format_exc_info)
        renderer: structlog.types.Processor = structlog.processors.JSONRenderer()
    else:
        renderer = structlog.dev.ConsoleRenderer()
    structlog.configure(
        processors=[*shared_processors, renderer],
        wrapper_class=structlog.make_filtering_bound_logger(
            getattr(logging, log_level.upper(), logging.INFO)
        ),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=True,
    )
