# Spec: Incremental (change-detection) deploys

## Problem

depush currently uploads every file on every run, regardless of whether the file has changed. For large codebases or frequent deploys this wastes time and bandwidth.

## Goal

Skip files that haven't changed since the last deploy. Only upload new or modified files. Continue deleting stale files as before.

No new CLI flags or config options — change detection is always on. The output should indicate which files were skipped.

## Change detection strategy per target

### S3 / MinIO

- Before uploading, call `head_object` to get the remote ETag.
- Compute the local file's MD5 hex digest.
- Skip upload if local MD5 == remote ETag (stripped of quotes).
- New files (404 on `head_object`) are always uploaded.
- Note: S3 ETags for standard (non-multipart) uploads are the MD5 of the file content. This covers our use case since depush uses `upload_file` which does single-part uploads for small files. For multipart uploads the ETag format differs — we treat a mismatch as "changed" and re-upload, which is the safe default.

### Local directory

- Before copying, compare source `mtime` and `size` against the destination file.
- Skip copy if both match.
- Use `os.stat()` on both sides. Compare `st_mtime` (float) and `st_size`.
- For mtime comparison, use a small epsilon (1e-3) to handle filesystem timestamp precision differences.
- New files (destination doesn't exist) are always copied.
- After copying, `shutil.copy2` already preserves mtime, so subsequent runs will correctly detect unchanged files.

### SSH (paramiko path)

- Before uploading via SFTP, call `sftp.stat()` on the remote path to get `st_mtime` and `st_size`.
- Compare against local `os.stat()` values (same logic as local).
- Skip upload if both match.
- New files (remote `FileNotFoundError` / `IOError` from `sftp.stat()`) are always uploaded.
- After uploading, call `sftp.utime()` to set the remote mtime to match the local file's mtime, so subsequent runs detect unchanged files correctly.

### SSH (rsync path)

- No changes. rsync already handles this natively via its own protocol.

## Dry-run must show the full change plan

Currently, dry-run skips connecting to the remote for SSH and cannot detect stale files. With this change, **dry-run must connect and perform the same change detection as a real run** — it just doesn't execute any writes or deletes.

This means:
- **S3 dry-run**: connect, call `head_object` / `list_objects_v2`, compute local MD5s, report what would be uploaded/skipped/deleted.
- **Local dry-run**: stat destination files, compare mtime+size, report what would be copied/skipped/deleted.
- **SSH dry-run**: connect via paramiko, `sftp.stat()` remote files, compare mtime+size, report what would be uploaded/skipped/deleted. Then disconnect.

The dry-run output uses the same `[new]`, `[upload]`, `[skip]`, `[delete]` labels (prefixed with `[dry-run]`) so the user sees the exact plan before committing.

Remove the current SSH dry-run shortcut that prints "Stale remote files would also be deleted (requires connection to determine)".

## Output changes

Update the summary line to show skipped files:

```
Deployed 3 file(s) to /dest/ (12 unchanged, 2 deleted)
```

For individual files, indicate the action:

```
  [upload] s3://bucket/mylib/1.0/changed.py
  [skip]   s3://bucket/mylib/1.0/unchanged.py
  [new]    s3://bucket/mylib/1.0/added.py
  [delete] s3://bucket/mylib/1.0/removed.py
```

In dry-run mode, prefix as before but use the same action labels:

```
  [dry-run] [upload] s3://bucket/mylib/1.0/changed.py
  [dry-run] [skip]   s3://bucket/mylib/1.0/unchanged.py
```

## Implementation notes

- Add a helper `_md5_file(path: Path) -> str` that returns the hex digest of a file.
- For S3, wrap `head_object` in a try/except for `ClientError` with 404 status to detect new files.
- For local/SSH, the stat comparison logic is identical — extract into a shared helper `_file_changed(local_stat, remote_mtime, remote_size) -> bool`.
- The stale-file deletion logic is unchanged.
- No new dependencies.

## Test plan

- Unit tests: mock `head_object` / `sftp.stat()` / `os.stat()` to verify skip/upload decisions.
- Unit tests: verify mtime is set on remote after paramiko upload (`sftp.utime` called).
- Unit tests: verify output includes `[skip]`, `[upload]`, `[new]`, `[delete]` labels.
- Integration tests: deploy twice with no changes, assert second run uploads 0 files. Deploy again after modifying one file, assert only that file is uploaded.
