from __future__ import annotations

import base64
import concurrent.futures
import io
import json
import logging
import re
import time
from dataclasses import dataclass
from enum import Enum
from typing import Sequence

import httpx
from PIL import Image, ImageDraw, ImageFilter, ImageFont

from lemon_manga_translator.types import TextBlock


class BackgroundMaskMode(str, Enum):
    NONE = "none"
    SOLID = "solid"
    BLUR = "blur"
    OVERLAY = "overlay"

DEFAULT_VISION_MAX_LONG_EDGE = 1024

logger = logging.getLogger(__name__)


class OpenRouterError(RuntimeError):
    pass


@dataclass
class VisionBlockResult:
    block_index: int
    no_translate: bool
    ko_translation: str | None


SYSTEM_PROMPT = """\
You process numbered text regions on a manga page in a single pass:
classify each region and translate dialogue into Korean.

The image has numbered rectangles drawn on it. Each rectangle encloses
some text (or what the detector thought was text). For EACH number,
output two things:

1. no_translate (bool)
   - true  = any text that should NOT be translated. This includes:
     • sound effects / onomatopoeia (ガタガタ, ドキドキ, バン, ドーン)
     • text that is hand-drawn or rasterized into the artwork itself.
       Visual cues: colored/gradient fills, outlines or shadows baked
       into the letterforms, irregular or stylized glyph shapes,
       text that overlaps or blends with the illustration rather than
       sitting on a clean background. Examples: decorative title
       logos, artistic chapter headers, hand-lettered cover text.
     • non-text regions the detector picked up by mistake
       (illustration fragments, patterns, artifacts)
   - false = dialogue / narration / sign / title text a translator would
     handle. This includes speech bubbles, thought bubbles, narrator
     boxes, readable signage, AND titles or captions rendered in a
     clean standard font (even if they are not dialogue).

2. ko_translation (string | null)
   - If no_translate=false: a natural Korean translation matching the tone of
     the panel (존댓말/반말 preserved, 만화 말풍선 특유의 줄임/감탄은
     자연스럽게). Read the Japanese text from the image directly.
   - If no_translate=true: null (do not translate).

Output: pure JSON array, no markdown, no explanation. One element per
numbered rectangle, in numeric order:

[
  {"id": <int>, "no_translate": <bool>, "ko_translation": <string|null>}
]
"""


_LABEL_PAD = 4
_BBOX_COLOR = (255, 0, 0)
_LABEL_BG = (255, 255, 0)
_LABEL_FG = (0, 0, 0)
_LABEL_BORDER = (0, 0, 0)
_MASK_BBOX_PAD = 5


class PageAnnotator:
    def __init__(
        self,
        max_long_edge: int = DEFAULT_VISION_MAX_LONG_EDGE,
        bg_mask_mode: BackgroundMaskMode = BackgroundMaskMode.NONE,
    ):
        self.max_long_edge = max_long_edge
        self.bg_mask_mode = bg_mask_mode

    def annotate(
        self, page_image: Image.Image, blocks: Sequence[TextBlock]
    ) -> Image.Image:
        resized, scaled_bboxes = self._resize_with_blocks(
            page_image.convert("RGB"), blocks
        )
        resized = self._apply_background_mask(resized, scaled_bboxes)
        long_edge = max(resized.size)
        font_size = max(12, int(round(long_edge * 0.018)))
        line_width = max(1, int(round(long_edge / 500)))
        return self._draw_numbered_overlay(
            resized, scaled_bboxes, font_size=font_size, line_width=line_width
        )

    def _apply_background_mask(
        self,
        image: Image.Image,
        bboxes: Sequence[tuple[int, int, int, int]],
    ) -> Image.Image:
        if self.bg_mask_mode == BackgroundMaskMode.NONE:
            return image

        W, H = image.size
        keep = Image.new("L", (W, H), 0)
        draw = ImageDraw.Draw(keep)
        for x0, y0, x1, y1 in bboxes:
            draw.rectangle(
                [
                    max(0, x0 - _MASK_BBOX_PAD),
                    max(0, y0 - _MASK_BBOX_PAD),
                    min(W, x1 + _MASK_BBOX_PAD),
                    min(H, y1 + _MASK_BBOX_PAD),
                ],
                fill=255,
            )

        if self.bg_mask_mode == BackgroundMaskMode.SOLID:
            bg = Image.new("RGB", (W, H), (255, 255, 255))
            bg.paste(image, mask=keep)
            return bg

        if self.bg_mask_mode == BackgroundMaskMode.BLUR:
            blurred = image.filter(ImageFilter.GaussianBlur(radius=20))
            blurred.paste(image, mask=keep)
            return blurred

        if self.bg_mask_mode == BackgroundMaskMode.OVERLAY:
            grey = Image.new("RGB", (W, H), (180, 180, 180))
            blend = keep.point(lambda p: 255 if p > 0 else 80)
            return Image.composite(image, grey, blend)

        return image

    def _resize_with_blocks(
        self, image: Image.Image, blocks: Sequence[TextBlock]
    ) -> tuple[Image.Image, list[tuple[int, int, int, int]]]:
        W, H = image.size
        bboxes = [
            (int(b.bbox.x), int(b.bbox.y), int(b.bbox.x1), int(b.bbox.y1))
            for b in blocks
        ]
        long_edge = max(W, H)
        if long_edge <= self.max_long_edge:
            return image, bboxes
        scale = self.max_long_edge / long_edge
        new_w = max(1, int(round(W * scale)))
        new_h = max(1, int(round(H * scale)))
        resized = image.resize((new_w, new_h), Image.LANCZOS)
        scaled = [
            (
                int(round(x0 * scale)),
                int(round(y0 * scale)),
                int(round(x1 * scale)),
                int(round(y1 * scale)),
            )
            for (x0, y0, x1, y1) in bboxes
        ]
        return resized, scaled

    def _load_font(self, font_size: int) -> ImageFont.ImageFont:
        return ImageFont.load_default(font_size)

    def _draw_numbered_overlay(
        self,
        image: Image.Image,
        bboxes: Sequence[tuple[int, int, int, int]],
        font_size: int,
        line_width: int,
    ) -> Image.Image:
        out = image.convert("RGB").copy()
        draw = ImageDraw.Draw(out)
        font = self._load_font(font_size)
        W, H = out.size
        for idx, (x0, y0, x1, y1) in enumerate(bboxes):
            draw.rectangle([x0, y0, x1, y1], outline=_BBOX_COLOR, width=line_width)
            self._draw_label(draw, str(idx), x0, y0, x1, y1, W, H, font)
        return out

    @staticmethod
    def _draw_label(
        draw: ImageDraw.ImageDraw,
        label: str,
        x0: int,
        y0: int,
        x1: int,
        y1: int,
        W: int,
        H: int,
        font: ImageFont.ImageFont,
    ) -> None:
        text_bbox = draw.textbbox((0, 0), label, font=font)
        tw = text_bbox[2] - text_bbox[0]
        th = text_bbox[3] - text_bbox[1]
        label_w = tw + 2 * _LABEL_PAD
        label_h = th + 2 * _LABEL_PAD
        lx0 = max(0, x0 - 2)
        ly0 = y0 - label_h - 2
        if ly0 < 0:
            ly0 = y1 + 2
            if ly0 + label_h > H:
                ly0 = y0 + 2
        lx1 = min(W, lx0 + label_w)
        ly1 = ly0 + label_h
        draw.rectangle(
            [lx0, ly0, lx1, ly1], fill=_LABEL_BG, outline=_LABEL_BORDER, width=1
        )
        draw.text((lx0 + _LABEL_PAD, ly0 + _LABEL_PAD), label, fill=_LABEL_FG, font=font)


def _encode_jpeg_b64(image: Image.Image, quality: int = 90) -> str:
    buf = io.BytesIO()
    # PNG는 무손실이라 페이로드 크기가 큼 (1024 long-edge에서 1~2MB).
    # JPEG quality=90이면 페이로드 1/5~1/10 수준. annotation overlay와 텍스트
    # 가독성 모두 충분.
    image.save(buf, format="JPEG", quality=quality)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _parse_json_array(content: str) -> list[dict]:
    s = (content or "").strip()
    if not s:
        raise OpenRouterError("LLM returned empty content")
    fence = re.match(r"^```(?:json)?\s*(.*?)\s*```$", s, re.DOTALL)
    if fence:
        s = fence.group(1).strip()
    try:
        parsed = json.loads(s)
    except json.JSONDecodeError:
        match = re.search(r"\[[\s\S]*\]", s)
        if not match:
            raise OpenRouterError(f"LLM did not return a JSON array: {content[:300]}")
        parsed = json.loads(match.group(0))
    if not isinstance(parsed, list):
        raise OpenRouterError(f"Expected JSON array, got {type(parsed).__name__}")
    return parsed


@dataclass
class VisionPageResult:
    blocks: list[VisionBlockResult]
    annotated: Image.Image | None
    usage: dict
    attempts: int
    # primary가 모두 실패해 fallback이 처리한 경우 fallback model 이름이 들어감.
    model: str = ""


class VisionLlmClient:
    def __init__(
        self,
        api_key: str,
        model: str,
        base_url: str = "https://openrouter.ai/api/v1",
        max_long_edge: int = DEFAULT_VISION_MAX_LONG_EDGE,
        max_attempts: int = 5,
        timeout: float = 60.0,
        annotator: PageAnnotator | None = None,
        fallback_model: str | None = None,
        fallback_max_attempts: int = 1,
    ):
        if not api_key:
            raise OpenRouterError("OPENROUTER_API_KEY is empty")
        if not model:
            raise OpenRouterError("OPENROUTER_MODEL is empty")
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.max_attempts = max_attempts
        # wall-clock 상한 (요청 1회당). httpx의 read 타임아웃은 청크 사이 간격이라
        # OpenRouter가 keepalive 바이트를 흘리면 무한 대기가 됨. 워치독으로 강제 차단.
        self.timeout = timeout
        self.annotator = annotator or PageAnnotator(max_long_edge=max_long_edge)
        self.fallback_model = fallback_model or None
        self.fallback_max_attempts = max(1, fallback_max_attempts)

    def run_page(
        self, page_image: Image.Image, blocks: Sequence[TextBlock]
    ) -> VisionPageResult:
        if not blocks:
            return VisionPageResult(blocks=[], annotated=None, usage={}, attempts=0)

        annotated = self.annotator.annotate(page_image, blocks)
        b64 = _encode_jpeg_b64(annotated)
        block_ids = list(range(len(blocks)))
        id_list = ", ".join(str(i) for i in block_ids)
        user_text = (
            f"The image has {len(block_ids)} numbered rectangles. The IDs are: "
            f"{id_list}. For each id, output no_translate and ko_translation. "
            f"Return exactly {len(block_ids)} elements in the JSON array, one "
            f"per id."
        )

        try:
            parsed, usage, attempts = self._call_with_retry(
                b64, user_text, len(block_ids), self.model, self.max_attempts
            )
            used_model = self.model
        except OpenRouterError as primary_err:
            if not self.fallback_model:
                raise
            logger.warning(
                "Vision LLM primary 모델 실패 (%s), fallback %s로 재시도: %s",
                self.model,
                self.fallback_model,
                primary_err,
            )
            parsed, usage, attempts = self._call_with_retry(
                b64,
                user_text,
                len(block_ids),
                self.fallback_model,
                self.fallback_max_attempts,
            )
            used_model = self.fallback_model
            logger.info("Vision LLM fallback 성공 (모델=%s, 시도=%d)", used_model, attempts)
        return VisionPageResult(
            blocks=self._build_results(parsed, block_ids),
            annotated=annotated,
            usage=usage,
            attempts=attempts,
            model=used_model,
        )

    def _call_with_retry(
        self, b64: str, user_text: str, expected: int, model: str, max_attempts: int
    ) -> tuple[list[dict], dict, int]:
        last_err: Exception | None = None
        for attempt in range(1, max_attempts + 1):
            try:
                parsed, usage = self._call_once(b64, user_text, expected, model)
                return parsed, usage, attempt
            except Exception as e:
                last_err = e
                if attempt < max_attempts:
                    time.sleep(2 ** (attempt - 1))
        raise OpenRouterError(
            f"vision call failed after {max_attempts} attempts on {model}: {last_err}"
        ) from last_err

    @staticmethod
    def _build_results(
        parsed: list[dict], block_ids: list[int]
    ) -> list[VisionBlockResult]:
        by_id = {int(item.get("id", -1)): item for item in parsed}
        results: list[VisionBlockResult] = []
        for i in block_ids:
            item = by_id.get(i, {})
            no_translate = bool(item.get("no_translate", False))
            ko_raw = item.get("ko_translation")
            ko = ko_raw.strip() if isinstance(ko_raw, str) else None
            results.append(
                VisionBlockResult(
                    block_index=i,
                    no_translate=no_translate,
                    ko_translation=(ko or None),
                )
            )
        return results

    def _call_once(
        self, b64: str, user_text: str, expected: int, model: str
    ) -> tuple[list[dict], dict]:
        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": user_text},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/jpeg;base64,{b64}"},
                        },
                    ],
                },
            ],
            "temperature": 0,
            # 동일 토큰을 길게 반복 출력하는 모델 폭주(예: SFX/외침 박스에서
            # 같은 글자가 32K 토큰까지 늘어나는 현상)를 방지한다. 정상 대사의
            # 자연스러운 반복(같은 인물명, "귀여워! 귀여워!" 등)에는 영향이 적은
            # 보수적 값.
            "frequency_penalty": 1.0,
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        # httpx 자체 타임아웃은 wall-clock과 동일하게 두되, 진짜 cap은 워치독이 잡음.
        httpx_timeout = httpx.Timeout(
            connect=10.0, read=self.timeout, write=30.0, pool=10.0
        )
        client = httpx.Client(timeout=httpx_timeout)

        def _do_request() -> httpx.Response:
            return client.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
            )

        executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="openrouter"
        )
        start = time.monotonic()
        try:
            future = executor.submit(_do_request)
            try:
                response = future.result(timeout=self.timeout)
            except concurrent.futures.TimeoutError:
                elapsed = time.monotonic() - start
                # client를 강제로 닫아 백그라운드 스레드의 소켓을 끊는다.
                # 워커 스레드는 곧 ReadError/ConnectError로 종료된다.
                try:
                    client.close()
                except Exception:
                    pass
                executor.shutdown(wait=False)
                logger.warning(
                    "OpenRouter request exceeded wall-clock timeout (%.2fs / %.0fs limit)",
                    elapsed,
                    self.timeout,
                )
                raise OpenRouterError(
                    f"OpenRouter request exceeded wall-clock timeout of {self.timeout}s"
                )
            except Exception:
                executor.shutdown(wait=False)
                raise
            else:
                executor.shutdown(wait=True)
                logger.debug(
                    "OpenRouter request completed in %.2fs", time.monotonic() - start
                )
        finally:
            try:
                client.close()
            except Exception:
                pass

        if response.status_code != 200:
            raise OpenRouterError(
                f"OpenRouter returned {response.status_code}: {response.text[:500]}"
            )
        body = response.json()
        if "error" in body:
            raise OpenRouterError(f"OpenRouter error: {body['error']}")
        try:
            content = body["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as e:
            raise OpenRouterError(f"Unexpected response shape: {body}") from e
        usage = body.get("usage") or {}
        parsed = _parse_json_array(content)
        if len(parsed) != expected:
            raise OpenRouterError(
                f"block count mismatch: expected {expected}, got {len(parsed)}"
            )
        return parsed, usage
