"""Extract inline SVG blocks from content text into standalone .svg files.

Inline ``<svg>...</svg>`` markup is replaced with ``<img>`` references
pointing to generated media files, keeping the QTI XML spec-compliant.

The extraction returns *placeholder tokens* rather than actual ``<img>``
tags so that downstream markdown processing does not mangle them.  Call
:func:`restore_img_placeholders` after markdown conversion to swap
the placeholders for real ``<img>`` elements.
"""

from __future__ import annotations

import hashlib
import logging
import re

logger = logging.getLogger(__name__)

_SVG_BLOCK_RE = re.compile(r"<svg[\s>].*?</svg>", re.DOTALL | re.IGNORECASE)
_SVG_DETECT_RE = re.compile(r"<svg[\s>]", re.IGNORECASE)

_XMLNS_RE = re.compile(r'\bxmlns\s*=\s*["\']', re.IGNORECASE)
_SVG_OPEN_RE = re.compile(r"<svg\b", re.IGNORECASE)
_SVG_OPEN_TAG_RE = re.compile(r"<svg\b[^>]*>", re.IGNORECASE | re.DOTALL)

_WIDTH_RE = re.compile(r'\bwidth\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
_HEIGHT_RE = re.compile(r'\bheight\s*=\s*["\']([^"\']+)["\']', re.IGNORECASE)
_VIEWBOX_RE = re.compile(r'\bviewBox\s*=\s*["\']([^"\']+)["\']')
_PX_SUFFIX_RE = re.compile(r"^(\d+(?:\.\d+)?)\s*px$", re.IGNORECASE)

_DEFAULT_WIDTH = 400
_DEFAULT_HEIGHT = 300

SVG_XMLNS = 'xmlns="http://www.w3.org/2000/svg"'
SVG_XML_DECL = '<?xml version="1.0" encoding="UTF-8"?>\n'

_PLACEHOLDER_PREFIX = "\x00SVG_IMG_"
_PLACEHOLDER_SUFFIX = "\x00"


def _parse_dimension(raw: str) -> int | None:
    """Parse a bare number or ``<number>px`` value to an integer.

    Returns ``None`` for values with non-px units (em, %, etc.)
    that we cannot safely normalise.
    """
    raw = raw.strip()
    px = _PX_SUFFIX_RE.match(raw)
    if px:
        return round(float(px.group(1)))
    try:
        return round(float(raw))
    except ValueError:
        return None


def ensure_svg_dimensions(svg: str) -> str:
    """Ensure the ``<svg>`` root element has explicit ``width`` and ``height``.

    Injection cascade:
    1. Both present  → leave unchanged (strip ``px`` suffix if present).
    2. viewBox + one missing → derive missing from aspect ratio.
    3. viewBox + both missing → use viewBox w/h directly.
    4. Nothing present → apply default 400×300, add viewBox, log warning.
    """
    tag_match = _SVG_OPEN_TAG_RE.search(svg)
    if not tag_match:
        return svg

    open_tag = tag_match.group(0)

    w_match = _WIDTH_RE.search(open_tag)
    h_match = _HEIGHT_RE.search(open_tag)
    vb_match = _VIEWBOX_RE.search(open_tag)

    width = _parse_dimension(w_match.group(1)) if w_match else None
    height = _parse_dimension(h_match.group(1)) if h_match else None

    vb_w: float | None = None
    vb_h: float | None = None
    if vb_match:
        parts = vb_match.group(1).split()
        if len(parts) == 4:
            try:
                vb_w = float(parts[2])
                vb_h = float(parts[3])
            except ValueError:
                vb_w = vb_h = None

    if width is not None and height is not None:
        if w_match and _PX_SUFFIX_RE.match(w_match.group(1).strip()):
            open_tag = _replace_attr(open_tag, "width", str(width))
        if h_match and _PX_SUFFIX_RE.match(h_match.group(1).strip()):
            open_tag = _replace_attr(open_tag, "height", str(height))
        if open_tag != tag_match.group(0):
            return svg[: tag_match.start()] + open_tag + svg[tag_match.end() :]
        return svg

    if vb_w and vb_h:
        if width is not None and height is None:
            height = round(width * vb_h / vb_w)
        elif height is not None and width is None:
            width = round(height * vb_w / vb_h)
        else:
            width = round(vb_w)
            height = round(vb_h)
    else:
        width = width or _DEFAULT_WIDTH
        height = height or _DEFAULT_HEIGHT
        if not vb_match:
            open_tag = _insert_attr(open_tag, "viewBox", f"0 0 {width} {height}")
        logger.warning(
            "SVG has no dimensions or viewBox — applying default %d×%d",
            width,
            height,
        )

    if w_match:
        open_tag = _replace_attr(open_tag, "width", str(width))
    else:
        open_tag = _insert_attr(open_tag, "width", str(width))

    if h_match:
        open_tag = _replace_attr(open_tag, "height", str(height))
    else:
        open_tag = _insert_attr(open_tag, "height", str(height))

    return svg[: tag_match.start()] + open_tag + svg[tag_match.end() :]


def _replace_attr(tag: str, attr: str, value: str) -> str:
    """Replace an existing attribute value in an SVG opening tag."""
    pattern = re.compile(
        rf'(\b{attr}\s*=\s*["\'])([^"\']*)(["\']\s*)', re.IGNORECASE
    )
    return pattern.sub(rf"\g<1>{value}\3", tag, count=1)


def _insert_attr(tag: str, attr: str, value: str) -> str:
    """Insert a new attribute into the ``<svg`` opening tag."""
    return _SVG_OPEN_RE.sub(f'<svg {attr}="{value}"', tag, count=1)


def has_inline_svg(text: str) -> bool:
    """Fast check for the presence of inline ``<svg>`` tags."""
    return bool(_SVG_DETECT_RE.search(text))


def extract_inline_svgs(
    text: str,
    item_id: str,
) -> tuple[str, dict[str, str], dict[str, str]]:
    """Replace inline ``<svg>`` blocks with placeholder tokens.

    Returns ``(rewritten_text, {zip_path: svg_file_content},
    {placeholder: img_tag})``.
    If no SVG blocks are found the original text and empty dicts are
    returned.
    """
    assets: dict[str, str] = {}
    placeholders: dict[str, str] = {}
    counter = 0

    def _replace(match: re.Match[str]) -> str:
        nonlocal counter
        svg_source = match.group(0)
        svg_file = _ensure_xmlns(svg_source)
        svg_file = ensure_svg_dimensions(svg_file)
        svg_file = SVG_XML_DECL + svg_file

        digest = hashlib.sha256(svg_source.encode()).hexdigest()[:12]
        zip_path = f"media/{item_id}/svg_{digest}.svg"

        rel_src = f"../{zip_path}"
        img_tag = f'<img src="{rel_src}" alt="embedded SVG graphic"/>'

        placeholder = f"{_PLACEHOLDER_PREFIX}{counter}{_PLACEHOLDER_SUFFIX}"
        counter += 1

        assets[zip_path] = svg_file
        placeholders[placeholder] = img_tag
        return placeholder

    rewritten = _SVG_BLOCK_RE.sub(_replace, text)
    return rewritten, assets, placeholders


def restore_img_placeholders(
    text: str,
    placeholders: dict[str, str],
) -> str:
    """Replace placeholder tokens with actual ``<img>`` tags."""
    for placeholder, img_tag in placeholders.items():
        text = text.replace(placeholder, img_tag)
    return text


def _ensure_xmlns(svg: str) -> str:
    """Add the SVG namespace declaration if missing."""
    if _XMLNS_RE.search(svg):
        return svg
    return _SVG_OPEN_RE.sub(f"<svg {SVG_XMLNS}", svg, count=1)
