"""Content processing pipeline: LaTeX -> MathML -> Markdown -> HTML -> XML.

Processing order
================

The full chain is invoked by ``BaseBuilder._process_content``, which wraps
``ContentPipeline.process`` with an outer SVG extraction/restoration layer.
The complete sequence, with step numbers referenced in the dependency table
below, is:

**Outer layer** (``BaseBuilder._process_content``):

0.  **SVG extract** — ``extract_inline_svgs``
    Replace ``<svg>...</svg>`` blocks with null-byte placeholder tokens.
    *Input:* raw content string.
    *Output:* text with SVG-free placeholders + asset dict + img-tag map.

    ... steps 1–8 run inside ``ContentPipeline.process`` ...

9.  **SVG restore** — ``restore_img_placeholders``
    Swap null-byte tokens back with ``<img src="..."/>`` tags.
    *Input:* fully-processed pipeline output.
    *Output:* final XML-ready string.

**Inner pipeline** (``ContentPipeline.process``):

1.  **Template-variable protect** — ``_protect_template_vars``
    Replace ``@@var@@`` tokens with ``TVAR_PIPE_<hex>`` placeholders.
    *Assumes:* SVGs already removed (step 0).
    *Why here:* The LaTeX converter (step 3) recognises ``TVAR_PIPE_``
    placeholders and wraps them in ``\\text{}`` so ``latex2mathml`` treats
    them as opaque text nodes, not individual math identifiers.

2.  **Blank protect** — ``_protect_blanks``
    Replace ``<blank>`` / ``<blank-N>`` markers with ``BLANK_PIPE_<hex>``
    placeholders.
    *Assumes:* nothing besides step 0.
    *Why here:* Must run before LaTeX (step 3) because ``<blank-N>``
    contains angle brackets that trigger the inline-math false-positive
    guard (``if "<" in latex and ">" in latex: skip``).  The LaTeX
    converter recognises ``BLANK_PIPE_`` placeholders and wraps them in
    ``\\text{}`` (same as template vars) so they survive ``latex2mathml``
    as single ``<mtext>`` nodes.  Must also run before Markdown (step 5)
    because mistune's handling of unknown HTML-like tags is
    context-dependent and non-deterministic.

3.  **LaTeX conversion** — ``LatexConverter.convert``
    Convert ``$...$`` (inline) and ``$$...$$`` (display) to MathML
    ``<math>`` elements.  Internally protects pre-existing ``<math>``
    blocks and escaped ``\\$`` signs.  Wraps ``TVAR_PIPE_`` and
    ``BLANK_PIPE_`` placeholders in ``\\text{}`` before calling
    ``latex2mathml``.
    *Assumes:* template vars and blanks are already placeholders
    (steps 1–2).  SVGs already removed (step 0).
    *Why here:* Dollar-sign delimiters must be processed before Markdown
    escapes or transforms them.

4.  **MathML protect** — ``_protect_mathml``
    Replace ``<math>...</math>`` blocks (just produced by step 3) with
    ``MATHML_PIPE_<hex>`` placeholders.
    *Assumes:* LaTeX has already run (step 3).
    *Why here:* Shields MathML from mistune (step 5), which could wrap
    ``<math>`` in ``<p>``, alter whitespace, or otherwise corrupt the
    markup.

5.  **Markdown conversion** — ``MarkdownConverter.convert``
    Convert GFM markdown to HTML via mistune (tables, strikethrough,
    hard wrap).  Runs with ``escape=False`` so raw HTML passes through.
    *Assumes:* all angle-bracket content (MathML, blanks, SVGs) is
    hidden behind inert placeholders.
    *Why here:* must run after all protection steps, before any
    restoration steps.

6.  **MathML restore** — ``_restore_mathml``
    Put back ``<math>...</math>`` blocks in place of ``MATHML_PIPE_``
    placeholders.
    *Assumes:* Markdown has already run (step 5).
    *Why here:* Must be restored before template-var restoration (step 7)
    so that ``_restore_template_vars`` can detect ``<mtext>`` wrapping
    to distinguish math-context from prose-context variables.

7.  **HTML-to-XML normalisation** — ``html_to_xml``
    Self-close void elements, replace ``&nbsp;``, add boolean attribute
    values.
    *Assumes:* MathML is already restored (step 6).  Its regexes target
    specific HTML void element names, so MathML tags pass through
    unaffected.
    *Why here:* must run before template-var and blank restoration
    (steps 7–8) which emit new XML elements or entity-escaped content
    that should not be re-processed.

8a. **Template-variable restore** — ``_restore_template_vars``
    Context-dependent: if placeholder is inside ``<mtext>...</mtext>``,
    emit ``<mi>varname</mi>``; otherwise emit
    ``<qti-printed-variable identifier="var"/>``.
    *Assumes:* MathML restored (step 6) so ``<mtext>`` context is
    visible.  ``html_to_xml`` has run (step 7).

8b. **Blank restore** — ``_restore_blanks``
    Replace ``BLANK_PIPE_<hex>`` with ``&lt;blank-N&gt;``
    (entity-escaped).  If the placeholder is inside
    ``<mtext>...</mtext>`` (from LaTeX math), unwrap the ``<mtext>``
    wrapper so the entity-escaped token is directly in the output.
    *Assumes:* ``html_to_xml`` has run (step 7).
    *Why last:* the entity-escaped form is the contract with downstream
    builders (``text_entry_builder``, ``composite_builder``), which do
    ``.replace("&lt;blank-N&gt;", interaction_xml)``.  No subsequent
    step should decode or re-encode these entities.

Ordering constraints (dependency graph)
========================================

Arrows read "must precede":

- 0 -> 1, 2, 3       SVGs removed before any text processing.
- 1 -> 3              Template vars become placeholders before LaTeX sees them.
- 2 -> 3              Blanks become placeholders before LaTeX sees them.
- 3 -> 4              LaTeX produces <math> blocks for MathML-protect to find.
- 4 -> 5              MathML hidden before Markdown runs.
- 2 -> 5              Blanks hidden before Markdown runs.
- 1 -> 5              Template vars hidden before Markdown runs.
- 5 -> 6              MathML restored after Markdown.
- 6 -> 8a             Template-var restore needs <mtext> context from MathML.
- 6 -> 7              html_to_xml runs over restored MathML (harmless).
- 7 -> 8a, 8b         New XML elements/entities not re-processed by html_to_xml.
- 8b -> 9             Entity-escaped blanks must survive until SVG restore (last).

.. warning::

   Reordering any step requires verifying all constraints above.  Each
   protect/restore pair assumes specific content has or has not been
   transformed yet.  See individual function docstrings for details.
"""

from __future__ import annotations

import re
import uuid

from .latex_converter import LatexConverter, _TVAR_PLACEHOLDER_PREFIX
from .markdown_converter import MarkdownConverter
from .xml_utils import html_to_xml

_MATH_PLACEHOLDER_PREFIX = "MATHML_PIPE_"
_BLANK_PLACEHOLDER_PREFIX = "BLANK_PIPE_"
_TVAR_PATTERN = re.compile(r"@@(\w+)@@")
_BLANK_PATTERN = re.compile(r"<(blank(?:-\w+)?)>")


class ContentPipeline:
    """Orchestrates the full content processing chain.

    Each step is also available individually for cases where only
    partial processing is needed.
    """

    def __init__(self) -> None:
        self.latex = LatexConverter()
        self.markdown = MarkdownConverter()

    def process(
        self,
        text: str,
        format_map: dict[str, str] | None = None,
    ) -> str:
        """Run the full pipeline: LaTeX -> MathML -> Markdown -> HTML -> XML.

        MathML produced by the LaTeX step is shielded from the markdown
        parser via placeholders so that mistune cannot escape the tags.

        ``@@var@@`` tokens are shielded and later restored context-
        dependently: inside MathML they become ``<mi>var</mi>`` (the
        renderer substitutes values via ``math-variable="true"``);
        outside MathML they become ``<qti-printed-variable
        identifier="var"/>`` elements.  *format_map* maps variable names
        to C-style format strings (e.g. ``{"%0.2f"}``) which become
        ``format`` attributes on the emitted ``<qti-printed-variable>``
        elements.
        """
        if not text:
            return text
        result, tvar_map = _protect_template_vars(text, format_map)
        result, blank_map = _protect_blanks(result)
        result = self.latex.convert(result)
        result, math_map = _protect_mathml(result)
        result = self.markdown.convert(result)
        result = _restore_mathml(result, math_map)
        result = html_to_xml(result)
        result = _restore_template_vars(result, tvar_map)
        result = _restore_blanks(result, blank_map)
        return result

    def process_plain(self, text: str) -> str:
        """Process without markdown (for content already in HTML)."""
        if not text:
            return text
        result = self.latex.convert(text)
        result = html_to_xml(result)
        return result


def _protect_mathml(text: str) -> tuple[str, dict[str, str]]:
    """Replace <math>...</math> blocks with unique placeholders."""
    mapping: dict[str, str] = {}
    for match in re.finditer(r"<math[\s>].*?</math>", text, re.DOTALL):
        key = f"{_MATH_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
        mapping[key] = match.group(0)
        text = text.replace(match.group(0), key, 1)
    return text, mapping


def _restore_mathml(text: str, mapping: dict[str, str]) -> str:
    """Put the original <math> blocks back in place of their placeholders."""
    for key, original in mapping.items():
        text = text.replace(key, original)
    return text


def _protect_template_vars(
    text: str,
    format_map: dict[str, str] | None,
) -> tuple[str, dict[str, tuple[str, str]]]:
    """Replace ``@@var@@`` tokens with unique placeholders.

    Returns ``(text_with_placeholders, {placeholder: (var_name, xml_element_string)})``.
    """
    mapping: dict[str, tuple[str, str]] = {}
    for match in _TVAR_PATTERN.finditer(text):
        var_name = match.group(1)
        key = f"{_TVAR_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
        fmt = (format_map or {}).get(var_name)
        fmt_attr = f' format="{fmt}"' if fmt else ""
        xml_str = f'<qti-printed-variable identifier="{var_name}"{fmt_attr}/>'
        mapping[key] = (var_name, xml_str)
        text = text.replace(match.group(0), key, 1)
    return text, mapping


def _restore_template_vars(text: str, mapping: dict[str, tuple[str, str]]) -> str:
    """Replace template-variable placeholders with the appropriate elements.

    When placeholders appear inside LaTeX math, they are wrapped in ``\\text{}``
    by the LatexConverter, producing ``<mtext>TVAR_PIPE_xxx</mtext>``.  Per the
    QTI spec, template variables inside MathML must use ``<mi>varname</mi>``
    (the renderer substitutes values via ``math-variable="true"``).

    Outside math, placeholders are bare and restored as
    ``<qti-printed-variable identifier="var"/>`` elements.
    """
    for key, (var_name, xml_str) in mapping.items():
        mtext_wrapped = f"<mtext>{key}</mtext>"
        if mtext_wrapped in text:
            text = text.replace(mtext_wrapped, f"<mi>{var_name}</mi>")
        else:
            text = text.replace(key, xml_str)
    return text


def _protect_blanks(text: str) -> tuple[str, dict[str, str]]:
    """Replace ``<blank>`` / ``<blank-N>`` markers with unique placeholders.

    These markers are used by text-entry interactions as fill-in-the-blank
    placeholders.  They look like HTML tags to mistune, which may pass them
    through as raw HTML (context-dependent) instead of escaping them.
    Shielding them ensures deterministic behaviour regardless of paragraph
    structure.
    """
    mapping: dict[str, str] = {}
    for match in _BLANK_PATTERN.finditer(text):
        key = f"{_BLANK_PLACEHOLDER_PREFIX}{uuid.uuid4().hex}"
        mapping[key] = match.group(1)
        text = text.replace(match.group(0), key, 1)
    return text, mapping


def _restore_blanks(text: str, mapping: dict[str, str]) -> str:
    """Restore blank placeholders as XML-escaped entities.

    The builders expect the escaped form (``&lt;blank&gt;``) so they can
    ``.replace()`` it with the actual ``<qti-text-entry-interaction>`` XML.

    When a placeholder appears inside LaTeX math, the LatexConverter wraps
    it in ``\\text{}``, producing ``<mtext>BLANK_PIPE_xxx</mtext>``.  We
    unwrap the ``<mtext>`` so the entity-escaped blank is directly in the
    output for the builder's ``.replace()`` to find.
    """
    for key, tag_name in mapping.items():
        escaped = f"&lt;{tag_name}&gt;"
        mtext_wrapped = f"<mtext>{key}</mtext>"
        if mtext_wrapped in text:
            text = text.replace(mtext_wrapped, escaped)
        else:
            text = text.replace(key, escaped)
    return text
