"""HTML to XML normalization and XML utility functions."""

from __future__ import annotations

import re

VOID_ELEMENTS = frozenset({
    "area", "base", "br", "col", "embed", "hr", "img", "input",
    "link", "meta", "param", "source", "track", "wbr",
})


def html_to_xml(html: str) -> str:
    """Convert HTML to well-formed XML.

    - Self-closes void elements (``<br>`` -> ``<br/>``)
    - Replaces ``&nbsp;`` with ``&#160;``
    - Ensures boolean attributes have values
    """
    result = html
    result = result.replace("&nbsp;", "&#160;")

    for tag in VOID_ELEMENTS:
        result = re.sub(
            rf"<({tag})\b([^>]*?)(?<!/)>",
            rf"<\1\2/>",
            result,
        )

    result = re.sub(
        r'\b(checked|disabled|readonly|selected|open|controls|autoplay|loop|muted|playsinline)(?=[>\s/])',
        r'\1="\1"',
        result,
    )
    return result


def escape_xml(text: str) -> str:
    """Escape text for safe inclusion in XML text nodes or attributes."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def escape_xml_text(text: str) -> str:
    """Escape text for XML text content (less aggressive than attribute)."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )
