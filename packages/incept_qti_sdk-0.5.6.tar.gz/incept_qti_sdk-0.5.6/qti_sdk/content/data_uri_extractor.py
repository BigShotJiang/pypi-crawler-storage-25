"""Extract ``data:image/*;base64,...`` URLs into standalone media files.

Rasters are stored as bytes; SVG is normalized like :func:`extract_inline_svgs`.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import logging
import re
from .svg_extractor import (
    SVG_XML_DECL,
    _ensure_xmlns,
    ensure_svg_dimensions,
)

logger = logging.getLogger(__name__)

_IMG_SRC_DATA_URI_RE = re.compile(
    r"\bsrc\s*=\s*(?P<q>[\"'])(?P<uri>data:image[^\"']+)(?P=q)",
    re.IGNORECASE,
)

# image/<subtype> — subtype may be e.g. png, svg+xml
_MIME_TO_EXT: dict[str, str] = {
    "png": "png",
    "jpeg": "jpg",
    "jpg": "jpg",
    "gif": "gif",
    "webp": "webp",
    "svg+xml": "svg",
}


class DataUriImageError(ValueError):
    """Raised when a data URI cannot be parsed or decoded."""


def _subtype_from_mediatype(mediatype: str) -> str:
    mt = mediatype.strip().lower()
    if not mt.startswith("image/"):
        raise DataUriImageError(f"Expected image/* mediatype, got {mediatype!r}")
    return mt[6:].strip()


def _ext_for_subtype(subtype: str) -> str:
    key = subtype.lower().strip()
    if key in _MIME_TO_EXT:
        return _MIME_TO_EXT[key]
    # Single-token types like "png"
    if key in ("jpeg",):
        return "jpg"
    raise DataUriImageError(f"Unsupported image subtype: {subtype!r}")


def _parse_data_image_uri(uri: str) -> tuple[str, bytes]:
    """Return (media subtype key, raw decoded bytes).

    Only ``data:image/...;...;base64,...`` forms are supported.
    """
    if not uri.startswith("data:"):
        raise DataUriImageError("Not a data URI")
    rest = uri[5:]
    comma = rest.find(",")
    if comma < 0:
        raise DataUriImageError("Invalid data URI: missing comma separator")

    header = rest[:comma]
    payload = rest[comma + 1 :]

    parts = [p.strip() for p in header.split(";") if p.strip()]
    if not parts:
        raise DataUriImageError("Invalid data URI: empty header")

    mediatype = parts[0]
    subtype = _subtype_from_mediatype(mediatype)

    header_lower = header.lower()
    if "base64" not in header_lower:
        raise DataUriImageError(
            "Only base64-encoded image data URIs are supported (got non-base64 header)"
        )

    try:
        raw = base64.b64decode(payload, validate=True)
    except binascii.Error as e:
        raise DataUriImageError("Invalid base64 in data URI") from e

    if not raw:
        raise DataUriImageError("Decoded data URI payload is empty")

    return subtype, raw


def externalize_image_url(url: str, item_id: str) -> tuple[str, dict[str, str | bytes]]:
    """If ``url`` is a supported ``data:image/...;base64,...`` URI, decode it to a
    package file under ``media/{item_id}/`` and return ``("../media/.../img_....ext", assets)``.
    Otherwise return ``(url, {})`` unchanged.
    """
    if not url.startswith("data:image/"):
        return url, {}

    subtype, raw = _parse_data_image_uri(url)
    ext = _ext_for_subtype(subtype)
    digest = hashlib.sha256(raw).hexdigest()[:12]
    zip_path = f"media/{item_id}/img_{digest}.{ext}"
    rel_src = f"../{zip_path}"

    if ext == "svg":
        try:
            text = raw.decode("utf-8")
        except UnicodeDecodeError as e:
            raise DataUriImageError("SVG data URI is not valid UTF-8") from e
        svg_file = _ensure_xmlns(text)
        svg_file = ensure_svg_dimensions(svg_file)
        content: str | bytes = SVG_XML_DECL + svg_file
    else:
        content = raw

    return rel_src, {zip_path: content}


def externalize_data_images_in_html(
    html: str,
    item_id: str,
) -> tuple[str, dict[str, str | bytes]]:
    """Replace ``<img src="data:image...">`` with ``../media/...`` paths; merge all assets."""
    merged: dict[str, str | bytes] = {}

    def _repl(m: re.Match[str]) -> str:
        data_uri = m.group("uri")
        try:
            new_url, assets = externalize_image_url(data_uri, item_id)
        except DataUriImageError as e:
            logger.warning("Skipping data URI in HTML: %s", e)
            return m.group(0)
        merged.update(assets)
        q = m.group("q")
        return f"src={q}{new_url}{q}"

    out = _IMG_SRC_DATA_URI_RE.sub(_repl, html)
    return out, merged
