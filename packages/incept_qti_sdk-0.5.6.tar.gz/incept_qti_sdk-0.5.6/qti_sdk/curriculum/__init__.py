"""Curriculum resolution is performed at upload time via :class:`qti_sdk.upload.CaseResolver`.

Provide ``ItemPackaging.document`` and ``ItemPackaging.course`` (human-readable titles)
to locate the course tree on TimeBack; no local registry file is used.
"""

__all__: list[str] = []
