"""Upload orchestrator: package BuildResults and upload to TimeBack."""

from __future__ import annotations

import logging
from pathlib import Path

import httpx
from pydantic import BaseModel, Field

from ..exceptions import UploadError, ValidationError

from ..builders.base_builder import BuildResult
from ..builders.package_builder import PackageBuilder
from .asset_resolver import resolve_assets
from .auth import get_token
from .case_resolver import CaseResolver
from .config import TimeBackConfig
from .zip_assembler import assemble_zip

logger = logging.getLogger(__name__)


class UploadResponse(BaseModel):
    """Result of uploading a QTI package to TimeBack."""

    job_id: str = Field(description="Ingest job ID for status polling.")
    warnings: list[str] = Field(
        default_factory=list,
        description="PCI URL warnings, unresolved standards, asset issues.",
    )


async def upload_qti_package(
    items: list[BuildResult],
    config: TimeBackConfig,
    *,
    package_id: str | None = None,
    schema: str = "QTI Item Bank",
    media_root: Path | None = None,
    download_external: bool = True,
    resolve_standards: bool = True,
    save_zip: Path | None = None,
) -> UploadResponse:
    """Package items into a QTI ZIP and upload to TimeBack.

    Returns immediately after upload completes. Use
    ``get_job_status()`` to check processing progress.

    Parameters
    ----------
    items:
        Built QTI items to package and upload.
    config:
        TimeBack platform credentials.
    package_id:
        Manifest package identifier (auto-generated if None).
    schema:
        Manifest schema name (default: ``"QTI Item Bank"``).
    media_root:
        Directory to resolve local media file paths against.
    download_external:
        If True (default), download non-whitelisted external URLs in
        ``src`` attributes and bundle them in the ZIP. TimeBack rejects
        external URLs that are not on its whitelist, so disabling this
        will cause ingestion failures for items with external assets.
    resolve_standards:
        If True, resolve human-readable standard labels to CASE UUIDs
        via TimeBack's CASE API before packaging.
    save_zip:
        If set, write the assembled ZIP to this path for debugging
        or inspection. Parent directories are created automatically.
    """
    _validate_items_for_upload(items, resolve_standards=resolve_standards)

    warnings: list[str] = []

    logger.info("Authenticating with TimeBack...")
    token = await get_token(config)

    if resolve_standards:
        logger.info("Resolving curriculum standards...")
        warnings.extend(await _resolve_all_standards(items, config, token))

    logger.info("Resolving assets...")
    asset_manifest = resolve_assets(
        items,
        media_root=media_root,
        download_external=download_external,
    )
    warnings.extend(asset_manifest.warnings)

    downloaded_assets: dict[str, bytes] | None = None
    if asset_manifest.downloads:
        logger.info("Downloading %d external asset(s)...", len(asset_manifest.downloads))
        downloaded_assets = await _download_assets(asset_manifest.downloads)

    logger.info("Assembling QTI package...")
    pkg_id = package_id or f"pkg_{items[0].item_id}" if items else "pkg_empty"
    manifest_xml = PackageBuilder().build(items, pkg_id, schema=schema)

    zip_bytes = assemble_zip(
        items,
        manifest_xml,
        asset_manifest,
        downloaded_assets=downloaded_assets,
    )
    logger.info("Package assembled: %d KB", len(zip_bytes) // 1024)

    if save_zip:
        save_zip.parent.mkdir(parents=True, exist_ok=True)
        save_zip.write_bytes(zip_bytes)
        logger.info("Saved QTI package to %s (%d bytes)", save_zip, len(zip_bytes))

    logger.info("Uploading to TimeBack...")
    base_url = config.base_url.rstrip("/")
    headers = {"Authorization": f"Bearer {token}"}

    async with httpx.AsyncClient() as client:
        try:
            upload_resp = await client.post(
                f"{base_url}/content/1.0/ingest/upload-url",
                headers=headers,
                json={"itemCount": len(items), "zipFileSize": len(zip_bytes)},
                timeout=30.0,
            )
            if upload_resp.status_code >= 400:
                logger.error(
                    "Upload URL request failed (%s): %s",
                    upload_resp.status_code,
                    upload_resp.text,
                )
            upload_resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise UploadError(
                f"Failed to obtain upload URL: {exc}"
            ) from exc
        upload_data = upload_resp.json()

        presigned_url = upload_data["uploadUrl"]
        job_id = upload_data["jobId"]

        try:
            put_resp = await client.put(
                presigned_url,
                content=zip_bytes,
                headers={"Content-Type": "application/zip"},
                timeout=120.0,
            )
            put_resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise UploadError(
                f"Failed to upload ZIP to presigned URL: {exc}"
            ) from exc

    return UploadResponse(job_id=job_id, warnings=warnings)


def _validate_items_for_upload(
    items: list[BuildResult],
    *,
    resolve_standards: bool,
) -> None:
    """Validate all items before making any network calls.

    Raises :class:`ValidationError` with a per-item error report if any
    item fails validation.  Checks run before authentication so consumers
    get fast, actionable feedback.
    """
    errors: dict[str, list[str]] = {}

    for item in items:
        item_errors: list[str] = []
        pkg = item.packaging

        if not pkg or not pkg.curriculum_standards:
            item_errors.append(
                "Missing curriculum_standards: at least one StandardAlignment is required."
            )
            if item_errors:
                errors[item.item_id] = item_errors
            continue

        unresolved = [s for s in pkg.curriculum_standards if s.case_item_uri is None]
        if not unresolved:
            continue

        if not resolve_standards:
            labels = ", ".join(s.label for s in unresolved)
            item_errors.append(
                f"Standards missing case_item_uri (resolve_standards is disabled): {labels}. "
                f"Either set case_item_uri on each StandardAlignment or enable resolve_standards."
            )
        elif not pkg.document or not pkg.course:
            labels = ", ".join(s.label for s in unresolved)
            item_errors.append(
                f"Unresolved standards without document and course names: {labels}. "
                f"Set ItemPackaging.document and ItemPackaging.course to the CFDocument title "
                f"and course title (matched case-insensitively on TimeBack)."
            )

        if item_errors:
            errors[item.item_id] = item_errors

    if errors:
        lines = [f"Upload validation failed for {len(errors)} item(s):\n"]
        for item_id, item_errors in errors.items():
            lines.append(f"  {item_id}:")
            for err in item_errors:
                lines.append(f"    - {err}")
        raise ValidationError("\n".join(lines))


async def _resolve_all_standards(
    items: list[BuildResult],
    config: TimeBackConfig,
    token: str,
) -> list[str]:
    """Resolve any unresolved standard labels across all items.

    Groups standards by ``(document, course)`` and creates one
    :class:`CaseResolver` per group (with shared class-level caching).
    """
    from ..models.base import StandardAlignment

    groups: dict[tuple[str, str], list[StandardAlignment]] = {}

    for item in items:
        if not item.packaging or not item.packaging.curriculum_standards:
            continue
        unresolved = [
            s for s in item.packaging.curriculum_standards
            if s.case_item_uri is None
        ]
        if not unresolved:
            continue
        doc = item.packaging.document
        course = item.packaging.course
        if doc and course:
            groups.setdefault((doc, course), []).extend(unresolved)

    warnings: list[str] = []
    for (document, course), standards in groups.items():
        resolver = CaseResolver(
            config,
            token,
            document=document,
            course=course,
        )
        warnings.extend(await resolver.resolve(standards))

    return warnings


async def _download_assets(downloads: dict[str, str]) -> dict[str, bytes]:
    """Download external assets that need to be bundled in the ZIP."""
    result: dict[str, bytes] = {}

    async with httpx.AsyncClient() as client:
        for zip_path, url in downloads.items():
            try:
                resp = await client.get(url, timeout=60.0, follow_redirects=True)
                resp.raise_for_status()
                result[zip_path] = resp.content
            except httpx.HTTPError:
                logger.warning("Failed to download asset: %s", url)

    return result
