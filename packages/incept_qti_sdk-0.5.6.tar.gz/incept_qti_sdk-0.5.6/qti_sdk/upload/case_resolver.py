"""Resolve human-readable standard labels to CASE UUIDs via the Curriculum API."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

import httpx

from ..exceptions import UploadError

if TYPE_CHECKING:
    from ..models.base import StandardAlignment
    from .config import TimeBackConfig

logger = logging.getLogger(__name__)

CURRICULUM_API_PREFIX = "curriculum/1.0"
CASE_API_PREFIX = "case/1.1"


def _norm(s: str) -> str:
    return s.strip().casefold()


def _match_by_title(
    rows: list[dict[str, Any]],
    name: str,
    *,
    title_getters: tuple[str, ...],
) -> list[dict[str, Any]]:
    """Return rows whose title matches ``name`` with case-insensitive strict equality."""
    want = _norm(name)
    matches: list[dict[str, Any]] = []
    for row in rows:
        title = ""
        for k in title_getters:
            if row.get(k) is not None and str(row.get(k)).strip() != "":
                title = str(row[k])
                break
        if _norm(title) == want:
            matches.append(row)
    return matches


class CaseResolver:
    """Resolves standard labels to CASE item UUIDs.

    Uses the TimeBack CASE API to list CFDocuments and match ``document`` by
    title, then lists courses under that document and matches ``course`` by
    title.  When multiple documents or courses share the same name, all
    ``(document, course)`` pairs are tried in order until every standard is
    resolved or the list is exhausted.  Standards resolved from a non-primary
    pair produce a warning in the returned list.

    Typical usage::

        resolver = CaseResolver(
            config, token,
            document="Common Core Standard",
            course="3rd Grade",
        )
        warnings = await resolver.resolve(standards_list)
    """

    # (base_url, document_norm, course_norm) -> list of (document_id, course_id) pairs
    _pairs_cache: dict[tuple[str, str, str], list[tuple[str, str]]] = {}
    # base_url -> CFDocuments page (full list after pagination)
    _documents_cache: dict[str, list[dict[str, Any]]] = {}
    # (base_url, document_id) -> courses list
    _courses_cache: dict[tuple[str, str], list[dict[str, Any]]] = {}
    # (base_url, document_id, course_id) -> code->UUID map
    _tree_cache: dict[tuple[str, str, str], dict[str, str]] = {}

    def __init__(
        self,
        config: TimeBackConfig,
        token: str,
        *,
        document: str,
        course: str,
    ) -> None:
        self._base_url = config.base_url.rstrip("/")
        self._token = token
        self._document_name = document
        self._course_name = course

    @classmethod
    def clear_cache(cls) -> None:
        """Clear in-memory document/course caches (mainly for tests)."""
        cls._pairs_cache.clear()
        cls._documents_cache.clear()
        cls._courses_cache.clear()
        cls._tree_cache.clear()

    async def resolve(
        self,
        standards: list[StandardAlignment],
    ) -> list[str]:
        """Resolve unresolved standards in-place. Returns list of warning messages."""
        warnings: list[str] = []
        unresolved = [s for s in standards if s.case_item_uri is None]
        if not unresolved:
            return warnings

        pairs = await self._resolve_all_pairs()

        for pair_idx, (doc_id, course_id) in enumerate(pairs):
            if not unresolved:
                break
            code_map = await self._fetch_course_tree(doc_id, course_id)
            still_unresolved: list[StandardAlignment] = []
            for standard in unresolved:
                uuid = code_map.get(standard.label)
                if uuid:
                    standard.case_item_uri = uuid
                    if pair_idx > 0:
                        warnings.append(
                            f"Standard '{standard.label}' resolved from "
                            f"alternate document/course match "
                            f"(document={doc_id[:12]}, course={course_id[:12]})"
                        )
                else:
                    still_unresolved.append(standard)
            unresolved = still_unresolved

        for standard in unresolved:
            warnings.append(
                f"Could not resolve standard label to CASE UUID: "
                f"{standard.label}"
            )

        return warnings

    # ------------------------------------------------------------------
    # Pair resolution
    # ------------------------------------------------------------------

    async def _resolve_all_pairs(self) -> list[tuple[str, str]]:
        """Build all valid ``(doc_id, course_id)`` pairs for the configured names."""
        cache_key = (
            self._base_url,
            _norm(self._document_name),
            _norm(self._course_name),
        )
        if cache_key in self._pairs_cache:
            return self._pairs_cache[cache_key]

        doc_ids = await self._find_matching_doc_ids(self._document_name)
        pairs: list[tuple[str, str]] = []
        for doc_id in doc_ids:
            course_ids = await self._find_matching_course_ids(
                doc_id, self._course_name
            )
            for course_id in course_ids:
                pairs.append((doc_id, course_id))

        if not pairs:
            raise UploadError(
                f"No course with title matching {self._course_name!r} found "
                f"under any of the {len(doc_ids)} CFDocument(s) matching "
                f"{self._document_name!r}"
            )

        if len(pairs) > 1:
            logger.info(
                "Found %d (document, course) pairs for %r / %r; will cascade",
                len(pairs),
                self._document_name,
                self._course_name,
            )

        self._pairs_cache[cache_key] = pairs
        return pairs

    # ------------------------------------------------------------------
    # Document helpers
    # ------------------------------------------------------------------

    async def _fetch_all_documents(self) -> list[dict[str, Any]]:
        if self._base_url in self._documents_cache:
            return self._documents_cache[self._base_url]

        headers = {"Authorization": f"Bearer {self._token}"}
        docs: list[dict[str, Any]] = []
        offset = 0
        page_limit = 100
        url = f"{self._base_url}/{CASE_API_PREFIX}/CFDocuments"

        async with httpx.AsyncClient() as client:
            while True:
                try:
                    resp = await client.get(
                        url,
                        headers=headers,
                        params={"limit": page_limit, "offset": offset},
                        timeout=120.0,
                    )
                    resp.raise_for_status()
                except httpx.HTTPError as exc:
                    raise UploadError(
                        f"Failed to list CFDocuments: {exc}"
                    ) from exc
                body = resp.json()
                page = body.get("CFDocuments", [])
                docs.extend(page)
                total = body.get("total", len(docs))
                if len(docs) >= total or not page:
                    break
                offset += len(page)

        self._documents_cache[self._base_url] = docs
        logger.info("Loaded %d CFDocument(s) for name matching", len(docs))
        return docs

    async def _find_matching_doc_ids(self, name: str) -> list[str]:
        """Return identifiers of all CFDocuments whose title matches *name*."""
        docs = await self._fetch_all_documents()
        matches = _match_by_title(docs, name, title_getters=("title",))
        if not matches:
            titles = [str(d.get("title", "(untitled)")) for d in docs[:20]]
            hint = f" Sample titles: {titles!r}" if docs else ""
            raise UploadError(
                f"No CFDocument with title matching {name!r} "
                f"(case-insensitive exact match).{hint}"
            )
        doc_ids: list[str] = []
        for m in matches:
            doc_id = m.get("identifier")
            if doc_id:
                doc_ids.append(str(doc_id))
        if not doc_ids:
            raise UploadError(
                f"CFDocument(s) matched title {name!r} but all are missing "
                f"an identifier field"
            )
        if len(doc_ids) > 1:
            logger.info(
                "Found %d CFDocuments matching title %r; will cascade",
                len(doc_ids),
                name,
            )
        return doc_ids

    # ------------------------------------------------------------------
    # Course helpers
    # ------------------------------------------------------------------

    async def _fetch_courses_for_document(self, document_id: str) -> list[dict[str, Any]]:
        cache_key = (self._base_url, document_id)
        if cache_key in self._courses_cache:
            return self._courses_cache[cache_key]

        url = (
            f"{self._base_url}/{CURRICULUM_API_PREFIX}"
            f"/documents/{document_id}/courses"
        )
        headers = {"Authorization": f"Bearer {self._token}"}

        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(url, headers=headers, timeout=120.0)
                resp.raise_for_status()
            except httpx.HTTPError as exc:
                raise UploadError(
                    f"Failed to list courses for document {document_id[:12]}...: {exc}"
                ) from exc
            body = resp.json()

        courses = body if isinstance(body, list) else body.get("items", body.get("courses", []))
        if not isinstance(courses, list):
            courses = []
        self._courses_cache[cache_key] = courses
        logger.info(
            "Loaded %d course(s) for document %s...",
            len(courses),
            document_id[:12],
        )
        return courses

    async def _find_matching_course_ids(self, document_id: str, name: str) -> list[str]:
        """Return ids of courses matching *name* under *document_id*.

        Returns an empty list (not an error) when no course matches — the
        caller aggregates across documents and raises if no pair is found.
        """
        courses = await self._fetch_courses_for_document(document_id)
        matches = _match_by_title(
            courses,
            name,
            title_getters=("title", "name"),
        )
        course_ids: list[str] = []
        for m in matches:
            cid = m.get("id")
            if cid:
                course_ids.append(str(cid))
        return course_ids

    # ------------------------------------------------------------------
    # Course tree
    # ------------------------------------------------------------------

    async def _fetch_course_tree(
        self, document_id: str, course_id: str
    ) -> dict[str, str]:
        """Fetch the full course tree and build a code -> UUID map."""
        tree_key = (self._base_url, document_id, course_id)
        if tree_key in self._tree_cache:
            return self._tree_cache[tree_key]

        url = (
            f"{self._base_url}/{CURRICULUM_API_PREFIX}"
            f"/documents/{document_id}/courses/{course_id}"
        )
        headers = {"Authorization": f"Bearer {self._token}"}

        async with httpx.AsyncClient() as client:
            try:
                resp = await client.get(url, headers=headers, timeout=120.0)
                resp.raise_for_status()
            except httpx.HTTPError as exc:
                raise UploadError(
                    f"Failed to fetch course tree for document={document_id[:12]}... "
                    f"course={course_id[:12]}...: {exc}"
                ) from exc
            body = resp.json()

        items = body.get("items", [])
        code_map: dict[str, str] = {}
        self._walk_tree(items, code_map)

        logger.info(
            "Loaded %d code->UUID mappings from course %s... (document=%s...)",
            len(code_map),
            course_id[:12],
            document_id[:12],
        )
        self._tree_cache[tree_key] = code_map
        return code_map

    @staticmethod
    def _walk_tree(nodes: list[dict[str, Any]], code_map: dict[str, str]) -> None:
        """Recursively collect code -> id pairs from the course tree."""
        for node in nodes:
            code = node.get("code")
            node_id = node.get("id")
            if code and node_id:
                code_map[code] = node_id
            children = node.get("children", [])
            if children:
                CaseResolver._walk_tree(children, code_map)
