"""Scan QTI XMLs for media references and prepare assets for ZIP bundling.

Categorizes each URL found in ``src`` or ``data-*`` attributes:
- Local relative path -> resolve against ``media_root``, bundle in ZIP
- Whitelisted external -> leave as-is
- Non-whitelisted external -> download and rewrite to local path (if enabled)

PCI ``data-item-path-uri`` URLs are left as-is — the QTI player
loads PCI modules directly from their web-hosted location at runtime.

``href`` attributes with external URLs are always allowed and skipped.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

from ..builders.base_builder import BuildResult
from .config import is_whitelisted

_ATTR_PATTERN = re.compile(
    r'(src|href|data-[\w-]+)\s*=\s*["\']([^"\']*?)["\']',
    re.IGNORECASE,
)

@dataclass
class AssetManifest:
    """Result of scanning XMLs for media references."""

    local_files: dict[str, Path] = field(default_factory=dict)
    downloads: dict[str, str] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    rewritten_xmls: dict[str, str] = field(default_factory=dict)


def _is_external(url: str) -> bool:
    return url.startswith("http://") or url.startswith("https://")


def _extract_domain(url: str) -> str:
    return urlparse(url).hostname or ""


_PATH_EXT_RE = re.compile(r"\.\w{1,5}$")


def _looks_like_path(value: str) -> bool:
    """Heuristic: does this non-external value look like a file path?

    Returns True for values like ``images/foo.png`` or ``style.css``.
    Returns False for numeric/config data values like ``0,0.25,0.5``.
    """
    if "/" in value:
        return True
    return bool(_PATH_EXT_RE.search(value))


def _make_local_path(url: str, item_id: str) -> str:
    """Generate a local ZIP path for a downloaded external asset."""
    parsed = urlparse(url)
    filename = Path(parsed.path).name or "asset"
    return f"media/{item_id}/{filename}"


def _scan_xml(
    xml_str: str,
    item_id: str,
    *,
    xml_subdir: str,
    media_root: Path | None,
    download_external: bool,
    manifest: AssetManifest,
    generated_refs: set[str] | None = None,
) -> str:
    """Scan a single XML string for asset references.

    Parameters
    ----------
    xml_subdir:
        The subdirectory the XML file lives in within the ZIP
        (e.g. ``"items"`` or ``"stimuli"``).  Used to compute the
        correct relative path from the XML to the media root.

    Returns the (potentially rewritten) XML string.
    """
    depth = len(Path(xml_subdir).parts) if xml_subdir else 0
    rel_prefix = "../" * depth

    rewritten = False

    def _replace_match(m: re.Match) -> str:
        nonlocal rewritten
        attr_name = m.group(1).lower()
        value = m.group(2)

        if not value or value.startswith("#"):
            return m.group(0)

        if attr_name == "href" and _is_external(value):
            return m.group(0)

        if not _is_external(value):
            if attr_name in ("src", "href") or attr_name.startswith("data-"):
                if attr_name.startswith("data-") and not _looks_like_path(value):
                    return m.group(0)
                if generated_refs and value in generated_refs:
                    return m.group(0)
                if media_root is not None:
                    local_path = media_root / value
                    if local_path.exists():
                        zip_path = f"media/{value}"
                        manifest.local_files[zip_path] = local_path
                        src_path = f"{rel_prefix}{zip_path}"
                        if src_path != value:
                            rewritten = True
                            quote = m.group(0)[len(m.group(1)) + 1]
                            return f'{m.group(1)}={quote}{src_path}{quote}'
                    else:
                        manifest.warnings.append(
                            f"Local asset not found: {value} (item {item_id})"
                        )
            return m.group(0)

        domain = _extract_domain(value)

        if is_whitelisted(domain):
            return m.group(0)

        if attr_name.startswith("data-"):
            return m.group(0)

        if attr_name == "src" and download_external:
            zip_path = _make_local_path(value, item_id)
            manifest.downloads[zip_path] = value
            src_path = f"{rel_prefix}{zip_path}"
            rewritten = True
            quote = m.group(0)[len(m.group(1)) + 1]
            return f'{m.group(1)}={quote}{src_path}{quote}'

        if attr_name == "src" and not download_external:
            manifest.warnings.append(
                f"External URL in src will be rejected by TimeBack "
                f"(set download_external=True to bundle): "
                f"src=\"{value}\" (item {item_id})"
            )

        return m.group(0)

    result_xml = _ATTR_PATTERN.sub(_replace_match, xml_str)

    if rewritten:
        manifest.rewritten_xmls[item_id] = result_xml

    return result_xml


def resolve_assets(
    results: list[BuildResult],
    *,
    media_root: Path | None = None,
    download_external: bool = False,
) -> AssetManifest:
    """Scan all BuildResult XMLs for asset references.

    Parameters
    ----------
    results:
        List of BuildResult objects.
    media_root:
        Directory to resolve local relative paths against.
    download_external:
        If True, non-whitelisted external URLs in ``src`` attributes
        will be scheduled for download and rewritten to local paths.
    """
    manifest = AssetManifest()

    generated_refs: set[str] = set()
    for r in results:
        if r.stimulus_id:
            generated_refs.add(f"stimuli/{r.stimulus_id}.xml")
        for zip_path in r.generated_assets:
            generated_refs.add(f"../{zip_path}")

    for r in results:
        _scan_xml(
            r.item_xml,
            r.item_id,
            xml_subdir="items",
            media_root=media_root,
            download_external=download_external,
            manifest=manifest,
            generated_refs=generated_refs,
        )

        if r.stimulus_xml and r.stimulus_id:
            _scan_xml(
                r.stimulus_xml,
                r.stimulus_id,
                xml_subdir="stimuli",
                media_root=media_root,
                download_external=download_external,
                manifest=manifest,
                generated_refs=generated_refs,
            )

    return manifest
