"""OAuth 2.0 client credentials authentication for TimeBack."""

from __future__ import annotations

import time

import logging

import httpx

from ..exceptions import AuthenticationError
from .config import TimeBackConfig

logger = logging.getLogger(__name__)

_token_cache: dict[str, tuple[str, float]] = {}


async def get_token(config: TimeBackConfig) -> str:
    """Obtain a bearer token using client credentials grant.

    Caches tokens per ``(base_url, client_id)`` pair until 60 seconds
    before expiry.
    """
    cache_key = f"{config.base_url}|{config.client_id}"
    now = time.time()

    if cache_key in _token_cache:
        token, expires_at = _token_cache[cache_key]
        if now < expires_at:
            return token

    base_url = config.base_url.rstrip("/")

    async with httpx.AsyncClient() as client:
        try:
            resp = await client.post(
                f"{base_url}/auth/1.0/token",
                auth=(config.client_id, config.client_secret),
                data={
                    "grant_type": "client_credentials",
                    "scope": config.scope,
                },
                timeout=30.0,
            )
            resp.raise_for_status()
        except httpx.HTTPError as exc:
            raise AuthenticationError(
                f"Failed to obtain OAuth token: {exc}"
            ) from exc
        data = resp.json()

    granted = data.get("scope", "")
    logger.debug("Granted scopes: %s", granted)

    token = data["access_token"]
    expires_in = data.get("expires_in", 3600)
    _token_cache[cache_key] = (token, now + expires_in - 60)

    return token


def clear_token_cache() -> None:
    """Clear the token cache (useful for testing)."""
    _token_cache.clear()
