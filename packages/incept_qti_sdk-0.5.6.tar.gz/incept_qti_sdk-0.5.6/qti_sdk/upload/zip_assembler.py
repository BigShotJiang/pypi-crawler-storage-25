"""Assemble a QTI content package ZIP in memory."""

from __future__ import annotations

import io
import logging
import zipfile

from ..builders.base_builder import BuildResult
from ..content.svg_extractor import ensure_svg_dimensions
from .asset_resolver import AssetManifest

logger = logging.getLogger(__name__)


def _process_svg_bytes(data: bytes) -> bytes:
    """Apply dimension injection to raw SVG bytes."""
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        return data
    return ensure_svg_dimensions(text).encode("utf-8")


def assemble_zip(
    results: list[BuildResult],
    manifest_xml: str,
    asset_manifest: AssetManifest,
    *,
    downloaded_assets: dict[str, bytes] | None = None,
) -> bytes:
    """Build an in-memory ZIP containing the full QTI content package.

    Parameters
    ----------
    results:
        BuildResult objects (item XML + optional stimulus XML).
    manifest_xml:
        The imsmanifest.xml content string.
    asset_manifest:
        Resolved asset information from ``resolve_assets()``.
    downloaded_assets:
        Pre-downloaded external asset bytes, keyed by zip_path.
        Populated by the upload orchestrator after downloading.
    """
    buf = io.BytesIO()
    seen_stimuli: set[str] = set()

    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("imsmanifest.xml", manifest_xml)

        for r in results:
            xml = asset_manifest.rewritten_xmls.get(r.item_id, r.item_xml)
            zf.writestr(f"items/{r.item_id}.xml", xml)

            if r.stimulus_xml and r.stimulus_id and r.stimulus_id not in seen_stimuli:
                seen_stimuli.add(r.stimulus_id)
                stim_xml = asset_manifest.rewritten_xmls.get(r.stimulus_id, r.stimulus_xml)
                zf.writestr(f"stimuli/{r.stimulus_id}.xml", stim_xml)

        for zip_path, disk_path in asset_manifest.local_files.items():
            if zip_path.lower().endswith(".svg"):
                svg_bytes = disk_path.read_bytes()
                zf.writestr(zip_path, _process_svg_bytes(svg_bytes))
            else:
                zf.write(str(disk_path), zip_path)

        for r in results:
            for zip_path, content in r.generated_assets.items():
                zf.writestr(zip_path, content)

        if downloaded_assets:
            for zip_path, data in downloaded_assets.items():
                if zip_path.lower().endswith(".svg"):
                    zf.writestr(zip_path, _process_svg_bytes(data))
                else:
                    zf.writestr(zip_path, data)

    return buf.getvalue()
