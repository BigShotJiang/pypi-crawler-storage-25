# QTI SDK — QuestionItem Model Reference

> This document is designed for LLM consumption. Use it as context when writing
> code that maps your data model to the SDK's `QuestionItem` format.
> Generate it anytime with: `qti-sdk transformer-context`
>
> **When something is wrong**, run `qti-sdk build -i items.json -o output_dir/` or fetch from renderer ui, open the generated QTI XML, and use that output, asking an LLM to help debug validation, rendering, or mapping issues — the built XML is the ground truth for what the SDK emitted.

## 1. What This SDK Does

The QTI SDK converts a JSON representation of assessment items (`QuestionItem`)
into QTI 3.0 XML, packages them into a ZIP, and uploads them to TimeBack.

**Pipeline**: `QuestionItem JSON` → `build` → `QTI 3.0 XML files` → `upload` → `TimeBack`

**CLI quick reference**:
```
qti-sdk build   -i items.json -o output_dir/     # JSON → XML files
qti-sdk upload  -i items.json --poll              # JSON → build → upload → poll
qti-sdk status  JOB_ID --poll                     # check upload job status
qti-sdk schema                                    # dump JSON Schema
```

### Debugging for developers and generators

If you hit **validation errors**, **unexpected player or TimeBack behavior**, or you are **unsure how your JSON maps to QTI**, do not rely on JSON alone:

1. Run **`qti-sdk build -i items.json -o output_dir/`** (same inputs you would upload).
2. Inspect the **generated XML** under `output_dir/` — item files, manifest, and related assets — that is what the SDK actually produced.
3. To get help from an **LLM**, paste **relevant XML snippets** (and your `QuestionItem` JSON if useful). Describe the symptom and ask whether the XML matches QTI 3 expectations or what to change in JSON to get your desired behaviour.

Iterating against visible XML is usually faster than guessing from JSON only.

---

## 2. QuestionItem Structure

A `QuestionItem` is the top-level object. It represents one assessment item.

### Required Fields

| Field | Type | Description |
|---|---|---|
| `question` | `string` | The stem / prompt. Supports Markdown and LaTeX (`$...$` inline, `$$...$$` block). |
| `behavior` | `object` | How the item scores and gives feedback. See Section 4. |
| `interactions` | `array` (min 1) | One or more interaction configs. See Section 3. |
| `packaging` | `object` | Manifest metadata: `difficulty` (required, 0.0–1.0), optional `document`/`course` for resolving standards, `curriculum_standards`, freeform metadata. |

### Optional Fields

| Field | Type | Description |
|---|---|---|
| `item_id` | `string` | Custom identifier. Auto-generated from content hash if omitted. |
| `title` | `string` | Human-readable title. |
| `stimulus` | `object` or `array` | Passage, image, audio, or video shown alongside the item. See Section 6. |
| `feedback` | `list[Feedback]` | Item-level feedback entries (explanation, hint, solution_steps, etc.). See Section 4a. |
| `companion_materials` | `object` | Tools available: `calculator` (`"basic"/"standard"/"scientific"`), `ruler`, `protractor`. |
| `scoring_dimensions` | `array` | Named rubric dimensions for multi-dimensional scoring. |
| `max_score` | `number` | Maximum possible score. |
| `grading_rubric` | `string` | HTML shown to human scorers. |
| `lang` | `string` | BCP 47 language tag (e.g. `"en-US"`, `"ar-AE"`). |
| `template` | `object` | Randomized template variables. See Advanced Features. |
| `context_declarations` | `array` | Advanced: custom QTI context variables. |
| `extension_attributes` | `object` | Freeform key-value attributes on the root element. |
| `api_scoring` | `object` | Optional external API grading (`endpoint`, optional `mastery_value`, optional `extra_fields`). When set, the delivery player POSTs responses to your service and maps the JSON result to QTI outcomes. Requires `max_score` and is incompatible with `external_graded` behavior. See [`docs/custom_grading_api.md`](../../docs/custom_grading_api.md). |

---

## 3. Choosing an Interaction Type

Each entry in the `interactions` array is a discriminated union — set the `type` field to select.

### Decision Tree

| Your question format | Use this type | Key |
|---|---|---|
| Multiple choice, pick ONE answer | `choice` | `max_selections: 1` (default) |
| Multiple choice, pick SEVERAL answers | `choice` | `max_selections: <N>` or `0` for unlimited |
| Typed answer, one blank | `text_entry` | `answers: ["accepted", "variations"]` |
| Typed answer, multiple blanks | `text_entry` | `answers: {"blank-1": [...], "blank-2": [...]}` with `<blank-N>` in prompt |
| Free response / essay / open-ended | `extended_text` | `expected_length: "brief" / "paragraph" / "essay" / "long_essay"` |
| Matching / drag-and-drop between two sets | `match` | `source_set` + `target_set` + `correct_mapping` |
| Ordering / sequencing items | `order` (**temporarily disabled** — validation raises at construction) | `items` + `correct_order` |
| Watch/listen to media, track play count | `media` | `media_type` + `sources` + `autostart` |
| Custom interactive widget (number line, graph) | `pci` | `interaction_type: "number-line-question"` etc. |

### Choice (`type: "choice"`)

```json
{
  "type": "choice",
  "choices": [
    {"id": "A", "content": "Option A", "correct": false},
    {"id": "B", "content": "Option B", "correct": true},
    {"id": "C", "content": "Option C", "correct": false},
    {"id": "D", "content": "Option D", "correct": false}
  ],
  "max_selections": 1,
  "shuffle": false
}
```

- `choices`: min 2 required. Each has `id`, `content` (Markdown), `correct` (bool).
- `max_selections`: `1` = single-select (exactly 1 correct required), `>1` or `0` = multi-select.
- `feedback` on a Choice: `list[Feedback]` — per-option feedback entries (e.g. explanation shown when that option is selected). Used with `feedback_enabled` behavior.
- `fixed` on a Choice: opts that choice out of shuffle.
- `feedback` on ChoiceConfig: `list[Feedback]` — interaction-level feedback entries (hint, solution_steps, etc.).
- `orientation` (optional): `"horizontal"` or `"vertical"` — adds presentation class `qti-orientation-*`.
- `stacking` (optional): `1..5` — adds presentation class `qti-choices-stacking-*`.

### Text Entry (`type: "text_entry"`)

**Single blank:**
```json
{
  "type": "text_entry",
  "prompt": "The capital of France is <blank>.",
  "answers": ["Paris"],
  "case_sensitive": false
}
```

**Multiple blanks:**
```json
{
  "type": "text_entry",
  "prompt": "Water is <blank-1> parts hydrogen and <blank-2> part oxygen.",
  "answers": {
    "blank-1": ["2", "two"],
    "blank-2": ["1", "one"]
  }
}
```

- `prompt`: Contains `<blank>` (single) or `<blank-1>`, `<blank-2>`, etc. (multi). If omitted, the main `question` field must contain the blank markers instead.
- `answers`: `list[str]` for single blank, `dict[str, list[str]]` for multi blank. Keys must match blank IDs (`blank-1`, `blank-2`, etc.) in `prompt` or `question`.
- `tolerance`: Absolute numeric tolerance for math answers (e.g. `0.01`).
- `case_sensitive`: Default `false`.
- `feedback`: `list[Feedback]` — interaction-level feedback entries.
- `placeholder_text` (optional): default message shown in the input until the learner types; emitted as `placeholder-text`.
- `expected_length` (optional): explicit width hint for expected character count. If omitted, SDK derives from accepted answers.
- `input_width` (optional): one of `1,2,3,4,5,6,10,15,20,25,30,35,40,45,50,72`; emitted as `qti-input-width-*` class.
- `alignment` (optional): `"left"`, `"center"`, or `"right"`; emitted as `qti-align-*` class.
- `math_input` (optional, default `false`): When `true`, the renderer shows a math keyboard for the input field. Only applies to `text_entry` interactions.
- `linked_answers` (optional, default `false`): Multi-blank only. When `true`, answer lists are positionally correlated — index 0 across all blanks forms one valid combination, index 1 forms another, etc. All blanks must have the same number of accepted answers. When `false` (default), each blank is scored independently (any accepted value for one blank can pair with any accepted value for another).

**Linked answers example** (only [3,5] and [5,3] are accepted, not [3,3] or [5,5]):
```json
{
  "type": "text_entry",
  "prompt": "<blank-1> + <blank-2> = 8",
  "answers": {
    "blank-1": ["3", "5"],
    "blank-2": ["5", "3"]
  },
  "linked_answers": true
}
```

### Extended Text (`type: "extended_text"`)

```json
{
  "type": "extended_text",
  "expected_length": "paragraph",
  "scoring_mode": "human"
}
```

- Use for essays, short-answer, free-response questions.
- `expected_length`: `"brief"` (3 lines), `"paragraph"` (6 lines), `"essay"` (15 lines), or `"long_essay"` (95 lines). Emits both `expected-lines` and a renderer height class (`qti-height-lines-*` or `sbac-height-lines-95`).
- `scoring_mode`: `"human"` or `"machine"`.
- `placeholder_text` (optional): default message shown in the textarea until the learner types; emitted as `placeholder-text`.
- Pair with `external_graded` behavior (no auto-scoring).

### Match (`type: "match"`)

```json
{
  "type": "match",
  "source_set": [
    {"id": "a1", "content": "H₂O"},
    {"id": "a2", "content": "NaCl"},
    {"id": "a3", "content": "CO₂"}
  ],
  "target_set": [
    {"id": "b1", "content": "Water"},
    {"id": "b2", "content": "Salt"},
    {"id": "b3", "content": "Carbon dioxide"}
  ],
  "correct_mapping": [["a1", "b1"], ["a2", "b2"], ["a3", "b3"]]
}
```

- `source_set` / `target_set`: Lists of `{id, content}` items. Each item also accepts `feedback: list[Feedback]` for per-option feedback.
- `correct_mapping`: Array of `[source_id, target_id]` pairs.
- All IDs referenced in `correct_mapping` must exist in the respective sets.
- `feedback` on MatchConfig: `list[Feedback]` — interaction-level feedback entries.

### Order (`type: "order"`)

> **Temporarily disabled:** constructing `OrderConfig` (JSON or Python) raises `ValidationError` until support is re-enabled. The schema below documents the intended shape.

```json
{
  "type": "order",
  "items": [
    {"id": "s1", "content": "Mix ingredients"},
    {"id": "s2", "content": "Preheat oven"},
    {"id": "s3", "content": "Bake for 30 minutes"},
    {"id": "s4", "content": "Let cool"}
  ],
  "correct_order": ["s2", "s1", "s3", "s4"],
  "partial_credit": true
}
```

- `correct_order`: List of item IDs in the correct sequence. Must contain every item ID exactly once.
- `partial_credit`: Award points per correctly placed item.
- Each `OrderItem` also accepts `feedback: list[Feedback]` for per-option feedback.
- `feedback` on OrderConfig: `list[Feedback]` — interaction-level feedback entries.
- `orientation` (optional): `"horizontal"` or `"vertical"` — adds presentation class `qti-orientation-*`.

### Media (`type: "media"`)

```json
{
  "type": "media",
  "media_type": "video",
  "sources": [{"url": "https://example.com/video.mp4", "media_type": "video/mp4"}],
  "autostart": false,
  "min_plays": 1,
  "max_plays": 3,
  "controls": true,
  "css_classes": "qti-width-1-2"
}
```

- Wraps a single `<video>` or `<audio>` element. The response variable holds an integer play count (how many times the candidate played to completion). **No scoring** — media interactions do not contribute to SCORE.
- Typically used as a **companion** in composite items: watch video, then answer a choice/text-entry question.
- `media_type`: `"video"` or `"audio"`.
- `sources`: At least one `{url, media_type}`. Maps to `<source>` elements.
- `autostart`: Required per QTI spec. `true` = play on load, `false` = user-initiated.
- `min_plays` (default 0): Minimum completions for valid response. 0 = no minimum.
- `max_plays` (default 0): Maximum completions allowed. 0 = unlimited.
- `loop` (default false): Restart automatically after each completion.
- Video-only: `poster` (poster image URL). Omit for audio.
- `css_classes` (optional): Space-separated class names on `<qti-media-interaction>` (e.g. `qti-width-1-2 qti-height-auto`). Full utility naming is in the player's `QtiAssessmentItem.scss`; overview is in the `MediaConfig` class docstring (`qti_sdk/models/interactions.py`).
- `tracks` (optional): `[{url, kind, srclang?, default?}]` for captions/subtitles. `kind`: `"subtitles"`, `"captions"`, `"descriptions"`, `"chapters"`, `"metadata"`.
- `prompt` (optional): Prompt text shown before or alongside the media.
- No `feedback` field — media interactions track play count, not user answers.

### PCI — Portable Custom Interaction (`type: "pci"`)

```json
{
  "type": "pci",
  "interaction_type": "number-line-question",
  "data_attributes": {
    "data-steps": "0,1,2,3,4,5,6,7,8,9,10",
    "data-labels": "0,2,4,6,8,10"
  },
  "correct_values": ["2.8"]
}
```

- `interaction_type`: A registered module name or custom URN.
- Registered modules: `number-line-question`, `graph-based-question`, `graph-plot-points-question`, `graph-line-inequality-question`. These auto-resolve `module`, `data_item_path_uri`, and `primary_configuration`.
- `data_attributes`: Key-value strings set as data-* attributes. This is the primary config channel for registered modules.
- `correct_values`: Optional `list[str]`. Each entry becomes a `<qti-value>` inside `<qti-correct-response>`. Format: space-separated `"x y"` for point type (e.g. `["3 4"]`), decimal string for float type (e.g. `["2.8"]`), string for string type. Required for `match-correct` scoring.
- Per-module response declaration: `number-line-question` → single/float; `graph-based-question` → single/string; `graph-plot-points-question` → multiple/point; `graph-line-inequality-question` → single/string.
- `graph-plot-points-question` authoring rule: use increment/label keys (`data-graph-increment-value`, `data-graph-label-interval`, `data-graph-x-increment-value`, etc.) and avoid `data-graph-x-step` / `data-graph-y-step`.
- For custom (non-registered) modules, you must also provide `module` and `data_item_path_uri`. Custom modules default to single/string response declaration.

---

## 4. Choosing a Behavior

The `behavior` field is a discriminated union — set the `type` field to select.

There are exactly **3** behavior types:

| Behavior | `type` value | Purpose |
|---|---|---|
| `SummativeBehavior` | `"summative"` | High-stakes test, score only, no feedback. |
| `FeedbackEnabled` | `"feedback_enabled"` | All feedback scenarios: formative practice, adaptive scaffolding, diagnostics, remediation. |
| `ExternalGraded` | `"external_graded"` | No automated scoring — human or AI grader. |

### Decision Tree

| Scenario | Use this behavior | Notes |
|---|---|---|
| Practice with immediate per-option feedback | `feedback_enabled` | Use `Choice.feedback` for per-option feedback |
| High-stakes test, no feedback shown | `summative` | Cannot have any `feedback` entries |
| Multi-attempt with hints and worked solution | `feedback_enabled` | Set `adaptive=true` and add hint/solution_steps Feedback entries |
| Multi-attempt with remediation content | `feedback_enabled` | Set `adaptive=true` and add learning_content Feedback entries |
| Human or AI graded, no auto-scoring | `external_graded` | Cannot have any `feedback` entries |
| Misconception identification | `feedback_enabled` | Single-attempt with per-option explanation feedback |

### Inference Guidance

When your source data doesn't explicitly specify a behavior, infer from context:

- **If you have per-option explanations** (e.g. `answer_explanation` in generator output) → use `feedback_enabled`. The explanations become `Choice.feedback` entries with `type: "explanation"`.
- **If the content is for practice / homework / low-stakes** → `feedback_enabled`.
- **If the content is for a test / exam / high-stakes assessment** → `summative`.
- **If questions are open-ended (essay, free-response)** → `external_graded`.
- **If you want to allow retries with progressive help** → `feedback_enabled` with `adaptive=true` and hint/solution_steps Feedback entries on the interaction or item.
- **When in doubt**, `feedback_enabled` is the safest default for generated content.

### `FeedbackEnabled` Fields

| Field | Type | Default | Description |
|---|---|---|---|
| `type` | `"feedback_enabled"` | — | Discriminator. |
| `adaptive` | `bool` | `false` | `false` = non-adaptive submission flow. `true` = adaptive multi-attempt flow. |
| `policy` | `FeedbackPolicy` | `FeedbackPolicy()` | Default show conditions per feedback type. See Section 4a. |

### Behavior JSON Examples

```json
{"type": "summative"}
```

```json
{"type": "feedback_enabled"}
```

```json
{"type": "feedback_enabled", "adaptive": true}
```

```json
{
  "type": "feedback_enabled",
  "adaptive": true,
  "policy": {
    "completion_after": 3,
    "hint": {"after_attempt": 1},
    "solution_steps": {"after_attempt": 2},
    "answer_reveal": {"after_attempt": 3}
  }
}
```

```json
{"type": "external_graded"}
```

### Build options for adaptive items

By default, adaptive items do **not** emit `qti-end-attempt-interaction` or the `RESPONSE_END_ATTEMPT` response declaration. This avoids a duplicate Submit button when the renderer (e.g. qti-3-player) provides its own wrapper Submit button. The `completionStatus` outcome and its response-processing rules are always emitted so the renderer can detect when the item is complete.

To include the end-attempt interaction for renderers that need an in-body Submit control:

- **CLI**: `qti-sdk build -i items.json -o out/ --emit-end-attempt` (or `qti-sdk upload ... --emit-end-attempt`)
- **Python API**: `builder.build(item, emit_end_attempt=True)`

---

## 4a. Feedback Model

Feedback is a first-class entity. Instead of separate fields for hints, explanations, and modal feedback, the SDK uses a unified `Feedback` object that can be attached at three levels:

1. **Per-option**: `Choice.feedback`, `MatchItem.feedback`, `OrderItem.feedback` — shown when that specific option is selected.
2. **Per-interaction**: `ChoiceConfig.feedback`, `TextEntryConfig.feedback`, `MatchConfig.feedback`, `OrderConfig.feedback` — scoped to the interaction.
3. **Per-item**: `QuestionItem.feedback` — item-level feedback rendered as modal feedback or feedback blocks.

### Feedback Entity

```json
{
  "type": "explanation",
  "content": "7 × 8 = 56 because multiplication means repeated addition.",
  "show_when": {"on_correct": true}
}
```

| Field | Type | Description |
|---|---|---|
| `type` | one of: `"explanation"`, `"hint"`, `"solution_steps"`, `"learning_content"`, `"answer_reveal"` | Feedback category. Drives default show conditions and QTI presentation. |
| `content` | `string` (Markdown), `LearningContent`, or `WorkedExampleContent` | The feedback body. Plain string for text/markdown. Use `LearningContent` for structured remediation (text or video). Use `WorkedExampleContent` with `type: "solution_steps"` for interactive step-by-step reveal. |
| `show_when` | `ShowCondition` or `null` | Per-feedback condition override. `null` = use defaults from `FeedbackPolicy`. |

#### `answer_reveal` content guidance

The `content` of an `answer_reveal` feedback entry is **displayed directly to students** after they exhaust their attempts. It is **not** post-processed or resolved by the converter — what you write is exactly what the student sees. Therefore:

- **Do NOT** put raw choice IDs like `"B"` or `"A, C"`. Students cannot map these back to the answer text.
- **DO** write student-facing prose that clearly states the correct answer, e.g.:
  - MCQ: `"<p><strong>Correct answer:</strong> 5 &times; ? = 30</p>"`
  - MSQ: `"<p><strong>Correct answer:</strong> 5/5 and 2/2</p>"`
  - Fill-in: `"<p><strong>Correct answer:</strong> Blank 1: 4</p>"`
  - Order: `"<p><strong>Correct order:</strong> Step A &rarr; Step B &rarr; Step C</p>"`
  - Match: `"<p><strong>Correct matching:</strong> Cat &rarr; Animal, Rose &rarr; Flower</p>"`
- You may include a brief rationale alongside the answer if pedagogically useful.
- **Shuffle convention**: When `shuffle=True` on the interaction, feedback text should reference answers **by content** (e.g., "The correct answer is Paris") rather than by choice ID or position (e.g., "The answer is B"), since choice order is randomized at render time.

#### Auto-generated default `answer_reveal`

For **adaptive** items (`FeedbackEnabled(adaptive=True)`), if no explicit `answer_reveal` feedback entry is provided anywhere in the item (item-level, interaction-level, or nested), the SDK automatically injects a default `answer_reveal` block with the content `"Maximum attempts reached."`. This ensures:

- The `REVEAL_ANSWER_FEEDBACK` outcome declaration is always present for adaptive items.
- The renderer can always highlight the correct response after the student exhausts their attempts.
- Students are never blocked with no indication that their attempts are exhausted.

If you provide your own `answer_reveal` feedback entry (even with empty content), the default is **not** injected.

### ShowCondition

Controls when feedback is revealed. All fields within a single `ShowCondition` are AND-ed together.

```json
{"after_attempt": 1, "on_correct": false}
```

| Field | Type | Default | Description |
|---|---|---|---|
| `after_attempt` | `int` or `null` | `null` | Show after N submissions (SDK maps to `numAttempts >= N`). |
| `on_correct` | `bool` or `null` | `null` | `true` = show on correct, `false` = show on incorrect, `null` = show regardless. |
| `match` | `list[ConditionMatch]` | `[]` | Typed matchers AND-ed together. For OR logic, use separate `Feedback` entries. |

`ConditionMatch` is a discriminated union with two variants:

- `MatchResponse`: `{"type": "response", "value": "A"}` — match against the response variable.
- `MatchTemplateVar`: `{"type": "template", "variable": "x", "value": "5"}` — match against a template variable.

### FeedbackPolicy

Attached to `FeedbackEnabled.policy`. Provides default `ShowCondition` per feedback type. Individual `Feedback` entries can override via their own `show_when`.

| Feedback type | Default ShowCondition |
|---|---|
| `explanation` | `ShowCondition()` (always shown) |
| `hint` | `ShowCondition(after_attempt=1)` |
| `solution_steps` | `ShowCondition(after_attempt=3)` |
| `learning_content` | `ShowCondition(on_correct=false)` |
| `answer_reveal` | `ShowCondition(after_attempt=4)` |

### LearningContent

Used as the `content` field in a `Feedback` entry when structured remediation is needed (instead of a plain string).

| Type | Fields | Use for |
|---|---|---|
| `text` | `text` (Markdown) | Inline instructional text |
| `video` | `url` | Video-based remediation |

Example with `LearningContent`:
```json
{
  "type": "learning_content",
  "content": {
    "type": "video",
    "url": "https://example.com/area-review.mp4"
  },
  "show_when": {"on_correct": false, "after_attempt": 2}
}
```

### WorkedExampleContent (Interactive Step-by-Step Reveal)

Used as the `content` field in a `Feedback` entry with `type: "solution_steps"` to produce an interactive worked-example reveal instead of plain HTML solution steps.

When the renderer encounters this structure, it renders a progressive step-by-step reveal UI: steps are shown sequentially, with details expandable on click, and the final step stays locked until all preceding steps have been viewed.

| Field | Type | Default | Description |
|---|---|---|---|
| `type` | `"worked_example"` | — | Discriminator (required). |
| `title` | `string` | `"Solution Steps"` | Heading shown above the step list. |
| `steps` | `list[WorkedExampleStep]` | — | Ordered list of steps (min 1). |

Each `WorkedExampleStep`:

| Field | Type | Default | Description |
|---|---|---|---|
| `summary` | `string` (Markdown) | — | Always-visible step description. Must not be empty. |
| `details` | `string` (Markdown) or `null` | `null` | Content revealed on click. If `null`, step is text-only. |

Example:
```json
{
  "type": "solution_steps",
  "content": {
    "type": "worked_example",
    "title": "Solution Steps",
    "steps": [
      {"summary": "Identify the formula", "details": "Area = length × width"},
      {"summary": "Substitute the values", "details": "$A = 8 \\times 5$"},
      {"summary": "Compute the result", "details": "$A = 40$ cm²"}
    ]
  },
  "show_when": {"after_attempt": 2}
}
```

**Backward compatibility**: If `content` is a plain string (not a `WorkedExampleContent` object), the `solution_steps` feedback renders as legacy plain HTML — no step-by-step reveal, no `tb-*` classes. Existing items with string-based `solution_steps` are unaffected.

**Validation rules**:
- `WorkedExampleContent` is only valid with `type: "solution_steps"`. Using it with any other type raises a `ValidationError`.
- Every step's `summary` must be non-empty. Empty or whitespace-only summaries raise a `ValidationError` identifying the step index.
- `LearningContent` (`TextLearningContent`, `VideoLearningContent`) cannot be used with `type: "solution_steps"`.

**TTS (Text-to-Speech) for worked example steps**: The SDK does not auto-generate accessibility catalog entries for steps. Generators that need TTS support for step content should supply entries via `QuestionItem.accessibility_catalog` with `target_path` values that address step elements, e.g. `"feedback[0].steps[0].summary"`, `"feedback[0].steps[0].details"`, `"feedback[0].steps[1].summary"`, etc.

> **TimeBack retrieval caveat**: Worked example step-by-step reveal (interactive expand/collapse with progressive unlock) requires the **original** version to be retrieved from TimeBack. If the **cleaned** version is retrieved, the `tb-*` structure is preserved as plain HTML but without interactive styling or progressive reveal behavior — it degrades to a static ordered list.

### Feedback placement and ordering

Scaffold feedback blocks (hint, solution_steps, learning_content, answer_reveal) are placed according to their source:

- **Interaction-level feedback** (on `ChoiceConfig.feedback`, `TextEntryConfig.feedback`, etc.) is rendered **near its interaction** — immediately after that interaction's correct/incorrect blocks.
- **Item-level feedback** (on `QuestionItem.feedback`) is rendered **after all interactions**.

Within each level, list order controls the visual sequence when multiple blocks are shown. Place feedback entries so that expected later reveals come later in the list; otherwise an early-revealing block (e.g. hint at attempt 1) may appear mid-way in the sequence and confuse learners.

Each scaffold type generates at most one block per item; the first occurrence wins (e.g. if both interaction and item have a hint, only the interaction's hint is rendered, near that interaction).

### Feedback Placement Summary

| Location | Field | Purpose |
|---|---|---|
| `Choice.feedback` | `list[Feedback]` | Per-option feedback shown when that choice is selected |
| `OrderItem.feedback` | `list[Feedback]` | Per-option feedback for ordering items |
| `MatchItem.feedback` | `list[Feedback]` | Per-option feedback for match items |
| `ChoiceConfig.feedback` | `list[Feedback]` | Interaction-level feedback |
| `TextEntryConfig.feedback` | `list[Feedback]` | Interaction-level feedback |
| `MatchConfig.feedback` | `list[Feedback]` | Interaction-level feedback |
| `OrderConfig.feedback` | `list[Feedback]` | Interaction-level feedback |
| `QuestionItem.feedback` | `list[Feedback]` | Item-level feedback (modal feedback or feedback blocks) |

---

## 5. Generator Output → QuestionItem Mapping

This section shows how to transform common generator output formats into valid `QuestionItem` JSON.

### MCQ → QuestionItem

Generator output:
```json
{
  "question": "What is 7 × 8?",
  "answer": "C",
  "answer_explanation": "7 × 8 = 56",
  "answer_options": [
    {"key": "A", "text": "$48$"},
    {"key": "B", "text": "$54$"},
    {"key": "C", "text": "$56$"},
    {"key": "D", "text": "$64$"}
  ],
  "image_url": [],
  "additional_details": ""
}
```

Mapping:
- `question` → `QuestionItem.question`
- `answer_options` → `interactions[0].choices` — map `key` → `id`, `text` → `content`, set `correct: true` on the choice whose `key` matches `answer`
- `answer_explanation` → `Choice.feedback` on the correct choice: `[{"type": "explanation", "content": "7 × 8 = 56"}]`
- `image_url` → `stimulus` (see Section 6)
- `additional_details` → `packaging.timeback_metadata.additional_details`
- Behavior: `{"type": "feedback_enabled"}` (explanations present)

Result:
```json
{
  "question": "What is 7 × 8?",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "choice",
    "choices": [
      {"id": "A", "content": "$48$", "correct": false},
      {"id": "B", "content": "$54$", "correct": false},
      {"id": "C", "content": "$56$", "correct": true, "feedback": [{"type": "explanation", "content": "7 × 8 = 56"}]},
      {"id": "D", "content": "$64$", "correct": false}
    ]
  }],
  "packaging": {"difficulty": 0.5}
}
```

### MSQ (Multi-Select) → QuestionItem

Same as MCQ except:
- `answer` is an array of keys (e.g. `["A", "C"]`) — mark ALL matching choices as `correct: true`
- Set `max_selections` to `len(answer)` (or `0` for unlimited selection)
- Put `answer_explanation` on `QuestionItem.feedback` as an explanation entry (since it applies to the combination, not a single choice): `[{"type": "explanation", "content": "...", "show_when": {"on_correct": true}}]`

### Fill-In → QuestionItem

Generator output:
```json
{
  "question": "The chemical formula for water is ___.",
  "answer": [
    {
      "id": "RESP_1",
      "accepted_answers": ["H2O", "h2o"],
      "answer_explanation": "Water consists of 2 hydrogen atoms and 1 oxygen atom."
    }
  ]
}
```

Mapping:
- Place blank markers in `question` (or `prompt`) using SDK format: single blank → `<blank>`, multiple blanks → `<blank-1>`, `<blank-2>`, etc. When blanks are in `question`, `prompt` can be omitted.
- `answer[].accepted_answers` → `interactions[0].answers`
  - Single blank: `answers: ["H2O", "h2o"]`
  - Multi blank: `answers: {"blank-1": [...], "blank-2": [...]}` — keys must be `blank-1`, `blank-2`, etc. (not `response1`, `RESP_1`, etc.)
- `answer[].id` (e.g. `RESP_1`, `RESP_2`) → rename to `blank-1`, `blank-2` in order
- Per-blank `answer_explanation` → `QuestionItem.feedback` as explanation entries: `[{"type": "explanation", "content": "Water consists of 2 hydrogen atoms and 1 oxygen atom."}]`

Result (single blank):
```json
{
  "question": "The chemical formula for water is ___.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "text_entry",
    "prompt": "The chemical formula for water is <blank>.",
    "answers": ["H2O", "h2o"],
    "case_sensitive": false
  }],
  "feedback": [
    {"type": "explanation", "content": "Water consists of 2 hydrogen atoms and 1 oxygen atom."}
  ],
  "packaging": {"difficulty": 0.5}
}
```

### Match → QuestionItem

Generator output:
```json
{
  "question": "Match each compound to its common name.",
  "answer": {"a1": "b2", "a2": "b3", "a3": "b1"},
  "column_a": [
    {"id": "a1", "content": "H₂O"},
    {"id": "a2", "content": "NaCl"},
    {"id": "a3", "content": "CO₂"}
  ],
  "column_b": [
    {"id": "b1", "content": "Carbon dioxide"},
    {"id": "b2", "content": "Water"},
    {"id": "b3", "content": "Salt"}
  ],
  "answer_explanation": "H₂O is water, NaCl is table salt, CO₂ is carbon dioxide."
}
```

Mapping:
- `column_a` → `interactions[0].source_set` as `[{id, content}, ...]`
- `column_b` → `interactions[0].target_set`
- `answer` dict → `interactions[0].correct_mapping` as array of `[key, value]` pairs
- `answer_explanation` → `QuestionItem.feedback` as an explanation entry: `[{"type": "explanation", "content": "..."}]`

Result:
```json
{
  "question": "Match each compound to its common name.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "match",
    "source_set": [
      {"id": "a1", "content": "H₂O"},
      {"id": "a2", "content": "NaCl"},
      {"id": "a3", "content": "CO₂"}
    ],
    "target_set": [
      {"id": "b1", "content": "Carbon dioxide"},
      {"id": "b2", "content": "Water"},
      {"id": "b3", "content": "Salt"}
    ],
    "correct_mapping": [["a1", "b2"], ["a2", "b3"], ["a3", "b1"]]
  }],
  "feedback": [
    {"type": "explanation", "content": "H₂O is water, NaCl is table salt, CO₂ is carbon dioxide."}
  ],
  "packaging": {"difficulty": 0.5}
}
```

### Difficulty Mapping

Generator difficulty strings map to `packaging.difficulty` (0.0–1.0):

| Generator value | SDK value |
|---|---|
| `"easy"` | `0.25` |
| `"medium"` | `0.50` |
| `"hard"` | `0.75` |

### Building `packaging` from Request Metadata

The `packaging` field is required. Build it from the generator's request context:

```json
{
  "packaging": {
    "difficulty": 0.50,
    "document": "Common Core Standard",
    "course": "3rd Grade",
    "curriculum_standards": [
      {"label": "CCSS.MATH.CONTENT.3.OA.A.1+1"}
    ],
    "timeback_metadata": {
      "subject": "Mathematics",
      "grade": "3",
      "toolName": "my-generator@1.0.0"
    }
  }
}
```

- `difficulty`: Required. Float 0.0–1.0.
- `document`: Required for upload when any `curriculum_standards` entry lacks `case_item_uri`. CFDocument **title** on TimeBack (case-insensitive exact match). The SDK lists `GET /case/1.1/CFDocuments` and picks the matching document.
- `course`: Required together with `document` in that case. Course **title** under that document (case-insensitive exact match). The SDK lists courses and matches by title.
- `curriculum_standards`: Required for upload — at least one entry per item. Array of `{"label": "..."}` objects. The `label` is the human-readable standard code (e.g. `CCSS.MATH.CONTENT.3.OA.A.1`, typically from `skills.substandard_id` in your source data). The SDK resolves these to CASE UUIDs against the selected course tree unless `case_item_uri` is already set.
- `timeback_metadata`: Freeform key-value pairs stored as extended attributes in the manifest.

**Validation**: Items missing `curriculum_standards`, or with unresolved labels but missing `document` / `course`, are rejected before upload with a per-item error report.

---

## 6. Stimulus (Passages and Media)

The `stimulus` field attaches a passage, image, audio, or video to the item. It can be a single object or an array for multi-passage items.

### Types

| Type | Key fields | Use for |
|---|---|---|
| `text` | `text` (Markdown) | Reading passages, data tables, problem context |
| `image` | `url`, `alt` | Diagrams, charts, photos |
| `audio` | `url` | Listening passages |
| `video` | `url` | Video clips |

### Examples

```json
"stimulus": {
  "type": "image",
  "url": "https://example.com/diagram.png",
  "alt": "A bar chart showing monthly rainfall"
}
```

```json
"stimulus": [
  {"type": "text", "text": "Read the following passage:\n\nThe water cycle..."},
  {"type": "image", "url": "https://example.com/water_cycle.png", "alt": "Water cycle diagram"}
]
```

### Mapping `image_url` from Generator Output

If the generator provides `image_url` as an array of URLs:
- Empty array → omit `stimulus`
- One URL → `"stimulus": {"type": "image", "url": "<url>", "alt": ""}`
- Multiple URLs → `"stimulus": [{"type": "image", "url": "<url1>", "alt": ""}, ...]`

### Stimulus vs Inline Prompt Media

Prefer **`stimulus`** unless inline placement is required.

- Use `stimulus` when media is standalone/shared supporting content
  (passages, reference diagrams, listening/video clips shown alongside the item).
- Use inline prompt media only when text and media must be interleaved inside
  an interaction prompt (for example: text -> image -> text in one prompt flow).

**Inline image in prompt (markdown syntax):**
```json
{
  "type": "choice",
  "prompt": "Study the diagram.\\n\\n![Circuit diagram](https://example.com/circuit.png)\\n\\nWhich component limits current?",
  "choices": [
    {"id": "A", "content": "Resistor", "correct": true},
    {"id": "B", "content": "Battery", "correct": false}
  ]
}
```

**Inline audio/video in prompt (raw HTML tags):**
```json
{
  "type": "choice",
  "prompt": "Listen to the clip, then answer.\\n\\n<audio src=\"https://example.com/clip.mp3\" controls=\"controls\"></audio>\\n\\nWhich instrument is most prominent?",
  "choices": [
    {"id": "A", "content": "Violin", "correct": true},
    {"id": "B", "content": "Trumpet", "correct": false}
  ]
}
```

Notes:
- Markdown has native syntax for images (`![alt](url)`), but not for audio/video.
- For audio/video/figure, use raw HTML tags in prompt strings.
- For boolean HTML attributes, XML-safe forms like `controls=\"controls\"` are recommended.
- Prompt `src` URLs are processed by asset resolution during packaging. With
  `download_external=true`, non-whitelisted external assets are downloaded and
  rewritten to relative ZIP media paths.
- `MarkdownStr` is a superset field: generators can provide pure Markdown,
  Markdown mixed with raw HTML, or pure HTML in the same prompt field.

**Pure HTML prompt example (also valid):**
```json
{
  "type": "choice",
  "prompt": "<p>Watch and answer.</p><video src=\"https://example.com/clip.mp4\" controls=\"controls\"></video><p>What changes in the final 10 seconds?</p>",
  "choices": [
    {"id": "A", "content": "The light turns off", "correct": true},
    {"id": "B", "content": "The camera zooms in", "correct": false}
  ]
}
```

---

## 7. Validation Rules

These constraints are enforced at parse time. Violations produce a `ValidationError`.

1. **`SummativeBehavior` and `ExternalGraded` cannot have `feedback`.** Remove all `feedback` entries (on the item, interactions, and choices) when using these behaviors, or switch to `feedback_enabled`.

2. **Single-select choice (`max_selections: 1`) requires exactly 1 correct choice.** Multi-select requires at least 1 correct.

3. **Choice IDs must be unique** within each interaction.

4. **Blank IDs must match answer keys.** For multi-blank text entry, `<blank-1>` and `<blank-2>` in `prompt` (or `question` when `prompt` is omitted) must exactly correspond to keys `"blank-1"` and `"blank-2"` in the `answers` dict.

5. **Single-blank text must contain `<blank>`.** Either `prompt` or `question` (when `prompt` is omitted) must include the `<blank>` placeholder for single-blank text entry.

6. **`correct_expression` on text entry requires `template` on the parent QuestionItem.** This is for template-computed answers.

7. **`score_expression` requires `max_score` or a matching `scoring_dimension`.** If an interaction has a custom score expression, the SDK needs to know the maximum possible score.

8. **`correct_order` must contain every item ID exactly once** in order interactions.

9. **`correct_mapping` source/target IDs must exist** in their respective `source_set`/`target_set`.

---

## 8. Complete Examples

### 8.1 Single-Select MCQ with Feedback

```json
{
  "question": "There are 5 bags with 3 apples in each bag. Which expression shows the total number of apples?",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "choice",
    "choices": [
      {"id": "A", "content": "$5 + 3$", "correct": false, "feedback": [{"type": "explanation", "content": "Addition finds the sum, not the total of equal groups."}]},
      {"id": "B", "content": "$5 \\times 3$", "correct": true, "feedback": [{"type": "explanation", "content": "Correct! 5 groups of 3 = 5 × 3 = 15."}]},
      {"id": "C", "content": "$5 - 3$", "correct": false, "feedback": [{"type": "explanation", "content": "Subtraction finds the difference."}]},
      {"id": "D", "content": "$5 \\div 3$", "correct": false, "feedback": [{"type": "explanation", "content": "Division splits into groups, not combines them."}]}
    ]
  }],
  "packaging": {
    "difficulty": 0.25,
    "document": "Common Core Standard",
    "course": "3rd Grade",
    "curriculum_standards": [
      {"label": "CCSS.MATH.CONTENT.3.OA.A.1+1"}
    ],
    "timeback_metadata": {"subject": "Mathematics", "grade": "3"}
  }
}
```

### 8.2 Multi-Select Choice

```json
{
  "question": "Which of the following are prime numbers? Select all that apply.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "choice",
    "choices": [
      {"id": "A", "content": "2", "correct": true},
      {"id": "B", "content": "4", "correct": false},
      {"id": "C", "content": "7", "correct": true},
      {"id": "D", "content": "9", "correct": false},
      {"id": "E", "content": "11", "correct": true}
    ],
    "max_selections": 3
  }],
  "packaging": {"difficulty": 0.5}
}
```

### 8.3 Single-Blank Text Entry

```json
{
  "question": "What is $7 \\times 8$?",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "text_entry",
    "prompt": "$7 \\times 8 =$ <blank>",
    "answers": ["56"]
  }],
  "packaging": {"difficulty": 0.35}
}
```

### 8.4 Multi-Blank Text Entry

```json
{
  "question": "Fill in the missing values.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "text_entry",
    "prompt": "The factors of 12 that are also factors of 8 are <blank-1> and <blank-2>.",
    "answers": {
      "blank-1": ["1", "4"],
      "blank-2": ["4", "1"]
    }
  }],
  "packaging": {"difficulty": 0.6}
}
```

### 8.5 Match Interaction

```json
{
  "question": "Match each fraction with its decimal equivalent.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "match",
    "source_set": [
      {"id": "s1", "content": "$\\frac{1}{2}$"},
      {"id": "s2", "content": "$\\frac{1}{4}$"},
      {"id": "s3", "content": "$\\frac{3}{4}$"}
    ],
    "target_set": [
      {"id": "t1", "content": "0.25"},
      {"id": "t2", "content": "0.5"},
      {"id": "t3", "content": "0.75"}
    ],
    "correct_mapping": [["s1", "t2"], ["s2", "t1"], ["s3", "t3"]]
  }],
  "packaging": {"difficulty": 0.4}
}
```

### 8.6 Order Interaction

**Temporarily disabled:** `OrderConfig` raises `ValidationError` at construction. Example shape for when support is restored:

```json
{
  "question": "Arrange these fractions from least to greatest.",
  "behavior": {"type": "feedback_enabled"},
  "interactions": [{
    "type": "order",
    "items": [
      {"id": "f1", "content": "$\\frac{3}{4}$"},
      {"id": "f2", "content": "$\\frac{1}{8}$"},
      {"id": "f3", "content": "$\\frac{1}{2}$"},
      {"id": "f4", "content": "$\\frac{7}{8}$"}
    ],
    "correct_order": ["f2", "f3", "f1", "f4"],
    "partial_credit": true
  }],
  "packaging": {"difficulty": 0.55}
}
```

### 8.7 Item with Image Stimulus

```json
{
  "question": "Look at the picture below. How many circles are there in all?",
  "behavior": {"type": "feedback_enabled"},
  "stimulus": {
    "type": "image",
    "url": "https://example.com/3_groups_of_2.png",
    "alt": "Three groups of 2 circles each"
  },
  "interactions": [{
    "type": "choice",
    "choices": [
      {"id": "A", "content": "$3 + 2 = 5$", "correct": false},
      {"id": "B", "content": "$3 \\times 2 = 6$", "correct": true},
      {"id": "C", "content": "$2 \\times 2 = 4$", "correct": false},
      {"id": "D", "content": "$3 \\times 3 = 9$", "correct": false}
    ]
  }],
  "packaging": {"difficulty": 0.3}
}
```

### 8.8 Extended Text with External Grading

```json
{
  "question": "Explain how the water cycle affects weather patterns. Use evidence from the passage to support your answer.",
  "behavior": {"type": "external_graded"},
  "stimulus": {
    "type": "text",
    "text": "The water cycle is the continuous movement of water on, above, and below the surface of the Earth..."
  },
  "interactions": [{
    "type": "extended_text",
    "expected_length": "paragraph",
    "scoring_mode": "human"
  }],
  "scoring_dimensions": [
    {"name": "Content", "max_score": 3.0, "scoring_method": "human"},
    {"name": "Evidence", "max_score": 2.0, "scoring_method": "human"}
  ],
  "max_score": 5.0,
  "packaging": {"difficulty": 0.7}
}
```

### 8.9 Multi-Attempt Adaptive with Hints and Solution Steps

**Plain string solution steps (legacy):**
```json
{
  "question": "What is the area of a rectangle with length 8 cm and width 5 cm?",
  "behavior": {
    "type": "feedback_enabled",
    "adaptive": true,
    "policy": {
      "completion_after": 3,
      "hint": {"after_attempt": 1},
      "solution_steps": {"after_attempt": 2}
    }
  },
  "interactions": [{
    "type": "text_entry",
    "prompt": "Area = <blank> cm²",
    "answers": ["40"],
    "feedback": [
      {"type": "hint", "content": "Think about what operation combines length and width to find area."},
      {"type": "solution_steps", "content": "Area = length × width = 8 × 5 = 40 cm²"}
    ]
  }],
  "packaging": {"difficulty": 0.4}
}
```

### 8.10 Multi-Attempt Adaptive with Worked Example (Interactive Step-by-Step Reveal)

**WorkedExampleContent solution steps (interactive reveal):**
```json
{
  "question": "What is the area of a rectangle with length 8 cm and width 5 cm?",
  "behavior": {
    "type": "feedback_enabled",
    "adaptive": true,
    "policy": {
      "completion_after": 3,
      "hint": {"after_attempt": 1},
      "solution_steps": {"after_attempt": 2}
    }
  },
  "interactions": [{
    "type": "text_entry",
    "prompt": "Area = <blank> cm²",
    "answers": ["40"]
  }],
  "feedback": [
    {"type": "hint", "content": "Think about what operation combines length and width to find area."},
    {
      "type": "solution_steps",
      "content": {
        "type": "worked_example",
        "title": "Solution Steps",
        "steps": [
          {"summary": "Identify the formula", "details": "Area = length × width"},
          {"summary": "Substitute the values", "details": "$A = 8 \\times 5$"},
          {"summary": "Compute the result", "details": "$A = 40$ cm²"}
        ]
      }
    }
  ],
  "packaging": {"difficulty": 0.4}
}
```

---

## 9. Shared Building Blocks (Quick Reference)

| Type | Description |
|---|---|
| `MarkdownStr` | `string` supporting Markdown formatting and LaTeX math (`$...$`, `$$...$$`). |
| `BlankTemplateStr` | `string` with `<blank>` or `<blank-N>` placeholders for text entry interactions. |
| `Stimulus` | Union of `TextStimulus`, `ImageStimulus`, `AudioStimulus`, `VideoStimulus`. |
| `CompanionMaterials` | Calculator, ruler, protractor availability. |
| `Feedback` | Feedback entry: `type` + `content` + optional `show_when`. See Section 4a. |
| `FeedbackPolicy` | Default `ShowCondition` per feedback type, attached to `FeedbackEnabled.policy`. |
| `ShowCondition` | When to reveal feedback: `after_attempt`, `on_correct`, `match`. |
| `LearningContent` | Union of `TextLearningContent` and `VideoLearningContent`. Used as `Feedback.content` for structured remediation. |
| `WorkedExampleContent` | Interactive step-by-step reveal content. Used as `Feedback.content` with `type: "solution_steps"`. Contains `title` and `steps` (list of `WorkedExampleStep` with `summary` and optional `details`). |
| `ScoringDimension` | Named rubric dimension with max score and scoring method. |
| `TemplateConfig` | Randomized template variables, constraints, and computed values. |
| `ContextVariable` | Advanced: custom QTI context declaration. |
| `ItemPackaging` | Manifest metadata: difficulty, document/course (for standard resolution), standards, freeform metadata. |

---

## 10. Advanced Features (Compact Reference)

**Companion Materials**: Attach tools available during the item. `"companion_materials": {"calculator": "scientific", "ruler": true, "protractor": false}`.

**Accessibility Catalog**: Provide alternate representations (glossary, sign language, spoken text, braille, etc.) for assistive technologies. Each entry targets an element by ID and provides content for a specific support type.

**Scoring Dimensions**: For rubric-scored items, define named dimensions with max scores: `"scoring_dimensions": [{"name": "Thesis", "max_score": 3.0, "scoring_method": "human"}]`. Interactions can target a dimension via `target_dimension`.

**Template Variables**: Randomize numeric values across item clones. Define variables with min/max/step in `template.variables`, reference them in question text as `@@var_name@@`, and optionally set `template.constraints` (e.g. `["a != b"]`) and `template.computed_values` (e.g. `{"sum": "a + b"}`).

**Score Maps**: Override default all-or-nothing scoring with weighted per-option scores. Available on choice (`ChoiceScoreMap`), text entry (`TextEntryScoreMap`), and match (`MatchScoreMap`) interactions.

**Score Expressions**: A typed expression tree for custom scoring logic. Supports `map_response`, `variable`, `base_value`, `sum`, `subtract`, `product`, `divide`. Compiles 1:1 to QTI expression elements.

**PCI (Portable Custom Interaction)**: For interactive widgets not covered by standard QTI interactions. Registered modules auto-resolve from the built-in registry; each has a specific response declaration (e.g. `graph-plot-points-question` → multiple/point). Use `correct_values` for match-correct scoring. For `graph-plot-points-question`, prefer increment/label data attributes and avoid `data-graph-x-step` / `data-graph-y-step`.

**Inline SVG**: SVG images can be embedded directly in `question`, `Choice.content`, or any Markdown string field. Use standard `<svg>...</svg>` tags. The SDK's content pipeline preserves block-level HTML through the Markdown-to-XML conversion.
