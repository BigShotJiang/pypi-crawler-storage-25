"""CLI entry-point: python -m qti_sdk {schema,build,upload,status,...}"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import os
import sys
import uuid
from pathlib import Path

from qti_sdk.models import QuestionItem
from qti_sdk.models.interactions import (
    ChoiceConfig,
    ExtendedTextConfig,
    MatchConfig,
    MediaConfig,
    OrderConfig,
    PCIConfig,
    TextEntryConfig,
)

_MODELS: dict[str, type] = {
    "QuestionItem": QuestionItem,
    "ChoiceConfig": ChoiceConfig,
    "TextEntryConfig": TextEntryConfig,
    "ExtendedTextConfig": ExtendedTextConfig,
    "MatchConfig": MatchConfig,
    "OrderConfig": OrderConfig,
    "MediaConfig": MediaConfig,
    "PCIConfig": PCIConfig,
}

logger = logging.getLogger("qti_sdk.cli")

EXIT_OK = 0
EXIT_VALIDATION = 1
EXIT_BUILD = 2
EXIT_UPLOAD = 3
EXIT_TIMEOUT = 4

# ---------------------------------------------------------------------------
# Shared CLI helpers
# ---------------------------------------------------------------------------


def _setup_logging(*, verbose: bool = False, quiet: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.WARNING if quiet else logging.INFO
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    root = logging.getLogger()
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)


def _ensure_item_id(data: dict, json_file: Path) -> None:
    """Inject a deterministic UUID v5 item_id derived from the filename stem.

    Timeback requires RFC 9562 UUIDs for item identifiers.  When loading
    from a directory, each file's stem (e.g. ``tc-k2-math-q1``) is hashed
    with a fixed namespace so the same filename always produces the same
    UUID, keeping IDs stable across rebuilds.
    """
    if not isinstance(data, dict) or data.get("item_id"):
        return
    stem = json_file.stem
    generated = str(uuid.uuid5(uuid.NAMESPACE_URL, f"urn:qti-sdk:item:{stem}"))
    data["item_id"] = generated
    logger.debug("item_id for %s -> %s", stem, generated)


def _read_input(args: argparse.Namespace) -> list | dict:
    """Read JSON from --input FILE, --input DIR (recursive), or stdin."""
    source = getattr(args, "input", None)
    if source:
        p = Path(source)
        if p.is_dir():
            items = []
            for json_file in sorted(p.rglob("*.json")):
                with open(json_file, encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, list):
                    for item in data:
                        _ensure_item_id(item, json_file)
                    items.extend(data)
                else:
                    _ensure_item_id(data, json_file)
                    items.append(data)
            if not items:
                _exit_error(
                    "ValidationError",
                    f"No .json files found in {source}",
                    exit_code=EXIT_VALIDATION,
                )
            logger.info("Loaded %d item(s) from %s", len(items), source)
            return items
        with open(source, encoding="utf-8") as f:
            return json.load(f)
    if sys.stdin.isatty():
        _exit_error("ValidationError", "No input provided. Use --input FILE, --input DIR, or pipe JSON to stdin.", exit_code=EXIT_VALIDATION)
    return json.load(sys.stdin)


def _write_output(data: dict | list, args: argparse.Namespace) -> None:
    """Write JSON to -o FILE or stdout."""
    text = json.dumps(data, indent=2, ensure_ascii=False)
    output_path = getattr(args, "output", None)
    if output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(text)
            f.write("\n")
    else:
        sys.stdout.write(text)
        sys.stdout.write("\n")
        sys.stdout.flush()


def _exit_error(
    error_type: str,
    message: str,
    *,
    details: list | None = None,
    exit_code: int = EXIT_BUILD,
) -> None:
    """Write a structured JSON error to stdout and exit."""
    payload: dict = {"error": error_type, "message": message}
    if details is not None:
        payload["details"] = details
    sys.stdout.write(json.dumps(payload, indent=2, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()
    sys.exit(exit_code)


def _resolve_config():
    """Build TimeBackConfig from env vars. Exits with error if missing."""
    from qti_sdk.upload.config import TimeBackConfig

    base_url = os.environ.get("TIMEBACK_PLATFORM_API_URL")
    client_id = os.environ.get("TIMEBACK_APPLICATION_CLIENT_ID")
    client_secret = os.environ.get("TIMEBACK_APPLICATION_CLIENT_SECRET")

    missing = []
    if not base_url:
        missing.append("TIMEBACK_PLATFORM_API_URL")
    if not client_id:
        missing.append("TIMEBACK_APPLICATION_CLIENT_ID")
    if not client_secret:
        missing.append("TIMEBACK_APPLICATION_CLIENT_SECRET")

    if missing:
        _exit_error(
            "ConfigurationError",
            f"Missing required environment variables: {', '.join(missing)}",
            exit_code=EXIT_VALIDATION,
        )

    return TimeBackConfig(
        base_url=base_url,
        client_id=client_id,
        client_secret=client_secret,
    )


def _add_common_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--input", "-i", default=None,
        help="Path to QuestionItem JSON file or directory (recursive). Reads from stdin if omitted.",
    )
    parser.add_argument(
        "--output", "-o", default=None,
        help="Output path (directory for build, file for upload/status).",
    )
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--verbose", "-v", action="store_true",
        help="Show DEBUG-level logs on stderr.",
    )
    group.add_argument(
        "--quiet", "-q", action="store_true",
        help="Suppress INFO logs; show only WARNING and above.",
    )


def _parse_items(raw: dict | list) -> list[QuestionItem]:
    """Validate raw JSON as one or more QuestionItem instances."""
    items_raw = raw if isinstance(raw, list) else [raw]
    return [QuestionItem.model_validate(item) for item in items_raw]


def _dump(model_cls: type) -> str:
    return json.dumps(model_cls.model_json_schema(), indent=2)


# ---------------------------------------------------------------------------
# context sub-command
# ---------------------------------------------------------------------------


def _run_context(args: argparse.Namespace) -> None:
    context_path = Path(__file__).parent / "data" / "model_context.md"
    content = context_path.read_text(encoding="utf-8")

    if not args.no_schema:
        schema = json.dumps(QuestionItem.model_json_schema(), indent=2)
        content += "\n---\n\n## 10. JSON Schema\n\n"
        content += "Full JSON Schema for `QuestionItem` (auto-generated):\n\n"
        content += f"```json\n{schema}\n```\n"

    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Context written to {args.output}", file=sys.stderr)
    else:
        sys.stdout.buffer.write(content.encode("utf-8"))
        sys.stdout.buffer.flush()


# ---------------------------------------------------------------------------
# build sub-command
# ---------------------------------------------------------------------------

def _run_build(args: argparse.Namespace) -> None:
    from qti_sdk.builders import QtiBuilder
    from qti_sdk.builders.base_builder import BuildResult

    raw = _read_input(args)
    items = _parse_items(raw)

    stimulus_mode = getattr(args, "stimulus_mode", "separate")
    output_dir = Path(args.output)

    logger.info("Building %d item(s)...", len(items))

    builder = QtiBuilder()
    results: list[BuildResult] = []
    for item in items:
        results.append(builder.build(item, stimulus_mode=stimulus_mode, emit_end_attempt=getattr(args, "emit_end_attempt", False)))

    items_dir = output_dir / "items"
    items_dir.mkdir(parents=True, exist_ok=True)

    seen_stimuli: set[str] = set()
    has_stimuli = any(r.stimulus_xml for r in results)
    if has_stimuli:
        stimuli_dir = output_dir / "stimuli"
        stimuli_dir.mkdir(parents=True, exist_ok=True)

    manifest_items: list[dict] = []
    for result in results:
        item_rel = f"items/{result.item_id}.xml"
        (items_dir / f"{result.item_id}.xml").write_text(result.item_xml, encoding="utf-8")

        stim_rel = None
        if result.stimulus_xml and result.stimulus_id:
            stim_rel = f"stimuli/{result.stimulus_id}.xml"
            if result.stimulus_id not in seen_stimuli:
                seen_stimuli.add(result.stimulus_id)
                (output_dir / stim_rel).write_text(result.stimulus_xml, encoding="utf-8")

        manifest_items.append({
            "item_id": result.item_id,
            "item_xml": item_rel,
            "stimulus_xml": stim_rel,
            "stimulus_id": result.stimulus_id,
            "metadata": result.metadata,
        })

    generated_media: list[str] = []
    for result in results:
        for zip_path, asset_content in result.generated_assets.items():
            asset_path = output_dir / zip_path
            asset_path.parent.mkdir(parents=True, exist_ok=True)
            if isinstance(asset_content, bytes):
                asset_path.write_bytes(asset_content)
            else:
                asset_path.write_text(asset_content, encoding="utf-8")
            generated_media.append(zip_path)

    manifest = {
        "output_dir": str(output_dir),
        "items": manifest_items,
    }
    if generated_media:
        manifest["generated_media"] = generated_media

    logger.info(
        "Wrote %d item(s), %d stimulus file(s), and %d media asset(s) to %s",
        len(results), len(seen_stimuli), len(generated_media), output_dir,
    )

    sys.stdout.write(json.dumps(manifest, indent=2, ensure_ascii=False))
    sys.stdout.write("\n")
    sys.stdout.flush()


# ---------------------------------------------------------------------------
# upload sub-command
# ---------------------------------------------------------------------------

async def _run_upload(args: argparse.Namespace) -> None:
    from qti_sdk.builders import QtiBuilder
    from qti_sdk.upload import get_job_status, upload_qti_package
    from qti_sdk.upload.status import TERMINAL_STATUSES

    raw = _read_input(args)
    items = _parse_items(raw)

    stimulus_mode = getattr(args, "stimulus_mode", "separate")
    media_root = Path(args.media_root) if args.media_root else None
    save_zip = Path(args.save_zip) if args.save_zip else None

    config = _resolve_config()

    logger.info("Building %d item(s)...", len(items))
    builder = QtiBuilder()
    results = [builder.build(item, stimulus_mode=stimulus_mode, emit_end_attempt=getattr(args, "emit_end_attempt", False)) for item in items]

    logger.info("Uploading to %s...", config.base_url)
    upload_resp = await upload_qti_package(
        results,
        config,
        media_root=media_root,
        save_zip=save_zip,
    )

    output: dict = {
        "job_id": upload_resp.job_id,
        "warnings": upload_resp.warnings,
    }
    logger.info("Upload complete. Job ID: %s", upload_resp.job_id)
    if upload_resp.warnings:
        for w in upload_resp.warnings:
            logger.warning("%s", w)

    if args.poll:
        logger.info("Polling for job completion...")
        status = await get_job_status(
            upload_resp.job_id,
            config,
            poll=True,
            poll_interval=3.0,
            poll_timeout=120.0,
        )
        status_data = status.model_dump()
        output["status"] = status_data["status"]
        output["last_updated"] = status_data["last_updated"]
        output["item_statuses"] = status_data["item_statuses"]
        logger.info("Final status: %s", status.status)

        if status.status not in TERMINAL_STATUSES:
            _write_output(output, args)
            logger.error("Poll timed out. Status: %s", status.status)
            sys.exit(EXIT_TIMEOUT)

    _write_output(output, args)


# ---------------------------------------------------------------------------
# status sub-command
# ---------------------------------------------------------------------------

async def _run_status(args: argparse.Namespace) -> None:
    from qti_sdk.upload import get_job_status
    from qti_sdk.upload.status import TERMINAL_STATUSES

    config = _resolve_config()
    job_id = args.job_id

    if args.poll:
        logger.info("Polling job %s for completion...", job_id)
    else:
        logger.info("Checking status of job %s...", job_id)

    status = await get_job_status(
        job_id,
        config,
        poll=args.poll,
        poll_interval=3.0,
        poll_timeout=120.0,
    )

    output = status.model_dump()
    logger.info("Status: %s", status.status)

    if args.poll and status.status not in TERMINAL_STATUSES:
        _write_output(output, args)
        logger.error("Poll timed out. Status: %s", status.status)
        sys.exit(EXIT_TIMEOUT)

    _write_output(output, args)


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="python -m qti_sdk",
        description="QTI SDK utilities",
    )
    sub = parser.add_subparsers(dest="command")

    # -- schema --
    schema_cmd = sub.add_parser(
        "schema",
        help="Dump JSON Schema for one or all models.",
    )
    schema_cmd.add_argument(
        "--model",
        choices=list(_MODELS.keys()),
        default=None,
        help="Model to export. Omit to export all models.",
    )
    schema_cmd.add_argument(
        "--output", "-o",
        default=None,
        help="Write to file instead of stdout.",
    )

    # -- transformer-context --
    context_cmd = sub.add_parser(
        "transformer-context",
        help="Export model guide and examples to help build a mapping from your data model to QuestionItem.",
    )
    context_cmd.add_argument(
        "--output", "-o",
        default=None,
        help="Write to file instead of stdout.",
    )
    context_cmd.add_argument(
        "--no-schema",
        action="store_true",
        help="Omit the JSON Schema appendix.",
    )

    # -- build --
    build_cmd = sub.add_parser(
        "build",
        help="Build QuestionItem JSON into QTI 3.0 XML files.",
    )
    _add_common_args(build_cmd)
    build_cmd.add_argument(
        "--stimulus-mode",
        choices=["separate", "inline"],
        default="separate",
        help="Stimulus handling: 'separate' (default) or 'inline'.",
    )
    build_cmd.add_argument(
        "--emit-end-attempt",
        action="store_true",
        default=False,
        help="Include qti-end-attempt-interaction in adaptive items (for renderers without a wrapper Submit button).",
    )

    # -- upload --
    upload_cmd = sub.add_parser(
        "upload",
        help="Build, package, and upload items to TimeBack.",
    )
    _add_common_args(upload_cmd)
    upload_cmd.add_argument(
        "--stimulus-mode",
        choices=["separate", "inline"],
        default="separate",
        help="Stimulus handling: 'separate' (default) or 'inline'.",
    )
    upload_cmd.add_argument(
        "--emit-end-attempt",
        action="store_true",
        default=False,
        help="Include qti-end-attempt-interaction in adaptive items (for renderers without a wrapper Submit button).",
    )
    upload_cmd.add_argument(
        "--media-root",
        default=None,
        help="Directory to resolve local asset paths against.",
    )
    upload_cmd.add_argument(
        "--save-zip",
        default=None,
        help="Save assembled ZIP to this path (for debugging).",
    )
    upload_cmd.add_argument(
        "--poll",
        action="store_true",
        help="Wait for job to reach terminal status before exiting.",
    )

    # -- status --
    status_cmd = sub.add_parser(
        "status",
        help="Check or poll a TimeBack ingest job.",
    )
    status_cmd.add_argument(
        "job_id",
        help="Ingest job ID returned by the upload command.",
    )
    status_cmd.add_argument(
        "--output", "-o",
        default=None,
        help="Write result JSON to file instead of stdout.",
    )
    status_cmd.add_argument(
        "--poll",
        action="store_true",
        help="Wait for job to reach terminal status before exiting.",
    )
    group = status_cmd.add_mutually_exclusive_group()
    group.add_argument("--verbose", "-v", action="store_true")
    group.add_argument("--quiet", "-q", action="store_true")

    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(1)

    # Set up logging for commands that use it
    if args.command in ("build", "upload", "status"):
        _setup_logging(verbose=args.verbose, quiet=args.quiet)

    # Load .env for commands that need credentials
    if args.command in ("upload", "status"):
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except ImportError:
            pass

    try:
        if args.command == "schema":
            if args.model:
                output = _dump(_MODELS[args.model])
            else:
                combined = {
                    name: cls.model_json_schema() for name, cls in _MODELS.items()
                }
                output = json.dumps(combined, indent=2)

            if args.output:
                with open(args.output, "w", encoding="utf-8") as f:
                    f.write(output)
                    f.write("\n")
                print(f"Schema written to {args.output}")
            else:
                print(output)

        elif args.command == "transformer-context":
            _run_context(args)

        elif args.command == "build":
            if not args.output:
                _exit_error(
                    "ValidationError",
                    "The build command requires -o / --output to specify an output directory.",
                    exit_code=EXIT_VALIDATION,
                )
            _run_build(args)

        elif args.command == "upload":
            asyncio.run(_run_upload(args))

        elif args.command == "status":
            asyncio.run(_run_status(args))

    except KeyboardInterrupt:
        sys.exit(130)
    except SystemExit:
        raise
    except Exception as exc:
        _handle_exception(exc)


def _handle_exception(exc: Exception) -> None:
    from pydantic import ValidationError as PydanticValidationError

    from qti_sdk.exceptions import BuildError, QtiSdkError, UploadError

    if isinstance(exc, PydanticValidationError):
        _exit_error(
            "ValidationError",
            str(exc.error_count()) + " validation error(s)",
            details=[
                {"loc": list(e["loc"]), "msg": e["msg"], "type": e["type"]}
                for e in exc.errors()
            ],
            exit_code=EXIT_VALIDATION,
        )
    elif isinstance(exc, json.JSONDecodeError):
        _exit_error(
            "ValidationError",
            f"Invalid JSON: {exc.msg} (line {exc.lineno}, col {exc.colno})",
            exit_code=EXIT_VALIDATION,
        )
    elif isinstance(exc, UploadError):
        _exit_error("UploadError", str(exc), exit_code=EXIT_UPLOAD)
    elif isinstance(exc, BuildError):
        _exit_error("BuildError", str(exc), exit_code=EXIT_BUILD)
    elif isinstance(exc, QtiSdkError):
        _exit_error("SdkError", str(exc), exit_code=EXIT_BUILD)
    else:
        logger.debug("Unhandled exception", exc_info=True)
        _exit_error("InternalError", str(exc), exit_code=EXIT_BUILD)


if __name__ == "__main__":
    main()
