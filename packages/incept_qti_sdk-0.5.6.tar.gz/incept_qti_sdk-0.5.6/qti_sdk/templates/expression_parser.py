"""Parse arithmetic expressions and constraints to QTI 3.0 XML elements.

Converts string expressions like ``"a + b * 2"`` into nested lxml element
trees (``qti-sum``, ``qti-product``, ``qti-variable``, ``qti-base-value``,
etc.) suitable for ``<qti-template-processing>`` blocks.

Uses Python's ``ast`` module for safe parsing with correct operator
precedence and parenthesisation.
"""

from __future__ import annotations

import ast
import re
from typing import Literal, Set

from lxml import etree

from ..exceptions import BuildError

_OP_MAP: dict[type, str] = {
    ast.Add: "qti-sum",
    ast.Sub: "qti-subtract",
    ast.Mult: "qti-product",
    ast.Div: "qti-divide",
    ast.FloorDiv: "qti-integer-divide",
    ast.Mod: "qti-integer-modulus",
    ast.Pow: "qti-power",
}

_COMPARE_MAP: dict[type, str] = {
    ast.Eq: "qti-equal",
    ast.Lt: "qti-lt",
    ast.LtE: "qti-lte",
    ast.Gt: "qti-gt",
    ast.GtE: "qti-gte",
}

_ALLOWED_NODES = (
    ast.Expression,
    ast.BinOp,
    ast.UnaryOp,
    ast.USub,
    ast.Constant,
    ast.Name,
    ast.Load,
    ast.Compare,
    ast.NotEq,
    *_OP_MAP.keys(),
    *_COMPARE_MAP.keys(),
)


def parse_arithmetic(expr: str, known_vars: Set[str] | None = None) -> etree._Element:
    """Parse an arithmetic string into a QTI expression element tree.

    Supports ``+``, ``-``, ``*``, ``/``, ``//``, ``%``, ``^`` (mapped to
    ``**`` internally), parentheses, variable names, and integer/float
    literals.

    Parameters
    ----------
    expr:
        The arithmetic expression string.  ``^`` is converted to ``**``
        before parsing so authors can use caret for exponentiation.
    known_vars:
        Optional set of valid variable names.  If provided, any ``ast.Name``
        not in this set raises ``ValueError``.
    """
    normalised = expr.replace("^", "**")
    tree = _safe_parse(normalised)
    return _compile_node(tree.body, known_vars)


def parse_constraint(
    expr: str, known_vars: Set[str] | None = None,
) -> etree._Element:
    """Parse a constraint string into a QTI boolean expression element.

    Supports comparison operators ``==``, ``!=``, ``<``, ``>``, ``<=``,
    ``>=`` with arithmetic expressions on both sides.

    Returns the boolean expression element to be placed inside a
    ``<qti-template-constraint>``.
    """
    normalised = expr.replace("^", "**")

    match = re.match(
        r"^(.+?)\s*(!=|==|<=|>=|<|>)\s*(.+)$", normalised,
    )
    if match:
        lhs_str, op_str, rhs_str = match.groups()
        return _build_comparison(lhs_str, op_str, rhs_str, known_vars)

    tree = _safe_parse(normalised)
    if isinstance(tree.body, ast.Compare):
        return _compile_compare(tree.body, known_vars)

    raise BuildError(f"Cannot parse constraint: {expr!r}")


def _safe_parse(source: str) -> ast.Expression:
    """Parse *source* as an expression and reject unsafe AST nodes."""
    try:
        tree = ast.parse(source, mode="eval")
    except SyntaxError as exc:
        raise BuildError(f"Invalid expression syntax: {source!r}") from exc
    _validate_ast(tree)
    return tree


def _validate_ast(node: ast.AST) -> None:
    """Walk the AST and reject any node type not in the allow-list."""
    if not isinstance(node, _ALLOWED_NODES):
        raise BuildError(
            f"Unsupported expression element: {type(node).__name__}"
        )
    for child in ast.iter_child_nodes(node):
        _validate_ast(child)


def _compile_node(
    node: ast.expr, known_vars: Set[str] | None,
) -> etree._Element:
    """Recursively compile an AST expression node to an lxml element."""
    if isinstance(node, ast.BinOp):
        tag = _OP_MAP.get(type(node.op))
        if tag is None:
            raise BuildError(
                f"Unsupported operator: {type(node.op).__name__}"
            )
        el = etree.Element(tag)
        el.append(_compile_node(node.left, known_vars))
        el.append(_compile_node(node.right, known_vars))
        return el

    if isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        sub = etree.Element("qti-subtract")
        zero = etree.SubElement(sub, "qti-base-value", attrib={"base-type": "integer"})
        zero.text = "0"
        sub.append(_compile_node(node.operand, known_vars))
        return sub

    if isinstance(node, ast.Constant):
        if isinstance(node.value, int):
            el = etree.Element("qti-base-value", attrib={"base-type": "integer"})
            el.text = str(node.value)
            return el
        if isinstance(node.value, float):
            el = etree.Element("qti-base-value", attrib={"base-type": "float"})
            el.text = str(node.value)
            return el
        raise BuildError(f"Unsupported constant type: {type(node.value).__name__}")

    if isinstance(node, ast.Name):
        if known_vars is not None and node.id not in known_vars:
            raise BuildError(f"Unknown variable: {node.id!r}")
        return etree.Element("qti-variable", attrib={"identifier": node.id})

    raise BuildError(f"Unsupported AST node: {type(node).__name__}")


def _build_comparison(
    lhs_str: str,
    op_str: str,
    rhs_str: str,
    known_vars: Set[str] | None,
) -> etree._Element:
    """Build a QTI comparison element from string parts."""
    lhs_tree = _safe_parse(lhs_str)
    rhs_tree = _safe_parse(rhs_str)
    lhs_el = _compile_node(lhs_tree.body, known_vars)
    rhs_el = _compile_node(rhs_tree.body, known_vars)

    if op_str == "!=":
        not_el = etree.Element("qti-not")
        eq_el = etree.SubElement(not_el, "qti-equal")
        eq_el.append(lhs_el)
        eq_el.append(rhs_el)
        return not_el

    tag_map = {"==": "qti-equal", "<": "qti-lt", ">": "qti-gt", "<=": "qti-lte", ">=": "qti-gte"}
    tag = tag_map[op_str]
    el = etree.Element(tag)
    el.append(lhs_el)
    el.append(rhs_el)
    return el


def _compile_compare(
    node: ast.Compare, known_vars: Set[str] | None,
) -> etree._Element:
    """Compile a Python ``Compare`` AST node (single comparator only)."""
    if len(node.ops) != 1 or len(node.comparators) != 1:
        raise BuildError("Only single comparisons are supported")

    op = node.ops[0]
    lhs_el = _compile_node(node.left, known_vars)
    rhs_el = _compile_node(node.comparators[0], known_vars)

    if isinstance(op, ast.NotEq):
        not_el = etree.Element("qti-not")
        eq_el = etree.SubElement(not_el, "qti-equal")
        eq_el.append(lhs_el)
        eq_el.append(rhs_el)
        return not_el

    tag = _COMPARE_MAP.get(type(op))
    if tag is None:
        raise BuildError(f"Unsupported comparison operator: {type(op).__name__}")

    el = etree.Element(tag)
    el.append(lhs_el)
    el.append(rhs_el)
    return el


# ── Type inference ──────────────────────────────────────────────────

_ALWAYS_FLOAT_OPS = frozenset({"qti-divide"})
_ALWAYS_INTEGER_OPS = frozenset({"qti-integer-divide", "qti-integer-modulus"})
_PROPAGATING_OPS = frozenset({
    "qti-sum", "qti-subtract", "qti-product", "qti-power",
})


def infer_result_type(
    element: etree._Element,
    known_var_types: dict[str, str] | None = None,
) -> Literal["integer", "float"]:
    """Infer the QTI base-type that *element* will produce at runtime.

    Walks the compiled lxml expression tree and applies QTI type rules:

    * ``qti-divide`` always produces ``"float"``
    * ``qti-integer-divide`` / ``qti-integer-modulus`` always produce ``"integer"``
    * ``qti-sum``, ``qti-subtract``, ``qti-product``, ``qti-power`` propagate
      — ``"float"`` if any operand is float, else ``"integer"``
    * ``qti-base-value`` reads its ``base-type`` attribute
    * ``qti-variable`` looks up *known_var_types*
    """
    tag = etree.QName(element.tag).localname if "}" in element.tag else element.tag

    if tag in _ALWAYS_FLOAT_OPS:
        return "float"

    if tag in _ALWAYS_INTEGER_OPS:
        return "integer"

    if tag in _PROPAGATING_OPS:
        child_types = [
            infer_result_type(child, known_var_types) for child in element
        ]
        return "float" if "float" in child_types else "integer"

    if tag == "qti-base-value":
        return element.get("base-type", "integer")  # type: ignore[return-value]

    if tag == "qti-variable":
        identifier = element.get("identifier", "")
        if known_var_types and identifier in known_var_types:
            return known_var_types[identifier]  # type: ignore[return-value]
        return "integer"

    return "integer"
