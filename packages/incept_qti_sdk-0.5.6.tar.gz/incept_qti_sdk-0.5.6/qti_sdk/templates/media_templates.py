"""Response processing templates for MediaConfig behaviors.

Media interactions track play count only — no scoring. No response
processing fragments are emitted.
"""

from __future__ import annotations

from ..models.interactions import MediaConfig
from ..models.question_item import QuestionItem


class MediaTemplates:
    """Generates response processing for media interactions.

    Media interactions have no scoring — the response variable holds
    play count. Both get() and get_interaction_rp() return empty/None.
    """

    @staticmethod
    def get(
        item: QuestionItem,
        config: MediaConfig,
        *,
        response_id: str = "RESPONSE",
        score_id: str = "SCORE",
        feedback_id: str = "FEEDBACK",
    ) -> None:
        """Return None — no response processing needed for standalone media items."""
        return None

    @staticmethod
    def get_interaction_rp(
        item: QuestionItem,
        config: MediaConfig,
        response_id: str,
        score_id: str,
        feedback_id: str | None,
        *,
        include_completion: bool = False,
    ) -> list:
        """Return empty list — no scoring fragments for media in composite items."""
        return []
