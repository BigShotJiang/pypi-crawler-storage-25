"""Response processing template generators."""
