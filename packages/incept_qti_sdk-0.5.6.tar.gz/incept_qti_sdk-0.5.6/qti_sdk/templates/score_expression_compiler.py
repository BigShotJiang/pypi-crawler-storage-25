"""Compiles Score Expression DSL trees to QTI 3.0 XML elements.

Each DSL node maps 1:1 to a QTI expression element.
"""

from __future__ import annotations

from lxml import etree

from ..exceptions import BuildError
from ..models.scoring import (
    BaseValueExpr,
    DivideExpr,
    IntegerDivideExpr,
    IntegerModulusExpr,
    MapResponseExpr,
    ProductExpr,
    ScoreExpression,
    SubtractExpr,
    SumExpr,
    VariableExpr,
)

_CONTAINER_MAP: dict[str, str] = {
    "sum": "qti-sum",
    "subtract": "qti-subtract",
    "product": "qti-product",
    "divide": "qti-divide",
    "integer_divide": "qti-integer-divide",
    "integer_modulus": "qti-integer-modulus",
}


def compile_score_expression(expr: ScoreExpression) -> etree._Element:
    """Recursively compile a ``ScoreExpression`` tree to an lxml element."""
    if isinstance(expr, MapResponseExpr):
        return etree.Element(
            "qti-map-response", attrib={"identifier": expr.identifier}
        )

    if isinstance(expr, VariableExpr):
        return etree.Element(
            "qti-variable", attrib={"identifier": expr.identifier}
        )

    if isinstance(expr, BaseValueExpr):
        el = etree.Element(
            "qti-base-value", attrib={"base-type": expr.base_type}
        )
        el.text = expr.value
        return el

    if isinstance(expr, (
        SumExpr, SubtractExpr, ProductExpr, DivideExpr,
        IntegerDivideExpr, IntegerModulusExpr,
    )):
        tag = _CONTAINER_MAP[expr.type]
        el = etree.Element(tag)
        for operand in expr.operands:
            el.append(compile_score_expression(operand))
        return el

    raise BuildError(f"Unknown score expression type: {type(expr).__name__}")
