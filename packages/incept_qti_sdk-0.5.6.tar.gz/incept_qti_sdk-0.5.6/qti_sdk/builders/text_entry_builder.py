"""Builder for QuestionItem with TextEntryConfig -> QTI 3.0 XML."""

from __future__ import annotations

from lxml import etree

from ..models.base import Feedback
from ..models.behaviors import (
    ExternalGraded,
    FeedbackEnabled,
    SummativeBehavior,
)
from ..models.interactions import TextEntryConfig
from ..models.question_item import QuestionItem
from ..templates._helpers import ensure_default_answer_reveal
from ..templates.api_scoring_templates import ApiScoringTemplates
from ..templates.text_entry_templates import TextEntryTemplates, _response_id_for_blank
from .base_builder import BaseBuilder, BuildResult


class TextEntryBuilder(BaseBuilder):
    """Converts a QuestionItem with a single TextEntryConfig into QTI 3.0 XML."""

    def build(
        self, item: QuestionItem, *, emit_end_attempt: bool = False
    ) -> BuildResult:
        """Build a text-entry (fill-in-the-blank) item into QTI 3.0 XML.

        Supports single-blank and multi-blank modes, case sensitivity,
        numeric tolerance, and template-computed answers.
        """
        config: TextEntryConfig = item.interactions[0]  # type: ignore[assignment]

        item_id = self._make_item_id("textentry", item.item_id)
        self._reset_build_state(item_id)
        is_adaptive = self._is_adaptive(item.behavior)

        title = item.title or "TextEntryInteraction"

        children: list[etree._Element] = []
        children.extend(self._build_context_declarations(item.context_declarations))

        children.extend(self._build_response_decls(item, config))

        if is_adaptive and emit_end_attempt:
            children.append(
                self._build_response_declaration(
                    "RESPONSE_END_ATTEMPT",
                    "single",
                    "boolean",
                )
            )

        children.extend(self._build_outcome_declarations(item))

        tmpl_decls, tmpl_proc = self._build_template_elements(item)
        children.extend(tmpl_decls)
        if tmpl_proc is not None:
            children.append(tmpl_proc)

        stim_ref, stim_content, stim_id = self._build_stimulus_ref(
            item.stimulus,
            item_id,
        )
        if stim_ref is not None:
            children.append(stim_ref)

        comp = self._build_companion_materials(item.companion_materials)
        if comp is not None:
            children.append(comp)

        body = self._build_item_body(item, config, is_adaptive, emit_end_attempt)
        self._wire_catalog_refs(body, item)
        children.append(body)

        catalog = self._build_catalog_info(item.accessibility_catalog)
        if catalog is not None:
            children.append(catalog)

        if item.api_scoring:
            rp = ApiScoringTemplates.get(item)
            children.append(rp)
        else:
            sid = self._effective_score_id(config)
            rp = TextEntryTemplates.get(item, config, score_id=sid)
            if rp is not None:
                self._append_dimension_to_score(rp, item)
                if any(fb.type == "explanation" for fb in item.feedback):
                    from ..templates._helpers import build_modal_feedback_rp

                    build_modal_feedback_rp(rp)
                children.append(rp)

        if not item.api_scoring:
            fmt = self._get_format_map(item)
            children.extend(
                self._build_modal_feedback_elements(item.feedback, format_map=fmt),
            )

        root = self._build_assessment_item(
            item_id,
            title,
            is_adaptive,
            children,
            lang=item.lang,
            extension_attributes=item.extension_attributes,
        )

        stimulus_xml_str = None
        if stim_content and stim_id:
            from .stimulus_builder import StimulusBuilder

            sb = StimulusBuilder()
            stimulus_xml_str = sb.build(item.stimulus, stim_id)
            self._generated_assets.update(sb._generated_assets)

        return BuildResult(
            item_xml=self.serialize(root),
            stimulus_xml=stimulus_xml_str,
            stimulus_id=stim_id,
            item_id=item_id,
            metadata={
                "interaction_type": "textEntryInteraction",
                "feedback_type": "adaptive" if is_adaptive else "nonadaptive",
            },
            packaging=item.packaging,
            generated_assets=self._generated_assets,
        )

    def _build_response_decls(
        self,
        item: QuestionItem,
        config: TextEntryConfig,
        response_id: str = "RESPONSE",
    ) -> list[etree._Element]:
        has_correct_expr = config.correct_expression is not None

        if not config.is_multi_blank:
            assert isinstance(config.answers, list)
            correct_vals = None if has_correct_expr else config.answers
            return [
                self._build_response_declaration(
                    response_id,
                    "single",
                    "string",
                    correct_vals,
                    mapping=config.score_map,
                )
            ]

        assert isinstance(config.answers, dict)
        decls: list[etree._Element] = []
        for bid in config.resolve_blank_ids(item.question):
            rid = _response_id_for_blank(bid, response_id)
            correct_vals = None if has_correct_expr else config.answers[bid]
            decls.append(
                self._build_response_declaration(
                    rid,
                    "single",
                    "string",
                    correct_vals,
                )
            )
        return decls

    def _process_question_with_blanks(
        self,
        item: QuestionItem,
        config: TextEntryConfig,
        response_id: str = "RESPONSE",
    ) -> str:
        """Replace <blank> / <blank-N> placeholders with QTI text entry elements."""
        fmt = self._get_format_map(item)
        question_html = self._process_content(item.question, format_map=fmt)
        expected_length = config.expected_length or self._calculate_expected_length(
            config
        )

        if not config.is_multi_blank:
            interaction_xml = self._text_entry_interaction_xml(
                response_id=response_id,
                expected_length=expected_length,
                config=config,
            )
            return question_html.replace("&lt;blank&gt;", interaction_xml)

        result = question_html
        for bid in reversed(config.resolve_blank_ids(item.question)):
            rid = _response_id_for_blank(bid, response_id)
            interaction_xml = self._text_entry_interaction_xml(
                response_id=rid,
                expected_length=expected_length,
                config=config,
            )
            placeholder = f"&lt;{bid}&gt;"
            result = result.replace(placeholder, interaction_xml)
        return result

    def _text_entry_interaction_xml(
        self,
        *,
        response_id: str,
        expected_length: int,
        config: TextEntryConfig,
    ) -> str:
        classes = ["inline-text-entry"]
        if config.input_width is not None:
            classes.append(f"qti-input-width-{config.input_width}")
        if config.alignment is not None:
            classes.append(f"qti-align-{config.alignment}")

        attrs = {
            "response-identifier": response_id,
            "expected-length": str(expected_length),
            "class": " ".join(classes),
        }
        if config.placeholder_text:
            attrs["placeholder-text"] = config.placeholder_text
        if config.math_input:
            attrs["data-math-input"] = "true"

        el = etree.Element("qti-text-entry-interaction", attrib=attrs)
        return etree.tostring(el, encoding="unicode")

    def _build_item_body(
        self,
        item: QuestionItem,
        config: TextEntryConfig,
        is_adaptive: bool,
        emit_end_attempt: bool = False,
    ) -> etree._Element:
        body = etree.Element("qti-item-body")

        rb = self._build_rubric_block(item.grading_rubric)
        if rb is not None:
            body.append(rb)

        stem_div = etree.SubElement(body, "div", attrib={"class": "stem"})
        question_html = self._process_question_with_blanks(item, config)
        self._set_inner_html(stem_div, question_html)

        fmt = self._get_format_map(item)
        if config.instructions:
            inst_div = etree.SubElement(body, "div", attrib={"class": "instruction"})
            inst_html = self._process_content(config.instructions, format_map=fmt)
            self._set_inner_html(inst_div, inst_html)

        if isinstance(item.behavior, FeedbackEnabled):
            _all_fb = list(config.feedback) + list(item.feedback)
            correct_fb = next(
                (
                    fb
                    for fb in _all_fb
                    if fb.type == "explanation"
                    and fb.show_when
                    and fb.show_when.on_correct is True
                ),
                None,
            )
            incorrect_fb = next(
                (
                    fb
                    for fb in _all_fb
                    if fb.type == "explanation"
                    and fb.show_when
                    and fb.show_when.on_correct is False
                ),
                None,
            )
            correct_html = (
                self._render_feedback_content(correct_fb, format_map=fmt)
                if correct_fb
                else "<p>Correct!</p>"
            )
            incorrect_html = (
                self._render_feedback_content(incorrect_fb, format_map=fmt)
                if incorrect_fb
                else "<p>Incorrect.</p>"
            )
            body.append(
                self._build_feedback_block(
                    identifier="correct",
                    outcome_identifier="FEEDBACK",
                    content_html=correct_html,
                    css_class="qti-feedback-correct",
                )
            )
            body.append(
                self._build_feedback_block(
                    identifier="incorrect",
                    outcome_identifier="FEEDBACK",
                    content_html=incorrect_html,
                    css_class="qti-feedback-incorrect",
                )
            )

        _all_fb = ensure_default_answer_reveal(
            item.behavior, list(config.feedback) + list(item.feedback)
        )
        n_config = len(config.feedback)

        def _path_resolver(idx: int, _fb: Feedback) -> str | None:
            if idx < n_config:
                return f"interactions[0].feedback[{idx}]"
            return f"feedback[{idx - n_config}]"

        for fb in self._build_scaffold_feedback(
            _all_fb, format_map=fmt, path_resolver=_path_resolver
        ):
            body.append(fb)

        if item.api_scoring and isinstance(item.behavior, FeedbackEnabled):
            body.append(self._build_generated_feedback_block())

        if is_adaptive and emit_end_attempt:
            body.append(self._build_end_attempt_interaction())

        return body

    def _calculate_expected_length(self, config: TextEntryConfig) -> int:
        if config.is_multi_blank:
            assert isinstance(config.answers, dict)
            all_answers = [a for answers in config.answers.values() for a in answers]
        else:
            assert isinstance(config.answers, list)
            all_answers = config.answers
        raw = max((len(a) for a in all_answers), default=10) + 1
        return min(raw, 40)
