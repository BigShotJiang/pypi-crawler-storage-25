"""Builder for QuestionItem with PCIConfig -> QTI 3.0 XML."""

from __future__ import annotations

from typing import Any

from lxml import etree

from ..content.svg_extractor import extract_inline_svgs, restore_img_placeholders
from ..models.behaviors import FeedbackEnabled
from ..models.interactions import PCI_MODULE_REGISTRY, PCIConfig
from ..models.question_item import QuestionItem
from ..templates._helpers import ensure_default_answer_reveal
from ..templates.api_scoring_templates import ApiScoringTemplates
from ..templates.pci_templates import PCITemplates
from .base_builder import BaseBuilder, BuildResult


class PCIBuilder(BaseBuilder):
    """Converts a QuestionItem with a single PCIConfig into QTI 3.0 XML."""

    def build(
        self, item: QuestionItem, *, emit_end_attempt: bool = False
    ) -> BuildResult:
        """Build a Portable Custom Interaction item into QTI 3.0 XML.

        Resolves the PCI module from the built-in registry (or uses explicit
        URN/module fields), emits ``<qti-portable-custom-interaction>`` with
        data attributes, properties, and template variable mappings.
        """
        config: PCIConfig = item.interactions[0]  # type: ignore[assignment]

        item_id = self._make_item_id("pci", item.item_id)
        self._reset_build_state(item_id)
        is_adaptive = self._is_adaptive(item.behavior)

        title = item.title or "PortableCustomInteraction"

        children: list[etree._Element] = []
        children.extend(self._build_context_declarations(item.context_declarations))

        registry = PCI_MODULE_REGISTRY.get(config.interaction_type)
        cardinality = (
            registry.get("response_cardinality", "single") if registry else "single"
        )
        base_type = (
            registry.get("response_base_type", "string") if registry else "string"
        )
        children.append(
            self._build_response_declaration(
                "RESPONSE", cardinality, base_type, config.correct_values
            )
        )

        if is_adaptive and emit_end_attempt:
            children.append(
                self._build_response_declaration(
                    "RESPONSE_END_ATTEMPT",
                    "single",
                    "boolean",
                )
            )

        children.extend(self._build_outcome_declarations(item, supports_reveal=False))

        tmpl_decls, tmpl_proc = self._build_template_elements(item)
        children.extend(tmpl_decls)
        if tmpl_proc is not None:
            children.append(tmpl_proc)

        stim_ref, stim_content, stim_id = self._build_stimulus_ref(
            item.stimulus,
            item_id,
        )
        if stim_ref is not None:
            children.append(stim_ref)

        comp = self._build_companion_materials(item.companion_materials)
        if comp is not None:
            children.append(comp)

        body = self._build_item_body(item, config, is_adaptive, emit_end_attempt)
        self._wire_catalog_refs(body, item)
        children.append(body)

        catalog = self._build_catalog_info(item.accessibility_catalog)
        if catalog is not None:
            children.append(catalog)

        if item.api_scoring:
            rp = ApiScoringTemplates.get(item)
            children.append(rp)
        else:
            sid = self._effective_score_id(config)
            rp = PCITemplates.get(item, config, score_id=sid)
            if rp is not None:
                self._append_dimension_to_score(rp, item)
                if any(fb.type == "explanation" for fb in item.feedback):
                    from ..templates._helpers import build_modal_feedback_rp

                    build_modal_feedback_rp(rp)
                children.append(rp)

        if not item.api_scoring:
            fmt = self._get_format_map(item)
            children.extend(
                self._build_modal_feedback_elements(item.feedback, format_map=fmt),
            )

        root = self._build_assessment_item(
            item_id,
            title,
            is_adaptive,
            children,
            lang=item.lang,
            extension_attributes=item.extension_attributes,
        )

        stimulus_xml_str = None
        if stim_content and stim_id:
            from .stimulus_builder import StimulusBuilder

            sb = StimulusBuilder()
            stimulus_xml_str = sb.build(item.stimulus, stim_id)
            self._generated_assets.update(sb._generated_assets)

        return BuildResult(
            item_xml=self.serialize(root),
            stimulus_xml=stimulus_xml_str,
            stimulus_id=stim_id,
            item_id=item_id,
            metadata={
                "interaction_type": "portableCustomInteraction",
                "feedback_type": "adaptive" if is_adaptive else "nonadaptive",
            },
            packaging=item.packaging,
            generated_assets=self._generated_assets,
        )

    # -----------------------------------------------------------------
    # Module resolution helpers
    # -----------------------------------------------------------------

    @staticmethod
    def _resolve_module(config: PCIConfig) -> tuple[str, str | None, str | None, str]:
        """Return (urn, module_name, data_uri, primary_cfg) from registry + explicit fields."""
        registry = PCI_MODULE_REGISTRY.get(config.interaction_type)
        urn = registry["urn"] if registry else config.interaction_type
        module_name = config.module or (config.interaction_type if registry else None)
        data_uri = config.data_item_path_uri or (
            registry["data_item_path_uri"] if registry else None
        )
        primary_cfg = config.primary_configuration or (
            registry["primary_configuration"]
            if registry
            else "modules/module_resolution.json"
        )
        return urn, module_name, data_uri, primary_cfg

    # -----------------------------------------------------------------
    # Interaction element
    # -----------------------------------------------------------------

    def _build_interaction_element(
        self,
        item: QuestionItem,
        config: PCIConfig,
        response_id: str = "RESPONSE",
        feedback_id: str = "FEEDBACK",
    ) -> etree._Element:
        """Return the ``<qti-portable-custom-interaction>`` element."""
        interaction = etree.Element("qti-portable-custom-interaction")
        interaction.set("response-identifier", response_id)

        urn, module_name, data_uri, primary_cfg = self._resolve_module(config)

        interaction.set("custom-interaction-type-identifier", urn)
        if module_name:
            interaction.set("module", module_name)
        if data_uri:
            interaction.set("data-item-path-uri", data_uri)

        for attr_name, attr_value in config.data_attributes.items():
            interaction.set(attr_name, attr_value)

        if config.template_variable_mappings:
            for mapping in config.template_variable_mappings:
                tv = etree.SubElement(interaction, "qti-template-variable")
                tv.set("template-identifier", mapping.template_identifier)
                tv.set("configuration-property", mapping.configuration_property)

        if config.properties:
            self._build_properties_element(interaction, config.properties)

        if config.prompt:
            fmt = self._get_format_map(item)
            prompt_el = etree.SubElement(interaction, "qti-prompt")
            prompt_html = self._process_content(config.prompt, format_map=fmt)
            self._set_inner_html(prompt_el, prompt_html)

        if config.interaction_markup:
            markup_html, svgs, img_map = extract_inline_svgs(
                config.interaction_markup,
                self._current_item_id,
            )
            self._generated_assets.update(svgs)
            markup_html = restore_img_placeholders(markup_html, img_map)
            markup_el = etree.SubElement(interaction, "qti-interaction-markup")
            self._set_inner_html(markup_el, markup_html)

        modules_el = etree.SubElement(interaction, "qti-interaction-modules")
        modules_el.set("primary-configuration", primary_cfg)

        return interaction

    @staticmethod
    def _build_properties_element(
        parent: etree._Element,
        props: dict[str, Any],
        key: str | None = None,
    ) -> None:
        """Recursively build ``<properties>`` / ``<entry>`` elements."""
        attrib = {"key": key} if key else {}
        container = etree.SubElement(parent, "properties", attrib=attrib)
        for k, v in props.items():
            if isinstance(v, dict):
                PCIBuilder._build_properties_element(container, v, key=k)
            else:
                entry = etree.SubElement(container, "entry", key=k)
                entry.text = str(v)

    # -----------------------------------------------------------------
    # Item body
    # -----------------------------------------------------------------

    def _build_item_body(
        self,
        item: QuestionItem,
        config: PCIConfig,
        is_adaptive: bool,
        emit_end_attempt: bool = False,
    ) -> etree._Element:
        fmt = self._get_format_map(item)
        body = etree.Element("qti-item-body")

        rb = self._build_rubric_block(item.grading_rubric)
        if rb is not None:
            body.append(rb)

        stem_div = etree.SubElement(body, "div", attrib={"class": "stem"})
        question_html = self._process_content(item.question, format_map=fmt)
        self._set_inner_html(stem_div, question_html)

        if config.label:
            label_div = etree.SubElement(body, "div", attrib={"class": "part-label"})
            label_div.text = config.label

        body.append(self._build_interaction_element(item, config))

        fmt = self._get_format_map(item)
        _all_fb = ensure_default_answer_reveal(
            item.behavior, list(getattr(config, "feedback", [])) + list(item.feedback)
        )
        n_config = len(getattr(config, "feedback", []))
        path_resolver = (
            lambda idx, _fb: f"interactions[0].feedback[{idx}]"
            if idx < n_config
            else f"feedback[{idx - n_config}]"
        )
        for fb in self._build_scaffold_feedback(
            _all_fb, format_map=fmt, path_resolver=path_resolver
        ):
            body.append(fb)

        if item.api_scoring and isinstance(item.behavior, FeedbackEnabled):
            body.append(self._build_generated_feedback_block())

        if is_adaptive and emit_end_attempt:
            body.append(self._build_end_attempt_interaction())

        return body
