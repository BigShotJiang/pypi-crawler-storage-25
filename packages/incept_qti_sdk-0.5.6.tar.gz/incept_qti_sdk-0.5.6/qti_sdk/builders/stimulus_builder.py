"""Builder for standalone qti-assessment-stimulus XML files."""

from __future__ import annotations

import logging
from typing import Union

from lxml import etree

from ..models.base import (
    AudioStimulus,
    ImageStimulus,
    Stimulus,
    TextStimulus,
    VideoStimulus,
)
from .base_builder import BaseBuilder, NSMAP, QTI_SCHEMA_LOCATION, XSI_NS

LOGGER = logging.getLogger(__name__)


class StimulusBuilder(BaseBuilder):
    """Generates a standalone QTI 3.0 assessment stimulus XML document."""

    def build(
        self,
        stimulus: Union[Stimulus, list[Stimulus], None],
        identifier: str,
    ) -> str | None:
        if stimulus is None:
            return None
        self._reset_build_state(identifier)

        root = etree.Element(
            "qti-assessment-stimulus",
            nsmap=NSMAP,
            attrib={
                f"{{{XSI_NS}}}schemaLocation": QTI_SCHEMA_LOCATION,
                "identifier": identifier,
                "title": f"Stimulus {identifier}",
            },
        )

        stim_body = etree.SubElement(root, "qti-stimulus-body")
        wrapper = etree.SubElement(stim_body, "div")
        wrapper.set("class", "tb-stimulus-container")

        if isinstance(stimulus, list):
            self._render_list(wrapper, stimulus)
        else:
            self._render_single(wrapper, stimulus)

        return self.serialize(root)

    def _render_single(
        self, parent: etree._Element, stimulus: Stimulus,
    ) -> None:
        container_class = (
            "tb-image-stimulus-container"
            if isinstance(stimulus, ImageStimulus)
            else "tb-text-stimulus-container"
        )
        div = etree.SubElement(parent, "div")
        div.set("class", container_class)

        if isinstance(stimulus, TextStimulus):
            content_html = self._process_content(stimulus.text)
            self._set_inner_html(div, content_html)

        elif isinstance(stimulus, ImageStimulus):
            img_html = self._build_image_tag(stimulus)
            self._set_inner_html(div, img_html)
            if stimulus.credit:
                credit = etree.SubElement(div, "p")
                credit.set("class", "credit")
                credit.text = stimulus.credit

        elif isinstance(stimulus, AudioStimulus):
            audio = etree.SubElement(div, "audio")
            audio.set("src", stimulus.url)
            audio.set("controls", "controls")

        elif isinstance(stimulus, VideoStimulus):
            video = etree.SubElement(div, "video")
            video.set("src", stimulus.url)
            video.set("controls", "controls")

    def _render_list(
        self, parent: etree._Element, stimuli: list[Stimulus],
    ) -> None:
        """Render multiple stimuli with document-based wrappers for 2+ items."""
        if len(stimuli) <= 1:
            for stim in stimuli:
                self._render_single(parent, stim)
            return

        titles = [getattr(stim, "title", None) for stim in stimuli]
        titled_count = sum(1 for title in titles if title)
        if 0 < titled_count < len(stimuli):
            LOGGER.warning(
                "Mixed titled and untitled multi-stimulus list detected for item '%s'. "
                "Auto-generating missing titles.",
                self._current_item_id,
            )

        resolved_titles = [
            title if title else f"Document {idx + 1}"
            for idx, title in enumerate(titles)
        ]

        header = etree.SubElement(
            parent,
            "p",
            attrib={"class": "tb-document-based-stimulus-title"},
        )
        header.text = "Source Documents"

        container = etree.SubElement(
            parent,
            "div",
            attrib={"class": "tb-document-based-stimulus-container"},
        )
        for stim, title in zip(stimuli, resolved_titles):
            item_div = etree.SubElement(
                container,
                "div",
                attrib={"class": "tb-document-stimulus-item"},
            )
            details = etree.SubElement(
                item_div,
                "details",
                attrib={"class": "tb-document-stimulus-item-details"},
            )
            summary = etree.SubElement(
                details,
                "summary",
                attrib={"class": "tb-document-stimulus-item-summary"},
            )
            summary.text = title
            content_div = etree.SubElement(
                details,
                "div",
                attrib={"class": "tb-document-stimulus-item-content"},
            )
            self._render_single(content_div, stim)
