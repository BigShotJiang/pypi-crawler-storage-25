"""Shared types and building blocks used across all models.

Contains semantic type aliases, stimulus types, companion materials,
accessibility catalog entries, learning content, worked example content,
feedback entity types, scoring dimensions, context variables, and
template config.
"""

from __future__ import annotations

from enum import Enum
from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field, model_validator

# ---------------------------------------------------------------------------
# Semantic type aliases
# ---------------------------------------------------------------------------

MarkdownStr = Annotated[
    str,
    Field(
        description=(
            "Rich text string. Supports Markdown formatting and LaTeX math "
            "($...$ for inline, $$...$$ for block). You can also embed raw "
            "HTML tags when needed, such as <audio>, <video>, and <figure>. "
            "Use markdown image syntax ![alt](url) for inline images. "
            "For media tags with boolean attributes, prefer XML-safe forms "
            "like controls=\"controls\"."
        ),
    ),
]
"""A string that may contain Markdown, LaTeX, and optional raw HTML.

Accepts pure Markdown, Markdown with embedded HTML, or pure HTML.
"""

BlankTemplateStr = Annotated[
    str,
    Field(
        description=(
            "Question text with blank placeholders where the student types an answer. "
            "Supports Markdown and LaTeX ($...$ for inline, $$...$$ for block). "
            "Single-blank: include exactly one <blank> placeholder. "
            "Multi-blank: use <blank-1>, <blank-2>, etc. — keys must match the answers dict."
        ),
        json_schema_extra={
            "examples": [
                "The chemical symbol for water is <blank>.",
                "The <blank-1> of the cell is the <blank-2>.",
            ],
        },
    ),
]
"""A string containing ``<blank>`` or ``<blank-N>`` placeholders for text entry interactions."""


# ---------------------------------------------------------------------------
# Accessibility catalog support types
# ---------------------------------------------------------------------------


class CatalogSupport(str, Enum):
    """QTI accessibility catalog support types.

    Each value corresponds to a ``<qti-access-element>`` support type
    in the QTI 3.0 accessibility catalog.  Attach one or more entries
    to a ``QuestionItem`` via ``accessibility_catalog`` to provide
    alternate representations for assistive technologies.
    """

    SPOKEN = "spoken"
    GLOSSARY_ON_SCREEN = "glossary-on-screen"
    SIGN_LANGUAGE = "sign-language"
    LONG_DESCRIPTION = "long-description"
    SIMPLIFIED_LANGUAGE = "simplified-language-portions"
    SIMPLIFIED_GRAPHICS = "simplified-graphics"
    KEYWORD_TRANSLATION = "keyword-translation"
    BRAILLE = "braille"
    TACTILE = "tactile"
    TRANSCRIPT = "transcript"
    AUDIO_DESCRIPTION = "audio-description"
    HIGH_CONTRAST = "high-contrast"
    ADDITIONAL_DIRECTIONS = "additional-directions"
    KEYBOARD_DIRECTIONS = "keyboard-directions"
    LINGUISTIC_GUIDANCE = "linguistic-guidance"


class AccessibilityCatalogEntry(BaseModel):
    """A single accessibility support binding for a QTI element.

    Associates a :class:`CatalogSupport` type with the element it targets
    (by ``target_path``) and the support content (HTML, SSML, or a URL).
    """

    target_path: str = Field(
        description=(
            "Model path to the element this support targets. "
            "Examples: 'question', 'interactions[0].prompt', "
            "'interactions[0].choices[A]', 'interactions[0].label'."
        ),
    )
    support: CatalogSupport = Field(description="Type of accessibility support.")
    content: str = Field(
        description="Support content — HTML, SSML, or URL depending on the support type.",
    )


# ---------------------------------------------------------------------------
# Stimulus types
# ---------------------------------------------------------------------------


class TextStimulus(BaseModel):
    """Rich-text stimulus passage rendered alongside the item.

    Use for reading passages, problem context, data tables, or any
    Markdown/LaTeX content the student reads before answering.
    In multi-stimulus sets, titled entries are treated as document-style
    sources by renderer conventions.
    """

    type: Literal["text"] = "text"
    text: MarkdownStr
    title: str | None = Field(
        default=None,
        description=(
            "Document title for multi-stimulus sets. When multiple stimuli "
            "have titles, the renderer presents them as navigable collapsible "
            "documents (for example, DBQ sources). Titles are auto-generated "
            "for untitled items in multi-stimulus lists. "
            'Example: "Document A: The Federalist No. 10".'
        ),
    )


class ImageStimulus(BaseModel):
    """Image stimulus rendered alongside the item.

    The image can be a local relative path (bundled into the QTI package)
    or an external URL.
    """

    type: Literal["image"] = "image"
    url: str = Field(description="URL or relative path to the image file.")
    alt: str | None = Field(default=None, description="Alt text for accessibility.")
    credit: str | None = Field(default=None, description="Image attribution / credit line.")
    title: str | None = None


class AudioStimulus(BaseModel):
    """Audio stimulus rendered alongside the item (e.g. a listening passage)."""

    type: Literal["audio"] = "audio"
    url: str = Field(description="URL or relative path to the audio file.")
    title: str | None = None


class VideoStimulus(BaseModel):
    """Video stimulus rendered alongside the item (e.g. a lecture clip)."""

    type: Literal["video"] = "video"
    url: str = Field(description="URL or relative path to the video file.")
    title: str | None = None


Stimulus = Annotated[
    Union[TextStimulus, ImageStimulus, AudioStimulus, VideoStimulus],
    Field(discriminator="type"),
]
"""Discriminated union of all stimulus types, selected by ``type``."""


# ---------------------------------------------------------------------------
# Companion Materials
# ---------------------------------------------------------------------------


class CompanionMaterials(BaseModel):
    """Tools available to the student during the item (calculator, ruler, etc.).

    Maps to ``<qti-companion-materials-info>`` in the generated XML.
    """

    calculator: Literal["basic", "standard", "scientific"] | None = Field(
        default=None, description="Calculator type available during the item.",
    )
    ruler: bool = Field(default=False, description="Whether a ruler tool is available.")
    protractor: bool = Field(default=False, description="Whether a protractor tool is available.")


# ---------------------------------------------------------------------------
# Learning Content (used in Feedback entries with type="learning_content")
# ---------------------------------------------------------------------------


class TextLearningContent(BaseModel):
    """Text-based remediation content for a ``Feedback`` entry.

    Used as ``Feedback.content`` when structured instructional text is needed
    instead of a plain Markdown string.
    """

    type: Literal["text"] = "text"
    text: MarkdownStr


class VideoLearningContent(BaseModel):
    """Video-based remediation content for a ``Feedback`` entry.

    Used as ``Feedback.content`` when video-based remediation is needed.
    """

    type: Literal["video"] = "video"
    url: str = Field(description="URL of the learning video.")


LearningContent = Annotated[
    Union[TextLearningContent, VideoLearningContent],
    Field(discriminator="type"),
]
"""Discriminated union of remediation content types, selected by ``type``."""


# ---------------------------------------------------------------------------
# Worked Example Content (renderer extension for solution_steps)
# ---------------------------------------------------------------------------


class WorkedExampleStep(BaseModel):
    """A single step in a worked-example reveal sequence.

    ``summary`` is always visible; ``details`` is revealed on click.
    The renderer shows a progressive unlock UI — the last step with
    details stays locked until all preceding steps have been viewed.
    """

    summary: MarkdownStr = Field(
        description="Always-visible step description. Must not be empty.",
    )
    details: MarkdownStr | None = Field(
        default=None,
        description=(
            "Content revealed when the student clicks the step. "
            "If None, the step is text-only with no expand/collapse."
        ),
    )


class WorkedExampleContent(BaseModel):
    """Structured worked-example content for the renderer's step-by-step
    reveal extension.

    When used as ``Feedback.content`` with ``type="solution_steps"``, the
    SDK emits the renderer's ``tb-*`` class structure with
    ``WORKED_EXAMPLE_FEEDBACK`` / ``worked_example_feedback`` identifiers
    instead of the plain ``WORKED_SOLUTION_FEEDBACK`` path.

    **TimeBack retrieval caveat**: interactive step-by-step reveal
    (expand/collapse with progressive unlock) requires the **original**
    version to be retrieved from TimeBack.  If the **cleaned** version is
    retrieved, the ``tb-*`` structure is preserved as plain HTML but
    without interactive styling or progressive reveal — it degrades to a
    static ordered list.
    """

    type: Literal["worked_example"] = "worked_example"
    title: str = Field(
        default="Solution Steps",
        description="Heading shown above the step list.",
    )
    steps: list[WorkedExampleStep] = Field(
        min_length=1,
        description="Ordered list of solution steps (at least 1 required).",
    )

    @model_validator(mode="after")
    def _validate_step_summaries(self) -> WorkedExampleContent:
        for i, step in enumerate(self.steps):
            if not step.summary or not step.summary.strip():
                from ..exceptions import ValidationError

                raise ValidationError(
                    f"WorkedExampleContent step {i} has an empty summary. "
                    "Every step must have a non-empty summary."
                )
        return self


FeedbackContent = Annotated[
    Union[TextLearningContent, VideoLearningContent, WorkedExampleContent],
    Field(discriminator="type"),
]
"""Discriminated union of all structured feedback content types."""


# ---------------------------------------------------------------------------
# Feedback — first-class entity
# ---------------------------------------------------------------------------


class MatchResponse(BaseModel):
    """Condition: match against the response variable resolved from structural
    placement of the feedback.  The SDK maps ``interaction`` to the correct
    QTI response variable name (``RESPONSE``, ``RESPONSE_1``, etc.)."""

    type: Literal["response"] = "response"
    value: str = Field(description="Expected response value to match against.")
    interaction: int | None = Field(
        default=None,
        description=(
            "0-based index into QuestionItem.interactions[]. "
            "None means 'this interaction' (the one the feedback is attached to)."
        ),
    )


class MatchTemplateVar(BaseModel):
    """Condition: match against a generator-declared template variable
    (from ``TemplateConfig.variables``)."""

    type: Literal["template"] = "template"
    variable: str = Field(description="Template variable name (must exist in TemplateConfig).")
    value: str = Field(description="Expected value to match against.")


ConditionMatch = Annotated[
    Union[MatchResponse, MatchTemplateVar],
    Field(discriminator="type"),
]
"""Discriminated union of condition matchers for ``ShowCondition.match``."""


class ShowCondition(BaseModel):
    """Declares when a feedback entry should be revealed.

    Convenience fields (``after_attempt``, ``on_correct``) abstract away
    SDK-owned variable names.  The ``match`` list provides extensible
    typed matchers for generator-owned variables.  All conditions within
    a single ``ShowCondition`` are AND-ed.
    """

    after_attempt: int | None = Field(
        default=None,
        description="Show after N submissions (SDK maps to numAttempts >= N).",
    )
    on_correct: bool | None = Field(
        default=None,
        description="True = show on correct; False = show on incorrect.",
    )
    match: list[ConditionMatch] = Field(
        default_factory=list,
        description="Typed matchers AND-ed together. For OR, use separate Feedback entries.",
    )


class Feedback(BaseModel):
    """A single piece of feedback content attached to a choice, interaction,
    or item.  The SDK infers the QTI mechanism (inline / block / modal) from
    structural placement."""

    type: Literal[
        "explanation",
        "hint",
        "solution_steps",
        "learning_content",
        "answer_reveal",
    ] = Field(description="Feedback category; drives default show conditions and presentation.")
    content: MarkdownStr | FeedbackContent = Field(
        description=(
            "Feedback body — plain string for text/markdown, "
            "LearningContent for video/text remediation, or "
            "WorkedExampleContent for interactive step-by-step reveal."
        ),
    )
    show_when: ShowCondition | None = Field(
        default=None,
        description="Per-feedback condition override. None = use defaults from FeedbackPolicy.",
    )

    @model_validator(mode="after")
    def _validate_content_type_compat(self) -> Feedback:
        from ..exceptions import ValidationError

        content = self.content
        fb_type = self.type

        if isinstance(content, WorkedExampleContent) and fb_type != "solution_steps":
            raise ValidationError(
                f"WorkedExampleContent can only be used with "
                f'type="solution_steps", got type="{fb_type}".'
            )
        if isinstance(content, (TextLearningContent, VideoLearningContent)):
            if fb_type == "solution_steps":
                raise ValidationError(
                    f"LearningContent ({type(content).__name__}) cannot be "
                    f'used with type="solution_steps". Use a plain string '
                    f"or WorkedExampleContent instead."
                )
        return self


class FeedbackPolicy(BaseModel):
    """Default ``ShowCondition`` per feedback type.  Attached to
    ``FeedbackEnabled`` behavior; individual ``Feedback`` entries can
    override via their own ``show_when``."""

    completion_after: int = Field(
        default=5,
        ge=1,
        description=(
            "Completion ceiling for adaptive items. The SDK sets "
            "completionStatus='completed' after this many attempts even if "
            "the learner has not reached MAXSCORE."
        ),
    )
    explanation: ShowCondition = Field(default_factory=ShowCondition)
    hint: ShowCondition = Field(
        default_factory=lambda: ShowCondition(after_attempt=1),
    )
    solution_steps: ShowCondition = Field(
        default_factory=lambda: ShowCondition(after_attempt=3),
    )
    learning_content: ShowCondition = Field(
        default_factory=lambda: ShowCondition(on_correct=False),
    )
    answer_reveal: ShowCondition = Field(
        default_factory=lambda: ShowCondition(after_attempt=4),
    )


# ---------------------------------------------------------------------------
# Scoring Dimensions
# ---------------------------------------------------------------------------


class ScoringDimension(BaseModel):
    """A named scoring dimension for multi-dimensional rubric scoring."""

    name: str = Field(description='Dimension name, e.g. "Thesis", "Evidence".')
    max_score: float
    scoring_method: Literal["human", "machine"] = "human"


# ---------------------------------------------------------------------------
# Context Variables (advanced escape hatch)
# ---------------------------------------------------------------------------


class ContextVariable(BaseModel):
    """Maps to ``<qti-context-declaration>``.  Advanced feature for PCI
    config injection and context-aware scoring."""

    identifier: str
    cardinality: Literal["single", "multiple", "ordered", "record"]
    base_type: str | None = Field(
        default=None,
        description='"identifier", "string", "integer", "float", etc.',
    )
    default_value: str | None = None


# ---------------------------------------------------------------------------
# Template Config
# ---------------------------------------------------------------------------


class TemplateVariable(BaseModel):
    """A single template variable declaration."""

    name: str = Field(description="Maps to identifier in qti-template-declaration.")
    type: Literal["integer", "float"] = "integer"
    min: int | float = Field(description="Minimum value (inclusive).")
    max: int | float = Field(description="Maximum value (inclusive).")
    step: int | float = 1
    default: int | float | None = Field(
        default=None, description="Maps to qti-default-value.",
    )
    display_format: str | None = Field(
        default=None,
        description='C-style format, e.g. "%0.2f".  Applied to all <qti-printed-variable> refs.',
    )


class TemplateConfig(BaseModel):
    """Item-level template variable declarations and processing config."""

    variables: list[TemplateVariable] = Field(min_length=1)
    constraints: list[str] | None = Field(
        default=None,
        description='Constraint expressions, e.g. ["a != b", "a + b <= 20"].',
    )
    answer_type: Literal["integer", "float"] = "integer"
    tolerance: float | None = Field(
        default=None,
        description="Absolute tolerance (tolerance-mode='absolute').",
    )
    computed_values: dict[str, str] | None = Field(
        default=None,
        description='Extra template vars computed from others, e.g. {"product": "a * b"}.',
    )

    @model_validator(mode="after")
    def _validate_computed_values(self) -> TemplateConfig:
        """Check that computed_values expressions parse and reference known variables."""
        if not self.computed_values:
            return self

        from ..exceptions import ValidationError
        from ..templates.expression_parser import parse_arithmetic

        var_names = {v.name for v in self.variables}
        all_names = var_names | set(self.computed_values.keys())

        for name, expr_str in self.computed_values.items():
            try:
                parse_arithmetic(expr_str, all_names)
            except Exception as exc:
                raise ValidationError(
                    f"computed_values['{name}']: {exc}"
                ) from exc
        return self


# ---------------------------------------------------------------------------
# Packaging Metadata (manifest-only, not in item XML)
# ---------------------------------------------------------------------------


class StandardAlignment(BaseModel):
    """Alignment to a curriculum standard."""

    label: str = Field(
        description='Human-readable standard label, e.g. "CCSS.MATH.CONTENT.8.G.B.7".',
    )
    case_item_uri: str | None = Field(
        default=None,
        description="CASE UUID for this standard. If provided, skips resolution at upload time.",
    )


class ItemPackaging(BaseModel):
    """Per-item metadata consumed only at packaging time.

    Does not affect generated item XML.  Carried through ``BuildResult``
    and emitted in ``imsmanifest.xml`` by ``PackageBuilder``.
    """

    document: str | None = Field(
        default=None,
        description=(
            "CASE CFDocument title to match at upload time (case-insensitive exact match). "
            "Required when curriculum_standards contains unresolved labels. "
            "The SDK lists documents from TimeBack and resolves this to a document id."
        ),
    )
    course: str | None = Field(
        default=None,
        description=(
            "Curriculum course title under that document (case-insensitive exact match). "
            "Required when curriculum_standards contains unresolved labels. "
            "The SDK lists courses for the matched document and resolves this to a course id."
        ),
    )
    difficulty: float = Field(ge=0.0, le=1.0, description="Item difficulty (0.0 = easy, 1.0 = hard).")
    curriculum_standards: list[StandardAlignment] | None = Field(
        default=None,
        description="Curriculum standards this item aligns to.",
    )
    timeback_metadata: dict[str, str] | None = Field(
        default=None,
        description="Freeform key-value metadata stored as TimeBack extended attributes.",
    )
