"""Score maps, Score Expression DSL, and API-based scoring config.

Score maps provide weighted per-option scoring (``qti-mapping``).
The Score Expression DSL provides a typed, serializable expression tree
that compiles 1:1 to QTI expression elements.
API-based scoring configures external grading via ``qti-custom-operator``.
"""

from __future__ import annotations

from typing import Annotated, Literal, Union

from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------------
# Score maps (per interaction type)
# ---------------------------------------------------------------------------


class ChoiceScoreMap(BaseModel):
    """Weighted per-choice scoring.  Maps choice IDs to point values."""

    entries: dict[str, float] = Field(
        description="Mapping of choice_id -> score value.",
    )
    default_value: float = 0.0
    lower_bound: float | None = None
    upper_bound: float | None = None


class TextEntryScoreMap(BaseModel):
    """Weighted per-response-string scoring for text entry."""

    entries: dict[str, float] = Field(
        description="Mapping of response_string -> score value.",
    )
    default_value: float = 0.0
    case_sensitive: bool = Field(
        default=False,
        description="Inherits from interaction if not set.",
    )


class MatchScoreEntry(BaseModel):
    """A single source-target pair with its score."""

    source: str = Field(description="Source item id.")
    target: str = Field(description="Target item id.")
    score: float


class MatchScoreMap(BaseModel):
    """Weighted per-pair scoring for match interactions."""

    entries: list[MatchScoreEntry] = Field(
        description="Structured source-target score pairs.",
    )
    default_value: float = 0.0
    lower_bound: float | None = None
    upper_bound: float | None = None


# ---------------------------------------------------------------------------
# Score Expression DSL
# ---------------------------------------------------------------------------


class MapResponseExpr(BaseModel):
    """References a RESPONSE variable's mapping (``qti-map-response``)."""

    type: Literal["map_response"] = "map_response"
    identifier: str = Field(description="References a RESPONSE variable's mapping.")


class VariableExpr(BaseModel):
    """References any variable (``qti-variable``)."""

    type: Literal["variable"] = "variable"
    identifier: str


class BaseValueExpr(BaseModel):
    """A literal numeric value (``qti-base-value``)."""

    type: Literal["base_value"] = "base_value"
    base_type: Literal["float", "integer"]
    value: str


class SumExpr(BaseModel):
    """Sum of operands (``qti-sum``)."""

    type: Literal["sum"] = "sum"
    operands: list[ScoreExpression]


class SubtractExpr(BaseModel):
    """Difference of operands (``qti-subtract``)."""

    type: Literal["subtract"] = "subtract"
    operands: list[ScoreExpression]


class ProductExpr(BaseModel):
    """Product of operands (``qti-product``)."""

    type: Literal["product"] = "product"
    operands: list[ScoreExpression]


class DivideExpr(BaseModel):
    """Division of operands (``qti-divide``).  Always produces float."""

    type: Literal["divide"] = "divide"
    operands: list[ScoreExpression]


class IntegerDivideExpr(BaseModel):
    """Integer division of operands (``qti-integer-divide``).  Always produces integer."""

    type: Literal["integer_divide"] = "integer_divide"
    operands: list[ScoreExpression]


class IntegerModulusExpr(BaseModel):
    """Modulus of operands (``qti-integer-modulus``).  Always produces integer."""

    type: Literal["integer_modulus"] = "integer_modulus"
    operands: list[ScoreExpression]


ScoreExpression = Annotated[
    Union[
        MapResponseExpr,
        VariableExpr,
        BaseValueExpr,
        SumExpr,
        SubtractExpr,
        ProductExpr,
        DivideExpr,
        IntegerDivideExpr,
        IntegerModulusExpr,
    ],
    Field(discriminator="type"),
]
"""Typed expression tree that compiles 1:1 to QTI expression elements."""

# Pydantic v2 needs model_rebuild for forward-ref resolution on recursive types.
SumExpr.model_rebuild()
SubtractExpr.model_rebuild()
ProductExpr.model_rebuild()
DivideExpr.model_rebuild()
IntegerDivideExpr.model_rebuild()
IntegerModulusExpr.model_rebuild()


# ---------------------------------------------------------------------------
# API-based scoring (external grading via qti-custom-operator)
# ---------------------------------------------------------------------------

_API_SCORING_RESERVED = frozenset(
    {
        "SCORE",
        "MAXSCORE",
        "PASSED",
        "GENERATED_FEEDBACK",
        "GENERATED_FEEDBACK_VISIBILITY",
        "COMMENT",
        "GRADING_RESPONSE",
        "completionStatus",
        "FEEDBACK",
        "MODAL_FEEDBACK",
    }
)


class ApiScoringExtraField(BaseModel):
    """An additional field to extract from the grading API response
    into a custom QTI outcome variable."""

    api_field: str = Field(
        description=(
            "Key in the grading API's JSON response to extract. "
            'Example: "rubric_analysis", "confidence"'
        ),
    )
    outcome_identifier: str = Field(
        description=(
            "QTI outcome variable to store the extracted value in. "
            "Must not collide with built-in identifiers "
            "(SCORE, MAXSCORE, PASSED, GENERATED_FEEDBACK, etc.)."
        ),
    )
    base_type: Literal["float", "integer", "string", "boolean", "identifier"] = Field(
        default="string",
        description="Data type of the extracted value.",
    )

    @model_validator(mode="after")
    def _check_not_reserved(self) -> ApiScoringExtraField:
        if self.outcome_identifier in _API_SCORING_RESERVED:
            from ..exceptions import ValidationError

            raise ValidationError(
                f"ApiScoringExtraField outcome_identifier "
                f"'{self.outcome_identifier}' collides with a reserved "
                f"SDK identifier"
            )
        return self


class ApiScoringConfig(BaseModel):
    """Configure external API-based scoring.

    The renderer POSTs the student's responses to the endpoint URL.
    The API returns a JSON object with scoring results. The SDK
    automatically extracts the standard fields into built-in QTI
    outcome variables::

        API response key    ->  QTI outcome variable
        scoreGiven          ->  SCORE
        scoreMaximum        ->  MAXSCORE
        htmlComment         ->  GENERATED_FEEDBACK  (shown to student)
        comment             ->  COMMENT             (stored, not shown)

    Use ``extra_fields`` to extract additional API response keys into
    custom outcome variables.
    """

    endpoint: str = Field(
        description="URL the renderer will POST to for grading.",
    )
    mastery_value: float | None = Field(
        default=None,
        description=(
            "Passing threshold. When set, a PASSED outcome is computed: "
            "score >= mastery_value means pass, otherwise fail. "
            "Also used for completionStatus in adaptive items "
            "(score >= mastery_value marks the item completed). "
            "If omitted, no pass/fail — just a numeric score."
        ),
    )
    extra_fields: list[ApiScoringExtraField] | None = Field(
        default=None,
        description=(
            "Additional fields to extract from the API response beyond "
            "the standard set (scoreGiven, scoreMaximum, htmlComment, "
            "comment). Each entry creates a new outcome variable and "
            "an extraction rule."
        ),
    )
