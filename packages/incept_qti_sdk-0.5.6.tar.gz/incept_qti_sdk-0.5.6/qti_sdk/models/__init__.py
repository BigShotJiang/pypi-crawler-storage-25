"""QTI SDK model exports — unified QuestionItem architecture."""

# --- Base types ---
from .base import (
    AccessibilityCatalogEntry,
    AudioStimulus,
    BlankTemplateStr,
    CatalogSupport,
    CompanionMaterials,
    ConditionMatch,
    ContextVariable,
    Feedback,
    FeedbackContent,
    FeedbackPolicy,
    ImageStimulus,
    ItemPackaging,
    LearningContent,
    MarkdownStr,
    MatchResponse,
    MatchTemplateVar,
    ScoringDimension,
    ShowCondition,
    StandardAlignment,
    Stimulus,
    TemplateConfig,
    TemplateVariable,
    TextLearningContent,
    TextStimulus,
    VideoLearningContent,
    VideoStimulus,
    WorkedExampleContent,
    WorkedExampleStep,
)

# --- Behavior types ---
from .behaviors import (
    AssessmentBehavior,
    ExternalGraded,
    FeedbackEnabled,
    SummativeBehavior,
)

# --- Scoring types ---
from .scoring import (
    ApiScoringConfig,
    ApiScoringExtraField,
    BaseValueExpr,
    ChoiceScoreMap,
    DivideExpr,
    MapResponseExpr,
    MatchScoreEntry,
    MatchScoreMap,
    ProductExpr,
    ScoreExpression,
    SubtractExpr,
    SumExpr,
    TextEntryScoreMap,
    VariableExpr,
)

# --- Interaction types ---
from .interactions import (
    PCI_MODULE_REGISTRY,
    Choice,
    ChoiceConfig,
    ExtendedTextConfig,
    Interaction,
    MatchConfig,
    MatchItem,
    MediaConfig,
    MediaSource,
    MediaTrack,
    OrderConfig,
    OrderItem,
    PCIConfig,
    PCITemplateMapping,
    TextEntryConfig,
)

# --- QuestionItem ---
from .question_item import QuestionItem
