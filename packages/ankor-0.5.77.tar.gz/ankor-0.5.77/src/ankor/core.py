from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from fastapi import Request
from fastapi.responses import JSONResponse, Response
from .types import NodeFn, WorkflowFn

if TYPE_CHECKING:
    from fastapi import FastAPI

STATIC_DIR = Path(__file__).parent / "static"


async def _recover_from_restart(session, wrappers: dict) -> None:
    """Cancel orphaned running runs from before the restart, then kick off pending ones.

    Running runs left in the DB from a crashed/stopped server are no longer
    being executed — mark them cancelled so they don't stay stuck forever.
    Pending runs are re-queued by starting the drain loop for each affected workflow.
    """
    from datetime import datetime, timezone

    from sqlmodel import select

    from .decorator import _ensure_drain_task, _notify_drain
    from .models import Workflow, WorkflowRun, WorkflowStatus

    now = datetime.now(timezone.utc)

    orphaned = list(
        (
            await session.exec(
                select(WorkflowRun).where(WorkflowRun.status == WorkflowStatus.running)
            )
        ).all()
    )

    for run in orphaned:
        run.status = WorkflowStatus.cancelled
        run.finished_at = now
        session.add(run)

    if orphaned:
        await session.commit()

    pending_wf_names = list(
        (
            await session.exec(
                select(Workflow.name)
                .join(WorkflowRun, WorkflowRun.workflow_id == Workflow.id)
                .where(WorkflowRun.status == WorkflowStatus.pending)
                .distinct()
            )
        ).all()
    )

    for wf_name in pending_wf_names:
        if wf_name in wrappers:
            raw_fn = getattr(wrappers[wf_name], "_gtm_fn", wrappers[wf_name])
            _ensure_drain_task(wf_name, raw_fn)
            _notify_drain(wf_name)


class ankor:
    def __init__(
        self,
        app: "FastAPI",
        db_url: str,
        secret: str,
        dev: bool = False,
        auto_seed: bool = False,
        tables: list[dict] | None = None,
    ) -> None:
        from .auth import configure
        from .database import setup_engine

        configure(secret)
        setup_engine(db_url)
        self._tables_schema = tables or []

        from .config_store import ConfigStore
        from .db_store import DbStore

        self.config = ConfigStore()
        """Programmatic access to the Config store (``await gtm.config.get(key)``)."""
        self.db = DbStore()
        """Programmatic access to the lightweight DB tables (``await gtm.db.rows(table)``)."""

        self._workflows: dict = {}
        self._wrappers: dict = {}  # name -> wrapped fn (for re-run dispatch)
        self._cron_workflows: list[dict] = []  # [{fn, cron, interval, name}]
        self._webhook_workflows: dict[str, Any] = {}  # name -> fn
        self._workflow_meta: dict[str, dict] = (
            {}
        )  # name -> {trigger_type, cron, interval, is_webhook}
        self._app = app

        async def _startup() -> None:
            from .auth import generate_webhook_token
            from .database import _SessionLocal, run_migrations
            from .db_store import _ensure_tables
            from .models import Workflow, WebhookToken

            await run_migrations()

            if self._tables_schema:
                await _ensure_tables(self._tables_schema)

            if _SessionLocal is not None:
                from sqlmodel import select

                async with _SessionLocal() as _s:
                    if not await _s.get(WebhookToken, "default"):
                        _s.add(WebhookToken(token=generate_webhook_token()))
                        await _s.commit()

                    # Upsert a workflows row for every registered workflow so that
                    # workflow_runs can reference it via workflow_id.
                    for wf_name in self._workflow_meta:
                        existing = (
                            await _s.exec(
                                select(Workflow).where(Workflow.name == wf_name)
                            )
                        ).first()
                        if existing is None:
                            meta = self._workflow_meta[wf_name]
                            _s.add(
                                Workflow(
                                    name=wf_name,
                                    max_concurrent_runs=meta.get("max_concurrent_runs"),
                                )
                            )
                    await _s.commit()

                    await _recover_from_restart(_s, self._wrappers)

            if auto_seed:
                from .seed import seed_demo_data

                await seed_demo_data()

            self._start_scheduler()

        app.router.on_startup.append(_startup)
        self._register_router(app, secret)
        self._mount_dashboard(app, dev)

    def _start_scheduler(self) -> None:
        if not self._cron_workflows:
            return

        try:
            from apscheduler.schedulers.asyncio import AsyncIOScheduler
            from apscheduler.triggers.cron import CronTrigger
            from apscheduler.triggers.interval import IntervalTrigger
        except ImportError as exc:
            raise ImportError(
                "APScheduler is required for cron/interval workflows. "
                "Install it with: pip install apscheduler"
            ) from exc

        scheduler = AsyncIOScheduler()

        for entry in self._cron_workflows:
            fn = entry["fn"]
            name = entry["name"]
            cron_expr = entry.get("cron")
            interval_seconds = entry.get("interval")

            if interval_seconds is not None:
                trigger = IntervalTrigger(seconds=interval_seconds)
            elif cron_expr:
                fields = cron_expr.split()
                if len(fields) != 5:
                    raise ValueError(
                        f"Cron expression for '{name}' must have 5 fields "
                        f"(minute hour day month day_of_week), got: {cron_expr!r}"
                    )
                minute, hour, day, month, day_of_week = fields
                trigger = CronTrigger(
                    minute=minute,
                    hour=hour,
                    day=day,
                    month=month,
                    day_of_week=day_of_week,
                )
            else:
                continue

            async def _cron_job(
                _fn=fn, _name=name, _cron=cron_expr, _interval=interval_seconds
            ):
                from .database import _SessionLocal
                from .models import Workflow
                from .trigger_context import TriggerContext

                if _SessionLocal is not None:
                    async with _SessionLocal() as _s:
                        from sqlmodel import select

                        _cfg = (
                            await _s.exec(
                                select(Workflow).where(Workflow.name == _name)
                            )
                        ).first()
                        if _cfg is not None and not _cfg.enabled:
                            return
                schedule = _cron if _cron else f"interval:{_interval}s"
                ctx = TriggerContext("cron", {}, {"schedule": schedule})
                await _fn({}, _ctx=ctx)

            scheduler.add_job(_cron_job, trigger=trigger, id=f"cron_{name}")

        scheduler.start()

    def _register_router(self, app: "FastAPI", secret: str) -> None:
        from .routers import create_router
        from .trigger_context import TriggerContext

        async def _invoke(name: str, ctx: TriggerContext) -> None:
            wrapper = self._wrappers.get(name)
            if wrapper is None:
                raise KeyError(name)
            asyncio.create_task(wrapper(ctx.inputs, _ctx=ctx))

        router = create_router(
            workflow_meta=self._workflow_meta, invoke=_invoke, wrappers=self._wrappers
        )
        app.include_router(router, prefix="/api")

    def _mount_dashboard(self, app: "FastAPI", dev: bool) -> None:
        if dev:
            self._mount_dev_proxy(app)
        elif STATIC_DIR.exists():
            from fastapi.responses import FileResponse

            @app.get("/admin/{path:path}", include_in_schema=False)
            async def _serve_dashboard(path: str) -> FileResponse:
                candidate = STATIC_DIR / path
                if candidate.is_file():
                    return FileResponse(candidate)
                return FileResponse(STATIC_DIR / "index.html")

    def _mount_dev_proxy(self, app: "FastAPI") -> None:
        import httpx
        from fastapi import Request
        from fastapi.responses import StreamingResponse

        @app.api_route("/admin/{path:path}", methods=["GET"])
        async def _proxy(path: str, request: Request) -> StreamingResponse:
            async with httpx.AsyncClient() as client:
                url = f"http://localhost:5173/admin/{path}"
                resp = await client.get(url, headers=dict(request.headers))
                return StreamingResponse(
                    content=iter([resp.content]),
                    status_code=resp.status_code,
                    media_type=resp.headers.get("content-type"),
                )

    def workflow(
        self,
        fn=None,
        *,
        cron: str | None = None,
        interval: int | None = None,
        webhook: bool = False,
        background=False,
        input_schema: list[dict] | None = None,
        instructions: str | None = None,
        max_concurrent_runs: int | None = None,
    ) -> WorkflowFn | Callable[[Any], WorkflowFn]:
        """Decorator that registers a workflow function.

        Usage:
            @gtm.workflow
            async def my_workflow(inputs): ...

            @gtm.workflow(cron="0 9 * * 1-5")
            async def daily_workflow(inputs): ...

            @gtm.workflow(interval=10)   # every 10 seconds
            async def frequent_workflow(inputs): ...

            @gtm.workflow(webhook=True)
            async def webhook_workflow(inputs): ...

            @gtm.workflow(
                input_schema=[
                    {"key": "limit", "type": "number", "label": "Limit", "default": 10},
                    {"key": "dry_run", "type": "boolean", "label": "Dry run", "default": False},
                ],
                instructions="Fetches contacts and enriches each one.",
            )
            async def my_workflow(inputs): ...
        """

        def _decorate(func):
            from .decorator import make_workflow_wrapper

            wrapper = make_workflow_wrapper(func)
            self._workflows[func.__name__] = func
            self._wrappers[func.__name__] = wrapper

            trigger_type = "manual"
            if cron:
                trigger_type = "cron"
            elif interval is not None:
                trigger_type = "interval"
            elif webhook:
                trigger_type = "webhook"

            self._workflow_meta[func.__name__] = {
                "trigger_type": trigger_type,
                "cron": cron,
                "interval": interval,
                "is_webhook": webhook,
                "webhook_path": f"/api/webhooks/{func.__name__}" if webhook else None,
                "input_schema": input_schema or [],
                "instructions": instructions,
                "max_concurrent_runs": max_concurrent_runs,
            }

            if cron or interval is not None:
                self._cron_workflows.append(
                    {
                        "fn": wrapper,
                        "cron": cron,
                        "interval": interval,
                        "name": func.__name__,
                    }
                )

            if webhook:
                self._register_webhook(func.__name__, wrapper, background=background)

            return wrapper

        if fn is not None:
            return _decorate(fn)

        return _decorate

    def _register_webhook(self, name: str, wrapper, background=False) -> None:
        """Mount POST /api/webhooks/{name} that calls the workflow.

        Sync mode (default, ``background=False``):
            The HTTP connection stays open until the function finishes.
            The function's return value drives the response:
            - ``None``     → ``200 {"status": "success"}``
            - ``dict``     → ``200`` with that dict as the JSON body
            - ``Response`` → passed through as-is (full control over status/headers)

        Background mode (``background=True | dict | Response``):
            Responds immediately; the workflow runs as an asyncio task.
            - ``True``       → ``202 {"status": "accepted"}``
            - ``dict``       → ``202`` with that dict as the JSON body
            - ``Response``   → exactly that response
            The function's return value is ignored.
        """
        app = self._app
        path = f"/api/webhooks/{name}"

        async def _auth_ok(request: Request) -> bool:
            from .auth import verify_webhook_token
            from .database import _SessionLocal
            from .models import WebhookToken

            auth = request.headers.get("Authorization", "")
            if not auth.startswith("Bearer "):
                return False
            provided = auth[7:]
            if _SessionLocal is None:
                return False
            async with _SessionLocal() as _s:
                wt = await _s.get(WebhookToken, "default")
            return wt is not None and verify_webhook_token(provided, wt.token)

        if background is not False:
            # Resolve the immediate response once at decoration time.
            if isinstance(background, Response):
                _imm = background
            elif isinstance(background, dict):
                _imm = JSONResponse(content=background, status_code=202)
            else:  # True
                _imm = JSONResponse(content={"status": "accepted"}, status_code=202)

            @app.post(path, tags=["webhooks"])
            async def _webhook_handler_bg(request: Request) -> Response:
                if not await _auth_ok(request):
                    return JSONResponse(
                        status_code=401, content={"error": "Unauthorized"}
                    )
                from .database import _SessionLocal
                from .models import WorkflowConfig
                from .trigger_context import TriggerContext, _safe_headers

                if _SessionLocal is not None:
                    from sqlmodel import select as _select

                    async with _SessionLocal() as _s:
                        _cfg = (
                            await _s.exec(
                                _select(WorkflowConfig).where(
                                    WorkflowConfig.name == name
                                )
                            )
                        ).first()
                        if _cfg is not None and not _cfg.enabled:
                            return JSONResponse(
                                status_code=503,
                                content={"error": "Workflow is disabled"},
                            )
                try:
                    body = await request.json()
                except Exception:
                    body = {}
                inputs = {"body": body, "headers": _safe_headers(request.headers)}
                ctx = TriggerContext("webhook", inputs)

                async def _run() -> None:
                    try:
                        await wrapper(inputs, _ctx=ctx)
                    except Exception:
                        pass  # already recorded in DB by make_workflow_wrapper

                asyncio.create_task(_run())
                return _imm

        else:

            @app.post(path, tags=["webhooks"])
            async def _webhook_handler(request: Request) -> Response:
                if not await _auth_ok(request):
                    return JSONResponse(
                        status_code=401, content={"error": "Unauthorized"}
                    )
                from .database import _SessionLocal
                from .models import WorkflowConfig
                from .trigger_context import TriggerContext, _safe_headers

                if _SessionLocal is not None:
                    from sqlmodel import select as _select

                    async with _SessionLocal() as _s:
                        _cfg = (
                            await _s.exec(
                                _select(WorkflowConfig).where(
                                    WorkflowConfig.name == name
                                )
                            )
                        ).first()
                        if _cfg is not None and not _cfg.enabled:
                            return JSONResponse(
                                status_code=503,
                                content={"error": "Workflow is disabled"},
                            )
                try:
                    body = await request.json()
                except Exception:
                    body = {}
                inputs = {"body": body, "headers": _safe_headers(request.headers)}
                ctx = TriggerContext("webhook", inputs)
                try:
                    result = await wrapper(inputs, _ctx=ctx)
                except Exception as exc:
                    return JSONResponse(status_code=500, content={"error": str(exc)})
                if isinstance(result, Response):
                    return result
                if isinstance(result, dict):
                    return JSONResponse(content=result)
                return JSONResponse(content={"status": "success"})

        self._webhook_workflows[name] = wrapper

    def log(self, message: str, *, type: str = "info", json: bool = False) -> None:
        """Append a structured log entry to the currently executing node's log buffer.

        Call from inside a ``@gtm.node`` function.  If called outside a node
        the message is silently dropped.

        Args:
            message: The log message text.
            type:    ``"info"`` (default), ``"warning"``, or ``"error"``.
            json:    Set to ``True`` when *message* is a JSON string.
        """
        from .decorator import log as _log

        _log(message, type=type, json=json)

    def plan(self, *names: str) -> None:
        """Declare the ordered list of nodes this workflow intends to run.

        Any nodes in the plan that do not complete (due to an earlier failure)
        will be recorded with ``pending`` status in the dashboard.

        Call once at the top of a ``@gtm.workflow`` function body.
        """
        from .decorator import plan as _plan

        _plan(*names)

    def node(self, fn=None) -> NodeFn | Callable[[Any], NodeFn]:
        """Decorator that wraps a function as a tracked workflow node.

        Each call is recorded as an individual step in the active workflow run,
        with its own inputs, outputs, timing, and logs.  When called outside a
        workflow the function executes transparently with no tracking overhead.

        Usage:
            @gtm.node
            async def my_step(inputs: dict) -> dict: ...
        """

        def _decorate(func):
            from .decorator import make_node_wrapper

            return make_node_wrapper(func)

        if fn is not None:
            return _decorate(fn)

        return _decorate
