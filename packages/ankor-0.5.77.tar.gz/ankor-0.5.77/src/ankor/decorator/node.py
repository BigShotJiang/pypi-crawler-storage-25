from __future__ import annotations

import asyncio
import dataclasses
import functools
import traceback
from datetime import datetime, timezone
from typing import Callable

from ._context import _active_node_logs, _active_node_slot, _active_run_ctx
from ._persistence import _persist_run_snapshot, _schedule_snapshot
from ._serialization import _json_safe, _serialize_action
from ..types import NodeFn


@dataclasses.dataclass
class DbActionRecord:
    inputs: dict
    outputs: dict
    duration_ms: int


def log(message: str, *, type: str = "info", json: bool = False) -> None:
    """Append a structured log entry to the active log buffer.

    When inside a node, writes to the node's log buffer. When inside a workflow
    but outside any node, writes to the run's top-level logs. Silently dropped
    when called outside a workflow.
    """
    entry = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "body": str(message),
        "type": type,
        "json": json,
    }
    node_buf = _active_node_logs.get()
    if node_buf is not None:
        node_buf.append(entry)
        return
    run_ctx = _active_run_ctx.get()
    if run_ctx is not None:
        run_ctx["logs"].append(entry)


def plan(*names: str) -> None:
    """Declare the ordered list of nodes this workflow intends to run.

    Any planned-but-not-executed names are recorded as ``status="pending"``
    when the run finishes. Call once at the top of a workflow body.
    """
    ctx = _active_run_ctx.get()
    if ctx is not None:
        ctx["plan"] = list(names)


def record_db_action(op: str, table: str, record: DbActionRecord) -> None:
    """Record a data-table operation as a child action of the current context.

    Called automatically by DbStore methods. No-op outside a workflow run.
    """
    ctx = _active_run_ctx.get()
    if ctx is None:
        return
    parent_slot = _active_node_slot.get()
    parent_list = parent_slot["children"] if parent_slot is not None else ctx["actions"]
    ctx["_action_counter"] += 1
    parent_list.append(
        {
            "id": ctx["_action_counter"],
            "name": f"{op}: {table}",
            "type": "db",
            "status": "success",
            "inputs": _json_safe(record.inputs),
            "outputs": _json_safe(record.outputs),
            "duration_ms": record.duration_ms,
            "children": [],
        }
    )
    run_id = ctx.get("run_id")
    run_meta = ctx.get("_run_meta")
    if run_id is not None and run_meta is not None:
        from ..broadcast import manager

        try:
            loop = asyncio.get_running_loop()
            loop.create_task(
                manager.broadcast(
                    f"workflow_detail:{run_id}",
                    {
                        "type": "run_updated",
                        "data": {
                            **run_meta,
                            "status": "running",
                            "actions": [_serialize_action(a) for a in ctx["actions"]],
                        },
                    },
                )
            )
        except RuntimeError:
            pass
        _schedule_snapshot(run_id, ctx)


def make_node_wrapper(fn) -> NodeFn:
    @functools.wraps(fn)
    async def wrapper(inputs: dict, *, slug: str | None = None):
        ctx = _active_run_ctx.get()
        if ctx is None:
            return await fn(inputs)

        from ..broadcast import manager

        node_start = datetime.now(timezone.utc)
        node_logs: list[dict] = []
        logs_token = _active_node_logs.set(node_logs)

        parent_slot = _active_node_slot.get()
        parent_list = (
            parent_slot["children"] if parent_slot is not None else ctx["actions"]
        )
        ctx["_action_counter"] += 1
        slot: dict = {
            "id": ctx["_action_counter"],
            "name": fn.__name__,
            "slug": slug,
            "type": "node",
            "status": "running",
            "inputs": inputs,
            "outputs": {},
            "duration_ms": 0,
            "logs": None,
            "children": [],
        }
        parent_list.append(slot)
        slot_token = _active_node_slot.set(slot)

        run_id = ctx.get("run_id")
        run_meta = ctx.get("_run_meta")

        def _broadcast_payload() -> dict:
            return {
                "type": "run_updated",
                "data": {
                    **run_meta,
                    "status": "running",
                    "actions": [_serialize_action(a) for a in ctx["actions"]],
                },
            }

        if run_id is not None and run_meta is not None:
            await manager.broadcast(f"workflow_detail:{run_id}", _broadcast_payload())
            await _persist_run_snapshot(run_id, ctx)

        try:
            result = await fn(inputs)
            duration_ms = int(
                (datetime.now(timezone.utc) - node_start).total_seconds() * 1000
            )
            slot.update(
                {
                    "status": "success",
                    "outputs": result if isinstance(result, dict) else {},
                    "duration_ms": duration_ms,
                    "logs": node_logs if node_logs else None,
                }
            )
            return result
        except Exception:
            duration_ms = int(
                (datetime.now(timezone.utc) - node_start).total_seconds() * 1000
            )
            slot.update(
                {
                    "status": "failed",
                    "duration_ms": duration_ms,
                    "logs": [
                        *node_logs,
                        {
                            "timestamp": datetime.now(timezone.utc).isoformat(),
                            "body": traceback.format_exc(),
                            "type": "error",
                            "json": False,
                        },
                    ],
                }
            )
            raise
        finally:
            _active_node_logs.reset(logs_token)
            _active_node_slot.reset(slot_token)
            if run_id is not None and run_meta is not None:
                await manager.broadcast(
                    f"workflow_detail:{run_id}", _broadcast_payload()
                )
                await _persist_run_snapshot(run_id, ctx)

    wrapper._gtm_fn = fn
    return wrapper
