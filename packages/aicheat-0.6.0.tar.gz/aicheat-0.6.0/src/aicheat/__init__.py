try:
    from ._version import __version__, __version_tuple__  # noqa: F401
except ImportError:
    import warnings

    warnings.warn("Couldn't get version from _version.py", stacklevel=2)
    __version__ = "0.0.0"


def _monkeypatch_rich_codeblock_padding() -> None:
    """Monkeypatch rich.markdown to remove padding and newlines around code blocks."""
    import inspect
    import textwrap
    import warnings
    import rich.markdown
    from rich.syntax import Syntax
    from rich.console import Console, ConsoleOptions, RenderResult

    # 1. Remove internal padding from CodeBlock
    def __rich_console__(
        self: rich.markdown.CodeBlock, console: Console, options: ConsoleOptions
    ) -> RenderResult:
        code = str(self.text).strip()
        yield Syntax(code, self.lexer_name, theme=self.theme, word_wrap=True, padding=0)

    rich.markdown.CodeBlock.__rich_console__ = __rich_console__
    rich.markdown.CodeBlock.new_line = False

    # 2. Patch Markdown.__rich_console__ to skip newlines before code blocks
    PATCHES = [
        (
            "                    if new_line:\n                        yield _new_line_segment",
            '                    if new_line and node_type not in ("fence", "code_block"):\n                        yield _new_line_segment',
        ),
        (
            '                    if new_line and node_type != "inline":\n                        yield _new_line_segment',
            '                    if new_line and node_type not in ("inline", "fence", "code_block"):\n                        yield _new_line_segment',
        ),
    ]

    try:
        orig_source = textwrap.dedent(
            inspect.getsource(rich.markdown.Markdown.__rich_console__)
        )
        patched_source = orig_source

        for old, new in PATCHES:
            if old not in patched_source:
                raise ValueError(f"Patch pattern not found: {repr(old[:50])}...")
            patched_source = patched_source.replace(old, new)

        patched_source = patched_source.replace(
            "def __rich_console__(", "def _patched_rich_console("
        )

        exec(patched_source, rich.markdown.__dict__)
        rich.markdown.Markdown.__rich_console__ = rich.markdown.__dict__[
            "_patched_rich_console"
        ]
    except Exception as e:
        warnings.warn(
            f"Failed to patch rich.markdown.Markdown.__rich_console__: {e}. "
            "Code blocks may have extra spacing.",
            stacklevel=2,
        )


_monkeypatch_rich_codeblock_padding()
