"""Completion utilities shared across commands"""

from __future__ import annotations

import os
from functools import cache
from typing import Iterable

from prompt_toolkit.completion import (
    Completion,
    WordCompleter,
    NestedCompleter,
)
from prompt_toolkit.document import Document

from .logger import getLogger

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from prompt_toolkit.completion import CompleteEvent


logger = getLogger(__name__)


def completion_filter_invisible_files(path: str) -> bool:
    """Filter out hidden files (starting with .)"""
    name = path.rsplit(os.sep, maxsplit=1)[-1]
    logger.trace(f"{path=}")  # type: ignore # trace level defined in .logger
    return not name.startswith(".")


class LazyCommandsMetaDict:
    """Lazy way to get docstrings for commands after they've been registered in commands.handlers"""

    @cache
    def get(self, key: str, default: str) -> str:
        from .commands import registry

        try:
            cls, _ = registry[key.lstrip("/")]
        except KeyError:
            return default

        return cls.__doc__.split("\n", maxsplit=1)[0] if cls.__doc__ else ""


class CommandPrefixCompleter(NestedCompleter):
    """Completer for command prefixes with support for nested completers"""

    def get_completions(
        self, document: Document, complete_event: CompleteEvent
    ) -> Iterable[Completion]:
        # Split document.
        text = document.text_before_cursor.lstrip()
        stripped_len = len(document.text_before_cursor) - len(text)

        # If there is a space, check for the first term, and use a
        # subcompleter.
        if " " in text:
            first_term = text.split()[0]
            completer = self.options.get(first_term)

            # If we have a sub completer, use this for the completions.
            if completer is not None:
                remaining_text = text[len(first_term) :].lstrip()
                move_cursor = len(text) - len(remaining_text) + stripped_len

                new_document = Document(
                    remaining_text,
                    cursor_position=document.cursor_position - move_cursor,
                )

                yield from completer.get_completions(new_document, complete_event)

        # No space in the input: behave exactly like `WordCompleter`.
        elif text.startswith("/"):
            completer = WordCompleter(
                [key for key in self.options.keys() if key.startswith("/")],
                ignore_case=self.ignore_case,
                sentence=True,  # sentence must be set to true since the command prefix "/" counts as a word boundary
                meta_dict=LazyCommandsMetaDict(),  # type: ignore
            )
            yield from completer.get_completions(document, complete_event)
        else:
            completer = WordCompleter(
                list(self.options.keys()), ignore_case=self.ignore_case, sentence=True
            )
            yield from completer.get_completions(document, complete_event)
