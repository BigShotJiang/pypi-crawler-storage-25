"""Keybindings command - shows available keybindings"""

from prompt_toolkit.completion import WordCompleter

from aicheat.commands.core import CommandBase


class KeybindingsCommand(CommandBase):
    """Show available keybindings"""

    name = "keybindings"
    completer = WordCompleter([])

    def execute(self, arg: str = "") -> None:
        keybindings = [
            ("Ctrl-C (twice)", "Clear conversation and reset"),
            ("Ctrl-V", "Enter multiline mode"),
            ("Ctrl-D", "Exit aicheat"),
            ("Ctrl-J", "Submit line (in multiline mode)"),
            ("Ctrl-T", "Toggle token usage display (no → percentage → verbose)"),
            ("Ctrl-X Ctrl-E", "Open current message in $EDITOR (emacs mode)"),
            ("Shift-tab", "Toggle YOLO mode status"),
            ("vv", "Open current message in $EDITOR (vi mode)"),
            ("Escape Enter", "Ignore (in multiline mode)"),
        ]

        lines = ["**Available Keybindings:**", ""]

        max_key_width = max(len(kb[0]) for kb in keybindings)

        for key, description in keybindings:
            lines.append(f"- `{key:<{max_key_width}}` │ {description}")

        lines.append("")
        lines.append(
            "*Note: Keybindings may vary depending on your terminal and $EDITOR settings.*"
        )

        self.markdown("\n".join(lines))
