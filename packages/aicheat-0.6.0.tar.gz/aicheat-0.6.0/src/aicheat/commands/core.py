"""Command core module - base classes, registry"""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from pathlib import Path
from textwrap import dedent
from typing import TYPE_CHECKING, Any, Callable

from prompt_toolkit.completion import Completer
import json

from aicheat.utils import choice

if TYPE_CHECKING:
    from aicheat.chat import Conversation

    from rich.status import Status

logger = logging.getLogger(__name__)


# maps command name to a command instance.
registry: dict[str, tuple[type[CommandBase], CommandBase | None]] = {}


class CommandBase(ABC):
    """base class for Conversation commands

    Override this docstring to include a description/help text for the command
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """command name"""

    prefix: str = "/"
    completer: Completer | None = None
    rule: Callable | None = None

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(
            **kwargs,
        )

        if isinstance(cls.name, property):
            logger.debug(
                "Not registering class %s into the command registry: no name is defined"
            )
            return

        # Automatically register commands into the registry here
        registry[cls.name] = (cls, None)
        logger.info(
            "Registered command: %s%s",
            cls.prefix,
            cls.name,
        )

    def __init__(self, conversation: Conversation):
        self.conversation = conversation

    @property
    def console(self):
        return self.conversation.console

    @property
    def logger(self):
        return logging.getLogger(f"commands.{self.name}")

    def parse_args(self, prompt: str) -> str:
        return prompt.removeprefix(f"{self.prefix}{self.name}").strip()

    def split_args(self, args: str, maxsplit: int = -1) -> list[str]:
        return args.split() if maxsplit == -1 else args.split(maxsplit=maxsplit)

    def require_args(self, args: str, error_msg: str = "Arguments required") -> None:
        if not args:
            self.error(error_msg)
            raise ValueError(error_msg)

    def info(self, message: str, **kwargs: Any) -> None:
        self.conversation.console.print(message, style="info", **kwargs)

    def error(self, message: str, **kwargs: Any) -> None:
        self.conversation.console.print(message, style="error", **kwargs)

    def system(self, message: str, **kwargs: Any) -> None:
        self.conversation.console.print(message, style="system", **kwargs)

    def markdown(self, content: str, **kwargs: Any) -> None:
        self.conversation._print_markdown(content, **kwargs)

    def json_output(self, data: Any, **kwargs: Any) -> None:
        self.conversation.console.print_json(json.dumps(data), **kwargs)

    def status(self, message: str) -> Status:
        return self.conversation.console.status(message)

    def resolve_path(self, path_str: str, expand: bool = True) -> Path:
        path = Path(path_str)
        if expand:
            path = path.expanduser()
        return path.resolve()

    def validate_path_exists(self, path: Path, error_msg: str | None = None) -> bool:
        if not path.exists():
            self.error(error_msg or f"Path does not exist: {path}")
            return False
        return True

    def validate_is_directory(self, path: Path, error_msg: str | None = None) -> bool:
        if not path.is_dir():
            self.error(error_msg or f"Not a directory: {path}")
            return False
        return True

    def confirm(self, message: str, default: str = "n") -> str:
        return choice(message, choices=("y", "n"), default=default)

    def dedent(self, text: str) -> str:
        return dedent(text)

    # FIXME: execute and __call__ are redundant
    @abstractmethod
    def execute(self, args: str) -> str | None:
        """execute action corresponding to the command"""

    def __call__(self, prompt: str) -> str | None:
        args = self.parse_args(prompt)
        try:
            return self.execute(args)
        except ValueError as e:
            self.error(str(e))
            return None
        except Exception as e:
            self.error(f"Command failed: {e}")
            logger.exception("Command execution failed")
            return None


class CommandWithSubcommandsBase(CommandBase):
    """Base class for commands that have subcommands

    Just like CommandBase, this requires setting the name attribute at instantiation.
    """

    # mapps subcommand name to method names
    SUBCOMMANDS: dict[str, str]

    def execute(self, args: str) -> str | None:
        # Parse action and remaining args
        parts = args.split()
        action = parts[0] if parts else ""
        remaining = " ".join(parts[1:]) if len(parts) > 1 else ""

        if not action:
            return self.execute_default()

        if action.lower() not in self.SUBCOMMANDS:
            self.error(f"Unknown subcommand: {action}")
            self.show_usage()
            return None

        method_name = self.SUBCOMMANDS[action.lower()]
        method = getattr(self, method_name)  # type: ignore
        if method is None or not callable(method):
            self.error(f"Invalid subcommand handler: {action}")
            return None

        return method(remaining)

    @abstractmethod
    def execute_default(self) -> str | None:
        """default action when no"""

    def show_usage(self) -> None:
        """show usage for this command"""
        assert self.__doc__
        self.markdown("**Usage:**\n" + self.__doc__)


def get_prefixes() -> set[str]:
    return {cmd.prefix for cmd, _ in registry.values()}


def get_all_commands() -> dict[str, type[CommandBase]]:
    return {name: cmd_cls for name, (cmd_cls, _) in registry.items()}


def match_command(
    prompt: str,
) -> tuple[
    type[CommandBase] | None,
    CommandBase | None,
]:
    for cmd_name, (cls, cmd) in registry.items():
        if prompt.startswith(f"{cls.prefix}{cls.name}"):
            return cls, cmd

        if cls.rule and callable(cls.rule) and cls.rule(prompt):
            return cls, cmd

    return None, None
