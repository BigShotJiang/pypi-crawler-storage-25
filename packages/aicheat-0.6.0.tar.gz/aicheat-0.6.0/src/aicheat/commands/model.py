"""Model command - shows current model or lists available models"""

from aicheat.commands.core import CommandBase
from aicheat.model_utils import get_model_max_context
from rich.text import Text


class ModelCommand(CommandBase):
    """Show the selected model or list available models (`/models`)"""

    name = "model"

    def execute(self, arg: str) -> None:
        if not arg:
            assert self.conversation.model

            self.markdown(
                f"💡 Current model: `{self.conversation.model.id}` "
                f"(ctx={get_model_max_context(self.conversation.model) or 'unknown'})"
            )
        elif arg == "s":  # /models
            models_formatted = (
                f"- [code]{model.id}[/code] "
                f"(ctx={get_model_max_context(model) or 'unknown'})"
                for model in self.conversation.available_models
            )
            self.console.print(
                Text("Available models:\n", style="system"),
                "\n".join(models_formatted),
            )
        else:
            raise ValueError(f"Invalid argument: {arg}")
