"""Commands related to memory"""

import datetime
import textwrap
from pathlib import Path

import yaml
from prompt_toolkit.completion.filesystem import PathCompleter

from aicheat.commands.core import CommandBase
from aicheat.completions import completion_filter_invisible_files
from aicheat.prompts import save_command_prompt
from aicheat.utils import choice, parse_frontmatter


class LoadCommand(CommandBase):
    """Load and display a saved session summary.

    Usage:
       - /load  [memory_file.md] - Load `memory.md` (or `memory_file.md`)
    """

    name = "load"
    completer = PathCompleter(
        file_filter=lambda file: (
            file.endswith(".md") and completion_filter_invisible_files(file)
        ),
    )

    def execute(self, filename: str = "") -> str | None:
        path = Path(filename or "memory.md")
        if not path.exists():
            self.markdown(f"File `{path}` does not exist.", style="error")
            return None

        memory = path.read_text()

        frontmatter, memory = parse_frontmatter(memory)

        skills = []
        if "skills" in frontmatter:
            skills = [Path(skill["path"]) for skill in frontmatter["skills"]]

        for path in skills:
            if not path.exists():
                self.system(f"# Warning: Saved skill path does not exist: {path}")

        if loaded_skills := self.conversation.skill_manager.load(skills):
            self.markdown(
                "Loaded skill(s) from memory file: "
                + ", ".join(skill.name for skill in loaded_skills)
            )
        elif skills:
            self.system(
                "# Warning: Couldn't load skills referenced in memory file: "
                + ", ".join(skill.name for skill in skills),
                style="system",
            )

        return (
            textwrap.dedent(
                """
                # User loaded a memory from a previous conversation:

                ```markdown
                {memory}
                ```
                """
            )
            .format(memory=memory)
            .strip()
        )


class SaveCommand(CommandBase):
    """Summarize the current session to a markdown. Usage: /save or /save <filename>"""

    name = "save"

    def execute(self, filename: str = "") -> None:
        messages = [
            {
                "role": "system",
                "content": save_command_prompt,
            },
            *[message for message in self.conversation.messages[1:]],
        ]

        with self.conversation.console.status("Generating session summary..."):
            try:
                response = self.conversation.client.chat.completions.create(
                    messages=messages,
                    model=self.conversation.model.id,
                    stream=False,
                    tools=None,
                )
            except KeyboardInterrupt:
                self.markdown("Interrupted", style="error")
                return
            except Exception as exc:
                self.logger.exception("Unexpected error during summarization")
                self.markdown(
                    f"Unexpected error during summarization: {exc}",
                    style="error",
                )
                return

        summary_md = response.choices[0].message.content

        if not summary_md:
            self.markdown("Failed to generate a summary.", style="error")
            return

        skill_info = []
        for skill_path, skill in self.conversation.skill_manager.items():
            skill_info.append(
                {
                    "path": skill_path.resolve().as_posix(),
                    "name": skill.name,
                    "description": skill.description,
                }
            )

        timestamp = datetime.datetime.now().isoformat(timespec="minutes")
        frontmatter = {
            "timestamp": timestamp,
            "model": self.conversation.model.id,
            "skills": skill_info,
        }

        formatted_memory = (
            self.dedent(
                """
                ---
                {frontmatter}
                ---
                {summary_section}
                """
            )
            .strip()
            .format(
                frontmatter=yaml.dump(frontmatter).strip(),
                summary_section=summary_md.strip(),
            )
        )

        default = "memory.md"
        memory = Path(filename or default)

        if (
            memory.exists()
            and choice(f"{memory.name} exists, overwrite?", default="n") == "n"
        ):
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            memory = memory.with_stem(f"{memory.stem}_{timestamp}")

        with memory.open("w") as f:
            f.write(formatted_memory)

        self.markdown(f"Session saved to `{memory.name}`")
