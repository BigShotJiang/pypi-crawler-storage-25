"""Fragment command - insert content from file or URL"""

import re
from pathlib import Path

from prompt_toolkit.completion.filesystem import PathCompleter

from aicheat.commands.core import CommandBase
from aicheat.completions import completion_filter_invisible_files


class FragmentCommand(CommandBase):
    """Inserts a fragment into the context, reading it from a file or url"""

    name = "fragment"
    completer = PathCompleter(
        file_filter=completion_filter_invisible_files,
    )

    def execute(self, fragment: str) -> str | None:
        res = fragment.split(" ", maxsplit=1)
        path_or_url, extra = res[0], (None if (len(res) == 1 or not res[1]) else res[1])
        if not path_or_url:
            self.error("No path or url provided")
            return None

        if re.match("https?://", path_or_url):
            return self.conversation._handle_url_fragment(path_or_url, extra)

        path = Path(path_or_url).expanduser()

        if not path.exists():
            self.error(f"File does not exist: {path}")
            return None

        return self.conversation._handle_file_fragment(path, extra)
