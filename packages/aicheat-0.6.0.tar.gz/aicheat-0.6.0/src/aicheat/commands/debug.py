"""Debug command - toggles debugging mode"""

from aicheat.commands.core import CommandBase


class DebugCommand(CommandBase):
    """Toggles debugging"""

    name = "debug"

    def execute(self, args: str) -> None:
        self.conversation._debug = not self.conversation._debug
        self.system(
            "# debug is now "
            + ("enabled." if self.conversation._debug else "disabled.")
        )
        return None
