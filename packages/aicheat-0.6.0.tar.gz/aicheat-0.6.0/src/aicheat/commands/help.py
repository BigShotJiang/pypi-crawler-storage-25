"""Help command - shows available commands"""

import textwrap

from prompt_toolkit.completion import WordCompleter

from aicheat.commands import registry
from aicheat.commands.core import CommandBase


class HelpCommandCompleter(WordCompleter):
    """Lazy completer for the help command that suggests command names"""

    def __init__(self):
        self.ignore_case = True
        self.meta_dict = None

    def get_completions(self, document, complete_event):
        command_names = list(registry.keys())
        meta_dict = {
            name: (
                registry[name][0].__doc__.split("\n")[0]
                if registry[name][0].__doc__
                else ""
            )
            for name in command_names
        }

        completer = WordCompleter(
            words=command_names,
            ignore_case=self.ignore_case,
            meta_dict=meta_dict,
        )
        yield from completer.get_completions(document, complete_event)


class HelpCommand(CommandBase):
    """Show help"""

    name = "help"
    completer = HelpCommandCompleter()

    def execute(self, name: str | None) -> None:
        if name:
            self._show_command_help(name)
            return

        self._show_all_commands()

    def _show_command_help(self, name: str) -> None:
        if name not in registry.keys():
            self.error(f"No such command: {name}")
            return

        cls, _ = registry[name]
        doc = cls.__doc__

        if not doc:
            self.system(f"No help for {name}")
            return

        self.markdown(
            "\n".join(
                (f"# Help for {name}", *doc.splitlines()),
            ),
        )

    def _show_all_commands(self) -> None:
        max_command_width = (
            max(len(cls.prefix + cls.name) for (cls, _) in registry.values()) + 2
        )
        max_help_width = max(
            (len(cls.__doc__.splitlines()[0]) if cls.__doc__ else 0)
            for (cls, _) in registry.values()
        )

        commands_help = []
        for cls, cmd in registry.values():
            cmd_str = f"`{cls.prefix}{cls.name}`"
            formatted_command = f"- {cmd_str:<{max_command_width}}"

            doc = cls.__doc__
            help_lines = doc.splitlines() if doc else []
            doc_line, doc_detail = help_lines[0] if help_lines else "", help_lines[1:]

            formatted_doc_detail = textwrap.indent("\n".join(doc_detail), prefix="\t\t")
            formatted_command_description = f"{doc_line:<{max_help_width}}" + (
                ("\n" + formatted_doc_detail) if doc_detail else ""
            )

            commands_help.append(
                f"{formatted_command} │ {formatted_command_description}"
            )

        self.markdown(
            "\n".join(("# Available commands", *commands_help)),
        )
