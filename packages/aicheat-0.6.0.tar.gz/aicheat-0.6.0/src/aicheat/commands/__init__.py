"""Commands package"""

from .core import (
    CommandBase,
    CommandWithSubcommandsBase,
    get_all_commands,
    get_prefixes,
    match_command,
    registry,
)

from aicheat.utils import _init_submodules

__all__ = [
    "CommandBase",
    "CommandWithSubcommandsBase",
    "registry",
    "get_command",
    "get_all_commands",
    "get_prefixes",
    "match_command",
    *_init_submodules(__file__),
]
