"""Skills commands - manage skills"""

from pathlib import Path

from prompt_toolkit.completion import NestedCompleter, PathCompleter, WordCompleter

from aicheat.commands.core import CommandWithSubcommandsBase
from aicheat.skills import manager as skill_manager
from ..utils import safe_relative_to
import os


def completion_filter_invisible_files(path: str) -> bool:
    """Filter out hidden files (starting with .)"""
    name = path.rsplit(os.sep, maxsplit=1)[-1]
    return not name.startswith(".")


def get_skills_completer():
    """Get completer for skills load/unload commands"""

    def get_loaded_skill_paths() -> list[str]:
        return [safe_relative_to(path).as_posix() for path in skill_manager]

    return NestedCompleter.from_nested_dict(
        {
            "load": PathCompleter(file_filter=completion_filter_invisible_files),
            "unload": WordCompleter(words=get_loaded_skill_paths),
        }
    )


class SkillCommand(CommandWithSubcommandsBase):
    """Lists or loads/unloads skills. Usage: /skill [load path/to/skill.md | unload skill_name].

    Call with no arguments to get a list of loaded skills"""

    name = "skill"
    SUBCOMMANDS = {
        "load": "_load_skills",
        "unload": "_unload_skills",
    }
    completer = get_skills_completer()

    def execute_default(self) -> None:
        skills = self.conversation.skill_manager.values()
        if not skills:
            self.system("# No loaded skills.")
        else:
            header = "# Loaded skills\n"
            self.markdown(
                header
                + "\n".join(
                    f" - `{skill.name}`"
                    + (f" - {skill.description}" if skill.description else "")
                    for skill in skills
                )
            )

    def _load_skills(self, args: str) -> None:
        paths = list(map(Path, args.split()))
        if not args:
            self.error("No paths provided")
            return

        loaded_skills = self.conversation.skill_manager.load(paths)
        if not loaded_skills:
            self.error("No skills could be loaded.")
            return

        loaded_formatted = []
        for path in paths:
            try:
                formatted = path.relative_to(path.cwd())
            except ValueError:
                formatted = path
            loaded_formatted.append(formatted)

        if not loaded_formatted:
            self.error(
                f"Couldn't load skill{'s' if len(paths) > 1 else ''}.",
            )
            return

        header = f"**Loaded skills from** `{', '.join(path.as_posix() for path in loaded_formatted)}`: "
        self.markdown(header + ", ".join(skill.name for skill in loaded_skills))

    def _unload_skills(self, args: str) -> None:
        skills = set(args.split())
        if not skills:
            self.conversation.skill_manager.unload_all()
            self.system("# Unloaded all skills")
            return

        unloaded_skills = [
            self.conversation.skill_manager.unload(skill_name) for skill_name in skills
        ]
        assert all(unloaded_skills)

        not_found = skills - {skill.path.as_posix() for skill in unloaded_skills}

        if not_found:
            self.system(
                f"# No such skill{'s' if len(not_found) > 1 else ''}: {', '.join(not_found)}",
            )

        for unloaded_skill in unloaded_skills:
            assert unloaded_skill
            skill_path = safe_relative_to(unloaded_skill.path)

            self.markdown(
                f"**Unloaded skill:** `{unloaded_skill.name}` (`{skill_path}`)",
                style="system",
            )


class SkillsCommand(SkillCommand):
    """Alias for /skill"""

    name = "skills"
