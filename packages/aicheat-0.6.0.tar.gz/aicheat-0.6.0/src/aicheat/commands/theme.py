"""Theme command - show/select pygments themes"""

import textwrap

from prompt_toolkit.completion import WordCompleter
from pygments.styles import get_all_styles

from aicheat.commands.core import CommandBase
from aicheat.utils import choice


class ThemeCommand(CommandBase):  # FIXME: refactor suing CommandWithSubcommandsBase?
    """Show or select theme (pygments themes)"""

    name = "theme"

    completer = WordCompleter(
        ["list", *get_all_styles()],
        meta_dict={"list": "Select theme interactively."},
    )

    def execute(self, theme: str | None) -> None:
        if not theme:
            self.console.print("[system]Current theme:[/system] ", end="")
            self.markdown(
                f"`{self.conversation.theme}`. Use `/theme list` to list available themes.",
                end="",
            )
            return

        theme = theme.strip()

        theme_sample_template = textwrap.dedent(
            """
            # Theme: {style}

            This is an `hello_world.py`:
            ```python
            def hello_world():
                print("hello world!")
            ```
            """
        )

        all_styles = list(get_all_styles())
        if theme == "list":
            self.console.print("Available themes:")
            num_styles = len(all_styles)
            selected_theme = None
            for index, style in enumerate(all_styles):
                self.markdown(
                    theme_sample_template.format(style=style),
                    markdown_kwargs={"code_theme": style},
                )
                answer = choice(
                    f"Select {style}? y to set as new theme, e to exit ({index + 1}/{num_styles})",
                    choices=("y", "n", "e"),
                    default="n",
                )
                if answer == "y":
                    selected_theme = style
                    break

                if answer == "e":
                    return

            if not selected_theme:
                return
        else:
            selected_theme = theme

        if selected_theme not in all_styles:
            self.console.print(
                f'Style "{selected_theme}" is not available, use "/theme list" to list available themes'
            )
            return

        self.conversation.set_theme(selected_theme)
        self.system(f"# Set theme: {selected_theme}.")
        self.system(
            "# Use `/config save` to persist changes across sessions.",
        )
