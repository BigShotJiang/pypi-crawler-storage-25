"""Config command - shows/saves configuration"""

from pathlib import Path

from prompt_toolkit.completion import NestedCompleter

from aicheat.commands.core import CommandBase
from aicheat.utils import safe_relative_to


def _create_config_completer():
    """Create completer for config command"""
    completer = NestedCompleter.from_nested_dict(
        {
            "save": None,
            "show_tokens": {
                "no": None,
                "percentage": None,
                "verbose": None,
            },
        }
    )
    completer.meta_dict = {
        "save": "Save the current tools configuration",
        "show_tokens": "Configure token usage display",
        "show_tokens no": "Don't show token usage",
        "show_tokens percentage": "Show percentage of context used",
        "show_tokens verbose": "Show completion tokens, total tokens, and percentage",
    }
    return completer


class ConfigCommand(CommandBase):
    """Shows the current configuration

    Subcommands:
        save - Save the current configuration to disk
        show_tokens <mode> - Configure token usage display
            Modes:
                no - Don't show token usage (default)
                percentage - Show total tokens and percentage
                verbose - Show completion/total/max tokens and percentage
    """

    name = "config"
    completer = _create_config_completer()

    def execute(self, arg: str = "") -> None:
        from aicheat.config import config, TokenUsageConfig

        lines = ["**Current Configuration:**"]

        lines.extend(
            [
                f"- configuration file: `~/{safe_relative_to(config.config_file, Path.home())}`",
                f"- logfile: `~/{config.logfile.relative_to(Path.home())}`",
                f"- current chat prompt history: `~/{safe_relative_to(config.chat_history_path, Path.home())}`",
                f"- active model: `{self.conversation.model.id}`",
                f"- show reasoning: `{self.conversation.get_show_reasoning()}`",
                f"- reasoning effort: `{self.conversation.get_reasoning_effort()}`",
                f"- token usage display: `{config.token_usage.show_tokens if config.token_usage else 'no'}`",
            ]
        )

        if arg == "save":
            lines.append("")
            lines.append("Saved current configuration.")

            config.save(self.conversation)
        elif arg.startswith("show_tokens"):
            # Parse the mode from the argument
            parts = arg.split()
            if len(parts) == 2:
                mode = parts[1]
                if mode in ("no", "percentage", "verbose"):
                    if config.token_usage is None:
                        config.token_usage = TokenUsageConfig()
                    config.token_usage.show_tokens = mode  # type: ignore
                    lines.append("")
                    lines.append(f"Set token usage display to: `{mode}`")
                    lines.append("Use `/config save` to persist this setting.")
                    # Update the displayed value in the config output
                    lines[7] = f"- token usage display: `{mode}`"
                    # Update +the prompt to reflect the new setting
                    self.conversation._update_console_prompt()
                else:
                    lines.append("")
                    lines.append(
                        f"Invalid mode: `{mode}`. Valid options: `no`, `percentage`, `verbose`"
                    )
            else:
                lines.append("")
                lines.append(
                    "Usage: `/config show_tokens <mode>` where mode is `no`, `percentage`, or `verbose`"
                )
                lines.append("")
                lines.append("- `no`: Don't show token usage")
                lines.append("- `percentage`: Show percentage of context used")
                lines.append(
                    "- `verbose`: Show completion tokens, total tokens, and percentage"
                )

        self.markdown("\n".join(lines))
