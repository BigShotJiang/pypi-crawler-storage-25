"""Reasoning command - show/hide reasoning content"""

from prompt_toolkit.completion import Completer, WordCompleter
from prompt_toolkit.document import Document

from openai.types import ReasoningEffort

from aicheat.commands.core import CommandWithSubcommandsBase

REASONING_EFFORT_VALUES = ReasoningEffort.__args__[0].__args__


class ReasoningCompleter(Completer):
    """Completer for the reasoning command"""

    _meta_dict = {
        "show": "Show reasoning content",
        "hide": "Hide reasoning content",
        "toggle": "Toggle showing reasoning content",
        "effort": "Get/Set reasoning effort",
    }

    def get_completions(self, document: Document, complete_event):
        text = document.text_before_cursor.lstrip()
        stripped_len = len(document.text_before_cursor) - len(text)

        completer: Completer
        if " " not in text:
            # No space in the input: behave exactly like `WordCompleter`.
            completer = WordCompleter(
                list(self._meta_dict.keys()),
                meta_dict=self._meta_dict,
            )
            yield from completer.get_completions(document, complete_event)

            return

        # If there is a space, check for the first term, and use a
        # subcompleter.
        text_list = text.split()
        first_term = text_list[0]

        if first_term != "effort":
            return

        try:
            second_term = text_list[1]
        except IndexError:
            second_term = ""

        if second_term == "get":
            return

        if second_term == "set":
            completer = WordCompleter(REASONING_EFFORT_VALUES)

            remaining_text = text[len(second_term) :].lstrip()
            move_cursor = len(text) - len(remaining_text) + stripped_len

            new_document = Document(
                remaining_text,
                cursor_position=document.cursor_position - move_cursor,
            )

            yield from completer.get_completions(new_document, complete_event)
            return

        completer = WordCompleter(
            ["get", "set"],
            meta_dict={
                "get": "Get reasoning effort",
                "set": "Set reasoning effort",
            },
        )

        remaining_text = text[len(second_term) :].lstrip()
        move_cursor = len(text) - len(remaining_text) + stripped_len

        new_document = Document(
            remaining_text,
            cursor_position=document.cursor_position - move_cursor,
        )

        yield from completer.get_completions(new_document, complete_event)


class ReasoningCommand(CommandWithSubcommandsBase):
    r"""Show reasoning content. Usage: /reasoning show|hide|toggle|(effort [get|set \<value\>])

    Usage:

    /reasoning show|hide|toggle
    /reasoning effort [get|set <value>]
    """

    name = "reasoning"

    completer = ReasoningCompleter()
    SUBCOMMANDS = {
        "show": "_show_reasoning",
        "hide": "_hide_reasoning",
        "toggle": "_toggle_reasoning",
        "effort": "_effort_reasoning",
    }

    def execute_default(self) -> None:
        """Default action: toggle reasoning display"""
        self._toggle_reasoning()

    def _show_reasoning(self, args: str = "") -> None:
        self.conversation.show_reasoning(True)
        self.system("# Showing reasoning content")

    def _hide_reasoning(self, args: str = "") -> None:
        self.conversation.show_reasoning(False)
        self.system("# Hiding reasoning content")

    def _toggle_reasoning(self, args: str = "") -> None:
        showing = self.conversation.show_reasoning()
        self.system(f"# {'Showing' if not showing else 'Hiding'} reasoning content")

    def _effort_reasoning(self, args: str) -> None:
        args_list = args.split()

        try:
            effort_action = args_list[0] if args_list else None
        except IndexError:
            effort_action = None

        try:
            new_reasoning_effort = args_list[1] if len(args_list) > 1 else None
        except IndexError:
            new_reasoning_effort = None

        reasoning_effort = self.conversation.get_reasoning_effort()

        if not effort_action or effort_action == "get":
            self.system(f"# Current reasoning effort: {reasoning_effort}")
            return

        if effort_action not in ("set", "get"):
            self.markdown(
                "Usage: /reasoning effort [get|set <value>]",
            )
            return

        if effort_action == "set" and (
            not new_reasoning_effort
            or (
                new_reasoning_effort
                and new_reasoning_effort not in REASONING_EFFORT_VALUES
            )
        ):
            self.markdown(
                f"Usage: /reasoning effort set {'|'.join(REASONING_EFFORT_VALUES)}",
            )
            return

        if effort_action == "get" and new_reasoning_effort:
            self.markdown("Usage: /reasoning effort [get]")
            return None

        if effort_action == "set":
            self.conversation.set_reasoning_effort(new_reasoning_effort)
            self.system(f"# Set reasoning effort to {new_reasoning_effort}")
