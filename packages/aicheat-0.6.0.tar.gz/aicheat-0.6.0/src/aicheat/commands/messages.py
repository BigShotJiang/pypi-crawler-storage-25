"""Messages command - shows conversation history"""

import json

from aicheat.commands.core import CommandBase
from aicheat.chat_utils import filter_encoded_images


class MessagesCommand(CommandBase):
    """Shows the current conversation.

    Usage:
    - /messages    - Shows all messages
    - /messages 2  - Shows the second message
    - /messages 2: - Shows all messages starting from the second
    - /messages -1 - Shows the last message"""

    name = "messages"

    def _get_message_range(
        self, messages: list[dict[str, str]], arg: str
    ) -> list[dict[str, str]]:
        range_min_str, range_max_str = arg.split(":")
        try:
            range_min = int(range_min_str)
        except ValueError:
            range_min = None
        try:
            range_max = int(range_max_str)
        except ValueError:
            range_max = None

        if range_min is None and range_max is None:
            messages_slice = messages
        elif range_min is None:
            messages_slice = messages[:range_max]
        elif range_max is None:
            messages_slice = messages[range_min:]
        else:
            messages_slice = messages[range_min:range_max]

        return messages_slice

    def _get_message_index(
        self, messages: list[dict[str, str | dict[str, str]]], idx: int
    ) -> str:
        try:
            to_print = messages[idx]["content"]
        except IndexError:
            n_messages = len(self.conversation.messages)
            allowed_range = "[0]" if n_messages == 1 else f"[0-{n_messages - 1}]"
            return self.console.print(
                f"index is out of range, must be in {allowed_range}",
                style="error",
            )
        except KeyError:
            if "tool_calls" not in messages[idx]:
                raise

            parts: list[str] = []
            for tool_call in messages[idx]["tool_calls"]:
                assert isinstance(tool_call, dict)

                f = tool_call["function"]

                name = f["name"]
                args_dict = json.loads(f["arguments"])

                formatted_args = ", ".join(f'{k}="{v}"' for k, v in args_dict.items())
                formatted_tool_call_message = f"`{name}({formatted_args})`"

                parts.append(f"🔧 tool_call: {formatted_tool_call_message}")

            return "\n".join(parts)

        assert isinstance(to_print, str)
        return to_print

    def execute(self, arg: str) -> str | None:
        cleaned = filter_encoded_images(self.conversation.messages)
        if not arg:
            self.json_output(cleaned, indent=1)
            return None

        to_print: str | list[dict[str, str]]

        if ":" in arg:
            to_print = self._get_message_range(cleaned, arg)
            self.json_output(to_print, indent=1)
            return None

        try:
            idx = int(arg)
        except ValueError:
            self.error("Invalid message index, must be a number")
            return None

        to_print = self._get_message_index(cleaned, idx)
        self.markdown(to_print)

        return None
