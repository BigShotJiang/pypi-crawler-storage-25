"""Shell command - execute shell commands with ! prefix"""

import os
import subprocess

from aicheat.commands.core import CommandBase


class ShellCommand(CommandBase):
    """Messages prefixed with `!` are interpreted as shell commands: they will be executed and output is inserted in the current context."""

    name = "shell_command"
    prefix = "!"

    @classmethod
    def rule(cls, prompt: str) -> bool:
        return prompt.startswith(cls.prefix)

    def parse_shell_command(self, prompt: str) -> str:
        return prompt.lstrip(self.prefix).strip()

    def execute(self, prompt: str) -> str:
        command = self.parse_shell_command(prompt)
        shell_path = os.getenv("SHELL", "/bin/bash")
        with self.conversation.console.status(f"Calling {command}"):
            proc = subprocess.Popen(
                [
                    shell_path,
                    "-il",
                    "-c",
                    command,
                ],
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            try:
                output, _ = proc.communicate()
            finally:
                retcode = proc.returncode
                proc.kill()

            if retcode != 0:
                self.console.print("Command failed", style="error")

        self.markdown(
            f"{command=}, return code={retcode}, output:\n```\n{output}\n```\n"
        )

        return f"User ran shell command `{command}`. return code={retcode}, output:\n```\n{output}\n```\n"
