"""YOLO command - enable/disable confirmation dialogs"""

from prompt_toolkit.completion import NestedCompleter, WordCompleter

from aicheat.commands.core import CommandWithSubcommandsBase
from aicheat.tools import registry as tools_registry


class LazyYoloCompleter(NestedCompleter):
    """Lazy wordcompleter to list tools that require confirmation *after* they have been registered."""

    @classmethod
    def from_tools_registry(cls) -> NestedCompleter:
        commands = ["enable", "disable", "toggle", "status"]

        tool_names = [
            tool.name for tool in tools_registry.values() if tool.requires_confirmation
        ]

        return cls.from_nested_dict(
            {
                command: WordCompleter(
                    tool_names,
                    meta_dict=None,
                )
                for command in commands
            }
        )


class YoloCommand(CommandWithSubcommandsBase):
    """Enable YOLO mode: disable confirmation dialog for all or selected tool calls

    Usage:
      - /yolo [status]                             - shows the current status
      - /yolo [enable|disable|toggle]              - Enable/Disable/Toggle YOLO mode for all tools
      - /yolo [enable|disable|toggle] [tool name]  - Enable/Disable/Toggle YOLO mode for a specific tool
    """

    name = "yolo"

    completer = LazyYoloCompleter.from_tools_registry()
    SUBCOMMANDS = {
        "enable": "enable",
        "disable": "disable",
        "status": "status",
        "toggle": "toggle",
    }

    def execute_default(self) -> None:
        """Default action: show status"""
        self._status_yolo("")

    def enable(self, tool_name: str) -> None:
        if tool_name and tool_name not in tools_registry:
            self.error(f"No such tool: `{tool_name}`")
            return

        self.conversation.set_yolo_mode(True, tool_name if tool_name else None)

        if tool_name:
            self.system(f"# YOLO mode enabled for tool: {tool_name}")
        else:
            self.system("# YOLO mode enabled: no confirmation required for tool calls.")

    def disable(self, tool_name: str) -> None:
        if tool_name and tool_name not in tools_registry:
            self.error(f"No such tool: `{tool_name}`")
            return

        self.conversation.set_yolo_mode(False, tool_name if tool_name else None)

        if tool_name:
            self.system(f"# YOLO mode disabled for tool: {tool_name}")
        else:
            self.system("# YOLO mode disabled")

    def toggle(self, tool_name: str | None = None) -> None:
        if tool_name and tool_name not in tools_registry:
            self.error(f"No such tool: `{tool_name}`")
            return

        self.conversation.set_yolo_mode(tool_name=tool_name if tool_name else None)

        yolo_status = self.conversation.get_yolo_mode(tool_name if tool_name else None)

        if tool_name:
            message = (
                f"# YOLO mode enabled for tool: {tool_name}"
                if yolo_status
                else f"# YOLO mode disabled for tool: {tool_name}"
            )
        else:
            message = (
                "# YOLO mode enabled: no confirmation required for tool calls."
                if yolo_status
                else "# YOLO mode disabled"
            )

        self.system(message)

    def status(self, args: str) -> None:
        md_lines = ["# YOLO mode status"]
        md_lines.append("When **enabled**, tool calls require NO approval")
        for name, enabled in self.conversation.get_yolo_mode_status().items():
            md_lines.append(
                f"- `{name}`: " + ("`enabled`" if enabled else "`disabled`")
            )
        self.markdown("\n".join(md_lines))
