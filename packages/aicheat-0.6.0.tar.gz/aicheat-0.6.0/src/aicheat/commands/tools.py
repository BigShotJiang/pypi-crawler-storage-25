"""Tools commands - list and manage tools"""

import inspect
import textwrap

from prompt_toolkit.completion import NestedCompleter, WordCompleter

from aicheat.commands.core import CommandBase
from aicheat.tools import registry as tools_registry


class LazyToolsCompleter(NestedCompleter):
    """Lazy wordcompleter to list available tools *after* they have been registered."""

    @classmethod
    def from_tools_registry(cls) -> NestedCompleter:
        return cls.from_nested_dict(
            {
                tool.name: WordCompleter(
                    [
                        "disable" if tool.enabled else "disabled",
                        "toggle",
                        "enable",
                    ]
                )
                for tool in tools_registry.values()
            }
        )


class ToolsCommand(CommandBase):
    """List available tools"""

    name = "tools"

    def execute(self, args: str = "") -> str | None:
        max_tool_width = max(map(len, tools_registry)) + 2
        max_doc_width = (
            max(
                map(
                    len,
                    map(
                        lambda f: (
                            f.__doc__.split("\n", maxsplit=1)[0] if f.__doc__ else ""
                        ),
                        tools_registry.values(),
                    ),
                )
            )
            + 1
        )
        tools_text = ["# 🛠️ Enabled tools"]
        disabled_tools_text = ["# 🛠️ Disabled tools"]

        for tool_name, tool in tools_registry.items():
            doc_header = (
                tool.function.__doc__.split("\n", maxsplit=1)[0]
                if tool.function.__doc__
                else ""
            )
            formatted_tool_name = f"`{tool_name}`"
            formatted_description = doc_header + (
                " (__requires confirmation__)" if tool.requires_confirmation else ""
            )

            (tools_text if tool.is_enabled() else disabled_tools_text).append(
                f"- {formatted_tool_name:<{max_tool_width}} │ {formatted_description:<{max_doc_width}}"
            )

        self.markdown("\n".join(tools_text) + "\n" + "\n".join(disabled_tools_text))
        self.markdown("Use /tool <name> to get information about a tool")

        return None


# NOTE: this doesn't use CommandWithSubcommandsBase because it has a custom parsing strategy
class ToolCommand(CommandBase):
    """Get information and enable/disable a specific tool. Usage: `/tool <name> [enable|disable|toggle]`"""

    name = "tool"
    completer = LazyToolsCompleter.from_tools_registry()

    def execute(self, args: str) -> None:
        if not args:
            tools_cmd = ToolsCommand(self.conversation)
            tools_cmd.execute("")
            return

        parts = args.split()

        if len(parts) == 1:
            # Just tool name - show info
            self._show_tool(parts[0])
            return

        if len(parts) == 2:
            # Tool name and action
            name, action = parts
            self._handle_action(name, action)
            return

        # Too many arguments
        self.markdown(
            "Invalid usage: must call /tool [tool_name] [enable|disable|toggle]",
        )

    def _show_tool(self, name: str) -> None:
        try:
            tool = tools_registry[name]
        except KeyError:
            self.markdown(f"No tool named `{name}` exists")
            return

        tools_text = [f"# source code for {name}"]

        source = inspect.getsource(tool.function)
        formatted_source = textwrap.dedent(
            """
            ```python
            {code}
            ```
            """
        ).format(code=source)

        tools_text.append(formatted_source)

        self.markdown("\n".join(tools_text))

    def _handle_action(self, name: str, action: str) -> None:
        try:
            tool = tools_registry[name]
        except KeyError:
            self.markdown(f"No tool named `{name}` exists")
            return

        match action.lower():
            case "enabled" | "enable":
                tool.enabled = True
                self.markdown(f"Tool `{tool.name}` is now enabled")
            case "disabled" | "disable":
                tool.enabled = False
                self.markdown(f"Tool `{tool.name}` is now disabled")
            case "toggle":
                tool.enabled = not tool.enabled
                self.markdown(
                    f"Tool `{tool.name}` is now "
                    + ("enabled" if tool.enabled else "disabled")
                )
            case _:
                self.markdown(
                    "Invalid usage: must call /tool [tool_name] [enable|disable|toggle]",
                )
                return

        self.system("# Use /config save to persist configuration")
