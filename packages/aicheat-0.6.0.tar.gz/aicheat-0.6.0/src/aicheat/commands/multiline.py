"""Multiline command - toggles multiline mode"""

from aicheat.commands.core import CommandBase


class MultilineCommand(CommandBase):
    """Enables multiline mode (can be used with an inline prompt, e.g /multiline first line)"""

    name = "multiline"

    def execute(self, args: str) -> None:
        return self.conversation.toggle_multiline(args)
