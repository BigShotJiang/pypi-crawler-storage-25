"""Prompt command - shows/sets the system prompt"""

import textwrap

from aicheat.commands.core import CommandBase


class PromptCommand(CommandBase):
    """Show/Set the system prompt"""

    name = "prompt"

    def execute(self, new_prompt: str) -> None:
        if new_prompt:
            self.conversation.override_system_prompt(new_prompt)

        self.markdown(
            textwrap.dedent(
                """
                # 📜 System prompt

                ```markdown
                {md}
                ```
                """
            ).format(md=self.conversation.system_prompt["content"])
        )
