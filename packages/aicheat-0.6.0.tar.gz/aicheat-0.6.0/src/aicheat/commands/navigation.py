"""Navigation commands - cd, cwd, pwd"""

import os
from pathlib import Path

from prompt_toolkit.completion.filesystem import PathCompleter

from aicheat.commands.core import CommandBase
from aicheat.completions import completion_filter_invisible_files

from aicheat.utils import safe_relative_to


class CdCommand(CommandBase):
    """change working directory"""

    name = "cd"
    completer = PathCompleter(
        only_directories=True,
        file_filter=completion_filter_invisible_files,
    )

    def execute(self, path_str: str) -> str | None:
        if not path_str:
            self.error("Must provide a path")
            return None

        path = self.resolve_path(path_str)

        if not self.validate_is_directory(path, f"{path_str=} is not a directory"):
            return None

        os.chdir(path)
        msg = f"Working directory now changed to: {path.as_posix()}"
        self.info(msg)
        return msg


class CwdCommand(CommandBase):
    """Get the current working directory"""

    name = "cwd"

    def execute(self, args: str) -> str | None:
        cwd = safe_relative_to(Path.cwd(), Path.home())

        if cwd.as_posix() == ".":
            cwd = Path("~")

        msg = f"Working directory is: ~/{cwd.as_posix()}"
        self.info(msg)
        return msg


class PwdCommand(CwdCommand):
    """alias to /cwd"""

    name = "pwd"
