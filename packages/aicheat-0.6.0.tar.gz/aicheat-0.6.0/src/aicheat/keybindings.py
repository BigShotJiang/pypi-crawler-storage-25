from __future__ import annotations
import copy

from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import Keys
from typing import TYPE_CHECKING
from .logger import getLogger

from prompt_toolkit.filters import IsMultiline
from prompt_toolkit.key_binding.bindings.named_commands import (
    accept_line,
)

if TYPE_CHECKING:
    from prompt_toolkit.key_binding.key_processor import KeyPressEvent as Event


logger = getLogger(__name__)

if TYPE_CHECKING:
    from .chat import Conversation

bindings = KeyBindings()
_conversation: Conversation | None = None


@bindings.add(Keys.ControlV)
def _(event: Event):
    _conversation.toggle_multiline(skip_input=True)
    accept_line(event)
    # event.current_buffer.insert_text("\n")


@bindings.add("c-j", filter=IsMultiline())
def _(event: Event):
    accept_line(event)


@bindings.add("escape", "enter", filter=IsMultiline())
def _(event: Event):
    logger.debug("Ignoring escape enter")


@bindings.add("c-t")
def toggle_token_display(event: Event):
    """Toggle token usage display on/off"""
    if _conversation and _conversation.config.token_usage:
        current_mode = _conversation.config.token_usage.show_tokens
        # Cycle through: no -> percentage -> verbose -> no
        if current_mode == "no":
            new_mode = "percentage"
        elif current_mode == "percentage":
            new_mode = "verbose"
        else:
            new_mode = "no"

        _conversation.config.token_usage.show_tokens = new_mode  # type: ignore
        _conversation._update_console_prompt()
        logger.info("Toggled token display to: %s", new_mode)


@bindings.add("s-tab")
def toggle_yolo(event: Event):
    """Toggle yolo mode on/off"""
    if not _conversation:
        logger.error("Called toggle yolo via keybinding but conversation is not set")
        return

    from .commands.yolo import YoloCommand

    command = YoloCommand(_conversation)
    command.info("")

    document = copy.copy(event.current_buffer.document)
    event.current_buffer.reset()
    command.toggle()
    event.app.reset()

    event.current_buffer.set_document(document)


def register_conversation(c: Conversation) -> KeyBindings:
    global _conversation

    _conversation = c  # noqa: F841
    logger.info("Registered conversation to keybindings module")
    return bindings
