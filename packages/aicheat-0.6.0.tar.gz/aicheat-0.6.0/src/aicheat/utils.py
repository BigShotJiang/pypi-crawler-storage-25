from __future__ import annotations
import subprocess

import importlib
import inspect
import os
import re
from pathlib import Path
from shutil import which
from subprocess import check_output
from typing import TYPE_CHECKING, Any, Sequence

import yaml
from prompt_toolkit.formatted_text import (
    AnyFormattedText,
    FormattedText,
    merge_formatted_text,
)
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import Keys
from prompt_toolkit.shortcuts.prompt import PromptSession

import aicheat
from aicheat.logger import getLogger

if TYPE_CHECKING:
    from prompt_toolkit.key_binding.key_processor import KeyPressEvent
    from prompt_toolkit.shortcuts.prompt import AnyFormattedText


logger = getLogger(__name__)


def _init_submodules(current_module: str) -> list[str]:
    """helper to import all submodules in a directory and return a list of found packages

    This is useful to perform dynamic registration of functions in modules."""
    frame = inspect.currentframe()
    assert frame is not None

    caller_frame = frame.f_back
    assert caller_frame is not None
    caller_module = caller_frame.f_globals["__name__"]

    found_packages = []
    module_base = Path(aicheat.__file__).parent
    for path in Path(current_module).parent.iterdir():
        if path.is_file() and path.suffix != ".py":
            continue

        resolved_path = safe_relative_to(path, module_base)

        if path.name in ("__init__.py", "core.py"):
            logger.debug("Excluding %s", resolved_path)
            continue

        if path.name == "__pycache__":
            continue

        logger.debug("Loading %s", resolved_path)

        # Use stem instead of rstrip to avoid stripping individual characters
        name = path.stem
        module = importlib.import_module(f"{caller_module}.{name}")
        found_packages.append(module.__name__)

    return found_packages


def get_system_information() -> str:
    info_lines = []

    info_lines.append(f"- Current shell is {os.getenv('SHELL')}")

    if "TMUX" in os.environ:
        logger.info("In a tmux session")
        info_lines.append(
            "- User is running a tmux session. Run `tmux list-panes` to show panes in the current window and `tmux list-windows` to list all windows"
        )

    if which("inxi"):
        description = check_output(
            "inxi --system",
            shell=True,
        ).decode()

        logger.info("Got system information through inxi")
        info_lines.append(f"- {description}")
    elif (os_release := Path("/etc/os-release")).exists():
        os_release_info = os_release.read_text().splitlines()

        os_name = ""
        for line in os_release_info:
            if not line.startswith("NAME="):
                continue

            os_name = line.lstrip('NAME="').rstrip("")
            logger.info("Got os name from /etc/os-release: %s")
            info_lines.append(f"- OS: {os_name}")
            break
    else:
        logger.info("Could not get system information.")

    git_status_code, git_root = subprocess.getstatusoutput(
        "git rev-parse --show-toplevel"
    )

    if git_status_code == 0:
        cwd = Path.cwd()
        if git_root == cwd.as_posix():
            git_info = "- Working in a git repo's root directory"
        else:
            relative_path = Path.cwd().relative_to(Path(git_root))
            git_info = f"- Working in a git repo's subdirectory: {relative_path}"

        info_lines.append(git_info)

    return "\n".join(info_lines)


# modified from from prompt_toolkit.shortcuts.prompt
def create_choice_session(
    message: AnyFormattedText, choices: Sequence[str] = ("y", "n"), default: str = "y"
) -> PromptSession[str]:
    """Create a `PromptSession` object for the 'choice' function"""
    bindings = KeyBindings()

    if default not in choices:
        raise ValueError("default must be in choices")

    formatted_choices = []
    for choice in choices:
        if not len(choice) == 1:
            raise ValueError("choices must be a list of single characters")

        @bindings.add(choice.upper())
        @bindings.add(choice.lower())
        def handle_keypress(event: KeyPressEvent) -> None:
            session.default_buffer.text = event.data
            logger.debug("Got keypress: %s", event.data)
            event.app.exit(result=event.data.lower())

        if choice.lower() == default.lower():
            # default choice in bold
            formatted_choices.append(("bold ansipurple", choice.upper()))
        else:
            formatted_choices.append(("ansipurple", choice))

        # add separator
        if choice != choices[-1]:
            formatted_choices.append(("ansipurple", "/"))

    @bindings.add(Keys.Any)
    def ignore_other_keys(event: KeyPressEvent) -> None:
        logger.debug("Disallowing other text: %s (not in %s)", event.data, choices)

    suffix = FormattedText(
        [("ansipurple", " ("), *formatted_choices, ("ansipurple", ") ")]
    )
    complete_message = merge_formatted_text([message, suffix])

    session: PromptSession[str] = PromptSession(complete_message, key_bindings=bindings)
    return session


# from prompt_toolkit.shortcuts.prompt
def choice(
    message: AnyFormattedText = "Confirm?", choices=("y", "n"), default: str = "y"
) -> str:
    """returns (and accepts) one of the given choices"""
    try:
        return create_choice_session(
            message,
            choices,
            default=default,
        ).prompt()
    except EOFError:
        return default


def parse_frontmatter(content: str) -> tuple[dict[str, Any], str]:
    """Parse YAML frontmatter from content and return frontmatter dict and remaining content."""
    yaml_match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", content, re.DOTALL)
    if not yaml_match:
        return {}, content

    try:
        frontmatter = yaml.safe_load(yaml_match.group(1)) or {}
        remaining_content = yaml_match.group(2).strip()
    except (ValueError, yaml.YAMLError):
        logger.exception("Failed to parse YAML frontmatter")
        return {}, content

    return frontmatter, remaining_content


def safe_relative_to(
    path: Path,
    base_path: Path | None = None,
) -> Path:
    """safely return a path relative to the current working directory"""
    try:
        return path.relative_to(base_path or Path.cwd())
    except ValueError:
        return path


logger.debug("Utils: init")
