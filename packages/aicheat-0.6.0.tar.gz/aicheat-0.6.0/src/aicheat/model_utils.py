from __future__ import annotations

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from openai.types.model import Model

from aicheat.logger import getLogger

logger = getLogger(__name__)


def get_model_max_context(model: Model) -> int | None:
    # try to get max_model_len (vllm)
    # fallback to context_window (llama.cpp)

    if max_model_len := getattr(model, "max_model_len", None):
        # vllm
        return max_model_len

    if context_window := getattr(model, "context_window", None):
        # llama.cpp
        return context_window

    logger.info("Failed to get context len for %s", model)
    return None
