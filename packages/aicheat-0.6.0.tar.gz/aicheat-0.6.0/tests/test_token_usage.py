"""Tests for token usage tracking feature"""

import pytest
from openai.types.chat.chat_completion_chunk import (
    Choice,
    ChoiceDelta,
    CompletionUsage,
)
from openai.types.model import Model

from aicheat.chat import Conversation
from aicheat.config import Config, TokenUsageConfig


@pytest.fixture
def mocked_client_with_usage():
    """Mock client that returns usage information in chunks"""

    class Data:
        data: list[Model] = [
            Model(
                id="test-model",
                created="1234",
                object="model",
                owned_by="pytest",
                max_model_len=8192,  # Set a specific max_model_len for testing
            )
        ]

    class Models:
        def list(self):
            return Data()

    # Create a mock chunk with usage data
    usage = CompletionUsage(
        prompt_tokens=100,
        completion_tokens=50,
        total_tokens=150,
        prompt_tokens_details=None,
    )

    class MockChunk:
        def __init__(self):
            self.choices = [
                Choice(
                    index=0,
                    delta=ChoiceDelta(content="test response"),
                    finish_reason="stop",
                )
            ]
            self.usage = usage

    class MockCompletions:
        def create(self, *args, **kwargs):
            # Return an iterator with one chunk
            return iter([MockChunk()])

        @property
        def models(self):
            return Models()

    class MockChat:
        completions = MockCompletions()

    class MockClient:
        chat = MockChat()
        base_url = "http://localhost:8080"
        models = Models()

    return MockClient()


def test_token_usage_tracking(mocked_client_with_usage, tmp_path):
    """Test that token usage is tracked correctly"""
    import os

    os.chdir(tmp_path)

    # Create conversation with token usage enabled
    config = Config()
    config.token_usage = TokenUsageConfig(show_tokens="percentage")

    conversation = Conversation(
        client=mocked_client_with_usage,
        config=config,
        load_agent_files=False,  # Don't load agent files in tests
    )

    # Manually set token_usage to avoid config file interference
    conversation.config.token_usage = TokenUsageConfig(
        show_tokens=config.token_usage.show_tokens
    )

    # Mock the model selection
    conversation.model = mocked_client_with_usage.models.list().data[0]
    conversation._set_max_model_len()

    # Verify max_model_len is set
    assert conversation._max_model_len == 8192

    # Simulate processing a response (this would normally happen in _process)
    # We'll manually call _update_token_usage with mock usage data
    from openai.types.chat.chat_completion_chunk import CompletionUsage

    usage = CompletionUsage(
        prompt_tokens=100,
        completion_tokens=50,
        total_tokens=150,
        prompt_tokens_details=None,
    )

    conversation._update_token_usage(usage)

    # Verify token counts are tracked
    assert conversation._prompt_tokens == 100
    assert conversation._completion_tokens == 50
    assert conversation._total_tokens == 150


def test_token_usage_display_percentage(mocked_client_with_usage, tmp_path):
    """Test token usage display in percentage mode"""
    import os

    os.chdir(tmp_path)

    config = Config()
    config.token_usage = TokenUsageConfig(show_tokens="percentage")

    conversation = Conversation(
        client=mocked_client_with_usage,
        config=config,
        load_agent_files=False,  # Don't load agent files in tests
    )

    # Manually set token_usage to avoid config file interference
    conversation.config.token_usage = TokenUsageConfig(
        show_tokens=config.token_usage.show_tokens
    )

    conversation.model = mocked_client_with_usage.models.list().data[0]
    conversation._set_max_model_len()

    from openai.types.chat.chat_completion_chunk import CompletionUsage

    usage = CompletionUsage(
        prompt_tokens=100,
        completion_tokens=50,
        total_tokens=150,
        prompt_tokens_details=None,
    )

    conversation._update_token_usage(usage)

    # Get the display string
    display = conversation._get_token_usage_display()

    # Should show total tokens and percentage
    assert "150" in display
    assert "1.83%" in display  # 150/8192 * 100 ≈ 1.83%


def test_token_usage_display_verbose(mocked_client_with_usage, tmp_path):
    """Test token usage display in verbose mode"""
    import os

    os.chdir(tmp_path)

    config = Config()
    config.token_usage = TokenUsageConfig(show_tokens="verbose")

    conversation = Conversation(
        client=mocked_client_with_usage,
        config=config,
        load_agent_files=False,  # Don't load agent files in tests
    )

    # Manually set token_usage to avoid config file interference
    conversation.config.token_usage = TokenUsageConfig(
        show_tokens=config.token_usage.show_tokens
    )

    conversation.model = mocked_client_with_usage.models.list().data[0]
    conversation._set_max_model_len()

    from openai.types.chat.chat_completion_chunk import CompletionUsage

    usage = CompletionUsage(
        prompt_tokens=100,
        completion_tokens=50,
        total_tokens=150,
        prompt_tokens_details=None,
    )

    conversation._update_token_usage(usage)

    # Get the display string
    display = conversation._get_token_usage_display()

    # Should show completion tokens, total tokens, max model len, and percentage
    assert "50" in display  # completion tokens
    assert "150" in display  # total tokens
    assert "8192" in display  # max model len
    assert "1.83%" in display


def test_token_usage_display_disabled(mocked_client_with_usage, tmp_path):
    """Test token usage display when disabled"""
    import os

    os.chdir(tmp_path)

    # Test the _get_token_usage_display method directly with show_tokens="no"
    config = Config()
    config.token_usage = TokenUsageConfig(show_tokens="no")

    conversation = Conversation(
        client=mocked_client_with_usage,
        config=config,
        load_agent_files=False,
    )

    # Override the config's token_usage after initialization
    conversation.config.token_usage = TokenUsageConfig(show_tokens="no")

    conversation.model = mocked_client_with_usage.models.list().data[0]
    conversation._max_model_len = 8192  # Set directly
    conversation._total_tokens = 150
    conversation._completion_tokens = 50

    # Get the display string - should be empty when mode is "no"
    display = conversation._get_token_usage_display()
    assert display == ""


def test_token_usage_reset_on_conversation_reset(mocked_client_with_usage, tmp_path):
    """Test that token usage is reset when conversation is reset"""
    import os

    os.chdir(tmp_path)

    config = Config()
    config.token_usage = TokenUsageConfig(show_tokens="percentage")

    conversation = Conversation(
        client=mocked_client_with_usage,
        config=config,
        load_agent_files=False,  # Don't load agent files in tests
    )

    # Manually set token_usage to avoid config file interference
    conversation.config.token_usage = TokenUsageConfig(
        show_tokens=config.token_usage.show_tokens
    )

    conversation.model = mocked_client_with_usage.models.list().data[0]
    conversation._set_max_model_len()

    from openai.types.chat.chat_completion_chunk import CompletionUsage

    usage = CompletionUsage(
        prompt_tokens=100,
        completion_tokens=50,
        total_tokens=150,
        prompt_tokens_details=None,
    )

    conversation._update_token_usage(usage)

    # Verify tokens are tracked
    assert conversation._total_tokens == 150

    # Reset conversation
    conversation._reset_conversation()

    # Verify tokens are reset
    assert conversation._total_tokens == 0
    assert conversation._completion_tokens == 0
    assert conversation._prompt_tokens == 0


def test_token_usage_no_max_model_len(mocked_client_with_usage, tmp_path):
    """Test token usage display when max_model_len is not available"""
    import os

    os.chdir(tmp_path)

    config = Config()
    config.token_usage = TokenUsageConfig(show_tokens="percentage")

    conversation = Conversation(
        client=mocked_client_with_usage,
        config=config,
        load_agent_files=False,  # Don't load agent files in tests
    )

    # Manually set token_usage to avoid config file interference
    conversation.config.token_usage = TokenUsageConfig(
        show_tokens=config.token_usage.show_tokens
    )

    conversation.model = mocked_client_with_usage.models.list().data[0]
    # Don't set _max_model_len (simulate it being None)
    conversation._max_model_len = None

    from openai.types.chat.chat_completion_chunk import CompletionUsage

    usage = CompletionUsage(
        prompt_tokens=100,
        completion_tokens=50,
        total_tokens=150,
        prompt_tokens_details=None,
    )

    conversation._update_token_usage(usage)

    # Display should be empty when max_model_len is not available
    display = conversation._get_token_usage_display()
    assert display == ""
