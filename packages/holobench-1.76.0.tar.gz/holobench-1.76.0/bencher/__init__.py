import warnings

warnings.filterwarnings("ignore", message="Unable to import Axes3D", category=UserWarning)

from .bencher import Bench, BenchCfg, BenchRunCfg
from .bench_runner import BenchRunner
from .example.benchmark_data import ExampleBenchCfg
from .bench_plot_server import BenchPlotServer
from .variables.sweep_base import hash_sha1
from .variables.inputs import (
    IntSweep,
    FloatSweep,
    StringSweep,
    EnumSweep,
    BoolSweep,
    SweepBase,
    YamlSweep,
)
from .variables.time import TimeSnapshot

from .variables.inputs import box, p, sweep
from .variables.results import (
    ResultVar,
    ResultBool,
    ResultVec,
    ResultHmap,
    ResultPath,
    ResultVideo,
    ResultImage,
    ResultString,
    ResultContainer,
    ResultReference,
    ResultVolume,
    OptDir,
    ResultDataSet,
    curve,
)

from .results.composable_container.composable_container_base import (
    ComposeType,
    ComposableContainerBase,
    PaneLayout,
)
from .results.composable_container.composable_container_video import (
    ComposableContainerVideo,
    RenderCfg,
)
from .results.composable_container.composable_container_panel import (
    ComposableContainerPanel,
)
from .results.composable_container.composable_container_dataframe import (
    ComposableContainerDataset,
)

from bencher.results.holoview_results.distribution_result.box_whisker_result import BoxWhiskerResult
from bencher.results.holoview_results.distribution_result.violin_result import ViolinResult
from bencher.results.holoview_results.scatter_result import ScatterResult
from bencher.results.holoview_results.distribution_result.scatter_jitter_result import (
    ScatterJitterResult,
)
from bencher.results.holoview_results.bar_result import BarResult
from bencher.results.holoview_results.line_result import LineResult
from bencher.results.holoview_results.curve_result import CurveResult
from bencher.results.holoview_results.heatmap_result import HeatmapResult
from bencher.results.holoview_results.band_result import BandResult
from bencher.results.holoview_results.surface_result import SurfaceResult
from bencher.results.holoview_results.tabulator_result import TabulatorResult
from bencher.results.holoview_results.table_result import TableResult
from bencher.results.volume_result import VolumeResult

from bencher.results.histogram_result import HistogramResult
from bencher.results.explorer_result import ExplorerResult
from bencher.results.dataset_result import DataSetResult

from .utils import (
    hmap_canonical_input,
    get_nearest_coords,
    make_namedtuple,
    gen_path,
    gen_image_path,
    gen_video_path,
    gen_rerun_data_path,
    lerp,
    tabs_in_markdown,
    publish_file,
    github_content,
)

from .utils_rrd import (
    publish_and_view_rrd,
    rrd_to_pane,
    rrd_file_to_pane,
)
from .file_server import run_file_server

try:
    from .utils_rerun import (
        rerun_to_pane,
        capture_rerun_window,
        capture_rerun_rrd,
    )
except ModuleNotFoundError:
    pass


from .regression import RegressionResult, RegressionReport, RegressionError
from .perf_tracker import PerfTracker, PerfReport
from .git_info import git_time_event
from .plotting.plot_filter import VarRange, PlotFilter
from .variables.parametrised_sweep import ParametrizedSweep
from .variables.singleton_parametrized_sweep import ParametrizedSweepSingleton
from .sample_order import SampleOrder
from .caching import CachedParams
from .results.bench_result import BenchResult
from .results.optimize_result import OptimizeResult
from .results.video_result import VideoResult
from .results.holoview_results.holoview_result import ReduceType, HoloviewResult
from .bench_report import BenchReport, GithubPagesCfg
from .job import Executors
from .sweep_timings import SweepTimings
from .video_writer import VideoWriter, add_image
from .class_enum import ClassEnum, ExampleEnum
from .factories import create_bench, create_bench_runner
from .run import run
