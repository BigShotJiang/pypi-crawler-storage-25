<script lang="ts">
  import { onMount } from 'svelte';
  import { goto } from '$app/navigation';
  import { page } from '$app/stores';
  import Clock from 'lucide-svelte/icons/clock';
  import FolderKanban from 'lucide-svelte/icons/folder-kanban';
  import ListTodo from 'lucide-svelte/icons/list-todo';
  import MessageSquareText from 'lucide-svelte/icons/message-square-text';
  import Settings from 'lucide-svelte/icons/settings';
  import { blockingOverlayActive } from '$lib/stores/overlays';
  import { emitTabReset } from '$lib/stores/tabReset';
  import { viewportMetrics } from '$lib/stores/viewport';

  /**
   * Mobile bottom tab bar. Shown only below `lg` breakpoint (matches `isMobile`
   * store's pivot). Contains the four most-used top-level destinations.
   *
   * Hidden inside chat detail screens so the composer owns the bottom safe-area.
   */

  interface Props {
    hidden?: boolean;
  }

  let { hidden = false }: Props = $props();
  let navEl = $state<HTMLElement | null>(null);

  const tabs = [
    { href: '/chat', label: 'Chat', icon: MessageSquareText },
    { href: '/projects', label: 'Projects', icon: FolderKanban },
    { href: '/tasks', label: 'Tasks', icon: ListTodo },
    { href: '/schedules', label: 'Schedules', icon: Clock },
    { href: '/settings', label: 'Settings', icon: Settings }
  ];

  function isActive(href: string, pathname: string): boolean {
    if (href === '/chat' && pathname.startsWith('/chat')) return true;
    return pathname.startsWith(href);
  }

  // True when the current route is represented by one of the four tabs.
  const isOnTabRoute = $derived(tabs.some((tab) => isActive(tab.href, $page.url.pathname)));

  // Hide the tab bar while the on-screen keyboard is open. The bar is
  // `position: fixed; bottom: 0` anchored to the layout viewport, so when
  // iOS/Android slide the keyboard up it would otherwise be stuck
  // underneath it. Collapsing it also frees the `--app-shell-bottom-offset`
  // reservation, so the shell uses the full visible height above the
  // keyboard.
  const keyboardOpen = $derived($viewportMetrics.keyboardOpen);
  const visible = $derived(!hidden && !$blockingOverlayActive && !keyboardOpen);

  function setBottomOffset(value: number): void {
    if (typeof document === 'undefined') return;
    document.documentElement.style.setProperty('--app-shell-bottom-offset', `${Math.max(0, Math.round(value))}px`);
  }

  function syncBottomOffset(): void {
    if (typeof window === 'undefined') return;
    const shouldReserve = visible && window.innerWidth < 1024;
    setBottomOffset(shouldReserve ? navEl?.offsetHeight ?? 0 : 0);
  }

  $effect(() => {
    if (typeof window === 'undefined') return;
    void visible;
    void navEl;
    const rafId = window.requestAnimationFrame(syncBottomOffset);
    return () => window.cancelAnimationFrame(rafId);
  });

  $effect(() => {
    if (typeof ResizeObserver === 'undefined') return;
    const element = navEl;
    if (!element) {
      syncBottomOffset();
      return;
    }
    const observer = new ResizeObserver(syncBottomOffset);
    observer.observe(element);
    return () => observer.disconnect();
  });

  onMount(() => {
    syncBottomOffset();
    window.addEventListener('resize', syncBottomOffset);
    return () => {
      window.removeEventListener('resize', syncBottomOffset);
      setBottomOffset(0);
    };
  });
</script>

{#if visible}
  <nav
    bind:this={navEl}
    class="fixed inset-x-0 bottom-0 z-[60] border-t border-slate-800/80 lg:hidden"
    style="background: var(--app-bottom-chrome-bg); padding-left: env(safe-area-inset-left, 0px); padding-right: env(safe-area-inset-right, 0px); padding-bottom: var(--app-bottom-control-inset);"
    aria-label="Primary"
  >
    <ul class="grid grid-cols-5">
      {#each tabs as tab}
        {@const active = isActive(tab.href, $page.url.pathname)}
        {@const Icon = tab.icon}
        <li class="contents">
          <a
            class={`flex min-h-[48px] flex-col items-center justify-end gap-0.5 px-2 pb-0 pt-1 text-[10px] leading-none transition ${
              active
                ? 'text-sky-300'
                : isOnTabRoute
                  ? 'text-slate-400 hover:text-white'
                  : 'text-slate-500 hover:text-slate-300'
            }`}
            href={tab.href}
            aria-current={active ? 'page' : undefined}
            onclick={(event: MouseEvent) => {
              if (!active) return;
              // Active-tab tap: navigate to the bare href to clear any
              // `?filter=...` state, then broadcast a reset signal so the
              // current page also scrolls to top and drops expanded UI
              // state. Intercept the anchor so SvelteKit does not treat
              // this as a same-URL no-op when filters are already clean.
              event.preventDefault();
              const current = $page.url.pathname + $page.url.search;
              if (current !== tab.href) {
                void goto(tab.href, { replaceState: false, noScroll: true, keepFocus: true });
              }
              emitTabReset(tab.href);
            }}
          >
            <Icon class="h-5 w-5" aria-hidden="true" />
            <span class="font-medium">{tab.label}</span>
          </a>
        </li>
      {/each}
    </ul>
  </nav>
{/if}
