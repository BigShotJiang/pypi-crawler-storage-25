"""Chat messages — the universal request shape modern LLM providers converged on.

Single-turn is just ``[user("hi")]``; the convenience constructors keep call
sites clean.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from keel_llm_protocol.tools import ToolCall

__all__ = ["Message", "Role", "assistant", "system", "tool", "user"]

Role = Literal["system", "user", "assistant", "tool"]


@dataclass
class Message:
    """One message in a conversation.

    ``tool_calls`` is populated on *assistant* messages that requested tools;
    ``tool_call_id`` is set on *tool* messages answering a specific call.
    """

    role: Role
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    tool_call_id: str | None = None
    name: str | None = None


def system(content: str) -> Message:
    """A system message."""
    return Message("system", content)


def user(content: str) -> Message:
    """A user message."""
    return Message("user", content)


def assistant(content: str) -> Message:
    """An assistant message."""
    return Message("assistant", content)


def tool(content: str, *, tool_call_id: str, name: str | None = None) -> Message:
    """A tool-result message answering the tool call ``tool_call_id``."""
    return Message("tool", content, tool_call_id=tool_call_id, name=name)
