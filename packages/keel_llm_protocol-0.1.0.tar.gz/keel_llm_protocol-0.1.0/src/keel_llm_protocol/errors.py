"""Standardized adapter error taxonomy — the reliability core of keel-llm-protocol.

Every adapter raises these typed errors instead of provider-specific exceptions,
so reliability machinery (circuit breakers, retries, failover) acts on *uniform,
typed* failures: ``except RateLimitError`` works identically whether the call hit
Groq, Gemini, Mistral, or a local model.

The single most important field is ``category`` — it drives **three** distinct
reliability actions, which is what a plain ``retryable`` boolean cannot express:

- ``"backpressure"`` (e.g. 429) — healthy but throttled → **defer** (let a rate
  limiter pace it); do NOT retry now, do NOT record a circuit-breaker failure.
- ``"transient"`` (5xx, timeout) — a real but likely-temporary failure → **retry
  / fail over**.
- ``"terminal"`` (auth, bad request, context-length, content-filter) — won't
  change on retry → **fail fast**.

The defer-vs-retry-now distinction (deferring a 429 instead of retrying or failing
it) is the one that matters most for reliability at scale. ``retryable`` is kept
as a derived convenience (``category != "terminal"``).

Mapping a provider's failure to a category is the adapter's job; consuming code
depends only on the taxonomy.
"""

from __future__ import annotations

from typing import Literal

__all__ = [
    "AdapterError",
    "AdapterTimeoutError",
    "AuthenticationError",
    "BadRequestError",
    "ContentFilterError",
    "ContextLengthError",
    "ErrorCategory",
    "ProviderError",
    "RateLimitError",
    "TransientError",
]

# The reliability action an error maps to. Exactly three — one per action.
ErrorCategory = Literal["backpressure", "transient", "terminal"]


class AdapterError(Exception):
    """Base for every error a ``ModelAdapter`` raises.

    Carries typed metadata so reliability primitives act without inspecting
    provider internals. ``category`` is the single source of truth for how to
    react; ``retryable`` is derived from it.
    """

    # Unknown/unexpected errors are terminal by default — never retry something
    # you don't understand. Subclasses set their category explicitly.
    category: ErrorCategory = "terminal"

    def __init__(
        self,
        message: str = "",
        *,
        model_key: str | None = None,
        status_code: int | None = None,
        provider_error: object | None = None,
    ) -> None:
        super().__init__(message)
        self.model_key = model_key
        self.status_code = status_code
        # The original provider exception or payload, for debugging/escalation.
        # Not part of any stable contract — shape is provider-specific.
        self.provider_error = provider_error

    @property
    def retryable(self) -> bool:
        """Derived convenience: ``True`` unless ``terminal``. Prefer ``category``
        for dispatch — a ``bool`` cannot distinguish *defer* (backpressure) from
        *retry now* (transient)."""
        return self.category != "terminal"


class RateLimitError(AdapterError):
    """Rate limited or quota exhausted (typically HTTP 429).

    Backpressure: the model is healthy, just throttled. Defer to a rate limiter;
    do not retry now and do not record a breaker failure.
    """

    category: ErrorCategory = "backpressure"

    def __init__(
        self,
        message: str = "",
        *,
        retry_after: float | None = None,
        model_key: str | None = None,
        status_code: int | None = None,
        provider_error: object | None = None,
    ) -> None:
        super().__init__(
            message,
            model_key=model_key,
            status_code=status_code,
            provider_error=provider_error,
        )
        # Seconds to wait before retrying, if the provider told us (Retry-After).
        self.retry_after = retry_after


class AuthenticationError(AdapterError):
    """Invalid, expired, or missing credentials (401/403). Terminal."""

    category: ErrorCategory = "terminal"


class AdapterTimeoutError(AdapterError):
    """The request timed out (connect or read). Transient — retry / fail over.

    Named ``AdapterTimeoutError`` (not ``TimeoutError``) to avoid shadowing the
    builtin in consumers' namespaces.
    """

    category: ErrorCategory = "transient"


class TransientError(AdapterError):
    """Transient upstream failure — 5xx, connection reset, overloaded. Transient."""

    category: ErrorCategory = "transient"


class ContentFilterError(AdapterError):
    """Provider refused on content policy. Terminal — same input, same refusal."""

    category: ErrorCategory = "terminal"


class ContextLengthError(AdapterError):
    """Input (+ requested ``max_tokens``) exceeds the model's context window. Terminal."""

    category: ErrorCategory = "terminal"


class BadRequestError(AdapterError):
    """Malformed or invalid request (400) — bad params, unsupported feature. Terminal."""

    category: ErrorCategory = "terminal"


class ProviderError(AdapterError):
    """An unexpected provider failure not covered above. Terminal by default."""

    category: ErrorCategory = "terminal"
