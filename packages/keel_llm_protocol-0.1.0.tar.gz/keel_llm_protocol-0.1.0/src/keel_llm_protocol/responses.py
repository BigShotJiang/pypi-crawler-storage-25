"""Standard result types every adapter returns — uniform across providers."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal

from keel_llm_protocol.tools import ToolCall

__all__ = ["AdapterResponse", "FinishReason", "HealthStatus", "StreamChunk", "Usage"]

# Why generation stopped. Normalized across providers so callers can distinguish
# a clean stop from truncation (length) from a content-policy halt.
# "unknown" is REQUIRED: an adapter must map an unrecognized provider stop reason
# to "unknown", never silently to "stop" — a missing mapping must stay visible,
# not masquerade as a clean completion (no-silent-degradation contract).
FinishReason = Literal[
    "stop", "length", "tool_calls", "content_filter", "error", "unknown"
]


@dataclass
class Usage:
    """Token (and optional cost) accounting for one call."""

    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float | None = None

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens


@dataclass
class AdapterResponse:
    """The complete result of a non-streaming ``generate``."""

    text: str
    model_key: str
    model_id: str
    finish_reason: FinishReason = "stop"
    usage: Usage = field(default_factory=Usage)
    tool_calls: list[ToolCall] = field(default_factory=list)
    latency_ms: int = 0
    # Runtime honored-signal for a requested `response_format` (no-silent-degradation):
    #   None  — no structured output was requested (not applicable)
    #   True  — requested AND the adapter applied it
    #   False — requested but the provider/adapter does not honor it (degraded to
    #           best-effort text). The consumer SEES the degradation instead of
    #           trusting output that was never constrained.
    structured_output_honored: bool | None = None
    # Provider-specific raw payload — escape hatch, NOT part of the stable contract.
    raw_response: dict[str, Any] | None = None


@dataclass
class StreamChunk:
    """One streamed delta. ``finish_reason`` and ``usage`` typically appear only
    on the final chunk."""

    delta: str = ""
    finish_reason: FinishReason | None = None
    usage: Usage | None = None


@dataclass
class HealthStatus:
    """Result of an adapter's ``health_check`` — credential + endpoint reachability."""

    model_key: str
    healthy: bool
    latency_ms: int = 0
    error: str = ""
