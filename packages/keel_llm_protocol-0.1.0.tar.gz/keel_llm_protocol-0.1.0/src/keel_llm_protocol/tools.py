"""Tool / function-calling types.

The protocol *describes* a tool the model may call and a call the model requests.
It never executes a tool, parses arguments, or runs an agentic loop — that is the
consumer's baseplate (ADR-0004 Tenet 3). These are types only.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal

__all__ = ["ToolCall", "ToolChoice", "ToolSpec"]

# How the model should choose tools. Pass a tool *name* (str) to force a specific one.
ToolChoice = Literal["auto", "none", "required"]


@dataclass
class ToolSpec:
    """A tool the model may call.

    ``parameters`` is a JSON Schema object describing the tool's arguments —
    the same shape every major provider accepts.
    """

    name: str
    description: str
    parameters: dict[str, Any]


@dataclass
class ToolCall:
    """A tool invocation the model requested.

    ``arguments`` is a JSON string exactly as the model produced it. The consumer
    parses and dispatches it — the protocol deliberately does neither.
    """

    id: str
    name: str
    arguments: str
