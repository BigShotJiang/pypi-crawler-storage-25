"""The ``ModelAdapter`` Protocol family — the vendor-neutral interface.

**Composable.** Implement ``ModelAdapter`` for the core; add
``StreamingModelAdapter`` or ``ToolCallingModelAdapter`` only if your backend
supports those. Consumers type against the capability they actually need, so a
plain text model and a streaming tool-using model both fit cleanly.

**Strictly an interface.** These describe the *shape* of a call and the *type* of
a result. They never orchestrate, retry, route, buffer, or hold state — that is
the consumer's baseplate (ADR-0004 Tenet 3). If it makes a decision or holds
state, it does not belong here.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass
from typing import Any, Literal, Protocol, runtime_checkable

from keel_llm_protocol.messages import Message
from keel_llm_protocol.responses import AdapterResponse, HealthStatus, StreamChunk
from keel_llm_protocol.tools import ToolChoice, ToolSpec

__all__ = [
    "Capability",
    "ModelAdapter",
    "ResponseFormat",
    "StreamingModelAdapter",
    "ToolCallingModelAdapter",
]

# Optional features whose support varies by provider/endpoint. An adapter
# declares which it *honors* via ``ModelAdapter.capabilities`` so a consumer can
# route BEFORE a call (e.g. send schema-critical work only to adapters that
# honor "json_schema") rather than discover a silently-ignored request after.
# Routing is the consumer's baseplate; the protocol only *exposes* the capability.
Capability = Literal["streaming", "tools", "json_object", "json_schema"]


@dataclass
class ResponseFormat:
    """Requested output format.

    ``type="json_schema"`` with a ``json_schema`` (a JSON Schema object) requests
    schema-constrained structured output where the provider supports it. Check
    ``adapter.capabilities`` first — a requested format an adapter does not honor
    must surface via ``AdapterResponse.structured_output_honored=False``, never be
    silently ignored.
    """

    type: Literal["text", "json_object", "json_schema"] = "text"
    json_schema: dict[str, Any] | None = None


@runtime_checkable
class ModelAdapter(Protocol):
    """The core every adapter implements."""

    @property
    def model_key(self) -> str:
        """Stable handle the application uses for this model (e.g. ``"groq:llama-3.3-70b"``)."""
        ...

    @property
    def capabilities(self) -> frozenset[Capability]:
        """The optional features this adapter *honors* (see :data:`Capability`).

        Lets a consumer route before a call instead of discovering a silently
        ignored request afterward. Capability varies by endpoint/model, so it is
        an instance property, not a class fact.
        """
        ...

    async def generate(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        """Produce a complete response for ``messages``.

        Raises a ``keel_llm_protocol.errors.AdapterError`` subclass on failure
        (the caller inspects the type / ``retryable`` rather than parsing strings).
        """
        ...

    async def health_check(self) -> HealthStatus:
        """Verify credentials and endpoint availability."""
        ...


@runtime_checkable
class StreamingModelAdapter(ModelAdapter, Protocol):
    """A ``ModelAdapter`` that can stream tokens."""

    def stream(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
    ) -> AsyncIterator[StreamChunk]:
        """Stream the response as deltas. Yields ``StreamChunk``s; the consumer
        owns reassembly (the protocol does not buffer)."""
        ...


@runtime_checkable
class ToolCallingModelAdapter(ModelAdapter, Protocol):
    """A ``ModelAdapter`` that supports tool / function calling."""

    async def generate_with_tools(
        self,
        messages: Sequence[Message],
        tools: Sequence[ToolSpec],
        *,
        tool_choice: ToolChoice | str = "auto",
        temperature: float | None = None,
        max_tokens: int | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        """Generate with tools available. The returned ``AdapterResponse.tool_calls``
        carries any calls the model requested; the consumer executes them (the
        protocol never does)."""
        ...
