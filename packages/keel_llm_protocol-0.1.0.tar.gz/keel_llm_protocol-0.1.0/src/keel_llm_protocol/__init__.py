"""keel-llm-protocol — the vendor-neutral LLM adapter standard (the "JDBC of LLMs").

A small, zero-dependency interface any LLM adapter implements, plus the standard
types adapters exchange. Anything that speaks ``keel-llm-protocol`` drives any
conforming adapter without knowing the provider.

What makes it a *standard* rather than one product's interface:

- **A standardized error taxonomy** (``errors``) — every adapter raises typed,
  ``retryable``-tagged failures, so circuit breakers / retries / failover act on
  uniform types instead of parsing provider strings. (A 429 is ``RateLimitError``
  everywhere; reliability logic stops guessing.)
- **Composable capability protocols** — ``ModelAdapter`` is the minimal core;
  ``StreamingModelAdapter`` and ``ToolCallingModelAdapter`` layer on streaming and
  tools only where a backend supports them.
- **Normalized results** — ``Usage``, ``FinishReason``, ``ToolCall`` are uniform
  across providers.
- **No silent degradation** — a requested guarantee must never quietly become
  best-effort. Support that varies is *introspectable up front*
  (``ModelAdapter.capabilities``) and *flagged at runtime*
  (``AdapterResponse.structured_output_honored``; an unmapped stop reason becomes
  ``FinishReason`` ``"unknown"``, never ``"stop"``). An ignored feature is always
  visible, never laundered into apparent success.

The package is strictly an interface: it describes call shapes and result types
and never orchestrates, executes, routes, or holds state.
"""

from __future__ import annotations

from keel_llm_protocol.errors import (
    AdapterError,
    AdapterTimeoutError,
    AuthenticationError,
    BadRequestError,
    ContentFilterError,
    ContextLengthError,
    ErrorCategory,
    ProviderError,
    RateLimitError,
    TransientError,
)
from keel_llm_protocol.messages import Message, Role, assistant, system, tool, user
from keel_llm_protocol.protocol import (
    Capability,
    ModelAdapter,
    ResponseFormat,
    StreamingModelAdapter,
    ToolCallingModelAdapter,
)
from keel_llm_protocol.responses import (
    AdapterResponse,
    FinishReason,
    HealthStatus,
    StreamChunk,
    Usage,
)
from keel_llm_protocol.tools import ToolCall, ToolChoice, ToolSpec

__all__ = [
    # protocols
    "ModelAdapter",
    "StreamingModelAdapter",
    "ToolCallingModelAdapter",
    "ResponseFormat",
    "Capability",
    # messages
    "Message",
    "Role",
    "system",
    "user",
    "assistant",
    "tool",
    # responses
    "AdapterResponse",
    "StreamChunk",
    "Usage",
    "FinishReason",
    "HealthStatus",
    # tools
    "ToolSpec",
    "ToolCall",
    "ToolChoice",
    # errors
    "AdapterError",
    "ErrorCategory",
    "RateLimitError",
    "AuthenticationError",
    "AdapterTimeoutError",
    "TransientError",
    "ContentFilterError",
    "ContextLengthError",
    "BadRequestError",
    "ProviderError",
]
