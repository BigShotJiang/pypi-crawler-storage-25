"""Tests for keel-llm-protocol — the interface, the types, and the error taxonomy."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Sequence

from keel_llm_protocol import (
    AdapterError,
    AdapterResponse,
    AdapterTimeoutError,
    Capability,
    AuthenticationError,
    BadRequestError,
    ContentFilterError,
    ContextLengthError,
    HealthStatus,
    Message,
    ModelAdapter,
    ProviderError,
    RateLimitError,
    ResponseFormat,
    StreamChunk,
    StreamingModelAdapter,
    ToolCall,
    ToolCallingModelAdapter,
    ToolSpec,
    TransientError,
    Usage,
    assistant,
    system,
    tool,
    user,
)


# --------------------------------------------------------------------------- #
# Reference conforming adapters (these are also the structural-typing proof)
# --------------------------------------------------------------------------- #


class CoreAdapter:
    @property
    def model_key(self) -> str:
        return "fake:core"

    @property
    def capabilities(self) -> frozenset[str]:
        return frozenset({"json_object"})

    async def generate(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        return AdapterResponse(
            text="hello",
            model_key=self.model_key,
            model_id="fake-core-1",
            usage=Usage(input_tokens=3, output_tokens=1),
        )

    async def health_check(self) -> HealthStatus:
        return HealthStatus(model_key=self.model_key, healthy=True, latency_ms=5)


class StreamingAdapter(CoreAdapter):
    async def stream(
        self,
        messages: Sequence[Message],
        *,
        temperature: float | None = None,
        max_tokens: int | None = None,
        stop: Sequence[str] | None = None,
    ) -> AsyncIterator[StreamChunk]:
        yield StreamChunk(delta="hel")
        yield StreamChunk(delta="lo")
        yield StreamChunk(finish_reason="stop", usage=Usage(input_tokens=3, output_tokens=1))


class ToolAdapter(CoreAdapter):
    async def generate_with_tools(
        self,
        messages: Sequence[Message],
        tools: Sequence[ToolSpec],
        *,
        tool_choice: str = "auto",
        temperature: float | None = None,
        max_tokens: int | None = None,
        response_format: ResponseFormat | None = None,
    ) -> AdapterResponse:
        return AdapterResponse(
            text="",
            model_key=self.model_key,
            model_id="fake-core-1",
            finish_reason="tool_calls",
            tool_calls=[ToolCall(id="c1", name=tools[0].name, arguments='{"x": 1}')],
        )


# --------------------------------------------------------------------------- #
# Structural conformance (@runtime_checkable)
# --------------------------------------------------------------------------- #


def test_core_adapter_conforms() -> None:
    a: ModelAdapter = CoreAdapter()
    assert isinstance(a, ModelAdapter)


def test_streaming_adapter_conforms_to_both() -> None:
    a = StreamingAdapter()
    assert isinstance(a, ModelAdapter)
    assert isinstance(a, StreamingModelAdapter)


def test_tool_adapter_conforms() -> None:
    a = ToolAdapter()
    assert isinstance(a, ModelAdapter)
    assert isinstance(a, ToolCallingModelAdapter)


def test_core_adapter_is_not_streaming_or_tools() -> None:
    a = CoreAdapter()
    assert not isinstance(a, StreamingModelAdapter)
    assert not isinstance(a, ToolCallingModelAdapter)


def test_non_adapter_does_not_conform() -> None:
    class NotAnAdapter:
        pass

    assert not isinstance(NotAnAdapter(), ModelAdapter)


# --------------------------------------------------------------------------- #
# Behavior of the conforming adapters
# --------------------------------------------------------------------------- #


def test_generate_returns_response() -> None:
    resp = asyncio.run(CoreAdapter().generate([user("hi")]))
    assert resp.text == "hello"
    assert resp.usage.total_tokens == 4
    assert resp.finish_reason == "stop"
    assert resp.tool_calls == []


def test_stream_yields_chunks() -> None:
    async def collect() -> list[StreamChunk]:
        return [c async for c in StreamingAdapter().stream([user("hi")])]

    chunks = asyncio.run(collect())
    assert "".join(c.delta for c in chunks) == "hello"
    assert chunks[-1].finish_reason == "stop"
    assert chunks[-1].usage is not None
    assert chunks[-1].usage.total_tokens == 4


def test_generate_with_tools_returns_tool_call() -> None:
    spec = ToolSpec(name="get_weather", description="...", parameters={"type": "object"})
    resp = asyncio.run(ToolAdapter().generate_with_tools([user("weather?")], [spec]))
    assert resp.finish_reason == "tool_calls"
    assert resp.tool_calls[0].name == "get_weather"
    assert resp.tool_calls[0].arguments == '{"x": 1}'


# --------------------------------------------------------------------------- #
# Message helpers
# --------------------------------------------------------------------------- #


def test_message_constructors() -> None:
    assert system("s") == Message("system", "s")
    assert user("u") == Message("user", "u")
    assert assistant("a") == Message("assistant", "a")
    t = tool("result", tool_call_id="c1", name="get_weather")
    assert t.role == "tool"
    assert t.tool_call_id == "c1"
    assert t.name == "get_weather"


# --------------------------------------------------------------------------- #
# Types: Usage / ResponseFormat
# --------------------------------------------------------------------------- #


def test_usage_total_tokens() -> None:
    assert Usage(input_tokens=10, output_tokens=5).total_tokens == 15
    assert Usage().total_tokens == 0


def test_response_format_defaults() -> None:
    assert ResponseFormat().type == "text"
    rf = ResponseFormat(type="json_schema", json_schema={"type": "object"})
    assert rf.json_schema == {"type": "object"}


# --------------------------------------------------------------------------- #
# Error taxonomy — the reliability core
# --------------------------------------------------------------------------- #


def test_all_errors_subclass_adapter_error() -> None:
    for cls in (
        RateLimitError,
        AuthenticationError,
        AdapterTimeoutError,
        TransientError,
        ContentFilterError,
        ContextLengthError,
        BadRequestError,
        ProviderError,
    ):
        assert issubclass(cls, AdapterError)


def test_category_drives_three_actions() -> None:
    # The single source of truth: three categories, one per reliability action.
    assert RateLimitError().category == "backpressure"  # defer
    assert TransientError().category == "transient"  # retry / fail over
    assert AdapterTimeoutError().category == "transient"
    for cls in (
        AuthenticationError,
        ContentFilterError,
        ContextLengthError,
        BadRequestError,
        ProviderError,
    ):
        assert cls().category == "terminal"  # fail fast
    assert AdapterError().category == "terminal"  # unknown -> safe default


def test_retryable_is_derived_from_category() -> None:
    # retryable is a convenience: True unless terminal. category is the real axis.
    assert RateLimitError().retryable is True  # backpressure != terminal
    assert TransientError().retryable is True
    assert AuthenticationError().retryable is False
    assert AdapterError().retryable is False


def test_retryable_flags() -> None:
    # Retryable: backpressure + transient + timeout.
    assert RateLimitError().retryable is True
    assert TransientError().retryable is True
    assert AdapterTimeoutError().retryable is True
    # Not retryable: same input → same failure.
    assert AuthenticationError().retryable is False
    assert ContentFilterError().retryable is False
    assert ContextLengthError().retryable is False
    assert BadRequestError().retryable is False
    assert ProviderError().retryable is False
    assert AdapterError().retryable is False


def test_rate_limit_carries_retry_after_and_metadata() -> None:
    err = RateLimitError(
        "throttled", retry_after=2.5, model_key="groq:llama", status_code=429
    )
    assert err.retryable is True
    assert err.retry_after == 2.5
    assert err.model_key == "groq:llama"
    assert err.status_code == 429


def test_adapter_error_metadata() -> None:
    cause = ValueError("boom")
    err = TransientError("upstream 503", model_key="m", status_code=503, provider_error=cause)
    assert err.model_key == "m"
    assert err.status_code == 503
    assert err.provider_error is cause


def test_errors_are_raisable_and_catchable_by_base() -> None:
    try:
        raise RateLimitError("x")
    except AdapterError as e:  # uniform catch across providers
        assert isinstance(e, RateLimitError)
        assert e.retryable is True


# --------------------------------------------------------------------------- #
# No-silent-degradation contract
# --------------------------------------------------------------------------- #


def test_adapter_declares_capabilities() -> None:
    caps = CoreAdapter().capabilities
    assert isinstance(caps, frozenset)
    assert "json_object" in caps


def test_capability_introspection_lets_consumer_route() -> None:
    a = CoreAdapter()
    # The consumer can decide BEFORE calling whether to trust schema output.
    wants: Capability = "json_schema"
    assert wants not in a.capabilities  # -> route elsewhere / use tolerant parsing


def test_finish_reason_unknown_is_valid() -> None:
    # An adapter must be able to surface an unmapped stop reason as "unknown".
    resp = AdapterResponse(text="", model_key="m", model_id="m", finish_reason="unknown")
    assert resp.finish_reason == "unknown"


def test_structured_output_honored_tristate() -> None:
    base = AdapterResponse(text="", model_key="m", model_id="m")
    assert base.structured_output_honored is None  # not requested
    assert AdapterResponse(
        text="", model_key="m", model_id="m", structured_output_honored=True
    ).structured_output_honored is True
    assert AdapterResponse(
        text="", model_key="m", model_id="m", structured_output_honored=False
    ).structured_output_honored is False
