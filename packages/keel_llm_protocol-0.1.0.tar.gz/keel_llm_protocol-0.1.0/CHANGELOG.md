# Changelog

All notable changes to `keel-llm-protocol` are documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/). This package
is in `0.x` — breaking changes may land at minor bumps and are noted under
**Changed**. An interface is most valuable when stable, so the surface is kept
minimal-but-complete. Pin exact versions; read this file before upgrading.

## [Unreleased]

## [0.1.0] - 2026-05-22

### Added

- **Composable adapter protocols** (`@runtime_checkable`):
  - `ModelAdapter` — core: `model_key`, `generate(messages, ...) -> AdapterResponse`,
    `health_check() -> HealthStatus`.
  - `StreamingModelAdapter` — adds `stream(...) -> AsyncIterator[StreamChunk]`.
  - `ToolCallingModelAdapter` — adds `generate_with_tools(messages, tools, ...)`.
- **Standardized error taxonomy** (`keel_llm_protocol.errors`): `AdapterError` base
  plus `RateLimitError` (carries `retry_after`), `AuthenticationError`,
  `AdapterTimeoutError`, `TransientError`, `ContentFilterError`,
  `ContextLengthError`, `BadRequestError`, `ProviderError`. Each carries
  `model_key`, `status_code`, `provider_error` so reliability logic acts on
  types, not provider strings.
- **`category: ErrorCategory`** (`"backpressure"` / `"transient"` / `"terminal"`) —
  the single source of truth for *how to react*, because there are three actions
  (defer / retry-now / fail-fast), not two. `retryable` is kept as a derived
  convenience (`category != "terminal"`) but cannot express the defer-vs-retry-now
  distinction that is the core reliability win. Grounded in LLMCouncil's PR #77.
- **Standard types**: `Message` (+ `system`/`user`/`assistant`/`tool` helpers),
  `AdapterResponse`, `StreamChunk`, `Usage` (with `total_tokens`), `HealthStatus`,
  `ToolSpec`, `ToolCall`, `ResponseFormat`, and the `Role` / `FinishReason` /
  `ToolChoice` / `Capability` literals.
- **No-silent-degradation contract** (a stated property of the standard): a
  requested guarantee must never quietly become best-effort.
  - `ModelAdapter.capabilities -> frozenset[Capability]` — declares which optional
    features (`streaming` / `tools` / `json_object` / `json_schema`) an adapter
    *honors*, so a consumer routes **before** a call instead of discovering a
    silently ignored request afterward.
  - `AdapterResponse.structured_output_honored: bool | None` — runtime signal that
    a requested `response_format` was applied (`True`), degraded to best-effort
    (`False`), or not requested (`None`).
  - `FinishReason` includes `"unknown"` — an adapter maps an unrecognized provider
    stop reason to `"unknown"`, never silently to `"stop"`.
- PEP 561 `py.typed`; `mypy --strict` clean; zero runtime dependencies.
- **"Consuming the taxonomy" guidance** (README): how reliability machinery should
  *act* on typed errors — `RateLimitError` is backpressure (defer to limiter, don't
  trip the breaker), other `retryable` errors retry/fail over, non-retryable fail
  fast. Pattern contributed by the LLMCouncil product team; measured to move a
  throttled model from 3/10 → 10/10 availability in a real fan-out.

### Notes

- This is a *standard*: it describes call shapes and result types and never
  orchestrates, executes tools, routes failover, buffers streams, or holds state
  (that is the consumer's baseplate). Grounded by two reference implementations —
  `keel-llm-adapter-openai` (OpenAI-compatible family) and
  `keel-llm-adapter-anthropic` (a deliberately divergent API, validating that the
  standard generalizes without changes).
