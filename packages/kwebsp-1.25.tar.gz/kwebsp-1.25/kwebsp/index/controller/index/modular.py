from .common import *
kwebsuserinfopath=os.path.split(os.path.realpath(__file__))[0]+"/common/file/"
dqpath=os.path.split(os.path.realpath(__file__))[0]
class modular:
    def index():
        return response.tpl(dqpath+'/tpl/modular/index.html',absolutelypath=True)
    if not os.path.exists(kwebsuserinfopath):
        os.makedirs(kwebsuserinfopath)
    def kwebssebduser():
        data=request.get_json()
        res=requests.post(config.domain['kcwebsapi']+"/pub/sebduser",data=data)
        res=json_decode(res.text)
        return response.json(res)
    def kwebsreg():
        data=request.get_json()
        res=requests.post(config.domain['kcwebsapi']+"/pub/reg",data=data)
        res=json_decode(res.text)
        return response.json(res)
    def banduser():
        data=request.get_json()
        timestamp=times()
        sign=md5(str(data['username'])+str(timestamp)+md5(md5(data['password'])))
        headers={}
        headers['username']=data['username']
        headers['timestamp']=str(timestamp)
        headers['sign']=sign
        res=requests.get(config.domain['kcwebsapi']+"/user/userinfo",headers=headers)
        res=json_decode(res.text)
        if(res['code']==0):
            kwebsuserinfo=res['data']
            kwebsuserinfo['username']=data['username']
            kwebsuserinfo['password']=data['password']
            file_set_content(kwebsuserinfopath+str(G.userinfo['id']),json_encode(kwebsuserinfo))
            return successjson()
        else:
            return errorjson(msg=res['msg'])
        
    def modular_list(kw='',pagenow=1):
        res=requests.get(config.domain['kcwebsapi']+"/pub/modular_list",params={
            "kw":kw,"pagenow":pagenow
        })
        res=json_decode(res.text)
        lists=res['data']['lists']
        for k in lists:
            k['status']=0 #0未安装  1已安装  2安装中 3卸载中 4不可以安装
            if os.path.exists("app/"+str(k['name'])):
                k['status']=1
        if os.path.isfile(kwebsuserinfopath+str(G.userinfo['id'])):
            kwebsuserinfo=file_get_content(kwebsuserinfopath+str(G.userinfo['id']))
        else:
            kwebsuserinfo=''
        if kwebsuserinfo:
            res['kwebsuserinfo']=json_decode(kwebsuserinfo)
        else:
            res['kwebsuserinfo']=''
        return response.json(res)

    def uploadmodular():
        "打包模块上传"
        G.setadminlog="打包模块上传模块"
        kwebsuserinfo=file_get_content(kwebsuserinfopath+str(G.userinfo['id']))
        if kwebsuserinfo:
            kwebsuserinfo=json_decode(kwebsuserinfo)
            data=request.get_json()
            server=create("app",data['name'])
            data=server.packmodular()
            if data[0]:
                data=server.uploadmodular(kwebsuserinfo['username'],kwebsuserinfo['password'])
                if data[0]:
                    return successjson()
                else:
                    return errorjson(msg=data[1])
            return errorjson(msg=data[1])
        else:
            return errorjson("请先配置kwebs账号")
    def installmodular():
        "安装模块"
        G.setadminlog="安装模块"
        arr=request.get_json()
        server=create("app",arr['name'])
        data=server.installmodular(arr['token'])
        time.sleep(1)
        if data[0]:
            # model_intapp_menu.add(title=arr['title'],icon=arr['icon'],url="/"+arr['name'])
            return successjson()
        else:
            return errorjson(msg=data[1])
    def uninstallmodular():
        "卸载模块"
        G.setadminlog="卸载模块"
        arr=request.get_json()
        server=create("app",arr['name'])
        data=server.uninstallmodular()
        time.sleep(1)
        if data[0]:
            model_intapp_menu.delete(title=arr['title'])
            return successjson()
        else:
            return errorjson(msg=data[1])

