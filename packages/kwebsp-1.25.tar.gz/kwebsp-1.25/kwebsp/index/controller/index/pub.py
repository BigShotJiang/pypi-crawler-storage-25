from .common import *
if not config.app['cli']:
    if os.name == 'nt':
        system_start.insert_Boot_up(cmd='start /b kwebsp /index/index/pub/clistartplan',types='kwebsp',name='内置计划服务',icon='/index/index/pub/icon?text=plan')
    elif 'Linux' in get_sysinfo()['platform']:
        system_start.insert_Boot_up(cmd='kwebsp /index/index/pub/clistartplan -d',types='kwebsp',name='内置计划服务',icon='/index/index/pub/icon?text=plan')
    else:
        raise Exception('不支持该操作系统')
dqpath=os.path.split(os.path.realpath(__file__))[0]
def before_request():
    pass
dqpath=os.path.split(os.path.realpath(__file__))[0]
def PIL_drawlist(x,y,w,h):
    return [x,y,x+w-1,y+h-1]

def generate_image_with_text(texts,bg_color='',font_color='',bg_colors='',cl=''):
    from PIL import Image, ImageDraw, ImageFont
    import io
    if not texts:
        texts=''
    if not bg_color:
        if texts in ['文件夹']:
            bg_color='245,187,80'
        elif texts in ['kwebsp','kwebs','kunapi']:
            bg_color='255,71,26'
            font_color='255,255,255'
        elif texts in ['py','python']:
            bg_color='89,124,179'
            bg_colors='255,255,255'
            font_color='221,158,90'
        elif texts in ['rdb','redis']:
            bg_color='229,31,0'
            bg_colors='0,0,0'
            font_color='255,255,255'
        elif texts in ['pdf']:
            bg_color='207,20,7'
        else:
            if re.search(re.compile('[\u4e00-\u9fa5]'), texts):
                bg_color='207,20,7'
                font_color='255,255,255'
            else:
                bg_color='240,240,241'
    # if texts and texts[0:2] in ['fa']:
    #     filename=kwebsphtmltoimage('http://127.0.0.1:39001/index/index/pub/iconhtml?classstr='+texts+'&color='+bg_colors+'&size=128px')
    #     f=open(filename,"rb")
    #     body=f.read()
    #     f.close()
    #     return body
    # print('texts',texts)
    if texts and texts.lower() in ['zip','rar','tgz','gz','ai','?','？']:
        if texts in ['tgz','gz']:
            texts='zip'
        elif texts in ['?','？']:
            texts='wh'
        filename=dqpath+"/common/file/image/"+(texts.lower())+".png"
        if texts.lower() in ['ai','wh']:
            filename=dqpath+"/common/file/image/"+(texts.lower())+".gif"
        f=open(filename,"rb")
        body=f.read()
        f.close()
        return body
    elif texts and texts.lower() in ['文件夹','wjj','folder']:
        filename=dqpath+"/common/file/image/folder.gif"
        f=open(filename,"rb")
        body=f.read()
        f.close()
        return body


    if not cl:
        if re.search(re.compile('[\u4e00-\u9fa5]'), texts):
            if len(texts)>=12:
                cl=3
            elif len(texts) >= 4:
                cl=2
            elif len(texts) in [1,2,3,4]:
                cl=1
            else:
                cl=1
        else:
            if len(texts)>=15:
                cl=3
            elif len(texts) >= 8:
                cl=2
            elif len(texts) in [1,2,3,4,5]:
                cl=1
            else:
                cl=2
    else:
        cl=int(cl)
    
    bg_arr=bg_color.split(",")
    bg_color=[]
    for k in bg_arr:
        bg_color.append(int(k))
    bg_color=tuple(bg_color)
    
    if font_color:
        font_color_arr=font_color.split(",")
        font_color=[]
        for k in font_color_arr:
            font_color.append(int(k))
        font_color=tuple(font_color)
    else:
        font_color=[0,0,0]
        if bg_color[0]>150:
            font_color[0]=bg_color[0]-100
        else:
            font_color[0]=bg_color[0]+100
        if bg_color[1]>150:
            font_color[1]=bg_color[1]-100
        else:
            font_color[1]=bg_color[1]+100
        if bg_color[2]>150:
            font_color[2]=bg_color[2]-100
        else:
            font_color[2]=bg_color[2]+100
        font_color=tuple(font_color)
    if not bg_colors:
        bg_colors=list(bg_color)
        if bg_colors[0]>230:
            bg_colors[0]=bg_colors[0]-20
        else:
            bg_colors[0]=bg_colors[0]+20
        if bg_colors[1]>230:
            bg_colors[1]=bg_colors[1]-20
        else:
            bg_colors[1]=bg_colors[1]+20
        if bg_colors[2]>230:
            bg_colors[2]=bg_colors[2]-20
        else:
            bg_colors[2]=bg_colors[2]+20
        bg_colors=tuple(bg_colors)
    else:
        bg_colors_arr=bg_colors.split(",")
        bg_colors=[]
        for k in bg_colors_arr:
            bg_colors.append(int(k))
        bg_colors=tuple(bg_colors)

    if cl==1:
        if re.search(re.compile('[\u4e00-\u9fa5]'), texts):
            text=[texts[0:4].upper()]
        else:
            text=[texts[0:5].upper()]
    elif cl==2:
        if re.search(re.compile('[\u4e00-\u9fa5]'), texts):
            if len(texts)>=6:
                text=[texts[0:3].upper()]
                if texts[3:6]:
                    text.append(texts[3:6].upper())
            else:
                text=[texts[0:2].upper()]
                if texts[2:4]:
                    text.append(texts[2:4].upper())
        else:
            if len(texts)>=10:
                text=[texts[0:5].upper()]
                if texts[5:10]:
                    text.append(texts[5:10].upper())
            elif len(texts)>=8:
                text=[texts[0:4].upper()]
                if texts[4:8]:
                    text.append(texts[4:8].upper())
            else:
                text=[texts[0:3].upper()]
                if texts[3:6]:
                    text.append(texts[4:6].upper())
    elif cl==3:
        if re.search(re.compile('[\u4e00-\u9fa5]'), texts):
            text=[texts[0:4].upper()]
            if texts[4:8]:
                text.append(texts[4:8].upper())
            if texts[8:12]:
                text.append(texts[8:12].upper())
        else:
            text=[texts[0:5].upper()]
            if texts[5:10]:
                text.append(texts[5:10].upper())
            if texts[10:15]:
                text.append(texts[10:15].upper())
        


    image = Image.new('RGBA',(128,128), color = (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    current_directory = dqpath+"/common/file/fzxst.TTF"
    
    if texts in ['文件夹','文件管理']:
        draw.polygon([(40, 0), (40, 20), (80, 20)], fill=bg_color) #绘制三角形
        draw.rectangle([10, 22, 123, 123], fill=bg_color)  # 绘制矩形
        draw.ellipse([0, 0, 20, 20], fill=bg_color)# 绘制圆形
        draw.ellipse([0, 108, 20, 108+20], fill=bg_color)# 绘制圆形
        draw.ellipse([108, 108, 108+20, 108+20], fill=bg_color)# 绘制圆形
      
        draw.rectangle([10, 0, 40, 20], fill=bg_color)
        draw.rectangle([0, 10, 10, 20], fill=bg_color)
        draw.rectangle([0, 22, 10, 118], fill=bg_color)
        draw.rectangle([10, 118, 118, 128], fill=bg_color)
        draw.rectangle([108, 22, 128, 118], fill=bg_color)
        if texts=='文件管理':
            draw.rectangle([50, 0, 128, 1], fill=bg_color)
            draw.rectangle([60, 5, 128, 6], fill=bg_color)
            draw.rectangle([70, 10, 128, 11], fill=bg_color)
            draw.rectangle([80, 15, 128, 16], fill=bg_color)
        else:
            draw.ellipse([126, 0, 126+2, 0+2], fill=bg_color)# 绘制圆形
            draw.ellipse([116, 0, 116+2, 0+2], fill=bg_color)
            draw.ellipse([106, 0, 106+2, 0+2], fill=bg_color)
            draw.ellipse([96, 0, 96+2, 0+2], fill=bg_color)
            draw.ellipse([86, 0, 86+2, 0+2], fill=bg_color)
            draw.ellipse([76, 0, 76+2, 0+2], fill=bg_color)
            draw.ellipse([66, 0, 66+2, 0+2], fill=bg_color)
            draw.ellipse([56, 0, 56+2, 0+2], fill=bg_color)
            draw.ellipse([46, 0, 46+2, 0+2], fill=bg_color)
    elif texts in ['用户']:
        draw.rectangle(PIL_drawlist(0,0,128,128), fill=bg_color)  # 绘制矩形
        draw.ellipse(PIL_drawlist(49,18,30,30), fill=bg_colors)# 绘制用户头像
        draw.rectangle(PIL_drawlist(55,42,20,15), fill=bg_colors) #绘制脖子
        draw.rectangle(PIL_drawlist(41,58,50,50), fill=bg_colors) #绘制身体
    elif texts in ['电灯泡','灯泡','电灯','灯']:
        draw.rectangle(PIL_drawlist(0,0,128,128), fill=bg_colors)  # 绘制矩形
        draw.ellipse(PIL_drawlist(35,15,60,60), fill=bg_colors)# 绘制用户头像
        draw.rectangle(PIL_drawlist(49,70,35,35), fill=bg_colors) #绘制脖子
    elif texts in ['home','首页']:
        draw.polygon([(64, 0), (0, 50), (128, 50)], fill=bg_colors) #绘制三角形
        draw.rectangle(PIL_drawlist(0,50,128,78), fill=bg_colors) #绘制主体
        draw.rectangle(PIL_drawlist(38,70,20,20), fill=bg_color) #绘制窗户
        draw.rectangle(PIL_drawlist(70,70,20,20), fill=bg_color) #绘制窗户
        font = ImageFont.truetype(current_directory, 14)
        textsize = draw.textlength(text[0], font=font)
        draw.text(((128-textsize)/2,100), text[0], fill=font_color, font=font)
    else:
        if re.search(re.compile('[\u4e00-\u9fa5]'), text[0]):
            draw.rectangle([0, 0, 128, 128], fill=bg_color)  # 绘制矩形
        else:
            draw.polygon([(108, 0), (108, 20), (128, 20)], fill=bg_colors) #绘制三角形
            draw.rectangle([10, 22, 123, 123], fill=bg_color)  # 绘制矩形
            draw.ellipse([0, 0, 20, 20], fill=bg_color)# 绘制圆形
            draw.ellipse([0, 108, 20, 108+20], fill=bg_color)# 绘制圆形
            draw.ellipse([108, 108, 108+20, 108+20], fill=bg_color)# 绘制圆形
            draw.rectangle([10, 0, 106, 20], fill=bg_color)
            draw.rectangle([0, 10, 10, 20], fill=bg_color)
            draw.rectangle([0, 22, 10, 118], fill=bg_color)
            draw.rectangle([10, 118, 118, 128], fill=bg_color)
            draw.rectangle([108, 22, 128, 118], fill=bg_color)
            
            draw.rectangle([15, 26, 80, 30], fill=bg_colors) #(198,196,203)
            draw.rectangle([15, 52, 105, 56], fill=bg_colors)
            draw.rectangle([15, 78, 105, 82], fill=bg_colors)
            draw.rectangle([15, 102, 70, 106], fill=bg_colors)
            draw.rectangle([80, 102, 80+4, 106], fill=bg_colors)
            draw.rectangle([90, 102, 90+4, 106], fill=bg_colors)
            draw.rectangle([100, 102, 100+4, 106], fill=bg_colors)
        if texts not in ['html','css','js','java','shtml','htm']:
            if len(text)==1:
                if text[0] in ['文件夹']:
                    pass
                elif len(text[0])==1:
                    font = ImageFont.truetype(current_directory, 90)
                    textsize = draw.textlength(text[0], font=font)
                    draw.text(((128-textsize)/2,20), text[0], fill=font_color, font=font)
                elif len(text[0])==2:
                    font = ImageFont.truetype(current_directory, 50)
                    textsize = draw.textlength(text[0], font=font)
                    draw.text(((128-textsize)/2,35), text[0], fill=font_color, font=font)
                elif len(text[0])==3:
                    font = ImageFont.truetype(current_directory, 38)
                    textsize = draw.textlength(text[0], font=font)
                    draw.text(((128-textsize)/2,48), text[0], fill=font_color, font=font)
                elif len(text[0])==4:
                    font = ImageFont.truetype(current_directory, 30)
                    textsize = draw.textlength(text[0], font=font)
                    draw.text(((128-textsize)/2,50), text[0], fill=font_color, font=font)
                elif len(text[0])==5:
                    font = ImageFont.truetype(current_directory, 30)
                    textsize = draw.textlength(text[0], font=font)
                    draw.text(((128-textsize)/2,50), text[0], fill=font_color, font=font)
            elif len(text)==2:
                if len(text[0])==2:
                    font = ImageFont.truetype(current_directory, 50)
                    textsize1 = draw.textlength(text[0], font=font)
                    textsize2 = draw.textlength(text[1], font=font)
                    draw.text(((128-textsize1)/2,10), text[0], fill=font_color, font=font)
                    draw.text(((128-textsize2)/2,64), text[1], fill=font_color, font=font)
                elif len(text[0]) in [3,4]:
                    font = ImageFont.truetype(current_directory, 38)
                    textsize1 = draw.textlength(text[0], font=font)
                    textsize2 = draw.textlength(text[1], font=font)
                    draw.text(((128-textsize1)/2,20), text[0], fill=font_color, font=font)
                    draw.text(((128-textsize2)/2,66), text[1], fill=font_color, font=font)
                else:
                    font = ImageFont.truetype(current_directory, 28)
                    textsize1 = draw.textlength(text[0], font=font)
                    textsize2 = draw.textlength(text[1], font=font)
                    draw.text(((128-textsize1)/2,25), text[0], fill=font_color, font=font)
                    draw.text(((128-textsize2)/2,71), text[1], fill=font_color, font=font)
            elif len(text)==3:
                font = ImageFont.truetype(current_directory, 25)
                textsize1 = draw.textlength(text[0], font=font)
                textsize2 = draw.textlength(text[1], font=font)
                textsize3 = draw.textlength(text[2], font=font)
                draw.text(((128-textsize1)/2,10), text[0], fill=font_color, font=font)
                draw.text(((128-textsize2)/2,50), text[1], fill=font_color, font=font)
                draw.text(((128-textsize3)/2,90), text[2], fill=font_color, font=font)

    # 将图像转换为字节流
    img_byte_arr = io.BytesIO()
    image.save(img_byte_arr, format='PNG')
    img_byte_arr = img_byte_arr.getvalue()  # 获取字节流的值
    return img_byte_arr

class pub:
    def icon(texts='',t=''):
        try:
            HTTP_IF_NONE_MATCH=globals.HEADER.GET['HTTP_IF_NONE_MATCH']
        except:
            HTTP_IF_NONE_MATCH=None
        if not HTTP_IF_NONE_MATCH:
            text=request.args.get('text')
            bg_color=request.args.get('bg_color')
            font_color=request.args.get('font_color')
            cl=request.args.get('cl')
            body=generate_image_with_text(texts=text,bg_color=bg_color,font_color=font_color,cl=cl)
        else:
            body=''
        return response.pic(body=body)
    def iconhtml():
        classstr=request.args.get('classstr')
        color=request.args.get('color')
        size=request.args.get('size')
        if not classstr:
            classstr="fa fa-home"
        response.classstr=classstr

        if not color:
            color="#d82222"
        else:
            if ',' in color:
                color="rgba("+color+", 1)"
            else:
                color="#"+color
        response.color=color

        if not size:
            size="128px"
        response.size=size
        return response.tpl(dqpath+'/tpl/pub/iconhtml.html')
    def outlogin():
        account_token=request.args.get("account_token")
        if account_token:
            del_cache(account_token)
        else:
            del_session('userinfo')
        return successjson()
    def get_account_token(username,sign,timestamp,random,types="get_account_token"):
        "获取用户token"
        status,code,msg,account_token=serlogin(username,sign,timestamp,random,types)
        if status:
            return successjson(data={"account_token":account_token},msg=msg)
        else:
            return errorjson(code=-1,msg=msg)
    def login(username,sign,timestamp,random,types="session"):
        "登录"
        G.setadminlog=username+",登录系统"
        status,code,msg,account_token=serlogin(username,sign,timestamp,random,types)
        if status:
            return successjson(data=account_token,msg=msg)
        else:
            return errorjson(code=code,msg=msg)
    def addr():
        return successjson(request.HEADER.Physical_IP())

    def getkwebs():
        config.kwebs['path']=get_kwebs_folder()
        return successjson(config.kwebs)
    
    def checkserver():
        return successjson()
    
    def clistartplan():
        #这里是初始化计划任务 （cli方式运行）
        try:
            serverserverintervals=sqlite("interval",model_intapp_index_path).select()
            if serverserverintervals and (times()-int(serverserverintervals[0]['updtime'])) > 5:
                for serverserverinterval in serverserverintervals:
                        serverserverinterval['updtime']=times()
                        sqlite("interval",model_intapp_index_path).where("id",serverserverinterval['id']).update(serverserverinterval)
                        PLANTASK.plantask(serverserverinterval) #添加计划任务
                while True:
                    time.sleep(100)
        except:
            pass
    def webclosemsg(a1='',a2='',a3='',a4='',a5='',a6='',a7='',a8='',a9='',a10=''):
        format='json'
        if format=='html':
            return '您访问的站点正在维护中，暂时无法访问，请稍后在试'
        elif format=='json':
            return errorjson(code=-1,msg='您访问的站点正在维护中，暂时无法访问，请稍后在试')
    def gitpull():
        "执行git"
        path=request.args.get('path')
        branch=request.args.get('branch') #强制更新指定分支
        title=request.args.get('title')
        taskid=md5(randoms()+str(times()))
        if not title:
            title="git pull，"+path
        if 'Linux' in get_sysinfo()['platform']:
            shell='cd '+path+' && git reset --hard'
            if branch:
                shell+=' origin/'+branch
            shell+=' && git clean -f && git pull'
            kwebsp_news_push(content="进入 Queues",percentage=1)
            Queues.insert(target=PUBLICOther.gitpull,args=(taskid,path,shell),title=title,describes="执行命令："+shell,taskid=taskid,start=10,updtime=times()+1)
        elif 'Window' in get_sysinfo()['platform']:
            shell="git reset --hard"
            if branch:
                shell+=' origin/'+branch
            Queues.insert(target=PUBLICOther.gitpull,args=(taskid,path,shell),title=title,describes="执行命令："+shell,taskid=taskid)
            shell='git clean -f'
            Queues.insert(target=PUBLICOther.gitpull,args=(taskid,path,shell),title=title,describes="执行命令："+shell,taskid=taskid)
            shell='git pull'
            Queues.insert(target=PUBLICOther.gitpull,args=(taskid,path,shell),title=title,describes="执行命令："+shell,taskid=taskid)
        G.setadminlog="执行命令："+shell
        return successjson("命令已添加到任务队列中")
    
class PUBLICOther():
    def gitpull(taskid,path,shell):
        kwebsp_news_push(content="执行命令："+shell,percentage=10)
        pi=subprocess.Popen(shell,shell=True, stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        strs=pi.stdout.read().decode()
        kwebsp_news_push(content="命令结果："+strs,percentage=99)
        if path=='/kwebsp/pythoninvdatap':
            try:
                os.remove("app/zcg.zip")
            except:pass
            # time.sleep(1)
            kcwebszip.packzip("pythoninvdatap/app/zcg","app/zcg.zip")
            kcwebszip.unzip_file("app/zcg.zip","app/zcg")
            try:
                os.remove("app/zcg.zip")
            except:pass
            strs="文件已更新："+strs
        Queues.setfield(taskid,'msg',"执行结果："+str(strs))
        kwebsp_news_push(content="git拉取完成<br><br><br><br><br>",percentage=100)


    