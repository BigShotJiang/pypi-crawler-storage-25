from kwebs.common import *
from kwebsp import config
import kwebsocket
if os.name=='nt':
    try:import pyautogui,win32com
    except ModuleNotFoundError:
        import pip
        install_requires=['pyautogui==0.9.54','pywin32==311']
        install_requires.insert(0,"install")
        install_requires.append('-i')
        install_requires.append('https://mirrors.aliyun.com/pypi/simple/')
        if 0 != pip.main(install_requires):
            raise Exception('依赖包安装错误')
        import pyautogui,win32com
    except:raise
kwebsppath=(os.path.split(os.path.realpath(__file__))[0]).replace('\\','/')[:-7] #框架目录
class kwebspdomain:
    def getbanddomain():
        """获取绑定域名
        """
        addtype='kwebsp'
        if os.path.isfile('app/intapp/controller/soft/nginx.py'):
            nginx=getfunction('app.intapp.controller.soft.nginx')
            status,lists,count=nginx.weblist(pagenow=1,pagesize=1,kw='kwebsp域名映射',addtype=addtype)
            if not status:
                return False,lists
            else:
                if len(lists):
                    webitem=lists[0]
                else:
                    webitem={}
                return True,webitem
        else:
            return False,'需要先在插件管理中安装“软件管理”'
    def banddomainall(domain,proxy_pass=[],client_max_body_size=50,read_timeout=60):
        """绑定域名/修改多个代理
        
        domain 域名 必填 该方法生次使用时必填

        proxy_pass 代理信息 格式：[{'notes':'备注','types':'http','rule':'规则','url':'地址'}]
        """
        for k in proxy_pass:
            if not is_index(k,'notes') or not k['notes']:
                return False,'proxy_pass参数缺少notes'
            if not is_index(k,'types') or not k['types']:
                return False,'proxy_pass参数缺少types'
            if not is_index(k,'rule') or not k['rule']:
                return False,'proxy_pass参数缺少rule'
            if not is_index(k,'url') or not k['url']:
                return False,'proxy_pass参数缺少url'
        addtype='kwebsp'
        if os.path.isfile('app/intapp/controller/soft/nginx.py'):
            nginx=getfunction('app.intapp.controller.soft.nginx')
            status,lists,count=nginx.weblist(pagenow=1,pagesize=1,kw='kwebsp域名映射',addtype=addtype)
            if not status:
                return False,lists
            webitem={
                'id':'','log_switch':0,'domain':domain,'port':'80','title':'kwebsp域名映射',
                'describes':'','path':'','webtpl':'balancing','client_max_body_size':int(client_max_body_size),
                'balancing':[{'ip':'127.0.0.1','port':'39001','type':'weight','val':1}],
                'proxy_set_header':[],'header':[],'aliaslists':[],'ssl':'','key':'','pem':'',
                'rewrite':'','ssl_certificate':'','ssl_certificate_key':'','other':{'phppath':'','proxy_pass':proxy_pass,'read_timeout':read_timeout},'cusconfdata':'','denylist':[]
            }
            if len(lists):
                webitem=lists[0]
                if domain:
                    webitem['domain']=domain
                    webitem['other']={'phppath':'','proxy_pass':proxy_pass,'read_timeout':read_timeout}
            status,msg=nginx.funadd_web(data=webitem,addtype=addtype)
            return status,msg
        else:
            return False,'需要先在插件管理中安装“软件管理”'
    def banddomain(proxyitem,domain='',client_max_body_size=50,read_timeout=60):
        """绑定域名/增加代理
        
        proxyitem 代理信息 必填 格式：{'notes':'备注','types':'http','rule':'规则','url':'地址'} 

        domain 域名 非必填 该方法首次使用时该参数必填
        """
        if not is_index(proxyitem,'notes') or not proxyitem['notes']:
            return False,'proxyitem参数缺少notes'
        if not is_index(proxyitem,'types') or not proxyitem['types']:
            return False,'proxyitem参数缺少types'
        if not is_index(proxyitem,'rule') or not proxyitem['rule']:
            return False,'proxyitem参数缺少rule'
        if not is_index(proxyitem,'url') or not proxyitem['url']:
            return False,'proxyitem参数缺少url'
        addtype='kwebsp'
        if os.path.isfile('app/intapp/controller/soft/nginx.py'):
            nginx=getfunction('app.intapp.controller.soft.nginx')
            status,lists,count=nginx.weblist(pagenow=1,pagesize=1,kw='kwebsp域名映射',addtype=addtype)
            if not status:
                return False,lists
            if not len(lists):
                if not domain:
                    return False,'请绑定域名'
            webitem={
                'id':'','log_switch':0,'domain':domain,'port':'80','title':'kwebsp域名映射',
                'describes':'','path':'','webtpl':'balancing','client_max_body_size':int(client_max_body_size),
                'balancing':[{'ip':'127.0.0.1','port':'39001','type':'weight','val':1}],
                'proxy_set_header':[],'header':[],'aliaslists':[],'ssl':'','key':'','pem':'',
                'rewrite':'','ssl_certificate':'','ssl_certificate_key':'','other':{'phppath':'','proxy_pass':[proxyitem],'read_timeout':read_timeout},'cusconfdata':'','denylist':[]
            }
            zx =False
            if len(lists):
                webitem=lists[0]
                if domain:
                    webitem['domain']=domain
                    zx=True
                add=True
                for k in webitem['other']['proxy_pass']:
                    if k['url']==proxyitem['url'] and k['rule']==proxyitem['rule']:
                        add=False
                if add:
                    webitem['other']['proxy_pass'].append(proxyitem)
                    zx=True
                # if proxyitem not in webitem['other']['proxy_pass']:
                #     webitem['other']['proxy_pass'].append(proxyitem)
                #     zx=True
            else:
                zx=True
            if zx:
                status,msg=nginx.funadd_web(data=webitem,addtype=addtype)
                return status,msg
            else:
                return True,'没有任何变化'
        else:
            return False,'需要先在插件管理中安装“软件管理”'
    def delproxy(proxyitem):
        """删除指定代理
        
        proxyitem 代理信息 必填 格式：{'rule':'规则','url':'地址'}
        """
        if not is_index(proxyitem,'rule') or not proxyitem['rule']:
            return False,'proxyitem参数缺少rule'
        if not is_index(proxyitem,'url') or not proxyitem['url']:
            return False,'proxyitem参数缺少url'
        addtype='kwebsp'
        if os.path.isfile('app/intapp/controller/soft/nginx.py'):
            nginx=getfunction('app.intapp.controller.soft.nginx')
            status,lists,count=nginx.weblist(pagenow=1,pagesize=1,kw='kwebsp域名映射',addtype=addtype)
            if not status:
                return False,lists
            if len(lists):
                webitem=lists[0]
                proxy_pass=webitem['other']['proxy_pass']
                proxy_passarr=[]
                for k in proxy_pass:
                    if k['url']!=proxy_pass['url'] and k['rule']!=proxy_pass['rule']:
                        proxy_passarr.append(k)
                webitem['other']['proxy_pass']=proxy_passarr
                status,msg=nginx.funadd_web(data=webitem,addtype=addtype)
                return status,msg
            else:
                return False,'未绑定域名'
        else:
            return False,'需要先在插件管理中安装“软件管理”'
    def delbnddomain():
        addtype='kwebsp'
        if os.path.isfile('app/intapp/controller/soft/nginx.py'):
            nginx=getfunction('app.intapp.controller.soft.nginx')
            status,lists,count=nginx.weblist(pagenow=1,pagesize=1,kw='kwebsp域名映射',addtype=addtype)
            if not status:
                return False,lists
            if len(lists):
                id=lists[0]['id']
                status,msg=nginx.del_nginx_web(id=id)
                return status,msg
            else:
                return True,'相关网站不存在'
        else:
            return False,'需要先在插件管理中安装“软件管理”'
def get_kwebsp_api(intappurl,url,params=None,data=None,json=None,method='POST',username='kcws',password='111111'):
    account_token=get_cache(intappurl+'account_token')
    if not account_token:
        timestamp=str(times())
        random='vfsgresgs'
        sign=md5(username+md5('kcws'+password)+timestamp+random)
        res=requests.post(intappurl+'index/index/pub/get_account_token/'+username+'/'+sign+'/'+timestamp+'/'+random)
        arr=json_decode(res.text)
        if arr['code']==0:
            account_token=arr['data']['account_token']
            set_cache(intappurl+'account_token',account_token,86400)
        else:
            raise Exception(intappurl+','+res.text)
    res=requests.request(method=method,url=intappurl+url+'?account_token='+account_token,params=params,data=data,json=json)
    arr=json_decode(res.text)
    if arr['code']==-2:
        timestamp=str(times())
        random='vfsgresgs'
        sign=md5(username+md5('kcws'+password)+timestamp+random)
        res=requests.post(intappurl+'index/index/pub/get_account_token/'+username+'/'+sign+'/'+timestamp+'/'+random)
        arr=json_decode(res.text)
        if arr['code']==0:
            account_token=arr['data']['account_token']
            res=requests.request(method=method,url=intappurl+url+'?account_token='+account_token,params=params,data=data,json=json)
            arr=json_decode(res.text)
            set_cache(intappurl+'account_token',account_token,86400)
        else:
            raise Exception(intappurl+','+res.text)
    return arr
sockets_admin_authkey=''
php_ims_config_arr=''
try:
    php_ims_config_arr=json_decode(file_get_content(os.getcwd()+'/app/official/controller/phpims/common/file/sqlite/data'))
    sockets_admin_authkey=php_ims_config_arr['admintoken']
except:
    php_ims_config_arr=''
    if os.name=='nt':
        sockets_admin_authkey=kuncache.cache.set_config({'type':'File','path':'C:/temp'}).get_cache("admin_authkey")
        if not sockets_admin_authkey:
            kuncache.cache.set_config({'type':'File','path':'C:/temp'}).set_cache('admin_authkey',md5(str(times())+randoms(6,2)),86400)
            sockets_admin_authkey=kuncache.cache.set_config({'type':'File','path':'C:/temp'}).get_cache("admin_authkey")
    else:
        sockets_admin_authkey=kuncache.cache.set_config({'type':'File','path':'app/runtime/cachepath'}).get_cache("admin_authkey")
        if not sockets_admin_authkey:
            kuncache.cache.set_config({'type':'File','path':'app/runtime/cachepath'}).set_cache('admin_authkey',md5(str(times())+randoms(6,2)),86400)
            sockets_admin_authkey=kuncache.cache.set_config({'type':'File','path':'app/runtime/cachepath'}).get_cache("admin_authkey")
def get_kwebsp_websocket_url(GroupName='kwebsp',unionid=''):
    """获取 kwebsp websocket 的订阅者连接地址"""
    mytime=str(times())
    if unionid:
        unionid=str(unionid)
    socket_hosts='127.0.0.1'
    if request.HEADER.HTTP_HOST():
        socket_hosts=request.HEADER.HTTP_HOST().split(":")[0]
    if php_ims_config_arr:
        token=md5(randoms(6,2))
        sign=kcwsign.getsign({'unionid':unionid,'token':token,'time':mytime,'GroupName':GroupName})

        conf=copy.deepcopy(config.redis)
        conf['host']=php_ims_config_arr['redis']['ip']
        conf['port']=php_ims_config_arr['redis']['port']
        conf['db']=php_ims_config_arr['redis']['db']
        conf['password']=php_ims_config_arr['redis']['password']
        kredis.redis.connect(conf).setstr(unionid,token,60)

        if len(request.HEADER.HTTP_HOST().split(":"))>1:
            return '//'+socket_hosts+':39040?unionid='+str(unionid)+'&time='+mytime+'&sign='+sign+'&GroupName='+GroupName
        else:
            return '//'+socket_hosts+'/phpims/ws?unionid='+str(unionid)+'&time='+mytime+'&sign='+sign+'&GroupName='+GroupName
    else:
        token=md5(randoms())
        set_cache("token",token,60)
        sign=kcwsign.getsign({'unionid':unionid,'token':token,'time':mytime,'GroupName':GroupName})
        if len(request.HEADER.HTTP_HOST().split(":"))>1:
            return "//"+socket_hosts+':39030?unionid='+unionid+'&time='+mytime+'&sign='+sign+'&GroupName='+GroupName
        else:
            return "//"+socket_hosts+'/index/index/ws?unionid='+unionid+'&time='+mytime+'&sign='+sign+'&GroupName='+GroupName
def get_kwebsp_push_websocket_url():
    """获取 kwebsp websocket 的发布者连接地址"""
    socket_hosts='127.0.0.1'
    if request.HEADER.HTTP_HOST():
        socket_hosts=request.HEADER.HTTP_HOST().split(":")[0]
    if sockets_admin_authkey:
        if php_ims_config_arr:
            if len(request.HEADER.HTTP_HOST().split(":"))>1:
                url='//'+socket_hosts+':39040'
            else:
                url='//'+socket_hosts+'/phpims/ws'
        else:
            if len(request.HEADER.HTTP_HOST().split(":"))>1:
                url='//'+socket_hosts+':39030/'
            else:
                url='//'+socket_hosts+'/index/index/ws'
        return url,sockets_admin_authkey
def kwebsp_im_push(data,types,GroupName='',client_id='',unionid=''):
    """推送即时通讯信息
    
    data 要推送的数据

    types 类型 sendToAll(给所有在线发送信息)  sendToGroup(给指定组发送信息)  sendToClient(给指定客户端发送信息)  sendToUid(给指定客户端发送信息)

    GroupName 组名 types=sendToGroup时必填

    client_id 客户端id types=sendToClient时必填

    unionid 用户id types=sendToUid时必填
    
    """
    if sockets_admin_authkey:
        socket_hosts='127.0.0.1'
        if request.HEADER.HTTP_HOST():
            socket_hosts=request.HEADER.HTTP_HOST().split(":")[0]
        if php_ims_config_arr:
            url='ws://'+socket_hosts+':39040'
        else:
            url='ws://'+socket_hosts+':39030'
        kwebsocket.client.connect(url=url,admintoken=sockets_admin_authkey).send_arr(data=data,types=types,GroupName=GroupName,client_id=client_id,unionid=unionid,admintoken=sockets_admin_authkey)
        return url
def kwebsp_news_push(content,percentage=0,percentage1=0,types='',stype='sendToGroup',GroupName='kwebsp',client_id='',unionid=''):
    """推送消息通知
    
    content 信息内容

    percentage 总进度条 百分比 0到100  支持元组(1,100)1表示已处理数量，100表示总数量
    percentage1 子进度条 百分比 0到100  支持元组(1,100)1表示已处理数量，100表示总数量

    types 信息类型 broadcast(广播信息)

    stype 类型 sendToAll(给所有在线发送信息)  sendToGroup(给指定组发送信息)  sendToClient(给指定客户端发送信息)  sendToUid(给指定客户端发送信息)

    GroupName 组名 types=sendToGroup时必填

    client_id 客户端id types=sendToClient时必填

    unionid 用户id types=sendToUid时必填
    """
    if isinstance(percentage, tuple):
        percentage=percentage[0]/percentage[1]*100
    if isinstance(percentage, float):
        percentage=round(percentage, 1)
    if percentage>100:
        percentage=100

    if isinstance(percentage1, tuple):
        percentage1=percentage1[0]/percentage1[1]*100
    if isinstance(percentage1, float):
        percentage1=round(percentage1, 1)
    if percentage1>100:
        percentage1=100

    data={
        'types':types,
        'content':content
    }
    if percentage:
        data['percentage']=percentage #percentage是百分比(可选值) 0到100
    if percentage1:
        data['percentage1']=percentage1 #percentage1是百分比(可选值) 0到100
    return kwebsp_im_push(data,types=stype,GroupName=GroupName,client_id=client_id,unionid=unionid)

