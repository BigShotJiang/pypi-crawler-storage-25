Standings
---------

