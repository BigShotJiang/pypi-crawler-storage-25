Plot Styling
------------

