"""Boot-time preflight: verify external dependencies and credentials."""

import asyncio
import logging
import os
import re
import sys

from kimi_discord_bridge.config import get_config

logger = logging.getLogger("kimi_discord_bridge.preflight")


# ---------------------------------------------------------------------------
# Discord credential validation
# ---------------------------------------------------------------------------

def _validate_discord_credentials(cfg) -> list[str]:
    """Return list of error strings; empty list means all OK."""
    errors = []

    token = cfg.DISCORD_TOKEN
    if not token:
        errors.append("DISCORD_TOKEN is empty")
    else:
        # Discord bot tokens are 3 base64-ish segments separated by dots
        segments = token.split(".")
        if len(segments) != 3:
            errors.append(f"Invalid DISCORD_TOKEN format (expected 3 dot-separated segments, got {len(segments)})")
        elif any(not seg for seg in segments):
            errors.append("Invalid DISCORD_TOKEN format (one or more segments are empty)")

    for name in ("DISCORD_CLIENT_ID", "DISCORD_GUILD_ID"):
        value = getattr(cfg, name)
        if not value:
            errors.append(f"{name} is empty")
        elif not re.fullmatch(r"\d{17,19}", value):
            errors.append(f"{name} must be a 17–19 digit Discord snowflake (got '{value}')")

    return errors


# ---------------------------------------------------------------------------
# toad auto-detection
# ---------------------------------------------------------------------------

async def _detect_toad_cmd(_exec) -> str | None:
    """Try multiple toad invocation candidates and return the first that works."""
    candidates = [
        # 1. Explicit env override (already handled by config, but listed for completeness)
        os.environ.get("TOAD_CMD"),
        # 2. Module invocations (different package names)
        "python -m toad.cli",
        "python -m batrachian_toad",
        # 3. Direct binary on PATH
        "toad",
    ]

    for candidate in candidates:
        if not candidate:
            continue
        parts = candidate.split()
        exe = parts[0]
        args = parts[1:] + ["--version"]
        try:
            stdout, _ = await _exec(exe, args)
            if stdout:
                logger.info("[preflight] toad auto-detected: %s (version: %s)", candidate, stdout.strip().split("\n")[0])
                return candidate
        except Exception:
            continue

    return None


# ---------------------------------------------------------------------------
# cmux sync check
# ---------------------------------------------------------------------------

async def check_cmux_sync(*, toad_cmd: str | None = None, _exec=None) -> dict:
    exec_fn = _exec or _default_exec
    errors = []
    details = {}

    # Check Python version
    if sys.version_info < (3, 14):
        errors.append(f"Python {sys.version_info.major}.{sys.version_info.minor} < 3.14")

    # Auto-detect toad if no explicit command given
    effective_toad = toad_cmd
    if not effective_toad:
        detected = await _detect_toad_cmd(exec_fn)
        if detected:
            effective_toad = detected
            details["toad_auto_detected"] = detected
        else:
            errors.append(
                "toad unavailable: tried 'python -m toad.cli', "
                "'python -m batrachian_toad', and 'toad'. "
                "Set TOAD_CMD to the absolute path of the Python interpreter "
                "inside the kimi-cli venv (e.g. /.../kimi-cli/bin/python -m toad.cli)."
            )
            return {"ok": False, "errors": errors, "details": details}

    # Check toad
    toad_exe = effective_toad.split()[0]
    toad_args = effective_toad.split()[1:] + ["--version"]
    try:
        stdout, _ = await exec_fn(toad_exe, toad_args)
        details["toad"] = stdout.strip().split("\n")[0] if stdout else "ok"
    except Exception as exc:
        errors.append(f"toad unavailable ({effective_toad}): {exc}")

    return {"ok": len(errors) == 0, "errors": errors, "details": details}


async def _default_exec(cmd: str, args: list[str]) -> tuple[str, str]:
    proc = await asyncio.create_subprocess_exec(
        cmd, *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stdout, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"exit code {proc.returncode}: {stderr.decode()}")
    return stdout.decode(), stderr.decode()


# ---------------------------------------------------------------------------
# Main entry
# ---------------------------------------------------------------------------

async def run_preflight() -> dict:
    cfg = get_config()

    # 1. Credential checks first (fail fast)
    cred_errors = _validate_discord_credentials(cfg)
    if cred_errors:
        logger.error("[preflight] Discord credential errors:")
        for e in cred_errors:
            logger.error("[preflight]   • %s", e)
        return {"ok": False, "errors": cred_errors, "details": {}}

    logger.info("[preflight] Discord credentials OK")

    # 2. cmux / toad checks
    result = await check_cmux_sync(toad_cmd=cfg.TOAD_CMD or None)
    if result["ok"]:
        logger.info(
            "[preflight] cmux sync ENABLED (toad=%s)",
            result["details"].get("toad", "?"),
        )
    else:
        logger.warning("[preflight] cmux sync DISABLED — Discord-only mode. Reasons:")
        for e in result["errors"]:
            logger.warning("[preflight]   • %s", e)
    return result
