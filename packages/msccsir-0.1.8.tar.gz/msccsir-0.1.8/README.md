# DeepLearinnng 📦

A simple deep learning practice package containing multiple practical programs (prac1 to prac9).

## 🚀 Installation

```bash
pip install msccsir
```
