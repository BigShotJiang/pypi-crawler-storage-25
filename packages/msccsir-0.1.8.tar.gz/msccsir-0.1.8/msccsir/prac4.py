def prac4():
    return"""
import numpy as np
import matplotlib.pyplot as plt
from keras.datasets import mnist
from keras.models import Model
from keras.layers import Input, Dense
from keras.optimizers import Adam
from sklearn.manifold import TSNE


# -------------------------------------
# 1. Load and Preprocess the MNIST Data
# -------------------------------------


(x_train, y_train), (x_test, y_test) = mnist.load_data()


# Normalize pixel values to be between 0 and 1
x_train = x_train.astype('float32') / 255
x_test = x_test.astype('float32') / 255.


# Flatten the 28x28 images into vectors of 784 elements
x_train = x_train.reshape((len(x_train), np.prod(x_train.shape[1:])))
x_test = x_test.reshape((len(x_test), np.prod(x_test.shape[1:])))




# ------------------------------
# 2. Build the autoencoder model
# ------------------------------


# This is the size of our encoded representations
encoding_dim = 32 # 32 floats -> compression of factor 24.5, assuming the input is 784 floats


# This is our input placeholder
input_img = Input(shape=(784,))


# "encoded" is the encoded representation of the input
encoded = Dense(encoding_dim, activation='relu')(input_img)


# "decoded " is the Lossy reconstruction of the input
decoded = Dense(784, activation='sigmoid')(encoded)


# This model maps an input to its reconstruction
autoencoder = Model(input_img, decoded)


# This model maps an input to its encoded representation
encoder = Model(input_img, encoded)


# Create a placeholder for an encoded (32-dimensional) input
encoded_input = Input(shape=(encoding_dim,))


# Retrieve the Last Layer of the autoencoder model
decoder_layer = autoencoder.layers[-1]


# Create the decoder model
decoder = Model(encoded_input, decoder_layer(encoded_input))


# Compile the autoencoder
autoencoder.compile(optimizer='adam', loss='binary_crossentropy')




# ------------------------
# 3. Train the autoencoder
# ------------------------
history = autoencoder.fit(x_train, x_train, epochs=50, batch_size=256, shuffle=True, validation_data=(x_test, x_test))




# -------------------------------------------------------
# 4. Predict on the test data to get reconstructed images
# -------------------------------------------------------
decoded_imgs = autoencoder.predict(x_test)




# --------------------------------------------------
# 5. Visualize the original and reconstructed images
# --------------------------------------------------


n = 10 # How many digits we will display
plt.figure(figsize=(20, 4))
for i in range(n):
    # Display original
    ax = plt.subplot(2, n, i + 1)
    plt.imshow(x_test[i].reshape(28, 28))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    if i == 0:
        ax.set_title('Original Images', loc='left')


    # display reconstruction
    ax = plt.subplot(2, n, i + 1 + n)
    plt.imshow(decoded_imgs[i].reshape(28, 28))
    plt.gray()
    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    if i == 0:
        ax.set_title('Reconstructed Images', loc='left')
plt.show()




# --------------------------------------------
# 6. Plotting the Training and Validation Loss
# --------------------------------------------
plt.figure(figsize=(10, 5))
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss During Training')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)
plt.show()




# -----------------------------------------
# 7. Visualize the Latent Space using t-SNE
# -----------------------------------------


# Use the encoder to get the latent representations of the test data
encoded_imgs = encoder.predict(x_test)


# Use t-SNE to reduce the dimensionality of the latent space to 2D
tsne = TSNE(n_components=2, random_state=42)
encoded_imgs_2d = tsne.fit_transform(encoded_imgs)


# Plot the 2D Latent space
plt.figure(figsize=(12, 10))
plt.scatter(encoded_imgs_2d[:, 0], encoded_imgs_2d[:, 1], c=y_test,cmap='jet',s=10)
plt.colorbar()
plt.title('t-SNE visualization of the MNIST latent space')
plt.xlabel('t-SNE dimension 1')
plt.ylabel('t-SNE dimension 2')
plt.show()
"""