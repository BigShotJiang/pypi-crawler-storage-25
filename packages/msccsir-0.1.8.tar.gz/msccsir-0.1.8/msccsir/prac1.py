def prac1():
    return """

# On MNIST Dataset

import numpy as np

import matplotlib.pyplot as plt

from tensorflow.keras.datasets import mnist

from tensorflow.keras.utils import to_categorical

from tensorflow.keras.models import Sequential

from tensorflow.keras.layers import Dense, Flatten

from tensorflow.keras.optimizers import Adam

from sklearn.metrics import classification_report, confusion_matrix
# Load the MNIST dataset

(X_train, y_train), (X_test, y_test) = mnist.load_data()

# Normalize the dataset

X_train = X_train.astype('float32') / 255.0

X_test = X_test.astype('float32') / 255.0

# One One-hot encode the Labels

y_train = to_categorical(y_train, 10)

y_test = to_categorical(y_test, 10)

# Build a Multi-Layer Perceptron model

def build_mlp(activation='relu', layer_config=[128, 64]):
    model = Sequential()
    model.add(Flatten(input_shape=(28, 28)))
    for units in layer_config:
        model.add(Dense(units, activation=activation))
    model.add(Dense(10, activation='softmax'))
    model.compile(optimizer=Adam(learning_rate=0.001), loss='categorical_crossentropy', metrics=['accuracy'])
    return model
# Experiment with different configurations

activations = ["relu", "tanh"]

# Corrected syntax for layer_configs, assuming intent was a list of lists for configurations
layer_configs = [[128, 64], [256, 128, 64], [1932, 256, 128, 54]]

results = {}

for activation in activations:
    for config in layer_configs:
        print(f"Training with Activation: {activation}, Layer Config: {config}")
        model = build_mlp(activation=activation, layer_config=config)
        # Corrected variable names and parameters for model.fit
        history = model.fit(X_train, y_train, epochs=10, batch_size=32, validation_split=0.2, verbose=0)

        # Corrected variable names and parameters for model.evaluate
        _, accuracy = model.evaluate(X_test, y_test, verbose=0)
        results[(activation, str(config))] = accuracy # Store results in the dictionary

        print(f'Activation: {activation}, Layer Config: {config}, Accuracy: {accuracy:.4f}')

#Visualize the results

plt.figure(figsize=(12, 8))

for key, value in results.items():

 plt.bar(str(key), value)

plt.xticks(rotation=90)

plt.xlabel('Activation Function and Layer Configuration')

plt.ylabel('Accuracy')

plt.title('Accuracy for Different Activation Functions and Layer Configurations')
plt.show()


# ------------------------------------------------------Prat 2-------------------------------------------------------------------------------


# Display classification report for the best model
best_model_key = max(results, key=results.get)
best_activation, best_config = best_model_key

best_model = build_mlp(activation=best_activation, layer_config=eval(best_config))
best_model.fit(X_train, y_train, epochs=10, batch_size=32, validation_split=0.2, verbose=0)

y_pred = np.argmax(best_model.predict(X_test), axis=1)
y_test_labels = np.argmax(y_test, axis=1)

print(f'Best Model: Activation: {best_activation}, Layer Config: {best_config}')
print('Classification Report:')
print(classification_report(y_test_labels, y_pred))

print('Confusion Matrix:')
print(confusion_matrix(y_test_labels, y_pred))

# Display some test images with their predicted labels
plt.figure(figsize=(15, 15))

for i in range(25):
    plt.subplot(5, 5, i + 1)
    plt.imshow(X_test[i], cmap='gray')
    plt.title(f'Predicted: {y_pred[i]}, True: {y_test_labels[i]}')
    plt.axis('off')

plt.show()
"""