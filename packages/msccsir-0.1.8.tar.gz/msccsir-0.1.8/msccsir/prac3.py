def prac3():
    return """
# Import necessary libraries
import yfinance as yf
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, GRU, Dense

# Load stock data from Yahoo Finance (e.g., Apple stock)
stock_symbol = "AAPL"
df = yf.download(stock_symbol, start="2019-01-01", end="2023-01-01")

# Use the 'Close' price for modeling
data = df[['Close']].values

# Normalize the data
scaler = MinMaxScaler(feature_range=(0, 1))
data_scaled = scaler.fit_transform(data)
# Split data into train and test sets
train_size = int(len(data_scaled) * 0.8)
train, test = data_scaled[0:train_size], data_scaled[train_size:]

# Convert the data into time series format
def create_dataset(dataset, look_back=60):
    X, y = [], []
    for i in range(len(dataset) - look_back):
        X.append(dataset[i:i + look_back, 0])
        y.append(dataset[i + look_back, 0])
    return np.array(X), np.array(y)

look_back = 10
X_train, y_train = create_dataset(train, look_back)
X_test, y_test = create_dataset(test, look_back)

# Reshape input to be [samples, time steps, features]
X_train = np.reshape(X_train, (X_train.shape[0], X_train.shape[1], 1))
X_test = np.reshape(X_test, (X_test.shape[0], X_test.shape[1], 1))

# Build LSTM model
model_lstm = Sequential()
model_lstm.add(LSTM(50, input_shape=(look_back, 1)))
model_lstm.add(Dense(1))
model_lstm.compile(loss='mean_squared_error', optimizer='adam')

# Build GRU model
model_gru = Sequential()
model_gru.add(GRU(50, input_shape=(look_back, 1)))
model_gru.add(Dense(1))
model_gru.compile(loss='mean_squared_error', optimizer='adam')

# Train both models
model_lstm.fit(X_train, y_train, epochs=20, batch_size=32, verbose=1)
model_gru.fit(X_train, y_train, epochs=20, batch_size=32, verbose=1)

# Make predictions
lstm_predictions = model_lstm.predict(X_test)
gru_predictions = model_gru.predict(X_test)

# Inverse transform predictions and actual values
lstm_predictions = scaler.inverse_transform(lstm_predictions)
gru_predictions = scaler.inverse_transform(gru_predictions)
y_test_actual = scaler.inverse_transform(y_test.reshape(-1, 1))

# Plot the predictions and actual values
plt.figure(figsize=(14, 7))
plt.plot(y_test_actual, label='Actual Stock Price')
plt.plot(lstm_predictions, label='LSTM Predictions')
plt.plot(gru_predictions, label='GRU Predictions')
plt.title('Stock Price Prediction - LSTM vs GRU')
plt.xlabel('Time Steps')
plt.ylabel('Stock Price')
plt.legend()
plt.show()

# Future predictions (next 30 days)
future_steps = 30
last_sequence = X_test[-1]

# Predict future prices using the LSTM model
lstm_future_predictions = []
for _ in range(future_steps):
    prediction = model_lstm.predict(last_sequence.reshape(1, look_back, 1))
    lstm_future_predictions.append(prediction[0][0])
    last_sequence = np.append(last_sequence[1:], prediction)

# Predict future prices using the GRU model
last_sequence = X_test[-1]
gru_future_predictions = []
for _ in range(future_steps):
    prediction = model_gru.predict(last_sequence.reshape(1, look_back, 1))
    gru_future_predictions.append(prediction[0][0])
    last_sequence = np.append(last_sequence[1:], prediction)

# Inverse transform future predictions
lstm_future_predictions = scaler.inverse_transform(
    np.array(lstm_future_predictions).reshape(-1, 1)
)
gru_future_predictions = scaler.inverse_transform(
    np.array(gru_future_predictions).reshape(-1, 1)
)

# Plot future predictions
plt.figure(figsize=(14, 7))
plt.plot(lstm_future_predictions, label='LSTM Future Predictions')
plt.plot(gru_future_predictions, label='GRU Future Predictions')
plt.title('Stock Price Future Predictions (Next 30 Days)')
plt.xlabel('Time Steps')
plt.ylabel('Stock Price')
plt.legend()
plt.show()
"""