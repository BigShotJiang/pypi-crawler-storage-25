def prac5():
    return """
import tensorflow as tf
import matplotlib.pyplot as plt

#PART 1: Function Definition
# Define a simple quadratic loss function: f(x) = (x - 3) ^ 2

# The minimum of this function is at x = 3
def loss_function(x):
  return (x-3) **2

#PART 2: Manual Gradient Descent
#Initialize a variable (trainable parameter) with an arbitrary value
x_manual = tf.Variable(initial_value=5.0, trainable=True, dtype =tf.float32)

# Learning rate for gradient-based optimization
learning_rate = 0.01

#Lists to store values for visualization
steps = []
loss_values=[]

# Gradient descent optimization for 20 steps
for step in range(20):
  with tf.GradientTape() as tape:
    #Compute the Loss
    loss = loss_function(x_manual)
  #Compute the gradient of the loss with respect to the variable x_manual
  gradients = tape.gradient(loss, [x_manual])

  # Update the variable using the gradient
  x_manual.assign_sub(learning_rate * gradients[0]) #x_manual = x_manual - Learning_rate * gradient

  # Store the step and Loss value for visualization
  steps.append(step)
  loss_values.append(loss.numpy())
  #Print the details of each step
  print(f"Step {step + 1}: x = {x_manual.numpy():.4f}, Loss = {loss.numpy():.4f}")



#PART 3: Visualization for Manual Gradient Descent
#Plot the Loss values over the optimization steps
plt.figure(figsize=(10, 6))
plt.plot(steps, loss_values, marker='o', label='Manual Gradient Descent')
plt.title('Gradient-Based Optimization: Loss Reduction (Manual)')
plt.xlabel('Steps')
plt.ylabel('Loss')
plt.grid(True)
plt.legend()
plt.show()


#PART 4: Using TensorFlow Optimizers
#Reset the variable x for optimization using TensorFlow's Adam optimizer
x_adam = tf.Variable(initial_value =5.0, trainable =True, dtype=tf.float32)
#Define an Adam optimizer
optimizer = tf.keras.optimizers.Adam(learning_rate=0.1)
#Lists to store values for visualization
adam_steps=[]
adam_loss_values =[]
#Optimization using Adam for 20 steps
for step in range(20):
  with tf.GradientTape() as tape:
    #Compute the Loss
    loss = loss_function(x_adam)
  #Compute the gradients
  gradients = tape.gradient(loss, [x_adam])
  #Apply the gradients using the optimizer
  optimizer.apply_gradients(zip(gradients, [x_adam]))
  # Store the step and Loss value for visualization
  adam_steps.append(step)
  adam_loss_values.append(loss.numpy())
  #Print the details of each step
  print(f"Step {step + 1} (Adam): x = {x_adam.numpy():.4f}, Loss = {loss.numpy():.4f}")

#Plot the Loss values for Adam optimization
plt.figure(figsize=(10, 6))
plt.plot(adam_steps, adam_loss_values, marker='o', color='orange', label='Adam Optimizer')
plt.title('Gradient-Based Optimization: Loss Reduction (Adam)')
plt.xlabel('Steps')
plt.ylabel('Loss')
plt.grid(True)
plt.legend()
plt.show()

# PART 5: Combined Visualization
plt.figure(figsize=(10, 6))
plt.plot(steps, loss_values, marker='o', label='Manual Gradient Descent')
plt.plot(adam_steps, adam_loss_values, marker='o', color='orange', label='Adam Optimizer')
plt.title('Gradient-Based Optimization: Loss Reduction Comparison')
plt.xlabel('Steps')
plt.ylabel('Loss')
plt.grid(True)
plt.legend()
plt.show()

#------------------------------------------------------------------Part B--------------------------------------------------------------------------------------

#5B 2nd Part

import tensorflow as tf
import matplotlib.pyplot as plt
#PART 1: Function Definition
# Define a simple quadratic Loss function: f(x) = (x - 3) ^ 2
# The minimum of this function is at x = 3
def loss_function(x):
  return (x-3) **2

#PART 2: Gradient Computation
#Initialize a variable (trainable parameter) with an arbitrary value
x = tf.Variable(initial_value=5.0, trainable=True, dtype=tf.float32)
# Learning rate for gradient-based optimization
learning_rate= 0.01
#Lists to store values for visualization
steps =[]
loss_values=[]
# Gradient descent optimization for 20 steps
for step in range(20):
  with tf.GradientTape() as tape:
    #Compute the Loss
    loss =loss_function(x)

  #Compute the gradient of the loss with respect to the variable x
  gradients=tape.gradient(loss, [x])

  # Update the variable using the gradient
  x.assign_sub(learning_rate*gradients[0]) #x = x - Learning rate * gradient

  # Store the step and Loss value for visualization
  steps.append(step)
  loss_values.append(loss.numpy())
  #Print the details of each step
  print(f"Step {step + 1}: x = {x.numpy():.4f}, Loss = {loss.numpy():.4f}")

#PART 3: Visualization for Manual Gradient Descent
#Plot the Loss values over the optimization steps
plt.figure(figsize=(10, 6))
plt.plot(steps, loss_values, marker='o', label='Manual Gradient Descent')
plt.title('Gradient-Based Optimization: Loss Reduction (Manual)')
plt.xlabel('Steps')
plt.ylabel('Loss')
plt.grid(True)
plt.legend()
plt.show()

#PART 4: Using TensorFlow Optimizers
#Reset the variable x for optimization using TensorFlow's Adam optimizer
x_adam = tf.Variable(initial_value =5.0, trainable =True, dtype=tf.float32)
#Define an Adam optimizer
optimizer = tf.keras.optimizers.Adam(learning_rate=0.1)
#Lists to store values for visualization
adam_steps=[]
adam_loss_values =[]
#Optimization using Adam for 20 steps
for step in range(20):
  with tf.GradientTape() as tape:
    #Compute the Loss
    loss = loss_function(x_adam)
  #Compute the gradients
  gradients = tape.gradient(loss, [x_adam])
  #Apply the gradients using the optimizer
  optimizer.apply_gradients(zip(gradients, [x_adam]))
  # Store the step and Loss value for visualization
  adam_steps.append(step)
  adam_loss_values.append(loss.numpy())
  #Print the details of each step
  print(f"Step {step + 1} (Adam): x = {x_adam.numpy():.4f}, Loss = {loss.numpy():.4f}")

#Plot the Loss values for Adam optimization
plt.figure(figsize=(10, 6))
plt.plot(adam_steps, adam_loss_values, marker='o', color='orange', label='Adam Optimizer')
plt.title('Gradient-Based Optimization: Loss Reduction (Adam)')
plt.xlabel('Steps')
plt.ylabel('Loss')
plt.grid(True)
plt.legend()
plt.show()

# PART 5: Combined Visualization
plt.figure(figsize=(10, 6))
plt.plot(steps, loss_values, marker='o', label='Manual Gradient Descent')
plt.plot(adam_steps, adam_loss_values, marker='o', color='orange', label='Adam Optimizer')
plt.title('Gradient-Based Optimization: Loss Reduction Comparison')
plt.xlabel('Steps')
plt.ylabel('Loss')
plt.grid(True)
plt.legend()
plt.show()
"""