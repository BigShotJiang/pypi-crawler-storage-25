def prac9():
    return """
# A) Text-Music (15-20s)

# pip install -U torch torchaudio transformers accelerate

import torch, torchaudio
from transformers import AutoProcessor, MusicgenForConditionalGeneration

MODEL = "facebook/musicgen-small"
processor = AutoProcessor.from_pretrained(MODEL)
model = MusicgenForConditionalGeneration.from_pretrained(MODEL)

# prompt = "warm lo-fi beat with soft piano and vinyl crackle"
prompt = "An Indian classical music performance with sitar and tabla, gentle rhythm and melodic improvisation."

inputs = processor(text=[prompt], return_tensors="pt")

model.generation_config.do_sample = True
model.generation_config.guidance_scale = 3.0 # creativity vs. prompt adherence
model.generation_config.max_new_tokens = 50 * 15 # 50 tokens/sec = 15s

audio = model.generate(**inputs)
# (1, channels, samples)

sr = model.config.audio_encoder.sampling_rate
torchaudio.save("text_music.wav", audio[0].cpu(), sr)
print("Saved text_music.wav")


# --- Configuration Example ---
cfg = model.generation_config
cfg.do_sample = True
cfg.temperature = 1.0 # 1.0 more conservative; 1.8 more exploratory
cfg.top_k = 50
cfg.top_p = 0.95
# nucleus sampling: smallest set with cumulative prob >= p
cfg.guidance_scale = 3.8
# limit sampling to top-K most likely tokens
cfg.max_new_tokens = 50 * 20


# ---------------------------------------------------------------part B--------------------------------------------------

import torch, torchaudio
from transformers import AutoProcessor, MusicgenMelodyForConditionalGeneration

# 1. Use the melody-specific model class
MODEL = "facebook/musicgen-melody"
processor = AutoProcessor.from_pretrained(MODEL)
model = MusicgenMelodyForConditionalGeneration.from_pretrained(MODEL)

prompt = "emotional strings over gentle ambient pads"

# 2. Load the audio we just made in Part A
melody, sr_in = torchaudio.load("text_music.wav")

# 3. Feed BOTH the text prompt and your audio file into the processor
# Note: The processor for melody models expects the 'melody' argument
inputs = processor(
    text=[prompt],
    melody=melody,
    sampling_rate=sr_in,
    return_tensors="pt"
)

# 4. Generate the audio!
# We pass the processed inputs to the model
predict_ids = model.generate(**inputs, max_new_tokens=50 * 15)

# 5. Save the final track
sr_out = model.config.audio_encoder.sampling_rate
torchaudio.save("guided_music.wav", predict_ids[0].cpu(), sr_out)
print("Saved guided_music.wav!")
"""
