def prac2():
    return """
# Import required libraries
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from tensorflow import keras
from tensorflow.keras import layers, models
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split


# 1. Dataset Preparation
# -----------------------


# Load the MNIST dataset (28x28 grayscale images of handwritten digits)
(x_train, y_train), (x_test, y_test) = keras.datasets.mnist.load_data()


# Normalize the image data to range [0, 1]
x_train = x_train.astype("float32") / 255.0
x_test = x_test.astype("float32") / 255.0


# Reshape to include channel dimension (28, 28, 1)
x_train = x_train[..., np.newaxis]
x_test = x_test[..., np.newaxis]


# Convert labels to one-hot encoded format
num_classes = 10
y_train_cat = keras.utils.to_categorical(y_train, num_classes)
y_test_cat = keras.utils.to_categorical(y_test, num_classes)


# Split training data into train and validation sets
x_train, x_val, y_train_cat, y_val_cat = train_test_split(
    x_train, y_train_cat, test_size=0.1, random_state=42
)

# 2. Define CNN Model Architecture
# ---------------------------------
model = models.Sequential()


# Convolutional Layer 1: Extract low-level features
model.add(layers.Conv2D(32, (3, 3), activation='relu', input_shape=(28, 28, 1)))
model.add(layers.MaxPooling2D((2, 2))) # Reduce spatial dimensions


# Convolutional Layer 2
model.add(layers.Conv2D(64, (3, 3), activation='relu'))
model.add(layers.MaxPooling2D((2, 2)))


# Flatten the output and feed into Fully Connected Layers
model.add(layers.Flatten())
model.add(layers.Dense(128, activation='relu')) # Fully connected layer
model.add(layers.Dropout(0.5)) # Dropout for regularization


# Output layer with Softmax for multi-class classification
model.add(layers.Dense(num_classes, activation='softmax'))


# Display the model summary
model.summary()

# ---------------------------------------------------------------Part 2--------------------------------------------------------------------------

# 3. Compilation
# ---------------
model.compile(optimizer='adam',
              loss='categorical_crossentropy',
              metrics=['accuracy'])


# 4. Training the Model
# ----------------------


# Define EarlyStopping to prevent overfitting
early_stop = keras.callbacks.EarlyStopping(
    monitor='val_loss', patience=3, restore_best_weights=True
)


# Train the model
history = model.fit(
    x_train, y_train_cat,
    epochs=15,
    batch_size=128,
    validation_data=(x_val, y_val_cat),
    callbacks=[early_stop]
)

# 5. Testing and Evaluation
# --------------------------
test_loss, test_acc = model.evaluate(x_test, y_test_cat, verbose=2)
print(f"\nTest accuracy: {test_acc:.4f}, Test loss: {test_loss:.4f}")


# Predict on some test images
predictions = model.predict(x_test)
y_pred = np.argmax(predictions, axis=1)


# Display a few predictions
plt.figure(figsize=(10, 4))
for i in range(5):
    plt.subplot(1, 5, i+1)
    plt.imshow(x_test[i].reshape(28, 28), cmap='gray')
    plt.title(f"Pred: {y_pred[i]}\nTrue: {y_test[i]}")
    plt.axis('off')
plt.tight_layout()
plt.show()


# 6. Performance Visualization
# -----------------------------


# Plot training & validation accuracy/loss
def plot_metrics(history):
    plt.figure(figsize=(12, 5))


    # Accuracy Plot
    plt.subplot(1, 2, 1)
    plt.plot(history.history['accuracy'], label='Train Acc')
    plt.plot(history.history['val_accuracy'], label='Val Acc')
    plt.title('Accuracy over Epochs')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()


    # Loss Plot
    plt.subplot(1, 2, 2)
    plt.plot(history.history['loss'], label='Train Loss')
    plt.plot(history.history['val_loss'], label='Val Loss')
    plt.title('Loss over Epochs')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()


    plt.tight_layout()
    plt.show()


plot_metrics(history)


# Confusion Matrix (Visualized in the slides)
cm = confusion_matrix(y_test, y_pred)
plt.figure(figsize=(8,6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=range(10), yticklabels=range(10))
plt.xlabel('Predicted')
plt.ylabel('Truth')
plt.title('Confusion Matrix')
plt.show()


# Classification Report
print("\nClassification Report:\n")
print(classification_report(y_test, y_pred))
"""
