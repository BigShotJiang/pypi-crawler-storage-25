def prac7():
    return """
import numpy as np
import matplotlib.pyplot as plt


from sklearn.datasets import make_moons
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader


# -----------------------------------
# 0) Reproducibility
# -----------------------------------


seed = 7
np.random.seed(seed)
torch.manual_seed(seed)


# -----------------------------------
# 1) Data: Two Moons (binary classification)
# -----------------------------------


X, y = make_moons(n_samples=1200, noise=0.18, random_state=seed)
X = StandardScaler().fit_transform(X)


X_train, X_val, y_train, y_val = train_test_split(
    X, y, test_size=0.2, random_state=seed, stratify=y
)


X_train_t = torch.tensor(X_train, dtype=torch.float32)
y_train_t = torch.tensor(y_train, dtype=torch.float32).view(-1,1)
X_val_t = torch.tensor(X_val, dtype=torch.float32)
y_val_t = torch.tensor(y_val, dtype=torch.float32).view(-1,1)


train_loader = DataLoader(
    TensorDataset(X_train_t, y_train_t),
    batch_size=64, shuffle=True
)


criterion = nn.BCEWithLogitsLoss() # sigmoid is built-in via Logits loss


# -----------------------------------
# 2) Optimizers from library (torch.optim)
# -----------------------------------


optimizer_builders = {
    "SGD":          lambda params: optim.SGD(params, lr=0.08),
    "SGD+Momentum": lambda params: optim.SGD(params, lr=0.06, momentum=0.9),
    "RMSprop":      lambda params: optim.RMSprop(params, lr=0.01, alpha=0.9),
    "Adam":         lambda params: optim.Adam(params, lr=0.01),
}


EPOCHS = 90


histories ={} # name -> dict of lists
final_metrics = {} # name -> (train_loss, val_loss, val_acc)


# -----------------------------------
# 3) Train the same model separately with each optimizer
# -----------------------------------


for name, make_opt in optimizer_builders.items():
  # Same init for fair competition
  torch.manual_seed(seed)


  model = nn.Sequential(
      nn.Linear(2, 16),
      nn.ReLU(),
      nn.Linear(16, 1) # logits
  )


  optimizer = make_opt(model.parameters())


  train_loss_list = []
  val_loss_list = []
  val_acc_list = []


  for epoch in range(EPOCHS):
    model.train()
    running_loss = 0.0


    for xb, yb in train_loader:
      optimizer.zero_grad(set_to_none=True)
      logits = model(xb)
      loss = criterion(logits, yb)
      loss.backward()
      optimizer.step()
      running_loss += loss.item() * xb.size(0)


    train_loss = running_loss / len(train_loader.dataset)


    # Validation (no function; inline)
    model.eval()
    with torch.no_grad():
      val_logits = model(X_val_t)
      val_loss = criterion(val_logits, y_val_t).item()
      val_probs = torch.sigmoid(val_logits)
      val_preds = (val_probs >= 0.5).float()
      val_acc = (val_preds.eq(y_val_t)).float().mean().item()


    train_loss_list.append(train_loss)
    val_loss_list.append(val_loss)
    val_acc_list.append(val_acc)


  histories[name] = {
      "train_loss":  train_loss_list,
      "val_loss": val_loss_list,
      "val_acc": val_acc_list
    }


  final_metrics[name] = (train_loss_list[-1], val_loss_list[-1], val_acc_list[-1])


# -----------------------------------
# 4) Plots
# -----------------------------------


plt.figure()
for name in histories:
  plt.plot(histories[name]["train_loss"], label=name)
plt.title("Training Loss vs EPOCHS (BCEWithLogitsLoss)")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.show()


plt.figure()
for name in histories:
  plt.plot(histories[name]["val_loss"], label=name)
plt.title("Validation Loss vs EPOCHS")
plt.xlabel("Epoch")
plt.ylabel("Loss")
plt.legend()
plt.show()


plt.figure()
for name in histories:
  plt.plot(histories[name]["val_acc"], label=name)
plt.title("Validation Accuracy vs EPOCHS")
plt.xlabel("Epoch")
plt.ylabel("Accuracy")
plt.legend()
plt.show()


# -----------------------------------
# 5) Print final summary table
# -----------------------------------


print("Final Metrics after training: ")
print("Optimizer\tTrain Loss\tVal Loss\tVal Acc")
for name, (t1, v1, va) in final_metrics.items():
  print(f"{name:13s} {t1:8.4f} {v1:8.4f} {va*100:6.2f}")

"""