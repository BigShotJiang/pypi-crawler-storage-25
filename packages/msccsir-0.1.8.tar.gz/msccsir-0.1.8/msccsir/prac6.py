def prac6():
    return """
import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt




# -----------------------------
# 1. SETUP AND DATA PREPARATION
# -----------------------------


# Check if TensorFlow is able to detect a GPU
print(tf.config.list_physical_devices('GPU'))


# Set the GPU device to use
device_name = '/device:GPU:0'


# Load MNIST dataset
mnist = tf.keras.datasets.mnist
(train_images, train_labels), (_, _) = mnist.load_data()


# Normalize the images to [-1, 1]
train_images = (train_images.astype('float32') - 127.5) / 127.5


# Reshape the images to (28, 28, 1) and add a channel dimension
train_images = np.expand_dims(train_images, axis=-1)


# Batch and shuffle the data
BUFFER_SIZE = 60000
BATCH_SIZE = 256
train_dataset = tf.data.Dataset.from_tensor_slices(train_images).shuffle(BUFFER_SIZE).batch(BATCH_SIZE)




# ----------------------
# 2. MODEL ARCHITECTURES
# ----------------------


def make_generator_model():
    model = tf.keras.Sequential()
    # Initial dense layer
    model.add(tf.keras.layers.Dense(7*7*256, use_bias=False, input_shape=(100,)))
    model.add(tf.keras.layers.BatchNormalization())
    model.add(tf.keras.layers.LeakyReLU())


    # Reshape to start convolutional process
    model.add(tf.keras.layers.Reshape((7, 7, 256)))
    assert model.output_shape == (None, 7, 7, 256)


    # First Transposed Convolution (keeps 7x7 size)
    model.add(tf.keras.layers.Conv2DTranspose(128, (5, 5), strides=(1, 1), padding='same', use_bias=False))
    assert model.output_shape == (None, 7, 7, 128)
    model.add(tf.keras.layers.BatchNormalization())
    model.add(tf.keras.layers.LeakyReLU())


    # Second Transposed Convolution (upsamples to 14x14)
    model.add(tf.keras.layers.Conv2DTranspose(64, (5, 5), strides=(2, 2), padding='same', use_bias=False))
    assert model.output_shape == (None, 14, 14, 64)
    model.add(tf.keras.layers.BatchNormalization())
    model.add(tf.keras.layers.LeakyReLU())


    # Final Transposed Convolution (upsamples to 28x28 grayscale image)
    model.add(tf.keras.layers.Conv2DTranspose(1, (5, 5), strides=(2, 2), padding='same', use_bias=False, activation='tanh'))
    assert model.output_shape == (None, 28, 28, 1)


    return model


def make_discriminator_model():
    model = tf.keras.Sequential()
    # First convolutional layer
    model.add(tf.keras.layers.Conv2D(64, (5, 5), strides=(2, 2), padding='same', input_shape=[28, 28, 1]))
    model.add(tf.keras.layers.LeakyReLU())
    model.add(tf.keras.layers.Dropout(0.3))


    # Second convolutional layer
    model.add(tf.keras.layers.Conv2D(128, (5, 5), strides=(2, 2), padding='same'))
    model.add(tf.keras.layers.LeakyReLU())
    model.add(tf.keras.layers.Dropout(0.3))


    # Classifier head
    model.add(tf.keras.layers.Flatten())
    model.add(tf.keras.layers.Dense(1))


    return model




# --------------------------------
# 3. LOSS FUNCTIONS AND OPTIMIZERS
# --------------------------------


cross_entropy = tf.keras.losses.BinaryCrossentropy(from_logits=True)


def discriminator_loss(real_output, fake_output):
    # Loss for correctly identifying real and fake images
    real_loss = cross_entropy(tf.ones_like(real_output), real_output)
    fake_loss = cross_entropy(tf.zeros_like(fake_output), fake_output)
    total_loss = real_loss + fake_loss
    return total_loss


def generator_loss(fake_output):
    # Loss for how well the generator fooled the discriminator
    return cross_entropy(tf.ones_like(fake_output), fake_output)


# Instantiate models
generator = make_generator_model()
discriminator = make_discriminator_model()


# Define Adam optimizers
generator_optimizer = tf.keras.optimizers.Adam(1e-4)
discriminator_optimizer = tf.keras.optimizers.Adam(1e-4)


# --- 4. TRAINING LOOP ---
EPOCHS = 100
noise_dim = 100
num_examples_to_generate = 16


@tf.function
def train_step(images):
    # Generate random noise seed
    noise = tf.random.normal([BATCH_SIZE, noise_dim])


    with tf.GradientTape() as gen_tape, tf.GradientTape() as disc_tape:
        # Generate fake images
        generated_images = generator(noise, training=True)


        # Get discriminator evaluations
        real_output = discriminator(images, training=True)
        fake_output = discriminator(generated_images, training=True)


        # Calculate losses
        gen_loss = generator_loss(fake_output)
        disc_loss = discriminator_loss(real_output, fake_output)


    # Compute and apply gradients
    gradients_of_generator = gen_tape.gradient(gen_loss, generator.trainable_variables)
    gradients_of_discriminator = disc_tape.gradient(disc_loss, discriminator.trainable_variables)


    generator_optimizer.apply_gradients(zip(gradients_of_generator, generator.trainable_variables))
    discriminator_optimizer.apply_gradients(zip(gradients_of_discriminator, discriminator.trainable_variables))




# ---------------------------------
# 5. IMAGE GENERATION AND EXECUTION
# ---------------------------------


def generate_and_save_images(model, epoch, test_input):
    # Predictions and rescale from [-1, 1] to [0, 1] for plotting
    predictions = model(test_input, training=False)
    predictions = (predictions + 1) / 2.0


    # Plot results in a 4x4 grid
    fig = plt.figure(figsize=(4, 4))
    for i in range(predictions.shape[0]):
        plt.subplot(4, 4, i+1)
        plt.imshow(predictions[i, :, :, 0], cmap='gray')
        plt.axis('off')


    plt.savefig('image_at_epoch_{:04d}.png'.format(epoch))
    plt.show()


# Fixed noise for consistent evaluation
fixed_noise = tf.random.normal([num_examples_to_generate, noise_dim])


# Main training execution
for epoch in range(EPOCHS):
    for image_batch in train_dataset:
        train_step(image_batch)


    # Save images every 10 epochs
    if (epoch + 1) % 10 == 0:
        generate_and_save_images(generator, epoch + 1, fixed_noise)


    print('Epoch {} completed'.format(epoch + 1))
"""