from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as f:
    long_desc = f.read()

setup(
    name='msccsir',
    version='0.1.8',
    author='Enzo Martin',
    author_email='enzomartini.1995@gmail.com',
    description='Deep learning practical package (prac1–prac9)',
    long_description=long_desc,
    long_description_content_type='text/markdown',
    packages=find_packages(),
    python_requires='>=3.6',
)