import json
import logging
from pathlib import Path
from PySide6.QtWidgets import QMainWindow, QMenuBar, QMenu
from PySide6.QtGui import QAction
from PySide6.QtCore import QObject

logger = logging.getLogger("wysebee")


class WysebeeAppMenu:
    def __init__(self, browser, backend: QObject, menu_path: str):
        self._browser = browser
        self._backend = backend
        self._main_window = QMainWindow()
        self._main_window.setCentralWidget(browser)

        menu_file = Path(menu_path)
        if not menu_file.exists():
            logger.warning(f"Menu file not found: {menu_path}")
            return

        with open(menu_file, "r") as f:
            menu_data = json.load(f)

        menu_bar = self._main_window.menuBar()
        self._build_menu(menu_bar, menu_data)

    def _build_menu(self, parent, items):
        for item in items:
            if item.get("separator"):
                if isinstance(parent, QMenu):
                    parent.addSeparator()
                continue

            label = item.get("label", "")
            submenu = item.get("submenu")

            if submenu:
                menu = parent.addMenu(label)
                self._build_menu(menu, submenu)
            else:
                action_name = item.get("action")
                action = QAction(label, self._main_window)
                if action_name:
                    handler = getattr(self._backend, action_name, None)
                    if handler:
                        action.triggered.connect(handler)
                    else:
                        logger.warning(f"Backend has no method '{action_name}' for menu item '{label}'")
                parent.addAction(action)

    def show(self):
        self._main_window.show()

    @property
    def main_window(self):
        return self._main_window
