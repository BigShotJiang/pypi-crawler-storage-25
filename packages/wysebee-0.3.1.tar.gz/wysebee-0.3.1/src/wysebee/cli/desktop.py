import json
import os
import subprocess
from pathlib import Path
from typing import Optional

from colorama import Fore

from ._uv import bootstrap_uv_project
from ._vite import install_router_if_react, setup_vite_pages


def _generate_ui_template(name: str, ui_dir: str, template: str):
    # Change to UI directory and initialize vite
    try:
        print(Fore.YELLOW + f"Setting up Vite in UI folder...")
        original_dir = os.getcwd()
        os.chdir(ui_dir)
        if template:
            subprocess.run(
                ["npm", "create", "vite@latest", ".", "--", "--template", template],
                input="n\n",
                text=True,
                check=True,
            )
        else:
            subprocess.run(
                ["npm", "create", "vite@latest", "."],
                input="n\n",
                text=True,
                check=True,
            )

        subprocess.run(["npm", "install"], check=True)
        install_router_if_react(template)

        # Write fresh vite.config.js + index/settings pages + entry modules
        setup_vite_pages(template, platform="desktop")

        subprocess.run(["npm", "run", "build"], check=True)
        os.chdir(original_dir)
        print(Fore.YELLOW + f"Successfully set up Vite in {name}/ui!")
    except subprocess.CalledProcessError as e:
        print(Fore.RED + f"Error running npm create vite: {e}")
        os.chdir(original_dir)
    except Exception as e:
        print(Fore.RED + f"Unexpected error: {e}")
        os.chdir(original_dir)


def _generate_app_menu_template(desktop_dir: Path):
    """Create a menu folder with a sample menu.json inside the desktop folder."""
    menu_dir = desktop_dir / "menu"
    menu_dir.mkdir(exist_ok=True)
    menu_file = menu_dir / "menu.json"
    menu_file.write_text(
        json.dumps(
            [
                {
                    "label": "File",
                    "submenu": [
                        {"label": "Open", "action": "on_open"},
                        {"label": "Save", "action": "on_save"},
                        {"separator": True},
                        {"label": "Exit", "action": "on_exit"},
                    ],
                },
            ],
            indent=2,
        )
    )
    print(Fore.YELLOW + f"Created menu/menu.json in {desktop_dir}")


def generate_desktop_app(name: str, app_dir: Path, ui_dir: Path, template: str, project_name: Optional[str] = None) -> None:
    """Generate a complete desktop app: desktop/{main.py, src/, menu/, pyproject.toml}, UI at root."""
    if project_name is None:
        project_name = name
    # Create the desktop/ subfolder that holds all Python files
    desktop_dir = app_dir / "desktop"
    desktop_dir.mkdir(exist_ok=True)
    print(Fore.YELLOW + f"Created desktop folder in {name}")

    # Create the src subfolder inside desktop/
    src_dir = desktop_dir / "src"
    src_dir.mkdir(exist_ok=True)
    print(Fore.YELLOW + f"Created desktop/src folder in {name}")

    # Generate menu template inside desktop/
    _generate_app_menu_template(desktop_dir)

    # Create desktop/src/__init__.py
    init_file = src_dir / "__init__.py"
    init_file.write_text("")

    # Create desktop/src/backend.py
    backend_file = src_dir / "backend.py"
    backend_file.write_text(
        """import logging
from PySide6.QtWidgets import QApplication, QFileDialog
from PySide6.QtCore import Slot
from wysebee import WysebeeBackend

logger = logging.getLogger("wysebee")


class MyBackend(WysebeeBackend):
    def __init__(self, parent):
        super().__init__(parent)

    @Slot()
    def on_open(self):
        file_path, _ = QFileDialog.getOpenFileName(None, "Open File")
        if file_path:
            logger.info(f"Opened file: {file_path}")

    @Slot()
    def on_save(self):
        file_path, _ = QFileDialog.getSaveFileName(None, "Save File")
        if file_path:
            logger.info(f"Saved file: {file_path}")

    @Slot()
    def on_exit(self):
        logger.info("Exiting application")
        QApplication.quit()
"""
    )
    print(Fore.YELLOW + f"Created desktop/src/backend.py in {name}")

    # Create desktop/main.py for desktop app. Paths are relative to this file:
    #   menu -> menu/menu.json (same dir)
    #   ui   -> ../ui/templates/index.html (ui lives at project root)
    main_file = desktop_dir / "main.py"
    main_file.write_text(
        """
import sys
import os
from PySide6.QtWidgets import QApplication
from wysebee import Wysebee, WysebeeAppMenu
from src.backend import MyBackend

def main():
    app = QApplication(sys.argv)
    wysebee = Wysebee(app)
    backend = MyBackend(app)
    browser = wysebee.initialize_window(width=1280, height=800, backend=backend)
    menu_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "menu/menu.json"))
    app_menu = WysebeeAppMenu(browser, backend, menu_path)
    html_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "../ui/templates/index.html"))
    wysebee.launch(html_path)
    app_menu.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
"""
    )
    print(Fore.YELLOW + f"Created desktop/main.py file in {name}")

    # Write desktop/pyproject.toml (uv-managed)
    pyproject_file = desktop_dir / "pyproject.toml"
    pyproject_file.write_text(
        f"""[project]
name = "{project_name}-desktop"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "PySide6",
    "Wysebee",
]
"""
    )
    print(Fore.YELLOW + f"Created desktop/pyproject.toml in {name}")

    # Build the UI first (ui/ stays at project root)
    _generate_ui_template(name, ui_dir, template)

    # Bootstrap the uv venv + install dependencies
    if bootstrap_uv_project(desktop_dir):
        print(Fore.GREEN + f"Now you are ready!")
        print(Fore.GREEN + f" To run the app, use:")
        if name != ".":
            print(Fore.GREEN + f"   cd {name}/desktop")
        else:
            print(Fore.GREEN + f"   cd desktop")
        print(Fore.GREEN + f"   uv run python main.py")
