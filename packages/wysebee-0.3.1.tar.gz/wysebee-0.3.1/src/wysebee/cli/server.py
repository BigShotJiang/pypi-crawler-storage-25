import os
import subprocess
from pathlib import Path
from typing import Optional

from colorama import Fore

from ._uv import bootstrap_uv_project
from ._vite import install_router_if_react, setup_vite_pages


def _generate_web_ui_template(name: str, ui_dir: str, template: str):
    """Generate UI template for web apps (no QWebChannel)."""
    try:
        print(Fore.YELLOW + f"Setting up Vite in UI folder...")
        original_dir = os.getcwd()
        os.chdir(ui_dir)
        if template:
            subprocess.run(
                ["npm", "create", "vite@latest", ".", "--", "--template", template],
                input="n\n",
                text=True,
                check=True,
            )
        else:
            subprocess.run(
                ["npm", "create", "vite@latest", "."],
                input="n\n",
                text=True,
                check=True,
            )

        subprocess.run(["npm", "install"], check=True)
        install_router_if_react(template)

        # Write fresh vite.config.js + index/settings pages + entry modules
        setup_vite_pages(template, platform="web")

        subprocess.run(["npm", "run", "build"], check=True)
        os.chdir(original_dir)
        print(Fore.YELLOW + f"Successfully set up Vite in {name}/ui!")
    except subprocess.CalledProcessError as e:
        print(Fore.RED + f"Error running npm create vite: {e}")
        os.chdir(original_dir)
    except Exception as e:
        print(Fore.RED + f"Unexpected error: {e}")
        os.chdir(original_dir)


def _write_dockerfile(app_dir: Path, name: str) -> None:
    """Write a minimal Dockerfile at the project root that runs the FastAPI server."""
    dockerfile = app_dir / "Dockerfile"
    dockerfile.write_text(
        """FROM python:3.12-slim

# Install uv
RUN pip install --no-cache-dir uv

WORKDIR /app

# Copy server pyproject + source and the built UI
COPY server/ /app/server/
COPY ui/templates/ /app/ui/templates/

WORKDIR /app/server

RUN uv sync

EXPOSE 8000

CMD ["uv", "run", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
"""
    )
    print(Fore.YELLOW + f"Created Dockerfile in {name}")


def generate_server_app(name: str, app_dir: Path, ui_dir: Path, template: str, project_name: Optional[str] = None) -> None:
    """Generate a FastAPI web app: server/{main.py, pyproject.toml}, root Dockerfile, UI."""
    if project_name is None:
        project_name = name
    # Create server/ subfolder
    server_dir = app_dir / "server"
    server_dir.mkdir(exist_ok=True)
    print(Fore.YELLOW + f"Created server folder in {name}")

    # Create server/main.py — ui/templates lives one level up at the project root
    main_file = server_dir / "main.py"
    main_file.write_text(
        """import os
import uvicorn
from fastapi import FastAPI
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

app = FastAPI()

# Built frontend (ui/ lives at the project root, one level above server/)
UI_DIR = os.path.join(os.path.dirname(__file__), "../ui/templates")


@app.get("/settings")
def settings():
    return FileResponse(os.path.join(UI_DIR, "settings.html"))


# StaticFiles(html=True) serves index.html at "/" and resolves assets, /vite.svg, etc.
# Mount LAST so the explicit routes above take precedence.
app.mount("/", StaticFiles(directory=UI_DIR, html=True), name="static")


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)
"""
    )
    print(Fore.YELLOW + f"Created server/main.py file in {name}")

    # Write server/pyproject.toml (uv-managed)
    pyproject_file = server_dir / "pyproject.toml"
    pyproject_file.write_text(
        f"""[project]
name = "{project_name}-server"
version = "0.1.0"
requires-python = ">=3.10"
dependencies = [
    "fastapi",
    "uvicorn[standard]",
    "Wysebee",
]
"""
    )
    print(Fore.YELLOW + f"Created server/pyproject.toml in {name}")

    # Write Dockerfile at the project root
    _write_dockerfile(app_dir, name)

    # Build the UI first (ui/ stays at project root)
    _generate_web_ui_template(name, ui_dir, template)

    # Bootstrap uv venv + install dependencies inside server/
    if bootstrap_uv_project(server_dir):
        print(Fore.GREEN + f"Now you are ready!")
        print(Fore.GREEN + f" To run the app, use:")
        if name != ".":
            print(Fore.GREEN + f"   cd {name}/server")
        else:
            print(Fore.GREEN + f"   cd server")
        print(Fore.GREEN + f"   uv run uvicorn main:app --reload")
