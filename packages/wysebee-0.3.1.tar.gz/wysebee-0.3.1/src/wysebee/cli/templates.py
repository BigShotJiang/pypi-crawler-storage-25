"""Shared HTML + entry-module template helpers for generated apps."""

# Map each Vite template to its per-page entry script paths.
_ENTRY_POINTS = {
    "react":      {"index": "/src/main.jsx",     "settings": "/src/settings.jsx"},
    "react-ts":   {"index": "/src/main.tsx",     "settings": "/src/settings.tsx"},
    "vanilla":    {"index": "/src/main.js",      "settings": "/src/settings.js"},
    "vanilla-ts": {"index": "/src/main.ts",      "settings": "/src/settings.ts"},
}

_QWEBCHANNEL_HEAD = '<script src="qrc:///qtwebchannel/qwebchannel.js"></script>'

_QWEBCHANNEL_INIT = """<script>
      new QWebChannel(qt.webChannelTransport, function(channel) {
        console.log("✅ QWebChannel initialized");
        channel.objects.wysebee.sendMessage("Hello from the frontend!");
        window.wysebee = channel.objects.wysebee;
      });
    </script>"""


def entry_for(template: str, page: str) -> str:
    """Return the entry-script path for a given Vite template + page."""
    pages = _ENTRY_POINTS.get(template, _ENTRY_POINTS["vanilla"])
    return pages[page]


def render_page_html(template: str, platform: str, page: str) -> str:
    """Render a Wysebee-branded HTML entry page.

    Args:
        template: Vite template ("react", "react-ts", "vanilla", "vanilla-ts").
        platform: "desktop" or "web". Desktop includes the QWebChannel bridge.
        page: "index" or "settings". Selects which entry script to load and
            which body content to render.
    """
    entry = entry_for(template, page)
    if platform == "desktop":
        runtime_label = "PySide"
        runtime_emoji = "🖥️"
        qwebchannel_head = _QWEBCHANNEL_HEAD
        qwebchannel_init = _QWEBCHANNEL_INIT
    else:
        runtime_label = "FastAPI"
        runtime_emoji = "⚡"
        qwebchannel_head = ""
        qwebchannel_init = ""

    if page == "settings":
        title = f"Settings · Wysebee.io + Vite + {runtime_label}"
        body_content = """<h1 style=\"margin-top:0\">⚙️ Settings</h1>
    <p>Configure your app here.</p>"""
    else:
        title = f"Wysebee.io + Vite + {runtime_label}"
        body_content = f"""<div class=\"wysebee-stack\">
      <span class=\"item\">🐝<span class=\"label\">Wysebee</span></span>
      <span class=\"plus\">+</span>
      <span class=\"item\">⚡<span class=\"label\">Vite</span></span>
      <span class=\"plus\">+</span>
      <span class=\"item\">{runtime_emoji}<span class=\"label\">{runtime_label}</span></span>
    </div>
    <p class=\"wysebee-link\">Powered by <a href=\"https://wysebee.io\" target=\"_blank\" rel=\"noopener\">wysebee.io</a></p>"""

    return f"""<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="/vite.svg" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>{title}</title>
    <style>
      body {{
        font-family: system-ui, -apple-system, sans-serif;
        text-align: center;
        padding: 2rem;
        color: #213547;
      }}
      .wysebee-nav {{ margin-bottom: 1.5rem; font-size: 0.95rem; }}
      .wysebee-nav a {{ color: #646cff; text-decoration: none; margin: 0 0.4rem; }}
      .wysebee-nav a:hover {{ text-decoration: underline; }}
      .wysebee-stack {{
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 1rem;
        margin: 1.5rem 0;
        font-size: 2rem;
      }}
      .wysebee-stack .plus {{ color: #888; font-size: 1.5rem; }}
      .wysebee-stack .label {{ font-size: 0.85rem; display: block; color: #555; }}
      .wysebee-stack .item {{ display: flex; flex-direction: column; align-items: center; }}
      .wysebee-link a {{ color: #646cff; text-decoration: none; font-weight: 500; }}
      .wysebee-link a:hover {{ text-decoration: underline; }}
    </style>
    {qwebchannel_head}
  </head>
  <body>
    <nav class="wysebee-nav">
      <a href="./index.html">Home</a> · <a href="./settings.html">Settings</a>
    </nav>
    {body_content}
    <div id="root"></div>
    {qwebchannel_init}
    <script type="module" src="{entry}"></script>
  </body>
</html>
"""


# ---------------------------------------------------------------------------
# React entry modules (HashRouter-wrapped)
# ---------------------------------------------------------------------------

_REACT_MAIN_BODY = """import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { HashRouter, Routes, Route } from 'react-router-dom'
import './index.css'
import App from './App.__APP_EXT__'

createRoot(document.getElementById('root')__NOT_NULL__).render(
  <StrictMode>
    <HashRouter>
      <Routes>
        <Route path="/" element={<App />} />
      </Routes>
    </HashRouter>
  </StrictMode>,
)
"""

_REACT_SETTINGS_BODY = """import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { HashRouter, Routes, Route } from 'react-router-dom'

function Settings() {
  return (
    <div style={{ padding: '2rem' }}>
      <p>Adjust these options to taste.</p>
    </div>
  )
}

createRoot(document.getElementById('root')__NOT_NULL__).render(
  <StrictMode>
    <HashRouter>
      <Routes>
        <Route path="/" element={<Settings />} />
      </Routes>
    </HashRouter>
  </StrictMode>,
)
"""


def render_react_entry(template: str, page: str) -> str:
    """Return the contents of src/main.(j|t)sx or src/settings.(j|t)sx.

    Wraps the page component in <HashRouter> by default.
    """
    is_ts = template == "react-ts"
    app_ext = "tsx" if is_ts else "jsx"
    not_null = "!" if is_ts else ""
    body = _REACT_MAIN_BODY if page == "index" else _REACT_SETTINGS_BODY
    return body.replace("__APP_EXT__", app_ext).replace("__NOT_NULL__", not_null)


# ---------------------------------------------------------------------------
# Vanilla settings entry (minimal, no router)
# ---------------------------------------------------------------------------

_VANILLA_SETTINGS = """document.querySelector('#root').innerHTML = `
  <div style="padding: 2rem">
    <p>Adjust these options to taste.</p>
  </div>
`
"""


def render_vanilla_settings_entry(template: str) -> str:
    return _VANILLA_SETTINGS
