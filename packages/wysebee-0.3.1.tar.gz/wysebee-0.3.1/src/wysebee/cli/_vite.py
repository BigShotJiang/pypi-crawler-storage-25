"""Shared Vite setup helpers: fresh vite.config.js + multi-page entries."""

import subprocess
from pathlib import Path

from colorama import Fore

from .templates import (
    render_page_html,
    render_react_entry,
    render_vanilla_settings_entry,
)


def _vite_config(template: str, platform: str) -> str:
    """Return a fresh vite.config.js body for the given template + platform.

    - Desktop uses base './' so the PySide WebView can load assets via file:// URLs.
    - Web uses base '/' so both `/` and `/settings` can share absolute asset paths.
    """
    base = "./" if platform == "desktop" else "/"
    is_react = template in ("react", "react-ts")

    plugin_import = "import react from '@vitejs/plugin-react'\n" if is_react else ""
    plugins_line = "  plugins: [react()],\n" if is_react else ""

    return f"""import {{ defineConfig }} from 'vite'
{plugin_import}
// https://vitejs.dev/config/
export default defineConfig({{
{plugins_line}  base: '{base}',
  build: {{
    outDir: 'templates',
    emptyOutDir: true,
    rollupOptions: {{
      input: {{
        main: 'index.html',
        settings: 'settings.html',
      }},
    }},
  }},
}})
"""


def setup_vite_pages(template: str, platform: str) -> None:
    """Write vite.config.js, index.html, settings.html, and entry modules.

    Assumes the current working directory is the `ui/` folder containing the
    just-initialized Vite project.
    """
    Path("vite.config.js").write_text(_vite_config(template, platform))
    print(Fore.YELLOW + f"Wrote vite.config.js (multi-page, base={'./'if platform == 'desktop' else '/'})")

    Path("index.html").write_text(render_page_html(template, platform, "index"))
    Path("settings.html").write_text(render_page_html(template, platform, "settings"))
    print(Fore.YELLOW + f"Wrote index.html and settings.html for {platform} ({template})")

    if template in ("react", "react-ts"):
        ext = "tsx" if template == "react-ts" else "jsx"
        Path(f"src/main.{ext}").write_text(render_react_entry(template, "index"))
        Path(f"src/settings.{ext}").write_text(render_react_entry(template, "settings"))
        print(Fore.YELLOW + f"Wrote src/main.{ext} and src/settings.{ext} with HashRouter")
    elif template in ("vanilla", "vanilla-ts"):
        ext = "ts" if template == "vanilla-ts" else "js"
        Path(f"src/settings.{ext}").write_text(render_vanilla_settings_entry(template))
        print(Fore.YELLOW + f"Wrote src/settings.{ext}")


def install_router_if_react(template: str) -> None:
    """Install react-router-dom if the template is a react template."""
    if template in ("react", "react-ts"):
        print(Fore.YELLOW + "Installing react-router-dom...")
        subprocess.run(["npm", "install", "react-router-dom"], check=True)
