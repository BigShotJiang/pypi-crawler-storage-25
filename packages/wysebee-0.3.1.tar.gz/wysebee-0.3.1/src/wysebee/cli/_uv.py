import shutil
import subprocess
from pathlib import Path

from colorama import Fore


def ensure_uv_available() -> bool:
    """Return True if `uv` is on PATH, otherwise print an error and return False."""
    if shutil.which("uv") is None:
        print(
            Fore.RED
            + "uv is not installed or not on PATH. Install it from https://docs.astral.sh/uv/ and re-run."
        )
        return False
    return True


def bootstrap_uv_project(project_dir: Path) -> bool:
    """Run `uv venv` and `uv sync` inside the given project directory."""
    if not ensure_uv_available():
        return False
    try:
        print(Fore.YELLOW + f"Creating virtualenv in {project_dir} with uv...")
        subprocess.run(["uv", "venv"], cwd=project_dir, check=True)
        print(Fore.YELLOW + f"Installing dependencies in {project_dir} with uv...")
        subprocess.run(["uv", "sync"], cwd=project_dir, check=True)
        return True
    except subprocess.CalledProcessError as e:
        print(Fore.RED + f"uv bootstrap failed: {e}")
        return False
