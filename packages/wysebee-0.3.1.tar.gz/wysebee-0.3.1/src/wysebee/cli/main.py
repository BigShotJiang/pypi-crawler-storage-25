import typer
from colorama import init as colorama_init, Fore
from pathlib import Path
import subprocess
import sys
import os

from .desktop import generate_desktop_app
from .server import generate_server_app

colorama_init(autoreset=True)
app = typer.Typer()


@app.callback()
def main_callback(
    ctx: typer.Context,
    web: bool = typer.Option(False, "--web", help="Target the web/server app"),
    desktop: bool = typer.Option(False, "--desktop", help="Target the desktop app"),
):
    if web and desktop:
        print(Fore.RED + "Cannot specify both --web and --desktop")
        raise typer.Exit(code=1)
    ctx.ensure_object(dict)
    ctx.obj["app_type"] = "web" if web else "desktop" if desktop else None


@app.command()
def init(
    name: str,
    template: str = typer.Option(
        "react", "--template", help="Template to use: react, react-ts, vanilla, vanilla-ts"
    )
):
    if not template in ["react", "react-ts", "vanilla", "vanilla-ts"]:
        print(
            Fore.RED
            + f"Invalid template '{template}'. Please choose from: react, react-ts, vanilla, vanilla-ts"
        )
        raise typer.Exit(code=1)

    app_type = typer.prompt(
        "What type of app would you like to create? (desktop/web)",
        default="desktop",
    ).strip().lower()
    if app_type not in ["desktop", "web"]:
        print(Fore.RED + f"Invalid app type '{app_type}'. Please choose 'desktop' or 'web'.")
        raise typer.Exit(code=1)

    # Resolve a project name for pyproject.toml — when `name` is a path like "."
    # we still need a valid package name.
    if name == "." or not name.replace("-", "").replace("_", "").isalnum():
        project_name = typer.prompt(
            "What would you like to name the project?",
            default="my-first-app",
        ).strip()
    else:
        project_name = name

    print(Fore.YELLOW + f"Creating {app_type} app {project_name}")
    # Create the main app directory
    app_dir = Path(name)
    app_dir.mkdir(parents=True, exist_ok=True)

    # Create the ui subfolder
    ui_dir = app_dir / "ui"
    ui_dir.mkdir(exist_ok=True)
    print(Fore.YELLOW + f"Created ui folder in {name}")

    if app_type == "web":
        generate_server_app(name, app_dir, ui_dir, template, project_name)
    else:
        generate_desktop_app(name, app_dir, ui_dir, template, project_name)


def detect_available_app_types():
    """Return list of app types whose folders exist in the current project."""
    found = []
    if (Path("server") / "main.py").exists():
        found.append("web")
    if (Path("desktop") / "main.py").exists():
        found.append("desktop")
    return found


def resolve_app_type(selected):
    available = detect_available_app_types()
    if selected:
        if selected not in available:
            print(Fore.RED + f"No {selected} app found in this project.")
            raise typer.Exit(code=1)
        return selected
    if len(available) == 1:
        return available[0]
    if len(available) == 0:
        # Fallback: legacy layout with main.py at the root
        main_py = Path("main.py")
        if main_py.exists() and "fastapi" in main_py.read_text().lower():
            return "web"
        return "desktop"
    # both present — prompt
    choice = typer.prompt(
        "Both 'server/' and 'desktop/' found. Which do you want to run? (web/desktop)",
        default="desktop",
    ).strip().lower()
    if choice not in ("web", "desktop"):
        print(Fore.RED + f"Invalid choice '{choice}'.")
        raise typer.Exit(code=1)
    return choice


@app.command()
def dev(ctx: typer.Context):
    build_ui()
    selected = ctx.obj.get("app_type") if ctx.obj else None
    app_type = resolve_app_type(selected)
    if app_type == "web":
        print(Fore.YELLOW + "Starting FastAPI development server...")
        process = subprocess.Popen(
            ["uv", "run", "uvicorn", "main:app", "--reload"],
            cwd="server",
        )
    else:
        process = subprocess.Popen(
            ["uv", "run", "python", "main.py", "--dev"],
            cwd="desktop",
        )
    try:
        process.wait()
    except KeyboardInterrupt:
        print(Fore.YELLOW + "Stopping development server...")
        process.terminate()


def build_ui():
    original_dir = os.getcwd()
    app_dir = Path(original_dir)
    app_name = app_dir.name
    print(Fore.GREEN + f"Building UI for {app_name}!")

    ui_dir = app_dir / "ui"
    if ui_dir.exists():
        os.chdir(ui_dir)
        try:
            subprocess.run(["npm", "run", "build"], check=True)
            print(Fore.GREEN + f"Successfully built UI for {app_name}!")
        except subprocess.CalledProcessError as e:
            print(Fore.RED + f"Error building UI: {e}")
        finally:
            os.chdir(original_dir)
    else:
        print(
            Fore.RED
            + f"UI directory not found at {ui_dir}. Make sure you're in the correct project directory."
        )


@app.command()
def build(ui: bool = typer.Option(False, "--ui", help="Only build the UI portion")):
    if ui:
        build_ui()
    else:
        typer.echo(f"Building app!")
        # Add full build logic here


def app_web():
    sys.argv.insert(1, "--web")
    app()


def app_desktop():
    sys.argv.insert(1, "--desktop")
    app()


if __name__ == "__main__":
    app()
