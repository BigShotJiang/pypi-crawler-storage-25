# Publishing hyperclast-mcp to PyPI

## First-time setup

1. Create a PyPI account at https://pypi.org/account/register/
2. Create an API token at https://pypi.org/manage/account/token/ (scope it to the `hyperclast-mcp` project after the first upload)

## Publishing

1. Bump the version in `pyproject.toml`
2. Build and publish:

```bash
cd mcp
uv build
uv publish --token pypi-YOUR_TOKEN
```

3. Verify: `uvx hyperclast-mcp@latest --help`

## Notes

- First upload can use an unscoped token; after that, create a project-scoped token
- `uv build` outputs to `dist/` — you can inspect the `.whl` and `.tar.gz` before publishing
- Published versions are immutable on PyPI — if you make a mistake, bump the version and publish again
