from typing import Iterator
import geopandas as gpd

def chunk_gdf(gdf: gpd.GeoDataFrame, size: int = 500) -> Iterator[gpd.GeoDataFrame]:
    n = len(gdf)
    for i in range(0, n, size):
        yield gdf.iloc[i : i + size]
