# Import necessary modules
import html as html_lib
import json
import re
from typing import Dict, List, Optional
from pydantic import BaseModel

from dhisana.schemas.sales import CampaignContext, ContentGenerationContext, ConversationContext, Lead, MessageGenerationInstructions, MessageItem, SenderInfo
from dhisana.utils.generate_structured_output_internal import (
    get_structured_output_internal,
    get_structured_output_with_assistant_and_vector_store
)
from datetime import datetime
from pydantic import BaseModel, ConfigDict

# ---------------------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------------------
DEFAULT_EMAIL_GEN_MODEL = "gpt-5.4"


# -----------------------------------------------------------------------------
# Email Copy schema
# -----------------------------------------------------------------------------
class EmailCopy(BaseModel):
    subject: str
    body: str
    body_html: Optional[str] = None
 
    model_config = ConfigDict(extra="forbid")


# Phone-number pattern used to redact lead phone numbers from the prompt
_PHONE_RE = re.compile(r"(\+?\d[\d\-.\s()]{7,}\d)")

# Large blobs that should never be forwarded into the email-generation prompt
_FULL_EXPORT_EXCLUDED_ADDITIONAL = {
    "pc_person_data",
    "pc_company_data",
    "apollo_person_data",
    "apollo_company_data",
}


def _sanitize_lead_for_prompt(lead: "Lead") -> str:
    """Return a clean JSON string of lead data suitable for an LLM prompt.

    * Serialises via model_dump / dict → json.dumps so the model sees real
      JSON (not Python repr with UUID(...), None, etc.).
    * Redacts the 'phone' field and scrubs phone-shaped strings from
      'research_summary' to prevent the model from leaking lead phone
      numbers into the generated email.
    """
    data = lead.model_dump() if hasattr(lead, "model_dump") else lead.dict()

    # Redact explicit phone field
    if "phone" in data:
        data["phone"] = "[redacted]"

    # Scrub phone patterns from research_summary
    if data.get("research_summary"):
        data["research_summary"] = _PHONE_RE.sub("[redacted]", data["research_summary"])

    # Strip bulky raw-export blobs from additional_properties
    ap = data.get("additional_properties")
    if isinstance(ap, dict):
        for key in _FULL_EXPORT_EXCLUDED_ADDITIONAL:
            ap.pop(key, None)

    return json.dumps(data, indent=2, default=str)


def _html_to_plain_text(html_content: str) -> str:
    """Simple HTML to text conversion to backfill plain body."""
    if not html_content:
        return ""
    text = html_content
    # Block-level tags → newlines
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</(?:p|div|tr|h[1-6]|li|blockquote)>", "\n", text, flags=re.IGNORECASE)
    # Remove remaining tags
    text = re.sub(r"<[^>]+>", " ", text)
    text = html_lib.unescape(text)
    # Collapse whitespace per line, drop blank lines
    lines = [line.strip() for line in text.splitlines()]
    return "\n".join(line for line in lines if line)

# -----------------------------------------------------------------------------
# Utility to Clean Up Context (if needed)
# -----------------------------------------------------------------------------
def cleanup_email_context(email_context: ContentGenerationContext) -> ContentGenerationContext:
    """
    Return a copy of ContentGenerationContext without sensitive or irrelevant fields.
    Modify or remove fields as necessary for your project.
    """
    clone_context = email_context.copy(deep=True)
    # For demonstration, no sensitive fields in new classes by default.
    # Adjust if you want to remove certain fields (like 'sender_bio', etc.).
    if clone_context.external_known_data:
        clone_context.external_known_data.external_openai_vector_store_id = None
    return clone_context

# -----------------------------------------------------------------------------
# Known Framework Variations (fallback if user instructions are not provided)
# -----------------------------------------------------------------------------
FRAMEWORK_VARIATIONS = [
    "Use PAS (Problem, Agitate, Solve) framework to write up the email.",
    "Use VETO framework (Value, Evidence, Tie, Offer). Highlight how our product addresses the company's current goals.",
    "Use AIDA framework (Attention, Interest, Desire, Action) to compose the email.",
    "Use SPIN (Situation, Problem, Implication, Need-Payoff) framework to write the email.",
    "Use BANT (Budget, Authority, Need, Timeline) framework to write the email.",
    "Use P-S-B (Pain, Solution, Benefit) with a 3-Bullet Approach. Keep it concise.",
    "Use Hook, Insight, Offer framework to write the email."
]

# -----------------------------------------------------------------------------
# Core function to generate an email copy (single-step)
# -----------------------------------------------------------------------------
async def generate_personalized_email_copy(
    email_context: ContentGenerationContext,
    message_instructions: MessageGenerationInstructions,
    variation_text: str,
    tool_config: Optional[List[Dict]] = None,
) -> dict:
    """
    Generate a personalized email in a single LLM call.
    Passes all lead, sender, campaign, and conversation context directly
    to the model and returns the final email.
    """
    cleaned_context = cleanup_email_context(email_context)

    # Decide final instructions: user-provided or fallback variation
    user_custom_instructions = (message_instructions.instructions_to_generate_message or "").strip()
    selected_instructions = user_custom_instructions if user_custom_instructions else variation_text

    # Pull out fields or fallback to empty if None
    lead_data = cleaned_context.lead_info or Lead()
    sender_data = cleaned_context.sender_info or SenderInfo()
    campaign_data = cleaned_context.campaign_context or CampaignContext()
    conversation_data = cleaned_context.current_conversation_context or ConversationContext()

    allow_html = getattr(message_instructions, "allow_html", False)

    html_template_note = ""
    if allow_html and getattr(message_instructions, "html_template", None):
        html_template_note = f"\nHTML Template to follow: {message_instructions.html_template}"

    if allow_html:
        output_requirements = """
        OUTPUT REQUIREMENTS:
        -  Fill the email "subject", "body", and "body_html" fields in output.
        - "body_html" should be clean HTML suitable for email (no external assets), inline styles welcome.
        - "body" must be the plain-text equivalent of "body_html".
        """
    else:
        output_requirements = """
        OUTPUT REQUIREMENTS:
        - Output must be JSON with "subject" and "body" fields only.
        - In the subject or body DO NOT include any HTML tags like <a>, <b>, <i>, etc.
        - The body and subject should be in plain text.
        - If there is a link provided, use it as is without wrapping in any HTML tags.
        """

    email_prompt = f"""You are an AI sales copywriter. Your task is to write exactly one personalized outbound business email on behalf of the sender to the lead described below.

## Rules

1. Ground every claim in the provided context only. When information is missing, omit it — never guess or fabricate.
2. The "body" field must contain ONLY the email text. Never append JSON, metadata, dictionaries, or structured data to the body.
3. Do not use em dashes. Do not include internal references, notes, or content identifiers.
4. body is a well formatted email with proper greeting and signature.

## Lead

Name: {lead_data.first_name or ''} {lead_data.last_name or ''}
Organization: {lead_data.organization_name or ''}
Title: {lead_data.job_title or ''}

## Sender (closed set — use ONLY these facts)

The fields below are the ONLY facts you may use about the sender. If a field is blank or missing, it is unknown — omit it, do not infer or invent a value.

- Full Name: {sender_data.sender_full_name or ''}
- First Name: {sender_data.sender_first_name or ''}
- Last Name: {sender_data.sender_last_name or ''}
- Email: {sender_data.sender_email or ''}
- Bio: {sender_data.sender_bio or ''}
- Booking URL: {sender_data.sender_appointment_booking_url or ''}

**Never invent** phone numbers, direct lines, office numbers, mobile numbers, job titles, company names, locations, addresses, social handles, alternate emails, meeting links, websites, or any contact detail not listed above.

## Campaign

- Product: {campaign_data.product_name or ''}
- Value Proposition: {campaign_data.value_prop or ''}
- Call to Action: {campaign_data.call_to_action or ''}
- Pain Points: {campaign_data.pain_points or []}
- Proof Points: {campaign_data.proof_points or []}
- Email Triage Guidelines: {campaign_data.email_triage_guidelines or ''}
- LinkedIn Triage Guidelines: {campaign_data.linkedin_triage_guidelines or ''}

## Writing Instructions

{selected_instructions}{html_template_note}

## Signature Rules

- Use sender first name if available, otherwise full name, otherwise omit.
- Do NOT add phone numbers, email addresses, titles, company addresses, or booking links to the signature unless the writing instructions explicitly ask for a specific provided field.
- Phone numbers appearing in the lead context belong to the lead, not the sender — never include them in the email.

## Output Format
{output_requirements}

## Additional Lead Context

The data below is for reference only — do NOT echo, copy, or reproduce it in your output.

{_sanitize_lead_for_prompt(lead_data)}

## Conversation History

Email Thread: {conversation_data.current_email_thread or ''}
LinkedIn Thread: {conversation_data.current_linkedin_thread or ''}
"""

    # Check if a vector store is available
    vector_store_id = (email_context.external_known_data.external_openai_vector_store_id
                       if email_context.external_known_data else None)
    use_cache = email_context.message_instructions.use_cache if email_context.message_instructions else True

    if vector_store_id:
        email_response, email_status = await get_structured_output_with_assistant_and_vector_store(
            prompt=email_prompt,
            response_format=EmailCopy,
            vector_store_id=vector_store_id,
            model=DEFAULT_EMAIL_GEN_MODEL,
            effort="medium",
            tool_config=tool_config,
            use_cache=use_cache
        )
    else:
        email_response, email_status = await get_structured_output_internal(
            prompt=email_prompt,
            response_format=EmailCopy,
            model=DEFAULT_EMAIL_GEN_MODEL,
            effort="medium",
            tool_config=tool_config,
            use_cache=use_cache
        )

    if email_status != "SUCCESS":
        raise Exception("Error: Could not generate email.")

    plain_body = email_response.body
    html_body = getattr(email_response, "body_html", None)
    if not plain_body and html_body:
        plain_body = _html_to_plain_text(html_body)

    response_item = MessageItem(
        message_id="",  # or some real ID if you have it
        thread_id="",
        sender_name=email_context.sender_info.sender_full_name or "",
        sender_email=email_context.sender_info.sender_email or "",
        receiver_name=email_context.lead_info.full_name or "",
        receiver_email=email_context.lead_info.email or "",
        iso_datetime=datetime.utcnow().isoformat(),
        subject=email_response.subject,
        body=plain_body,
        html_body=html_body if getattr(message_instructions, "allow_html", False) else None,
    )
    return response_item.model_dump()

# -----------------------------------------------------------------------------
# Primary function to generate multiple variations
# -----------------------------------------------------------------------------
async def generate_personalized_email(
    generation_context: ContentGenerationContext,
    number_of_variations: int = 3,
    tool_config: Optional[List[Dict]] = None
) -> List[dict]:
    """
    Generates multiple personalized email variations based on the given context and instructions.

    Parameters:
        - email_context: The consolidated context for email generation.
        - message_instructions: User-supplied instructions or templates for generating the message.
        - number_of_variations: How many email variations to produce.
        - tool_config: Optional tool configuration for the LLM calls.

    Returns:
        A list of dictionaries, each containing:
          {
            "subject": "string",
            "body": "string"
          }
    """
    email_variations = []
    message_instructions = generation_context.message_instructions 
    user_instructions_exist = bool(
        (message_instructions.instructions_to_generate_message or "").strip()
    )

    for i in range(number_of_variations):
        try:
            # If user provided instructions, use them for each variation
            # (skip the internal frameworks).
            if user_instructions_exist:
                variation_text = message_instructions.instructions_to_generate_message or ""
            else:
                # Otherwise, pick from known frameworks (circular indexing)
                variation_text = FRAMEWORK_VARIATIONS[i % len(FRAMEWORK_VARIATIONS)]

            email_copy = await generate_personalized_email_copy(
                email_context=generation_context,
                message_instructions=message_instructions,
                variation_text=variation_text,
                tool_config=tool_config
            )
            email_variations.append(email_copy)

        except Exception as e:
            raise e
    return email_variations
