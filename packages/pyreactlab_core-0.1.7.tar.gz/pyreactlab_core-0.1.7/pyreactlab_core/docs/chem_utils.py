# import libs
import logging
from typing import List, Optional, Tuple, Dict
from pythermodb_settings.models import Component, ComponentKey
from pythermodb_settings.utils import set_component_id
# locals
from ..models.reaction import Reaction
from ..utils.component_tools import map_component_ids

# NOTE: configure logger
logger = logging.getLogger(__name__)


def build_stoichiometry_matrix(
        reactions: List[Reaction],
        components: Optional[List[Component]],
        component_key: ComponentKey = "Name-Formula"
):
    '''
    Build stoichiometry matrix for reactions

    Parameters
    ----------
    reactions : List[Reaction]
        List of Reaction instances
    components : Optional[List[Component]]
        List of Component instances
    component_key : ComponentKey
        The key used to identify components in the reaction.

    Returns
    -------
    component_list: list
        component list
    component_dict: dict
        component dict
    comp_list: list
        component list
    comp_coeff: list
        component coefficient
    component_state_list: list
        component state list
    '''
    try:
        # SECTION: extract reaction results
        # NOTE: reaction num
        reaction_num = len(reactions)

        # NOTE: component list
        component_list = []

        # NOTE: component state list
        component_state_list = []

        # SECTION: Iterate over reactions and extract reactants and products
        for item in reactions:
            # get components
            _components = item.all_components
            # store
            component_list.extend(_components)

        # remove duplicate
        component_list = list(set(component_list))

        # component id: key, value
        component_dict = {}

        # loop over component list
        for i, item in enumerate(component_list):
            component_dict[item] = i

        # SECTION: Initialize the component list
        comp_list = [
            {i: 0.0 for i in component_dict.keys()} for _ in range(reaction_num)
        ]

        # SECTION: Iterate over reactions and components
        for j, reaction in enumerate(reactions):
            for item in component_dict.keys():
                # NOTE: Check reactants
                for reactant in reactions[j].reactants:
                    # matching state
                    if reactant['molecule_state'] == item:
                        comp_list[j][item] = -1 * \
                            float(reactant['coefficient'])

                    # >> component state list
                    component_state_list.append(
                        (
                            reactant['molecule'],
                            reactant['state'],
                            reactant['molecule_state']
                        )
                    )

                # NOTE: Check products
                for product in reactions[j].products:
                    # matching state
                    if product['molecule_state'] == item:
                        comp_list[j][item] = float(product['coefficient'])

                    # >> component state list
                    component_state_list.append(
                        (
                            product['molecule'],
                            product['state'],
                            product['molecule_state']
                        )
                    )

        # Convert comp_list to comp_matrix
        comp_coeff = [
            [comp_list[j][item] for item in component_dict.keys()] for j in range(reaction_num)
        ]

        # NOTE: map component ids to components
        components_ext = {}
        if components is not None:
            components_ext = map_component_ids(
                component_ids=component_list,
                component=components,
                component_key=component_key
            )

        # res
        return {
            "components": components_ext,
            "component_list": component_list,
            "component_dict": component_dict,
            "component_state_list": component_state_list,
            "comp_list": comp_list,
            "comp_coeff": comp_coeff,
        }
    except Exception as e:
        raise Exception(f"Error defining component ID: {e}")


# SECTION: build stoichiometry matrix for reactions
def build_rxn_stoichiometry_source(
        reactions: List[Reaction],
        components: List[Component],
        component_key: ComponentKey
) -> Optional[
    Tuple[
        List[Dict[str, float]],
        List[List[float]]
    ]
]:
    try:
        # NOTE: stoichiometry source
        stoichiometry_source = []

    #    iterate over reactions
        for reaction in reactions:
            # stoichiometry
            stoichiometry_ = reaction.reaction_stoichiometry_source.get(
                component_key, {})
            # >> check
            if not stoichiometry_:
                logger.warning(
                    f"Stoichiometry source not found for reaction: {reaction.name}")
                return None

            # store
            stoichiometry_source.append(stoichiometry_)

        # NOTE: map component ids to components
        components_source = [
            set_component_id(
                component=item,
                component_key=component_key
            ) for item in components
        ]

        # NOTE: stoichiometry
        stoichiometry_result: List[Dict[str, float]] = []

        # iterate over stoichiometry source
        for i in range(len(reactions)):
            sto_ = {}
            for item in components_source:
                # raw data
                sto_[item] = 0.0

            # update
            stoichiometry_result.append(sto_)

        # update stoichiometry result
        for i, item in enumerate(stoichiometry_result):
            for key, value in stoichiometry_source[i].items():
                item[key] = value

        # NOTE: create a matrix of stoichiometry
        stoichiometry_result_matrix: List[List[float]] = []
        for item in stoichiometry_result:
            row = []
            for key in components_source:
                row.append(float(item[key]))
            stoichiometry_result_matrix.append(row)

        return stoichiometry_result, stoichiometry_result_matrix
    except Exception as e:
        logger.error(f"Error building reaction stoichiometry source: {e}")
        return None
