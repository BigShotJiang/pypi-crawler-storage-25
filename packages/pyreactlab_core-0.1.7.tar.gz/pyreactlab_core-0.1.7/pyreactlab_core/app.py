# import libs
import logging
from typing import List, Optional, Dict, Tuple
from pythermodb_settings.models import Component, ComponentKey
# locals
from .models.reaction import Reaction
from .docs.chem_utils import build_stoichiometry_matrix, build_rxn_stoichiometry_source

# NOTE: configure logger
logger = logging.getLogger(__name__)


def rxn(
        reaction_str: str,
        name: Optional[str] = None,
) -> Optional[Reaction]:
    """
    Create and analyze a chemical reaction.

    Parameters
    ----------
    reaction_str : str
        reaction expression string such as "A + B => C + D"
    name : Optional[str]
        Name of the reaction

    Returns
    -------
    Reaction
        An instance of the Reaction class containing analysis results.
    """
    try:
        # SECTION: validate inputs
        if not isinstance(reaction_str, str) or not reaction_str.strip():
            logger.error("Invalid reaction string provided.")
            return None

        # check name format
        if name is not None and not isinstance(name, str):
            logger.error("Invalid name format provided.")
            return None

        # SECTION: create Reaction instance
        reaction = Reaction(
            name=name if name else "Unnamed Reaction",
            reaction=reaction_str
        )
        return reaction
    except Exception as e:
        logger.error(f"Error creating Reaction instance: {e}")
        return None


def rxn_stoichiometry_matrix(
        reaction: Reaction,
) -> Optional[List[float]]:
    """
    Get the reaction stoichiometry matrix for a given chemical reaction.

    Parameters
    ----------
    reaction : Reaction
        An instance of the Reaction class.

    Returns
    -------
    Optional[List[float]]
        The reaction stoichiometry matrix if successful, None otherwise.
    """
    try:
        # SECTION: validate inputs
        if not isinstance(reaction, Reaction):
            logger.error("Invalid Reaction instance provided.")
            return None

        # SECTION: retrieve stoichiometry matrix
        if reaction:
            return reaction.reaction_stoichiometry_matrix
        else:
            logger.error("Failed to create Reaction instance.")
            return None
    except Exception as e:
        logger.error(f"Error retrieving reaction stoichiometry matrix: {e}")
        return None


def rxns_stoichiometry(
        reactions: List[Reaction],
        components: Optional[List[Component]] = None,
        component_key: ComponentKey = "Name-Formula"
) -> Optional[Dict]:
    """
    Get the reaction stoichiometry matrices for a list of chemical reactions.

    Parameters
    ----------
    reactions : List[Reaction]
        List of Reaction instances.

    Returns
    -------
    Optional[List[List[float]]]
        List of reaction stoichiometry matrices if successful, None otherwise.
    """
    try:
        # SECTION: validate inputs
        if (
            not isinstance(reactions, list) or
            not all(isinstance(rxn, Reaction) for rxn in reactions)
        ):
            logger.error("Invalid reactions list provided.")
            return None

        # SECTION: retrieve stoichiometry matrices
        result = build_stoichiometry_matrix(
            reactions=reactions,
            components=components,
            component_key=component_key
        )

        # NOTE: res
        return {
            "components": result["components"],
            "component_list": result["component_list"],
            "component_ids": result["component_dict"],
            "stoichiometry_matrices_list": result["comp_coeff"],
            "stoichiometry_matrices_dict": result["comp_list"],
        }
    except Exception as e:
        logger.error(f"Error retrieving reaction stoichiometry matrices: {e}")
        return None

# SECTION: Build stoichiometry for reactions


def build_rxns_stoichiometry(
    reactions: List[Reaction],
    components: List[Component],
    component_key: ComponentKey
) -> Optional[
    Dict[str, List[Dict[str, float]] | List[List[float]]]
]:
    """
    Build the reaction stoichiometry matrices for a list of chemical reactions.

    Parameters
    ----------
    reactions : List[Reaction]
        List of Reaction instances.
    components : List[Component]
        List of all components involved in the reactions.
    component_key : ComponentKey
        The key to use for mapping components (e.g., "Name-Formula").

    Returns
    -------
    Optional[Dict[str, List[Dict[str, float]] | List[List[float]]]]
        A dictionary containing the stoichiometry source and matrices if successful, None otherwise. The dictionary has the following structure:
        - "source": List[Dict[str, float]] - A list of dictionaries representing the stoichiometry source for each reaction.
        - "matrix": List[List[float]] - A list of stoichiometry matrices corresponding to each reaction.
    """
    try:
        # SECTION: validate inputs
        if (
            not isinstance(reactions, list) or
            not all(isinstance(rxn, Reaction) for rxn in reactions)
        ):
            logger.error("Invalid reactions list provided.")
            return None

        if (
            not isinstance(components, list) or
            not all(isinstance(comp, Component) for comp in components)
        ):
            logger.error("Invalid components list provided.")
            return None

        # SECTION: build stoichiometry source
        stoichiometry_source = build_rxn_stoichiometry_source(
            reactions=reactions,
            components=components,
            component_key=component_key
        )

        # >> check
        if not stoichiometry_source:
            logger.error("Failed to build reaction stoichiometry source.")
            return None

        # result
        res = {
            "source": stoichiometry_source[0],
            "matrix": stoichiometry_source[1]
        }

        return res
    except Exception as e:
        logger.error(f"Error building reaction stoichiometry: {e}")
        return None
