# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.0.7

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.0.6...8b01993d382cb366dd367caa6178d049025f2182))

### Maintenance and upkeep improvements

- Add Licenses [#79](https://github.com/jupyterlab/jupyter-builder/pull/79) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2026-04-10&to=2026-04-11&type=c))

@Darshan808 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3ADarshan808+updated%3A2026-04-10..2026-04-11&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akrassowski+updated%3A2026-04-10..2026-04-11&type=Issues))

<!-- <END NEW CHANGELOG ENTRY> -->

## 0.0.6

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.0.5...14238e2b794d812309b68d597f5a7e6f0179e6f0))

### Maintenance and upkeep improvements

- Remove `jupyterlab` from test dependencies and drop `jupyter_sever` usage. [#78](https://github.com/jupyterlab/jupyter-builder/pull/78) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2026-04-10&to=2026-04-10&type=c))

@Darshan808 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3ADarshan808+updated%3A2026-04-10..2026-04-10&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akrassowski+updated%3A2026-04-10..2026-04-10&type=Issues))

## 0.0.5

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.0.4...2d1c4632d7fb21c3868e20d0fdd785d579b6dd96))

### Maintenance and upkeep improvements

- Add `jupyter-core` as a dependency [#74](https://github.com/jupyterlab/jupyter-builder/pull/74) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Documentation improvements

- Update project URLs in pyproject.toml [#75](https://github.com/jupyterlab/jupyter-builder/pull/75) ([@krassowski](https://github.com/krassowski), [@Darshan808](https://github.com/Darshan808))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2026-04-10&to=2026-04-10&type=c))

@Darshan808 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3ADarshan808+updated%3A2026-04-10..2026-04-10&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akrassowski+updated%3A2026-04-10..2026-04-10&type=Issues))

## 0.0.4

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.0.3...a3fd3ceec6d67a426e94f7077b5bf46786470c82))

### Maintenance and upkeep improvements

- Restore `core-path` flag as mark it as deprecated. [#73](https://github.com/jupyterlab/jupyter-builder/pull/73) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))
- Remove `jupyterlab-server` as a dependency [#72](https://github.com/jupyterlab/jupyter-builder/pull/72) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Documentation improvements

- Setup Proper Documentation [#69](https://github.com/jupyterlab/jupyter-builder/pull/69) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2026-04-01&to=2026-04-10&type=c))

@Darshan808 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3ADarshan808+updated%3A2026-04-01..2026-04-10&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akrassowski+updated%3A2026-04-01..2026-04-10&type=Issues))

## 0.0.3

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.0.2...123e1ff1cb70765da40487f3b435a70d8a6c58da))

### Maintenance and upkeep improvements

- Fix version bump of `@jupyter/builder` npm package [#68](https://github.com/jupyterlab/jupyter-builder/pull/68) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))
- Remove default value for `steps_to_skip` in publish release [#65](https://github.com/jupyterlab/jupyter-builder/pull/65) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2026-03-31&to=2026-04-01&type=c))

@Darshan808 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3ADarshan808+updated%3A2026-03-31..2026-04-01&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akrassowski+updated%3A2026-03-31..2026-04-01&type=Issues))

## 0.0.2

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.1.0a5...5d328483cbf722a959a10876b56e04ddb8fc2a5b))

### Enhancements made

- Rename Package [#60](https://github.com/jupyterlab/jupyter-builder/pull/60) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))
- Build NPM package via releaser [#59](https://github.com/jupyterlab/jupyter-builder/pull/59) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))
- Use `@jupyterlab/core-meta` package [#57](https://github.com/jupyterlab/jupyter-builder/pull/57) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Maintenance and upkeep improvements

- Add build and version badges to README [#63](https://github.com/jupyterlab/jupyter-builder/pull/63) ([@krassowski](https://github.com/krassowski), [@Darshan808](https://github.com/Darshan808))
- Make builder public and fix URLs in package.json [#62](https://github.com/jupyterlab/jupyter-builder/pull/62) ([@krassowski](https://github.com/krassowski), [@Darshan808](https://github.com/Darshan808))
- Workaround to make pre-releases check green [#56](https://github.com/jupyterlab/jupyter-builder/pull/56) ([@krassowski](https://github.com/krassowski), [@Darshan808](https://github.com/Darshan808))
- Clean and rename to `BuilderApp` [#55](https://github.com/jupyterlab/jupyter-builder/pull/55) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))
- Migrate to `rspack` [#54](https://github.com/jupyterlab/jupyter-builder/pull/54) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2026-02-22&to=2026-03-31&type=c))

@Darshan808 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3ADarshan808+updated%3A2026-02-22..2026-03-31&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akrassowski+updated%3A2026-02-22..2026-03-31&type=Issues))

## 0.1.0a5

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.1.0a4...88ec34f5d3708e44b2f84a922a0a4f2e612f57f9))

### Enhancements made

- Use github to get core meta [#51](https://github.com/jupyterlab/jupyter-builder/pull/51) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2026-02-05&to=2026-02-22&type=c))

@Darshan808 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3ADarshan808+updated%3A2026-02-05..2026-02-22&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akrassowski+updated%3A2026-02-05..2026-02-22&type=Issues))

## 0.1.0a4

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.1.0a3...2e9b6382798d488315617750333cc50f5a445b5c))

### Enhancements made

- Sync `yarn.js` with core [#47](https://github.com/jupyterlab/jupyter-builder/pull/47) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))
- Add `jupyterlab_server` and update some dependencies [#44](https://github.com/jupyterlab/jupyter-builder/pull/44) ([@Darshan808](https://github.com/Darshan808), [@krassowski](https://github.com/krassowski))
- Migrated Builder Folder to jupyter-builder [#29](https://github.com/jupyterlab/jupyter-builder/pull/29) ([@Darshan808](https://github.com/Darshan808), [@fcollonval](https://github.com/fcollonval), [@jtpio](https://github.com/jtpio))

### Maintenance and upkeep improvements

- Bump the actions group across 1 directory with 6 updates [#39](https://github.com/jupyterlab/jupyter-builder/pull/39) ([@krassowski](https://github.com/krassowski))
- Bump ruff from 0.9.9 to 0.11.2 in the pip group [#36](https://github.com/jupyterlab/jupyter-builder/pull/36) ([@krassowski](https://github.com/krassowski))
- Bump ruff from 0.9.4 to 0.9.9 in the pip group [#35](https://github.com/jupyterlab/jupyter-builder/pull/35) ([@fcollonval](https://github.com/fcollonval))
- Bump apache/skywalking-eyes from 0.6.0 to 0.7.0 in the actions group [#34](https://github.com/jupyterlab/jupyter-builder/pull/34) ([@fcollonval](https://github.com/fcollonval))
- Bump ruff from 0.8.4 to 0.9.4 in the pip group [#33](https://github.com/jupyterlab/jupyter-builder/pull/33) ([@jtpio](https://github.com/jtpio))
- Bump ruff from 0.8.1 to 0.8.4 in the pip group [#32](https://github.com/jupyterlab/jupyter-builder/pull/32) ([@fcollonval](https://github.com/fcollonval))
- Bump ruff from 0.7.1 to 0.8.1 in the pip group [#31](https://github.com/jupyterlab/jupyter-builder/pull/31) ([@jtpio](https://github.com/jtpio))
- Bump ruff from 0.6.8 to 0.7.1 in the pip group [#30](https://github.com/jupyterlab/jupyter-builder/pull/30) ([@fcollonval](https://github.com/fcollonval))
- Bump ruff from 0.5.5 to 0.6.8 in the pip group across 1 directory [#28](https://github.com/jupyterlab/jupyter-builder/pull/28) ([@fcollonval](https://github.com/fcollonval))

### Documentation improvements

- Update README.md 2 [#26](https://github.com/jupyterlab/jupyter-builder/pull/26) ([@cronan03](https://github.com/cronan03), [@fcollonval](https://github.com/fcollonval))

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2024-07-30&to=2026-02-05&type=c))

@cronan03 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Acronan03+updated%3A2024-07-30..2026-02-05&type=Issues)) | @Darshan808 ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3ADarshan808+updated%3A2024-07-30..2026-02-05&type=Issues)) | @fcollonval ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Afcollonval+updated%3A2024-07-30..2026-02-05&type=Issues)) | @jtpio ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Ajtpio+updated%3A2024-07-30..2026-02-05&type=Issues)) | @krassowski ([activity](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akrassowski+updated%3A2024-07-30..2026-02-05&type=Issues))

## 0.1.0a3

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/v0.1.0a2...464a12d6a8288e06646f0c364ee1477d643c7261))

### Maintenance and upkeep improvements

- Bump ruff from 0.4.7 to 0.5.5 in the pip group across 1 directory [#24](https://github.com/jupyterlab/jupyter-builder/pull/24) ([@dependabot](https://github.com/dependabot))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2024-07-29&to=2024-07-30&type=c))

[@dependabot](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Adependabot+updated%3A2024-07-29..2024-07-30&type=Issues)

## 0.1.0a2

([Full Changelog](https://github.com/jupyterlab/jupyter-builder/compare/ac6bb51518d309b96658dc45784f4d47a7cd559c...02764ce51fd919bdb5739e06d545656ee0e5b2c9))

### Enhancements made

- Include jlpm within this package (Issue #15) [#20](https://github.com/jupyterlab/jupyter-builder/pull/20) ([@cronan03](https://github.com/cronan03))
- Watch feature and tests [#18](https://github.com/jupyterlab/jupyter-builder/pull/18) ([@cronan03](https://github.com/cronan03))
- Build feature and Tests [#13](https://github.com/jupyterlab/jupyter-builder/pull/13) ([@cronan03](https://github.com/cronan03))
- Develop command working [#11](https://github.com/jupyterlab/jupyter-builder/pull/11) ([@cronan03](https://github.com/cronan03))

### Bugs fixed

- Comment npm related release hook [#25](https://github.com/jupyterlab/jupyter-builder/pull/25) ([@fcollonval](https://github.com/fcollonval))

### Maintenance and upkeep improvements

- Scaffolding for adding a npm package and setting up the releaser [#23](https://github.com/jupyterlab/jupyter-builder/pull/23) ([@fcollonval](https://github.com/fcollonval))
- Bump ruff from 0.4.2 to 0.4.7 in the pip group [#9](https://github.com/jupyterlab/jupyter-builder/pull/9) ([@dependabot](https://github.com/dependabot))
- Bump ruff from 0.3.4 to 0.4.2 in the pip group [#7](https://github.com/jupyterlab/jupyter-builder/pull/7) ([@dependabot](https://github.com/dependabot))
- Bump apache/skywalking-eyes from 97538682f556b56cc7422ece660d8d7e6c4fb013 to cd7b195c51fd3d6ad52afceb760719ddc6b3ee91 in the actions group [#6](https://github.com/jupyterlab/jupyter-builder/pull/6) ([@dependabot](https://github.com/dependabot))
- Bump the pip group with 1 update [#5](https://github.com/jupyterlab/jupyter-builder/pull/5) ([@dependabot](https://github.com/dependabot))
- Bump the actions group with 1 update [#4](https://github.com/jupyterlab/jupyter-builder/pull/4) ([@dependabot](https://github.com/dependabot))
- Add skeleton [#2](https://github.com/jupyterlab/jupyter-builder/pull/2) ([@fcollonval](https://github.com/fcollonval))

### Documentation improvements

- Documentation  [#22](https://github.com/jupyterlab/jupyter-builder/pull/22) ([@cronan03](https://github.com/cronan03))

### Contributors to this release

([GitHub contributors page for this release](https://github.com/jupyterlab/jupyter-builder/graphs/contributors?from=2024-03-04&to=2024-07-29&type=c))

[@cronan03](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Acronan03+updated%3A2024-03-04..2024-07-29&type=Issues) | [@dependabot](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Adependabot+updated%3A2024-03-04..2024-07-29&type=Issues) | [@fcollonval](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Afcollonval+updated%3A2024-03-04..2024-07-29&type=Issues) | [@kloczek](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Akloczek+updated%3A2024-03-04..2024-07-29&type=Issues) | [@welcome](https://github.com/search?q=repo%3Ajupyterlab%2Fjupyter-builder+involves%3Awelcome+updated%3A2024-03-04..2024-07-29&type=Issues)
