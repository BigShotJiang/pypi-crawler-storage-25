from __future__ import annotations

import argparse
import json
import os
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


class MissingUsageRegistrySchema(RuntimeError):
    pass


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Sync tracked package functions into Supabase usage counters."
    )
    parser.add_argument(
        "--registry",
        default="function_usage_registry.json",
        help="Path to JSON array of function names.",
    )
    parser.add_argument(
        "--remove-stale",
        action="store_true",
        help="Remove zero-count stale rows and mark nonzero stale rows inactive.",
    )
    args = parser.parse_args()

    supabase_url = _required_env("SUPABASE_URL").rstrip("/")
    service_role_key = _required_env("SUPABASE_SERVICE_ROLE_KEY")
    functions = _load_registry(Path(args.registry))

    payload = json.dumps(
        {
            "p_functions": functions,
            "p_remove_stale": bool(args.remove_stale),
        }
    ).encode("utf-8")
    request = urllib.request.Request(
        f"{supabase_url}/rest/v1/rpc/sync_package_function_usage_registry",
        data=payload,
        headers={
            "apikey": service_role_key,
            "Authorization": f"Bearer {service_role_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            body = response.read().decode("utf-8")
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        if error.code == 404 and "PGRST202" in detail:
            try:
                synced = _sync_registry_table(
                    supabase_url,
                    service_role_key,
                    functions,
                )
            except MissingUsageRegistrySchema as missing_schema:
                print(
                    f"{missing_schema} Apply the package_function_usage "
                    "migration before expecting usage registry rows to sync."
                )
                return 0
            print(
                "sync_package_function_usage_registry RPC is not available; "
                f"upserted {synced} package function usage rows directly."
            )
            if args.remove_stale:
                print(
                    "Skipped stale-row cleanup because direct table sync cannot "
                    "safely reproduce the RPC cleanup without deployed SQL."
                )
            return 0
        raise RuntimeError(
            f"Supabase usage sync failed: {error.code} {detail}"
        ) from error

    print(f"Synced {len(functions)} package function usage rows: {body}")
    return 0


def _required_env(name: str) -> str:
    value = os.getenv(name)
    if value and value.strip():
        return value.strip()
    raise RuntimeError(f"{name} is required")


def _load_registry(path: Path) -> list[str]:
    parsed: Any = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(parsed, list) or not all(
        isinstance(item, str) for item in parsed
    ):
        raise ValueError(f"{path} must contain a JSON array of strings")
    functions = sorted({item.strip() for item in parsed if item.strip()})
    if not functions:
        raise ValueError(f"{path} did not contain any function names")
    return functions


def _sync_registry_table(
    supabase_url: str,
    service_role_key: str,
    functions: list[str],
) -> int:
    payload = json.dumps(
        [
            {"function_name": function_name, "is_active": True}
            for function_name in functions
        ]
    ).encode("utf-8")
    request = urllib.request.Request(
        f"{supabase_url}/rest/v1/package_function_usage?on_conflict=function_name",
        data=payload,
        headers={
            "apikey": service_role_key,
            "Authorization": f"Bearer {service_role_key}",
            "Content-Type": "application/json",
            "Prefer": "resolution=merge-duplicates,return=minimal",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30):
            pass
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        if error.code == 404 and "PGRST205" in detail:
            raise MissingUsageRegistrySchema(
                "package_function_usage table is not available in Supabase."
            ) from error
        raise RuntimeError(
            f"Supabase direct usage registry sync failed: {error.code} {detail}"
        ) from error
    return len(functions)


if __name__ == "__main__":
    raise SystemExit(main())
