# AGENTS.md

## Cursor Cloud specific instructions

This is a Python SDK (`freesolo`) for tracing, evaluating, and training LLM applications. There are no running services — it is a client library that communicates with a remote API.

### Key commands

| Task | Command |
|------|---------|
| Install deps | `uv sync --dev --extra dev` |
| Lint | `uv run ruff check .` |
| Format check | `uv run ruff format --check .` |
| Tests | `uv run pytest tests/ -v` |
| Run example (local) | `PYTHONPATH="$PWD/pypi" uv run python examples/evaluation_custom_scorer.py --local` |

### Notes

- The package source lives under `pypi/freesolo/`, not at the repo root. The `pyproject.toml` sets `packages = ["pypi/freesolo"]` for the wheel build.
- All tests use mocks/monkeypatch — no external services or API keys are needed to run the test suite.
- When running examples outside of tests, set `PYTHONPATH="$PWD/pypi"` so the local source is used.
- The `--local` flag on examples runs scorers locally without requiring `FREESOLO_API_KEY`.
- Dev dependencies (`pytest`, `ruff`) are in the `[project.optional-dependencies] dev` group; use `uv sync --dev --extra dev` to install them.
