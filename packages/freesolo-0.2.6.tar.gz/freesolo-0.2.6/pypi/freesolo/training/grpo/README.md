# GRPO

GRPO uses the repo environment as its attachment point for prompts, rewards, and
response parsing. GRPO hyperparameters live beside SFT hyperparameters in
generated `freesolo/config.py`.

## Public Import

```python
from freesolo.training import GrpoConfig
```

`freesolo.training.grpo` also exports `GrpoConfig` for users already looking in
the GRPO namespace. Other names in this folder are trainer implementation
details.

## Environment Hooks Used By GRPO

Generated `freesolo/environment.py` should implement or override:

- `build_prompt_messages(example, prompt_text)`: build the prompt for each task.
- `score_response(example, response_text)`: score one sampled response.
- `score_responses(example, response_texts)`: optional batched/group reward path;
  must return one `RewardResult` per response.
- `extract_response_text(parsed_message)`: optional renderer-output parser.
- `normalize_response_text(example, response_text)`: optional deterministic
  cleanup before scoring.
- `get_grpo_config() -> GrpoConfig`: return `GRPO_CONFIG` from generated config.

Generated `freesolo/config.py` should define:

```python
from freesolo.training import GrpoConfig

GRPO_CONFIG = GrpoConfig(...)
```

Generated `freesolo/environment.py` should expose it:

```python
from config import GRPO_CONFIG
from freesolo.environments import Environment
from freesolo.training import GrpoConfig


class RepoEnvironment(Environment):
    def get_grpo_config(self) -> GrpoConfig:
        return GRPO_CONFIG
```

## Agent Guidance

- Define GRPO hyperparameters once in `GRPO_CONFIG`; do not duplicate them in
  `freesolo/environment.py` or `freesolo/training.py`.
- GRPO should be called through `train_grpo(...)`; do not call datums, rewards,
  or sampling helpers directly from generated repos.
- If all rewards in a group are identical, GRPO skips that group. Design rewards
  with enough diversity to create trainable groups.
- Log reward diagnostics such as nonzero rate, unique reward count, uniform
  groups, trainable groups, invalid output rate, and representative completions.
- Keep public eval semantics stricter and stable; training reward shaping may be
  auxiliary only when it still pushes toward the approved contract.
