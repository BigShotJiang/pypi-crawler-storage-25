from __future__ import annotations

import asyncio
import os
import re
import time
from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class SamplerState:
    current_path: str | None = None
    session_id: str | None = None


async def ensure_sampling_client(
    *,
    service_client: Any,
    training_client: Any,
    state: SamplerState,
    global_step: int,
    save_every: int,
    conflict_error_type: type[BaseException],
) -> Any:
    save_sampler = (
        state.current_path is None
        or global_step == 0
        or (save_every > 0 and global_step % save_every == 0)
    )
    if save_sampler:
        await save_sampler_checkpoint(
            service_client=service_client,
            training_client=training_client,
            state=state,
            checkpoint_name=_sampler_checkpoint_name(global_step),
            conflict_error_type=conflict_error_type,
        )
    if state.current_path is None:
        raise RuntimeError("Failed to create a sampling checkpoint for GRPO")
    return await asyncio.to_thread(
        service_client.create_sampling_client,
        model_path=state.current_path,
    )


async def save_sampler_checkpoint(
    *,
    service_client: Any,
    training_client: Any,
    state: SamplerState,
    checkpoint_name: str,
    conflict_error_type: type[BaseException],
) -> None:
    max_overwrite_attempts = 2
    for attempt in range(max_overwrite_attempts):
        try:
            sampler_result = await asyncio.to_thread(
                training_client.save_weights_for_sampler(name=checkpoint_name).result
            )
            _record_sampler_path(state, sampler_result.path)
            return
        except conflict_error_type:  # noqa: PERF203
            if attempt < max_overwrite_attempts - 1:
                await _delete_existing_sampler_weights(
                    service_client=service_client,
                    training_client=training_client,
                    state=state,
                    checkpoint_name=checkpoint_name,
                )
                await asyncio.sleep(0.1)
                continue

            unique_checkpoint_name = f"{checkpoint_name}_{int(time.time())}"
            sampler_result = await asyncio.to_thread(
                training_client.save_weights_for_sampler(
                    name=unique_checkpoint_name
                ).result
            )
            _record_sampler_path(state, sampler_result.path)
            return


async def _delete_existing_sampler_weights(
    *,
    service_client: Any,
    training_client: Any,
    state: SamplerState,
    checkpoint_name: str,
) -> None:
    if state.session_id is None:
        try:
            maybe_session_id = getattr(training_client, "session_id", None)
            if maybe_session_id:
                state.session_id = str(maybe_session_id)
        except Exception:
            pass
    if not state.session_id:
        return

    existing_path = (
        f"tinker://{state.session_id}:train:0/sampler_weights/{checkpoint_name}"
    )
    try:
        weights_api = getattr(service_client, "weights", None)
        delete_fn = getattr(weights_api, "delete", None)
        if callable(delete_fn):
            await asyncio.to_thread(delete_fn, path=existing_path)
    except Exception:
        pass


def _record_sampler_path(state: SamplerState, path: str) -> None:
    state.current_path = path
    if state.session_id is None:
        state.session_id = session_id_from_tinker_path(path)


def session_id_from_tinker_path(path: str | None) -> str | None:
    if not path:
        return None
    match = re.match(r"tinker://([^:]+):", str(path))
    return match.group(1) if match else None


def _sampler_checkpoint_name(global_step: int) -> str:
    return f"sample_{global_step:06d}_{os.getpid()}_{time.time_ns()}"
