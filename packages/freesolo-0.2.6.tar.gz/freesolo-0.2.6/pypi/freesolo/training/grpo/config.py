from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class GrpoConfig:
    batch_size: int | None = None
    group_size: int | None = None
    learning_rate: float | None = None
    max_tokens: int | None = None
    num_epochs: int | None = None
    save_every: int | None = None
    temperature: float | None = None
    advantage_clip: float | None = None
    stop_sequences: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ResolvedGrpoConfig:
    batch_size: int
    group_size: int
    learning_rate: float
    max_tokens: int
    num_epochs: int
    save_every: int
    temperature: float
    advantage_clip: float
    stop_sequences: tuple[str, ...]


def resolve_grpo_config(config: GrpoConfig) -> ResolvedGrpoConfig:
    return ResolvedGrpoConfig(
        batch_size=int(config.batch_size if config.batch_size is not None else 4),
        group_size=int(config.group_size if config.group_size is not None else 4),
        learning_rate=float(
            config.learning_rate if config.learning_rate is not None else 5e-6
        ),
        max_tokens=int(config.max_tokens if config.max_tokens is not None else 1024),
        num_epochs=int(config.num_epochs if config.num_epochs is not None else 1),
        save_every=int(config.save_every if config.save_every is not None else 10),
        temperature=float(
            config.temperature if config.temperature is not None else 0.6
        ),
        advantage_clip=float(
            config.advantage_clip if config.advantage_clip is not None else 5.0
        ),
        stop_sequences=tuple(config.stop_sequences),
    )


__all__ = [
    "GrpoConfig",
]
