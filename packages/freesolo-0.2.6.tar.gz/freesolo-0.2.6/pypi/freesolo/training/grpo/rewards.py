from __future__ import annotations

import math

from freesolo.utils.core import coerce_bool, coerce_float


def reward_metrics(rewards: list[float]) -> dict[str, float]:
    if not rewards:
        return {}
    reward_count = len(rewards)
    reward_mean = sum(rewards) / reward_count
    variance = sum((reward - reward_mean) ** 2 for reward in rewards) / reward_count
    return {
        "grpo/reward_count": float(reward_count),
        "grpo/reward_max": max(rewards),
        "grpo/reward_mean": reward_mean,
        "grpo/reward_min": min(rewards),
        "grpo/reward_nonzero_rate": sum(1 for reward in rewards if reward > 0.0)
        / reward_count,
        "grpo/reward_std": math.sqrt(variance),
        "grpo/reward_unique_values": float(len(set(rewards))),
    }


def reward_diagnostics(reward_results: list[object]) -> dict[str, float]:
    if not reward_results:
        return {}

    metadata = [_reward_result_metadata(result) for result in reward_results]
    metadata_count = sum(1 for item in metadata if item)
    bool_metrics: dict[str, list[float]] = {
        "valid_json": [],
        "valid_mongodb": [],
    }
    result_counts: list[float] = []
    judge_scores: list[float] = []
    error_count = 0
    success_count = 0
    judge_called_count = 0

    for result, item in zip(reward_results, metadata, strict=True):
        success = coerce_bool(getattr(result, "success", None))
        if success is True:
            success_count += 1

        valid_json = coerce_bool(item.get("valid_json_filter"))
        if valid_json is not None:
            bool_metrics["valid_json"].append(1.0 if valid_json else 0.0)

        valid_mongodb = coerce_bool(item.get("valid_mongodb_filter"))
        if valid_mongodb is not None:
            bool_metrics["valid_mongodb"].append(1.0 if valid_mongodb else 0.0)

        result_count = coerce_float(item.get("result_count"))
        if result_count is not None:
            result_counts.append(result_count)

        judge_score = coerce_float(item.get("judge_filter_fidelity"))
        if judge_score is not None:
            judge_scores.append(judge_score)

        if item.get("error"):
            error_count += 1
        if (
            valid_json is True
            and valid_mongodb is True
            and result_count
            and result_count > 0
        ):
            judge_called_count += 1

    reward_count = float(len(reward_results))
    diagnostics = {
        "grpo/reward_metadata_rate": metadata_count / reward_count,
        "grpo/reward_success_rate": success_count / reward_count,
        "grpo/reward_error_rate": error_count / reward_count,
        "grpo/reward_judge_called_rate": judge_called_count / reward_count,
    }
    if bool_metrics["valid_json"]:
        diagnostics["grpo/reward_valid_json_rate"] = _mean(bool_metrics["valid_json"])
    if bool_metrics["valid_mongodb"]:
        diagnostics["grpo/reward_valid_mongodb_rate"] = _mean(
            bool_metrics["valid_mongodb"]
        )
    if result_counts:
        diagnostics.update(
            {
                "grpo/reward_result_count_mean": _mean(result_counts),
                "grpo/reward_result_count_min": min(result_counts),
                "grpo/reward_result_count_max": max(result_counts),
                "grpo/reward_zero_result_rate": sum(
                    1.0 for count in result_counts if count == 0
                )
                / len(result_counts),
                "grpo/reward_nonzero_result_rate": sum(
                    1.0 for count in result_counts if count > 0
                )
                / len(result_counts),
            }
        )
    if judge_scores:
        diagnostics.update(
            {
                "grpo/judge_filter_fidelity_mean": _mean(judge_scores),
                "grpo/judge_filter_fidelity_nonzero_rate": sum(
                    1.0 for score in judge_scores if score > 0.0
                )
                / len(judge_scores),
            }
        )
    return diagnostics


def _reward_result_metadata(reward_result: object) -> dict[str, object]:
    metadata = getattr(reward_result, "metadata", None)
    return metadata if isinstance(metadata, dict) else {}


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else 0.0
