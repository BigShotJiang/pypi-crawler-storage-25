from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any

TokenPayload = tuple[list[int], list[float], float]


@dataclass(slots=True)
class GrpoBatchResult:
    training_datums: list[Any] = field(default_factory=list)
    rewards: list[float] = field(default_factory=list)
    reward_results: list[object] = field(default_factory=list)
    response_count: int = 0
    group_count: int = 0
    trainable_group_count: int = 0
    uniform_group_count: int = 0


async def build_grpo_batch_datums(
    *,
    batch: list[Any],
    training_environment: Any,
    contract_text: str,
    renderer: Any,
    sampling_client: Any,
    sampling_params: Any,
    group_size: int,
    advantage_clip: float,
) -> GrpoBatchResult:
    import numpy as np
    from tinker import types
    from tinker.types.tensor_data import TensorData

    result = GrpoBatchResult()
    for example in batch:
        prompt_messages = training_environment.build_prompt_messages(
            example,
            contract_text,
        )
        model_input = renderer.build_generation_prompt(prompt_messages)
        prompt_tokens = model_input.to_ints()
        sample_payloads, response_texts = await sample_group(
            sampling_client=sampling_client,
            renderer=renderer,
            model_input=model_input,
            prompt_tokens=prompt_tokens,
            sampling_params=sampling_params,
            group_size=group_size,
            training_environment=training_environment,
        )

        reward_results = training_environment.score_responses(example, response_texts)
        if len(reward_results) != len(sample_payloads):
            raise RuntimeError(
                "Environment score_responses() must return one RewardResult per sampled response"
            )
        result.reward_results.extend(reward_results)

        rewards: list[float] = []
        rescored_payloads: list[TokenPayload] = []
        for (tokens, logprobs, _), reward_result in zip(
            sample_payloads,
            reward_results,
            strict=True,
        ):
            reward = float(reward_result.score)
            rewards.append(reward)
            result.rewards.append(reward)
            rescored_payloads.append((tokens, logprobs, reward))

        result.response_count += len(response_texts)
        result.group_count += 1
        if not rewards or len(set(rewards)) == 1:
            result.uniform_group_count += 1
            continue

        result.trainable_group_count += 1
        advantages = centered_advantages(rewards, advantage_clip=advantage_clip)
        for (tokens, logprobs, _reward), advantage in zip(
            rescored_payloads,
            advantages,
            strict=True,
        ):
            result.training_datums.append(
                build_importance_sampling_datum(
                    tokens=tokens,
                    logprobs=logprobs,
                    prompt_tokens=prompt_tokens,
                    advantage=advantage,
                    np=np,
                    types=types,
                    TensorData=TensorData,
                )
            )
    return result


async def sample_group(
    *,
    sampling_client: Any,
    renderer: Any,
    model_input: Any,
    prompt_tokens: list[int],
    sampling_params: Any,
    group_size: int,
    training_environment: Any,
) -> tuple[list[TokenPayload], list[str]]:
    sample_futures = [
        sampling_client.sample(
            prompt=model_input,
            num_samples=1,
            sampling_params=sampling_params,
        )
        for _ in range(group_size)
    ]
    sample_results = await asyncio.gather(
        *[asyncio.to_thread(future.result) for future in sample_futures]
    )

    sample_payloads: list[TokenPayload] = []
    response_texts: list[str] = []
    for sample_result in sample_results:
        sampled_tokens = sample_result.sequences[0].tokens
        sampled_logprobs = sample_result.sequences[0].logprobs
        if sampled_logprobs is None:
            raise RuntimeError(
                "Tinker sampler did not return token logprobs required for "
                "importance_sampling"
            )
        parsed_message, _ = renderer.parse_response(sampled_tokens)
        response_text = training_environment.extract_response_text(parsed_message)
        response_texts.append(response_text)
        sample_payloads.append(
            (
                prompt_tokens + sampled_tokens,
                list(sampled_logprobs),
                0.0,
            )
        )
    return sample_payloads, response_texts


def centered_advantages(rewards: list[float], *, advantage_clip: float) -> list[float]:
    reward_mean = sum(rewards) / len(rewards)
    centered = [reward - reward_mean for reward in rewards]
    if advantage_clip <= 0:
        return centered
    return [max(-advantage_clip, min(advantage_clip, value)) for value in centered]


def build_importance_sampling_datum(
    *,
    tokens: list[int],
    logprobs: list[float],
    prompt_tokens: list[int],
    advantage: float,
    np: Any,
    types: Any,
    TensorData: Any,
) -> Any:
    input_tokens = [int(token) for token in tokens[:-1]]
    target_tokens = tokens[1:]
    observation_length = len(prompt_tokens) - 1
    padded_logprobs = [0.0] * observation_length + logprobs
    padded_advantages = [0.0] * observation_length + [advantage] * (
        len(input_tokens) - observation_length
    )
    if not (
        len(input_tokens)
        == len(target_tokens)
        == len(padded_logprobs)
        == len(padded_advantages)
    ):
        raise RuntimeError(
            "GRPO datum lengths do not match: "
            f"input_tokens={len(input_tokens)}, "
            f"target_tokens={len(target_tokens)}, "
            f"logprobs={len(padded_logprobs)}, "
            f"advantages={len(padded_advantages)}"
        )
    return types.Datum(
        model_input=types.ModelInput.from_ints(tokens=input_tokens),
        loss_fn_inputs={
            "target_tokens": TensorData.from_numpy(
                np.asarray(target_tokens, dtype=np.int32)
            ),
            "logprobs": TensorData.from_numpy(
                np.asarray(padded_logprobs, dtype=np.float32)
            ),
            "advantages": TensorData.from_numpy(
                np.asarray(padded_advantages, dtype=np.float32)
            ),
        },
    )
