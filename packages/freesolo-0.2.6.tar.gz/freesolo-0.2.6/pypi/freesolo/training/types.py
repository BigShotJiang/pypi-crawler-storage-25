from dataclasses import dataclass
from pathlib import Path
from typing import Required, TypedDict


@dataclass(frozen=True)
class SftConfig:
    batch_size: int | None = None
    learning_rate: float | None = None
    lora_rank: int | None = None
    max_length: int | None = None
    num_epochs: int | None = None
    save_every: int | None = None


class TrainSftOptions(TypedDict, total=False):
    dataset_path: Required[str | Path]
    contract_path: str | Path
    environment: str | None
    log_dir: str | Path
    base_model: str
    base_url: str | None
    sft_config: SftConfig | None


class TrainGrpoOptions(TypedDict, total=False):
    dataset_path: Required[str | Path]
    contract_path: str | Path
    environment: str | None
    log_dir: str | Path
    sft_log_dir: str | Path
    sft_checkpoint_name: str
    sft_state_path: str | None
    reward_command: str | None
    base_model: str
    base_url: str | None


__all__ = [
    "SftConfig",
    "TrainGrpoOptions",
    "TrainSftOptions",
]
