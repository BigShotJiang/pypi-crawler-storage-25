from .grpo.config import GrpoConfig
from .types import SftConfig, TrainGrpoOptions, TrainSftOptions


def __getattr__(name: str) -> object:
    if name == "train_grpo":
        from .train_grpo import train_grpo

        return train_grpo
    if name == "train_sft":
        from .train_sft import train_sft

        return train_sft
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "GrpoConfig",
    "SftConfig",
    "TrainGrpoOptions",
    "TrainSftOptions",
    "train_grpo",
    "train_sft",
]
