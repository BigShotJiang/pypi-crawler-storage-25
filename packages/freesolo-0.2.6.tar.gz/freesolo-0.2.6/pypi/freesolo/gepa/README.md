# GEPA

GEPA optimizes model-facing prompt or adapter text. It must not edit the
approved training contract.

## Public Imports

```python
from freesolo.gepa import (
    GEPAConfig,
    GEPASetup,
    DefaultReflectionAgent,
    attach_gepa,
    optimize_gepa,
)
```

## Generated Repo Pattern

Generated `freesolo/gepa.py` should:

1. Load config from generated `freesolo/config.py`.
2. Load the environment with `freesolo.environments.load_environment(...)` or by
   passing `ENVIRONMENT_REFERENCE` through setup helpers.
3. Seed the prompt candidate from the approved contract's `prompt.messages` or
   from a repo-level prompt artifact.
4. Attach the environment with `attach_gepa(...)` or
   `GEPASetup.from_environment(...)`.
5. Call `optimize_gepa(...)`.
6. Write selected prompt artifacts under the active run directory.

## Agent Guidance

- GEPA candidates are prompt candidates for rollouts, SFT, GRPO, and eval.
- Store kept GEPA prompt candidates in generated config or run artifacts.
- Do not write GEPA output back into the approved contract markdown.
- Evaluate kept candidates through the same contract-aligned public scorers.
- Do not reimplement GEPA search loops in generated repos.
