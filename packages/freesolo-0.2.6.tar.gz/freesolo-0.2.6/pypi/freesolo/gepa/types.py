from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from freesolo.contracts.markdown import ChatMessage
from freesolo.datasets import TaskExample
from freesolo.environments import Environment, RewardResult
from freesolo.utils.core import JsonValue, MetadataDict

Candidate = dict[str, str]
ReflectiveRecord = dict[str, JsonValue]
ReflectiveDataset = dict[str, list[ReflectiveRecord]]


@dataclass(frozen=True)
class GEPAConfig:
    """Small config object that mirrors GEPA's optimize knobs."""

    max_metric_calls: int = 100
    task_lm: Any | None = None
    evaluator: Any | None = None
    reflection_lm: Any | None = None
    reflection_minibatch_size: int | None = 3
    perfect_score: float = 1.0
    batch_sampler: Any = "epoch_shuffled"
    reflection_prompt_template: str | dict[str, str] | None = None
    custom_candidate_proposer: Any | None = None
    reflection_model: str | None = None
    candidate_selection_strategy: Any = "pareto"
    module_selector: Any = "round_robin"
    frontier_type: Any = "instance"
    skip_perfect_score: bool = True
    use_merge: bool = False
    max_merge_invocations: int = 5
    merge_val_overlap_floor: int = 5
    stop_callbacks: Any | None = None
    logger: Any | None = None
    run_dir: str | None = None
    callbacks: list[Any] | None = None
    use_wandb: bool = False
    wandb_api_key: str | None = None
    wandb_init_kwargs: dict[str, Any] | None = None
    use_mlflow: bool = False
    mlflow_tracking_uri: str | None = None
    mlflow_experiment_name: str | None = None
    seed: int = 0
    track_best_outputs: bool = False
    display_progress_bar: bool = False
    use_cloudpickle: bool = False
    cache_evaluation: bool = False
    raise_on_exception: bool = True
    val_evaluation_policy: Any | None = None


@dataclass(frozen=True)
class EnvironmentGEPAContext:
    """Runtime context passed to user code that executes one GEPA candidate."""

    environment: Environment
    example: TaskExample
    candidate: Candidate
    prompt_text: str
    messages: list[ChatMessage]


@dataclass(frozen=True)
class EnvironmentGEPAOutput:
    response_text: str
    metadata: MetadataDict = field(default_factory=dict)


@dataclass(frozen=True)
class EnvironmentGEPATrajectory:
    example: TaskExample
    candidate: Candidate
    prompt_text: str
    messages: list[ChatMessage]
    response_text: str
    reward: RewardResult
    output_metadata: MetadataDict = field(default_factory=dict)
    error: str | None = None


@dataclass(frozen=True)
class EvaluationBatch:
    outputs: list[EnvironmentGEPAOutput]
    scores: list[float]
    objective_scores: list[dict[str, float]] | None = None
    trajectories: list[EnvironmentGEPATrajectory] | None = None


class EnvironmentRollout(Protocol):
    def __call__(
        self,
        context: EnvironmentGEPAContext,
    ) -> str | EnvironmentGEPAOutput:
        """Execute one candidate on one task example and return model text."""


class ReflectionAgentProtocol(Protocol):
    def propose_new_texts(
        self,
        candidate: Candidate,
        reflective_dataset: ReflectiveDataset,
        components_to_update: list[str],
    ) -> Candidate:
        """Return replacement text for selected GEPA candidate components."""


class ReflectionGenerator(Protocol):
    def __call__(self, prompt: str) -> str:
        """Call a reflection model and return its raw text response."""


__all__ = [
    "GEPAConfig",
    "ReflectionAgentProtocol",
    "ReflectionGenerator",
]
