from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from freesolo.datasets import TaskExample
from freesolo.datasets.records import load_task_examples
from freesolo.datasets.types import DatasetRecord
from freesolo.environments import Environment
from freesolo.utils.wandb import (
    is_wandb_enabled,
    start_wandb_run,
    wandb_api_key_from_env,
)

from .adapter import EnvironmentGEPAAdapter, _make_seed_candidate
from .types import (
    Candidate,
    EnvironmentRollout,
    GEPAConfig,
    ReflectionAgentProtocol,
)


@dataclass
class GEPASetup:
    """Bundle the pieces needed to run GEPA against a Freesolo environment."""

    adapter: EnvironmentGEPAAdapter
    seed_candidate: Candidate
    trainset: list[TaskExample]
    valset: list[TaskExample] | None = None
    config: GEPAConfig = field(default_factory=GEPAConfig)

    @classmethod
    def from_environment(
        cls,
        environment: Environment,
        *,
        rollout: EnvironmentRollout,
        train_source: str | Path | Iterable[TaskExample | DatasetRecord],
        val_source: str | Path | Iterable[TaskExample | DatasetRecord] | None = None,
        seed_candidate: Candidate | None = None,
        prompt_text: str = "",
        prompt_component: str = "prompt",
        reflection_agent: ReflectionAgentProtocol | None = None,
        config: GEPAConfig | None = None,
        failure_score: float = 0.0,
    ) -> GEPASetup:
        resolved_seed = seed_candidate or _make_seed_candidate(
            prompt_text,
            component_name=prompt_component,
        )
        adapter = EnvironmentGEPAAdapter(
            environment=environment,
            rollout=rollout,
            reflection_agent=reflection_agent,
            prompt_component=prompt_component,
            failure_score=failure_score,
        )
        return cls(
            adapter=adapter,
            seed_candidate=resolved_seed,
            trainset=_load_examples(train_source),
            valset=_load_examples(val_source) if val_source is not None else None,
            config=config or GEPAConfig(),
        )

    def optimize(self) -> object:
        return optimize_gepa(
            seed_candidate=self.seed_candidate,
            trainset=self.trainset,
            valset=self.valset,
            adapter=self.adapter,
            config=self.config,
        )


def optimize_gepa(
    *,
    seed_candidate: Candidate,
    trainset: Any,
    adapter: Any | None = None,
    config: GEPAConfig | None = None,
    valset: Any | None = None,
    **gepa_kwargs: Any,
) -> object:
    resolved_config = config or GEPAConfig()
    optimize_kwargs = _gepa_kwargs_from_config(resolved_config)
    optimize_kwargs.update(gepa_kwargs)

    task_lm = optimize_kwargs.get("task_lm")
    reflection_lm = optimize_kwargs.get("reflection_lm")
    custom_candidate_proposer = optimize_kwargs.get("custom_candidate_proposer")

    if adapter is None and task_lm is None:
        raise ValueError(
            "GEPA needs task_lm when no adapter is provided. "
            "For Freesolo environments, pass adapter=attach_gepa(...)."
        )
    if adapter is not None and task_lm is not None:
        raise ValueError("GEPA task_lm must be omitted when adapter is provided.")
    if (
        adapter is not None
        and getattr(adapter, "propose_new_texts", None) is None
        and reflection_lm is None
        and custom_candidate_proposer is None
    ):
        raise ValueError(
            "GEPA needs either a reflection_agent on EnvironmentGEPAAdapter "
            "or GEPAConfig.reflection_lm."
        )

    try:
        import gepa as gepa_package
    except ImportError as exc:
        raise ImportError("The gepa package is required before optimizing.") from exc

    return gepa_package.optimize(
        seed_candidate=seed_candidate,
        trainset=trainset,
        valset=valset,
        adapter=adapter,
        **optimize_kwargs,
    )


def attach_gepa(
    environment: Environment,
    *,
    rollout: EnvironmentRollout,
    reflection_agent: ReflectionAgentProtocol | None = None,
    prompt_component: str = "prompt",
    failure_score: float = 0.0,
) -> EnvironmentGEPAAdapter:
    return EnvironmentGEPAAdapter(
        environment=environment,
        rollout=rollout,
        reflection_agent=reflection_agent,
        prompt_component=prompt_component,
        failure_score=failure_score,
    )


def _load_examples(
    source: str | Path | Iterable[TaskExample | DatasetRecord],
) -> list[TaskExample]:
    return load_task_examples(source)


def _gepa_kwargs_from_config(config: GEPAConfig) -> dict[str, Any]:
    reflection_lm = config.reflection_lm
    if reflection_lm is None and config.reflection_model is not None:
        reflection_lm = config.reflection_model
    use_wandb = config.use_wandb or is_wandb_enabled()
    wandb_init_kwargs = config.wandb_init_kwargs
    if use_wandb:
        wandb_run = start_wandb_run(
            "gepa",
            log_dir=config.run_dir,
            tags=("freesolo", "gepa"),
            config={
                "phase": "gepa",
                "max_metric_calls": config.max_metric_calls,
                "perfect_score": config.perfect_score,
                "seed": config.seed,
                "run_dir": config.run_dir,
                "reflection_model": config.reflection_model,
                "candidate_selection_strategy": str(
                    config.candidate_selection_strategy
                ),
                "frontier_type": str(config.frontier_type),
            },
            wandb_init_kwargs=wandb_init_kwargs,
            enabled=use_wandb,
            start_sdk=False,
        )
        wandb_init_kwargs = wandb_run.init_kwargs

    return {
        "task_lm": config.task_lm,
        "evaluator": config.evaluator,
        "reflection_lm": reflection_lm,
        "candidate_selection_strategy": config.candidate_selection_strategy,
        "frontier_type": config.frontier_type,
        "skip_perfect_score": config.skip_perfect_score,
        "batch_sampler": config.batch_sampler,
        "reflection_minibatch_size": config.reflection_minibatch_size,
        "perfect_score": config.perfect_score,
        "reflection_prompt_template": config.reflection_prompt_template,
        "custom_candidate_proposer": config.custom_candidate_proposer,
        "module_selector": config.module_selector,
        "use_merge": config.use_merge,
        "max_merge_invocations": config.max_merge_invocations,
        "merge_val_overlap_floor": config.merge_val_overlap_floor,
        "max_metric_calls": config.max_metric_calls,
        "stop_callbacks": config.stop_callbacks,
        "logger": config.logger,
        "run_dir": config.run_dir,
        "callbacks": config.callbacks,
        "use_wandb": use_wandb,
        "wandb_api_key": config.wandb_api_key or wandb_api_key_from_env(),
        "wandb_init_kwargs": wandb_init_kwargs,
        "use_mlflow": config.use_mlflow,
        "mlflow_tracking_uri": config.mlflow_tracking_uri,
        "mlflow_experiment_name": config.mlflow_experiment_name,
        "track_best_outputs": config.track_best_outputs,
        "display_progress_bar": config.display_progress_bar,
        "use_cloudpickle": config.use_cloudpickle,
        "cache_evaluation": config.cache_evaluation,
        "seed": config.seed,
        "raise_on_exception": config.raise_on_exception,
        "val_evaluation_policy": config.val_evaluation_policy,
    }


__all__ = ["GEPASetup", "attach_gepa", "optimize_gepa"]
