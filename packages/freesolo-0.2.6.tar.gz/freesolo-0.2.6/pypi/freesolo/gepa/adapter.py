from __future__ import annotations

import traceback
from dataclasses import dataclass

from freesolo.datasets import TaskExample
from freesolo.environments import Environment, RewardResult
from freesolo.utils.core import json_safe_value

from .types import (
    Candidate,
    EnvironmentGEPAContext,
    EnvironmentGEPAOutput,
    EnvironmentGEPATrajectory,
    EnvironmentRollout,
    EvaluationBatch,
    ReflectionAgentProtocol,
    ReflectiveDataset,
    ReflectiveRecord,
)


@dataclass
class EnvironmentGEPAAdapter:
    """GEPA adapter for Freesolo environments.

    The adapter owns the environment scoring loop. User code owns `rollout`,
    which executes a candidate and returns the agent/model response text.
    """

    environment: Environment
    rollout: EnvironmentRollout
    reflection_agent: ReflectionAgentProtocol | None = None
    prompt_component: str = "prompt"
    failure_score: float = 0.0

    def __post_init__(self) -> None:
        self.propose_new_texts = (
            self.reflection_agent.propose_new_texts
            if self.reflection_agent is not None
            else None
        )

    def evaluate(
        self,
        batch: list[TaskExample],
        candidate: Candidate,
        capture_traces: bool = False,
    ) -> EvaluationBatch:
        outputs: list[EnvironmentGEPAOutput] = []
        scores: list[float] = []
        objective_scores: list[dict[str, float]] = []
        trajectories: list[EnvironmentGEPATrajectory] = []

        for example in batch:
            output, reward, trajectory = self._evaluate_one(
                example=example,
                candidate=candidate,
                capture_trace=capture_traces,
            )
            outputs.append(output)
            scores.append(reward.score)
            objective_scores.append(_objective_scores_from_reward(reward))
            if trajectory is not None:
                trajectories.append(trajectory)

        return EvaluationBatch(
            outputs=outputs,
            scores=scores,
            objective_scores=objective_scores,
            trajectories=trajectories if capture_traces else None,
        )

    def make_reflective_dataset(
        self,
        candidate: Candidate,
        eval_batch: EvaluationBatch,
        components_to_update: list[str],
    ) -> ReflectiveDataset:
        trajectories = eval_batch.trajectories or []
        dataset: ReflectiveDataset = {}
        for component_name in components_to_update:
            dataset[component_name] = [
                self._build_reflective_record(component_name, candidate, trajectory)
                for trajectory in trajectories
            ]
        return dataset

    def _evaluate_one(
        self,
        *,
        example: TaskExample,
        candidate: Candidate,
        capture_trace: bool,
    ) -> tuple[
        EnvironmentGEPAOutput,
        RewardResult,
        EnvironmentGEPATrajectory | None,
    ]:
        prompt_text = _render_candidate_prompt(
            candidate,
            preferred_component=self.prompt_component,
        )
        messages = self.environment.build_prompt_messages(example, prompt_text)
        error: str | None = None

        try:
            raw_output = self.rollout(
                EnvironmentGEPAContext(
                    environment=self.environment,
                    example=example,
                    candidate=dict(candidate),
                    prompt_text=prompt_text,
                    messages=messages,
                )
            )
            output = _coerce_rollout_output(raw_output)
            response_text = self.environment.normalize_response_text(
                example,
                output.response_text,
            )
            reward = self.environment.score_response(example, response_text)
        except Exception:
            error = traceback.format_exc()
            output = EnvironmentGEPAOutput(response_text="", metadata={"error": error})
            reward = RewardResult(score=self.failure_score, metadata={"error": error})

        trajectory = None
        if capture_trace:
            trajectory = EnvironmentGEPATrajectory(
                example=example,
                candidate=dict(candidate),
                prompt_text=prompt_text,
                messages=messages,
                response_text=output.response_text,
                reward=reward,
                output_metadata=output.metadata,
                error=error,
            )
        return output, reward, trajectory

    def _build_reflective_record(
        self,
        component_name: str,
        candidate: Candidate,
        trajectory: EnvironmentGEPATrajectory,
    ) -> ReflectiveRecord:
        feedback = _format_feedback(trajectory.reward, trajectory.error)
        record: ReflectiveRecord = {
            "Inputs": {
                "task": trajectory.example.task,
                "task_id": trajectory.example.task_id,
                "metadata": json_safe_value(trajectory.example.metadata),
                "messages": json_safe_value(trajectory.messages),
                "component_name": component_name,
                "current_text": candidate.get(component_name, ""),
            },
            "Generated Outputs": trajectory.response_text,
            "Feedback": feedback,
            "score": trajectory.reward.score,
        }
        if trajectory.example.expected_output is not None:
            record["expected_output"] = json_safe_value(
                trajectory.example.expected_output
            )
        if trajectory.reward.metadata:
            record["reward_metadata"] = json_safe_value(trajectory.reward.metadata)
        if trajectory.output_metadata:
            record["output_metadata"] = json_safe_value(trajectory.output_metadata)
        return record


def _make_seed_candidate(
    prompt_text: str,
    *,
    component_name: str = "prompt",
) -> Candidate:
    return {component_name: prompt_text}


def _render_candidate_prompt(
    candidate: Candidate,
    *,
    preferred_component: str = "prompt",
) -> str:
    if preferred_component in candidate:
        return candidate[preferred_component]
    if len(candidate) == 1:
        return next(iter(candidate.values()))
    return "\n\n".join(f"## {name}\n{text}" for name, text in sorted(candidate.items()))


def _coerce_rollout_output(
    raw_output: str | EnvironmentGEPAOutput,
) -> EnvironmentGEPAOutput:
    if isinstance(raw_output, EnvironmentGEPAOutput):
        return raw_output
    return EnvironmentGEPAOutput(response_text=str(raw_output))


def _format_feedback(reward: RewardResult, error: str | None = None) -> str:
    lines = [f"Score: {reward.score}"]
    if error:
        lines.append("The rollout or scorer failed.")
        lines.append(error.strip())
    if reward.metadata:
        lines.append("Reward metadata:")
        lines.append(str(reward.metadata))
    return "\n".join(lines)


def _objective_scores_from_reward(reward: RewardResult) -> dict[str, float]:
    scores = {reward.name or "environment_reward": float(reward.score)}
    for metric in reward.metrics:
        if metric.score is not None:
            scores[metric.name] = float(metric.score)
    return scores
