from __future__ import annotations

import logging

import httpx

from .utils.core import _env_value, _resolve_base_url, _usage_headers

USAGE_PATH = "/api/package-functions/usage"
USAGE_TIMEOUT_SECONDS = 1.0

logger = logging.getLogger("freesolo.usage")


def record_function_usage(
    function_name: str,
    *,
    api_key: str | None = None,
    base_url: str | None = None,
) -> None:
    resolved_api_key = api_key or _env_value("FREESOLO_API_KEY")
    if not resolved_api_key:
        return

    endpoint = f"{_resolve_base_url(base_url)}{USAGE_PATH}"
    try:
        with httpx.Client(timeout=USAGE_TIMEOUT_SECONDS) as client:
            client.post(
                endpoint,
                headers=_usage_headers(resolved_api_key),
                json={"function_name": function_name},
            )
    except Exception:
        logger.debug(
            "failed to record freesolo usage for %s", function_name, exc_info=True
        )


__all__ = ["record_function_usage"]
