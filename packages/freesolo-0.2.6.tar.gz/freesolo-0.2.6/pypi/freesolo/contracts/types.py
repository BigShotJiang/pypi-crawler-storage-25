from __future__ import annotations

from typing import TypedDict


class ChatMessage(TypedDict):
    role: str
    content: str


class ContractMessageSpec(TypedDict, total=False):
    role: str
    content: str


class PromptConfig(TypedDict, total=False):
    messages: list[ContractMessageSpec]


class ContractSpec(TypedDict, total=False):
    prompt: PromptConfig


__all__ = [
    "ChatMessage",
    "ContractMessageSpec",
    "ContractSpec",
    "PromptConfig",
]
