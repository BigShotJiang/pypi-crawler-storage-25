# Contracts

The contract is the source of truth for generated repo behavior.

## Public Imports

```python
from freesolo.contracts import (
    build_oracle_messages,
    extract_contract_spec,
    load_contract_spec,
    load_contract_text,
)
```

## Expected Contract File

Generated repos should treat `freesolo/TRAINING_CONTRACT.md` or
`TRAINING_CONTRACT.md` as read-only approved input, depending on where the
repo-level agent wrote it. Do not edit the approved contract during optimizer or
training runs.

The markdown should contain one fenced JSON block tagged `freesolo-contract`:

````markdown
```json freesolo-contract
{
  "prompt": {
    "messages": [
      {"role": "system", "content": "Follow the task contract."},
      {"role": "user", "content": "{task}"}
    ]
  }
}
```
````

`load_contract_spec(path)` returns that JSON object when present.

## Agent Guidance

- Use `load_contract_text(...)` whenever a package helper needs the prose
  contract.
- Use `load_contract_spec(...)` to seed prompt messages and output-shape
  expectations.
- Use `build_oracle_messages(...)` for oracle generation instead of rebuilding
  prompt rendering.
- GEPA candidates may optimize model-facing prompt text derived from
  `prompt.messages`; they must not rewrite the approved contract markdown.
