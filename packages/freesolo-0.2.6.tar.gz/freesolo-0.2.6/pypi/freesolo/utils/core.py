from __future__ import annotations

import hashlib
import json
import os
import re
import time
from collections.abc import Iterable, Iterator, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TypeAlias, cast

JsonPrimitive: TypeAlias = str | int | float | bool | None
JsonValue: TypeAlias = JsonPrimitive | list["JsonValue"] | dict[str, "JsonValue"]
JsonObject: TypeAlias = dict[str, JsonValue]
MetadataDict: TypeAlias = dict[str, JsonValue]

DEFAULT_BASE_URL = "https://api.freesolo.co"

_JSON_CODE_BLOCK_RE = re.compile(
    r"```(?:[a-zA-Z0-9_-]+)?\s*(.*?)```",
    flags=re.DOTALL | re.IGNORECASE,
)


@dataclass
class ValidationResult:
    ok: bool
    checks: dict[str, bool] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    parsed: Any = None


def load_dotenv_if_available() -> None:
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    load_dotenv()


def required_path(value: str | Path | None, option_name: str) -> Path:
    if value:
        return Path(value)
    raise RuntimeError(f"Missing required path: {option_name}")


def _env_value(name: str) -> str | None:
    value = os.getenv(name)
    return value or None


def _normalize_base_url(value: str) -> str:
    return value.rstrip("/")


def _resolve_base_url(value: str | None = None) -> str:
    return (
        _normalize_base_url(
            value or _env_value("FREESOLO_BASE_URL") or DEFAULT_BASE_URL
        )
        or DEFAULT_BASE_URL
    )


def _require_api_key(value: str | None = None, *, error_message: str) -> str:
    resolved = value or _env_value("FREESOLO_API_KEY")
    if not resolved:
        raise ValueError(error_message)
    return resolved


def require_non_empty(value: str, name: str) -> str:
    stripped = value.strip()
    if not stripped:
        raise ValueError(f"{name} is required")
    return stripped


def _auth_headers(
    api_key: str,
    *,
    function_name: str | None = None,
) -> dict[str, str]:
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }
    if function_name:
        headers["X-Freesolo-Function"] = function_name
    return headers


def _usage_headers(api_key: str) -> dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }


def _normalize_data_row(row: object, index: int) -> dict[str, Any]:
    if not isinstance(row, dict):
        raise TypeError(f"Evaluation row {index + 1} must be a dict")
    return dict(row)


def _json_text_candidates(text: str) -> Iterator[str]:
    stripped = text.strip()
    if stripped:
        yield stripped
    for match in _JSON_CODE_BLOCK_RE.finditer(stripped):
        candidate = match.group(1).strip()
        if candidate:
            yield candidate


def loads_json_object(text: str) -> JsonObject | None:
    for candidate in _json_text_candidates(text):
        try:
            parsed = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(parsed, dict):
            return cast(JsonObject, parsed)
    return None


def _serialize_value(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True)
    except TypeError:
        return str(value)


def _find_first_present(row: Mapping[str, Any], keys: Iterable[str]) -> Any:
    for key in keys:
        if key in row and row[key] is not None:
            return row[key]
    return None


def _require_field(row: Mapping[str, Any], key: str) -> Any:
    if key not in row or row[key] is None:
        raise ValueError(f'hosted scorer requires row field "{key}"')
    return row[key]


def _clamp_score(value: Any) -> float:
    score = float(value)
    return max(0.0, min(1.0, score))


def _maybe_parse_json_text(text: str) -> Any:
    stripped = text.strip()
    if not stripped:
        return stripped
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        return stripped


def json_safe_value(value: object) -> JsonValue:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, Mapping):
        return {str(key): json_safe_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe_value(item) for item in value]
    try:
        json.dumps(value)
    except (TypeError, ValueError):
        return str(value)
    return cast(JsonValue, value)


def optional_int(value: Any) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return int(value)
    return None


def optional_str(value: object | None) -> str | None:
    if value is None:
        return None
    return str(value)


def coerce_bool(value: object) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    return None


def coerce_float(value: object) -> float | None:
    if isinstance(value, (int, float)):
        return float(value)
    return None


def truthy(value: str | None) -> bool:
    return (value or "").strip().lower() in {"1", "true", "yes", "on"}


def slugify(value: str, *, fallback: str = "run") -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", value.strip().lower()).strip("-")
    return slug or fallback


def elapsed_ms(started: float) -> int:
    return int((time.perf_counter() - started) * 1000)


def truncate_text(value: str, limit: int, *, suffix: str = "...") -> str:
    if len(value) <= limit:
        return value
    if limit <= len(suffix):
        return suffix[:limit]
    return f"{value[: limit - len(suffix)]}{suffix}"


def serialize_value(value: Any, *, pretty: bool = True) -> str:
    if isinstance(value, str):
        return value.strip()
    if pretty:
        return json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True)
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def load_json_schema(path: str | Path | None) -> dict[str, Any] | None:
    if path is None:
        return None
    schema_path = Path(path)
    if not schema_path.is_file():
        raise FileNotFoundError(f"Schema file not found: {schema_path}")
    parsed = json.loads(schema_path.read_text(encoding="utf-8"))
    if not isinstance(parsed, dict):
        raise ValueError(f"Expected a JSON object schema in {schema_path}")
    return parsed


def validate_output(
    output: Any,
    *,
    schema: dict[str, Any] | None = None,
    require_json: bool | None = None,
) -> ValidationResult:
    result = ValidationResult(ok=True, parsed=output)
    json_required = bool(schema) if require_json is None else require_json
    parsed = output
    parsed_json = False

    if isinstance(output, str):
        stripped = output.strip()
        if stripped:
            try:
                parsed = json.loads(stripped)
                parsed_json = True
            except json.JSONDecodeError as exc:
                if json_required:
                    result.ok = False
                    result.checks["valid_json"] = False
                    result.errors.append(str(exc))
                    return result
                parsed = stripped
        else:
            parsed = ""

    result.parsed = parsed
    if json_required or parsed_json:
        result.checks["valid_json"] = True

    if schema is None:
        result.ok = all(result.checks.values()) if result.checks else True
        return result

    try:
        from jsonschema import Draft202012Validator
    except ImportError as error:
        result.ok = False
        result.checks["schema_valid"] = False
        result.errors.append(f"jsonschema is required for schema validation: {error}")
        return result

    validator = Draft202012Validator(schema)
    errors = sorted(validator.iter_errors(parsed), key=lambda item: list(item.path))
    if errors:
        result.checks["schema_valid"] = False
        result.errors.extend(
            [
                f"schema: {'/'.join(map(str, error.path)) or '<root>'}: {error.message}"
                for error in errors[:5]
            ]
        )
    else:
        result.checks["schema_valid"] = True

    result.ok = all(result.checks.values()) if result.checks else True
    return result


def write_jsonl(path: str | Path, records: list[dict[str, Any]]) -> None:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        "".join(f"{json.dumps(record, ensure_ascii=True)}\n" for record in records),
        encoding="utf-8",
    )


def stable_index(value: str) -> int:
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
    return int(digest[:8], 16) % 10000


def split_name(value: str, val_ratio: float = 0.15, test_ratio: float = 0.15) -> str:
    bucket = stable_index(value) % 10000 / 10000
    if bucket < test_ratio:
        return "test"
    if bucket < test_ratio + val_ratio:
        return "val"
    return "train"
