from __future__ import annotations

import json
import os
import sys
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .core import json_safe_value, optional_str, slugify, truthy

DEFAULT_WANDB_PROJECT = "freesolo"


def generate_wandb_run_id(phase: str = "run") -> str:
    """Generate a per-run W&B id without relying on WANDB_RUN_ID."""

    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"freesolo-{slugify(phase)}-{stamp}-{uuid.uuid4().hex[:8]}"


def wandb_api_key_from_env() -> str | None:
    return os.environ.get("WANDB_API_KEY") or None


def is_wandb_enabled(enabled: bool | None = None) -> bool:
    if enabled is not None:
        return bool(enabled)
    if truthy(os.environ.get("WANDB_DISABLED")):
        return False
    if (os.environ.get("WANDB_MODE") or "").strip().lower() == "disabled":
        return False
    return bool(wandb_api_key_from_env())


def _wandb_init_payload(
    phase: str,
    *,
    log_dir: str | Path | None = None,
    run_id: str | None = None,
    name: str | None = None,
    project: str | None = None,
    entity: str | None = None,
    group: str | None = None,
    tags: tuple[str, ...] | list[str] = (),
    config: dict[str, Any] | None = None,
    wandb_init_kwargs: dict[str, Any] | None = None,
) -> dict[str, Any]:
    resolved_run_id = run_id or generate_wandb_run_id(phase)
    resolved_project = (
        project or os.environ.get("WANDB_PROJECT") or DEFAULT_WANDB_PROJECT
    )
    resolved_entity = entity or os.environ.get("WANDB_ENTITY") or None
    resolved_group = group or os.environ.get("WANDB_GROUP") or None
    resolved_name = name or resolved_run_id

    payload: dict[str, Any] = {
        "project": resolved_project,
        "id": resolved_run_id,
        "name": resolved_name,
        "resume": "allow",
        "tags": list(tags),
        "config": json_safe_value(config or {}),
    }
    if resolved_entity:
        payload["entity"] = resolved_entity
    if resolved_group:
        payload["group"] = resolved_group
    if log_dir is not None:
        payload["dir"] = str(Path(log_dir))
    mode = os.environ.get("WANDB_MODE")
    if mode:
        payload["mode"] = mode
    return _merge_wandb_init_kwargs(payload, wandb_init_kwargs)


@dataclass
class WandbRun:
    enabled: bool
    run_id: str
    project: str | None = None
    entity: str | None = None
    name: str | None = None
    url: str | None = None
    reason: str | None = None
    init_kwargs: dict[str, Any] | None = field(default=None, repr=False)
    _run: Any | None = field(default=None, repr=False)

    def log(self, metrics: dict[str, Any], *, step: int | None = None) -> None:
        if self._run is None:
            return
        payload = json_safe_value(metrics)
        if isinstance(payload, dict):
            self._run.log(payload, step=step)

    def summary_update(self, metrics: dict[str, Any]) -> None:
        if self._run is None:
            return
        for key, value in metrics.items():
            self._run.summary[key] = json_safe_value(value)

    def finish(self) -> None:
        if self._run is not None:
            self._run.finish()

    def write_metadata(self, log_dir: str | Path | None) -> None:
        if log_dir is None:
            return
        path = Path(log_dir) / "wandb.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "enabled": self.enabled,
            "run_id": self.run_id,
            "project": self.project,
            "entity": self.entity,
            "name": self.name,
            "url": self.url,
            "reason": self.reason,
            "sdk_started": self._run is not None,
        }
        path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")


def start_wandb_run(
    phase: str,
    *,
    log_dir: str | Path | None = None,
    run_id: str | None = None,
    name: str | None = None,
    project: str | None = None,
    entity: str | None = None,
    group: str | None = None,
    tags: tuple[str, ...] | list[str] = (),
    config: dict[str, Any] | None = None,
    wandb_init_kwargs: dict[str, Any] | None = None,
    enabled: bool | None = None,
    strict: bool | None = None,
    start_sdk: bool = True,
) -> WandbRun:
    """Start a standardized W&B run, or prepare init kwargs for an external owner.

    `start_sdk=False` is for integrations that initialize W&B internally after
    accepting raw `wandb.init(...)` kwargs, such as GEPA.
    """

    init_kwargs = _wandb_init_payload(
        phase,
        log_dir=log_dir,
        run_id=run_id,
        name=name,
        project=project,
        entity=entity,
        group=group,
        tags=tags,
        config=config,
        wandb_init_kwargs=wandb_init_kwargs,
    )
    resolved_run_id = str(init_kwargs["id"])
    if not is_wandb_enabled(enabled):
        run = WandbRun(
            enabled=False,
            run_id=resolved_run_id,
            project=str(init_kwargs.get("project") or ""),
            entity=optional_str(init_kwargs.get("entity")),
            name=optional_str(init_kwargs.get("name")),
            reason="WANDB_API_KEY is not configured or W&B is disabled",
            init_kwargs=init_kwargs,
        )
        run.write_metadata(log_dir)
        return run

    if not start_sdk:
        run = WandbRun(
            enabled=True,
            run_id=resolved_run_id,
            project=str(init_kwargs.get("project") or ""),
            entity=optional_str(init_kwargs.get("entity")),
            name=optional_str(init_kwargs.get("name")),
            init_kwargs=init_kwargs,
        )
        run.write_metadata(log_dir)
        return run

    try:
        import wandb as wandb_sdk
    except ImportError as exc:
        message = "wandb package is not installed"
        strict_mode = (
            bool(strict)
            if strict is not None
            else truthy(os.environ.get("FREESOLO_WANDB_STRICT"))
        )
        if strict_mode:
            raise RuntimeError(message) from exc
        print(f"[freesolo] W&B logging disabled: {message}", file=sys.stderr)
        run = WandbRun(
            enabled=False,
            run_id=resolved_run_id,
            project=str(init_kwargs.get("project") or ""),
            entity=optional_str(init_kwargs.get("entity")),
            name=optional_str(init_kwargs.get("name")),
            reason=message,
            init_kwargs=init_kwargs,
        )
        run.write_metadata(log_dir)
        return run

    api_key = wandb_api_key_from_env()
    if api_key:
        wandb_sdk.login(key=api_key, relogin=False)

    if log_dir is not None:
        Path(log_dir).mkdir(parents=True, exist_ok=True)

    sdk_run = wandb_sdk.init(**init_kwargs)
    run = WandbRun(
        enabled=True,
        run_id=resolved_run_id,
        project=str(init_kwargs.get("project") or ""),
        entity=optional_str(init_kwargs.get("entity")),
        name=optional_str(init_kwargs.get("name")),
        url=optional_str(getattr(sdk_run, "url", None)),
        init_kwargs=init_kwargs,
        _run=sdk_run,
    )
    run.write_metadata(log_dir)
    return run


def numeric_metrics_from_result(prefix: str, value: object) -> dict[str, float]:
    metrics: dict[str, float] = {}
    _collect_numeric_metrics(metrics, slugify(prefix).replace("-", "/"), value)
    return metrics


def _collect_numeric_metrics(
    metrics: dict[str, float],
    prefix: str,
    value: object,
) -> None:
    if isinstance(value, bool):
        return
    if isinstance(value, (int, float)):
        metrics[prefix] = float(value)
        return
    if isinstance(value, dict):
        for key, child in value.items():
            _collect_numeric_metrics(metrics, f"{prefix}/{slugify(str(key))}", child)
        return
    for key in ("loss", "mean_loss", "kl", "entropy", "learning_rate"):
        if hasattr(value, key):
            _collect_numeric_metrics(metrics, f"{prefix}/{key}", getattr(value, key))


def _merge_wandb_init_kwargs(
    payload: dict[str, Any],
    overrides: dict[str, Any] | None,
) -> dict[str, Any]:
    if not overrides:
        return payload
    merged = dict(payload)
    for key, value in overrides.items():
        if (
            key == "config"
            and isinstance(merged.get("config"), dict)
            and isinstance(value, dict)
        ):
            merged["config"] = json_safe_value({**merged["config"], **value})
        else:
            merged[key] = value
    return merged
