from __future__ import annotations

import mimetypes
import tempfile
import zipfile
from pathlib import Path
from typing import Any

import httpx

from .core import (
    JsonObject,
    _auth_headers,
    _require_api_key,
    _resolve_base_url,
    json_safe_value,
    require_non_empty,
    truncate_text,
)

DATASETS_PATH = "/api/datasets"
RUNS_PATH = "/api/runs"
CODEX_LOGS_PATH = "/api/codex-logs"
DEFAULT_TIMEOUT_SECONDS = 300.0
AUTH_CHECK_DATASET_NAME = "__freesolo_auth_check__"
MAX_ERROR_BODY_CHARS = 2_000
TRUNCATED_BODY_SUFFIX = "... [truncated]"


class FreesoloStorageClient:
    """Small authenticated client for Freesolo dataset and run records."""

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout_seconds: float = DEFAULT_TIMEOUT_SECONDS,
    ) -> None:
        self.api_key = _require_api_key(
            api_key,
            error_message="FREESOLO_API_KEY or api_key is required for Freesolo storage sync",
        )
        self.base_url = _resolve_base_url(base_url)
        self.timeout_seconds = timeout_seconds

    def verify_api_key(self) -> None:
        """Check authentication without creating a dataset or run."""
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.post(
                f"{self.base_url}{DATASETS_PATH}",
                headers=_auth_headers(
                    self.api_key,
                    function_name="FreesoloStorageClient.verify_api_key",
                ),
                json={"name": AUTH_CHECK_DATASET_NAME},
            )
        if response.status_code in {400, 415, 422}:
            return
        _json_response(response, DATASETS_PATH)

    def upload_dataset(self, path: str | Path, *, name: str | None = None) -> str:
        dataset_path = Path(path).expanduser().resolve()
        if dataset_path.is_file():
            return self._upload_dataset_file(dataset_path, name=name)
        if dataset_path.is_dir():
            with tempfile.TemporaryDirectory(prefix="freesolo-dataset-upload-") as tmp:
                archive_path = Path(tmp) / f"{dataset_path.name or 'dataset'}.zip"
                _zip_directory(dataset_path, archive_path)
                return self._upload_dataset_file(
                    archive_path, name=name or archive_path.name
                )
        raise FileNotFoundError(f"Dataset path not found: {dataset_path}")

    def create_run(
        self,
        *,
        name: str,
        description: str | None = None,
        version: str | None = None,
        dataset_ids: list[str] | tuple[str, ...] = (),
        evaluator_ids: list[str] | tuple[str, ...] = (),
        model_id: str | None = None,
    ) -> str:
        payload: JsonObject = {"name": require_non_empty(name, "name")}
        if description:
            payload["description"] = description
        if version:
            payload["version"] = version
        if model_id:
            payload["model_id"] = model_id
        if dataset_ids:
            payload["dataset_ids"] = [str(value) for value in dataset_ids]
        if evaluator_ids:
            payload["evaluator_ids"] = [str(value) for value in evaluator_ids]
        data = self._post_json(
            RUNS_PATH,
            payload,
            function_name="FreesoloStorageClient.create_run",
        )
        return _response_id(data, "run_id")

    def update_run(
        self,
        run_id: str,
        *,
        status: str | None = None,
        error: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        payload: JsonObject = {}
        if status is not None:
            payload["status"] = require_non_empty(status, "status")
        if error is not None:
            payload["error"] = error
        if config is not None:
            payload["config"] = json_safe_value(config)
        if not payload:
            return
        self._patch_json(
            f"{RUNS_PATH}/{require_non_empty(run_id, 'run_id')}",
            payload,
            function_name="FreesoloStorageClient.update_run",
        )

    def link_wandb(self, run_id: str, wandb_url: str | None) -> None:
        if not wandb_url:
            return
        self._post_json(
            f"{RUNS_PATH}/{require_non_empty(run_id, 'run_id')}/wandb",
            {"wandb_url": require_non_empty(wandb_url, "wandb_url")},
            function_name="FreesoloStorageClient.link_wandb",
        )

    def append_codex_log(self, content: str) -> str:
        data = self._post_json(
            CODEX_LOGS_PATH,
            {"content": require_non_empty(content, "content")},
            function_name="FreesoloStorageClient.append_codex_log",
        )
        return _response_id(data, "codex_log_id")

    def _upload_dataset_file(self, path: Path, *, name: str | None) -> str:
        mime_type = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        with (
            path.open("rb") as file,
            httpx.Client(timeout=self.timeout_seconds) as client,
        ):
            response = client.post(
                f"{self.base_url}{DATASETS_PATH}",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "X-Freesolo-Function": "FreesoloStorageClient.upload_dataset",
                },
                data={"name": name or path.name},
                files={"file": (path.name, file, mime_type)},
            )
        data = _json_response(response, DATASETS_PATH)
        return _response_id(data, "dataset_id")

    def _post_json(
        self,
        path: str,
        payload: JsonObject,
        *,
        function_name: str,
    ) -> JsonObject:
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.post(
                f"{self.base_url}{path}",
                headers=_auth_headers(self.api_key, function_name=function_name),
                json=payload,
            )
        return _json_response(response, path)

    def _patch_json(
        self,
        path: str,
        payload: JsonObject,
        *,
        function_name: str,
    ) -> JsonObject:
        with httpx.Client(timeout=self.timeout_seconds) as client:
            response = client.patch(
                f"{self.base_url}{path}",
                headers=_auth_headers(self.api_key, function_name=function_name),
                json=payload,
            )
        return _json_response(response, path)


def _json_response(response: httpx.Response, path: str) -> JsonObject:
    if response.is_error:
        raise httpx.HTTPStatusError(
            f"freesolo {path} returned {response.status_code}: "
            f"{_response_error_body(response)}",
            request=response.request,
            response=response,
        )
    data = response.json()
    if not isinstance(data, dict):
        raise ValueError(f"freesolo {path} returned a non-object response")
    return data


def _response_id(data: JsonObject, key: str) -> str:
    value = data.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"freesolo response missing {key}")
    return value


def _response_error_body(response: httpx.Response) -> str:
    body = response.text.strip()
    if len(body) <= MAX_ERROR_BODY_CHARS:
        return body
    return truncate_text(
        body,
        MAX_ERROR_BODY_CHARS + len(TRUNCATED_BODY_SUFFIX),
        suffix=TRUNCATED_BODY_SUFFIX,
    )


def _zip_directory(source_dir: Path, archive_path: Path) -> None:
    with zipfile.ZipFile(
        archive_path, "w", compression=zipfile.ZIP_DEFLATED
    ) as archive:
        for path in sorted(source_dir.rglob("*")):
            if path.is_symlink():
                relative_path = path.relative_to(source_dir)
                raise ValueError(
                    "Dataset directory contains a symlink, which is not uploaded: "
                    f"{relative_path}"
                )
            if path.is_file():
                archive.write(path, path.relative_to(source_dir))
