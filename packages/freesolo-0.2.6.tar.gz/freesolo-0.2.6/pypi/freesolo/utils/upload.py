from __future__ import annotations

from typing import Any

import httpx

from .core import require_non_empty

DEFAULT_UPLOAD_URL = (
    "https://clado-ai--freesolo-tinker-deployment-fastapi-app.modal.run"
)
UPLOADS_PATH = "/deployments"
DEFAULT_TIMEOUT_SECONDS = 6 * 60 * 60


def upload_tinker_checkpoint_to_huggingface(
    tinker_path: str,
    *,
    base_model: str,
    repo_name: str | None = None,
) -> dict[str, Any]:
    """Upload a Tinker checkpoint to a private Hugging Face model repo."""

    payload: dict[str, Any] = {
        "tinkerPath": _require_tinker_path(tinker_path),
        "baseModel": require_non_empty(base_model, "base_model"),
        "private": True,
    }
    if repo_name is not None:
        payload["repoName"] = require_non_empty(repo_name, "repo_name")
    with httpx.Client(timeout=DEFAULT_TIMEOUT_SECONDS) as client:
        response = client.post(
            f"{DEFAULT_UPLOAD_URL}{UPLOADS_PATH}",
            json=payload,
        )
        if response.is_error:
            raise httpx.HTTPStatusError(
                f"Hugging Face upload returned {response.status_code}: {response.text}",
                request=response.request,
                response=response,
            )
        data = response.json()
    if not isinstance(data, dict):
        raise ValueError("Hugging Face upload response must be a JSON object")
    return data


def _require_tinker_path(value: str) -> str:
    cleaned = require_non_empty(value, "tinker_path")
    if not cleaned.startswith("tinker://"):
        raise ValueError("tinker_path must start with 'tinker://'")
    return cleaned


__all__ = ["upload_tinker_checkpoint_to_huggingface"]
