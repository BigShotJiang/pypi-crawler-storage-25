from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from freesolo.contracts.markdown import (
    load_contract_spec,
    load_contract_text,
)
from freesolo.datasets.records import load_task_examples
from freesolo.utils.core import (
    ValidationResult,
    _maybe_parse_json_text,
    load_dotenv_if_available,
    load_json_schema,
    serialize_value,
    split_name,
    validate_output,
    write_jsonl,
)
from freesolo.utils.openrouter import (
    DEFAULT_OPENROUTER_ORACLE_MODEL,
    generate_openrouter_text,
    resolve_openrouter_model,
)

DEFAULT_MODEL = DEFAULT_OPENROUTER_ORACLE_MODEL


def build_ground_truth_record(
    *,
    source_record: dict[str, Any],
    task_text: str,
    raw_output: Any,
    validation: ValidationResult,
    provider: str,
    model: str,
    metadata: dict[str, Any],
    source_path: str,
    source_index: int,
) -> dict[str, Any]:
    parsed_output = getattr(validation, "parsed", raw_output)
    validation_metadata = {
        "ok": bool(getattr(validation, "ok", True)),
        "checks": dict(getattr(validation, "checks", {}) or {}),
        "errors": list(getattr(validation, "errors", []) or []),
    }
    return {
        "id": str(
            source_record.get("id")
            or source_record.get("_id")
            or f"example_{source_index:06d}"
        ),
        "input": task_text,
        "task": task_text,
        "raw_output": serialize_value(raw_output),
        "output": parsed_output,
        "ground_truth": parsed_output,
        "validation": validation_metadata,
        "split": split_name(task_text),
        "oracle_provider": provider,
        "oracle_model": model,
        "oracle_attempts": 1,
        "provider": provider,
        "model": model,
        "metadata": {
            **metadata,
            "source_index": source_index,
            "source_path": source_path,
        },
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate ground-truth JSONL samples.")
    parser.add_argument("--contract", default="TRAINING_CONTRACT.md")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--schema")
    parser.add_argument("--environment")
    parser.add_argument(
        "--model",
        default=DEFAULT_MODEL,
        help="OpenRouter model id.",
    )
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--temperature", type=float, default=0.0)
    return parser.parse_args()


def _call_openrouter(
    *,
    model: str,
    system_prompt: str | None,
    messages: list[dict[str, str]],
    schema: dict[str, Any] | None,
    temperature: float,
) -> Any:
    provider_messages = list(messages)
    if system_prompt:
        provider_messages = [
            {"role": "system", "content": system_prompt},
            *provider_messages,
        ]

    response_format: dict[str, Any] = {"type": "json_object"}
    if schema is not None:
        response_format = {
            "type": "json_schema",
            "json_schema": {
                "name": "ground_truth",
                "schema": schema,
            },
        }
    content = generate_openrouter_text(
        model=model,
        messages=provider_messages,
        temperature=temperature,
        response_format=response_format,
        timeout_seconds=120.0,
    )
    return _maybe_parse_json_text(content)


def generate_ground_truth_records(
    *,
    input_path: str | Path,
    contract_path: str | Path = "TRAINING_CONTRACT.md",
    output_path: str | Path | None = None,
    schema_path: str | Path | None = None,
    environment: str | None = None,
    model: str = DEFAULT_MODEL,
    limit: int = 0,
    temperature: float = 0.0,
) -> list[dict[str, Any]]:
    from freesolo.environments.base import (
        load_environment as load_training_environment,
    )

    load_dotenv_if_available()
    model = resolve_openrouter_model(model)

    contract_text = load_contract_text(contract_path)
    contract_spec = load_contract_spec(contract_path)
    schema = load_json_schema(schema_path)
    training_environment = load_training_environment(
        environment,
        contract_path=str(contract_path),
        dataset_path=str(input_path),
        mode="oracle",
    )
    examples = load_task_examples(input_path)
    if limit > 0:
        examples = examples[:limit]

    output_records: list[dict[str, Any]] = []
    for index, example in enumerate(examples):
        oracle_messages = training_environment.build_oracle_messages(
            example,
            contract_text,
            contract_spec=contract_spec,
        )
        system_prompt, provider_messages = _split_messages(oracle_messages)
        ground_truth = _call_openrouter(
            model=model,
            system_prompt=system_prompt,
            messages=provider_messages,
            schema=schema,
            temperature=temperature,
        )
        validation = validate_output(
            ground_truth,
            schema=schema,
            require_json=bool(schema),
        )
        output_records.append(
            build_ground_truth_record(
                source_record=example.record,
                task_text=example.task,
                raw_output=ground_truth,
                validation=validation,
                provider="openrouter",
                model=model,
                metadata=example.metadata,
                source_path=str(Path(input_path)),
                source_index=index,
            )
        )

    if output_path is not None:
        write_jsonl(output_path, output_records)
    return output_records


def main() -> int:
    load_dotenv_if_available()
    args = _parse_args()
    generate_ground_truth_records(
        input_path=args.input,
        contract_path=args.contract,
        output_path=args.output,
        schema_path=args.schema,
        environment=args.environment,
        model=args.model,
        limit=args.limit,
        temperature=args.temperature,
    )
    return 0


def _split_messages(
    messages: list[dict[str, str]],
) -> tuple[str | None, list[dict[str, str]]]:
    system_parts: list[str] = []
    provider_messages: list[dict[str, str]] = []
    for message in messages:
        role = str(message.get("role", "user"))
        content = str(message.get("content", ""))
        if role == "system":
            system_parts.append(content)
            continue
        provider_messages.append({"role": role, "content": content})
    if not provider_messages:
        provider_messages.append({"role": "user", "content": ""})
    system_prompt = "\n\n".join(part for part in system_parts if part.strip()) or None
    return system_prompt, provider_messages


__all__ = [
    "generate_ground_truth_records",
]


if __name__ == "__main__":
    raise SystemExit(main())
