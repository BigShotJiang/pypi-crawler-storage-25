from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Protocol

CheckpointRecord = dict[str, Any]
TRAINING_PROGRESS_FILENAME = "training_progress.json"


class CheckpointUtils(Protocol):
    def get_last_checkpoint(self, log_path: str) -> object | None: ...

    def save_checkpoint(
        self,
        *,
        training_client: object,
        name: str,
        log_path: str,
        loop_state: dict[str, Any],
        kind: str,
    ) -> object: ...


def checkpoint_value(record: object | None, key: str) -> Any:
    if record is None:
        return None
    getter = getattr(record, "get", None)
    if callable(getter):
        return getter(key)
    if isinstance(record, dict):
        return record.get(key)
    return getattr(record, key, None)


def checkpoint_loop_state(record: object | None) -> CheckpointRecord:
    loop_state = checkpoint_value(record, "loop_state")
    return loop_state if isinstance(loop_state, dict) else {}


def checkpoint_step(record: object | None, *, default: int = 0) -> int:
    value = checkpoint_loop_state(record).get("step", default)
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def checkpoint_epoch(record: object | None, *, default: int = 0) -> int:
    value = checkpoint_loop_state(record).get("epoch", default)
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def checkpoint_batch_index(record: object | None, *, default: int = 0) -> int:
    value = checkpoint_loop_state(record).get("batch_index", default)
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def get_last_tinker_checkpoint(
    checkpoint_utils: CheckpointUtils,
    log_dir: str | Path,
) -> object | None:
    return checkpoint_utils.get_last_checkpoint(str(log_dir))


def read_checkpoint_records(log_dir: str | Path) -> list[CheckpointRecord]:
    checkpoint_file = Path(log_dir) / "checkpoints.jsonl"
    if not checkpoint_file.exists():
        return []

    records: list[CheckpointRecord] = []
    for line in checkpoint_file.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        parsed = json.loads(line)
        if isinstance(parsed, dict):
            records.append(parsed)
    return records


def read_training_progress(log_dir: str | Path) -> CheckpointRecord:
    progress_file = Path(log_dir) / TRAINING_PROGRESS_FILENAME
    if not progress_file.exists():
        return {}
    parsed = json.loads(progress_file.read_text(encoding="utf-8"))
    return parsed if isinstance(parsed, dict) else {}


def write_training_progress(
    log_dir: str | Path,
    *,
    phase: str,
    step: int,
    epoch: int,
    batch_index: int,
    batches_per_epoch: int,
    checkpoint_name: str | None = None,
    state_path: str | None = None,
    sampler_path: str | None = None,
    skipped_batch: bool = False,
) -> CheckpointRecord:
    progress = {
        "phase": phase,
        "step": int(step),
        "epoch": int(epoch),
        "batch_index": int(batch_index),
        "batches_per_epoch": int(batches_per_epoch),
        "checkpoint_name": checkpoint_name,
        "state_path": state_path,
        "sampler_path": sampler_path,
        "skipped_batch": bool(skipped_batch),
    }
    progress_file = Path(log_dir) / TRAINING_PROGRESS_FILENAME
    progress_file.parent.mkdir(parents=True, exist_ok=True)
    progress_file.write_text(
        json.dumps(progress, indent=2, sort_keys=True),
        encoding="utf-8",
    )
    return progress


def next_training_position(
    *,
    epoch: int,
    batch_index: int,
    batches_per_epoch: int,
) -> tuple[int, int]:
    next_batch_index = int(batch_index) + 1
    next_epoch = int(epoch)
    if next_batch_index >= int(batches_per_epoch):
        next_epoch += 1
        next_batch_index = 0
    return next_epoch, next_batch_index


def resolve_training_position(
    checkpoint_record: object | None,
    log_dir: str | Path,
    *,
    batches_per_epoch: int,
) -> tuple[int, int, int, CheckpointRecord]:
    progress = read_training_progress(log_dir)
    checkpoint_record_step = checkpoint_step(checkpoint_record)
    use_progress = False
    if progress:
        try:
            progress_step = int(progress.get("step", 0))
            use_progress = progress_step >= checkpoint_record_step
        except (TypeError, ValueError):
            use_progress = False

    if use_progress:
        step = int(progress.get("step", 0))
        epoch = int(progress.get("epoch", 0))
        batch_index = int(progress.get("batch_index", 0))
    else:
        step = checkpoint_record_step
        epoch = checkpoint_epoch(
            checkpoint_record,
            default=step // max(1, int(batches_per_epoch)),
        )
        batch_index = checkpoint_batch_index(
            checkpoint_record,
            default=step % max(1, int(batches_per_epoch)),
        )

    safe_batches_per_epoch = max(1, int(batches_per_epoch))
    if batch_index < 0 or batch_index >= safe_batches_per_epoch:
        epoch += max(0, batch_index) // safe_batches_per_epoch
        batch_index = max(0, batch_index) % safe_batches_per_epoch
    return (
        max(0, step),
        max(0, epoch),
        max(0, batch_index),
        progress if use_progress else {},
    )


def find_checkpoint_record(
    log_dir: str | Path,
    checkpoint_name: str,
) -> CheckpointRecord | None:
    for record in read_checkpoint_records(log_dir):
        if record.get("name") == checkpoint_name:
            return record
    return None


def resolve_checkpoint_state_path(record: object | None) -> str | None:
    state_path = checkpoint_value(record, "state_path")
    return str(state_path) if state_path else None


def resolve_checkpoint_sampler_path(record: object | None) -> str | None:
    sampler_path = checkpoint_value(record, "sampler_path")
    return str(sampler_path) if sampler_path else None


def resolve_sft_state_path(
    *,
    explicit_state_path: str | None,
    sft_log_dir: str | Path,
    checkpoint_name: str,
    checkpoint_utils: CheckpointUtils,
) -> str | None:
    if explicit_state_path:
        return explicit_state_path

    latest_checkpoint = get_last_tinker_checkpoint(checkpoint_utils, sft_log_dir)
    latest_state_path = resolve_checkpoint_state_path(latest_checkpoint)
    if latest_state_path:
        return latest_state_path

    named_checkpoint = find_checkpoint_record(sft_log_dir, checkpoint_name)
    return resolve_checkpoint_state_path(named_checkpoint)


def save_tinker_checkpoint(
    *,
    checkpoint_utils: CheckpointUtils,
    training_client: object,
    name: str,
    log_dir: str | Path,
    loop_state: dict[str, Any],
    kind: str = "both",
) -> object:
    return checkpoint_utils.save_checkpoint(
        training_client=training_client,
        name=name,
        log_path=str(log_dir),
        loop_state=loop_state,
        kind=kind,
    )
