from __future__ import annotations

import importlib
import importlib.util
import inspect
import sys
from abc import ABC, abstractmethod
from collections.abc import Callable
from pathlib import Path
from types import ModuleType

from freesolo.datasets import TaskExample
from freesolo.training import GrpoConfig

from ..contracts.markdown import (
    ChatMessage,
    ContractSpec,
    build_oracle_messages as render_oracle_messages,
)
from .types import (
    RewardResult,
)

_DEFAULT_ENVIRONMENT_FACTORY = "load_environment"
_REPO_ENVIRONMENT_FILE = Path("freesolo") / "environment.py"
_REPO_ENVIRONMENT_REFERENCE = "freesolo/environment.py:load_environment"


class Environment(ABC):
    """Task behavior adapter used by GRPO/RL, GEPA, and oracle generation."""

    @abstractmethod
    def build_prompt_messages(
        self,
        example: TaskExample,
        prompt_text: str,
    ) -> list[ChatMessage]:
        """Build the model-input messages for one environment example."""

    def build_oracle_messages(
        self,
        example: TaskExample,
        contract_text: str,
        *,
        contract_spec: ContractSpec | None = None,
    ) -> list[ChatMessage]:
        return render_oracle_messages(
            example.task,
            contract_text,
            contract_spec=contract_spec,
        )

    def get_grpo_config(self) -> GrpoConfig:
        return GrpoConfig()

    def extract_response_text(self, parsed_message: object) -> str:
        if isinstance(parsed_message, dict):
            return str(parsed_message.get("content", ""))
        content = getattr(parsed_message, "content", parsed_message)
        return str(content)

    def normalize_response_text(
        self,
        example: TaskExample,
        response_text: str,
    ) -> str:
        return response_text

    @abstractmethod
    def score_response(
        self,
        example: TaskExample,
        response_text: str,
    ) -> RewardResult:
        """Return the scalar reward for one sampled response."""

    def score_responses(
        self,
        example: TaskExample,
        response_texts: list[str],
    ) -> list[RewardResult]:
        return [
            self.score_response(
                example,
                self.normalize_response_text(example, response_text),
            )
            for response_text in response_texts
        ]


def load_environment(
    reference: str | None = None,
    **kwargs: object,
) -> Environment:
    resolved_reference = _default_environment_reference(reference)
    factory = _resolve_factory(resolved_reference)
    environment = _call_factory(factory, kwargs)
    return _validate_environment(environment, reference=resolved_reference)


def _validate_environment(
    environment: object,
    *,
    reference: str | None = None,
) -> Environment:
    if not isinstance(environment, Environment):
        source = f" {reference!r}" if reference else ""
        raise TypeError(
            f"Environment loader{source} must return an instance of "
            "freesolo.environments.Environment. Canonical setup: define "
            "freesolo/environment.py with load_environment(...) returning a "
            "subclass of Environment."
        )
    grpo_config = environment.get_grpo_config()
    if not isinstance(grpo_config, GrpoConfig):
        source = f" from {reference!r}" if reference else ""
        raise TypeError(
            f"Environment{source} get_grpo_config() must return "
            "freesolo.training.GrpoConfig"
        )
    return environment


def _default_environment_reference(
    reference: str | None = None,
    *,
    cwd: str | Path | None = None,
) -> str:
    if reference and reference.strip():
        return reference.strip()

    root = Path.cwd() if cwd is None else Path(cwd)
    if (root / _REPO_ENVIRONMENT_FILE).is_file():
        return _REPO_ENVIRONMENT_REFERENCE
    raise ValueError(
        "No environment reference provided. Expected the canonical generated-repo "
        "environment at freesolo/environment.py with load_environment(), or pass "
        "an explicit reference such as 'freesolo/environment.py:load_environment'."
    )


def _resolve_factory(reference: str) -> Callable[..., object]:
    module_reference, _, attribute_name = reference.partition(":")
    if not attribute_name:
        attribute_name = _DEFAULT_ENVIRONMENT_FACTORY

    module = _import_reference_module(module_reference)
    if not hasattr(module, attribute_name):
        raise AttributeError(
            f"Environment reference {reference!r} does not define {attribute_name!r}"
        )
    factory = getattr(module, attribute_name)
    if not callable(factory):
        raise TypeError(
            f"Environment reference {reference!r} resolved {attribute_name!r}, but it is not callable"
        )
    return factory


def _import_reference_module(module_reference: str) -> ModuleType:
    candidate_path = Path(module_reference)
    if candidate_path.suffix == ".py" or candidate_path.is_file():
        module_path = candidate_path.resolve()
        if not module_path.is_file():
            raise FileNotFoundError(f"Environment file not found: {module_reference}")
        module_name = f"_freesolo_env_{module_path.stem}_{abs(hash(module_path))}"
        spec = importlib.util.spec_from_file_location(module_name, module_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not import environment module from {module_path}")
        module = importlib.util.module_from_spec(spec)
        _prepend_module_dir(module_path.parent)
        spec.loader.exec_module(module)
        return module
    return importlib.import_module(module_reference)


def _prepend_module_dir(module_dir: Path) -> None:
    # Generated repo modules live beside config.py and import it as `config`.
    module_dir_text = str(module_dir)
    if module_dir_text not in sys.path:
        sys.path.insert(0, module_dir_text)


def _call_factory(factory: Callable[..., object], kwargs: dict[str, object]) -> object:
    signature = inspect.signature(factory)
    accepts_var_kwargs = any(
        parameter.kind == inspect.Parameter.VAR_KEYWORD
        for parameter in signature.parameters.values()
    )
    if accepts_var_kwargs:
        return factory(**kwargs)
    filtered_kwargs = {
        name: value for name, value in kwargs.items() if name in signature.parameters
    }
    return factory(**filtered_kwargs)


__all__ = [
    "Environment",
    "load_environment",
]
