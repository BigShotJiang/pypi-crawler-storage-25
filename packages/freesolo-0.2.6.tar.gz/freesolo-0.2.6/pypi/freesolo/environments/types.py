from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from ..utils.core import JsonValue, MetadataDict

EnvironmentMetadata = MetadataDict
RewardReturnType = Literal["binary", "numeric"]


@dataclass(frozen=True)
class RewardMetric:
    """A named component that explains how a reward score was produced.

    This shape is intentionally JSON-compatible because it is stored inside
    eval_tasks.scorers_data[*].metrics.
    """

    name: str
    score: float | None = None
    value: JsonValue | None = None
    success: bool | None = None
    threshold: float | None = None
    weight: float | None = None
    reason: str | None = None
    metadata: EnvironmentMetadata = field(default_factory=dict)


@dataclass(frozen=True)
class RewardResult:
    score: float
    metadata: EnvironmentMetadata = field(default_factory=dict)
    name: str = "environment_reward"
    success: bool | None = None
    threshold: float | None = None
    value: JsonValue | None = None
    reason: str | None = None
    error: str | None = None
    return_type: RewardReturnType = "numeric"
    metrics: tuple[RewardMetric, ...] = ()
    latency_ms: int | None = None
    total_tokens: int | None = None

    def resolved_success(self) -> bool:
        if self.success is not None:
            return self.success
        if self.error:
            return False
        if self.threshold is not None:
            return self.score >= self.threshold
        return self.score > 0.0

    def resolved_value(self) -> JsonValue:
        if self.value is not None:
            return self.value
        if self.return_type == "binary":
            return self.resolved_success()
        return self.score

__all__ = [
    "RewardMetric",
    "RewardResult",
]
