# Freesolo Environments

Generated training repos should use one canonical environment module:

```text
freesolo/environment.py
```

That file must expose:

```python
def load_environment(
    *,
    contract_path: str | None = None,
    dataset_path: str | None = None,
    reward_command: str | None = None,
    mode: str = "eval",
    **_: object,
) -> Environment:
    return RepoEnvironment(
        contract_path=contract_path,
        dataset_path=dataset_path,
        reward_command=reward_command,
        mode=mode,
    )
```

`RepoEnvironment` must subclass `freesolo.environments.Environment` and implement:

- `build_prompt_messages(example, prompt_text) -> list[ChatMessage]`
- `score_response(example, response_text) -> RewardResult`

It may override:

- `score_responses(example, response_texts) -> list[RewardResult]`; must return one result per response.
- `get_grpo_config() -> freesolo.training.GrpoConfig`; return `GRPO_CONFIG`
  from generated `freesolo/config.py` so SFT and GRPO config objects live in the
  same place.
- `extract_response_text(parsed_message) -> str`
- `normalize_response_text(example, response_text) -> str`
- `build_oracle_messages(...)`

Use this exact GRPO config pattern in generated environments:

```python
from config import GRPO_CONFIG
from freesolo.environments import Environment
from freesolo.training import GrpoConfig


class RepoEnvironment(Environment):
    def get_grpo_config(self) -> GrpoConfig:
        return GRPO_CONFIG
```

GRPO, SFT, GEPA, and local evaluation attach with the same reference:

```python
ENVIRONMENT_REFERENCE = "freesolo/environment.py:load_environment"
```

When run from a generated repo root, `load_environment(None, ...)` resolves this
canonical file automatically. Root-level `environment.py` files are intentionally
not discovered by default.
