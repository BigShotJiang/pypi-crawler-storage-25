# Datasets

Dataset helpers turn raw records into `TaskExample` objects and SFT
conversations.

## Public Imports

```python
from freesolo.datasets import Dataset, PromptBuilder, TaskExample, load_dataset
```

## Supported Record Sources

`load_dataset(...)` accepts either a path or an iterable of records.

Path inputs support:

- `.jsonl`
- `.json`
- `.csv`
- `.txt`
- `.bson` when BSON support is installed

Each record must include one task field:

- `task`
- `prompt`
- `query`
- `input`

Labeled/SFT records should also include one target field:

- `ground_truth`
- `expected_output`
- `output`
- `completion`

## Agent Guidance

- Load task data with `load_dataset(...)`.
- Build labeled SFT conversations by calling
  `dataset.build_conversations(environment, contract_text)`.
- Keep split manifests and generated oracle files in run artifacts, not inside
  this package.
- Do not put dataset parsing inside generated `freesolo/environment.py` unless
  the task needs small per-example normalization for prompt or reward logic.
