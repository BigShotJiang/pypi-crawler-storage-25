from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from freesolo.utils.core import JsonObject, serialize_value

from .types import DatasetRecord, DatasetSource, TaskExample

try:
    from bson import decode_file_iter as _decode_file_iter
except Exception:
    _decode_file_iter = None


def load_records(path: str | Path) -> list[dict[str, Any]]:
    input_path = Path(path)
    if not input_path.is_file():
        raise FileNotFoundError(f"Input dataset not found: {input_path}")

    suffix = input_path.suffix.lower()
    if suffix == ".jsonl":
        return _read_jsonl_records(input_path)
    if suffix == ".json":
        return _read_json_records(input_path)
    if suffix == ".csv":
        return _read_csv_records(input_path)
    if suffix == ".txt":
        return _read_txt_records(input_path)
    if suffix == ".bson":
        return _read_bson_records(input_path)
    raise ValueError(f"Unsupported dataset extension: {input_path.suffix}")


def load_task_examples(source: DatasetSource) -> list[TaskExample]:
    if isinstance(source, (str, Path)):
        return [task_example_from_record(record) for record in load_records(source)]
    return [coerce_task_example(item) for item in source]


def coerce_task_example(value: TaskExample | DatasetRecord) -> TaskExample:
    if isinstance(value, TaskExample):
        return value
    return task_example_from_record(value)


def task_example_from_record(record: DatasetRecord) -> TaskExample:
    normalized = normalize_task(record)
    return TaskExample(
        record=record,
        task=normalized["task"],
        task_id=normalized["id"],
        metadata=normalized["metadata"],
        expected_output=infer_expected_output(record),
    )


def normalize_task(record: dict[str, Any]) -> JsonObject:
    task = (
        record.get("task")
        or record.get("prompt")
        or record.get("query")
        or record.get("input")
    )
    if task is None:
        raise ValueError(
            "Each record must contain one of: task, prompt, query, or input"
        )

    metadata = record.get("metadata")
    return {
        "id": str(record.get("id") or record.get("_id") or "").strip() or None,
        "task": serialize_value(task),
        "metadata": metadata if isinstance(metadata, dict) else {},
    }


def infer_expected_output(record: dict[str, Any]) -> Any:
    for key in ("ground_truth", "expected_output", "output", "completion"):
        if key in record and record.get(key) is not None:
            return record.get(key)
    return None


def _read_jsonl_records(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for line_number, line in enumerate(
        path.read_text(encoding="utf-8").splitlines(), start=1
    ):
        stripped = line.strip()
        if not stripped:
            continue
        parsed = json.loads(stripped)
        if isinstance(parsed, str):
            parsed = {"input": parsed}
        if not isinstance(parsed, dict):
            raise ValueError(f"Expected JSON object on line {line_number} of {path}")
        records.append(parsed)
    return records


def _read_json_records(path: Path) -> list[dict[str, Any]]:
    parsed = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(parsed, dict) and isinstance(parsed.get("data"), list):
        parsed = parsed["data"]
    if not isinstance(parsed, list):
        raise ValueError(f"Expected a JSON array of objects in {path}")
    records: list[dict[str, Any]] = []
    for item in parsed:
        if isinstance(item, str):
            item = {"input": item}
        if not isinstance(item, dict):
            raise ValueError(f"Expected JSON object items in {path}")
        records.append(item)
    return records


def _read_csv_records(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        return [dict(row) for row in reader]


def _read_txt_records(path: Path) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for index, line in enumerate(path.read_text(encoding="utf-8").splitlines()):
        stripped = line.strip()
        if stripped:
            records.append({"id": f"prompt_{index:06d}", "input": stripped})
    return records


def _read_bson_records(path: Path) -> list[dict[str, Any]]:
    if _decode_file_iter is None:
        raise RuntimeError("Install bson or pymongo to read BSON prompt sources")
    with path.open("rb") as handle:
        return [dict(raw) for raw in _decode_file_iter(handle)]
