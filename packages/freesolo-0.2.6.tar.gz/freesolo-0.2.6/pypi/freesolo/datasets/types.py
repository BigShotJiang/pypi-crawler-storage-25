from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from pathlib import Path
from typing import TypeAlias

from freesolo.utils.core import JsonObject, MetadataDict

DatasetRecord = JsonObject
DatasetMetadata = MetadataDict
DatasetSource: TypeAlias = str | Path | Iterable["TaskExample | DatasetRecord"]


@dataclass(frozen=True)
class TaskExample:
    record: DatasetRecord
    task: str
    task_id: str | None = None
    metadata: DatasetMetadata = field(default_factory=dict)
    expected_output: object | None = None


__all__ = [
    "TaskExample",
]
