from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from freesolo.contracts.markdown import ChatMessage
from freesolo.utils.core import serialize_value

from .records import load_task_examples
from .types import DatasetSource, TaskExample


class PromptBuilder(Protocol):
    def build_prompt_messages(
        self,
        example: TaskExample,
        prompt_text: str,
    ) -> list[ChatMessage]:
        """Build model-input messages for one labeled example."""


@dataclass(frozen=True)
class Dataset:
    examples: list[TaskExample]

    @classmethod
    def from_source(
        cls,
        source: DatasetSource,
    ) -> Dataset:
        return cls(examples=load_task_examples(source))

    def build_conversations(
        self,
        prompt_builder: PromptBuilder,
        prompt_text: str,
    ) -> list[list[ChatMessage]]:
        return [
            _build_conversation(prompt_builder, example, prompt_text)
            for example in self.examples
        ]


def load_dataset(
    source: DatasetSource,
) -> Dataset:
    return Dataset.from_source(source)


def _build_conversation(
    prompt_builder: PromptBuilder,
    example: TaskExample,
    prompt_text: str,
) -> list[ChatMessage]:
    if example.expected_output is None:
        raise ValueError(
            "Each labeled record must contain task/prompt/query/input plus "
            "ground_truth/expected_output/output/completion"
        )
    messages = prompt_builder.build_prompt_messages(example, prompt_text)
    return [
        *messages,
        {
            "role": "assistant",
            "content": serialize_value(example.expected_output),
        },
    ]


__all__ = [
    "Dataset",
    "PromptBuilder",
    "load_dataset",
]
