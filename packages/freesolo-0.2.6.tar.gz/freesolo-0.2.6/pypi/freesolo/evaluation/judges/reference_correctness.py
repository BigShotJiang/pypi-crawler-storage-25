from __future__ import annotations

from typing import Any

from ...utils.core import _require_field
from ..types import DataRow
from .base import HostedLLMScorer


class ReferenceCorrectnessScorer(HostedLLMScorer):
    name = "reference_correctness"
    threshold = 0.8

    def build_instructions(self, row: DataRow) -> str:
        _ = row
        return (
            "Judge whether actual_output is correct with respect to expected_output. "
            "Use the input for context. Penalize factual mistakes, omissions, or contradictions."
        )

    def build_payload(self, row: DataRow) -> dict[str, Any]:
        return {
            "input": row.get("input"),
            "actual_output": _require_field(row, "actual_output"),
            "expected_output": _require_field(row, "expected_output"),
        }
