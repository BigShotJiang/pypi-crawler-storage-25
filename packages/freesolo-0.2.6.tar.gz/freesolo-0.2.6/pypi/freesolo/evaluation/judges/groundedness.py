from __future__ import annotations

from typing import Any

from ...utils.core import _find_first_present, _require_field
from ..types import DataRow
from .base import HostedLLMScorer


class GroundednessScorer(HostedLLMScorer):
    name = "groundedness"
    threshold = 0.8

    def build_instructions(self, row: DataRow) -> str:
        _ = row
        return (
            "Judge whether actual_output is fully supported by the supplied context. "
            "Penalize unsupported claims, hallucinations, and overstatements."
        )

    def build_payload(self, row: DataRow) -> dict[str, Any]:
        context = _find_first_present(
            row, ("context", "contexts", "retrieved_documents", "sources")
        )
        if context is None:
            raise ValueError(
                "groundedness scorer requires one of: context, contexts, "
                "retrieved_documents, or sources"
            )
        return {
            "input": row.get("input"),
            "actual_output": _require_field(row, "actual_output"),
            "context": context,
        }
