from __future__ import annotations

from typing import Any

from ...utils.core import _find_first_present, _require_field
from ..types import DataRow
from .base import HostedLLMScorer


class InstructionFollowingScorer(HostedLLMScorer):
    name = "instruction_following"
    threshold = 0.85

    def build_instructions(self, row: DataRow) -> str:
        _ = row
        return (
            "Judge whether actual_output followed the user's instructions and task constraints. "
            "Consider requested format, completeness, and compliance."
        )

    def build_payload(self, row: DataRow) -> dict[str, Any]:
        task = _find_first_present(row, ("instructions", "input", "prompt"))
        if task is None:
            raise ValueError(
                "instruction_following scorer requires one of: instructions, input, or prompt"
            )
        return {
            "instructions": task,
            "actual_output": _require_field(row, "actual_output"),
            "expected_output": row.get("expected_output"),
        }
