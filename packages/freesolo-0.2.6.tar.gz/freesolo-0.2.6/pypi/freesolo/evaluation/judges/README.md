# Evaluation Judges

Hosted judges score model outputs against the approved contract. Generated repos
should normally import judges from `freesolo.evaluation`, not this subpackage.

## Public Imports

```python
from freesolo.evaluation import (
    CustomScorer,
    GroundednessScorer,
    HostedJudgeClient,
    InstructionFollowingScorer,
    PairwisePreferenceScorer,
    ReferenceCorrectnessScorer,
    RubricScorer,
)
```

## Agent Guidance

- Use `CustomScorer` for repo-specific deterministic or model-assisted scorers.
- Use hosted judge scorers only for public eval dimensions that match the
  approved contract.
- Keep training-only reward shaping in `freesolo/environment.py`; do not encode
  it as a public judge unless it is also part of the eval contract.
- Pass API keys into clients at runtime. Do not commit secrets or generate
  repo-local defaults for secrets.
