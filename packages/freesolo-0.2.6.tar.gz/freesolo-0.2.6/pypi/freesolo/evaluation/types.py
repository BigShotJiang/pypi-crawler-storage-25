from __future__ import annotations

from ..utils.core import JsonObject, JsonValue, MetadataDict

DataRow = JsonObject
EvaluationMetadata = MetadataDict
ScorerValue = JsonValue
ScorerMetadata = MetadataDict


__all__ = [
    "DataRow",
    "EvaluationMetadata",
    "ScorerMetadata",
    "ScorerValue",
]
