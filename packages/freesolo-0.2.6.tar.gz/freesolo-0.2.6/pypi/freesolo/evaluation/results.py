from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

from ..utils.core import JsonObject
from .types import DataRow, ScorerMetadata, ScorerValue


@dataclass(slots=True)
class ScorerMetricData:
    name: str
    score: float | None = None
    value: ScorerValue = None
    success: bool | None = None
    threshold: float | None = None
    weight: float | None = None
    reason: str | None = None
    metadata: ScorerMetadata = field(default_factory=dict)

    def to_dict(self) -> JsonObject:
        payload: JsonObject = {"name": self.name}
        for key, value in {
            "score": self.score,
            "value": self.value,
            "success": self.success,
            "threshold": self.threshold,
            "weight": self.weight,
            "reason": self.reason,
            "metadata": self.metadata,
        }.items():
            if value is not None and value != {} and value != []:
                payload[key] = value
        return payload


@dataclass(slots=True)
class ScorerData:
    name: str
    success: bool
    value: ScorerValue = None
    score: float | None = None
    threshold: float | None = None
    reason: str | None = None
    error: str | None = None
    return_type: Literal["binary", "numeric"] | None = None
    # Wall time of the scorer's score() call, measured by the runner.
    latency_ms: int | None = None
    # Token usage reported by the scorer's response, if tracked.
    total_tokens: int | None = None
    metadata: ScorerMetadata = field(default_factory=dict)
    metrics: list[ScorerMetricData] = field(default_factory=list)

    def to_dict(self) -> JsonObject:
        payload: JsonObject = {
            "name": self.name,
            "success": self.success,
        }
        for key, value in {
            "value": self.value,
            "score": self.score,
            "threshold": self.threshold,
            "reason": self.reason,
            "error": self.error,
            "return_type": self.return_type,
            "latency_ms": self.latency_ms,
            "total_tokens": self.total_tokens,
            "metadata": self.metadata,
            "metrics": [metric.to_dict() for metric in self.metrics],
        }.items():
            if value is not None and value != {} and value != []:
                payload[key] = value
        return payload


@dataclass(slots=True)
class ScoringResult:
    success: bool
    scorers_data: list[ScorerData]
    data_object: DataRow
    # populated client-side from the post response; not sent on the wire.
    run_id: str | None = None
    # whole-run wall time in seconds; not sent on the wire (backend does not
    # consume it). kept on the dataclass for user-facing inspection.
    run_duration: float | None = None

    def to_dict(self) -> JsonObject:
        payload: JsonObject = {
            "success": self.success,
            "scorers_data": [scorer.to_dict() for scorer in self.scorers_data],
            "data_object": dict(self.data_object),
        }
        return payload
