from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


@dataclass(slots=True)
class BaseResponse:
    value: Any
    reason: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)
    # Opt-in: scorers that wrap an LLM call should report token usage so the
    # backend can roll it up into eval_tasks.tokens_used.
    total_tokens: int | None = None

    @property
    def return_type(self) -> Literal["binary", "numeric"]:
        raise NotImplementedError

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "value": self.value,
            "reason": self.reason,
            "return_type": self.return_type,
        }
        if self.metadata:
            payload["metadata"] = dict(self.metadata)
        if self.total_tokens is not None:
            payload["total_tokens"] = self.total_tokens
        return payload


@dataclass(slots=True)
class BinaryResponse(BaseResponse):
    value: bool

    def __post_init__(self) -> None:
        self.value = bool(self.value)

    @property
    def return_type(self) -> Literal["binary"]:
        return "binary"


@dataclass(slots=True)
class NumericResponse(BaseResponse):
    value: float

    def __post_init__(self) -> None:
        self.value = float(self.value)

    @property
    def return_type(self) -> Literal["numeric"]:
        return "numeric"


ScorerResponse = BinaryResponse | NumericResponse
