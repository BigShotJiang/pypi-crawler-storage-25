from __future__ import annotations

import base64
import dataclasses
import hashlib
import re
from collections.abc import Mapping, Sequence
from typing import Any

DATA_URL_RE = re.compile(r"^data:([^;,]+)?(;base64)?,(.*)$", re.DOTALL)
MAX_STRING_LENGTH = 4000
MAX_COLLECTION_ITEMS = 50
MAX_DEPTH = 8
MAX_INLINE_IMAGE_BYTES = 5 * 1024 * 1024
SAFE_INLINE_IMAGE_MEDIA_TYPES = {
    "image/gif",
    "image/jpeg",
    "image/jpg",
    "image/png",
    "image/webp",
}


def _truncate_text(value: str) -> str:
    if len(value) <= MAX_STRING_LENGTH:
        return value
    omitted = len(value) - MAX_STRING_LENGTH
    return f"{value[:MAX_STRING_LENGTH]}... <truncated {omitted} chars>"


def _estimate_base64_bytes(payload: str) -> int:
    padding = payload.count("=")
    return max(0, (len(payload) * 3) // 4 - padding)


def _can_embed_image(media_type: str, byte_count: int) -> bool:
    return (
        media_type.lower() in SAFE_INLINE_IMAGE_MEDIA_TYPES
        and byte_count <= MAX_INLINE_IMAGE_BYTES
    )


def _mark_omitted_image_data_url(
    summary: dict[str, Any],
    media_type: str,
    byte_count: int,
) -> None:
    if media_type.lower() not in SAFE_INLINE_IMAGE_MEDIA_TYPES:
        summary["omitted_data_url_reason"] = "unsupported_image_media_type"
        return
    if byte_count > MAX_INLINE_IMAGE_BYTES:
        summary["omitted_data_url_reason"] = "image_too_large"
        summary["max_inline_image_bytes"] = MAX_INLINE_IMAGE_BYTES


def _summarize_data_url(value: str) -> dict[str, Any]:
    match = DATA_URL_RE.match(value)
    if not match:
        return {"type": "string", "value": _truncate_text(value)}

    media_type = match.group(1) or "application/octet-stream"
    is_base64 = bool(match.group(2))
    data = match.group(3)

    if is_base64:
        approx_bytes = _estimate_base64_bytes(data)
        digest = hashlib.sha256(data[:8192].encode("utf-8")).hexdigest()
        summary = {
            "type": "data_url",
            "media_type": media_type,
            "encoding": "base64",
            "approx_bytes": approx_bytes,
            "sha256_prefix": digest,
        }
        if media_type.startswith("image/") and _can_embed_image(
            media_type,
            approx_bytes,
        ):
            summary["data_url"] = value
        elif media_type.startswith("image/"):
            _mark_omitted_image_data_url(summary, media_type, approx_bytes)
        return summary

    return {
        "type": "data_url",
        "media_type": media_type,
        "encoding": "urlencoded",
        "approx_chars": len(data),
    }


def _summarize_bytes(value: bytes | bytearray | memoryview) -> dict[str, Any]:
    raw = bytes(value)
    return {
        "type": "bytes",
        "length": len(raw),
        "sha256_prefix": hashlib.sha256(raw[:8192]).hexdigest(),
        "base64_preview": base64.b64encode(raw[:24]).decode("ascii"),
    }


def _summarize_inline_bytes_blob(value: Mapping[str, Any]) -> dict[str, Any] | None:
    data = value.get("data")
    mime_type = value.get("mime_type") or value.get("media_type")

    if not isinstance(mime_type, str):
        return None
    if not mime_type.startswith("image/"):
        return None
    if not isinstance(data, (bytes, bytearray, memoryview)):
        return None

    raw = bytes(data)
    summary = {
        "type": "inline_data",
        "media_type": mime_type,
        "encoding": "base64",
        "approx_bytes": len(raw),
        "sha256_prefix": hashlib.sha256(raw[:8192]).hexdigest(),
    }
    if _can_embed_image(mime_type, len(raw)):
        encoded = base64.b64encode(raw).decode("ascii")
        summary["data_url"] = f"data:{mime_type};base64,{encoded}"
    else:
        _mark_omitted_image_data_url(summary, mime_type, len(raw))
    return summary


def _summarize_base64_blob(value: Mapping[str, Any]) -> dict[str, Any] | None:
    data = value.get("data")
    blob_type = value.get("type")
    if blob_type != "base64" or not isinstance(data, str):
        return None

    media_type = value.get("media_type") or "application/octet-stream"
    approx_bytes = _estimate_base64_bytes(data)
    summary = {
        "type": "base64_blob",
        "media_type": media_type,
        "encoding": "base64",
        "approx_bytes": approx_bytes,
        "sha256_prefix": hashlib.sha256(data[:8192].encode("utf-8")).hexdigest(),
    }
    if (
        isinstance(media_type, str)
        and media_type.startswith("image/")
        and _can_embed_image(media_type, approx_bytes)
    ):
        summary["data_url"] = f"data:{media_type};base64,{data}"
    elif isinstance(media_type, str) and media_type.startswith("image/"):
        _mark_omitted_image_data_url(summary, media_type, approx_bytes)
    return summary


def sanitize_value(value: Any, *, _depth: int = 0) -> Any:
    if _depth >= MAX_DEPTH:
        return {"type": "max_depth_reached", "repr": repr(value)[:500]}

    if value is None or isinstance(value, (bool, int, float)):
        return value

    if isinstance(value, str):
        if value.startswith("data:"):
            return _summarize_data_url(value)
        return _truncate_text(value)

    if isinstance(value, (bytes, bytearray, memoryview)):
        return _summarize_bytes(value)

    if dataclasses.is_dataclass(value):
        return sanitize_value(dataclasses.asdict(value), _depth=_depth + 1)

    if hasattr(value, "model_dump") and callable(value.model_dump):
        try:
            return sanitize_value(value.model_dump(), _depth=_depth + 1)
        except Exception:
            return {"type": "model_dump_error", "repr": repr(value)[:500]}

    if hasattr(value, "dict") and callable(value.dict):
        try:
            return sanitize_value(value.dict(), _depth=_depth + 1)
        except Exception:
            return {"type": "dict_error", "repr": repr(value)[:500]}

    if isinstance(value, Mapping):
        inline_bytes_summary = _summarize_inline_bytes_blob(value)
        if inline_bytes_summary is not None:
            return inline_bytes_summary

        base64_summary = _summarize_base64_blob(value)
        if base64_summary is not None:
            return base64_summary

        items = list(value.items())[:MAX_COLLECTION_ITEMS]
        output: dict[str, Any] = {}
        for key, item_value in items:
            output[str(key)] = sanitize_value(item_value, _depth=_depth + 1)
        if len(value) > MAX_COLLECTION_ITEMS:
            output["__truncated_items__"] = len(value) - MAX_COLLECTION_ITEMS
        return output

    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        items = list(value)[:MAX_COLLECTION_ITEMS]
        output = [sanitize_value(item, _depth=_depth + 1) for item in items]
        if len(value) > MAX_COLLECTION_ITEMS:
            output.append(
                {
                    "type": "truncated_items",
                    "count": len(value) - MAX_COLLECTION_ITEMS,
                }
            )
        return output

    if hasattr(value, "__dict__"):
        try:
            return sanitize_value(vars(value), _depth=_depth + 1)
        except Exception:
            return {"type": "object", "repr": repr(value)[:500]}

    return {"type": "repr", "value": repr(value)[:500]}
