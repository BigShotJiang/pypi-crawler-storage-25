from __future__ import annotations

import json
import logging
import math
from collections.abc import Callable, Mapping, Sequence
from typing import Any

from opentelemetry import trace as otel_trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import (
    ReadableSpan,
    SpanLimits,
    SpanProcessor,
    TracerProvider,
)
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    SimpleSpanProcessor,
    SpanExporter,
    SpanExportResult,
)

from .._usage import record_function_usage
from ..utils.core import _require_api_key, _resolve_base_url, truncate_text
from .sanitize import sanitize_value

logger = logging.getLogger("freesolo.tracing.otel")

OTEL_TRACER_NAME = "freesolo"
OTLP_TRACE_INGEST_PATH = "/api/traces/ingest"
DEFAULT_MAX_ATTRIBUTE_LENGTH = 8_192
DEFAULT_MAX_SPAN_ATTRIBUTES = 128

_configured_provider: TracerProvider | None = None


class _FreesoloSpanExporter(SpanExporter):
    """OpenTelemetry exporter that sends spans to Freesolo over native OTLP/HTTP."""

    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        endpoint_path: str = OTLP_TRACE_INGEST_PATH,
        timeout_seconds: float = 10.0,
        headers: Mapping[str, str] | None = None,
    ) -> None:
        resolved_api_key = _require_api_key(
            api_key,
            error_message="Freesolo OpenTelemetry export requires FREESOLO_API_KEY.",
        )
        endpoint = _otlp_endpoint(base_url=base_url, endpoint_path=endpoint_path)
        self._delegate = OTLPSpanExporter(
            endpoint=endpoint,
            headers={
                "Authorization": f"Bearer {resolved_api_key}",
                "X-Freesolo-Function": "freesolo.tracing.configure_tracer",
                **dict(headers or {}),
            },
            timeout=timeout_seconds,
        )

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        return self._delegate.export(spans)

    def shutdown(self) -> None:
        self._delegate.shutdown()

    def force_flush(self, timeout_millis: int = 30_000) -> bool:
        return self._delegate.force_flush(timeout_millis)


def configure_tracer(
    *,
    service_name: str = "freesolo",
    base_url: str | None = None,
    api_key: str | None = None,
    resource_attributes: Mapping[str, Any] | None = None,
    batch: bool = True,
    set_global: bool = True,
    endpoint_path: str = OTLP_TRACE_INGEST_PATH,
    timeout_seconds: float = 10.0,
    serializer: Callable[[Any], str] | None = None,
    span_limits: SpanLimits | None = None,
    max_attribute_length: int = DEFAULT_MAX_ATTRIBUTE_LENGTH,
    max_span_attributes: int = DEFAULT_MAX_SPAN_ATTRIBUTES,
    span_processors: Sequence[SpanProcessor] | None = None,
    headers: Mapping[str, str] | None = None,
) -> TracerProvider:
    """Configure the Freesolo OpenTelemetry tracer exporter."""

    global _configured_provider

    record_function_usage(
        "freesolo.tracing.configure_tracer",
        api_key=api_key,
        base_url=base_url,
    )
    resource = Resource.create(
        {
            "service.name": service_name or "freesolo",
            "telemetry.sdk.name": "freesolo",
            **_sanitize_otel_attributes(
                resource_attributes or {},
                serializer=serializer,
                max_attribute_length=max_attribute_length,
            ),
        }
    )
    provider = TracerProvider(
        resource=resource,
        span_limits=span_limits
        or SpanLimits(
            max_span_attributes=max_span_attributes,
            max_span_attribute_length=max_attribute_length,
        ),
    )
    exporter = _FreesoloSpanExporter(
        base_url=base_url,
        api_key=api_key,
        endpoint_path=endpoint_path,
        timeout_seconds=timeout_seconds,
        headers=headers,
    )
    processor = BatchSpanProcessor(exporter) if batch else SimpleSpanProcessor(exporter)
    provider.add_span_processor(processor)
    for extra_processor in span_processors or ():
        provider.add_span_processor(extra_processor)

    if set_global:
        try:
            otel_trace.set_tracer_provider(provider)
        except Exception:
            logger.exception("failed to set global OpenTelemetry tracer provider")

    _configured_provider = provider
    return provider


def get_tracer(name: str = OTEL_TRACER_NAME):
    return otel_trace.get_tracer(name)


def force_flush(timeout_millis: int = 30_000) -> bool:
    provider = _configured_provider
    return bool(provider and provider.force_flush(timeout_millis))


def shutdown() -> None:
    provider = _configured_provider
    if provider is not None:
        provider.shutdown()


def _sanitize_otel_attributes(
    attributes: Mapping[str, Any],
    *,
    serializer: Callable[[Any], str] | None = None,
    max_attribute_length: int = DEFAULT_MAX_ATTRIBUTE_LENGTH,
) -> dict[str, str | bool | int | float | Sequence[str | bool | int | float]]:
    sanitized: dict[
        str, str | bool | int | float | Sequence[str | bool | int | float]
    ] = {}
    for key, value in attributes.items():
        coerced = _coerce_otel_attribute(
            value,
            serializer=serializer,
            max_attribute_length=max_attribute_length,
        )
        if coerced is not None:
            sanitized[str(key)] = coerced
    return sanitized


def _otlp_endpoint(*, base_url: str | None, endpoint_path: str) -> str:
    normalized_path = (
        endpoint_path if endpoint_path.startswith("/") else f"/{endpoint_path}"
    )
    return f"{_resolve_base_url(base_url)}{normalized_path}"


def _coerce_otel_attribute(
    value: Any,
    *,
    serializer: Callable[[Any], str] | None,
    max_attribute_length: int,
) -> str | bool | int | float | Sequence[str | bool | int | float] | None:
    value = sanitize_value(value)
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if isinstance(value, str):
        return truncate_text(value, max_attribute_length)
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        scalar_values = [
            _coerce_scalar_attribute(item, max_attribute_length=max_attribute_length)
            for item in value
        ]
        if all(item is not None for item in scalar_values):
            return [item for item in scalar_values if item is not None]
    return truncate_text(_serialize_attribute(value, serializer), max_attribute_length)


def _coerce_scalar_attribute(
    value: Any,
    *,
    max_attribute_length: int,
) -> str | bool | int | float | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    if isinstance(value, int):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else str(value)
    if isinstance(value, str):
        return truncate_text(value, max_attribute_length)
    return None


def _serialize_attribute(
    value: Any,
    serializer: Callable[[Any], str] | None,
) -> str:
    if serializer is not None:
        return serializer(value)
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


__all__ = [
    "configure_tracer",
    "force_flush",
    "get_tracer",
    "shutdown",
]
