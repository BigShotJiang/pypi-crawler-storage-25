# Tracing

Tracing configures OpenTelemetry export for SDK activity.

## Public Imports

```python
from freesolo.tracing import configure_tracer, force_flush, get_tracer, shutdown
```

## Agent Guidance

- Call `configure_tracer(...)` from a generated entrypoint only when trace export
  is explicitly requested.
- Pass `api_key` and `base_url` at runtime when they are known by the caller.
- Use `get_tracer(...)` for custom spans around generated repo work.
- Call `force_flush(...)` or `shutdown()` before process exit when a short-lived
  command needs trace delivery.
- Do not import `sanitize` or exporter internals from generated repos.
