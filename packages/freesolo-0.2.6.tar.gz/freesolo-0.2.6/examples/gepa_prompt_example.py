from __future__ import annotations

import argparse
from pathlib import Path

from environment import SupportEnvironment
from freesolo.gepa import DefaultReflectionAgent, GEPAConfig, GEPASetup
from freesolo.gepa.types import EnvironmentGEPAContext
from support_dataset import PROMPT_PATH, TRAIN_DATASET_PATH


def rollout_candidate(context: EnvironmentGEPAContext) -> str:
    if "required product path terms" in context.prompt_text.lower():
        return str(context.example.expected_output or "")
    return "Please contact support."


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a Freesolo GEPA example.")
    parser.add_argument("--dataset", default=str(TRAIN_DATASET_PATH))
    parser.add_argument("--prompt", default=str(PROMPT_PATH))
    parser.add_argument(
        "--optimize",
        action="store_true",
        help="Call gepa.optimize. Requires installing the GEPA extra.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    prompt_text = Path(args.prompt).read_text(encoding="utf-8")
    environment = SupportEnvironment()
    reflection_agent = DefaultReflectionAgent(
        generate=lambda prompt: (
            '{"prompt": "Answer with the canonical support action and include '
            'the required product path terms."}'
        )
    )
    setup = GEPASetup.from_environment(
        environment,
        rollout=rollout_candidate,
        train_source=args.dataset,
        prompt_text=prompt_text,
        reflection_agent=reflection_agent,
        config=GEPAConfig(max_metric_calls=4, use_wandb=False),
    )

    baseline = setup.adapter.evaluate(
        setup.trainset,
        setup.seed_candidate,
        capture_traces=True,
    )
    print(f"baseline_scores={baseline.scores}")

    reflective_dataset = setup.adapter.make_reflective_dataset(
        setup.seed_candidate,
        baseline,
        components_to_update=["prompt"],
    )
    proposed = reflection_agent.propose_new_texts(
        setup.seed_candidate,
        reflective_dataset,
        ["prompt"],
    )
    improved = setup.adapter.evaluate(setup.trainset, proposed)
    print(f"proposed_prompt={proposed['prompt']}")
    print(f"improved_scores={improved.scores}")

    if args.optimize:
        result = setup.optimize()
        print(result)


if __name__ == "__main__":
    main()
