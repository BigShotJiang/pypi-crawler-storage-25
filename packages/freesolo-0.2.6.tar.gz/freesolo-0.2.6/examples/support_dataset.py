from __future__ import annotations

from pathlib import Path

from freesolo.datasets import TaskExample
from freesolo.datasets.records import load_task_examples

EXAMPLES_DIR = Path(__file__).resolve().parent
CONTRACT_PATH = EXAMPLES_DIR / "TRAINING_CONTRACT.md"
PROMPT_PATH = EXAMPLES_DIR / "PROMPT.md"
EVAL_DATASET_PATH = EXAMPLES_DIR / "data" / "support_eval.jsonl"
TRAIN_DATASET_PATH = EXAMPLES_DIR / "data" / "support_train.jsonl"


def load_eval_examples() -> list[TaskExample]:
    return load_task_examples(EVAL_DATASET_PATH)


def load_training_examples() -> list[TaskExample]:
    return load_task_examples(TRAIN_DATASET_PATH)
