from __future__ import annotations

import argparse
from typing import Any

from environment import SupportEnvironment, generate_support_answer
from freesolo.evaluation import EvaluationClient
from support_dataset import CONTRACT_PATH, EVAL_DATASET_PATH


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run an environment eval from example files."
    )
    parser.add_argument("--name", default="support-agent-file-backed-eval")
    parser.add_argument("--dataset", default=str(EVAL_DATASET_PATH))
    parser.add_argument("--contract", default=str(CONTRACT_PATH))
    return parser.parse_args()


def print_results(results: list[Any]) -> None:
    for index, result in enumerate(results, start=1):
        scorer = result.scorers_data[0]
        print(
            f"{index}. {'pass' if result.success else 'fail'}: "
            f"{scorer.name} score={scorer.score} reason={scorer.reason}"
        )


def main() -> None:
    args = parse_args()
    environment = SupportEnvironment()

    results = EvaluationClient().run_environment(
        name=args.name,
        source=args.dataset,
        contract_path=args.contract,
        environment=environment,
        generate=generate_support_answer,
        metadata={"example": "evaluation_from_files"},
    )

    print_results(results)


if __name__ == "__main__":
    main()
