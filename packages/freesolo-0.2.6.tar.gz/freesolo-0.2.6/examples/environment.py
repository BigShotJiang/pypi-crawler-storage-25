from __future__ import annotations

from typing import Any

from freesolo.datasets import TaskExample
from freesolo.environments import (
    Environment,
    EnvironmentGeneration,
    RewardMetric,
    RewardResult,
)
from freesolo.training import GrpoConfig


class SupportEnvironment(Environment):
    def build_prompt_messages(
        self,
        example: TaskExample,
        prompt_text: str,
    ) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": prompt_text},
            {"role": "user", "content": example.task},
        ]

    def get_grpo_config(self) -> GrpoConfig:
        return GrpoConfig(
            batch_size=2,
            group_size=2,
            learning_rate=1e-5,
            max_tokens=128,
            num_epochs=1,
            save_every=10,
            temperature=0.7,
        )

    def score_response(
        self,
        example: TaskExample,
        response_text: str,
    ) -> RewardResult:
        expected = str(example.expected_output or "").strip()
        required_terms = _required_terms(example.record)
        normalized_response = response_text.lower()

        expected_match = bool(expected) and expected.lower() in normalized_response
        matched_terms = [
            term for term in required_terms if term.lower() in normalized_response
        ]
        term_score = len(matched_terms) / len(required_terms) if required_terms else 1.0
        exact_score = 1.0 if expected_match else 0.0
        score = (exact_score * 0.7) + (term_score * 0.3)
        passed = score >= 0.8

        return RewardResult(
            name="support_answer_quality",
            score=score,
            success=passed,
            threshold=0.8,
            value=passed,
            reason="answered with the canonical support action"
            if passed
            else "response missed the expected action or required terms",
            return_type="numeric",
            metadata={
                "expected_output": expected,
                "matched_terms": matched_terms,
                "required_terms": required_terms,
            },
            metrics=(
                RewardMetric(
                    name="expected_answer",
                    score=exact_score,
                    success=expected_match,
                    threshold=1.0,
                ),
                RewardMetric(
                    name="required_terms",
                    score=term_score,
                    success=term_score >= 1.0,
                    threshold=1.0,
                    metadata={"matched_terms": matched_terms},
                ),
            ),
        )


def generate_support_answer(
    messages: list[dict[str, str]],
    example: TaskExample,
) -> EnvironmentGeneration:
    """Example model callback used by eval scripts."""

    _ = messages
    return EnvironmentGeneration(
        response_text=str(example.expected_output or ""),
        metadata={"model": "example-deterministic-support-agent"},
    )


def load_environment(**kwargs: object) -> SupportEnvironment:
    _ = kwargs
    return SupportEnvironment()


def _required_terms(record: dict[str, Any]) -> list[str]:
    raw_terms = record.get("required_terms")
    if not isinstance(raw_terms, list):
        return []
    return [str(term) for term in raw_terms if str(term).strip()]
