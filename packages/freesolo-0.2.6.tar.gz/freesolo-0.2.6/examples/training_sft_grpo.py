from __future__ import annotations

import argparse
import os
from collections.abc import Iterator
from contextlib import contextmanager

from freesolo.training import SftConfig, train_grpo, train_sft
from support_dataset import EXAMPLES_DIR, TRAIN_DATASET_PATH


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Start a Freesolo training run.")
    parser.add_argument("phase", choices=("sft", "grpo"))
    parser.add_argument("--dataset", default=str(TRAIN_DATASET_PATH))
    parser.add_argument("--base-model", default="openai/gpt-oss-20b")
    parser.add_argument("--base-url")
    parser.add_argument("--log-dir")
    parser.add_argument("--sft-log-dir", default="./logs/sft")
    parser.add_argument("--sft-checkpoint-name", default="final")
    parser.add_argument("--sft-state-path")
    parser.add_argument("--reward-command")
    parser.add_argument("--batch-size", type=int)
    parser.add_argument("--learning-rate", type=float)
    parser.add_argument("--lora-rank", type=int)
    parser.add_argument("--max-length", type=int)
    parser.add_argument("--num-epochs", type=int)
    parser.add_argument("--save-every", type=int)
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    with example_project_root():
        if args.phase == "sft":
            return train_sft(
                dataset_path=args.dataset,
                log_dir=args.log_dir or args.sft_log_dir,
                base_model=args.base_model,
                base_url=args.base_url,
                sft_config=SftConfig(
                    batch_size=args.batch_size,
                    learning_rate=args.learning_rate,
                    lora_rank=args.lora_rank,
                    max_length=args.max_length,
                    num_epochs=args.num_epochs,
                    save_every=args.save_every,
                ),
            )

        return train_grpo(
            dataset_path=args.dataset,
            log_dir=args.log_dir or "./logs/grpo",
            sft_log_dir=args.sft_log_dir,
            sft_checkpoint_name=args.sft_checkpoint_name,
            sft_state_path=args.sft_state_path,
            reward_command=args.reward_command,
            base_model=args.base_model,
            base_url=args.base_url,
        )


@contextmanager
def example_project_root() -> Iterator[None]:
    previous_cwd = os.getcwd()
    os.chdir(EXAMPLES_DIR)
    try:
        yield
    finally:
        os.chdir(previous_cwd)


if __name__ == "__main__":
    raise SystemExit(main())
