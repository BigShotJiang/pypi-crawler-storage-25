from __future__ import annotations

import argparse
from typing import Any

from freesolo.evaluation import (
    BinaryResponse,
    CustomScorer,
    EvaluationClient,
    NumericResponse,
    run_local_evaluation,
)


class ExactMatch(CustomScorer[BinaryResponse]):
    name = "exact_match"

    async def score(self, row: dict[str, Any]) -> BinaryResponse:
        actual = str(row.get("actual_output", "")).strip().lower()
        expected = str(row.get("expected_output", "")).strip().lower()
        passed = bool(actual) and actual == expected
        return BinaryResponse(
            value=passed,
            reason="answers match"
            if passed
            else f"expected {expected!r}, got {actual!r}",
        )


class RequiredTerms(CustomScorer[NumericResponse]):
    name = "required_terms"
    threshold = 0.8

    async def score(self, row: dict[str, Any]) -> NumericResponse:
        actual = str(row.get("actual_output", "")).lower()
        terms = [str(term).lower() for term in row.get("required_terms", [])]
        if not terms:
            return NumericResponse(value=1.0, reason="no required terms")

        matched = [term for term in terms if term in actual]
        score = len(matched) / len(terms)
        return NumericResponse(
            value=score,
            reason=f"matched {len(matched)} of {len(terms)} required terms",
            metadata={"matched_terms": matched, "required_terms": terms},
        )


def build_dataset() -> list[dict[str, Any]]:
    return [
        {
            "input": "What is the capital of France?",
            "actual_output": "Paris",
            "expected_output": "Paris",
            "required_terms": ["paris"],
        },
        {
            "input": "How do I reset my password?",
            "actual_output": "Open Account settings, then choose Security.",
            "expected_output": "Use Account settings > Security.",
            "required_terms": ["account settings", "security"],
        },
    ]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run a Freesolo eval example.")
    parser.add_argument("--name", default="support-agent-custom-scorers")
    parser.add_argument(
        "--local",
        action="store_true",
        help="Run scorers locally without uploading results to Freesolo.",
    )
    return parser.parse_args()


def print_results(results: list[Any]) -> None:
    for index, result in enumerate(results, start=1):
        scorer_summary = ", ".join(
            f"{scorer.name}={'pass' if scorer.success else 'fail'}"
            for scorer in result.scorers_data
        )
        print(f"{index}. {'pass' if result.success else 'fail'}: {scorer_summary}")


def main() -> None:
    args = parse_args()
    data = build_dataset()
    scorers = [ExactMatch(), RequiredTerms()]

    if args.local:
        results = run_local_evaluation(data=data, scorers=scorers)
    else:
        results = EvaluationClient().run(
            name=args.name,
            data=data,
            scorers=scorers,
            metadata={"example": "evaluation_custom_scorer"},
        )

    print_results(results)


if __name__ == "__main__":
    main()
