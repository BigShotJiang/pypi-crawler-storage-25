from __future__ import annotations

import importlib
import inspect
import json
import re
from pathlib import Path

import pytest

SDK_ROOT = Path(__file__).resolve().parents[2]
WORKSPACE_ROOT = SDK_ROOT.parent
FREESOLO_REPO_ROOT = WORKSPACE_ROOT / "freesolo"
if not FREESOLO_REPO_ROOT.exists():
    FREESOLO_REPO_ROOT = WORKSPACE_ROOT / "rl"
REGISTRY_PATH = SDK_ROOT / "function_usage_registry.json"
USAGE_MIGRATION_PATH = (
    FREESOLO_REPO_ROOT
    / "frontend"
    / "supabase"
    / "migrations"
    / "20260514010000_create_package_function_usage.sql"
)
SOURCE_ROOTS = (
    SDK_ROOT / "pypi" / "freesolo",
    FREESOLO_REPO_ROOT / "agent" / "src",
)
TRACKED_NAME_RE = re.compile(
    r"""(?:function_name=|record_function_usage\()\s*["']([^"']+)["']"""
    r"""|["']X-Freesolo-Function["']\s*:\s*["']([^"']+)["']"""
    r"""|(?:\[["']X-Freesolo-Function["']\]\s*=\s*)["']([^"']+)["']"""
)
PUBLIC_API_MODULES = (
    "freesolo.contracts",
    "freesolo.datasets",
    "freesolo.environments",
    "freesolo.evaluation",
    "freesolo.evaluation.judges",
    "freesolo.gepa",
    "freesolo.tracing",
    "freesolo.training",
    "freesolo.utils.oracle",
    "freesolo.utils.upload",
)
PUBLIC_API_EXTRAS = (
    "freesolo.utils.storage.FreesoloStorageClient",
    "freesolo.utils.wandb.generate_wandb_run_id",
    "freesolo.utils.wandb.start_wandb_run",
    "freesolo_agent.run_backend_training_job",
)


def _tracked_function_names() -> set[str]:
    names: set[str] = set()
    for root in SOURCE_ROOTS:
        if not root.exists():
            continue
        for path in root.rglob("*.py"):
            for match in TRACKED_NAME_RE.finditer(path.read_text(encoding="utf-8")):
                names.add(next(group for group in match.groups() if group is not None))
    return names


def _public_function_names() -> set[str]:
    names: set[str] = set()
    for module_name in PUBLIC_API_MODULES:
        module = importlib.import_module(module_name)
        for exported_name in getattr(module, "__all__", ()):
            value = getattr(module, exported_name)
            if inspect.isfunction(value):
                names.add(f"{module_name}.{exported_name}")
            elif inspect.isclass(value):
                names.update(_public_class_method_names(exported_name, value))

    for qualified_name in PUBLIC_API_EXTRAS:
        if qualified_name == "freesolo_agent.run_backend_training_job":
            names.add(qualified_name)
            continue
        module_name, _, exported_name = qualified_name.rpartition(".")
        value = getattr(importlib.import_module(module_name), exported_name)
        if inspect.isfunction(value):
            names.add(qualified_name)
        elif inspect.isclass(value):
            names.update(_public_class_method_names(exported_name, value))

    return names


def _public_class_method_names(class_name: str, class_type: type[object]) -> set[str]:
    names: set[str] = set()
    for method_name, raw_value in class_type.__dict__.items():
        if method_name.startswith("_"):
            continue
        value = raw_value
        if isinstance(value, (classmethod, staticmethod)):
            value = value.__func__
        if inspect.isfunction(value):
            names.add(f"{class_name}.{method_name}")
    return names


def test_usage_registry_matches_tracked_function_names() -> None:
    registry = set(json.loads(REGISTRY_PATH.read_text(encoding="utf-8")))

    assert _tracked_function_names() <= registry


def test_usage_registry_matches_public_function_names() -> None:
    registry = set(json.loads(REGISTRY_PATH.read_text(encoding="utf-8")))

    assert _public_function_names() <= registry


def test_usage_registry_matches_database_seed() -> None:
    if not USAGE_MIGRATION_PATH.exists():
        pytest.skip("Freesolo app migration is not available in this checkout")

    registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    migration = USAGE_MIGRATION_PATH.read_text(encoding="utf-8")
    match = re.search(
        r"SELECT\s+public\.sync_package_function_usage_registry\(\s*'(\[.*?\])'::jsonb",
        migration,
        re.DOTALL,
    )

    assert match is not None
    assert json.loads(match.group(1)) == registry
