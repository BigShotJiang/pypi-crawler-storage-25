from __future__ import annotations

from freesolo.datasets import (
    Dataset,
    TaskExample,
    load_dataset,
)
from freesolo.datasets.core import _build_conversation
from freesolo.datasets.records import load_task_examples
from freesolo.training import SftConfig


class _PromptBuilder:
    def build_prompt_messages(
        self,
        example: TaskExample,
        prompt_text: str,
    ) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": prompt_text},
            {"role": "user", "content": example.task},
        ]


def test_load_task_examples_normalizes_records() -> None:
    examples = load_task_examples(
        [
            {
                "id": "task-1",
                "query": {"question": "continue?"},
                "metadata": {"split": "train"},
                "expected_output": {"answer": "yes"},
            }
        ]
    )

    assert examples == [
        TaskExample(
            record={
                "id": "task-1",
                "query": {"question": "continue?"},
                "metadata": {"split": "train"},
                "expected_output": {"answer": "yes"},
            },
            task='{\n  "question": "continue?"\n}',
            task_id="task-1",
            metadata={"split": "train"},
            expected_output={"answer": "yes"},
        )
    ]


def test_dataset_builds_conversations_from_examples() -> None:
    example = TaskExample(
        record={"task": "say yes", "expected_output": "yes"},
        task="say yes",
        expected_output="yes",
    )

    dataset = Dataset(examples=[example])

    assert dataset.build_conversations(_PromptBuilder(), "Follow the contract.") == [
        [
            {"role": "system", "content": "Follow the contract."},
            {"role": "user", "content": "say yes"},
            {"role": "assistant", "content": "yes"},
        ]
    ]


def test_load_dataset_preserves_source_order() -> None:
    dataset = load_dataset(
        [
            {"id": "1", "task": "first", "expected_output": "A"},
            {"id": "2", "task": "second", "expected_output": "B"},
        ],
    )

    assert [example.task for example in dataset.examples] == ["first", "second"]
    assert [example.expected_output for example in dataset.examples] == ["A", "B"]


def test_sft_config_lives_with_training_options() -> None:
    config = SftConfig(batch_size=8, learning_rate=1e-5)

    assert config.batch_size == 8
    assert config.learning_rate == 1e-5


def test_build_conversation_serializes_structured_outputs() -> None:
    example = TaskExample(
        record={"task": "return json", "expected_output": {"answer": "yes"}},
        task="return json",
        expected_output={"answer": "yes"},
    )

    assert _build_conversation(_PromptBuilder(), example, "Follow the contract.")[
        -1
    ] == {
        "role": "assistant",
        "content": '{\n  "answer": "yes"\n}',
    }


def test_build_conversation_requires_expected_output() -> None:
    example = TaskExample(record={"task": "say yes"}, task="say yes")

    try:
        _build_conversation(_PromptBuilder(), example, "Follow the contract.")
    except ValueError as exc:
        assert "ground_truth/expected_output/output/completion" in str(exc)
    else:
        raise AssertionError("build_conversation should reject unlabeled examples")
