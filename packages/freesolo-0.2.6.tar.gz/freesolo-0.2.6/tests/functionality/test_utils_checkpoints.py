from __future__ import annotations

from types import SimpleNamespace

from freesolo.utils.checkpoints import (
    checkpoint_batch_index,
    checkpoint_epoch,
    checkpoint_step,
    find_checkpoint_record,
    next_training_position,
    read_checkpoint_records,
    resolve_sft_state_path,
    resolve_training_position,
    write_training_progress,
)


class FakeCheckpointUtils:
    def __init__(self, checkpoint: object | None) -> None:
        self.checkpoint = checkpoint

    def get_last_checkpoint(self, log_path: str) -> object | None:
        return self.checkpoint


def test_checkpoint_helpers_read_dicts_and_objects() -> None:
    dict_record = {"loop_state": {"step": "3", "epoch": "1", "batch_index": "2"}}
    object_record = SimpleNamespace(
        loop_state={"step": "4", "epoch": "2", "batch_index": "3"}
    )

    assert checkpoint_step(dict_record) == 3
    assert checkpoint_epoch(dict_record) == 1
    assert checkpoint_batch_index(dict_record) == 2
    assert checkpoint_step(object_record) == 4
    assert checkpoint_epoch(object_record) == 2
    assert checkpoint_batch_index(object_record) == 3
    assert checkpoint_step({"loop_state": {"step": "bad"}}, default=9) == 9


def test_training_progress_wins_when_it_is_at_least_checkpoint_step(tmp_path) -> None:
    progress = write_training_progress(
        tmp_path,
        phase="grpo",
        step=10,
        epoch=2,
        batch_index=4,
        batches_per_epoch=5,
        checkpoint_name="ckpt",
        state_path="/state",
    )

    assert progress["step"] == 10
    assert resolve_training_position(
        {"loop_state": {"step": 9}},
        tmp_path,
        batches_per_epoch=5,
    ) == (10, 2, 4, progress)


def test_training_position_falls_back_to_newer_checkpoint(tmp_path) -> None:
    write_training_progress(
        tmp_path,
        phase="grpo",
        step=2,
        epoch=0,
        batch_index=2,
        batches_per_epoch=3,
    )

    assert resolve_training_position(
        {"loop_state": {"step": 7, "epoch": 1, "batch_index": 9}},
        tmp_path,
        batches_per_epoch=3,
    ) == (7, 4, 0, {})


def test_checkpoint_records_and_sft_state_resolution(tmp_path) -> None:
    (tmp_path / "checkpoints.jsonl").write_text(
        '\n{"name": "first", "state_path": "/state/first"}\n'
        '{"name": "final", "state_path": "/state/final"}\n',
        encoding="utf-8",
    )

    assert read_checkpoint_records(tmp_path) == [
        {"name": "first", "state_path": "/state/first"},
        {"name": "final", "state_path": "/state/final"},
    ]
    assert find_checkpoint_record(tmp_path, "final") == {
        "name": "final",
        "state_path": "/state/final",
    }
    assert (
        resolve_sft_state_path(
            explicit_state_path=None,
            sft_log_dir=tmp_path,
            checkpoint_name="final",
            checkpoint_utils=FakeCheckpointUtils(None),
        )
        == "/state/final"
    )


def test_next_training_position_rolls_epoch() -> None:
    assert next_training_position(epoch=0, batch_index=1, batches_per_epoch=3) == (0, 2)
    assert next_training_position(epoch=0, batch_index=2, batches_per_epoch=3) == (1, 0)
