from __future__ import annotations

from typing import is_typeddict

import pytest
from freesolo.datasets.records import (
    infer_expected_output,
    load_records,
    normalize_task,
)
from freesolo.environments import (
    Environment,
    RewardResult,
    load_environment,
)
from freesolo.environments.base import (
    _default_environment_reference,
    _validate_environment,
)
from freesolo.training import GrpoConfig, TrainGrpoOptions, TrainSftOptions
from freesolo.training.grpo.config import resolve_grpo_config
from freesolo.training.grpo.rewards import reward_diagnostics, reward_metrics
from freesolo.utils.core import split_name, validate_output


def test_load_records_normalizes_supported_text_json_jsonl_and_csv(tmp_path) -> None:
    jsonl_path = tmp_path / "data.jsonl"
    jsonl_path.write_text('"hello"\n{"input":"world"}\n', encoding="utf-8")
    json_path = tmp_path / "data.json"
    json_path.write_text('{"data":[{"prompt":"p"}]}', encoding="utf-8")
    csv_path = tmp_path / "data.csv"
    csv_path.write_text("input,answer\nquestion,answer\n", encoding="utf-8")
    txt_path = tmp_path / "data.txt"
    txt_path.write_text("\nfirst\n\nsecond\n", encoding="utf-8")

    assert load_records(jsonl_path) == [{"input": "hello"}, {"input": "world"}]
    assert load_records(json_path) == [{"prompt": "p"}]
    assert load_records(csv_path) == [{"input": "question", "answer": "answer"}]
    assert load_records(txt_path) == [
        {"id": "prompt_000001", "input": "first"},
        {"id": "prompt_000003", "input": "second"},
    ]


def test_normalize_task_and_expected_output_precedence() -> None:
    record = {
        "_id": "mongo-id",
        "query": {"structured": True},
        "metadata": {"split": "train"},
        "expected_output": "expected",
        "output": "fallback",
    }

    assert normalize_task(record) == {
        "id": "mongo-id",
        "task": '{\n  "structured": true\n}',
        "metadata": {"split": "train"},
    }
    assert infer_expected_output(record) == "expected"


def test_validate_output_handles_json_requirement_and_schema() -> None:
    valid = validate_output('{"answer": "yes"}', require_json=True)
    invalid = validate_output("not-json", require_json=True)

    assert valid.ok is True
    assert valid.parsed == {"answer": "yes"}
    assert invalid.ok is False
    assert invalid.checks["valid_json"] is False


def test_reward_metrics_and_diagnostics_cover_common_training_signals() -> None:
    metrics = reward_metrics([0.0, 1.0, 1.0])
    diagnostics = reward_diagnostics(
        [
            RewardResult(
                score=1.0,
                success=True,
                metadata={
                    "valid_json_filter": True,
                    "valid_mongodb_filter": True,
                    "result_count": 2,
                    "judge_filter_fidelity": 0.8,
                },
            ),
            RewardResult(
                score=0.0,
                success=False,
                metadata={
                    "valid_json_filter": False,
                    "valid_mongodb_filter": False,
                    "result_count": 0,
                    "error": "invalid json",
                },
            ),
        ]
    )

    assert metrics["grpo/reward_count"] == 3.0
    assert metrics["grpo/reward_mean"] == pytest.approx(2 / 3)
    assert metrics["grpo/reward_nonzero_rate"] == pytest.approx(2 / 3)
    assert diagnostics["grpo/reward_success_rate"] == 0.5
    assert diagnostics["grpo/reward_valid_json_rate"] == 0.5
    assert diagnostics["grpo/reward_zero_result_rate"] == 0.5
    assert diagnostics["grpo/judge_filter_fidelity_mean"] == 0.8


def test_resolve_grpo_config_defaults_and_overrides() -> None:
    defaults = resolve_grpo_config(GrpoConfig())
    overridden = resolve_grpo_config(
        GrpoConfig(
            batch_size=8,
            group_size=2,
            learning_rate=1e-5,
            max_tokens=256,
            num_epochs=3,
            save_every=4,
            temperature=0.2,
            advantage_clip=1.5,
            stop_sequences=("END",),
        )
    )

    assert defaults.batch_size == 4
    assert defaults.group_size == 4
    assert defaults.stop_sequences == ()
    assert overridden.batch_size == 8
    assert overridden.group_size == 2
    assert overridden.learning_rate == 1e-5
    assert overridden.stop_sequences == ("END",)


def test_training_option_types_are_exported() -> None:
    assert is_typeddict(TrainSftOptions)
    assert is_typeddict(TrainGrpoOptions)
    assert TrainSftOptions.__required_keys__ == frozenset({"dataset_path"})
    assert TrainGrpoOptions.__required_keys__ == frozenset({"dataset_path"})


def test_default_environment_reference_prefers_repo_environment(tmp_path) -> None:
    repo_env = tmp_path / "freesolo" / "environment.py"
    repo_env.parent.mkdir()
    repo_env.write_text("# canonical\n", encoding="utf-8")

    assert (
        _default_environment_reference(cwd=tmp_path)
        == "freesolo/environment.py:load_environment"
    )


def test_default_environment_reference_rejects_root_environment_file(tmp_path) -> None:
    (tmp_path / "environment.py").write_text("# not canonical\n", encoding="utf-8")

    with pytest.raises(ValueError, match=r"freesolo/environment\.py"):
        _default_environment_reference(cwd=tmp_path)


def test_load_environment_uses_canonical_repo_environment(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path,
) -> None:
    repo_env = tmp_path / "freesolo" / "environment.py"
    repo_env.parent.mkdir()
    repo_config = tmp_path / "freesolo" / "config.py"
    repo_config.write_text(
        "\n".join(
            [
                "from freesolo.training import GrpoConfig",
                "",
                "GRPO_CONFIG = GrpoConfig(group_size=2, max_tokens=64)",
                "",
            ]
        ),
        encoding="utf-8",
    )
    repo_env.write_text(
        "\n".join(
            [
                "from freesolo.environments import Environment, RewardResult",
                "from config import GRPO_CONFIG",
                "from freesolo.training import GrpoConfig",
                "",
                "class RepoEnvironment(Environment):",
                "    def __init__(self, *, mode='eval', dataset_path=None, **_):",
                "        self.mode = mode",
                "        self.dataset_path = dataset_path",
                "",
                "    def build_prompt_messages(self, example, prompt_text):",
                "        return [{'role': 'user', 'content': f'{prompt_text}\\n{example.task}'}]",
                "",
                "    def score_response(self, example, response_text):",
                "        return RewardResult(score=1.0 if response_text else 0.0)",
                "",
                "    def get_grpo_config(self) -> GrpoConfig:",
                "        return GRPO_CONFIG",
                "",
                "def load_environment(**kwargs):",
                "    return RepoEnvironment(**kwargs)",
                "",
            ]
        ),
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)

    environment = load_environment(mode="grpo", dataset_path="train.jsonl")

    assert environment.mode == "grpo"
    assert environment.dataset_path == "train.jsonl"
    assert environment.get_grpo_config().group_size == 2


def test_validate_environment_requires_grpo_config() -> None:
    class BadConfigEnvironment:
        def get_grpo_config(self):
            return {}

    with pytest.raises(TypeError, match="must return an instance"):
        _validate_environment(BadConfigEnvironment())

    class WrongGrpoConfigEnvironment(Environment):
        def build_prompt_messages(self, example, prompt_text):
            return []

        def score_response(self, example, response_text):
            return RewardResult(score=0.0)

        def get_grpo_config(self):
            return {}

    with pytest.raises(TypeError, match="get_grpo_config"):
        _validate_environment(WrongGrpoConfigEnvironment())


def test_split_name_is_deterministic() -> None:
    assert split_name("same-id") == split_name("same-id")
