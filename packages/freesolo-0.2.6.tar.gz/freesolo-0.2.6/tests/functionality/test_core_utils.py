from __future__ import annotations

from pathlib import Path

import pytest
from freesolo.utils.core import (
    coerce_bool,
    coerce_float,
    json_safe_value,
    loads_json_object,
    optional_int,
    optional_str,
    require_non_empty,
    slugify,
    truncate_text,
    truthy,
)


def test_json_safe_value_normalizes_common_non_json_values() -> None:
    assert json_safe_value(
        {
            "path": Path("logs/run"),
            "items": ("a", Path("b")),
            "set": {"x"},
            1: "numeric-key",
        }
    ) == {
        "path": "logs/run",
        "items": ["a", "b"],
        "set": ["x"],
        "1": "numeric-key",
    }


def test_string_and_scalar_helpers() -> None:
    assert require_non_empty(" value ", "name") == "value"
    with pytest.raises(ValueError, match="name is required"):
        require_non_empty(" ", "name")

    assert optional_int(3.9) == 3
    assert optional_int(True) is None
    assert optional_str(None) is None
    assert optional_str(123) == "123"
    assert coerce_bool(1) is True
    assert coerce_bool("true") is None
    assert coerce_float(2) == 2.0
    assert coerce_float(True) == 1.0
    assert truthy(" yes ") is True
    assert truthy("no") is False
    assert slugify("SFT / GRPO!") == "sft-grpo"
    assert slugify("!!!", fallback="fallback") == "fallback"
    assert truncate_text("abcdef", 5) == "ab..."


def test_loads_json_object_accepts_plain_and_fenced_json() -> None:
    assert loads_json_object('{"ok": true}') == {"ok": True}
    assert loads_json_object('```json\n{"ok": true}\n```') == {"ok": True}
    assert loads_json_object('```text\n{"ok": true}\n```') == {"ok": True}
    assert loads_json_object("[1, 2]") is None
