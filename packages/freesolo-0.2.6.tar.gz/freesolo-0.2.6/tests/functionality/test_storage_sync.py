from __future__ import annotations

from io import BytesIO
from pathlib import Path
from typing import Any, ClassVar
from zipfile import ZipFile

import httpx
import pytest
from freesolo.training.storage import start_stored_training_run
from freesolo.utils.core import _auth_headers
from freesolo.utils.storage import FreesoloStorageClient


class _FakeHttpClient:
    calls: ClassVar[list[dict[str, Any]]] = []
    response_json_by_suffix: ClassVar[dict[str, dict[str, Any]]] = {}
    status_by_suffix: ClassVar[dict[str, int]] = {}
    text_by_suffix: ClassVar[dict[str, str]] = {}

    def __init__(self, *, timeout: float) -> None:
        self.timeout = timeout

    def __enter__(self) -> _FakeHttpClient:
        return self

    def __exit__(self, *args: object) -> None:
        return None

    def post(self, url: str, **kwargs: Any) -> httpx.Response:
        return self._request("POST", url, **kwargs)

    def patch(self, url: str, **kwargs: Any) -> httpx.Response:
        return self._request("PATCH", url, **kwargs)

    def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        call = {"url": url, **kwargs}
        if files := kwargs.get("files"):
            filename, file_obj, mime_type = files["file"]
            call["uploaded_file"] = {
                "filename": filename,
                "content": file_obj.read(),
                "mime_type": mime_type,
            }
            call.pop("files")
        self.calls.append(call)
        request = httpx.Request(method, url)
        for suffix, status_code in self.status_by_suffix.items():
            if url.endswith(suffix):
                return httpx.Response(
                    status_code,
                    text=self.text_by_suffix.get(suffix, ""),
                    request=request,
                )
        for suffix, payload in self.response_json_by_suffix.items():
            if url.endswith(suffix):
                return httpx.Response(200, json=payload, request=request)
        if url.endswith("/api/datasets"):
            return httpx.Response(
                200, json={"ok": True, "dataset_id": "ds-1"}, request=request
            )
        if url.endswith("/api/runs"):
            return httpx.Response(
                200, json={"ok": True, "run_id": "run-1"}, request=request
            )
        if url.endswith("/api/runs/run-1"):
            return httpx.Response(
                200, json={"ok": True, "run_id": "run-1"}, request=request
            )
        if url.endswith("/api/runs/run-1/wandb"):
            return httpx.Response(
                200,
                json={
                    "ok": True,
                    "run_id": "run-1",
                    "wandb_url": "https://wandb.ai/o/p/runs/r",
                },
                request=request,
            )
        if url.endswith("/api/codex-logs"):
            return httpx.Response(
                200, json={"ok": True, "codex_log_id": "log-1"}, request=request
            )
        return httpx.Response(404, text="not found", request=request)


@pytest.fixture(autouse=True)
def _reset_fake_client() -> None:
    _FakeHttpClient.calls = []
    _FakeHttpClient.response_json_by_suffix = {}
    _FakeHttpClient.status_by_suffix = {}
    _FakeHttpClient.text_by_suffix = {}


def test_storage_client_requires_api_key(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("FREESOLO_API_KEY", raising=False)

    with pytest.raises(ValueError, match="FREESOLO_API_KEY"):
        FreesoloStorageClient()


def test_storage_client_uses_env_key_and_normalizes_base_url(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("FREESOLO_API_KEY", "fs-env")
    monkeypatch.setenv("FREESOLO_BASE_URL", "https://api.test///")

    client = FreesoloStorageClient()

    assert client.api_key == "fs-env"
    assert client.base_url == "https://api.test"


def test_storage_client_sets_function_usage_headers(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)

    FreesoloStorageClient(
        api_key="fs-test",
        base_url="https://api.test",
    ).create_run(name="train")

    assert _FakeHttpClient.calls[0]["headers"] == _auth_headers(
        "fs-test",
        function_name="FreesoloStorageClient.create_run",
    )


def test_verify_api_key_accepts_authenticated_validation_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    _FakeHttpClient.status_by_suffix = {"/api/datasets": 415}

    FreesoloStorageClient(
        api_key="fs-test", base_url="https://api.test"
    ).verify_api_key()

    assert _FakeHttpClient.calls == [
        {
            "url": "https://api.test/api/datasets",
            "headers": _auth_headers(
                "fs-test",
                function_name="FreesoloStorageClient.verify_api_key",
            ),
            "json": {"name": "__freesolo_auth_check__"},
        }
    ]


def test_verify_api_key_rejects_unauthorized_response(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    _FakeHttpClient.status_by_suffix = {"/api/datasets": 401}
    _FakeHttpClient.text_by_suffix = {"/api/datasets": '{"detail":"Unauthorized"}'}

    with pytest.raises(httpx.HTTPStatusError, match="Unauthorized"):
        FreesoloStorageClient(
            api_key="fs-test",
            base_url="https://api.test",
        ).verify_api_key()


def test_upload_dataset_posts_file_to_combined_datasets_route(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    dataset_path = tmp_path / "data.jsonl"
    dataset_path.write_text('{"x": 1}\n', encoding="utf-8")

    dataset_id = FreesoloStorageClient(
        api_key="fs-test",
        base_url="https://api.test",
    ).upload_dataset(dataset_path, name="demo")

    assert dataset_id == "ds-1"
    assert _FakeHttpClient.calls == [
        {
            "url": "https://api.test/api/datasets",
            "headers": {
                "Authorization": "Bearer fs-test",
                "X-Freesolo-Function": "FreesoloStorageClient.upload_dataset",
            },
            "data": {"name": "demo"},
            "uploaded_file": {
                "filename": "data.jsonl",
                "content": b'{"x": 1}\n',
                "mime_type": "application/octet-stream",
            },
        }
    ]


def test_upload_dataset_zips_directory_before_upload(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    dataset_dir = tmp_path / "dataset"
    (dataset_dir / "nested").mkdir(parents=True)
    (dataset_dir / "nested" / "a.jsonl").write_text("a\n", encoding="utf-8")
    (dataset_dir / "b.jsonl").write_text("b\n", encoding="utf-8")

    dataset_id = FreesoloStorageClient(
        api_key="fs-test",
        base_url="https://api.test",
    ).upload_dataset(dataset_dir)

    assert dataset_id == "ds-1"
    uploaded = _FakeHttpClient.calls[0]["uploaded_file"]
    assert uploaded["filename"] == "dataset.zip"
    with ZipFile(BytesIO(uploaded["content"])) as archive:
        assert sorted(archive.namelist()) == ["b.jsonl", "nested/a.jsonl"]
        assert archive.read("nested/a.jsonl") == b"a\n"
        assert archive.read("b.jsonl") == b"b\n"


def test_upload_dataset_directory_rejects_symlinks(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    dataset_dir = tmp_path / "dataset"
    dataset_dir.mkdir()
    outside_file = tmp_path / "outside.jsonl"
    outside_file.write_text('{"secret": true}\n', encoding="utf-8")
    link_path = dataset_dir / "outside.jsonl"
    try:
        link_path.symlink_to(outside_file)
    except OSError as exc:
        pytest.skip(f"symlinks are not available in this environment: {exc}")

    with pytest.raises(ValueError, match="symlink"):
        FreesoloStorageClient(
            api_key="fs-test",
            base_url="https://api.test",
        ).upload_dataset(dataset_dir)

    assert _FakeHttpClient.calls == []


def test_run_create_update_and_wandb_use_freesolo_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    client = FreesoloStorageClient(api_key="fs-test", base_url="https://api.test")

    run_id = client.create_run(name="train", dataset_ids=["ds-1"])
    client.update_run(run_id, status="running", config={"phase": "sft"})
    client.link_wandb(run_id, "https://wandb.ai/o/p/runs/r")

    assert run_id == "run-1"
    assert _FakeHttpClient.calls[0] == {
        "url": "https://api.test/api/runs",
        "headers": _auth_headers(
            "fs-test",
            function_name="FreesoloStorageClient.create_run",
        ),
        "json": {"name": "train", "dataset_ids": ["ds-1"]},
    }
    assert _FakeHttpClient.calls[1] == {
        "url": "https://api.test/api/runs/run-1",
        "headers": _auth_headers(
            "fs-test",
            function_name="FreesoloStorageClient.update_run",
        ),
        "json": {"status": "running", "config": {"phase": "sft"}},
    }
    assert _FakeHttpClient.calls[2] == {
        "url": "https://api.test/api/runs/run-1/wandb",
        "headers": _auth_headers(
            "fs-test",
            function_name="FreesoloStorageClient.link_wandb",
        ),
        "json": {"wandb_url": "https://wandb.ai/o/p/runs/r"},
    }


def test_update_run_without_fields_does_not_call_api(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)

    FreesoloStorageClient(api_key="fs-test", base_url="https://api.test").update_run(
        "run-1"
    )

    assert _FakeHttpClient.calls == []


def test_append_codex_log_posts_content(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    client = FreesoloStorageClient(api_key="fs-test", base_url="https://api.test")

    log_id = client.append_codex_log("Draft agent started")

    assert log_id == "log-1"
    assert _FakeHttpClient.calls == [
        {
            "url": "https://api.test/api/codex-logs",
            "headers": _auth_headers(
                "fs-test",
                function_name="FreesoloStorageClient.append_codex_log",
            ),
            "json": {"content": "Draft agent started"},
        }
    ]


def test_storage_client_surfaces_http_error_body(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    _FakeHttpClient.status_by_suffix = {"/api/runs": 500}
    _FakeHttpClient.text_by_suffix = {"/api/runs": "db unavailable"}

    with pytest.raises(httpx.HTTPStatusError, match="db unavailable"):
        FreesoloStorageClient(
            api_key="fs-test",
            base_url="https://api.test",
        ).create_run(name="train")


def test_storage_client_truncates_long_http_error_body(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    _FakeHttpClient.status_by_suffix = {"/api/runs": 500}
    _FakeHttpClient.text_by_suffix = {"/api/runs": "x" * 2_500}

    with pytest.raises(httpx.HTTPStatusError) as exc_info:
        FreesoloStorageClient(
            api_key="fs-test",
            base_url="https://api.test",
        ).create_run(name="train")

    message = str(exc_info.value)
    assert message.count("x") == 2_000
    assert "... [truncated]" in message


def test_storage_client_rejects_missing_response_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr("freesolo.utils.storage.httpx.Client", _FakeHttpClient)
    _FakeHttpClient.response_json_by_suffix = {"/api/runs": {"ok": True}}

    with pytest.raises(ValueError, match="missing run_id"):
        FreesoloStorageClient(
            api_key="fs-test",
            base_url="https://api.test",
        ).create_run(name="train")


def test_training_storage_uploads_dataset_creates_run_and_marks_running(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    class FakeStorageClient:
        def __init__(self) -> None:
            self.calls: list[tuple[str, dict[str, Any]]] = []
            created_clients.append(self)

        def upload_dataset(self, path: str | Path, *, name: str | None = None) -> str:
            self.calls.append(("upload_dataset", {"path": str(path), "name": name}))
            return "ds-1"

        def create_run(self, **kwargs: Any) -> str:
            self.calls.append(("create_run", kwargs))
            return "run-1"

        def update_run(self, run_id: str, **kwargs: Any) -> None:
            self.calls.append(("update_run", {"run_id": run_id, **kwargs}))

    created_clients: list[FakeStorageClient] = []
    monkeypatch.setattr(
        "freesolo.training.storage.FreesoloStorageClient", FakeStorageClient
    )

    stored = start_stored_training_run(
        phase="grpo",
        dataset_path="/tmp/data.jsonl",
        name="full train",
        description="long training",
        config={"learning_rate": 1e-5},
    )

    assert stored.run_id == "run-1"
    assert stored.dataset_id == "ds-1"
    assert created_clients[0].calls == [
        (
            "upload_dataset",
            {"path": "/tmp/data.jsonl", "name": "data.jsonl"},
        ),
        (
            "create_run",
            {
                "name": "full train",
                "description": "long training",
                "dataset_ids": ["ds-1"],
            },
        ),
        (
            "update_run",
            {
                "run_id": "run-1",
                "status": "running",
                "config": {
                    "learning_rate": 1e-5,
                    "phase": "grpo",
                    "freesolo_run_id": "run-1",
                    "dataset_id": "ds-1",
                },
            },
        ),
    ]


def test_stored_training_run_complete_and_fail_update_status() -> None:
    class FakeClient:
        def __init__(self) -> None:
            self.calls: list[tuple[str, dict[str, Any]]] = []

        def update_run(self, run_id: str, **kwargs: Any) -> None:
            self.calls.append((run_id, kwargs))

        def link_wandb(self, run_id: str, wandb_url: str | None) -> None:
            self.calls.append((run_id, {"wandb_url": wandb_url}))

    from freesolo.training.storage import StoredTrainingRun

    client = FakeClient()
    stored = StoredTrainingRun(client=client, run_id="run-1", dataset_id="ds-1")

    stored.link_wandb("https://wandb.ai/o/p/runs/r")
    stored.complete()
    stored.fail(RuntimeError("boom"))

    assert client.calls == [
        ("run-1", {"wandb_url": "https://wandb.ai/o/p/runs/r"}),
        ("run-1", {"status": "completed"}),
        ("run-1", {"status": "failed", "error": "boom"}),
    ]
