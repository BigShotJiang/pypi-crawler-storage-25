from __future__ import annotations

import threading
import time

import pytest
from freesolo.datasets import TaskExample
from freesolo.environments import Environment, RewardMetric, RewardResult
from freesolo.environments.evaluation import (
    EnvironmentGeneration,
    _run_local_environment_evaluation,
)


class ExactMatchEnvironment(Environment):
    def build_prompt_messages(
        self,
        example: TaskExample,
        prompt_text: str,
    ) -> list[dict[str, str]]:
        return [
            {"role": "system", "content": prompt_text},
            {"role": "user", "content": example.task},
        ]

    def score_response(
        self,
        example: TaskExample,
        response_text: str,
    ) -> RewardResult:
        matched = response_text == example.expected_output
        return RewardResult(
            score=1.0 if matched else 0.0,
            threshold=1.0,
            reason="exact match" if matched else "mismatch",
            metrics=(
                RewardMetric(
                    name="exact_match",
                    score=1.0 if matched else 0.0,
                    success=matched,
                ),
            ),
            metadata={"expected": str(example.expected_output)},
        )


def test_local_environment_evaluation_runs_generation_and_scoring_end_to_end() -> None:
    calls: list[list[dict[str, str]]] = []

    async def generate(messages, example, **_kwargs):
        calls.append(messages)
        return EnvironmentGeneration(
            response_text=str(example.expected_output),
            latency_ms=12,
            total_tokens=9,
            metadata={"source": "fake-model"},
        )

    results = _run_local_environment_evaluation(
        source=[
            {"id": "1", "task": "say yes", "expected_output": "yes"},
            {"id": "2", "task": "say no", "expected_output": "no"},
        ],
        contract_text="Answer exactly.",
        environment=ExactMatchEnvironment(),
        generate=generate,
    )

    assert len(calls) == 2
    assert calls[0] == [
        {"role": "system", "content": "Answer exactly."},
        {"role": "user", "content": "say yes"},
    ]
    assert [result.success for result in results] == [True, True]
    assert [result.scorers_data[0].score for result in results] == [1.0, 1.0]
    assert results[0].scorers_data[0].latency_ms == 12
    assert results[0].scorers_data[0].total_tokens == 9
    assert results[0].scorers_data[0].metrics[0].name == "exact_match"
    assert results[0].data_object == {
        "input": "say yes",
        "actual_output": "yes",
        "expected_output": "yes",
        "task_id": "1",
        "generation_metadata": {"source": "fake-model"},
    }
    assert all(result.run_duration is not None for result in results)


def test_local_environment_evaluation_uses_bounded_concurrency_and_preserves_order() -> (
    None
):
    active = 0
    max_active = 0
    lock = threading.Lock()

    def generate(messages, example, **_kwargs):
        del messages
        nonlocal active, max_active
        with lock:
            active += 1
            max_active = max(max_active, active)
        time.sleep(0.02)
        with lock:
            active -= 1
        return str(example.expected_output)

    results = _run_local_environment_evaluation(
        source=[
            {"id": "1", "task": "first", "expected_output": "one"},
            {"id": "2", "task": "second", "expected_output": "two"},
            {"id": "3", "task": "third", "expected_output": "three"},
        ],
        contract_text="Answer exactly.",
        environment=ExactMatchEnvironment(),
        generate=generate,
        concurrency=2,
    )

    assert max_active == 2
    assert [result.data_object["input"] for result in results] == [
        "first",
        "second",
        "third",
    ]
    assert [result.success for result in results] == [True, True, True]


@pytest.mark.parametrize("concurrency", [0, -1, True])
def test_local_environment_evaluation_rejects_invalid_concurrency(concurrency) -> None:
    def generate(_messages, example, **_kwargs):
        return str(example.expected_output)

    with pytest.raises(ValueError, match="concurrency must be a positive integer"):
        _run_local_environment_evaluation(
            source=[{"id": "1", "task": "first", "expected_output": "one"}],
            contract_text="Answer exactly.",
            environment=ExactMatchEnvironment(),
            generate=generate,
            concurrency=concurrency,
        )
