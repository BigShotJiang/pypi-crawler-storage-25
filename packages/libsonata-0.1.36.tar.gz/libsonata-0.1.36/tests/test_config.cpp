#include <catch2/catch_all.hpp>

#include <nlohmann/json.hpp>

#include "../extlib/filesystem.hpp"
#include "catch2/matchers/catch_matchers_string.hpp"

#include <bbp/sonata/config.h>

#include <cstdio>
#include <string>
#include <vector>

using namespace bbp::sonata;

bool endswith(const std::string& haystack, const std::string& needle) {
    return std::equal(needle.rbegin(), needle.rend(), haystack.rbegin());
}

bool contains(const std::string& haystack, const std::string& needle) {
    return haystack.find(needle) != std::string::npos;
}

TEST_CASE("CircuitConfig") {
    SECTION("Simple") {
        const auto config = CircuitConfig::fromFile("./data/config/circuit_config.json");
        CHECK(config.getNodeSetsPath()[0] == '/');  // is an absolute path
        CHECK(endswith(config.getNodeSetsPath(), "node_sets.json"));

        CHECK(config.listNodePopulations() == std::set<std::string>{"nodes-A", "nodes-B"});
        CHECK(config.listEdgePopulations() == std::set<std::string>{"edges-AB", "edges-AC"});

        CHECK_THROWS_AS(config.getNodePopulation("DoesNotExist"), SonataError);
        CHECK_THROWS_AS(config.getEdgePopulation("DoesNotExist"), SonataError);

        CHECK(config.getNodePopulation("nodes-A").name() == "nodes-A");
        CHECK(config.getEdgePopulation("edges-AB").name() == "edges-AB");

        CHECK_THROWS_AS(config.getNodePopulationProperties("DoesNotExist"), SonataError);
        CHECK_THROWS_AS(config.getEdgePopulationProperties("DoesNotExist"), SonataError);

        CHECK(config.getNodePopulationProperties("nodes-A").type == "biophysical");
        CHECK(endswith(config.getNodePopulationProperties("nodes-A").typesPath, ""));
        CHECK(endswith(config.getNodePopulationProperties("nodes-A").elementsPath, "tests/data/nodes1.h5"));

        CHECK(config.getEdgePopulationProperties("edges-AB").type == "chemical");
        CHECK(endswith(config.getEdgePopulationProperties("edges-AB").typesPath, ""));
        CHECK(endswith(config.getEdgePopulationProperties("edges-AB").elementsPath, "tests/data/edges1.h5"));

        CHECK_NOTHROW(nlohmann::json::parse(config.getExpandedJSON()));
        CHECK(nlohmann::json::parse(config.getExpandedJSON())
                  .at("components")
                  .at("morphologies_dir")
                  .get<std::string>() == "morphologies");
    }

    SECTION("Exception") {
        CHECK_THROWS(CircuitConfig::fromFile("/file/does/not/exist"));

        {  // Missing 'networks'
            auto contents = R"({ "manifest": {} })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }
        {  // Missing 'nodes' subnetwork
            auto contents = R"({ "manifest": {}, "networks":{ "edges":[] } })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }
        {  // Missing 'edges' subnetwork
            auto contents = R"({ "manifest": {}, "networks":{ "nodes":[] } })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }

        {  // Self recursion
            auto contents = R"({
              "manifest": { "$DIR": "$DIR" },
              "networks": {}
            })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }

        {  // mutual recursion
            auto contents = R"({
              "manifest": {
                "$FOO": "$BAR",
                "$BAR": "$FOO"
              },
              "networks": {}
            })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }

        {  // Invalid variable name
            auto contents = R"({
              "manifest": {
                "$FOO[]": "InvalidVariableName"
              },
              "networks": {}
            })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }

        {  // Duplicate population names
            auto contents = R"({
              "manifest": {
                "$NETWORK_DIR": "./data"
              },
              "networks": {
                "nodes": [
                  {
                    "nodes_file": "$NETWORK_DIR/nodes1.h5"
                  },
                  {
                    "nodes_file": "$NETWORK_DIR/nodes1.h5"
                  }
                ]
              }
            })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }

        {  // Biophysical population without morphology dir
            auto contents = R"({
              "manifest": {
                "$NETWORK_DIR": "./data"
              },
              "components": {
                "morphologies_dir": ""
              },
              "networks": {
                "nodes": [
                  {
                    "nodes_file": "$NETWORK_DIR/nodes1.h5",
                    "populations": {
                      "nodes-A": {
                        "type": "biophysical",
                        "biophysical_neuron_models_dir": "a/fake/dir"
                      },
                      "nodes-B": {
                        "type": "virtualnode"
                      }
                    }
                  }
                ],
                "edges":[]
              }
            })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }

        {  // Biophysical population without `biophysical_neuron_models_dir`
            auto contents = R"({
              "manifest": {
                "$NETWORK_DIR": "./data"
              },
              "components": {
                "morphologies_dir": "a/fake/dir"
              },
              "networks": {
                "nodes": [
                  {
                    "nodes_file": "$NETWORK_DIR/nodes1.h5",
                    "populations": {
                      "nodes-A": {
                        "type": "biophysical"
                      },
                      "nodes-B": {
                        "type": "virtualnode"
                      }
                    }
                  }
                ],
                "edges":[]
              }
            })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }

        {  // No node file defined for node subnetwork
            auto contents = R"({
              "manifest": {
                "$NETWORK_DIR": "./data"
              },
              "networks": {
                "nodes": [
                  {
                    "nodes_file": ""
                  }
                ]
              }
            })";
            CHECK_THROWS_AS(CircuitConfig(contents, "./"), SonataError);
        }
    }

    SECTION("Overrides") {
        {  // Population without overriden properties return default component values
            auto contents = R"({
              "manifest": {
                "$NETWORK_DIR": "./data",
                "$COMPONENT_DIR": "./"
              },
              "components": {
                "morphologies_dir": "$COMPONENT_DIR/morphologies",
                "biophysical_neuron_models_dir": "$COMPONENT_DIR/biophysical_neuron_models",
                "alternate_morphologies": {
                  "h5v1": "$COMPONENT_DIR/morphologies/h5"
                }
              },
              "networks": {
                "nodes": [
                  {
                    "nodes_file": "$NETWORK_DIR/nodes1.h5",
                    "populations": {
                      "nodes-A": {}
                    }
                  }
                ],
                "edges":[]
              }
            })";
            CHECK(contains(CircuitConfig(contents, "./")
                           .getNodePopulationProperties("nodes-A")
                           .alternateMorphologyFormats["h5v1"],
                           "morphologies/h5"));
        }

        {  // Node population with overriden properties return correct information
            auto contents = R"({
              "manifest": {
                "$NETWORK_DIR": "./data",
                "$COMPONENT_DIR": "./"
              },
              "components": {
                "morphologies_dir": "$COMPONENT_DIR/morphologies",
                "biophysical_neuron_models_dir": "$COMPONENT_DIR/biophysical_neuron_models",
                "alternate_morphologies": {
                  "h5v1": "$COMPONENT_DIR/morphologies/h5"
                }
              },
              "networks": {
                "nodes": [
                  {
                    "nodes_file": "$NETWORK_DIR/nodes1.h5",
                    "populations": {
                      "nodes-A": {
                        "morphologies_dir": "my/custom/morphologies/dir",
                        "alternate_morphologies": {
                          "h5v1" : "another/custom/morphologies/dir"
                        }
                      },
                      "nodes-B": {
                        "alternate_morphologies": {
                          "h5v1" : "another/custom/morphologies/dir"
                        }
                      }
                    }
                  }
                ],
                "edges":[]
              }
            })";
            CHECK(contains(CircuitConfig(contents, "./")
                           .getNodePopulationProperties("nodes-A")
                           .morphologiesDir,
                           "/my/custom/morphologies/dir"));
        }

        {  // Edge population with overriden properties return correct information
            auto contents = R"({
              "manifest": {
                "$NETWORK_DIR": "./data",
                "$COMPONENT_DIR": "./"
              },
              "components": {
                "morphologies_dir": "$COMPONENT_DIR/morphologies",
                "biophysical_neuron_models_dir": "$COMPONENT_DIR/biophysical_neuron_models",
                "alternate_morphologies": {
                  "h5v1": "$COMPONENT_DIR/morphologies/h5"
                }
              },
              "networks": {
                "edges": [
                  {
                    "edges_file": "$NETWORK_DIR/edges1.h5",
                    "populations": {
                      "edges-AB": {
                        "morphologies_dir": "my/custom/morphologies/dir"
                      }
                    }
                  }
                ],
                "nodes":[]
              }
            })";
            CHECK(contains(CircuitConfig(contents, "./")
                           .getEdgePopulationProperties("edges-AB")
                           .morphologiesDir,
                           "my/custom/morphologies/dir"));
        }
    }
}

TEST_CASE("SimulationConfig") {
    SECTION("Simple") {
        const auto config = SimulationConfig::fromFile("./data/config/simulation_config.json");
        CHECK_NOTHROW(config.getRun());
        using Catch::Matchers::WithinULP;
        CHECK(config.getRun().tstop == 1000);
        CHECK(config.getRun().dt == 0.025);
        CHECK(config.getRun().randomSeed == 201506);
        CHECK(config.getRun().spikeThreshold == -35.5);
        CHECK(config.getRun().integrationMethod ==
              SimulationConfig::Run::IntegrationMethod::crank_nicolson_ion);
        CHECK(config.getRun().stimulusSeed == 111);
        CHECK(config.getRun().ionchannelSeed == 222);
        CHECK(config.getRun().minisSeed == 333);
        CHECK(config.getRun().synapseSeed == 444);

        namespace fs = ghc::filesystem;
        const auto basePath = fs::absolute(
            fs::path("./data/config/simulation_config.json").parent_path());

        const auto electrodesPath = fs::absolute(basePath / "electrodes/electrode_weights.h5");
        CHECK(config.getRun().electrodesFile == (electrodesPath).lexically_normal());

        CHECK_NOTHROW(config.getOutput());
        const auto outputPath = fs::absolute(basePath / "some/path/output");
        CHECK(config.getOutput().outputDir == (outputPath).lexically_normal());
        CHECK(config.getOutput().spikesFile == "out.h5");
        CHECK(config.getOutput().logFile.empty());
        CHECK(config.getOutput().sortOrder == SimulationConfig::Output::SpikesSortOrder::by_id);

        CHECK_NOTHROW(config.getConditions());
        CHECK(config.getConditions().celsius == 35.);
        CHECK(config.getConditions().vInit == -80);
        CHECK(config.getConditions().spikeLocation ==
              SimulationConfig::Conditions::SpikeLocation::AIS);
        CHECK(config.getConditions().extracellularCalcium == nonstd::nullopt);
        CHECK(config.getConditions().randomizeGabaRiseTime == false);
        CHECK(config.getConditions().mechanisms.size() == 2);
        auto itr = config.getConditions().mechanisms.find("ProbAMPANMDA_EMS");
        CHECK(itr != config.getConditions().mechanisms.end());
        CHECK(nonstd::get<bool>(itr->second.find("property1")->second) == false);
        CHECK(nonstd::get<int>(itr->second.find("property2")->second) == -1);
        itr = config.getConditions().mechanisms.find("GluSynapse");
        CHECK(nonstd::get<double>(itr->second.find("property3")->second) == 0.025);
        CHECK(nonstd::get<std::string>(itr->second.find("property4")->second) == "test");
        const auto modifications = config.getConditions().getModifications();
        CHECK(modifications.size() == 5);
        const auto TTX = nonstd::get<SimulationConfig::ModificationTTX>(modifications[0]);
        CHECK(TTX.name == "applyTTX");
        CHECK(TTX.type == SimulationConfig::ModificationBase::ModificationType::TTX);
        CHECK(TTX.nodeSet == "single");
        const auto configAllSects = nonstd::get<SimulationConfig::ModificationConfigureAllSections>(modifications[1]);
        CHECK(configAllSects.name == "no_SK_E2");
        CHECK(configAllSects.type ==
              SimulationConfig::ModificationBase::ModificationType::ConfigureAllSections);
        CHECK(configAllSects.nodeSet == "single");
        CHECK(configAllSects.sectionConfigure == "%s.gSK_E2bar_SK_E2 = 0");
        const auto configSectList = nonstd::get<SimulationConfig::ModificationSectionList>(modifications[2]);
        CHECK(configSectList.name == "apical_block_NaTg");
        CHECK(configSectList.type ==
              SimulationConfig::ModificationBase::ModificationType::SectionList);
        CHECK(configSectList.nodeSet == "single");
        CHECK(configSectList.sectionConfigure == "apical.gbar_NaTg = 0");
        const auto configSection = nonstd::get<SimulationConfig::ModificationSection>(modifications[3]);
        CHECK(configSection.name == "apical[10]_KTst_NaTg_block");
        CHECK(configSection.type ==
              SimulationConfig::ModificationBase::ModificationType::Section);
        CHECK(configSection.nodeSet == "single");
        CHECK(configSection.sectionConfigure == "apic[10].gbar_KTst = 0; apic[10].gbar_NaTg = 0");
        const auto configCompSet = nonstd::get<SimulationConfig::ModificationCompartmentSet>(modifications[4]);
        CHECK(configCompSet.name == "Ca_hotspot_dend[10]_manipulation");
        CHECK(configCompSet.type ==
              SimulationConfig::ModificationBase::ModificationType::CompartmentSet);
        CHECK(configCompSet.compartmentSet == "dend_ca_hotspot_name");
        CHECK(configCompSet.sectionConfigure == "gbar_Ca_HVA2 = 1.5; gbar_Ca_LVA = 2");

        CHECK_THROWS_AS(config.getReport("DoesNotExist"), SonataError);
        CHECK(config.listReportNames() == std::set<std::string>{
              "axonal_comp_centers",
              "cell_imembrane",
              "compartment",
              "soma",
              "lfp",
              "compartment_set_v"
              });

        CHECK(config.getReport("soma").cells == "Column");
        CHECK(config.getReport("soma").type == SimulationConfig::Report::Type::compartment);
        CHECK(config.getReport("soma").compartments == SimulationConfig::Report::Compartments::center);
        CHECK(config.getReport("soma").enabled == true);
        const auto somaFilePath = fs::absolute(config.getOutput().outputDir / fs::path("soma.h5"));
        CHECK(config.getReport("soma").fileName == somaFilePath.lexically_normal());
        CHECK(config.getReport("compartment").dt == 0.1);
        CHECK(config.getReport("compartment").sections == SimulationConfig::Report::Sections::all);
        CHECK(config.getReport("compartment").compartments == SimulationConfig::Report::Compartments::all);
        CHECK(config.getReport("compartment").enabled == false);
        CHECK(config.getReport("axonal_comp_centers").startTime == 0.);
        CHECK(config.getReport("axonal_comp_centers").compartments == SimulationConfig::Report::Compartments::center);
        CHECK(config.getReport("axonal_comp_centers").scaling == SimulationConfig::Report::Scaling::none);
        const auto axonalFilePath = fs::absolute(config.getOutput().outputDir / fs::path("axon_centers.h5"));
        CHECK(config.getReport("axonal_comp_centers").fileName ==
              axonalFilePath.lexically_normal());
        CHECK(config.getReport("cell_imembrane").endTime == 500.);
        CHECK(config.getReport("cell_imembrane").variableName == "i_membrane, IClamp");
        CHECK(config.getReport("lfp").type == SimulationConfig::Report::Type::lfp);
        CHECK(config.getReport("compartment_set_v").type == SimulationConfig::Report::Type::compartment_set);
        CHECK(config.getReport("compartment_set_v").sections == SimulationConfig::Report::Sections::invalid);
        CHECK(config.getReport("compartment_set_v").compartments == SimulationConfig::Report::Compartments::invalid);
        CHECK(config.getReport("compartment_set_v").compartment_set == "cs0");

        CHECK_NOTHROW(nlohmann::json::parse(config.getExpandedJSON()));
        CHECK(config.getBasePath() == basePath.lexically_normal());

        const auto network = fs::absolute(basePath / fs::path("circuit_config.json"));
        CHECK(config.getNetwork() == network.lexically_normal());
        CHECK(config.getTargetSimulator() == SimulatorType::CORENEURON);
        const auto circuit_conf = CircuitConfig::fromFile(config.getNetwork());
        CHECK(config.getNodeSetsFile() == circuit_conf.getNodeSetsPath());
        CHECK(config.getNodeSet() == "Column");

        using InputType = SimulationConfig::InputBase::InputType;
        using Module = SimulationConfig::InputBase::Module;
        {
            const auto input = nonstd::get<SimulationConfig::InputLinear>(config.getInput("ex_linear"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::linear);
            CHECK(input.delay == 0);
            CHECK(input.duration == 15);
            CHECK(input.nodeSet == "Column");
            CHECK(input.ampStart == 0.15);
            CHECK(input.ampEnd == 0.15);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputRelativeLinear>(config.getInput("ex_rel_linear"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::relative_linear);
            CHECK(input.delay == 0);
            CHECK(input.duration == 1000);
            CHECK(input.nodeSet == "Column");
            CHECK(input.percentStart == 80);
            CHECK(input.percentEnd == 20);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputPulse>(config.getInput("ex_pulse"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::pulse);
            CHECK(input.delay == 10);
            CHECK(input.duration == 80);
            CHECK(input.nodeSet == "Mosaic");

            CHECK(input.frequency == 80);
            CHECK(input.ampStart == 2);
            CHECK(input.width == 1);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputSinusoidal>(config.getInput("ex_sinusoidal"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::sinusoidal);
            CHECK(input.delay == 10);
            CHECK(input.duration == 80);
            CHECK(input.nodeSet == "Mosaic");

            CHECK(input.frequency == 8);
            CHECK(input.ampStart == 0.2);
            CHECK(input.dt == 0.5);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputSinusoidal>(config.getInput("ex_sinusoidal_default_dt"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::sinusoidal);
            CHECK(input.delay == 10);
            CHECK(input.duration == 80);
            CHECK(input.nodeSet == "Mosaic");

            CHECK(input.frequency == 80);
            CHECK(input.ampStart == 2);
            CHECK(input.dt == 0.025);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputSubthreshold>(config.getInput("ex_subthreshold"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::subthreshold);
            CHECK(input.delay == 10);
            CHECK(input.duration == 80);
            CHECK(input.nodeSet == "Mosaic");
            CHECK(input.percentLess == 80);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputNoise>(config.getInput("ex_noise_meanpercent"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::noise);
            CHECK(input.delay == 0);
            CHECK(input.duration == 5000);
            CHECK(input.nodeSet == "Rt_RC");
            CHECK(input.meanPercent.value() == 0.01);
            CHECK(input.variance == 0.001);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputNoise>(config.getInput("ex_noise_mean"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::noise);
            CHECK(input.delay == 0);
            CHECK(input.duration == 5000);
            CHECK(input.nodeSet == "Rt_RC");
            CHECK(input.mean.value() == 0);
            CHECK(input.variance == 0.001);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputShotNoise>(config.getInput("ex_shotnoise"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::shot_noise);
            CHECK(input.delay == 0);
            CHECK(input.duration == 1000);
            CHECK(input.nodeSet == "L5E");
            CHECK(input.ampMean == 70);
            CHECK(input.ampVar == 40);
            CHECK(input.rate == 4);
            CHECK(input.randomSeed == nonstd::nullopt);
            CHECK(input.riseTime == 0.4);
            CHECK(input.decayTime == 4);
            CHECK(input.reversal == 10);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputRelativeShotNoise>(config.getInput("ex_rel_shotnoise"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::relative_shot_noise);
            CHECK(input.delay == 0);
            CHECK(input.duration == 1000);
            CHECK(input.nodeSet == "L5E");
            CHECK(input.meanPercent == 70);
            CHECK(input.sdPercent == 40);
            CHECK(input.randomSeed == 230522);
            CHECK(input.riseTime == 0.4);
            CHECK(input.decayTime == 4);
            CHECK(input.reversal == 0);
            CHECK(input.relativeSkew == 0.5);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputHyperpolarizing>(config.getInput("ex_hyperpolarizing"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::hyperpolarizing);
            CHECK(input.delay == 0);
            CHECK(input.duration == 1000);
            CHECK(input.nodeSet == "L5E");
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputSynapseReplay>(config.getInput("ex_replay"));
            CHECK(input.inputType == InputType::spikes);
            CHECK(input.module == Module::synapse_replay);
            CHECK(input.delay == 0);
            CHECK(input.duration == 40000);
            CHECK(input.nodeSet == "Column");
            CHECK(endswith(input.spikeFile, "replay.h5"));
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputSeclamp>(config.getInput("ex_seclamp"));
            CHECK(input.inputType == InputType::voltage_clamp);
            CHECK(input.module == Module::seclamp);
            CHECK(input.delay == 0);
            CHECK(input.duration == 1000.);
            CHECK(input.nodeSet == "L5E");
            CHECK(input.voltage == 1.1);
            CHECK(input.seriesResistance == 0.5);
            CHECK(input.durationLevels == std::vector<double>{0, 10, 20, 30});
            CHECK(input.voltageLevels == std::vector<double>{1.5, 2, 3, 4});
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputAbsoluteShotNoise>(
                config.getInput("ex_abs_shotnoise"));
            CHECK(input.inputType == InputType::conductance);
            CHECK(input.module == Module::absolute_shot_noise);
            CHECK(input.mean == 50);
            CHECK(input.sigma == 5);
            CHECK(input.reversal == 10);
            CHECK(input.randomSeed == nonstd::nullopt);
            CHECK(input.representsPhysicalElectrode == true);
            CHECK(input.relativeSkew == 0.1);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputOrnsteinUhlenbeck>(
                config.getInput("ex_OU"));
            CHECK(input.inputType == InputType::conductance);
            CHECK(input.module == Module::ornstein_uhlenbeck);
            CHECK(input.tau == 2.8);
            CHECK(input.reversal == 10);
            CHECK(input.mean == 50);
            CHECK(input.sigma == 5);
            CHECK(input.randomSeed == nonstd::nullopt);
            CHECK(input.representsPhysicalElectrode == false);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputRelativeOrnsteinUhlenbeck>(
                config.getInput("ex_rel_OU"));
            CHECK(input.inputType == InputType::current_clamp);
            CHECK(input.module == Module::relative_ornstein_uhlenbeck);
            CHECK(input.tau == 2.8);
            CHECK(input.reversal == 0);
            CHECK(input.meanPercent == 70);
            CHECK(input.sdPercent == 10);
            CHECK(input.randomSeed == 230522);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputSpatiallyUniformEField>(
                config.getInput("ex_efields"));
            CHECK(input.inputType == InputType::extracellular_stimulation);
            CHECK(input.module == Module::spatially_uniform_e_field);
            CHECK(input.delay == 0);
            CHECK(input.duration == 1000);
            CHECK(input.nodeSet == "Mosaic");
            CHECK(input.rampUpTime == 100.);
            CHECK(input.rampDownTime == 10.);
            const auto fields = input.fields;
            CHECK(fields.size() == 4);
            CHECK(fields[0].ex == 0.1);
            CHECK(fields[0].ey == 0.2);
            CHECK(fields[0].ez == 0.3);
            CHECK(fields[0].frequency == 10.);
            CHECK(fields[0].phase == 0.5);
            CHECK(fields[1].ex == 0.4);
            CHECK(fields[1].ey == 0.5);
            CHECK(fields[1].ez == 0.6);
            CHECK(fields[1].frequency == 0.);
            CHECK(fields[1].phase == 0);
            CHECK(fields[2].ex == 0.7);
            CHECK(fields[2].ey == 0.8);
            CHECK(fields[2].ez == 0.9);
            CHECK(fields[2].frequency == 100.);
            CHECK(fields[2].phase == 0.);
            CHECK(fields[3].frequency == 0);
            CHECK(fields[3].phase == -0.1);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputSpatiallyUniformEField>(
                config.getInput("ex_efields_noramp"));
            CHECK(input.inputType == InputType::extracellular_stimulation);
            CHECK(input.module == Module::spatially_uniform_e_field);
            CHECK(input.delay == 0);
            CHECK(input.duration == 1000);
            CHECK(input.nodeSet == "Mosaic");
            CHECK(input.rampUpTime == 0.);
            CHECK(input.rampDownTime == 0.);
            const auto fields = input.fields;
            CHECK(fields.size() == 1);
            CHECK(fields[0].ex == 0.1);
            CHECK(fields[0].ey == 0.2);
            CHECK(fields[0].ez == 0.3);
            CHECK(fields[0].frequency == 0.);
            CHECK(fields[0].phase == 0.);
        }
        {
            const auto input = nonstd::get<SimulationConfig::InputPoissonSpike>(
                config.getInput("ex_poisson"));
            CHECK(input.inputType == InputType::spikes);
            CHECK(input.module == Module::poisson);
            CHECK(input.delay == 1);
            CHECK(input.duration == 555);
            CHECK(input.nodeSet == "All");
            CHECK(input.rate == 4.9);
            CHECK(input.weight == 3.5);
        }
        CHECK(config.listInputNames() == std::vector<std::string>{"ex_linear",
                                                                  "ex_linear_compartment_set",
                                                                  "ex_rel_linear",
                                                                  "ex_pulse",
                                                                  "ex_sinusoidal",
                                                                  "ex_sinusoidal_default_dt",
                                                                  "ex_subthreshold",
                                                                  "ex_shotnoise",
                                                                  "ex_hyperpolarizing",
                                                                  "ex_seclamp",
                                                                  "ex_noise_meanpercent",
                                                                  "ex_noise_mean",
                                                                  "ex_rel_shotnoise",
                                                                  "ex_abs_shotnoise",
                                                                  "ex_replay",
                                                                  "ex_OU",
                                                                  "ex_rel_OU",
                                                                  "ex_efields",
                                                                  "ex_efields_noramp",
                                                                  "ex_poisson",
                                                                  });

        auto overrides = config.getConnectionOverrides();
        CHECK(overrides[0].name == "ConL3Exc-Uni");
        CHECK(overrides[0].source == "Excitatory");
        CHECK(overrides[0].target == "Mosaic");
        CHECK(overrides[0].weight == 1);
        CHECK(overrides[0].spontMinis == 0.01);
        CHECK(overrides[0].modoverride == "GluSynapse");
        CHECK(overrides[0].delay == 0.5);
        CHECK(overrides[0].synapseDelayOverride == nonstd::nullopt);
        CHECK(overrides[0].synapseConfigure == nonstd::nullopt);
        CHECK(overrides[0].neuromodulationDtc == nonstd::nullopt);
        CHECK(overrides[0].neuromodulationStrength == nonstd::nullopt);

        CHECK(overrides[1].name == "GABAB_erev");
        CHECK(overrides[1].spontMinis == nonstd::nullopt);
        CHECK(overrides[1].synapseDelayOverride == 0.5);
        CHECK(overrides[1].delay == 0);
        CHECK(overrides[1].synapseConfigure == "%s.e_GABAA = -82.0 tau_d_GABAB_ProbGABAAB_EMS = 77");
        CHECK(overrides[1].modoverride == nonstd::nullopt);
        CHECK(overrides[1].neuromodulationDtc == 100);
        CHECK(overrides[1].neuromodulationStrength == 0.75);
        REQUIRE_THAT(config.getMetaData(),
                     Catch::Matchers::Predicate<decltype(config.getMetaData())>(
                         [](const auto& metadata) -> bool {
                             return metadata.size() == 4 &&
                                    nonstd::get<std::string>(metadata.at("note")) ==
                                        "first attempt of simulation" &&
                                    nonstd::get<int>(metadata.at("sim_version")) == 1 &&
                                    nonstd::get<double>(metadata.at("v_float")) == 0.5 &&
                                    nonstd::get<bool>(metadata.at("v_bool")) == false;
                         },
                         "metadata matches"));
        REQUIRE_THAT(config.getBetaFeatures(),
                     Catch::Matchers::Predicate<decltype(config.getBetaFeatures())>(
                         [](const auto& features) -> bool {
                             return features.size() == 4 &&
                                    nonstd::get<std::string>(features.at("v_str")) == "abcd" &&
                                    nonstd::get<int>(features.at("v_int")) == 10 &&
                                    nonstd::get<double>(features.at("v_float")) == 0.5 &&
                                    nonstd::get<bool>(features.at("v_bool")) == false;
                         },
                         "beta features match"));
    }

    SECTION("manifest_network_run") {
        auto contents = R"({
          "manifest": {
            "$CIRCUIT_DIR": "./circuit"
          },
          "network": "$CIRCUIT_DIR/circuit_config.json",
          "run": {
            "random_seed": 12345,
            "dt": 0.05,
            "tstop": 1000
          }
        })";
        namespace fs = ghc::filesystem;
        const auto basePath = fs::absolute(fs::path("./").parent_path());
        const auto config = SimulationConfig(contents, basePath);
        const auto network = fs::absolute(basePath / "circuit" / fs::path("circuit_config.json"));
        CHECK(config.getNetwork() == network.lexically_normal());
        CHECK(config.getTargetSimulator() == SimulatorType::UNSPECIFIED);
        CHECK(config.getNodeSetsFile() == "");  // network file is not readable so default empty
        CHECK(config.getNodeSet() == nonstd::nullopt);  // default
        CHECK(config.getRun().stimulusSeed == 0);
        CHECK(config.getRun().ionchannelSeed == 0);
        CHECK(config.getRun().minisSeed == 0);
        CHECK(config.getRun().synapseSeed == 0);
        CHECK(config.getRun().electrodesFile == "");
        CHECK(config.getRun().spikeThreshold == -30.0);
    }

    SECTION("Exception") {
        {  // No run section
            auto contents = R"({})";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No tstop in run section
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No dt in run section
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "tstop": 1000
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No random_seed in run section
            auto contents = R"({
              "run": {
                "tstop": 1000,
                "dt": 0.05
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Wrong spike_location in a condition object
            auto contents = R"({
              "run": {
                "tstop": 1000,
                "dt": 0.05,
                "random_seed": 12345
              },
              "conditions": {
                "spike_location": "axon"
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Wrong integration_method in a run object
            auto contents = R"({
              "run": {
                "tstop": 1000,
                "dt": 0.05,
                "random_seed": 12345,
                "integration_method": 4
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No reports section
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              }
            })";
            CHECK_NOTHROW(SimulationConfig(contents, "./"));
        }
        {  // No cells in a report object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "type": "typestring",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No type in a report object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No variable_name in a report object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "type": "compartment",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Wrong variable_name in a report object: no variable after ','
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "variable_name": "variablestring,",
                   "type": "compartment",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Wrong variable_name in a report object: leading '.'
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "variable_name": ".V_M, V",
                   "type": "compartment",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Wrong variable_name in a report object: more than one '.' in a name
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "variable_name": "AdEx..foo, V",
                   "type": "compartment",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Wrong variable_name in a report object: more than one '.' in a name
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "variable_name": "AdEx.V_M.foo, V",
                   "type": "compartment",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No dt in a report object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "type": "compartment",
                   "variable_name": "variablestring",
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No start_time in a report object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "type": "summation",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No end_time in a report object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "type": "summation",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Invalid sections in a report object
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "sections": "none",
                   "type": "synapse",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Invalid type in a report object, non-existing enum value
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "type": "not-a-valid-type",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Invalid type in a report object, numeric value
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "type": 0,
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }{  // Invalid type in a report object; `true` value
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "type": true,
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Invalid scaling in a report object
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "scaling": "linear",
                   "type": "compartment",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "compartments" key is not allowed in a report of type compartment_set
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000,
                "random_seed": 0
              },
              "reports": {
                "test": {
                   "compartment_set": "cs0",
                   "cells": "nodesetstring",
                   "compartments": "center",
                   "type": "compartment_set",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "sections" key is not allowed in a report of type compartment_set
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000,
                "random_seed": 0
              },
              "reports": {
                "test": {
                   "compartment_set": "cs0",
                   "cells": "nodesetstring",
                   "sections": "soma",
                   "type": "compartment_set",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "compartment_set" key is necessary in a report of type compartment_set
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000,
                "random_seed": 0
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "type": "compartment_set",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "compartment_set" key is not allowed when the report is not of type compartment_set
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000,
                "random_seed": 0
              },
              "reports": {
                "test": {
                   "compartment_set": "cs0",
                   "cells": "nodesetstring",
                   "type": "compartment",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Invalid compartments in a report object
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000,
                "random_seed": 0
              },
              "reports": {
                "test": {
                   "cells": "nodesetstring",
                   "compartment_set": "cs0",
                   "compartments": "middle",
                   "type": "compartment_set",
                   "variable_name": "variablestring",
                   "dt": 0.05,
                   "start_time": 0,
                   "end_time": 500
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "Field 'compartments' is not allowed for reports of type "
                                     "'compartment_set'."));
        }
        {  // wrong input_type in an input object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "linear": {
                   "input_type": "current",
                   "module": "linear",
                   "amp_start": 0.15,
                   "delay": 0,
                   "duration": 15,
                   "node_set":"Column"
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // wrong module in an input object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "linear": {
                   "input_type": "current_clamp",
                   "module": "spike_replay",
                   "amp_start": 0.15,
                   "delay": 0,
                   "duration": 15,
                   "node_set":"Column"
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // wrong input_type for module in an input object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                  "ex_hyperpolarizing": {
                      "input_type": "voltage_clamp",
                      "module": "hyperpolarizing",
                      "delay": 0,
                      "duration": 1000,
                      "node_set": "L5E"
                  }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // no amp_start in a linear input object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "linear": {
                    "input_type": "current_clamp",
                    "module": "linear",
                    "delay": 0,
                    "duration": 15,
                    "node_set":"Column"
                }
              }
            })";
            CHECK_THROWS_WITH(
                SimulationConfig(contents, "./"),
                Catch::Matchers::ContainsSubstring("amp_start")
            );
        }                                                      
        {  // Both node_set and compartment_set are given in an input object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "linear": {
                    "input_type": "current_clamp",
                    "module": "linear",
                    "delay": 0,
                    "duration": 15,
                    "amp_start": 1,
                    "node_set":"Column",
                    "compartment_set":"cs1"
                }
              }
            })";
            CHECK_THROWS_WITH(
                SimulationConfig(contents, "./"),
                Catch::Matchers::ContainsSubstring("node_set") &&
                Catch::Matchers::ContainsSubstring("compartment_set")
            );
        }
        {  // Both node_set and compartment_set are missing in an input object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "linear": {
                    "input_type": "current_clamp",
                    "module": "linear",
                    "delay": 0,
                    "duration": 15,
                    "amp_start": 1
                }
              }
            })";
            CHECK_THROWS_WITH(
                SimulationConfig(contents, "./"),
                Catch::Matchers::ContainsSubstring("node_set") &&
                Catch::Matchers::ContainsSubstring("compartment_set")
            );
        }
        {  // Both mean and mean_percent are given in a noise input object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "noise": {
                   "input_type": "current_clamp",
                   "module": "noise",
                   "delay": 0,
                   "duration": 15,
                   "node_set":"Column",
                   "mean" : 0.1,
                   "mean_percent": 0.01,
                   "variance": 0.001
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // No valuable mean or mean_percent are given in a noise input object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "noise": {
                   "input_type": "current_clamp",
                   "module": "noise",
                   "delay": 0,
                   "duration": 15,
                   "node_set":"Column",
                   "variance": 0.001,
                   "mean" : null
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // missing input
            const auto config = SimulationConfig::fromFile("./data/config/simulation_config.json");
            CHECK_THROWS_AS(config.getInput("does_not_exist"), SonataError);
        }
        {  // non-existant input_type
            const auto* contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "noise": {
                   "input_type": "Does_not_exist",
                   "module": "hyperpolarization"
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // wrong module for extracellular stimulation input
            const auto* contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "ex_replay": {
                  "input_type": "extracellular_stimulation",
                  "module": "synapse_replay",
                  "delay": 0.0,
                  "duration": 40000.0,
                  "spike_file": "replay.h5",
                  "node_set": "Column"
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "An `input` has module `synapse_replay` and input_type "
                                     "`extracellular_stimulation` which mismatch"));
        }
        {  // missing fields in spatially_uniform_e_field
            const auto* contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "ex_efields": {
                  "input_type": "extracellular_stimulation",
                  "module": "spatially_uniform_e_field",
                  "delay": 0.0,
                  "duration": 40000.0,
                  "node_set": "Column",
                  "ramp_up_time": 10.0
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "Could not find 'fields' in 'input ex_efields'"));
        }
        {  // fields must be an array in spatially_uniform_e_field
            const auto* contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "ex_efields": {
                  "input_type": "extracellular_stimulation",
                  "module": "spatially_uniform_e_field",
                  "delay": 0.0,
                  "duration": 40000.0,
                  "node_set": "Column",
                  "ramp_up_time": 10.0,
                  "fields": {"a":1, "b":2}
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "'fields' must be an array in 'input ex_efields'"));
        }
        {  // fields must not be empty in spatially_uniform_e_field
            const auto* contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "ex_efields": {
                  "input_type": "extracellular_stimulation",
                  "module": "spatially_uniform_e_field",
                  "delay": 0.0,
                  "duration": 40000.0,
                  "node_set": "Column",
                  "ramp_up_time": 10.0,
                  "fields": []
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "'fields' is empty in 'input ex_efields'"));
        }
        {  // Missing mandatory parameters in fields
            const auto* contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "ex_efields": {
                  "input_type": "extracellular_stimulation",
                  "module": "spatially_uniform_e_field",
                  "delay": 0.0,
                  "duration": 40000.0,
                  "node_set": "Column",
                  "ramp_up_time": 10.0,
                  "fields": [
                    {
                      "Ex": 0.1,
                      "frequency": 1.0
                    }
                  ]
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "Could not find 'Ey' in 'input ex_efields fields'"));
        }
        {  // Must be non-negative frequency in fields
            const auto* contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "ex_efields": {
                  "input_type": "extracellular_stimulation",
                  "module": "spatially_uniform_e_field",
                  "delay": 0.0,
                  "duration": 40000.0,
                  "node_set": "Column",
                  "ramp_up_time": 10.0,
                  "fields": [
                    {
                      "Ex": 0.1,
                      "Ey": 0.2,
                      "Ez": 0.3,
                      "frequency": -1.0
                    }
                  ]
                }
              }
            })";
            CHECK_THROWS_MATCHES(
                SimulationConfig(contents, "./"),
                SonataError,
                Catch::Matchers::Message(
                    "'frequency' must be non-negative in 'input ex_efields fields'"));
        }
        {  // Frequency should be less than 1000/(2*dt) (dt in ms) in fields
            const auto* contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs": {
                "ex_efields": {
                  "input_type": "extracellular_stimulation",
                  "module": "spatially_uniform_e_field",
                  "delay": 0.0,
                  "duration": 40000.0,
                  "node_set": "Column",
                  "ramp_up_time": 10.0,
                  "fields": [
                    {
                      "Ex": 0.1,
                      "Ey": 0.2,
                      "Ez": 0.3,
                      "frequency": 1.0
                    },
                    {
                      "Ex": 0.1,
                      "Ey": 0.2,
                      "Ez": 0.3,
                      "frequency": 20000
                    }
                  ]
                }
              }
            })";
            CHECK_THROWS_MATCHES(
                SimulationConfig(contents, "./"),
                SonataError,
                Catch::Matchers::Message(
                    "'frequency 20000' must be less than the Nyquist frequency of the simulation "
                    "1/(2*dt) = 10000 in 'input ex_efields fields'"));
        }
        {  // Invalid spikes ordering in the output section
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000
              },
              "output": {
                "output_dir": "$OUTPUT_DIR/output",
                "spikes_file": "out.h5",
                "spikes_sort_order": "invalid-order"
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {
            // Missing mandatory parameter in a connection_override object
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "connection_overrides": {
                "connect1": {
                   "source": "Excitatory",
                   "weight": 1
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // Wrong simulator type
            auto contents = R"({
              "target_simulator" : "BLABLA",
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {
            // Replay with a non-h5 file
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs" : {
                "ex_replay": {
                    "input_type": "spikes",
                    "module": "synapse_replay",
                    "delay": 0.0,
                    "duration": 40000.0,
                    "spike_file": "replay.dat",
                    "node_set": "Column"
                }
              }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {
            // SEClamp with delay
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs" : {
                "seclamp": {
                    "input_type": "voltage_clamp",
                    "node_set": "Column",
                    "module": "seclamp",
                    "delay": 0.01,
                    "duration": 100.0,
                    "voltage": 10
                }
              }
            })";
            CHECK_THROWS_MATCHES(
                SimulationConfig(contents, "./"),
                SonataError,
                Catch::Matchers::Message(
                    "`delay` is not applicable to SEClamp, must be zero in input seclamp"));
        }
        {
            // SEClamp with negative duration
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs" : {
                "seclamp": {
                    "input_type": "voltage_clamp",
                    "node_set": "Column",
                    "module": "seclamp",
                    "duration": -0.5,
                    "delay": 0,
                    "voltage": 10
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "`duration` must be non-negative in input seclamp"));
        }
        {
            // SEClamp with different length of voltage_levels and duration_levels
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs" : {
                "seclamp": {
                    "input_type": "voltage_clamp",
                    "node_set": "Column",
                    "module": "seclamp",
                    "delay": 0.0,
                    "duration": 100.0,
                    "voltage": 10,
                    "duration_levels": [10.0, 20.0],
                    "voltage_levels": [10.0, 20.0, 30.0]
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "`duration_levels` and `voltage_levels` must have the same "
                                     "size in input seclamp"));
        }
        {
            // SEClamp with duration_levels that contains negative values
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs" : {
                "seclamp": {
                    "input_type": "voltage_clamp",
                    "node_set": "Column",
                    "module": "seclamp",
                    "delay": 0.0,
                    "duration": 100.0,
                    "voltage": 10,
                    "duration_levels": [-0.00000005, 10.0, 20.0],
                    "voltage_levels": [10.0, 20.0, 30.0]
                }
              }
            })";
            CHECK_THROWS_MATCHES(
                SimulationConfig(contents, "./"),
                SonataError,
                Catch::Matchers::Message(
                    "`duration_levels` must contain only non-negative values in input seclamp"));
        }
        {
            // SEClamp with duration_levels that exceed the total duration
            auto contents = R"({
              "run": {
                "random_seed": 12345,
                "dt": 0.05,
                "tstop": 1000
              },
              "inputs" : {
                "seclamp": {
                    "input_type": "voltage_clamp",
                    "node_set": "Column",
                    "module": "seclamp",
                    "delay": 0.0,
                    "duration": 10.0,
                    "voltage": 10,
                    "duration_levels": [5.000001, 3.0, 2.0],
                    "voltage_levels": [10.0, 20.0, 30.0]
                }
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "Sum of `duration_levels` must not exceed the total "
                                     "`duration` in input seclamp"));
        }
        {  // The "node_set" key is mandatory in "section_list" modification
            auto contents = R"({
                "run": {
                  "random_seed": 12345,
                  "dt": 0.05,
                  "tstop": 1000
                },
                "conditions": {
                  "celsius": 34.0,
                  "modifications": [
                    {
                      "name": "apical_block_NaTg_exception",
                      "type": "section_list",
                      "section_configure": "apical.gbar_NaTg = 0"
                    }
                  ]
                }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "node_set" key is mandatory in "section_list" modification
            auto contents = R"({
                "run": {
                  "random_seed": 12345,
                  "dt": 0.05,
                  "tstop": 1000
                },
                "conditions": {
                  "celsius": 34.0,
                  "modifications": [
                    {
                      "name": "apical_block_NaTg_exception",
                      "compartment_set": "dend_ca_hotspot_name",
                      "type": "section_list",
                      "section_configure": "apical.gbar_NaTg = 0"
                    }
                  ]
                }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "node_set" key is mandatory in "section" modification
            auto contents = R"({
                "run": {
                  "random_seed": 12345,
                  "dt": 0.05,
                  "tstop": 1000
                },
                "conditions": {
                  "celsius": 34.0,
                  "modifications": [
                    {
                      "name": "apical[10]_KTst_NaTg_block_exception",
                      "type": "section",
                      "section_configure": "apic[10].gbar_KTst = 0; apic[10].gbar_NaTg = 0"
                    }
                  ]
                }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "node_set" key is mandatory in "section" modification
            auto contents = R"({
                "run": {
                  "random_seed": 12345,
                  "dt": 0.05,
                  "tstop": 1000
                },
                "conditions": {
                  "celsius": 34.0,
                  "modifications": [
                    {
                      "name": "apical[10]_KTst_NaTg_block_exception",
                      "compartment_set": "dend_ca_hotspot_name",
                      "type": "section",
                      "section_configure": "apic[10].gbar_KTst = 0; apic[10].gbar_NaTg = 0"
                    }
                  ]
                }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "compartment_set" key is mandatory in "compartment_set" modification
            auto contents = R"({
                "run": {
                  "random_seed": 12345,
                  "dt": 0.05,
                  "tstop": 1000
                },
                "conditions": {
                  "celsius": 34.0,
                  "modifications": [
                    {
                      "name": "Ca_hotspot_dend[10]_manipulation_exception",
                      "type": "compartment_set",
                      "section_configure": "gbar_Ca_HVA2 = 1.5; gbar_Ca_LVA = 2"
                    }
                  ]
                }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // The "compartment_set" key is mandatory in "compartment_set" modification
            auto contents = R"({
                "run": {
                  "random_seed": 12345,
                  "dt": 0.05,
                  "tstop": 1000
                },
                "conditions": {
                  "celsius": 34.0,
                  "modifications": [
                    {
                      "name": "Ca_hotspot_dend[10]_manipulation_exception",
                      "node_set": "single",
                      "type": "compartment_set",
                      "section_configure": "gbar_Ca_HVA2 = 1.5; gbar_Ca_LVA = 2"
                    }
                  ]
                }
            })";
            CHECK_THROWS_AS(SimulationConfig(contents, "./"), SonataError);
        }
        {  // duplicate keys at root level rejected by nlohmann::json
            auto contents = R"({
            "ABC": 1,
            "ABC": 2
          })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message("Duplicate key 'ABC' in 'root'"));
        }
        {  // duplicate section keys at root level rejected by nlohmann::json
            auto contents = R"({
            "reports": {},
            "reports": {}
          })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message("Duplicate key 'reports' in 'root'"));
        }
        {  // duplicate keys in section - 1
            auto contents = R"({
            "ABC": 1,
            "run" : {
              "ABC": 1,
              "ABC": 2
            }
          })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message("Duplicate key 'ABC' in 'run'"));
        }
        {  // duplicate section keys in section - 2, such inputs, reports
            auto contents = R"({
            "ABC": 1,
            "inputs" : {
              "ABC": {},
              "ABC": {}
            }
          })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message("Duplicate key 'ABC' in 'inputs'"));
        }
        {  // duplicate keys in sub sections
            auto contents = R"({
            "ABC": 1,
            "conditions": {
              "ABC": 1,
               "mechanisms": {
                  "ABC": {"A":1},
                  "ABC": {"A":1}
                }
              }
          })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message("Duplicate key 'ABC' in 'mechanisms'"));
        }
        {  // duplicate connection_override name
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000,
                "random_seed": 0
              },
              "connection_overrides": [
                {
                    "name": "dup_conn",
                    "source": "A",
                    "target": "B",
                    "synapse_configure": "%s.dummy=1"
                },
                {
                    "name": "dup_conn",
                    "source": "A",
                    "target": "B",
                    "synapse_configure": "%s.dummy=1"
                }
              ]
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "Duplicate name 'dup_conn' in 'connection_overrides'"));
        }
        {  // duplicate condition modification name
            auto contents = R"({
              "run": {
                "dt": 0.05,
                "tstop": 1000,
                "random_seed": 0
              },
              "conditions": {
                "modifications": [
                  {
                    "name": "TTXdup",
                    "node_set": "single",
                    "type": "ttx"
                  },
                  {
                    "name": "TTXdup",
                    "node_set": "single",
                    "type": "ttx"
                  }
                ]
              }
            })";
            CHECK_THROWS_MATCHES(SimulationConfig(contents, "./"),
                                 SonataError,
                                 Catch::Matchers::Message(
                                     "Duplicate name 'TTXdup' in 'modifications'"));
        }
    }
}
