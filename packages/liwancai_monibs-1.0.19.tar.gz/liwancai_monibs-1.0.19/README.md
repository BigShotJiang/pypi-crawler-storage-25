# MoNiBS

模拟交易回测系统 - 提供完整的订单管理、账户管理、数据管理功能

**注意**: 包在PyPI上的名称是 `liwancai-MoNiBS`，但导入时使用 `MoNiBS`

## 安装

```bash
pip install liwancai-MoNiBS
```

## 使用

```python
# 导入整个包的所有功能
from MoNiBS import *
 
### 其他导入方式

# 导入特定模块
from MoNiBS import MoNiBS, Order, Account

# 导入特定函数
from MoNiBS.OrderHold.OrderDeal import OrderDeal_getKNum, OrderDeal_getPNum
```

# MoNiBS 量化回测框架

MoNiBS（模拟交易回测系统）是一个功能强大的Python量化回测框架，它提供了完整的交易模拟、账户管理、数据管理和回测分析功能。

## 🚀 核心特性

- **完整的交易模拟**：支持多空交易、看多看空等多种交易类型
- **多周期数据支持**：支持分钟线、日线等多时间周期数据
- **智能账户管理**：多账户支持、资金管理、风险控制
- **数据库存储**：使用DuckDB进行高效数据存储和查询
- **模块化设计**：各功能模块独立，易于扩展和维护
- **Web API接口**：提供RESTful API接口，支持远程调用
- **因子分析模块**：内置因子计算和IC/IR分析功能

## 📁 项目结构

```
MoNiBS/
├── Account/           # 账户管理模块
│   ├── Account.py     # 账户数据模型
│   ├── AccountHub.py  # 账户管理器
│   └── __init__.py
├── DBSave/            # 数据存储模块
│   ├── DBSaveHub.py   # 数据库管理器
│   └── __init__.py
├── Factor/            # 因子分析模块
│   ├── ICIR.py        # IC/IR分析
│   ├── PreProcess.py  # 数据预处理
│   ├── Work.py        # 因子计算工作流
│   └── __init__.py
├── MgrData/           # 数据管理模块
│   ├── Client.py      # 数据客户端
│   ├── CodeFees.py    # 费用计算
│   ├── MgrDataHub.py  # 数据管理器
│   └── __init__.py
├── OrderHold/         # 订单持仓模块
│   ├── Help.py        # 订单帮助文档
│   ├── Hold.py        # 持仓管理
│   ├── Order.py       # 订单模型
│   ├── OrderDeal.py   # 订单处理
│   ├── OrderHub.py    # 订单管理器
│   ├── OrderPGFH.py   # 分红配股处理
│   ├── Type.py        # 类型定义
│   └── __init__.py
├── Strategys/         # 策略模块
│   └── __init__.py
├── WebApi/            # Web API接口模块
│   ├── ApiAccs.py     # 账户数据API
│   ├── ApiBase.py     # 基础数据API
│   ├── ApiHold.py     # 持仓数据API
│   ├── ApiOrder.py    # 订单数据API
│   ├── DBConBase.py   # 数据库连接基类
│   ├── Evaluate.py    # 评估数据模型
│   └── __init__.py
├── utils/             # 工具模块
│   ├── DataType.py    # 数据类型定义
│   ├── Tools.py       # 工具函数
│   └── __init__.py
├── MoNiBS.py          # 主框架类
└── __init__.py
```

## 依赖包

- `liwancai-PyLOG>=1.0.0`: 日志记录
- `liwancai-PyTools>=1.0.0`: 工具函数
- `fastapi>=0.68.0`: Web API框架
- `pydantic>=1.8.0`: 数据验证
- `duckdb>=0.5.0`: 数据库存储

## 🔄 更新日志

### 最新更新
- **Web API模块**：新增完整的RESTful API接口
- **因子分析模块**：新增IC/IR分析和数据预处理功能
- **代码优化**：统一数据库依赖管理，消除重复代码
- **模块化改进**：更好的模块分离和接口设计

## 📄 许可证

MIT License