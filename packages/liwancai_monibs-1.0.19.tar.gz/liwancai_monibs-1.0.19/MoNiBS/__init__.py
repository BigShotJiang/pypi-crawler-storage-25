# -*- coding: utf-8 -*-
"""
MoNiBS - 模拟交易回测系统

提供完整的订单管理、账户管理、数据管理功能，支持多种交易类型和策略。
"""

from .MoNiBS import MoNiBS
from .OrderHold.OrderHub import OrderHub
from .DBSave.DBSaveHub import DBSaveHub
from .MgrData.MgrDataHub import MgrDataHub
from .Account.AccountHub import AccountHub
from .Account.AccountHub import Account
from .OrderHold.Help import OrderHelp
from .OrderHold.Order import Order, OrderStatus
from .utils.DataType import KLine, KLineN, TickN
from .OrderHold.Type import BSType, BSTypeString
from .OrderHold.OrderDeal import OrderDeal_getKNum, OrderDeal_getPNum
from .OrderHold.OrderDeal import OrderDeal_getBSPrice, OrderDeal_checkOrder

__version__ = "1.0.19"
__author__ = "liwancai"
__all__ = [
    "MoNiBS",
    "OrderHub",
    "DBSaveHub", 
    "MgrDataHub",
    "AccountHub",
    "Account",
    "OrderHelp",
    "Order",
    "OrderStatus", 
    "KLine",
    "KLineN",
    "TickN",
    "BSType",
    "BSTypeString",
    "OrderDeal_getKNum",
    "OrderDeal_getPNum", 
    "OrderDeal_getBSPrice",
    "OrderDeal_checkOrder"
]
