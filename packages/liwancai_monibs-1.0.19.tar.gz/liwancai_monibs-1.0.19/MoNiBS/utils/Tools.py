import uuid
from datetime import datetime
def UniqueID(prefix: str = "") -> str:
    """
    格式: prefix-100432901-550e8400e29b_20260327
    包含日期、微秒时间戳、UUID前12位
    """
    now = datetime.now()
    date_str = now.strftime("%Y%m%d")
    time_str = now.strftime("%H%M%S%f")[:-3]  # 毫秒级
    uuid_part = uuid.uuid4().hex[:12]
    return f"{prefix}_{time_str}-{uuid_part}_{date_str}"

 