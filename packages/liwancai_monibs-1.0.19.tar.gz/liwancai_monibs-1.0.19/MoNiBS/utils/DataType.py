from typing import Optional
from dataclasses import dataclass, field


@dataclass
class KLineN:
    # K线基本标识字段
    code: str 
    period: str 
    REFclose: float 
    trade_time: str 
    trade_date: str 
    # K线基本行情数据字段
    open: float 
    close: float 
    high: float 
    low: float 
    volume: float 
    amount: float 
    # 序列及复权字段
    hfq: float
    # 可选字段（有默认值）
    Name: Optional[str] = None
    FullName: Optional[str] = None
    Qfq: Optional[float] = None
    ADJ: Optional[str] = None
    Kid: Optional[int] = None
    # 期货补充字段
    OI: Optional[float] = None
    REFOI: Optional[float] = None
    REFamount: Optional[float] = None
    REFvolume: Optional[float] = None
    NumT: Optional[int] = None
    NumK: Optional[int] = None
    REFNumK: Optional[int] = None
    Time: Optional[int] = None
    REFTime: Optional[int] = None
    ActionDay: Optional[str] = None
    SetPrice: Optional[float] = None
    REFSetPrice: Optional[float] = None
    OpenPrice: Optional[float] = None
    HighPrice: Optional[float] = None
    LowPrice: Optional[float] = None
    Uplimitprice: Optional[float] = None
    Dwlimitprice: Optional[float] = None
    AveragePrice: Optional[float] = None

def KLine(**kwargs) -> KLineN:
    # 提取必需参数
    # 创建KLineN实例
    k = KLineN(**kwargs)
    # 设置可选参数
    if kwargs:
        for key, value in kwargs.items(): 
            if hasattr(k, key) and key not in kwargs.keys():
                setattr(k, key, value)
    return k

@dataclass
class TickN:
    """股票Tick行情数据"""
    Code: str # 股票代码
    Time: int   # 时间戳
    TradeTime: str # 交易时间戳
    TradeDate: str # 交易日期戳

    LastPrice: float# 最新价
    Volume: float   # 成交量
    Amount: float   # 成交额
    REFclose: float # 前交易日收盘价

    SetPrice: float     #结算价
    OpenPrice: float    #开盘价
    UPLimitPrice: float # 上限价 涨停价
    DWLimitPrice: float # 下限价 跌停价

    HighPrice: float     ### 最高价
    LowPrice: float      ### 最低价
    AskPrice: list[float] = field(default_factory=list)## 卖盘（挂卖单的价格）
    BidPrice: list[float] = field(default_factory=list)## 买盘（挂买单的价格）
    AskVol: list[int] = field(default_factory=list)
    BidVol: list[int] = field(default_factory=list)