from enum import IntEnum

class OrderStatus(IntEnum):
    Pending     = 0         # 待处理: 订单已提交，等待处理 完全未成交 部分成交
    Processing  = 1         # 处理中 ### 原子状态 不可编辑
    Completed   = 2         # 已完成
    Cancelled   = 3         # 已取消
    Failed      = 4         # 失败/废单
    Expired     = 5         # 过期


OrderStatusMap ={
    "Pending": OrderStatus.Pending,
    "Processing": OrderStatus.Processing,
    "Completed": OrderStatus.Completed,
    "Cancelled": OrderStatus.Cancelled,
    "Failed": OrderStatus.Failed,
    "Expired": OrderStatus.Expired,
}
OrderStatusString={
    OrderStatus.Pending: "Pending",
    OrderStatus.Processing: "Processing",
    OrderStatus.Completed: "Completed",
    OrderStatus.Cancelled: "Cancelled",
    OrderStatus.Failed: "Failed",
    OrderStatus.Expired: "Expired",
}
OrderStatusDesc ={
    OrderStatus.Pending: "待处理",
    OrderStatus.Processing: "处理中",
    OrderStatus.Completed: "已完成",
    OrderStatus.Cancelled: "已取消",
    OrderStatus.Failed: "失败",
    OrderStatus.Expired: "已过期",
}

class OrderMethod(IntEnum):    
    Market = 13       # 市价
    Limit  = 12       # 限价
    UpLimit = 11      # 上限价 涨停价 价格笼子上限
    DwLimit = 10      # 下限价 跌停价 价格笼子下限

    Buy1 = 1      # 买1
    Buy2 = 2      # 买2
    Buy3 = 3      # 买3
    Buy4 = 4      # 买4
    Buy5 = 5      # 买5

    Sell1 = -1      # 卖1
    Sell2 = -2      # 卖2
    Sell3 = -3      # 卖3
    Sell4 = -4      # 卖4
    Sell5 = -5      # 卖5

OrderMethodMap ={
    "Market": OrderMethod.Market,
    "Limit": OrderMethod.Limit,
    "UpLimit": OrderMethod.UpLimit,
    "DwLimit": OrderMethod.DwLimit,
    "Buy1": OrderMethod.Buy1,
    "Buy2": OrderMethod.Buy2,
    "Buy3": OrderMethod.Buy3,
    "Buy4": OrderMethod.Buy4,
    "Buy5": OrderMethod.Buy5,
    "Sell1": OrderMethod.Sell1,
    "Sell2": OrderMethod.Sell2,
    "Sell3": OrderMethod.Sell3,
    "Sell4": OrderMethod.Sell4,
    "Sell5": OrderMethod.Sell5,
}
OrderMethodString={
    OrderMethod.Market: "Market",
    OrderMethod.Limit: "Limit",
    OrderMethod.UpLimit: "UpLimit",
    OrderMethod.DwLimit: "DwLimit",
    OrderMethod.Buy1: "Buy1",
    OrderMethod.Buy2: "Buy2",
    OrderMethod.Buy3: "Buy3",
    OrderMethod.Buy4: "Buy4",
    OrderMethod.Buy5: "Buy5",
    OrderMethod.Sell1: "Sell1",
    OrderMethod.Sell2: "Sell2",
    OrderMethod.Sell3: "Sell3",
    OrderMethod.Sell4: "Sell4",
    OrderMethod.Sell5: "Sell5",
}

OrderMethodDesc ={
    OrderMethod.Market: "市价",
    OrderMethod.Limit: "限价",
    OrderMethod.UpLimit: "上限价",
    OrderMethod.DwLimit: "下限价",
    OrderMethod.Buy1: "买1",
    OrderMethod.Buy2: "买2",
    OrderMethod.Buy3: "买3",
    OrderMethod.Buy4: "买4",
    OrderMethod.Buy5: "买5",
    OrderMethod.Sell1: "卖1",
    OrderMethod.Sell2: "卖2",
    OrderMethod.Sell3: "卖3",
    OrderMethod.Sell4: "卖4",
    OrderMethod.Sell5: "卖5",
}

class BSType(IntEnum):
    ND = 0      # 无交易

    KS = 1      # 开 空单 S
    KB = 2      # 开 多单 B
    KSS = 3     # 开 看空卖方 S
    KSB = 4     # 开 看空买方 B
    KBS = 5     # 开 看多卖方 S
    KBB = 6     # 开 看多买方 B

    PS = -1      # 平 空单 B
    PB = -2      # 平 多单 S
    PSS = -3     # 平 看空卖方 B
    PSB = -4     # 平 看空买方 S
    PBS = -5     # 平 看多卖方 B
    PBB = -6     # 平 看多买方 S

# 字符串到枚举的映射
BSTypeMap = {
    "ND":  BSType.ND,  # 无交易
    "KB":  BSType.KB,  # 开多单
    "KS":  BSType.KS,  # 开空单
    "KSS": BSType.KSS, # 开看空卖方
    "KSB": BSType.KSB, # 开看空买方
    "KBS": BSType.KBS, # 开看多卖方
    "KBB": BSType.KBB, # 开看多买方
    "PB":  BSType.PB,  # 平多单
    "PS":  BSType.PS,  # 平空单
    "PSS": BSType.PSS, # 平看空卖方
    "PSB": BSType.PSB, # 平看空买方
    "PBS": BSType.PBS, # 平看多卖方
    "PBB": BSType.PBB, # 平看多买方
}

# 枚举到字符串的映射
BSTypeString = {
    BSType.ND:  "ND",
    BSType.KB:  "KB",
    BSType.KS:  "KS",
    BSType.KSS: "KSS",
    BSType.KSB: "KSB",
    BSType.KBS: "KBS",
    BSType.KBB: "KBB",
    BSType.PB:  "PB",
    BSType.PS:  "PS",
    BSType.PSS: "PSS",
    BSType.PSB: "PSB",
    BSType.PBS: "PBS",
    BSType.PBB: "PBB",
}

# 枚举到描述的映射
BSTypeDesc = {
    BSType.ND:  "无交易",
    BSType.KB:  "开多单",
    BSType.KS:  "开空单",
    BSType.KSS: "开看空卖方",
    BSType.KSB: "开看空买方",
    BSType.KBS: "开看多卖方",
    BSType.KBB: "开看多买方",
    BSType.PB:  "平多单",
    BSType.PS:  "平空单",
    BSType.PSS: "平看空卖方",
    BSType.PSB: "平看空买方",
    BSType.PBS: "平看多卖方",
    BSType.PBB: "平看多买方",
}
def getBSTypeGroup(t: BSType) -> str:
    return abs(t)

def IsK(t: BSType) -> bool:###开仓的订单
    return t > 0
def IsP(t: BSType) -> bool:###平仓的订单
    return t < 0

def IsBid(t: BSType) -> bool:###买盘的订单 
    return (t>0 and t%2==0) or (t<0 and t%2!=0)
def IsAsk(t: BSType) -> bool:###卖盘的订单
    return (t>0 and t%2!=0) or (t<0 and t%2==0)


