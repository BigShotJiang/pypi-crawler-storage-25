from dataclasses                     import dataclass
from PyTools.TimeDate                import NowTime
from ..utils.Tools                   import UniqueID
from ..utils.DataType                import KLineN,TickN
from .Type                import BSType, OrderMethod, OrderStatus,OrderMethodMap
@dataclass
class OrderN:
    OrderID: str        ## 订单ID 订单唯一性编号
    AccountID: str      ## 账户ID 指定哪一个账户来开仓交易
    Code: str           ## 代码

    Price: float        ## 价格 限价时必填
    Qty: float          ## 数量 单位股 默认100股
    OkQty: float        ## 已成交数量 单位股 默认0股
    Type: BSType        ## 交易类型 KB开多/KS开空/PB平多/PS平空 KBB开看多买方KBS开看多卖方 KSB开看空买方KSS开看空卖方 PBB平看多买方PBS平看多卖方 PSB平看空买方PSS平看空卖方
    Method: OrderMethod     ## 交易方式 市价 限价 上限价 下限价 买1 买2 买3 买4 买5 卖1 卖2 卖3 卖4 卖5 
    Status: OrderStatus     ## 订单状态 待处理/处理中/已完成/已取消/失败/已过期
    BSTDNum: int          ## T+N 交易模式 由订单传递给持仓属性 0:t+0 1:t+1 2:t+2 .. 10:t+10
    CreateTime: str         ## 创建时间 格式YYYY-MM-DD HH:MM:SS ### 通常是K线时间
    UpdateTime: str         ## 更新时间 格式YYYY-MM-DD HH:MM:SS ### 通常是K线时间
    ExpireTime: str         ## 过期时间 格式YYYY-MM-DD HH:MM:SS ### 通常是K线时间 默认K线交易日16:00:00就过期
    SystemTime: str         ## 系统时间 格式YYYY-MM-DD HH:MM:SS ### 通常是K线时间 默认当前时间
    INFO: str             ## 订单备注 由用户自定义
def flashMethodPrice(Method:OrderMethod ,Price:float,kline:KLineN,tick:TickN=None):
    # 处理 Method 参数：字符串 → 枚举，数字 → 枚举
    if isinstance(Method, str):### 如果传入的是字符串
        # 传入字符串："Market" / "Limit" / "Buy1"
        Method = OrderMethodMap[Method]### 转换为枚举
    elif isinstance(Method, int):# 传入数字：13 / 12 / 1
        Method = OrderMethod(Method)### 转换为枚举
    ### 赋值   
    if  Method in [OrderMethod.Buy1, OrderMethod.Buy2, OrderMethod.Buy3, OrderMethod.Buy4, OrderMethod.Buy5]:
        ### 如果Tick有数据 Method是买1-5 则设置Price 为对应价格
        if tick: Price = tick.BidPrice[Method-1 ]
        else: Price = (kline.close + kline.low)/2 ### 没有Tick数据时，默认使用K线收盘价和最低价的平均值作为价格
        Method = OrderMethod.Limit
    elif Method in [OrderMethod.Sell1, OrderMethod.Sell2, OrderMethod.Sell3, OrderMethod.Sell4, OrderMethod.Sell5]:
        ### 如果Tick有数据 Method是卖1-5 则设置Price 为对应价格
        if tick: Price = tick.AskPrice[abs(Method)-1 ]
        else: Price = (kline.close + kline.high)/2 ### 没有Tick数据时，默认使用K线收盘价和最高价的平均值作为价格
        Method = OrderMethod.Limit
    return Method,Price
def Order(AccountID:str,###需要指定账户ID 
        kline:KLineN,tick:TickN=None, BSType:BSType=BSType.ND,
        Method:OrderMethod=OrderMethod.Market,
        Price:float=0.0, Qty:float=0.0,OkQty:float=0.0,
        ExpireTime:str="", BSTDNum:int=1,INFO:str="",**kwargs) -> OrderN:
    # ====================== 【新增】自动转换 Method：支持 枚举/数字/字符串 ======================
    Method,Price = flashMethodPrice(Method,Price,kline,tick)
        
    order = OrderN(
        OrderID     =UniqueID(f"{BSType.value}_{kline.code}"),   ### 由系统生成 不受参数覆盖
        Status      =OrderStatus.Pending if Qty!=0 else OrderStatus.Failed, ### 由系统生成 不受参数覆盖
        AccountID   =AccountID,                                  ### 指定哪一个账户来开仓交易 
        Code        =kline.code,
        Price       =Price,
        Qty         =Qty,
        OkQty       =OkQty,
        Type        =BSType,
        Method      =Method,
        BSTDNum     =abs(BSTDNum),###默认T+1 交易模式 避免负数
        CreateTime  =kline.trade_time,
        UpdateTime  =kline.trade_time,
        ExpireTime  =ExpireTime if ExpireTime else f"{kline.trade_date} 16:00:00" ,
        SystemTime  =NowTime(),
        INFO        =INFO  )
    if kwargs:   ### 处理kwargs参数
        for key, value in kwargs.items(): 
            if hasattr(order, key):setattr(order, key, value)
    return order
