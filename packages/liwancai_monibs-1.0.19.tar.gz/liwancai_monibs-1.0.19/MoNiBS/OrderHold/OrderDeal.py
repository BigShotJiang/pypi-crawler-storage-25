from ..Account.AccountHub        import AccountN
from ..MgrData.CodeFees          import CodeFeesN
from .Type                       import OrderMethod
from ..utils.DataType            import KLineN,TickN
from .Order                      import OrderN ,BSType
from .Hold                       import HoldN,HoldType
from .Type                       import OrderStatus,IsAsk,IsBid,IsK,IsP

import math
from LOG                         import log
from PyTools.TimeDate            import NowTime,Timestamp2Str


def IsLong(t: BSType | HoldType) -> bool:###多头 开仓
    return (t>0 and t%2==0)###偶数
def IsShort(t: BSType | HoldType) -> bool:###空头 开仓
    return (t>0 and t%2!=0)###奇数

def OrderDeal_checkOrder(codeOrder: OrderN,Kline: KLineN,Tick: TickN = None) -> bool:
    """
    检查订单是否待处理 未过期
    """
    ### 验证订单是否待处理 未过期
    if codeOrder.Status != OrderStatus.Pending:
        log.Warn(f"订单ID {codeOrder.OrderID} 状态不是待处理状态: {codeOrder.Status}")
        return  False
    ### 获取K线时间 用于更新订单时间及验证订单有效期
    TradeTime = Kline.trade_time if Tick is None else Timestamp2Str(Tick.time)
    if codeOrder.ExpireTime <= TradeTime:
        codeOrder.Status = OrderStatus.Expired
        codeOrder.UpdateTime = TradeTime
        codeOrder.SystemTime = NowTime()
        log.Warn(f"订单ID {codeOrder.OrderID} 过期: {codeOrder.ExpireTime}")
        return False
    return True
def getBaseMargin(BSPrice: float,BSHoldType: BSType | HoldType,codeFees: CodeFeesN) -> float:
    """
    获取保证金
    """
    if BSPrice<0:return 0.0
    ### 计算保证金
    VolumeMultiple = codeFees.VolumeMultiple### 乘数
    Long  = (BSPrice*VolumeMultiple  *codeFees.LongMarginRatioByMoney  + codeFees.LongMarginRatioByVolume )
    Short = (BSPrice*VolumeMultiple  *codeFees.ShortMarginRatioByMoney + codeFees.ShortMarginRatioByVolume)
    BaseMargin = Long if IsLong(BSHoldType) else Short
    return BaseMargin
def getOpenFee(BSPrice: float,codeFees: CodeFeesN,ByVolume: bool = False) -> float:
    """
    获取开仓手续费
    """
    if BSPrice<0:return 0.0
    if ByVolume:
        return codeFees.OpenRatioByVolume
    else:
        return BSPrice * codeFees.VolumeMultiple *codeFees.OpenRatioByMoney 
 
def getCloseFee(BSPrice: float,codeFees: CodeFeesN,ToDay: bool = False,ByVolume: bool = False) -> float:
    """
    获取平仓手续费
    """
    if BSPrice<0:return 0.0
    ### 计算平仓手续费
    if ToDay:
        ### 平今手续费
        if ByVolume:
            return codeFees.CloseTodayRatioByVolume
        else:
            return BSPrice * codeFees.VolumeMultiple *codeFees.CloseTodayRatioByMoney  
    else:
        ### 平仓手续费
        if ByVolume:
            return codeFees.CloseRatioByVolume
        else:
            return BSPrice * codeFees.VolumeMultiple *codeFees.CloseRatioByMoney  

def OrderDeal_getKNum(codeOrder: OrderN,Account: AccountN,Kline: KLineN,BSPrice: float,codeFees: CodeFeesN):
    '''
    ### 最小单位【保证金】计算公式:
    ### 多头保证金 = 价格 * 乘数 * 多头保证金率 + 多头保证金费
    ### 空头保证金 = 价格 * 乘数 * 空头保证金率 + 空头保证金费
    ### 股票 = 价格 * 乘数(1) *  保证金率(1) +保证金费(0)

    ### 开仓手续费 = 开仓价格 * 乘数 * 开仓手续费率 + 开仓手续费 
    ### 股票 = 开仓价格 * 乘数(1) * 开仓手续费率(3/1000) + 开仓手续费(5) 
    '''
    if IsP(codeOrder.Type) or BSPrice<0:return 0,0 ### 错误 检查出是平仓订单 不能计算可开数量
    BSNum = codeOrder.Qty - codeOrder.OkQty### 订单任务中未成交数量 = 订单数量 - 已成交数量 
    if abs(BSNum)<codeFees.MinOpenVolume : 
        log.Warn(f"订单开仓数量小于最小开仓数量{codeFees.MinOpenVolume} 废单")
        codeOrder.Status = OrderStatus.Failed
        codeOrder.UpdateTime = Kline.trade_time
        codeOrder.SystemTime = NowTime()
        return 0,0
    if Account.FundsAble<=0: 
        log.Warn(f"可用资金不足{Account.FundsAble},订单ID {codeOrder.OrderID} 无法开仓")
        codeOrder.Status = OrderStatus.Failed
        codeOrder.UpdateTime = Kline.trade_time
        codeOrder.SystemTime = NowTime()
        return 0,0 ### 资金不足
    ### 计算保证金
    BaseMargin = getBaseMargin(BSPrice,codeOrder.Type,codeFees)
    ### 计算手续费
    oNEFee = getOpenFee(BSPrice,codeFees)
    Fees   = abs(BSNum) * oNEFee 
    NeedFunds = abs(BSPrice) * abs(BSNum) + Fees ### 开仓资金 
    if Account.FundsAble<NeedFunds:### 资金不足
        KNum = abs(codeFees.MinOpenVolume*(((Account.FundsAble - Fees )/BaseMargin)//codeFees.MinOpenVolume))
        if KNum<codeFees.MinOpenVolume: KNum = 0 ### 小于最小开仓数量
        BSNum = math.copysign(KNum,BSNum)
        Fees = abs(BSNum) * oNEFee
        log.Warn(f"{Account.FundsAble}资金不足无法全量开仓,订单ID {codeOrder.OrderID},Qty:{codeOrder.Qty } ,OkQty:{codeOrder.OkQty} ,最大可开数量: {BSNum}")
        NeedFunds = (BSPrice +oNEFee) * abs(BSNum) 
    Account.FundsAble -= NeedFunds ### 扣除开仓资金 ###避免其他订单开仓时重复计算
    return BSNum,Fees
 

def OrderDeal_getPNum(codeOrder: OrderN,Hold: HoldN,codeFees: CodeFeesN,BSPrice: float):
    ### 获取平仓数量 
    if IsK(codeOrder.Type) or BSPrice<0:return 0,0 ### 错误 检查出是开仓订单 
    ### Hold.AblePNum = Hold.HoldNum - sum(Hold.HoldNumNDs) ### 可平数量 = 持仓数量 - 限制N天持仓 持仓数量
    if abs(codeOrder.Qty)>=abs(codeOrder.OkQty) :
        BSNum = codeOrder.Qty-codeOrder.OkQty ### 订单任务中未成交数量 = 订单数量 - 已成交数量 
    else:
        log.Error(f"订单ID {codeOrder.OrderID} 订单总量{codeOrder.Qty} 已成交数量{codeOrder.OkQty}")
        BSNum = 0 ### 订单任务中未成交数量 = 订单数量 - 已成交数量 
    if BSNum==0:return 0,0 ### 订单未成交数量为0 无法平仓
    PNum = -1* math.copysign(min(abs(Hold.AblePNum),abs(BSNum)),Hold.AblePNum) ###由持仓符号控制清仓符号
    ### 取最小值 如可平500 订单要平800 实际平500 考虑到数量带符号 还需设置符号
    oNEFee = getCloseFee(BSPrice,codeFees)
    PFees = abs(PNum) * oNEFee
    return PNum,PFees



def OrderDeal_getBSPrice(codeOrder: OrderN,Kline: KLineN,Tick: TickN =None ):
    ### 处理订单前先修改订单状态为处理中
    codeOrder.Status = OrderStatus.Processing
    codeOrder.UpdateTime = Kline.trade_time
    codeOrder.SystemTime = NowTime()
    log.Info(f"订单ID {codeOrder.OrderID} 开始处理: {Kline.trade_time}")
    ### 模拟触发订单指令
    if Tick is not None:
        BSPrice = GetOrderBSPrice_Tick(codeOrder, Tick)
    else:
        BSPrice = GetOrderBSPrice_Kline(codeOrder, Kline)
    return BSPrice

### 通过行情数据判断订单是否成交 
def GetOrderBSPrice_Kline(codeOrder: OrderN,Kline: KLineN) -> (float):
    """
    确定模拟交易价格
    """
    BSPrice = -1.0### 未触发订单
    ### 市价交易 则以K线Close 的价格成交 
    if codeOrder.Method == OrderMethod.Market:
        BSPrice = Kline.close ###市价交易 则以K线Close 的价格成交         
    elif codeOrder.Method == OrderMethod.Limit:
        if Kline.trade_time > codeOrder.CreateTime:### 首先K线时间必须大于订单时间 
            ### 如果是限价交易 则需要判断价格是否在K线范围内
            if codeOrder.Price >= Kline.low and codeOrder.Price <= Kline.high:# 价格在K线范围内
                BSPrice = codeOrder.Price
            else:
                ### 如果价格不在K线范围内  
                if IsBid(codeOrder.Type):###超过最高价的买单
                    if codeOrder.Price > Kline.high:
                        BSPrice = codeOrder.high
                if IsAsk(codeOrder.Type):### 超过最低价的卖单
                    if codeOrder.Price < Kline.low:
                        BSPrice = codeOrder.low
    return BSPrice             
    
def GetOrderBSPrice_Tick(codeOrder: OrderN,Tick: TickN) -> (float):
    """
    处理交易数据，根据持仓类型和交易方法执行订单
    """
    BSPrice = -1.0### 未触发订单
    if codeOrder.Method == OrderMethod.Market:
        ### 市价交易 则以Tick价格成交 
        BSPrice = Tick.LastPrice ###市价交易 则以Tick价格成交
    elif codeOrder.Method == OrderMethod.Limit:
        if IsAsk(codeOrder.Type):### 卖单
            if codeOrder.Price < Tick.LastPrice:
                BSPrice = Tick.LastPrice
        if IsBid(codeOrder.Type):### 买单
            if codeOrder.Price > Tick.LastPrice:
                BSPrice = Tick.LastPrice
    return BSPrice             
