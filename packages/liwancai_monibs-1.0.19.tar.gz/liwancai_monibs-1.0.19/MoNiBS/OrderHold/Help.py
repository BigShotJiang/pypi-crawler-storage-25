
def OrderHelp():
    """
    订单系统极简帮助手册（新手必看）
    调用：order_help()
    """
    helpdoc = """🤡🤡🤡\n"""
    line = "=" * 70
    helpdoc+=line
    helpdoc+="\n📘 订单系统使用帮助（通用参数 + 枚举对照表）\n"
    helpdoc+=line

    # ==================== 1. 通用参数（所有订单共用）====================
    helpdoc+="\n【1】通用参数（所有订单 KB/KS/PB/PS.. 完全一致）\n"
    helpdoc+="-" * 50
    helpdoc+="\nAccountID   : 必传，账户ID字符串,如果为None则系统默认当前主账户 如果是Code独立子账户必传对应AccountID"
    helpdoc+="\nkline       : 必传，K线数据（系统自动传入）"
    helpdoc+="\nMethod      : 可选，交易方式（默认市价=Market）"
    helpdoc+="\nPrice       : 可选，价格（仅限价单必填）"
    helpdoc+="\nQty         : 可选，数量（单位：股，默认=100）"
    helpdoc+="\n⚠ 所有订单方法参数完全通用，只需替换方法名即可"

    # ==================== 2. 支持的订单方法 ====================
    helpdoc+="\n【2】支持的订单方法（调用方式：order_hub.方法名()）\n"
    helpdoc+="-" * 50
    methods = [
        ("KB", "开多单"), ("KS", "开空单"),
        ("PB", "平多单"), ("PS", "平空单"),
        ("KBB", "开看多买方"), ("KBS", "开看多卖方"),
        ("KSB", "开看空买方"), ("KSS", "开看空卖方"),
        ("PBB", "平看多买方"), ("PBS", "平看多卖方"),
        ("PSB", "平看空买方"), ("PSS", "平看空卖方"),
    ]
    for code, desc in methods:
        helpdoc+=f"\n{code:5} {desc}"
    helpdoc+="\n"

    # ==================== 3. Method 完整对照表（核心！）====================
    helpdoc+="\n【3】Method 交易方式（支持 枚举 / 数字 / 字符串 三选一）\n"
    helpdoc+="-" * 50
    method_list = [
        ("Market", 13, "市价"),
        ("Limit", 12, "限价（需传Price）"),
        ("UpLimit", 11, "上限价/涨停价"),
        ("DwLimit", 10, "下限价/跌停价"),
        ("Buy1~Buy5", [1,2,3,4,5], "买1~买5"),
        ("Sell1~Sell5", [-1,-2,-3,-4,-5], "卖1~卖5"),
    ]
    for s, n, d in method_list:
        helpdoc+=f"\n字符串:{s:<10} 数字:{str(n):<8} 中文:{d}"

    # ==================== 4. 通用示例 ====================
    helpdoc+="\n【4】通用调用示例（所有订单都这么写）\n"
    helpdoc+="-" * 50
    helpdoc+="\n# 最简写法（默认市价，100股）"
    helpdoc+="\norder_hub.KB('ACC001', kline)"
    helpdoc+="\n# 完整写法（限价单）:"
    helpdoc+="\norder_hub.KB("
    helpdoc+="\n    AccountID='ACC001',"
    helpdoc+="\n    kline=kline,"
    helpdoc+="\n    Method='Limit',  # 字符串/数字/枚举都可以"
    helpdoc+="\n    Price=10.5,"
    helpdoc+="\n    Qty=200"
    helpdoc+="\n    )"

    # ==================== 5. 数量单位 ====================
    helpdoc+="\n【5】数量与规则\n"
    helpdoc+="-" * 50
    helpdoc+="\nQty 单位 : 股（A股 100股=1手，默认值=100）"
    helpdoc+="\nMethod   : 不传则自动使用【市价单】"
    helpdoc+="\nPrice    : 仅限价单必填，其他方式无需传参\n"

    helpdoc+=line
    helpdoc+="\n✅ 记住：所有订单参数完全一样，只需改 KB/KS/PB/PS 即可！\n"
    helpdoc+=line
    return helpdoc
