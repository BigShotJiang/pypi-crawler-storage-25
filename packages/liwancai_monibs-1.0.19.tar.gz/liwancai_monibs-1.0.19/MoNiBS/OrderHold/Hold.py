from dataclasses                     import dataclass
from enum                            import IntEnum
from .Type                           import BSType
from ..utils.DataType                import KLineN
 

class HoldType(IntEnum):
    NH  = 0     # 持仓 无
    HS  = 1     # 持有 空单 S
    HB  = 2     # 持有 多单 B
    HSS = 3     # 持有 看空卖方 S
    HSB = 4     # 持有 看空买方 B
    HBS = 5     # 持有 看多卖方 S
    HBB = 6     # 持有 看多买方 B

# 字符串到枚举的映射
HoldTypeMap = {
    "NH":  HoldType.NH,  # 持仓 无
    "HS":  HoldType.HS,  # 持有 空单 S
    "HB":  HoldType.HB,  # 持有 多单 B
    "HSS": HoldType.HSS, # 持有 看空卖方 S
    "HSB": HoldType.HSB, # 持有 看空买方 B
    "HBS": HoldType.HBS, # 持有 看多卖方 S
    "HBB": HoldType.HBB, # 持有 看多买方 B
    
}

# 枚举到字符串的映射
HoldTypeString = {
    HoldType.NH:  "NH",
    HoldType.HS:  "HS",
    HoldType.HB:  "HB",
    HoldType.HSS: "HSS",
    HoldType.HSB: "HSB",
    HoldType.HBS: "HBS",
    HoldType.HBB: "HBB",
   
}

# 枚举到描述的映射
HoldTypeDesc = {
    HoldType.NH:  "持仓 清仓",
    HoldType.HB:  "持仓 多单 B",
    HoldType.HS:  "持仓 空单 S",
    HoldType.HSS: "持仓 看空卖方 S",
    HoldType.HSB: "持仓 看空买方 B",
    HoldType.HBS: "持仓 看多卖方 S",
    HoldType.HBB: "持仓 看多买方 B",
}



@dataclass
class HoldN:
    Code: str               ### *代码 
    AccountID: str          ### *账户ID
    HoldType: HoldType      ### *持仓类型
    HoldNum: float          ### 持仓数量(累计总数) 该属性减去HoldNumNDs中的元素就是可平数量
    ###HoldNumNDs：N天持仓 持仓数量 [REF0DaysHold,..,REF5DaysHold,..]
    ###处理逻辑很简单:依据交易日的变化来更新列表 限制列表长度 BSTNum 只保留BSTNum长度的持仓数量就是限制交易的持仓
    HoldNumNDs: list[float] 
    BSTDNum: int            ### T+N 交易模式 由订单传递给持仓属性 0:t+0 1:t+1 2:t+2 .. 10:t+10
    HoldCost: float         ### 持仓成本
    HoldFunds: float        ### 持仓资金
    AblePNum: float         ### 可平数量

    EarnSum: float          ### 清仓交易 时刻的 结算盈亏 汇总完毕后清零
    HoldEarn: float        ### 未清仓时的浮动盈亏 清仓交易后清零
    FeesSum: float          ### 持仓期间手续费总和
    BSFees: float           ### 交易产生 时刻的 手续费 汇总完毕后清零
    TradeTime: str          ### 最新交易时间(K线数据提供更新)
    TradeDate: str          ### 最新交易日期(K线数据提供更新)
    UpdateTime: str         ### 最新更新时间(K线数据提供更新)
    CreateTime: str         ### 初次建仓时间
    Price: float            ### 最新市场价格
    Hfq: float              ### 后复权因子用于对齐配股分红
### 交易类型到持仓类型的映射
def BSType2HoldType(BSType: BSType) -> HoldType|None:
    """
    将交易类型转换为持仓类型
    """
    if  BSType > 6 or BSType<1: return None
    return HoldType(BSType)

def Hold(AccountID:str,Kline:KLineN,BSType:BSType,BSTDNum:int=0, **kwargs):
    hold =  HoldN(
            Code        = Kline.code,
            AccountID   = AccountID,### 必须明确由哪一个账户的资金开仓
            HoldType    = BSType2HoldType(BSType),
            HoldNum     = 0.0,
            HoldNumNDs  = [],
            BSTDNum     = BSTDNum,
            HoldCost    = 0.0,
            HoldFunds   = 0.0,
            AblePNum    = 0.0,
            EarnSum     = 0.0,
            HoldEarn    = 0.0,
            FeesSum     = 0.0,
            BSFees      = 0.0,
            Price       = Kline.close,### 最新市场价格
            Hfq         = Kline.hfq,
            TradeTime   = Kline.trade_time ,### 最新交易时间(K线数据提供更新)
            TradeDate   = Kline.trade_date ,### 最新交易日期(K线数据提供更新)
            UpdateTime  = Kline.trade_time ,### 最新更新时间(K线数据提供更新)
            CreateTime  = Kline.trade_time ,### 初次建仓时间(K线数据提供更新)
            
            )
    if kwargs:### 处理kwargs参数
        for key, value in kwargs.items(): 
            if hasattr(hold, key):setattr(hold, key, value)
    return hold
