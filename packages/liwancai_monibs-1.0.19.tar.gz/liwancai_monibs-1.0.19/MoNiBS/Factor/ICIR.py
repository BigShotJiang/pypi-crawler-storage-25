from LOG                                    import log
import pandas                               as pd
import numpy                                as np
from scipy                                  import stats
from typing                                 import List, Dict, Optional, Union, Any, Tuple
# ===================== 4. 计算IC函数（单交易日） =====================
def OneDay_IC(
    data: pd.DataFrame,
    trade_date: Union[str, int],
    factor_col: str = 'HLPer1',    #因子列名（同去极值、中性化、标准化的factor_col）      
    return_cols: List[str] = ['REBChgPer20'],
    group_num: int = 10,
    has_winsor=True, has_neutral=True, has_std=True,code_col: str = 'code',   
    prev_group_dict: Dict[str, int] = None,  # 前一日分组标签，index为股票代码
    ) -> Tuple[List[Dict[str, Any]], Optional[pd.Series]]:
    """
    单个交易日的完整因子分析输出
    """
    if data.empty:
        log.Warn(f"交易日{trade_date}数据为空")
        return [], {}

    if code_col not in data.columns:
        log.Error(f"{data.columns}数据缺少股票代码列: {code_col}")
        return [], {}
 
    # 确定最终使用的因子列
    target_col = factor_col
    if has_winsor:
        winsor_col = f'{target_col}_winsor'
        if winsor_col in data.columns:
            target_col = winsor_col
        else:
            log.Warn(f"交易日{trade_date}_winsor：未找到{winsor_col}列，将使用{factor_col}列")
    
    if has_neutral: 
        neutral_col = f'{target_col}_neutral'
        if neutral_col in data.columns:
            target_col = neutral_col
        else:
            log.Warn(f"交易日{trade_date}_neutral：未找到{neutral_col}列，将使用{target_col}列")
    if has_std:
        std_col = f'{target_col}_std'
        if std_col in data.columns:
            target_col = std_col
        else:
            log.Warn(f"交易日{trade_date}_std：未找到{std_col}列，将使用{target_col}列")

    results = []
    curr_groups_dict = prev_group_dict
    # ---------- 1. 统一过滤基础有效样本（因子值非空 + 总市值>0） ----------
    base_valid_mask = (  data[target_col].notna() & (data.get('total_mv', 1) > 0) )
    df_base_valid = data[base_valid_mask].copy()
    base_valid_num = len(df_base_valid)### 有效样本数（基础有效样本 + 收益率非空）
    if base_valid_num < 100:
        log.Warn(f"交易日{trade_date} 基础有效样本数 {base_valid_num} < 100，跳过IC计算")
        return [], curr_groups_dict
    baserst = {
            'trade_date': trade_date,
            'factor_col': factor_col,
            'target_col': target_col,
            'group_num': group_num,
            'base_valid_num': base_valid_num,
            'factor_mean': df_base_valid[factor_col].mean(),### 因子值均值
            'factor_median': df_base_valid[factor_col].median(),### 因子值中位数
            'factor_quantile_1025507590': df_base_valid[factor_col].quantile([0.1,0.25,0.5,0.75,0.90]).to_dict()
            }
    # ---------- 2. 统一生成当日分组（所有收益率列共用） ----------
 
    # 尝试 qcut 分组，若失败则降级为等频分组
    # - pd.qcut默认行为 ：按数值 从小到大 自动分箱
    # - 组号分配 ：因子值最小的股票分到组0，最大的分到组9
    try:
        df_base_valid['group'] = pd.qcut(
                        df_base_valid[target_col],
                        q=group_num,
                        labels=False,
                        duplicates='raise'  # 先严格检测，失败再降级
                    )
    except Exception as e:
        log.Info(f"交易日{trade_date} qcut 降级为等频分组: {e}")
        df_base_valid = df_base_valid.sort_values(target_col)  # 按因子值排序（默认升序）
        df_base_valid['group'] = np.floor(np.linspace(0, group_num, len(df_base_valid), endpoint=False)).astype(int)
    # 存储当日分组标签（所有收益率列共用）
    curr_groups_dict = df_base_valid.set_index(code_col)['group'].to_dict()
    # ===================== 遍历每个收益率列 =====================
    for return_col in return_cols:
        # ---------- 1. 过滤该收益率列的有效样本（基础有效样本 + 收益率非空） ----------
        if base_valid_num >= 100:
            # 在统一分组的基础上，过滤该收益率列非空的样本
            valid_mask = df_base_valid[return_col].notna()&(df_base_valid[return_col]!=-9999)
            df_valid = df_base_valid[valid_mask].copy()
            valid_num = len(df_valid)
        else:
            # 基础样本不足时，直接标记为无效
            df_valid = pd.DataFrame()
            valid_num = 0
        # ---------- 2. 计算 IC（基于该收益率列的有效样本） ----------
        if valid_num < 2:
            rank_ic, p_value = np.nan, np.nan
        else:
            rank_ic, p_value = stats.spearmanr(df_valid[target_col], df_valid[return_col])### 秩相关系数 
        # ---------- 3. 计算各组收益（复用统一分组） ----------
        if df_valid.empty:
            group_totalmv = {}
            group_close = {}
            group_returns = {}
            group_counts = {}
            GroupCodes = {}
        else:
            # 计算各组平均收益和股票数量
            group_totalmv   = df_valid.groupby('group')['total_mv'].mean()
            group_close     = df_valid.groupby('group')['close'].mean()
            group_returns   = df_valid.groupby('group')[return_col].mean()
            group_counts    = df_valid.groupby('group').size()
            GroupCodes      = df_valid.groupby('group')[code_col].apply(list)
        # ---------- 4. 计算换手率（基于统一分组） ----------
        turnover        = {}
        REFGroupCodes   = {}
        if not df_valid.empty and prev_group_dict:  # 检查字典是否为空
            df_valid['prev_group'] = df_valid[code_col].map(prev_group_dict)
            REFGroupCodes = df_valid.groupby('prev_group')[code_col].apply(list)
            df_valid['changed'] = df_valid['group'] != df_valid['prev_group']
            NT1 = df_valid.groupby('group').size()
            REFNT1 = df_valid.groupby('prev_group').size()
            NChgNT = df_valid[df_valid['changed']==False].groupby('group').size()
            for group in range(group_num):
                NChgNT_Num = NChgNT.get(group,0)
                SumNTG = ((REFNT1.get(group,0) + NT1.get(group,0))/2)
                turnover[group] = ((NT1.get(group,0)-NChgNT_Num )+ (REFNT1.get(group,0) -NChgNT_Num)) / SumNTG if SumNTG != 0 else 0
        ### 汇总合并数据
        return_col_rst = {
            **baserst,
            'return_col': return_col,
            'valid_num': valid_num,
            'rank_ic': rank_ic,
            'p_value': p_value,
            'group_totalmv_mean': dict(group_totalmv),           # 创建新字典
            'group_close_mean': dict(group_close),               # 创建新字典
            'group_returns_mean': dict(group_returns),           # 创建新字典
            'group_counts': dict(group_counts),                  # 创建新字典
            'turnover': turnover,
            'GroupCodes': dict(GroupCodes),
            'REFGroupCodes': dict(REFGroupCodes),
        }
        results.append(return_col_rst)
    return results, curr_groups_dict
def format_p_value(p_val):
    if pd.isna(p_val):
        return "N/A"
    elif p_val < 0.0001:
        return f"{p_val:.2e}"  # 科学计数法
    else:
        return f"{p_val:.6f}"  # 常规小数

 
def OneReturnCol_ICIR(df,p_value:float = 0.05):
    # 数据校验：确保关键列存在
    required_cols = ['trade_date', 'rank_ic', 'p_value','return_col']
    if not all(col in df.columns for col in required_cols):
        raise ValueError(f"DataFrame必须包含列：{required_cols}")
    # 去重：按交易日去重（避免同一交易日多条记录重复统计）
    df_unique = df.drop_duplicates(subset=['trade_date']).copy()
    factor_col = df_unique['factor_col'].iloc[0]
    return_col = df_unique['return_col'].iloc[0]
    target_col = df_unique['target_col'].iloc[0]
    # 1. 核心IC指标计算（保留精度，补充年化IR）
    ic_series = df_unique['rank_ic']
    ic_mean = ic_series.mean()  # 平均IC
    ic_std = ic_series.std()    # IC标准差
    ic_ir = ic_mean / ic_std if ic_std != 1e-8 else np.nan  # 避免除以0（用1e-8容错）
    ic_ir_annual = ic_ir * np.sqrt(252) if not np.isnan(ic_ir) else np.nan  # 年化IR（252个交易日）
    
    # 2. 双向胜率统计（区分正负零IC，零IC用1e-8精度判断，避免浮点误差）
    total_days = len(df_unique)
    ic_negative_count = len(df_unique[ic_series < -1e-8])  # 负IC天数
    ic_positive_count = len(df_unique[ic_series > 1e-8])  # 正IC天数
    ic_zero_count = total_days - ic_negative_count - ic_positive_count  # 零IC天数（兜底计算更准确）
    
    # 3. 显著IC统计（p值<阈值 且 IC方向显著）
    sig_neg_mask = (df_unique['p_value'] < p_value) & (ic_series < -1e-8)
    sig_pos_mask = (df_unique['p_value'] < p_value) & (ic_series > 1e-8)
    significant_negative_count = len(df_unique[sig_neg_mask])  # 显著负IC天数
    significant_positive_count = len(df_unique[sig_pos_mask])  # 显著正IC天数
    
    # 4. 增强指标：胜率（正IC占比）、IC绝对值均值（更贴合因子有效性）
    # win_rate = ic_positive_count / total_days if total_days > 0 else 0  # 正IC胜率
    ic_abs_mean = abs(ic_series).mean()  # IC绝对值均值（衡量因子整体相关性强度）
    
    # 先准备每日 P_VALUE 列表：p_values = [每日计算的p_value值]
    p_mean = np.mean(df_unique['p_value'])  # 所有交易日P值均值（越小越优）
    p_median = np.median(df_unique['p_value'])  # P值中位数（比均值更稳健）
    p_less_005_ratio = sum(1 for p in df_unique['p_value'] if p < 0.05) / total_days  # 整体显著率
    p_less_001_ratio = sum(1 for p in df_unique['p_value'] if p < 0.01) / total_days  # 高显著率（可选）

    # 检验平均IC绝对值是否显著 > 0.02
    # 1. 做t检验：检验是否显著≠0
    t_stat, abs_IC_p_value = stats.ttest_1samp(
                                                np.abs(df_unique['rank_ic']),  # 取IC绝对值
                                                popmean=0.02,                  # 检验是否显著大于0.02
                                                alternative='greater'          # 单边检验：大于
                                                )
    # 5. 结果汇总（完全保留原格式，补充增强指标）
    rstdata = {
        '因子': factor_col,
        '执行因子': target_col,
        'N周期收益': return_col,
        '平均IC': f"{ic_mean:.4f} ({ic_mean:.2%})",
        '整体IC显著性P值(t检验:ic绝对值>0.02P值)': f"{format_p_value(abs_IC_p_value)}",  # 核心新增 
        '整体IC是否显著': '是' if abs_IC_p_value < 0.05 else '否',  # 辅助判断
        'IC绝对值均值': f"{ic_abs_mean:.4f} ({ic_abs_mean:.2%})",  # 新增：更易判断因子强度
        'IC标准差': f"{ic_std:.4f} ({ic_std:.2%})",
        'IC_IR': f"{ic_ir:.4f}",
        '年化IC_IR': f"{ic_ir_annual:.4f}",  # 新增：年化IR（行业通用）
        '负IC占比': f"{ic_negative_count/total_days:.2%}",
        '正IC占比(胜率)': f"{ic_positive_count/total_days:.2%}",  # 标注胜率更直观
        '零IC占比': f"{ic_zero_count/total_days:.2%}",
        f'显著负IC占比(p<{p_value:.2f})': f"{significant_negative_count/total_days:.2%}",
        f'显著正IC占比(p<{p_value:.2f})': f"{significant_positive_count/total_days:.2%}",
        'P值均值': f"{p_mean:.4f}",  # 越小说明整体越显著
        'P值中位数': f"{p_median:.4f}",  # 避免极值干扰，更靠谱
        '整体显著率(p<0.05)': f"{p_less_005_ratio:.2%}",  # 所有交易日中显著的比例
        '高显著率(p<0.01)': f"{p_less_001_ratio:.2%}",
        '总有效交易日数': total_days,
        '负IC交易日数': ic_negative_count,
        '正IC交易日数': ic_positive_count,
        '零IC交易日数': ic_zero_count,
        '显著负IC交易日数': significant_negative_count,
        '显著正IC交易日数': significant_positive_count
    }
    
    return rstdata