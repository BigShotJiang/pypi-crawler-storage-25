from LOG                                    import log
from sklearn.linear_model                   import LinearRegression
import pandas                               as pd
import numpy                                as np
 
def Factor_PreProcess( df, factor='HLPer1',cfg=None):
    '''
    因子预处理
    cfg ={
        'do_winsor' : {"mathed":"MADWIN","arges":{"k":5, "lower_quantile":0.01, "upper_quantile":0.99}}, ### 去极值方法：MAD、WIN、MADWIN
        'do_neutral': {"mathed":"INDCAP"}, ### 中性化方法：行业+市值、行业、市值 
        'do_std': True}
    '''
    # 默认配置
    default_cfg = {
        'do_winsor' : {"mathed":"MADWIN","arges":{"k":5, "lower_quantile":0.01, "upper_quantile":0.99}}, ### 去极值方法：MAD、WIN、MADWIN
        'do_neutral': {"mathed":"INDCAP"}, ### 中性化方法：行业+市值、行业、市值 
        'do_std': True
    }
    if cfg is None:  cfg = {}
    final_cfg = {**default_cfg, **cfg}
    
    # 步骤1：去极值
    if final_cfg['do_winsor']:
        COND_MAD =  "MAD" in final_cfg['do_winsor']['mathed'].upper()
        COND_WIN =  "WIN" in final_cfg['do_winsor']['mathed'].upper()
        if COND_MAD and COND_WIN:
            df = 去极值_MADWIN(df, factor_col=factor, cfg=final_cfg['do_winsor']['arges'])### 基于MAD和WIN的去极值（3倍MAD+1%/99%分位数缩尾）
        elif COND_MAD:
            df = 去极值_MAD(df, factor_col=factor, cfg=final_cfg['do_winsor']['arges'])### 基于MAD的去极值（3倍MAD）
        elif COND_WIN:
            df = 去极值_WIN(df, factor_col=factor, cfg=final_cfg['do_winsor']['arges'])### 百分比去极值（1%/99%分位数缩尾）
    
    # 步骤2：中性化
    if final_cfg['do_neutral']:
        mathed = final_cfg['do_neutral']['mathed'].upper()
        COND_IND = "IND" in mathed or "行业" in mathed
        COND_CAP = "CAP" in mathed or "市值" in mathed
        if COND_IND and COND_CAP:
            df = 行业_市值中性化(df, factor_col=factor, has_winsor=final_cfg['do_winsor'])
        elif COND_IND:
            df = 行业中性化(df, factor_col=factor, has_winsor=final_cfg['do_winsor'])
        elif COND_CAP:  # 市值
            df = 市值中性化(df, factor_col=factor, has_winsor=final_cfg['do_winsor'])
    
    # 步骤3：标准化
    if final_cfg['do_std']:
        df = 标准化(df, factor_col=factor, 
                   has_winsor =final_cfg['do_winsor'], 
                   has_neutral=final_cfg['do_neutral'])
    
    return df



# ===================== 1. 去极值函数（1%/99%分位数缩尾，机构标准） =====================
def 去极值_MADWIN(df, factor_col, cfg={"k":5, "lower_quantile":0.01, "upper_quantile":0.99}, suffix='_winsor'):
    """
    对单个交易日的因子依次进行MAD去极值和百分比去极值（先MAD后百分比）
    
    Parameters
    ----------
    df : pd.DataFrame
        单个交易日的原始DataFrame
    factor_col : str
        需要去极值的因子列名
    k : float, default 5
        MAD的倍数参数，通常取3~5
    lower_quantile : float, default 0.01
        下分位数（例如0.01代表1%）
    upper_quantile : float, default 0.99
        上分位数（例如0.99代表99%）
    suffix : str, default '_winsor'
        新列名的后缀，最终列名为 factor_col + suffix
    Returns
    -------
    pd.DataFrame
        原DataFrame新增一列 factor_col + suffix，内容为去极值后的因子值
    """
    # 复制一份以免修改原df（但原df通常不会在函数内被修改，这里为了安全可copy，但大数据量时慎用）
    df = df.copy()
    
    # --- 1. MAD去极值（中间结果）---
    # 提取有效值：排除-9999和NaN（只用于计算上下限）
    valid_vals = df[factor_col][(df[factor_col] != -9999) & (df[factor_col].notna())]
    
    if len(valid_vals) <= 1:
        # 如果有效数据太少，直接返回原列
        df[factor_col + suffix] = df[factor_col]
        return df
    
    median = valid_vals.median()
    mad = np.median(np.abs(valid_vals - median))
    
    if mad == 0:
        # 所有有效值相同，MAD为0，则跳过MAD步骤，直接使用原列
        mad_winsor_vals = df[factor_col]
    else:
        lower_mad = median - cfg.get('k', 4) * mad
        upper_mad = median + cfg.get('k', 4) * mad
        # 只对有效值进行clip，无效值（-9999或NaN）保持原样
        mad_winsor_vals = df[factor_col].copy()
        mask = (df[factor_col] != -9999) & (df[factor_col].notna())
        mad_winsor_vals.loc[mask] = df.loc[mask, factor_col].clip(lower=lower_mad, upper=upper_mad)
    
    # --- 2. 百分比去极值（基于MAD处理后的中间值）---
    # 注意：此时仍用有效值（排除-9999和NaN）来计算分位数，但中间值已经过MAD缩尾
    valid_after_mad = mad_winsor_vals[(mad_winsor_vals != -9999) & (mad_winsor_vals.notna())]
    
    if len(valid_after_mad) <= 1:
        # 有效数据太少，直接使用mad_winsor_vals作为最终结果
        df[factor_col + suffix] = mad_winsor_vals
        return df
    
    q1 = valid_after_mad.quantile(cfg.get('lower_quantile', 0.01), interpolation='nearest')
    q99 = valid_after_mad.quantile(cfg.get('upper_quantile', 0.99), interpolation='nearest')
    
    # 再次只对有效值进行clip
    final_vals = mad_winsor_vals.copy()
    mask2 = (final_vals != -9999) & (final_vals.notna())
    final_vals.loc[mask2] = mad_winsor_vals.loc[mask2].clip(lower=q1, upper=q99)
    
    df[factor_col + suffix] = final_vals
    return df
 

def 去极值_MAD(df, factor_col, cfg={"k":5}):
    """
    对单个交易日的因子进行MAD（中位数绝对偏差）去极值（保留-9999和NaN）
    :param df: 单个交易日的原始DataFrame
    :param factor_col: 需要去极值的因子列名
    :param k: 倍数（通常取3，严格点取4）
    :return: 新增去极值后的因子列（列名：factor_col + '_winsor'）
    """
    # 复制原数据，避免修改传入的DataFrame
    df = df.copy()

    # 1. 获取有效值的掩码（既不是-9999也不是NaN）
    valid_mask = (df[factor_col] != -9999) & (df[factor_col].notna())
    valid_series = df.loc[valid_mask, factor_col]
    
    # 极端情况：有效数据为空或只有1个值，直接填充原数值
    if len(valid_series) <= 1:
        df[f'{factor_col}_winsor'] = df[factor_col]
        return df
    
    # 2. MAD核心计算
    median = valid_series.median()
    mad = np.median(np.abs(valid_series - median))
    
    # 极端情况：MAD为0（所有有效值相同），直接返回原数值
    if mad == 0:
        df[f'{factor_col}_winsor'] = df[factor_col]
        return df
    
    # 3. 计算上下限
    lower_bound = median - cfg.get('k', 4) * mad
    upper_bound = median + cfg.get('k', 4) * mad
    
    # 4. 缩尾处理：仅对有效值进行clip，其他值（-9999和NaN）保持不变
    df[f'{factor_col}_winsor'] = df[factor_col]  # 先复制原列
    df.loc[valid_mask, f'{factor_col}_winsor'] = df.loc[valid_mask, factor_col].clip(
        lower=lower_bound, upper=upper_bound
    )
    
    # 5. 无需额外填充NaN，因为NaN在clip后仍为NaN，原列NaN已在复制中保留
    return df


def 去极值_WIN(df, factor_col, cfg={ "lower_quantile":0.01, "upper_quantile":0.99}):
    """
    对单个交易日的因子进行截面去极值（分位数缩尾），保留-9999和NaN
    :param df: 单个交易日的原始DataFrame
    :param factor_col: 需要去极值的因子列名
    :param lower_quantile: 下分位数，默认0.01
    :param upper_quantile: 上分位数，默认0.99
    :return: 新增去极值后的因子列（列名：factor_col + '_winsor'）
    """
    df = df.copy()

    # 有效值掩码
    valid_mask = (df[factor_col] != -9999) & (df[factor_col].notna())
    valid_series = df.loc[valid_mask, factor_col]
    
    if len(valid_series) <= 1:
        df[f'{factor_col}_winsor'] = df[factor_col]
        return df
    
    # 计算分位数
    q_low = valid_series.quantile(cfg.get('lower_quantile', 0.01), interpolation='nearest')
    q_high = valid_series.quantile(cfg.get('upper_quantile', 0.99), interpolation='nearest')
    
    # 缩尾处理：仅对有效值进行clip
    df[f'{factor_col}_winsor'] = df[factor_col]
    df.loc[valid_mask, f'{factor_col}_winsor'] = df.loc[valid_mask, factor_col].clip(
        lower=q_low, upper=q_high
    )
    
    return df

# ===================== 2. 行业+市值中性化函数（截面回归取残差） =====================
def 行业_市值中性化(df, ### 数据
    factor_col,### 原始因子列名
    TotalMV_col='total_mv', ### 总市值列名，默认'total_mv'
    Industry_col='industry', ### 行业列名，默认'industry' 一级行业
    has_winsor=True,### 是否优先使用去极值后的因子列（{factor_col}_winsor）
    min_samples=100### 最小有效样本数，低于此值时中性化列填充NaN
    ):
    # 确定要标准化的列（优先用去极值后的列）
    target_col = factor_col
    if has_winsor:
        winsor_col = f'{target_col}_winsor'
        if winsor_col not in df.columns:
            log.Info(f"警告：未找到{winsor_col}列，将使用{target_col}列中性化")
        else:
            target_col = winsor_col

    # 过滤有效数据（剔除NaN、市值<=0，保证回归有效性）
    valid_mask = (
        df[target_col].notna() &          # 因子值非空
        df[TotalMV_col].notna() &         # 市值非空
        df[Industry_col].notna() &        # 行业非空
        (df[TotalMV_col] > 0)             # 市值>0
    )
    df_valid = df[valid_mask].copy()
    # 若有效样本<100，返回原数据（避免伪回归，中性化列填充NaN）
    if len(df_valid) < min_samples:
        df[f'{target_col}_neutral'] = np.nan
        return df
    # 1. 计算对数市值（市值中性化核心，线性化市值的非线性影响）
    df_valid['log_mv'] = np.log(df_valid[TotalMV_col])
    # 2. 行业哑变量（one-hot编码，剔除第一列避免共线性）
    industry_dummies = pd.get_dummies(df_valid[Industry_col], drop_first=True)
    # 3. 构建回归矩阵（行业哑变量 + 对数市值）  // 若市值列与因子列相同，仅用行业哑变量
    X = pd.concat([industry_dummies, df_valid[['log_mv']]], axis=1) if TotalMV_col!=factor_col else industry_dummies
    y = df_valid[target_col]
    # 4. 线性回归取残差（残差=真实值 - 行业+市值解释的部分，即中性化结果）
    lr = LinearRegression(fit_intercept=True)
    lr.fit(X, y)
    df_valid[f'{target_col}_neutral'] = y - lr.predict(X)
    
    # 5. 将中性化结果合并回原数据（无效样本仍为NaN）
    df = df.merge(
        df_valid[[f'{target_col}_neutral']],
        left_index=True, right_index=True,
        how='left'
    )
    # 清理临时列
    if 'log_mv' in df.columns:df.drop('log_mv', axis=1, inplace=True)
    return df
 
def 市值中性化(df, factor_col, TotalMV_col='total_mv', has_winsor=True, min_samples=100):
    """
    对因子进行市值中性化（去除市值影响）
    
    Parameters
    ----------
    df : DataFrame
        包含因子、市值等字段的数据
    factor_col : str
        原始因子列名
    TotalMV_col : str
        总市值列名，默认'total_mv'
    has_winsor : bool
        是否优先使用去极值后的因子列（{factor_col}_winsor）
    min_samples : int
        最小有效样本数，低于此值时中性化列填充NaN
    
    Returns
    -------
    DataFrame
        添加了市值中性化结果列（列名：{factor_col}_neutral 或 {factor_col}_winsor_neutral）
    """
    # 确定要中性化的目标列（优先使用去极值后的列）
    target_col = factor_col
    if has_winsor:
        winsor_col = f'{target_col}_winsor'
        if winsor_col not in df.columns:
            print(f"警告：未找到{winsor_col}列，将使用{target_col}列进行市值中性化")
        else:
            target_col = winsor_col

    # 过滤有效数据（因子值、市值非空且市值>0）
    valid_mask = (
        df[target_col].notna() &
        df[TotalMV_col].notna() &
        (df[TotalMV_col] > 0)
    )
    df_valid = df[valid_mask].copy()

    # 若有效样本不足，直接返回全NaN的中性化列
    if len(df_valid) < min_samples:
        df[f'{target_col}_neutral'] = np.nan
        return df

    # 计算对数市值，作为回归自变量
    df_valid['log_mv'] = np.log(df_valid[TotalMV_col])

    # 市值中性化：因子 ~ 对数市值（含截距），取残差
    X = df_valid[['log_mv']]
    y = df_valid[target_col]
    lr = LinearRegression(fit_intercept=True)
    lr.fit(X, y)
    df_valid[f'{target_col}_neutral'] = y - lr.predict(X)

    # 将结果合并回原DataFrame
    df = df.merge(
        df_valid[[f'{target_col}_neutral']],
        left_index=True, right_index=True,
        how='left'
    )
    # 清理临时列
    if 'log_mv' in df.columns:
        df.drop('log_mv', axis=1, inplace=True)
    return df


def 行业中性化(df, factor_col, Industry_col='industry', has_winsor=True, min_samples=100):
    """
    对因子进行行业中性化（去除行业影响）
    
    Parameters
    ----------
    df : DataFrame
        包含因子、行业等字段的数据
    factor_col : str
        原始因子列名
    Industry_col : str
        行业列名，默认'industry'
    has_winsor : bool
        是否优先使用去极值后的因子列（{factor_col}_winsor）
    min_samples : int
        最小有效样本数，低于此值时中性化列填充NaN
    Returns
    -------
    DataFrame
        添加了行业中性化结果列（列名：{factor_col}_neutral 或 {factor_col}_winsor_neutral）
    """
    # 确定要中性化的目标列
    target_col = factor_col
    if has_winsor:
        winsor_col = f'{target_col}_winsor'
        if winsor_col not in df.columns:
            print(f"警告：未找到{winsor_col}列，将使用{target_col}列进行行业中性化")
        else:
            target_col = winsor_col

    # 过滤有效数据（因子值、行业非空）
    valid_mask = (
        df[target_col].notna() &
        df[Industry_col].notna()
    )
    df_valid = df[valid_mask].copy()

    if len(df_valid) < min_samples:
        df[f'{target_col}_neutral'] = np.nan
        return df

    # 生成行业哑变量（drop_first避免多重共线性）
    industry_dummies = pd.get_dummies(df_valid[Industry_col], drop_first=True)

    # 行业中性化：因子 ~ 行业哑变量（含截距），取残差
    X = industry_dummies
    y = df_valid[target_col]
    lr = LinearRegression(fit_intercept=True)
    lr.fit(X, y)
    df_valid[f'{target_col}_neutral'] = y - lr.predict(X)

    # 合并结果
    df = df.merge(
        df_valid[[f'{target_col}_neutral']],
        left_index=True, right_index=True,
        how='left'
    )
    return df
def 标准化(df, factor_col, has_winsor=True,has_neutral=True):
    """
    对单个交易日的因子数据进行标准化（Z-score）
    """
    target_col = factor_col
    # 确定要标准化的列（优先用去极值后的列）
    if has_winsor:
        winsor_col = f'{target_col}_winsor'
        if winsor_col not in df.columns:
            log.Info(f"警告：未找到{winsor_col}列，将使用{target_col}列")
        else:
            target_col = winsor_col
    if has_neutral: 
        neutral_col = f'{target_col}_neutral'
        if  neutral_col not in df.columns:
            log.Info(f"警告：未找到{neutral_col}列，将使用{target_col}列标准化")
        else: target_col = neutral_col

    # 计算该交易日因子的均值和标准差
    std_val  = df[target_col].std()
    mean_val = df[target_col].mean()
    
    # 标准化核心逻辑（避免除0）
    if std_val == 0 :
        # 所有值相同，标准化后全为0
        df[f'{target_col}_std'] = 0
    else:
        df[f'{target_col}_std'] = (df[target_col] - mean_val) / std_val
    return df