# -*- coding: utf-8 -*-
"""
策略元数据查询API
提供策略列表、数据库名、表名查询接口
"""
from pydantic                import BaseModel
from fastapi                 import APIRouter, HTTPException, Depends
from .                       import GetConBase

base_router = APIRouter()
# ========================= 请求体模型 =========================
class DBNamesQuery(BaseModel):
    """数据库名查询请求体"""
    strategy_name: str
class TblNamesQuery(BaseModel):
    """表名查询请求体"""
    strategy_name: str
    db_name: str
# ========================= 接口实现函数 =========================
@base_router.get("/strategies")
def get_strategy_names(conbase = Depends(GetConBase)):
    """
    获取所有策略名称列表
    返回系统中所有可用的回测策略名称
    """
    try:
        strategies = conbase.getStrategyNames()
        return  strategies
    except Exception as e:
        raise HTTPException(500, detail=f"获取策略列表失败: {str(e)}")


@base_router.post("/dbnames")
def get_db_names(query: DBNamesQuery, conbase = Depends(GetConBase)):
    """
    根据策略名查询该策略数据库中的所有数据库名（schema）
    用于后续接口的db_name参数
    """
    try:
        conn = conbase.connect(query.strategy_name)
        db_names = conbase.getDBNames(conn)
        conn.Close()
        return db_names
    except Exception as e:
        raise HTTPException(500, detail=f"获取数据库名失败: {str(e)}")

@base_router.post("/tblnames")
def get_tbl_names(query: TblNamesQuery, conbase = Depends(GetConBase)):
    """
    根据策略名和数据库名查询该数据库中的所有表名
    用于后续接口的tbl_name参数
    """
    try:
        conn = conbase.connect(query.strategy_name)
        tbl_names = conbase.getTblNames(conn, query.db_name)
        conn.Close()
        return tbl_names
    except Exception as e:
        raise HTTPException(500, detail=f"获取表名失败: {str(e)}")

 