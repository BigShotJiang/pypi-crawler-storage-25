# -*- coding: utf-8 -*-
"""
MoNiBS WebApi 模块
"""

from .DBConBase import DBConBase

# 全局数据库实例，由主应用初始化
_ConBase: DBConBase = None
_Initialized: bool = False


def InitDBConBase(cfg: dict) -> DBConBase:
    """
    初始化数据库连接，在主应用启动时调用一次
    """
    global _ConBase, _Initialized
    _ConBase = DBConBase(cfg)
    _Initialized = True
    return _ConBase


def GetConBase() -> DBConBase:
    """
    安全获取数据库连接实例
    如果未初始化会抛出清晰的错误
    """
    if not _Initialized or _ConBase is None:
        raise RuntimeError(
            "ConBase 尚未初始化！"
            "请在主应用启动时先调用 InitDBConBase(config)"
        )
    return _ConBase


# 保持向后兼容：ConBase 属性访问时检查初始化状态
class _ConBaseProxy:
    """ConBase 代理类，延迟检查初始化状态"""

    def __getattr__(self, name):
        if not _Initialized or _ConBase is None:
            raise RuntimeError(
                "ConBase 尚未初始化！"
                "请在主应用启动时先调用 InitDBConBase(config)"
            )
        return getattr(_ConBase, name)

    def __call__(self, *args, **kwargs):
        if not _Initialized or _ConBase is None:
            raise RuntimeError(
                "ConBase 尚未初始化！"
                "请在主应用启动时先调用 InitDBConBase(config)"
            )
        return _ConBase(*args, **kwargs)
# 导出兼容的 ConBase（代理对象）
ConBase = _ConBaseProxy()