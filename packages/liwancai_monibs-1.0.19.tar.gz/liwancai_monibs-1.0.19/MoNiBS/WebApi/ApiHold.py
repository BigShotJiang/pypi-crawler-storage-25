from typing                  import Optional
from fastapi                 import APIRouter, HTTPException, Depends
from pydantic                import BaseModel
from .                       import GetConBase

hold_router = APIRouter()

class HoldQuery(BaseModel):
    strategy_name: str
    db_name : str
    tbl_name: str
    code: Optional[str] = None
    account_id: Optional[str] = None
    hold_type: Optional[int] = None
    start_date: Optional[str] = None
    end_date: Optional[str] = None


@hold_router.post("/holds")
async def get_holds(query: HoldQuery, conbase = Depends(GetConBase)):
    """
    按条件筛选持仓数据，支持日期范围、代码、账户ID、持仓类型筛选。
    当且仅当所有筛选条件都为空时，取最新交易日作为默认日期范围。
    """
    try:
        conn = conbase.connect(query.strategy_name)

        # 判断是否有任何筛选条件
        has_filter = (
            query.code or
            query.account_id or
            query.hold_type  > 0  or
            query.start_date or
            query.end_date
        )

        start_input = query.start_date if query.start_date else None
        end_input = query.end_date if query.end_date else None

        if not has_filter:
            # 无任何筛选条件，取最新交易日
            df_trade_date = conn.GetData(f"SELECT MAX(TradeDate) as latest FROM {query.db_name}.{query.tbl_name}")
            if df_trade_date.empty or df_trade_date.iloc[0]['latest'] is None:
                raise HTTPException(404, "No Hold data found")
            latest_val = df_trade_date.iloc[0]['latest']
            latest = latest_val.strftime("%Y-%m-%d") if hasattr(latest_val, 'strftime') else str(latest_val)
            start_date = latest
            end_date = latest
        else:
            # 有筛选条件，日期不传则不限日期范围
            start_date = start_input
            end_date = end_input

        # 构建SQL
        sql = f"SELECT * FROM {query.db_name}.{query.tbl_name} WHERE 1=1"
        if start_date:
            sql += f" AND TradeDate >= '{start_date}'"
        if end_date:
            sql += f" AND TradeDate <= '{end_date}'"
        if query.code:
            sql += f" AND Code = '{query.code}'"
        if query.account_id:
            sql += f" AND AccountID = '{query.account_id}'"
        if query.hold_type > 0:
            sql += f" AND HoldType = {query.hold_type}"
        sql += " ORDER BY TradeDate DESC, Code LIMIT 2500"

        df = conn.GetData(sql)
        conn.Close()

        return df.to_dict(orient="records")
    except Exception as e:
        raise HTTPException(500, detail=str(e))
