from dataclasses   import dataclass
from ..utils.Tools import UniqueID

@dataclass
class AccountN:
    '''账户结构体'''
    AccName: str   = ""           # 账户名称 ###
    AccountID: str = ""         # 账户ID ###
    TradeTime: str = ""         # 交易时间
    TradeDate: str = ""         # 交易日期

    FundsOut: float  = 0          # 资金转出:累计汇总
    FundsInit: float = 100_0000   # 转入资金:累计汇总

    FundsSum: float  = 100_0000   # *账户总资产 
    # A:[净转入资金 + 赚的钱(浮动盈亏 + 清仓结算盈亏)- 总手续费  ] 
    # B:[(持仓资金||占用保证金) + 可用资金]
    FundsHold: float = 0          # 持仓资金||占用保证金(属于截面切片 随源变化)
    FundsAble: float = 100_0000   # 可用资金(属于计算值 不用汇总): 账户总资产 - (持仓资金||占用保证金)

    HoldEarn: float      = 0     # 浮动盈亏(属于截面切片 随源变化)
    FundsEarnSum: float  = 0     # 清仓结算盈亏(属于累计值 汇总后要及时清除源标记)
    FundsUseRatio: float = 0     # *持仓比例：持仓资金/总资产
    FeesSum: float       = 0     # 总手续费(属于累计值 汇总后要及时清除源标记)

    
    
def Account(AccName:str='',initfunds: float = 0, **kwargs) -> AccountN:
    '''
    创建账户实例，支持通过kwargs更新字段
    # 创建新账户
    acc1 = Account()  # 使用默认值
    # 使用字典更新账户
    acc_data = {
        "Account": "账户1",
        "AccountID": "001",
        "FundsInit": 200_0000,
        "FundsSum": 200_0000
    }
    acc2 = Account(**acc_data)  # 字典会更新到账户实例中
    # 也可以混合使用
    acc3 = Account(initfunds=100_0000, AccName="自定义账户", AccountID="002")
    '''
    acc = AccountN(
        AccName     =AccName,
        AccountID   =UniqueID(AccName),
        TradeTime   ="",
        TradeDate   ="",
        FundsOut    =0,
        FundsInit   =initfunds,
        FundsSum    =initfunds,
        FundsHold   =0,
        FundsAble   =initfunds,
        FundsEarnSum    =0,
        FundsUseRatio   =0,
        FeesSum         =0,
        HoldEarn     =0
    )
    if kwargs:
        for key, value in kwargs.items(): 
            if hasattr(acc, key):setattr(acc, key, value)
    return acc
 