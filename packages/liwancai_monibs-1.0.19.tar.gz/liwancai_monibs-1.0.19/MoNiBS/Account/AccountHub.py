from LOG                                import log
from .Account                           import Account,AccountN

class AccountHub:
    '''
    账户管理器
    总账户 = 所有品种共用同一个账户
    独立子账户 = 每个品种都有一个独立账户，互不干扰
    '''
    def __init__(self,cfg:dict = None):
        '''
        如果需要配置账户数据
        cfg: 账户配置字典 Accs 以AccountID为键 以Account对象为值
        Accs: {
            'main0-uuid-0':Account("main0",0),
            'main1-uuid-0':Account("main1",0),
            'main2-uuid-0':Account("main2",0),
            'main-uuid-1':Account("main",0)
        }
        '''
        ### 初始化账户字典 便于查找
        self.AccsByID:dict[str,AccountN]       = cfg.get("Accs",{}) ### 账户字典 用于通过AccID快速找到对应账户
        self.AccsByName:dict[str,AccountN]     = {x.AccName:x for x in self.AccsByID.values()} ### 账户字典 用于通过AccName快速找到对应账户
        ### 用于汇总的总账户 不可交易
        self.__Acc_Total:AccountN       = Account("total",0)
        ### 初始化主账户 初始资金为 0
        self.Acc_Main:AccountN       = self.AccsByName.get("main",Account("main",0))### 主账户是 公共账户
        self.AccsByID[self.Acc_Main.AccountID] = self.Acc_Main### 主账户 也加入字典
        self.AccsByName[self.Acc_Main.AccName] = self.Acc_Main### 主账户 也加入字典 
        
    def Get_Account(self,AccName=None,AccID:str = None)->AccountN:
        '''
        获取账户 通过AccID或 AccName 获取账户对象 
        如果AccName AccID 参数都是None 则返回 主账户
        '''
        if AccID is not None:### 先通过AccID查找
            if AccID in self.AccsByID:return  self.AccsByID[AccID]### 独立子账户
            else: log.Warn(f"账户ID {AccID} 不存在")
        ### AccName AccID 参数都是None 直接返回 主账户
        if AccName is None: return self.Acc_Main 
        ### 如果AccName名称存在 则返回对应的账户
        if AccName in self.AccsByName:return  self.AccsByName[AccName]### 对应的账户
        ### 如果AccName名称不存在 则创建一个新的 初始资金为0 的账户
        log.Notice(f"创建新账户 {AccName}")
        self.AccsByName[AccName]=self.AccsByName.get(AccName,Account(AccName,0))
        if self.AccsByName[AccName].AccountID not in self.AccsByID:### 将新创建的账户 加入字典记录
            self.AccsByID[self.AccsByName[AccName].AccountID]= self.AccsByName[AccName]
        ### 检查是否成功创建账户
        if self.AccsByName[AccName] :
            log.Notice(f"创建新账户 {AccName} 成功：{self.AccsByName[AccName]}")
        else: log.Error(f"创建新账户 {AccName} 失败")
        return self.AccsByName[AccName]### 对应的账户

    def Set_Account(self,acc:dict = None,NewAccName=None)->None:
        '''
        设置账户数据
        AccName: 账户名称
        acc: 账户完整数据
        '''
        acc_copy = acc.copy()# 避免账户参数 AccName 的重复传递
        if NewAccName is not None: 
            acc_copy.AccName = NewAccName
        AccNew  = Account(**acc_copy)### 新账户
        self.AccsByID[AccNew.AccountID] = AccNew
        self.AccsByName[AccNew.AccName] = AccNew 

    def AccFundsIn(self,AccName=None,AccID:str = None,funds:float = 0.0)->None:
        '''
        资金转入
        如果AccName AccID 参数都是None 则转入主账户
        如果AccName 则按AccName转入资金
        如果AccID 则按AccID 转入资金
       
      
        :param AccName: 账户名称
        :param AccID: 账户ID
        :param funds: 资金转入金额
        :return: None
        如果账户不存在 则创建一个新的 初始资金为0 的账户 再转入资金
        如果账户存在 则直接转入资金
        资金转入后 更新账户总资产和可用资金汇总
        
        '''
        if AccName is None and AccID is None: 
            self.Acc_Main.FundsInit += funds ### 转入资金增加
            self.Acc_Main.FundsSum  += funds ### 账户总资产增加
            self.Acc_Main.FundsAble += funds ### 可用资金增加
        if AccName is not None:
            if AccName not in self.AccsByName: 
                log.Error(f"账户名称 {AccName} 不存在")
                return
            self.AccsByName[AccName].FundsInit += funds ### 转入资金增加
            self.AccsByName[AccName].FundsSum  += funds ### 账户总资产增加
            self.AccsByName[AccName].FundsAble += funds ### 可用资金增加
        if AccID is not None:
            if AccID not in self.AccsByID: 
                log.Error(f"账户ID {AccID} 不存在")
                return
            self.AccsByID[AccID].FundsInit += funds ### 转入资金增加
            self.AccsByID[AccID].FundsSum  += funds ### 账户总资产增加
            self.AccsByID[AccID].FundsAble += funds ### 可用资金增加

    def AccFundsOut(self,AccName=None,AccID:str = None,funds:float = 0.0)->bool:
        '''
        资金转出
        如果AccName AccID 参数都是None 则转出主账户
        如果AccName 则按AccName转出资金
        如果AccID 则按AccID转出资金
       
        '''
        if AccName is None and AccID is None: 
            if self.Acc_Main.FundsAble < funds: 
                log.Warn(f"主账户最大可转出资金为{self.Acc_Main.FundsAble}元,已转出!")
            self.Acc_Main.FundsOut  += funds ### 资金转出汇总
            self.Acc_Main.FundsAble -= funds ### 可用资金减少
            self.Acc_Main.FundsSum  -= funds ### 账户总资产减少 
        if AccID is not None:
            if AccID not in self.AccsByID:
                log.Error(f"账户ID {AccID} 不存在")
                return False
            if self.AccsByID[AccID].FundsAble < funds: 
                log.Warn(f"{AccID}最大可转出资金为{self.AccsByID[AccID].FundsAble}元,已转出!")
            self.AccsByID[AccID].FundsOut  += funds ### 资金转出汇总
            self.AccsByID[AccID].FundsAble -= funds ### 可用资金减少
            self.AccsByID[AccID].FundsSum  -= funds ### 账户总资产减少 
        if AccName is not None:
            if AccName not in self.AccsByName:
                log.Error(f"账户名称 {AccName} 不存在")
                return False
            if self.AccsByName[AccName].FundsAble < funds: 
                log.Warn(f"{AccName}最大可转出资金为{self.AccsByName[AccName].FundsAble}元,已转出!")
            self.AccsByName[AccName].FundsOut  += funds ### 资金转出汇总
            self.AccsByName[AccName].FundsAble -= funds ### 可用资金减少
            self.AccsByName[AccName].FundsSum  -= funds ### 账户总资产减少 
        return True


    def Get_AccountTotal(self)->AccountN:
        '''
        对账户数据进行汇总 
        :return: 总账户的资金详情
        '''
        ### 再汇总独立子账户的账户数据 合并到总账户
        for acc in self.AccsByName.values():
            self.__Acc_Total.TradeTime = max(self.__Acc_Total.TradeTime,acc.TradeTime)         # 交易时间
            self.__Acc_Total.TradeDate = max(self.__Acc_Total.TradeDate,acc.TradeDate)         # 交易日期
            self.__Acc_Total.FundsOut += acc.FundsOut # 资金转出:累计汇总
            self.__Acc_Total.FundsInit += acc.FundsInit # 初始转入资金:100万
            self.__Acc_Total.FundsHold += acc.FundsHold # 持仓资金||占用保证金
            self.__Acc_Total.FundsAble += acc.FundsAble # 可用资金 
            self.__Acc_Total.FeesSum += acc.FeesSum # 总手续费(累计汇总)
            self.__Acc_Total.HoldEarn += acc.HoldEarn #  浮动盈亏
            # self.__Acc_Total.FundsEarnSum += acc.FundsEarnSum # 清仓结算盈亏
        self.__Acc_Total.FundsSum = self.__Acc_Total.FundsHold + self.__Acc_Total.FundsAble # 账户总资产 = 持仓资金||占用保证金 + 可用资金 
        self.__Acc_Total.FundsEarnSum = self.__Acc_Total.FundsSum - (self.__Acc_Total.FundsInit - self.__Acc_Total.FundsOut) # 资金总收益汇总:账户总资产(FundsSum) - 净转入资金(FundsInit - FundsOut)
        self.__Acc_Total.FundsUseRatio = self.__Acc_Total.FundsHold / self.__Acc_Total.FundsSum # 持仓比例：持仓资金/总资产
        return self.__Acc_Total
