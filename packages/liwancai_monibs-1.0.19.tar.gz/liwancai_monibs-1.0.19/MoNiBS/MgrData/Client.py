 
import random,time,threading
from ApiClient           import ApiClient
from LOG                 import log
class DataClient():
    def __init__(self, url: str):
        self.url = url
        self.api:ApiClient  = ApiClient(url)
        self.phone = None
        self.password = None
        self.apitoken = None
        self.webtoken = None
        self.webExpiresIn = 0   
        self.refresh_thread = None
        self.refresh_running = False
    
    def Login(self, phone: str, password: str):
        self.phone = phone
        self.password = password
        rst = self.api.login(phone=phone,Password=password).data
        self.webtoken  = rst["accessToken"]
        self.webExpiresIn = rst["expiresIn"]
        self.api.set_webtoken(self.webtoken)
        self._start_auto_refresh()# 启动自动刷新线程
        return rst
    
    def Set_API_Token(self, token: str):
        self.apitoken = token
        self.api.set_apitoken(token)
    
    def _start_auto_refresh(self):
        """启动自动刷新线程"""
        if self.refresh_running: return
        self.refresh_running = True
        self.refresh_thread = threading.Thread(target=self._auto_refresh_worker, daemon=True)
        self.refresh_thread.start()
    def _auto_refresh_worker(self):
        """自动刷新工作线程"""
        while self.refresh_running:
            try:
                # 随机sleep时间：webExpiresIn/2 到 webExpiresIn-30秒 之间
                sleep_time = random.randint(self.webExpiresIn // 2, self.webExpiresIn-30)
                log.Info(f"后台线程等待 {sleep_time} 秒后刷新token")
                time.sleep(sleep_time)
                # 重新登录更新token
                if self.phone and self.password:
                    log.Info("后台自动刷新token..")
                    rst = self.api.login(phone=self.phone, password=self.password).data
                    self.webtoken = rst["accessToken"]
                    self.webExpiresIn = rst["expiresIn"]
                    self.api.set_webtoken(self.webtoken)
                    log.Info("Token自动刷新成功")
            except Exception as e:
                log.Error(f"自动刷新异常: {e}")
                time.sleep(3)  # 异常后等待3秒再重试
  