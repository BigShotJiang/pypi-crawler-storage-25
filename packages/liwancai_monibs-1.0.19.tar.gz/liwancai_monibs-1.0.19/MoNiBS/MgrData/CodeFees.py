
from dataclasses                     import dataclass
from enum                            import IntEnum

@dataclass
class CodeFeesN:
    Code                            :str              
    VolumeMultiple                  :float    ### 乘数
    ###  保证金信息
    LongMarginRatioByMoney          :float    ### 多头保证金率
    LongMarginRatioByVolume         :float    ### 多头保证金费
    ShortMarginRatioByMoney         :float    ### 空头保证金率
    ShortMarginRatioByVolume        :float    ### 空头保证金费
    ### 手续费信息
    OpenRatioByMoney              :float    ### 开仓手续费率
    OpenRatioByVolume             :float    ### 开仓手续费
    CloseRatioByMoney             :float    ### 平仓手续费率
    CloseRatioByVolume            :float    ### 平仓手续费
    CloseTodayRatioByMoney        :float    ### 平今手续费率
    CloseTodayRatioByVolume       :float    ### 平今手续费费
    ### 最小开仓数量
    MinOpenVolume                   :int    ### 最小开仓数量
def CodeFees(Code:str,cfg:dict):
    return CodeFeesN(
        Code=Code,
        VolumeMultiple=cfg.get("VolumeMultiple",1.0),
        LongMarginRatioByMoney=cfg.get("LongMarginRatioByMoney",1.0),### 多头保证金率
        LongMarginRatioByVolume=cfg.get("LongMarginRatioByVolume",0.0),### 多头保证金费
        ShortMarginRatioByMoney=cfg.get("ShortMarginRatioByMoney",1.0),### 空头保证金率
        ShortMarginRatioByVolume=cfg.get("ShortMarginRatioByVolume",0.0),### 空头保证金费

        OpenRatioByMoney=cfg.get("OpenRatioByMoney",1.5/1000),### 开仓手续费率
        OpenRatioByVolume=cfg.get("OpenRatioByVolume",0.0),### 开仓手续费
        CloseRatioByMoney=cfg.get("CloseRatioByMoney",1.5/1000),### 平仓手续费率
        CloseRatioByVolume=cfg.get("CloseRatioByVolume",0.0),### 平仓手续费
        CloseTodayRatioByMoney=cfg.get("CloseTodayRatioByMoney",1.5/1000),### 平今手续费率
        CloseTodayRatioByVolume=cfg.get("CloseTodayRatioByVolume",0.0),### 平今手续费费
        MinOpenVolume=cfg.get("MinOpenVolume",100),### 最小开仓数量
    )
 
