from typing                                 import Any
from .Client                                import DataClient
from .CodeFees                              import CodeFees
from PyTools                                import SetList
import pandas                               as pd 
class MgrDataHub:
    def __init__(self,cfg:dict = None):
        self.Periods   = cfg.get("Periods",[1440])### 客户端订阅的周期列表
        self.MinPeriod = min(self.Periods)### 最小周期
        self.KDates         = []### 客户端订阅的时间列表 ["20230101","20230102"]
        self.KTimes         = []### 客户端订阅的时间列表 [093100 093200 093300 093400] 
        self.PeriodTimes    = {}### 各周期的时间列表 {1440:[093100 093200 093300 093400],1440:[150000]}

        self.STCodeList      :list             = []   # ST股票代码列表
        self.DaysUPDWDict    :dict             = {}   # 涨停价格数据
        self.CodeBasicDict   :dict             = {}   # 股票上市基础信息
        self.CodeInfoDict    :dict             = {}   # 股票行业等基础信息
        self.CodeFeesDict    :dict             = {}   # 股票手续费信息
        self.DaysPersDict    :dict             = {}   # N周期后的相对涨幅统计
        self.DaysMetricsDict :dict             = {}   # 基础指标:pe pb 流通市值 换手率等
        self.client          :DataClient       = None # 数据接口客户端
        self.codeinfo        :pd.DataFrame     = None # 股票基础信息数据集 包含CodeBasicDict和CodeInfoDict 的DataFrame
        self.InitClient(cfg.get("URL","https://api.liwancai.com"),
                        cfg.get("Username",""), cfg.get("Password",""))
    def InitClient(self,URL:str , Username:str ,Password:str ):
        '''
        初始化ApiGroupClient
        '''
        self.client:DataClient  = DataClient(URL)
        self.client.Login(phone=Username,password=Password)
        return self.client 
    def SetCodeFees(self,Code:str,FeesDict:dict):
        '''
        设置股票手续费信息
        '''
        self.CodeFeesDict[Code] = CodeFees(Code,FeesDict)
    def SetPeriods(self,Periods:list):
        self.Periods = SetList([int(x) for x in Periods])
        self.MinPeriod = min(self.Periods)
        self.Periods.sort()
    def getDoDateTime(self,SDate="",EDate=""):
        for period in self.Periods:
            KDates = self.client.api.KLs.AbleDates( period=period ).data
            self.KDates.extend(KDates)
            KTimes = self.client.api.KLs.AbleTimes( period=period ).data
            KTimes.sort()
            self.PeriodTimes[period] = KTimes
            if period == self.MinPeriod: self.KTimes = KTimes
        self.KDates = list[Any](set(self.KDates))### 去重
        if  SDate!="":  self.KDates = [ x  for x in self.KDates if x >= SDate.replace("-","")]
        if  EDate!="":  self.KDates = [ x  for x in self.KDates if x <= EDate.replace("-","")]
        self.KDates.sort()### 排序 升序
    def FlashST(self,trade_time,period=1440):
        '''
        获取昨日ST股票列表 
        '''
        st_data         = self.client.api.KLs.DaysIsst(trade_time=trade_time,period=period).Todf()### 获取昨日ST股票列表
        self.STCodeList = st_data['code'].tolist()
        return st_data
    def FlashUPDW(self,trade_time,period=1440):
        '''
        获取昨日涨停价格数据
        '''
        updw_df = self.client.api.KLs.DaysUpdw(trade_time=trade_time,period=period).Todf()### 获取涨停价格数据
        self.client.api.DFToType(updw_df,['dwlimit','uplimit'],float)
        self.DaysUPDWDict = self.client.api.DFToDict(updw_df,"index",index_field='code')
        return updw_df
    def getBaseInfo(self):
        '''
        获取股票基础信息: 上市日期等
        '''
        self.CodeBasicDict = self.client.api.GPs.Get_CodeBasic().data### 包含上市日期等基础信息
        self.CodeInfoDict  = self.client.api.GPs.Get_CodeInfo().data### 包含行业等基础信息

        basic_df = pd.DataFrame(self.CodeBasicDict.values())
        info_df  = pd.DataFrame(self.CodeInfoDict.values())
        self.codeinfo = pd.merge(basic_df,info_df,on='code',how='left')
        return self.codeinfo
    def getDaysKlines(self,trade_time,period=1440): 
        '''
        获取K线数据
        '''
        df = self.client.api.KLs.DaysKline(trade_time=trade_time,period=period).Todf()### 获取K线数据
        df.rename(columns={x:x.replace("name=","") for x in df.columns},inplace=True)
        self.client.api.DFToType(df,['hfq','REFclose','close','open','high','low'],float)
        self.client.api.DFToType(df,['trade_time','trade_date'],str)
        return df
    def getPers(self,trade_time,period=1440):
        '''
        获取N周期后的相对涨幅,  
        '''
        dfpers = self.client.api.KLs.DaysPers(trade_time=trade_time,period=period).Todf() ### N周期后的相对涨幅
        self.client.api.DFToType(dfpers,dfpers.columns.tolist(),float)
        self.DaysPersDict = self.client.api.DFToDict(dfpers,"index",index_field='code')
        return dfpers
    def getMetrics(self,trade_time,period=1440):
        '''
        获取N周期后的基础指标:pe pb 流通市值 换手率等
        '''
        dfmetrics = self.client.api.KLs.DaysMetrics(trade_time=trade_time,period=period).Todf() ### 基础指标:pe pb 流通市值 换手率等
        self.client.api.DFToType(dfmetrics,dfmetrics.columns.tolist(),float)
        self.DaysMetricsDict = self.client.api.DFToDict(dfmetrics,"index",index_field='code')
        return dfmetrics
    def Fees_Get(self,code):
        '''
        获取手续费
        '''
        # 从接口获取手续费 待实现
        return self.CodeFeesDict.get(code,CodeFees(code,{}))
