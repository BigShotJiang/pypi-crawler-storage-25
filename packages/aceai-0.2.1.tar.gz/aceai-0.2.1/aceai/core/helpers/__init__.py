"""Shared helper utilities."""
