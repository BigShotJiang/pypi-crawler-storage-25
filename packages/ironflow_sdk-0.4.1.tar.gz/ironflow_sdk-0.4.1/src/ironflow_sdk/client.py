# HTTP client for the Ironflow REST API. Uses httpx.

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Generic, Never, TypeVar

import httpx

from .errors import AuthError, IronflowError, QueryWindowError, QueryTimeoutError, QueryTooExpensiveError, RateLimitError, TierError

DEFAULT_BASE_URL = "https://api.ironflow.sh"
DEFAULT_SOURCE = "hyperliquid"
SDK_VERSION = "0.4.1"

T = TypeVar("T")


def _validate_base_url(value: str) -> str:
    """Reject http:// (key would travel in cleartext) for non-localhost hosts."""
    from urllib.parse import urlparse

    parsed = urlparse(value)
    is_local = parsed.hostname in ("localhost", "127.0.0.1")
    if parsed.scheme not in ("https", "http"):
        raise ValueError(f"Ironflow SDK: invalid base_url: {value}")
    if parsed.scheme != "https" and not is_local:
        raise ValueError(
            "Ironflow SDK: base_url must use https:// "
            f"(got {parsed.scheme}://). API keys sent over http would be "
            "readable by network observers."
        )
    return value.rstrip("/")


class HttpClient:
    """Thin httpx wrapper that handles auth, error mapping, and source injection."""

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        source: str = DEFAULT_SOURCE,
        timeout: float = 30.0,
    ) -> None:
        self._api_key = api_key
        self.base_url = _validate_base_url(base_url)
        self.source = source
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "User-Agent": f"ironflow-sdk/{SDK_VERSION}",
            },
            timeout=timeout,
        )

    async def get_ws_url(self) -> str:
        """Resolve a WebSocket URL using a short-lived connect token.

        POSTs to /v1/ws/token (authenticated via the bearer header) to obtain
        a token, then returns a wss:// URL that carries the token instead of
        the raw API key — keeping the key out of Caddy/Cloudflare logs,
        browser history, and Referer headers.

        Falls back to the legacy ``?api_key=`` form on 404/405 (older
        deployments that pre-date the token endpoint).
        """
        ws_base = self.base_url.replace("https://", "wss://").replace("http://", "ws://")
        try:
            res = await self._client.post("/v1/ws/token")
            if res.is_success:
                body = res.json()
                token = body.get("token")
                if token:
                    return f"{ws_base}/ws?token={token}"
            elif res.status_code not in (404, 405):
                self._raise_from(res)
        except httpx.HTTPError:
            # Network errors fall through to legacy.
            pass
        return f"{ws_base}/ws?api_key={self._api_key}"

    @property
    def ws_url(self) -> str:
        """Synchronous URL helper that embeds the raw API key.

        Deprecated: prefer ``await client.get_ws_url()`` so the key stays
        out of URL logs.
        """
        url = self.base_url.replace("https://", "wss://").replace("http://", "ws://")
        return f"{url}/ws?api_key={self._api_key}"

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Send a GET request; inject source if absent."""
        p = dict(params or {})
        p.setdefault("source", self.source)
        # Remove None values.
        p = {k: v for k, v in p.items() if v is not None}
        res = await self._client.get(path, params=p)
        return self._handle(res)

    async def post(self, path: str, body: Any) -> Any:
        """Send a POST request with a JSON body."""
        res = await self._client.post(path, json=body)
        return self._handle(res)

    async def patch(self, path: str, body: Any) -> Any:
        """Send a PATCH request with a JSON body."""
        res = await self._client.patch(path, json=body)
        return self._handle(res)

    async def delete(self, path: str) -> None:
        """Send a DELETE request."""
        res = await self._client.request("DELETE", path)
        if not res.is_success:
            self._raise_from(res)

    async def aclose(self) -> None:
        await self._client.aclose()

    async def get_raw(self, path: str, params: dict[str, Any] | None = None) -> bytes:
        """Send a GET request and return raw bytes (for binary exports)."""
        p = dict(params or {})
        p.setdefault("source", self.source)
        p = {k: v for k, v in p.items() if v is not None}
        res = await self._client.get(path, params=p)
        if not res.is_success:
            self._raise_from(res)
        return res.content

    def _handle(self, res: httpx.Response) -> Any:
        if res.is_success:
            return res.json()
        self._raise_from(res)

    def _raise_from(self, res: httpx.Response) -> "Never":
        """Parse an error response and raise the appropriate typed exception."""
        try:
            err = res.json()
            code = err.get("error", {}).get("code", "UNKNOWN")
            message = err.get("error", {}).get("message", res.text)
        except Exception:
            code = "UNKNOWN"
            message = res.text

        if res.status_code == 400:
            if code == "QUERY_WINDOW_EXCEEDED":
                raise QueryWindowError(message)
            if code == "QUERY_TOO_EXPENSIVE":
                raise QueryTooExpensiveError(message)
        if res.status_code == 401:
            raise AuthError(message)
        if res.status_code == 403:
            raise TierError(message, code)
        if res.status_code == 429:
            retry_after = int(res.headers.get("Retry-After", "60"))
            raise RateLimitError(message, retry_after * 1000)
        if res.status_code == 504:
            raise QueryTimeoutError(message)
        raise IronflowError(message, code, res.status_code)


@dataclass
class Pagination:
    """Pagination metadata exposed on every Page."""
    next_cursor: str | None
    has_more: bool


class Page(Generic[T]):
    """Paginated result with async next() support and a public `.pagination` field."""

    def __init__(
        self,
        data: list[T],
        has_more: bool,
        next_cursor: str | None,
        next_fn: Callable[[str], "Page[T]"] | None,
    ) -> None:
        self.data = data
        self.has_more = has_more
        self.pagination = Pagination(next_cursor=next_cursor, has_more=has_more)
        self._next_cursor = next_cursor
        self._next_fn = next_fn if has_more and next_cursor else None

    async def next(self) -> "Page[T]":
        """Fetch the next page. Raises if there are no more pages."""
        if not self._next_fn or not self._next_cursor:
            raise StopAsyncIteration("No more pages")
        return await self._next_fn(self._next_cursor)
