# Ironflow Python SDK — market data for on-chain derivatives.
#
# Usage:
#   from ironflow_sdk import Ironflow
#   client = Ironflow("if_your_api_key")
#   trades = await client.trades("BTC-PERP", limit=10)

from __future__ import annotations

from typing import Any

from .client import HttpClient, Page
from .errors import AuthError, IronflowError, QueryWindowError, QueryTimeoutError, QueryTooExpensiveError, RateLimitError, TierError
from .stream import StreamClient
from .types import (
    BookSnapshot, BookLevel, Candle, Deposit, FundingRate, Liquidation,
    MarkPrice, OpenInterest, OrderStatus, Trade, Withdrawal,
    VaultOperation, Trigger, CohortInfo, CohortAddressEntry, CohortAddresses,
    NetFlow, LiquidationLevel, OrderFlow, VaultLeaderboardEntry, FundingStats,
    StatusResponse, DataFreshness, VenueStatus, PlatformStats,
    MeResponse, MeLimits, HealthResponse,
    Market, APIMetrics, PipelineMetrics, SyntheticMetrics,
    StatusMetricsResponse, UptimePoint, StatusHistoryResponse,
)

__all__ = [
    "Ironflow",
    "IronflowError", "RateLimitError", "AuthError", "TierError",
    "QueryWindowError", "QueryTimeoutError", "QueryTooExpensiveError",
    "Trade", "BookLevel", "BookSnapshot", "Candle", "FundingRate",
    "Liquidation", "OpenInterest", "MarkPrice", "Deposit", "Withdrawal", "OrderStatus",
    "VaultOperation", "Trigger", "CohortInfo", "CohortAddressEntry", "CohortAddresses",
    "NetFlow", "LiquidationLevel", "OrderFlow", "VaultLeaderboardEntry", "FundingStats",
    "StatusResponse", "DataFreshness", "VenueStatus", "PlatformStats",
    "MeResponse", "MeLimits", "HealthResponse",
    "Market", "APIMetrics", "PipelineMetrics", "SyntheticMetrics",
    "StatusMetricsResponse", "UptimePoint", "StatusHistoryResponse",
]


_TYPE_DEFAULTS: dict[str, Any] = {"str": "", "int": 0, "float": 0.0, "bool": False}


def _only_fields(cls: Any, d: dict[str, Any]) -> dict[str, Any]:
    """Filter a dict to fields declared on a dataclass, dropping unknowns.

    Keeps the SDK forward-compatible: the server can add new response fields
    without breaking older SDK clients. Also fills in zero-values for missing
    required fields so clients that predate a new server field (e.g. older
    servers that don't yet emit ``issuer``/``base_market``) don't raise on
    construction.
    """
    import dataclasses as _dc

    kept = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
    for name, field in cls.__dataclass_fields__.items():
        if name in kept:
            continue
        if field.default is not _dc.MISSING or field.default_factory is not _dc.MISSING:  # type: ignore[misc]
            continue
        type_name = getattr(field.type, "__name__", str(field.type))
        kept[name] = _TYPE_DEFAULTS.get(type_name, None)
    return kept


def _parse_trade(d: dict[str, Any]) -> Trade:
    return Trade(**_only_fields(Trade, d))


def _parse_book(d: dict[str, Any]) -> BookSnapshot:
    return BookSnapshot(
        source=d["source"],
        market=d["market"],
        issuer=d.get("issuer", ""),
        base_market=d.get("base_market", ""),
        timestamp=d["timestamp"],
        bids=[BookLevel(**_only_fields(BookLevel, b)) for b in d["bids"]],
        asks=[BookLevel(**_only_fields(BookLevel, a)) for a in d["asks"]],
    )


def _parse_candle(d: dict[str, Any]) -> Candle:
    return Candle(**_only_fields(Candle, d))


def _parse_funding(d: dict[str, Any]) -> FundingRate:
    return FundingRate(**_only_fields(FundingRate, d))


def _parse_liquidation(d: dict[str, Any]) -> Liquidation:
    return Liquidation(**_only_fields(Liquidation, d))


def _parse_open_interest(d: dict[str, Any]) -> OpenInterest:
    return OpenInterest(**_only_fields(OpenInterest, d))


def _parse_mark_price(d: dict[str, Any]) -> MarkPrice:
    return MarkPrice(**_only_fields(MarkPrice, d))


def _parse_deposit(d: dict[str, Any]) -> Deposit:
    return Deposit(**_only_fields(Deposit, d))


def _parse_withdrawal(d: dict[str, Any]) -> Withdrawal:
    return Withdrawal(**_only_fields(Withdrawal, d))


def _parse_order_status(d: dict[str, Any]) -> OrderStatus:
    return OrderStatus(**_only_fields(OrderStatus, d))


def _parse_vault_operation(d: dict[str, Any]) -> VaultOperation:
    return VaultOperation(**_only_fields(VaultOperation, d))


def _parse_trigger(d: dict[str, Any]) -> Trigger:
    return Trigger(**_only_fields(Trigger, d))


def _parse_cohort_info(d: dict[str, Any]) -> CohortInfo:
    return CohortInfo(
        name=d["name"],
        description=d.get("description", ""),
    )


def _parse_cohort_address_entry(d: dict[str, Any]) -> CohortAddressEntry:
    return CohortAddressEntry(
        address=d["address"],
        value=d.get("value"),
    )


def _parse_net_flow(d: dict[str, Any]) -> NetFlow:
    return NetFlow(**_only_fields(NetFlow, d))


def _parse_liquidation_level(d: dict[str, Any]) -> LiquidationLevel:
    return LiquidationLevel(**_only_fields(LiquidationLevel, d))


def _parse_order_flow(d: dict[str, Any]) -> OrderFlow:
    return OrderFlow(**_only_fields(OrderFlow, d))


def _parse_vault_leaderboard(d: dict[str, Any]) -> VaultLeaderboardEntry:
    return VaultLeaderboardEntry(**_only_fields(VaultLeaderboardEntry, d))


def _parse_funding_stats(d: dict[str, Any]) -> FundingStats:
    return FundingStats(**_only_fields(FundingStats, d))


class Ironflow:
    """Ironflow API client."""

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.ironflow.sh",
        source: str = "hyperliquid",
        timeout: float = 30.0,
    ) -> None:
        self._http = HttpClient(api_key, base_url=base_url, source=source, timeout=timeout)
        # StreamClient receives the HttpClient so it can fetch a fresh
        # connect-token URL on each connection — keeping the raw API key
        # out of the WebSocket URL (and thus out of server logs).
        self.stream = StreamClient(self._http, source=source)

    # ─── Market Data ────────────────────────────────────────────────────

    async def trades(self, market: str, **options: Any) -> Page[Trade]:
        """Get recent trades for a market."""
        return await self._paginated("/v1/trades", {"market": market, **options}, _parse_trade)

    async def fills(self, address: str, **options: Any) -> Page[Trade]:
        """Get fills for an address."""
        return await self._paginated("/v1/fills", {"address": address, **options}, _parse_trade)

    async def book(self, market: str, **options: Any) -> Page[BookSnapshot]:
        """Get recent order book snapshots."""
        return await self._paginated("/v1/book", {"market": market, **options}, _parse_book)

    async def candles(self, market: str, interval: str | None = None, **options: Any) -> Page[Candle]:
        """Get OHLCV candlestick data."""
        params: dict[str, Any] = {"market": market, **options}
        if interval is not None:
            params["interval"] = interval
        return await self._paginated("/v1/candles", params, _parse_candle)

    async def liquidations(self, market: str | None = None, **options: Any) -> Page[Liquidation]:
        """Get liquidation events."""
        params: dict[str, Any] = {**options}
        if market is not None:
            params["market"] = market
        return await self._paginated("/v1/liquidations", params, _parse_liquidation)

    async def funding(self, market: str, **options: Any) -> Page[FundingRate]:
        """Get funding rate history."""
        return await self._paginated("/v1/funding", {"market": market, **options}, _parse_funding)

    async def open_interest(self, market: str, **options: Any) -> Page[OpenInterest]:
        """Get open interest snapshots."""
        return await self._paginated("/v1/open-interest", {"market": market, **options}, _parse_open_interest)

    async def mark_prices(self, market: str, **options: Any) -> Page[MarkPrice]:
        """Get mark and oracle prices."""
        return await self._paginated("/v1/mark-prices", {"market": market, **options}, _parse_mark_price)

    async def deposits(self, **options: Any) -> Page[Deposit]:
        """Get deposit events."""
        return await self._paginated("/v1/deposits", options, _parse_deposit)

    async def withdrawals(self, **options: Any) -> Page[Withdrawal]:
        """Get withdrawal events."""
        return await self._paginated("/v1/withdrawals", options, _parse_withdrawal)

    async def order_statuses(self, **options: Any) -> Page[OrderStatus]:
        """Get order status events."""
        return await self._paginated("/v1/order-statuses", options, _parse_order_status)

    # ─── Vault Operations ────────────────────────────────────────────────

    async def vault_operations(self, **options: Any) -> Page[VaultOperation]:
        """Get vault deposit/withdraw events."""
        return await self._paginated("/v1/vault-operations", options, _parse_vault_operation)

    # ─── Triggers ───────────────────────────────────────────────────────

    async def create_trigger(
        self, name: str, channel: str, rule: dict[str, Any], webhook_url: str,
    ) -> Trigger:
        """Create a rule-based webhook trigger."""
        raw = await self._http.post("/v1/triggers", {
            "name": name, "channel": channel, "rule": rule, "webhook_url": webhook_url,
        })
        return _parse_trigger(raw)

    async def list_triggers(self) -> list[Trigger]:
        """List all triggers for the authenticated user."""
        raw = await self._http.get("/v1/triggers")
        return [_parse_trigger(t) for t in (raw.get("data") or [])]

    async def toggle_trigger(self, trigger_id: int, *, is_active: bool) -> Trigger:
        """Toggle a trigger on or off."""
        raw = await self._http.patch(f"/v1/triggers/{trigger_id}", {"is_active": is_active})
        return _parse_trigger(raw)

    async def delete_trigger(self, trigger_id: int) -> None:
        """Delete a trigger."""
        await self._http.delete(f"/v1/triggers/{trigger_id}")

    async def test_trigger(self, rule: dict[str, Any], event: dict[str, Any]) -> bool:
        """Test a trigger rule against a sample event. Returns whether it matched."""
        raw = await self._http.post("/v1/triggers/test", {"rule": rule, "event": event})
        return raw["matched"]

    # ─── Cohorts ────────────────────────────────────────────────────────

    async def list_cohorts(self) -> list[CohortInfo]:
        """List predefined and custom cohorts."""
        raw = await self._http.get("/v1/cohorts")
        return [_parse_cohort_info(c) for c in raw["data"]]

    async def create_cohort(self, name: str, addresses: list[str]) -> CohortInfo:
        """Create a custom address cohort."""
        raw = await self._http.post("/v1/cohorts", {"name": name, "addresses": addresses})
        return _parse_cohort_info(raw)

    async def cohort_addresses(self, name: str) -> CohortAddresses:
        """Get addresses in a cohort."""
        raw = await self._http.get(f"/v1/cohorts/{name}")
        return CohortAddresses(
            addresses=[_parse_cohort_address_entry(a) for a in (raw.get("addresses") or [])],
            fetched_at=raw.get("fetched_at", 0),
        )

    async def delete_cohort(self, name: str) -> None:
        """Delete a custom cohort."""
        await self._http.delete(f"/v1/cohorts/{name}")

    # ─── Analytics (Builder+ only) ─────────────────────────────────────

    async def net_flows(self, **options: Any) -> list[NetFlow]:
        """Get net deposit/withdrawal flows over time."""
        raw = await self._http.get("/v1/analytics/net-flows", options)
        return [_parse_net_flow(f) for f in raw["data"]]

    async def liquidation_levels(self, market: str, **options: Any) -> list[LiquidationLevel]:
        """Get liquidations bucketed by price level (heatmap data)."""
        raw = await self._http.get("/v1/analytics/liquidation-levels", {"market": market, **options})
        return [_parse_liquidation_level(l) for l in raw["data"]]

    async def order_flow(self, **options: Any) -> list[OrderFlow]:
        """Get fill and cancel rates per market."""
        raw = await self._http.get("/v1/analytics/order-flow", options)
        return [_parse_order_flow(f) for f in raw["data"]]

    async def vault_leaderboard(self, **options: Any) -> list[VaultLeaderboardEntry]:
        """Get vaults ranked by net deposits."""
        raw = await self._http.get("/v1/analytics/vault-leaderboard", options)
        return [_parse_vault_leaderboard(v) for v in raw["data"]]

    async def funding_stats(self, market: str, **options: Any) -> list[FundingStats]:
        """Get funding rate statistics over time."""
        raw = await self._http.get("/v1/analytics/funding-stats", {"market": market, **options})
        return [_parse_funding_stats(f) for f in raw["data"]]

    # ─── Markets registry ──────────────────────────────────────────────

    async def markets(
        self,
        *,
        source: str | None = None,
        market_class: str | None = None,
        issuer: str | None = None,
    ) -> list[Market]:
        """List active markets from the registry.

        Reads Postgres directly — no ClickHouse round-trip and no per-tier
        query window applies. Filter by ``market_class`` ("perp" | "spot")
        or ``issuer`` (HIP-3 builder code). Pass ``issuer=""`` to return
        only native non-builder markets.
        """
        params: dict[str, Any] = {}
        if source is not None:
            params["source"] = source
        if market_class is not None:
            params["market_class"] = market_class
        if issuer is not None:
            params["issuer"] = issuer
        raw = await self._http.get("/v1/markets", params)
        return [Market(**_only_fields(Market, m)) for m in raw.get("data", [])]

    # ─── Status ────────────────────────────────────────────────────────

    async def status(self) -> StatusResponse:
        """Get system status and data freshness (unauthenticated)."""
        raw = await self._http.get("/v1/status")
        venues: dict[str, VenueStatus] = {}
        for vname, vdata in raw.get("venues", {}).items():
            streams = {
                sname: DataFreshness(**sdata)
                for sname, sdata in vdata.get("streams", {}).items()
            }
            events = {
                ename: DataFreshness(**edata)
                for ename, edata in vdata.get("events", {}).items()
            }
            venues[vname] = VenueStatus(
                status=vdata.get("status", "operational"),
                markets=vdata.get("markets", 0),
                streams=streams,
                events=events,
            )
        platform = None
        if "platform" in raw and raw["platform"] is not None:
            platform = PlatformStats(**raw["platform"])
        return StatusResponse(
            status=raw["status"],
            timestamp=raw.get("timestamp", 0),
            uptime=raw.get("uptime", ""),
            venues=venues,
            platform=platform,
        )

    # ─── Account ────────────────────────────────────────────────────────

    async def me(self) -> MeResponse:
        """Get the authenticated user's tier and rate limits."""
        raw = await self._http.get("/v1/me")
        limits_raw = raw.get("limits", {})
        return MeResponse(
            tier=raw.get("tier", ""),
            active=raw.get("active", False),
            limits=MeLimits(
                requests_per_min=limits_raw.get("requests_per_min", 0),
                info_requests_per_min=limits_raw.get("info_requests_per_min", 0),
                history_window_ms=limits_raw.get("history_window_ms", 0),
                websocket_connections=limits_raw.get("websocket_connections", 0),
                address_tracking=limits_raw.get("address_tracking", 0),
                full_analytics=limits_raw.get("full_analytics", False),
            ),
        )

    async def status_metrics(self) -> StatusMetricsResponse:
        """Get rolling-window API + pipeline + synthetic metrics (unauthenticated)."""
        raw = await self._http.get("/v1/status/metrics")
        return StatusMetricsResponse(
            timestamp=raw.get("timestamp", 0),
            api=APIMetrics(**_only_fields(APIMetrics, raw.get("api", {}))),
            pipeline=PipelineMetrics(**_only_fields(PipelineMetrics, raw.get("pipeline", {}))),
            synthetic=SyntheticMetrics(
                ws_latency_ms=raw.get("synthetic", {}).get("ws_latency_ms", 0.0),
                ws_latency_p50_ms=raw.get("synthetic", {}).get("ws_latency_p50_ms", 0.0),
                query_latencies=raw.get("synthetic", {}).get("query_latencies", {}) or {},
            ),
        )

    async def status_history(self, period: str | None = None) -> StatusHistoryResponse:
        """Get an uptime / freshness timeline (unauthenticated).

        ``period`` accepts ``"24h"`` (default) or ``"7d"``.
        """
        params: dict[str, Any] = {}
        if period is not None:
            params["period"] = period
        raw = await self._http.get("/v1/status/history", params)
        points = [UptimePoint(**_only_fields(UptimePoint, p)) for p in raw.get("points", []) or []]
        return StatusHistoryResponse(
            period=raw.get("period", ""),
            uptime_percent=raw.get("uptime_percent", 0.0),
            points=points,
        )

    async def healthz(self) -> HealthResponse:
        """Liveness probe (unauthenticated)."""
        raw = await self._http.get("/healthz")
        return HealthResponse(status=raw.get("status", ""))

    # ─── Info API ───────────────────────────────────────────────────────

    async def info(self, request: dict[str, Any]) -> Any:
        """Proxy request to the Hyperliquid Info API."""
        return await self._http.post("/v1/info", request)

    # ─── Export ─────────────────────────────────────────────────────────

    async def export_data(
        self,
        event_type: str,
        *,
        market: str | None = None,
        from_ts: int | None = None,
        to_ts: int | None = None,
        format: str = "csv",
    ) -> bytes:
        """Export data as CSV or Parquet (Builder+ only). Returns raw bytes."""
        params: dict[str, Any] = {"event_type": event_type, "format": format}
        if market is not None:
            params["market"] = market
        if from_ts is not None:
            params["from"] = from_ts
        if to_ts is not None:
            params["to"] = to_ts
        return await self._http.get_raw("/v1/export", params)

    # ─── Lifecycle ──────────────────────────────────────────────────────

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    async def __aenter__(self) -> "Ironflow":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # ─── Helpers ────────────────────────────────────────────────────────

    async def _paginated(
        self,
        path: str,
        params: dict[str, Any],
        parser: Any,
    ) -> Page[Any]:
        raw = await self._http.get(path, params)
        data = [parser(item) for item in raw["data"]]
        pagination = raw["pagination"]

        async def fetch_next(cursor: str) -> Page[Any]:
            return await self._paginated(path, {**params, "cursor": cursor}, parser)

        return Page(
            data=data,
            has_more=pagination["has_more"],
            next_cursor=pagination.get("next_cursor"),
            next_fn=fetch_next,
        )
