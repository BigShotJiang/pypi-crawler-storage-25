# WebSocket streaming for the Ironflow API.
# Returns async generators for each channel.

from __future__ import annotations

import json
from collections.abc import AsyncGenerator
from typing import TYPE_CHECKING, Any, Callable, TypeVar

from websockets.asyncio.client import connect

if TYPE_CHECKING:
    from .client import HttpClient

T = TypeVar("T")

from .types import (
    BookLevel, BookSnapshot, Deposit, FundingRate, Liquidation,
    OrderStatus, Trade, VaultOperation, Withdrawal,
)


_TYPE_DEFAULTS: dict[str, Any] = {"str": "", "int": 0, "float": 0.0, "bool": False}


def _only(cls: Any, d: dict[str, Any]) -> dict[str, Any]:
    """Build kwargs for a dataclass: drop unknown keys, and fill missing required
    fields with type-appropriate zero values.

    WS events are venue-native and often lack some of the normalized fields the
    REST `Trade`/`Liquidation`/etc. dataclasses declare as required. Filling
    with zero-values lets the typed wrapper succeed; callers can check whether
    a field is the zero value if they need to distinguish.
    """
    kept = {k: v for k, v in d.items() if k in cls.__dataclass_fields__}
    for name, field in cls.__dataclass_fields__.items():
        if name in kept:
            continue
        # Skip fields that already have a default/default_factory.
        import dataclasses as _dc
        if field.default is not _dc.MISSING or field.default_factory is not _dc.MISSING:  # type: ignore[misc]
            continue
        type_name = getattr(field.type, "__name__", str(field.type))
        kept[name] = _TYPE_DEFAULTS.get(type_name, None)
    return kept


def _add_routing(opts: dict[str, Any], *, base_market: str | None, issuer: str | None) -> None:
    """Attach optional HIP-3 routing fields to a subscribe payload."""
    if base_market is not None:
        opts["base_market"] = base_market
    if issuer is not None:
        opts["issuer"] = issuer


def _parse_trade(d: dict[str, Any]) -> Trade:
    return Trade(**_only(Trade, d))


def _parse_book(d: dict[str, Any]) -> BookSnapshot:
    return BookSnapshot(
        source=d["source"],
        market=d["market"],
        issuer=d.get("issuer", ""),
        base_market=d.get("base_market", ""),
        timestamp=d["timestamp"],
        bids=[BookLevel(**_only(BookLevel, b)) for b in d["bids"]],
        asks=[BookLevel(**_only(BookLevel, a)) for a in d["asks"]],
    )


class StreamClient:
    """WebSocket streaming client. Each method returns an AsyncGenerator."""

    def __init__(self, http: "HttpClient", source: str = "hyperliquid") -> None:
        self._http = http
        self._source = source

    def trades(
        self,
        market: str,
        *,
        min_size: str | None = None,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[Trade, None]:
        opts: dict[str, Any] = {"channel": "trades", "market": market}
        if min_size is not None:
            opts["min_size"] = min_size
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, _parse_trade)

    def fills(
        self,
        address: str,
        *,
        market: str | None = None,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[Trade, None]:
        opts: dict[str, Any] = {"channel": "fills", "address": address}
        if market is not None:
            opts["market"] = market
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, _parse_trade)

    def book(
        self,
        market: str,
        *,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[BookSnapshot, None]:
        opts: dict[str, Any] = {"channel": "book", "market": market}
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, _parse_book)

    def book_l4(
        self,
        market: str,
        *,
        depth: int | None = None,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[BookSnapshot, None]:
        opts: dict[str, Any] = {"channel": "book_l4", "market": market}
        if depth is not None:
            opts["depth"] = depth
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, _parse_book)

    def orders(
        self,
        address: str,
        *,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[OrderStatus, None]:
        opts: dict[str, Any] = {"channel": "orders", "address": address}
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, lambda d: OrderStatus(**_only(OrderStatus, d)))

    def liquidations(
        self,
        market: str,
        *,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[Liquidation, None]:
        opts: dict[str, Any] = {"channel": "liquidations", "market": market}
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, lambda d: Liquidation(**_only(Liquidation, d)))

    def funding_rates(
        self,
        market: str,
        *,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[FundingRate, None]:
        opts: dict[str, Any] = {"channel": "funding_rate", "market": market}
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, lambda d: FundingRate(**_only(FundingRate, d)))

    def deposits(
        self,
        *,
        address: str | None = None,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[Deposit, None]:
        opts: dict[str, Any] = {"channel": "deposits"}
        if address is not None:
            opts["address"] = address
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, lambda d: Deposit(**_only(Deposit, d)))

    def withdrawals(
        self,
        *,
        address: str | None = None,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[Withdrawal, None]:
        opts: dict[str, Any] = {"channel": "withdrawals"}
        if address is not None:
            opts["address"] = address
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, lambda d: Withdrawal(**_only(Withdrawal, d)))

    def vault_operations(
        self,
        *,
        address: str | None = None,
        vault: str | None = None,
        base_market: str | None = None,
        issuer: str | None = None,
    ) -> AsyncGenerator[VaultOperation, None]:
        opts: dict[str, Any] = {"channel": "vault_operations"}
        if address is not None:
            opts["address"] = address
        if vault is not None:
            opts["vault"] = vault
        _add_routing(opts, base_market=base_market, issuer=issuer)
        return self._subscribe(opts, lambda d: VaultOperation(**_only(VaultOperation, d)))

    async def _subscribe(self, options: dict[str, Any], parser: Callable[[dict[str, Any]], Any]) -> AsyncGenerator[Any, None]:
        sub_msg = {"op": "subscribe", "source": self._source, **options}
        ws_url = await self._http.get_ws_url()
        async with connect(ws_url) as ws:
            await ws.send(json.dumps(sub_msg))
            async for raw in ws:
                try:
                    msg = json.loads(raw)
                    if msg.get("op") == "ping":
                        await ws.send(json.dumps({"op": "pong"}))
                        continue
                    if msg.get("op") != "data":
                        continue
                    # Merge outer envelope fields (source, market, timestamp) into the
                    # inner data payload. WS events carry venue-native fields inside
                    # `data` and the normalized context (source/market/timestamp) on
                    # the outer envelope.
                    data = msg["data"] if isinstance(msg.get("data"), dict) else {}
                    merged = {
                        "source": msg.get("source", ""),
                        "market": msg.get("market", ""),
                        "issuer": msg.get("issuer", ""),
                        "base_market": msg.get("base_market", ""),
                        "timestamp": msg.get("timestamp", 0),
                        **data,
                    }
                    yield parser(merged)
                except (json.JSONDecodeError, KeyError, TypeError):
                    continue
