"""Tests for LangChain and CrewAI tool wrappers."""

import importlib

import pytest
import httpx
import respx

BASE = "https://api.voke.run"

_has_langchain = importlib.util.find_spec("langchain_core") is not None
_has_crewai = importlib.util.find_spec("crewai") is not None or importlib.util.find_spec("crewai_tools") is not None


# ---------------------------------------------------------------------------
# LangChain tool
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not _has_langchain, reason="langchain not installed")
class TestLangChainTool:
    def test_run_calls_create_and_wait(self, respx_mock: respx.MockRouter):
        # Mock job creation
        respx_mock.post(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                202, json={"id": "lc-1", "status": "queued"}
            )
        )
        # Mock polling: first running, then completed
        call_count = 0

        def poll_handler(request):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                return httpx.Response(200, json={"id": "lc-1", "status": "running"})
            return httpx.Response(
                200,
                json={
                    "id": "lc-1",
                    "status": "completed",
                    "exit_code": 0,
                    "stdout": "arm64\n",
                    "stderr": "",
                },
            )

        respx_mock.get(f"{BASE}/v1/jobs/lc-1").mock(side_effect=poll_handler)

        from voke.tools.langchain import VokeRunTool

        tool = VokeRunTool(api_key="sk_test")
        result = tool._run(script="uname -m")
        assert "exit_code: 0" in result
        assert "arm64" in result

    def test_run_shows_stderr(self, respx_mock: respx.MockRouter):
        respx_mock.post(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                202, json={"id": "lc-2", "status": "queued"}
            )
        )
        respx_mock.get(f"{BASE}/v1/jobs/lc-2").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "lc-2",
                    "status": "completed",
                    "exit_code": 1,
                    "stdout": "",
                    "stderr": "command not found",
                },
            )
        )

        from voke.tools.langchain import VokeRunTool

        tool = VokeRunTool(api_key="sk_test")
        result = tool._run(script="bad_command")
        assert "exit_code: 1" in result
        assert "command not found" in result


# ---------------------------------------------------------------------------
# CrewAI tool
# ---------------------------------------------------------------------------


@pytest.mark.skipif(not _has_crewai, reason="crewai not installed")
class TestCrewAITool:
    def test_run_calls_create_and_wait(self, respx_mock: respx.MockRouter):
        respx_mock.post(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                202, json={"id": "cr-1", "status": "queued"}
            )
        )
        respx_mock.get(f"{BASE}/v1/jobs/cr-1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "cr-1",
                    "status": "completed",
                    "exit_code": 0,
                    "stdout": "macOS\n",
                    "stderr": "",
                },
            )
        )

        from voke.tools.crewai import VokeTool

        tool = VokeTool(api_key="sk_test")
        result = tool._run(script="uname")
        assert "exit_code: 0" in result
        assert "macOS" in result
