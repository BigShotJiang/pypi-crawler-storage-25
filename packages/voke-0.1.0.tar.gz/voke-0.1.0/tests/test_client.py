"""Tests for Voke sync and async clients."""

import pytest
import httpx
import respx
from respx.patterns import M

from voke import Voke, AsyncVoke
from voke.errors import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ValidationError,
    VokeError,
)


BASE = "https://api.voke.run"


# ---------------------------------------------------------------------------
# Sync client tests
# ---------------------------------------------------------------------------


class TestSyncClient:
    def test_create_job(self, respx_mock: respx.MockRouter):
        respx_mock.post(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                202,
                json={"id": "job-1", "status": "queued", "estimated_wait_seconds": 60},
            )
        )
        client = Voke(api_key="sk_test")
        job = client.jobs.create(script="uname -m")
        assert job.id == "job-1"
        assert job.status == "queued"

    def test_get_job(self, respx_mock: respx.MockRouter):
        respx_mock.get(f"{BASE}/v1/jobs/job-1").mock(
            return_value=httpx.Response(
                200,
                json={
                    "id": "job-1",
                    "status": "completed",
                    "exit_code": 0,
                    "stdout": "arm64\n",
                    "stderr": "",
                    "duration_seconds": 12.5,
                },
            )
        )
        client = Voke(api_key="sk_test")
        job = client.jobs.get("job-1")
        assert job.status == "completed"
        assert job.exit_code == 0
        assert job.stdout == "arm64\n"

    def test_list_jobs(self, respx_mock: respx.MockRouter):
        respx_mock.get(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                200,
                json={
                    "jobs": [
                        {"id": "job-1", "status": "completed", "created_at": 1000},
                        {"id": "job-2", "status": "running", "created_at": 1001},
                    ],
                    "total": 2,
                    "limit": 20,
                    "offset": 0,
                },
            )
        )
        client = Voke(api_key="sk_test")
        result = client.jobs.list()
        assert result.total == 2
        assert len(result.jobs) == 2

    def test_cancel_job(self, respx_mock: respx.MockRouter):
        respx_mock.delete(f"{BASE}/v1/jobs/job-1").mock(
            return_value=httpx.Response(200, json={"id": "job-1", "status": "cancelled"})
        )
        client = Voke(api_key="sk_test")
        job = client.jobs.cancel("job-1")
        assert job.status == "cancelled"

    def test_wait_polls_until_terminal(self, respx_mock: respx.MockRouter):
        call_count = 0

        def handler(request):
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                return httpx.Response(200, json={"id": "job-1", "status": "running"})
            return httpx.Response(
                200,
                json={
                    "id": "job-1",
                    "status": "completed",
                    "exit_code": 0,
                    "stdout": "done",
                    "stderr": "",
                },
            )

        respx_mock.get(f"{BASE}/v1/jobs/job-1").mock(side_effect=handler)
        client = Voke(api_key="sk_test")
        job = client._poll_job("job-1", poll_interval=0.01)
        assert job.status == "completed"
        assert call_count == 3

    def test_auth_error_401(self, respx_mock: respx.MockRouter):
        respx_mock.get(f"{BASE}/v1/jobs/x").mock(
            return_value=httpx.Response(
                401,
                json={"detail": {"error": "missing_auth", "message": "No auth header"}},
            )
        )
        client = Voke(api_key="sk_test")
        with pytest.raises(AuthenticationError):
            client.jobs.get("x")

    def test_not_found_error(self, respx_mock: respx.MockRouter):
        respx_mock.get(f"{BASE}/v1/jobs/nope").mock(
            return_value=httpx.Response(
                404,
                json={"detail": {"error": "not_found", "message": "Job not found"}},
            )
        )
        client = Voke(api_key="sk_test")
        with pytest.raises(NotFoundError):
            client.jobs.get("nope")

    def test_rate_limit_error(self, respx_mock: respx.MockRouter):
        respx_mock.post(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                429,
                json={"detail": {"error": "rate_limited", "message": "Slow down"}},
            )
        )
        client = Voke(api_key="sk_test")
        with pytest.raises(RateLimitError):
            client.jobs.create(script="echo hi")

    def test_validation_error(self, respx_mock: respx.MockRouter):
        respx_mock.post(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                400,
                json={"detail": {"error": "empty_script", "message": "Script is empty"}},
            )
        )
        client = Voke(api_key="sk_test")
        with pytest.raises(ValidationError):
            client.jobs.create(script="")

    def test_images_sends_auth_header(self, respx_mock: respx.MockRouter):
        route = respx_mock.get(f"{BASE}/v1/images").mock(
            return_value=httpx.Response(
                200,
                json={"base": {"name": "base", "description": "Clean macOS"}},
            )
        )
        client = Voke(api_key="sk_test")
        result = client.images()
        assert "base" in result
        # Verify the Authorization header was sent
        assert route.calls[0].request.headers["authorization"] == "Bearer sk_test"

    def test_retry_on_500(self, respx_mock: respx.MockRouter):
        call_count = 0

        def handler(request):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return httpx.Response(500, json={"detail": {"error": "internal", "message": "Oops"}})
            return httpx.Response(
                200,
                json={"id": "job-1", "status": "queued", "estimated_wait_seconds": 60},
            )

        respx_mock.post(f"{BASE}/v1/jobs").mock(side_effect=handler)
        client = Voke(api_key="sk_test")
        job = client.jobs.create(script="echo hello")
        assert job.id == "job-1"
        assert call_count == 2

    def test_labels_sent_in_create(self, respx_mock: respx.MockRouter):
        route = respx_mock.post(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                202,
                json={"id": "job-1", "status": "queued"},
            )
        )
        client = Voke(api_key="sk_test")
        client.jobs.create(script="echo hi", labels={"env": "test", "team": "ci"})
        import json as _json
        sent_body = _json.loads(route.calls[0].request.content)
        assert sent_body["labels"] == {"env": "test", "team": "ci"}


# ---------------------------------------------------------------------------
# Async client tests
# ---------------------------------------------------------------------------


class TestAsyncClient:
    @pytest.mark.asyncio
    async def test_create_job(self, respx_mock: respx.MockRouter):
        respx_mock.post(f"{BASE}/v1/jobs").mock(
            return_value=httpx.Response(
                202, json={"id": "job-a", "status": "queued"}
            )
        )
        client = AsyncVoke(api_key="sk_test")
        job = await client.jobs.create(script="uname -m")
        assert job.id == "job-a"
        await client.close()

    @pytest.mark.asyncio
    async def test_images_sends_auth_header(self, respx_mock: respx.MockRouter):
        route = respx_mock.get(f"{BASE}/v1/images").mock(
            return_value=httpx.Response(
                200,
                json={"base": {"name": "base", "description": "Clean macOS"}},
            )
        )
        client = AsyncVoke(api_key="sk_test")
        result = await client.images()
        assert "base" in result
        # Verify the Authorization header was sent
        assert route.calls[0].request.headers["authorization"] == "Bearer sk_test"
        await client.close()

    @pytest.mark.asyncio
    async def test_poll_async(self, respx_mock: respx.MockRouter):
        call_count = 0

        def handler(request):
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                return httpx.Response(200, json={"id": "job-a", "status": "running"})
            return httpx.Response(
                200,
                json={"id": "job-a", "status": "completed", "exit_code": 0, "stdout": "ok"},
            )

        respx_mock.get(f"{BASE}/v1/jobs/job-a").mock(side_effect=handler)
        client = AsyncVoke(api_key="sk_test")
        job = await client._poll_job("job-a", poll_interval=0.01)
        assert job.status == "completed"
        await client.close()
