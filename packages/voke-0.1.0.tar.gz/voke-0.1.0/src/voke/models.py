"""Pydantic v2 models for the Voke API."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class Job(BaseModel):
    """A single Voke job (full detail)."""

    id: str
    status: str
    image: Optional[str] = None
    script: Optional[str] = None
    timeout: Optional[int] = None
    created_at: Optional[float] = None
    dispatched_at: Optional[float] = None
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    duration_seconds: Optional[float] = None
    exit_code: Optional[int] = None
    stdout: Optional[str] = None
    stderr: Optional[str] = None
    error: Optional[str] = None
    worker_id: Optional[str] = None
    webhook_url: Optional[str] = None
    artifacts: Optional[List[str]] = None
    estimated_wait_seconds: Optional[float] = None

    # Populated by the client so .wait() can poll
    _client: Any = None

    model_config = {"extra": "allow"}

    def _bind(self, client: Any) -> "Job":
        object.__setattr__(self, "_client", client)
        return self

    def wait(self, poll_interval: float = 1.5, timeout: Optional[float] = None) -> "Job":
        """Synchronously poll until the job reaches a terminal state."""
        client = object.__getattribute__(self, "_client")
        if client is None:
            raise RuntimeError("Job is not bound to a client. Use client.jobs.create() or client.jobs.get().")
        return client._poll_job(self.id, poll_interval=poll_interval, timeout=timeout)

    async def async_wait(self, poll_interval: float = 1.5, timeout: Optional[float] = None) -> "Job":
        """Asynchronously poll until the job reaches a terminal state."""
        client = object.__getattribute__(self, "_client")
        if client is None:
            raise RuntimeError("Job is not bound to a client. Use client.jobs.create() or client.jobs.get().")
        return await client._poll_job(self.id, poll_interval=poll_interval, timeout=timeout)

    @property
    def is_terminal(self) -> bool:
        return self.status in ("completed", "failed", "cancelled", "timeout")


class JobSummary(BaseModel):
    """A job as returned by the list endpoint (fewer fields)."""

    id: str
    status: str
    image: Optional[str] = None
    created_at: Optional[float] = None
    completed_at: Optional[float] = None
    duration_seconds: Optional[float] = None
    exit_code: Optional[int] = None
    worker_id: Optional[str] = None

    model_config = {"extra": "allow"}


class JobList(BaseModel):
    """Paginated list of jobs."""

    jobs: List[JobSummary]
    total: int
    limit: int
    offset: int


class ImageInfo(BaseModel):
    """Available macOS image."""

    name: str
    description: Optional[str] = None
    os: Optional[str] = None
    size_gb: Optional[float] = None
    preinstalled: Optional[List[str]] = None

    model_config = {"extra": "allow"}


class MonthUsage(BaseModel):
    jobs: Optional[int] = None
    minutes_used: Optional[float] = None
    free_minutes_remaining: Optional[float] = None
    billable_minutes: Optional[float] = None
    rate_per_minute: Optional[str] = None
    estimated_bill_usd: Optional[float] = None

    model_config = {"extra": "allow"}


class UsageResponse(BaseModel):
    """Account usage information."""

    tier: Optional[str] = None
    billing_period: Optional[str] = None
    this_month: Optional[MonthUsage] = None
    # Alternative flat fields from some API versions
    free_minutes_total: Optional[float] = None
    free_minutes_used: Optional[float] = None
    free_minutes_remaining: Optional[float] = None
    jobs_this_month: Optional[int] = None

    model_config = {"extra": "allow"}
