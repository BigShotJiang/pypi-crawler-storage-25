"""Voke API client — sync and async."""

from __future__ import annotations

import os
import time
import asyncio
from typing import Any, Dict, List, Optional

import httpx

from voke.errors import raise_for_status
from voke.models import Job, JobList, ImageInfo, UsageResponse

TERMINAL_STATUSES = frozenset({"completed", "failed", "cancelled", "timeout"})


# ---------------------------------------------------------------------------
# Sync client
# ---------------------------------------------------------------------------


class _SyncJobsResource:
    """jobs.create / .get / .list / .cancel"""

    def __init__(self, client: "Voke"):
        self._c = client

    def create(
        self,
        script: str,
        *,
        image: str = "base",
        timeout: int = 600,
        env: Optional[Dict[str, str]] = None,
        labels: Optional[Dict[str, str]] = None,
        webhook_url: Optional[str] = None,
    ) -> Job:
        body: Dict[str, Any] = {"script": script, "image": image, "timeout": timeout}
        if webhook_url:
            body["webhook_url"] = webhook_url
        if labels:
            body["labels"] = labels
        # Env vars: prepend exports to script
        if env:
            exports = "\n".join(f'export {k}={_shell_quote(v)}' for k, v in env.items())
            body["script"] = f"{exports}\n{script}"
        resp = self._c._request("POST", "/v1/jobs", json=body)
        return Job.model_validate(resp)._bind(self._c)

    def get(self, job_id: str) -> Job:
        resp = self._c._request("GET", f"/v1/jobs/{job_id}")
        return Job.model_validate(resp)._bind(self._c)

    def list(
        self,
        *,
        limit: int = 20,
        offset: int = 0,
        status: Optional[str] = None,
    ) -> JobList:
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        resp = self._c._request("GET", "/v1/jobs", params=params)
        return JobList.model_validate(resp)

    def cancel(self, job_id: str) -> Job:
        resp = self._c._request("DELETE", f"/v1/jobs/{job_id}")
        return Job.model_validate(resp)._bind(self._c)


class Voke:
    """Synchronous Voke API client."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.voke.run",
        *,
        http_client: Optional[httpx.Client] = None,
    ):
        self.api_key = api_key or os.environ.get("VOKE_API_KEY", "")
        self.base_url = base_url.rstrip("/")
        self._http = http_client or httpx.Client(timeout=30.0)
        self.jobs = _SyncJobsResource(self)

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
        }

    def _request(
        self, method: str, path: str, *, json: Any = None, params: Any = None
    ) -> Any:
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                resp = self._http.request(
                    method,
                    f"{self.base_url}{path}",
                    headers=self._headers(),
                    json=json,
                    params=params,
                )
            except httpx.TransportError:
                if attempt >= max_attempts - 1:
                    raise
                time.sleep(0.5 * 2**attempt)
                continue

            if resp.status_code == 429:
                if attempt >= max_attempts - 1:
                    body = resp.json() if resp.content else {}
                    raise_for_status(resp.status_code, body)
                retry_after = resp.headers.get("Retry-After")
                wait = float(retry_after) if retry_after else 2.0
                time.sleep(wait)
                continue

            if resp.status_code >= 500:
                if attempt >= max_attempts - 1:
                    body = resp.json() if resp.content else {}
                    raise_for_status(resp.status_code, body)
                time.sleep(0.5 * 2**attempt)
                continue

            body = resp.json() if resp.content else {}
            raise_for_status(resp.status_code, body)
            return body

        # Unreachable, but satisfies type checker
        raise RuntimeError("Exhausted retries")

    def _poll_job(
        self,
        job_id: str,
        *,
        poll_interval: float = 1.5,
        timeout: Optional[float] = None,
    ) -> Job:
        deadline = time.time() + timeout if timeout else None
        while True:
            job = self.jobs.get(job_id)
            if job.is_terminal:
                return job
            if deadline and time.time() >= deadline:
                raise TimeoutError(f"Job {job_id} did not finish within {timeout}s")
            time.sleep(poll_interval)

    def images(self) -> Dict[str, ImageInfo]:
        resp = self._request("GET", "/v1/images")
        return {k: ImageInfo.model_validate(v) for k, v in resp.items()}

    def usage(self) -> UsageResponse:
        resp = self._request("GET", "/v1/auth/usage")
        return UsageResponse.model_validate(resp)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "Voke":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------


class _AsyncJobsResource:
    """Async jobs.create / .get / .list / .cancel"""

    def __init__(self, client: "AsyncVoke"):
        self._c = client

    async def create(
        self,
        script: str,
        *,
        image: str = "base",
        timeout: int = 600,
        env: Optional[Dict[str, str]] = None,
        labels: Optional[Dict[str, str]] = None,
        webhook_url: Optional[str] = None,
    ) -> Job:
        body: Dict[str, Any] = {"script": script, "image": image, "timeout": timeout}
        if webhook_url:
            body["webhook_url"] = webhook_url
        if labels:
            body["labels"] = labels
        if env:
            exports = "\n".join(f'export {k}={_shell_quote(v)}' for k, v in env.items())
            body["script"] = f"{exports}\n{script}"
        resp = await self._c._request("POST", "/v1/jobs", json=body)
        return Job.model_validate(resp)._bind(self._c)

    async def get(self, job_id: str) -> Job:
        resp = await self._c._request("GET", f"/v1/jobs/{job_id}")
        return Job.model_validate(resp)._bind(self._c)

    async def list(
        self,
        *,
        limit: int = 20,
        offset: int = 0,
        status: Optional[str] = None,
    ) -> JobList:
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        resp = await self._c._request("GET", "/v1/jobs", params=params)
        return JobList.model_validate(resp)

    async def cancel(self, job_id: str) -> Job:
        resp = await self._c._request("DELETE", f"/v1/jobs/{job_id}")
        return Job.model_validate(resp)._bind(self._c)


class AsyncVoke:
    """Asynchronous Voke API client."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.voke.run",
        *,
        http_client: Optional[httpx.AsyncClient] = None,
    ):
        self.api_key = api_key or os.environ.get("VOKE_API_KEY", "")
        self.base_url = base_url.rstrip("/")
        self._http = http_client or httpx.AsyncClient(timeout=30.0)
        self.jobs = _AsyncJobsResource(self)

    def _headers(self) -> Dict[str, str]:
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
        }

    async def _request(
        self, method: str, path: str, *, json: Any = None, params: Any = None
    ) -> Any:
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                resp = await self._http.request(
                    method,
                    f"{self.base_url}{path}",
                    headers=self._headers(),
                    json=json,
                    params=params,
                )
            except httpx.TransportError:
                if attempt >= max_attempts - 1:
                    raise
                await asyncio.sleep(0.5 * 2**attempt)
                continue

            if resp.status_code == 429:
                if attempt >= max_attempts - 1:
                    body = resp.json() if resp.content else {}
                    raise_for_status(resp.status_code, body)
                retry_after = resp.headers.get("Retry-After")
                wait = float(retry_after) if retry_after else 2.0
                await asyncio.sleep(wait)
                continue

            if resp.status_code >= 500:
                if attempt >= max_attempts - 1:
                    body = resp.json() if resp.content else {}
                    raise_for_status(resp.status_code, body)
                await asyncio.sleep(0.5 * 2**attempt)
                continue

            body = resp.json() if resp.content else {}
            raise_for_status(resp.status_code, body)
            return body

        # Unreachable, but satisfies type checker
        raise RuntimeError("Exhausted retries")

    async def _poll_job(
        self,
        job_id: str,
        *,
        poll_interval: float = 1.5,
        timeout: Optional[float] = None,
    ) -> Job:
        deadline = time.time() + timeout if timeout else None
        while True:
            job = await self.jobs.get(job_id)
            if job.is_terminal:
                return job
            if deadline and time.time() >= deadline:
                raise TimeoutError(f"Job {job_id} did not finish within {timeout}s")
            await asyncio.sleep(poll_interval)

    async def images(self) -> Dict[str, ImageInfo]:
        resp = await self._request("GET", "/v1/images")
        return {k: ImageInfo.model_validate(v) for k, v in resp.items()}

    async def usage(self) -> UsageResponse:
        resp = await self._request("GET", "/v1/auth/usage")
        return UsageResponse.model_validate(resp)

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncVoke":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _shell_quote(s: str) -> str:
    """Simple shell quoting for env var values."""
    return "'" + s.replace("'", "'\\''") + "'"
