"""Voke SDK error hierarchy."""

from __future__ import annotations

from typing import Any, Optional


class VokeError(Exception):
    """Base exception for all Voke SDK errors."""

    def __init__(
        self,
        message: str,
        *,
        status_code: Optional[int] = None,
        error_code: Optional[str] = None,
        body: Optional[Any] = None,
    ):
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code
        self.body = body


class AuthenticationError(VokeError):
    """Raised on 401 or 403 responses."""


class RateLimitError(VokeError):
    """Raised on 429 responses."""


class NotFoundError(VokeError):
    """Raised on 404 responses."""


class ValidationError(VokeError):
    """Raised on 400 responses."""


def raise_for_status(status_code: int, body: Any) -> None:
    """Map HTTP status codes to typed exceptions."""
    if 200 <= status_code < 300:
        return

    detail = body if isinstance(body, dict) else {}
    if "detail" in detail:
        detail = detail["detail"]

    error_code = detail.get("error", f"http_{status_code}")
    message = detail.get("message", f"HTTP {status_code}")

    kwargs = dict(status_code=status_code, error_code=error_code, body=body)

    if status_code in (401, 403):
        raise AuthenticationError(message, **kwargs)
    elif status_code == 404:
        raise NotFoundError(message, **kwargs)
    elif status_code == 429:
        raise RateLimitError(message, **kwargs)
    elif status_code == 400:
        raise ValidationError(message, **kwargs)
    else:
        raise VokeError(message, **kwargs)
