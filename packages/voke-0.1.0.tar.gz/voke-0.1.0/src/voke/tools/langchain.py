"""LangChain tool integration for Voke."""

from __future__ import annotations

from typing import Optional, Type

from pydantic import BaseModel, Field

try:
    from langchain_core.tools import BaseTool
except ImportError:
    raise ImportError(
        "langchain-core is required for the LangChain integration. "
        "Install it with: pip install voke[langchain]"
    )

from voke.client import Voke


class RunOnMacOSInput(BaseModel):
    script: str = Field(description="The bash/shell script to execute on macOS")
    image: str = Field(
        default="base",
        description='macOS image: "base" (clean macOS) or "xcode16" (with Xcode 16/Swift 6)',
    )
    timeout: int = Field(
        default=120,
        description="Max wall-clock seconds (10-600)",
    )


class VokeRunTool(BaseTool):
    """LangChain tool that runs a script on a real Apple Silicon Mac via Voke."""

    name: str = "run_on_macos"
    description: str = (
        "Run a bash script on a real Apple Silicon Mac (macOS Sonoma). "
        "The VM is ephemeral and destroyed after execution. "
        "Use for: checking macOS APIs, building Swift/Xcode projects, "
        "testing install scripts, running macOS-specific commands. "
        "Returns exit code, stdout, and stderr."
    )
    args_schema: Type[BaseModel] = RunOnMacOSInput

    api_key: Optional[str] = None
    base_url: str = "https://api.voke.run"

    def _run(self, script: str, image: str = "base", timeout: int = 120) -> str:
        client = Voke(api_key=self.api_key, base_url=self.base_url)
        try:
            job = client.jobs.create(script=script, image=image, timeout=timeout)
            result = job.wait(timeout=timeout + 120)
            lines = [f"exit_code: {result.exit_code}"]
            if result.stdout:
                lines.append(f"stdout:\n{result.stdout}")
            if result.stderr:
                lines.append(f"stderr:\n{result.stderr}")
            return "\n".join(lines)
        finally:
            client.close()

    async def _arun(self, script: str, image: str = "base", timeout: int = 120) -> str:
        from voke.client import AsyncVoke

        client = AsyncVoke(api_key=self.api_key, base_url=self.base_url)
        try:
            job = await client.jobs.create(script=script, image=image, timeout=timeout)
            result = await job.async_wait(timeout=timeout + 120)
            lines = [f"exit_code: {result.exit_code}"]
            if result.stdout:
                lines.append(f"stdout:\n{result.stdout}")
            if result.stderr:
                lines.append(f"stderr:\n{result.stderr}")
            return "\n".join(lines)
        finally:
            await client.close()
