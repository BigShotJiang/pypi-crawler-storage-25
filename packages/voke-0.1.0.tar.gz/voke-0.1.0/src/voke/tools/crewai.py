"""CrewAI tool integration for Voke."""

from __future__ import annotations

from typing import Optional, Type

from pydantic import BaseModel, Field

try:
    from crewai.tools import BaseTool
except ImportError:
    try:
        from crewai_tools import BaseTool  # type: ignore[no-redef]
    except ImportError:
        raise ImportError(
            "crewai is required for the CrewAI integration. "
            "Install it with: pip install voke[crewai]"
        )

from voke.client import Voke


class VokeToolInput(BaseModel):
    script: str = Field(description="The bash/shell script to execute on macOS")


class VokeTool(BaseTool):
    """CrewAI tool that runs a script on a real Apple Silicon Mac via Voke."""

    name: str = "Run on macOS"
    description: str = (
        "Execute a bash script on a real Apple Silicon Mac (macOS Sonoma). "
        "The VM is ephemeral and destroyed after execution. "
        "Useful for macOS-specific commands, Swift builds, Xcode projects, "
        "and testing install scripts. Returns exit code, stdout, and stderr."
    )
    args_schema: Type[BaseModel] = VokeToolInput

    api_key: Optional[str] = None
    base_url: str = "https://api.voke.run"
    image: str = "base"
    timeout: int = 120

    def _run(self, script: str) -> str:
        client = Voke(api_key=self.api_key, base_url=self.base_url)
        try:
            job = client.jobs.create(
                script=script, image=self.image, timeout=self.timeout
            )
            result = job.wait(timeout=self.timeout + 120)
            lines = [f"exit_code: {result.exit_code}"]
            if result.stdout:
                lines.append(f"stdout:\n{result.stdout}")
            if result.stderr:
                lines.append(f"stderr:\n{result.stderr}")
            return "\n".join(lines)
        finally:
            client.close()
