"""
Data models for Gitto objects (Blob, Tree, Commit).
"""

from dataclasses import asdict, dataclass
import json
from typing import Any, Optional


@dataclass
class Blob:
    """Represents raw PokePaste team content."""

    team_name: str
    raw_text: str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return asdict(self)

    def to_json(self) -> str:
        """Convert to JSON string for hashing."""
        return json.dumps(self.to_dict(), sort_keys=True)


@dataclass
class Tree:
    """
    Represents a structured snapshot of a team.
    """

    blob_hash: str
    metadata: Optional[dict[str, Any]] = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {"blob_hash": self.blob_hash, "metadata": self.metadata or {}}

    def to_json(self) -> str:
        """Convert to JSON string for hashing."""
        return json.dumps(self.to_dict(), sort_keys=True)


@dataclass
class Commit:
    """
    Represents a snapshot in time with parent references.
    Implements content-addressed storage.
    """

    tree_hash: str
    parent_hashes: list[
        str
    ]  # Can be empty (initial commit), single, or multiple (merge)
    message: str
    timestamp: int  # Unix timestamp
    author: str
    pokepaste_url: Optional[str] = None  # URL of the PokePaste used to create this commit

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        result = {
            "tree_hash": self.tree_hash,
            "parent_hashes": self.parent_hashes,
            "message": self.message,
            "timestamp": self.timestamp,
            "author": self.author,
        }
        if self.pokepaste_url is not None:
            result["pokepaste_url"] = self.pokepaste_url
        return result

    def to_json(self) -> str:
        """Convert to JSON string for hashing."""
        return json.dumps(self.to_dict(), sort_keys=True)

    @property
    def is_initial(self) -> bool:
        """Check if this is an initial commit (no parents)."""
        return len(self.parent_hashes) == 0

    @property
    def is_merge_commit(self) -> bool:
        """Check if this is a merge commit (multiple parents)."""
        return len(self.parent_hashes) > 1
