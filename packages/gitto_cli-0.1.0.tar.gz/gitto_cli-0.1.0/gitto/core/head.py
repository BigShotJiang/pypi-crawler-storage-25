import json
from typing import Optional
from pathlib import Path


class Head:
    """Manages the current team and variant state."""

    def __init__(self, head_file: Path):
        """Initialize HEAD management."""
        self.head_file = head_file
        self._ensure_initialized()

    def _ensure_initialized(self):
        """Ensure HEAD file exists."""
        if not self.head_file.exists():
            self.head_file.parent.mkdir(parents=True, exist_ok=True)
            self._write_head(None, None)

    def _write_head(self, team: Optional[str], variant: Optional[str]):
        """Write current team/variant to HEAD file."""
        data = {"team": team, "variant": variant}
        with open(self.head_file, "w", encoding="utf-8") as f:
            json.dump(data, f)

    def _read_head(self) -> tuple[Optional[str], Optional[str]]:
        """Read current team/variant from HEAD file."""
        try:
            with open(self.head_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            return data.get("team"), data.get("variant")
        except (json.JSONDecodeError, FileNotFoundError):
            return None, None

    def set_head(self, team: str, variant: str):
        """Set the current team and variant."""
        self._write_head(team, variant)

    def get_head(self) -> tuple[Optional[str], Optional[str]]:
        """Get the current team and variant."""
        return self._read_head()

    def get_team(self) -> Optional[str]:
        """Get the current team."""
        team, _ = self._read_head()
        return team

    def get_variant(self) -> Optional[str]:
        """Get the current variant."""
        _, variant = self._read_head()
        return variant

    def is_initialized(self) -> bool:
        """Check if HEAD is initialized with a team/variant."""
        team, _ = self._read_head()
        return team is not None

    def clear(self):
        """Clear HEAD (no team/variant active)."""
        self._write_head(None, None)
