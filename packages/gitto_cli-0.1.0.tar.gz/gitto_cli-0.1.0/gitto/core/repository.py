"""
Main Repository class that coordinates all core components.
"""

from pathlib import Path
from typing import Optional

from gitto.config.constants import GITTO_DIR, HEAD_FILE, OBJECTS_DIR, REFS_DIR
from gitto.core.head import Head
from gitto.storage.object_store import ObjectStore
from gitto.storage.ref_store import RefStore


class Repository:
    """
    Main repository interface.
    Coordinates object store, ref store, and HEAD management.
    """

    def __init__(self, work_dir: Path):
        """
        Initialize or open a repository.
        """
        self.work_dir = work_dir
        self.gitto_dir = work_dir / GITTO_DIR

        # Initialize core components
        self.objects = ObjectStore(self.gitto_dir / OBJECTS_DIR)
        self.refs = RefStore(self.gitto_dir / REFS_DIR)
        self.head = Head(self.gitto_dir / HEAD_FILE)

        self._ensure_initialized()

    def _ensure_initialized(self):
        """Ensure repository structure is initialized."""
        self.gitto_dir.mkdir(parents=True, exist_ok=True)

    def is_initialized(self) -> bool:
        """Check if repository is properly initialized."""
        return self.gitto_dir.exists()

    @staticmethod
    def find_repo(start_dir: Optional[Path] = None) -> Optional["Repository"]:
        """
        Find and open the nearest .gitto repository.
        """
        if start_dir is None:
            start_dir = Path.cwd()

        current = start_dir.resolve()

        while True:
            gitto_dir = current / GITTO_DIR
            if gitto_dir.exists():
                return Repository(current)

            parent = current.parent
            if parent == current:
                # Reached filesystem root
                return None

            current = parent

    def get_current_state(self) -> tuple[Optional[str], Optional[str]]:
        """
        Get current team and variant.
        """
        return self.head.get_head()

    def set_current_state(self, team: str, variant: str):
        """
        Set current team and variant.
        """
        self.head.set_head(team, variant)

    def get_logs_dir(self) -> Path:
        """Get the logs directory."""
        logs_dir = self.gitto_dir / "logs"
        logs_dir.mkdir(exist_ok=True)
        return logs_dir
