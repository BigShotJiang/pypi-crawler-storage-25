"""
Hashing utilities for content-addressed storage.
"""

import hashlib
from typing import Union

from gitto.config.constants import BLOB_TYPE, COMMIT_TYPE, TREE_TYPE
from gitto.models.objects import Blob, Commit, Tree


def hash_object(obj: Union[Blob, Commit, Tree]) -> str:
    """
    Generate SHA1 hash for a Gitto object.
    Hash = SHA1(type + size + content)
    """
    if isinstance(obj, Blob):
        obj_type = BLOB_TYPE
    elif isinstance(obj, Tree):
        obj_type = TREE_TYPE
    elif isinstance(obj, Commit):
        obj_type = COMMIT_TYPE
    else:
        raise TypeError(f"Unknown object type: {type(obj)}")

    json_str = obj.to_json()
    size = len(json_str.encode("utf-8"))

    # Create the hashable content: type + null byte + size + null byte + content
    content = f"{obj_type}\x00{size}\x00{json_str}".encode("utf-8")

    return hashlib.sha1(content).hexdigest()


def hash_string(data: str) -> str:
    """
    Generate SHA1 hash for arbitrary string data.
    """
    return hashlib.sha1(data.encode("utf-8")).hexdigest()


def get_object_type(obj_hash: str, object_bytes: bytes) -> str:
    """
    Determine the type of a stored object (blob, commit or tree) from its header.
    """
    # Parse the type from the stored format
    type_end = object_bytes.find(b"\x00")
    if type_end == -1:
        raise ValueError(f"Invalid object format for {obj_hash}")
    return object_bytes[:type_end].decode("utf-8")
