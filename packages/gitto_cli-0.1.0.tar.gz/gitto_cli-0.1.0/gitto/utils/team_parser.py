"""
Parse and structure Pokémon team data from Pokémon Showdown format.
Handles both clean and HTML-contaminated data.
"""

from dataclasses import dataclass, field
import re
from typing import Any, Optional

from bs4 import BeautifulSoup


HEADER_RE = re.compile(
    r"^(?:(?P<nickname>.+?)\s\()?(?P<species>.+?)\)?\s@\s(?P<item>.+)$"
)


@dataclass
class PokemonEntry:
    """Represents a single Pokémon in a team."""

    nickname: Optional[str] = None  # Custom name (if different from species)
    species: str = ""  # The actual Pokémon species
    item: Optional[str] = None  # Held item
    ability: Optional[str] = None
    tera_type: Optional[str] = None
    nature: Optional[str] = None
    gender: Optional[str] = None  # M, F, or None
    shiny: bool = False
    evs: dict[str, int] = field(default_factory=dict)  # {'HP': 252, 'Atk': 4, ...}
    ivs: dict[str, int] = field(default_factory=dict)
    moves: list[str] = field(default_factory=list)
    stats: dict[str, str] = field(default_factory=dict)

    def display_name(self) -> str:
        """Get display name (nickname if present, else species)."""
        if self.nickname:
            return f"{self.nickname} ({self.species})"
        return self.species

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for comparison."""
        return {
            "nickname": self.nickname,
            "species": self.species,
            "item": self.item,
            "ability": self.ability,
            "tera_type": self.tera_type,
            "nature": self.nature,
            "gender": self.gender,
            "shiny": self.shiny,
            "evs": self.evs.copy(),
            "ivs": self.ivs.copy(),
            "moves": self.moves.copy(),
            "stats": self.stats.copy(),
        }


def parse_team(text: str) -> list[PokemonEntry]:
    """
    Parse team text into structured Pokémon entries.
    """
    return _parse_team_html(text)


def _parse_team_html(text: str) -> list[PokemonEntry]:
    """Parse HTML-formatted team data using BeautifulSoup."""
    try:
        soup = BeautifulSoup(text, "html.parser")

        # Find all <pre> tags which contain individual Pokémon
        pokemon_blocks = soup.find_all("pre")
        if not pokemon_blocks:
            return _parse_team_text(text)
        team = []

        for block in pokemon_blocks:
            raw_text = block.get_text()
            pokemon = _parse_pokemon_block(raw_text)
            if pokemon:
                team.append(pokemon)

        return team
    except Exception:
        # Fallback to text parsing if HTML parsing fails
        return _parse_team_text(text)


def _parse_team_text(text: str) -> list[PokemonEntry]:
    """Parse clean Pokémon Showdown format text."""
    team = []

    # Split by double newlines to get individual Pokémon blocks
    blocks = re.split(r"\n\s*\n", text.strip())

    for block in blocks:
        if not block.strip():
            continue
        pokemon = _parse_pokemon_block(block)
        if pokemon:
            team.append(pokemon)

    return team


def _parse_pokemon_block(text: str) -> Optional[PokemonEntry]:
    """Parse a Pokémon entry from a block of text."""
    lines = [re.sub(r"<[^>]+>", "", line).strip() for line in text.split("\n")]
    lines = [line for line in lines if line]
    if not lines:
        return None

    header = HEADER_RE.match(lines[0])
    if not header:
        return None

    pokemon = PokemonEntry(
        nickname=header.group("nickname"),
        species=header.group("species").strip(),
        item=header.group("item").strip(),
    )

    # Parse remaining lines for metadata
    for line in lines[1:]:
        _parse_pokemon_metadata(pokemon, line)

    return pokemon if pokemon.species else None


def _parse_pokemon_metadata(pokemon: PokemonEntry, line: str) -> None:
    """Parse a single metadata line for a Pokémon."""
    if not line or line.startswith("<") or line.startswith(">"):
        return

    if line.startswith("- "):
        pokemon.moves.append(line[2:].strip())
        return
    elif line.startswith("-") or line.startswith("–"):
        move = line.lstrip("-–").strip()
        if move:
            pokemon.moves.append(move)
        return

    if ":" in line:
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        pokemon.stats[key] = value

        if key == "Ability":
            pokemon.ability = value
        elif key == "Tera Type":
            pokemon.tera_type = value
        elif key == "Gender":
            pokemon.gender = value
        elif key == "Shiny":
            pokemon.shiny = value.lower() == "yes"
        elif key == "EVs":
            _parse_stats(value, pokemon.evs)
        elif key == "IVs":
            _parse_stats(value, pokemon.ivs)
    elif "Nature" in line:
        nature = line.replace("Nature", "").strip()
        pokemon.nature = nature
        pokemon.stats["Nature"] = nature


def _parse_stats(stats_str: str, stats_dict: dict[str, int]) -> None:
    """Parse stats string like '252 SpA / 4 SpD / 252 Spe' into dict."""
    parts = stats_str.split("/")
    stat_names = {
        "HP": ["HP"],
        "Atk": ["Atk", "Attack"],
        "Def": ["Def", "Defense"],
        "SpA": ["SpA", "Sp. Atk", "Special Attack"],
        "SpD": ["SpD", "Sp. Def", "Special Defense"],
        "Spe": ["Spe", "Speed"],
    }

    for part in parts:
        part = part.strip()
        # Extract number and stat name
        match = re.match(r"(\d+)\s*(.+)", part)
        if match:
            value = int(match.group(1))
            stat_name = match.group(2).strip()

            # Find matching stat
            for standard_name, aliases in stat_names.items():
                if stat_name in aliases:
                    stats_dict[standard_name] = value
                    break


def compare_teams(team1: list[PokemonEntry], team2: list[PokemonEntry]) -> list[str]:
    """
    Compare two teams using the species-indexed diff algorithm.
    """
    indexed_team1 = _index_team_by_species(team1)
    indexed_team2 = _index_team_by_species(team2)

    results = {"removed": [], "added": [], "changed": []}

    for species, pokemon1 in indexed_team1.items():
        if species not in indexed_team2:
            results["removed"].append(species)
        else:
            pokemon2 = indexed_team2[species]
            diffs = _compare_mon(pokemon1, pokemon2)
            if diffs:
                results["changed"].append({"species": species, "changes": diffs})

    for species in indexed_team2:
        if species not in indexed_team1:
            results["added"].append(species)

    changes = []

    for species in sorted(results["removed"]):
        changes.append(f"[-] Removed {species}")

    for species in sorted(results["added"]):
        changes.append(f"[+] Added {species}")

    for changed in sorted(results["changed"], key=lambda entry: entry["species"]):
        changes.append(f"[*] {changed['species']}:")
        for change in changed["changes"]:
            changes.append(f"    - {change}")

    return changes if changes else ["No differences detected"]


def _index_team_by_species(team: list[PokemonEntry]) -> dict[str, dict[str, Any]]:
    """Convert parsed entries to the compare structure indexed by species."""
    pokemon_list = {}

    for pokemon in team:
        pokemon_list[pokemon.species] = {
            "nickname": pokemon.nickname,
            "species": pokemon.species,
            "item": pokemon.item,
            "moves": sorted(pokemon.moves),
            "stats": pokemon.stats.copy(),
        }

    return pokemon_list


def _compare_mon(pokemon1: dict[str, Any], pokemon2: dict[str, Any]) -> list[str]:
    """Internal helper to find specific attribute differences."""
    diffs = []

    # Compare core attributes
    if pokemon1["item"] != pokemon2["item"]:
        diffs.append(f"Item: {pokemon1['item']} -> {pokemon2['item']}")
    if pokemon1["nickname"] != pokemon2["nickname"]:
        diffs.append(f"Nickname: {pokemon1['nickname']} -> {pokemon2['nickname']}")

    # Compare Moves
    if pokemon1["moves"] != pokemon2["moves"]:
        removed_moves = set(pokemon1["moves"]) - set(pokemon2["moves"])
        added_moves = set(pokemon2["moves"]) - set(pokemon1["moves"])
        if removed_moves or added_moves:
            diffs.append(
                f"Moves changed (Lost: {list(removed_moves)}, Gained: {list(added_moves)})"
            )

    # Compare Stats/Attributes (EVs, IVs, Ability, Tera, etc.)
    all_keys = set(pokemon1["stats"].keys()) | set(pokemon2["stats"].keys())
    for key in all_keys:
        value1 = pokemon1["stats"].get(key)
        value2 = pokemon2["stats"].get(key)
        if value1 != value2:
            diffs.append(f"{key}: {value1} -> {value2}")

    return diffs
