"""
PokePaste integration for fetching and parsing Pokémon team data.
"""

import re
from typing import Any

from bs4 import BeautifulSoup
import requests


def clean_team_html(text: str) -> str:
    """
    Remove HTML tags and metadata from team text.
    Preserves the blank lines between Pokémon entries.
    """
    # Remove HTML tags
    clean_text = re.sub(r"<[^>]+>", "", text)

    # Remove HTML entities
    clean_text = clean_text.replace("&nbsp;", " ")
    clean_text = clean_text.replace("&amp;", "&")

    # Split into lines and filter
    skip_keywords = {
        "doctype",
        "html",
        "head",
        "body",
        "meta",
        "title",
        "link",
        "script",
        "article",
        "aside",
        "div",
        "img",
        "main",
        "footer",
        "form",
        "input",
        "label",
        "by ",
        "format:",
        "columns mode",
        "stat colours",
        "light mode",
        "preferences.js",
        "paste.css",
    }

    content_lines = []
    blank_line_count = 0

    for line in clean_text.split("\n"):
        line = line.strip()

        # Track blank lines
        if not line:
            blank_line_count += 1
            continue

        # Skip lines that look like HTML metadata or structure
        line_lower = line.lower()
        if any(keyword in line_lower for keyword in skip_keywords):
            continue

        # Skip lines that are just HTML artifacts
        if all(c in "/<>- " for c in line):
            continue

        if content_lines and blank_line_count > 0:
            content_lines.append("")  # Add one blank line between entries

        content_lines.append(line)
        blank_line_count = 0

    # Rejoin with preserved spacing
    return "\n".join(content_lines)


def validate_pokepaste_url(url: str) -> bool:
    """
    Validate that a URL is a valid PokePaste link.
    """
    pattern = r"^https?://pokepast\.es/[a-zA-Z0-9]+/?$"
    return bool(re.match(pattern, url))


def fetch_team_from_pokepaste(url: str) -> dict[str, Any]:
    """
    Fetch and parse PokePaste team content.
    """
    if not validate_pokepaste_url(url):
        raise ValueError(f"Invalid PokePaste URL: {url}")

    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()

        soup = BeautifulSoup(response.text, "html.parser")

        title_tag = soup.find("h1")
        team_name = title_tag.get_text().strip() if title_tag else "Untitled Team"

        pre_tags = soup.find_all("pre")
        if not pre_tags:
            raise ValueError("No Pokémon data found at this URL.")

        raw_text = "\n\n".join([pre.get_text().strip() for pre in pre_tags])

        return {"team_name": team_name, "raw_text": raw_text}

    except requests.exceptions.RequestException as e:
        raise IOError(f"Failed to fetch PokePaste: {e}")
    except Exception as e:
        raise IOError(f"Failed to parse PokePaste: {e}")


def normalize_team_text(text: str) -> str:
    """
    Normalize team text for consistent hashing.
    """
    # Just strip trailing whitespace from each line, preserve the spacing
    lines = [line.rstrip() for line in text.strip().split("\n")]
    # Rejoin with single newlines to preserve the double-newline structure
    return "\n".join(lines)


def parse_pokepaste(url: str) -> dict[str, Any]:
    """
    Fetch and parse a PokePaste URL.
    """
    parsed = fetch_team_from_pokepaste(url)
    # BeautifulSoup already provides clean text, no need to normalize
    return {"team_name": parsed["team_name"], "raw_text": parsed["raw_text"]}
