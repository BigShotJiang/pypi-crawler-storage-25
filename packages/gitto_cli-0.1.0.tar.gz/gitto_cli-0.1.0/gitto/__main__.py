"""
Entry point for running Gitto as a module: python -m gitto
"""

import sys

from gitto.cli.repl import main_entry

if __name__ == "__main__":
    sys.exit(main_entry())
