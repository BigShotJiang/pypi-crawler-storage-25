"""
Configuration and CLI constants.
"""

# Repository structure
GITTO_DIR = ".gitto"
OBJECTS_DIR = "objects"
REFS_DIR = "refs"
REFS_TEAMS_DIR = "teams"
HEAD_FILE = "HEAD"
LOGS_DIR = "logs"

# Object types
BLOB_TYPE = "blob"
TREE_TYPE = "tree"
COMMIT_TYPE = "commit"

# Default values
DEFAULT_VARIANT = "main"
DEFAULT_AUTHOR = "user"

# Validation patterns
VALID_NAME_PATTERN = r"^[a-zA-Z0-9\-]+$"

# Message prefixes
SUCCESS = "✔"
INFO = "→"
WARNING = "!"
ERROR = "✖"

# Status codes
EXIT_SUCCESS = 0
EXIT_ERROR = 1
