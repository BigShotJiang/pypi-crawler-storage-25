"""
Commit and update service.
Handles creating commits from PokePaste URLs and managing history.
"""

import time
from typing import Optional

from gitto.config.constants import DEFAULT_AUTHOR
from gitto.core.repository import Repository
from gitto.models.objects import Blob, Commit, Tree
from gitto.utils.pokepaste import parse_pokepaste, validate_pokepaste_url


class CommitService:
    """
    Manages commits and team updates.
    """

    def __init__(self, repo: Repository):
        """
        Initialize commit service.
        """
        self.repo = repo

    def _get_active_team_variant(self) -> tuple[Optional[str], Optional[str]]:
        """Get active team and variant, or raise error if none."""
        team, variant = self.repo.get_current_state()
        return team, variant

    def update_team(
        self, url: str, message: str, author: str = DEFAULT_AUTHOR
    ) -> tuple[bool, str, Optional[str]]:
        """
        Create a new commit from a PokePaste URL.
        """
        team, variant = self._get_active_team_variant()

        if team is None or variant is None:
            return False, "No active team/variant", None

        if not validate_pokepaste_url(url):
            return False, f"Invalid PokePaste URL: {url}", None

        try:
            # Fetch and parse PokePaste
            paste_data = parse_pokepaste(url)
        except (ValueError, IOError) as e:
            return False, f"Failed to fetch PokePaste: {e}", None

        try:
            # Create blob
            blob = Blob(**paste_data)
            blob_hash = self.repo.objects.store(blob)

            # Create tree
            tree = Tree(blob_hash=blob_hash)
            tree_hash = self.repo.objects.store(tree)

            # Get parent commit
            parent_hash = self.repo.refs.get_variant_ref(team, variant)
            parent_hashes = [parent_hash] if parent_hash and parent_hash.strip() else []

            # Create commit
            commit = Commit(
                tree_hash=tree_hash,
                parent_hashes=parent_hashes,
                message=message,
                timestamp=int(time.time()),
                author=author,
                pokepaste_url=url,
            )
            commit_hash = self.repo.objects.store(commit)

            # Update variant ref
            self.repo.refs.set_variant_ref(team, variant, commit_hash)

            return (
                True,
                f"Updated team '{team}' (commit: {commit_hash[:8]})",
                commit_hash,
            )

        except Exception as e:
            return False, f"Error creating commit: {e}", None

    def amend_team(
        self, url: str, message: str, author: str = DEFAULT_AUTHOR
    ) -> tuple[bool, str, Optional[str]]:
        """
        Replace the last commit with a new one.
        """
        team, variant = self._get_active_team_variant()

        if team is None or variant is None:
            return False, "No active team/variant", None

        # Get current commit
        current_hash = self.repo.refs.get_variant_ref(team, variant)
        if not current_hash or not current_hash.strip():
            return False, "No commits to amend", None

        current_commit = self.repo.objects.retrieve(current_hash)
        if not isinstance(current_commit, Commit):
            return False, "Invalid commit", None

        if not validate_pokepaste_url(url):
            return False, f"Invalid PokePaste URL: {url}", None

        try:
            # Fetch and parse PokePaste
            paste_data = parse_pokepaste(url)
        except (ValueError, IOError) as e:
            return False, f"Failed to fetch PokePaste: {e}", None

        try:
            # Create blob and tree (same as update)
            blob = Blob(**paste_data)
            blob_hash = self.repo.objects.store(blob)

            tree = Tree(blob_hash=blob_hash)
            tree_hash = self.repo.objects.store(tree)

            # Create new commit with same parents as current
            new_commit = Commit(
                tree_hash=tree_hash,
                parent_hashes=current_commit.parent_hashes,
                message=message,
                timestamp=int(time.time()),
                author=author,
                pokepaste_url=url,
            )
            new_hash = self.repo.objects.store(new_commit)

            # Update variant ref
            self.repo.refs.set_variant_ref(team, variant, new_hash)

            return True, f"Amended team '{team}' (commit: {new_hash[:8]})", new_hash

        except Exception as e:
            return False, f"Error amending commit: {e}", None

    def get_commit(self, commit_hash: str) -> Optional[Commit]:
        """
        Get a commit by hash.
        """
        obj = self.repo.objects.retrieve(commit_hash)
        if isinstance(obj, Commit):
            return obj
        return None

    def get_commit_history(
        self, team: Optional[str] = None, variant: Optional[str] = None
    ) -> list[tuple[str, Commit]]:
        """
        Get commit history for a variant (in reverse chronological order).
        """
        if team is None or variant is None:
            team, variant = self._get_active_team_variant()

        if team is None or variant is None:
            return []

        history = []
        current_hash = self.repo.refs.get_variant_ref(team, variant)

        visited = set()
        while current_hash and current_hash.strip():
            if current_hash in visited:
                break  # Prevent cycles
            visited.add(current_hash)

            commit = self.get_commit(current_hash)
            if not commit:
                break

            history.append((current_hash, commit))

            # Get first parent (linear history)
            if commit.parent_hashes:
                current_hash = commit.parent_hashes[0]
            else:
                break

        return history

    def get_team_content(self, commit_hash: Optional[str] = None) -> tuple[bool, str]:
        """
        Get the team content (raw text) from a commit.
        """
        if commit_hash is None:
            team, variant = self._get_active_team_variant()
            if team is None or variant is None:
                return False, "No active team/variant"
            commit_hash = self.repo.refs.get_variant_ref(team, variant)
            if not commit_hash or not commit_hash.strip():
                return False, "No commits in this variant"

        # Retrieve commit
        commit = self.get_commit(commit_hash)
        if not commit:
            return False, f"Commit not found: {commit_hash}"

        # Retrieve tree
        tree = self.repo.objects.retrieve(commit.tree_hash)
        if not tree:
            return False, f"Tree not found: {commit.tree_hash}"

        # Retrieve blob
        blob = self.repo.objects.retrieve(tree.blob_hash)
        if not isinstance(blob, Blob):
            return False, f"Blob not found: {tree.blob_hash}"

        # Clean and return content
        from gitto.utils.pokepaste import clean_team_html

        clean_content = clean_team_html(blob.raw_text)
        return True, clean_content
