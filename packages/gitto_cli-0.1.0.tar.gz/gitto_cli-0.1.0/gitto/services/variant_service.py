"""
Variant management service.
Handles variant creation, deletion, and switching.
"""

import re
from typing import Optional

from gitto.config.constants import DEFAULT_VARIANT, VALID_NAME_PATTERN
from gitto.core.repository import Repository


class VariantService:
    """
    Manages variant operations within a team.
    """

    def __init__(self, repo: Repository):
        """
        Initialize variant service.
        """
        self.repo = repo

    def validate_variant_name(self, name: str) -> bool:
        """
        Validate variant name format.
        """
        return bool(re.match(VALID_NAME_PATTERN, name))

    def _get_active_team(self) -> Optional[str]:
        """Get the active team, or raise error if none."""
        team, _ = self.repo.get_current_state()
        return team

    def create_variant(self, name: str, team: Optional[str] = None) -> tuple[bool, str]:
        """
        Create a new variant in a team.
        """
        if team is None:
            team = self._get_active_team()

        if team is None:
            return False, "No active team"

        if not self.validate_variant_name(name):
            return False, f"Invalid variant name: {name}"

        if not self.repo.refs.team_exists(team):
            return False, f"Team '{team}' does not exist"

        if self.repo.refs.variant_exists(team, name):
            return False, f"Variant '{name}' already exists in team '{team}'"

        # Create variant (can be empty, no initial commit)
        self.repo.refs.create_variant(team, name)

        return True, f"Created variant '{name}' in team '{team}'"

    def delete_variant(self, name: str, team: Optional[str] = None) -> tuple[bool, str]:
        """
        Delete a variant.
        """
        if team is None:
            team = self._get_active_team()

        if team is None:
            return False, "No active team"

        if name == DEFAULT_VARIANT:
            return False, f"Cannot delete the '{DEFAULT_VARIANT}' variant"

        if not self.repo.refs.variant_exists(team, name):
            return False, f"Variant '{name}' does not exist"

        # Check if active
        _, current_variant = self.repo.get_current_state()
        if current_variant == name:
            return False, f"Cannot delete active variant '{name}'"

        self.repo.refs.delete_variant(team, name)
        return True, f"Deleted variant '{name}'"

    def switch_variant(self, name: str, team: Optional[str] = None) -> tuple[bool, str]:
        """
        Switch to a different variant.
        """
        if team is None:
            team = self._get_active_team()

        if team is None:
            return False, "No active team"

        if not self.repo.refs.variant_exists(team, name):
            return False, f"Variant '{name}' does not exist"

        self.repo.set_current_state(team, name)
        return True, f"Switched to variant '{name}'"

    def list_variants(self, team: Optional[str] = None) -> list[str]:
        """
        List all variants in a team.
        """
        if team is None:
            team = self._get_active_team()

        if team is None:
            return []

        return sorted(self.repo.refs.list_variants(team))

    def rename_variant(
        self, old_name: str, new_name: str, team: Optional[str] = None
    ) -> tuple[bool, str]:
        """
        Rename a variant.
        """
        if team is None:
            team = self._get_active_team()

        if team is None:
            return False, "No active team"

        if not self.validate_variant_name(new_name):
            return False, f"Invalid variant name: {new_name}"

        if not self.repo.refs.variant_exists(team, old_name):
            return False, f"Variant '{old_name}' does not exist"

        if self.repo.refs.variant_exists(team, new_name):
            return False, f"Variant '{new_name}' already exists"

        self.repo.refs.rename_variant(team, old_name, new_name)

        # Update HEAD if active
        current_team, current_variant = self.repo.get_current_state()
        if current_team == team and current_variant == old_name:
            self.repo.set_current_state(team, new_name)

        return True, f"Renamed variant '{old_name}' to '{new_name}'"

    def get_variant_status(
        self, name: str, team: Optional[str] = None
    ) -> Optional[dict]:
        """
        Get status of a variant.
        """
        if team is None:
            team = self._get_active_team()

        if team is None or not self.repo.refs.variant_exists(team, name):
            return None

        commit_hash = self.repo.refs.get_variant_ref(team, name)
        current_team, current_variant = self.repo.get_current_state()

        return {
            "team": team,
            "name": name,
            "commit_hash": commit_hash,
            "active": current_team == team and current_variant == name,
            "has_commits": commit_hash is not None and commit_hash.strip() != "",
        }
