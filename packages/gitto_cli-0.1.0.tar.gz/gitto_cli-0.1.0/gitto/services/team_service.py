"""
Team management service.
Handles team creation, deletion, switching, and basic operations.
"""

import re
from typing import Optional

from gitto.config.constants import DEFAULT_VARIANT, VALID_NAME_PATTERN
from gitto.core.repository import Repository


class TeamService:
    """
    Manages team operations.
    """

    def __init__(self, repo: Repository):
        """
        Initialize team service.
        """
        self.repo = repo

    def validate_team_name(self, name: str) -> bool:
        """
        Validate team name format.
        """
        return bool(re.match(VALID_NAME_PATTERN, name))

    def create_team(self, name: str) -> tuple[bool, str]:
        """
        Create a new team.
        """
        if not self.validate_team_name(name):
            return False, f"Invalid team name: {name}"

        if self.repo.refs.team_exists(name):
            return False, f"Team '{name}' already exists"

        self.repo.refs.create_team(name)
        self.repo.refs.create_variant(name, DEFAULT_VARIANT)

        return True, f"Created team '{name}'"

    def delete_team(self, name: str) -> tuple[bool, str]:
        """
        Delete a team.
        """
        if not self.repo.refs.team_exists(name):
            return False, f"Team '{name}' does not exist"

        # Check if active - if so, clear the HEAD
        current_team, _ = self.repo.get_current_state()
        if current_team == name:
            self.repo.head.clear()

        self.repo.refs.delete_team(name)
        return True, f"Deleted team '{name}'"

    def list_teams(self) -> list[str]:
        """
        List all teams.
        """
        return sorted(self.repo.refs.list_teams())

    def switch_team(self, name: str) -> tuple[bool, str]:
        """
        Switch to a team.
        """
        if not self.repo.refs.team_exists(name):
            return False, f"Team '{name}' does not exist"

        # Get default variant (main)
        variants = self.repo.refs.list_variants(name)
        if not variants:
            return False, f"Team '{name}' has no variants"

        variant = DEFAULT_VARIANT if DEFAULT_VARIANT in variants else variants[0]
        self.repo.set_current_state(name, variant)

        return True, f"Switched to team '{name}' (variant: {variant})"

    def rename_team(self, old_name: str, new_name: str) -> tuple[bool, str]:
        """
        Rename a team.
        """
        if not self.validate_team_name(new_name):
            return False, f"Invalid team name: {new_name}"

        if not self.repo.refs.team_exists(old_name):
            return False, f"Team '{old_name}' does not exist"

        if self.repo.refs.team_exists(new_name):
            return False, f"Team '{new_name}' already exists"

        self.repo.refs.rename_team(old_name, new_name)

        # Update HEAD if active
        current_team, variant = self.repo.get_current_state()
        if current_team == old_name:
            self.repo.set_current_state(new_name, variant)

        return True, f"Renamed team '{old_name}' to '{new_name}'"

    def get_team_status(self, name: str) -> Optional[dict]:
        """
        Get status of a team.
        """
        if not self.repo.refs.team_exists(name):
            return None

        variants = self.repo.refs.list_variants(name)
        current_team, current_variant = self.repo.get_current_state()

        return {
            "name": name,
            "variants": variants,
            "active": current_team == name,
            "current_variant": current_variant if current_team == name else None,
        }
