"""
Merge and garbage collection service.
Handles merging variants and cleaning up unreachable objects.
"""

import time
from typing import Optional

from gitto.config.constants import DEFAULT_AUTHOR
from gitto.core.repository import Repository
from gitto.models.objects import Commit
from gitto.services.commit_service import CommitService


class MergeService:
    """
    Handles merging variants and commits.
    """

    def __init__(self, repo: Repository):
        """
        Initialize merge service.
        """
        self.repo = repo
        self.commit_service = CommitService(repo)

    def merge_variant(
        self,
        source_variant: str,
        target_variant: Optional[str] = None,
        team: Optional[str] = None,
        message: Optional[str] = None,
        author: str = DEFAULT_AUTHOR,
    ) -> tuple[bool, str, Optional[str]]:
        """
        Merge one variant into another.
        Creates a merge commit with two parents.
        """
        if team is None:
            team, active_variant = self.repo.get_current_state()
        else:
            active_variant = None

        if team is None:
            return False, "No active team", None

        if target_variant is None:
            target_variant = active_variant

        if target_variant is None:
            return False, "No target variant specified", None

        if source_variant == target_variant:
            return False, "Cannot merge a variant into itself", None

        if not self.repo.refs.variant_exists(team, source_variant):
            return False, f"Source variant '{source_variant}' does not exist", None

        if not self.repo.refs.variant_exists(team, target_variant):
            return False, f"Target variant '{target_variant}' does not exist", None

        # Get both commit hashes
        source_hash = self.repo.refs.get_variant_ref(team, source_variant)
        target_hash = self.repo.refs.get_variant_ref(team, target_variant)

        if not source_hash or not source_hash.strip():
            return False, f"Source variant '{source_variant}' has no commits", None

        if not target_hash or not target_hash.strip():
            return False, f"Target variant '{target_variant}' has no commits", None

        # Create merge commit
        try:
            # Get tree from target (use target's team data)
            target_commit = self.commit_service.get_commit(target_hash)
            if not target_commit:
                return False, "Could not retrieve target commit", None

            # Create merge commit with both parents
            if message is None:
                message = f"Merge '{source_variant}' into '{target_variant}'"

            merge_commit = Commit(
                tree_hash=target_commit.tree_hash,  # Keep target's team data
                parent_hashes=[target_hash, source_hash],  # Both parents
                message=message,
                timestamp=int(time.time()),
                author=author,
            )

            merge_hash = self.repo.objects.store(merge_commit)

            # Update target variant to point to merge commit
            self.repo.refs.set_variant_ref(team, target_variant, merge_hash)

            return (
                True,
                f"Merged '{source_variant}' into '{target_variant}'",
                merge_hash,
            )

        except Exception as e:
            return False, f"Error creating merge commit: {e}", None


class GarbageCollectionService:
    """
    Handles cleanup and garbage collection.
    """

    def __init__(self, repo: Repository):
        """
        Initialize GC service.
        """
        self.repo = repo
        self.commit_service = CommitService(repo)

    def _get_reachable_objects(self) -> set[str]:
        """
        Find all objects reachable from any ref.
        """
        reachable = set()

        # Traverse from all variant refs
        for team in self.repo.refs.list_teams():
            for variant in self.repo.refs.list_variants(team):
                history = self.commit_service.get_commit_history(team, variant)
                for commit_hash, commit in history:
                    reachable.add(commit_hash)
                    reachable.add(commit.tree_hash)

                    # Get blob from tree
                    tree = self.repo.objects.retrieve(commit.tree_hash)
                    if tree:
                        reachable.add(tree.blob_hash)

        return reachable

    def collect_garbage(self, dry_run: bool = False) -> tuple[int, int]:
        """
        Remove unreachable objects.
        """
        all_hashes = self.repo.objects.get_all_hashes()
        reachable = self._get_reachable_objects()

        total = len(all_hashes)
        deleted = 0

        for obj_hash in all_hashes:
            if obj_hash not in reachable:
                if not dry_run:
                    self.repo.objects.delete(obj_hash)
                deleted += 1

        return total, deleted

    def get_repository_stats(self) -> dict:
        """
        Get repository statistics.
        """
        all_hashes = self.repo.objects.get_all_hashes()
        reachable = self._get_reachable_objects()
        unreachable = len(all_hashes) - len(reachable)

        teams = self.repo.refs.list_teams()
        total_variants = sum(len(self.repo.refs.list_variants(t)) for t in teams)
        total_commits = len(reachable)  # Approximation

        return {
            "teams": len(teams),
            "variants": total_variants,
            "total_objects": len(all_hashes),
            "reachable_objects": len(reachable),
            "unreachable_objects": unreachable,
            "estimated_commits": total_commits,
        }
