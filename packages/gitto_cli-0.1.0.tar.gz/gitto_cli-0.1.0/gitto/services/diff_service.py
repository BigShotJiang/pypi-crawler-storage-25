"""
Diff and history service for comparing and viewing changes.
"""

from typing import Any, Optional

from gitto.core.repository import Repository
from gitto.models.objects import Blob
from gitto.services.commit_service import CommitService
from gitto.utils.team_parser import compare_teams, parse_team


class DiffService:
    """
    Compares two commits/variants and shows differences.
    """

    def __init__(self, repo: Repository):
        """
        Initialize diff service.
        """
        self.repo = repo
        self.commit_service = CommitService(repo)

    def _get_blob_from_commit(self, commit_hash: str) -> Optional[Blob]:
        """Get the blob from a commit."""
        commit = self.commit_service.get_commit(commit_hash)
        if not commit:
            return None

        tree = self.repo.objects.retrieve(commit.tree_hash)
        if not tree:
            return None

        blob = self.repo.objects.retrieve(tree.blob_hash)
        return blob if isinstance(blob, Blob) else None

    def compare_commits(self, hash1: str, hash2: str) -> dict[str, Any]:
        """
        Compare two commits with detailed structural differences.
        """
        blob1 = self._get_blob_from_commit(hash1)
        blob2 = self._get_blob_from_commit(hash2)

        if not blob1 or not blob2:
            return {
                "error": "Could not retrieve commits",
                "hash1": hash1,
                "hash2": hash2,
            }

        # Parse both teams into structured data (handles both clean and HTML)
        team1 = parse_team(blob1.raw_text)
        team2 = parse_team(blob2.raw_text)

        # Generate detailed diff
        changes = compare_teams(team1, team2)

        return {
            "hash1": hash1,
            "hash2": hash2,
            "changes": changes,
            "team1_size": len(team1),
            "team2_size": len(team2),
        }

    def get_status(self) -> dict[str, Any]:
        """
        Get repository status.
        """
        team, variant = self.repo.get_current_state()

        if not team or not variant:
            return {"initialized": False, "current_team": None, "current_variant": None}

        history = self.commit_service.get_commit_history(team, variant)

        return {
            "initialized": True,
            "current_team": team,
            "current_variant": variant,
            "total_commits": len(history),
            "last_commit_hash": history[0][0] if history else None,
            "teams": self.repo.refs.list_teams(),
            "variants": self.repo.refs.list_variants(team),
        }


class HistoryService:
    """
    Manages and displays commit history.
    """

    def __init__(self, repo: Repository):
        """
        Initialize history service.
        """
        self.repo = repo
        self.commit_service = CommitService(repo)

    def get_history(
        self,
        team: Optional[str] = None,
        variant: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """
        Get commit history in readable format.
        """
        history = self.commit_service.get_commit_history(team, variant)

        result = []
        for i, (commit_hash, commit) in enumerate(history):
            if limit and i >= limit:
                break

            entry = {
                "hash": commit_hash,
                "short_hash": commit_hash[:8],
                "message": commit.message,
                "author": commit.author,
                "timestamp": commit.timestamp,
                "is_merge": commit.is_merge_commit,
                "parent_count": len(commit.parent_hashes),
            }
            if commit.pokepaste_url:
                entry["pokepaste_url"] = commit.pokepaste_url
            result.append(entry)

        return result

    def get_timeline(self) -> list[dict[str, Any]]:
        """
        Get a timeline of all operations (reflog-like).
        """
        timeline = []

        for team in self.repo.refs.list_teams():
            for variant in self.repo.refs.list_variants(team):
                history = self.commit_service.get_commit_history(team, variant)
                for commit_hash, commit in history[:10]:  # Last 10 per variant
                    entry = {
                        "team": team,
                        "variant": variant,
                        "commit": commit_hash[:8],
                        "message": commit.message,
                        "timestamp": commit.timestamp,
                        "author": commit.author,
                    }
                    if commit.pokepaste_url:
                        entry["pokepaste_url"] = commit.pokepaste_url
                    timeline.append(entry)

        # Sort by timestamp descending
        timeline.sort(key=lambda x: x["timestamp"], reverse=True)
        return timeline[:50]  # Last 50 timeline entries
