"""
Reference store for managing teams and variants.
Stores pointers to commit hashes.
"""

from pathlib import Path
import shutil
from typing import Optional


class RefStore:
    """
    Manages references (team pointers to commits).
    Structure: .gitto/refs/teams/<team>/variants/<variant>
    """

    def __init__(self, refs_dir: Path):
        """
        Initialize reference store.
        """
        self.refs_dir = refs_dir
        self.teams_dir = refs_dir / "teams"
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        """Ensure refs directory exists."""
        self.teams_dir.mkdir(parents=True, exist_ok=True)

    def _get_variant_path(self, team: str, variant: str) -> Path:
        """Get filesystem path for a variant reference."""
        return self.teams_dir / team / "variants" / variant

    def _get_team_dir(self, team: str) -> Path:
        """Get filesystem path for a team directory."""
        return self.teams_dir / team

    def create_team(self, team: str) -> bool:
        """
        Create a new team with main variant.
        """
        team_dir = self._get_team_dir(team)

        if team_dir.exists():
            return False

        team_dir.mkdir(parents=True, exist_ok=True)

        # Create main variant directory
        variants_dir = team_dir / "variants"
        variants_dir.mkdir(exist_ok=True)

        return True

    def team_exists(self, team: str) -> bool:
        """Check if a team exists."""
        return self._get_team_dir(team).exists()

    def delete_team(self, team: str) -> bool:
        """
        Delete a team and all its variants.
        """
        team_dir = self._get_team_dir(team)

        if not team_dir.exists():
            return False

        shutil.rmtree(team_dir)
        return True

    def set_variant_ref(self, team: str, variant: str, commit_hash: str):
        """
        Set a variant reference to point to a commit.
        """
        variant_path = self._get_variant_path(team, variant)
        variant_path.parent.mkdir(parents=True, exist_ok=True)

        with open(variant_path, "w", encoding="utf-8") as f:
            f.write(commit_hash)

    def get_variant_ref(self, team: str, variant: str) -> Optional[str]:
        """
        Get the commit hash a variant points to.
        """
        variant_path = self._get_variant_path(team, variant)

        if not variant_path.exists():
            return None

        with open(variant_path, "r", encoding="utf-8") as f:
            return f.read().strip()

    def variant_exists(self, team: str, variant: str) -> bool:
        """Check if a variant exists."""
        return self._get_variant_path(team, variant).exists()

    def create_variant(
        self, team: str, variant: str, commit_hash: Optional[str] = None
    ) -> bool:
        """
        Create a new variant.
        """
        if self.variant_exists(team, variant):
            return False

        if commit_hash:
            self.set_variant_ref(team, variant, commit_hash)
        else:
            # Create empty variant
            self._get_variant_path(team, variant).parent.mkdir(
                parents=True, exist_ok=True
            )
            self._get_variant_path(team, variant).touch()

        return True

    def delete_variant(self, team: str, variant: str) -> bool:
        """
        Delete a variant reference.
        """
        variant_path = self._get_variant_path(team, variant)

        if not variant_path.exists():
            return False

        variant_path.unlink()

        # Clean up empty directories
        try:
            variant_path.parent.rmdir()  # variants dir
            variant_path.parent.parent.rmdir()  # team dir
        except OSError:
            pass  # Directories not empty, which is fine

        return True

    def list_teams(self) -> list[str]:
        """Get all teams."""
        if not self.teams_dir.exists():
            return []

        return [d.name for d in self.teams_dir.iterdir() if d.is_dir()]

    def list_variants(self, team: str) -> list[str]:
        """Get all variants for a team."""
        variants_dir = self._get_team_dir(team) / "variants"

        if not variants_dir.exists():
            return []

        return [f.name for f in variants_dir.iterdir() if f.is_file()]

    def rename_team(self, old_name: str, new_name: str) -> bool:
        """
        Rename a team.
        """
        old_dir = self._get_team_dir(old_name)
        new_dir = self._get_team_dir(new_name)

        if not old_dir.exists() or new_dir.exists():
            return False

        old_dir.rename(new_dir)
        return True

    def rename_variant(self, team: str, old_name: str, new_name: str) -> bool:
        """
        Rename a variant.
        """
        old_path = self._get_variant_path(team, old_name)
        new_path = self._get_variant_path(team, new_name)

        if not old_path.exists() or new_path.exists():
            return False

        new_path.parent.mkdir(parents=True, exist_ok=True)
        old_path.rename(new_path)
        return True
