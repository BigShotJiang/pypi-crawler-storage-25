"""
Object store implementation for Merkle DAG storage.
Handles persistence and retrieval of Blob, Commit and Tree objects.
"""

import json
from pathlib import Path
from typing import Optional, Union

from gitto.config.constants import BLOB_TYPE, COMMIT_TYPE, TREE_TYPE
from gitto.models.objects import Blob, Commit, Tree
from gitto.utils.hashing import hash_object


class ObjectStore:
    """
    Content-addressed object storage.
    Objects are stored in the .gitto/objects/ directory.
    """

    def __init__(self, objects_dir: Path):
        """
        Initialize object store.
        """
        self.objects_dir = objects_dir
        self._ensure_dir()

    def _ensure_dir(self) -> None:
        """Ensure objects directory exists."""
        self.objects_dir.mkdir(parents=True, exist_ok=True)

    def _get_object_path(self, obj_hash: str) -> Path:
        """
        Get filesystem path for an object hash.
        Uses 2-char prefix directory for distribution.
        """
        prefix = obj_hash[:2]
        filename = obj_hash[2:]
        return self.objects_dir / prefix / filename

    def store(self, obj: Union[Blob, Commit, Tree]) -> str:
        """
        Store an object and return its hash.
        """
        obj_hash = hash_object(obj)
        obj_path = self._get_object_path(obj_hash)

        # Don't re-store if already exists
        if obj_path.exists():
            return obj_hash

        # Create prefix directory
        obj_path.parent.mkdir(parents=True, exist_ok=True)

        # Serialize and store
        if isinstance(obj, Blob):
            obj_type = BLOB_TYPE
        elif isinstance(obj, Tree):
            obj_type = TREE_TYPE
        elif isinstance(obj, Commit):
            obj_type = COMMIT_TYPE
        else:
            raise TypeError(f"Unknown object type: {type(obj)}")

        json_str = obj.to_json()
        size = len(json_str.encode("utf-8"))

        # Store as: type\0size\0json_content
        content = f"{obj_type}\x00{size}\x00{json_str}"

        with open(obj_path, "w", encoding="utf-8") as f:
            f.write(content)

        return obj_hash

    def _resolve_hash(self, hash_prefix: str) -> Optional[str]:
        """
        Resolve an abbreviated hash to a full hash.
        """
        # If it's already a full hash, check if it exists
        if len(hash_prefix) == 40:
            if self._get_object_path(hash_prefix).exists():
                return hash_prefix
            return None

        # For abbreviated hash, search the prefix directory
        prefix = hash_prefix[:2]
        prefix_dir = self.objects_dir / prefix

        if not prefix_dir.exists():
            return None

        # Find matching file
        for obj_file in prefix_dir.iterdir():
            full_hash = prefix + obj_file.name
            if full_hash.startswith(hash_prefix):
                return full_hash

        return None

    def retrieve(self, obj_hash: str) -> Optional[Union[Blob, Commit, Tree]]:
        """
        Retrieve an object by its hash (full or abbreviated).
        """
        # Resolve abbreviated hash to full hash
        full_hash = self._resolve_hash(obj_hash)
        if not full_hash:
            return None

        obj_path = self._get_object_path(full_hash)

        if not obj_path.exists():
            return None

        with open(obj_path, "r", encoding="utf-8") as f:
            content = f.read()

        # Parse: type\0size\0json_content
        parts = content.split("\x00", 2)
        if len(parts) < 3:
            raise ValueError(f"Invalid object format: {obj_hash}")

        obj_type, _, json_str = parts

        try:
            obj_data = json.loads(json_str)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON in object {obj_hash}: {e}")

        # Deserialize based on type
        if obj_type == BLOB_TYPE:
            return Blob(**obj_data)
        elif obj_type == TREE_TYPE:
            return Tree(**obj_data)
        elif obj_type == COMMIT_TYPE:
            return Commit(**obj_data)
        else:
            raise ValueError(f"Unknown object type: {obj_type}")

    def exists(self, obj_hash: str) -> bool:
        """Check if an object exists."""
        return self._get_object_path(obj_hash).exists()

    def get_all_hashes(self) -> list:
        """
        Get all stored object hashes.
        """
        hashes = []
        if not self.objects_dir.exists():
            return hashes

        for prefix_dir in self.objects_dir.iterdir():
            if prefix_dir.is_dir():
                prefix = prefix_dir.name
                for filename in prefix_dir.iterdir():
                    hashes.append(prefix + filename.name)

        return hashes

    def delete(self, obj_hash: str) -> bool:
        """
        Delete an object from storage.
        """
        obj_path = self._get_object_path(obj_hash)

        if not obj_path.exists():
            return False

        obj_path.unlink()

        # Clean up empty prefix directory
        try:
            obj_path.parent.rmdir()
        except OSError:
            pass  # Directory not empty, which is fine

        return True
