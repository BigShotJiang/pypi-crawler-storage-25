"""
Command line interface for Gitto.
Handles command parsing and execution.
"""

import argparse
from pathlib import Path
import sys
from typing import Optional


from gitto.config.constants import (
    ERROR,
    EXIT_ERROR,
    EXIT_SUCCESS,
    INFO,
    SUCCESS,
    WARNING,
)
from gitto.core.repository import Repository
from gitto.services.commit_service import CommitService
from gitto.services.diff_service import DiffService, HistoryService
from gitto.services.team_service import TeamService
from gitto.services.merge_service import GarbageCollectionService, MergeService
from gitto.services.variant_service import VariantService


class GittoCommand:
    """Main command handler."""

    def __init__(self):
        """Initialize command handler."""
        self.repo: Optional[Repository] = None
        self.team_service: Optional[TeamService] = None
        self.variant_service: Optional[VariantService] = None
        self.commit_service: Optional[CommitService] = None
        self.diff_service: Optional[DiffService] = None
        self.history_service: Optional[HistoryService] = None
        self.merge_service: Optional[MergeService] = None
        self.gc_service: Optional[GarbageCollectionService] = None

    def _ensure_repo(self, auto_init: bool = False) -> bool:
        """
        Ensure repository is initialized.
        If auto_init is True, initialize repo if not found.
        If False, error on not found.
        """
        if self.repo is None:
            self.repo = Repository.find_repo()
            if self.repo is None:
                if auto_init:
                    # Create repo at current directory
                    self.repo = Repository(Path.cwd())
                else:
                    self._print_error("Not a Gitto repository")
                    return False

            # Initialize services
            self.team_service = TeamService(self.repo)
            self.variant_service = VariantService(self.repo)
            self.commit_service = CommitService(self.repo)
            self.diff_service = DiffService(self.repo)
            self.history_service = HistoryService(self.repo)
            self.merge_service = MergeService(self.repo)
            self.gc_service = GarbageCollectionService(self.repo)

        return True

    def _ensure_active_team(self) -> bool:
        """Ensure an active team is set."""
        if not self._ensure_repo():
            return False

        team, _ = self.repo.get_current_state()
        if team is None:
            self._print_error("No active team. Use 'team switch' or 'team create'")
            return False

        return True

    @staticmethod
    def _print_success(msg: str):
        """Print success message."""
        print(f"{SUCCESS} {msg}")

    @staticmethod
    def _print_info(msg: str):
        """Print info message."""
        print(f"{INFO} {msg}")

    @staticmethod
    def _print_warning(msg: str):
        """Print warning message."""
        print(f"{WARNING} {msg}")

    @staticmethod
    def _print_error(msg: str):
        """Print error message."""
        print(f"{ERROR} {msg}")

    # Team commands
    def cmd_team_create(self, args):
        """team create <name>"""
        if not self.repo:
            self.repo = Repository(Path.cwd())
            self.team_service = TeamService(self.repo)
            self.variant_service = VariantService(self.repo)

        success, msg = self.team_service.create_team(args.name)
        if success:
            self._print_success(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    def cmd_team_switch(self, args):
        """team switch <name>"""
        if not self._ensure_repo():
            return EXIT_ERROR

        success, msg = self.team_service.switch_team(args.name)
        if success:
            self._print_info(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    def cmd_team_list(self, args):
        """team list"""
        if not self._ensure_repo(auto_init=True):
            return EXIT_ERROR

        teams = self.team_service.list_teams()
        current_team, _ = self.repo.get_current_state()

        if not teams:
            self._print_info("No teams yet")
            return EXIT_SUCCESS

        print("\nTeams:")
        for team in teams:
            marker = " (active)" if team == current_team else ""
            print(f"  {team}{marker}")
        print()
        return EXIT_SUCCESS

    def cmd_team_rename(self, args):
        """team rename <old> <new>"""
        if not self._ensure_repo():
            return EXIT_ERROR

        success, msg = self.team_service.rename_team(args.old_name, args.new_name)
        if success:
            self._print_success(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    def cmd_team_delete(self, args):
        """team delete <name>"""
        if not self._ensure_repo():
            return EXIT_ERROR

        success, msg = self.team_service.delete_team(args.name)
        if success:
            self._print_success(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    # Variant commands
    def cmd_variant_create(self, args):
        """team variant <name>"""
        if not self._ensure_active_team():
            return EXIT_ERROR

        success, msg = self.variant_service.create_variant(args.name)
        if success:
            self._print_success(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    def cmd_variant_switch(self, args):
        """team use <name>"""
        if not self._ensure_active_team():
            return EXIT_ERROR

        success, msg = self.variant_service.switch_variant(args.name)
        if success:
            self._print_info(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    def cmd_variant_delete(self, args):
        """team discard <name>"""
        if not self._ensure_active_team():
            return EXIT_ERROR

        success, msg = self.variant_service.delete_variant(args.name)
        if success:
            self._print_success(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    def cmd_variant_list(self, args):
        """team variants"""
        if not self._ensure_active_team():
            return EXIT_ERROR

        variants = self.variant_service.list_variants()
        _, current_variant = self.repo.get_current_state()

        if not variants:
            self._print_info("No variants yet")
            return EXIT_SUCCESS

        print("\nVariants:")
        for variant in variants:
            marker = " (active)" if variant == current_variant else ""
            print(f"  {variant}{marker}")
        print()
        return EXIT_SUCCESS

    # Commit commands
    def cmd_update(self, args):
        """team update <url> -m <message>"""
        if not self._ensure_active_team():
            return EXIT_ERROR

        success, msg, commit_hash = self.commit_service.update_team(
            args.url, args.message
        )
        if success:
            self._print_success(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    def cmd_amend(self, args):
        """team amend <url> -m <message>"""
        if not self._ensure_active_team():
            return EXIT_ERROR

        success, msg, commit_hash = self.commit_service.amend_team(
            args.url, args.message
        )
        if success:
            self._print_success(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    # History commands
    def cmd_status(self, args):
        """team status"""
        if not self._ensure_repo():
            return EXIT_ERROR

        status = self.diff_service.get_status()

        if not status["initialized"]:
            self._print_info("No active team")
            return EXIT_SUCCESS

        print(f"\nTeam: {status['current_team']}")
        print(f"Variant: {status['current_variant']}")
        print(f"Commits: {status['total_commits']}")
        if status["last_commit_hash"]:
            print(f"Latest: {status['last_commit_hash'][:8]}")
        print()
        return EXIT_SUCCESS

    def cmd_history(self, args):
        """team history"""
        if not self._ensure_active_team():
            return EXIT_ERROR

        history = self.history_service.get_history(limit=10)

        if not history:
            self._print_info("No commits yet")
            return EXIT_SUCCESS

        print("\nHistory:")
        for i, entry in enumerate(history):
            timestamp = entry["timestamp"]
            print(f"  {i + 1}. [{entry['short_hash']}] {entry['message']}")
            print(f"     by {entry['author']}")
            if "pokepaste_url" in entry and entry["pokepaste_url"]:
                print(f"     URL: {entry['pokepaste_url']}")
        print()
        return EXIT_SUCCESS

    def cmd_timeline(self, args):
        """team timeline"""
        if not self._ensure_repo():
            return EXIT_ERROR

        timeline = self.history_service.get_timeline()

        if not timeline:
            self._print_info("No commits yet")
            return EXIT_SUCCESS

        print("\nTimeline (recent):")
        for entry in timeline[:20]:
            print(
                f"  [{entry['commit']}] {entry['team']}/{entry['variant']}: {entry['message']}"
            )
            if "pokepaste_url" in entry and entry["pokepaste_url"]:
                print(f"     URL: {entry['pokepaste_url']}")
        print()
        return EXIT_SUCCESS

    def cmd_compare(self, args):
        """team compare - shows changes from previous to current (old → new)"""
        if not self._ensure_repo():
            return EXIT_ERROR

        team, variant = self.repo.get_current_state()
        if not team or not variant:
            self._print_error("No active team/variant")
            return EXIT_ERROR

        # Handle different argument patterns
        ref1 = getattr(args, "ref1", None)
        ref2 = getattr(args, "ref2", None)

        # Get commit history for the current variant
        history = self.commit_service.get_commit_history(team, variant)

        if not history:
            self._print_error("No commits in this variant")
            return EXIT_ERROR

        # Extract just the commit hashes from the history
        commit_hashes = [h for h, _ in history]

        # Case 1: No arguments - compare previous with current
        if not ref1:
            if len(commit_hashes) < 2:
                self._print_error("Need at least 2 commits to compare")
                return EXIT_ERROR
            ref1 = commit_hashes[1]  # Previous (old)
            ref2 = commit_hashes[0]  # Current (new)
        # Case 2: One argument - compare that commit with the next one in history
        elif not ref2:
            if len(commit_hashes) < 2:
                self._print_error("Need at least 2 commits to compare")
                return EXIT_ERROR
            ref2_hash = None
            for i, h in enumerate(commit_hashes):
                if h.startswith(ref1) or ref1 == h[: len(ref1)]:
                    if i + 1 < len(commit_hashes):
                        ref2_hash = commit_hashes[i + 1]
                    break
            if not ref2_hash:
                self._print_error(f"Commit {ref1} not found or is the oldest")
                return EXIT_ERROR
            ref2 = ref2_hash
        # Case 3: Two arguments - compare directly

        result = self.diff_service.compare_commits(ref1, ref2)

        if "error" in result:
            self._print_error(result["error"])
            return EXIT_ERROR

        print("\n" + "=" * 70)
        print(f"Comparison: {result['hash1'][:8]} → {result['hash2'][:8]}")
        print("=" * 70)

        changes = result.get("changes", [])

        if changes:
            for change in changes:
                if change.startswith("[-]"):
                    print(f"  {change}")
                elif change.startswith("[+]"):
                    print(f"  {change}")
                elif change.startswith("[*]"):
                    print(f"\n  {change}")
                else:
                    print(f"    {change}")

        print()
        return EXIT_SUCCESS

    # Merge commands
    def cmd_merge(self, args):
        """team combine <src> <target>"""
        if not self._ensure_active_team():
            return EXIT_ERROR

        success, msg, _ = self.merge_service.merge_variant(
            args.source, args.target if args.target else None
        )
        if success:
            self._print_success(msg)
            return EXIT_SUCCESS
        else:
            self._print_error(msg)
            return EXIT_ERROR

    # Maintenance commands
    def cmd_tidy(self, args):
        """team tidy"""
        if not self._ensure_repo():
            return EXIT_ERROR

        total, deleted = self.gc_service.collect_garbage()

        if deleted > 0:
            self._print_success(f"Garbage collection: removed {deleted} objects")
        else:
            self._print_info("Repository is clean")

        return EXIT_SUCCESS

    def cmd_stats(self, args):
        """team stats"""
        if not self._ensure_repo():
            return EXIT_ERROR

        stats = self.gc_service.get_repository_stats()

        print("\nRepository Stats:")
        print(f"  Teams: {stats['teams']}")
        print(f"  Variants: {stats['variants']}")
        print(f"  Objects: {stats['total_objects']}")
        print(f"  Unreachable: {stats['unreachable_objects']}")
        print()
        return EXIT_SUCCESS

    def cmd_view(self, args):
        """team view [<commit_hash>]"""
        if not self._ensure_repo():
            return EXIT_ERROR

        # Get commit hash (optional argument)
        commit_hash = (
            args.commit_hash
            if hasattr(args, "commit_hash") and args.commit_hash
            else None
        )

        success, content = self.commit_service.get_team_content(commit_hash)

        if not success:
            self._print_error(content)
            return EXIT_ERROR

        print()
        print(content)
        print()
        return EXIT_SUCCESS

    def cmd_help(self, args):
        """Show help."""
        self._print_help()
        return EXIT_SUCCESS

    @staticmethod
    def _print_help():
        """Print help message."""
        help_text = """
Gitto CLI Reference

Team Management:
  team create <name>           Create a new Pokémon team
  team switch <name>           Switch to an existing team
  team list                    List all teams
  team rename <old> <new>      Rename a team
  team delete <name>           Delete a team

Variant Management:
  team variant <name>          Create a new experimental variant of your team
  team use <name>              Switch to an existing variant
  team variants                List all variants in the current team
  team discard <name>          Delete a variant

Updates:
  team update <url> -m <msg>   Add a new update from a PokéPaste URL
  team amend <url> -m <msg>    Overwrite the most recent update with new data

History & Status:
  team status                  Show current team, variant and latest update
  team history                 Show the history of updates in the current variant
  team timeline                Show a chronological log of all recent actions
  team compare [<ref> | <ref1> <ref2>]  Describe the differences between two updates (default: recent vs previous)
  team view [<hash>]           View team content for a specific update

Advanced:
  team combine <src> <target>  Apply changes from one variant into another (merge)
  team tidy                    Clean up unused data to free up storage space
  team stats                   Show team size and update counts
"""
        print(help_text)


def parse_args(args: Optional[list[str]] = None):
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        prog="gitto", description="Git-like CLI for Pokémon team version control"
    )

    subparsers = parser.add_subparsers(dest="command", help="Command to run")

    # Team commands
    team_parser = subparsers.add_parser("team", help="Team commands")
    team_subparsers = team_parser.add_subparsers(
        dest="subcommand", help="Team subcommand"
    )

    # team create
    create_parser = team_subparsers.add_parser("create", help="Create a team")
    create_parser.add_argument("name", help="Team name")

    # team switch
    switch_parser = team_subparsers.add_parser("switch", help="Switch team")
    switch_parser.add_argument("name", help="Team name")

    # team list
    team_subparsers.add_parser("list", help="List teams")

    # team rename
    rename_parser = team_subparsers.add_parser("rename", help="Rename team")
    rename_parser.add_argument("old_name", help="Current team name")
    rename_parser.add_argument("new_name", help="New team name")

    # team delete
    delete_parser = team_subparsers.add_parser("delete", help="Delete team")
    delete_parser.add_argument("name", help="Team name")

    # team variant
    variant_parser = team_subparsers.add_parser("variant", help="Create variant")
    variant_parser.add_argument("name", help="Variant name")

    # team use
    use_parser = team_subparsers.add_parser("use", help="Switch variant")
    use_parser.add_argument("name", help="Variant name")

    # team discard
    discard_parser = team_subparsers.add_parser("discard", help="Delete variant")
    discard_parser.add_argument("name", help="Variant name")

    # team variants
    team_subparsers.add_parser("variants", help="List variants")

    # team update
    update_parser = team_subparsers.add_parser("update", help="Update team")
    update_parser.add_argument("url", help="PokePaste URL")
    update_parser.add_argument("-m", "--message", required=True, help="Commit message")

    # team amend
    amend_parser = team_subparsers.add_parser("amend", help="Amend commit")
    amend_parser.add_argument("url", help="PokePaste URL")
    amend_parser.add_argument("-m", "--message", required=True, help="Commit message")

    # team status
    team_subparsers.add_parser("status", help="Show status")

    # team history
    team_subparsers.add_parser("history", help="Show history")

    # team timeline
    team_subparsers.add_parser("timeline", help="Show timeline")

    # team compare
    compare_parser = team_subparsers.add_parser("compare", help="Compare commits")
    compare_parser.add_argument(
        "ref1", nargs="?", default=None, help="First commit hash (optional)"
    )
    compare_parser.add_argument(
        "ref2", nargs="?", default=None, help="Second commit hash (optional)"
    )

    # team combine
    combine_parser = team_subparsers.add_parser("combine", help="Merge variants")
    combine_parser.add_argument("source", help="Source variant")
    combine_parser.add_argument("--target", help="Target variant (default: active)")

    # team tidy
    team_subparsers.add_parser("tidy", help="Garbage collection")

    # team stats
    team_subparsers.add_parser("stats", help="Show stats")

    # team view
    view_parser = team_subparsers.add_parser("view", help="View team content")
    view_parser.add_argument(
        "commit_hash",
        nargs="?",
        default=None,
        help="Commit hash (default: current variant head)",
    )

    # Help
    subparsers.add_parser("help", help="Show help")

    return parser.parse_args(args)


def main(args: Optional[list[str]] = None):
    """Main entry point."""
    try:
        parsed_args = parse_args(args)
    except SystemExit:
        return EXIT_ERROR

    cmd = GittoCommand()

    # Dispatch commands
    if not parsed_args.command:
        cmd.cmd_help(None)
        return EXIT_SUCCESS

    if parsed_args.command == "help":
        return cmd.cmd_help(parsed_args)
    elif parsed_args.command == "team":
        if parsed_args.subcommand == "create":
            return cmd.cmd_team_create(parsed_args)
        elif parsed_args.subcommand == "switch":
            return cmd.cmd_team_switch(parsed_args)
        elif parsed_args.subcommand == "list":
            return cmd.cmd_team_list(parsed_args)
        elif parsed_args.subcommand == "rename":
            return cmd.cmd_team_rename(parsed_args)
        elif parsed_args.subcommand == "delete":
            return cmd.cmd_team_delete(parsed_args)
        elif parsed_args.subcommand == "variant":
            return cmd.cmd_variant_create(parsed_args)
        elif parsed_args.subcommand == "use":
            return cmd.cmd_variant_switch(parsed_args)
        elif parsed_args.subcommand == "discard":
            return cmd.cmd_variant_delete(parsed_args)
        elif parsed_args.subcommand == "variants":
            return cmd.cmd_variant_list(parsed_args)
        elif parsed_args.subcommand == "update":
            return cmd.cmd_update(parsed_args)
        elif parsed_args.subcommand == "amend":
            return cmd.cmd_amend(parsed_args)
        elif parsed_args.subcommand == "status":
            return cmd.cmd_status(parsed_args)
        elif parsed_args.subcommand == "history":
            return cmd.cmd_history(parsed_args)
        elif parsed_args.subcommand == "timeline":
            return cmd.cmd_timeline(parsed_args)
        elif parsed_args.subcommand == "compare":
            return cmd.cmd_compare(parsed_args)
        elif parsed_args.subcommand == "combine":
            return cmd.cmd_merge(parsed_args)
        elif parsed_args.subcommand == "tidy":
            return cmd.cmd_tidy(parsed_args)
        elif parsed_args.subcommand == "stats":
            return cmd.cmd_stats(parsed_args)
        elif parsed_args.subcommand == "view":
            return cmd.cmd_view(parsed_args)
        else:
            cmd.cmd_help(parsed_args)
            return EXIT_SUCCESS
    else:
        cmd.cmd_help(parsed_args)
        return EXIT_SUCCESS


if __name__ == "__main__":
    sys.exit(main())
