"""
REPL loop for interactive Gitto usage.
"""

import argparse
import shlex
import sys
from typing import Optional

from gitto import __version__
from gitto.cli.command import main
from gitto.config.constants import ERROR
from gitto.core.repository import Repository


class GittoREPL:
    """Interactive REPL for Gitto."""

    def __init__(self):
        """Initialize REPL."""
        self.repo: Optional[Repository] = None
        self.running = True

    def _update_prompt(self) -> str:
        """Generate prompt based on current state."""
        try:
            self.repo = Repository.find_repo()
            if self.repo:
                team, variant = self.repo.get_current_state()
                if team and variant:
                    return f"gitto({team}/{variant})> "
                elif team:
                    return f"gitto({team})> "
        except Exception:
            pass

        return "gitto> "

    def _process_command(self, user_input: str) -> int:
        """
        Process a user command.
        """
        if not user_input.strip():
            return 0

        # Split input into args (using shlex to respect quoted strings)
        try:
            parts = shlex.split(user_input.strip())
        except ValueError as e:
            print(f"{ERROR} Command parsing error: {e}")
            return 1

        # Handle special commands
        if parts[0] in ["quit", "exit", "q"]:
            self.running = False
            return 0

        if parts[0] in ["clear", "cls"]:
            import os

            os.system("cls" if sys.platform == "win32" else "clear")
            return 0

        # Delegate to main command handler
        try:
            return main(parts)
        except Exception as e:
            print(f"{ERROR} Command error: {e}")
            return 1

    def run(self):
        """Run the REPL loop."""
        print("\nWelcome to Gitto!")
        print("A Git-like CLI tool for PokéPaste team version control")
        print("Type 'help' for commands or 'exit'/'quit' to exit\n")

        while self.running:
            try:
                prompt = self._update_prompt()
                user_input = input(prompt)
                self._process_command(user_input)
            except KeyboardInterrupt:
                print("\n")
                self.running = False
            except EOFError:
                print()
                self.running = False
            except Exception as e:
                print(f"{ERROR} {e}")


def run_repl():
    """Start the REPL."""
    repl = GittoREPL()
    repl.run()


def main_entry():
    """Main entry point for the gitto command-line tool."""
    parser = argparse.ArgumentParser(
        prog="gitto",
        description="Git-like CLI for Pokémon team version control",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    # Parse only the first argument for flags; remaining args are passed to REPL
    _, remaining = parser.parse_known_args()

    # If there are remaining arguments, treat them as commands to run
    if remaining:
        try:
            return main(remaining)
        except SystemExit:
            return 0

    # Otherwise, start the REPL
    run_repl()
    return 0


if __name__ == "__main__":
    sys.exit(main_entry())
