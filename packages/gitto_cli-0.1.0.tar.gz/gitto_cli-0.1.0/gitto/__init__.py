"""Gitto - A command-line tool for PokéPaste team version control."""

__version__ = "0.1.0"
__author__ = "Sai Nikhil Tadepalli"
