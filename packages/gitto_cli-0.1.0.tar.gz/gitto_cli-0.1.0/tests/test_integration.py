"""
Integration tests for Gitto.
Tests multiple services working together.
"""

from gitto.config.constants import DEFAULT_VARIANT


class TestTeamAndVariantIntegration:
    """Test team and variant services working together."""

    def test_create_team_and_variants(self, team_service, variant_service):
        """Test creating a team and then variants."""
        team_service.create_team("main-team")
        team_service.switch_team("main-team")

        variant_service.create_variant("variant-a")
        variant_service.create_variant("variant-b")

        variants = variant_service.list_variants()
        assert DEFAULT_VARIANT in variants
        assert "variant-a" in variants
        assert "variant-b" in variants

    def test_switch_team_then_variants(self, team_service, variant_service):
        """Test switching between teams and variants."""
        team_service.create_team("team-1")
        team_service.create_team("team-2")

        # Team 1 setup
        team_service.switch_team("team-1")
        variant_service.create_variant("v1-a")
        variant_service.switch_variant("v1-a")
        team1_state = team_service.repo.get_current_state()

        # Team 2 setup
        team_service.switch_team("team-2")
        variant_service.create_variant("v2-a")
        variant_service.switch_variant("v2-a")
        team2_state = team_service.repo.get_current_state()

        # Verify states
        assert team1_state[0] == "team-1"
        assert team1_state[1] == "v1-a"
        assert team2_state[0] == "team-2"
        assert team2_state[1] == "v2-a"

    def test_rename_team_with_variants(self, team_service, variant_service):
        """Test renaming a team preserves variants."""
        team_service.create_team("old-name")
        team_service.switch_team("old-name")
        variant_service.create_variant("var-1")

        team_service.rename_team("old-name", "new-name")
        team_service.switch_team("new-name")

        variants = variant_service.list_variants()
        assert "var-1" in variants

    def test_delete_team_clears_all_variants(self, team_service, variant_service):
        """Test deleting a team removes all its variants."""
        team_service.create_team("doomed-team")
        team_service.switch_team("doomed-team")
        variant_service.create_variant("v1")
        variant_service.create_variant("v2")

        team_service.delete_team("doomed-team")

        # Verify team and all variants are gone
        assert not team_service.repo.refs.team_exists("doomed-team")


class TestCommitWorkflow:
    """Test complete commit workflow."""

    def test_update_and_amend_workflow(
        self, team_service, commit_service, valid_pokepaste_url_1, valid_pokepaste_url_2
    ):
        """Test creating and amending commits in sequence."""
        team_service.create_team("test-team")
        team_service.switch_team("test-team")

        # Create initial commit
        success1, _, hash1 = commit_service.update_team(
            valid_pokepaste_url_1, "Initial team"
        )
        assert success1 is True
        assert hash1 is not None

        # Amend the commit
        success2, _, hash2 = commit_service.amend_team(
            valid_pokepaste_url_2, "Updated team"
        )
        assert success2 is True
        assert hash2 != hash1

        # Verify history
        history = commit_service.get_commit_history("test-team", DEFAULT_VARIANT)
        assert len(history) == 1  # Amendment replaces, doesn't add
        assert history[0][0] == hash2  # Check hash from tuple (hash, commit)

    def test_multiple_commits_different_variants(
        self,
        team_service,
        variant_service,
        commit_service,
        valid_pokepaste_url_1,
        valid_pokepaste_url_2,
    ):
        """Test creating commits in different variants of same team."""
        team_service.create_team("team")
        team_service.switch_team("team")

        # Commit in main variant
        _, _, hash1_main = commit_service.update_team(
            valid_pokepaste_url_1, "Main variant commit"
        )

        # Create and switch to new variant
        variant_service.create_variant("experiment")
        variant_service.switch_variant("experiment")
        _, _, hash1_exp = commit_service.update_team(
            valid_pokepaste_url_2, "Experiment commit"
        )

        # Verify separate histories
        main_history = commit_service.get_commit_history("team", DEFAULT_VARIANT)
        exp_history = commit_service.get_commit_history("team", "experiment")

        assert main_history[0][0] == hash1_main  # Check hash from tuple (hash, commit)
        assert exp_history[0][0] == hash1_exp
        assert hash1_main != hash1_exp

    def test_commit_chain_with_parents(
        self, team_service, commit_service, valid_pokepaste_url_1, valid_pokepaste_url_2
    ):
        """Test that commits properly chain with parent references."""
        team_service.create_team("chain-team")
        team_service.switch_team("chain-team")

        _, _, hash1 = commit_service.update_team(valid_pokepaste_url_1, "First")
        _, _, hash2 = commit_service.update_team(valid_pokepaste_url_2, "Second")

        # Load second commit and verify parent
        commit2_obj = commit_service.repo.objects.retrieve(hash2)
        assert commit2_obj is not None
        assert len(commit2_obj.parent_hashes) == 1
        assert commit2_obj.parent_hashes[0] == hash1


class TestRepositoryStateIntegration:
    """Test repository state across operations."""

    def test_state_persistence_across_team_operations(self, team_service):
        """Test that repository state is properly maintained."""
        team_service.create_team("team-1")
        team_service.create_team("team-2")

        # Set state to team 1
        team_service.switch_team("team-1")
        team, _ = team_service.repo.get_current_state()
        assert team == "team-1"

        # Create team 2 but don't switch
        team, _ = team_service.repo.get_current_state()
        assert team == "team-1"  # Should still be team-1

        # Switch to team 2
        team_service.switch_team("team-2")
        team, _ = team_service.repo.get_current_state()
        assert team == "team-2"

    def test_state_cleared_on_delete_active_team(self, team_service):
        """Test that deleting active team clears state."""
        team_service.create_team("only-team")
        team_service.switch_team("only-team")

        # Verify team is active
        team, _ = team_service.repo.get_current_state()
        assert team == "only-team"

        # Delete it
        team_service.delete_team("only-team")

        # Verify state is cleared
        team, variant = team_service.repo.get_current_state()
        assert team is None
        assert variant is None


class TestMultiTeamScenarios:
    """Test scenarios with multiple teams."""

    def test_switch_between_multiple_teams(self, team_service):
        """Test switching between three teams."""
        for name in ["team-a", "team-b", "team-c"]:
            team_service.create_team(name)

        for name in ["team-a", "team-b", "team-c"]:
            team_service.switch_team(name)
            team, _ = team_service.repo.get_current_state()
            assert team == name

    def test_list_teams_consistency(self, team_service):
        """Test that team listing is consistent."""
        names = ["z-team", "a-team", "m-team"]
        for name in names:
            team_service.create_team(name)

        teams = team_service.list_teams()
        expected = ["a-team", "m-team", "z-team"]
        assert teams == expected

    def test_delete_non_active_preserves_state(self, team_service):
        """Test deleting a non-active team doesn't affect active team."""
        team_service.create_team("keep-this")
        team_service.create_team("delete-this")

        team_service.switch_team("keep-this")
        team_service.delete_team("delete-this")

        team, _ = team_service.repo.get_current_state()
        assert team == "keep-this"


class TestVariantEdgeCases:
    """Test variant edge cases in integrated scenarios."""

    def test_cannot_delete_default_variant(self, team_service, variant_service):
        """Test that default variant cannot be deleted."""
        team_service.create_team("team")
        team_service.switch_team("team")

        success, _ = variant_service.delete_variant(DEFAULT_VARIANT)
        assert success is False

    def test_switch_to_default_variant(self, team_service, variant_service):
        """Test switching to the default variant."""
        team_service.create_team("team")
        team_service.switch_team("team")
        variant_service.create_variant("custom")
        variant_service.switch_variant("custom")

        # Switch back to default
        variant_service.switch_variant(DEFAULT_VARIANT)
        _, current_variant = team_service.repo.get_current_state()
        assert current_variant == DEFAULT_VARIANT


class TestNameValidationIntegration:
    """Test name validation across services."""

    def test_invalid_names_rejected_at_creation(self, team_service, variant_service):
        """Test that invalid names are rejected."""
        success, _ = team_service.create_team("invalid name")
        assert success is False

        team_service.create_team("valid-team")
        team_service.switch_team("valid-team")

        success, _ = variant_service.create_variant("invalid name")
        assert success is False

    def test_valid_names_accepted(self, team_service, variant_service):
        """Test that valid names are accepted."""
        valid_team = "valid-team-123"
        valid_variant = "valid-var-456"

        success, _ = team_service.create_team(valid_team)
        assert success is True

        team_service.switch_team(valid_team)
        success, _ = variant_service.create_variant(valid_variant)
        assert success is True
