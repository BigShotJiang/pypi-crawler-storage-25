"""
Pytest configuration and shared fixtures for Gitto tests.
"""

from pathlib import Path
import tempfile

import pytest

from gitto.core.repository import Repository
from gitto.services.team_service import TeamService
from gitto.services.variant_service import VariantService
from gitto.services.commit_service import CommitService


@pytest.fixture
def temp_dir():
    """Create a temporary directory for testing."""
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


@pytest.fixture
def repo(temp_dir, monkeypatch):
    """Create a test repository in a temporary directory."""
    monkeypatch.chdir(temp_dir)
    return Repository(temp_dir)


@pytest.fixture
def team_service(repo):
    """Create a team service with test repository."""
    return TeamService(repo)


@pytest.fixture
def variant_service(repo):
    """Create a variant service with test repository."""
    return VariantService(repo)


@pytest.fixture
def commit_service(repo):
    """Create a commit service with test repository."""
    return CommitService(repo)


@pytest.fixture
def test_team_name():
    """Return a test team name."""
    return "test-team"


@pytest.fixture
def test_variant_name():
    """Return a test variant name."""
    return "test-variant"


@pytest.fixture
def test_message():
    """Return a test commit message."""
    return "Test commit message"


@pytest.fixture
def test_author():
    """Return a test author name."""
    return "test-author"


@pytest.fixture
def valid_pokepaste_url_1():
    """Valid PokePaste URL for testing."""
    return "https://pokepast.es/ded91db8cf09afcd"


@pytest.fixture
def valid_pokepaste_url_2():
    """Valid PokePaste URL for testing."""
    return "https://pokepast.es/3013f68af29ec535"


@pytest.fixture
def invalid_pokepaste_urls():
    """Collection of invalid PokePaste URLs."""
    return [
        "https://example.com",
        "https://pokepast.es/",
        "http://pokepast.es/invalid url with spaces",
        "https://pokepaste.es/ded91db8cf09afcd",  # typo: pokepaste instead of pokepast
        "not-a-url",
        "",
    ]
