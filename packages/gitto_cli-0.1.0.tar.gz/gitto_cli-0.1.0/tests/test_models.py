"""
Test suite for data models (Blob, Tree, Commit).
Covers object creation, serialization, and properties.
"""

import json
from gitto.models.objects import Blob, Tree, Commit


class TestBlobModel:
    """Test Blob data model."""

    def test_blob_creation(self):
        """Test creating a Blob object."""
        blob = Blob(team_name="test-team", raw_text="Team data here")
        assert blob.team_name == "test-team"
        assert blob.raw_text == "Team data here"

    def test_blob_to_dict(self):
        """Test converting Blob to dictionary."""
        blob = Blob(team_name="test-team", raw_text="Team data")
        blob_dict = blob.to_dict()

        assert blob_dict["team_name"] == "test-team"
        assert blob_dict["raw_text"] == "Team data"

    def test_blob_to_json(self):
        """Test converting Blob to JSON."""
        blob = Blob(team_name="test-team", raw_text="Team data")
        blob_json = blob.to_json()

        # Should be valid JSON
        parsed = json.loads(blob_json)
        assert parsed["team_name"] == "test-team"
        assert parsed["raw_text"] == "Team data"

    def test_blob_json_consistency(self):
        """Test that JSON output is deterministic."""
        blob = Blob(team_name="test", raw_text="data")
        json1 = blob.to_json()
        json2 = blob.to_json()

        assert json1 == json2

    def test_blob_with_special_characters(self):
        """Test Blob with special characters in raw text."""
        special_text = 'Team data with "quotes" and \\backslashes\n and \t tabs'
        blob = Blob(team_name="test", raw_text=special_text)
        blob_json = blob.to_json()

        parsed = json.loads(blob_json)
        assert parsed["raw_text"] == special_text

    def test_blob_with_empty_raw_text(self):
        """Test Blob with empty raw text."""
        blob = Blob(team_name="test", raw_text="")
        assert blob.raw_text == ""
        blob_dict = blob.to_dict()
        assert blob_dict["raw_text"] == ""


class TestTreeModel:
    """Test Tree data model."""

    def test_tree_creation_basic(self):
        """Test creating a Tree object with blob hash."""
        tree = Tree(blob_hash="abc123def456")
        assert tree.blob_hash == "abc123def456"
        assert tree.metadata is None

    def test_tree_creation_with_metadata(self):
        """Test creating a Tree object with metadata."""
        metadata = {"size": 512, "type": "pokemon-team"}
        tree = Tree(blob_hash="abc123", metadata=metadata)
        assert tree.metadata == metadata

    def test_tree_to_dict(self):
        """Test converting Tree to dictionary."""
        tree = Tree(blob_hash="abc123")
        tree_dict = tree.to_dict()

        assert tree_dict["blob_hash"] == "abc123"
        assert tree_dict["metadata"] == {}

    def test_tree_to_dict_with_metadata(self):
        """Test converting Tree with metadata to dictionary."""
        metadata = {"key": "value"}
        tree = Tree(blob_hash="abc123", metadata=metadata)
        tree_dict = tree.to_dict()

        assert tree_dict["metadata"] == metadata

    def test_tree_to_json(self):
        """Test converting Tree to JSON."""
        tree = Tree(blob_hash="abc123")
        tree_json = tree.to_json()

        parsed = json.loads(tree_json)
        assert parsed["blob_hash"] == "abc123"

    def test_tree_json_consistency(self):
        """Test that Tree JSON is deterministic."""
        tree = Tree(blob_hash="hash", metadata={"a": 1})
        json1 = tree.to_json()
        json2 = tree.to_json()

        assert json1 == json2


class TestCommitModel:
    """Test Commit data model."""

    def test_commit_creation_initial(self):
        """Test creating an initial commit (no parents)."""
        commit = Commit(
            tree_hash="tree123",
            parent_hashes=[],
            message="Initial commit",
            timestamp=1234567890,
            author="test-author",
        )
        assert commit.tree_hash == "tree123"
        assert commit.parent_hashes == []
        assert commit.message == "Initial commit"

    def test_commit_creation_with_parent(self):
        """Test creating a commit with one parent."""
        commit = Commit(
            tree_hash="tree123",
            parent_hashes=["parent123"],
            message="Second commit",
            timestamp=1234567890,
            author="test-author",
        )
        assert len(commit.parent_hashes) == 1
        assert commit.parent_hashes[0] == "parent123"

    def test_commit_creation_with_multiple_parents(self):
        """Test creating a merge commit with multiple parents."""
        commit = Commit(
            tree_hash="tree123",
            parent_hashes=["parent1", "parent2"],
            message="Merge commit",
            timestamp=1234567890,
            author="test-author",
        )
        assert len(commit.parent_hashes) == 2

    def test_commit_is_initial_property(self):
        """Test is_initial property."""
        initial = Commit(
            tree_hash="tree",
            parent_hashes=[],
            message="msg",
            timestamp=123,
            author="auth",
        )
        assert initial.is_initial is True

        with_parent = Commit(
            tree_hash="tree",
            parent_hashes=["p1"],
            message="msg",
            timestamp=123,
            author="auth",
        )
        assert with_parent.is_initial is False

    def test_commit_is_merge_commit_property(self):
        """Test is_merge_commit property."""
        normal = Commit(
            tree_hash="tree",
            parent_hashes=["p1"],
            message="msg",
            timestamp=123,
            author="auth",
        )
        assert normal.is_merge_commit is False

        merge = Commit(
            tree_hash="tree",
            parent_hashes=["p1", "p2"],
            message="msg",
            timestamp=123,
            author="auth",
        )
        assert merge.is_merge_commit is True

    def test_commit_to_dict(self):
        """Test converting Commit to dictionary."""
        commit = Commit(
            tree_hash="tree123",
            parent_hashes=["parent1"],
            message="Test commit",
            timestamp=1234567890,
            author="test-author",
        )
        commit_dict = commit.to_dict()

        assert commit_dict["tree_hash"] == "tree123"
        assert commit_dict["parent_hashes"] == ["parent1"]
        assert commit_dict["message"] == "Test commit"
        assert commit_dict["timestamp"] == 1234567890
        assert commit_dict["author"] == "test-author"

    def test_commit_to_json(self):
        """Test converting Commit to JSON."""
        commit = Commit(
            tree_hash="tree123",
            parent_hashes=[],
            message="Test",
            timestamp=123456,
            author="author",
        )
        commit_json = commit.to_json()

        parsed = json.loads(commit_json)
        assert parsed["tree_hash"] == "tree123"
        assert parsed["message"] == "Test"

    def test_commit_json_consistency(self):
        """Test that Commit JSON is deterministic."""
        commit = Commit(
            tree_hash="tree",
            parent_hashes=["p1", "p2"],
            message="msg",
            timestamp=123,
            author="auth",
        )
        json1 = commit.to_json()
        json2 = commit.to_json()

        assert json1 == json2

    def test_commit_with_empty_message(self):
        """Test commit with empty message."""
        commit = Commit(
            tree_hash="tree", parent_hashes=[], message="", timestamp=123, author="auth"
        )
        assert commit.message == ""

    def test_commit_with_long_message(self):
        """Test commit with a long message."""
        long_msg = "x" * 1000
        commit = Commit(
            tree_hash="tree",
            parent_hashes=[],
            message=long_msg,
            timestamp=123,
            author="auth",
        )
        assert len(commit.message) == 1000

    def test_commit_with_special_characters_in_message(self):
        """Test commit with special characters in message."""
        message = 'Updated team with "special" chars: @#$%^&*()'
        commit = Commit(
            tree_hash="tree",
            parent_hashes=[],
            message=message,
            timestamp=123,
            author="auth",
        )
        commit_json = commit.to_json()
        parsed = json.loads(commit_json)
        assert parsed["message"] == message

    def test_commit_timestamp_types(self):
        """Test commit with different timestamp values."""
        # Modern timestamp
        commit1 = Commit(
            tree_hash="tree",
            parent_hashes=[],
            message="msg",
            timestamp=1700000000,
            author="auth",
        )
        assert commit1.timestamp == 1700000000

        # Old timestamp
        commit2 = Commit(
            tree_hash="tree",
            parent_hashes=[],
            message="msg",
            timestamp=0,
            author="auth",
        )
        assert commit2.timestamp == 0


class TestCommitSerializationEdgeCases:
    """Test edge cases in commit serialization."""

    def test_commit_with_many_parents(self):
        """Test commit with many parent hashes."""
        # Theoretically possible though unusual
        parents = [f"parent{i}" for i in range(10)]
        commit = Commit(
            tree_hash="tree",
            parent_hashes=parents,
            message="Unusual merge",
            timestamp=123,
            author="auth",
        )
        assert len(commit.parent_hashes) == 10
        commit_dict = commit.to_dict()
        assert len(commit_dict["parent_hashes"]) == 10

    def test_commit_json_parsing_roundtrip(self):
        """Test that commit can be serialized and parsed back."""
        original = Commit(
            tree_hash="tree123",
            parent_hashes=["p1", "p2"],
            message="Test message",
            timestamp=1234567890,
            author="test-author",
        )

        json_str = original.to_json()
        parsed = json.loads(json_str)

        assert parsed["tree_hash"] == original.tree_hash
        assert parsed["parent_hashes"] == original.parent_hashes
        assert parsed["message"] == original.message
        assert parsed["timestamp"] == original.timestamp
        assert parsed["author"] == original.author
