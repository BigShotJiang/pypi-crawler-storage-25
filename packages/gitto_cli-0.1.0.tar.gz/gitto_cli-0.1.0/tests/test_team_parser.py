"""
Test suite for team parsing and species-indexed diffing.
"""

from gitto.utils.team_parser import compare_teams, parse_team


TEAM_BASE = """Mozilla (Ninetales) @ Heat Rock
Ability: Drought
Shiny: Yes
Tera Type: Flying
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
IVs: 0 Atk
- Fire Blast
- Solar Beam
- Encore
- Healing Wish

BruteRoot (Venusaur) @ Life Orb
Ability: Chlorophyll
Tera Type: Water
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
IVs: 0 Atk
- Growth
- Solar Beam
- Weather Ball
- Sludge Bomb
"""


TEAM_CHANGED = """Mozilla (Ninetales) @ Heavy-Duty Boots
Ability: Drought
Shiny: Yes
Tera Type: Fire
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
IVs: 0 Atk
- Fire Blast
- Solar Beam
- Memento
- Healing Wish

BruteRoot (Venusaur) @ Life Orb
Ability: Chlorophyll
Tera Type: Water
EVs: 252 Atk / 4 SpD / 252 Spe
Adamant Nature
IVs: 0 Atk
- Swords Dance
- Seed Bomb
- Weather Ball
- Sludge Bomb

Stitch (Sableye) @ Red Card
Ability: Prankster
Tera Type: Steel
EVs: 252 HP / 4 Atk / 252 SpD
Careful Nature
- Sunny Day
- Will-O-Wisp
- Knock Off
- Poltergeist
"""


TEAM_REORDERED = """BruteRoot (Venusaur) @ Life Orb
Ability: Chlorophyll
Tera Type: Water
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
IVs: 0 Atk
- Sludge Bomb
- Weather Ball
- Solar Beam
- Growth

Mozilla (Ninetales) @ Heat Rock
Ability: Drought
Shiny: Yes
Tera Type: Flying
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
IVs: 0 Atk
- Healing Wish
- Encore
- Solar Beam
- Fire Blast
"""


TEAM_HTML = """<html><body>
<pre>Mozilla (Ninetales) @ Heat Rock
Ability: Drought
Shiny: Yes
Tera Type: Flying
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
IVs: 0 Atk
- Fire Blast
- Solar Beam
- Encore
- Healing Wish</pre>
<pre>BruteRoot (Venusaur) @ Life Orb
Ability: Chlorophyll
Tera Type: Water
EVs: 252 SpA / 4 SpD / 252 Spe
Modest Nature
IVs: 0 Atk
- Growth
- Solar Beam
- Weather Ball
- Sludge Bomb</pre>
</body></html>"""


class TestTeamParser:
    """Test parsing logic for PokePaste team text."""

    def test_parse_team_parses_plain_text_blocks(self):
        """Plain stored blob text should parse into Pokemon entries."""
        team = parse_team(TEAM_BASE)

        assert len(team) == 2
        assert team[0].species == "Ninetales"
        assert team[0].nickname == "Mozilla"
        assert team[0].item == "Heat Rock"
        assert team[0].ability == "Drought"
        assert team[0].tera_type == "Flying"
        assert team[0].nature == "Timid"
        assert team[0].stats["Nature"] == "Timid"
        assert team[0].stats["EVs"] == "252 SpA / 4 SpD / 252 Spe"
        assert team[0].moves == [
            "Fire Blast",
            "Solar Beam",
            "Encore",
            "Healing Wish",
        ]

    def test_parse_team_parses_html_pre_blocks(self):
        """HTML PokePaste content should parse through the <pre> path."""
        team = parse_team(TEAM_HTML)

        assert len(team) == 2
        assert team[1].species == "Venusaur"
        assert team[1].nickname == "BruteRoot"
        assert team[1].stats["Ability"] == "Chlorophyll"


class TestTeamDiffing:
    """Test species-indexed diff generation."""

    def test_compare_teams_detects_no_differences_for_identical_teams(self):
        """Identical teams should report no differences."""
        changes = compare_teams(parse_team(TEAM_BASE), parse_team(TEAM_BASE))

        assert changes == ["No differences detected"]

    def test_compare_teams_ignores_team_order_and_move_order(self):
        """Reordering species or moves alone should not count as a diff."""
        changes = compare_teams(parse_team(TEAM_BASE), parse_team(TEAM_REORDERED))

        assert changes == ["No differences detected"]

    def test_compare_teams_reports_added_and_removed_species(self):
        """Species missing from one side should show as removed or added."""
        changes = compare_teams(parse_team(TEAM_BASE), parse_team(TEAM_CHANGED))

        assert "[-] Removed Ninetales" not in changes
        assert any(change == "[+] Added Sableye" for change in changes)

    def test_compare_teams_reports_item_and_nickname_changes(self):
        """Core attributes should use the provided diff message format."""
        old_team = """Mozilla (Ninetales) @ Heat Rock
Ability: Drought
Shiny: Yes
Tera Type: Flying
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Fire Blast
"""
        new_team = """Kitsune (Ninetales) @ Heavy-Duty Boots
Ability: Drought
Shiny: Yes
Tera Type: Flying
EVs: 252 SpA / 4 SpD / 252 Spe
Timid Nature
- Fire Blast
"""

        changes = compare_teams(parse_team(old_team), parse_team(new_team))

        assert "[*] Ninetales:" in changes
        assert "    - Item: Heat Rock -> Heavy-Duty Boots" in changes
        assert "    - Nickname: Mozilla -> Kitsune" in changes

    def test_compare_teams_reports_move_changes(self):
        """Move additions and removals should be aggregated into one message."""
        changes = compare_teams(parse_team(TEAM_BASE), parse_team(TEAM_CHANGED))

        venusaur_section = _section_for_species(changes, "Venusaur")
        ninetales_section = _section_for_species(changes, "Ninetales")

        assert any("Moves changed" in line for line in venusaur_section)
        assert any("Growth" in line for line in venusaur_section)
        assert any("Swords Dance" in line for line in venusaur_section)
        assert any("Moves changed" in line for line in ninetales_section)
        assert any("Encore" in line for line in ninetales_section)
        assert any("Memento" in line for line in ninetales_section)

    def test_compare_teams_reports_stat_changes_from_stats_dictionary(self):
        """Stats captured from metadata lines should be compared by key."""
        changes = compare_teams(parse_team(TEAM_BASE), parse_team(TEAM_CHANGED))

        venusaur_section = _section_for_species(changes, "Venusaur")
        ninetales_section = _section_for_species(changes, "Ninetales")

        assert "    - EVs: 252 SpA / 4 SpD / 252 Spe -> 252 Atk / 4 SpD / 252 Spe" in venusaur_section
        assert "    - Nature: Modest -> Adamant" in venusaur_section
        assert "    - Item: Heat Rock -> Heavy-Duty Boots" in ninetales_section
        assert "    - Tera Type: Flying -> Fire" in ninetales_section


def _section_for_species(changes: list[str], species: str) -> list[str]:
    """Extract one species section from compare output."""
    header = f"[*] {species}:"
    if header not in changes:
        return []

    start = changes.index(header)
    section = []
    for line in changes[start + 1 :]:
        if line.startswith("[*] ") or line.startswith("[+] ") or line.startswith("[-] "):
            break
        section.append(line)
    return section
