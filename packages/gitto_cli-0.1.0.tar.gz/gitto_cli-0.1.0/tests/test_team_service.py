"""
Test suite for TeamService.
Covers team creation, deletion, switching, renaming, and listing.
"""

from gitto.config.constants import DEFAULT_VARIANT


class TestTeamCreation:
    """Test team creation functionality."""

    def test_create_team_normal(self, team_service, test_team_name):
        """Test creating a team with valid name."""
        success, msg = team_service.create_team(test_team_name)
        assert success is True
        assert test_team_name in msg
        assert team_service.repo.refs.team_exists(test_team_name)

    def test_create_team_creates_default_variant(self, team_service, test_team_name):
        """Test that creating a team also creates the default variant."""
        team_service.create_team(test_team_name)
        variants = team_service.repo.refs.list_variants(test_team_name)
        assert DEFAULT_VARIANT in variants

    def test_create_team_duplicate(self, team_service, test_team_name):
        """Test creating a team that already exists."""
        team_service.create_team(test_team_name)
        success, msg = team_service.create_team(test_team_name)
        assert success is False
        assert "already exists" in msg

    def test_create_team_invalid_name_with_spaces(self, team_service):
        """Test creating a team with spaces in name."""
        success, msg = team_service.create_team("invalid team")
        assert success is False
        assert "Invalid team name" in msg

    def test_create_team_invalid_name_with_special_chars(self, team_service):
        """Test creating a team with special characters."""
        success, msg = team_service.create_team("team@123")
        assert success is False
        assert "Invalid team name" in msg

    def test_create_team_invalid_name_empty(self, team_service):
        """Test creating a team with empty name."""
        success, _ = team_service.create_team("")
        assert success is False

    def test_create_team_valid_names(self, team_service):
        """Test creating teams with various valid names."""
        valid_names = ["team-1", "Team-123", "a", "my-team-123"]
        for name in valid_names:
            success, _ = team_service.create_team(name)
            assert success is True, f"Failed to create team '{name}'"


class TestTeamDeletion:
    """Test team deletion functionality."""

    def test_delete_team_normal(self, team_service, test_team_name):
        """Test deleting a team that exists."""
        team_service.create_team(test_team_name)
        success, msg = team_service.delete_team(test_team_name)
        assert success is True
        assert test_team_name in msg
        assert not team_service.repo.refs.team_exists(test_team_name)

    def test_delete_nonexistent_team(self, team_service):
        """Test deleting a team that doesn't exist."""
        success, msg = team_service.delete_team("nonexistent")
        assert success is False
        assert "does not exist" in msg

    def test_delete_active_team_clears_head(self, team_service, test_team_name):
        """Test that deleting the active team clears the HEAD state."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        # Verify team is active
        current_team, _ = team_service.repo.get_current_state()
        assert current_team == test_team_name

        # Delete the active team
        success, _ = team_service.delete_team(test_team_name)
        assert success is True

        # Verify HEAD is cleared
        current_team, current_variant = team_service.repo.get_current_state()
        assert current_team is None
        assert current_variant is None

    def test_delete_inactive_team(self, team_service):
        """Test deleting an inactive team."""
        team_service.create_team("team-a")
        team_service.create_team("team-b")
        team_service.switch_team("team-a")

        # Delete inactive team
        success, _ = team_service.delete_team("team-b")
        assert success is True
        assert not team_service.repo.refs.team_exists("team-b")

        # Active team should remain unchanged
        current_team, _ = team_service.repo.get_current_state()
        assert current_team == "team-a"


class TestTeamSwitching:
    """Test team switching functionality."""

    def test_switch_team_normal(self, team_service, test_team_name):
        """Test switching to an existing team."""
        team_service.create_team(test_team_name)
        success, msg = team_service.switch_team(test_team_name)
        assert success is True
        assert test_team_name in msg

        current_team, current_variant = team_service.repo.get_current_state()
        assert current_team == test_team_name
        assert current_variant == DEFAULT_VARIANT

    def test_switch_nonexistent_team(self, team_service):
        """Test switching to a team that doesn't exist."""
        success, msg = team_service.switch_team("nonexistent")
        assert success is False
        assert "does not exist" in msg

    def test_switch_between_teams(self, team_service):
        """Test switching between multiple teams."""
        team_service.create_team("team-a")
        team_service.create_team("team-b")

        team_service.switch_team("team-a")
        current_team, _ = team_service.repo.get_current_state()
        assert current_team == "team-a"

        team_service.switch_team("team-b")
        current_team, _ = team_service.repo.get_current_state()
        assert current_team == "team-b"

    def test_switch_to_same_team(self, team_service, test_team_name):
        """Test switching to the currently active team."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, _ = team_service.switch_team(test_team_name)
        assert success is True


class TestTeamListing:
    """Test team listing functionality."""

    def test_list_teams_empty(self, team_service):
        """Test listing teams when none exist."""
        teams = team_service.list_teams()
        assert teams == []

    def test_list_teams_single(self, team_service, test_team_name):
        """Test listing teams with one team."""
        team_service.create_team(test_team_name)
        teams = team_service.list_teams()
        assert teams == [test_team_name]

    def test_list_teams_multiple(self, team_service):
        """Test listing multiple teams."""
        team_service.create_team("team-a")
        team_service.create_team("team-b")
        team_service.create_team("team-c")
        teams = team_service.list_teams()
        assert teams == ["team-a", "team-b", "team-c"]

    def test_list_teams_sorted(self, team_service):
        """Test that listed teams are sorted."""
        team_service.create_team("zebra")
        team_service.create_team("apple")
        team_service.create_team("banana")
        teams = team_service.list_teams()
        assert teams == ["apple", "banana", "zebra"]


class TestTeamRenaming:
    """Test team renaming functionality."""

    def test_rename_team_normal(self, team_service):
        """Test renaming a team with valid new name."""
        team_service.create_team("old-name")
        success, msg = team_service.rename_team("old-name", "new-name")
        assert success is True
        assert "old-name" in msg
        assert "new-name" in msg
        assert not team_service.repo.refs.team_exists("old-name")
        assert team_service.repo.refs.team_exists("new-name")

    def test_rename_nonexistent_team(self, team_service):
        """Test renaming a team that doesn't exist."""
        success, msg = team_service.rename_team("nonexistent", "new-name")
        assert success is False
        assert "does not exist" in msg

    def test_rename_to_existing_name(self, team_service):
        """Test renaming a team to a name that already exists."""
        team_service.create_team("team-a")
        team_service.create_team("team-b")
        success, msg = team_service.rename_team("team-a", "team-b")
        assert success is False
        assert "already exists" in msg

    def test_rename_active_team_updates_head(self, team_service):
        """Test that renaming the active team updates HEAD."""
        team_service.create_team("old-name")
        team_service.switch_team("old-name")

        team_service.rename_team("old-name", "new-name")

        current_team, current_variant = team_service.repo.get_current_state()
        assert current_team == "new-name"
        assert current_variant == DEFAULT_VARIANT

    def test_rename_inactive_team_preserves_active(self, team_service):
        """Test that renaming an inactive team doesn't change active team."""
        team_service.create_team("team-a")
        team_service.create_team("team-b")
        team_service.switch_team("team-a")

        team_service.rename_team("team-b", "team-b-renamed")

        current_team, _ = team_service.repo.get_current_state()
        assert current_team == "team-a"

    def test_rename_invalid_new_name(self, team_service, test_team_name):
        """Test renaming a team to an invalid name."""
        team_service.create_team(test_team_name)
        success, msg = team_service.rename_team(test_team_name, "invalid name")
        assert success is False
        assert "Invalid team name" in msg


class TestTeamStatus:
    """Test team status retrieval."""

    def test_get_team_status_nonexistent(self, team_service):
        """Test getting status of a team that doesn't exist."""
        status = team_service.get_team_status("nonexistent")
        assert status is None

    def test_get_team_status_normal(self, team_service, test_team_name):
        """Test getting status of an existing team."""
        team_service.create_team(test_team_name)
        status = team_service.get_team_status(test_team_name)
        assert status is not None
        assert status["name"] == test_team_name
        assert DEFAULT_VARIANT in status["variants"]
        assert status["active"] is False

    def test_get_team_status_active(self, team_service, test_team_name):
        """Test getting status of the active team."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        status = team_service.get_team_status(test_team_name)
        assert status["active"] is True
        assert status["current_variant"] == DEFAULT_VARIANT
