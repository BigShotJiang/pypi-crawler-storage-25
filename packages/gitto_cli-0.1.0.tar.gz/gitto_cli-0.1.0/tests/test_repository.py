"""
Test suite for Repository and Head management.
Covers repository initialization, HEAD state management, and file structure.
"""

import pytest

from gitto.core.repository import Repository


class TestRepositoryInitialization:
    """Test repository initialization and structure."""

    def test_repository_creates_gitto_dir(self, temp_dir):
        """Test that creating a repository creates .gitto directory."""
        _ = Repository(temp_dir)
        assert (temp_dir / ".gitto").exists()

    def test_repository_is_initialized(self, temp_dir):
        """Test that repository is marked as initialized."""
        repo = Repository(temp_dir)
        assert repo.is_initialized()

    def test_repository_creates_subdirectories(self, temp_dir):
        """Test that repository creates required subdirectories."""
        repo = Repository(temp_dir)
        gitto_dir = temp_dir / ".gitto"

        assert (gitto_dir / "objects").exists()
        assert (gitto_dir / "refs").exists()
        assert (gitto_dir / "HEAD").exists()

    def test_find_repo_in_current_directory(self, temp_dir, monkeypatch):
        """Test finding repository in current directory."""
        monkeypatch.chdir(temp_dir)
        repo = Repository(temp_dir)

        found_repo = Repository.find_repo(temp_dir)
        assert found_repo is not None
        assert found_repo.work_dir == temp_dir

    def test_find_repo_in_parent_directory(self, temp_dir, monkeypatch):
        """Test finding repository in parent directory."""
        subdir = temp_dir / "subdir" / "nested"
        subdir.mkdir(parents=True)

        repo = Repository(temp_dir)
        found_repo = Repository.find_repo(subdir)
        assert found_repo is not None
        assert found_repo.work_dir == temp_dir

    def test_find_repo_nonexistent(self, temp_dir, monkeypatch):
        """Test finding repository when no repository exists in the local temp hierarchy."""
        monkeypatch.chdir(temp_dir)

        # find_repo() walks all the way to the filesystem root, so this assertion is
        # only valid if the temporary directory is not nested beneath some ambient
        # .gitto repository on the host machine.
        current = temp_dir.parent
        while current != current.parent:
            if (current / ".gitto").exists():
                pytest.skip(
                    "Ambient ancestor .gitto repository detected above temp_dir; "
                    "skipping nonexistent-repo assertion."
                )
            current = current.parent

        found_repo = Repository.find_repo(temp_dir)
        assert found_repo is None


class TestHeadManagement:
    """Test HEAD state management."""

    def test_get_head_initial_state(self, repo):
        """Test that HEAD is None initially."""
        team, variant = repo.get_current_state()
        assert team is None
        assert variant is None

    def test_set_head_and_get(self, repo):
        """Test setting and retrieving HEAD state."""
        repo.set_current_state("team-a", "main")

        team, variant = repo.get_current_state()
        assert team == "team-a"
        assert variant == "main"

    def test_set_head_overwrites_previous(self, repo):
        """Test that setting HEAD overwrites previous state."""
        repo.set_current_state("team-a", "variant-1")
        repo.set_current_state("team-b", "variant-2")

        team, variant = repo.get_current_state()
        assert team == "team-b"
        assert variant == "variant-2"

    def test_head_persistence(self, temp_dir, monkeypatch):
        """Test that HEAD state persists across repository instances."""
        monkeypatch.chdir(temp_dir)
        repo1 = Repository(temp_dir)
        repo1.set_current_state("team-x", "variant-y")

        repo2 = Repository(temp_dir)
        team, variant = repo2.get_current_state()
        assert team == "team-x"
        assert variant == "variant-y"

    def test_clear_head_state(self, repo):
        """Test clearing HEAD state."""
        repo.set_current_state("team-a", "main")
        repo.head.clear()

        team, variant = repo.get_current_state()
        assert team is None
        assert variant is None

    def test_get_head_file_content(self, repo):
        """Test that HEAD file is properly formatted JSON."""
        repo.set_current_state("team-a", "main")

        import json

        with open(repo.gitto_dir / "HEAD", "r") as f:
            head_data = json.load(f)

        assert head_data["team"] == "team-a"
        assert head_data["variant"] == "main"


class TestRepositoryObjects:
    """Test repository object storage access."""

    def test_repository_has_object_store(self, repo):
        """Test that repository provides access to object store."""
        assert repo.objects is not None
        assert hasattr(repo.objects, "store")
        assert hasattr(repo.objects, "retrieve")

    def test_repository_has_ref_store(self, repo):
        """Test that repository provides access to ref store."""
        assert repo.refs is not None
        assert hasattr(repo.refs, "create_team")
        assert hasattr(repo.refs, "team_exists")

    def test_repository_has_head(self, repo):
        """Test that repository provides access to HEAD."""
        assert repo.head is not None
        assert hasattr(repo.head, "set_head")
        assert hasattr(repo.head, "get_head")


class TestRepositoryPaths:
    """Test repository path management."""

    def test_get_logs_dir_creates_directory(self, repo):
        """Test that get_logs_dir creates the logs directory."""
        logs_dir = repo.get_logs_dir()
        assert logs_dir.exists()
        assert logs_dir.name == "logs"

    def test_get_logs_dir_idempotent(self, repo):
        """Test that calling get_logs_dir multiple times is safe."""
        logs_dir1 = repo.get_logs_dir()
        logs_dir2 = repo.get_logs_dir()
        assert logs_dir1 == logs_dir2
        assert logs_dir1.exists()


class TestMultipleRepositories:
    """Test handling multiple repositories."""

    def test_separate_repositories_isolated(self, temp_dir, monkeypatch):
        """Test that separate repositories are isolated."""
        dir1 = temp_dir / "repo1"
        dir2 = temp_dir / "repo2"
        dir1.mkdir()
        dir2.mkdir()

        repo1 = Repository(dir1)
        repo2 = Repository(dir2)

        repo1.set_current_state("team-a", "main")

        team2, _ = repo2.get_current_state()
        assert team2 is None  # repo2 should not see repo1's state

    def test_find_repo_navigates_hierarchy(self, temp_dir, monkeypatch):
        """Test that find_repo correctly navigates directory hierarchy."""
        repo_dir = temp_dir / "my-repo"
        subdir = repo_dir / "dir1" / "dir2" / "dir3"
        subdir.mkdir(parents=True)

        repo = Repository(repo_dir)
        found_from_deep = Repository.find_repo(subdir)

        assert found_from_deep is not None
        assert found_from_deep.work_dir == repo_dir
