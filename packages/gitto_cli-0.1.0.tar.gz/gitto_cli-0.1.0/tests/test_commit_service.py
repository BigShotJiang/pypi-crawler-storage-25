"""
Test suite for CommitService.
Covers commit creation, amending, and history retrieval.
"""

from gitto.config.constants import DEFAULT_VARIANT


class TestCommitCreation:
    """Test commit creation (update_team) functionality."""

    def test_update_team_valid_url(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        test_message,
    ):
        """Test creating a commit from a valid PokePaste URL."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg, commit_hash = commit_service.update_team(
            valid_pokepaste_url_1, test_message
        )
        assert success is True
        assert commit_hash is not None
        assert len(commit_hash) > 0
        assert test_team_name in msg

    def test_update_team_no_active_team(
        self, commit_service, valid_pokepaste_url_1, test_message
    ):
        """Test updating when no team is active."""
        success, msg, commit_hash = commit_service.update_team(
            valid_pokepaste_url_1, test_message
        )
        assert success is False
        assert "No active team" in msg
        assert commit_hash is None

    def test_update_team_invalid_url(
        self, team_service, commit_service, test_team_name, test_message
    ):
        """Test updating with an invalid URL."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg, commit_hash = commit_service.update_team(
            "https://example.com", test_message
        )
        assert success is False
        assert "Invalid PokePaste URL" in msg or "Failed to fetch" in msg
        assert commit_hash is None

    def test_update_team_invalid_urls(
        self,
        team_service,
        commit_service,
        test_team_name,
        test_message,
        invalid_pokepaste_urls,
    ):
        """Test updating with various invalid URLs."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        for invalid_url in invalid_pokepaste_urls:
            success, _, _ = commit_service.update_team(invalid_url, test_message)
            assert success is False, f"URL '{invalid_url}' should have failed"

    def test_update_team_custom_author(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        test_message,
        test_author,
    ):
        """Test creating a commit with a custom author."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, _, commit_hash = commit_service.update_team(
            valid_pokepaste_url_1, test_message, author=test_author
        )
        assert success is True
        assert commit_hash is not None

    def test_update_team_multiple_commits(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        valid_pokepaste_url_2,
    ):
        """Test creating multiple commits in a variant."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success1, _, hash1 = commit_service.update_team(
            valid_pokepaste_url_1, "First commit"
        )
        success2, _, hash2 = commit_service.update_team(
            valid_pokepaste_url_2, "Second commit"
        )

        assert success1 is True
        assert success2 is True
        assert hash1 != hash2

    def test_update_team_creates_object_references(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        test_message,
    ):
        """Test that update creates blob, tree, and commit objects."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, _, commit_hash = commit_service.update_team(
            valid_pokepaste_url_1, test_message
        )
        assert success is True

        # Verify commit object exists
        commit_obj = commit_service.repo.objects.retrieve(commit_hash)
        assert commit_obj is not None


class TestCommitAmending:
    """Test commit amending functionality."""

    def test_amend_team_valid_url(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        valid_pokepaste_url_2,
        test_message,
    ):
        """Test amending the last commit."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        # Create initial commit
        success, _, hash1 = commit_service.update_team(valid_pokepaste_url_1, "Initial")
        assert success is True

        # Amend the commit
        success, _, hash2 = commit_service.amend_team(valid_pokepaste_url_2, "Amended")
        assert success is True
        assert hash2 is not None
        assert hash1 != hash2

    def test_amend_team_no_active_team(
        self, commit_service, valid_pokepaste_url_1, test_message
    ):
        """Test amending when no team is active."""
        success, msg, _ = commit_service.amend_team(valid_pokepaste_url_1, test_message)
        assert success is False
        assert "No active team" in msg

    def test_amend_team_no_commits(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        test_message,
    ):
        """Test amending when no commits exist."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg, _ = commit_service.amend_team(valid_pokepaste_url_1, test_message)
        assert success is False
        assert "No commits to amend" in msg

    def test_amend_team_invalid_url(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        test_message,
    ):
        """Test amending with an invalid URL."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        # Create initial commit
        commit_service.update_team(valid_pokepaste_url_1, "Initial")

        # Try to amend with invalid URL
        success, _, _ = commit_service.amend_team("https://example.com", test_message)
        assert success is False


class TestCommitHistory:
    """Test commit history retrieval functionality."""

    def test_get_commit_history_empty(
        self, team_service, commit_service, test_team_name
    ):
        """Test getting history when no commits exist."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        history = commit_service.get_commit_history(test_team_name, DEFAULT_VARIANT)
        assert history == []

    def test_get_commit_history_single_commit(
        self, team_service, commit_service, test_team_name, valid_pokepaste_url_1
    ):
        """Test getting history with a single commit."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, _, commit_hash = commit_service.update_team(
            valid_pokepaste_url_1, "First commit"
        )
        assert success is True

        history = commit_service.get_commit_history(test_team_name, DEFAULT_VARIANT)
        assert len(history) == 1
        assert history[0][0] == commit_hash  # Check hash from tuple (hash, commit)

    def test_get_commit_history_multiple_commits(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        valid_pokepaste_url_2,
    ):
        """Test getting history with multiple commits."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        _, _, hash1 = commit_service.update_team(valid_pokepaste_url_1, "First")
        _, _, hash2 = commit_service.update_team(valid_pokepaste_url_2, "Second")

        history = commit_service.get_commit_history(test_team_name, DEFAULT_VARIANT)
        assert len(history) == 2
        # Most recent commit should be first
        assert history[0][0] == hash2  # Check hash from tuple (hash, commit)
        assert history[1][0] == hash1

    def test_get_commit_history_nonexistent_variant(
        self, team_service, commit_service, test_team_name
    ):
        """Test getting history for a nonexistent variant."""
        team_service.create_team(test_team_name)

        history = commit_service.get_commit_history(test_team_name, "nonexistent")
        assert history == []


class TestCommitObjects:
    """Test commit object creation and storage."""

    def test_commit_object_has_tree(
        self, team_service, commit_service, test_team_name, valid_pokepaste_url_1
    ):
        """Test that commit object contains tree reference."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        _, _, commit_hash = commit_service.update_team(valid_pokepaste_url_1, "Test")
        commit_obj = commit_service.repo.objects.retrieve(commit_hash)

        assert commit_obj is not None
        assert hasattr(commit_obj, "tree_hash")
        assert commit_obj.tree_hash is not None

    def test_commit_object_parent_reference(
        self,
        team_service,
        commit_service,
        test_team_name,
        valid_pokepaste_url_1,
        valid_pokepaste_url_2,
    ):
        """Test that second commit references first as parent."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        _, _, hash1 = commit_service.update_team(valid_pokepaste_url_1, "First")
        _, _, hash2 = commit_service.update_team(valid_pokepaste_url_2, "Second")

        commit2_obj = commit_service.repo.objects.retrieve(hash2)
        assert len(commit2_obj.parent_hashes) == 1
        assert commit2_obj.parent_hashes[0] == hash1
