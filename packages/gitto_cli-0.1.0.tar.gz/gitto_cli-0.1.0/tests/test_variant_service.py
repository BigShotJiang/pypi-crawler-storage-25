"""
Test suite for VariantService.
Covers variant creation, deletion, switching, renaming, and listing.
"""

from gitto.config.constants import DEFAULT_VARIANT


class TestVariantCreation:
    """Test variant creation functionality."""

    def test_create_variant_normal(
        self, team_service, variant_service, test_team_name, test_variant_name
    ):
        """Test creating a variant in an active team."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg = variant_service.create_variant(test_variant_name)
        assert success is True
        assert test_variant_name in msg

    def test_create_variant_explicit_team(
        self, team_service, variant_service, test_team_name, test_variant_name
    ):
        """Test creating a variant with explicit team parameter."""
        team_service.create_team(test_team_name)

        success, _ = variant_service.create_variant(
            test_variant_name, team=test_team_name
        )
        assert success is True
        assert variant_service.repo.refs.variant_exists(
            test_team_name, test_variant_name
        )

    def test_create_variant_no_active_team(self, variant_service, test_variant_name):
        """Test creating a variant when no team is active."""
        success, msg = variant_service.create_variant(test_variant_name)
        assert success is False
        assert "No active team" in msg

    def test_create_variant_nonexistent_team(self, variant_service, test_variant_name):
        """Test creating a variant in a team that doesn't exist."""
        success, msg = variant_service.create_variant(
            test_variant_name, team="nonexistent"
        )
        assert success is False
        assert "does not exist" in msg

    def test_create_variant_duplicate(
        self, team_service, variant_service, test_team_name, test_variant_name
    ):
        """Test creating a variant that already exists."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant(test_variant_name)

        success, msg = variant_service.create_variant(test_variant_name)
        assert success is False
        assert "already exists" in msg

    def test_create_variant_invalid_name(
        self, team_service, variant_service, test_team_name
    ):
        """Test creating a variant with invalid name."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg = variant_service.create_variant("invalid variant")
        assert success is False
        assert "Invalid variant name" in msg

    def test_create_multiple_variants(
        self, team_service, variant_service, test_team_name
    ):
        """Test creating multiple variants in a team."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        variant_service.create_variant("variant-a")
        variant_service.create_variant("variant-b")
        variant_service.create_variant("variant-c")

        variants = variant_service.list_variants()
        assert "variant-a" in variants
        assert "variant-b" in variants
        assert "variant-c" in variants


class TestVariantDeletion:
    """Test variant deletion functionality."""

    def test_delete_variant_normal(
        self, team_service, variant_service, test_team_name, test_variant_name
    ):
        """Test deleting a variant."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant(test_variant_name)

        success, msg = variant_service.delete_variant(test_variant_name)
        assert success is True
        assert not variant_service.repo.refs.variant_exists(
            test_team_name, test_variant_name
        )

    def test_delete_default_variant(
        self, team_service, variant_service, test_team_name
    ):
        """Test that default variant cannot be deleted."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg = variant_service.delete_variant(DEFAULT_VARIANT)
        assert success is False
        assert "Cannot delete" in msg
        assert DEFAULT_VARIANT in msg

    def test_delete_nonexistent_variant(
        self, team_service, variant_service, test_team_name
    ):
        """Test deleting a variant that doesn't exist."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg = variant_service.delete_variant("nonexistent")
        assert success is False
        assert "does not exist" in msg

    def test_delete_active_variant(
        self, team_service, variant_service, test_team_name, test_variant_name
    ):
        """Test that active variant cannot be deleted."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant(test_variant_name)
        variant_service.switch_variant(test_variant_name)

        success, msg = variant_service.delete_variant(test_variant_name)
        assert success is False
        assert "Cannot delete active variant" in msg

    def test_delete_variant_no_active_team(self, variant_service, test_variant_name):
        """Test deleting a variant when no team is active."""
        success, msg = variant_service.delete_variant(test_variant_name)
        assert success is False
        assert "No active team" in msg


class TestVariantSwitching:
    """Test variant switching functionality."""

    def test_switch_variant_normal(
        self, team_service, variant_service, test_team_name, test_variant_name
    ):
        """Test switching to an existing variant."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant(test_variant_name)

        success, msg = variant_service.switch_variant(test_variant_name)
        assert success is True
        assert test_variant_name in msg

        _, current_variant = variant_service.repo.get_current_state()
        assert current_variant == test_variant_name

    def test_switch_variant_nonexistent(
        self, team_service, variant_service, test_team_name
    ):
        """Test switching to a variant that doesn't exist."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg = variant_service.switch_variant("nonexistent")
        assert success is False
        assert "does not exist" in msg

    def test_switch_variant_no_active_team(self, variant_service):
        """Test switching variant when no team is active."""
        success, msg = variant_service.switch_variant("main")
        assert success is False
        assert "No active team" in msg

    def test_switch_between_variants(
        self, team_service, variant_service, test_team_name
    ):
        """Test switching between multiple variants."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant("variant-a")
        variant_service.create_variant("variant-b")

        variant_service.switch_variant("variant-a")
        _, variant = variant_service.repo.get_current_state()
        assert variant == "variant-a"

        variant_service.switch_variant("variant-b")
        _, variant = variant_service.repo.get_current_state()
        assert variant == "variant-b"


class TestVariantListing:
    """Test variant listing functionality."""

    def test_list_variants_single_default(
        self, team_service, variant_service, test_team_name
    ):
        """Test listing variants when only default variant exists."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        variants = variant_service.list_variants()
        assert variants == [DEFAULT_VARIANT]

    def test_list_variants_multiple(
        self, team_service, variant_service, test_team_name
    ):
        """Test listing multiple variants."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant("variant-a")
        variant_service.create_variant("variant-b")

        variants = variant_service.list_variants()
        assert DEFAULT_VARIANT in variants
        assert "variant-a" in variants
        assert "variant-b" in variants

    def test_list_variants_sorted(self, team_service, variant_service, test_team_name):
        """Test that listed variants are sorted."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant("zebra")
        variant_service.create_variant("apple")

        variants = variant_service.list_variants()
        assert variants == ["apple", DEFAULT_VARIANT, "zebra"]

    def test_list_variants_no_active_team(self, variant_service):
        """Test listing variants when no team is active."""
        variants = variant_service.list_variants()
        assert variants == []

    def test_list_variants_explicit_team(
        self, team_service, variant_service, test_team_name
    ):
        """Test listing variants of a non-active team."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant("variant-a")

        # Switch to a different team
        team_service.create_team("other-team")
        team_service.switch_team("other-team")

        # List variants of the first team explicitly
        variants = variant_service.list_variants(team=test_team_name)
        assert "variant-a" in variants
        assert DEFAULT_VARIANT in variants


class TestVariantRenaming:
    """Test variant renaming functionality."""

    def test_rename_variant_normal(self, team_service, variant_service, test_team_name):
        """Test renaming a variant."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant("old-name")

        success, msg = variant_service.rename_variant("old-name", "new-name")
        assert success is True
        assert not variant_service.repo.refs.variant_exists(test_team_name, "old-name")
        assert variant_service.repo.refs.variant_exists(test_team_name, "new-name")

    def test_rename_nonexistent_variant(
        self, team_service, variant_service, test_team_name
    ):
        """Test renaming a variant that doesn't exist."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        success, msg = variant_service.rename_variant("nonexistent", "new-name")
        assert success is False
        assert "does not exist" in msg

    def test_rename_to_existing_name(
        self, team_service, variant_service, test_team_name
    ):
        """Test renaming a variant to a name that already exists."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant("variant-a")
        variant_service.create_variant("variant-b")

        success, msg = variant_service.rename_variant("variant-a", "variant-b")
        assert success is False
        assert "already exists" in msg

    def test_rename_active_variant_updates_head(
        self, team_service, variant_service, test_team_name
    ):
        """Test that renaming active variant updates HEAD."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant("old-name")
        variant_service.switch_variant("old-name")

        variant_service.rename_variant("old-name", "new-name")

        _, current_variant = variant_service.repo.get_current_state()
        assert current_variant == "new-name"

    def test_rename_invalid_new_name(
        self, team_service, variant_service, test_team_name
    ):
        """Test renaming a variant to an invalid name."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)
        variant_service.create_variant("old-name")

        success, msg = variant_service.rename_variant("old-name", "invalid name")
        assert success is False
        assert "Invalid variant name" in msg


class TestVariantStatus:
    """Test variant status retrieval."""

    def test_get_variant_status_normal(
        self, team_service, variant_service, test_team_name
    ):
        """Test getting status of a variant."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        status = variant_service.get_variant_status(DEFAULT_VARIANT)
        assert status is not None
        assert status["name"] == DEFAULT_VARIANT

    def test_get_variant_status_nonexistent(
        self, team_service, variant_service, test_team_name
    ):
        """Test getting status of a variant that doesn't exist."""
        team_service.create_team(test_team_name)
        team_service.switch_team(test_team_name)

        status = variant_service.get_variant_status("nonexistent")
        assert status is None
