"""MQTT streaming connector (requires paho-mqtt>=1.6)."""

import json
import queue
from collections.abc import Iterator
from typing import Any


def mqtt_stream(
    topic: str,
    broker: str = "localhost",
    port: int = 1883,
    target_key: str = "target",
    **client_kwargs: Any,
) -> Iterator[tuple[dict[str, Any], Any]]:
    """Stream data from an MQTT topic.

    Requires paho-mqtt to be installed:
        pip install paho-mqtt>=1.6

    Args:
        topic: MQTT topic to subscribe to.
        broker: MQTT broker address.
        port: MQTT broker port.
        target_key: Key in the JSON message containing the target value.
        **client_kwargs: Additional MQTT client configuration.

    Yields:
        Tuples of (features_dict, target_value).
    """
    try:
        import paho.mqtt.client as mqtt
    except ImportError as e:
        raise ImportError(
            "paho-mqtt is required for MQTT streaming. "
            "Install it with: pip install paho-mqtt>=1.6"
        ) from e

    msg_queue: queue.Queue[dict[str, Any]] = queue.Queue()

    def on_message(client: Any, userdata: Any, message: Any) -> None:
        try:
            data = json.loads(message.payload.decode("utf-8"))
            if isinstance(data, dict):
                msg_queue.put(data)
        except (json.JSONDecodeError, UnicodeDecodeError):
            pass

    client = mqtt.Client(**client_kwargs)
    client.on_message = on_message
    client.connect(broker, port)
    client.subscribe(topic)
    client.loop_start()

    try:
        while True:
            try:
                data = msg_queue.get(timeout=1.0)
            except queue.Empty:
                continue

            y = data.pop(target_key, None)
            x: dict[str, Any] = {}
            for k, v in data.items():
                try:
                    x[k] = float(v)
                except (ValueError, TypeError):
                    x[k] = v

            yield x, y
    finally:
        client.loop_stop()
        client.disconnect()
