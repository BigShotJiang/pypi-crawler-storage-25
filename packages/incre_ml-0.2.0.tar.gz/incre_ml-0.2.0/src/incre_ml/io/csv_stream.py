"""CSV-based streaming data connector."""

import csv
from collections.abc import Iterator
from typing import Any


def csv_stream(
    filepath: str,
    target_column: str,
    delimiter: str = ",",
) -> Iterator[tuple[dict[str, Any], Any]]:
    """Stream data from a CSV file one row at a time.

    Args:
        filepath: Path to the CSV file.
        target_column: Name of the target column.
        delimiter: CSV delimiter character.

    Yields:
        Tuples of (features_dict, target_value).
    """
    with open(filepath, newline="") as f:
        reader = csv.DictReader(f, delimiter=delimiter)
        for row in reader:
            y_raw = row.pop(target_column, None)
            x: dict[str, Any] = {}
            for k, v in row.items():
                try:
                    x[k] = float(v)
                except (ValueError, TypeError):
                    x[k] = v

            # Try to convert target to float
            y: Any
            try:
                y = float(y_raw) if y_raw is not None else None
            except (ValueError, TypeError):
                y = y_raw

            yield x, y
