import base64
import pickle
from typing import Any


def to_dict(model: Any) -> dict[str, Any]:
    """Serialize a incre-ml model to a versioned dictionary.

    Args:
        model: Any incre-ml model, transformer, or pipeline.

    Returns:
        Dictionary containing serialized state and metadata.
    """
    state_bytes = pickle.dumps(model)
    state_b64 = base64.b64encode(state_bytes).decode("utf-8")

    return {
        "library": "incre-ml",
        "version": "0.1.0",
        "class": model.__class__.__name__,
        "state": state_b64,
    }


def from_dict(data: dict[str, Any]) -> Any:
    """Reconstruct a incre-ml model from a serialized dictionary.

    Args:
        data: Serialized dictionary from to_dict().

    Returns:
        The reconstructed model object.
    """
    if not isinstance(data, dict):
        raise TypeError("data must be a dictionary")
    if data.get("library") != "incre-ml":
        raise ValueError("Invalid serialization format: Not a incre-ml object.")
    if "state" not in data:
        raise ValueError("Invalid serialization format: missing 'state'")

    state_b64 = data["state"]
    try:
        state_bytes = base64.b64decode(state_b64)
    except Exception as exc:
        raise ValueError("Invalid serialization format: bad base64 state") from exc
    return pickle.loads(state_bytes)
