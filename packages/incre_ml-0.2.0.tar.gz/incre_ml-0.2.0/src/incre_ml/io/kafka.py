"""Kafka streaming connector (requires confluent-kafka>=2.0)."""

import json
from collections.abc import Iterator
from typing import Any


def kafka_stream(
    topic: str,
    bootstrap_servers: str = "localhost:9092",
    group_id: str = "incre-ml",
    target_key: str = "target",
    **consumer_kwargs: Any,
) -> Iterator[tuple[dict[str, Any], Any]]:
    """Stream data from a Kafka topic.

    Requires confluent-kafka to be installed:
        pip install confluent-kafka>=2.0

    Args:
        topic: Kafka topic to consume from.
        bootstrap_servers: Kafka broker addresses.
        group_id: Consumer group ID.
        target_key: Key in the JSON message containing the target value.
        **consumer_kwargs: Additional Kafka consumer configuration.

    Yields:
        Tuples of (features_dict, target_value).
    """
    try:
        from confluent_kafka import Consumer
    except ImportError as e:
        raise ImportError(
            "confluent-kafka is required for Kafka streaming. "
            "Install it with: pip install confluent-kafka>=2.0"
        ) from e

    config: dict[str, Any] = {
        "bootstrap.servers": bootstrap_servers,
        "group.id": group_id,
        "auto.offset.reset": "earliest",
        **consumer_kwargs,
    }

    consumer = Consumer(config)
    consumer.subscribe([topic])

    try:
        while True:
            msg = consumer.poll(timeout=1.0)
            if msg is None or msg.error():
                continue

            result = _parse_message(msg, target_key)
            if result is not None:
                yield result
    finally:
        consumer.close()


def _parse_message(msg: Any, target_key: str) -> tuple[dict[str, Any], Any] | None:
    """Parse a Kafka message into (features, target) or None."""
    try:
        data = json.loads(msg.value().decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None

    if not isinstance(data, dict):
        return None

    y = data.pop(target_key, None)
    x: dict[str, Any] = {}
    for k, v in data.items():
        try:
            x[k] = float(v)
        except (ValueError, TypeError):
            x[k] = v

    return x, y
