import math
from numbers import Real
from typing import Any

from ..base.classifier import Classifier
from ..stats.running import RunningStatistics


class NaiveBayes(Classifier):
    """Gaussian Naive Bayes for online classification."""

    def __init__(self) -> None:
        self.class_counts: dict[str | int, int] = {}
        self.feature_stats: dict[str | int, dict[str, RunningStatistics]] = {}
        self.n_samples = 0

    def _get_gaussian_pdf(self, x: float, mean: float, std_dev: float) -> float:
        # Avoid division by zero and very small values
        std_dev = max(std_dev, 1e-4)
        exponent = math.exp(-((x - mean) ** 2 / (2 * std_dev**2)))
        return (1 / (math.sqrt(2 * math.pi) * std_dev)) * exponent

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        if not self.class_counts or self.n_samples == 0:
            return {}

        log_probas = {}
        for label, count in self.class_counts.items():
            # Initial log probability based on class prior
            log_p = math.log(count / self.n_samples)

            # Incorporate evidence from each feature
            for feat, val in x.items():
                if not (isinstance(val, Real) and math.isfinite(float(val))):
                    continue
                fval = float(val)
                if label in self.feature_stats and feat in self.feature_stats[label]:
                    stats = self.feature_stats[label][feat]
                    # Only use features that have seen at least 2 samples (for variance)
                    min_samples = 2
                    if stats.count >= min_samples:
                        # Use a small floor for std_dev to avoid math domain errors
                        std = max(stats.std_dev, 1e-4)
                        pdf = self._get_gaussian_pdf(fval, stats.mean, std)
                        log_p += math.log(max(pdf, 1e-10))

            log_probas[label] = log_p

        # To avoid overflow, subtract max log_p
        max_log = max(log_probas.values())
        probas = {label: math.exp(lp - max_log) for label, lp in log_probas.items()}
        total_proba = sum(probas.values())

        return {k: v / total_proba for k, v in probas.items()}

    def predict_one(self, x: dict[str, Any]) -> str | int:
        probas = self.predict_proba_one(x)
        if not probas:
            return ""
        return max(probas, key=lambda k: float(probas[k]))

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        label = self.predict_one(x)
        if not label or label not in self.feature_stats:
            return {}

        expl = {}
        for feat, val in x.items():
            if not (isinstance(val, Real) and math.isfinite(float(val))):
                continue
            fval = float(val)
            if feat in self.feature_stats[label]:
                stats = self.feature_stats[label][feat]
                min_samples = 2
                if stats.count >= min_samples:
                    std = max(stats.std_dev, 1e-4)
                    pdf = self._get_gaussian_pdf(fval, stats.mean, std)
                    expl[feat] = float(math.log(max(pdf, 1e-10)))
        return expl

    def learn_one(self, x: dict[str, Any], y: str | int) -> "NaiveBayes":
        self.n_samples += 1
        self.class_counts[y] = self.class_counts.get(y, 0) + 1

        if y not in self.feature_stats:
            self.feature_stats[y] = {}

        for feat, val in x.items():
            if not (isinstance(val, Real) and math.isfinite(float(val))):
                continue
            if feat not in self.feature_stats[y]:
                self.feature_stats[y][feat] = RunningStatistics()
            self.feature_stats[y][feat].update(float(val))

        return self

    def clear(self) -> None:
        self.class_counts = {}
        self.feature_stats = {}
        self.n_samples = 0
