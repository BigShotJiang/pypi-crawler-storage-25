import math
from numbers import Real
from typing import Any

from ..base.classifier import Classifier


class SGDClassifier(Classifier):
    """Linear classifier using Stochastic Gradient Descent.

    Supports various loss functions (log-loss, hinge).
    """

    def __init__(
        self,
        learning_rate: float = 0.01,
        loss: str = "log",
        intercept: bool = True,
    ) -> None:
        if learning_rate <= 0.0:
            raise ValueError("learning_rate must be > 0")
        if loss not in {"log", "hinge"}:
            raise ValueError("loss must be one of {'log', 'hinge'}")
        self.learning_rate = learning_rate
        self.loss = loss
        self.intercept = intercept
        self.weights: dict[str, float] = {}
        self.intercept_weight = 0.0
        self.classes: set[str | int] = set()

    def _sigmoid(self, z: float) -> float:
        return 1.0 / (1.0 + math.exp(-max(min(z, 500), -500)))

    def _binary_target(self, y: str | int) -> float:
        if y in (1, True, "1"):
            return 1.0
        if y in (0, False, "0"):
            return 0.0
        raise ValueError("SGDClassifier supports only binary targets in {0, 1}.")

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        z = self.intercept_weight if self.intercept else 0.0
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                z += self.weights.get(key, 0.0) * float(value)

        if self.loss == "log":
            p = self._sigmoid(z)
            return {0: 1.0 - p, 1: p}
        else:
            # Hinge loss doesn't provide natural probabilities
            return {0: 0.5, 1: 0.5}

    def predict_one(self, x: dict[str, Any]) -> str | int:
        z = self.intercept_weight if self.intercept else 0.0
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                z += self.weights.get(key, 0.0) * float(value)
        return 1 if z > 0 else 0

    def learn_one(self, x: dict[str, Any], y: str | int) -> "SGDClassifier":
        target = self._binary_target(y)
        z = self.intercept_weight if self.intercept else 0.0
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                z += self.weights.get(key, 0.0) * float(value)

        if self.loss == "log":
            p = self._sigmoid(z)
            error = target - p
        elif self.loss == "hinge":
            # Hinge loss target is usually -1, 1
            t = 1.0 if target == 1 else -1.0
            error = t if t * z < 1 else 0.0
        else:
            error = 0.0

        # Update
        for key, value in x.items():
            if not (isinstance(value, Real) and math.isfinite(float(value))):
                continue
            fval = float(value)
            if key not in self.weights:
                self.weights[key] = 0.0
            self.weights[key] += self.learning_rate * error * fval

        if self.intercept:
            self.intercept_weight += self.learning_rate * error

        return self

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = {"intercept": self.intercept_weight}
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                expl[key] = self.weights.get(key, 0.0) * float(value)
        return expl

    def clear(self) -> None:
        self.weights = {}
        self.intercept_weight = 0.0
        self.classes = set()


class PassiveAggressiveClassifier(Classifier):
    """Passive-Aggressive classifier for binary classification."""

    def __init__(self, c_param: float = 1.0, intercept: bool = True) -> None:
        if c_param <= 0.0:
            raise ValueError("c_param must be > 0")
        self.c_param = c_param
        self.intercept = intercept
        self.weights: dict[str, float] = {}
        self.intercept_weight = 0.0

    def _binary_target(self, y: str | int) -> float:
        if y in (1, True, "1"):
            return 1.0
        if y in (0, False, "0"):
            return -1.0
        raise ValueError(
            "PassiveAggressiveClassifier supports only binary targets in {0, 1}."
        )

    def predict_one(self, x: dict[str, Any]) -> str | int:
        z = self.intercept_weight if self.intercept else 0.0
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                z += self.weights.get(key, 0.0) * float(value)
        return 1 if z > 0 else 0

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        return {0: 0.5, 1: 0.5}

    def learn_one(
        self, x: dict[str, Any], y: str | int
    ) -> "PassiveAggressiveClassifier":
        target = self._binary_target(y)
        z = self.intercept_weight if self.intercept else 0.0
        numeric_x: dict[str, float] = {}
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                fval = float(value)
                numeric_x[key] = fval
                z += self.weights.get(key, 0.0) * fval

        loss = max(0.0, 1.0 - target * z)
        if loss == 0:
            return self

        squared_norm = sum(v**2 for v in numeric_x.values())
        if self.intercept:
            squared_norm += 1.0

        if squared_norm == 0:
            return self

        tau = min(self.c_param, loss / squared_norm)
        step = tau * target

        for key, value in numeric_x.items():
            if key not in self.weights:
                self.weights[key] = 0.0
            self.weights[key] += step * value

        if self.intercept:
            self.intercept_weight += step

        return self

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = {"intercept": self.intercept_weight}
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                expl[key] = self.weights.get(key, 0.0) * float(value)
        return expl

    def clear(self) -> None:
        self.weights = {}
        self.intercept_weight = 0.0


class AbstainingClassifier(Classifier):
    """Wraps a classifier and abstains if confidence is low."""

    def __init__(self, model: Classifier, threshold: float = 0.6) -> None:
        if not (0.0 <= threshold <= 1.0):
            raise ValueError("threshold must be in [0, 1]")
        self.model = model
        self.threshold = threshold

    def predict_one(self, x: dict[str, Any]) -> str | int:
        probas = self.model.predict_proba_one(x)
        if not probas:
            return "ABSTAIN"

        best_class = max(probas, key=lambda k: float(probas[k]))
        if probas[best_class] < self.threshold:
            return "ABSTAIN"

        return best_class

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        return self.model.predict_proba_one(x)

    def learn_one(self, x: dict[str, Any], y: str | int) -> "AbstainingClassifier":
        self.model.learn_one(x, y)
        return self

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return self.model.explain_one(x)

    def clear(self) -> None:
        self.model.clear()
