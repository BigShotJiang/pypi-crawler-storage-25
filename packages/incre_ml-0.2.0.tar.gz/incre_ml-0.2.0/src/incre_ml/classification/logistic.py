import math
from numbers import Real
from typing import Any

from ..base.classifier import Classifier
from ..base.federated import FederatedModel


class LogisticRegression(Classifier, FederatedModel):
    """Logistic Regression using SGD for online binary classification."""

    def __init__(self, learning_rate: float = 0.01, intercept: bool = True) -> None:
        if learning_rate <= 0.0:
            raise ValueError("learning_rate must be > 0")
        self.learning_rate = learning_rate
        self.intercept = intercept

        self.weights: dict[str, float] = {}
        self.intercept_weight = 0.0
        self.classes: set[str | int] = set()

    def _sigmoid(self, z: float) -> float:
        return 1.0 / (1.0 + math.exp(-max(min(z, 500), -500)))

    def _binary_target(self, y: str | int) -> float:
        if y in (1, True, "1"):
            return 1.0
        if y in (0, False, "0"):
            return 0.0
        raise ValueError("LogisticRegression supports only binary targets in {0, 1}.")

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        z = self.intercept_weight if self.intercept else 0.0
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                z += self.weights.get(key, 0.0) * float(value)

        p = self._sigmoid(z)
        # Assuming binary classification (0 or 1)
        return {0: 1.0 - p, 1: p}

    def predict_one(self, x: dict[str, Any]) -> str | int:
        probas = self.predict_proba_one(x)
        # Type safe max key
        if not probas:
            return 0
        return max(probas, key=lambda k: float(probas[k]))

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = {}
        if self.intercept:
            expl["intercept"] = self.intercept_weight
        for key, value in x.items():
            if isinstance(value, Real) and math.isfinite(float(value)):
                expl[key] = self.weights.get(key, 0.0) * float(value)
        return expl

    def learn_one(self, x: dict[str, Any], y: str | int) -> "LogisticRegression":
        self.classes.add(y)
        target = self._binary_target(y)

        probas = self.predict_proba_one(x)
        p = probas.get(1, 0.5)
        error = target - p

        # Update weights
        for key, value in x.items():
            if not (isinstance(value, Real) and math.isfinite(float(value))):
                continue
            fval = float(value)
            if key not in self.weights:
                self.weights[key] = 0.0
            self.weights[key] += self.learning_rate * error * fval

        if self.intercept:
            self.intercept_weight += self.learning_rate * error

        return self

    def clear(self) -> None:
        self.weights = {}
        self.intercept_weight = 0.0
        self.classes = set()

    def get_weights(self) -> dict[str, Any]:
        return {
            "weights": self.weights.copy(),
            "intercept_weight": self.intercept_weight,
            "classes": self.classes.copy(),
        }

    def set_weights(self, weights: dict[str, Any]) -> None:
        self.weights = weights["weights"].copy()
        self.intercept_weight = weights["intercept_weight"]
        self.classes = weights["classes"].copy()
