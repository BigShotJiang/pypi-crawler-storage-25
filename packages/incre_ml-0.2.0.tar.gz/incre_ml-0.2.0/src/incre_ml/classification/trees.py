from typing import Any

import numpy as np

from ..base.classifier import Classifier
from .hoeffding import HoeffdingTreeClassifier


class AdaptiveRandomForestClassifier(Classifier):
    """Adaptive Random Forest (ARF) for online classification.

    Uses an ensemble of Hoeffding Trees with online bagging.
    """

    def __init__(
        self, n_models: int = 10, delta: float = 0.01, grace_period: int = 50
    ) -> None:
        if n_models <= 0:
            raise ValueError("n_models must be > 0")
        self.n_models = int(n_models)
        self.models = [
            HoeffdingTreeClassifier(delta=delta, grace_period=grace_period)
            for _ in range(self.n_models)
        ]

    def learn_one(
        self, x: dict[str, Any], y: str | int
    ) -> "AdaptiveRandomForestClassifier":
        for model in self.models:
            # Online Bagging (Oza Bagging)
            k = np.random.poisson(1)
            for _ in range(k):
                model.learn_one(x, y)
        return self

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        if not self.models:
            return {}

        all_probas: dict[str | int, list[float]] = {}
        for model in self.models:
            probas = model.predict_proba_one(x)
            for label, p in probas.items():
                if label not in all_probas:
                    all_probas[label] = []
                all_probas[label].append(p)

        return {label: float(np.mean(ps)) for label, ps in all_probas.items()}

    def predict_one(self, x: dict[str, Any]) -> str | int:
        probas = self.predict_proba_one(x)
        if not probas:
            return ""
        return max(probas, key=lambda k: float(probas[k]))

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        # Average feature importance across trees
        all_expls: dict[str, list[float]] = {}
        for model in self.models:
            expl = model.explain_one(x)
            for feat, val in expl.items():
                if feat not in all_expls:
                    all_expls[feat] = []
                all_expls[feat].append(val)

        return {feat: float(np.mean(vals)) for feat, vals in all_expls.items()}

    def clear(self) -> None:
        for model in self.models:
            model.clear()
