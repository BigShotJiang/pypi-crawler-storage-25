import math
from numbers import Real
from typing import Any

from ..base.classifier import Classifier


class HoeffdingNode:
    """A node in the Hoeffding Tree for classification."""

    def __init__(self, max_bins: int = 64) -> None:
        self.count = 0
        self.class_counts: dict[str | int, int] = {}
        self.max_bins = max_bins

        # Split info
        self.is_leaf = True
        self.split_feature: str | None = None
        self.split_value: float | None = None
        self.children: dict[bool, HoeffdingNode] = {}

        # Stats for entropy/Gini calculation
        # feature -> value -> class -> count
        self.feature_stats: dict[str, dict[float, dict[str | int, int]]] = {}

    def update_stats(self, x: dict[str, Any], y: str | int) -> None:
        self.count += 1
        self.class_counts[y] = self.class_counts.get(y, 0) + 1

        for feat, val in x.items():
            if not isinstance(val, Real):
                continue
            fval = float(val)
            if not math.isfinite(fval):
                continue
            if feat not in self.feature_stats:
                self.feature_stats[feat] = {}
            if fval not in self.feature_stats[feat]:
                self.feature_stats[feat][fval] = {}

            stats = self.feature_stats[feat][fval]
            stats[y] = stats.get(y, 0) + 1

            # Merge closest bins if exceeding max_bins
            if len(self.feature_stats[feat]) > self.max_bins:
                self._merge_closest_bins(feat)

    def _merge_closest_bins(self, feat: str) -> None:
        """Merge the two closest bins for a feature to bound memory."""
        bins = sorted(self.feature_stats[feat].keys())
        if len(bins) < 2:
            return

        # Find the two closest bins
        min_gap = float("inf")
        merge_idx = 0
        for i in range(len(bins) - 1):
            gap = bins[i + 1] - bins[i]
            if gap < min_gap:
                min_gap = gap
                merge_idx = i

        # Merge bins[merge_idx+1] into bins[merge_idx]
        b1, b2 = bins[merge_idx], bins[merge_idx + 1]
        merged = self.feature_stats[feat][b1]
        for label, count in self.feature_stats[feat][b2].items():
            merged[label] = merged.get(label, 0) + count
        del self.feature_stats[feat][b2]

    def get_gini(self, counts: dict[str | int, int], total: int) -> float:
        if total == 0:
            return 0.0
        sum_sq = sum((count / total) ** 2 for count in counts.values())
        return 1.0 - sum_sq

    def find_best_split(self) -> tuple[str | None, float | None, float]:
        """Finds split that yields best Gini impurity reduction."""
        best_gini_red = -1.0
        best_feat = None
        best_val = None

        current_gini = self.get_gini(self.class_counts, self.count)

        for feat, vals in self.feature_stats.items():
            for split_val in vals.keys():
                left_counts: dict[str | int, int] = {}
                left_total = 0
                for v, c_counts in vals.items():
                    if v <= split_val:
                        for label, c in c_counts.items():
                            left_counts[label] = left_counts.get(label, 0) + c
                            left_total += c

                right_total = self.count - left_total
                right_counts = {
                    label: self.class_counts[label] - left_counts.get(label, 0)
                    for label in self.class_counts
                }

                if left_total == 0 or right_total == 0:
                    continue

                gini_red = current_gini - (
                    (left_total / self.count) * self.get_gini(left_counts, left_total)
                    + (right_total / self.count)
                    * self.get_gini(right_counts, right_total)
                )

                if gini_red > best_gini_red:
                    best_gini_red = gini_red
                    best_feat = feat
                    best_val = split_val

        return best_feat, best_val, best_gini_red


class HoeffdingTreeClassifier(Classifier):
    """Hoeffding Tree Classifier for online multi-class classification."""

    def __init__(
        self,
        delta: float = 0.01,
        grace_period: int = 50,
        tau: float = 0.05,
        max_bins: int = 64,
    ) -> None:
        if not (0.0 < delta < 1.0):
            raise ValueError("delta must be in (0, 1)")
        if grace_period <= 0:
            raise ValueError("grace_period must be > 0")
        if tau < 0.0:
            raise ValueError("tau must be >= 0")
        self.max_bins = max_bins
        self.root = HoeffdingNode(max_bins=max_bins)
        self.delta = float(delta)
        self.grace_period = int(grace_period)
        self.tau = float(tau)

    def _get_leaf(self, x: dict[str, Any]) -> HoeffdingNode:
        node = self.root
        while not node.is_leaf:
            raw_val = x.get(str(node.split_feature), 0.0)
            if isinstance(raw_val, Real):
                val = float(raw_val)
            else:
                val = 0.0
            node = node.children[val <= float(node.split_value or 0.0)]
        return node

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        leaf = self._get_leaf(x)
        if leaf.count == 0:
            return {}
        return {label: count / leaf.count for label, count in leaf.class_counts.items()}

    def predict_one(self, x: dict[str, Any]) -> str | int:
        probas = self.predict_proba_one(x)
        if not probas:
            return ""
        return max(probas, key=lambda k: float(probas[k]))

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        probas = self.predict_proba_one(x)
        return {str(k): float(v) for k, v in probas.items()}

    def learn_one(self, x: dict[str, Any], y: str | int) -> "HoeffdingTreeClassifier":
        leaf = self._get_leaf(x)
        leaf.update_stats(x, y)

        if leaf.count % self.grace_period == 0:
            self._attempt_split(leaf)

        return self

    def _attempt_split(self, node: HoeffdingNode) -> None:
        best_feat, best_val, best_gini_red = node.find_best_split()
        if best_feat is None:
            return

        range_val = 1.0  # Max possible Gini reduction
        epsilon = math.sqrt(
            (range_val**2 * math.log(1 / self.delta)) / (2 * node.count)
        )

        if best_gini_red > epsilon or epsilon < self.tau:
            node.is_leaf = False
            node.split_feature = best_feat
            node.split_value = best_val
            node.children = {
                True: HoeffdingNode(max_bins=self.max_bins),
                False: HoeffdingNode(max_bins=self.max_bins),
            }
            node.feature_stats = {}

    def clear(self) -> None:
        self.root = HoeffdingNode(max_bins=self.max_bins)
