import heapq
import math
from collections import deque
from typing import Any

from ..base.classifier import Classifier


class WindowedKNN(Classifier):
    """Approximate k-NN classifier using a sliding window of recent examples.

    Stores recent examples in a deque and uses distance-weighted voting
    for predictions.
    """

    def __init__(self, k: int = 5, max_size: int = 1000) -> None:
        if k <= 0:
            raise ValueError("k must be > 0")
        if max_size <= 0:
            raise ValueError("max_size must be > 0")
        self.k = k
        self.max_size = max_size
        self._window: deque[tuple[dict[str, Any], str | int]] = deque(maxlen=max_size)

    def _distance(self, a: dict[str, Any], b: dict[str, Any]) -> float:
        """Squared Euclidean distance between two feature dicts."""
        keys = set(a.keys()) | set(b.keys())
        dist = 0.0
        for key in keys:
            va = (
                float(a.get(key, 0.0))
                if isinstance(a.get(key, 0.0), int | float)
                else 0.0
            )
            vb = (
                float(b.get(key, 0.0))
                if isinstance(b.get(key, 0.0), int | float)
                else 0.0
            )
            dist += (va - vb) ** 2
        return dist

    def _k_nearest(
        self, x: dict[str, Any]
    ) -> list[tuple[float, dict[str, Any], str | int]]:
        """Find k nearest neighbors using heapq for O(n log k)."""
        if not self._window:
            return []

        # Use negative distance for max-heap behavior via heapq (min-heap)
        neighbors: list[tuple[float, int, dict[str, Any], str | int]] = []
        for idx, (xi, yi) in enumerate(self._window):
            d = self._distance(x, xi)
            if len(neighbors) < self.k:
                heapq.heappush(neighbors, (-d, idx, xi, yi))
            elif d < -neighbors[0][0]:
                heapq.heapreplace(neighbors, (-d, idx, xi, yi))

        return [(-neg_d, xi, yi) for neg_d, _, xi, yi in neighbors]

    def learn_one(self, x: dict[str, Any], y: str | int) -> "WindowedKNN":
        self._window.append((x.copy(), y))
        return self

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        neighbors = self._k_nearest(x)
        if not neighbors:
            return {}

        # Distance-weighted voting
        weighted_votes: dict[str | int, float] = {}
        total_weight = 0.0

        for dist, _xi, yi in neighbors:
            # Inverse distance weighting (add epsilon to avoid div by zero)
            w = 1.0 / (math.sqrt(dist) + 1e-10)
            weighted_votes[yi] = weighted_votes.get(yi, 0.0) + w
            total_weight += w

        if total_weight > 0:
            return {k: v / total_weight for k, v in weighted_votes.items()}
        return weighted_votes

    def predict_one(self, x: dict[str, Any]) -> str | int:
        probas = self.predict_proba_one(x)
        if not probas:
            return ""
        return max(probas, key=lambda k: probas[k])

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        neighbors = self._k_nearest(x)
        if not neighbors:
            return {}

        # Feature contribution based on distance-weighted neighbor features
        result: dict[str, float] = {}
        total_weight = 0.0
        for dist, xi, _yi in neighbors:
            w = 1.0 / (math.sqrt(dist) + 1e-10)
            total_weight += w
            for feat in set(x.keys()) | set(xi.keys()):
                val_x = (
                    float(x.get(feat, 0.0))
                    if isinstance(x.get(feat, 0.0), int | float)
                    else 0.0
                )
                val_xi = (
                    float(xi.get(feat, 0.0))
                    if isinstance(xi.get(feat, 0.0), int | float)
                    else 0.0
                )
                contribution = w * abs(val_x - val_xi)
                result[feat] = result.get(feat, 0.0) + contribution

        if total_weight > 0:
            result = {k: v / total_weight for k, v in result.items()}
        return result

    def clear(self) -> None:
        self._window = deque(maxlen=self.max_size)
