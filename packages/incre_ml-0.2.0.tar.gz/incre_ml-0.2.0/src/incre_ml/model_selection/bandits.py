import random
from typing import Any

from ..base.regressor import Regressor
from ..metrics.regression import MAE


class BanditModelSelector(Regressor):
    """Selects the best model using an Epsilon-Greedy bandit strategy."""

    def __init__(self, models: dict[str, Regressor], epsilon: float = 0.1) -> None:
        if not models:
            raise ValueError("models must not be empty")
        if not (0.0 <= epsilon <= 1.0):
            raise ValueError("epsilon must be in [0, 1]")
        self.models = models
        self.epsilon = float(epsilon)
        self.metrics = {name: MAE() for name in models.keys()}
        self.best_model_name = list(models.keys())[0]

    def learn_one(self, x: dict[str, Any], y: float) -> "BanditModelSelector":
        for name, model in self.models.items():
            y_pred = model.predict_one(x)
            self.metrics[name].update(y, y_pred)
            model.learn_one(x, y)

        # Update best model
        self.best_model_name = min(
            self.metrics.keys(), key=lambda name: float(self.metrics[name].get())
        )
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        # Exploration vs Exploitation
        if random.random() < self.epsilon:
            name = random.choice(list(self.models.keys()))
        else:
            name = self.best_model_name

        return self.models[name].predict_one(x)

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return self.models[self.best_model_name].explain_one(x)

    def clear(self) -> None:
        for model in self.models.values():
            model.clear()
        for metric in self.metrics.values():
            metric.clear()
