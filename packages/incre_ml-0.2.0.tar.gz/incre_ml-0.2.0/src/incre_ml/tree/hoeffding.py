import bisect
import math
from numbers import Real
from typing import Any

from ..base import Regressor


class _QuantileBucket:
    """Fixed-width histogram bucket for a single feature.

    Maintains a sorted list of at most ``max_bins`` representative split
    candidates.  When the list is full, the two closest values are merged into
    their midpoint (histogram compression).  This gives O(log B) insert and
    O(B) split search — much better than the O(n²) naive approach.

    For each observed value we also track (count, sum_y, sum_y_sq) aggregated
    by bucket, which allows computing variance reduction in O(B) time.
    """

    def __init__(self, max_bins: int = 32) -> None:
        self.max_bins = max_bins
        # Parallel arrays: sorted split candidates and their aggregates
        self._vals: list[float] = []
        self._counts: list[int] = []
        self._sum_y: list[float] = []
        self._sum_y2: list[float] = []
        # Running range for Hoeffding bound computation
        self.min_val = float("inf")
        self.max_val = float("-inf")

    def update(self, val: float, y: float) -> None:
        self.min_val = min(self.min_val, val)
        self.max_val = max(self.max_val, val)

        idx = bisect.bisect_left(self._vals, val)
        if idx < len(self._vals) and self._vals[idx] == val:
            # Exact match — add to existing bucket
            self._counts[idx] += 1
            self._sum_y[idx] += y
            self._sum_y2[idx] += y * y
        else:
            # Insert new bucket
            self._vals.insert(idx, val)
            self._counts.insert(idx, 1)
            self._sum_y.insert(idx, y)
            self._sum_y2.insert(idx, y * y)
            if len(self._vals) > self.max_bins:
                self._compress()

    def _compress(self) -> None:
        """Merge the two closest adjacent buckets to maintain max_bins limit."""
        min_gap = float("inf")
        merge_idx = 0
        for i in range(len(self._vals) - 1):
            gap = self._vals[i + 1] - self._vals[i]
            if gap < min_gap:
                min_gap = gap
                merge_idx = i

        i = merge_idx
        j = i + 1
        total = self._counts[i] + self._counts[j]
        merged_val = (
            self._vals[i] * self._counts[i] + self._vals[j] * self._counts[j]
        ) / total
        self._vals[i] = merged_val
        self._counts[i] = total
        self._sum_y[i] += self._sum_y[j]
        self._sum_y2[i] += self._sum_y2[j]
        del self._vals[j], self._counts[j], self._sum_y[j], self._sum_y2[j]

    def best_split(
        self, total_count: int, total_sy: float, total_sy2: float
    ) -> tuple[float | None, float]:
        """Return the (split_value, variance_reduction) for the best split point.

        Iterates over candidate split points in O(B) time.
        """
        if len(self._vals) < 2:
            return None, -1.0

        current_var = _var(total_count, total_sy, total_sy2)
        best_val: float | None = None
        best_vr = -1.0

        left_c = 0
        left_sy = 0.0
        left_sy2 = 0.0

        for i in range(len(self._vals) - 1):
            left_c += self._counts[i]
            left_sy += self._sum_y[i]
            left_sy2 += self._sum_y2[i]

            right_c = total_count - left_c
            if left_c == 0 or right_c == 0:
                continue

            right_sy = total_sy - left_sy
            right_sy2 = total_sy2 - left_sy2

            vr = current_var - (
                (left_c / total_count) * _var(left_c, left_sy, left_sy2)
                + (right_c / total_count) * _var(right_c, right_sy, right_sy2)
            )
            if vr > best_vr:
                best_vr = vr
                # Split at the midpoint between adjacent buckets
                best_val = (self._vals[i] + self._vals[i + 1]) / 2.0

        return best_val, best_vr

    @property
    def value_range(self) -> float:
        if self.min_val == float("inf"):
            return 1.0
        r = self.max_val - self.min_val
        return r if r > 0.0 else 1.0


def _var(count: int, sy: float, sy2: float) -> float:
    if count <= 1:
        return 0.0
    return max(0.0, (sy2 - (sy * sy / count)) / count)


class HoeffdingNode:
    """A node in the Hoeffding Tree."""

    def __init__(self, max_bins: int = 32) -> None:
        self.count = 0
        self.sum_y = 0.0
        self.sum_y_sq = 0.0

        # Split info
        self.is_leaf = True
        self.split_feature: str | None = None
        self.split_value: float | None = None
        self.children: dict[bool, HoeffdingNode] = {}

        # Histogram per feature
        self._max_bins = max_bins
        self.feature_buckets: dict[str, _QuantileBucket] = {}

    def update_stats(self, x: dict[str, Any], y: float) -> None:
        self.count += 1
        self.sum_y += y
        self.sum_y_sq += y * y

        for feat, val in x.items():
            if not isinstance(val, Real):
                continue
            fval = float(val)
            if not math.isfinite(fval):
                continue
            if feat not in self.feature_buckets:
                self.feature_buckets[feat] = _QuantileBucket(self._max_bins)
            self.feature_buckets[feat].update(fval, y)

    def find_best_split(self) -> tuple[str | None, float | None, float, float]:
        """O(F * B) split search using histogram buckets.

        Returns:
            (best_feature, best_split_value, best_variance_reduction, range_val)
        """
        best_feat = None
        best_val: float | None = None
        best_vr = -1.0
        best_range = 1.0

        for feat, bucket in self.feature_buckets.items():
            split_val, vr = bucket.best_split(self.count, self.sum_y, self.sum_y_sq)
            if split_val is not None and vr > best_vr:
                best_vr = vr
                best_feat = feat
                best_val = split_val
                best_range = bucket.value_range

        return best_feat, best_val, best_vr, best_range


class HoeffdingTreeRegressor(Regressor):
    """Hoeffding Tree Regressor (VFDT-style for online regression).

    Improvements over the naive version:
    - **O(F·B) split search** via fixed-width histogram compression (was O(n²)).
    - **Adaptive Hoeffding bound**: ``range_val`` is derived from the actual
      observed feature range rather than being hardcoded to 1.0.
    - **max_bins** controls histogram resolution vs. memory trade-off.

    Args:
        delta: Confidence parameter for the Hoeffding bound.  Lower = more
            splits (larger trees, better fit); higher = fewer splits (smaller
            trees, faster).
        grace_period: Number of samples between split attempts at a leaf.
        tau: Tie-breaking threshold.  If the Hoeffding bound falls below tau
            and the best split has positive variance reduction, split anyway.
        max_bins: Maximum number of histogram buckets per feature per leaf.
            Higher = more accurate split search; lower = less memory.
    """

    def __init__(
        self,
        delta: float = 0.01,
        grace_period: int = 50,
        tau: float = 0.05,
        max_bins: int = 32,
    ) -> None:
        if not (0.0 < delta < 1.0):
            raise ValueError("delta must be in (0, 1)")
        if grace_period <= 0:
            raise ValueError("grace_period must be > 0")
        if tau < 0.0:
            raise ValueError("tau must be >= 0")
        if max_bins < 2:
            raise ValueError("max_bins must be >= 2")
        self.delta = float(delta)
        self.grace_period = int(grace_period)
        self.tau = float(tau)
        self.max_bins = int(max_bins)
        self.root = HoeffdingNode(self.max_bins)

    def _get_leaf(self, x: dict[str, Any]) -> HoeffdingNode:
        node = self.root
        while not node.is_leaf:
            raw_val = x.get(str(node.split_feature), 0.0)
            val = float(raw_val) if isinstance(raw_val, Real) else 0.0
            node = node.children[val <= float(node.split_value or 0.0)]
        return node

    def predict_one(self, x: dict[str, Any]) -> float:
        leaf = self._get_leaf(x)
        return leaf.sum_y / leaf.count if leaf.count > 0 else 0.0

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        """Return the split path and leaf mean as explanation."""
        node = self.root
        path: dict[str, float] = {}
        depth = 0
        while not node.is_leaf:
            feat = str(node.split_feature)
            raw_val = x.get(feat, 0.0)
            val = float(raw_val) if isinstance(raw_val, Real) else 0.0
            path[f"split_{depth}_{feat}"] = float(node.split_value or 0.0)
            node = node.children[val <= float(node.split_value or 0.0)]
            depth += 1
        leaf_mean = node.sum_y / node.count if node.count > 0 else 0.0
        path["leaf_mean"] = leaf_mean
        return path

    def learn_one(self, x: dict[str, Any], y: float) -> "HoeffdingTreeRegressor":
        leaf = self._get_leaf(x)
        leaf.update_stats(x, y)

        if leaf.count % self.grace_period == 0:
            self._attempt_split(leaf)

        return self

    def _attempt_split(self, node: HoeffdingNode) -> None:
        best_feat, best_val, best_vr, range_val = node.find_best_split()

        if best_feat is None or best_vr <= 0.0:
            return

        # Hoeffding bound using the actual observed range of the split criterion
        epsilon = math.sqrt(
            (range_val**2 * math.log(1.0 / self.delta)) / (2.0 * node.count)
        )

        if best_vr > epsilon or epsilon < self.tau:
            node.is_leaf = False
            node.split_feature = best_feat
            node.split_value = best_val
            node.children = {
                True: HoeffdingNode(self.max_bins),
                False: HoeffdingNode(self.max_bins),
            }
            # Free histogram memory in internal nodes
            node.feature_buckets = {}

    def clear(self) -> None:
        self.root = HoeffdingNode(self.max_bins)
