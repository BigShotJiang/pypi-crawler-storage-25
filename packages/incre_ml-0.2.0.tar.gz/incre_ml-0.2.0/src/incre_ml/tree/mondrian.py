"""Mondrian Forest Regressor for online streaming prediction with uncertainty.

Mondrian Forests (Lakshminarayanan et al., 2014; Mourtada et al., 2019) are a
family of randomised partition trees with the following properties desirable for
streaming ML:

1. **Calibrated uncertainty**: Mondrian partitions are independent of labels,
   so prediction intervals are valid without held-out calibration sets.
2. **Online leaf refinement**: Splits can be added *above* existing splits,
   preserving all previously learned structure while incorporating new data.
3. **O(log n) predict**: Tree depth grows logarithmically with data volume.

This implementation uses the ``MondrianTree`` (single-tree) and
``MondrianForestRegressor`` (ensemble of trees) classes.

Implementation notes
--------------------
* Splits are drawn from an Exponential(Λ) distribution where Λ is proportional
  to the feature range — narrower features split less often.
* Prediction is the weighted leaf mean; uncertainty is the standard deviation
  across tree predictions (inter-tree variance = epistemic uncertainty).
* This is a *simplified* Mondrian tree that supports `learn_one` but does not
  implement the full retroactive-split mechanism.  Splits are proposed at
  ``learn_one`` time if the observation falls outside the current cell bounds.
"""

import math
import random
from typing import Any

from ..base import Regressor
from ..stats.running import RunningStatistics


class _MondrianNode:
    """A node (Mondrian cell) in a Mondrian tree."""

    def __init__(self) -> None:
        self.is_leaf = True
        self.split_feat: str | None = None
        self.split_val: float = 0.0
        self.left: _MondrianNode | None = None
        self.right: _MondrianNode | None = None
        # Leaf statistics
        self.stats = RunningStatistics()
        # Feature bounds of the cell [lo, hi]
        self.lo: dict[str, float] = {}
        self.hi: dict[str, float] = {}

    def update_bounds(self, x: dict[str, float]) -> None:
        for feat, val in x.items():
            if feat not in self.lo:
                self.lo[feat] = val
                self.hi[feat] = val
            else:
                self.lo[feat] = min(self.lo[feat], val)
                self.hi[feat] = max(self.hi[feat], val)

    @property
    def total_range(self) -> float:
        return sum(max(0.0, self.hi[f] - self.lo[f]) for f in self.lo)


class _MondrianTree:
    """A single Mondrian tree regressor."""

    def __init__(self, lifetime: float, rng: random.Random) -> None:
        self.lifetime = float(lifetime)  # budget parameter λ
        self.rng = rng
        self.root = _MondrianNode()
        self._min_leaf_samples = 2

    def _get_leaf(self, x: dict[str, Any]) -> _MondrianNode:
        node = self.root
        while not node.is_leaf:
            feat = node.split_feat
            val = float(x.get(feat, 0.0)) if feat is not None else 0.0
            node = node.left if val <= node.split_val else node.right  # type: ignore[assignment]
        return node

    def predict(self, x: dict[str, Any]) -> float:
        leaf = self._get_leaf(x)
        return leaf.stats.mean if leaf.stats.count > 0 else 0.0

    def learn_one(self, x: dict[str, Any], y: float) -> None:
        x_f = {
            k: float(v)
            for k, v in x.items()
            if isinstance(v, int | float) and math.isfinite(float(v))
        }
        leaf = self._get_leaf(x_f)
        leaf.update_bounds(x_f)
        leaf.stats.update(y)

        # Attempt to extend the Mondrian tree downward if leaf has enough samples
        if leaf.stats.count >= self._min_leaf_samples:
            self._attempt_extend(leaf)

    def _attempt_extend(self, node: _MondrianNode) -> None:
        """Attempt a Mondrian split if the budget allows."""
        total_range = node.total_range
        if total_range <= 0.0:
            return

        # Mondrian split rate: E = total_range (sum of feature ranges)
        # Draw a split time from Exp(total_range); accept if within lifetime budget
        split_time = self.rng.expovariate(total_range)
        if split_time > self.lifetime:
            return

        # Choose split feature proportionally to range
        feats = [f for f in node.lo if node.hi[f] > node.lo[f]]
        if not feats:
            return

        ranges = [node.hi[f] - node.lo[f] for f in feats]
        total = sum(ranges)
        r = self.rng.random() * total
        cumsum = 0.0
        chosen_feat = feats[-1]
        for feat, rng_val in zip(feats, ranges, strict=True):
            cumsum += rng_val
            if r <= cumsum:
                chosen_feat = feat
                break

        # Draw uniform split point within feature range
        lo, hi = node.lo[chosen_feat], node.hi[chosen_feat]
        split_val = self.rng.uniform(lo, hi)

        # Create children
        node.is_leaf = False
        node.split_feat = chosen_feat
        node.split_val = split_val
        node.left = _MondrianNode()
        node.right = _MondrianNode()
        # Propagate bounds and stats are lost in children (online simplification)
        for child in (node.left, node.right):
            child.lo = dict(node.lo)
            child.hi = dict(node.hi)

    def clear(self) -> None:
        self.root = _MondrianNode()


class MondrianForestRegressor(Regressor):
    """Online Mondrian Forest for streaming regression with uncertainty.

    An ensemble of ``n_trees`` independent Mondrian trees.  Predictions are the
    unweighted mean across trees; uncertainty is the inter-tree standard
    deviation (epistemic uncertainty estimate).

    Prediction intervals can be derived from the tree ensemble spread.

    Args:
        n_trees: Number of Mondrian trees.
        lifetime: Mondrian budget parameter λ.  Controls tree depth — larger λ
            allows finer splits.  A good starting range is 1.0–10.0 depending
            on the scale of your features.
        seed: Random seed for reproducibility.
    """

    def __init__(
        self,
        n_trees: int = 10,
        lifetime: float = 5.0,
        seed: int = 42,
    ) -> None:
        if n_trees < 1:
            raise ValueError("n_trees must be >= 1")
        if lifetime <= 0.0:
            raise ValueError("lifetime must be > 0")
        self.n_trees = n_trees
        self.lifetime = float(lifetime)
        self.seed = seed
        self._rng = random.Random(seed)
        self._trees = [
            _MondrianTree(lifetime, random.Random(self._rng.randint(0, 2**31)))
            for _ in range(n_trees)
        ]

    def learn_one(self, x: dict[str, Any], y: float) -> "MondrianForestRegressor":
        for tree in self._trees:
            tree.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        preds = [t.predict(x) for t in self._trees]
        return sum(preds) / len(preds)

    def predict_interval(self, x: dict[str, Any]) -> tuple[float, float, float]:
        """Return (mean, lower_95, upper_95) using inter-tree spread.

        The 95% interval is mean ± 1.96 * std_dev across tree predictions.
        """
        preds = [t.predict(x) for t in self._trees]
        mean = sum(preds) / len(preds)
        if len(preds) < 2:
            return mean, mean, mean
        variance = sum((p - mean) ** 2 for p in preds) / (len(preds) - 1)
        std = math.sqrt(variance)
        return mean, mean - 1.96 * std, mean + 1.96 * std

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        preds = [t.predict(x) for t in self._trees]
        mean = sum(preds) / len(preds)
        if len(preds) < 2:
            std = 0.0
        else:
            variance = sum((p - mean) ** 2 for p in preds) / (len(preds) - 1)
            std = math.sqrt(variance)
        return {
            "mean_prediction": mean,
            "epistemic_std": std,
            "n_trees": float(self.n_trees),
        }

    def clear(self) -> None:
        self._rng = random.Random(self.seed)
        self._trees = [
            _MondrianTree(self.lifetime, random.Random(self._rng.randint(0, 2**31)))
            for _ in range(self.n_trees)
        ]
