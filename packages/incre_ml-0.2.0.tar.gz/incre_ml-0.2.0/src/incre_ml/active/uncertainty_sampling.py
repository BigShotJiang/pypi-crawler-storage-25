"""Active learning via uncertainty sampling."""

from typing import Any

from ..base.classifier import Classifier


class UncertaintySampler:
    """Wraps a classifier and recommends labeling when uncertainty is high.

    Uses prediction entropy to determine when a sample should be
    labeled by an oracle.
    """

    def __init__(
        self,
        model: Classifier,
        threshold: float = 0.5,
    ) -> None:
        if not (0.0 < threshold <= 1.0):
            raise ValueError("threshold must be in (0, 1]")
        self.model = model
        self.threshold = threshold
        self._n_queries = 0
        self._n_total = 0

    def _uncertainty(self, x: dict[str, Any]) -> float:
        """Compute prediction uncertainty as 1 - max_prob."""
        probas = self.model.predict_proba_one(x)
        if not probas:
            return 1.0
        max_prob = max(probas.values())
        return 1.0 - max_prob

    def should_label(self, x: dict[str, Any]) -> bool:
        """Determine if this sample should be labeled by an oracle.

        Returns True if the model's uncertainty exceeds the threshold.
        """
        self._n_total += 1
        uncertainty = self._uncertainty(x)
        if uncertainty >= self.threshold:
            self._n_queries += 1
            return True
        return False

    def learn_one(self, x: dict[str, Any], y: str | int) -> "UncertaintySampler":
        """Update the model with a labeled sample."""
        self.model.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> str | int:
        return self.model.predict_one(x)

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        return self.model.predict_proba_one(x)

    @property
    def query_rate(self) -> float:
        """Fraction of samples that were recommended for labeling."""
        if self._n_total == 0:
            return 0.0
        return self._n_queries / self._n_total

    def clear(self) -> None:
        self.model.clear()
        self._n_queries = 0
        self._n_total = 0
