"""Multi-output regression support."""

from typing import Any

from .regressor import Regressor


class MultiOutputRegressor:
    """Wraps N regressors, one per target, for multi-output regression.

    Each target dimension gets its own independent regressor.
    """

    def __init__(
        self,
        model_factory: type[Regressor],
        **model_kwargs: Any,
    ) -> None:
        self._model_factory = model_factory
        self._model_kwargs = model_kwargs
        self._models: dict[str, Regressor] = {}

    def learn_one(
        self, x: dict[str, Any], y: dict[str, float]
    ) -> "MultiOutputRegressor":
        """Update all target models.

        Args:
            x: Input features.
            y: Target values as {target_name: value}.
        """
        for target_name, target_val in y.items():
            if target_name not in self._models:
                self._models[target_name] = self._model_factory(**self._model_kwargs)
            self._models[target_name].learn_one(x, target_val)
        return self

    def predict_one(self, x: dict[str, Any]) -> dict[str, float]:
        """Predict all targets.

        Returns:
            Dictionary of {target_name: predicted_value}.
        """
        return {name: model.predict_one(x) for name, model in self._models.items()}

    def explain_one(self, x: dict[str, Any]) -> dict[str, dict[str, float]]:
        """Explain predictions for all targets."""
        return {name: model.explain_one(x) for name, model in self._models.items()}

    def clear(self) -> None:
        for model in self._models.values():
            model.clear()
        self._models = {}
