from abc import ABC, abstractmethod
from typing import Any


class Clusterer(ABC):
    """Base class for online clustering models."""

    @abstractmethod
    def learn_one(self, x: dict[str, Any]) -> "Clusterer":
        """Update the model with a single observation."""
        pass

    @abstractmethod
    def predict_one(self, x: dict[str, Any]) -> int:
        """Return the cluster ID for a single observation."""
        pass

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        """Explain the clustering decision. Default returns empty dict."""
        return {}

    @abstractmethod
    def clear(self) -> None:
        """Reset the clusterer state."""
        pass
