from abc import ABC, abstractmethod
from typing import Any


class Regressor(ABC):
    """Base class for online regression models."""

    @abstractmethod
    def learn_one(self, x: dict[str, Any], y: float) -> "Regressor":
        """Update the model with a single observation.

        Args:
            x: Input features as a dictionary.
            y: Target value.

        Returns:
            self
        """
        pass

    @abstractmethod
    def predict_one(self, x: dict[str, Any]) -> float:
        """Predict the target value for a single observation.

        Args:
            x: Input features as a dictionary.

        Returns:
            Predicted target value.
        """
        pass

    @abstractmethod
    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        """Explain the prediction for a single observation.

        Returns:
            Dictionary mapping feature names to their contribution.
        """
        pass

    @abstractmethod
    def clear(self) -> None:
        """Reset the regressor state."""
        pass
