from abc import ABC, abstractmethod
from typing import Any


class Transformer(ABC):
    """Base class for online data transformers."""

    @abstractmethod
    def learn_one(self, x: dict[str, Any], y: Any | None = None) -> "Transformer":
        """Update the transformer's state with a single observation.

        Args:
            x: Input features.
            y: Optional target value (for supervised transformers).

        Returns:
            self
        """
        pass

    @abstractmethod
    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        """Apply the transformation to a single observation.

        Args:
            x: Input features.

        Returns:
            Transformed features.
        """
        pass

    @abstractmethod
    def clear(self) -> None:
        """Reset the transformer state."""
        pass
