from abc import ABC, abstractmethod
from typing import Any

from .regressor import Regressor


class Constraint(ABC):
    """Base class for physical laws and constraints."""

    @abstractmethod
    def violation_one(self, x: dict[str, Any], y_pred: float) -> float:
        """Calculate the magnitude of the physical law violation.

        Returns:
            0.0 if valid, > 0.0 proportional to severity.
        """
        pass

    @abstractmethod
    def project_one(self, x: dict[str, Any], y_pred: float) -> float:
        """Project the prediction back onto the feasible physical manifold.

        Returns:
            The physically-constrained prediction.
        """
        pass

    def explain_one(self, x: dict[str, Any], y_pred: float) -> dict[str, float]:
        """Explain the nature of the violation."""
        return {"violation": self.violation_one(x, y_pred)}


class PhysicsInformedWrapper(Regressor):
    """Wraps any regressor with physical constraints."""

    def __init__(self, model: Regressor, constraint: Constraint) -> None:
        self.model = model
        self.constraint = constraint
        self.last_violation = 0.0

    def learn_one(self, x: dict[str, Any], y: float) -> "PhysicsInformedWrapper":
        self.model.learn_one(x, y)
        # Propagate learning to stateful constraints (e.g., rate limits, monotonicity).
        if hasattr(self.constraint, "learn_one"):
            self.constraint.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        raw_pred = self.model.predict_one(x)
        violation = self.constraint.violation_one(x, raw_pred)
        self.last_violation = violation

        if violation > 0:
            return self.constraint.project_one(x, raw_pred)
        return raw_pred

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = self.model.explain_one(x)
        raw_pred = self.model.predict_one(x)
        expl.update(self.constraint.explain_one(x, raw_pred))
        return expl

    def clear(self) -> None:
        self.model.clear()
        if hasattr(self.constraint, "clear"):
            self.constraint.clear()
        self.last_violation = 0.0
