from abc import abstractmethod
from typing import Any

from .regressor import Regressor


class UncertaintyRegressor(Regressor):
    """Base class for models that provide uncertainty estimates."""

    @abstractmethod
    def predict_with_uncertainty(self, x: dict[str, Any]) -> tuple[float, float]:
        """Predict the target value and its uncertainty (std dev).

        Args:
            x: Input features.

        Returns:
            Tuple of (prediction, uncertainty).
        """
        pass
