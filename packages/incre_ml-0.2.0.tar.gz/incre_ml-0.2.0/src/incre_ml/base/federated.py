from abc import ABC, abstractmethod
from typing import Any


class FederatedModel(ABC):
    """Interface for models that support federated weight aggregation."""

    @abstractmethod
    def get_weights(self) -> dict[str, Any]:
        """Return the model's internal weights/parameters.

        Returns:
            Dictionary of parameter names and values.
        """
        pass

    @abstractmethod
    def set_weights(self, weights: dict[str, Any]) -> None:
        """Set the model's internal weights/parameters.

        Args:
            weights: Dictionary of parameter names and values.
        """
        pass
