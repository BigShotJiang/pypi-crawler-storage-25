from abc import ABC, abstractmethod


class OnlineMetric(ABC):
    """Base class for online performance metrics."""

    @abstractmethod
    def update(self, y_true: float, y_pred: float) -> "OnlineMetric":
        """Update the metric with a new prediction and ground truth.

        Args:
            y_true: True target value.
            y_pred: Predicted target value.

        Returns:
            self
        """
        pass

    @abstractmethod
    def get(self) -> float:
        """Return the current value of the metric.

        Returns:
            Current metric value.
        """
        pass

    @abstractmethod
    def clear(self) -> None:
        """Reset the metric state."""
        pass


class MeanSquaredError(OnlineMetric):
    """Incremental Mean Squared Error (MSE)."""

    def __init__(self) -> None:
        self.n = 0
        self.sum_sq_error = 0.0

    def update(self, y_true: float, y_pred: float) -> "MeanSquaredError":
        error = y_true - y_pred
        self.sum_sq_error += error**2
        self.n += 1
        return self

    def get(self) -> float:
        return self.sum_sq_error / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.n = 0
        self.sum_sq_error = 0.0


class MeanAbsoluteError(OnlineMetric):
    """Incremental Mean Absolute Error (MAE)."""

    def __init__(self) -> None:
        self.n = 0
        self.sum_abs_error = 0.0

    def update(self, y_true: float, y_pred: float) -> "MeanAbsoluteError":
        error = abs(y_true - y_pred)
        self.sum_abs_error += error
        self.n += 1
        return self

    def get(self) -> float:
        return self.sum_abs_error / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.n = 0
        self.sum_abs_error = 0.0
