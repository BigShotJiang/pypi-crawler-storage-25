from abc import ABC, abstractmethod
from typing import Any


class Detector(ABC):
    """Base class for online anomaly detectors."""

    @abstractmethod
    def score_one(self, x: dict[str, Any]) -> float:
        """Returns an anomaly score between 0.0 and 1.0.

        Args:
            x: Input features.

        Returns:
            Anomaly score (closer to 1.0 is more anomalous).
        """
        pass

    @abstractmethod
    def learn_one(self, x: dict[str, Any]) -> "Detector":
        """Update the model with a new observation.

        Args:
            x: Input features.

        Returns:
            self
        """
        pass

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        """Explain the anomaly score for a single observation.

        Default implementation returns empty dict. Override in subclasses.
        """
        return {}

    @abstractmethod
    def clear(self) -> None:
        """Reset the detector state."""
        pass
