from abc import ABC, abstractmethod
from typing import Any


class Classifier(ABC):
    """Base class for online classification models."""

    @abstractmethod
    def learn_one(self, x: dict[str, Any], y: str | int) -> "Classifier":
        """Update the model with a single observation.

        Args:
            x: Input features.
            y: Target class label.

        Returns:
            self
        """
        pass

    @abstractmethod
    def predict_one(self, x: dict[str, Any]) -> str | int:
        """Predict the class label for a single observation.

        Args:
            x: Input features.

        Returns:
            Predicted class label.
        """
        pass

    @abstractmethod
    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        """Predict the class probabilities for a single observation.

        Args:
            x: Input features.

        Returns:
            Dictionary mapping class labels to probabilities.
        """
        pass

    @abstractmethod
    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        """Explain the prediction for a single observation.

        Returns:
            Dictionary mapping feature names to their contribution.
        """
        pass

    @abstractmethod
    def clear(self) -> None:
        """Reset the classifier state."""
        pass
