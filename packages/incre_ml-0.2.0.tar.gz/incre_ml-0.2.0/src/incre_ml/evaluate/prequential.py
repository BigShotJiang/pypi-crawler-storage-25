from collections.abc import Iterable
from typing import Any

from ..base.classifier import Classifier
from ..base.regressor import Regressor
from ..metrics.base import Metric


def prequential_score(
    model: Regressor | Classifier,
    stream: Iterable[tuple[dict[str, Any], Any]],
    metric: Metric,
    print_every: int = 0,
) -> float:
    """Prequential (test-then-train) evaluation.

    For each observation in the stream:
    1. Predict (test)
    2. Update the metric
    3. Learn (train)

    Args:
        model: An online model (Regressor or Classifier).
        stream: Iterable of (x, y) pairs.
        metric: An online metric to track performance.
        print_every: If > 0, print metric value every N observations.

    Returns:
        Final metric value.
    """
    n = 0
    for x, y in stream:
        # Test
        y_pred: Any = model.predict_one(x)

        # Score
        metric.update(y, y_pred)

        # Train
        model.learn_one(x, y)

        n += 1
        if print_every > 0 and n % print_every == 0:
            print(f"[{n}] {metric.__class__.__name__}: {metric.get():.6f}")

    return metric.get()
