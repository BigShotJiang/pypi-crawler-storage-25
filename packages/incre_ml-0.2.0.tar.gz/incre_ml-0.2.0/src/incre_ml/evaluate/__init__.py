from .prequential import prequential_score

__all__ = ["prequential_score"]
