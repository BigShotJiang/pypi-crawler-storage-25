import random


class ThresholdPolicy:
    """Simple policy that triggers an action when a value exceeds a threshold."""

    def __init__(self, threshold: float, side: str = "above") -> None:
        self.threshold = threshold
        if side not in {"above", "below"}:
            raise ValueError("side must be 'above' or 'below'")
        self.side = side

    def decide(self, value: float) -> bool:
        if self.side == "above":
            return value > self.threshold
        return value < self.threshold


class EpsilonGreedyBandit:
    """Decisioning agent that balances exploration and exploitation."""

    def __init__(self, actions: list[str], epsilon: float = 0.1) -> None:
        if not actions:
            raise ValueError("actions must not be empty")
        if len(set(actions)) != len(actions):
            raise ValueError("actions must be unique")
        if not (0.0 <= epsilon <= 1.0):
            raise ValueError("epsilon must be in [0, 1]")
        self.actions = actions
        self.epsilon = epsilon
        self.counts = {a: 0 for a in actions}
        self.values = {a: 0.0 for a in actions}

    def select_action(self) -> str:
        if random.random() < self.epsilon:
            return random.choice(self.actions)

        # Exploitation: pick best action
        return max(self.values, key=lambda k: float(self.values[k]))

    def update(self, action: str, reward: float) -> None:
        if action not in self.counts:
            raise KeyError(f"Unknown action: {action}")
        self.counts[action] += 1
        n = self.counts[action]
        val = self.values[action]
        # Incremental mean update for reward
        self.values[action] = val + (reward - val) / n
