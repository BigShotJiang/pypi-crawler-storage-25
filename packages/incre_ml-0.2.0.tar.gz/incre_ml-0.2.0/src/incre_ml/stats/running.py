import math


class RunningStatistics:
    """Computes online mean and variance using Welford's algorithm."""

    def __init__(self) -> None:
        self.n = 0
        self.mean = 0.0
        self._m2 = 0.0

    def update(self, x: float) -> "RunningStatistics":
        self.n += 1
        delta = x - self.mean
        self.mean += delta / self.n
        delta2 = x - self.mean
        self._m2 += delta * delta2
        return self

    def clear(self) -> None:
        """Reset the statistics."""
        self.n = 0
        self.mean = 0.0
        self._m2 = 0.0

    @property
    def variance(self) -> float:
        return self._m2 / self.n if self.n > 1 else 0.0

    @property
    def std_dev(self) -> float:
        return math.sqrt(self.variance)

    @property
    def count(self) -> int:
        return self.n


class RunningCorrelation:
    """Computes online Pearson correlation between two variables."""

    def __init__(self) -> None:
        self.stats_x = RunningStatistics()
        self.stats_y = RunningStatistics()
        self.sum_xy = 0.0
        self.n = 0

    def update(self, x: float, y: float) -> "RunningCorrelation":
        self.n += 1
        self.stats_x.update(x)
        self.stats_y.update(y)
        self.sum_xy += x * y
        return self

    @property
    def correlation(self) -> float:
        min_samples = 2
        if self.n < min_samples:
            return 0.0

        # Pearson correlation formula: (E[XY] - E[X]E[Y]) / (std_x * std_y)
        mean_x = self.stats_x.mean
        mean_y = self.stats_y.mean
        std_x = self.stats_x.std_dev
        std_y = self.stats_y.std_dev

        if std_x == 0 or std_y == 0:
            return 0.0

        covariance = (self.sum_xy / self.n) - (mean_x * mean_y)
        return covariance / (std_x * std_y)

    def clear(self) -> None:
        self.stats_x.clear()
        self.stats_y.clear()
        self.sum_xy = 0.0
        self.n = 0
