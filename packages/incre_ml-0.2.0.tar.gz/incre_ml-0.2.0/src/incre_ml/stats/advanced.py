import math

from .running import RunningStatistics


class EWMAStatistics:
    """Exponentially Weighted Moving Average and Variance."""

    def __init__(self, alpha: float = 0.5) -> None:
        self.alpha = alpha
        self.mean: float = 0.0
        self.variance: float = 0.0
        self.n = 0

    def update(self, x: float) -> "EWMAStatistics":
        if self.n == 0:
            self.mean = x
            self.variance = 0.0
        else:
            diff = x - self.mean
            incr = self.alpha * diff
            self.mean += incr
            self.variance = (1.0 - self.alpha) * (self.variance + diff * incr)
        self.n += 1
        return self

    @property
    def std_dev(self) -> float:
        return math.sqrt(self.variance)

    def clear(self) -> None:
        self.mean = 0.0
        self.variance = 0.0
        self.n = 0


class ResidualTracker:
    """Tracks prediction residuals and their distribution."""

    def __init__(self) -> None:
        self.stats = RunningStatistics()

    def update(self, y_true: float, y_pred: float) -> "ResidualTracker":
        residual = y_true - y_pred
        self.stats.update(residual)
        return self

    @property
    def mean(self) -> float:
        return self.stats.mean

    @property
    def std(self) -> float:
        return self.stats.std_dev

    def clear(self) -> None:
        self.stats.clear()
