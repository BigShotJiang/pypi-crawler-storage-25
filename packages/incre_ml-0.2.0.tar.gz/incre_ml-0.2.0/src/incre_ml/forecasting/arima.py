from collections import deque
from math import comb
from typing import Any

from ..base import Regressor
from ..linear import LinearRegression


class AR(Regressor):
    """Auto-Regressive (AR) model with online learning.

    Predicts the next value based on the previous `p` values.
    """

    def __init__(self, p: int = 1, learning_rate: float = 0.01) -> None:
        self.p = p
        self.model = LinearRegression(learning_rate=learning_rate)
        self.history: deque[float] = deque(maxlen=p)

    def _get_features(self) -> dict[str, float]:
        """Convert the history of the last `p` points into features."""
        return {
            f"lag_{i + 1}": self.history[-(i + 1)] for i in range(len(self.history))
        }

    def learn_one(self, x: dict[str, Any], y: float) -> "AR":
        if len(self.history) == self.p:
            features = self._get_features()
            self.model.learn_one(features, y)

        self.history.append(y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        if len(self.history) < self.p:
            return self.history[-1] if self.history else 0.0

        features = self._get_features()
        return self.model.predict_one(features)

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        if len(self.history) < self.p:
            return {"fallback": self.history[-1] if self.history else 0.0}
        return self.model.explain_one(self._get_features())

    def clear(self) -> None:
        self.model.clear()
        self.history = deque(maxlen=self.p)


class SNARIMAX(Regressor):
    """Seasonal Non-stationary AutoRegressive Integrated Moving-Average.

    A simplified online version that uses SGD to update weights
    for lags and seasonal components. Includes support for exogenous variables.
    """

    def __init__(
        self,
        p: int = 1,
        d: int = 0,
        q: int = 0,
        p_seasonal: int = 0,
        d_seasonal: int = 0,
        q_seasonal: int = 0,
        s: int = 0,
        learning_rate: float = 0.01,
    ) -> None:
        if (
            p < 0
            or d < 0
            or q < 0
            or p_seasonal < 0
            or d_seasonal < 0
            or q_seasonal < 0
        ):
            raise ValueError("ARIMA orders must be non-negative.")
        if s < 0:
            raise ValueError("Seasonality period `s` must be non-negative.")
        if (d_seasonal > 0 or p_seasonal > 0 or q_seasonal > 0) and s <= 0:
            raise ValueError(
                "Seasonal orders require a positive seasonality period `s`."
            )

        self.p = p
        self.d = d
        self.q = q
        self.p_seasonal = p_seasonal
        self.d_seasonal = d_seasonal
        self.q_seasonal = q_seasonal
        self.s = s

        self.model = LinearRegression(learning_rate=learning_rate)
        self._diff_coeffs = self._build_differencing_coefficients()

        # Compute state cap once in __init__
        max_state_lag = max(
            self._max_required_raw_lag(),
            self.p,
            self.q,
            self.p_seasonal * self.s if self.s > 0 else 0,
            self.q_seasonal * self.s if self.s > 0 else 0,
        )
        self._state_cap = max(8, max_state_lag + 4)

        self.history: deque[float] = deque(maxlen=self._state_cap)
        self.transformed_history: deque[float] = deque(maxlen=self._state_cap)
        self.residual_history: deque[float] = deque(maxlen=self._state_cap)

    def _build_differencing_coefficients(self) -> dict[int, float]:
        """Build coefficients for (1-B)^d * (1-B^s)^D as lag->coefficient."""
        coeffs: dict[int, float] = {0: 1.0}

        for k in range(1, self.d + 1):
            coeffs[k] = coeffs.get(k, 0.0) + ((-1.0) ** k) * float(comb(self.d, k))

        seasonal_coeffs: dict[int, float] = {0: 1.0}
        for k in range(1, self.d_seasonal + 1):
            seasonal_coeffs[k * self.s] = seasonal_coeffs.get(k * self.s, 0.0) + (
                (-1.0) ** k
            ) * float(comb(self.d_seasonal, k))

        final_coeffs: dict[int, float] = {}
        for lag_a, coef_a in coeffs.items():
            for lag_b, coef_b in seasonal_coeffs.items():
                lag = lag_a + lag_b
                final_coeffs[lag] = final_coeffs.get(lag, 0.0) + coef_a * coef_b
        return final_coeffs

    def _max_required_raw_lag(self) -> int:
        return max(self._diff_coeffs.keys(), default=0)

    def _compute_transformed_target(self, y: float) -> float | None:
        """Compute differenced target z_t from raw y_t and raw history."""
        max_lag = self._max_required_raw_lag()
        if len(self.history) < max_lag:
            return None

        z_t = self._diff_coeffs.get(0, 1.0) * y
        for lag, coef in self._diff_coeffs.items():
            if lag == 0:
                continue
            z_t += coef * self.history[-lag]
        return float(z_t)

    def _get_features(self) -> dict[str, float]:
        features: dict[str, float] = {}
        for i in range(1, min(self.p + 1, len(self.transformed_history) + 1)):
            features[f"lag_{i}"] = self.transformed_history[-i]

        if self.s > 0:
            for i in range(1, self.p_seasonal + 1):
                idx = i * self.s
                if len(self.transformed_history) >= idx:
                    features[f"seasonal_lag_{i}"] = self.transformed_history[-idx]

        for i in range(1, min(self.q + 1, len(self.residual_history) + 1)):
            features[f"ma_{i}"] = self.residual_history[-i]

        if self.s > 0:
            for i in range(1, self.q_seasonal + 1):
                idx = i * self.s
                if len(self.residual_history) >= idx:
                    features[f"seasonal_ma_{i}"] = self.residual_history[-idx]

        return features

    def _inverse_transform_forecast(self, z_hat: float) -> float:
        """Map differenced forecast back to original scale."""
        y_hat = float(z_hat)
        for lag, coef in self._diff_coeffs.items():
            if lag == 0:
                continue
            if len(self.history) < lag:
                return self.history[-1] if self.history else 0.0
            y_hat -= coef * self.history[-lag]
        return float(y_hat)

    def learn_one(self, x: dict[str, Any], y: float) -> "SNARIMAX":
        z_t = self._compute_transformed_target(y)
        if z_t is not None:
            features = self._get_features()
            features.update(x)
            z_pred = self.model.predict_one(features)
            self.model.learn_one(features, z_t)
            self.transformed_history.append(float(z_t))
            self.residual_history.append(float(z_t - z_pred))

        self.history.append(float(y))
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        features = self._get_features()
        features.update(x)

        if not features and not x:
            return self.history[-1] if self.history else 0.0

        z_hat = self.model.predict_one(features)
        if self.d == 0 and self.d_seasonal == 0:
            return float(z_hat)
        return self._inverse_transform_forecast(float(z_hat))

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        features = self._get_features()
        features.update(x)
        if not features:
            return {"fallback": self.history[-1] if self.history else 0.0}
        return self.model.explain_one(features)

    def clear(self) -> None:
        self.model.clear()
        self.history = deque(maxlen=self._state_cap)
        self.transformed_history = deque(maxlen=self._state_cap)
        self.residual_history = deque(maxlen=self._state_cap)
