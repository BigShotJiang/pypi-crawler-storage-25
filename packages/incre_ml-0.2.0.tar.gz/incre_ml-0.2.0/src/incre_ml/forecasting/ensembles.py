import math
from typing import Any

from ..base.regressor import Regressor


class WeightedExpertsEnsemble(Regressor):
    """Combines multiple models using Exponentially Weighted Forecaster logic.

    Each model's weight is updated based on its loss, giving more influence
    to models that have performed better recently.
    """

    def __init__(self, models: dict[str, Regressor], eta: float = 0.1) -> None:
        if not models:
            raise ValueError("models must not be empty")
        if eta < 0.0:
            raise ValueError("eta must be >= 0")
        self.models = models
        self.eta = eta
        self.weights = {name: 1.0 / len(models) for name in models.keys()}

    def learn_one(self, x: dict[str, Any], y: float) -> "WeightedExpertsEnsemble":
        for name, model in self.models.items():
            y_pred = model.predict_one(x)
            loss = abs(y - y_pred)

            # Update weights: w = w * exp(-eta * loss)
            self.weights[name] *= math.exp(-self.eta * loss)

            # Model internal update
            model.learn_one(x, y)

        # Re-normalize weights to avoid underflow and keep distribution
        total_w = sum(self.weights.values())
        if total_w > 0:
            for name in self.weights:
                self.weights[name] /= total_w
        else:
            self.weights = {name: 1.0 / len(self.models) for name in self.models.keys()}

        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        total_pred = 0.0
        for name, model in self.models.items():
            total_pred += model.predict_one(x) * self.weights[name]
        return total_pred

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl: dict[str, float] = {}
        for name, model in self.models.items():
            # Weighted contribution from each model's own explanation
            m_expl = model.explain_one(x)
            for feat, val in m_expl.items():
                expl[f"{name}_{feat}"] = val * self.weights[name]
        return expl

    def clear(self) -> None:
        for model in self.models.values():
            model.clear()
        self.weights = {name: 1.0 / len(self.models) for name in self.models.keys()}
