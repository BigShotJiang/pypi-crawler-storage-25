from typing import Any

import numpy as np

from ..base.regressor import Regressor


class KalmanFilterRegressor(Regressor):
    """Kalman Filter for online regression/tracking.

    A simple 1D Kalman filter that tracks a state (level and trend).
    """

    def __init__(
        self, process_noise: float = 0.1, measurement_noise: float = 1.0
    ) -> None:
        if process_noise < 0.0:
            raise ValueError("process_noise must be >= 0")
        if measurement_noise <= 0.0:
            raise ValueError("measurement_noise must be > 0")
        self.q = process_noise
        self.r = measurement_noise

        # State vector [level, trend]
        self.x = np.zeros(2)
        # Covariance matrix
        self.p = np.eye(2)
        # Transition matrix (assuming constant velocity)
        self.f = np.array([[1.0, 1.0], [0.0, 1.0]])
        # Measurement matrix
        self.h = np.array([[1.0, 0.0]])

        self.initialized = False

    def learn_one(self, x: dict[str, Any], y: float) -> "KalmanFilterRegressor":
        if not self.initialized:
            self.x = np.array([y, 0.0])
            self.initialized = True
            return self

        # 1. Predict
        self.x = self.f @ self.x
        self.p = self.f @ self.p @ self.f.T + self.q * np.eye(2)

        # 2. Update
        z = np.array([y])
        y_residual = z - self.h @ self.x
        s = self.h @ self.p @ self.h.T + self.r
        # Regularization guard for numerical stability
        s += 1e-10 * np.eye(s.shape[0])
        # Use solve instead of inv for numerical stability
        k = np.linalg.solve(s, (self.p @ self.h.T).T).T

        self.x = self.x + k @ y_residual
        self.p = (np.eye(2) - k @ self.h) @ self.p

        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        if not self.initialized:
            return 0.0
        # For one step ahead, we assume state transition
        pred_x = self.f @ self.x
        return float(pred_x[0])

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return {"level": float(self.x[0]), "trend": float(self.x[1])}

    def clear(self) -> None:
        self.x = np.zeros(2)
        self.p = np.eye(2)
        self.initialized = False
