from typing import Any

import numpy as np
import numpy.typing as npt

from ..base.regressor import Regressor


class RecursiveLeastSquaresRegressor(Regressor):
    """Recursive Least Squares (RLS) regressor.

    RLS provides an exact recursive update for linear models. It is
    computationally more expensive than SGD but converges much faster.
    """

    def __init__(self, l2: float = 1.0, delta: float = 0.01) -> None:
        if l2 <= 0.0:
            raise ValueError("`l2` must be > 0.")
        if delta <= 0.0:
            raise ValueError("`delta` must be > 0.")
        self.l2 = l2
        self.delta = delta
        self.w: npt.NDArray[np.float64] | None = None
        self.P: npt.NDArray[np.float64] | None = None
        self.feature_names: list[str] = []

    def _init_model(self, n_features: int) -> None:
        self.w = np.zeros(n_features)
        # P is inverse information matrix.
        # This corresponds to a ridge prior with precision `l2`
        # and prior confidence scaling `delta`.
        self.P = np.eye(n_features) / (self.l2 * self.delta)

    def _expand_model_if_needed(self, x_with_intercept: dict[str, Any]) -> None:
        if self.w is None or self.P is None:
            return
        missing = sorted(set(x_with_intercept.keys()) - set(self.feature_names))
        if not missing:
            return

        old_n = len(self.feature_names)
        new_n = old_n + len(missing)
        new_w = np.zeros(new_n)
        new_w[:old_n] = self.w

        new_p_mat = np.eye(new_n) / (self.l2 * self.delta)
        new_p_mat[:old_n, :old_n] = self.P

        self.w = new_w
        self.P = new_p_mat
        self.feature_names.extend(missing)

    def learn_one(
        self, x: dict[str, Any], y: float
    ) -> "RecursiveLeastSquaresRegressor":
        # Add intercept
        x_with_intercept = x.copy()
        if "intercept" not in x_with_intercept:
            x_with_intercept["intercept"] = 1.0

        if self.w is None:
            self.feature_names = sorted(x_with_intercept.keys())
            self._init_model(len(self.feature_names))
        else:
            self._expand_model_if_needed(x_with_intercept)

        # Convert dict to vector
        x_vec = np.array([x_with_intercept.get(f, 0.0) for f in self.feature_names])

        # RLS Update formulas
        # 1. Gain vector: k = (p_mat * x) / (1 + x^T * p_mat * x)
        p_mat = self.P
        w = self.w
        if p_mat is not None and w is not None:
            p_x = p_mat @ x_vec
            denom = 1.0 + x_vec @ p_x
            if denom <= 1e-12:
                return self
            k = p_x / denom

            # 2. Update weights: w = w + k * (y - x^T * w)
            error = y - x_vec @ w
            self.w = w + k * error

            # 3. Update P: p_mat = p_mat - k * x^T * p_mat
            self.P = p_mat - np.outer(k, x_vec @ p_mat)

        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        if self.w is None:
            return 0.0

        x_with_intercept = x.copy()
        if "intercept" not in x_with_intercept:
            x_with_intercept["intercept"] = 1.0

        x_vec = np.array([x_with_intercept.get(f, 0.0) for f in self.feature_names])
        return float(x_vec @ self.w)

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        if self.w is None:
            return {}

        x_with_intercept = x.copy()
        if "intercept" not in x_with_intercept:
            x_with_intercept["intercept"] = 1.0

        expl = {}
        for i, feat in enumerate(self.feature_names):
            expl[feat] = float(self.w[i] * x_with_intercept.get(feat, 0.0))
        return expl

    def clear(self) -> None:
        self.w = None
        self.P = None
        self.feature_names = []
