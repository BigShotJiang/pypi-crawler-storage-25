import copy
from typing import Any

import numpy as np

from ..base.uncertainty import UncertaintyRegressor


class BootstrappedRegressor(UncertaintyRegressor):
    """Ensemble that estimates uncertainty using streaming bootstrap.

    Uses the Oza-Russell algorithm: each incoming sample is used to update
    each member K times, where K ~ Poisson(1).
    """

    def __init__(self, base_model: Any, n_models: int = 10) -> None:
        if n_models <= 0:
            raise ValueError("n_models must be > 0")
        self.n_models = int(n_models)
        # Create n clones of the base model
        self.models = [copy.deepcopy(base_model) for _ in range(self.n_models)]

    def learn_one(self, x: dict[str, Any], y: float) -> "BootstrappedRegressor":
        for model in self.models:
            # Poisson(1) sampling for online bootstrap
            k = np.random.poisson(1)
            for _ in range(k):
                model.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        preds = [model.predict_one(x) for model in self.models]
        return float(np.mean(preds))

    def predict_with_uncertainty(self, x: dict[str, Any]) -> tuple[float, float]:
        preds = [model.predict_one(x) for model in self.models]
        return float(np.mean(preds)), float(np.std(preds))

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        # Aggregate explanations from all bootstrapped models
        all_expls: dict[str, list[float]] = {}
        for model in self.models:
            expl = model.explain_one(x)
            for feat, val in expl.items():
                if feat not in all_expls:
                    all_expls[feat] = []
                all_expls[feat].append(val)

        return {feat: float(np.mean(vals)) for feat, vals in all_expls.items()}

    def clear(self) -> None:
        for model in self.models:
            model.clear()
