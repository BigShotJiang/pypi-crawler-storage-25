from collections import deque
from typing import Any

from ..base import MeanAbsoluteError, Regressor


class ModelSelectorEnsemble(Regressor):
    """Ensemble of forecasters that dynamically selects the best-performing model.

    Tracks the performance of each candidate model and uses the prediction from
    the model with the lowest historical (or rolling-window) error.

    The correct prequential protocol is enforced:
        1. predict_one(x)     — cache predictions before any learning
        2. (receive true y)
        3. learn_one(x, y)    — update metrics from cached preds, then update models

    Args:
        models: Named dict of candidate regressors.
        window_size: If > 0, use a rolling window of the last `window_size`
            absolute errors for model selection instead of cumulative MAE.
            Rolling-window selection adapts faster after concept drift.
    """

    def __init__(self, models: dict[str, Regressor], window_size: int = 0):
        if not models:
            raise ValueError("models must not be empty")
        if window_size < 0:
            raise ValueError("window_size must be >= 0")
        self.models = models
        self.window_size = int(window_size)
        self.metrics = {name: MeanAbsoluteError() for name in models.keys()}
        # Rolling window buffers (only used when window_size > 0)
        self._windows: dict[str, deque[float]] = (
            {name: deque(maxlen=window_size) for name in models.keys()}
            if window_size > 0
            else {}
        )
        self.last_predictions: dict[str, float] = {}

    def _window_mae(self, name: str) -> float:
        buf = self._windows[name]
        if not buf:
            return float("inf")
        return sum(buf) / len(buf)

    def learn_one(self, x: dict[str, Any], y: float) -> "ModelSelectorEnsemble":
        # Update metrics using predictions made during the preceding predict_one call.
        # This is the correct prequential (test-then-train) protocol.
        for name, pred in self.last_predictions.items():
            ae = abs(y - pred)
            self.metrics[name].update(y, pred)
            if self.window_size > 0:
                self._windows[name].append(ae)

        # After metrics are updated, let each model learn.
        for model in self.models.values():
            model.learn_one(x, y)

        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        # Cache all model predictions before returning — metrics will be
        # evaluated against these predictions in the next learn_one call.
        self.last_predictions = {
            name: model.predict_one(x) for name, model in self.models.items()
        }

        best_model_name = self._get_best_model()
        return self.last_predictions[best_model_name]

    def _get_best_model(self) -> str:
        if self.window_size > 0:
            return min(self.models.keys(), key=self._window_mae)
        return min(
            self.metrics.keys(),
            key=lambda name: self.metrics[name].get(),
        )

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return self.models[self._get_best_model()].explain_one(x)

    def clear(self) -> None:
        for model in self.models.values():
            model.clear()
        for metric in self.metrics.values():
            metric.clear()
        for buf in self._windows.values():
            buf.clear()
        self.last_predictions = {}

    def get_best_model(self) -> str:
        """Return the name of the currently best-performing model."""
        return self._get_best_model()
