from typing import Any

from ..base.regressor import Regressor


class Croston(Regressor):
    """Croston's method for intermittent demand forecasting."""

    def __init__(self, alpha: float = 0.1) -> None:
        if not (0.0 <= alpha <= 1.0):
            raise ValueError("alpha must be in [0, 1]")
        self.alpha = alpha
        self.demand = 0.0
        self.period = 1.0
        self.time_since_last = 0
        self.initialized = False

    def learn_one(self, x: dict[str, Any], y: float) -> "Croston":
        self.time_since_last += 1
        if y > 0:
            if not self.initialized:
                self.demand = y
                self.period = float(self.time_since_last)
                self.initialized = True
            else:
                self.demand = self.alpha * y + (1 - self.alpha) * self.demand
                self.period = (
                    self.alpha * self.time_since_last + (1 - self.alpha) * self.period
                )

            self.time_since_last = 0
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        if not self.initialized or self.period == 0:
            return 0.0
        return self.demand / self.period

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return {"demand_size": self.demand, "demand_period": self.period}

    def clear(self) -> None:
        self.demand = 0.0
        self.period = 1.0
        self.time_since_last = 0
        self.initialized = False


class TSB(Regressor):
    """Teunter-Syntetos-Babai (TSB) method for intermittent demand."""

    def __init__(self, alpha: float = 0.1, beta: float = 0.1) -> None:
        if not (0.0 <= alpha <= 1.0):
            raise ValueError("alpha must be in [0, 1]")
        if not (0.0 <= beta <= 1.0):
            raise ValueError("beta must be in [0, 1]")
        self.alpha = alpha
        self.beta = beta
        self.demand = 0.0
        self.probability = 0.0
        self.initialized = False

    def learn_one(self, x: dict[str, Any], y: float) -> "TSB":
        if not self.initialized:
            self.demand = y
            self.probability = 1.0 if y > 0 else 0.0
            self.initialized = True
            return self

        if y > 0:
            self.demand = self.alpha * y + (1 - self.alpha) * self.demand
            self.probability = self.beta * 1.0 + (1 - self.beta) * self.probability
        else:
            self.probability = self.beta * 0.0 + (1 - self.beta) * self.probability

        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.demand * self.probability

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return {"demand_level": self.demand, "demand_probability": self.probability}

    def clear(self) -> None:
        self.demand = 0.0
        self.probability = 0.0
        self.initialized = False
