from typing import Any

from ..base import Regressor


class HoltWinters(Regressor):
    """Triple Exponential Smoothing (Holt-Winters).

    Supports level, trend, and additive seasonality.
    """

    def __init__(
        self,
        season_length: int,
        alpha: float = 0.5,
        beta: float = 0.1,
        gamma: float = 0.1,
    ) -> None:
        if season_length <= 0:
            raise ValueError("season_length must be > 0")
        if not (0.0 <= alpha <= 1.0 and 0.0 <= beta <= 1.0 and 0.0 <= gamma <= 1.0):
            raise ValueError("alpha, beta, gamma must be in [0, 1]")
        self.season_length = season_length
        self.alpha = alpha
        self.beta = beta
        self.gamma = gamma

        # State components
        self.level = 0.0
        self.trend = 0.0
        self.seasonal: list[float] = [0.0] * season_length

        self.n = 0

    def _get_seasonal_index(self, step: int) -> int:
        return step % self.season_length

    def learn_one(self, x: dict[str, Any], y: float) -> "HoltWinters":
        if self.n == 0:
            self.level = y
            self.n += 1
            return self

        # Update components using recursive formulas
        idx = self._get_seasonal_index(self.n)

        last_level = self.level
        last_trend = self.trend
        last_seasonal = self.seasonal[idx]

        # 1. Level update
        self.level = self.alpha * (y - last_seasonal) + (1 - self.alpha) * (
            last_level + last_trend
        )

        # 2. Trend update
        self.trend = (
            self.beta * (self.level - last_level) + (1 - self.beta) * last_trend
        )

        # 3. Seasonal update
        self.seasonal[idx] = (
            self.gamma * (y - self.level) + (1 - self.gamma) * last_seasonal
        )

        self.n += 1
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        if self.n == 0:
            return 0.0

        # For next point, seasonal index is n
        idx = self._get_seasonal_index(self.n)
        return self.level + self.trend + self.seasonal[idx]

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        if self.n == 0:
            return {}
        idx = self._get_seasonal_index(self.n)
        return {
            "level": self.level,
            "trend": self.trend,
            "seasonality": self.seasonal[idx],
        }

    def clear(self) -> None:
        self.level = 0.0
        self.trend = 0.0
        self.seasonal = [0.0] * self.season_length
        self.n = 0
