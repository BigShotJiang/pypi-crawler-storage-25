from collections import deque
from typing import Any

from ..base import Regressor


class NaiveForecaster(Regressor):
    """Predicts the last seen value."""

    def __init__(self) -> None:
        self.last_y = 0.0

    def learn_one(self, x: dict[str, Any], y: float) -> "NaiveForecaster":
        self.last_y = y
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.last_y

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return {"last_value": self.last_y}

    def clear(self) -> None:
        self.last_y = 0.0


class SeasonalNaiveForecaster(Regressor):
    """Predicts the value from the same time in the previous season."""

    def __init__(self, season_length: int) -> None:
        if season_length <= 0:
            raise ValueError("season_length must be > 0")
        self.season_length = season_length
        self.buffer: deque[float] = deque(maxlen=season_length)

    def learn_one(self, x: dict[str, Any], y: float) -> "SeasonalNaiveForecaster":
        self.buffer.append(y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        if len(self.buffer) < self.season_length:
            return self.buffer[-1] if self.buffer else 0.0
        return self.buffer[0]

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return {"seasonal_value": self.predict_one(x)}

    def clear(self) -> None:
        self.buffer = deque(maxlen=self.season_length)
