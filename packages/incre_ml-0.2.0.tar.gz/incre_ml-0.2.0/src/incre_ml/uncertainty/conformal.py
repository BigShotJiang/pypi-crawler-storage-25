import math
from collections import deque
from typing import Any

import numpy as np

from ..base.regressor import Regressor
from ..base.uncertainty import UncertaintyRegressor


class ConformalRegressor(UncertaintyRegressor):
    """Wraps a model with Conformal Prediction for valid intervals.

    Uses a sliding window of absolute residuals to determine the
    prediction interval for a given confidence level (alpha).
    """

    def __init__(
        self, model: Regressor, window_size: int = 100, alpha: float = 0.1
    ) -> None:
        if window_size <= 0:
            raise ValueError("window_size must be > 0")
        if not (0.0 < alpha < 1.0):
            raise ValueError("alpha must be in (0, 1)")
        self.model = model
        self.window_size = int(window_size)
        self.alpha = float(alpha)
        self.residuals: deque[float] = deque(maxlen=window_size)

    def learn_one(self, x: dict[str, Any], y: float) -> "ConformalRegressor":
        y_pred = self.model.predict_one(x)
        error = abs(float(y) - float(y_pred))
        if np.isfinite(error):
            self.residuals.append(error)
        self.model.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.model.predict_one(x)

    def predict_with_uncertainty(self, x: dict[str, Any]) -> tuple[float, float]:
        y_pred = float(self.model.predict_one(x))

        if not self.residuals:
            return y_pred, 0.0

        sorted_res = np.sort(np.asarray(self.residuals, dtype=float))
        n = int(sorted_res.size)
        k = int(math.ceil((n + 1) * (1.0 - self.alpha)))
        idx = max(0, min(n - 1, k - 1))
        quantile_val = float(sorted_res[idx])
        if not np.isfinite(quantile_val) or quantile_val < 0.0:
            quantile_val = 0.0

        return y_pred, quantile_val

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = self.model.explain_one(x) or {}
        _, std = self.predict_with_uncertainty(x)
        expl["conformal_interval"] = std
        return expl

    def clear(self) -> None:
        self.model.clear()
        self.residuals = deque(maxlen=self.window_size)


class AdaptiveConformalRegressor(UncertaintyRegressor):
    """Conformal Regressor with Adaptive Conformal Inference (ACI).

    Adjusts alpha based on recent coverage rate to maintain
    the target coverage level dynamically.
    """

    def __init__(
        self,
        model: Regressor,
        window_size: int = 100,
        alpha: float = 0.1,
        gamma: float = 0.01,
    ) -> None:
        if window_size <= 0:
            raise ValueError("window_size must be > 0")
        if not (0.0 < alpha < 1.0):
            raise ValueError("alpha must be in (0, 1)")
        if gamma <= 0:
            raise ValueError("gamma must be > 0")
        self.model = model
        self.window_size = int(window_size)
        self.target_alpha = float(alpha)
        self.alpha = float(alpha)
        self.gamma = float(gamma)
        self.residuals: deque[float] = deque(maxlen=window_size)
        self._coverage_history: deque[int] = deque(maxlen=window_size)

    def learn_one(self, x: dict[str, Any], y: float) -> "AdaptiveConformalRegressor":
        y_pred, interval = self.predict_with_uncertainty(x)
        error = abs(float(y) - float(y_pred))

        # Track coverage
        covered = 1 if error <= interval else 0
        self._coverage_history.append(covered)

        # Adapt alpha based on coverage
        if len(self._coverage_history) > 10:
            empirical_coverage = sum(self._coverage_history) / len(
                self._coverage_history
            )
            target_coverage = 1.0 - self.target_alpha
            # If under-covering, decrease alpha (widen intervals)
            # If over-covering, increase alpha (narrow intervals)
            adjustment = self.gamma * (empirical_coverage - target_coverage)
            self.alpha = max(0.01, min(0.99, self.alpha + adjustment))

        if np.isfinite(error):
            self.residuals.append(error)
        self.model.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.model.predict_one(x)

    def predict_with_uncertainty(self, x: dict[str, Any]) -> tuple[float, float]:
        y_pred = float(self.model.predict_one(x))

        if not self.residuals:
            return y_pred, 0.0

        sorted_res = np.sort(np.asarray(self.residuals, dtype=float))
        n = int(sorted_res.size)
        k = int(math.ceil((n + 1) * (1.0 - self.alpha)))
        idx = max(0, min(n - 1, k - 1))
        quantile_val = float(sorted_res[idx])
        if not np.isfinite(quantile_val) or quantile_val < 0.0:
            quantile_val = 0.0

        return y_pred, quantile_val

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = self.model.explain_one(x) or {}
        _, interval = self.predict_with_uncertainty(x)
        expl["adaptive_conformal_interval"] = interval
        expl["current_alpha"] = self.alpha
        return expl

    def clear(self) -> None:
        self.model.clear()
        self.residuals = deque(maxlen=self.window_size)
        self._coverage_history = deque(maxlen=self.window_size)
        self.alpha = self.target_alpha
