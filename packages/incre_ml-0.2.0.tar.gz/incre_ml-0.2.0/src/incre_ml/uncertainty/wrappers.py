import math
from typing import Any

from ..base.regressor import Regressor
from ..base.uncertainty import UncertaintyRegressor
from ..stats.advanced import ResidualTracker


class ResidualUncertaintyWrapper(UncertaintyRegressor):
    """Wraps a model and uses historical residuals to estimate uncertainty.

    Assumes residuals are approximately Gaussian.
    """

    def __init__(
        self, model: Regressor, residual_tracker: ResidualTracker | None = None
    ) -> None:
        self.model = model
        self.residual_tracker = residual_tracker or ResidualTracker()

    def learn_one(self, x: dict[str, Any], y: float) -> "ResidualUncertaintyWrapper":
        y_pred = self.model.predict_one(x)
        if math.isfinite(float(y)) and math.isfinite(float(y_pred)):
            self.residual_tracker.update(y, y_pred)
        self.model.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.model.predict_one(x)

    def predict_with_uncertainty(self, x: dict[str, Any]) -> tuple[float, float]:
        pred = float(self.model.predict_one(x))
        std = float(self.residual_tracker.std)
        if not math.isfinite(std) or std < 0.0:
            std = 0.0
        return pred, std

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = self.model.explain_one(x) or {}
        expl["residual_std"] = self.residual_tracker.std
        return expl

    def clear(self) -> None:
        self.model.clear()
        self.residual_tracker.clear()
