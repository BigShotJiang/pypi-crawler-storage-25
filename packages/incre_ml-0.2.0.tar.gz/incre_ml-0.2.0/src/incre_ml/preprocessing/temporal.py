from collections import deque
from datetime import datetime
from typing import Any

from ..base.transformer import Transformer
from ..stats.running import RunningStatistics


class LagFeatureTransformer(Transformer):
    """Transformer that adds lagged features of a target variable."""

    def __init__(self, lags: list[int], feature_name: str = "y") -> None:
        if not lags:
            raise ValueError("lags must not be empty")
        if any(int(lag) <= 0 for lag in lags):
            raise ValueError("all lags must be positive integers")
        self.lags = lags
        self.feature_name = feature_name
        self.max_lag = max(lags) if lags else 0
        self.history: deque[float] = deque(maxlen=self.max_lag)

    def learn_one(
        self, x: dict[str, Any], y: Any | None = None
    ) -> "LagFeatureTransformer":
        if y is not None:
            self.history.append(float(y))
        return self

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        x_transformed = x.copy()
        for lag in self.lags:
            if len(self.history) >= lag:
                x_transformed[f"{self.feature_name}_lag_{lag}"] = self.history[-lag]
            else:
                x_transformed[f"{self.feature_name}_lag_{lag}"] = 0.0
        return x_transformed

    def clear(self) -> None:
        self.history = deque(maxlen=self.max_lag)


class RollingStatsTransformer(Transformer):
    """Transformer that adds rolling statistics of a target variable."""

    def __init__(self, window_size: int, feature_name: str = "y") -> None:
        if window_size <= 0:
            raise ValueError("window_size must be > 0")
        self.window_size = window_size
        self.feature_name = feature_name
        self.buffer: deque[float] = deque(maxlen=window_size)
        self._current_stats = RunningStatistics()
        self._cached_mean = 0.0
        self._cached_std = 0.0

    def learn_one(
        self, x: dict[str, Any], y: Any | None = None
    ) -> "RollingStatsTransformer":
        if y is not None:
            val = float(y)
            if len(self.buffer) == self.window_size:
                # Buffer full — rebuild stats (eviction requires rebuild with Welford's)
                self.buffer.append(val)
                self._rebuild_stats()
            else:
                self.buffer.append(val)
                self._current_stats.update(val)
                self._cached_mean = self._current_stats.mean
                self._cached_std = self._current_stats.std_dev
        return self

    def _rebuild_stats(self) -> None:
        """Rebuild stats from buffer after eviction."""
        self._current_stats = RunningStatistics()
        for v in self.buffer:
            self._current_stats.update(v)
        self._cached_mean = self._current_stats.mean
        self._cached_std = self._current_stats.std_dev

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        x_transformed = x.copy()
        if self.buffer:
            x_transformed[f"{self.feature_name}_rolling_mean"] = self._cached_mean
            x_transformed[f"{self.feature_name}_rolling_std"] = self._cached_std
        else:
            x_transformed[f"{self.feature_name}_rolling_mean"] = 0.0
            x_transformed[f"{self.feature_name}_rolling_std"] = 0.0
        return x_transformed

    def clear(self) -> None:
        self.buffer = deque(maxlen=self.window_size)
        self._current_stats = RunningStatistics()
        self._cached_mean = 0.0
        self._cached_std = 0.0


class DateTimeFeaturesTransformer(Transformer):
    """Transformer that extracts features from a datetime field."""

    def __init__(self, feature_name: str = "timestamp") -> None:
        self.feature_name = feature_name

    def learn_one(
        self, x: dict[str, Any], y: Any | None = None
    ) -> "DateTimeFeaturesTransformer":
        return self

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        x_transformed = x.copy()
        dt_val = x.get(self.feature_name)

        if dt_val:
            if isinstance(dt_val, str):
                try:
                    dt = datetime.fromisoformat(dt_val)
                except ValueError:
                    return x_transformed
            elif isinstance(dt_val, datetime):
                dt = dt_val
            else:
                return x_transformed

            x_transformed[f"{self.feature_name}_hour"] = float(dt.hour)
            x_transformed[f"{self.feature_name}_dayofweek"] = float(dt.weekday())
            x_transformed[f"{self.feature_name}_month"] = float(dt.month)

        return x_transformed

    def clear(self) -> None:
        pass
