from typing import Any

from ..base.transformer import Transformer
from ..stats.running import RunningStatistics


class OneHotEncoder(Transformer):
    """Online one-hot encoding for categorical features.

    Tracks seen categories per feature and transforms them into binary columns.
    """

    def __init__(self, max_categories: int = 100) -> None:
        if max_categories <= 0:
            raise ValueError("max_categories must be > 0")
        self.max_categories = max_categories
        self._categories: dict[str, set[str]] = {}

    def learn_one(self, x: dict[str, Any], y: Any | None = None) -> "OneHotEncoder":
        for feat, val in x.items():
            if isinstance(val, str):
                if feat not in self._categories:
                    self._categories[feat] = set()
                if len(self._categories[feat]) < self.max_categories:
                    self._categories[feat].add(val)
        return self

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for feat, val in x.items():
            if isinstance(val, str) and feat in self._categories:
                for cat in self._categories[feat]:
                    result[f"{feat}_{cat}"] = 1.0 if val == cat else 0.0
            else:
                result[feat] = val
        return result

    def clear(self) -> None:
        self._categories = {}


class TargetEncoder(Transformer):
    """Online target encoding with Bayesian smoothing.

    Encodes categorical features using the running mean of the target
    per category, with a global mean prior for smoothing.
    """

    def __init__(self, smoothing: float = 10.0) -> None:
        if smoothing < 0:
            raise ValueError("smoothing must be >= 0")
        self.smoothing = smoothing
        self._category_stats: dict[str, dict[str, RunningStatistics]] = {}
        self._global_stats = RunningStatistics()

    def learn_one(self, x: dict[str, Any], y: Any | None = None) -> "TargetEncoder":
        if y is None:
            return self
        target = float(y)
        self._global_stats.update(target)
        for feat, val in x.items():
            if isinstance(val, str):
                if feat not in self._category_stats:
                    self._category_stats[feat] = {}
                if val not in self._category_stats[feat]:
                    self._category_stats[feat][val] = RunningStatistics()
                self._category_stats[feat][val].update(target)
        return self

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        global_mean = self._global_stats.mean
        for feat, val in x.items():
            if isinstance(val, str):
                if feat in self._category_stats and val in self._category_stats[feat]:
                    stats = self._category_stats[feat][val]
                    n = stats.count
                    cat_mean = stats.mean
                    # Bayesian smoothing: blend category mean and global mean
                    encoded = (n * cat_mean + self.smoothing * global_mean) / (
                        n + self.smoothing
                    )
                    result[feat] = encoded
                else:
                    result[feat] = global_mean
            else:
                result[feat] = val
        return result

    def clear(self) -> None:
        self._category_stats = {}
        self._global_stats = RunningStatistics()
