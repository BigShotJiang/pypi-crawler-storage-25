import math
from numbers import Real
from typing import Any

from ..base.transformer import Transformer
from ..stats.running import RunningCorrelation


class SelectKBest(Transformer):
    """Keep the k features with highest absolute correlation with the target.

    This is a supervised transformer that requires the target value 'y'
    during the learn_one phase.
    """

    def __init__(self, k: int = 5, update_interval: int = 100) -> None:
        if k <= 0:
            raise ValueError("k must be > 0")
        self.k = k
        self.update_interval = update_interval
        self._sample_count = 0
        self.feature_correlations: dict[str, RunningCorrelation] = {}
        self.top_k_features: list[str] = []

    def learn_one(self, x: dict[str, Any], y: float | None = None) -> "SelectKBest":
        if y is None:
            return self
        if not isinstance(y, Real) or not math.isfinite(float(y)):
            return self
        fy = float(y)

        for feat, val in x.items():
            if not isinstance(val, Real):
                continue
            fval = float(val)
            if not math.isfinite(fval):
                continue
            if feat not in self.feature_correlations:
                self.feature_correlations[feat] = RunningCorrelation()
            self.feature_correlations[feat].update(fval, fy)

        self._sample_count += 1
        # Amortized update: only recompute top-k every update_interval samples
        if self._sample_count % self.update_interval == 0 or not self.top_k_features:
            self._update_top_k()
        return self

    def _update_top_k(self) -> None:
        # Sort features by absolute correlation
        sorted_feats = sorted(
            self.feature_correlations.keys(),
            key=lambda f: abs(self.feature_correlations[f].correlation),
            reverse=True,
        )
        self.top_k_features = sorted_feats[: self.k]

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        if not self.top_k_features:
            return x
        return {f: x[f] for f in self.top_k_features if f in x}

    def clear(self) -> None:
        self.feature_correlations = {}
        self.top_k_features = []
        self._sample_count = 0

    def get_correlations(self) -> dict[str, float]:
        """Returns the current absolute correlation for all features."""
        return {
            f: abs(corr.correlation) for f, corr in self.feature_correlations.items()
        }
