import math
from numbers import Real
from typing import Any

from ..base.transformer import Transformer
from ..stats.running import RunningStatistics


class StandardScaler(Transformer):
    """Incremental standard scaler for online normalization.

    Transforms each feature x by (x - mean) / std_dev.
    """

    def __init__(self) -> None:
        self.stats: dict[str, RunningStatistics] = {}

    def learn_one(self, x: dict[str, Any], y: Any | None = None) -> "StandardScaler":
        for feat, val in x.items():
            if not isinstance(val, Real):
                continue
            fval = float(val)
            if not math.isfinite(fval):
                continue
            if feat not in self.stats:
                self.stats[feat] = RunningStatistics()
            self.stats[feat].update(fval)
        return self

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        transformed_x = {}
        for feat, val in x.items():
            if not isinstance(val, Real):
                transformed_x[feat] = val
                continue
            fval = float(val)
            if not math.isfinite(fval):
                transformed_x[feat] = val
                continue
            if feat in self.stats and self.stats[feat].count > 1:
                std = self.stats[feat].std_dev
                if std > 0:
                    transformed_x[feat] = (fval - self.stats[feat].mean) / std
                else:
                    transformed_x[feat] = 0.0
            else:
                transformed_x[feat] = fval
        return transformed_x

    def clear(self) -> None:
        self.stats = {}


class MinMaxScaler(Transformer):
    """Incremental min-max scaler for online normalization.

    Transforms each feature x to a range [0, 1].
    """

    def __init__(self) -> None:
        self.mins: dict[str, float] = {}
        self.maxs: dict[str, float] = {}

    def learn_one(self, x: dict[str, Any], y: Any | None = None) -> "MinMaxScaler":
        for feat, val in x.items():
            if not isinstance(val, Real):
                continue
            fval = float(val)
            if not math.isfinite(fval):
                continue
            if feat not in self.mins or fval < self.mins[feat]:
                self.mins[feat] = fval
            if feat not in self.maxs or fval > self.maxs[feat]:
                self.maxs[feat] = fval
        return self

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        transformed_x = {}
        for feat, val in x.items():
            if not isinstance(val, Real):
                transformed_x[feat] = val
                continue
            fval = float(val)
            if not math.isfinite(fval):
                transformed_x[feat] = val
                continue
            if feat in self.mins and feat in self.maxs:
                denom = self.maxs[feat] - self.mins[feat]
                if denom > 0:
                    transformed_x[feat] = (fval - self.mins[feat]) / denom
                else:
                    transformed_x[feat] = 0.5
            else:
                transformed_x[feat] = fval
        return transformed_x

    def clear(self) -> None:
        self.mins = {}
        self.maxs = {}
