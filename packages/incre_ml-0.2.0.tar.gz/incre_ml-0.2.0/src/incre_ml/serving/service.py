from typing import Any


class PredictService:
    """A lightweight service wrapper for model serving."""

    def __init__(self, model: Any) -> None:
        if model is None:
            raise ValueError("model must not be None")
        self.model = model

    def predict(self, x: dict[str, Any]) -> dict[str, Any]:
        """Generate a prediction and explanation."""
        if not isinstance(x, dict):
            raise TypeError("x must be a dictionary of features")
        y_pred = None
        if hasattr(self.model, "predict_one"):
            y_pred = self.model.predict_one(x)
        else:
            raise TypeError(
                "model must implement predict_one for PredictService.predict"
            )

        expl = {}
        if hasattr(self.model, "explain_one"):
            expl = self.model.explain_one(x)
            if not isinstance(expl, dict):
                expl = {}

        return {"prediction": y_pred, "explanation": expl}

    def update(self, x: dict[str, Any], y: float) -> None:
        """Update the model state."""
        if not isinstance(x, dict):
            raise TypeError("x must be a dictionary of features")
        if not hasattr(self.model, "learn_one"):
            raise TypeError("model must implement learn_one for PredictService.update")
        self.model.learn_one(x, y)
