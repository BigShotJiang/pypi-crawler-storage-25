import math
from typing import Any

from .base import Metric


class Accuracy(Metric):
    """Cumulative Accuracy score."""

    def __init__(self) -> None:
        self.correct = 0
        self.n = 0

    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "Accuracy":
        if y_true == y_pred:
            self.correct += 1
        self.n += 1
        return self

    def get(self) -> float:
        return self.correct / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.correct = 0
        self.n = 0


class Precision(Metric):
    """Precision for binary classification (assuming class 1)."""

    def __init__(self, pos_label: str | int = 1) -> None:
        self.pos_label = pos_label
        self.tp = 0
        self.fp = 0

    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "Precision":
        if y_pred == self.pos_label:
            if y_true == self.pos_label:
                self.tp += 1
            else:
                self.fp += 1
        return self

    def get(self) -> float:
        total = self.tp + self.fp
        return self.tp / total if total > 0 else 0.0

    def clear(self) -> None:
        self.tp = 0
        self.fp = 0


class Recall(Metric):
    """Recall for binary classification (assuming class 1)."""

    def __init__(self, pos_label: str | int = 1) -> None:
        self.pos_label = pos_label
        self.tp = 0
        self.fn = 0

    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "Recall":
        if y_true == self.pos_label:
            if y_pred == self.pos_label:
                self.tp += 1
            else:
                self.fn += 1
        return self

    def get(self) -> float:
        total = self.tp + self.fn
        return self.tp / total if total > 0 else 0.0

    def clear(self) -> None:
        self.tp = 0
        self.fn = 0


class F1(Metric):
    """F1 score for binary classification."""

    def __init__(self, pos_label: str | int = 1) -> None:
        self.precision = Precision(pos_label)
        self.recall = Recall(pos_label)

    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "F1":
        self.precision.update(y_true, y_pred)
        self.recall.update(y_true, y_pred)
        return self

    def get(self) -> float:
        p = self.precision.get()
        r = self.recall.get()
        if (p + r) == 0:
            return 0.0
        return 2 * (p * r) / (p + r)

    def clear(self) -> None:
        self.precision.clear()
        self.recall.clear()


class BrierScore(Metric):
    """Brier Score for binary probabilistic classification."""

    def __init__(self, pos_label: str | int = 1) -> None:
        self.pos_label = pos_label
        self.sum_sq_error = 0.0
        self.n = 0

    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "BrierScore":
        # y_proba should be in kwargs
        y_proba = float(kwargs.get("y_proba", 0.0))
        y_proba = min(max(y_proba, 0.0), 1.0)
        target = 1.0 if y_true == self.pos_label else 0.0
        self.sum_sq_error += (target - y_proba) ** 2
        self.n += 1
        return self

    def get(self) -> float:
        return self.sum_sq_error / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.sum_sq_error = 0.0
        self.n = 0


class LogLoss(Metric):
    """Logarithmic Loss for binary probabilistic classification."""

    def __init__(self, pos_label: str | int = 1, epsilon: float = 1e-15) -> None:
        self.pos_label = pos_label
        self.epsilon = epsilon
        self.sum_log_loss = 0.0
        self.n = 0

    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "LogLoss":
        y_proba = kwargs.get("y_proba", 0.5)
        # Clip probability to avoid log(0)
        p = min(max(y_proba, self.epsilon), 1.0 - self.epsilon)
        target = 1.0 if y_true == self.pos_label else 0.0
        self.sum_log_loss -= target * math.log(p) + (1.0 - target) * math.log(1.0 - p)
        self.n += 1
        return self

    def get(self) -> float:
        return self.sum_log_loss / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.sum_log_loss = 0.0
        self.n = 0


class BalancedAccuracy(Metric):
    """Balanced Accuracy score for binary classification."""

    def __init__(self, pos_label: str | int = 1) -> None:
        self.pos_label = pos_label
        self.recall_pos = Recall(pos_label)
        # For recall_neg, we assume binary and just flip label logic
        # Simplified for v1: just track both recalls
        self.tp = 0
        self.fn = 0
        self.tn = 0
        self.fp = 0

    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "BalancedAccuracy":
        if y_true == self.pos_label:
            if y_pred == self.pos_label:
                self.tp += 1
            else:
                self.fn += 1
        elif y_pred != self.pos_label:
            self.tn += 1
        else:
            self.fp += 1
        return self

    def get(self) -> float:
        tpr = self.tp / (self.tp + self.fn) if (self.tp + self.fn) > 0 else 0.0
        tnr = self.tn / (self.tn + self.fp) if (self.tn + self.fp) > 0 else 0.0
        return (tpr + tnr) / 2.0

    def clear(self) -> None:
        self.tp = 0
        self.fn = 0
        self.tn = 0
        self.fp = 0


class ROCAUC(Metric):
    """Online ROC-AUC using the Mann-Whitney U statistic.

    Maintains running counts for concordant, discordant, and tied pairs.
    Requires y_proba in kwargs for probability scores.
    """

    def __init__(self, pos_label: str | int = 1) -> None:
        self.pos_label = pos_label
        self._pos_scores: list[float] = []
        self._neg_scores: list[float] = []

    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "ROCAUC":
        y_proba = float(kwargs.get("y_proba", 0.0))
        if y_true == self.pos_label:
            self._pos_scores.append(y_proba)
        else:
            self._neg_scores.append(y_proba)
        return self

    def get(self) -> float:
        n_pos = len(self._pos_scores)
        n_neg = len(self._neg_scores)
        if n_pos == 0 or n_neg == 0:
            return 0.5

        # Mann-Whitney U statistic
        concordant = 0
        tied = 0
        for ps in self._pos_scores:
            for ns in self._neg_scores:
                if ps > ns:
                    concordant += 1
                elif ps == ns:
                    tied += 1

        return (concordant + 0.5 * tied) / (n_pos * n_neg)

    def clear(self) -> None:
        self._pos_scores = []
        self._neg_scores = []
