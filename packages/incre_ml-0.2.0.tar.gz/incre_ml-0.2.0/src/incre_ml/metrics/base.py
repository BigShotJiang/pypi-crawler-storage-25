from abc import ABC, abstractmethod
from typing import Any


class Metric(ABC):
    """Base class for all online metrics."""

    @abstractmethod
    def update(self, y_true: Any, y_pred: Any, **kwargs: Any) -> "Metric":
        """Update the metric with a new observation.

        Args:
            y_true: True target value.
            y_pred: Predicted target value.
            **kwargs: Additional information (e.g., sample weights).

        Returns:
            self
        """
        pass

    @abstractmethod
    def get(self) -> float:
        """Return the current value of the metric.

        Returns:
            Current metric value.
        """
        pass

    @abstractmethod
    def clear(self) -> None:
        """Reset the metric state."""
        pass
