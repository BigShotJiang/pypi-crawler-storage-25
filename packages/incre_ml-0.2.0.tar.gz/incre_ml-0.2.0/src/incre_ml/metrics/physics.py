from typing import Any

from .base import Metric


class ConstraintViolationRate(Metric):
    """Tracks how often predictions violate physics constraints.

    Records the fraction of predictions where the constraint
    violation is greater than zero (before correction).
    """

    def __init__(self) -> None:
        self._violations = 0
        self._total = 0

    def update(
        self, y_true: Any, y_pred: Any, **kwargs: Any
    ) -> "ConstraintViolationRate":
        violation = float(kwargs.get("violation", 0.0))
        self._total += 1
        if violation > 0:
            self._violations += 1
        return self

    def get(self) -> float:
        if self._total == 0:
            return 0.0
        return self._violations / self._total

    def clear(self) -> None:
        self._violations = 0
        self._total = 0
