import math
from typing import Any

from .base import Metric


class MAE(Metric):
    """Mean Absolute Error."""

    def __init__(self) -> None:
        self.sum_abs_error = 0.0
        self.n = 0

    def update(self, y_true: float, y_pred: float, **kwargs: Any) -> "MAE":
        self.sum_abs_error += abs(y_true - y_pred)
        self.n += 1
        return self

    def get(self) -> float:
        return self.sum_abs_error / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.sum_abs_error = 0.0
        self.n = 0


class MSE(Metric):
    """Mean Squared Error."""

    def __init__(self) -> None:
        self.sum_sq_error = 0.0
        self.n = 0

    def update(self, y_true: float, y_pred: float, **kwargs: Any) -> "MSE":
        self.sum_sq_error += (y_true - y_pred) ** 2
        self.n += 1
        return self

    def get(self) -> float:
        return self.sum_sq_error / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.sum_sq_error = 0.0
        self.n = 0


class RMSE(MSE):
    """Root Mean Squared Error."""

    def get(self) -> float:
        mse = super().get()
        return math.sqrt(mse)


class MAPE(Metric):
    """Mean Absolute Percentage Error (zero-safe)."""

    def __init__(self, epsilon: float = 1e-10) -> None:
        if epsilon <= 0.0:
            raise ValueError("epsilon must be > 0")
        self.sum_ape = 0.0
        self.n = 0
        self.epsilon = epsilon

    def update(self, y_true: float, y_pred: float, **kwargs: Any) -> "MAPE":
        self.sum_ape += abs((y_true - y_pred) / (abs(y_true) + self.epsilon))
        self.n += 1
        return self

    def get(self) -> float:
        return self.sum_ape / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.sum_ape = 0.0
        self.n = 0


class SMAPE(Metric):
    """Symmetric Mean Absolute Percentage Error."""

    def __init__(self) -> None:
        self.sum_sape = 0.0
        self.n = 0

    def update(self, y_true: float, y_pred: float, **kwargs: Any) -> "SMAPE":
        denominator = (abs(y_true) + abs(y_pred)) / 2.0
        if denominator > 0:
            self.sum_sape += abs(y_true - y_pred) / denominator
        self.n += 1
        return self

    def get(self) -> float:
        return self.sum_sape / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.sum_sape = 0.0
        self.n = 0


class CoverageError(Metric):
    """Absolute prediction interval coverage error.

    Computes ``|target_coverage - observed_coverage|`` where observed coverage is the
    percentage of truths that fall within the predicted interval.
    """

    def __init__(self, target_coverage: float = 0.95) -> None:
        self.covered = 0
        self.n = 0
        self.target_coverage = float(max(0.0, min(1.0, target_coverage)))

    def update(self, y_true: float, y_pred: float, **kwargs: Any) -> "CoverageError":
        interval = kwargs.get("interval")
        if interval:
            lower, upper = interval
            if lower > upper:
                lower, upper = upper, lower
            if lower <= y_true <= upper:
                self.covered += 1
        self.n += 1
        return self

    def get(self) -> float:
        return abs(self.target_coverage - self.coverage_probability)

    @property
    def coverage_probability(self) -> float:
        return self.covered / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.covered = 0
        self.n = 0


class CoverageProbability(Metric):
    """Prediction Interval Coverage Probability (PICP)."""

    def __init__(self) -> None:
        self.covered = 0
        self.n = 0

    def update(
        self, y_true: float, y_pred: float, **kwargs: Any
    ) -> "CoverageProbability":
        interval = kwargs.get("interval")
        if interval:
            lower, upper = interval
            if lower > upper:
                lower, upper = upper, lower
            if lower <= y_true <= upper:
                self.covered += 1
        self.n += 1
        return self

    def get(self) -> float:
        return self.covered / self.n if self.n > 0 else 0.0

    def clear(self) -> None:
        self.covered = 0
        self.n = 0
