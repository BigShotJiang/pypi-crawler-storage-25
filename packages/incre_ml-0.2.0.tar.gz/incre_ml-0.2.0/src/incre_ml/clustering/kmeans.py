import math
from typing import Any

from ..base.clusterer import Clusterer


class OnlineKMeans(Clusterer):
    """Online K-Means clustering.

    Maintains k centroids and updates the nearest one incrementally
    on each observation.
    """

    def __init__(self, k: int = 3, seed: int | None = None) -> None:
        if k <= 0:
            raise ValueError("k must be > 0")
        self.k = k
        self.centroids: list[dict[str, float]] = []
        self._counts: list[int] = []
        self._initialized = False

    def _distance(self, a: dict[str, float], b: dict[str, Any]) -> float:
        """Squared Euclidean distance between two feature dicts."""
        keys = set(a.keys()) | set(b.keys())
        dist = 0.0
        for key in keys:
            va = float(a.get(key, 0.0))
            vb = float(b.get(key, 0.0))
            dist += (va - vb) ** 2
        return dist

    def _nearest_centroid(self, x: dict[str, Any]) -> int:
        best_idx = 0
        best_dist = float("inf")
        for i, c in enumerate(self.centroids):
            d = self._distance(c, x)
            if d < best_dist:
                best_dist = d
                best_idx = i
        return best_idx

    def learn_one(self, x: dict[str, Any]) -> "OnlineKMeans":
        # Initialization phase: collect first k distinct points
        if not self._initialized:
            fx: dict[str, float] = {
                k: float(v) for k, v in x.items() if isinstance(v, int | float)
            }
            self.centroids.append(fx)
            self._counts.append(1)
            if len(self.centroids) >= self.k:
                self._initialized = True
            return self

        # Find nearest centroid and update it
        idx = self._nearest_centroid(x)
        self._counts[idx] += 1
        n = self._counts[idx]
        centroid = self.centroids[idx]

        # Incremental mean update
        all_keys = set(centroid.keys()) | set(x.keys())
        for key in all_keys:
            old_val = centroid.get(key, 0.0)
            new_val = float(x.get(key, 0.0))
            centroid[key] = old_val + (new_val - old_val) / n

        return self

    def predict_one(self, x: dict[str, Any]) -> int:
        if not self.centroids:
            return 0
        return self._nearest_centroid(x)

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        result: dict[str, float] = {}
        for i, c in enumerate(self.centroids):
            result[f"distance_to_cluster_{i}"] = math.sqrt(
                max(0.0, self._distance(c, x))
            )
        return result

    def clear(self) -> None:
        self.centroids = []
        self._counts = []
        self._initialized = False
