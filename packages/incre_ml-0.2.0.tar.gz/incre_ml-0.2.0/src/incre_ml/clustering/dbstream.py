import math
from typing import Any

from ..base.clusterer import Clusterer


class _MicroCluster:
    """A micro-cluster with center, weight, and timestamp."""

    def __init__(self, center: dict[str, float], time: int) -> None:
        self.center = center
        self.weight = 1.0
        self.last_update = time

    def update(self, x: dict[str, Any], time: int) -> None:
        """Incrementally update center toward new point."""
        self.weight += 1.0
        self.last_update = time
        for key in set(self.center.keys()) | set(x.keys()):
            old_val = self.center.get(key, 0.0)
            new_val = float(x.get(key, 0.0))
            self.center[key] = old_val + (new_val - old_val) / self.weight


class DBSTREAM(Clusterer):
    """Density-Based Stream clustering.

    Maintains micro-clusters with a radius threshold. Points within
    radius are absorbed; otherwise new micro-clusters are created.
    Decays old micro-clusters over time.
    """

    def __init__(
        self,
        radius: float = 1.0,
        decay_factor: float = 0.01,
        min_weight: float = 0.5,
        cleanup_interval: int = 100,
    ) -> None:
        if radius <= 0:
            raise ValueError("radius must be > 0")
        if not (0.0 < decay_factor < 1.0):
            raise ValueError("decay_factor must be in (0, 1)")
        self.radius = radius
        self.decay_factor = decay_factor
        self.min_weight = min_weight
        self.cleanup_interval = cleanup_interval
        self.micro_clusters: list[_MicroCluster] = []
        self._time = 0

    def _distance(self, a: dict[str, float], b: dict[str, Any]) -> float:
        keys = set(a.keys()) | set(b.keys())
        dist = 0.0
        for key in keys:
            va = float(a.get(key, 0.0))
            vb = float(b.get(key, 0.0))
            dist += (va - vb) ** 2
        return math.sqrt(dist)

    def _nearest_micro_cluster(self, x: dict[str, Any]) -> tuple[int, float]:
        best_idx = -1
        best_dist = float("inf")
        for i, mc in enumerate(self.micro_clusters):
            d = self._distance(mc.center, x)
            if d < best_dist:
                best_dist = d
                best_idx = i
        return best_idx, best_dist

    def _decay(self) -> None:
        """Apply time-based decay to all micro-clusters."""
        for mc in self.micro_clusters:
            mc.weight *= 1.0 - self.decay_factor

    def _cleanup(self) -> None:
        """Remove micro-clusters with weight below threshold."""
        self.micro_clusters = [
            mc for mc in self.micro_clusters if mc.weight >= self.min_weight
        ]

    def learn_one(self, x: dict[str, Any]) -> "DBSTREAM":
        self._time += 1

        # Apply decay
        self._decay()

        if not self.micro_clusters:
            fx: dict[str, float] = {
                k: float(v) for k, v in x.items() if isinstance(v, int | float)
            }
            self.micro_clusters.append(_MicroCluster(fx, self._time))
            return self

        idx, dist = self._nearest_micro_cluster(x)

        if dist <= self.radius:
            self.micro_clusters[idx].update(x, self._time)
        else:
            fx = {k: float(v) for k, v in x.items() if isinstance(v, int | float)}
            self.micro_clusters.append(_MicroCluster(fx, self._time))

        if self._time % self.cleanup_interval == 0:
            self._cleanup()

        return self

    def predict_one(self, x: dict[str, Any]) -> int:
        if not self.micro_clusters:
            return 0
        idx, _ = self._nearest_micro_cluster(x)
        return idx

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        result: dict[str, float] = {}
        for i, mc in enumerate(self.micro_clusters):
            result[f"distance_to_mc_{i}"] = self._distance(mc.center, x)
            result[f"weight_mc_{i}"] = mc.weight
        return result

    def clear(self) -> None:
        self.micro_clusters = []
        self._time = 0
