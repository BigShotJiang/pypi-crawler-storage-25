from typing import Any

from ..base import Regressor
from ..base.federated import FederatedModel


class LinearRegression(Regressor, FederatedModel):
    """Linear Regression using Stochastic Gradient Descent (SGD).

    This model updates its weights with each observation using a
    specified learning rate.
    """

    def __init__(self, learning_rate: float = 0.01, intercept: bool = True) -> None:
        self.learning_rate = learning_rate
        self.intercept = intercept

        self.weights: dict[str, float] = {}
        self.intercept_weight = 0.0

    def predict_one(self, x: dict[str, Any]) -> float:
        y_pred = self.intercept_weight if self.intercept else 0.0

        for key, value in x.items():
            y_pred += self.weights.get(key, 0.0) * value

        return y_pred

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = {}
        if self.intercept:
            expl["intercept"] = self.intercept_weight
        for key, value in x.items():
            expl[key] = self.weights.get(key, 0.0) * value
        return expl

    def learn_one(self, x: dict[str, Any], y: float) -> "LinearRegression":
        y_pred = self.predict_one(x)
        error = y - y_pred

        # Update weights
        for key, value in x.items():
            if key not in self.weights:
                self.weights[key] = 0.0
            self.weights[key] += self.learning_rate * error * value

        if self.intercept:
            self.intercept_weight += self.learning_rate * error

        return self

    def clear(self) -> None:
        self.weights = {}
        self.intercept_weight = 0.0

    def get_weights(self) -> dict[str, Any]:
        return {
            "weights": self.weights.copy(),
            "intercept_weight": self.intercept_weight,
        }

    def set_weights(self, weights: dict[str, Any]) -> None:
        self.weights = weights["weights"].copy()
        self.intercept_weight = weights["intercept_weight"]
