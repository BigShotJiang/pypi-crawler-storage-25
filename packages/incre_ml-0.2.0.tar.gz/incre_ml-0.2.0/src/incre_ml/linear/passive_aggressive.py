from typing import Any

from ..base import Regressor


class PassiveAggressiveRegressor(Regressor):
    """Passive-Aggressive Regressor for online regression.

    A margin-based online algorithm that updates its weights only
    when the prediction error exceeds a certain threshold (epsilon).
    """

    def __init__(
        self, c_param: float = 1.0, epsilon: float = 0.1, intercept: bool = True
    ) -> None:
        self.c_param = c_param
        self.epsilon = epsilon
        self.intercept = intercept

        self.weights: dict[str, float] = {}
        self.intercept_weight = 0.0

    def predict_one(self, x: dict[str, Any]) -> float:
        y_pred = self.intercept_weight if self.intercept else 0.0

        for key, value in x.items():
            y_pred += self.weights.get(key, 0.0) * value

        return y_pred

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        expl = {}
        if self.intercept:
            expl["intercept"] = self.intercept_weight
        for key, value in x.items():
            expl[key] = self.weights.get(key, 0.0) * value
        return expl

    def learn_one(self, x: dict[str, Any], y: float) -> "PassiveAggressiveRegressor":
        y_pred = self.predict_one(x)
        error = y - y_pred
        abs_error = abs(error)

        if abs_error <= self.epsilon:
            return self

        # Calculate step size
        squared_norm = sum(v**2 for v in x.values())
        if self.intercept:
            squared_norm += 1.0

        if squared_norm == 0:
            return self

        tau = min(self.c_param, (abs_error - self.epsilon) / squared_norm)
        step = tau * (1 if error > 0 else -1)

        # Update weights
        for key, value in x.items():
            if key not in self.weights:
                self.weights[key] = 0.0
            self.weights[key] += step * value

        if self.intercept:
            self.intercept_weight += step

        return self

    def clear(self) -> None:
        self.weights = {}
        self.intercept_weight = 0.0
