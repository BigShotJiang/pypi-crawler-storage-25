from ..base.regressor import Regressor
from .bagging import OzaBagging
from .boosting import OzaBoost
from .pipeline import Pipeline
from .stacking import StackingClassifier, StackingRegressor
from .tournament import ModelTournament
from .transformers import ColumnTransformer, FeatureUnion
from .wrappers import AlertSuppressionWrapper


class ChampionChallenger(ModelTournament):
    """Backward-compatible two-model champion/challenger via ``ModelTournament``."""

    def __init__(
        self,
        champion: Regressor,
        challenger: Regressor,
        **kwargs: object,
    ) -> None:
        super().__init__(
            models={"champion": champion, "challenger": challenger},
            **kwargs,  # type: ignore[arg-type]
        )


__all__ = [
    "Pipeline",
    "FeatureUnion",
    "ColumnTransformer",
    "ModelTournament",
    "ChampionChallenger",
    "AlertSuppressionWrapper",
    "OzaBagging",
    "OzaBoost",
    "StackingRegressor",
    "StackingClassifier",
]
