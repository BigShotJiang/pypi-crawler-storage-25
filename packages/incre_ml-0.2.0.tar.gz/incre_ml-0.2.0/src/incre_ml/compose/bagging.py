import math
import random
from typing import Any

from ..base.classifier import Classifier


class OzaBagging(Classifier):
    """Online Bagging (Oza & Russell, 2001).

    Wraps n base classifiers with Poisson(1) resampling per sample.
    Prediction via majority vote.
    """

    def __init__(
        self, base_classifiers: list[Classifier], seed: int | None = None
    ) -> None:
        if not base_classifiers:
            raise ValueError("Must provide at least one base classifier")
        self.base_classifiers = base_classifiers
        self._rng = random.Random(seed)

    def learn_one(self, x: dict[str, Any], y: str | int) -> "OzaBagging":
        for clf in self.base_classifiers:
            # Poisson(1) resampling
            k = self._poisson(1.0)
            for _ in range(k):
                clf.learn_one(x, y)
        return self

    def _poisson(self, lam: float) -> int:
        """Generate a Poisson-distributed random number."""
        l_val = math.exp(-lam)
        k = 0
        p = 1.0
        while True:
            k += 1
            p *= self._rng.random()
            if p <= l_val:
                break
        return k - 1

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        combined: dict[str | int, float] = {}
        n = len(self.base_classifiers)
        for clf in self.base_classifiers:
            probas = clf.predict_proba_one(x)
            for label, prob in probas.items():
                combined[label] = combined.get(label, 0.0) + prob / n
        return combined

    def predict_one(self, x: dict[str, Any]) -> str | int:
        votes: dict[str | int, int] = {}
        for clf in self.base_classifiers:
            pred = clf.predict_one(x)
            if pred != "":
                votes[pred] = votes.get(pred, 0) + 1
        if not votes:
            return ""
        return max(votes, key=lambda k: votes[k])

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        result: dict[str, float] = {}
        for i, clf in enumerate(self.base_classifiers):
            expl = clf.explain_one(x)
            for feat, val in expl.items():
                key = f"clf_{i}_{feat}"
                result[key] = val
        return result

    def clear(self) -> None:
        for clf in self.base_classifiers:
            clf.clear()
