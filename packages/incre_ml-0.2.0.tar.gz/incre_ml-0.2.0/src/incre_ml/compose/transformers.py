from typing import Any

from ..base.transformer import Transformer


class FeatureUnion(Transformer):
    """Concatenates results of multiple transformer objects."""

    def __init__(self, transformers: list[Transformer]) -> None:
        if not transformers:
            raise ValueError("FeatureUnion requires at least one transformer")
        self.transformers = transformers

    def learn_one(self, x: dict[str, Any], y: Any | None = None) -> "FeatureUnion":
        for trans in self.transformers:
            trans.learn_one(x, y)
        return self

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        x_transformed = {}
        for trans in self.transformers:
            x_transformed.update(trans.transform_one(x))
        return x_transformed

    def clear(self) -> None:
        for trans in self.transformers:
            trans.clear()


class ColumnTransformer(Transformer):
    """Applies transformers to specific columns."""

    def __init__(self, transformers: list[tuple[str, Transformer, list[str]]]) -> None:
        """
        Args:
            transformers: List of (name, transformer, columns) tuples.
        """
        if not transformers:
            raise ValueError("ColumnTransformer requires at least one transformer spec")
        self.transformers = transformers

    def learn_one(self, x: dict[str, Any], y: Any | None = None) -> "ColumnTransformer":
        for _, trans, cols in self.transformers:
            # Filter x to only include relevant columns
            x_filtered = {c: x[c] for c in cols if c in x}
            trans.learn_one(x_filtered, y)
        return self

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        x_transformed = x.copy()
        for _, trans, cols in self.transformers:
            x_filtered = {c: x[c] for c in cols if c in x}
            res = trans.transform_one(x_filtered)
            x_transformed.update(res)
        return x_transformed

    def clear(self) -> None:
        for _, trans, _ in self.transformers:
            trans.clear()
