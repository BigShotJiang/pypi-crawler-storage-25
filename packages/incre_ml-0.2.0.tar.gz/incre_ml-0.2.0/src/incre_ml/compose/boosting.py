import math
import random
from typing import Any

from ..base.classifier import Classifier


class OzaBoost(Classifier):
    """Online AdaBoost (Oza & Russell, 2001).

    Wraps n base classifiers with adaptive weighting.
    Each classifier's weight is adjusted based on its error rate.
    """

    def __init__(
        self, base_classifiers: list[Classifier], seed: int | None = None
    ) -> None:
        if not base_classifiers:
            raise ValueError("Must provide at least one base classifier")
        self.base_classifiers = base_classifiers
        self._n = len(base_classifiers)
        self._lambda_correct: list[float] = [1.0] * self._n
        self._lambda_wrong: list[float] = [1.0] * self._n
        self._epsilon: list[float] = [0.5] * self._n
        self._rng = random.Random(seed)

    def _poisson(self, lam: float) -> int:
        """Generate a Poisson-distributed random number."""
        if lam <= 0:
            return 0
        l_val = math.exp(-min(lam, 500))
        k = 0
        p = 1.0
        while True:
            k += 1
            p *= self._rng.random()
            if p <= l_val:
                break
        return k - 1

    def learn_one(self, x: dict[str, Any], y: str | int) -> "OzaBoost":
        lam = 1.0
        for i, clf in enumerate(self.base_classifiers):
            k = self._poisson(lam)
            for _ in range(k):
                clf.learn_one(x, y)

            pred = clf.predict_one(x)
            if pred == y:
                self._lambda_correct[i] += lam
                epsilon = self._lambda_wrong[i] / (
                    self._lambda_correct[i] + self._lambda_wrong[i]
                )
                self._epsilon[i] = epsilon
                if epsilon > 0:
                    lam *= 1.0 / (2.0 * (1.0 - epsilon))
            else:
                self._lambda_wrong[i] += lam
                epsilon = self._lambda_wrong[i] / (
                    self._lambda_correct[i] + self._lambda_wrong[i]
                )
                self._epsilon[i] = epsilon
                if epsilon < 1.0:
                    lam *= 1.0 / (2.0 * epsilon)
        return self

    def _classifier_weight(self, i: int) -> float:
        """Log-odds weight for classifier i."""
        eps = max(self._epsilon[i], 1e-10)
        eps = min(eps, 1.0 - 1e-10)
        return math.log((1.0 - eps) / eps)

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        combined: dict[str | int, float] = {}
        total_weight = 0.0
        for i, clf in enumerate(self.base_classifiers):
            w = self._classifier_weight(i)
            total_weight += w
            probas = clf.predict_proba_one(x)
            for label, prob in probas.items():
                combined[label] = combined.get(label, 0.0) + prob * w
        if total_weight > 0:
            combined = {k: v / total_weight for k, v in combined.items()}
        return combined

    def predict_one(self, x: dict[str, Any]) -> str | int:
        weighted_votes: dict[str | int, float] = {}
        for i, clf in enumerate(self.base_classifiers):
            w = self._classifier_weight(i)
            pred = clf.predict_one(x)
            if pred != "":
                weighted_votes[pred] = weighted_votes.get(pred, 0.0) + w
        if not weighted_votes:
            return ""
        return max(weighted_votes, key=lambda k: weighted_votes[k])

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        result: dict[str, float] = {}
        for i, _clf in enumerate(self.base_classifiers):
            w = self._classifier_weight(i)
            result[f"clf_{i}_weight"] = w
        return result

    def clear(self) -> None:
        for clf in self.base_classifiers:
            clf.clear()
        self._lambda_correct = [1.0] * self._n
        self._lambda_wrong = [1.0] * self._n
        self._epsilon = [0.5] * self._n
