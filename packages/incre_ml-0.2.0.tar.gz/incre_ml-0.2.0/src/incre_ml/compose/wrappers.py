from typing import Any

from ..base.anomaly import Detector


class AlertSuppressionWrapper(Detector):
    """Meta-wrapper that suppresses repeated alerts within a cooldown window.

    After an alert fires (score > ``alert_threshold``), the wrapper returns 0.0
    for the next ``window_size`` observations.  This prevents alert storms when a
    real anomaly persists for multiple steps.

    Args:
        detector: Any ``Detector`` to wrap.
        window_size: Number of observations to suppress after an alert.
        alert_threshold: Score value above which suppression is triggered.
    """

    def __init__(
        self,
        detector: Detector,
        window_size: int = 10,
        alert_threshold: float = 0.5,
    ) -> None:
        if window_size < 0:
            raise ValueError("window_size must be >= 0")
        if not (0.0 <= alert_threshold <= 1.0):
            raise ValueError("alert_threshold must be in [0, 1]")
        self.detector = detector
        self.window_size = int(window_size)
        self.alert_threshold = float(alert_threshold)
        self.countdown = 0

    def score_one(self, x: dict[str, Any]) -> float:
        score = self.detector.score_one(x)
        if self.countdown > 0:
            self.countdown -= 1
            return 0.0
        if score > self.alert_threshold:
            self.countdown = self.window_size
        return score

    def learn_one(
        self, x: dict[str, Any], y: float | None = None
    ) -> "AlertSuppressionWrapper":
        if y is not None:
            try:
                self.detector.learn_one(x, y)  # type: ignore[call-arg]
            except TypeError:
                self.detector.learn_one(x)
        else:
            self.detector.learn_one(x)
        return self

    def clear(self) -> None:
        self.detector.clear()
        self.countdown = 0
