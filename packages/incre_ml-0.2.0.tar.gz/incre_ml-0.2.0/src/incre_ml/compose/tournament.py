from collections import deque
from typing import Any, Literal

from ..base.regressor import Regressor
from ..metrics.regression import MAE


class ModelTournament(Regressor):
    """N-way champion-challenger tournament for online regression models.

    Maintains a pool of N candidate models.  At each step the model with the
    lowest rolling-window (or cumulative) MAE is used for external predictions.
    A configurable promotion policy decides when a challenger may replace the
    reigning champion.

    Args:
        models: Named dict of candidate regressors.  The first entry is treated
            as the initial champion.
        window_size: Number of recent observations to use for performance
            tracking.  0 means cumulative MAE (no window).
        promotion_policy: ``"never"`` — manual only; ``"auto"`` — the challenger
            with the lowest windowed MAE becomes champion immediately; ``"streak"``
            — a non-champion must beat the champion for `promotion_streak`
            consecutive steps to be promoted.
        promotion_streak: Steps a challenger must consecutively outperform the
            champion before being auto-promoted (only used when
            ``promotion_policy="streak"``).
    """

    def __init__(
        self,
        models: dict[str, Regressor],
        window_size: int = 50,
        promotion_policy: Literal["never", "auto", "streak"] = "streak",
        promotion_streak: int = 20,
    ) -> None:
        if not models:
            raise ValueError("models must not be empty")
        if window_size < 0:
            raise ValueError("window_size must be >= 0")
        if promotion_streak <= 0:
            raise ValueError("promotion_streak must be > 0")

        self.models = models
        self.window_size = int(window_size)
        self.promotion_policy = promotion_policy
        self.promotion_streak = int(promotion_streak)

        # Champion is the first model by insertion order
        self.champion_name: str = next(iter(models))

        # Per-model rolling MAE buffers
        self._windows: dict[str, deque[float]] = {
            name: deque(maxlen=window_size) if window_size > 0 else deque()
            for name in models
        }
        self._cumulative_mae: dict[str, MAE] = {name: MAE() for name in models}

        # Streak counters for promotion_policy="streak"
        self._streak: dict[str, int] = {name: 0 for name in models}

        # Cache of last predictions (set in predict_one, consumed in learn_one)
        self._last_preds: dict[str, float] = {}

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _mae(self, name: str) -> float:
        if self.window_size > 0:
            buf = self._windows[name]
            return sum(buf) / len(buf) if buf else float("inf")
        return self._cumulative_mae[name].get()

    def _best_name(self) -> str:
        return min(self.models.keys(), key=self._mae)

    def _update_promotion(self, y: float) -> None:
        """Update streak counters and apply promotion policy."""
        if self.promotion_policy == "never":
            return

        best = self._best_name()

        if self.promotion_policy == "auto":
            self.champion_name = best
            return

        # streak mode
        for name in self.models:
            if name == self.champion_name:
                self._streak[name] = 0
                continue
            if self._mae(name) < self._mae(self.champion_name):
                self._streak[name] += 1
                if self._streak[name] >= self.promotion_streak:
                    self.champion_name = name
                    # Reset all streaks
                    for k in self._streak:
                        self._streak[k] = 0
            else:
                self._streak[name] = 0

    # ------------------------------------------------------------------
    # Regressor API
    # ------------------------------------------------------------------

    def learn_one(self, x: dict[str, Any], y: float) -> "ModelTournament":
        # Update performance metrics using predictions cached in predict_one.
        for name, pred in self._last_preds.items():
            ae = abs(y - pred)
            self._cumulative_mae[name].update(y, pred)
            if self.window_size > 0:
                self._windows[name].append(ae)

        self._update_promotion(y)

        for model in self.models.values():
            model.learn_one(x, y)

        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        self._last_preds = {
            name: model.predict_one(x) for name, model in self.models.items()
        }
        return self._last_preds[self.champion_name]

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return self.models[self.champion_name].explain_one(x)

    def clear(self) -> None:
        for model in self.models.values():
            model.clear()
        for mae in self._cumulative_mae.values():
            mae.clear()
        for buf in self._windows.values():
            buf.clear()
        for name in self._streak:
            self._streak[name] = 0
        self._last_preds = {}
        self.champion_name = next(iter(self.models))

    # ------------------------------------------------------------------
    # Introspection
    # ------------------------------------------------------------------

    @property
    def summary(self) -> dict[str, Any]:
        """Return per-model MAE keyed as ``{name}_mae``.

        This format is intentionally backward-compatible with the old
        binary ``ChampionChallenger`` which returned ``champion_mae`` and
        ``challenger_mae`` keys.  The current champion can be read via
        ``self.champion_name``.
        """
        return {f"{name}_mae": self._mae(name) for name in self.models}

    def force_promote(self, name: str) -> None:
        """Manually promote a model to champion regardless of performance."""
        if name not in self.models:
            raise ValueError(f"Unknown model: {name!r}")
        self.champion_name = name
        for k in self._streak:
            self._streak[k] = 0
