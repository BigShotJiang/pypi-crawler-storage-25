from typing import Any

from ..base.classifier import Classifier
from ..base.regressor import Regressor


class StackingRegressor:
    """Online stacking ensemble for regression.

    Base models produce predictions that are fed as features to a meta-learner.
    Uses prequential (out-of-fold) predictions to train the meta-learner.
    """

    def __init__(
        self,
        base_models: list[Regressor],
        meta_learner: Regressor,
        include_original: bool = True,
    ) -> None:
        if not base_models:
            raise ValueError("Must provide at least one base model")
        self.base_models = base_models
        self.meta_learner = meta_learner
        self.include_original = include_original

    def _meta_features(self, x: dict[str, Any]) -> dict[str, Any]:
        """Generate meta-features from base model predictions."""
        meta_x: dict[str, Any] = {}
        if self.include_original:
            meta_x.update(x)
        for i, model in enumerate(self.base_models):
            meta_x[f"base_{i}_pred"] = model.predict_one(x)
        return meta_x

    def learn_one(self, x: dict[str, Any], y: float) -> "StackingRegressor":
        # Get out-of-fold predictions (prequential: predict before train)
        meta_x = self._meta_features(x)

        # Train meta-learner on base predictions
        self.meta_learner.learn_one(meta_x, y)

        # Train all base models
        for model in self.base_models:
            model.learn_one(x, y)

        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        meta_x = self._meta_features(x)
        return self.meta_learner.predict_one(meta_x)

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        meta_x = self._meta_features(x)
        return self.meta_learner.explain_one(meta_x)

    def clear(self) -> None:
        for model in self.base_models:
            model.clear()
        self.meta_learner.clear()


class StackingClassifier:
    """Online stacking ensemble for classification.

    Base classifiers produce probability predictions that are fed as
    features to a meta-learner classifier.
    """

    def __init__(
        self,
        base_classifiers: list[Classifier],
        meta_learner: Classifier,
        include_original: bool = True,
    ) -> None:
        if not base_classifiers:
            raise ValueError("Must provide at least one base classifier")
        self.base_classifiers = base_classifiers
        self.meta_learner = meta_learner
        self.include_original = include_original

    def _meta_features(self, x: dict[str, Any]) -> dict[str, Any]:
        """Generate meta-features from base classifier predictions."""
        meta_x: dict[str, Any] = {}
        if self.include_original:
            meta_x.update(x)
        for i, clf in enumerate(self.base_classifiers):
            probas = clf.predict_proba_one(x)
            for label, prob in probas.items():
                meta_x[f"base_{i}_{label}"] = prob
        return meta_x

    def learn_one(self, x: dict[str, Any], y: str | int) -> "StackingClassifier":
        meta_x = self._meta_features(x)
        self.meta_learner.learn_one(meta_x, y)
        for clf in self.base_classifiers:
            clf.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> str | int:
        meta_x = self._meta_features(x)
        return self.meta_learner.predict_one(meta_x)

    def predict_proba_one(self, x: dict[str, Any]) -> dict[str | int, float]:
        meta_x = self._meta_features(x)
        return self.meta_learner.predict_proba_one(meta_x)

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        meta_x = self._meta_features(x)
        return self.meta_learner.explain_one(meta_x)

    def clear(self) -> None:
        for clf in self.base_classifiers:
            clf.clear()
        self.meta_learner.clear()
