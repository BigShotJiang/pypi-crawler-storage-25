from typing import Any

from ..base.anomaly import Detector
from ..base.classifier import Classifier
from ..base.regressor import Regressor
from ..base.transformer import Transformer


class Pipeline:
    """A pipeline for streaming data.

    Chains one or more transformers and an optional final predictor
    (regressor, classifier, or anomaly detector).
    """

    def __init__(self, steps: list[Transformer | Regressor | Classifier | Detector]):
        if not steps:
            raise ValueError("Pipeline requires at least one step")
        for idx, step in enumerate(steps[:-1]):
            if not isinstance(step, Transformer):
                raise ValueError(
                    f"All non-final steps must be transformers. "
                    f"Invalid step at index {idx}."
                )
        if not isinstance(steps[-1], Transformer | Regressor | Classifier | Detector):
            raise ValueError(
                "Final pipeline step must be a transformer, regressor, "
                "classifier, or detector."
            )
        self.steps = steps

    def learn_one(self, x: dict[str, Any], y: Any | None = None) -> "Pipeline":
        """Update each step in the pipeline.

        Args:
            x: Input features.
            y: Optional target label.

        Returns:
            self
        """
        x_transformed = x
        for step in self.steps:
            if isinstance(step, Transformer):
                step.learn_one(x_transformed, y)
                x_transformed = step.transform_one(x_transformed)
            elif isinstance(step, Regressor | Classifier):
                if y is not None:
                    step.learn_one(x_transformed, y)
            elif isinstance(step, Detector):
                if y is not None:
                    try:
                        step.learn_one(x_transformed, y=y)  # type: ignore[call-arg]
                    except TypeError:
                        step.learn_one(x_transformed)
                else:
                    step.learn_one(x_transformed)
        return self

    def predict_one(self, x: dict[str, Any]) -> Any:
        """Apply transformers and then predict using the final model."""
        x_transformed = x
        for step in self.steps[:-1]:
            if isinstance(step, Transformer):
                x_transformed = step.transform_one(x_transformed)

        final_step = self.steps[-1]
        if hasattr(final_step, "predict_one"):
            return final_step.predict_one(x_transformed)
        if isinstance(final_step, Transformer):
            return final_step.transform_one(x_transformed)
        return x_transformed

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        """Explain the final step after transformations."""
        x_transformed = x
        for step in self.steps[:-1]:
            if isinstance(step, Transformer):
                x_transformed = step.transform_one(x_transformed)

        final_step = self.steps[-1]
        if hasattr(final_step, "explain_one"):
            return final_step.explain_one(x_transformed)
        return {}

    def score_one(self, x: dict[str, Any]) -> float:
        """Apply transformers and then score using the final detector."""
        x_transformed = x
        for step in self.steps[:-1]:
            if isinstance(step, Transformer):
                x_transformed = step.transform_one(x_transformed)

        final_step = self.steps[-1]
        if hasattr(final_step, "score_one"):
            return final_step.score_one(x_transformed)
        return 0.0

    def transform_one(self, x: dict[str, Any]) -> dict[str, Any]:
        """Apply all transformer steps in the pipeline."""
        x_transformed = x
        for step in self.steps:
            if isinstance(step, Transformer):
                x_transformed = step.transform_one(x_transformed)
        return x_transformed

    def clear(self) -> None:
        """Reset all steps in the pipeline."""
        for step in self.steps:
            if hasattr(step, "clear"):
                step.clear()
