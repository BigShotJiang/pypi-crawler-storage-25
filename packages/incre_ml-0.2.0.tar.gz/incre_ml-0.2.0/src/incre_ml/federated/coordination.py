from .ensemble import FederatedEnsemble


class FederatedCoordinator:
    """Orchestrates multiple FederatedEnsembles across different sites/fleets."""

    def __init__(self, ensembles: list[FederatedEnsemble]) -> None:
        self.ensembles = ensembles

    def sync_all(self) -> None:
        """Triggers a global synchronization across all managed ensembles."""
        # 1. Sync local clients to global models
        for ensemble in self.ensembles:
            ensemble.sync()

        # 2. Then, aggregate all ensemble global models into one "Super-Global" model
        # (This would be Mission v3 advanced aggregation logic)
        # For v3.1, we ensure all local ensembles are synchronized.
        pass
