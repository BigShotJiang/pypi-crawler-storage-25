from typing import Any


class FederatedAveraging:
    """Aggregates weights from multiple FederatedModels using simple averaging."""

    @classmethod
    def aggregate(
        cls, model_weights: list[dict[str, Any]], weights: list[float] | None = None
    ) -> dict[str, Any]:
        """Aggregate multiple weight dictionaries into one.

        Args:
            model_weights: List of weight dictionaries from get_weights().
            weights: Optional list of importance weights for each model.

        Returns:
            Aggregated weight dictionary.
        """
        if not model_weights:
            return {}
        if weights is not None and len(weights) != len(model_weights):
            raise ValueError("weights length must match number of models")

        if weights is None:
            weights = [1.0 / len(model_weights)] * len(model_weights)
        else:
            weights = [float(w) for w in weights]
            if any(w < 0.0 for w in weights):
                raise ValueError("weights must be non-negative")

        # Normalize weights
        total_w = sum(weights)
        if total_w <= 0.0:
            raise ValueError("sum of weights must be > 0")
        norm_weights = [w / total_w for w in weights]

        # Identify all keys (assuming consistent structure)
        base_keys = model_weights[0].keys()
        for mw in model_weights[1:]:
            if mw.keys() != base_keys:
                raise ValueError(
                    "all model weight dictionaries must have identical top-level keys"
                )
        aggregated: dict[str, Any] = {}
        for key in base_keys:
            aggregated[key] = FederatedAveraging._aggregate_value(
                key, model_weights, norm_weights
            )
        return aggregated

    @staticmethod
    def _aggregate_value(
        key: str,
        model_weights: list[dict[str, Any]],
        norm_weights: list[float],
    ) -> Any:
        """Aggregate a single key across all model weight dicts."""
        first_val = model_weights[0][key]
        if isinstance(first_val, dict):
            return FederatedAveraging._aggregate_dict(
                [mw[key] for mw in model_weights], norm_weights
            )
        if isinstance(first_val, float | int):
            return sum(
                mw[key] * w for mw, w in zip(model_weights, norm_weights, strict=True)
            )
        if isinstance(first_val, set):
            agg_set: set[Any] = set()
            for mw in model_weights:
                agg_set.update(mw[key])
            return agg_set
        return first_val

    @staticmethod
    def _aggregate_dict(
        dicts: list[dict[str, float]], weights: list[float]
    ) -> dict[str, float]:
        """Aggregate nested dictionaries of feature weights."""
        all_keys: set[str] = set()
        for d in dicts:
            all_keys.update(d.keys())

        aggregated: dict[str, float] = {}
        for key in all_keys:
            val = 0.0
            for d, w in zip(dicts, weights, strict=True):
                val += d.get(key, 0.0) * w
            aggregated[key] = val
        return aggregated


class ReputationWeightedAggregation:
    """Weighted aggregation that down-weights clients with poor validation loss.

    Each client's contribution to the global model is proportional to its
    reputation score, which is derived from its recent validation MAE.  Clients
    with lower MAE receive higher weight.

    The reputation is updated online: each call to ``update_reputation``
    incorporates the latest local validation MAE with an exponential moving
    average controlled by ``alpha``.

    Args:
        n_clients: Number of federated clients.
        alpha: EMA smoothing factor for reputation updates.  Higher = more
            reactive to recent performance.
        epsilon: Floor on reputation to prevent any client being completely
            silenced on a single bad round.
    """

    def __init__(
        self,
        n_clients: int,
        alpha: float = 0.3,
        epsilon: float = 1e-6,
    ) -> None:
        if n_clients <= 0:
            raise ValueError("n_clients must be > 0")
        if not (0.0 < alpha <= 1.0):
            raise ValueError("alpha must be in (0, 1]")
        if epsilon <= 0.0:
            raise ValueError("epsilon must be > 0")
        self.n_clients = n_clients
        self.alpha = float(alpha)
        self.epsilon = float(epsilon)
        # Running EMA of validation MAE per client (initialised to 1.0)
        self._ema_mae: list[float] = [1.0] * n_clients

    def update_reputation(self, client_id: int, validation_mae: float) -> None:
        """Update the reputation of a single client after a local training round.

        Args:
            client_id: Zero-based index of the client.
            validation_mae: Client's local validation MAE for the latest round.
        """
        if not (0 <= client_id < self.n_clients):
            raise ValueError(
                f"client_id {client_id} out of range [0, {self.n_clients})"
            )
        if validation_mae < 0.0:
            raise ValueError("validation_mae must be >= 0")
        self._ema_mae[client_id] = (
            self.alpha * validation_mae + (1.0 - self.alpha) * self._ema_mae[client_id]
        )

    def _reputation_weights(self) -> list[float]:
        """Convert EMA-MAE values to inverse-MAE reputation weights."""
        inv = [1.0 / max(m, self.epsilon) for m in self._ema_mae]
        total = sum(inv)
        return [v / total for v in inv]

    def aggregate(self, model_weights: list[dict[str, Any]]) -> dict[str, Any]:
        """Aggregate model weights using reputation-derived client weights.

        Args:
            model_weights: Ordered list of weight dicts, one per client.

        Returns:
            Reputation-weighted aggregated weight dict.
        """
        if len(model_weights) != self.n_clients:
            raise ValueError(
                f"Expected {self.n_clients} model weight dicts, "
                f"got {len(model_weights)}"
            )
        rep_weights = self._reputation_weights()
        return FederatedAveraging.aggregate(model_weights, rep_weights)

    @property
    def reputations(self) -> list[float]:
        """Current reputation weight per client (sums to 1)."""
        return self._reputation_weights()

    def reset(self) -> None:
        """Reset all client reputations to uniform."""
        self._ema_mae = [1.0] * self.n_clients


class FedProxAggregation:
    """FedProx-style aggregation with proximal regularisation.

    FedProx (Li et al., 2020) adds a proximal term to each client's local
    objective:
        F_local(w) += (μ / 2) * ||w_local - w_global||²

    This penalises local models from drifting too far from the global model,
    which is critical when clients have heterogeneous (non-IID) data.

    In this online implementation, aggregation is standard weighted averaging
    (identical to ``FederatedAveraging``).  The proximal correction is applied
    **after** aggregation: client weights that deviate significantly from the
    global aggregated weights are pulled back toward the global model.

    The correction step computes:
        w_corrected = w_local - mu * (w_local - w_global)
                    = (1 - mu) * w_local + mu * w_global

    This is then re-aggregated, effectively shrinking outlier clients toward the
    consensus — the discrete-time analogue of the continuous FedProx penalty.

    Args:
        mu: Proximal coefficient.  0.0 = no proximal correction (reduces to
            FedAvg).  1.0 = all clients collapsed to global mean.
    """

    def __init__(self, mu: float = 0.1) -> None:
        if not (0.0 <= mu <= 1.0):
            raise ValueError("mu must be in [0, 1]")
        self.mu = float(mu)

    def aggregate(
        self,
        model_weights: list[dict[str, Any]],
        weights: list[float] | None = None,
    ) -> dict[str, Any]:
        """Aggregate with proximal correction.

        Args:
            model_weights: Weight dicts from each client.
            weights: Optional per-client importance weights (e.g., dataset size
                fractions).  Defaults to uniform.

        Returns:
            Proximal-corrected aggregated weight dict.
        """
        if not model_weights:
            return {}

        # Step 1: standard weighted average → global model
        global_weights = FederatedAveraging.aggregate(model_weights, weights)

        if self.mu == 0.0:
            return global_weights

        # Step 2: proximal correction — pull each client toward global
        corrected: list[dict[str, Any]] = []
        for local in model_weights:
            corrected.append(self._proximal_correct(local, global_weights))

        # Step 3: re-aggregate corrected weights
        return FederatedAveraging.aggregate(corrected, weights)

    def _proximal_correct(
        self,
        local: dict[str, Any],
        global_w: dict[str, Any],
    ) -> dict[str, Any]:
        """Apply w_corrected = (1 - mu) * w_local + mu * w_global."""
        result: dict[str, Any] = {}
        for key, lv in local.items():
            gv = global_w.get(key, lv)
            if isinstance(lv, float | int) and isinstance(gv, float | int):
                result[key] = (1.0 - self.mu) * float(lv) + self.mu * float(gv)
            elif isinstance(lv, dict) and isinstance(gv, dict):
                result[key] = self._proximal_correct_nested_dict(lv, gv)
            else:
                result[key] = lv
        return result

    def _proximal_correct_nested_dict(
        self,
        local: dict[str, float],
        global_w: dict[str, float],
    ) -> dict[str, float]:
        all_keys = set(local) | set(global_w)
        return {
            k: (1.0 - self.mu) * local.get(k, 0.0) + self.mu * global_w.get(k, 0.0)
            for k in all_keys
        }
