import copy
from typing import Any

from ..base.federated import FederatedModel
from .aggregation import FederatedAveraging


class FederatedEnsemble:
    """Manages a global model and multiple local clients for online federated learning.

    Clients learn locally from their streams. Periodically, 'sync()' can be
    called to aggregate local updates into the global model and push the global
    state back to clients.
    """

    def __init__(self, global_model: FederatedModel, client_ids: list[str]) -> None:
        if not client_ids:
            raise ValueError("client_ids must not be empty")
        if len(set(client_ids)) != len(client_ids):
            raise ValueError("client_ids must be unique")
        self.global_model = global_model
        # Create unique local models for each client
        self.clients: dict[str, FederatedModel] = {
            cid: copy.deepcopy(global_model) for cid in client_ids
        }
        self.client_samples: dict[str, int] = {cid: 0 for cid in client_ids}

    def learn_one(self, client_id: str, x: dict[str, Any], y: Any) -> None:
        """Let a specific client learn from a data point."""
        if client_id not in self.clients:
            raise KeyError(f"Unknown client_id: {client_id}")
        model = self.clients[client_id]
        # Duck-typing check for learn_one (could be Regressor or Classifier)
        if not hasattr(model, "learn_one"):
            raise TypeError("Client model does not implement learn_one")
        model.learn_one(x, y)
        self.client_samples[client_id] += 1

    def sync(self) -> None:
        """Aggregate local models into global and sync clients back."""
        if not self.clients:
            return

        # 1. Collect weights and sample counts
        all_weights = [c.get_weights() for c in self.clients.values()]
        # Importance weights based on how much each client learned
        importance = [float(s) for s in self.client_samples.values()]

        if sum(importance) == 0:
            importance = [1.0] * len(all_weights)

        # 2. Aggregate
        global_weights = FederatedAveraging.aggregate(all_weights, importance)
        self.global_model.set_weights(global_weights)

        # 3. Synchronize all clients to the new global state
        for client in self.clients.values():
            client.set_weights(global_weights)

        # Reset counters for the next round
        for cid in self.client_samples:
            self.client_samples[cid] = 0

    def predict_global(self, x: dict[str, Any]) -> Any:
        """Prediction using the shared global model."""
        if hasattr(self.global_model, "predict_one"):
            return self.global_model.predict_one(x)
        return None
