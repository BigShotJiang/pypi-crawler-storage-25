"""Regional demand forecasting stream generator."""

import math
from typing import Any

from .base import BaseStreamGenerator


class RegionalDemandStreamGenerator(BaseStreamGenerator):
    """Simulates regional product demand with weekly + daily seasonality.

    Target: demand units (daily).
    Features: price, promotion_active, day_of_week, temperature, competitor_price.

    Concept drift: price elasticity shift at 55% (e.g., competitor enters market).
    Seasonality: 7-day weekly (period=7) + intra-week (period=3.5).
    """

    def __init__(
        self,
        base_demand: float = 500.0,
        seed: int = 42,
        **kwargs: Any,
    ) -> None:
        super().__init__(seed=seed, ar1_coeff=0.6, **kwargs)
        self.base_demand = float(base_demand)

    def _base_signal(self) -> float:
        seasonal = self._seasonality([(7.0, 80.0), (3.5, 30.0)])
        return self.base_demand + seasonal

    def _feature_names(self) -> list[str]:
        return ["price", "promotion_active", "day_of_week", "temperature"]

    def _secondary_features(self, target: float) -> dict[str, Any]:
        t = self._step
        dow = t % 7
        price = 9.99 + self._drift_factor() * 2.0 + self._rng.gauss(0.0, 0.5)
        promotion = 1.0 if dow in {5, 6} else 0.0
        temperature = (
            15.0 + 10.0 * math.sin(2 * math.pi * t / 365.0) + self._rng.gauss(0.0, 2.0)
        )
        competitor_price = (
            10.49 - self._drift_factor() * 1.5 + self._rng.gauss(0.0, 0.3)
        )
        return {
            "price": round(price, 2),
            "promotion_active": promotion,
            "day_of_week": dow,
            "temperature": round(temperature, 1),
            "competitor_price": round(competitor_price, 2),
            "dow_sin": math.sin(2 * math.pi * dow / 7.0),
            "dow_cos": math.cos(2 * math.pi * dow / 7.0),
        }
