"""API security monitoring stream generator (cybersecurity scenario)."""

import math
from typing import Any

from .base import BaseStreamGenerator


class CybersecurityStreamGenerator(BaseStreamGenerator):
    """Simulates per-minute API gateway telemetry for security monitoring.

    Target: request_rate (req/min).
    Features: latency_p95_ms, error_rate, auth_failures, bytes_out_mb, time features.

    Concept drift: credential stuffing attack starts at 55%:
        - auth_failures spike (brute force)
        - error_rate rises (failed auth attempts)
        - bytes_out_mb spikes (data exfiltration signal)
    Anomaly events: ~3% probability of auth_failure burst (brute force attempt).
    Seasonality: 24h business hours (period=1440) + 7-day weekly (period=10080).
    Granularity: 1-minute resolution.
    """

    def __init__(
        self,
        base_rate: float = 1000.0,
        seed: int = 42,
        **kwargs: Any,
    ) -> None:
        super().__init__(seed=seed, ar1_coeff=0.75, noise_scale=0.05, **kwargs)
        self.base_rate = float(base_rate)

    def _base_signal(self) -> float:
        t = self._step
        # 24h business hour pattern (minute resolution, period=1440 minutes)
        hour_effect = 300.0 * math.sin(2 * math.pi * t / 1440.0)
        # 7-day weekly pattern (period=10080 minutes)
        weekly_effect = self._seasonality([(10080.0, 100.0)])
        return self.base_rate + hour_effect + weekly_effect

    def _feature_names(self) -> list[str]:
        return ["latency_p95_ms", "error_rate", "auth_failures", "bytes_out_mb"]

    def _secondary_features(self, target: float) -> dict[str, Any]:
        t = self._step
        drift = self._drift_factor()

        # p95 latency (ms): rises during attack due to auth processing overhead
        latency = max(10.0, 45.0 + drift * 80.0 + self._rng.gauss(0.0, 5.0))

        # Error rate: rises during attack phase (failed auth = 4xx/5xx errors)
        error_rate = max(
            0.0, min(1.0, 0.005 + drift * 0.08 + self._rng.gauss(0.0, 0.003))
        )

        # Auth failures: Poisson-like base + brute force bursts during attack
        brute_force = self._rng.random() < (0.03 + drift * 0.15)
        if brute_force:
            auth_count = int(max(0, 30 + drift * 20 + self._rng.gauss(0.0, 5.0)))
        else:
            base_auth = 2.0 + drift * 20.0
            auth_count = int(max(0, base_auth + self._rng.gauss(0.0, 1.5)))

        # Data egress: spikes during exfiltration phase (late drift)
        bytes_out = max(0.0, 10.0 + drift * 50.0 + self._rng.gauss(0.0, 2.0))

        # Time features (minute of day → hour, day of week)
        minute_of_day = t % 1440
        hour_of_day = minute_of_day // 60
        day_of_week = (t // 1440) % 7

        return {
            "latency_p95_ms": round(latency, 1),
            "error_rate": round(error_rate, 4),
            "auth_failures": auth_count,
            "bytes_out_mb": round(bytes_out, 2),
            "hour_sin": math.sin(2 * math.pi * hour_of_day / 24.0),
            "hour_cos": math.cos(2 * math.pi * hour_of_day / 24.0),
            "dow_sin": math.sin(2 * math.pi * day_of_week / 7.0),
            "dow_cos": math.cos(2 * math.pi * day_of_week / 7.0),
        }
