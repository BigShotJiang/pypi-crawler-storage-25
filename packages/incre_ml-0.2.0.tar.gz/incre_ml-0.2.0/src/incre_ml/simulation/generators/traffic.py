"""Vehicle telemetry stream generator for connected vehicle safety scenario."""

import math
from typing import Any

from .base import BaseStreamGenerator


class VehicleTelemetryGenerator(BaseStreamGenerator):
    """Simulates individual vehicle telemetry during a 20-minute highway drive.

    Target: speed_kmh (km/h, AR1=0.92 for sticky speed).
    Features: headway_s, acceleration_ms2, ttc_s, lane_change, road_condition.

    Concept drift: tailgating scenario at 55% — headway decreases, following
    distance shrinks and relative approach speed increases.
    Faults: emergency brake events (sudden acceleration ~-8 m/s², TTC < 0.8s).
    Physics: TTC = headway / max(relative_speed, 0.1) — proper formula.
    Granularity: 1-second resolution.
    """

    def __init__(
        self,
        base_speed: float = 100.0,
        seed: int = 42,
        **kwargs: Any,
    ) -> None:
        super().__init__(seed=seed, ar1_coeff=0.92, noise_scale=0.02, **kwargs)
        self.base_speed = float(base_speed)
        self._road_condition: int = 0  # 0=dry, 1=wet, 2=ice
        self._prev_accel: float = 0.0

    def _base_signal(self) -> float:
        # Speed with slow sinusoidal variation (highway cruise + deceleration zones)
        t = self._step
        speed_variation = 8.0 * math.sin(2 * math.pi * t / 300.0)
        return self.base_speed + speed_variation

    def _feature_names(self) -> list[str]:
        return [
            "headway_s",
            "acceleration_ms2",
            "ttc_s",
            "lane_change",
            "road_condition",
        ]

    def _secondary_features(self, target: float) -> dict[str, Any]:
        drift = self._drift_factor()

        # Headway decreases during tailgating phase (drift)
        base_headway = max(0.2, 2.0 - drift * 1.2 + self._rng.gauss(0.0, 0.12))
        headway = round(float(base_headway), 2)

        # Acceleration: AR(1) dynamics, physics bound ±10 m/s²
        emergency_brake = self._rng.random() < (0.003 + drift * 0.02)
        if emergency_brake:
            new_accel = -8.0 + self._rng.gauss(0.0, 0.5)
        else:
            raw_accel = 0.85 * self._prev_accel + self._rng.gauss(0.0, 0.8)
            new_accel = max(-10.0, min(10.0, raw_accel))
        self._prev_accel = new_accel
        accel = round(new_accel, 3)

        # Relative speed (positive = approaching faster)
        rel_speed = max(0.1, abs(accel) * 0.5 + drift * 3.0 + self._rng.gauss(0.0, 0.8))

        # TTC = headway / max(relative_speed, 0.1) — physics formula
        ttc = round(float(min(20.0, headway / max(rel_speed, 0.1))), 3)

        # Lane change: Bernoulli(0.02) + burst during overtaking sequences
        overtaking = drift > 0.3 and self._rng.random() < 0.08
        lane_change = 1 if (self._rng.random() < 0.02 or overtaking) else 0

        # Road condition state machine (changes slowly ~0.2% per step)
        if self._rng.random() < 0.002:
            choices = [0, 0, 0, 1, 2]  # weighted toward dry
            self._road_condition = self._rng.choice(choices)

        return {
            "headway_s": headway,
            "acceleration_ms2": accel,
            "ttc_s": ttc,
            "lane_change": lane_change,
            "road_condition": self._road_condition,
        }
