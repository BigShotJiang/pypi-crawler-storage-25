"""Multi-line manufacturing plant stream generator for workforce orchestration."""

import math
import random
from typing import Any

_LINES = ("A", "B", "C", "D")

# Base throughput per line (units/hr)
_LINE_PROFILES: dict[str, dict[str, float]] = {
    "A": {"base_throughput": 110.0, "base_health": 0.92, "base_crew": 12},
    "B": {"base_throughput": 95.0, "base_health": 0.88, "base_crew": 12},
    "C": {"base_throughput": 100.0, "base_health": 0.90, "base_crew": 12},
    "D": {"base_throughput": 85.0, "base_health": 0.85, "base_crew": 12},
}


class PlantWorkforceGenerator:
    """Simulates a 4-line automotive manufacturing plant at 15-min resolution.

    Produces per-tick observations with flattened per-line fields (health,
    throughput, quality, crew, status) plus plant-level fields (shift, rush
    orders, total workers).

    Event injection (deterministic via seed):
    - Line C: gradual health degradation starting at ~40% of stream.
    - Line A: sudden failure at ~65% (health drops for ~20 ticks).
    - Line B: quality crisis at ~50% for ~15 ticks.
    - Rush orders: ~5% per tick, each lasting 8-16 ticks.
    """

    def __init__(
        self,
        total_steps: int = 1200,
        total_workers: int = 48,
        seed: int = 42,
    ) -> None:
        self.total_steps = total_steps
        self.total_workers = total_workers
        self.seed = seed
        self._rng = random.Random(seed)
        self._step = 0

        # Per-line AR(1) state for health smoothing
        self._health_state: dict[str, float] = {
            line: prof["base_health"] for line, prof in _LINE_PROFILES.items()
        }

        # Rush order state
        self._rush_active = False
        self._rush_line: str | None = None
        self._rush_remaining = 0

    def _shift(self) -> int:
        """Shift index: 0=day, 1=evening, 2=night (96 ticks = 24h)."""
        return (self._step % 96) // 32

    def _shift_factor(self) -> float:
        """Throughput multiplier by shift."""
        s = self._shift()
        return {0: 1.0, 1: 0.92, 2: 0.80}[s]

    def _seasonality(self, period: float, amplitude: float) -> float:
        return amplitude * math.sin(2.0 * math.pi * self._step / period)

    def _line_health(self, line: str) -> float:
        """Compute raw health for a line, including event injection."""
        base = _LINE_PROFILES[line]["base_health"]
        # Small natural variation
        noise = self._rng.gauss(0.0, 0.015)
        # Shift-based slight degradation on night shift
        shift_penalty = 0.02 if self._shift() == 2 else 0.0
        # Daily maintenance cycle (slight dip mid-shift)
        cycle = self._seasonality(96.0, 0.03)

        raw = base + noise - shift_penalty + cycle

        # Event: Line C gradual degradation starting at 40%
        frac = self._step / max(1, self.total_steps)
        if line == "C" and frac > 0.40:
            progress = min(1.0, (frac - 0.40) / 0.35)
            raw -= 0.45 * progress

        # Event: Line A sudden failure at 65% for 20 ticks
        fail_start = int(0.65 * self.total_steps)
        fail_end = fail_start + 20
        if line == "A" and fail_start <= self._step < fail_end:
            drop = 0.75 if self._step < fail_start + 2 else 0.60
            raw -= drop

        # AR(1) smoothing
        phi = 0.7
        prev = self._health_state[line]
        smoothed = phi * prev + (1.0 - phi) * raw
        self._health_state[line] = smoothed

        return max(0.0, min(1.0, smoothed))

    def _line_quality(self, line: str, health: float) -> float:
        """Quality rate correlated with health."""
        base_q = 0.92 + 0.06 * health
        noise = self._rng.gauss(0.0, 0.01)

        # Event: Line B quality crisis at 50% for 15 ticks
        crisis_start = int(0.50 * self.total_steps)
        crisis_end = crisis_start + 15
        if line == "B" and crisis_start <= self._step < crisis_end:
            base_q -= 0.25

        return max(0.0, min(1.0, base_q + noise))

    def _line_throughput(self, line: str, health: float, crew: int) -> float:
        """Throughput depends on health, crew, and shift."""
        base = _LINE_PROFILES[line]["base_throughput"]
        base_crew = _LINE_PROFILES[line]["base_crew"]

        # Health impact: below 0.5 health, throughput degrades sharply
        health_mult = min(1.0, health / 0.7) if health > 0.3 else health * 0.5

        # Crew impact: understaffing reduces, overstaffing has diminishing returns
        crew_ratio = crew / base_crew if base_crew > 0 else 1.0
        if crew_ratio <= 1.0:
            crew_mult = crew_ratio
        else:
            crew_mult = 1.0 + 0.3 * (crew_ratio - 1.0)  # diminishing returns

        shift_mult = self._shift_factor()
        noise = self._rng.gauss(0.0, 2.0)

        return max(0.0, base * health_mult * crew_mult * shift_mult + noise)

    def _line_status(self, health: float) -> int:
        """0=running, 1=degraded, 2=down."""
        if health < 0.15:
            return 2
        if health < 0.45:
            return 1
        return 0

    def _update_rush_order(self) -> None:
        """Manage rush order state."""
        if self._rush_active:
            self._rush_remaining -= 1
            if self._rush_remaining <= 0:
                self._rush_active = False
                self._rush_line = None
        elif self._rng.random() < 0.05:
            self._rush_active = True
            self._rush_line = self._rng.choice(list(_LINES))
            self._rush_remaining = self._rng.randint(8, 16)

    def next(self) -> dict[str, Any]:
        """Generate the next tick observation."""
        self._update_rush_order()

        # Compute per-line health first
        healths: dict[str, float] = {}
        for line in _LINES:
            healths[line] = self._line_health(line)

        # Default crew allocation (equal)
        base_crew = {line: int(_LINE_PROFILES[line]["base_crew"]) for line in _LINES}

        # Compute status
        statuses: dict[str, int] = {}
        for line in _LINES:
            statuses[line] = self._line_status(healths[line])

        # Build observation
        obs: dict[str, Any] = {
            "step": self._step,
            "shift": self._shift(),
            "total_workers": self.total_workers,
            "rush_order": self._rush_active,
            "rush_order_line": self._rush_line if self._rush_active else None,
        }

        for line in _LINES:
            crew = base_crew[line]
            quality = self._line_quality(line, healths[line])
            throughput = self._line_throughput(line, healths[line], crew)

            obs[f"{line}_health"] = round(healths[line], 4)
            obs[f"{line}_quality"] = round(quality, 4)
            obs[f"{line}_throughput"] = round(throughput, 2)
            obs[f"{line}_crew"] = crew
            obs[f"{line}_status"] = statuses[line]

        self._step += 1
        return obs

    def reset(self) -> None:
        """Reset generator to initial state."""
        self._rng = random.Random(self.seed)
        self._step = 0
        self._health_state = {
            line: prof["base_health"] for line, prof in _LINE_PROFILES.items()
        }
        self._rush_active = False
        self._rush_line = None
        self._rush_remaining = 0

    def __iter__(self) -> "PlantWorkforceGenerator":
        return self

    def __next__(self) -> dict[str, Any]:
        if self._step >= self.total_steps:
            raise StopIteration
        return self.next()
