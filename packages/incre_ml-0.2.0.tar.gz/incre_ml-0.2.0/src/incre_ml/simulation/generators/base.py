"""Base class for all domain-specific stream generators."""

import math
import random
from abc import ABC, abstractmethod
from typing import Any


class BaseStreamGenerator(ABC):
    """Shared realism features for all domain-specific generators.

    Provides:
    - AR(1) autocorrelation via an exponential smoothing filter
    - Heteroscedastic Gaussian noise scaled by signal magnitude
    - Nested seasonality: multiple sinusoidal components
    - Correlated missingness: sensor failures cascade across features
    - Abrupt or gradual concept drift at configurable schedule

    Subclasses must implement ``_base_signal()`` and ``_feature_names()``.
    """

    def __init__(
        self,
        seed: int = 42,
        ar1_coeff: float = 0.7,
        noise_scale: float = 0.05,
        drift_start: float = 0.55,
        drift_magnitude: float = 0.3,
        drift_gradual: bool = True,
        missing_rate: float = 0.02,
        missing_cascade_prob: float = 0.5,
        total_steps: int = 1000,
    ) -> None:
        """
        Args:
            seed: Random seed.
            ar1_coeff: AR(1) coefficient φ ∈ [0, 1).  Higher = stickier signal.
            noise_scale: Heteroscedastic noise as fraction of signal magnitude.
            drift_start: Fraction of total_steps at which concept drift begins.
            drift_magnitude: Relative magnitude of drift (fraction of base signal).
            drift_gradual: If True, drift is linear ramp; if False, step function.
            missing_rate: Per-step probability that the primary sensor fails.
            missing_cascade_prob: P(secondary sensor also fails | primary fails).
            total_steps: Total stream length (used for drift scheduling).
        """
        if not (0.0 <= ar1_coeff < 1.0):
            raise ValueError("ar1_coeff must be in [0, 1)")
        self.seed = seed
        self.ar1_coeff = float(ar1_coeff)
        self.noise_scale = float(noise_scale)
        self.drift_start = float(drift_start)
        self.drift_magnitude = float(drift_magnitude)
        self.drift_gradual = drift_gradual
        self.missing_rate = float(missing_rate)
        self.missing_cascade_prob = float(missing_cascade_prob)
        self.total_steps = int(total_steps)
        self._rng = random.Random(seed)
        self._step = 0
        self._ar_state: float = 0.0  # AR(1) filter state

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    @abstractmethod
    def _base_signal(self) -> float:
        """Return the noiseless base signal value at the current step."""
        ...

    @abstractmethod
    def _feature_names(self) -> list[str]:
        """Return the list of secondary feature names (besides the target)."""
        ...

    @abstractmethod
    def _secondary_features(self, target: float) -> dict[str, Any]:
        """Return secondary features as a dict, given the current target value."""
        ...

    # ------------------------------------------------------------------
    # Realism helpers
    # ------------------------------------------------------------------

    def _seasonality(
        self,
        components: list[tuple[float, float]],
    ) -> float:
        """Nested seasonality: sum of sinusoidal components.

        Args:
            components: List of (period, amplitude) pairs.
        """
        t = self._step
        return sum(
            amp * math.sin(2.0 * math.pi * t / period) for period, amp in components
        )

    def _ar1_filter(self, raw: float) -> float:
        """Apply AR(1) smoothing: y_t = φ * y_{t-1} + (1 - φ) * raw."""
        self._ar_state = self.ar1_coeff * self._ar_state + (1.0 - self.ar1_coeff) * raw
        return self._ar_state

    def _heteroscedastic_noise(self, signal: float) -> float:
        """Gaussian noise scaled by signal magnitude."""
        scale = self.noise_scale * (abs(signal) + 1.0)
        return self._rng.gauss(0.0, scale)

    def _drift_factor(self) -> float:
        """Compute the additive drift at current step."""
        drift_step = int(self.drift_start * self.total_steps)
        if self._step < drift_step:
            return 0.0
        if self.drift_gradual:
            remaining = self.total_steps - drift_step
            progress = min(1.0, (self._step - drift_step) / max(1, remaining))
            return self.drift_magnitude * progress
        return self.drift_magnitude

    def _missing_mask(self) -> list[bool]:
        """Return a missing-indicator list (True = missing) for all features.

        Missing values cascade: if the primary sensor fails, secondary sensors
        fail with probability ``missing_cascade_prob``.
        """
        names = self._feature_names()
        primary_missing = self._rng.random() < self.missing_rate
        mask = [primary_missing]
        for _ in names[1:]:
            if primary_missing and self._rng.random() < self.missing_cascade_prob:
                mask.append(True)
            else:
                mask.append(self._rng.random() < self.missing_rate * 0.1)
        return mask

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def next(self) -> tuple[dict[str, Any], float]:
        """Generate the next (features, target) observation.

        Returns:
            (x, y) where x is a feature dict and y is the float target.
        """
        raw = self._base_signal()
        drift = self._drift_factor()
        raw_drifted = raw + drift * abs(raw + 1.0)
        smoothed = self._ar1_filter(raw_drifted)
        target = smoothed + self._heteroscedastic_noise(smoothed)

        x = self._secondary_features(target)
        x["step"] = self._step

        # Apply missingness
        names = self._feature_names()
        mask = self._missing_mask()
        for feat, missing in zip(names, mask, strict=True):
            if missing and feat in x:
                x[feat] = float("nan")

        self._step += 1
        return x, float(target)

    def __iter__(self) -> "BaseStreamGenerator":
        return self

    def __next__(self) -> tuple[dict[str, Any], float]:
        return self.next()

    def reset(self) -> None:
        """Reset generator to initial state."""
        self._rng = random.Random(self.seed)
        self._step = 0
        self._ar_state = 0.0
