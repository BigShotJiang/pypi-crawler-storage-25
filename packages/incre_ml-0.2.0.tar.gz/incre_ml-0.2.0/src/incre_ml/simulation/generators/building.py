"""Building thermal management stream generator."""

import math
from typing import Any

from .base import BaseStreamGenerator


class BuildingThermalStreamGenerator(BaseStreamGenerator):
    """Simulates building HVAC thermal dynamics.

    Target: zone temperature (°C).
    Features: setpoint, occupancy, outdoor_temp, solar_irradiance, hvac_power.

    Concept drift: HVAC efficiency degradation from 55% onward.
    Seasonality: 24-hour daily + annual (mapped to steps).
    Physics: Newton's cooling toward outdoor temperature.
    """

    def __init__(
        self,
        base_temp: float = 22.0,
        outdoor_temp: float = 10.0,
        seed: int = 42,
        **kwargs: Any,
    ) -> None:
        super().__init__(seed=seed, ar1_coeff=0.9, **kwargs)
        self.base_temp = float(base_temp)
        self.outdoor_temp = float(outdoor_temp)

    def _base_signal(self) -> float:
        t = self._step
        # Daily solar cycle + occupancy heat gain
        hour = t % 24
        solar = 3.0 * max(0.0, math.sin(math.pi * (hour - 6) / 12.0))
        occupancy_heat = 1.5 * max(0.0, math.sin(math.pi * (hour - 8) / 10.0))
        # Newton's cooling component
        newton = -0.05 * (self.base_temp - self.outdoor_temp)
        return self.base_temp + solar + occupancy_heat + newton

    def _feature_names(self) -> list[str]:
        return ["setpoint", "occupancy_count", "outdoor_temp", "solar_irradiance"]

    def _secondary_features(self, target: float) -> dict[str, Any]:
        t = self._step
        hour = t % 24
        setpoint = 21.0 + (1.0 if 9 <= hour <= 18 else 0.0)
        occupancy = max(
            0,
            int(
                20 * max(0.0, math.sin(math.pi * (hour - 8) / 10.0))
                + self._rng.gauss(0.0, 2.0)
            ),
        )
        outdoor = (
            self.outdoor_temp
            + 8.0 * math.sin(math.pi * (hour - 6) / 12.0)
            + self._rng.gauss(0.0, 1.0)
        )
        solar = max(
            0.0,
            600.0 * math.sin(math.pi * (hour - 6) / 12.0) + self._rng.gauss(0.0, 30.0),
        )
        hvac_power = max(
            0.0,
            abs(target - setpoint) * (2.0 + self._drift_factor() * 1.5)
            + self._rng.gauss(0.0, 0.2),
        )
        return {
            "setpoint": round(setpoint, 1),
            "occupancy_count": occupancy,
            "outdoor_temp": round(outdoor, 1),
            "solar_irradiance": round(solar, 0),
            "hvac_power_kw": round(hvac_power, 2),
            "hour": hour,
            "hour_sin": math.sin(2 * math.pi * hour / 24.0),
            "hour_cos": math.cos(2 * math.pi * hour / 24.0),
        }
