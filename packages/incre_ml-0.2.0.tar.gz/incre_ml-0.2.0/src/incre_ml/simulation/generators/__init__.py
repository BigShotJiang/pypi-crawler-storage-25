"""Domain-specific stream generators for incre-ml demos and testing.

Each generator encapsulates:
- AR(1) autocorrelation for temporal stickiness
- Heteroscedastic noise (noise magnitude scales with signal level)
- Correlated missingness (sensor-failure cascades)
- Nested seasonality (hourly + daily + weekly)
- Configurable concept drift schedule

All generators expose a ``next()`` method that returns a ``dict[str, Any]``
observation and a ``target()`` float, matching the incre-ml streaming API.
"""

from .building import BuildingThermalStreamGenerator
from .clinical import ClinicalStreamGenerator
from .demand import RegionalDemandStreamGenerator
from .finance import RevenueAnomalyStreamGenerator
from .manufacturing import ManufacturingStreamGenerator
from .plant_workforce import PlantWorkforceGenerator
from .traffic import VehicleTelemetryGenerator
from .workforce import CybersecurityStreamGenerator

# Backward-compatible aliases
TrafficStreamGenerator = VehicleTelemetryGenerator
WorkforceAbsenteeismStreamGenerator = CybersecurityStreamGenerator

__all__ = [
    "ManufacturingStreamGenerator",
    "PlantWorkforceGenerator",
    "ClinicalStreamGenerator",
    "RegionalDemandStreamGenerator",
    "VehicleTelemetryGenerator",
    "TrafficStreamGenerator",  # alias
    "BuildingThermalStreamGenerator",
    "RevenueAnomalyStreamGenerator",
    "CybersecurityStreamGenerator",
    "WorkforceAbsenteeismStreamGenerator",  # alias
]
