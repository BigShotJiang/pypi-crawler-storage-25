"""Clinical patient monitoring stream generator."""

import math
from typing import Any

from .base import BaseStreamGenerator


class ClinicalStreamGenerator(BaseStreamGenerator):
    """Simulates ICU patient vitals stream with circadian rhythm.

    Target: heart rate (bpm).
    Features: blood pressure, SpO2, respiratory rate, temperature, SOFA score.

    Concept drift: medication change at 55% of stream causing HR shift.
    Seasonality: circadian rhythm (24-hour period).
    """

    def __init__(
        self,
        base_hr: float = 75.0,
        seed: int = 42,
        **kwargs: Any,
    ) -> None:
        super().__init__(seed=seed, ar1_coeff=0.85, **kwargs)
        self.base_hr = float(base_hr)

    def _base_signal(self) -> float:
        # Circadian: HR slightly elevated during day, lower at night
        seasonal = self._seasonality([(1440.0, 5.0), (480.0, 2.0)])
        return self.base_hr + seasonal

    def _feature_names(self) -> list[str]:
        return ["systolic_bp", "spo2", "resp_rate", "body_temp"]

    def _secondary_features(self, target: float) -> dict[str, Any]:
        t = self._step
        # Correlated vital signs
        hr_norm = (target - self.base_hr) / max(1.0, self.base_hr)
        systolic_bp = 120.0 + 15.0 * hr_norm + self._rng.gauss(0.0, 5.0)
        spo2 = min(100.0, 97.0 - 2.0 * abs(hr_norm) + self._rng.gauss(0.0, 0.5))
        resp_rate = 16.0 + 4.0 * hr_norm + self._rng.gauss(0.0, 1.0)
        body_temp = 37.0 + 0.5 * self._drift_factor() + self._rng.gauss(0.0, 0.1)
        hour_of_day = (t % 1440) / 60.0
        return {
            "systolic_bp": round(systolic_bp, 1),
            "spo2": round(max(80.0, spo2), 1),
            "resp_rate": round(max(8.0, resp_rate), 1),
            "body_temp": round(body_temp, 2),
            "hour_of_day": round(hour_of_day, 2),
            "hour_sin": math.sin(2 * math.pi * hour_of_day / 24.0),
            "hour_cos": math.cos(2 * math.pi * hour_of_day / 24.0),
        }
