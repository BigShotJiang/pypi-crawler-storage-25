"""Revenue anomaly stream generator for financial monitoring."""

import math
from typing import Any

from .base import BaseStreamGenerator


class RevenueAnomalyStreamGenerator(BaseStreamGenerator):
    """Simulates daily revenue with seasonal patterns and occasional anomalies.

    Target: daily revenue (thousands USD).
    Features: transactions, avg_ticket, refund_rate, channel_mix, day_features.

    Concept drift: pricing strategy change at 55% (revenue uplift).
    Seasonality: weekly (7-day) + monthly (30-day) + quarterly (90-day).
    Anomalies: injected revenue spikes/drops (promotions, outages).
    """

    def __init__(
        self,
        base_revenue: float = 100.0,
        anomaly_rate: float = 0.03,
        seed: int = 42,
        **kwargs: Any,
    ) -> None:
        super().__init__(seed=seed, ar1_coeff=0.5, **kwargs)
        self.base_revenue = float(base_revenue)
        self.anomaly_rate = float(anomaly_rate)

    def _base_signal(self) -> float:
        seasonal = self._seasonality(
            [
                (7.0, 15.0),  # weekly
                (30.0, 8.0),  # monthly
                (90.0, 20.0),  # quarterly
            ]
        )
        return self.base_revenue + seasonal

    def _feature_names(self) -> list[str]:
        return ["transactions", "avg_ticket", "refund_rate", "channel_online"]

    def _secondary_features(self, target: float) -> dict[str, Any]:
        t = self._step
        dow = t % 7
        # Anomaly injection
        is_anomaly = self._rng.random() < self.anomaly_rate
        anomaly_factor = self._rng.choice([-0.5, 2.0]) if is_anomaly else 1.0

        transactions = max(
            1, int(target * 10 * anomaly_factor + self._rng.gauss(0.0, 50))
        )
        avg_ticket = max(
            0.0, target * 1000 / max(1, transactions) + self._rng.gauss(0.0, 2.0)
        )
        refund_rate = max(
            0.0, 0.02 + self._drift_factor() * 0.01 + self._rng.gauss(0.0, 0.005)
        )
        channel_online = min(
            1.0, 0.6 + self._drift_factor() * 0.15 + self._rng.gauss(0.0, 0.05)
        )
        return {
            "transactions": transactions,
            "avg_ticket": round(avg_ticket, 2),
            "refund_rate": round(refund_rate, 4),
            "channel_online": round(channel_online, 3),
            "day_of_week": dow,
            "is_weekend": float(dow >= 5),
            "dow_sin": math.sin(2 * math.pi * dow / 7.0),
            "dow_cos": math.cos(2 * math.pi * dow / 7.0),
        }
