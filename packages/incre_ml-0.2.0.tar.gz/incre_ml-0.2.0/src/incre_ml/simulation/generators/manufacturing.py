"""Manufacturing process stream generator."""

import math
from typing import Any

from .base import BaseStreamGenerator


class ManufacturingStreamGenerator(BaseStreamGenerator):
    """Simulates a CNC/machining process with temperature, vibration, and wear.

    Target: spindle temperature (°C).
    Features: vibration, power draw, coolant flow, tool wear index, shift.

    Concept drift: gradual tool wear increase at 55% of stream.
    Seasonality: 8-hour shifts (hourly + per-shift).
    """

    def __init__(
        self,
        base_temp: float = 65.0,
        seed: int = 42,
        **kwargs: Any,
    ) -> None:
        super().__init__(seed=seed, **kwargs)
        self.base_temp = float(base_temp)

    def _base_signal(self) -> float:
        # Nested seasonality: hourly (period=60) + shift (period=480)
        seasonal = self._seasonality([(60.0, 3.0), (480.0, 8.0)])
        return self.base_temp + seasonal

    def _feature_names(self) -> list[str]:
        return ["vibration", "power_kw", "coolant_flow", "tool_wear"]

    def _secondary_features(self, target: float) -> dict[str, Any]:
        t = self._step
        shift = (t // 480) % 3  # 0, 1, 2 for morning/afternoon/night
        vibration = 0.2 * target / self.base_temp + self._rng.gauss(0.0, 0.02)
        power_kw = 5.0 + 0.1 * target + self._rng.gauss(0.0, 0.3)
        coolant_flow = max(
            0.1, 2.0 - self._drift_factor() * 0.5 + self._rng.gauss(0.0, 0.1)
        )
        tool_wear = min(1.0, t / (self.total_steps * 0.9) + self._drift_factor() * 0.3)
        return {
            "vibration": round(vibration, 4),
            "power_kw": round(power_kw, 3),
            "coolant_flow": round(coolant_flow, 3),
            "tool_wear": round(tool_wear, 4),
            "shift": shift,
            "hour_sin": math.sin(2 * math.pi * (t % 60) / 60.0),
            "hour_cos": math.cos(2 * math.pi * (t % 60) / 60.0),
        }
