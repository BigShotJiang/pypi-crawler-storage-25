import random
from collections.abc import Iterator


class FaultInjection:
    """Wraps a stream and injects artificial faults/anomalies."""

    def __init__(
        self,
        stream: Iterator[float],
        spike_chance: float = 0.05,
        spike_magnitude: float = 50.0,
        stuck_chance: float = 0.01,
        stuck_duration: int = 10,
    ) -> None:
        if not (0.0 <= spike_chance <= 1.0):
            raise ValueError("spike_chance must be in [0, 1]")
        if not (0.0 <= stuck_chance <= 1.0):
            raise ValueError("stuck_chance must be in [0, 1]")
        if stuck_duration < 0:
            raise ValueError("stuck_duration must be >= 0")
        self.stream = stream
        self.spike_chance = spike_chance
        self.spike_magnitude = spike_magnitude
        self.stuck_chance = stuck_chance
        self.stuck_duration = stuck_duration
        self.stuck_counter = 0
        self.stuck_value: float | None = None

    def __iter__(self) -> Iterator[float]:
        return self

    def __next__(self) -> float:
        # If currently stuck, return the stuck value
        if self.stuck_counter > 0:
            self.stuck_counter -= 1
            return float(self.stuck_value or 0.0)

        val = next(self.stream)

        # Check for new stuck fault
        if random.random() < self.stuck_chance:
            self.stuck_counter = self.stuck_duration
            self.stuck_value = val
            return float(val)

        # Check for spike fault
        if random.random() < self.spike_chance:
            chance = 0.5
            sign = 1 if random.random() > chance else -1
            return float(val + sign * self.spike_magnitude)

        return float(val)
