import math
import random
from collections.abc import Iterator

import numpy as np


class SyntheticStreamGenerator:
    """Generates synthetic data streams for testing and demos."""

    def __init__(
        self,
        base_value: float = 0.0,
        trend: float = 0.0,
        seasonality: dict[str, float] | None = None,
        noise_std: float = 1.0,
        seed: int = 42,
    ) -> None:
        """
        Args:
            base_value: Starting value of the stream.
            trend: Change per step.
            seasonality: Dict with 'period' and 'amplitude'.
            noise_std: Standard deviation of Gaussian noise.
        """
        if noise_std < 0.0:
            raise ValueError("noise_std must be >= 0")
        self.base_value = float(base_value)
        self.trend = float(trend)
        self.seasonality = seasonality or {}
        period = self.seasonality.get("period")
        if period is not None and float(period) == 0.0:
            raise ValueError("seasonality period must be non-zero")
        self.noise_std = float(noise_std)
        self.step = 0
        self._rng = random.Random(seed)
        self._np_rng = np.random.default_rng(seed)

    def next_point(self) -> float:
        """Generate the next point in the stream."""
        val = self.base_value + self.trend * self.step

        if self.seasonality:
            period = float(self.seasonality.get("period", 24.0))
            amplitude = float(self.seasonality.get("amplitude", 10.0))
            val += amplitude * math.sin(2 * math.pi * self.step / period)

        val += float(self._np_rng.normal(0, self.noise_std))
        self.step += 1
        return float(val)

    def __iter__(self) -> Iterator[float]:
        return self

    def __next__(self) -> float:
        return self.next_point()
