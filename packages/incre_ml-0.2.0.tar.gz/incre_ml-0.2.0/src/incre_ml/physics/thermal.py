from typing import Any

from ..base.physics import Constraint


class NewtonCoolingConstraint(Constraint):
    """Enforces Newton's Law of Cooling: dT/dt = -k(T - T_ambient).

    After one time step: T_expected = T_last - k * (T_last - T_ambient).

    When ``estimate_k=True`` the cooling coefficient ``k`` is estimated online
    from observed temperature pairs using a one-dimensional recursive least-
    squares update.  The RLS tracks:
        ΔT = k * (T_last - T_ambient)
    where ΔT = T_last - T_observed.  This reduces to a scalar gain update:
        k_new = k + gain * (ΔT_obs - k * (T_last - T_ambient))

    Args:
        k: Initial cooling coefficient.  Used as the fixed value when
            ``estimate_k=False``, or as the initial estimate when ``True``.
        ambient_temp: Ambient temperature (target steady state).
        max_deviation: Tolerance band around the physics-expected value before
            projection is applied.
        dt: Time-step size.  The discrete cooling law is
            T_next = T - k * dt * (T - T_ambient).
        estimate_k: If True, update k online from observations.
        rls_forgetting: Forgetting factor for the scalar RLS update.
            Values close to 1.0 = slow adaptation; smaller = faster.
    """

    def __init__(
        self,
        k: float = 0.1,
        ambient_temp: float = 25.0,
        max_deviation: float = 2.0,
        dt: float = 1.0,
        estimate_k: bool = False,
        rls_forgetting: float = 0.99,
    ) -> None:
        if k <= 0.0:
            raise ValueError("k must be > 0")
        if dt <= 0.0:
            raise ValueError("dt must be > 0")
        if not (0.0 < rls_forgetting <= 1.0):
            raise ValueError("rls_forgetting must be in (0, 1]")
        self.k = float(k)
        self.ambient_temp = float(ambient_temp)
        self.max_deviation = float(max_deviation)
        self.dt = float(dt)
        self.estimate_k = estimate_k
        self.rls_forgetting = float(rls_forgetting)
        self.last_y: float | None = None
        # Scalar RLS state: P is the inverse covariance (scalar)
        self._rls_p: float = 1.0 / (k * 0.01 + 1e-6)  # vague prior

    def _get_expected(self, y_last: float) -> float:
        """Discrete Newton's cooling step."""
        return y_last - self.k * self.dt * (y_last - self.ambient_temp)

    def _update_k(self, y_last: float, y_observed: float) -> None:
        """Scalar RLS update to estimate cooling coefficient k.

        Observation model: ΔT = k * x  where x = (T_last - T_ambient).
        Observed: ΔT_obs = T_last - T_observed.
        """
        x = self.dt * (y_last - self.ambient_temp)
        if abs(x) < 1e-9:
            return  # no thermal driving force — skip update

        delta_t_obs = y_last - y_observed

        # RLS gain
        p = self._rls_p
        gain = p * x / (self.rls_forgetting + x * p * x)

        # Innovation
        innovation = delta_t_obs - self.k * x

        # Update k and P
        self.k = max(1e-6, self.k + gain * innovation)
        self._rls_p = (p - gain * x * p) / self.rls_forgetting

    def violation_one(self, x: dict[str, Any], y_pred: float) -> float:
        if self.last_y is None:
            return 0.0

        expected = self._get_expected(self.last_y)
        diff = abs(y_pred - expected)
        return float(max(0.0, diff - self.max_deviation))

    def project_one(self, x: dict[str, Any], y_pred: float) -> float:
        if self.last_y is None:
            return y_pred

        expected = self._get_expected(self.last_y)
        # Pull prediction closer to physical expected value
        return (y_pred + expected) / 2.0

    def learn_one(self, x: dict[str, Any], y: float) -> None:
        """Update last observed temperature and (optionally) estimate k."""
        if self.estimate_k and self.last_y is not None:
            self._update_k(self.last_y, y)
        self.last_y = y


class SoftConstraint(Constraint):
    """Wraps a hard ``Constraint`` and applies a soft penalty blending.

    Instead of hard-projecting onto the feasible manifold, the soft variant
    returns a prediction that is a weighted interpolation between the raw ML
    prediction and the physics-projected prediction:

        y_soft = (1 - strength) * y_pred + strength * y_projected

    ``strength=1.0`` is equivalent to the hard constraint.
    ``strength=0.0`` disables the constraint entirely.

    This allows the ML model to deviate from physics when the data warrants it
    while still being penalised for large violations.

    Args:
        constraint: The underlying hard ``Constraint`` to wrap.
        strength: Blending weight in [0, 1].  Higher = closer to physics.
    """

    def __init__(self, constraint: Constraint, strength: float = 0.5) -> None:
        if not (0.0 <= strength <= 1.0):
            raise ValueError("strength must be in [0, 1]")
        self.constraint = constraint
        self.strength = float(strength)

    def violation_one(self, x: dict[str, Any], y_pred: float) -> float:
        return self.constraint.violation_one(x, y_pred)

    def project_one(self, x: dict[str, Any], y_pred: float) -> float:
        y_hard = self.constraint.project_one(x, y_pred)
        return (1.0 - self.strength) * y_pred + self.strength * y_hard

    def learn_one(self, x: dict[str, Any], y: float) -> None:
        if hasattr(self.constraint, "learn_one"):
            self.constraint.learn_one(x, y)

    def clear(self) -> None:
        if hasattr(self.constraint, "clear"):
            self.constraint.clear()
