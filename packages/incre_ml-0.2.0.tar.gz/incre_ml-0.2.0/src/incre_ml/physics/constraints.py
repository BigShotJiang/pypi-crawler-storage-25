from typing import Any

from ..base.physics import Constraint


class RangeConstraint(Constraint):
    """Enforces that a prediction stays within [min_val, max_val]."""

    def __init__(
        self, min_val: float = -float("inf"), max_val: float = float("inf")
    ) -> None:
        self.min_val = min_val
        self.max_val = max_val

    def violation_one(self, x: dict[str, Any], y_pred: float) -> float:
        if y_pred < self.min_val:
            return float(self.min_val - y_pred)
        if y_pred > self.max_val:
            return float(y_pred - self.max_val)
        return 0.0

    def project_one(self, x: dict[str, Any], y_pred: float) -> float:
        return float(max(self.min_val, min(self.max_val, y_pred)))


class RateLimitConstraint(Constraint):
    """Limits the maximum change between consecutive predictions."""

    def __init__(self, max_delta: float) -> None:
        self.max_delta = max_delta
        self.last_y: float | None = None

    def learn_one(self, x: dict[str, Any], y: float) -> None:
        self.last_y = y

    def violation_one(self, x: dict[str, Any], y_pred: float) -> float:
        if self.last_y is None:
            return 0.0
        diff = abs(y_pred - self.last_y)
        return float(max(0.0, diff - self.max_delta))

    def project_one(self, x: dict[str, Any], y_pred: float) -> float:
        if self.last_y is None:
            return y_pred

        diff = y_pred - self.last_y
        if abs(diff) > self.max_delta:
            sign = 1 if diff > 0 else -1
            return float(self.last_y + sign * self.max_delta)
        return y_pred


class MonotonicConstraint(Constraint):
    """Enforces that predictions must be non-decreasing or non-increasing."""

    def __init__(self, direction: str = "increasing") -> None:
        self.direction = direction
        self.last_y: float | None = None

    def learn_one(self, x: dict[str, Any], y: float) -> None:
        self.last_y = y

    def violation_one(self, x: dict[str, Any], y_pred: float) -> float:
        if self.last_y is None:
            return 0.0

        if self.direction == "increasing" and y_pred < self.last_y:
            return float(self.last_y - y_pred)
        if self.direction == "decreasing" and y_pred > self.last_y:
            return float(y_pred - self.last_y)
        return 0.0

    def project_one(self, x: dict[str, Any], y_pred: float) -> float:
        if self.last_y is None:
            return y_pred

        if self.direction == "increasing":
            return float(max(self.last_y, y_pred))
        return float(min(self.last_y, y_pred))


class CompositeConstraint(Constraint):
    """Composes multiple constraints, applying them in sequence.

    Each constraint is applied in order. The final projected value
    satisfies all constraints (or the best approximation thereof).
    """

    def __init__(self, constraints: list[Constraint]) -> None:
        if not constraints:
            raise ValueError("Must provide at least one constraint")
        self.constraints = constraints

    def violation_one(self, x: dict[str, Any], y_pred: float) -> float:
        """Returns the maximum violation across all constraints."""
        return max(c.violation_one(x, y_pred) for c in self.constraints)

    def project_one(self, x: dict[str, Any], y_pred: float) -> float:
        """Apply all constraints in sequence."""
        projected = y_pred
        for c in self.constraints:
            projected = c.project_one(x, projected)
        return projected

    def explain_one(self, x: dict[str, Any], y_pred: float) -> dict[str, float]:
        """Explain violations from all constraints."""
        result: dict[str, float] = {}
        for i, c in enumerate(self.constraints):
            v = c.violation_one(x, y_pred)
            name = c.__class__.__name__
            result[f"{name}_{i}_violation"] = v
        result["total_violation"] = self.violation_one(x, y_pred)
        return result

    def learn_one(self, x: dict[str, Any], y: float) -> None:
        """Propagate learning to stateful constraints."""
        for c in self.constraints:
            if hasattr(c, "learn_one"):
                c.learn_one(x, y)


class SoftConstraintWrapper:
    """Applies constraints as soft penalties rather than hard projections.

    Instead of projecting predictions, applies a penalty that nudges
    the prediction toward the feasible region.
    """

    def __init__(self, constraint: Constraint, penalty_weight: float = 0.5) -> None:
        if not (0.0 <= penalty_weight <= 1.0):
            raise ValueError("penalty_weight must be in [0, 1]")
        self.constraint = constraint
        self.penalty_weight = penalty_weight

    def apply(self, x: dict[str, Any], y_pred: float) -> float:
        """Apply soft constraint: blend between raw prediction and projected value."""
        violation = self.constraint.violation_one(x, y_pred)
        if violation <= 0:
            return y_pred
        projected = self.constraint.project_one(x, y_pred)
        return y_pred + self.penalty_weight * (projected - y_pred)
