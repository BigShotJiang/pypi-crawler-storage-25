from typing import Any

from ...base.regressor import Regressor


class ResidualDriftMonitor:
    """Monitors concept drift based on model residuals."""

    def __init__(self, model: Regressor, detector: Any) -> None:
        self.model = model
        self.detector = detector
        self.drifted = False

    def update(self, x: dict[str, Any], y: float) -> bool:
        y_pred = self.model.predict_one(x)
        residual = abs(y - y_pred)

        # Some detectors expect booleans (correct/incorrect)
        # We can threshold the residual
        # For now, we pass the raw residual if the detector supports it
        if not hasattr(self.detector, "update"):
            raise TypeError("detector must implement update")
        self.drifted = bool(self.detector.update(residual))
        return self.drifted

    def clear(self) -> None:
        if hasattr(self.detector, "clear"):
            self.detector.clear()
        self.drifted = False
