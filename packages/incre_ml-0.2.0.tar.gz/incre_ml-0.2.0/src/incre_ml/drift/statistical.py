import math


class EDDM:
    """Early Drift Detection Method (EDDM).

    Designed specifically for detecting drift in data streams where
    the distance between errors is used as the signal.
    """

    def __init__(self) -> None:
        self.m = 0.0
        self.s = 0.0
        self.m_max = -1.0
        self.s_max = -1.0
        self.n = 0
        self.last_error_idx = 0
        self.drifted = False
        self.warning = False
        self.error_count = 0

    def update(self, is_correct: bool) -> bool:
        self.drifted = False
        self.warning = False
        self.n += 1
        if not is_correct:
            self.error_count += 1
            distance = self.n - self.last_error_idx
            self.last_error_idx = self.n

            # Incremental mean and std of distance
            old_m = self.m
            divisor = self.error_count if self.error_count > 0 else 1
            self.m += (distance - self.m) / divisor
            self.s += (distance - old_m) * (distance - self.m)

            std = (
                math.sqrt(self.s / max(1, self.error_count - 1))
                if self.error_count > 1
                else 0.0
            )
            current_val = self.m + 2 * std

            min_errors_for_detection = 5
            best_val = self.m_max + 2 * self.s_max if self.m_max >= 0 else -1.0
            if current_val > best_val:
                self.m_max = self.m
                self.s_max = std
            elif self.m_max > 0 and self.error_count >= min_errors_for_detection:
                denom = self.m_max + 2 * self.s_max
                ratio = current_val / denom if denom > 0 else 1.0
                drift_limit = 0.9
                warning_limit = 0.95
                if ratio < drift_limit:
                    self.drifted = True
                elif ratio < warning_limit:
                    self.warning = True

        return self.drifted

    def clear(self) -> None:
        self.m = 0.0
        self.s = 0.0
        self.m_max = -1.0
        self.s_max = -1.0
        self.n = 0
        self.last_error_idx = 0
        self.drifted = False
        self.warning = False
        self.error_count = 0


class HddmA:
    """Hoeffding Drift Detection Method based on moving average (HDDM_A)."""

    def __init__(
        self, drift_confidence: float = 0.001, warning_confidence: float = 0.005
    ) -> None:
        if not (0.0 < drift_confidence < 1.0):
            raise ValueError("drift_confidence must be in (0, 1)")
        if not (0.0 < warning_confidence < 1.0):
            raise ValueError("warning_confidence must be in (0, 1)")
        if warning_confidence < drift_confidence:
            raise ValueError("warning_confidence should be >= drift_confidence")
        self.drift_confidence = drift_confidence
        self.warning_confidence = warning_confidence
        self.n = 0
        self.m = 0.0
        self.m_min = 1.0
        self.drifted = False
        self.warning = False

    def update(self, is_correct: bool) -> bool:
        self.warning = False
        self.n += 1
        val = 0.0 if is_correct else 1.0
        self.m += (val - self.m) / self.n

        self.m_min = min(self.m_min, self.m)

        epsilon = math.sqrt(math.log(1.0 / self.drift_confidence) / (2 * self.n))
        warning_eps = math.sqrt(math.log(1.0 / self.warning_confidence) / (2 * self.n))
        if self.m - self.m_min > epsilon:
            self.drifted = True
            self.warning = False
        elif self.m - self.m_min > warning_eps:
            self.drifted = False
            self.warning = True
        else:
            self.drifted = False

        return self.drifted

    def clear(self) -> None:
        self.n = 0
        self.m = 0.0
        self.m_min = 1.0
        self.drifted = False
        self.warning = False
