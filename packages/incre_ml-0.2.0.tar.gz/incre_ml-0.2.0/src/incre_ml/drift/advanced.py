import math
from typing import Any

from ..base.regressor import Regressor


class PageHinkleyDrift:
    """Page-Hinkley test for detecting change in a data stream mean."""

    def __init__(
        self, delta: float = 0.005, threshold: float = 50.0, alpha: float = 1.0 - 0.0001
    ) -> None:
        if delta < 0.0:
            raise ValueError("delta must be >= 0")
        if threshold <= 0.0:
            raise ValueError("threshold must be > 0")
        if not (0.0 < alpha <= 1.0):
            raise ValueError("alpha must be in (0, 1]")
        self.delta = delta
        self.threshold = threshold
        self.alpha = alpha
        self.sum = 0.0
        self.n = 0
        self.mean = 0.0
        self.drifted = False

    def update(self, value: float) -> bool:
        if not math.isfinite(value):
            raise ValueError("PageHinkleyDrift requires finite numeric values")
        self.n += 1
        self.mean += (value - self.mean) / self.n
        self.sum = self.alpha * self.sum + (value - self.mean - self.delta)

        if self.sum > self.threshold:
            self.drifted = True
        else:
            self.drifted = False

        return self.drifted

    def clear(self) -> None:
        self.sum = 0.0
        self.n = 0
        self.mean = 0.0
        self.drifted = False


class DriftAwareWrapper(Regressor):
    """Wraps a model with a drift detector and a response policy."""

    def __init__(
        self,
        model: Regressor,
        detector: Any,  # e.g., ADWIN or PageHinkleyDrift
        signal: str = "residual",
        policy: str = "reset",
    ) -> None:
        self.model = model
        self.detector = detector
        self.signal = signal
        self.policy = policy

    def learn_one(self, x: dict[str, Any], y: float) -> "DriftAwareWrapper":
        y_pred = self.model.predict_one(x)

        # Calculate signal for detector
        if self.signal == "residual":
            val = abs(y - y_pred)
        else:
            val = y

        drifted = self.detector.update(val)

        if drifted and self.policy == "reset":
            self.model.clear()
            self.detector.clear()

        self.model.learn_one(x, y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.model.predict_one(x)

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return self.model.explain_one(x)

    def clear(self) -> None:
        self.model.clear()
        self.detector.clear()
