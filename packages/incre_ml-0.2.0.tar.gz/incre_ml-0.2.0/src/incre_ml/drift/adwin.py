import math
from collections import deque
from typing import NamedTuple


class _Bucket(NamedTuple):
    total: float
    variance: float
    size: int


class ADWIN:
    """Adaptive Windowing (ADWIN) for concept drift detection.

    ADWIN maintains a sliding window of variable length and automatically
    detects changes in the mean of the values in the window.

    Uses exponential histogram (Bifet & Gavalda) for O(log n) per update.
    """

    def __init__(self, delta: float = 0.002, max_buckets: int = 5) -> None:
        if not (0.0 < delta < 1.0):
            raise ValueError("delta must be in (0, 1)")
        self.delta = float(delta)
        self.max_buckets = max(2, max_buckets)
        # Each level is a deque of _Bucket; level 0 = single observations
        self._bucket_rows: list[deque[_Bucket]] = []
        self._total = 0.0
        self._variance = 0.0
        self._count = 0
        self.width = 0
        self.drift_detected = False

    def _insert_bucket(self, total: float, variance: float, size: int) -> None:
        """Insert a new bucket at level 0 and compress upward."""
        bucket = _Bucket(total, variance, size)
        if not self._bucket_rows:
            self._bucket_rows.append(deque())
        self._bucket_rows[0].appendleft(bucket)

        # Compress: if a row has too many buckets, merge two oldest
        level = 0
        while level < len(self._bucket_rows):
            if len(self._bucket_rows[level]) <= self.max_buckets:
                break
            # Merge two oldest (rightmost) buckets
            b1 = self._bucket_rows[level].pop()
            b2 = self._bucket_rows[level].pop()
            merged_size = b1.size + b2.size
            merged_total = b1.total + b2.total
            # Combined variance using parallel algorithm
            delta_mean = (
                (b1.total / b1.size) - (b2.total / b2.size)
                if b1.size > 0 and b2.size > 0
                else 0.0
            )
            merged_variance = (
                b1.variance
                + b2.variance
                + delta_mean * delta_mean * (b1.size * b2.size) / merged_size
            )
            merged = _Bucket(merged_total, merged_variance, merged_size)

            level += 1
            if level >= len(self._bucket_rows):
                self._bucket_rows.append(deque())
            self._bucket_rows[level].appendleft(merged)

    def _delete_oldest(self) -> None:
        """Remove the oldest bucket (rightmost at highest level)."""
        for level in range(len(self._bucket_rows) - 1, -1, -1):
            if self._bucket_rows[level]:
                b = self._bucket_rows[level].pop()
                self._total -= b.total
                self._variance -= b.variance
                self._count -= b.size
                self.width -= b.size
                # Clean up empty trailing rows
                while self._bucket_rows and not self._bucket_rows[-1]:
                    self._bucket_rows.pop()
                return

    def update(self, value: float) -> bool:
        """Update the window with a new value and check for drift.

        Returns:
            True if drift was detected at this step.
        """
        if not math.isfinite(value):
            raise ValueError("ADWIN requires finite numeric values")
        self.drift_detected = False

        # Insert new single-observation bucket
        self._insert_bucket(value, 0.0, 1)
        self._total += value
        self._count += 1
        self.width += 1

        if self.width < 2:
            return False

        # Check for drift by scanning from newest to oldest
        self._check_drift()
        return self.drift_detected

    def _check_drift(self) -> None:
        """Check all bucket boundaries for significant mean difference."""
        min_width = 2
        found_change = True

        while found_change and self.width >= min_width:
            found_change = False
            w1_count = 0
            w1_total = 0.0

            # Iterate buckets from newest to oldest
            for level in range(len(self._bucket_rows)):
                for bucket in self._bucket_rows[level]:
                    w1_count += bucket.size
                    w1_total += bucket.total

                    w2_count = self._count - w1_count
                    if w1_count < 1 or w2_count < 1:
                        continue

                    w2_total = self._total - w1_total

                    m1 = w1_total / w1_count
                    m2 = w2_total / w2_count

                    m = 1.0 / (1.0 / w1_count + 1.0 / w2_count)
                    delta_p = max(self.delta / self.width, 1e-300)
                    epsilon = math.sqrt(
                        max(0.0, (1.0 / (2 * m)) * math.log(2.0 / delta_p))
                    )

                    if abs(m1 - m2) > epsilon:
                        found_change = True
                        self.drift_detected = True
                        self._delete_oldest()
                        break
                if found_change:
                    break

    @property
    def sum(self) -> float:
        return self._total

    def clear(self) -> None:
        """Reset ADWIN state."""
        self._bucket_rows = []
        self._total = 0.0
        self._variance = 0.0
        self._count = 0
        self.width = 0
        self.drift_detected = False
