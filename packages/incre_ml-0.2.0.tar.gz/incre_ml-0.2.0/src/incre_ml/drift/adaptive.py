import copy
from typing import Any, Literal

from ..base.classifier import Classifier
from ..base.regressor import Regressor
from .adwin import ADWIN


class DriftAdaptiveWrapper:
    """Wraps any model with automatic drift adaptation.

    Monitors prediction error using a drift detector and responds with
    one of three strategies when drift is detected.

    Strategies:
        "reset": Clear model state on drift.
        "decay": Halve effective learning by re-learning recent samples.
        "replacement": Train a fresh model in parallel, switch when it
                       outperforms the current model.
    """

    def __init__(
        self,
        model: Regressor | Classifier,
        drift_detector: ADWIN | None = None,
        strategy: Literal["reset", "decay", "replacement"] = "reset",
        grace_period: int = 100,
    ) -> None:
        self.model = model
        self.drift_detector = drift_detector or ADWIN(delta=0.002)
        self.strategy = strategy
        self.grace_period = grace_period
        self._n = 0
        self._drift_count = 0
        # For replacement strategy
        self._replacement_model: Regressor | Classifier | None = None
        self._replacement_errors: float = 0.0
        self._replacement_n: int = 0
        self._current_errors: float = 0.0
        self._current_n: int = 0

    def learn_one(self, x: dict[str, Any], y: Any) -> "DriftAdaptiveWrapper":
        self._n += 1

        # Get prediction error for drift detection
        if isinstance(self.model, Classifier):
            y_pred = self.model.predict_one(x)
            error = 0.0 if y_pred == y else 1.0
        else:
            y_pred_val = self.model.predict_one(x)
            error = abs(float(y) - float(y_pred_val))

        # Update drift detector
        drift = self.drift_detector.update(error)

        # Train replacement model if active
        if self._replacement_model is not None:
            if isinstance(self._replacement_model, Classifier):
                r_pred = self._replacement_model.predict_one(x)
                r_error = 0.0 if r_pred == y else 1.0
            else:
                r_pred_val = self._replacement_model.predict_one(x)
                r_error = abs(float(y) - float(r_pred_val))
            self._replacement_errors += r_error
            self._replacement_n += 1
            self._current_errors += error
            self._current_n += 1
            self._replacement_model.learn_one(x, y)

            # Check if replacement outperforms current
            if self._replacement_n >= self.grace_period:
                r_avg = self._replacement_errors / self._replacement_n
                c_avg = self._current_errors / self._current_n
                if r_avg < c_avg:
                    self.model = self._replacement_model
                    self._replacement_model = None
                    self._replacement_errors = 0.0
                    self._replacement_n = 0
                    self._current_errors = 0.0
                    self._current_n = 0

        # Train main model
        self.model.learn_one(x, y)

        # Handle drift
        if drift and self._n > self.grace_period:
            self._drift_count += 1
            self._handle_drift()

        return self

    def _handle_drift(self) -> None:
        if self.strategy == "reset":
            self.model.clear()
        elif self.strategy == "decay":
            # Reset detector to allow fresh assessment
            self.drift_detector.clear()
        elif self.strategy == "replacement":
            if self._replacement_model is None:
                self._replacement_model = copy.deepcopy(self.model)
                self._replacement_model.clear()
                self._replacement_errors = 0.0
                self._replacement_n = 0
                self._current_errors = 0.0
                self._current_n = 0

    def predict_one(self, x: dict[str, Any]) -> Any:
        return self.model.predict_one(x)

    def clear(self) -> None:
        self.model.clear()
        self.drift_detector.clear()
        self._n = 0
        self._drift_count = 0
        self._replacement_model = None
        self._replacement_errors = 0.0
        self._replacement_n = 0
        self._current_errors = 0.0
        self._current_n = 0

    @property
    def drift_count(self) -> int:
        return self._drift_count
