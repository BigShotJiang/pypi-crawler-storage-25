from typing import Any

from ..base.anomaly import Detector


class AnomalyEnsemble(Detector):
    """Ensemble for online anomaly detection.

    Combines multiple detectors (Statistical, Geometric, and ML)
    into a single robust anomaly score.
    """

    def __init__(
        self,
        detectors: dict[str, Detector],
        weights: dict[str, float] | None = None,
    ):
        if not detectors:
            raise ValueError("detectors must not be empty")
        self.detectors = detectors
        # Default to equal weighting
        self.weights = weights or {
            name: 1.0 / len(detectors) for name in detectors.keys()
        }
        if any(float(w) < 0.0 for w in self.weights.values()):
            raise ValueError("ensemble weights must be non-negative")
        total = float(sum(self.weights.get(name, 0.0) for name in self.detectors))
        if total <= 0.0:
            raise ValueError("sum of ensemble weights must be > 0")
        self.weights = {
            name: float(self.weights.get(name, 0.0)) / total for name in self.detectors
        }

    def score_one(self, x: dict[str, Any]) -> float:
        total_score = 0.0
        for name, detector in self.detectors.items():
            total_score += detector.score_one(x) * self.weights.get(name, 1.0)

        return total_score

    def learn_one(self, x: dict[str, Any]) -> "AnomalyEnsemble":
        for detector in self.detectors.values():
            detector.learn_one(x)
        return self

    def clear(self) -> None:
        for detector in self.detectors.values():
            detector.clear()

    def get_contributions(self, x: dict[str, Any]) -> dict[str, float]:
        """Returns the anomaly score for each individual detector."""
        return {name: det.score_one(x) for name, det in self.detectors.items()}
