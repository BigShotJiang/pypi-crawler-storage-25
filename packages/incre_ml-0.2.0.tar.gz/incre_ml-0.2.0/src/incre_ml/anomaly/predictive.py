from typing import Any

from ..base.anomaly import Detector
from ..base.regressor import Regressor
from ..stats.advanced import ResidualTracker
from ..stats.running import RunningStatistics


class PredictiveAnomalyDetector(Detector):
    """ML/Predictive Anomaly Detection.

    A point is anomalous if the model's prediction error is
    significantly higher than its historical average error.
    """

    def __init__(self, model: Regressor, feature_name: str):
        self.model = model
        self.feature_name = feature_name
        self.error_stats = RunningStatistics()
        self.last_prediction: float | None = None

    def score_one(self, x: dict[str, Any]) -> float:
        val = x.get(self.feature_name, 0.0)
        self.last_prediction = self.model.predict_one(x)

        min_samples = 5
        if self.error_stats.count < min_samples:
            return 0.0

        error = abs(val - self.last_prediction)

        std = self.error_stats.std_dev
        if std == 0:
            return 1.0 if error > self.error_stats.mean else 0.0

        z = (error - self.error_stats.mean) / std
        return float(max(0.0, min(1.0, z / 5.0)))  # Scale: z=5 is 100% anomaly

    def learn_one(self, x: dict[str, Any]) -> "PredictiveAnomalyDetector":
        val = x.get(self.feature_name, 0.0)
        if self.last_prediction is not None:
            error = abs(val - self.last_prediction)
            self.error_stats.update(error)

        self.model.learn_one(x, val)
        return self

    def clear(self) -> None:
        self.error_stats.clear()
        self.last_prediction = None
        if hasattr(self.model, "clear"):
            self.model.clear()


class ResidualZScoreDetector(Detector):
    """Predictive anomaly detection using standardized residuals.

    Requires the true label ``y`` in ``learn_one`` to compute residuals.
    The score exposed via ``score_one`` reflects the residual z-score from
    the most recent ``learn_one`` call (test-then-train protocol).

    Args:
        model: Any ``Regressor`` used to predict expected values.
        threshold: Number of residual standard deviations considered anomalous.
            Higher = less sensitive.
        min_samples: Warm-up period before scoring begins.
    """

    def __init__(
        self,
        model: Regressor,
        threshold: float = 3.0,
        min_samples: int = 5,
    ) -> None:
        self.model = model
        self.tracker = ResidualTracker()
        self.threshold = max(1e-9, float(threshold))
        self.min_samples = int(min_samples)
        self.last_score = 0.0

    def score_one(self, x: dict[str, Any]) -> float:
        # Score is based on the residual computed in the last learn_one call.
        _ = self.model.predict_one(x)
        return float(min(1.0, max(0.0, self.last_score)))

    def learn_one(
        self, x: dict[str, Any], y: float | None = None
    ) -> "ResidualZScoreDetector":
        if y is not None:
            y_pred = self.model.predict_one(x)
            residual = y - y_pred
            if self.tracker.stats.count >= self.min_samples:
                if self.tracker.std > 0.0:
                    z = abs((residual - self.tracker.mean) / self.tracker.std)
                    self.last_score = float(min(1.0, z / self.threshold))
                else:
                    self.last_score = (
                        1.0 if abs(residual - self.tracker.mean) > 0.0 else 0.0
                    )
            else:
                self.last_score = 0.0
            self.tracker.update(y, y_pred)
            self.model.learn_one(x, y)
        return self

    def clear(self) -> None:
        self.model.clear()
        self.tracker.clear()
        self.last_score = 0.0
