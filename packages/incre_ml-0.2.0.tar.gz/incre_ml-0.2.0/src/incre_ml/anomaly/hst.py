import random
from collections import deque
from typing import Any

from ..base.anomaly import Detector


class HSTNode:
    """A node in a Half-Space Tree."""

    def __init__(self, depth: int, max_depth: int) -> None:
        self.depth = depth
        self.max_depth = max_depth
        self.r = 0.0
        self.l = 0.0

        self.split_feat: str | None = None
        self.split_val: float | None = None
        self.left: HSTNode | None = None
        self.right: HSTNode | None = None

    def build(self, limits: dict[str, list[float]]) -> None:
        if self.depth == self.max_depth:
            return

        self.split_feat = random.choice(list(limits.keys()))
        min_val, max_val = limits[self.split_feat]
        self.split_val = (min_val + max_val) / 2.0

        left_limits = limits.copy()
        left_limits[self.split_feat] = [min_val, self.split_val]
        self.left = HSTNode(self.depth + 1, self.max_depth)
        self.left.build(left_limits)

        right_limits = limits.copy()
        right_limits[self.split_feat] = [self.split_val, max_val]
        self.right = HSTNode(self.depth + 1, self.max_depth)
        self.right.build(right_limits)


class HalfSpaceTrees(Detector):
    """Mathematical/Geometric Anomaly Detection (HST).

    A set of random trees that partition the space. Points in
    seldom-visited nodes are considered anomalous.
    """

    def __init__(
        self,
        n_trees: int = 25,
        max_depth: int = 15,
        window_size: int = 100,
        limits: dict[str, list[float]] | None = None,
    ) -> None:
        self.n_trees = n_trees
        self.max_depth = max_depth
        self.window_size = window_size
        self.limits = limits or {}
        self.trees: list[HSTNode] = []
        self.count = 0
        self._observed_max_mass = 1.0

        if limits:
            for _ in range(n_trees):
                tree = HSTNode(0, max_depth)
                tree.build(limits)
                self.trees.append(tree)

    def _get_leaf(self, tree: HSTNode, x: dict[str, Any]) -> HSTNode:
        node = tree
        while node.left and node.right:
            val = x.get(str(node.split_feat), 0.0)
            node = node.left if val <= float(node.split_val or 0.0) else node.right
        return node

    def score_one(self, x: dict[str, Any]) -> float:
        if not self.trees:
            return 0.0

        total_r_mass = 0.0
        for tree in self.trees:
            leaf = self._get_leaf(tree, x)
            total_r_mass += float(leaf.r * (2**leaf.depth))

        if self.count < self.window_size:
            return 0.0

        # Track observed max mass for better normalization
        self._observed_max_mass = max(self._observed_max_mass, total_r_mass)

        return float(max(0.0, 1.0 - (total_r_mass / self._observed_max_mass)))

    def learn_one(self, x: dict[str, Any]) -> "HalfSpaceTrees":
        if not self.trees:
            return self

        for tree in self.trees:
            leaf = self._get_leaf(tree, x)
            leaf.l += 1

        self.count += 1
        if self.count % self.window_size == 0:
            self._swap_counts(self.trees)

        return self

    def _swap_counts(self, nodes: list[HSTNode]) -> None:
        queue: deque[HSTNode] = deque(nodes)
        while queue:
            node = queue.popleft()
            node.r = node.l
            node.l = 0.0
            if node.left and node.right:
                queue.append(node.left)
                queue.append(node.right)

    def clear(self) -> None:
        self.count = 0
        self._observed_max_mass = 1.0
        queue: deque[HSTNode] = deque(self.trees)
        while queue:
            node = queue.popleft()
            node.r = 0.0
            node.l = 0.0
            if node.left and node.right:
                queue.append(node.left)
                queue.append(node.right)
