from typing import Any

from ..base.anomaly import Detector
from ..base.regressor import Regressor
from ..compose.wrappers import AlertSuppressionWrapper  # noqa: F401
from ..stats.advanced import EWMAStatistics, ResidualTracker
from .predictive import ResidualZScoreDetector  # noqa: F401


class EWMAControlChartDetector(Detector):
    """Anomaly detection using EWMA Control Charts."""

    def __init__(self, alpha: float = 0.5, l_param: float = 3.0) -> None:
        self.stats = EWMAStatistics(alpha=alpha)
        self.l_param = l_param  # Width of control limits in std devs

    def score_one(self, x: dict[str, Any]) -> float:
        val = next(iter(x.values())) if x else 0.0
        min_samples = 2
        if self.stats.n < min_samples:
            return 0.0

        std = self.stats.std_dev
        if std == 0:
            return 0.0

        z = abs(val - self.stats.mean) / std
        return float(min(1.0, z / (self.l_param * 2)))

    def learn_one(self, x: dict[str, Any]) -> "EWMAControlChartDetector":
        val = next(iter(x.values())) if x else 0.0
        self.stats.update(val)
        return self

    def clear(self) -> None:
        self.stats.clear()


class CUSUMDetector(Detector):
    """Cumulative Sum (CUSUM) detector for mean shifts."""

    def __init__(self, threshold: float = 5.0, drift: float = 0.5) -> None:
        self.threshold = threshold
        self.drift = drift
        self.g_plus = 0.0
        self.g_minus = 0.0
        self.mean = 0.0
        self.n = 0

    def score_one(self, x: dict[str, Any]) -> float:
        val = next(iter(x.values())) if x else 0.0
        if self.n == 0:
            return 0.0

        diff = val - self.mean
        gp = max(0.0, self.g_plus + diff - self.drift)
        gm = max(0.0, self.g_minus - diff - self.drift)

        score = max(gp, gm) / self.threshold
        return float(min(1.0, score))

    def learn_one(self, x: dict[str, Any]) -> "CUSUMDetector":
        val = next(iter(x.values())) if x else 0.0
        self.n += 1
        self.mean += (val - self.mean) / self.n

        diff = val - self.mean
        self.g_plus = max(0.0, self.g_plus + diff - self.drift)
        self.g_minus = max(0.0, self.g_minus - diff - self.drift)

        if self.g_plus > self.threshold or self.g_minus > self.threshold:
            # Reset after detection
            self.g_plus = 0.0
            self.g_minus = 0.0

        return self

    def clear(self) -> None:
        self.g_plus = 0.0
        self.g_minus = 0.0
        self.mean = 0.0
        self.n = 0


class SeasonalAnomalyDetector(Detector):
    """Detects anomalies by comparing to seasonal expectations."""

    def __init__(
        self, model: Regressor, threshold: float = 3.0, max_seasons: int = 256
    ) -> None:
        self.model = model
        self.tracker = ResidualTracker()
        self.threshold = max(1e-9, float(threshold))
        self.last_score = 0.0
        self.min_samples = 5
        self.max_seasons = max_seasons
        self.season_trackers: dict[Any, ResidualTracker] = {}
        self._access_order: dict[Any, int] = {}
        self._access_counter = 0

    def _season_key(self, x: dict[str, Any]) -> Any:
        for key in (
            "season",
            "season_idx",
            "hour",
            "hour_of_day",
            "dow",
            "day_of_week",
        ):
            if key in x:
                return (key, x[key])
        if "hour_sin" in x and "hour_cos" in x:
            hour_sin = float(x["hour_sin"])
            hour_cos = float(x["hour_cos"])
            return ("hour_phase", round(hour_sin, 3), round(hour_cos, 3))
        return ("global",)

    def _score_from_trackers(
        self, residual: float, season_tracker: ResidualTracker
    ) -> float:
        scores = []
        if season_tracker.stats.count >= self.min_samples:
            if season_tracker.std > 0.0:
                z_season = abs((residual - season_tracker.mean) / season_tracker.std)
                scores.append(z_season / self.threshold)
            elif abs(residual - season_tracker.mean) > 0.0:
                scores.append(1.0)
        if self.tracker.stats.count >= self.min_samples:
            if self.tracker.std > 0.0:
                z_global = abs((residual - self.tracker.mean) / self.tracker.std)
                scores.append(z_global / self.threshold)
            elif abs(residual - self.tracker.mean) > 0.0:
                scores.append(1.0)
        if not scores:
            return 0.0
        return float(min(1.0, max(scores)))

    def score_one(self, x: dict[str, Any]) -> float:
        _ = self.model.predict_one(x)
        return float(min(1.0, max(0.0, self.last_score)))

    def learn_one(
        self, x: dict[str, Any], y: float | None = None
    ) -> "SeasonalAnomalyDetector":
        if y is not None:
            y_pred = self.model.predict_one(x)
            residual = y - y_pred
            key = self._season_key(x)
            season_tracker = self.season_trackers.setdefault(key, ResidualTracker())
            # Track access order for LRU eviction
            self._access_counter += 1
            self._access_order[key] = self._access_counter
            # Evict least-recently-used key when over limit
            if len(self.season_trackers) > self.max_seasons:
                lru_key = min(self._access_order, key=self._access_order.get)  # type: ignore[arg-type]
                del self.season_trackers[lru_key]
                del self._access_order[lru_key]
            self.last_score = self._score_from_trackers(residual, season_tracker)
            self.tracker.update(y, y_pred)
            season_tracker.update(y, y_pred)
            self.model.learn_one(x, y)
        return self

    def clear(self) -> None:
        self.model.clear()
        self.tracker.clear()
        self.last_score = 0.0
        self.season_trackers.clear()
        self._access_order.clear()
        self._access_counter = 0
