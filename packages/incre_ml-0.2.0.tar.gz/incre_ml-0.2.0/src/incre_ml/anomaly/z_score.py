import math
from typing import Any

from ..base.anomaly import Detector
from ..stats.running import RunningStatistics


class ZScoreDetector(Detector):
    """Statistical anomaly detection using Z-Scores (6-sigma style).

    A point is anomalous if its value is many standard deviations away
    from the current mean.
    """

    def __init__(self, feature_name: str, window_size: int | None = None):
        self.feature_name = feature_name
        self.stats = RunningStatistics()
        # TODO: Implement windowed stats for drift adaptation

    def score_one(self, x: dict[str, Any]) -> float:
        val = x.get(self.feature_name, 0.0)
        min_samples = 2
        if self.stats.count < min_samples:
            return 0.0

        std = self.stats.std_dev
        if std == 0:
            return 1.0 if val != self.stats.mean else 0.0

        z_score = abs(val - self.stats.mean) / std

        # Normalize to 0-1 scale. A z-score of 3 is ~0.5, 6 is ~0.9
        # Sigmoid-like normalization:
        return 2 / (1 + math.exp(-0.5 * z_score)) - 1

    def learn_one(self, x: dict[str, Any]) -> "ZScoreDetector":
        val = x.get(self.feature_name, 0.0)
        self.stats.update(val)
        return self

    def clear(self) -> None:
        self.stats.clear()
