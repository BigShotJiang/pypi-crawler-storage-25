from typing import Any


class LinearAttributionExplainer:
    """Standardizes explainability for linear models."""

    @staticmethod
    def explain(model: Any, x: dict[str, Any]) -> dict[str, float]:
        """Explain a linear model's prediction."""
        if hasattr(model, "weights") and hasattr(model, "intercept_weight"):
            weights = model.weights
            intercept = model.intercept_weight

            expl = {"intercept": float(intercept)}
            for key, val in x.items():
                expl[key] = float(weights.get(key, 0.0) * val)
            return expl
        return {}
