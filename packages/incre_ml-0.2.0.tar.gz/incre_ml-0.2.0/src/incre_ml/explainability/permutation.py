from typing import Any

from ..base.regressor import Regressor
from ..stats.running import RunningCorrelation, RunningStatistics


class PermutationImportanceExplainer:
    """Model-agnostic permutation importance for online regressors.

    Estimates feature importance by measuring how much the absolute prediction
    error increases when each feature value is replaced by the feature's running
    mean (a simple proxy for permutation).  No shuffling of stored history is
    needed — this is an O(1) online approximation.

    Proper offline permutation importance shuffles each feature across the full
    dataset.  The online variant used here measures:
        importance(f) = |error_with_mean_f| - |baseline_error|
    averaged over a rolling window.  Positive values indicate a feature that
    hurts when its information is destroyed; negative values indicate a feature
    whose mean substitution accidentally improves predictions.

    Args:
        model: Any fitted ``Regressor``.
        window_size: Rolling window length for averaging importance estimates.
            0 means cumulative average.
    """

    def __init__(self, model: Regressor, window_size: int = 100) -> None:
        if window_size < 0:
            raise ValueError("window_size must be >= 0")
        self.model = model
        self.window_size = int(window_size)
        # Running mean of each feature (used as replacement value)
        self._feature_means: dict[str, RunningStatistics] = {}
        # Running mean of importance per feature
        self._importance: dict[str, RunningStatistics] = {}

    def update(self, x: dict[str, Any], y: float) -> "PermutationImportanceExplainer":
        """Update importance estimates with one observation.

        Should be called **after** ``model.learn_one(x, y)`` so the model has
        been updated but the current observation is still fresh for evaluation.
        """
        baseline_pred = self.model.predict_one(x)
        baseline_err = abs(y - baseline_pred)

        for feat, val in x.items():
            if not isinstance(val, int | float):
                continue

            # Ensure running stats exist for this feature
            if feat not in self._feature_means:
                self._feature_means[feat] = RunningStatistics()
                self._importance[feat] = RunningStatistics()

            feat_mean = self._feature_means[feat]
            feat_mean.update(float(val))

            if feat_mean.count < 2:
                continue

            # Replace feature with its running mean
            x_perturbed = dict(x)
            x_perturbed[feat] = feat_mean.mean
            perturbed_pred = self.model.predict_one(x_perturbed)
            perturbed_err = abs(y - perturbed_pred)

            delta = perturbed_err - baseline_err
            self._importance[feat].update(delta)

        return self

    def importances(self) -> dict[str, float]:
        """Return the current mean importance estimate per feature.

        Higher values = more important.  Features not yet seen return 0.0.
        """
        return {feat: stats.mean for feat, stats in self._importance.items()}

    def clear(self) -> None:
        self._feature_means.clear()
        self._importance.clear()


class StreamingFeatureImportance:
    """Streaming feature importance via running Pearson correlation.

    Maintains online ``Corr(feature_i, |residual|)`` for each feature.  A high
    positive correlation means the feature value is strongly linked to large
    prediction errors — a signal that the model has not yet learned that feature
    well, or that feature carries anomaly-relevant variance.

    Args:
        model: Any fitted ``Regressor``.
    """

    def __init__(self, model: Regressor) -> None:
        self.model = model
        self._correlations: dict[str, RunningCorrelation] = {}

    def update(self, x: dict[str, Any], y: float) -> "StreamingFeatureImportance":
        """Update correlations with one observation.

        Should be called after ``model.learn_one(x, y)``.
        """
        y_pred = self.model.predict_one(x)
        abs_residual = abs(y - y_pred)

        for feat, val in x.items():
            if not isinstance(val, int | float):
                continue
            if feat not in self._correlations:
                self._correlations[feat] = RunningCorrelation()
            self._correlations[feat].update(float(val), abs_residual)

        return self

    def importances(self) -> dict[str, float]:
        """Return ``|Corr(feature, |residual|)|`` per feature."""
        return {feat: abs(rc.correlation) for feat, rc in self._correlations.items()}

    def clear(self) -> None:
        self._correlations.clear()
