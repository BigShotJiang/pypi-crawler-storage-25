import math
import random
from typing import Any

import numpy as np
import pytest

from incre_ml.base.regressor import Regressor
from incre_ml.control import EpsilonGreedyBandit
from incre_ml.drift import ADWIN, EDDM, HddmA, PageHinkleyDrift
from incre_ml.forecasting import BootstrappedRegressor
from incre_ml.linear import LinearRegression
from incre_ml.model_selection import BanditModelSelector
from incre_ml.simulation import FaultInjection, SyntheticStreamGenerator
from incre_ml.uncertainty import ConformalRegressor, ResidualUncertaintyWrapper

pytestmark = pytest.mark.certification


class ConstantRegressor(Regressor):
    def __init__(self, value: float = 0.0) -> None:
        self.value = float(value)

    def learn_one(self, x: dict[str, Any], y: float) -> "ConstantRegressor":
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.value

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return {"constant": self.value}

    def clear(self) -> None:
        self.value = 0.0


def test_control_bandit_converges_to_best_arm_stationary() -> None:
    random.seed(11)
    rng = random.Random(777)
    bandit = EpsilonGreedyBandit(actions=["a", "b", "c"], epsilon=0.1)
    probs = {"a": 0.2, "b": 0.45, "c": 0.75}

    for _ in range(2500):
        action = bandit.select_action()
        reward = 1.0 if rng.random() < probs[action] else 0.0
        bandit.update(action, reward)

    assert max(bandit.values, key=bandit.values.get) == "c"
    assert bandit.values["c"] > bandit.values["b"] > bandit.values["a"]


def test_model_selection_tracks_low_error_model() -> None:
    selector = BanditModelSelector(
        models={
            "near": ConstantRegressor(100.0),
            "far": ConstantRegressor(25.0),
        },
        epsilon=0.0,
    )
    for _ in range(120):
        selector.learn_one({}, 100.0)

    assert selector.best_model_name == "near"
    assert selector.metrics["near"].get() < selector.metrics["far"].get()


def test_simulation_generator_matches_exact_trend_and_season_when_noise_zero() -> None:
    gen = SyntheticStreamGenerator(
        base_value=5.0,
        trend=1.25,
        seasonality={"period": 4.0, "amplitude": 2.0},
        noise_std=0.0,
        seed=123,
    )
    vals = [next(gen) for _ in range(8)]
    expected = [5.0, 8.25, 7.5, 6.75, 10.0, 13.25, 12.5, 11.75]
    assert vals == pytest.approx(expected, abs=1e-10)


def test_simulation_fault_injection_empirical_rates() -> None:
    random.seed(9)
    base = iter([0.0] * 4000)
    faulted = FaultInjection(
        base, spike_chance=0.08, spike_magnitude=7.0, stuck_chance=0.0
    )
    vals = [next(faulted) for _ in range(4000)]
    spike_rate = sum(abs(v) > 1e-12 for v in vals) / len(vals)
    assert 0.06 <= spike_rate <= 0.10


def test_drift_adwin_detects_step_change_with_bounded_latency() -> None:
    rng = np.random.default_rng(42)
    adwin = ADWIN(delta=0.01)

    for v in rng.normal(0.0, 0.05, size=200):
        adwin.update(float(v))

    detect_idx = None
    shifted = list(rng.normal(1.0, 0.05, size=220))
    for i, v in enumerate(shifted):
        if adwin.update(float(v)):
            detect_idx = i
            break
    assert detect_idx is not None
    assert detect_idx <= 140


def test_drift_eddm_signals_after_error_rate_shift() -> None:
    rng = random.Random(1234)
    eddm = EDDM()
    stream = [rng.random() < 0.95 for _ in range(150)] + [
        rng.random() < 0.65 for _ in range(240)
    ]
    first_signal = None
    for i, is_correct in enumerate(stream):
        eddm.update(is_correct)
        if eddm.warning or eddm.drifted:
            first_signal = i
            break
    assert first_signal is not None
    assert first_signal >= 150
    assert first_signal - 150 <= 180


def test_drift_hddma_signals_after_error_rate_shift() -> None:
    rng = random.Random(5678)
    h = HddmA(drift_confidence=0.001, warning_confidence=0.01)
    stream = [rng.random() < 0.97 for _ in range(180)] + [
        rng.random() < 0.65 for _ in range(260)
    ]
    first_signal = None
    for i, is_correct in enumerate(stream):
        h.update(is_correct)
        if h.warning or h.drifted:
            first_signal = i
            break
    assert first_signal is not None
    assert first_signal >= 180
    assert first_signal - 180 <= 180


def test_drift_page_hinkley_detects_upward_shift() -> None:
    ph = PageHinkleyDrift(delta=0.001, threshold=5.0, alpha=0.99)
    for _ in range(80):
        assert ph.update(0.0) is False
    detected = any(ph.update(2.0) for _ in range(120))
    assert detected


def test_uncertainty_conformal_empirical_coverage_near_target() -> None:
    rng = np.random.default_rng(321)
    alpha = 0.1
    model = ConformalRegressor(ConstantRegressor(0.0), window_size=300, alpha=alpha)

    covered = 0
    total = 0
    for i in range(1800):
        y = float(rng.normal(0.0, 1.0))
        pred, q = model.predict_with_uncertainty({})
        if i >= 400:
            total += 1
            if (pred - q) <= y <= (pred + q):
                covered += 1
        model.learn_one({}, y)

    empirical = covered / total
    assert empirical == pytest.approx(1.0 - alpha, abs=0.05)


def test_uncertainty_residual_wrapper_sigma_matches_noise_scale() -> None:
    rng = np.random.default_rng(654)
    target_sigma = 2.5
    model = ResidualUncertaintyWrapper(ConstantRegressor(0.0))

    for _ in range(1600):
        y = float(rng.normal(0.0, target_sigma))
        model.learn_one({}, y)

    _, sigma = model.predict_with_uncertainty({})
    assert math.isfinite(sigma)
    assert sigma == pytest.approx(target_sigma, abs=0.25)


def test_uncertainty_bootstrapped_regressor_produces_nonzero_spread_on_noisy_stream() -> (  # noqa: E501
    None
):
    np.random.seed(222)
    rng = np.random.default_rng(222)
    model = BootstrappedRegressor(LinearRegression(learning_rate=0.03), n_models=9)

    for t in range(500):
        x = {"x": float((t % 25) / 25.0)}
        y = float(4.0 * x["x"] + rng.normal(0.0, 0.25))
        model.learn_one(x, y)

    _, sigma = model.predict_with_uncertainty({"x": 0.5})
    assert math.isfinite(sigma)
    assert sigma > 0.0
