from incre_ml.federated.ensemble import FederatedEnsemble
from incre_ml.linear import LinearRegression


def test_federated_averaging():
    global_model = LinearRegression(learning_rate=0.1)
    ensemble = FederatedEnsemble(global_model, client_ids=["A", "B"])

    # Client A learns relationship for 'x1'
    for _ in range(50):
        ensemble.learn_one("A", {"x1": 1.0, "x2": 0.0}, 10.0)

    # Client B learns relationship for 'x2'
    for _ in range(50):
        ensemble.learn_one("B", {"x1": 0.0, "x2": 1.0}, 20.0)

    # Before sync, global model knows nothing
    assert ensemble.predict_global({"x1": 1.0, "x2": 1.0}) == 0.0

    # Sync knowledge
    ensemble.sync()

    # After sync, global model should have aggregated knowledge
    # Contribution from A: x1=10, Contribution from B: x2=20
    # Average expected: x1=5, x2=10 (since we did simple averaging of weights)
    pred = ensemble.predict_global({"x1": 1.0, "x2": 1.0})
    assert pred > 10.0
    assert pred < 20.0
