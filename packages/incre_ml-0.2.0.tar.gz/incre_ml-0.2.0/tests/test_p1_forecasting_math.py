import pytest

from incre_ml.forecasting import SNARIMAX, RecursiveLeastSquaresRegressor


def test_snarimax_regular_differencing_inverts_to_original_scale() -> None:
    model = SNARIMAX(p=1, d=1, q=1, learning_rate=0.05)

    # Linear trend: first difference is constant (=2)
    for t in range(1, 80):
        y = 2.0 * t + 5.0
        model.learn_one({}, y)

    pred_next = model.predict_one({})
    expected_next = 2.0 * 80 + 5.0
    assert pred_next == pytest.approx(expected_next, abs=6.0)


def test_snarimax_seasonal_differencing_tracks_periodic_series() -> None:
    model = SNARIMAX(p=1, p_seasonal=1, d_seasonal=1, s=4, learning_rate=0.05)

    seasonal = [10.0, 20.0, 30.0, 40.0]
    for i in range(120):
        model.learn_one({}, seasonal[i % 4])

    pred = model.predict_one({})
    assert pred == pytest.approx(10.0, abs=6.0)


def test_rls_l2_affects_shrinkage_magnitude() -> None:
    x = {"f": 1.0}
    y = 10.0
    low_reg = RecursiveLeastSquaresRegressor(l2=0.1, delta=0.1)
    high_reg = RecursiveLeastSquaresRegressor(l2=100.0, delta=0.1)

    for _ in range(30):
        low_reg.learn_one(x, y)
        high_reg.learn_one(x, y)

    pred_low = low_reg.predict_one(x)
    pred_high = high_reg.predict_one(x)
    assert pred_low > pred_high


def test_rls_supports_new_features_after_initialization() -> None:
    model = RecursiveLeastSquaresRegressor()

    model.learn_one({"a": 1.0}, 1.0)
    model.learn_one({"a": 1.0, "b": 2.0}, 5.0)
    pred = model.predict_one({"a": 1.0, "b": 2.0})
    assert isinstance(pred, float)
    assert "b" in model.feature_names
