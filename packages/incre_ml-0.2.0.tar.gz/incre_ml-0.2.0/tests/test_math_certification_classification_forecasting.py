import numpy as np
import pytest

from incre_ml.classification import (
    AbstainingClassifier,
    AdaptiveRandomForestClassifier,
    HoeffdingTreeClassifier,
    LogisticRegression,
    NaiveBayes,
    PassiveAggressiveClassifier,
    SGDClassifier,
)
from incre_ml.forecasting import (
    TSB,
    Croston,
    HoltWinters,
    KalmanFilterRegressor,
    ModelSelectorEnsemble,
    NaiveForecaster,
    SeasonalNaiveForecaster,
    WeightedExpertsEnsemble,
)
from incre_ml.metrics import MAE
from tests.fixtures.benchmark_streams import (
    binary_separable_stream,
    intermittent_stream,
    seasonal_stream,
    trend_stream,
)

pytestmark = pytest.mark.certification


def _progressive_accuracy(clf, stream, warmup: int = 200) -> float:
    correct = 0
    total = 0
    for i, sample in enumerate(stream):
        pred = clf.predict_one(sample.x)
        if i >= warmup:
            total += 1
            correct += int(pred == sample.y)
        clf.learn_one(sample.x, sample.y)
    return correct / max(1, total)


@pytest.mark.parametrize(
    "builder, min_acc",
    [
        (lambda: LogisticRegression(learning_rate=0.05), 0.92),
        (lambda: SGDClassifier(learning_rate=0.05, loss="log"), 0.90),
        (lambda: PassiveAggressiveClassifier(c_param=1.0), 0.88),
        (lambda: NaiveBayes(), 0.92),
        (lambda: HoeffdingTreeClassifier(grace_period=25, delta=0.01), 0.85),
        (lambda: AdaptiveRandomForestClassifier(n_models=5, grace_period=20), 0.87),
    ],
)
def test_classifiers_meet_reference_accuracy_on_separable_stream(
    builder, min_acc: float
) -> None:
    np.random.seed(101)
    stream = binary_separable_stream(n=1400, seed=101)
    clf = builder()
    acc = _progressive_accuracy(clf, stream)
    assert acc >= min_acc


def test_abstaining_classifier_improves_precision_at_high_threshold() -> None:
    stream = binary_separable_stream(n=1400, seed=202)
    base = LogisticRegression(learning_rate=0.05)
    wrapped = AbstainingClassifier(
        LogisticRegression(learning_rate=0.05), threshold=0.8
    )

    for sample in stream[:250]:
        base.learn_one(sample.x, sample.y)
        wrapped.learn_one(sample.x, sample.y)

    base_correct = 0
    base_total = 0
    wrapped_correct = 0
    wrapped_total = 0
    abstains = 0
    for sample in stream[250:]:
        pb = base.predict_one(sample.x)
        pw = wrapped.predict_one(sample.x)
        base_total += 1
        base_correct += int(pb == sample.y)
        if pw == "ABSTAIN":
            abstains += 1
        else:
            wrapped_total += 1
            wrapped_correct += int(pw == sample.y)
        base.learn_one(sample.x, sample.y)
        wrapped.learn_one(sample.x, sample.y)

    base_precision = base_correct / base_total
    wrapped_precision = wrapped_correct / max(1, wrapped_total)
    abstain_rate = abstains / (len(stream) - 250)

    assert wrapped_precision >= base_precision
    assert abstain_rate <= 0.35


def _progressive_mae(model, y_stream: list[float], warmup: int = 40) -> float:
    metric = MAE()
    for i, y in enumerate(y_stream):
        pred = model.predict_one({})
        if i >= warmup:
            metric.update(y, pred)
        model.learn_one({}, y)
    return metric.get()


def test_forecasting_trend_models_outperform_naive() -> None:
    stream = trend_stream(n=900, slope=0.2, noise=0.12, seed=11)
    naive = NaiveForecaster()
    hw = HoltWinters(season_length=6, alpha=0.5, beta=0.2, gamma=0.0)
    kf = KalmanFilterRegressor(process_noise=0.05, measurement_noise=0.2)

    mae_naive = _progressive_mae(naive, stream)
    mae_hw = _progressive_mae(hw, stream)
    mae_kf = _progressive_mae(kf, stream)

    assert mae_hw < mae_naive
    assert mae_kf < mae_naive


def test_forecasting_seasonal_models_outperform_naive() -> None:
    stream = seasonal_stream(n=1000, period=12, amplitude=8.0, noise=0.15, seed=12)
    naive = NaiveForecaster()
    seasonal_naive = SeasonalNaiveForecaster(season_length=12)
    hw = HoltWinters(season_length=12, alpha=0.4, beta=0.05, gamma=0.4)

    mae_naive = _progressive_mae(naive, stream, warmup=60)
    mae_sn = _progressive_mae(seasonal_naive, stream, warmup=60)
    mae_hw = _progressive_mae(hw, stream, warmup=60)

    assert mae_sn < mae_naive
    assert mae_hw < mae_naive


def test_forecasting_intermittent_models_are_reasonable() -> None:
    stream = intermittent_stream(n=800, seed=13)
    croston = Croston(alpha=0.2)
    tsb = TSB(alpha=0.2, beta=0.2)

    mae_croston = _progressive_mae(croston, stream, warmup=80)
    mae_tsb = _progressive_mae(tsb, stream, warmup=80)

    assert mae_croston >= 0.0
    assert mae_tsb >= 0.0
    assert abs(mae_croston - mae_tsb) < 3.5


def test_forecasting_ensembles_track_best_expert_or_better() -> None:
    stream = seasonal_stream(n=850, period=10, amplitude=6.0, noise=0.2, seed=14)
    experts_a = {
        "naive": NaiveForecaster(),
        "seasonal": SeasonalNaiveForecaster(season_length=10),
    }
    experts_b = {
        "naive": NaiveForecaster(),
        "seasonal": SeasonalNaiveForecaster(season_length=10),
    }
    selector = ModelSelectorEnsemble(experts_a)
    weighted = WeightedExpertsEnsemble(experts_b, eta=0.3)

    mae_selector = MAE()
    mae_weighted = MAE()
    mae_naive = MAE()
    mae_seasonal = MAE()
    naive = NaiveForecaster()
    seasonal = SeasonalNaiveForecaster(season_length=10)

    for i, y in enumerate(stream):
        p_sel = selector.predict_one({})
        p_wgt = weighted.predict_one({})
        p_n = naive.predict_one({})
        p_s = seasonal.predict_one({})
        if i >= 60:
            mae_selector.update(y, p_sel)
            mae_weighted.update(y, p_wgt)
            mae_naive.update(y, p_n)
            mae_seasonal.update(y, p_s)
        selector.learn_one({}, y)
        weighted.learn_one({}, y)
        naive.learn_one({}, y)
        seasonal.learn_one({}, y)

    best_single = min(mae_naive.get(), mae_seasonal.get())
    assert mae_selector.get() <= best_single + 0.35
    assert mae_weighted.get() <= best_single + 0.45
