import math

import pytest

from incre_ml.preprocessing import MinMaxScaler, SelectKBest, StandardScaler
from incre_ml.serving import PredictService
from incre_ml.tree import HoeffdingTreeRegressor


def test_hoeffding_tree_learns_step_split_with_clear_margin() -> None:
    tree = HoeffdingTreeRegressor(grace_period=10, delta=0.01, tau=0.01)
    for i in range(200):
        x = float(i % 20)
        y = 0.0 if x < 10.0 else 100.0
        tree.learn_one({"x": x}, y)

    pred_left = tree.predict_one({"x": 2.0})
    pred_right = tree.predict_one({"x": 18.0})
    assert pred_right - pred_left > 40.0


def test_hoeffding_tree_ignores_non_numeric_features_safely() -> None:
    tree = HoeffdingTreeRegressor(grace_period=5)
    for i in range(30):
        tree.learn_one({"x": float(i % 10), "region": "north"}, float(i % 2))
    pred = tree.predict_one({"x": 5.0, "region": "south"})
    assert isinstance(pred, float)
    assert math.isfinite(pred)


def test_preprocessing_non_numeric_features_are_passed_through() -> None:
    ss = StandardScaler()
    mm = MinMaxScaler()
    sk = SelectKBest(k=1)

    for i in range(1, 10):
        x = {"num": float(i), "cat": "A" if i % 2 else "B"}
        ss.learn_one(x)
        mm.learn_one(x)
        sk.learn_one(x, float(i))

    x_test = {"num": 5.0, "cat": "A"}
    xs = ss.transform_one(x_test)
    xm = mm.transform_one(x_test)
    xk = sk.transform_one(x_test)

    assert xs["cat"] == "A"
    assert xm["cat"] == "A"
    assert "cat" not in xk
    assert "num" in xk


def test_predict_service_validates_feature_payload_type() -> None:
    svc = PredictService(HoeffdingTreeRegressor())
    with pytest.raises(TypeError):
        svc.predict([])  # type: ignore[arg-type]
    with pytest.raises(TypeError):
        svc.update([], 1.0)  # type: ignore[arg-type]
