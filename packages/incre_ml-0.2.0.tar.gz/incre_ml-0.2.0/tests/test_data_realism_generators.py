from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd


def _load_app():
    repo_root = Path(__file__).resolve().parents[1]
    import sys

    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    import app

    return app


def test_generators_are_deterministic_for_same_n() -> None:
    app = _load_app()
    gens = [
        app.gen_mfg,
        app.gen_supply,
        app.gen_sales,
        app.gen_clinical,
        app.gen_auto,
        app.gen_hr,
        app.gen_energy,
    ]
    for gen in gens:
        a = gen(120)
        b = gen(120)
        pd.testing.assert_frame_equal(a, b, check_exact=False, rtol=0, atol=0)


def test_manufacturing_generator_ranges_and_missingness() -> None:
    app = _load_app()
    df = app.gen_mfg(800)
    assert {
        "temperature",
        "vibration",
        "pressure",
        "humidity",
        "defect_label",
    }.issubset(df.columns)
    assert df["temperature"].between(40, 120).all()
    assert df["pressure"].between(3.0, 6.0).all()
    assert df["humidity"].between(20, 80).all()
    miss_rate = df["vibration"].isna().mean()
    assert 0.005 <= miss_rate <= 0.10
    defect_rate = df["defect_label"].mean()
    assert 0.02 <= defect_rate <= 0.95


def test_supply_generator_has_valid_regions_and_plausible_demand() -> None:
    app = _load_app()
    df = app.gen_supply(365)
    assert sorted(df["region"].unique().tolist()) == ["East", "North", "South"]
    assert (df["demand"] >= 0).all()
    assert df["promo_flag"].isin([0, 1]).all()
    assert df["lead_time_days"].between(1, 15).all()
    # Promo days should on average increase demand in at least one region significantly.
    promo_mean = float(df.loc[df["promo_flag"] == 1, "demand"].mean())
    nonpromo_mean = float(df.loc[df["promo_flag"] == 0, "demand"].mean())
    assert promo_mean > nonpromo_mean


def test_sales_generator_realistic_rates_and_revenue_relationships() -> None:
    app = _load_app()
    df = app.gen_sales(24 * 30)
    assert (df["traffic"] > 0).mean() > 0.98
    assert df["conversion_rate"].between(0.0, 0.2).all()
    assert df["refund_rate"].between(0.0, 0.35).all()
    assert (df["revenue"] >= 0).all()
    corr = float(df[["traffic", "revenue"]].corr().iloc[0, 1])
    assert np.isfinite(corr)
    assert corr > 0.4


def test_clinical_generator_plausible_vitals_and_missing_lactate() -> None:
    app = _load_app()
    df = app.gen_clinical(600)
    assert df["temp_c"].between(34.0, 41.5).all()
    assert df["hr_bpm"].between(30, 220).all()
    assert df["rr_bpm"].between(5, 60).all()
    assert df["spo2_pct"].between(80, 101).all()
    assert df["triage_class"].isin([0, 1, 2]).all()
    lactate_missing = df["lactate"].isna().mean()
    assert 0.005 <= lactate_missing <= 0.10


def test_automotive_generator_vehicle_telemetry_ranges() -> None:
    app = _load_app()
    df = app.gen_auto(1500)
    assert {
        "speed_kmh",
        "headway_s",
        "acceleration_ms2",
        "ttc_s",
        "lane_change",
    }.issubset(df.columns)
    assert df["speed_kmh"].between(0, 220).all()
    assert df["headway_s"].between(0.2, 8.0).all()
    assert df["ttc_s"].between(0, 20).all()
    assert df["lane_change"].isin([0, 1]).all()
    # Physics constraint: acceleration bounded by ±10 m/s²
    assert df["acceleration_ms2"].between(-10.0, 10.0).all()
    # Tailgating drift at 55%: headway should be lower in second half
    n = len(df)
    mid = n // 2
    late_headway = float(df["headway_s"].iloc[mid:].mean())
    early_headway = float(df["headway_s"].iloc[:mid].mean())
    assert late_headway < early_headway  # headway decreases during tailgating phase


def test_cybersecurity_generator_plausible_security_features() -> None:
    app = _load_app()
    df = app.gen_hr(1440)  # 24 hours of minute data
    assert {
        "request_rate",
        "latency_p95_ms",
        "error_rate",
        "auth_failures",
        "bytes_out_mb",
    }.issubset(df.columns)
    assert (df["request_rate"] > 0).mean() > 0.98
    assert (df["auth_failures"] >= 0).all()
    assert (df["bytes_out_mb"] >= 0).all()
    assert df["error_rate"].between(0, 1).all()
    # During attack phase (55%+), auth_failures and bytes_out_mb should be elevated
    split = int(0.65 * len(df))
    attack_auth = float(df["auth_failures"].iloc[split:].mean())
    normal_auth = float(df["auth_failures"].iloc[:split].mean())
    assert attack_auth > normal_auth
    attack_egress = float(df["bytes_out_mb"].iloc[split:].mean())
    normal_egress = float(df["bytes_out_mb"].iloc[:split].mean())
    assert attack_egress > normal_egress


def test_energy_generator_plausible_thermal_and_power_relationships() -> None:
    app = _load_app()
    df = app.gen_energy(1200)
    assert df["occupancy_flag"].isin([0, 1]).all()
    assert df["outdoor_temp"].between(-20, 40).all()
    assert df["indoor_temp"].between(10, 40).all()
    assert (df["power_kw"] >= 0).all()
    hvac_abs = df["hvac_signal"].abs()
    corr = float(
        pd.DataFrame({"hvac_abs": hvac_abs, "power_kw": df["power_kw"]})
        .corr()
        .iloc[0, 1]
    )
    assert np.isfinite(corr)
    assert corr > 0.35
