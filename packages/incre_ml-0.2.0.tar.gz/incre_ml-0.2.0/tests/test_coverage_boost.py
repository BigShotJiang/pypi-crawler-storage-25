"""Tests to boost overall project coverage from ~73% to 80%+.

Covers modules that previously had 0% or very low test coverage.
"""

import math
import os
import tempfile

import pytest

# ---------------------------------------------------------------------------
# 1. PermutationImportanceExplainer & StreamingFeatureImportance
# ---------------------------------------------------------------------------


def test_permutation_explainer_basic():
    from incre_ml.explainability.permutation import PermutationImportanceExplainer
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    explainer = PermutationImportanceExplainer(model, window_size=50)

    for i in range(30):
        x = {"a": float(i), "b": float(i * 2)}
        y = 3.0 * i + 1.0
        model.learn_one(x, y)
        explainer.update(x, y)

    imp = explainer.importances()
    assert isinstance(imp, dict)
    # After enough samples, features should have importance values
    assert "a" in imp or "b" in imp


def test_permutation_explainer_clear():
    from incre_ml.explainability.permutation import PermutationImportanceExplainer
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    explainer = PermutationImportanceExplainer(model, window_size=0)

    for i in range(5):
        x = {"a": float(i)}
        model.learn_one(x, float(i))
        explainer.update(x, float(i))

    explainer.clear()
    assert explainer.importances() == {}


def test_permutation_explainer_negative_window():
    from incre_ml.explainability.permutation import PermutationImportanceExplainer
    from incre_ml.linear import LinearRegression

    with pytest.raises(ValueError, match="window_size must be >= 0"):
        PermutationImportanceExplainer(LinearRegression(), window_size=-1)


def test_permutation_explainer_returns_self():
    from incre_ml.explainability.permutation import PermutationImportanceExplainer
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    explainer = PermutationImportanceExplainer(model, window_size=10)

    x = {"a": 1.0}
    model.learn_one(x, 1.0)
    result = explainer.update(x, 1.0)
    assert result is explainer


def test_streaming_feature_importance():
    from incre_ml.explainability.permutation import StreamingFeatureImportance
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    sfi = StreamingFeatureImportance(model)

    for i in range(20):
        x = {"a": float(i), "b": float(i * 0.5)}
        y = 2.0 * i
        model.learn_one(x, y)
        result = sfi.update(x, y)
        assert result is sfi  # returns self

    imp = sfi.importances()
    assert isinstance(imp, dict)
    for v in imp.values():
        assert v >= 0.0  # absolute correlation

    sfi.clear()
    assert sfi.importances() == {}


def test_streaming_feature_importance_multiple_features():
    from incre_ml.explainability.permutation import StreamingFeatureImportance
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    sfi = StreamingFeatureImportance(model)

    for i in range(10):
        x = {"a": float(i), "b": float(i * 0.1)}
        model.learn_one(x, float(i))
        sfi.update(x, float(i))

    imp = sfi.importances()
    assert "a" in imp
    assert "b" in imp


# ---------------------------------------------------------------------------
# 2. LinearAttributionExplainer
# ---------------------------------------------------------------------------


def test_linear_explainer_with_weights():
    from incre_ml.explainability.linear import LinearAttributionExplainer
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    for i in range(20):
        model.learn_one({"a": float(i), "b": 1.0}, float(i) * 2.0)

    expl = LinearAttributionExplainer.explain(model, {"a": 5.0, "b": 1.0})
    assert "intercept" in expl
    assert "a" in expl
    assert "b" in expl


def test_linear_explainer_no_weights():
    from incre_ml.explainability.linear import LinearAttributionExplainer

    class Dummy:
        pass

    expl = LinearAttributionExplainer.explain(Dummy(), {"a": 1.0})
    assert expl == {}


# ---------------------------------------------------------------------------
# 3. UncertaintySampler
# ---------------------------------------------------------------------------


def test_uncertainty_sampler_basic():
    from incre_ml.active.uncertainty_sampling import UncertaintySampler
    from incre_ml.classification import NaiveBayes

    model = NaiveBayes()
    sampler = UncertaintySampler(model, threshold=0.3)

    # Initially uncertain (no training data) -> should_label returns True
    assert sampler.should_label({"a": 1.0}) is True
    assert sampler.query_rate > 0.0

    # Train on some data
    for _ in range(20):
        sampler.learn_one({"a": 1.0, "b": 0.0}, "cat")
        sampler.learn_one({"a": 0.0, "b": 1.0}, "dog")

    pred = sampler.predict_one({"a": 1.0, "b": 0.0})
    assert pred in ("cat", "dog")

    probas = sampler.predict_proba_one({"a": 1.0, "b": 0.0})
    assert isinstance(probas, dict)


def test_uncertainty_sampler_threshold_validation():
    from incre_ml.active.uncertainty_sampling import UncertaintySampler
    from incre_ml.classification import NaiveBayes

    with pytest.raises(ValueError, match="threshold must be in"):
        UncertaintySampler(NaiveBayes(), threshold=0.0)
    with pytest.raises(ValueError, match="threshold must be in"):
        UncertaintySampler(NaiveBayes(), threshold=1.5)


def test_uncertainty_sampler_clear():
    from incre_ml.active.uncertainty_sampling import UncertaintySampler
    from incre_ml.classification import NaiveBayes

    sampler = UncertaintySampler(NaiveBayes(), threshold=0.5)
    sampler.should_label({"a": 1.0})
    sampler.learn_one({"a": 1.0}, "cat")
    sampler.clear()
    assert sampler._n_queries == 0
    assert sampler._n_total == 0
    assert sampler.query_rate == 0.0


# ---------------------------------------------------------------------------
# 4. prequential_score
# ---------------------------------------------------------------------------


def test_prequential_score_basic():
    from incre_ml.evaluate.prequential import prequential_score
    from incre_ml.linear import LinearRegression
    from incre_ml.metrics.regression import MAE

    model = LinearRegression(learning_rate=0.01)
    stream = [({"x": float(i)}, float(i) * 2.0) for i in range(50)]
    metric = MAE()

    score = prequential_score(model, stream, metric)
    assert isinstance(score, float)
    assert score >= 0.0


def test_prequential_score_with_print(capsys):
    from incre_ml.evaluate.prequential import prequential_score
    from incre_ml.linear import LinearRegression
    from incre_ml.metrics.regression import MAE

    model = LinearRegression(learning_rate=0.01)
    stream = [({"x": float(i)}, float(i)) for i in range(10)]
    metric = MAE()

    prequential_score(model, stream, metric, print_every=5)
    captured = capsys.readouterr()
    assert "[5]" in captured.out
    assert "[10]" in captured.out


# ---------------------------------------------------------------------------
# 5. ConstraintViolationRate (physics metric)
# ---------------------------------------------------------------------------


def test_constraint_violation_rate():
    from incre_ml.metrics.physics import ConstraintViolationRate

    m = ConstraintViolationRate()
    assert m.get() == 0.0

    m.update(1.0, 1.0, violation=0.5)
    m.update(1.0, 1.0, violation=0.0)
    m.update(1.0, 1.0, violation=1.0)
    assert m.get() == pytest.approx(2.0 / 3.0)

    m.clear()
    assert m.get() == 0.0


def test_constraint_violation_rate_no_violations():
    from incre_ml.metrics.physics import ConstraintViolationRate

    m = ConstraintViolationRate()
    for _ in range(5):
        m.update(1.0, 1.0, violation=0.0)
    assert m.get() == 0.0


# ---------------------------------------------------------------------------
# 6. MultiOutputRegressor
# ---------------------------------------------------------------------------


def test_multi_output_regressor():
    from incre_ml.base.multi_output import MultiOutputRegressor
    from incre_ml.linear import LinearRegression

    mor = MultiOutputRegressor(LinearRegression, learning_rate=0.1)

    for i in range(20):
        x = {"a": float(i)}
        y = {"t1": float(i) * 2, "t2": float(i) * 3}
        mor.learn_one(x, y)

    preds = mor.predict_one({"a": 5.0})
    assert "t1" in preds
    assert "t2" in preds
    assert isinstance(preds["t1"], float)

    expl = mor.explain_one({"a": 5.0})
    assert "t1" in expl
    assert "t2" in expl

    mor.clear()
    assert mor._models == {}


# ---------------------------------------------------------------------------
# 7. CsvStream
# ---------------------------------------------------------------------------


def test_csv_stream_basic():
    from incre_ml.io.csv_stream import csv_stream

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write("a,b,target\n")
        f.write("1.0,hello,3.0\n")
        f.write("2.5,world,6.0\n")
        path = f.name

    try:
        rows = list(csv_stream(path, target_column="target"))
        assert len(rows) == 2

        x0, y0 = rows[0]
        assert x0["a"] == 1.0
        assert x0["b"] == "hello"  # non-numeric stays string
        assert y0 == 3.0

        x1, y1 = rows[1]
        assert x1["a"] == 2.5
        assert y1 == 6.0
    finally:
        os.unlink(path)


def test_csv_stream_missing_target():
    from incre_ml.io.csv_stream import csv_stream

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write("a,b\n")
        f.write("1.0,2.0\n")
        path = f.name

    try:
        rows = list(csv_stream(path, target_column="target"))
        assert len(rows) == 1
        _, y = rows[0]
        assert y is None
    finally:
        os.unlink(path)


def test_csv_stream_string_target():
    from incre_ml.io.csv_stream import csv_stream

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".csv", delete=False, newline=""
    ) as f:
        f.write("a,target\n")
        f.write("1.0,cat\n")
        path = f.name

    try:
        rows = list(csv_stream(path, target_column="target"))
        _, y = rows[0]
        assert y == "cat"
    finally:
        os.unlink(path)


# ---------------------------------------------------------------------------
# 8. MondrianForestRegressor
# ---------------------------------------------------------------------------


def test_mondrian_forest_learn_predict():
    from incre_ml.tree.mondrian import MondrianForestRegressor

    mf = MondrianForestRegressor(n_trees=5, lifetime=5.0, seed=42)

    for i in range(50):
        x = {"a": float(i), "b": float(i % 5)}
        mf.learn_one(x, float(i) * 2.0)

    pred = mf.predict_one({"a": 25.0, "b": 0.0})
    assert isinstance(pred, float)


def test_mondrian_forest_predict_interval():
    from incre_ml.tree.mondrian import MondrianForestRegressor

    mf = MondrianForestRegressor(n_trees=5, lifetime=5.0, seed=42)

    for i in range(30):
        mf.learn_one({"a": float(i)}, float(i))

    mean, lo, hi = mf.predict_interval({"a": 15.0})
    assert isinstance(mean, float)
    assert lo <= mean <= hi or lo == hi == mean


def test_mondrian_forest_explain():
    from incre_ml.tree.mondrian import MondrianForestRegressor

    mf = MondrianForestRegressor(n_trees=3, lifetime=3.0, seed=42)
    for i in range(20):
        mf.learn_one({"a": float(i)}, float(i))

    expl = mf.explain_one({"a": 10.0})
    assert "mean_prediction" in expl
    assert "epistemic_std" in expl
    assert "n_trees" in expl
    assert expl["n_trees"] == 3.0


def test_mondrian_forest_clear():
    from incre_ml.tree.mondrian import MondrianForestRegressor

    mf = MondrianForestRegressor(n_trees=3, lifetime=3.0, seed=42)
    for i in range(10):
        mf.learn_one({"a": float(i)}, float(i))

    mf.clear()
    pred = mf.predict_one({"a": 5.0})
    assert pred == 0.0


def test_mondrian_forest_validation():
    from incre_ml.tree.mondrian import MondrianForestRegressor

    with pytest.raises(ValueError, match="n_trees must be >= 1"):
        MondrianForestRegressor(n_trees=0)
    with pytest.raises(ValueError, match="lifetime must be > 0"):
        MondrianForestRegressor(lifetime=-1.0)


def test_mondrian_single_tree():
    from incre_ml.tree.mondrian import MondrianForestRegressor

    mf = MondrianForestRegressor(n_trees=1, lifetime=5.0, seed=42)
    for i in range(20):
        mf.learn_one({"a": float(i)}, float(i))

    mean, lo, hi = mf.predict_interval({"a": 10.0})
    # With 1 tree, interval should be degenerate
    assert lo == mean == hi

    expl = mf.explain_one({"a": 10.0})
    assert expl["epistemic_std"] == 0.0


# ---------------------------------------------------------------------------
# 9. WindowedKNN
# ---------------------------------------------------------------------------


def test_windowed_knn_basic():
    from incre_ml.classification.knn import WindowedKNN

    knn = WindowedKNN(k=3, max_size=100)

    # No data -> empty predictions
    assert knn.predict_one({"a": 1.0}) == ""
    assert knn.predict_proba_one({"a": 1.0}) == {}

    # Train
    for i in range(20):
        knn.learn_one({"a": float(i), "b": 0.0}, "A")
    for i in range(20, 40):
        knn.learn_one({"a": float(i), "b": 1.0}, "B")

    pred = knn.predict_one({"a": 5.0, "b": 0.0})
    assert pred == "A"

    pred_b = knn.predict_one({"a": 35.0, "b": 1.0})
    assert pred_b == "B"


def test_windowed_knn_probas():
    from incre_ml.classification.knn import WindowedKNN

    knn = WindowedKNN(k=5, max_size=50)
    for i in range(10):
        knn.learn_one({"x": float(i)}, "cat")
    for i in range(10, 20):
        knn.learn_one({"x": float(i)}, "dog")

    probas = knn.predict_proba_one({"x": 5.0})
    assert isinstance(probas, dict)
    total = sum(probas.values())
    assert abs(total - 1.0) < 1e-6


def test_windowed_knn_explain():
    from incre_ml.classification.knn import WindowedKNN

    knn = WindowedKNN(k=3, max_size=50)
    for i in range(10):
        knn.learn_one({"x": float(i), "y": float(i * 2)}, "A")

    expl = knn.explain_one({"x": 5.0, "y": 10.0})
    assert isinstance(expl, dict)
    assert "x" in expl


def test_windowed_knn_explain_empty():
    from incre_ml.classification.knn import WindowedKNN

    knn = WindowedKNN(k=3)
    assert knn.explain_one({"x": 1.0}) == {}


def test_windowed_knn_clear():
    from incre_ml.classification.knn import WindowedKNN

    knn = WindowedKNN(k=3, max_size=50)
    knn.learn_one({"x": 1.0}, "A")
    knn.clear()
    assert knn.predict_one({"x": 1.0}) == ""


def test_windowed_knn_validation():
    from incre_ml.classification.knn import WindowedKNN

    with pytest.raises(ValueError, match="k must be > 0"):
        WindowedKNN(k=0)
    with pytest.raises(ValueError, match="max_size must be > 0"):
        WindowedKNN(max_size=0)


# ---------------------------------------------------------------------------
# 10. StackingRegressor & StackingClassifier
# ---------------------------------------------------------------------------


def test_stacking_regressor():
    from incre_ml.compose.stacking import StackingRegressor
    from incre_ml.linear import LinearRegression

    base = [LinearRegression(learning_rate=0.01), LinearRegression(learning_rate=0.05)]
    meta = LinearRegression(learning_rate=0.01)
    stack = StackingRegressor(base, meta, include_original=True)

    for i in range(30):
        x = {"a": float(i), "b": float(i * 0.5)}
        stack.learn_one(x, float(i) * 2.0)

    pred = stack.predict_one({"a": 10.0, "b": 5.0})
    assert isinstance(pred, float)

    expl = stack.explain_one({"a": 10.0, "b": 5.0})
    assert isinstance(expl, dict)

    stack.clear()


def test_stacking_regressor_no_original():
    from incre_ml.compose.stacking import StackingRegressor
    from incre_ml.linear import LinearRegression

    base = [LinearRegression(learning_rate=0.01)]
    meta = LinearRegression(learning_rate=0.01)
    stack = StackingRegressor(base, meta, include_original=False)

    stack.learn_one({"a": 1.0}, 2.0)
    pred = stack.predict_one({"a": 1.0})
    assert isinstance(pred, float)


def test_stacking_regressor_empty():
    from incre_ml.compose.stacking import StackingRegressor
    from incre_ml.linear import LinearRegression

    with pytest.raises(ValueError, match="Must provide at least one base model"):
        StackingRegressor([], LinearRegression())


def test_stacking_classifier():
    from incre_ml.classification import NaiveBayes
    from incre_ml.compose.stacking import StackingClassifier

    base = [NaiveBayes(), NaiveBayes()]
    meta = NaiveBayes()
    stack = StackingClassifier(base, meta, include_original=True)

    for i in range(20):
        x = {"a": float(i % 5)}
        label = "A" if i % 2 == 0 else "B"
        stack.learn_one(x, label)

    pred = stack.predict_one({"a": 2.0})
    assert pred in ("A", "B", "")

    probas = stack.predict_proba_one({"a": 2.0})
    assert isinstance(probas, dict)

    expl = stack.explain_one({"a": 2.0})
    assert isinstance(expl, dict)

    stack.clear()


def test_stacking_classifier_no_original():
    from incre_ml.classification import NaiveBayes
    from incre_ml.compose.stacking import StackingClassifier

    base = [NaiveBayes()]
    meta = NaiveBayes()
    stack = StackingClassifier(base, meta, include_original=False)

    stack.learn_one({"a": 1.0}, "X")
    pred = stack.predict_one({"a": 1.0})
    assert isinstance(pred, (str, int))


def test_stacking_classifier_empty():
    from incre_ml.classification import NaiveBayes
    from incre_ml.compose.stacking import StackingClassifier

    with pytest.raises(ValueError, match="Must provide at least one base classifier"):
        StackingClassifier([], NaiveBayes())


# ---------------------------------------------------------------------------
# 11. ConformalRegressor & AdaptiveConformalRegressor
# ---------------------------------------------------------------------------


def test_conformal_regressor():
    from incre_ml.linear import LinearRegression
    from incre_ml.uncertainty.conformal import ConformalRegressor

    model = LinearRegression(learning_rate=0.01)
    cr = ConformalRegressor(model, window_size=50, alpha=0.1)

    # Before learning
    pred, interval = cr.predict_with_uncertainty({"x": 1.0})
    assert interval == 0.0  # no residuals yet

    for i in range(30):
        x = {"x": float(i)}
        cr.learn_one(x, float(i) * 2.0)

    pred, interval = cr.predict_with_uncertainty({"x": 15.0})
    assert isinstance(pred, float)
    assert interval >= 0.0

    expl = cr.explain_one({"x": 15.0})
    assert "conformal_interval" in expl

    cr.clear()
    _, interval_after_clear = cr.predict_with_uncertainty({"x": 1.0})
    assert interval_after_clear == 0.0


def test_conformal_regressor_validation():
    from incre_ml.linear import LinearRegression
    from incre_ml.uncertainty.conformal import ConformalRegressor

    with pytest.raises(ValueError, match="window_size must be > 0"):
        ConformalRegressor(LinearRegression(), window_size=0)
    with pytest.raises(ValueError, match="alpha must be in"):
        ConformalRegressor(LinearRegression(), alpha=0.0)
    with pytest.raises(ValueError, match="alpha must be in"):
        ConformalRegressor(LinearRegression(), alpha=1.0)


def test_adaptive_conformal_regressor():
    from incre_ml.linear import LinearRegression
    from incre_ml.uncertainty.conformal import AdaptiveConformalRegressor

    model = LinearRegression(learning_rate=0.01)
    acr = AdaptiveConformalRegressor(model, window_size=50, alpha=0.1, gamma=0.05)

    for i in range(60):
        x = {"x": float(i)}
        acr.learn_one(x, float(i) * 2.0)

    pred, interval = acr.predict_with_uncertainty({"x": 30.0})
    assert isinstance(pred, float)
    assert interval >= 0.0

    # Alpha should have adapted
    expl = acr.explain_one({"x": 30.0})
    assert "adaptive_conformal_interval" in expl
    assert "current_alpha" in expl

    acr.clear()
    assert acr.alpha == acr.target_alpha


def test_adaptive_conformal_validation():
    from incre_ml.linear import LinearRegression
    from incre_ml.uncertainty.conformal import AdaptiveConformalRegressor

    with pytest.raises(ValueError, match="window_size must be > 0"):
        AdaptiveConformalRegressor(LinearRegression(), window_size=0)
    with pytest.raises(ValueError, match="alpha must be in"):
        AdaptiveConformalRegressor(LinearRegression(), alpha=0.0)
    with pytest.raises(ValueError, match="gamma must be > 0"):
        AdaptiveConformalRegressor(LinearRegression(), gamma=0)


# ---------------------------------------------------------------------------
# 12. FederatedAveraging, ReputationWeightedAggregation, FedProxAggregation
# ---------------------------------------------------------------------------


def test_federated_averaging_basic():
    from incre_ml.federated.aggregation import FederatedAveraging

    w1 = {"weights": {"a": 1.0, "b": 2.0}, "bias": 0.5, "classes": {"A", "B"}}
    w2 = {"weights": {"a": 3.0, "b": 4.0}, "bias": 1.5, "classes": {"A", "C"}}

    agg = FederatedAveraging.aggregate([w1, w2])
    assert agg["weights"]["a"] == pytest.approx(2.0)
    assert agg["weights"]["b"] == pytest.approx(3.0)
    assert agg["bias"] == pytest.approx(1.0)
    assert agg["classes"] == {"A", "B", "C"}


def test_federated_averaging_empty():
    from incre_ml.federated.aggregation import FederatedAveraging

    assert FederatedAveraging.aggregate([]) == {}


def test_federated_averaging_custom_weights():
    from incre_ml.federated.aggregation import FederatedAveraging

    w1 = {"val": 10.0}
    w2 = {"val": 20.0}

    agg = FederatedAveraging.aggregate([w1, w2], weights=[3.0, 1.0])
    # Normalized: [0.75, 0.25] -> 10*0.75 + 20*0.25 = 12.5
    assert agg["val"] == pytest.approx(12.5)


def test_federated_averaging_mismatched_weights():
    from incre_ml.federated.aggregation import FederatedAveraging

    with pytest.raises(ValueError, match="weights length"):
        FederatedAveraging.aggregate([{"a": 1.0}], weights=[1.0, 2.0])


def test_federated_averaging_negative_weights():
    from incre_ml.federated.aggregation import FederatedAveraging

    with pytest.raises(ValueError, match="weights must be non-negative"):
        FederatedAveraging.aggregate([{"a": 1.0}, {"a": 2.0}], weights=[1.0, -1.0])


def test_federated_averaging_mismatched_keys():
    from incre_ml.federated.aggregation import FederatedAveraging

    with pytest.raises(ValueError, match="identical top-level keys"):
        FederatedAveraging.aggregate([{"a": 1.0}, {"b": 2.0}])


def test_federated_averaging_string_values():
    from incre_ml.federated.aggregation import FederatedAveraging

    w1 = {"name": "model_a"}
    w2 = {"name": "model_b"}
    agg = FederatedAveraging.aggregate([w1, w2])
    assert agg["name"] == "model_a"  # non-numeric: returns first


def test_reputation_weighted_aggregation():
    from incre_ml.federated.aggregation import ReputationWeightedAggregation

    rwa = ReputationWeightedAggregation(n_clients=3, alpha=0.5)

    # Client 0 has lower MAE -> higher weight
    rwa.update_reputation(0, 0.1)
    rwa.update_reputation(1, 1.0)
    rwa.update_reputation(2, 0.5)

    reps = rwa.reputations
    assert len(reps) == 3
    assert sum(reps) == pytest.approx(1.0)
    assert reps[0] > reps[1]  # Client 0 should have highest weight

    w = [{"val": 10.0}, {"val": 20.0}, {"val": 15.0}]
    agg = rwa.aggregate(w)
    assert "val" in agg

    rwa.reset()
    reps_after = rwa.reputations
    assert all(abs(r - 1.0 / 3) < 1e-6 for r in reps_after)


def test_reputation_weighted_validation():
    from incre_ml.federated.aggregation import ReputationWeightedAggregation

    with pytest.raises(ValueError, match="n_clients must be > 0"):
        ReputationWeightedAggregation(n_clients=0)
    with pytest.raises(ValueError, match="alpha must be in"):
        ReputationWeightedAggregation(n_clients=2, alpha=0.0)
    with pytest.raises(ValueError, match="epsilon must be > 0"):
        ReputationWeightedAggregation(n_clients=2, epsilon=0.0)

    rwa = ReputationWeightedAggregation(n_clients=2)
    with pytest.raises(ValueError, match="client_id .* out of range"):
        rwa.update_reputation(5, 0.1)
    with pytest.raises(ValueError, match="validation_mae must be >= 0"):
        rwa.update_reputation(0, -0.1)
    with pytest.raises(ValueError, match="Expected 2"):
        rwa.aggregate([{"a": 1.0}])


def test_fedprox_aggregation():
    from incre_ml.federated.aggregation import FedProxAggregation

    fedprox = FedProxAggregation(mu=0.5)

    w1 = {"weights": {"a": 1.0}, "bias": 0.0}
    w2 = {"weights": {"a": 3.0}, "bias": 2.0}

    agg = fedprox.aggregate([w1, w2])
    assert "weights" in agg
    assert "bias" in agg


def test_fedprox_mu_zero():
    from incre_ml.federated.aggregation import FedProxAggregation

    fedprox = FedProxAggregation(mu=0.0)
    w1 = {"val": 10.0}
    w2 = {"val": 20.0}

    agg = fedprox.aggregate([w1, w2])
    assert agg["val"] == pytest.approx(15.0)  # plain FedAvg


def test_fedprox_empty():
    from incre_ml.federated.aggregation import FedProxAggregation

    fedprox = FedProxAggregation(mu=0.5)
    assert fedprox.aggregate([]) == {}


def test_fedprox_validation():
    from incre_ml.federated.aggregation import FedProxAggregation

    with pytest.raises(ValueError, match="mu must be in"):
        FedProxAggregation(mu=-0.1)
    with pytest.raises(ValueError, match="mu must be in"):
        FedProxAggregation(mu=1.5)


def test_fedprox_non_numeric_passthrough():
    from incre_ml.federated.aggregation import FedProxAggregation

    fedprox = FedProxAggregation(mu=0.5)
    w1 = {"name": "model_a", "val": 10.0}
    w2 = {"name": "model_b", "val": 20.0}
    agg = fedprox.aggregate([w1, w2])
    assert agg["name"] == "model_a"


# ---------------------------------------------------------------------------
# 13. CompositeConstraint, SoftConstraintWrapper, RangeConstraint, etc.
# ---------------------------------------------------------------------------


def test_range_constraint():
    from incre_ml.physics.constraints import RangeConstraint

    rc = RangeConstraint(min_val=0.0, max_val=100.0)
    assert rc.violation_one({}, 50.0) == 0.0
    assert rc.violation_one({}, -5.0) == 5.0
    assert rc.violation_one({}, 110.0) == 10.0
    assert rc.project_one({}, -5.0) == 0.0
    assert rc.project_one({}, 110.0) == 100.0
    assert rc.project_one({}, 50.0) == 50.0


def test_rate_limit_constraint():
    from incre_ml.physics.constraints import RateLimitConstraint

    rl = RateLimitConstraint(max_delta=5.0)
    assert rl.violation_one({}, 10.0) == 0.0  # no last_y
    assert rl.project_one({}, 10.0) == 10.0

    rl.learn_one({}, 10.0)
    assert rl.violation_one({}, 12.0) == 0.0
    assert rl.violation_one({}, 20.0) == 5.0
    assert rl.project_one({}, 20.0) == 15.0
    assert rl.project_one({}, 3.0) == 5.0


def test_monotonic_constraint():
    from incre_ml.physics.constraints import MonotonicConstraint

    mc_inc = MonotonicConstraint(direction="increasing")
    assert mc_inc.violation_one({}, 10.0) == 0.0  # no last_y
    mc_inc.learn_one({}, 10.0)
    assert mc_inc.violation_one({}, 12.0) == 0.0
    assert mc_inc.violation_one({}, 8.0) == 2.0
    assert mc_inc.project_one({}, 8.0) == 10.0
    assert mc_inc.project_one({}, 12.0) == 12.0

    mc_dec = MonotonicConstraint(direction="decreasing")
    mc_dec.learn_one({}, 10.0)
    assert mc_dec.violation_one({}, 12.0) == 2.0
    assert mc_dec.violation_one({}, 8.0) == 0.0
    assert mc_dec.project_one({}, 12.0) == 10.0
    assert mc_dec.project_one({}, 8.0) == 8.0


def test_composite_constraint():
    from incre_ml.physics.constraints import (
        CompositeConstraint,
        RangeConstraint,
        RateLimitConstraint,
    )

    rc = RangeConstraint(min_val=0.0, max_val=100.0)
    rl = RateLimitConstraint(max_delta=10.0)
    rl.learn_one({}, 50.0)

    comp = CompositeConstraint([rc, rl])

    # Prediction of 150 violates both range and rate
    v = comp.violation_one({}, 150.0)
    assert v > 0.0

    projected = comp.project_one({}, 150.0)
    assert 0.0 <= projected <= 100.0

    expl = comp.explain_one({}, 150.0)
    assert "total_violation" in expl
    assert "RangeConstraint_0_violation" in expl

    comp.learn_one({}, 60.0)


def test_composite_constraint_empty():
    from incre_ml.physics.constraints import CompositeConstraint

    with pytest.raises(ValueError, match="Must provide at least one constraint"):
        CompositeConstraint([])


def test_soft_constraint_wrapper():
    from incre_ml.physics.constraints import RangeConstraint, SoftConstraintWrapper

    rc = RangeConstraint(min_val=0.0, max_val=100.0)
    soft = SoftConstraintWrapper(rc, penalty_weight=0.5)

    # No violation -> passthrough
    assert soft.apply({}, 50.0) == 50.0

    # Violation -> blend
    result = soft.apply({}, 110.0)
    assert 100.0 <= result <= 110.0  # blended toward projected

    # Zero penalty_weight
    soft0 = SoftConstraintWrapper(rc, penalty_weight=0.0)
    # weight=0 means no blending even with violation
    result0 = soft0.apply({}, 110.0)
    assert result0 == pytest.approx(110.0)


def test_soft_constraint_wrapper_validation():
    from incre_ml.physics.constraints import RangeConstraint, SoftConstraintWrapper

    with pytest.raises(ValueError, match="penalty_weight must be in"):
        SoftConstraintWrapper(RangeConstraint(), penalty_weight=1.5)


# ---------------------------------------------------------------------------
# 14. ModelTournament
# ---------------------------------------------------------------------------


def test_model_tournament_auto():
    from incre_ml.compose.tournament import ModelTournament
    from incre_ml.linear import LinearRegression

    models = {
        "good": LinearRegression(learning_rate=0.1),
        "bad": LinearRegression(learning_rate=0.001),
    }
    mt = ModelTournament(models, window_size=10, promotion_policy="auto")

    for i in range(30):
        x = {"a": float(i)}
        mt.predict_one(x)
        mt.learn_one(x, float(i) * 2.0)

    summary = mt.summary
    assert "good_mae" in summary
    assert "bad_mae" in summary


def test_model_tournament_streak():
    from incre_ml.compose.tournament import ModelTournament
    from incre_ml.linear import LinearRegression

    models = {
        "m1": LinearRegression(learning_rate=0.01),
        "m2": LinearRegression(learning_rate=0.1),
    }
    mt = ModelTournament(
        models, window_size=10, promotion_policy="streak", promotion_streak=5
    )

    for i in range(50):
        x = {"a": float(i)}
        mt.predict_one(x)
        mt.learn_one(x, float(i) * 2.0)

    assert mt.champion_name in ("m1", "m2")


def test_model_tournament_never():
    from incre_ml.compose.tournament import ModelTournament
    from incre_ml.linear import LinearRegression

    models = {
        "a": LinearRegression(learning_rate=0.01),
        "b": LinearRegression(learning_rate=0.1),
    }
    mt = ModelTournament(models, promotion_policy="never")

    for i in range(20):
        mt.predict_one({"x": float(i)})
        mt.learn_one({"x": float(i)}, float(i))

    assert mt.champion_name == "a"  # Never changes


def test_model_tournament_force_promote():
    from incre_ml.compose.tournament import ModelTournament
    from incre_ml.linear import LinearRegression

    models = {"a": LinearRegression(), "b": LinearRegression()}
    mt = ModelTournament(models, promotion_policy="never")

    mt.force_promote("b")
    assert mt.champion_name == "b"

    with pytest.raises(ValueError, match="Unknown model"):
        mt.force_promote("nonexistent")


def test_model_tournament_clear():
    from incre_ml.compose.tournament import ModelTournament
    from incre_ml.linear import LinearRegression

    models = {"a": LinearRegression(), "b": LinearRegression()}
    mt = ModelTournament(models, promotion_policy="auto")

    for i in range(10):
        mt.predict_one({"x": float(i)})
        mt.learn_one({"x": float(i)}, float(i))

    mt.clear()
    assert mt.champion_name == "a"


def test_model_tournament_explain():
    from incre_ml.compose.tournament import ModelTournament
    from incre_ml.linear import LinearRegression

    models = {"a": LinearRegression(learning_rate=0.1)}
    mt = ModelTournament(models)

    for i in range(10):
        mt.predict_one({"x": float(i)})
        mt.learn_one({"x": float(i)}, float(i))

    expl = mt.explain_one({"x": 5.0})
    assert isinstance(expl, dict)


def test_model_tournament_validation():
    from incre_ml.compose.tournament import ModelTournament
    from incre_ml.linear import LinearRegression

    with pytest.raises(ValueError, match="models must not be empty"):
        ModelTournament({})
    with pytest.raises(ValueError, match="window_size must be >= 0"):
        ModelTournament({"a": LinearRegression()}, window_size=-1)
    with pytest.raises(ValueError, match="promotion_streak must be > 0"):
        ModelTournament({"a": LinearRegression()}, promotion_streak=0)


def test_model_tournament_cumulative_mae():
    from incre_ml.compose.tournament import ModelTournament
    from incre_ml.linear import LinearRegression

    models = {"a": LinearRegression(learning_rate=0.1)}
    mt = ModelTournament(models, window_size=0, promotion_policy="auto")

    for i in range(10):
        mt.predict_one({"x": float(i)})
        mt.learn_one({"x": float(i)}, float(i))

    summary = mt.summary
    assert "a_mae" in summary


# ---------------------------------------------------------------------------
# 15. DriftAdaptiveWrapper
# ---------------------------------------------------------------------------


def test_drift_adaptive_reset():
    from incre_ml.drift.adaptive import DriftAdaptiveWrapper
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    wrapper = DriftAdaptiveWrapper(model, strategy="reset", grace_period=10)

    for i in range(50):
        x = {"a": float(i)}
        wrapper.learn_one(x, float(i) * 2.0)

    pred = wrapper.predict_one({"a": 25.0})
    assert isinstance(pred, float)
    assert wrapper.drift_count >= 0


def test_drift_adaptive_decay():
    from incre_ml.drift.adaptive import DriftAdaptiveWrapper
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    wrapper = DriftAdaptiveWrapper(model, strategy="decay", grace_period=10)

    for i in range(50):
        wrapper.learn_one({"a": float(i)}, float(i))

    assert isinstance(wrapper.predict_one({"a": 1.0}), float)


def test_drift_adaptive_replacement():
    from incre_ml.drift.adaptive import DriftAdaptiveWrapper
    from incre_ml.drift.adwin import ADWIN
    from incre_ml.linear import LinearRegression

    model = LinearRegression(learning_rate=0.1)
    # Use very sensitive detector to trigger drift
    detector = ADWIN(delta=0.5)
    wrapper = DriftAdaptiveWrapper(
        model, drift_detector=detector, strategy="replacement", grace_period=5
    )

    # Normal data
    for i in range(20):
        wrapper.learn_one({"a": float(i)}, float(i))

    # Abrupt shift to trigger drift
    for i in range(50):
        wrapper.learn_one({"a": float(i)}, float(i) * 100.0)

    assert isinstance(wrapper.predict_one({"a": 1.0}), float)


def test_drift_adaptive_clear():
    from incre_ml.drift.adaptive import DriftAdaptiveWrapper
    from incre_ml.linear import LinearRegression

    wrapper = DriftAdaptiveWrapper(LinearRegression(), strategy="reset")
    for i in range(10):
        wrapper.learn_one({"a": float(i)}, float(i))

    wrapper.clear()
    assert wrapper._n == 0
    assert wrapper._drift_count == 0
    assert wrapper._replacement_model is None


def test_drift_adaptive_with_classifier():
    from incre_ml.classification import NaiveBayes
    from incre_ml.drift.adaptive import DriftAdaptiveWrapper

    wrapper = DriftAdaptiveWrapper(NaiveBayes(), strategy="reset", grace_period=5)

    for i in range(30):
        label = "A" if i % 2 == 0 else "B"
        wrapper.learn_one({"x": float(i)}, label)

    pred = wrapper.predict_one({"x": 5.0})
    assert pred in ("A", "B", "")


# ---------------------------------------------------------------------------
# 16. NewtonCoolingConstraint & SoftConstraint (thermal)
# ---------------------------------------------------------------------------


def test_newton_cooling_basic():
    from incre_ml.physics.thermal import NewtonCoolingConstraint

    nc = NewtonCoolingConstraint(k=0.1, ambient_temp=25.0, max_deviation=2.0)

    # No last_y -> no violation
    assert nc.violation_one({}, 50.0) == 0.0
    assert nc.project_one({}, 50.0) == 50.0

    nc.learn_one({}, 50.0)

    # Expected next: 50 - 0.1 * 1.0 * (50 - 25) = 47.5
    expected = 47.5
    assert nc.violation_one({}, expected) == 0.0
    assert nc.violation_one({}, 60.0) > 0.0

    projected = nc.project_one({}, 60.0)
    assert projected == pytest.approx((60.0 + expected) / 2.0)


def test_newton_cooling_estimate_k():
    from incre_ml.physics.thermal import NewtonCoolingConstraint

    nc = NewtonCoolingConstraint(
        k=0.1, ambient_temp=25.0, estimate_k=True, rls_forgetting=0.99
    )

    # Simulate cooling
    temp = 80.0
    true_k = 0.05
    for _ in range(50):
        nc.learn_one({}, temp)
        temp = temp - true_k * (temp - 25.0)

    # k should have adapted toward true_k
    assert nc.k > 0


def test_newton_cooling_validation():
    from incre_ml.physics.thermal import NewtonCoolingConstraint

    with pytest.raises(ValueError, match="k must be > 0"):
        NewtonCoolingConstraint(k=0.0)
    with pytest.raises(ValueError, match="dt must be > 0"):
        NewtonCoolingConstraint(dt=0.0)
    with pytest.raises(ValueError, match="rls_forgetting must be in"):
        NewtonCoolingConstraint(rls_forgetting=0.0)


def test_newton_cooling_no_driving_force():
    from incre_ml.physics.thermal import NewtonCoolingConstraint

    nc = NewtonCoolingConstraint(k=0.1, ambient_temp=25.0, estimate_k=True)
    nc.learn_one({}, 25.0)  # T == ambient -> no driving force -> skip k update
    nc.learn_one({}, 25.0)


def test_soft_constraint_thermal():
    from incre_ml.physics.thermal import NewtonCoolingConstraint, SoftConstraint

    nc = NewtonCoolingConstraint(k=0.1, ambient_temp=25.0)
    soft = SoftConstraint(nc, strength=0.5)

    assert soft.violation_one({}, 50.0) == 0.0  # no last_y in inner

    nc.learn_one({}, 50.0)
    soft.learn_one({}, 50.0)

    projected = soft.project_one({}, 60.0)
    hard_projected = nc.project_one({}, 60.0)
    assert projected == pytest.approx(0.5 * 60.0 + 0.5 * hard_projected)

    soft.clear()


def test_soft_constraint_validation():
    from incre_ml.physics.thermal import NewtonCoolingConstraint, SoftConstraint

    with pytest.raises(ValueError, match="strength must be in"):
        SoftConstraint(NewtonCoolingConstraint(), strength=1.5)


# ---------------------------------------------------------------------------
# 17. StreamGenerator base
# ---------------------------------------------------------------------------


def test_stream_generator_base():
    from incre_ml.simulation.generators.manufacturing import (
        ManufacturingStreamGenerator,
    )

    gen = ManufacturingStreamGenerator(seed=42, total_steps=100)

    x, y = gen.next()
    assert isinstance(x, dict)
    assert isinstance(y, float)
    assert "vibration" in x or math.isnan(x.get("vibration", 0.0))
    assert "step" in x

    # Generate several
    for _ in range(20):
        x, y = gen.next()

    gen.reset()
    assert gen._step == 0


def test_stream_generator_iterator():
    from incre_ml.simulation.generators.manufacturing import (
        ManufacturingStreamGenerator,
    )

    gen = ManufacturingStreamGenerator(seed=42, total_steps=10)
    count = 0
    for _x, _y in gen:
        count += 1
        if count >= 10:
            break
    assert count == 10


def test_stream_generator_drift():
    from incre_ml.simulation.generators.manufacturing import (
        ManufacturingStreamGenerator,
    )

    gen = ManufacturingStreamGenerator(
        seed=42, total_steps=100, drift_start=0.5, drift_magnitude=0.5
    )

    # Before drift
    for _ in range(40):
        gen.next()

    # At drift point and beyond
    for _ in range(60):
        x, y = gen.next()
        assert isinstance(y, float)


def test_stream_generator_abrupt_drift():
    from incre_ml.simulation.generators.manufacturing import (
        ManufacturingStreamGenerator,
    )

    gen = ManufacturingStreamGenerator(
        seed=42, total_steps=100, drift_gradual=False, drift_start=0.5
    )

    for _ in range(80):
        x, y = gen.next()
        assert isinstance(y, float)


def test_stream_generator_ar1_validation():

    with pytest.raises(ValueError, match="ar1_coeff must be in"):
        # Use a concrete subclass to test
        from incre_ml.simulation.generators.manufacturing import (
            ManufacturingStreamGenerator,
        )

        ManufacturingStreamGenerator(ar1_coeff=1.0)


# ---------------------------------------------------------------------------
# 18. Concrete generators: clinical, demand
# ---------------------------------------------------------------------------


def test_clinical_generator():
    from incre_ml.simulation.generators.clinical import ClinicalStreamGenerator

    gen = ClinicalStreamGenerator(seed=42, total_steps=100)

    for _ in range(20):
        x, y = gen.next()
        assert isinstance(y, float)
        assert "step" in x

    # Check feature names
    names = gen._feature_names()
    assert "systolic_bp" in names
    assert "spo2" in names


def test_demand_generator():
    from incre_ml.simulation.generators.demand import RegionalDemandStreamGenerator

    gen = RegionalDemandStreamGenerator(seed=42, total_steps=100)

    for _ in range(20):
        x, y = gen.next()
        assert isinstance(y, float)
        assert "price" in x or math.isnan(x.get("price", 0.0))

    names = gen._feature_names()
    assert "price" in names
    assert "promotion_active" in names


def test_manufacturing_generator():
    from incre_ml.simulation.generators.manufacturing import (
        ManufacturingStreamGenerator,
    )

    gen = ManufacturingStreamGenerator(base_temp=70.0, seed=42, total_steps=100)

    for _ in range(20):
        x, y = gen.next()
        assert isinstance(y, float)

    names = gen._feature_names()
    assert "vibration" in names
    assert "tool_wear" in names


def test_generators_with_missing_data():
    from incre_ml.simulation.generators.clinical import ClinicalStreamGenerator

    gen = ClinicalStreamGenerator(
        seed=42, total_steps=200, missing_rate=0.5, missing_cascade_prob=0.9
    )

    nan_count = 0
    for _ in range(200):
        x, y = gen.next()
        for v in x.values():
            if isinstance(v, float) and math.isnan(v):
                nan_count += 1
                break

    assert nan_count > 0  # With high missing rate, should see some NaN
