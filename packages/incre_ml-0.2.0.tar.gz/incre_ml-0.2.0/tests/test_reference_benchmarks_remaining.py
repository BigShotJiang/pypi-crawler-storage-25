import math
import random
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any

import numpy as np
import pytest

from incre_ml.base.regressor import Regressor
from incre_ml.control import EpsilonGreedyBandit
from incre_ml.drift import ADWIN, DriftAwareWrapper, HddmA, PageHinkleyDrift
from incre_ml.model_selection import BanditModelSelector
from incre_ml.simulation import FaultInjection, SyntheticStreamGenerator


class ConstantRegressor(Regressor):
    def __init__(self, value: float) -> None:
        self.value = float(value)

    def learn_one(self, x: dict[str, Any], y: float) -> "ConstantRegressor":
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.value

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return {"constant": self.value}

    def clear(self) -> None:
        return None


@dataclass
class ThresholdDetector:
    threshold: float
    drifted: bool = False

    def update(self, value: float) -> bool:
        self.drifted = value > self.threshold
        return self.drifted

    def clear(self) -> None:
        self.drifted = False


def test_epsilon_greedy_bandit_stationary_rewards_learn_best_arm() -> None:
    random.seed(123)
    reward_rng = random.Random(999)
    bandit = EpsilonGreedyBandit(["bad", "mid", "best"], epsilon=0.1)
    probs = {"bad": 0.15, "mid": 0.45, "best": 0.8}

    for _ in range(2000):
        action = bandit.select_action()
        reward = 1.0 if reward_rng.random() < probs[action] else 0.0
        bandit.update(action, reward)

    assert max(bandit.values, key=bandit.values.get) == "best"
    assert bandit.values["best"] > bandit.values["mid"] > bandit.values["bad"]
    # Selection counts can be noisy under exploration, but the best arm should
    # still be sampled materially more than the clearly bad arm.
    assert bandit.counts["best"] > bandit.counts["bad"]
    assert bandit.counts["best"] > 100


def test_bandit_model_selector_stationary_regime_tracks_low_error_model() -> None:
    selector = BanditModelSelector(
        {
            "near": ConstantRegressor(10.0),
            "far": ConstantRegressor(-4.0),
        },
        epsilon=0.0,
    )

    for _ in range(120):
        selector.learn_one({}, 10.5)

    assert selector.best_model_name == "near"
    assert selector.metrics["near"].get() < selector.metrics["far"].get()
    pred = selector.predict_one({})
    assert pred == pytest.approx(10.0)


def test_bandit_model_selector_exploration_mode_samples_multiple_models() -> None:
    random.seed(321)
    selector = BanditModelSelector(
        {
            "a": ConstantRegressor(0.0),
            "b": ConstantRegressor(1.0),
            "c": ConstantRegressor(2.0),
        },
        epsilon=1.0,
    )
    seen = {selector.predict_one({}) for _ in range(120)}
    assert seen == {0.0, 1.0, 2.0}


def test_synthetic_stream_noise_statistics_match_configuration() -> None:
    gen = SyntheticStreamGenerator(
        base_value=3.0, trend=0.0, seasonality=None, noise_std=2.0, seed=17
    )
    values = np.array([next(gen) for _ in range(5000)], dtype=float)
    assert abs(values.mean() - 3.0) < 0.12
    assert 1.75 < values.std(ddof=1) < 2.25


def test_fault_injection_empirical_spike_rate_and_sign_balance() -> None:
    random.seed(7)
    base_stream: Iterator[float] = iter([0.0] * 4000)
    faulted = FaultInjection(
        base_stream,
        spike_chance=0.1,
        spike_magnitude=5.0,
        stuck_chance=0.0,
    )
    vals = [next(faulted) for _ in range(4000)]
    spikes = [v for v in vals if abs(v) > 1e-12]
    spike_rate = len(spikes) / len(vals)
    assert 0.07 <= spike_rate <= 0.13
    pos_share = sum(v > 0 for v in spikes) / max(1, len(spikes))
    assert 0.35 <= pos_share <= 0.65


def test_fault_injection_stuck_duration_semantics_are_predictable(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    # Sequence controls random draws:
    # 1st call: trigger stuck fault (< stuck_chance), then no spike path is reached.
    # Subsequent non-stuck samples: no stuck, no spike.
    draws = iter([0.0, 1.0, 1.0, 1.0, 1.0, 1.0])
    monkeypatch.setattr("incre_ml.simulation.faults.random.random", lambda: next(draws))

    faulted = FaultInjection(
        iter([1.0, 2.0, 3.0, 4.0]),
        spike_chance=0.5,
        spike_magnitude=99.0,
        stuck_chance=0.5,
        stuck_duration=2,
    )
    # Trigger sample + 2 extra stuck repeats, then stream resumes.
    assert [next(faulted) for _ in range(4)] == [1.0, 1.0, 1.0, 2.0]


def test_adwin_stationary_stream_has_low_false_positive_rate() -> None:
    rng = np.random.default_rng(123)
    adwin = ADWIN(delta=0.01)
    false_positives = 0
    for v in rng.normal(0.0, 0.05, size=400):
        if adwin.update(float(v)):
            false_positives += 1
    assert false_positives <= 2


def test_hddm_warning_or_drift_appears_quickly_after_error_rate_shift() -> None:
    h = HddmA(drift_confidence=0.001, warning_confidence=0.01)
    stream = ([True] * 100) + ([False] * 140)

    first_warning = None
    first_drift = None
    for i, is_correct in enumerate(stream):
        h.update(is_correct)
        if h.warning and first_warning is None:
            first_warning = i
        if h.drifted and first_drift is None:
            first_drift = i

    assert first_warning is not None or first_drift is not None
    if first_warning is not None:
        assert first_warning >= 100
        assert first_warning - 100 <= 80
    if first_drift is not None:
        assert first_drift >= 100
        assert first_drift - 100 <= 120
    if first_warning is not None and first_drift is not None:
        assert first_warning <= first_drift


def test_page_hinkley_redetects_after_clear_on_second_shift() -> None:
    ph = PageHinkleyDrift(delta=0.001, threshold=4.0, alpha=0.99)

    for _ in range(60):
        assert ph.update(0.0) is False
    detected_first = any(ph.update(2.5) for _ in range(80))
    assert detected_first is True

    ph.clear()
    for _ in range(60):
        assert ph.update(1.0) is False
    detected_second = any(ph.update(4.0) for _ in range(80))
    assert detected_second is True


def test_drift_aware_wrapper_target_signal_uses_target_not_residual() -> None:
    model = ConstantRegressor(999.0)
    detector = ThresholdDetector(threshold=5.0)
    wrapper = DriftAwareWrapper(
        model=model, detector=detector, signal="target", policy="reset"
    )

    # If target signal is used, y controls drift directly even though residual
    # would be huge.
    wrapper.learn_one({}, 4.0)
    assert detector.drifted is False
    wrapper.learn_one({}, 6.0)
    assert detector.drifted is False  # reset policy clears detector on drift
    # Model still adheres to regressor contract post-reset/relearn.
    assert math.isfinite(wrapper.predict_one({}))
    assert isinstance(wrapper.explain_one({}), dict)
