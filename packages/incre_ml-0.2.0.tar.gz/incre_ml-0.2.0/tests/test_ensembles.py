import pytest

from incre_ml.classification.naive_bayes import NaiveBayes
from incre_ml.compose.bagging import OzaBagging
from incre_ml.compose.boosting import OzaBoost


def _make_classifiers(n=3):
    return [NaiveBayes() for _ in range(n)]


class TestOzaBagging:
    def test_init_requires_classifiers(self):
        with pytest.raises(ValueError):
            OzaBagging(base_classifiers=[])

    def test_basic_learning_and_prediction(self):
        bag = OzaBagging(base_classifiers=_make_classifiers(3), seed=42)
        for _ in range(50):
            bag.learn_one({"x": 1.0}, y=1)
            bag.learn_one({"x": -1.0}, y=0)

        pred = bag.predict_one({"x": 1.0})
        assert pred in (0, 1)

    def test_predict_proba(self):
        bag = OzaBagging(base_classifiers=_make_classifiers(3), seed=42)
        for _ in range(50):
            bag.learn_one({"x": 1.0}, y=1)
            bag.learn_one({"x": -1.0}, y=0)

        probas = bag.predict_proba_one({"x": 1.0})
        assert sum(probas.values()) == pytest.approx(1.0, abs=0.1)

    def test_clear_resets(self):
        bag = OzaBagging(base_classifiers=_make_classifiers(2))
        bag.learn_one({"x": 1.0}, y=1)
        bag.clear()
        for clf in bag.base_classifiers:
            assert clf.n_samples == 0


class TestOzaBoost:
    def test_init_requires_classifiers(self):
        with pytest.raises(ValueError):
            OzaBoost(base_classifiers=[])

    def test_basic_learning_and_prediction(self):
        boost = OzaBoost(base_classifiers=_make_classifiers(3), seed=42)
        for _ in range(50):
            boost.learn_one({"x": 1.0, "y_feat": 1.0}, y=1)
            boost.learn_one({"x": -1.0, "y_feat": -1.0}, y=0)

        pred = boost.predict_one({"x": 1.0, "y_feat": 1.0})
        assert pred in (0, 1)

    def test_weighted_voting(self):
        boost = OzaBoost(base_classifiers=_make_classifiers(5), seed=42)
        for _ in range(100):
            boost.learn_one({"x": 1.0}, y=1)
            boost.learn_one({"x": -1.0}, y=0)

        probas = boost.predict_proba_one({"x": 1.0})
        assert len(probas) > 0

    def test_clear_resets(self):
        boost = OzaBoost(base_classifiers=_make_classifiers(2))
        boost.learn_one({"x": 1.0}, y=1)
        boost.clear()
        assert boost._epsilon == [0.5, 0.5]
