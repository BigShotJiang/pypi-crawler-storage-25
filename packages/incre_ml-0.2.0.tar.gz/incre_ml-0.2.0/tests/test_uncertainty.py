import numpy as np

from incre_ml.forecasting import BootstrappedRegressor, NaiveForecaster


def test_bootstrapped_regressor_uncertainty():
    # Use a naive forecaster as the base
    base = NaiveForecaster()
    model = BootstrappedRegressor(base, n_models=20)

    # Stable period
    for _ in range(50):
        model.learn_one({}, 10.0 + np.random.normal(0, 0.1))

    pred, std = model.predict_with_uncertainty({})
    # Low noise -> low uncertainty
    assert std < 1.0

    # Introduce sudden high variance/chaos
    for _ in range(50):
        model.learn_one({}, 10.0 + np.random.normal(0, 5.0))

    pred_noisy, std_noisy = model.predict_with_uncertainty({})
    # Uncertainty should have spiked
    assert std_noisy > std
