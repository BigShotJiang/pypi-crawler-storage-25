from incre_ml.base.physics import PhysicsInformedWrapper
from incre_ml.forecasting import NaiveForecaster
from incre_ml.physics.constraints import MonotonicConstraint, RateLimitConstraint
from incre_ml.physics.thermal import NewtonCoolingConstraint


def test_wrapper_updates_stateful_constraint_automatically():
    base_model = NaiveForecaster()
    constraint = RateLimitConstraint(max_delta=2.0)
    model = PhysicsInformedWrapper(base_model, constraint)

    model.learn_one({}, 10.0)

    # Naive model predicts the last observed y (=10). If constraint state wasn't updated
    # by the wrapper, violation would stay 0.0 here.
    base_model.learn_one({}, 20.0)
    constrained = model.predict_one({})
    assert constrained == 12.0
    assert model.last_violation == 8.0


def test_monotonic_constraint_state_propagates_through_wrapper():
    base_model = NaiveForecaster()
    constraint = MonotonicConstraint(direction="increasing")
    model = PhysicsInformedWrapper(base_model, constraint)

    model.learn_one({}, 5.0)
    base_model.learn_one(
        {}, 2.0
    )  # raw prediction would violate increasing monotonicity

    pred = model.predict_one({})
    assert pred == 5.0
    assert model.last_violation == 3.0


def test_physics_informed_guard():
    # Ambient is 25, k=0.1
    # If last was 30, expected next is ~29.5
    constraint = NewtonCoolingConstraint(k=0.1, ambient_temp=25.0, max_deviation=1.0)
    base_model = NaiveForecaster()
    pi_model = PhysicsInformedWrapper(base_model, constraint)

    # 1. Learn a starting point
    pi_model.learn_one({}, 30.0)

    # 2. ML model (Naive) wants to predict 30.0 (last seen)
    # This is physically plausible (within 1.0 of 29.5)
    pred = pi_model.predict_one({})
    assert pred == 30.0
    assert pi_model.last_violation == 0.0

    # 3. Simulate an "Impossible" prediction
    # Force base model to predict something crazy by learning it
    base_model.learn_one({}, 80.0)

    # Raw prediction is 80.0, but constraint should pull it down
    pred_constrained = pi_model.predict_one({})
    assert pred_constrained < 80.0
    assert pi_model.last_violation > 0.0
    print(f"Base: 80.0, Constrained: {pred_constrained}")
