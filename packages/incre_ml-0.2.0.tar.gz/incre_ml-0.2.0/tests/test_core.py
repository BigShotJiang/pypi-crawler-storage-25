import numpy as np
import pytest

from incre_ml.anomaly import (
    AnomalyEnsemble,
    HalfSpaceTrees,
    PredictiveAnomalyDetector,
    ZScoreDetector,
)
from incre_ml.classification import (
    HoeffdingTreeClassifier,
    LogisticRegression,
    NaiveBayes,
)
from incre_ml.compose import Pipeline
from incre_ml.forecasting import (
    AR,
    SNARIMAX,
    HoltWinters,
    ModelSelectorEnsemble,
    NaiveForecaster,
    SeasonalNaiveForecaster,
)
from incre_ml.linear import PassiveAggressiveRegressor
from incre_ml.preprocessing import MinMaxScaler, SelectKBest, StandardScaler
from incre_ml.stats.running import RunningCorrelation, RunningStatistics
from incre_ml.tree import HoeffdingTreeRegressor


def test_seasonal_naive():
    model = SeasonalNaiveForecaster(season_length=3)
    # Series: 1, 2, 3, 1, 2, 3...
    for val in [1.0, 2.0, 3.0]:
        model.learn_one({}, val)
    # Next should be 1.0
    assert model.predict_one({}) == 1.0


def test_model_selector_ensemble():
    models = {"naive": NaiveForecaster(), "hw": HoltWinters(season_length=4)}
    ensemble = ModelSelectorEnsemble(models)
    # Predict-then-Learn cycle is important for metrics
    for i in range(1, 50):
        val = float(i)
        ensemble.predict_one({})
        ensemble.learn_one({}, val)

    # After a long trend, HoltWinters should be better than Naive
    assert ensemble.get_best_model() == "hw"
    assert ensemble.predict_one({}) > 45.0


def test_anomaly_ensemble():
    detectors = {
        "z": ZScoreDetector(feature_name="v"),
        "p": PredictiveAnomalyDetector(model=NaiveForecaster(), feature_name="v"),
    }
    # Weighted ensemble: bias towards Z-Score
    ensemble = AnomalyEnsemble(detectors, weights={"z": 0.7, "p": 0.3})
    for _ in range(50):
        # Learn normal behavior
        ensemble.score_one({"v": 10.0})
        ensemble.learn_one({"v": 10.0})

    # Normal
    assert ensemble.score_one({"v": 10.0}) < 0.3
    # Anomaly
    assert ensemble.score_one({"v": 500.0}) > 0.6


def test_min_max_scaler():
    scaler = MinMaxScaler()
    for val in [0.0, 100.0]:
        scaler.learn_one({"v": val})

    transformed = scaler.transform_one({"v": 50.0})
    assert transformed["v"] == pytest.approx(0.5)


def test_ar_model():
    model = AR(p=1, learning_rate=0.01)
    # y_t = 0.5 * y_{t-1} + noise (stable AR(1))
    val = 1.0
    for _ in range(100):
        val = 0.5 * val + 0.1
        model.learn_one({}, val)
    pred = model.predict_one({})
    # Process is stable, pred should be around 0.2
    assert 0.0 < pred < 1.0


def test_snarimax_model():
    model = SNARIMAX(p=1, s=4, p_seasonal=1)
    # Seasonal pattern + trend
    for i in range(20):
        val = float(i % 4 + i * 0.1)
        model.learn_one({}, val)
    assert model.predict_one({}) is not None


def test_passive_aggressive():
    model = PassiveAggressiveRegressor(epsilon=0.1)
    for _ in range(50):
        model.learn_one({"x": 1.0}, 5.0)
    assert model.predict_one({"x": 1.0}) == pytest.approx(5.0, abs=0.2)


def test_naive_bayes():
    model = NaiveBayes()
    # Class A: centered at 10.0, Class B: centered at -10.0
    for _ in range(50):
        model.learn_one({"x": 10.0 + np.random.normal(0, 1)}, "A")
        model.learn_one({"x": -10.0 + np.random.normal(0, 1)}, "B")

    # Test clear separation
    assert model.predict_one({"x": 12.0}) == "A"
    assert model.predict_one({"x": -12.0}) == "B"


def test_hoeffding_tree_regressor():
    model = HoeffdingTreeRegressor(grace_period=10)
    for i in range(50):
        # Step function: y=0 if x<5 else 10
        x = float(i % 10)
        y = 0.0 if x < 5 else 10.0
        model.learn_one({"x": x}, y)

    assert model.predict_one({"x": 2.0}) < 5.0
    assert model.predict_one({"x": 8.0}) > 5.0


def test_hoeffding_tree_classifier():
    model = HoeffdingTreeClassifier(grace_period=10)
    for i in range(50):
        x = float(i % 10)
        y = "A" if x < 5 else "B"
        model.learn_one({"x": x}, y)

    assert model.predict_one({"x": 2.0}) == "A"
    assert model.predict_one({"x": 8.0}) == "B"


def test_hst_detector():
    # Detectors need limits for HST
    detector = HalfSpaceTrees(
        n_trees=5, max_depth=5, window_size=20, limits={"v": [0, 100]}
    )
    # Fill reference window
    for _ in range(20):
        detector.learn_one({"v": 50.0})
    # Fill next window to trigger swap
    for _ in range(20):
        detector.learn_one({"v": 50.0})

    # 50 is normal
    s_normal = detector.score_one({"v": 50.0})
    # 99 is anomalous
    s_anomaly = detector.score_one({"v": 99.0})
    assert s_anomaly > s_normal


def test_predictive_anomaly():
    forecaster = HoltWinters(season_length=4)
    detector = PredictiveAnomalyDetector(model=forecaster, feature_name="v")
    for i in range(40):
        # Predict before learning
        detector.score_one({"v": float(i % 4)})
        detector.learn_one({"v": float(i % 4)})

    # Normal point in pattern
    s_normal = detector.score_one({"v": 0.0})
    # Break pattern
    s_anomaly = detector.score_one({"v": 10.0})
    assert s_anomaly > s_normal


def test_running_stats():
    stats = RunningStatistics()
    data = [1, 2, 3, 4, 5]
    for x in data:
        stats.update(x)
    assert stats.mean == pytest.approx(3.0)
    assert stats.variance == pytest.approx(2.0)
    assert stats.std_dev == pytest.approx(np.sqrt(2.0))


def test_running_correlation():
    corr = RunningCorrelation()
    # Simple linear relationship y = 2x
    for i in range(1, 6):
        corr.update(float(i), float(2 * i))
    assert corr.correlation == pytest.approx(1.0)


def test_holt_winters():
    model = HoltWinters(season_length=4)
    # Simple increasing series
    for i in range(1, 10):
        model.learn_one({}, float(i))
    pred = model.predict_one({})
    assert pred > 9.0


def test_zscore_detector():
    detector = ZScoreDetector(feature_name="val")
    # Establish normal range around 10
    for _ in range(50):
        detector.learn_one({"val": 10.0 + np.random.normal(0, 1)})

    # Normal point
    assert detector.score_one({"val": 10.0}) < 0.5
    # Anomaly (many standard deviations away)
    assert detector.score_one({"val": 50.0}) > 0.8


def test_logistic_regression():
    model = LogisticRegression(learning_rate=0.1)
    # Simple linear separable data
    for _ in range(50):
        model.learn_one({"x": 1.0}, 1)
        model.learn_one({"x": -1.0}, 0)

    assert model.predict_one({"x": 1.0}) == 1
    assert model.predict_one({"x": -1.0}) == 0


def test_standard_scaler():
    scaler = StandardScaler()
    data = [{"v": 100.0}, {"v": 200.0}]
    for x in data:
        scaler.learn_one(x)

    transformed = scaler.transform_one({"v": 150.0})
    assert transformed["v"] == pytest.approx(0.0)


def test_pipeline():
    pipe = Pipeline([StandardScaler(), NaiveForecaster()])
    pipe.learn_one({"val": 10.0}, 10.0)
    pipe.learn_one({"val": 20.0}, 20.0)
    # Naive forecaster should predict last Y (20.0)
    assert pipe.predict_one({"val": 30.0}) == 20.0


def test_select_k_best():
    selector = SelectKBest(k=1)
    # 'a' is highly correlated, 'b' is noise
    for i in range(1, 20):
        selector.learn_one({"a": float(i), "b": np.random.normal(0, 10)}, float(i))

    transformed = selector.transform_one({"a": 1.0, "b": 1.0})
    assert "a" in transformed
    assert "b" not in transformed


def test_clear_functionality():
    stats = RunningStatistics()
    stats.update(10.0)
    stats.clear()
    assert stats.count == 0
    assert stats.mean == 0.0
