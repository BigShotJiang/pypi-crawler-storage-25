import numpy as np

from incre_ml.drift import ADWIN


def test_adwin_drift_detection():
    adwin = ADWIN(delta=0.01)

    # Stable data
    for _ in range(100):
        adwin.update(10.0 + np.random.normal(0, 0.1))

    # No drift should be detected in stable phase (mostly)
    assert not adwin.drift_detected

    # Sudden shift
    drift_at = -1
    for i in range(100):
        if adwin.update(20.0 + np.random.normal(0, 0.1)):
            drift_at = i
            break

    # Drift should be detected after some samples in the new regime
    assert drift_at != -1
    assert 0 <= drift_at < 50
