import math

import pytest

from incre_ml.federated import (
    FederatedAveraging,
    FederatedCoordinator,
    FederatedEnsemble,
)
from incre_ml.linear import LinearRegression


def test_federated_aggregation_nested_dicts_and_sets() -> None:
    weights = [
        {"weights": {"x": 2.0}, "intercept_weight": 1.0, "classes": {0, 1}},
        {"weights": {"x": 4.0, "z": 10.0}, "intercept_weight": 3.0, "classes": {1, 2}},
    ]
    out = FederatedAveraging.aggregate(weights, [1.0, 3.0])
    assert out["intercept_weight"] == pytest.approx(2.5)
    assert out["weights"]["x"] == pytest.approx(3.5)
    assert out["weights"]["z"] == pytest.approx(7.5)
    assert out["classes"] == {0, 1, 2}


def test_federated_sync_converges_clients_and_reduces_divergence() -> None:
    ensemble = FederatedEnsemble(
        LinearRegression(learning_rate=0.05), client_ids=["A", "B"]
    )

    # Train clients on different regimes to create divergence.
    for _ in range(80):
        ensemble.learn_one("A", {"x": 1.0}, 0.0)
    for _ in range(80):
        ensemble.learn_one("B", {"x": 1.0}, 10.0)

    pre_a = ensemble.clients["A"].predict_one({"x": 1.0})
    pre_b = ensemble.clients["B"].predict_one({"x": 1.0})
    pre_gap = abs(pre_a - pre_b)
    assert pre_gap > 1.0

    ensemble.sync()

    post_a = ensemble.clients["A"].predict_one({"x": 1.0})
    post_b = ensemble.clients["B"].predict_one({"x": 1.0})
    post_g = ensemble.predict_global({"x": 1.0})
    post_gap = abs(post_a - post_b)

    assert post_gap == pytest.approx(0.0, abs=1e-12)
    assert abs(post_a - post_g) == pytest.approx(0.0, abs=1e-12)
    assert min(pre_a, pre_b) <= post_g <= max(pre_a, pre_b)
    assert post_gap < pre_gap


def test_federated_weighted_sync_biases_toward_high_sample_client() -> None:
    ensemble = FederatedEnsemble(
        LinearRegression(learning_rate=0.05), client_ids=["A", "B"]
    )

    for _ in range(200):
        ensemble.learn_one("A", {"x": 1.0}, 1.0)
    for _ in range(10):
        ensemble.learn_one("B", {"x": 1.0}, 9.0)

    ensemble.sync()
    pred = ensemble.predict_global({"x": 1.0})
    assert math.isfinite(pred)
    # Weighted aggregation should bias closer to A's regime (1.0) than B's (9.0).
    assert abs(pred - 1.0) < abs(pred - 9.0)


def test_federated_coordinator_syncs_multiple_ensembles() -> None:
    e1 = FederatedEnsemble(LinearRegression(learning_rate=0.05), client_ids=["A", "B"])
    e2 = FederatedEnsemble(LinearRegression(learning_rate=0.05), client_ids=["C", "D"])
    for _ in range(30):
        e1.learn_one("A", {"x": 1.0}, 2.0)
        e1.learn_one("B", {"x": 1.0}, 4.0)
        e2.learn_one("C", {"x": 1.0}, 8.0)
        e2.learn_one("D", {"x": 1.0}, 10.0)

    coordinator = FederatedCoordinator([e1, e2])
    coordinator.sync_all()

    assert e1.client_samples == {"A": 0, "B": 0}
    assert e2.client_samples == {"C": 0, "D": 0}
    assert math.isfinite(e1.predict_global({"x": 1.0}))
    assert math.isfinite(e2.predict_global({"x": 1.0}))


def test_federated_heterogeneous_feature_spaces_survive_sync() -> None:
    ensemble = FederatedEnsemble(
        LinearRegression(learning_rate=0.05), client_ids=["A", "B"]
    )

    for _ in range(60):
        ensemble.learn_one("A", {"x1": 1.0}, 5.0)
    for _ in range(60):
        ensemble.learn_one("B", {"x2": 1.0}, 9.0)

    ensemble.sync()
    g_weights = ensemble.global_model.get_weights()["weights"]
    assert "x1" in g_weights
    assert "x2" in g_weights
    assert math.isfinite(ensemble.predict_global({"x1": 1.0, "x2": 1.0}))


def test_federated_multi_round_sync_convergence_trajectory() -> None:
    ensemble = FederatedEnsemble(
        LinearRegression(learning_rate=0.03), client_ids=["A", "B"]
    )
    pre_gaps = []
    post_gaps = []

    rounds = [
        (0.0, 10.0, 50, 50),
        (2.0, 8.0, 40, 40),
        (4.0, 6.0, 30, 30),
    ]
    for ya, yb, na, nb in rounds:
        for _ in range(na):
            ensemble.learn_one("A", {"x": 1.0}, ya)
        for _ in range(nb):
            ensemble.learn_one("B", {"x": 1.0}, yb)
        pre_gap = abs(
            ensemble.clients["A"].predict_one({"x": 1.0})
            - ensemble.clients["B"].predict_one({"x": 1.0})
        )
        pre_gaps.append(pre_gap)
        ensemble.sync()
        post_gap = abs(
            ensemble.clients["A"].predict_one({"x": 1.0})
            - ensemble.clients["B"].predict_one({"x": 1.0})
        )
        post_gaps.append(post_gap)

    assert all(g > 0.0 for g in pre_gaps)
    assert all(g == pytest.approx(0.0, abs=1e-12) for g in post_gaps)


def test_federated_coordinator_different_sample_rates_multi_rounds() -> None:
    e_fast = FederatedEnsemble(
        LinearRegression(learning_rate=0.04), client_ids=["A", "B"]
    )
    e_slow = FederatedEnsemble(
        LinearRegression(learning_rate=0.04), client_ids=["C", "D"]
    )
    coordinator = FederatedCoordinator([e_fast, e_slow])

    for _ in range(3):
        for _ in range(80):
            e_fast.learn_one("A", {"x": 1.0}, 3.0)
            e_fast.learn_one("B", {"x": 1.0}, 5.0)
        for _ in range(10):
            e_slow.learn_one("C", {"x": 1.0}, 7.0)
            e_slow.learn_one("D", {"x": 1.0}, 9.0)
        coordinator.sync_all()

    assert e_fast.client_samples == {"A": 0, "B": 0}
    assert e_slow.client_samples == {"C": 0, "D": 0}
    pf = e_fast.predict_global({"x": 1.0})
    ps = e_slow.predict_global({"x": 1.0})
    assert math.isfinite(pf)
    assert math.isfinite(ps)
    assert pf != ps
