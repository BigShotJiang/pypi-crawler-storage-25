import pytest

from incre_ml.anomaly.industrial import ResidualZScoreDetector, SeasonalAnomalyDetector
from incre_ml.base.regressor import Regressor
from incre_ml.metrics import CoverageError, CoverageProbability


class ConstantRegressor(Regressor):
    def __init__(self, value: float = 0.0) -> None:
        self.value = value

    def learn_one(self, x, y):
        return self

    def predict_one(self, x):
        return float(self.value)

    def explain_one(self, x):
        return {}

    def clear(self) -> None:
        self.value = 0.0


def test_residual_zscore_detector_computes_nonzero_score_after_warmup():
    det = ResidualZScoreDetector(model=ConstantRegressor(0.0), threshold=3.0)

    for _ in range(8):
        det.learn_one({"v": 0.0}, y=0.0)
        assert 0.0 <= det.score_one({"v": 0.0}) <= 1.0

    det.learn_one({"v": 0.0}, y=12.0)
    score = det.score_one({"v": 12.0})
    assert 0.0 <= score <= 1.0
    assert score > 0.0


def test_seasonal_anomaly_detector_scores_using_learned_residuals():
    det = SeasonalAnomalyDetector(model=ConstantRegressor(0.0), threshold=3.0)

    for _ in range(8):
        det.learn_one({"hour": 9}, y=1.0)
        det.learn_one({"hour": 18}, y=1.0)

    det.learn_one({"hour": 9}, y=15.0)
    score = det.score_one({"hour": 9})
    assert 0.0 <= score <= 1.0
    assert score > 0.0

    det.clear()
    assert det.score_one({"hour": 9}) == 0.0


def test_coverage_probability_and_coverage_error_have_distinct_semantics():
    picp = CoverageProbability()
    err = CoverageError(target_coverage=0.8)

    observations = [
        (1.0, (0.0, 2.0)),  # covered
        (5.0, (4.0, 6.0)),  # covered
        (9.0, (7.0, 8.0)),  # missed
        (2.0, (3.0, 1.0)),  # covered after interval normalization
    ]
    for y, interval in observations:
        picp.update(y, 0.0, interval=interval)
        err.update(y, 0.0, interval=interval)

    assert picp.get() == pytest.approx(0.75)
    assert err.coverage_probability == pytest.approx(0.75)
    assert err.get() == pytest.approx(0.05)  # |0.8 - 0.75|
