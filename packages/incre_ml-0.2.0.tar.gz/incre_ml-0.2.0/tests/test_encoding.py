from incre_ml.preprocessing.encoding import OneHotEncoder, TargetEncoder


class TestOneHotEncoder:
    def test_basic_encoding(self):
        enc = OneHotEncoder()
        x = {"color": "red", "value": 1.0}
        enc.learn_one(x)
        enc.learn_one({"color": "blue", "value": 2.0})

        result = enc.transform_one({"color": "red", "value": 3.0})
        assert result["color_red"] == 1.0
        assert result["color_blue"] == 0.0
        assert result["value"] == 3.0

    def test_max_categories(self):
        enc = OneHotEncoder(max_categories=2)
        for i in range(10):
            enc.learn_one({"feat": f"cat_{i}"})
        assert len(enc._categories["feat"]) == 2

    def test_clear_resets(self):
        enc = OneHotEncoder()
        enc.learn_one({"feat": "a"})
        enc.clear()
        assert len(enc._categories) == 0

    def test_unseen_category_not_encoded(self):
        enc = OneHotEncoder()
        enc.learn_one({"color": "red"})
        result = enc.transform_one({"color": "green"})
        assert result["color_red"] == 0.0


class TestTargetEncoder:
    def test_basic_encoding(self):
        enc = TargetEncoder(smoothing=0.0)
        for _ in range(100):
            enc.learn_one({"color": "red"}, y=10.0)
        for _ in range(100):
            enc.learn_one({"color": "blue"}, y=0.0)

        result = enc.transform_one({"color": "red"})
        assert result["color"] > 5.0  # Should be close to 10.0

    def test_smoothing_pulls_toward_global_mean(self):
        enc = TargetEncoder(smoothing=1000.0)
        enc.learn_one({"color": "red"}, y=100.0)
        enc.learn_one({"color": "blue"}, y=0.0)

        result = enc.transform_one({"color": "red"})
        # With heavy smoothing, should be close to global mean (50)
        assert 20.0 < result["color"] < 80.0

    def test_clear_resets(self):
        enc = TargetEncoder()
        enc.learn_one({"feat": "a"}, y=1.0)
        enc.clear()
        assert len(enc._category_stats) == 0

    def test_numeric_passthrough(self):
        enc = TargetEncoder()
        enc.learn_one({"num": 5.0, "cat": "a"}, y=1.0)
        result = enc.transform_one({"num": 5.0, "cat": "a"})
        assert result["num"] == 5.0
