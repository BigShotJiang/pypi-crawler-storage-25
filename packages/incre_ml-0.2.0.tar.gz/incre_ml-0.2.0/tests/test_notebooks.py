import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

NOTEBOOKS = [
    "notebooks/forecasting_demo.ipynb",
    "notebooks/manufacturing_anomaly_demo.ipynb",
    "notebooks/streaming_classification_demo.ipynb",
    "notebooks/pipeline_demo.ipynb",
]


def _extract_notebook_code(path: Path) -> str:
    with path.open("r", encoding="utf-8") as f:
        nb = json.load(f)

    code_cells = [
        cell["source"] for cell in nb["cells"] if cell.get("cell_type") == "code"
    ]
    preamble = (
        "import matplotlib.pyplot as plt\nplt.show = lambda *args, **kwargs: None\n"
    )
    chunks = [preamble]
    for cell in code_cells:
        chunks.append("".join(cell) if isinstance(cell, list) else str(cell))
        chunks.append("\n")
    return "".join(chunks)


@pytest.mark.parametrize("notebook_path", NOTEBOOKS)
def test_notebook_executes(notebook_path: str, tmp_path: Path) -> None:
    nb_path = Path(notebook_path)
    if not nb_path.exists():
        pytest.skip(f"Notebook not found: {nb_path}")

    script_path = tmp_path / f"exec_{nb_path.stem}.py"
    script_path.write_text(_extract_notebook_code(nb_path), encoding="utf-8")

    env = os.environ.copy()
    src_path = str(Path.cwd() / "src")
    env["PYTHONPATH"] = (
        src_path if not env.get("PYTHONPATH") else f"{src_path}:{env['PYTHONPATH']}"
    )

    proc = subprocess.run(
        [sys.executable, str(script_path)],
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert proc.returncode == 0, (
        f"Notebook failed: {nb_path}\n"
        f"--- stdout ---\n{proc.stdout}\n"
        f"--- stderr ---\n{proc.stderr}"
    )
