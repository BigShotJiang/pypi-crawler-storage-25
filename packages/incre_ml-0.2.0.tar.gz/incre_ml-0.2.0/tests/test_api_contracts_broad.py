import math

import pytest

from incre_ml.anomaly import (
    AlertSuppressionWrapper,
    AnomalyEnsemble,
    CUSUMDetector,
    EWMAControlChartDetector,
    HalfSpaceTrees,
    PredictiveAnomalyDetector,
    ResidualZScoreDetector,
    SeasonalAnomalyDetector,
    ZScoreDetector,
)
from incre_ml.classification import (
    AbstainingClassifier,
    AdaptiveRandomForestClassifier,
    HoeffdingTreeClassifier,
    LogisticRegression,
    NaiveBayes,
    PassiveAggressiveClassifier,
    SGDClassifier,
)
from incre_ml.forecasting import (
    AR,
    SNARIMAX,
    TSB,
    BootstrappedRegressor,
    Croston,
    HoltWinters,
    KalmanFilterRegressor,
    ModelSelectorEnsemble,
    NaiveForecaster,
    RecursiveLeastSquaresRegressor,
    SeasonalNaiveForecaster,
    WeightedExpertsEnsemble,
)
from incre_ml.linear import LinearRegression, PassiveAggressiveRegressor
from incre_ml.uncertainty import ConformalRegressor, ResidualUncertaintyWrapper


def _assert_finite_float(v: float) -> None:
    assert isinstance(v, float)
    assert math.isfinite(v)


@pytest.mark.parametrize(
    "builder, stream",
    [
        (lambda: NaiveForecaster(), [1.0, 2.0, 3.0]),
        (lambda: SeasonalNaiveForecaster(season_length=3), [1.0, 2.0, 3.0, 1.0]),
        (lambda: HoltWinters(season_length=4), [1.0, 2.0, 3.0, 4.0, 5.0]),
        (lambda: AR(p=2), [1.0, 0.5, 0.8, 0.3, 0.1]),
        (lambda: SNARIMAX(p=1, s=4, p_seasonal=1), [float(i % 4) for i in range(12)]),
        (lambda: RecursiveLeastSquaresRegressor(), [1.0, 2.0, 3.0, 4.0]),
        (lambda: KalmanFilterRegressor(), [1.0, 1.1, 1.2, 1.3]),
        (lambda: Croston(), [0.0, 0.0, 4.0, 0.0, 0.0, 3.0]),
        (lambda: TSB(), [0.0, 1.0, 0.0, 2.0, 0.0]),
        (lambda: LinearRegression(), [1.0, 2.0, 3.0, 4.0]),
        (lambda: PassiveAggressiveRegressor(), [1.0, 2.0, 3.0, 4.0]),
        (
            lambda: BootstrappedRegressor(NaiveForecaster(), n_models=5),
            [1.0, 2.0, 3.0, 4.0],
        ),
        (lambda: ResidualUncertaintyWrapper(NaiveForecaster()), [1.0, 2.0, 3.0, 4.0]),
        (
            lambda: ConformalRegressor(NaiveForecaster(), window_size=16, alpha=0.1),
            [1.0, 2.0, 3.0, 4.0, 5.0],
        ),
        (
            lambda: ModelSelectorEnsemble(
                {"naive": NaiveForecaster(), "hw": HoltWinters(season_length=4)}
            ),
            [1.0, 2.0, 3.0, 4.0, 5.0],
        ),
        (
            lambda: WeightedExpertsEnsemble(
                {"naive": NaiveForecaster(), "sn": SeasonalNaiveForecaster(2)}
            ),
            [1.0, 2.0, 1.0, 2.0, 1.0],
        ),
    ],
)
def test_regressor_family_contracts(builder, stream) -> None:
    model = builder()
    x = {"x": 1.0, "v": 1.0}

    for y in stream:
        _ = model.predict_one(x)
        model.learn_one(x, float(y))

    pred = model.predict_one(x)
    _assert_finite_float(float(pred))

    expl = model.explain_one(x)
    assert isinstance(expl, dict)

    if hasattr(model, "predict_with_uncertainty"):
        pred_u, sigma = model.predict_with_uncertainty(x)
        _assert_finite_float(float(pred_u))
        _assert_finite_float(float(sigma))
        assert float(sigma) >= 0.0


@pytest.mark.parametrize(
    "builder",
    [
        lambda: LogisticRegression(),
        lambda: NaiveBayes(),
        lambda: HoeffdingTreeClassifier(grace_period=5),
        lambda: SGDClassifier(),
        lambda: PassiveAggressiveClassifier(),
        lambda: AdaptiveRandomForestClassifier(n_models=3, grace_period=5),
        lambda: AbstainingClassifier(LogisticRegression(), threshold=0.6),
    ],
)
def test_classifier_family_contracts(builder) -> None:
    clf = builder()
    x_pos = {"x": 1.0}
    x_neg = {"x": -1.0}

    for _ in range(20):
        clf.learn_one(x_pos, 1)
        clf.learn_one(x_neg, 0)

    pred = clf.predict_one(x_pos)
    assert pred in {0, 1, "ABSTAIN", ""}

    proba = clf.predict_proba_one(x_pos)
    assert isinstance(proba, dict)
    if proba:
        total = float(sum(float(v) for v in proba.values()))
        assert 0.0 <= total <= 1.000001 or 0.999 <= total <= 1.001
        for v in proba.values():
            assert 0.0 <= float(v) <= 1.0

    expl = clf.explain_one(x_pos)
    assert isinstance(expl, dict)


@pytest.mark.parametrize(
    "builder, score_x, learn_calls",
    [
        (
            lambda: ZScoreDetector(feature_name="v"),
            {"v": 10.0},
            [({"v": 10.0}, None)] * 8,
        ),
        (lambda: EWMAControlChartDetector(), {"v": 10.0}, [({"v": 10.0}, None)] * 8),
        (lambda: CUSUMDetector(), {"v": 10.0}, [({"v": 10.0}, None)] * 8),
        (
            lambda: PredictiveAnomalyDetector(
                model=NaiveForecaster(), feature_name="v"
            ),
            {"v": 10.0},
            [({"v": 10.0}, None)] * 10,
        ),
        (
            lambda: ResidualZScoreDetector(model=NaiveForecaster()),
            {"v": 10.0},
            [({"v": 10.0}, 10.0)] * 8 + [({"v": 100.0}, 100.0)],
        ),
        (
            lambda: SeasonalAnomalyDetector(model=NaiveForecaster()),
            {"hour": 9, "v": 1.0},
            [({"hour": 9}, 1.0)] * 8 + [({"hour": 9}, 20.0)],
        ),
        (
            lambda: AlertSuppressionWrapper(
                ZScoreDetector(feature_name="v"), window_size=3
            ),
            {"v": 10.0},
            [({"v": 10.0}, None)] * 8,
        ),
        (
            lambda: HalfSpaceTrees(
                n_trees=3, max_depth=4, window_size=10, limits={"v": [0.0, 1.0]}
            ),
            {"v": 0.5},
            [({"v": 0.5}, None)] * 25,
        ),
        (
            lambda: AnomalyEnsemble(
                {
                    "z": ZScoreDetector(feature_name="v"),
                    "p": PredictiveAnomalyDetector(
                        model=NaiveForecaster(), feature_name="v"
                    ),
                }
            ),
            {"v": 10.0},
            [({"v": 10.0}, None)] * 12,
        ),
    ],
)
def test_anomaly_family_contracts(builder, score_x, learn_calls) -> None:
    det = builder()

    for x, y in learn_calls:
        _ = det.score_one(x)
        if y is None:
            det.learn_one(x)
        else:
            det.learn_one(x, y)

    score = det.score_one(score_x)
    _assert_finite_float(float(score))
    assert 0.0 <= float(score) <= 1.0


def test_exported_class_parameter_validation_edges() -> None:
    with pytest.raises(ValueError):
        BootstrappedRegressor(NaiveForecaster(), n_models=0)
    with pytest.raises(ValueError):
        ModelSelectorEnsemble({})
    with pytest.raises(ValueError):
        WeightedExpertsEnsemble({}, eta=0.1)
    with pytest.raises(ValueError):
        WeightedExpertsEnsemble({"n": NaiveForecaster()}, eta=-0.1)
    with pytest.raises(ValueError):
        AdaptiveRandomForestClassifier(n_models=0)
    with pytest.raises(ValueError):
        AnomalyEnsemble({})
    with pytest.raises(ValueError):
        AbstainingClassifier(LogisticRegression(), threshold=1.1)
