import pytest

from incre_ml.clustering import DBSTREAM, OnlineKMeans


class TestOnlineKMeans:
    def test_init_requires_positive_k(self):
        with pytest.raises(ValueError):
            OnlineKMeans(k=0)

    def test_basic_clustering(self):
        km = OnlineKMeans(k=2)
        # Two distinct clusters
        for _ in range(50):
            km.learn_one({"x": 0.0, "y": 0.0})
        for _ in range(50):
            km.learn_one({"x": 10.0, "y": 10.0})

        c0 = km.predict_one({"x": 0.1, "y": 0.1})
        c1 = km.predict_one({"x": 9.9, "y": 9.9})
        assert c0 != c1

    def test_explain_one_returns_distances(self):
        km = OnlineKMeans(k=2)
        for _ in range(10):
            km.learn_one({"x": 0.0})
        for _ in range(10):
            km.learn_one({"x": 10.0})

        expl = km.explain_one({"x": 5.0})
        assert "distance_to_cluster_0" in expl
        assert "distance_to_cluster_1" in expl

    def test_clear_resets_state(self):
        km = OnlineKMeans(k=2)
        km.learn_one({"x": 1.0})
        km.clear()
        assert len(km.centroids) == 0

    def test_predict_before_learning(self):
        km = OnlineKMeans(k=3)
        assert km.predict_one({"x": 1.0}) == 0


class TestDBSTREAM:
    def test_init_requires_positive_radius(self):
        with pytest.raises(ValueError):
            DBSTREAM(radius=0)

    def test_basic_clustering(self):
        db = DBSTREAM(radius=2.0)
        for _ in range(20):
            db.learn_one({"x": 0.0, "y": 0.0})
        for _ in range(20):
            db.learn_one({"x": 100.0, "y": 100.0})

        c0 = db.predict_one({"x": 0.0, "y": 0.0})
        c1 = db.predict_one({"x": 100.0, "y": 100.0})
        assert c0 != c1

    def test_clear_resets(self):
        db = DBSTREAM(radius=1.0)
        db.learn_one({"x": 1.0})
        db.clear()
        assert len(db.micro_clusters) == 0

    def test_explain_returns_distances(self):
        db = DBSTREAM(radius=5.0)
        db.learn_one({"x": 0.0})
        db.learn_one({"x": 100.0})
        expl = db.explain_one({"x": 50.0})
        assert len(expl) > 0
