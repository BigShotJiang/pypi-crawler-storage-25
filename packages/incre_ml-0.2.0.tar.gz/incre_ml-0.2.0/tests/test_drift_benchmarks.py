from dataclasses import dataclass

from incre_ml.drift import ADWIN, HddmA, PageHinkleyDrift


@dataclass
class DriftFixture:
    values: list[float]
    change_index: int


def step_mean_stream(n1: int, n2: int, before: float, after: float) -> DriftFixture:
    return DriftFixture(values=[before] * n1 + [after] * n2, change_index=n1)


def latency_from_change(flags: list[bool], change_index: int) -> int | None:
    for i in range(change_index, len(flags)):
        if flags[i]:
            return i - change_index
    return None


def error_regime_stream(n1: int, n2: int) -> list[bool]:
    # True = correct; False = error
    return ([True] * n1) + ([False] * n2)


def test_adwin_benchmark_known_change_latency() -> None:
    fx = step_mean_stream(n1=80, n2=220, before=0.0, after=1.0)
    ad = ADWIN(delta=0.01)
    flags = [ad.update(v) for v in fx.values]
    latency = latency_from_change(flags, fx.change_index)
    assert latency is not None
    assert 0 <= latency <= 120


def test_page_hinkley_benchmark_known_change_latency() -> None:
    fx = step_mean_stream(n1=60, n2=160, before=0.0, after=2.0)
    ph = PageHinkleyDrift(delta=0.001, threshold=5.0, alpha=0.99)
    flags = [ph.update(v) for v in fx.values]
    latency = latency_from_change(flags, fx.change_index)
    assert latency is not None
    assert 0 <= latency <= 80


def test_hddm_a_benchmark_error_rate_shift_latency() -> None:
    stream = error_regime_stream(80, 160)
    h = HddmA(drift_confidence=0.001, warning_confidence=0.01)
    drift_flags = [h.update(is_correct) for is_correct in stream]
    drift_latency = latency_from_change(drift_flags, 80)
    assert drift_latency is not None
    assert 0 <= drift_latency <= 120


def test_drift_benchmark_fixture_helper() -> None:
    fx = step_mean_stream(5, 7, before=1.0, after=3.0)
    assert fx.change_index == 5
    assert fx.values[:5] == [1.0] * 5
    assert fx.values[5:] == [3.0] * 7

    flags = [False, False, False, True, False]
    assert latency_from_change(flags, 2) == 1
    assert latency_from_change([False, False], 1) is None
