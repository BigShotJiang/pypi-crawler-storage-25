import numpy as np

from incre_ml.forecasting import BootstrappedRegressor, NaiveForecaster


def collect_bootstrap_stats(
    noise_std: float, seed: int = 123, warmup: int = 100, n_eval: int = 300
):
    np.random.seed(seed)
    rng = np.random.default_rng(seed)
    model = BootstrappedRegressor(NaiveForecaster(), n_models=20)

    covered_1 = 0
    covered_2 = 0
    total = 0
    widths_1 = []
    widths_2 = []
    sigmas = []

    for i in range(warmup + n_eval):
        y = float(10.0 + rng.normal(0, noise_std))
        pred, sigma = model.predict_with_uncertainty({})
        if i >= warmup:
            total += 1
            widths_1.append(2.0 * sigma)
            widths_2.append(4.0 * sigma)
            sigmas.append(sigma)
            if pred - sigma <= y <= pred + sigma:
                covered_1 += 1
            if pred - 2 * sigma <= y <= pred + 2 * sigma:
                covered_2 += 1
        model.learn_one({}, y)

    return {
        "cov1": covered_1 / total,
        "cov2": covered_2 / total,
        "avg_width1": float(np.mean(widths_1)),
        "avg_width2": float(np.mean(widths_2)),
        "avg_sigma": float(np.mean(sigmas)),
    }


def test_bootstrapped_uncertainty_proxy_coverage_and_sharpness_tradeoff() -> None:
    stats = collect_bootstrap_stats(noise_std=1.0, seed=7)
    # Wider interval should not cover less and should be wider (sharpness tradeoff).
    assert stats["cov2"] >= stats["cov1"]
    assert stats["avg_width2"] >= stats["avg_width1"]
    assert stats["avg_sigma"] >= 0.0


def test_bootstrapped_uncertainty_sigma_increases_with_noise() -> None:
    low = collect_bootstrap_stats(noise_std=0.2, seed=17)
    high = collect_bootstrap_stats(noise_std=2.0, seed=17)
    assert high["avg_sigma"] > low["avg_sigma"]
    assert high["avg_width1"] > low["avg_width1"]
