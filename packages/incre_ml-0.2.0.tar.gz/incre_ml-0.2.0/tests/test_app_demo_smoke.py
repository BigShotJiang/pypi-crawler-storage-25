import os
import subprocess
import sys
from pathlib import Path


def test_app_import_bootstraps_local_src() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    script = """
import app
assert app.INCREML_IMPORTS_AVAILABLE, "incre-ml imports unavailable"
assert app.HoltWinters is not None
assert app.Pipeline is not None
assert len(app.scenarios()) >= 1
print("ok")
"""
    env = os.environ.copy()
    env.pop("PYTHONPATH", None)

    proc = subprocess.run(
        [sys.executable, "-c", script],
        cwd=repo_root,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert proc.returncode == 0, proc.stderr or proc.stdout
    assert "ok" in proc.stdout


def test_app_replay_smoke_manufacturing() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    import app

    for key in list(app.st.session_state.keys()):
        if key.startswith("rt__") or key.startswith("timeline__"):
            del app.st.session_state[key]

    sc = app.scenarios()["manufacturing"]
    opts = {
        "chart_window": 80,
        "step_size": 2,
        "auto_play": False,
        "auto_ms": 700,
        "use_physics": True,
        "sync_interval": 14,
    }

    app.init_runtime(sc, opts["use_physics"], 240)
    app.process_steps(sc, 5, opts)

    base = f"rt__{sc.key}"
    hist = app.st.session_state[f"{base}__history"]
    assert not hist.empty
    assert len(hist) >= 1
    assert "y" in hist.columns


def test_app_replay_and_snapshot_formatting() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    import pandas as pd

    import app

    for key in list(app.st.session_state.keys()):
        if key.startswith("rt__") or key.startswith("timeline__"):
            del app.st.session_state[key]

    sc = app.scenarios()["manufacturing"]
    opts = {
        "chart_window": 80,
        "step_size": 2,
        "auto_play": False,
        "auto_ms": 700,
        "use_physics": True,
        "sync_interval": 14,
    }

    app.init_runtime(sc, opts["use_physics"], 240)
    app.process_steps(sc, 20, opts)

    base = f"rt__{sc.key}"
    hist = app.st.session_state[f"{base}__history"]
    assert not hist.empty

    assert app.format_snapshot_value(0.04) == "0.0400"
    assert (
        app.format_snapshot_value(pd.Timestamp("2024-01-01 12:34:56"))
        == "2024-01-01 12:34:56"
    )


def test_app_supply_chain_replay_values_stay_finite_and_bounded() -> None:
    repo_root = Path(__file__).resolve().parents[1]
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    import numpy as np

    import app

    for key in list(app.st.session_state.keys()):
        if key.startswith("rt__") or key.startswith("timeline__"):
            del app.st.session_state[key]

    sc = app.scenarios()["supply_chain"]
    opts = {
        "chart_window": 80,
        "step_size": 2,
        "auto_play": False,
        "auto_ms": 700,
        "use_physics": False,
        "sync_interval": 14,
    }

    app.init_runtime(sc, opts["use_physics"], 180)
    app.process_steps(sc, 40, opts)

    hist = app.st.session_state[f"rt__{sc.key}__history"]
    assert not hist.empty
    for col in ["y", "pred", "local_pred", "global_pred", "sigma"]:
        if col in hist.columns:
            s = hist[col].dropna()
            assert np.isfinite(s.astype(float)).all()
    if "sigma" in hist.columns:
        assert float(hist["sigma"].dropna().max()) <= 1000.0
