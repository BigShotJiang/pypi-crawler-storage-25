import math
import random

import pytest

from incre_ml.control import EpsilonGreedyBandit, ThresholdPolicy
from incre_ml.drift import ADWIN
from incre_ml.drift.monitors.residuals import ResidualDriftMonitor
from incre_ml.forecasting import NaiveForecaster
from incre_ml.io import from_dict, to_dict
from incre_ml.model_selection import BanditModelSelector
from incre_ml.simulation import FaultInjection, SyntheticStreamGenerator


def test_threshold_policy_and_bandit_validation() -> None:
    with pytest.raises(ValueError):
        ThresholdPolicy(1.0, side="sideways")
    assert ThresholdPolicy(1.0, side="above").decide(2.0) is True
    assert ThresholdPolicy(1.0, side="below").decide(2.0) is False

    with pytest.raises(ValueError):
        EpsilonGreedyBandit([], epsilon=0.1)
    with pytest.raises(ValueError):
        EpsilonGreedyBandit(["a", "a"], epsilon=0.1)
    with pytest.raises(ValueError):
        EpsilonGreedyBandit(["a"], epsilon=1.1)

    bandit = EpsilonGreedyBandit(["a", "b"], epsilon=0.0)
    # Deterministic exploitation on initial equal values selects one valid action.
    action = bandit.select_action()
    assert action in {"a", "b"}
    bandit.update("a", 1.0)
    bandit.update("a", 3.0)
    assert bandit.values["a"] == pytest.approx(2.0)
    with pytest.raises(KeyError):
        bandit.update("z", 1.0)


def test_synthetic_stream_generator_determinism_and_parameter_validation() -> None:
    with pytest.raises(ValueError):
        SyntheticStreamGenerator(noise_std=-1.0)
    with pytest.raises(ValueError):
        SyntheticStreamGenerator(seasonality={"period": 0.0, "amplitude": 1.0})

    g1 = SyntheticStreamGenerator(base_value=1.0, trend=0.5, noise_std=0.0, seed=7)
    g2 = SyntheticStreamGenerator(base_value=1.0, trend=0.5, noise_std=0.0, seed=7)
    vals1 = [next(g1) for _ in range(5)]
    vals2 = [next(g2) for _ in range(5)]
    assert vals1 == vals2 == [1.0, 1.5, 2.0, 2.5, 3.0]

    gs = SyntheticStreamGenerator(
        base_value=0.0,
        trend=0.0,
        seasonality={"period": 4.0, "amplitude": 2.0},
        noise_std=0.0,
        seed=1,
    )
    seasonal = [next(gs) for _ in range(4)]
    assert seasonal[0] == pytest.approx(0.0)
    assert seasonal[1] == pytest.approx(2.0)
    assert seasonal[2] == pytest.approx(0.0, abs=1e-12)
    assert seasonal[3] == pytest.approx(-2.0)


def test_fault_injection_validation_and_deterministic_no_fault_mode() -> None:
    with pytest.raises(ValueError):
        FaultInjection(iter([1.0]), spike_chance=-0.1)
    with pytest.raises(ValueError):
        FaultInjection(iter([1.0]), stuck_chance=1.1)
    with pytest.raises(ValueError):
        FaultInjection(iter([1.0]), stuck_duration=-1)

    random.seed(123)
    base = iter([1.0, 2.0, 3.0, 4.0])
    fi = FaultInjection(base, spike_chance=0.0, stuck_chance=0.0)
    assert [next(fi) for _ in range(4)] == [1.0, 2.0, 3.0, 4.0]


def test_serialization_roundtrip_and_invalid_payloads() -> None:
    model = NaiveForecaster()
    model.learn_one({}, 42.0)
    payload = to_dict(model)
    restored = from_dict(payload)
    assert isinstance(restored, NaiveForecaster)
    assert restored.predict_one({}) == 42.0

    with pytest.raises(TypeError):
        from_dict("not-a-dict")  # type: ignore[arg-type]
    with pytest.raises(ValueError):
        from_dict({"library": "other", "state": ""})
    with pytest.raises(ValueError):
        from_dict({"library": "incre-ml"})
    with pytest.raises(ValueError):
        from_dict({"library": "incre-ml", "state": "not base64!!!"})


def test_bandit_model_selector_contract_and_reference_behavior() -> None:
    with pytest.raises(ValueError):
        BanditModelSelector({})
    with pytest.raises(ValueError):
        BanditModelSelector({"n": NaiveForecaster()}, epsilon=-0.1)

    # epsilon=0 for deterministic exploitation of currently best tracked model
    selector = BanditModelSelector(
        {
            "good": NaiveForecaster(),
            "bad": NaiveForecaster(),
        },
        epsilon=0.0,
    )

    # Bias "good" by pretraining it closer to the stream; "bad" stays stale.
    selector.models["good"].learn_one({}, 10.0)
    selector.models["bad"].learn_one({}, -10.0)

    for _ in range(40):
        selector.learn_one({}, 10.0)

    pred = selector.predict_one({})
    assert isinstance(pred, float)
    assert math.isfinite(pred)
    assert selector.best_model_name in {"good", "bad"}
    assert selector.metrics["good"].get() <= selector.metrics["bad"].get()


def test_residual_drift_monitor_with_adwin_and_invalid_detector() -> None:
    model = NaiveForecaster()
    monitor = ResidualDriftMonitor(model=model, detector=ADWIN(delta=0.01))
    # Stable phase
    for _ in range(50):
        model.learn_one({}, 0.0)
        monitor.update({}, 0.0)
    # Shift phase causes high residuals
    detected = False
    for _ in range(100):
        if monitor.update({}, 5.0):
            detected = True
            break
    assert detected
    monitor.clear()
    assert monitor.drifted is False

    class NoUpdate:
        pass

    bad = ResidualDriftMonitor(model=NaiveForecaster(), detector=NoUpdate())
    with pytest.raises(TypeError):
        bad.update({}, 1.0)
