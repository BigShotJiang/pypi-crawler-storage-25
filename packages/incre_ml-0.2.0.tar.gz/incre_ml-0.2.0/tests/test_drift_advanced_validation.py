from dataclasses import dataclass
from typing import Any

from incre_ml.base.regressor import Regressor
from incre_ml.drift import EDDM, DriftAwareWrapper


def error_pattern_stream(
    pre_len: int, pre_period: int, post_len: int, post_period: int
) -> list[bool]:
    stream: list[bool] = []
    for i in range(pre_len):
        stream.append(False if (i + 1) % pre_period == 0 else True)
    for i in range(post_len):
        stream.append(False if (i + 1) % post_period == 0 else True)
    return stream


def first_true_after(flags: list[bool], start: int) -> int | None:
    for i in range(start, len(flags)):
        if flags[i]:
            return i
    return None


def test_eddm_sensitivity_specificity_on_controlled_error_stream() -> None:
    eddm = EDDM()
    stream = error_pattern_stream(
        pre_len=200, pre_period=20, post_len=200, post_period=2
    )

    false_positive_count = 0
    post_detect_idx = None
    for i, is_correct in enumerate(stream):
        drifted = eddm.update(is_correct)
        if i < 200 and drifted:
            false_positive_count += 1
        if i >= 200 and (eddm.warning or drifted) and post_detect_idx is None:
            post_detect_idx = i

    # Specificity proxy: no repeated false alarms in the stable region.
    assert false_positive_count <= 1
    # Sensitivity proxy: should raise a warning or drift in the degraded region.
    assert post_detect_idx is not None
    assert 0 <= (post_detect_idx - 200) <= 120


@dataclass
class TriggerDetector:
    threshold: float
    drifted: bool = False
    resets: int = 0

    def update(self, value: float) -> bool:
        self.drifted = value > self.threshold
        return self.drifted

    def clear(self) -> None:
        self.drifted = False
        self.resets += 1


class CountingRegressor(Regressor):
    def __init__(self) -> None:
        self.bias = 0.0
        self.learn_calls = 0
        self.clear_calls = 0

    def learn_one(self, x: dict[str, Any], y: float) -> "CountingRegressor":
        self.learn_calls += 1
        self.bias = float(y)
        return self

    def predict_one(self, x: dict[str, Any]) -> float:
        return self.bias

    def explain_one(self, x: dict[str, Any]) -> dict[str, float]:
        return {"bias": self.bias}

    def clear(self) -> None:
        self.clear_calls += 1
        self.bias = 0.0


def test_drift_aware_wrapper_reset_policy_handles_repeated_drifts() -> None:
    model = CountingRegressor()
    detector = TriggerDetector(threshold=1.0)
    wrapper = DriftAwareWrapper(
        model=model, detector=detector, signal="residual", policy="reset"
    )

    # No drift
    wrapper.learn_one({}, 0.0)
    wrapper.learn_one({}, 0.0)
    assert model.clear_calls == 0
    assert detector.resets == 0

    # Drift 1: large residual triggers reset
    wrapper.learn_one({}, 10.0)
    assert model.clear_calls == 1
    assert detector.resets == 1

    # After a reset-triggering sample, the model is re-learned on that sample (y=10),
    # so "stable" means staying near 10 before creating a new large residual again.
    wrapper.learn_one({}, 10.0)
    wrapper.learn_one({}, 10.0)
    wrapper.learn_one({}, 0.0)
    assert model.clear_calls == 2
    assert detector.resets == 2

    # Wrapper should still expose regressor contract
    assert isinstance(wrapper.predict_one({}), float)
    assert isinstance(wrapper.explain_one({}), dict)
