import numpy as np
import pytest

from incre_ml.base.regressor import Regressor
from incre_ml.uncertainty import ConformalRegressor


class ConstantRegressor(Regressor):
    def __init__(self, value: float = 0.0) -> None:
        self.value = float(value)

    def learn_one(self, x, y):
        return self

    def predict_one(self, x):
        return self.value

    def explain_one(self, x):
        return {"constant": self.value}

    def clear(self) -> None:
        pass


def empirical_coverage(
    alpha: float, seed: int = 123, warmup: int = 300, n_eval: int = 1200
) -> float:
    rng = np.random.default_rng(seed)
    model = ConformalRegressor(ConstantRegressor(0.0), window_size=200, alpha=alpha)

    covered = 0
    total = 0
    stream = rng.normal(0.0, 1.0, warmup + n_eval)
    for i, y in enumerate(stream):
        pred, q = model.predict_with_uncertainty({})
        if i >= warmup:
            total += 1
            if (pred - q) <= float(y) <= (pred + q):
                covered += 1
        model.learn_one({}, float(y))
    return covered / total


def test_conformal_empirical_coverage_matches_target_within_tolerance() -> None:
    alpha = 0.1
    target = 1.0 - alpha
    cov = empirical_coverage(alpha=alpha, seed=11)
    # Finite-window online conformal on IID residuals should be close, but not exact.
    assert cov == pytest.approx(target, abs=0.06)


def test_conformal_coverage_monotonicity_vs_alpha() -> None:
    cov_90 = empirical_coverage(alpha=0.1, seed=22)
    cov_80 = empirical_coverage(alpha=0.2, seed=22)
    assert cov_90 >= cov_80
