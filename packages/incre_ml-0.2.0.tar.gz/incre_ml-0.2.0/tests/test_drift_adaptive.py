from incre_ml.drift.adaptive import DriftAdaptiveWrapper
from incre_ml.linear.regression import LinearRegression


class TestDriftAdaptiveWrapper:
    def test_reset_strategy(self):
        model = LinearRegression(learning_rate=0.01)
        wrapper = DriftAdaptiveWrapper(model, strategy="reset", grace_period=10)

        # Train on stable pattern
        for i in range(100):
            wrapper.learn_one({"x": float(i)}, y=float(i))

        # Introduce abrupt drift
        for i in range(100):
            wrapper.learn_one({"x": float(i)}, y=float(i) + 1000.0)

        # Should have detected at least one drift
        # (may or may not depending on ADWIN sensitivity)
        pred = wrapper.predict_one({"x": 50.0})
        assert isinstance(pred, float)

    def test_replacement_strategy(self):
        model = LinearRegression(learning_rate=0.01)
        wrapper = DriftAdaptiveWrapper(model, strategy="replacement", grace_period=20)

        for i in range(200):
            wrapper.learn_one({"x": float(i % 10)}, y=float(i % 10))

        pred = wrapper.predict_one({"x": 5.0})
        assert isinstance(pred, float)

    def test_clear_resets_state(self):
        model = LinearRegression(learning_rate=0.01)
        wrapper = DriftAdaptiveWrapper(model, strategy="reset")
        wrapper.learn_one({"x": 1.0}, y=1.0)
        wrapper.clear()
        assert wrapper._n == 0
        assert wrapper._drift_count == 0

    def test_drift_count_tracks(self):
        model = LinearRegression(learning_rate=0.01)
        wrapper = DriftAdaptiveWrapper(model, strategy="reset", grace_period=5)
        assert wrapper.drift_count == 0

    def test_decay_strategy_runs(self):
        model = LinearRegression(learning_rate=0.01)
        wrapper = DriftAdaptiveWrapper(model, strategy="decay", grace_period=10)
        for i in range(50):
            wrapper.learn_one({"x": float(i)}, y=float(i))
        pred = wrapper.predict_one({"x": 25.0})
        assert isinstance(pred, float)
