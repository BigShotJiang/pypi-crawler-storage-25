import math

import numpy as np
import pytest

from incre_ml.anomaly import ZScoreDetector
from incre_ml.classification import LogisticRegression
from incre_ml.drift import ADWIN, EDDM, HddmA, PageHinkleyDrift
from incre_ml.federated.aggregation import FederatedAveraging
from incre_ml.federated.ensemble import FederatedEnsemble
from incre_ml.forecasting import NaiveForecaster
from incre_ml.linear import LinearRegression
from incre_ml.uncertainty import ConformalRegressor, ResidualUncertaintyWrapper


def test_uncertainty_wrappers_parameter_validation_and_contracts() -> None:
    with pytest.raises(ValueError):
        ConformalRegressor(NaiveForecaster(), window_size=0)
    with pytest.raises(ValueError):
        ConformalRegressor(NaiveForecaster(), alpha=0.0)
    with pytest.raises(ValueError):
        ConformalRegressor(NaiveForecaster(), alpha=1.0)

    base = NaiveForecaster()
    conformal = ConformalRegressor(base, window_size=8, alpha=0.2)
    resid_wrap = ResidualUncertaintyWrapper(NaiveForecaster())

    for y in [10.0, 10.2, 9.8, 10.1, 9.9, 10.0, 10.3, 9.7, 10.0]:
        conformal.learn_one({}, y)
        resid_wrap.learn_one({}, y)

    pred_c, q = conformal.predict_with_uncertainty({})
    pred_r, std = resid_wrap.predict_with_uncertainty({})

    assert isinstance(pred_c, float)
    assert isinstance(q, float)
    assert q >= 0.0
    assert math.isfinite(q)
    assert isinstance(conformal.explain_one({}), dict)
    assert "conformal_interval" in conformal.explain_one({})

    assert isinstance(pred_r, float)
    assert isinstance(std, float)
    assert std >= 0.0
    assert math.isfinite(std)
    assert isinstance(resid_wrap.explain_one({}), dict)
    assert "residual_std" in resid_wrap.explain_one({})


def test_conformal_interval_width_increases_with_noise() -> None:
    model = ConformalRegressor(NaiveForecaster(), window_size=40, alpha=0.1)
    rng = np.random.default_rng(42)

    for _ in range(40):
        model.learn_one({}, float(10.0 + rng.normal(0, 0.1)))
    _, q_stable = model.predict_with_uncertainty({})

    for _ in range(40):
        model.learn_one({}, float(10.0 + rng.normal(0, 3.0)))
    _, q_noisy = model.predict_with_uncertainty({})

    assert q_noisy >= q_stable


def test_federated_aggregation_validates_weights_and_keys() -> None:
    weights = [{"w": 1.0}, {"w": 3.0}]
    out = FederatedAveraging.aggregate(weights, [1.0, 3.0])
    assert out["w"] == pytest.approx(2.5)

    with pytest.raises(ValueError):
        FederatedAveraging.aggregate(weights, [1.0])
    with pytest.raises(ValueError):
        FederatedAveraging.aggregate(weights, [0.0, 0.0])
    with pytest.raises(ValueError):
        FederatedAveraging.aggregate(weights, [1.0, -1.0])
    with pytest.raises(ValueError):
        FederatedAveraging.aggregate([{"a": 1.0}, {"b": 2.0}], [1.0, 1.0])


def test_federated_ensemble_contracts_and_sync_resets_counts() -> None:
    with pytest.raises(ValueError):
        FederatedEnsemble(LinearRegression(), client_ids=[])
    with pytest.raises(ValueError):
        FederatedEnsemble(LinearRegression(), client_ids=["A", "A"])

    ens = FederatedEnsemble(LinearRegression(learning_rate=0.05), client_ids=["A", "B"])
    with pytest.raises(KeyError):
        ens.learn_one("Z", {"x": 1.0}, 1.0)

    for _ in range(30):
        ens.learn_one("A", {"x": 1.0}, 5.0)
    for _ in range(5):
        ens.learn_one("B", {"x": 1.0}, 20.0)

    assert ens.client_samples["A"] == 30
    assert ens.client_samples["B"] == 5
    ens.sync()
    assert ens.client_samples["A"] == 0
    assert ens.client_samples["B"] == 0
    pred = ens.predict_global({"x": 1.0})
    assert isinstance(pred, float)
    assert math.isfinite(pred)


def test_drift_detectors_validate_params_and_handle_edge_inputs() -> None:
    with pytest.raises(ValueError):
        ADWIN(delta=0.0)
    with pytest.raises(ValueError):
        ADWIN(delta=1.0)
    ad = ADWIN(delta=0.01)
    with pytest.raises(ValueError):
        ad.update(float("nan"))

    with pytest.raises(ValueError):
        PageHinkleyDrift(delta=-1.0)
    with pytest.raises(ValueError):
        PageHinkleyDrift(threshold=0.0)
    with pytest.raises(ValueError):
        PageHinkleyDrift(alpha=0.0)
    ph = PageHinkleyDrift()
    with pytest.raises(ValueError):
        ph.update(float("inf"))

    with pytest.raises(ValueError):
        HddmA(drift_confidence=0.0)
    with pytest.raises(ValueError):
        HddmA(warning_confidence=2.0)
    with pytest.raises(ValueError):
        HddmA(drift_confidence=0.01, warning_confidence=0.001)


def test_drift_detectors_detect_shift_and_flags_are_not_sticky() -> None:
    rng = np.random.default_rng(7)

    ad = ADWIN(delta=0.01)
    for _ in range(80):
        ad.update(float(rng.normal(0.0, 0.05)))
    detected = any(ad.update(float(rng.normal(2.0, 0.05))) for _ in range(80))
    assert detected

    ph = PageHinkleyDrift(delta=0.001, threshold=5.0, alpha=0.99)
    for _ in range(50):
        ph.update(0.0)
    ph_detected = any(ph.update(3.0) for _ in range(100))
    assert ph_detected

    eddm = EDDM()
    for _ in range(50):
        eddm.update(True)
    _ = eddm.update(False)
    first_flag = eddm.warning or eddm.drifted
    for _ in range(10):
        eddm.update(True)
    assert not (eddm.warning and not first_flag) or isinstance(eddm.warning, bool)
    # Main regression check: flags are recomputed each call, not permanently sticky.
    assert isinstance(eddm.drifted, bool)
    assert isinstance(eddm.warning, bool)

    h = HddmA(drift_confidence=0.001, warning_confidence=0.01)
    for _ in range(50):
        h.update(True)
    for _ in range(50):
        h.update(False)
        if h.warning or h.drifted:
            break
    assert isinstance(h.warning, bool)
    assert isinstance(h.drifted, bool)


def test_api_contract_representative_models() -> None:
    # Regressor contract
    reg = LinearRegression()
    for _ in range(5):
        reg.learn_one({"x": 1.0}, 2.0)
    pred = reg.predict_one({"x": 1.0})
    expl = reg.explain_one({"x": 1.0})
    assert isinstance(pred, float)
    assert math.isfinite(pred)
    assert isinstance(expl, dict)

    # Classifier contract
    clf = LogisticRegression()
    for _ in range(10):
        clf.learn_one({"x": 1.0}, 1)
        clf.learn_one({"x": -1.0}, 0)
    y_hat = clf.predict_one({"x": 1.0})
    proba = clf.predict_proba_one({"x": 1.0})
    c_expl = clf.explain_one({"x": 1.0})
    assert y_hat in {0, 1}
    assert isinstance(proba, dict)
    assert 0.0 <= sum(proba.values()) <= 1.0000001
    assert all(0.0 <= float(v) <= 1.0 for v in proba.values())
    assert isinstance(c_expl, dict)

    # Detector contract
    det = ZScoreDetector(feature_name="v")
    for _ in range(10):
        det.learn_one({"v": 1.0})
    score = det.score_one({"v": 5.0})
    assert isinstance(score, float)
    assert 0.0 <= score <= 1.0
