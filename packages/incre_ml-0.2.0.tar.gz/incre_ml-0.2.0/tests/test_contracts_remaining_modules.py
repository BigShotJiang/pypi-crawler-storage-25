from datetime import datetime

import pytest

from incre_ml.anomaly.industrial import AlertSuppressionWrapper, ResidualZScoreDetector
from incre_ml.base.regressor import Regressor
from incre_ml.compose import (
    ChampionChallenger,
    ColumnTransformer,
    FeatureUnion,
    Pipeline,
)
from incre_ml.forecasting import NaiveForecaster
from incre_ml.metrics import (
    F1,
    MAE,
    MAPE,
    MSE,
    RMSE,
    SMAPE,
    Accuracy,
    BalancedAccuracy,
    BrierScore,
    CoverageError,
    CoverageProbability,
    LogLoss,
    Precision,
    Recall,
)
from incre_ml.preprocessing import (
    DateTimeFeaturesTransformer,
    LagFeatureTransformer,
    MinMaxScaler,
    RollingStatsTransformer,
    SelectKBest,
    StandardScaler,
)
from incre_ml.serving import PredictService
from incre_ml.tree import HoeffdingTreeRegressor


class ConstantRegressor(Regressor):
    def __init__(self, value: float = 0.0) -> None:
        self.value = value

    def learn_one(self, x, y):
        return self

    def predict_one(self, x):
        return float(self.value)

    def explain_one(self, x):
        return {}

    def clear(self) -> None:
        self.value = 0.0


def test_compose_exports_contracts() -> None:
    with pytest.raises(ValueError):
        Pipeline([])
    with pytest.raises(ValueError):
        FeatureUnion([])
    with pytest.raises(ValueError):
        ColumnTransformer([])
    with pytest.raises(ValueError):
        Pipeline([NaiveForecaster(), StandardScaler()])

    scaler = StandardScaler()
    dt = DateTimeFeaturesTransformer("ts")
    union = FeatureUnion([scaler, dt])
    x = {"v": 10.0}
    union.learn_one(x, y=1.0)
    xu = union.transform_one(x)
    assert "v" in xu
    xdt_union = union.transform_one({"v": 10.0, "ts": datetime(2024, 1, 1, 13, 0)})
    assert "ts_hour" in xdt_union

    col = ColumnTransformer([("s", StandardScaler(), ["v"])])
    col.learn_one({"v": 1.0, "u": 9.0}, y=1.0)
    xc = col.transform_one({"v": 2.0, "u": 9.0})
    assert "u" in xc and "v" in xc

    pipe = Pipeline([StandardScaler(), NaiveForecaster()])
    for y in [1.0, 2.0, 3.0]:
        _ = pipe.predict_one({"v": y})
        pipe.learn_one({"v": y}, y)
    assert isinstance(pipe.predict_one({"v": 4.0}), float)
    assert isinstance(pipe.explain_one({"v": 4.0}), dict)

    # Pipeline ending in transformer should still apply the final transform in
    # predict_one.
    tpipe = Pipeline([DateTimeFeaturesTransformer("ts")])
    out = tpipe.predict_one({"ts": "2024-01-01T09:00:00"})
    assert isinstance(out, dict)
    assert out["ts_hour"] == 9.0

    cc = ChampionChallenger(NaiveForecaster(), NaiveForecaster())
    for y in [1.0, 2.0, 3.0]:
        cc.learn_one({}, y)
    summary = cc.summary
    assert set(summary.keys()) == {"champion_mae", "challenger_mae"}
    assert summary["champion_mae"] >= 0.0


def test_pipeline_and_wrapper_forward_supervised_targets_to_detectors() -> None:
    det = ResidualZScoreDetector(model=ConstantRegressor(0.0), threshold=3.0)
    pipe = Pipeline([det])
    for _ in range(8):
        pipe.learn_one({"v": 0.0}, y=0.0)
    pipe.learn_one({"v": 0.0}, y=15.0)
    assert pipe.score_one({"v": 15.0}) > 0.0

    wrapped = AlertSuppressionWrapper(
        ResidualZScoreDetector(model=ConstantRegressor(0.0), threshold=3.0)
    )
    for _ in range(8):
        wrapped.learn_one({"v": 0.0}, y=0.0)
    wrapped.learn_one({"v": 0.0}, y=10.0)
    assert wrapped.score_one({"v": 10.0}) > 0.0


def test_preprocessing_exports_contracts() -> None:
    ss = StandardScaler()
    mm = MinMaxScaler()
    for x in [{"a": 0.0}, {"a": 10.0}]:
        ss.learn_one(x)
        mm.learn_one(x)
    xs = ss.transform_one({"a": 5.0})
    xm = mm.transform_one({"a": 5.0})
    assert isinstance(xs["a"], float)
    assert 0.0 <= xm["a"] <= 1.0

    with pytest.raises(ValueError):
        SelectKBest(k=0)
    sk = SelectKBest(k=1)
    for i in range(1, 20):
        sk.learn_one({"a": float(i), "b": 1.0}, float(i))
    xt = sk.transform_one({"a": 1.0, "b": 2.0})
    assert len(xt) == 1

    with pytest.raises(ValueError):
        LagFeatureTransformer(lags=[])
    with pytest.raises(ValueError):
        LagFeatureTransformer(lags=[0, 1])
    lag = LagFeatureTransformer(lags=[1, 2], feature_name="y")
    lag.learn_one({}, 10.0)
    lag.learn_one({}, 12.0)
    xl = lag.transform_one({})
    assert xl["y_lag_1"] == 12.0
    assert xl["y_lag_2"] == 10.0

    with pytest.raises(ValueError):
        RollingStatsTransformer(window_size=0)
    rst = RollingStatsTransformer(window_size=3, feature_name="y")
    for y in [1.0, 2.0, 3.0]:
        rst.learn_one({}, y)
    xr = rst.transform_one({})
    assert "y_rolling_mean" in xr and "y_rolling_std" in xr
    assert xr["y_rolling_mean"] == pytest.approx(2.0)

    dt = DateTimeFeaturesTransformer("ts")
    xdt = dt.transform_one({"ts": "2024-02-01T14:15:00"})
    assert xdt["ts_hour"] == 14.0
    xbad = dt.transform_one({"ts": "not-a-date"})
    assert "ts_hour" not in xbad


def test_metrics_exports_contracts_and_bounds() -> None:
    with pytest.raises(ValueError):
        MAPE(epsilon=0.0)

    reg_metrics = [MAE(), MSE(), RMSE(), MAPE(), SMAPE()]
    for m in reg_metrics:
        for y_true, y_pred in [(1.0, 1.2), (2.0, 1.5), (0.0, 0.1)]:
            m.update(y_true, y_pred)
        v = m.get()
        assert isinstance(v, float)
        assert v >= 0.0
        m.clear()
        assert m.get() == 0.0

    picp = CoverageProbability()
    cerr = CoverageError(target_coverage=0.8)
    for y, interval in [(1.0, (0.0, 2.0)), (2.0, (3.0, 1.0)), (5.0, (0.0, 1.0))]:
        picp.update(y, 0.0, interval=interval)
        cerr.update(y, 0.0, interval=interval)
    assert 0.0 <= picp.get() <= 1.0
    assert 0.0 <= cerr.coverage_probability <= 1.0
    assert 0.0 <= cerr.get() <= 1.0

    cls_metrics = [
        Accuracy(),
        Precision(),
        Recall(),
        F1(),
        BrierScore(),
        LogLoss(),
        BalancedAccuracy(),
    ]
    probs = [0.9, 0.2, 0.8, 0.4]
    ys = [1, 0, 1, 0]
    yps = [1, 0, 1, 1]
    for m in cls_metrics:
        for y, yp, p in zip(ys, yps, probs, strict=True):
            if isinstance(m, BrierScore | LogLoss):
                m.update(y, yp, y_proba=p)
            else:
                m.update(y, yp)
        v = m.get()
        assert isinstance(v, float)
        if not isinstance(m, LogLoss):
            assert 0.0 <= v <= 1.0 + 1e-9
        else:
            assert v >= 0.0

    brier = BrierScore()
    brier.update(1, 1, y_proba=5.0)
    assert 0.0 <= brier.get() <= 1.0


def test_tree_and_serving_exports_contracts() -> None:
    with pytest.raises(ValueError):
        HoeffdingTreeRegressor(delta=0.0)
    with pytest.raises(ValueError):
        HoeffdingTreeRegressor(grace_period=0)
    tree = HoeffdingTreeRegressor(grace_period=5)
    for i in range(30):
        x = {"x": float(i % 10)}
        y = 0.0 if x["x"] < 5 else 10.0
        tree.learn_one(x, y)
    pred = tree.predict_one({"x": 8.0})
    expl = tree.explain_one({"x": 8.0})
    assert isinstance(pred, float)
    assert isinstance(expl, dict)

    with pytest.raises(ValueError):
        PredictService(None)
    svc = PredictService(tree)
    payload = svc.predict({"x": 8.0})
    assert set(payload.keys()) == {"prediction", "explanation"}
    svc.update({"x": 2.0}, 0.0)

    class NoPredict:
        def learn_one(self, x, y):  # pragma: no cover - local test helper
            return self

    with pytest.raises(TypeError):
        PredictService(NoPredict()).predict({})

    class NoLearn:
        def predict_one(self, x):  # pragma: no cover - local test helper
            return 1.0

    with pytest.raises(TypeError):
        PredictService(NoLearn()).update({}, 1.0)
