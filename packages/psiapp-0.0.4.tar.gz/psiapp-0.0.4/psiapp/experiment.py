import logging
log = logging.getLogger()

from pathlib import Path

from atom.api import Atom, Dict, Enum, List, Str, Value

from psi.experiment.api import (paradigm_manager, ParadigmNotFound)


class Experiment(Atom):

    paradigm = Value()

    preference = Str()

    #: List of available preferences. Primarily used for updating the GUI.
    preferences = List()

    #: Plugins selected for load
    plugins = List(Str())

    #: Supplemental note to append based on the button clicked.
    mode_notes = Dict()

    def iter_selectable_plugins(self):
        for plugin in self.paradigm.plugins:
            if plugin.required:
                continue
            if plugin.info.get('hide', False):
                continue
            yield plugin

    def _default_mode_notes(self):
        return {}

    def update_preferences(self):
        # This will force a change notification in the Enaml ObjectCombo,
        # thereby refreshing the list of options.
        self.preferences = self.paradigm.list_preferences().copy()

    def __init__(self, paradigm, plugins=None, preference=None, **kwargs):
        if isinstance(paradigm, str):
            paradigm = paradigm_manager.get_paradigm(paradigm)
        self.paradigm = paradigm
        self.update_preferences()

        # Make sure the plugins saved to the config file are valid plugins (we
        # sometimes remove or rename plugins). If the plugin is no longer
        # valid, remove it. If the plugin is required, remove it as a plugin
        # that the user can select from in the GUI (since it automatically gets
        # loaded).
        plugins = set() if plugins is None else set(plugins)
        valid_plugins = set(p.id for p in self.iter_selectable_plugins())
        plugins = list(plugins & valid_plugins)

        # We only save preference name, not the full path to the preference. We
        # need to restore the full path to the preference by scanning through
        # the list of avaialble preferences. This allows for portability across
        # systems.
        if preference is None:
            preference = ''
        else:
            preference = Path(preference)
            for valid_preference in self.preferences:
                if valid_preference.stem == preference.stem:
                    preference = str(valid_preference)
                    break
            else:
                log.warning('Invalid preference requested for %s: %s', paradigm,
                            preference)
                preference = ''

        super().__init__(paradigm=paradigm, plugins=plugins,
                         preference=preference, **kwargs)

    def __getstate__(self):
        state = super().__getstate__()
        # Convert some keys to things that can be JSON-serialized. Don't save
        # the full path to the preference because we want this to be portable
        # across environments and installs.
        state['preference'] = Path(state['preference']).name
        state['paradigm'] = state['paradigm'].name
        return state

    def freeze(self, mode):
        '''
        Return experiment in which mode and ear are fixed. Used in running
        sequences.

        Parameters
        ----------
        mode : str
            One of the modes the paradigm can be run under (e.g., 'run',
            'ipsi', 'contra').

        This is used for sequences where we may need to specify run mode (i.e.,
        ipsi vs. contra).
        '''
        if mode is None:
            mode = self.modes[0]
        return FrozenExperiment(
            paradigm=self.paradigm,
            preference=self.preference,
            plugins=self.plugins,
            mode_notes=self.mode_notes,
            mode=mode,
        )


class FrozenExperiment(Experiment):
    '''
    Subclass of Experiment in which we have frozen the ear and mode (used for
    sequences).
    '''
    mode = Str()

    #: If either, then ear will be drawn from what is selected.
    ear = Enum('selected', 'left', 'right')


def load_experiments(seq, experiment_class=Experiment):
    '''
    Helper function for loading experiments from JSON file
    '''
    experiments = []
    for s in seq:
        # Remove obsolete label argument from saved paradigms and
        # legacy modes since we changed how this is handled (it was
        # always a hack to put in the file).
        s.pop('label', None)
        s.pop('modes', None)
        mode_notes = s.get('mode_notes', {})
        s['mode_notes'] = {k.lower(): v for k, v in mode_notes.items()}
        try:
            experiments.append(experiment_class(**s))
        except ParadigmNotFound:
            pass
    return experiments
