# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-04-09 10:00:00
@LastEditTime: 2026-04-13 11:22:33
@LastEditors: HuangJianYi
@Description: 翻译帮助类
"""
import os
import json
from seven_framework import *
from seven_cloudapp_frame.libs.common import *

class TranslationHelper:
    """
    :description: 翻译帮助类
    """
    _instance = None
    _translations = {}
    _default_locale = share_config.get_value("locale", 'zh_CN')
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._load_translations()
        return cls._instance
    
    def _load_translations(self):
        """
        :description: 加载翻译文件
        """
        def load_from_directory(dir_path):
            if not os.path.exists(dir_path):
                return
            
            for filename in os.listdir(dir_path):
                if not filename.endswith(".json"):
                    continue
                
                locale = filename[:-5]
                file_path = os.path.join(dir_path, filename)
                
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        translations = json.load(f)
                    
                    if locale in self._translations:
                        self._translations[locale].update(translations)
                    else:
                        self._translations[locale] = translations
                except Exception as e:
                    print(f"加载翻译文件 {filename} 失败: {e}")
        
        locales_dir = share_config.get_value("locales_dir")
        if locales_dir:
            load_from_directory(locales_dir)
        
        default_locales_dir = os.path.join(os.path.dirname(__file__), "..", "..", "locales")
        load_from_directory(default_locales_dir)
    
    def get_locale(self, context):
        """
        :description: 获取当前语言环境
        :param context: 请求上下文
        :return: str 语言环境代码
        """
        # 1. 从Clientheaderinfo中获取
        device_info = context.get_device_info_dict() if hasattr(context, "get_device_info_dict") else {}
        locale = device_info.get("lang", "")
        if locale:
            return locale
        
        # 2. 使用默认语言
        return self._default_locale
    
    def translate(self, key, locale=None, **kwargs):
        """
        :description: 翻译文本
        :param key: 翻译键（中文）
        :param locale: 语言环境
        :param kwargs: 替换参数
        :return: str 翻译后的文本
        """
        if not locale:
            locale = self._default_locale
        
        # 尝试获取翻译
        translation = self._translations.get(locale, {})
        if locale == 'en':
            if "参数错误,缺少必传参数" in key:
                return "Parameter error, missing required parameters"
            elif "此商品ID已关联活动" in key:
                return "This product ID is already associated with an activity"
            elif "对不起,该商品已绑定" in key:
                return "Sorry, the product has already been bound to other price tiers"



        text = translation.get(key, key)
        
        # 替换参数
        if kwargs:
            text = text.format(**kwargs)
        
        return text

# 全局实例
translation_helper = TranslationHelper()
