# CHANGELOG

<!-- version list -->

## v1.3.2 (2026-04-08)

### Bug Fixes

- Use python3 -m pip instead of pip3 in install script to avoid version mismatch
  ([`41f7e4b`](https://github.com/agntspace/agntspace/commit/41f7e4b50497b1b2112eda375572a85137f60b96))


## v1.3.1 (2026-04-08)

### Bug Fixes

- Add --no-cache-dir to install script to prevent stale package versions
  ([`fb9c204`](https://github.com/agntspace/agntspace/commit/fb9c204e92d9862298a2ea1a499f6a1f5d1bba4a))


## v1.3.0 (2026-04-08)

### Features

- Update version to 1.1.1 and add fastembed dependency for semantic search
  ([`2a9d2a3`](https://github.com/agntspace/agntspace/commit/2a9d2a3bb8b4474eba12c8248a3b0dfa09225ee0))


## v1.2.0 (2026-04-08)

### Features

- Add installation scripts for Windows and Linux
  ([`1432a5c`](https://github.com/agntspace/agntspace/commit/1432a5cc5f8ee47d91747c4a919458efd3ee4c26))


## v1.1.0 (2026-04-08)

### Features

- Enable publishing to PyPI in release workflow
  ([`c15b197`](https://github.com/agntspace/agntspace/commit/c15b197a097b7c2b00b7340bc9d537e179d70eb9))


## v1.0.0 (2026-04-08)

- Initial Release
