"""Knowledge Base service — full LLM Wiki implementation.

Based on the LLM Wiki pattern (Karpathy, 2026):
  raw/      — drop zone (user dumps files, agent processes + moves)
  library/  — organized archive (category/YYYY-MM/file)
  wiki/     — LLM-compiled articles with [[backlinks]]
    entities/  — person, organization, tool pages
    concepts/  — topic and concept pages
    sources/   — source summary pages
    .index.md  — content catalog
    .concepts.md — concept map
  output/   — generated reports, slides, charts
  SCHEMA.md — conventions, structure, workflows
  log.md    — chronological operation log

Rules:
- LLM is editor, not writer. Every sentence traces to a source.
- Gaps marked [TODO: ...], never hallucinated.
- Contradictions flagged explicitly.
- Incremental compilation — only new/changed sources processed.
- Tiered context loading — index first, then targeted reads.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from agntspace.llm.base import LLMProvider
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)

# All wiki subdirectories that may contain articles
_WIKI_SUBDIRS = ("entities", "concepts", "sources", "source_summary", "synthesis", "decisions", "projects")

# ── Page templates per entity type ──

_TEMPLATES: dict[str, str] = {
    "person": """---
title: "{title}"
entity_type: person
category: "{category}"
taxonomy_path: "{taxonomy_path}"
status: draft
sources: {sources}
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

# {title}

## Overview
[TODO: biographical summary from sources]

## Role & Affiliations
[TODO: roles, organizations, positions]

## Key Contributions
[TODO: notable work, ideas, achievements]

## Relationships
[TODO: connections to other entities in the KB]

## Open Questions
[TODO: what don't we know about this person that we should?]

## Counter-Arguments & Controversies
[TODO: critiques, controversies, opposing views]

## Sources
{source_list}
""",
    "organization": """---
title: "{title}"
entity_type: organization
category: "{category}"
taxonomy_path: "{taxonomy_path}"
status: draft
sources: {sources}
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

# {title}

## Overview
[TODO: what this organization does]

## Key People
[TODO: people connected to this org]

## Products & Projects
[TODO: notable outputs]

## Timeline
[TODO: key events and dates]

## Open Questions
[TODO: what don't we know about this organization that we should?]

## Sources
{source_list}
""",
    "concept": """---
title: "{title}"
entity_type: concept
category: "{category}"
taxonomy_path: "{taxonomy_path}"
status: draft
sources: {sources}
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

# {title}

## Definition
[TODO: clear definition from sources]

## Context & Background
[TODO: where this concept comes from]

## Key Details
[TODO: important specifics]

## Related Concepts
[TODO: [[links]] to related concepts]

## Open Questions
[TODO: what don't we know about this topic that we should?]

## Counter-Arguments & Data Gaps
[TODO: critiques, limitations, unknowns]

## Sources
{source_list}
""",
    "synthesis": """---
title: "Synthesis: {title}"
entity_type: synthesis
category: "cross-source"
taxonomy_path: "{taxonomy_path}"
status: draft
related: {sources}
sources: {sources}
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

# Synthesis: {title}

## Connections
[TODO: how the sources relate to each other]

## Key Insight
[TODO: what these sources reveal together that neither says alone]

## Implications
[TODO: what this means for the domain]

## Open Questions
[TODO: what this cross-reference raises but doesn't answer]

## Sources
{source_list}
""",
    "source_summary": """---
title: "Source: {title}"
entity_type: source_summary
category: "{category}"
taxonomy_path: "{taxonomy_path}"
status: verified
source_file: "{filename}"
library_path: "{library_path}"
source_url: "{source_url}"
vault_source: "{vault_source}"
cite_key: "{cite_key}"
author: agent
agent: librarian
date_created: "{date_created}"
date_updated: "{date_updated}"
---

# {title}
{image_section}
## Summary
{summary}

## Key Takeaways
{concepts}

## Contradictions with Existing Knowledge
[TODO: note where this source disagrees with existing wiki content]

## Open Questions
[TODO: what questions does this source raise that aren't answered?]

## Original Source
- File: [{filename}](<{library_path}>)
{vault_source_line}- Category: {category}
- Ingested: {date_updated}
- Hash: {hash}
""",
    "decision_record": """---
title: "Decision: {title}"
entity_type: decision_record
status: active
date: "{date}"
affects: {affects}
supersedes: ""
author: agent
agent: editor
---

# {title}

## Decision
{decision}

## Context
{context}

## Alternatives Considered
{alternatives}

## Reasoning
{reasoning}

## Consequences
{consequences}
""",
}

_SCHEMA_TEMPLATE = """---
title: "{topic} — Knowledge Base Schema"
type: kb_schema
author: user
---

# {topic}

## Purpose
<!-- What is this knowledge base about? What questions should it answer? -->

## Conventions
- Every claim must trace to a source. No hallucinated content.
- Gaps marked with [TODO: ...] rather than invented filler.
- Articles use [[wiki-links]] for cross-references.
- Each article has frontmatter: title, entity_type, category, status, sources, author.
- Contradictions tracked in "Counter-Arguments & Data Gaps" sections.

## Entity Types
- **person** — people (wiki/entities/person-name.md)
- **organization** — companies, institutions (wiki/entities/org-name.md)
- **concept** — topics, ideas, methods (wiki/concepts/concept-name.md)
- **source_summary** — per-source summary (wiki/sources/filename.md)
- **synthesis** — cross-source analysis, insights connecting multiple sources (wiki/synthesis/slug.md)
- **decision_record** — structural decisions about wiki organization (wiki/decisions/slug.md)

## Status Values
- **draft** — auto-generated, not yet verified
- **verified** — human-reviewed and confirmed
- **stale** — may be outdated by newer sources

## Structure
- `inbox/` — drop zone for new source files
- `library/` — organized sources (agent-maintained)
- `wiki/entities/` — entity pages (people, organizations)
- `wiki/concepts/` — concept and topic pages
- `wiki/sources/` — source summary pages
- `wiki/synthesis/` — cross-source analysis and insights
- `wiki/decisions/` — structural decision records (why the wiki is shaped this way)
- `wiki/projects/` — project-scoped knowledge (project-specific entities, concepts, notes)
- `output/` — research outputs, reports, slides

## Project Scoping
When sources are project-specific, articles go to `wiki/projects/<project-slug>/`.
Each project gets an overview page at `wiki/projects/<project-slug>/<project-slug>.md`.
Global knowledge stays in top-level categories. Project articles link to global ones via [[wikilinks]].

## Article Sections (required)
Every article must include:
- Summary paragraph after the title
- Key content sections
- **Open Questions** — what we don't know yet about this topic
- **Sources** — links to source files

## Notes
<!-- Domain-specific instructions for the agent -->
"""

_INDEX_TEMPLATE = """---
title: "{topic} — Index"
type: kb_index
author: agent
agent: librarian
updated: "{date}"
source_count: 0
article_count: 0
---

# {topic} — Knowledge Base

## Sources

<!-- Each source: link, one-line summary, date ingested -->

## Entities

<!-- Entity pages: [[link]] — one-line description -->

## Concepts

<!-- Concept pages: [[link]] — one-line description -->

## Statistics
- Sources ingested: 0
- Entity pages: 0
- Concept pages: 0
- Last updated: {date}
"""

# ── Source type classification ──

_SOURCE_TYPES = {
    "paper": {"exts": {".pdf"}, "prompt_focus": "Extract thesis, methodology, key findings, citations. Academic rigor."},
    "article": {"exts": {".md", ".html", ".htm", ".txt", ".rst"}, "prompt_focus": "Extract main arguments, key facts, quotes, author perspective."},
    "data": {"exts": {".csv", ".tsv", ".yaml", ".yml"}, "prompt_focus": "Describe the data structure, key fields, notable patterns, size."},
    "chat_history": {"exts": {".jsonl"}, "prompt_focus": "Extract key decisions, insights, topics discussed, action items from this conversation."},
    "export": {"exts": {".json"}, "prompt_focus": "Extract key topics, decisions, people mentioned, and actionable insights."},
    "transcript": {"exts": {".vtt", ".srt"}, "prompt_focus": "Extract key discussion points, decisions made, action items, attendees mentioned."},
    "code": {"exts": {".py", ".js", ".ts"}, "prompt_focus": "Describe purpose, key functions, architecture, dependencies."},
    "image": {"exts": {".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp"}, "prompt_focus": "Describe what the image shows, any text/labels visible, context."},
}

_CLASSIFY_PROMPT_FALLBACK = """Classify this source document and extract information.

Source file: {filename}
Source type: {source_type}
Type-specific focus: {type_focus}

IMPORTANT: The body text may start with ads, navigation, or sidebar content captured by
web clippers. Use the SOURCE METADATA (title, description, URL) to determine the article's
TRUE topic. Ignore unrelated noise at the start of the body.

KB Schema:
{schema}

Existing wiki index (what's already in the KB):
{index}

RULES:
- Every fact must trace to the source text. Do NOT invent information.
- If something is unclear, write [TODO: clarify from source].
- Note any contradictions with the existing wiki index.
- Use the frontmatter title/description as the authoritative topic — not the first line of body text.

Produce:

```summary
(3-5 sentence summary of the source, citing specific details)
```

```concepts
- concept1
- concept2
```

```entities
- person: Name — role/description
- organization: Org Name — what they do
```

```contradictions
(any facts that contradict existing wiki content, or "none found")
```

```wiki_updates
List ONLY entities and concepts that are SIGNIFICANT to this source — not every noun mentioned.

Significance test: would someone search for this concept to understand the source's domain?
- YES: "Bowtie Analysis", "FMEA", "Sarah Chen" — core to the domain, worth a page
- NO: "hexadecimal notation", "bugs", "court cases", "time management" — generic, passing mentions

CREATE sparingly. Prefer UPDATE to existing pages. Maximum 5 CREATE lines per source.

Format:
- CREATE entities/person-slug: Full name and role | REASON: why this person matters
- CREATE entities/org-slug: Organization name | REASON: significance to the domain
- CREATE concepts/topic-slug: What this concept is about | REASON: why it deserves its own page
- UPDATE concepts/existing-slug: What new info to add from this source
```

```bibliography
- title: (exact title of the work — not the filename)
- authors: (comma-separated list of authors, or "unknown")
- date: (publication date YYYY-MM-DD or YYYY, or "unknown")
- publisher: (journal, conference, website, publisher name, or "unknown")
- doi: (DOI if visible, or "")
```"""

_COMPILE_PROMPT_FALLBACK = """You are a knowledge base wiki compiler.

KB SCHEMA:
{schema}

WIKI INDEX:
{index}

KNOWLEDGE TAXONOMY (assign each article a taxonomy_path from this tree):
{taxonomy}

EXISTING ARTICLES (summaries):
{existing_articles}

NEW SOURCES TO PROCESS:
{sources}

VALID SUBDIRECTORIES (use ONLY these — no others):
- entities/ — people and organizations
- concepts/ — topics, ideas, methods, standards
- synthesis/ — cross-source analysis (insights spanning multiple sources)
- sources/ — per-source summaries (created by ingest, not compile)
- decisions/ — structural decision records

RULES — CRITICAL:
1. You are an EDITOR, not a writer. Every sentence must trace to a source.
2. NEVER invent information. If data is missing, write [TODO: ...].
3. Use [[wiki-links]] generously for cross-references.
4. Flag contradictions explicitly in a "Counter-Arguments & Data Gaps" section.
5. Include [Source: filename] citations for every claim.
6. Use ONLY the valid subdirectories listed above. Meetings go in concepts/, events go in concepts/.
7. ALWAYS include taxonomy_path in frontmatter — pick the most specific matching node from the taxonomy.
8. WRITE FULL CONTENT — not stubs. Extract ALL available information from the sources into article sections. A person page must include their role, affiliations, contributions. A concept page must explain what it is, how it works, where it's used. Only use [TODO: ...] for information genuinely absent from the sources.
9. UPDATE existing articles that are stubs (mostly [TODO] placeholders). Fill them with real content from sources.
10. Include an "Open Questions" section listing what the sources don't answer.
11. Deduplicate: do NOT create new articles for entities/concepts that already have pages. Use the EXISTING slug.
12. QUALITY OVER QUANTITY. Only create articles for concepts that are CENTRAL to the sources — not every term mentioned. A concept article should have at least 3 sentences of real content. If you can't write 3 sourced sentences about it, it's not worth an article. Maximum 10 new articles per compile pass.

Output format — for each article (new OR updated stub):
```article:{{subdir}}/{{slug}}
---
title: "Article Title"
entity_type: "person|organization|concept"
category: "category-name"
taxonomy_path: "parent-slug/child-slug"
status: draft
related: ["other-slug"]
sources: ["source1.md"]
source_count: 1
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

(FULL article content with [[wiki-links]] and [Source: file] citations — NOT stubs)

## Open Questions
(what the sources don't tell us)

## Counter-Arguments & Data Gaps
(contradictions, unknowns)
```

After all entity/concept articles, if 2+ sources connect in a non-obvious way, create a SYNTHESIS page:
```article:synthesis/{{slug}}
---
title: "Synthesis: descriptive title"
entity_type: synthesis
category: "cross-source"
taxonomy_path: "relevant/path"
status: draft
related: ["entity-or-concept-1", "entity-or-concept-2"]
sources: ["source1.md", "source2.md"]
source_count: 2
author: agent
agent: "{agent}"
date_created: "{date}"
date_updated: "{date}"
---

(Cross-source insight — what do these sources reveal TOGETHER that neither says alone?)

## Connections
(how the sources relate)

## Implications
(what this means for the domain)

## Open Questions
(what this cross-reference raises but doesn't answer)
```

Only create synthesis pages when there is a genuine cross-source insight. Do NOT create them for trivial overlaps (same person mentioned in 2 sources is NOT a synthesis — that's just an entity page).

After all articles:
```concepts
## Category Name
- [[Concept One]] — brief description [Source: file]
```"""

_RESEARCH_PROMPT_FALLBACK = """You are a knowledge base research assistant.

KB SCHEMA:
{schema}

WIKI ARTICLES:
{context}

QUESTION:
{query}

RULES:
- Answer using ONLY wiki content. Cite articles: [See: Article Title]
- If the wiki lacks information, say exactly what's missing.
- Use [[wiki-links]] for concepts.
- Never invent facts not in the wiki.
- Mark uncertainties with [Unverified] or [TODO: needs source].

{output_instruction}"""

_REFLECT_PROMPT_FALLBACK = """You are a knowledge base structural analyst. The wiki must understand its own shape — not just what it knows, but WHY it knows things that way.

WHAT JUST CHANGED:
- Articles created: {articles_created}
- Files ingested: {files_ingested}

RECENTLY CREATED/MODIFIED ARTICLES (full content):
{recent_articles}

FULL WIKI STATE (titles and types):
{existing_articles}

KB SCHEMA:
{schema}

Analyze with these questions:
1. **Why were these articles created this way?** — What framing was chosen? Was "bowtie analysis" categorized as a concept rather than a process? Was a person filed globally rather than under a project? What alternatives existed?
2. **What got connected and what didn't?** — Which sources drove which articles? Are there obvious connections the compile missed?
3. **Ingestion bias** — Are early sources over-represented as hubs? Is the wiki shaped by what was ingested first rather than what matters most?
4. **Blind spots** — Topics the domain clearly requires but the wiki lacks. Questions the wiki should answer but can't.
5. **Structural debt** — Taxonomy mismatches, concepts that should be merged, entities that should be split.

RULES:
- Only create decision records for SIGNIFICANT structural choices — not routine additions.
- Each decision record must explain what ALTERNATIVE framing was possible and WHY this one was chosen.
- Be brutally honest. The point is to catch biases, not confirm choices.
- If nothing significant happened, say so.

Output format — ONLY if there are significant decisions:
```decision
title: Short decision title
decision: What was decided
context: What triggered this
alternatives: What other approaches were possible
reasoning: Why this choice
consequences: What this means going forward
affects: article-slug-1, article-slug-2
```

If no significant decisions were made, output:
```no_decisions
Routine update — no structural decisions to record.
```"""

_CONSOLIDATE_PROMPT_FALLBACK = """You are rewriting a wiki article that has accumulated incremental updates over time.

The article below contains the original content plus multiple "Updated from compile" sections appended at different dates. Your job is to merge everything into a single coherent, well-structured article.

Rules:
1. Preserve ALL factual content — do not lose any information from any update
2. Resolve contradictions: newer information supersedes older (use the dates to determine recency)
3. Remove the "Updated from compile" markers and date stamps — integrate the content naturally
4. Maintain the original structure (sections, headers) but reorganize if the updates make it clearer
5. Keep all [[wikilinks]] intact
6. Keep all [Source: ...] citations intact
7. Mark any remaining gaps with [TODO: ...]
8. Preserve the writing style and tone of the original
9. Output ONLY the consolidated article body (no frontmatter, no fences)"""

_LINT_PROMPT_FALLBACK = """You are a knowledge base health checker performing a deep wiki audit.

KB SCHEMA:
{schema}

WIKI INDEX:
{index}

STRUCTURAL ISSUES (pre-computed from file analysis — already verified):
{structural_issues}

ARTICLES (full content for semantic analysis):
{articles}

Your job is the SEMANTIC analysis. The structural issues above are already confirmed.
Focus on what only an LLM can detect:

1. **Contradictions** — conflicting facts across articles (same entity, different claims)
2. **Stale claims** — information that newer sources have likely superseded
3. **Missing cross-references** — related articles that should link to each other but don't
4. **Important concepts without pages** — ideas mentioned repeatedly across articles that deserve their own page
5. **Data gaps** — important questions the KB should answer but doesn't, topics that could be filled with a web search
6. **Unsourced claims** — statements not traced to any source file
7. **Quality issues** — articles that are mostly [TODO] placeholder text, or very thin compared to available sources

Output:
```issues
- [contradiction] Article "A" says X but Article "B" says Y
- [stale] Article "X" claim about Y may be outdated — check against newer sources
- [unsourced] Article "X" claims Y without citing a source
- [quality] Article "X" is mostly placeholder text (N TODOs, only M sentences of real content)
```

```suggestions
- [new_article] "Title" — mentioned in articles X, Y, Z but has no dedicated page
- [new_link] Article "A" should cross-reference [[B]] — they discuss related topics
- [investigate] "Question?" — researching this would fill a gap in the KB
- [web_search] "Search query" — this information gap could likely be filled with a web search
- [verify] Claim in "X" should be cross-checked — it may conflict with "Y"
- [merge] Articles "A" and "B" cover the same topic and should be consolidated
```"""


class KnowledgeBaseService:
    """Manages personal knowledge bases — full LLM Wiki implementation."""

    def __init__(
        self,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        llm: LLMProvider,
        skills_dir: Path | None = None,
        skill_loader: object | None = None,
        model_router: object | None = None,
        bibliography: object | None = None,
    ) -> None:
        self._reader = vault_reader
        self._writer = vault_writer
        self._llm = llm
        self._skills_dir = skills_dir
        self._skill_loader = skill_loader
        self._model_router = model_router
        self._bibliography = bibliography
        # Per-KB locks to prevent concurrent ingest (watcher + API racing)
        self._ingest_locks: dict[str, asyncio.Lock] = {}

    def _load_skill_rules(self, skill_name: str) -> str:
        """Load quality rules from a skill's SKILL.md body.

        Returns the "## Quality Rules" section (and below) if found, empty string otherwise.
        """
        if not self._skills_dir:
            return ""
        skill_path = self._skills_dir / "core" / skill_name / "SKILL.md"
        if not skill_path.exists():
            return ""
        try:
            import frontmatter as fm
            post = fm.load(str(skill_path))
            content = post.content
            # Extract from "## Quality Rules" onward (skip instructions, include rules)
            marker = "## Quality Rules"
            idx = content.find(marker)
            if idx >= 0:
                return content[idx:]
            return ""
        except Exception:
            return ""

    def _get_skill_prompt(self, skill_name: str) -> str:
        """Load system prompt from skill definition via SkillLoader.

        Falls back to empty string if the skill loader is unavailable or
        the skill has no System Prompt section.
        """
        if not self._skill_loader:
            return ""
        try:
            prompt = self._skill_loader.get_system_prompt(skill_name)
            return prompt or ""
        except Exception:
            return ""

    def _get_skill_rules(self, skill_name: str) -> str:
        """Load quality rules from skill definition via SkillLoader.

        Falls back to the legacy ``_load_skill_rules`` method if the
        skill loader is unavailable.
        """
        if self._skill_loader:
            try:
                rules = self._skill_loader.get_skill_rules(skill_name)
                if rules:
                    return rules
            except Exception:
                pass
        return self._load_skill_rules(skill_name)

    def _resolve_model(self, tier: str) -> str | None:
        """Resolve a model tier to a specific model via the router. Returns None if no router."""
        if self._model_router and hasattr(self._model_router, "resolve"):
            return self._model_router.resolve(tier)
        return None

    @property
    def _taxonomy_text(self) -> str:
        """Lazily load taxonomy and render as prompt text."""
        if self._skills_dir:
            from agntspace.kb.taxonomy import load_taxonomy, taxonomy_for_prompt
            tree = load_taxonomy(self._skills_dir)
            return taxonomy_for_prompt(tree)
        return "(no taxonomy configured)"

    def _classify(self, entity_type: str, category: str, title: str) -> str:
        """Classify an article into the taxonomy. Returns taxonomy_path."""
        if not self._skills_dir:
            return "general"
        from agntspace.kb.taxonomy import classify_article, flatten_taxonomy, load_taxonomy
        tree = load_taxonomy(self._skills_dir)
        flat_nodes = flatten_taxonomy(tree)
        return classify_article(entity_type=entity_type, category=category, title=title, flat_nodes=flat_nodes)

    # ── Helpers ──

    def _classify_source(self, filename: str) -> tuple[str, str]:
        """Classify source by file type. Returns (type_name, prompt_focus)."""
        ext = Path(filename).suffix.lower()
        for stype, info in _SOURCE_TYPES.items():
            if ext in info["exts"]:
                return stype, info["prompt_focus"]
        return "article", "Extract main points, key facts, and context."

    @staticmethod
    def _strip_web_noise(content: str) -> str:
        """Strip common web clipper noise from article content.

        Obsidian Clipper and similar tools often capture ad banners, nav elements,
        cookie notices, and sidebar content before the actual article body. This
        strips those artifacts so the LLM sees the real content first.
        """
        import re as _re

        lines = content.split("\n")
        cleaned: list[str] = []
        for line in lines:
            stripped = line.strip()
            # Skip empty lines at the very beginning
            if not cleaned and not stripped:
                continue
            # Skip iframe embeds (ads, trackers, interactive widgets)
            if stripped.startswith("<iframe") or stripped.startswith("</iframe"):
                continue
            # Skip bare image-only lines that are just ads/banners (not part of article)
            # Keep images that have alt text describing article content
            if _re.match(r"^!\[.*\]\(https?://static\.", stripped):
                # This is likely a CDN-hosted article image — keep it
                cleaned.append(line)
                continue
            # Skip HTML comment blocks
            if stripped.startswith("<!--") and stripped.endswith("-->"):
                continue
            cleaned.append(line)

        return "\n".join(cleaned)

    def _get_wiki_subdirs(self, slug: str) -> list[str]:
        """Discover all wiki subdirectories dynamically (covers LLM-created dirs like events/)."""
        wiki_dir = self._reader._vault_dir / "agnt-kb" / slug / "wiki"
        if not wiki_dir.is_dir():
            return list(_WIKI_SUBDIRS)
        dirs = []
        for d in wiki_dir.iterdir():
            if d.is_dir() and not d.name.startswith(("_", ".")):
                dirs.append(d.name)
        # Ensure static subdirs are always included
        for sd in _WIKI_SUBDIRS:
            if sd not in dirs:
                dirs.append(sd)
        return dirs

    def _list_wiki_articles(self, base_path: str, pattern: str = "*.md") -> list:
        """List wiki article files, excluding .history/ version archives."""
        try:
            files = self._reader.list_files(base_path, pattern)
            return [
                f for f in files
                if "/.history/" not in str(f).replace("\\", "/")
                and "\\.history\\" not in str(f)
            ]
        except Exception:
            return []

    def _read_schema(self, slug: str) -> str:
        path = f"agnt-kb/{slug}/SCHEMA.md"
        if self._reader.exists(path):
            return self._reader.read(path).content
        return ""

    def _read_index(self, slug: str) -> str:
        path = f"agnt-kb/{slug}/wiki/.index.md"
        if self._reader.exists(path):
            return self._reader.read(path).content
        return ""

    def _append_log(self, slug: str, operation: str, details: str) -> None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        entry = f"\n## [{now}] {operation} | {details}\n"
        log_path = f"agnt-kb/{slug}/log.md"
        if not self._reader.exists(log_path):
            self._writer.write(log_path, (
                "---\ntitle: \"Operation Log\"\ntype: kb_log\nauthor: agent\nagent: librarian\n---\n\n"
                "# Knowledge Base Log\n"
            ))
        self._writer.append(log_path, entry)

    def _read_compile_state(self, slug: str) -> dict:
        path = f"agnt-kb/{slug}/.compile-state.json"
        if self._reader.exists(path):
            try:
                doc = self._reader.read(path)
                state = json.loads(doc.content)
                # Migrate old format: ensure "sources" dict exists
                if "sources" not in state:
                    state["sources"] = {}
                    # Migrate processed_hashes → sources
                    for fname, h in state.get("processed_hashes", {}).items():
                        state["sources"][fname] = {
                            "hash": h,
                            "vault_source": "",
                            "ingested_at": state.get("last_ingest", ""),
                            "source_type": "",
                            "library_path": "",
                            "produced_pages": [],
                            "agent": "librarian",
                            "status": "ingested",
                        }
                return state
            except Exception:
                pass
        return {
            "last_ingest": None,
            "last_compile": None,
            "processed_hashes": {},
            "sources": {},
        }

    def _write_compile_state(self, slug: str, state: dict) -> None:
        self._writer.write(f"agnt-kb/{slug}/.compile-state.json", json.dumps(state, indent=2))

    def _record_source(
        self, state: dict, fname: str, *,
        content_hash: str, vault_source: str = "",
        source_type: str = "", library_path: str = "",
        produced_pages: list[str] | None = None,
        agent: str = "librarian",
    ) -> None:
        """Record full provenance for a processed source."""
        now = datetime.now(UTC).isoformat()
        sources = state.setdefault("sources", {})
        existing = sources.get(fname, {})
        sources[fname] = {
            "hash": content_hash,
            "vault_source": vault_source or existing.get("vault_source", ""),
            "ingested_at": existing.get("ingested_at", now),
            "updated_at": now,
            "source_type": source_type or existing.get("source_type", ""),
            "library_path": library_path or existing.get("library_path", ""),
            "produced_pages": (produced_pages or []) + existing.get("produced_pages", []),
            "agent": agent,
            "status": "ingested",
        }
        # Keep backward compat
        state.setdefault("processed_hashes", {})[fname] = content_hash

    def _check_cross_kb_duplicate(self, current_slug: str, content_hash: str) -> str | None:
        """Check if content_hash exists in any other KB's processed_hashes.
        Returns the other KB slug if found, else None.
        """
        for kb in self.list_kbs():
            other_slug = kb["slug"]
            if other_slug == current_slug:
                continue
            other_state = self._read_compile_state(other_slug)
            if content_hash in other_state.get("processed_hashes", {}).values():
                return other_slug
        return None

    def _find_similar_article(self, kb_slug: str, article_path: str, content: str) -> str | None:
        """Check if a near-duplicate article already exists.

        Checks:
        1. Slug similarity (e.g., 'ai-safety' vs 'artificial-intelligence-safety')
        2. Title match in frontmatter
        Returns the path of the duplicate if found, else None.
        """
        import re as _re
        from difflib import SequenceMatcher

        # Extract the proposed slug and subdir
        parts = article_path.split("/", 1)
        if len(parts) != 2:
            return None
        subdir, new_slug = parts

        # Extract proposed title from content frontmatter
        new_title = ""
        title_match = _re.search(r'^title:\s*"?(.+?)"?\s*$', content, _re.MULTILINE)
        if title_match:
            new_title = title_match.group(1).strip().lower()

        # Scan existing articles in the same subdir
        base = f"agnt-kb/{kb_slug}/wiki/{subdir}"
        try:
            existing_files = list(self._reader.list_files(base, "*.md"))
        except Exception:
            return None

        for ef in existing_files:
            # Skip version history files
            if "/.history/" in str(ef).replace("\\", "/") or "\\.history\\" in str(ef):
                continue
            existing_slug = ef.stem
            # 1. Slug similarity — one is a substring of the other, or SequenceMatcher > 0.75
            slug_ratio = SequenceMatcher(None, new_slug, existing_slug).ratio()
            if slug_ratio > 0.75 or new_slug in existing_slug or existing_slug in new_slug:
                return f"{subdir}/{existing_slug}"

            # 2. Title match
            if new_title:
                try:
                    doc = self._reader.read(f"{base}/{ef.name}")
                    existing_title = doc.metadata.get("title", "").strip().lower()
                    if existing_title and (
                        existing_title == new_title
                        or SequenceMatcher(None, new_title, existing_title).ratio() > 0.80
                    ):
                        return f"{subdir}/{existing_slug}"
                except Exception:
                    continue

        return None

    def _render_template(self, entity_type: str, **kwargs) -> str:
        template = _TEMPLATES.get(entity_type, _TEMPLATES["concept"])
        kwargs.setdefault("agent", "editor")
        return template.format(**kwargs)

    def _update_index_stats(self, slug: str) -> None:
        """Recount articles on disk and update .index.md frontmatter + Statistics section."""
        import re as _re
        base = f"agnt-kb/{slug}"
        idx_path = f"{base}/wiki/.index.md"
        if not self._reader.exists(idx_path):
            return
        src_count = len([f for f in self._reader.list_files(f"{base}/library", "**/*") if f.name != ".gitkeep"])
        ent_count = len(self._list_wiki_articles(f"{base}/wiki/entities"))
        con_count = len(self._list_wiki_articles(f"{base}/wiki/concepts"))
        # Count source pages across both legacy (source_summary/) and current (sources/) dirs
        src_pages = set()
        for sd in ("sources", "source_summary"):
            src_pages.update(f.stem for f in self._list_wiki_articles(f"{base}/wiki/{sd}"))
        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

        doc = self._reader.read(idx_path)
        idx = doc.raw
        idx = self._update_frontmatter(idx, "source_count", str(src_count))
        idx = self._update_frontmatter(idx, "article_count", str(ent_count + con_count))
        # Update Statistics section
        idx = _re.sub(r"- Sources ingested: \d+", f"- Sources ingested: {src_count}", idx)
        idx = _re.sub(r"- Entity pages: \d+", f"- Entity pages: {ent_count}", idx)
        idx = _re.sub(r"- Concept pages: \d+", f"- Concept pages: {con_count}", idx)
        idx = _re.sub(r"- Last updated: .+", f"- Last updated: {date_str}", idx)
        self._writer.write(idx_path, idx)

    # ── KB Management ���─

    def create_kb(
        self,
        topic: str,
        *,
        description: str = "",
        focus_questions: list[str] | None = None,
        source_types: list[str] | None = None,
        notes: str = "",
    ) -> dict:
        slug = topic.lower().replace(" ", "-")
        base = f"agnt-kb/{slug}"
        now = datetime.now().strftime("%Y-%m-%d %H:%M")

        self._writer.write(f"{base}/inbox/.gitkeep", "")
        self._writer.write(f"{base}/library/.gitkeep", "")
        self._writer.write(f"{base}/wiki/.index.md", _INDEX_TEMPLATE.format(topic=topic, date=now))
        self._writer.write(f"{base}/wiki/entities/.gitkeep", "")
        self._writer.write(f"{base}/wiki/concepts/.gitkeep", "")
        self._writer.write(f"{base}/wiki/sources/.gitkeep", "")
        self._writer.write(f"{base}/wiki/synthesis/.gitkeep", "")
        self._writer.write(f"{base}/wiki/decisions/.gitkeep", "")
        self._writer.write(f"{base}/wiki/decisions/evolution/.gitkeep", "")
        self._writer.write(f"{base}/wiki/projects/.gitkeep", "")
        self._writer.write(f"{base}/output/.gitkeep", "")

        # Build enriched SCHEMA.md from wizard fields
        schema = _SCHEMA_TEMPLATE.format(topic=topic)
        if description:
            schema = schema.replace(
                "<!-- What is this knowledge base about? What questions should it answer? -->",
                description,
            )
        if focus_questions:
            fq_lines = "\n".join(f"- {q}" for q in focus_questions)
            schema = schema.replace(
                "## Conventions",
                f"## Focus Questions\n{fq_lines}\n\n## Conventions",
            )
        if source_types:
            st_lines = "\n".join(f"- **{t}**" for t in source_types)
            schema = schema.replace(
                "## Notes\n<!-- Domain-specific instructions for the agent -->",
                f"## Expected Source Types\n{st_lines}\n\n## Notes\n{notes if notes else '<!-- Domain-specific instructions for the agent -->'}",
            )
        elif notes:
            schema = schema.replace(
                "<!-- Domain-specific instructions for the agent -->",
                notes,
            )

        self._writer.write(f"{base}/SCHEMA.md", schema)
        self._write_compile_state(slug, {"last_ingest": None, "last_compile": None, "processed_hashes": {}})
        self._append_log(slug, "create", f"Knowledge base created: {topic}")

        return {"topic": topic, "slug": slug, "path": base}

    def delete_kb(self, slug: str) -> dict:
        """Delete a knowledge base and clean up all references."""
        import shutil

        vault_dir = self._reader._vault_dir
        kb_path = vault_dir / "agnt-kb" / slug
        if not kb_path.is_dir():
            raise FileNotFoundError(f"KB not found: {slug}")

        # Count articles and sources before deleting
        article_count = 0
        for sd in _WIKI_SUBDIRS:
            article_count += len(self._list_wiki_articles(f"agnt-kb/{slug}/wiki/{sd}"))
        source_count = len([
            f for f in self._reader.list_files(f"agnt-kb/{slug}/library", "**/*")
            if f.name != ".gitkeep"
        ])

        # Delete the entire KB folder
        shutil.rmtree(kb_path)

        # Clean up bibliography entries
        bib_cleaned = 0
        bib_path = vault_dir / "agnt-memory" / "bibliography.json"
        if bib_path.is_file():
            try:
                entries = json.loads(bib_path.read_text(encoding="utf-8"))
                before = len(entries)
                entries = [e for e in entries if e.get("kb_slug") != slug]
                bib_cleaned = before - len(entries)
                if bib_cleaned > 0:
                    bib_path.write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")
            except Exception:
                log.warning("Failed to clean bibliography for deleted KB %s", slug)

        # Clean up project references
        projects_updated = self._remove_kb_from_projects(slug, vault_dir)

        return {
            "slug": slug,
            "deleted_articles": article_count,
            "deleted_sources": source_count,
            "bibliography_cleaned": bib_cleaned,
            "projects_updated": projects_updated,
        }

    def rename_kb(self, slug: str, new_title: str) -> dict:
        """Rename a knowledge base (folder + all references)."""
        import re as _re
        import shutil

        vault_dir = self._reader._vault_dir
        old_path = vault_dir / "agnt-kb" / slug
        if not old_path.is_dir():
            raise FileNotFoundError(f"KB not found: {slug}")

        new_slug = _re.sub(r"[^a-z0-9-]", "", new_title.lower().replace(" ", "-")).strip("-")
        if not new_slug:
            raise ValueError("Invalid title — produces empty slug")

        new_path = vault_dir / "agnt-kb" / new_slug
        if new_path.exists():
            raise ValueError(f"KB already exists: {new_slug}")

        # Get old title from index
        idx_rel = f"agnt-kb/{slug}/wiki/.index.md"
        old_title = slug.replace("-", " ").title()
        if self._reader.exists(idx_rel):
            doc = self._reader.read(idx_rel)
            old_title = doc.metadata.get("title", old_title)

        # Rename the folder
        shutil.move(str(old_path), str(new_path))

        # Update _index.md title inside the KB
        new_idx_path = new_path / "wiki" / ".index.md"
        if new_idx_path.is_file():
            content = new_idx_path.read_text(encoding="utf-8")
            # Update frontmatter title
            content = _re.sub(
                r'^title:\s*".*?"',
                f'title: "{new_title} — Index"',
                content, count=1, flags=_re.MULTILINE,
            )
            # Update heading
            content = _re.sub(
                r"^# .+ — Knowledge Base",
                f"# {new_title} — Knowledge Base",
                content, count=1, flags=_re.MULTILINE,
            )
            new_idx_path.write_text(content, encoding="utf-8")

        # Update bibliography entries
        bib_updated = 0
        bib_path = vault_dir / "agnt-memory" / "bibliography.json"
        if bib_path.is_file():
            try:
                entries = json.loads(bib_path.read_text(encoding="utf-8"))
                for e in entries:
                    if e.get("kb_slug") == slug:
                        e["kb_slug"] = new_slug
                        bib_updated += 1
                if bib_updated > 0:
                    bib_path.write_text(json.dumps(entries, indent=2, ensure_ascii=False), encoding="utf-8")
            except Exception:
                log.warning("Failed to update bibliography for renamed KB %s -> %s", slug, new_slug)

        # Update project references
        projects_updated = self._rename_kb_in_projects(slug, new_slug, vault_dir)

        return {
            "old_slug": slug,
            "new_slug": new_slug,
            "old_title": old_title,
            "new_title": new_title,
            "bibliography_updated": bib_updated,
            "projects_updated": projects_updated,
        }

    def _remove_kb_from_projects(self, kb_slug: str, vault_dir: Path) -> list[str]:
        """Remove a KB slug from linked_kbs in all PROJECT.md files."""
        import frontmatter as fm

        updated = []
        projects_dir = vault_dir / "projects"
        if not projects_dir.is_dir():
            return updated
        for child in projects_dir.iterdir():
            if not child.is_dir():
                continue
            project_file = child / "PROJECT.md"
            if not project_file.is_file():
                continue
            try:
                post = fm.load(str(project_file))
                linked = post.metadata.get("linked_kbs") or []
                if kb_slug in linked:
                    linked = [k for k in linked if k != kb_slug]
                    post.metadata["linked_kbs"] = linked
                    project_file.write_text(fm.dumps(post), encoding="utf-8")
                    updated.append(child.name)
            except Exception:
                log.warning("Failed to update project %s for KB cleanup", child.name)
        return updated

    def _rename_kb_in_projects(self, old_slug: str, new_slug: str, vault_dir: Path) -> list[str]:
        """Replace old KB slug with new in linked_kbs across all PROJECT.md files."""
        import frontmatter as fm

        updated = []
        projects_dir = vault_dir / "projects"
        if not projects_dir.is_dir():
            return updated
        for child in projects_dir.iterdir():
            if not child.is_dir():
                continue
            project_file = child / "PROJECT.md"
            if not project_file.is_file():
                continue
            try:
                post = fm.load(str(project_file))
                linked = post.metadata.get("linked_kbs") or []
                if old_slug in linked:
                    linked = [new_slug if k == old_slug else k for k in linked]
                    post.metadata["linked_kbs"] = linked
                    project_file.write_text(fm.dumps(post), encoding="utf-8")
                    updated.append(child.name)
            except Exception:
                log.warning("Failed to update project %s for KB rename", child.name)
        return updated

    def list_kbs(self) -> list[dict]:
        kbs = []
        seen_slugs: set[str] = set()
        try:
            files = self._reader.list_files("agnt-kb", "**/wiki/.index.md")
        except Exception:
            return []
        for f in files:
            # Skip archived copies
            f_str = str(f).replace("\\", "/")
            if "/.archives/" in f_str:
                continue
            try:
                parts = f_str.split("/")
                kb_idx = next(i for i, p in enumerate(parts) if p == "agnt-kb")
                slug = parts[kb_idx + 1]
                if slug in seen_slugs:
                    continue
                seen_slugs.add(slug)
                doc = self._reader.read(f"agnt-kb/{slug}/wiki/.index.md")
                lib = self._reader.list_files(f"agnt-kb/{slug}/library", "**/*")
                wiki = self._reader.list_files(f"agnt-kb/{slug}/wiki", "**/*.md")
                kbs.append({
                    "slug": slug,
                    "title": doc.metadata.get("title", slug),
                    "sources": len([r for r in lib if r.name != ".gitkeep"]),
                    "articles": len([w for w in wiki if not w.name.startswith(("_", "."))
                                     and "/.history/" not in str(w).replace("\\", "/")
                                     and "/.archives/" not in str(w).replace("\\", "/")]),
                    "updated": doc.metadata.get("updated", ""),
                })
            except Exception:
                continue
        return kbs

    def get_kb_status(self, slug: str) -> dict:
        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        doc = self._reader.read(f"{base}/wiki/.index.md")
        raw = [r.name for r in self._reader.list_files(f"{base}/inbox", "**/*") if r.name != ".gitkeep"]
        lib = [s.name for s in self._reader.list_files(f"{base}/library", "**/*") if s.name != ".gitkeep"]
        entities = [w.name for w in self._reader.list_files(f"{base}/wiki/entities", "*.md")]
        concepts = [w.name for w in self._reader.list_files(f"{base}/wiki/concepts", "*.md")]
        sources = [w.name for w in self._reader.list_files(f"{base}/wiki/sources", "*.md")]
        source_summaries = [w.name for w in self._reader.list_files(f"{base}/wiki/source_summary", "*.md")]
        sources = list(set(sources + source_summaries))  # merge legacy + current
        state = self._read_compile_state(slug)

        return {
            "slug": slug, "title": doc.metadata.get("title", slug),
            "raw_pending": raw, "library": lib,
            "entity_pages": entities, "concept_pages": concepts, "source_pages": sources,
            "raw_count": len(raw), "library_count": len(lib),
            "entity_count": len(entities), "concept_count": len(concepts), "source_count": len(sources),
            "last_ingest": state.get("last_ingest"), "last_compile": state.get("last_compile"),
            "has_schema": self._reader.exists(f"{base}/SCHEMA.md"),
        }

    # ── Delete / Reset ──

    def delete_article(self, slug: str, article_slug: str) -> dict:
        """Delete a single wiki article from a KB. Returns info about what was deleted."""
        base = f"agnt-kb/{slug}/wiki"
        deleted = []
        for subdir in _WIKI_SUBDIRS:
            path = f"{base}/{subdir}/{article_slug}.md"
            full = self._reader._vault_dir / path
            log.debug("delete_article: checking %s (exists=%s)", full, full.exists())
            if full.exists():
                full.unlink()
                deleted.append(f"{subdir}/{article_slug}")
                log.info("Deleted wiki article: %s", full)
        if not deleted:
            log.warning("delete_article: no files found for %s in KB %s", article_slug, slug)

        # Also remove from .index.md and update stats
        if deleted:
            idx_path = f"agnt-kb/{slug}/wiki/.index.md"
            if self._reader.exists(idx_path):
                doc = self._reader.read(idx_path)
                idx = doc.raw
                for d in deleted:
                    idx = idx.replace(f"- [[{d}]]\n", "")
                    idx = idx.replace(f"- [[{article_slug}]]\n", "")
                self._writer.write(idx_path, idx)
            self._update_index_stats(slug)
            self._append_log(slug, "delete", f"Deleted article: {article_slug}")

        return {"slug": slug, "article": article_slug, "deleted": deleted}

    # ------------------------------------------------------------------
    # Article CRUD helpers
    # ------------------------------------------------------------------

    def _find_article_by_slug(self, slug: str) -> tuple[str, str, Path, dict, str] | None:
        """Find a wiki article by slug across all KBs.

        Returns (kb_slug, subdir, filepath, metadata, content) or None.
        Searches frontmatter ``slug`` field first, then filename stem match.
        """
        import re as _re

        vault_dir = self._reader._vault_dir
        try:
            files = self._reader.list_files("agnt-kb", "**/wiki/**/*.md")
        except Exception:
            return None

        for f in files:
            f_str = str(f).replace("\\", "/")
            if "/.archives/" in f_str or "/.history/" in f_str:
                continue
            if f.name.startswith(("_", ".")):
                continue

            # Quick filename stem check (slug-style)
            stem_slug = _re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-")
            match_by_name = stem_slug == slug

            try:
                rel = str(f.relative_to(vault_dir)).replace("\\", "/")
                doc = self._reader.read(rel)
                meta = doc.metadata
                content = doc.content
            except Exception:
                continue

            fm_slug = meta.get("slug", "")
            if fm_slug == slug or match_by_name:
                # Extract kb_slug and subdir from path
                parts = rel.replace("\\", "/").split("/")
                try:
                    kb_idx = parts.index("agnt-kb")
                    kb_slug = parts[kb_idx + 1]
                except (ValueError, IndexError):
                    kb_slug = ""
                # subdir is the directory between wiki/ and the file
                try:
                    wiki_idx = parts.index("wiki")
                    if wiki_idx + 2 < len(parts):
                        subdir = parts[wiki_idx + 1]
                    else:
                        subdir = ""
                except (ValueError, IndexError):
                    subdir = ""
                return (kb_slug, subdir, f, meta, content)

        return None

    def create_article(
        self,
        kb_slug: str,
        title: str,
        content: str,
        entity_type: str = "concept",
        subdir: str | None = None,
    ) -> dict:
        """Create a new wiki article in a knowledge base.

        Returns {"slug", "title", "kb", "path"}.
        Raises ValueError on duplicate slug.
        """
        import re as _re
        from datetime import date
        from agntspace.vault.writer import title_to_filename

        # Determine subdir
        if not subdir:
            if entity_type in ("person", "organization"):
                subdir = "entities"
            else:
                subdir = "concepts"

        # Generate slug
        slug = _re.sub(r"[^a-z0-9-]", "", title.lower().replace(" ", "-")).strip("-")
        if not slug:
            slug = "untitled"

        # Check for duplicate slug across this KB's wiki
        vault_dir = self._reader._vault_dir
        wiki_base = vault_dir / "agnt-kb" / kb_slug / "wiki"
        if wiki_base.exists():
            for sd in _WIKI_SUBDIRS:
                sd_path = wiki_base / sd
                if not sd_path.exists():
                    continue
                for f in sd_path.glob("*.md"):
                    if f.name.startswith(("_", ".")):
                        continue
                    stem_slug = _re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-")
                    if stem_slug == slug:
                        raise ValueError(f"Article with slug '{slug}' already exists in KB '{kb_slug}'")
                    # Also check frontmatter slug
                    try:
                        rel = str(f.relative_to(vault_dir)).replace("\\", "/")
                        doc = self._reader.read(rel)
                        if doc.metadata.get("slug") == slug:
                            raise ValueError(f"Article with slug '{slug}' already exists in KB '{kb_slug}'")
                    except ValueError:
                        raise
                    except Exception:
                        pass
            # Re-check: the inner ValueError may have been caught by the bare except
            # Actually the except clause above only catches FileNotFoundError and ValueError
            # Let me restructure — check root wiki dir too
            for f in wiki_base.glob("*.md"):
                if f.name.startswith(("_", ".")):
                    continue
                stem_slug = _re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-")
                if stem_slug == slug:
                    raise ValueError(f"Article with slug '{slug}' already exists in KB '{kb_slug}'")

        filename = title_to_filename(title)
        relative_path = f"agnt-kb/{kb_slug}/wiki/{subdir}/{filename}.md"

        metadata = {
            "title": title,
            "slug": slug,
            "entity_type": entity_type,
            "author": "user",
            "date": date.today().isoformat(),
        }

        self._writer.write(relative_path, content, metadata, versioned=True)
        self._append_log(kb_slug, "create", f"Created article: {title} ({slug})")

        return {"slug": slug, "title": title, "kb": kb_slug, "path": relative_path}

    def update_article(
        self,
        slug: str,
        content: str | None = None,
        metadata_updates: dict | None = None,
    ) -> dict:
        """Update an existing wiki article (content and/or metadata).

        Finds the article by slug across all KBs.
        Returns {"slug", "title", "kb", "path", "updated_fields"}.
        Raises FileNotFoundError if not found.
        """
        from datetime import date

        found = self._find_article_by_slug(slug)
        if not found:
            raise FileNotFoundError(f"Article not found: {slug}")

        kb_slug, subdir, filepath, meta, existing_content = found
        vault_dir = self._reader._vault_dir
        rel_path = str(filepath.relative_to(vault_dir)).replace("\\", "/")

        updated_fields: list[str] = []

        # Update content
        if content is not None:
            existing_content = content
            updated_fields.append("content")

        # Merge metadata updates
        if metadata_updates:
            for k, v in metadata_updates.items():
                meta[k] = v
                updated_fields.append(k)

        # Always set date_updated
        meta["date_updated"] = date.today().isoformat()

        self._writer.write(rel_path, existing_content, meta, versioned=True)
        self._append_log(kb_slug, "update", f"Updated article: {meta.get('title', slug)} ({slug})")

        return {
            "slug": slug,
            "title": meta.get("title", slug),
            "kb": kb_slug,
            "path": rel_path,
            "updated_fields": updated_fields,
        }

    def rename_article(self, slug: str, new_title: str) -> dict:
        """Rename a wiki article: new file, backlink rewriting, compile state update.

        Returns {"old_slug", "new_slug", "old_title", "new_title", "kb", "backlinks_updated"}.
        Raises FileNotFoundError if not found, ValueError on slug collision.
        """
        import re as _re
        from datetime import date
        from agntspace.vault.writer import title_to_filename

        found = self._find_article_by_slug(slug)
        if not found:
            raise FileNotFoundError(f"Article not found: {slug}")

        kb_slug, subdir, filepath, meta, content = found
        vault_dir = self._reader._vault_dir
        old_rel = str(filepath.relative_to(vault_dir)).replace("\\", "/")
        old_title = meta.get("title", filepath.stem)

        # Generate new slug
        new_slug = _re.sub(r"[^a-z0-9-]", "", new_title.lower().replace(" ", "-")).strip("-")
        if not new_slug:
            new_slug = "untitled"

        # Check for collision (skip if renaming to same slug)
        if new_slug != slug:
            collision = self._find_article_by_slug(new_slug)
            if collision:
                raise ValueError(f"Article with slug '{new_slug}' already exists")

        # Build new path
        new_filename = title_to_filename(new_title)
        if subdir:
            new_rel = f"agnt-kb/{kb_slug}/wiki/{subdir}/{new_filename}.md"
        else:
            new_rel = f"agnt-kb/{kb_slug}/wiki/{new_filename}.md"

        # Update metadata
        meta["title"] = new_title
        meta["slug"] = new_slug
        meta["date_updated"] = date.today().isoformat()

        # Write new file
        self._writer.write(new_rel, content, meta, versioned=True)

        # Delete old file
        if filepath.exists() and old_rel != new_rel:
            filepath.unlink()

        # --- Backlink rewriting across ALL KBs ---
        backlinks_updated = 0
        try:
            all_files = self._reader.list_files("agnt-kb", "**/wiki/**/*.md")
        except Exception:
            all_files = []

        for f in all_files:
            f_str = str(f).replace("\\", "/")
            if "/.archives/" in f_str or "/.history/" in f_str:
                continue
            if f.name.startswith(("_", ".")):
                continue
            # Skip the article we just wrote
            f_rel = str(f.relative_to(vault_dir)).replace("\\", "/")
            if f_rel == new_rel:
                continue

            try:
                doc = self._reader.read(f_rel)
                raw = doc.raw
            except Exception:
                continue

            updated_raw = raw
            # Replace [[Old Title]] with [[New Title]]
            if old_title and old_title != new_title:
                updated_raw = updated_raw.replace(f"[[{old_title}]]", f"[[{new_title}]]")
            # Replace [[old-slug]] with [[new-slug]]
            if slug != new_slug:
                updated_raw = updated_raw.replace(f"[[{slug}]]", f"[[{new_slug}]]")

            if updated_raw != raw:
                # Write the updated file directly (mechanical rewrite, no versioning)
                full_path = vault_dir / f_rel
                full_path.write_text(updated_raw, encoding="utf-8")
                backlinks_updated += 1

        # --- Update compile state ---
        try:
            state = self._read_compile_state(kb_slug)
            sources = state.get("sources", {})
            changed = False
            for fname, info in sources.items():
                pages = info.get("produced_pages", [])
                new_pages = []
                for p in pages:
                    if p == old_rel:
                        new_pages.append(new_rel)
                        changed = True
                    else:
                        new_pages.append(p)
                info["produced_pages"] = new_pages
            if changed:
                self._write_compile_state(kb_slug, state)
        except Exception:
            log.warning("Failed to update compile state during rename", exc_info=True)

        # --- Update _index.md ---
        idx_path = f"agnt-kb/{kb_slug}/wiki/_index.md"
        try:
            if self._reader.exists(idx_path):
                doc = self._reader.read(idx_path)
                idx_raw = doc.raw
                updated_idx = idx_raw.replace(f"[[{old_title}]]", f"[[{new_title}]]")
                if slug != new_slug:
                    updated_idx = updated_idx.replace(f"[[{slug}]]", f"[[{new_slug}]]")
                if updated_idx != idx_raw:
                    self._writer.write(idx_path, updated_idx, versioned=False)
        except Exception:
            log.warning("Failed to update _index.md during rename", exc_info=True)

        self._append_log(
            kb_slug, "rename",
            f"Renamed article: {old_title} → {new_title} ({slug} → {new_slug}), "
            f"{backlinks_updated} backlinks updated",
        )

        return {
            "old_slug": slug,
            "new_slug": new_slug,
            "old_title": old_title,
            "new_title": new_title,
            "kb": kb_slug,
            "backlinks_updated": backlinks_updated,
        }

    def find_backlinks(self, slug: str) -> list[dict]:
        """Find all articles that link to the given article via [[wikilinks]].

        Returns list of {"slug", "title", "kb"} dicts.
        """
        import re as _re

        found = self._find_article_by_slug(slug)
        if not found:
            return []

        _kb_slug, _subdir, _filepath, meta, _content = found
        title = meta.get("title", "")
        vault_dir = self._reader._vault_dir
        backlinks: list[dict] = []

        try:
            all_files = self._reader.list_files("agnt-kb", "**/wiki/**/*.md")
        except Exception:
            return []

        for f in all_files:
            f_str = str(f).replace("\\", "/")
            if "/.archives/" in f_str or "/.history/" in f_str:
                continue
            if f.name.startswith(("_", ".")):
                continue

            try:
                rel = str(f.relative_to(vault_dir)).replace("\\", "/")
                doc = self._reader.read(rel)
                raw_content = doc.content
            except Exception:
                continue

            # Check for [[Title]] or [[slug]] references
            has_link = False
            if title and f"[[{title}]]" in raw_content:
                has_link = True
            if f"[[{slug}]]" in raw_content:
                has_link = True

            if has_link:
                art_slug = doc.metadata.get("slug") or _re.sub(
                    r"[^a-z0-9]+", "-", f.stem.lower()
                ).strip("-")
                parts = rel.split("/")
                try:
                    kb_idx = parts.index("agnt-kb")
                    art_kb = parts[kb_idx + 1]
                except (ValueError, IndexError):
                    art_kb = ""
                backlinks.append({
                    "slug": art_slug,
                    "title": doc.metadata.get("title", f.stem),
                    "kb": art_kb,
                })

        return backlinks

    def reset_wiki(self, slug: str) -> dict:
        """Delete ALL wiki articles for a KB and reset compile state. Keeps library/inbox intact."""

        base_rel = f"agnt-kb/{slug}/wiki"
        vault_dir = self._reader._vault_dir
        wiki_dir = vault_dir / "agnt-kb" / slug / "wiki"

        if not wiki_dir.exists():
            return {"slug": slug, "deleted": 0, "message": "Wiki directory not found"}

        # Count articles before deletion
        deleted_count = 0
        for subdir in _WIKI_SUBDIRS:
            d = wiki_dir / subdir
            if d.exists():
                for f in d.glob("*.md"):
                    f.unlink()
                    deleted_count += 1

        # Reset .index.md to clean state (matching _INDEX_TEMPLATE structure)
        idx_path = wiki_dir / ".index.md"
        if idx_path.exists():
            title = slug.replace("-", " ").title()
            date_str = datetime.now().strftime('%Y-%m-%d')
            self._writer.write(f"{base_rel}/.index.md", _INDEX_TEMPLATE.format(
                topic=title, date=date_str,
            ).strip())

        # Reset .concepts.md
        concepts_path = wiki_dir / ".concepts.md"
        if concepts_path.exists():
            concepts_path.unlink()

        # Reset compile state so next compile starts fresh
        self._write_compile_state(slug, {"last_ingest": None, "last_compile": None, "processed_hashes": {}})

        self._append_log(slug, "reset", f"Wiki reset — deleted {deleted_count} articles")
        return {"slug": slug, "deleted": deleted_count}

    def reset_all_wikis(self) -> dict:
        """Reset wikis across ALL knowledge bases."""
        kbs = self.list_kbs()
        total = 0
        results = []
        for kb in kbs:
            r = self.reset_wiki(kb["slug"])
            total += r["deleted"]
            results.append(r)
        return {"kbs_reset": len(results), "total_deleted": total, "details": results}

    # ── Ingest ──

    async def ingest(self, slug: str) -> dict:
        """Process raw/ files: classify, extract, create source summary + wiki updates, move to library/."""
        # Per-KB lock prevents concurrent ingest (watcher + API racing)
        lock = self._ingest_locks.setdefault(slug, asyncio.Lock())
        async with lock:
            return await self._do_ingest(slug)

    async def _do_ingest(self, slug: str) -> dict:
        """Internal ingest implementation (holds per-KB lock)."""
        from agntspace.llm.base import Message

        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Pipeline mode: suppress versioning for automated writes
        self._writer._pipeline_mode = True

        index_doc = self._reader.read(f"{base}/wiki/.index.md")
        index_content = index_doc.raw
        schema = self._read_schema(slug)
        state = self._read_compile_state(slug)

        all_inbox = [f for f in self._reader.list_files(f"{base}/inbox", "**/*") if f.name != ".gitkeep"]
        raw_files = [f for f in all_inbox if not f.name.endswith(".source")]
        if not raw_files:
            return {"slug": slug, "ingested": [], "count": 0, "message": "raw/ is empty."}

        # Read sidecar .source files to get original vault paths
        vault_sources: dict[str, str] = {}
        for f in all_inbox:
            if f.name.endswith(".source"):
                try:
                    original_name = f.name[:-7]  # strip ".source"
                    vault_sources[original_name] = f.read_text(encoding="utf-8").strip()
                except Exception:
                    pass

        now = datetime.now(UTC)
        local_now = datetime.now()
        date_folder = now.strftime("%Y-%m")
        date_str = local_now.strftime("%Y-%m-%d %H:%M")
        ingested = []
        wiki_updates = []

        # Discover known projects for auto-routing
        known_projects: dict[str, str] = {}  # slug → title
        projects_dir = self._reader._vault_dir / base / "wiki" / "projects"
        if projects_dir.is_dir():
            for d in projects_dir.iterdir():
                if d.is_dir() and d.name != ".gitkeep":
                    known_projects[d.name] = d.name.replace("-", " ").title()
        # Also check vault projects (from ProjectService)
        vault_projects_dir = self._reader._vault_dir / "projects"
        if vault_projects_dir.is_dir():
            for d in vault_projects_dir.iterdir():
                if d.is_dir() and d.name not in known_projects:
                    known_projects[d.name] = d.name.replace("-", " ").title()

        # Skip patterns for files that don't contain useful knowledge
        _SKIP_PATTERNS = {
            "time report", "time-report", "timereport",
            "day template", "template",
            "untitled",
        }

        for raw_file in raw_files:
            fname = raw_file.name
            fname_lower = fname.lower()

            # Skip mundane files (time reports, templates, etc.)
            if any(p in fname_lower for p in _SKIP_PATTERNS):
                log.info("KB %s: skipping mundane file %s", slug, fname)
                continue

            content_hash = ""
            source_meta: dict = {}

            # Classify first — determines how to read the file
            source_type, type_focus = self._classify_source(fname)
            is_image = source_type == "image"
            source_text = ""
            raw_source_url = ""

            if is_image:
                # Use OCR + vision LLM to understand the image
                try:
                    image_file = self._reader._vault_dir / base / "inbox" / fname

                    # OCR pass — extract text if Tesseract is available
                    from agntspace.llm.ocr import extract_text as ocr_extract
                    ocr_text = ocr_extract(image_file)

                    # Vision LLM pass — describe the image (with OCR context)
                    image_description = await self._describe_image(image_file, ocr_text=ocr_text)

                    # Combine: OCR text first (verbatim), then vision description
                    parts = [f"[Image: {fname}]"]
                    if ocr_text:
                        parts.append(f"## OCR Text\n{ocr_text}")
                    parts.append(f"## Visual Description\n{image_description}")
                    source_text = "\n\n".join(parts)

                    content_hash = hashlib.md5(source_text.encode()).hexdigest()[:12]
                except Exception:
                    source_text = f"[Image file: {fname} — could not analyze]"
                    content_hash = hashlib.md5(fname.encode()).hexdigest()[:12]
            else:
                # Try multi-format parser first (PDF, JSONL, JSON, VTT, SRT)
                parsed = None
                ext = Path(fname).suffix.lower()
                if ext in (".pdf", ".jsonl", ".json", ".vtt", ".srt"):
                    try:
                        from agntspace.kb.parsers import parse_file
                        parsed = parse_file(raw_file)
                        if parsed:
                            log.info("KB %s: parsed %s via multi-format parser (%d chars)", slug, fname, len(parsed))
                    except Exception:
                        log.debug("Multi-format parser failed for %s", fname, exc_info=True)

                try:
                    if parsed:
                        source_text = parsed
                        source_meta: dict = {}
                    else:
                        doc = self._reader.read(f"{base}/inbox/{fname}")
                        source_meta = doc.metadata or {}
                        # Strip web clipper noise: ad banners, nav elements, iframes
                        source_text = self._strip_web_noise(doc.content)
                        # Obsidian Clipper uses "source:" field; our scraper uses "source_url:"
                        raw_source_url = (
                            source_meta.get("source_url", "")
                            or source_meta.get("source", "")
                            or source_meta.get("url", "")
                        )
                        # Only keep if it looks like a URL
                        if raw_source_url and not raw_source_url.startswith(("http://", "https://")):
                            raw_source_url = ""
                    content_hash = hashlib.md5(source_text.encode()).hexdigest()[:12]
                except Exception:
                    source_text = f"[Binary or unreadable file: {fname}]"
                    source_meta = {}
                    content_hash = hashlib.md5(fname.encode()).hexdigest()[:12]

            # Skip if already processed — check by filename AND by content hash
            if state["processed_hashes"].get(fname) == content_hash:
                self._move_to_library(raw_file, base, fname, date_folder)
                continue

            # Check for duplicate content under a different filename (same KB)
            all_hashes = state["processed_hashes"]
            duplicate_of = next(
                (existing_name for existing_name, h in all_hashes.items() if h == content_hash and existing_name != fname),
                None,
            )
            if duplicate_of:
                log.info("KB %s: skipping %s — duplicate of %s (same content hash)", slug, fname, duplicate_of)
                self._append_log(slug, "skip", f"Duplicate: {fname} = {duplicate_of}")
                state["processed_hashes"][fname] = content_hash
                self._move_to_library(raw_file, base, fname, date_folder)
                self._write_compile_state(slug, state)
                continue

            # Cross-KB dedup: check if this content hash exists in any other KB
            cross_dup = self._check_cross_kb_duplicate(slug, content_hash)
            if cross_dup:
                log.info("KB %s: skipping %s — already ingested in KB %s", slug, fname, cross_dup)
                self._append_log(slug, "skip", f"Cross-KB duplicate: {fname} already in {cross_dup}")
                state["processed_hashes"][fname] = content_hash
                self._move_to_library(raw_file, base, fname, date_folder)
                self._write_compile_state(slug, state)
                continue

            # Skip empty files — LLM will reject empty content
            if not source_text.strip():
                log.info("KB %s: skipping %s — empty file", slug, fname)
                state["processed_hashes"][fname] = content_hash
                self._move_to_library(raw_file, base, fname, date_folder)
                self._write_compile_state(slug, state)
                continue

            # Check if this is an updated version of an existing file (same stem, different hash)
            existing_entry = next(
                (existing_name for existing_name in all_hashes if Path(existing_name).stem == Path(fname).stem and existing_name != fname),
                None,
            )
            if existing_entry:
                log.info("KB %s: %s appears to be an update of %s — replacing", slug, fname, existing_entry)
                # Clean up old source summary if the slug changed
                old_source_slug = Path(existing_entry).stem.lower().replace(" ", "-")
                new_source_slug = Path(fname).stem.lower().replace(" ", "-")
                if old_source_slug != new_source_slug:
                    old_page = self._reader._vault_dir / base / "wiki" / "sources" / f"{old_source_slug}.md"
                    if old_page.exists():
                        old_page.unlink()
                        log.info("KB %s: cleaned up orphaned source page %s", slug, old_source_slug)
                # Also clean up pages the old source produced
                old_provenance = state.get("sources", {}).get(existing_entry, {})
                for old_page_path in old_provenance.get("produced_pages", []):
                    if old_page_path.startswith("sources/"):
                        continue  # handled above
                    full = self._reader._vault_dir / base / "wiki" / f"{old_page_path}.md"
                    if full.exists():
                        full.unlink()
                        log.info("KB %s: cleaned up old produced page %s", slug, old_page_path)
                # Remove old hash and provenance
                del all_hashes[existing_entry]
                state.get("sources", {}).pop(existing_entry, None)

            # type_focus already set from classification above

            # For large documents: chunked multi-pass extraction
            # Extracts knowledge from ALL sections via parallel LLM calls,
            # then merges into a single consolidated summary. No content dropped.
            from agntspace.kb.chunked_extract import needs_chunking, chunked_extract
            if not is_image and needs_chunking(source_text):
                try:
                    source_text = await chunked_extract(
                        source_text, fname, source_type, self._llm,
                        model=self._resolve_model("fast"),
                    )
                    log.info("KB %s: chunked extraction complete for %s (%d chars)",
                             slug, fname, len(source_text))
                except Exception:
                    log.exception("KB %s: chunked extraction failed for %s — using first 12K chars",
                                  slug, fname)
                    source_text = source_text[:12000]

            # LLM: type-specific extraction — wrapped in try/except so one failure
            # doesn't kill the entire batch
            try:
                # Build classify prompt: skill-loaded or hardcoded fallback
                _bib_block = (
                    "\n\nAlso extract bibliographic metadata into this block:\n"
                    "```bibliography\n"
                    "- title: (exact title of the work — not the filename)\n"
                    "- authors: (comma-separated list of authors, or \"unknown\")\n"
                    "- date: (publication date YYYY-MM-DD or YYYY, or \"unknown\")\n"
                    "- publisher: (journal, conference, website, publisher name, or \"unknown\")\n"
                    "- doi: (DOI if visible, or \"\")\n"
                    "```"
                )

                # Build frontmatter context block — gives the LLM authoritative
                # metadata from the source (title, description, author, URL) so it
                # doesn't have to guess the topic from potentially noisy body text.
                _fm_parts: list[str] = []
                if not is_image and source_meta:
                    fm_title = source_meta.get("title", "")
                    fm_desc = source_meta.get("description", "")
                    fm_author = source_meta.get("author", "")
                    fm_published = source_meta.get("published", source_meta.get("date", ""))
                    fm_tags = source_meta.get("tags", [])
                    if fm_title:
                        _fm_parts.append(f"Title: {fm_title}")
                    if fm_desc:
                        _fm_parts.append(f"Description: {fm_desc}")
                    if fm_author:
                        if isinstance(fm_author, list):
                            fm_author = ", ".join(str(a).strip("[]") for a in fm_author)
                        _fm_parts.append(f"Author: {fm_author}")
                    if fm_published:
                        _fm_parts.append(f"Published: {fm_published}")
                    if raw_source_url:
                        _fm_parts.append(f"Source URL: {raw_source_url}")
                    if fm_tags and isinstance(fm_tags, list):
                        _fm_parts.append(f"Tags: {', '.join(str(t) for t in fm_tags)}")
                _fm_block = ""
                if _fm_parts:
                    _fm_block = (
                        "\n\nSOURCE METADATA (from file frontmatter — this is authoritative, "
                        "use it to determine the article's true topic even if body text "
                        "starts with ads or unrelated content):\n"
                        + "\n".join(_fm_parts) + "\n"
                    )

                dynamic_ctx = (
                    f"\nSource file: {fname}\nSource type: {source_type}\n"
                    f"Type-specific focus: {type_focus}\n"
                    f"{_fm_block}\n"
                    f"KB Schema:\n{schema[:1000]}\n\n"
                    f"Existing wiki index:\n{index_doc.content[:2000]}\n\n"
                    f"KNOWLEDGE TAXONOMY:\n{self._taxonomy_text}"
                    f"{_bib_block}"
                )
                skill_prompt = self._get_skill_prompt("kb-ingest")
                if skill_prompt:
                    classify_system = skill_prompt + "\n\n" + dynamic_ctx
                else:
                    classify_system = _CLASSIFY_PROMPT_FALLBACK.format(
                        filename=fname, source_type=source_type, type_focus=type_focus,
                        schema=schema[:1000], index=index_doc.content[:2000],
                        taxonomy=self._taxonomy_text,
                    )
                classify_system += "\n\n" + self._get_skill_rules("kb-ingest")
                response = await self._llm.complete(
                    messages=[Message(role="user", content=source_text)],
                    system=classify_system,
                    max_tokens=2500,
                    temperature=0.3,
                    model=self._resolve_model("fast"),  # librarian: classification
                )
            except Exception:
                log.exception("KB %s: LLM extraction failed for %s — skipping", slug, fname)
                continue

            summary = self._extract_block(response.content, "summary") or response.content[:300]
            concepts = self._extract_block(response.content, "concepts") or ""
            self._extract_block(response.content, "entities")  # parsed but used implicitly via wiki_updates
            contradictions = self._extract_block(response.content, "contradictions") or "none found"
            updates = self._extract_block(response.content, "wiki_updates") or ""
            bib_raw = self._extract_block(response.content, "bibliography") or ""

            # Create source summary page — use display name for filename
            from agntspace.vault.writer import title_to_filename
            source_slug = Path(fname).stem.lower().replace(" ", "-")
            source_display = title_to_filename(Path(fname).stem)
            file_category = source_type if source_type in ("article", "paper", "image", "data", "code") else self._classify_source(fname)[0]
            lib_path = f"library/{file_category}/{date_folder}/{fname}"

            # For images: embed the image in the wiki page
            if is_image:
                image_section = f"\n![{fname}](../../{lib_path})\n\n> *Image analyzed by AI vision — see description below.*\n\n"
            else:
                image_section = ""

            vault_src = vault_sources.get(fname, "")
            vault_source_line = f"- Original: `{vault_src}`\n" if vault_src else ""

            # Preserve date_created from existing source page (don't overwrite on re-ingest)
            source_path = f"{base}/wiki/sources/{source_display}.md"
            original_date = date_str
            if self._reader.exists(source_path):
                try:
                    existing_doc = self._reader.read(source_path)
                    original_date = existing_doc.metadata.get("date_created", date_str)
                except Exception:
                    pass

            # Register in global bibliography (before source page so we get cite_key)
            cite_key = ""
            if self._bibliography:
                try:
                    bib_meta = self._parse_bib_metadata(bib_raw, fname, source_type, raw_source_url, date_str) if bib_raw else {
                        "title": Path(fname).stem.replace("-", " ").replace("_", " "),
                        "authors": [],
                        "date": date_str,
                        "source_type": source_type,
                    }
                    if raw_source_url:
                        bib_meta["url"] = raw_source_url
                    bib_entry = self._bibliography.register_from_ingest({
                        **bib_meta,
                        "kb_slug": slug,
                        "source_file": fname,
                        "library_path": lib_path,
                        "content_hash": content_hash,
                        "date_ingested": date_str,
                    })
                    cite_key = bib_entry.get("cite_key", "")
                except Exception:
                    log.debug("KB %s: bibliography registration failed for %s", slug, fname, exc_info=True)

            source_page = self._render_template("source_summary",
                title=fname, filename=fname, category=source_type,
                taxonomy_path=self._classify("source_summary", source_type, fname),
                summary=summary, concepts=concepts,
                date_created=original_date, date_updated=date_str,
                hash=content_hash,
                library_path=f"../../{lib_path}",
                source_url=raw_source_url,
                image_section=image_section,
                vault_source=vault_src,
                vault_source_line=vault_source_line,
                cite_key=cite_key,
            )

            # For images: append raw OCR text and vision description to the source page
            if is_image and source_text:
                source_page += "\n\n## Extracted Content\n" + source_text
            self._writer.write(source_path, source_page)
            wiki_updates.append(f"created sources/{source_display}")

            # Process CREATE/UPDATE wiki actions
            created_entities: list[str] = []
            created_concepts: list[str] = []
            if updates:
                for line in updates.strip().split("\n"):
                    line = line.strip().lstrip("- ")
                    if line.startswith("CREATE "):
                        parts = line[7:].split(":", 1)
                        if len(parts) == 2:
                            page_path = parts[0].strip()
                            desc_and_reason = parts[1].strip()
                            # Parse optional REASON
                            created_reason = ""
                            if "| REASON:" in desc_and_reason:
                                description, _, created_reason = desc_and_reason.partition("| REASON:")
                                description = description.strip()
                                created_reason = created_reason.strip()
                            else:
                                description = desc_and_reason
                            # Normalize slug: strip type prefixes, remap invalid subdirs
                            subdir, raw_slug = page_path.rsplit("/", 1) if "/" in page_path else ("concepts", page_path)
                            _INGEST_REMAP = {"events": "concepts", "meetings": "concepts", "people": "entities",
                                             "organizations": "entities", "orgs": "entities", "references": "sources"}
                            subdir = _INGEST_REMAP.get(subdir, subdir)
                            # Reject placeholder slugs from prompt examples
                            _PLACEHOLDER_SLUGS = {"person-slug", "topic-slug", "slug", "org-slug", "existing-slug"}
                            if raw_slug in _PLACEHOLDER_SLUGS or page_path.split("/")[-1] in _PLACEHOLDER_SLUGS:
                                continue
                            for prefix in ("person-", "org-", "organization-", "company-", "concept-", "entity-"):
                                if raw_slug.startswith(prefix):
                                    raw_slug = raw_slug[len(prefix):]
                                    break
                            page_path = f"{subdir}/{raw_slug}"

                            # Project auto-routing: if source or description mentions a known project,
                            # route to wiki/projects/{project}/{subdir}/ instead of global
                            matched_project = None
                            if known_projects:
                                source_lower = source_text.lower()
                                desc_lower = description.lower()
                                for proj_slug, proj_title in known_projects.items():
                                    proj_words = proj_slug.replace("-", " ")
                                    if proj_words in source_lower or proj_words in desc_lower:
                                        matched_project = proj_slug
                                        break
                            if matched_project:
                                page_path = f"projects/{matched_project}/{subdir}/{raw_slug}"
                                # Ensure project subdir exists
                                proj_subdir = self._reader._vault_dir / base / "wiki" / "projects" / matched_project / subdir
                                proj_subdir.mkdir(parents=True, exist_ok=True)

                            # Determine entity type from path
                            etype = "person" if "entities/" in page_path else "concept"
                            if any(kw in description.lower() for kw in ("company", "organization", "institution", "firm")):
                                etype = "organization"
                            # Use display-name filename, keep slug for dedup and API
                            display_name = title_to_filename(description)
                            full_path = f"{base}/wiki/{subdir}/{display_name}.md"
                            if not self._reader.exists(full_path):
                                alt_exists = False
                                try:
                                    # Words too generic for meaningful dedup
                                    _SLUG_STOPWORDS = {
                                        "analysis", "assessment", "management", "system", "systems",
                                        "process", "review", "report", "data", "control", "overview",
                                        "general", "safety", "security", "tracking", "standard",
                                    }
                                    new_words = {w for w in raw_slug.split("-") if len(w) >= 4 and w not in _SLUG_STOPWORDS}
                                    for existing_file in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                                        if "/.history/" in str(existing_file).replace("\\", "/") or "\\.history\\" in str(existing_file):
                                            continue
                                        existing_slug = existing_file.stem
                                        # 1. Substring match (archer-futura ⊂ archer-futura-technologies)
                                        if raw_slug in existing_slug or existing_slug in raw_slug:
                                            alt_exists = True
                                            log.info("KB %s: dedup %s — substring of %s", slug, page_path, existing_slug)
                                            break
                                        # 2. Word overlap (bowtie-analysis ~ bowtie-methodology)
                                        if new_words:
                                            existing_words = {w for w in existing_slug.split("-") if len(w) >= 4 and w not in _SLUG_STOPWORDS}
                                            overlap = new_words & existing_words
                                            # If they share a significant word AND both are short slugs, likely same topic
                                            if overlap and (len(overlap) / max(len(new_words), 1) >= 0.5
                                                           or len(overlap) / max(len(existing_words), 1) >= 0.5):
                                                alt_exists = True
                                                log.info("KB %s: dedup %s — word overlap with %s (shared: %s)",
                                                         slug, page_path, existing_slug, ", ".join(overlap))
                                                break
                                except Exception:
                                    pass
                                # Also check against pages created in THIS batch
                                if not alt_exists:
                                    batch_slugs = [p.rsplit("/", 1)[-1] for p in created_entities + created_concepts]
                                    for bs in batch_slugs:
                                        if raw_slug in bs or bs in raw_slug:
                                            alt_exists = True
                                            log.info("KB %s: dedup %s — substring of batch page %s", slug, page_path, bs)
                                            break
                                        bs_words = {w for w in bs.split("-") if len(w) >= 4 and w not in _SLUG_STOPWORDS}
                                        if new_words and bs_words:
                                            overlap = new_words & bs_words
                                            if overlap and (len(overlap) / max(len(new_words), 1) >= 0.5
                                                           or len(overlap) / max(len(bs_words), 1) >= 0.5):
                                                alt_exists = True
                                                log.info("KB %s: dedup %s — word overlap with batch page %s (shared: %s)",
                                                         slug, page_path, bs, ", ".join(overlap))
                                                break
                                if alt_exists:
                                    continue
                                page = self._render_template(etype,
                                    title=description, category=source_type,
                                    taxonomy_path=self._classify(etype, source_type, description),
                                    sources=json.dumps([fname]),
                                    source_list=f"- [[{source_display}|{fname}]]",
                                    date=date_str,
                                )
                                # Inject slug + created_reason into frontmatter
                                if "---" in page:
                                    fm_parts = page.split("---", 2)
                                    if len(fm_parts) >= 3:
                                        fm_parts[1] = fm_parts[1].rstrip() + f'\nslug: "{raw_slug}"\n'
                                        if created_reason:
                                            fm_parts[1] = fm_parts[1].rstrip() + f'\ncreated_reason: "{created_reason}"\n'
                                        page = "---".join(fm_parts)
                                self._writer.write(full_path, page)
                                wiki_updates.append(f"created {page_path}")
                                # Track for index update
                                if page_path.startswith("entities/"):
                                    created_entities.append(page_path)
                                elif page_path.startswith("concepts/"):
                                    created_concepts.append(page_path)

                    elif line.startswith("UPDATE "):
                        parts = line[7:].split(":", 1)
                        if len(parts) == 2:
                            page_path = parts[0].strip()
                            note = parts[1].strip()
                            full_path = f"{base}/wiki/{page_path}.md"
                            if self._reader.exists(full_path):
                                self._writer.append(full_path,
                                    f"\n\n> **Update from [[{fname}]]**: {note} [Source: {fname}]\n")
                                wiki_updates.append(f"updated {page_path}")

            # Add created entity/concept pages to index
            if created_entities:
                new = [p for p in created_entities if f"[[{p}]]" not in index_content]
                if new:
                    entry = "\n".join(f"- [[{p}]]" for p in new)
                    index_content = index_content.replace(
                        "<!-- Entity pages:",
                        f"<!-- Entity pages:\n{entry}",
                    )
            if created_concepts:
                new = [p for p in created_concepts if f"[[{p}]]" not in index_content]
                if new:
                    entry = "\n".join(f"- [[{p}]]" for p in new)
                    index_content = index_content.replace(
                        "<!-- Concept pages:",
                        f"<!-- Concept pages:\n{entry}",
                    )

            # Log contradictions (source page may not exist yet)
            if contradictions and contradictions != "none found":
                try:
                    self._writer.append(f"{base}/wiki/sources/{source_slug}.md",
                        f"\n## Contradictions Detected\n{contradictions}\n")
                except FileNotFoundError:
                    log.debug("KB %s: source page %s not found for contradiction log", slug, source_slug)

            # Update index — skip if this source is already listed
            dest_path = f"library/{source_type}/{date_folder}/{fname}"
            if f"### [{fname}]" not in index_content:
                entry = f"\n### [{fname}]({dest_path})\n- Type: {source_type}\n- Summary: {summary}\n- Hash: {content_hash}\n"
                index_content = index_content.replace(
                    "<!-- Each source: link, one-line summary, date ingested -->",
                    f"<!-- Each source: link, one-line summary, date ingested -->\n{entry}",
                )

            # Record full provenance — only pages created by THIS source
            lib_path = f"library/{source_type}/{date_folder}/{fname}"
            file_pages = [f"sources/{source_slug}"]
            file_pages.extend(created_entities)
            file_pages.extend(created_concepts)
            # Also count updates (not just creates)
            file_pages.extend(u.split(" ", 1)[-1] for u in wiki_updates if u.startswith("updated ") and fname in u)
            vault_src = vault_sources.get(fname, "")
            self._record_source(
                state, fname,
                content_hash=content_hash,
                vault_source=vault_src,
                source_type=source_type,
                library_path=lib_path,
                produced_pages=file_pages,
                agent="librarian",
            )
            ingested.append(fname)
            self._move_to_library(raw_file, base, fname, date_folder)
            # Atomic save: index FIRST (so it's never behind state), then state
            self._writer.write(f"{base}/wiki/.index.md", index_content)
            self._write_compile_state(slug, state)

            log.info("KB %s: ingested %s (hash %s, %d pages)", slug, fname, content_hash, len(file_pages))

        if ingested:
            index_content = self._update_frontmatter(index_content, "updated", date_str)
            self._writer.write(f"{base}/wiki/.index.md", index_content)
            self._update_index_stats(slug)
            state["last_ingest"] = now.isoformat()
            self._write_compile_state(slug, state)
            self._append_log(slug, "ingest", f"{len(ingested)} sources: {', '.join(ingested)}")

        self._writer._pipeline_mode = False
        return {"slug": slug, "ingested": ingested, "wiki_updates": wiki_updates, "count": len(ingested)}

    async def _describe_image(self, image_path: Path, ocr_text: str = "") -> str:
        """Use vision LLM to describe an image. Returns text description."""
        import base64

        from agntspace.llm.base import ImageContent

        # Read and encode image
        raw_bytes = image_path.read_bytes()
        b64 = base64.b64encode(raw_bytes).decode()

        # Determine media type
        ext = image_path.suffix.lower()
        media_types = {
            ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
            ".gif": "image/gif", ".webp": "image/webp", ".svg": "image/svg+xml",
        }
        media_type = media_types.get(ext, "image/png")

        image = ImageContent(base64_data=b64, media_type=media_type)

        prompt_parts = [
            "Describe this image in detail for a knowledge base. Include:",
            "1. What the image shows (diagram, photo, screenshot, chart, etc.)",
            "2. Any text, labels, or annotations visible",
            "3. Key information that should be indexed",
            "4. People, organizations, or concepts depicted",
            "5. How this relates to a knowledge base context",
            "",
            "Be thorough — this description replaces the image for text-based search and wiki compilation.",
        ]
        if ocr_text:
            prompt_parts.append(
                f"\n\nOCR has already extracted the following text from this image. "
                f"Use it as ground truth for any text visible, and focus your description "
                f"on visual elements, layout, and context that OCR cannot capture:\n\n{ocr_text}"
            )

        response = await self._llm.complete_vision(
            prompt="\n".join(prompt_parts),
            images=[image],
            max_tokens=1024,
        )

        log.info("Image described via vision LLM: %s (%d chars)", image_path.name, len(response.content))
        return response.content

    def _move_to_library(self, raw_file: Path, base: str, filename: str, date_folder: str) -> None:
        import shutil
        stype, _ = self._classify_source(filename)
        dest_dir = self._reader._vault_dir / base / "library" / stype / date_folder
        dest_dir.mkdir(parents=True, exist_ok=True)
        src = raw_file if isinstance(raw_file, Path) else Path(str(raw_file))
        try:
            shutil.move(str(src), str(dest_dir / filename))
        except Exception:
            log.warning("Failed to move %s", filename)
        # Clean up sidecar .source file if it exists
        source_meta = src.parent / f"{filename}.source"
        if source_meta.exists():
            try:
                source_meta.unlink()
            except Exception:
                pass

    # ── Compile ──

    async def compile_wiki(self, slug: str, full: bool = False) -> dict:
        """Compile sources into wiki articles. Incremental by default."""
        from agntspace.llm.base import Message

        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        self._writer._pipeline_mode = True

        index_doc = self._reader.read(f"{base}/wiki/.index.md")
        schema = self._read_schema(slug)
        state = self._read_compile_state(slug)
        now = datetime.now(UTC)
        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

        # Read existing articles (summaries only — tiered L1 loading)
        existing = {}
        for subdir in self._get_wiki_subdirs(slug):
            for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                try:
                    doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                    # L1: title + first 200 chars only
                    title = doc.metadata.get("title", wf.stem)
                    existing[f"{subdir}/{wf.stem}"] = f"{title}: {doc.content[:200]}"
                except Exception:
                    continue

        existing_text = "\n".join(f"- {k}: {v}" for k, v in existing.items()) or "No existing articles."

        # Identify stub pages that need filling (3+ TODOs, mostly placeholder)
        stubs = []
        for subdir in self._get_wiki_subdirs(slug):
            for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                try:
                    doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                    todo_count = doc.content.count("[TODO:")
                    if todo_count >= 3:
                        stubs.append(f"{subdir}/{wf.stem}")
                except Exception:
                    continue

        # Read sources — only new since last compile (unless full)
        # Sort by modification time (newest first) so recent ingests get compile priority
        source_files: list[tuple[float, Path]] = []
        last_compile = state.get("last_compile") if not full else None
        for search_dir in [f"{base}/library", f"{base}/inbox"]:
            try:
                for sf in self._reader.list_files(search_dir, "**/*"):
                    if sf.name == ".gitkeep":
                        continue
                    mtime = os.path.getmtime(sf)
                    # Incremental: skip if older than last compile
                    if last_compile:
                        file_time = datetime.fromtimestamp(mtime, tz=UTC).isoformat()
                        if file_time < last_compile:
                            continue
                    source_files.append((mtime, sf))
            except Exception:
                continue

        # Newest sources first — ensures recently ingested content gets compiled
        source_files.sort(key=lambda x: x[0], reverse=True)

        source_texts = []
        for _, sf in source_files:
            try:
                rel = str(sf.relative_to(self._reader._vault_dir)).replace("\\", "/")
                doc = self._reader.read(rel)
                source_texts.append(f"### {sf.name}\n{doc.content[:2500]}")
            except Exception:
                continue

        if not source_texts and not stubs:
            return {"slug": slug, "articles": [], "count": 0, "message": "No new sources and no stubs to fill."}

        # Build user message with specific instructions
        stubs_instruction = ""
        if stubs:
            stubs_list = ", ".join(stubs[:15])
            stubs_instruction = (
                f"\n\nCRITICAL: These {len(stubs)} existing articles are STUBS with only [TODO] placeholders. "
                f"You MUST rewrite them with FULL content extracted from the sources above. "
                f"Output each as an article block. Stubs to fill: {stubs_list}"
            )

        # Build compile prompt: skill-loaded or hardcoded fallback
        dynamic_ctx = (
            f"\nKB SCHEMA:\n{schema[:1500]}\n\n"
            f"WIKI INDEX:\n{index_doc.content[:2000]}\n\n"
            f"KNOWLEDGE TAXONOMY:\n{self._taxonomy_text}\n\n"
            f"EXISTING ARTICLES:\n{existing_text[:5000]}\n\n"
            f"NEW SOURCES TO PROCESS:\n{chr(10).join(source_texts)[:30000]}\n\n"
            f"Date: {date_str}"
        )
        skill_prompt = self._get_skill_prompt("kb-compile")
        if skill_prompt:
            compile_system = skill_prompt + "\n\n" + dynamic_ctx
        else:
            compile_system = _COMPILE_PROMPT_FALLBACK.format(
                schema=schema[:1500], index=index_doc.content[:2000],
                taxonomy=self._taxonomy_text,
                existing_articles=existing_text[:3000], sources="\n\n".join(source_texts)[:8000],
                date=date_str,
            )
        compile_system += "\n\n" + self._get_skill_rules("kb-compile")
        # Build explicit skip list from existing articles
        existing_slugs = list(existing.keys())
        skip_note = ""
        if existing_slugs:
            skip_note = f" ALREADY EXISTS (do NOT recreate): {', '.join(existing_slugs[:50])}."

        user_msg = (
            "Compile the wiki from sources now. "
            "Output ONLY ```article: blocks — no preamble, no explanation, no markdown outside the blocks. "
            "Start your response immediately with ```article:subdir/slug. "
            "Create NEW articles for entities, concepts, and techniques NOT already covered."
            f"{skip_note}"
            f"{stubs_instruction}"
        )
        response = await self._llm.complete(
            messages=[Message(role="user", content=user_msg)],
            system=compile_system,
            max_tokens=8192,
            temperature=0.0,
            model=self._resolve_model("fast"),  # librarian: compilation
        )

        articles_written = []
        log.info("KB %s compile: LLM response %d chars, contains 'article:': %s",
                 slug, len(response.content), "```article:" in response.content)
        if "```article:" not in response.content:
            log.info("KB %s compile: response preview: %s", slug, response.content[:500])
        parts = response.content.split("```article:")
        for part in parts[1:]:
            lines = part.split("\n", 1)
            article_path = lines[0].strip()  # e.g., "entities/person-name" or "concepts/topic"
            rest = lines[1] if len(lines) > 1 else ""
            end = rest.find("```")
            content = rest[:end].strip() if end != -1 else rest.strip()

            if article_path and content:
                # Remap unknown subdirectories to valid ones
                _VALID_SUBDIRS = {"entities", "concepts", "synthesis", "sources", "decisions", "projects"}
                _SUBDIR_REMAP = {
                    "events": "concepts", "meetings": "concepts", "people": "entities",
                    "organizations": "entities", "orgs": "entities", "references": "sources",
                    "skills": "concepts", "journal": "concepts",
                }
                if "/" in article_path:
                    subdir_part = article_path.split("/")[0]
                    if subdir_part not in _VALID_SUBDIRS:
                        remapped = _SUBDIR_REMAP.get(subdir_part, "concepts")
                        slug_part = article_path.split("/", 1)[1]
                        log.info("KB %s: remapping %s/ → %s/ for %s", slug, subdir_part, remapped, slug_part)
                        article_path = f"{remapped}/{slug_part}"

                # Extract title from article content frontmatter for display-name filename
                article_title = None
                if "---" in content:
                    _fm_parts = content.split("---", 2)
                    if len(_fm_parts) >= 3:
                        for _fm_line in _fm_parts[1].strip().split("\n"):
                            if _fm_line.startswith("title:"):
                                article_title = _fm_line.split(":", 1)[1].strip().strip('"').strip("'")
                                break

                # Use display-name filename if title available, otherwise fall back to slug
                from agntspace.vault.writer import title_to_filename
                if article_title:
                    article_subdir = article_path.rsplit("/", 1)[0] if "/" in article_path else "concepts"
                    display_filename = title_to_filename(article_title)
                    full_path = f"{base}/wiki/{article_subdir}/{display_filename}.md"
                    # Inject slug into frontmatter for API routing
                    article_slug = article_path.rsplit("/", 1)[-1] if "/" in article_path else article_path
                    if "---" in content:
                        _fm_parts = content.split("---", 2)
                        if len(_fm_parts) >= 3 and "slug:" not in _fm_parts[1]:
                            _fm_parts[1] = _fm_parts[1].rstrip() + f"\nslug: \"{article_slug}\"\n"
                            content = "---".join(_fm_parts)
                else:
                    full_path = f"{base}/wiki/{article_path}.md"

                is_stub_replace = False
                # If article exists: stub → replace, real content → enrich (append new info)
                if self._reader.exists(full_path):
                    existing_doc = self._reader.read(full_path)
                    todo_count = existing_doc.content.count("[TODO:")
                    real_content = len(existing_doc.content.replace("[TODO:", "").strip())
                    if todo_count >= 3 or real_content < 300:
                        is_stub_replace = True
                        log.info("KB %s: replacing stub %s (%d TODOs)", slug, article_path, todo_count)
                    else:
                        # Non-stub enrichment: append ONLY genuinely new content
                        new_body = content
                        if "---" in content:
                            fm_parts = content.split("---", 2)
                            if len(fm_parts) >= 3:
                                new_body = fm_parts[2].strip()
                        # Skip if new body is too similar to existing content (>60% overlap)
                        existing_text = existing_doc.content.strip()
                        if new_body and len(new_body) > 100:
                            from difflib import SequenceMatcher
                            similarity = SequenceMatcher(None, existing_text[:3000], new_body[:3000]).ratio()
                            if similarity > 0.6:
                                log.info("KB %s: skipping enrichment for %s — %.0f%% similar to existing", slug, article_path, similarity * 100)
                                continue
                            source_fnames = [sf.split("\n")[0].replace("### ", "").strip() for sf in source_texts]
                            update_note = f"\n\n---\n\n> **Updated from compile ({date_str})** — new sources: {', '.join(source_fnames[:5])}\n\n"
                            self._writer.append(full_path, update_note + new_body)
                            articles_written.append(article_path)
                            log.info("KB %s: enriched %s with new source content (%.0f%% novel)", slug, article_path, (1 - similarity) * 100)
                        continue
                # Dedup: skip for stub replacements (they SHOULD match existing slugs)
                if not is_stub_replace:
                    dup = self._find_similar_article(slug, article_path, content)
                    if dup:
                        log.info("KB %s: compile skipping %s — similar to existing %s", slug, article_path, dup)
                        continue
                # Inject derived_from with source files that contributed
                source_fnames = [sf.split("\n")[0].replace("### ", "").strip() for sf in source_texts]
                if "---" in content:
                    # Insert derived_from into existing frontmatter
                    parts_fm = content.split("---", 2)
                    if len(parts_fm) >= 3:
                        derived = json.dumps(source_fnames[:20])
                        parts_fm[1] = parts_fm[1].rstrip() + f"\nderived_from: {derived}\ncompiled_by: editor\ncompiled_at: \"{date_str}\"\n"
                        content = "---".join(parts_fm)
                # Append bibliography section if entries exist for the sources
                if self._bibliography and source_fnames:
                    bib_section = self._build_bibliography_section(source_fnames, slug)
                    if bib_section:
                        content = content.rstrip() + "\n\n" + bib_section

                self._writer.write(full_path, content)
                articles_written.append(article_path)

                # Track in compile state: which sources produced this article
                compile_record = state.setdefault("compiled_articles", {})
                compile_record[article_path] = {
                    "compiled_at": date_str,
                    "derived_from": source_fnames[:20],
                    "agent": "editor",
                }

        # Concept map
        concepts = self._extract_block(response.content, "concepts")
        if concepts:
            self._writer.write(f"{base}/wiki/.concepts.md", (
                f"---\ntitle: \"Concept Map\"\ntype: kb_concepts\nauthor: agent\nagent: editor\n"
                f"date_updated: \"{date_str}\"\n---\n\n{concepts}"
            ))

        # Update index — deduplicate, separate entities from concepts
        if articles_written:
            idx = index_doc.raw
            new_entities = [a for a in articles_written if a.startswith("entities/") and f"[[{a}]]" not in idx]
            new_concepts = [a for a in articles_written if a.startswith("concepts/") and f"[[{a}]]" not in idx]
            if new_entities:
                entity_list = "\n".join(f"- [[{a}]]" for a in new_entities)
                marker = "<!-- Entity pages:"
                if marker in idx:
                    idx = idx.replace(marker, f"{marker}\n{entity_list}\n")
            if new_concepts:
                concept_list = "\n".join(f"- [[{a}]]" for a in new_concepts)
                marker = "<!-- Concept pages:"
                if marker in idx:
                    idx = idx.replace(marker, f"{marker}\n{concept_list}\n")
            idx = self._update_frontmatter(idx, "updated", date_str)
            self._writer.write(f"{base}/wiki/.index.md", idx)

        self._update_index_stats(slug)
        state["last_compile"] = now.isoformat()
        self._write_compile_state(slug, state)
        self._append_log(slug, "compile", f"{len(articles_written)} articles: {', '.join(articles_written)}")

        self._writer._pipeline_mode = False
        return {"slug": slug, "articles": articles_written, "count": len(articles_written)}

    # ── Cross-Link ──

    def cross_link(self, slug: str) -> dict:
        """Scan all wiki pages for unlinked mentions of existing articles. Add [[wikilinks]].

        Scans every article for plain-text mentions of other article titles/slugs
        that aren't already wrapped in [[links]]. Converts them in-place.
        Pipeline mode: no versioning for automated cross-link writes.
        """
        import re as _re
        self._writer._pipeline_mode = True

        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Build lookup: slug → title for all articles
        articles: dict[str, str] = {}  # slug → title
        for subdir in self._get_wiki_subdirs(slug):
            try:
                for wf in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                    if wf.name.startswith(("_", ".")):
                        continue
                    try:
                        doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                        title = doc.metadata.get("title", wf.stem.replace("-", " ").title())
                        articles[wf.stem] = title
                    except Exception:
                        pass
            except Exception:
                continue

        if len(articles) < 2:
            return {"slug": slug, "links_added": 0, "pages_modified": 0}

        # Build regex patterns: match title or slug (case-insensitive) NOT inside [[...]]
        # Sort by title length descending so longer titles match first
        patterns: list[tuple[str, str, str]] = []  # (slug, title, regex pattern)
        for article_slug, title in sorted(articles.items(), key=lambda x: len(x[1]), reverse=True):
            # Skip very short titles (too many false positives)
            if len(title) < 4 and len(article_slug) < 4:
                continue
            # Match title or slug-as-words, NOT already inside [[ ]]
            escaped_title = _re.escape(title)
            escaped_slug_words = _re.escape(article_slug.replace("-", " "))
            # Combine: match either title or slug-as-words
            if escaped_title.lower() != escaped_slug_words.lower():
                pattern = f"(?:{escaped_title}|{escaped_slug_words})"
            else:
                pattern = escaped_title
            patterns.append((article_slug, title, pattern))

        links_added = 0
        pages_modified = 0

        # Scan each article
        for subdir in self._get_wiki_subdirs(slug):
            try:
                for wf in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                    if wf.name.startswith(("_", ".")):
                        continue
                    current_slug = wf.stem
                    try:
                        rel_path = f"{base}/wiki/{subdir}/{wf.name}"
                        doc = self._reader.read(rel_path)
                        content = doc.raw
                    except Exception:
                        continue

                    # Split into frontmatter and body
                    body_start = 0
                    if content.startswith("---"):
                        fm_end = content.find("---", 3)
                        if fm_end != -1:
                            body_start = fm_end + 3

                    frontmatter = content[:body_start]
                    body = content[body_start:]
                    modified = False

                    for target_slug, target_title, pattern in patterns:
                        # Don't link to self
                        if target_slug == current_slug:
                            continue

                        # Find mentions NOT already inside [[ ]]
                        def replace_mention(m: _re.Match, _title=target_title, body=body) -> str:
                            # Check if already inside a wikilink
                            start = m.start()
                            prefix = body[:start]
                            if prefix.endswith("[[") or "[[" in prefix[max(0, start - 50):start]:
                                # Check more carefully
                                last_open = prefix.rfind("[[")
                                last_close = prefix.rfind("]]")
                                if last_open > last_close:
                                    return m.group(0)  # inside [[ ]], leave alone
                            # Use display-name wikilinks: [[Title]] resolves to Title.md
                            # If matched text differs from title, use pipe: [[Title|matched text]]
                            matched = m.group(0)
                            if matched.lower() == _title.lower():
                                return f"[[{_title}]]"
                            return f"[[{_title}|{matched}]]"

                        new_body = _re.sub(
                            rf"(?<!\[\[)\b({pattern})\b(?!\]\])",
                            replace_mention,
                            body,
                            flags=_re.IGNORECASE,
                            count=1,  # Only link first mention per article
                        )
                        if new_body != body:
                            body = new_body
                            modified = True
                            links_added += 1

                    if modified:
                        self._writer.write(rel_path, frontmatter + body)
                        pages_modified += 1
            except Exception:
                continue

        if links_added:
            self._append_log(slug, "cross-link", f"{links_added} links added across {pages_modified} pages")
            log.info("KB %s: cross-linked %d mentions across %d pages", slug, links_added, pages_modified)

        self._writer._pipeline_mode = False
        return {"slug": slug, "links_added": links_added, "pages_modified": pages_modified}

    # ── Synthesize ──

    async def synthesize(self, slug: str) -> dict:
        """Generate cross-source synthesis pages — insights that no single source contains alone."""
        from agntspace.llm.base import Message

        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Read all source summaries
        source_texts = []
        try:
            for sf in self._reader.list_files(f"{base}/wiki/sources", "*.md"):
                doc = self._reader.read(f"{base}/wiki/sources/{sf.name}")
                source_texts.append(f"### {sf.stem}\n{doc.content[:2000]}")
        except Exception:
            pass

        if len(source_texts) < 2:
            return {"slug": slug, "articles": [], "count": 0, "message": "Need 2+ sources for synthesis."}

        # Read existing synthesis pages to avoid re-creating
        existing_synthesis = []
        try:
            for sf in self._reader.list_files(f"{base}/wiki/synthesis", "*.md"):
                existing_synthesis.append(sf.stem)
        except Exception:
            pass

        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

        response = await self._llm.complete(
            messages=[Message(role="user", content=(
                f"Analyze these {len(source_texts)} source summaries and identify cross-source insights — "
                f"connections, contradictions, patterns, or implications that no single source reveals alone.\n\n"
                f"Existing synthesis pages (do NOT duplicate): {', '.join(existing_synthesis) or 'none'}\n\n"
                f"For each genuine insight, create an article block. Only create synthesis pages for "
                f"NON-OBVIOUS connections. If no real cross-source insights exist, output nothing."
            ))],
            system=(
                "You are a knowledge synthesis specialist. Read source summaries and find connections across them.\n\n"
                "SOURCES:\n" + "\n\n".join(source_texts) + "\n\n"
                "Output format for each synthesis:\n"
                "```article:synthesis/{slug}\n"
                "---\n"
                f'title: "Synthesis: descriptive title"\n'
                "entity_type: synthesis\n"
                "category: cross-source\n"
                'status: draft\n'
                f'sources: ["source1", "source2"]\n'
                "author: agent\n"
                "agent: editor\n"
                f'date_created: "{date_str}"\n'
                f'date_updated: "{date_str}"\n'
                "---\n\n"
                "(Full analysis with [[wikilinks]] and [Source: file] citations)\n\n"
                "## Connections\n(how the sources relate)\n\n"
                "## Implications\n(what this means)\n\n"
                "## Open Questions\n(what this raises but doesn't answer)\n"
                "```\n\n"
                "If no genuine cross-source insights exist, respond with: no_synthesis"
            ),
            max_tokens=4096,
            temperature=0.1,
            model=self._resolve_model("capable"),  # editor: synthesis
        )

        if "no_synthesis" in response.content.lower():
            return {"slug": slug, "articles": [], "count": 0, "message": "No cross-source insights found."}

        articles_written = []
        parts = response.content.split("```article:")
        for part in parts[1:]:
            lines = part.split("\n", 1)
            article_path = lines[0].strip()
            rest = lines[1] if len(lines) > 1 else ""
            end = rest.find("```")
            content = rest[:end].strip() if end != -1 else rest.strip()

            if article_path and content and article_path.startswith("synthesis/"):
                full_path = f"{base}/wiki/{article_path}.md"
                if not self._reader.exists(full_path):
                    self._writer.write(full_path, content)
                    articles_written.append(article_path)

        if articles_written:
            self._append_log(slug, "synthesize", f"{len(articles_written)} synthesis pages: {', '.join(articles_written)}")

        return {"slug": slug, "articles": articles_written, "count": len(articles_written)}

    # ── Archive ──

    def snapshot(self, slug: str, reason: str = "manual") -> dict:
        """Create a timestamped snapshot of the wiki before destructive operations."""
        import shutil

        base = self._reader._vault_dir / "agnt-kb" / slug
        if not (base / "wiki" / ".index.md").exists():
            return {"error": f"KB not found: {slug}"}

        now = datetime.now(UTC)
        archive_name = now.strftime("%Y%m%dT%H%M%S")
        archive_dir = base / ".archives" / archive_name
        archive_dir.mkdir(parents=True, exist_ok=True)

        # Copy wiki/ and metadata
        wiki_dir = base / "wiki"
        if wiki_dir.is_dir():
            shutil.copytree(str(wiki_dir), str(archive_dir / "wiki"))

        # Copy state files
        for fname in (".compile-state.json", "SCHEMA.md", "log.md"):
            src = base / fname
            if src.exists():
                shutil.copy2(str(src), str(archive_dir / fname))

        # Write archive metadata
        import json as _json
        article_count = sum(1 for _ in wiki_dir.rglob("*.md")) if wiki_dir.is_dir() else 0
        meta = {
            "archived_at": now.isoformat(),
            "reason": reason,
            "article_count": article_count,
            "slug": slug,
        }
        (archive_dir / "archive-meta.json").write_text(_json.dumps(meta, indent=2), encoding="utf-8")

        self._append_log(slug, "snapshot", f"Archive created: {archive_name} (reason: {reason}, {article_count} articles)")
        log.info("KB %s: snapshot created at %s (%d articles)", slug, archive_name, article_count)
        return {"slug": slug, "archive": archive_name, "articles": article_count, "reason": reason}

    def list_snapshots(self, slug: str) -> list[dict]:
        """List available snapshots for a KB."""
        import json as _json

        archive_dir = self._reader._vault_dir / "agnt-kb" / slug / ".archives"
        if not archive_dir.is_dir():
            return []

        snapshots = []
        for d in sorted(archive_dir.iterdir(), reverse=True):
            if not d.is_dir():
                continue
            meta_file = d / "archive-meta.json"
            if meta_file.exists():
                try:
                    meta = _json.loads(meta_file.read_text(encoding="utf-8"))
                    meta["archive_id"] = d.name
                    snapshots.append(meta)
                except Exception:
                    snapshots.append({"archived_at": d.name, "archive_id": d.name, "reason": "unknown"})
        return snapshots

    def restore_snapshot(self, slug: str, archive_id: str) -> dict:
        """Restore a wiki from a previous snapshot.

        Safety: snapshots current state before restoring.
        """
        import shutil

        base = self._reader._vault_dir / "agnt-kb" / slug
        archive_dir = base / ".archives" / archive_id
        if not archive_dir.is_dir():
            return {"error": f"Snapshot not found: {archive_id}"}

        archived_wiki = archive_dir / "wiki"
        if not archived_wiki.is_dir():
            return {"error": f"Snapshot has no wiki directory: {archive_id}"}

        # Safety: snapshot current state before restoring
        pre_restore = self.snapshot(slug, reason="pre-restore")

        # Clear current wiki
        live_wiki = base / "wiki"
        if live_wiki.is_dir():
            shutil.rmtree(str(live_wiki))

        # Copy archived wiki back
        shutil.copytree(str(archived_wiki), str(live_wiki))

        # Restore state files if they exist in the archive
        for fname in (".compile-state.json", "SCHEMA.md", "log.md"):
            archived_file = archive_dir / fname
            if archived_file.exists():
                shutil.copy2(str(archived_file), str(base / fname))

        self._append_log(slug, "restore", f"Restored from snapshot {archive_id} (pre-restore saved as {pre_restore.get('archive', '?')})")
        log.info("KB %s: restored from snapshot %s", slug, archive_id)

        # Count restored articles
        article_count = sum(1 for _ in live_wiki.rglob("*.md"))

        return {
            "slug": slug,
            "restored_from": archive_id,
            "pre_restore_snapshot": pre_restore.get("archive", ""),
            "articles_restored": article_count,
        }

    # ── Project Scoping ──

    def create_project_wiki(
        self, kb_slug: str, project_slug: str, project_title: str,
        project_data: dict | None = None,
    ) -> str:
        """Create a project namespace within a KB wiki.

        If project_data is provided (from ProjectService), populates the overview
        with real description, goals, agents, milestones, and status.
        """
        base = f"agnt-kb/{kb_slug}/wiki/projects/{project_slug}"
        date_str = datetime.now().strftime("%Y-%m-%d %H:%M")

        # Pull real data from the projects module
        pd = project_data or {}
        description = pd.get("description", "")
        status = pd.get("status", "active")
        target_date = pd.get("target_date", "")
        goals = pd.get("related_goals", [])
        agents = pd.get("assigned_agents", [])
        milestones = pd.get("milestones", "")

        desc_text = description if description else "[TODO: project description]"
        target_text = f"\n**Target date:** {target_date}" if target_date else ""

        goals_text = "\n".join(f"- [[{g}]]" for g in goals) if goals else "[TODO: link to goals]"
        agents_text = "\n".join(f"- {a}" for a in agents) if agents else "[TODO: assigned agents]"

        milestones_text = ""
        if milestones:
            milestones_text = f"\n## Milestones\n{milestones}\n"

        overview = (
            f"---\ntitle: \"{project_title}\"\n"
            f"entity_type: project\ncategory: project\n"
            f"status: {status}\nauthor: agent\nagent: wiki-supervisor\n"
            f"related_goals: {json.dumps(goals)}\nassigned_agents: {json.dumps(agents)}\n"
            f"date_created: \"{date_str}\"\ndate_updated: \"{date_str}\"\n---\n\n"
            f"# {project_title}\n{target_text}\n\n"
            f"## Overview\n{desc_text}\n\n"
            f"## Goals\n{goals_text}\n\n"
            f"## Assigned Agents\n{agents_text}\n"
            f"{milestones_text}\n"
            f"## Key Concepts\n[TODO: link to project-specific concept pages]\n\n"
            f"## Key People\n[TODO: link to entity pages]\n\n"
            f"## Open Questions\n- [TODO: what don't we know yet?]\n\n"
            f"## Sources\n[TODO: source links]\n"
        )
        self._writer.write(f"{base}/{project_slug}.md", overview)
        self._writer.write(f"{base}/concepts/.gitkeep", "")
        self._writer.write(f"{base}/entities/.gitkeep", "")
        self._writer.write(f"{base}/notes/.gitkeep", "")

        self._append_log(kb_slug, "project", f"Project wiki created: {project_title} ({project_slug})")
        return f"{base}/{project_slug}.md"

    # ── Reflect ──

    def create_decision_record(
        self, slug: str, *,
        title: str, decision: str, context: str,
        alternatives: str = "None documented.",
        reasoning: str = "", consequences: str = "",
        affects: list[str] | None = None,
    ) -> str:
        """Create a decision record as a first-class wiki page."""
        date_str = datetime.now(UTC).strftime("%Y-%m-%d")
        from agntspace.vault.writer import title_to_filename
        record_display = title_to_filename(title)
        path = f"agnt-kb/{slug}/wiki/decisions/{record_display}.md"

        page = self._render_template("decision_record",
            title=title, date=date_str,
            decision=decision, context=context,
            alternatives=alternatives, reasoning=reasoning,
            consequences=consequences,
            affects=json.dumps(affects or []),
        )
        self._writer.write(path, page)
        self._append_log(slug, "decision", f"Decision recorded: {title}")
        return path

    async def reflect(
        self, slug: str, *,
        articles_created: list[str] | None = None,
        files_ingested: list[str] | None = None,
    ) -> dict:
        """Structural reflection after compile — creates decision records for significant changes.

        Part of the full pipeline: ingest → compile → **reflect** → lint
        """
        from agntspace.llm.base import Message

        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        articles_created = articles_created or []
        files_ingested = files_ingested or []

        # Nothing to reflect on
        if not articles_created and not files_ingested:
            return {"slug": slug, "decisions_created": 0, "message": "No changes to reflect on."}

        schema = self._read_schema(slug)

        # Read FULL content of recently created/modified articles
        recent_articles_text = []
        for art_path in articles_created[:10]:
            full = f"{base}/wiki/{art_path}.md"
            if self._reader.exists(full):
                try:
                    doc = self._reader.read(full)
                    recent_articles_text.append(f"### {art_path}\n{doc.content[:1000]}")
                except Exception:
                    pass

        # Also read source summaries for ingested files
        for fname in files_ingested[:5]:
            src_slug = fname.lower().replace(" ", "-").replace(".md", "")
            src_path = f"{base}/wiki/sources/{src_slug}.md"
            if self._reader.exists(src_path):
                try:
                    doc = self._reader.read(src_path)
                    recent_articles_text.append(f"### sources/{src_slug}\n{doc.content[:800]}")
                except Exception:
                    pass

        # Read existing article titles for context
        existing = []
        for subdir in self._get_wiki_subdirs(slug):
            try:
                for wf in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                    if wf.name.startswith(("_", ".")):
                        continue
                    try:
                        doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                        title = doc.metadata.get("title", wf.stem)
                        etype = doc.metadata.get("entity_type", "")
                        existing.append(f"- {subdir}/{wf.stem} [{etype}]: {title}")
                    except Exception:
                        pass
            except Exception:
                continue

        # Build reflect prompt: skill-loaded or hardcoded fallback
        dynamic_ctx = (
            f"\nWHAT JUST CHANGED:\n"
            f"- Articles created: {', '.join(articles_created) or 'none'}\n"
            f"- Files ingested: {', '.join(files_ingested[:10]) or 'none'}\n\n"
            f"RECENTLY CREATED/MODIFIED ARTICLES:\n"
            f"{chr(10).join(recent_articles_text) or 'No recent articles to analyze.'}\n\n"
            f"FULL WIKI STATE:\n{chr(10).join(existing[:80]) or 'No existing articles.'}\n\n"
            f"KB SCHEMA:\n{schema[:1000]}"
        )
        skill_prompt = self._get_skill_prompt("kb-reflect")
        if skill_prompt:
            reflect_system = skill_prompt + "\n\n" + dynamic_ctx
        else:
            reflect_system = _REFLECT_PROMPT_FALLBACK.format(
                articles_created=", ".join(articles_created) or "none",
                files_ingested=", ".join(files_ingested[:10]) or "none",
                recent_articles="\n\n".join(recent_articles_text) or "No recent articles to analyze.",
                existing_articles="\n".join(existing[:80]) or "No existing articles.",
                schema=schema[:1000],
            )
        response = await self._llm.complete(
            messages=[Message(role="user", content="Analyze the structural impact of recent wiki changes.")],
            system=reflect_system,
            max_tokens=2000, temperature=0.3,
            model=self._resolve_model("capable"),  # editor: reflection
        )

        # Check if LLM found significant decisions
        if "```no_decisions" in response.content:
            self._append_log(slug, "reflect", "No significant structural decisions")
            return {"slug": slug, "decisions_created": 0, "message": "Routine update — no structural decisions."}

        # Parse decision blocks
        decisions_created = 0
        for block in response.content.split("```decision"):
            if not block.strip() or block.strip().startswith("```"):
                continue
            end = block.find("```")
            content = block[:end].strip() if end != -1 else block.strip()

            # Parse fields
            fields: dict[str, str] = {}
            for line in content.split("\n"):
                if ":" in line:
                    key, _, val = line.partition(":")
                    fields[key.strip().lower()] = val.strip()

            title = fields.get("title", "Unnamed decision")
            if not title or title == "Unnamed decision":
                continue

            affects = [a.strip() for a in fields.get("affects", "").split(",") if a.strip()]

            self.create_decision_record(
                slug,
                title=title,
                decision=fields.get("decision", ""),
                context=fields.get("context", ""),
                alternatives=fields.get("alternatives", "None documented."),
                reasoning=fields.get("reasoning", ""),
                consequences=fields.get("consequences", ""),
                affects=affects,
            )
            decisions_created += 1

        self._append_log(slug, "reflect", f"{decisions_created} decision records created")
        return {"slug": slug, "decisions_created": decisions_created}

    # ── Research ──

    async def research(self, slug: str, query: str, save_output: bool = False, file_to_wiki: bool = False) -> dict:
        """Research with tiered context loading: index → search → targeted reads."""
        from agntspace.llm.base import Message

        base = f"agnt-kb/{slug}"
        schema = self._read_schema(slug)
        self._read_index(slug)  # warm cache

        # L1: Read index to find relevant pages
        query_words = set(query.lower().split())

        # L2: Score articles by relevance using index
        all_articles = {}
        for subdir in _WIKI_SUBDIRS:
            try:
                for wf in self._reader.list_files(f"{base}/wiki/{subdir}", "*.md"):
                    path = f"{base}/wiki/{subdir}/{wf.name}"
                    doc = self._reader.read(path)
                    title = doc.metadata.get("title", wf.stem)
                    # Score by query word overlap in title + first 200 chars
                    preview = f"{title} {doc.content[:200]}".lower()
                    score = sum(1 for w in query_words if w in preview)
                    all_articles[path] = {"title": title, "score": score, "content": doc.content}
            except Exception:
                continue

        if not all_articles:
            return {"answer": "No wiki articles. Run ingest + compile first.", "sources": []}

        # L3: Load full content of top-scoring articles only
        sorted_articles = sorted(all_articles.items(), key=lambda x: x[1]["score"], reverse=True)
        context_parts = []
        token_budget = 15000
        used = 0
        for path, info in sorted_articles[:15]:
            article_text = f"## {info['title']}\n\n{info['content']}"
            if used + len(article_text) > token_budget:
                break
            context_parts.append(article_text)
            used += len(article_text)

        output_instruction = ""
        if file_to_wiki:
            output_instruction = "Format as a wiki article with frontmatter. Use [[wiki-links]] and [Source: file] citations."

        # Build research prompt: skill-loaded or hardcoded fallback
        articles_ctx = "\n\n---\n\n".join(context_parts)
        dynamic_ctx = (
            f"\nKB SCHEMA:\n{schema[:1000]}\n\n"
            f"WIKI ARTICLES:\n{articles_ctx}\n\n"
            f"QUESTION:\n{query}\n\n{output_instruction}"
        )
        skill_prompt = self._get_skill_prompt("kb-research")
        if skill_prompt:
            research_system = skill_prompt + "\n\n" + dynamic_ctx
        else:
            research_system = _RESEARCH_PROMPT_FALLBACK.format(
                schema=schema[:1000], context="\n\n---\n\n".join(context_parts),
                query=query, output_instruction=output_instruction,
            )
        response = await self._llm.complete(
            messages=[Message(role="user", content=query)],
            system=research_system,
            max_tokens=2048, temperature=0.3,
            model=self._resolve_model("reasoning"),  # researcher: research
        )

        # Auto-file to wiki if answer has good citation coverage (>= 3 source references)
        source_refs = response.content.count("[Source:") + response.content.count("[[sources/")
        if not file_to_wiki and source_refs >= 3:
            file_to_wiki = True
            log.info("KB %s: auto-filing research answer to wiki (%d source citations)", slug, source_refs)

        output_path = None
        if save_output or file_to_wiki:
            ts = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
            date_today = datetime.now(UTC).strftime("%Y-%m-%d")
            q_slug = query[:40].lower().replace(" ", "-").replace("/", "-")
            if file_to_wiki:
                output_path = f"{base}/wiki/concepts/research-{q_slug}.md"
                # Idempotent: update existing research article instead of duplicating
                if self._reader.exists(output_path):
                    existing = self._reader.read(output_path)
                    content = self._update_frontmatter(existing.raw, "date_updated", date_today)
                    # Replace body after frontmatter
                    fm_end = content.find("---", content.find("---") + 3)
                    if fm_end != -1:
                        content = content[:fm_end + 3] + f"\n\n{response.content}"
                    log.info("KB %s: updated existing research article %s", slug, output_path)
                else:
                    content = response.content if response.content.startswith("---") else (
                        f"---\ntitle: \"{query[:80]}\"\nentity_type: concept\ncategory: research\n"
                        f"status: draft\nauthor: agent\nagent: researcher\ndate_created: \"{date_today}\"\n"
                        f"date_updated: \"{date_today}\"\n---\n\n{response.content}"
                    )
            else:
                output_path = f"{base}/output/research_{q_slug}_{ts}.md"
                content = (
                    f"---\ntitle: \"{query[:80]}\"\ntype: kb_research\nauthor: agent\nagent: researcher\n"
                    f"date: \"{date_today}\"\n---\n\n# Research: {query}\n\n{response.content}"
                )
            self._writer.write(output_path, content)

        self._append_log(slug, "research", f"Q: {query[:80]}")
        return {"answer": response.content, "output_path": output_path, "filed_to_wiki": file_to_wiki}

    # ── Lint ──

    def _structural_analysis(self, slug: str) -> tuple[list[dict], dict[str, str]]:
        """Pre-compute structural wiki issues from file data (no LLM needed).

        Returns (issues_list, articles_dict) where articles_dict maps path → content.
        """
        import re as _re
        from difflib import SequenceMatcher

        base = f"agnt-kb/{slug}"
        issues: list[dict] = []

        # Load all articles: path → {content, title, metadata, links_out, links_in}
        articles: dict[str, dict] = {}
        for subdir in _WIKI_SUBDIRS:
            try:
                for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                    rel = f"{subdir}/{wf.stem}"
                    doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                    # Extract outbound [[wiki-links]]
                    outbound = set(_re.findall(r'\[\[([^\]]+)\]\]', doc.content))
                    # Count TODOs
                    todos = len(_re.findall(r'\[TODO:', doc.content))
                    articles[rel] = {
                        "content": doc.content,
                        "title": doc.metadata.get("title", wf.stem),
                        "metadata": doc.metadata,
                        "outbound_links": outbound,
                        "inbound_count": 0,
                        "todo_count": todos,
                        "status": doc.metadata.get("status", ""),
                        "entity_type": doc.metadata.get("entity_type", ""),
                        "sources": doc.metadata.get("sources", []),
                        "date_created": doc.metadata.get("date_created", ""),
                    }
            except Exception:
                continue

        if not articles:
            return issues, {}

        # Build inbound link counts + find broken links
        all_slugs = set(articles.keys())
        # Also index by just the slug part (without subdir) for fuzzy matching
        slug_to_path = {}
        for path in all_slugs:
            parts = path.split("/", 1)
            if len(parts) == 2:
                slug_to_path[parts[1]] = path

        missing_pages: set[str] = set()
        for path, info in articles.items():
            for link in info["outbound_links"]:
                # Normalize: links might be "slug" or "subdir/slug"
                link_norm = link.lower().replace(" ", "-")
                target = None
                if link_norm in all_slugs:
                    target = link_norm
                elif link_norm in slug_to_path:
                    target = slug_to_path[link_norm]
                else:
                    # Try partial match
                    for s in all_slugs:
                        if s.endswith(f"/{link_norm}"):
                            target = s
                            break

                if target and target in articles:
                    articles[target]["inbound_count"] += 1
                elif link_norm not in missing_pages:
                    missing_pages.add(link_norm)

        # 1. Orphan pages (no inbound links, excluding source summaries and index)
        for path, info in articles.items():
            if info["inbound_count"] == 0 and not path.startswith("sources/") and not path.startswith("source_summary/"):
                issues.append({
                    "type": "orphan",
                    "severity": "warning",
                    "message": f'Article "{info["title"]}" ({path}) has no inbound links',
                })

        # 2. Broken/missing pages
        for link in missing_pages:
            issues.append({
                "type": "missing_page",
                "severity": "critical",
                "message": f'[[{link}]] is linked but no article exists',
            })

        # 3. High TODO density
        for path, info in articles.items():
            if info["todo_count"] >= 3:
                issues.append({
                    "type": "todo",
                    "severity": "warning",
                    "message": f'Article "{info["title"]}" ({path}) has {info["todo_count"]} [TODO] items',
                })

        # 4. Missing frontmatter
        required_fields = {"entity_type", "status"}
        for path, info in articles.items():
            missing = [f for f in required_fields if not info["metadata"].get(f)]
            if missing:
                issues.append({
                    "type": "frontmatter",
                    "severity": "warning",
                    "message": f'Article "{info["title"]}" ({path}) missing frontmatter: {", ".join(missing)}',
                })

        # 5. Slug-based duplicate detection
        titles_seen: dict[str, str] = {}  # normalized_title → path
        for path, info in articles.items():
            if path.startswith("sources/") or path.startswith("source_summary/"):
                continue
            norm_title = info["title"].lower().strip()
            if norm_title in titles_seen:
                issues.append({
                    "type": "duplicate",
                    "severity": "critical",
                    "message": f'Potential duplicate: "{info["title"]}" ({path}) and ({titles_seen[norm_title]}) have the same title',
                })
            else:
                titles_seen[norm_title] = path

        # Also check slug similarity
        non_source_paths = [p for p in all_slugs if not p.startswith("sources/") and not p.startswith("source_summary/")]
        for i, p1 in enumerate(non_source_paths):
            slug1 = p1.split("/")[-1]
            for p2 in non_source_paths[i + 1:]:
                slug2 = p2.split("/")[-1]
                if slug1 != slug2 and SequenceMatcher(None, slug1, slug2).ratio() > 0.80:
                    issues.append({
                        "type": "duplicate",
                        "severity": "warning",
                        "message": f'Similar slugs: {p1} and {p2} — may be duplicates',
                    })

        # 6. Stale articles (source_summary pointing to deleted files)
        for path, info in articles.items():
            if info["status"] == "stale":
                issues.append({
                    "type": "stale",
                    "severity": "warning",
                    "message": f'Article "{info["title"]}" ({path}) is marked stale',
                })

        # Build articles_text dict for LLM prompt
        articles_text = {path: info["content"] for path, info in articles.items()}

        return issues, articles_text

    async def lint(self, slug: str) -> dict:
        """Run comprehensive wiki health-check: structural analysis + LLM semantic review."""
        from agntspace.llm.base import Message

        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        schema = self._read_schema(slug)
        index_doc = self._reader.read(f"{base}/wiki/.index.md")

        # Phase 1: Structural analysis (fast, no LLM)
        structural_issues, articles_content = self._structural_analysis(slug)

        structural_text = "\n".join(
            f"- [{i['type']}] ({i['severity']}) {i['message']}" for i in structural_issues
        ) or "No structural issues found."

        # Phase 2: Semantic analysis (LLM)
        articles_text = []
        for path, content in articles_content.items():
            articles_text.append(f"### {path}\n{content[:1500]}")

        # Build lint prompt: skill-loaded or hardcoded fallback
        dynamic_ctx = (
            f"\nKB SCHEMA:\n{schema[:1000]}\n\n"
            f"WIKI INDEX:\n{index_doc.content[:3000]}\n\n"
            f"STRUCTURAL ISSUES:\n{structural_text[:3000]}\n\n"
            f"ARTICLES:\n{chr(10).join(articles_text)[:10000]}"
        )
        skill_prompt = self._get_skill_prompt("kb-lint")
        if skill_prompt:
            lint_system = skill_prompt + "\n\n" + dynamic_ctx
        else:
            lint_system = _LINT_PROMPT_FALLBACK.format(
                schema=schema[:1000], index=index_doc.content[:3000],
                structural_issues=structural_text[:3000],
                articles="\n\n".join(articles_text)[:10000],
            )
        response = await self._llm.complete(
            messages=[Message(role="user", content="Run deep wiki health check. Focus on semantic issues the structural analysis can't detect.")],
            system=lint_system,
            max_tokens=2048, temperature=0.3,
            model=self._resolve_model("capable"),  # editor: lint
        )

        llm_issues_text = self._extract_block(response.content, "issues") or ""
        suggestions_text = self._extract_block(response.content, "suggestions") or ""
        llm_issues = [l.strip() for l in llm_issues_text.split("\n") if l.strip().startswith("- ")]
        suggestion_list = [l.strip() for l in suggestions_text.split("\n") if l.strip().startswith("- ")]

        # Combine structural + semantic issues
        all_issues = [f"- [{i['type']}] {i['message']}" for i in structural_issues] + llm_issues

        self._append_log(slug, "lint",
            f"{len(structural_issues)} structural + {len(llm_issues)} semantic issues, {len(suggestion_list)} suggestions")
        return {
            "slug": slug,
            "issues": all_issues,
            "suggestions": suggestion_list,
            "issue_count": len(all_issues),
            "suggestion_count": len(suggestion_list),
            "structural_issues": len(structural_issues),
            "semantic_issues": len(llm_issues),
        }

    # ── Repair ──

    async def repair(self, slug: str) -> dict:
        """Auto-fix wiki issues: delete orphans, remove duplicates, clean .history/ noise.

        Runs structural analysis, then acts on fixable issues:
        - Orphan articles (no inbound links, not sources): deleted
        - Duplicate titles: keeps the one with more content, deletes the other
        - .history/ files that leaked into wiki listings: cleaned up
        - Empty articles (< 50 chars of real content): deleted

        Does NOT require LLM. Fast, deterministic.
        """
        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        issues, articles_text = self._structural_analysis(slug)
        actions = {"deleted": [], "kept": [], "cleaned": []}

        # 1. Delete empty articles (< 50 chars of real content)
        for subdir in self._get_wiki_subdirs(slug):
            for wf in self._list_wiki_articles(f"{base}/wiki/{subdir}"):
                try:
                    doc = self._reader.read(f"{base}/wiki/{subdir}/{wf.name}")
                    # Strip frontmatter and whitespace
                    real = doc.content.strip()
                    if len(real) < 50:
                        full = self._reader._vault_dir / base / "wiki" / subdir / wf.name
                        if full.exists():
                            full.unlink()
                            actions["deleted"].append(f"{subdir}/{wf.stem} (empty)")
                except Exception:
                    continue

        # 2. Delete duplicate titles (keep the one with more content)
        title_map: dict[str, list[tuple[str, int]]] = {}  # norm_title → [(path, content_len)]
        for issue in issues:
            if issue["type"] == "duplicate" and "same title" in issue["message"]:
                # Extract both paths from the message
                import re as _re
                paths = _re.findall(r'\(([^)]+)\)', issue["message"])
                if len(paths) >= 2:
                    for p in paths:
                        content = articles_text.get(p, "")
                        title_map.setdefault(issue["message"], []).append((p, len(content)))

        for _msg, entries in title_map.items():
            if len(entries) < 2:
                continue
            # Keep the one with more content
            entries.sort(key=lambda x: x[1], reverse=True)
            keep = entries[0][0]
            for path, _size in entries[1:]:
                subdir, stem = path.split("/", 1) if "/" in path else ("", path)
                full = self._reader._vault_dir / base / "wiki" / subdir / f"{stem}.md"
                if full.exists():
                    full.unlink()
                    actions["deleted"].append(f"{path} (duplicate of {keep})")
            actions["kept"].append(keep)

        # 3. Clean up .history/ files that shouldn't exist (e.g., in non-wiki dirs)
        try:
            history_dirs = list((self._reader._vault_dir / base / "wiki").rglob(".history"))
            for hd in history_dirs:
                if hd.is_dir():
                    # Count files
                    history_files = list(hd.glob("*.md"))
                    if len(history_files) > 20:
                        # Keep only 20 most recent per article stem
                        stems: dict[str, list] = {}
                        for hf in history_files:
                            stem = hf.stem.rsplit("_", 1)[0] if "_" in hf.stem else hf.stem
                            stems.setdefault(stem, []).append(hf)
                        for stem, files in stems.items():
                            files.sort(key=lambda f: f.name, reverse=True)
                            for old in files[20:]:
                                old.unlink()
                                actions["cleaned"].append(str(old.name))
        except Exception:
            pass

        self._append_log(slug, "repair",
            f"deleted {len(actions['deleted'])}, cleaned {len(actions['cleaned'])}")

        return {
            "slug": slug,
            "deleted": actions["deleted"],
            "kept": actions["kept"],
            "cleaned": actions["cleaned"],
            "total_actions": len(actions["deleted"]) + len(actions["cleaned"]),
        }

    async def sync_projects_to_wiki(self, slug: str) -> dict:
        """Ensure all vault projects have wiki pages in this KB.

        For each project that doesn't have a wiki namespace yet,
        creates a project wiki page with overview, status, and links.
        """
        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        # Get all projects from vault
        projects_dir = self._reader._vault_dir / "projects"
        if not projects_dir.is_dir():
            return {"slug": slug, "synced": 0, "message": "No projects directory"}

        synced = 0
        for proj_dir in projects_dir.iterdir():
            if not proj_dir.is_dir():
                continue
            project_md = proj_dir / "PROJECT.md"
            if not project_md.exists():
                continue

            proj_slug = proj_dir.name
            wiki_path = f"{base}/wiki/projects/{proj_slug}/{proj_slug}.md"

            # Skip if already exists
            if self._reader.exists(wiki_path):
                continue

            # Read project data
            try:
                import frontmatter as fm
                post = fm.load(str(project_md))
                title = post.metadata.get("title", proj_slug.replace("-", " ").title())
                status = post.metadata.get("status", "active")
                description = post.content[:500] if post.content else ""
                goals = post.metadata.get("related_goals", [])
                agents = post.metadata.get("assigned_agents", [])
                kbs = post.metadata.get("linked_kbs", [])
            except Exception:
                title = proj_slug.replace("-", " ").title()
                status = "active"
                description = ""
                goals = []
                agents = []
                kbs = []

            # Create project wiki page
            content = f"""---
title: "{title}"
entity_type: project
category: projects
status: {status}
author: agent
agent: wiki-supervisor
date_created: "{datetime.now(UTC).strftime('%Y-%m-%d %H:%M')}"
---

# {title}

{description}

## Status

{status}

## Links

"""
            if goals:
                content += "### Goals\n" + "\n".join(f"- [[{g}]]" for g in goals) + "\n\n"
            if agents:
                content += "### Agents\n" + "\n".join(f"- [[{a}]]" for a in agents) + "\n\n"
            if kbs:
                content += "### Knowledge Bases\n" + "\n".join(f"- {kb}" for kb in kbs) + "\n\n"

            # Write
            (self._reader._vault_dir / base / "wiki" / "projects" / proj_slug).mkdir(parents=True, exist_ok=True)
            self._writer.write(wiki_path, content)
            synced += 1
            log.info("Synced project to wiki: %s → %s", proj_slug, wiki_path)

        if synced:
            self._append_log(slug, "sync-projects", f"{synced} projects synced to wiki")

        return {"slug": slug, "synced": synced}

    # ── Article Consolidation ──

    async def consolidate_articles(self, slug: str, min_updates: int = 3) -> dict:
        """Find and rewrite append-only articles that have accumulated updates.

        Articles with `min_updates` or more "Updated from compile" markers get
        rewritten by the LLM into a single coherent article. Old version is
        automatically saved to .history/ by the vault writer.

        Returns count of articles consolidated.
        """
        from agntspace.llm.base import Message

        base = f"agnt-kb/{slug}"
        wiki_base = f"{base}/wiki"

        if not self._reader.exists(f"{wiki_base}/.index.md"):
            return {"error": f"KB not found: {slug}"}

        candidates = []
        for subdir in ("entities", "concepts", "sources", "synthesis", "decisions"):
            dir_path = f"{wiki_base}/{subdir}"
            try:
                files = self._reader.list_files(dir_path, "*.md")
            except Exception:
                continue
            for f in files:
                if f.name.startswith(("_", ".")):
                    continue
                try:
                    relative = f"{dir_path}/{f.name}"
                    doc = self._reader.read(relative)
                    update_count = doc.content.count("Updated from compile")
                    if update_count >= min_updates:
                        candidates.append({
                            "path": relative,
                            "title": doc.metadata.get("title", f.stem),
                            "update_count": update_count,
                            "size": len(doc.content),
                        })
                except Exception:
                    continue

        if not candidates:
            return {"slug": slug, "consolidated": 0, "message": "No articles need consolidation"}

        # Sort by most updates first
        candidates.sort(key=lambda x: x["update_count"], reverse=True)

        consolidated = 0
        for article in candidates[:10]:  # max 10 per run
            try:
                doc = self._reader.read(article["path"])
                frontmatter_raw = doc.raw[:doc.raw.index("---", 3) + 3] if "---" in doc.raw[3:] else ""

                consolidate_system = self._get_skill_prompt("kb-consolidate") or _CONSOLIDATE_PROMPT_FALLBACK
                response = await self._llm.complete(
                    messages=[Message(role="user", content=doc.content)],
                    system=consolidate_system,
                    max_tokens=4096,
                    temperature=0.3,
                    model=self._resolve_model("capable"),  # editor: consolidate
                )

                new_content = response.content.strip()
                if not new_content or len(new_content) < 100:
                    continue

                # Preserve frontmatter, replace body
                if frontmatter_raw:
                    full = f"{frontmatter_raw}\n\n{new_content}"
                else:
                    full = new_content

                # Write (versioning happens automatically in VaultWriter)
                self._writer.write(article["path"], full)
                consolidated += 1
                log.info("Consolidated article: %s (%d updates merged)",
                         article["path"], article["update_count"])
            except Exception as e:
                log.warning("Failed to consolidate %s: %s", article["path"], e)
                continue

        self._log(slug, "consolidate", f"{consolidated} articles consolidated")
        return {"slug": slug, "consolidated": consolidated, "candidates": len(candidates)}

    # ── Full Pipeline ──

    async def run_wiki_job(self, slug: str, *, skip_lint: bool = False, skip_reflect: bool = False) -> dict:
        """Run the full wiki pipeline: snapshot → ingest → compile → reflect → lint.

        This is the single entry point for a complete wiki processing cycle.
        Designed to be called from chat (agent tool) or API.
        """
        base = f"agnt-kb/{slug}"
        if not self._reader.exists(f"{base}/wiki/.index.md"):
            return {"error": f"KB not found: {slug}"}

        results: dict[str, Any] = {"slug": slug, "steps": []}

        # 1. Snapshot (safety net before processing)
        try:
            snap = self.snapshot(slug, reason="pre-wiki-job")
            results["snapshot"] = snap.get("path", "")
            results["steps"].append("snapshot")
        except Exception:
            log.warning("KB %s: snapshot failed, continuing anyway", slug)

        # 2. Ingest (process inbox files)
        try:
            ingest_result = await self.ingest(slug)
            results["ingested"] = ingest_result.get("count", 0)
            results["ingested_files"] = ingest_result.get("ingested", [])
            results["steps"].append("ingest")
        except Exception:
            log.exception("KB %s: ingest failed during wiki job", slug)
            results["ingested"] = 0
            results["ingest_error"] = True

        # 3. Compile (generate/update wiki articles)
        try:
            compile_result = await self.compile_wiki(slug)
            results["compiled"] = compile_result.get("count", 0)
            results["compiled_articles"] = compile_result.get("articles", [])
            results["steps"].append("compile")
        except Exception:
            log.exception("KB %s: compile failed during wiki job", slug)
            results["compiled"] = 0
            results["compile_error"] = True

        # 4. Synthesize (cross-source insights — only if 2+ sources exist)
        if results.get("ingested", 0) > 0 or results.get("compiled", 0) > 0:
            try:
                synth_result = await self.synthesize(slug)
                results["synthesized"] = synth_result.get("count", 0)
                if synth_result.get("count", 0) > 0:
                    results["steps"].append("synthesize")
            except Exception:
                log.exception("KB %s: synthesize failed during wiki job", slug)

        # 5. Cross-link (scan for unlinked mentions, add [[wikilinks]])
        if results.get("ingested", 0) > 0 or results.get("compiled", 0) > 0:
            try:
                xlink = self.cross_link(slug)
                results["cross_links_added"] = xlink.get("links_added", 0)
                if xlink.get("links_added", 0) > 0:
                    results["steps"].append("cross-link")
            except Exception:
                log.exception("KB %s: cross-link failed during wiki job", slug)

        # 6. Reflect (structural analysis — only if something changed)
        if not skip_reflect and (results.get("ingested", 0) > 0 or results.get("compiled", 0) > 0):
            try:
                reflect_result = await self.reflect(
                    slug,
                    articles_created=results.get("compiled_articles", []),
                    files_ingested=results.get("ingested_files", []),
                )
                results["decisions_created"] = reflect_result.get("decisions_created", 0)
                results["reflect_message"] = reflect_result.get("message", "")
                results["steps"].append("reflect")
            except Exception:
                log.exception("KB %s: reflect failed during wiki job", slug)
                results["reflect_error"] = True

        # 6. Lint (health check)
        if not skip_lint:
            try:
                lint_result = await self.lint(slug)
                results["issues"] = lint_result.get("issue_count", 0)
                results["suggestions"] = lint_result.get("suggestion_count", 0)
                results["lint_issues"] = lint_result.get("issues", [])[:10]  # top 10
                results["lint_suggestions"] = lint_result.get("suggestions", [])[:5]
                results["steps"].append("lint")
            except Exception:
                log.exception("KB %s: lint failed during wiki job", slug)
                results["lint_error"] = True

        self._append_log(slug, "wiki-job",
            f"Pipeline complete: {results.get('ingested', 0)} ingested, "
            f"{results.get('compiled', 0)} compiled, "
            f"{results.get('synthesized', 0)} synthesized, "
            f"{results.get('cross_links_added', 0)} cross-links, "
            f"{results.get('decisions_created', 0)} decisions, "
            f"{results.get('issues', '?')} issues")

        return results

    # ── Reclassify ──

    def reclassify_articles(self, slug: str | None = None) -> dict:
        """Re-run taxonomy classification on all articles and update their frontmatter.

        Call after taxonomy YAML changes to migrate all articles to new paths.
        If slug is None, reclassifies across all KBs.
        """
        from agntspace.kb.taxonomy import classify_article, flatten_taxonomy, load_taxonomy

        if not self._skills_dir:
            return {"error": "No skills directory configured", "updated": 0}

        tree = load_taxonomy(self._skills_dir)
        flat_nodes = flatten_taxonomy(tree)
        slugs = [slug] if slug else [kb["slug"] for kb in self.list_kbs()]
        updated = 0
        total = 0

        for kb_slug in slugs:
            base = f"agnt-kb/{kb_slug}/wiki"
            for subdir in _WIKI_SUBDIRS:
                try:
                    files = self._reader.list_files(f"{base}/{subdir}", "*.md")
                except Exception:
                    continue
                for f in files:
                    total += 1
                    try:
                        rel = f"agnt-kb/{kb_slug}/wiki/{subdir}/{f.name}"
                        doc = self._reader.read(rel)
                        meta = doc.metadata
                        old_path = meta.get("taxonomy_path", "")

                        new_path = classify_article(
                            entity_type=meta.get("entity_type", ""),
                            category=meta.get("category", ""),
                            title=meta.get("title", f.stem.replace("-", " ").title()),
                            flat_nodes=flat_nodes,
                        )

                        if new_path != old_path:
                            content = self._update_frontmatter(doc.raw, "taxonomy_path", new_path)
                            self._writer.write(rel, content)
                            updated += 1
                    except Exception:
                        continue

        return {"updated": updated, "total": total, "kbs": slugs}

    # ── Utility ──

    @staticmethod
    def _extract_block(text: str, label: str) -> str | None:
        marker = f"```{label}"
        start = text.find(marker)
        if start == -1:
            return None
        start = text.index("\n", start) + 1
        end = text.find("```", start)
        if end == -1:
            return text[start:].strip()
        return text[start:end].strip()

    def _build_bibliography_section(self, source_files: list[str], kb_slug: str) -> str:
        """Build a numbered bibliography section from source files."""
        entries: list[str] = []
        for i, fname in enumerate(source_files, 1):
            bib = self._bibliography.find_by_source(fname, kb_slug)
            if bib:
                authors = bib.get("authors", [])
                author_str = ", ".join(authors) if authors else ""
                title = bib.get("title", fname)
                date = bib.get("date", "")
                publisher = bib.get("publisher", "")
                url = bib.get("url", "")
                cite_key = bib.get("cite_key", "")

                parts = []
                if author_str:
                    parts.append(author_str)
                if date:
                    parts.append(f"({date})")
                parts.append(f'"{title}"')
                if publisher:
                    parts.append(f"*{publisher}*")
                if url:
                    parts.append(f"[Link]({url})")
                if cite_key:
                    parts.append(f"`[@{cite_key}]`")
                entries.append(f"{i}. {'. '.join(parts)}")
            else:
                entries.append(f"{i}. [[{Path(fname).stem}|{fname}]]")
        if not entries:
            return ""
        return "## References\n\n" + "\n".join(entries) + "\n"

    @staticmethod
    def _parse_bib_metadata(
        bib_raw: str, filename: str, source_type: str, source_url: str, date_str: str,
    ) -> dict:
        """Parse the LLM-produced bibliography block into structured metadata."""
        meta: dict = {"source_type": source_type}
        for line in bib_raw.strip().split("\n"):
            line = line.strip().lstrip("- ")
            if ":" not in line:
                continue
            key, _, val = line.partition(":")
            key = key.strip().lower()
            val = val.strip().strip('"').strip("'")
            if not val or val.lower() == "unknown":
                continue
            if key == "title":
                meta["title"] = val
            elif key == "authors":
                meta["authors"] = [a.strip() for a in val.split(",") if a.strip()]
            elif key == "date":
                meta["date"] = val
            elif key == "publisher":
                meta["publisher"] = val
            elif key == "doi":
                meta["doi"] = val
        # Fallbacks
        if "title" not in meta:
            meta["title"] = Path(filename).stem.replace("-", " ").replace("_", " ")
        if source_url:
            meta["url"] = source_url
        if "date" not in meta:
            meta["date"] = date_str
        return meta

    @staticmethod
    def _update_frontmatter(content: str, key: str, value: str) -> str:
        import re
        pattern = rf'^{key}:\s*".*?"'
        replacement = f'{key}: "{value}"'
        result = re.sub(pattern, replacement, content, count=1, flags=re.MULTILINE)
        if result == content:
            result = content.replace("---\n", f"---\n{key}: \"{value}\"\n", 1)
        return result
