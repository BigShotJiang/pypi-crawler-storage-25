"""Vault full-text search using SQLite FTS5."""

from __future__ import annotations

import hashlib
import logging
from datetime import UTC, datetime

import aiosqlite

from agntspace.vault.reader import VaultReader

log = logging.getLogger(__name__)


class VaultSearch:
    """Full-text search over vault markdown files using FTS5."""

    def __init__(
        self,
        db: aiosqlite.Connection,
        vault: VaultReader,
        exclude_dirs: list[str] | None = None,
    ) -> None:
        self._db = db
        self._vault = vault
        self._exclude_dirs = set(exclude_dirs or ["finances", "health"])

    async def index_vault(self) -> int:
        """Scan vault and index all markdown files. Returns count of indexed files."""
        files = self._vault.list_files(pattern="**/*.md")
        indexed = 0

        for file_path in files:
            relative = str(file_path.relative_to(self._vault.vault_dir)).replace("\\", "/")

            # Skip excluded directories
            if any(relative.startswith(f"{d}/") for d in self._exclude_dirs):
                continue

            try:
                doc = self._vault.read(relative)
            except Exception:
                continue

            content_hash = hashlib.md5(doc.raw.encode()).hexdigest()

            # Check if already indexed with same hash
            cursor = await self._db.execute(
                "SELECT content_hash FROM vault_index WHERE path = ?",
                (relative,),
            )
            row = await cursor.fetchone()
            if row and row[0] == content_hash:
                continue

            title = doc.metadata.get("title", file_path.stem)

            # Upsert index record
            await self._db.execute(
                "INSERT OR REPLACE INTO vault_index (path, title, content_hash, indexed_at) "
                "VALUES (?, ?, ?, ?)",
                (relative, title, content_hash, datetime.now(UTC).isoformat()),
            )

            # Upsert FTS record (delete + insert since FTS5 doesn't support REPLACE)
            await self._db.execute(
                "DELETE FROM vault_fts WHERE path = ?", (relative,)
            )
            await self._db.execute(
                "INSERT INTO vault_fts (path, title, content) VALUES (?, ?, ?)",
                (relative, title, doc.content),
            )
            indexed += 1

        await self._db.commit()
        log.debug("Vault indexed: %d files updated", indexed)
        return indexed

    async def search(self, query: str, limit: int = 10) -> list[dict]:
        """Search vault content. Returns matching files with snippets."""
        if not query.strip():
            return []

        # FTS5 query — escape special chars
        safe_query = self._escape_fts_query(query)

        cursor = await self._db.execute(
            "SELECT path, title, snippet(vault_fts, 2, '**', '**', '...', 40) as snippet, "
            "rank FROM vault_fts WHERE vault_fts MATCH ? ORDER BY rank LIMIT ?",
            (safe_query, limit),
        )
        rows = await cursor.fetchall()
        return [
            {
                "path": row[0],
                "title": row[1],
                "snippet": row[2],
                "score": row[3],
            }
            for row in rows
        ]

    async def remove_file(self, path: str) -> None:
        """Remove a file from the search index."""
        await self._db.execute("DELETE FROM vault_fts WHERE path = ?", (path,))
        await self._db.execute("DELETE FROM vault_index WHERE path = ?", (path,))
        await self._db.commit()

    @staticmethod
    def _escape_fts_query(query: str) -> str:
        """Escape FTS5 special characters and build a query."""
        # Split into words and quote each for safety
        words = query.strip().split()
        if not words:
            return '""'
        # Use implicit AND by joining quoted terms
        return " ".join(f'"{w}"' for w in words if w)
