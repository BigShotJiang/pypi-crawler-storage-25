"""Reflection: synthesize journal entries into long-term memory."""

from __future__ import annotations

import logging
from datetime import UTC, datetime

from agntspace.vault.reader import VaultReader
from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)


class ReflectionService:
    """Runs daily and weekly reflection cycles."""

    def __init__(
        self,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        llm: object | None = None,
        memory_engine: object | None = None,
        skill_loader: object | None = None,
        model_router: object | None = None,
    ) -> None:
        self._reader = vault_reader
        self._writer = vault_writer
        self._llm = llm  # kept for backwards compat, no longer used
        self._memory_engine = memory_engine
        self._skill_loader = skill_loader
        self._model_router = model_router
        self._agent: object | None = None  # injected post-hoc from main.py

    async def run_daily_reflection(self, date: str | None = None) -> dict:
        """Run daily reflection on a journal entry.

        Args:
            date: YYYY-MM-DD string. Defaults to today.

        Returns:
            dict with 'date', 'reflection', 'status', 'path'.
        """
        if not date:
            date = datetime.now(UTC).strftime("%Y-%m-%d")

        journal_path = f"journal/{date}.md"
        if not self._reader.exists(journal_path):
            return {"date": date, "reflection": "", "status": "no_journal"}

        journal = self._reader.read(journal_path)
        if len(journal.content.strip()) < 50:
            return {"date": date, "reflection": "", "status": "journal_too_short"}

        # Build context: user journal (primary) + agent observations (supplementary)
        context = f"# User Journal\n\n{journal.content}"
        agent_obs_path = f"journal/agent-observations_{date}.md"
        if self._reader.exists(agent_obs_path):
            agent_obs = self._reader.read(agent_obs_path)
            context += f"\n\n# Agent Observations (supplementary)\n\n{agent_obs.content}"

        # Generate reflection via the main agent
        task_instruction = (
            f"Produce a structured daily reflection for {date}. Include:\n"
            "1. **Summary** — 2-3 sentences on what happened today.\n"
            "2. **Key Decisions** — bullet list of decisions made and their reasoning.\n"
            "3. **Learnings to Remember** — things worth adding to long-term memory.\n"
            "4. **Suggested MEMORY.md Updates** — specific entries (format: 'Add: ...' or 'Update: ...').\n\n"
            "Be concise. Focus on what's worth remembering long-term, not transient details. "
            "Output ONLY the reflection content as markdown."
        )

        reflection_content = await self._agent.process_task(task=task_instruction, context=context)

        # Save reflection (in journal directory alongside other daily files)
        reflection_path = f"journal/daily-reflection_{date}.md"
        full_content = (
            f"---\ntitle: \"Daily Reflection — {date}\"\n"
            f"date: \"{date}\"\ntype: daily_reflection\nauthor: agent\nagent: philosopher\n"
            f"description: \"Agent-synthesized daily reflection — key decisions, learnings, memory suggestions.\"\n"
            f"status: pending\n---\n\n{reflection_content}"
        )
        self._writer.write(reflection_path, full_content)

        log.info("Daily reflection generated for %s", date)
        return {
            "date": date,
            "reflection": reflection_content,
            "status": "pending",
            "path": reflection_path,
        }

    async def run_weekly_reflection(self, week_end: str | None = None) -> dict:
        """Run weekly reflection over the past 7 days of journals.

        Args:
            week_end: YYYY-MM-DD end date. Defaults to today.
        """
        from datetime import timedelta

        if not week_end:
            week_end = datetime.now(UTC).strftime("%Y-%m-%d")

        end_date = datetime.strptime(week_end, "%Y-%m-%d")
        journals = []

        for i in range(7):
            d = end_date - timedelta(days=i)
            date_str = d.strftime("%Y-%m-%d")
            # User journal (primary source)
            path = f"journal/{date_str}.md"
            if self._reader.exists(path):
                doc = self._reader.read(path)
                day_content = f"## {date_str}\n\n{doc.content}"
                # Include agent observations as supplementary
                agent_path = f"journal/agent-observations_{date_str}.md"
                if self._reader.exists(agent_path):
                    agent_doc = self._reader.read(agent_path)
                    day_content += f"\n\n### Agent Observations\n{agent_doc.content}"
                journals.append(day_content)

        if not journals:
            return {"week_end": week_end, "reflection": "", "status": "no_journals"}

        combined = "\n\n---\n\n".join(reversed(journals))

        # Generate weekly reflection via the main agent
        task_instruction = (
            f"Produce a weekly reflection synthesis for the week ending {week_end}. Include:\n"
            "1. **Week Summary** — What was the overall theme/focus this week?\n"
            "2. **Progress** — What moved forward? What stalled?\n"
            "3. **Patterns** — Behavioral patterns observed (positive and concerning).\n"
            "4. **Goal Check** — Any goals that need attention?\n"
            "5. **Learnings** — Key takeaways to carry forward.\n\n"
            "Be concise and actionable. Focus on patterns and progress, not daily details. "
            "Output ONLY the reflection content as markdown."
        )

        response_content = await self._agent.process_task(task=task_instruction, context=combined)

        # Determine ISO week
        week_num = end_date.isocalendar()[1]
        week_label = f"{end_date.year}-W{week_num:02d}"
        reflection_path = f"journal/weekly-reflection_{week_label}.md"

        full_content = (
            f"---\ntitle: \"Weekly Reflection — {week_label}\"\n"
            f"date: \"{end_date.strftime('%Y-%m-%d')}\"\ntype: weekly_reflection\nauthor: agent\nagent: philosopher\n"
            f"description: \"Weekly synthesis — patterns, progress, goal check, and key takeaways.\"\n"
            f"status: pending\n---\n\n{response_content}"
        )
        self._writer.write(reflection_path, full_content)

        # Trigger layered memory compaction — each layer compacts from the one below
        if self._memory_engine and hasattr(self._memory_engine, "compact_memory"):
            try:
                await self._memory_engine.compact_memory()
                log.info("All memory layers compacted during weekly reflection")
            except Exception:
                log.debug("Memory compaction failed during weekly reflection", exc_info=True)

        log.info("Weekly reflection generated for %s", week_label)
        return {
            "week": week_label,
            "reflection": response_content,
            "status": "pending",
            "path": reflection_path,
        }

    async def approve_reflection(self, path: str) -> None:
        """Approve a reflection and apply its MEMORY.md updates."""
        if not self._reader.exists(path):
            raise FileNotFoundError(f"Reflection not found: {path}")

        doc = self._reader.read(path)

        # Update status to approved
        content = doc.raw.replace("status: pending", "status: approved")
        self._writer.write(path, content)

        # Extract suggested MEMORY.md updates and append them
        memory_updates = self._extract_memory_updates(doc.content)
        if memory_updates and self._reader.exists("agnt-memory/MEMORY.md"):
            self._writer.append("agnt-memory/MEMORY.md", "\n" + memory_updates)
            log.info("MEMORY.md updated from reflection: %s", path)

    def list_reflections(self, limit: int = 20) -> list[dict]:
        """List reflection files (checks journal/ and legacy agnt-reflections/)."""
        results = []
        # New location: journal/
        for f in self._reader.list_files("journal", "*reflection*.md"):
            try:
                doc = self._reader.read(f"journal/{f.name}")
                results.append({
                    "path": f"journal/{f.name}",
                    "title": doc.metadata.get("title", f.stem),
                    "status": doc.metadata.get("status", "unknown"),
                })
            except Exception:
                continue
        # Legacy location: agnt-reflections/
        try:
            for f in self._reader.list_files("agnt-reflections", "*.md"):
                try:
                    doc = self._reader.read(f"agnt-reflections/{f.name}")
                    results.append({
                        "path": f"agnt-reflections/{f.name}",
                        "title": doc.metadata.get("title", f.stem),
                        "status": doc.metadata.get("status", "unknown"),
                    })
                except Exception:
                    continue
        except Exception:
            pass  # agnt-reflections/ may not exist
        results.sort(key=lambda x: x["path"], reverse=True)
        return results[:limit]

    @staticmethod
    def _extract_memory_updates(content: str) -> str:
        """Extract suggested MEMORY.md updates from reflection content."""
        lines = []
        in_section = False
        for line in content.split("\n"):
            if "Suggested MEMORY.md" in line or "Memory Updates" in line:
                in_section = True
                continue
            if in_section:
                if line.startswith("##"):
                    break
                if line.strip().startswith("- "):
                    lines.append(line.strip())
        return "\n".join(lines)
