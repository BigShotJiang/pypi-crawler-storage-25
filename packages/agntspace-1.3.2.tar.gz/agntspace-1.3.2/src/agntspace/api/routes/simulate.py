"""Workflow simulation & agent health-check API.

Two modes:
  - health: fast, no LLM — validates agents, skills, tools, contract
  - full: creates test data, runs lightweight dispatches, validates, cleans up
"""

from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

log = logging.getLogger(__name__)

# Maximum log files to keep (rolling)
_MAX_LOG_FILES = 50

router = APIRouter(prefix="/orchestrator/simulate", tags=["simulate"])

# ── Test data for full simulation ──

_TEST_DOC = """---
title: Simulation Test Document
author: system
date: {date}
entity_type: concept
---

# AgntSpace Simulation Test

This is a synthetic document created for workflow simulation.
It contains test entities like **Alice Johnson** (researcher at ACME Corp)
and concepts like machine learning, neural networks, and knowledge graphs.

Alice collaborates with Bob Smith on the Project Phoenix initiative.
The project started in January 2025 and focuses on automated knowledge extraction.

## Key Facts

- Alice Johnson works at ACME Corp
- Bob Smith is a data engineer at ACME Corp
- Project Phoenix uses knowledge graphs for entity resolution
- The deadline for Phase 1 is Q2 2025
"""


class SimulateRequest(BaseModel):
    mode: str = "health"  # "health" or "full"
    workflow_id: str | None = None  # None = all workflows


# ── Health check (fast, no LLM) ──


def _check_agent_health(
    orchestrator: Any,
    agent_key: str,
    required_skills: list[str],
    required_tools: list[str],
) -> dict:
    """Check if an agent is properly configured and ready."""
    result: dict[str, Any] = {
        "agent_key": agent_key,
        "status": "pass",
        "checks": [],
        "issues": [],
    }

    # 1. Agent exists and is active
    agent = orchestrator.agents.get(agent_key)
    if not agent:
        result["status"] = "fail"
        result["issues"].append(f"Agent '{agent_key}' not found in registry")
        result["checks"].append({"check": "agent_exists", "passed": False})
        return result
    result["checks"].append({"check": "agent_exists", "passed": True})

    if agent.status != "active":
        result["status"] = "warn"
        result["issues"].append(f"Agent '{agent_key}' status is '{agent.status}' (not active)")
    result["checks"].append({"check": "agent_active", "passed": agent.status == "active"})

    # 2. Required skills loaded
    agent_skills = set(agent.skills or [])
    for skill in required_skills:
        has_it = skill in agent_skills
        result["checks"].append({"check": f"skill:{skill}", "passed": has_it})
        if not has_it:
            if result["status"] == "pass":
                result["status"] = "warn"
            result["issues"].append(f"Missing skill: {skill}")

    # 3. Tools accessible
    try:
        allowed = set(orchestrator.get_allowed_tools(agent_key))
    except Exception:
        allowed = set()
    for tool in required_tools:
        has_it = tool in allowed
        result["checks"].append({"check": f"tool:{tool}", "passed": has_it})
        if not has_it:
            if result["status"] == "pass":
                result["status"] = "warn"
            result["issues"].append(f"Tool not accessible: {tool}")

    # 4. Agent has personality/capabilities
    has_personality = bool(agent.personality and agent.personality.strip())
    result["checks"].append({"check": "has_personality", "passed": has_personality})
    if not has_personality:
        result["issues"].append("Agent has no personality defined")

    # Final: any issues means at least warn
    if result["issues"] and result["status"] == "pass":
        result["status"] = "warn"

    return result


def _check_workflow_health(
    orchestrator: Any,
    workflow: Any,
    contract: Any | None = None,
) -> dict:
    """Run health checks on all agents in a workflow."""
    wf_result: dict[str, Any] = {
        "workflow_id": workflow.id,
        "workflow_name": workflow.name,
        "supervisor": workflow.supervisor,
        "status": "pass",
        "steps": [],
        "issues": [],
    }

    # Check supervisor exists
    sup = orchestrator.agents.get(workflow.supervisor)
    if not sup:
        wf_result["status"] = "fail"
        wf_result["issues"].append(f"Supervisor '{workflow.supervisor}' not found")
    else:
        wf_result["supervisor_name"] = sup.name

    # Check each step
    for step in workflow.steps:
        step_result = _check_agent_health(
            orchestrator, step.agent_key, step.skills, step.tools,
        )
        step_result["step_id"] = step.id
        step_result["step_label"] = step.label
        wf_result["steps"].append(step_result)

        if step_result["status"] == "fail":
            wf_result["status"] = "fail"
        elif step_result["status"] == "warn" and wf_result["status"] == "pass":
            wf_result["status"] = "warn"

    # Check contract actions
    if contract:
        for action in ["delegate_task", "run_workflow"]:
            try:
                decision = contract.check(action)
                passed = decision != "blocked"
                wf_result["steps"].append({
                    "step_id": f"contract:{action}",
                    "step_label": f"Contract: {action}",
                    "agent_key": "system",
                    "status": "pass" if passed else "fail",
                    "checks": [{"check": f"contract:{action}", "passed": passed}],
                    "issues": [] if passed else [f"Contract blocks action: {action}"],
                })
                if not passed:
                    wf_result["status"] = "fail"
                    wf_result["issues"].append(f"Contract blocks: {action}")
            except Exception:
                pass

    return wf_result


# ── Full simulation (with LLM) ──


async def _run_full_simulation(
    request: Request,
    workflow_id: str | None,
) -> dict:
    """Run a full simulation with test data."""
    orchestrator = request.app.state.orchestrator
    workflow_defs = getattr(request.app.state, "workflow_defs", {})
    vault_writer = getattr(request.app.state, "vault_writer", None)
    vault = getattr(request.app.state, "vault", None)

    workflows_to_test = {}
    if workflow_id:
        wf = workflow_defs.get(workflow_id)
        if not wf:
            return {"error": f"Unknown workflow: {workflow_id}"}
        workflows_to_test[workflow_id] = wf
    else:
        workflows_to_test = workflow_defs

    results: dict[str, Any] = {
        "mode": "full",
        "started_at": datetime.now(UTC).isoformat(),
        "workflows": {},
        "test_data_created": False,
        "test_data_cleaned": False,
    }

    # Create test KB data
    test_kb_path = None
    if vault_writer:
        try:
            test_doc = _TEST_DOC.format(date=datetime.now(UTC).strftime("%Y-%m-%d"))
            vault_writer.write("agnt-kb/_simulation-test/inbox/test-doc.md", test_doc)
            results["test_data_created"] = True
            if vault:
                test_kb_path = vault._vault_dir / "agnt-kb" / "_simulation-test"  # noqa: SLF001
        except Exception as exc:
            log.warning("Failed to create test data: %s", exc)

    # Test each workflow by dispatching a health-check prompt to each agent
    for wf_id, wf in workflows_to_test.items():
        wf_result: dict[str, Any] = {
            "workflow_id": wf_id,
            "workflow_name": wf.name,
            "status": "pass",
            "steps": [],
            "total_duration_ms": 0,
        }

        for step in wf.steps:
            step_start = time.monotonic()
            step_result: dict[str, Any] = {
                "step_id": step.id,
                "step_label": step.label,
                "agent_key": step.agent_key,
                "status": "pass",
                "duration_ms": 0,
                "response_preview": "",
            }

            try:
                # Dispatch a lightweight health-check prompt
                result = await asyncio.wait_for(
                    orchestrator.dispatch(
                        agent_name=step.agent_key,
                        task=(
                            f"SIMULATION HEALTH CHECK — respond with a single sentence confirming "
                            f"you are ready to perform: {step.label}. "
                            f"Include the word 'READY' in your response."
                        ),
                        context="This is a system health check. Respond briefly.",
                    ),
                    timeout=30.0,
                )
                step_result["duration_ms"] = int((time.monotonic() - step_start) * 1000)
                step_result["response_preview"] = (result.content or "")[:200]

                # Check the agent actually responded sensibly
                if not result.content or len(result.content.strip()) < 5:
                    step_result["status"] = "warn"
                    step_result["issue"] = "Agent returned empty/minimal response"
                else:
                    step_result["status"] = "pass"

            except asyncio.TimeoutError:
                step_result["status"] = "fail"
                step_result["issue"] = "Agent timed out (30s)"
                step_result["duration_ms"] = 30000
            except Exception as exc:
                step_result["status"] = "fail"
                step_result["issue"] = str(exc)[:200]
                step_result["duration_ms"] = int((time.monotonic() - step_start) * 1000)

            wf_result["steps"].append(step_result)
            wf_result["total_duration_ms"] += step_result["duration_ms"]

            if step_result["status"] == "fail":
                wf_result["status"] = "fail"
            elif step_result["status"] == "warn" and wf_result["status"] == "pass":
                wf_result["status"] = "warn"

        results["workflows"][wf_id] = wf_result

    # Clean up test data
    if test_kb_path and test_kb_path.exists():
        try:
            import shutil
            shutil.rmtree(test_kb_path)
            results["test_data_cleaned"] = True
        except Exception as exc:
            log.warning("Failed to clean test data: %s", exc)
            results["test_data_cleaned"] = False

    results["completed_at"] = datetime.now(UTC).isoformat()
    return results


# ── Log persistence ──


def _get_logs_dir(request: Request) -> Path | None:
    """Get the simulation logs directory in agnt-system/logs/simulation/."""
    vault = getattr(request.app.state, "vault", None)
    if not vault:
        return None
    vault_dir = getattr(vault, "_vault_dir", None)
    if not vault_dir:
        return None
    logs_dir = Path(vault_dir) / "agnt-system" / "logs" / "simulation"
    logs_dir.mkdir(parents=True, exist_ok=True)
    return logs_dir


def _build_md_report(results: dict) -> str:
    """Build a human-readable markdown report from simulation results."""
    mode = results.get("mode", "unknown")
    ts = results.get("timestamp") or results.get("started_at") or ""
    overall = results.get("overall_status", "unknown")
    summary = results.get("summary")

    lines = [
        "---",
        f"title: {'Health Check' if mode == 'health' else 'Full Simulation'} Report",
        f"date: {ts[:10] if ts else ''}",
        f"mode: {mode}",
        f"status: {overall}",
        "author: agent",
        "agent: healer",
        "---",
        "",
        f"# {'Health Check' if mode == 'health' else 'Full Simulation'} Report",
        "",
        f"**Status:** {overall.upper()}  ",
        f"**Time:** {ts}  ",
    ]

    if summary:
        lines.append(f"**Checks:** {summary.get('passed', 0)}/{summary.get('total_checks', 0)} passed, "
                      f"{summary.get('failures', 0)} failures  ")
    lines.append("")

    for wf_id, wf in results.get("workflows", {}).items():
        wf_name = wf.get("workflow_name", wf_id)
        wf_status = wf.get("status", "unknown")
        steps = wf.get("steps", [])
        passed = sum(1 for s in steps if s.get("status") == "pass")
        dur = wf.get("total_duration_ms")

        lines.append(f"## {wf_name}")
        lines.append("")
        dur_str = f" ({dur}ms)" if dur else ""
        lines.append(f"**Status:** {wf_status.upper()} — {passed}/{len(steps)} steps passed{dur_str}  ")
        lines.append("")

        for s in steps:
            label = s.get("step_label") or s.get("label") or ""
            agent = s.get("agent_key", "")
            status = s.get("status", "")
            icon = "✅" if status == "pass" else "⚠️" if status == "warn" else "❌"
            step_dur = s.get("duration_ms")
            dur_part = f" ({step_dur}ms)" if step_dur else ""

            lines.append(f"- {icon} **{label}** — {agent}{dur_part}")

            # Issues
            for iss in s.get("issues", []):
                lines.append(f"  - {iss}")
            if s.get("issue"):
                lines.append(f"  - {s['issue']}")

            # Checks detail (health mode)
            checks = s.get("checks", [])
            if checks:
                failed_checks = [c for c in checks if not c.get("passed")]
                if failed_checks:
                    for c in failed_checks:
                        lines.append(f"  - ❌ `{c['check']}`")

        lines.append("")

    return "\n".join(lines)


def _persist_log(request: Request, results: dict) -> str | None:
    """Write simulation results as JSON + MD report. Returns JSON filename."""
    logs_dir = _get_logs_dir(request)
    if not logs_dir:
        return None

    try:
        mode = results.get("mode", "unknown")
        ts = datetime.now(UTC).strftime("%Y-%m-%d_%H%M%S")
        workflow_id = ""
        wf_keys = list(results.get("workflows", {}).keys())
        if len(wf_keys) == 1:
            workflow_id = f"_{wf_keys[0]}"

        base_name = f"{ts}_{mode}{workflow_id}"

        # Save JSON (machine-readable)
        json_path = logs_dir / f"{base_name}.json"
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(results, f, indent=2, default=str)

        # Save MD (human-readable, Obsidian-compatible)
        md_path = logs_dir / f"{base_name}.md"
        with open(md_path, "w", encoding="utf-8") as f:
            f.write(_build_md_report(results))

        # Rolling cleanup — keep only the most recent logs
        all_logs = sorted(logs_dir.glob("*.json"), key=lambda p: p.stat().st_mtime)
        if len(all_logs) > _MAX_LOG_FILES:
            for old in all_logs[: len(all_logs) - _MAX_LOG_FILES]:
                old.unlink(missing_ok=True)
                # Also remove matching .md
                md_pair = old.with_suffix(".md")
                if md_pair.exists():
                    md_pair.unlink(missing_ok=True)

        log.info("Simulation log saved: %s (.json + .md)", base_name)
        return f"{base_name}.json"
    except Exception as exc:
        log.warning("Failed to save simulation log: %s", exc)
        return None


# ── API Endpoints ──


@router.post("")
async def simulate_workflows(request: Request, body: SimulateRequest) -> dict:
    """Run workflow simulation / health check.

    Modes:
      - health: fast validation (no LLM calls) — checks agents, skills, tools, contract
      - full: dispatches a health-check prompt to each agent (uses LLM tokens)

    Results are persisted to agnt-system/logs/simulation/ for historical tracking.
    """
    orchestrator = request.app.state.orchestrator
    workflow_defs = getattr(request.app.state, "workflow_defs", {})
    contract = getattr(request.app.state, "contract", None)

    if body.mode == "health":
        # Fast health check — no LLM
        workflows_to_check = {}
        if body.workflow_id:
            wf = workflow_defs.get(body.workflow_id)
            if not wf:
                raise HTTPException(status_code=404, detail=f"Unknown workflow: {body.workflow_id}")
            workflows_to_check[body.workflow_id] = wf
        else:
            workflows_to_check = workflow_defs

        results: dict[str, Any] = {
            "mode": "health",
            "timestamp": datetime.now(UTC).isoformat(),
            "overall_status": "pass",
            "workflows": {},
            "summary": {"total_checks": 0, "passed": 0, "warnings": 0, "failures": 0},
        }

        for wf_id, wf in workflows_to_check.items():
            wf_result = _check_workflow_health(orchestrator, wf, contract)
            results["workflows"][wf_id] = wf_result

            # Aggregate counts
            for step in wf_result["steps"]:
                for check in step.get("checks", []):
                    results["summary"]["total_checks"] += 1
                    if check["passed"]:
                        results["summary"]["passed"] += 1
                    else:
                        results["summary"]["failures"] += 1

            if wf_result["status"] == "fail":
                results["overall_status"] = "fail"
            elif wf_result["status"] == "warn" and results["overall_status"] == "pass":
                results["overall_status"] = "warn"

        # Persist log
        log_file = _persist_log(request, results)
        if log_file:
            results["log_file"] = log_file

        return results

    elif body.mode == "full":
        # Full simulation — uses LLM
        results = await _run_full_simulation(request, body.workflow_id)

        # Persist log
        log_file = _persist_log(request, results)
        if log_file:
            results["log_file"] = log_file

        return results

    else:
        raise HTTPException(status_code=400, detail=f"Unknown mode: {body.mode}. Use 'health' or 'full'.")


@router.get("/status")
async def simulation_status(request: Request) -> dict:
    """Get agent readiness overview (quick health summary)."""
    orchestrator = request.app.state.orchestrator
    workflow_defs = getattr(request.app.state, "workflow_defs", {})

    agents = orchestrator.agents
    total_agents = len(agents)
    active_agents = sum(1 for a in agents.values() if a.status == "active")
    total_workflows = len(workflow_defs)

    # Quick check: do all workflow agents exist?
    missing_agents = set()
    for wf in workflow_defs.values():
        if wf.supervisor not in agents:
            missing_agents.add(wf.supervisor)
        for step in wf.steps:
            if step.agent_key not in agents:
                missing_agents.add(step.agent_key)

    return {
        "total_agents": total_agents,
        "active_agents": active_agents,
        "total_workflows": total_workflows,
        "missing_agents": sorted(missing_agents),
        "ready": len(missing_agents) == 0 and active_agents > 0,
    }


@router.get("/logs")
async def list_simulation_logs(request: Request, limit: int = 20) -> list[dict]:
    """List recent simulation log files with full detail (newest first)."""
    logs_dir = _get_logs_dir(request)
    if not logs_dir or not logs_dir.exists():
        return []

    all_logs = sorted(logs_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    entries = []
    for lf in all_logs[:limit]:
        try:
            with open(lf, encoding="utf-8") as f:
                data = json.load(f)
            entries.append({
                "filename": lf.name,
                "mode": data.get("mode"),
                "timestamp": data.get("timestamp") or data.get("started_at"),
                "overall_status": data.get("overall_status"),
                "summary": data.get("summary"),
                "workflows": data.get("workflows", {}),
            })
        except Exception:
            entries.append({"filename": lf.name, "error": "Failed to parse"})

    return entries


@router.get("/logs/{filename}")
async def get_simulation_log(request: Request, filename: str) -> dict:
    """Get a specific simulation log file (full detail)."""
    logs_dir = _get_logs_dir(request)
    if not logs_dir:
        raise HTTPException(status_code=404, detail="Logs directory not found")

    # Sanitize filename to prevent path traversal
    safe_name = Path(filename).name
    if not safe_name.endswith(".json"):
        raise HTTPException(status_code=400, detail="Invalid log filename")

    filepath = logs_dir / safe_name
    if not filepath.is_file():
        raise HTTPException(status_code=404, detail=f"Log not found: {safe_name}")

    try:
        with open(filepath, encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Failed to read log: {exc}") from exc


@router.delete("/logs/{filename}")
async def delete_simulation_log(request: Request, filename: str) -> dict:
    """Delete a specific simulation log file."""
    logs_dir = _get_logs_dir(request)
    if not logs_dir:
        raise HTTPException(status_code=404, detail="Logs directory not found")

    safe_name = Path(filename).name
    filepath = logs_dir / safe_name
    if not filepath.is_file():
        raise HTTPException(status_code=404, detail=f"Log not found: {safe_name}")

    filepath.unlink()
    # Also delete the matching .md report if it exists
    md_pair = filepath.with_suffix(".md")
    if md_pair.is_file():
        md_pair.unlink()
    return {"status": "deleted", "filename": safe_name}


# ── Heal proposals (user approval gate) ──


def _get_proposals_path(request: Request) -> Path | None:
    logs_dir = _get_logs_dir(request)
    if not logs_dir:
        return None
    return logs_dir / "heal-proposals.json"


@router.get("/proposals")
async def list_proposals(request: Request) -> list[dict]:
    """List pending heal proposals for user approval."""
    path = _get_proposals_path(request)
    if not path or not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return [p for p in data if p.get("status") == "pending"]
    except Exception:
        return []


class ApproveRequest(BaseModel):
    agent_key: str
    skill: str


@router.post("/proposals/approve")
async def approve_proposal(request: Request, body: ApproveRequest) -> dict:
    """Approve a heal proposal — adds the skill to the agent."""
    path = _get_proposals_path(request)
    if not path or not path.exists():
        raise HTTPException(status_code=404, detail="No proposals found")

    proposals = json.loads(path.read_text(encoding="utf-8"))

    # Find the matching proposal
    found = None
    for p in proposals:
        if p["agent_key"] == body.agent_key and p["skill"] == body.skill and p.get("status") == "pending":
            found = p
            break
    if not found:
        raise HTTPException(status_code=404, detail="Proposal not found or already processed")

    # Apply the change
    orchestrator = request.app.state.orchestrator
    writer = request.app.state.vault_writer
    agent_def = orchestrator.agents.get(body.agent_key)
    if not agent_def:
        raise HTTPException(status_code=404, detail=f"Agent not found: {body.agent_key}")

    if body.skill not in (agent_def.skills or []):
        agent_def.skills.append(body.skill)

        # Rebuild agent file
        agent_path = f"agnt-system/agents/{body.agent_key}.md"
        vault = request.app.state.vault
        vault_dir = getattr(vault, "_vault_dir", None)
        if vault_dir:
            full_path = Path(vault_dir) / agent_path
            if full_path.exists():
                content = full_path.read_text(encoding="utf-8")
                # Insert skill into YAML frontmatter skills list
                if f"  - {body.skill}" not in content:
                    content = content.replace(
                        f"access: {agent_def.access}",
                        f"  - {body.skill}\naccess: {agent_def.access}",
                    )
                    writer.write(agent_path, content)

        orchestrator.load_agents()

    # Mark proposal as approved
    found["status"] = "approved"
    path.write_text(json.dumps(proposals, indent=2), encoding="utf-8")

    # Sync: also update skills-review/ file
    _sync_skills_review(request, body.agent_key, body.skill, "approved")

    return {"status": "approved", "agent": body.agent_key, "skill": body.skill}


@router.post("/proposals/reject")
async def reject_proposal(request: Request, body: ApproveRequest) -> dict:
    """Reject a heal proposal."""
    path = _get_proposals_path(request)
    if not path or not path.exists():
        raise HTTPException(status_code=404, detail="No proposals found")

    proposals = json.loads(path.read_text(encoding="utf-8"))
    found = None
    for p in proposals:
        if p["agent_key"] == body.agent_key and p["skill"] == body.skill and p.get("status") == "pending":
            found = p
            break
    if not found:
        raise HTTPException(status_code=404, detail="Proposal not found or already processed")

    found["status"] = "rejected"
    path.write_text(json.dumps(proposals, indent=2), encoding="utf-8")

    # Sync: also update skills-review/ file
    _sync_skills_review(request, body.agent_key, body.skill, "rejected")

    return {"status": "rejected", "agent": body.agent_key, "skill": body.skill}


def _sync_skills_review(request: Request, agent_key: str, skill: str, new_status: str) -> None:
    """Sync heal proposal status to skills-review/ file (for Skills page)."""
    vault = getattr(request.app.state, "vault", None)
    if not vault:
        return
    vault_dir = getattr(vault, "_vault_dir", None)
    if not vault_dir:
        return

    slug = f"heal-{agent_key}-{skill}"
    review_path = Path(vault_dir) / "skills-review" / f"{slug}.md"
    if not review_path.exists():
        return

    try:
        content = review_path.read_text(encoding="utf-8")
        content = content.replace("status: pending_review", f"status: {new_status}")
        review_path.write_text(content, encoding="utf-8")
    except Exception:
        pass


class SkillApproveRequest(BaseModel):
    skill: str


@router.post("/proposals/approve-skill")
async def approve_skill_draft(request: Request, body: SkillApproveRequest) -> dict:
    """Approve a drafted skill — moves from pending/ to custom/, sets status active, reloads skills."""
    vault = request.app.state.vault
    vault_dir = getattr(vault, "_vault_dir", None)
    if not vault_dir:
        raise HTTPException(status_code=500, detail="Vault not found")

    pending_dir = Path(vault_dir) / "agnt-system" / "skills" / "pending" / body.skill
    if not pending_dir.exists():
        raise HTTPException(status_code=404, detail=f"No draft found for skill: {body.skill}")

    # Move to custom/
    target_dir = Path(vault_dir) / "agnt-system" / "skills" / "custom" / body.skill
    target_dir.mkdir(parents=True, exist_ok=True)

    import shutil
    for f in pending_dir.iterdir():
        content = f.read_text(encoding="utf-8")
        # Activate the skill
        content = content.replace("status: draft", "status: active")
        content = content.replace("category: custom", "category: custom")
        (target_dir / f.name).write_text(content, encoding="utf-8")

    # Clean up pending
    shutil.rmtree(pending_dir)

    # Update proposal status
    path = _get_proposals_path(request)
    if path and path.exists():
        proposals = json.loads(path.read_text(encoding="utf-8"))
        for p in proposals:
            if p.get("skill") == body.skill and p.get("type") == "create_skill" and p.get("status") == "pending":
                p["status"] = "approved"
        path.write_text(json.dumps(proposals, indent=2), encoding="utf-8")

    # Reload skills
    skill_loader = getattr(request.app.state, "skills", None)
    if skill_loader:
        skill_loader.load_all()

    return {"status": "approved", "skill": body.skill, "location": f"agnt-system/skills/custom/{body.skill}"}


@router.post("/proposals/reject-skill")
async def reject_skill_draft(request: Request, body: SkillApproveRequest) -> dict:
    """Reject a drafted skill — removes the pending draft."""
    vault = request.app.state.vault
    vault_dir = getattr(vault, "_vault_dir", None)
    if not vault_dir:
        raise HTTPException(status_code=500, detail="Vault not found")

    pending_dir = Path(vault_dir) / "agnt-system" / "skills" / "pending" / body.skill
    if pending_dir.exists():
        import shutil
        shutil.rmtree(pending_dir)

    # Update proposal status
    path = _get_proposals_path(request)
    if path and path.exists():
        proposals = json.loads(path.read_text(encoding="utf-8"))
        for p in proposals:
            if p.get("skill") == body.skill and p.get("type") == "create_skill" and p.get("status") == "pending":
                p["status"] = "rejected"
        path.write_text(json.dumps(proposals, indent=2), encoding="utf-8")

    return {"status": "rejected", "skill": body.skill}
