"""Subagent orchestration API endpoints."""

from __future__ import annotations

import re

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

router = APIRouter(prefix="/orchestrator", tags=["orchestrator"])


class DispatchRequest(BaseModel):
    agent_name: str
    task: str
    context: str = ""


class AgentSaveRequest(BaseModel):
    name: str
    role: str
    personality: str = ""
    capabilities: str = ""
    boundaries: str = ""
    skills: list[str] = []
    access: str = "read-only"
    status: str = "active"


# ── List / detail ──


@router.get("/agents")
async def list_agents(request: Request) -> list[dict]:
    """List all available subagents."""
    orchestrator = request.app.state.orchestrator
    return orchestrator.list_agents()


@router.get("/agents/{key}")
async def get_agent(request: Request, key: str) -> dict:
    """Get a single subagent's details."""
    orchestrator = request.app.state.orchestrator
    agents = orchestrator.agents
    agent_def = agents.get(key)
    if not agent_def:
        raise HTTPException(status_code=404, detail=f"Subagent not found: {key}")
    return {
        "key": key,
        "name": agent_def.name,
        "role": agent_def.role,
        "personality": agent_def.personality,
        "capabilities": agent_def.capabilities,
        "boundaries": agent_def.boundaries,
        "skills": agent_def.skills,
        "access": agent_def.access,
        "status": agent_def.status,
        "allowed_tools": agent_def.allowed_tools,
        "effective_tools": sorted(orchestrator.get_allowed_tools(key)),
    }


# ── Create / update / delete ──


@router.put("/agents/{key}")
async def save_agent(request: Request, key: str, body: AgentSaveRequest) -> dict:
    """Update an existing subagent definition (writes back to vault .md file)."""
    writer = request.app.state.vault_writer
    orchestrator = request.app.state.orchestrator

    content = _build_agent_md(body)
    writer.write(f"agnt-system/agents/{key}.md", content)
    orchestrator.load_agents()
    return {"status": "updated", "key": key}


@router.post("/agents")
async def create_agent(request: Request, body: AgentSaveRequest) -> dict:
    """Create a new subagent definition."""
    writer = request.app.state.vault_writer
    orchestrator = request.app.state.orchestrator

    key = re.sub(r"[^a-z0-9-]", "", body.name.lower().replace(" ", "-"))[:60]
    if not key:
        raise HTTPException(status_code=400, detail="Invalid agent name")
    if key in orchestrator.agents:
        raise HTTPException(status_code=409, detail=f"Agent '{key}' already exists")

    content = _build_agent_md(body)
    writer.write(f"agnt-system/agents/{key}.md", content)
    orchestrator.load_agents()
    return {"status": "created", "key": key}


@router.delete("/agents/{key}")
async def delete_agent(request: Request, key: str) -> dict:
    """Delete a subagent definition."""
    orchestrator = request.app.state.orchestrator
    if key not in orchestrator.agents:
        raise HTTPException(status_code=404, detail=f"Subagent not found: {key}")

    vault = request.app.state.vault
    agent_path = vault._vault_dir / "agnt-system" / "agents" / f"{key}.md"  # noqa: SLF001
    if agent_path.is_file():
        agent_path.unlink()
    orchestrator.load_agents()
    return {"status": "deleted", "key": key}


# ── Dispatch / reload ──


@router.post("/dispatch")
async def dispatch_task(request: Request, body: DispatchRequest) -> dict:
    """Dispatch a task to a specific subagent."""
    orchestrator = request.app.state.orchestrator
    try:
        result = await orchestrator.dispatch(
            agent_name=body.agent_name,
            task=body.task,
            context=body.context,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return {
        "agent_name": result.agent_name,
        "content": result.content,
        "input_tokens": result.input_tokens,
        "output_tokens": result.output_tokens,
    }


@router.post("/reload")
async def reload_agents(request: Request) -> dict:
    """Reload subagent definitions from vault."""
    orchestrator = request.app.state.orchestrator
    agents = orchestrator.load_agents()
    return {"reloaded": len(agents), "agents": list(agents.keys())}


# ── Available skills (for the editor's skill picker) ──


@router.get("/available-skills")
async def list_available_skills(request: Request) -> list[dict]:
    """List all skills that can be assigned to subagents."""
    skills = request.app.state.skills
    return [
        {
            "name": s.name,
            "title": s.title,
            "description": s.description,
            "category": s.category,
            "triggers": s.triggers,
        }
        for s in skills.skills.values()
        if s.status == "active"
    ]


# ── Visualization data ──


@router.get("/stats")
async def get_agent_stats(request: Request) -> list[dict]:
    """Per-agent dispatch statistics for visualization."""
    orchestrator = request.app.state.orchestrator
    return await orchestrator.get_agent_stats()


@router.get("/dispatch-log")
async def get_dispatch_log(
    request: Request, limit: int = 50, agent: str | None = None,
) -> list[dict]:
    """Recent dispatch history."""
    orchestrator = request.app.state.orchestrator
    return await orchestrator.get_dispatch_log(limit=limit, agent_key=agent)


@router.get("/active")
async def get_active_dispatches(request: Request) -> dict:
    """Currently running dispatches."""
    orchestrator = request.app.state.orchestrator
    return orchestrator.get_active_dispatches()


# ── Helpers ──


def _build_agent_md(body: AgentSaveRequest) -> str:
    """Build the markdown file content for a subagent definition."""
    skills_yaml = "\n".join(f"  - {s}" for s in body.skills) if body.skills else ""
    skills_block = f"skills:\n{skills_yaml}" if skills_yaml else "skills: []"

    sections = []
    if body.personality.strip():
        sections.append(f"## Personality\n\n{body.personality.strip()}")
    if body.capabilities.strip():
        sections.append(f"## Capabilities\n\n{body.capabilities.strip()}")
    if body.boundaries.strip():
        sections.append(f"## Boundaries\n\n{body.boundaries.strip()}")

    body_text = "\n\n".join(sections)

    return f"""---
title: {body.name}
role: {body.role}
status: {body.status}
{skills_block}
access: {body.access}
---

{body_text}
"""


# ── Workflow execution (supervisor-driven) ──


class WorkflowRunRequest(BaseModel):
    context: str = ""


@router.post("/workflow/{workflow_id}")
async def run_workflow(request: Request, workflow_id: str, body: WorkflowRunRequest | None = None) -> dict:
    """Execute a workflow through the supervisor.

    The supervisor adaptively decides step order, feedback loops, parallelism,
    and skips based on results from each step.
    """
    supervisor = getattr(request.app.state, "supervisor", None)
    if not supervisor:
        raise HTTPException(status_code=503, detail="Workflow supervisor not initialized")

    # Resolve workflow definition from UI-registered workflows
    workflow_defs = getattr(request.app.state, "workflow_defs", {})
    workflow = workflow_defs.get(workflow_id)
    if not workflow:
        raise HTTPException(status_code=404, detail=f"Unknown workflow: {workflow_id}")

    context = body.context if body else ""

    execution = await supervisor.execute(workflow, context=context)

    return {
        "workflow_id": execution.workflow_id,
        "status": execution.status,
        "total_iterations": execution.total_iterations,
        "steps_executed": len(execution.step_results),
        "results": [
            {
                "step_id": r.step_id,
                "agent": r.agent_key,
                "content": r.content[:500],
                "tokens": r.input_tokens + r.output_tokens,
                "duration_ms": r.duration_ms,
                "iteration": r.iteration,
            }
            for r in execution.step_results
        ],
        "supervisor_log": execution.supervisor_log,
    }


@router.get("/workflows")
async def list_workflows(request: Request) -> list[dict]:
    """List available workflow definitions."""
    workflow_defs = getattr(request.app.state, "workflow_defs", {})
    return [
        {
            "id": w.id,
            "name": w.name,
            "description": w.description,
            "supervisor": w.supervisor,
            "steps": [
                {"id": s.id, "agent_key": s.agent_key, "label": s.label}
                for s in w.steps
            ],
        }
        for w in workflow_defs.values()
    ]
