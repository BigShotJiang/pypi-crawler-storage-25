"""Settings API: read/write config, manage credentials, factory reset."""

from __future__ import annotations

import logging

import httpx
from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(prefix="/settings", tags=["settings"])


class UpdateSectionRequest(BaseModel):
    values: dict


class LocaleRequest(BaseModel):
    locale: str


class CredentialRequest(BaseModel):
    service: str
    credentials: dict


# ---- Config ----


@router.get("")
async def get_settings(request: Request) -> dict:
    """Get all settings from config.toml."""
    svc = request.app.state.settings_service
    return svc.get_all()


@router.get("/locale")
async def get_locale() -> dict:
    """Get current backend locale."""
    from agntspace.infra.i18n import _CURRENT_LOCALE
    return {"locale": _CURRENT_LOCALE}


@router.put("/locale")
async def set_locale_endpoint(body: LocaleRequest) -> dict:
    """Set backend locale."""
    from agntspace.infra import i18n
    i18n.set_locale(body.locale)
    return {"locale": body.locale}


@router.get("/{section}")
async def get_section(request: Request, section: str) -> dict:
    """Get a config section."""
    svc = request.app.state.settings_service
    return svc.get_section(section)


@router.put("/{section}")
async def update_section(request: Request, section: str, body: UpdateSectionRequest) -> dict:
    """Update a config section."""
    svc = request.app.state.settings_service
    return svc.update_section(section, body.values)


# ---- Health & Reset ----


class ResetRequest(BaseModel):
    categories: list[str] | None = None


class ResetFileRequest(BaseModel):
    path: str


@router.get("/health")
async def vault_health(request: Request) -> dict:
    """Validate system files and return per-file health status."""
    from agntspace.setup.init import validate_vault

    settings = request.app.state.settings
    try:
        return validate_vault(settings.root_dir)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/migrate-frontmatter")
async def migrate_frontmatter(request: Request) -> dict:
    """Backfill date: and agent: fields on existing vault files."""
    from agntspace.vault.migrate_frontmatter import migrate_vault

    settings = request.app.state.settings
    result = migrate_vault(settings.vault_dir)
    return result


@router.post("/reset")
async def factory_reset(request: Request, body: ResetRequest | None = None) -> dict:
    """Reset system files to factory defaults.

    Body: { "categories": ["identity", "memory", "agents", "skills", "security"] }
    Omit categories to reset all. User content is always preserved.
    """
    from agntspace.setup.init import reset_vault

    settings = request.app.state.settings
    categories = body.categories if body else None
    try:
        result = reset_vault(settings.root_dir, categories=categories)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    # Re-initialize agent with fresh files
    agent = getattr(request.app.state, "agent", None)
    if agent:
        await agent.initialize()
        log.info("Agent re-initialized after reset (%s)", result.get("categories"))

    return result


@router.post("/reset-file")
async def reset_single_file(request: Request, body: ResetFileRequest) -> dict:
    """Reset a single system file to its factory default."""
    from agntspace.setup.init import reset_file

    settings = request.app.state.settings
    try:
        result = reset_file(settings.root_dir, body.path)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc

    # Re-initialize agent
    agent = getattr(request.app.state, "agent", None)
    if agent:
        await agent.initialize()

    return result


# ---- Ollama ----

OLLAMA_BASE = "http://localhost:11434"


@router.get("/ollama/models")
async def list_ollama_models() -> dict:
    """List locally available Ollama models."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{OLLAMA_BASE}/api/tags")
            resp.raise_for_status()
            data = resp.json()
            models = [m["name"] for m in data.get("models", [])]
            return {"online": True, "models": sorted(models)}
    except Exception:
        return {"online": False, "models": []}


@router.post("/ollama/test/{model}")
async def test_ollama_model(model: str) -> StreamingResponse:
    """Interactive health check: stream a short response from the model."""

    prompt = (
        "You are being tested by a user who just installed you. "
        "Say hi, introduce yourself in one SHORT sentence (who you are, what you're good at), "
        "then confirm you're working. Be friendly and a little playful. Keep it under 30 words total."
    )

    async def _stream():
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(60, connect=10)) as client:
                async with client.stream(
                    "POST",
                    f"{OLLAMA_BASE}/api/generate",
                    json={"model": model, "prompt": prompt, "stream": True,
                          "options": {"num_predict": 60}},
                ) as resp:
                    async for line in resp.aiter_lines():
                        if line.strip():
                            yield line + "\n"
        except Exception as exc:
            import json as _json
            yield _json.dumps({"error": str(exc)[:200]}) + "\n"

    return StreamingResponse(_stream(), media_type="application/x-ndjson")


class OllamaPullRequest(BaseModel):
    name: str


@router.post("/ollama/pull")
async def pull_ollama_model(body: OllamaPullRequest) -> StreamingResponse:
    """Pull a model from the Ollama library. Streams progress as JSON lines."""

    async def _stream():
        async with httpx.AsyncClient(timeout=httpx.Timeout(600, connect=10)) as client:
            async with client.stream(
                "POST",
                f"{OLLAMA_BASE}/api/pull",
                json={"name": body.name, "stream": True},
            ) as resp:
                async for line in resp.aiter_lines():
                    if line.strip():
                        yield line + "\n"

    return StreamingResponse(_stream(), media_type="application/x-ndjson")


@router.delete("/ollama/models/{model}")
async def delete_ollama_model(model: str) -> dict:
    """Delete an Ollama model."""
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.request(
                "DELETE",
                f"{OLLAMA_BASE}/api/delete",
                json={"name": model},
            )
            resp.raise_for_status()
            return {"ok": True}
    except Exception as exc:
        return {"ok": False, "error": str(exc)[:200]}


# ---- Credentials ----


@router.get("/credentials/list")
async def list_credentials(request: Request) -> list[str]:
    """List services with stored credentials."""
    creds = request.app.state.credential_store
    return creds.list_services()


@router.post("/credentials/save")
async def save_credentials(request: Request, body: CredentialRequest) -> dict:
    """Save credentials for a service."""
    creds = request.app.state.credential_store
    creds.set(body.service, body.credentials)
    return {"saved": True, "service": body.service}


@router.delete("/credentials/{service}")
async def delete_credentials(request: Request, service: str) -> dict:
    """Delete credentials for a service."""
    creds = request.app.state.credential_store
    creds.delete(service)
    return {"deleted": True, "service": service}


