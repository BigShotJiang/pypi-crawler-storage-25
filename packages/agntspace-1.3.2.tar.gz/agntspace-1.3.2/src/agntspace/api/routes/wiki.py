"""Personal Wiki API — unified access to all knowledge bases.

Unified view across all KBs: articles, people, categories, search, recent changes.
The wiki is maintained by the agent — user reads, agent writes.
"""

from __future__ import annotations

import logging
import re
from datetime import UTC, datetime
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

log = logging.getLogger(__name__)

router = APIRouter(prefix="/wiki", tags=["wiki"])

# In-memory article cache (avoids re-reading 700+ files on every request)
_article_cache: dict = {"articles": [], "built_at": 0.0, "ttl": 60.0, "rebuilding": False}


def _build_article_list(vault) -> list[dict]:
    """Read all wiki files and build the article list. CPU-bound, runs in thread."""
    import os

    articles = []
    for f in _list_wiki_files(vault):
        result = _read_article_safe(vault, f)
        if not result:
            continue
        rel, meta, content = result
        content_text = content.strip()
        excerpt = content_text[:200].split("\n\n")[0] if content_text else ""
        raw_links = re.findall(r"\[\[([^\]]+)\]\]", content_text)
        links = [lnk.split("|")[0].strip() for lnk in raw_links]

        try:
            mtime = os.path.getmtime(f)
        except OSError:
            mtime = 0.0

        articles.append({
            "slug": meta.get("slug") or re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-"),
            "title": meta.get("title", f.stem),
            "category": meta.get("category", ""),
            "taxonomy_path": meta.get("taxonomy_path", ""),
            "entity_type": meta.get("entity_type", ""),
            "status": meta.get("status", ""),
            "excerpt": excerpt,
            "links": links[:10],
            "sources": meta.get("sources", []),
            "path": rel,
            "kb": _extract_kb_slug(rel),
            "mtime": mtime,
        })

    articles.sort(key=lambda a: a["title"])
    return articles


def _get_cached_articles(vault) -> list[dict]:
    """Return cached article list. Stale cache triggers background rebuild — never blocks."""
    import threading  # noqa: PLC0415
    import time  # noqa: PLC0415

    now = time.time()
    if _article_cache["articles"] and (now - _article_cache["built_at"]) < _article_cache["ttl"]:
        return _article_cache["articles"]

    # Stale — if we have old data, return it and rebuild in background
    if _article_cache["articles"] and not _article_cache["rebuilding"]:
        _article_cache["rebuilding"] = True

        def _rebuild():
            try:
                articles = _build_article_list(vault)
                _article_cache["articles"] = articles
                _article_cache["built_at"] = time.time()
            finally:
                _article_cache["rebuilding"] = False

        threading.Thread(target=_rebuild, daemon=True).start()
        return _article_cache["articles"]  # return stale while rebuilding

    # No cached data — rebuild synchronously so the caller gets fresh results
    articles = _build_article_list(vault)
    _article_cache["articles"] = articles
    _article_cache["built_at"] = time.time()
    return articles


def warm_article_cache(vault) -> None:
    """Pre-warm the article cache at server startup. Call from lifespan."""
    import threading
    import time

    def _warm():
        articles = _build_article_list(vault)
        _article_cache["articles"] = articles
        _article_cache["built_at"] = time.time()
        log.debug("Wiki article cache warmed: %d articles", len(articles))

    threading.Thread(target=_warm, daemon=True).start()


def invalidate_article_cache():
    """Call after any write operation that changes wiki articles.

    Clears cached articles so the next request rebuilds synchronously
    instead of returning stale data.
    """
    _article_cache["built_at"] = 0.0
    _article_cache["articles"] = []


@router.get("/taxonomy")
async def get_taxonomy(request: Request) -> dict:
    """Return the knowledge taxonomy tree annotated with article counts."""
    from agntspace.kb.taxonomy import (
        build_taxonomy_tree_with_counts,
        classify_article,
        flatten_taxonomy,
        load_taxonomy,
    )

    skills_dir: Path | None = getattr(request.app.state, "skills_dir", None)
    if not skills_dir:
        return {"tree": [], "flat": []}

    tree = load_taxonomy(skills_dir)
    flat_nodes = flatten_taxonomy(tree)

    vault = request.app.state.vault
    all_articles = _get_cached_articles(vault)

    # If cache is still warming up, build article list synchronously
    # so taxonomy tree always has correct article counts
    if not all_articles:
        all_articles = _build_article_list(vault)

    # Auto-classify articles that lack taxonomy_path
    articles = []
    for a in all_articles:
        tp = a.get("taxonomy_path", "")
        if not tp:
            tp = classify_article(
                entity_type=a.get("entity_type", ""),
                category=a.get("category", ""),
                title=a.get("title", ""),
                flat_nodes=flat_nodes,
            )
        articles.append({
            "slug": a["slug"],
            "title": a["title"],
            "taxonomy_path": tp,
            "category": a.get("category", ""),
            "entity_type": a.get("entity_type", ""),
            "kb": a.get("kb", ""),
        })

    annotated_tree = build_taxonomy_tree_with_counts(tree, articles)
    return {"tree": annotated_tree}


@router.get("/articles")
async def list_articles(
    request: Request,
    category: str | None = None,
    taxonomy_path: str | None = None,
    sort: str = "title",
    limit: int = 500,
) -> list[dict]:
    """List all wiki articles across all KBs.

    Filter by category (legacy) or taxonomy_path (hierarchical).
    taxonomy_path matches prefix — "science-technology" includes all children.
    Auto-classifies articles that lack taxonomy_path in frontmatter.
    """
    from agntspace.kb.taxonomy import classify_article, flatten_taxonomy, load_taxonomy

    vault = request.app.state.vault
    all_articles = _get_cached_articles(vault)

    # Apply taxonomy auto-classification if filtering by taxonomy
    flat_nodes: list | None = None
    if taxonomy_path:
        skills_dir: Path | None = getattr(request.app.state, "skills_dir", None)
        if skills_dir:
            tree = load_taxonomy(skills_dir)
            flat_nodes = flatten_taxonomy(tree)

    # Filter
    filtered = []
    for a in all_articles:
        tp = a.get("taxonomy_path", "")
        if not tp and flat_nodes:
            tp = classify_article(
                entity_type=a.get("entity_type", ""),
                category=a.get("category", ""),
                title=a.get("title", ""),
                flat_nodes=flat_nodes,
            )
        if category and a.get("category", "") != category:
            continue
        if taxonomy_path and not (tp == taxonomy_path or tp.startswith(taxonomy_path + "/")):
            continue
        filtered.append(a)

    # Sort
    if sort == "recent":
        filtered.sort(key=lambda a: a.get("mtime", 0), reverse=True)
    elif sort == "links":
        filtered.sort(key=lambda a: len(a.get("links", [])), reverse=True)
    # default: already sorted by title from cache

    return filtered[:limit]


@router.get("/article/{slug}")
async def get_article(request: Request, slug: str) -> dict:
    """Get a single wiki article by slug. Searches across all KBs."""
    vault = request.app.state.vault

    # Find article by slug: check article cache first (frontmatter slug field),
    # then fall back to filename glob for backwards compatibility with slug-named files.
    articles = _get_cached_articles(vault)
    cached = next((a for a in articles if a["slug"] == slug), None)
    if cached:
        f = vault.vault_dir / cached["path"]
        result = _read_article_safe(vault, f)
        if result:
            rel, meta, content = result
        else:
            cached = None

    if not cached:
        # Fallback: try glob by slug filename (backwards compat with old slug-named files)
        try:
            files = vault.list_files("agnt-kb", f"**/wiki/**/{slug}.md")
            files = [f for f in files
                     if "/.archives/" not in str(f).replace("\\", "/")
                     and "/.history/" not in str(f).replace("\\", "/")]
        except Exception:
            files = []
        result = None
        for f in files:
            result = _read_article_safe(vault, f)
            if result:
                rel, meta, content = result
                break

    if not (cached or result):
        # Final fallback: search by frontmatter slug via KBService (display-name files)
        kb_svc = getattr(request.app.state, "kb_service", None)
        found = kb_svc._find_article_by_slug(slug) if kb_svc else None
        if found:
            _kb, _sd, fpath, meta, content = found
            vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir
            rel = str(fpath.relative_to(vault_dir)).replace("\\", "/")
        else:
            raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    raw_links = re.findall(r"\[\[([^\]]+)\]\]", content)
    links = [lnk.split("|")[0].strip() for lnk in raw_links]
    source_file = meta.get("source_file", "")
    library_path = meta.get("library_path", "")
    kb_slug = _extract_kb_slug(rel)

    # Derive source_url — web URL from frontmatter, or local library path
    source_url = meta.get("source_url", "")
    image_url = ""
    # Local file path for vault/library sources
    local_source = ""
    if source_file:
        if library_path:
            clean = library_path.replace("../../", "")
            local_source = f"agnt-kb/{kb_slug}/{clean}" if not clean.startswith("agnt-kb/") else clean
        else:
            try:
                found = vault.list_files(f"agnt-kb/{kb_slug}/library", f"**/{source_file}")
                if found:
                    local_source = _kb_relative_path(found[0], vault)
            except Exception:
                pass

        file_path = local_source or source_url
        if file_path and re.search(r"\.(png|jpg|jpeg|gif|webp|svg)$", source_file, re.I):
            image_url = file_path

    # Scan content for inline image references
    content_images: list[str] = []
    for img_match in re.finditer(r"!\[[^\]]*\]\(([^)]+)\)", content):
        img_path = img_match.group(1)
        if img_path.startswith("../../"):
            img_path = f"agnt-kb/{kb_slug}/{img_path[6:]}"
        elif img_path.startswith("library/"):
            img_path = f"agnt-kb/{kb_slug}/{img_path}"
        if re.search(r"\.(png|jpg|jpeg|gif|webp|svg)$", img_path, re.I):
            content_images.append(img_path)

    if not image_url and content_images:
        image_url = content_images[0]

    # Resolve vault paths for all source files
    source_paths = _resolve_source_paths(request, meta.get("sources", []), kb_slug)

    return {
        "slug": slug,
        "title": meta.get("title", slug.replace("-", " ").title()),
        "category": meta.get("category", ""),
        "taxonomy_path": meta.get("taxonomy_path", ""),
        "entity_type": meta.get("entity_type", ""),
        "content": content,
        "links": links,
        "related": meta.get("related", []),
        "sources": meta.get("sources", []),
        "source_paths": source_paths,
        "source_file": source_file,
        "library_path": library_path,
        "vault_source": _resolve_vault_source(request, meta, kb_slug),
        "created_reason": meta.get("created_reason", ""),
        "source_url": source_url,
        "image_url": image_url,
        "images": content_images,
        "path": rel,
        "kb": kb_slug,
        "date_created": meta.get("date_created", meta.get("date", "")),
        "date_updated": meta.get("date_updated", ""),
        "author": meta.get("author", ""),
        "agent": meta.get("agent", ""),
    }


@router.get("/categories")
async def list_categories(request: Request) -> list[dict]:
    """List all categories with article counts."""
    vault = request.app.state.vault
    categories: dict[str, int] = {}

    for f in _list_wiki_files(vault):
        result = _read_article_safe(vault, f)
        if not result:
            continue
        _rel, meta, _content = result
        cat = meta.get("category", "uncategorized")
        categories[cat] = categories.get(cat, 0) + 1

    return [{"name": name, "count": count} for name, count in sorted(categories.items())]


@router.get("/people")
async def list_people(request: Request) -> list[dict]:
    """List all person entities in the wiki (articles with entity_type: person)."""
    vault = request.app.state.vault
    articles = _get_cached_articles(vault)
    people = []
    for a in articles:
        if a.get("entity_type") == "person":
            people.append({
                "name": a["title"],
                "slug": a["slug"],
                "excerpt": a.get("excerpt", ""),
                "kb": a.get("kb", ""),
                "links": len(a.get("links", [])),
            })
    return sorted(people, key=lambda p: p["name"])


@router.get("/search")
async def search_wiki(request: Request, q: str, limit: int = 20) -> list[dict]:
    """Full-text search across all wiki articles."""
    vault = request.app.state.vault
    query_lower = q.lower()
    results = []

    # Use cached article list instead of re-reading all files
    articles = _get_cached_articles(vault)
    for a in articles:
        title = a.get("title", "")
        excerpt = a.get("excerpt", "")

        score = 0
        if query_lower in title.lower():
            score += 10

        # Check excerpt for quick content match
        if query_lower in excerpt.lower():
            score += 3

        if score == 0:
            # Fall back to full file read only if no title/excerpt match
            f = vault.vault_dir / a["path"]
            file_result = _read_article_safe(vault, f)
            if not file_result:
                continue
            _rel, _meta, content = file_result
            occurrences = content.lower().count(query_lower)
            score += min(occurrences, 5)
            if score == 0:
                continue
        else:
            # Read full content for snippet extraction
            f = vault.vault_dir / a["path"]
            file_result = _read_article_safe(vault, f)
            if file_result:
                _rel, _meta, content = file_result
            else:
                content = excerpt

        content_lower = content.lower()
        idx = content_lower.find(query_lower)
        if idx >= 0:
            start = max(0, idx - 80)
            end = min(len(content), idx + 120)
            snippet = content[start:end].strip()
            if start > 0:
                snippet = "..." + snippet
            if end < len(content):
                snippet += "..."
        else:
            snippet = excerpt

        results.append({
            "slug": a["slug"],
            "title": title,
            "category": a.get("category", ""),
            "snippet": snippet,
            "score": score,
            "kb": a.get("kb", ""),
        })

    results.sort(key=lambda r: r["score"], reverse=True)
    return results[:limit]


@router.get("/recent")
async def recent_changes(request: Request, limit: int = 20) -> list[dict]:
    """Recently modified wiki articles."""
    vault = request.app.state.vault
    articles = _get_cached_articles(vault)

    result = [
        {
            "slug": a["slug"],
            "title": a["title"],
            "modified": datetime.fromtimestamp(a.get("mtime", 0), tz=UTC).isoformat(),
            "kb": a.get("kb", ""),
        }
        for a in articles if a.get("mtime", 0) > 0 and a.get("entity_type") != "source_summary"
    ]
    result.sort(key=lambda a: a["modified"], reverse=True)
    return result[:limit]


@router.get("/popular")
async def popular_articles(request: Request, limit: int = 10) -> list[dict]:
    """Most linked articles — articles that appear in the most [[links]] across the wiki."""
    vault = request.app.state.vault
    articles = _get_cached_articles(vault)
    link_counts: dict[str, int] = {}
    slug_titles: dict[str, str] = {}

    # Slugs to exclude from ranking (index/catalog files, not real articles)
    _META_SLUGS = {"sources", "links", "index", "concepts", "catalog", "decisions"}

    for a in articles:
        slug = a["slug"]
        # Skip source summary articles and meta-articles from being counted as sources of links
        entity_type = a.get("entity_type", "")
        if entity_type == "source_summary" or slug in _META_SLUGS:
            continue
        slug_titles[slug] = a["title"]
        for link in a.get("links", []):
            link_slug = link.split("/")[-1].lower().replace(" ", "-")
            # Don't count references to meta-articles
            if link_slug not in _META_SLUGS:
                link_counts[link_slug] = link_counts.get(link_slug, 0) + 1

    ranked = sorted(link_counts.items(), key=lambda x: x[1], reverse=True)
    return [
        {"slug": slug, "title": slug_titles.get(slug, slug.replace("-", " ").title()), "link_count": count}
        for slug, count in ranked[:limit]
        if slug not in _META_SLUGS
    ]


@router.get("/featured")
async def featured_article(request: Request) -> dict:
    """Featured article — the most recently compiled article with the most links."""

    vault = request.app.state.vault
    articles = _get_cached_articles(vault)

    best = None
    best_score = -1.0
    for a in articles:
        link_count = len(a.get("links", []))
        excerpt_len = len(a.get("excerpt", ""))
        score = link_count + excerpt_len / 100
        if score > best_score and excerpt_len > 50:
            best_score = score
            best = {
                "slug": a["slug"],
                "title": a["title"],
                "category": a.get("category", ""),
                "excerpt": a.get("excerpt", ""),
                "link_count": link_count,
                "kb": a.get("kb", ""),
            }

    return {"article": best}


@router.get("/stats")
async def wiki_stats(request: Request) -> dict:
    """Overall wiki statistics."""
    kb_service = request.app.state.kb_service

    kbs = kb_service.list_kbs()
    total_articles = sum(kb.get("articles", 0) for kb in kbs)
    total_sources = sum(kb.get("sources", 0) for kb in kbs)

    return {
        "knowledge_bases": len(kbs),
        "total_articles": total_articles,
        "total_sources": total_sources,
        "kbs": kbs,
    }


@router.get("/ingested")
async def recent_ingestions(request: Request, limit: int = 15) -> list[dict]:
    """Recently ingested sources — shows what the agent has processed."""
    vault = request.app.state.vault
    items: list[dict] = []

    try:
        files = vault.list_files("agnt-kb", "**/wiki/sources/*.md")
        files = [f for f in files if "/.archives/" not in str(f).replace("\\", "/")]
    except Exception:
        log.exception("Failed to list ingested sources")
        return []

    for f in files:
        if f.name.startswith(("_", ".")):
            continue
        result = _read_article_safe(vault, f)
        if not result:
            continue
        rel, meta, content = result
        date_created = meta.get("date_created", "")
        excerpt = ""
        for line in content.split("\n"):
            line = line.strip()
            if line and not line.startswith("#") and not line.startswith("-") and not line.startswith(">"):
                excerpt = line[:200]
                break
        items.append({
            "slug": meta.get("slug") or re.sub(r"[^a-z0-9]+", "-", f.stem.lower()).strip("-"),
            "title": meta.get("source_file", f.stem.replace("-", " ").title()),
            "category": meta.get("category", ""),
            "date": date_created,
            "excerpt": excerpt,
            "kb": _extract_kb_slug(rel),
        })

    items.sort(key=lambda a: a.get("date", ""), reverse=True)
    return items[:limit]


@router.get("/stale")
async def list_stale_articles(request: Request) -> list[dict]:
    """List all stale articles (source was deleted)."""
    vault = request.app.state.vault
    articles = _get_cached_articles(vault)
    return [
        {"slug": a["slug"], "title": a["title"], "path": a.get("path", ""), "kb": a.get("kb", "")}
        for a in articles if a.get("status") == "stale"
    ]


class CreateArticleBody(BaseModel):
    kb_slug: str
    title: str
    content: str = ""
    entity_type: str = "concept"
    subdir: str | None = None


class UpdateArticleBody(BaseModel):
    content: str | None = None
    metadata: dict | None = None


class RenameArticleBody(BaseModel):
    new_title: str


@router.post("/article")
async def create_article(request: Request, body: CreateArticleBody) -> dict:
    """Create a new wiki article in a specific KB."""
    kb_service = request.app.state.kb_service
    try:
        result = kb_service.create_article(
            body.kb_slug, body.title, body.content, body.entity_type, body.subdir,
        )
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e)) from e

    invalidate_article_cache()
    return result


@router.put("/article/{slug}")
async def update_article(request: Request, slug: str, body: UpdateArticleBody) -> dict:
    """Update a wiki article's content and/or metadata."""
    if body.content is None and body.metadata is None:
        raise HTTPException(status_code=400, detail="Provide content and/or metadata to update")

    kb_service = request.app.state.kb_service
    try:
        result = kb_service.update_article(slug, body.content, body.metadata)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e

    invalidate_article_cache()
    return result


@router.post("/article/{slug}/rename")
async def rename_article(request: Request, slug: str, body: RenameArticleBody) -> dict:
    """Rename a wiki article — updates file, slug, and all backlinks."""
    if not body.new_title.strip():
        raise HTTPException(status_code=400, detail="new_title is required")

    kb_service = request.app.state.kb_service
    try:
        result = kb_service.rename_article(slug, body.new_title.strip())
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e)) from e
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e)) from e

    invalidate_article_cache()
    return result


@router.get("/article/{slug}/backlinks")
async def get_backlinks(request: Request, slug: str) -> dict:
    """Count how many articles link to this slug/title."""
    vault = request.app.state.vault
    articles = _get_cached_articles(vault)
    cached = next((a for a in articles if a["slug"] == slug), None)
    title = cached["title"] if cached else slug.replace("-", " ")

    count = 0
    for article_file in _list_wiki_files(vault):
        art_result = _read_article_safe(vault, article_file)
        if not art_result:
            continue
        art_rel, _, art_content = art_result
        # Skip self
        if cached and art_rel == cached.get("path"):
            continue
        if f"[[{title}]]" in art_content or f"[[{slug}]]" in art_content or f"[[{slug}|" in art_content:
            count += 1

    return {"slug": slug, "backlink_count": count}


@router.delete("/article/{slug}")
async def delete_article(request: Request, slug: str) -> dict:
    """Delete a wiki article across all KBs. Returns broken backlink info."""
    vault = request.app.state.vault
    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir
    kb_service = request.app.state.kb_service

    # Collect backlinks before deleting so the caller can warn about broken links
    broken_backlinks = kb_service.find_backlinks(slug)

    try:
        files = vault.list_files("agnt-kb", f"**/wiki/**/{slug}.md")
        files = [f for f in files if "/.archives/" not in str(f).replace("\\", "/")]
    except Exception:
        files = []

    # Also try to find by frontmatter slug (display-name filenames)
    if not files:
        found = kb_service._find_article_by_slug(slug)
        if found:
            _kb, _sd, fpath, _meta, _content = found
            files = [fpath]

    deleted = []
    for f in files:
        try:
            full = f if f.is_absolute() else vault_dir / _kb_relative_path(f, vault)
            if full.exists():
                full.unlink()
                deleted.append(str(f.name))
        except Exception:
            continue

    # Clean up index references
    if deleted:
        seen_kbs: set[str] = set()
        for f in files:
            kb_slug_val = _extract_kb_slug(_kb_relative_path(f, vault))
            if kb_slug_val and kb_slug_val not in seen_kbs:
                seen_kbs.add(kb_slug_val)
                idx_rel = f"agnt-kb/{kb_slug_val}/wiki/_index.md"
                try:
                    doc = vault.read(idx_rel)
                    idx = doc.raw
                    new_lines = [l for l in idx.split("\n") if f"[[{slug}]]" not in l and f"[{slug}]" not in l]
                    vault_writer = getattr(request.app.state, "vault_writer", None)
                    if vault_writer:
                        vault_writer.write(idx_rel, "\n".join(new_lines))
                except Exception:
                    pass

    if not deleted:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    invalidate_article_cache()
    return {
        "deleted": True,
        "slug": slug,
        "files": deleted,
        "broken_backlinks": [{"article": bl["slug"], "kb": bl["kb"]} for bl in broken_backlinks],
    }


@router.get("/article/{slug}/history")
async def article_history(request: Request, slug: str) -> dict:
    """List version history for a wiki article."""
    vault = request.app.state.vault
    writer = getattr(request.app.state, "vault_writer", None)
    if not writer:
        return {"versions": [], "slug": slug}

    # Find the article file across all KBs
    try:
        files = vault.list_files("agnt-kb", f"**/wiki/**/{slug}.md")
        files = [f for f in files if "/.archives/" not in str(f).replace("\\", "/")
                 and "/.history/" not in str(f).replace("\\", "/")]
    except Exception:
        files = []

    if not files:
        # Fallback: search by frontmatter slug (display-name files)
        kb_svc = getattr(request.app.state, "kb_service", None)
        found = kb_svc._find_article_by_slug(slug) if kb_svc else None
        if found:
            files = [found[2]]  # filepath

    if not files:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    # Get relative path
    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir
    relative = str(files[0].relative_to(vault_dir)).replace("\\", "/")
    versions = writer.list_versions(relative)

    return {"slug": slug, "path": relative, "versions": versions}


@router.get("/article/{slug}/version/{version}")
async def article_version(request: Request, slug: str, version: str) -> dict:
    """Read a specific version of a wiki article."""
    vault = request.app.state.vault
    writer = getattr(request.app.state, "vault_writer", None)
    if not writer:
        raise HTTPException(status_code=404, detail="No writer available")

    try:
        files = vault.list_files("agnt-kb", f"**/wiki/**/{slug}.md")
        files = [f for f in files if "/.archives/" not in str(f).replace("\\", "/")
                 and "/.history/" not in str(f).replace("\\", "/")]
    except Exception:
        files = []

    if not files:
        raise HTTPException(status_code=404, detail=f"Article not found: {slug}")

    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir
    relative = str(files[0].relative_to(vault_dir)).replace("\\", "/")
    content = writer.read_version(relative, version)

    if content is None:
        raise HTTPException(status_code=404, detail=f"Version not found: {version}")

    return {"slug": slug, "version": version, "content": content}


@router.post("/reclassify")
async def reclassify_all(request: Request) -> dict:
    """Re-run taxonomy classification on all articles. Call after taxonomy changes."""
    kb_service = request.app.state.kb_service
    return kb_service.reclassify_articles()


@router.post("/reclassify/{kb_slug}")
async def reclassify_kb(request: Request, kb_slug: str) -> dict:
    """Re-run taxonomy classification on a specific KB's articles."""
    kb_service = request.app.state.kb_service
    return kb_service.reclassify_articles(kb_slug)


@router.delete("/reset")
async def reset_all_wikis(request: Request) -> dict:
    """Reset ALL wiki articles across all KBs. Keeps library/inbox sources intact."""
    kb_service = request.app.state.kb_service
    return kb_service.reset_all_wikis()


@router.delete("/reset/{kb_slug}")
async def reset_kb_wiki(request: Request, kb_slug: str) -> dict:
    """Reset all wiki articles for a specific KB. Keeps library/inbox sources intact."""
    kb_service = request.app.state.kb_service
    return kb_service.reset_wiki(kb_slug)




@router.delete("/stale")
async def delete_all_stale(request: Request) -> dict:
    """Delete all stale articles at once."""
    stale = await list_stale_articles(request)
    vault = request.app.state.vault
    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir
    deleted = []
    for article in stale:
        try:
            full = vault_dir / article["path"]
            if full.exists():
                full.unlink()
                deleted.append(article["slug"])
        except Exception:
            continue
    return {"deleted": deleted, "count": len(deleted)}


@router.get("/file/{file_path:path}")
@router.get("/image/{file_path:path}")
async def serve_file(request: Request, file_path: str):
    """Serve a file from the vault (images, documents, any source file)."""
    from fastapi.responses import FileResponse

    vault = request.app.state.vault
    vault_dir = vault.vault_dir if hasattr(vault, "vault_dir") else vault._vault_dir
    full_path = vault_dir / file_path

    if not full_path.exists() or not full_path.is_file():
        raise HTTPException(status_code=404, detail=f"Image not found: {file_path}")

    # Security: ensure path is within vault
    try:
        full_path.resolve().relative_to(vault_dir.resolve())
    except ValueError as e:
        raise HTTPException(status_code=403, detail="Access denied") from e

    return FileResponse(str(full_path))


@router.post("/open-file")
async def open_local_file(request: Request) -> dict:
    """Open a local file with the OS default handler (like double-clicking it).

    This is a local-only app — this endpoint only works on the host machine.
    """
    import subprocess
    import sys

    try:
        body = await request.json()
    except Exception:
        raw = await request.body()
        import json as _json
        body = _json.loads(raw.decode("utf-8", errors="replace"))
    file_path = body.get("path", "")

    if not file_path:
        raise HTTPException(status_code=400, detail="No path provided")

    # Decode any URL-encoded characters (spaces, unicode, etc.)
    from urllib.parse import unquote
    file_path = unquote(file_path)

    from pathlib import Path as P
    path = P(file_path)
    # Resolve vault-relative paths (e.g., "agnt-kb/general/library/article/...")
    if not path.is_absolute() and hasattr(request.app.state, "vault"):
        vault_dir = request.app.state.vault.vault_dir
        path = vault_dir / file_path
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {file_path}")

    try:
        method = "default"
        if sys.platform == "win32":
            import os
            import shutil
            import winreg

            # 1. Try Obsidian URI if file is inside an Obsidian vault
            check = path.parent
            for _ in range(10):
                if (check / ".obsidian").is_dir():
                    try:
                        rel = path.relative_to(check)
                        from urllib.parse import quote
                        obsidian_uri = f"obsidian://open?vault={quote(check.name)}&file={quote(str(rel).replace(chr(92), '/'))}"
                        os.startfile(obsidian_uri)
                        return {"opened": True, "path": file_path, "method": "obsidian"}
                    except Exception:
                        break
                if check.parent == check:
                    break
                check = check.parent

            # 2. Check if the extension has a file association
            ext = path.suffix.lower()
            has_association = False
            try:
                with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, ext) as key:
                    val = winreg.QueryValueEx(key, "")[0]
                    has_association = bool(val)
            except OSError:
                pass

            if has_association:
                os.startfile(str(path))
                method = "os"
            else:
                # 3. No association — find a usable editor
                # Try VS Code, then notepad as universal fallback
                code = shutil.which("code")
                if code:
                    subprocess.Popen([code, str(path)])
                    method = "vscode"
                else:
                    subprocess.Popen(["notepad.exe", str(path)])
                    method = "notepad"
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
        return {"opened": True, "path": file_path, "method": method}
    except Exception as e:
        log.exception("Failed to open file: %s", file_path)
        raise HTTPException(status_code=500, detail=f"Failed to open: {e}") from e


def _kb_relative_path(file_path: Path, vault) -> str:
    """Get vault-relative path for a KB file."""
    vault_dir = vault.vault_dir
    try:
        return str(file_path.relative_to(vault_dir)).replace("\\", "/")
    except ValueError:
        # Absolute path not under vault_dir — use as-is
        return str(file_path).replace("\\", "/")


def _extract_kb_slug(path: str) -> str:
    """Extract KB slug from a path like 'agnt-kb/ai-safety/wiki/article.md'."""
    parts = path.replace("\\", "/").split("/")
    try:
        kb_idx = parts.index("agnt-kb")
        return parts[kb_idx + 1]
    except (ValueError, IndexError):
        return ""


def _resolve_vault_source(request: Request, meta: dict, kb_slug: str) -> str:
    """Resolve the original vault path for an article.

    Priority:
    1. Article's own vault_source frontmatter
    2. Compile state sources dict (fast lookup)
    3. Source summary page's vault_source frontmatter (fallback for pre-tracking data)
    """
    direct = meta.get("vault_source", "")
    if direct:
        return direct

    source_files = meta.get("sources", [])
    if not source_files or not kb_slug:
        return ""

    try:
        kb_service = request.app.state.kb_service
        vault = request.app.state.vault

        # Try compile state first
        state = kb_service._read_compile_state(kb_slug)
        sources = state.get("sources", {})
        for fname in source_files:
            if fname in sources:
                vs = sources[fname].get("vault_source", "")
                if vs:
                    return vs

        # Fallback: read the source summary page's frontmatter
        for fname in source_files:
            slug = fname.lower().replace(" ", "-").replace(".md", "")
            source_path = f"agnt-kb/{kb_slug}/wiki/sources/{slug}.md"
            if vault.exists(source_path):
                try:
                    doc = vault.read(source_path)
                    vs = doc.metadata.get("vault_source", "")
                    if vs:
                        return vs
                except Exception:
                    pass
    except Exception:
        pass

    return ""


def _resolve_source_paths(request: Request, source_files: list[str], kb_slug: str) -> dict[str, str]:
    """Resolve each source filename to its vault path (absolute on disk).

    Returns a dict mapping source filename → absolute file path.
    Sources live in the KB library folder; we also check compile state for vault_source.
    """
    if not source_files or not kb_slug:
        return {}

    result: dict[str, str] = {}
    try:
        vault = request.app.state.vault
        kb_service = request.app.state.kb_service

        # Load compile state once for all sources
        state = kb_service._read_compile_state(kb_slug)
        sources_state = state.get("sources", {})

        for fname in source_files:
            # 1. Check compile state for vault_source (original file outside vault)
            if fname in sources_state:
                vs = sources_state[fname].get("vault_source", "")
                if vs and Path(vs).is_file():
                    result[fname] = vs
                    continue

            # 2. Try to find in KB library folder
            try:
                found = vault.list_files(f"agnt-kb/{kb_slug}/library", f"**/{fname}")
                if found:
                    result[fname] = str(found[0])
                    continue
            except Exception:
                pass

            # 3. Try inbox
            try:
                found = vault.list_files(f"agnt-kb/{kb_slug}/inbox", f"**/{fname}")
                if found:
                    result[fname] = str(found[0])
            except Exception:
                pass
    except Exception:
        pass

    return result


def _list_wiki_files(vault) -> list[Path]:
    """List all wiki article .md files across all KBs.

    Filters out .index.md, .concepts.md, .gitkeep, and archived snapshots.
    """
    try:
        files = vault.list_files("agnt-kb", "**/wiki/**/*.md")
    except Exception:
        log.exception("Failed to list wiki files")
        return []
    return [
        f for f in files
        if not f.name.startswith(("_", "."))
        and "/.archives/" not in str(f).replace("\\", "/")
        and "/.history/" not in str(f).replace("\\", "/")
    ]


def _read_article_safe(vault, file_path: Path) -> tuple[str, dict, str] | None:
    """Read a wiki article, returning (rel_path, metadata, content) or None on error."""
    try:
        rel = _kb_relative_path(file_path, vault)
        doc = vault.read(rel)
        return rel, doc.metadata, doc.content
    except Exception as e:
        log.debug("Skipped article with bad frontmatter: %s (%s)", file_path.name, e.__class__.__name__)
        return None
