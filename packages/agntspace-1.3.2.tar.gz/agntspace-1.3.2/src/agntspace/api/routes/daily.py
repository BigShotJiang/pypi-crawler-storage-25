"""Daily cycle API: morning briefing + end-of-day report + focus."""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Request
from pydantic import BaseModel  # noqa: F401 — used by FocusRequest

router = APIRouter(prefix="/daily", tags=["daily"])


class FocusRequest(BaseModel):
    text: str


@router.get("/status")
async def daily_status(request: Request) -> dict:
    """Get daily cycle status."""
    return request.app.state.daily_cycle.status()


@router.post("/briefing")
async def generate_briefing(request: Request) -> dict:
    """Manually trigger morning briefing."""
    daily = request.app.state.daily_cycle
    briefing = await daily.generate_morning_briefing()
    return {"briefing": briefing}


@router.get("/briefing")
async def get_latest_briefing(request: Request) -> dict:
    """Get the latest morning briefing."""
    daily = request.app.state.daily_cycle
    return {"briefing": daily.latest_briefing or "No briefing generated yet. Trigger one with POST /api/daily/briefing."}


@router.post("/eod")
async def generate_eod(request: Request) -> dict:
    """Manually trigger end-of-day report."""
    daily = request.app.state.daily_cycle
    eod = await daily.generate_eod_report()
    return {"report": eod}


@router.get("/eod")
async def get_latest_eod(request: Request) -> dict:
    """Get the latest end-of-day report."""
    daily = request.app.state.daily_cycle
    return {"report": daily.latest_eod or "No end-of-day report yet. Trigger one with POST /api/daily/eod."}


@router.post("/focus")
async def set_focus(request: Request, body: FocusRequest) -> dict:
    """Set today's focus in the journal's Focus section.

    This feeds into the morning briefing. The agent will honor your
    focus over auto-generated suggestions.
    """
    journal = request.app.state.journal
    journal.set_focus(body.text)
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    return {"status": "ok", "date": today}


@router.get("/focus")
async def get_focus(request: Request) -> dict:
    """Get today's focus from the journal."""
    journal = request.app.state.journal
    today = datetime.now(UTC).strftime("%Y-%m-%d")
    content = journal.get_section("Focus")
    return {"date": today, "focus": content, "set": bool(content)}
