"""Factory for creating LLM providers from settings.

Uses LiteLLM UniversalProvider — supports 100+ providers
through a single interface. No provider-specific code.
"""

from __future__ import annotations

import logging
from collections.abc import AsyncIterator

from agntspace.infra.config import Settings
from agntspace.llm.base import LLMError, LLMProvider, LLMResponse, Message, StreamChunk
from agntspace.llm.provider import UniversalProvider

log = logging.getLogger(__name__)

_NO_KEY_MSG = (
    "No API key configured. Please go to Settings > LLM and enter your API key, "
    "or set the ANTHROPIC_API_KEY / OPENAI_API_KEY environment variable."
)


class _StubProvider(LLMProvider):
    """Placeholder provider when no API key is available.

    Lets the server boot so the user can access the UI to enter the key.
    Every LLM call returns a clear error message instead of crashing.
    """

    async def complete(
        self,
        messages: list[Message],
        system: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
    ) -> LLMResponse:
        raise LLMError(_NO_KEY_MSG, provider="none", retryable=False)

    async def stream(  # type: ignore[override]
        self,
        messages: list[Message],
        system: str | None = None,
        max_tokens: int = 4096,
        temperature: float = 0.7,
    ) -> AsyncIterator[StreamChunk]:
        yield StreamChunk(delta=_NO_KEY_MSG, done=True)


def get_provider(
    settings: Settings,
    credential_store: object | None = None,
) -> LLMProvider:
    """Create an LLM provider based on current settings.

    Returns a stub provider if no API key is available — the server
    still starts so the user can access the UI to enter the key.

    Model format: "provider/model" for LiteLLM routing.
    Examples:
        anthropic/claude-sonnet-4-20250514
        openai/gpt-4o
        ollama/llama3
        gemini/gemini-pro
    """
    fallback = settings.llm.fallback_model or None

    if settings.llm.mode == "local":
        model = f"ollama/{settings.llm.local_model}"
        return UniversalProvider(
            model=model,
            api_base="http://localhost:11434",
            fallback_model=fallback,
        )

    # Cloud mode — build model string
    provider = settings.llm.cloud_provider
    model_name = settings.llm.cloud_model

    model = model_name if "/" in model_name else f"{provider}/{model_name}"

    # Get the appropriate API key: env vars first, then credential store
    api_key = settings.active_api_key
    if (not api_key or api_key == "ollama") and credential_store is not None:
        # UI saves under the provider name (e.g. "anthropic", "openai")
        creds = getattr(credential_store, "get", lambda _: None)(provider)
        if creds:
            api_key = creds.get("api_key", "")

    if not api_key or api_key == "ollama":
        log.warning(
            "API key not set for %s. Server will start but LLM features are unavailable. "
            "Set the key in Settings > LLM or via ANTHROPIC_API_KEY / OPENAI_API_KEY env var.",
            provider,
        )
        return _StubProvider()

    return UniversalProvider(model=model, api_key=api_key, fallback_model=fallback)
