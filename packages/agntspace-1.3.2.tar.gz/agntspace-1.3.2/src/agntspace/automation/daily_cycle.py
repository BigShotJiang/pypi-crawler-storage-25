"""Daily cycle: morning briefing + end-of-day report with reflection.

Runs on a 1-minute check loop. Triggers at configured times.
Results saved to journal and vault.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from agntspace.agent.orchestrator import Orchestrator
    from agntspace.automation.heartbeat import Heartbeat
    from agntspace.coach.service import CoachService
    from agntspace.journal.reflection import ReflectionService
    from agntspace.journal.service import JournalService
    from agntspace.kb.memory_bridge import MemoryWikiBridge
    from agntspace.llm.base import LLMProvider
    from agntspace.memory.engine import MemoryEngine
    from agntspace.skillschool.service import SkillSchoolService
    from agntspace.tasks.service import TaskService
    from agntspace.trust.service import TrustService
    from agntspace.vault.reader import VaultReader
    from agntspace.vault.search import VaultSearch
    from agntspace.vault.writer import VaultWriter

log = logging.getLogger(__name__)


class DailyCycle:
    """Manages morning briefing and end-of-day report generation."""

    def __init__(
        self,
        llm: LLMProvider,
        journal: JournalService,
        task_service: TaskService,
        coach: CoachService,
        trust_service: TrustService,
        reflection_service: ReflectionService,
        vault_reader: VaultReader,
        vault_writer: VaultWriter,
        memory_engine: MemoryEngine | None = None,
        heartbeat: Heartbeat | None = None,
        skillschool: SkillSchoolService | None = None,
        vault_search: VaultSearch | None = None,
        orchestrator: Orchestrator | None = None,
        memory_bridge: MemoryWikiBridge | None = None,
        morning_hour: int = 7,
        evening_hour: int = 21,
        weekly_compaction_day: int = 6,  # 0=Mon, 6=Sun
        skill_loader: object | None = None,
        model_router: object | None = None,
    ) -> None:
        self._llm = llm
        self._journal = journal
        self._tasks = task_service
        self._coach = coach
        self._trust = trust_service
        self._reflection = reflection_service
        self._reader = vault_reader
        self._writer = vault_writer
        self._memory_engine = memory_engine
        self._heartbeat = heartbeat
        self._skillschool = skillschool
        self._vault_search = vault_search
        self._orchestrator = orchestrator
        self._memory_bridge = memory_bridge
        self._skill_loader = skill_loader
        self._model_router = model_router
        self._agent: object | None = None  # injected post-hoc from main.py
        self._last_editor: str = ""
        self._morning_hour = morning_hour
        self._evening_hour = evening_hour
        self._weekly_day = weekly_compaction_day
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False
        self._last_morning: str = ""
        self._last_evening: str = ""
        self._last_weekly: str = ""
        self._latest_briefing: str = ""
        self._latest_eod: str = ""

    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._run())
        log.debug(
            "Daily cycle started (morning: %02d:00, evening: %02d:00)",
            self._morning_hour,
            self._evening_hour,
        )

    async def _run(self) -> None:
        """Run catch-up first, then enter the regular loop."""
        await self._catch_up()
        await self._loop()

    def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None

    @property
    def latest_briefing(self) -> str:
        return self._latest_briefing

    @property
    def latest_eod(self) -> str:
        return self._latest_eod

    async def generate_morning_briefing(self) -> str:
        """Generate the morning briefing via the main agent."""
        # Gather context
        tasks = self._tasks.list_tasks()
        active_tasks = [t for t in tasks if t.get("status") not in ("done", "cancelled")]
        task_text = "\n".join(
            f"- {t['title']} [{t['status']}] (mode: {t['mode']}, domain: {t['domain']})"
            for t in active_tasks
        ) or "No active tasks."

        goals = self._coach.list_goals(status_filter="active")
        goals_text = "\n".join(f"- {g['title']} (due: {g.get('target_date', 'no date')})" for g in goals) or "No active goals."

        nudges = self._coach.generate_nudges()
        nudges_text = "\n".join(f"- {n}" for n in nudges) or "No nudges."

        # Yesterday's journal
        from datetime import timedelta

        yesterday = (datetime.now(UTC) - timedelta(days=1)).strftime("%Y-%m-%d")
        yesterday_doc = self._journal.get_entry(yesterday)
        yesterday_text = yesterday_doc.content if yesterday_doc else "No journal entry yesterday."

        # Memory
        memory_text = ""
        memory_path = "agnt-memory/MEMORY.md"
        if self._reader.exists(memory_path):
            memory_text = self._reader.read(memory_path).content

        # User's focus for today (from journal Focus section)
        focus_text = "Not set — suggest based on tasks and goals."
        focus_content = self._journal.get_section("Focus")
        if focus_content:
            focus_text = focus_content

        # Evolution context — trust changes, skill proposals, stalled goals
        evolution_parts: list[str] = []
        try:
            trust_changes = self._trust.get_recent_changes(since_date=yesterday)
            if trust_changes:
                evolution_parts.append("Trust changes:\n" + "\n".join(trust_changes))
        except Exception:
            pass
        if self._skillschool:
            try:
                proposals = self._skillschool.list_proposals()
                pending = [p for p in proposals if p.get("status") == "pending"]
                if pending:
                    evolution_parts.append(f"{len(pending)} pending skill proposal(s): " + ", ".join(p.get("title", p.get("name", "?")) for p in pending))
            except Exception:
                pass
        stalled = self._coach.detect_stalls()
        if stalled:
            evolution_parts.append(f"{len(stalled)} stalled goal(s): " + ", ".join(s.get("title", "?") for s in stalled))
        evolution_text = "\n".join(evolution_parts) or "No evolution updates."

        # Search vault for upcoming scheduled activities, deadlines, and recurring items
        upcoming_text = "None found."
        if self._vault_search:
            try:
                searches = ["scheduled activities", "maintenance due", "deadline upcoming", "recurring"]
                all_results: list[str] = []
                seen_paths: set[str] = set()
                for query in searches:
                    results = await self._vault_search.search(query, limit=3)
                    for r in results:
                        path = r.get("path", "")
                        if path not in seen_paths:
                            seen_paths.add(path)
                            snippet = r.get("snippet", "")[:300]
                            all_results.append(f"[{path}] {snippet}")
                if all_results:
                    upcoming_text = "\n".join(all_results[:8])
            except Exception:
                log.debug("Vault search for upcoming items failed", exc_info=True)

        # Build context for the agent
        dynamic_ctx = (
            f"USER'S FOCUS FOR TODAY:\n{focus_text}\n\n"
            f"ACTIVE TASKS:\n{task_text}\n\n"
            f"GOALS:\n{goals_text}\n\n"
            f"COACHING NUDGES:\n{nudges_text}\n\n"
            f"YESTERDAY'S JOURNAL:\n{yesterday_text[:1500]}\n\n"
            f"MEMORY:\n{memory_text[:1000]}\n\n"
            f"EVOLUTION:\n{evolution_text}\n\n"
            f"UPCOMING SCHEDULES & DEADLINES:\n{upcoming_text}"
        )

        task_instruction = (
            "Generate my morning briefing for today. Include these sections:\n"
            "- Good morning — a brief personalized greeting\n"
            "- Today's focus — honor the user's focus if set, otherwise suggest top priorities\n"
            "- Active tasks — bullet list of in-progress and pending tasks\n"
            "- Upcoming — scheduled items and deadlines (skip if empty)\n"
            "- Nudges — coaching nudges (skip if empty)\n"
            "- Yesterday's takeaway — one key thing from yesterday\n"
            "- Evolution — trust changes, skill proposals, stalled goals (skip if empty)\n\n"
            "Keep it under 300 words. Be warm but efficient. Output ONLY the briefing content."
        )

        try:
            briefing = await self._agent.process_task(task=task_instruction, context=dynamic_ctx)
        except Exception as exc:
            log.error("Morning briefing failed: %s", exc)
            self._journal.append_observation(f"Morning briefing failed: {exc}")
            if self._heartbeat:
                await self._heartbeat.record_pulse("error", f"Morning briefing failed: {exc}")
            raise

        self._latest_briefing = briefing

        # Log to agent observations
        self._journal.append_action("Morning briefing generated")

        # Save to vault
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        self._writer.write(
            f"journal/morning-briefing_{today}.md",
            f"---\ntitle: \"Morning Briefing — {today}\"\ndate: \"{today}\"\ntype: briefing\nauthor: agent\nagent: ops-supervisor\ndescription: \"Agent-generated morning briefing with priorities, tasks, and context.\"\n---\n\n{briefing}",
        )

        log.info("Morning briefing generated (%d chars)", len(briefing))
        if self._heartbeat:
            await self._heartbeat.record_pulse("automation", "Morning briefing generated")
        return briefing

    async def generate_eod_report(self) -> str:
        """Generate end-of-day report via the main agent + trigger reflection."""
        today = datetime.now(UTC).strftime("%Y-%m-%d")

        # Today's journal
        today_doc = self._journal.get_entry(today)
        journal_text = today_doc.content if today_doc else "No journal entries today."

        # Tasks
        tasks = self._tasks.list_tasks()
        task_text = "\n".join(
            f"- {t['title']} [{t['status']}]" for t in tasks
        ) or "No tasks."

        # Goals
        goals = self._coach.list_goals(status_filter="active")
        goals_text = "\n".join(f"- {g['title']}" for g in goals) or "No active goals."

        # Build context for the agent
        eod_dynamic_ctx = (
            f"TODAY'S JOURNAL:\n{journal_text[:2000]}\n\n"
            f"ACTIVE TASKS:\n{task_text}\n\n"
            f"GOALS:\n{goals_text}"
        )

        task_instruction = (
            "Generate my end-of-day report for today. Include these sections:\n"
            "- Day summary — 2-3 sentences on what happened today\n"
            "- Completed — tasks finished today\n"
            "- Still active — what carries over to tomorrow\n"
            "- Decisions made — key decisions from the journal\n"
            "- Learnings — things worth remembering\n"
            "- Memory updates — specific items for long-term memory (format as '- Add: ...' or '- Update: ...')\n\n"
            "Keep it concise and actionable. Output ONLY the report content."
        )

        try:
            eod = await self._agent.process_task(task=task_instruction, context=eod_dynamic_ctx)
        except Exception as exc:
            log.error("EOD report failed: %s", exc)
            self._journal.append_observation(f"EOD report failed: {exc}")
            if self._heartbeat:
                await self._heartbeat.record_pulse("error", f"EOD report failed: {exc}")
            raise

        self._latest_eod = eod

        # Log to agent observations
        self._journal.append_action("EOD report generated")

        # Save to vault
        self._writer.write(
            f"journal/eod-report_{today}.md",
            f"---\ntitle: \"EOD Report — {today}\"\ndate: \"{today}\"\ntype: eod_report\nauthor: agent\nagent: ops-supervisor\ndescription: \"End-of-day summary with completed tasks, decisions, and memory updates.\"\n---\n\n{eod}",
        )

        log.info("End-of-day report generated (%d chars)", len(eod))
        if self._heartbeat:
            await self._heartbeat.record_pulse("automation", "EOD report generated")

        # Post-EOD cascade runs in background — don't block the caller
        asyncio.create_task(self._post_eod_cascade(today))

        return eod

    async def _post_eod_cascade(self, today: str) -> None:
        """Run reflection, memory generation, and bridges after EOD.

        Runs as a background task so the EOD API returns quickly.
        """
        # Trigger daily reflection
        try:
            await self._reflection.run_daily_reflection(today)
            log.info("Daily reflection triggered from EOD report")
        except Exception:
            log.debug("Daily reflection failed", exc_info=True)

        # Generate daily memory file
        if self._memory_engine:
            try:
                result = await self._memory_engine.generate_daily_memory(today)
                log.info("Daily memory generated: %s", result.get("path", "?"))
            except Exception:
                log.debug("Daily memory generation failed", exc_info=True)

        # Memory ↔ Wiki bridge
        if self._memory_bridge:
            try:
                m2w = await self._memory_bridge.memory_to_wiki(today)
                log.info("Memory->Wiki: %d updates filed", m2w.get("updates_filed", 0))
            except Exception:
                log.debug("Memory->Wiki bridge failed", exc_info=True)
            try:
                w2m = await self._memory_bridge.wiki_to_memory()
                log.info("Wiki->Memory: %d pending facts", w2m.get("count", 0))
            except Exception:
                log.debug("Wiki->Memory bridge failed", exc_info=True)

        # System bridge
        if hasattr(self, "_system_bridge") and self._system_bridge:
            try:
                sb_result = await self._system_bridge.sync_all(today)
                log.info("SystemBridge: %d triples synced", sb_result.get("total", 0))
            except Exception:
                log.debug("SystemBridge sync failed", exc_info=True)

        log.info("Post-EOD cascade complete for %s", today)

    async def run_weekly_compaction(self) -> None:
        """Run weekly reflection + memory compaction.

        Triggers weekly reflection (which in turn calls compact_memory).
        Scheduled automatically on the configured day of the week.
        """
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        try:
            result = await self._reflection.run_weekly_reflection(today)
            log.info("Weekly reflection completed: %s", result.get("week", "?"))
        except Exception:
            log.exception("Weekly reflection/compaction failed")

    def status(self) -> dict:
        return {
            "running": self._running,
            "morning_hour": self._morning_hour,
            "evening_hour": self._evening_hour,
            "weekly_compaction_day": self._weekly_day,
            "last_morning": self._last_morning,
            "last_evening": self._last_evening,
            "last_weekly": self._last_weekly,
            "has_briefing": bool(self._latest_briefing),
            "has_eod": bool(self._latest_eod),
        }

    async def _catch_up(self) -> None:
        """Detect and run missed cycles from when the server was offline.

        Checks the last 7 days for missing EOD reports/memory files.
        Generates them retroactively so memory continuity is preserved.
        Morning briefing is only generated for today if missed.
        """
        from datetime import timedelta

        now = datetime.now(UTC)
        today = now.strftime("%Y-%m-%d")
        caught_up = []

        # Check today's morning briefing — generate if missed and it's past morning hour
        if now.hour >= self._morning_hour:
            briefing_path = f"journal/morning-briefing_{today}.md"
            if not self._reader.exists(briefing_path):
                try:
                    await self.generate_morning_briefing()
                    caught_up.append(f"morning briefing ({today})")
                except Exception:
                    log.debug("Catch-up: morning briefing failed", exc_info=True)

        # Check past days for missed EOD reports + memory files (up to 7 days)
        for days_ago in range(1, 8):
            date = (now - timedelta(days=days_ago)).strftime("%Y-%m-%d")
            eod_path = f"journal/eod-report_{date}.md"

            if self._reader.exists(eod_path):
                # This day was processed — stop looking further back
                break

            # Check if there was any user activity that day (journal exists)
            journal_path = f"journal/{date}.md"
            if not self._reader.exists(journal_path):
                # No user activity — nothing to synthesize
                continue

            # Missed EOD — generate retroactively
            try:
                log.debug("Catch-up: generating missed EOD for %s", date)
                await self._generate_retroactive_eod(date)
                caught_up.append(f"EOD + memory ({date})")
            except Exception:
                log.debug("Catch-up: EOD for %s failed", date, exc_info=True)

        # Check for missed weekly compaction
        # Find last Sunday (or configured day) and check if weekly reflection exists
        days_since_weekly = (now.weekday() - self._weekly_day) % 7
        if days_since_weekly > 0:
            last_weekly_date = (now - timedelta(days=days_since_weekly)).strftime("%Y-%m-%d")
            last_weekly_dt = datetime.strptime(last_weekly_date, "%Y-%m-%d")
            week_num = last_weekly_dt.isocalendar()[1]
            week_label = f"{last_weekly_dt.year}-W{week_num:02d}"
            weekly_path = f"agnt-reflections/weekly-reflection_{week_label}.md"

            if not self._reader.exists(weekly_path):
                try:
                    log.debug("Catch-up: running missed weekly compaction for %s", week_label)
                    await self._reflection.run_weekly_reflection(last_weekly_date)
                    caught_up.append(f"weekly reflection ({week_label})")
                except Exception:
                    log.debug("Catch-up: weekly reflection failed", exc_info=True)

        if caught_up:
            log.debug("Catch-up completed: %s", ", ".join(caught_up))
            self._journal.append_observation(
                f"Startup catch-up: generated {', '.join(caught_up)}"
            )
        else:
            log.debug("Catch-up: nothing missed, all cycles up to date")

    async def _generate_retroactive_eod(self, date: str) -> None:
        """Generate an EOD report for a past date via the main agent.

        Similar to generate_eod_report() but uses the specific date's data
        instead of 'today', and triggers reflection + memory for that date.
        """
        # Journal for that date
        journal_doc = self._journal.get_entry(date)
        journal_text = journal_doc.content if journal_doc else "No journal entries."

        # Tasks (current state — best we can do retroactively)
        tasks = self._tasks.list_tasks()
        task_text = "\n".join(f"- {t['title']} [{t['status']}]" for t in tasks) or "No tasks."

        # Goals
        goals = self._coach.list_goals(status_filter="active")
        goals_text = "\n".join(f"- {g['title']}" for g in goals) or "No active goals."

        # Build context for the agent
        catchup_dynamic_ctx = (
            f"JOURNAL FOR {date}:\n{journal_text[:2000]}\n\n"
            f"ACTIVE TASKS:\n{task_text}\n\n"
            f"GOALS:\n{goals_text}"
        )

        task_instruction = (
            f"Generate an end-of-day report for {date} (retroactive catch-up). "
            "Include: day summary, completed tasks, still active, decisions, learnings, memory updates. "
            "Keep it concise. Output ONLY the report content."
        )

        try:
            eod = await self._agent.process_task(task=task_instruction, context=catchup_dynamic_ctx)
        except Exception as exc:
            log.error("Retroactive EOD for %s failed: %s", date, exc)
            self._journal.append_observation(f"Catch-up EOD for {date} failed: {exc}")
            raise

        # Save EOD report
        self._writer.write(
            f"journal/eod-report_{date}.md",
            f"---\ntitle: \"EOD Report — {date}\"\ndate: \"{date}\"\ntype: eod_report\nauthor: agent\nagent: ops-supervisor\ndescription: \"End-of-day summary (retroactive catch-up).\"\ncatch_up: true\n---\n\n{eod}",
        )

        # Log to agent observations
        self._journal.append_observation(f"Retroactive EOD report generated for {date}")

        # Trigger reflection for that date
        try:
            await self._reflection.run_daily_reflection(date)
        except Exception:
            log.debug("Catch-up: reflection for %s failed", date, exc_info=True)

        # Generate daily memory for that date
        if self._memory_engine:
            try:
                await self._memory_engine.generate_daily_memory(date)
            except Exception:
                log.debug("Catch-up: memory for %s failed", date, exc_info=True)

    async def _run_editor_pass(self) -> None:
        """Delegate daily wiki quality pass to the Editor subagent."""
        if not self._orchestrator:
            log.debug("Editor pass skipped: no orchestrator available")
            return

        try:
            result = await self._orchestrator.dispatch(
                agent_name="editor",
                task=(
                    "Daily wiki quality and reflection pass:\n\n"
                    "## Phase 1: Lint\n"
                    "Find broken links, orphans, stale articles, missing frontmatter across all KBs.\n\n"
                    "## Phase 2: Taxonomy\n"
                    "Reclassify misplaced articles. Note clusters needing new categories.\n\n"
                    "## Phase 3: Reflect\n"
                    "Review what changed since yesterday. For any significant structural changes "
                    "(new categories, merges, reframings, articles that became hubs):\n"
                    "- What decision was made?\n"
                    "- What alternatives existed?\n"
                    "- What bias might this introduce?\n"
                    "Create decision records in wiki/decisions/ for non-trivial changes.\n\n"
                    "## Phase 4: Curate\n"
                    "Update featured article. Check index stats.\n\n"
                    "Report findings concisely."
                ),
                context="Scheduled daily editor review with structural reflection.",
            )
            log.info("Editor pass completed: %s", result.content[:100])
            self._journal.append_observation(f"Daily editor pass completed: {result.content[:200]}")
            if self._heartbeat:
                await self._heartbeat.record_pulse("automation", "Daily editor pass completed")
        except Exception as exc:
            log.warning("Daily editor pass failed: %s", exc)
            if self._heartbeat:
                await self._heartbeat.record_pulse("error", f"Editor pass failed: {exc}")

    async def _loop(self) -> None:
        while self._running:
            try:
                now = datetime.now(UTC)
                today = now.strftime("%Y-%m-%d")
                hour = now.hour

                # Morning briefing
                if hour == self._morning_hour and self._last_morning != today:
                    self._last_morning = today
                    await self.generate_morning_briefing()

                # Daily Editor pass — lint, taxonomy, curation (runs after briefing)
                editor_hour = self._morning_hour + 1  # 1 hour after briefing
                if hour == editor_hour and self._last_editor != today:
                    self._last_editor = today
                    await self._run_editor_pass()

                # End-of-day report
                if hour == self._evening_hour and self._last_evening != today:
                    self._last_evening = today
                    await self.generate_eod_report()

                    # Weekly compaction — runs after EOD on the configured day
                    if now.weekday() == self._weekly_day and self._last_weekly != today:
                        self._last_weekly = today
                        await self.run_weekly_compaction()

                        # Weekly skill analysis — propose new skills from task patterns
                        if self._skillschool:
                            try:
                                proposals = await self._skillschool.analyze_patterns()
                                if proposals:
                                    log.info("Weekly skill analysis: %d proposals generated", len(proposals))
                                    self._journal.append_observation(
                                        f"Skill analysis: {len(proposals)} new skill proposal(s) from task patterns"
                                    )
                            except Exception:
                                log.debug("Weekly skill analysis failed", exc_info=True)

            except asyncio.CancelledError:
                break
            except Exception as exc:
                log.exception("Daily cycle error")
                if self._heartbeat:
                    try:
                        await self._heartbeat.record_pulse("error", f"Daily cycle: {exc}")
                    except Exception:
                        pass
            await asyncio.sleep(60)  # Check every minute
