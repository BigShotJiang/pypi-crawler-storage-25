"""Heartbeat: periodic background loop that checks state and logs observations.

Every pulse is recorded to SQLite for the cardiogram time series.
Deviations (blocked tasks, overdue items, errors) are flagged.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import aiosqlite

if TYPE_CHECKING:
    from agntspace.journal.service import JournalService
    from agntspace.tasks.service import TaskService

log = logging.getLogger(__name__)


class Heartbeat:
    """15-minute background loop that monitors state and logs to journal.

    Every pulse is persisted to SQLite so the UI can render a cardiogram.
    """

    def __init__(
        self,
        journal: JournalService,
        task_service: TaskService,
        db: aiosqlite.Connection | None = None,
        interval_seconds: int = 900,
        llm: object | None = None,
    ) -> None:
        self._journal = journal
        self._task_service = task_service
        self._db = db
        self._interval = interval_seconds
        self._llm = llm  # LLM provider for connectivity checks
        self._task: asyncio.Task | None = None  # type: ignore[type-arg]
        self._running = False

    async def init_schema(self) -> None:
        """Create heartbeat tables if they don't exist."""
        if not self._db:
            return
        await self._db.executescript("""
            CREATE TABLE IF NOT EXISTS heartbeat_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ts TEXT NOT NULL,
                pulse_type TEXT NOT NULL DEFAULT 'heartbeat',
                status TEXT NOT NULL DEFAULT 'normal',
                observations INTEGER NOT NULL DEFAULT 0,
                active_tasks INTEGER NOT NULL DEFAULT 0,
                blocked_tasks INTEGER NOT NULL DEFAULT 0,
                overdue_tasks INTEGER NOT NULL DEFAULT 0,
                details TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_heartbeat_ts ON heartbeat_log(ts);
        """)
        # Add pulse_type column if upgrading from older schema
        try:
            await self._db.execute("SELECT pulse_type FROM heartbeat_log LIMIT 1")
        except Exception:
            await self._db.execute("ALTER TABLE heartbeat_log ADD COLUMN pulse_type TEXT NOT NULL DEFAULT 'heartbeat'")
        await self._db.commit()

    def start(self) -> None:
        """Start the heartbeat background loop."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        log.debug("Heartbeat started (interval: %ds)", self._interval)

    def stop(self) -> None:
        """Stop the heartbeat background loop."""
        self._running = False
        if self._task:
            self._task.cancel()
            self._task = None
        log.debug("Heartbeat stopped")

    async def record_pulse(
        self,
        pulse_type: str,
        details: str | None = None,
        status: str | None = None,
    ) -> None:
        """Record any agent activity as a pulse on the cardiogram.

        Pulse types:
        - heartbeat: regular 15-min check (automatic)
        - chat: agent responded to a message
        - tool_use: agent used a tool (email, vault, task, etc.)
        - automation: briefing, EOD, reflection, memory generation
        - channel: handled a channel message
        - cron: cron job executed
        - error: LLM failure, integration error, etc. (auto-deviation)
        - startup: server startup pulse
        """
        if not self._db:
            return
        # Error pulses are always deviations
        if status is None:
            status = "deviation" if pulse_type == "error" else "normal"
        now = datetime.now(UTC).isoformat()
        try:
            await self._db.execute(
                "INSERT INTO heartbeat_log (ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks, details) "
                "VALUES (?, ?, ?, 0, 0, 0, 0, ?)",
                (now, pulse_type, status, details),
            )
            await self._db.commit()
        except Exception:
            log.debug("Failed to record %s pulse", pulse_type, exc_info=True)

    @property
    def is_running(self) -> bool:
        return self._running

    async def run_once(self) -> list[str]:
        """Run a single heartbeat cycle. Returns list of observations logged."""
        observations: list[str] = []
        now = datetime.now(UTC)
        now_str = now.strftime("%H:%M")

        active_count = 0
        blocked_count = 0
        overdue_count = 0

        # Check tasks
        try:
            tasks = self._task_service.list_tasks()
            blocked = [t for t in tasks if t.get("status") == "blocked"]
            in_review = [t for t in tasks if t.get("status") == "review"]
            active = [t for t in tasks if t.get("status") == "in_progress"]

            active_count = len(active)
            blocked_count = len(blocked)

            if blocked:
                names = ", ".join(t.get("title", "?") for t in blocked)
                observations.append(f"Heartbeat: {len(blocked)} blocked task(s): {names}")

            if in_review:
                names = ", ".join(t.get("title", "?") for t in in_review)
                observations.append(f"Heartbeat: {len(in_review)} task(s) awaiting review: {names}")

            if active:
                observations.append(f"Heartbeat: {len(active)} task(s) in progress")

        except Exception:
            log.debug("Heartbeat: task check failed", exc_info=True)

        # Check for overdue tasks
        try:
            tasks = self._task_service.list_tasks()
            today = now.strftime("%Y-%m-%d")
            for t in tasks:
                due = t.get("due", "")
                if due and due < today and t.get("status") not in ("done", "cancelled"):
                    overdue_count += 1
                    observations.append(f"Heartbeat: task '{t.get('title', '?')}' is overdue (due: {due})")
        except Exception:
            pass

        # Check LLM connectivity
        llm_error = None
        if self._llm:
            try:
                from agntspace.llm.base import Message as LLMMessage

                await self._llm.complete(
                    messages=[LLMMessage(role="user", content="ping")],
                    system="Reply with exactly: pong",
                    max_tokens=10,
                    temperature=0,
                )
            except Exception as exc:
                llm_error = str(exc)
                observations.append(f"Heartbeat: LLM unreachable — {llm_error}")
                log.warning("Heartbeat: LLM check failed: %s", llm_error)

        # Determine status
        if llm_error or overdue_count > 0 or blocked_count > 0:
            status = "deviation"
        else:
            status = "normal"

        # Log observations to agent file
        for obs in observations:
            try:
                self._journal.append_observation(obs)
            except Exception:
                log.debug("Heartbeat: failed to log observation", exc_info=True)

        # Record pulse to SQLite
        if self._db:
            details = "; ".join(observations) if observations else None
            try:
                await self._db.execute(
                    "INSERT INTO heartbeat_log (ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks, details) "
                    "VALUES (?, 'heartbeat', ?, ?, ?, ?, ?, ?)",
                    (now.isoformat(), status, len(observations), active_count, blocked_count, overdue_count, details),
                )
                await self._db.commit()
            except Exception:
                log.debug("Heartbeat: failed to record pulse", exc_info=True)

        if observations:
            log.info("Heartbeat: %d observations logged (%s)", len(observations), status)
        else:
            log.debug("Heartbeat: pulse at %s — normal", now_str)

        return observations

    async def get_history(self, hours: int = 24, limit: int = 200) -> list[dict]:
        """Get heartbeat history for the cardiogram chart."""
        if not self._db:
            return []
        from datetime import timedelta

        cutoff = (datetime.now(UTC) - timedelta(hours=hours)).isoformat()
        cursor = await self._db.execute(
            "SELECT ts, pulse_type, status, observations, active_tasks, blocked_tasks, overdue_tasks "
            "FROM heartbeat_log WHERE ts >= ? ORDER BY ts DESC LIMIT ?",
            (cutoff, limit),
        )
        rows = await cursor.fetchall()
        return [
            {
                "ts": row[0],
                "pulse_type": row[1],
                "status": row[2],
                "observations": row[3],
                "active_tasks": row[4],
                "blocked_tasks": row[5],
                "overdue_tasks": row[6],
            }
            for row in reversed(rows)  # chronological order
        ]

    async def get_deviations(self, limit: int = 50) -> list[dict]:
        """Get recent deviations (non-normal pulses)."""
        if not self._db:
            return []
        cursor = await self._db.execute(
            "SELECT ts, status, observations, blocked_tasks, overdue_tasks, details "
            "FROM heartbeat_log WHERE status != 'normal' ORDER BY ts DESC LIMIT ?",
            (limit,),
        )
        rows = await cursor.fetchall()
        return [
            {
                "ts": row[0],
                "status": row[1],
                "observations": row[2],
                "blocked_tasks": row[3],
                "overdue_tasks": row[4],
                "details": row[5],
            }
            for row in rows
        ]

    async def get_status(self) -> dict:
        """Get current heartbeat status summary."""
        last_pulse = None
        total_pulses = 0
        total_deviations = 0

        if self._db:
            cursor = await self._db.execute(
                "SELECT ts, status FROM heartbeat_log ORDER BY ts DESC LIMIT 1"
            )
            row = await cursor.fetchone()
            if row:
                last_pulse = {"ts": row[0], "status": row[1]}

            cursor = await self._db.execute("SELECT COUNT(*) FROM heartbeat_log")
            total_pulses = (await cursor.fetchone())[0]

            cursor = await self._db.execute(
                "SELECT COUNT(*) FROM heartbeat_log WHERE status != 'normal'"
            )
            total_deviations = (await cursor.fetchone())[0]

        return {
            "running": self._running,
            "interval_seconds": self._interval,
            "last_pulse": last_pulse,
            "total_pulses": total_pulses,
            "total_deviations": total_deviations,
        }

    def _seconds_until_next_slot(self) -> float:
        """Calculate seconds until the next clock-aligned slot.

        With a 15-minute interval, pulses land on :00, :15, :30, :45.
        With a 30-minute interval, pulses land on :00, :30.
        """
        now = datetime.now(UTC)
        interval_min = self._interval // 60 or 1
        current_min = now.minute
        next_slot = ((current_min // interval_min) + 1) * interval_min
        seconds_into_minute = now.second + now.microsecond / 1_000_000
        wait = (next_slot - current_min) * 60 - seconds_into_minute
        if wait <= 0:
            wait += self._interval
        return wait

    async def _loop(self) -> None:
        """Main heartbeat loop — clock-aligned pulses.

        Pulses land on clean clock boundaries (e.g., 08:00, 08:15, 08:30, 08:45).
        """
        # Immediate pulse on startup, then align to clock
        try:
            await self.run_once()
        except Exception:
            log.exception("Heartbeat startup pulse failed")

        # Wait until the first aligned slot
        wait = self._seconds_until_next_slot()
        log.debug("Heartbeat: next pulse in %.0fs (aligned to clock)", wait)
        await asyncio.sleep(wait)

        while self._running:
            try:
                await self.run_once()
            except asyncio.CancelledError:
                break
            except Exception:
                log.exception("Heartbeat error")
            # Sleep until next aligned slot
            await asyncio.sleep(self._seconds_until_next_slot())
