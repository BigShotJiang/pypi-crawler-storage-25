"""Fixture-driven tests for Webhooks resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_webhooks.lib.testing import create_recording_transport
from timeback_webhooks.resources.webhooks import WebhooksResource

FIXTURES_DIR = fixtures_dir("webhooks", "webhooks")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": WebhooksResource(transport), "calls": transport.calls}


test_webhooks_webhooks_fixtures = make_resource_fixture_test(
    name="webhooks > webhooks",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
