"""Fixture-driven tests for Webhook Filters resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_webhooks.lib.testing import create_recording_transport
from timeback_webhooks.resources.webhook_filters import WebhookFiltersResource

FIXTURES_DIR = fixtures_dir("webhooks", "webhook-filters")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": WebhookFiltersResource(transport), "calls": transport.calls}


test_webhooks_webhook_filters_fixtures = make_resource_fixture_test(
    name="webhooks > webhook-filters",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
