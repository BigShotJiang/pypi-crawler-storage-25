"""
Webhooks Input Types

Pydantic models for Webhooks API request validation.
Mirrors the TypeScript SDK's Zod schemas.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, HttpUrl

from timeback_common import NonEmptyString  # noqa: TC001


class WebhookCreateInput(BaseModel):
    """Input for creating a webhook."""

    name: NonEmptyString
    target_url: HttpUrl = Field(alias="targetUrl")
    secret: NonEmptyString
    active: bool
    sensor: str | None = None
    description: str | None = None

    model_config = {"populate_by_name": True}


WebhookUpdateInput = WebhookCreateInput


class WebhookFilterCreateInput(BaseModel):
    """Input for creating a webhook filter."""

    webhook_id: NonEmptyString = Field(alias="webhookId")
    filter_key: NonEmptyString = Field(alias="filterKey")
    filter_value: NonEmptyString = Field(alias="filterValue")
    filter_type: Literal["string", "number", "boolean"] = Field(alias="filterType")
    filter_operator: Literal[
        "eq",
        "neq",
        "gt",
        "gte",
        "lt",
        "lte",
        "contains",
        "notContains",
        "in",
        "notIn",
        "startsWith",
        "endsWith",
        "regexp",
    ] = Field(alias="filterOperator")
    active: bool

    model_config = {"populate_by_name": True}


WebhookFilterUpdateInput = WebhookFilterCreateInput
