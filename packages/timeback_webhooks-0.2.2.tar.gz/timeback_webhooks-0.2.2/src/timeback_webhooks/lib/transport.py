"""
Webhooks Transport Layer

HTTP transport for Webhooks API communication.
Webhooks use the same infrastructure as other clients — no custom
pagination is needed since webhook endpoints don't paginate.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from timeback_common import BaseTransport, TokenManager, WebhookPaths

if TYPE_CHECKING:
    import httpx


class Transport(BaseTransport):
    """HTTP transport layer for Webhooks API communication."""

    def __init__(
        self,
        *,
        base_url: str,
        token_manager: TokenManager | None = None,
        paths: WebhookPaths,
        timeout: float = 30.0,
        http_client: httpx.AsyncClient | None = None,
        no_auth: bool = False,
    ) -> None:
        super().__init__(
            base_url=base_url,
            timeout=timeout,
            token_manager=token_manager,
            http_client=http_client,
            no_auth=no_auth,
        )
        self.paths = paths


__all__ = ["Transport"]
