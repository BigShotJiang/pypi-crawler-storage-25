# timeback-webhooks

Timeback Webhooks client for managing webhook registrations and filters.

## Installation

```bash
pip install timeback-webhooks
```

## Usage

```python
from timeback_webhooks import WebhooksClient

client = WebhooksClient(
    env="staging",
    client_id="your-client-id",
    client_secret="your-client-secret",
)

# Create a webhook
webhook = await client.webhooks.create({
    "name": "My Webhook",
    "targetUrl": "https://myapp.example.com/events",
    "secret": "my-shared-secret",
    "active": True,
})

# Add a filter
filter = await client.webhook_filters.create({
    "webhookId": webhook.id,
    "filterKey": "type",
    "filterValue": "ActivityEvent",
    "filterType": "string",
    "filterOperator": "eq",
    "active": True,
})
```
