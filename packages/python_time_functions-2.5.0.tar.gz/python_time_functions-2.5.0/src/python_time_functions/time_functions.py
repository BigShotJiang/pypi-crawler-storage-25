"""
################################################################################
#                         time_functions                                       #
#                                                                              #
# Description:                                                                 #
# Frequently used python time conversions                                      #
#                                                                              #
# Author:                                                                      #
# Corne Bester <corne.bester@gmail.com>                                        #
#                                                                              #
# This program is free software: you can redistribute it and/or modify         #
# it under the terms of the GNU General Public License as published by         #
# the Free Software Foundation, either version 2 of the License, or            #
# (at your option) any later version.                                          #
#                                                                              #
# This program is distributed in the hope that it will be useful,              #
# but WITHOUT ANY WARRANTY; without even the implied warranty of               #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                #
# GNU General Public License for more details.                                 #
#                                                                              #
# You should have received a copy of the GNU General Public License            #
# along with this program. If not, see <https://www.gnu.org/licenses/>.        #
################################################################################

"""

import logging
from datetime import datetime, timezone

logger = logging.getLogger(__name__)


def get_timestamp_iso8601_millis(datetime_obj):
    """
    Take a UTC datetime object as input. E.g.:

    obj = datetime.now(timezone.utc)

    Returns an UTC ISO8601 formatted timestamp with milliseconds from passed datetime object

    https://stackoverflow.com/questions/10286204/what-is-the-right-json-date-format
    """
    utc_iso = datetime_obj.replace(tzinfo=None).isoformat(timespec="milliseconds") + "Z"
    return utc_iso


def get_timestamp_iso8601_micros(datetime_obj):
    """
    Take a UTC datetime object as input. E.g.:

    obj = datetime.now(timezone.utc)

    Returns an UTC ISO8601 formatted timestamp with microseconds from passed datetime object

    https://stackoverflow.com/questions/10286204/what-is-the-right-json-date-format
    """
    utc_iso = datetime_obj.replace(tzinfo=None).isoformat() + "Z"
    return utc_iso


def get_timestamp_iso8601(datetime_obj):
    """
    Take a UTC datetime object as input. E.g.:

    obj = datetime.now(timezone.utc)

    Returns an UTC ISO8601 formatted timestamp with seconds from passed datetime object

    https://stackoverflow.com/questions/10286204/what-is-the-right-json-date-format
    """
    utc_iso = datetime_obj.replace(tzinfo=None).isoformat(timespec="seconds") + "Z"
    return utc_iso


def get_timestamp_unix(datetime_obj):
    """
    Returns an UTC timestamp as a seconds float with sub seconds as the decimal values
    """
    if datetime_obj.tzname() == "UTC":
        utc_unix_time = (
            datetime_obj.timestamp()
        )  # object to seconds float type with subseconds as decimal value
        return int(utc_unix_time)
    elif datetime_obj.tzname() is None:
        utc_unix_time = datetime_obj.replace(
            tzinfo=timezone.utc
        ).timestamp()  # object to seconds float type with subseconds as decimal value
        return int(utc_unix_time)
    else:
        raise ValueError("Unexpected value, not supported")


def get_timestamp_unix_subseconds_decimal(datetime_obj):
    """
    Returns an UTC timestamp as a seconds float with sub seconds as the decimal value
    """
    if datetime_obj.tzname() == "UTC":
        utc_unix_time = (
            datetime_obj.timestamp()
        )  # object to seconds float type with subseconds as decimal value
        return utc_unix_time
    elif datetime_obj.tzname() is None:
        utc_unix_time = datetime_obj.replace(
            tzinfo=timezone.utc
        ).timestamp()  # object to seconds float type with subseconds as decimal value
        return utc_unix_time
    else:
        raise ValueError("Unexpected value, not supported")


def get_timestamp_unix_millis(datetime_obj):
    """
    Returns an UTC timestamp integer as milliseconds
    """
    if datetime_obj.tzname() == "UTC":
        utc_unix_time = (
            datetime_obj.timestamp()
        )  # object to seconds float type with subseconds as decimal value
        utc_unix_time_millis = utc_unix_time * 1e3  # milliseconds
        return int(utc_unix_time_millis)
    elif datetime_obj.tzname() is None:
        utc_unix_time = datetime_obj.replace(
            tzinfo=timezone.utc
        ).timestamp()  # object to seconds float type with subseconds as decimal value
        utc_unix_time_millis = utc_unix_time * 1e3  # milliseconds
        return int(utc_unix_time_millis)
    else:
        raise ValueError("Unexpected value, not supported")


def get_timestamp_unix_micros(datetime_obj):
    """
    Returns an UTC timestamp integer as microseconds
    """
    if datetime_obj.tzname() == "UTC":
        utc_unix_time = (
            datetime_obj.timestamp()
        )  # object to seconds float type with subseconds as decimal value
        utc_unix_time_micros = utc_unix_time * 1e6  # microseconds
        return int(utc_unix_time_micros)
    elif datetime_obj.tzname() is None:
        utc_unix_time = datetime_obj.replace(
            tzinfo=timezone.utc
        ).timestamp()  # object to seconds float type with subseconds as decimal value
        utc_unix_time_micros = utc_unix_time * 1e6  # microseconds
        return int(utc_unix_time_micros)
    else:
        raise ValueError("Unexpected value, not supported")


def convert_iso_string_to_datetime_obj(iso_string):
    """
    Returns a datetime obj from an ISO 8601 timestamp with Zulu /UTC suffix
    """
    remove_zulu = iso_string.removesuffix("Z")
    datetime_obj = datetime.fromisoformat(remove_zulu)  # string to obj
    datetime_obj_to_utc = datetime_obj.replace(tzinfo=timezone.utc)
    return datetime_obj_to_utc


def convert_unix_to_datetime_obj(utc_unix_time_var):
    """
    Returns a datetime obj from unix timestamp.
    accept:
        int of seconds, milliseconds or microseconds
        float of seconds with subseconds millis or micros
    e.g. 1739738432.888289 OR 1739738432.888 OR 1739738432
    """
    try:
        if isinstance(utc_unix_time_var, int):
            if len(str(utc_unix_time_var)) == 10:
                datetime_obj = datetime.fromtimestamp(
                    utc_unix_time_var, tz=timezone.utc
                )  # to obj
                return datetime_obj
            elif len(str(utc_unix_time_var)) == 13:
                datetime_obj = datetime.fromtimestamp(
                    utc_unix_time_var / 1000, tz=timezone.utc
                )  # to obj
                return datetime_obj
            elif len(str(utc_unix_time_var)) == 16:
                datetime_obj = datetime.fromtimestamp(
                    utc_unix_time_var / 1000000, tz=timezone.utc
                )  # to obj
                return datetime_obj
            else:
                logger.warning("incorrect length. Must be 10, 13 or 16 digits")
        elif isinstance(utc_unix_time_var, float):
            datetime_obj = datetime.fromtimestamp(
                utc_unix_time_var, tz=timezone.utc
            )  # to obj
            return datetime_obj
    except Exception as e2:
        logger.exception(e2)


def timestamp_parser_psql_millis(timestamp):
    """
    * Function to convert common timestamps for use with postgresql query with millisecond precision.
    * Strips higher precision.
    * does not fix/sanitize bad formats
    Accept inputs:
    * ISO8601/rfc3399 in second, millisecond or microsecond precision
    * int Unix time (epoch) in seconds, milliseconds and microseconds
    * float Unix time (epoch) in seconds with milliseconds and microseconds as decimal. e.g. 1742742625.002908
    """
    if isinstance(timestamp, int):
        if len(str(timestamp)) == 10:
            return timestamp
        elif len(str(timestamp)) == 13:
            timestamp = timestamp / 1000
            return timestamp
        elif len(str(timestamp)) == 16:
            timestamp = str(timestamp / 1000000)[:14]
            return float(timestamp)
    elif isinstance(timestamp, float):
        decimal_index = str.index(str(timestamp), ".")
        if decimal_index == 10:
            timestamp = str(timestamp)[:14]  # remove microsecond precision
            return float(timestamp)
        else:
            logger.error("Non-standard format {timestamp}")
    elif isinstance(timestamp, str):
        if len(timestamp) == 20:
            obj_from_iso = convert_iso_string_to_datetime_obj(timestamp)
            unix_with_subseconds = get_timestamp_unix_subseconds_decimal(obj_from_iso)
            timestamp = unix_with_subseconds
            return timestamp
        if len(timestamp) == 24:
            obj_from_iso = convert_iso_string_to_datetime_obj(timestamp)
            unix_with_subseconds = get_timestamp_unix_subseconds_decimal(obj_from_iso)
            timestamp = unix_with_subseconds
            return timestamp
        elif len(timestamp) == 27:
            obj_from_iso = convert_iso_string_to_datetime_obj(timestamp)
            unix_with_subseconds = get_timestamp_unix_subseconds_decimal(obj_from_iso)
            timestamp = str(unix_with_subseconds)[:14]
            return float(timestamp)


def timestamp_sanitizer_psql(input):
    """
    Normalize unix timestamps to postgresl friendly float with millisecond decimals. 14 digits
    Attemps to fix/sanitize bad timestamp format I dreamed up like
    >>> time_functions.timestamp_sanitizer_psql(1729755232184)
    1729755232.184
    >>> time_functions.timestamp_sanitizer_psql(1729765227856.3)
    1729765227.856
    >>> time_functions.timestamp_sanitizer_psql(1729765228327.051)
    1729765228.327
    handle timestamp as:
    unix micros or millis in decimal format
    unix millis or micros in unix format
    iso8601
    """
    try:
        if isinstance(input, int):
            if len(str(input)) == 10:
                logger.debug("Not millsecond precision: %s", input)
                return input
            elif len(str(input)) == 13:
                normalized = str((input / 1000))[:14]
                logger.debug(
                    "Normalizing timestamp for postgresql from %s to %s",
                    input,
                    normalized,
                )
                return float(normalized)
            elif len(str(input)) == 16:
                normalized = str(input / 1000000)[:14]
                logger.debug(
                    "Normalizing timestamp for postgresql from %s to %s",
                    input,
                    normalized,
                )
                return float(normalized)
        elif isinstance(input, float):
            # elif '.' in str(input):
            decimal_index = str.index(str(input), ".")
            if decimal_index == 13:
                normalized = str(input / 1000)[:14]  # remove microsecond precision
                logger.debug(
                    "Normalizing timestamp for postgresql from %s to %s",
                    input,
                    normalized,
                )
                return float(normalized)
            elif decimal_index == 10:
                normalized = str(input)[:14]  # remove microsecond precision
                logger.debug(
                    "Normalizing timestamp for postgresql from %s to %s",
                    input,
                    normalized,
                )
                return float(normalized)
        elif isinstance(input, str):
            if len(input) == 20:
                obj_from_iso = convert_iso_string_to_datetime_obj(input)
                unix_with_subseconds = get_timestamp_unix_subseconds_decimal(
                    obj_from_iso
                )
                normalized = unix_with_subseconds
                logger.debug(
                    "Normalizing timestamp for postgresql from %s to %s",
                    input,
                    normalized,
                )
                return float(normalized)
            if len(input) == 24:
                obj_from_iso = convert_iso_string_to_datetime_obj(input)
                unix_with_subseconds = get_timestamp_unix_subseconds_decimal(
                    obj_from_iso
                )
                normalized = unix_with_subseconds
                logger.debug(
                    "Normalizing timestamp for postgresql from %s to %s",
                    input,
                    normalized,
                )
                return float(normalized)
            elif len(input) == 27:
                obj_from_iso = convert_iso_string_to_datetime_obj(input)
                unix_with_subseconds = get_timestamp_unix_subseconds_decimal(
                    obj_from_iso
                )
                normalized = str(unix_with_subseconds)[:14]
                logger.debug(
                    "Normalizing timestamp for postgresql from %s to %s",
                    input,
                    normalized,
                )
                return float(normalized)
        else:
            logger.error("Unexcpected timestamp format")
    except Exception as msg:
        logger.exception(msg)
