# Readme

Common Python functions for time handling

```shell
pip install --upgrade python_time_functions
```

```python
from datetime import datetime, timezone
from python_time_functions import time_functions as tf

timestamp = datetime.now(timezone.utc)
unix_millis = tf.get_timestamp_unix_millis(timestamp)  # create unix timestamp from obj above

```

## local dev

```shell
pip install -r requirements.txt
```

## test

```shell
pytest
```

### other

```shell
pip3 freeze > requirements.txt
```

