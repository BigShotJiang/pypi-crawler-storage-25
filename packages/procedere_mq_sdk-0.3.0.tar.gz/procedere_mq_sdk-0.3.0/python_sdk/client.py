from __future__ import annotations

import base64
from datetime import datetime, timezone
from typing import Any

import requests


class LiteMQError(Exception):
    pass


class QueueEmptyError(LiteMQError):
    pass


class NotFoundError(LiteMQError):
    pass


class Producer:
    def __init__(self, client: "LiteMQClient", queue: str) -> None:
        queue = queue.strip()
        if not queue:
            raise ValueError("queue is required")
        self.client = client
        self.queue = queue

    def publish(
        self,
        payload: dict[str, Any] | list[Any] | str | int | float | bool | None = None,
        *,
        job_id: str | None = None,
        max_retry: int | None = None,
        run_at: datetime | None = None,
    ) -> dict[str, Any]:
        return self.client.enqueue(
            self.queue,
            payload,
            job_id=job_id,
            max_retry=max_retry,
            run_at=run_at,
        )


class Consumer:
    def __init__(self, client: "LiteMQClient", queue: str) -> None:
        queue = queue.strip()
        if not queue:
            raise ValueError("queue is required")
        self.client = client
        self.queue = queue

    def receive(self) -> dict[str, Any]:
        return self.client.dequeue(self.queue)

    def ack(self, job_or_id: dict[str, Any] | str) -> dict[str, Any]:
        return self.client.ack(_extract_job_id(job_or_id))

    def fail(self, job_or_id: dict[str, Any] | str) -> dict[str, Any]:
        return self.client.fail(_extract_job_id(job_or_id))


class LiteMQClient:
    def __init__(
        self,
        base_url: str,
        timeout: float = 10.0,
        api_key: str | None = None,
        username: str | None = None,
        password: str | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.api_key = api_key.strip() if api_key else None
        self.username = username.strip() if username else None
        self.password = password
        self.session = requests.Session()

    def producer(self, queue: str) -> Producer:
        return Producer(self, queue)

    def consumer(self, queue: str) -> Consumer:
        return Consumer(self, queue)

    def enqueue(
        self,
        queue: str,
        payload: dict[str, Any] | list[Any] | str | int | float | bool | None = None,
        *,
        job_id: str | None = None,
        max_retry: int | None = None,
        run_at: datetime | None = None,
    ) -> dict[str, Any]:
        if not queue or not queue.strip():
            raise ValueError("queue is required")
        body: dict[str, Any] = {"queue": queue}
        if payload is not None:
            body["payload"] = payload
        if job_id:
            body["id"] = job_id
        if max_retry is not None:
            body["max_retry"] = max_retry
        if run_at is not None:
            body["run_at"] = self._format_datetime(run_at)
        return self._request("POST", "/enqueue", json=body, expected_status=201)

    def dequeue(self, queue: str) -> dict[str, Any]:
        if not queue or not queue.strip():
            raise ValueError("queue is required")
        return self._request("GET", "/dequeue", params={"queue": queue}, expected_status=200)

    def ack(self, job_id: str) -> dict[str, Any]:
        if not job_id or not job_id.strip():
            raise ValueError("job_id is required")
        return self._request("POST", "/ack", json={"id": job_id}, expected_status=200)

    def fail(self, job_id: str) -> dict[str, Any]:
        if not job_id or not job_id.strip():
            raise ValueError("job_id is required")
        return self._request("POST", "/fail", json={"id": job_id}, expected_status=200)

    def _request(self, method: str, path: str, expected_status: int, **kwargs: Any) -> dict[str, Any]:
        url = f"{self.base_url}{path}"
        headers = dict(kwargs.pop("headers", {}) or {})
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        elif self.username and self.password:
            token = base64.b64encode(f"{self.username}:{self.password}".encode("utf-8")).decode("ascii")
            headers["Authorization"] = f"Basic {token}"
        response = self.session.request(method, url, timeout=self.timeout, headers=headers, **kwargs)

        if response.status_code == 204:
            raise QueueEmptyError("queue empty")
        if response.status_code == 404:
            raise NotFoundError(self._extract_error(response))
        if response.status_code != expected_status:
            raise LiteMQError(self._extract_error(response))

        if not response.content:
            return {}

        data = response.json()
        if isinstance(data, dict):
            return data
        return {"data": data}

    @staticmethod
    def _extract_error(response: requests.Response) -> str:
        try:
            payload = response.json()
        except ValueError:
            return response.text or response.reason
        if isinstance(payload, dict):
            message = payload.get("error")
            if isinstance(message, str) and message.strip():
                return message
        return response.text or response.reason

    @staticmethod
    def _format_datetime(value: datetime) -> str:
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _extract_job_id(job_or_id: dict[str, Any] | str) -> str:
    if isinstance(job_or_id, dict):
        job_id = job_or_id.get("id")
        if isinstance(job_id, str) and job_id.strip():
            return job_id
        raise ValueError("job id is required")
    if isinstance(job_or_id, str) and job_or_id.strip():
        return job_or_id
    raise ValueError("job id is required")
