/*
    Copyright 2017 Zheyong Fan and GPUMD development team
    This file is part of GPUMD.
    GPUMD is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    GPUMD is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with GPUMD.  If not, see <http://www.gnu.org/licenses/>.
*/

#pragma once
#include <vector>

class EwaldNep
{
public:
  EwaldNep();
  ~EwaldNep();
  void initialize(const double alpha_input);
  void find_force(
    const int N,
    const double* box,
    const std::vector<double>& charge,
    const std::vector<double>& position_per_atom,
    std::vector<double>& D_real,
    std::vector<double>& force_per_atom,
    std::vector<double>& virial_per_atom,
    std::vector<double>& potential_per_atom);
private:
    int num_kpoints_max = 1;
    int num_kpoints;
    double alpha = 0.5; // 1 / (2 Angstrom)
    double alpha_factor = 1.0; // 1 / (4 * alpha * alpha)
    std::vector<double> kx;
    std::vector<double> ky;
    std::vector<double> kz;
    std::vector<double> G;
    std::vector<double> S_real;
    std::vector<double> S_imag;
    void find_k_and_G(const double* box);
};
