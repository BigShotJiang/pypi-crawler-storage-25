"""Internal ASGI dispatch — invoke HawkAPI routes from MCP tool calls."""

from __future__ import annotations

import json
from typing import Any
from urllib.parse import quote

from hawkapi_mcp._errors import INVALID_PARAMS, RpcError


def _reject_control_chars(value: str, where: str) -> None:
    if "\r" in value or "\n" in value or "\x00" in value:
        raise RpcError(INVALID_PARAMS, f"control characters in {where}")


async def dispatch_tool(
    app: Any,
    method: str,
    path: str,
    arguments: dict[str, Any],
    *,
    client: tuple[str, int] | None = None,
) -> tuple[int, bytes, dict[str, str]]:
    """Call a HawkAPI route via raw ASGI and return ``(status, body, headers)``.

    ``arguments`` follows the input-schema namespacing built by
    :func:`hawkapi_mcp._tools.openapi_to_tools`: ``path.foo``, ``query.foo``,
    ``header.foo``, and an optional ``body`` field (rendered as JSON).
    """
    # Substitute path parameters: ``/users/{user_id}`` + ``path.user_id=42`` → ``/users/42``
    resolved_path = path
    query_pairs: list[str] = []
    headers: list[tuple[bytes, bytes]] = []
    body_bytes = b""

    for key, value in arguments.items():
        if key == "body":
            if isinstance(value, (bytes, bytearray)):
                body_bytes = bytes(value)
            else:
                body_bytes = json.dumps(value).encode("utf-8")
            if body_bytes:
                headers.append((b"content-type", b"application/json"))
            continue
        if "." not in key:
            continue
        loc, name = key.split(".", 1)
        rendered = "" if value is None else str(value)
        _reject_control_chars(rendered, "argument")
        if loc == "path":
            encoded = quote(rendered, safe="")
            resolved_path = resolved_path.replace(f"{{{name}}}", encoded)
        elif loc == "query":
            query_pairs.append(f"{quote(name, safe='')}={quote(rendered, safe='')}")
        elif loc == "header":
            _reject_control_chars(name, "header name")
            try:
                name_bytes = name.lower().encode("latin-1")
                value_bytes = rendered.encode("latin-1")
            except UnicodeEncodeError as exc:
                raise RpcError(INVALID_PARAMS, "invalid header encoding") from exc
            headers.append((name_bytes, value_bytes))

    # Any unfilled placeholders are a hard error — never let `{...}` leak to ASGI.
    if "{" in resolved_path or "}" in resolved_path:
        raise RpcError(INVALID_PARAMS, "missing path parameter")

    if body_bytes:
        headers.append((b"content-length", str(len(body_bytes)).encode("latin-1")))

    scope: dict[str, Any] = {
        "type": "http",
        "asgi": {"version": "3.0"},
        "http_version": "1.1",
        "method": method.upper(),
        "scheme": "http",
        "path": resolved_path,
        "raw_path": resolved_path.encode("utf-8"),
        "query_string": "&".join(query_pairs).encode("latin-1"),
        "headers": headers,
        "client": client if client is not None else ("mcp-bridge", 0),
        "server": ("127.0.0.1", 80),
        "root_path": "",
        "app": app,
    }

    received = {"done": False}

    async def receive() -> dict[str, Any]:
        if received["done"]:
            return {"type": "http.disconnect"}
        received["done"] = True
        return {"type": "http.request", "body": body_bytes, "more_body": False}

    status_holder: dict[str, Any] = {"status": 500, "headers": []}
    body_chunks: list[bytes] = []

    async def send(message: dict[str, Any]) -> None:
        msg_type = message.get("type")
        if msg_type == "http.response.start":
            status_holder["status"] = int(message.get("status", 500))
            status_holder["headers"] = list(message.get("headers", []))
        elif msg_type == "http.response.body":
            chunk = message.get("body", b"")
            if isinstance(chunk, (bytes, bytearray)):
                body_chunks.append(bytes(chunk))

    await app(scope, receive, send)

    resp_headers: dict[str, str] = {
        k.decode("latin-1"): v.decode("latin-1") for k, v in status_holder["headers"]
    }
    return status_holder["status"], b"".join(body_chunks), resp_headers


__all__ = ["dispatch_tool"]
