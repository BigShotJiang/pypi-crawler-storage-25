"""hawkapi-mcp — MCP (Model Context Protocol) server for HawkAPI.

Exports every HawkAPI route as an MCP tool. Plug a compatible AI agent into
the mounted endpoint and it can call your API directly.

```python
from hawkapi import HawkAPI
from hawkapi_mcp import mount_mcp

app = HawkAPI()
mount_mcp(app)  # serves POST /mcp
```
"""

from __future__ import annotations

__version__ = "0.2.0"

from hawkapi_mcp._mount import mount_mcp
from hawkapi_mcp._server import MCP_PROTOCOL_VERSION, MCPServer

__all__ = [
    "MCPServer",
    "MCP_PROTOCOL_VERSION",
    "__version__",
    "mount_mcp",
]
