"""HTTP transport for MCP — mounts a JSON-RPC endpoint on a HawkAPI app."""

from __future__ import annotations

import json
import warnings
from typing import Any

from hawkapi.requests.request import Request
from hawkapi.responses.json_response import JSONResponse
from hawkapi.responses.response import Response

from hawkapi_mcp._server import MCPServer

_MAX_JSON_DEPTH = 64


def mount_mcp(
    app: Any,
    *,
    path: str = "/mcp",
    server_name: str | None = None,
    server_version: str | None = None,
    include_only: set[str] | None = None,
    exclude: set[str] | None = None,
    dependencies: list[Any] | None = None,
    max_batch: int = 100,
    max_body_bytes: int = 1_048_576,
) -> MCPServer:
    """Mount an MCP JSON-RPC endpoint at *path*.

    Every HawkAPI route (except those in *exclude* or outside *include_only*)
    becomes an MCP tool. ``POST {path}`` accepts a single JSON-RPC request or
    a batch and returns the matching response shape.

    Parameters
    ----------
    dependencies:
        Optional list of HawkAPI dependencies (e.g. auth) attached to the
        ``POST {path}`` route. If you do not pass *include_only* AND not
        *exclude*, a warning is emitted because the endpoint exposes every
        route — wire authentication here, or filter explicitly.
    max_batch:
        Maximum number of items in a JSON-RPC batch request. Defaults to 100.
    max_body_bytes:
        Maximum accepted request body size in bytes. Defaults to 1 MiB.

    Example::

        from hawkapi import HawkAPI
        from hawkapi_mcp import mount_mcp

        app = HawkAPI()

        @app.get("/users/{user_id:int}")
        async def get_user(user_id: int): ...

        mount_mcp(app)  # serves /mcp
    """
    if include_only is None and exclude is None:
        warnings.warn(
            "mount_mcp() exposes every route by default. "
            "Pass include_only=... or exclude=... to limit attack surface, "
            "and dependencies=[...] to require auth on /mcp.",
            stacklevel=2,
        )

    server = MCPServer(
        app,
        server_name=server_name,
        server_version=server_version,
        include_only=include_only,
        exclude=exclude,
    )

    async def mcp_handler(request: Request) -> Response | JSONResponse:
        if request.method.upper() != "POST":
            return _error_response(
                "Only POST is supported on this MCP endpoint.",
                status=405,
            )

        # Reject oversized bodies early via Content-Length when honest.
        content_length = request.headers.get("content-length")
        if content_length is not None:
            try:
                declared = int(content_length)
            except ValueError:
                return _error_response("Invalid Content-Length.", status=400)
            if declared > max_body_bytes:
                return _error_response("Request body too large.", status=413)

        body = await request.body()
        if len(body) > max_body_bytes:
            return _error_response("Request body too large.", status=413)

        try:
            payload: Any = json.loads(body)
        except (json.JSONDecodeError, UnicodeDecodeError):
            return _error_response("Malformed JSON body.")
        except RecursionError:
            return _error_response("JSON nesting too deep.")

        if _json_depth(payload) > _MAX_JSON_DEPTH:
            return _error_response("JSON nesting too deep.")

        if isinstance(payload, list):
            if len(payload) > max_batch:
                return _error_response("Batch too large.", status=400)
            responses: list[dict[str, Any]] = []
            for item in payload:
                resp = await server.handle(item if isinstance(item, dict) else {})
                if resp is not None:
                    responses.append(resp)
            return JSONResponse(responses)
        if isinstance(payload, dict):
            resp = await server.handle(payload)
            if resp is None:
                return Response(status_code=204)
            return JSONResponse(resp)
        return _error_response("Body must be a JSON object or array.")

    app.add_route(
        path,
        mcp_handler,
        methods={"POST"},
        include_in_schema=False,
        dependencies=dependencies,
    )
    return server


def _json_depth(value: Any, _depth: int = 0) -> int:
    """Return the maximum nesting depth of a JSON-decoded value.

    Iterative-ish recursion bounded by Python's stack; the caller still wraps
    json.loads in ``except RecursionError`` for the parsing side.
    """
    if _depth > _MAX_JSON_DEPTH:
        return _depth
    if isinstance(value, dict):
        if not value:
            return _depth
        return max(_json_depth(v, _depth + 1) for v in value.values())
    if isinstance(value, list):
        if not value:
            return _depth
        return max(_json_depth(v, _depth + 1) for v in value)
    return _depth


def _error_response(message: str, *, status: int = 400) -> JSONResponse:
    return JSONResponse(
        {"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": message}},
        status_code=status,
    )


__all__ = ["mount_mcp"]
