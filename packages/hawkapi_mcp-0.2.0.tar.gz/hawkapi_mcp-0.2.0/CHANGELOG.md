# Changelog

## 0.2.0 — 2026-05-16

- URL-encode path and query params; reject CR/LF/NUL in argument and header values.
- Reject unfilled `{...}` path placeholders.
- `mount_mcp(dependencies=...)` forwards auth dependencies to `POST /mcp`.
- `max_batch` (default 100) and `max_body_bytes` (default 1 MiB) limits on `/mcp`.
- JSON nesting depth capped at 64.
- Warn at mount time when neither `include_only` nor `exclude` is set.
- `asyncio.Lock` around `tools/list` cache population.
- `dispatch_tool(client=...)`; default scope client is now `("mcp-bridge", 0)` instead of `127.0.0.1`.

## [0.1.0] - 2026-05-16

Initial release.

### Added

- `mount_mcp(app, path="/mcp", ...)` — adds a JSON-RPC endpoint that exposes every HawkAPI route as an MCP tool.
- `MCPServer` — transport-agnostic JSON-RPC core (initialize / ping / tools/list / tools/call / notifications).
- OpenAPI 3.1 → tool conversion. `operationId` is the tool name; missing IDs synthesised from method + path.
- Path / query / header / cookie params + JSON body merged into a single input schema with namespaced keys.
- `include_only` / `exclude` filters by tool name.
- Batch JSON-RPC requests supported.
- Internal ASGI dispatch — tool calls run against the same app instance, so all middleware / auth / DI apply.

[0.1.0]: https://github.com/ashimov/hawkapi-mcp/releases/tag/v0.1.0
