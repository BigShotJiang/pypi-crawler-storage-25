"""OpenAPI → tool conversion tests."""

from __future__ import annotations

from hawkapi_mcp._tools import openapi_to_tools


def _spec(paths: dict) -> dict:
    return {"openapi": "3.1.0", "info": {"title": "t", "version": "0"}, "paths": paths}


def test_get_operation_becomes_tool() -> None:
    spec = _spec({"/ping": {"get": {"operationId": "ping", "summary": "Ping"}}})
    tools = openapi_to_tools(spec)
    assert len(tools) == 1
    assert tools[0]["name"] == "ping"
    assert tools[0]["description"] == "Ping"
    assert tools[0]["_meta"]["method"] == "GET"
    assert tools[0]["_meta"]["path"] == "/ping"


def test_synthesised_name_when_operation_id_missing() -> None:
    spec = _spec({"/users/{id}": {"get": {"summary": "Get user"}}})
    tools = openapi_to_tools(spec)
    assert tools[0]["name"] == "get_users_id"


def test_path_param_required_in_input_schema() -> None:
    spec = _spec(
        {
            "/users/{user_id}": {
                "get": {
                    "operationId": "get_user",
                    "parameters": [
                        {"in": "path", "name": "user_id", "schema": {"type": "integer"}},
                    ],
                }
            }
        }
    )
    schema = openapi_to_tools(spec)[0]["inputSchema"]
    assert "path.user_id" in schema["properties"]
    assert "path.user_id" in schema["required"]


def test_query_param_optional_unless_required() -> None:
    spec = _spec(
        {
            "/search": {
                "get": {
                    "operationId": "search",
                    "parameters": [
                        {"in": "query", "name": "q", "schema": {"type": "string"}},
                        {
                            "in": "query",
                            "name": "limit",
                            "schema": {"type": "integer"},
                            "required": True,
                        },
                    ],
                }
            }
        }
    )
    schema = openapi_to_tools(spec)[0]["inputSchema"]
    assert "query.q" in schema["properties"]
    assert "query.limit" in schema["properties"]
    assert "query.q" not in schema["required"]
    assert "query.limit" in schema["required"]


def test_request_body_added_when_present() -> None:
    spec = _spec(
        {
            "/items": {
                "post": {
                    "operationId": "create_item",
                    "requestBody": {
                        "required": True,
                        "content": {"application/json": {"schema": {"type": "object"}}},
                    },
                }
            }
        }
    )
    schema = openapi_to_tools(spec)[0]["inputSchema"]
    assert "body" in schema["properties"]
    assert "body" in schema["required"]


def test_include_only_filter() -> None:
    spec = _spec(
        {
            "/a": {"get": {"operationId": "a"}},
            "/b": {"get": {"operationId": "b"}},
        }
    )
    tools = openapi_to_tools(spec, include_only={"a"})
    assert [t["name"] for t in tools] == ["a"]


def test_exclude_filter() -> None:
    spec = _spec(
        {
            "/a": {"get": {"operationId": "a"}},
            "/b": {"get": {"operationId": "b"}},
        }
    )
    tools = openapi_to_tools(spec, exclude={"a"})
    assert [t["name"] for t in tools] == ["b"]


def test_unsupported_methods_skipped() -> None:
    spec = _spec({"/x": {"get": {"operationId": "x"}, "summary": "not-a-method", "trace": {}}})
    # trace is not in the cacheable set; summary is not an HTTP method either.
    tools = openapi_to_tools(spec)
    assert [t["name"] for t in tools] == ["x"]
