"""HTTP transport tests — full round-trip via TestClient."""

from __future__ import annotations

import pytest
from hawkapi import HawkAPI
from hawkapi.responses import JSONResponse
from hawkapi.testing import TestClient

from hawkapi_mcp import mount_mcp


@pytest.fixture
def client() -> TestClient:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"pong": True})

    mount_mcp(app)
    return TestClient(app)


def test_mcp_endpoint_responds_to_initialize(client: TestClient) -> None:
    r = client.post(
        "/mcp",
        json={"jsonrpc": "2.0", "id": 1, "method": "initialize"},
    )
    assert r.status_code == 200
    body = r.json()
    assert body["result"]["protocolVersion"]


def test_mcp_endpoint_lists_tools(client: TestClient) -> None:
    r = client.post(
        "/mcp",
        json={"jsonrpc": "2.0", "id": 1, "method": "tools/list"},
    )
    body = r.json()
    names = [t["name"] for t in body["result"]["tools"]]
    assert "ping" in names


def test_mcp_endpoint_calls_tool(client: TestClient) -> None:
    r = client.post(
        "/mcp",
        json={
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "ping", "arguments": {}},
        },
    )
    body = r.json()
    assert body["result"]["isError"] is False
    assert '"pong": true' in body["result"]["content"][0]["text"].lower()


def test_mcp_batch_request(client: TestClient) -> None:
    r = client.post(
        "/mcp",
        json=[
            {"jsonrpc": "2.0", "id": 1, "method": "ping"},
            {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        ],
    )
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body, list)
    assert len(body) == 2
    assert body[0]["result"] == {}
    assert "tools" in body[1]["result"]


def test_mcp_rejects_get(client: TestClient) -> None:
    r = client.get("/mcp")
    assert r.status_code == 405


def test_mcp_malformed_body_returns_400(client: TestClient) -> None:
    r = client.post(
        "/mcp",
        body=b"not json",
        headers={"Content-Type": "application/json"},
    )
    assert r.status_code == 400


def test_mcp_notification_returns_204(client: TestClient) -> None:
    r = client.post(
        "/mcp",
        json={"jsonrpc": "2.0", "method": "notifications/initialized"},
    )
    assert r.status_code == 204
