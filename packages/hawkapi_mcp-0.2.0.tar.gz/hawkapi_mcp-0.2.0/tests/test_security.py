"""Regression tests for security hardening — injection and DoS limits."""

from __future__ import annotations

import json
import warnings

import pytest
from hawkapi import HawkAPI
from hawkapi.responses import JSONResponse
from hawkapi.testing import TestClient

from hawkapi_mcp import MCPServer, mount_mcp


@pytest.fixture
def app() -> HawkAPI:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)

    @app.get("/search")
    async def search(q: str = "") -> JSONResponse:
        return JSONResponse({"q": q})

    @app.get("/users/{user_id}")
    async def get_user(user_id: str) -> JSONResponse:
        return JSONResponse({"user_id": user_id})

    @app.get("/echo")
    async def echo() -> JSONResponse:
        return JSONResponse({"ok": True})

    return app


@pytest.fixture
def server(app: HawkAPI) -> MCPServer:
    return MCPServer(app)


# -- Injection regressions ---------------------------------------------------


async def test_query_injection_value_is_encoded(server: MCPServer) -> None:
    """An '&' inside a query value must not start a new pair."""
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query.q": "a&admin=true"}},
        }
    )
    assert resp is not None
    payload = json.loads(resp["result"]["content"][0]["text"])
    assert payload == {"q": "a&admin=true"}


async def test_path_traversal_in_path_param_is_encoded(server: MCPServer) -> None:
    """'../../admin' must be URL-encoded so it does not change route resolution."""
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 2,
            "method": "tools/call",
            "params": {
                "name": "get_user",
                "arguments": {"path.user_id": "../../admin"},
            },
        }
    )
    assert resp is not None
    payload = json.loads(resp["result"]["content"][0]["text"])
    # Slashes must be percent-encoded so the value cannot escape its path segment.
    assert "/" not in payload["user_id"]
    assert "%2F" in payload["user_id"].upper()


async def test_crlf_in_header_value_is_rejected(server: MCPServer) -> None:
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 3,
            "method": "tools/call",
            "params": {
                "name": "echo",
                "arguments": {"header.x-custom": "v\r\nX-Inj: e"},
            },
        }
    )
    assert resp is not None
    assert resp["error"]["code"] == -32602
    assert "control" in resp["error"]["message"].lower()


async def test_crlf_in_query_value_is_rejected(server: MCPServer) -> None:
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {"name": "search", "arguments": {"query.q": "a\r\nB"}},
        }
    )
    assert resp is not None
    assert resp["error"]["code"] == -32602


async def test_unfilled_path_param_is_rejected(server: MCPServer) -> None:
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 5,
            "method": "tools/call",
            "params": {"name": "get_user", "arguments": {}},
        }
    )
    assert resp is not None
    assert resp["error"]["code"] == -32602
    assert "path parameter" in resp["error"]["message"].lower()


# -- DoS limits --------------------------------------------------------------


def _silent_client(app: HawkAPI, **kwargs: object) -> TestClient:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        mount_mcp(app, **kwargs)  # type: ignore[arg-type]
    return TestClient(app)


def test_oversized_batch_is_rejected(app: HawkAPI) -> None:
    client = _silent_client(app, max_batch=100)
    batch = [{"jsonrpc": "2.0", "id": i, "method": "ping"} for i in range(101)]
    r = client.post("/mcp", json=batch)
    assert r.status_code == 400
    assert "batch too large" in r.json()["error"]["message"].lower()


def test_oversized_body_is_rejected(app: HawkAPI) -> None:
    client = _silent_client(app, max_body_bytes=1_048_576)
    # 2 MiB of padding inside a syntactically valid JSON-RPC envelope.
    huge = "x" * (2 * 1_048_576)
    body = json.dumps(
        {
            "jsonrpc": "2.0",
            "id": 1,
            "method": "tools/call",
            "params": {"name": "echo", "arguments": {"header.x-pad": huge}},
        }
    ).encode("utf-8")
    r = client.post("/mcp", body=body, headers={"Content-Type": "application/json"})
    assert r.status_code == 413


def test_deeply_nested_json_is_rejected(app: HawkAPI) -> None:
    client = _silent_client(app)
    # Build {"a": {"a": {... 80 deep ...}}}
    nested: object = "leaf"
    for _ in range(80):
        nested = {"a": nested}
    body = json.dumps({"jsonrpc": "2.0", "id": 1, "method": "ping", "params": nested}).encode(
        "utf-8"
    )
    r = client.post("/mcp", body=body, headers={"Content-Type": "application/json"})
    assert r.status_code == 400
    assert "deep" in r.json()["error"]["message"].lower()


# -- mount-time warning ------------------------------------------------------


def test_full_exposure_emits_warning() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        mount_mcp(app)
    assert any("exposes every route" in str(w.message) for w in caught)


def test_filtered_mount_does_not_warn() -> None:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        mount_mcp(app, include_only={"none"})
    assert not any("exposes every route" in str(w.message) for w in caught)
