"""MCPServer JSON-RPC method tests."""

from __future__ import annotations

import json

import pytest
from hawkapi import HawkAPI
from hawkapi.responses import JSONResponse

from hawkapi_mcp import MCP_PROTOCOL_VERSION, MCPServer


@pytest.fixture
def app() -> HawkAPI:
    app = HawkAPI(openapi_url=None, docs_url=None, redoc_url=None, scalar_url=None)

    @app.get("/ping")
    async def ping() -> JSONResponse:
        return JSONResponse({"pong": True})

    @app.get("/users/{user_id:int}")
    async def get_user(user_id: int) -> JSONResponse:
        return JSONResponse({"id": user_id, "name": "Alice"})

    @app.post("/items")
    async def create_item(body: dict) -> JSONResponse:
        return JSONResponse({"created": body})

    return app


@pytest.fixture
def server(app: HawkAPI) -> MCPServer:
    return MCPServer(app, server_name="t", server_version="0.0.0")


async def test_initialize_returns_protocol_and_capabilities(server: MCPServer) -> None:
    resp = await server.handle({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
    assert resp is not None
    assert resp["jsonrpc"] == "2.0"
    assert resp["id"] == 1
    assert resp["result"]["protocolVersion"] == MCP_PROTOCOL_VERSION
    assert "tools" in resp["result"]["capabilities"]
    assert resp["result"]["serverInfo"] == {"name": "t", "version": "0.0.0"}


async def test_ping_returns_empty_result(server: MCPServer) -> None:
    resp = await server.handle({"jsonrpc": "2.0", "id": 2, "method": "ping"})
    assert resp == {"jsonrpc": "2.0", "id": 2, "result": {}}


async def test_tools_list_returns_app_routes(server: MCPServer) -> None:
    resp = await server.handle({"jsonrpc": "2.0", "id": 3, "method": "tools/list"})
    assert resp is not None
    names = {t["name"] for t in resp["result"]["tools"]}
    # Three operations registered, plus auto-HEAD for the GETs.
    assert "ping" in names
    assert "get_user" in names
    assert "create_item" in names


async def test_tools_call_invokes_handler(server: MCPServer) -> None:
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 4,
            "method": "tools/call",
            "params": {"name": "ping", "arguments": {}},
        }
    )
    assert resp is not None
    result = resp["result"]
    assert result["isError"] is False
    assert result["structuredContent"]["status"] == 200
    assert json.loads(result["content"][0]["text"]) == {"pong": True}


async def test_tools_call_substitutes_path_params(server: MCPServer) -> None:
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 5,
            "method": "tools/call",
            "params": {"name": "get_user", "arguments": {"path.user_id": "42"}},
        }
    )
    assert resp is not None
    assert json.loads(resp["result"]["content"][0]["text"]) == {"id": 42, "name": "Alice"}


async def test_tools_call_sends_json_body(server: MCPServer) -> None:
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 6,
            "method": "tools/call",
            "params": {"name": "create_item", "arguments": {"body": {"name": "x"}}},
        }
    )
    assert resp is not None
    result = resp["result"]
    assert result["isError"] is False
    assert json.loads(result["content"][0]["text"]) == {"created": {"name": "x"}}


async def test_unknown_method_returns_error(server: MCPServer) -> None:
    resp = await server.handle({"jsonrpc": "2.0", "id": 7, "method": "wat"})
    assert resp is not None
    assert resp["error"]["code"] == -32601


async def test_unknown_tool_returns_error(server: MCPServer) -> None:
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 8,
            "method": "tools/call",
            "params": {"name": "nope", "arguments": {}},
        }
    )
    assert resp is not None
    assert resp["error"]["code"] == -32601


async def test_invalid_jsonrpc_version_rejected(server: MCPServer) -> None:
    resp = await server.handle({"jsonrpc": "1.0", "id": 9, "method": "ping"})
    assert resp is not None
    assert resp["error"]["code"] == -32600


async def test_notification_returns_none(server: MCPServer) -> None:
    resp = await server.handle({"jsonrpc": "2.0", "method": "notifications/initialized"})
    assert resp is None


async def test_invalid_params_for_tools_call(server: MCPServer) -> None:
    resp = await server.handle(
        {
            "jsonrpc": "2.0",
            "id": 10,
            "method": "tools/call",
            "params": {"arguments": {}},  # missing name
        }
    )
    assert resp is not None
    assert resp["error"]["code"] == -32602


async def test_filter_include_only(app: HawkAPI) -> None:
    server = MCPServer(app, include_only={"ping"})
    resp = await server.handle({"jsonrpc": "2.0", "id": 11, "method": "tools/list"})
    assert resp is not None
    assert [t["name"] for t in resp["result"]["tools"]] == ["ping"]


async def test_filter_exclude(app: HawkAPI) -> None:
    server = MCPServer(app, exclude={"create_item"})
    resp = await server.handle({"jsonrpc": "2.0", "id": 12, "method": "tools/list"})
    assert resp is not None
    names = {t["name"] for t in resp["result"]["tools"]}
    assert "create_item" not in names
    assert "ping" in names
