from .utils import get_client, encode_image
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Dict

# 3rd-party packages
import pandas as pd
from alive_progress import alive_bar


def compute_metrics(df: pd.DataFrame):
    TP = (df["score"] == 1).sum()
    FP = (df["score"] == 0).sum()
    FN = FP
    precision = TP / (TP + FP) if (TP + FP) > 0 else 0
    recall = TP / (TP + FN) if (TP + FN) > 0 else 0
    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    return round(precision*100,2), round(recall*100,2), round(f1*100,2)





def llm_judge_binary(task, model_name="gpt-4o-mini-2024-07-18"):
    client = get_client()

    prompt = f"""
You are a strict evaluator.

Return ONLY:
1 → if the model answer is correct
0 → if the model answer is incorrect

No explanation.

Question:
{task['question']}

Model Answer:
{task['response']}

Choices:
{task['choices']}

Correct Answer:
{task['answer']}


"""
    images_paths = [p for p in  task["ques_image_path_lst"]]
    
    content = [{"type": "text", "text": prompt}]
    
    content += [
        {
            "type": "image_url",
            "image_url": {"url": f"data:image/jpeg;base64,{encode_image(path)}"}
        }
        for path in images_paths
    ]
    
    response = client.chat.completions.create(
        model=model_name,
        temperature=0,
        messages=[{"role": "user", "content": content}],
        max_tokens=5,
    )

    output = response.choices[0].message.content.strip()

    # safe parsing
    if "1" in output:
        return 1
    elif "0" in output:
        return 0
    else:
        return 0.5  # fallback if model misbehaves


def evaluator(
    dataset: Dict,
    evaluate_mcq_by_judge_llm: bool,
    mcq_match_full_answer: bool,
    var: bool = False,
    eval_path: str = "",
    max_workers: int = 4
) -> Dict:
    """
    Parallel evaluation of dataset with optional LLM scoring.
    """
    evaluation = {}

    # Exclude already-evaluated items
    if eval_path and os.path.exists(eval_path):
        
        exclude_ids = set(pd.read_csv(eval_path)["id"].to_list())
        dataset = {k: v for k, v in dataset.items() if k not in exclude_ids}
        evaluation=pd.read_csv(eval_path).set_index('id').to_dict(orient='index')

    def evaluate_item(d_id, data):
        """Evaluate a single dataset item and return result tuple"""
        # MCQ scoring
        if data.get("question_type") == "MCQ" and not evaluate_mcq_by_judge_llm:
            if mcq_match_full_answer:
                score = 1 if data["answer"] in data["response"] else 0
            else:
                score = 1 if data["correct_option"] == data["response"] else 0
        else:
            score = llm_judge_binary(task=data)
        
        key_id = "".join(d_id.split("-")[:2]) if var else d_id
        return key_id, data, score


    # Run in parallel
    with alive_bar(len(dataset), bar='blocks', spinner='dots', title='Running Evaluation', force_tty=True) as bar:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_id = {executor.submit(evaluate_item, d_id, data): d_id for d_id, data in dataset.items()}
            
            for future in as_completed(future_to_id):
                key_id, data, score = future.result()
                
                # Merge results safely
                if var and key_id in evaluation:
                    evaluation[key_id]["prompt"].append(data["task_description"])
                    evaluation[key_id]["response"].append(data["response"])
                    evaluation[key_id]["scores"].append(score)
                else:
                    evaluation[key_id] = {**data}
                    if var:
                        evaluation[key_id]["prompt"] = [data["task_description"]]
                        evaluation[key_id]["response"] = [data["response"]]
                        evaluation[key_id]["scores"] = [score]
                    else:
                        evaluation[key_id]["score"] = score

                bar()  # update progress

    # Compute averaged scores for var=True
    if var:
        for i in evaluation:
            evaluation[i]["score"] = sum(evaluation[i]["scores"]) / len(evaluation[i]["scores"])

    # Save final CSV once
    if eval_path:
        pd.DataFrame.from_dict(evaluation, orient="index").rename_axis("id").reset_index().to_csv(eval_path, index=False)
        
    return evaluation


def get_evaluation_result(df):
    TP = (df["score"] == 1).sum()
    FP = (df["score"] == 0).sum()
    
    # If every row has a prediction, FN ~ FP for binary correctness
    FN = FP  

    precision = TP / (TP + FP) if (TP + FP) > 0 else 0
    recall = TP / (TP + FN) if (TP + FN) > 0 else 0
    f1 = (2 * precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

    return round(precision*100,2), round(recall*100,2), round(f1*100,2)



def evaluation_result(eval_path):
    df = pd.read_csv(eval_path)

    # ---------------- Aggregations ----------------
    cat_df = (
        df.groupby("category")
        .apply(lambda x: pd.Series({
            "cat_score": x["score"].mean()*100,
            "cat_count": len(x),
            "precision": compute_metrics(x)[0],
            "recall": compute_metrics(x)[1],
            "f1": compute_metrics(x)[2],
        }))
        .reset_index()
    )

    sub_df = (
        df.groupby(["category", "sub_category"])
        .apply(lambda x: pd.Series({
            "subcat_score": x["score"].mean()*100,
            "subcat_count": len(x),
            "precision": compute_metrics(x)[0],
            "recall": compute_metrics(x)[1],
            "f1": compute_metrics(x)[2],
        }))
        .reset_index()
    )

    task_df = (
        df.groupby(["category", "sub_category", "task"])
        .apply(lambda x: pd.Series({
            "task_score": x["score"].mean()*100,
            "task_count": len(x),
            "precision": compute_metrics(x)[0],
            "recall": compute_metrics(x)[1],
            "f1": compute_metrics(x)[2],
        }))
        .reset_index()
    )

    # Merge
    merged = (
        task_df
        .merge(sub_df, on=["category", "sub_category"])
        .merge(cat_df, on="category")
    )

    # Sort worst → best
    merged = merged.sort_values(
        by=["cat_score", "subcat_score", "task_score"],
        ascending=[True, True, True]
    )

    # ---------------- Pretty Print ----------------
    for cat, cat_group in merged.groupby("category", sort=False):
        row = cat_group.iloc[0]
        print(f"\n📊 Category: {cat} | Score: {row['cat_score']:.2f}% | Count: {row['cat_count']}")
        print(f"   Precision: {row['precision']}% | Recall: {row['recall']}% | F1: {row['f1']}%")
        print("-" * 90)

        for sub, sub_group in cat_group.groupby("sub_category", sort=False):
            row = sub_group.iloc[0]
            print(f"  🔹 Sub-category: {sub} | Score: {row['subcat_score']:.2f}% | Count: {row['subcat_count']}")
            print(f"     Precision: {row['precision']}% | Recall: {row['recall']}% | F1: {row['f1']}%")

            for _, r in sub_group.iterrows():
                print(
                    f"      ▪ Task: {r['task']:<25} "
                    f"| Score: {r['task_score']:>6.2f}% "
                    f"| P: {r['precision']:>5}% "
                    f"| R: {r['recall']:>5}% "
                    f"| F1: {r['f1']:>5}% "
                    f"| Count: {r['task_count']}"
                )

    # ---------------- Overall ----------------
    p, r, f1 = compute_metrics(df)
    print("\nOverall Score:", round(df["score"].mean()*100, 2), "%")
    print(f"Overall Precision: {p}% | Recall: {r}% | F1: {f1}%")

