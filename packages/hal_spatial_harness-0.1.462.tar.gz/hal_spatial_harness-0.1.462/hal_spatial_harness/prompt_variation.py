
from typing import Dict,  List
from .utils import get_client







# ---------------- Config ----------------

# Instructions per strength
STRENGTH_INSTRUCTIONS = {
    "mild": (
        "Generate small, surface-level variations of the prompt. "
        "Use synonyms, minor changes in formality, active/passive voice changes. "
        "Keep all information, meaning, and structure intact. "
        "Output should be fluent and similar in style to the original."
    ),
    "medium": (
        "Generate variations that restructure sentences and reorder information. "
        "Combine or split sentences, slightly change phrasing, but preserve all meaning. "
        "Output should still be clear and professional, resembling the original style."
    ),
    "strong": (
        "Generate majorly different variations that sound like different people wrote them. "
        "Use conversational phrasing, varied sentence structures, and style differences. "
        "Preserve all information and constraints exactly. Output should maintain readability."
    ),
    "naturalistic": (
        "Generate realistic user-style variations as if typed by a real person. "
        "Include casual phrasing, abbreviations, typos, and informal chat patterns. "
        "Keep all meaning and requirements intact. Output should still resemble the original prompt in content."
    ),
}

STRENGTH_TEMPERATURE = {
    "mild": 0.7,
    "medium": 0.8,
    "strong": 0.9,
    "naturalistic": 0.9,
}


class PromptVariationGenerator:
    def __init__(self, model_name="gpt-4o-mini-2024-07-18", num_variations=2, strength="medium"):
        self.model_name = model_name
        self.num_variations = num_variations
        self.strength = strength.lower()
        self.client = get_client()

    def generate_variations_for_task(self, task_id: str, prompt: str) -> List[Dict]:
        instruction = STRENGTH_INSTRUCTIONS.get(self.strength, STRENGTH_INSTRUCTIONS["mild"])
        temperature = STRENGTH_TEMPERATURE.get(self.strength, 0.7)

        system_prompt = f"You are an expert at paraphrasing prompts while preserving meaning.\nInstruction: {instruction}"
        user_prompt = f"Original prompt:\n{prompt}\nGenerate {self.num_variations} variations, one per line. Do NOT number them."

        try:
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=temperature,
                max_tokens=1000,
            )

            lines = response.choices[0].message.content.strip().split("\n")
            variations = [line.strip() for line in lines if len(line.strip()) > 10]

        except Exception as e:
            print(f"Error generating variations for task {task_id}: {e}")
            variations = []

        all_variations = [prompt] + variations[:self.num_variations]

        return [
            {"question": v, "prompt_variation_id": i, "prompt_variation_strength": self.strength}
            for i, v in enumerate(all_variations)
        ]

    def generate_variations_for_dataset(self, dataset: Dict[str, Dict], prompt_field: str = "question") -> Dict[str, List[Dict]]:
        result = {}
        for task_id, task_data in dataset.items():
            if prompt_field not in task_data:
                result[task_id] = [{
                    "question": task_data.get(prompt_field, ""),
                    "prompt_variation_id": 0,
                    "prompt_variation_strength": self.strength
                }]
                continue
            prompt = task_data[prompt_field]
            result[task_id] = self.generate_variations_for_task(task_id, prompt)
        return result



def generate_var_bench( dataset, prompt_map):
    new_dataset={}
    for d_id,d in dataset.items():
        
        for idx,q in  enumerate(prompt_map[d_id]):
            new_dataset[f'{d_id}-{str(idx).zfill(2)}'] = { 
                **dataset[d_id],
                "question":q['question']
            } 

    return new_dataset






