"""Native core of nbuv (nanobind bindings over the nbuv C++ library)."""

from collections.abc import Sequence
from typing import overload


def add(a: int, b: int) -> int:
    """Return the sum of two integers."""

def sum(values: Sequence[float]) -> float:
    """Return the sum of a sequence of floats."""

class Greeter:
    """A minimal demo class with a mutable `name` property."""

    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, name: str) -> None: ...

    def greet(self) -> str:
        """Return a friendly greeting."""

    @property
    def name(self) -> str:
        """The name used in the greeting."""

    @name.setter
    def name(self, arg: str, /) -> None: ...
