from __future__ import annotations

from typing import Any, Iterator, Optional, TypedDict


class CacheSummary(TypedDict):
	"""Summary returned by ``MessageCacheReader.get_cache_summary``.

	Keys:
	- ``file_source``: source file path used in ``load_to_cache`` (or ``None``)
	- ``total_messages``: total parsed messages in cache
	- ``total_orders``: count of order-side messages (N/M/X)
	- ``total_trades``: count of trade messages (T)
	- ``memory_usage_bytes``: approximate memory used by cached message vector
	"""

	file_source: Optional[str]
	total_messages: int
	total_orders: int
	total_trades: int
	memory_usage_bytes: int


class Snapshot(TypedDict):
	"""Snapshot returned by ``OrderbookBuilder.get_snapshot``.

	Keys:
	- ``token``: token requested
	- ``found``: True if book exists for token
	- ``mid_price``: midpoint from best bid/ask
	- ``best_bid``: best bid tuple ``(price, qty)`` or ``None``
	- ``best_ask``: best ask tuple ``(price, qty)`` or ``None``
	- ``spread``: ``best_ask_price - best_bid_price`` or ``None``
	- ``bids``: top-N bid levels (best to worse)
	- ``asks``: top-N ask levels (best to worse)
	"""

	token: int
	found: bool
	mid_price: int
	best_bid: Optional[tuple[int, int]]
	best_ask: Optional[tuple[int, int]]
	spread: Optional[int]
	bids: list[tuple[int, int]]
	asks: list[tuple[int, int]]


class DepthSnapshot(TypedDict):
	"""Full depth snapshot for a token.

	Keys:
	- ``token``: token requested
	- ``found``: True if book exists for token
	- ``best_bid``: best bid tuple ``(price, qty)`` or ``None``
	- ``best_ask``: best ask tuple ``(price, qty)`` or ``None``
	- ``spread``: ``best_ask_price - best_bid_price`` or ``None``
	- ``bids``: all non-zero bid levels (best to worse)
	- ``asks``: all non-zero ask levels (best to worse)
	"""

	token: int
	found: bool
	best_bid: Optional[tuple[int, int]]
	best_ask: Optional[tuple[int, int]]
	spread: Optional[int]
	bids: list[tuple[int, int]]
	asks: list[tuple[int, int]]


class MessageCacheReader:
	"""Load full binary feed into RAM and provide cached access.

	This is the high-throughput batch mode reader:
	- parses all supported records from disk,
	- stores parsed messages in memory,
	- allows repeated processing without re-reading file.
	"""

	def __init__(self) -> None: ...

	def load_to_cache(self, file_path: str) -> int:
		"""Parse the full binary file and cache all messages.

		Parameters:
		- ``file_path``: absolute or relative path to feed file

		Returns:
		- number of parsed messages loaded into cache

		Raises:
		- ``RuntimeError`` when file cannot be opened/read/parsed
		"""
		...

	def get_all_messages(self) -> list[str]:
		"""Return all cached messages as formatted strings.

		Each element is a human-readable line like:
		- ``Order Message: ...``
		- ``Trade Message: ...``
		"""
		...

	def get_cache_summary(self) -> CacheSummary:
		"""Return structured cache statistics for quick diagnostics."""
		...


class StreamingBinaryLoader:
	"""Disk-streaming reader with active file pointer.

	Unlike ``MessageCacheReader``, this loader does not keep all messages in RAM.
	It keeps a file handle open and reads one message at a time in sequence.
	"""

	def __init__(self) -> None: ...

	def open_stream(self, file_path: str, count_messages: bool = True) -> int:
		"""Open stream source and initialize pointer at beginning.

		Parameters:
		- ``file_path``: binary feed file path
		- ``count_messages``: if True (default), pre-scan the file and return total count;
		  if False, skip pre-scan and return ``0`` for faster startup

		Returns:
		- total message count when ``count_messages=True``
		- ``0`` when ``count_messages=False``
		"""
		...

	def reset_cursor(self) -> None:
		"""Reset stream cursor to file start so replay can run again."""
		...

	def get_next_message(self) -> str:
		"""Read and format only the next message from disk.

		Returns:
		- formatted message string for next record
		- ``"END"`` when EOF is reached
		"""
		...


class OrderbookBuilder:
	"""Build and query order book state from parsed message streams.

	Supports both:
	- full-cache replay (``build_from_list``)
	- streaming replay (``build_from_source`` with ``StreamingBinaryLoader``)
	"""

	def __init__(self) -> None: ...

	def apply_filter(self, logic_criteria: Optional[list[str]] = None) -> None:
		"""Apply message-type filter before replay.

		Typical values:
		- ``["N", "M", "X"]``: order lifecycle only
		- ``["T"]``: trades only
		- ``None``: no filter (default)
		"""
		...

	def build_from_list(self, source: MessageCacheReader | list[dict[str, Any]]) -> int:
		"""Replay messages from cache reader or decoded message list.

		When ``source`` is a list, each dict should include:
		- order message keys: ``msg_type``, ``order_id``, ``token``, ``order_type``, ``price``, ``quantity``
		- trade message keys: ``msg_type``, ``buy_order_id``, ``sell_order_id``, ``token``, ``trade_quantity``

		Optional keys: ``exch_ts``, ``local_ts``, ``flags``, ``trade_price``.
		Returns the count of applied messages (after filter, if set).
		"""
		...

	def build_from_source(
		self,
		source: MessageCacheReader | StreamingBinaryLoader,
		limit: Optional[int] = None,
	) -> int:
		"""Replay from either cache reader or streaming loader.

		- With ``MessageCacheReader``, replays full cache.
		- With ``StreamingBinaryLoader``, replays until EOF or ``limit``.
		"""
		...

	def get_snapshot(self, token: int, levels: Optional[int] = None) -> Snapshot:
		"""Return token snapshot as structured dictionary."""
		...

	def get_orderbook_snapshot(self, token: int, levels: Optional[int] = None) -> Snapshot:
		"""Compatibility alias for ``get_snapshot``."""
		...

	def get_full_depth(self, token: int) -> DepthSnapshot:
		"""Return full bid/ask depth with all non-zero levels."""
		...

	def snapshot_header(self) -> str:
		"""Return fixed CSV header for snapshot-row exports.

		Header columns:
		``local_ts,exch_ts,mid_price,bid_price_0,bid_qty_0,ask_price_0,ask_qty_0,...,ask_price_4,ask_qty_4``
		"""
		...

	def get_snapshot_row(self, token: int, levels: Optional[int] = None) -> str:
		"""Return one CSV row in exact ``snapshot_header`` column order.

		Row format:
		``local_ts,exch_ts,mid_price,bid_price_0,bid_qty_0,ask_price_0,ask_qty_0,...,ask_price_4,ask_qty_4``
		"""
		...


class BinaryDataLoader:
	"""Compatibility wrapper exposed at package root for legacy callers.

	This class wraps ``MessageCacheReader`` and ``StreamingBinaryLoader``.
	Keep using new classes directly for best control and performance.
	"""

	def __init__(self, path: str, token: Optional[int] = None) -> None: ...
	def total_messages(self) -> int: ...
	def total_orders(self) -> int: ...
	def total_trades(self) -> int: ...
	def reset_cursor(self) -> None: ...
	def summary(self) -> str: ...
	def get_all_messages(self, limit: Optional[int] = None) -> list[str]: ...
	def get_order_messages(self, limit: Optional[int] = None) -> list[str]: ...
	def get_trade_messages(self, limit: Optional[int] = None) -> list[str]: ...
	def get_next_message(self) -> str: ...


class BinaryLoader(Iterator[str]):
	"""Iterator adapter over ``BinaryDataLoader.get_next_message``."""

	def __init__(self, reader: BinaryDataLoader) -> None: ...
	def __iter__(self) -> BinaryLoader: ...
	def __next__(self) -> str: ...


ReadMsgFromBinary = BinaryDataLoader


__all__ = [
	"MessageCacheReader",
	"StreamingBinaryLoader",
	"OrderbookBuilder",
	"BinaryDataLoader",
	"ReadMsgFromBinary",
	"BinaryLoader",
	"CacheSummary",
	"Snapshot",
	"DepthSnapshot",
]
