"""Tests for credential storage and auth resolution."""

import json
from pathlib import Path
from unittest.mock import patch

import pytest

from tyko._auth import clear_credentials, get_stored_credentials, store_credentials


@pytest.fixture()
def credentials_dir(tmp_path: Path) -> Path:
    config_dir = tmp_path / ".config" / "tyko"
    config_dir.mkdir(parents=True)
    with patch("tyko._auth._config_dir", return_value=config_dir):
        yield config_dir


# --- store_credentials ---


def test_store_credentials_sets_anonymous_flag(credentials_dir: Path) -> None:
    store_credentials(api_key="abc123", api_url="http://localhost", anonymous=True)
    data = json.loads((credentials_dir / "credentials").read_text())
    assert data["anonymous"] is True


def test_store_credentials_defaults_to_not_anonymous(credentials_dir: Path) -> None:
    store_credentials(api_key="abc123", api_url="http://localhost")
    data = json.loads((credentials_dir / "credentials").read_text())
    assert data["anonymous"] is False


def test_store_credentials_does_not_overwrite_non_anonymous_with_anonymous(
    credentials_dir: Path,
) -> None:
    """Anonymous auto-provisioning must not replace a real login key."""
    store_credentials(api_key="real-key", api_url="http://localhost", anonymous=False)
    store_credentials(api_key="anon-key", api_url="http://localhost", anonymous=True)

    data = json.loads((credentials_dir / "credentials").read_text())
    assert data["api_key"] == "real-key"
    assert data["anonymous"] is False


def test_store_credentials_overwrites_anonymous_with_anonymous(
    credentials_dir: Path,
) -> None:
    """Re-provisioning anonymous is fine if existing creds are also anonymous."""
    store_credentials(api_key="anon-1", api_url="http://localhost", anonymous=True)
    store_credentials(api_key="anon-2", api_url="http://localhost", anonymous=True)

    data = json.loads((credentials_dir / "credentials").read_text())
    assert data["api_key"] == "anon-2"


def test_store_credentials_overwrites_anonymous_with_login(
    credentials_dir: Path,
) -> None:
    """tyko login should replace anonymous credentials."""
    store_credentials(api_key="anon-key", api_url="http://localhost", anonymous=True)
    store_credentials(api_key="real-key", api_url="http://localhost", anonymous=False)

    data = json.loads((credentials_dir / "credentials").read_text())
    assert data["api_key"] == "real-key"
    assert data["anonymous"] is False


# --- get_stored_credentials ---


def test_get_stored_credentials_returns_none_when_no_file(
    credentials_dir: Path,
) -> None:
    assert get_stored_credentials() is None


def test_get_stored_credentials_reads_anonymous_flag(credentials_dir: Path) -> None:
    store_credentials(api_key="key", api_url="http://localhost", anonymous=True)
    creds = get_stored_credentials()
    assert creds is not None
    assert creds["anonymous"] is True


def test_get_stored_credentials_defaults_anonymous_false_for_old_files(
    credentials_dir: Path,
) -> None:
    """Credentials written before the anonymous flag should be treated as non-anonymous."""
    path = credentials_dir / "credentials"
    path.write_text(json.dumps({"api_key": "old-key", "api_url": "http://localhost"}))
    creds = get_stored_credentials()
    assert creds is not None
    assert creds.get("anonymous") is False


# --- clear_credentials ---


def test_clear_credentials_removes_file(credentials_dir: Path) -> None:
    store_credentials(api_key="key", api_url="http://localhost")
    assert clear_credentials() is True
    assert get_stored_credentials() is None


def test_clear_credentials_returns_false_when_no_file(
    credentials_dir: Path,
) -> None:
    assert clear_credentials() is False
