# -*- coding: utf-8 -*-
"""
StockClaw CLI 命令行工具

提供命令行接口供Agent调用，封装所有对外API功能。

使用方法:
    # 更新数据
    python -m claw_quant.cli update --codes 000001.SZ --date 2026-04-20
    
    # 查询数据
    python -m claw_quant.cli query --code 000001.SZ --start 2026-04-17 --end 2026-04-20
    
    # 获取最新日期
    python -m claw_quant.cli latest
    
    # 获取股票列表
    python -m claw_quant.cli stocks
    
    # 回测
    python -m claw_quant.cli backtest --factor CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
    
    # 多引擎对比回测
    python -m claw_quant.cli backtest --factor CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --compare
"""

import argparse
import json
import sys
import io
import os
import subprocess
import signal
from datetime import date, datetime
from typing import Optional, Dict, Any, List

# 设置 stdout 编码为 UTF-8（解决 Windows 中文乱码）
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from .database.api import StockAPI


def get_db_server_pid():
    """获取数据库服务器进程ID"""
    import glob
    pid_files = glob.glob(os.path.expanduser('~/.claw_quant/db_server_*.pid'))
    if pid_files:
        try:
            with open(pid_files[0], 'r') as f:
                return int(f.read().strip())
        except:
            pass
    return None


def save_db_server_pid(pid):
    """保存数据库服务器进程ID"""
    pid_dir = os.path.expanduser('~/.claw_quant')
    os.makedirs(pid_dir, exist_ok=True)
    pid_file = os.path.join(pid_dir, f'db_server_{pid}.pid')
    with open(pid_file, 'w') as f:
        f.write(str(pid))


def remove_db_server_pid():
    """删除数据库服务器进程ID文件"""
    import glob
    pid_files = glob.glob(os.path.expanduser('~/.claw_quant/db_server_*.pid'))
    for f in pid_files:
        try:
            os.remove(f)
        except:
            pass


def cmd_db_start(args) -> int:
    """启动数据库服务器命令"""
    # 检查是否已经在运行
    existing_pid = get_db_server_pid()
    if existing_pid:
        try:
            if sys.platform == 'win32':
                import ctypes
                kernel32 = ctypes.windll.kernel32
                handle = kernel32.OpenProcess(1, False, existing_pid)
                if handle:
                    kernel32.CloseHandle(handle)
                    print(format_output({
                        'success': False,
                        'message': f'数据库服务器已在运行 (PID: {existing_pid})',
                        'pid': existing_pid,
                        'status': 'running'
                    }))
                    return 0
            else:
                os.kill(existing_pid, 0)
                print(format_output({
                    'success': False,
                    'message': f'数据库服务器已在运行 (PID: {existing_pid})',
                    'pid': existing_pid,
                    'status': 'running'
                }))
                return 0
        except:
            remove_db_server_pid()
    
    # 启动数据库服务器
    try:
        from .database.storage.db_server import get_default_db_path, main as db_main
        
        db_path = args.db_path or get_default_db_path()
        host = args.host
        port = args.port
        
        # 确保数据库目录存在
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        
        print(format_output({
            'success': True,
            'message': '正在启动数据库服务器...',
            'db_path': db_path,
            'host': host,
            'port': port,
            'status': 'starting'
        }))
        
        if args.background:
            # 后台启动
            if sys.platform == 'win32':
                # Windows 使用 subprocess.CREATE_NEW_CONSOLE
                proc = subprocess.Popen(
                    [sys.executable, '-m', 'claw_quant.database.storage.db_server',
                     '--db-path', db_path, '--host', host, '--port', str(port)],
                    creationflags=subprocess.CREATE_NEW_CONSOLE,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL
                )
            else:
                # Linux/Mac 使用 nohup
                proc = subprocess.Popen(
                    [sys.executable, '-m', 'claw_quant.database.storage.db_server',
                     '--db-path', db_path, '--host', host, '--port', str(port)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True
                )
            
            save_db_server_pid(proc.pid)
            print(format_output({
                'success': True,
                'message': f'数据库服务器已在后台启动 (PID: {proc.pid})',
                'pid': proc.pid,
                'db_path': db_path,
                'host': host,
                'port': port,
                'status': 'running'
            }))
            return 0
        else:
            # 前台启动
            import sys as sys_module
            # 模拟命令行参数
            original_argv = sys_module.argv
            sys_module.argv = ['db_server', '--db-path', db_path, '--host', host, '--port', str(port)]
            try:
                db_main()
            finally:
                sys_module.argv = original_argv
            return 0
            
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'启动数据库服务器失败: {str(e)}',
            'error': str(e),
            'status': 'failed'
        }))
        return 1


def cmd_db_stop(args) -> int:
    """停止数据库服务器命令"""
    pid = get_db_server_pid()
    
    if not pid:
        print(format_output({
            'success': False,
            'message': '未找到运行的数据库服务器',
            'status': 'not_running'
        }))
        return 1
    
    try:
        if sys.platform == 'win32':
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(1, False, pid)
            if handle:
                kernel32.TerminateProcess(handle, 0)
                kernel32.CloseHandle(handle)
        else:
            os.kill(pid, signal.SIGTERM)
        
        remove_db_server_pid()
        
        print(format_output({
            'success': True,
            'message': f'数据库服务器已停止 (PID: {pid})',
            'pid': pid,
            'status': 'stopped'
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'停止数据库服务器失败: {str(e)}',
            'error': str(e),
            'status': 'error'
        }))
        return 1


def cmd_db_status(args) -> int:
    """检查数据库服务器状态命令"""
    pid = get_db_server_pid()
    
    if not pid:
        print(format_output({
            'success': True,
            'message': '数据库服务器未运行',
            'status': 'not_running',
            'pid': None
        }))
        return 0
    
    try:
        if sys.platform == 'win32':
            import ctypes
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(1, False, pid)
            if handle:
                kernel32.CloseHandle(handle)
                is_running = True
            else:
                is_running = False
        else:
            os.kill(pid, 0)
            is_running = True
        
        if is_running:
            print(format_output({
                'success': True,
                'message': f'数据库服务器正在运行 (PID: {pid})',
                'status': 'running',
                'pid': pid
            }))
            return 0
        else:
            remove_db_server_pid()
            print(format_output({
                'success': True,
                'message': '数据库服务器未运行',
                'status': 'not_running',
                'pid': None
            }))
            return 0
            
    except:
        remove_db_server_pid()
        print(format_output({
            'success': True,
            'message': '数据库服务器未运行',
            'status': 'not_running',
            'pid': None
        }))
        return 0


def parse_date(date_str: str) -> date:
    """解析日期字符串"""
    try:
        return datetime.strptime(date_str, '%Y-%m-%d').date()
    except ValueError:
        raise argparse.ArgumentTypeError(f'无效的日期格式: {date_str}，请使用 YYYY-MM-DD 格式')


def format_output(data: dict) -> str:
    """格式化输出为JSON"""
    return json.dumps(data, ensure_ascii=False, indent=2)


def cmd_update(args) -> int:
    """更新数据命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh',
            'saved_count': 0,
            'requested_date': args.date.strftime('%Y-%m-%d') if args.date else None,
            'actual_date': None,
            'is_mapping': False
        }))
        return 1
    
    codes = args.codes.split(',') if args.codes else None
    target_date = args.date
    
    result = api.update_daily(codes=codes, target_date=target_date)
    print(format_output(result))
    return 0 if result['success'] else 1


def _convert_to_json_serializable(data: list) -> list:
    """将数据中的date对象转换为字符串"""
    result = []
    for item in data:
        new_item = {}
        for key, value in item.items():
            if isinstance(value, date):
                new_item[key] = value.strftime('%Y-%m-%d')
            else:
                new_item[key] = value
        result.append(new_item)
    return result


def cmd_query(args) -> int:
    """查询数据命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh',
            'data': []
        }))
        return 1
    
    try:
        if args.codes:
            # 批量查询
            codes = args.codes.split(',')
            df = api.get_daily_multi(codes, args.start, args.end)
        else:
            # 单只股票查询
            df = api.get_daily(args.code, args.start, args.end)
        
        # 转换为字典列表，并处理date对象
        raw_data = df.to_dict(orient='records') if not df.empty else []
        data = _convert_to_json_serializable(raw_data)
        
        print(format_output({
            'success': True,
            'message': f'查询成功，返回 {len(data)} 条记录',
            'count': len(data),
            'data': data
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'查询失败: {str(e)}',
            'data': []
        }))
        return 1


def cmd_latest(args) -> int:
    """获取最新日期命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh',
            'latest_date': None
        }))
        return 1
    
    latest = api.get_latest_date()
    
    print(format_output({
        'success': True,
        'message': '查询成功',
        'latest_date': latest.strftime('%Y-%m-%d') if latest else None
    }))
    return 0


def cmd_stocks(args) -> int:
    """获取股票列表命令"""
    api = StockAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh',
            'count': 0,
            'stocks': []
        }))
        return 1
    
    try:
        df = api.get_all_stocks()
        raw_stocks = df.to_dict(orient='records') if not df.empty else []
        
        # 处理date对象
        stocks = _convert_to_json_serializable(raw_stocks)
        
        # 如果指定了limit，限制返回数量
        if args.limit and len(stocks) > args.limit:
            stocks = stocks[:args.limit]
        
        print(format_output({
            'success': True,
            'message': f'查询成功，返回 {len(stocks)} 只股票',
            'count': len(stocks),
            'stocks': stocks
        }))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'查询失败: {str(e)}',
            'count': 0,
            'stocks': []
        }))
        return 1


def cmd_factor(args) -> int:
    """因子管理命令 - 根据子命令分发"""
    if args.factor_subcommand == 'list':
        return cmd_factor_list(args)
    elif args.factor_subcommand == 'info':
        return cmd_factor_info(args)
    elif args.factor_subcommand == 'calc':
        return cmd_factor_calc(args)
    elif args.factor_subcommand == 'backtest':
        return cmd_factor_backtest(args)
    else:
        # 默认列出所有因子
        return cmd_factor_list(args)


def cmd_factor_list(args) -> int:
    """列出所有因子"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    factors = api.get_available_factors()
    print(format_output({
        'success': True,
        'count': len(factors),
        'factors': factors
    }))
    return 0


def cmd_factor_info(args) -> int:
    """查看因子详情"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    info = api.get_factor_info(args.name)
    if info:
        # 如果有help文本，优先显示help
        if 'help' in info:
            print(info['help'])
        else:
            print(format_output({
                'success': True,
                'factor': info
            }))
    else:
        print(format_output({
            'success': False,
            'message': f'因子不存在: {args.name}'
        }))
    return 0


def cmd_factor_calc(args) -> int:
    """计算因子值"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    import json
    import re
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    try:
        # 解析股票代码
        codes = args.codes.split(',') if args.codes else ['000001.SZ']
        
        # 解析因子参数
        factor_params = {}
        if args.params:
            params_str = args.params.strip()
            
            # 尝试直接解析JSON
            try:
                factor_params = json.loads(params_str)
            except json.JSONDecodeError:
                # 尝试修复常见的JSON格式问题
                # 1. 将单引号替换为双引号
                params_str = params_str.replace("'", '"')
                # 2. 处理没有引号的key
                params_str = re.sub(r'([{,])\s*(\w+)\s*:', r'\1"\2":', params_str)
                
                try:
                    factor_params = json.loads(params_str)
                except json.JSONDecodeError as e:
                    print(format_output({
                        'success': False,
                        'message': f'参数解析失败: {str(e)}。请使用JSON格式，如: {{"short_window":10,"long_window":30}}'
                    }))
                    return 1
        
        # 计算因子值
        result = api.calculate_factor_values(
            factor_code=args.name,
            codes=codes,
            calc_date=args.date,
            factor_params=factor_params,
            limit=args.limit if args.limit > 0 else None
        )
        
        if not result.get('success', False):
            print(format_output({
                'success': False,
                'message': result.get('message', '计算失败')
            }))
            return 1
        
        print(format_output(result))
        return 0
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'计算失败: {str(e)}'
        }))
        return 1


def cmd_factor_backtest(args) -> int:
    """因子回测"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 运行因子测试
    try:
        result = api.run_factor_test(
            factor_name=args.name,
            codes=codes,
            start_date=args.start,
            end_date=args.end,
            factor_params=factor_params,
            method=args.method
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }))
        return 1


def cmd_strategy(args) -> int:
    """策略管理命令 - 根据子命令分发"""
    if args.strategy_subcommand == 'list':
        return cmd_strategy_list(args)
    elif args.strategy_subcommand == 'info':
        return cmd_strategy_info(args)
    elif args.strategy_subcommand == 'backtest':
        return cmd_strategy_backtest(args)
    else:
        # 默认列出所有策略
        return cmd_strategy_list(args)


def cmd_strategy_list(args) -> int:
    """列出所有策略"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    strategies = api.list_strategies()
    print(format_output({
        'success': True,
        'count': len(strategies),
        'strategies': strategies
    }))
    return 0


def cmd_strategy_info(args) -> int:
    """查看策略详情"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    info = api.get_strategy_info(args.name)
    if info:
        print(format_output({
            'success': True,
            'strategy': info
        }))
    else:
        print(format_output({
            'success': False,
            'message': f'策略不存在: {args.name}'
        }))
    return 0


def cmd_strategy_backtest(args) -> int:
    """策略回测"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    code = codes[0]
    
    # 解析策略参数
    strategy_params = {}
    if args.params:
        try:
            strategy_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 运行策略回测
    try:
        result = api.run_strategy_backtest(
            strategy_name=args.name,
            code=code,
            start_date=args.start,
            end_date=args.end,
            init_capital=args.capital,
            strategy_params=strategy_params,
            engine=args.engine if args.engine else None
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }))
        return 1


def cmd_engines(args) -> int:
    """查看可用回测引擎"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    engines = api.get_available_engines()
    
    print(format_output({
        'success': True,
        'count': len(engines),
        'engines': engines
    }))
    return 0


def cmd_selftest(args) -> int:
    """自我测试命令 - 完整的自动化测试流程"""
    import subprocess
    import time
    import sys as sys_module
    
    test_results = []
    test_code = '000001.SZ'
    test_date = '2024-06-01'
    test_start = '2024-01-01'
    test_end = '2024-06-01'
    
    # 使用当前 Python 解释器
    python_exe = sys_module.executable
    
    def run_command(cmd, description, check_success=True):
        """运行命令并检查结果"""
        print(f"\n{'='*60}")
        print(f"[测试] {description}")
        print(f"{'='*60}")
        print(f"命令: {cmd}")
        
        try:
            # 设置环境变量确保 UTF-8 编码
            env = os.environ.copy()
            env['PYTHONIOENCODING'] = 'utf-8'
            
            result = subprocess.run(
                cmd,
                shell=True,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                timeout=60,
                env=env
            )
            
            if result.returncode != 0 and check_success:
                error_msg = result.stderr or result.stdout or "未知错误"
                print(f"[失败] {error_msg}")
                return False, error_msg
            
            try:
                output = json.loads(result.stdout)
                print(f"[成功] {output.get('message', '执行成功')}")
                return True, output
            except:
                print(f"[成功] {result.stdout[:200] if result.stdout else '执行成功'}")
                return True, result.stdout
                
        except subprocess.TimeoutExpired:
            error_msg = "命令执行超时"
            print(f"[失败] {error_msg}")
            return False, error_msg
        except Exception as e:
            error_msg = str(e)
            print(f"[失败] {error_msg}")
            return False, error_msg
    
    def check_qmt_status():
        """检查 QMT 状态"""
        print(f"\n{'='*60}")
        print("[测试] 检查 QMT 连接状态")
        print(f"{'='*60}")
        
        try:
            from .database.source.qmt import QMTDataSource
            qmt = QMTDataSource()
            if qmt.connect():
                print("[成功] QMT 连接正常")
                return True
            else:
                print("[警告] QMT 未连接，跳过数据更新测试")
                return False
        except Exception as e:
            print(f"[警告] QMT 检查失败: {e}，跳过数据更新测试")
            return False
    
    print("\n" + "="*60)
    print("开始自我测试")
    print("="*60)
    
    # 1. 测试各命令的 --help
    help_commands = [
        (f"{python_exe} -m claw_quant.cli --help", "主帮助"),
        (f"{python_exe} -m claw_quant.cli db --help", "数据库命令帮助"),
        (f"{python_exe} -m claw_quant.cli update --help", "更新命令帮助"),
        (f"{python_exe} -m claw_quant.cli query --help", "查询命令帮助"),
        (f"{python_exe} -m claw_quant.cli factor --help", "因子命令帮助"),
        (f"{python_exe} -m claw_quant.cli strategy --help", "策略命令帮助"),
    ]
    
    for cmd, desc in help_commands:
        success, output = run_command(cmd, f"{desc} (--help)", check_success=False)
        if not success:
            print(format_output({
                'success': False,
                'stage': f'help_{desc}',
                'message': f'帮助命令测试失败: {output}'
            }))
            return 1
        test_results.append({'stage': f'help_{desc}', 'success': True})
    
    # 2. 检查数据库状态
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli db status",
        "检查数据库状态"
    )
    if not success:
        print(format_output({
            'success': False,
            'stage': 'db_status',
            'message': f'数据库状态检查失败: {output}'
        }))
        return 1
    test_results.append({'stage': 'db_status', 'success': True})
    
    # 3. 如果数据库已运行，先停止
    db_was_running = False
    try:
        if isinstance(output, dict) and output.get('status') == 'running':
            db_was_running = True
            success, _ = run_command(
                f"{python_exe} -m claw_quant.cli db stop",
                "停止已运行的数据库"
            )
            if not success:
                print("[警告] 停止数据库失败，继续测试")
            time.sleep(2)
    except:
        pass
    
    # 4. 启动数据库
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli db start --background",
        "启动数据库服务器"
    )
    if not success:
        print(format_output({
            'success': False,
            'stage': 'db_start',
            'message': f'数据库启动失败: {output}'
        }))
        return 1
    test_results.append({'stage': 'db_start', 'success': True})
    
    # 等待数据库就绪
    print("[等待] 等待数据库就绪 (3秒)...")
    time.sleep(3)
    
    # 5. 再次检查数据库状态
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli db status",
        "验证数据库运行状态"
    )
    if not success:
        print(format_output({
            'success': False,
            'stage': 'db_verify',
            'message': f'数据库状态验证失败: {output}'
        }))
        return 1
    test_results.append({'stage': 'db_verify', 'success': True})
    
    # 6. 检查 QMT 状态
    qmt_available = check_qmt_status()
    test_results.append({'stage': 'qmt_check', 'success': qmt_available, 'optional': True})
    
    # 7. 如果 QMT 可用，测试数据更新
    if qmt_available:
        success, output = run_command(
            f"{python_exe} -m claw_quant.cli update --codes {test_code} --date {test_date}",
            f"更新股票数据 ({test_code})"
        )
        if success:
            test_results.append({'stage': 'data_update', 'success': True})
        else:
            print("[警告] 数据更新失败，继续其他测试")
            test_results.append({'stage': 'data_update', 'success': False, 'optional': True})
    
    # 8. 查询数据
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli query --code {test_code} --start {test_start} --end {test_end}",
        f"查询股票数据 ({test_code})"
    )
    test_results.append({'stage': 'data_query', 'success': success, 'optional': not qmt_available})
    
    # 9. 获取最新日期
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli latest",
        "获取最新交易日期"
    )
    test_results.append({'stage': 'latest_date', 'success': success})
    
    # 10. 获取股票列表
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli stocks --limit 5",
        "获取股票列表 (前5只)"
    )
    test_results.append({'stage': 'stock_list', 'success': success})
    
    # 11. 因子列表
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli factor list",
        "获取因子列表"
    )
    test_results.append({'stage': 'factor_list', 'success': success})
    
    # 12. 因子详情
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli factor info CROSS",
        "获取因子详情 (CROSS)"
    )
    test_results.append({'stage': 'factor_info', 'success': success, 'optional': True})
    
    # 13. 因子计算
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli factor calc CROSS --date {test_date} --codes {test_code}",
        f"计算因子值 (CROSS, {test_code})"
    )
    test_results.append({'stage': 'factor_calc', 'success': success, 'optional': True})
    
    # 14. 因子回测
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli factor backtest CROSS --codes {test_code} --start {test_start} --end {test_end}",
        f"因子回测 (CROSS, {test_code})"
    )
    test_results.append({'stage': 'factor_backtest', 'success': success, 'optional': True})
    
    # 15. 策略列表
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli strategy list",
        "获取策略列表"
    )
    test_results.append({'stage': 'strategy_list', 'success': success})
    
    # 16. 策略详情
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli strategy info CROSS_STRATEGY",
        "获取策略详情 (CROSS_STRATEGY)"
    )
    test_results.append({'stage': 'strategy_info', 'success': success, 'optional': True})
    
    # 17. 策略回测
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes {test_code} --start {test_start} --end {test_end}",
        f"策略回测 (CROSS_STRATEGY, {test_code})"
    )
    test_results.append({'stage': 'strategy_backtest', 'success': success, 'optional': True})
    
    # 18. 查看回测引擎
    success, output = run_command(
        f"{python_exe} -m claw_quant.cli engines",
        "查看可用回测引擎"
    )
    test_results.append({'stage': 'engines', 'success': success})
    
    # 19. 如果数据库原本没有运行，停止数据库
    if not db_was_running:
        success, _ = run_command(
            f"{python_exe} -m claw_quant.cli db stop",
            "停止数据库服务器"
        )
        if success:
            test_results.append({'stage': 'db_stop', 'success': True})
    
    # 汇总结果
    print("\n" + "="*60)
    print("测试结果汇总")
    print("="*60)
    
    passed = 0
    failed = 0
    optional_failed = 0
    
    for result in test_results:
        status = "✓" if result['success'] else "✗"
        optional = " (可选)" if result.get('optional') else ""
        print(f"{status} {result['stage']}{optional}")
        if result['success']:
            passed += 1
        elif result.get('optional'):
            optional_failed += 1
        else:
            failed += 1
    
    print(f"\n总计: {passed} 通过, {failed} 失败, {optional_failed} 可选失败")
    
    if failed > 0:
        print(format_output({
            'success': False,
            'message': f'自我测试完成，但有 {failed} 个必要测试失败',
            'passed': passed,
            'failed': failed,
            'optional_failed': optional_failed,
            'results': test_results
        }))
        return 1
    else:
        print(format_output({
            'success': True,
            'message': f'自我测试全部通过！',
            'passed': passed,
            'failed': failed,
            'optional_failed': optional_failed,
            'results': test_results
        }))
        return 0


def cmd_doctor(args) -> int:
    """自我诊断命令 - 检查系统运行状态"""
    import platform
    import importlib.util
    
    diagnosis = {
        'success': True,
        'timestamp': datetime.now().isoformat(),
        'system': {},
        'package': {},
        'database': {},
        'qmt': {},
        'backtest_engines': {}
    }
    
    print("\n" + "="*60)
    print("系统自我诊断")
    print("="*60)
    
    # 1. 系统信息
    print("\n[1/5] 系统信息")
    diagnosis['system'] = {
        'platform': platform.system(),
        'platform_version': platform.version(),
        'python_version': platform.python_version(),
        'machine': platform.machine(),
        'processor': platform.processor()
    }
    print(f"  操作系统: {diagnosis['system']['platform']} {diagnosis['system']['platform_version']}")
    print(f"  Python版本: {diagnosis['system']['python_version']}")
    print(f"  处理器: {diagnosis['system']['processor']}")
    
    # 2. 包信息
    print("\n[2/5] 包信息")
    try:
        import claw_quant
        package_path = claw_quant.__path__[0] if hasattr(claw_quant, '__path__') else 'Unknown'
        diagnosis['package'] = {
            'installed': True,
            'path': package_path,
            'is_site_package': 'site-packages' in package_path
        }
        print(f"  安装状态: 已安装")
        print(f"  安装路径: {package_path}")
        print(f"  安装类型: {'PyPI包' if diagnosis['package']['is_site_package'] else '本地开发'}")
    except Exception as e:
        diagnosis['package'] = {'installed': False, 'error': str(e)}
        print(f"  安装状态: 未安装或损坏 ({e})")
        diagnosis['success'] = False
    
    # 3. 数据库诊断
    print("\n[3/5] 数据库诊断")
    try:
        from .database.storage.db_server import get_default_db_path
        db_path = get_default_db_path()
        diagnosis['database']['default_path'] = db_path
        print(f"  默认数据库路径: {db_path}")
        
        # 检查数据库目录
        db_dir = os.path.dirname(db_path)
        dir_exists = os.path.exists(db_dir)
        dir_writable = os.access(db_dir, os.W_OK) if dir_exists else False
        diagnosis['database']['directory_exists'] = dir_exists
        diagnosis['database']['directory_writable'] = dir_writable
        print(f"  目录存在: {'是' if dir_exists else '否'}")
        print(f"  目录可写: {'是' if dir_writable else '否'}")
        
        # 检查数据库文件
        db_exists = os.path.exists(db_path)
        diagnosis['database']['file_exists'] = db_exists
        if db_exists:
            file_size = os.path.getsize(db_path)
            diagnosis['database']['file_size_bytes'] = file_size
            print(f"  数据库文件: 存在 ({file_size / 1024 / 1024:.2f} MB)")
        else:
            print(f"  数据库文件: 不存在")
        
        # 检查数据库服务器状态
        pid = get_db_server_pid()
        if pid:
            try:
                if sys.platform == 'win32':
                    import ctypes
                    kernel32 = ctypes.windll.kernel32
                    handle = kernel32.OpenProcess(1, False, pid)
                    if handle:
                        kernel32.CloseHandle(handle)
                        is_running = True
                    else:
                        is_running = False
                else:
                    os.kill(pid, 0)
                    is_running = True
                diagnosis['database']['server_running'] = is_running
                diagnosis['database']['server_pid'] = pid
                print(f"  服务器状态: 运行中 (PID: {pid})")
            except:
                diagnosis['database']['server_running'] = False
                print(f"  服务器状态: 未运行 (PID文件残留)")
                remove_db_server_pid()
        else:
            diagnosis['database']['server_running'] = False
            print(f"  服务器状态: 未运行")
        
        # 测试数据库连接
        from .database.api import StockAPI
        api = StockAPI()
        can_connect = api.ping()
        diagnosis['database']['can_connect'] = can_connect
        print(f"  连接测试: {'成功' if can_connect else '失败'}")
        
        if can_connect:
            try:
                latest = api.get_latest_date()
                diagnosis['database']['latest_date'] = latest.strftime('%Y-%m-%d') if latest else None
                print(f"  最新数据日期: {diagnosis['database']['latest_date'] or '无数据'}")
            except Exception as e:
                print(f"  最新数据日期: 查询失败 ({e})")
        
    except Exception as e:
        diagnosis['database']['error'] = str(e)
        print(f"  诊断失败: {e}")
        diagnosis['success'] = False
    
    # 4. QMT诊断
    print("\n[4/5] QMT客户端诊断")
    try:
        from .database.source.qmt import QMTDataSource
        qmt = QMTDataSource()
        # QMT 在初始化时自动连接，使用 is_connected 检查状态
        can_connect = qmt.is_connected()
        diagnosis['qmt']['can_connect'] = can_connect
        print(f"  连接状态: {'已连接' if can_connect else '未连接'}")
        
        if can_connect:
            try:
                # 尝试获取股票列表来验证功能
                stock_list = qmt.get_stock_list()
                can_read = len(stock_list) > 0
                diagnosis['qmt']['can_read'] = can_read
                diagnosis['qmt']['stock_count'] = len(stock_list)
                print(f"  读取测试: {'成功' if can_read else '失败'}")
                print(f"  股票数量: {len(stock_list)}")
            except Exception as e:
                diagnosis['qmt']['can_read'] = False
                diagnosis['qmt']['read_error'] = str(e)
                print(f"  读取测试: 失败 ({e})")
        else:
            diagnosis['qmt']['can_read'] = False
            print(f"  读取测试: 跳过 (未连接)")
            
    except Exception as e:
        diagnosis['qmt']['error'] = str(e)
        diagnosis['qmt']['can_connect'] = False
        diagnosis['qmt']['can_read'] = False
        print(f"  诊断失败: {e}")
    
    # 5. 回测引擎诊断
    print("\n[5/5] 回测引擎依赖诊断")
    engines_to_check = [
        ('vnpy', 'vnpy', 'VNPy量化框架'),
        ('vnpy_ctastrategy', 'vnpy_ctastrategy', 'VNPy CTA策略模块'),
        ('jqdata', 'jqdata', '聚宽数据接口'),
        ('backtrader', 'backtrader', 'Backtrader回测框架'),
        ('zipline', 'zipline', 'Zipline回测框架'),
    ]
    
    for module_name, package_name, description in engines_to_check:
        try:
            spec = importlib.util.find_spec(module_name)
            if spec is not None:
                module = importlib.import_module(module_name)
                version = getattr(module, '__version__', 'unknown')
                diagnosis['backtest_engines'][package_name] = {
                    'installed': True,
                    'version': version,
                    'path': spec.origin
                }
                print(f"  ✓ {description} ({package_name}): 已安装 (v{version})")
            else:
                diagnosis['backtest_engines'][package_name] = {
                    'installed': False,
                    'optional': True
                }
                print(f"  ✗ {description} ({package_name}): 未安装 (可选)")
        except Exception as e:
            diagnosis['backtest_engines'][package_name] = {
                'installed': False,
                'error': str(e),
                'optional': True
            }
            print(f"  ✗ {description} ({package_name}): 检查失败 ({e})")
    
    # 汇总
    print("\n" + "="*60)
    print("诊断汇总")
    print("="*60)
    
    issues = []
    if not diagnosis['package'].get('installed'):
        issues.append("包未正确安装")
    if not diagnosis['database'].get('directory_writable'):
        issues.append("数据库目录不可写")
    if not diagnosis['database'].get('can_connect'):
        issues.append("数据库无法连接")
    if not diagnosis['qmt'].get('can_connect'):
        issues.append("QMT未连接 (可选)")
    
    if issues:
        print(f"发现 {len(issues)} 个问题:")
        for issue in issues:
            print(f"  - {issue}")
        diagnosis['success'] = False
    else:
        print("系统状态良好，未发现明显问题")
    
    print(format_output(diagnosis))
    return 0 if diagnosis['success'] else 1


def cmd_backtest(args) -> int:
    """回测命令 - 支持多引擎"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    code = codes[0]  # 目前只支持单只股票回测
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 多引擎对比模式
    if args.compare:
        return _run_compare_backtest(api, args, code, factor_params)
    
    # 单引擎模式
    return _run_single_backtest(api, args, code, factor_params)


def _run_single_backtest(api, args, code: str, factor_params: Dict[str, Any]) -> int:
    """运行单引擎回测"""
    try:
        # 运行回测
        result = api.run_backtest(
            factor_name=args.factor,
            code=code,
            start_date=args.start,
            end_date=args.end,
            init_capital=args.capital,
            factor_params=factor_params,
            engine=args.engine if args.engine else None
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }))
        return 1


def _run_compare_backtest(api, args, code: str, factor_params: Dict[str, Any]) -> int:
    """运行多引擎对比回测"""
    # 获取可用引擎
    available_engines = api.get_available_engines()
    engines_to_test = []
    
    for e in available_engines:
        if e['available']:
            engines_to_test.append(e['type'])
    
    if len(engines_to_test) < 2:
        print(format_output({
            'success': False,
            'message': f'可用引擎不足2个，无法进行比对（当前可用: {engines_to_test}）'
        }))
        return 1
    
    print(format_output({
        'message': f'开始多引擎对比回测',
        'engines': engines_to_test,
        'factor': args.factor,
        'code': code,
        'start_date': args.start.strftime('%Y-%m-%d'),
        'end_date': args.end.strftime('%Y-%m-%d'),
        'factor_params': factor_params
    }))
    print("-" * 60)
    
    results = {}
    errors = {}
    
    for engine_name in engines_to_test:
        print(f"\n正在使用引擎 '{engine_name}' 运行回测...")
        try:
            result = api.run_backtest(
                factor_name=args.factor,
                code=code,
                start_date=args.start,
                end_date=args.end,
                init_capital=args.capital,
                factor_params=factor_params,
                engine=engine_name
            )
            
            if result.get('success'):
                results[engine_name] = result
                print(f"  ✓ 成功 - 总收益: {result['total_return']:.2%}")
            else:
                errors[engine_name] = result.get('error', '未知错误')
                print(f"  ✗ 失败 - {result.get('error', '未知错误')}")
        except Exception as e:
            errors[engine_name] = str(e)
            print(f"  ✗ 异常 - {e}")
    
    # 输出对比结果
    print("\n" + "=" * 60)
    print("多引擎回测结果对比")
    print("=" * 60)
    
    if len(results) > 0:
        # 构建对比表格
        comparison = {
            'success': True,
            'comparison': {},
            'summary': {}
        }
        
        # 详细结果
        for engine_name, result in results.items():
            comparison['comparison'][engine_name] = {
                'total_return': f"{result['total_return']:.2%}",
                'annual_return': f"{result['annual_return']:.2%}",
                'max_drawdown': f"{result['max_drawdown']:.2%}",
                'sharpe_ratio': f"{result['sharpe_ratio']:.2f}",
                'total_trades': result['total_trades'],
                'win_rate': f"{result['win_rate']:.2%}",
                'final_capital': f"{result['final_capital']:,.2f}"
            }
        
        # 汇总统计
        if len(results) > 1:
            returns = [r['total_return'] for r in results.values()]
            comparison['summary'] = {
                'engine_count': len(results),
                'max_return': f"{max(returns):.2%}",
                'min_return': f"{min(returns):.2%}",
                'avg_return': f"{sum(returns)/len(returns):.2%}",
                'return_std': f"{(sum((x-sum(returns)/len(returns))**2 for x in returns)/len(returns))**0.5:.2%}",
                'consistency': '高' if max(returns) - min(returns) < 0.01 else '中' if max(returns) - min(returns) < 0.05 else '低'
            }
        
        # 错误信息
        if errors:
            comparison['errors'] = errors
        
        print(format_output(comparison))
    else:
        print(format_output({
            'success': False,
            'message': '所有引擎回测均失败',
            'errors': errors
        }))
    
    return 0 if len(results) > 0 else 1


def cmd_factorbacktest(args) -> int:
    """因子回测 - 测试因子预测能力（IC、分层收益）"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    
    # 解析因子参数
    factor_params = {}
    if args.params:
        try:
            factor_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    try:
        # 运行因子测试
        result = api.run_factor_test(
            factor_name=args.factor,
            codes=codes,
            start_date=args.start,
            end_date=args.end,
            factor_params=factor_params,
            method=args.method
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'因子回测失败: {str(e)}'
        }))
        return 1


def cmd_strategybacktest(args) -> int:
    """策略回测 - 测试策略盈利能力（资金曲线、收益率等）"""
    from .skills.claw_quant.tools.backtest_api import BacktestToolAPI
    
    api = BacktestToolAPI()
    
    # 检查数据库连接
    if not api.ping():
        print(format_output({
            'success': False,
            'message': '数据库连接失败。请启动数据库服务：Windows运行 start_db_server.bat，Linux/Mac运行 ./start_db_server.sh'
        }))
        return 1
    
    # 解析股票代码
    codes = args.codes.split(',') if args.codes else ['000001.SZ']
    code = codes[0]  # 目前只支持单只股票回测
    
    # 解析策略参数
    strategy_params = {}
    if args.params:
        try:
            strategy_params = json.loads(args.params)
        except json.JSONDecodeError as e:
            print(format_output({
                'success': False,
                'message': f'参数解析失败: {str(e)}'
            }))
            return 1
    
    # 多引擎对比模式
    if args.compare:
        return _run_strategy_compare_backtest(api, args, code, strategy_params)
    
    # 单引擎模式
    return _run_single_strategy_backtest(api, args, code, strategy_params)


def _run_single_strategy_backtest(api, args, code: str, strategy_params: Dict[str, Any]) -> int:
    """运行单引擎策略回测"""
    try:
        result = api.run_strategy_backtest(
            strategy_name=args.strategy,
            code=code,
            start_date=args.start,
            end_date=args.end,
            init_capital=args.capital,
            strategy_params=strategy_params,
            engine=args.engine if args.engine else None
        )
        
        print(format_output(result))
        return 0 if result.get('success') else 1
        
    except Exception as e:
        print(format_output({
            'success': False,
            'message': f'策略回测失败: {str(e)}'
        }))
        return 1


def _run_strategy_compare_backtest(api, args, code: str, strategy_params: Dict[str, Any]) -> int:
    """运行多引擎策略回测对比"""
    available_engines = api.get_available_engines()
    engines_to_test = [e['type'] for e in available_engines if e['available']]
    
    if len(engines_to_test) < 2:
        print(format_output({
            'success': False,
            'message': f'可用引擎不足2个，无法进行比对（当前可用: {engines_to_test}）'
        }))
        return 1
    
    print(format_output({
        'message': f'开始多引擎策略回测对比',
        'engines': engines_to_test,
        'strategy': args.strategy,
        'code': code,
        'start_date': args.start.strftime('%Y-%m-%d'),
        'end_date': args.end.strftime('%Y-%m-%d'),
        'strategy_params': strategy_params
    }))
    print("-" * 60)
    
    results = {}
    errors = {}
    
    for engine_name in engines_to_test:
        print(f"\n正在使用引擎 '{engine_name}' 运行策略回测...")
        try:
            result = api.run_strategy_backtest(
                strategy_name=args.strategy,
                code=code,
                start_date=args.start,
                end_date=args.end,
                init_capital=args.capital,
                strategy_params=strategy_params,
                engine=engine_name
            )
            
            if result.get('success'):
                results[engine_name] = result
                print(f"  ✓ 成功 - 总收益: {result['total_return']:.2%}")
            else:
                errors[engine_name] = result.get('error', '未知错误')
                print(f"  ✗ 失败 - {result.get('error', '未知错误')}")
        except Exception as e:
            errors[engine_name] = str(e)
            print(f"  ✗ 异常 - {e}")
    
    print("\n" + "=" * 60)
    print("多引擎策略回测结果对比")
    print("=" * 60)
    
    if len(results) > 0:
        comparison = {
            'success': True,
            'comparison': {},
            'summary': {}
        }
        
        for engine_name, result in results.items():
            comparison['comparison'][engine_name] = {
                'total_return': f"{result['total_return']:.2%}",
                'annual_return': f"{result['annual_return']:.2%}",
                'max_drawdown': f"{result['max_drawdown']:.2%}",
                'sharpe_ratio': f"{result['sharpe_ratio']:.2f}",
                'total_trades': result['total_trades'],
                'win_rate': f"{result['win_rate']:.2%}",
                'final_capital': f"{result['final_capital']:,.2f}"
            }
        
        if len(results) > 1:
            returns = [r['total_return'] for r in results.values()]
            comparison['summary'] = {
                'engine_count': len(results),
                'max_return': f"{max(returns):.2%}",
                'min_return': f"{min(returns):.2%}",
                'avg_return': f"{sum(returns)/len(returns):.2%}",
                'return_std': f"{(sum((x-sum(returns)/len(returns))**2 for x in returns)/len(returns))**0.5:.2%}",
                'consistency': '高' if max(returns) - min(returns) < 0.01 else '中' if max(returns) - min(returns) < 0.05 else '低'
            }
        
        if errors:
            comparison['errors'] = errors
        
        print(format_output(comparison))
    else:
        print(format_output({
            'success': False,
            'message': '所有引擎策略回测均失败',
            'errors': errors
        }))
    
    return 0 if len(results) > 0 else 1


def main():
    """主入口"""
    parser = argparse.ArgumentParser(
        description='StockClaw CLI - 股票数据管理与回测工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 更新单只股票数据
  python -m claw_quant.cli update --codes 000001.SZ --date 2026-04-20
  
数据管理命令:
  # 更新数据（从QMT到本地数据库）
  python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01
  python -m claw_quant.cli update --date 2024-06-01  # 更新所有股票
  
  # 查询数据
  python -m claw_quant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01
  python -m claw_quant.cli query --codes 000001.SZ,000002.SZ --start 2024-01-01 --end 2024-06-01
  
  # 获取最新交易日期
  python -m claw_quant.cli latest
  
  # 获取股票列表
  python -m claw_quant.cli stocks --limit 10

因子管理命令:
  # 查看可用因子
  python -m claw_quant.cli factor list
  
  # 查看因子详情
  python -m claw_quant.cli factor info CROSS
  
  # 计算因子值
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 因子回测（IC测试）
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 因子回测（分层收益测试）
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer

策略管理命令:
  # 查看可用策略
  python -m claw_quant.cli strategy list
  
  # 查看策略详情
  python -m claw_quant.cli strategy info CROSS_STRATEGY
  
  # 策略回测
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

数据库管理命令:
  # 启动数据库服务器（必须先启动数据库才能使用其他命令）
  python -m claw_quant.cli db start
  
  # 后台启动数据库服务器
  python -m claw_quant.cli db start --background
  
  # 停止数据库服务器
  python -m claw_quant.cli db stop
  
  # 查看数据库服务器状态
  python -m claw_quant.cli db status

其他命令:
  # 查看可用回测引擎
  python -m claw_quant.cli engines

使用说明:
  1. 所有日期格式为 YYYY-MM-DD
  2. 股票代码格式为 000001.SZ（深市）或 600000.SH（沪市）
  3. 使用 --help 查看具体命令的详细参数，如：python -m claw_quant.cli factor backtest --help
  4. 因子是纯数据计算，策略是完整交易系统（包含仓位管理、风控等）
        '''
    )
    
    subparsers = parser.add_subparsers(dest='command', help='可用命令', metavar='COMMAND')
    
    # db 命令（数据库管理）
    db_parser = subparsers.add_parser(
        'db',
        help='数据库服务器管理',
        description='启动、停止和管理DuckDB数据库服务器。',
        epilog='''
数据库服务器管理命令:
  # 启动数据库服务器（前台运行）
  python -m claw_quant.cli db start
  
  # 后台启动数据库服务器
  python -m claw_quant.cli db start --background
  
  # 指定数据库路径启动
  python -m claw_quant.cli db start --db-path /path/to/db
  
  # 停止数据库服务器
  python -m claw_quant.cli db stop
  
  # 查看数据库状态
  python -m claw_quant.cli db status

说明:
  - 数据库服务器提供HTTP API访问DuckDB数据库
  - 默认地址: http://127.0.0.1:9529
  - 数据默认存储在系统缓存目录
  - 必须先启动数据库才能使用其他CLI命令
        '''
    )
    db_subparsers = db_parser.add_subparsers(dest='db_command', help='数据库子命令', metavar='DB_COMMAND')
    
    # db start 命令
    db_start_parser = db_subparsers.add_parser(
        'start',
        help='启动数据库服务器',
        description='启动DuckDB HTTP API服务器。'
    )
    db_start_parser.add_argument(
        '--db-path',
        type=str,
        help='数据库文件路径（默认: 系统缓存目录）'
    )
    db_start_parser.add_argument(
        '--host',
        type=str,
        default='127.0.0.1',
        help='服务器地址（默认: 127.0.0.1）'
    )
    db_start_parser.add_argument(
        '--port',
        type=int,
        default=9529,
        help='服务器端口（默认: 9529）'
    )
    db_start_parser.add_argument(
        '--background', '-b',
        action='store_true',
        help='后台运行模式'
    )
    db_start_parser.set_defaults(func=cmd_db_start)
    
    # db stop 命令
    db_stop_parser = db_subparsers.add_parser(
        'stop',
        help='停止数据库服务器',
        description='停止正在运行的DuckDB HTTP API服务器。'
    )
    db_stop_parser.set_defaults(func=cmd_db_stop)
    
    # db status 命令
    db_status_parser = db_subparsers.add_parser(
        'status',
        help='查看数据库服务器状态',
        description='检查数据库服务器是否正在运行。'
    )
    db_status_parser.set_defaults(func=cmd_db_status)
    
    # update 命令
    update_parser = subparsers.add_parser(
        'update',
        help='从QMT更新数据到数据库',
        description='从QMT获取实时行情数据并保存到本地DuckDB数据库。',
        epilog='''
前提条件:
  1. QMT客户端已登录
  2. QMT已下载所需日期的数据
  3. DuckDB数据库服务已启动

示例:
  # 更新单只股票
  python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01
  
  # 更新多只股票
  python -m claw_quant.cli update --codes 000001.SZ,000002.SZ --date 2024-06-01
  
  # 更新所有股票（不指定--codes）
  python -m claw_quant.cli update --date 2024-06-01
  
  # 更新今日数据（默认日期）
  python -m claw_quant.cli update

注意:
  - 股票代码格式：深市000001.SZ，沪市600000.SH
  - 不指定--codes时会更新所有股票，耗时较长
  - 重复更新同一日期会覆盖已有数据
        '''
    )
    update_parser.add_argument(
        '--codes',
        type=str,
        help='股票代码，多个用逗号分隔，如：000001.SZ,000002.SZ。不指定则更新所有股票'
    )
    update_parser.add_argument(
        '--date',
        type=parse_date,
        default=date.today(),
        help='目标日期，格式：YYYY-MM-DD，默认为今天'
    )
    update_parser.set_defaults(func=cmd_update)
    
    # query 命令
    query_parser = subparsers.add_parser(
        'query',
        help='查询数据库中的数据',
        description='从本地DuckDB数据库查询股票历史行情数据。',
        epilog='''
前提条件:
  数据已存在于数据库（需先运行update命令更新数据）

示例:
  # 查询单只股票
  python -m claw_quant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 查询多只股票
  python -m claw_quant.cli query --codes 000001.SZ,000002.SZ --start 2024-01-01 --end 2024-06-01

输出字段:
  - trade_date: 交易日期
  - code: 股票代码
  - open: 开盘价
  - high: 最高价
  - low: 最低价
  - close: 收盘价
  - volume: 成交量
  - amount: 成交金额

注意:
  - --code 和 --codes 必须指定其中一个
  - 日期格式：YYYY-MM-DD
  - 查询前确保数据已更新
        '''
    )
    query_group = query_parser.add_mutually_exclusive_group(required=True)
    query_group.add_argument(
        '--code',
        type=str,
        help='单只股票代码，如：000001.SZ'
    )
    query_group.add_argument(
        '--codes',
        type=str,
        help='多只股票代码，用逗号分隔，如：000001.SZ,000002.SZ'
    )
    query_parser.add_argument(
        '--start',
        type=parse_date,
        required=True,
        help='开始日期，格式：YYYY-MM-DD'
    )
    query_parser.add_argument(
        '--end',
        type=parse_date,
        required=True,
        help='结束日期，格式：YYYY-MM-DD'
    )
    query_parser.set_defaults(func=cmd_query)
    
    # latest 命令
    latest_parser = subparsers.add_parser(
        'latest',
        help='获取数据库中最新的交易日期',
        description='查询本地数据库中已存储的最新交易日期。用于确认数据更新状态。'
    )
    latest_parser.set_defaults(func=cmd_latest)
    
    # stocks 命令
    stocks_parser = subparsers.add_parser(
        'stocks',
        help='获取股票列表',
        description='获取系统中的股票列表，包括股票代码和名称。',
        epilog='''
示例:
  # 获取所有股票
  python -m claw_quant.cli stocks
  
  # 只获取前10只
  python -m claw_quant.cli stocks --limit 10

输出字段:
  - code: 股票代码
  - name: 股票名称
  - industry: 所属行业
        '''
    )
    stocks_parser.add_argument(
        '--limit',
        type=int,
        help='限制返回数量，不指定则返回所有股票'
    )
    stocks_parser.set_defaults(func=cmd_stocks)
    
    # factor 命令 - 使用子命令
    factor_parser = subparsers.add_parser(
        'factor',
        help='因子管理',
        description='因子管理命令。因子是纯数据计算，输出信号值。',
        epilog='''
示例:
  # 列出所有可用因子
  python -m claw_quant.cli factor list
  
  # 查看CROSS因子详情
  python -m claw_quant.cli factor info CROSS
  
  # 计算CROSS因子在2024-06-01的值
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 对CROSS因子进行IC测试
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 对CROSS因子进行分层收益测试
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer

说明:
  - factor list: 显示所有可用因子及其参数
  - factor info: 查看因子的详细说明和参数定义
  - factor calc: 计算指定日期的因子值，输出原始值、排名、百分位、Z-score
  - factor backtest: 测试因子的预测能力（IC值或分层收益）
        '''
    )
    factor_subparsers = factor_parser.add_subparsers(dest='factor_subcommand', help='因子子命令', metavar='SUBCOMMAND')
    
    # factor list
    factor_list_parser = factor_subparsers.add_parser(
        'list',
        help='列出所有可用因子',
        description='列出系统中所有可用的因子，包括因子名称、描述和参数。'
    )
    factor_list_parser.set_defaults(func=cmd_factor)
    
    # factor info
    factor_info_parser = factor_subparsers.add_parser(
        'info',
        help='查看因子详情',
        description='查看指定因子的详细信息，包括描述、参数定义和默认值。'
    )
    factor_info_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_info_parser.set_defaults(func=cmd_factor)
    
    # factor calc
    factor_calc_parser = factor_subparsers.add_parser(
        'calc',
        help='计算因子值',
        description='计算指定日期股票的因子值。输出包括原始值、排名、百分位和Z-score。',
        epilog='''
示例:
  # 计算单只股票的因子值
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ
  
  # 计算多只股票的因子值
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --codes 000001.SZ,000002.SZ
  
  # 计算所有股票的因子值，只显示前50条
  python -m claw_quant.cli factor calc CROSS --date 2024-06-01 --limit 50

输出字段:
  - calc_date: 计算日期
  - code: 股票代码
  - factor_code: 因子代码
  - value: 因子原始值
  - rank_value: 排名（从高到低）
  - percentile: 百分位（0-1）
  - zscore: Z-score标准化值
        '''
    )
    factor_calc_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_calc_parser.add_argument('--date', type=parse_date, required=True, help='计算日期，格式：YYYY-MM-DD')
    factor_calc_parser.add_argument('--codes', type=str, help='股票代码，多个用逗号分隔，如：000001.SZ,000002.SZ。不指定则计算所有股票')
    factor_calc_parser.add_argument('--params', type=str, help='因子参数，JSON格式，如：\'{"short_window":10,"long_window":30}\'')
    factor_calc_parser.add_argument('--limit', type=int, default=20, help='限制返回结果数量，默认20，设为0返回全部')
    factor_calc_parser.set_defaults(func=cmd_factor)
    
    # factor backtest
    factor_backtest_parser = factor_subparsers.add_parser(
        'backtest',
        help='因子回测（IC测试、分层收益）',
        description='测试因子的预测能力。IC测试计算因子值与未来收益的相关系数；分层测试将股票按因子值分5层，观察各层收益差异。',
        epilog='''
示例:
  # IC测试（默认）
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 分层收益测试
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer
  
  # 带参数的回测
  python -m claw_quant.cli factor backtest CROSS --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --params '{"short_window":10,"long_window":30}'

测试方法说明:
  ic: IC测试，计算因子值与未来1日收益的相关系数
      - IC > 0.03: 因子有一定预测能力
      - IC > 0.05: 因子预测能力较强
      - IC绝对值越大，预测能力越强
  
  layer: 分层收益测试，按因子值将股票分为5层
      - 观察各层收益是否单调（L1 < L2 < L3 < L4 < L5）
      - 单调性越好，因子越有效
      - 计算顶层与底层收益差（spread）
        '''
    )
    factor_backtest_parser.add_argument('name', type=str, help='因子名称，如：CROSS, MACD, MA, RSI')
    factor_backtest_parser.add_argument('--start', type=parse_date, required=True, help='开始日期，格式：YYYY-MM-DD')
    factor_backtest_parser.add_argument('--end', type=parse_date, required=True, help='结束日期，格式：YYYY-MM-DD')
    factor_backtest_parser.add_argument('--codes', type=str, default='000001.SZ', help='股票代码，多个用逗号分隔，如：000001.SZ,000002.SZ')
    factor_backtest_parser.add_argument('--params', type=str, help='因子参数，JSON格式，如：\'{"short_window":5,"long_window":20}\'')
    factor_backtest_parser.add_argument('--method', type=str, choices=['ic', 'layer'], default='ic', help='测试方法：ic=IC测试，layer=分层收益测试')
    factor_backtest_parser.set_defaults(func=cmd_factor)
    
    # strategy 命令 - 使用子命令
    strategy_parser = subparsers.add_parser(
        'strategy',
        help='策略管理',
        description='策略管理命令。策略是完整的交易系统，包含信号生成、仓位管理、风控等。',
        epilog='''
示例:
  # 列出所有可用策略
  python -m claw_quant.cli strategy list
  
  # 查看CROSS_STRATEGY策略详情
  python -m claw_quant.cli strategy info CROSS_STRATEGY
  
  # 对CROSS_STRATEGY进行回测
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 指定初始资金和参数进行回测
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --capital 500000 --params '{"short_window":10,"long_window":30}'

说明:
  - strategy list: 显示所有可用策略及其参数
  - strategy info: 查看策略的详细说明、参数和默认配置
  - strategy backtest: 测试策略的盈利能力，输出资金曲线和各项指标

因子与策略的区别:
  - 因子：纯数据计算，输出信号值（如CROSS因子计算均线差值）
  - 策略：完整交易系统，使用因子生成信号，并执行买卖、仓位管理、风控
        '''
    )
    strategy_subparsers = strategy_parser.add_subparsers(dest='strategy_subcommand', help='策略子命令', metavar='SUBCOMMAND')
    
    # strategy list
    strategy_list_parser = strategy_subparsers.add_parser(
        'list',
        help='列出所有可用策略',
        description='列出系统中所有可用的策略，包括策略名称、类型、描述和可调参数。'
    )
    strategy_list_parser.set_defaults(func=cmd_strategy)
    
    # strategy info
    strategy_info_parser = strategy_subparsers.add_parser(
        'info',
        help='查看策略详情',
        description='查看指定策略的详细信息，包括描述、使用的因子、参数定义、默认配置等。'
    )
    strategy_info_parser.add_argument('name', type=str, help='策略名称，如：CROSS_STRATEGY, MACD_STRATEGY')
    strategy_info_parser.set_defaults(func=cmd_strategy)
    
    # strategy backtest
    strategy_backtest_parser = strategy_subparsers.add_parser(
        'backtest',
        help='策略回测（资金曲线、收益率等）',
        description='测试策略的盈利能力。输出资金曲线、总收益率、年化收益、最大回撤、夏普比率、交易记录等。',
        epilog='''
示例:
  # 基本回测
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
  
  # 指定初始资金
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --capital 500000
  
  # 自定义策略参数
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --params '{"short_window":10,"long_window":30}'
  
  # 指定回测引擎
  python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --engine vnpy

输出指标说明:
  - total_return: 总收益率
  - annual_return: 年化收益率
  - max_drawdown: 最大回撤（负数表示亏损）
  - sharpe_ratio: 夏普比率（风险调整后收益，>1较好）
  - total_trades: 总交易次数
  - win_rate: 胜率
  - trades: 详细交易记录（买入/卖出时间、价格、数量、原因）
        '''
    )
    strategy_backtest_parser.add_argument('name', type=str, help='策略名称，如：CROSS_STRATEGY, MACD_STRATEGY')
    strategy_backtest_parser.add_argument('--start', type=parse_date, required=True, help='开始日期，格式：YYYY-MM-DD')
    strategy_backtest_parser.add_argument('--end', type=parse_date, required=True, help='结束日期，格式：YYYY-MM-DD')
    strategy_backtest_parser.add_argument('--codes', type=str, default='000001.SZ', help='股票代码，多个用逗号分隔，如：000001.SZ,000002.SZ')
    strategy_backtest_parser.add_argument('--capital', type=float, default=1000000.0, help='初始资金，默认1000000')
    strategy_backtest_parser.add_argument('--params', type=str, help='策略参数，JSON格式，如：\'{"short_window":5,"long_window":20}\'')
    strategy_backtest_parser.add_argument('--engine', type=str, choices=['local', 'cskhquant', 'jqdata', 'vnpy'], help='指定回测引擎：local=本地引擎(默认), cskhquant=CSKhQuant, jqdata=聚宽, vnpy=VNPY')
    strategy_backtest_parser.set_defaults(func=cmd_strategy)
    
    # engines 命令
    engines_parser = subparsers.add_parser(
        'engines',
        help='查看可用回测引擎',
        description='显示所有可用的回测引擎及其状态。'
    )
    engines_parser.set_defaults(func=cmd_engines)
    
    # selftest 命令
    selftest_parser = subparsers.add_parser(
        'selftest',
        help='运行自我测试',
        description='执行完整的自动化测试流程，验证所有 CLI 功能是否正常工作。',
        epilog='''
测试流程:
  1. 测试所有 --help 命令
  2. 检查数据库状态
  3. 启动数据库服务器
  4. 检查 QMT 连接状态
  5. 更新股票数据（如果 QMT 可用）
  6. 查询股票数据
  7. 获取最新交易日期
  8. 获取股票列表
  9. 因子列表、详情、计算、回测
  10. 策略列表、详情、回测
  11. 查看回测引擎
  12. 停止数据库服务器

示例:
  python -m claw_quant.cli selftest

注意:
  - 测试会自动启动和停止数据库
  - 如果 QMT 未连接，数据更新测试会被跳过
  - 测试失败时会显示详细错误信息
        '''
    )
    selftest_parser.set_defaults(func=cmd_selftest)
    
    # doctor 命令
    doctor_parser = subparsers.add_parser(
        'doctor',
        help='运行系统诊断',
        description='检查系统运行状态，包括版本、数据库、QMT、回测引擎等。',
        epilog='''
诊断项目:
  1. 系统信息 (操作系统、Python版本)
  2. 包信息 (安装路径、版本)
  3. 数据库诊断 (路径、运行状态、连接测试)
  4. QMT客户端诊断 (连接状态、读取测试)
  5. 回测引擎依赖 (vnpy, jqdata, backtrader等)

示例:
  python -m claw_quant.cli doctor

输出:
  以JSON格式返回详细的诊断信息
  包含每个组件的状态和可能的错误信息
        '''
    )
    doctor_parser.set_defaults(func=cmd_doctor)
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    return args.func(args)


if __name__ == '__main__':
    sys.exit(main())
