# -*- coding: utf-8 -*-
"""
@File    : test_redis_lock.py
@Author  : Jay
@Date    : 2026/3/19 15:39
@Desc    : 测试 AsyncRedisAtomicMultiLock 分布式锁功能

组合锁：所有 KEYS 都要同时不存在或被删除，才认为锁释放
单键锁：单个 KEY 被删除即释放锁
"""

from redis_xsync import register_redis

if __name__ == "__main__":
    import threading, asyncio

    cfg = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0,
        'password': '',
        'decode_responses': True
    }
    cx = 0
    redisXsync = register_redis(label='redis_xsync', **cfg)
    AsyncRedisAtomicMultiLock = redisXsync.AsyncRedisAtomicMultiLock


    async def async_example():
        global cx
        while True:
            try:
                async with AsyncRedisAtomicMultiLock("lock2", db=0, ttl_ms=2000, blocking=True):
                    # async with redisXsyn cas r: # 或者也可以使用默认 db
                    async with redisXsync(db=0) as r:
                        await r.setnx(f"db-async", str(cx))
                        cx += 1
                        await asyncio.sleep(.5)
                        print(f"async_example-- {cx=}")
            except:
                pass


    def sync_example():
        global cx
        while True:
            try:
                with AsyncRedisAtomicMultiLock("lock2", db=0, ttl_ms=2000, blocking=True):
                    with redisXsync(db=0) as r:
                        r.setnx("db2", str(cx))
                        cx += 1
                        print(f"sync_example ++ {cx=}")

                    with redisXsync(db=0) as r:
                        r.setnx("db3", str(cx))
                        cx += 1
                        print(f"sync_example++ {cx=}")
            except Exception as E:
                raise E


    # # 同步线程
    # for _ in range(3):
    threading.Thread(target=sync_example).start()
    threading.Thread(target=sync_example).start()

    asyncio.run(async_example())
