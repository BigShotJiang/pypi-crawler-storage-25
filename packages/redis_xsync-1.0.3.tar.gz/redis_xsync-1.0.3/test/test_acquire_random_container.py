# -*- coding: utf-8 -*-
"""
@File    : test_acquire_random_container.py
@Author  : Jay
@Date    : 2026/3/23 13:59
@Desc    :
"""

from redis_xsync import register_redis


def test_redis_rate_limit_sync(limiter):
    with limiter(redis_key="crawler:identity:flow_limit") as lt:
        while True:
            # print(lt.acquire_random_containers())
            print(lt.wait_acquire_random_container())


async def test_redis_rate_limit(limiter):
    async with redisXsync.Limited(redis_key="crawler:identity:flow_limit") as lt:
        while True:
            print(await lt.acquire_random_containers(quantity=2))
            print(json.loads(await lt.ask_available_container()))


if __name__ == '__main__':
    import threading

    cfg = {
        'host': '127.0.0.1',
        'port': 6379,
        'db': 0,
        'password': '',
        'decode_responses': True
    }
    redisXsync = register_redis(label='redis_xsync', **cfg)
    Limited = redisXsync.Limited
    import json


    # ['acquire_random_container', 'acquire_random_containers', 'ask_available_container', 'ask_available_containers', 'close', 'disable_containers', 'set_available_containers', 'wait_ask_available_container', 'wait_ask_available_containers']
    async def t():
        async with Limited(redis_key="crawler:identity:flow_limit") as lt:
            print(json.loads(await lt.ask_available_container()))


    with Limited(redis_key="crawler:identity:flow_limit") as lt:
        print(json.loads(lt.ask_available_container()))

    threading.Thread(target=test_redis_rate_limit_sync, args=(Limited,)).start()
    # threading.Thread(target=test_redis_rate_limit_sync, args=(Limited,)).start()
    # asyncio.run(test_redis_rate_limit(Limited))
