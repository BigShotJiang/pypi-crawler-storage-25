# -*- coding: utf-8 -*-
"""
@File    : test_acquire_available_container.py
@Author  : Jay
@Date    : 2026/3/27 14:57
@Desc    :
"""
import time

from redis_xsync import register_redis


def test_acquire_available_containers_sync1(limited):
    while True:
        try:
            with limited.acquire_available_container(timeout=9_000, lock_release_ms=10_000) as container:
                s = f"test_acquire_available_containers_sync1 --> {container}"
                print(int(time.time()), s)
                time.sleep(10)
            # limited.disable_containers(container["id"])
        except:
            pass


async def test_acquire_available_containers_async2(limited):
    while True:
        try:
            async with limited.acquire_available_container(timeout=20_000, lock_release_ms=3_000) as container:
                print(int(time.time()), f"test_acquire_available_containers_async2 --> {container}")
        except:
            pass


async def test_acquire_available_containers1(limited):
    async with limited.acquire_available_container(timeout=20_000) as container:
        print(f"test_acquire_available_containers1 --> {container}")
        await limited.disable_containers(container["id"])


if __name__ == '__main__':
    import threading, asyncio

    cfg = {
        'host': '47.77.206.244',
        'port': 6379,
        'db': 0,
        'password': 'Alsdawo*Z96@J!Nddawaw4k#R1$hjJ8v!1daw1reach',
        'decode_responses': True
    }
    redis = register_redis(label="redis_xsync", **cfg)
    limited = redis.Limited(redis_key="crawler:identity:flow_limit")
    # test_acquire_available_containers_sync1(limited)

    threading.Thread(target=test_acquire_available_containers_sync1, args=[limited]).start()
    threading.Thread(target=test_acquire_available_containers_sync1, args=[limited]).start()
    threading.Thread(target=test_acquire_available_containers_sync1, args=[limited]).start()
    threading.Thread(target=test_acquire_available_containers_sync1, args=[limited]).start()
    # threading.Thread(target=test_acquire_available_containers_sync2, args=[limited]).run()
    asyncio.run(test_acquire_available_containers_async2(limited))
