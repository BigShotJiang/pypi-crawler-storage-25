# -*- coding: utf-8 -*-
"""
@File    : distributed_lock.py
@Author  : Jay
@Date    : 2026/3/18 17:47
@Desc    : Redis connection pool and distributed lock implementation
"""

import asyncio
import time
import uuid

# Lua script: atomic acquire multi-key lock
_ACQUIRE_LUA = """
-- Try to acquire multiple locks atomically
-- KEYS: lock keys
-- ARGV[1..N]: unique lock values for each key
-- ARGV[last]: ttl in milliseconds

local ttl_ms = tonumber(ARGV[#ARGV])

for i=1,#KEYS do
    -- If any key already exists, fail immediately (no partial lock)
    if redis.call('exists', KEYS[i]) == 1 then
        return 0
    end

    -- Set lock with TTL (PX = milliseconds)
    redis.call('set', KEYS[i], ARGV[i], 'PX', ttl_ms)
end

-- All locks acquired successfully
return 1
"""

# Lua script: release lock (only if owned)
_RELEASE_LUA = """
-- Release locks only if value matches (ownership check)

for i=1,#KEYS do
  if redis.call('get', KEYS[i]) == ARGV[i] then
    redis.call('del', KEYS[i])
  end
end

return 1
"""


class AsyncRedisAtomicMultiLock:
    """
    Redis-based distributed multi-key lock with atomic guarantee.

    This implementation ensures:
        - Atomic acquisition of multiple keys (all-or-nothing)
        - Ownership-safe release (value comparison)
        - Optional blocking retry mechanism
        - Both sync and async support

    Key Features:
        - Prevents partial lock acquisition across multiple keys
        - Safe in high concurrency scenarios
        - Uses Lua scripts to ensure atomicity
        - Supports TTL-based auto-expiry to prevent deadlocks

    Note:
        For Redis Cluster environments, consider using Redlock-based solutions
        (e.g., aioredlock) for stronger guarantees.
    """

    def __init__(
            self,
            *keys: str,
            redis_xsync,
            redis_db,
            ttl_ms: int = 5000,
            blocking: bool = False,
            blocking_timeout: int = 5,
            sleep: float = 0.3
    ):
        """
        Initialize distributed multi-key lock.

        Args:
            *keys (str): Redis keys to lock. All keys must be acquired atomically.
            redis_xsync: Redis client factory (supports sync/async context).
            redis_db (int): Redis database index.
            ttl_ms (int): Lock expiration time in milliseconds.
            blocking (bool): Whether to wait until lock is acquired.
            blocking_timeout (int): Max wait time (seconds) if blocking=True.
            sleep (float): Retry interval (seconds) between attempts.
        """
        self.redis_xsync = redis_xsync
        self.redis_db = redis_db
        self.keys = list(keys)

        # Lock expiration time
        self.ttl_ms = int(ttl_ms)

        # Unique token per key (used for ownership validation)
        self.container = list(map(lambda _: uuid.uuid4().hex, keys))

        # Lock state flag
        self.acquired = False

        # Blocking configuration
        self.blocking = blocking
        self.blocking_timeout = blocking_timeout
        self.sleep = sleep

    # <editor-fold desc="Distributed lock: async implementation">

    async def _async_with_client(self, script: str, keys, *args):
        """
        Execute Lua script asynchronously.

        Args:
            script (str): Lua script content.
            keys (list[str]): Redis keys used in script.
            *args: Arguments passed to Lua script.

        Returns:
            bool: True if script returns success (1), False otherwise.
        """
        async with self.redis_xsync(db=self.redis_db) as redis:
            return (await redis.eval(script, len(keys), *keys, *args)) == 1

    async def async_acquire(self) -> bool:
        """
        Attempt to acquire the lock asynchronously.

        Behavior:
            - Non-blocking: try once
            - Blocking: retry until success or timeout

        Returns:
            bool: True if lock acquired, False otherwise.
        """
        argv = [*self.container, str(self.ttl_ms)]

        async def try_once():
            return await self._async_with_client(_ACQUIRE_LUA, self.keys, *argv)

        if not self.blocking:
            self.acquired = await try_once()
            return self.acquired

        end_time = asyncio.get_event_loop().time() + self.blocking_timeout

        while True:
            if await try_once():
                self.acquired = True
                return True

            if asyncio.get_event_loop().time() > end_time:
                return False

            await asyncio.sleep(self.sleep)

    async def async_release(self) -> None:
        """
        Release lock asynchronously.

        Notes:
            - Only releases keys owned by this instance
            - Safe against accidental unlock by others
        """
        try:
            await self._async_with_client(_RELEASE_LUA, self.keys, *self.container)
        finally:
            self.acquired = False

    async def __aenter__(self):
        """
        Async context manager entry.

        Raises:
            TimeoutError: If lock acquisition fails within timeout.

        Returns:
            AsyncRedisAtomicMultiLock: self
        """
        ok = await self.async_acquire()
        if not ok:
            raise TimeoutError("Failed to acquire lock within timeout")
        return self

    async def __aexit__(self, exc_type, exc, tb):
        """Async context manager exit (always releases lock)."""
        await self.async_release()

    # </editor-fold>

    # <editor-fold desc="Distributed lock: sync implementation">

    def _sync_with_client(self, script: str, keys, *args) -> bool:
        """
        Execute Lua script synchronously.

        Args:
            script (str): Lua script content.
            keys (list[str]): Redis keys.
            *args: Script arguments.

        Returns:
            bool: True if success, False otherwise.
        """
        with self.redis_xsync(db=self.redis_db) as redis:
            return int(redis.eval(script, len(keys), *keys, *args)) == 1

    def sync_acquire(self) -> bool:
        """
        Attempt to acquire lock synchronously.

        Behavior:
            - Non-blocking: single attempt
            - Blocking: retry until success or timeout

        Returns:
            bool: True if lock acquired, False otherwise.
        """
        argv = [*self.container, str(self.ttl_ms)]

        def try_once():
            return self._sync_with_client(_ACQUIRE_LUA, self.keys, *argv)

        if not self.blocking:
            self.acquired = try_once()
            return self.acquired

        end_time = time.time() + self.blocking_timeout

        while True:
            if try_once():
                self.acquired = True
                return True

            if time.time() > end_time:
                return False

            time.sleep(self.sleep)

    def sync_release(self) -> None:
        """
        Release lock synchronously.

        Notes:
            - Only releases keys owned by this instance
        """
        try:
            self._sync_with_client(_RELEASE_LUA, self.keys, *self.container)
        finally:
            self.acquired = False

    def __enter__(self):
        """
        Sync context manager entry.

        Raises:
            TimeoutError: If lock acquisition fails.

        Returns:
            AsyncRedisAtomicMultiLock: self
        """
        ok = self.sync_acquire()
        if not ok:
            raise TimeoutError(
                f"Failed to acquire lock on keys {self.keys} in {self.blocking_timeout}s"
            )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Sync context manager exit (always releases lock)."""
        self.sync_release()

    # </editor-fold>


__all__ = ["AsyncRedisAtomicMultiLock"]
