# -*- coding: utf-8 -*-
"""
@File    : __init__.py
@Author  : Jay
@Date    : 2026/3/19 18:01
@Desc    : Utilities to detect synchronous vs asynchronous call context
         and to decorate async functions to fallback to sync implementations.
"""
import asyncio
import functools
import inspect
import random
import sys
import time
from contextlib import AbstractAsyncContextManager
from functools import partial
from functools import wraps
from typing import Callable, Any

# Flags from code objects that indicate coroutine behavior
_CO_FROM_COROUTINE = (
        inspect.CO_COROUTINE
        | inspect.CO_ITERABLE_COROUTINE
        | inspect.CO_ASYNC_GENERATOR
)


def is_coroutine_context(level: int = 2) -> bool:
    """Determine if the current call context is asynchronous (coroutine).

    Args:
        level (int): Stack level to inspect (default 2). Increase if called from wrapper functions.

    Returns:
        bool: True if the current frame is part of a coroutine context, False if synchronous.
    """
    frame = sys._getframe(level)
    f_code = frame.f_code

    # Check if the code object has coroutine flags
    if f_code.co_flags & _CO_FROM_COROUTINE:
        return True

    # Handle nested "<...>" function wrappers (like decorators)
    if f_code.co_flags & inspect.CO_NESTED and f_code.co_name[0] == '<':
        return is_coroutine_context(level + 2)

    return False


def awaitable(async_func: Callable) -> Callable:
    """Decorator for async functions to use a synchronous fallback when called from sync context.

    Usage:
        def foo_sync(x, y): ...

        @awaitable(foo_sync)
        async def foo_async(x, y): ...

    Args:
        async_func (Callable): Synchronous implementation of the async function.

    Returns:
        Callable: Decorated async function that uses `sync_func` if called synchronously.
    """

    def decorator(sync_func: Callable) -> Callable:
        # Signature check to ensure sync/async match
        sig_sync = inspect.signature(sync_func)
        sig_async = inspect.signature(async_func)
        if sig_sync != sig_async:
            raise TypeError(
                f"{sync_func.__name__} and async {async_func.__name__} signatures differ:\n"
                f"  sync: {sig_sync}\n"
                f"  async: {sig_async}"
            )

        @wraps(async_func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # If currently inside a coroutine, run async function
            if is_coroutine_context():
                return async_func(*args, **kwargs)

            # Otherwise, run synchronous version
            result = sync_func(*args, **kwargs)
            if inspect.iscoroutine(result):
                raise RuntimeError(
                    f"Synchronous function {sync_func.__name__} returned a coroutine object. "
                    f"Ensure it is a true synchronous implementation."
                )
            return result

        # Attach references for introspection
        wrapper._sync_func = sync_func
        wrapper._async_func = async_func
        wrapper._awaitable = True
        return wrapper

    return decorator


class AnySyncContextManager(AbstractAsyncContextManager):
    """
    A context manager that supports both synchronous and asynchronous usage.

    Behavior:
        - Synchronous (`with`) usage calls the provided synchronous function.
          If the sync function is a generator, it returns the first value using `next()`.
          Otherwise, it returns the function's return value directly.
        - Asynchronous (`async with`) usage calls the provided async generator function
          and returns the first yielded value.

    Use case:
        This is useful for wrapping operations that have both synchronous and asynchronous
        implementations, allowing a single interface for both `with` and `async with`.
    """

    def __init__(self, sync_func: Callable, async_func: Callable, *args, **kwargs):
        """
        Initialize the context manager with synchronous and asynchronous functions.

        Args:
            sync_func: The synchronous function to call in synchronous context.
            async_func: The asynchronous generator function to call in async context.
            *args, **kwargs: Arguments to pass to both functions.
        """
        self._sync_func = sync_func
        self._async_func = async_func
        self._args = args
        self._kwargs = kwargs
        self._gen = None  # Stores the async generator instance
        self._sync_result = None  # Stores the sync generator or return value

    def __call__(self, *args, **kwargs):
        """Update arguments and reset the generator, return self."""
        self._args = args
        self._kwargs = kwargs
        self._gen = None
        return self

    def __get__(self, instance, owner):
        """
        Support for instance methods via descriptor protocol.
        Returns a partial bound to the instance if used as a class method.
        """
        if instance is None:
            return self
        return partial(
            self.__class__,
            self._sync_func.__get__(instance, owner),
            self._async_func.__get__(instance, owner)
        )

    # ----------------- Synchronous Context -----------------
    def __enter__(self):
        """
        Enter synchronous context.

        Returns:
            The first value from the synchronous generator if it's a generator,
            otherwise returns the synchronous function's return value.
        """
        self._sync_result = self._sync_func(*self._args, **self._kwargs)
        try:
            return next(self._sync_result)  # If generator, return first yielded value
        except TypeError:
            # If not a generator, return the value directly
            return self._sync_result

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit synchronous context. No cleanup needed for simple sync functions."""
        pass

    # ----------------- Asynchronous Context -----------------
    async def __aenter__(self):
        """
        Enter asynchronous context.

        Returns:
            The first yielded value from the asynchronous generator.
        """
        if self._gen is None:
            self._gen = self._async_func(*self._args, **self._kwargs)
        try:
            return await self._gen.__anext__()
        except StopAsyncIteration:
            return None

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """
        Exit asynchronous context.

        Attempts to finalize the async generator if it exists,
        ignoring StopAsyncIteration.
        """
        if self._gen is None:
            return
        try:
            await self._gen.__anext__()
        except StopAsyncIteration:
            pass


def contextmanager(async_func: Callable):
    """
    Decorator that binds a synchronous function with an asynchronous generator function,
    producing a unified context manager usable in both sync and async contexts.

    The decorated function returns an `AnySyncContextManager`, which transparently
    supports both `with` and `async with` usage patterns.

    Usage:
        @contextmanager(sync_func)
        async def async_func(...):
            ...
            yield value

    Args:
        async_func (Callable):
            An asynchronous generator function that defines the async context behavior.

    Returns:
        Callable:
            A wrapper that takes a synchronous function and returns a context manager
            compatible with both synchronous and asynchronous execution.
    """

    def wrapper(sync_func: Callable):
        return lambda *args, **kwargs: AnySyncContextManager(sync_func, async_func, *args, **kwargs)

    return wrapper


def wait_for_value(_func=None, *, timeout_ms=None):
    """
    Decorator that waits until the decorated function (sync or async)
    returns a non-empty/non-None value.

    Can be used with or without parentheses:
        @wait_for_value
        @wait_for_value(timeout=5)

    Args:
        _func:
        timeout_ms (float, optional): Timeout in seconds for synchronous functions.
            If None: wait indefinitely.
    """

    def decorator(func):
        is_async = inspect.iscoroutinefunction(func)

        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            start_time = time.time() * 1000
            while True:
                t = time.time() * 1000
                if timeout_ms is not None and (t - start_time > timeout_ms): raise TimeoutError(f"Waiting for containers timed out after {timeout_ms} seconds")
                result = func(*args, **kwargs)
                if result: return result
                time.sleep(0.3 + random.random() * 0.1)

        @functools.wraps(func)
        async def async_wrapper(*args, **kwargs):
            while True:
                result = await func(*args, **kwargs)
                if result: return result
                await asyncio.sleep(0.3 + random.random() * 0.1)

        return async_wrapper if is_async else sync_wrapper

    # 写法 @wait_for_value(timeout_ms=5)
    if _func is None: return decorator

    # 写法 @wait_for_value
    return decorator(_func)


__all__ = ["awaitable", "contextmanager", "is_coroutine_context", "wait_for_value"]
if __name__ == '__main__':
    # Demonstration of `awaitable` decorator usage
    class Limited:
        def _ask_available_container_sync(self, quantity):
            """Synchronous fallback implementation."""
            return "sync-"

        @awaitable(_ask_available_container_sync)
        async def ask_available_container(self, quantity):
            """Async implementation."""
            return "async+"


    lt = Limited()

    # Synchronous call
    res_sync = lt.ask_available_container(1)
    print("Sync result:", res_sync)


    # Asynchronous call

    async def main():
        res_async = await lt.ask_available_container(2)
        print("Async result:", res_async)


    asyncio.run(main())
