# -*- coding: utf-8 -*-
"""
@File    : rate_limited_pool.py
@Author  : Jay
@Date    : 2026/3/18 17:46
@Desc    : Data collection - general identity token rate limiting
"""
import asyncio
import json
import random
from typing import Union

from redis.commands.search.field import TextField, NumericField
from redis.commands.search.index_definition import IndexDefinition, IndexType

from .awaitable import awaitable, contextmanager, wait_for_value
from .rtypes import LimitedModel


class RedisearchNotAvailableError(Exception):
    """Raised when RediSearch module is not installed or Redis version is too low."""
    pass


class Limited(object):
    """Rate-limited identity container manager using Redis + RediSearch.

    This class provides synchronous and asynchronous methods for managing
    identity containers with rate limiting enforced via Redis and RediSearch.
    """
    _redis_key = "crawler:identity:flow_limit"

    def __init__(self, redis_xsync, redis_key=None):
        """Initialize the Limited container manager.

        This constructor sets up the Redis client factory and optionally
        allows a custom Redis key prefix for the rate-limited containers.
        It also ensures that RediSearch is available and ready.

        Args:
            redis_xsync: Redis client factory supporting synchronous and asynchronous context usage.
            redis_key (str, optional): Redis key prefix for rate-limited containers. Defaults to `_redis_key`.
        """
        self._redis_xsync = redis_xsync
        self._redis_key = redis_key or self._redis_key

        # Verify Redis supports RediSearch module
        self._is_redisearch_supported()

    def _is_redisearch_supported(self) -> bool:
        """Check if RediSearch module is installed and create the index if needed.

        This method queries the Redis modules list to detect if RediSearch is available.
        If the module exists, it will call `_create_index` to ensure the container index is created.

        Raises:
            RedisearchNotAvailableError: If RediSearch is missing or Redis version is too low.

        Returns:
            bool: True if RediSearch is supported and index is ready.
        """
        with self._redis_xsync(db=0) as redis:
            modules = redis.execute_command("MODULE", "LIST")
            for module in modules:
                for name in module:
                    if isinstance(name, bytes):
                        name = name.decode()
                    if str(name).endswith("redisearch.so"):
                        self._create_index(redis=redis)  # Create index if module found
                        return True
            raise RedisearchNotAvailableError(
                "RediSearch is not installed or your Redis version is too low to support it. "
                "Starting with Redis 8, RediSearch (Redis Query Engine) is integrated and does not need a separate module; "
                "for older versions you must load the module manually. See https://redis.io/docs/latest/develop/ai/search-and-query/ for details."
            )

    def _create_index(self, redis):
        """Create the RediSearch index for container rate limiting.

        This method defines the schema for the container hash data
        and ensures the index exists before any operations. It uses
        an atomic lock to avoid race conditions during index creation.

        Args:
            redis: Redis connection object used to execute commands.
        """
        ft = redis.ft(self._redis_key)
        schema = [
            TextField(name="id", sortable=True),
            NumericField(name="ct", sortable=True),
            NumericField(name="ttl_ms", sortable=True),
            NumericField(name="next_time_available", sortable=True),
            NumericField(name="interval_ms", sortable=True),
            NumericField(name="usage_count", sortable=True),
            NumericField(name="locked_until", sortable=True),
            TextField(name="containers")
        ]
        definition = IndexDefinition(
            prefix=[f"{self._redis_key}:"],
            index_type=IndexType.HASH
        )

        # Use an atomic lock to safely create the index without race conditions
        with self._redis_xsync.AsyncRedisAtomicMultiLock(
                "_temporary_index_redis_search",
                ttl_ms=60 * 1000,
                blocking=True,
                blocking_timeout=60 * 1000,
                sleep=0.3 + random.random() * 0.1,
        ):
            existing_indexes = [
                idx.decode() if isinstance(idx, bytes) else idx
                for idx in redis.execute_command("FT._LIST")
            ]
            if self._redis_key in existing_indexes:
                return

            # Create index if it does not exist
            ft.create_index(schema, definition=definition)

    # <editor-fold desc="Get N available containers">
    _lua_ask_script = """
    -- Lua script to atomically fetch N available containers from Redis
    local t = redis.call("TIME")
    local now = t[1] * 1000 + math.floor(t[2] / 1000)

    local index = ARGV[1]        -- Redisearch index name
    local quantity = tonumber(ARGV[2])
    local result = {}

    -- Search for containers that are available or have no interval
    local query = string.format(
        "((@next_time_available:[-inf %d] @locked_until:[0 %d]) | @interval_ms:[0 0])",
        now, now
    )
    local search_res = redis.call(
        "FT.SEARCH", index, query, "NOCONTENT",
        "SORTBY", "usage_count", "ASC",
        "LIMIT", 0, quantity
    )
    if #search_res <= 1 then return nil end

    for i = 2, #search_res do
        local key = search_res[i]
        local fields = redis.call("HMGET", key, "id", "containers", "interval_ms")
        local id_val = fields[1]
        local containers = fields[2]
        local interval_ms = tonumber(fields[3] or 0)

        -- Increment usage_count atomically
        local new_usage_count = redis.call("HINCRBY", key, "usage_count", 1)

        -- Update next_time_available if interval_ms is positive
        if interval_ms > 0 then
            redis.call("HSET", key, "next_time_available", now + interval_ms)
        end

        -- Add container info to result (JSON encoded)
        table.insert(result, {
            id = id_val,
            containers = containers,
            usage_count = new_usage_count
        })
    end

    return cjson.encode(result)
    """

    async def _ask_available_containers_async(self, quantity):
        """Retrieve a specific number of available containers from Redis.

        Executes the Lua script atomically. Increments usage counts and updates
        next availability if interval_ms > 0.

        Args:
            quantity (int): Number of containers to fetch.

        Returns:
            str or None: JSON-encoded container data, or None if no containers are available.
        """
        async with self._redis_xsync(db=0) as redis:
            encoded_result = await redis.eval(self._lua_ask_script, 0, self._redis_key, quantity)
            return encoded_result

    @awaitable(_ask_available_containers_async)
    def ask_available_containers(self, quantity):
        """Fetch a specific number of available containers asynchronously.

        Wraps the Lua script execution for convenience.

        Args:
            quantity (int): Number of containers to fetch.

        Returns:
            str or None: JSON-encoded container data, or None if no containers are available.
        """
        with self._redis_xsync(db=0) as redis:
            encoded_result = redis.eval(self._lua_ask_script, 0, self._redis_key, quantity)
            return encoded_result

    async def _ask_available_container_async(self):
        """Retrieve a single available container from Redis.

        Returns:
            str or None: JSON-encoded container data, or None if unavailable.
        """
        return await self._ask_available_containers_async(quantity=1)

    @awaitable(_ask_available_container_async)
    def ask_available_container(self):
        """Fetch a single available container asynchronously.

        Returns:
            str or None: JSON-encoded container data, or None if unavailable.
        """
        return self.ask_available_containers(quantity=1)

    # </editor-fold>

    # <editor-fold desc="Wait until containers are available">
    async def _wait_ask_available_containers(self, quantity=1):
        """Wait asynchronously until the requested number of containers are available.

        Repeatedly queries Redis until the required containers are found or the operation is cancelled.

        Args:
            quantity (int, optional): Number of containers to wait for. Defaults to 1.

        Returns:
            str: JSON-encoded container data once available.
        """

        @wait_for_value
        async def process(r, q):
            containers = await r.eval(self._lua_ask_script, 0, self._redis_key, q)
            if containers:
                return containers
            return None

        async with self._redis_xsync(db=0) as redis:
            return await process(r=redis, q=quantity)

    async def _wait_ask_available_containers_async(self, quantity=1, timeout=60_000):
        """Wait synchronously until the requested number of containers are available.

        Blocks until the containers are found or the specified timeout is reached.

        Args:
            quantity (int, optional): Number of containers to wait for. Defaults to 1.
            timeout (int, optional): Maximum wait time in milliseconds. Defaults to 60,000.

        Returns:
            str: JSON-encoded container data once available.
        """

        return await asyncio.wait_for(
            self._wait_ask_available_containers(quantity),
            timeout=timeout / 1000
        )

    @awaitable(_wait_ask_available_containers_async)
    def wait_ask_available_containers(self, quantity=1, timeout=60_000):
        """Asynchronously wait for a number of containers to become available.

        Wraps the async wait with a timeout and returns JSON-encoded container data.

        Args:
            quantity (int, optional): Number of containers to retrieve. Defaults to 1.
            timeout (int, optional): Maximum wait time in milliseconds. Defaults to 60,000.

        Returns:
            str or None: JSON-encoded container data, or None if the timeout expires.
        """

        @wait_for_value(timeout_ms=timeout)
        def process(r, q):
            containers = r.eval(self._lua_ask_script, 0, self._redis_key, q)
            if containers: return containers
            return None

        with self._redis_xsync(db=0) as redis:
            return process(r=redis, q=quantity)

    async def _wait_ask_available_container_async(self, timeout=60_000):
        """Wait synchronously for a single available container.

        Args:
            timeout (int, optional): Maximum wait time in milliseconds. Defaults to 60,000.

        Returns:
            str: JSON-encoded single container data once available.
        """
        return await asyncio.wait_for(
            self._wait_ask_available_containers(quantity=1),
            timeout=timeout / 1000
        )

    @awaitable(_wait_ask_available_container_async)
    def wait_ask_available_container(self, timeout=60_000):
        """Asynchronously wait for a single container to become available.

        Args:
            timeout (int, optional): Maximum wait time in milliseconds. Defaults to 60,000.

        Returns:
            str: JSON-encoded single container data once available.
        """
        return self.wait_ask_available_containers(quantity=1, timeout=timeout)

    # </editor-fold>

    # <editor-fold desc="Set available containers">
    _lua_set_script = """
    -- Lua script to store multiple container configurations in Redis
    local prefix = ARGV[1]
    local json_list = cjson.decode(ARGV[2])

    for i, data in ipairs(json_list) do
        local key = prefix .. data["id"]
        local ttl_ms = tonumber(data["ttl_ms"] or 0)

        -- Prepare all fields except ttl_ms for a single HSET call
        local hm = {}
        for field, value in pairs(data) do
            if field ~= "ttl_ms" then
                table.insert(hm, field)
                table.insert(hm, tostring(value))
            end
        end

        -- Write all fields in one HSET command
        if #hm > 0 then
            redis.call("HSET", key, unpack(hm))
        end

        -- Set expiration if ttl_ms > 0
        if ttl_ms > 0 then
            redis.call("PEXPIRE", key, ttl_ms)
        end
    end

    return 1  -- Return 1 on success
    """

    async def _set_available_containers_async(self, *containers: LimitedModel):
        """Store one or more container configurations in Redis asynchronously.

        Converts each LimitedModel into a JSON dictionary and writes all fields
        to Redis hashes. TTL is applied if specified for each container.

        Args:
            *containers (LimitedModel): One or more container configurations to store.

        Returns:
            bool: True if the operation succeeded, False otherwise.
        """
        async with self._redis_xsync(db=0) as redis:
            new_containers = json.dumps([token.model_dump() for token in containers])
            return bool(await redis.eval(self._lua_set_script, 0, f"{self._redis_key}:", new_containers))

    @awaitable(_set_available_containers_async)
    def set_available_containers(self, *containers: LimitedModel):
        """Asynchronously store multiple container configurations in Redis.

        Writes all fields of each container to Redis hashes.
        Applies TTL if provided for each container.

        Args:
            *containers (LimitedModel): One or more container configurations to store.

        Returns:
            bool: True if the operation succeeded, False otherwise.
        """
        with self._redis_xsync(db=0) as redis:
            new_containers = json.dumps([token.model_dump() for token in containers])
            return bool(redis.eval(self._lua_set_script, 0, f"{self._redis_key}:", new_containers))

    # </editor-fold>

    # <editor-fold desc="Randomly acquire a container, ignoring rate limit">
    _lua_random_container = """
    local index = ARGV[1]
    local quantity = tonumber(ARGV[2]) or 1

    -- Perform RediSearch query to get all unlocked containers
    local query = "@locked_until:[0 +inf]"
    local search_res = redis.call(
        "FT.SEARCH", index,
        query,
        "NOCONTENT",
        "SORTBY", "usage_count", "ASC",
        "LIMIT", 0, quantity
    )
    if #search_res <= 1 then return nil end

    -- Build candidate list (skip the first element which is the total count)
    local candidates = {}
    for i = 2, #search_res do
        table.insert(candidates, search_res[i])
    end

    local result = {}
    for i = 2, #search_res do
        local key = search_res[i]

        local fields = redis.call("HMGET", key, "id", "containers", "interval_ms")
        local id_val = fields[1]
        local containers = fields[2]
        local interval_ms = tonumber(fields[3] or 0)

        -- Increment usage_count
        local new_usage_count = redis.call("HINCRBY", key, "usage_count", 1)
        table.insert(result, {
            id = id_val,
            containers = containers,
            interval_ms = interval_ms,
            usage_count = new_usage_count
        })
    end

    -- Return JSON-encoded list of containers
    return cjson.encode(result)
    """

    async def _acquire_random_containers_async(self, quantity=1):
        """Acquire a specified number of random containers asynchronously, ignoring rate limits.

        Args:
            quantity (int): Number of containers to retrieve.

        Returns:
            str: JSON-encoded list of container data.
        """
        async with self._redis_xsync(db=0) as redis:
            return await redis.eval(self._lua_random_container, 0, self._redis_key, quantity)

    @awaitable(_acquire_random_containers_async)
    def acquire_random_containers(self, quantity=1):
        """Asynchronously acquire a specified number of random containers, ignoring rate limits.

        Args:
            quantity (int): Number of containers to retrieve.

        Returns:
            str: JSON-encoded list of container data.
        """
        with self._redis_xsync(db=0) as redis:
            return redis.eval(self._lua_random_container, 0, self._redis_key, quantity)

    async def _acquire_random_container_async(self):
        """Acquire a single random container asynchronously, ignoring rate limits.

        Returns:
            str: JSON-encoded single container data.
        """
        return await self._acquire_random_containers_async(quantity=1)

    @awaitable(_acquire_random_container_async)
    def acquire_random_container(self):
        """Asynchronously acquire a single random container, ignoring rate limits.

        Returns:
            str: JSON-encoded single container data.
        """
        return self.acquire_random_containers(quantity=1)

    # </editor-fold>

    # <editor-fold desc="Asynchronous helper to acquire a single random container">
    async def _wait_acquire_random_containers(self, quantity=1):
        """Wait asynchronously until the specified number of random containers are available.

        Continuously queries Redis until containers are found.

        Args:
            quantity (int): Number of containers to wait for.

        Returns:
            str: JSON-encoded container data once available.
        """

        @wait_for_value
        async def process(r, q):
            containers = await r.eval(self._lua_random_container, 0, self._redis_key, q)
            if containers: return containers
            return None

        async with self._redis_xsync(db=0) as redis:
            return await process(r=redis, q=quantity)

    async def _wait_acquire_random_containers_async(self, quantity=1, timeout=60_000):
        """Wait synchronously for N random containers with a timeout.

        Blocks until containers are available or timeout is reached.

        Args:
            quantity (int): Number of containers to wait for.
            timeout (int): Maximum waiting time in milliseconds.

        Returns:
            str: JSON-encoded container data once available.
        """
        return await asyncio.wait_for(
            self._wait_acquire_random_containers(quantity),
            timeout=timeout / 1000.0
        )

    @awaitable(_wait_acquire_random_containers_async)
    def wait_acquire_random_containers(self, quantity=1, timeout=60_000):
        """Asynchronously wait for N random containers to become available.

        Wraps the async wait with a timeout and returns JSON-encoded container data.

        Args:
            quantity (int): Number of containers to retrieve.
            timeout (int): Maximum waiting time in milliseconds.

        Returns:
            str: JSON-encoded container data once available.
        """

        @wait_for_value(timeout_ms=timeout)
        def process(r, q):
            containers = r.eval(self._lua_random_container, 0, self._redis_key, q)
            if containers:
                return containers
            return None

        with self._redis_xsync(db=0) as redis:
            return process(r=redis, q=quantity)

    async def _wait_acquire_random_container_async(self, timeout=60_000):
        """Wait synchronously for a single random container to become available.

        Args:
            timeout (int): Maximum waiting time in milliseconds.

        Returns:
            str: JSON-encoded single container data.
        """
        return await asyncio.wait_for(
            self._wait_acquire_random_containers(quantity=1),
            timeout=timeout / 1000.0
        )

    @awaitable(_wait_acquire_random_container_async)
    def wait_acquire_random_container(self, timeout=60_000):
        """Asynchronously wait for a single random container to become available.

        Args:
            timeout (int): Maximum waiting time in milliseconds.

        Returns:
            str: JSON-encoded single container data.
        """
        return self.wait_acquire_random_containers(quantity=1, timeout=timeout)

    # </editor-fold>

    # <editor-fold desc="Rate limiting & container acquisition">
    _lua_acquire_script = """
    -- Atomic container acquisition script with rate limiting
    local t = redis.call("TIME")
    local now_ms = t[1] * 1000 + math.floor(t[2] / 1000)

    local index = ARGV[1]
    local lock_ms = tonumber(ARGV[2]) or 20000  -- default 20s lock
    local result = {}

    -- Query available containers (next_time_available <= now and locked_until <= now)
    local query = string.format("(@next_time_available:[-inf %d] @locked_until:[0 %d])", now_ms, now_ms)
    local search_res = redis.call("FT.SEARCH", index, query, "NOCONTENT", "SORTBY", "usage_count", "ASC", "LIMIT", 0, 1)

    if #search_res <= 1 then
        return nil
    end
    local key = search_res[2]

    -- Only set lock if it's not permanently disabled
    local locked_until = tonumber(redis.call("HGET", key, "locked_until") or 0)
    if locked_until ~= -1 then
        redis.call("HSET", key, "locked_until", now_ms + lock_ms)
    end

    local new_usage_count = redis.call("HINCRBY", key, "usage_count", 1)
    local fields = redis.call("HMGET", key, "id", "containers", "interval_ms")
    
    local container = {
        id = fields[1],
        containers = fields[2],
        interval_ms = tonumber(fields[3] or 0),
        usage_count = new_usage_count,
        locked_until = now_ms + lock_ms
    }
    return cjson.encode(container)
    """

    _lua_acquire_release_script = """
    -- Release a single container lock and update next available time
    -- ARGV[1] = prefix for Redis keys
    -- ARGV[2] = JSON of the container
    -- ARGV[3] = locked_until at acquire time (用于精准解锁)
    
    local prefix = ARGV[1]
    local container = cjson.decode(ARGV[2])
    local expected_locked_until = tonumber(container["locked_until"])
    
    -- Get current time in milliseconds
    local t = redis.call("TIME")
    
    local key = prefix .. container["id"]
    
    -- Fetch current locked_until and interval_ms
    local values = redis.call("HMGET", key, "interval_ms", "locked_until")
    local interval_ms = tonumber(values[1]) or 0
    local cur_locked_until = tonumber(values[2]) or 0
    
    if cur_locked_until == -1 then
        return 1
    end
    
    -- Only release if locked_until matches the one we acquired
    if cur_locked_until == expected_locked_until then
        local now_ms = t[1] * 1000 + math.floor(t[2] / 1000)
        redis.call("HMSET", key,
            "locked_until", 0,
            "next_time_available", now_ms + interval_ms
        )
    end
    
    return 1
    """

    async def _acquire_available_container_async(
            self,
            timeout: Union[float, int] = 6_000,
            lock_release_ms: Union[float, int] = 6_000
    ):
        """Acquire a single container asynchronously with rate limiting.

        Blocks until a container is available or timeout is reached.
        Automatically releases the lock when exiting the context.

        Args:
            timeout (Union[float, int], optional): Maximum wait time in milliseconds. Defaults to 6000.
            lock_release_ms (Union[float, int], optional): Time before the container becomes available again. Defaults to 6000.

        Yields:
            dict: Acquired container data with 'id', 'containers', 'interval_ms', 'usage_count', and 'locked_until'.
        """

        @wait_for_value
        async def acquire(r):
            rs = await r.eval(self._lua_acquire_script, 0, self._redis_key, str(lock_release_ms))
            if rs: return rs
            return None

        async with self._redis_xsync(db=0) as redis:
            encoded_result = await asyncio.wait_for(acquire(redis), timeout=timeout / 1000)
            containers = json.loads(encoded_result)
            try:
                yield containers
            finally:
                containers and await redis.eval(
                    self._lua_acquire_release_script,
                    0,
                    f"{self._redis_key}:",
                    encoded_result
                )

    @contextmanager(_acquire_available_container_async)
    def acquire_available_container(
            self,
            timeout: Union[float, int] = 6_000,
            lock_release_ms: Union[float, int] = 6_000
    ):
        """Acquire a single container asynchronously with rate limiting using a context manager.

        Waits until a container is available or timeout expires.
        Automatically releases the lock when exiting the context.

        Args:
            timeout (Union[float, int], optional): Maximum wait time in milliseconds. Defaults to 6000.
            lock_release_ms (Union[float, int], optional): Time before the container becomes available again. Defaults to 6000.

        Yields:
            dict: Acquired container data with 'id', 'containers', 'interval_ms', 'usage_count', and 'locked_until'.
        """

        @wait_for_value(timeout_ms=timeout)
        def acquire(r):
            rs = r.eval(self._lua_acquire_script, 0, self._redis_key, str(lock_release_ms))
            if rs: return rs
            return None

        with self._redis_xsync(db=0) as redis:
            encoded_result = acquire(r=redis)
            containers = json.loads(encoded_result)
            try:
                yield containers
            finally:
                containers and redis.eval(
                    self._lua_acquire_release_script,
                    0,
                    f"{self._redis_key}:",
                    encoded_result
                )

    # </editor-fold>

    # <editor-fold desc="Disable the containers">
    async def _disable_containers_async(self, *ids):
        """Disable specified containers asynchronously by setting `locked_until` to -1.

        Marks containers as permanently disabled. Uses a Redis pipeline to batch
        multiple HSET commands for better performance.

        Args:
            *ids: One or more container IDs to disable.
        """
        async with self._redis_xsync(db=0) as redis:
            async with redis.pipeline() as pipe:
                for _id in ids:
                    await pipe.hset(f"{self._redis_key}:{_id}", "locked_until", -1)
                await pipe.execute()

    @awaitable(_disable_containers_async)
    def disable_containers(self, *ids):
        """Asynchronously disable specified containers by setting `locked_until` to -1.

        Marks containers as permanently disabled. Uses a Redis pipeline to batch
        multiple HSET commands for better performance.

        Args:
            *ids: One or more container IDs to disable.
        """
        with self._redis_xsync(db=0) as redis:
            with redis.pipeline() as pipe:
                for _id in ids:
                    pipe.hset(f"{self._redis_key}:{_id}", "locked_until", -1)
                pipe.execute()

    # </editor-fold>

    # <editor-fold desc="Context Manager Support">
    async def __aenter__(self):
        """Enter the asynchronous context."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Exit the asynchronous context."""
        pass

    def __enter__(self):
        """Enter the synchronous context."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Exit the synchronous context."""
        pass

    def close(self):
        """Release any internal resources (currently a no-op)."""
        pass
    # </editor-fold>


__all__ = ["Limited"]
