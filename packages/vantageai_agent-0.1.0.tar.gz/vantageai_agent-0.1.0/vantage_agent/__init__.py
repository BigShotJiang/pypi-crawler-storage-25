"""Vantage Agent — AI coding agent with per-tool permissions and cost tracking."""
__version__ = "0.1.0"
