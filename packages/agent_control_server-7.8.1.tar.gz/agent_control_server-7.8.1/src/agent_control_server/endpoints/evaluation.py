"""Evaluation analysis endpoints."""

import json
from dataclasses import dataclass

from agent_control_engine.core import ControlEngine
from agent_control_models import (
    ControlDefinitionRuntime,
    ControlMatch,
    EvaluationRequest,
    EvaluationResponse,
)
from agent_control_models.errors import ErrorCode, ValidationErrorItem
from fastapi import APIRouter, Depends, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from ..auth_framework import Operation, Principal, require_operation
from ..db import get_async_db
from ..errors import APIValidationError, NotFoundError
from ..logging_utils import get_logger
from ..models import Agent
from ..services.controls import ControlService

router = APIRouter(prefix="/evaluation", tags=["evaluation"])

_logger = get_logger(__name__)

SAFE_EVALUATOR_ERROR = "Evaluation failed due to an internal evaluator error."
SAFE_EVALUATOR_TIMEOUT_ERROR = "Evaluation timed out before completion."
SAFE_INVALID_STEP_REGEX_ERROR = "Control configuration error: invalid step name regex."
SAFE_ENGINE_VALIDATION_MESSAGE = "Invalid evaluation request or control configuration."


@dataclass
class ControlAdapter:
    """Adapts API Control to Engine ControlWithIdentity protocol."""

    id: int
    name: str
    control: ControlDefinitionRuntime


def _sanitize_evaluator_error(error_message: str) -> str:
    """Convert evaluator runtime errors into safe client-facing text."""
    if "invalid step_name_regex" in error_message.lower():
        return SAFE_INVALID_STEP_REGEX_ERROR
    if "timeout" in error_message.lower():
        return SAFE_EVALUATOR_TIMEOUT_ERROR
    return SAFE_EVALUATOR_ERROR


def _sanitize_condition_trace(trace: object) -> object:
    """Recursively redact internal evaluator errors from condition traces."""
    if isinstance(trace, list):
        return [_sanitize_condition_trace(item) for item in trace]

    if not isinstance(trace, dict):
        return trace

    sanitized = {
        key: _sanitize_condition_trace(value)
        for key, value in trace.items()
    }

    raw_error = sanitized.get("error")
    if isinstance(raw_error, str) and raw_error:
        safe_error = _sanitize_evaluator_error(raw_error)
        sanitized["error"] = safe_error
        raw_message = sanitized.get("message")
        if raw_message is None or isinstance(raw_message, str):
            sanitized["message"] = safe_error

    return sanitized


def _sanitize_control_match(match: ControlMatch) -> ControlMatch:
    """Redact internal evaluator error strings from a control match."""
    if match.result.error is None:
        return match

    safe_error = _sanitize_evaluator_error(match.result.error)
    safe_message = safe_error
    metadata = dict(match.result.metadata or {})
    condition_trace = metadata.get("condition_trace")
    if condition_trace is not None:
        metadata["condition_trace"] = _sanitize_condition_trace(condition_trace)
    sanitized_result = match.result.model_copy(
        update={
            "error": safe_error,
            "message": safe_message,
            "metadata": metadata or None,
        }
    )
    return match.model_copy(update={"result": sanitized_result})


def _sanitize_evaluation_response(response: EvaluationResponse) -> EvaluationResponse:
    """Return a copy of the evaluation response with safe public error text."""
    return response.model_copy(
        update={
            "matches": (
                [_sanitize_control_match(match) for match in response.matches]
                if response.matches
                else None
            ),
            "errors": (
                [_sanitize_control_match(match) for match in response.errors]
                if response.errors
                else None
            ),
            "non_matches": (
                [_sanitize_control_match(match) for match in response.non_matches]
                if response.non_matches
                else None
            ),
        }
    )


async def _evaluation_context(request: Request) -> dict[str, object]:
    """Surface target identifiers to the runtime authorizer."""
    try:
        body = await request.json()
    except (json.JSONDecodeError, UnicodeDecodeError):
        _logger.debug("Unable to decode evaluation request body for auth context")
        return {}
    if not isinstance(body, dict):
        return {}
    target_type = body.get("target_type")
    target_id = body.get("target_id")
    if not isinstance(target_type, str) or not isinstance(target_id, str):
        return {}
    if not target_type or not target_id:
        return {}
    return {"target_type": target_type, "target_id": target_id}


@router.post(
    "",
    response_model=EvaluationResponse,
    summary="Analyze content safety",
    response_description="Safety analysis result",
)
async def evaluate(
    request: EvaluationRequest,
    db: AsyncSession = Depends(get_async_db),
    principal: Principal = Depends(
        require_operation(Operation.RUNTIME_USE, context_builder=_evaluation_context)
    ),
) -> EvaluationResponse:
    """Analyze content for safety and control violations.

    The effective control set is the de-duplicated union of the agent's
    direct controls, policy-derived controls, and (when ``target_type`` and
    ``target_id`` are both supplied) controls attached to that target via
    enabled bindings in the same namespace. The same merge applies on
    ``initAgent`` and ``GET /agents/{name}/controls`` so all three surfaces
    return the same set for the same inputs.

    This endpoint is intentionally evaluation-only. It returns the semantic
    ``EvaluationResponse`` and does not build or ingest observability events
    on the server; SDKs reconstruct and emit those events separately through
    the observability ingestion endpoint.
    """
    namespace_key = principal.namespace_key

    agent_result = await db.execute(
        select(Agent).where(
            Agent.name == request.agent_name,
            Agent.namespace_key == namespace_key,
        )
    )
    agent = agent_result.scalar_one_or_none()
    if agent is None:
        raise NotFoundError(
            error_code=ErrorCode.AGENT_NOT_FOUND,
            detail=f"Agent '{request.agent_name}' not found",
            resource="Agent",
            resource_id=request.agent_name,
            hint="Register the agent via initAgent before evaluating.",
        )

    runtime_controls = await ControlService(db).list_runtime_controls_for_agent(
        request.agent_name,
        namespace_key=namespace_key,
        target_type=request.target_type,
        target_id=request.target_id,
        allow_invalid_step_name_regex=True,
    )

    engine_controls = [ControlAdapter(c.id, c.name, c.control) for c in runtime_controls]

    engine = ControlEngine(engine_controls)
    try:
        raw_response = await engine.process(request)
    except ValueError:
        _logger.exception("Evaluation failed due to invalid configuration or input")
        raise APIValidationError(
            error_code=ErrorCode.EVALUATION_FAILED,
            detail="Evaluation failed due to invalid configuration or input",
            resource="Evaluation",
            hint="Check the evaluation request format and control configurations.",
            errors=[
                ValidationErrorItem(
                    resource="Evaluation",
                    field=None,
                    code="evaluation_error",
                    message=SAFE_ENGINE_VALIDATION_MESSAGE,
                )
            ],
        )

    return _sanitize_evaluation_response(raw_response)
