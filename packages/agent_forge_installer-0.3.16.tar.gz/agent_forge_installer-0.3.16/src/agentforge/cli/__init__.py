"""AgentForge CLI — main dispatcher."""

import argparse
import sys


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="agentforge",
        description="AgentForge — multi-agent Telegram bot framework",
    )
    sub = parser.add_subparsers(dest="command")

    # --- agentforge bot ---
    bot_parser = sub.add_parser("bot", help="Run the Telegram bot")
    bot_parser.add_argument("--config", help="Path to config.json")

    # --- agentforge api ---
    api_parser = sub.add_parser("api", help="Run the HTTP API server")
    api_parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    api_parser.add_argument("--port", type=int, help="Bind port (default: AGENTFORGE_API_PORT or 8080)")
    api_parser.add_argument("--config", help="Path to config.json")

    # --- agentforge agent ---
    agent_parser = sub.add_parser("agent", help="Manage agents")
    agent_sub = agent_parser.add_subparsers(dest="agent_command")

    # agent create
    create_p = agent_sub.add_parser("create", help="Create a new agent")
    create_p.add_argument("name", help="Agent name (lowercase, e.g. 'victor')")
    create_p.add_argument("--backend", default="claude", help="LLM backend (default: claude)")
    create_p.add_argument("--model", default="sonnet", help="LLM model (default: sonnet)")
    create_p.add_argument("--thread-id", type=int, help="Telegram thread ID for this agent")
    create_p.add_argument("--config", help="Path to config.json")

    # agent list
    list_p = agent_sub.add_parser("list", help="List configured agents")
    list_p.add_argument("--config", help="Path to config.json")

    # agent remove
    remove_p = agent_sub.add_parser("remove", help="Remove an agent")
    remove_p.add_argument("name", help="Agent name to remove")
    remove_p.add_argument("--config", help="Path to config.json")
    remove_p.add_argument("--keep-files", action="store_true",
                          help="Keep agent files on disk (only remove from config)")

    # agent link-vault
    link_vault_p = agent_sub.add_parser(
        "link-vault",
        help="Move agent .md files into vault/Agents/<name>/ and symlink back",
    )
    link_vault_p.add_argument(
        "agents", nargs="*", metavar="AGENT",
        help="Agent names to link (default: all)",
    )
    link_vault_p.add_argument("--vault-dir", help="Path to vault directory (default: $AGENTFORGE_ROOT/vault)")
    link_vault_p.add_argument("--dry-run", action="store_true", help="Show what would be moved without doing it")

    sync_state_p = agent_sub.add_parser(
        "sync-system-state",
        help="Regenerate the shared read-only system state note",
    )
    sync_state_p.add_argument("--config", help="Path to config.json")

    # --- agentforge memory ---
    mem_parser = sub.add_parser("memory", help="Memory / conversation database operations")
    mem_sub = mem_parser.add_subparsers(dest="memory_command")

    search_p = mem_sub.add_parser("search", help="Search conversations")
    search_p.add_argument("query", help="Search query")

    recent_p = mem_sub.add_parser("recent", help="Show recent messages")
    recent_p.add_argument("count", nargs="?", type=int, default=20, help="Number of messages")

    mem_sub.add_parser("stats", help="Show database statistics")

    # --- agentforge init ---
    init_parser = sub.add_parser("init", help="Initialize a new AgentForge instance")
    init_parser.add_argument("--dir", default=".", help="Target directory (default: current)")
    init_parser.add_argument(
        "--non-interactive",
        action="store_true",
        help="Skip the setup wizard and only scaffold template files",
    )

    # --- agentforge vault ---
    vault_parser = sub.add_parser("vault", help="Structured memory vault operations")

    # --- agentforge service ---
    svc_parser = sub.add_parser("service", help="Manage systemd service")
    svc_sub = svc_parser.add_subparsers(dest="service_command")

    svc_gen = svc_sub.add_parser("generate", help="Generate systemd unit files")
    svc_gen.add_argument("--name", default="agentforge", help="Service name (default: agentforge)")
    svc_gen.add_argument("--no-heartbeat", action="store_true", help="Skip heartbeat timer generation")
    svc_gen.add_argument("--heartbeat-interval", type=int, default=10,
                         help="Heartbeat interval in minutes (default: 10)")
    svc_gen.add_argument("--no-monitoring", action="store_true", help="Skip monitoring heartbeat timer generation")
    svc_gen.add_argument("--monitoring-interval", type=int, default=5,
                         help="Monitoring heartbeat interval in minutes (default: 5)")

    svc_sub.add_parser("status", help="Show service status")

    svc_logs = svc_sub.add_parser("logs", help="Show service logs")
    svc_logs.add_argument("-n", "--lines", type=int, default=50, help="Number of lines")

    # --- agentforge sync ---
    sync_parser = sub.add_parser("sync", help="Knowledge vault sync via Syncthing")
    sync_sub = sync_parser.add_subparsers(dest="sync_command")

    sync_sub.add_parser("setup", help="Set up Syncthing for vault syncing")
    sync_sub.add_parser("status", help="Show sync status")

    # --- agentforge update ---
    upd_parser = sub.add_parser("update", help="Check and apply updates")
    upd_sub = upd_parser.add_subparsers(dest="update_command")

    upd_check = upd_sub.add_parser("check", help="Check for available updates")
    upd_check.add_argument("--channel", default="stable", choices=["stable", "beta"],
                           help="Release channel (default: stable)")

    upd_apply = upd_sub.add_parser("apply", help="Apply available updates")
    upd_apply.add_argument("--channel", default="stable", choices=["stable", "beta"])
    upd_apply.add_argument("--yes", "-y", action="store_true", help="Skip confirmation prompt")
    upd_apply.add_argument("--skip-restart", action="store_true",
                           help="Don't restart the service after update")

    upd_sub.add_parser("rollback", help="Rollback to the previous version")
    upd_sub.add_parser("status", help="Show update status and version info")

    upd_auto = upd_sub.add_parser("auto-enable", help="Enable automatic update checking")
    upd_auto.add_argument("--auto-apply", action="store_true",
                          help="Automatically apply updates (default: notify only)")
    upd_auto.add_argument("--interval-hours", type=int, default=24,
                          help="Check interval in hours (default: 24)")

    upd_sub.add_parser("auto-disable", help="Disable automatic update checking")

    # Parse
    args = parser.parse_args(argv)

    if args.command is None:
        parser.print_help()
        sys.exit(0)

    if args.command == "bot":
        _run_bot(args)
    elif args.command == "api":
        _run_api(args)
    elif args.command == "agent":
        _run_agent(args)
    elif args.command == "memory":
        _run_memory(args)
    elif args.command == "init":
        _run_init(args)
    elif args.command == "vault":
        _run_vault(args)
    elif args.command == "service":
        _run_service(args)
    elif args.command == "sync":
        _run_sync(args)
    elif args.command == "update":
        _run_update(args)
    else:
        parser.print_help()
        sys.exit(1)


def _run_bot(args):
    """Start the Telegram bot."""
    import logging
    import os
    from pathlib import Path

    root = os.environ.get("AGENTFORGE_ROOT", os.path.expanduser("~"))
    agent_dir = os.environ.get("AGENT_DIR")
    log_dir = Path(agent_dir) / "logs" if agent_dir else Path(root) / "logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(str(log_dir / "telegram.log")),
            logging.StreamHandler(),
        ],
    )
    from agentforge.telegram_adapter import ClawdiaBot
    bot = ClawdiaBot(config_path=args.config)
    bot.poll()


def _run_api(args):
    """Start the HTTP API server."""
    from agentforge.api_server import run_api_server

    run_api_server(host=args.host, port=args.port, config_path=args.config)


def _run_agent(args):
    """Dispatch agent subcommands."""
    from agentforge.cli.agent import (
        agent_create,
        agent_link_vault,
        agent_list,
        agent_remove,
        agent_sync_system_state,
    )

    if args.agent_command == "create":
        agent_create(args.name, backend=args.backend, model=args.model, thread_id=args.thread_id,
                     config_path=args.config)
    elif args.agent_command == "list":
        agent_list(config_path=args.config)
    elif args.agent_command == "remove":
        agent_remove(args.name, keep_files=args.keep_files, config_path=args.config)
    elif args.agent_command == "link-vault":
        agent_link_vault(
            args.agents or None,
            vault_dir=args.vault_dir,
            dry_run=args.dry_run,
        )
    elif args.agent_command == "sync-system-state":
        agent_sync_system_state(config_path=args.config)
    else:
        print("Usage: agentforge agent {create,list,remove,link-vault,sync-system-state}")
        sys.exit(1)


def _run_memory(args):
    """Dispatch memory subcommands."""
    from agentforge.memory_manager import MemoryManager

    if args.memory_command == "search":
        mm = MemoryManager()
        results = mm.search(args.query)
        for r in results:
            print(f"[{r['timestamp']}] {r['role']}: {r['content'][:200]}")
    elif args.memory_command == "recent":
        mm = MemoryManager()
        results = mm.recent(args.count)
        for r in results:
            print(f"[{r['timestamp']}] {r['role']}: {r['content'][:200]}")
    elif args.memory_command == "stats":
        mm = MemoryManager()
        mm.stats()
    else:
        print("Usage: agentforge memory {search,recent,stats}")
        sys.exit(1)


def _run_init(args):
    """Initialize a new AgentForge instance."""
    from agentforge.cli.init import forge_init
    forge_init(args.dir, interactive=not args.non_interactive)


def _run_vault(args):
    """Forward to vault module."""
    from agentforge.vault import main as vault_main
    vault_main()


def _run_service(args):
    """Dispatch service subcommands."""
    from agentforge.cli.service import service_generate, service_status, service_logs

    if args.service_command == "generate":
        service_generate(
            name=args.name,
            heartbeat=not args.no_heartbeat,
            heartbeat_interval=args.heartbeat_interval,
            monitoring=not args.no_monitoring,
            monitoring_interval=args.monitoring_interval,
        )
    elif args.service_command == "status":
        service_status()
    elif args.service_command == "logs":
        service_logs(lines=args.lines)
    else:
        print("Usage: agentforge service {generate,status,logs}")
        sys.exit(1)


def _run_sync(args):
    """Dispatch sync subcommands."""
    from agentforge.cli.sync import sync_setup, sync_status

    if args.sync_command == "setup":
        sync_setup()
    elif args.sync_command == "status":
        sync_status()
    else:
        print("Usage: agentforge sync {setup,status}")
        sys.exit(1)


def _run_update(args):
    """Dispatch update subcommands."""
    from agentforge.cli.update import (
        update_check, update_apply, update_rollback,
        update_status, update_auto_enable, update_auto_disable,
    )

    cmd = args.update_command

    # `agentforge update` with no subcommand → apply
    if cmd is None or cmd == "apply":
        channel = getattr(args, "channel", "stable")
        yes = getattr(args, "yes", False)
        skip_restart = getattr(args, "skip_restart", False)
        update_apply(channel=channel, yes=yes, skip_restart=skip_restart)
    elif cmd == "check":
        update_check(channel=getattr(args, "channel", "stable"))
    elif cmd == "rollback":
        update_rollback()
    elif cmd == "status":
        update_status()
    elif cmd == "auto-enable":
        update_auto_enable(
            auto_apply=getattr(args, "auto_apply", False),
            interval_hours=getattr(args, "interval_hours", 24),
        )
    elif cmd == "auto-disable":
        update_auto_disable()
    else:
        print("Usage: agentforge update {check,apply,rollback,status,auto-enable,auto-disable}")
        sys.exit(1)
