#!/usr/bin/env python3
"""AgentForge Telegram Adapter — polls Telegram, invokes Claude Code CLI.

This is the main bot process. It uses extracted modules for:
- HTTP: agentforge.http_client
- Routing: agentforge.message_router
- Claude invocation: agentforge.claude_runner
- Voice: agentforge.voice
"""

import json
import logging
import os
import queue
import random
import signal
import sqlite3
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
from typing import Any

from agentforge.http_client import http_get, http_post_json
from agentforge.config_models import AgentRuntimeConfig, ValidationError, load_agent_runtime_config, load_command_config
from agentforge.message_router import (
    get_thread_config,
    get_project_topic_config,
    get_agent_thread_config,
    parse_mention,
    build_topic_context,
)
from agentforge.claude_runner import (
    ClaudeCodeLimitError,
    InvokeResult,
    RateLimitError,
    format_claude_code_limit_user_message,
    invoke_claude,
)
from agentforge.approval_gates import ApprovalGates
from agentforge.claude_usage import ClaudeUsageError, get_claude_oauth_usage, parse_usage_reset
from agentforge.config_store import RuntimeConfigStore
from agentforge.rate_limiter import RateLimiter
from agentforge.conversation_store import ConversationStore
from agentforge.paths import resolve_runtime_local_bin, resolve_runtime_root, resolve_runtime_scripts_dir
from agentforge.task_engine import TaskEngine
from agentforge.voice import transcribe_voice_note

MONTREAL = ZoneInfo("America/Montreal")

AGENTFORGE_ROOT = os.environ.get("AGENTFORGE_ROOT", os.path.expanduser("~"))
AGENT_DIR = os.environ.get("AGENT_DIR")  # Per-agent dir, e.g. agents/archie/ — new architecture
CONFIG_PATH = Path(AGENTFORGE_ROOT) / "bot" / "config.json"
ENV_PATH = Path(AGENTFORGE_ROOT) / ".env"
MONITOR_NO_ACTION = "[NO_ACTION]"
MONITOR_REACT_ONLY = "[REACT_ONLY]"

WORKING_MESSAGES = [
    "⏳ Je travaille là-dessus, je te reviens…",
    "⏳ On it.",
    "⏳ Je m'en occupe.",
    "⏳ Laisse-moi regarder ça.",
    "⏳ En cours…",
    "⏳ Je creuse ça.",
    "⏳ Ça s'en vient.",
    "⏳ Working on it…",
    "⏳ Je cogite.",
    "⏳ Une seconde.",
    "⏳ Sur le coup.",
    "⏳ Let me check that.",
    "⏳ J'y travaille.",
    "⏳ En train de réfléchir…",
    "⏳ Donne-moi un moment.",
    "⏳ Je m'y mets.",
    "⏳ Hold on…",
    "⏳ Je fouille ça.",
    "⏳ Deux secondes.",
    "⏳ On the case.",
]

STARTUP_MESSAGES = [
    "✅ Je suis de retour.",
    "✅ Back online.",
    "✅ Me revoilà.",
    "✅ Rebooted and ready.",
    "✅ Je suis là, qu'est-ce que j'ai manqué ?",
    "✅ Redémarrage complété. Prête.",
    "✅ Back in business.",
    "✅ Online. Qu'est-ce qui se passe ?",
    "✅ Je reviens de nulle part, mais je suis là.",
    "✅ Restart réussi. À vos ordres.",
    "✅ Hello again.",
    "✅ C'est reparti.",
    "✅ J'ai survécu au redémarrage.",
    "✅ Ready when you are.",
    "✅ De retour sur mes pattes.",
    "✅ Relancée. On reprend ?",
    "✅ Je suis vivante.",
    "✅ Up and running.",
    "✅ Boop — je suis là.",
    "✅ Redémarrée avec succès. Bonjour !",
]


def _verify_telegram_bot_identity(
    api_base: str,
    expected_username: str,
    *,
    http_get_fn=http_get,
) -> bool:
    """Return True when identity is verified or unverifiable; False on mismatch."""
    expected = expected_username.strip().lstrip("@")
    if not expected:
        return True

    try:
        payload = http_get_fn(f"{api_base}/getMe", timeout=10)
    except Exception as exc:
        logging.warning(f"Could not verify Telegram bot identity: {exc}")
        return True

    if not payload.get("ok"):
        description = payload.get("description", "unknown error")
        logging.warning(f"Could not verify Telegram bot identity: {description}")
        return True

    actual = str(payload.get("result", {}).get("username", "")).strip().lstrip("@")
    if not actual:
        logging.warning("Could not verify Telegram bot identity: missing username in getMe response.")
        return True

    if actual.lower() != expected.lower():
        logging.error(f"Telegram token mismatch: expected @{expected} but token belongs to @{actual}.")
        return False

    logging.info(f"  ✓ Telegram token verified for @{actual}")
    return True


class ClawdiaBot:
    def __init__(self, config_path: str | None = None):
        if config_path:
            path = Path(config_path)
        elif AGENT_DIR:
            path = Path(AGENT_DIR) / "config.json"
        else:
            path = CONFIG_PATH
        self._config_path = path
        self._config_store = RuntimeConfigStore(
            path,
            normalizer=self._normalize_config,
            log_warning=logging.warning,
        )
        self.config = self._config_store.get_config()
        self.bot_name = self.config.get("bot_name", "assistant")
        self._load_env()
        self.token = os.environ.get(self.config["telegram"]["token_env_var"], "")
        if not self.token:
            logging.error(
                f"Telegram token not found in env var "
                f"{self.config['telegram']['token_env_var']}"
            )
            sys.exit(1)
        self.api_base = f"https://api.telegram.org/bot{self.token}"
        expected_bot = self.config.get("telegram", {}).get("bot_username", "")
        if not _verify_telegram_bot_identity(self.api_base, expected_bot):
            sys.exit(1)
        self._build_api_bases()
        self.offset = self._load_offset()
        self.db = self._init_db()
        self.db_lock = threading.Lock()
        self.agent_queues: dict[str, queue.Queue] = {}
        self.agent_workers: dict[str, threading.Thread] = {}
        limits_cfg = self.config.get("rate_limits", {})
        self.rate_limiter = RateLimiter(
            max_per_minute=int(limits_cfg.get("max_per_minute", 10)),
            max_per_hour=int(limits_cfg.get("max_per_hour", 60)),
            max_concurrent_sessions=int(limits_cfg.get("max_concurrent_sessions", 2)),
        )
        self.running = True
        self._last_retry_check = 0.0
        self.approval_gates = ApprovalGates(root=AGENTFORGE_ROOT)
        signal.signal(signal.SIGTERM, self._shutdown)
        signal.signal(signal.SIGINT, self._shutdown)
        self._register_commands()
        # Pre-start one worker per known agent
        self._ensure_agent_worker(self.bot_name)
        for tid, tcfg in self.config.get("threads", {}).items():
            if tid == "default":
                continue
            agent_name = tcfg.get("name", self.bot_name) or self.bot_name
            self._ensure_agent_worker(agent_name)

    # ------------------------------------------------------------------
    # Initialization helpers
    # ------------------------------------------------------------------

    def _load_env(self):
        """Source .env file into environment."""
        if ENV_PATH.exists():
            for line in ENV_PATH.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ[key.strip()] = val.strip()

    def _normalize_config(self, raw: dict) -> dict:
        """Normalize a per-agent config.json (new format) into the legacy structure.

        When AGENT_DIR is set the config has a flat structure:
            {"name": "archie", "telegram": {...}, "claude": {...}, "context": {...}}
        This is converted to the internal representation expected by ClawdiaBot.
        Legacy configs (with bot_name, threads, memory keys) pass through unchanged.
        """
        if "bot_name" in raw or "threads" in raw:
            return raw  # already in legacy format

        try:
            raw = AgentRuntimeConfig.model_validate(raw).model_dump()
        except ValidationError as exc:
            raise ValueError(f"Invalid config at {self._config_path}: {exc}") from exc

        name = raw.get("name", "assistant")
        db_path = str(Path(AGENTFORGE_ROOT) / "data" / "conversations.db")
        ctx = raw.get("context", {})
        normalized = {
            "bot_name": name,
            "telegram": raw.get("telegram", {}),
            "claude": raw.get("claude", {}),
            "context": ctx,
            "memory": {"db_path": db_path},
            # Include agent name in default thread so _build_system_prompt_context
            # resolves to canonical vault prompt files, with legacy agents/<name>/
            # files as fallback for older installs.
            "threads": {
                "default": {
                    "name": name,
                    "backend": raw.get("claude", {}).get("backend", ""),
                    "model": raw.get("claude", {}).get("model", "haiku"),
                }
            },
            "commands": {},
        }
        return normalized

    def _discover_filesystem_commands(self) -> dict[str, dict]:
        """Discover slash commands from commands/ dirs on the filesystem.

        Looks in:
          1. {AGENTFORGE_ROOT}/commands/*/
          2. {AGENTFORGE_ROOT}/agents/shared/commands/*/

        Each command dir must contain task.sh.  Optional config.json may provide:
            {"description": "...", "visible": true}

        Returns a mapping of "/cmd_name" → {"script": "commands/cmd_name/task.sh",
                                             "description": "...", "source": "fs"}.
        """
        commands: dict[str, dict] = {}
        search_dirs = [
            Path(AGENTFORGE_ROOT) / "commands",
            Path(AGENTFORGE_ROOT) / "agents" / "shared" / "commands",
        ]
        for base in search_dirs:
            if not base.is_dir():
                continue
            for cmd_dir in sorted(base.iterdir()):
                if not cmd_dir.is_dir():
                    continue
                task_sh = cmd_dir / "task.sh"
                if not task_sh.exists():
                    continue
                # Telegram commands must be [a-z0-9_] only — convert hyphens to underscores
                cmd_name = "/" + cmd_dir.name.lower().replace("-", "_")
                cfg_path = cmd_dir / "config.json"
                description = ""
                visible = True
                if cfg_path.exists():
                    try:
                        cfg = load_command_config(cfg_path)
                        description = cfg.description
                        visible = cfg.visible
                    except ValidationError as exc:
                        logging.warning(f"Skipping invalid command config {cfg_path}: {exc}")
                        continue
                    except Exception as exc:
                        logging.warning(f"Skipping unreadable command config {cfg_path}: {exc}")
                        continue
                if not visible:
                    continue
                # Relative path from AGENTFORGE_ROOT for the script key
                try:
                    rel = str(task_sh.relative_to(AGENTFORGE_ROOT))
                except ValueError:
                    rel = str(task_sh)
                commands[cmd_name] = {
                    "script": rel,
                    "description": description,
                    "source": "fs",
                }
        return commands

    def _build_api_bases(self):
        """Build per-thread and per-agent API base URLs for multi-bot tokens."""
        self.thread_api_bases: dict[str, str] = {}
        self.agent_api_bases: dict[str, str] = {}
        for tid, tcfg in self.config.get("threads", {}).items():
            if tid == "default":
                continue
            env_var = tcfg.get("token_env_var")
            if env_var:
                agent_token = os.environ.get(env_var, "")
                if agent_token:
                    self.thread_api_bases[tid] = f"https://api.telegram.org/bot{agent_token}"
                    name = tcfg.get("name")
                    if name:
                        self.agent_api_bases[name] = f"https://api.telegram.org/bot{agent_token}"

    # Built-in commands registered automatically on every instance.
    # These appear in the Telegram autocomplete menu alongside any instance-local commands.
    BUILTIN_COMMANDS = {
        "/status": "État du système (bot, CPU/disk, crons, usage Claude)",
        "/restart": "Redémarrer un autre agent",
        "/active": "Voir ou modifier l'état actif de l'agent",
        "/claudelogin": "Générer un lien Claude login frais",
    }

    def _get_current_service_unit(self) -> str:
        if AGENT_DIR:
            return f"agentforge-{self.bot_name}.service"
        return "agentforge.service"

    def _discover_restartable_agents(self) -> list[dict[str, str]]:
        agents: dict[str, dict[str, str]] = {}

        global_config = self.config if "bot_name" in self.config else {}
        global_name = str(global_config.get("bot_name", "")).strip().lower()
        if global_name:
            agents[global_name] = {
                "name": global_name,
                "service_unit": "agentforge.service",
                "label": global_name,
            }

        for thread_cfg in self.config.get("threads", {}).values():
            name = str(thread_cfg.get("name") or "").strip().lower()
            if not name or name in agents:
                continue
            agents[name] = {
                "name": name,
                "service_unit": f"agentforge-{name}.service",
                "label": name,
            }

        agents_dir = Path(AGENTFORGE_ROOT) / "agents"
        if agents_dir.exists():
            for agent_dir in sorted(agents_dir.iterdir()):
                if not agent_dir.is_dir() or agent_dir.name.startswith("_") or agent_dir.name == "shared":
                    continue
                name = agent_dir.name.strip().lower()
                if not name:
                    continue
                agents.setdefault(
                    name,
                    {
                        "name": name,
                        "service_unit": f"agentforge-{name}.service",
                        "label": name,
                    },
                )

        current_name = (self.bot_name or "").strip().lower()
        return sorted(
            (entry for name, entry in agents.items() if name and name != current_name),
            key=lambda item: item["name"],
        )

    def _build_restart_picker(self) -> dict[str, Any]:
        agents = self._discover_restartable_agents()
        if not agents:
            return {"text": "⚠️ Aucun autre agent redémarrable trouvé."}

        keyboard = []
        for agent in agents:
            keyboard.append(
                [
                    {
                        "text": agent["label"],
                        "callback_data": f"/restart {agent['name']}",
                    }
                ]
            )

        return {
            "text": "Choisis l'agent à redémarrer :",
            "reply_markup": {"inline_keyboard": keyboard},
        }

    def _restart_agent_service(self, agent_name: str) -> str:
        target = agent_name.strip().lower()
        if not target:
            return "Usage: `/restart`"

        if target == (self.bot_name or "").strip().lower():
            return "⚠️ Un agent ne peut pas se redémarrer lui-même via `/restart`."

        agents = {entry["name"]: entry for entry in self._discover_restartable_agents()}
        selected = agents.get(target)
        if selected is None:
            return f"⚠️ Agent inconnu ou non redémarrable : `{target}`"

        env = os.environ.copy()
        env.setdefault("XDG_RUNTIME_DIR", f"/run/user/{os.getuid()}")

        try:
            subprocess.run(
                ["systemctl", "--user", "restart", selected["service_unit"]],
                capture_output=True,
                text=True,
                timeout=30,
                env=env,
                check=False,
            )
            status_proc = subprocess.run(
                ["systemctl", "--user", "is-active", selected["service_unit"]],
                capture_output=True,
                text=True,
                timeout=10,
                env=env,
                check=False,
            )
        except Exception as exc:
            logging.error(f"Restart failed for {selected['service_unit']}: {exc}")
            return f"❌ Redémarrage échoué pour `{target}` : {exc}"

        state = status_proc.stdout.strip() or "unknown"
        if status_proc.returncode == 0 and state == "active":
            return f"✅ `{target}` redémarré (`{selected['service_unit']}` actif)."

        stderr = status_proc.stderr.strip()
        detail = f" ({stderr})" if stderr else ""
        return f"⚠️ `{target}` redémarrage lancé, état actuel: `{state}`{detail}"

    @staticmethod
    def _format_cron_line(line: str) -> str:
        """Convert a raw crontab line into a human-readable summary.

        Input:  '55 9 * * * export HOME=... && /path/to/morning_brief.sh >> ...'
        Output: 'morning_brief — daily 09:55'
        """
        import re as _re
        parts = line.split()
        if len(parts) < 6:
            return line

        minute, hour, dom, month, dow = parts[:5]

        # Extract script name from the command (last *.sh before '>>')
        cmd = " ".join(parts[5:])
        script_match = _re.search(r'(\w+)\.sh', cmd)
        name = script_match.group(1).replace("_", " ") if script_match else cmd[:30]

        # Build human-readable schedule
        if dom == "*" and month == "*":
            if dow == "*":
                schedule = "daily"
            elif dow == "0":
                schedule = "Sun"
            elif dow == "1":
                schedule = "Mon"
            elif dow == "2":
                schedule = "Tue"
            elif dow == "3":
                schedule = "Wed"
            elif dow == "4":
                schedule = "Thu"
            elif dow == "5":
                schedule = "Fri"
            elif dow == "6":
                schedule = "Sat"
            else:
                schedule = f"dow={dow}"
        else:
            schedule = f"{dom}/{month}"

        try:
            time_str = f"{int(hour):02d}:{int(minute):02d}"
        except ValueError:
            time_str = f"{hour}:{minute}"

        return f"{name} — {schedule} {time_str}"

    def _builtin_status(self) -> str:
        """Return a status report: bot uptime, CPU/disk, cron schedule, and cc usage."""
        lines = []
        lines.append(f"🔧 Service: `{self._get_current_service_unit()}`")

        # --- Bot uptime ---
        try:
            uptime_proc = subprocess.run(
                ["systemctl", "--user", "show", "agentforge.service",
                 "--property=ActiveEnterTimestamp", "--value"],
                capture_output=True, text=True, timeout=5,
            )
            ts = uptime_proc.stdout.strip()
            if ts and ts != "n/a":
                from datetime import timezone
                start = datetime.strptime(ts, "%a %Y-%m-%d %H:%M:%S %Z").replace(tzinfo=timezone.utc)
                delta = datetime.now(timezone.utc) - start
                h, rem = divmod(int(delta.total_seconds()), 3600)
                m = rem // 60
                lines.append(f"🤖 Bot uptime: {h}h{m:02d}m")
            else:
                lines.append("🤖 Bot: running (uptime unknown)")
        except Exception:
            lines.append("🤖 Bot: running")

        # --- CPU & disk ---
        try:
            cpu_proc = subprocess.run(
                ["top", "-bn1"],
                capture_output=True, text=True, timeout=5,
            )
            for line in cpu_proc.stdout.splitlines():
                if "Cpu(s)" in line or "%Cpu" in line:
                    # Extract idle % → compute used %
                    import re
                    m = re.search(r"(\d+[\.,]\d+)\s*id", line)
                    if m:
                        idle = float(m.group(1).replace(",", "."))
                        used = round(100 - idle, 1)
                        lines.append(f"🖥  CPU: {used}% used")
                    break
        except Exception:
            pass

        try:
            df_proc = subprocess.run(
                ["df", "-h", AGENTFORGE_ROOT],
                capture_output=True, text=True, timeout=5,
            )
            df_lines = df_proc.stdout.strip().splitlines()
            if len(df_lines) >= 2:
                parts = df_lines[1].split()
                if len(parts) >= 5:
                    lines.append(f"💾 Disk: {parts[2]} used / {parts[1]} ({parts[4]})")
        except Exception:
            pass

        try:
            self._append_task_engine_summary(lines)
        except Exception as exc:
            logging.debug(f"Task engine summary failed: {exc}")

        # --- Cron schedule ---
        try:
            cron_proc = subprocess.run(
                ["crontab", "-l"],
                capture_output=True, text=True, timeout=5,
            )
            cron_lines = [
                l for l in cron_proc.stdout.splitlines()
                if l.strip() and not l.startswith("#")
            ]
            runtime_lines = [
                line for line in cron_lines
                if "heartbeat.sh" in line or "monitoring_heartbeat.sh" in line
            ]
            if runtime_lines:
                lines.append("\n⏰ Runtime:")
                for cl in runtime_lines:
                    lines.append(f"  {self._format_cron_line(cl)}")
        except Exception:
            pass

        try:
            self._append_claude_usage_summary(lines)
        except Exception as e:
            logging.debug(f"Usage summary failed: {e}")

        return "\n".join(lines) if lines else "✅ Système opérationnel."

    def _append_claude_usage_summary(self, lines: list[str]) -> None:
        try:
            payload = get_claude_oauth_usage(root=AGENTFORGE_ROOT)
        except ClaudeUsageError as exc:
            logging.debug(f"Real Claude usage unavailable: {exc}")
            lines.append("\n📊 Claude Code")
            lines.append("  Données d'usage indisponibles.")
            return

        self._append_real_claude_usage(lines, payload)

    def _append_real_claude_usage(self, lines: list[str], payload: dict) -> None:
        from datetime import timezone as _tz

        now_local = datetime.now(ZoneInfo("America/Toronto"))
        now_utc = datetime.now(_tz.utc)
        lines.append("\n📊 Utilisation")

        window_durations = {
            "five_hour":        5 * 3600,
            "seven_day":        7 * 24 * 3600,
            "seven_day_opus":   7 * 24 * 3600,
            "seven_day_sonnet": 7 * 24 * 3600,
        }

        for key, label in (
            ("five_hour", "Session 5h :"),
            ("seven_day", "Semaine :"),
            ("seven_day_opus", "Opus semaine :"),
            ("seven_day_sonnet", "Sonnet semaine :"),
        ):
            window = payload.get(key)
            if not isinstance(window, dict):
                continue

            utilization = float(window.get("utilization", 0.0))
            reset_at = parse_usage_reset(window.get("resets_at"))
            reset_label = self._format_usage_reset_label(reset_at, now_local)

            # % ahead / behind expected pace
            # delta > 0: consuming faster than expected → surconsommation
            # delta < 0: consuming slower than expected → en réserve
            delta_str = ""
            if reset_at is not None:
                window_duration = window_durations[key]
                time_until_reset = (reset_at - now_utc).total_seconds()
                time_elapsed = window_duration - time_until_reset
                if 0 < time_elapsed < window_duration:
                    expected_pct = (time_elapsed / window_duration) * 100
                    delta = utilization - expected_pct
                    if abs(delta) >= 1:
                        if delta > 0:
                            delta_str = f"{delta:.0f}% surconsommation"
                        else:
                            delta_str = f"{abs(delta):.0f}% en réserve"

            filled = max(0, min(10, round(utilization / 10)))
            bar = "▓" * filled + "░" * (10 - filled)
            lines.append(f"{label} (reset {reset_label})")
            lines.append(f"  {bar} {utilization:.0f}%")
            if delta_str:
                lines.append(delta_str)
            lines.append("")

        if lines[-1] == "":
            lines.pop()

    def _append_task_engine_summary(self, lines: list[str]) -> None:
        root = Path(AGENTFORGE_ROOT)
        engine = TaskEngine(root)
        actor_ids: list[str] = []
        agents_dir = root / "agents"
        if agents_dir.exists():
            actor_ids.extend(
                child.name
                for child in agents_dir.iterdir()
                if child.is_dir() and not child.name.startswith((".", "_")) and child.name != "shared"
            )
        actor_ids = sorted(set(actor_ids))
        if not actor_ids:
            return

        total_open = 0
        actionable_pairs: list[str] = []
        for actor_id in actor_ids:
            engine.bootstrap_actor(actor_id)
            tasks = engine.list_tasks(actor_id)
            open_count = sum(1 for task in tasks if task.status == "open")
            actionable_count = len(engine.select_actionable(actor_id, limit=50))
            total_open += open_count
            if actionable_count:
                actionable_pairs.append(f"{actor_id}:{actionable_count}")

        lines.append(f"🗂  Tasks: {total_open} open")
        if actionable_pairs:
            lines.append("  Actionable now: " + ", ".join(actionable_pairs))

    def _format_usage_reset_label(
        self,
        reset_at: datetime | None,
        now: datetime,
    ) -> str:
        if reset_at is None:
            return "inconnu"

        local = reset_at.astimezone(ZoneInfo("America/Toronto"))
        delta = local - now
        if 0 < delta.total_seconds() <= 12 * 3600:
            total_minutes = int(delta.total_seconds() // 60)
            hours, minutes = divmod(total_minutes, 60)
            return f"dans {hours}h{minutes:02d}"

        day_names_fr = ["lun", "mar", "mer", "jeu", "ven", "sam", "dim"]
        return f"{day_names_fr[local.weekday()]} {local.strftime('%Hh%M')}"

    def _dispatch_builtin(self, cmd_key: str, cmd_args: str = "") -> str | dict[str, Any] | None:
        """Handle built-in slash commands. Returns output string or None."""
        if cmd_key == "/status":
            return self._builtin_status()
        if cmd_key == "/restart":
            if cmd_args.strip():
                return self._restart_agent_service(cmd_args)
            return self._build_restart_picker()
        if cmd_key == "/active":
            arg = cmd_args.strip().lower()
            name = self.bot_name.capitalize()
            if arg == "true":
                self._set_active(True)
                return f"✅ {name} est maintenant actif."
            elif arg == "false":
                self._set_active(False)
                return f"⏸ {name} est désactivé. Heartbeats et messages sont ignorés.\nUtilisez `/active true` pour réactiver."
            else:
                status = "actif ✅" if self._is_active() else "désactivé ⏸"
                return f"{name} — état actuel : {status}"
        if cmd_key == "/claudelogin":
            return self._builtin_claude_login()
        return None

    def _builtin_claude_login(self) -> str:
        generator = resolve_runtime_scripts_dir(AGENTFORGE_ROOT) / "generate_claude_login_url.sh"
        if not generator.exists():
            return (
                "❌ Générateur de lien introuvable.\n"
                "Commande hôte: sudo -u agentforge -H bash -lc "
                "'cd /home/agentforge/AgentForge/runtime && ./.local/bin/claude auth login --claudeai'"
            )

        env = os.environ.copy()
        env["AGENTFORGE_ROOT"] = AGENTFORGE_ROOT
        env["AGENTFORGE_RUNTIME_ROOT"] = str(resolve_runtime_root(AGENTFORGE_ROOT))
        env["HOME"] = env["AGENTFORGE_RUNTIME_ROOT"]
        try:
            proc = subprocess.run(
                [str(generator)],
                capture_output=True,
                text=True,
                timeout=20,
                env=env,
            )
        except subprocess.TimeoutExpired:
            return "⏱ Génération du lien expirée. Réessaie `/claudelogin`."
        except Exception as exc:
            return f"❌ Impossible de générer le lien Claude login : {exc}"

        url = (proc.stdout or "").strip()
        if proc.returncode != 0 or not url.startswith("https://claude.ai/oauth/authorize?"):
            return (
                "❌ Impossible de générer un lien Claude login frais.\n"
                "Réessaie `/claudelogin` dans quelques secondes.\n"
                "Fallback hôte: sudo -u agentforge -H bash -lc "
                "'cd /home/agentforge/AgentForge/runtime && ./.local/bin/claude auth login --claudeai'"
            )

        return (
            "🔐 Lien Claude login généré maintenant.\n"
            "Ouvre-le tout de suite; il peut expirer rapidement.\n\n"
            f"{url}\n\n"
            "Si le lien expire, renvoie `/claudelogin`."
        )

    def _register_commands(self):
        """Register slash commands with Telegram via setMyCommands API.

        Merges built-in commands with instance-local commands from config.json,
        then pushes the list to Telegram so the native autocomplete menu works.

            "commands": {
                "/brief": {"script": "commands/brief.sh", "description": "Morning brief immédiat"},
                ...
            }
        """
        tg_commands = []

        # 1. Built-in commands (always registered)
        for cmd, description in self.BUILTIN_COMMANDS.items():
            tg_commands.append({"command": cmd.lstrip("/"), "description": description})

        # 2. Filesystem commands (commands/ and agents/shared/commands/)
        fs_commands = self._discover_filesystem_commands()
        for cmd, cfg in fs_commands.items():
            description = cfg.get("description", "")
            if description:
                tg_commands.append({"command": cmd.lstrip("/"), "description": description})

        # 3. Instance-local commands from config.json (legacy / override)
        commands_cfg = self.config.get("commands", {})
        for cmd, cfg in commands_cfg.items():
            if not cmd.startswith("/"):
                continue
            description = cfg.get("description", "")
            if description:
                # Only add if not already registered from filesystem
                if not any(c["command"] == cmd.lstrip("/") for c in tg_commands):
                    tg_commands.append({"command": cmd.lstrip("/"), "description": description})

        if not tg_commands:
            return

        # Register commands for multiple scopes:
        # - default (private chats, no scope param)
        # - all_group_chats (covers supergroups where the bot lives)
        # - per-chat for each explicitly allowed chat (most reliable for supergroups)
        scopes: list[dict] = [
            {},  # default scope — private chats
            {"scope": {"type": "all_group_chats"}},
        ]
        allowed_chat_ids = self.config.get("telegram", {}).get("allowed_chat_ids", [])
        for cid in allowed_chat_ids:
            scopes.append({"scope": {"type": "chat", "chat_id": int(cid)}})

        registered = 0
        for extra in scopes:
            try:
                payload = {"commands": tg_commands, **extra}
                result = http_post_json(f"{self.api_base}/setMyCommands", payload)
                if result.get("ok"):
                    registered += 1
                else:
                    scope_label = extra.get("scope", {}).get("type", "default")
                    logging.warning(
                        f"setMyCommands({scope_label}) failed: {result.get('description', result)}"
                    )
            except Exception as e:
                logging.warning(f"Could not register slash commands: {e}")

        if registered:
            logging.info(
                f"Registered {len(tg_commands)} slash command(s) across {registered}/{len(scopes)} scope(s)."
            )

    def _dispatch_command(self, text: str, chat_id: str, thread_id) -> str | None:
        """If text is a slash command, execute it and return output.

        Checks built-in commands first, then instance-local scripts from config.json.
        Returns the output string, or None if the text is not a known command.
        """
        if not text.startswith("/"):
            return None

        # Parse command name and optional args ("/brief" or "/search foo bar")
        parts = text.split(None, 1)
        cmd_key = parts[0].split("@", 1)[0].lower()
        cmd_args = parts[1] if len(parts) > 1 else ""

        if cmd_key in {"/search", "/deepsearch"}:
            return self._start_search_job(cmd_key, cmd_args, chat_id, thread_id)

        # 1. Built-in commands
        builtin_result = self._dispatch_builtin(cmd_key, cmd_args)
        if builtin_result is not None:
            return builtin_result

        # 2. Filesystem commands (commands/ and agents/shared/commands/)
        all_commands = self._discover_filesystem_commands()
        # 3. Merge with instance-local commands from config.json
        for k, v in self.config.get("commands", {}).items():
            if k not in all_commands:
                all_commands[k] = v

        cfg = all_commands.get(cmd_key)
        if cfg is None:
            return None

        script_rel = cfg.get("script")
        if not script_rel:
            return None

        script_path = Path(AGENTFORGE_ROOT) / script_rel
        if not script_path.exists():
            return f"⚠️ Script introuvable : `{script_rel}`"

        try:
            env = os.environ.copy()
            env["AGENTFORGE_ROOT"] = AGENTFORGE_ROOT
            if AGENT_DIR:
                env["AGENT_DIR"] = AGENT_DIR
                env["AGENT_NAME"] = self.bot_name
            env["CMD_ARGS"] = cmd_args
            proc = subprocess.run(
                [str(script_path)] + (cmd_args.split() if cmd_args else []),
                capture_output=True,
                text=True,
                timeout=60,
                env=env,
            )
            output = (proc.stdout + proc.stderr).strip()
            if not output:
                return f"✅ `{cmd_key}` exécuté (pas de sortie)."
            # Detect JSON output with inline keyboard
            if output.startswith("{"):
                try:
                    parsed = json.loads(output)
                    if isinstance(parsed, dict) and "text" in parsed:
                        return parsed
                except (json.JSONDecodeError, ValueError):
                    pass
            return output
        except subprocess.TimeoutExpired:
            return f"⏱ `{cmd_key}` timeout après 60s."
        except Exception as e:
            return f"❌ Erreur lors de l'exécution de `{cmd_key}` : {e}"

    def _start_search_job(self, cmd_key: str, query: str, chat_id: str, thread_id) -> str:
        query = (query or "").strip()
        if not query:
            return f"Usage: `{cmd_key} <query>`"

        depth = "deep" if cmd_key == "/deepsearch" else "quick"
        thread_cfg = get_thread_config(thread_id, self.config)
        agent_name = thread_cfg.get("name", self.bot_name)
        ack = f"🔍 Recherche en cours sur : {query}"

        def run_job() -> None:
            try:
                from agentforge.search.models import SearchRequest
                from agentforge.search.pipeline import run_search

                request = SearchRequest(
                    query=query,
                    sources=["brave"],
                    depth=depth,
                    max_results_per_source=15 if depth == "deep" else 8,
                )
                report, report_path = run_search(
                    request=request,
                    root=AGENTFORGE_ROOT,
                    config=self.config,
                    thread_cfg=thread_cfg,
                    mode="recherche",
                )
                summary = report.summary.strip()
                completion = (
                    f"✅ Recherche terminée: {query}\n\n"
                    f"{summary}\n\n"
                    f"Rapport: {report_path}"
                )
                self._send_message(chat_id, completion, thread_id, agent_name=agent_name)
            except Exception as exc:
                self._send_message(
                    chat_id,
                    f"❌ Recherche échouée: {exc}",
                    thread_id,
                    agent_name=agent_name,
                )

        threading.Thread(target=run_job, daemon=True).start()
        return ack

    def _load_offset(self) -> int:
        state_path = self._get_state_path()
        if state_path.exists():
            state = json.loads(state_path.read_text())
            return state.get("telegram_offset", 0)
        return 0

    def _save_offset(self):
        state_path = self._get_state_path()
        state_path.parent.mkdir(parents=True, exist_ok=True)
        state = {}
        if state_path.exists():
            state = json.loads(state_path.read_text())
        state["telegram_offset"] = self.offset
        state_path.write_text(json.dumps(state, indent=2))

    def _get_state_path(self) -> Path:
        """State path for telegram_offset (and other bot-level keys)."""
        return (Path(AGENT_DIR) / "data" / "state.json") if AGENT_DIR else (Path(AGENTFORGE_ROOT) / "data" / "state.json")

    def _get_active_state_path(self) -> Path:
        """Per-agent state path for the active flag.

        Always resolves to agents/<bot_name>/data/state.json so the heartbeat
        (which iterates per-agent dir) reads the same file the bot writes,
        even in legacy shared-bot mode where AGENT_DIR is unset.
        """
        if AGENT_DIR:
            return Path(AGENT_DIR) / "data" / "state.json"
        return Path(AGENTFORGE_ROOT) / "agents" / self.bot_name / "data" / "state.json"

    def _is_active(self) -> bool:
        """Return True if this agent is active (default). Reads from per-agent state.json."""
        state_path = self._get_active_state_path()
        if not state_path.exists():
            return True
        try:
            state = json.loads(state_path.read_text())
            return bool(state.get("active", True))
        except Exception:
            return True

    def _set_active(self, active: bool) -> None:
        """Persist the active flag to per-agent state.json."""
        state_path = self._get_active_state_path()
        state_path.parent.mkdir(parents=True, exist_ok=True)
        state: dict = {}
        if state_path.exists():
            try:
                state = json.loads(state_path.read_text())
            except Exception:
                pass
        state["active"] = active
        state_path.write_text(json.dumps(state, indent=2))

    def _init_db(self) -> sqlite3.Connection:
        db_path = self.config["memory"]["db_path"]
        self.store = ConversationStore(db_path)
        return self.store.connection

    # ------------------------------------------------------------------
    # Main polling loop
    # ------------------------------------------------------------------

    def poll(self):
        logging.info("AgentForge Telegram adapter started — polling...")
        self._notify_startup()
        while self.running:
            try:
                self._refresh_runtime_config()
                updates = self._get_updates()
                for update in updates:
                    self._handle_update(update)
                if time.time() - self._last_retry_check > 60:
                    self._process_pending_retries()
                    self._last_retry_check = time.time()
            except KeyboardInterrupt:
                break
            except Exception as e:
                logging.error(f"Poll error: {e}", exc_info=True)
                time.sleep(5)
            time.sleep(self.config["telegram"]["poll_interval_seconds"])

    def _refresh_runtime_config(self) -> None:
        config, changed = self._config_store.reload_if_needed()
        if not changed:
            return

        self.config = config
        self._build_api_bases()
        self._register_commands()
        logging.info(f"Hot-reloaded runtime config from {self._config_path}")

    def _notify_startup(self):
        """Send a startup notification.

        Only the architect agent sends a notification (to the AgentForge group
        topic) so that all agents restarting don't flood Martin's private chat.
        Other agents stay silent on startup.
        """
        if self.bot_name != "architect":
            self._notify_update_if_needed()
            return
        try:
            from importlib.metadata import version as pkg_version
            try:
                v = pkg_version("agent-forge-installer")
            except Exception:
                v = "unknown"
            notify_cfg = self.config.get("telegram", {}).get("agentforge_topic", {})
            group_id = str(notify_cfg.get("group_id", "-1003757288851"))
            thread_id = notify_cfg.get("thread_id", 1549)
            msg = f"✅ Agents redémarrés _(v{v})_"
            self._send_message(group_id, msg, thread_id)
        except Exception as e:
            logging.warning(f"Startup notification failed: {e}")
        self._notify_update_if_needed()

    def _notify_update_if_needed(self):
        """Send a single update notification to the AgentForge topic when the package
        was upgraded.  Only the architect agent sends this message so that all agents
        restarting after an update don't flood the channel.

        Detection: version.json records ``previous_version``; if it differs from the
        currently installed package version we know an upgrade just happened.
        """
        try:
            if self.bot_name != "architect":
                return

            from importlib.metadata import version as pkg_version
            from agentforge.migrations import read_version_state

            try:
                current_v = pkg_version("agent-forge-installer")
            except Exception:
                return

            root = Path(AGENTFORGE_ROOT)
            state = read_version_state(root)
            previous_v = state.get("previous_version")

            if not previous_v or previous_v == current_v:
                return

            # An upgrade was applied — notify once in the AgentForge topic
            notify_cfg = self.config.get("telegram", {}).get("agentforge_topic", {})
            group_id = str(notify_cfg.get("group_id", "-1003757288851"))
            thread_id = notify_cfg.get("thread_id", 1549)

            msg = f"📦 AgentForge mis à jour : *{previous_v}* → *{current_v}*"
            self._send_message(group_id, msg, thread_id)
            logging.info(f"Update notification sent to AgentForge topic ({group_id}/{thread_id})")
        except Exception as e:
            logging.warning(f"Update notification failed: {e}")

    def _get_updates(self) -> list:
        try:
            data = http_get(
                f"{self.api_base}/getUpdates",
                params={
                    "offset": self.offset,
                    "timeout": 30,
                    "allowed_updates": json.dumps(["message", "callback_query"]),
                },
                timeout=35,
            )
            if not data.get("ok"):
                logging.error(f"Telegram API error: {data}")
                return []
            return data.get("result", [])
        except Exception as e:
            logging.error(f"Failed to get updates: {e}")
            return []

    # ------------------------------------------------------------------
    # Message handling
    # ------------------------------------------------------------------

    def _handle_update(self, update):
        self.offset = update["update_id"] + 1
        self._save_offset()

        # Handle inline button callbacks
        if update.get("callback_query"):
            self._handle_callback_query(update["callback_query"])
            return

        msg = update.get("message")
        if not msg:
            return

        chat_id = str(msg["chat"]["id"])
        allowed = self.config["telegram"].get("allowed_chat_ids", [])
        if allowed and chat_id not in [str(c) for c in allowed]:
            logging.warning(f"Ignoring message from unauthorized chat {chat_id}")
            return

        message_id = str(msg["message_id"])
        thread_id = msg.get("message_thread_id")
        session_id = f"tg-{chat_id}-t{thread_id}" if thread_id else f"tg-{chat_id}"
        project_cfg = get_project_topic_config(thread_id, self.config)

        allow_bot_messages = self.config.get("telegram", {}).get("allow_bot_messages", False)
        if msg.get("from", {}).get("is_bot") and not allow_bot_messages:
            if project_cfg:
                self._record_project_topic_bot_message(
                    msg,
                    chat_id=chat_id,
                    thread_id=thread_id,
                    session_id=session_id,
                )
            return

        # Topic routing: only respond if this agent is the default for this thread,
        # or if the agent is explicitly @mentioned in the message.
        if not self._should_respond_to_thread(msg, thread_id):
            return
        session_id = f"tg-{chat_id}-t{thread_id}" if thread_id else f"tg-{chat_id}"
        user_name = msg.get("from", {}).get("first_name", "User")
        thread_cfg = get_thread_config(thread_id, self.config)

        # Determine message content
        user_text = self._extract_message_text(msg, chat_id, thread_id)
        if user_text is None:
            return
        parent_message_id = self._resolve_reply_parent_message_id(
            chat_id=chat_id,
            thread_id=thread_id,
            reply_to=msg.get("reply_to_message"),
        )

        # Prepend reply context if replying to a message
        # Keep this lightweight inline cue even when a full flat thread is injected later;
        # it preserves immediate reply intent for legacy prompt consumers and for cases
        # where thread reconstruction is unavailable from storage.
        reply_to = msg.get("reply_to_message")
        if reply_to and reply_to.get("text"):
            user_text = f"[En réponse à : « {reply_to['text']} »]\n\n{user_text}"

        # Project topic routing
        if project_cfg:
            target_agent, user_text = parse_mention(user_text, project_cfg)
            thread_cfg = get_agent_thread_config(target_agent, self.config)
            thread_cfg["topic_context"] = build_topic_context(project_cfg, target_agent)

        logging.info(
            f"[{session_id}] thread={thread_id} model={thread_cfg.get('model')} "
            f"{user_name}: {user_text[:100]}"
        )

        agent_name = thread_cfg.get("name", self.bot_name) or self.bot_name
        allowed_rate, reason = self.rate_limiter.allow(chat_id, agent_name)
        if not allowed_rate:
            self._send_message(chat_id, f"⏱ {reason}", thread_id, agent_name=agent_name)
            return

        # Slash command dispatch — intercept before sending to Claude
        command_response = self._dispatch_command(user_text, chat_id, thread_id)
        if command_response is not None:
            response_text = command_response["text"] if isinstance(command_response, dict) else command_response
            is_error = isinstance(response_text, str) and any(
                response_text.startswith(p) for p in ("⚠️", "❌", "⏱")
            )

            self._set_reaction(chat_id, message_id, "⚠️" if is_error else "✅", thread_id, agent_name)
            if isinstance(command_response, dict):
                self._send_message(
                    chat_id,
                    command_response["text"],
                    thread_id,
                    agent_name=agent_name,
                    reply_markup=command_response.get("reply_markup"),
                )
            else:
                self._send_message(chat_id, command_response, thread_id, agent_name=agent_name)

            if is_error:
                # Save the command and error to conversation history so Claude
                # has context if the user follows up immediately.
                self._save_message(
                    session_id, "user", user_text,
                    chat_id, message_id,
                    thread_id=thread_id, agent_name=agent_name,
                )
                self._save_message(
                    session_id, "assistant", response_text,
                    chat_id, None,
                    thread_id=thread_id, agent_name=agent_name,
                )
                # Auto-relaunch Claude with the error as context so it can
                # react immediately (suggest a fix, explain the issue, etc.)
                error_prompt = (
                    f"La commande slash `{user_text}` a échoué avec l'erreur suivante :\n"
                    f"{response_text}\n\n"
                    f"Analyse l'erreur et propose une solution ou explique le problème."
                )
                self._enqueue_task({
                    "session_id": session_id,
                    "user_text": error_prompt,
                    "thread_cfg": thread_cfg,
                    "chat_id": chat_id,
                    "thread_id": thread_id,
                })
            return

        # Deactivated check — slash commands (including /active) are handled above;
        # all other messages are dropped with a brief notice.
        if not self._is_active():
            self._send_message(
                chat_id,
                f"_{self.bot_name.capitalize()} est actuellement désactivé(e)._\n_Utilisez `/active true` pour réactiver._",
                thread_id,
                agent_name=agent_name,
            )
            return

        is_monitor = self._is_monitor_thread(thread_id)
        current_message_id = None
        if not is_monitor:
            saved_message = self._save_message(
                session_id,
                "user",
                user_text,
                chat_id,
                message_id,
                thread_id=thread_id,
                agent_name=thread_cfg.get("name", self.bot_name),
                parent_message_id=parent_message_id,
            )
            current_message_id = saved_message.id
        self._enqueue_task({
            "session_id": session_id,
            "user_text": user_text,
            "thread_cfg": thread_cfg,
            "chat_id": chat_id,
            "thread_id": thread_id,
            "parent_message_id": parent_message_id,
            "current_message_id": current_message_id,
            "is_monitor_mode": is_monitor,
            "monitor_message_id": message_id if is_monitor else None,
        })

    def _should_respond_to_thread(self, msg, thread_id) -> bool:
        """Return True if this agent should respond to the given message.

        Rules (in order):
        1. Private chat → always respond.
        2. Agent is @mentioned in the message → respond.
        3. This thread is in the agent's default_for_threads list → respond.
        4. This thread is in the agent's monitor_threads list → respond (monitor mode).
        5. default_for_threads not configured → respond to everything (backward compat).
        6. Otherwise → ignore.
        """
        if msg.get("chat", {}).get("type") == "private":
            return True
        if self._is_mentioned(msg):
            return True
        default_threads = self.config.get("telegram", {}).get("default_for_threads")
        if default_threads is not None and thread_id in default_threads:
            return True
        monitor_threads = self.config.get("telegram", {}).get("monitor_threads")
        if monitor_threads is not None and thread_id in monitor_threads:
            return True
        if default_threads is None:
            return True  # Not configured → respond to everything
        return False

    def _is_self_bot_message(self, msg) -> bool:
        username = str(msg.get("from", {}).get("username", "")).strip().lstrip("@")
        expected = str(self.config.get("telegram", {}).get("bot_username", "")).strip().lstrip("@")
        return bool(username and expected and username.lower() == expected.lower())

    def _resolve_reply_parent_message_id(self, *, chat_id, thread_id, reply_to) -> int | None:
        if not reply_to:
            return None
        parent_message = self.store.find_telegram_message(
            chat_id=chat_id,
            telegram_message_id=str(reply_to.get("message_id", "")),
            channel_id=str(thread_id) if thread_id is not None else None,
        )
        if parent_message is None:
            return None
        return parent_message.parent_message_id or parent_message.id

    def _record_project_topic_bot_message(self, msg, *, chat_id, thread_id, session_id) -> None:
        # Preserve project-topic history even when bots are globally ignored.
        if self._is_self_bot_message(msg):
            return
        user_text = self._extract_message_text(msg, chat_id, thread_id)
        if user_text is None:
            return
        parent_message_id = self._resolve_reply_parent_message_id(
            chat_id=chat_id,
            thread_id=thread_id,
            reply_to=msg.get("reply_to_message"),
        )
        bot_username = str(msg.get("from", {}).get("username", "")).strip().lstrip("@")
        if bot_username:
            user_text = f"[@{bot_username}] {user_text}"
        self._save_message(
            session_id,
            "assistant",
            user_text,
            chat_id,
            str(msg.get("message_id", "")),
            thread_id=thread_id,
            agent_name=bot_username or None,
            parent_message_id=parent_message_id,
        )

    def _is_monitor_thread(self, thread_id) -> bool:
        """Return True if thread_id is a monitored (passive) thread for this agent."""
        monitor_threads = self.config.get("telegram", {}).get("monitor_threads")
        if monitor_threads is None:
            return False
        default_threads = self.config.get("telegram", {}).get("default_for_threads")
        # Only monitor mode if thread is in monitor_threads but NOT in default_for_threads
        if default_threads is not None and thread_id in default_threads:
            return False
        return thread_id in monitor_threads

    def _is_mentioned(self, msg) -> bool:
        """Return True if this agent's name is @mentioned in the message."""
        import re
        text = msg.get("text", "") or ""
        agent_name = getattr(self, "bot_name", "") or self.config.get("bot_name", "")
        if not agent_name:
            return False
        return bool(re.search(rf"@{re.escape(agent_name)}\b", text, re.IGNORECASE))

    def _extract_message_text(self, msg, chat_id, thread_id) -> str | None:
        """Extract text content from a Telegram message. Returns None for unsupported types."""
        if msg.get("text"):
            return msg["text"]
        elif msg.get("voice"):
            text = transcribe_voice_note(msg["voice"], self.api_base, self.token)
            if text is None:
                self._send_message(
                    chat_id,
                    "🎤 Transcription non disponible ou audio incompréhensible.",
                    thread_id,
                )
                return None
            self._send_message(chat_id, f"🎤 _{text}_", thread_id)
            return text
        elif msg.get("photo"):
            self._send_message(chat_id, "📷 Je ne supporte pas encore les images.", thread_id)
            return None
        elif msg.get("document") or msg.get("video") or msg.get("sticker"):
            self._send_message(chat_id, "📎 Je ne supporte pas encore ce type de fichier.", thread_id)
            return None
        return None

    # ------------------------------------------------------------------
    # Worker queue system
    # ------------------------------------------------------------------

    def _ensure_agent_worker(self, agent_name: str):
        if agent_name not in self.agent_queues:
            q: queue.Queue = queue.Queue()
            self.agent_queues[agent_name] = q
            t = threading.Thread(target=self._worker, args=(agent_name, q), daemon=True)
            t.start()
            self.agent_workers[agent_name] = t
            logging.info(f"Started worker for agent: {agent_name}")

    def _enqueue_task(self, task: dict):
        agent_name = task.get("thread_cfg", {}).get("name", self.bot_name) or self.bot_name
        self._ensure_agent_worker(agent_name)
        self.agent_queues[agent_name].put(task)
        logging.info(
            f"[{task.get('session_id', '?')}] Enqueued for agent={agent_name} "
            f"(queue size={self.agent_queues[agent_name].qsize()})"
        )

    def _worker(self, agent_name: str, task_queue: queue.Queue):
        """Dispatch loop — spawns one thread per task for parallel execution."""
        logging.info(f"Worker thread started for agent: {agent_name}.")
        while True:
            try:
                task = task_queue.get()
            except Exception:
                continue
            if task is None:
                logging.info(f"Worker {agent_name} received shutdown sentinel — exiting.")
                task_queue.task_done()
                break
            t = threading.Thread(
                target=self._invoke_and_respond,
                args=(task, task_queue),
                daemon=True,
            )
            t.start()

    def _invoke_and_respond(self, task: dict, task_queue: queue.Queue):
        """Run a single Claude invocation and send the response."""
        session_id = task["session_id"]
        user_text = task["user_text"]
        thread_cfg = task["thread_cfg"]
        chat_id = task["chat_id"]
        thread_id = task["thread_id"]
        worker_agent = thread_cfg.get("name", self.bot_name) or self.bot_name
        is_monitor_mode = bool(task.get("is_monitor_mode"))
        policy = self.approval_gates.evaluate_command(user_text)
        autonomy_level = self._resolve_autonomy_level(thread_cfg)

        if policy.status == "blocked":
            self.approval_gates.record_auto_decision(
                status="blocked",
                actor_label=worker_agent,
                chat_id=chat_id,
                thread_id=thread_id,
                command_text=user_text,
                reason=policy.reason,
            )
            self._send_message(
                chat_id,
                (
                    "⛔ Command blocked by safety policy before execution.\n"
                    f"Rule: `{policy.reason}`"
                ),
                thread_id,
                agent_name=worker_agent,
            )
            task_queue.task_done()
            return

        if policy.status == "approval_required":
            decision = self.approval_gates.request_and_wait(
                chat_id=chat_id,
                thread_id=thread_id,
                command_text=user_text,
                actor_label=worker_agent,
                send_message_fn=lambda cid, text, tid, reply_markup=None: self._send_message(
                    cid,
                    text,
                    tid,
                    agent_name=worker_agent,
                    reply_markup=reply_markup,
                ),
            )
            if decision.status != "approved":
                reason = "timed out" if decision.status == "timeout" else "denied"
                self._send_message(
                    chat_id,
                    f"⏸ Operation {reason}; execution skipped.",
                    thread_id,
                    agent_name=worker_agent,
                )
                task_queue.task_done()
                return
        self.rate_limiter.session_start(worker_agent)

        # Monitor mode: no typing indicator (silent triage)
        if is_monitor_mode:
            stop_typing = threading.Event()
        else:
            stop_typing = self._start_typing_loop(chat_id, thread_id, agent_name=worker_agent)

        result_holder: list[InvokeResult | None] = [None]
        error_holder: list[Exception | None] = [None]
        done_event = threading.Event()

        # Monitor mode: inject triage instructions and use lightweight model
        effective_user_text = user_text
        effective_thread_cfg = dict(thread_cfg)
        if is_monitor_mode:
            effective_thread_cfg["backend"] = "claude"
            effective_thread_cfg["model"] = "haiku"
            effective_thread_cfg["max_budget_usd"] = 0.5
            effective_user_text = (
                f"[MONITOR MODE — General topic message]\n\n"
                f"{user_text}\n\n"
                f"---\n"
                f"This message was posted in the General topic (shared across all agents). "
                f"You are monitoring it passively. Evaluate if this message concerns you "
                f"({worker_agent}) based on your role and responsibilities.\n\n"
                f"Rules:\n"
                f"- If the message does NOT concern you at all → respond ONLY with: {MONITOR_NO_ACTION}\n"
                f"- If the message concerns you and a 👍 reaction alone is enough → respond ONLY with: {MONITOR_REACT_ONLY}\n"
                f"- If the message concerns you and a reply is needed → respond with a short, relevant reply. "
                f"Do NOT add {MONITOR_NO_ACTION} or {MONITOR_REACT_ONLY} in this case.\n"
                f"- Keep your response very concise (1-3 sentences max).\n"
                f"- If someone explicitly @mentions you, always respond.\n"
            )

        def run_claude():
            try:
                parent_message_id = task.get("parent_message_id")
                current_message_id = task.get("current_message_id")
                thread_messages = None
                exclude_message_ids = {current_message_id} if current_message_id is not None else set()
                if parent_message_id is not None:
                    thread_messages, thread_ids = self.store.get_thread_context(
                        parent_message_id,
                        exclude_message_ids=exclude_message_ids,
                    )
                    exclude_message_ids.update(thread_ids)
                recent = self.store.get_dynamic_messages(
                    session_id,
                    min_msgs=3,
                    max_msgs=100,
                    hours=4,
                    agent_name=worker_agent or None,
                    exclude_message_ids=exclude_message_ids if exclude_message_ids else None,
                )
                result_holder[0] = invoke_claude(
                    session_id=session_id,
                    user_text=effective_user_text,
                    thread_cfg=effective_thread_cfg,
                    config=self.config,
                    recent_messages=recent,
                    thread_messages=thread_messages,
                    root=AGENTFORGE_ROOT,
                )
            except Exception as e:
                error_holder[0] = e
            finally:
                done_event.set()

        claude_thread = threading.Thread(target=run_claude, daemon=True)
        claude_thread.start()
        done_event.wait()
        stop_typing.set()
        self.rate_limiter.session_end(worker_agent)

        if error_holder[0] is not None:
            self._handle_worker_error(error_holder[0], task, chat_id, thread_id, worker_agent, task_queue)
            return

        invoke_result: InvokeResult = result_holder[0]
        response = invoke_result.text
        # Monitor mode: check if agent decided to act
        if is_monitor_mode:
            stripped = response.strip()
            if stripped == MONITOR_NO_ACTION or stripped.startswith(MONITOR_NO_ACTION):
                logging.info(f"[{session_id}] Monitor mode: {worker_agent} → no action")
                task_queue.task_done()
                return
            monitor_msg_id = task.get("monitor_message_id")
            if stripped == MONITOR_REACT_ONLY or stripped.startswith(MONITOR_REACT_ONLY):
                if monitor_msg_id:
                    self._set_reaction(chat_id, monitor_msg_id, "👍", thread_id, worker_agent)
                logging.info(f"[{session_id}] Monitor mode: {worker_agent} → react only")
                task_queue.task_done()
                return
            logging.info(f"[{session_id}] Monitor mode: {worker_agent} → replying")

        self._save_message(
            session_id, "assistant", response,
            chat_id, None,
            thread_id=thread_id, agent_name=worker_agent,
            parent_message_id=task.get("parent_message_id"),
        )
        self._send_message(chat_id, response, thread_id, agent_name=worker_agent)
        self._log_action(worker_agent, "telegram_send", "telegram", response[:100].replace("\n", " "))
        logging.info(f"[{session_id}] Invoke complete: {response[:100]}")
        task_queue.task_done()

    def _handle_worker_error(self, error, task, chat_id, thread_id, agent_name, task_queue):
        """Handle errors from Claude invocation in worker."""
        if isinstance(error, ClaudeCodeLimitError):
            message = format_claude_code_limit_user_message(error.restore_at)
            self._send_message(chat_id, message, thread_id, agent_name=agent_name)
        elif isinstance(error, RateLimitError):
            retry_attempt = task.get("_retry_attempt", 0)
            if retry_attempt >= 3:
                message = "⚠️ Rate limit persistant après 3 tentatives. Réessaie manuellement."
            else:
                self._save_pending_retry(task, error.retry_after_seconds)
                message = "⏸ Rate limit Anthropic atteint. Réessaie plus tard."
            self._send_message(chat_id, message, thread_id, agent_name=agent_name)
        else:
            message = "Sorry, I encountered an error. Please try again."
            self._send_message(chat_id, message, thread_id, agent_name=agent_name)
        task_queue.task_done()

    # ------------------------------------------------------------------
    # Telegram helpers
    # ------------------------------------------------------------------

    def _get_api_base(self, thread_id=None, agent_name=None) -> str:
        if agent_name and agent_name in self.agent_api_bases:
            return self.agent_api_bases[agent_name]
        if thread_id:
            return self.thread_api_bases.get(str(thread_id), self.api_base)
        return self.api_base

    def _send_typing(self, chat_id, thread_id=None, agent_name=None):
        try:
            payload = {"chat_id": chat_id, "action": "typing"}
            if thread_id:
                payload["message_thread_id"] = thread_id
            http_post_json(f"{self._get_api_base(thread_id, agent_name)}/sendChatAction", payload)
        except Exception:
            pass

    def _start_typing_loop(self, chat_id, thread_id, agent_name=None) -> threading.Event:
        stop_event = threading.Event()

        def loop():
            while not stop_event.wait(5):
                self._send_typing(chat_id, thread_id, agent_name)

        self._send_typing(chat_id, thread_id, agent_name)
        t = threading.Thread(target=loop, daemon=True)
        t.start()
        return stop_event

    def _send_message(self, chat_id, text, thread_id=None, agent_name=None, reply_markup=None):
        max_len = self.config.get("telegram", {}).get("max_message_length", 4096)
        chunks = [text[i : i + max_len] for i in range(0, len(text), max_len)]
        api_base = self._get_api_base(thread_id, agent_name)
        for i, chunk in enumerate(chunks):
            try:
                payload = {"chat_id": chat_id, "text": chunk}
                if thread_id:
                    payload["message_thread_id"] = thread_id
                # Only attach reply_markup to the last chunk
                if reply_markup and i == len(chunks) - 1:
                    payload["reply_markup"] = reply_markup
                http_post_json(f"{api_base}/sendMessage", payload)
            except Exception as e:
                if api_base != self.api_base:
                    logging.warning(f"Agent token failed ({e}), falling back to main token")
                    try:
                        http_post_json(f"{self.api_base}/sendMessage", payload)
                    except Exception as e2:
                        logging.error(f"Failed to send message (fallback also failed): {e2}")
                else:
                    logging.error(f"Failed to send message: {e}")

    def _handle_callback_query(self, cb: dict):
        """Handle an inline keyboard button press."""
        cb_id = cb.get("id", "")
        data = cb.get("data", "")
        msg = cb.get("message", {})
        chat_id = str(msg.get("chat", {}).get("id", ""))
        thread_id = msg.get("message_thread_id")

        # Answer the callback immediately (removes Telegram's loading spinner)
        try:
            http_post_json(f"{self.api_base}/answerCallbackQuery", {"callback_query_id": cb_id})
        except Exception as e:
            logging.warning(f"answerCallbackQuery failed: {e}")

        if not data or not chat_id:
            return

        allowed = self.config["telegram"].get("allowed_chat_ids", [])
        if allowed and chat_id not in [str(c) for c in allowed]:
            return

        logging.info(f"[callback] chat={chat_id} thread={thread_id} data={data!r}")
        actor_id = str(cb.get("from", {}).get("id", ""))
        gate_result = self.approval_gates.resolve_callback(data, actor_id=actor_id)
        if gate_result is not None:
            if gate_result.status == "handled":
                decision_label = "approved" if gate_result.reason == "approve" else "denied"
                self._send_message(chat_id, f"Decision recorded: {decision_label}.", thread_id)
            elif gate_result.status in {"not_found", "invalid"}:
                self._send_message(chat_id, "Approval request expired or invalid.", thread_id)
            return

        # Route the callback data as a slash command
        response = self._dispatch_command(data, chat_id, thread_id)
        if response is None:
            return

        thread_cfg = get_thread_config(thread_id, self.config)
        agent_name = thread_cfg.get("name", self.bot_name)
        if isinstance(response, dict):
            self._send_message(
                chat_id,
                response["text"],
                thread_id,
                agent_name=agent_name,
                reply_markup=response.get("reply_markup"),
            )
        else:
            self._send_message(chat_id, response, thread_id, agent_name=agent_name)

    def _set_reaction(self, chat_id, message_id, emoji, thread_id=None, agent_name=None):
        try:
            api_base = self._get_api_base(thread_id, agent_name)
            http_post_json(f"{api_base}/setMessageReaction", {
                "chat_id": chat_id,
                "message_id": int(message_id),
                "reaction": [{"type": "emoji", "emoji": emoji}],
            })
        except Exception as e:
            logging.warning(f"Could not set reaction: {e}")

    # ------------------------------------------------------------------
    # Database operations
    # ------------------------------------------------------------------

    def _save_message(
        self,
        session_id,
        role,
        content,
        chat_id=None,
        message_id=None,
        *,
        thread_id=None,
        agent_name=None,
        parent_message_id=None,
    ):
        metadata = {}
        if thread_id is not None:
            metadata["channel"] = str(thread_id)
        if agent_name:
            metadata["agent"] = agent_name
        return self.store.save_message(
            session_id,
            role,
            content,
            source="telegram",
            telegram_chat_id=chat_id,
            telegram_message_id=message_id,
            metadata=metadata or None,
            parent_message_id=parent_message_id,
            agent_name=agent_name or None,
        )

    def _get_recent_messages(self, session_id, limit, hours=None) -> list[tuple[str, str, str]]:
        return self.store.get_recent_messages(session_id, limit, hours=hours)

    # ------------------------------------------------------------------
    # Retry system
    # ------------------------------------------------------------------

    def _save_pending_retry(self, task, retry_after_seconds=3600):
        now = datetime.now(MONTREAL)
        retry_after = (now + timedelta(seconds=retry_after_seconds)).strftime("%Y-%m-%d %H:%M:%S")
        with self.db_lock:
            self.db.execute(
                """
                INSERT INTO pending_retries
                (session_id, user_text, thread_cfg, chat_id, thread_id, created_at, retry_after, attempts)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                """,
                (
                    task["session_id"],
                    task["user_text"],
                    json.dumps(task["thread_cfg"]),
                    task["chat_id"],
                    str(task["thread_id"]) if task["thread_id"] is not None else None,
                    now.strftime("%Y-%m-%d %H:%M:%S"),
                    retry_after,
                ),
            )
            self.db.commit()

    def _process_pending_retries(self):
        now = datetime.now(MONTREAL).strftime("%Y-%m-%d %H:%M:%S")
        with self.db_lock:
            cur = self.db.execute(
                """
                SELECT id, session_id, user_text, thread_cfg, chat_id, thread_id, attempts
                FROM pending_retries WHERE retry_after <= ?
                """,
                (now,),
            )
            rows = cur.fetchall()
        for row in rows:
            rid, session_id, user_text, thread_cfg_json, chat_id, thread_id, attempts = row
            thread_cfg = json.loads(thread_cfg_json)
            thread_id_val = int(thread_id) if thread_id else None
            with self.db_lock:
                self.db.execute("DELETE FROM pending_retries WHERE id = ?", (rid,))
                self.db.commit()
            logging.info(f"[{session_id}] Re-queuing rate-limited message (attempt {attempts + 1})")
            self._send_message(chat_id, "🔄 Rate limit expiré — je reprends ta question…", thread_id_val)
            self._enqueue_task({
                "session_id": session_id,
                "user_text": user_text,
                "thread_cfg": thread_cfg,
                "chat_id": chat_id,
                "thread_id": thread_id_val,
                "_retry_attempt": attempts,
            })

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def _log_action(self, agent, action_type, target, details=""):
        try:
            subprocess.Popen(
                [str(resolve_runtime_scripts_dir(AGENTFORGE_ROOT) / "log_action.sh"), agent, action_type, target, details],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=AGENTFORGE_ROOT,
                env={
                    **os.environ,
                    "HOME": os.environ.get("AGENTFORGE_RUNTIME_ROOT", str(Path(AGENTFORGE_ROOT) / "runtime")),
                    "PATH": f"{resolve_runtime_local_bin(AGENTFORGE_ROOT)}:" + os.environ.get("PATH", "/usr/bin:/bin"),
                },
            )
        except Exception as e:
            logging.warning(f"log_action failed: {e}")

    def _shutdown(self, signum, frame):
        logging.info("Shutting down gracefully...")
        self.running = False

    def _resolve_autonomy_level(self, thread_cfg: dict) -> int:
        raw = (
            thread_cfg.get("autonomy_level")
            or thread_cfg.get("autonomy")
            or self.config.get("autonomy_level")
            or self.config.get("context", {}).get("autonomy_level")
            or 2
        )
        try:
            level = int(raw)
        except (TypeError, ValueError):
            level = 2
        return max(0, min(4, level))


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(str(Path(AGENTFORGE_ROOT) / "logs" / "telegram.log")),
            logging.StreamHandler(),
        ],
    )
    bot = ClawdiaBot()
    bot.poll()
