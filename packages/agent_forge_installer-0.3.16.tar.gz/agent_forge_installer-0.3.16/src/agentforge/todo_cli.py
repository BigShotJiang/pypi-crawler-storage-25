"""CLI helpers for the structured task engine."""

from __future__ import annotations

import argparse
from datetime import datetime
import json
import os
from pathlib import Path

from agentforge.task_engine import TaskEngine, TaskRecord
from agentforge.todo_md import parse_tasks_text


def _resolve_root(root: str | None) -> Path:
    if root:
        return Path(root)
    return Path(os.environ.get("AGENTFORGE_ROOT", ".")).resolve()


def _resolve_actor(actor: str | None) -> str:
    if actor:
        return actor.strip().lstrip("@").lower()
    return os.environ.get("AGENT_NAME", "architect").strip().lstrip("@").lower()


def _read_raw_args(values: list[str]) -> str:
    raw_env = os.environ.get("CMD_RAW")
    if raw_env:
        return raw_env.strip()
    return " ".join(values).strip()


def _format_user_list(items: list[TaskRecord], *, title: str) -> str:
    if not items:
        return f"{title}\n\nNo matching open tasks."
    lines = [title, ""]
    for index, item in enumerate(items, start=1):
        extra: list[str] = []
        if item.schedule_type == "recurring" and item.next_run_at:
            extra.append(f"next {item.next_run_at.strftime('%Y-%m-%d %H:%M')}")
        elif item.due_at:
            extra.append(item.due_at.strftime("%Y-%m-%d %H:%M") if item.due_at.time().hour or item.due_at.time().minute else item.due_at.strftime("%Y-%m-%d"))
        if item.tags:
            extra.append(" ".join(item.tags))
        suffix = f" ({' | '.join(extra)})" if extra else ""
        lines.append(f"{index}. {item.title}{suffix}")
    return "\n".join(lines)


def _render_markdown(items: list[TaskRecord], *, title: str = "Actionable Tasks") -> str:
    if not items:
        return ""
    lines = [f"## {title}", ""]
    for item in items:
        lines.append(f"- [ ] {item.title}")
        lines.append(f"  task_id:: {item.task_id}")
        if item.due_at:
            rendered_due = item.due_at.strftime("%Y-%m-%d %H:%M") if item.due_at.hour or item.due_at.minute else item.due_at.strftime("%Y-%m-%d")
            lines.append(f"  due:: {rendered_due}")
        if item.recurrence_rule:
            lines.append(f"  recur:: {item.recurrence_rule}")
        if item.next_run_at:
            lines.append(f"  next_run_at:: {item.next_run_at.strftime('%Y-%m-%d %H:%M')}")
        if item.prompt_ref:
            lines.append(f"  prompt_ref:: {item.prompt_ref}")
        if item.priority != "medium":
            lines.append(f"  priority:: {item.priority}")
        if item.tags:
            lines.append(f"  tags:: {' '.join(item.tags)}")
        lines.append("")
    return "\n".join(lines).rstrip()


def _parse_task_input(raw: str) -> tuple[str, dict[str, str]]:
    items = parse_tasks_text(f"## Inbox\n- [ ] {raw}".strip())
    if not items:
        return raw.strip(), {}
    item = items[0]
    metadata = dict(item.metadata)
    if item.recur:
        metadata["recur"] = item.recur
    if item.due_at:
        metadata["due"] = item.due_at.isoformat(timespec="minutes")
    if item.tags:
        metadata["tags"] = " ".join(item.tags)
    if item.priority:
        metadata["priority"] = item.priority
    return item.text, metadata


def cmd_due(args: argparse.Namespace) -> int:
    root = _resolve_root(args.root)
    actor = _resolve_actor(args.agent)
    with TaskEngine(root) as engine:
        engine.bootstrap_actor(actor)
        actionable = engine.select_actionable(actor, limit=args.limit)
        if args.format == "heartbeat":
            text = engine.render_heartbeat_payload(actor, limit=args.limit)
        else:
            text = _render_markdown(actionable)
    if text:
        print(text)
    return 0


def cmd_render_vault(args: argparse.Namespace) -> int:
    root = _resolve_root(args.root)
    actor = _resolve_actor(args.agent)
    with TaskEngine(root) as engine:
        path = engine.cleanup_legacy_tasks_view(actor)
    print(f"Removed legacy vault tasks view for {actor} → {path}")
    return 0


def cmd_update(args: argparse.Namespace) -> int:
    root = _resolve_root(args.root)
    with TaskEngine(root) as engine:
        due_at = datetime.fromisoformat(args.due) if args.due else None
        tags = args.tags.split() if args.tags else None
        ok = engine.update_task(
            args.task_id,
            title=args.title,
            recurrence_rule=args.recur,
            prompt_ref=args.prompt_ref,
            due_at=due_at,
            priority=args.priority,
            tags=tags,
            notes=args.notes,
        )
    if ok:
        print(f"Updated task {args.task_id}")
        return 0
    print(f"Unknown task id: {args.task_id}")
    return 1


def cmd_complete(args: argparse.Namespace) -> int:
    with TaskEngine(_resolve_root(args.root)) as engine:
        ok = engine.complete_task(args.task_id, result=args.result)
    if ok:
        print(f"Completed {args.task_id}")
        return 0
    print(f"Unknown task id: {args.task_id}")
    return 1


def cmd_defer(args: argparse.Namespace) -> int:
    with TaskEngine(_resolve_root(args.root)) as engine:
        ok = engine.defer_task(args.task_id, reason=args.reason)
    if ok:
        print(f"Deferred {args.task_id}")
        return 0
    print(f"Unknown task id: {args.task_id}")
    return 1


def cmd_fail(args: argparse.Namespace) -> int:
    with TaskEngine(_resolve_root(args.root)) as engine:
        result = engine.fail_task(args.task_id, error=args.error or "")
    if result is None:
        print(f"Unknown task id: {args.task_id}")
        return 1
    payload = {
        "task_id": result.task_id,
        "assignee_id": result.assignee_id,
        "title": result.title,
        "failure_count": result.failure_count,
        "retry_after": result.retry_after.strftime("%Y-%m-%d %H:%M"),
        "last_error": result.last_error,
        "escalated": result.escalated,
        "escalation_task_id": result.escalation_task_id,
    }
    print(json.dumps(payload, ensure_ascii=False))
    return 0


def cmd_command(args: argparse.Namespace) -> int:
    root = _resolve_root(args.root)
    command = args.name
    actor = _resolve_actor(args.agent)
    raw = _read_raw_args(args.command_args)
    with TaskEngine(root) as engine:
        engine.bootstrap_actor(actor)

        if command == "todo-add":
            target_actor = actor
            text = raw
            if raw.startswith("@"):
                first, _, rest = raw.partition(" ")
                target_actor = first.lstrip("@").lower()
                text = rest.strip()
            if not text:
                print("Usage: /todo-add [@actor] <task text>")
                return 0
            title, metadata = _parse_task_input(text)
            due_at = datetime.fromisoformat(metadata["due"]) if metadata.get("due") else None
            recurrence_rule = metadata.get("recur")
            priority = metadata.get("priority", "medium")
            tags = metadata.get("tags", "").split() if metadata.get("tags") else []
            prompt_ref = metadata.get("prompt_ref") or metadata.get("prompt_file")
            repeat_from = metadata.get("repeat_from", "schedule")
            engine.create_task(
                assignee_id=target_actor,
                title=title,
                due_at=due_at,
                recurrence_rule=recurrence_rule,
                priority=priority,
                tags=tags,
                prompt_ref=prompt_ref,
                repeat_from=repeat_from,
                source="command:todo-add",
            )
            print(f"Added to {target_actor}: {title}")
            return 0

        open_items = [item for item in engine.list_tasks(actor) if item.status == "open"]

        if command == "todo-all":
            if raw:
                actor = _resolve_actor(raw)
                engine.bootstrap_actor(actor)
                open_items = [item for item in engine.list_tasks(actor) if item.status == "open"]
            print(_format_user_list(open_items, title=f"Open tasks for {actor}"))
            return 0

        if command == "todo-next":
            actionable = engine.select_actionable(actor, limit=1)
            print(_format_user_list(actionable, title=f"Next task for {actor}"))
            return 0

        if command == "todo-nexts":
            actionable = engine.select_actionable(actor, limit=5)
            print(_format_user_list(actionable, title=f"Next tasks for {actor}"))
            return 0

        if command == "todo-projets":
            tags = sorted({tag for item in open_items for tag in item.tags if tag.startswith("#project/") or tag.startswith("#projet/")})
            if not tags:
                print(f"No project tags for {actor}.")
                return 0
            print("Project tags:\n\n" + "\n".join(f"- {tag}" for tag in tags))
            return 0

        if command == "todo-projet":
            if not raw:
                print("Usage: /todo-projet <#project/tag>")
                return 0
            needle = raw if raw.startswith("#") else f"#project/{raw}"
            matches = [item for item in open_items if needle in item.tags]
            print(_format_user_list(matches, title=f"Tasks for {needle}"))
            return 0

        if command == "todo-goals":
            tags = sorted({tag for item in open_items for tag in item.tags if tag.startswith("#goal/") or tag.startswith("#objectif/")})
            if not tags:
                print(f"No goal tags for {actor}.")
                return 0
            print("Goal tags:\n\n" + "\n".join(f"- {tag}" for tag in tags))
            return 0

        if command == "todo-goal":
            if not raw:
                print("Usage: /todo-goal <#goal/tag>")
                return 0
            needle = raw if raw.startswith("#") else f"#goal/{raw}"
            matches = [item for item in open_items if needle in item.tags or needle.replace("#goal/", "#objectif/") in item.tags]
            print(_format_user_list(matches, title=f"Tasks for {needle}"))
            return 0

        if command == "todo-autres":
            matches = [
                item for item in open_items
                if not any(tag.startswith(("#project/", "#projet/", "#goal/", "#objectif/")) for tag in item.tags)
            ]
            print(_format_user_list(matches, title=f"Uncategorized tasks for {actor}"))
            return 0

        if command == "todo-migrer":
            print("`/todo-migrer` is deprecated in the structured task engine.")
            return 0

        if command == "2do":
            if not raw or raw == "help":
                print(
                    "Use /todo-add, /todo-all, /todo-next, /todo-nexts, /todo-projets, "
                    "/todo-projet, /todo-goals, /todo-goal, or /todo-autres."
                )
                return 0
            if raw.startswith("@"):
                first, _, rest = raw.partition(" ")
                if rest:
                    title, metadata = _parse_task_input(rest)
                    engine.create_task(
                        assignee_id=first.lstrip("@").lower(),
                        title=title,
                        due_at=datetime.fromisoformat(metadata["due"]) if metadata.get("due") else None,
                        recurrence_rule=metadata.get("recur"),
                        priority=metadata.get("priority", "medium"),
                        tags=metadata.get("tags", "").split() if metadata.get("tags") else [],
                        prompt_ref=metadata.get("prompt_ref") or metadata.get("prompt_file"),
                        repeat_from=metadata.get("repeat_from", "schedule"),
                        source="command:2do",
                    )
                    print(f"Added to {first}: {title}")
                    return 0
            title, metadata = _parse_task_input(raw)
            engine.create_task(
                assignee_id=actor,
                title=title,
                due_at=datetime.fromisoformat(metadata["due"]) if metadata.get("due") else None,
                recurrence_rule=metadata.get("recur"),
                priority=metadata.get("priority", "medium"),
                tags=metadata.get("tags", "").split() if metadata.get("tags") else [],
                prompt_ref=metadata.get("prompt_ref") or metadata.get("prompt_file"),
                repeat_from=metadata.get("repeat_from", "schedule"),
                source="command:2do",
            )
            print(f"Added to {actor}: {title}")
            return 0

    print(f"Unknown todo command: {command}")
    return 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="python -m agentforge.todo_cli")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    due_p = subparsers.add_parser("due", help="Print actionable tasks for heartbeat injection")
    due_p.add_argument("--root", default=None)
    due_p.add_argument("--agent", default=None)
    due_p.add_argument("--limit", type=int, default=8)
    due_p.add_argument("--format", choices=("markdown", "heartbeat"), default="markdown")
    due_p.set_defaults(func=cmd_due)

    render_p = subparsers.add_parser("render-vault", help="Remove the legacy vault tasks.md view for an agent")
    render_p.add_argument("--root", default=None)
    render_p.add_argument("--agent", default=None)
    render_p.set_defaults(func=cmd_render_vault)

    update_p = subparsers.add_parser("update", help="Update fields on an existing task and re-render the vault")
    update_p.add_argument("--root", default=None)
    update_p.add_argument("--task-id", required=True)
    update_p.add_argument("--title", default=None)
    update_p.add_argument("--recur", default=None)
    update_p.add_argument("--prompt-ref", default=None)
    update_p.add_argument("--due", default=None, help="ISO datetime e.g. 2026-04-20T09:00")
    update_p.add_argument("--priority", default=None, choices=["low", "medium", "high"])
    update_p.add_argument("--tags", default=None, help="Space-separated tags e.g. '#projet/dev #goal/ship'")
    update_p.add_argument("--notes", default=None)
    update_p.set_defaults(func=cmd_update)

    complete_p = subparsers.add_parser("complete", help="Mark a task complete in the structured task engine")
    complete_p.add_argument("--root", default=None)
    complete_p.add_argument("--task-id", required=True)
    complete_p.add_argument("--result", default="done")
    complete_p.set_defaults(func=cmd_complete)

    defer_p = subparsers.add_parser("defer", help="Defer a task after an agent skips it")
    defer_p.add_argument("--root", default=None)
    defer_p.add_argument("--task-id", required=True)
    defer_p.add_argument("--reason", default="skip")
    defer_p.set_defaults(func=cmd_defer)

    fail_p = subparsers.add_parser("fail", help="Record a failed task attempt with retry backoff")
    fail_p.add_argument("--root", default=None)
    fail_p.add_argument("--task-id", required=True)
    fail_p.add_argument("--error", default="")
    fail_p.set_defaults(func=cmd_fail)

    cmd_p = subparsers.add_parser("command", help="Run a todo command handler")
    cmd_p.add_argument("name")
    cmd_p.add_argument("command_args", nargs="*")
    cmd_p.add_argument("--root", default=None)
    cmd_p.add_argument("--agent", default=None)
    cmd_p.set_defaults(func=cmd_command)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
