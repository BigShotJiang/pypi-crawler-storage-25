"""Compatibility wrapper around the 2Do-backed task service."""

from __future__ import annotations

from pathlib import Path

from agentforge.task_service import TaskFailureResult, TaskRecord, TaskService


class TaskEngine:
    """Preserve the previous TaskEngine API while delegating to TaskService."""

    def __init__(self, root: Path) -> None:
        self.root = root
        self._service = TaskService(root)

    def close(self) -> None:
        return None

    def __enter__(self) -> "TaskEngine":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def ensure_actor(self, actor_id: str) -> tuple[str, str]:
        return self._service.ensure_actor(actor_id)

    def bootstrap_actor(self, actor_id: str) -> None:
        self._service.bootstrap_actor(actor_id)

    def create_task(self, **kwargs) -> str:
        return self._service.create_task(**kwargs)

    def list_tasks(self, actor_id: str, *, status: str | None = None) -> list[TaskRecord]:
        return self._service.list_tasks(actor_id, status=status)

    def select_actionable(self, actor_id: str, *, now=None, limit: int = 8) -> list[TaskRecord]:
        return self._service.select_actionable(actor_id, now=now, limit=limit)

    def render_heartbeat_payload(self, actor_id: str, *, now=None, limit: int = 8) -> str:
        return self._service.render_heartbeat_payload(actor_id, now=now, limit=limit)

    def complete_task(self, task_id: str, *, result: str = "done", completed_at=None) -> bool:
        return self._service.complete_task(task_id, result=result, completed_at=completed_at)

    def update_task(self, task_id: str, **kwargs) -> bool:
        return self._service.update_task(task_id, **kwargs)

    def defer_task(self, task_id: str, *, deferred_until=None, reason: str = "skip") -> bool:
        return self._service.defer_task(task_id, deferred_until=deferred_until, reason=reason)

    def fail_task(self, task_id: str, *, error: str = "", now=None) -> TaskFailureResult | None:
        return self._service.fail_task(task_id, error=error, now=now)

    def cleanup_legacy_tasks_view(self, actor_id: str) -> Path:
        return self._service.cleanup_legacy_tasks_view(actor_id)
