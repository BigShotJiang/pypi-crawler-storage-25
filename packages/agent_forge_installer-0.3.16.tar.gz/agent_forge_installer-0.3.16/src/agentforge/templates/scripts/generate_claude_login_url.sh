#!/usr/bin/env bash
set -euo pipefail

AGENTFORGE_ROOT="${AGENTFORGE_ROOT:?AGENTFORGE_ROOT is not set}"
AGENTFORGE_RUNTIME_ROOT="${AGENTFORGE_RUNTIME_ROOT:?AGENTFORGE_RUNTIME_ROOT is not set}"
CLAUDE_BIN="$AGENTFORGE_RUNTIME_ROOT/.local/bin/claude"

[ -x "$CLAUDE_BIN" ] || exit 1

TMP_LOG=$(mktemp)
cleanup() {
    rm -f "$TMP_LOG"
}
trap cleanup EXIT

cd "$AGENTFORGE_RUNTIME_ROOT"

timeout 8s script -q -c "$CLAUDE_BIN auth login --claudeai" "$TMP_LOG" >/dev/null 2>&1 || true

python3 - <<'PY' "$TMP_LOG"
import re
import sys

text = open(sys.argv[1], "r", encoding="utf-8", errors="ignore").read()
match = re.search(r"https://claude\.ai/oauth/authorize\?[^\s\r\n]+", text)
if match:
    print(match.group(0))
PY
