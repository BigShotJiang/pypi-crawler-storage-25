"""Store em memória por execution_id (Padrão A).

Objetivo: permitir inspecionar histórico de spans durante a execução.
Não faz IO externo.
"""

from threading import Lock
from typing import Any


class InMemorySpanStore:
    """
    Store de spans por `execution_id` apenas em memória.

    Uso:
    - Permite visualizar o histórico de eventos de uma execução antes de persistir.
    - Não faz IO externo.
    """
    def __init__(self) -> None:
        self._lock = Lock()
        self._by_execution: dict[str, list[dict[str, Any]]] = {}

    def append(self, event: dict[str, Any]) -> None:
        """
        Adiciona um evento ao store baseado no `execution_id` do próprio evento.
        """
        exec_id = event["execution_id"]
        with self._lock:
            self._by_execution.setdefault(exec_id, []).append(event)

    def get(self, execution_id: str) -> list[dict[str, Any]]:
        """
        Retorna uma cópia da lista de eventos associados ao `execution_id`.
        """
        with self._lock:
            return list(self._by_execution.get(execution_id, []))

    def clear(self, execution_id: str) -> None:
        """
        Remove todos os eventos de um `execution_id`.
        """
        with self._lock:
            self._by_execution.pop(execution_id, None)
