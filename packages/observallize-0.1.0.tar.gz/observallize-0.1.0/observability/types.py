from contextvars import ContextVar
from queue import SimpleQueue
from typing import Any, ParamSpec, TypeVar

P = ParamSpec("P")
R = TypeVar("R")
Context = ContextVar[str]
SPAN_QUEUE: SimpleQueue[dict[str, Any]] = SimpleQueue()
SPAN_CUSTOM: dict[str, dict[str, Any]] = {}
