"""Helpers de memória/RSS.

- rss() retorna RSS atual em bytes.
- to_mb converte bytes -> MB.
- sample_peak_rss_mb mede pico de RSS durante uma janela, via amostragem.

Obs: "pico do span" não é fornecido nativamente pelo SO de forma isolada.
O jeito mais confiável no MVP é amostrar enquanto o span roda.
"""

import time
from threading import Event

import psutil

_process = psutil.Process()


def rss_bytes() -> int:
    """
    Retorna o RSS (resident set size) atual do processo em bytes.
    """
    return _process.memory_info().rss


def to_mb(num_bytes: int) -> float:
    """
    Converte bytes em megabytes (MB).
    """
    return num_bytes / (1024 * 1024)


def sample_peak_rss_mb(*, interval_s: float = 0.05, stop_event: Event) -> float:
    """
    Amostra o RSS do processo periodicamente enquanto `stop_event` não é sinalizado
    e retorna o valor máximo observado, em MB.

    Parâmetros:
    - interval_s: período entre amostragens.
    - stop_event: evento de parada sinalizado por quem controla o ciclo do span.
    """
    peak = to_mb(rss_bytes())
    while not stop_event.is_set():
        time.sleep(interval_s)
        val = to_mb(rss_bytes())
        if val > peak:
            peak = val
    return peak
