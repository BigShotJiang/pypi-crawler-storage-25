import json
import time
import traceback
import uuid
from collections.abc import Callable
from contextvars import ContextVar
from dataclasses import asdict
from threading import Event
from typing import Any

import psutil

from .event_schema import SpanEvent
from .exporters import Exporter
from .memory import rss_bytes, sample_peak_rss_mb, to_mb
from .types import SPAN_CUSTOM, Context, P, R

execution_id_var: Context = ContextVar("execution_id", default="")
current_span_var: Context = ContextVar("current_span", default="")
exporter_var: ContextVar[Exporter | None] = ContextVar("exporter", default=None)

process = psutil.Process()


def set_execution_context(execution_id: str | None = None) -> str:
    """
    Define o contexto de execução atual (correlation_id) e o retorna.

    Parâmetros:
    - execution_id: opcional; se não fornecido, um UUID é gerado.
    """
    exec_id = execution_id or str(uuid.uuid4())
    execution_id_var.set(exec_id)
    return exec_id


def get_execution_id() -> str:
    """
    Retorna o `execution_id` atual do contexto (string vazia se não definido).
    """
    return execution_id_var.get()


def add_metric(key: str, value: Any) -> None:
    """
    Adiciona uma métrica customizada ao span atual.

    Requer um span ativo (isto é, estar dentro de uma função decorada por @observe).
    """
    span_id = current_span_var.get()
    if not span_id:
        return
    SPAN_CUSTOM.setdefault(span_id, {})[key] = value


def get_metrics(span_id: str) -> dict[str, Any]:
    return SPAN_CUSTOM.get(span_id, {})


def clear_metrics(span_id: str) -> None:
    SPAN_CUSTOM.pop(span_id, None)


def _safe_jsonable(obj: Any, max_len: int) -> Any:
    try:
        s = json.dumps(obj, default=repr, ensure_ascii=False)
        if len(s) > max_len:
            s = s[: max_len - 3] + "..."
        return json.loads(s)
    except Exception:
        r = repr(obj)
        if len(r) > max_len:
            r = r[: max_len - 3] + "..."
        return r


def observe(
    name: str | None = None,
    capture_io: bool = True,
    capture_result: bool = True,
    sanitize: bool = True,
    max_len: int = 2000,
    exporter: Exporter | None = None,
    capture_rss_peak: bool = True,
    rss_peak_interval_s: float = 0.05,
):
    """
    Decorator para observar a execução de uma função, produzindo um evento (span).

    Parâmetros:
    - name: nome lógico do span; por padrão usa o qualname da função.
    - capture_io: captura `args` e `kwargs`.
    - capture_result: captura o retorno da função.
    - sanitize: serializa/simplifica I/O e retorno, limitando seu tamanho.
    - max_len: limite de tamanho (caracteres) para serialização segura.
    - exporter: exporter específico para este span; se omitido, usa o de contexto.
    - capture_rss_peak: amostra pico de RSS durante o span.
    - rss_peak_interval_s: período de amostragem do pico de RSS.
    """

    def deco(fn: Callable[P, R]) -> Callable[P, R]:
        fn_qual = getattr(fn, "__qualname__", fn.__name__)
        fn_mod = getattr(fn, "__module__", "")
        fn_full = f"{fn_mod}.{fn_qual}" if fn_mod else fn_qual

        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            exec_id = execution_id_var.get() or set_execution_context()
            parent_span = current_span_var.get() or None
            span_id = str(uuid.uuid4())

            token = current_span_var.set(span_id)
            start_ts = time.time()
            t0 = time.perf_counter()

            rss_start = process.memory_info().rss
            peak_process = None

            stop_evt: Event | None = None
            peak_span_mb: float | None = None
            peak_thread = None
            if capture_rss_peak:
                stop_evt = Event()

                # roda em thread: amostra RSS e calcula pico em MB
                def _runner():
                    nonlocal peak_span_mb
                    peak_span_mb = sample_peak_rss_mb(
                        interval_s=rss_peak_interval_s, stop_event=stop_evt
                    )

                from threading import Thread

                peak_thread = Thread(target=_runner, daemon=True)
                peak_thread.start()

            evt = SpanEvent(
                execution_id=exec_id,
                span_id=span_id,
                parent_span_id=parent_span,
                name=name or fn_qual,
                function=fn_full,
                start_ts=start_ts,
                end_ts=start_ts,
                duration_ms=0.0,
                rss_start=rss_start,
                rss_peak_process=peak_process,
                rss_start_mb=to_mb(rss_start),
            )

            if capture_io:
                if sanitize:
                    evt.args = _safe_jsonable(args, max_len=max_len)
                    evt.kwargs = _safe_jsonable(kwargs, max_len=max_len)
                else:
                    evt.args = args
                    evt.kwargs = kwargs

            try:
                result = fn(*args, **kwargs)

                if capture_result:
                    evt.result = _safe_jsonable(result, max_len=max_len) if sanitize else result

                return result

            except Exception as e:
                evt.exception_type = type(e).__name__
                evt.message = str(e)
                evt.stacktrace = traceback.format_exc()
                raise

            finally:
                evt.end_ts = time.time()
                evt.duration_ms = (time.perf_counter() - t0) * 1000.0

                # encerra thread de pico (se habilitado)
                if stop_evt is not None:
                    stop_evt.set()
                    if peak_thread is not None:
                        peak_thread.join(timeout=1.0)
                    evt.rss_peak_span_mb = peak_span_mb

                rss_end = rss_bytes()
                evt.rss_end = rss_end
                evt.rss_delta = rss_end - (evt.rss_start or rss_end)
                evt.rss_end_mb = to_mb(rss_end)
                evt.rss_delta_mb = (
                    (evt.rss_end_mb - (evt.rss_start_mb or evt.rss_end_mb))
                    if evt.rss_end_mb is not None
                    else None
                )

                # métricas custom anexadas durante o span
                evt.custom = get_metrics(evt.span_id)
                clear_metrics(evt.span_id)

                exp = exporter if exporter is not None else exporter_var.get()
                if exp is not None:
                    exp.emit(asdict(evt))

                current_span_var.reset(token)

        return wrapper

    return deco
