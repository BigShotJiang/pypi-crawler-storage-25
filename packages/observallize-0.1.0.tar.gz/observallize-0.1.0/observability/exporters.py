"""Exporters (responsabilidade única): recebem dict e dão destino.

- Guarda no store (para debug/histórico durante execução)
- Enfileira para persistência/batch (para mandar ao banco)
"""

from typing import Any, Protocol

from .store import InMemorySpanStore
from .types import SPAN_QUEUE

SPAN_STORE = InMemorySpanStore()


class Exporter(Protocol):
    def emit(self, event: dict[str, Any]) -> None: ...


class StoreExporter:
    """
    Exporta eventos apenas para o store em memória.

    Uso:
    - Útil para inspeção local durante a execução, sem IO externo.
    """
    def emit(self, event: dict[str, Any]) -> None:
        SPAN_STORE.append(event)


class QueueExporter:
    """
    Exporta eventos apenas para a fila (queue) em memória.

    Uso:
    - Útil quando você fará um flush em batch para o banco/endpoint via `flush_to_db`.
    """
    def emit(self, event: dict[str, Any]) -> None:
        SPAN_QUEUE.put(event)


class StoreAndQueueExporter:
    """
    Exporta eventos para store e/ou fila.

    Parâmetros:
    - also_store: se True, envia o evento para o store em memória (inspeção por execution_id).
    - also_queue: se True, enfileira o evento para posterior flush/batch.

    Observação:
    - Quando for persistir usando `obs.to_rows(...); insert_batch(rows)`, prefira
    `also_queue=False` para evitar produzir eventos na fila que não serão drenados.
    """
    def __init__(self, *, also_store: bool = True, also_queue: bool = True) -> None:
        self.also_store = also_store
        self.also_queue = also_queue

    def emit(self, event: dict[str, Any]) -> None:
        if self.also_store:
            SPAN_STORE.append(event)
        if self.also_queue:
            SPAN_QUEUE.put(event)
