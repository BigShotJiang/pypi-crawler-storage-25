import random
import time
from collections.abc import Callable
from typing import Any, ParamSpec, TypeVar

P = ParamSpec("P")
R = TypeVar("R")


def retry(
    attempts: int = 3,
    *,
    exceptions: type[BaseException] | tuple[type[BaseException], ...] = Exception,
    delay_s: float = 0.0,
    backoff: float = 1.0,
    max_delay_s: float | None = None,
    jitter_s: float = 0.0,
    log: Any | None = None,
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """
    Decorator de retentativa com backoff exponencial e jitter opcional.

    Parâmetros:
    - attempts: número total de tentativas (>=1).
    - exceptions: exceção(ões) que disparam a retentativa.
    - delay_s: atraso inicial entre tentativas (segundos).
    - backoff: multiplicador do atraso a cada falha subsequente (>=1).
    - max_delay_s: teto para o atraso calculado (opcional).
    - jitter_s: ruído aleatório [0..jitter_s] somado ao atraso (opcional).
    - log: logger com `.warning(str)` ou callable(str) para registrar as falhas.

    Comportamento:
    - Em caso de exceção prevista, loga (se fornecido), aguarda e reexecuta
    até `attempts`. Na última falha, propaga a exceção.
    """
    if attempts < 1:
        raise ValueError("attempts must be >= 1")
    if delay_s < 0:
        raise ValueError("delay_s must be >= 0")
    if backoff < 1:
        raise ValueError("backoff must be >= 1")
    if jitter_s < 0:
        raise ValueError("jitter_s must be >= 0")
    if max_delay_s is not None and max_delay_s < 0:
        raise ValueError("max_delay_s must be >= 0")

    def _log(msg: str) -> None:
        if log is None:
            return
        if hasattr(log, "warning") and callable(getattr(log, "warning")):
            log.warning(msg)
            return
        if callable(log):
            log(msg)
            return

    def deco(fn: Callable[P, R]) -> Callable[P, R]:
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            current_delay = delay_s
            for i in range(1, attempts + 1):
                try:
                    return fn(*args, **kwargs)
                except exceptions as e:
                    if i >= attempts:
                        raise
                    sleep_for = current_delay
                    if jitter_s:
                        sleep_for += random.uniform(0, jitter_s)
                    if max_delay_s is not None:
                        sleep_for = min(sleep_for, max_delay_s)
                    fn_name = getattr(fn, "__qualname__", fn.__name__)
                    _log(
                        f"retry: attempt={i}/{attempts} fn={fn_name} error={type(e).__name__}: {e}"
                    )
                    if sleep_for > 0:
                        time.sleep(sleep_for)
                    current_delay *= backoff
            raise RuntimeError("unreachable")

        return wrapper

    return deco
