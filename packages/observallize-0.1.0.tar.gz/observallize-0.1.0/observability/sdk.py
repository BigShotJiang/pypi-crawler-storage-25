from collections.abc import Callable, Iterator
from contextlib import contextmanager
from typing import Any

from .exporters import SPAN_STORE, Exporter, StoreAndQueueExporter
from .flusher import flush_to_db
from .observability import add_metric, exporter_var, get_execution_id, observe, set_execution_context
from .parser import events_to_json, events_to_rows


class Observability:
    """
    Fachada para as capacidades de observabilidade.

    Objetivos:
    - Reduzir a quantidade de imports espalhados.
    - Padronizar o uso em Controllers/Services.
    - Expor helpers de contexto, decorator, store, flush e transformação.
    """

    def set_execution_context(self, execution_id: str | None = None) -> str:
        """
        Define o `execution_id` (correlation_id) do contexto atual.
        Retorna o id definido.
        """
        return set_execution_context(execution_id)

    def get_execution_id(self) -> str:
        """
        Retorna o `execution_id` atual do contexto (string vazia se não definido).
        """
        return get_execution_id()

    def add_metric(self, key: str, value: Any) -> None:
        """
        Anexa uma métrica customizada ao span atual.
        """
        add_metric(key, value)

    def observe(
        self,
        *,
        name: str | None = None,
        capture_io: bool = True,
        capture_result: bool = True,
        sanitize: bool = True,
        max_len: int = 2000,
        exporter: Exporter | None = None,
        capture_rss_peak: bool = True,
        rss_peak_interval_s: float = 0.05,
    ):
        """
        Retorna o decorator de observação de spans.

        Parâmetros seguem `observability.observe`.
        """
        return observe(
            name=name,
            capture_io=capture_io,
            capture_result=capture_result,
            sanitize=sanitize,
            max_len=max_len,
            exporter=exporter,
            capture_rss_peak=capture_rss_peak,
            rss_peak_interval_s=rss_peak_interval_s,
        )

    def create_exporter(
        self, *, also_store: bool = True, also_queue: bool = True
    ) -> StoreAndQueueExporter:
        """
        Cria um exporter configurado para armazenar em memória e/ou enfileirar.
        """
        return StoreAndQueueExporter(also_store=also_store, also_queue=also_queue)

    @property
    def span_store(self):
        """
        Acesso ao store em memória, indexado por `execution_id`.
        """
        return SPAN_STORE

    def flush(
        self,
        insert_batch: Callable[[list[dict[str, Any]]], None],
        *,
        max_items: int = 1000,
    ) -> int:
        """
        Drena a fila de eventos e chama `insert_batch` com o lote.
        """
        return flush_to_db(insert_batch, max_items=max_items)

    def to_rows(
        self,
        events: list[dict[str, Any]],
        *,
        include_io: bool = True,
        include_result: bool = True,
        custom_prefix: str = "custom__",
        round_rss_mb: int | None = 2,
    ) -> list[dict[str, Any]]:
        """
        Converte eventos em linhas normalizadas (ideal para pandas/ORMs).
        """
        return events_to_rows(
            events,
            include_io=include_io,
            include_result=include_result,
            custom_prefix=custom_prefix,
            round_rss_mb=round_rss_mb,
        )

    def to_json(
        self,
        events: list[dict[str, Any]],
        *,
        include_io: bool = True,
        include_result: bool = True,
        indent: int = 2,
        ensure_ascii: bool = False,
        sort_keys: bool = True,
        datetime_format: str = "%d/%m/%Y %H:%M:%S",
    ) -> str:
        """
        Serializa eventos como JSON identado para inspeção durante desenvolvimento.
        """
        return events_to_json(
            events,
            include_io=include_io,
            include_result=include_result,
            indent=indent,
            ensure_ascii=ensure_ascii,
            sort_keys=sort_keys,
            datetime_format=datetime_format,
        )

    @contextmanager
    def use_exporter(self, exporter: Exporter) -> Iterator[None]:
        """
        Define o exporter atual apenas durante o bloco `with`, via ContextVar.

        Garante isolamento por execução e spans aninhados herdarem o mesmo exporter.
        """
        token = exporter_var.set(exporter)
        try:
            yield
        finally:
            exporter_var.reset(token)


obs = Observability()
