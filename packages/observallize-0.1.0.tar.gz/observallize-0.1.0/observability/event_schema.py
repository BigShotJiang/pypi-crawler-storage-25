"""Schema do evento (Span) capturado pelo decorator.

Mantém apenas dados + tipos (responsabilidade única).
"""

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class SpanEvent:
    execution_id: str
    span_id: str
    parent_span_id: str | None
    name: str
    function: str
    start_ts: float
    end_ts: float
    duration_ms: float

    rss_start: int | None = None
    rss_end: int | None = None
    rss_delta: int | None = None
    rss_peak_process: int | None = None
    rss_start_mb: float | None = None
    rss_end_mb: float | None = None
    rss_delta_mb: float | None = None
    rss_peak_span_mb: float | None = None

    args: Any | None = None
    kwargs: Any | None = None
    result: Any | None = None

    exception_type: str | None = None
    message: str | None = None
    stacktrace: str | None = None
    custom: dict[str, Any] | None = None
