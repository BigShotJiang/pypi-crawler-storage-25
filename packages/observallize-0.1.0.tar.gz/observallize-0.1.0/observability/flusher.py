"""Flush da fila para o banco (responsabilidade única).

Você pluga o seu insert real em `insert_batch`.
"""

from collections.abc import Callable

from .types import SPAN_QUEUE, Any


def flush_to_db(
    insert_batch: Callable[[list[dict[str, Any]]], None], *, max_items: int = 1000
) -> int:
    """
    Drena a fila de eventos (`SPAN_QUEUE`) e envia para `insert_batch` em lote.

    Parâmetros:
    - insert_batch: callable que recebe list[dict[str, Any]] para persistência real.
    - max_items: número máximo de eventos drenados por chamada.

    Retorno:
    - int: quantidade de eventos enviados ao `insert_batch`.

    Observação:
    - Use quando o exporter em uso estiver com `also_queue=True`.
    """
    batch: list[dict[str, Any]] = []
    while len(batch) < max_items and not SPAN_QUEUE.empty():
        batch.append(SPAN_QUEUE.get())

    if batch:
        insert_batch(batch)
    return len(batch)
