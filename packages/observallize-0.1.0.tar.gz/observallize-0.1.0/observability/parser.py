"""Parser para transformar eventos em list[dict] pronto para pandas/SQLAlchemy.

Regras típicas:
- Converte RSS (bytes -> MB)
- "Achata" custom metrics em colunas (prefixo custom__)
- Remove chaves muito grandes se quiser (args/result)
"""

import json
from datetime import datetime, timedelta
from typing import Any


def events_to_rows(
    events: list[dict[str, Any]],
    *,
    include_io: bool = True,
    include_result: bool = True,
    custom_prefix: str = "custom__",
    round_rss_mb: int | None = 2,
) -> list[dict[str, Any]]:
    """
    Transforma eventos de spans em linhas para pandas/ORM.

    Parâmetros:
    - events: lista de eventos (dicts) capturados pelo decorator.
    - include_io: se False, remove `args` e `kwargs`.
    - include_result: se False, remove `result`.
    - custom_prefix: prefixo para colunas derivadas de `custom` (ex.: custom__chave).
    - round_rss_mb: casas decimais para campos *_mb; se None, não arredonda.

    Conversões:
    - start_ts/end_ts: float/epoch -> datetime local (sem tz).
    - duration_ms: float -> timedelta.
    - rss_*_mb: arredondados conforme `round_rss_mb`.
    """
    rows: list[dict[str, Any]] = []
    for e in events:
        row = dict(e)

        start_ts = row.get("start_ts")
        if isinstance(start_ts, (int, float)):
            row["start_ts"] = datetime.fromtimestamp(float(start_ts))
        end_ts = row.get("end_ts")
        if isinstance(end_ts, (int, float)):
            row["end_ts"] = datetime.fromtimestamp(float(end_ts))
        duration_ms = row.get("duration_ms")
        if isinstance(duration_ms, (int, float)):
            row["duration_ms"] = timedelta(milliseconds=float(duration_ms))

        if round_rss_mb is not None:
            for k in (
                "rss_start_mb",
                "rss_end_mb",
                "rss_delta_mb",
                "rss_peak_span_mb",
            ):
                v = row.get(k)
                if isinstance(v, (int, float)):
                    row[k] = round(float(v), round_rss_mb)

        custom = row.pop("custom", None) or {}
        for k, v in custom.items():
            row[f"{custom_prefix}{k}"] = v

        if not include_io:
            row.pop("args", None)
            row.pop("kwargs", None)
        if not include_result:
            row.pop("result", None)

        rows.append(row)
    return rows


def events_to_json(
    events: list[dict[str, Any]],
    *,
    include_io: bool = True,
    include_result: bool = True,
    indent: int = 2,
    ensure_ascii: bool = False,
    sort_keys: bool = True,
    datetime_format: str = "%d/%m/%Y %H:%M:%S",
) -> str:
    """
    Serializa eventos como JSON identado para inspeção durante desenvolvimento.

    Parâmetros:
    - events: lista de eventos (dicts) capturados pelo decorator.
    - include_io: se False, remove `args` e `kwargs`.
    - include_result: se False, remove `result`.
    - indent: nível de indentação do JSON.
    - ensure_ascii: se True, escapa caracteres não-ASCII.
    - sort_keys: se True, ordena as chaves no output.
    - datetime_format: formato para start_ts/end_ts (ex.: "%d/%m/%Y %H:%M:%S" ou "%Y/%m/%d %H:%M:%S").

    Conversões:
    - start_ts/end_ts: float/epoch -> string no formato configurado.
    - datetime -> string no formato configurado.
    - timedelta -> total de milissegundos (float).
    """

    def _normalize_value(v: Any) -> Any:
        if isinstance(v, datetime):
            return v.strftime(datetime_format)
        if isinstance(v, timedelta):
            return v.total_seconds() * 1000.0
        if isinstance(v, (list, tuple)):
            return [_normalize_value(x) for x in v]
        if isinstance(v, dict):
            return {str(k): _normalize_value(val) for k, val in v.items()}
        try:
            json.dumps(v, ensure_ascii=ensure_ascii)
            return v
        except Exception:
            return repr(v)

    normalized: list[dict[str, Any]] = []
    for e in events:
        ev = dict(e)

        if not include_io:
            ev.pop("args", None)
            ev.pop("kwargs", None)
        if not include_result:
            ev.pop("result", None)

        for ts_key in ("start_ts", "end_ts"):
            ts_val = ev.get(ts_key)
            if isinstance(ts_val, (int, float)):
                ev[ts_key] = datetime.fromtimestamp(float(ts_val)).strftime(datetime_format)

        normalized.append(_normalize_value(ev))

    return json.dumps(
        normalized,
        indent=indent,
        ensure_ascii=ensure_ascii,
        sort_keys=sort_keys,
    )
