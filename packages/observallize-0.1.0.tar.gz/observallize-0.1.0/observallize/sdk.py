from observability.sdk import Observability, obs

__all__ = ["Observability", "obs"]
