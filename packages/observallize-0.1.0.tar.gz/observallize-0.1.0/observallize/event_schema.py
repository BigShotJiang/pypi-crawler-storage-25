from observability.event_schema import SpanEvent

__all__ = ["SpanEvent"]
