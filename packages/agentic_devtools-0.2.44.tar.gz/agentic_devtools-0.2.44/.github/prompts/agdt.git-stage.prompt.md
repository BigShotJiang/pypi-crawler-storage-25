---
agent: agdt.git-stage
---
