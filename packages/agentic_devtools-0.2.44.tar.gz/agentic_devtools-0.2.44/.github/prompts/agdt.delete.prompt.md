---
agent: agdt.delete
---
