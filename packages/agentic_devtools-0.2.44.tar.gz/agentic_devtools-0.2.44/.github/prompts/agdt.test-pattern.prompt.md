---
agent: agdt.test-pattern
---
