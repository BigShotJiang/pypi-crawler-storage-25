---
agent: agdt.resolve-thread
---
