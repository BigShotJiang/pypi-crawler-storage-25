from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from v4_proto.cosmos_proto import cosmos_pb2 as _cosmos_pb2
from v4_proto.cosmos.base.v1beta1 import coin_pb2 as _coin_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BridgeEvent(_message.Message):
    __slots__ = ("id", "coin", "address", "eth_block_height", "eth_token_address", "eth_chain_id", "log_index", "chain_block_height")
    ID_FIELD_NUMBER: _ClassVar[int]
    COIN_FIELD_NUMBER: _ClassVar[int]
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    ETH_BLOCK_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    ETH_TOKEN_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    LOG_INDEX_FIELD_NUMBER: _ClassVar[int]
    CHAIN_BLOCK_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    id: int
    coin: _coin_pb2.Coin
    address: str
    eth_block_height: int
    eth_token_address: str
    eth_chain_id: int
    log_index: int
    chain_block_height: int
    def __init__(self, id: _Optional[int] = ..., coin: _Optional[_Union[_coin_pb2.Coin, _Mapping]] = ..., address: _Optional[str] = ..., eth_block_height: _Optional[int] = ..., eth_token_address: _Optional[str] = ..., eth_chain_id: _Optional[int] = ..., log_index: _Optional[int] = ..., chain_block_height: _Optional[int] = ...) -> None: ...

class FinalityConfirmation(_message.Message):
    __slots__ = ("event_id", "eth_chain_id")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    event_id: int
    eth_chain_id: int
    def __init__(self, event_id: _Optional[int] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class PendingFinalityEvent(_message.Message):
    __slots__ = ("event", "acknowledged_at_block")
    EVENT_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGED_AT_BLOCK_FIELD_NUMBER: _ClassVar[int]
    event: BridgeEvent
    acknowledged_at_block: int
    def __init__(self, event: _Optional[_Union[BridgeEvent, _Mapping]] = ..., acknowledged_at_block: _Optional[int] = ...) -> None: ...

class WithdrawalConfirmationEvent(_message.Message):
    __slots__ = ("event_id", "withdrawal_id", "eth_chain_id", "eth_block_height", "sender", "coin", "eth_token_address", "log_index", "chain_block_height")
    EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_BLOCK_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    SENDER_FIELD_NUMBER: _ClassVar[int]
    COIN_FIELD_NUMBER: _ClassVar[int]
    ETH_TOKEN_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    LOG_INDEX_FIELD_NUMBER: _ClassVar[int]
    CHAIN_BLOCK_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    event_id: int
    withdrawal_id: int
    eth_chain_id: int
    eth_block_height: int
    sender: str
    coin: _coin_pb2.Coin
    eth_token_address: str
    log_index: int
    chain_block_height: int
    def __init__(self, event_id: _Optional[int] = ..., withdrawal_id: _Optional[int] = ..., eth_chain_id: _Optional[int] = ..., eth_block_height: _Optional[int] = ..., sender: _Optional[str] = ..., coin: _Optional[_Union[_coin_pb2.Coin, _Mapping]] = ..., eth_token_address: _Optional[str] = ..., log_index: _Optional[int] = ..., chain_block_height: _Optional[int] = ...) -> None: ...

class WithdrawalConfirmationInfo(_message.Message):
    __slots__ = ("next_event_id", "eth_block_height")
    NEXT_EVENT_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_BLOCK_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    next_event_id: int
    eth_block_height: int
    def __init__(self, next_event_id: _Optional[int] = ..., eth_block_height: _Optional[int] = ...) -> None: ...

class ChainWithdrawalConfirmationInfo(_message.Message):
    __slots__ = ("chain_id", "info")
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    INFO_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    info: WithdrawalConfirmationInfo
    def __init__(self, chain_id: _Optional[int] = ..., info: _Optional[_Union[WithdrawalConfirmationInfo, _Mapping]] = ...) -> None: ...

class BridgeOperation(_message.Message):
    __slots__ = ("deposit", "withdrawal_confirmation")
    DEPOSIT_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_CONFIRMATION_FIELD_NUMBER: _ClassVar[int]
    deposit: DepositOperation
    withdrawal_confirmation: WithdrawalConfirmationEvent
    def __init__(self, deposit: _Optional[_Union[DepositOperation, _Mapping]] = ..., withdrawal_confirmation: _Optional[_Union[WithdrawalConfirmationEvent, _Mapping]] = ...) -> None: ...

class DepositOperation(_message.Message):
    __slots__ = ("event", "is_finalized")
    EVENT_FIELD_NUMBER: _ClassVar[int]
    IS_FINALIZED_FIELD_NUMBER: _ClassVar[int]
    event: BridgeEvent
    is_finalized: bool
    def __init__(self, event: _Optional[_Union[BridgeEvent, _Mapping]] = ..., is_finalized: bool = ...) -> None: ...
