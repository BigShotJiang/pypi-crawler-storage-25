from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from v4_proto.ritbit.bridge import bridge_event_pb2 as _bridge_event_pb2
from v4_proto.ritbit.bridge import bridge_event_info_pb2 as _bridge_event_info_pb2
from v4_proto.ritbit.bridge import params_pb2 as _params_pb2
from v4_proto.ritbit.bridge import withdrawal_pb2 as _withdrawal_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class GenesisState(_message.Message):
    __slots__ = ("event_params", "propose_params", "safety_params", "acknowledged_event_infos", "withdrawal_params", "chain_withdrawal_states", "withdrawal_daily_usage", "withdrawal_confirmation_infos")
    EVENT_PARAMS_FIELD_NUMBER: _ClassVar[int]
    PROPOSE_PARAMS_FIELD_NUMBER: _ClassVar[int]
    SAFETY_PARAMS_FIELD_NUMBER: _ClassVar[int]
    ACKNOWLEDGED_EVENT_INFOS_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_PARAMS_FIELD_NUMBER: _ClassVar[int]
    CHAIN_WITHDRAWAL_STATES_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_DAILY_USAGE_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_CONFIRMATION_INFOS_FIELD_NUMBER: _ClassVar[int]
    event_params: _params_pb2.EventParams
    propose_params: _params_pb2.ProposeParams
    safety_params: _params_pb2.SafetyParams
    acknowledged_event_infos: _containers.RepeatedCompositeFieldContainer[_bridge_event_info_pb2.ChainBridgeEventInfo]
    withdrawal_params: _withdrawal_pb2.WithdrawalParams
    chain_withdrawal_states: _containers.RepeatedCompositeFieldContainer[_withdrawal_pb2.ChainWithdrawalState]
    withdrawal_daily_usage: _containers.RepeatedCompositeFieldContainer[_withdrawal_pb2.AssetChainWithdrawalDailyUsage]
    withdrawal_confirmation_infos: _containers.RepeatedCompositeFieldContainer[_bridge_event_pb2.ChainWithdrawalConfirmationInfo]
    def __init__(self, event_params: _Optional[_Union[_params_pb2.EventParams, _Mapping]] = ..., propose_params: _Optional[_Union[_params_pb2.ProposeParams, _Mapping]] = ..., safety_params: _Optional[_Union[_params_pb2.SafetyParams, _Mapping]] = ..., acknowledged_event_infos: _Optional[_Iterable[_Union[_bridge_event_info_pb2.ChainBridgeEventInfo, _Mapping]]] = ..., withdrawal_params: _Optional[_Union[_withdrawal_pb2.WithdrawalParams, _Mapping]] = ..., chain_withdrawal_states: _Optional[_Iterable[_Union[_withdrawal_pb2.ChainWithdrawalState, _Mapping]]] = ..., withdrawal_daily_usage: _Optional[_Iterable[_Union[_withdrawal_pb2.AssetChainWithdrawalDailyUsage, _Mapping]]] = ..., withdrawal_confirmation_infos: _Optional[_Iterable[_Union[_bridge_event_pb2.ChainWithdrawalConfirmationInfo, _Mapping]]] = ...) -> None: ...
