from v4_proto.cosmos_proto import cosmos_pb2 as _cosmos_pb2
from v4_proto.cosmos.msg.v1 import msg_pb2 as _msg_pb2
from v4_proto.cosmos.base.v1beta1 import coin_pb2 as _coin_pb2
from v4_proto.ritbit.bridge import bridge_event_pb2 as _bridge_event_pb2
from v4_proto.ritbit.bridge import params_pb2 as _params_pb2
from v4_proto.ritbit.bridge import withdrawal_pb2 as _withdrawal_pb2
from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MsgAcknowledgeBridges(_message.Message):
    __slots__ = ("operations", "confirmations")
    OPERATIONS_FIELD_NUMBER: _ClassVar[int]
    CONFIRMATIONS_FIELD_NUMBER: _ClassVar[int]
    operations: _containers.RepeatedCompositeFieldContainer[_bridge_event_pb2.BridgeOperation]
    confirmations: _containers.RepeatedCompositeFieldContainer[_bridge_event_pb2.FinalityConfirmation]
    def __init__(self, operations: _Optional[_Iterable[_Union[_bridge_event_pb2.BridgeOperation, _Mapping]]] = ..., confirmations: _Optional[_Iterable[_Union[_bridge_event_pb2.FinalityConfirmation, _Mapping]]] = ...) -> None: ...

class MsgAcknowledgeBridgesResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgCompleteBridge(_message.Message):
    __slots__ = ("authority", "event")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    EVENT_FIELD_NUMBER: _ClassVar[int]
    authority: str
    event: _bridge_event_pb2.BridgeEvent
    def __init__(self, authority: _Optional[str] = ..., event: _Optional[_Union[_bridge_event_pb2.BridgeEvent, _Mapping]] = ...) -> None: ...

class MsgCompleteBridgeResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgUpdateEventParams(_message.Message):
    __slots__ = ("authority", "params")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    authority: str
    params: _params_pb2.EventParams
    def __init__(self, authority: _Optional[str] = ..., params: _Optional[_Union[_params_pb2.EventParams, _Mapping]] = ...) -> None: ...

class MsgUpdateEventParamsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgUpdateChainEventParams(_message.Message):
    __slots__ = ("authority", "chain_config")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    CHAIN_CONFIG_FIELD_NUMBER: _ClassVar[int]
    authority: str
    chain_config: _params_pb2.ChainConfig
    def __init__(self, authority: _Optional[str] = ..., chain_config: _Optional[_Union[_params_pb2.ChainConfig, _Mapping]] = ...) -> None: ...

class MsgUpdateChainEventParamsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgUpdateProposeParams(_message.Message):
    __slots__ = ("authority", "params")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    authority: str
    params: _params_pb2.ProposeParams
    def __init__(self, authority: _Optional[str] = ..., params: _Optional[_Union[_params_pb2.ProposeParams, _Mapping]] = ...) -> None: ...

class MsgUpdateProposeParamsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgUpdateSafetyParams(_message.Message):
    __slots__ = ("authority", "params")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    authority: str
    params: _params_pb2.SafetyParams
    def __init__(self, authority: _Optional[str] = ..., params: _Optional[_Union[_params_pb2.SafetyParams, _Mapping]] = ...) -> None: ...

class MsgUpdateSafetyParamsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgWithdrawal(_message.Message):
    __slots__ = ("sender", "amount", "eth_recipient", "eth_chain_id", "asset_id")
    SENDER_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    ETH_RECIPIENT_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    sender: str
    amount: str
    eth_recipient: str
    eth_chain_id: int
    asset_id: int
    def __init__(self, sender: _Optional[str] = ..., amount: _Optional[str] = ..., eth_recipient: _Optional[str] = ..., eth_chain_id: _Optional[int] = ..., asset_id: _Optional[int] = ...) -> None: ...

class MsgWithdrawalResponse(_message.Message):
    __slots__ = ("withdrawal_id", "status", "timelock_blocks")
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    TIMELOCK_BLOCKS_FIELD_NUMBER: _ClassVar[int]
    withdrawal_id: int
    status: _withdrawal_pb2.WithdrawalStatus
    timelock_blocks: int
    def __init__(self, withdrawal_id: _Optional[int] = ..., status: _Optional[_Union[_withdrawal_pb2.WithdrawalStatus, str]] = ..., timelock_blocks: _Optional[int] = ...) -> None: ...

class MsgUpdateWithdrawalParams(_message.Message):
    __slots__ = ("authority", "params")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    authority: str
    params: _withdrawal_pb2.WithdrawalParams
    def __init__(self, authority: _Optional[str] = ..., params: _Optional[_Union[_withdrawal_pb2.WithdrawalParams, _Mapping]] = ...) -> None: ...

class MsgUpdateWithdrawalParamsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgRegisterValidatorEvmAddress(_message.Message):
    __slots__ = ("authority", "validator_address", "evm_address")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    VALIDATOR_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    EVM_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    authority: str
    validator_address: str
    evm_address: str
    def __init__(self, authority: _Optional[str] = ..., validator_address: _Optional[str] = ..., evm_address: _Optional[str] = ...) -> None: ...

class MsgRegisterValidatorEvmAddressResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgUnregisterValidatorEvmAddress(_message.Message):
    __slots__ = ("authority", "validator_address")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    VALIDATOR_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    authority: str
    validator_address: str
    def __init__(self, authority: _Optional[str] = ..., validator_address: _Optional[str] = ...) -> None: ...

class MsgUnregisterValidatorEvmAddressResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgSubmitWithdrawalSignatures(_message.Message):
    __slots__ = ("signatures", "executions")
    SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    EXECUTIONS_FIELD_NUMBER: _ClassVar[int]
    signatures: _containers.RepeatedCompositeFieldContainer[WithdrawalSignatureEntry]
    executions: _containers.RepeatedCompositeFieldContainer[WithdrawalExecutionEntry]
    def __init__(self, signatures: _Optional[_Iterable[_Union[WithdrawalSignatureEntry, _Mapping]]] = ..., executions: _Optional[_Iterable[_Union[WithdrawalExecutionEntry, _Mapping]]] = ...) -> None: ...

class MsgSubmitWithdrawalSignaturesResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class WithdrawalSignatureEntry(_message.Message):
    __slots__ = ("validator_address", "withdrawal_id", "eth_signature", "eth_chain_id")
    VALIDATOR_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_SIGNATURE_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    validator_address: str
    withdrawal_id: int
    eth_signature: bytes
    eth_chain_id: int
    def __init__(self, validator_address: _Optional[str] = ..., withdrawal_id: _Optional[int] = ..., eth_signature: _Optional[bytes] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class WithdrawalExecutionEntry(_message.Message):
    __slots__ = ("validator_address", "withdrawal_id", "success", "eth_tx_hash", "eth_chain_id", "validator_eth_address")
    VALIDATOR_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ETH_TX_HASH_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    VALIDATOR_ETH_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    validator_address: str
    withdrawal_id: int
    success: bool
    eth_tx_hash: str
    eth_chain_id: int
    validator_eth_address: str
    def __init__(self, validator_address: _Optional[str] = ..., withdrawal_id: _Optional[int] = ..., success: bool = ..., eth_tx_hash: _Optional[str] = ..., eth_chain_id: _Optional[int] = ..., validator_eth_address: _Optional[str] = ...) -> None: ...

class MsgActivateWithdrawal(_message.Message):
    __slots__ = ("authority", "withdrawal_id", "eth_chain_id")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    authority: str
    withdrawal_id: int
    eth_chain_id: int
    def __init__(self, authority: _Optional[str] = ..., withdrawal_id: _Optional[int] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class MsgActivateWithdrawalResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgWithdrawalSigningTimeout(_message.Message):
    __slots__ = ("authority", "withdrawal_id", "eth_chain_id")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    authority: str
    withdrawal_id: int
    eth_chain_id: int
    def __init__(self, authority: _Optional[str] = ..., withdrawal_id: _Optional[int] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class MsgWithdrawalSigningTimeoutResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgWithdrawalRelayTimeout(_message.Message):
    __slots__ = ("authority", "withdrawal_id", "eth_chain_id")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    authority: str
    withdrawal_id: int
    eth_chain_id: int
    def __init__(self, authority: _Optional[str] = ..., withdrawal_id: _Optional[int] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class MsgWithdrawalRelayTimeoutResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgCompleteWithdrawalRecovery(_message.Message):
    __slots__ = ("authority", "event")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    EVENT_FIELD_NUMBER: _ClassVar[int]
    authority: str
    event: _bridge_event_pb2.WithdrawalConfirmationEvent
    def __init__(self, authority: _Optional[str] = ..., event: _Optional[_Union[_bridge_event_pb2.WithdrawalConfirmationEvent, _Mapping]] = ...) -> None: ...

class MsgCompleteWithdrawalRecoveryResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class TokenWithdrawalFeeUpdate(_message.Message):
    __slots__ = ("chain_id", "asset_id", "fee")
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    FEE_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    asset_id: int
    fee: _containers.RepeatedCompositeFieldContainer[_coin_pb2.Coin]
    def __init__(self, chain_id: _Optional[int] = ..., asset_id: _Optional[int] = ..., fee: _Optional[_Iterable[_Union[_coin_pb2.Coin, _Mapping]]] = ...) -> None: ...

class MsgUpdateTokenWithdrawalFees(_message.Message):
    __slots__ = ("authority", "updates")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    UPDATES_FIELD_NUMBER: _ClassVar[int]
    authority: str
    updates: _containers.RepeatedCompositeFieldContainer[TokenWithdrawalFeeUpdate]
    def __init__(self, authority: _Optional[str] = ..., updates: _Optional[_Iterable[_Union[TokenWithdrawalFeeUpdate, _Mapping]]] = ...) -> None: ...

class MsgUpdateTokenWithdrawalFeesResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
