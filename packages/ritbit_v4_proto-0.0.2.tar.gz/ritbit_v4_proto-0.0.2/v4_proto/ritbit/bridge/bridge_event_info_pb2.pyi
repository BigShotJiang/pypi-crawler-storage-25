from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class BridgeEventInfo(_message.Message):
    __slots__ = ("next_id", "eth_block_height")
    NEXT_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_BLOCK_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    next_id: int
    eth_block_height: int
    def __init__(self, next_id: _Optional[int] = ..., eth_block_height: _Optional[int] = ...) -> None: ...

class ChainBridgeEventInfo(_message.Message):
    __slots__ = ("chain_id", "info")
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    INFO_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    info: BridgeEventInfo
    def __init__(self, chain_id: _Optional[int] = ..., info: _Optional[_Union[BridgeEventInfo, _Mapping]] = ...) -> None: ...
