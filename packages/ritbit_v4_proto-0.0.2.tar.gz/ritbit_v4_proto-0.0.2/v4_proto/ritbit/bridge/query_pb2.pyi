from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from v4_proto.google.api import annotations_pb2 as _annotations_pb2
from v4_proto.ritbit.bridge import bridge_event_pb2 as _bridge_event_pb2
from v4_proto.ritbit.bridge import bridge_event_info_pb2 as _bridge_event_info_pb2
from v4_proto.ritbit.bridge import params_pb2 as _params_pb2
from v4_proto.ritbit.bridge import token_reserve_pb2 as _token_reserve_pb2
from v4_proto.ritbit.bridge import tx_pb2 as _tx_pb2
from v4_proto.ritbit.bridge import withdrawal_pb2 as _withdrawal_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class QueryEventParamsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class QueryEventParamsResponse(_message.Message):
    __slots__ = ("params",)
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    params: _params_pb2.EventParams
    def __init__(self, params: _Optional[_Union[_params_pb2.EventParams, _Mapping]] = ...) -> None: ...

class QueryProposeParamsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class QueryProposeParamsResponse(_message.Message):
    __slots__ = ("params",)
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    params: _params_pb2.ProposeParams
    def __init__(self, params: _Optional[_Union[_params_pb2.ProposeParams, _Mapping]] = ...) -> None: ...

class QuerySafetyParamsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class QuerySafetyParamsResponse(_message.Message):
    __slots__ = ("params",)
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    params: _params_pb2.SafetyParams
    def __init__(self, params: _Optional[_Union[_params_pb2.SafetyParams, _Mapping]] = ...) -> None: ...

class QueryAcknowledgedEventInfoRequest(_message.Message):
    __slots__ = ("chain_id",)
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    def __init__(self, chain_id: _Optional[int] = ...) -> None: ...

class QueryAcknowledgedEventInfoResponse(_message.Message):
    __slots__ = ("infos",)
    INFOS_FIELD_NUMBER: _ClassVar[int]
    infos: _containers.RepeatedCompositeFieldContainer[_bridge_event_info_pb2.ChainBridgeEventInfo]
    def __init__(self, infos: _Optional[_Iterable[_Union[_bridge_event_info_pb2.ChainBridgeEventInfo, _Mapping]]] = ...) -> None: ...

class QueryRecognizedEventInfoRequest(_message.Message):
    __slots__ = ("chain_id",)
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    def __init__(self, chain_id: _Optional[int] = ...) -> None: ...

class QueryRecognizedEventInfoResponse(_message.Message):
    __slots__ = ("infos",)
    INFOS_FIELD_NUMBER: _ClassVar[int]
    infos: _containers.RepeatedCompositeFieldContainer[_bridge_event_info_pb2.ChainBridgeEventInfo]
    def __init__(self, infos: _Optional[_Iterable[_Union[_bridge_event_info_pb2.ChainBridgeEventInfo, _Mapping]]] = ...) -> None: ...

class QueryDelayedCompleteBridgeMessagesRequest(_message.Message):
    __slots__ = ("address",)
    ADDRESS_FIELD_NUMBER: _ClassVar[int]
    address: str
    def __init__(self, address: _Optional[str] = ...) -> None: ...

class QueryDelayedCompleteBridgeMessagesResponse(_message.Message):
    __slots__ = ("messages",)
    MESSAGES_FIELD_NUMBER: _ClassVar[int]
    messages: _containers.RepeatedCompositeFieldContainer[DelayedCompleteBridgeMessage]
    def __init__(self, messages: _Optional[_Iterable[_Union[DelayedCompleteBridgeMessage, _Mapping]]] = ...) -> None: ...

class DelayedCompleteBridgeMessage(_message.Message):
    __slots__ = ("message", "block_height")
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    BLOCK_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    message: _tx_pb2.MsgCompleteBridge
    block_height: int
    def __init__(self, message: _Optional[_Union[_tx_pb2.MsgCompleteBridge, _Mapping]] = ..., block_height: _Optional[int] = ...) -> None: ...

class QueryWithdrawalRequest(_message.Message):
    __slots__ = ("id", "eth_chain_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    id: int
    eth_chain_id: int
    def __init__(self, id: _Optional[int] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class QueryWithdrawalResponse(_message.Message):
    __slots__ = ("withdrawal",)
    WITHDRAWAL_FIELD_NUMBER: _ClassVar[int]
    withdrawal: _withdrawal_pb2.Withdrawal
    def __init__(self, withdrawal: _Optional[_Union[_withdrawal_pb2.Withdrawal, _Mapping]] = ...) -> None: ...

class QueryWithdrawalsRequest(_message.Message):
    __slots__ = ("status", "sender", "limit", "offset", "eth_chain_id")
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SENDER_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    status: _withdrawal_pb2.WithdrawalStatus
    sender: str
    limit: int
    offset: int
    eth_chain_id: int
    def __init__(self, status: _Optional[_Union[_withdrawal_pb2.WithdrawalStatus, str]] = ..., sender: _Optional[str] = ..., limit: _Optional[int] = ..., offset: _Optional[int] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class QueryWithdrawalsResponse(_message.Message):
    __slots__ = ("withdrawals", "total")
    WITHDRAWALS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_FIELD_NUMBER: _ClassVar[int]
    withdrawals: _containers.RepeatedCompositeFieldContainer[_withdrawal_pb2.Withdrawal]
    total: int
    def __init__(self, withdrawals: _Optional[_Iterable[_Union[_withdrawal_pb2.Withdrawal, _Mapping]]] = ..., total: _Optional[int] = ...) -> None: ...

class QueryWithdrawalParamsRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class QueryWithdrawalParamsResponse(_message.Message):
    __slots__ = ("params",)
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    params: _withdrawal_pb2.WithdrawalParams
    def __init__(self, params: _Optional[_Union[_withdrawal_pb2.WithdrawalParams, _Mapping]] = ...) -> None: ...

class QueryChainWithdrawalStatesRequest(_message.Message):
    __slots__ = ("chain_id",)
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    def __init__(self, chain_id: _Optional[int] = ...) -> None: ...

class QueryChainWithdrawalStatesResponse(_message.Message):
    __slots__ = ("states",)
    STATES_FIELD_NUMBER: _ClassVar[int]
    states: _containers.RepeatedCompositeFieldContainer[_withdrawal_pb2.ChainWithdrawalState]
    def __init__(self, states: _Optional[_Iterable[_Union[_withdrawal_pb2.ChainWithdrawalState, _Mapping]]] = ...) -> None: ...

class QueryWithdrawalDailyUsageRequest(_message.Message):
    __slots__ = ("chain_id", "asset_id")
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    asset_id: int
    def __init__(self, chain_id: _Optional[int] = ..., asset_id: _Optional[int] = ...) -> None: ...

class QueryWithdrawalDailyUsageResponse(_message.Message):
    __slots__ = ("usage",)
    USAGE_FIELD_NUMBER: _ClassVar[int]
    usage: _containers.RepeatedCompositeFieldContainer[_withdrawal_pb2.AssetChainWithdrawalDailyUsage]
    def __init__(self, usage: _Optional[_Iterable[_Union[_withdrawal_pb2.AssetChainWithdrawalDailyUsage, _Mapping]]] = ...) -> None: ...

class QueryReadyForRelayWithdrawalsRequest(_message.Message):
    __slots__ = ("limit",)
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    limit: int
    def __init__(self, limit: _Optional[int] = ...) -> None: ...

class QueryReadyForRelayWithdrawalsResponse(_message.Message):
    __slots__ = ("aggregated_withdrawals", "current_block_height")
    AGGREGATED_WITHDRAWALS_FIELD_NUMBER: _ClassVar[int]
    CURRENT_BLOCK_HEIGHT_FIELD_NUMBER: _ClassVar[int]
    aggregated_withdrawals: _containers.RepeatedCompositeFieldContainer[_withdrawal_pb2.AggregatedWithdrawal]
    current_block_height: int
    def __init__(self, aggregated_withdrawals: _Optional[_Iterable[_Union[_withdrawal_pb2.AggregatedWithdrawal, _Mapping]]] = ..., current_block_height: _Optional[int] = ...) -> None: ...

class QueryValidatorEvmAddressRequest(_message.Message):
    __slots__ = ("validator_address",)
    VALIDATOR_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    validator_address: str
    def __init__(self, validator_address: _Optional[str] = ...) -> None: ...

class QueryValidatorEvmAddressResponse(_message.Message):
    __slots__ = ("validator_evm_address",)
    VALIDATOR_EVM_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    validator_evm_address: _withdrawal_pb2.ValidatorEvmAddress
    def __init__(self, validator_evm_address: _Optional[_Union[_withdrawal_pb2.ValidatorEvmAddress, _Mapping]] = ...) -> None: ...

class QueryValidatorEvmAddressesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class QueryValidatorEvmAddressesResponse(_message.Message):
    __slots__ = ("validator_evm_addresses",)
    VALIDATOR_EVM_ADDRESSES_FIELD_NUMBER: _ClassVar[int]
    validator_evm_addresses: _containers.RepeatedCompositeFieldContainer[_withdrawal_pb2.ValidatorEvmAddress]
    def __init__(self, validator_evm_addresses: _Optional[_Iterable[_Union[_withdrawal_pb2.ValidatorEvmAddress, _Mapping]]] = ...) -> None: ...

class QueryValidatorEvmAddressByEvmAddressRequest(_message.Message):
    __slots__ = ("evm_address",)
    EVM_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    evm_address: str
    def __init__(self, evm_address: _Optional[str] = ...) -> None: ...

class QueryValidatorEvmAddressByEvmAddressResponse(_message.Message):
    __slots__ = ("validator_evm_address",)
    VALIDATOR_EVM_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    validator_evm_address: _withdrawal_pb2.ValidatorEvmAddress
    def __init__(self, validator_evm_address: _Optional[_Union[_withdrawal_pb2.ValidatorEvmAddress, _Mapping]] = ...) -> None: ...

class QueryAggregatedWithdrawalRequest(_message.Message):
    __slots__ = ("id", "eth_chain_id")
    ID_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    id: int
    eth_chain_id: int
    def __init__(self, id: _Optional[int] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class QueryAggregatedWithdrawalResponse(_message.Message):
    __slots__ = ("aggregated_withdrawal",)
    AGGREGATED_WITHDRAWAL_FIELD_NUMBER: _ClassVar[int]
    aggregated_withdrawal: _withdrawal_pb2.AggregatedWithdrawal
    def __init__(self, aggregated_withdrawal: _Optional[_Union[_withdrawal_pb2.AggregatedWithdrawal, _Mapping]] = ...) -> None: ...

class QueryWithdrawalSignaturesRequest(_message.Message):
    __slots__ = ("withdrawal_id", "eth_chain_id")
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    withdrawal_id: int
    eth_chain_id: int
    def __init__(self, withdrawal_id: _Optional[int] = ..., eth_chain_id: _Optional[int] = ...) -> None: ...

class QueryWithdrawalSignaturesResponse(_message.Message):
    __slots__ = ("signatures",)
    SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    signatures: _containers.RepeatedCompositeFieldContainer[_withdrawal_pb2.WithdrawalSignature]
    def __init__(self, signatures: _Optional[_Iterable[_Union[_withdrawal_pb2.WithdrawalSignature, _Mapping]]] = ...) -> None: ...

class QueryTokenReserveRequest(_message.Message):
    __slots__ = ("asset_id", "chain_id")
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    asset_id: int
    chain_id: int
    def __init__(self, asset_id: _Optional[int] = ..., chain_id: _Optional[int] = ...) -> None: ...

class QueryTokenReserveResponse(_message.Message):
    __slots__ = ("info",)
    INFO_FIELD_NUMBER: _ClassVar[int]
    info: _token_reserve_pb2.TokenReserve
    def __init__(self, info: _Optional[_Union[_token_reserve_pb2.TokenReserve, _Mapping]] = ...) -> None: ...

class QueryTokenReservesRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class QueryTokenReservesResponse(_message.Message):
    __slots__ = ("infos",)
    INFOS_FIELD_NUMBER: _ClassVar[int]
    infos: _containers.RepeatedCompositeFieldContainer[_token_reserve_pb2.TokenReserve]
    def __init__(self, infos: _Optional[_Iterable[_Union[_token_reserve_pb2.TokenReserve, _Mapping]]] = ...) -> None: ...

class QueryPendingFinalityEventsRequest(_message.Message):
    __slots__ = ("chain_id",)
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    def __init__(self, chain_id: _Optional[int] = ...) -> None: ...

class QueryPendingFinalityEventsResponse(_message.Message):
    __slots__ = ("events",)
    EVENTS_FIELD_NUMBER: _ClassVar[int]
    events: _containers.RepeatedCompositeFieldContainer[_bridge_event_pb2.PendingFinalityEvent]
    def __init__(self, events: _Optional[_Iterable[_Union[_bridge_event_pb2.PendingFinalityEvent, _Mapping]]] = ...) -> None: ...

class QueryWithdrawalConfirmationInfoRequest(_message.Message):
    __slots__ = ("chain_id",)
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    def __init__(self, chain_id: _Optional[int] = ...) -> None: ...

class QueryWithdrawalConfirmationInfoResponse(_message.Message):
    __slots__ = ("infos",)
    INFOS_FIELD_NUMBER: _ClassVar[int]
    infos: _containers.RepeatedCompositeFieldContainer[_bridge_event_pb2.ChainWithdrawalConfirmationInfo]
    def __init__(self, infos: _Optional[_Iterable[_Union[_bridge_event_pb2.ChainWithdrawalConfirmationInfo, _Mapping]]] = ...) -> None: ...

class QueryRecognizedWithdrawalConfirmationInfoRequest(_message.Message):
    __slots__ = ("chain_id",)
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    def __init__(self, chain_id: _Optional[int] = ...) -> None: ...

class QueryRecognizedWithdrawalConfirmationInfoResponse(_message.Message):
    __slots__ = ("infos",)
    INFOS_FIELD_NUMBER: _ClassVar[int]
    infos: _containers.RepeatedCompositeFieldContainer[_bridge_event_pb2.ChainWithdrawalConfirmationInfo]
    def __init__(self, infos: _Optional[_Iterable[_Union[_bridge_event_pb2.ChainWithdrawalConfirmationInfo, _Mapping]]] = ...) -> None: ...
