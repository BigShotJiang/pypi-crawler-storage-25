from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from v4_proto.cosmos_proto import cosmos_pb2 as _cosmos_pb2
from v4_proto.cosmos.base.v1beta1 import coin_pb2 as _coin_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class WithdrawalStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    WITHDRAWAL_STATUS_UNSPECIFIED: _ClassVar[WithdrawalStatus]
    WITHDRAWAL_STATUS_PENDING_TIMELOCK: _ClassVar[WithdrawalStatus]
    WITHDRAWAL_STATUS_SIGNING: _ClassVar[WithdrawalStatus]
    WITHDRAWAL_STATUS_READY: _ClassVar[WithdrawalStatus]
    WITHDRAWAL_STATUS_RELAYED: _ClassVar[WithdrawalStatus]
    WITHDRAWAL_STATUS_ERROR: _ClassVar[WithdrawalStatus]
    WITHDRAWAL_STATUS_EXPIRED: _ClassVar[WithdrawalStatus]
WITHDRAWAL_STATUS_UNSPECIFIED: WithdrawalStatus
WITHDRAWAL_STATUS_PENDING_TIMELOCK: WithdrawalStatus
WITHDRAWAL_STATUS_SIGNING: WithdrawalStatus
WITHDRAWAL_STATUS_READY: WithdrawalStatus
WITHDRAWAL_STATUS_RELAYED: WithdrawalStatus
WITHDRAWAL_STATUS_ERROR: WithdrawalStatus
WITHDRAWAL_STATUS_EXPIRED: WithdrawalStatus

class Withdrawal(_message.Message):
    __slots__ = ("id", "amount", "eth_recipient", "sender", "status", "created_at_block", "timelock_blocks", "eth_chain_id", "eth_tx_hash", "error_message", "asset_id", "relay_attempts", "ready_at_block", "fee", "fee_payer")
    ID_FIELD_NUMBER: _ClassVar[int]
    AMOUNT_FIELD_NUMBER: _ClassVar[int]
    ETH_RECIPIENT_FIELD_NUMBER: _ClassVar[int]
    SENDER_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_BLOCK_FIELD_NUMBER: _ClassVar[int]
    TIMELOCK_BLOCKS_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_TX_HASH_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    RELAY_ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    READY_AT_BLOCK_FIELD_NUMBER: _ClassVar[int]
    FEE_FIELD_NUMBER: _ClassVar[int]
    FEE_PAYER_FIELD_NUMBER: _ClassVar[int]
    id: int
    amount: str
    eth_recipient: str
    sender: str
    status: WithdrawalStatus
    created_at_block: int
    timelock_blocks: int
    eth_chain_id: int
    eth_tx_hash: str
    error_message: str
    asset_id: int
    relay_attempts: int
    ready_at_block: int
    fee: _containers.RepeatedCompositeFieldContainer[_coin_pb2.Coin]
    fee_payer: str
    def __init__(self, id: _Optional[int] = ..., amount: _Optional[str] = ..., eth_recipient: _Optional[str] = ..., sender: _Optional[str] = ..., status: _Optional[_Union[WithdrawalStatus, str]] = ..., created_at_block: _Optional[int] = ..., timelock_blocks: _Optional[int] = ..., eth_chain_id: _Optional[int] = ..., eth_tx_hash: _Optional[str] = ..., error_message: _Optional[str] = ..., asset_id: _Optional[int] = ..., relay_attempts: _Optional[int] = ..., ready_at_block: _Optional[int] = ..., fee: _Optional[_Iterable[_Union[_coin_pb2.Coin, _Mapping]]] = ..., fee_payer: _Optional[str] = ...) -> None: ...

class AssetChainDailyLimitConfig(_message.Message):
    __slots__ = ("chain_id", "asset_id", "daily_limit")
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    DAILY_LIMIT_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    asset_id: int
    daily_limit: str
    def __init__(self, chain_id: _Optional[int] = ..., asset_id: _Optional[int] = ..., daily_limit: _Optional[str] = ...) -> None: ...

class ChainWithdrawalState(_message.Message):
    __slots__ = ("chain_id", "next_id")
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    NEXT_ID_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    next_id: int
    def __init__(self, chain_id: _Optional[int] = ..., next_id: _Optional[int] = ...) -> None: ...

class AssetChainWithdrawalDailyUsage(_message.Message):
    __slots__ = ("chain_id", "asset_id", "daily_used", "last_reset")
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    DAILY_USED_FIELD_NUMBER: _ClassVar[int]
    LAST_RESET_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    asset_id: int
    daily_used: str
    last_reset: int
    def __init__(self, chain_id: _Optional[int] = ..., asset_id: _Optional[int] = ..., daily_used: _Optional[str] = ..., last_reset: _Optional[int] = ...) -> None: ...

class WithdrawalParams(_message.Message):
    __slots__ = ("chain_withdrawal_configs", "daily_limit_configs", "withdrawals_disabled", "signing_timeout_blocks", "max_relay_attempts", "relay_timeout_blocks", "confirmation_timeout_blocks")
    CHAIN_WITHDRAWAL_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    DAILY_LIMIT_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWALS_DISABLED_FIELD_NUMBER: _ClassVar[int]
    SIGNING_TIMEOUT_BLOCKS_FIELD_NUMBER: _ClassVar[int]
    MAX_RELAY_ATTEMPTS_FIELD_NUMBER: _ClassVar[int]
    RELAY_TIMEOUT_BLOCKS_FIELD_NUMBER: _ClassVar[int]
    CONFIRMATION_TIMEOUT_BLOCKS_FIELD_NUMBER: _ClassVar[int]
    chain_withdrawal_configs: _containers.RepeatedCompositeFieldContainer[ChainWithdrawalConfig]
    daily_limit_configs: _containers.RepeatedCompositeFieldContainer[AssetChainDailyLimitConfig]
    withdrawals_disabled: bool
    signing_timeout_blocks: int
    max_relay_attempts: int
    relay_timeout_blocks: int
    confirmation_timeout_blocks: int
    def __init__(self, chain_withdrawal_configs: _Optional[_Iterable[_Union[ChainWithdrawalConfig, _Mapping]]] = ..., daily_limit_configs: _Optional[_Iterable[_Union[AssetChainDailyLimitConfig, _Mapping]]] = ..., withdrawals_disabled: bool = ..., signing_timeout_blocks: _Optional[int] = ..., max_relay_attempts: _Optional[int] = ..., relay_timeout_blocks: _Optional[int] = ..., confirmation_timeout_blocks: _Optional[int] = ...) -> None: ...

class ChainWithdrawalConfig(_message.Message):
    __slots__ = ("chain_id", "asset_configs")
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ASSET_CONFIGS_FIELD_NUMBER: _ClassVar[int]
    chain_id: int
    asset_configs: _containers.RepeatedCompositeFieldContainer[AssetWithdrawalConfig]
    def __init__(self, chain_id: _Optional[int] = ..., asset_configs: _Optional[_Iterable[_Union[AssetWithdrawalConfig, _Mapping]]] = ...) -> None: ...

class AssetWithdrawalConfig(_message.Message):
    __slots__ = ("asset_id", "large_withdrawal_threshold", "timelock_blocks", "withdrawal_fee")
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    LARGE_WITHDRAWAL_THRESHOLD_FIELD_NUMBER: _ClassVar[int]
    TIMELOCK_BLOCKS_FIELD_NUMBER: _ClassVar[int]
    WITHDRAWAL_FEE_FIELD_NUMBER: _ClassVar[int]
    asset_id: int
    large_withdrawal_threshold: str
    timelock_blocks: int
    withdrawal_fee: _containers.RepeatedCompositeFieldContainer[_coin_pb2.Coin]
    def __init__(self, asset_id: _Optional[int] = ..., large_withdrawal_threshold: _Optional[str] = ..., timelock_blocks: _Optional[int] = ..., withdrawal_fee: _Optional[_Iterable[_Union[_coin_pb2.Coin, _Mapping]]] = ...) -> None: ...

class ValidatorEvmAddress(_message.Message):
    __slots__ = ("validator_address", "evm_address", "registered_at_block")
    VALIDATOR_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    EVM_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    REGISTERED_AT_BLOCK_FIELD_NUMBER: _ClassVar[int]
    validator_address: str
    evm_address: str
    registered_at_block: int
    def __init__(self, validator_address: _Optional[str] = ..., evm_address: _Optional[str] = ..., registered_at_block: _Optional[int] = ...) -> None: ...

class WithdrawalSignature(_message.Message):
    __slots__ = ("withdrawal_id", "validator_address", "validator_eth_address", "eth_signature", "signed_at_block")
    WITHDRAWAL_ID_FIELD_NUMBER: _ClassVar[int]
    VALIDATOR_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    VALIDATOR_ETH_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    ETH_SIGNATURE_FIELD_NUMBER: _ClassVar[int]
    SIGNED_AT_BLOCK_FIELD_NUMBER: _ClassVar[int]
    withdrawal_id: int
    validator_address: str
    validator_eth_address: str
    eth_signature: bytes
    signed_at_block: int
    def __init__(self, withdrawal_id: _Optional[int] = ..., validator_address: _Optional[str] = ..., validator_eth_address: _Optional[str] = ..., eth_signature: _Optional[bytes] = ..., signed_at_block: _Optional[int] = ...) -> None: ...

class AggregatedWithdrawal(_message.Message):
    __slots__ = ("withdrawal", "signatures", "signature_count", "required_signatures", "ready_for_relay", "ready_at_block", "assigned_relayer")
    WITHDRAWAL_FIELD_NUMBER: _ClassVar[int]
    SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    SIGNATURE_COUNT_FIELD_NUMBER: _ClassVar[int]
    REQUIRED_SIGNATURES_FIELD_NUMBER: _ClassVar[int]
    READY_FOR_RELAY_FIELD_NUMBER: _ClassVar[int]
    READY_AT_BLOCK_FIELD_NUMBER: _ClassVar[int]
    ASSIGNED_RELAYER_FIELD_NUMBER: _ClassVar[int]
    withdrawal: Withdrawal
    signatures: _containers.RepeatedCompositeFieldContainer[WithdrawalSignature]
    signature_count: int
    required_signatures: int
    ready_for_relay: bool
    ready_at_block: int
    assigned_relayer: str
    def __init__(self, withdrawal: _Optional[_Union[Withdrawal, _Mapping]] = ..., signatures: _Optional[_Iterable[_Union[WithdrawalSignature, _Mapping]]] = ..., signature_count: _Optional[int] = ..., required_signatures: _Optional[int] = ..., ready_for_relay: bool = ..., ready_at_block: _Optional[int] = ..., assigned_relayer: _Optional[str] = ...) -> None: ...
