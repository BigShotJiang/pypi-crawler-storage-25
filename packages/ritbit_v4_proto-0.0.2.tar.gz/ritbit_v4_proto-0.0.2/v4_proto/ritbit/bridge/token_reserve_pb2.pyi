from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from v4_proto.cosmos_proto import cosmos_pb2 as _cosmos_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class TokenReserve(_message.Message):
    __slots__ = ("asset_id", "chain_id", "reserved_amount", "token_address")
    ASSET_ID_FIELD_NUMBER: _ClassVar[int]
    CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    RESERVED_AMOUNT_FIELD_NUMBER: _ClassVar[int]
    TOKEN_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    asset_id: int
    chain_id: int
    reserved_amount: str
    token_address: str
    def __init__(self, asset_id: _Optional[int] = ..., chain_id: _Optional[int] = ..., reserved_amount: _Optional[str] = ..., token_address: _Optional[str] = ...) -> None: ...
