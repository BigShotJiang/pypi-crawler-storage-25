from v4_proto.cosmos_proto import cosmos_pb2 as _cosmos_pb2
from v4_proto.cosmos.msg.v1 import msg_pb2 as _msg_pb2
from v4_proto.gogoproto import gogo_pb2 as _gogo_pb2
from v4_proto.ritbit.assets import asset_pb2 as _asset_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MsgCreateAsset(_message.Message):
    __slots__ = ("authority", "asset")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    ASSET_FIELD_NUMBER: _ClassVar[int]
    authority: str
    asset: _asset_pb2.Asset
    def __init__(self, authority: _Optional[str] = ..., asset: _Optional[_Union[_asset_pb2.Asset, _Mapping]] = ...) -> None: ...

class MsgCreateAssetResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MsgModifyAsset(_message.Message):
    __slots__ = ("authority", "id", "has_market", "market_id")
    AUTHORITY_FIELD_NUMBER: _ClassVar[int]
    ID_FIELD_NUMBER: _ClassVar[int]
    HAS_MARKET_FIELD_NUMBER: _ClassVar[int]
    MARKET_ID_FIELD_NUMBER: _ClassVar[int]
    authority: str
    id: int
    has_market: bool
    market_id: int
    def __init__(self, authority: _Optional[str] = ..., id: _Optional[int] = ..., has_market: bool = ..., market_id: _Optional[int] = ...) -> None: ...

class MsgModifyAssetResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
