from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class LegacyEventParams(_message.Message):
    __slots__ = ("denom", "eth_chain_id", "eth_address")
    DENOM_FIELD_NUMBER: _ClassVar[int]
    ETH_CHAIN_ID_FIELD_NUMBER: _ClassVar[int]
    ETH_ADDRESS_FIELD_NUMBER: _ClassVar[int]
    denom: str
    eth_chain_id: int
    eth_address: str
    def __init__(self, denom: _Optional[str] = ..., eth_chain_id: _Optional[int] = ..., eth_address: _Optional[str] = ...) -> None: ...
