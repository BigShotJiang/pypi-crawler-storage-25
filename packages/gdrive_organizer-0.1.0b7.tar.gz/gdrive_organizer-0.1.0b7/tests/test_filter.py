"""Tests for scan filtering."""

from gdrive_organizer.config import Config
from gdrive_organizer.scanner.filter import (
    ExcludeRules,
    build_md5_index,
    detect_junk_files,
    filter_files,
    load_exclude_rules,
    save_exclude_config,
)

FOLDER = "application/vnd.google-apps.folder"

SAMPLE_FILES = [
    {"id": "root", "name": "My Files", "mimeType": FOLDER},
    {"id": "doc1", "name": "report.txt", "mimeType": "text/plain", "parents": ["root"]},
    # node_modules folder and its children
    {"id": "nm", "name": "node_modules", "mimeType": FOLDER, "parents": ["root"]},
    {"id": "nm_pkg", "name": "lodash", "mimeType": FOLDER, "parents": ["nm"]},
    {"id": "nm_file", "name": "index.js", "mimeType": "text/javascript", "parents": ["nm_pkg"]},
    # __pycache__
    {"id": "pyc_dir", "name": "__pycache__", "mimeType": FOLDER, "parents": ["root"]},
    {
        "id": "pyc_file",
        "name": "main.cpython-312.pyc",
        "mimeType": "application/octet-stream",
        "parents": ["pyc_dir"],
    },
    # .git
    {"id": "git_dir", "name": ".git", "mimeType": FOLDER, "parents": ["root"]},
    {"id": "git_file", "name": "HEAD", "mimeType": "text/plain", "parents": ["git_dir"]},
    # Normal files with excluded extensions
    {"id": "log_file", "name": "app.log", "mimeType": "text/plain", "parents": ["root"]},
    {
        "id": "pyc_loose",
        "name": "module.pyc",
        "mimeType": "application/octet-stream",
        "parents": ["root"],
    },
    # Exact name matches
    {"id": "ds", "name": ".DS_Store", "mimeType": "application/octet-stream", "parents": ["root"]},
    # Normal file that should survive
    {"id": "good", "name": "README.md", "mimeType": "text/markdown", "parents": ["root"]},
]


def test_filter_excludes_folders_recursively():
    rules = ExcludeRules()
    kept, stats = filter_files(SAMPLE_FILES, rules)
    kept_ids = {f["id"] for f in kept}

    # node_modules and all children excluded
    assert "nm" not in kept_ids
    assert "nm_pkg" not in kept_ids
    assert "nm_file" not in kept_ids

    # __pycache__ and children excluded
    assert "pyc_dir" not in kept_ids
    assert "pyc_file" not in kept_ids

    # .git and children excluded
    assert "git_dir" not in kept_ids
    assert "git_file" not in kept_ids


def test_filter_excludes_extensions():
    rules = ExcludeRules()
    kept, stats = filter_files(SAMPLE_FILES, rules)
    kept_ids = {f["id"] for f in kept}

    assert "log_file" not in kept_ids  # .log excluded
    assert "pyc_loose" not in kept_ids  # .pyc excluded
    assert stats.excluded_by_extension >= 2


def test_filter_excludes_names():
    rules = ExcludeRules()
    kept, stats = filter_files(SAMPLE_FILES, rules)
    kept_ids = {f["id"] for f in kept}

    assert "ds" not in kept_ids  # .DS_Store excluded
    assert stats.excluded_by_name >= 1


def test_filter_keeps_normal_files():
    rules = ExcludeRules()
    kept, stats = filter_files(SAMPLE_FILES, rules)
    kept_ids = {f["id"] for f in kept}

    assert "root" in kept_ids
    assert "doc1" in kept_ids
    assert "good" in kept_ids


def test_filter_stats():
    rules = ExcludeRules()
    _, stats = filter_files(SAMPLE_FILES, rules)
    assert stats.total_before == len(SAMPLE_FILES)
    assert stats.total_after < stats.total_before
    assert stats.excluded_by_folder > 0


def test_empty_rules_keeps_everything():
    rules = ExcludeRules(
        folders=frozenset(),
        extensions=frozenset(),
        names=frozenset(),
    )
    kept, stats = filter_files(SAMPLE_FILES, rules)
    assert stats.total_after == stats.total_before


def test_custom_exclude_config(tmp_path):
    config = Config(config_dir=tmp_path, data_dir=tmp_path / "data")

    # Save custom config that adds a folder and removes "build" from defaults
    save_exclude_config(
        config,
        {
            "excluded_folders": {"add": ["my_cache"], "remove": ["build"]},
            "excluded_extensions": {"add": [".bak"], "remove": []},
            "excluded_names": {"add": [], "remove": []},
        },
    )

    rules = load_exclude_rules(config)
    assert "my_cache" in rules.folders
    assert "build" not in rules.folders
    assert "node_modules" in rules.folders  # default preserved
    assert ".bak" in rules.extensions


def test_load_exclude_rules_no_file(tmp_path):
    config = Config(config_dir=tmp_path, data_dir=tmp_path / "data")
    rules = load_exclude_rules(config)
    # Should return defaults
    assert "node_modules" in rules.folders
    assert ".pyc" in rules.extensions
    assert ".DS_Store" in rules.names


# --- Junk detection tests ---

JUNK_FILES = [
    {"id": "j1", "name": "Copy of report.txt", "mimeType": "text/plain"},
    {"id": "j2", "name": "복사본 설계서.docx", "mimeType": "application/octet-stream"},
    {"id": "j3", "name": "보고서 (1).pdf", "mimeType": "application/pdf"},
    {"id": "j4", "name": "image (2).png", "mimeType": "image/png"},
    {"id": "j5", "name": "새 폴더", "mimeType": FOLDER},
    {"id": "j6", "name": "Untitled document", "mimeType": "text/plain"},
    {"id": "j7", "name": "tmp", "mimeType": FOLDER},
    {"id": "ok1", "name": "real_report.pdf", "mimeType": "application/pdf"},
    {"id": "ok2", "name": "project (v2).zip", "mimeType": "application/zip"},
]


def test_detect_junk_prefix():
    junk = detect_junk_files(JUNK_FILES)
    junk_ids = {j.file_id for j in junk}
    assert "j1" in junk_ids  # Copy of
    assert "j2" in junk_ids  # 복사본


def test_detect_junk_suffix():
    junk = detect_junk_files(JUNK_FILES)
    junk_ids = {j.file_id for j in junk}
    assert "j3" in junk_ids  # (1)
    assert "j4" in junk_ids  # (2)


def test_detect_junk_default_name():
    junk = detect_junk_files(JUNK_FILES)
    junk_ids = {j.file_id for j in junk}
    assert "j5" in junk_ids  # 새 폴더
    assert "j6" in junk_ids  # Untitled document


def test_detect_junk_temp_folder():
    junk = detect_junk_files(JUNK_FILES)
    junk_ids = {j.file_id for j in junk}
    assert "j7" in junk_ids  # tmp


def test_detect_junk_not_false_positive():
    junk = detect_junk_files(JUNK_FILES)
    junk_ids = {j.file_id for j in junk}
    assert "ok1" not in junk_ids  # Normal file
    assert "ok2" not in junk_ids  # (v2) is not (2) pattern


def test_junk_md5_trash_candidate():
    files = [
        {
            "id": "a",
            "name": "report (1).pdf",
            "mimeType": "application/pdf",
            "md5Checksum": "abc123",
        },
        {"id": "b", "name": "report.pdf", "mimeType": "application/pdf", "md5Checksum": "abc123"},
    ]
    md5_idx = build_md5_index(files)
    junk = detect_junk_files(files, md5_index=md5_idx)
    # "report (1).pdf" is junk + has duplicate md5 → trash candidate
    assert len(junk) == 1
    assert junk[0].file_id == "a"
    assert junk[0].is_trash_candidate is True
