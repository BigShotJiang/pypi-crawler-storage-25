"""Tests for permission scanning."""

from unittest.mock import MagicMock

from gdrive_organizer.models import DriveFile, DrivePermission, PermissionRole
from gdrive_organizer.scanner.permissions import (
    get_file_permissions,
    summarize_permissions,
)


def test_get_file_permissions():
    service = MagicMock()
    service.permissions.return_value.list.return_value.execute.return_value = {
        "permissions": [{"id": "1", "type": "user", "role": "writer", "emailAddress": "a@b.com"}]
    }
    perms = get_file_permissions(service, "file1")
    assert len(perms) == 1
    assert perms[0]["emailAddress"] == "a@b.com"


def test_summarize_permissions():
    files = [
        DriveFile(
            id="1",
            name="public.txt",
            mime_type="text/plain",
            permissions=[DrivePermission(id="p1", type="anyone", role=PermissionRole.READER)],
        ),
        DriveFile(
            id="2",
            name="domain.txt",
            mime_type="text/plain",
            permissions=[DrivePermission(id="p2", type="domain", role=PermissionRole.READER)],
        ),
        DriveFile(
            id="3",
            name="shared.txt",
            mime_type="text/plain",
            permissions=[
                DrivePermission(id="p3", type="user", role=PermissionRole.WRITER, email="a@b.com")
            ],
        ),
        DriveFile(id="4", name="private.txt", mime_type="text/plain"),
    ]
    summary = summarize_permissions(files)
    assert summary["public"] == 1
    assert summary["domain"] == 1
    assert summary["specific_users"] == 1
    assert summary["not_shared"] == 1
    assert len(summary["details"]["public_files"]) == 1
