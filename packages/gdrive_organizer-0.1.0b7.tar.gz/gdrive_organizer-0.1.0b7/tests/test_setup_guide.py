"""Tests for the interactive GCP OAuth setup guide."""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from io import StringIO
from unittest.mock import MagicMock, patch

import pytest
import typer
from rich.console import Console

from gdrive_organizer.auth.setup_guide import (
    _manual_credentials_input,
    _pre_check,
    _step_detect_and_login,
    _step_oauth_login,
    _wait_for_credentials,
    run_setup_guide,
)
from gdrive_organizer.config import Config

# Patch targets — lazy imports mean we must patch at the source module
_PATCH_GET_SERVICE = "gdrive_organizer.auth.oauth.get_drive_service"
_PATCH_AUTO_DETECT = "gdrive_organizer.auth.oauth.auto_detect_credentials"


@pytest.fixture
def config(tmp_path):
    """Config backed by a temporary directory."""
    return Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")


@pytest.fixture
def console():
    """A Rich Console that writes to a buffer for assertion."""
    return Console(file=StringIO(), force_terminal=False, no_color=True)


def _make_token_data(*, valid: bool = True) -> dict:
    expiry = datetime.now(UTC) + (timedelta(hours=1) if valid else timedelta(hours=-1))
    return {
        "token": "fake-access-token",
        "refresh_token": "fake-refresh-token",
        "token_uri": "https://oauth2.googleapis.com/token",
        "client_id": "test-client-id",
        "client_secret": "test-secret",
        "scopes": ["https://www.googleapis.com/auth/drive"],
        "expiry": expiry.isoformat(),
        "account_email": "user@example.com",
    }


def _write_credentials(config: Config) -> None:
    """Create a fake credentials.json file."""
    config.credentials_path.parent.mkdir(parents=True, exist_ok=True)
    config.credentials_path.write_text('{"installed": {"client_id": "test"}}')


def _write_valid_token(config: Config) -> None:
    """Create a fake valid token.json file."""
    config.token_path.parent.mkdir(parents=True, exist_ok=True)
    config.token_path.write_text(json.dumps(_make_token_data(valid=True)))


def _mock_service() -> MagicMock:
    """Create a mock Drive service with about() stubbed."""
    svc = MagicMock()
    svc.about.return_value.get.return_value.execute.return_value = {
        "user": {"displayName": "Test User", "emailAddress": "test@example.com"},
    }
    return svc


# ── Pre-check tests ─────────────────────────────────────────────


class TestPreCheck:
    """Tests for _pre_check() — decides which steps to skip."""

    def test_no_credentials_no_token_returns_false(self, config, console):
        """Fresh install: should start from Step 1."""
        result = _pre_check(config, console)
        assert result is False

    def test_credentials_exist_no_token_returns_true(self, config, console):
        """Credentials present but no login: skip to OAuth login."""
        _write_credentials(config)
        result = _pre_check(config, console)
        assert result is True

    def test_credentials_and_valid_token_returns_none(self, config, console):
        """Fully authenticated: nothing to do."""
        _write_credentials(config)
        _write_valid_token(config)
        with patch(
            "gdrive_organizer.auth.oauth.Credentials.from_authorized_user_info"
        ) as mock_creds:
            mock_creds.return_value.valid = True
            mock_creds.return_value.expired = False
            mock_creds.return_value.expiry = datetime.now(UTC) + timedelta(hours=1)
            result = _pre_check(config, console)
        assert result is None

    def test_credentials_and_expired_token_returns_true(self, config, console):
        """Credentials present but token expired: should re-login."""
        _write_credentials(config)
        config.token_path.parent.mkdir(parents=True, exist_ok=True)
        config.token_path.write_text(json.dumps(_make_token_data(valid=False)))
        with patch(
            "gdrive_organizer.auth.oauth.Credentials.from_authorized_user_info"
        ) as mock_creds:
            mock_creds.return_value.valid = False
            mock_creds.return_value.expired = True
            mock_creds.return_value.expiry = datetime.now(UTC) - timedelta(hours=1)
            result = _pre_check(config, console)
        assert result is True


# ── run_setup_guide routing tests ────────────────────────────────


class TestRunSetupGuide:
    """Tests for run_setup_guide() — verifies routing based on pre-check."""

    def test_already_authenticated_exits_early(self, config, console):
        """When fully authenticated, guide should return immediately."""
        _write_credentials(config)
        _write_valid_token(config)
        with patch(
            "gdrive_organizer.auth.oauth.Credentials.from_authorized_user_info"
        ) as mock_creds:
            mock_creds.return_value.valid = True
            mock_creds.return_value.expired = False
            mock_creds.return_value.expiry = datetime.now(UTC) + timedelta(hours=1)
            run_setup_guide(config, console)

        output = console.file.getvalue()
        assert "이미 인증이 완료되어 있습니다" in output

    def test_credentials_exist_skips_to_oauth(self, config, console):
        """When credentials exist but no token, should skip GCP steps."""
        _write_credentials(config)

        with patch(_PATCH_GET_SERVICE, return_value=_mock_service()):
            run_setup_guide(config, console)

        output = console.file.getvalue()
        assert "GCP 설정 단계를 건너뛰고" in output
        assert "설정 완료" in output
        assert "Step 1/" not in output

    def test_fresh_install_runs_full_guide(self, config, console):
        """When nothing exists, should run all steps."""
        with (
            patch("gdrive_organizer.auth.setup_guide.typer.confirm", return_value=False),
            patch.object(console, "input", return_value=""),
            patch(_PATCH_AUTO_DETECT, return_value=True),
            patch(_PATCH_GET_SERVICE, return_value=_mock_service()),
        ):
            run_setup_guide(config, console)

        output = console.file.getvalue()
        assert "Step 1/5" in output
        assert "Step 2/5" in output
        assert "Step 3/5" in output
        assert "Step 4/5" in output
        assert "Step 5/5" in output
        assert "설정 완료" in output


# ── Credential detection tests ───────────────────────────────────


class TestWaitForCredentials:
    """Tests for _wait_for_credentials() — Downloads folder polling."""

    def test_found_immediately(self, config, console):
        """Credentials found on first poll."""
        with patch(_PATCH_AUTO_DETECT, return_value=True):
            result = _wait_for_credentials(config, console)

        assert result is True
        output = console.file.getvalue()
        assert "발견하여 이동했습니다" in output

    def test_found_after_retry(self, config, console):
        """Credentials not found initially, then found on second attempt."""
        call_count = 0

        def mock_detect(_config):
            nonlocal call_count
            call_count += 1
            return call_count >= 2

        with (
            patch(_PATCH_AUTO_DETECT, side_effect=mock_detect),
            patch("gdrive_organizer.auth.setup_guide.time.sleep"),
        ):
            result = _wait_for_credentials(config, console)

        assert result is True
        assert call_count == 2

    def test_timeout(self, config, console):
        """Should return False after timeout."""
        with (
            patch(_PATCH_AUTO_DETECT, return_value=False),
            patch("gdrive_organizer.auth.setup_guide.time.sleep"),
        ):
            result = _wait_for_credentials(config, console)

        assert result is False
        output = console.file.getvalue()
        assert "찾지 못했습니다" in output


# ── Manual credentials input tests ───────────────────────────────


class TestManualCredentialsInput:
    """Tests for _manual_credentials_input() — manual path fallback."""

    def test_valid_path_copies_file(self, config, console, tmp_path):
        """Should copy file to config dir when given a valid path."""
        source = tmp_path / "my_creds.json"
        source.write_text('{"installed": {"client_id": "manual"}}')

        with patch(
            "gdrive_organizer.auth.setup_guide.typer.prompt",
            return_value=str(source),
        ):
            result = _manual_credentials_input(config, console)

        assert result is True
        assert config.credentials_path.exists()
        content = json.loads(config.credentials_path.read_text())
        assert content["installed"]["client_id"] == "manual"

    def test_quit_returns_false(self, config, console):
        """Entering 'q' should abort."""
        with patch(
            "gdrive_organizer.auth.setup_guide.typer.prompt",
            return_value="q",
        ):
            result = _manual_credentials_input(config, console)

        assert result is False

    def test_nonexistent_path_returns_false(self, config, console):
        """Providing a path that doesn't exist should fail gracefully."""
        with patch(
            "gdrive_organizer.auth.setup_guide.typer.prompt",
            return_value="/nonexistent/path/creds.json",
        ):
            result = _manual_credentials_input(config, console)

        assert result is False
        output = console.file.getvalue()
        assert "찾을 수 없습니다" in output

    def test_abort_returns_false(self, config, console):
        """Ctrl+C (typer.Abort) should return False."""
        with patch(
            "gdrive_organizer.auth.setup_guide.typer.prompt",
            side_effect=typer.Abort(),
        ):
            result = _manual_credentials_input(config, console)

        assert result is False


# ── OAuth login step tests ───────────────────────────────────────


class TestStepOAuthLogin:
    """Tests for _step_oauth_login() — final login verification."""

    def test_success_shows_account_info(self, config, console):
        """Successful login should display user info and next steps."""
        with patch(_PATCH_GET_SERVICE, return_value=_mock_service()):
            _step_oauth_login(config, console)

        output = console.file.getvalue()
        assert "설정 완료" in output
        assert "Test User" in output
        assert "test@example.com" in output
        assert "gdrive-organizer scan" in output

    def test_failure_exits_with_error(self, config, console):
        """OAuth failure should print error and raise typer.Exit."""
        with (
            patch(
                _PATCH_GET_SERVICE,
                side_effect=RuntimeError("connection failed"),
            ),
            pytest.raises((SystemExit, typer.Exit)),
        ):
            _step_oauth_login(config, console)

        output = console.file.getvalue()
        assert "로그인 실패" in output


# ── detect_and_login integration tests ───────────────────────────


class TestStepDetectAndLogin:
    """Tests for _step_detect_and_login() — Step 5 full flow."""

    def test_credentials_already_exist(self, config, console):
        """When credentials.json already exists, skip detection."""
        _write_credentials(config)

        with patch(_PATCH_GET_SERVICE, return_value=_mock_service()):
            _step_detect_and_login(config, console)

        output = console.file.getvalue()
        assert "이미 존재" in output
        assert "설정 완료" in output

    def test_detection_fails_manual_fails_exits(self, config, console):
        """When both auto-detect and manual input fail, should exit."""
        with (
            patch(
                "gdrive_organizer.auth.setup_guide._wait_for_credentials",
                return_value=False,
            ),
            patch(
                "gdrive_organizer.auth.setup_guide._manual_credentials_input",
                return_value=False,
            ),
            pytest.raises((SystemExit, typer.Exit)),
        ):
            _step_detect_and_login(config, console)

        output = console.file.getvalue()
        assert "찾지 못했습니다" in output
