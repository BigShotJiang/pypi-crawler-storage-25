"""Tests for failure transparency — scanner error handling, LLM client error paths."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from gdrive_organizer.ai.classifier import GrokClient, LLMError

# --- B1: Scanner error narrowing ---


class TestScannerErrorHandling:
    def test_http_error_caught_gracefully(self):
        """HttpError from permissions fetch should be caught, not re-raised."""
        from googleapiclient.errors import HttpError

        from gdrive_organizer.scanner.crawler import enrich_permissions_for_shared

        service = MagicMock()
        http_err = HttpError(MagicMock(status=403), b"forbidden")
        service.permissions.return_value.list.return_value.execute.side_effect = http_err

        files = [{"id": "f1", "ownedByMe": True, "shared": True}]
        # Should NOT raise — HttpError is caught gracefully
        count = enrich_permissions_for_shared(service, files, delay=0)
        assert count == 0
        assert files[0]["permissions"] == []

    def test_unexpected_error_propagates(self):
        """Non-HttpError (e.g. programming bug) should propagate, not be swallowed."""
        from gdrive_organizer.scanner.crawler import enrich_permissions_for_shared

        service = MagicMock()
        service.permissions.return_value.list.return_value.execute.side_effect = RuntimeError(
            "unexpected bug"
        )

        files = [{"id": "f1", "ownedByMe": True, "shared": True}]
        with pytest.raises(RuntimeError, match="unexpected bug"):
            enrich_permissions_for_shared(service, files, delay=0)

    def test_revision_http_error_caught(self):
        """HttpError from revision fetch should be caught gracefully."""
        from googleapiclient.errors import HttpError

        from gdrive_organizer.scanner.crawler import enrich_revisions

        service = MagicMock()
        http_err = HttpError(MagicMock(status=404), b"not found")
        service.revisions.return_value.list.return_value.execute.side_effect = http_err

        files = [{"id": "f1", "mimeType": "text/plain"}]
        # Should NOT raise
        enrich_revisions(service, files, max_files=1, delay=0)
        assert files[0]["revisionCount"] == 0

    def test_revision_unexpected_error_propagates(self):
        """Non-HttpError in revision fetch should propagate."""
        from gdrive_organizer.scanner.crawler import enrich_revisions

        service = MagicMock()
        service.revisions.return_value.list.return_value.execute.side_effect = TypeError("bug")

        files = [{"id": "f1", "mimeType": "text/plain"}]
        with pytest.raises(TypeError, match="bug"):
            enrich_revisions(service, files, max_files=1, delay=0)


# --- B2: LLM client error transparency ---


class TestLLMClientErrors:
    def test_non_rate_limit_error_raises_llm_error(self):
        """Non-rate-limit exceptions must raise LLMError, not return ''."""
        with patch.object(GrokClient, "__init__", lambda self, *a, **kw: None):
            client = GrokClient.__new__(GrokClient)
            client.model = "test"
            client.client = MagicMock()
            client._semaphore = asyncio.Semaphore(1)

            # Mock create to raise a generic error
            mock_create = AsyncMock(side_effect=ConnectionError("network down"))
            client.client.chat.completions.create = mock_create

            with pytest.raises(LLMError, match="LLM API call failed"):
                asyncio.run(client.chat("system", "user"))

    def test_rate_limit_is_retried_then_raised(self):
        """RateLimitError should be retried, then raised (not swallowed)."""
        from openai import RateLimitError

        with patch.object(GrokClient, "__init__", lambda self, *a, **kw: None):
            client = GrokClient.__new__(GrokClient)
            client.model = "test"
            client.client = MagicMock()
            client._semaphore = asyncio.Semaphore(1)

            mock_resp = MagicMock()
            mock_resp.status_code = 429
            mock_resp.headers = {}
            rate_err = RateLimitError(
                message="rate limited",
                response=mock_resp,
                body=None,
            )
            client.client.chat.completions.create = AsyncMock(side_effect=rate_err)

            with pytest.raises(RateLimitError):
                asyncio.run(client._call_with_retry("sys", "usr", 0.1, max_retries=2))

    def test_llm_error_is_importable(self):
        """LLMError should be importable for caller-side handling."""
        from gdrive_organizer.ai.classifier import LLMError

        assert issubclass(LLMError, Exception)
        err = LLMError("test")
        assert str(err) == "test"
