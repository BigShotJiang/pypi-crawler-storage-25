"""Tests for approved-plan source selection and lifecycle."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from gdrive_organizer.ai.planner import (
    approved_plan_path,
    load_plan,
    resolve_plan_path,
    save_plan,
)
from gdrive_organizer.cli import app
from gdrive_organizer.executor.runner import ExecutionResult
from gdrive_organizer.models import ExecutionPlan, OperationType, PlanOperation


def _make_plan(name: str, operation_count: int = 1) -> ExecutionPlan:
    operations = [
        PlanOperation(
            file_id=f"{name}-{idx}",
            current_name=f"{name}-{idx}.txt",
            current_path=f"root/{name}-{idx}.txt",
            operation=OperationType.MOVE,
            new_parent_id="target-folder",
            current_parent_id="source-folder",
            new_path=f"보관함/{name}-{idx}.txt",
            reason=f"move {name} {idx}",
        )
        for idx in range(operation_count)
    ]
    return ExecutionPlan(
        created_at=datetime(2026, 4, 13, 9, 0, tzinfo=UTC),
        preset_id="migration",
        operations=operations,
        stats={
            "total_operations": len(operations),
            "moves": len(operations),
        },
    )


def _write_plan(path: Path, plan: ExecutionPlan) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(plan.model_dump_json(indent=2))


def test_resolve_plan_path_prefers_approved(config):
    latest_path = config.data_dir / "plans" / "plan-2026-04-13T09-00-00.json"
    _write_plan(latest_path, _make_plan("latest"))
    _write_plan(approved_plan_path(config), _make_plan("approved"))

    resolved = resolve_plan_path(config)

    assert resolved == approved_plan_path(config)


def test_save_plan_invalidates_existing_approved(config):
    approved = approved_plan_path(config)
    _write_plan(approved, _make_plan("approved"))

    save_plan(_make_plan("latest"), config)

    assert not approved.exists()
    archived = list((config.data_dir / "plans").glob("approved-invalidated-*.json"))
    assert len(archived) == 1


def test_cli_plan_show_uses_approved_by_default(config, monkeypatch):
    runner = CliRunner()
    latest_path = config.data_dir / "plans" / "plan-2026-04-13T09-00-00.json"
    _write_plan(latest_path, _make_plan("latest"))
    _write_plan(approved_plan_path(config), _make_plan("approved"))
    monkeypatch.setattr("gdrive_organizer.cli._get_config", lambda: config)

    result = runner.invoke(app, ["plan", "show"])

    assert result.exit_code == 0
    assert "Approved plan: approved-plan.json" in result.stdout


def test_cli_plan_apply_dry_run_uses_approved_by_default(config, monkeypatch):
    runner = CliRunner()
    latest_path = config.data_dir / "plans" / "plan-2026-04-13T09-00-00.json"
    _write_plan(latest_path, _make_plan("latest"))
    _write_plan(approved_plan_path(config), _make_plan("approved"))
    monkeypatch.setattr("gdrive_organizer.cli._get_config", lambda: config)

    result = runner.invoke(app, ["plan", "apply", "--dry-run"])

    assert result.exit_code == 0
    assert "Approved plan: approved-plan.json" in result.stdout
    assert "Dry run complete: 1 operations previewed." in result.stdout


def test_cli_plan_apply_latest_plan_bypasses_approved(config, monkeypatch):
    runner = CliRunner()
    latest_path = config.data_dir / "plans" / "plan-2026-04-13T09-00-00.json"
    _write_plan(latest_path, _make_plan("latest"))
    _write_plan(approved_plan_path(config), _make_plan("approved"))
    monkeypatch.setattr("gdrive_organizer.cli._get_config", lambda: config)

    result = runner.invoke(app, ["plan", "apply", "--dry-run", "--latest-plan"])

    assert result.exit_code == 0
    assert f"Latest plan: {latest_path.name}" in result.stdout


def test_cli_plan_apply_archives_approved_after_real_execution(config, monkeypatch):
    runner = CliRunner()
    approved = approved_plan_path(config)
    plan = _make_plan("approved")
    _write_plan(approved, plan)
    monkeypatch.setattr("gdrive_organizer.cli._get_config", lambda: config)

    fake_log = config.data_dir / "logs" / "rollback-2026-04-13T09-05-00.json"
    fake_log.parent.mkdir(parents=True, exist_ok=True)
    fake_log.write_text("{}")

    with (
        patch("gdrive_organizer.auth.oauth.get_drive_service", return_value=MagicMock()),
        patch(
            "gdrive_organizer.executor.runner.PlanRunner.execute",
            return_value=ExecutionResult(
                success_count=1,
                rollback_log_path=fake_log,
            ),
        ),
    ):
        result = runner.invoke(app, ["plan", "apply", "--yes"])

    assert result.exit_code == 0
    assert not approved.exists()
    archived = list((config.data_dir / "plans").glob("approved-applied-*.json"))
    assert len(archived) == 1
    assert load_plan(archived[0]).operations[0].file_id == plan.operations[0].file_id


def test_cli_plan_apply_keeps_approved_when_execution_never_starts(config, monkeypatch):
    runner = CliRunner()
    approved = approved_plan_path(config)
    _write_plan(approved, _make_plan("approved"))
    monkeypatch.setattr("gdrive_organizer.cli._get_config", lambda: config)

    with (
        patch("gdrive_organizer.auth.oauth.get_drive_service", return_value=MagicMock()),
        patch(
            "gdrive_organizer.executor.runner.PlanRunner.execute",
            return_value=ExecutionResult(
                success_count=0,
                failure_count=1,
                errors=[{"file_id": "_stale_snapshot", "error": "stale"}],
                rollback_log_path=None,
            ),
        ),
    ):
        result = runner.invoke(app, ["plan", "apply", "--yes"])

    assert result.exit_code == 0
    assert approved.exists()
    archived = list((config.data_dir / "plans").glob("approved-applied-*.json"))
    assert archived == []
