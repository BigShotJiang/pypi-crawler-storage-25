"""Global search navigation E2E."""

from __future__ import annotations

import re

from playwright.sync_api import Page, expect


def test_enter_in_sidebar_search_navigates_to_explorer_with_query(live_server: str, page: Page):
    """Typing a query and pressing Enter in the sidebar navigates to /explorer?q=<query>."""
    page.goto(f"{live_server}/")

    search = page.locator("#global-search")
    expect(search).to_be_visible()

    search.fill("report")
    search.press("Enter")

    expect(page).to_have_url(re.compile(r"/explorer\?q=report$"))


def test_sidebar_search_does_nothing_on_empty_submit(live_server: str, page: Page):
    """Empty query must not navigate away."""
    page.goto(f"{live_server}/")
    start_url = page.url

    page.locator("#global-search").press("Enter")

    # Let any (unwanted) navigation fire
    page.wait_for_timeout(150)
    assert page.url == start_url, f"navigated unexpectedly: {start_url} -> {page.url}"
