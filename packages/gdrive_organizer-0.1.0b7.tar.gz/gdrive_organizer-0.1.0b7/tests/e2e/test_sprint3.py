"""Sprint 3 E2E: dashboard freshness chips, plan diff highlighting, expandable last-applied panel."""

from __future__ import annotations

import json

import pytest
from playwright.sync_api import Page, expect


@pytest.fixture
def seeded_plan(seeded_snapshot, config):
    """Plan with one rename op whose diff is easy to assert visually."""
    plan = {
        "created_at": "2026-04-12T11:30:00Z",
        "operations": [
            {
                "file_id": "file1",
                "current_name": "report.pdf",
                "current_path": "/Documents/report.pdf",
                "operation": "rename",
                "new_name": "report (final).pdf",
            },
        ],
        "stats": {"total_operations": 1},
    }
    (config.data_dir / "plans" / "plan-2026-04-12T11-30-00.json").write_text(json.dumps(plan))
    return config


@pytest.fixture
def with_rollback_log_mixed(config):
    """Rollback log with ok + failed ops for summary-count testing."""
    logs = config.data_dir / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    (logs / "rollback-2026-04-11T10-00-00.json").write_text(
        json.dumps(
            {
                "executedAt": "2026-04-11T10:00:00+00:00",
                "planRef": "2026-04-11T09:00:00",
                "operations": [
                    {"fileId": "f1", "type": "move", "status": "ok", "before": {"name": "a.txt"}},
                    {"fileId": "f2", "type": "move", "status": "ok", "before": {"name": "b.txt"}},
                    {
                        "fileId": "f3",
                        "type": "rename",
                        "status": "failed",
                        "before": {"name": "c.txt"},
                    },
                ],
            }
        )
    )
    return logs


# ── Dashboard freshness chips ──────────────────────────────────────────


def test_dashboard_shows_last_scan_chip(live_server: str, page: Page):
    page.goto(f"{live_server}/")
    chips = page.locator("#freshness-chips")
    expect(chips).to_be_visible()
    expect(chips).to_contain_text("Last scan")


def test_dashboard_shows_last_classify_chip_when_plan_exists(live_server: str, page: Page):
    page.goto(f"{live_server}/")
    chips = page.locator("#freshness-chips")
    expect(chips).to_contain_text("Last classify")


# ── Plan diff highlighting ─────────────────────────────────────────────


def test_plan_op_highlights_added_middle_on_after_side(live_server: str, page: Page):
    """The 'after' card must show both common parts (report, .pdf) and the added middle '(final)'."""
    page.goto(f"{live_server}/plan")
    expect(page.locator(".plan-check")).to_have_count(1)

    # Scope to the plan container to avoid matching the 'Select Safe Only' button (also bg-green-50)
    after_card = page.locator("#plan-container .bg-green-50").first
    expect(after_card).to_contain_text("report")
    expect(after_card).to_contain_text("(final)")


def test_plan_op_renders_before_side_without_error(live_server: str, page: Page):
    """The 'before' card renders the original name/path cleanly."""
    page.goto(f"{live_server}/plan")
    expect(page.locator(".plan-check")).to_have_count(1)

    before_card = page.locator("#plan-container .bg-red-50").first
    expect(before_card).to_contain_text("report.pdf")


# ── Expandable last-applied panel ──────────────────────────────────────


def test_last_applied_summary_shows_ok_and_failed_counts(
    with_rollback_log_mixed, live_server: str, page: Page
):
    page.goto(f"{live_server}/plan")
    panel = page.locator("#last-applied-panel")
    expect(panel).to_be_visible()
    expect(panel).to_contain_text("2 ok")
    expect(panel).to_contain_text("1 failed")


def test_last_applied_details_toggle_expands_and_lists_operations(
    with_rollback_log_mixed, live_server: str, page: Page
):
    page.goto(f"{live_server}/plan")
    panel = page.locator("#last-applied-panel")
    expect(panel).to_be_visible()

    # Details not shown initially
    expect(panel).not_to_contain_text("a.txt")

    panel.get_by_role("button", name="Show details").click()

    # After expand, per-op rows visible
    expect(panel).to_contain_text("a.txt")
    expect(panel).to_contain_text("b.txt")
    expect(panel).to_contain_text("c.txt")
    # Button text flipped
    expect(panel.get_by_role("button", name="Hide details")).to_be_visible()
