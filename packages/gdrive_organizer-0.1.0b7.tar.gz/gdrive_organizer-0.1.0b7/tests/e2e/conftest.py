"""E2E fixtures: live uvicorn server + seeded snapshot/plan.

The parent tests/conftest.py provides the `config` fixture; here we layer on a
real HTTP server spun up in a background thread so Playwright can drive it.

Tests in this directory are opt-in: default pytest collection excludes them
(see pyproject.toml `norecursedirs`). Run explicitly with `just e2e` or
`pytest tests/e2e`.
"""

from __future__ import annotations

import json
import socket
import threading
import time

import pytest
import uvicorn

from gdrive_organizer.store.snapshot import save_snapshot
from gdrive_organizer.viewer.app import create_app


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _ThreadedUvicorn(uvicorn.Server):
    """Uvicorn server that does not install signal handlers (so it can run in a thread)."""

    def install_signal_handlers(self):  # noqa: D401 — uvicorn override
        pass


@pytest.fixture
def seeded_snapshot(config, sample_raw_files):
    """Write a real snapshot into the temp config so the viewer has data to render."""
    save_snapshot(sample_raw_files, "change_token_e2e", config)
    return config


@pytest.fixture
def seeded_plan(seeded_snapshot, config):
    """Write a plan with two operations sharing a file_id so per-op selection is exercised."""
    plan = {
        "created_at": "2026-04-10T00:00:00Z",
        "operations": [
            {
                "file_id": "file1",
                "current_name": "report.docx",
                "current_path": "/Documents/report.docx",
                "operation": "move",
                "proposed_path": "/Work/report.docx",
            },
            {
                "file_id": "file1",
                "current_name": "report.docx",
                "current_path": "/Documents/report.docx",
                "operation": "update_description",
                "proposed_description": "Quarterly report",
            },
            {
                "file_id": "file2",
                "current_name": "photo.jpg",
                "current_path": "/photo.jpg",
                "operation": "rename",
                "proposed_name": "2026-04-01_photo.jpg",
            },
        ],
        "stats": {"total_operations": 3},
    }
    plan_path = config.data_dir / "plans" / "plan-2026-04-10T00-00-00.json"
    plan_path.write_text(json.dumps(plan))
    return plan_path


@pytest.fixture
def live_server(seeded_plan, config):
    """Start the viewer on a random free port in a background thread; yield its URL."""
    port = _free_port()
    app = create_app(config)
    ucfg = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", access_log=False)
    server = _ThreadedUvicorn(config=ucfg)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    # Wait for startup (up to 5s)
    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline:
        if server.started:
            break
        time.sleep(0.05)
    else:
        raise RuntimeError("live_server failed to start within 5s")

    yield f"http://127.0.0.1:{port}"

    server.should_exit = True
    thread.join(timeout=5)
