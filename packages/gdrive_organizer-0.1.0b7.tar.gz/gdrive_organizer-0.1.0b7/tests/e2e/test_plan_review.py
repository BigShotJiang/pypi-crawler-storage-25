"""Plan Review E2E: the browser-only behaviors that backend tests cannot catch.

Pins the regressions that only showed up in real browser interactions:
  1. Filter change must not reset checkbox state
  2. Approve payload must send per-operation IDs (not per-file), so two ops
     sharing a file_id can be approved independently
"""

from __future__ import annotations

from playwright.sync_api import Page, expect


def test_filter_change_preserves_deselected_state(live_server: str, page: Page):
    """Deselect op-0, filter to 'rename', filter back to 'all' → op-0 must stay unchecked."""
    page.goto(f"{live_server}/plan")

    # Wait for the 3 seeded ops to render
    expect(page.locator(".plan-check")).to_have_count(3)
    first = page.locator(".plan-check").first
    expect(first).to_be_checked()

    first.uncheck()
    expect(first).not_to_be_checked()

    # Filter to a single type — hides the unchecked one
    page.locator("#plan-filter").select_option("rename")
    expect(page.locator(".plan-check")).to_have_count(1)

    # Back to all — the previously unchecked op must still be unchecked
    page.locator("#plan-filter").select_option("all")
    expect(page.locator(".plan-check")).to_have_count(3)
    expect(page.locator(".plan-check").first).not_to_be_checked()


def test_approve_sends_operation_ids_and_per_op_selection_is_honored(live_server: str, page: Page):
    """The approve payload must use approved_operation_ids. Two ops with the same
    file_id must be independently selectable."""
    page.goto(f"{live_server}/plan")
    expect(page.locator(".plan-check")).to_have_count(3)

    # Deselect op-1 (the update_description for file1). op-0 (move for file1) stays checked.
    page.locator(".plan-check").nth(1).uncheck()

    with page.expect_request(
        lambda r: r.url.endswith("/api/plan/approve") and r.method == "POST"
    ) as req_info:
        page.get_by_role("button", name="Approve Selected").click()

    body = req_info.value.post_data_json
    assert body is not None, "approve request had no JSON body"
    assert "approved_operation_ids" in body, f"expected per-op ids, payload keys were: {list(body)}"
    ids = body["approved_operation_ids"]
    assert set(ids) == {"op-0", "op-2"}, f"expected op-0 and op-2 only, got {ids}"
