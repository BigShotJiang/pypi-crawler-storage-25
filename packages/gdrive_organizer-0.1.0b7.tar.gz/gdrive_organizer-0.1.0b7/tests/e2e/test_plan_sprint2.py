"""Sprint 2 Plan Review E2E: name search, bulk actions, approved-plan banner, last-applied panel.

Overrides the conftest `seeded_plan` fixture to provide a richer plan (including
a TRASH op) plus an approved-plan.json and a rollback log, so the new UI surfaces
have real data to render.
"""

from __future__ import annotations

import json
import re

import pytest
from playwright.sync_api import Page, expect

# ── fixtures: override seeded_plan, add approved plan + rollback log ───────


@pytest.fixture
def seeded_plan(seeded_snapshot, config):
    plan = {
        "created_at": "2026-04-10T00:00:00Z",
        "operations": [
            {
                "file_id": "file1",
                "current_name": "report.docx",
                "current_path": "/Documents/report.docx",
                "operation": "move",
                "proposed_path": "/Work/report.docx",
            },
            {
                "file_id": "file2",
                "current_name": "photo.jpg",
                "current_path": "/photo.jpg",
                "operation": "rename",
                "proposed_name": "2026-04-01_photo.jpg",
            },
            {
                "file_id": "file3",
                "current_name": "notes.txt",
                "current_path": "/Documents/notes.txt",
                "operation": "trash",
            },
        ],
        "stats": {"total_operations": 3},
    }
    plan_path = config.data_dir / "plans" / "plan-2026-04-10T00-00-00.json"
    plan_path.write_text(json.dumps(plan))
    return plan_path


@pytest.fixture
def with_approved_plan(seeded_plan, config):
    """Write an approved-plan.json containing a single op subset."""
    approved = config.data_dir / "plans" / "approved-plan.json"
    approved.write_text(
        json.dumps(
            {
                "created_at": "2026-04-10T00:00:00Z",
                "operations": [
                    {
                        "file_id": "file2",
                        "current_name": "photo.jpg",
                        "current_path": "/photo.jpg",
                        "operation": "rename",
                        "proposed_name": "2026-04-01_photo.jpg",
                    }
                ],
                "stats": {"total_operations": 1},
            }
        )
    )
    return approved


@pytest.fixture
def with_rollback_log(config):
    """Write a rollback log so /api/last-applied has content to return."""
    logs_dir = config.data_dir / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)
    log_path = logs_dir / "rollback-2026-04-11T10-00-00.json"
    log_path.write_text(
        json.dumps(
            {
                "executedAt": "2026-04-11T10:00:00+00:00",
                "planRef": "2026-04-11T09:00:00",
                "operations": [
                    {"fileId": "file1", "type": "move", "before": {}, "after": {}, "status": "ok"},
                    {
                        "fileId": "file2",
                        "type": "rename",
                        "before": {},
                        "after": {},
                        "status": "ok",
                    },
                ],
            }
        )
    )
    return log_path


# ── Name search ────────────────────────────────────────────────────────


def test_plan_name_search_filters_by_current_name(live_server: str, page: Page):
    """Typing into plan-search narrows the list by filename (case-insensitive)."""
    page.goto(f"{live_server}/plan")
    expect(page.locator(".plan-check")).to_have_count(3)

    page.locator("#plan-search").fill("photo")
    expect(page.locator(".plan-check")).to_have_count(1)

    page.locator("#plan-search").fill("")
    expect(page.locator(".plan-check")).to_have_count(3)


def test_plan_name_search_combines_with_type_filter(live_server: str, page: Page):
    """Type filter AND name search must both be satisfied (AND-logic)."""
    page.goto(f"{live_server}/plan")
    expect(page.locator(".plan-check")).to_have_count(3)

    # Filter to rename type → 1 op (photo.jpg)
    page.locator("#plan-filter").select_option("rename")
    expect(page.locator(".plan-check")).to_have_count(1)

    # Search for "notes" (which is a trash op, not rename) → 0 matches
    page.locator("#plan-search").fill("notes")
    expect(page.locator(".plan-check")).to_have_count(0)

    # Clear type filter, keep name search → should find the notes.txt trash op
    page.locator("#plan-filter").select_option("all")
    expect(page.locator(".plan-check")).to_have_count(1)


# ── Bulk actions ───────────────────────────────────────────────────────


def test_bulk_deselect_all_trash_button_only_shown_when_trash_ops_exist(
    live_server: str, page: Page
):
    """The TRASH button is visible only when the plan contains trash ops and shows the count."""
    page.goto(f"{live_server}/plan")
    expect(page.locator(".plan-check")).to_have_count(3)

    trash_btn = page.locator("#bulk-deselect-trash")
    expect(trash_btn).to_be_visible()
    expect(page.locator("#bulk-trash-count")).to_have_text("1")


def test_bulk_select_safe_only_excludes_trash(live_server: str, page: Page):
    """Select Safe Only leaves move+rename checked and trash unchecked."""
    page.goto(f"{live_server}/plan")
    expect(page.locator(".plan-check")).to_have_count(3)

    page.get_by_role("button", name="Select Safe Only").click()

    # All visible checkboxes still rendered; trash one must be unchecked, others checked
    checks = page.locator(".plan-check")
    expect(checks).to_have_count(3)

    # op-0 (move) and op-1 (rename) checked, op-2 (trash) unchecked
    expect(checks.nth(0)).to_be_checked()
    expect(checks.nth(1)).to_be_checked()
    expect(checks.nth(2)).not_to_be_checked()


def test_bulk_deselect_all_trash_removes_trash_from_selection(live_server: str, page: Page):
    """The dedicated deselect-trash button removes only the trash op from selection."""
    page.goto(f"{live_server}/plan")
    expect(page.locator(".plan-check")).to_have_count(3)

    # Default state: all checked
    for i in range(3):
        expect(page.locator(".plan-check").nth(i)).to_be_checked()

    page.get_by_role("button", name=re.compile(r"Deselect all TRASH")).click()

    expect(page.locator(".plan-check").nth(0)).to_be_checked()
    expect(page.locator(".plan-check").nth(1)).to_be_checked()
    expect(page.locator(".plan-check").nth(2)).not_to_be_checked()


# ── Approved plan banner ───────────────────────────────────────────────


def test_approved_banner_rendered_when_approved_plan_exists(
    with_approved_plan, live_server: str, page: Page
):
    page.goto(f"{live_server}/plan")
    banner = page.locator("#approved-banner")
    expect(banner).to_be_visible()
    expect(banner).to_contain_text("1 operation currently approved")


def test_clear_approval_removes_file_and_hides_banner(
    with_approved_plan, live_server: str, page: Page
):
    """Clicking 'Clear approval' deletes approved-plan.json and hides the banner."""
    page.goto(f"{live_server}/plan")
    banner = page.locator("#approved-banner")
    expect(banner).to_be_visible()

    # Accept the native confirm() dialog
    page.once("dialog", lambda d: d.accept())

    with page.expect_response(
        lambda r: r.url.endswith("/api/plan/approve") and r.request.method == "DELETE"
    ) as resp_info:
        page.get_by_role("button", name="Clear approval").click()

    assert resp_info.value.status == 200
    assert resp_info.value.json()["status"] == "cleared"

    # After loadPlan reruns, banner should be hidden
    expect(banner).to_be_hidden()


# ── Last-applied panel ─────────────────────────────────────────────────


def test_last_applied_panel_shows_rollback_log_metadata(
    with_rollback_log, live_server: str, page: Page
):
    page.goto(f"{live_server}/plan")
    panel = page.locator("#last-applied-panel")
    expect(panel).to_be_visible()
    expect(panel).to_contain_text("2 operations")
    # The copy-pasteable CLI command must be present
    expect(panel).to_contain_text("gdrive-organizer plan rollback")


def test_last_applied_panel_hidden_when_no_logs(live_server: str, page: Page):
    page.goto(f"{live_server}/plan")
    expect(page.locator("#last-applied-panel")).to_be_hidden()
