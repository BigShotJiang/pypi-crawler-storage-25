"""Tests for viewer safety gates — session token, confirmation barrier, empty state."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

import pytest
from starlette.testclient import TestClient

from gdrive_organizer.store.snapshot import save_snapshot
from gdrive_organizer.viewer.app import create_app

# config fixture provided by conftest.py


@pytest.fixture
def app(config):
    return create_app(config)


@pytest.fixture
def client(app):
    return TestClient(app)


def _plan_doc(operations: list[dict]) -> dict:
    normalized = []
    for op in operations:
        normalized.append(
            {
                "file_id": op["file_id"],
                "current_name": op.get("current_name", op["file_id"]),
                "current_path": op.get("current_path", f"/{op['file_id']}"),
                "operation": op["operation"],
            }
        )
    return {
        "created_at": "2026-04-10T00:00:00Z",
        "operations": normalized,
        "stats": {"total_operations": len(normalized)},
    }


# --- Session Token ---


class TestSessionToken:
    def test_index_sets_session_cookie(self, client):
        resp = client.get("/")
        assert resp.status_code == 200
        assert "drivecore_session" in resp.cookies

    def test_plan_page_also_sets_session_cookie(self, client):
        """Cookie must be set on all pages, not just /."""
        resp = client.get("/plan")
        assert resp.status_code == 200
        assert "drivecore_session" in resp.cookies

    def test_approve_works_from_plan_page_cookie(self, client, config):
        """User can go directly to /plan and approve without visiting / first."""
        plans_dir = config.data_dir / "plans"
        plan_data = _plan_doc([{"file_id": "f1", "operation": "move"}])
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(json.dumps(plan_data))
        cookies = client.get("/plan").cookies
        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True},
            cookies=cookies,
        )
        assert resp.status_code == 200
        assert resp.json()["status"] == "approved"

    def test_approve_without_session_returns_403(self, client):
        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": [], "confirmed": True},
        )
        assert resp.status_code == 403

    def test_approve_with_valid_session_works(self, client, config):
        # First get the cookie
        index_resp = client.get("/")
        cookies = index_resp.cookies

        # Create a plan file for the endpoint to find
        plans_dir = config.data_dir / "plans"
        plan_data = _plan_doc([{"file_id": "f1", "operation": "move", "current_name": "a.txt"}])
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(json.dumps(plan_data))

        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True},
            cookies=cookies,
        )
        assert resp.status_code == 200
        data = resp.json()
        assert data["status"] == "approved"

    def test_apikey_set_without_session_returns_403(self, client):
        resp = client.post(
            "/api/apikey/set",
            json={"api_key": "test-key"},
        )
        assert resp.status_code == 403

    def test_apikey_delete_without_session_returns_403(self, client):
        resp = client.delete("/api/apikey")
        assert resp.status_code == 403


# --- Confirmation Barrier ---


class TestConfirmationBarrier:
    def _setup_plan(self, config, operations):
        plans_dir = config.data_dir / "plans"
        plan_data = _plan_doc(operations)
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(json.dumps(plan_data))

    def test_approve_without_confirmed_returns_summary(self, client, config):
        self._setup_plan(
            config,
            [
                {"file_id": "f1", "operation": "move", "current_name": "a.txt"},
                {"file_id": "f2", "operation": "trash", "current_name": "b.txt"},
            ],
        )
        cookies = client.get("/").cookies

        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1", "f2"], "confirmed": False},
            cookies=cookies,
        )
        data = resp.json()
        assert data["status"] == "confirmation_required"
        assert data["trash_count"] == 1
        assert data["operations"] == 2
        assert "summary" in data

    def test_approve_with_confirmed_true_proceeds(self, client, config):
        self._setup_plan(
            config,
            [
                {"file_id": "f1", "operation": "move", "current_name": "a.txt"},
            ],
        )
        cookies = client.get("/").cookies

        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True},
            cookies=cookies,
        )
        data = resp.json()
        assert data["status"] == "approved"
        assert data["operations"] == 1

    def test_trash_ops_require_trash_confirmed_flag(self, client, config):
        """Server enforces separate trash_confirmed for plans with TRASH ops."""
        self._setup_plan(
            config,
            [
                {"file_id": "f1", "operation": "trash", "current_name": "junk.txt"},
            ],
        )
        cookies = client.get("/").cookies

        # confirmed=True but no trash_confirmed → server rejects
        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True},
            cookies=cookies,
        )
        data = resp.json()
        assert data["status"] == "trash_confirmation_required"

    def test_trash_ops_pass_with_both_flags(self, client, config):
        """TRASH ops pass when both confirmed and trash_confirmed are set."""
        self._setup_plan(
            config,
            [
                {"file_id": "f1", "operation": "trash", "current_name": "junk.txt"},
            ],
        )
        cookies = client.get("/").cookies

        resp = client.post(
            "/api/plan/approve",
            json={"approved_ids": ["f1"], "confirmed": True, "trash_confirmed": True},
            cookies=cookies,
        )
        data = resp.json()
        assert data["status"] == "approved"

    def test_approve_can_select_one_operation_from_duplicate_file_id(self, client, config):
        self._setup_plan(
            config,
            [
                {"file_id": "f1", "operation": "move", "current_name": "a.txt"},
                {
                    "file_id": "f1",
                    "operation": "update_description",
                    "current_name": "a.txt",
                },
            ],
        )
        cookies = client.get("/").cookies

        resp = client.post(
            "/api/plan/approve",
            json={"approved_operation_ids": ["op-0"], "confirmed": True},
            cookies=cookies,
        )

        assert resp.status_code == 200
        assert resp.json()["operations"] == 1
        approved = json.loads((config.data_dir / "plans" / "approved-plan.json").read_text())
        assert len(approved["operations"]) == 1
        assert approved["operations"][0]["operation"] == "move"


# --- Empty State ---


class TestEmptyState:
    """All read endpoints must return a clean empty response, never 500."""

    @pytest.mark.parametrize(
        "path",
        [
            "/api/stats",
            "/api/tree",
            "/api/files",
            "/api/permissions",
            "/api/duplicates",
            "/api/file/nonexistent",
            "/api/shared-with-me",
            "/api/shared-by-me",
            "/api/drive-info",
        ],
    )
    def test_read_endpoint_returns_empty_on_no_snapshot(self, client, path):
        resp = client.get(path)
        assert resp.status_code == 200
        data = resp.json()
        assert data.get("empty") is True
        assert "message" in data

    def test_plan_returns_none_when_no_plan(self, client):
        resp = client.get("/api/plan")
        assert resp.status_code == 200
        data = resp.json()
        assert data["plan"] is None
        assert data["approved_plan_present"] is False
        assert data["approved_operation_count"] == 0


class TestSnapshotAutoReload:
    """#J3 regression: SnapshotCache must pick up a newer snapshot file
    on the next request, without requiring viewer restart. Otherwise the
    user runs scan/classify/apply and the dashboard keeps showing stale
    data until they manually restart the server."""

    def test_cache_invalidates_when_snapshot_mtime_advances(self, client, config, sample_raw_files):
        # First snapshot — minimal so we can tell the two responses apart
        save_snapshot([sample_raw_files[0]], "tok1", config)
        first = client.get("/api/stats").json()
        assert first["total_files_count"] == 1

        # Save a richer snapshot. save_snapshot updates latest.json.gz to
        # point at the new file with a newer mtime.
        import time

        time.sleep(0.05)  # ensure mtime ticks even on coarse-grained FS
        save_snapshot(sample_raw_files, "tok2", config)

        second = client.get("/api/stats").json()
        # Auto-reload picks up the new snapshot — count grew without
        # any explicit cache invalidation call from the test.
        assert second["total_files_count"] == len(sample_raw_files)

    def test_cache_invalidates_for_tree_endpoint_too(self, client, config, sample_raw_files):
        """The tree cache derives from snapshot — must reset on advance."""
        save_snapshot([sample_raw_files[0]], "tok1", config)
        first = client.get("/api/tree").json()
        first_count = len(first.get("tree", []))

        import time

        time.sleep(0.05)
        save_snapshot(sample_raw_files, "tok2", config)

        second = client.get("/api/tree").json()
        # Different snapshots should produce different root counts/contents
        assert second != first or len(second.get("tree", [])) >= first_count


class TestRateLimiting:
    def test_rapid_mutation_calls_get_429(self, client, config):
        """Flooding /api/plan/approve should eventually return 429."""
        plans_dir = config.data_dir / "plans"
        plan_data = _plan_doc([{"file_id": "f1", "operation": "move"}])
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(json.dumps(plan_data))
        cookies = client.get("/").cookies

        # Send many rapid requests — should hit 429 within 15 calls
        statuses = []
        for _ in range(15):
            resp = client.post(
                "/api/plan/approve",
                json={"approved_ids": ["f1"], "confirmed": True},
                cookies=cookies,
            )
            statuses.append(resp.status_code)

        assert 429 in statuses, f"Expected 429 in statuses but got: {set(statuses)}"


class TestPlanMetadata:
    def test_api_plan_exposes_approved_metadata(self, client, config):
        plans_dir = config.data_dir / "plans"
        (plans_dir / "plan-2026-04-10T00-00-00.json").write_text(
            json.dumps(_plan_doc([{"file_id": "f1", "operation": "move"}]))
        )
        (plans_dir / "approved-plan.json").write_text(
            json.dumps(_plan_doc([{"file_id": "f1", "operation": "move"}]))
        )

        resp = client.get("/api/plan")

        assert resp.status_code == 200
        data = resp.json()
        assert data["approved_plan_present"] is True
        assert data["approved_operation_count"] == 1
        assert data["approved_source"] == "approved-plan.json"
        assert data["plan"]["operations"][0]["viewer_operation_id"] == "op-0"


class TestClearApproval:
    def test_delete_without_session_returns_403(self, client):
        resp = client.delete("/api/plan/approve")
        assert resp.status_code == 403

    def test_delete_removes_approved_plan(self, client, config):
        plans_dir = config.data_dir / "plans"
        approved = plans_dir / "approved-plan.json"
        approved.write_text(json.dumps(_plan_doc([{"file_id": "f1", "operation": "move"}])))
        cookies = client.get("/plan").cookies

        resp = client.delete("/api/plan/approve", cookies=cookies)

        assert resp.status_code == 200
        assert resp.json()["status"] == "cleared"
        assert not approved.exists()

    def test_delete_when_no_approved_plan_is_noop(self, client, config):
        cookies = client.get("/plan").cookies
        resp = client.delete("/api/plan/approve", cookies=cookies)
        assert resp.status_code == 200
        assert resp.json()["status"] == "noop"


class TestLastApplied:
    def test_returns_not_present_when_no_logs(self, client):
        resp = client.get("/api/last-applied")
        assert resp.status_code == 200
        assert resp.json() == {"present": False}

    def test_returns_latest_log_metadata(self, client, config):
        logs_dir = config.data_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        (logs_dir / "rollback-2026-04-10T10-00-00.json").write_text(
            json.dumps(
                {
                    "executedAt": "2026-04-10T10:00:00+00:00",
                    "planRef": "2026-04-10T09:00:00",
                    "operations": [{"fileId": "f1"}, {"fileId": "f2"}],
                }
            )
        )
        (logs_dir / "rollback-2026-04-11T10-00-00.json").write_text(
            json.dumps(
                {
                    "executedAt": "2026-04-11T10:00:00+00:00",
                    "planRef": "2026-04-11T09:00:00",
                    "operations": [{"fileId": "f3"}],
                }
            )
        )

        resp = client.get("/api/last-applied")

        assert resp.status_code == 200
        data = resp.json()
        assert data["present"] is True
        # Most recent (reverse-sorted by name → 2026-04-11) should win
        assert data["log_name"] == "rollback-2026-04-11T10-00-00.json"
        assert data["operation_count"] == 1
        assert data["executed_at"] == "2026-04-11T10:00:00+00:00"

    def test_corrupt_log_returns_not_present(self, client, config):
        logs_dir = config.data_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        (logs_dir / "rollback-2026-04-10T10-00-00.json").write_text("{not-json")

        resp = client.get("/api/last-applied")
        assert resp.status_code == 200
        assert resp.json() == {"present": False}

    def test_summary_counts_ok_and_failed(self, client, config):
        logs_dir = config.data_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        (logs_dir / "rollback-2026-04-12T10-00-00.json").write_text(
            json.dumps(
                {
                    "executedAt": "2026-04-12T10:00:00+00:00",
                    "planRef": "x",
                    "operations": [
                        {"fileId": "f1", "type": "move", "status": "ok"},
                        {"fileId": "f2", "type": "move", "status": "ok"},
                        {"fileId": "f3", "type": "rename", "status": "failed"},
                        {"fileId": "f4", "type": "rename", "status": ""},
                    ],
                }
            )
        )
        resp = client.get("/api/last-applied")
        assert resp.status_code == 200
        data = resp.json()
        assert data["summary"] == {"ok": 2, "failed": 1, "other": 1}
        # Summary-only response must not include the ops list
        assert "operations" not in data

    def test_details_true_includes_operation_list(self, client, config):
        logs_dir = config.data_dir / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        (logs_dir / "rollback-2026-04-12T10-00-00.json").write_text(
            json.dumps(
                {
                    "executedAt": "2026-04-12T10:00:00+00:00",
                    "planRef": "x",
                    "operations": [
                        {
                            "fileId": "f1",
                            "type": "move",
                            "status": "ok",
                            "before": {"name": "doc.txt"},
                        },
                        {"fileId": "f2", "type": "rename", "status": "failed"},
                    ],
                }
            )
        )
        resp = client.get("/api/last-applied?details=true")
        assert resp.status_code == 200
        data = resp.json()
        assert "operations" in data
        assert data["operations"][0] == {
            "file_id": "f1",
            "type": "move",
            "status": "ok",
            "name": "doc.txt",
        }
        # Missing `before.name` falls back to file_id
        assert data["operations"][1]["name"] == "f2"


class TestStatsFreshness:
    def test_stats_exposes_last_scan_and_last_classify(self, client, config, saved_snapshot):
        # saved_snapshot fixture already writes a snapshot via save_snapshot
        plans_dir = config.data_dir / "plans"
        (plans_dir / "plan-2026-04-12T11-00-00.json").write_text(
            json.dumps(
                {
                    "created_at": "2026-04-12T11:00:00Z",
                    "operations": [],
                    "stats": {"total_operations": 0},
                }
            )
        )

        resp = client.get("/api/stats")

        assert resp.status_code == 200
        data = resp.json()
        assert data["last_scan_at"] is not None
        assert data["last_classify_at"] == "2026-04-12T11:00:00Z"

    def test_stats_last_classify_is_none_when_no_plans(self, client, saved_snapshot):
        resp = client.get("/api/stats")
        assert resp.status_code == 200
        data = resp.json()
        assert data["last_scan_at"] is not None
        assert data["last_classify_at"] is None


class TestAuthStatus:
    def test_auth_status_never_exposes_client_id_as_email(self, client, config, sample_raw_files):
        config.token_path.parent.mkdir(parents=True, exist_ok=True)
        config.token_path.write_text(
            json.dumps(
                {
                    "token": "abc",
                    "refresh_token": "ref",
                    "token_uri": "https://oauth2.googleapis.com/token",
                    "client_id": "oauth-client-id.apps.googleusercontent.com",
                    "client_secret": "secret",
                    "scopes": ["https://www.googleapis.com/auth/drive"],
                    "expiry": "2026-04-13T12:00:00+00:00",
                }
            )
        )
        save_snapshot(
            sample_raw_files,
            "change-1",
            config,
            drive_info_data={"user_email": "person@example.com"},
        )

        with patch(
            "gdrive_organizer.auth.oauth.Credentials.from_authorized_user_info"
        ) as mock_creds:
            mock_creds.return_value.valid = True
            mock_creds.return_value.expired = False
            mock_creds.return_value.expiry = None
            resp = client.get("/api/auth/status")

        assert resp.status_code == 200
        data = resp.json()
        assert data["authenticated"] is True
        assert data["email"] == "person@example.com"
        assert data["email"] != "oauth-client-id.apps.googleusercontent.com"

    def test_auth_status_marks_expired_token_as_not_connected(self, client, config):
        config.token_path.parent.mkdir(parents=True, exist_ok=True)
        config.token_path.write_text(
            json.dumps(
                {
                    "token": "abc",
                    "refresh_token": "ref",
                    "token_uri": "https://oauth2.googleapis.com/token",
                    "client_id": "oauth-client-id.apps.googleusercontent.com",
                    "client_secret": "secret",
                    "scopes": ["https://www.googleapis.com/auth/drive"],
                    "expiry": "2026-04-13T12:00:00+00:00",
                    "account_email": "person@example.com",
                }
            )
        )

        with patch(
            "gdrive_organizer.auth.oauth.Credentials.from_authorized_user_info"
        ) as mock_creds:
            mock_creds.return_value.valid = False
            mock_creds.return_value.expired = True
            mock_creds.return_value.expiry = None
            resp = client.get("/api/auth/status")

        assert resp.status_code == 200
        data = resp.json()
        assert data["authenticated"] is False
        assert data["expired"] is True


class TestTemplateAssets:
    def test_base_template_uses_local_vendor_assets(self):
        template = (
            Path(__file__).resolve().parents[1]
            / "src"
            / "gdrive_organizer"
            / "viewer"
            / "templates"
            / "base.html"
        ).read_text()

        assert "https://cdn.tailwindcss.com" not in template
        assert "https://unpkg.com" not in template
        # Tailwind is now a proper PostCSS-built stylesheet (not the JIT
        # browser runtime that printed a production warning every page load).
        assert "/static/vendor/tailwind.css" in template
        assert "/static/vendor/tailwindcss-browser.js" not in template
        assert "/static/vendor/lucide.min.js" in template


# --- Page Routes Smoke Test ---


class TestPageRoutes:
    @pytest.mark.parametrize(
        "path",
        ["/", "/explorer", "/plan", "/permissions", "/duplicates", "/settings"],
    )
    def test_pages_return_200(self, client, path):
        resp = client.get(path)
        assert resp.status_code == 200
        assert "text/html" in resp.headers["content-type"]
