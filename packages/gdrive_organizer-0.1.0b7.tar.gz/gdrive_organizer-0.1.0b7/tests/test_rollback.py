"""Tests for rollback correctness — TRASH→UNTRASH, CREATE_FOLDER→TRASH, reverse order."""

from __future__ import annotations

import json

from gdrive_organizer.executor.runner import PlanRunner
from gdrive_organizer.models import OperationType, PlanOperation


class TestBuildReverseOperations:
    """Test _build_reverse_operations produces correct reversal semantics."""

    def _make_runner(self, tmp_path):
        from unittest.mock import MagicMock

        from gdrive_organizer.config import Config

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        return PlanRunner(MagicMock(), config)

    def test_trash_reversed_to_untrash(self, tmp_path):
        """TRASH operations must produce UNTRASH (trashed=false), not RENAME."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "file1",
                    "type": "trash",
                    "before": {"name": "doc.txt", "path": "/docs/doc.txt"},
                    "after": {"name": "doc.txt", "path": "/docs/doc.txt"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.UNTRASH
        assert ops[0].file_id == "file1"
        assert ops[0].reason == "rollback: restore from trash"

    def test_create_folder_reversed_to_trash_with_real_id(self, tmp_path):
        """CREATE_FOLDER must produce TRASH targeting the real Drive ID."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "id_mapping": {"__new_folder_0__": "real_drive_id_abc"},
            "operations": [
                {
                    "fileId": "__new_folder_0__",
                    "type": "create_folder",
                    "realDriveId": "real_drive_id_abc",
                    "before": {},
                    "after": {"name": "보관함", "path": "보관함"},
                    "status": "success",
                }
            ],
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.TRASH
        assert ops[0].file_id == "real_drive_id_abc"  # real ID, not placeholder
        assert "remove created folder" in ops[0].reason

    def test_create_folder_without_real_id_skipped_with_warning(self, tmp_path):
        """CREATE_FOLDER without a real Drive ID cannot be rolled back."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "__new_folder_0__",
                    "type": "create_folder",
                    "before": {},
                    "after": {"name": "orphan"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 0  # Cannot rollback without real ID

    def test_create_folder_uses_id_mapping_fallback(self, tmp_path):
        """If realDriveId is missing but id_mapping has the entry, use that."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "id_mapping": {"__new_folder_0__": "from_mapping_id"},
            "operations": [
                {
                    "fileId": "__new_folder_0__",
                    "type": "create_folder",
                    "before": {},
                    "after": {"name": "test"},
                    "status": "success",
                }
            ],
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].file_id == "from_mapping_id"

    def test_move_reversed_correctly(self, tmp_path):
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "file1",
                    "type": "move",
                    "before": {
                        "name": "doc.txt",
                        "path": "/old/doc.txt",
                        "parent_id": "old_parent",
                    },
                    "after": {"name": "doc.txt", "path": "/new/doc.txt", "parent_id": "new_parent"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.MOVE
        assert ops[0].new_parent_id == "old_parent"
        assert ops[0].current_parent_id == "new_parent"

    def test_failed_operations_skipped(self, tmp_path):
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {"fileId": "f1", "type": "move", "before": {}, "after": {}, "status": "failed"},
                {"fileId": "f2", "type": "trash", "before": {}, "after": {}, "status": "success"},
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].file_id == "f2"

    def test_reverse_order_is_preserved(self, tmp_path):
        """Operations should be reversed in reverse order of execution."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "f1",
                    "type": "trash",
                    "before": {},
                    "after": {"name": "first"},
                    "status": "success",
                },
                {
                    "fileId": "f2",
                    "type": "trash",
                    "before": {},
                    "after": {"name": "second"},
                    "status": "success",
                },
                {
                    "fileId": "f3",
                    "type": "trash",
                    "before": {},
                    "after": {"name": "third"},
                    "status": "success",
                },
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        # Should be reversed: f3, f2, f1
        assert [o.file_id for o in ops] == ["f3", "f2", "f1"]

    def test_shortcut_reversed_to_trash_using_shortcut_drive_id(self, tmp_path):
        """create_shortcut rollback must trash the shortcut by its OWN Drive ID,
        not the target file's ID (entry["fileId"] holds the latter)."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "target_file_id",  # the original file the shortcut points to
                    "realDriveId": "shortcut_drive_id_xyz",  # the new shortcut's own ID
                    "type": "create_shortcut",
                    "before": {},
                    "after": {"name": "link.txt"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.TRASH
        # Critical: must trash the shortcut, NOT the target file
        assert ops[0].file_id == "shortcut_drive_id_xyz"
        assert ops[0].file_id != "target_file_id"

    def test_shortcut_without_real_drive_id_skipped(self, tmp_path):
        """Legacy logs (pre-realDriveId) must skip rather than risk trashing the target."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "target_file_id",
                    "type": "create_shortcut",
                    "before": {},
                    "after": {"name": "link.txt"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert ops == []  # safer to skip than to trash the wrong file

    def test_description_reversed_to_previous(self, tmp_path):
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "f1",
                    "type": "update_description",
                    "before": {"name": "doc.txt", "description": "old desc"},
                    "after": {"name": "doc.txt", "description": "new desc"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.UPDATE_DESCRIPTION
        assert ops[0].new_description == "old desc"

    def test_description_rollback_unsets_when_no_prior_value(self, tmp_path):
        """If the original description was empty/missing (newly added by apply),
        rollback should unset it via empty string — not skip."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "f1",
                    "type": "update_description",
                    "before": {"name": "doc.txt"},  # no prior description
                    "after": {"name": "doc.txt", "description": "new desc"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.UPDATE_DESCRIPTION
        assert ops[0].new_description == ""  # explicit clear


class TestDogfoodRegression:
    """Regressions for bugs found during real-world dogfooding (2026-05-01).

    Each test reproduces a concrete defect that slipped through the original
    test suite because it only covered the typical case.
    """

    def _make_runner(self, tmp_path):
        from unittest.mock import MagicMock

        from gdrive_organizer.config import Config

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        return PlanRunner(MagicMock(), config)

    def test_root_file_move_rollback_returns_to_root(self, tmp_path):
        """A file at My Drive root has parent_id=None in `before`. Reverse move
        must send it back to root (Drive API alias) — not silently fail."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "root_file",
                    "type": "move",
                    "before": {
                        "name": "Vercel report",
                        "path": "Vercel report",
                        "parent_id": None,  # root file
                    },
                    "after": {
                        "name": "Vercel report",
                        "path": "보관함/2026/04/Vercel report",
                        "parent_id": "archive_folder_id",
                    },
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.MOVE
        # Critical: must resolve null parent to "root", not None
        assert ops[0].new_parent_id == "root"
        assert ops[0].current_parent_id == "archive_folder_id"

    def test_shortcut_rollback_does_not_trash_target_file(self, tmp_path):
        """create_shortcut entry's fileId is the *target* file's ID. Rollback
        must use realDriveId (the shortcut's own ID) so the target file is
        never trashed by mistake. This is the worst dogfood bug — data loss."""
        runner = self._make_runner(tmp_path)
        target_file_id = "target_doc_xyz"
        shortcut_drive_id = "new_shortcut_abc"
        rollback_data = {
            "operations": [
                {
                    "fileId": target_file_id,  # target — not the shortcut!
                    "realDriveId": shortcut_drive_id,
                    "type": "create_shortcut",
                    "before": {},
                    "after": {"name": "Vercel report", "path": "리서치/.../Vercel report"},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].operation == OperationType.TRASH
        # Must trash the shortcut, NOT the target the shortcut points at
        assert ops[0].file_id == shortcut_drive_id
        assert ops[0].file_id != target_file_id

    def test_description_added_to_root_file_rollback_clears_it(self, tmp_path):
        """Migration preset adds descriptions to files that didn't have one.
        Rollback must clear (empty string) — not skip."""
        runner = self._make_runner(tmp_path)
        rollback_data = {
            "operations": [
                {
                    "fileId": "doc_id",
                    "type": "update_description",
                    "before": {"name": "doc.txt"},  # no description originally
                    "after": {"name": "doc.txt", "description": "AI summary..."},
                    "status": "success",
                }
            ]
        }
        ops = runner._build_reverse_operations(rollback_data)
        assert len(ops) == 1
        assert ops[0].new_description == ""

    def test_success_count_uniquely_tracks_multiple_ops_per_file(self, tmp_path):
        """A migration plan typically has move + create_shortcut + update_description
        for the same file. success_count must reflect every successful op, not
        just one (file_id was used as a dict key, causing later ops to overwrite
        earlier ones — undercounting by 1+ per file).
        """
        from unittest.mock import patch

        from gdrive_organizer.config import Config
        from gdrive_organizer.models import ExecutionPlan

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        from unittest.mock import MagicMock

        service = MagicMock()
        # Mock files().get() so the trashed-parent guard sees folder_a as live
        service.files().get().execute.return_value = {
            "id": "folder_a",
            "name": "folder_a",
            "trashed": False,
        }
        runner = PlanRunner(service, config)

        # Plan: same file_id, move + update_description
        plan = ExecutionPlan(
            created_at="2026-04-11T00:00:00Z",
            operations=[
                PlanOperation(
                    file_id="file1",
                    current_name="doc.txt",
                    current_path="doc.txt",
                    operation=OperationType.MOVE,
                    new_parent_id="folder_a",
                    current_parent_id=None,
                ),
                PlanOperation(
                    file_id="file1",
                    current_name="doc.txt",
                    current_path="doc.txt",
                    operation=OperationType.UPDATE_DESCRIPTION,
                    new_description="some desc",
                ),
            ],
        )

        with (
            patch("gdrive_organizer.executor.runner.execute_batch") as mock_batch,
            patch("gdrive_organizer.executor.runner.update_description") as mock_desc,
        ):

            def fake_batch(_svc, ops, callback):
                for op in ops:
                    callback(f"{op.file_id}:{op.operation.value}", {"id": op.file_id}, None)

            mock_batch.side_effect = fake_batch
            mock_desc.return_value = {"id": "file1"}

            result = runner.execute(plan, skip_freshness_check=True)

        # Both ops succeeded — must count both, not 1
        assert result.success_count == 2
        assert result.failure_count == 0


class TestTrashedParentGuard:
    """Regression for #J5: a plan whose destination parent is currently in
    trash must be refused at apply time, not silently moved-into. Otherwise
    files vanish from the Drive UI even though the API call succeeded."""

    def _make_runner_with_service(self, tmp_path, trashed_ids: set[str]):
        from unittest.mock import MagicMock

        from gdrive_organizer.config import Config

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        service = MagicMock()

        def fake_get(fileId, fields, supportsAllDrives):  # noqa: ARG001, N803
            request = MagicMock()
            request.execute.return_value = {
                "id": fileId,
                "name": f"folder-{fileId}",
                "trashed": fileId in trashed_ids,
            }
            return request

        service.files().get.side_effect = fake_get
        return PlanRunner(service, config)

    def test_move_into_trashed_parent_aborts(self, tmp_path):
        from gdrive_organizer.models import ExecutionPlan

        runner = self._make_runner_with_service(tmp_path, trashed_ids={"trashed_folder"})
        plan = ExecutionPlan(
            created_at="2026-05-03T00:00:00Z",
            operations=[
                PlanOperation(
                    file_id="file1",
                    current_name="doc.txt",
                    current_path="doc.txt",
                    operation=OperationType.MOVE,
                    new_parent_id="trashed_folder",
                    current_parent_id=None,
                ),
            ],
        )
        result = runner.execute(plan, skip_freshness_check=True)
        assert result.success_count == 0
        assert result.skipped_count == 1
        assert any("trashed_folder" in e["error"] for e in result.errors)
        # The actual update API must not have been called
        runner.service.files().update.assert_not_called()

    def test_placeholder_parent_skipped_by_guard(self, tmp_path):
        """Placeholder __new_folder_* IDs are resolved at Phase 1 — they
        cannot be checked for trashed status and must not abort the apply."""
        from unittest.mock import patch

        from gdrive_organizer.models import ExecutionPlan

        runner = self._make_runner_with_service(tmp_path, trashed_ids=set())
        plan = ExecutionPlan(
            created_at="2026-05-03T00:00:00Z",
            operations=[
                PlanOperation(
                    file_id="__new_folder_0__",
                    current_name="archive",
                    current_path="",
                    operation=OperationType.CREATE_FOLDER,
                    new_path="archive",
                ),
                PlanOperation(
                    file_id="file1",
                    current_name="doc.txt",
                    current_path="doc.txt",
                    operation=OperationType.MOVE,
                    new_parent_id="__new_folder_0__",
                    current_parent_id=None,
                ),
            ],
        )
        with (
            patch("gdrive_organizer.executor.runner.create_folder") as mock_create,
            patch("gdrive_organizer.executor.runner.execute_batch") as mock_batch,
        ):
            mock_create.return_value = {"id": "real_archive_id"}

            def fake_batch(_svc, ops, callback):
                for op in ops:
                    callback(f"{op.file_id}:{op.operation.value}", {"id": op.file_id}, None)

            mock_batch.side_effect = fake_batch

            result = runner.execute(plan, skip_freshness_check=True)

        # Guard didn't abort — Phase 1 + Phase 2 ran normally
        assert result.failure_count == 0

    def test_root_alias_not_checked(self, tmp_path):
        """Drive's `root` alias is never trashed; the guard must skip it
        without making an API call (avoids spurious errors / wasted quota)."""
        from unittest.mock import patch

        from gdrive_organizer.models import ExecutionPlan

        runner = self._make_runner_with_service(tmp_path, trashed_ids=set())
        plan = ExecutionPlan(
            created_at="2026-05-03T00:00:00Z",
            operations=[
                PlanOperation(
                    file_id="file1",
                    current_name="doc.txt",
                    current_path="archive/doc.txt",
                    operation=OperationType.MOVE,
                    new_parent_id="root",
                    current_parent_id="archive_id",
                ),
            ],
        )
        with patch("gdrive_organizer.executor.runner.execute_batch") as mock_batch:

            def fake_batch(_svc, ops, callback):
                for op in ops:
                    callback(f"{op.file_id}:{op.operation.value}", {"id": op.file_id}, None)

            mock_batch.side_effect = fake_batch
            runner.execute(plan, skip_freshness_check=True)

        # files().get should never have been called for "root"
        for call in runner.service.files().get.call_args_list:
            assert call.kwargs.get("fileId") != "root"


class TestUntrashBuildRequest:
    """Test that UNTRASH produces the correct Drive API request."""

    def test_untrash_sets_trashed_false(self):
        from unittest.mock import MagicMock

        from gdrive_organizer.executor.batch import build_request

        service = MagicMock()
        op = PlanOperation(
            file_id="file1",
            current_name="doc.txt",
            current_path="/trash/doc.txt",
            operation=OperationType.UNTRASH,
            reason="rollback: restore from trash",
        )
        build_request(service, op)
        # Verify the update call includes trashed=False
        call_kwargs = service.files().update.call_args
        assert call_kwargs is not None
        body = call_kwargs.kwargs.get("body", call_kwargs[1].get("body", {}))
        assert body.get("trashed") is False


class TestRollbackLogContainsIdMapping:
    """Verify that _save_rollback_log persists id_mapping for folder rollback."""

    def test_log_contains_id_mapping_and_real_drive_ids(self, tmp_path):
        from unittest.mock import MagicMock

        from gdrive_organizer.config import Config

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        runner = PlanRunner(MagicMock(), config)

        from gdrive_organizer.models import ExecutionPlan

        plan = ExecutionPlan(
            created_at="2026-04-11T00:00:00Z",
            operations=[
                PlanOperation(
                    file_id="__new_folder_0__",
                    current_name="test",
                    current_path="",
                    operation=OperationType.CREATE_FOLDER,
                    new_path="test",
                ),
            ],
        )
        results = {"__new_folder_0__:create_folder": {"status": "success"}}
        before_states = {"__new_folder_0__": {}}
        id_mapping = {"__new_folder_0__": "real_id_123"}

        log_path = runner._save_rollback_log(plan, results, before_states, id_mapping)
        log = json.loads(log_path.read_text())

        assert log["id_mapping"] == {"__new_folder_0__": "real_id_123"}
        assert log["operations"][0]["realDriveId"] == "real_id_123"

    def test_log_contains_before_and_after_description(self, tmp_path):
        from unittest.mock import MagicMock

        from gdrive_organizer.config import Config
        from gdrive_organizer.models import ExecutionPlan

        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        runner = PlanRunner(MagicMock(), config)
        plan = ExecutionPlan(
            created_at="2026-04-11T00:00:00Z",
            operations=[
                PlanOperation(
                    file_id="file-1",
                    current_name="doc.txt",
                    current_path="/docs/doc.txt",
                    operation=OperationType.UPDATE_DESCRIPTION,
                    current_description="old desc",
                    new_description="new desc",
                ),
            ],
        )
        results = {"file-1:update_description": {"status": "success"}}
        before_states = {
            "file-1": {
                "name": "doc.txt",
                "path": "/docs/doc.txt",
                "parent_id": "folder-1",
                "description": "old desc",
            }
        }

        log_path = runner._save_rollback_log(plan, results, before_states, {})
        log = json.loads(log_path.read_text())

        assert log["operations"][0]["before"]["description"] == "old desc"
        assert log["operations"][0]["after"]["description"] == "new desc"
