"""Tests for shared Pydantic models."""

from datetime import UTC, datetime

from gdrive_organizer.models import (
    DriveFile,
    ExecutionPlan,
    FileType,
    OperationType,
    PlanOperation,
    Snapshot,
    SnapshotStats,
)


def test_drive_file_defaults():
    f = DriveFile(id="1", name="test.txt", mime_type="text/plain")
    assert f.parents == []
    assert f.shared is False
    assert f.file_type == FileType.FILE


def test_drive_file_folder_type():
    f = DriveFile(id="2", name="My Folder", mime_type="application/vnd.google-apps.folder")
    assert f.file_type == FileType.FOLDER


def test_drive_file_shortcut_type():
    f = DriveFile(id="3", name="Shortcut", mime_type="application/vnd.google-apps.shortcut")
    assert f.file_type == FileType.SHORTCUT


def test_snapshot_serialization():
    snap = Snapshot(
        scanned_at=datetime(2026, 1, 1, tzinfo=UTC),
        stats=SnapshotStats(total_files=10, total_folders=2),
        files=[DriveFile(id="1", name="a.txt", mime_type="text/plain")],
    )
    data = snap.model_dump(mode="json")
    restored = Snapshot.model_validate(data)
    assert restored.stats.total_files == 10
    assert len(restored.files) == 1


def test_execution_plan():
    plan = ExecutionPlan(
        created_at=datetime(2026, 1, 1, tzinfo=UTC),
        operations=[
            PlanOperation(
                file_id="1",
                current_name="old.txt",
                current_path="/old.txt",
                operation=OperationType.RENAME,
                new_name="new.txt",
                current_description="before",
                reason="cleanup",
            )
        ],
    )
    assert plan.operations[0].operation == OperationType.RENAME
    data = plan.model_dump(mode="json")
    restored = ExecutionPlan.model_validate(data)
    assert restored.operations[0].new_name == "new.txt"
    assert restored.operations[0].current_description == "before"
