"""Tests for batch API wrapper and runner."""

from datetime import UTC, datetime
from unittest.mock import MagicMock

from gdrive_organizer.executor.batch import build_request
from gdrive_organizer.executor.runner import PlanRunner
from gdrive_organizer.models import ExecutionPlan, OperationType, PlanOperation


def test_build_request_rename():
    service = MagicMock()
    op = PlanOperation(
        file_id="f1",
        current_name="old.txt",
        current_path="root/old.txt",
        operation=OperationType.RENAME,
        new_name="new.txt",
    )
    build_request(service, op)
    service.files().update.assert_called_once()
    call_kwargs = service.files().update.call_args
    assert call_kwargs.kwargs["body"]["name"] == "new.txt"
    assert call_kwargs.kwargs["fileId"] == "f1"


def test_build_request_move():
    service = MagicMock()
    op = PlanOperation(
        file_id="f1",
        current_name="file.txt",
        current_path="root/file.txt",
        operation=OperationType.MOVE,
        new_parent_id="folder2",
    )
    build_request(service, op)
    call_kwargs = service.files().update.call_args
    assert call_kwargs.kwargs["addParents"] == "folder2"


def test_dry_run():
    service = MagicMock()
    from gdrive_organizer.config import Config

    config = Config(config_dir="/tmp/test", data_dir="/tmp/test/data")
    runner = PlanRunner(service, config)

    plan = ExecutionPlan(
        created_at=datetime(2026, 1, 1, tzinfo=UTC),
        operations=[
            PlanOperation(
                file_id="f1",
                current_name="old.txt",
                current_path="root/old.txt",
                operation=OperationType.RENAME,
                new_name="new.txt",
            ),
        ],
    )
    result = runner.execute(plan, dry_run=True)
    assert result.success_count == 1
    assert result.failure_count == 0
    # No actual API calls should have been made
    service.files().update.assert_not_called()


def test_rollback_log_format(tmp_path):
    service = MagicMock()
    from gdrive_organizer.config import Config

    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")
    runner = PlanRunner(service, config)

    plan = ExecutionPlan(
        created_at=datetime(2026, 1, 1, tzinfo=UTC),
        operations=[
            PlanOperation(
                file_id="f1",
                current_name="old.txt",
                current_path="root/old.txt",
                operation=OperationType.RENAME,
                new_name="new.txt",
            ),
        ],
    )

    results = {"f1:rename": {"status": "success", "response": {}}}
    before_states = {"f1": {"name": "old.txt", "path": "root/old.txt"}}

    log_path = runner._save_rollback_log(plan, results, before_states, {})
    assert log_path.exists()

    import json

    log = json.loads(log_path.read_text())
    assert log["operations"][0]["fileId"] == "f1"
    assert log["operations"][0]["status"] == "success"
    assert log["operations"][0]["before"]["name"] == "old.txt"
    assert log["operations"][0]["after"]["name"] == "new.txt"


def test_build_reverse_operations(tmp_path):
    service = MagicMock()
    from gdrive_organizer.config import Config

    config = Config(config_dir=tmp_path / "config", data_dir=tmp_path / "data")
    runner = PlanRunner(service, config)

    rollback_data = {
        "operations": [
            {
                "fileId": "f1",
                "type": "rename",
                "before": {"name": "original.txt", "path": "root/original.txt"},
                "after": {"name": "renamed.txt", "path": "root/renamed.txt"},
                "status": "success",
            },
            {
                "fileId": "f2",
                "type": "rename",
                "before": {"name": "a.txt"},
                "after": {"name": "b.txt"},
                "status": "failed",
            },
        ],
    }
    reverse_ops = runner._build_reverse_operations(rollback_data)
    # Only successful operations should be reversed
    assert len(reverse_ops) == 1
    assert reverse_ops[0].file_id == "f1"
    assert reverse_ops[0].new_name == "original.txt"
