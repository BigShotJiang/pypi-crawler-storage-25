"""Tests for plan generation."""

from datetime import UTC, datetime

from gdrive_organizer.ai.planner import (
    _resolve_time_path,
    _response_to_operations,
    detect_conflicts,
)
from gdrive_organizer.models import (
    DriveFile,
    LLMResponseItem,
    OperationType,
    PlanOperation,
)


def _make_file(fid: str, name: str, path: str = "", modified: str | None = None) -> DriveFile:
    return DriveFile(
        id=fid,
        name=name,
        mime_type="text/plain",
        path=path or f"root/{name}",
        parents=["root_folder"],
        modified_time=modified or datetime(2026, 4, 8, tzinfo=UTC),
        description="기존 설명",
    )


def test_resolve_time_path():
    f = _make_file("1", "test.txt", modified=datetime(2026, 4, 8, tzinfo=UTC))
    assert _resolve_time_path(f) == "🪄 AI 정리/보관함/2026/04"


def test_resolve_time_path_no_date():
    f = DriveFile(id="1", name="test.txt", mime_type="text/plain")
    assert _resolve_time_path(f) == "🪄 AI 정리/보관함/미분류"


def test_archive_root_prefix_signals_ai_origin():
    """The AI-managed root must be visually distinct so the user can tell
    AI-created folders apart from their own (per #N from dogfood)."""
    from gdrive_organizer.ai.prompts import AI_ROOT, ARCHIVE_ROOT

    assert AI_ROOT.startswith("🪄")  # wand emoji = AI/auto
    assert "AI" in AI_ROOT
    assert ARCHIVE_ROOT == f"{AI_ROOT}/보관함"


def test_response_to_operations_move():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]
    ops = _response_to_operations(items, files, set())
    move_ops = [op for op in ops if op.operation == OperationType.MOVE]
    assert len(move_ops) == 1
    assert move_ops[0].new_path == "보관함/2026/04/report.txt"


def test_response_to_operations_shortcut():
    files = {"1": _make_file("1", "report.txt")}
    items = [
        LLMResponseItem(
            file_id="1",
            move_to="보관함/2026/04",
            shortcuts=["태그/AI"],
        )
    ]
    ops = _response_to_operations(items, files, set())
    shortcut_ops = [op for op in ops if op.operation == OperationType.CREATE_SHORTCUT]
    assert len(shortcut_ops) == 1
    assert shortcut_ops[0].shortcut_target_id == "1"


def test_response_to_operations_description():
    files = {"1": _make_file("1", "report.txt")}
    items = [
        LLMResponseItem(
            file_id="1",
            move_to="보관함/2026/04",
            new_description="AI 관련 리서치 문서",
        )
    ]
    ops = _response_to_operations(items, files, set())
    desc_ops = [op for op in ops if op.operation == OperationType.UPDATE_DESCRIPTION]
    assert len(desc_ops) == 1
    assert desc_ops[0].new_description == "AI 관련 리서치 문서"
    assert desc_ops[0].current_description == "기존 설명"


def test_response_to_operations_creates_folders():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04", shortcuts=["태그/AI"])]
    ops = _response_to_operations(items, files, set())
    folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
    assert len(folder_ops) >= 2  # 보관함/2026/04 and 태그/AI


def test_response_skips_existing_folders():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]
    # Mark 보관함/2026/04 as already existing
    ops = _response_to_operations(items, files, {"보관함/2026/04"})
    folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
    # Should NOT create 보관함/2026/04 since it exists
    created_paths = {op.new_path for op in folder_ops}
    assert "보관함/2026/04" not in created_paths


def test_existing_folder_move_uses_real_folder_id():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]

    ops = _response_to_operations(items, files, {"보관함/2026/04": "folder_2026_04"})

    move_ops = [op for op in ops if op.operation == OperationType.MOVE]
    assert move_ops[0].new_parent_id == "folder_2026_04"


def test_partial_existing_parent_chain_uses_real_parent_and_placeholder_child():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04")]

    ops = _response_to_operations(items, files, {"보관함": "archive_root"})

    folder_ops = [op for op in ops if op.operation == OperationType.CREATE_FOLDER]
    folder_by_path = {op.new_path: op for op in folder_ops}
    assert folder_by_path["보관함/2026"].new_parent_id == "archive_root"
    assert folder_by_path["보관함/2026/04"].new_parent_id == folder_by_path["보관함/2026"].file_id

    move_ops = [op for op in ops if op.operation == OperationType.MOVE]
    assert move_ops[0].new_parent_id == folder_by_path["보관함/2026/04"].file_id


def test_existing_folder_shortcut_uses_real_folder_id():
    files = {"1": _make_file("1", "report.txt")}
    items = [LLMResponseItem(file_id="1", move_to="보관함/2026/04", shortcuts=["태그/AI"])]

    ops = _response_to_operations(items, files, {"태그/AI": "tag_ai"})

    shortcut_ops = [op for op in ops if op.operation == OperationType.CREATE_SHORTCUT]
    assert shortcut_ops[0].shortcut_parent_id == "tag_ai"


def test_detect_conflicts():
    ops = [
        PlanOperation(
            file_id="1",
            current_name="a.txt",
            current_path="root/a.txt",
            operation=OperationType.MOVE,
            new_name="report.txt",
            new_path="보관함/report.txt",
        ),
        PlanOperation(
            file_id="2",
            current_name="b.txt",
            current_path="root/b.txt",
            operation=OperationType.MOVE,
            new_name="report.txt",
            new_path="보관함/report.txt",
        ),
    ]
    conflicts = detect_conflicts(ops)
    assert len(conflicts) == 1


def test_detect_no_conflicts():
    ops = [
        PlanOperation(
            file_id="1",
            current_name="a.txt",
            current_path="root/a.txt",
            operation=OperationType.MOVE,
            new_path="보관함/2026/04/a.txt",
        ),
        PlanOperation(
            file_id="2",
            current_name="b.txt",
            current_path="root/b.txt",
            operation=OperationType.MOVE,
            new_path="보관함/2026/04/b.txt",
        ),
    ]
    conflicts = detect_conflicts(ops)
    assert len(conflicts) == 0


# --- Preset content-gating (#4) ---


def test_migration_preset_does_not_require_content():
    """Migration is metadata-only — must not trigger snippet extraction."""
    from gdrive_organizer.ai.prompts import BUILTIN_PRESETS

    assert BUILTIN_PRESETS["migration"].requires_content is False


def test_second_brain_preset_requires_content():
    """Second-brain analyzes text content — must trigger snippet extraction."""
    from gdrive_organizer.ai.prompts import BUILTIN_PRESETS

    assert BUILTIN_PRESETS["second-brain"].requires_content is True


def test_custom_preset_defaults_to_requiring_content(tmp_path):
    """Custom preset defaults to True (conservative — user might reference content)."""
    from gdrive_organizer.ai.prompts import load_preset

    prompt_file = tmp_path / "custom.txt"
    prompt_file.write_text("Classify these files based on their content.")

    preset = load_preset("custom", prompt_file=prompt_file)
    assert preset.requires_content is True


def test_generate_plan_skips_extract_snippets_for_migration(monkeypatch):
    """Real-world bug: migration preset triggered ~21min snippet download.
    Verify the gate now skips _extract_snippets entirely."""
    import asyncio
    from unittest.mock import AsyncMock, MagicMock, patch

    from gdrive_organizer.ai import planner
    from gdrive_organizer.models import Snapshot

    snapshot = Snapshot(
        scanned_at=datetime(2026, 5, 1, tzinfo=UTC),
        files=[
            DriveFile(
                id="f1",
                name="report.md",
                mime_type="text/markdown",
                path="report.md",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
            ),
        ],
    )

    from gdrive_organizer.ai.validator import ValidationResult

    extract_mock = AsyncMock(return_value={})
    classify_mock = AsyncMock(return_value=[])

    config = MagicMock()
    config.llm_model = "test-model"

    with (
        patch.object(planner, "_extract_snippets", extract_mock),
        patch.object(planner, "_classify_with_preset", classify_mock),
        patch("gdrive_organizer.ai.planner.GrokClient") as grok_cls,
        patch(
            "gdrive_organizer.ai.planner.validate_llm_responses",
            return_value=ValidationResult(),
        ),
    ):
        client = MagicMock()
        client.close = AsyncMock()
        grok_cls.return_value = client

        asyncio.run(
            planner.generate_plan(
                snapshot=snapshot,
                config=config,
                preset_id="migration",
            )
        )

    extract_mock.assert_not_called()
    classify_mock.assert_called_once()


# --- _extract_snippets parallelism (#5) ---


def test_extract_snippets_runs_in_parallel():
    """The serial version blocked the event loop; the parallel version must
    finish in <(N * per_call_latency) wall time. We verify by inserting a
    100ms sleep per call and asserting that 8 files complete in <300ms (vs
    800ms serial)."""
    import asyncio
    import time as time_mod
    from unittest.mock import MagicMock, patch

    from gdrive_organizer.ai import planner

    files = [
        DriveFile(
            id=f"f{i}",
            name=f"doc{i}",
            mime_type="application/vnd.google-apps.document",  # exportable
            path=f"doc{i}",
            parents=[],
            modified_time=datetime(2026, 4, 1, tzinfo=UTC),
        )
        for i in range(8)
    ]

    def slow_extract(_svc, file_id, _mime, head=300, tail=150):
        time_mod.sleep(0.1)  # simulate Drive export latency
        return f"snippet-{file_id}"

    service = MagicMock()
    with patch.object(planner, "extract_text_snippet", side_effect=slow_extract):
        start = time_mod.perf_counter()
        result = asyncio.run(planner._extract_snippets(service, files, concurrency=8))
        elapsed = time_mod.perf_counter() - start

    assert len(result) == 8
    # 8 parallel × 100ms ≈ ~100-200ms; serial would be ~800ms.
    # Generous threshold accounts for thread spawn overhead in CI.
    assert elapsed < 0.5, f"Expected parallel execution (~0.1s), got {elapsed:.2f}s"


def test_extract_snippets_returns_empty_when_no_service():
    import asyncio

    from gdrive_organizer.ai import planner

    files = [
        DriveFile(
            id="f1",
            name="doc.md",
            mime_type="text/markdown",
            path="doc.md",
            parents=[],
            modified_time=datetime(2026, 4, 1, tzinfo=UTC),
        ),
    ]
    result = asyncio.run(planner._extract_snippets(None, files))
    assert result == {}


# --- LLM batch parallelism (#J) ---


def test_classify_with_preset_runs_batches_in_parallel():
    """Sequential batches were the dominant cost (~14min on 1500 files);
    gather + the client's internal Semaphore should bring wall time down
    to roughly N/concurrency * per_batch_latency."""
    import asyncio
    import time as time_mod
    from unittest.mock import AsyncMock, MagicMock, patch

    from gdrive_organizer.ai import planner

    files = [
        DriveFile(
            id=f"f{i}",
            name=f"doc{i}",
            mime_type="text/plain",
            path=f"doc{i}",
            parents=[],
            modified_time=datetime(2026, 4, 1, tzinfo=UTC),
        )
        for i in range(8 * 50)  # 8 batches at BATCH_SIZE=50
    ]

    async def slow_chat(_system, _user, temperature=0.1):
        await asyncio.sleep(0.1)  # simulate LLM latency
        return "[]"  # empty response — parse_preset_output_raw handles it

    client = MagicMock()
    client.chat = slow_chat

    with patch("gdrive_organizer.ai.planner.parse_preset_output_raw", return_value=[]):
        start = time_mod.perf_counter()
        result = asyncio.run(
            planner._classify_with_preset(
                client,
                files,
                preset_prompt="prompt",
                snippets={},
                junk_ids=set(),
                existing_folders=[],
            )
        )
        elapsed = time_mod.perf_counter() - start

    assert result == []
    # 8 batches × 100ms serial = 800ms; in parallel ≈ 100-200ms.
    # Generous threshold for CI scheduling jitter.
    assert elapsed < 0.4, f"Expected parallel execution, got {elapsed:.2f}s"


def test_classify_with_preset_propagates_first_failure():
    """gather should raise the first exception (and cancel the rest),
    matching the old sequential abort-on-first behavior."""
    import asyncio
    from unittest.mock import MagicMock

    from gdrive_organizer.ai import planner
    from gdrive_organizer.ai.classifier import LLMError

    files = [
        DriveFile(
            id=f"f{i}",
            name=f"doc{i}",
            mime_type="text/plain",
            path=f"doc{i}",
            parents=[],
            modified_time=datetime(2026, 4, 1, tzinfo=UTC),
        )
        for i in range(100)  # 2 batches
    ]

    call_count = {"n": 0}

    async def flaky_chat(_system, _user, temperature=0.1):
        call_count["n"] += 1
        if call_count["n"] == 1:
            raise LLMError("simulated rate limit exhaustion")
        await asyncio.sleep(10)  # would be slow; should be cancelled
        return "[]"

    client = MagicMock()
    client.chat = flaky_chat

    import pytest

    with pytest.raises(LLMError, match="simulated rate limit"):
        asyncio.run(
            planner._classify_with_preset(
                client,
                files,
                preset_prompt="prompt",
                snippets={},
                junk_ids=set(),
                existing_folders=[],
            )
        )


# --- ownedByMe filter (#J1 from Stage-1 dogfood) ---


def test_generate_plan_excludes_unowned_files():
    """Files where ownedByMe=False (shared from someone else) cannot be moved
    or have their description updated by us. The planner must drop them so
    apply doesn't generate guaranteed-fail ops."""
    import asyncio
    from unittest.mock import AsyncMock, MagicMock, patch

    from gdrive_organizer.ai import planner
    from gdrive_organizer.ai.validator import ValidationResult
    from gdrive_organizer.models import Snapshot

    snapshot = Snapshot(
        scanned_at=datetime(2026, 5, 2, tzinfo=UTC),
        files=[
            DriveFile(
                id="mine",
                name="my doc",
                mime_type="text/plain",
                path="my doc",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=True,
            ),
            DriveFile(
                id="shared",
                name="someones-pdf.pdf",
                mime_type="application/pdf",
                path="someones-pdf.pdf",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=False,  # shared from someone else
            ),
            DriveFile(
                id="unknown",
                name="legacy.txt",
                mime_type="text/plain",
                path="legacy.txt",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=None,  # scanner couldn't determine — keep
            ),
        ],
    )

    classify_mock = AsyncMock(return_value=[])
    config = MagicMock()
    config.llm_model = "test-model"

    with (
        patch.object(planner, "_classify_with_preset", classify_mock),
        patch("gdrive_organizer.ai.planner.GrokClient") as grok_cls,
        patch(
            "gdrive_organizer.ai.planner.validate_llm_responses",
            return_value=ValidationResult(),
        ),
    ):
        client = MagicMock()
        client.close = AsyncMock()
        grok_cls.return_value = client

        asyncio.run(
            planner.generate_plan(
                snapshot=snapshot,
                config=config,
                preset_id="migration",
            )
        )

    # The classifier should have received only the owned + unknown files,
    # never the explicitly-unowned one.
    files_passed = classify_mock.call_args.args[1]
    file_ids = {f.id for f in files_passed}
    assert "mine" in file_ids
    assert "unknown" in file_ids  # None is treated as "maybe owned" → keep
    assert "shared" not in file_ids  # explicit False → drop


# --- shortcut filter (#J2 from Stage-2 dogfood) ---


def test_generate_plan_excludes_shortcut_files():
    """Shortcut files (mimeType=application/vnd.google-apps.shortcut) must
    not feed back into the planner — using them as a source produces a
    shortcut-of-shortcut chain that Drive rejects.

    Real-world trigger: after Stage 1 created shortcuts in 부트캠프/, the
    next snapshot included those shortcuts; the next plan tried to
    create_shortcut on them again. 4 of 4 Stage-2 failures.
    """
    import asyncio
    from unittest.mock import AsyncMock, MagicMock, patch

    from gdrive_organizer.ai import planner
    from gdrive_organizer.ai.validator import ValidationResult
    from gdrive_organizer.models import Snapshot

    snapshot = Snapshot(
        scanned_at=datetime(2026, 5, 2, tzinfo=UTC),
        files=[
            DriveFile(
                id="real",
                name="my doc",
                mime_type="text/plain",
                path="my doc",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=True,
            ),
            DriveFile(
                id="shortcut1",
                name="my doc (shortcut)",
                mime_type="application/vnd.google-apps.shortcut",
                path="부트캠프/my doc",
                parents=[],
                modified_time=datetime(2026, 4, 1, tzinfo=UTC),
                owned_by_me=True,
            ),
        ],
    )

    classify_mock = AsyncMock(return_value=[])
    config = MagicMock()
    config.llm_model = "test-model"

    with (
        patch.object(planner, "_classify_with_preset", classify_mock),
        patch("gdrive_organizer.ai.planner.GrokClient") as grok_cls,
        patch(
            "gdrive_organizer.ai.planner.validate_llm_responses",
            return_value=ValidationResult(),
        ),
    ):
        client = MagicMock()
        client.close = AsyncMock()
        grok_cls.return_value = client

        asyncio.run(
            planner.generate_plan(
                snapshot=snapshot,
                config=config,
                preset_id="migration",
            )
        )

    files_passed = classify_mock.call_args.args[1]
    file_ids = {f.id for f in files_passed}
    assert "real" in file_ids
    assert "shortcut1" not in file_ids


# --- conflict suffix resolution (#J4 from Stage-5 dogfood) ---


def test_resolve_conflicts_appends_suffix_instead_of_dropping():
    """When two ops land at the same destination, the later one should be
    renamed with a ' (2)' suffix — not dropped. Dropping leaves duplicate
    files orphaned at root forever (Stage-5 dogfood: 6 files survived 4
    stages by being silently dropped from every subsequent classify)."""
    from gdrive_organizer.ai.planner import resolve_conflicts

    ops = [
        PlanOperation(
            file_id="a",
            current_name="report",
            current_path="report",
            operation=OperationType.MOVE,
            new_path="보관함/2025/12/report",
        ),
        PlanOperation(
            file_id="b",  # different file, same target name
            current_name="report",
            current_path="report",
            operation=OperationType.MOVE,
            new_path="보관함/2025/12/report",
        ),
    ]
    renames = resolve_conflicts(ops)
    assert renames == 1
    assert ops[0].new_path == "보관함/2025/12/report"  # first wins
    assert ops[1].new_path == "보관함/2025/12/report (2)"  # second renamed
    assert ops[1].new_name == "report (2)"


def test_resolve_conflicts_handles_extension():
    """Suffix must go before the file extension, not after."""
    from gdrive_organizer.ai.planner import resolve_conflicts

    ops = [
        PlanOperation(
            file_id="a",
            current_name="data.csv",
            current_path="data.csv",
            operation=OperationType.MOVE,
            new_path="보관함/2025/06/data.csv",
        ),
        PlanOperation(
            file_id="b",
            current_name="data.csv",
            current_path="data.csv",
            operation=OperationType.MOVE,
            new_path="보관함/2025/06/data.csv",
        ),
    ]
    resolve_conflicts(ops)
    assert ops[1].new_path == "보관함/2025/06/data (2).csv"


def test_resolve_conflicts_chains_more_than_two():
    """3 colliding ops should become name, name (2), name (3)."""
    from gdrive_organizer.ai.planner import resolve_conflicts

    ops = [
        PlanOperation(
            file_id=str(i),
            current_name="x",
            current_path="x",
            operation=OperationType.MOVE,
            new_path="보관함/2025/06/x",
        )
        for i in range(3)
    ]
    resolve_conflicts(ops)
    assert ops[0].new_path == "보관함/2025/06/x"
    assert ops[1].new_path == "보관함/2025/06/x (2)"
    assert ops[2].new_path == "보관함/2025/06/x (3)"
