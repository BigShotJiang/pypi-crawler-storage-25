# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [0.1.0-beta.7] - 2026-05-04

A workflow-friction fix landed during the same-day b6 dogfood. Both
defects always required manual intervention after every apply, so the
release goes out separately for visibility.

### Fixed

- **Viewer dashboard auto-reloads on snapshot advance** (#J3). The viewer cached the snapshot at startup and never re-read the file, so a CLI scan had no effect on the running server until the user killed and re-started it. `SnapshotCache` now tracks the latest-snapshot file's mtime (resolving the symlink) and invalidates itself the next time the file advances. The first request after a scan transparently reloads. Tests cover both `/api/stats` and `/api/tree`.

### Added

- **`plan apply --rescan/--no-rescan`** (default on). After a successful apply, the runner now invokes the existing `incremental_scan` path so the snapshot reflects the just-applied state. Without this, the next plan and the viewer's tree both lied about what was actually in Drive — observed in real dogfood. Auto-rescan failures degrade to a yellow note instead of aborting the apply summary.

## [0.1.0-beta.6] - 2026-05-03

A second dogfood pass against the same 1500-file Drive surfaced two new
data-integrity defects (#J5, #J6) and four planner / classify
improvements (#J1, #J2, #J4, #N) plus a 13× speedup on classify. This
release ships all of them.

### Fixed

- **Apply refuses to write into a trashed parent folder** (#J5). After a `plan rollback` trashes folders that were freshly created by the previous apply, those folder Drive IDs still live in the snapshot. The next classify happily resolved a destination path to one of those trashed IDs, and Phase 2 quietly moved files into an invisible parent — they no longer appeared in the Drive UI even though the API call succeeded. The runner now batch-fetches `trashed` for every real (non-placeholder, non-`root`) destination parent the plan references and aborts with a clear "re-scan and re-classify" message if any are trashed.
- **Scanner re-parents orphans whose folder is in trash** (#J6). Drive's `q=trashed=false` returns a file whose own `trashed=false` even when its direct parent has been moved to trash; `build_tree` then silently demoted such a file to a root node, but it was still a member of an invisible parent so the user could not see it and the next plan never flagged it as needing organization. The scanner now detects files whose parents fell outside the scan result, confirms the parent is trashed via a `files.get`, and clears `parents=[]` so the file surfaces at My Drive root and gets classified normally. Live external parents (e.g. shared-from-others folders) are left alone.
- **Planner skips shared-from-others files** (`ownedByMe=False`) (#J1). Drive rejects move/update on these files (canEdit/canMove=False), so including them produced guaranteed apply failures — 7 of 15 failures in the Stage-1 dogfood were `ownedByMe=False` PDFs in shared course folders. Files where `owned_by_me` is unknown (`None`) are still permitted.
- **Planner skips `mimeType=shortcut` files as classification candidates** (#J2). Using a shortcut as a source produced a shortcut-of-shortcut chain that Drive rejects (4 of 4 remaining failures in Stage-2 dogfood were exactly this — shortcuts created by an earlier apply, then handed back to the next plan as candidates).
- **Conflict resolution renames instead of dropping** (#J4). When two ops would land at the same destination, the planner used to drop the later op, leaving duplicate-named files stranded at root forever — they would be dropped from every subsequent plan as well. Stage-5 dogfood found 6 such files that survived 4 stages. Renaming with a `(2)`, `(3)`, ... suffix preserves the data so every file gets organized, just with disambiguated names.

### Changed

- **Classify is dramatically faster — 13× wall-clock speedup** (~14 min → ~1 min 35 s on a 1500-file Drive). LLM batches now run in parallel via `asyncio.gather`; `client.chat()` already enforced concurrency through its `Semaphore(MAX_CONCURRENT=10)`, so spawning all batches at once and letting the client throttle them brings wall time down by roughly the semaphore size. Order is preserved (gather returns results in input order) and first-failure abort semantics match the old sequential path.
- **AI-managed folders are prefixed with `🪄 AI 정리`** (#N). The previous default rooted everything under `보관함`, which the user already used for unrelated personal archives. The wand emoji prefix lets the user tell at a glance which folders the tool created vs. their own existing tree.

## [0.1.0-beta.5] - 2026-05-02

Real-world dogfooding on a 1500-file Drive surfaced 18 defects — three of
which were data-integrity bugs that the existing test suite missed. This
release ships the fixes.

### Fixed

- **Rollback no longer trashes the original file** when undoing a `create_shortcut` op. The shortcut entry's `fileId` was the *target* file's ID, not the shortcut's; the rollback log now records the shortcut's own Drive ID and trashes that. (#24)
- **Rollback restores root files correctly** when `before.parent_id` is `null` — previously the reverse `move` op silently failed to specify a parent and left the file orphaned in the apply target. Now resolves to Drive's `"root"` alias. (#25)
- **Rollback unsets descriptions** that were newly added by the apply (empty string), instead of skipping the reversal. (#22)
- **`success_count` is per-op, not per-file_id** — a file that received both a `move` and an `update_description` op was undercounting by 1 because the results dict overwrote on `file_id` collision. (#20)
- **`auth login` recovers from expired refresh tokens** automatically — was leaking a `RefreshError` traceback and forcing manual `auth logout` first. (#1)
- **Stale-snapshot guard reports honestly** — was printing "Failed: N" when nothing was even attempted. Added `ExecutionResult.skipped_count` to distinguish "not attempted" from "tried and failed". (#18, #23)
- **`plan rollback` accepts `-y/--yes`** for non-interactive use, matching `plan apply`. (#21)

### Changed

- **Classify is dramatically faster for the migration preset** — measured 21 min → 14 min on a 1500-file Drive (-32%). The `_extract_snippets` step is now gated behind a `requires_content` flag on the preset (migration is metadata-only), and when it does run it's genuinely async + parallel via `asyncio.to_thread` + `Semaphore` instead of fake-async sync calls + `time.sleep`. Progress bars added to both extract and LLM batch phases. (#4, #5, #6)
- **`plan apply --dry-run` defaults to a phase summary** instead of one line per op (was 3,262 lines on a real plan). Pass `--verbose` for the legacy line-by-line output. (#15, #16)
- **`plan show` samples per phase** so the preview isn't dominated by `create_folder` ops. New `--phase` filter and `--per-phase N` knob; columns auto-fit so paths no longer truncate mid-name. (#9–#11)
- **Viewer Plan page**: `create_folder` ops show a single "NEW" card (was identical BEFORE/AFTER); the bulk-select button is now labeled "Select All (Skip Trash)" with an explicit tooltip. (#12, #14)
- **Viewer CSS pipeline** moved from the Tailwind JIT browser runtime (which printed a "do not use in production" warning on every page load and weighed 407 KB) to a proper PostCSS production build (47 KB, no warning). New `viewer-build/` workspace with the compiled output committed under `static/vendor/tailwind.css`. End users still need no Node installed. (#13)
- **`config exclude` documentation** in `README.md` and `CLAUDE.md` now matches the actual flag-style command (`--show`, `--add-folder`, `--remove-folder`, ...) instead of subcommand-style. (#2)
- **Validator's "Conflict removed" log line** now identifies the planner as the source and explains *why* (which destination already had a different op landing there). (#7)
- **File logging is actually wired up** — `setup_logger` was previously never called, so `~/.local/share/gdrive-organizer/logs/gdrive-organizer.log` stayed empty even on errors. (#8)

### Added

- **Per-page scan timing logs** for diagnosing slow scans. The 19-minute scan observed during dogfood had no breakdown; the next slow run will. (#3)
- **`docs/SCAN-PERFORMANCE.md`** — investigation notes for the 19-minute scan and a measurement of the post-fix classify run with a follow-up suggestion (parallelize `_classify_with_preset` via the existing `classify_batch_parallel` path).
- **5 dogfood regression tests** in `tests/test_rollback.py::TestDogfoodRegression` reproducing each of #20, #22, #24, #25.

## [0.1.0-beta.4] - 2026-04-17

### Added

- **`auth setup` command**: GCP OAuth 설정을 처음부터 안내하는 인터랙티브 가이드. 프로젝트 생성 → Drive API 활성화 → OAuth 동의 화면 → Client ID 생성 → credentials 자동 감지 → OAuth 로그인까지 5단계로 진행. credentials.json이 이미 있으면 GCP 단계를 건너뛰고, 인증 완료 상태면 즉시 종료.
- **Docker deployment**: `docker compose up` 으로 viewer를 컨테이너로 실행 가능. Dockerfile + compose.yml 추가.
- **Viewer icon**: Drive Manager 전용 아이콘 적용 (sidebar, favicon).

### Changed

- Viewer sidebar 로고 아이콘 viewBox 조정.

## [0.1.0-beta.3] - 2026-04-16

### Added

- **Homebrew tap**: `brew tap papa-channy/tap && brew install gdrive-organizer` now works on macOS/Linux. Formula pins all transitive resources from the PyPI sdist.
- **CI: tag-driven release workflow** (`.github/workflows/release.yml`) — pushing a `v*` tag runs lint + tests, verifies the tag matches `pyproject.toml` version, builds sdist + wheel, publishes to PyPI via **trusted publishing** (OIDC; no stored tokens), and uploads the artifacts to a matching GitHub release with pre-release flag auto-inferred from the tag suffix.
- **README**: Homebrew install as the first option for macOS/Linux users; `pipx` / `pip` kept as platform-agnostic fallbacks.
- **docs/RELEASING.md**: rewritten for the new two-command release flow, with a one-time PyPI trusted-publisher setup guide and a manual break-glass fallback retained for reference.

### Changed

- No package code changes from v0.1.0-beta.2. This release exists solely to validate the auto-publish pipeline end-to-end and ship the Homebrew path.

## [0.1.0-beta.2] - 2026-04-15

### Added

- **Plan Review**: name/path search box that combines with the operation-type filter
- **Plan Review**: bulk-action shortcuts — "Select Safe Only" (excludes TRASH) and "Deselect all TRASH (N)" (only shown when trash ops exist)
- **Plan Review**: approved-subset banner with "Clear approval" button; matching `DELETE /api/plan/approve` endpoint (session-gated, rate-limited)
- **Plan Review**: last-applied panel with success/failed op counts, expandable per-op status list, and copy-pasteable `plan rollback` command
- **Plan Review**: character-level diff highlighting — common prefix/suffix dimmed, removed middle strike-through (BEFORE), added middle bold-green (AFTER)
- **Dashboard**: freshness chips — "Last scan: 2h ago" / "Last classify: 15m ago" with CLI-command hint when missing
- **Viewer**: vendored Lucide and Tailwind CSS assets (`static/vendor/`) so the local viewer runs fully offline
- **Viewer**: consistent empty/error states via `renderEmptyState` helper across tree, plan, permissions, duplicates, search, and settings
- **Test infra**: Playwright E2E skeleton (`tests/e2e/`) with live uvicorn fixture; 19 browser tests covering all new interactions
- **Docs**: viewer screenshots (`docs/assets/viewer-*.png`) plus `scripts/capture_screenshots.py` for reproducible regeneration with synthetic data

### Fixed

- **Plan Review**: same `file_id` with multiple operations can now be approved independently (approval API switched to `approved_operation_ids`)
- **Plan Review**: selection state survives filter changes (previously any filter change re-checked all items)
- **Settings**: expired or corrupt tokens correctly surface as "Expired" or "Not Connected" instead of "Connected"
- **Dashboard**: `last_scan_at` is now derived from `snapshot.scanned_at`; the dashboard's "Updated Xh ago" subtitle no longer falsely reports "No scan yet" when a snapshot exists

### Changed

- `typer[all]>=0.12` → `typer>=0.12` — removes the "no extra named 'all'" warning on `pip install` with recent typer versions
- Plan apply now prefers `approved-plan.json` as the CLI default; `--latest-plan` bypasses the approved subset when needed

## [0.1.0-beta.1] - 2026-04-12

### Added

- **Core workflow**: scan -> classify -> plan -> apply -> rollback
- **Flat-crawl scanner**: single `files.list` call with in-memory tree reconstruction
- **AI classification**: xAI Grok integration with configurable presets (migration, second-brain, custom)
- **Plan/Apply separation**: AI generates reviewable JSON plans, never mutates Drive directly
- **Dry-run support**: `plan apply --dry-run` previews changes without execution
- **Rollback**: undo applied plans with correct operation ordering and untrash semantics
- **Readonly OAuth mode**: `oauth_readonly` config for inspection without write credentials
- **Incremental sync**: Changes API integration for fast re-scans after initial crawl
- **Local web viewer**: FastAPI dashboard with tree explorer, plan review, duplicate detection, permission audit
- **Batch executor**: Google Batch API wrapper with token-bucket rate limiter (3 writes/sec default)
- **Atomic snapshot writes**: prevents corruption from interrupted writes
- **Advisory snapshot locking**: reduces concurrent write races
- **Session-gated viewer mutations**: confirmation and session token checks for web-initiated changes
- **LLM response validation**: validates AI output structure before mutation planning
- **System keychain API key storage**: via `keyring` library
- **Restricted directory permissions**: `0700` on POSIX for config and data directories
- **File content reading**: `cat` command with auto-export for Google Workspace files
- **Scan exclusion rules**: configurable file/folder exclusions
- **Snapshot freshness checks**: warns when applying plans against stale snapshots
- **CLI**: typer-based with rich output formatting
- **justfile**: task runner with 32 recipes for common operations

### Security

- OAuth scope mismatch detection prevents readonly config from reusing write tokens
- Localhost-only viewer binding by default
- Credentials and tokens excluded from version control via `.gitignore`
