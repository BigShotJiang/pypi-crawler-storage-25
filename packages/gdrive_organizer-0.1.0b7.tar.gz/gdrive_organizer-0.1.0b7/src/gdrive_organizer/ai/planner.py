"""Plan generation — preset-based LLM pipeline for file organization."""

from __future__ import annotations

import asyncio
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING

from rich.progress import BarColumn, Progress, TextColumn, TimeElapsedColumn

from gdrive_organizer.ai.classifier import GrokClient
from gdrive_organizer.ai.prompts import (
    ARCHIVE_ROOT,
    build_preset_input,
    load_preset,
    parse_preset_output_raw,
)
from gdrive_organizer.ai.validator import (
    save_quarantine_log,
    validate_llm_responses,
)
from gdrive_organizer.models import (
    DriveFile,
    ExecutionPlan,
    LLMResponseItem,
    OperationType,
    PlanOperation,
    PlanStats,
    Snapshot,
)
from gdrive_organizer.scanner.content import extract_text_snippet, is_exportable
from gdrive_organizer.scanner.filter import build_md5_index, detect_junk_files
from gdrive_organizer.utils.logger import get_logger

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

    from gdrive_organizer.config import Config

logger = get_logger("ai.planner")

BATCH_SIZE = 50
SNIPPET_CONCURRENCY = 8  # Drive export is light; 8 keeps us well under quota
FOLDER_MIME = "application/vnd.google-apps.folder"
SHORTCUT_MIME = "application/vnd.google-apps.shortcut"
APPROVED_PLAN_FILENAME = "approved-plan.json"


def _resolve_time_path(file: DriveFile) -> str:
    """Compute time-based archive path from modified_time.

    Folders this function returns live under the AI_ROOT prefix so the
    user can tell at a glance which folders the tool created vs. their
    own existing 보관함/ tree (if any).
    """
    dt = file.modified_time or file.created_time
    if dt:
        return f"{ARCHIVE_ROOT}/{dt.year}/{dt.month:02d}"
    return f"{ARCHIVE_ROOT}/미분류"


def _get_existing_folders(snapshot: Snapshot) -> list[str]:
    """Extract meaningful folder paths from snapshot."""
    folders = []
    for f in snapshot.files:
        if f.mime_type == FOLDER_MIME and f.path:
            folders.append(f.path)
    return sorted(folders)


def _get_existing_folder_index(snapshot: Snapshot) -> dict[str, str]:
    """Map existing folder paths to their real Drive IDs."""
    return {f.path: f.id for f in snapshot.files if f.mime_type == FOLDER_MIME and f.path and f.id}


def _plans_dir(config: Config) -> Path:
    plans_dir = config.data_dir / "plans"
    plans_dir.mkdir(parents=True, exist_ok=True)
    return plans_dir


def approved_plan_path(config: Config) -> Path:
    """Return the active approved-plan path."""
    return _plans_dir(config) / APPROVED_PLAN_FILENAME


def archive_approved_plan(config: Config, reason: str) -> Path | None:
    """Archive the active approved plan, if present, and return the archive path."""
    active = approved_plan_path(config)
    if not active.exists():
        return None
    timestamp = datetime.now(UTC).strftime("%Y-%m-%dT%H-%M-%S")
    archive_path = active.with_name(f"approved-{reason}-{timestamp}.json")
    active.rename(archive_path)
    return archive_path


def resolve_plan_path(config: Config, mode: str = "auto") -> Path | None:
    """Resolve which plan file should be used for the requested mode."""
    plans_dir = _plans_dir(config)
    if mode not in {"auto", "latest"}:
        raise ValueError(f"Unsupported plan resolution mode: {mode}")

    if mode == "auto":
        approved = approved_plan_path(config)
        if approved.exists():
            return approved

    plan_files = sorted(plans_dir.glob("plan-*.json"), reverse=True)
    return plan_files[0] if plan_files else None


def plan_source_label(config: Config, path: Path) -> str:
    """Return a human-readable label for a resolved plan path."""
    if path == approved_plan_path(config):
        return f"Approved plan: {path.name}"
    return f"Latest plan: {path.name}"


def load_plan(path: Path) -> ExecutionPlan:
    """Load a plan from a specific file path."""
    data = json.loads(path.read_text())
    return ExecutionPlan.model_validate(data)


def build_plan_stats(operations: list[PlanOperation]) -> PlanStats:
    """Compute plan stats from a list of operations."""
    return PlanStats(
        total_operations=len(operations),
        renames=sum(1 for op in operations if op.operation == OperationType.RENAME),
        moves=sum(1 for op in operations if op.operation == OperationType.MOVE),
        rename_and_moves=sum(
            1 for op in operations if op.operation == OperationType.RENAME_AND_MOVE
        ),
        shortcuts=sum(1 for op in operations if op.operation == OperationType.CREATE_SHORTCUT),
        descriptions=sum(
            1 for op in operations if op.operation == OperationType.UPDATE_DESCRIPTION
        ),
        trashed=sum(1 for op in operations if op.operation == OperationType.TRASH),
    )


def save_plan(
    plan: ExecutionPlan, config: Config, invalidate_existing_approval: bool = True
) -> Path:
    """Persist a full plan to disk, archiving any stale approved subset first."""
    plans_dir = _plans_dir(config)
    if invalidate_existing_approval:
        archive_approved_plan(config, reason="invalidated")
    timestamp = plan.created_at.strftime("%Y-%m-%dT%H-%M-%S")
    plan_path = plans_dir / f"plan-{timestamp}.json"
    plan_path.write_text(plan.model_dump_json(indent=2))
    return plan_path


async def _extract_snippets(
    service: Resource | None,
    files: list[DriveFile],
    concurrency: int = SNIPPET_CONCURRENCY,
) -> dict[str, str]:
    """Extract text snippets from exportable files in parallel.

    Each Drive export call is wrapped in asyncio.to_thread so the event loop
    stays responsive (the prior version was async-in-name-only — sync API +
    time.sleep). A Semaphore caps concurrent exports.
    """
    snippets: dict[str, str] = {}
    if service is None:
        return snippets

    exportable = [f for f in files if is_exportable(f.mime_type)]
    if not exportable:
        return snippets

    semaphore = asyncio.Semaphore(concurrency)

    with Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeElapsedColumn(),
        transient=True,
    ) as progress:
        task = progress.add_task(
            f"Extracting content from {len(exportable)} files",
            total=len(exportable),
        )

        async def fetch_one(f: DriveFile) -> None:
            async with semaphore:
                try:
                    snippet = await asyncio.to_thread(
                        extract_text_snippet, service, f.id, f.mime_type
                    )
                    if snippet:
                        snippets[f.id] = snippet
                except Exception as e:  # noqa: BLE001
                    logger.warning("Snippet extract failed for %s: %s", f.id, e)
                finally:
                    progress.update(task, advance=1)

        await asyncio.gather(*(fetch_one(f) for f in exportable))

    return snippets


async def _classify_with_preset(
    client: GrokClient,
    files: list[DriveFile],
    preset_prompt: str,
    snippets: dict[str, str],
    junk_ids: set[str],
    existing_folders: list[str],
    batch_size: int = BATCH_SIZE,
) -> list[dict]:
    """Classify files using LLM with the given preset prompt — batches in parallel.

    The previous version awaited each batch sequentially; on a 1500-file Drive
    that meant 26 batches × ~30s wall = ~14min. `client.chat()` already
    enforces concurrency via its internal Semaphore(MAX_CONCURRENT=10), so
    spawning all batches at once and letting the client throttle them brings
    the wall time down by roughly that semaphore size.

    Returns raw dicts (not validated models) so the validator layer can
    quarantine individual invalid items. Order is preserved (gather returns
    results in input order); downstream consumers are file_id-keyed and
    don't depend on ordering, but preserving it keeps the rollback log
    deterministic.
    """
    inputs: list[str] = []
    for i in range(0, len(files), batch_size):
        batch = files[i : i + batch_size]
        inputs.append(
            build_preset_input(
                batch,
                snippets=snippets,
                junk_ids=junk_ids,
                existing_folders=existing_folders,
            )
        )

    if not inputs:
        return []

    with Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        TimeElapsedColumn(),
        transient=True,
    ) as progress:
        task = progress.add_task(
            f"LLM classify ({len(files)} files, {len(inputs)} batches in parallel)",
            total=len(inputs),
        )

        async def classify_one(input_text: str) -> str:
            response = await client.chat(preset_prompt, input_text)
            progress.update(task, advance=1)
            return response

        # gather propagates the first exception and cancels the rest, which
        # matches the old sequential behavior of aborting on first failure.
        responses = await asyncio.gather(*(classify_one(t) for t in inputs))

    all_raw: list[dict] = []
    for r in responses:
        all_raw.extend(parse_preset_output_raw(r))
    return all_raw


def _response_to_operations(
    items: list[LLMResponseItem],
    files_by_id: dict[str, DriveFile],
    existing_folders: dict[str, str] | set[str],
) -> list[PlanOperation]:
    """Convert LLM response items into PlanOperations."""
    operations: list[PlanOperation] = []
    existing_folder_ids = (
        existing_folders
        if isinstance(existing_folders, dict)
        else {path: "" for path in existing_folders}
    )
    folders_to_create: dict[str, dict[str, str | None]] = {}
    placeholder_counter = 0

    def resolve_target_folder(path: str | None) -> str | None:
        """Return a real folder ID or placeholder ID for the given path."""
        nonlocal placeholder_counter
        if not path:
            return None
        if path in existing_folder_ids:
            return existing_folder_ids[path] or None
        if path in folders_to_create:
            return folders_to_create[path]["placeholder_id"]

        parts = path.rsplit("/", 1)
        name = parts[-1]
        parent_path = parts[0] if len(parts) > 1 else None
        parent_id = resolve_target_folder(parent_path)
        pid = f"__new_folder_{placeholder_counter}__"
        placeholder_counter += 1
        folders_to_create[path] = {
            "placeholder_id": pid,
            "name": name,
            "parent_id": parent_id,
        }
        return pid

    for item in items:
        file = files_by_id.get(item.file_id)
        if not file:
            continue

        # 1. MOVE to time-based archive
        move_to = item.move_to or _resolve_time_path(file)
        target_parent_id = resolve_target_folder(move_to)
        current_parent = file.parents[0] if file.parents else None

        operations.append(
            PlanOperation(
                file_id=file.id,
                current_name=file.name,
                current_path=file.path,
                operation=OperationType.MOVE,
                new_path=f"{move_to}/{file.name}",
                new_parent_id=target_parent_id,
                current_parent_id=current_parent,
                reason=f"시계열 정리: {move_to}",
            )
        )

        # 2. CREATE_SHORTCUT for each tag/folder
        for shortcut_path in item.shortcuts:
            shortcut_parent_id = resolve_target_folder(shortcut_path)
            operations.append(
                PlanOperation(
                    file_id=f"shortcut__{file.id}__{shortcut_path}",
                    current_name=file.name,
                    current_path=file.path,
                    operation=OperationType.CREATE_SHORTCUT,
                    shortcut_target_id=file.id,
                    shortcut_parent_id=shortcut_parent_id,
                    new_path=f"{shortcut_path}/{file.name}",
                    reason=f"바로가기: {shortcut_path}",
                )
            )

        # 3. UPDATE_DESCRIPTION
        if item.new_description:
            operations.append(
                PlanOperation(
                    file_id=file.id,
                    current_name=file.name,
                    current_path=file.path,
                    operation=OperationType.UPDATE_DESCRIPTION,
                    new_description=item.new_description,
                    current_description=file.description,
                    reason="설명 주입",
                )
            )

    # Prepend folder creation operations
    folder_ops = []
    for path, metadata in folders_to_create.items():
        folder_ops.append(
            PlanOperation(
                file_id=metadata["placeholder_id"],
                current_name=metadata["name"] or "",
                current_path="",
                operation=OperationType.CREATE_FOLDER,
                new_parent_id=metadata["parent_id"],
                new_path=path,
                reason=f"폴더 생성: {path}",
            )
        )

    return folder_ops + operations


def _add_trash_operations(
    junk_list: list,
    files_by_id: dict[str, DriveFile],
) -> list[PlanOperation]:
    """Create TRASH operations for confirmed junk duplicates."""
    ops = []
    for junk in junk_list:
        if junk.is_trash_candidate:
            file = files_by_id.get(junk.file_id)
            if not file:
                continue
            ops.append(
                PlanOperation(
                    file_id=file.id,
                    current_name=file.name,
                    current_path=file.path,
                    operation=OperationType.TRASH,
                    reason=f"중복 파일 (junk: {junk.reason})",
                )
            )
    return ops


def detect_conflicts(
    operations: list[PlanOperation],
) -> list[tuple[PlanOperation, PlanOperation]]:
    """Find operations that would create name collisions in the same folder."""
    conflicts = []
    targets: dict[str, PlanOperation] = {}
    for op in operations:
        if op.operation in (OperationType.CREATE_FOLDER, OperationType.UPDATE_DESCRIPTION):
            continue
        target_name = op.new_name or op.current_name
        target_path = op.new_path or op.current_path
        target_folder = target_path.rsplit("/", 1)[0] if "/" in target_path else ""
        key = f"{target_folder}/{target_name}"
        if key in targets:
            conflicts.append((targets[key], op))
        else:
            targets[key] = op
    return conflicts


def _next_available_name(name: str, taken: set[str]) -> str:
    """Return `name`, or `name (2)`, `name (3)` ... until not in `taken`."""
    if name not in taken:
        return name
    if "." in name:
        base, ext = name.rsplit(".", 1)
        ext = "." + ext
    else:
        base, ext = name, ""
    n = 2
    while True:
        candidate = f"{base} ({n}){ext}"
        if candidate not in taken:
            return candidate
        n += 1


def resolve_conflicts(operations: list[PlanOperation]) -> int:
    """Rename later ops with ` (2)` suffix when destination collides.

    Previous behavior was to drop the later op, which left duplicates
    (different files with the same name) stranded at root forever — they
    would be dropped from every subsequent plan as well. Renaming preserves
    the data: every file gets organized, just with disambiguated names.

    Mutates operations in place. Returns the number of renames.
    """
    seen_per_folder: dict[str, set[str]] = {}
    renames = 0
    for op in operations:
        if op.operation in (OperationType.CREATE_FOLDER, OperationType.UPDATE_DESCRIPTION):
            continue
        name = op.new_name or op.current_name
        path = op.new_path or op.current_path
        folder = path.rsplit("/", 1)[0] if "/" in path else ""
        taken = seen_per_folder.setdefault(folder, set())
        if name in taken:
            new_name = _next_available_name(name, taken)
            op.new_name = new_name
            op.new_path = f"{folder}/{new_name}" if folder else new_name
            logger.warning(
                "[planner] Renamed '%s' -> '%s' to avoid conflict in '%s'",
                name,
                new_name,
                folder or "(root)",
            )
            renames += 1
            name = new_name
        taken.add(name)
    return renames


async def generate_plan(
    snapshot: Snapshot,
    config: Config,
    preset_id: str = "migration",
    prompt_file: Path | None = None,
    service: Resource | None = None,
) -> ExecutionPlan:
    """Generate an execution plan using the preset-based pipeline."""
    preset = load_preset(preset_id, prompt_file)
    client = GrokClient(config)

    # Separate files and folders. Two filters:
    #
    # 1. ownedByMe=False — Drive rejects move/update on shared-from-others
    #    files (canEdit/canMove=False), so including them produces guaranteed
    #    apply failures (#J1 from Stage-1 dogfood: 7 of 15 failures were
    #    `ownedByMe=False` PDFs in shared course folders). owned_by_me=None
    #    means the scanner couldn't determine — be permissive there.
    #
    # 2. shortcut mimeType — using a shortcut as a source produces a
    #    shortcut-of-shortcut chain that Drive rejects (#J2 from Stage-2
    #    dogfood: 4 of 4 remaining failures were shortcuts created by an
    #    earlier apply, then handed back as classification candidates by the
    #    next plan). Shortcuts are navigation aids, not organize targets.
    candidate_files = [f for f in snapshot.files if f.mime_type != FOLDER_MIME]
    files = [
        f for f in candidate_files if f.owned_by_me is not False and f.mime_type != SHORTCUT_MIME
    ]
    skipped_unowned = sum(1 for f in candidate_files if f.owned_by_me is False)
    skipped_shortcuts = sum(1 for f in candidate_files if f.mime_type == SHORTCUT_MIME)
    if skipped_unowned:
        logger.info(
            "Skipping %d shared-from-others file(s) (ownedByMe=False).",
            skipped_unowned,
        )
    if skipped_shortcuts:
        logger.info(
            "Skipping %d shortcut file(s) (mimeType=shortcut — already a pointer).",
            skipped_shortcuts,
        )
    files_by_id = {f.id: f for f in snapshot.files}
    existing_folders = _get_existing_folders(snapshot)
    existing_folder_index = _get_existing_folder_index(snapshot)
    existing_folder_paths = set(existing_folder_index)

    # Junk detection
    from gdrive_organizer.store.snapshot import drive_file_to_raw

    raw_files = [drive_file_to_raw(f) for f in files]
    md5_index = build_md5_index(raw_files)
    junk_list = detect_junk_files(raw_files, md5_index=md5_index)
    junk_ids = {j.file_id for j in junk_list}

    # Text snippet extraction — only when the preset actually reads content.
    # Migration is metadata-only, so skipping this saves ~21 minutes on a
    # 1500-file Drive (590 exportable docs × serial export latency).
    if preset.requires_content:
        snippets = await _extract_snippets(service, files)
    else:
        logger.info(
            "Skipping content extraction (preset '%s' is metadata-only).",
            preset.id,
        )
        snippets = {}

    # LLM classification — returns raw dicts for validator
    try:
        raw_items = await _classify_with_preset(
            client,
            files,
            preset.system_prompt,
            snippets,
            junk_ids,
            existing_folders,
        )
    finally:
        await client.close()

    # --- Trust boundary: validate LLM responses before conversion ---
    snapshot_file_ids = set(files_by_id.keys())
    validation = validate_llm_responses(
        raw_items=raw_items,
        snapshot_file_ids=snapshot_file_ids,
        snapshot_folder_paths=existing_folder_paths,
    )
    if validation.rejected:
        save_quarantine_log(validation.rejected, config)
        logger.warning(
            "LLM validation: %d accepted, %d rejected (quarantined)",
            len(validation.accepted),
            validation.reject_count,
        )
    items = validation.accepted

    # Convert to operations
    operations = _response_to_operations(items, files_by_id, existing_folder_index)

    # Add trash operations for junk duplicates
    trash_ops = _add_trash_operations(junk_list, files_by_id)
    operations.extend(trash_ops)

    # Conflict resolution: when two ops would land at the same destination,
    # rename the later op with a " (N)" suffix instead of dropping it.
    # Dropping silently strands duplicate-named files at root forever
    # (they get dropped again on every subsequent classify) — Stage-5
    # dogfood found 6 such files that survived 4 stages. Renaming
    # preserves the data and lets every file get organized.
    resolve_conflicts(operations)

    # Stats
    stats = build_plan_stats(operations)

    plan = ExecutionPlan(
        created_at=datetime.now(UTC),
        snapshot_ref=str(snapshot.scanned_at),
        preset_id=preset_id,
        operations=operations,
        stats=stats,
    )

    save_plan(plan, config)

    return plan
