"""FastAPI local web viewer for Drive data."""

from __future__ import annotations

import secrets
import time
import webbrowser
from collections import Counter
from pathlib import Path
from typing import TYPE_CHECKING

import uvicorn
from fastapi import Cookie, FastAPI, HTTPException, Query
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request

if TYPE_CHECKING:
    from gdrive_organizer.config import Config
    from gdrive_organizer.models import Snapshot

VIEWER_DIR = Path(__file__).parent
TEMPLATES_DIR = VIEWER_DIR / "templates"
STATIC_DIR = VIEWER_DIR / "static"

# Lightweight rate limiter for mutation endpoints
MUTATION_RATE_LIMIT = 10  # max calls per window
MUTATION_RATE_WINDOW = 60  # seconds


def _viewer_operation_id(index: int) -> str:
    """Build a stable viewer-only operation identifier from plan order."""
    return f"op-{index}"


def _serialize_plan_for_viewer(plan) -> dict:
    """Serialize a plan with viewer-only per-operation IDs."""
    payload = plan.model_dump(mode="json")
    for idx, operation in enumerate(payload.get("operations", [])):
        operation["viewer_operation_id"] = _viewer_operation_id(idx)
    return payload


class _MutationRateLimiter:
    """Simple in-memory sliding-window rate limiter for mutation endpoints."""

    def __init__(self, max_calls: int = MUTATION_RATE_LIMIT, window: int = MUTATION_RATE_WINDOW):
        self._max = max_calls
        self._window = window
        self._calls: list[float] = []

    def check(self) -> bool:
        """Return True if the call is allowed, False if rate-limited."""
        now = time.monotonic()
        self._calls = [t for t in self._calls if now - t < self._window]
        if len(self._calls) >= self._max:
            return False
        self._calls.append(now)
        return True


class SnapshotCache:
    """Cache snapshot in memory to avoid re-reading 200MB+ JSON on every request.

    Tracks the mtime of the latest snapshot file and invalidates when it
    advances — so a CLI scan that produces a new snapshot is picked up by
    the next viewer request, no manual reload needed (#J3).
    """

    def __init__(self):
        self._snapshot: Snapshot | None = None
        self._tree_data: dict | None = None
        self._snapshot_mtime: float | None = None

    @staticmethod
    def _resolve_latest_snapshot_path(config: Config) -> Path | None:
        """Return the actual on-disk path of the latest snapshot, or None."""
        snapshots_dir = config.data_dir / "snapshots"
        gz = snapshots_dir / "latest.json.gz"
        if gz.is_symlink() or gz.exists():
            return gz.resolve() if gz.is_symlink() else gz
        plain = snapshots_dir / "latest.json"
        if plain.is_symlink() or plain.exists():
            return plain.resolve() if plain.is_symlink() else plain
        return None

    def _check_freshness(self, config: Config) -> None:
        """Invalidate the cache if the latest snapshot file has advanced."""
        path = self._resolve_latest_snapshot_path(config)
        if path is None:
            return
        try:
            mtime = path.stat().st_mtime
        except OSError:
            return
        if self._snapshot_mtime is not None and mtime > self._snapshot_mtime:
            self.invalidate()
        self._snapshot_mtime = mtime

    def get_snapshot(self, config: Config) -> Snapshot:
        self._check_freshness(config)
        if self._snapshot is None:
            from gdrive_organizer.store.snapshot import load_snapshot

            self._snapshot = load_snapshot(config=config)
        return self._snapshot

    def get_tree(self, config: Config) -> dict:
        """Build tree once and cache it."""
        snapshot = self.get_snapshot(config)
        if self._tree_data is None:
            from gdrive_organizer.scanner.tree import build_tree, compute_paths

            raw_files = [
                {"id": f.id, "name": f.name, "mimeType": f.mime_type, "parents": f.parents}
                for f in snapshot.files
            ]
            node_map, roots = build_tree(raw_files)
            compute_paths(roots)
            self._tree_data = {"node_map": node_map, "roots": roots}
        return self._tree_data

    def invalidate(self):
        self._snapshot = None
        self._tree_data = None


def _node_to_dict_shallow(node, depth: int = 0, max_depth: int = 2) -> dict:
    """Convert node to dict with limited depth for lazy loading."""
    result = {
        "id": node.file_id,
        "name": node.name,
        "mimeType": node.mime_type,
        "path": node.path,
        "isFolder": node.is_folder,
        "childCount": len(node.children),
    }
    if depth < max_depth:
        result["children"] = [_node_to_dict_shallow(c, depth + 1, max_depth) for c in node.children]
    else:
        result["children"] = None  # Signal to client: fetch on expand
    return result


def create_app(config: Config) -> FastAPI:
    """Create and configure the FastAPI app."""
    app = FastAPI(title="DriveCore Viewer")
    templates = Jinja2Templates(directory=str(TEMPLATES_DIR))
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    cache = SnapshotCache()
    app.state.config = config

    # ── Session token for mutation endpoints ─────────────────────
    session_token = secrets.token_urlsafe(32)
    app.state.session_token = session_token
    mutation_limiter = _MutationRateLimiter()

    def _verify_session(token: str | None) -> None:
        """Raise 403 if the session token is missing or invalid."""
        if token != session_token:
            raise HTTPException(status_code=403, detail="Invalid or missing session token")

    def _check_rate_limit() -> None:
        """Raise 429 if mutation rate limit exceeded."""
        if not mutation_limiter.check():
            raise HTTPException(status_code=429, detail="Rate limit exceeded. Try again shortly.")

    # ── Page Routes ──────────────────────────────────────────────

    def _page_response(request: Request, template: str) -> HTMLResponse:
        """Render a page template and set the session cookie."""
        resp = templates.TemplateResponse(request, template)
        resp.set_cookie(
            key="drivecore_session",
            value=session_token,
            httponly=True,
            samesite="strict",
            path="/",
        )
        return resp

    @app.get("/", response_class=HTMLResponse)
    async def index(request: Request):
        return _page_response(request, "index.html")

    @app.get("/explorer", response_class=HTMLResponse)
    async def explorer_page(request: Request):
        return _page_response(request, "explorer.html")

    @app.get("/plan", response_class=HTMLResponse)
    async def plan_page(request: Request):
        return _page_response(request, "plan.html")

    @app.get("/permissions", response_class=HTMLResponse)
    async def permissions_page(request: Request):
        return _page_response(request, "permissions.html")

    @app.get("/duplicates", response_class=HTMLResponse)
    async def duplicates_page(request: Request):
        return _page_response(request, "duplicates.html")

    @app.get("/settings", response_class=HTMLResponse)
    async def settings_page(request: Request):
        return _page_response(request, "settings.html")

    # ── Data API Endpoints ───────────────────────────────────────

    no_snapshot_msg = {
        "empty": True,
        "message": "No snapshot found. Run 'gdrive-organizer scan' from the CLI first.",
    }

    @app.get("/api/tree")
    async def api_tree(
        node_id: str | None = Query(None, description="Folder ID to expand"),
    ):
        try:
            tree_data = cache.get_tree(config)
        except FileNotFoundError:
            return no_snapshot_msg
        if node_id:
            node = tree_data["node_map"].get(node_id)
            if not node:
                return {"children": []}
            return {"children": [_node_to_dict_shallow(c, 0, 2) for c in node.children]}
        return {"tree": [_node_to_dict_shallow(r, 0, 2) for r in tree_data["roots"]]}

    @app.get("/api/files")
    async def api_files(q: str = Query("", description="Search query")):
        try:
            snapshot = cache.get_snapshot(config)
        except FileNotFoundError:
            return no_snapshot_msg
        if not q:
            return {"files": [_file_summary(f) for f in snapshot.files[:100]]}
        query = q.lower()
        matched = [f for f in snapshot.files if query in f.name.lower()]
        return {"files": [_file_summary(f) for f in matched[:100]]}

    @app.get("/api/stats")
    async def api_stats():
        try:
            snapshot = cache.get_snapshot(config)
        except FileNotFoundError:
            return no_snapshot_msg
        type_counter: Counter[str] = Counter()
        for f in snapshot.files:
            type_counter[f.mime_type] += 1

        # Freshness: when was the latest plan generated?
        last_classify_at: str | None = None
        plans_dir = config.data_dir / "plans"
        if plans_dir.exists():
            plan_files = sorted(plans_dir.glob("plan-*.json"), reverse=True)
            if plan_files:
                try:
                    import json as _json

                    data = _json.loads(plan_files[0].read_text())
                    last_classify_at = data.get("created_at")
                except Exception:
                    last_classify_at = None

        return {
            "stats": snapshot.stats.model_dump(),
            "drive_info": snapshot.drive_info.model_dump() if snapshot.drive_info else None,
            "type_distribution": dict(type_counter.most_common(20)),
            "total_files_count": len(snapshot.files),
            "last_scan_at": snapshot.scanned_at.isoformat() if snapshot.scanned_at else None,
            "last_classify_at": last_classify_at,
        }

    @app.get("/api/permissions")
    async def api_permissions():
        from gdrive_organizer.scanner.permissions import summarize_permissions

        try:
            snapshot = cache.get_snapshot(config)
        except FileNotFoundError:
            return no_snapshot_msg
        return summarize_permissions(snapshot.files)

    @app.get("/api/plan")
    async def api_plan():
        from gdrive_organizer.ai.planner import approved_plan_path, load_plan, resolve_plan_path

        latest_path = resolve_plan_path(config, mode="latest")
        approved_path = approved_plan_path(config)
        approved_count = 0
        if approved_path.exists():
            try:
                approved_count = len(load_plan(approved_path).operations)
            except Exception:
                approved_count = 0
        if not latest_path:
            return {
                "plan": None,
                "approved_plan_present": approved_path.exists(),
                "approved_operation_count": approved_count,
                "approved_source": approved_path.name if approved_path.exists() else None,
            }
        data = _serialize_plan_for_viewer(load_plan(latest_path))
        return {
            "plan": data,
            "approved_plan_present": approved_path.exists(),
            "approved_operation_count": approved_count,
            "approved_source": approved_path.name if approved_path.exists() else None,
        }

    @app.post("/api/plan/approve")
    async def api_plan_approve(
        body: dict,
        drivecore_session: str | None = Cookie(None),
    ):
        """Approve selected plan operations. Requires session token and confirmation."""
        from gdrive_organizer.ai.planner import (
            approved_plan_path,
            build_plan_stats,
            load_plan,
            resolve_plan_path,
        )

        # Session token gate: mutations require a valid session
        _verify_session(drivecore_session)
        _check_rate_limit()

        approved_ids = set(body.get("approved_ids", []))
        approved_operation_ids = set(body.get("approved_operation_ids", []))
        confirmed = body.get("confirmed", False)

        latest_path = resolve_plan_path(config, mode="latest")
        if not latest_path:
            return {"error": "No plan found"}
        plan = load_plan(latest_path)
        if approved_operation_ids:
            operations = [
                op
                for idx, op in enumerate(plan.operations)
                if _viewer_operation_id(idx) in approved_operation_ids
            ]
        elif approved_ids:
            operations = [op for op in plan.operations if op.file_id in approved_ids]
        else:
            operations = list(plan.operations)

        data = plan.model_copy(
            update={"operations": operations, "stats": build_plan_stats(operations)}
        )
        ops = _serialize_plan_for_viewer(data).get("operations", [])
        trash_count = sum(1 for op in ops if op.get("operation") == "trash")

        # Build summary for any confirmation flow
        op_summary = {}
        for op in ops:
            op_type = op.get("operation", "unknown")
            op_summary[op_type] = op_summary.get(op_type, 0) + 1

        # Confirmation barrier: always require confirmation
        if not confirmed:
            return {
                "status": "confirmation_required",
                "operations": len(ops),
                "trash_count": trash_count,
                "summary": op_summary,
                "message": "Send confirmed=true to proceed.",
            }

        # Server-side enforcement: TRASH ops require explicit trash_confirmed flag
        if trash_count > 0:
            trash_confirmed = body.get("trash_confirmed", False)
            if not trash_confirmed:
                return {
                    "status": "trash_confirmation_required",
                    "trash_count": trash_count,
                    "message": "Plan contains TRASH ops. Send trash_confirmed=true.",
                }

        approved_path = approved_plan_path(config)
        approved_path.write_text(data.model_dump_json(indent=2))
        return {
            "status": "approved",
            "operations": len(ops),
            "trash_count": trash_count,
            "message": (
                "Approved selection saved. "
                "'gdrive-organizer plan apply' now runs the approved selection by default. "
                "Use '--latest-plan' to apply the full plan."
            ),
        }

    @app.delete("/api/plan/approve")
    async def api_plan_approve_clear(
        drivecore_session: str | None = Cookie(None),
    ):
        """Clear the approved subset so `plan apply` falls back to the latest full plan."""
        from gdrive_organizer.ai.planner import approved_plan_path

        _verify_session(drivecore_session)
        _check_rate_limit()

        approved_path = approved_plan_path(config)
        if approved_path.exists():
            approved_path.unlink()
            return {"status": "cleared"}
        return {"status": "noop", "message": "No approved plan to clear."}

    @app.get("/api/last-applied")
    async def api_last_applied(details: bool = False):
        """Return metadata about the most recent applied plan (via its rollback log).

        When `details=true`, also returns per-op status list and summary counts.
        The viewer uses this as a read-only surface; actual rollback is executed from the CLI
        with `gdrive-organizer plan rollback` to preserve the CLI-first mutation model.
        """
        import json as _json

        logs_dir = config.data_dir / "logs"
        if not logs_dir.exists():
            return {"present": False}
        log_files = sorted(logs_dir.glob("rollback-*.json"), reverse=True)
        if not log_files:
            return {"present": False}
        latest = log_files[0]
        try:
            data = _json.loads(latest.read_text())
        except Exception:
            return {"present": False}
        ops = data.get("operations", [])

        summary: dict[str, int] = {"ok": 0, "failed": 0, "other": 0}
        for op in ops:
            status = (op.get("status") or "").lower()
            if status in ("ok", "success"):
                summary["ok"] += 1
            elif status in ("failed", "error"):
                summary["failed"] += 1
            else:
                summary["other"] += 1

        result = {
            "present": True,
            "log_name": latest.name,
            "executed_at": data.get("executedAt"),
            "operation_count": len(ops),
            "plan_ref": data.get("planRef"),
            "summary": summary,
        }
        if details:
            result["operations"] = [
                {
                    "file_id": op.get("fileId"),
                    "type": op.get("type"),
                    "status": op.get("status"),
                    "name": (op.get("before") or {}).get("name") or op.get("fileId"),
                }
                for op in ops
            ]
        return result

    @app.get("/api/file/{file_id}")
    async def api_file_detail(file_id: str):
        try:
            snapshot = cache.get_snapshot(config)
        except FileNotFoundError:
            return no_snapshot_msg
        for f in snapshot.files:
            if f.id == file_id:
                return f.model_dump(mode="json")
        return {"error": "not found"}

    @app.get("/api/shared-with-me")
    async def api_shared_with_me():
        """Files shared by others."""
        try:
            snapshot = cache.get_snapshot(config)
        except FileNotFoundError:
            return no_snapshot_msg
        shared = [
            _file_summary(f) | {"sharing_user": f.sharing_user}
            for f in snapshot.files
            if f.owned_by_me is False
        ]
        return {"files": shared, "count": len(shared)}

    @app.get("/api/shared-by-me")
    async def api_shared_by_me():
        """Files I own that are shared with others (with permission details)."""
        try:
            snapshot = cache.get_snapshot(config)
        except FileNotFoundError:
            return no_snapshot_msg
        shared = []
        for f in snapshot.files:
            if not (f.owned_by_me is True and f.shared is True):
                continue
            summary = _file_summary(f)
            recipients = []
            for p in f.permissions:
                if p.role.value == "owner":
                    continue
                recipients.append(
                    {
                        "type": p.type,
                        "role": p.role.value,
                        "email": p.email,
                        "display_name": p.display_name,
                    }
                )
            summary["recipients"] = recipients
            summary["recipient_count"] = len(recipients)
            shared.append(summary)
        return {"files": shared, "count": len(shared)}

    @app.get("/api/drive-info")
    async def api_drive_info():
        """Drive account storage and user info."""
        try:
            snapshot = cache.get_snapshot(config)
        except FileNotFoundError:
            return no_snapshot_msg
        if snapshot.drive_info:
            return snapshot.drive_info.model_dump()
        return {"error": "No drive info. Rescan required."}

    @app.get("/api/duplicates")
    async def api_duplicates():
        try:
            snapshot = cache.get_snapshot(config)
        except FileNotFoundError:
            return no_snapshot_msg
        by_md5: dict[str, list] = {}
        for f in snapshot.files:
            if f.md5_checksum:
                by_md5.setdefault(f.md5_checksum, []).append(_file_summary(f))
        duplicates = {k: v for k, v in by_md5.items() if len(v) > 1}
        return {
            "duplicates": duplicates,
            "total_duplicate_groups": len(duplicates),
        }

    @app.get("/api/config")
    async def api_config():
        """Return current configuration (excluding sensitive paths)."""
        data = config.model_dump(mode="json")
        safe_keys = [
            "viewer_port",
            "llm_model",
            "log_level",
            "scan_page_size",
            "batch_size",
            "write_rate_limit",
        ]
        return {"config": {k: data[k] for k in safe_keys if k in data}}

    @app.get("/api/auth/status")
    async def api_auth_status():
        """Check OAuth token status."""
        from gdrive_organizer.auth.oauth import check_token_status

        if not config.token_path.exists():
            return {"authenticated": False}
        status = check_token_status(config)
        return {
            "authenticated": bool(status.get("valid")),
            "email": status.get("email"),
            "token_expiry": status.get("expiry"),
            "expired": status.get("expired", False),
        }

    @app.post("/api/auth/login")
    async def api_auth_login(drivecore_session: str | None = Cookie(None)):
        """Trigger the OAuth flow (opens a browser window)."""
        import asyncio

        from gdrive_organizer.auth.oauth import (
            auto_detect_credentials,
            get_drive_service,
        )

        _verify_session(drivecore_session)
        _check_rate_limit()

        if not config.credentials_path.exists() and not auto_detect_credentials(config):
            return {
                "status": "error",
                "error": (
                    "OAuth credentials not found. Download the client JSON from "
                    "Google Cloud Console to your Downloads folder and retry."
                ),
            }

        try:
            service = await asyncio.to_thread(get_drive_service, config)
            about = await asyncio.to_thread(lambda: service.about().get(fields="user").execute())
            user = about.get("user", {})
            return {
                "status": "ok",
                "email": user.get("emailAddress"),
            }
        except Exception as e:
            return {"status": "error", "error": str(e)}

    # ── API Key Management ───────────────────────────────────────

    @app.get("/api/apikey/status")
    async def api_apikey_status():
        """Check if xAI API key is registered."""
        from gdrive_organizer.ai.classifier import load_api_key

        key = load_api_key()
        if key:
            masked = key[:8] + "•" * (len(key) - 12) + key[-4:]
            return {"registered": True, "masked_key": masked}
        return {"registered": False, "masked_key": None}

    @app.post("/api/apikey/set")
    async def api_apikey_set(body: dict, drivecore_session: str | None = Cookie(None)):
        """Validate and save xAI API key to system keychain."""
        _verify_session(drivecore_session)
        _check_rate_limit()
        import httpx as httpx_client

        from gdrive_organizer.ai.classifier import XAI_BASE_URL, save_api_key

        key = body.get("api_key", "").strip()
        if not key:
            return {"error": "API key is required"}

        # Validate by calling xAI models endpoint
        try:
            async with httpx_client.AsyncClient(timeout=10.0) as client:
                resp = await client.get(
                    f"{XAI_BASE_URL}/models",
                    headers={"Authorization": f"Bearer {key}"},
                )
            if resp.status_code == 401:
                return {"error": "Invalid API key (401 Unauthorized)"}
            if resp.status_code == 403:
                return {"error": "API key lacks permissions (403 Forbidden)"}
            if resp.status_code not in (200, 201):
                return {"error": f"Validation failed (HTTP {resp.status_code})"}
        except httpx_client.TimeoutException:
            return {"error": "xAI API timeout — check your network"}
        except Exception as e:
            return {"error": f"Validation request failed: {e}"}

        save_api_key(key)
        masked = key[:8] + "•" * (len(key) - 12) + key[-4:]
        return {"status": "saved", "masked_key": masked}

    @app.delete("/api/apikey")
    async def api_apikey_delete(drivecore_session: str | None = Cookie(None)):
        """Delete xAI API key from system keychain."""
        _verify_session(drivecore_session)
        _check_rate_limit()
        from gdrive_organizer.ai.classifier import delete_api_key

        delete_api_key()
        return {"status": "deleted"}

    return app


def start_viewer(config: Config, unsafe_public: bool = False) -> None:
    """Start the viewer server and open browser.

    Defaults to 127.0.0.1 binding. Passing unsafe_public=True binds to 0.0.0.0
    with a prominent warning.
    """
    host = config.viewer_host
    if unsafe_public:
        host = "0.0.0.0"
    elif host not in ("127.0.0.1", "localhost", "::1"):
        from rich.console import Console

        Console().print(
            f"[bold red]WARNING:[/bold red] viewer_host is set to '{host}'. "
            "Use --unsafe-public to confirm non-localhost binding, "
            "or set viewer_host=127.0.0.1 in config."
        )
        host = "127.0.0.1"

    app = create_app(config)

    from rich.console import Console

    console = Console()
    url = f"http://{host}:{config.viewer_port}"
    console.print(f"[bold green]DriveCore viewer:[/bold green] {url}")
    if unsafe_public:
        console.print("[bold red]WARNING: Viewer is publicly accessible![/bold red]")

    webbrowser.open(f"http://127.0.0.1:{config.viewer_port}")
    uvicorn.run(app, host=host, port=config.viewer_port, log_level="warning")


def _file_summary(f) -> dict:
    """Lightweight file dict for search results and listings."""
    return {
        "id": f.id,
        "name": f.name,
        "mime_type": f.mime_type,
        "path": f.path,
        "size": f.size,
        "owned_by_me": f.owned_by_me,
        "starred": f.starred,
        "shared": f.shared,
        "md5_checksum": f.md5_checksum,
        "file_extension": f.file_extension,
        "modified_time": f.modified_time.isoformat() if f.modified_time else None,
        "sharing_user": f.sharing_user,
        "version": f.version,
        "revision_count": f.revision_count,
    }
