/* DriveCore — Client-side Application */

// ════════════════════════════════════════
// Theme
// ════════════════════════════════════════

function toggleTheme() {
    const html = document.documentElement;
    const isDark = html.classList.toggle('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
}

// ════════════════════════════════════════
// Toast Notifications
// ════════════════════════════════════════

function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

// ════════════════════════════════════════
// Utilities
// ════════════════════════════════════════

function debounce(fn, ms) {
    let timer;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => fn.apply(this, args), ms);
    };
}

function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// ════════════════════════════════════════
// Empty / Error State Renderer
// ════════════════════════════════════════
// Single entry point so every empty/error surface looks and reads the same.
// Usage: renderEmptyState(container, { icon, title, description, command, hint, tone })
//   tone: 'neutral' (default) | 'error' | 'success'
function renderEmptyState(container, opts) {
    if (!container) return;
    const {
        icon = 'inbox',
        title = '',
        description = '',
        command = '',
        hint = '',
        tone = 'neutral',
    } = opts || {};
    const iconClass = {
        neutral: 'text-[#86868B]',
        error: 'text-red-500',
        success: 'text-green-500',
    }[tone] || 'text-[#86868B]';
    const cmdHtml = command
        ? `<code class="inline-block px-3 py-1.5 rounded-lg bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[12px] font-mono select-all">${escapeHtml(command)}</code>`
        : '';
    container.innerHTML = `
        <div class="text-center py-16">
            <i data-lucide="${escapeHtml(icon)}" class="w-12 h-12 ${iconClass} mx-auto mb-4"></i>
            <p class="text-[15px] font-medium mb-2">${escapeHtml(title)}</p>
            ${description ? `<p class="text-[#86868B] text-[13px] mb-4">${escapeHtml(description)}</p>` : ''}
            ${cmdHtml}
            ${hint ? `<p class="text-[#86868B] text-[12px] mt-4">${escapeHtml(hint)}</p>` : ''}
        </div>`;
    if (window.lucide) lucide.createIcons();
}

function formatSize(bytes) {
    if (!bytes) return '0 B';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let i = 0, size = bytes;
    while (size >= 1024 && i < units.length - 1) { size /= 1024; i++; }
    return `${size.toFixed(1)} ${units[i]}`;
}

function formatDate(iso) {
    if (!iso) return '—';
    return new Date(iso).toLocaleString('ko-KR', {
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit',
    });
}

function timeAgo(iso) {
    if (!iso) return 'never';
    const diff = Date.now() - new Date(iso).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    const days = Math.floor(hrs / 24);
    return `${days}d ago`;
}

async function apiFetch(url, opts) {
    try {
        const resp = await fetch(url, opts);
        if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
        return await resp.json();
    } catch (e) {
        console.error(`API error [${url}]:`, e);
        throw e;
    }
}

// ════════════════════════════════════════
// Dashboard
// ════════════════════════════════════════

async function loadDashboard() {
    try {
        const [statsData, dupData, permData] = await Promise.all([
            apiFetch('/api/stats'),
            apiFetch('/api/duplicates'),
            apiFetch('/api/permissions'),
        ]);
        renderMetrics(statsData, dupData, permData);
        renderStorageBreakdown(statsData);
    } catch {
        showToast('Failed to load dashboard data. Run "gdrive-organizer scan" first.', 'error');
    }
}

function renderMetrics(statsData, dupData, permData) {
    const stats = statsData.stats || {};
    const totalSize = stats.total_size || 0;
    const totalItems = statsData.total_files_count || 0;
    const scannedAt = statsData.last_scan_at;
    const classifiedAt = statsData.last_classify_at;

    // Storage Used
    const elStorage = document.getElementById('metric-storage');
    if (elStorage) {
        elStorage.querySelector('.metric-value').textContent = formatSize(totalSize);
        elStorage.querySelector('.metric-sub').textContent = `${(totalItems || 0).toLocaleString()} items indexed`;
    }

    // Indexed Items
    const elItems = document.getElementById('metric-items');
    if (elItems) {
        elItems.querySelector('.metric-value').textContent = totalItems.toLocaleString();
        elItems.querySelector('.metric-sub').textContent = scannedAt ? `Updated ${timeAgo(scannedAt)}` : 'No scan yet';
    }

    renderFreshnessChips(scannedAt, classifiedAt);

    // Wasted Space (duplicates)
    const dupGroups = dupData.total_duplicate_groups || 0;
    let wastedSize = 0;
    if (dupData.duplicates) {
        for (const files of Object.values(dupData.duplicates)) {
            for (let i = 1; i < files.length; i++) {
                wastedSize += files[i].size || 0;
            }
        }
    }
    const elWaste = document.getElementById('metric-waste');
    if (elWaste) {
        elWaste.querySelector('.metric-value').textContent = formatSize(wastedSize);
        elWaste.querySelector('.metric-sub').textContent = `Found in ${dupGroups} duplicate groups`;
    }
}

// ────────────────────────────────────────
// Dashboard: data freshness chips
// ────────────────────────────────────────

function renderFreshnessChips(scannedAt, classifiedAt) {
    const el = document.getElementById('freshness-chips');
    if (!el) return;
    const chips = [];
    chips.push(_freshnessChip({
        icon: 'database',
        label: 'Last scan',
        iso: scannedAt,
        emptyText: 'gdrive-organizer scan',
    }));
    chips.push(_freshnessChip({
        icon: 'sparkles',
        label: 'Last classify',
        iso: classifiedAt,
        emptyText: 'gdrive-organizer classify',
    }));
    el.innerHTML = chips.join('');
    if (window.lucide) lucide.createIcons();
}

function _freshnessChip({ icon, label, iso, emptyText }) {
    const present = Boolean(iso);
    const tone = present ? 'text-[#86868B]' : 'text-orange-500';
    const body = present
        ? `${escapeHtml(label)}: <span class="font-semibold">${escapeHtml(timeAgo(iso))}</span>`
        : `${escapeHtml(label)}: <code class="px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[11px] font-mono">${escapeHtml(emptyText)}</code>`;
    return `
        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/60 dark:bg-white/5 border border-[#E5E5EA] dark:border-[#38383A] ${tone}">
            <i data-lucide="${escapeHtml(icon)}" class="w-3.5 h-3.5"></i>
            ${body}
        </span>`;
}

function renderStorageBreakdown(statsData) {
    const dist = statsData.type_distribution || {};

    // Categorize MIME types
    const categories = { Video: 0, Images: 0, Documents: 0, Other: 0 };
    for (const [mime, count] of Object.entries(dist)) {
        if (mime.startsWith('video/')) categories.Video += count;
        else if (mime.startsWith('image/')) categories.Images += count;
        else if (mime.startsWith('application/pdf') || mime.startsWith('text/') ||
                 mime.includes('document') || mime.includes('spreadsheet') ||
                 mime.includes('presentation') || mime.includes('form')) {
            categories.Documents += count;
        } else {
            categories.Other += count;
        }
    }

    const total = Object.values(categories).reduce((a, b) => a + b, 0) || 1;
    const colors = ['#6366F1', '#A855F7', '#D946EF'];
    const catEntries = Object.entries(categories);

    // Bar segments
    const barEl = document.getElementById('storage-bar');
    if (barEl) {
        barEl.innerHTML = catEntries.map(([, count], i) => {
            const pct = Math.max((count / total) * 100, 1);
            const bg = i < 3 ? colors[i] : 'var(--bar-other)';
            return `<div class="storage-bar-segment h-full" style="width:${pct}%;background:${bg}"></div>`;
        }).join('');
    }

    // Legend
    const legendEl = document.getElementById('storage-legend');
    if (legendEl) {
        legendEl.innerHTML = catEntries.map(([label, count], i) => {
            const dotColor = i < 3 ? colors[i] : '#86868B';
            return `
                <div>
                    <div class="flex items-center space-x-2 mb-1.5">
                        <div class="w-2.5 h-2.5 rounded-full" style="background:${dotColor}"></div>
                        <span class="text-[13px] font-medium text-[#86868B]">${label}</span>
                    </div>
                    <p class="text-[20px] font-bold">${count.toLocaleString()}</p>
                </div>`;
        }).join('');
    }

    // MIME detail table
    const detailEl = document.getElementById('storage-detail');
    if (detailEl) {
        const sorted = Object.entries(dist).sort((a, b) => b[1] - a[1]);
        const maxCount = sorted.length > 0 ? sorted[0][1] : 1;
        detailEl.innerHTML = sorted.map(([mime, count]) => {
            const pct = (count / maxCount) * 100;
            return `
                <div class="flex items-center gap-3 py-1.5">
                    <span class="w-48 text-[13px] truncate text-[#86868B]" title="${escapeHtml(mime)}">${escapeHtml(mime)}</span>
                    <div class="flex-1 h-2 rounded-full bg-[#E5E5EA] dark:bg-[#2C2C2E] overflow-hidden">
                        <div class="h-full rounded-full bg-gradient-to-r from-[#6366F1] to-[#A855F7]" style="width:${pct}%"></div>
                    </div>
                    <span class="text-[13px] font-medium w-12 text-right">${count}</span>
                </div>`;
        }).join('');
    }
}

// ════════════════════════════════════════
// Explorer
// ════════════════════════════════════════

let selectedFileId = null;

async function loadExplorerTree(nodeId) {
    const container = document.getElementById('tree-container');
    if (!container) return;

    if (!nodeId) {
        container.innerHTML = '<div class="flex justify-center py-8"><div class="spinner"></div></div>';
        try {
            const data = await apiFetch('/api/tree');
            container.innerHTML = '';
            const ul = buildTreeNodes(data.tree);
            container.appendChild(ul);
        } catch {
            renderEmptyState(container, {
                icon: 'folder-search',
                title: 'No snapshot yet',
                description: 'Scan your Drive from the CLI first:',
                command: 'gdrive-organizer scan',
                hint: 'Then return here to explore the tree.',
            });
        }
    }
}

function buildTreeNodes(nodes) {
    if (!nodes || nodes.length === 0) return document.createDocumentFragment();
    const ul = document.createElement('ul');
    ul.className = 'tree-node';

    for (const node of nodes) {
        const li = document.createElement('li');
        const item = document.createElement('div');
        item.className = 'tree-item';
        item.dataset.id = node.id;

        if (node.isFolder) {
            const hasChildren = node.childCount > 0;
            item.innerHTML = `
                <span class="tree-arrow${hasChildren ? '' : ' invisible'}">${hasChildren ? '<i data-lucide="chevron-right" class="w-3.5 h-3.5"></i>' : ''}</span>
                <i data-lucide="folder" class="w-4 h-4 text-[#6366F1] flex-shrink-0"></i>
                <span class="truncate">${escapeHtml(node.name)}</span>
                <span class="tree-child-count">${node.childCount}</span>`;
            item.onclick = (e) => {
                e.stopPropagation();
                handleTreeToggle(li, node);
            };
        } else {
            item.innerHTML = `
                <span class="tree-arrow invisible"></span>
                <i data-lucide="file-text" class="w-4 h-4 text-[#86868B] flex-shrink-0"></i>
                <span class="truncate">${escapeHtml(node.name)}</span>`;
            item.onclick = () => showFileDetail(node);
        }

        li.appendChild(item);

        // Pre-loaded children
        if (node.isFolder && node.children && node.children.length > 0) {
            const childUl = buildTreeNodes(node.children);
            childUl.style.display = 'none';
            li.appendChild(childUl);
            li.dataset.loaded = 'true';
        } else {
            li.dataset.loaded = 'false';
        }

        ul.appendChild(li);
    }

    // Reinitialize lucide icons for new elements
    setTimeout(() => lucide.createIcons(), 0);
    return ul;
}

async function handleTreeToggle(li, node) {
    let childUl = li.querySelector(':scope > ul');
    const arrow = li.querySelector('.tree-arrow');

    if (childUl && childUl.style.display !== 'none') {
        childUl.style.display = 'none';
        arrow?.classList.remove('open');
        return;
    }

    if (childUl) {
        childUl.style.display = '';
        arrow?.classList.add('open');
        return;
    }

    // Lazy load
    arrow?.classList.add('open');
    try {
        const data = await apiFetch(`/api/tree?node_id=${encodeURIComponent(node.id)}`);
        childUl = buildTreeNodes(data.children);
        li.appendChild(childUl);
        li.dataset.loaded = 'true';
    } catch {
        arrow?.classList.remove('open');
    }
}

async function showFileDetail(node) {
    const content = document.getElementById('detail-content');
    const closeBtn = document.getElementById('detail-close-btn');
    if (!content) return;

    // Mark selected
    document.querySelectorAll('.tree-item.selected').forEach(el => el.classList.remove('selected'));
    const item = document.querySelector(`.tree-item[data-id="${node.id}"]`);
    if (item) item.classList.add('selected');

    selectedFileId = node.id;
    if (closeBtn) closeBtn.classList.remove('hidden');
    content.innerHTML = '<div class="flex justify-center py-12"><div class="spinner"></div></div>';

    try {
        const f = await apiFetch(`/api/file/${encodeURIComponent(node.id)}`);
        if (f.error) throw new Error(f.error);

        const rows = [
            ['Name', f.name],
            ['Path', f.path || node.path],
            ['Type', f.mime_type],
            ['Size', formatSize(f.size)],
        ];
        if (f.owned_by_me !== null && f.owned_by_me !== undefined) rows.push(['Owned', f.owned_by_me ? 'Yes' : 'No']);
        if (f.starred) rows.push(['Starred', 'Yes']);
        if (f.description) rows.push(['Desc', f.description]);
        if (f.file_extension) rows.push(['Ext', f.file_extension]);
        if (f.original_filename) rows.push(['Original', f.original_filename]);
        if (f.last_modifying_user) rows.push(['Editor', f.last_modifying_user]);
        if (f.owners?.length) rows.push(['Owner', f.owners.join(', ')]);
        if (f.created_time) rows.push(['Created', formatDate(f.created_time)]);
        if (f.modified_time) rows.push(['Modified', formatDate(f.modified_time)]);

        let linkHtml = '';
        if (f.web_view_link) {
            linkHtml = `<a href="${escapeHtml(f.web_view_link)}" target="_blank" rel="noopener"
                class="inline-flex items-center gap-1.5 text-[#6366F1] hover:underline text-[13px] mt-5 font-medium">
                <i data-lucide="external-link" class="w-3.5 h-3.5"></i> Open in Drive
            </a>`;
        }

        let idHtml = '';
        if (f.id) {
            idHtml = `<div class="mt-4 pt-4 border-t border-[#E5E5EA] dark:border-[#38383A]">
                <span class="text-[11px] text-[#A1A1A6] break-all font-mono">${escapeHtml(f.id)}</span>
            </div>`;
        }

        let md5Html = '';
        if (f.md5_checksum) {
            md5Html = `<div class="mt-2">
                <span class="text-[11px] text-[#A1A1A6] font-mono">MD5: ${escapeHtml(f.md5_checksum)}</span>
            </div>`;
        }

        content.innerHTML = `
            <h3 class="text-[15px] font-bold mb-5 break-words">${escapeHtml(f.name)}</h3>
            <div class="space-y-2.5">
                ${rows.map(([label, value]) => `
                    <div class="flex gap-2">
                        <span class="w-20 text-[12px] font-medium text-[#86868B] flex-shrink-0 pt-px">${label}</span>
                        <span class="text-[12px] min-w-0 break-words">${typeof value === 'string' && !value.includes('<') ? escapeHtml(value) : value}</span>
                    </div>
                `).join('')}
            </div>
            ${linkHtml}
            ${idHtml}
            ${md5Html}`;
        lucide.createIcons();
    } catch {
        content.innerHTML = '<p class="text-[#86868B] text-center py-8">Failed to load details.</p>';
    }
}

function closeDetailPanel() {
    const content = document.getElementById('detail-content');
    const closeBtn = document.getElementById('detail-close-btn');
    if (content) {
        content.innerHTML = `
            <div class="flex flex-col items-center justify-center h-full text-center">
                <i data-lucide="mouse-pointer-click" class="w-10 h-10 text-[#C7C7CC] dark:text-[#545456] mb-3"></i>
                <p class="text-[14px] text-[#86868B]">Select a file to view details</p>
            </div>`;
        lucide.createIcons();
    }
    if (closeBtn) closeBtn.classList.add('hidden');
    selectedFileId = null;
    document.querySelectorAll('.tree-item.selected').forEach(el => el.classList.remove('selected'));
}

async function explorerSearch() {
    const query = document.getElementById('explorer-search')?.value;
    const container = document.getElementById('tree-container');
    if (!container) return;

    if (!query) {
        loadExplorerTree();
        return;
    }

    container.innerHTML = '<div class="flex justify-center py-8"><div class="spinner"></div></div>';
    try {
        const data = await apiFetch(`/api/files?q=${encodeURIComponent(query)}`);
        if (data.files.length === 0) {
            renderEmptyState(container, {
                icon: 'search-x',
                title: 'No matching files',
                description: 'Try a different query.',
            });
            return;
        }

        const ul = document.createElement('ul');
        ul.className = 'tree-node';
        for (const f of data.files) {
            const li = document.createElement('li');
            const item = document.createElement('div');
            item.className = 'tree-item';
            item.dataset.id = f.id;
            item.innerHTML = `
                <span class="tree-arrow invisible"></span>
                <i data-lucide="file-text" class="w-4 h-4 text-[#86868B] flex-shrink-0"></i>
                <span class="truncate">${escapeHtml(f.name)}</span>
                <span class="tree-child-count">${formatSize(f.size)}</span>`;
            item.onclick = () => showFileDetail({ id: f.id, name: f.name, path: f.path, mimeType: f.mime_type });
            li.appendChild(item);
            ul.appendChild(li);
        }
        container.innerHTML = '';
        container.appendChild(ul);
        lucide.createIcons();
    } catch {
        renderEmptyState(container, {
            icon: 'alert-circle',
            title: 'Search failed',
            description: 'Check that a snapshot exists, then try again.',
            command: 'gdrive-organizer scan',
            tone: 'error',
        });
    }
}

// ════════════════════════════════════════
// Plan (AI Classify)
// ════════════════════════════════════════

let currentPlanOps = [];
let currentPlanMeta = null;
let selectedPlanOperationIds = new Set();

// Common prefix/suffix diff: returns {prefix, middle, suffix} for one side.
// side: 'before' uses `a`, 'after' uses `b`. Common parts are identical on both.
function _diffParts(a, b) {
    a = a || '';
    b = b || '';
    let p = 0;
    const minLen = Math.min(a.length, b.length);
    while (p < minLen && a[p] === b[p]) p++;
    let s = 0;
    while (
        s < a.length - p &&
        s < b.length - p &&
        a[a.length - 1 - s] === b[b.length - 1 - s]
    ) s++;
    return {
        prefix: a.slice(0, p),
        middleA: a.slice(p, a.length - s),
        middleB: b.slice(p, b.length - s),
        suffix: s > 0 ? a.slice(a.length - s) : '',
    };
}

// Render a diff-highlighted span for one side. side='before' dims common+strikes middle.
// side='after' dims common + highlights (bold/green) middle.
function renderDiff(before, after, side) {
    if (!before && !after) return '';
    if (before === after) return escapeHtml(before);
    const { prefix, middleA, middleB, suffix } = _diffParts(before, after);
    const middle = side === 'before' ? middleA : middleB;
    const middleClass = side === 'before'
        ? 'text-red-600 dark:text-red-400 line-through decoration-2'
        : 'text-green-700 dark:text-green-400 font-semibold';
    const dim = 'text-[#86868B]';
    const parts = [];
    if (prefix) parts.push(`<span class="${dim}">${escapeHtml(prefix)}</span>`);
    if (middle) parts.push(`<span class="${middleClass}">${escapeHtml(middle)}</span>`);
    if (suffix) parts.push(`<span class="${dim}">${escapeHtml(suffix)}</span>`);
    return parts.join('') || escapeHtml(side === 'before' ? before : after);
}

async function loadPlan() {
    const container = document.getElementById('plan-container');
    const summary = document.getElementById('plan-summary');
    if (!container) return;

    container.innerHTML = '<div class="flex justify-center py-12"><div class="spinner"></div></div>';

    try {
        const data = await apiFetch('/api/plan');
        currentPlanMeta = data;
        if (!data.plan || !data.plan.operations || data.plan.operations.length === 0) {
            currentPlanOps = [];
            selectedPlanOperationIds = new Set();
            renderEmptyState(container, {
                icon: 'clipboard-list',
                title: 'No plan to review',
                description: 'Generate a plan from the CLI first:',
                command: 'gdrive-organizer classify',
                hint: 'Then return here to review and approve the plan.',
            });
            return;
        }
        currentPlanOps = data.plan.operations;
        selectedPlanOperationIds = new Set(currentPlanOps.map(op => op.viewer_operation_id));
        renderPlanOps(currentPlanOps, container);
        updatePlanSummary(currentPlanOps, summary, data);
        renderApprovedBanner(data);
        updateBulkActionVisibility(currentPlanOps);
        loadLastApplied();
    } catch {
        renderEmptyState(container, {
            icon: 'alert-circle',
            title: 'Failed to load plan',
            description: 'The plan file may be missing or corrupted. Try regenerating it:',
            command: 'gdrive-organizer classify',
            tone: 'error',
        });
    }
}

function renderPlanOps(ops, container) {
    const filter = document.getElementById('plan-filter')?.value || 'all';
    const queryRaw = (document.getElementById('plan-search')?.value || '').trim().toLowerCase();
    const filtered = ops.filter(o => {
        if (filter !== 'all' && o.operation !== filter) return false;
        if (!queryRaw) return true;
        const haystack = [
            o.current_name, o.current_path,
            o.new_name, o.new_path,
            o.proposed_name, o.proposed_path,
        ].filter(Boolean).join(' ').toLowerCase();
        return haystack.includes(queryRaw);
    });

    if (filtered.length === 0) {
        renderEmptyState(container, {
            icon: 'filter-x',
            title: 'No operations match this filter',
            description: 'Try a different operation type.',
        });
        return;
    }

    container.innerHTML = filtered.map((op, i) => {
        // create_folder is purely additive — there is no "before" state for
        // a folder that doesn't exist yet. Showing two identical cards is
        // noise; collapse to a single "NEW" card.
        const isAdditive = op.operation === 'create_folder';
        const newPath = op.new_path || op.current_path;
        const newName = op.new_name || op.current_name;
        const cards = isAdditive ? `
            <div class="rounded-xl p-3 bg-green-50 dark:bg-green-500/10">
                <p class="text-[11px] font-semibold text-[#86868B] mb-1">NEW</p>
                <p class="text-[13px] font-medium break-words">${escapeHtml(newName)}</p>
                <p class="text-[12px] truncate" title="${escapeHtml(newPath)}">${escapeHtml(newPath)}</p>
            </div>
        ` : `
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div class="rounded-xl p-3 bg-red-50 dark:bg-red-500/10">
                    <p class="text-[11px] font-semibold text-[#86868B] mb-1">BEFORE</p>
                    <p class="text-[13px] font-medium break-words">${renderDiff(op.current_name, newName, 'before')}</p>
                    <p class="text-[12px] truncate" title="${escapeHtml(op.current_path)}">${renderDiff(op.current_path, newPath, 'before')}</p>
                </div>
                <div class="rounded-xl p-3 bg-green-50 dark:bg-green-500/10">
                    <p class="text-[11px] font-semibold text-[#86868B] mb-1">AFTER</p>
                    <p class="text-[13px] font-medium break-words">${renderDiff(op.current_name, newName, 'after')}</p>
                    <p class="text-[12px] truncate" title="${escapeHtml(newPath)}">${renderDiff(op.current_path, newPath, 'after')}</p>
                </div>
            </div>
        `;
        return `
            <div class="glass-card p-5 flex gap-4 items-start">
                <input
                    type="checkbox"
                    class="plan-check mt-1 w-4 h-4 rounded accent-[#6366F1]"
                    data-file-id="${escapeHtml(op.file_id)}"
                    data-op-id="${escapeHtml(op.viewer_operation_id || '')}"
                    ${selectedPlanOperationIds.has(op.viewer_operation_id) ? 'checked' : ''}
                >
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 mb-3">
                        <span class="op-badge op-${op.operation}">${op.operation.replace(/_/g, ' ')}</span>
                        <span class="text-[13px] text-[#86868B]">#${i + 1}</span>
                    </div>
                    ${cards}
                    ${op.reason ? `<p class="text-[12px] text-[#86868B] mt-2">${escapeHtml(op.reason)}</p>` : ''}
                </div>
            </div>
        `;
    }).join('');

    container.querySelectorAll('.plan-check').forEach(cb => {
        cb.addEventListener('change', () => {
            const opId = cb.dataset.opId;
            if (!opId) return;
            if (cb.checked) selectedPlanOperationIds.add(opId);
            else selectedPlanOperationIds.delete(opId);
            updatePlanSummary(currentPlanOps, document.getElementById('plan-summary'), currentPlanMeta);
        });
    });
}

function updatePlanSummary(ops, el, meta = null) {
    if (!el) return;
    const counts = {};
    for (const op of ops) {
        counts[op.operation] = (counts[op.operation] || 0) + 1;
    }
    const parts = Object.entries(counts).map(([k, v]) => `${v} ${k.replace(/_/g, ' ')}`);
    const selectedCount = ops.filter(op => selectedPlanOperationIds.has(op.viewer_operation_id)).length;
    const base = `${ops.length} operations — ${parts.join(', ')} | ${selectedCount} selected`;
    if (meta?.approved_plan_present) {
        el.textContent = `${base} | Reviewing latest full plan. CLI default: approved selection (${meta.approved_operation_count} ops).`;
        return;
    }
    el.textContent = `${base} | CLI default: latest full plan.`;
}

function planApproveAll() {
    document.querySelectorAll('.plan-check').forEach(cb => {
        cb.checked = true;
        if (cb.dataset.opId) selectedPlanOperationIds.add(cb.dataset.opId);
    });
    updatePlanSummary(currentPlanOps, document.getElementById('plan-summary'), currentPlanMeta);
}

function planRejectAll() {
    document.querySelectorAll('.plan-check').forEach(cb => {
        cb.checked = false;
        if (cb.dataset.opId) selectedPlanOperationIds.delete(cb.dataset.opId);
    });
    updatePlanSummary(currentPlanOps, document.getElementById('plan-summary'), currentPlanMeta);
}

// Bulk: select every op that is not TRASH (applies to the full plan, not just visible).
function planSelectSafeOnly() {
    selectedPlanOperationIds = new Set(
        currentPlanOps
            .filter(op => op.operation !== 'trash')
            .map(op => op.viewer_operation_id)
    );
    const container = document.getElementById('plan-container');
    if (container) renderPlanOps(currentPlanOps, container);
    updatePlanSummary(currentPlanOps, document.getElementById('plan-summary'), currentPlanMeta);
    const trashCount = currentPlanOps.filter(op => op.operation === 'trash').length;
    if (trashCount > 0) {
        showToast(`Excluded ${trashCount} TRASH op${trashCount === 1 ? '' : 's'} from selection.`, 'info');
    }
}

// Bulk: remove every TRASH op from the current selection (keeps other selections intact).
function planDeselectAllTrash() {
    let removed = 0;
    for (const op of currentPlanOps) {
        if (op.operation === 'trash' && selectedPlanOperationIds.has(op.viewer_operation_id)) {
            selectedPlanOperationIds.delete(op.viewer_operation_id);
            removed += 1;
        }
    }
    const container = document.getElementById('plan-container');
    if (container) renderPlanOps(currentPlanOps, container);
    updatePlanSummary(currentPlanOps, document.getElementById('plan-summary'), currentPlanMeta);
    if (removed > 0) {
        showToast(`Removed ${removed} TRASH op${removed === 1 ? '' : 's'} from selection.`, 'success');
    }
}

// Show/hide the trash-related bulk button based on the current plan.
function updateBulkActionVisibility(ops) {
    const trashCount = ops.filter(op => op.operation === 'trash').length;
    const btn = document.getElementById('bulk-deselect-trash');
    const countEl = document.getElementById('bulk-trash-count');
    if (!btn) return;
    if (trashCount > 0) {
        btn.classList.remove('hidden');
        if (countEl) countEl.textContent = String(trashCount);
    } else {
        btn.classList.add('hidden');
    }
}

let _pendingApprovalIds = [];

async function planApply() {
    const operationIds = Array.from(selectedPlanOperationIds);
    if (operationIds.length === 0) {
        showToast('No operations selected.', 'error');
        return;
    }
    // Step 1: Request confirmation summary from server (without confirmed=true)
    try {
        const data = await apiFetch('/api/plan/approve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ approved_operation_ids: operationIds, confirmed: false }),
        });
        if (data.status === 'confirmation_required') {
            _pendingApprovalIds = operationIds;
            showConfirmModal(data);
        } else if (data.status === 'approved') {
            showToast(`Approved ${data.operations} operations.`, 'success');
        }
    } catch {
        showToast('Failed to approve plan.', 'error');
    }
}

function showConfirmModal(data) {
    const modal = document.getElementById('confirm-modal');
    const summary = document.getElementById('confirm-summary');
    const trashWarning = document.getElementById('confirm-trash-warning');
    const confirmInput = document.getElementById('confirm-input');

    if (!modal || !summary) return;

    let html = `<p class="font-medium">${data.operations} operations selected:</p><ul class="ml-4 mt-1 space-y-1">`;
    for (const [op, count] of Object.entries(data.summary || {})) {
        const isTrash = op === 'trash';
        html += `<li class="${isTrash ? 'text-red-500 font-semibold' : ''}">${count} ${op.replace(/_/g, ' ')}</li>`;
    }
    html += '</ul>';
    summary.innerHTML = html;

    if (data.trash_count > 0) {
        trashWarning.classList.remove('hidden');
        if (confirmInput) confirmInput.value = '';
    } else {
        trashWarning.classList.add('hidden');
    }

    modal.classList.remove('hidden');
    modal.classList.add('flex');
    lucide.createIcons();
}

function closeConfirmModal() {
    const modal = document.getElementById('confirm-modal');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
    _pendingApprovalIds = [];
}

async function confirmPlanApply() {
    const trashWarning = document.getElementById('confirm-trash-warning');
    const confirmInput = document.getElementById('confirm-input');
    let trashConfirmed = false;

    // If trash ops present, require typed confirmation
    if (trashWarning && !trashWarning.classList.contains('hidden')) {
        if (!confirmInput || confirmInput.value.trim().toLowerCase() !== 'apply') {
            showToast('Type "apply" to confirm destructive operations.', 'error');
            return;
        }
        trashConfirmed = true;
    }

    try {
        const data = await apiFetch('/api/plan/approve', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                approved_operation_ids: _pendingApprovalIds,
                confirmed: true,
                trash_confirmed: trashConfirmed,
            }),
        });
        if (data.status === 'approved') {
            showToast(data.message || `Approved ${data.operations} operations.`, 'success');
            // Show next-step guidance inline
            const container = document.getElementById('plan-container');
            if (container) {
                container.innerHTML = `
                    <div class="glass-card p-8 text-center">
                        <i data-lucide="check-circle" class="w-12 h-12 text-green-500 mx-auto mb-4"></i>
                        <p class="text-[16px] font-bold mb-2">${data.operations} operations approved</p>
                        <p class="text-[14px] text-[#86868B] mb-4">Run the following command to execute the approved selection:</p>
                        <code class="px-4 py-2 rounded-lg bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[13px] font-mono">gdrive-organizer plan apply</code>
                        <p class="text-[12px] text-[#86868B] mt-4">Add <code class="text-[11px]">--dry-run</code> to preview without executing. Use <code class="text-[11px]">--latest-plan</code> to force the full plan, or <code class="text-[11px]">gdrive-organizer plan rollback</code> to undo.</p>
                    </div>`;
                lucide.createIcons();
            }
        } else if (data.status === 'trash_confirmation_required') {
            showToast('Trash operations require typed confirmation. Please try again.', 'error');
        } else {
            showToast(data.error || 'Approval failed.', 'error');
        }
    } catch {
        showToast('Failed to approve plan.', 'error');
    } finally {
        closeConfirmModal();
    }
}

function filterPlan() {
    const container = document.getElementById('plan-container');
    if (container && currentPlanOps.length > 0) {
        renderPlanOps(currentPlanOps, container);
        updatePlanSummary(currentPlanOps, document.getElementById('plan-summary'), currentPlanMeta);
    }
}

// ────────────────────────────────────────
// Approved plan banner
// ────────────────────────────────────────

function renderApprovedBanner(meta) {
    const el = document.getElementById('approved-banner');
    if (!el) return;
    if (!meta?.approved_plan_present) {
        el.classList.add('hidden');
        el.innerHTML = '';
        return;
    }
    const count = meta.approved_operation_count ?? 0;
    el.classList.remove('hidden');
    el.innerHTML = `
        <div class="glass-card p-4 flex items-start gap-3 border-l-4 border-indigo-500">
            <i data-lucide="check-circle-2" class="w-5 h-5 text-indigo-500 shrink-0 mt-0.5"></i>
            <div class="flex-1 min-w-0">
                <p class="text-[13px] font-semibold mb-1">
                    ${count} operation${count === 1 ? '' : 's'} currently approved
                </p>
                <p class="text-[12px] text-[#86868B]">
                    <code class="px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[11px] font-mono">gdrive-organizer plan apply</code>
                    will execute this approved subset. Regenerate with
                    <code class="px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[11px] font-mono">classify</code>
                    or use
                    <code class="px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[11px] font-mono">--latest-plan</code>
                    to bypass.
                </p>
            </div>
            <button onclick="clearApprovedPlan()"
                class="shrink-0 px-3 py-1.5 rounded-lg text-[12px] font-semibold
                    bg-[#F5F5F7] hover:bg-[#E5E5EA] text-[#1D1D1F]
                    dark:bg-[#2C2C2E] dark:hover:bg-[#38383A] dark:text-[#F5F5F7]">
                Clear approval
            </button>
        </div>`;
    if (window.lucide) lucide.createIcons();
}

async function clearApprovedPlan() {
    if (!confirm('Clear the approved subset? The CLI will fall back to the latest full plan.')) return;
    try {
        await apiFetch('/api/plan/approve', { method: 'DELETE' });
        showToast('Approved subset cleared.', 'success');
        loadPlan();
    } catch {
        showToast('Failed to clear approval.', 'error');
    }
}

// ────────────────────────────────────────
// Last Applied / Rollback surface (CLI-first)
// ────────────────────────────────────────

async function loadLastApplied() {
    const el = document.getElementById('last-applied-panel');
    if (!el) return;
    try {
        const data = await apiFetch('/api/last-applied');
        if (!data || !data.present) {
            el.classList.add('hidden');
            el.innerHTML = '';
            return;
        }
        el.classList.remove('hidden');
        _renderLastAppliedPanel(el, data, /*expanded*/ false, /*details*/ null);
    } catch {
        el.classList.add('hidden');
    }
}

function _renderLastAppliedPanel(el, data, expanded, details) {
    const when = data.executed_at ? formatDate(data.executed_at) : '—';
    const count = data.operation_count ?? 0;
    const summary = data.summary || { ok: 0, failed: 0, other: 0 };
    const okBadge = summary.ok > 0
        ? `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-100 dark:bg-green-500/20 text-green-700 dark:text-green-400 text-[11px] font-semibold"><i data-lucide="check" class="w-3 h-3"></i>${summary.ok} ok</span>`
        : '';
    const failedBadge = summary.failed > 0
        ? `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-100 dark:bg-red-500/20 text-red-700 dark:text-red-400 text-[11px] font-semibold"><i data-lucide="x" class="w-3 h-3"></i>${summary.failed} failed</span>`
        : '';
    const otherBadge = summary.other > 0
        ? `<span class="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[#86868B] text-[11px] font-semibold">${summary.other} other</span>`
        : '';
    const detailsBody = expanded ? _renderLastAppliedDetails(details) : '';
    const toggleLabel = expanded ? 'Hide details' : 'Show details';
    const toggleIcon = expanded ? 'chevron-up' : 'chevron-down';
    el.innerHTML = `
        <div class="glass-card p-4 border-l-4 border-amber-500">
            <div class="flex items-start gap-3">
                <i data-lucide="history" class="w-5 h-5 text-amber-500 shrink-0 mt-0.5"></i>
                <div class="flex-1 min-w-0">
                    <div class="flex items-center gap-2 flex-wrap mb-1">
                        <p class="text-[13px] font-semibold">
                            Last applied: ${count} operation${count === 1 ? '' : 's'} on ${escapeHtml(when)}
                        </p>
                        ${okBadge} ${failedBadge} ${otherBadge}
                    </div>
                    <p class="text-[12px] text-[#86868B]">
                        To undo, run in terminal:
                        <code class="ml-1 px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[11px] font-mono select-all">gdrive-organizer plan rollback</code>
                    </p>
                </div>
                <button onclick="toggleLastAppliedDetails()"
                    class="shrink-0 px-2.5 py-1 rounded-lg text-[12px] font-semibold inline-flex items-center gap-1
                        bg-[#F5F5F7] hover:bg-[#E5E5EA] text-[#1D1D1F]
                        dark:bg-[#2C2C2E] dark:hover:bg-[#38383A] dark:text-[#F5F5F7]">
                    <i data-lucide="${toggleIcon}" class="w-3.5 h-3.5"></i>
                    ${toggleLabel}
                </button>
            </div>
            ${detailsBody}
        </div>`;
    if (window.lucide) lucide.createIcons();
}

function _renderLastAppliedDetails(details) {
    const ops = (details && details.operations) || [];
    if (ops.length === 0) {
        return `<p class="text-[12px] text-[#86868B] mt-3 ml-8">No per-op details available.</p>`;
    }
    const rows = ops.map(op => {
        const status = (op.status || '').toLowerCase();
        const dot = status === 'ok' || status === 'success'
            ? '<span class="inline-block w-2 h-2 rounded-full bg-green-500"></span>'
            : (status === 'failed' || status === 'error')
                ? '<span class="inline-block w-2 h-2 rounded-full bg-red-500"></span>'
                : '<span class="inline-block w-2 h-2 rounded-full bg-[#C7C7CC]"></span>';
        return `
            <li class="flex items-center gap-2 py-1 text-[12px]">
                ${dot}
                <span class="px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[10px] font-mono uppercase">${escapeHtml(op.type || '')}</span>
                <span class="truncate flex-1" title="${escapeHtml(op.name || '')}">${escapeHtml(op.name || op.file_id || '')}</span>
                <span class="text-[#86868B] text-[11px]">${escapeHtml(op.status || '')}</span>
            </li>`;
    }).join('');
    return `
        <ul class="mt-3 ml-8 divide-y divide-[#E5E5EA] dark:divide-[#38383A]">
            ${rows}
        </ul>`;
}

let _lastAppliedExpanded = false;
let _lastAppliedDetailsCache = null;

async function toggleLastAppliedDetails() {
    const el = document.getElementById('last-applied-panel');
    if (!el) return;
    _lastAppliedExpanded = !_lastAppliedExpanded;
    if (_lastAppliedExpanded && !_lastAppliedDetailsCache) {
        try {
            _lastAppliedDetailsCache = await apiFetch('/api/last-applied?details=true');
        } catch {
            _lastAppliedDetailsCache = { present: true, operations: [] };
        }
    }
    // Re-fetch summary-only for freshness, but reuse cache for details
    try {
        const summaryData = await apiFetch('/api/last-applied');
        _renderLastAppliedPanel(el, summaryData, _lastAppliedExpanded, _lastAppliedDetailsCache);
    } catch {
        // keep panel as-is on failure
    }
}

// ════════════════════════════════════════
// Permissions
// ════════════════════════════════════════

async function loadPermissions() {
    const container = document.getElementById('permissions-container');
    if (!container) return;

    container.innerHTML = '<div class="flex justify-center py-12"><div class="spinner"></div></div>';

    try {
        const data = await apiFetch('/api/permissions');
        renderPermissions(data, container);
    } catch {
        renderEmptyState(container, {
            icon: 'shield-alert',
            title: 'Failed to load permissions',
            description: 'Scan your Drive first:',
            command: 'gdrive-organizer scan',
            tone: 'error',
        });
    }
}

function renderPermissions(data, container) {
    const categories = [
        { key: 'public', label: 'Public', icon: 'globe', color: 'perm-public', desc: 'Accessible to anyone on the internet' },
        { key: 'domain', label: 'Domain', icon: 'building', color: 'perm-domain', desc: 'Shared with your organization' },
        { key: 'specific_users', label: 'Specific Users', icon: 'users', color: 'perm-specific', desc: 'Shared with individual people' },
        { key: 'not_shared', label: 'Private', icon: 'lock', color: 'perm-private', desc: 'Only you have access' },
    ];

    const total = categories.reduce((sum, c) => sum + (data[c.key] || 0), 0) || 1;

    container.innerHTML = `
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
            ${categories.map(c => {
                const count = data[c.key] || 0;
                const pct = ((count / total) * 100).toFixed(1);
                return `
                    <div class="glass-card p-6">
                        <div class="flex items-center justify-between mb-3">
                            <span class="text-[13px] font-semibold uppercase text-[#86868B]">${c.label}</span>
                            <i data-lucide="${c.icon}" class="w-[18px] h-[18px] ${c.color}"></i>
                        </div>
                        <p class="text-[28px] font-bold mb-1">${count.toLocaleString()}</p>
                        <p class="text-[13px] text-[#86868B]">${pct}% of total</p>
                    </div>`;
            }).join('')}
        </div>
        ${data.details?.public_files?.length ? `
            <div class="glass-card p-6">
                <h3 class="text-[16px] font-bold mb-4 flex items-center gap-2">
                    <i data-lucide="alert-triangle" class="w-5 h-5 text-red-500"></i>
                    Public Files (${data.details.public_files.length})
                </h3>
                <div class="space-y-2 max-h-[400px] overflow-y-auto custom-scrollbar">
                    ${data.details.public_files.map(f => `
                        <div class="flex items-center gap-3 p-3 rounded-xl hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                            <i data-lucide="file-warning" class="w-4 h-4 text-red-400 flex-shrink-0"></i>
                            <div class="min-w-0">
                                <p class="text-[13px] font-medium truncate">${escapeHtml(f.name)}</p>
                                <p class="text-[12px] text-[#86868B] truncate">${escapeHtml(f.id)}</p>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        ` : ''}`;

    lucide.createIcons();
}

// ════════════════════════════════════════
// Duplicates
// ════════════════════════════════════════

async function loadDuplicates() {
    const container = document.getElementById('duplicates-container');
    if (!container) return;

    container.innerHTML = '<div class="flex justify-center py-12"><div class="spinner"></div></div>';

    try {
        const data = await apiFetch('/api/duplicates');
        renderDuplicates(data, container);
    } catch {
        renderEmptyState(container, {
            icon: 'copy',
            title: 'Failed to load duplicates',
            description: 'Scan your Drive first:',
            command: 'gdrive-organizer scan',
            tone: 'error',
        });
    }
}

function renderDuplicates(data, container) {
    const groups = data.duplicates || {};
    const groupEntries = Object.entries(groups);

    if (groupEntries.length === 0) {
        container.innerHTML = `
            <!-- handled below -->`;
        renderEmptyState(container, {
            icon: 'check-circle',
            title: 'No duplicates found',
            description: 'Your Drive is clean.',
            tone: 'success',
        });
        return;
    }

    // Calculate total wasted
    let totalWasted = 0;
    for (const files of Object.values(groups)) {
        for (let i = 1; i < files.length; i++) totalWasted += files[i].size || 0;
    }

    container.innerHTML = `
        <div class="glass-card p-6 mb-6">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-[13px] font-semibold uppercase text-[#86868B]">Summary</p>
                    <p class="text-[24px] font-bold mt-1">${groupEntries.length} duplicate groups</p>
                </div>
                <div class="text-right">
                    <p class="text-[13px] font-semibold uppercase text-[#86868B]">Wasted Space</p>
                    <p class="text-[24px] font-bold mt-1 text-orange-500">${formatSize(totalWasted)}</p>
                </div>
            </div>
        </div>
        <div class="space-y-4">
            ${groupEntries.slice(0, 50).map(([md5, files], idx) => `
                <div class="glass-card p-5">
                    <div class="flex items-center gap-2 mb-3">
                        <i data-lucide="copy" class="w-4 h-4 text-orange-500"></i>
                        <span class="text-[13px] font-semibold">Group #${idx + 1}</span>
                        <span class="text-[12px] text-[#86868B]">${files.length} copies</span>
                        <span class="text-[11px] text-[#86868B] ml-auto font-mono">${md5.slice(0, 12)}...</span>
                    </div>
                    <div class="space-y-2">
                        ${files.map((f, fi) => `
                            <div class="flex items-center gap-3 p-2.5 rounded-xl ${fi === 0 ? 'bg-green-50 dark:bg-green-500/10' : 'bg-black/[0.02] dark:bg-white/[0.02]'}">
                                ${fi === 0 ? '<i data-lucide="star" class="w-3.5 h-3.5 text-green-500 flex-shrink-0"></i>' : '<i data-lucide="file" class="w-3.5 h-3.5 text-[#86868B] flex-shrink-0"></i>'}
                                <div class="min-w-0 flex-1">
                                    <p class="text-[13px] font-medium truncate">${escapeHtml(f.name)}</p>
                                    <p class="text-[12px] text-[#86868B] truncate">${escapeHtml(f.path || '')}</p>
                                </div>
                                <span class="text-[12px] text-[#86868B] flex-shrink-0">${formatSize(f.size)}</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            `).join('')}
            ${groupEntries.length > 50 ? `<p class="text-center text-[13px] text-[#86868B]">...and ${groupEntries.length - 50} more groups</p>` : ''}
        </div>`;

    lucide.createIcons();
}

// ════════════════════════════════════════
// Settings
// ════════════════════════════════════════

async function loadSettings() {
    const container = document.getElementById('settings-container');
    if (!container) return;

    try {
        const [configData, authData, apikeyData] = await Promise.all([
            apiFetch('/api/config'),
            apiFetch('/api/auth/status'),
            apiFetch('/api/apikey/status'),
        ]);
        renderSettings(configData, authData, apikeyData, container);
    } catch {
        renderEmptyState(container, {
            icon: 'alert-circle',
            title: 'Failed to load settings',
            description: 'Please reload the page. If the issue persists, check the CLI config:',
            command: 'gdrive-organizer config show',
            tone: 'error',
        });
    }
}

function renderSettings(configData, authData, apikeyData, container) {
    const config = configData.config || {};
    const auth = authData || {};
    const apikey = apikeyData || {};
    const authLabel = auth.authenticated ? 'Connected' : (auth.expired ? 'Expired' : 'Not Connected');
    const authClass = auth.authenticated ? 'text-green-500' : (auth.expired ? 'text-orange-500' : 'text-red-500');

    container.innerHTML = `
        <!-- Auth Status -->
        <div class="glass-card p-6 mb-6">
            <h3 class="text-[16px] font-bold mb-4 flex items-center gap-2">
                <i data-lucide="key" class="w-5 h-5 text-[#6366F1]"></i>
                Google OAuth
            </h3>
            <div class="space-y-3">
                <div class="flex items-center justify-between">
                    <span class="text-[13px] text-[#86868B]">Status</span>
                    <span class="text-[13px] font-medium ${authClass}">
                        ${authLabel}
                    </span>
                </div>
                ${auth.email ? `
                    <div class="flex items-center justify-between">
                        <span class="text-[13px] text-[#86868B]">Account</span>
                        <span class="text-[13px] font-medium">${escapeHtml(auth.email)}</span>
                    </div>` : ''}
                ${auth.token_expiry ? `
                    <div class="flex items-center justify-between">
                        <span class="text-[13px] text-[#86868B]">Token Expires</span>
                        <span class="text-[13px] font-medium">${formatDate(auth.token_expiry)}</span>
                    </div>` : ''}
                ${auth.expired ? `
                    <p class="text-[12px] text-orange-500 mt-2">Stored token is expired. Click <strong>Reconnect</strong> to refresh, or run <code class="px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[11px] font-mono">gdrive-organizer auth login</code>.</p>` : ''}
                ${!auth.authenticated && !auth.expired ? `
                    <p class="text-[12px] text-[#A1A1A6] mt-2">Click <strong>Connect</strong> to start the OAuth flow, or run <code class="px-1.5 py-0.5 rounded bg-[#F5F5F7] dark:bg-[#2C2C2E] text-[11px] font-mono">gdrive-organizer auth login</code>.</p>` : ''}
                ${!auth.authenticated ? `
                    <div class="flex justify-end pt-2">
                        <button id="oauth-connect-btn" onclick="connectAuth()" class="px-4 py-2 rounded-lg bg-[#6366F1] hover:bg-[#4F46E5] text-white text-[13px] font-medium transition-colors disabled:opacity-60 disabled:cursor-not-allowed">
                            ${auth.expired ? 'Reconnect' : 'Connect'}
                        </button>
                    </div>` : ''}
            </div>
        </div>

        <!-- xAI API Key -->
        <div class="glass-card p-6 mb-6">
            <h3 class="text-[16px] font-bold mb-4 flex items-center gap-2">
                <i data-lucide="sparkles" class="w-5 h-5 text-[#D946EF]"></i>
                xAI API Key
            </h3>
            <div class="space-y-4">
                <div class="flex items-center justify-between">
                    <span class="text-[13px] text-[#86868B]">Status</span>
                    <span class="text-[13px] font-medium ${apikey.registered ? 'text-green-500' : 'text-red-500'}">
                        ${apikey.registered ? 'Registered' : 'Not Set'}
                    </span>
                </div>
                ${apikey.masked_key ? `
                    <div class="flex items-center justify-between">
                        <span class="text-[13px] text-[#86868B]">Key</span>
                        <span class="text-[12px] font-mono text-[#86868B]">${escapeHtml(apikey.masked_key)}</span>
                    </div>` : ''}

                <!-- Input form -->
                <div class="pt-2 border-t border-[#E5E5EA] dark:border-[#38383A]">
                    <label class="text-[12px] font-medium text-[#86868B] block mb-2">
                        ${apikey.registered ? 'Update API Key' : 'Enter API Key'}
                    </label>
                    <div class="flex gap-2">
                        <input
                            type="password"
                            id="apikey-input"
                            placeholder="xai-..."
                            class="flex-1 px-3 py-2 rounded-xl border text-[13px] outline-none transition-colors
                                bg-white border-[#E5E5EA] text-[#1D1D1F] focus:border-[#6366F1]
                                dark:bg-[#1C1C1E] dark:border-[#38383A] dark:text-[#F5F5F7] dark:focus:border-[#6366F1]"
                        >
                        <button onclick="saveApiKey()"
                            class="px-4 py-2 rounded-xl text-[13px] font-semibold text-white
                                bg-gradient-to-r from-[#6366F1] to-[#D946EF]
                                hover:opacity-90 transition-opacity">
                            Save
                        </button>
                    </div>
                </div>

                ${apikey.registered ? `
                    <button onclick="deleteApiKey()"
                        class="text-[13px] text-red-500 hover:text-red-600 font-medium transition-colors">
                        Remove API Key
                    </button>` : ''}
            </div>
        </div>

        <!-- Configuration -->
        <div class="glass-card p-6">
            <h3 class="text-[16px] font-bold mb-4 flex items-center gap-2">
                <i data-lucide="sliders-horizontal" class="w-5 h-5 text-[#6366F1]"></i>
                Configuration
            </h3>
            <div class="space-y-3">
                ${Object.entries(config).map(([key, value]) => `
                    <div class="flex items-center justify-between py-2 border-b border-[#E5E5EA] dark:border-[#38383A] last:border-0">
                        <span class="text-[13px] font-medium">${escapeHtml(key)}</span>
                        <span class="text-[13px] text-[#86868B]">${escapeHtml(String(value))}</span>
                    </div>
                `).join('')}
            </div>
        </div>`;

    lucide.createIcons();
}

async function saveApiKey() {
    const input = document.getElementById('apikey-input');
    const saveBtn = input?.parentElement?.querySelector('button');
    const key = input?.value?.trim();
    if (!key) {
        showToast('API key를 입력하세요.', 'error');
        return;
    }
    // Disable button during validation
    if (saveBtn) { saveBtn.disabled = true; saveBtn.textContent = 'Validating...'; }
    try {
        const data = await apiFetch('/api/apikey/set', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ api_key: key }),
        });
        if (data.error) {
            showToast(data.error, 'error');
            return;
        }
        input.value = '';
        showToast('API key 검증 완료, 저장되었습니다.', 'success');
        loadSettings();
    } catch {
        showToast('API key 저장에 실패했습니다.', 'error');
    } finally {
        if (saveBtn) { saveBtn.disabled = false; saveBtn.textContent = 'Save'; }
    }
}

async function connectAuth() {
    const btn = document.getElementById('oauth-connect-btn');
    const originalLabel = btn?.textContent?.trim();
    if (btn) { btn.disabled = true; btn.textContent = 'Opening browser...'; }
    showToast('브라우저에서 Google 로그인을 완료하세요.', 'info');
    try {
        const data = await apiFetch('/api/auth/login', { method: 'POST' });
        if (data.status === 'ok') {
            showToast(`Connected${data.email ? ` as ${data.email}` : ''}.`, 'success');
            loadSettings();
        } else {
            showToast(data.error || 'OAuth flow failed.', 'error');
            if (btn) { btn.disabled = false; btn.textContent = originalLabel || 'Connect'; }
        }
    } catch {
        showToast('OAuth 요청에 실패했습니다.', 'error');
        if (btn) { btn.disabled = false; btn.textContent = originalLabel || 'Connect'; }
    }
}

async function deleteApiKey() {
    if (!confirm('API key를 삭제하시겠습니까?')) return;
    try {
        await apiFetch('/api/apikey', { method: 'DELETE' });
        showToast('API key가 삭제되었습니다.', 'success');
        loadSettings();
    } catch {
        showToast('API key 삭제에 실패했습니다.', 'error');
    }
}

// ════════════════════════════════════════
// Keyboard Shortcuts
// ════════════════════════════════════════

document.addEventListener('keydown', (e) => {
    // Cmd+K → Focus search
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        const search = document.getElementById('global-search') || document.getElementById('explorer-search');
        if (search) search.focus();
    }
    // Escape → Close detail panel
    if (e.key === 'Escape') {
        closeDetailPanel();
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const globalSearch = document.getElementById('global-search');
    if (globalSearch) {
        globalSearch.addEventListener('keydown', (e) => {
            if (e.key !== 'Enter') return;
            const query = globalSearch.value.trim();
            if (!query) return;
            window.location.href = `/explorer?q=${encodeURIComponent(query)}`;
        });
    }

    // Populate user avatar from auth status
    (async () => {
        const el = document.getElementById('user-avatar');
        if (!el) return;
        try {
            const auth = await apiFetch('/api/auth/status');
            const email = auth?.email || '';
            const initial = email ? email.charAt(0).toUpperCase() : '?';
            el.textContent = initial;
            el.title = auth?.authenticated
                ? email
                : (auth?.expired ? 'Token expired' : 'Not connected');
        } catch {
            el.textContent = '?';
            el.title = 'Auth status unavailable';
        }
    })();
});
