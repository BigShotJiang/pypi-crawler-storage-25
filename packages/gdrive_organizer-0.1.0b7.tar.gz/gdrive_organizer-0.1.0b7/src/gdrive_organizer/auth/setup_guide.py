"""Interactive GCP OAuth setup guide for first-time users."""

from __future__ import annotations

import shutil
import time
import webbrowser
from pathlib import Path
from typing import TYPE_CHECKING

import typer
from rich.console import Console

if TYPE_CHECKING:
    from gdrive_organizer.config import Config

TOTAL_STEPS = 5

# GCP Console deep-links
URL_PROJECT_CREATE = "https://console.cloud.google.com/projectcreate"
URL_DRIVE_API = "https://console.cloud.google.com/apis/library/drive.googleapis.com"
URL_CONSENT_SCREEN = "https://console.cloud.google.com/apis/credentials/consent"
URL_CREDENTIALS = "https://console.cloud.google.com/apis/credentials"


def run_setup_guide(config: Config, console: Console) -> None:
    """Run the interactive GCP OAuth setup guide."""
    console.print()
    console.print("[bold cyan]Google Drive API OAuth 설정 가이드[/bold cyan]")
    console.print("[dim]GCP 프로젝트 생성부터 인증까지 단계별로 안내합니다.[/dim]")
    console.print()

    # --- Pre-check ---
    skip_to_login = _pre_check(config, console)
    if skip_to_login is None:
        # Already fully authenticated
        return
    if skip_to_login:
        # credentials.json exists, skip to OAuth login
        _step_oauth_login(config, console)
        return

    # --- Full guide ---
    _step_create_project(console)
    _step_enable_api(console)
    _step_consent_screen(console)
    _step_create_client_id(console)
    _step_detect_and_login(config, console)


def _pre_check(config: Config, console: Console) -> bool | None:
    """Check current state and decide where to start.

    Returns:
        None  — already authenticated, nothing to do
        True  — credentials exist, skip to OAuth login
        False — start from Step 1
    """
    from gdrive_organizer.auth.oauth import check_token_status

    has_credentials = config.credentials_path.exists()
    token_status = check_token_status(config)

    if has_credentials and token_status["valid"]:
        email = token_status.get("email") or "unknown"
        console.print(f"[green]이미 인증이 완료되어 있습니다![/green] ({email})")
        console.print(
            f"[dim]credentials: {config.credentials_path}[/dim]\n"
            f"[dim]token: {config.token_path}[/dim]"
        )
        return None

    if has_credentials:
        console.print(f"[green]credentials.json 발견:[/green] {config.credentials_path}")
        console.print("[dim]GCP 설정 단계를 건너뛰고 OAuth 로그인으로 이동합니다.[/dim]")
        console.print()
        return True

    return False


# ── Step functions ──────────────────────────────────────────────


def _step_create_project(console: Console) -> None:
    """Step 1: Create GCP project."""
    _print_step_header(console, 1, "GCP 프로젝트 생성")

    console.print("  Google Cloud Console에서 새 프로젝트를 만듭니다.\n")
    console.print("  1. 아래 URL을 열어주세요:")
    console.print(f"     [bold]{URL_PROJECT_CREATE}[/bold]\n")
    console.print('  2. [bold]"Project name"[/bold] 에 원하는 이름 입력 (예: GDrive Organizer)')
    console.print('  3. [bold]"Create"[/bold] 클릭')
    console.print()
    console.print("  [dim]이미 GCP 프로젝트가 있다면 기존 프로젝트를 사용해도 됩니다.[/dim]")

    _open_url_prompt(console, URL_PROJECT_CREATE)
    _wait_for_enter(console)


def _step_enable_api(console: Console) -> None:
    """Step 2: Enable Google Drive API."""
    _print_step_header(console, 2, "Google Drive API 활성화")

    console.print("  프로젝트에서 Drive API를 사용하도록 설정합니다.\n")
    console.print("  1. 아래 URL을 열어주세요:")
    console.print(f"     [bold]{URL_DRIVE_API}[/bold]\n")
    console.print("  2. 상단의 프로젝트가 방금 만든 프로젝트인지 확인하세요")
    console.print('  3. [bold]"Enable"[/bold] 버튼 클릭')
    console.print()
    console.print(
        '  [dim]이미 활성화되어 있다면 "Manage" 버튼이 보입니다. 그대로 넘어가세요.[/dim]'
    )

    _open_url_prompt(console, URL_DRIVE_API)
    _wait_for_enter(console)


def _step_consent_screen(console: Console) -> None:
    """Step 3: Configure OAuth consent screen."""
    _print_step_header(console, 3, "OAuth 동의 화면 설정")

    console.print("  사용자 인증 시 표시되는 동의 화면을 구성합니다.\n")
    console.print("  1. 아래 URL을 열어주세요:")
    console.print(f"     [bold]{URL_CONSENT_SCREEN}[/bold]\n")

    console.print("  2. 아래 순서대로 진행하세요:\n")
    console.print('     a) User Type: [bold]"External"[/bold] 선택 → [bold]"Create"[/bold]')
    console.print(
        '     b) App name: [bold]"GDrive Organizer"[/bold] 입력, '
        "User support email에 본인 이메일 입력"
    )
    console.print('     c) [bold]"Save and Continue"[/bold] 클릭')
    console.print()
    console.print('     d) Scopes 페이지: [bold]"Add or Remove Scopes"[/bold] 클릭')
    console.print(
        "        → 필터에 [bold]drive[/bold] 검색"
        " → [bold]https://www.googleapis.com/auth/drive[/bold] 체크"
    )
    console.print('        → [bold]"Update"[/bold] → [bold]"Save and Continue"[/bold]')
    console.print()
    console.print(
        '     e) Test users: [bold]"+ Add Users"[/bold] '
        '→ 본인 Gmail 주소 입력 → [bold]"Save and Continue"[/bold]'
    )
    console.print('     f) Summary 확인 → [bold]"Back to Dashboard"[/bold]')
    console.print()

    console.print(
        "  [yellow]참고:[/yellow] 테스팅 모드에서는 등록된 테스트 사용자만 로그인할 수 있고,"
    )
    console.print("  refresh token이 7일 후 만료됩니다. 만료 시 다시 로그인하면 됩니다.")

    _open_url_prompt(console, URL_CONSENT_SCREEN)
    _wait_for_enter(console)


def _step_create_client_id(console: Console) -> None:
    """Step 4: Create OAuth Client ID and download JSON."""
    _print_step_header(console, 4, "OAuth Client ID 생성 및 JSON 다운로드")

    console.print("  API 인증에 사용할 Client ID를 생성하고 JSON 파일을 받습니다.\n")
    console.print("  1. 아래 URL을 열어주세요:")
    console.print(f"     [bold]{URL_CREDENTIALS}[/bold]\n")

    console.print('  2. [bold]"+ Create Credentials"[/bold] → [bold]"OAuth client ID"[/bold] 클릭')
    console.print('  3. Application type: [bold]"Desktop app"[/bold] 선택')
    console.print('  4. Name: [bold]"GDrive Organizer CLI"[/bold] 입력')
    console.print('  5. [bold]"Create"[/bold] 클릭')
    console.print()
    console.print("  6. 생성 완료 팝업에서 [bold]JSON 다운로드[/bold] (↓ 아이콘) 클릭")
    console.print()
    console.print("  [dim]다운로드된 파일 이름을 변경할 필요 없습니다 — 자동으로 감지됩니다.[/dim]")

    _open_url_prompt(console, URL_CREDENTIALS)
    _wait_for_enter(console)


def _step_detect_and_login(config: Config, console: Console) -> None:
    """Step 5: Detect downloaded credentials and run OAuth login."""
    _print_step_header(console, 5, "Credentials 감지 및 로그인")

    console.print("  다운로드된 credentials 파일을 찾고 OAuth 로그인을 진행합니다.\n")

    if config.credentials_path.exists():
        console.print(f"[green]credentials.json 이미 존재:[/green] {config.credentials_path}")
    else:
        found = _wait_for_credentials(config, console)
        if not found:
            found = _manual_credentials_input(config, console)
        if not found:
            console.print("\n[red]credentials 파일을 찾지 못했습니다.[/red]")
            console.print(
                "  파일을 다운로드한 후 다시 "
                "[bold]gdrive-organizer auth setup[/bold] 을 실행하세요."
            )
            raise typer.Exit(1)

    console.print()
    _step_oauth_login(config, console)


def _step_oauth_login(config: Config, console: Console) -> None:
    """Run OAuth login flow and verify."""
    console.print("[bold cyan]OAuth 로그인을 시작합니다...[/bold cyan]")
    console.print("[dim]브라우저가 열리면 Google 계정으로 로그인하고 권한을 허용해주세요.[/dim]")
    console.print()

    try:
        from gdrive_organizer.auth.oauth import get_drive_service

        service = get_drive_service(config)
        about = service.about().get(fields="user").execute()
        user = about.get("user", {})
        name = user.get("displayName", "unknown")
        email = user.get("emailAddress", "unknown")

        console.print()
        console.print("[bold green]설정 완료![/bold green]")
        console.print(f"  계정: {name} ({email})")
        console.print()
        console.print("[dim]이제 다음 명령어로 시작하세요:[/dim]")
        console.print("  [bold]gdrive-organizer scan[/bold]    — Drive 파일 스캔")
        console.print("  [bold]gdrive-organizer tree[/bold]    — 폴더 트리 보기")
        console.print("  [bold]gdrive-organizer auth status[/bold] — 인증 상태 확인")
    except Exception as e:
        console.print(f"\n[red]OAuth 로그인 실패:[/red] {e}")
        console.print("  다시 시도하려면 [bold]gdrive-organizer auth login[/bold] 을 실행하세요.")
        raise typer.Exit(1) from e


# ── Helpers ─────────────────────────────────────────────────────


def _print_step_header(console: Console, step: int, title: str) -> None:
    """Print a formatted step header."""
    console.print()
    console.print(f"[bold cyan]━━━ Step {step}/{TOTAL_STEPS}: {title} ━━━[/bold cyan]")
    console.print()


def _wait_for_enter(console: Console) -> None:
    """Wait for the user to press Enter to continue."""
    console.print()
    console.input("[dim]완료했으면 Enter를 눌러 다음 단계로 이동하세요...[/dim] ")
    console.print()


def _open_url_prompt(console: Console, url: str) -> None:
    """Offer to open a URL in the default browser."""
    console.print()
    try:
        open_it = typer.confirm("  브라우저에서 열까요?", default=True)
    except typer.Abort:
        return
    if open_it:
        try:
            webbrowser.open(url)
            console.print("  [dim]브라우저를 열었습니다.[/dim]")
        except Exception:
            console.print(
                "  [yellow]브라우저를 열 수 없습니다. 위 URL을 직접 복사해서 열어주세요.[/yellow]"
            )


def _wait_for_credentials(config: Config, console: Console) -> bool:
    """Poll Downloads folder for GCP credentials file.

    Returns True if credentials were found and moved to config dir.
    """
    from gdrive_organizer.auth.oauth import auto_detect_credentials

    timeout = 300  # 5 minutes
    interval = 2

    console.print("  Downloads 폴더에서 credentials 파일을 찾습니다.")
    console.print("  [dim]GCP Console에서 JSON을 다운로드하면 자동으로 감지됩니다.[/dim]\n")

    with console.status(
        "[bold cyan]  credentials 파일 감지 대기 중...[/bold cyan]",
        spinner="dots",
    ):
        elapsed = 0
        while elapsed < timeout:
            if auto_detect_credentials(config):
                break
            time.sleep(interval)
            elapsed += interval
        else:
            console.print("\n  [yellow]5분 동안 파일을 찾지 못했습니다.[/yellow]")
            return False

    console.print(
        f"\n  [green]credentials 파일을 발견하여 이동했습니다:[/green]\n"
        f"    {config.credentials_path}"
    )
    return True


def _manual_credentials_input(config: Config, console: Console) -> bool:
    """Allow the user to manually specify the credentials file path."""
    console.print()
    console.print("  파일 경로를 직접 입력하거나 'q'로 종료할 수 있습니다.")

    try:
        path_str = typer.prompt("  파일 경로", default="q")
    except typer.Abort:
        return False

    if path_str.strip().lower() == "q":
        return False

    source = Path(path_str.strip()).expanduser()
    if not source.exists():
        console.print(f"  [red]파일을 찾을 수 없습니다:[/red] {source}")
        return False

    config.credentials_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(str(source), str(config.credentials_path))
    console.print(
        f"  [green]credentials 파일을 복사했습니다:[/green]\n    {config.credentials_path}"
    )
    return True
