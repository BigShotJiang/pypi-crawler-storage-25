"""Google OAuth 2.0 authentication for Drive API v3."""

from __future__ import annotations

import json
import os
import platform
import shutil
from datetime import UTC
from pathlib import Path
from typing import TYPE_CHECKING

from google.auth.exceptions import RefreshError
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

from gdrive_organizer.utils.logger import get_logger

if TYPE_CHECKING:
    from googleapiclient.discovery import Resource

    from gdrive_organizer.config import Config

logger = get_logger("auth.oauth")

SCOPES = ["https://www.googleapis.com/auth/drive"]
READONLY_SCOPES = ["https://www.googleapis.com/auth/drive.metadata.readonly"]

# GCP Console downloads credentials with this filename pattern
_GCP_CREDS_GLOB = "client_secret_*.apps.googleusercontent.com.json"


def _get_scopes(config: Config) -> list[str]:
    """Return the appropriate OAuth scopes based on config."""
    return READONLY_SCOPES if config.oauth_readonly else SCOPES


def get_drive_service(config: Config) -> Resource:
    """Authenticate and return a Drive API v3 service instance."""
    creds = _load_or_refresh_token(config)
    if creds is None:
        creds = _run_oauth_flow(config)
    service = build("drive", "v3", credentials=creds)
    _ensure_account_email_metadata(service, config)
    return service


def _load_or_refresh_token(config: Config) -> Credentials | None:
    """Load token from disk, refresh if expired.

    If oauth_readonly is enabled but the stored token was issued with full
    drive scope, the token is rejected and the user must re-authenticate.
    """
    if not config.token_path.exists():
        return None
    scopes = _get_scopes(config)
    data = json.loads(config.token_path.read_text())

    # Scope mismatch guard: if readonly mode is requested but the stored
    # token has full-write scope, refuse to use it silently.
    if config.oauth_readonly:
        token_scopes = data.get("scopes", [])
        full_scope = "https://www.googleapis.com/auth/drive"
        if full_scope in token_scopes:
            return None  # Force re-auth with readonly scope

    creds = Credentials.from_authorized_user_info(data, scopes)
    if creds.valid:
        return creds
    if creds.expired and creds.refresh_token:
        try:
            creds.refresh(Request())
        except RefreshError as e:
            # Refresh token was revoked or expired (Google's testing-mode
            # 7-day cap is the common cause). Wipe the dead token so the
            # caller can fall through to a fresh OAuth flow — otherwise
            # the user would have to run `auth logout` manually first.
            logger.warning(
                "Refresh token rejected (%s); deleting stored token "
                "and falling back to fresh OAuth flow.",
                e,
            )
            try:
                config.token_path.unlink()
            except FileNotFoundError:
                pass
            return None
        _save_token(
            creds,
            config.token_path,
            extra_metadata=_extract_token_metadata(data),
        )
        return creds
    return None


def _run_oauth_flow(config: Config) -> Credentials:
    """Run the OAuth 2.0 desktop app flow."""
    if not config.credentials_path.exists():
        # Try to auto-detect from Downloads folder
        found = auto_detect_credentials(config)
        if not found:
            raise FileNotFoundError(
                f"OAuth credentials not found at {config.credentials_path}\n"
                "Please download the OAuth client JSON from Google Cloud Console\n"
                "and place it in your Downloads folder, or run:\n"
                f"  cp <downloaded-file>.json {config.credentials_path}"
            )
    scopes = _get_scopes(config)
    flow = InstalledAppFlow.from_client_secrets_file(str(config.credentials_path), scopes)
    creds = flow.run_local_server(port=0)
    service = build("drive", "v3", credentials=creds)
    account_email = _fetch_account_email(service)
    _save_token(
        creds,
        config.token_path,
        extra_metadata={"account_email": account_email} if account_email else None,
    )
    return creds


def _extract_token_metadata(data: dict) -> dict:
    """Extract custom metadata fields that should survive token refreshes."""
    metadata = {}
    if data.get("account_email"):
        metadata["account_email"] = data["account_email"]
    return metadata


def _save_token(
    creds: Credentials,
    path: Path,
    extra_metadata: dict | None = None,
) -> None:
    """Save credentials to a JSON file with restricted permissions."""
    path.parent.mkdir(parents=True, exist_ok=True)
    data = json.loads(creds.to_json())
    if extra_metadata:
        data.update({k: v for k, v in extra_metadata.items() if v})
    path.write_text(json.dumps(data, indent=2))
    # Restrict to owner-only read/write (chmod 600)
    if platform.system() != "Windows":
        os.chmod(path, 0o600)


def _fetch_account_email(service: Resource) -> str | None:
    """Fetch the authenticated user's email address from Drive about()."""
    try:
        about = service.about().get(fields="user").execute()
    except Exception:
        return None
    user = about.get("user", {})
    return user.get("emailAddress")


def _load_fallback_account_email(config: Config) -> str | None:
    """Fallback to the last scanned Drive account email for legacy token files."""
    try:
        from gdrive_organizer.store.snapshot import load_snapshot

        snapshot = load_snapshot(config=config)
    except Exception:
        return None
    if snapshot.drive_info and snapshot.drive_info.user_email:
        return snapshot.drive_info.user_email
    return None


def _ensure_account_email_metadata(service: Resource, config: Config) -> None:
    """Backfill account_email into token metadata when it is missing."""
    if not config.token_path.exists():
        return
    try:
        data = json.loads(config.token_path.read_text())
    except Exception:
        return
    if data.get("account_email"):
        return
    account_email = _fetch_account_email(service)
    if not account_email:
        return
    data["account_email"] = account_email
    config.token_path.write_text(json.dumps(data, indent=2))
    if platform.system() != "Windows":
        os.chmod(config.token_path, 0o600)


def auto_detect_credentials(config: Config) -> bool:
    """Search for GCP OAuth credentials in common download locations.

    Returns True if credentials were found and moved to the config directory.
    """
    search_dirs = _get_download_dirs()

    candidates: list[Path] = []
    for search_dir in search_dirs:
        if search_dir.exists():
            candidates.extend(search_dir.glob(_GCP_CREDS_GLOB))

    if not candidates:
        return False

    # Pick the most recently modified file
    candidates.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    source = candidates[0]

    # Move to config directory
    config.credentials_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(source), str(config.credentials_path))
    os.chmod(config.credentials_path, 0o600)

    return True


def _get_download_dirs() -> list[Path]:
    """Get common download directories for the current platform."""
    home = Path.home()
    dirs = [home / "Downloads"]

    system = platform.system()
    if system == "Darwin":
        # macOS: also check Desktop
        dirs.append(home / "Desktop")
    elif system == "Windows":
        # Windows: Downloads might be localized, but ~/Downloads is standard
        dirs.append(home / "Desktop")
    elif system == "Linux":
        # XDG user dirs
        xdg_download = os.environ.get("XDG_DOWNLOAD_DIR")
        if xdg_download:
            dirs.append(Path(xdg_download))

    return dirs


def check_token_status(config: Config) -> dict:
    """Check the status of the stored OAuth token."""
    if not config.token_path.exists():
        return {
            "valid": False,
            "expired": False,
            "expiry": None,
            "email": None,
            "readonly": config.oauth_readonly,
        }
    try:
        scopes = _get_scopes(config)
        data = json.loads(config.token_path.read_text())
        creds = Credentials.from_authorized_user_info(data, scopes)
        expiry = creds.expiry
        if expiry and expiry.tzinfo is None:
            expiry = expiry.replace(tzinfo=UTC)
        return {
            "valid": creds.valid,
            "expired": creds.expired,
            "expiry": expiry.isoformat() if expiry else None,
            "email": data.get("account_email") or _load_fallback_account_email(config),
            "readonly": config.oauth_readonly,
        }
    except Exception:
        return {
            "valid": False,
            "expired": False,
            "expiry": None,
            "email": _load_fallback_account_email(config),
            "readonly": config.oauth_readonly,
        }


def logout(config: Config) -> bool:
    """Remove stored token. Returns True if token was removed."""
    if config.token_path.exists():
        config.token_path.unlink()
        return True
    return False
