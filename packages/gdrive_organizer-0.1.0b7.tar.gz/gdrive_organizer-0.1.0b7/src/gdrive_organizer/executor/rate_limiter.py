"""Token bucket rate limiter for Drive API write operations."""

import threading
import time


class TokenBucket:
    """Thread-safe token bucket rate limiter."""

    def __init__(self, rate: float = 3.0, capacity: float = 10.0):
        self.rate = rate  # tokens per second
        self.capacity = capacity
        self._tokens = capacity
        self._last_refill = time.monotonic()
        self._lock = threading.Lock()

    def acquire(self, tokens: float = 1.0) -> None:
        """Block until enough tokens are available."""
        if tokens > self.capacity:
            raise ValueError(
                f"Requested {tokens} tokens but bucket capacity is {self.capacity}. "
                "Increase capacity or request fewer tokens."
            )
        while True:
            with self._lock:
                self._refill()
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return
                wait_time = (tokens - self._tokens) / self.rate
            time.sleep(wait_time)

    def _refill(self) -> None:
        """Add tokens based on elapsed time."""
        now = time.monotonic()
        elapsed = now - self._last_refill
        self._tokens = min(self.capacity, self._tokens + elapsed * self.rate)
        self._last_refill = now
