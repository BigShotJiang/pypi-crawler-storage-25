"""GDrive Organizer CLI entry point."""

from collections import Counter
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from gdrive_organizer import __version__
from gdrive_organizer.auth.oauth import check_token_status, logout
from gdrive_organizer.config import ensure_dirs, load_config

console = Console()

app = typer.Typer(
    name="gdrive-organizer",
    help="AI-powered Google Drive organizer",
    no_args_is_help=True,
)

auth_app = typer.Typer(help="Authentication commands")
app.add_typer(auth_app, name="auth")

config_app = typer.Typer(help="Configuration commands")
app.add_typer(config_app, name="config")

plan_app = typer.Typer(help="Plan management commands")
app.add_typer(plan_app, name="plan")


def _version_callback(value: bool):
    if value:
        typer.echo(f"gdrive-organizer v{__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool | None = typer.Option(
        None, "--version", "-v", help="Show version and exit.", callback=_version_callback
    ),
    config_dir: Path | None = typer.Option(None, "--config-dir", help="Config directory path."),
    verbose: bool = typer.Option(False, "--verbose", help="Enable verbose logging."),
):
    """AI-powered Google Drive organizer."""
    main.config_dir = config_dir
    main.verbose = verbose


def _get_config():
    from gdrive_organizer.utils.logger import setup_logger

    config_dir = getattr(main, "config_dir", None)
    config = load_config(config_dir)
    if getattr(main, "verbose", False):
        config.log_level = "DEBUG"
    ensure_dirs(config)
    # Wire up the root logger once per CLI invocation so warnings/errors land
    # in logs/gdrive-organizer.log (rotating). Previously nothing called
    # setup_logger, so the logs/ dir stayed empty even on errors.
    setup_logger(
        name="gdrive_organizer",
        log_level=config.log_level,
        log_dir=config.data_dir / "logs",
    )
    return config


# --- Auth commands ---


@auth_app.command("setup")
def auth_setup():
    """GCP OAuth 설정 가이드 — 처음 사용하는 분을 위한 단계별 안내."""
    config = _get_config()
    from gdrive_organizer.auth.setup_guide import run_setup_guide

    run_setup_guide(config, console)


@auth_app.command("login")
def auth_login():
    """Authenticate with Google Drive via OAuth."""
    config = _get_config()
    from gdrive_organizer.auth.oauth import auto_detect_credentials, get_drive_service

    # Auto-detect credentials if not already present
    if not config.credentials_path.exists():
        console.print("[dim]Credentials not found. Searching Downloads folder...[/dim]")
        if auto_detect_credentials(config):
            console.print(
                f"[green]Found and moved credentials to {config.credentials_path}[/green]"
            )
        else:
            console.print(
                "[red]No credentials found.[/red]\n"
                "Download the OAuth client JSON from Google Cloud Console\n"
                "and save it to your Downloads folder, then run this command again."
            )
            raise typer.Exit(1)

    try:
        service = get_drive_service(config)
        about = service.about().get(fields="user").execute()
        user = about.get("user", {})
        console.print(f"[green]Authenticated as {user.get('displayName', 'unknown')}[/green]")
        console.print(f"Email: {user.get('emailAddress', 'unknown')}")
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e


@auth_app.command("status")
def auth_status():
    """Check authentication status."""
    config = _get_config()
    status = check_token_status(config)

    table = Table(title="Auth Status")
    table.add_column("Field", style="cyan")
    table.add_column("Value", style="white")
    table.add_row("Token exists", str(config.token_path.exists()))
    table.add_row("Valid", str(status["valid"]))
    table.add_row("Expired", str(status["expired"]))
    table.add_row("Expiry", status["expiry"] or "N/A")
    console.print(table)


@auth_app.command("logout")
def auth_logout():
    """Remove stored authentication token."""
    config = _get_config()
    if logout(config):
        console.print("[green]Logged out successfully.[/green]")
    else:
        console.print("[yellow]No token found.[/yellow]")


# --- Config commands ---


@config_app.command("show")
def config_show():
    """Show current configuration."""
    config = _get_config()
    table = Table(title="Configuration")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="white")
    for key, value in config.model_dump().items():
        table.add_row(key, str(value))
    console.print(table)


@config_app.command("set")
def config_set(
    key: str = typer.Argument(help="Configuration key"),
    value: str = typer.Argument(help="Configuration value"),
):
    """Update a configuration value."""
    from gdrive_organizer.config import save_config

    config = _get_config()
    data = config.model_dump()
    if key not in data:
        console.print(f"[red]Unknown key: {key}[/red]")
        raise typer.Exit(1)
    current = data[key]
    if isinstance(current, bool):
        coerced = value.lower() in ("true", "1", "yes")
    elif isinstance(current, int):
        coerced = int(value)
    elif isinstance(current, float):
        coerced = float(value)
    else:
        coerced = value
    setattr(config, key, coerced)
    save_config(config)
    console.print(f"[green]Set {key} = {coerced}[/green]")


@config_app.command("api-key")
def config_api_key(
    action: str = typer.Argument(help="set, show, or delete"),
    key: str | None = typer.Argument(None, help="API key value (for 'set')"),
):
    """Manage xAI Grok API key (stored in system keychain)."""
    from gdrive_organizer.ai.classifier import delete_api_key, load_api_key, save_api_key

    if action == "set":
        if not key:
            key = typer.prompt("Enter your xAI API key", hide_input=True)
        save_api_key(key)
        console.print("[green]API key saved to system keychain.[/green]")
    elif action == "show":
        stored = load_api_key()
        if stored:
            masked = stored[:8] + "..." + stored[-4:]
            console.print(f"API key: {masked}")
        else:
            console.print("[yellow]No API key stored.[/yellow]")
    elif action == "delete":
        delete_api_key()
        console.print("[green]API key removed from keychain.[/green]")
    else:
        console.print("[red]Usage: api-key set|show|delete[/red]")
        raise typer.Exit(1)


@config_app.command("exclude")
def config_exclude(
    show: bool = typer.Option(False, "--show", help="Show current exclude rules."),
    add_folder: list[str] | None = typer.Option(None, "--add-folder"),
    remove_folder: list[str] | None = typer.Option(None, "--remove-folder"),
    add_ext: list[str] | None = typer.Option(None, "--add-ext"),
    remove_ext: list[str] | None = typer.Option(None, "--remove-ext"),
    add_name: list[str] | None = typer.Option(None, "--add-name"),
    remove_name: list[str] | None = typer.Option(None, "--remove-name"),
    reset: bool = typer.Option(False, "--reset", help="Reset to defaults."),
):
    """Manage scan exclusion rules."""
    config = _get_config()
    from gdrive_organizer.scanner.filter import (
        load_exclude_config,
        load_exclude_rules,
        save_exclude_config,
    )

    if reset:
        save_exclude_config(
            config,
            {
                "excluded_folders": {"add": [], "remove": []},
                "excluded_extensions": {"add": [], "remove": []},
                "excluded_names": {"add": [], "remove": []},
            },
        )
        console.print("[green]Exclude rules reset to defaults.[/green]")
        return

    has_changes = any([add_folder, remove_folder, add_ext, remove_ext, add_name, remove_name])
    if show or not has_changes:
        rules = load_exclude_rules(config)
        table = Table(title="Exclude Rules")
        table.add_column("Type", style="cyan")
        table.add_column("Patterns", style="white")
        table.add_row("Folders", ", ".join(sorted(rules.folders)))
        table.add_row("Extensions", ", ".join(sorted(rules.extensions)))
        table.add_row("Names", ", ".join(sorted(rules.names)))
        console.print(table)
        return

    data = load_exclude_config(config)
    if add_folder:
        existing = set(data["excluded_folders"].get("add", []))
        data["excluded_folders"]["add"] = list(existing | set(add_folder))
    if remove_folder:
        existing = set(data["excluded_folders"].get("remove", []))
        data["excluded_folders"]["remove"] = list(existing | set(remove_folder))
    if add_ext:
        existing = set(data["excluded_extensions"].get("add", []))
        data["excluded_extensions"]["add"] = list(existing | set(add_ext))
    if remove_ext:
        existing = set(data["excluded_extensions"].get("remove", []))
        data["excluded_extensions"]["remove"] = list(existing | set(remove_ext))
    if add_name:
        existing = set(data["excluded_names"].get("add", []))
        data["excluded_names"]["add"] = list(existing | set(add_name))
    if remove_name:
        existing = set(data["excluded_names"].get("remove", []))
        data["excluded_names"]["remove"] = list(existing | set(remove_name))
    save_exclude_config(config, data)
    console.print("[green]Exclude rules updated.[/green]")


# --- Scan command ---


@app.command("scan")
def scan(
    folder: str | None = typer.Option(None, "--folder", help="Folder ID to scan."),
    incremental: bool = typer.Option(
        False, "--incremental", help="Incremental scan via Changes API."
    ),
    no_filter: bool = typer.Option(
        False, "--no-filter", help="Disable exclusion filters, scan everything."
    ),
):
    """Scan Google Drive and save a snapshot."""
    config = _get_config()
    from gdrive_organizer.auth.oauth import get_drive_service

    service = get_drive_service(config)

    if incremental:
        from gdrive_organizer.store.changelog import ChangeTokenExpiredError, incremental_scan

        try:
            snapshot = incremental_scan(service, config)
        except ChangeTokenExpiredError:
            console.print(
                "[bold red]Change token expired (410 Gone).[/bold red]\n"
                "The stored sync token is no longer valid.\n"
                "[yellow]Run a full scan instead:[/yellow] "
                "[cyan]gdrive-organizer scan[/cyan]"
            )
            raise typer.Exit(1) from None
        console.print("[green]Incremental scan complete.[/green]")
        console.print(
            f"Files: {snapshot.stats.total_files} | Folders: {snapshot.stats.total_folders}"
        )
        return

    from gdrive_organizer.scanner.service import run_full_scan

    try:
        result = run_full_scan(
            service,
            config,
            folder_id=folder,
            apply_filters=not no_filter,
        )
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from None

    table = Table(title="Scan Summary")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="white")
    table.add_row("Files", str(result.file_count))
    table.add_row("Folders", str(result.folder_count))
    table.add_row("Total items", str(result.total_items))
    table.add_row("Duration", f"{result.duration_ms}ms")
    table.add_row("Snapshot", str(result.filepath.name))
    console.print(table)


# --- Tree command ---


@app.command("tree")
def tree(
    depth: int | None = typer.Option(None, "--depth", "-d", help="Maximum tree depth."),
):
    """Display Drive file tree."""
    config = _get_config()
    from gdrive_organizer.scanner.tree import build_tree, compute_paths, tree_to_rich
    from gdrive_organizer.store.snapshot import drive_file_to_raw, load_snapshot

    snapshot = load_snapshot(config=config)
    raw_files = [drive_file_to_raw(f) for f in snapshot.files]
    _, roots = build_tree(raw_files)
    compute_paths(roots)
    rich_tree = tree_to_rich(roots, max_depth=depth)
    console.print(rich_tree)


# --- Stats command ---


@app.command("stats")
def stats():
    """Show Drive statistics."""
    config = _get_config()
    from gdrive_organizer.store.snapshot import load_snapshot

    snapshot = load_snapshot(config=config)

    # Type distribution
    type_counter: Counter[str] = Counter()
    for f in snapshot.files:
        type_counter[f.mime_type] += 1

    table = Table(title="File Type Distribution")
    table.add_column("MIME Type", style="cyan")
    table.add_column("Count", style="white", justify="right")
    for mime, count in type_counter.most_common(15):
        table.add_row(mime, str(count))
    console.print(table)

    # Top 10 largest files
    sorted_files = sorted(snapshot.files, key=lambda f: f.size, reverse=True)[:10]
    table2 = Table(title="Top 10 Largest Files")
    table2.add_column("Name", style="cyan")
    table2.add_column("Size", style="white", justify="right")
    table2.add_column("Type", style="dim")
    for f in sorted_files:
        size_str = _format_size(f.size)
        table2.add_row(f.name, size_str, f.mime_type)
    console.print(table2)

    # Summary
    console.print(f"\nTotal files: {snapshot.stats.total_files}")
    console.print(f"Total folders: {snapshot.stats.total_folders}")
    console.print(f"Total size: {_format_size(snapshot.stats.total_size)}")


# --- Permissions command ---


@app.command("permissions")
def permissions():
    """Show permission summary."""
    config = _get_config()
    from gdrive_organizer.scanner.permissions import summarize_permissions
    from gdrive_organizer.store.snapshot import load_snapshot

    snapshot = load_snapshot(config=config)
    summary = summarize_permissions(snapshot.files)

    table = Table(title="Permission Summary")
    table.add_column("Category", style="cyan")
    table.add_column("Count", style="white", justify="right")
    table.add_row("Public (anyone)", str(summary["public"]))
    table.add_row("Domain shared", str(summary["domain"]))
    table.add_row("Specific users/groups", str(summary["specific_users"]))
    table.add_row("Not shared", str(summary["not_shared"]))
    console.print(table)

    if summary["details"]["public_files"]:
        console.print("\n[bold red]Publicly accessible files:[/bold red]")
        for f in summary["details"]["public_files"]:
            console.print(f"  - {f['name']} ({f['path'] or f['id']})")


# --- View command ---


@app.command("view")
def view(
    port: int | None = typer.Option(None, "--port", "-p", help="Server port."),
    unsafe_public: bool = typer.Option(
        False, "--unsafe-public", help="Bind to 0.0.0.0 (for Docker / remote access)."
    ),
):
    """Start the web viewer."""
    config = _get_config()
    if port:
        config.viewer_port = port
    from gdrive_organizer.viewer.app import start_viewer

    host = "0.0.0.0" if unsafe_public else config.viewer_host
    console.print(f"Starting viewer at http://{host}:{config.viewer_port}")
    start_viewer(config, unsafe_public=unsafe_public)


# --- Preset commands ---

preset_app = typer.Typer(help="Prompt preset management")
app.add_typer(preset_app, name="preset")


@preset_app.command("list")
def preset_list():
    """List available classification presets."""
    from gdrive_organizer.ai.prompts import list_presets

    table = Table(title="Available Presets")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="white")
    table.add_column("Description", style="dim")
    for p in list_presets():
        table.add_row(p.id, p.name, p.description)
    console.print(table)


@preset_app.command("show")
def preset_show(
    preset_id: str = typer.Argument(help="Preset ID (migration, second-brain, custom)"),
):
    """Show preset details including system prompt."""
    from gdrive_organizer.ai.prompts import load_preset

    try:
        preset = load_preset(preset_id)
    except (ValueError, FileNotFoundError) as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1) from e
    console.print(f"[bold]{preset.name}[/bold] ({preset.id})")
    console.print(f"[dim]{preset.description}[/dim]\n")
    console.print(preset.system_prompt)


# --- Classify command ---


@app.command("classify")
def classify(
    preset: str = typer.Option(
        "migration",
        "--preset",
        "-p",
        help="Preset: migration, second-brain, custom",
    ),
    prompt_file: Path | None = typer.Option(
        None, "--prompt-file", help="Custom prompt file (for custom preset)."
    ),
):
    """Classify files using AI preset and generate an execution plan."""
    import asyncio

    config = _get_config()
    from gdrive_organizer.ai.planner import generate_plan
    from gdrive_organizer.auth.oauth import get_drive_service
    from gdrive_organizer.store.snapshot import load_snapshot

    snapshot = load_snapshot(config=config)
    file_count = len(snapshot.files)
    console.print(f"Classifying {file_count} files with preset [cyan]{preset}[/cyan]...")

    service = get_drive_service(config)
    try:
        with console.status(
            f"[bold cyan]AI classification in progress ({file_count} files)...[/bold cyan]",
            spinner="dots",
        ):
            plan = asyncio.run(
                generate_plan(
                    snapshot,
                    config,
                    preset_id=preset,
                    prompt_file=prompt_file,
                    service=service,
                )
            )
    except Exception as e:
        from gdrive_organizer.ai.classifier import LLMError

        if isinstance(e, LLMError) or (e.__cause__ and isinstance(e.__cause__, LLMError)):
            console.print(f"[bold red]LLM classification failed:[/bold red] {e}")
            console.print("[yellow]Check your API key and network. See logs for details.[/yellow]")
            raise typer.Exit(1) from None
        raise

    table = Table(title="Plan Summary")
    table.add_column("Metric", style="cyan")
    table.add_column("Count", style="white", justify="right")
    table.add_row("Total operations", str(plan.stats.total_operations))
    table.add_row("Moves", str(plan.stats.moves))
    table.add_row("Shortcuts", str(plan.stats.shortcuts))
    table.add_row("Descriptions", str(plan.stats.descriptions))
    table.add_row("Trashed", str(plan.stats.trashed))
    console.print(table)


# --- Plan commands ---


@plan_app.command("show")
def plan_show(
    latest_plan: bool = typer.Option(
        False,
        "--latest-plan",
        help="Show the latest full plan even if an approved subset exists.",
    ),
    phase: int = typer.Option(
        0,
        "--phase",
        help="Filter by phase (1=folders, 2=moves, 3=shortcuts, 4=descriptions). 0=all.",
    ),
    per_phase: int = typer.Option(
        10,
        "--per-phase",
        help="Sample size per phase in the preview table.",
    ),
):
    """Show the current execution plan."""
    from collections import Counter

    config = _get_config()
    from gdrive_organizer.ai.planner import load_plan, plan_source_label, resolve_plan_path

    plan_path = resolve_plan_path(config, mode="latest" if latest_plan else "auto")
    if not plan_path:
        console.print("[yellow]No plan found. Run 'gdrive-organizer classify' first.[/yellow]")
        raise typer.Exit(1)
    plan = load_plan(plan_path)

    console.print(plan_source_label(config, plan_path))
    if plan.preset_id:
        console.print(f"Preset: [cyan]{plan.preset_id}[/cyan]")

    phase_map = {
        "create_folder": 1,
        "move": 2,
        "rename": 2,
        "rename_and_move": 2,
        "trash": 2,
        "untrash": 2,
        "create_shortcut": 3,
        "update_description": 4,
    }

    # ── Summary by phase / op type ──
    summary: Counter[tuple[int, str]] = Counter()
    for op in plan.operations:
        ph = phase_map.get(op.operation.value, 0)
        summary[(ph, op.operation.value)] += 1

    summary_table = Table(title=f"Plan summary — {len(plan.operations)} ops total")
    summary_table.add_column("Phase", style="yellow", justify="right")
    summary_table.add_column("Operation", style="cyan")
    summary_table.add_column("Count", style="green", justify="right")
    for (ph, op_type), count in sorted(summary.items()):
        summary_table.add_row(str(ph), op_type, str(count))
    console.print(summary_table)

    # ── Phase-balanced preview (otherwise the first 50 are all folders) ──
    if phase:
        ops_to_show = [
            op for op in plan.operations if phase_map.get(op.operation.value, 0) == phase
        ][: per_phase * 5]
        title = f"Phase {phase} preview ({len(ops_to_show)} ops)"
    else:
        # Sample N per phase so the user sees ops from every phase.
        by_phase: dict[int, list] = {1: [], 2: [], 3: [], 4: []}
        for op in plan.operations:
            ph = phase_map.get(op.operation.value, 0)
            if ph in by_phase and len(by_phase[ph]) < per_phase:
                by_phase[ph].append(op)
        ops_to_show = [op for ph in (1, 2, 3, 4) for op in by_phase[ph]]
        title = f"Preview — up to {per_phase} ops per phase ({len(ops_to_show)} shown)"

    table = Table(title=title)
    table.add_column("#", style="dim", justify="right")
    table.add_column("Phase", style="yellow")
    table.add_column("Operation", style="cyan")
    table.add_column("File", style="white", overflow="fold")
    table.add_column("Target", style="green", overflow="fold")
    table.add_column("Reason", style="dim", overflow="fold")

    for i, op in enumerate(ops_to_show, 1):
        ph = phase_map.get(op.operation.value, 0)
        target = op.new_path or op.new_description or "-"
        table.add_row(
            str(i),
            str(ph),
            op.operation.value,
            op.current_name,
            target,
            (op.reason or ""),
        )
    console.print(table)

    if not phase and len(plan.operations) > len(ops_to_show):
        console.print(
            f"[dim]... showing {len(ops_to_show)} of {len(plan.operations)}. "
            f"Use --phase N or raise --per-phase to see more.[/dim]"
        )


@plan_app.command("apply")
def plan_apply(
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without executing."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
    force: bool = typer.Option(
        False, "--force", help="Skip stale-snapshot check (use with caution)."
    ),
    latest_plan: bool = typer.Option(
        False,
        "--latest-plan",
        help="Apply the latest full plan even if an approved subset exists.",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="In dry-run, print every op (default: phase summary only).",
    ),
    rescan: bool = typer.Option(
        True,
        "--rescan/--no-rescan",
        help=(
            "After a successful apply, run an incremental scan so the "
            "snapshot reflects the new state. The viewer auto-reloads when "
            "the snapshot advances."
        ),
    ),
):
    """Apply the current execution plan."""
    config = _get_config()
    from gdrive_organizer.ai.planner import (
        approved_plan_path,
        archive_approved_plan,
        load_plan,
        plan_source_label,
        resolve_plan_path,
    )
    from gdrive_organizer.auth.oauth import get_drive_service
    from gdrive_organizer.executor.runner import PlanRunner

    plan_path = resolve_plan_path(config, mode="latest" if latest_plan else "auto")
    if not plan_path:
        console.print("[yellow]No plan found.[/yellow]")
        raise typer.Exit(1)
    plan = load_plan(plan_path)

    console.print(plan_source_label(config, plan_path))
    console.print(f"Plan: {plan.stats.total_operations} operations")
    if not dry_run and not yes:
        confirm = typer.confirm("Apply this plan?")
        if not confirm:
            raise typer.Exit()

    service = get_drive_service(config) if not dry_run else None
    runner = PlanRunner(service, config)
    result = runner.execute(
        plan,
        dry_run=dry_run,
        skip_freshness_check=force,
        verbose=verbose,
    )

    if dry_run:
        n = result.success_count
        console.print(f"\n[dim]Dry run complete: {n} operations previewed.[/dim]")
    else:
        console.print(f"\n[green]Success: {result.success_count}[/green]")
        if result.failure_count:
            console.print(f"[red]Failed: {result.failure_count}[/red]")
        if result.skipped_count:
            console.print(
                f"[yellow]Skipped: {result.skipped_count}[/yellow] "
                f"[dim](not attempted — see message above)[/dim]"
            )
        if result.rollback_log_path:
            console.print(f"Rollback log: {result.rollback_log_path}")
            if plan_path == approved_plan_path(config) and not latest_plan:
                archived = archive_approved_plan(config, reason="applied")
                if archived:
                    console.print(f"Archived approved plan: {archived}")

        # Post-apply incremental scan: keep the snapshot in sync with Drive
        # so the viewer picks up the new state on its next request and the
        # next plan apply doesn't refer to ops that already happened.
        if rescan and result.success_count > 0:
            from gdrive_organizer.store.changelog import (
                ChangeTokenExpiredError,
                incremental_scan,
            )

            console.print("\n[cyan]Refreshing snapshot via incremental scan...[/cyan]")
            try:
                snapshot = incremental_scan(service, config)
                console.print(
                    f"[green]Snapshot refreshed.[/green] "
                    f"Files: {snapshot.stats.total_files} | "
                    f"Folders: {snapshot.stats.total_folders}"
                )
            except ChangeTokenExpiredError:
                console.print(
                    "[yellow]Auto-rescan skipped: change token expired. "
                    "Run 'gdrive-organizer scan' (full) when convenient.[/yellow]"
                )
            except Exception as e:  # noqa: BLE001 — auto-rescan must never abort the apply summary
                console.print(f"[yellow]Auto-rescan failed: {e}[/yellow]")


@plan_app.command("rollback")
def plan_rollback(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
):
    """Rollback the last applied plan."""
    config = _get_config()
    from gdrive_organizer.auth.oauth import get_drive_service
    from gdrive_organizer.executor.runner import PlanRunner

    logs_dir = config.data_dir / "logs"
    log_files = sorted(logs_dir.glob("rollback-*.json"), reverse=True)
    if not log_files:
        console.print("[yellow]No rollback log found.[/yellow]")
        raise typer.Exit(1)

    latest_log = log_files[0]
    console.print(f"Rolling back from: {latest_log.name}")
    if not yes:
        confirm = typer.confirm("Proceed with rollback?")
        if not confirm:
            raise typer.Exit()

    service = get_drive_service(config)
    runner = PlanRunner(service, config)
    result = runner.rollback(latest_log)

    console.print(f"[green]Rollback complete: {result.success_count} operations reversed.[/green]")
    if result.failure_count:
        console.print(f"[red]Failed: {result.failure_count}[/red]")
    if result.skipped_count:
        console.print(
            f"[yellow]Skipped: {result.skipped_count}[/yellow] "
            f"[dim](log lacked enough info to reverse — see warnings)[/dim]"
        )


# --- File content commands ---


@app.command("cat")
def cat_cmd(
    file_id: str = typer.Argument(help="File ID to read."),
):
    """Read file content as text (auto-exports Google Workspace files)."""
    config = _get_config()
    from gdrive_organizer.auth.oauth import get_drive_service
    from gdrive_organizer.scanner.content import get_file_metadata, read_file_content

    service = get_drive_service(config)
    meta = get_file_metadata(service, file_id)
    content = read_file_content(service, file_id, meta["mimeType"])

    if isinstance(content, str):
        console.print(content)
    else:
        console.print(
            f"[yellow]Binary file: {meta['name']} ({len(content)} bytes). "
            "Use 'export' command with --output instead.[/yellow]"
        )


@app.command("export")
def export_cmd(
    file_id: str = typer.Argument(help="File ID to export."),
    fmt: str = typer.Option("text", "--format", "-f", help="Export format."),
    output: Path | None = typer.Option(None, "--output", "-o", help="Output file."),
):
    """Export a file (supports Google Docs/Sheets/Slides)."""
    config = _get_config()
    from gdrive_organizer.auth.oauth import get_drive_service
    from gdrive_organizer.scanner.content import (
        download_file,
        export_file,
        get_file_metadata,
        is_exportable,
        resolve_export_mime,
    )

    service = get_drive_service(config)
    meta = get_file_metadata(service, file_id)
    mime = meta["mimeType"]

    if is_exportable(mime):
        export_mime = resolve_export_mime(fmt)
        data = export_file(service, file_id, export_mime)
    else:
        data = download_file(service, file_id)

    if output:
        output.write_bytes(data)
        console.print(f"[green]Exported to {output} ({len(data)} bytes)[/green]")
    elif fmt in ("text", "txt", "html", "csv"):
        console.print(data.decode("utf-8", errors="replace"))
    else:
        console.print(f"[yellow]Binary output ({len(data)} bytes). Use --output to save.[/yellow]")


# --- Create folder command ---


@app.command("create-folder")
def create_folder_cmd(
    name: str = typer.Argument(help="Folder name"),
    parent: str | None = typer.Option(None, "--parent", help="Parent folder ID."),
):
    """Create a new folder in Google Drive."""
    config = _get_config()
    from gdrive_organizer.auth.oauth import get_drive_service
    from gdrive_organizer.executor.batch import create_folder

    service = get_drive_service(config)
    result = create_folder(service, name, parent)
    console.print(f"[green]Created folder: {result['name']}[/green]")
    console.print(f"ID: {result['id']}")


# --- Helpers ---


def _format_size(size_bytes: int) -> str:
    """Format bytes to human-readable string."""
    if size_bytes == 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    size = float(size_bytes)
    while size >= 1024 and i < len(units) - 1:
        size /= 1024
        i += 1
    return f"{size:.1f} {units[i]}"
