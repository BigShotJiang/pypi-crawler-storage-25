"""AI-powered Google Drive organizer CLI."""

__version__ = "0.1.0-beta.7"
