Packaging and release-infrastructure update — no runtime code changes.

**What's new**

- **Homebrew**: install on macOS/Linux with a tap
  ```bash
  brew tap papa-channy/tap
  brew install gdrive-organizer
  ```
- **Tag-driven auto-release**: pushing a `v*` tag now runs lint + tests, verifies the tag matches the package version, builds sdist + wheel, publishes to PyPI via OIDC trusted publishing (no stored tokens), and attaches the artifacts to this GitHub release automatically. See `docs/RELEASING.md`.

**Note for users**

There are no functional changes since v0.1.0-beta.2. If you are already on beta.2 you can stay — upgrading only gets you the Homebrew-friendly sdist published through the new pipeline.

See [CHANGELOG.md](CHANGELOG.md) for the full list of changes.
