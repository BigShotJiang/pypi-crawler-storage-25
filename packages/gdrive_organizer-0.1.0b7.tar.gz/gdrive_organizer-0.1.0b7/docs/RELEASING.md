# Release Guide

How to publish a new version of gdrive-organizer.

After the one-time setup below, every release is just:

```bash
# 1. bump version in pyproject.toml + src/gdrive_organizer/__init__.py
# 2. write CHANGELOG entry + docs/release-notes-v<VERSION>.md
# 3. commit + push
# 4. tag + push tag — the Release workflow does the rest (PyPI + GH release)
git tag v0.1.0-beta.3
git push origin v0.1.0-beta.3
```

The `.github/workflows/release.yml` workflow runs on any `v*` tag and:
1. Verifies lint + tests pass
2. Verifies the tag matches the `pyproject.toml` version (guards against typos)
3. Builds sdist + wheel
4. Publishes to PyPI via **trusted publishing** (OIDC — no stored token)
5. Creates/updates the matching GitHub release and attaches the built artifacts

---

## One-time setup: PyPI trusted publishing

The release workflow uses PyPI's OIDC trusted publisher feature, so no API
token needs to live in GitHub secrets. Set this up once:

1. Go to https://pypi.org/manage/project/gdrive-organizer/settings/publishing/
2. Under **Trusted publishers**, add a **GitHub** publisher with:
   - **Owner**: `papa-channy`
   - **Repository name**: `google-drive-manager`
   - **Workflow name**: `release.yml`
   - **Environment name**: `pypi`
3. On GitHub, under **Settings → Environments**, create an environment named
   `pypi` (no secrets needed). Optionally add a required reviewer for extra
   safety so a human has to approve each release.

Once both sides know about each other, every tag push triggers a secure
publish with a short-lived OIDC token minted at runtime.

---

## Version Locations

Update the version string in **both** of these files before tagging:

1. `pyproject.toml` → `version`
2. `src/gdrive_organizer/__init__.py` → `__version__`

These must match. The workflow fails fast if the git tag doesn't match
`pyproject.toml`, catching typos before anything is published.

## Pre-Release Checklist

```bash
# 1. Ensure all tests pass locally
just check

# 2. Verify version strings match
grep '^version' pyproject.toml
grep '__version__' src/gdrive_organizer/__init__.py

# 3. Write CHANGELOG entry for this version in CHANGELOG.md

# 4. Write release notes at docs/release-notes-v<VERSION>.md
#    (used verbatim as the GitHub release body)

# 5. Clean working tree
git status
```

## Release

```bash
# Commit bump + notes
git add -A
git commit -m "chore(release): v0.1.0-beta.3"
git push origin main

# Tag + push — this fires the Release workflow
git tag v0.1.0-beta.3
git push origin v0.1.0-beta.3
```

Watch the run at https://github.com/papa-channy/google-drive-manager/actions.
When green, the new version is on PyPI and the GitHub release is live.

## Verify (recommended)

```bash
# In a fresh env
python -m venv /tmp/gdo-test
source /tmp/gdo-test/bin/activate
pip install gdrive-organizer==0.1.0b3
gdrive-organizer --version
deactivate && rm -rf /tmp/gdo-test
```

## Version Scheme

- `X.Y.Z-alpha.N` / `X.Y.Z-beta.N` / `X.Y.Z-rc.N` — pre-releases (marked as
  GitHub prerelease automatically based on tag)
- `X.Y.Z` — stable releases
- Follow [Semantic Versioning](https://semver.org/)

## Manual fallback

If the workflow is broken, you can still release manually — keep the steps
below as a break-glass reference.

```bash
uv build
uv publish --token <PyPI API token>
gh release create v0.1.0-beta.3 \
  --title "v0.1.0-beta.3" \
  --notes-file docs/release-notes-v0.1.0-beta.3.md \
  --prerelease
```
