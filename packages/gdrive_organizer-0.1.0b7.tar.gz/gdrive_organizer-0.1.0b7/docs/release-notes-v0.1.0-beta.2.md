Second public beta of gdrive-organizer. Feedback-driven polish on top of the v0.1.0-beta.1 foundation.

**What's new**

- **Plan Review gets real**: name search, bulk-action shortcuts (Select Safe Only / Deselect all TRASH), per-op approval for same-file ops, and character-level diff highlighting for rename/move targets
- **Approved subset, visible**: a banner surfaces the approved-plan.json state with a one-click Clear
- **Last-applied + rollback hint**: a panel shows the most recent applied plan with ok/failed counts and expandable per-op detail; the `plan rollback` command is copy-pasteable
- **Dashboard freshness**: "Last scan" and "Last classify" chips — or an orange CLI hint when a step hasn't been run yet
- **Offline viewer**: Lucide and Tailwind are vendored, no CDN dependency
- **Consistent empty states** across every page: icon + title + description + a copy-pasteable CLI command + hint

**Fixed**

- Same file_id with multiple operations can now be approved independently
- Plan Review selection state survives filter changes
- Settings correctly shows Expired / Not Connected for unhealthy tokens
- `typer[all]` extra warning on `pip install` — now uses plain `typer`

**Test infra**

- Playwright E2E suite added (`tests/e2e/`): 19 browser tests covering plan review interactions, approval flow, global search, dashboard chips, last-applied toggle
- Backend tests: 241 unit/integration passing

**Install**

```bash
pipx install gdrive-organizer==0.1.0b2
# or
pip install gdrive-organizer==0.1.0b2
```

See [CHANGELOG.md](CHANGELOG.md) for the full list of changes.
