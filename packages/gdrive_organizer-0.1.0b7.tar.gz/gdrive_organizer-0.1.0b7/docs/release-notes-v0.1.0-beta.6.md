A second dogfood pass on the same 1500-file Drive surfaced two new data-integrity defects and four planner / classify improvements. This release ships all of them, plus a 13× speedup on classify.

**Fixed**

- **#J5 — Apply refuses to write into a trashed parent.** A previous `plan rollback` could leave folder Drive IDs in the snapshot whose `trashed` flag is now `true`; the next classify resolved a destination path to one of those IDs and Phase 2 quietly moved files into an invisible parent. The runner now batch-fetches `trashed` for every real destination parent the plan references and aborts with a clear "re-scan and re-classify" message.
- **#J6 — Scanner re-parents orphans whose folder is in trash.** Drive's `q=trashed=false` returns a file whose own `trashed=false` even if its parent was trashed; the file ended up silently re-rooted in `build_tree` and never flagged as needing organization. The scanner now detects these orphans, confirms the parent is trashed via `files.get`, and clears `parents=[]` so the file surfaces at My Drive root.
- **#J1 — Planner excludes `ownedByMe=False` files.** 7 of 15 Stage-1 apply failures were shared-from-others files Drive refuses to move.
- **#J2 — Planner skips `mimeType=shortcut` files** as classification candidates. Shortcut-of-shortcut chains are rejected by Drive.
- **#J4 — Conflict resolution renames instead of dropping.** Files with name collisions used to be dropped silently and stranded at root forever; they now get a `(2)`, `(3)`, ... suffix so every file lands somewhere.

**Changed**

- **Classify is ~13× faster** (14 min → 1 min 35 s on a 1500-file Drive). LLM batches now run in parallel via `asyncio.gather`, throttled by the existing `Semaphore(MAX_CONCURRENT=10)` in the client.
- **AI-managed folders are prefixed with `🪄 AI 정리`** so they're visually distinct from any existing `보관함/` tree the user already maintained.

**Upgrade**

```bash
brew upgrade gdrive-organizer        # macOS / Linux
pipx upgrade gdrive-organizer        # platform-agnostic
```

See [CHANGELOG.md](CHANGELOG.md) for the full list of changes.
