A same-day workflow-friction fix on top of v0.1.0-beta.6. Both defects always required manual intervention after every apply, so this release goes out separately for visibility.

**Fixed**

- **#J3 — Viewer auto-reloads when the snapshot advances.** The viewer cached the snapshot at startup and never re-read it, so a CLI scan had no effect on the running server until the user killed and re-started it. `SnapshotCache` now tracks the latest-snapshot file's mtime and invalidates the next time the file changes. The first request after a scan transparently reloads.

**Added**

- **`plan apply --rescan` (default on).** After a successful apply, the runner invokes `incremental_scan` so the snapshot reflects the just-applied state. Without this, the next plan and the viewer's tree both lied about what was actually in Drive. Pass `--no-rescan` to opt out; auto-rescan failures degrade to a yellow note instead of aborting the apply summary.

**Workflow now collapses to**

```
gdrive-organizer plan apply -y    # auto-rescans on success
F5 in browser                     # viewer is already fresh
```

**Upgrade**

```bash
brew upgrade gdrive-organizer        # macOS / Linux
pipx upgrade gdrive-organizer        # platform-agnostic
```

See [CHANGELOG.md](CHANGELOG.md) for the full list of changes.
