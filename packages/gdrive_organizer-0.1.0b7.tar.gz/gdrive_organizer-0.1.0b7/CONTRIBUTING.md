# Contributing to gdrive-organizer

Thank you for considering a contribution. This document covers the basics.

## Development Setup

```bash
git clone https://github.com/papa-channy/google-drive-manager.git
cd google-drive-manager
uv sync --all-extras
```

Requires Python 3.12+ and [uv](https://docs.astral.sh/uv/).

## Task Runner

The project uses [just](https://github.com/casey/just) as a task runner. Run `just` to see all available commands.

```bash
just test          # Run pytest (unit + integration; excludes E2E)
just lint          # Lint with ruff
just fmt           # Format with ruff
just check         # lint + format + test
just start         # Start viewer in background (port 8765)
just stop          # Stop viewer
```

### Browser E2E tests

The viewer has a small Playwright test suite that drives a real browser against
an in-process live server. These tests catch regressions that backend tests
cannot (checkbox state, per-op approval wiring, navigation).

```bash
just e2e-setup     # one-time: install chromium (~150MB)
just e2e           # run the E2E suite (~5s on chromium)
```

E2E tests live in `tests/e2e/` and are excluded from the default `pytest`
collection — they are opt-in via `just e2e`.

## Code Quality

Before submitting a PR:

```bash
just check         # Must pass: lint + format + test
```

The project enforces:
- **ruff** for linting and formatting
- **pytest** with pytest-asyncio for tests

CI runs the same checks via GitHub Actions on push and PR.

## Commit Messages

Follow the conventional format:

```
feat|fix|docs|test|refactor(module): short description
```

Examples:
- `feat(scanner): add incremental sync via Changes API`
- `fix(executor): correct rollback ordering for nested moves`
- `docs(readme): update install instructions`

## Pull Requests

1. Create a feature branch from `main`
2. Make your changes
3. Run `just check` locally
4. Open a PR with:
   - A clear title (under 70 characters)
   - Description of what changed and why
   - How to test the change

## Good First Contribution Areas

- Performance benchmarks at larger Drive sizes
- Viewer UI polish
- Packaging improvements (Homebrew formula, etc.)
- Documentation and usage examples
- Test coverage for edge cases
- CI/CD improvements

## Reporting Bugs

Open an issue with:
- Platform and Python version
- Install method (`uv sync`, `pip`, etc.)
- Command you ran
- Expected vs actual behavior
- Sanitized logs or error output

## Project Layout

```
src/gdrive_organizer/
  cli.py              # Typer CLI entry point
  config.py           # Pydantic Settings
  auth/               # Google OAuth flow
  scanner/            # Flat crawl, tree, permissions
  store/              # Snapshot, Changes API
  ai/                 # xAI classifier, namer, planner
  executor/           # Batch API, rate limiter, rollback
  viewer/             # FastAPI local dashboard
  utils/              # Retry, logging
tests/                # pytest test suite
docs/                 # Architecture docs, user guide
```

## License

By contributing, you agree that your contributions will be licensed under the [Apache License 2.0](LICENSE).
