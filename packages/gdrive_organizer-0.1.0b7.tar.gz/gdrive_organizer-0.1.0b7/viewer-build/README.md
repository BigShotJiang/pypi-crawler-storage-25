# Viewer CSS build

Builds the production Tailwind CSS bundle for the FastAPI viewer.

The compiled output is committed at
`src/gdrive_organizer/viewer/static/vendor/tailwind.css`, so end users do **not**
need Node installed — only contributors who change templates/JS that introduce
new utility classes.

## When to rebuild

Re-run the build whenever you add new Tailwind classes in:

- `src/gdrive_organizer/viewer/templates/**/*.html`
- `src/gdrive_organizer/viewer/static/**/*.js`

## How

```bash
cd viewer-build
npm install
npm run build      # one-shot minified build
npm run watch      # dev watcher
```

Then commit the regenerated `src/gdrive_organizer/viewer/static/vendor/tailwind.css`.

## Why this layout

- `viewer-build/` is sibling to `src/`, not inside it — keeps `node_modules`
  out of the published Python package.
- `tailwindcss-browser.js` (the JIT runtime that prints a "do not use in
  production" warning on every page load) was removed in favor of this
  proper build pipeline (#13 from the dogfooding audit).
