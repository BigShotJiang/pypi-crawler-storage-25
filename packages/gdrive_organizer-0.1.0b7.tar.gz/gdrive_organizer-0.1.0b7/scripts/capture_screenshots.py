"""Capture viewer screenshots into docs/assets/ using synthetic data.

Run:
    uv run python scripts/capture_screenshots.py

What it does:
    1. Builds a temp config with a realistic-looking fake snapshot, plan,
       approved-plan.json, and rollback log.
    2. Starts the viewer on a free port in a background thread.
    3. Uses Playwright (chromium) to navigate each key page and write a PNG.
    4. Writes to <repo-root>/docs/assets/.

Privacy note: this uses synthetic data, not the maintainer's real Drive, so the
resulting PNGs are safe to commit.

Regenerating: after viewer UI changes, re-run this script to refresh the PNGs.
"""

from __future__ import annotations

import socket
import tempfile
import threading
import time
from datetime import UTC, datetime
from pathlib import Path

import uvicorn
from playwright.sync_api import sync_playwright

import json as _json

from gdrive_organizer.config import Config
from gdrive_organizer.store.snapshot import save_snapshot
from gdrive_organizer.viewer.app import create_app

REPO_ROOT = Path(__file__).resolve().parent.parent
ASSETS_DIR = REPO_ROOT / "docs" / "assets"
VIEWPORT = {"width": 1440, "height": 900}

ROOT_ID = "root"
FOLDER_MIME = "application/vnd.google-apps.folder"
GDOC_MIME = "application/vnd.google-apps.document"
GSHEET_MIME = "application/vnd.google-apps.spreadsheet"


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class _ThreadedUvicorn(uvicorn.Server):
    def install_signal_handlers(self):  # noqa: D401
        pass


def _folder(fid: str, name: str, parent: str) -> dict:
    return {
        "id": fid,
        "name": name,
        "mimeType": FOLDER_MIME,
        "parents": [parent] if parent else [],
        "size": "0",
        "createdTime": "2025-10-01T09:00:00Z",
        "modifiedTime": "2026-04-10T09:00:00Z",
        "ownedByMe": True,
    }


def _file(fid: str, name: str, parent: str, mime: str, size: int, **extra) -> dict:
    base = {
        "id": fid,
        "name": name,
        "mimeType": mime,
        "parents": [parent],
        "size": str(size),
        "createdTime": "2025-11-15T12:00:00Z",
        "modifiedTime": "2026-04-08T14:30:00Z",
        "ownedByMe": True,
    }
    base.update(extra)
    return base


def _build_synthetic_files() -> list[dict]:
    files: list[dict] = [_folder(ROOT_ID, "My Drive", "")]
    for fid, name, parent in [
        ("f_work", "Work", ROOT_ID),
        ("f_personal", "Personal", ROOT_ID),
        ("f_projects", "Projects", "f_work"),
        ("f_reports", "Reports", "f_work"),
        ("f_photos", "Photos", "f_personal"),
        ("f_archive", "Archive", ROOT_ID),
        ("f_ideas", "Ideas", ROOT_ID),
    ]:
        files.append(_folder(fid, name, parent))

    # (id, name, parent, mime, size, **extra)
    plain: list[tuple[str, str, str, str, int]] = [
        ("d_q1", "Q1 2026 Report.gdoc", "f_reports", GDOC_MIME, 0),
        ("d_q2", "Q2 2026 Planning.gdoc", "f_reports", GDOC_MIME, 0),
        ("d_budget", "Budget Tracker 2026.gsheet", "f_reports", GSHEET_MIME, 0),
        ("d_roadmap", "Roadmap.gdoc", "f_projects", GDOC_MIME, 0),
        ("d_specA", "Project A Spec.gdoc", "f_projects", GDOC_MIME, 0),
        ("d_specB", "Project B Spec.gdoc", "f_projects", GDOC_MIME, 0),
        ("d_meeting", "meeting notes.gdoc", "f_projects", GDOC_MIME, 0),
        ("d_slides", "Kickoff Deck.pdf", "f_projects", "application/pdf", 2_400_000),
        ("p_resume", "Resume_v3.pdf", "f_personal", "application/pdf", 180_000),
        ("p_taxes", "taxes_2025.pdf", "f_personal", "application/pdf", 3_200_000),
        ("p_notes", "journal.txt", "f_personal", "text/plain", 12_000),
        ("ph1", "IMG_2847.jpg", "f_photos", "image/jpeg", 3_800_000),
        ("ph2", "IMG_2848.jpg", "f_photos", "image/jpeg", 4_100_000),
        ("ph3", "IMG_2849.jpg", "f_photos", "image/jpeg", 3_600_000),
        ("ph4", "screenshot.png", "f_photos", "image/png", 890_000),
        ("a1", "Untitled document.gdoc", "f_archive", GDOC_MIME, 0),
        ("a2", "Copy of invoice.pdf", "f_archive", "application/pdf", 210_000),
        ("a3", "old_backup.zip", "f_archive", "application/zip", 48_000_000),
        ("i1", "startup idea.txt", "f_ideas", "text/plain", 4_800),
        ("i2", "book list.gdoc", "f_ideas", GDOC_MIME, 0),
    ]
    for fid, name, parent, mime, size in plain:
        files.append(_file(fid, name, parent, mime, size))

    # Duplicate pair (same md5) to populate /duplicates
    files.append(
        _file("dup1", "report.pdf", "f_reports", "application/pdf", 520_000, md5Checksum="abc123")
    )
    files.append(
        _file(
            "dup2", "report (1).pdf", "f_archive", "application/pdf", 520_000, md5Checksum="abc123"
        )
    )
    # A public file to populate /permissions
    files.append(
        _file(
            "pub1",
            "shared-link.pdf",
            ROOT_ID,
            "application/pdf",
            150_000,
            shared=True,
            permissions=[{"id": "anyoneWithLink", "type": "anyone", "role": "reader"}],
        )
    )
    return files


def _build_plan() -> dict:
    return {
        "created_at": "2026-04-12T11:30:00Z",
        "operations": [
            {
                "file_id": "d_meeting",
                "current_name": "meeting notes.gdoc",
                "current_path": "/Work/Projects/meeting notes.gdoc",
                "operation": "rename",
                "new_name": "2026-04-08 Project A Kickoff Notes.gdoc",
                "reason": "Add date prefix and specify project for better archival retrieval.",
            },
            {
                "file_id": "a1",
                "current_name": "Untitled document.gdoc",
                "current_path": "/Archive/Untitled document.gdoc",
                "operation": "rename",
                "new_name": "2025-09-15 Research Notes.gdoc",
                "reason": "Replace generic 'Untitled' with detected topic from content.",
            },
            {
                "file_id": "a2",
                "current_name": "Copy of invoice.pdf",
                "current_path": "/Archive/Copy of invoice.pdf",
                "operation": "rename_and_move",
                "new_name": "2025-12 Invoice AWS.pdf",
                "new_path": "/Personal/Receipts/2025-12 Invoice AWS.pdf",
                "reason": "Remove 'Copy of' and move to Receipts folder by detected vendor.",
            },
            {
                "file_id": "d_q1",
                "current_name": "Q1 2026 Report.gdoc",
                "current_path": "/Work/Reports/Q1 2026 Report.gdoc",
                "operation": "move",
                "new_path": "/Work/Reports/2026/Q1 2026 Report.gdoc",
                "reason": "Organize reports by year.",
            },
            {
                "file_id": "d_q2",
                "current_name": "Q2 2026 Planning.gdoc",
                "current_path": "/Work/Reports/Q2 2026 Planning.gdoc",
                "operation": "move",
                "new_path": "/Work/Reports/2026/Q2 2026 Planning.gdoc",
                "reason": "Organize reports by year.",
            },
            {
                "file_id": "i1",
                "current_name": "startup idea.txt",
                "current_path": "/Ideas/startup idea.txt",
                "operation": "rename",
                "new_name": "2026-03 Startup Idea — Personal Finance.txt",
                "reason": "Date prefix + topic tag detected from content.",
            },
            {
                "file_id": "dup2",
                "current_name": "report (1).pdf",
                "current_path": "/Archive/report (1).pdf",
                "operation": "trash",
                "reason": "Duplicate of /Work/Reports/report.pdf (MD5 match).",
            },
            {
                "file_id": "create_receipts",
                "current_name": "Receipts",
                "current_path": "/Personal/Receipts",
                "operation": "create_folder",
                "reason": "Target folder for renamed invoices.",
            },
            {
                "file_id": "create_2026",
                "current_name": "2026",
                "current_path": "/Work/Reports/2026",
                "operation": "create_folder",
                "reason": "Year-based archive folder.",
            },
        ],
        "stats": {"total_operations": 9},
    }


def _build_approved_plan() -> dict:
    """A subset (3 ops) that the user already approved in a previous session."""
    return {
        "created_at": "2026-04-12T11:30:00Z",
        "operations": [
            {
                "file_id": "d_q1",
                "current_name": "Q1 2026 Report.gdoc",
                "current_path": "/Work/Reports/Q1 2026 Report.gdoc",
                "operation": "move",
                "new_path": "/Work/Reports/2026/Q1 2026 Report.gdoc",
            },
            {
                "file_id": "d_q2",
                "current_name": "Q2 2026 Planning.gdoc",
                "current_path": "/Work/Reports/Q2 2026 Planning.gdoc",
                "operation": "move",
                "new_path": "/Work/Reports/2026/Q2 2026 Planning.gdoc",
            },
            {
                "file_id": "create_2026",
                "current_name": "2026",
                "current_path": "/Work/Reports/2026",
                "operation": "create_folder",
            },
        ],
        "stats": {"total_operations": 3},
    }


def _build_rollback_log() -> dict:
    return {
        "executedAt": "2026-04-10T15:20:00+00:00",
        "planRef": "2026-04-10T15:19:30",
        "id_mapping": {},
        "operations": [
            {"fileId": "ph1", "type": "move", "before": {}, "after": {}, "status": "ok"},
            {"fileId": "ph2", "type": "move", "before": {}, "after": {}, "status": "ok"},
            {"fileId": "ph3", "type": "move", "before": {}, "after": {}, "status": "ok"},
            {"fileId": "ph4", "type": "rename", "before": {}, "after": {}, "status": "ok"},
        ],
    }


def _seed(config: Config) -> None:
    save_snapshot(
        _build_synthetic_files(),
        "demo_change_token",
        config,
        drive_info_data={
            "user_name": "Demo User",
            "user_email": "demo@example.com",
            "storage_limit": 15 * 1024**3,
            "storage_used": int(1.2 * 1024**3),
            "storage_in_drive": int(1.1 * 1024**3),
            "storage_in_trash": int(0.1 * 1024**3),
        },
    )
    plans = config.data_dir / "plans"
    plans.mkdir(parents=True, exist_ok=True)
    (plans / "plan-2026-04-12T11-30-00.json").write_text(_json.dumps(_build_plan()))
    (plans / "approved-plan.json").write_text(_json.dumps(_build_approved_plan()))
    logs = config.data_dir / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    (logs / "rollback-2026-04-10T15-20-00.json").write_text(_json.dumps(_build_rollback_log()))


def _start_server(config: Config) -> tuple[str, _ThreadedUvicorn, threading.Thread]:
    port = _free_port()
    app = create_app(config)
    ucfg = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning", access_log=False)
    server = _ThreadedUvicorn(config=ucfg)
    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()
    deadline = time.monotonic() + 5.0
    while time.monotonic() < deadline:
        if server.started:
            break
        time.sleep(0.05)
    else:
        raise RuntimeError("server failed to start")
    return f"http://127.0.0.1:{port}", server, thread


def _capture(base_url: str) -> None:
    ASSETS_DIR.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        context = browser.new_context(
            viewport=VIEWPORT, device_scale_factor=2, color_scheme="light"
        )
        page = context.new_page()

        def _shot(path: str, filename: str, wait_ms: int = 900, prep=None) -> None:
            page.goto(f"{base_url}{path}", wait_until="networkidle")
            page.wait_for_timeout(wait_ms)
            if prep is not None:
                prep()
                page.wait_for_timeout(500)
            out = ASSETS_DIR / filename
            page.screenshot(path=str(out), full_page=False)
            print(f"captured {path} -> docs/assets/{filename}")

        _shot("/", "viewer-dashboard.png", 900)
        _shot("/plan", "viewer-plan.png", 1200)

        def _expand_tree():
            # Click the root node's toggle to reveal children, then open Work
            root = page.locator(".tree-item").first
            root.click()
            page.wait_for_timeout(400)
            # Try to open one sub-folder to make the tree feel alive
            try:
                work = page.get_by_text("Work", exact=True).first
                work.click(timeout=1000)
            except Exception:
                pass

        _shot("/explorer", "viewer-explorer.png", 900, prep=_expand_tree)
        _shot("/permissions", "viewer-permissions.png", 700)
        context.close()
        browser.close()


def main() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)
        config = Config(data_dir=tmp_path, config_dir=tmp_path / "config")
        for sub in ("plans", "snapshots", "logs"):
            (tmp_path / sub).mkdir(parents=True, exist_ok=True)
        config.config_dir.mkdir(parents=True, exist_ok=True)
        _seed(config)
        base_url, server, thread = _start_server(config)
        try:
            _capture(base_url)
        finally:
            server.should_exit = True
            thread.join(timeout=5)


if __name__ == "__main__":
    main()
