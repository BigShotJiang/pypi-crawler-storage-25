from __future__ import annotations

import hashlib
import re
import time
from typing import Any, Dict, List, Optional, Set


INJECTION_PATTERNS = [
    re.compile(r"(?i)ignore\s+(all\s+)?(previous|prior)\s+instructions"),
    re.compile(r"(?i)you\s+are\s+now\s+(in\s+)?(developer|admin|root)\s+mode"),
    re.compile(r"(?i)<<<PREFIX"),
    re.compile(r"(?i)disable\s+circuit\s+breaker"),
    re.compile(r"(?i)\.env\b|/etc/passwd|api[_-]?key"),
]

STRIP_CONTEXT_KEYS = frozenset({
    "discord_raw", "credentials", "stack_trace", "network", "optimizer",
})


class PromptGuard:
    """
    Implements non-bypassable guard filtering for prompt inputs, context sanitization,
    tool budgets, loop detection, and safe formatting.
    """

    def __init__(
        self,
        max_tool_calls_per_turn: int = 12,
        max_wall_time_sec: float = 45.0,
        max_duplicate_tool: int = 2
    ):
        self.max_tool_calls = max_tool_calls_per_turn
        self.max_wall_time = max_wall_time_sec
        self.max_duplicate_tool = max_duplicate_tool
        self._turn_start = 0.0
        self._calls: List[dict] = []
        self._simhashes: List[str] = []

    def start_turn(self) -> None:
        self._turn_start = time.time()
        self._calls.clear()

    def sanitize_context(self, context: dict | None) -> dict:
        if not context:
            return {}
        clean = {}
        for k, v in context.items():
            if k.startswith("_") and k not in ("_intermod", "_intermod_from", "_intermod_depth"):
                continue
            if k in STRIP_CONTEXT_KEYS:
                continue
            clean[k] = v
        return clean

    def score_injection(self, prompt: str) -> float:
        hits = sum(1 for p in INJECTION_PATTERNS if p.search(prompt))
        return min(1.0, hits * 0.35)

    def normalize_prompt(self, prompt: str) -> str:
        p = prompt.replace("\r\n", "\n").replace("\r", "\n")
        p = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", p)
        return p[:8192]

    def check_tool_call(self, tool: str, args: dict) -> str | None:
        if time.time() - self._turn_start > self.max_wall_time:
            return "wall_time_exceeded"
        if len(self._calls) >= self.max_tool_calls:
            return "tool_budget_exceeded"
            
        ah = hashlib.sha256(repr(sorted(args.items())).encode()).hexdigest()[:16]
        dup = sum(1 for c in self._calls if c["tool"] == tool and c["args_hash"] == ah)
        if dup >= self.max_duplicate_tool:
            return "duplicate_tool_call"
            
        sim = hashlib.sha256(f"{tool}:{ah}".encode()).hexdigest()[:12]
        if sim in self._simhashes and dup == 0:
            return "tool_loop_simhash"
            
        self._simhashes.append(sim)
        if len(self._simhashes) > 8:
            self._simhashes.pop(0)
            
        self._calls.append({"tool": tool, "args_hash": ah, "ts": time.time()})
        return None

    def wrap_untrusted_tool_result(self, tool: str, result: str) -> str:
        """Escapes raw tool output to prevent downstream instruction smuggling."""
        escaped = result.replace("<<<", "＜＜＜")
        return (
            f"<tool_result tool={tool} trust=untrusted>\n"
            f"{escaped[:16000]}\n"
            f"</tool_result>"
        )


def sanitize_federation_import(payload: dict) -> dict:
    """
    Safeguards against prototype pollution and removes disallowed key patterns
    such as those starting with double underscores or matching '__proto__'.
    """
    if not isinstance(payload, dict):
        return payload

    clean = {}
    for k, v in payload.items():
        if k == "__proto__" or k == "constructor" or k == "prototype":
            continue
        
        # Remove prefix underscores
        clean_key = k.lstrip("_")
        if not clean_key:
            continue

        if isinstance(v, dict):
            clean[clean_key] = sanitize_federation_import(v)
        elif isinstance(v, list):
            clean[clean_key] = [
                sanitize_federation_import(item) if isinstance(item, dict) else item
                for item in v
            ]
        else:
            clean[clean_key] = v
            
    return clean
