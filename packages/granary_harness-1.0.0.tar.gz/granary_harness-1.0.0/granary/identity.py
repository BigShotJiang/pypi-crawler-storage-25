from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional
from uuid import uuid4


@dataclass(slots=True)
class AgentProvenance:
    repository: str
    branch: str
    commit_sha: str


@dataclass(slots=True)
class AgentActClaim:
    sub: str
    iss: str
    provenance: AgentProvenance


@dataclass(slots=True)
class TaskContext:
    task_id: str
    parent_session_id: str
    max_blast_radius: str


@dataclass(slots=True)
class MayActClaim:
    client_id: str
    allowed_resource_indicators: List[str] = field(default_factory=list)


@dataclass(slots=True)
class AgentAssertionToken:
    """
    Canonical claim schema for Granary's Agent Assertion Token (AAT).
    """

    iss: str
    sub: str
    aud: str
    exp: int
    nbf: int
    iat: int
    jti: str
    act: AgentActClaim
    task_context: TaskContext
    may_act: MayActClaim
    agent_owner: Optional[str] = None
    agent_trust_score: Optional[float] = None

    @classmethod
    def create(
        cls,
        *,
        issuer: str,
        subject: str,
        audience: str,
        agent_id: str,
        repository: str,
        branch: str,
        commit_sha: str,
        task_id: str,
        parent_session_id: str,
        max_blast_radius: str,
        client_id: str,
        allowed_resources: List[str],
        lifetime_seconds: int = 300,
        now: Optional[datetime] = None,
        agent_owner: Optional[str] = None,
        agent_trust_score: Optional[float] = None,
    ) -> "AgentAssertionToken":
        now_dt = now or datetime.now(timezone.utc)
        iat = int(now_dt.timestamp())
        return cls(
            iss=issuer,
            sub=subject,
            aud=audience,
            exp=iat + lifetime_seconds,
            nbf=iat,
            iat=iat,
            jti=f"aat_{uuid4()}",
            act=AgentActClaim(
                sub=agent_id,
                iss=issuer,
                provenance=AgentProvenance(
                    repository=repository,
                    branch=branch,
                    commit_sha=commit_sha,
                ),
            ),
            task_context=TaskContext(
                task_id=task_id,
                parent_session_id=parent_session_id,
                max_blast_radius=max_blast_radius,
            ),
            may_act=MayActClaim(
                client_id=client_id,
                allowed_resource_indicators=allowed_resources,
            ),
            agent_owner=agent_owner,
            agent_trust_score=agent_trust_score,
        )

    def to_payload(self) -> Dict[str, object]:
        payload = {
            "iss": self.iss,
            "sub": self.sub,
            "aud": self.aud,
            "exp": self.exp,
            "nbf": self.nbf,
            "iat": self.iat,
            "jti": self.jti,
            "act": {
                "sub": self.act.sub,
                "iss": self.act.iss,
                "provenance": {
                    "repository": self.act.provenance.repository,
                    "branch": self.act.provenance.branch,
                    "commit_sha": self.act.provenance.commit_sha,
                },
            },
            "task_context": {
                "task_id": self.task_context.task_id,
                "parent_session_id": self.task_context.parent_session_id,
                "max_blast_radius": self.task_context.max_blast_radius,
            },
            "may_act": {
                "client_id": self.may_act.client_id,
                "allowed_resource_indicators": list(self.may_act.allowed_resource_indicators),
            },
        }
        if self.agent_owner is not None:
            payload["agent_owner"] = self.agent_owner
        if self.agent_trust_score is not None:
            payload["agent_trust_score"] = self.agent_trust_score
        return payload

    def validate_for_exchange(self, resource: str) -> None:
        now_ts = int(datetime.now(timezone.utc).timestamp())
        if self.nbf > now_ts:
            raise ValueError("AAT is not yet valid (nbf in future)")
        if self.exp <= now_ts:
            raise ValueError("AAT is expired")
        if resource not in self.may_act.allowed_resource_indicators:
            raise ValueError(f"Resource not allowed by may_act: {resource}")

    def generate_signature(self, secret: str) -> str:
        """
        Generates a cryptographic HMAC-SHA256 signature of the token payload.
        """
        import hmac
        import hashlib
        import json
        payload = self.to_payload()
        serialized = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hmac.new(secret.encode("utf-8"), serialized, hashlib.sha256).hexdigest()

    def verify_signature(self, signature: str, secret: str) -> bool:
        """
        Cryptographically verifies the token signature.
        """
        import hmac
        expected = self.generate_signature(secret)
        return hmac.compare_digest(signature, expected)

    def generate_dpop_proof(self, http_method: str, http_uri: str, secret: str, now: Optional[datetime] = None) -> Dict[str, str]:
        """
        Generates an RFC 9449 DPoP proof payload binding the token to an HTTP request context.
        """
        import hmac
        import hashlib
        import json
        now_dt = now or datetime.now(timezone.utc)
        iat = int(now_dt.timestamp())
        proof_payload = {
            "htm": http_method.upper(),
            "htu": http_uri,
            "iat": iat,
            "jti": f"dpop_{uuid4()}",
            "ath": hashlib.sha256(self.jti.encode("utf-8")).hexdigest(),
        }
        serialized = json.dumps(proof_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        signature = hmac.new(secret.encode("utf-8"), serialized, hashlib.sha256).hexdigest()
        return {
            "proof_payload": json.dumps(proof_payload),
            "signature": signature,
        }

    def validate_dpop_proof(
        self,
        proof: Dict[str, str],
        http_method: str,
        http_uri: str,
        secret: str,
        now: Optional[datetime] = None,
        max_skew_seconds: int = 300,
    ) -> bool:
        """
        Validates an RFC 9449 DPoP proof, ensuring method/URI matching and cryptographically checking signature.
        """
        import hmac
        import hashlib
        import json
        
        sig = proof.get("signature")
        raw_payload = proof.get("proof_payload")
        if not sig or not raw_payload:
            return False
            
        try:
            proof_payload = json.loads(raw_payload)
        except json.JSONDecodeError:
            return False
            
        # 1. Cryptographic signature check
        serialized = json.dumps(proof_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        expected_sig = hmac.new(secret.encode("utf-8"), serialized, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected_sig):
            return False
            
        # 2. Match request context
        if proof_payload.get("htm") != http_method.upper():
            return False
        if proof_payload.get("htu") != http_uri:
            return False
            
        # 3. Check JTI bound association
        expected_ath = hashlib.sha256(self.jti.encode("utf-8")).hexdigest()
        if proof_payload.get("ath") != expected_ath:
            return False
            
        # 4. Check time skew
        now_dt = now or datetime.now(timezone.utc)
        now_ts = int(now_dt.timestamp())
        proof_iat = proof_payload.get("iat", 0)
        if abs(now_ts - proof_iat) > max_skew_seconds:
            return False
            
        return True


@dataclass(slots=True)
class TokenExchangeRequest:
    """
    RFC 8693-compliant token exchange payload.
    """

    grant_type: str
    resource: str
    audience: str
    scope: str
    requested_token_type: str
    subject_token: str
    subject_token_type: str
    actor_token: str
    actor_token_type: str

    def to_json(self) -> Dict[str, str]:
        return {
            "grant_type": self.grant_type,
            "resource": self.resource,
            "audience": self.audience,
            "scope": self.scope,
            "requested_token_type": self.requested_token_type,
            "subject_token": self.subject_token,
            "subject_token_type": self.subject_token_type,
            "actor_token": self.actor_token,
            "actor_token_type": self.actor_token_type,
        }


def build_token_exchange_request(
    *,
    subject_token_jwt: str,
    actor_token_jwt: str,
    resource: str,
    audience: str,
    scope: str,
) -> TokenExchangeRequest:
    return TokenExchangeRequest(
        grant_type="urn:ietf:params:oauth:grant-type:token-exchange",
        resource=resource,
        audience=audience,
        scope=scope,
        requested_token_type="urn:ietf:params:oauth:token-type:access_token",
        subject_token=subject_token_jwt,
        subject_token_type="urn:ietf:params:oauth:token-type:jwt",
        actor_token=actor_token_jwt,
        actor_token_type="urn:ietf:params:oauth:token-type:jwt",
    )
