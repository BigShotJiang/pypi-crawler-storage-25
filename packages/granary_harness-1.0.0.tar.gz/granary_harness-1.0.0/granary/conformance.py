from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple


class ProviderTier(str, Enum):
    VERIFIED = "verified"
    LIMITED = "limited"
    EXPERIMENTAL = "experimental"


@dataclass(slots=True)
class ConformanceScore:
    tool_calling_passed: bool = False
    structured_output_passed: bool = False
    streaming_order_passed: bool = False
    strict_mode_passed: bool = False

    def is_fully_conforming(self) -> bool:
        return (
            self.tool_calling_passed
            and self.structured_output_passed
            and self.streaming_order_passed
            and self.strict_mode_passed
        )


@dataclass(slots=True)
class ProviderRecord:
    provider_name: str
    model_name: str
    version: str
    tier: ProviderTier
    score: ConformanceScore
    last_certified_at: float = field(default_factory=time.time)
    drift_alerts_count: int = 0


class ConformanceManager:
    """
    Implements automated provider conformance testing, tiering policies,
    and continuous re-certification triggers.
    """

    def __init__(self) -> None:
        self.registry: Dict[Tuple[str, str], ProviderRecord] = {}

    def register_provider(
        self,
        *,
        provider_name: str,
        model_name: str,
        version: str,
        score: ConformanceScore,
    ) -> ProviderRecord:
        """
        Runs the tiering policy to classify and register the provider based on its conformance score.
        """
        tier = self._determine_tier(score)
        record = ProviderRecord(
            provider_name=provider_name,
            model_name=model_name,
            version=version,
            tier=tier,
            score=score,
        )
        self.registry[(provider_name, model_name)] = record
        return record

    def trigger_recertification(self, provider_name: str, model_name: str, reason: str) -> Optional[ProviderRecord]:
        """
        Triggers continuous re-certification on version drift, upgrades, or prediction drift alerts.
        """
        record = self.registry.get((provider_name, model_name))
        if not record:
            return None

        # Reset score, force re-evaluation
        record.score = ConformanceScore()
        record.tier = ProviderTier.EXPERIMENTAL
        record.last_certified_at = time.time()
        record.drift_alerts_count += 1
        return record

    def run_automated_conformance_battery(
        self,
        *,
        tool_calling_output: dict,
        structured_json_output: dict,
        streaming_chunks: List[dict],
        schema_arguments: dict,
    ) -> ConformanceScore:
        """
        Evaluates a BYOK/BYOM provider's feature compliance across four criteria.
        """
        score = ConformanceScore()

        # 1. Tool-Calling validation
        if "tool_calls" in tool_calling_output:
            calls = tool_calling_output["tool_calls"]
            if isinstance(calls, list) and len(calls) >= 1:
                if all("name" in c and "arguments" in c for c in calls):
                    score.tool_calling_passed = True

        # 2. Structured Output validation
        if "result" in structured_json_output and isinstance(structured_json_output["result"], dict):
            score.structured_output_passed = True

        # 3. Streaming Event Order and completion invariants
        if streaming_chunks:
            # First chunk must contain metadata/start, last chunk must be completion
            has_start = streaming_chunks[0].get("event") == "start"
            has_done = streaming_chunks[-1].get("event") == "done"
            is_monotonic = all(
                streaming_chunks[i]["seq"] < streaming_chunks[i+1]["seq"]
                for i in range(len(streaming_chunks) - 1)
            )
            if has_start and has_done and is_monotonic:
                score.streaming_order_passed = True

        # 4. Strict Mode Argument validation
        # Ensure schema_arguments has matching type alignments
        if "strict" in schema_arguments and schema_arguments["strict"] is True:
            if "parameters" in schema_arguments:
                score.strict_mode_passed = True

        return score

    def _determine_tier(self, score: ConformanceScore) -> ProviderTier:
        if score.is_fully_conforming():
            return ProviderTier.VERIFIED
        if score.tool_calling_passed or score.structured_output_passed:
            return ProviderTier.LIMITED
        return ProviderTier.EXPERIMENTAL
