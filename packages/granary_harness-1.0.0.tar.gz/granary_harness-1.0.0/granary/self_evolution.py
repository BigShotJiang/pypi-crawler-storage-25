from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set


@dataclass(slots=True)
class EvolutionPolicy:
    max_score_delta_per_step: float = 0.05
    max_combo_weight_delta: float = 0.08
    reward_ema_alpha: float = 0.1
    min_samples_before_update: int = 20
    system_lr_multiplier_range: tuple[float, float] = (0.7, 1.1)
    per_module_lr_boost_cap: float = 1.3
    per_module_lr_hard_cap: float = 1.0e-3
    experiment_window_steps: int = 300
    revert_on_composite_delta_lt: float = -0.03
    max_growth_per_cycle: int = 1
    rollback_quality_drop: float = 0.15
    rollback_loss_spike_factor: float = 2.0
    watch_steps_post_growth: int = 200
    circuit_breaker_open_blocks_routing: bool = True
    growth_suppressed_on_open_cb: bool = True
    auto_pause_acc_below: float = 0.40
    auto_pause_min_samples: int = 500


def bounded_routing_update(
    scores: dict[str, float],
    proposed_deltas: dict[str, float],
    *,
    max_delta: float = 0.05
) -> dict[str, float]:
    """Ensures per-step changes in routing weights never exceed safety bounds."""
    out = dict(scores)
    for mod, delta in proposed_deltas.items():
        if mod not in out:
            continue
        clamped = max(-max_delta, min(max_delta, delta))
        out[mod] = max(-1.0, min(2.0, out[mod] + clamped))
    return out


def bounded_combo_reward(
    combo_key: str,
    quality: float,
    history: dict[str, list[float]],
    *,
    max_window: int = 50,
    max_single_jump: float = 0.15
) -> None:
    """Updates sequence affinity metrics with sharp step-wise caps."""
    hist = history.setdefault(combo_key, [])
    if hist:
        last = hist[-1]
        quality = max(last - max_single_jump, min(last + max_single_jump, quality))
    hist.append(quality)
    if len(hist) > max_window:
        del hist[0]


@dataclass(slots=True)
class EvolutionSnapshot:
    step: int
    module: str
    routing_scores: dict[str, float]
    combo_quality_means: dict[str, float]
    checkpoint_version_id: str | None
    system_lr_multiplier: float


def take_evolution_snapshot(orch, hp, mod_name: str, step: int) -> EvolutionSnapshot:
    vm = getattr(orch._modules.get(mod_name), "_version_manager", None)
    best = vm.get_best_version() if vm else None
    combo_means = {
        k: (sum(v) / len(v) if v else 0.5)
        for k, v in orch._combo_quality.items()
    }
    
    routing_scores = {}
    for m in orch._module_quality:
        hist = orch._module_quality[m]
        routing_scores[m] = hist[-1] if hist else 0.5

    return EvolutionSnapshot(
        step=step,
        module=mod_name,
        routing_scores=routing_scores,
        combo_quality_means=combo_means,
        checkpoint_version_id=getattr(best, "version_id", None) if best else None,
        system_lr_multiplier=hp._system_lr_multiplier
    )


def rollback_evolution(snapshot: EvolutionSnapshot, orch, hp, mod) -> bool:
    """Restores the routing priorities and system state to pre-experimental baseline."""
    hp._system_lr_multiplier = snapshot.system_lr_multiplier
    
    # Restore combo qualities
    for k, v in snapshot.combo_quality_means.items():
        orch._combo_quality[k] = [v]
        
    # Restore module qualities
    for m, score in snapshot.routing_scores.items():
        orch._module_quality[m] = [score]

    if snapshot.checkpoint_version_id and hasattr(mod, "_version_manager"):
        return mod._version_manager.restore_version(snapshot.checkpoint_version_id)
    return False


def detect_prediction_drift(
    pred_a: dict[str, float], 
    pred_b: dict[str, float],
    directional_keys: set[str] | List[str],
    *,
    severity_threshold: float = 0.25
) -> dict[str, float] | None:
    """Checks for directional disagreement to publish a divergence event."""
    dirs_a, dirs_b = [], []
    for k in directional_keys:
        if k in pred_a:
            dirs_a.append(1 if pred_a[k] > 0.5 else -1)
        if k in pred_b:
            dirs_b.append(1 if pred_b[k] > 0.5 else -1)
    if not dirs_a or not dirs_b:
        return None
        
    agree = sum(1 for a, b in zip(dirs_a, dirs_b) if a == b)
    agreement = agree / max(len(dirs_a), len(dirs_b))
    severity = 1.0 - agreement
    if severity < severity_threshold:
        return None
    return {"severity": severity, "agreement": agreement}


def anti_gaming_quality_signal(
    self_reported_quality: float,
    outcome_ema: float | None,
    outcome_samples: int,
    *,
    min_outcome_samples: int = 30,
    max_discrepancy: float = 0.25
) -> float:
    """Discounts internal module quality claims if they mismatch actual outcomes."""
    if outcome_samples < min_outcome_samples or outcome_ema is None:
        return self_reported_quality * 0.7  # down-weight unverified claims
    disc = abs(self_reported_quality - outcome_ema)
    if disc > max_discrepancy:
        return outcome_ema  # trust actual ground-truth outcome
    return 0.6 * outcome_ema + 0.4 * self_reported_quality
