"""
Granary security and governance primitives.

This package provides implementation-ready building blocks for:
- Agent identity and token exchange (RFC 8693)
- Confidential computing attestation policy generation
- ShieldNet network anomaly detection
- Deterministic safety gates
- Fleet discovery and compliance telemetry
"""

from granary.identity import (
    AgentAssertionToken,
    TokenExchangeRequest,
    build_token_exchange_request,
)
from granary.finops import (
    TokenPricing,
    calculate_saved_cogs,
    TurnState,
    FinOpsController,
)
from granary.otel import (
    inject_trace_context,
    extract_trace_context,
    AgentSpanAttributes,
    OTelRedactionProcessor,
)
from granary.constitution import (
    OperatingConstitution,
    parse_lightweight_yaml,
)
from granary.idempotency import (
    IdempotencyRegistry,
    OutboxManager,
    ConsumerDeduplicator,
)
from granary.hitl import (
    HITLRequest,
    HITLManager,
)
from granary.audit import (
    AuditEvent,
    AuditManager,
)
from granary.roles import (
    AgentRole,
    RoleRegistry,
    RoleMetrics,
)
from granary.orchestration import (
    SupervisorState,
    SupervisorFSM,
    validate_blackboard_envelope,
    validate_channel_payload,
    publish_validated,
    score_plan_decomposition,
    contract_net_allocate,
)
from granary.self_evolution import (
    EvolutionPolicy,
    bounded_routing_update,
    bounded_combo_reward,
    EvolutionSnapshot,
    take_evolution_snapshot,
    rollback_evolution,
    detect_prediction_drift,
    anti_gaming_quality_signal,
)
from granary.self_healing import (
    FailureClass,
    FailureEvent,
    validate_failure_event,
    HealingState,
    SelfHealingEngine,
    replay_safe_process_outcome,
)
from granary.eval_flywheel import (
    FlywheelMetrics,
    EvaluationFlywheel,
    OnlineKpiTracker,
    ShadowLogEntry,
    CounterfactualEvaluator,
    HoldoutGovernance,
)
from granary.auto_memory import (
    MemoryTier,
    MemorySource,
    MemoryRecord,
    AutoMemoryManager,
)
from granary.auto_hook import (
    HookState,
    FailureFingerprint,
    AgentHook,
    AutoHookManager,
)
from granary.auto_gate import (
    GateState,
    GateClause,
    AgentGate,
    AutoGateManager,
)
from granary.auto_kpis import (
    IntelligenceKpis,
    IntelligenceKpiTracker,
)
from granary.self_handshake import (
    ContextState,
    ContinuationManifest,
    SelfHandshakeValidator,
    ContextBudgetManager,
    ProbationMonitor,
)
from granary.workspace import (
    WorkspaceBoundarySandbox,
    CredentialSegregationPolicy,
    DockerSandboxIntegration,
    UntrustedToolInterceptor,
)
from granary.continuity_envelopes import (
    EnvelopeKind,
    EpistemicNode,
    EpistemicTypingContract,
    ContinuityEnvelope,
    EnvelopeGatePipeline,
    translate_shsc_to_xmh,
    translate_xmh_to_shsc,
    reduce_journal_to_envelope,
)
from granary.rollups import (
    TaskStatus,
    TaskItem,
    HandoffSnapshot,
    RollupReconciler,
    HandoffSnapshotProtocol,
)
from granary.contamination import (
    LedgerRow,
    ContaminationAwareEvaluator,
)
from granary.prompt_security import (
    PromptGuard,
    sanitize_federation_import,
)
from granary.mcp_security import (
    RiskTier,
    McpTrustGateway,
)
from granary.conformance import (
    ProviderTier,
    ConformanceScore,
    ProviderRecord,
    ConformanceManager,
)
from granary.supply_chain import (
    ModelArtifact,
    AdmissionVerdict,
    ServingAdmissionController,
    sign_artifact_digest,
)
from granary.disaster_recovery import (
    JournalEvent,
    DREventStreamReplicator,
)
from granary.core_store import (
    CheckpointManifest,
    ImmutableCoreStore,
    bootstrap_session_with_handoff,
)
from granary.chaos import (
    ChaosExperimentRecord,
    AgentChaosMonkey,
)
from granary.slo import (
    AgentSloMonitor,
)
from granary.readiness import (
    Waiver,
    GateResult,
    GoNoGoDecisionMatrix,
    execute_day0_rollback_drill,
)
from granary.coherence import (
    SubsystemState,
    IntelligenceUpgradeStage,
    CoherenceWorkUnit,
    CoherenceContractManager,
)
from granary.continuity import (
    FallbackLevel,
    XMHSnapshot,
    CapabilityGapMatrix,
    ContinuityFallbackLadder,
    CapabilityNegotiationProtocol,
    DeterminismCheckingHarness,
    calculate_resume_determinism_kpis,
)
from granary.adversa import (
    AdversaHarness,
    AdversaResult,
    judge_compliance,
    judge_security_analyst,
    judge_system_auditor,
)
from granary.deterministic_gates import (
    TaintLevel,
    GateVerdict,
    DeterministicGateEngine,
    evaluate_named_variables_taint,
)
from granary.discovery import (
    NetworkSignal,
    AgentSignatureVerdict,
    classify_agent_signature,
    batch_classify,
    build_defender_alert_payload,
)
from granary.licensing import (
    LicensePayload,
    generate_node_lock_fingerprint,
    sign_license,
    verify_license,
    create_default_vpc_operator_license,
)
from granary.shieldnet import (
    ShieldNetPolicy,
    ShieldNetVerdict,
    ShieldNetClassifier,
    shannon_entropy,
)
from granary.attestation import (
    NitroMeasurements,
    generate_kms_attestation_policy,
)

__all__ = [
    "AgentAssertionToken",
    "TokenExchangeRequest",
    "build_token_exchange_request",
    "TokenPricing",
    "calculate_saved_cogs",
    "TurnState",
    "FinOpsController",
    "inject_trace_context",
    "extract_trace_context",
    "AgentSpanAttributes",
    "OTelRedactionProcessor",
    "OperatingConstitution",
    "parse_lightweight_yaml",
    "IdempotencyRegistry",
    "OutboxManager",
    "ConsumerDeduplicator",
    "HITLRequest",
    "HITLManager",
    "AuditEvent",
    "AuditManager",
    "AgentRole",
    "RoleRegistry",
    "RoleMetrics",
    "SupervisorState",
    "SupervisorFSM",
    "validate_blackboard_envelope",
    "validate_channel_payload",
    "publish_validated",
    "score_plan_decomposition",
    "contract_net_allocate",
    "EvolutionPolicy",
    "bounded_routing_update",
    "bounded_combo_reward",
    "EvolutionSnapshot",
    "take_evolution_snapshot",
    "rollback_evolution",
    "detect_prediction_drift",
    "anti_gaming_quality_signal",
    "FailureClass",
    "FailureEvent",
    "validate_failure_event",
    "HealingState",
    "SelfHealingEngine",
    "replay_safe_process_outcome",
    "FlywheelMetrics",
    "EvaluationFlywheel",
    "OnlineKpiTracker",
    "ShadowLogEntry",
    "CounterfactualEvaluator",
    "HoldoutGovernance",
    "MemoryTier",
    "MemorySource",
    "MemoryRecord",
    "AutoMemoryManager",
    "HookState",
    "FailureFingerprint",
    "AgentHook",
    "AutoHookManager",
    "GateState",
    "GateClause",
    "AgentGate",
    "AutoGateManager",
    "IntelligenceKpis",
    "IntelligenceKpiTracker",
    "TaskStatus",
    "TaskItem",
    "HandoffSnapshot",
    "RollupReconciler",
    "HandoffSnapshotProtocol",
    "WorkspaceBoundarySandbox",
    "CredentialSegregationPolicy",
    "DockerSandboxIntegration",
    "UntrustedToolInterceptor",
    "EnvelopeKind",
    "EpistemicNode",
    "EpistemicTypingContract",
    "ContinuityEnvelope",
    "EnvelopeGatePipeline",
    "translate_shsc_to_xmh",
    "translate_xmh_to_shsc",
    "reduce_journal_to_envelope",
    "FallbackLevel",
    "XMHSnapshot",
    "CapabilityGapMatrix",
    "ContinuityFallbackLadder",
    "CapabilityNegotiationProtocol",
    "DeterminismCheckingHarness",
    "calculate_resume_determinism_kpis",
    "ContextState",
    "ContinuationManifest",
    "SelfHandshakeValidator",
    "ContextBudgetManager",
    "ProbationMonitor",
    "CheckpointManifest",
    "ImmutableCoreStore",
    "bootstrap_session_with_handoff",
    "LedgerRow",
    "ContaminationAwareEvaluator",
    "PromptGuard",
    "sanitize_federation_import",
    "RiskTier",
    "McpTrustGateway",
    "ProviderTier",
    "ConformanceScore",
    "ProviderRecord",
    "ConformanceManager",
    "ModelArtifact",
    "AdmissionVerdict",
    "ServingAdmissionController",
    "sign_artifact_digest",
    "JournalEvent",
    "DREventStreamReplicator",
    "ChaosExperimentRecord",
    "AgentChaosMonkey",
    "AgentSloMonitor",
    "Waiver",
    "GateResult",
    "GoNoGoDecisionMatrix",
    "execute_day0_rollback_drill",
    "SubsystemState",
    "IntelligenceUpgradeStage",
    "CoherenceWorkUnit",
    "CoherenceContractManager",
    "AdversaHarness",
    "AdversaResult",
    "judge_compliance",
    "judge_security_analyst",
    "judge_system_auditor",
    "TaintLevel",
    "GateVerdict",
    "DeterministicGateEngine",
    "evaluate_named_variables_taint",
    "NetworkSignal",
    "AgentSignatureVerdict",
    "classify_agent_signature",
    "batch_classify",
    "build_defender_alert_payload",
    "LicensePayload",
    "generate_node_lock_fingerprint",
    "sign_license",
    "verify_license",
    "create_default_vpc_operator_license",
    "ShieldNetPolicy",
    "ShieldNetVerdict",
    "ShieldNetClassifier",
    "shannon_entropy",
    "NitroMeasurements",
    "generate_kms_attestation_policy",
]
# Cleaned export manifest. Standalone repository verification successful.
