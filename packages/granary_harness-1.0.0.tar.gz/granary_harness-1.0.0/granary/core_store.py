from __future__ import annotations

import os
import hmac
import json
import time
import shutil
import hashlib
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple


@dataclass(slots=True)
class CheckpointManifest:
    version_id: str
    step: int
    state_hash: str
    timestamp: float
    signature: str


class ImmutableCoreStore:
    """
    Implements the immutable file-core architecture with append-only journal,
    sealed snapshots, signed checkpoints, and atomic staging-based publish flow.
    """

    def __init__(self, storage_root: str, secret_key: bytes = b"granary-core-secret") -> None:
        self.storage_root = storage_root
        self.secret_key = secret_key
        
        self.journal_file = os.path.join(storage_root, "journal", "events.jsonl")
        self.snapshot_dir = os.path.join(storage_root, "snapshots")
        self.checkpoint_file = os.path.join(storage_root, "checkpoints", "manifest.json")
        self.staging_dir = os.path.join(storage_root, "staging")
        
        # Ensure directories exist
        os.makedirs(os.path.join(storage_root, "journal"), exist_ok=True)
        os.makedirs(self.snapshot_dir, exist_ok=True)
        os.makedirs(os.path.dirname(self.checkpoint_file), exist_ok=True)
        os.makedirs(self.staging_dir, exist_ok=True)

    def append_journal_event(self, event_type: str, payload: dict) -> dict:
        """
        Enforces atomic transaction-safe append-only journal writing.
        """
        event = {
            "event_id": f"evt_{hashlib.sha256(str(time.time_ns()).encode()).hexdigest()[:16]}",
            "event_type": event_type,
            "timestamp": time.time(),
            "payload": payload,
        }
        raw_line = json.dumps(event, sort_keys=True, separators=(",", ":")) + "\n"
        
        # Atomic append-flush guarantee
        with open(self.journal_file, "a", encoding="utf-8") as f:
            f.write(raw_line)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        return event

    def publish_sealed_snapshot(self, step: int, state_data: dict) -> CheckpointManifest:
        """
        Enforces atomic stage -> hash/sign -> publish -> reference update write flow.
        """
        version_id = f"snap_step_{step}_{int(time.time())}"
        temp_file = os.path.join(self.staging_dir, f"{version_id}.tmp")
        target_file = os.path.join(self.snapshot_dir, f"{version_id}.json")

        # 1. Stage state to temporary file
        raw_state = json.dumps(state_data, sort_keys=True, separators=(",", ":"))
        with open(temp_file, "w", encoding="utf-8") as f:
            f.write(raw_state)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass

        # 2. Compute state SHA256 digest
        state_hash = hashlib.sha256(raw_state.encode("utf-8")).hexdigest()

        # 3. Generate HMAC signature
        signature_material = f"{version_id}:{step}:{state_hash}".encode("utf-8")
        sig = hmac.new(self.secret_key, signature_material, hashlib.sha256).hexdigest()

        # 4. Atomic Publish (rename temp to target)
        os.replace(temp_file, target_file)

        # 5. Update sealed checkpoint reference manifest
        manifest = CheckpointManifest(
            version_id=version_id,
            step=step,
            state_hash=state_hash,
            timestamp=time.time(),
            signature=sig,
        )
        self._write_checkpoint_manifest(manifest)

        # 6. Append audit log event to the journal
        self.append_journal_event("snapshot_published", {
            "version_id": version_id,
            "step": step,
            "state_hash": state_hash,
        })

        return manifest

    def verify_checkpoint_integrity(self) -> Tuple[bool, str]:
        """
        Verifies the cryptographic integrity of the current checkpoint manifest and sealed snapshot.
        """
        if not os.path.exists(self.checkpoint_file):
            return False, "missing_checkpoint_manifest"

        try:
            with open(self.checkpoint_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            return False, "invalid_manifest_json"

        # Verify signature matching
        signature_material = f"{data['version_id']}:{data['step']}:{data['state_hash']}".encode("utf-8")
        expected_sig = hmac.new(self.secret_key, signature_material, hashlib.sha256).hexdigest()

        if not hmac.compare_digest(data["signature"], expected_sig):
            return False, "invalid_checkpoint_signature"

        # Verify physical snapshot file match
        snapshot_path = os.path.join(self.snapshot_dir, f"{data['version_id']}.json")
        if not os.path.exists(snapshot_path):
            return False, "missing_snapshot_file"

        with open(snapshot_path, "r", encoding="utf-8") as f:
            content = f.read()

        actual_hash = hashlib.sha256(content.encode("utf-8")).hexdigest()
        if actual_hash != data["state_hash"]:
            return False, "snapshot_content_hash_mismatch"

        return True, "verified"

    def execute_backup_verify_drill(self, backup_root: str) -> Tuple[bool, str]:
        """
        Executes a simulated automated backup verification and restore drill.
        Atomically copies active data to a backup folder and verifies integrity post-restore.
        """
        backup_dir = os.path.join(backup_root, f"backup_{int(time.time())}")
        os.makedirs(backup_dir, exist_ok=True)

        try:
            # Copy active database folders to backup
            shutil.copytree(self.storage_root, os.path.join(backup_dir, "data"), dirs_exist_ok=True)
            
            # Verify backup copy integrity by instantiating a sub-replicator on the backup directory
            backup_store = ImmutableCoreStore(os.path.join(backup_dir, "data"), self.secret_key)
            ok, msg = backup_store.verify_checkpoint_integrity()
            
            # Append drill completed audit logs
            self.append_journal_event("backup_drill_completed", {
                "backup_dir": backup_dir,
                "integrity_passed": ok,
                "reason": msg,
            })
            return ok, f"drill_completed_and_verified: {msg}"
        except Exception as e:
            return False, f"drill_failed: {str(e)}"

    def _write_checkpoint_manifest(self, manifest: CheckpointManifest) -> None:
        data = {
            "version_id": manifest.version_id,
            "step": manifest.step,
            "state_hash": manifest.state_hash,
            "timestamp": manifest.timestamp,
            "signature": manifest.signature,
        }
        temp_manifest = os.path.join(self.staging_dir, "manifest.tmp")
        with open(temp_manifest, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        os.replace(temp_manifest, self.checkpoint_file)


def bootstrap_session_with_handoff(repo_root: str) -> Optional[dict]:
    """
    Default policy to restart/bootstrap from latest validated handoff snapshot instead of context compression.
    """
    paths_to_check = [
        os.path.join(repo_root, ".handoff", "latest.json"),
        os.path.join(repo_root, ".agent", "rollups", "latest.json"),
    ]
    for path in paths_to_check:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                return data
            except (json.JSONDecodeError, OSError):
                pass
    return None
