from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List


@dataclass(slots=True)
class NetworkSignal:
    source_host: str
    destination_host: str
    destination_port: int
    protocol: str
    bytes_sent: int
    bytes_received: int
    process_name: str


@dataclass(slots=True)
class AgentSignatureVerdict:
    is_agentic: bool
    confidence: float
    reasons: List[str]


def classify_agent_signature(signal: NetworkSignal) -> AgentSignatureVerdict:
    score = 0.0
    reasons: List[str] = []

    process = signal.process_name.lower()
    if any(token in process for token in ("cursor", "claude", "codex", "ollama", "agent", "mcp")):
        score += 0.45
        reasons.append("process_name_matches_agent_tooling")

    if signal.destination_port in (443, 11434, 5000):
        score += 0.20
        reasons.append("agent_common_destination_port")

    if signal.protocol.lower() in ("https", "http2", "grpc"):
        score += 0.15
        reasons.append("agent_common_protocol")

    if signal.bytes_sent > 8_000 and signal.bytes_received > 8_000:
        score += 0.20
        reasons.append("high_bidirectional_payload")

    confidence = min(1.0, score)
    return AgentSignatureVerdict(
        is_agentic=confidence >= 0.60,
        confidence=confidence,
        reasons=reasons,
    )


def build_defender_alert_payload(
    *,
    tenant_id: str,
    signal: NetworkSignal,
    verdict: AgentSignatureVerdict,
    policy_id: str = "granary.shadow-ai.discovery.v1",
) -> Dict[str, object]:
    severity = "high" if verdict.confidence >= 0.85 else "medium"
    return {
        "schemaVersion": "2026-1",
        "provider": "granary",
        "policyId": policy_id,
        "tenantId": tenant_id,
        "severity": severity,
        "title": "Potential Shadow AI Agent Discovered",
        "description": "Granary identified traffic that matches agentic behavior signatures.",
        "evidence": {
            "sourceHost": signal.source_host,
            "destinationHost": signal.destination_host,
            "destinationPort": signal.destination_port,
            "protocol": signal.protocol,
            "processName": signal.process_name,
            "bytesSent": signal.bytes_sent,
            "bytesReceived": signal.bytes_received,
            "confidence": verdict.confidence,
            "reasons": verdict.reasons,
        },
    }


def batch_classify(signals: Iterable[NetworkSignal]) -> List[AgentSignatureVerdict]:
    return [classify_agent_signature(signal) for signal in signals]
