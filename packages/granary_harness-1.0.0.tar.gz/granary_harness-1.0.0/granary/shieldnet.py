from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from math import log2
from typing import Deque, Dict


@dataclass(slots=True)
class ShieldNetPolicy:
    max_dns_entropy_threshold: float = 4.8
    max_dns_query_rate_per_sec: int = 5
    max_post_body_bytes_per_window: int = 16_384
    window_seconds: int = 10
    allowlisted_domains: tuple[str, ...] = ("github.com", "pypi.org", "files.pythonhosted.org")


@dataclass(slots=True)
class ShieldNetVerdict:
    allowed: bool
    reason: str
    action: str


def shannon_entropy(value: str) -> float:
    if not value:
        return 0.0
    freq: Dict[str, int] = defaultdict(int)
    for ch in value:
        freq[ch] += 1
    total = len(value)
    return -sum((count / total) * log2(count / total) for count in freq.values())


class ShieldNetClassifier:
    """
    Low-overhead behavior classifier for sandbox egress decisions.
    """

    def __init__(self, policy: ShieldNetPolicy | None = None) -> None:
        self.policy = policy or ShieldNetPolicy()
        self._dns_events: Dict[str, Deque[float]] = defaultdict(deque)
        self._post_bytes: Dict[str, Deque[tuple[float, int]]] = defaultdict(deque)

    def classify_dns_query(self, *, session_id: str, domain: str, ts: float) -> ShieldNetVerdict:
        window = self._dns_events[session_id]
        window.append(ts)
        self._drop_old_timestamps(window, ts)

        entropy = shannon_entropy(domain.split(".")[0])
        query_rate = len(window) / max(1, self.policy.window_seconds)

        if entropy > self.policy.max_dns_entropy_threshold and query_rate > self.policy.max_dns_query_rate_per_sec:
            return ShieldNetVerdict(
                allowed=False,
                reason=f"dns_tunneling_suspected(entropy={entropy:.2f}, rate={query_rate:.2f})",
                action="freeze-cgroup",
            )
        if self._is_allowlisted(domain):
            return ShieldNetVerdict(allowed=True, reason="allowlisted_domain", action="allow")
        return ShieldNetVerdict(allowed=True, reason="default_allow_with_monitoring", action="allow")

    def classify_http_post(
        self, *, session_id: str, host: str, body_size_bytes: int, ts: float
    ) -> ShieldNetVerdict:
        window = self._post_bytes[session_id]
        window.append((ts, body_size_bytes))
        while window and ts - window[0][0] > self.policy.window_seconds:
            window.popleft()

        aggregate = sum(size for _, size in window)
        if aggregate > self.policy.max_post_body_bytes_per_window and not self._is_allowlisted(host):
            return ShieldNetVerdict(
                allowed=False,
                reason=f"egress_exfiltration_suspected(bytes={aggregate})",
                action="terminate-sandbox",
            )
        return ShieldNetVerdict(allowed=True, reason="post_within_limits", action="allow")

    def _drop_old_timestamps(self, window: Deque[float], ts: float) -> None:
        while window and ts - window[0] > self.policy.window_seconds:
            window.popleft()

    def _is_allowlisted(self, domain: str) -> bool:
        return any(domain == suffix or domain.endswith(f".{suffix}") for suffix in self.policy.allowlisted_domains)
