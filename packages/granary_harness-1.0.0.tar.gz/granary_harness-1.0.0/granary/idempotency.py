from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass(slots=True)
class IdempotencyKeyScope:
    namespace: str
    key: str
    ttl_seconds: int
    created_at: float = field(default_factory=time.time)


@dataclass(slots=True)
class OutboxEntry:
    event_id: str
    action_type: str
    payload: str
    status: str = "pending" # pending, processed, failed
    retry_count: int = 0
    max_retries: int = 3
    last_error: str = ""
    created_at: float = field(default_factory=time.time)
    processed_at: Optional[float] = None


class IdempotencyRegistry:
    """
    Manages action idempotency keys, TTLs, scopes, and conflict resolutions.
    """

    def __init__(self) -> None:
        self.registry: Dict[Tuple[str, str], IdempotencyKeyScope] = {}

    def register_key(self, namespace: str, key: str, ttl_seconds: int) -> bool:
        """
        Registers an idempotency key. Returns True if successful, False if already exists and is not expired.
        """
        now = time.time()
        stored = self.registry.get((namespace, key))
        if stored:
            if now - stored.created_at < stored.ttl_seconds:
                # Still valid/unexpired conflict
                return False
        
        self.registry[(namespace, key)] = IdempotencyKeyScope(
            namespace=namespace,
            key=key,
            ttl_seconds=ttl_seconds,
            created_at=now,
        )
        return True

    def is_key_active(self, namespace: str, key: str) -> bool:
        now = time.time()
        stored = self.registry.get((namespace, key))
        if not stored:
            return False
        return now - stored.created_at < stored.ttl_seconds

    def clean_expired_keys(self) -> None:
        now = time.time()
        expired = [
            k for k, v in self.registry.items()
            if now - v.created_at >= v.ttl_seconds
        ]
        for k in expired:
            del self.registry[k]


class OutboxManager:
    """
    Implements a transactional Outbox pattern for reliable multi-agent delivery.
    """

    def __init__(self) -> None:
        self.outbox: Dict[str, OutboxEntry] = {}

    def add_event(self, action_type: str, payload_dict: dict, max_retries: int = 3) -> OutboxEntry:
        event_id = f"evt_{hashlib.sha256(str(time.time_ns()).encode()).hexdigest()[:16]}"
        entry = OutboxEntry(
            event_id=event_id,
            action_type=action_type,
            payload=json.dumps(payload_dict),
            max_retries=max_retries,
        )
        self.outbox[event_id] = entry
        return entry

    def process_event(self, event_id: str, processor: callable) -> bool:
        """
        Processes an outbox event. Safely retries up to max_retries on failure.
        """
        entry = self.outbox.get(event_id)
        if not entry:
            return False
        
        if entry.status == "processed":
            return True
            
        if entry.status == "failed" and entry.retry_count >= entry.max_retries:
            return False

        try:
            entry.retry_count += 1
            payload_dict = json.loads(entry.payload)
            processor(entry.action_type, payload_dict)
            
            entry.status = "processed"
            entry.processed_at = time.time()
            return True
        except Exception as e:
            entry.last_error = str(e)
            if entry.retry_count >= entry.max_retries:
                entry.status = "failed"
            return False


class ConsumerDeduplicator:
    """
    Ensures message/event processing deduplication over a sliding window.
    Detects and handles poison-message loops.
    """

    def __init__(self, retention_window_seconds: int = 86400) -> None:
        self.retention_window_seconds = retention_window_seconds
        self.processed_messages: Dict[str, float] = {} # msg_id -> timestamp
        self.poison_message_counts: Dict[str, int] = {} # msg_id -> processing_failure_count

    def should_process(self, msg_id: str) -> bool:
        """
        Checks if a message should be processed based on the deduplication log and window.
        """
        now = time.time()
        # Clean old messages first
        self.clean_expired_records(now)
        
        if msg_id in self.processed_messages:
            return False
        return True

    def mark_processed(self, msg_id: str) -> None:
        self.processed_messages[msg_id] = time.time()
        # Clear poison count if successfully processed
        self.poison_message_counts.pop(msg_id, None)

    def track_failure(self, msg_id: str) -> bool:
        """
        Increments failure count for a message. Returns True if classified as a "poison message" (failures >= 3).
        """
        self.poison_message_counts[msg_id] = self.poison_message_counts.get(msg_id, 0) + 1
        return self.is_poison(msg_id)

    def is_poison(self, msg_id: str) -> bool:
        return self.poison_message_counts.get(msg_id, 0) >= 3

    def clean_expired_records(self, now: float) -> None:
        expired = [
            msg_id for msg_id, ts in self.processed_messages.items()
            if now - ts >= self.retention_window_seconds
        ]
        for msg_id in expired:
            del self.processed_messages[msg_id]
