from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple


@dataclass(slots=True)
class ConstitutionRule:
    id: str
    rule: str
    source: str


@dataclass(slots=True)
class AutonomyTier:
    name: str
    autonomy: str
    approval: str


@dataclass(slots=True)
class BlastRadiusLimits:
    max_files: int
    max_loc_delta: int
    token_budget: int
    wall_clock_minutes: int


@dataclass(slots=True)
class PathOverride:
    path_pattern: str
    max_tier: str
    max_files: Optional[int] = None
    max_loc_delta: Optional[int] = None
    requires_token: bool = False


@dataclass(slots=True)
class ElevationToken:
    tier: str
    session_id: str
    expires_at: datetime
    reason: str


def parse_lightweight_yaml(content: str) -> dict:
    """
    Lightweight, dependency-free YAML parser for agent-constitution.yaml.
    Supports key-value, nested structures, and list of dicts/items using strict indentation block matching.
    """
    lines = content.splitlines()
    cleaned = []
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        comment_idx = line.find(" #")
        if comment_idx != -1:
            line = line[:comment_idx]
        if not line.strip():
            continue
        cleaned.append(line)

    def parse_block(start_idx: int, parent_indent: int) -> tuple[dict | list | str, int]:
        if start_idx >= len(cleaned):
            return {}, start_idx

        first_line = cleaned[start_idx]
        first_indent = len(first_line) - len(first_line.lstrip())
        
        if first_line.strip().startswith("-"):
            lst = []
            idx = start_idx
            while idx < len(cleaned):
                line = cleaned[idx]
                indent = len(line) - len(line.lstrip())
                if indent < first_indent:
                    break
                stripped = line.strip()
                if stripped.startswith("-"):
                    item_content = stripped[1:].strip()
                    if ":" in item_content:
                        k, v = item_content.split(":", 1)
                        k = k.strip()
                        v = v.strip().strip('"').strip("'")
                        
                        item_dict = {k: v}
                        lst.append(item_dict)
                        
                        next_idx = idx + 1
                        while next_idx < len(cleaned):
                            next_line = cleaned[next_idx]
                            next_indent = len(next_line) - len(next_line.lstrip())
                            if next_indent <= first_indent:
                                break
                            next_stripped = next_line.strip()
                            if ":" in next_stripped:
                                nk, nv = next_stripped.split(":", 1)
                                nk = nk.strip()
                                nv = nv.strip().strip('"').strip("'")
                                item_dict[nk] = nv
                            next_idx += 1
                        idx = next_idx - 1
                    else:
                        lst.append(item_content.strip('"').strip("'"))
                idx += 1
            return lst, idx
        else:
            dct = {}
            idx = start_idx
            while idx < len(cleaned):
                line = cleaned[idx]
                indent = len(line) - len(line.lstrip())
                if indent < first_indent:
                    break
                stripped = line.strip()
                if ":" in stripped:
                    k, v = stripped.split(":", 1)
                    k = k.strip()
                    v = v.strip().strip('"').strip("'")
                    
                    if v == "":
                        if idx + 1 < len(cleaned):
                            next_line = cleaned[idx + 1]
                            next_indent = len(next_line) - len(next_line.lstrip())
                            if next_indent > indent:
                                val_block, next_idx = parse_block(idx + 1, indent)
                                dct[k] = val_block
                                idx = next_idx - 1
                    else:
                        dct[k] = v
                idx += 1
            return dct, idx

    res, _ = parse_block(0, -1)
    return res



class OperatingConstitution:
    """
    Parses and enforces the immutable docs/agent-constitution.yaml policy core.
    """

    def __init__(self, yaml_content: str) -> None:
        self.raw_data = parse_lightweight_yaml(yaml_content)
        self.schema_version = self.raw_data.get("schema_version", "1.0")
        self.constitution_id = self.raw_data.get("constitution_id", "living-nn-agent-ops")
        self.default_tier = self.raw_data.get("default_tier", "T1")
        self.max_tier_without_approval = self.raw_data.get("max_tier_without_approval", "T2")
        
        self.immutable_rules_hash = self.raw_data.get("immutable_rules_hash", "")
        self.immutable_rules: List[ConstitutionRule] = []
        self._parse_immutable_rules()
        
        self.autonomy_tiers: Dict[str, AutonomyTier] = {}
        self._parse_autonomy_tiers()
        
        self.blast_radius_caps: Dict[str, BlastRadiusLimits] = {}
        self._parse_blast_radius_caps()
        
        self.path_overrides: List[PathOverride] = []
        self._parse_path_overrides()
        
        self.action_registry: Dict[str, str] = self.raw_data.get("action_id_registry", {})
        
        # Current runtime session state
        self.current_tier = self.default_tier
        self.active_elevations: Dict[str, ElevationToken] = {}
        self.fail_closed_mode = False

    def _parse_immutable_rules(self) -> None:
        raw_rules = self.raw_data.get("immutable_rules", [])
        for r in raw_rules:
            if isinstance(r, dict):
                self.immutable_rules.append(
                    ConstitutionRule(
                        id=r.get("id", ""),
                        rule=r.get("rule", ""),
                        source=r.get("source", ""),
                    )
                )

    def _parse_autonomy_tiers(self) -> None:
        raw_tiers = self.raw_data.get("autonomy_tiers", {})
        for tier_id, data in raw_tiers.items():
            if isinstance(data, dict):
                self.autonomy_tiers[tier_id] = AutonomyTier(
                    name=data.get("name", ""),
                    autonomy=data.get("autonomy", ""),
                    approval=data.get("approval", ""),
                )

    def _parse_blast_radius_caps(self) -> None:
        raw_caps = self.raw_data.get("blast_radius_caps", {})
        for tier_id, data in raw_caps.items():
            if isinstance(data, dict):
                self.blast_radius_caps[tier_id] = BlastRadiusLimits(
                    max_files=int(data.get("max_files", -1)),
                    max_loc_delta=int(data.get("max_loc_delta", -1)),
                    token_budget=int(data.get("token_budget", -1)),
                    wall_clock_minutes=int(data.get("wall_clock_minutes", -1)),
                )

    def _parse_path_overrides(self) -> None:
        raw_overrides = self.raw_data.get("path_overrides", [])
        for o in raw_overrides:
            if isinstance(o, dict):
                self.path_overrides.append(
                    PathOverride(
                        path_pattern=o.get("path_pattern", ""),
                        max_tier=o.get("max_tier", ""),
                        max_files=int(o["max_files"]) if "max_files" in o else None,
                        max_loc_delta=int(o["max_loc_delta"]) if "max_loc_delta" in o else None,
                        requires_token=(o.get("requires_token", "false").lower() == "true"),
                    )
                )

    def verify_immutable_rules_hash(self, raw_yaml_rules_part: str) -> bool:
        """
        Verifies that the immutable_rules block matches its declared SHA256 checksum to prevent drift.
        """
        calculated_hash = "sha256:" + hashlib.sha256(raw_yaml_rules_part.strip().encode("utf-8")).hexdigest()
        return hmac_compare(self.immutable_rules_hash, calculated_hash)

    def check_action_allowed(self, action_id: str) -> Tuple[bool, str]:
        """
        Determines if the action is authorized under the current session's active autonomy tier.
        """
        if self.fail_closed_mode:
            return False, "FAIL_CLOSED_PROD_MODE_ACTIVE: All mutating actions blocked"

        required_tier = self.action_registry.get(action_id)
        if not required_tier:
            return False, f"Action ID '{action_id}' not found in action registry"

        # T0 <= T1 <= T2 <= T3 <= T4
        tier_levels = {"T0": 0, "T1": 1, "T2": 2, "T3": 3, "T4": 4}
        curr_level = tier_levels.get(self.current_tier, 0)
        req_level = tier_levels.get(required_tier, 0)

        if curr_level >= req_level:
            return True, f"Action allowed under active tier {self.current_tier}"
        
        return False, f"Action requires {required_tier}, current active tier is {self.current_tier}"

    def check_blast_radius(
        self,
        *,
        files_edited: int,
        loc_delta: int,
        tokens_used: int,
        elapsed_minutes: float,
    ) -> Tuple[bool, str]:
        """
        Validates the current session's metrics against blast-radius caps.
        """
        limits = self.blast_radius_caps.get(self.current_tier)
        if not limits:
            return True, "No blast-radius limits defined for current tier"

        if limits.max_files != -1 and files_edited > limits.max_files:
            return False, f"Blast-radius violation: files_edited ({files_edited}) exceeds tier maximum ({limits.max_files})"

        if limits.max_loc_delta != -1 and loc_delta > limits.max_loc_delta:
            return False, f"Blast-radius violation: loc_delta ({loc_delta}) exceeds tier maximum ({limits.max_loc_delta})"

        if limits.token_budget != -1 and tokens_used > limits.token_budget:
            return False, f"Blast-radius violation: tokens_used ({tokens_used}) exceeds tier maximum ({limits.token_budget})"

        if limits.wall_clock_minutes != -1 and elapsed_minutes > limits.wall_clock_minutes:
            return False, f"Blast-radius violation: elapsed_minutes ({elapsed_minutes:.1f}) exceeds tier maximum ({limits.wall_clock_minutes})"

        return True, "Blast-radius constraints satisfied"

    def verify_path_override(
        self,
        *,
        filepath: str,
        files_edited: int,
        loc_delta: int,
    ) -> Tuple[bool, str]:
        """
        Enforces path-specific security policies.
        """
        for override in self.path_overrides:
            pattern = override.path_pattern.replace("**", ".*").replace("*", "[^/]*")
            if re.match(pattern, filepath):
                # Enforce max tier
                tier_levels = {"T0": 0, "T1": 1, "T2": 2, "T3": 3, "T4": 4}
                curr_level = tier_levels.get(self.current_tier, 0)
                max_allowed_level = tier_levels.get(override.max_tier, 0)
                
                if curr_level > max_allowed_level:
                    return False, f"Path override violation for '{filepath}': requires max tier {override.max_tier}, active is {self.current_tier}"
                
                if override.max_files is not None and files_edited > override.max_files:
                    return False, f"Path override violation for '{filepath}': edits count ({files_edited}) exceeds path limit ({override.max_files})"
                
                if override.max_loc_delta is not None and loc_delta > override.max_loc_delta:
                    return False, f"Path override violation for '{filepath}': LOC delta ({loc_delta}) exceeds path limit ({override.max_loc_delta})"
                
                if override.requires_token and not self._is_elevated_session():
                    return False, f"Path override violation for '{filepath}': requires explicit human approval token"

        return True, "Path override constraints satisfied"

    def _is_elevated_session(self) -> bool:
        now_dt = datetime.now(timezone.utc)
        # Check if we have active valid elevation tokens
        for token in list(self.active_elevations.values()):
            if token.expires_at > now_dt:
                return True
        return False

    def parse_elevation_token(self, token_str: str) -> Optional[ElevationToken]:
        """
        Parses human elevation commands. Format:
        APPROVE T{n} session={uuid} until={ISO8601} reason={slug}
        """
        pattern = r"^APPROVE\s+(T[0-4])\s+session=([a-fA-F0-9-]+)\s+until=([^\s]+)\s+reason=([^\s]+)"
        match = re.match(pattern, token_str.strip())
        if not match:
            return None
        
        tier, session_id, until_str, reason = match.groups()
        try:
            # Parse ISO8601 until string
            expires_at = datetime.fromisoformat(until_str.replace("Z", "+00:00"))
        except ValueError:
            return None

        return ElevationToken(
            tier=tier,
            session_id=session_id,
            expires_at=expires_at,
            reason=reason,
        )

    def apply_elevation(self, token: ElevationToken) -> bool:
        now_dt = datetime.now(timezone.utc)
        if token.expires_at <= now_dt:
            return False
        
        self.active_elevations[token.session_id] = token
        self.current_tier = token.tier
        return True

    def enforce_fail_closed_prod(self, is_prod_detected: bool) -> None:
        """
        Enforce fail-closed state if production environment or ambiguous signals are detected.
        """
        if is_prod_detected:
            self.fail_closed_mode = True
            self.current_tier = "T0"


def hmac_compare(a: str, b: str) -> bool:
    return hashlib.sha256(a.encode()).digest() == hashlib.sha256(b.encode()).digest()
