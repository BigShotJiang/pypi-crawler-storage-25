from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass(slots=True)
class HITLRequest:
    approval_id: str
    work_unit_id: str
    action_id: str
    payload: str
    risk_tier: str # T0, T1, T2, T3, T4
    escalation_path: List[str]
    timeout_seconds: int
    status: str = "pending" # pending, approved, rejected, timed_out, escalated
    approver_id: Optional[str] = None
    decision_rationale: str = ""
    created_at: float = field(default_factory=time.time)
    resolved_at: Optional[float] = None
    checkpoint_data: Dict[str, str] = field(default_factory=dict) # State snapshots for resume guarantees


class HITLManager:
    """
    Manages durable human-in-the-loop (HITL) approval states, timeout logic,
    escalation ladders, and deterministic pause-resume semantics.
    """

    def __init__(self) -> None:
        self.requests: Dict[str, HITLRequest] = {}

    def submit_request(
        self,
        *,
        work_unit_id: str,
        action_id: str,
        payload: str,
        risk_tier: str,
        escalation_path: List[str],
        timeout_seconds: Optional[int] = None,
        checkpoint_data: Optional[Dict[str, str]] = None,
    ) -> HITLRequest:
        """
        Creates and registers a new human-in-the-loop (HITL) approval request.
        """
        approval_id = f"appr_{hashlib.sha256(f'{work_unit_id}:{action_id}:{time.time_ns()}'.encode()).hexdigest()[:16]}"
        
        # Default timeout values per risk tier if not specified
        if timeout_seconds is None:
            tier_timeouts = {
                "T0": 300,       # 5 minutes
                "T1": 600,       # 10 minutes
                "T2": 1800,      # 30 minutes
                "T3": 3600,      # 1 hour
                "T4": 86400,     # 24 hours (requires written human confirmation)
            }
            timeout_seconds = tier_timeouts.get(risk_tier, 1800)

        req = HITLRequest(
            approval_id=approval_id,
            work_unit_id=work_unit_id,
            action_id=action_id,
            payload=payload,
            risk_tier=risk_tier,
            escalation_path=list(escalation_path),
            timeout_seconds=timeout_seconds,
            checkpoint_data=dict(checkpoint_data) if checkpoint_data else {},
        )
        self.requests[approval_id] = req
        return req

    def resolve_request(
        self,
        approval_id: str,
        *,
        decision: str, # approved, rejected
        approver_id: str,
        rationale: str = "",
    ) -> bool:
        """
        Transition a pending request to approved or rejected.
        """
        req = self.requests.get(approval_id)
        if not req or req.status != "pending":
            return False

        if decision not in ("approved", "rejected"):
            raise ValueError("Decision must be either 'approved' or 'rejected'")

        req.status = decision
        req.approver_id = approver_id
        req.decision_rationale = rationale
        req.resolved_at = time.time()
        return True

    def check_and_apply_timeouts(self, now: Optional[float] = None) -> List[Tuple[str, str]]:
        """
        Scans requests and processes any timeouts based on risk tier rules.
        Returns a list of tuples containing (approval_id, action_taken).
        """
        current_time = now or time.time()
        expired_events = []

        for approval_id, req in self.requests.items():
            if req.status != "pending":
                continue

            if current_time - req.created_at >= req.timeout_seconds:
                # Process timeout behavior depending on risk tier
                if req.risk_tier == "T4":
                    # Hard-fail/reject for T4 irreversible actions
                    req.status = "rejected"
                    req.decision_rationale = "Timeout: Automatic rejection for T4 high-risk action"
                    req.resolved_at = current_time
                    expired_events.append((approval_id, "auto_rejected_t4"))
                elif req.risk_tier == "T3":
                    # Escalate to secondary target in the ladder
                    if req.escalation_path:
                        next_target = req.escalation_path[0]
                        req.status = "escalated"
                        req.decision_rationale = f"Timeout: Escalated to fallback target {next_target}"
                        req.resolved_at = current_time
                        expired_events.append((approval_id, f"escalated_to_{next_target}"))
                    else:
                        req.status = "rejected"
                        req.decision_rationale = "Timeout: Automatic rejection (empty escalation path)"
                        req.resolved_at = current_time
                        expired_events.append((approval_id, "auto_rejected_t3_no_fallback"))
                else:
                    # Default safe roll-back / fail-closed for T0-T2
                    req.status = "rejected"
                    req.decision_rationale = "Timeout: Default fail-closed rollback"
                    req.resolved_at = current_time
                    expired_events.append((approval_id, "auto_rejected_default"))

        return expired_events

    def get_resume_checkpoint(self, approval_id: str) -> Optional[Dict[str, str]]:
        """
        Retrieves the exact pre-saved state checkpoint for a previously approved session
        to guarantee deterministic resume semantics.
        """
        req = self.requests.get(approval_id)
        if not req or req.status != "approved":
            return None
        return req.checkpoint_data
