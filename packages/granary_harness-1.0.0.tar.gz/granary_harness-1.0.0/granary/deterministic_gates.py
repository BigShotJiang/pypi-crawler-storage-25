from __future__ import annotations

import re
from dataclasses import dataclass
from enum import IntEnum
from typing import Dict, Iterable, List, Tuple


class TaintLevel(IntEnum):
    TRUSTED_HIGH = 0
    TRUSTED_MEDIUM = 1
    UNTRUSTED_LOW = 2


@dataclass(slots=True)
class GateVerdict:
    allowed: bool
    reason: str
    risk_dimensions: int


class DeterministicGateEngine:
    """
    Non-LLM policy engine:
    - Sanitizes known injection markers
    - Tracks taint via a lattice meet operation
    - Enforces rule-of-two style gating
    """

    def __init__(self, extra_patterns: Iterable[str] | None = None) -> None:
        base_patterns = [
            r"(?i)ignore\s+previous\s+instructions",
            r"(?i)system\s+prompt",
            r"(?i)<script\b[^>]*>",
            r"[\U000E0000-\U000E007F]",  # invisible tag chars
            r"(?i)\b(base64\s+-d|curl\s+.+\|\s*sh)\b",
        ]
        if extra_patterns:
            base_patterns.extend(extra_patterns)
        self._compiled = [re.compile(pattern) for pattern in base_patterns]

    def sanitize_text(self, text: str) -> Tuple[str, List[str]]:
        findings: List[str] = []
        sanitized = text
        for pattern in self._compiled:
            if pattern.search(sanitized):
                findings.append(pattern.pattern)
                sanitized = pattern.sub("[REDACTED]", sanitized)
        return sanitized, findings

    def propagate_taint(self, *levels: TaintLevel) -> TaintLevel:
        # Meet operation for integrity lattice: most restrictive wins.
        return max(levels, default=TaintLevel.TRUSTED_HIGH)

    def evaluate_tool_call(
        self,
        *,
        input_taint: TaintLevel,
        touches_sensitive_system: bool,
        external_state_change: bool,
    ) -> GateVerdict:
        risk = 0
        if input_taint >= TaintLevel.UNTRUSTED_LOW:
            risk += 1
        if touches_sensitive_system:
            risk += 1
        if external_state_change:
            risk += 1

        if risk >= 2:
            return GateVerdict(
                allowed=False,
                reason="rule_of_two_block",
                risk_dimensions=risk,
            )
        return GateVerdict(
            allowed=True,
            reason="risk_below_threshold",
            risk_dimensions=risk,
        )


def evaluate_named_variables_taint(
    source_taints: Dict[str, TaintLevel],
    assignments: Iterable[Tuple[str, List[str]]],
) -> Dict[str, TaintLevel]:
    """
    Propagate taint across assignments.

    Example assignment tuple:
      ("combined_prompt", ["web_result", "user_input"])
    """
    taints = dict(source_taints)
    engine = DeterministicGateEngine()
    for target, sources in assignments:
        taints[target] = engine.propagate_taint(*(taints[s] for s in sources if s in taints))
    return taints
