from __future__ import annotations

import hashlib
import hmac
import json
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set


@dataclass(slots=True)
class AuditEvent:
    event_id: str
    session_id: str
    sequence_number: int
    event_type: str # PROMPT_INPUT, TOOL_REQUEST, TOOL_RESPONSE, SECURITY_ALERT, STATE_SNAPSHOT
    actor_type: str # USER, PLANNER_LLM, QUARANTINE_LLM, SANDBOX_TOOL, GATEWAY
    payload_json: str
    parent_event_hash: str
    current_event_hash: str
    recorded_at: float
    hsm_signature: Optional[str] = None


class AuditManager:
    """
    Implements the append-only, tamper-evident Merkle-chained Audit Ledger
    required for ISO 42001 and EU AI Act compliance.
    """

    def __init__(self, secret_signing_key: str = "granary-hsm-signer-key") -> None:
        self.secret_signing_key = secret_signing_key
        self.ledger: List[AuditEvent] = []
        self.last_hash: str = "0" * 64
        self.legal_holds: Set[str] = set() # Set of session_ids under legal hold
        
        # Redaction list to prevent leaking sensitive credentials in audit logs
        self.sensitive_keywords = {
            "password", "secret", "token", "key", "authorization", 
            "private", "credential", "api_key", "bearer", "session"
        }

    def redact_payload(self, payload: dict) -> dict:
        """
        Recursively redact sensitive credential keys from log payloads.
        """
        redacted = {}
        for k, v in payload.items():
            k_lower = k.lower()
            if any(kw in k_lower for kw in self.sensitive_keywords):
                redacted[k] = "[REDACTED_SENSITIVE]"
            elif isinstance(v, dict):
                redacted[k] = self.redact_payload(v)
            elif isinstance(v, list):
                redacted[k] = [
                    self.redact_payload(item) if isinstance(item, dict) else item 
                    for item in v
                ]
            else:
                redacted[k] = v
        return redacted

    def append_log(
        self,
        *,
        session_id: str,
        event_type: str,
        actor_type: str,
        payload: dict,
    ) -> AuditEvent:
        """
        Appends a masked, Merkle-chained, and HSM-signed audit event to the ledger.
        """
        now = time.time()
        seq_num = len(self.ledger) + 1
        
        # 1. Redact payload
        safe_payload = self.redact_payload(payload)
        payload_str = json.dumps(safe_payload, sort_keys=True, separators=(",", ":"))
        
        # 2. Compute parent hash and current event hash
        parent_hash = self.last_hash
        
        hasher = hashlib.sha256()
        hasher.update(f"{session_id}:{seq_num}:{payload_str}:{parent_hash}".encode("utf-8"))
        current_hash = hasher.hexdigest()
        
        # 3. Generate simulated HSM signature over current hash using HMAC-SHA256
        sig = hmac.new(
            self.secret_signing_key.encode("utf-8"),
            current_hash.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()

        event = AuditEvent(
            event_id=f"evt_{current_hash[:16]}",
            session_id=session_id,
            sequence_number=seq_num,
            event_type=event_type,
            actor_type=actor_type,
            payload_json=payload_str,
            parent_event_hash=parent_hash,
            current_event_hash=current_hash,
            recorded_at=now,
            hsm_signature=sig,
        )

        self.ledger.append(event)
        self.last_hash = current_hash
        return event

    def verify_chain_integrity(self) -> Tuple[bool, str]:
        """
        Performs a full cryptographic validation scan over the ledger chain.
        """
        expected_parent_hash = "0" * 64
        
        for idx, event in enumerate(self.ledger):
            # Check parent hash match
            if event.parent_event_hash != expected_parent_hash:
                return False, f"Integrity break at sequence {event.sequence_number}: parent hash mismatch"
            
            # Recalculate and verify current event hash
            hasher = hashlib.sha256()
            hasher.update(f"{event.session_id}:{event.sequence_number}:{event.payload_json}:{event.parent_event_hash}".encode("utf-8"))
            recalculated_hash = hasher.hexdigest()
            
            if event.current_event_hash != recalculated_hash:
                return False, f"Integrity break at sequence {event.sequence_number}: current hash altered"
            
            # Verify HSM signature
            expected_sig = hmac.new(
                self.secret_signing_key.encode("utf-8"),
                event.current_event_hash.encode("utf-8"),
                hashlib.sha256
            ).hexdigest()
            
            if not hmac.compare_digest(event.hsm_signature, expected_sig):
                return False, f"Integrity break at sequence {event.sequence_number}: invalid HSM signature"
                
            expected_parent_hash = event.current_event_hash

        return True, "All audit events successfully verified: chain matches cryptographic Merkle roots"

    def apply_retention_policy(self, max_age_seconds: int, now: Optional[float] = None) -> int:
        """
        Purges expired logs older than max_age_seconds, unless session is flagged under legal hold.
        Returns count of purged records.
        """
        current_time = now or time.time()
        original_count = len(self.ledger)
        
        # Retain only unexpired or legal-held logs
        self.ledger = [
            event for event in self.ledger
            if (current_time - event.recorded_at < max_age_seconds) or (event.session_id in self.legal_holds)
        ]
        
        # Re-chain last_hash if elements were removed to ensure continuity of subsequent appends
        if len(self.ledger) < original_count:
            if self.ledger:
                self.last_hash = self.ledger[-1].current_event_hash
            else:
                self.last_hash = "0" * 64

        return original_count - len(self.ledger)

    def set_legal_hold(self, session_id: str, active: bool) -> None:
        if active:
            self.legal_holds.add(session_id)
        else:
            self.legal_holds.discard(session_id)
