"""
Granary MCP Trust Gateway — stdio MCP server for Cursor / Claude agent sessions.
"""

from __future__ import annotations

import json
import time
from typing import Any

from granary.mcp_gateway_config import build_gateway
from granary.mcp_security import McpTrustGateway, RiskTier

_gateway: McpTrustGateway | None = None


def get_gateway() -> McpTrustGateway:
    global _gateway
    if _gateway is None:
        _gateway = build_gateway()
    return _gateway


def reset_gateway() -> None:
    global _gateway
    _gateway = None


def authorize_mcp_tool(
    principal: str,
    tool_name: str,
    claims_json: str,
    principal_allow: list[str] | None = None,
) -> dict[str, Any]:
    claims = json.loads(claims_json)
    allowed = principal_allow or [RiskTier.T0, RiskTier.T1, RiskTier.T2, RiskTier.T3]
    return get_gateway().authorize_tool(
        principal=principal,
        tool_name=tool_name,
        claims=claims,
        principal_allow=allowed,
    )


def approve_mcp_pending(pending_id: str, approver: str) -> dict[str, Any]:
    ok = get_gateway().approve_pending(pending_id, approver)
    return {"approved": ok, "pending_id": pending_id, "approver": approver}


def validate_oauth_redirect(uri: str) -> dict[str, Any]:
    allowed = get_gateway().validate_redirect_uri(uri)
    return {"uri": uri, "allowed": allowed}


def list_pending_approvals() -> dict[str, Any]:
    pending = get_gateway()._pending
    now = time.time()
    items = [
        {
            "pending_id": pid,
            "principal": rec["principal"],
            "tool": rec["tool"],
            "tier": rec["tier"],
            "age_seconds": round(now - rec["created_at"], 1),
        }
        for pid, rec in pending.items()
    ]
    return {"count": len(items), "pending": items}


def run_stdio_server() -> None:
    from mcp.server.fastmcp import FastMCP

    mcp = FastMCP("granary-gateway")

    @mcp.tool()
    def granary_authorize_tool(
        principal: str,
        tool_name: str,
        claims_json: str,
        principal_allow: list[str] | None = None,
    ) -> dict[str, Any]:
        return authorize_mcp_tool(principal, tool_name, claims_json, principal_allow)

    @mcp.tool()
    def granary_approve_pending(pending_id: str, approver: str) -> dict[str, Any]:
        return approve_mcp_pending(pending_id, approver)

    @mcp.tool()
    def granary_validate_redirect(uri: str) -> dict[str, Any]:
        return validate_oauth_redirect(uri)

    @mcp.tool()
    def granary_list_pending() -> dict[str, Any]:
        return list_pending_approvals()

    mcp.run(transport="stdio")


def main() -> None:
    run_stdio_server()


if __name__ == "__main__":
    main()
