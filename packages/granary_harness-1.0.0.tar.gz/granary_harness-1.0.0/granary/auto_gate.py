from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


class GateState(str, Enum):
    PROPOSED = "proposed"
    SHADOW = "shadow"
    ADVISORY = "advisory"
    BLOCKING = "blocking"
    DEPRECATED = "deprecated"


@dataclass(slots=True)
class GateClause:
    field_name: str
    op: str  # gte | lte | eq | lt | gt
    value: Any


@dataclass(slots=True)
class AgentGate:
    id: str
    version: int
    lifecycle_state: GateState
    owner: str
    applies_to: List[str]
    modules: List[str]
    predicate_op: str  # and | or
    clauses: List[GateClause]
    effect_mode: str  # shadow | advisory | blocking
    on_fail_action: str  # block | downweight | require_second_opinion
    weight_multiplier: float = 0.3
    message: str = "Gate condition failed"
    
    # Promotion Ralph Parameters
    min_shadow_steps: int = 500
    min_canary_steps: int = 1000
    holdout_fraction: float = 0.15
    promotion_metric: str = "outcome_win_rate"
    min_delta: float = 0.02
    promote_above: float = 0.58
    demote_below: float = 0.52
    min_steps_between_transitions: int = 200
    
    # Anti-gaming
    stratify_by: List[str] = field(default_factory=list)
    min_samples_per_stratum: int = 25
    require_holdout_improvement: bool = True
    max_weight_adjustment_per_step: float = 0.05
    
    # Status telemetry
    shadow_violations: int = 0
    shadow_passes: int = 0
    holdout_delta: float = 0.0
    last_eval_step: int = 0
    steps_in_state: int = 0
    win_rate_history: List[float] = field(default_factory=list)


class AutoGateManager:
    """
    Manages automated policy gates, predicate evaluations, and Ralph-Style state transitions.
    """

    def __init__(self) -> None:
        self.gates: Dict[str, AgentGate] = {}

    def register_gate(self, gate: AgentGate) -> None:
        self.gates[gate.id] = gate

    def evaluate_predicate(self, gate_id: str, payload: dict) -> bool:
        """
        Evaluates the composite predicates (AND/OR clauses) of the gate against a payload dictionary.
        """
        gate = self.gates.get(gate_id)
        if not gate:
            return True # If gate not registered, pass

        results = []
        for clause in gate.clauses:
            val = self._resolve_dotted_path(payload, clause.field_name)
            if val is None:
                results.append(False)
                continue

            # Compare operators
            if clause.op == "eq":
                results.append(val == clause.value)
            elif clause.op == "gte":
                results.append(val >= clause.value)
            elif clause.op == "lte":
                results.append(val <= clause.value)
            elif clause.op == "gt":
                results.append(val > clause.value)
            elif clause.op == "lt":
                results.append(val < clause.value)
            else:
                results.append(False)

        if gate.predicate_op == "and":
            return all(results) if results else False
        return any(results) if results else False

    def evaluate_gate_lifecycle_transition(
        self,
        gate_id: str,
        *,
        current_step: int,
        rolling_win_rate: float,
        control_win_rate: float,
    ) -> GateState:
        """
        Ralph-Style Hysteresis Promotion Algorithm:
        - proposed -> shadow (manual/validation)
        - shadow -> advisory: evaluated on 15% holdout. Win rate higher than control by >= min_delta over >= 500 steps.
        - advisory -> blocking: win rate >= 0.58 held for >= 1000 steps.
        - blocking -> shadow: win rate < 0.52 with >= 100 samples.
        """
        gate = self.gates.get(gate_id)
        if not gate:
            return GateState.DEPRECATED

        current = gate.lifecycle_state
        step_delta = current_step - gate.last_eval_step
        gate.last_eval_step = current_step
        gate.steps_in_state += step_delta
        gate.win_rate_history.append(rolling_win_rate)

        if current == GateState.SHADOW:
            delta = rolling_win_rate - control_win_rate
            gate.holdout_delta = delta
            if gate.steps_in_state >= gate.min_shadow_steps and delta >= gate.min_delta:
                # Transition to ADVISORY
                gate.lifecycle_state = GateState.ADVISORY
                gate.steps_in_state = 0

        elif current == GateState.ADVISORY:
            if gate.steps_in_state >= gate.min_canary_steps and rolling_win_rate >= gate.promote_above:
                # Transition to BLOCKING
                gate.lifecycle_state = GateState.BLOCKING
                gate.steps_in_state = 0

        elif current == GateState.BLOCKING:
            # Trigger demotion back to SHADOW if performance regresses below demote_below
            if len(gate.win_rate_history) >= 100 and rolling_win_rate < gate.demote_below:
                gate.lifecycle_state = GateState.SHADOW
                gate.steps_in_state = 0

        return gate.lifecycle_state

    def apply_gate_effect_multiplier(self, gate_id: str, weight: float, payload: dict) -> float:
        """
        Applies a maximum weight reduction of weight_multiplier (typically 0.3) on advisory gate failure.
        """
        gate = self.gates.get(gate_id)
        if not gate or gate.lifecycle_state != GateState.ADVISORY:
            return weight

        passed = self.evaluate_predicate(gate_id, payload)
        if not passed:
            # Downweight on fail
            return round(weight * gate.weight_multiplier, 4)
        return weight

    def _resolve_dotted_path(self, dct: dict, path: str) -> Any:
        parts = path.split(".")
        curr = dct
        for p in parts:
            if isinstance(curr, dict) and p in curr:
                curr = curr[p]
            else:
                return None
        return curr
