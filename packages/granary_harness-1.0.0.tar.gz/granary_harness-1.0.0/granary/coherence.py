from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Set, Tuple


log = logging.getLogger(__name__)


class SubsystemState(str, Enum):
    INIT = "initiated"
    GOVERNANCE_PASSED = "governance_passed"
    ORCHESTRATION_READY = "orchestration_ready"
    MEMORY_STORED = "memory_stored"
    EVALUATION_VERIFIED = "evaluation_verified"
    ROLLOUT_COMMITTED = "rollout_committed"
    OUTCOME_COMPLETED = "outcome_completed"


class IntelligenceUpgradeStage(int, Enum):
    OUTCOME_CLOSED = 1
    CALIBRATED_ROUTING = 2
    TYPED_DECOMPOSITION = 3
    CRITIC_VALIDATOR_SPLIT = 4
    MEMORY_QUALITY_GATES = 5


@dataclass(slots=True)
class CoherenceWorkUnit:
    work_unit_id: str
    subsystem_state: SubsystemState = SubsystemState.INIT
    evidence_references: List[str] = field(default_factory=list)
    circuit_breakers_tripped: Set[str] = field(default_factory=set)
    unmatched_quarantined: bool = False
    active_upgrade_stage: IntelligenceUpgradeStage = IntelligenceUpgradeStage.OUTCOME_CLOSED


class CoherenceContractManager:
    """
    Enforces the unified end-to-end Coherence Contract across all agent subsystems.
    """

    def __init__(self) -> None:
        self.active_work_units: Dict[str, CoherenceWorkUnit] = {}

    def register_work_unit(self, work_unit_id: str) -> CoherenceWorkUnit:
        unit = CoherenceWorkUnit(work_unit_id=work_unit_id)
        self.active_work_units[work_unit_id] = unit
        return unit

    def advance_subsystem_state(
        self,
        work_unit_id: str,
        target_state: SubsystemState,
        evidence: Optional[str] = None
    ) -> Tuple[bool, str]:
        """
        Enforces sequential, gated progress of a work unit.
        - No rollout without a verified evaluation.
        - Requires adding evidence references on mutating transitions.
        """
        unit = self.active_work_units.get(work_unit_id)
        if not unit:
            return False, "work_unit_not_registered"

        # Validate sequence
        state_order = [
            SubsystemState.INIT,
            SubsystemState.GOVERNANCE_PASSED,
            SubsystemState.ORCHESTRATION_READY,
            SubsystemState.MEMORY_STORED,
            SubsystemState.EVALUATION_VERIFIED,
            SubsystemState.ROLLOUT_COMMITTED,
            SubsystemState.OUTCOME_COMPLETED,
        ]
        
        curr_idx = state_order.index(unit.subsystem_state)
        target_idx = state_order.index(target_state)

        if target_idx != curr_idx + 1:
            return False, f"invalid_state_transition_sequence: expected next is {state_order[curr_idx + 1]}"

        # Enforce "No rollout without verified evaluation"
        if target_state == SubsystemState.ROLLOUT_COMMITTED:
            if unit.subsystem_state != SubsystemState.EVALUATION_VERIFIED:
                return False, "rollout_blocked: missing_evaluation_verification"
            if not evidence:
                return False, "rollout_blocked: missing_conformance_evidence"

        if evidence:
            unit.evidence_references.append(evidence)

        unit.subsystem_state = target_state
        return True, "state_advanced"

    def contain_failure_boundary(self, work_unit_id: str, tripped_breaker: str) -> None:
        """
        Enforces strict failure containment per subsystem.
        """
        unit = self.active_work_units.get(work_unit_id)
        if unit:
            unit.circuit_breakers_tripped.add(tripped_breaker)

    def validate_intelligence_upgrade(
        self,
        work_unit_id: str,
        proposed_stage: IntelligenceUpgradeStage
    ) -> Tuple[bool, str]:
        """
        Enforces the Intelligence Critical Path. Upgrades must proceed strictly in order:
        1. outcome-closed learning signals,
        2. calibrated routing with abstain/escalate,
        3. typed decomposition with validators,
        4. critic/validator split (sync hard gates + async critic),
        5. memory quality gates tied to outcomes.
        """
        unit = self.active_work_units.get(work_unit_id)
        if not unit:
            return False, "work_unit_not_registered"

        current_stage = unit.active_upgrade_stage
        if proposed_stage == current_stage + 1:
            unit.active_upgrade_stage = proposed_stage
            return True, "upgrade_stage_authorized"
            
        return False, f"critical_path_violation: cannot jump from {current_stage.name} to {proposed_stage.name}"
