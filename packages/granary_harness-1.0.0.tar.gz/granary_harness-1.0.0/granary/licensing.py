from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List


@dataclass(slots=True)
class LicensePayload:
    customer_id: str
    license_tier: str
    issued_at: int
    expires_at: int
    max_concurrent_sandboxes: int
    authorized_pcr_roots: List[str]
    enabled_modules: List[str] = field(default_factory=list)
    deployment_mode: str = "vpc"
    operator_scope: str = "cluster"
    node_lock_fingerprint: str = ""

    def to_dict(self) -> Dict[str, object]:
        return {
            "customer_id": self.customer_id,
            "license_tier": self.license_tier,
            "issued_at": self.issued_at,
            "expires_at": self.expires_at,
            "max_concurrent_sandboxes": self.max_concurrent_sandboxes,
            "authorized_pcr_roots": self.authorized_pcr_roots,
            "enabled_modules": self.enabled_modules,
            "deployment_mode": self.deployment_mode,
            "operator_scope": self.operator_scope,
            "node_lock_fingerprint": self.node_lock_fingerprint,
        }

    def validate(self, now_ts: int | None = None) -> None:
        if self.max_concurrent_sandboxes <= 0:
            raise ValueError("max_concurrent_sandboxes must be positive")
        if self.expires_at <= self.issued_at:
            raise ValueError("expires_at must be after issued_at")
        if not self.authorized_pcr_roots:
            raise ValueError("authorized_pcr_roots cannot be empty")
        if now_ts is not None and self.expires_at < now_ts:
            raise ValueError("license is expired")


def generate_node_lock_fingerprint(hostname: str, instance_id: str, cpu_model: str) -> str:
    material = f"{hostname}|{instance_id}|{cpu_model}".encode("utf-8")
    return hashlib.sha256(material).hexdigest()


def sign_license(payload: LicensePayload, secret: str) -> str:
    payload.validate()
    encoded = json.dumps(payload.to_dict(), sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hmac.new(secret.encode("utf-8"), encoded, hashlib.sha256).hexdigest()


def verify_license(payload: LicensePayload, signature: str, secret: str) -> bool:
    expected = sign_license(payload, secret)
    return hmac.compare_digest(signature, expected)


def create_default_vpc_operator_license(
    *,
    customer_id: str,
    max_concurrent_sandboxes: int,
    authorized_pcr_roots: List[str],
    enabled_modules: List[str],
    node_lock_fingerprint: str,
    validity_days: int = 365,
) -> LicensePayload:
    now = int(datetime.now(timezone.utc).timestamp())
    return LicensePayload(
        customer_id=customer_id,
        license_tier="ENTERPRISE_VPC",
        issued_at=now,
        expires_at=now + (validity_days * 24 * 60 * 60),
        max_concurrent_sandboxes=max_concurrent_sandboxes,
        authorized_pcr_roots=authorized_pcr_roots,
        enabled_modules=enabled_modules,
        deployment_mode="vpc",
        operator_scope="cluster",
        node_lock_fingerprint=node_lock_fingerprint,
    )
