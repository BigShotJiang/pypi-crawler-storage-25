from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple


@dataclass(slots=True)
class LedgerRow:
    row_id: str
    source: str
    policy_id: str
    scan_id: str
    recorded_at: float
    data: dict = field(default_factory=dict)


class ContaminationAwareEvaluator:
    """
    Implements contamination hygiene, leakage detection, stratified aggregation,
    and promotion blockade checks.
    """

    def __init__(self) -> None:
        # Sources to explicitly exclude from production metric pools
        self.excluded_sources = {"seed", "test", "synthetic", "demo"}
        self.exclusion_pattern = re.compile(r"^(seed.*|test.*|synthetic.*|demo.*)$", re.IGNORECASE)

    def is_contaminated_source(self, source: str) -> bool:
        """
        Check if the source matches any of the excluded/test namespaces.
        """
        return bool(self.exclusion_pattern.match(source))

    def detect_leakage(self, train_set: Set[str], eval_set: Set[str]) -> float:
        """
        Computes the overlap ratio between train and evaluation sets.
        Overlap = len(train & eval) / len(eval)
        """
        if not eval_set:
            return 0.0
        overlap = train_set & eval_set
        return len(overlap) / len(eval_set)

    def detect_sequence_leakage(self, train_seq: List[Tuple[int, float]], eval_seq: List[Tuple[int, float]]) -> float:
        """
        Computes the leakage ratio for sequence/timestamp-aligned datasets.
        Inputs: Lists of tuples (item_id, timestamp).
        """
        if not eval_seq:
            return 0.0
        train_set = set(train_seq)
        eval_set = set(eval_seq)
        overlap = train_set & eval_set
        return len(overlap) / len(eval_set)

    def generate_stratified_report(
        self,
        rows: List[LedgerRow],
        stratum_key: str, # e.g. "grade", "signal_type"
    ) -> dict[str, dict[str, Any]]:
        """
        Aggregates metrics separately per stratum.
        Each stratum contains 'wins', 'losses', 'accuracy', and 'n'.
        """
        strata_stats = {}
        for row in rows:
            # Skip contaminated/test sources
            if self.is_contaminated_source(row.source):
                continue

            val = row.data.get(stratum_key)
            if val is None:
                continue

            stat = strata_stats.setdefault(val, {"wins": 0, "losses": 0})
            is_win = row.data.get("is_correct", False)
            if is_win:
                stat["wins"] += 1
            else:
                stat["losses"] += 1

        report = {}
        for s, stats in strata_stats.items():
            n = stats["wins"] + stats["losses"]
            accuracy = stats["wins"] / n if n > 0 else 0.0
            report[str(s)] = {
                "n": n,
                "wins": stats["wins"],
                "losses": stats["losses"],
                "accuracy": round(accuracy, 4),
            }
        return report

    def check_promotion_blocker(
        self,
        *,
        train_set: Set[str],
        eval_set: Set[str],
        rows: List[LedgerRow],
        global_accuracy: float,
        stratum_key: str,
        leakage_limit: float = 0.02,
        underperformance_limit_pp: float = 0.10,
    ) -> Tuple[bool, List[str]]:
        """
        Enforces promotion blockade conditions:
        - Leakage ratio exceeds limit.
        - Any stratum with n >= 5 has win rate < global - 10pp.
        """
        blockers = []

        # 1. Leakage Check
        leakage = self.detect_leakage(train_set, eval_set)
        if leakage > leakage_limit:
            blockers.append(f"leakage_limit_exceeded(leakage={leakage:.4f}>{leakage_limit})")

        # 2. Underperformance / Discrepancy Check per stratum
        report = self.generate_stratified_report(rows, stratum_key)
        for s, stats in report.items():
            if stats["n"] >= 5:
                if stats["accuracy"] < (global_accuracy - underperformance_limit_pp):
                    blockers.append(
                        f"stratum_underperformance_violation(stratum={s}, wr={stats['accuracy']:.4f}<threshold={global_accuracy - underperformance_limit_pp:.4f})"
                    )

        return len(blockers) == 0, blockers

    def generate_contamination_report(
        self,
        *,
        train_set: Set[str],
        eval_set: Set[str],
        rows: List[LedgerRow],
        global_accuracy: float,
        stratum_key: str,
    ) -> dict[str, Any]:
        """
        Generates a structured dictionary representing the clean-versus-contaminated reporting format.
        """
        leakage = self.detect_leakage(train_set, eval_set)
        is_admitted, blockers = self.check_promotion_blocker(
            train_set=train_set,
            eval_set=eval_set,
            rows=rows,
            global_accuracy=global_accuracy,
            stratum_key=stratum_key,
        )
        
        return {
            "report_timestamp": time.time(),
            "metrics": {
                "total_eval_samples": len(eval_set),
                "total_train_samples": len(train_set),
                "leakage_ratio": round(leakage, 6),
                "contaminated_samples_count": len(train_set & eval_set),
            },
            "status": "BLOCKED" if not is_admitted else "CLEAN",
            "blockers": blockers,
            "strata_analysis": self.generate_stratified_report(rows, stratum_key)
        }

