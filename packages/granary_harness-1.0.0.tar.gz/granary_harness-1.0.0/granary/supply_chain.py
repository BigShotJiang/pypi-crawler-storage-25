from __future__ import annotations

import hashlib
import hmac
import json
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


@dataclass(slots=True)
class ModelArtifact:
    artifact_id: str
    digest_sha256: str
    signature: str
    sbom_attestation: str # JSON-serialized SBOM data


@dataclass(slots=True)
class AdmissionVerdict:
    admitted: bool
    reason: str
    provenance_verified: bool


class ServingAdmissionController:
    """
    Enforces secure model-serving admission policies. Unsigned, unverified,
    or non-conforming SBOM/attestation artifacts are strictly blocked from execution.
    """

    def __init__(self, public_verification_key: str = "granary-supply-chain-key") -> None:
        self.public_verification_key = public_verification_key

    def verify_signature(self, artifact: ModelArtifact) -> bool:
        """
        Cryptographically verifies the artifact digest's signature.
        """
        # In this secure python implementation, we utilize HMAC-SHA256 signature matching
        expected_sig = hmac.new(
            self.public_verification_key.encode("utf-8"),
            artifact.digest_sha256.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()
        return hmac.compare_digest(artifact.signature, expected_sig)

    def verify_sbom_attestation(self, artifact: ModelArtifact) -> Tuple[bool, str]:
        """
        Verifies attached SBOM attestation structure, packages list, and provenance chain.
        """
        try:
            sbom = json.loads(artifact.sbom_attestation)
        except (json.JSONDecodeError, TypeError):
            return False, "invalid_json_format"

        required_keys = ["format", "version", "packages", "provenance_chain"]
        for key in required_keys:
            if key not in sbom:
                return False, f"missing_required_sbom_field:{key}"

        # Validate format is SPDX or CycloneDX and contains a non-empty packages list
        if sbom["format"].lower() not in ("spdx", "cyclonedx"):
            return False, f"unsupported_sbom_format:{sbom['format']}"

        if not isinstance(sbom["packages"], list) or not sbom["packages"]:
            return False, "empty_packages_list"

        # Validate provenance chain contains compile/test environment references
        prov_chain = sbom["provenance_chain"]
        if not isinstance(prov_chain, list) or not prov_chain:
            return False, "missing_provenance_chain"

        for entry in prov_chain:
            if not isinstance(entry, dict) or "environment" not in entry or "build_step" not in entry:
                return False, "invalid_provenance_entry"

        return True, "verified"

    def evaluate_admission(self, artifact: ModelArtifact) -> AdmissionVerdict:
        """
        Executes strict admission control checks before deploying or running any model serving container.
        """
        # 1. Verify cryptographic signature
        if not self.verify_signature(artifact):
            return AdmissionVerdict(
                admitted=False,
                reason="cryptographic_signature_verification_failed",
                provenance_verified=False,
            )

        # 2. Verify SBOM completeness
        sbom_ok, sbom_reason = self.verify_sbom_attestation(artifact)
        if not sbom_ok:
            return AdmissionVerdict(
                admitted=False,
                reason=f"sbom_validation_failed:{sbom_reason}",
                provenance_verified=False,
            )

        # 3. Check for matching digest in provenance build step
        sbom = json.loads(artifact.sbom_attestation)
        provenance_digest = sbom["provenance_chain"][-1].get("tested_digest")
        if provenance_digest != artifact.digest_sha256:
            return AdmissionVerdict(
                admitted=False,
                reason="provenance_digest_mismatch",
                provenance_verified=False,
            )

        return AdmissionVerdict(
            admitted=True,
            reason="admitted",
            provenance_verified=True,
        )


def sign_artifact_digest(digest: str, private_key: str) -> str:
    """
    Utility helper to sign model digests during continuous integration compilation.
    """
    return hmac.new(
        private_key.encode("utf-8"),
        digest.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
