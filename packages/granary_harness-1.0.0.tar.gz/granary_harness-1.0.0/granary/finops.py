from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass(slots=True)
class TokenPricing:
    input_cost_per_1k: float
    output_cost_per_1k: float


def calculate_saved_cogs(
    *,
    blocked_events: int,
    avg_prompt_tokens: int,
    avg_completion_tokens: int,
    pricing: TokenPricing,
) -> Dict[str, float]:
    """
    Estimate avoided model spend from pre-execution blocking.
    """
    if blocked_events < 0:
        raise ValueError("blocked_events must be >= 0")

    input_tokens_saved = blocked_events * avg_prompt_tokens
    output_tokens_saved = blocked_events * avg_completion_tokens
    input_cost = (input_tokens_saved / 1000.0) * pricing.input_cost_per_1k
    output_cost = (output_tokens_saved / 1000.0) * pricing.output_cost_per_1k
    total = input_cost + output_cost
    return {
        "blocked_events": float(blocked_events),
        "input_tokens_saved": float(input_tokens_saved),
        "output_tokens_saved": float(output_tokens_saved),
        "saved_cogs_usd": round(total, 8),
    }


class TurnState:
    NORMAL = "normal"
    COMPACT = "compact"
    DEGRADED = "degraded"
    ESCALATE = "escalate"
    HALT = "halt"


class FinOpsController:
    COST = {
        "neural": 1,
        "llm": 50,
        "hybrid": 55,
        "intermod": 40,
        "chain_hop": 1
    }

    def __init__(self, cost_limit: float = 500.0):
        self.cost_limit = cost_limit
        self.cost_remaining = cost_limit
        self.turn_state = TurnState.NORMAL
        self._l1 = {}

    def build_prompt_envelope(
        self,
        methodology: str,
        system_state: dict,
        ranker_params: dict,
        user_query: str,
        context: dict = None
    ) -> dict:
        prefix = {
            "methodology": methodology,
            "system_state": system_state,
            "ranker_params": ranker_params
        }
        canonical = json.dumps(prefix, sort_keys=True, separators=(",", ":"))
        prefix_hash = "sha256:" + hashlib.sha256(canonical.encode()).hexdigest()
        return {
            "schema_version": "1.0.0",
            "prefix": prefix,
            "suffix": {"user_query": user_query, "context": context or {}},
            "prefix_hash": prefix_hash
        }

    def render_for_llm(self, envelope: dict) -> str:
        p = json.dumps(envelope["prefix"], sort_keys=True)
        s = json.dumps(envelope["suffix"], sort_keys=True)
        return f"<<sPREFIX {envelope['prefix_hash']}>>>\n{p}\n<<<SUFFIX>>>\n{s}"

    def charge(self, module_type: str, hops: int = 1, intermod: bool = False) -> bool:
        unit = self.COST.get(module_type, 10)
        if intermod:
            unit += self.COST["intermod"]
        unit += hops * self.COST["chain_hop"]
        if self.cost_remaining < unit:
            self._transition("BUDGET_LOW")
            return False
        self.cost_remaining -= unit
        return True

    def effective_chain_depth(self, default_depth: int) -> int:
        if self.turn_state == TurnState.DEGRADED:
            return 1
        if self.turn_state in (TurnState.COMPACT, TurnState.HALT, TurnState.ESCALATE):
            return 0 if self.turn_state == TurnState.HALT else 1
        return default_depth

    def _transition(self, event: str) -> None:
        table = {
            (TurnState.NORMAL, "BUDGET_LOW"): TurnState.COMPACT,
            (TurnState.NORMAL, "MODULE_FAULT"): TurnState.DEGRADED,
            (TurnState.COMPACT, "BUDGET_EXHAUSTED"): TurnState.ESCALATE,
            (TurnState.COMPACT, "CHAIN_TOTAL_FAILURE"): TurnState.HALT,
            (TurnState.DEGRADED, "CHAIN_TOTAL_FAILURE"): TurnState.HALT,
            (TurnState.DEGRADED, "PROBE_SUCCESS"): TurnState.NORMAL,
            (TurnState.ESCALATE, "HUMAN_CLEAR"): TurnState.NORMAL,
            (TurnState.ESCALATE, "TIMEOUT"): TurnState.HALT,
        }
        nxt = table.get((self.turn_state, event))
        if nxt:
            self.turn_state = nxt

    def compact_chain_log(self, chain_log: list, max_chars: int = 4000) -> str:
        if not chain_log:
            return ""
        parts = []
        for i, entry in enumerate(chain_log):
            if i < len(chain_log) - 1:
                parts.append(
                    f"{entry.get('module')}: conf={entry.get('confidence', 0):.2f} "
                    f"keys={list((entry.get('predictions') or {}).keys())[:4]}"
                )
            else:
                parts.append(json.dumps(entry, default=str)[:max_chars // 2])
        blob = "\n".join(parts)
        return blob[:max_chars] if len(blob) > max_chars else blob
