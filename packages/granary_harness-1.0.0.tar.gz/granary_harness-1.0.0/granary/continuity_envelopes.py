from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple


class EnvelopeKind:
    SHSC = "shsc"
    XMH = "xmh"
    WORK_UNIT = "work_unit"


@dataclass(slots=True)
class EpistemicNode:
    node_id: str
    category: str # facts | decisions | open_questions | attempts_failed | constraints
    text: str
    created_at: float = field(default_factory=time.time)
    revoked: bool = False


class EpistemicTypingContract:
    """
    Enforces non-mergeable epistemic bucket storage and revocation semantics.
    """

    def __init__(self) -> None:
        self.nodes: Dict[str, EpistemicNode] = {}

    def add_node(self, node_id: str, category: str, text: str) -> None:
        valid = {"facts", "decisions", "open_questions", "attempts_failed", "constraints"}
        if category not in valid:
            raise ValueError(f"Invalid epistemic category: {category}")
        self.nodes[node_id] = EpistemicNode(node_id=node_id, category=category, text=text)

    def revoke_node(self, node_id: str) -> bool:
        node = self.nodes.get(node_id)
        if not node:
            return False
        node.revoked = True
        return True

    def get_active_by_category(self, category: str) -> List[EpistemicNode]:
        return [n for n in self.nodes.values() if n.category == category and not n.revoked]


@dataclass(slots=True)
class ContinuityEnvelope:
    artifact_id: str
    artifact_kind: str # shsc | xmh | work_unit
    schema_version: str
    producer: str
    step: int
    payload: Dict[str, Any]
    parent_trace_id: str
    hop_index: int = 0
    module_chain: List[str] = field(default_factory=list)
    timestamp: float = field(default_factory=time.time)

    def calculate_hash(self) -> str:
        canonical = json.dumps({
            "artifact_id": self.artifact_id,
            "artifact_kind": self.artifact_kind,
            "step": self.step,
            "payload": self.payload,
            "parent_trace_id": self.parent_trace_id,
        }, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class EnvelopeGatePipeline:
    """
    Enforces Gate A-F validation pipeline with strict score thresholds.
    """

    def __init__(self, max_age_sec: float = 3600.0, min_quality_score: float = 0.65) -> None:
        self.max_age_sec = max_age_sec
        self.min_quality_score = min_quality_score

    def validate_envelope(self, envelope: ContinuityEnvelope, expected_parent_hash: Optional[str] = None) -> Tuple[bool, str]:
        # Gate A: Schema and Kind check
        if envelope.artifact_kind not in (EnvelopeKind.SHSC, EnvelopeKind.XMH, EnvelopeKind.WORK_UNIT):
            return False, "Gate_A_Failed: invalid_artifact_kind"
        if not envelope.artifact_id or not envelope.schema_version:
            return False, "Gate_A_Failed: missing_schema_properties"

        # Gate B: Integrity check (optional signature or hash chains)
        if expected_parent_hash:
            current_hash = envelope.calculate_hash()
            if not hmac_compare(current_hash, expected_parent_hash):
                return False, "Gate_B_Failed: integrity_hash_mismatch"

        # Gate C: Freshness check
        if time.time() - envelope.timestamp > self.max_age_sec:
            return False, "Gate_C_Failed: envelope_is_stale_exceeds_max_age"

        # Gate D: Quality validation (checks nested payload completeness)
        if not envelope.payload:
            return False, "Gate_D_Failed: empty_payload_quality_violation"

        # Gate E: Protocol matching
        if envelope.artifact_kind == EnvelopeKind.XMH and "receiver_model" not in envelope.payload:
            return False, "Gate_E_Failed: missing_xmh_protocol_receiver_model"

        return True, "verified"


def translate_shsc_to_xmh(shsc_envelope: ContinuityEnvelope, target_model: str) -> ContinuityEnvelope:
    """
    Translates a same-environment SHSC envelope into a model-neutral XMH envelope,
    preserving next_action priorities and normalized variables.
    """
    xmh_payload = dict(shsc_envelope.payload)
    xmh_payload["original_model"] = shsc_envelope.producer
    xmh_payload["receiver_model"] = target_model
    xmh_payload["do_not_redo"] = xmh_payload.get("do_not_redo", [])
    
    # Path normalization to portable slash notation
    if "workspace_paths" in xmh_payload:
        xmh_payload["workspace_paths"] = [p.replace("\\", "/") for p in xmh_payload["workspace_paths"]]

    return ContinuityEnvelope(
        artifact_id=f"xmh_{shsc_envelope.artifact_id[4:]}",
        artifact_kind=EnvelopeKind.XMH,
        schema_version=shsc_envelope.schema_version,
        producer=shsc_envelope.producer,
        step=shsc_envelope.step,
        payload=xmh_payload,
        parent_trace_id=shsc_envelope.parent_trace_id,
        hop_index=shsc_envelope.hop_index + 1,
        module_chain=list(shsc_envelope.module_chain) + [shsc_envelope.producer],
    )


def translate_xmh_to_shsc(xmh_envelope: ContinuityEnvelope) -> ContinuityEnvelope:
    """
    Translates an incoming XMH envelope back into a same-environment SHSC manifest,
    re-aligning path mappings and continuing the sequence.
    """
    shsc_payload = dict(xmh_envelope.payload)
    shsc_payload.pop("receiver_model", None)
    
    return ContinuityEnvelope(
        artifact_id=f"shsc_{xmh_envelope.artifact_id[4:]}",
        artifact_kind=EnvelopeKind.SHSC,
        schema_version=xmh_envelope.schema_version,
        producer=xmh_envelope.producer,
        step=xmh_envelope.step,
        payload=shsc_payload,
        parent_trace_id=xmh_envelope.parent_trace_id,
        hop_index=xmh_envelope.hop_index + 1,
        module_chain=list(xmh_envelope.module_chain) + [xmh_envelope.producer],
    )


def reduce_journal_to_envelope(journal_lines: List[str]) -> Optional[ContinuityEnvelope]:
    """
    A pure reducer that deterministically folds a sequence of events.jsonl ledger lines
    into a consolidated current state ContinuityEnvelope.
    """
    if not journal_lines:
        return None

    consolidated_payload = {}
    last_step = 0
    parent_trace_id = ""

    for line in journal_lines:
        if not line.strip():
            continue
        try:
            event = json.loads(line)
            last_step = event.get("step", last_step)
            parent_trace_id = event.get("trace_id", parent_trace_id)
            
            payload = event.get("payload", {})
            consolidated_payload.update(payload)
        except json.JSONDecodeError:
            pass

    return ContinuityEnvelope(
        artifact_id=f"shsc_{hashlib.sha256(str(time.time_ns()).encode()).hexdigest()[:16]}",
        artifact_kind=EnvelopeKind.SHSC,
        schema_version="1.0.0",
        producer="journal_reducer",
        step=last_step,
        payload=consolidated_payload,
        parent_trace_id=parent_trace_id,
    )


def hmac_compare(a: str, b: str) -> bool:
    return hashlib.sha256(a.encode()).digest() == hashlib.sha256(b.encode()).digest()
