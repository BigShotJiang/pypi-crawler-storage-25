from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from granary.mcp_security import McpTrustGateway, RiskTier


DEFAULT_ACTION_TIERS: dict[str, str] = {
    "mcp_filesystem_read": RiskTier.T0,
    "mcp_filesystem_write": RiskTier.T1,
    "mcp_gfo_federation_export": RiskTier.T2,
    "mcp_git_push": RiskTier.T3,
    "read_file": RiskTier.T0,
    "write_file": RiskTier.T1,
    "execute_command": RiskTier.T3,
}

DEFAULT_ACTION_SCOPES: dict[str, list[str]] = {
    "mcp_filesystem_read": ["file:read"],
    "mcp_filesystem_write": ["file:write"],
    "mcp_gfo_federation_export": ["gfo:export"],
    "mcp_git_push": ["git:write"],
    "read_file": ["file:read"],
    "write_file": ["file:write"],
    "execute_command": ["shell:exec"],
}

DEFAULT_REDIRECT_URIS: list[str] = [
    "http://127.0.0.1:5000/oauth/callback",
    "cursor://anysphere.cursor-mcp/oauth/callback",
    "https://auth.grandflipout.com/callback",
]


def load_gateway_policy(path: str | Path | None = None) -> dict[str, Any]:
    policy_path = path or os.environ.get("GRANARY_MCP_POLICY")
    if policy_path:
        raw = json.loads(Path(policy_path).read_text(encoding="utf-8"))
        return {
            "action_tiers": raw.get("action_tiers", DEFAULT_ACTION_TIERS),
            "action_scopes": raw.get("action_scopes", DEFAULT_ACTION_SCOPES),
            "allowed_redirect_uris": raw.get(
                "allowed_redirect_uris", DEFAULT_REDIRECT_URIS
            ),
        }
    return {
        "action_tiers": dict(DEFAULT_ACTION_TIERS),
        "action_scopes": dict(DEFAULT_ACTION_SCOPES),
        "allowed_redirect_uris": list(DEFAULT_REDIRECT_URIS),
    }


def build_gateway(path: str | Path | None = None) -> McpTrustGateway:
    policy = load_gateway_policy(path)
    return McpTrustGateway(
        action_tiers=policy["action_tiers"],
        action_scopes=policy["action_scopes"],
        allowed_redirect_uris=policy["allowed_redirect_uris"],
    )
