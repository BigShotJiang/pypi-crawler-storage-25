from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set


class FailureClass(str, Enum):
    MODEL = "model"
    TOOL = "tool"
    CONTEXT = "context"
    STATE = "state"


@dataclass(slots=True)
class FailureEvent:
    failure_id: str
    failure_class: FailureClass # Maps to 'class' in json schema
    subtype: str
    module: str
    step: int
    recoverable: bool
    error: str = ""
    trace_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        dct = {
            "failure_id": self.failure_id,
            "class": self.failure_class.value,
            "subtype": self.subtype,
            "module": self.module,
            "step": self.step,
            "recoverable": self.recoverable,
        }
        if self.error:
            dct["error"] = self.error[:200]
        if self.trace_id:
            dct["trace_id"] = self.trace_id
        return dct


def validate_failure_event(event_dict: dict) -> None:
    required = ["failure_id", "class", "subtype", "module", "step", "recoverable"]
    for req in required:
        if req not in event_dict:
            raise KeyError(f"FailureEvent missing required field: {req}")

    if event_dict["class"] not in [c.value for c in FailureClass]:
        raise ValueError(f"Invalid failure class: {event_dict['class']}")

    if not isinstance(event_dict["failure_id"], str):
        raise TypeError("failure_id must be a string")
    if not isinstance(event_dict["subtype"], str):
        raise TypeError("subtype must be a string")
    if not isinstance(event_dict["module"], str):
        raise TypeError("module must be a string")
    if not isinstance(event_dict["step"], int):
        raise TypeError("step must be an integer")
    if not isinstance(event_dict["recoverable"], bool):
        raise TypeError("recoverable must be a boolean")
    if "error" in event_dict:
        if not isinstance(event_dict["error"], str):
            raise TypeError("error must be a string")
        if len(event_dict["error"]) > 200:
            raise ValueError("error maxLength cannot exceed 200 characters")
    if "trace_id" in event_dict:
        if not isinstance(event_dict["trace_id"], str):
            raise TypeError("trace_id must be a string")


class HealingState(str, Enum):
    HEALTHY = "Healthy"
    DEGRADED = "Degraded"
    PAUSED = "Paused"
    RETIRED = "Retired"


class SelfHealingEngine:
    """
    Implements fast and slow recovery ladders for self-healing agent runs.
    """

    def __init__(self) -> None:
        self.state = HealingState.HEALTHY
        self.remedies_applied: List[dict] = []

    def handle_failure(self, event: FailureEvent, orch, hp, mod) -> str:
        """
        Processes a failure event through the recovery ladder.
        """
        validate_failure_event(event.to_dict())
        
        if self.state == HealingState.HEALTHY:
            self.state = HealingState.DEGRADED

        # Fast-Path L0/L1 Remedies
        remedy_info = {
            "failure_id": event.failure_id,
            "class": event.failure_class,
            "subtype": event.subtype,
            "module": event.module,
            "step": event.step,
        }

        if event.subtype == "error_flood":
            # Halves learning rate, multiplies EWC constraint
            hp._system_lr_multiplier = max(0.1, hp._system_lr_multiplier * 0.5)
            if hasattr(mod, "ewc_lambda"):
                mod.ewc_lambda *= 1.5
            remedy_info["remedy"] = "error_flood_reset"
            self.remedies_applied.append(remedy_info)
            self.state = HealingState.HEALTHY
            return "error_flood_reset"

        elif event.subtype == "loss_diverge":
            # Optimizer reset
            if hasattr(mod, "_reset_optimizer"):
                mod._reset_optimizer()
            remedy_info["remedy"] = "optimizer_reset"
            self.remedies_applied.append(remedy_info)
            self.state = HealingState.HEALTHY
            return "optimizer_reset"

        elif event.subtype == "stale_data":
            # Requests sleep cycle
            if hasattr(orch, "request_sleep_homeostasis"):
                orch.request_sleep_homeostasis()
            remedy_info["remedy"] = "sleep_homeostasis_request"
            self.remedies_applied.append(remedy_info)
            self.state = HealingState.HEALTHY
            return "sleep_homeostasis_request"

        elif event.subtype == "calibration_fail":
            # Resets calibration tracker
            if hasattr(mod, "calibration_tracker") and hasattr(mod.calibration_tracker, "reset"):
                mod.calibration_tracker.reset()
            remedy_info["remedy"] = "calibration_reset"
            self.remedies_applied.append(remedy_info)
            self.state = HealingState.HEALTHY
            return "calibration_reset"

        # Slow-Path L2 Escalations
        if not event.recoverable:
            self.state = HealingState.PAUSED
            
            # Check slow recovery sequence: consolidate -> lr_reset -> knowledge_import -> targeted_replay -> best_version_restore
            remedy_info["remedy"] = "slow_path_paused_consolidation"
            self.remedies_applied.append(remedy_info)
            return "slow_path_paused_consolidation"

        # Default degradation mode
        remedy_info["remedy"] = "degraded_mode_monitoring"
        self.remedies_applied.append(remedy_info)
        return "degraded_mode_monitoring"


# ── Replay-Safe Ingestion Contract ──

def replay_safe_process_outcome(
    learner,
    outcome_payload: dict,
    *,
    seen_ids: set[str]
) -> bool:
    """Enforces idempotent, trace-verified learning from GFO feedback payloads."""
    trade_id = outcome_payload.get("trade_id") or (
        f"{outcome_payload.get('item_id')}:{outcome_payload.get('timestamp')}"
    )
    if trade_id in seen_ids:
        return False  # Skip duplicate
    seen_ids.add(trade_id)

    hold = learner._normalize_hold_time(
        outcome_payload.get("hold_time_sec", 3600)
    )
    if hold is None:
        return False

    buy_time = outcome_payload.get("timestamp") - hold
    matched = learner._match_to_predictions(buy_time, outcome_payload.get("item_id"))

    if not matched.get("module") and not matched.get("direction"):
        learner._unmatched_outcomes += 1
        # Banned: Do NOT apply parameter gradients without verified historical snapshot
        learner.bus.publish("outcome.unmatched", {"trade_id": trade_id, "step": learner._step})
        return False

    learner._record_module_outcomes(outcome_payload, matched)
    learner._feed_outcome_to_modules(outcome_payload, matched)
    learner.bus.publish("outcome.processed", {"trade_id": trade_id})
    return True
