from __future__ import annotations

import re
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple


class SupervisorState:
    IDLE = "Idle"
    ROUTING = "Routing"
    EXECUTING_SINGLE = "ExecutingSingle"
    EXECUTING_CHAIN = "ExecutingChain"
    REJECTED = "Rejected"
    FEEDBACK = "Feedback"
    FALLBACK = "Fallback"
    DEGRADED = "Degraded"


class SupervisorFSM:
    """
    Manages the lifecycle of an agent query multi-hop transaction.
    """

    def __init__(self) -> None:
        self.state = SupervisorState.IDLE
        self.history: List[Tuple[float, str, str]] = []

    def transition(self, event: str, target: str) -> bool:
        """
        Transition state based on strict valid FSM paths:
        Idle -> Routing
        Routing -> ExecutingSingle, ExecutingChain, Rejected
        ExecutingSingle -> Feedback, Fallback
        ExecutingChain -> ExecutingChain (hops), Feedback, Degraded
        Fallback -> Feedback, Degraded
        Feedback -> Idle
        Rejected -> Idle
        Degraded -> Idle
        """
        allowed = {
            SupervisorState.IDLE: {SupervisorState.ROUTING},
            SupervisorState.ROUTING: {
                SupervisorState.EXECUTING_SINGLE,
                SupervisorState.EXECUTING_CHAIN,
                SupervisorState.REJECTED,
            },
            SupervisorState.EXECUTING_SINGLE: {
                SupervisorState.FEEDBACK,
                SupervisorState.FALLBACK,
            },
            SupervisorState.EXECUTING_CHAIN: {
                SupervisorState.EXECUTING_CHAIN,
                SupervisorState.FEEDBACK,
                SupervisorState.DEGRADED,
            },
            SupervisorState.FALLBACK: {SupervisorState.FEEDBACK, SupervisorState.DEGRADED},
            SupervisorState.FEEDBACK: {SupervisorState.IDLE},
            SupervisorState.REJECTED: {SupervisorState.IDLE},
            SupervisorState.DEGRADED: {SupervisorState.IDLE},
        }

        current = self.state
        if target not in allowed.get(current, set()) and not (current == SupervisorState.EXECUTING_CHAIN and target == SupervisorState.EXECUTING_CHAIN):
            return False

        self.state = target
        import time
        self.history.append((time.time(), current, target))
        return True


# ── Blackboard Schema Validation ──

UUID_REGEX = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")
VERSION_REGEX = re.compile(r"^\d+\.\d+\.\d+$")


def validate_blackboard_envelope(envelope: dict) -> None:
    required = ["artifact_id", "channel", "schema_version", "producer", "step", "payload", "provenance"]
    for req in required:
        if req not in envelope:
            raise KeyError(f"Envelope missing required field: {req}")

    if not UUID_REGEX.match(envelope["artifact_id"]):
        raise ValueError("artifact_id must be a valid UUID v4")

    if not isinstance(envelope["channel"], str):
        raise TypeError("channel must be a string")

    if not VERSION_REGEX.match(envelope["schema_version"]):
        raise ValueError("schema_version must match major.minor.patch pattern")

    if not isinstance(envelope["producer"], str):
        raise TypeError("producer must be a string")

    if not isinstance(envelope["step"], int) or envelope["step"] < 0:
        raise ValueError("step must be a non-negative integer")

    if "ttl_steps" in envelope:
        if not isinstance(envelope["ttl_steps"], int) or envelope["ttl_steps"] < 1:
            raise ValueError("ttl_steps must be an integer >= 1")

    if not isinstance(envelope["payload"], dict):
        raise TypeError("payload must be a dictionary")

    if not isinstance(envelope["provenance"], dict):
        raise TypeError("provenance must be a dictionary")

    prov_required = ["parent_trace_id"]
    for pr in prov_required:
        if pr not in envelope["provenance"]:
            raise KeyError(f"provenance missing required field: {pr}")

    prov = envelope["provenance"]
    if "hop_index" in prov:
        if not isinstance(prov["hop_index"], int):
            raise TypeError("hop_index must be an integer")
    if "module_chain" in prov:
        if not isinstance(prov["module_chain"], list) or not all(isinstance(x, str) for x in prov["module_chain"]):
            raise TypeError("module_chain must be a list of strings")


def validate_channel_payload(channel: str, payload: dict) -> None:
    """
    Simulates JSON-schema validation for the five distinct channels specified in the BSC contract.
    """
    if channel == "orchestrator.routing_decision":
        # RoutingDecisionArtifact
        required = ["modules", "strategy", "scores", "trace_id"]
        for r in required:
            if r not in payload:
                raise KeyError(f"Payload missing required field: {r}")
        if not isinstance(payload["modules"], list) or not all(isinstance(x, str) for x in payload["modules"]):
            raise TypeError("modules must be a list of strings")
        if len(payload["modules"]) > 8:
            raise ValueError("modules list cannot exceed 8 items")
        if payload["strategy"] not in ["single", "chain", "parallel", "fan_out", "none"]:
            raise ValueError(f"Invalid strategy: {payload['strategy']}")
        if not isinstance(payload["scores"], dict) or not all(isinstance(k, str) and isinstance(v, (int, float)) for k, v in payload["scores"].items()):
            raise TypeError("scores must be a mapping of string to numeric value")
        for k, v in payload["scores"].items():
            if not (-1 <= v <= 2):
                raise ValueError(f"Score for {k} ({v}) must be between -1 and 2")
        if not UUID_REGEX.match(payload["trace_id"]):
            raise ValueError("trace_id must be a valid UUID")
        if "step" in payload:
            if not isinstance(payload["step"], int) or payload["step"] < 0:
                raise ValueError("step must be non-negative integer")

    elif channel == "ensemble.prediction":
        # EnsembleArtifact
        required = ["consensus", "confidence", "agreement", "step"]
        for r in required:
            if r not in payload:
                raise KeyError(f"Payload missing required field: {r}")
        if payload["consensus"] not in ["bullish", "bearish", "neutral"]:
            raise ValueError(f"Invalid consensus: {payload['consensus']}")
        if not isinstance(payload["confidence"], (int, float)) or not (0 <= payload["confidence"] <= 1):
            raise ValueError("confidence must be between 0 and 1")
        if not isinstance(payload["agreement"], (int, float)) or not (0 <= payload["agreement"] <= 1):
            raise ValueError("agreement must be between 0 and 1")
        if not isinstance(payload["step"], int):
            raise TypeError("step must be an integer")
        if "weights" in payload:
            if not isinstance(payload["weights"], dict) or not all(isinstance(k, str) and isinstance(v, (int, float)) for k, v in payload["weights"].items()):
                raise TypeError("weights must be mapping of string to float")

    elif channel == "federation.trade_outcome":
        # TradeOutcomeArtifact
        required = ["item_name", "buy_price", "sell_price", "profit", "timestamp"]
        for r in required:
            if r not in payload:
                raise KeyError(f"Payload missing required field: {r}")
        if not isinstance(payload["item_name"], str):
            raise TypeError("item_name must be a string")
        if "item_id" in payload:
            if not isinstance(payload["item_id"], int):
                raise TypeError("item_id must be an integer")
        if not isinstance(payload["buy_price"], int) or payload["buy_price"] < 0:
            raise ValueError("buy_price must be non-negative integer")
        if not isinstance(payload["sell_price"], int) or payload["sell_price"] < 0:
            raise ValueError("sell_price must be non-negative integer")
        if not isinstance(payload["profit"], int):
            raise TypeError("profit must be an integer")
        if "hold_time_sec" in payload:
            if not isinstance(payload["hold_time_sec"], (int, float)) or not (0 <= payload["hold_time_sec"] <= 2592000):
                raise ValueError("hold_time_sec must be between 0 and 30 days")
        if not isinstance(payload["timestamp"], (int, float)):
            raise TypeError("timestamp must be a float or int")

    elif channel == "prediction.divergence_detected":
        # DivergenceArtifact
        required = ["module_a", "module_b", "severity", "step"]
        for r in required:
            if r not in payload:
                raise KeyError(f"Payload missing required field: {r}")
        if not isinstance(payload["module_a"], str) or not isinstance(payload["module_b"], str):
            raise TypeError("module names must be strings")
        if not isinstance(payload["severity"], (int, float)) or not (0 <= payload["severity"] <= 1):
            raise ValueError("severity must be between 0 and 1")
        if not isinstance(payload["step"], int):
            raise TypeError("step must be an integer")

    elif channel == "healing.recovery_started":
        # RecoveryArtifact
        required = ["module", "cause", "strategy", "attempt", "step"]
        for r in required:
            if r not in payload:
                raise KeyError(f"Payload missing required field: {r}")
        if not isinstance(payload["module"], str) or not isinstance(payload["cause"], str) or not isinstance(payload["strategy"], str):
            raise TypeError("module, cause, strategy must be strings")
        if not isinstance(payload["attempt"], int) or payload["attempt"] < 1:
            raise ValueError("attempt must be an integer >= 1")
        if not isinstance(payload["step"], int):
            raise TypeError("step must be an integer")

    else:
        raise KeyError(f"BSC registry violation: unregistered channel target '{channel}'")


def publish_validated(bus, registry: dict, channel: str, envelope: dict) -> int:
    """
    Enforces the Blackboard Schema Contract (BSC) gate validation.
    """
    ch = registry.get("channels", {}).get(channel)
    if ch is None:
        raise KeyError(f"Unregistered channel: {channel}")
    
    validate_blackboard_envelope(envelope)
    validate_channel_payload(channel, envelope["payload"])
    
    return bus.publish(channel, envelope)


# ── Plan Decomposition Quality Rubric (PDQR) ──

PDQR_WEIGHTS = {
    "coverage": 0.25, 
    "ordering": 0.20, 
    "minimality": 0.15,
    "feasibility": 0.25, 
    "reconciliation": 0.15
}
ACCEPT_THRESHOLD = 0.72
REJECT_THRESHOLD = 0.45

NEURAL_FIRST = {"ge_trading", "stock_market", "trading_strategy"}


def score_plan_decomposition(
    prompt: str,
    modules: list[str],
    scores: dict[str, float],
    orch,
    intent_domains: set[str],
    max_chain_depth: int = 4,
) -> dict:
    n = len(modules)
    
    # Hard Rejection Gates:
    # 1. Any module marked is_retired appears in plan -> Hard REJECT
    # 2. n > max_chain_depth -> Hard REJECT
    for m in modules:
        mod = orch._modules.get(m)
        if mod and (getattr(mod, "health", {}) or {}).get("is_retired"):
            return {
                "modules": modules,
                "composite_score": 0.0,
                "verdict": "reject",
                "rejection_reasons": [f"module_is_retired({m})"]
            }
            
    if n > max_chain_depth:
        return {
            "modules": modules,
            "composite_score": 0.0,
            "verdict": "reject",
            "rejection_reasons": ["exceeds_max_chain_depth"]
        }

    # 1. Coverage: checks match against module domains and domain relations
    mod_domains = {getattr(orch._modules.get(m), "domain", "") for m in modules if m in orch._modules}
    related = set()
    for d in intent_domains:
        related |= {d} | set(orch.DOMAIN_RELATIONS.get(d, []))
    coverage = len(mod_domains & related) / max(1, len(intent_domains))
    
    # Hard Rejection: coverage < 0.3 for single-domain query -> Hard REJECT
    if len(intent_domains) == 1 and coverage < 0.3:
        return {
            "modules": modules,
            "composite_score": 0.0,
            "verdict": "reject",
            "rejection_reasons": ["coverage_below_single_domain_threshold"]
        }

    # 2. Ordering: structural neural predictions must precede downstream synthesis
    indices = [(i, m) for i, m in enumerate(modules)]
    ordering = 1.0
    last_neural = -1
    for i, m in indices:
        if m in NEURAL_FIRST:
            last_neural = i
        elif last_neural >= 0 and i > last_neural:
            ordering = 0.85  # penalty if synthesis runs before neural outputs
    if n <= 1:
        ordering = 1.0

    # 3. Minimality: penalize redundant and deep chain traversals
    minimality = 1.0 if n <= 2 else max(0.5, 1.0 - 0.15 * (n - 2))

    # 4. Feasibility: verify health, circuit breakers, and state
    feasible = 0
    for m in modules:
        cb = orch._get_circuit_breaker(m)
        h = getattr(orch._modules.get(m), "health", {}) or {}
        if cb.allow_request() and not h.get("is_retired") and not h.get("is_paused"):
            feasible += 1
    feasibility = feasible / max(1, n)
    
    # Hard Rejection: feasibility < 0.5 -> Hard REJECT
    if feasibility < 0.5:
        return {
            "modules": modules,
            "composite_score": 0.0,
            "verdict": "reject",
            "rejection_reasons": ["feasibility_below_threshold"]
        }

    # 5. Reconciliation: ensure active divergence signals are resolved by the plan
    div = orch._has_active_divergence(modules)
    reconciliation = 1.0
    if div:
        dm = set(div.get("modules", []))
        reconciliation = 1.0 if dm.issubset(set(modules)) else 0.4

    dims = {
        "coverage": coverage, 
        "ordering": ordering, 
        "minimality": minimality,
        "feasibility": feasibility, 
        "reconciliation": reconciliation
    }
    composite = sum(PDQR_WEIGHTS[k] * dims[k] for k in dims)

    if composite >= ACCEPT_THRESHOLD:
        verdict, reasons = "accept", []
    elif composite < REJECT_THRESHOLD:
        verdict = "reject"
        reasons = [k for k, v in dims.items() if v < 0.5]
    else:
        verdict, reasons = "revise", ["composite_in_revision_band"]

    return {
        "modules": modules,
        "dimension_scores": dims,
        "composite_score": round(composite, 4),
        "verdict": verdict,
        "rejection_reasons": reasons
    }


# ── Contract-Net Protocol (CNP) ──

def contract_net_allocate(
    orch,
    task_id: str,
    prompt: str,
    excluded: list[str],
    required_domains: list[str] | None = None
) -> tuple[str | None, list[str]]:
    """Evaluates candidate bids and assigns a winner and fallback backup list."""
    keywords = prompt.lower().split()
    candidates = orch.skill_registry.find_modules_for(keywords=keywords)
    bids = []

    for mod_name, cap, base_score in candidates:
        if mod_name in excluded or mod_name not in orch._modules:
            continue
        cb = orch._get_circuit_breaker(mod_name)
        if cb.state == "open" and not cb.allow_request():
            continue

        mod = orch._modules[mod_name]
        h = getattr(mod, "health", {}) or {}
        score = base_score
        
        # Adjust score based on accuracy history
        if h.get("direction_accuracy") is not None and h.get("accuracy_samples", 0) >= 20:
            score += (h["direction_accuracy"] - 0.5) * 0.3
        
        # Adjust score based on composite health
        chs = h.get("composite_health", {}).get("score")
        if chs is not None:
            score += (chs - 0.5) * 0.25
            
        # Penalize if paused
        if h.get("is_paused"):
            score -= 0.3
            
        # Penalize domain mismatch
        if required_domains:
            dom = getattr(mod, "domain", "")
            if dom not in required_domains:
                score -= 0.2

        bids.append({
            "bidder": mod_name,
            "bid_score": score,
            "confidence": h.get("gate_confidence", 0.5) or 0.5,
            "cb_state": cb.state
        })

    if not bids:
        return None, []

    bids.sort(key=lambda b: b["bid_score"], reverse=True)
    winner = bids[0]["bidder"]
    fallback_order = [b["bidder"] for b in bids[1:4]]
    
    if orch._bus:
        orch._bus.publish("orchestrator.task_awarded", {
            "task_id": task_id,
            "winner": winner,
            "fallback_order": fallback_order,
            "bid_count": len(bids)
        })
    return winner, fallback_order
