from __future__ import annotations

import os
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple


class ContextState:
    GREEN = "green"
    YELLOW = "yellow"
    ORANGE = "orange"
    RED = "red"


@dataclass(slots=True)
class ContinuationManifest:
    manifest_id: str
    original_session_id: str
    workspace_path: str
    git_branch: str
    git_commit: str
    last_applied_index: int
    resume_state: dict[str, Any]
    next_actions: List[str]
    created_at: float = field(default_factory=time.time)
    expires_at: float = 0.0


class SelfHandshakeValidator:
    """
    Enforces deterministic environment parity checks (matching workspace path,
    git branch, git commit, and last_applied_index) before allowing session resume.
    """

    def __init__(self, current_workspace: str, current_branch: str, current_commit: str) -> None:
        self.current_workspace = current_workspace
        self.current_branch = current_branch
        self.current_commit = current_commit

    def validate_parity(self, manifest: ContinuationManifest) -> Tuple[bool, List[str]]:
        errors = []
        if manifest.workspace_path != self.current_workspace:
            errors.append(f"workspace_path_mismatch: expected={manifest.workspace_path}, active={self.current_workspace}")
        if manifest.git_branch != self.current_branch:
            errors.append(f"git_branch_mismatch: expected={manifest.git_branch}, active={self.current_branch}")
        if manifest.git_commit != self.current_commit:
            errors.append(f"git_commit_mismatch: expected={manifest.git_commit}, active={self.current_commit}")
        return len(errors) == 0, errors


class ContextBudgetManager:
    """
    Manages context budget threshold trigger bands with hysteresis (green/yellow/orange/red).
    """

    def __init__(self, limit_tokens: int = 200_000) -> None:
        self.limit_tokens = limit_tokens
        self.state = ContextState.GREEN

    def update_state(self, current_tokens: int) -> Tuple[str, bool]:
        """
        Determines current state and returns (state, trigger_rollover).
        Hysteresis triggers:
        - green: < 50%
        - yellow: 50% - 75%
        - orange: 75% - 90% (trigger manifest pre-generation)
        - red: >= 90% (force immediate rollover)
        """
        usage_pct = current_tokens / self.limit_tokens
        old_state = self.state

        if usage_pct < 0.50:
            self.state = ContextState.GREEN
        elif 0.50 <= usage_pct < 0.75:
            self.state = ContextState.YELLOW
        elif 0.75 <= usage_pct < 0.90:
            self.state = ContextState.ORANGE
        else:
            self.state = ContextState.RED

        # Trigger rollover on transitioning to ORANGE/RED
        trigger_rollover = (old_state != self.state) and (self.state in (ContextState.ORANGE, ContextState.RED))
        return self.state, trigger_rollover


class ProbationMonitor:
    """
    Tracks quality and stability metrics during the probation window immediately following a session resume.
    Triggers rollback if:
      - rework_rate > 40%
      - edit_churn > 35%
      - tool_repetition count is breached (3 identical consecutive calls)
    """

    def __init__(self, probation_window_steps: int = 20) -> None:
        self.probation_window_steps = probation_window_steps
        self.step_count = 0
        self.rework_count = 0
        self.edit_churns: List[float] = []
        self.consecutive_tool_calls: List[Tuple[str, dict]] = [] # list of (tool, args)

    def record_step(
        self,
        *,
        is_rework: bool,
        edit_churn_pct: float,
        tool_call: Tuple[str, dict]
    ) -> bool:
        """
        Records step metrics. Returns True if a rollback is triggered due to probation breach.
        """
        self.step_count += 1
        if is_rework:
            self.rework_count += 1
        self.edit_churns.append(edit_churn_pct)

        # Track consecutive tool call duplicates
        if self.consecutive_tool_calls and self.consecutive_tool_calls[-1] == tool_call:
            self.consecutive_tool_calls.append(tool_call)
        else:
            self.consecutive_tool_calls = [tool_call]

        # 1. Check tool repetition loop trigger: 3 identical consecutive calls
        if len(self.consecutive_tool_calls) >= 3:
            return True

        if self.step_count <= self.probation_window_steps:
            # 2. Check rework rate: rework_rate > 40% (at least 5 steps observed)
            rework_rate = self.rework_count / self.step_count
            if self.step_count >= 5 and rework_rate > 0.40:
                return True

            # 3. Check edit churn: average churn > 35%
            avg_churn = sum(self.edit_churns) / len(self.edit_churns)
            if self.step_count >= 5 and avg_churn > 35.0:
                return True

        return False
