from __future__ import annotations

import hashlib
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple


class HookState:
    DRAFT = "draft"
    REPLAY = "replay"
    SHADOW = "shadow"
    CANARY = "canary"
    ENFORCE = "enforce"
    DECAY = "decay"
    RETIRED = "retired"


@dataclass(slots=True)
class FailureFingerprint:
    fingerprint_id: str
    error_class: str
    error_prefix: str
    module: str
    channel: str
    stack_top: str
    context_keys: List[str]
    step_mod_100: int
    cluster_id: str
    hash_sha256: str = ""
    count_24h: int = 1
    first_seen: float = field(default_factory=time.time)
    last_seen: float = field(default_factory=time.time)
    severity_ema: float = 0.5

    def calculate_and_set_hash(self) -> str:
        """
        hash = SHA256(error_class | error_prefix[:80] | module | channel | stack_top)
        """
        prefix_slice = self.error_prefix[:80]
        material = f"{self.error_class}|{prefix_slice}|{self.module}|{self.channel}|{self.stack_top}".encode("utf-8")
        self.hash_sha256 = hashlib.sha256(material).hexdigest()
        return self.hash_sha256


@dataclass(slots=True)
class AgentHook:
    id: str
    version: int
    state: str  # draft | replay | shadow | canary | enforce | decay | retired
    fingerprint_cluster: str
    trigger_channels: List[str]
    trigger_match: Dict[str, Any]
    trigger_cooldown_sec: int
    action_type: str  # bus.publish | module.learn | healing.recover | orchestrator.schedule_probe
    action_params: Dict[str, Any]
    
    # Guards
    max_invocations_per_hour: int = 6
    max_depth: int = 2
    specificity_score: float = 0.0
    
    # Lifecycle
    draft_created_at: float = field(default_factory=time.time)
    replay_pass_rate: float = 0.0
    shadow_helped: int = 0
    shadow_harmed: int = 0
    shadow_neutral: int = 0
    canary_fraction: float = 0.10
    canary_lift_delta: float = 0.0
    canary_real_events_count: int = 0
    enforce_since: Optional[float] = None
    last_fired_at: float = 0.0
    
    # Sprawl Controls
    priority: int = 10
    replaces: List[str] = field(default_factory=list)
    capped_group: str = ""


class AutoHookManager:
    """
    Manages automated hook creation, lifecycle progression, specificity scoring, and recursion depth limits.
    """

    def __init__(self, max_hooks_per_group: int = 3, max_hooks_per_channel: int = 8) -> None:
        self.hooks: Dict[str, AgentHook] = {}
        self.max_hooks_per_group = max_hooks_per_group
        self.max_hooks_per_channel = max_hooks_per_channel
        self.active_execution_depth = 0

    def calculate_specificity(
        self,
        *,
        module_exact: bool,
        channel_exact: bool,
        prefix_regex: bool,
        context_keys: bool,
        wildcard_fraction: float,
    ) -> float:
        """
        specificity = 0.20 * 1[module_exact] + 0.20 * 1[channel_exact] + 0.30 * 1[prefix_regex] + 0.20 * 1[context_keys] + 0.10 * (1 - wildcard_fraction)
        """
        score = (
            (0.20 if module_exact else 0.0) +
            (0.20 if channel_exact else 0.0) +
            (0.30 if prefix_regex else 0.0) +
            (0.20 if context_keys else 0.0) +
            (0.10 * (1.0 - max(0.0, min(1.0, wildcard_fraction))))
        )
        return round(score, 4)

    def register_hook(self, hook: AgentHook) -> bool:
        """
        Registers a new hook, enforcing hard sprawl and subscription caps.
        """
        # Sprawl Cap Check: Maximum of 3 active hooks per capped_group
        if hook.capped_group and hook.state in (HookState.CANARY, HookState.ENFORCE):
            group_count = sum(
                1 for h in self.hooks.values()
                if h.capped_group == hook.capped_group and h.state in (HookState.CANARY, HookState.ENFORCE)
            )
            if group_count >= self.max_hooks_per_group:
                return False

        # Channel Cap Check: Maximum of 8 active hooks subscribed to any single channel
        for chan in hook.trigger_channels:
            chan_count = sum(
                1 for h in self.hooks.values()
                if chan in h.trigger_channels and h.state in (HookState.CANARY, HookState.ENFORCE)
            )
            if chan_count >= self.max_hooks_per_channel:
                return False

        self.hooks[hook.id] = hook
        return True

    def evaluate_lifecycle_progression(self, hook_id: str, now: Optional[float] = None) -> str:
        """
        Enforces state transition rules of the Hook lifecycle:
        - replay -> shadow: replay pass rate >= 80% on historical logs
        - shadow -> canary: helped-to-harmed ratio >= 4:1 over >= 30 events
        - canary -> enforce: canary lift delta >= 2% over >= 50 real events
        - enforce/any -> decay/retired: watchdog idle (no fires) for 30 consecutive days
        """
        hook = self.hooks.get(hook_id)
        if not hook:
            return ""

        current_time = now or time.time()
        current = hook.state

        if current == HookState.REPLAY:
            if hook.replay_pass_rate >= 0.80:
                hook.state = HookState.SHADOW
                hook.draft_created_at = current_time # Reset state timer

        elif current == HookState.SHADOW:
            total_shadow_events = hook.shadow_helped + hook.shadow_harmed
            if total_shadow_events >= 30:
                # Helped-to-harmed ratio >= 4:1
                ratio_ok = hook.shadow_helped >= (4 * max(1, hook.shadow_harmed))
                if ratio_ok:
                    hook.state = HookState.CANARY
                    hook.draft_created_at = current_time
            # Decay check if idle for 14 days
            elif current_time - hook.draft_created_at > (14 * 24 * 3600):
                hook.state = HookState.DECAY

        elif current == HookState.CANARY:
            if hook.canary_real_events_count >= 50:
                if hook.canary_lift_delta >= 0.02 and hook.specificity_score >= 0.65:
                    hook.state = HookState.ENFORCE
                    hook.enforce_since = current_time
            elif current_time - hook.draft_created_at > (30 * 24 * 3600):
                hook.state = HookState.DECAY

        elif current == HookState.ENFORCE:
            # Idle for 30 days decay check
            last_activity = hook.last_fired_at or (hook.enforce_since or current_time)
            if current_time - last_activity > (30 * 24 * 3600):
                hook.state = HookState.DECAY

        elif current == HookState.DECAY:
            # Automatic retirement
            hook.state = HookState.RETIRED

        return hook.state

    def trigger_hook_execution(self, hook_id: str) -> bool:
        """
        Enforces maximum execution depth (recursion limit of 2) during hook firing.
        """
        hook = self.hooks.get(hook_id)
        if not hook or hook.state not in (HookState.CANARY, HookState.ENFORCE):
            return False

        if self.active_execution_depth >= hook.max_depth:
            # Drop/reject to prevent loop amplification
            return False

        try:
            self.active_execution_depth += 1
            hook.last_fired_at = time.time()
            return True
        finally:
            self.active_execution_depth -= 1
