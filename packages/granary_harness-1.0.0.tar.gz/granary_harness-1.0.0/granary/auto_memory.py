from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


class MemoryTier:
    CANDIDATE = "candidate"
    PROBATION = "probation"
    ACTIVE = "active"
    CRYSTALLIZED = "crystallized"
    QUARANTINED = "quarantined"
    RETIRED = "retired"
    SHADOW = "SHADOW"


@dataclass(slots=True)
class MemorySource:
    source_type: str  # outcome_feedback | explicit_correction | bus_event
    weight: float
    event_id: Optional[str] = None
    module: Optional[str] = None
    item_name: Optional[str] = None
    profitable: Optional[bool] = None
    direction_correct: Optional[bool] = None
    actor: Optional[str] = None
    session_id: Optional[str] = None
    text: Optional[str] = None
    channel: Optional[str] = None
    payload_hash: Optional[str] = None


@dataclass(slots=True)
class MemoryRecord:
    id: str
    tier: str
    domain: str
    topics: List[str]
    content_text: str
    content_type: str = "procedural"  # fact | preference | procedure | constraint
    structured_data: Dict[str, Any] = field(default_factory=dict)
    version: int = 1
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    
    # Applicability
    modules: List[str] = field(default_factory=list)
    channels: List[str] = field(default_factory=list)
    min_confidence: float = 0.55
    
    # Lifecycle
    tier_entered_at: float = field(default_factory=time.time)
    promotion_score: float = 0.0
    decay_score: float = 0.5
    use_count: int = 0
    last_used_at: float = field(default_factory=time.time)
    
    # Provenance
    sources: List[MemorySource] = field(default_factory=list)
    trust_score: float = 0.5
    poison_risk: float = 0.0
    
    # Anti-poisoning
    quorum_required: int = 2
    holdout_pass_rate: float = 0.0
    contradiction_count: int = 0
    max_single_source_weight: float = 0.6
    
    # Crystallization (for EWC permanent protection)
    ewc_boost: float = 1.5
    confidence_floor: float = 0.55
    sustained_accuracy: float = 0.0
    sustained_steps: int = 0
    
    # Status
    blocked: bool = False
    block_reason: Optional[str] = None
    shadow_only: bool = False

    def to_dict(self) -> dict:
        return {
            "metadata": {
                "id": self.id,
                "version": self.version,
                "created_at": self.created_at,
                "updated_at": self.updated_at,
                "tier": self.tier,
                "domain": self.domain,
                "topics": self.topics,
            },
            "spec": {
                "content": {
                    "type": self.content_type,
                    "text": self.content_text,
                    "structured": self.structured_data,
                },
                "applicability": {
                    "modules": self.modules,
                    "channels": self.channels,
                    "min_confidence": self.min_confidence,
                },
                "lifecycle": {
                    "tier_entered_at": self.tier_entered_at,
                    "promotion_score": self.promotion_score,
                    "decay_score": self.decay_score,
                    "use_count": self.use_count,
                    "last_used_at": self.last_used_at,
                },
                "provenance": {
                    "sources": [
                        {
                            "type": s.source_type,
                            "weight": s.weight,
                            "event_id": s.event_id,
                            "module": s.module,
                            "item_name": s.item_name,
                            "profitable": s.profitable,
                            "direction_correct": s.direction_correct,
                            "actor": s.actor,
                            "session_id": s.session_id,
                            "text": s.text,
                            "channel": s.channel,
                            "payload_hash": s.payload_hash,
                        }
                        for s in self.sources
                    ],
                    "trust_score": self.trust_score,
                    "poison_risk": self.poison_risk,
                },
                "anti_poisoning": {
                    "quorum_required": self.quorum_required,
                    "holdout_pass_rate": self.holdout_pass_rate,
                    "contradiction_count": self.contradiction_count,
                    "max_single_source_weight": self.max_single_source_weight,
                },
                "crystallization": {
                    "ewc_boost": self.ewc_boost,
                    "confidence_floor": self.confidence_floor,
                    "sustained_accuracy": self.sustained_accuracy,
                    "sustained_steps": self.sustained_steps,
                }
            },
            "status": {
                "blocked": self.blocked,
                "block_reason": self.block_reason,
                "shadow_only": self.shadow_only,
            }
        }


class AutoMemoryManager:
    """
    Manages automated agent memory ingestion, extraction cues, state transitions,
    anti-poisoning score calculations, and deduplication of memories.
    """

    def __init__(self, ttl_seconds: int = 7 * 24 * 3600) -> None:
        self.memories: Dict[str, MemoryRecord] = {}
        self.candidate_ttl = ttl_seconds
        self.ingestion_timestamps: List[float] = []

    def create_candidate_from_cue(
        self,
        *,
        domain: str,
        topics: List[str],
        text: str,
        content_type: str = "procedural",
        structured_data: Optional[dict] = None,
        sources: List[MemorySource],
    ) -> MemoryRecord:
        """
        Extracts and ingests a candidate memory atom.
        """
        mem_id = f"mem_{hashlib.sha256(f'{text}:{time.time_ns()}'.encode()).hexdigest()[:16]}"
        record = MemoryRecord(
            id=mem_id,
            tier=MemoryTier.CANDIDATE,
            domain=domain,
            topics=topics,
            content_text=text,
            content_type=content_type,
            structured_data=structured_data or {},
            sources=list(sources),
        )
        self.memories[mem_id] = record
        self.ingestion_timestamps.append(time.time())
        self._deduplicate_and_merge(record)
        return record

    def update_promotion_score(self, mem_id: str, signal_value: float, alpha: float = 0.10) -> bool:
        """
        Dynamic EMA-based promotion score update:
        promotion_score_t = alpha * signal_t + (1 - alpha) * promotion_score_t-1
        """
        record = self.memories.get(mem_id)
        if not record:
            return False
        
        record.promotion_score = alpha * signal_value + (1 - alpha) * record.promotion_score
        record.updated_at = time.time()
        return True

    def calculate_poison_risk(
        self,
        mem_id: str,
        *,
        unmatched_ratio: float = 0.0
    ) -> float:
        """
        Poison Risk Formula:
        poison_risk = 0.35*S_dom + 0.25*A_rate + 0.30*C_count + 0.40*H_invalid + 0.15*U_ratio
        """
        record = self.memories.get(mem_id)
        if not record:
            return 0.0

        # S_dom: 1.0 if single source represents > 60% of total weight
        s_dom = 0.0
        total_weight = sum(s.weight for s in record.sources)
        if total_weight > 0:
            for s in record.sources:
                if (s.weight / total_weight) > 0.60:
                    s_dom = 1.0
                    break

        # A_rate: 1.0 if rate exceeds z-score threshold (simulated as >= 5 ingestions in past 10 seconds)
        now = time.time()
        recent_count = sum(1 for ts in self.ingestion_timestamps if now - ts < 10.0)
        a_rate = 1.0 if recent_count >= 5 else 0.0

        # C_count: 1.0 if contradiction count >= 2
        c_count = 1.0 if record.contradiction_count >= 2 else 0.0

        # H_invalid: 1.0 if hold_time or margin is invalid (e.g. negative or exceeds maximum limit)
        h_invalid = 0.0
        min_hold = record.structured_data.get("min_hold_time_sec")
        if min_hold is not None and (min_hold < 0 or min_hold > 2592000):
            h_invalid = 1.0

        # U_ratio: 1.0 if recent unmatched ratio is > 0.50
        u_ratio = 1.0 if unmatched_ratio > 0.50 else 0.0

        risk = (
            (0.35 * s_dom) +
            (0.25 * a_rate) +
            (0.30 * c_count) +
            (0.40 * h_invalid) +
            (0.15 * u_ratio)
        )
        record.poison_risk = max(0.0, min(1.0, risk))
        
        # If poison_risk >= 0.70, quarantine instantly
        if record.poison_risk >= 0.70 and record.tier != MemoryTier.RETIRED:
            self.transition_state(mem_id, MemoryTier.QUARANTINED)

        return record.poison_risk

    def transition_state(self, mem_id: str, target_tier: str) -> bool:
        """
        Enforces Memory state machine transitions:
        candidate -> quarantined | retired | probation
        probation -> active | retired
        active -> crystallized | SHADOW
        """
        record = self.memories.get(mem_id)
        if not record:
            return False

        current = record.tier
        if current == target_tier:
            return True

        # Define permitted transitions
        allowed = {
            MemoryTier.CANDIDATE: {MemoryTier.QUARANTINED, MemoryTier.RETIRED, MemoryTier.PROBATION},
            MemoryTier.PROBATION: {MemoryTier.ACTIVE, MemoryTier.RETIRED},
            MemoryTier.ACTIVE: {MemoryTier.CRYSTALLIZED, MemoryTier.SHADOW, MemoryTier.RETIRED},
            MemoryTier.CRYSTALLIZED: {MemoryTier.ACTIVE, MemoryTier.RETIRED},
            MemoryTier.QUARANTINED: {MemoryTier.RETIRED},
            MemoryTier.SHADOW: {MemoryTier.RETIRED, MemoryTier.ACTIVE},
            MemoryTier.RETIRED: set()  # terminal
        }

        if target_tier not in allowed.get(current, set()):
            return False

        record.tier = target_tier
        record.tier_entered_at = time.time()
        record.updated_at = time.time()
        return True

    def process_lifecycle_ticks(self, now: Optional[float] = None) -> List[Tuple[str, str]]:
        """
        Ticks the state machine to transition memories based on score thresholds and TTL expiries.
        Returns: List of tuples (mem_id, action_taken)
        """
        current_time = now or time.time()
        actions = []

        for mem_id, record in list(self.memories.items()):
            if record.tier == MemoryTier.CANDIDATE:
                # 1. Promote to probation
                if record.promotion_score >= 0.35 and len(record.sources) >= 1 and record.trust_score >= 0.40:
                    self.transition_state(mem_id, MemoryTier.PROBATION)
                    actions.append((mem_id, "moved_to_probation"))
                # 2. Expired Candidate TTL
                elif current_time - record.created_at >= self.candidate_ttl:
                    self.transition_state(mem_id, MemoryTier.RETIRED)
                    actions.append((mem_id, "candidate_ttl_expired"))

            elif record.tier == MemoryTier.PROBATION:
                # 1. Promote to active
                # Quorum of unique source types (e.g. outcome_feedback AND explicit_correction)
                unique_source_types = {s.source_type for s in record.sources}
                if record.promotion_score >= 0.55 and len(unique_source_types) >= record.quorum_required and record.holdout_pass_rate >= 0.55:
                    self.transition_state(mem_id, MemoryTier.ACTIVE)
                    actions.append((mem_id, "promoted_to_active"))
                # 2. Negative evaluation rollback or expired
                elif record.promotion_score < -0.20 or (current_time - record.tier_entered_at >= self.candidate_ttl):
                    self.transition_state(mem_id, MemoryTier.RETIRED)
                    actions.append((mem_id, "probation_expired_or_rejected"))

            elif record.tier == MemoryTier.ACTIVE:
                # 1. Crystallization EWC trigger
                if record.sustained_steps >= 300 and record.sustained_accuracy >= 0.65:
                    self.transition_state(mem_id, MemoryTier.CRYSTALLIZED)
                    actions.append((mem_id, "crystallized_ewc_locked"))
                # 2. De-escalate to SHADOW on accuracy drop
                elif record.decay_score < 0.15:
                    self.transition_state(mem_id, MemoryTier.SHADOW)
                    actions.append((mem_id, "de-escalated_to_shadow"))

        return actions

    def _deduplicate_and_merge(self, new_record: MemoryRecord) -> None:
        """
        Merge overlapping or duplicate memory entries to avoid redundancy.
        """
        for mem_id, existing in list(self.memories.items()):
            if mem_id == new_record.id or existing.tier == MemoryTier.RETIRED:
                continue

            # If semantic content text or structures align perfectly, merge sources
            if existing.content_text.strip().lower() == new_record.content_text.strip().lower():
                # Merge sources
                for src in new_record.sources:
                    if src not in existing.sources:
                        existing.sources.append(src)
                
                # Combine structured mapping
                existing.structured_data.update(new_record.structured_data)
                
                # Re-calculate averages/scores
                existing.version += 1
                existing.updated_at = time.time()
                
                # Retire the duplicate candidate
                new_record.tier = MemoryTier.RETIRED
                new_record.updated_at = time.time()
                break
