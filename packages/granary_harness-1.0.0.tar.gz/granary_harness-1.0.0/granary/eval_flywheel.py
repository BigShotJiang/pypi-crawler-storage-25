from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


@dataclass(slots=True)
class FlywheelMetrics:
    total_scans: int = 0
    matched_outcomes: int = 0
    outcome_timestamps: List[float] = field(default_factory=list)
    signal_timestamps: List[float] = field(default_factory=list)
    wins: int = 0
    losses: int = 0


@dataclass(slots=True)
class OnlineKpiTracker:
    """
    Manages online KPI tracking over a rolling window.
    Tracks:
      - outcome_match_rate
      - consecutive_live_days
      - synthetic_trades_count
      - federation_outcome_rate (per minute)
      - snapshot_match_rate
      - bus_handler_errors
    """
    outcome_matches: List[Tuple[float, bool]] = field(default_factory=list)  # (timestamp, is_match)
    consecutive_live_days: int = 0
    synthetic_trades_count: int = 0
    federation_outcomes: List[float] = field(default_factory=list)  # timestamps of federation outcomes
    snapshot_matches: List[Tuple[float, bool]] = field(default_factory=list)  # (timestamp, matches_at_delta_lte_600)
    bus_handler_errors: int = 0

    def record_match(self, timestamp: float, is_match: bool) -> None:
        self.outcome_matches.append((timestamp, is_match))
        self.prune_old_records(timestamp, 7 * 24 * 3600)

    def record_federation_outcome(self, timestamp: float) -> None:
        self.federation_outcomes.append(timestamp)
        self.prune_old_records(timestamp, 60.0)

    def record_snapshot_match(self, timestamp: float, is_match_lte_600s: bool) -> None:
        self.snapshot_matches.append((timestamp, is_match_lte_600s))
        self.prune_old_records(timestamp, 24 * 3600)

    def record_synthetic_trade(self) -> None:
        self.synthetic_trades_count += 1

    def record_bus_error(self) -> None:
        self.bus_handler_errors += 1

    def get_outcome_match_rate(self) -> float:
        if not self.outcome_matches:
            return 0.0
        return sum(1 for _, m in self.outcome_matches if m) / len(self.outcome_matches)

    def get_federation_outcome_rate_per_min(self, now: float) -> float:
        self.prune_old_records(now, 60.0)
        return len(self.federation_outcomes)

    def get_snapshot_match_rate(self) -> float:
        if not self.snapshot_matches:
            return 0.0
        return sum(1 for _, m in self.snapshot_matches if m) / len(self.snapshot_matches)

    def prune_old_records(self, now: float, max_age_sec: float) -> None:
        self.outcome_matches = [(ts, m) for ts, m in self.outcome_matches if now - ts < max_age_sec]
        self.federation_outcomes = [ts for ts in self.federation_outcomes if now - ts < max_age_sec]
        self.snapshot_matches = [(ts, m) for ts, m in self.snapshot_matches if now - ts < max_age_sec]


@dataclass(slots=True)
class ShadowLogEntry:
    trace_id: str
    item_id: int
    shadow_direction: str
    baseline_direction: str
    timestamp: float
    outcome_direction: Optional[str] = None


class CounterfactualEvaluator:
    """
    Enforces shadow counterfactual comparisons without production leakage.
    """
    def __init__(self) -> None:
        self.log: Dict[str, ShadowLogEntry] = {}

    def log_shadow(
        self,
        *,
        trace_id: str,
        item_id: int,
        shadow_dir: str,
        baseline_dir: str,
        timestamp: float
    ) -> None:
        self.log[trace_id] = ShadowLogEntry(
            trace_id=trace_id,
            item_id=item_id,
            shadow_direction=shadow_dir,
            baseline_direction=baseline_dir,
            timestamp=timestamp
        )

    def match_outcome(self, trace_id: str, outcome_dir: str) -> bool:
        if trace_id in self.log:
            self.log[trace_id].outcome_direction = outcome_dir
            return True
        return False

    def get_counterfactual_metrics(self) -> Tuple[float, float, float]:
        """
        Computes the win rates of Shadow Arm vs Baseline Arm.
        Returns (shadow_win_rate, baseline_win_rate, delta_pp).
        """
        resolved = [entry for entry in self.log.values() if entry.outcome_direction is not None]
        if not resolved:
            return 0.0, 0.0, 0.0

        shadow_wins = sum(1 for entry in resolved if entry.shadow_direction == entry.outcome_direction)
        baseline_wins = sum(1 for entry in resolved if entry.baseline_direction == entry.outcome_direction)

        shadow_wr = shadow_wins / len(resolved)
        baseline_wr = baseline_wins / len(resolved)
        return shadow_wr, baseline_wr, (shadow_wr - baseline_wr)


@dataclass(slots=True)
class EvaluationFlywheel:
    """
    Implements the observe -> shadow -> holdout -> canary -> promote/rollback evaluation pipeline.
    """

    canary_traffic_pct: float = 0.05
    min_canary_duration_sec: int = 72 * 60 * 60 # 72 hours
    min_canary_resolved: int = 30
    p95_lag_limit_sec: int = 6 * 60 * 60 # 6 hours

    def evaluate_stage0_integrity(
        self,
        *,
        outcome_match_rate: float,
        consecutive_live_days: int,
        synthetic_trades: int,
        federation_outcome_rate: float,
        snapshot_match_rate: float,
    ) -> bool:
        """
        Stage 0 go/no-go gate before Stage 1 shadow.
        Rule: outcome match rate >= 80% for 7 days live OR 200 synthetic trades.
        Prerequisite KPIs: federation outcome rate >= 0.5/min, snapshot match rate >= 85%.
        """
        if federation_outcome_rate < 0.5 or snapshot_match_rate < 0.85:
            return False

        if outcome_match_rate >= 0.80 and consecutive_live_days >= 7:
            return True

        if synthetic_trades >= 200:
            return True

        return False

    def is_holdout_item(self, item_id: int) -> bool:
        """
        Holdout lockbox rule: item_id % 10 == 0 is never exposed to feedback/tuning.
        """
        return item_id % 10 == 0

    def is_holdout_time_window(self, timestamp: float, total_duration_days: float, start_timestamp: float) -> bool:
        """
        Holdout lockbox rule: last 20% of calendar days reserved as holdout.
        """
        elapsed_days = (timestamp - start_timestamp) / (24 * 60 * 60)
        return (elapsed_days / total_duration_days) >= 0.80

    def calculate_counterfactual_win_rate(
        self,
        *,
        shadow_outcomes: List[Tuple[str, str]], # list of (prediction_direction, actual_outcome_direction)
        baseline_outcomes: List[Tuple[str, str]]
    ) -> Tuple[float, float, float]:
        """
        Calculates counterfactual win-rate of shadow vs. baseline.
        Returns: (shadow_win_rate, baseline_win_rate, delta_pp)
        """
        def wr(outcomes):
            if not outcomes:
                return 0.0
            wins = sum(1 for p, a in outcomes if p == a)
            return wins / len(outcomes)

        shadow_wr = wr(shadow_outcomes)
        baseline_wr = wr(baseline_outcomes)
        return shadow_wr, baseline_wr, (shadow_wr - baseline_wr)

    def evaluate_canary_success(
        self,
        *,
        canary_resolved: int,
        prod_resolved: int,
        wr_canary: float,
        wr_prod: float,
        ece_canary: float,
        canary_duration_sec: float,
        loss_streak_canary: int,
        p95_lag_sec: float,
    ) -> Tuple[bool, List[str]]:
        """
        Validates all canary stage success gates:
        - Sample size: n_canary_resolved >= max(30, 0.1 * n_prod_resolved)
        - Duration: >= 72h
        - Win rate non-inferiority: wr_canary >= wr_prod - 0.02
        - Effect size: wr_canary - wr_prod >= 0.03 OR margin improvement
        - Calibration: ECE <= 0.12
        - Safety: loss_streak_canary < 5
        - Federation lag: p95(outcome_ts - signal_ts) < 6h (21600s)
        """
        rejection_reasons = []

        if canary_duration_sec < self.min_canary_duration_sec:
            rejection_reasons.append("insufficient_canary_duration")

        min_required_samples = max(self.min_canary_resolved, int(0.1 * prod_resolved))
        if canary_resolved < min_required_samples:
            rejection_reasons.append(f"insufficient_canary_resolved_samples({canary_resolved}<{min_required_samples})")

        if wr_canary < (wr_prod - 0.02):
            rejection_reasons.append("canary_win_rate_inferiority_violation")

        effect_size = wr_canary - wr_prod
        if effect_size < 0.03:
            rejection_reasons.append(f"insufficient_canary_effect_size_delta({effect_size:.3f}<0.03)")

        if ece_canary > 0.12:
            rejection_reasons.append("canary_ece_calibration_failure")

        if loss_streak_canary >= 5:
            rejection_reasons.append("canary_loss_streak_safety_violation")

        if p95_lag_sec > self.p95_lag_limit_sec:
            rejection_reasons.append("canary_federation_lag_exceeded")

        return len(rejection_reasons) == 0, rejection_reasons

    def evaluate_rollback_trigger(
        self,
        *,
        win_rate_since_promotion: float,
        baseline_win_rate: float,
        resolved_count_since_promotion: int,
    ) -> bool:
        """
        Rollback trigger: wr_since < baseline - 0.05 with n_since >= 20 post-promote.
        """
        if resolved_count_since_promotion < 20:
            return False
        return win_rate_since_promotion < (baseline_win_rate - 0.05)


class HoldoutGovernance:
    """
    Manages and enforces partition rules between training, validation, and holdout datasets,
    guaranteeing zero leakage or training overlap.
    """
    def __init__(self, flywheel: EvaluationFlywheel) -> None:
        self.flywheel = flywheel
        self.training_items_seen: Set[int] = set()

    def assert_safe_to_train(self, item_id: int) -> None:
        """
        Raises ValueError if training is attempted on a locked holdout item.
        """
        if self.flywheel.is_holdout_item(item_id):
            raise ValueError(f"CRITICAL: Holdout Lockbox Overlap Violation! Attempted training on locked item_id: {item_id}")
        self.training_items_seen.add(item_id)

    def assert_safe_to_tune(self, timestamp: float, total_duration_days: float, start_timestamp: float) -> None:
        """
        Raises ValueError if tuning is attempted during the locked holdout window.
        """
        if self.flywheel.is_holdout_time_window(timestamp, total_duration_days, start_timestamp):
            raise ValueError(f"CRITICAL: Holdout Lockbox Overlap Violation! Attempted model tuning/updating during locked time window.")

