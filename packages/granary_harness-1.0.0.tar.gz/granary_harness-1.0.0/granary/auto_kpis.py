from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set


@dataclass(slots=True)
class IntelligenceKpis:
    # Memory KPIs
    total_memories: int = 0
    active_memories: int = 0
    quarantined_memories: int = 0
    average_memory_trust_score: float = 0.0
    
    # Hook KPIs
    total_hooks: int = 0
    enforced_hooks: int = 0
    average_helped_to_harmed_ratio: float = 0.0
    max_recursion_depth_observed: int = 0
    
    # Gate KPIs
    total_gates: int = 0
    blocking_gates: int = 0
    average_gate_ece: float = 0.0
    average_holdout_delta: float = 0.0
    
    # Safety & Violations
    total_violations_flagged: int = 0
    fail_closed_mode_active: bool = False


class IntelligenceKpiTracker:
    """
    Unified KPI stack for automatic memory, hook, and gate quality and safety outcomes.
    Enables cross-system monitoring via the SystemWatchdog.
    """

    def __init__(self) -> None:
        self.kpis = IntelligenceKpis()

    def update_memory_kpis(
        self,
        *,
        total: int,
        active: int,
        quarantined: int,
        avg_trust: float,
    ) -> None:
        self.kpis.total_memories = total
        self.kpis.active_memories = active
        self.kpis.quarantined_memories = quarantined
        self.kpis.average_memory_trust_score = round(avg_trust, 4)

    def update_hook_kpis(
        self,
        *,
        total: int,
        enforced: int,
        avg_helped_harmed: float,
        max_depth: int,
    ) -> None:
        self.kpis.total_hooks = total
        self.kpis.enforced_hooks = enforced
        self.kpis.average_helped_to_harmed_ratio = round(avg_helped_harmed, 4)
        self.kpis.max_recursion_depth_observed = max(self.kpis.max_recursion_depth_observed, max_depth)

    def update_gate_kpis(
        self,
        *,
        total: int,
        blocking: int,
        avg_ece: float,
        avg_holdout_delta: float,
    ) -> None:
        self.kpis.total_gates = total
        self.kpis.blocking_gates = blocking
        self.kpis.average_gate_ece = round(avg_ece, 4)
        self.kpis.average_holdout_delta = round(avg_holdout_delta, 4)

    def record_violation(self) -> None:
        self.kpis.total_violations_flagged += 1

    def set_fail_closed(self, active: bool) -> None:
        self.kpis.fail_closed_mode_active = active

    def generate_kpi_audit_report(self) -> dict:
        """
        Generates a comprehensive diagnostic report of all automatic intelligence subsystems.
        """
        status = "COMPLIANT"
        reasons = []

        # Enforce safety-preserving thresholds
        if self.kpis.quarantined_memories > 5:
            # High quarantine rate indicates potential poisoning attempt
            status = "WARNING"
            reasons.append("high_memory_quarantine_rate")

        if self.kpis.average_gate_ece > 0.15:
            status = "WARNING"
            reasons.append("poor_gate_ece_calibration")

        if self.kpis.max_recursion_depth_observed > 2:
            status = "DEGRADED"
            reasons.append("recursion_depth_limit_violated")

        if self.kpis.fail_closed_mode_active:
            status = "FAIL_CLOSED"
            reasons.append("fail_closed_mode_active")

        return {
            "timestamp": time.time(),
            "status": status,
            "reasons": reasons,
            "subsystems": {
                "memory": {
                    "total": self.kpis.total_memories,
                    "active": self.kpis.active_memories,
                    "quarantined": self.kpis.quarantined_memories,
                    "avg_trust": self.kpis.average_memory_trust_score,
                },
                "hooks": {
                    "total": self.kpis.total_hooks,
                    "enforced": self.kpis.enforced_hooks,
                    "avg_helped_to_harmed_ratio": self.kpis.average_helped_to_harmed_ratio,
                    "max_recursion_depth": self.kpis.max_recursion_depth_observed,
                },
                "gates": {
                    "total": self.kpis.total_gates,
                    "blocking": self.kpis.blocking_gates,
                    "avg_ece": self.kpis.average_gate_ece,
                    "avg_holdout_delta": self.kpis.average_holdout_delta,
                },
                "security": {
                    "total_violations": self.kpis.total_violations_flagged,
                    "fail_closed_active": self.kpis.fail_closed_mode_active,
                }
            }
        }
