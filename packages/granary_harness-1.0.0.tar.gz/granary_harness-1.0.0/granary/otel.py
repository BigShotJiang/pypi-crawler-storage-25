from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Mapping


TRACEPARENT = "traceparent"
TRACESTATE = "tracestate"
BAGGAGE = "baggage"


class AgentSpanAttributes:
    # Standardized 2026 GenAI/MCP/Agentic OpenTelemetry Semantic Conventions
    GEN_AI_OPERATION_NAME = "gen_ai.operation.name"
    MCP_TOOL_NAME = "mcp.tool.name"
    MCP_SERVER_NAME = "mcp.server.name"
    
    # Correlation Keys
    AGENT_ID = "agent.id"
    AGENT_OWNER = "agent.owner"
    TASK_ID = "task.id"
    SESSION_ID = "session.id"
    APPROVAL_ID = "approval.id"
    DEPLOYMENT_ID = "deployment.id"


@dataclass(slots=True)
class TraceContext:
    traceparent: str
    tracestate: str = ""
    baggage: str = ""

    def to_meta(self) -> Dict[str, str]:
        meta = {TRACEPARENT: self.traceparent}
        if self.tracestate:
            meta[TRACESTATE] = self.tracestate
        if self.baggage:
            meta[BAGGAGE] = self.baggage
        return meta


def inject_trace_context(params: Dict[str, object], context: TraceContext) -> Dict[str, object]:
    """
    Inject W3C trace context into JSON-RPC params._meta.
    """
    out = dict(params)
    meta = dict(out.get("_meta", {}))
    meta.update(context.to_meta())
    out["_meta"] = meta
    return out


def extract_trace_context(meta: Mapping[str, str]) -> TraceContext:
    traceparent = meta.get(TRACEPARENT, "")
    if not traceparent:
        raise ValueError("traceparent missing from _meta")
    return TraceContext(
        traceparent=traceparent,
        tracestate=meta.get(TRACESTATE, ""),
        baggage=meta.get(BAGGAGE, ""),
    )


class OTelRedactionProcessor:
    """
    Redaction processor that automatically masks credentials or sensitive data
    present inside Span attributes or serialized payloads.
    """

    def __init__(self) -> None:
        self.sensitive_patterns = [
            re.compile(r"(?i)(password|token|key|secret|credential|auth)"),
        ]

    def redact_attributes(self, attributes: Dict[str, str]) -> Dict[str, str]:
        redacted = {}
        for k, v in attributes.items():
            if any(pattern.search(k) for pattern in self.sensitive_patterns):
                redacted[k] = "[REDACTED]"
            else:
                # Also check value for potential bearer tokens or passwords
                if "bearer " in v.lower() or "ghp_" in v:
                    redacted[k] = "[REDACTED_SENSITIVE_VALUE]"
                else:
                    redacted[k] = v
        return redacted

