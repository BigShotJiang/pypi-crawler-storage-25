from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional


log = logging.getLogger(__name__)


class AgentSloMonitor:
    """
    Tracks Service Level Indicators (SLIs), monitors against Service Level Objectives (SLOs),
    and drives the SLA breach escalation ladder.
    """

    def __init__(self, bus, base_turn_limit: float = 35.0, min_resolve_rate: float = 0.85):
        self.bus = bus
        self.turn_limit = base_turn_limit
        self.min_resolve_rate = min_resolve_rate
        
        # Sliding performance windows
        self.recent_turn_durations: List[float] = []
        self.recent_resolutions: List[bool] = []  # List of bools (True = resolved, False = failed/aborted)
        
        self.escalation_state = "CLOSED"  # "CLOSED", "DEGRADED", "EMERGENCY_PAUSE"
        self.consecutive_breaches = 0

    def record_turn_telemetry(self, duration_sec: float, was_successful: bool) -> None:
        """Registers metrics and checks against active SLO limits."""
        self.recent_turn_durations.append(duration_sec)
        self.recent_resolutions.append(was_successful)
        
        # Keep windows sliding (cap length at 20)
        if len(self.recent_turn_durations) > 20:
            self.recent_turn_durations.pop(0)
        if len(self.recent_resolutions) > 20:
            self.recent_resolutions.pop(0)
            
        self.evaluate_slas()

    def evaluate_slas(self) -> str:
        """Computes current sliding averages and manages escalation states."""
        if len(self.recent_turn_durations) < 5:
            return self.escalation_state  # Warm-up phase; skip evaluation
            
        avg_turn = sum(self.recent_turn_durations[-5:]) / 5.0
        avg_resolve = sum(self.recent_resolutions[-20:]) / max(1, len(self.recent_resolutions[-20:]))
        
        # Check breaches
        breached = False
        reasons = []
        
        if avg_turn > self.turn_limit:
            breached = True
            reasons.append(f"Turn latency breach ({avg_turn:.1f}s > {self.turn_limit}s)")
        if avg_resolve < self.min_resolve_rate:
            breached = True
            reasons.append(f"SLA Resolve Rate breach ({avg_resolve*100:.1f}% < {self.min_resolve_rate*100}%)")
            
        if breached:
            self.consecutive_breaches += 1
            self._handle_sla_breach(reasons)
        else:
            self.consecutive_breaches = 0
            if self.escalation_state == "DEGRADED":
                self.escalation_state = "CLOSED"
                log.info("SloMonitor: All SLAs restored. Transitioning back to CLOSED state.")
                self.bus.publish("slo.restored", {"state": "CLOSED"})
                
        return self.escalation_state

    def _handle_sla_breach(self, reasons: list[str]) -> None:
        """Drives transition states based on breach severity."""
        log.warning(f"SloMonitor: SLA Breach Alert! Reasons: {reasons}")
        
        if self.consecutive_breaches >= 3:
            # Transition to EMERGENCY_PAUSE
            self.escalation_state = "EMERGENCY_PAUSE"
            log.critical("SloMonitor: Multi-SLA Breach threshold reached. Transitioning to EMERGENCY_PAUSE!")
            self.bus.publish("slo.escalation_emergency", {
                "state": "EMERGENCY_PAUSE",
                "reasons": reasons,
                "consecutive_breaches": self.consecutive_breaches
            })
        else:
            # Transition to DEGRADED
            self.escalation_state = "DEGRADED"
            log.warning("SloMonitor: SLA Breach registered. Transitioning to DEGRADED state.")
            self.bus.publish("slo.escalation_degraded", {
                "state": "DEGRADED",
                "reasons": reasons,
                "consecutive_breaches": self.consecutive_breaches
            })
