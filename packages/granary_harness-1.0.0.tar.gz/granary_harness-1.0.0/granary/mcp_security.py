from __future__ import annotations

import ipaddress
import time
from urllib.parse import urlparse
from typing import Dict, List, Optional, Set


class RiskTier:
    T0 = "T0_read"
    T1 = "T1_write"
    T2 = "T2_external"
    T3 = "T3_destructive"


class McpTrustGateway:
    """
    Enforces strict risk tiering, OAuth scope checks, redirect hardening,
    and replay protection for Model Context Protocol (MCP) tool connections.
    """

    def __init__(
        self,
        action_tiers: dict[str, str],
        action_scopes: dict[str, list[str]],
        allowed_redirect_uris: set[str] | List[str]
    ):
        self.action_tiers = action_tiers
        self.action_scopes = action_scopes
        self.allowed_redirect_uris = set(allowed_redirect_uris)
        self._pending: dict[str, dict] = {}
        self._used_jti: set[str] = set()

    def validate_redirect_uri(self, uri: str, deny_private: bool = True) -> bool:
        if uri not in self.allowed_redirect_uris:
            return False
        p = urlparse(uri)
        if p.scheme not in ("http", "https", "cursor"):
            return False
        if deny_private and p.hostname:
            try:
                ip = ipaddress.ip_address(p.hostname)
                if ip.is_private and p.hostname not in ("127.0.0.1", "::1"):
                    return False
                if ip.is_link_local or (ip.is_loopback and p.hostname not in ("127.0.0.1", "::1")):
                    return False
            except ValueError:
                pass
        return True

    def authorize_tool(
        self,
        principal: str,
        tool_name: str,
        claims: dict,
        principal_allow: list[str]
    ) -> dict:
        # 1. Validate JWT Token expiration
        if time.time() > claims.get("exp", 0):
            return {"allowed": False, "reason": "token_expired"}
            
        # 2. Check JTI replay attack
        jti = claims.get("jti")
        if not jti or jti in self._used_jti:
            return {"allowed": False, "reason": "jti_replay"}
            
        # 3. Check scope alignment
        required_scopes = self.action_scopes.get(tool_name, [])
        token_scopes = set(claims.get("scope", "").split())
        for sc in required_scopes:
            if sc not in token_scopes:
                return {"allowed": False, "reason": "insufficient_scope"}

        tier = self.action_tiers.get(tool_name, RiskTier.T2)
        if tier in principal_allow or "*" in principal_allow:
            if tier in (RiskTier.T0, RiskTier.T1):
                self._used_jti.add(jti)
                return {"allowed": True, "reason": "auto_allowed"}
                
            # T2/T3 actions require human intervention
            pid = f"pending:{jti}:{tool_name}"
            self._pending[pid] = {
                "principal": principal,
                "tool": tool_name,
                "tier": tier,
                "created_at": time.time()
            }
            return {"allowed": False, "reason": "approval_required", "pending_id": pid}

        return {"allowed": False, "reason": "principal_denied"}

    def approve_pending(self, pending_id: str, approver: str) -> bool:
        rec = self._pending.pop(pending_id, None)
        if not rec:
            return False
        # Extract JTI from the pending ID
        parts = pending_id.split(":")
        if len(parts) >= 2:
            self._used_jti.add(parts[1])
        return True
