from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


class WorkspaceBoundarySandbox:
    """
    Enforces directory boundaries, normalizes parent segments, and translates
    workspace path aliases between Linux and Windows hosts.
    """

    def __init__(self, workspace_root: str, path_alias_table: dict[str, str] | None = None) -> None:
        self.workspace_root = os.path.abspath(workspace_root)
        self.path_alias_table = path_alias_table or {
            "/home/shell/living-nn": "C:\\Users\\klasi\\Documents\\living-nn",
            "C:\\Users\\klasi\\Documents\\living-nn": "/home/shell/living-nn"
        }

    def translate_path(self, path: str, target_os: str = "linux") -> str:
        """
        Translates a path between host platforms using the path alias table.
        """
        normalized_path = path.replace("\\", "/")
        for linux_alias, win_alias in self.path_alias_table.items():
            linux_norm = linux_alias.replace("\\", "/")
            win_norm = win_alias.replace("\\", "/")
            
            if target_os == "linux" and normalized_path.startswith(win_norm):
                translated = normalized_path.replace(win_norm, linux_norm)
                return os.path.abspath(translated)
            elif target_os == "windows" and normalized_path.startswith(linux_norm):
                translated = normalized_path.replace(linux_norm, win_norm)
                return translated.replace("/", "\\")
        return path

    def is_within_boundary(self, path: str) -> bool:
        """
        Ensures target path does not escape the active workspace_root boundary via traversal.
        """
        translated = self.translate_path(path, target_os="linux")
        resolved = os.path.abspath(translated)
        return resolved == self.workspace_root or resolved.startswith(self.workspace_root + os.sep)


class CredentialSegregationPolicy:
    """
    Enforces secure credential segregation, blanking out sensitive GFO/Railway
    and other production secrets from being passed to tools or sandboxes.
    """

    def __init__(self) -> None:
        self.sensitive_env_keys = {
            "GFO_SERVER_URL", "GFO_SECRET", "RAILWAY_TOKEN", "AWS_SECRET_ACCESS_KEY",
            "DATABASE_URL", "JWT_SECRET"
        }

    def filter_env_context(self, env_dict: dict[str, str]) -> dict[str, str]:
        """
        Removes sensitive secrets, replacing them with mocked tokens for sandbox execution.
        """
        clean = dict(env_dict)
        for key in self.sensitive_env_keys:
            if key in clean:
                clean[key] = f"MOCK_SEGREGATED_{key}_TOKEN"
        return clean


class DockerSandboxIntegration:
    """
    Models execution bounds inside isolated Docker containers (sbx) with
    default-deny network capabilities, CAP_SYS_ADMIN drop rules, and read-only host mounts.
    """

    def __init__(self, allowed_domains: List[str] | None = None) -> None:
        self.allowed_domains = allowed_domains or ["github.com", "pypi.org"]
        self.read_only_mounts = ["/usr/lib", "/lib"]
        self.dropped_capabilities = ["CAP_SYS_ADMIN", "CAP_NET_ADMIN", "CAP_SYS_RAWIO"]

    def build_docker_run_args(self, image: str, workspace_mount: str, command: str) -> List[str]:
        args = ["docker", "run", "--rm"]
        
        # 1. Drop capabilities
        for cap in self.dropped_capabilities:
            args.extend(["--cap-drop", cap])

        # 2. Add seccomp security option
        args.extend(["--security-opt", "no-new-privileges=true"])

        # 3. Add read-only mounts
        for path in self.read_only_mounts:
            args.extend(["-v", f"{path}:{path}:ro"])

        # 4. Bind-mount active workspace root
        args.extend(["-v", f"{workspace_mount}:/workspace"])
        args.extend(["--workdir", "/workspace"])

        args.extend([image, "/bin/sh", "-c", command])
        return args


class UntrustedToolInterceptor:
    """
    syscall and tool-call interceptor that restricts unauthorized git-hook or
    systemd write commands.
    """

    def __init__(self) -> None:
        self.banned_write_patterns = [
            re.compile(r"\.git/hooks/"),
            re.compile(r"/etc/systemd/"),
            re.compile(r"~/\.config/systemd/")
        ]

    def authorize_write(self, filepath: str) -> bool:
        """
        Returns False if write targets banned lifecycle directories without explicit authorization.
        """
        normalized = filepath.replace("\\", "/")
        for pattern in self.banned_write_patterns:
            if pattern.search(normalized):
                return False
        return True
