from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, Dict, List, Optional, Set, Tuple


class FallbackLevel(IntEnum):
    L0_HOT_CONTINUE = 0
    L1_CONTINUATION_MANIFEST = 1
    L2_MANIFEST_LIVING_PATCH = 2
    L3_CROSS_MODEL_HANDOFF = 3
    L4_TRANSCRIPT_COMPRESSION = 4
    L5_HUMAN_GATED_RESTART = 5


@dataclass(slots=True)
class XMHSnapshot:
    session_id: str
    original_model: str
    receiver_model: str
    canonical_layer: Dict[str, Any]      # Stable decisions and requirements
    living_layer: List[Dict[str, Any]]    # Active tasks and pending work
    immutable_layer: Dict[str, str]       # File hashes / frozen state
    created_at: float = field(default_factory=time.time)


@dataclass(slots=True)
class CapabilityGapMatrix:
    supported_capabilities: Set[str]
    missing_capabilities: Set[str]
    degraded_runbooks: Dict[str, str]      # Mitigation steps per missing capability


class ContinuityFallbackLadder:
    """
    Implements the L0-L5 continuity fallback ladder from hot-continue through human-gated restart.
    """

    def __init__(self) -> None:
        self.current_level = FallbackLevel.L0_HOT_CONTINUE

    def escalate_fallback(self) -> FallbackLevel:
        if self.current_level < FallbackLevel.L5_HUMAN_GATED_RESTART:
            self.current_level = FallbackLevel(self.current_level + 1)
        return self.current_level

    def reset_fallback(self) -> None:
        self.current_level = FallbackLevel.L0_HOT_CONTINUE


class CapabilityNegotiationProtocol:
    """
    Implements model-neutral sender-receiver capability negotiation and gap-matrix generation.
    """

    def negotiate_capabilities(
        self,
        sender_requirements: Set[str],
        receiver_capabilities: Set[str]
    ) -> CapabilityGapMatrix:
        supported = sender_requirements & receiver_capabilities
        missing = sender_requirements - receiver_capabilities
        
        # Define degraded runbooks for missing capabilities
        degraded_runbooks = {}
        if "strict_json_schema" in missing:
            degraded_runbooks["strict_json_schema"] = "Fallback to non-strict schema, parse output with local pydantic validator gates"
        if "parallel_tool_calls" in missing:
            degraded_runbooks["parallel_tool_calls"] = "Execute tool calls sequentially inside the loop, adding delay buffers"
        if "image_vision_reading" in missing:
            degraded_runbooks["image_vision_reading"] = "Fallback to OCR-text preprocessing, feed text-extract to suffix query"

        return CapabilityGapMatrix(
            supported_capabilities=supported,
            missing_capabilities=missing,
            degraded_runbooks=degraded_runbooks
        )


class DeterminismCheckingHarness:
    """
    Compares the first 3 actual tool calls post-resume against an expected trace
    to detect semantic drift and prevent duplicate loop executions.
    """

    def __init__(self, expected_tool_trace: List[Tuple[str, dict]]) -> None:
        self.expected_tool_trace = expected_tool_trace[:3]
        self.actual_tool_trace: List[Tuple[str, dict]] = []

    def record_actual_tool_call(self, tool: str, args: dict) -> Tuple[bool, str]:
        """
        Records an actual tool call and checks for determinism alignment.
        Returns: (is_deterministic, drift_reason_or_ok)
        """
        if len(self.actual_tool_trace) >= 3:
            return True, "outside_determinism_eval_window"

        idx = len(self.actual_tool_trace)
        self.actual_tool_trace.append((tool, args))
        
        if idx >= len(self.expected_tool_trace):
            return False, "drift_detected: unexpected_extra_tool_call_executed"

        expected_tool, expected_args = self.expected_tool_trace[idx]
        if expected_tool != tool:
            return False, f"drift_detected: expected tool {expected_tool}, got {tool}"

        # Check argument hashes
        h_expected = hashlib.sha256(repr(sorted(expected_args.items())).encode()).hexdigest()[:8]
        h_actual = hashlib.sha256(repr(sorted(args.items())).encode()).hexdigest()[:8]
        
        if h_expected != h_actual:
            return False, f"drift_detected: argument mismatch on tool {tool} (expected_args={expected_args}, got={args})"

        return True, "aligned"


def calculate_resume_determinism_kpis(
    harness: DeterminismCheckingHarness,
    rework_count: int,
    total_steps: int
) -> dict[str, float]:
    """
    Computes resume determinism and rework-loss metrics.
    """
    # 1. Determinism score: % of aligned tool calls inside the first 3 steps window
    actual_len = len(harness.actual_tool_trace)
    aligned_count = 0
    for i, (tool, args) in enumerate(harness.actual_tool_trace):
        if i < len(harness.expected_tool_trace):
            exp_tool, exp_args = harness.expected_tool_trace[i]
            if exp_tool == tool:
                h_exp = hashlib.sha256(repr(sorted(exp_args.items())).encode()).hexdigest()[:8]
                h_act = hashlib.sha256(repr(sorted(args.items())).encode()).hexdigest()[:8]
                if h_exp == h_act:
                    aligned_count += 1

    determinism_score = aligned_count / max(1, len(harness.expected_tool_trace))
    
    # 2. Rework-loss ratio: rework_count / total_steps
    rework_loss = rework_count / max(1, total_steps)

    return {
        "resume_determinism_score": round(determinism_score, 4),
        "rework_loss_ratio": round(rework_loss, 4),
    }
