from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple


@dataclass(slots=True)
class RoleMetrics:
    success_count: int = 0
    failure_count: int = 0
    consecutive_failures: int = 0
    avg_latency_ms: float = 0.0
    accuracy_score: float = 0.5


@dataclass(slots=True)
class AgentRole:
    module_name: str
    capability_name: str
    lifecycle_state: str # SHADOW, CANDIDATE, ACTIVE, DEGRADED, RECOVERING, RETIRED
    tool_allowlist: List[str]
    max_autonomy_tier: str # T0, T1, T2, T3, T4
    metrics: RoleMetrics = field(default_factory=RoleMetrics)
    last_used_at: float = field(default_factory=time.time)
    created_at: float = field(default_factory=time.time)


class RoleRegistry:
    """
    Manages capability-scoped AgentRoles, state transitions, promotion gates,
    anti-sprawl merge controls, and discovery signals.
    """

    def __init__(self, max_roles_limit: int = 20) -> None:
        self.roles: Dict[Tuple[str, str], AgentRole] = {}
        self.max_roles_limit = max_roles_limit

    def register_role(
        self,
        module_name: str,
        capability_name: str,
        tool_allowlist: List[str],
        max_autonomy_tier: str,
        initial_state: str = "SHADOW",
    ) -> Optional[AgentRole]:
        """
        Registers a new AgentRole in the registry, enforcing hard sprawl caps.
        """
        # Exclude retired roles from sprawl limit
        active_roles = [r for r in self.roles.values() if r.lifecycle_state != "RETIRED"]
        if len(active_roles) >= self.max_roles_limit:
            # Enforce sprawl cap: deny new role creation
            return None

        role = AgentRole(
            module_name=module_name,
            capability_name=capability_name,
            lifecycle_state=initial_state,
            tool_allowlist=list(tool_allowlist),
            max_autonomy_tier=max_autonomy_tier,
        )
        self.roles[(module_name, capability_name)] = role
        return role

    def transition_state(self, module_name: str, capability_name: str, target_state: str) -> bool:
        """
        Enforces state transitions and safety guards for the Role state machine.
        Allowed transitions:
        SHADOW -> CANDIDATE -> ACTIVE -> DEGRADED -> RECOVERING -> ACTIVE
        Any state -> RETIRED
        """
        role = self.roles.get((module_name, capability_name))
        if not role:
            return False

        allowed_transitions = {
            "SHADOW": {"CANDIDATE", "RETIRED"},
            "CANDIDATE": {"ACTIVE", "SHADOW", "RETIRED"},
            "ACTIVE": {"DEGRADED", "RETIRED"},
            "DEGRADED": {"RECOVERING", "RETIRED"},
            "RECOVERING": {"ACTIVE", "DEGRADED", "RETIRED"},
            "RETIRED": set(), # Terminal state
        }

        current = role.lifecycle_state
        if target_state not in allowed_transitions[current] and target_state != "RETIRED":
            return False

        role.lifecycle_state = target_state
        return True

    def evaluate_promotion_gate(self, module_name: str, capability_name: str) -> bool:
        """
        Validates whether a candidate role meets criteria to be promoted to ACTIVE.
        Criteria:
        - Minimum sample size of 30 successful evaluations.
        - Accuracy score >= 0.70.
        - Zero security violations (consecutive failures < 3).
        """
        role = self.roles.get((module_name, capability_name))
        if not role or role.lifecycle_state != "CANDIDATE":
            return False

        total_samples = role.metrics.success_count + role.metrics.failure_count
        if total_samples < 30:
            return False

        if role.metrics.accuracy_score < 0.70:
            return False

        if role.metrics.consecutive_failures >= 3:
            return False

        return self.transition_state(module_name, capability_name, "ACTIVE")

    def evaluate_demotion_or_retirement(self, module_name: str, capability_name: str) -> str | None:
        """
        Evaluates and applies demotion or retirement gates.
        - If active role has consecutive_failures >= 3, demote to DEGRADED.
        - If role is degraded and has been idle (unused) for > 30 days (simulated), retire it.
        """
        role = self.roles.get((module_name, capability_name))
        if not role:
            return None

        now = time.time()
        
        if role.lifecycle_state == "ACTIVE" and role.metrics.consecutive_failures >= 3:
            self.transition_state(module_name, capability_name, "DEGRADED")
            return "DEGRADED"

        if role.lifecycle_state == "DEGRADED" and (now - role.last_used_at) > (30 * 24 * 60 * 60):
            self.transition_state(module_name, capability_name, "RETIRED")
            return "RETIRED"

        return None

    def merge_sprawl_roles(self, module_name: str, target_capability: str, source_capability: str) -> bool:
        """
        Anti-sprawl merge policy: Merges overlapping source and target capabilities of a module.
        """
        target_role = self.roles.get((module_name, target_capability))
        source_role = self.roles.get((module_name, source_capability))
        if not target_role or not source_role:
            return False

        # Merge tool list permissions
        merged_tools = list(set(target_role.tool_allowlist) | set(source_role.tool_allowlist))
        target_role.tool_allowlist = merged_tools

        # Retain highest max autonomy tier
        tier_levels = {"T0": 0, "T1": 1, "T2": 2, "T3": 3, "T4": 4}
        target_level = tier_levels.get(target_role.max_autonomy_tier, 0)
        source_level = tier_levels.get(source_role.max_autonomy_tier, 0)
        if source_level > target_level:
            target_role.max_autonomy_tier = source_role.max_autonomy_tier

        # Retype source to retired
        source_role.lifecycle_state = "RETIRED"
        return True

    def discover_role_hotspots(
        self,
        *,
        routing_misses: int,
        breaker_faults: int,
        curiosity_events: int,
        outcome_gaps: float,
    ) -> float:
        """
        Hotspot-weighted discovery algorithm: computes a unified "Discovery Heat Index".
        If index is >= 7.5, triggers new candidate role spawning.
        Formula:
        Heat = (routing_misses * 0.4) + (breaker_faults * 0.3) + (curiosity_events * 0.1) + (outcome_gaps * 0.2)
        """
        heat_index = (
            (routing_misses * 0.4) +
            (breaker_faults * 0.3) +
            (curiosity_events * 0.1) +
            (outcome_gaps * 0.2)
        )
        return round(heat_index, 2)
