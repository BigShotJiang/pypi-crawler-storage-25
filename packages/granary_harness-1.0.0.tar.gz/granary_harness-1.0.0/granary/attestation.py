from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List


HEX_CHARS = set("0123456789abcdefABCDEF")


def _is_hex(value: str) -> bool:
    return bool(value) and all(ch in HEX_CHARS for ch in value)


@dataclass(slots=True)
class NitroMeasurements:
    """
    Canonical Nitro enclave measurements used for KMS attestation gates.
    """

    image_sha384: str
    pcr0: str
    pcr1: str
    pcr2: str
    pcr3: str
    pcr4: str

    def validate(self) -> None:
        fields = {
            "image_sha384": self.image_sha384,
            "pcr0": self.pcr0,
            "pcr1": self.pcr1,
            "pcr2": self.pcr2,
            "pcr3": self.pcr3,
            "pcr4": self.pcr4,
        }
        for name, value in fields.items():
            if not _is_hex(value):
                raise ValueError(f"{name} must be a non-empty hex string")
            if len(value) < 64:
                raise ValueError(f"{name} hash is too short: expected >= 64 hex chars")


def generate_kms_attestation_policy(
    *,
    principal_arn: str,
    measurements: NitroMeasurements,
    actions: Iterable[str] | None = None,
) -> Dict[str, object]:
    """
    Build an AWS KMS key policy statement requiring Nitro attestation PCR match.
    """
    measurements.validate()
    resolved_actions: List[str] = list(
        actions
        if actions is not None
        else (
            "kms:Decrypt",
            "kms:GenerateDataKey",
            "kms:GenerateRandom",
        )
    )
    return {
        "Version": "2012-10-17",
        "Statement": [
            {
                "Sid": "EnforceNitroEnclaveAttestation",
                "Effect": "Allow",
                "Principal": {"AWS": principal_arn},
                "Action": resolved_actions,
                "Resource": "*",
                "Condition": {
                    "StringEqualsIgnoreCase": {
                        "kms:RecipientAttestation:ImageSha384": measurements.image_sha384,
                        "kms:RecipientAttestation:PCR0": measurements.pcr0,
                        "kms:RecipientAttestation:PCR1": measurements.pcr1,
                        "kms:RecipientAttestation:PCR2": measurements.pcr2,
                        "kms:RecipientAttestation:PCR3": measurements.pcr3,
                        "kms:RecipientAttestation:PCR4": measurements.pcr4,
                    }
                },
            }
        ],
    }
