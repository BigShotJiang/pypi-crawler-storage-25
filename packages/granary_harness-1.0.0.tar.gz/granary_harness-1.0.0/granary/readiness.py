from __future__ import annotations

import os
import re
import shutil
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple


@dataclass(slots=True)
class Waiver:
    waiver_id: str
    blocker_id: str
    expires_at: float
    authorized_by: str
    rollback_plan_verified: bool


@dataclass(slots=True)
class GateResult:
    id: str
    description: str
    passed: bool
    observed_value: str
    expected_value: str
    waived: bool = False


class GoNoGoDecisionMatrix:
    """
    Enforces the machine-calculable, strict pre-deployment Go/No-Go Gates and Waiver Policy.
    """

    def __init__(self, owner: str = "Max") -> None:
        self.owner = owner
        self.active_waivers: Dict[str, Waiver] = {}

    def add_waiver(self, waiver: Waiver) -> bool:
        # Idempotency safeguards: under no circumstances can idempotency checks or
        # TOS public surface checks be waived.
        if "idempotency" in waiver.blocker_id.lower() or "tos_public_surface" in waiver.blocker_id.lower():
            return False
        self.active_waivers[waiver.blocker_id] = waiver
        return True

    def evaluate_gate(
        self,
        *,
        gate_id: str,
        description: str,
        check_command_output: str,
        expected: str,
        now_ts: Optional[float] = None
    ) -> GateResult:
        current_time = now_ts or time.time()
        
        # Exact match check or substring check
        passed = False
        observed = check_command_output.strip()
        expected_clean = expected.strip()

        if expected_clean.startswith(">="):
            try:
                limit = float(expected_clean[2:].strip())
                val = float(observed)
                passed = val >= limit
            except ValueError:
                passed = observed == expected_clean
        elif expected_clean.startswith("<"):
            try:
                limit = float(expected_clean[1:].strip())
                val = float(observed)
                passed = val < limit
            except ValueError:
                passed = observed == expected_clean
        else:
            passed = (observed == expected_clean) or (expected_clean in observed)

        waived = False
        if not passed:
            # Check if active waiver covers this breach
            waiver = self.active_waivers.get(gate_id)
            if waiver and waiver.rollback_plan_verified:
                if waiver.expires_at > current_time:
                    waived = True

        return GateResult(
            id=gate_id,
            description=description,
            passed=passed or waived,
            observed_value=observed,
            expected_value=expected_clean,
            waived=waived
        )

    def evaluate_all_gates(self, outputs: List[dict]) -> Tuple[bool, List[GateResult]]:
        """
        Drives the entire pre-launch checklist block evaluation.
        Returns Tuple[all_passed, gate_results_list].
        """
        results = []
        all_passed = True
        for out in outputs:
            res = self.evaluate_gate(
                gate_id=out["id"],
                description=out["description"],
                check_command_output=out["observed"],
                expected=out["expected"]
            )
            results.append(res)
            if not res.passed:
                all_passed = False
        return all_passed, results


# ── Day-0 Rollback Drill Restorations ──

def execute_day0_rollback_drill(
    *,
    backup_storage_root: str,
    target_state_path: str,
    session_status_checker: callable
) -> bool:
    """
    Day-0 Rollback Drill (R1 - Cold State Restoration):
    Atomically restores the workspace to the latest verified backup.
    """
    if not os.path.exists(backup_storage_root):
        return False

    # Find the latest backup directory
    backups = [
        os.path.join(backup_storage_root, d)
        for d in os.listdir(backup_storage_root)
        if os.path.isdir(os.path.join(backup_storage_root, d))
    ]
    if not backups:
        return False

    # Sort by directory modification/creation time descending
    backups.sort(key=lambda d: os.path.getmtime(d), reverse=True)
    latest_backup = backups[0]

    # 1. Stop active writer process (via status checker mock or process control)
    session_status_checker("stop")

    # 2. Synchronize directories atomically
    shutil.rmtree(target_state_path, ignore_errors=True)
    shutil.copytree(latest_backup, target_state_path)

    # 3. Restart process and check liveness
    session_status_checker("start")
    liveness_ok = session_status_checker("status") == "healthy"

    return liveness_ok
