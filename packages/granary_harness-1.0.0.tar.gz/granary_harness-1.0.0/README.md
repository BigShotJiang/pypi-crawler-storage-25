# Granary Harness — Standalone Agent Security & Governance

A bio-inspired modular containment and zero-trust security framework for autonomous agents. Originally developed alongside the `living-nn` ecosystem, Granary is now a standalone package that acts as a secure trust gateway, sandbox interceptor, and policy enforcement engine.

## Key Features

- **Dynamic JIT Privilege Elevation**: Implements `AgentAssertionToken` (AAT) with `agent_owner` and `agent_trust_score` claims, alongside RFC 8693 token exchange payloads and RFC 9449 DPoP sender-constraining validation.
- **Operating Constitution**: Enforces a strict, declarative, five-tier (T0-T4) blast-radius boundary limit for filesystem, LOC edits, token budgets, and path overrides via `agent-constitution.yaml`.
- **Offline Red-Teaming (ADVERSA)**: Evaluates prompts and tool calls with automated mutation and multi-judge consensus scoring using `AdversaHarness`.
- **Egress & Tunneling Control (ShieldNet)**: Shannon entropy monitoring and rate limiting over DNS queries to identify exfiltration channels and active tunneling attempts.
- **MCP Trust Gateway**: High-fidelity Model Context Protocol tool interceptors, risk-based gating, and human-in-the-loop approvals.
- **Confidential Enclaves**: Automates AWS KMS key attestation policies tied directly to Nitro enclave Platform Configuration Register (PCR) measurements.

## Project Structure

```
granary-harness/
├── granary/                # Core security modules
│   ├── __init__.py         # Public API (39 fully exported modules)
│   ├── identity.py         # AAT Claims, signatures, and DPoP validation
│   ├── constitution.py     # Operating Constitution and YAML parser
│   ├── readiness.py        # Pre-launch checklists & cold rollbacks
│   ├── adversa.py          # Adversa offline red-teaming
│   ├── mcp_security.py     # MCP tool risk gateways
│   ├── shieldnet.py        # DNS entropy network egress
│   ├── attestation.py      # Nitro enclave attestation
│   └── ...                 # Sandboxing, rollups, self-healing, otel
├── tests/                  # Standalone unittest suites
│   └── test_granary_*.py   # 158 verified unit tests
├── docs/                   # Governance & policy contracts
│   ├── gtm/                # Competitive positioning & matrices
│   ├── agent-constitution.yaml
│   ├── governance-cadence.md
│   └── planning_merge_verification.md
├── pyproject.toml          # Package configuration
├── CLAUDE.md               # Code standards & run commands
└── AGENTS.md               # Autonomous onboarding reference
```

## Setup & Task Automation

Granary includes a standardized local task runner using the project `Makefile`:

-   **Set up standalone environment**: Create `.venv` and install the package in editable development mode:
    ```bash
    make setup
    ```
-   **Run the unit test suite**: Run all 158 tests with verbose reporting:
    ```bash
    make test
    ```
-   **Package compiling**: Compile the project into distributable wheel (`.whl`) and sdist (`.tar.gz`) archives:
    ```bash
    make build
    ```
-   **Pristine cleaning**: Recursively clean caches, bytecode, and packaging/environment folders:
    ```bash
    make clean
    ```

---

## Command-Line Interface (CLI)

The administrative utility is registered natively upon installation as the executable `granary`.

### 1. Constitution Validation
Validate the syntax and autonomy tiers of a declarative agent constitution YAML file:
```bash
granary validate-constitution --path docs/agent-constitution.yaml
```

### 2. Merkle Audit Ledger Management
-   **Export Chain**: Export a mock, cryptographically chained, and redacted compliance ledger:
    ```bash
    granary admin ledger export --work-unit-id "wu_92e8a10f-3a21" --output "./forensics_export.json"
    ```
-   **Verify Chain Integrity**: Scan, recalculate Merkle roots, and verify HSM-signatures over an exported ledger file:
    ```bash
    granary admin ledger verify-chain --input "./forensics_export.json"
    ```

---

## Running Unit Tests

Unit tests are written using Python's built-in, zero-dependency `unittest` module.

To run the complete test suite (158 tests) with no regressions:

```bash
python -m unittest discover -s tests -p "test_granary_*.py" -v
```

---

## MCP Gateway (Cursor / Claude)

Granary exposes a **stdio MCP server** that wraps `McpTrustGateway` for live agent sessions.

### Setup

```bash
make setup   # installs granary-harness[mcp]
```

### Cursor configuration

This repo ships [`.cursor/mcp.json`](.cursor/mcp.json). After setup, restart Cursor or reload MCP servers. You should see **`granary-gateway`** with four tools:

| Tool | Purpose |
|------|---------|
| `granary_authorize_tool` | Risk-tier + scope + JTI replay check before tool execution |
| `granary_approve_pending` | Human approval for T2/T3 actions |
| `granary_validate_redirect` | OAuth redirect URI allowlist check |
| `granary_list_pending` | List queued approval requests |

Run manually:

```bash
granary-mcp
```

Optional custom policy JSON via `GRANARY_MCP_POLICY=/path/to/policy.json`.

---

## Publishing to PyPI

See [`docs/PYPI_RELEASE.md`](docs/PYPI_RELEASE.md) for build, `twine check`, TestPyPI, and production upload steps.

```bash
make build
make publish-check
```
