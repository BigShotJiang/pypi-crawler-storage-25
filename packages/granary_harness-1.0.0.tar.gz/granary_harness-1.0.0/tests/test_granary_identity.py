from datetime import datetime, timezone
import unittest

from granary.identity import AgentAssertionToken, build_token_exchange_request


class TestGranaryIdentity(unittest.TestCase):

    def test_aat_creation_and_payload_shape(self) -> None:
        aat = AgentAssertionToken.create(
            issuer="https://gateway.granary.local",
            subject="user:alice@example.com",
            audience="https://iam.granary-enterprise.internal",
            agent_id="agent:coder-gpt4",
            repository="github.com/acme/repo",
            branch="main",
            commit_sha="abc123",
            task_id="task_1",
            parent_session_id="session_1",
            max_blast_radius="T2_READ_WRITE",
            client_id="granary_cli_v1.2",
            allowed_resources=["urn:github:acme:repo"],
            now=datetime(2026, 5, 22, tzinfo=timezone.utc),
        )
        payload = aat.to_payload()
        assert payload["iss"] == "https://gateway.granary.local"
        assert payload["act"]["sub"] == "agent:coder-gpt4"
        assert payload["task_context"]["task_id"] == "task_1"
        assert payload["may_act"]["allowed_resource_indicators"] == ["urn:github:acme:repo"]

    def test_aat_validate_for_exchange_rejects_unknown_resource(self) -> None:
        aat = AgentAssertionToken.create(
            issuer="https://gateway.granary.local",
            subject="user:alice@example.com",
            audience="https://iam.granary-enterprise.internal",
            agent_id="agent:coder-gpt4",
            repository="github.com/acme/repo",
            branch="main",
            commit_sha="abc123",
            task_id="task_1",
            parent_session_id="session_1",
            max_blast_radius="T2_READ_WRITE",
            client_id="granary_cli_v1.2",
            allowed_resources=["urn:github:acme:repo"],
        )
        with self.assertRaises(ValueError):
            aat.validate_for_exchange("urn:aws:s3:bucket")

    def test_rfc8693_request_shape(self) -> None:
        req = build_token_exchange_request(
            subject_token_jwt="subject.jwt",
            actor_token_jwt="actor.jwt",
            resource="urn:github:acme:repo",
            audience="https://api.github.com",
            scope="repo:write:feature/user-auth",
        )
        body = req.to_json()
        assert body["grant_type"] == "urn:ietf:params:oauth:grant-type:token-exchange"
        assert body["subject_token"] == "subject.jwt"
        assert body["actor_token"] == "actor.jwt"

    def test_aat_owner_and_trust_score_claims(self) -> None:
        aat = AgentAssertionToken.create(
            issuer="https://gateway.granary.local",
            subject="user:alice@example.com",
            audience="https://iam.granary-enterprise.internal",
            agent_id="agent:coder-gpt4",
            repository="github.com/acme/repo",
            branch="main",
            commit_sha="abc123",
            task_id="task_1",
            parent_session_id="session_1",
            max_blast_radius="T2_READ_WRITE",
            client_id="granary_cli_v1.2",
            allowed_resources=["urn:github:acme:repo"],
            now=datetime(2026, 5, 22, tzinfo=timezone.utc),
            agent_owner="oidc:max-dev-1",
            agent_trust_score=0.98,
        )
        payload = aat.to_payload()
        self.assertEqual(payload["agent_owner"], "oidc:max-dev-1")
        self.assertEqual(payload["agent_trust_score"], 0.98)

    def test_aat_cryptographic_signatures(self) -> None:
        aat = AgentAssertionToken.create(
            issuer="https://gateway.granary.local",
            subject="user:alice@example.com",
            audience="https://iam.granary-enterprise.internal",
            agent_id="agent:coder-gpt4",
            repository="github.com/acme/repo",
            branch="main",
            commit_sha="abc123",
            task_id="task_1",
            parent_session_id="session_1",
            max_blast_radius="T2_READ_WRITE",
            client_id="granary_cli_v1.2",
            allowed_resources=["urn:github:acme:repo"],
            now=datetime(2026, 5, 22, tzinfo=timezone.utc),
        )
        secret = "super-secret-key-123"
        sig = aat.generate_signature(secret)
        self.assertTrue(aat.verify_signature(sig, secret))
        self.assertFalse(aat.verify_signature(sig, "wrong-secret"))

    def test_aat_dpop_sender_constraining(self) -> None:
        now_dt = datetime(2026, 5, 22, tzinfo=timezone.utc)
        aat = AgentAssertionToken.create(
            issuer="https://gateway.granary.local",
            subject="user:alice@example.com",
            audience="https://iam.granary-enterprise.internal",
            agent_id="agent:coder-gpt4",
            repository="github.com/acme/repo",
            branch="main",
            commit_sha="abc123",
            task_id="task_1",
            parent_session_id="session_1",
            max_blast_radius="T2_READ_WRITE",
            client_id="granary_cli_v1.2",
            allowed_resources=["urn:github:acme:repo"],
            now=now_dt,
        )
        secret = "secret-jwt-key"
        proof = aat.generate_dpop_proof("POST", "https://api.gateway.local/v1/exchange", secret, now=now_dt)
        
        # Valid proof
        self.assertTrue(aat.validate_dpop_proof(proof, "POST", "https://api.gateway.local/v1/exchange", secret, now=now_dt))
        
        # Invalid method
        self.assertFalse(aat.validate_dpop_proof(proof, "GET", "https://api.gateway.local/v1/exchange", secret, now=now_dt))
        
        # Invalid URI
        self.assertFalse(aat.validate_dpop_proof(proof, "POST", "https://wrong-api.local/v1/exchange", secret, now=now_dt))
        
        # Invalid secret
        self.assertFalse(aat.validate_dpop_proof(proof, "POST", "https://api.gateway.local/v1/exchange", "wrong-secret", now=now_dt))
        
        # Exceeded time skew
        skewed_now = datetime(2026, 5, 22, 0, 10, 0, tzinfo=timezone.utc) # 10 mins later
        self.assertFalse(aat.validate_dpop_proof(proof, "POST", "https://api.gateway.local/v1/exchange", secret, now=skewed_now))

