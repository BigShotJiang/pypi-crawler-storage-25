import unittest
from granary.licensing import (
    create_default_vpc_operator_license,
    generate_node_lock_fingerprint,
    sign_license,
    verify_license,
)


class TestGranaryLicensing(unittest.TestCase):

    def test_license_sign_and_verify_roundtrip(self) -> None:
        fingerprint = generate_node_lock_fingerprint("host-a", "i-123", "x86_64")
        payload = create_default_vpc_operator_license(
            customer_id="cust_acme",
            max_concurrent_sandboxes=50,
            authorized_pcr_roots=["ab" * 48],
            enabled_modules=["identity", "shieldnet"],
            node_lock_fingerprint=fingerprint,
        )
        signature = sign_license(payload, "super-secret")
        assert verify_license(payload, signature, "super-secret") is True

    def test_license_verification_fails_on_secret_mismatch(self) -> None:
        fingerprint = generate_node_lock_fingerprint("host-a", "i-123", "x86_64")
        payload = create_default_vpc_operator_license(
            customer_id="cust_acme",
            max_concurrent_sandboxes=50,
            authorized_pcr_roots=["ab" * 48],
            enabled_modules=["identity", "shieldnet"],
            node_lock_fingerprint=fingerprint,
        )
        signature = sign_license(payload, "super-secret")
        assert verify_license(payload, signature, "wrong-secret") is False

