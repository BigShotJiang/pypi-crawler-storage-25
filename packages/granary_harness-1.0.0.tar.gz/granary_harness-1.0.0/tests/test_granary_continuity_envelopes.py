import unittest
import time
from granary.continuity_envelopes import (
    EnvelopeKind,
    EpistemicNode,
    EpistemicTypingContract,
    ContinuityEnvelope,
    EnvelopeGatePipeline,
    translate_shsc_to_xmh,
    translate_xmh_to_shsc,
    reduce_journal_to_envelope,
)


class TestGranaryContinuityEnvelopes(unittest.TestCase):

    def test_epistemic_typing_contract_and_revocations(self) -> None:
        contract = EpistemicTypingContract()
        
        contract.add_node("node_1", "facts", "Twisted Bow has margin of 500k")
        contract.add_node("node_2", "decisions", "Approved buy order at 500k")
        
        # Check active node counts
        self.assertEqual(len(contract.get_active_by_category("facts")), 1)
        self.assertEqual(len(contract.get_active_by_category("decisions")), 1)

        # Revoke node
        self.assertTrue(contract.revoke_node("node_1"))
        self.assertEqual(len(contract.get_active_by_category("facts")), 0)
        self.assertEqual(len(contract.get_active_by_category("decisions")), 1)

    def test_envelope_gate_pipeline_validations(self) -> None:
        pipeline = EnvelopeGatePipeline(max_age_sec=5.0)
        
        envelope = ContinuityEnvelope(
            artifact_id="shsc_12345",
            artifact_kind=EnvelopeKind.SHSC,
            schema_version="1.0.0",
            producer="test_agent",
            step=100,
            payload={"next_action": "PROC_TEST"},
            parent_trace_id="parent_1"
        )

        # 1. Successful pass
        ok, msg = pipeline.validate_envelope(envelope)
        self.assertTrue(ok, msg)

        # 2. Fails Gate C on stale age
        time.sleep(5.1)
        ok_stale, msg_stale = pipeline.validate_envelope(envelope)
        self.assertFalse(ok_stale)
        self.assertIn("Gate_C_Failed", msg_stale)

    def test_shsc_to_xmh_and_xmh_to_shsc_translations(self) -> None:
        shsc = ContinuityEnvelope(
            artifact_id="shsc_12345",
            artifact_kind=EnvelopeKind.SHSC,
            schema_version="1.0.0",
            producer="model_a",
            step=100,
            payload={"next_action": "PROC_TEST", "workspace_paths": ["C:\\Users\\klasi\\Documents\\living-nn"]},
            parent_trace_id="parent_1"
        )

        # Translate to XMH
        xmh = translate_shsc_to_xmh(shsc, target_model="model_b")
        self.assertEqual(xmh.artifact_kind, EnvelopeKind.XMH)
        self.assertEqual(xmh.payload["receiver_model"], "model_b")
        # Paths translated to portable / notation
        self.assertEqual(xmh.payload["workspace_paths"], ["C:/Users/klasi/Documents/living-nn"])

        # Translate back to SHSC
        shsc_back = translate_xmh_to_shsc(xmh)
        self.assertEqual(shsc_back.artifact_kind, EnvelopeKind.SHSC)
        self.assertNotIn("receiver_model", shsc_back.payload)

    def test_reduce_journal_to_envelope_determinism(self) -> None:
        journal_lines = [
            '{"step": 10, "trace_id": "t1", "payload": {"k1": "v1"}}',
            '{"step": 11, "trace_id": "t2", "payload": {"k2": "v2", "k1": "overwritten"}}',
        ]
        envelope = reduce_journal_to_envelope(journal_lines)
        self.assertIsNotNone(envelope)
        self.assertEqual(envelope.step, 11)
        self.assertEqual(envelope.parent_trace_id, "t2")
        self.assertEqual(envelope.payload["k1"], "overwritten")
        self.assertEqual(envelope.payload["k2"], "v2")
