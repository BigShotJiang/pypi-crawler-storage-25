import os
import shutil
import unittest
import json
import time
from granary.rollups import (
    TaskStatus,
    TaskItem,
    HandoffSnapshot,
    RollupReconciler,
    HandoffSnapshotProtocol,
)


class TestGranaryRollups(unittest.TestCase):

    def setUp(self) -> None:
        self.root = "/tmp/granary_rollups_test_repo"
        shutil.rmtree(self.root, ignore_errors=True)
        os.makedirs(self.root, exist_ok=True)
        self.reconciler = RollupReconciler(self.root)

    def tearDown(self) -> None:
        shutil.rmtree(self.root, ignore_errors=True)

    def test_parse_handoff_md_correctly(self) -> None:
        # Create a mock HANDOFF.md
        os.makedirs(os.path.dirname(self.reconciler.handoff_path), exist_ok=True)
        with open(self.reconciler.handoff_path, "w", encoding="utf-8") as f:
            f.write("""# Handoff Doc
## Pending Work

- [ ] [task_1] Initial design structure
- [~] [task_2] Build first prototype
- [x] [task_3] Implement tests

## Recent Work Completed
""")
        tasks = self.reconciler.parse_handoff_md()
        self.assertEqual(len(tasks), 3)
        self.assertEqual(tasks[0].task_id, "task_1")
        self.assertEqual(tasks[0].status, TaskStatus.PENDING)
        self.assertEqual(tasks[1].task_id, "task_2")
        self.assertEqual(tasks[1].status, TaskStatus.IN_PROGRESS)
        self.assertEqual(tasks[2].task_id, "task_3")
        self.assertEqual(tasks[2].status, TaskStatus.COMPLETED)

    def test_reconcile_with_dry_run_leaves_files_unmodified(self) -> None:
        os.makedirs(os.path.dirname(self.reconciler.handoff_path), exist_ok=True)
        with open(self.reconciler.handoff_path, "w", encoding="utf-8") as f:
            f.write("# Handoff\n## Pending Work\n- [ ] [t1] Initial task\n")

        # Run reconcile in dry-run mode -> files must not change
        ok, warnings, summary = self.reconciler.reconcile(mode="dry_run")
        self.assertTrue(ok)
        self.assertEqual(summary["total_reconciled"], 1)
        self.assertEqual(summary["pending"], 1)

        # Confirm no staged or backup rollups exist
        self.assertFalse(os.path.exists(self.reconciler.rollup_output))

    def test_reconcile_apply_rewrites_handoff_progress_and_rollups(self) -> None:
        # Append some events to journal
        os.makedirs(os.path.dirname(self.reconciler.journal_file), exist_ok=True)
        with open(self.reconciler.journal_file, "w", encoding="utf-8") as f:
            f.write(json.dumps({"event_type": "task_transition", "task_id": "t1", "status": TaskStatus.COMPLETED}) + "\n")
            f.write(json.dumps({"event_type": "task_transition", "task_id": "t2", "status": TaskStatus.IN_PROGRESS}) + "\n")

        # Write starting HANDOFF.md with tasks
        with open(self.reconciler.handoff_path, "w", encoding="utf-8") as f:
            f.write("""# Handoff
## Pending Work
- [ ] [t1] Task 1
- [ ] [t2] Task 2
""")

        ok, warnings, summary = self.reconciler.reconcile(mode="apply")
        self.assertTrue(ok)
        self.assertEqual(summary["completed"], 1) # t1 upgraded to complete
        self.assertEqual(summary["in_progress"], 1) # t2 upgraded to in_progress

        # Verify surgical overwrite occurred
        with open(self.reconciler.handoff_path, "r", encoding="utf-8") as f:
            content = f.read()
        self.assertIn("- [x] [t1]", content)
        self.assertIn("- [~] [t2]", content)

        # Verify PROGRESS.md was generated
        self.assertTrue(os.path.exists(self.reconciler.progress_path))
        with open(self.reconciler.progress_path, "r", encoding="utf-8") as f:
            prog_content = f.read()
        self.assertIn("- [x] [t1]", prog_content)
        self.assertNotIn("- [~] [t2]", prog_content) # In progress is not in progress completed lists

        # Verify latest.json rollback snapshots exist
        self.assertTrue(os.path.exists(self.reconciler.rollup_output))
        self.assertTrue(os.path.exists(self.reconciler.handoff_output))

    def test_handoff_snapshot_quality_scoring(self) -> None:
        protocol = HandoffSnapshotProtocol()
        snapshot = HandoffSnapshot(
            session_id="sess_1",
            branch="main",
            commit_sha="abc12345",
            verification_tier="T1",
            freshness_hash="hash_1",
            supersedes_pointer=None
        )
        
        # High quality score on few pending tasks
        score_high = protocol.calculate_snapshot_quality(snapshot, pending_tasks=2)
        self.assertGreaterEqual(score_high, 0.70)
        self.assertEqual(snapshot.completeness_score, 0.90)
        self.assertEqual(snapshot.verifiability_score, 1.0)

        # Lower quality score on high pending task backlog
        score_low = protocol.calculate_snapshot_quality(snapshot, pending_tasks=10)
        self.assertLess(score_low, score_high)
        self.assertEqual(snapshot.completeness_score, 0.50)
