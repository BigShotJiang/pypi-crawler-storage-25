import unittest
import time
from granary.auto_hook import (
    HookState,
    FailureFingerprint,
    AgentHook,
    AutoHookManager,
)


class TestGranaryAutoHook(unittest.TestCase):

    def test_failure_fingerprint_sha256_hash_calculation(self) -> None:
        fp = FailureFingerprint(
            fingerprint_id="fp_1",
            error_class="TimeoutError",
            error_prefix="circuit breaker open on query_hop",
            module="ge_trading",
            channel="orchestrator.module_fault",
            stack_top="core.orchestrator.Orchestrator._safe_module_query",
            context_keys=["timeout_sec"],
            step_mod_100=40,
            cluster_id="cluster_1"
        )
        # Verify hash matches SHA256 criteria
        h = fp.calculate_and_set_hash()
        self.assertTrue(fp.hash_sha256.startswith("78") or len(fp.hash_sha256) == 64)

    def test_calculate_specificity_score(self) -> None:
        manager = AutoHookManager()
        
        # High specificity hook
        score_high = manager.calculate_specificity(
            module_exact=True,
            channel_exact=True,
            prefix_regex=True,
            context_keys=True,
            wildcard_fraction=0.0
        )
        # 0.2 + 0.2 + 0.3 + 0.2 + 0.1 * (1.0 - 0.0) = 1.0
        self.assertEqual(score_high, 1.0)

        # Low specificity hook
        score_low = manager.calculate_specificity(
            module_exact=False,
            channel_exact=True,
            prefix_regex=False,
            context_keys=False,
            wildcard_fraction=0.8
        )
        # 0.0 + 0.2 + 0.0 + 0.0 + 0.1 * 0.2 = 0.22
        self.assertEqual(score_low, 0.22)

    def test_register_hook_limits_and_sprawl_caps(self) -> None:
        manager = AutoHookManager(max_hooks_per_group=2)
        
        h1 = AgentHook(
            id="hook_1",
            version=1,
            state=HookState.ENFORCE,
            fingerprint_cluster="cluster_1",
            trigger_channels=["orchestrator.module_fault"],
            trigger_match={"module": "ge_trading"},
            trigger_cooldown_sec=60,
            action_type="orchestrator.schedule_probe",
            action_params={},
            capped_group="group_a"
        )
        h2 = AgentHook(
            id="hook_2",
            version=1,
            state=HookState.ENFORCE,
            fingerprint_cluster="cluster_1",
            trigger_channels=["orchestrator.module_fault"],
            trigger_match={"module": "ge_trading"},
            trigger_cooldown_sec=60,
            action_type="orchestrator.schedule_probe",
            action_params={},
            capped_group="group_a"
        )
        self.assertTrue(manager.register_hook(h1))
        self.assertTrue(manager.register_hook(h2))

        # 3rd hook in same group_a should fail registration due to sprawl cap limit of 2
        h3 = AgentHook(
            id="hook_3",
            version=1,
            state=HookState.ENFORCE,
            fingerprint_cluster="cluster_1",
            trigger_channels=["orchestrator.module_fault"],
            trigger_match={"module": "ge_trading"},
            trigger_cooldown_sec=60,
            action_type="orchestrator.schedule_probe",
            action_params={},
            capped_group="group_a"
        )
        self.assertFalse(manager.register_hook(h3))

    def test_hook_lifecycle_state_machine_transitions(self) -> None:
        manager = AutoHookManager()
        hook = AgentHook(
            id="hook_1",
            version=1,
            state=HookState.REPLAY,
            fingerprint_cluster="cluster_1",
            trigger_channels=["orchestrator.module_fault"],
            trigger_match={"module": "ge_trading"},
            trigger_cooldown_sec=60,
            action_type="orchestrator.schedule_probe",
            action_params={},
        )
        manager.register_hook(hook)

        # Replay pass rate is too low -> state stays REPLAY
        hook.replay_pass_rate = 0.50
        self.assertEqual(manager.evaluate_lifecycle_progression(hook.id), HookState.REPLAY)

        # 1. Replay -> Shadow
        hook.replay_pass_rate = 0.85
        self.assertEqual(manager.evaluate_lifecycle_progression(hook.id), HookState.SHADOW)

        # 2. Shadow -> Canary
        hook.shadow_helped = 28
        hook.shadow_harmed = 4 # total 32, helped:harmed ratio = 7 > 4
        self.assertEqual(manager.evaluate_lifecycle_progression(hook.id), HookState.CANARY)

        # 3. Canary -> Enforce
        hook.canary_real_events_count = 55
        hook.canary_lift_delta = 0.03
        hook.specificity_score = 0.75 # >= 0.65 floor
        self.assertEqual(manager.evaluate_lifecycle_progression(hook.id), HookState.ENFORCE)

        # 4. Enforce -> Decay on idle
        now_future = time.time() + (35 * 24 * 3600) # 35 days in future
        self.assertEqual(manager.evaluate_lifecycle_progression(hook.id, now=now_future), HookState.DECAY)

    def test_recursion_depth_limit_guards(self) -> None:
        manager = AutoHookManager()
        hook = AgentHook(
            id="hook_1",
            version=1,
            state=HookState.ENFORCE,
            fingerprint_cluster="cluster_1",
            trigger_channels=["orchestrator.module_fault"],
            trigger_match={"module": "ge_trading"},
            trigger_cooldown_sec=60,
            action_type="orchestrator.schedule_probe",
            action_params={},
            max_depth=2
        )
        manager.register_hook(hook)

        # Execute at depth 0 -> OK
        manager.active_execution_depth = 0
        self.assertTrue(manager.trigger_hook_execution(hook.id))

        # Execute at depth 2 (equals max_depth limit) -> Blocker / False
        manager.active_execution_depth = 2
        self.assertFalse(manager.trigger_hook_execution(hook.id))
