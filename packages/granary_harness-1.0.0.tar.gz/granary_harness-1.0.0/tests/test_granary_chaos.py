import unittest
import time
from typing import Dict, List, Optional
from granary.chaos import AgentChaosMonkey, ChaosExperimentRecord


class MockBus:
    def __init__(self) -> None:
        self.published: List[tuple] = []

    def publish(self, channel: str, data: dict) -> None:
        self.published.append((channel, data))


class MockWatchdog:
    def __init__(self, memory: float = 20.0, open_breakers: int = 0, steps_hz: float = 2.0) -> None:
        self.status = {
            "memory_usage_pct": memory,
            "open_breakers_count": open_breakers,
            "steps_per_second": steps_hz,
        }


class MockSystem:
    pass


class TestGranaryChaos(unittest.TestCase):

    def setUp(self) -> None:
        self.bus = MockBus()
        self.system = MockSystem()
        self.watchdog = MockWatchdog(memory=25.0, open_breakers=0, steps_hz=2.0)
        self.chaos = AgentChaosMonkey(self.bus, self.system, self.watchdog)

    def test_measure_local_steady_state_calculation(self) -> None:
        state = self.chaos.measure_local_steady_state()
        # memory_health: 1.0 - 0.25 = 0.75 -> 0.75 * 0.4 = 0.3
        # breaker_health: 1.0 - 0.0 = 1.0 -> 1.0 * 0.4 = 0.4
        # throughput_health: 2.0 / 2.0 = 1.0 -> 1.0 * 0.2 = 0.2
        # total: 0.3 + 0.4 + 0.2 = 0.90
        self.assertAlmostEqual(state, 0.90)

    def test_measure_local_steady_state_handles_exception_fallback(self) -> None:
        class BrokenWatchdog:
            @property
            def status(self) -> dict:
                raise RuntimeError("Force fallback")
        
        self.chaos.watchdog = BrokenWatchdog()
        state_fallback = self.chaos.measure_local_steady_state()
        self.assertEqual(state_fallback, 0.5)

    def test_inject_fault_publishes_event_by_scenario(self) -> None:
        # 1. Process Kill
        exp_id_pk = self.chaos.inject_fault("process_kill")
        self.assertTrue(exp_id_pk.startswith("chaos_process_kill_"))
        self.assertEqual(len(self.bus.published), 1)
        self.assertEqual(self.bus.published[0][0], "orchestrator.module_fault")

        # 2. Latency Spike
        exp_id_ls = self.chaos.inject_fault("latency_spike", intensity=0.8)
        self.assertTrue(exp_id_ls.startswith("chaos_latency_spike_"))
        self.assertEqual(self.bus.published[1][0], "system.adapter_latency_test")
        self.assertAlmostEqual(self.bus.published[1][1]["latency_sec"], 4.0) # 0.8 * 5.0 = 4.0

        # 3. Memory Bloat
        exp_id_mb = self.chaos.inject_fault("memory_bloat", intensity=0.5)
        self.assertTrue(exp_id_mb.startswith("chaos_memory_bloat_"))
        self.assertEqual(self.bus.published[2][0], "growth.spawn_proposed")
        self.assertEqual(self.bus.published[2][1]["custom_params"], 20_000_000) # 0.5 * 40M = 20M

    def test_verify_recovery_success(self) -> None:
        exp_id = self.chaos.inject_fault("latency_spike")
        
        # System is already healthy (0.90 steady state compared to 0.90 initial)
        recovered = self.chaos.verify_recovery(exp_id, max_wait_sec=1.0, poll_interval_sec=0.01)
        self.assertTrue(recovered)
        
        self.assertEqual(len(self.chaos.completed_records), 1)
        record = self.chaos.completed_records[0]
        self.assertTrue(record.recovered)
        self.assertFalse(record.escalated)

    def test_verify_recovery_failure_triggers_escalation(self) -> None:
        exp_id = self.chaos.inject_fault("memory_bloat")
        
        # Simulate system degradation (increase memory to 90% and open 3 breakers)
        # initial state was 0.90
        # degraded state:
        # memory_health: 1.0 - 0.90 = 0.10 -> 0.10 * 0.4 = 0.04
        # breaker_health: 1.0 - 3 * 0.25 = 0.25 -> 0.25 * 0.4 = 0.1
        # throughput_health: 0.5 / 2.0 = 0.25 -> 0.25 * 0.2 = 0.05
        # total degraded: 0.04 + 0.10 + 0.05 = 0.19 (which is << 0.9 * 0.90 = 0.81 threshold)
        self.watchdog.status = {
            "memory_usage_pct": 90.0,
            "open_breakers_count": 3,
            "steps_per_second": 0.5,
        }

        recovered = self.chaos.verify_recovery(exp_id, max_wait_sec=0.2, poll_interval_sec=0.05)
        self.assertFalse(recovered)

        # Confirm escalation published
        self.assertEqual(len(self.chaos.completed_records), 1)
        record = self.chaos.completed_records[0]
        self.assertFalse(record.recovered)
        self.assertTrue(record.escalated)
        self.assertEqual(self.bus.published[-1][0], "healing.escalation")
        self.assertEqual(self.bus.published[-1][1]["experiment_id"], exp_id)
