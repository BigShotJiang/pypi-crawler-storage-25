import unittest
from granary.workspace import (
    WorkspaceBoundarySandbox,
    CredentialSegregationPolicy,
    DockerSandboxIntegration,
    UntrustedToolInterceptor,
)


class TestGranaryWorkspace(unittest.TestCase):

    def test_workspace_boundary_path_translation_and_traversal(self) -> None:
        sandbox = WorkspaceBoundarySandbox(
            workspace_root="/home/shell/living-nn",
            path_alias_table={
                "/home/shell/living-nn": "C:\\Users\\klasi\\Documents\\living-nn"
            }
        )

        # 1. Path translation between Linux and Windows
        win_path = "C:\\Users\\klasi\\Documents\\living-nn\\core\\system.py"
        translated_linux = sandbox.translate_path(win_path, target_os="linux")
        self.assertEqual(translated_linux, "/home/shell/living-nn/core/system.py")

        linux_path = "/home/shell/living-nn/core/system.py"
        translated_win = sandbox.translate_path(linux_path, target_os="windows")
        self.assertEqual(translated_win, "C:\\Users\\klasi\\Documents\\living-nn\\core\\system.py")

        # 2. Workspace boundary check
        self.assertTrue(sandbox.is_within_boundary("/home/shell/living-nn/core/system.py"))
        # Traversal attempt outside boundary -> should return False
        self.assertFalse(sandbox.is_within_boundary("/home/shell/living-nn/../other-project/secret.env"))

    def test_credential_segregation_strips_secrets(self) -> None:
        policy = CredentialSegregationPolicy()
        env = {
            "GFO_SERVER_URL": "https://grandflipout.com/api",
            "RAILWAY_TOKEN": "secret-railway-auth-token-999",
            "SAFE_PUBLIC_CONFIG": "allow",
        }
        clean = policy.filter_env_context(env)
        self.assertEqual(clean["SAFE_PUBLIC_CONFIG"], "allow")
        self.assertEqual(clean["GFO_SERVER_URL"], "MOCK_SEGREGATED_GFO_SERVER_URL_TOKEN")
        self.assertEqual(clean["RAILWAY_TOKEN"], "MOCK_SEGREGATED_RAILWAY_TOKEN_TOKEN")

    def test_docker_sandbox_integration_run_args(self) -> None:
        integration = DockerSandboxIntegration()
        args = integration.build_docker_run_args("alpine:latest", "/home/shell/living-nn", "pytest")
        
        # Verify seccomp and capability drop flags exist
        self.assertIn("--cap-drop", args)
        self.assertIn("CAP_SYS_ADMIN", args)
        self.assertIn("no-new-privileges=true", args[args.index("--security-opt") + 1])
        
        # Verify read-only volume mounts
        self.assertIn("-v", args)
        self.assertIn("/usr/lib:/usr/lib:ro", args)

    def test_untrusted_tool_interceptor_blocks_hook_writes(self) -> None:
        interceptor = UntrustedToolInterceptor()
        
        # Allow normal codebase edits
        self.assertTrue(interceptor.authorize_write("core/system.py"))
        self.assertTrue(interceptor.authorize_write("granary/workspace.py"))

        # Block malicious git hooks injection
        self.assertFalse(interceptor.authorize_write(".git/hooks/pre-commit"))
        self.assertFalse(interceptor.authorize_write(".git/hooks/post-checkout"))
        
        # Block malicious systemd service injection
        self.assertFalse(interceptor.authorize_write("/etc/systemd/system/malicious.service"))
        self.assertFalse(interceptor.authorize_write("~/.config/systemd/user/leak.service"))
