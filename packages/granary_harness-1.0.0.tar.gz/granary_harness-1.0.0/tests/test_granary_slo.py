import unittest
from typing import Dict, List
from granary.slo import AgentSloMonitor


class MockBus:
    def __init__(self) -> None:
        self.published: List[tuple] = []

    def publish(self, channel: str, data: dict) -> None:
        self.published.append((channel, data))


class TestGranarySlo(unittest.TestCase):

    def setUp(self) -> None:
        self.bus = MockBus()
        self.monitor = AgentSloMonitor(self.bus, base_turn_limit=30.0, min_resolve_rate=0.80)

    def test_warmup_phase_skips_evaluation(self) -> None:
        # Fewer than 5 turn durations -> state remains CLOSED, no evaluation
        for i in range(4):
            self.monitor.record_turn_telemetry(duration_sec=40.0, was_successful=False)
        self.assertEqual(self.monitor.escalation_state, "CLOSED")
        self.assertEqual(len(self.bus.published), 0)

    def test_sla_breach_and_degraded_transition(self) -> None:
        # Satisfy warmup
        for _ in range(5):
            self.monitor.record_turn_telemetry(duration_sec=10.0, was_successful=True)
        self.assertEqual(self.monitor.escalation_state, "CLOSED")

        # Record 5 consecutive latencies exceeding 30.0 -> transition to DEGRADED
        for _ in range(5):
            self.monitor.record_turn_telemetry(duration_sec=35.0, was_successful=True)
        self.assertEqual(self.monitor.escalation_state, "DEGRADED")
        self.assertEqual(self.monitor.consecutive_breaches, 1)
        self.assertEqual(self.bus.published[0][0], "slo.escalation_degraded")

    def test_consecutive_breaches_escalate_to_emergency_pause(self) -> None:
        # Record 5 warmups
        for _ in range(5):
            self.monitor.record_turn_telemetry(duration_sec=10.0, was_successful=True)

        # Trigger 1st breach (requires 4 consecutive 40.0 turns to make average > 30.0)
        for _ in range(4):
            self.monitor.record_turn_telemetry(duration_sec=40.0, was_successful=True)
        self.assertEqual(self.monitor.escalation_state, "DEGRADED")
        self.assertEqual(self.monitor.consecutive_breaches, 1)

        # 2nd breach (each new 40.0 turn keeps the average at 40.0 > 30.0)
        self.monitor.record_turn_telemetry(duration_sec=40.0, was_successful=True)
        self.assertEqual(self.monitor.escalation_state, "DEGRADED")
        self.assertEqual(self.monitor.consecutive_breaches, 2)

        # 3rd breach -> EMERGENCY_PAUSE
        self.monitor.record_turn_telemetry(duration_sec=40.0, was_successful=True)
        self.assertEqual(self.monitor.escalation_state, "EMERGENCY_PAUSE")
        self.assertEqual(self.monitor.consecutive_breaches, 3)
        self.assertEqual(self.bus.published[-1][0], "slo.escalation_emergency")

    def test_restoration_to_closed_state(self) -> None:
        # Satisfy warmup
        for _ in range(5):
            self.monitor.record_turn_telemetry(duration_sec=10.0, was_successful=True)

        # Trigger breach -> DEGRADED (requires 4 consecutive 40.0 turns)
        for _ in range(4):
            self.monitor.record_turn_telemetry(duration_sec=40.0, was_successful=True)
        self.assertEqual(self.monitor.escalation_state, "DEGRADED")
        self.assertEqual(self.monitor.consecutive_breaches, 1)

        # Trigger recovery (requires 5 consecutive 15.0 turns to make average <= 30.0)
        for _ in range(5):
            self.monitor.record_turn_telemetry(duration_sec=15.0, was_successful=True)
        self.assertEqual(self.monitor.escalation_state, "CLOSED")
        self.assertEqual(self.monitor.consecutive_breaches, 0)
        self.assertEqual(self.bus.published[-1][0], "slo.restored")
