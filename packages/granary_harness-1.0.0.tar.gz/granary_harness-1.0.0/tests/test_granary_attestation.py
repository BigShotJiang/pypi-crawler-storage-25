import unittest

from granary.attestation import NitroMeasurements, generate_kms_attestation_policy


def _hex_96() -> str:
    return "ab" * 48


class TestGranaryAttestation(unittest.TestCase):

    def test_generate_kms_attestation_policy_contains_required_pcrs(self) -> None:
        measurements = NitroMeasurements(
            image_sha384=_hex_96(),
            pcr0=_hex_96(),
            pcr1=_hex_96(),
            pcr2=_hex_96(),
            pcr3=_hex_96(),
            pcr4=_hex_96(),
        )
        policy = generate_kms_attestation_policy(
            principal_arn="arn:aws:iam::123456789012:role/GranaryAgentHostExecution",
            measurements=measurements,
        )
        condition = policy["Statement"][0]["Condition"]["StringEqualsIgnoreCase"]
        assert condition["kms:RecipientAttestation:PCR0"] == _hex_96()
        assert condition["kms:RecipientAttestation:PCR4"] == _hex_96()

    def test_measurements_reject_non_hex(self) -> None:
        measurements = NitroMeasurements(
            image_sha384="zzzz",
            pcr0=_hex_96(),
            pcr1=_hex_96(),
            pcr2=_hex_96(),
            pcr3=_hex_96(),
            pcr4=_hex_96(),
        )
        with self.assertRaises(ValueError):
            measurements.validate()

