import unittest
import time
from granary.eval_flywheel import (
    EvaluationFlywheel,
    OnlineKpiTracker,
    CounterfactualEvaluator,
    HoldoutGovernance,
)


class TestGranaryEvalFlywheel(unittest.TestCase):

    def test_stage0_integrity_gate(self) -> None:
        flywheel = EvaluationFlywheel()
        
        # Test success under consecutive live days and high match rate
        success = flywheel.evaluate_stage0_integrity(
            outcome_match_rate=0.85,
            consecutive_live_days=8,
            synthetic_trades=10,
            federation_outcome_rate=0.6,
            snapshot_match_rate=0.90
        )
        self.assertTrue(success)

        # Test success under synthetic trades threshold
        success_sync = flywheel.evaluate_stage0_integrity(
            outcome_match_rate=0.50,
            consecutive_live_days=2,
            synthetic_trades=250,
            federation_outcome_rate=0.7,
            snapshot_match_rate=0.88
        )
        self.assertTrue(success_sync)

        # Test failure under low KPIs (snapshot match rate < 85%)
        fail_kpi = flywheel.evaluate_stage0_integrity(
            outcome_match_rate=0.85,
            consecutive_live_days=8,
            synthetic_trades=250,
            federation_outcome_rate=0.6,
            snapshot_match_rate=0.80
        )
        self.assertFalse(fail_kpi)

    def test_holdout_lockbox_rules(self) -> None:
        flywheel = EvaluationFlywheel()
        
        # Item Lockbox: item_id % 10 == 0
        self.assertTrue(flywheel.is_holdout_item(100))
        self.assertTrue(flywheel.is_holdout_item(20))
        self.assertFalse(flywheel.is_holdout_item(43))

        # Time Lockbox: last 20% of calendar window
        start_ts = 1000.0
        duration_days = 10.0
        
        # Day 5 (50% elapsed) -> Not holdout
        mid_ts = start_ts + (5 * 24 * 60 * 60)
        self.assertFalse(flywheel.is_holdout_time_window(mid_ts, duration_days, start_ts))

        # Day 9 (90% elapsed) -> Holdout
        end_ts = start_ts + (9 * 24 * 60 * 60)
        self.assertTrue(flywheel.is_holdout_time_window(end_ts, duration_days, start_ts))

    def test_counterfactual_win_rate_calculations(self) -> None:
        flywheel = EvaluationFlywheel()
        
        shadow = [("bullish", "bullish"), ("bearish", "bullish"), ("neutral", "neutral")]
        baseline = [("bullish", "bearish"), ("bearish", "bullish"), ("neutral", "neutral")]

        shadow_wr, baseline_wr, delta = flywheel.calculate_counterfactual_win_rate(
            shadow_outcomes=shadow,
            baseline_outcomes=baseline
        )
        # shadow wins: 2 of 3 -> 0.6667
        # baseline wins: 1 of 3 -> 0.3333
        self.assertAlmostEqual(shadow_wr, 2/3)
        self.assertAlmostEqual(baseline_wr, 1/3)
        self.assertAlmostEqual(delta, 1/3)

    def test_evaluate_canary_success_and_failures(self) -> None:
        flywheel = EvaluationFlywheel()

        # All gates satisfy successful criteria
        success, reasons = flywheel.evaluate_canary_success(
            canary_resolved=40,
            prod_resolved=300,
            wr_canary=0.75,
            wr_prod=0.70,
            ece_canary=0.08,
            canary_duration_sec=75 * 60 * 60, # 75h
            loss_streak_canary=3,
            p95_lag_sec=4 * 60 * 60 # 4h
        )
        self.assertTrue(success)
        self.assertEqual(len(reasons), 0)

        # Fails on multiple gates: ECE high, short duration, safety streak
        success, reasons = flywheel.evaluate_canary_success(
            canary_resolved=40,
            prod_resolved=300,
            wr_canary=0.75,
            wr_prod=0.70,
            ece_canary=0.15, # fails
            canary_duration_sec=24 * 60 * 60, # fails (24h < 72h)
            loss_streak_canary=6, # fails
            p95_lag_sec=4 * 60 * 60
        )
        self.assertFalse(success)
        self.assertIn("canary_ece_calibration_failure", reasons)
        self.assertIn("insufficient_canary_duration", reasons)
        self.assertIn("canary_loss_streak_safety_violation", reasons)

    def test_evaluate_rollback_trigger(self) -> None:
        flywheel = EvaluationFlywheel()

        # Too few samples (<20) -> Do not trigger rollback
        self.assertFalse(flywheel.evaluate_rollback_trigger(
            win_rate_since_promotion=0.50,
            baseline_win_rate=0.70,
            resolved_count_since_promotion=15
        ))

        # Meets sample size but no significant drop
        self.assertFalse(flywheel.evaluate_rollback_trigger(
            win_rate_since_promotion=0.68,
            baseline_win_rate=0.70,
            resolved_count_since_promotion=25
        ))

        # Meets sample size and has significant drop (> 5pp)
        self.assertTrue(flywheel.evaluate_rollback_trigger(
            win_rate_since_promotion=0.62,
            baseline_win_rate=0.70,
            resolved_count_since_promotion=25
        ))

    def test_online_kpi_tracker(self) -> None:
        tracker = OnlineKpiTracker()
        now = time.time()
        
        # Record outcome matches
        tracker.record_match(now - 100.0, True)
        tracker.record_match(now - 50.0, False)
        self.assertAlmostEqual(tracker.get_outcome_match_rate(), 0.5)

        # Record federation outcomes
        tracker.record_federation_outcome(now - 2.0)
        tracker.record_federation_outcome(now - 1.0)
        self.assertEqual(tracker.get_federation_outcome_rate_per_min(now), 2)

        # Record snapshot match
        tracker.record_snapshot_match(now - 10.0, True)
        tracker.record_snapshot_match(now - 5.0, False)
        self.assertAlmostEqual(tracker.get_snapshot_match_rate(), 0.5)

        # Record synthetic trade and bus error
        tracker.record_synthetic_trade()
        self.assertEqual(tracker.synthetic_trades_count, 1)
        tracker.record_bus_error()
        self.assertEqual(tracker.bus_handler_errors, 1)

    def test_counterfactual_evaluator(self) -> None:
        evaluator = CounterfactualEvaluator()
        now = time.time()

        evaluator.log_shadow(
            trace_id="t1",
            item_id=1,
            shadow_dir="bullish",
            baseline_dir="bearish",
            timestamp=now
        )
        evaluator.log_shadow(
            trace_id="t2",
            item_id=2,
            shadow_dir="bearish",
            baseline_dir="bearish",
            timestamp=now
        )

        # Before matching, win rates are 0.0
        s_wr, b_wr, delta = evaluator.get_counterfactual_metrics()
        self.assertEqual(s_wr, 0.0)
        self.assertEqual(b_wr, 0.0)

        # Match outcome
        self.assertTrue(evaluator.match_outcome("t1", "bullish"))
        self.assertTrue(evaluator.match_outcome("t2", "bullish"))

        # s1: shadow bullish == actual bullish (win)
        # s1: baseline bearish != actual bullish (loss)
        # s2: shadow bearish != actual bullish (loss)
        # s2: baseline bearish != actual bullish (loss)
        # shadow wins: 1 of 2 -> 50%
        # baseline wins: 0 of 2 -> 0%
        s_wr, b_wr, delta = evaluator.get_counterfactual_metrics()
        self.assertAlmostEqual(s_wr, 0.5)
        self.assertAlmostEqual(b_wr, 0.0)
        self.assertAlmostEqual(delta, 0.5)

    def test_holdout_governance(self) -> None:
        flywheel = EvaluationFlywheel()
        gov = HoldoutGovernance(flywheel)

        # OK to train
        gov.assert_safe_to_train(11) # 11 % 10 != 0
        
        # Blocked holdout item training
        with self.assertRaises(ValueError):
            gov.assert_safe_to_train(100) # 100 % 10 == 0

        # OK to tune
        gov.assert_safe_to_tune(timestamp=100.0, total_duration_days=10.0, start_timestamp=0.0)

        # Blocked tuning during holdout time window (last 20%)
        with self.assertRaises(ValueError):
            gov.assert_safe_to_tune(timestamp=900.0 * 24 * 36, total_duration_days=10.0, start_timestamp=0.0)

