import unittest
from granary.shieldnet import ShieldNetClassifier, ShieldNetPolicy


class TestGranaryShieldnet(unittest.TestCase):

    def test_dns_entropy_detection_blocks_suspicious_burst(self) -> None:
        classifier = ShieldNetClassifier(
            ShieldNetPolicy(
                max_dns_entropy_threshold=3.0,
                max_dns_query_rate_per_sec=1,
                window_seconds=2,
            )
        )
        ts = 100.0
        # high entropy subdomain and high burst rate
        for i in range(4):
            verdict = classifier.classify_dns_query(
                session_id="s1",
                domain=f"a8f9z{i}q9xk2m7e.attacker.tld",
                ts=ts + (i * 0.2),
            )
        assert verdict.allowed is False
        assert verdict.action == "freeze-cgroup"

    def test_http_post_blocks_large_non_allowlisted_egress(self) -> None:
        classifier = ShieldNetClassifier(
            ShieldNetPolicy(
                max_post_body_bytes_per_window=100,
                window_seconds=10,
            )
        )
        classifier.classify_http_post(session_id="s2", host="evil.example", body_size_bytes=60, ts=1.0)
        verdict = classifier.classify_http_post(
            session_id="s2", host="evil.example", body_size_bytes=60, ts=1.1
        )
        assert verdict.allowed is False
        assert verdict.action == "terminate-sandbox"

