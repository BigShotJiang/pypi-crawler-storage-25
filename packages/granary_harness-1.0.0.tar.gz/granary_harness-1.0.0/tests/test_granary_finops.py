import unittest
from granary.finops import (
    TokenPricing,
    calculate_saved_cogs,
    TurnState,
    FinOpsController,
)


class TestGranaryFinops(unittest.TestCase):

    def test_calculate_saved_cogs(self) -> None:
        pricing = TokenPricing(input_cost_per_1k=0.01, output_cost_per_1k=0.03)
        metrics = calculate_saved_cogs(
            blocked_events=10,
            avg_prompt_tokens=2000,
            avg_completion_tokens=500,
            pricing=pricing,
        )
        assert metrics["input_tokens_saved"] == 20000
        assert metrics["output_tokens_saved"] == 5000
        assert metrics["saved_cogs_usd"] == 0.35

    def test_finops_controller_prompt_envelope(self) -> None:
        controller = FinOpsController(cost_limit=100.0)
        envelope = controller.build_prompt_envelope(
            methodology="Always buy low",
            system_state={"step": 10},
            ranker_params={"alpha": 0.5},
            user_query="Should I buy whip?"
        )
        self.assertEqual(envelope["schema_version"], "1.0.0")
        self.assertTrue(envelope["prefix_hash"].startswith("sha256:"))
        self.assertEqual(envelope["suffix"]["user_query"], "Should I buy whip?")

    def test_finops_controller_budget_charge_and_transitions(self) -> None:
        controller = FinOpsController(cost_limit=60.0)
        self.assertEqual(controller.turn_state, TurnState.NORMAL)

        # Successful charge
        success = controller.charge("neural", hops=2)
        self.assertTrue(success)
        # Cost: 1 (neural) + 2 * 1 (chain_hop) = 3 -> 60 - 3 = 57 remaining
        self.assertEqual(controller.cost_remaining, 57.0)

        # Charge exceeding budget -> triggers transition to COMPACT
        success_fail = controller.charge("llm", hops=10) # 50 (llm) + 10 = 60 > 57
        self.assertFalse(success_fail)
        self.assertEqual(controller.turn_state, TurnState.COMPACT)
        self.assertEqual(controller.effective_chain_depth(default_depth=3), 1)

    def test_finops_controller_compact_chain_log(self) -> None:
        controller = FinOpsController()
        log = [
            {"module": "ge_trading", "confidence": 0.92, "predictions": {"whip": 0.8}},
            {"module": "stock_market", "confidence": 0.88, "predictions": {"sp": 0.1}},
        ]
        compacted = controller.compact_chain_log(log, max_chars=100)
        self.assertIn("ge_trading", compacted)
        self.assertLessEqual(len(compacted), 100)
