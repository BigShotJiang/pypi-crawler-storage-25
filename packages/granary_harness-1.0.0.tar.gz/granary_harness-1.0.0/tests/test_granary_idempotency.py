import unittest
import time
from granary.idempotency import (
    IdempotencyRegistry,
    OutboxManager,
    ConsumerDeduplicator,
)


class TestGranaryIdempotency(unittest.TestCase):

    def test_idempotency_registry_uniqueness_and_ttl(self) -> None:
        registry = IdempotencyRegistry()
        
        # Register first key
        self.assertTrue(registry.register_key("backup", "test-key-1", ttl_seconds=1))
        
        # Duplicate should fail while unexpired
        self.assertFalse(registry.register_key("backup", "test-key-1", ttl_seconds=1))
        
        # Wait for TTL to expire
        time.sleep(1.1)
        
        # Now registering duplicate should succeed
        self.assertTrue(registry.register_key("backup", "test-key-1", ttl_seconds=1))

    def test_outbox_processing_and_retries(self) -> None:
        manager = OutboxManager()
        payload = {"cmd": "restart-service", "target": "living-nn"}
        
        entry = manager.add_event("SERVICE_RESTART_USER", payload, max_retries=2)
        self.assertEqual(entry.status, "pending")
        self.assertEqual(entry.retry_count, 0)

        # Successful processing
        executed_actions = []
        def successful_processor(action, p):
            executed_actions.append((action, p))

        success = manager.process_event(entry.event_id, successful_processor)
        self.assertTrue(success)
        self.assertEqual(entry.status, "processed")
        self.assertEqual(entry.retry_count, 1)
        self.assertEqual(executed_actions, [("SERVICE_RESTART_USER", payload)])

    def test_outbox_exhausts_retries_and_fails(self) -> None:
        manager = OutboxManager()
        payload = {"cmd": "failing-command"}
        entry = manager.add_event("FAILING_ACTION", payload, max_retries=2)

        def failing_processor(action, p):
            raise RuntimeError("Simulation failure")

        # First attempt (fails but not marked failed yet since max_retries=2)
        success = manager.process_event(entry.event_id, failing_processor)
        self.assertFalse(success)
        self.assertEqual(entry.status, "pending")
        self.assertEqual(entry.retry_count, 1)

        # Second attempt (exhausted retries -> transitions to failed)
        success = manager.process_event(entry.event_id, failing_processor)
        self.assertFalse(success)
        self.assertEqual(entry.status, "failed")
        self.assertEqual(entry.retry_count, 2)

    def test_consumer_deduplication_and_poison_detection(self) -> None:
        deduplicator = ConsumerDeduplicator(retention_window_seconds=1)
        
        msg_id = "msg-12345"
        self.assertTrue(deduplicator.should_process(msg_id))
        
        deduplicator.mark_processed(msg_id)
        # Duplicate check should block it now
        self.assertFalse(deduplicator.should_process(msg_id))
        
        # Test expiration
        time.sleep(1.1)
        self.assertTrue(deduplicator.should_process(msg_id))

        # Test poison message tracking
        poison_msg_id = "poison-999"
        self.assertFalse(deduplicator.is_poison(poison_msg_id))
        
        # Trigger 3 failures
        self.assertFalse(deduplicator.track_failure(poison_msg_id))
        self.assertFalse(deduplicator.track_failure(poison_msg_id))
        self.assertTrue(deduplicator.track_failure(poison_msg_id)) # 3rd failure makes it poison
        self.assertTrue(deduplicator.is_poison(poison_msg_id))
