import unittest
import time
from granary.conformance import (
    ConformanceScore,
    ProviderTier,
    ConformanceManager,
)


class TestGranaryConformance(unittest.TestCase):

    def setUp(self) -> None:
        self.manager = ConformanceManager()

    def test_run_automated_conformance_battery_success(self) -> None:
        tool_calling = {
            "tool_calls": [
                {"name": "read_file", "arguments": {"path": "/tmp/a"}}
            ]
        }
        structured_output = {
            "result": {"status": "success", "data": [1, 2]}
        }
        streaming_chunks = [
            {"event": "start", "seq": 1},
            {"event": "chunk", "seq": 2},
            {"event": "done", "seq": 3},
        ]
        schema_arguments = {
            "strict": True,
            "parameters": {"type": "object"}
        }

        score = self.manager.run_automated_conformance_battery(
            tool_calling_output=tool_calling,
            structured_json_output=structured_output,
            streaming_chunks=streaming_chunks,
            schema_arguments=schema_arguments
        )
        self.assertTrue(score.tool_calling_passed)
        self.assertTrue(score.structured_output_passed)
        self.assertTrue(score.streaming_order_passed)
        self.assertTrue(score.strict_mode_passed)
        self.assertTrue(score.is_fully_conforming())

    def test_conformance_battery_handles_individual_failures(self) -> None:
        # Invalid stream order (seq not monotonic)
        bad_chunks = [
            {"event": "start", "seq": 2},
            {"event": "chunk", "seq": 1}, # decrease
            {"event": "done", "seq": 3},
        ]
        score = self.manager.run_automated_conformance_battery(
            tool_calling_output={"tool_calls": []}, # fails tool call
            structured_json_output={"result": {}},
            streaming_chunks=bad_chunks,
            schema_arguments={"strict": False}
        )
        self.assertFalse(score.is_fully_conforming())
        self.assertFalse(score.streaming_order_passed)
        self.assertFalse(score.tool_calling_passed)

    def test_register_provider_tiering_assignment(self) -> None:
        # 1. Full conformance -> verified
        score_verified = ConformanceScore(True, True, True, True)
        record_verified = self.manager.register_provider(
            provider_name="ollama",
            model_name="llama3.1",
            version="1.0.0",
            score=score_verified
        )
        self.assertEqual(record_verified.tier, ProviderTier.VERIFIED)

        # 2. Partial conformance -> limited
        score_limited = ConformanceScore(True, False, False, False)
        record_limited = self.manager.register_provider(
            provider_name="local_mock",
            model_name="tiny-phi",
            version="0.5.0",
            score=score_limited
        )
        self.assertEqual(record_limited.tier, ProviderTier.LIMITED)

        # 3. No conformance -> experimental
        score_experimental = ConformanceScore(False, False, False, False)
        record_experimental = self.manager.register_provider(
            provider_name="unstable_cloud",
            model_name="mystery-v1",
            version="12.0",
            score=score_experimental
        )
        self.assertEqual(record_experimental.tier, ProviderTier.EXPERIMENTAL)

    def test_trigger_recertification_resets_tier_and_scores(self) -> None:
        score = ConformanceScore(True, True, True, True)
        self.manager.register_provider(
            provider_name="aws_bedrock",
            model_name="claude-3-5",
            version="v2",
            score=score
        )
        
        # Trigger recertification
        record = self.manager.trigger_recertification(
            provider_name="aws_bedrock",
            model_name="claude-3-5",
            reason="model_version_drift_alert"
        )
        self.assertIsNotNone(record)
        self.assertEqual(record.tier, ProviderTier.EXPERIMENTAL)
        self.assertFalse(record.score.is_fully_conforming())
        self.assertEqual(record.drift_alerts_count, 1)
