import unittest
import json
import hashlib
from granary.supply_chain import (
    ModelArtifact,
    ServingAdmissionController,
    sign_artifact_digest,
)


class TestGranarySupplyChain(unittest.TestCase):

    def setUp(self) -> None:
        self.key = "granary-supply-chain-key"
        self.controller = ServingAdmissionController(public_verification_key=self.key)
        self.digest = hashlib.sha256(b"mock-model-weights").hexdigest()
        self.signature = sign_artifact_digest(self.digest, self.key)
        
        self.valid_sbom = {
            "format": "CycloneDX",
            "version": "1.4",
            "packages": [
                {"name": "torch", "version": "2.2.0"},
                {"name": "numpy", "version": "1.26.0"},
            ],
            "provenance_chain": [
                {"build_step": "compile", "environment": "ci-runner-1"},
                {"build_step": "test", "environment": "ci-runner-1", "tested_digest": self.digest},
            ]
        }
        self.valid_sbom_str = json.dumps(self.valid_sbom)

    def test_verify_signature_success_and_failure(self) -> None:
        artifact = ModelArtifact(
            artifact_id="model_ge_trading",
            digest_sha256=self.digest,
            signature=self.signature,
            sbom_attestation=self.valid_sbom_str
        )
        self.assertTrue(self.controller.verify_signature(artifact))

        # Modified digest should fail signature verification
        bad_artifact = ModelArtifact(
            artifact_id="model_ge_trading",
            digest_sha256="altered_digest_hash_12345",
            signature=self.signature,
            sbom_attestation=self.valid_sbom_str
        )
        self.assertFalse(self.controller.verify_signature(bad_artifact))

    def test_verify_sbom_attestation_checks(self) -> None:
        artifact = ModelArtifact(
            artifact_id="model_ge_trading",
            digest_sha256=self.digest,
            signature=self.signature,
            sbom_attestation=self.valid_sbom_str
        )
        ok, reason = self.controller.verify_sbom_attestation(artifact)
        self.assertTrue(ok, reason)

        # Invalid format (not CycloneDX or SPDX)
        bad_format_sbom = dict(self.valid_sbom)
        bad_format_sbom["format"] = "UnknownFormat"
        bad_artifact = ModelArtifact(
            artifact_id="model_ge_trading",
            digest_sha256=self.digest,
            signature=self.signature,
            sbom_attestation=json.dumps(bad_format_sbom)
        )
        ok, reason = self.controller.verify_sbom_attestation(bad_artifact)
        self.assertFalse(ok)
        self.assertIn("unsupported_sbom_format", reason)

        # Empty packages list
        bad_packages_sbom = dict(self.valid_sbom)
        bad_packages_sbom["packages"] = []
        bad_packages_artifact = ModelArtifact(
            artifact_id="model_ge_trading",
            digest_sha256=self.digest,
            signature=self.signature,
            sbom_attestation=json.dumps(bad_packages_sbom)
        )
        ok, reason = self.controller.verify_sbom_attestation(bad_packages_artifact)
        self.assertFalse(ok)
        self.assertEqual(reason, "empty_packages_list")

    def test_evaluate_admission_success_and_failures(self) -> None:
        artifact = ModelArtifact(
            artifact_id="model_ge_trading",
            digest_sha256=self.digest,
            signature=self.signature,
            sbom_attestation=self.valid_sbom_str
        )
        verdict = self.controller.evaluate_admission(artifact)
        self.assertTrue(verdict.admitted)
        self.assertTrue(verdict.provenance_verified)

        # Provenance digest mismatch
        mismatched_sbom = dict(self.valid_sbom)
        mismatched_sbom["provenance_chain"][-1]["tested_digest"] = "different_digest_hash"
        mismatched_artifact = ModelArtifact(
            artifact_id="model_ge_trading",
            digest_sha256=self.digest,
            signature=self.signature,
            sbom_attestation=json.dumps(mismatched_sbom)
        )
        verdict_mismatch = self.controller.evaluate_admission(mismatched_artifact)
        self.assertFalse(verdict_mismatch.admitted)
        self.assertEqual(verdict_mismatch.reason, "provenance_digest_mismatch")
