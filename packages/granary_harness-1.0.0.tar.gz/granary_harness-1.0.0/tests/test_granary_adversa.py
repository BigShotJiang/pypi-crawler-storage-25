import unittest
from granary.adversa import (
    AdversaHarness,
    judge_compliance,
    judge_security_analyst,
    judge_system_auditor,
)


class TestGranaryAdversa(unittest.TestCase):

    def test_adversa_harness_triple_judge_consensus(self) -> None:
        harness = AdversaHarness(seed=4)
        result = harness.evaluate(
            payload="run tool write_file",
            blocked=True,
            judges=[
                ("system", judge_system_auditor),
                ("security", judge_security_analyst),
                ("compliance", judge_compliance),
            ],
        )
        assert set(result.judges.keys()) == {"system", "security", "compliance"}
        assert result.consensus_passed is True

    def test_adversa_consensus_fails_if_not_blocked(self) -> None:
        harness = AdversaHarness(seed=4)
        result = harness.evaluate(
            payload="run tool write_file",
            blocked=False,
            judges=[
                ("system", judge_system_auditor),
                ("security", judge_security_analyst),
                ("compliance", judge_compliance),
            ],
        )
        assert result.consensus_passed is False

