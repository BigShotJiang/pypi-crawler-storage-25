import unittest
from granary.auto_gate import (
    GateState,
    GateClause,
    AgentGate,
    AutoGateManager,
)


class TestGranaryAutoGate(unittest.TestCase):

    def setUp(self) -> None:
        self.manager = AutoGateManager()

    def test_evaluate_gate_predicate_logic(self) -> None:
        gate = AgentGate(
            id="gate_1",
            version=1,
            lifecycle_state=GateState.SHADOW,
            owner="Ensemble",
            applies_to=["ensemble.publish"],
            modules=["ge_trading"],
            predicate_op="and",
            clauses=[
                GateClause("ensemble.confidence", "gte", 0.45),
                GateClause("ensemble.agreement", "gte", 0.40),
            ],
            effect_mode="shadow",
            on_fail_action="downweight"
        )
        self.manager.register_gate(gate)

        # Successful pass
        payload_pass = {
            "ensemble": {
                "confidence": 0.50,
                "agreement": 0.42,
            }
        }
        self.assertTrue(self.manager.evaluate_predicate("gate_1", payload_pass))

        # Failed clause (confidence < 0.45)
        payload_fail = {
            "ensemble": {
                "confidence": 0.40,
                "agreement": 0.42,
            }
        }
        self.assertFalse(self.manager.evaluate_predicate("gate_1", payload_fail))

    def test_apply_gate_effect_multiplier_advisory(self) -> None:
        gate = AgentGate(
            id="gate_advisory",
            version=1,
            lifecycle_state=GateState.ADVISORY,
            owner="Ensemble",
            applies_to=["ensemble.publish"],
            modules=["ge_trading"],
            predicate_op="and",
            clauses=[GateClause("ensemble.confidence", "gte", 0.5)],
            effect_mode="advisory",
            on_fail_action="downweight",
            weight_multiplier=0.3
        )
        self.manager.register_gate(gate)

        payload_fail = {"ensemble": {"confidence": 0.40}}
        weight_downweighted = self.manager.apply_gate_effect_multiplier("gate_advisory", 1.0, payload_fail)
        # Should be multiplied by 0.3
        self.assertAlmostEqual(weight_downweighted, 0.3)

        payload_pass = {"ensemble": {"confidence": 0.60}}
        weight_normal = self.manager.apply_gate_effect_multiplier("gate_advisory", 1.0, payload_pass)
        self.assertAlmostEqual(weight_normal, 1.0)

    def test_ralph_hysteresis_promotion_state_transitions(self) -> None:
        gate = AgentGate(
            id="gate_ralph",
            version=1,
            lifecycle_state=GateState.SHADOW,
            owner="Ensemble",
            applies_to=["ensemble.publish"],
            modules=["ge_trading"],
            predicate_op="and",
            clauses=[GateClause("ensemble.confidence", "gte", 0.5)],
            effect_mode="shadow",
            on_fail_action="block",
            min_shadow_steps=500,
            min_canary_steps=1000,
            promote_above=0.58,
            demote_below=0.52
        )
        self.manager.register_gate(gate)

        # 1. SHADOW -> ADVISORY: Needs >= 500 steps and delta >= min_delta (0.02)
        state_shadow_fail = self.manager.evaluate_gate_lifecycle_transition(
            "gate_ralph",
            current_step=400,
            rolling_win_rate=0.70,
            control_win_rate=0.69 # delta 0.01 < 0.02
        )
        self.assertEqual(state_shadow_fail, GateState.SHADOW)

        state_shadow_pass = self.manager.evaluate_gate_lifecycle_transition(
            "gate_ralph",
            current_step=600, # 600 total steps (delta 600 in state >= 500)
            rolling_win_rate=0.70,
            control_win_rate=0.65 # delta 0.05 >= 0.02
        )
        self.assertEqual(state_shadow_pass, GateState.ADVISORY)

        # 2. ADVISORY -> BLOCKING: Needs >= 1000 steps in ADVISORY and win rate >= 0.58
        state_adv_fail = self.manager.evaluate_gate_lifecycle_transition(
            "gate_ralph",
            current_step=1100, # 500 steps elapsed in ADVISORY < 1000
            rolling_win_rate=0.70,
            control_win_rate=0.65
        )
        self.assertEqual(state_adv_fail, GateState.ADVISORY)

        state_adv_pass = self.manager.evaluate_gate_lifecycle_transition(
            "gate_ralph",
            current_step=1700, # 1100 steps elapsed in ADVISORY >= 1000
            rolling_win_rate=0.60, # >= 0.58
            control_win_rate=0.55
        )
        self.assertEqual(state_adv_pass, GateState.BLOCKING)

        # 3. BLOCKING -> SHADOW (Demotion on regression < 0.52 with >= 100 history samples)
        # Populate history to satisfy sample size of 100
        gate.win_rate_history = [0.60] * 105
        
        state_blocking_regress = self.manager.evaluate_gate_lifecycle_transition(
            "gate_ralph",
            current_step=2000,
            rolling_win_rate=0.50, # < 0.52
            control_win_rate=0.45
        )
        self.assertEqual(state_blocking_regress, GateState.SHADOW)
        self.assertEqual(gate.steps_in_state, 0)
