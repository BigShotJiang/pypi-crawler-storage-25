import json
import time
import unittest
import uuid

from granary.mcp_gateway_server import (
    approve_mcp_pending,
    authorize_mcp_tool,
    list_pending_approvals,
    reset_gateway,
    validate_oauth_redirect,
)
from granary.mcp_security import RiskTier


class TestGranaryMcpGatewayServer(unittest.TestCase):

    def setUp(self) -> None:
        reset_gateway()

    def tearDown(self) -> None:
        reset_gateway()

    def test_authorize_via_server_helpers(self) -> None:
        claims = {
            "scope": "file:read",
            "exp": time.time() + 300,
            "jti": str(uuid.uuid4()),
        }
        verdict = authorize_mcp_tool(
            principal="cursor_agent",
            tool_name="mcp_filesystem_read",
            claims_json=json.dumps(claims),
            principal_allow=[RiskTier.T0, RiskTier.T1],
        )
        self.assertTrue(verdict["allowed"])

    def test_validate_redirect_via_server_helpers(self) -> None:
        result = validate_oauth_redirect("http://127.0.0.1:5000/oauth/callback")
        self.assertTrue(result["allowed"])
        bad = validate_oauth_redirect("https://evil.example/callback")
        self.assertFalse(bad["allowed"])

    def test_pending_flow_via_server_helpers(self) -> None:
        jti = str(uuid.uuid4())
        claims = {
            "scope": "gfo:export",
            "exp": time.time() + 300,
            "jti": jti,
        }
        verdict = authorize_mcp_tool(
            principal="living_nn_service",
            tool_name="mcp_gfo_federation_export",
            claims_json=json.dumps(claims),
            principal_allow=[RiskTier.T0, RiskTier.T1, RiskTier.T2],
        )
        self.assertEqual(verdict["reason"], "approval_required")
        pending = list_pending_approvals()
        self.assertEqual(pending["count"], 1)
        approved = approve_mcp_pending(verdict["pending_id"], "admin")
        self.assertTrue(approved["approved"])
        self.assertEqual(list_pending_approvals()["count"], 0)
