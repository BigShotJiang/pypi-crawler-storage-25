import unittest
from granary.continuity import (
    FallbackLevel,
    XMHSnapshot,
    CapabilityGapMatrix,
    ContinuityFallbackLadder,
    CapabilityNegotiationProtocol,
    DeterminismCheckingHarness,
    calculate_resume_determinism_kpis,
)


class TestGranaryContinuity(unittest.TestCase):

    def test_continuity_fallback_ladder_progression(self) -> None:
        ladder = ContinuityFallbackLadder()
        self.assertEqual(ladder.current_level, FallbackLevel.L0_HOT_CONTINUE)

        # Escalate up the ladder
        self.assertEqual(ladder.escalate_fallback(), FallbackLevel.L1_CONTINUATION_MANIFEST)
        self.assertEqual(ladder.escalate_fallback(), FallbackLevel.L2_MANIFEST_LIVING_PATCH)
        self.assertEqual(ladder.escalate_fallback(), FallbackLevel.L3_CROSS_MODEL_HANDOFF)
        self.assertEqual(ladder.escalate_fallback(), FallbackLevel.L4_TRANSCRIPT_COMPRESSION)
        self.assertEqual(ladder.escalate_fallback(), FallbackLevel.L5_HUMAN_GATED_RESTART)
        
        # Stays at max L5
        self.assertEqual(ladder.escalate_fallback(), FallbackLevel.L5_HUMAN_GATED_RESTART)

        # Reset
        ladder.reset_fallback()
        self.assertEqual(ladder.current_level, FallbackLevel.L0_HOT_CONTINUE)

    def test_capability_negotiation_detects_and_maps_gaps(self) -> None:
        protocol = CapabilityNegotiationProtocol()
        sender_req = {"strict_json_schema", "parallel_tool_calls", "standard_text_inference"}
        receiver_cap = {"standard_text_inference", "parallel_tool_calls"} # Missing strict_json_schema

        matrix = protocol.negotiate_capabilities(sender_req, receiver_cap)
        self.assertEqual(matrix.supported_capabilities, {"standard_text_inference", "parallel_tool_calls"})
        self.assertEqual(matrix.missing_capabilities, {"strict_json_schema"})
        
        # Verify degraded runbook created
        self.assertIn("strict_json_schema", matrix.degraded_runbooks)
        self.assertIn("pydantic", matrix.degraded_runbooks["strict_json_schema"])

    def test_determinism_checking_harness_drift_detection(self) -> None:
        expected = [
            ("read_file", {"path": "/tmp/a"}),
            ("grep", {"pattern": "abc"}),
        ]
        harness = DeterminismCheckingHarness(expected)

        # 1. Aligned first call
        ok, msg = harness.record_actual_tool_call("read_file", {"path": "/tmp/a"})
        self.assertTrue(ok, msg)
        self.assertEqual(msg, "aligned")

        # 2. Mismatched argument on second call
        ok_drift, msg_drift = harness.record_actual_tool_call("grep", {"pattern": "different_pattern"})
        self.assertFalse(ok_drift)
        self.assertIn("argument mismatch", msg_drift)

    def test_calculate_resume_determinism_and_rework_kpis(self) -> None:
        expected = [
            ("read_file", {"path": "/tmp/a"}),
            ("grep", {"pattern": "abc"}),
        ]
        harness = DeterminismCheckingHarness(expected)
        
        # Record aligned calls
        harness.record_actual_tool_call("read_file", {"path": "/tmp/a"})
        harness.record_actual_tool_call("grep", {"pattern": "abc"})

        kpis = calculate_resume_determinism_kpis(harness, rework_count=2, total_steps=10)
        
        # 2 of 2 expected calls aligned -> determinism = 1.0
        self.assertEqual(kpis["resume_determinism_score"], 1.0)
        # rework_loss = 2 / 10 = 0.20
        self.assertEqual(kpis["rework_loss_ratio"], 0.20)
