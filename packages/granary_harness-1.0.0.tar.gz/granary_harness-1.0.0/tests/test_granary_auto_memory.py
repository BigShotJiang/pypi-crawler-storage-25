import unittest
import time
from granary.auto_memory import (
    MemoryTier,
    MemorySource,
    MemoryRecord,
    AutoMemoryManager,
)


class TestGranaryAutoMemory(unittest.TestCase):

    def test_create_candidate_memory_and_merge_duplicates(self) -> None:
        manager = AutoMemoryManager()
        
        src1 = MemorySource(source_type="explicit_correction", weight=1.0, actor="user")
        m1 = manager.create_candidate_from_cue(
            domain="ge_trading",
            topics=["hold_time"],
            text="Prefer hold_time > 300s",
            sources=[src1]
        )
        self.assertEqual(m1.tier, MemoryTier.CANDIDATE)
        self.assertEqual(m1.content_text, "Prefer hold_time > 300s")

        # Ingest identical/duplicate memory -> should merge
        src2 = MemorySource(source_type="outcome_feedback", weight=0.8, item_name="Torva")
        m2 = manager.create_candidate_from_cue(
            domain="ge_trading",
            topics=["hold_time"],
            text="Prefer hold_time > 300s", # exact match text
            sources=[src2]
        )
        self.assertEqual(m2.tier, MemoryTier.RETIRED) # duplicate retired
        self.assertEqual(len(m1.sources), 2) # sources merged into m1
        self.assertEqual(m1.version, 2)

    def test_promotion_score_ema_updates(self) -> None:
        manager = AutoMemoryManager()
        src = MemorySource(source_type="explicit_correction", weight=1.0)
        m = manager.create_candidate_from_cue(
            domain="ge_trading",
            topics=["margin"],
            text="Check margin boundaries",
            sources=[src]
        )
        self.assertAlmostEqual(m.promotion_score, 0.0)

        # Update with positive signal
        manager.update_promotion_score(m.id, signal_value=0.60, alpha=0.10)
        # 0.1 * 0.60 + 0.9 * 0.0 = 0.06
        self.assertAlmostEqual(m.promotion_score, 0.06)

        # Update with negative contradiction signal
        manager.update_promotion_score(m.id, signal_value=-0.50, alpha=0.10)
        # 0.1 * -0.50 + 0.9 * 0.06 = -0.05 + 0.054 = 0.004
        self.assertAlmostEqual(m.promotion_score, 0.004)

    def test_poison_risk_calculation_and_quarantine(self) -> None:
        manager = AutoMemoryManager()
        src = MemorySource(source_type="explicit_correction", weight=1.0)
        m = manager.create_candidate_from_cue(
            domain="ge_trading",
            topics=["margin"],
            text="Check margin boundaries",
            sources=[src],
            structured_data={"min_hold_time_sec": -50} # invalid hold_time (H_invalid = 1.0)
        )
        
        # We have single source weight > 60% -> S_dom = 1.0
        # Ingestion rate of 1 < 5 -> A_rate = 0.0
        # Contradiction count = 0 -> C_count = 0.0
        # min_hold_time_sec is negative -> H_invalid = 1.0
        # unmatched ratio = 0.80 -> U_ratio = 1.0
        # Risk = 0.35 * 1.0 + 0.25 * 0.0 + 0.30 * 0.0 + 0.40 * 1.0 + 0.15 * 1.0 = 0.35 + 0.40 + 0.15 = 0.90
        risk = manager.calculate_poison_risk(m.id, unmatched_ratio=0.80)
        self.assertAlmostEqual(risk, 0.90)
        # Risk exceeds 0.70 -> automatically transitions to QUARANTINED
        self.assertEqual(m.tier, MemoryTier.QUARANTINED)

    def test_lifecycle_tick_transitions(self) -> None:
        manager = AutoMemoryManager(ttl_seconds=10)
        src1 = MemorySource(source_type="explicit_correction", weight=1.0)
        m = manager.create_candidate_from_cue(
            domain="ge_trading",
            topics=["margin"],
            text="Check margin boundaries",
            sources=[src1]
        )
        m.trust_score = 0.50

        # Ticking now should not transition candidate (score too low)
        actions = manager.process_lifecycle_ticks(now=time.time())
        self.assertEqual(len(actions), 0)
        self.assertEqual(m.tier, MemoryTier.CANDIDATE)

        # 1. Candidate -> Probation
        m.promotion_score = 0.40
        actions = manager.process_lifecycle_ticks(now=time.time())
        self.assertEqual(len(actions), 1)
        self.assertEqual(actions[0], (m.id, "moved_to_probation"))
        self.assertEqual(m.tier, MemoryTier.PROBATION)

        # 2. Probation -> Active
        # Needs quorum of unique source types (quorum_required = 2)
        # Add another unique source type
        m.sources.append(MemorySource(source_type="outcome_feedback", weight=0.8))
        m.promotion_score = 0.60
        m.holdout_pass_rate = 0.65
        actions_active = manager.process_lifecycle_ticks(now=time.time())
        self.assertEqual(len(actions_active), 1)
        self.assertEqual(actions_active[0], (m.id, "promoted_to_active"))
        self.assertEqual(m.tier, MemoryTier.ACTIVE)

        # 3. Active -> Crystallized
        m.sustained_steps = 350
        m.sustained_accuracy = 0.75
        actions_cryst = manager.process_lifecycle_ticks(now=time.time())
        self.assertEqual(len(actions_cryst), 1)
        self.assertEqual(actions_cryst[0], (m.id, "crystallized_ewc_locked"))
        self.assertEqual(m.tier, MemoryTier.CRYSTALLIZED)
