import unittest
import time
from granary.contamination import (
    LedgerRow,
    ContaminationAwareEvaluator,
)


class TestGranaryContamination(unittest.TestCase):

    def test_contaminated_source_matching(self) -> None:
        evaluator = ContaminationAwareEvaluator()
        
        self.assertTrue(evaluator.is_contaminated_source("seed"))
        self.assertTrue(evaluator.is_contaminated_source("seed_123"))
        self.assertTrue(evaluator.is_contaminated_source("TEST"))
        self.assertTrue(evaluator.is_contaminated_source("demo-arm-a"))
        self.assertTrue(evaluator.is_contaminated_source("synthetic-run"))
        
        self.assertFalse(evaluator.is_contaminated_source("production"))
        self.assertFalse(evaluator.is_contaminated_source("ge_trading"))
        self.assertFalse(evaluator.is_contaminated_source("stock_market"))

    def test_detect_leakage_overlap(self) -> None:
        evaluator = ContaminationAwareEvaluator()
        
        train = {"item_1", "item_2", "item_3"}
        test_no_leak = {"item_4", "item_5"}
        test_leak = {"item_3", "item_4", "item_5"} # item_3 is leaked

        self.assertAlmostEqual(evaluator.detect_leakage(train, test_no_leak), 0.0)
        self.assertAlmostEqual(evaluator.detect_leakage(train, test_leak), 1/3)

    def test_generate_stratified_report(self) -> None:
        evaluator = ContaminationAwareEvaluator()
        
        rows = [
            # High-volume stratum
            LedgerRow("r1", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": True}),
            LedgerRow("r2", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": True}),
            LedgerRow("r3", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": False}),
            # Low-volume stratum
            LedgerRow("r4", "production", "pol_1", "scan_1", time.time(), {"grade": "low", "is_correct": False}),
            LedgerRow("r5", "production", "pol_1", "scan_1", time.time(), {"grade": "low", "is_correct": True}),
            # Skipped contaminated/test row
            LedgerRow("r6", "seed_run", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": True}),
        ]
        
        report = evaluator.generate_stratified_report(rows, "grade")
        
        # 'high' has 3 valid rows (2 wins, 1 loss) -> accuracy = 2/3 = 0.6667
        self.assertEqual(report["high"]["n"], 3)
        self.assertAlmostEqual(report["high"]["accuracy"], 0.6667)
        
        # 'low' has 2 valid rows (1 win, 1 loss) -> accuracy = 0.50
        self.assertEqual(report["low"]["n"], 2)
        self.assertAlmostEqual(report["low"]["accuracy"], 0.50)

    def test_check_promotion_blocker_triggers(self) -> None:
        evaluator = ContaminationAwareEvaluator()
        
        train = {"item_1", "item_2"}
        test_clean = {"item_3", "item_4"}
        test_leaked = {"item_2", "item_3", "item_4"} # item_2 matches train

        # Build rows where stratum 'high' has 5 samples and win rate 0.40
        # Stratum 'low' has 2 samples (n < 5, will be skipped)
        rows = [
            LedgerRow("r1", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": True}),
            LedgerRow("r2", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": True}),
            LedgerRow("r3", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": False}),
            LedgerRow("r4", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": False}),
            LedgerRow("r5", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": False}), # 2 wins, 3 losses -> wr = 0.40
            LedgerRow("r6", "production", "pol_1", "scan_1", time.time(), {"grade": "low", "is_correct": False}),
        ]

        # 1. Blocked by leakage
        allowed, blockers = evaluator.check_promotion_blocker(
            train_set=train,
            eval_set=test_leaked,
            rows=rows,
            global_accuracy=0.60,
            stratum_key="grade",
            leakage_limit=0.01,
            underperformance_limit_pp=0.10
        )
        self.assertFalse(allowed)
        self.assertTrue(any("leakage_limit_exceeded" in b for b in blockers))

        # 2. Blocked by stratum underperformance (grade 'high' is 0.40, which is < global_accuracy 0.60 - 0.10 = 0.50)
        allowed_perf, blockers_perf = evaluator.check_promotion_blocker(
            train_set=train,
            eval_set=test_clean,
            rows=rows,
            global_accuracy=0.60,
            stratum_key="grade",
            leakage_limit=0.10,
            underperformance_limit_pp=0.10
        )
        self.assertFalse(allowed_perf)
        self.assertTrue(any("stratum_underperformance_violation" in b for b in blockers_perf))

        # 3. Clean promotion
        allowed_clean, blockers_clean = evaluator.check_promotion_blocker(
            train_set=train,
            eval_set=test_clean,
            rows=rows,
            global_accuracy=0.45, # global is 0.45, stratum is 0.40. Threshold is 0.45 - 0.10 = 0.35. Stratum 0.40 >= 0.35, so NOT blocked!
            stratum_key="grade",
            leakage_limit=0.10,
            underperformance_limit_pp=0.10
        )
        self.assertTrue(allowed_clean)
        self.assertEqual(len(blockers_clean), 0)

    def test_detect_sequence_leakage(self) -> None:
        evaluator = ContaminationAwareEvaluator()
        
        train = [(10, 1000.0), (20, 2000.0)]
        test_no_leak = [(30, 3000.0), (40, 4000.0)]
        test_leak = [(20, 2000.0), (30, 3000.0)] # (20, 2000.0) is leaked

        self.assertAlmostEqual(evaluator.detect_sequence_leakage(train, test_no_leak), 0.0)
        self.assertAlmostEqual(evaluator.detect_sequence_leakage(train, test_leak), 0.5)

    def test_generate_contamination_report(self) -> None:
        evaluator = ContaminationAwareEvaluator()
        
        train = {"item_1", "item_2"}
        test_clean = {"item_3", "item_4"}
        rows = [
            LedgerRow("r1", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": True}),
            LedgerRow("r2", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": True}),
            LedgerRow("r3", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": False}),
            LedgerRow("r4", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": False}),
            LedgerRow("r5", "production", "pol_1", "scan_1", time.time(), {"grade": "high", "is_correct": False}),
        ]

        report = evaluator.generate_contamination_report(
            train_set=train,
            eval_set=test_clean,
            rows=rows,
            global_accuracy=0.45,
            stratum_key="grade"
        )
        
        self.assertEqual(report["status"], "CLEAN")
        self.assertEqual(report["metrics"]["total_eval_samples"], 2)
        self.assertEqual(report["metrics"]["total_train_samples"], 2)
        self.assertEqual(report["metrics"]["leakage_ratio"], 0.0)
        self.assertEqual(len(report["blockers"]), 0)
        self.assertIn("high", report["strata_analysis"])

