import unittest
from granary.coherence import (
    SubsystemState,
    IntelligenceUpgradeStage,
    CoherenceWorkUnit,
    CoherenceContractManager,
)


class TestGranaryCoherence(unittest.TestCase):

    def setUp(self) -> None:
        self.manager = CoherenceContractManager()

    def test_work_unit_registration_and_initial_state(self) -> None:
        unit = self.manager.register_work_unit("wu_12345")
        self.assertEqual(unit.work_unit_id, "wu_12345")
        self.assertEqual(unit.subsystem_state, SubsystemState.INIT)
        self.assertEqual(unit.active_upgrade_stage, IntelligenceUpgradeStage.OUTCOME_CLOSED)

    def test_sequential_state_transitions(self) -> None:
        self.manager.register_work_unit("wu_1")

        # 1. First transition -> GOVERNANCE_PASSED (Success)
        success, msg = self.manager.advance_subsystem_state("wu_1", SubsystemState.GOVERNANCE_PASSED)
        self.assertTrue(success)
        self.assertEqual(msg, "state_advanced")

        # 2. Out of order transition -> EVALUATION_VERIFIED (Fail)
        success, msg = self.manager.advance_subsystem_state("wu_1", SubsystemState.EVALUATION_VERIFIED)
        self.assertFalse(success)
        self.assertIn("invalid_state_transition_sequence", msg)

    def test_rollout_gate_verification(self) -> None:
        self.manager.register_work_unit("wu_2")
        
        # Advance sequentially up to MEMORY_STORED
        self.manager.advance_subsystem_state("wu_2", SubsystemState.GOVERNANCE_PASSED)
        self.manager.advance_subsystem_state("wu_2", SubsystemState.ORCHESTRATION_READY)
        self.manager.advance_subsystem_state("wu_2", SubsystemState.MEMORY_STORED)

        # Attempt ROLLOUT_COMMITTED directly from MEMORY_STORED (Fail - missing EVALUATION_VERIFIED)
        success, msg = self.manager.advance_subsystem_state(
            "wu_2", SubsystemState.ROLLOUT_COMMITTED, evidence="tested_release_sha"
        )
        self.assertFalse(success)
        self.assertEqual(msg, f"invalid_state_transition_sequence: expected next is {SubsystemState.EVALUATION_VERIFIED}")

        # Advance to EVALUATION_VERIFIED
        self.manager.advance_subsystem_state("wu_2", SubsystemState.EVALUATION_VERIFIED)

        # Attempt rollout without evidence reference (Fail)
        success_no_ev, msg_no_ev = self.manager.advance_subsystem_state(
            "wu_2", SubsystemState.ROLLOUT_COMMITTED, evidence=None
        )
        self.assertFalse(success_no_ev)
        self.assertEqual(msg_no_ev, "rollout_blocked: missing_conformance_evidence")

        # Rollout with evidence (Success)
        success_rollout, msg_rollout = self.manager.advance_subsystem_state(
            "wu_2", SubsystemState.ROLLOUT_COMMITTED, evidence="verified_canary_hash_12345"
        )
        self.assertTrue(success_rollout)
        self.assertEqual(msg_rollout, "state_advanced")

    def test_failure_boundary_containment(self) -> None:
        unit = self.manager.register_work_unit("wu_3")
        self.assertEqual(len(unit.circuit_breakers_tripped), 0)

        self.manager.contain_failure_boundary("wu_3", "ge_trading_circuit_breaker")
        self.assertEqual(len(unit.circuit_breakers_tripped), 1)
        self.assertIn("ge_trading_circuit_breaker", unit.circuit_breakers_tripped)

    def test_intelligence_critical_path_validation(self) -> None:
        self.manager.register_work_unit("wu_4")
        
        # 1. Valid next stage: 1 -> 2 (Success)
        success, msg = self.manager.validate_intelligence_upgrade(
            "wu_4", IntelligenceUpgradeStage.CALIBRATED_ROUTING
        )
        self.assertTrue(success)

        # 2. Invalid stage jump: 2 -> 4 (Fail)
        success_jump, msg_jump = self.manager.validate_intelligence_upgrade(
            "wu_4", IntelligenceUpgradeStage.CRITIC_VALIDATOR_SPLIT
        )
        self.assertFalse(success_jump)
        self.assertIn("critical_path_violation", msg_jump)

        # 3. Valid stage progression: 2 -> 3 (Success)
        success_next, msg_next = self.manager.validate_intelligence_upgrade(
            "wu_4", IntelligenceUpgradeStage.TYPED_DECOMPOSITION
        )
        self.assertTrue(success_next)
