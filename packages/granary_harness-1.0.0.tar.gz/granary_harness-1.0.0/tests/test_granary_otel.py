import unittest
from granary.otel import (
    TraceContext,
    extract_trace_context,
    inject_trace_context,
    AgentSpanAttributes,
    OTelRedactionProcessor,
)


class TestGranaryOtel(unittest.TestCase):

    def test_inject_trace_context_under_meta(self) -> None:
        params = {"name": "write_file", "arguments": {"path": "/tmp/a"}}
        ctx = TraceContext(
            traceparent="00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
            tracestate="granary_agent=planner",
            baggage="task_id=task_1",
        )
        enriched = inject_trace_context(params, ctx)
        assert enriched["_meta"]["traceparent"] == ctx.traceparent
        assert enriched["_meta"]["tracestate"] == ctx.tracestate
        assert enriched["_meta"]["baggage"] == ctx.baggage

    def test_extract_trace_context_round_trip(self) -> None:
        ctx = extract_trace_context(
            {
                "traceparent": "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
                "tracestate": "granary_agent=planner",
            }
        )
        assert ctx.traceparent.startswith("00-")
        assert ctx.tracestate == "granary_agent=planner"

    def test_otel_span_attributes_exist(self) -> None:
        self.assertEqual(AgentSpanAttributes.MCP_TOOL_NAME, "mcp.tool.name")
        self.assertEqual(AgentSpanAttributes.SESSION_ID, "session.id")

    def test_otel_redaction_processor_masks_secrets(self) -> None:
        processor = OTelRedactionProcessor()
        attrs = {
            "mcp.tool.name": "read_file",
            "db.password": "unmasked-raw-pass",
            "authorization": "Bearer eyJhbGciOi...",
            "git.token": "ghp_securetoken"
        }
        redacted = processor.redact_attributes(attrs)
        self.assertEqual(redacted["mcp.tool.name"], "read_file")
        self.assertEqual(redacted["db.password"], "[REDACTED]")
        self.assertEqual(redacted["authorization"], "[REDACTED]")
        self.assertEqual(redacted["git.token"], "[REDACTED]")


