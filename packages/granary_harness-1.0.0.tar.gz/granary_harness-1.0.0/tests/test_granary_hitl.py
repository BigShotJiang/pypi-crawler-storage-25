import unittest
import time
from granary.hitl import HITLManager, HITLRequest


class TestGranaryHITL(unittest.TestCase):

    def test_submit_request_and_resolution(self) -> None:
        manager = HITLManager()
        chk = {"workspace_state_hash": "sha256:abc12345", "git_head": "main"}
        
        req = manager.submit_request(
            work_unit_id="wu_92e8a10f",
            action_id="GIT_PUSH",
            payload="git push origin main",
            risk_tier="T4",
            escalation_path=["slack://#emergency-alerts"],
            checkpoint_data=chk
        )
        self.assertEqual(req.status, "pending")
        self.assertEqual(req.timeout_seconds, 86400) # T4 default
        
        # Approve the request
        success = manager.resolve_request(
            req.approval_id,
            decision="approved",
            approver_id="user:max",
            rationale="Approved for production hotfix"
        )
        self.assertTrue(success)
        self.assertEqual(req.status, "approved")
        self.assertEqual(req.approver_id, "user:max")
        self.assertEqual(req.decision_rationale, "Approved for production hotfix")

        # Verify deterministic resume checkpoint retrieval
        checkpoint = manager.get_resume_checkpoint(req.approval_id)
        self.assertEqual(checkpoint, chk)

    def test_timeout_auto_rejection_for_t4(self) -> None:
        manager = HITLManager()
        req = manager.submit_request(
            work_unit_id="wu_123",
            action_id="GIT_PUSH",
            payload="git push origin main",
            risk_tier="T4",
            escalation_path=["slack://#emergency-alerts"],
            timeout_seconds=10
        )
        
        # Advance clock manually to trigger timeout
        now = time.time() + 15
        expired = manager.check_and_apply_timeouts(now=now)
        self.assertEqual(len(expired), 1)
        self.assertEqual(expired[0], (req.approval_id, "auto_rejected_t4"))
        self.assertEqual(req.status, "rejected")
        self.assertIn("T4 high-risk action", req.decision_rationale)

    def test_timeout_escalation_ladder_for_t3(self) -> None:
        manager = HITLManager()
        req = manager.submit_request(
            work_unit_id="wu_456",
            action_id="FEDERATION_TUNING",
            payload="adjust trade metrics",
            risk_tier="T3",
            escalation_path=["slack://#emergency-alerts", "email://ciso@acme.com"],
            timeout_seconds=5
        )
        
        now = time.time() + 10
        expired = manager.check_and_apply_timeouts(now=now)
        self.assertEqual(len(expired), 1)
        self.assertEqual(expired[0], (req.approval_id, "escalated_to_slack://#emergency-alerts"))
        self.assertEqual(req.status, "escalated")
        self.assertIn("slack://#emergency-alerts", req.decision_rationale)
