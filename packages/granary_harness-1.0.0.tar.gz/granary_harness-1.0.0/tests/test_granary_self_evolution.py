import unittest
from typing import Dict, List, Optional
from granary.self_evolution import (
    EvolutionPolicy,
    bounded_routing_update,
    bounded_combo_reward,
    take_evolution_snapshot,
    rollback_evolution,
    detect_prediction_drift,
    anti_gaming_quality_signal,
    EvolutionSnapshot,
)


class MockVersion:
    def __init__(self, version_id: str) -> None:
        self.version_id = version_id


class MockVersionManager:
    def __init__(self, best_id: Optional[str] = "v_best") -> None:
        self.best_id = best_id
        self.restored_to: Optional[str] = None

    def get_best_version(self) -> Optional[MockVersion]:
        if self.best_id:
            return MockVersion(self.best_id)
        return None

    def restore_version(self, version_id: str) -> bool:
        self.restored_to = version_id
        return True


class MockModule:
    def __init__(self, has_vm: bool = True, best_version_id: Optional[str] = "v_best") -> None:
        if has_vm:
            self._version_manager = MockVersionManager(best_version_id)


class MockHyperparams:
    def __init__(self, system_lr_multiplier: float = 1.0) -> None:
        self._system_lr_multiplier = system_lr_multiplier


class MockOrchestrator:
    def __init__(self) -> None:
        self._modules: Dict[str, MockModule] = {}
        self._combo_quality: Dict[str, List[float]] = {}
        self._module_quality: Dict[str, List[float]] = {}


class TestGranarySelfEvolution(unittest.TestCase):

    def test_evolution_policy_defaults(self) -> None:
        policy = EvolutionPolicy()
        self.assertEqual(policy.max_score_delta_per_step, 0.05)
        self.assertEqual(policy.max_combo_weight_delta, 0.08)
        self.assertEqual(policy.min_samples_before_update, 20)

    def test_bounded_routing_update_clamping(self) -> None:
        scores = {"ge_trading": 0.8, "stock_market": 1.2}
        proposed_deltas = {"ge_trading": 0.1, "stock_market": -0.2}
        
        updated = bounded_routing_update(scores, proposed_deltas, max_delta=0.05)
        # delta clamped to 0.05 (for ge_trading) -> 0.8 + 0.05 = 0.85
        self.assertAlmostEqual(updated["ge_trading"], 0.85)
        # delta clamped to -0.05 (for stock_market) -> 1.2 - 0.05 = 1.15
        self.assertAlmostEqual(updated["stock_market"], 1.15)

    def test_bounded_combo_reward_history_clamping(self) -> None:
        history = {"seq_a": [0.5, 0.6]}
        bounded_combo_reward("seq_a", 0.9, history, max_window=3, max_single_jump=0.1)
        # Last was 0.6. 0.9 exceeds jump of 0.1, so clamped to 0.7
        self.assertEqual(history["seq_a"], [0.5, 0.6, 0.7])

        # Test window pruning
        bounded_combo_reward("seq_a", 0.75, history, max_window=3, max_single_jump=0.1)
        self.assertEqual(len(history["seq_a"]), 3)
        self.assertEqual(history["seq_a"], [0.6, 0.7, 0.75])

    def test_take_snapshot_and_rollback_evolution(self) -> None:
        orch = MockOrchestrator()
        orch._modules["ge_trading"] = MockModule(has_vm=True, best_version_id="v_123")
        orch._combo_quality["seq_a"] = [0.6, 0.8]
        orch._module_quality["ge_trading"] = [0.9]

        hp = MockHyperparams(system_lr_multiplier=1.0)

        snapshot = take_evolution_snapshot(orch, hp, "ge_trading", step=100)
        self.assertEqual(snapshot.step, 100)
        self.assertEqual(snapshot.checkpoint_version_id, "v_123")
        self.assertEqual(snapshot.combo_quality_means["seq_a"], 0.7)
        self.assertEqual(snapshot.system_lr_multiplier, 1.0)

        # Modify values to simulate experimental run
        orch._combo_quality["seq_a"] = [0.3]
        orch._module_quality["ge_trading"] = [0.2]
        hp._system_lr_multiplier = 0.5

        # Rollback
        mod = orch._modules["ge_trading"]
        success = rollback_evolution(snapshot, orch, hp, mod)
        self.assertTrue(success)
        self.assertEqual(hp._system_lr_multiplier, 1.0)
        self.assertEqual(orch._combo_quality["seq_a"], [0.7])
        self.assertEqual(orch._module_quality["ge_trading"], [0.9])
        self.assertEqual(mod._version_manager.restored_to, "v_123")

    def test_detect_prediction_drift(self) -> None:
        pred_a = {"entry_signal": 0.9, "exit_signal": 0.2}
        pred_b = {"entry_signal": 0.1, "exit_signal": 0.2} # entry_signal disagrees (dirs: 1 vs -1), exit agrees (dirs: -1 vs -1)
        
        res = detect_prediction_drift(pred_a, pred_b, {"entry_signal", "exit_signal"}, severity_threshold=0.2)
        # agree count = 1, total keys = 2 -> agreement = 0.5, severity = 0.5
        self.assertIsNotNone(res)
        self.assertAlmostEqual(res["severity"], 0.5)
        self.assertAlmostEqual(res["agreement"], 0.5)

        # Below threshold
        res_below = detect_prediction_drift(pred_a, pred_b, {"entry_signal", "exit_signal"}, severity_threshold=0.6)
        self.assertIsNone(res_below)

    def test_anti_gaming_quality_signal(self) -> None:
        # Fewer than min samples -> discount self-reported quality by 0.7
        val = anti_gaming_quality_signal(self_reported_quality=0.9, outcome_ema=0.8, outcome_samples=10, min_outcome_samples=30)
        self.assertAlmostEqual(val, 0.63)

        # Mismatch exceeds max discrepancy (0.25) -> trust outcome_ema directly
        val_disc = anti_gaming_quality_signal(self_reported_quality=0.9, outcome_ema=0.5, outcome_samples=40, min_outcome_samples=30, max_discrepancy=0.25)
        self.assertEqual(val_disc, 0.5)

        # Discrepancy within limits -> blend: 0.6 * outcome_ema + 0.4 * self_reported_quality
        val_blend = anti_gaming_quality_signal(self_reported_quality=0.9, outcome_ema=0.8, outcome_samples=40, min_outcome_samples=30, max_discrepancy=0.25)
        # 0.6 * 0.8 + 0.4 * 0.9 = 0.48 + 0.36 = 0.84
        self.assertAlmostEqual(val_blend, 0.84)
