import unittest
import time
from granary.roles import RoleRegistry, AgentRole, RoleMetrics


class TestGranaryRoles(unittest.TestCase):

    def test_registry_enforces_sprawl_caps(self) -> None:
        registry = RoleRegistry(max_roles_limit=2)
        
        r1 = registry.register_role("ge_trading", "price_prediction", ["FS_READ"], "T1")
        r2 = registry.register_role("ge_trading", "volume_analysis", ["FS_READ"], "T1")
        self.assertIsNotNone(r1)
        self.assertIsNotNone(r2)

        # 3rd role registration must fail due to sprawl caps
        r3 = registry.register_role("ge_trading", "margin_check", ["FS_READ"], "T1")
        self.assertIsNone(r3)

    def test_role_lifecycle_state_transitions(self) -> None:
        registry = RoleRegistry()
        role = registry.register_role("stock_market", "candlestick_scanner", ["FS_READ"], "T1")
        self.assertEqual(role.lifecycle_state, "SHADOW")

        # Invalid transition directly to ACTIVE
        success = registry.transition_state("stock_market", "candlestick_scanner", "ACTIVE")
        self.assertFalse(success)
        self.assertEqual(role.lifecycle_state, "SHADOW")

        # Valid transition to CANDIDATE
        success = registry.transition_state("stock_market", "candlestick_scanner", "CANDIDATE")
        self.assertTrue(success)
        self.assertEqual(role.lifecycle_state, "CANDIDATE")

        # Valid transition to ACTIVE
        success = registry.transition_state("stock_market", "candlestick_scanner", "ACTIVE")
        self.assertTrue(success)
        self.assertEqual(role.lifecycle_state, "ACTIVE")

    def test_promotion_gates(self) -> None:
        registry = RoleRegistry()
        role = registry.register_role("stock_market", "trend_analyzer", ["FS_READ"], "T1", initial_state="CANDIDATE")
        
        # Fails because total samples < 30
        role.metrics.success_count = 10
        role.metrics.failure_count = 5
        role.metrics.accuracy_score = 0.85
        success = registry.evaluate_promotion_gate("stock_market", "trend_analyzer")
        self.assertFalse(success)

        # Fails because accuracy_score < 0.70
        role.metrics.success_count = 25
        role.metrics.failure_count = 10 # 35 total
        role.metrics.accuracy_score = 0.65
        success = registry.evaluate_promotion_gate("stock_market", "trend_analyzer")
        self.assertFalse(success)

        # Success with 30+ samples and high accuracy
        role.metrics.success_count = 28
        role.metrics.failure_count = 4 # 32 total
        role.metrics.accuracy_score = 0.88
        success = registry.evaluate_promotion_gate("stock_market", "trend_analyzer")
        self.assertTrue(success)
        self.assertEqual(role.lifecycle_state, "ACTIVE")

    def test_demotion_gates(self) -> None:
        registry = RoleRegistry()
        role = registry.register_role("stock_market", "trend_analyzer", ["FS_READ"], "T1", initial_state="ACTIVE")

        # No demotion if failures < 3
        role.metrics.consecutive_failures = 2
        verdict = registry.evaluate_demotion_or_retirement("stock_market", "trend_analyzer")
        self.assertIsNone(verdict)

        # Demote to DEGRADED on 3 consecutive failures
        role.metrics.consecutive_failures = 3
        verdict = registry.evaluate_demotion_or_retirement("stock_market", "trend_analyzer")
        self.assertEqual(verdict, "DEGRADED")
        self.assertEqual(role.lifecycle_state, "DEGRADED")

        # Expire and RETIRE degraded role if idle for > 30 days
        role.last_used_at = time.time() - (35 * 24 * 60 * 60)
        verdict = registry.evaluate_demotion_or_retirement("stock_market", "trend_analyzer")
        self.assertEqual(verdict, "RETIRED")
        self.assertEqual(role.lifecycle_state, "RETIRED")

    def test_anti_sprawl_merge_policy(self) -> None:
        registry = RoleRegistry()
        r_target = registry.register_role("ge_trading", "margin_t1", ["FS_READ"], "T1", initial_state="ACTIVE")
        r_source = registry.register_role("ge_trading", "margin_t3", ["API_READ_LOCAL", "GIT_PUSH"], "T3", initial_state="SHADOW")

        success = registry.merge_sprawl_roles("ge_trading", "margin_t1", "margin_t3")
        self.assertTrue(success)
        
        # Permissions should be merged
        self.assertEqual(set(r_target.tool_allowlist), {"FS_READ", "API_READ_LOCAL", "GIT_PUSH"})
        self.assertEqual(r_target.max_autonomy_tier, "T3") # Promoted to highest max tier
        self.assertEqual(r_source.lifecycle_state, "RETIRED")

    def test_hotspot_weighted_discovery_algorithm(self) -> None:
        registry = RoleRegistry()
        heat = registry.discover_role_hotspots(
            routing_misses=10,
            breaker_faults=5,
            curiosity_events=3,
            outcome_gaps=12.5
        )
        # Heat = (10 * 0.4) + (5 * 0.3) + (3 * 0.1) + (12.5 * 0.2) = 4 + 1.5 + 0.3 + 2.5 = 8.3
        self.assertEqual(heat, 8.3)
