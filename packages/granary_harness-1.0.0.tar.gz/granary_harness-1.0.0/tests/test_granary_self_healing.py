import unittest
from typing import Dict, List, Optional
from granary.self_healing import (
    FailureClass,
    FailureEvent,
    validate_failure_event,
    SelfHealingEngine,
    HealingState,
    replay_safe_process_outcome,
)


class MockHyperparams:
    def __init__(self, system_lr_multiplier: float = 1.0) -> None:
        self._system_lr_multiplier = system_lr_multiplier


class MockModule:
    def __init__(self, ewc_lambda: float = 10.0) -> None:
        self.ewc_lambda = ewc_lambda
        self.optimizer_reset_called = False
        self.calibration_reset_called = False
        self.calibration_tracker = self

    def _reset_optimizer(self) -> None:
        self.optimizer_reset_called = True

    def reset(self) -> None:
        self.calibration_reset_called = True


class MockOrchestrator:
    def __init__(self) -> None:
        self.sleep_homeostasis_requested = False

    def request_sleep_homeostasis(self) -> None:
        self.sleep_homeostasis_requested = True


class MockBus:
    def __init__(self) -> None:
        self.published: List[tuple] = []

    def publish(self, channel: str, data: dict) -> None:
        self.published.append((channel, data))


class MockLearner:
    def __init__(self) -> None:
        self._step = 42
        self._unmatched_outcomes = 0
        self.bus = MockBus()
        self.recorded_outcomes: List[dict] = []
        self.fed_outcomes: List[dict] = []

    def _normalize_hold_time(self, hold_time_sec: float) -> Optional[float]:
        if 0 <= hold_time_sec <= 2592000:
            return hold_time_sec
        return None

    def _match_to_predictions(self, buy_time: float, item_id: int) -> dict:
        if item_id == 999: # simulate unmatched
            return {}
        return {"module": "ge_trading", "direction": "bullish"}

    def _record_module_outcomes(self, outcome_payload: dict, matched: dict) -> None:
        self.recorded_outcomes.append((outcome_payload, matched))

    def _feed_outcome_to_modules(self, outcome_payload: dict, matched: dict) -> None:
        self.fed_outcomes.append((outcome_payload, matched))


class TestGranarySelfHealing(unittest.TestCase):

    def test_validate_failure_event_valid_and_invalid(self) -> None:
        evt = FailureEvent(
            failure_id="f_1",
            failure_class=FailureClass.MODEL,
            subtype="loss_diverge",
            module="ge_trading",
            step=100,
            recoverable=True,
            error="Validation loss spiked",
            trace_id="t_1"
        )
        validate_failure_event(evt.to_dict()) # should not raise error

        # Invalid trace_id type
        bad_evt = evt.to_dict()
        bad_evt["trace_id"] = 1234
        with self.assertRaises(TypeError):
            validate_failure_event(bad_evt)

    def test_self_healing_fast_path_remedies(self) -> None:
        engine = SelfHealingEngine()
        orch = MockOrchestrator()
        hp = MockHyperparams(system_lr_multiplier=1.0)
        mod = MockModule(ewc_lambda=10.0)

        # 1. Test error_flood reset
        evt_flood = FailureEvent(
            failure_id="f_1",
            failure_class=FailureClass.STATE,
            subtype="error_flood",
            module="ge_trading",
            step=100,
            recoverable=True
        )
        remedy = engine.handle_failure(evt_flood, orch, hp, mod)
        self.assertEqual(remedy, "error_flood_reset")
        self.assertEqual(hp._system_lr_multiplier, 0.5)
        self.assertEqual(mod.ewc_lambda, 15.0)
        self.assertEqual(engine.state, HealingState.HEALTHY)

        # 2. Test loss_diverge reset
        evt_loss = FailureEvent(
            failure_id="f_2",
            failure_class=FailureClass.MODEL,
            subtype="loss_diverge",
            module="ge_trading",
            step=101,
            recoverable=True
        )
        remedy = engine.handle_failure(evt_loss, orch, hp, mod)
        self.assertEqual(remedy, "optimizer_reset")
        self.assertTrue(mod.optimizer_reset_called)

        # 3. Test stale_data reset
        evt_stale = FailureEvent(
            failure_id="f_3",
            failure_class=FailureClass.CONTEXT,
            subtype="stale_data",
            module="ge_trading",
            step=102,
            recoverable=True
        )
        remedy = engine.handle_failure(evt_stale, orch, hp, mod)
        self.assertEqual(remedy, "sleep_homeostasis_request")
        self.assertTrue(orch.sleep_homeostasis_requested)

    def test_self_healing_slow_path_escalation(self) -> None:
        engine = SelfHealingEngine()
        orch = MockOrchestrator()
        hp = MockHyperparams(system_lr_multiplier=1.0)
        mod = MockModule()

        evt_unrecoverable = FailureEvent(
            failure_id="f_4",
            failure_class=FailureClass.STATE,
            subtype="chain_total_failure",
            module="ge_trading",
            step=103,
            recoverable=False # triggers slow-path escalation
        )
        remedy = engine.handle_failure(evt_unrecoverable, orch, hp, mod)
        self.assertEqual(remedy, "slow_path_paused_consolidation")
        self.assertEqual(engine.state, HealingState.PAUSED)

    def test_replay_safe_process_outcome(self) -> None:
        learner = MockLearner()
        seen_ids = set()

        outcome_payload = {
            "trade_id": "trade_99",
            "item_id": 1,
            "buy_price": 100,
            "sell_price": 150,
            "profit": 50,
            "hold_time_sec": 3600,
            "timestamp": 1234567.8,
        }

        # 1. Process successfully
        processed = replay_safe_process_outcome(learner, outcome_payload, seen_ids=seen_ids)
        self.assertTrue(processed)
        self.assertIn("trade_99", seen_ids)
        self.assertEqual(len(learner.bus.published), 1)
        self.assertEqual(learner.bus.published[0][0], "outcome.processed")

        # 2. Block duplicates
        processed_dup = replay_safe_process_outcome(learner, outcome_payload, seen_ids=seen_ids)
        self.assertFalse(processed_dup)

        # 3. Handle unmatched outcome (simulate item_id=999)
        outcome_unmatched = {
            "trade_id": "trade_100",
            "item_id": 999,
            "buy_price": 100,
            "sell_price": 150,
            "profit": 50,
            "hold_time_sec": 3600,
            "timestamp": 1234567.8,
        }
        processed_unmatched = replay_safe_process_outcome(learner, outcome_unmatched, seen_ids=seen_ids)
        self.assertFalse(processed_unmatched)
        self.assertEqual(learner._unmatched_outcomes, 1)
        self.assertEqual(learner.bus.published[1][0], "outcome.unmatched")
