import unittest
import time
import uuid
from granary.mcp_security import McpTrustGateway, RiskTier


class TestGranaryMcpSecurity(unittest.TestCase):

    def setUp(self) -> None:
        self.action_tiers = {
            "mcp_filesystem_read": RiskTier.T0,
            "mcp_filesystem_write": RiskTier.T1,
            "mcp_gfo_federation_export": RiskTier.T2,
            "mcp_git_push": RiskTier.T3,
        }
        self.action_scopes = {
            "mcp_filesystem_read": ["file:read"],
            "mcp_filesystem_write": ["file:write"],
            "mcp_gfo_federation_export": ["gfo:export"],
            "mcp_git_push": ["git:write"],
        }
        self.allowed_redirects = {
            "http://127.0.0.1:5000/oauth/callback",
            "cursor://anysphere.cursor-mcp/oauth/callback",
            "https://auth.grandflipout.com/callback",
        }
        self.gateway = McpTrustGateway(
            action_tiers=self.action_tiers,
            action_scopes=self.action_scopes,
            allowed_redirect_uris=self.allowed_redirects
        )

    def test_validate_redirect_uri(self) -> None:
        # Allowed and valid
        self.assertTrue(self.gateway.validate_redirect_uri("http://127.0.0.1:5000/oauth/callback"))
        self.assertTrue(self.gateway.validate_redirect_uri("https://auth.grandflipout.com/callback"))

        # Unallowed URI
        self.assertFalse(self.gateway.validate_redirect_uri("https://evil-unallowed.com/callback"))

        # Invalid private IP (not loopback 127.0.0.1)
        self.assertFalse(self.gateway.validate_redirect_uri("http://192.168.1.50/callback"))

    def test_authorize_tool_success_and_errors(self) -> None:
        # 1. Normal auto-allowed tool run (T0)
        claims = {
            "iss": "https://auth.cursor.com",
            "aud": "living-nn-mcp-gateway",
            "sub": "user_123",
            "scope": "file:read",
            "exp": time.time() + 300,
            "jti": str(uuid.uuid4()),
        }
        verdict = self.gateway.authorize_tool(
            principal="cursor_agent",
            tool_name="mcp_filesystem_read",
            claims=claims,
            principal_allow=[RiskTier.T0, RiskTier.T1]
        )
        self.assertTrue(verdict["allowed"])
        self.assertEqual(verdict["reason"], "auto_allowed")

        # 2. Token expired error
        expired_claims = dict(claims)
        expired_claims["exp"] = time.time() - 10
        expired_claims["jti"] = str(uuid.uuid4())
        verdict_expired = self.gateway.authorize_tool(
            principal="cursor_agent",
            tool_name="mcp_filesystem_read",
            claims=expired_claims,
            principal_allow=[RiskTier.T0, RiskTier.T1]
        )
        self.assertFalse(verdict_expired["allowed"])
        self.assertEqual(verdict_expired["reason"], "token_expired")

        # 3. Insufficient scope error
        bad_scope_claims = dict(claims)
        bad_scope_claims["scope"] = "file:other"
        bad_scope_claims["jti"] = str(uuid.uuid4())
        verdict_scope = self.gateway.authorize_tool(
            principal="cursor_agent",
            tool_name="mcp_filesystem_read",
            claims=bad_scope_claims,
            principal_allow=[RiskTier.T0, RiskTier.T1]
        )
        self.assertFalse(verdict_scope["allowed"])
        self.assertEqual(verdict_scope["reason"], "insufficient_scope")

        # 4. JTI Replay attack error
        replay_claims = dict(claims)
        # Reuse same JTI used in step 1
        verdict_replay = self.gateway.authorize_tool(
            principal="cursor_agent",
            tool_name="mcp_filesystem_read",
            claims=replay_claims,
            principal_allow=[RiskTier.T0, RiskTier.T1]
        )
        self.assertFalse(verdict_replay["allowed"])
        self.assertEqual(verdict_replay["reason"], "jti_replay")

    def test_authorize_tool_requires_human_approval(self) -> None:
        jti = str(uuid.uuid4())
        claims = {
            "iss": "https://auth.cursor.com",
            "aud": "living-nn-mcp-gateway",
            "sub": "user_123",
            "scope": "gfo:export",
            "exp": time.time() + 300,
            "jti": jti,
        }
        # T2 external action -> requires human approval
        verdict = self.gateway.authorize_tool(
            principal="living_nn_service",
            tool_name="mcp_gfo_federation_export",
            claims=claims,
            principal_allow=[RiskTier.T0, RiskTier.T1, RiskTier.T2]
        )
        self.assertFalse(verdict["allowed"])
        self.assertEqual(verdict["reason"], "approval_required")
        self.assertIn("pending_id", verdict)

        # Approve the pending action
        success = self.gateway.approve_pending(verdict["pending_id"], "admin_user")
        self.assertTrue(success)

        # Attempt to replay approved JTI should be blocked
        verdict_replay = self.gateway.authorize_tool(
            principal="living_nn_service",
            tool_name="mcp_gfo_federation_export",
            claims=claims,
            principal_allow=[RiskTier.T0, RiskTier.T1, RiskTier.T2]
        )
        self.assertFalse(verdict_replay["allowed"])
        self.assertEqual(verdict_replay["reason"], "jti_replay")
