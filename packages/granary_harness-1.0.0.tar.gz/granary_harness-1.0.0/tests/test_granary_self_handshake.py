import unittest
import time
from granary.self_handshake import (
    ContextState,
    ContinuationManifest,
    SelfHandshakeValidator,
    ContextBudgetManager,
    ProbationMonitor,
)


class TestGranarySelfHandshake(unittest.TestCase):

    def test_context_budget_hysteresis_triggers(self) -> None:
        manager = ContextBudgetManager(limit_tokens=1000)
        
        # 1. 250 tokens -> Green
        state, trigger = manager.update_state(250)
        self.assertEqual(state, ContextState.GREEN)
        self.assertFalse(trigger)

        # 2. 600 tokens -> Yellow
        state, trigger = manager.update_state(600)
        self.assertEqual(state, ContextState.YELLOW)
        self.assertFalse(trigger)

        # 3. 800 tokens -> Orange, triggers manifest pre-generation
        state, trigger = manager.update_state(800)
        self.assertEqual(state, ContextState.ORANGE)
        self.assertTrue(trigger) # changed from yellow to orange

        # 4. 850 tokens -> Orange, trigger is False (already in Orange)
        state, trigger = manager.update_state(850)
        self.assertEqual(state, ContextState.ORANGE)
        self.assertFalse(trigger)

        # 5. 950 tokens -> Red, triggers immediate rollover
        state, trigger = manager.update_state(950)
        self.assertEqual(state, ContextState.RED)
        self.assertTrue(trigger)

    def test_self_handshake_validator_parity_checks(self) -> None:
        validator = SelfHandshakeValidator(
            current_workspace="/home/shell/living-nn",
            current_branch="main",
            current_commit="abc12345ef"
        )
        
        manifest = ContinuationManifest(
            manifest_id="manifest_1",
            original_session_id="sess_1",
            workspace_path="/home/shell/living-nn",
            git_branch="main",
            git_commit="abc12345ef",
            last_applied_index=10,
            resume_state={"app_mode": "strict"},
            next_actions=["PROC_TEST"]
        )

        ok, errors = validator.validate_parity(manifest)
        self.assertTrue(ok)
        self.assertEqual(len(errors), 0)

        # Mismatched commit hash
        bad_manifest = ContinuationManifest(
            manifest_id="manifest_1",
            original_session_id="sess_1",
            workspace_path="/home/shell/living-nn",
            git_branch="main",
            git_commit="wrong-different-commit",
            last_applied_index=10,
            resume_state={"app_mode": "strict"},
            next_actions=["PROC_TEST"]
        )
        ok, errors = validator.validate_parity(bad_manifest)
        self.assertFalse(ok)
        self.assertEqual(len(errors), 1)
        self.assertIn("git_commit_mismatch", errors[0])

    def test_probation_monitor_rollback_triggers(self) -> None:
        monitor = ProbationMonitor(probation_window_steps=10)

        # Record 2 reworks out of first 4 steps
        self.assertFalse(monitor.record_step(is_rework=True, edit_churn_pct=10.0, tool_call=("read_file", {"path": "/tmp/0"})))
        self.assertFalse(monitor.record_step(is_rework=True, edit_churn_pct=10.0, tool_call=("read_file", {"path": "/tmp/1"})))
        self.assertFalse(monitor.record_step(is_rework=False, edit_churn_pct=10.0, tool_call=("read_file", {"path": "/tmp/2"})))
        self.assertFalse(monitor.record_step(is_rework=False, edit_churn_pct=10.0, tool_call=("read_file", {"path": "/tmp/3"})))

        # 5th step is NOT a rework -> total reworks is 2/5 = 40% (still OK, needs > 40%)
        rollback = monitor.record_step(
            is_rework=False,
            edit_churn_pct=10.0,
            tool_call=("read_file", {"path": "/tmp/4"})
        )
        self.assertFalse(rollback)

        # 6th step is a rework -> total reworks is 3/6 = 50% > 40% -> triggers rollback!
        rollback = monitor.record_step(
            is_rework=True,
            edit_churn_pct=10.0,
            tool_call=("read_file", {"path": "/tmp/5"})
        )
        self.assertTrue(rollback)

    def test_probation_monitor_tool_repetition_trigger(self) -> None:
        monitor = ProbationMonitor(probation_window_steps=10)

        # Call same tool/args twice -> OK
        self.assertFalse(monitor.record_step(is_rework=False, edit_churn_pct=5.0, tool_call=("grep", {"pat": "abc"})))
        self.assertFalse(monitor.record_step(is_rework=False, edit_churn_pct=5.0, tool_call=("grep", {"pat": "abc"})))

        # 3rd identical call -> triggers rollback immediately
        rollback = monitor.record_step(is_rework=False, edit_churn_pct=5.0, tool_call=("grep", {"pat": "abc"}))
        self.assertTrue(rollback)
