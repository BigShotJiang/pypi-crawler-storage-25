import unittest
from granary.discovery import (
    NetworkSignal,
    build_defender_alert_payload,
    classify_agent_signature,
)


class TestGranaryDiscovery(unittest.TestCase):

    def test_classify_agent_signature_detects_agentic_traffic(self) -> None:
        signal = NetworkSignal(
            source_host="devbox-1",
            destination_host="api.anthropic.com",
            destination_port=443,
            protocol="https",
            bytes_sent=12000,
            bytes_received=15000,
            process_name="cursor-agent",
        )
        verdict = classify_agent_signature(signal)
        assert verdict.is_agentic is True
        assert verdict.confidence >= 0.6

    def test_build_defender_alert_payload_contains_evidence(self) -> None:
        signal = NetworkSignal(
            source_host="devbox-1",
            destination_host="api.openai.com",
            destination_port=443,
            protocol="https",
            bytes_sent=1000,
            bytes_received=2000,
            process_name="cursor",
        )
        verdict = classify_agent_signature(signal)
        payload = build_defender_alert_payload(tenant_id="tenant-1", signal=signal, verdict=verdict)
        assert payload["provider"] == "granary"
        assert payload["evidence"]["destinationHost"] == "api.openai.com"

