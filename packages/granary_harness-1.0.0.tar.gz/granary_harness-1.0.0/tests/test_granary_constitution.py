import unittest
from datetime import datetime, timedelta, timezone

from granary.constitution import (
    OperatingConstitution,
    parse_lightweight_yaml,
)


class TestGranaryConstitution(unittest.TestCase):

    def setUp(self) -> None:
        # Load the default constitution file for testing
        with open("docs/agent-constitution.yaml", "r", encoding="utf-8") as f:
            self.yaml_content = f.read()
        self.constitution = OperatingConstitution(self.yaml_content)

    def test_parse_simple_yaml_structure(self) -> None:
        data = parse_lightweight_yaml(self.yaml_content)
        self.assertEqual(data["schema_version"], "1.0")
        self.assertEqual(data["constitution_id"], "living-nn-agent-ops")
        self.assertEqual(data["default_tier"], "T1")
        self.assertIn("immutable_rules", data)
        self.assertIsInstance(data["immutable_rules"], list)
        self.assertEqual(data["immutable_rules"][0]["id"], "TOS_PUBLIC_SURFACE")

    def test_verify_immutable_rules_hash(self) -> None:
        # Extract the immutable rules section to test hash verification
        # The immutable rules part is covered by immutable_rules_hash in YAML
        raw_rules = """
  - id: "TOS_PUBLIC_SURFACE"
    rule: "No bot/automation reference in public GFO surfaces"
    source: "separation-rules.md"
  - id: "NO_SECRET_COMMIT"
    rule: "Never stage/commit .env, training.log, system_state/, venv/"
    source: "CLAUDE.md"
  - id: "NO_CROSS_REPO"
    rule: "living-nn != GrandFlipOut monorepo"
    source: "DIRECTION.md"
  - id: "CONTINUOUS_LEARNING_GATE"
    rule: "CONTINUOUS_LEARNING_ENABLED requires human + log verification"
    source: "config.py"
  - id: "PRETRAIN_MANUAL"
    rule: "No long pretrain without explicit user request"
    source: "HANDOFF.md"
  - id: "COMMIT_ONLY_WHEN_ASKED"
    rule: "No proactive git commits"
    source: "global"
  - id: "HUMAN_ONLY_AMENDMENT"
    rule: "Constitution/tier-ceiling changes are human-only"
    source: "global"
  - id: "FAIL_CLOSED_PROD"
    rule: "Ambiguous prod signal -> T0 until human re-authorizes"
    source: "global"
"""
        self.assertTrue(self.constitution.verify_immutable_rules_hash(raw_rules))

    def test_check_action_permissions_by_tier(self) -> None:
        self.constitution.current_tier = "T1"
        allowed, msg = self.constitution.check_action_allowed("FS_WRITE_CODE")
        self.assertTrue(allowed, msg)

        allowed, msg = self.constitution.check_action_allowed("SERVICE_RESTART_USER")
        self.assertFalse(allowed, msg)

        self.constitution.current_tier = "T2"
        allowed, msg = self.constitution.check_action_allowed("SERVICE_RESTART_USER")
        self.assertTrue(allowed, msg)

    def test_blast_radius_limits(self) -> None:
        self.constitution.current_tier = "T1"
        
        # Within limits
        allowed, msg = self.constitution.check_blast_radius(
            files_edited=5,
            loc_delta=300,
            tokens_used=200000,
            elapsed_minutes=30.0
        )
        self.assertTrue(allowed, msg)

        # Exceed max files limit
        allowed, msg = self.constitution.check_blast_radius(
            files_edited=10,
            loc_delta=300,
            tokens_used=200000,
            elapsed_minutes=30.0
        )
        self.assertFalse(allowed, msg)
        self.assertIn("files_edited", msg)

        # Exceed max LOC limit
        allowed, msg = self.constitution.check_blast_radius(
            files_edited=5,
            loc_delta=500,
            tokens_used=200000,
            elapsed_minutes=30.0
        )
        self.assertFalse(allowed, msg)
        self.assertIn("loc_delta", msg)

    def test_path_overrides_protection(self) -> None:
        self.constitution.current_tier = "T4"
        
        # Edits to core/system.py has max_tier: "T2" override constraint
        allowed, msg = self.constitution.verify_path_override(
            filepath="core/system.py",
            files_edited=1,
            loc_delta=50,
        )
        self.assertFalse(allowed, msg)
        self.assertIn("max tier T2", msg)

        self.constitution.current_tier = "T2"
        allowed, msg = self.constitution.verify_path_override(
            filepath="core/system.py",
            files_edited=1,
            loc_delta=50,
        )
        self.assertTrue(allowed, msg)

        # Edits to core/system.py has max LOC limits of 200
        allowed, msg = self.constitution.verify_path_override(
            filepath="core/system.py",
            files_edited=1,
            loc_delta=250,
        )
        self.assertFalse(allowed, msg)
        self.assertIn("LOC delta", msg)

    def test_parse_and_apply_elevation_token(self) -> None:
        # Command format: APPROVE T{n} session={uuid} until={ISO8601} reason={slug}
        expires_str = (datetime.now(timezone.utc) + timedelta(hours=1)).isoformat()
        token_cmd = f"APPROVE T3 session=ea8106df-2031-411a-85ba-b07ea692 until={expires_str} reason=tuning-deploy"
        
        token = self.constitution.parse_elevation_token(token_cmd)
        self.assertIsNotNone(token)
        self.assertEqual(token.tier, "T3")
        self.assertEqual(token.session_id, "ea8106df-2031-411a-85ba-b07ea692")
        self.assertEqual(token.reason, "tuning-deploy")

        # Apply elevation successfully
        success = self.constitution.apply_elevation(token)
        self.assertTrue(success)
        self.assertEqual(self.constitution.current_tier, "T3")

    def test_fail_closed_prod_mode(self) -> None:
        self.constitution.enforce_fail_closed_prod(is_prod_detected=True)
        self.assertEqual(self.constitution.current_tier, "T0")
        self.assertTrue(self.constitution.fail_closed_mode)

        # Attempting write action should be blocked under fail-closed T0 mode
        allowed, msg = self.constitution.check_action_allowed("FS_WRITE_CODE")
        self.assertFalse(allowed, msg)
        self.assertIn("FAIL_CLOSED_PROD_MODE_ACTIVE", msg)
