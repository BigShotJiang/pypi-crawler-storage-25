import os
import json
import shutil
import unittest
from granary.core_store import (
    ImmutableCoreStore,
    CheckpointManifest,
    bootstrap_session_with_handoff,
)


class TestGranaryCoreStore(unittest.TestCase):

    def setUp(self) -> None:
        self.root = "/tmp/granary_core_store_test_dir"
        shutil.rmtree(self.root, ignore_errors=True)
        self.secret = b"core-replicator-secret"
        self.store = ImmutableCoreStore(self.root, self.secret)

    def tearDown(self) -> None:
        shutil.rmtree(self.root, ignore_errors=True)

    def test_append_journal_events_atomically(self) -> None:
        evt1 = self.store.append_journal_event("task_started", {"task_id": "t1"})
        evt2 = self.store.append_journal_event("task_completed", {"task_id": "t1"})

        self.assertTrue(os.path.exists(self.store.journal_file))
        self.assertEqual(evt1["event_type"], "task_started")
        self.assertEqual(evt2["event_type"], "task_completed")

    def test_publish_sealed_snapshot_atomic_write_flow(self) -> None:
        state = {"metrics": {"accuracy": 0.85}, "model_weights_ref": "v2"}
        manifest = self.store.publish_sealed_snapshot(step=500, state_data=state)

        self.assertEqual(manifest.step, 500)
        self.assertTrue(manifest.version_id.startswith("snap_step_500_"))
        self.assertTrue(os.path.exists(self.store.checkpoint_file))

        # Check integrity verification succeeds
        ok, msg = self.store.verify_checkpoint_integrity()
        self.assertTrue(ok, msg)

    def test_verify_checkpoint_detects_signature_mismatch(self) -> None:
        state = {"metrics": {"accuracy": 0.85}}
        self.store.publish_sealed_snapshot(step=500, state_data=state)

        # Alter the secret key on a different sub-replicator to trigger signature validation failure
        malicious_store = ImmutableCoreStore(self.root, secret_key=b"altered-unallowed-secret")
        ok, msg = malicious_store.verify_checkpoint_integrity()
        self.assertFalse(ok)
        self.assertEqual(msg, "invalid_checkpoint_signature")

    def test_verify_checkpoint_detects_file_tampering(self) -> None:
        state = {"metrics": {"accuracy": 0.85}}
        manifest = self.store.publish_sealed_snapshot(step=500, state_data=state)

        # Let's manually corrupt/alter the content of the published snapshot file
        snap_path = os.path.join(self.store.snapshot_dir, f"{manifest.version_id}.json")
        with open(snap_path, "w", encoding="utf-8") as f:
            f.write('{"metrics":{"accuracy":0.00}}') # altered accuracy

        # Verification must now fail
        ok, msg = self.store.verify_checkpoint_integrity()
        self.assertFalse(ok)
        self.assertEqual(msg, "snapshot_content_hash_mismatch")

    def test_execute_backup_verify_drill(self) -> None:
        state = {"metrics": {"accuracy": 0.85}}
        self.store.publish_sealed_snapshot(step=500, state_data=state)

        backup_root = "/tmp/granary_backups_dr_root"
        shutil.rmtree(backup_root, ignore_errors=True)

        ok, msg = self.store.execute_backup_verify_drill(backup_root)
        self.assertTrue(ok)
        self.assertTrue(os.path.exists(backup_root))

        shutil.rmtree(backup_root, ignore_errors=True)

    def test_bootstrap_session_with_handoff_reconstruction(self) -> None:
        # Create a mock .handoff latest.json bootstrap packet
        handoff_dir = os.path.join(self.root, ".handoff")
        os.makedirs(handoff_dir, exist_ok=True)
        packet = {"timestamp": 12345.6, "tasks": [{"task_id": "t1", "status": "completed"}]}
        
        with open(os.path.join(handoff_dir, "latest.json"), "w", encoding="utf-8") as f:
            json.dump(packet, f)

        data = bootstrap_session_with_handoff(self.root)
        self.assertIsNotNone(data)
        self.assertEqual(data["tasks"][0]["task_id"], "t1")
