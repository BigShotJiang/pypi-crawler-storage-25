import os
import shutil
import unittest
import pickle
from granary.disaster_recovery import DREventStreamReplicator, JournalEvent


class TestGranaryDisasterRecovery(unittest.TestCase):

    def setUp(self) -> None:
        self.secret = b"dr-replicator-secret-key-1234567"
        self.path = "/tmp/granary_dr_test"
        shutil.rmtree(self.path, ignore_errors=True)
        self.replicator = DREventStreamReplicator("primary", self.secret, self.path)

    def tearDown(self) -> None:
        shutil.rmtree(self.path, ignore_errors=True)

    def test_append_event_enforces_permissions(self) -> None:
        # Success on primary
        evt = self.replicator.append_event("set_state", {"key1": "val1"})
        self.assertEqual(evt.event_id, 1)
        self.assertEqual(evt.action_type, "set_state")

        # Fails on standby
        standby_rep = DREventStreamReplicator("standby", self.secret, self.path)
        with self.assertRaises(PermissionError):
            standby_rep.append_event("set_state", {"key1": "val1"})

    def test_reconstruct_state_folds_events_correctly(self) -> None:
        # Append some sequential transactions on primary
        self.replicator.append_event("set_state", {"app_mode": "strict", "step_hz": 2})
        self.replicator.append_event("set_state", {"temp_val": "remove_me"})
        self.replicator.append_event("delete_state", ["temp_val"])
        self.replicator.append_event("mark_done", {"task_id": "todo_1"})

        # Standby reads the log to reconstruct state
        standby_rep = DREventStreamReplicator("standby", self.secret, self.path)
        state = standby_rep.verify_and_reconstruct_state()

        self.assertEqual(state["app_mode"], "strict")
        self.assertEqual(state["step_hz"], 2)
        self.assertNotIn("temp_val", state)
        self.assertEqual(state["todo_1"], "completed")

    def test_reconstruct_state_detects_log_corruption(self) -> None:
        self.replicator.append_event("set_state", {"sensitive_key": "val"})

        # Let's manually corrupt the binary WAL log
        with open(self.replicator.log_file, "rb") as f:
            events = []
            while True:
                try:
                    events.append(pickle.load(f))
                except EOFError:
                    break
        
        # Corrupt the parameters of the first event
        events[0].params["sensitive_key"] = "altered_evil_val"
        
        # Write corrupted events back
        with open(self.replicator.log_file, "wb") as f:
            for e in events:
                pickle.dump(e, f)

        # Standby verify and reconstruct should trigger Valueerror
        standby_rep = DREventStreamReplicator("standby", self.secret, self.path)
        with self.assertRaises(ValueError):
            standby_rep.verify_and_reconstruct_state()

    def test_hot_failover_standby_promotion(self) -> None:
        # Primary appends some events
        self.replicator.append_event("set_state", {"cluster_size": 3})

        standby_rep = DREventStreamReplicator("standby", self.secret, self.path)
        self.assertEqual(standby_rep.role, "standby")

        # Trigger failover
        state = standby_rep.handle_failover()
        self.assertEqual(standby_rep.role, "primary")
        self.assertEqual(state["cluster_size"], 3)
