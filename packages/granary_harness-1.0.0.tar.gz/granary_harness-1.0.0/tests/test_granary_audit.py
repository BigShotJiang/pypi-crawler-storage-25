import unittest
import time
from granary.audit import AuditManager


class TestGranaryAudit(unittest.TestCase):

    def test_redaction_policy_masks_credentials(self) -> None:
        manager = AuditManager()
        payload = {
            "cmd": "init",
            "db_password": "super-secret-pass",
            "nested_config": {
                "bearer_token": "token-12345",
                "normal_val": "safe-to-log"
            }
        }
        redacted = manager.redact_payload(payload)
        self.assertEqual(redacted["db_password"], "[REDACTED_SENSITIVE]")
        self.assertEqual(redacted["nested_config"]["bearer_token"], "[REDACTED_SENSITIVE]")
        self.assertEqual(redacted["nested_config"]["normal_val"], "safe-to-log")

    def test_merkle_chained_tamper_evident_verification(self) -> None:
        manager = AuditManager()
        
        # Append 3 logs
        manager.append_log(session_id="s1", event_type="PROMPT_INPUT", actor_type="USER", payload={"msg": "hello"})
        manager.append_log(session_id="s1", event_type="TOOL_REQUEST", actor_type="PLANNER_LLM", payload={"tool": "read_file"})
        manager.append_log(session_id="s1", event_type="TOOL_RESPONSE", actor_type="SANDBOX_TOOL", payload={"result": "success"})

        # Initial chain must verify successfully
        verified, msg = manager.verify_chain_integrity()
        self.assertTrue(verified, msg)

        # Tamper with the second log
        manager.ledger[1].payload_json = '{"tool": "malicious_write"}'
        
        # Chain verification must now fail
        verified, msg = manager.verify_chain_integrity()
        self.assertFalse(verified)
        self.assertIn("Integrity break", msg)

    def test_retention_and_legal_hold_enforcement(self) -> None:
        manager = AuditManager()
        
        # Add normal log (to be expired)
        manager.append_log(session_id="s_old", event_type="PROMPT_INPUT", actor_type="USER", payload={"msg": "expire-me"})
        
        # Add legal held log (should be retained despite being old)
        manager.append_log(session_id="s_hold", event_type="PROMPT_INPUT", actor_type="USER", payload={"msg": "hold-me"})
        manager.set_legal_hold("s_hold", active=True)

        # Run retention policy with 10 seconds age, but set mock clock to 20 seconds in future
        now = time.time() + 20
        purged_count = manager.apply_retention_policy(max_age_seconds=10, now=now)
        
        # Only the s_old log should have been purged
        self.assertEqual(purged_count, 1)
        self.assertEqual(len(manager.ledger), 1)
        self.assertEqual(manager.ledger[0].session_id, "s_hold")
