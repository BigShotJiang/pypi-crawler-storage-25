import os
import shutil
import unittest
import time
from typing import Optional
from granary.readiness import (
    Waiver,
    GateResult,
    GoNoGoDecisionMatrix,
    execute_day0_rollback_drill,
)


class TestGranaryReadiness(unittest.TestCase):

    def test_evaluate_gate_checks(self) -> None:
        matrix = GoNoGoDecisionMatrix()
        
        # 1. Exact string match
        res_str = matrix.evaluate_gate(
            gate_id="services_active",
            description="check active",
            check_command_output="active\nactive",
            expected="active\nactive"
        )
        self.assertTrue(res_str.passed)
        self.assertFalse(res_str.waived)

        # 2. Greater-than-equal-to numeric limit
        res_gte = matrix.evaluate_gate(
            gate_id="outcome_match_rate",
            description="check rate",
            check_command_output="0.82",
            expected=">= 0.80"
        )
        self.assertTrue(res_gte.passed)

        # 3. Less-than numeric limit
        res_lt = matrix.evaluate_gate(
            gate_id="open_circuit_ratio",
            description="check ratio",
            check_command_output="0.02",
            expected="< 0.05"
        )
        self.assertTrue(res_lt.passed)

    def test_waiver_policy_authorizations_and_denials(self) -> None:
        matrix = GoNoGoDecisionMatrix()

        # Try to waive normal gate
        waiver_normal = Waiver(
            waiver_id="w_1",
            blocker_id="gfo_connection_liveness",
            expires_at=time.time() + 10,
            authorized_by="Max",
            rollback_plan_verified=True
        )
        self.assertTrue(matrix.add_waiver(waiver_normal))

        # Try to waive critical idempotency or TOS public surface gate
        waiver_idempotency = Waiver(
            waiver_id="w_2",
            blocker_id="idempotency_check",
            expires_at=time.time() + 10,
            authorized_by="Max",
            rollback_plan_verified=True
        )
        self.assertFalse(matrix.add_waiver(waiver_idempotency))

        # Try to waive TOS public surface
        waiver_tos = Waiver(
            waiver_id="w_3",
            blocker_id="tos_public_surface",
            expires_at=time.time() + 10,
            authorized_by="Max",
            rollback_plan_verified=True
        )
        self.assertFalse(matrix.add_waiver(waiver_tos))

    def test_evaluate_gate_with_active_waiver(self) -> None:
        matrix = GoNoGoDecisionMatrix()
        waiver = Waiver(
            waiver_id="w_1",
            blocker_id="gfo_connection_liveness",
            expires_at=time.time() + 10, # Active
            authorized_by="Max",
            rollback_plan_verified=True
        )
        matrix.add_waiver(waiver)

        # Check gate (will fail naturally but must pass under active waiver)
        res = matrix.evaluate_gate(
            gate_id="gfo_connection_liveness",
            description="connection check",
            check_command_output="false",
            expected="true"
        )
        self.assertTrue(res.passed)
        self.assertTrue(res.waived)

        # Check gate with expired waiver
        expired_waiver = Waiver(
            waiver_id="w_2",
            blocker_id="rest_liveness",
            expires_at=time.time() - 10, # Expired
            authorized_by="Max",
            rollback_plan_verified=True
        )
        matrix.add_waiver(expired_waiver)
        res_expired = matrix.evaluate_gate(
            gate_id="rest_liveness",
            description="liveness",
            check_command_output="failed",
            expected="healthy"
        )
        self.assertFalse(res_expired.passed)
        self.assertFalse(res_expired.waived)

    def test_day0_rollback_drill_restoration(self) -> None:
        backup_root = "/tmp/granary_dr_backups"
        target_state_path = "/tmp/granary_target_state"
        
        shutil.rmtree(backup_root, ignore_errors=True)
        shutil.rmtree(target_state_path, ignore_errors=True)
        
        # Create a mock backup folder
        backup_dir = os.path.join(backup_root, "backup_2026-05-22")
        os.makedirs(backup_dir, exist_ok=True)
        with open(os.path.join(backup_dir, "checkpoint.bin"), "w") as f:
            f.write("mock-state")

        # Mock process status checker
        process_status = "started"
        def process_status_checker(cmd: str) -> Optional[str]:
            nonlocal process_status
            if cmd == "stop":
                process_status = "stopped"
            elif cmd == "start":
                process_status = "started"
            elif cmd == "status":
                return "healthy" if process_status == "started" else "down"
            return None

        success = execute_day0_rollback_drill(
            backup_storage_root=backup_root,
            target_state_path=target_state_path,
            session_status_checker=process_status_checker
        )
        self.assertTrue(success)
        self.assertEqual(process_status, "started")
        self.assertTrue(os.path.exists(os.path.join(target_state_path, "checkpoint.bin")))

        shutil.rmtree(backup_root, ignore_errors=True)
        shutil.rmtree(target_state_path, ignore_errors=True)
