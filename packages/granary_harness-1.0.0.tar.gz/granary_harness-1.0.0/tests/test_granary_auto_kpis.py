import unittest
from granary.auto_kpis import IntelligenceKpiTracker


class TestGranaryAutoKpis(unittest.TestCase):

    def setUp(self) -> None:
        self.tracker = IntelligenceKpiTracker()

    def test_kpi_tracker_initial_values_and_updates(self) -> None:
        report = self.tracker.generate_kpi_audit_report()
        self.assertEqual(report["status"], "COMPLIANT")
        self.assertEqual(report["subsystems"]["memory"]["total"], 0)
        self.assertEqual(report["subsystems"]["security"]["total_violations"], 0)

        # Update Memory KPIs
        self.tracker.update_memory_kpis(total=10, active=5, quarantined=1, avg_trust=0.85)
        
        # Update Hook KPIs
        self.tracker.update_hook_kpis(total=5, enforced=3, avg_helped_harmed=4.5, max_depth=1)

        # Update Gate KPIs
        self.tracker.update_gate_kpis(total=4, blocking=2, avg_ece=0.08, avg_holdout_delta=0.05)

        # Record a violation
        self.tracker.record_violation()

        report_updated = self.tracker.generate_kpi_audit_report()
        self.assertEqual(report_updated["status"], "COMPLIANT")
        self.assertEqual(report_updated["subsystems"]["memory"]["active"], 5)
        self.assertEqual(report_updated["subsystems"]["hooks"]["avg_helped_to_harmed_ratio"], 4.5)
        self.assertEqual(report_updated["subsystems"]["gates"]["avg_ece"], 0.08)
        self.assertEqual(report_updated["subsystems"]["security"]["total_violations"], 1)

    def test_kpi_tracker_warning_and_degraded_statuses(self) -> None:
        # 1. WARNING due to high quarantined memories count
        self.tracker.update_memory_kpis(total=20, active=5, quarantined=6, avg_trust=0.7)
        report_quarantine = self.tracker.generate_kpi_audit_report()
        self.assertEqual(report_quarantine["status"], "WARNING")
        self.assertIn("high_memory_quarantine_rate", report_quarantine["reasons"])

        # 2. DEGRADED due to recursion depth limit violation (depth > 2)
        self.tracker.update_hook_kpis(total=5, enforced=3, avg_helped_harmed=4.0, max_depth=3)
        report_depth = self.tracker.generate_kpi_audit_report()
        self.assertEqual(report_depth["status"], "DEGRADED")
        self.assertIn("recursion_depth_limit_violated", report_depth["reasons"])

        # 3. FAIL_CLOSED when fail-closed active is set to True
        self.tracker.set_fail_closed(True)
        report_fail_closed = self.tracker.generate_kpi_audit_report()
        self.assertEqual(report_fail_closed["status"], "FAIL_CLOSED")
        self.assertIn("fail_closed_mode_active", report_fail_closed["reasons"])
