import unittest
import uuid
from typing import Dict, Any, List, Optional
from granary.orchestration import (
    SupervisorFSM,
    SupervisorState,
    validate_blackboard_envelope,
    validate_channel_payload,
    publish_validated,
    score_plan_decomposition,
    contract_net_allocate,
)


class MockCircuitBreaker:
    def __init__(self, allowed: bool = True, state: str = "closed") -> None:
        self.allowed = allowed
        self.state = state

    def allow_request(self) -> bool:
        return self.allowed


class MockModule:
    def __init__(self, domain: str, health: dict) -> None:
        self.domain = domain
        self.health = health


class MockBus:
    def __init__(self) -> None:
        self.published: List[tuple] = []

    def publish(self, channel: str, data: dict) -> int:
        self.published.append((channel, data))
        return len(self.published)


class MockSkillRegistry:
    def __init__(self, candidates: List[tuple]) -> None:
        self.candidates = candidates

    def find_modules_for(self, keywords: List[str]) -> List[tuple]:
        return self.candidates


class MockOrchestrator:
    def __init__(self) -> None:
        self._modules: Dict[str, MockModule] = {}
        self._circuit_breakers: Dict[str, MockCircuitBreaker] = {}
        self.DOMAIN_RELATIONS: Dict[str, List[str]] = {
            "ge_trading": ["item_analysis", "pricing_model"],
            "stock_market": ["macro_index"]
        }
        self.skill_registry: Optional[MockSkillRegistry] = None
        self._bus: Optional[MockBus] = None
        self.active_divergence: Optional[Dict] = None

    def _get_circuit_breaker(self, module_name: str) -> MockCircuitBreaker:
        return self._circuit_breakers.get(module_name, MockCircuitBreaker())

    def _has_active_divergence(self, module_names: list) -> Optional[Dict]:
        return self.active_divergence


class TestGranaryOrchestration(unittest.TestCase):

    def test_supervisor_fsm_transitions(self) -> None:
        fsm = SupervisorFSM()
        self.assertEqual(fsm.state, SupervisorState.IDLE)

        # Valid transition: Idle -> Routing
        self.assertTrue(fsm.transition("QUERY_RECEIVED", SupervisorState.ROUTING))
        self.assertEqual(fsm.state, SupervisorState.ROUTING)

        # Invalid transition: Routing -> Idle
        self.assertFalse(fsm.transition("INVALID", SupervisorState.IDLE))
        self.assertEqual(fsm.state, SupervisorState.ROUTING)

        # Valid transition: Routing -> ExecutingChain
        self.assertTrue(fsm.transition("ROUTE_CHAIN", SupervisorState.EXECUTING_CHAIN))
        self.assertEqual(fsm.state, SupervisorState.EXECUTING_CHAIN)

        # Valid hop loop transition: ExecutingChain -> ExecutingChain
        self.assertTrue(fsm.transition("HOP_SUCCESS", SupervisorState.EXECUTING_CHAIN))

        # Valid transition: ExecutingChain -> Feedback
        self.assertTrue(fsm.transition("CHAIN_DONE", SupervisorState.FEEDBACK))
        self.assertEqual(fsm.state, SupervisorState.FEEDBACK)

    def test_blackboard_envelope_validation(self) -> None:
        valid_envelope = {
            "artifact_id": str(uuid.uuid4()),
            "channel": "orchestrator.routing_decision",
            "schema_version": "1.0.0",
            "producer": "orchestrator",
            "step": 42,
            "ttl_steps": 1,
            "payload": {
                "modules": ["ge_trading", "stock_market"],
                "strategy": "chain",
                "scores": {"ge_trading": 0.9, "stock_market": 0.8},
                "trace_id": str(uuid.uuid4()),
                "step": 42,
            },
            "provenance": {
                "parent_trace_id": str(uuid.uuid4()),
                "hop_index": 0,
                "module_chain": ["ge_trading"],
            }
        }
        # Should not raise exception
        validate_blackboard_envelope(valid_envelope)
        validate_channel_payload("orchestrator.routing_decision", valid_envelope["payload"])

        # Test invalid schema_version
        invalid_env = dict(valid_envelope)
        invalid_env["schema_version"] = "1.0-alpha"
        with self.assertRaises(ValueError):
            validate_blackboard_envelope(invalid_env)

    def test_validate_channel_payload_types_and_ranges(self) -> None:
        # Invalid consensus value in EnsembleArtifact
        bad_ensemble_payload = {
            "consensus": "invalid_bullish",
            "confidence": 0.9,
            "agreement": 0.8,
            "step": 100,
        }
        with self.assertRaises(ValueError):
            validate_channel_payload("ensemble.prediction", bad_ensemble_payload)

        # Out-of-bounds trade outcome in TradeOutcomeArtifact
        bad_trade_payload = {
            "item_name": "Twisted Bow",
            "buy_price": -100, # negative
            "sell_price": 500,
            "profit": 600,
            "timestamp": 123456.7,
        }
        with self.assertRaises(ValueError):
            validate_channel_payload("federation.trade_outcome", bad_trade_payload)

    def test_publish_validated_gate_enforcement(self) -> None:
        bus = MockBus()
        registry = {
            "channels": {
                "orchestrator.routing_decision": {}
            }
        }
        envelope = {
            "artifact_id": str(uuid.uuid4()),
            "channel": "orchestrator.routing_decision",
            "schema_version": "1.0.0",
            "producer": "orchestrator",
            "step": 1,
            "payload": {
                "modules": ["ge_trading"],
                "strategy": "single",
                "scores": {"ge_trading": 0.9},
                "trace_id": str(uuid.uuid4()),
            },
            "provenance": {
                "parent_trace_id": str(uuid.uuid4()),
            }
        }
        pub_id = publish_validated(bus, registry, "orchestrator.routing_decision", envelope)
        self.assertEqual(pub_id, 1)
        self.assertEqual(len(bus.published), 1)

    def test_score_plan_decomposition_pdqr(self) -> None:
        orch = MockOrchestrator()
        orch._modules = {
            "ge_trading": MockModule("ge_trading", {"is_retired": False, "is_paused": False}),
            "stock_market": MockModule("stock_market", {"is_retired": False, "is_paused": False}),
        }
        
        # Test accept plan
        res = score_plan_decomposition(
            prompt="Is Twisted Bow going to rise?",
            modules=["ge_trading", "stock_market"],
            scores={"ge_trading": 0.9, "stock_market": 0.8},
            orch=orch,
            intent_domains={"ge_trading", "stock_market"},
        )
        self.assertEqual(res["verdict"], "accept")
        self.assertGreaterEqual(res["composite_score"], 0.72)

        # Test hard reject on retired module
        orch._modules["ge_trading"].health["is_retired"] = True
        res_retired = score_plan_decomposition(
            prompt="Is Twisted Bow going to rise?",
            modules=["ge_trading", "stock_market"],
            scores={"ge_trading": 0.9, "stock_market": 0.8},
            orch=orch,
            intent_domains={"ge_trading", "stock_market"},
        )
        self.assertEqual(res_retired["verdict"], "reject")
        self.assertIn("module_is_retired(ge_trading)", res_retired["rejection_reasons"])

    def test_contract_net_allocation_cnp(self) -> None:
        orch = MockOrchestrator()
        orch._bus = MockBus()
        orch.skill_registry = MockSkillRegistry([
            ("ge_trading", "predict", 1.2),
            ("stock_market", "analyze", 0.9),
        ])
        orch._modules = {
            "ge_trading": MockModule("ge_trading", {"direction_accuracy": 0.8, "accuracy_samples": 25, "gate_confidence": 0.85}),
            "stock_market": MockModule("stock_market", {"direction_accuracy": 0.6, "accuracy_samples": 22, "gate_confidence": 0.7}),
        }
        
        winner, fallbacks = contract_net_allocate(
            orch=orch,
            task_id="task_1",
            prompt="predict the GE prices of OSRS items",
            excluded=[],
            required_domains=["ge_trading"],
        )
        self.assertEqual(winner, "ge_trading")
        self.assertEqual(fallbacks, ["stock_market"])
        self.assertEqual(len(orch._bus.published), 1)
        self.assertEqual(orch._bus.published[0][0], "orchestrator.task_awarded")
