"""Agent Platform CLI - resource/operation style commands."""

import hashlib
import json
import os
import shlex
import uuid
from pathlib import Path
from typing import List, Optional

import typer
from rich import print
from rich.console import Console

from ap_client import __version__, get_client, get_config
from ap_client.api import APIError, set_verbose_override
from ap_client.config import ConfigurationError, _parse_bool
from ap_client.exporter import export_group, export_job
from ap_client.waiter import WaitTimeoutError, wait_for_group, wait_for_job

# Verbose mode (AP_VERBOSE / --verbose) also controls whether Typer's pretty
# traceback dumps local variables on unhandled exceptions. Default is off to
# avoid leaking large payloads (URLs, events, job dicts) to end users.
_INITIAL_VERBOSE = _parse_bool(os.environ.get("AP_VERBOSE"))

app = typer.Typer(
    name="ap",
    help="Agent Platform CLI - minimal job submission tool",
    add_completion=False,
    no_args_is_help=True,
    pretty_exceptions_show_locals=_INITIAL_VERBOSE,
)
console = Console()
error_console = Console(stderr=True)

_NON_JSON_RESPONSE_DETAIL = "Unexpected non-JSON response from API endpoint"
_NON_JSON_RESPONSE_HINT = (
    "The request may have reached a gateway or non-API service. "
    "Check AP_CLUSTER and AP_BASE_URL."
)
_JOB_STATUS_HELP = "Job status. Values: Queued, Pending, Running, Succeeded, Failed, Cancelled, Unknown"
_ISO_TIME_HELP = "ISO time, e.g. 2026-03-26T00:00:00 or 2026-03-26T00:00:00+08:00"


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(__version__)
        raise typer.Exit()


@app.callback()
def _global_options(
    verbose: bool = typer.Option(
        False,
        "--verbose",
        help="Print HTTP Request/Response details to stderr (overrides AP_VERBOSE)",
    ),
    version: bool = typer.Option(
        False,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
) -> None:
    """Global CLI options."""
    del version
    if verbose:
        set_verbose_override(True)
        # Keep traceback-locals behavior in sync with the HTTP verbose switch.
        app.pretty_exceptions_show_locals = True


# Resource sub-command groups
template_app = typer.Typer(help="Template operations")
dataset_app = typer.Typer(help="Dataset operations")
job_app = typer.Typer(help="Job operations")
group_app = typer.Typer(help="Group operations")
plan_app = typer.Typer(help="Eval plan operations")

app.add_typer(template_app, name="template")
app.add_typer(dataset_app, name="dataset")
app.add_typer(job_app, name="job")
app.add_typer(group_app, name="group")
app.add_typer(plan_app, name="plan")

_PAI_RUNTIME_ENV_TAGS: tuple[tuple[str, str], ...] = (
    ("DLC_JOB_ID", "dlc_job_id"),
    ("DSW_INSTANCE_ID", "dsw_instance_id"),
    ("PAI_WORKSPACE_ID", "pai_workspace_id"),
    ("PAI_WORKSPACE_NAME", "pai_workspace_name"),
    ("PAI_USER_ID", "pai_user_id"),
    ("PAI_CLUSTER_ID", "pai_cluster_id"),
)


def _print_json(data):
    """Pretty-print JSON output."""
    console.print_json(json.dumps(data, ensure_ascii=False, indent=2))


def _emit_info(message: str, output_format: str = "plain") -> None:
    typer.echo(message, err=output_format != "plain")


def _emit_progress(message: str) -> None:
    typer.echo(message, err=True)


def _job_create_progress():
    from rich.progress import BarColumn, Progress, TaskProgressColumn, TextColumn

    return Progress(
        TextColumn("{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TextColumn("{task.fields[current_job]}"),
        TextColumn("{task.fields[current_stage]}"),
        console=Console(stderr=True),
        transient=True,
    )


def _shell_command(args: list[str]) -> str:
    return " ".join(shlex.quote(str(arg)) for arg in args)


def _build_job_create_retry_command(
    *,
    template: str,
    agenthub_ref: Optional[str],
    instance_id: Optional[str],
    dataset: Optional[str],
    instance_range: Optional[str],
    exclude_instance_ids: Optional[str],
    params: Optional[str],
    params_list_input: Optional[str],
    suite_name: Optional[str],
    group_id: Optional[str],
    tags: Optional[str],
    overrides: Optional[str],
    concurrency: Optional[int],
    batch_size: int,
    wait: bool,
    wait_interval: float,
    wait_timeout: Optional[float],
    output_format: str,
    enable_otel_tracing: Optional[bool],
    runner: Optional[str],
    runner_options: Optional[str],
    model_base_url_collection: Optional[str],
    model_base_url_file: Optional[str],
    idempotency_key: str,
) -> str:
    args = ["ap", "job", "create", template]
    if agenthub_ref:
        args.extend(["--agenthub-ref", agenthub_ref])
    if instance_id:
        args.extend(["-i", instance_id])
    if dataset:
        args.extend(["--dataset", dataset])
    if instance_range:
        args.extend(["--range", instance_range])
    if exclude_instance_ids:
        args.extend(["--exclude-instance-ids", exclude_instance_ids])
    if params:
        args.extend(["-p", params])
    if params_list_input:
        args.extend(["--params-list", params_list_input])
    if suite_name:
        args.extend(["--suite-name", suite_name])
    if group_id:
        args.extend(["--group-id", group_id])
    if tags:
        args.extend(["--tags", tags])
    if overrides:
        args.extend(["--overrides", overrides])
    if concurrency is not None:
        args.extend(["--concurrency", str(concurrency)])
    if batch_size != 200:
        args.extend(["--batch-size", str(batch_size)])
    if wait:
        args.append("--wait")
        if wait_interval != 5.0:
            args.extend(["--wait-interval", f"{wait_interval:g}"])
        if wait_timeout is not None:
            args.extend(["--wait-timeout", f"{wait_timeout:g}"])
    if output_format != "plain":
        args.extend(["--format", output_format])
    if enable_otel_tracing is not None:
        args.extend(["--enable-otel-tracing", str(enable_otel_tracing).lower()])
    if runner:
        args.extend(["--runner", runner])
    if runner_options:
        args.extend(["--runner-options", runner_options])
    if model_base_url_collection:
        args.extend(["--model-base-url-collection", model_base_url_collection])
    if model_base_url_file:
        args.extend(["--model-base-url-file", model_base_url_file])
    args.extend(["--idempotency-key", idempotency_key])
    return _shell_command(args)


def _emit_idempotency_retry_hint(command: str) -> None:
    typer.echo("", err=True)
    typer.secho("Retry this submission with:", dim=True, err=True)
    typer.secho(command, dim=True, err=True)


def _emit_error(message: str) -> None:
    error_console.print(f"[red]error: {message}[/]")


def _format_wait_timeout(timeout: Optional[float]) -> str:
    if timeout is None:
        return "none"
    if timeout == int(timeout):
        return f"{int(timeout)}s"
    return f"{timeout:g}s"


def _normalize_output_format(output_format: str) -> str:
    value = output_format.lower()
    if value == "text":
        return "plain"
    if value not in {"plain", "json", "yaml"}:
        raise typer.BadParameter("output format must be one of plain/json/yaml")
    return value


def _parse_instance_range(value: str) -> slice:
    raw = value.strip()
    if not raw:
        raise ValueError("--range must not be empty")

    if raw.startswith("range(") and raw.endswith(")"):
        raw = raw[len("range(") : -1]
        parts = [part.strip() for part in raw.split(",")]
        if len(parts) == 1:
            parts = ["", parts[0]]
    elif "," in raw:
        parts = [part.strip() for part in raw.split(",")]
    elif ":" in raw:
        parts = [part.strip() for part in raw.split(":")]
    else:
        parts = ["", raw]

    if len(parts) not in {2, 3}:
        raise ValueError(
            "--range must use END, START,END, START,END,STEP; also accepts START:END[:STEP] or range(...)"
        )

    try:
        start = int(parts[0]) if parts[0] else None
        stop = int(parts[1]) if parts[1] else None
        step = int(parts[2]) if len(parts) == 3 and parts[2] else None
    except ValueError as exc:
        raise ValueError("--range values must be integers") from exc

    if step == 0:
        raise ValueError("--range step must not be 0")
    if start is None and stop is None and step is None:
        raise ValueError("--range must specify at least one of start, end, or step")

    return slice(start, stop, step)


def _parse_instance_id_csv(value: str, option_name: str) -> list[str]:
    ids = [iid.strip() for iid in value.split(",") if iid.strip()]
    if not ids:
        raise ValueError(f"{option_name} must include at least one instance id")
    return ids


def _select_instance_ids(
    instance_ids: list[str],
    instance_range: Optional[str],
    exclude_instance_ids: Optional[str],
) -> list[str]:
    selected = instance_ids

    if instance_range:
        selected = selected[_parse_instance_range(instance_range)]
        if not selected:
            raise ValueError("--range selected no instance ids")

    if exclude_instance_ids:
        excluded = set(_parse_instance_id_csv(exclude_instance_ids, "--exclude-instance-ids"))
        selected = [iid for iid in selected if iid not in excluded]
        if not selected:
            raise ValueError("no instance ids remain after --exclude-instance-ids")

    return selected


def _print_formatted(data: dict, output_format: str) -> None:
    if output_format == "json":
        typer.echo(json.dumps(data, ensure_ascii=False, indent=2))
        return
    if output_format == "yaml":
        try:
            import yaml
        except ImportError as exc:
            raise typer.BadParameter("--format yaml requires PyYAML to be installed") from exc
        typer.echo(yaml.safe_dump(data, allow_unicode=True, sort_keys=False))
        return
    _print_json(data)


def _print_job_create_dry_run(
    client,
    payloads: list[dict],
    *,
    timeout: float,
    output_format: str,
) -> None:
    result = {
        "dry_run": True,
        "request": {
            "method": "POST",
            "url": client._url("/jobs"),
            "headers": client.preview_request_headers(),
            "timeout": timeout,
        },
        "payloads": payloads,
    }
    _print_formatted(result, "json" if output_format == "plain" else output_format)


def _emit_dry_run_warnings(warnings: list[str]) -> None:
    for warning in warnings:
        typer.echo(f"warning: {warning}", err=True)


def _print_plain_table(rows: list[dict], columns: list[tuple[str, str]]) -> None:
    if not rows:
        typer.echo("")
        return

    widths = []
    for key, title in columns:
        width = len(title)
        for row in rows:
            width = max(width, len(_stringify_cell(row.get(key))))
        widths.append(width)

    header = "  ".join(title.ljust(width) for (_, title), width in zip(columns, widths))
    typer.echo(header)
    for row in rows:
        typer.echo(
            "  ".join(
                _stringify_cell(row.get(key)).ljust(width)
                for (key, _title), width in zip(columns, widths)
            )
        )


def _stringify_cell(value: object) -> str:
    if value is None:
        return ""
    return str(value)


def _merge_job_tags(tags: Optional[list[str]]) -> Optional[list[str]]:
    merged: list[str] = []
    seen_tags: set[str] = set()

    for raw in (tags or []) + _runtime_job_tags():
        tag = str(raw).strip()
        if not tag or tag in seen_tags:
            continue
        merged.append(tag)
        seen_tags.add(tag)

    return merged or None


def _idempotency_item_key(
    *,
    template: str,
    params: dict,
    global_index: int,
    overrides: Optional[dict],
    agenthub_revision: Optional[str],
    enable_otel_tracing: Optional[bool],
    runner: Optional[str],
    runner_options: Optional[dict],
    model_base_url_collection: Optional[list],
) -> str:
    # Client-supplied item keys are authoritative; server hashing is only a
    # fallback for non-CLI callers, so this payload intentionally need not
    # match the server-side fallback payload exactly.
    payload = json.dumps(
        {
            "template": template,
            "params": params,
            "idempotency_metadata": {"global_index": global_index},
            "overrides": overrides,
            "agenthub_revision": agenthub_revision,
            "runner": runner,
            "runner_options": runner_options,
            "model_base_url_collection": model_base_url_collection,
            "enable_otel_tracing": enable_otel_tracing,
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _runtime_job_tags() -> list[str]:
    if not (os.getenv("DLC_JOB_ID", "").strip() or os.getenv("DSW_INSTANCE_ID", "").strip()):
        return []

    tags: list[str] = []
    for env_name, tag_name in _PAI_RUNTIME_ENV_TAGS:
        value = os.getenv(env_name, "").strip()
        if value:
            tags.append(f"{tag_name}:{value}")
    return tags


def _print_job_list_plain(result: dict) -> None:
    jobs = result.get("jobs", [])
    for row in jobs:
        if "tags" in row and isinstance(row["tags"], list):
            row["tags"] = ",".join(row["tags"])
    _print_plain_table(
        jobs,
        [
            ("job_id", "job_id"),
            ("template", "template"),
            ("instance_id", "instance_id"),
            ("group_id", "group_id"),
            ("status", "status"),
            ("failed_reason", "failed_reason"),
            ("tags", "tags"),
            ("created_at", "created_at"),
        ],
    )


def _print_group_list_plain(result: dict) -> None:
    _print_plain_table(
        result.get("groups", []),
        [
            ("group_id", "group_id"),
            ("name", "name"),
            ("max_concurrency", "max_concurrency"),
            ("created_at", "created_at"),
        ],
    )


def _pick_available_columns(
    rows: list[dict], candidates: list[tuple[str, str]]
) -> list[tuple[str, str]]:
    return [col for col in candidates if any(col[0] in row for row in rows)]


def _print_group_eval_plain(result: dict) -> None:
    header_parts: list[str] = []
    for key in ("group_id", "name"):
        if key in result:
            header_parts.append(f"{key}={_stringify_cell(result.get(key))}")
    if header_parts:
        typer.echo("  ".join(header_parts))

    summary = result.get("summary", {})
    has_summary = isinstance(summary, dict) and bool(summary)
    if has_summary:
        pass_keys = sorted(
            k for k in summary.keys() if k.startswith("pass@") or k.startswith("pass^")
        )
        summary_columns = _pick_available_columns(
            [summary],
            [
                ("total_tasks", "total_tasks"),
                ("total_trials", "total_trials"),
                ("scored_tasks", "scored_tasks"),
                ("passed_tasks", "passed_tasks"),
                ("avg_score", "avg_score"),
                ("pass_rate", "pass_rate"),
                ("avg_completion", "avg_completion"),
                ("avg_robustness", "avg_robustness"),
                ("avg_safety", "avg_safety"),
                *[(key, key) for key in pass_keys],
            ],
        )
        if summary_columns:
            _print_plain_table([summary], summary_columns)
        else:
            _print_json(summary)

    raw_rows = result.get("per_task", [])
    rows = [row for row in raw_rows if isinstance(row, dict)] if isinstance(raw_rows, list) else []
    if has_summary and rows:
        typer.echo("")
    if not rows:
        return

    columns = _pick_available_columns(
        rows,
        [
            ("task_id", "task_id"),
            ("trials", "trials"),
            ("scored", "scored"),
            ("avg_score", "avg_score"),
            ("passed", "passed"),
            ("pass_rate", "pass_rate"),
            ("completion", "completion"),
            ("robustness", "robustness"),
            ("communication", "communication"),
            ("safety", "safety"),
            ("category", "category"),
            ("difficulty", "difficulty"),
            ("total_tokens", "total_tokens"),
            ("input_tokens", "input_tokens"),
            ("output_tokens", "output_tokens"),
            ("total_turns", "total_turns"),
            ("wall_time_s", "wall_time_s"),
            ("model_time_s", "model_time_s"),
        ],
    )
    if not columns:
        _print_json({"results": rows})
        return
    _print_plain_table(rows, columns)


def _print_job_events_plain(result: dict) -> None:
    if "containers" in result:
        for cname, events in result["containers"].items():
            print(f"\n[{cname}]")
            for event in events:
                print(event)
        return
    for event in result.get("events", []):
        print(event)


def _mask_config_secret(value: str | None) -> str | None:
    if not value:
        return None
    if len(value) <= 8:
        return value[:1] + "..." + value[-1:]
    if len(value) <= 16:
        return value[:4] + "..." + value[-4:]
    return value[:8] + "..." + value[-4:]


def _mask_config_headers(headers: dict) -> dict:
    masked = {}
    for key, value in headers.items():
        lower = key.lower()
        if any(
            token in lower for token in ("authorization", "token", "api-key", "cookie", "secret")
        ):
            masked[key] = "***"
        else:
            masked[key] = value
    return masked


def _extract_cluster(headers: dict) -> str | None:
    for key, value in headers.items():
        if key.lower() == "x-cluster":
            return value
    return None


def _config_payload(show_secrets: bool = False) -> dict:
    from ap_client import api as _api

    config = get_config(verbose=_api._verbose_override)
    ap_cluster = (
        os.environ.get("AP_CLUSTER", "").strip() or _extract_cluster(config.headers) or None
    )
    return {
        "base_url": config.base_url,
        "ap_cluster": ap_cluster,
        "agenthub_ref": config.agenthub_ref,
        "ap_verbose": config.verbose,
        "ap_verbose_full_body": config.verbose_full_body,
        "api_key": config.token_key if show_secrets else _mask_config_secret(config.token_key),
        "headers": config.headers if show_secrets else _mask_config_headers(config.headers),
    }


@app.command("whoami")
def auth_whoami():
    """显示当前认证信息"""
    config = get_config()
    if config.token_key:
        print("认证方式: API Key")
        print(f"Key:      {_mask_config_secret(config.token_key)}")
    else:
        print("未认证（无 AP_API_KEY / AP_API_KEYS / AP_TOKEN_KEY 环境变量）")


def _list_all_group_jobs(client, group_id: str, page_size: int = 500) -> list[dict]:
    """分页获取 group 下的所有 jobs。

    终止条件（满足任一即停止）：
    1. 当前页返回空列表（没有更多数据）
    2. 已获取的任务数 >= total（服务端返回的总数）
    """
    jobs: list[dict] = []
    skip = 0
    total = None

    while True:
        page = client.list_jobs(group_id=group_id, skip=skip, limit=page_size)
        page_jobs = page.get("jobs", [])

        # 第一次请求时获取 total
        if total is None:
            total = page.get("total", 0)

        # 终止条件1: 当前页为空，说明没有更多数据
        if not page_jobs:
            break

        jobs.extend(page_jobs)
        skip += len(page_jobs)

        # 终止条件2: 已获取所有数据
        if total is not None and skip >= total:
            break

    return jobs


@app.command("config")
def show_config(
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
    show_secrets: bool = typer.Option(
        False,
        "--show-secrets",
        help="Print unmasked secret values, including API key and sensitive headers",
    ),
):
    """Show the current CLI configuration."""
    output_format = _normalize_output_format(output_format)
    payload = _config_payload(show_secrets=show_secrets)
    if output_format == "plain":
        rows = [
            {"key": "base_url", "value": payload["base_url"]},
            {"key": "ap_cluster", "value": payload["ap_cluster"]},
            {"key": "agenthub_ref", "value": payload["agenthub_ref"]},
            {"key": "api_key", "value": payload["api_key"]},
            {"key": "ap_verbose", "value": str(payload["ap_verbose"]).lower()},
            {"key": "ap_verbose_full_body", "value": str(payload["ap_verbose_full_body"]).lower()},
            {"key": "headers", "value": json.dumps(payload["headers"], ensure_ascii=False)},
        ]
        _print_plain_table(rows, [("key", "key"), ("value", "value")])
        return
    _print_formatted(payload, output_format)


# ==================== Template operations ====================


@template_app.command("list")
def template_list(
    agenthub_ref: Optional[str] = typer.Option(
        None, "--agenthub-ref", help="Agent-Hub branch/commit; overrides AP_AGENTHUB_REF"
    ),
):
    """List all templates."""
    client = get_client(agenthub_ref=agenthub_ref)
    templates = client.list_templates()
    _print_json(templates)


@template_app.command("get")
def template_get(
    name: str = typer.Argument(..., help="Template name"),
    agenthub_ref: Optional[str] = typer.Option(
        None, "--agenthub-ref", help="Agent-Hub branch/commit; overrides AP_AGENTHUB_REF"
    ),
):
    """Show template details."""
    client = get_client(agenthub_ref=agenthub_ref)
    template = client.get_template(name)
    _print_json(template)


@template_app.command("render")
def template_render(
    name: str = typer.Argument(..., help="Template name"),
    params: str = typer.Argument(..., help="Parameters (JSON)"),
    agenthub_ref: Optional[str] = typer.Option(
        None, "--agenthub-ref", help="Agent-Hub branch/commit; overrides AP_AGENTHUB_REF"
    ),
):
    """Preview template rendering result (without submitting)."""
    client = get_client(agenthub_ref=agenthub_ref)
    params_dict = json.loads(params)
    result = client.render_template(name, params_dict)
    print(f"Image:      {result.get('image')}")
    print(f"Resources:  {result.get('resources')}")
    print(f"Script:     {result.get('script_length')} chars")
    if result.get("sidecars"):
        print(f"Sidecars:   {', '.join(s['name'] for s in result['sidecars'])}")
    if result.get("env"):
        print(f"\nEnv ({len(result['env'])} vars):")
        for k, v in sorted(result["env"].items()):
            val = str(v)
            if len(val) > 60:
                val = val[:57] + "..."
            print(f"  {k}={val}")


# ==================== Dataset operations ====================


@dataset_app.command("list")
def dataset_list(
    search: Optional[str] = typer.Argument(None, help="Search keyword"),
):
    """List all datasets."""
    client = get_client()
    result = client.list_datasets(search)
    _print_json(result)


@dataset_app.command("versions")
def dataset_versions(
    dataset: str = typer.Argument(..., help="Dataset name"),
):
    """List dataset versions."""
    client = get_client()
    versions = client.list_dataset_versions(dataset)
    _print_json(versions)


@dataset_app.command("instances")
def dataset_instances(
    dataset_version: str = typer.Argument(
        ..., help="Dataset version path (e.g. qclawbench/skill/V0329-tasks)"
    ),
):
    """List dataset instances."""
    client = get_client()
    result = client.list_dataset_instances(dataset_version)
    _print_json(result)


# ==================== Job operations ====================


@job_app.command("list")
def job_list(
    template: Optional[str] = typer.Option(None, "--template", help="Template name"),
    group_id: Optional[str] = typer.Option(None, "--group-id", help="Group ID"),
    status: Optional[str] = typer.Option(None, "--status", help=_JOB_STATUS_HELP),
    job_id: Optional[str] = typer.Option(None, "--job-id", help="Job ID"),
    instance_id: Optional[str] = typer.Option(None, "--instance-id", help="Instance ID"),
    finished_after: Optional[str] = typer.Option(
        None, "--finished-after", help=f"Filter by lower bound of finished_at ({_ISO_TIME_HELP})"
    ),
    finished_before: Optional[str] = typer.Option(
        None, "--finished-before", help=f"Filter by upper bound of finished_at ({_ISO_TIME_HELP})"
    ),
    created_after: Optional[str] = typer.Option(
        None, "--created-after", help=f"Filter by lower bound of created_at ({_ISO_TIME_HELP})"
    ),
    created_before: Optional[str] = typer.Option(
        None, "--created-before", help=f"Filter by upper bound of created_at ({_ISO_TIME_HELP})"
    ),
    skip: int = typer.Option(0, "--skip", help="Skip the first N entries"),
    limit: int = typer.Option(100, "--limit", help="Maximum number of entries to return"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """List jobs."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.list_jobs(
        template=template,
        group_id=group_id,
        status=status,
        job_id=job_id,
        instance_id=instance_id,
        finished_after=finished_after,
        finished_before=finished_before,
        created_after=created_after,
        created_before=created_before,
        skip=skip,
        limit=limit,
    )
    if output_format == "plain":
        _print_job_list_plain(result)
    else:
        _print_formatted(result, output_format)


@job_app.command("create")
def job_create(
    template: str = typer.Argument(..., help="Template name"),
    agenthub_ref: Optional[str] = typer.Option(
        None, "--agenthub-ref", help="Agent-Hub branch/commit; overrides AP_AGENTHUB_REF"
    ),
    instance_id: Optional[str] = typer.Option(
        None, "--instance-id", "-i", help="Instance ID (comma-separated for multiple)"
    ),
    dataset: Optional[str] = typer.Option(None, "--dataset", "-d", help="Dataset version path"),
    instance_range: Optional[str] = typer.Option(
        None,
        "--range",
        help=(
            "Select a positional subset of instance IDs. Supports END, START,END, "
            "START,END,STEP. Also accepts START:END[:STEP] and range(START, END, STEP)"
        ),
    ),
    exclude_instance_ids: Optional[str] = typer.Option(
        None,
        "--exclude-instance-ids",
        help="Instance IDs to exclude from the selected set (comma-separated)",
    ),
    params: Optional[str] = typer.Option(None, "--params", "-p", help="Parameters (JSON)"),
    params_list_input: Optional[str] = typer.Option(
        None, "--params-list", "-l", help="Params list: JSON array string or path to a JSON file"
    ),
    suite_name: Optional[str] = typer.Option(None, "--suite-name", help="Suite (job group) name"),
    group_id: Optional[str] = typer.Option(
        None, "--group-id", help="Reuse or create the specified Group ID"
    ),
    tags: Optional[str] = typer.Option(None, "--tags", help="Tags (comma-separated)"),
    overrides: Optional[str] = typer.Option(None, "--overrides", help="Override config (JSON)"),
    concurrency: Optional[int] = typer.Option(
        None,
        "--concurrency",
        "-c",
        min=1,
        help="Concurrency (max simultaneously running jobs in batch submissions). Server default: 50.",
    ),
    model_base_url_collection: Optional[str] = typer.Option(
        None,
        "--model-base-url-collection",
        help="Model base URL collection for server-side load balancing (JSON array or comma-separated)",
    ),
    batch_size: int = typer.Option(
        200, "--batch-size", min=1, help="Number of params items per batch submission request; ignored with --job-spec"
    ),
    wait: bool = typer.Option(
        False, "--wait", help="Keep waiting after submission until the jobs finish"
    ),
    model_base_url_file: Optional[str] = typer.Option(
        None,
        "--model-base-url-file",
        help="File path containing model base URL list (one URL per line), fallback for --model-base-url-collection",
    ),
    wait_interval: float = typer.Option(
        5.0, "--wait-interval", min=0.1, help="Polling interval in seconds when used with --wait"
    ),
    wait_timeout: Optional[float] = typer.Option(
        None,
        "--wait-timeout",
        min=0.0,
        help="Maximum seconds to wait when used with --wait; omit to wait indefinitely",
    ),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
    enable_otel_tracing: Optional[bool] = typer.Option(
        None,
        "--enable-otel-tracing",
        help="Enable OTEL tracing; omit to use global config",
    ),
    runner: Optional[str] = typer.Option(
        None, "--runner", help="Runner backend (rock, k8s-orchestrated, argo, local)"
    ),
    runner_options: Optional[str] = typer.Option(
        None, "--runner-options", help="Runner options (JSON)"
    ),
    enable_idempotency: bool = typer.Option(
        False,
        "--idempotency",
        help="Enable idempotent submission; generates a UUID4 key when --idempotency-key is omitted",
    ),
    idempotency_key: Optional[str] = typer.Option(
        None,
        "--idempotency-key",
        help="UUID4 key for retrying the same logical submission; providing one enables idempotency",
    ),
    dry_run: bool = typer.Option(
        False, "--dry-run", help="Preview the full HTTP request payloads without submitting (respects --batch-size splits)"
    ),
    job_spec_flag: bool = typer.Option(
        False, "--job-spec", help="Output a single job-spec JSON and exit; use as input for 'ap plan create --job-spec'"
    ),
):
    """Submit a job.

    Examples:
        # Single job - full parameters
        ap job create claw-eval-task -p '{"task_id":"T02","model":"qwen-max"}'

        # Single job - instance_id + shared params
        ap job create claw-eval-task -i T02_email_triage -p '{"model":"qwen-max"}'

        # Batch jobs - multiple instance_ids + shared params
        ap job create claw-eval-task -i T02,T03,T04 -p '{"model":"qwen-max"}'

        # Batch jobs - dataset + shared params
        ap job create claw-eval-task --dataset claw-eval/claw-eval/v1@0 -p '{"model":"qwen-max"}'

        # Batch jobs - dataset subset with exclusions
        ap job create claw-eval-task --dataset claw-eval/claw-eval/v1@0 --range 0,100,2 --exclude-instance-ids T02

        # Batch jobs from a params list (inline JSON)
        ap job create claw-eval-task --params-list '[{"task_id":"T02"},{"task_id":"T03"}]'

        # Batch jobs from a params list with shared base params (-p merged into each item)
        ap job create claw-eval-task --params-list '[{"task_id":"T02"},{"task_id":"T03"}]' -p '{"model":"qwen-max"}'

        # Batch jobs from a params list file (also supports -p for shared base params)
        ap job create claw-eval-task --params-list params.json -p '{"model":"qwen-max"}'
    """
    output_format = _normalize_output_format(output_format)
    client = get_client(agenthub_ref=agenthub_ref)

    def wait_printer(message: str) -> None:
        typer.echo(message, err=output_format != "plain")

    wait_result = None
    idempotency_enabled = enable_idempotency or idempotency_key is not None
    submission_idempotency_key = (
        idempotency_key or str(uuid.uuid4()) if idempotency_enabled else None
    )
    dry_run_warnings: list[str] = []
    if job_spec_flag:
        if dry_run:
            dry_run_warnings.append("--dry-run is ignored when --job-spec is used")
            dry_run = False
        if wait:
            dry_run_warnings.append("--wait is ignored when --job-spec is used")
    elif dry_run and wait:
        dry_run_warnings.append("--wait is ignored in dry-run mode")

    params_dict = json.loads(params) if params else {}
    tags_list = _merge_job_tags(tags.split(",") if tags else None)
    overrides_dict = json.loads(overrides) if overrides else None
    runner_options_dict = json.loads(runner_options) if runner_options else None

    instance_ids = None
    if instance_id:
        try:
            instance_ids = _select_instance_ids(
                _parse_instance_id_csv(instance_id, "--instance-id"),
                instance_range,
                exclude_instance_ids,
            )
        except ValueError as exc:
            _emit_error(str(exc))
            raise typer.Exit(1)
    elif instance_range or exclude_instance_ids:
        if not dataset:
            _emit_error("--range and --exclude-instance-ids require --instance-id or --dataset")
            raise typer.Exit(1)

    parsed_params_list = None
    if params_list_input:
        raw = params_list_input.strip()
        if raw.startswith("["):
            try:
                parsed_params_list = json.loads(raw)
            except json.JSONDecodeError as e:
                _emit_error(f"failed to parse --params-list JSON: {e}")
                raise typer.Exit(1)
        else:
            try:
                with open(raw, "r", encoding="utf-8") as f:
                    parsed_params_list = json.load(f)
            except json.JSONDecodeError as e:
                _emit_error(f"failed to parse --params-list file as JSON: {e}")
                raise typer.Exit(1)
            except FileNotFoundError:
                _emit_error(f"file not found: {raw}")
                raise typer.Exit(1)
        if not isinstance(parsed_params_list, list):
            _emit_error("--params-list content must be a JSON array")
            raise typer.Exit(1)
        if len(parsed_params_list) == 0:
            _emit_error("--params-list content is an empty array")
            raise typer.Exit(1)

    is_batch = False
    if parsed_params_list:
        is_batch = True
    elif instance_ids and len(instance_ids) > 1:
        is_batch = True
    elif dataset:
        is_batch = True
    elif not instance_id and not dataset and not params:
        _emit_error("must specify -p, or use -i / --dataset / --params-list")
        raise typer.Exit(1)

    # Parse model_base_url_collection (supports JSON array, comma-separated string, or file path)
    model_base_url_collection_list = None
    if model_base_url_collection:
        # Try parsing as JSON array first
        try:
            model_base_url_collection_list = json.loads(model_base_url_collection)
            if not isinstance(model_base_url_collection_list, list):
                print("[red]error: --model-base-url-collection must be a JSON array[/]")
                raise typer.Exit(1)
        except json.JSONDecodeError:
            # Try as comma-separated string
            model_base_url_collection_list = [
                u.strip() for u in model_base_url_collection.split(",") if u.strip()
            ] or None
    
    # Fallback to model_base_url_file
    if not model_base_url_collection_list and model_base_url_file:
        try:
            model_base_url_collection_list = [
                line.strip()
                for line in Path(model_base_url_file).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ] or None
        except FileNotFoundError:
            print(f"[red]error: file not found: {model_base_url_file}[/]")
            raise typer.Exit(1)
    
    # --model-base-url-collection only applies to batch submissions; warn and drop it for single jobs.
    if not is_batch and model_base_url_collection_list:
        warning = "--model-base-url-collection is ignored for single-job submissions"
        if dry_run:
            dry_run_warnings.append(warning)
        else:
            _emit_info(f"warning: {warning}", output_format)
        model_base_url_collection_list = None

    retry_command = (
        _build_job_create_retry_command(
            template=template,
            agenthub_ref=agenthub_ref,
            instance_id=instance_id,
            dataset=dataset,
            instance_range=instance_range,
            exclude_instance_ids=exclude_instance_ids,
            params=params,
            params_list_input=params_list_input,
            suite_name=suite_name,
            group_id=group_id,
            tags=tags,
            overrides=overrides,
            concurrency=concurrency,
            batch_size=batch_size,
            wait=wait,
            wait_interval=wait_interval,
            wait_timeout=wait_timeout,
            output_format=output_format,
            enable_otel_tracing=enable_otel_tracing,
            runner=runner,
            runner_options=runner_options,
            model_base_url_collection=model_base_url_collection,
            model_base_url_file=model_base_url_file,
            idempotency_key=submission_idempotency_key,
        )
        if not dry_run and not job_spec_flag and idempotency_enabled and submission_idempotency_key is not None
        else None
    )
    retry_hint_printed = False

    def emit_retry_hint_once() -> None:
        nonlocal retry_hint_printed
        if retry_hint_printed:
            return
        if retry_command is None:
            return
        _emit_idempotency_retry_hint(retry_command)
        retry_hint_printed = True

    if instance_ids and len(instance_ids) == 1:
        # auto-map instance_id -> task_id
        params_dict = {**params_dict, "instance_id": instance_ids[0], "task_id": instance_ids[0]}

    if is_batch:
        if parsed_params_list:
            # build params_list from --params-list; -p takes precedence over each item
            base = json.loads(params) if params else {}
            params_list = [{**p, **base} for p in parsed_params_list]
        elif instance_ids:
            base = json.loads(params) if params else {}
            params_list = [{**base, "instance_id": iid, "task_id": iid} for iid in instance_ids]
        else:
            _emit_progress(f"Fetching dataset instances: {dataset} ...")
            try:
                instances = client.list_dataset_instances(dataset)
            except Exception:
                emit_retry_hint_once()
                raise
            total = instances.get("total", 0)
            if total == 0:
                typer.secho("error: no instances found", fg="red", err=True)
                emit_retry_hint_once()
                raise typer.Exit(1)
            _emit_progress(f"Found {total} instance(s)")
            try:
                instance_ids = _select_instance_ids(
                    instances.get("instance_ids", []),
                    instance_range,
                    exclude_instance_ids,
                )
            except ValueError as exc:
                _emit_error(str(exc))
                raise typer.Exit(1)
            if (instance_range or exclude_instance_ids) and len(instance_ids) != total:
                message = f"Selected {len(instance_ids)} instance(s)"
                if dry_run:
                    _emit_progress(message)
                else:
                    _emit_info(message, output_format)
            params_list = [
                {**params_dict, "instance_id": iid, "task_id": iid} for iid in instance_ids
            ]

        total_count = len(params_list)

        # Decide the group up front when provided by the caller. Otherwise the
        # first server batch response establishes the group for the submission.
        target_group_id = group_id

        total_submitted = 0
        total_failed = 0
        batch_results: list[dict] = []
        observed_group_id = target_group_id

        def build_batch(start: int) -> list[dict]:
            batch = []
            for offset, item_params in enumerate(params_list[start : start + batch_size]):
                item = dict(item_params)
                if submission_idempotency_key is not None:
                    global_index = start + offset
                    item["__ap_idem_item_key"] = _idempotency_item_key(
                        template=template,
                        params=item_params,
                        global_index=global_index,
                        overrides=overrides_dict,
                        agenthub_revision=client.config.agenthub_ref,
                        enable_otel_tracing=enable_otel_tracing,
                        runner=runner,
                        runner_options=runner_options_dict,
                        model_base_url_collection=model_base_url_collection_list,
                    )
                batch.append(item)
            return batch

        if job_spec_flag:
            payload = client.build_create_job_body(
                template=template,
                params_list=[dict(p) for p in params_list],
                suite_name=suite_name,
                tags=tags_list,
                overrides=overrides_dict,
                max_concurrency=concurrency,
                group_id=target_group_id,
                model_base_url_collection=model_base_url_collection_list,
                enable_otel_tracing=enable_otel_tracing,
                runner=runner,
                runner_options=runner_options_dict,
            )
            _emit_dry_run_warnings(dry_run_warnings)
            _print_formatted(payload, "json" if output_format == "plain" else output_format)
            return

        if dry_run:
            payloads = []
            for start in range(0, total_count, batch_size):
                batch = build_batch(start)
                payloads.append(
                    client.build_create_job_body(
                        template=template,
                        params_list=batch,
                        suite_name=suite_name,
                        tags=tags_list,
                        overrides=overrides_dict,
                        max_concurrency=concurrency,
                        group_id=target_group_id,
                        model_base_url_collection=model_base_url_collection_list,
                        enable_otel_tracing=enable_otel_tracing,
                        runner=runner,
                        runner_options=runner_options_dict,
                        idempotency_key=submission_idempotency_key,
                    )
                )
            _emit_dry_run_warnings(dry_run_warnings)
            _print_job_create_dry_run(
                client,
                payloads,
                timeout=120,
                output_format=output_format,
            )
            return

        try:
            with _job_create_progress() as progress:
                task_id = progress.add_task(
                    "Submitting jobs",
                    total=total_count,
                    current_job=f"group={target_group_id}" if target_group_id else "",
                    current_stage=f"batch_size={batch_size}",
                )
                for batch_index, start in enumerate(range(0, total_count, batch_size)):
                    batch = build_batch(start)
                    batch_end = start + len(batch)
                    progress.update(
                        task_id,
                        current_stage=f"batch {batch_index + 1}: {start + 1}-{batch_end}/{total_count}",
                    )
                    batch_result = client.create_job(
                        template=template,
                        params_list=batch,
                        suite_name=suite_name,
                        tags=tags_list,
                        overrides=overrides_dict,
                        max_concurrency=concurrency,
                        group_id=target_group_id,
                        model_base_url_collection=model_base_url_collection_list,
                        enable_otel_tracing=enable_otel_tracing,
                        runner=runner,
                        runner_options=runner_options_dict,
                        idempotency_key=submission_idempotency_key,
                        timeout=120,
                    )
                    batch_group_id = batch_result.get("group_id")
                    if not observed_group_id and batch_group_id:
                        observed_group_id = batch_group_id
                    server_ack_idempotency = (
                        batch_result.get("idempotency_key") == submission_idempotency_key
                    )
                    if not target_group_id and not server_ack_idempotency and batch_group_id:
                        target_group_id = batch_group_id

                    batch_submitted = int(batch_result.get("submitted") or 0)
                    batch_failed = int(batch_result.get("failed") or 0)
                    total_submitted += batch_submitted
                    total_failed += batch_failed
                    batch_results.append(
                        {
                            "batch": batch_index,
                            "start": start,
                            "end": batch_end,
                            "total": len(batch),
                            "submitted": batch_submitted,
                            "failed": batch_failed,
                        }
                    )
                    progress.update(
                        task_id,
                        completed=batch_end,
                        current_job=f"group={observed_group_id}" if observed_group_id else "",
                        current_stage=f"submitted={total_submitted} failed={total_failed}",
                    )
        except Exception:
            emit_retry_hint_once()
            raise

        result = {
            "group_id": observed_group_id,
            "total": total_count,
            "submitted": total_submitted,
            "failed": total_failed,
            "batches": batch_results,
        }
        if submission_idempotency_key is not None:
            result["idempotency_key"] = submission_idempotency_key
        if output_format == "plain":
            print("[green]Batch jobs submitted:[/]")
            print(f"  group_id: {result.get('group_id')}")
            if submission_idempotency_key is not None:
                print(f"  idempotency_key: {result.get('idempotency_key')}")
            print(f"  total: {result.get('total')}")
            print(f"  submitted: {result.get('submitted')}")
            print(f"  failed: {result.get('failed')}")
    else:
        if job_spec_flag:
            payload = client.build_create_job_body(
                template=template,
                params=params_dict,
                suite_name=suite_name,
                tags=tags_list,
                overrides=overrides_dict,
                group_id=group_id,
                enable_otel_tracing=enable_otel_tracing,
                runner=runner,
                runner_options=runner_options_dict,
            )
            _emit_dry_run_warnings(dry_run_warnings)
            _print_formatted(payload, "json" if output_format == "plain" else output_format)
            return

        if dry_run:
            payload = client.build_create_job_body(
                template=template,
                params=params_dict,
                suite_name=suite_name,
                tags=tags_list,
                overrides=overrides_dict,
                group_id=group_id,
                enable_otel_tracing=enable_otel_tracing,
                runner=runner,
                runner_options=runner_options_dict,
                idempotency_key=submission_idempotency_key
            )
            _emit_dry_run_warnings(dry_run_warnings)
            _print_job_create_dry_run(
                client,
                [payload],
                timeout=30,
                output_format=output_format,
            )
            return

        try:
            with _job_create_progress() as progress:
                task_id = progress.add_task(
                    "Submitting job",
                    total=1,
                    current_job="",
                    current_stage="submitting",
                )
                result = client.create_job(
                    template=template,
                    params=params_dict,
                    suite_name=suite_name,
                    tags=tags_list,
                    overrides=overrides_dict,
                    group_id=group_id,
                    enable_otel_tracing=enable_otel_tracing,
                    runner=runner,
                    runner_options=runner_options_dict,
                    idempotency_key=submission_idempotency_key,
                )
                jobs = result.get("jobs", [])
                if not jobs:
                    progress.update(task_id, completed=1, current_stage="submitted=0 failed=1")
                else:
                    job = jobs[0]
                    failed = 1 if job.get("status") == "Failed" else 0
                    submitted = 0 if failed else 1
                    progress.update(
                        task_id,
                        completed=1,
                        current_job=f"job={job.get('job_id')}" if job.get("job_id") else "",
                        current_stage=f"submitted={submitted} failed={failed}",
                    )
        except Exception:
            emit_retry_hint_once()
            raise
        jobs = result.get("jobs", [])
        if not jobs:
            typer.secho("错误: 任务提交失败", fg="red", err=True)
            for err in result.get("errors", []):
                typer.echo(
                    f"  [{err.get('index')}] {err.get('instance_id')}: {err.get('error')}",
                    err=True,
                )
            emit_retry_hint_once()
            raise typer.Exit(1)

        if submission_idempotency_key is not None and not result.get("idempotency_key"):
            result["idempotency_key"] = submission_idempotency_key

        job = jobs[0]
        if output_format == "plain":
            print("[green]任务已提交:[/]")
            print(f"  job_id: {job.get('job_id')}")
            print(f"  status: {job.get('status')}")
            if submission_idempotency_key is not None:
                print(
                    f"  idempotency_key: {result.get('idempotency_key') or submission_idempotency_key}"
                )
            if result.get("group_id"):
                print(f"  group_id: {result.get('group_id')}")

    if wait:
        try:
            group_id = result.get("group_id")
            if group_id:
                _emit_progress(
                    f"Waiting for group to finish: {group_id} "
                    f"(interval={wait_interval}s, timeout={_format_wait_timeout(wait_timeout)})"
                )
                final_group = wait_for_group(
                    client,
                    group_id,
                    wait_interval,
                    timeout=wait_timeout,
                    printer=wait_printer,
                )
                wait_result = {
                    "type": "group",
                    "interval": wait_interval,
                    "timeout": wait_timeout,
                    "result": final_group,
                }
                if output_format == "plain":
                    stats = final_group.get("stats") or {}
                    print(f"[green]Group finished:[/] {group_id}")
                    print(f"  total: {stats.get('total', 0)}")
                    print(f"  succeeded: {stats.get('succeeded', 0)}")
                    print(f"  failed: {stats.get('failed', 0)}")
                    print(f"  cancelled: {stats.get('cancelled', 0)}")
            else:
                job = result.get("jobs", [{}])[0]
                job_id = job.get("job_id")
                _emit_progress(
                    f"Waiting for job to finish: {job_id} "
                    f"(interval={wait_interval}s, timeout={_format_wait_timeout(wait_timeout)})"
                )
                final_job = wait_for_job(
                    client,
                    job_id,
                    wait_interval,
                    timeout=wait_timeout,
                    printer=wait_printer,
                )
                wait_result = {
                    "type": "job",
                    "interval": wait_interval,
                    "timeout": wait_timeout,
                    "result": final_job,
                }
                if output_format == "plain":
                    print(f"[green]Job finished:[/] {job_id}")
                    print(f"  status: {final_job.get('status')}")
                    if final_job.get("failed_reason"):
                        print(f"  failed_reason: {final_job.get('failed_reason')}")
        except WaitTimeoutError as exc:
            emit_retry_hint_once()
            typer.echo(f"error: {exc}", err=True)
            raise typer.Exit(1)
    if output_format != "plain":
        payload = {"submission": result}
        if wait_result is not None:
            payload["wait"] = wait_result
        _print_formatted(payload, output_format)


@job_app.command("get")
def job_get(job_id: str = typer.Argument(..., help="Job ID")):
    """Show job status."""
    client = get_client()
    result = client.get_job(job_id)
    _print_json(result)


@job_app.command("containers")
def job_containers(job_id: str = typer.Argument(..., help="Job ID")):
    """List container names for a job."""
    client = get_client()
    result = client.get_job_containers(job_id)
    _print_json(result)


def _format_log_line(entry) -> str:
    """Render a single log entry from the logs API."""
    if isinstance(entry, dict):
        return entry.get("timestamp", "") + "  | " + entry.get("content", "")
    return str(entry)


def _fetch_job_logs_for_tail(client, job_id: str, container: Optional[str]):
    """Fetch all paginated logs so --tail can truncate locally."""
    all_logs = []
    offset = 0
    page_size = 1000

    while True:
        result = client.get_job_logs(
            job_id=job_id,
            container=container,
            offset=offset,
            limit=page_size,
        )
        logs = result.get("logs", [])
        if isinstance(logs, list):
            all_logs.extend(logs)
        else:
            return logs

        next_offset = result.get("next_offset")
        if next_offset is None or next_offset <= offset:
            break
        offset = next_offset

    return all_logs


def _print_tail_logs(logs, tail: int) -> None:
    """Print the last N log entries returned by the CLI-side tail fallback."""
    if isinstance(logs, list):
        for log_line in logs[-tail:]:
            print(_format_log_line(log_line))
        return

    if isinstance(logs, str):
        lines = logs.splitlines()
        selected = lines[-tail:]
        if selected:
            print("\n".join(selected))
        return

    print(logs)


@job_app.command("logs")
def job_logs(
    job_id: str = typer.Argument(..., help="Job ID"),
    container: Optional[str] = typer.Option("main", "--container", "-c", help="Container name"),
    tail: Optional[int] = typer.Option(None, "--tail", "-n", help="Show only the last N log lines"),
    follow: bool = typer.Option(False, "--follow", "-f", is_flag=True, help="Follow logs until the job finishes"),
    offset: Optional[int] = typer.Option(0, "--offset", "-o", help="Starting log line offset"),
    limit: Optional[int] = typer.Option(1000, "--limit", "-l", help="Number of log lines to request"),
):
    """Show job logs."""
    client = get_client()

    if tail is not None:
        if tail <= 0:
            raise typer.BadParameter("--tail must be >= 1")
        if follow:
            raise typer.BadParameter("--tail cannot be used with --follow")
        logs = _fetch_job_logs_for_tail(client, job_id, container=container)
        _print_tail_logs(logs, tail)
        return

    if follow:
        # Poll logs until no next offset is returned.
        import time

        offset = 0

        while True:
            result = client.get_job_logs(
                job_id=job_id,
                container=container,
                offset=offset,
                limit=1000,
            )

            logs = result.get("logs", [])
            if isinstance(logs, list):
                for log_line in logs:
                    print(_format_log_line(log_line))
            else:
                print(logs)

            next_offset = result.get("next_offset")
            if next_offset is not None:
                offset = next_offset
            else:
                break

            time.sleep(1)
    else:
        result = client.get_job_logs(
            job_id=job_id,
            container=container,
            offset=offset,
            limit=limit,
        )

        print(f"[{result.get('job_id')}] - Container: {result.get('container', 'all')}")
        print(
            f"Offset: {result.get('offset', offset)}, Next Offset: {result.get('next_offset')}, Limit: {result.get('limit', limit)}"
        )
        print("=" * 50)

        logs = result.get("logs", [])
        if isinstance(logs, list):
            for log_line in logs:
                print(_format_log_line(log_line))
        else:
            print(logs)


@job_app.command("events")
def job_events(
    job_id: str = typer.Argument(..., help="Job ID"),
    container: Optional[str] = typer.Option(None, "--container", "-c", help="Container name"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """Show job events."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.get_job_events(job_id, container=container)
    if output_format == "plain":
        _print_job_events_plain(result)
    else:
        _print_formatted(result, output_format)


@job_app.command("metrics")
def job_metrics(
    job_id: str = typer.Argument(..., help="Job ID"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """Show job metrics."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.get_job_metrics(job_id)
    if output_format == "plain":
        _print_json(result)
    else:
        _print_formatted(result, output_format)


@job_app.command("cancel")
def job_cancel(job_id: str = typer.Argument(..., help="Job ID")):
    """Cancel a job."""
    client = get_client()
    result = client.cancel_job(job_id)
    print(f"[green]Cancelled:[/] {result.get('job_id')}")
    print(f"  status: {result.get('status')}")
    if result.get("failed_reason"):
        print(f"  failed_reason: {result.get('failed_reason')}")


@job_app.command("artifacts")
def job_artifacts(
    job_ids: str = typer.Argument(..., help="Job IDs (comma-separated for multiple)"),
):
    """Show job artifact download links."""
    client = get_client()
    ids = [jid.strip() for jid in job_ids.split(",")]
    results = client.get_job_artifacts(ids)
    _print_json(results)


@job_app.command("export")
def job_export(
    job_id: str = typer.Argument(..., help="Job ID"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Export directory"),
):
    """Export job artifacts/logs/events to a local directory."""
    client = get_client()
    dest = export_job(client, job_id, output)
    print(f"[green]Job exported:[/] {job_id}")
    print(f"  path: {dest}")


@job_app.command("wait")
def job_wait(
    job_id: str = typer.Argument(..., help="Job ID"),
    interval: float = typer.Option(
        5.0, "--interval", "-i", min=0.1, help="Polling interval (seconds)"
    ),
    timeout: Optional[float] = typer.Option(
        None,
        "--timeout",
        "--wait-timeout",
        min=0.0,
        help="Maximum seconds to wait; omit to wait indefinitely",
    ),
):
    """Poll until the job finishes."""
    client = get_client()
    try:
        result = wait_for_job(client, job_id, interval, timeout=timeout)
    except WaitTimeoutError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(1)
    print(f"[green]Job finished:[/] {job_id}")
    print(f"  status: {result.get('status')}")
    if result.get("failed_reason"):
        print(f"  failed_reason: {result.get('failed_reason')}")


# ==================== Group operations ====================


@group_app.command("create")
def group_create(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Group name"),
    max_concurrency: Optional[int] = typer.Option(
        None,
        "--max-concurrency",
        "-c",
        min=1,
        help="Maximum concurrent jobs. Server default: 50.",
    ),
    eval_config: Optional[str] = typer.Option(
        None, "--eval-config", help="Evaluation config (JSON)"
    ),
    model_base_url_collection: Optional[str] = typer.Option(
        None,
        "--model-base-url-collection",
        help="Model base URL collection for server-side load balancing (JSON array or comma-separated)",
    ),
    model_base_url_file: Optional[str] = typer.Option(
        None,
        "--model-base-url-file",
        help="File path containing model base URL list (one URL per line), fallback for --model-base-url-collection",
    ),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """Create a Group."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    eval_config_dict = json.loads(eval_config) if eval_config else None
    
    # Parse model_base_url_collection (supports JSON array or comma-separated string)
    model_base_url_collection_list = None
    if model_base_url_collection:
        try:
            model_base_url_collection_list = json.loads(model_base_url_collection)
            if not isinstance(model_base_url_collection_list, list):
                print("[red]error: --model-base-url-collection must be a JSON array[/]")
                raise typer.Exit(1)
        except json.JSONDecodeError:
            # Try as comma-separated string
            model_base_url_collection_list = [
                u.strip() for u in model_base_url_collection.split(",") if u.strip()
            ] or None
    
    # Fallback to model_base_url_file
    if not model_base_url_collection_list and model_base_url_file:
        try:
            model_base_url_collection_list = [
                line.strip()
                for line in Path(model_base_url_file).read_text(encoding="utf-8").splitlines()
                if line.strip()
            ] or None
        except FileNotFoundError:
            print(f"[red]error: file not found: {model_base_url_file}[/]")
            raise typer.Exit(1)
    
    result = client.create_group(
        name=name,
        max_concurrency=max_concurrency,
        eval_config=eval_config_dict,
        model_base_url_collection=model_base_url_collection_list,
    )
    if output_format == "plain":
        print("[green]Group created:[/]")
        print(f"  group_id: {result.get('group_id')}")
        print(f"  name: {result.get('name')}")
        print(f"  max_concurrency: {result.get('max_concurrency')}")
        print(f"  strict: {result.get('strict')}")
        if result.get("eval_config") is not None:
            print(f"  eval_config: {json.dumps(result.get('eval_config'), ensure_ascii=False)}")
        if result.get("model_base_url_collection") is not None:
            print(
                "  model_base_url_collection: "
                f"{json.dumps(result.get('model_base_url_collection'), ensure_ascii=False)}"
            )
        return
    _print_formatted(result, output_format)


@group_app.command("list")
def group_list(
    skip: int = typer.Option(0, "--skip", help="Skip the first N entries"),
    limit: int = typer.Option(100, "--limit", help="Maximum number of entries to return"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """List Groups."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.list_groups(skip=skip, limit=limit)
    if output_format == "plain":
        _print_group_list_plain(result)
    else:
        _print_formatted(result, output_format)


@group_app.command("get")
def group_get(group_id: str = typer.Argument(..., help="Group ID")):
    """Show Group details."""
    client = get_client()
    result = client.get_group(group_id)
    _print_json(result)


@group_app.command("jobs")
def group_jobs(
    group_id: str = typer.Argument(..., help="Group ID"),
    tag: Optional[list[str]] = typer.Option(
        None, "--tag", help="Filter by tag (repeatable; multiple tags are combined with AND)"
    ),
    skip: int = typer.Option(0, "--skip", help="Skip the first N entries"),
    limit: int = typer.Option(100, "--limit", help="Maximum number of entries to return"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """List jobs in a Group."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.list_group_jobs(group_id, tag=tag, skip=skip, limit=limit)
    if output_format == "plain":
        _print_job_list_plain(result)
    else:
        _print_formatted(result, output_format)


@group_app.command("stats")
def group_stats(group_id: str = typer.Argument(..., help="Group ID")):
    """Show Group progress."""
    client = get_client()
    result = client.get_group_stats(group_id)
    _print_json(result)


@group_app.command("eval")
def group_eval(
    group_id: str = typer.Argument(..., help="Group ID"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """Show Group aggregated evaluation results."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.get_group_eval(group_id)
    if output_format == "plain":
        _print_group_eval_plain(result)
    else:
        _print_formatted(result, output_format)


@group_app.command("artifacts")
def group_artifacts(group_id: str = typer.Argument(..., help="Group ID")):
    """Show Group artifact download links."""
    client = get_client()
    result = client.get_group_artifacts(group_id)
    _print_json(result)


@group_app.command("cancel")
def group_cancel(
    group_id: str = typer.Argument(..., help="Group ID"),
):
    """Cancel all unfinished jobs under a Group."""
    client = get_client()
    result = client.cancel_group(group_id)
    actual_group_id = result.get("group_id") or group_id
    print(f"[green]Group cancel completed:[/] {actual_group_id}")
    print(f"  cancelled: {result.get('cancelled', 0)}")
    print(f"  k8s_deleted: {result.get('k8s_deleted', False)}")
    k8s_errors = result.get("k8s_errors") or []
    if k8s_errors:
        print("  k8s_errors:")
        for err in k8s_errors:
            print(f"    - {err}")


@group_app.command("export")
def group_export(
    group_id: str = typer.Argument(..., help="Group ID"),
    output: Optional[Path] = typer.Option(None, "--output", "-o", help="Export directory"),
    workers: int = typer.Option(
        4, "--workers", "-w", min=1, help="Number of concurrent export workers"
    ),
):
    """Export artifacts/logs/events of all jobs under a Group to a local directory."""
    client = get_client()
    from rich.progress import BarColumn, Progress, TaskProgressColumn, TextColumn

    with Progress(
        TextColumn("{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TextColumn("{task.fields[current_job]}"),
        TextColumn("{task.fields[current_stage]}"),
        transient=True,
    ) as progress:
        task_id = progress.add_task(
            "Exporting group",
            total=0,
            current_job="",
            current_stage="",
        )

        def _on_progress(done: int, total: int, job_id: str, stage: str) -> None:
            current_job = f"job={job_id}" if job_id else ""
            current_stage = f"stage={stage}" if stage else ""
            progress.update(
                task_id,
                total=total,
                completed=done,
                current_job=current_job,
                current_stage=current_stage,
            )

        dest = export_group(
            client,
            group_id,
            output,
            progress_callback=_on_progress,
            workers=workers,
        )
    print(f"[green]Group exported:[/] {group_id}")
    print(f"  path: {dest}")


@group_app.command("wait")
def group_wait(
    group_id: str = typer.Argument(..., help="Group ID"),
    interval: float = typer.Option(
        5.0, "--interval", "-i", min=0.1, help="Polling interval (seconds)"
    ),
    timeout: Optional[float] = typer.Option(
        None,
        "--timeout",
        "--wait-timeout",
        min=0.0,
        help="Maximum seconds to wait; omit to wait indefinitely",
    ),
):
    """Poll until all jobs under a Group finish."""
    client = get_client()
    try:
        result = wait_for_group(client, group_id, interval, timeout=timeout)
    except WaitTimeoutError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise typer.Exit(1)
    stats = result.get("stats") or {}
    print(f"[green]Group finished:[/] {group_id}")
    print(f"  total: {stats.get('total', 0)}")
    print(f"  succeeded: {stats.get('succeeded', 0)}")
    print(f"  failed: {stats.get('failed', 0)}")
    print(f"  cancelled: {stats.get('cancelled', 0)}")


def main() -> None:
    try:
        app()
    except APIError as exc:
        typer.echo(_format_api_error(exc), err=True)
        raise SystemExit(1) from None
    except ConfigurationError as exc:
        typer.echo(f"error: {exc}", err=True)
        raise SystemExit(1) from None


def _format_api_error(exc: APIError) -> str:
    if str(exc.detail) != _NON_JSON_RESPONSE_DETAIL:
        return f"error: {exc}"

    status = exc.status_code if exc.status_code is not None else "<unknown>"
    lines = [
        f"error: API Error {status}: {exc.detail}",
        f"hint: {_NON_JSON_RESPONSE_HINT}",
        f"request_id: {exc.request_id}",
    ]
    if exc.response is not None:
        content_type = exc.response.headers.get("Content-Type") or "<missing>"
        lines.extend(
            [
                "response:",
                f"  status: {exc.response.status_code}",
                f"  content_type: {content_type}",
            ]
        )
        preview = _format_response_preview(exc.response.content or b"", content_type)
        if preview:
            lines.append(f"  preview: {preview}")
    return "\n".join(lines)


def _format_response_preview(raw: bytes, content_type: str) -> str:
    if not raw:
        return ""
    text = raw.decode("utf-8", errors="replace").strip()
    if _looks_like_html_response(text, content_type):
        return "HTML document returned; run with --verbose to inspect the response body."
    return _truncate_cli_text(" ".join(text.split()), 200)


def _looks_like_html_response(text: str, content_type: str) -> bool:
    stripped = text.lstrip().lower()
    return (
        "html" in content_type.lower()
        or stripped.startswith("<!doctype html")
        or stripped.startswith("<html")
    )


def _truncate_cli_text(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"...<truncated {len(text) - limit} chars>"


# ==================== Eval Plan operations ====================


def _print_plan_list_plain(result: dict) -> None:
    _print_plain_table(
        result.get("items", []),
        [
            ("plan_id", "plan_id"),
            ("name", "name"),
            ("status", "status"),
            ("cron_expression", "cron_expression"),
            ("run_count", "run_count"),
            ("next_run_at", "next_run_at"),
            ("created_at", "created_at"),
        ],
    )


def _print_plan_plain(data: dict) -> None:
    print(f"  plan_id:         {data.get('plan_id')}")
    print(f"  name:            {data.get('name')}")
    print(f"  description:     {data.get('description') or ''}")
    print(f"  status:          {data.get('status')}")
    print(f"  cron_expression: {data.get('cron_expression')}")
    print(f"  valid_from:      {data.get('valid_from')}")
    print(f"  valid_until:     {data.get('valid_until')}")
    print(f"  run_count:       {data.get('run_count')}")
    print(f"  next_run_at:     {data.get('next_run_at')}")
    print(f"  last_run_at:     {data.get('last_run_at')}")
    job_spec = data.get("job_spec", {})
    if job_spec:
        print(f"  job_spec.template: {job_spec.get('template')}")
        params = job_spec.get("params")
        if params:
            print(f"  job_spec.params:   {json.dumps(params, ensure_ascii=False)}")


@plan_app.command("create")
def plan_create(
    job_spec: str = typer.Option(
        ..., "--job-spec", help="Job spec JSON (e.g. output of 'ap job create --job-spec')"
    ),
    name: str = typer.Option(..., "--name", "-n", help="Plan name"),
    cron_expression: str = typer.Option(..., "--cron", help="Cron expression (e.g. '0 8 * * *')"),
    valid_from: str = typer.Option(..., "--valid-from", help="Valid from (ISO datetime, e.g. 2026-01-01)"),
    valid_until: str = typer.Option(..., "--valid-until", help="Valid until (ISO datetime, e.g. 2026-12-31)"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Plan description"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """Create an eval plan.

    Examples:
        # Build job spec, then create plan
        ap job create claw-eval-task -p '{"model":"qwen-max"}' --job-spec > spec.json
        ap plan create --job-spec spec.json -n daily-eval --cron '0 8 * * *' --valid-from 2026-01-01 --valid-until 2027-01-01

        # Inline job spec JSON
        ap plan create --job-spec '{"template":"claw-eval-task","params":{"model":"qwen-max"}}' -n daily-eval --cron '0 8 * * *' --valid-from 2026-01-01 --valid-until 2027-01-01
    """
    output_format = _normalize_output_format(output_format)
    client = get_client()

    # --job-spec: try inline JSON first, fall back to file path
    raw = job_spec.strip()
    try:
        job_spec_dict = json.loads(raw)
    except json.JSONDecodeError:
        try:
            with open(raw, "r", encoding="utf-8") as f:
                job_spec_dict = json.load(f)
        except json.JSONDecodeError as e:
            print(f"[red]error: failed to parse --job-spec file as JSON: {e}[/]")
            raise typer.Exit(1)
        except FileNotFoundError:
            print(f"[red]error: file not found: {raw}[/]")
            raise typer.Exit(1)

    result = client.create_eval_plan(
        name=name,
        job_spec=job_spec_dict,
        cron_expression=cron_expression,
        valid_from=valid_from,
        valid_until=valid_until,
        description=description,
    )
    if output_format == "plain":
        print("[green]Eval plan created:[/]")
        _print_plan_plain(result)
    else:
        _print_formatted(result, output_format)


@plan_app.command("list")
def plan_list(
    status: Optional[str] = typer.Option(None, "--status", help="Filter by status (Active/Paused)"),
    user_id: Optional[str] = typer.Option(None, "--user-id", help="Filter by user ID"),
    created_after: Optional[str] = typer.Option(None, "--created-after", help="Filter by created_at >= (ISO datetime)"),
    created_before: Optional[str] = typer.Option(None, "--created-before", help="Filter by created_at <= (ISO datetime)"),
    skip: int = typer.Option(0, "--skip", help="Skip the first N entries"),
    limit: int = typer.Option(-1, "--limit", help="Maximum number of entries (-1 for all)"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """List eval plans."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.list_eval_plans(
        status=status,
        user_id=user_id,
        created_after=created_after,
        created_before=created_before,
        skip=skip,
        limit=limit,
    )
    if output_format == "plain":
        _print_plan_list_plain(result)
    else:
        _print_formatted(result, output_format)


@plan_app.command("get")
def plan_get(
    plan_id: str = typer.Argument(..., help="Plan ID"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """Get eval plan detail."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.get_eval_plan(plan_id)
    if output_format == "plain":
        _print_plan_plain(result)
    else:
        _print_formatted(result, output_format)


@plan_app.command("update")
def plan_update(
    plan_id: str = typer.Argument(..., help="Plan ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Plan name"),
    job_spec: Optional[str] = typer.Option(
        None, "--job-spec", help="Job spec JSON (e.g. output of 'ap job create --job-spec')"
    ),
    cron_expression: Optional[str] = typer.Option(None, "--cron", help="Cron expression"),
    valid_from: Optional[str] = typer.Option(None, "--valid-from", help="Valid from (ISO datetime)"),
    valid_until: Optional[str] = typer.Option(None, "--valid-until", help="Valid until (ISO datetime)"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Plan description"),
    status: Optional[str] = typer.Option(None, "--status", help="Set status (Active/Paused)"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """Update an eval plan.

    All fields are optional — only provided fields are updated.

    Examples:
        # Pause a plan
        ap plan update <PLAN_ID> --status Paused

        # Update cron only
        ap plan update <PLAN_ID> --cron '0 10 * * 1-5'

        # Update job spec
        ap plan update <PLAN_ID> --job-spec "$(ap job create claw-eval-task -p '{\"model\":\"qwen-max\"}' --job-spec)"
    """
    output_format = _normalize_output_format(output_format)
    client = get_client()

    # Parse --job-spec if provided (inline JSON or file path)
    job_spec_dict = None
    if job_spec is not None:
        raw = job_spec.strip()
        try:
            job_spec_dict = json.loads(raw)
        except json.JSONDecodeError:
            try:
                with open(raw, "r", encoding="utf-8") as f:
                    job_spec_dict = json.load(f)
            except json.JSONDecodeError as e:
                print(f"[red]error: failed to parse --job-spec file as JSON: {e}[/]")
                raise typer.Exit(1)
            except FileNotFoundError:
                print(f"[red]error: file not found: {raw}[/]")
                raise typer.Exit(1)

    result = client.update_eval_plan(
        plan_id=plan_id,
        name=name,
        job_spec=job_spec_dict,
        cron_expression=cron_expression,
        valid_from=valid_from,
        valid_until=valid_until,
        description=description,
        status=status,
    )
    if output_format == "plain":
        print("[green]Eval plan updated:[/]")
        _print_plan_plain(result)
    else:
        _print_formatted(result, output_format)


@plan_app.command("delete")
def plan_delete(
    plan_ids: List[str] = typer.Argument(..., help="One or more plan IDs"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """Permanently delete one or more eval plans from MongoDB.

    Examples:
        ap plan delete plan-abc
        ap plan delete plan-abc plan-def plan-ghi
        ap plan delete plan-abc -y
    """
    if not yes:
        ids_str = ", ".join(plan_ids)
        typer.confirm(f"Permanently delete {len(plan_ids)} plan(s): {ids_str}?", abort=True)
    client = get_client()
    failed = []
    for pid in plan_ids:
        try:
            result = client.delete_eval_plan(pid)
        except APIError as e:
            if e.status_code == 404:
                print(f"[yellow]Plan not found, skipping:[/] {pid}")
                failed.append(pid)
                continue
            raise
        print(f"[green]Eval plan permanently deleted:[/] {result.get('plan_id')}")
    if failed:
        raise typer.Exit(1)


@plan_app.command("trigger")
def plan_trigger(
    plan_id: str = typer.Argument(..., help="Plan ID"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """Manually trigger an eval plan (creates Group + Jobs)."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.trigger_eval_plan(plan_id)
    if output_format == "plain":
        print("[green]Eval plan triggered:[/]")
        print(f"  plan_id:   {result.get('plan_id')}")
        print(f"  run_count: {result.get('run_count')}")
        run = result.get("run", {})
        if run:
            print(f"  run.type:  {run.get('type')}")
            print(f"  run.id:    {run.get('id')}")
        trigger_result = result.get("result", {})
        if trigger_result:
            group_id = trigger_result.get("group_id")
            submitted = trigger_result.get("submitted")
            if group_id:
                print(f"  group_id:  {group_id}")
            if submitted is not None:
                print(f"  submitted: {submitted}")
    else:
        _print_formatted(result, output_format)


@plan_app.command("runs")
def plan_runs(
    plan_id: str = typer.Argument(..., help="Plan ID"),
    skip: int = typer.Option(0, "--skip", help="Skip the first N entries"),
    limit: int = typer.Option(-1, "--limit", help="Maximum number of entries (-1 for all)"),
    output_format: str = typer.Option("plain", "--format", help="Output format: plain/json/yaml"),
):
    """List historical runs for an eval plan."""
    output_format = _normalize_output_format(output_format)
    client = get_client()
    result = client.list_eval_plan_runs(plan_id, skip=skip, limit=limit)
    if output_format == "plain":
        items = result.get("items", [])
        if not items:
            print("No runs found.")
        else:
            _print_plain_table(
                items,
                [
                    ("type", "type"),
                    ("id", "id"),
                    ("name", "name"),
                    ("job_count", "job_count"),
                    ("triggered_at", "triggered_at"),
                ],
            )
    else:
        _print_formatted(result, output_format)


if __name__ == "__main__":
    main()
