"""API client."""

import json
import platform
import re
import sys
import time
import uuid
from typing import Any, Optional
from urllib.parse import parse_qsl, quote, urlencode, urlsplit, urlunsplit

import requests

from .config import Config, ConfigurationError, get_config, has_cluster_header

_GROUP_ARTIFACTS_PAGE_SIZE = 500
_VERBOSE_SAMPLE_KEYS = 5
_VERBOSE_SAMPLE_ITEMS = 3
_VERBOSE_VALUE_PREVIEW = 120


class APIError(Exception):
    """Raised when an API request fails."""

    def __init__(
        self,
        status_code: Optional[int],
        detail: Any,
        request_id: str,
        response: Optional[requests.Response],
    ):
        self.status_code = status_code
        self.detail = detail
        self.request_id = request_id
        self.response = response
        super().__init__(self._build_message())

    def _build_message(self) -> str:
        if self.status_code is None:
            return f"API Network Error: {self.detail} (request_id={self.request_id})"
        return f"API Error {self.status_code}: {self.detail} (request_id={self.request_id})"


class APIClient:
    """Agent Platform API client."""

    def __init__(self, config: Config):
        self.config = config
        self.session = requests.Session()
        headers = dict(config.headers)
        user_agent = _build_user_agent(headers.get("User-Agent"))
        headers["User-Agent"] = user_agent

        # 认证 header: resolved CLI API key -> X-API-Key
        if config.token_key:
            headers["X-API-Key"] = config.token_key

        self.session.headers.update(
            {
                "Content-Type": "application/json",
                **headers,
            }
        )

    def _url(self, path: str) -> str:
        """Build the full URL."""
        if (
            path.startswith("/")
            and "/api" not in self.config.base_url
            and "nlb-" not in self.config.base_url
            and "localhost" not in self.config.base_url
        ):
            return f"{self.config.base_url}/api{path}"
        return f"{self.config.base_url}{path}"

    def preview_request_headers(self) -> dict:
        """Return redacted headers that would be sent with a request."""
        headers = dict(self.session.headers)
        headers["X-Request-ID"] = "<generated per HTTP request>"
        return _redact_headers(headers, self.config.verbose_redaction)

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict] = None,
        json_body: Any = None,
        timeout: float = 30,
    ) -> Any:
        """Send an HTTP request with X-Request-ID and optional verbose logging."""
        self._require_cluster_config()
        url = self._url(path)
        request_id = str(uuid.uuid4())
        headers = {"X-Request-ID": request_id}
        verbose = self.config.verbose
        if verbose:
            request_headers = dict(self.session.headers)
            request_headers.update(headers)
            self._log_request(method, url, request_id, request_headers, params, json_body)
        start = time.perf_counter()
        try:
            resp = self.session.request(
                method,
                url,
                params=params,
                json=json_body,
                headers=headers,
                timeout=timeout,
            )
        except requests.RequestException as exc:
            if verbose:
                duration_ms = (time.perf_counter() - start) * 1000
                self._log_exception(method, url, request_id, duration_ms, exc)
            raise APIError(None, str(exc), request_id, None) from exc
        duration_ms = (time.perf_counter() - start) * 1000
        if verbose:
            self._log_response(method, url, request_id, resp, duration_ms)
        if not resp.ok:
            detail = _response_error_detail(resp)
            raise APIError(resp.status_code, detail, request_id, resp)
        if not resp.content:
            return None
        try:
            return resp.json()
        except ValueError as exc:
            detail = _unexpected_non_json_response_detail(resp)
            raise APIError(resp.status_code, detail, request_id, resp) from exc

    def _require_cluster_config(self) -> None:
        if has_cluster_header(self.config.headers):
            return
        raise ConfigurationError(
            "Missing cluster configuration. Set AP_CLUSTER (e.g. export AP_CLUSTER=test) "
            "or include a non-empty X-Cluster in AP_HEADERS (e.g. export AP_HEADERS='X-Cluster: test')."
        )

    def _get(self, path: str, params: Optional[dict] = None) -> Any:
        """Send a GET request."""
        return self._request("GET", path, params=params)

    def _post(self, path: str, data: Any, timeout: float = 30) -> Any:
        """Send a POST request."""
        return self._request("POST", path, json_body=data, timeout=timeout)

    def _delete(self, path: str, *, params: Optional[dict] = None) -> Any:
        """Send a DELETE request."""
        return self._request("DELETE", path, params=params)

    # ==================== Verbose logging ====================

    def _log_request(
        self,
        method: str,
        url: str,
        request_id: str,
        headers: dict,
        params: Optional[dict],
        body: Any,
    ) -> None:
        lines = [
            f">> Request {method} {url}",
            f"   request_id={request_id}",
            f"   headers={_safe_json(_redact_headers(headers, self.config.verbose_redaction))}",
        ]
        if params:
            log_params = _redact_sensitive_data(params, self.config.verbose_redaction)
            lines.append(f"   params={_safe_json(log_params)}")
        if body is not None:
            encoded = _safe_json(body).encode("utf-8", errors="replace")
            log_body = _redact_sensitive_data(body, self.config.verbose_redaction)
            log_encoded = _safe_json(log_body).encode("utf-8", errors="replace")
            lines.append(f"   body_size={len(encoded)}")
            preview = self._summarize_body(log_body, encoded, log_encoded)
            if preview:
                lines.append(f"   body={preview}")
        _write_stderr(lines)

    def _log_response(
        self,
        method: str,
        url: str,
        request_id: str,
        resp: requests.Response,
        duration_ms: float,
    ) -> None:
        raw = resp.content or b""
        lines = [
            f"<< Response {method} {url}",
            f"   request_id={request_id}",
            f"   status={resp.status_code}",
            f"   duration_ms={duration_ms:.1f}",
            f"   headers={_safe_json(_redact_headers(dict(resp.headers), self.config.verbose_redaction))}",
            f"   body_size={len(raw)}",
        ]
        preview = self._summarize_response(resp, raw)
        if preview:
            lines.append(f"   body={preview}")
        _write_stderr(lines)

    def _log_exception(
        self,
        method: str,
        url: str,
        request_id: str,
        duration_ms: float,
        exc: Exception,
    ) -> None:
        _write_stderr(
            [
                f"!! Error {method} {url}",
                f"   request_id={request_id}",
                f"   duration_ms={duration_ms:.1f}",
                f"   error={type(exc).__name__}: {exc}",
            ]
        )

    def _summarize_body(self, body: Any, encoded: bytes, log_encoded: bytes | None = None) -> str:
        preview_encoded = log_encoded if log_encoded is not None else encoded
        if self.config.verbose_full_body:
            return preview_encoded.decode("utf-8", errors="replace")
        limit = self.config.verbose_body_limit
        if len(encoded) <= limit:
            return preview_encoded.decode("utf-8", errors="replace")
        return _summarize_json_value(body, limit)

    def _summarize_response(self, resp: requests.Response, raw: bytes) -> str:
        if not raw:
            return ""
        content_type = (resp.headers.get("Content-Type") or "").lower()
        if self.config.verbose_full_body:
            if self.config.verbose_redaction and "json" in content_type:
                try:
                    return _safe_json(_redact_sensitive_data(resp.json(), True))
                except Exception:
                    pass
            return _safe_decode(raw)
        limit = self.config.verbose_body_limit
        if "json" in content_type:
            try:
                data = resp.json()
            except Exception:
                return _truncate_text(_safe_decode(raw), limit)
            data = _redact_sensitive_data(data, self.config.verbose_redaction)
            encoded = _safe_json(data)
            if len(encoded.encode("utf-8", errors="replace")) <= limit:
                return encoded
            return _summarize_json_value(data, limit)
        return _truncate_text(_safe_decode(raw), limit)

    # ==================== Template operations ====================

    def list_templates(self) -> list:
        """List all templates."""
        params = {}
        if self.config.agenthub_ref:
            params["agenthub_revision"] = self.config.agenthub_ref
        return self._get("/templates", params=params)

    def get_template(self, name: str) -> dict:
        """Get template details."""
        params = {}
        if self.config.agenthub_ref:
            params["agenthub_revision"] = self.config.agenthub_ref
        return self._get(f"/templates/{quote(name)}", params=params)

    # ==================== Dataset operations ====================

    def list_datasets(self, search: Optional[str] = None) -> dict:
        """List all datasets."""
        params = {"limit": 500}
        if search:
            params["search"] = search
        return self._get("/datasets", params=params)

    def list_dataset_versions(self, dataset: str) -> list:
        """List dataset versions."""
        return self._get(f"/datasets/{quote(dataset)}/versions")

    def list_dataset_instances(self, dataset_version: str, limit: int = 10000) -> dict:
        """List dataset instances."""
        return self._get(f"/datasets/{quote(dataset_version)}/instances", params={"limit": limit})

    # ==================== Job operations ====================

    def create_group(
        self,
        name: Optional[str] = None,
        max_concurrency: Optional[int] = None,
        eval_config: Optional[dict] = None,
        model_base_url_collection: Optional[list] = None,
    ) -> dict:
        """Create a group."""
        body: dict = {}
        if name:
            body["name"] = name
        if max_concurrency is not None:
            body["max_concurrency"] = max_concurrency
        if eval_config is not None:
            body["eval_config"] = eval_config
        if model_base_url_collection is not None:
            body["model_base_url_collection"] = model_base_url_collection
        return self._post("/groups", body)

    def create_job(
        self,
        template: str,
        params: Optional[dict] = None,
        params_list: Optional[list] = None,
        suite_name: Optional[str] = None,
        tags: Optional[list] = None,
        overrides: Optional[dict] = None,
        max_concurrency: Optional[int] = None,
        group_id: Optional[str] = None,
        model_base_url_collection: Optional[list] = None,
        enable_otel_tracing: Optional[bool] = None,
        runner: Optional[str] = None,
        runner_options: Optional[dict] = None,
        idempotency_key: Optional[str] = None,
        timeout: float = 30
    ) -> dict:
        """Create a job."""
        body = self.build_create_job_body(
            template=template,
            params=params,
            params_list=params_list,
            suite_name=suite_name,
            tags=tags,
            overrides=overrides,
            max_concurrency=max_concurrency,
            group_id=group_id,
            model_base_url_collection=model_base_url_collection,
            enable_otel_tracing=enable_otel_tracing,
            runner=runner,
            runner_options=runner_options,
            idempotency_key=idempotency_key,
        )

        return self._post("/jobs", body, timeout=timeout)

    def build_create_job_body(
        self,
        template: str,
        params: Optional[dict] = None,
        params_list: Optional[list] = None,
        suite_name: Optional[str] = None,
        tags: Optional[list] = None,
        overrides: Optional[dict] = None,
        max_concurrency: Optional[int] = None,
        group_id: Optional[str] = None,
        model_base_url_collection: Optional[list] = None,
        enable_otel_tracing: Optional[bool] = None,
        runner: Optional[str] = None,
        runner_options: Optional[dict] = None,
        idempotency_key: Optional[str] = None,
    ) -> dict:
        """Build the /jobs request body for job creation."""
        body: dict = {"template": template}

        if params is not None:
            body["params"] = params
        if params_list is not None:
            body["params_list"] = params_list
        if suite_name:
            body["suite_name"] = suite_name
        if self.config.agenthub_ref:
            body["agenthub_revision"] = self.config.agenthub_ref
        if tags:
            body["tags"] = tags
        if overrides:
            body["overrides"] = overrides
        if max_concurrency is not None:
            body["max_concurrency"] = max_concurrency
        if group_id is not None:
            body["group_id"] = group_id
        if model_base_url_collection is not None:
            body["model_base_url_collection"] = model_base_url_collection
        if enable_otel_tracing is not None:
            body["enable_otel_tracing"] = enable_otel_tracing
        if runner is not None:
            body["runner"] = runner
        if runner_options is not None:
            body["runner_options"] = runner_options
        if idempotency_key is not None:
            body["idempotency_key"] = idempotency_key

        return body

    def get_job(self, job_id: str) -> dict:
        """Get job status."""
        return self._get(f"/jobs/{quote(job_id)}")

    def list_jobs(
        self,
        template: Optional[str] = None,
        group_id: Optional[str] = None,
        status: Optional[str] = None,
        job_id: Optional[str] = None,
        instance_id: Optional[str] = None,
        finished_after: Optional[str] = None,
        finished_before: Optional[str] = None,
        created_after: Optional[str] = None,
        created_before: Optional[str] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> dict:
        """List jobs."""
        params = {"skip": skip, "limit": limit}
        if template:
            params["template"] = template
        if group_id:
            params["group_id"] = group_id
        if status:
            params["status"] = status
        if job_id:
            params["job_id"] = job_id
        if instance_id:
            params["instance_id"] = instance_id
        if finished_after:
            params["finished_after"] = finished_after
        if finished_before:
            params["finished_before"] = finished_before
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before
        return self._get("/jobs", params=params)

    # ==================== Group operations ====================

    def get_group(self, group_id: str) -> dict:
        """Get group details."""
        return self._get(f"/groups/{quote(group_id)}")

    def list_groups(self, skip: int = 0, limit: int = 100) -> dict:
        """List groups."""
        return self._get("/groups", params={"skip": skip, "limit": limit})

    def list_group_jobs(
        self,
        group_id: str,
        tag: Optional[list[str]] = None,
        skip: int = 0,
        limit: int = 100,
    ) -> dict:
        """List jobs in a group."""
        params: dict = {"skip": skip, "limit": limit}
        if tag:
            params["tag"] = tag
        return self._get(f"/groups/{quote(group_id)}/jobs", params=params)

    def get_group_stats(self, group_id: str) -> dict:
        """Get group progress."""
        return self._get(f"/groups/{quote(group_id)}/stats")

    def update_group(
        self,
        group_id: str,
        max_concurrency: Optional[int] = None,
        eval_config: Optional[dict] = None
    ) -> dict:
        """Update group properties (max_concurrency and/or eval_config)."""
        body: dict = {}

        if max_concurrency is not None:
            body["max_concurrency"] = max_concurrency
        if eval_config is not None:
            body["eval_config"] = eval_config

        return self._request("PATCH", f"/groups/{quote(group_id)}", json_body=body)

    def get_group_eval(self, group_id: str) -> dict:
        """Get aggregated evaluation results for a group."""
        return self._get(f"/groups/{quote(group_id)}/eval")

    # ==================== Logs and artifacts ====================
    def cancel_group(self, group_id: str) -> dict:
        """Cancel all unfinished jobs in a group."""
        return self._post(f"/groups/{quote(group_id)}/cancel", {})

    def get_job_logs(
        self,
        job_id: str,
        container: Optional[str] = None,
        offset: Optional[int] = 0,
        limit: Optional[int] = 1000,
    ) -> dict:
        """获取任务日志

        Args:
            job_id: 任务ID
            container: 容器名称，如果为None则返回所有容器日志
            offset: 分页偏移量，用于获取后续日志页
            limit: 分页大小，默认为1000
        """
        params = {}
        if container:
            params["container"] = container
        if offset is not None:
            params["offset"] = offset
        if limit is not None:
            params["limit"] = limit
        return self._get(f"/jobs/{quote(job_id)}/logs", params=params or None)

    def get_job_logs_complete(self, job_id: str, container: str) -> dict:
        """获取完整日志（自动处理分页）

        一直调用接口直到返回的next_offset为空，标识日志获取完成

        Args:
            job_id: 任务ID
            container: 容器名称

        Returns:
            dict: 所有日志
        """
        all_logs = []
        offset = 0

        while True:
            result = self.get_job_logs(
                job_id=job_id, container=container, offset=offset, limit=1000
            )

            # 提取日志数据
            if "logs" in result and isinstance(result["logs"], list):
                all_logs.extend(result["logs"])

            # 检查是否还有更多日志
            next_offset = result.get("next_offset")
            if next_offset is None:
                break

            offset = next_offset

        return {"logs": all_logs, "container": container, "job_id": job_id}

    def get_job_events(self, job_id: str, container: Optional[str] = None) -> dict:
        """Get job events."""
        params = {}
        if container:
            params["container"] = container
        return self._get(f"/jobs/{quote(job_id)}/events", params=params or None)

    def get_job_containers(self, job_id: str) -> dict:
        """Get all container names for a job.

        Args:
            job_id: The job ID to get containers for
        """
        return self._get(f"/jobs/{quote(job_id)}/containers")

    def get_job_metrics(self, job_id: str) -> dict:
        """Get job metrics."""
        return self._get(f"/metrics/{quote(job_id)}")

    def cancel_job(self, job_id: str) -> dict:
        """Cancel a job."""
        return self._delete(f"/jobs/{quote(job_id)}")

    def get_group_artifacts_page(
        self,
        group_id: str,
        *,
        skip: int = 0,
        limit: int = _GROUP_ARTIFACTS_PAGE_SIZE,
    ) -> dict:
        """Get one page of artifact download links for a group."""
        return self._get(
            f"/groups/{quote(group_id)}/artifacts",
            params={"skip": skip, "limit": limit},
        )

    def get_group_artifacts(self, group_id: str) -> dict:
        """Get artifact download links for a group."""
        skip = 0
        artifacts: list[dict] = []
        last_page: dict | None = None

        while True:
            page = self.get_group_artifacts_page(
                group_id,
                skip=skip,
                limit=_GROUP_ARTIFACTS_PAGE_SIZE,
            )
            last_page = page
            page_artifacts = page.get("artifacts") or []
            artifacts.extend(page_artifacts)

            total = page.get("total")
            if total is not None and len(artifacts) >= total:
                break
            if len(page_artifacts) < _GROUP_ARTIFACTS_PAGE_SIZE:
                break

            skip += len(page_artifacts)

        return {
            **last_page,
            "skip": 0,
            "limit": len(artifacts),
            "artifacts": artifacts,
        }

    def get_job_artifacts(self, job_ids: list) -> list:
        """Get artifact download links for one or more jobs."""
        return self._post("/jobs/artifacts", {"job_ids": job_ids})

    def render_template(self, name: str, params: dict) -> dict:
        """Preview the rendered template output."""
        query_params = {}
        if self.config.agenthub_ref:
            query_params["agenthub_revision"] = self.config.agenthub_ref
        return self._request(
            "POST",
            f"/templates/{quote(name)}/render",
            params=query_params,
            json_body={"params": params},
        )

    # ==================== Eval Plan operations ====================

    def create_eval_plan(
        self,
        name: str,
        job_spec: dict,
        cron_expression: str,
        valid_from: str,
        valid_until: str,
        description: Optional[str] = None,
    ) -> dict:
        """Create an eval plan."""
        body: dict = {
            "name": name,
            "job_spec": job_spec,
            "cron_expression": cron_expression,
            "valid_from": valid_from,
            "valid_until": valid_until,
        }
        if description is not None:
            body["description"] = description
        return self._post("/eval-plans", body)

    def list_eval_plans(
        self,
        status: Optional[str] = None,
        user_id: Optional[str] = None,
        created_after: Optional[str] = None,
        created_before: Optional[str] = None,
        skip: int = 0,
        limit: int = -1,
    ) -> dict:
        """List eval plans with optional filters."""
        params: dict = {"skip": skip, "limit": limit}
        if status:
            params["status"] = status
        if user_id:
            params["user_id"] = user_id
        if created_after:
            params["created_after"] = created_after
        if created_before:
            params["created_before"] = created_before
        return self._get("/eval-plans", params=params)

    def get_eval_plan(self, plan_id: str) -> dict:
        """Get eval plan detail."""
        return self._get(f"/eval-plans/{quote(plan_id)}")

    def update_eval_plan(
        self,
        plan_id: str,
        name: Optional[str] = None,
        job_spec: Optional[dict] = None,
        cron_expression: Optional[str] = None,
        valid_from: Optional[str] = None,
        valid_until: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[str] = None,
    ) -> dict:
        """Update an eval plan.

        All fields except *plan_id* are optional — only provided fields
        are included in the PATCH request body.
        """
        body: dict = {}
        if name is not None:
            body["name"] = name
        if job_spec is not None:
            body["job_spec"] = job_spec
        if cron_expression is not None:
            body["cron_expression"] = cron_expression
        if valid_from is not None:
            body["valid_from"] = valid_from
        if valid_until is not None:
            body["valid_until"] = valid_until
        if description is not None:
            body["description"] = description
        if status is not None:
            body["status"] = status
        return self._request("PATCH", f"/eval-plans/{quote(plan_id)}", json_body=body)

    def delete_eval_plan(self, plan_id: str) -> dict:
        """Permanently delete an eval plan from MongoDB."""
        return self._delete(f"/eval-plans/{quote(plan_id)}")

    def trigger_eval_plan(self, plan_id: str) -> dict:
        """Manual trigger — creates Group + Jobs."""
        return self._post(f"/eval-plans/{quote(plan_id)}/trigger", {})

    def list_eval_plan_runs(
        self,
        plan_id: str,
        skip: int = 0,
        limit: int = -1,
    ) -> dict:
        """List historical runs for an eval plan."""
        return self._get(
            f"/eval-plans/{quote(plan_id)}/runs", params={"skip": skip, "limit": limit}
        )


_verbose_override: Optional[bool] = None


def set_verbose_override(value: Optional[bool]) -> None:
    """Set a process-wide verbose override consulted by get_client()."""
    global _verbose_override
    _verbose_override = value


def get_client(agenthub_ref: Optional[str] = None) -> APIClient:
    """Get an API client."""
    return APIClient(get_config(verbose=_verbose_override, agenthub_ref=agenthub_ref))


def _build_user_agent(existing: Optional[str] = None) -> str:
    """Build client User-Agent string."""
    client_ua = (
        f"ap-client/{_client_version()} "
        f"python/{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro} "
        f"{platform.system().lower()}/{platform.machine().lower()}"
    )
    if existing:
        return f"{existing} {client_ua}"
    return client_ua


def _client_version() -> str:
    from . import __version__

    return __version__


def _write_stderr(lines: list[str]) -> None:
    sys.stderr.write("\n".join(lines) + "\n")
    sys.stderr.flush()


def _safe_json(value: Any) -> str:
    try:
        return json.dumps(value, ensure_ascii=False, default=str)
    except Exception:
        return str(value)


_SENSITIVE_SUBSTRINGS = (
    "authorization",
    "api-key",
    "api_key",
    "apikey",
    "api-secret",
    "api_secret",
    "secret_key",
    "secret-key",
    "access_key",
    "access-key",
    "accesskey",
    "secretkey",
    "cookie",
    "secret",
    "password",
    "passwd",
)
_SENSITIVE_SEGMENT_RE = re.compile(r"(?:^|[_-])(?:ak|sk)(?:[_-]|$)", re.IGNORECASE)


def _redact_headers(headers: dict, enabled: bool = True) -> dict:
    if not enabled:
        return dict(headers)
    return {
        key: _mask_sensitive_value(value) if _is_sensitive_key(str(key)) else value
        for key, value in headers.items()
    }


def _redact_sensitive_data(value: Any, enabled: bool = True) -> Any:
    if not enabled:
        return value
    if isinstance(value, dict):
        return {
            key: _redact_sensitive_field(str(key), field_value)
            for key, field_value in value.items()
        }
    if isinstance(value, list):
        return [_redact_sensitive_data(item, enabled=True) for item in value]
    if isinstance(value, str):
        return _redact_url_query_secrets(value)
    return value


def _redact_sensitive_field(key: str, value: Any) -> Any:
    if _is_sensitive_key(key):
        return _mask_sensitive_value(value)
    return _redact_sensitive_data(value, enabled=True)


def _is_sensitive_key(key: str) -> bool:
    lower_key = key.lower()
    if any(pattern in lower_key for pattern in _SENSITIVE_SUBSTRINGS):
        return True
    return bool(_SENSITIVE_SEGMENT_RE.search(lower_key))


def _mask_sensitive_value(value: Any) -> Any:
    if isinstance(value, str) and value:
        return _mask_middle(value)
    return value


def _mask_middle(value: str) -> str:
    if len(value) == 1:
        return "*"
    if len(value) <= 8:
        return value[:1] + "..." + value[-1:]
    if value.lower().startswith("bearer "):
        return "Bearer " + _mask_middle(value[7:])
    if len(value) <= 16:
        return value[:4] + "..." + value[-4:]
    return value[:8] + "..." + value[-4:]


def _redact_url_query_secrets(value: str) -> str:
    if "?" not in value:
        return value
    try:
        parsed = urlsplit(value)
    except ValueError:
        return value
    if not parsed.query:
        return value

    changed = False
    query = []
    for key, item_value in parse_qsl(parsed.query, keep_blank_values=True):
        if _is_sensitive_key(key) and item_value:
            query.append((key, _mask_middle(item_value)))
            changed = True
        else:
            query.append((key, item_value))
    if not changed:
        return value
    return urlunsplit(
        (
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            urlencode(query),
            parsed.fragment,
        )
    )


def _response_error_detail(resp: requests.Response) -> Any:
    try:
        err_data = resp.json()
    except Exception:
        return resp.text
    if isinstance(err_data, dict):
        return err_data.get("detail", resp.text)
    return err_data


def _unexpected_non_json_response_detail(resp: requests.Response) -> str:
    return "Unexpected non-JSON response from API endpoint"


def _safe_decode(raw: bytes) -> str:
    try:
        return raw.decode("utf-8", errors="replace")
    except Exception:
        return f"<{len(raw)} bytes binary>"


def _truncate_text(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + f"...<truncated {len(text) - limit} chars>"


def _shorten_value(value: Any) -> Any:
    if isinstance(value, str):
        if len(value) > _VERBOSE_VALUE_PREVIEW:
            return value[:_VERBOSE_VALUE_PREVIEW] + "..."
        return value
    if isinstance(value, dict):
        return f"<dict {len(value)} keys>"
    if isinstance(value, list):
        return f"<list {len(value)} items>"
    return value


def _summarize_json_value(data: Any, limit: int) -> str:
    if isinstance(data, dict):
        keys = list(data.keys())
        sample = {k: _shorten_value(data[k]) for k in keys[:_VERBOSE_SAMPLE_KEYS]}
        summary = {"_keys": keys, "_sample": sample}
        if len(keys) > _VERBOSE_SAMPLE_KEYS:
            summary["_truncated_keys"] = len(keys) - _VERBOSE_SAMPLE_KEYS
        return _truncate_text(_safe_json(summary), limit)
    if isinstance(data, list):
        sample = [_shorten_value(item) for item in data[:_VERBOSE_SAMPLE_ITEMS]]
        summary = {"_count": len(data), "_sample": sample}
        return _truncate_text(_safe_json(summary), limit)
    return _truncate_text(_safe_json(data), limit)
