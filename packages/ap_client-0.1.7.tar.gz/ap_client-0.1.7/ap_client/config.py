"""Configuration management."""

import os
from dataclasses import dataclass

DEFAULT_BASE_URL = "http://agentplatform.aliyun-inc.com"
CLUSTER_HEADER = "X-Cluster"


class ConfigurationError(Exception):
    """Raised when required client configuration is missing or invalid."""


def _parse_bool(value: str | None) -> bool:
    """Parse a boolean environment variable."""
    if value is None:
        return False
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_bool_default(value: str | None, default: bool) -> bool:
    """Parse a boolean environment variable with an explicit default."""
    if value is None or not value.strip():
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _parse_positive_int(value: str | None, default: int) -> int:
    """Parse a positive-integer environment variable."""
    if value is None or not value.strip():
        return default
    parsed = int(value)
    if parsed <= 0:
        raise ValueError("environment variable must be a positive integer")
    return parsed


def has_cluster_header(headers: dict[str, str]) -> bool:
    return any(key.lower() == "x-cluster" and value.strip() for key, value in headers.items())


def _set_cluster_header(headers: dict[str, str], cluster: str) -> None:
    for key in list(headers):
        if key.lower() == "x-cluster":
            del headers[key]
    headers[CLUSTER_HEADER] = cluster


@dataclass
class Config:
    """CLI 配置

    认证: 支持以下方式
        - AP_API_KEY: CLI 当前请求使用的单个 API Key（推荐）
        - AP_API_KEYS: 向后兼容；CLI 侧只接受单个 key，服务端才使用逗号分隔列表
        - AP_TOKEN_KEY: 向后兼容的旧环境变量名
    """

    base_url: str
    headers: dict
    agenthub_ref: str | None
    verbose: bool = False
    verbose_body_limit: int = 4096
    verbose_full_body: bool = False
    verbose_redaction: bool = True
    token_key: str | None = None

    @classmethod
    def from_env(cls) -> "Config":
        """从环境变量加载配置"""
        base_url = os.environ.get("AP_BASE_URL") or DEFAULT_BASE_URL

        headers: dict[str, str] = {}
        headers_str = os.environ.get("AP_HEADERS", "")
        if headers_str:
            for h in headers_str.split(","):
                if ":" in h:
                    k, v = h.split(":", 1)
                    headers[k.strip()] = v.strip()

        token_key = _resolve_token_key()

        cluster = os.environ.get("AP_CLUSTER", "").strip()
        if cluster:
            _set_cluster_header(headers, cluster)

        return cls(
            base_url=base_url.rstrip("/"),
            headers=headers,
            agenthub_ref=os.environ.get("AP_AGENTHUB_REF"),
            verbose=_parse_bool(os.environ.get("AP_VERBOSE")),
            verbose_body_limit=_parse_positive_int(os.environ.get("AP_VERBOSE_BODY_LIMIT"), 4096),
            verbose_full_body=_parse_bool(os.environ.get("AP_VERBOSE_FULL_BODY")),
            verbose_redaction=_parse_bool_default(os.environ.get("AP_VERBOSE_REDACTION"), True),
            token_key=token_key,
        )


def _resolve_token_key() -> str | None:
    """Resolve the single API key used by the CLI."""
    for env_name in ("AP_API_KEY", "AP_API_KEYS", "AP_TOKEN_KEY"):
        value = os.environ.get(env_name)
        if value is None or not value.strip():
            continue
        token_key = value.strip()
        if "," in token_key:
            raise ConfigurationError(
                f"{env_name} must contain exactly one API key for the CLI; "
                "server-side AP_API_KEYS is the comma-separated allowlist."
            )
        return token_key
    return None


def get_config(
    verbose: bool | None = None,
    agenthub_ref: str | None = None,
) -> Config:
    """Return the current configuration."""
    config = Config.from_env()
    if verbose is not None:
        config.verbose = verbose
    if agenthub_ref is not None:
        config.agenthub_ref = agenthub_ref.strip() or None
    return config
