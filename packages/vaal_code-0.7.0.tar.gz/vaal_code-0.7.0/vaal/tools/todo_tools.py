"""Todo tools -- let the LLM create, update, and list todos during work."""

import json

from .registry import register_tool
from ..core.task_manager import get_task_manager, TaskStatus


@register_tool(
    name="todo_create",
    description=(
        "Create a todo item to track work that needs to be done. "
        "Use this to break down complex tasks into discrete steps, "
        "track progress, and ensure nothing is missed."
    ),
    parameters={
        "title": {
            "description": "Short title for the todo item (imperative form, e.g. 'Fix login validation').",
            "required": True,
        },
        "description": {
            "description": "Optional longer description of what needs to be done.",
            "required": False,
        },
    },
)
def todo_create(title: str, description: str = "") -> str:
    tm = get_task_manager()
    task = tm.create(title=title, description=description)
    return json.dumps({
        "id": task.id,
        "title": task.title,
        "status": task.status.value,
        "message": f"Created todo: {task.title}",
    }, indent=2)


@register_tool(
    name="todo_update",
    description=(
        "Update a todo item's status. Use 'in_progress' when starting work, "
        "'completed' when done, 'blocked' if stuck. "
        "Always mark todos as completed when you finish them."
    ),
    parameters={
        "id": {
            "description": "The todo ID (from todo_create or todo_list).",
            "required": True,
        },
        "status": {
            "description": "New status: pending, in_progress, completed, or blocked.",
            "required": True,
        },
        "title": {
            "description": "Optionally update the title.",
            "required": False,
        },
    },
)
def todo_update(id: str, status: str, title: str = "") -> str:
    tm = get_task_manager()
    try:
        status_val = TaskStatus(status)
    except ValueError:
        return json.dumps({"error": f"Invalid status: {status}. Use: pending, in_progress, completed, blocked"})

    task = tm.update(id, status=status_val, title=title if title else None)
    if not task:
        return json.dumps({"error": f"Todo not found: {id}"})

    return json.dumps({
        "id": task.id,
        "title": task.title,
        "status": task.status.value,
        "message": f"Updated: {task.title} -> {status}",
    }, indent=2)


@register_tool(
    name="todo_list",
    description=(
        "List all current todo items with their status. "
        "Use this to check progress and find what to work on next."
    ),
    parameters={},
)
def todo_list() -> str:
    tm = get_task_manager()
    tasks = tm.list_all()
    if not tasks:
        return json.dumps({"todos": [], "summary": "No todos."})

    return json.dumps({
        "todos": [t.to_dict() for t in tasks],
        "summary": tm.summary,
    }, indent=2)
