"""Git tools — status, diff, log, commit, branch, stash."""

import subprocess
import os

from .registry import register_tool


def _git(args: list[str], cwd: str | None = None, timeout: int = 30) -> tuple[str, int]:
    """Run a git command and return (output, returncode)."""
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd or os.getcwd(),
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            if output:
                output += "\n"
            output += result.stderr
        return output.strip(), result.returncode
    except FileNotFoundError:
        return "[error: git not found on PATH]", 1
    except subprocess.TimeoutExpired:
        return f"[error: git command timed out after {timeout}s]", 1
    except Exception as e:
        return f"[error: {e}]", 1


@register_tool(
    name="git_status",
    description="Show the working tree status — staged, unstaged, and untracked files.",
    parameters={
        "path": {"description": "Repository path (default: cwd)", "required": False},
    },
)
def git_status(path: str = "", **kwargs) -> str:
    cwd = path or None
    output, code = _git(["status", "--short", "--branch"], cwd=cwd)
    if code != 0 and "not a git repository" in output.lower():
        return "[error: not a git repository]"
    return output or "(clean working tree)"


@register_tool(
    name="git_diff",
    description="Show diffs — staged changes, unstaged changes, or a specific file.",
    parameters={
        "file_path": {"description": "Specific file to diff (optional)", "required": False},
        "staged": {"description": "Show staged (cached) changes only (true/false, default false)", "required": False},
        "path": {"description": "Repository path (default: cwd)", "required": False},
    },
)
def git_diff(file_path: str = "", staged: str = "", path: str = "", **kwargs) -> str:
    cwd = path or None
    args = ["diff"]
    if staged and str(staged).lower() in ("true", "1", "yes"):
        args.append("--cached")
    if file_path:
        args.append("--")
        args.append(file_path)
    output, code = _git(args, cwd=cwd, timeout=60)
    if code != 0:
        return f"[error: git diff failed]\n{output}"
    return output[:50000] or "(no differences)"


@register_tool(
    name="git_log",
    description="Show recent commit history.",
    parameters={
        "count": {"description": "Number of commits to show (default 10)", "required": False},
        "oneline": {"description": "Use compact one-line format (true/false, default true)", "required": False},
        "path": {"description": "Repository path (default: cwd)", "required": False},
    },
)
def git_log(count: str | int = 10, oneline: str = "true", path: str = "", **kwargs) -> str:
    cwd = path or None
    n = int(count) if count else 10
    args = ["log", f"-{n}"]
    if str(oneline).lower() in ("true", "1", "yes", ""):
        args.append("--oneline")
    else:
        args.extend(["--format=%h %ad %an: %s", "--date=short"])
    output, code = _git(args, cwd=cwd)
    if code != 0:
        return f"[error: git log failed]\n{output}"
    return output or "(no commits)"


@register_tool(
    name="git_commit",
    description="Stage files and create a git commit. DANGEROUS — modifies repository history.",
    parameters={
        "message": {"description": "Commit message", "required": True},
        "files": {"description": "Files to stage (space-separated). Use '.' for all.", "required": True},
        "path": {"description": "Repository path (default: cwd)", "required": False},
    },
    dangerous=True,
)
def git_commit(message: str, files: str, path: str = "", **kwargs) -> str:
    cwd = path or None

    # Stage files
    file_list = files.split()
    add_out, add_code = _git(["add"] + file_list, cwd=cwd)
    if add_code != 0:
        return f"[error: git add failed]\n{add_out}"

    # Append co-author trailer
    full_msg = message.rstrip() + "\n\nCo-Authored-By: Vaal <vaal@e-e.tools>"
    commit_out, commit_code = _git(["commit", "-m", full_msg], cwd=cwd)
    if commit_code != 0:
        return f"[error: git commit failed]\n{commit_out}"

    return commit_out


@register_tool(
    name="git_branch",
    description="List, create, or switch git branches.",
    parameters={
        "action": {"description": "Action: 'list' (default), 'create', or 'switch'", "required": False},
        "name": {"description": "Branch name (for create/switch)", "required": False},
        "path": {"description": "Repository path (default: cwd)", "required": False},
    },
)
def git_branch(action: str = "list", name: str = "", path: str = "", **kwargs) -> str:
    cwd = path or None
    action = (action or "list").lower()

    if action == "list":
        output, code = _git(["branch", "-a", "--no-color"], cwd=cwd)
        if code != 0:
            return f"[error: git branch failed]\n{output}"
        return output or "(no branches)"

    elif action == "create":
        if not name:
            return "[error: branch name required for 'create']"
        output, code = _git(["checkout", "-b", name], cwd=cwd)
        if code != 0:
            return f"[error: failed to create branch]\n{output}"
        return f"Created and switched to branch: {name}"

    elif action == "switch":
        if not name:
            return "[error: branch name required for 'switch']"
        output, code = _git(["checkout", name], cwd=cwd)
        if code != 0:
            return f"[error: failed to switch branch]\n{output}"
        return f"Switched to branch: {name}"

    else:
        return f"[error: unknown action '{action}'. Use 'list', 'create', or 'switch'.]"


@register_tool(
    name="git_stash",
    description="Stash or restore uncommitted changes.",
    parameters={
        "action": {"description": "Action: 'push' (default), 'pop', 'list', 'drop'", "required": False},
        "message": {"description": "Stash message (for push)", "required": False},
        "path": {"description": "Repository path (default: cwd)", "required": False},
    },
)
def git_stash(action: str = "push", message: str = "", path: str = "", **kwargs) -> str:
    cwd = path or None
    action = (action or "push").lower()

    if action == "push":
        args = ["stash", "push"]
        if message:
            args.extend(["-m", message])
        output, code = _git(args, cwd=cwd)
        if code != 0:
            return f"[error: git stash push failed]\n{output}"
        return output or "Changes stashed."

    elif action == "pop":
        output, code = _git(["stash", "pop"], cwd=cwd)
        if code != 0:
            return f"[error: git stash pop failed]\n{output}"
        return output or "Stash applied and dropped."

    elif action == "list":
        output, code = _git(["stash", "list"], cwd=cwd)
        if code != 0:
            return f"[error: git stash list failed]\n{output}"
        return output or "(no stashes)"

    elif action == "drop":
        output, code = _git(["stash", "drop"], cwd=cwd)
        if code != 0:
            return f"[error: git stash drop failed]\n{output}"
        return output or "Stash dropped."

    else:
        return f"[error: unknown action '{action}'. Use 'push', 'pop', 'list', or 'drop'.]"


@register_tool(
    name="git_worktree_create",
    description=(
        "Create a git worktree — an isolated copy of the repo on a new branch. "
        "Useful for working on changes without affecting the main working directory. "
        "Each worktree has its own working directory but shares the git history. "
        "Returns the path to the new worktree."
    ),
    parameters={
        "branch": {
            "description": "Branch name for the worktree (will be created if it doesn't exist).",
            "required": True,
        },
        "path": {
            "description": "Directory path for the worktree. Defaults to '../<repo>-<branch>' next to the repo.",
            "required": False,
        },
        "base": {
            "description": "Base branch/commit to branch from. Defaults to HEAD.",
            "required": False,
        },
    },
    dangerous=True,
)
def git_worktree_create(branch: str, path: str = "", base: str = "") -> str:
    """Create an isolated git worktree."""
    cwd = os.getcwd()

    # Check if inside a git repo
    _, code = _git(["rev-parse", "--git-dir"], cwd=cwd)
    if code != 0:
        return "[error: not inside a git repository]"

    # Default path: sibling directory named <repo>-<branch>
    if not path:
        repo_name = os.path.basename(cwd)
        path = os.path.join(os.path.dirname(cwd), f"{repo_name}-{branch}")

    path = os.path.abspath(path)

    # Check if branch already exists
    existing, _ = _git(["branch", "--list", branch], cwd=cwd)

    if existing.strip():
        # Branch exists — just add worktree pointing to it
        output, code = _git(["worktree", "add", path, branch], cwd=cwd)
    else:
        # Create new branch from base
        args = ["worktree", "add", "-b", branch, path]
        if base:
            args.append(base)
        output, code = _git(args, cwd=cwd)

    if code != 0:
        return f"[error: git worktree add failed]\n{output}"

    return f"Worktree created:\n  branch: {branch}\n  path: {path}\n{output}"


@register_tool(
    name="git_worktree_remove",
    description=(
        "Remove a git worktree. This deletes the worktree directory and "
        "unregisters it from git. The branch is NOT deleted."
    ),
    parameters={
        "path": {
            "description": "Path to the worktree to remove.",
            "required": True,
        },
        "force": {
            "description": "Force removal even with uncommitted changes. Default: false.",
            "required": False,
        },
    },
    dangerous=True,
)
def git_worktree_remove(path: str, force: str = "false") -> str:
    """Remove a git worktree."""
    cwd = os.getcwd()
    path = os.path.abspath(path)

    args = ["worktree", "remove", path]
    if force.lower() in ("true", "yes", "1"):
        args.insert(2, "--force")

    output, code = _git(args, cwd=cwd)
    if code != 0:
        return f"[error: git worktree remove failed]\n{output}"

    return f"Worktree removed: {path}\n{output}"


@register_tool(
    name="git_worktree_list",
    description="List all git worktrees for the current repository.",
    parameters={},
)
def git_worktree_list() -> str:
    """List git worktrees."""
    output, code = _git(["worktree", "list"], cwd=os.getcwd())
    if code != 0:
        return f"[error: git worktree list failed]\n{output}"
    return output or "(no worktrees)"
