"""API testing tools — make HTTP requests and inspect responses."""

import json
import time
import os
from pathlib import Path
from urllib.parse import urlparse

from .registry import register_tool


# Request history stored in ~/.vaal/api_history.json
HISTORY_FILE = Path.home() / ".vaal" / "api_history.json"
MAX_HISTORY = 100


def _load_history() -> list[dict]:
    """Load saved request history."""
    if HISTORY_FILE.is_file():
        try:
            return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return []


def _save_history(history: list[dict]):
    """Save request history to disk."""
    HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)
    # Trim to MAX_HISTORY
    history = history[-MAX_HISTORY:]
    try:
        HISTORY_FILE.write_text(json.dumps(history, indent=2, default=str), encoding="utf-8")
    except Exception:
        pass


def _record_request(entry: dict):
    """Append a request to history."""
    history = _load_history()
    history.append(entry)
    _save_history(history)


def _format_json(text: str) -> str:
    """Try to pretty-print JSON, return as-is if not JSON."""
    try:
        parsed = json.loads(text)
        return json.dumps(parsed, indent=2, ensure_ascii=False)
    except (json.JSONDecodeError, TypeError):
        return text


def _format_response(status: int, headers: dict, body: str, elapsed: float) -> str:
    """Format an HTTP response for display."""
    lines = []
    lines.append(f"Status: {status}")
    lines.append(f"Time: {elapsed:.2f}s")
    lines.append("")

    # Headers
    lines.append("Headers:")
    for key, val in sorted(headers.items()):
        lines.append(f"  {key}: {val}")
    lines.append("")

    # Body
    content_type = headers.get("content-type", headers.get("Content-Type", ""))
    if "json" in content_type.lower() or body.strip().startswith(("{", "[")):
        formatted = _format_json(body)
        lines.append("Body (JSON):")
        lines.append(formatted)
    elif len(body) > 5000:
        lines.append(f"Body ({len(body)} bytes, truncated):")
        lines.append(body[:5000])
        lines.append("... (truncated)")
    else:
        lines.append("Body:")
        lines.append(body)

    return "\n".join(lines)


def _make_request(
    method: str,
    url: str,
    headers: dict | None = None,
    body: str = "",
    auth: str = "",
    timeout: int = 30,
) -> str:
    """Make an HTTP request using urllib (no external deps).

    Returns formatted response string.
    """
    import urllib.request
    import urllib.error

    method = method.upper()
    headers = headers or {}

    # Set default headers
    if "User-Agent" not in headers:
        headers["User-Agent"] = "Vaal-API-Tool/1.0"

    # Handle auth
    if auth:
        if auth.startswith("Bearer "):
            headers["Authorization"] = auth
        elif ":" in auth:
            # Basic auth
            import base64
            encoded = base64.b64encode(auth.encode()).decode()
            headers["Authorization"] = f"Basic {encoded}"
        else:
            headers["Authorization"] = f"Bearer {auth}"

    # Auto-set content-type for body
    if body and "Content-Type" not in headers:
        try:
            json.loads(body)
            headers["Content-Type"] = "application/json"
        except (json.JSONDecodeError, TypeError):
            headers["Content-Type"] = "application/x-www-form-urlencoded"

    # Build request
    data = body.encode("utf-8") if body else None
    req = urllib.request.Request(url, data=data, headers=headers, method=method)

    start = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            elapsed = time.time() - start
            resp_headers = dict(resp.getheaders())
            resp_body = resp.read().decode("utf-8", errors="replace")
            status = resp.status

            # Record to history
            _record_request({
                "timestamp": time.time(),
                "method": method,
                "url": url,
                "request_headers": headers,
                "request_body": body[:500] if body else "",
                "status": status,
                "elapsed": round(elapsed, 2),
            })

            return _format_response(status, resp_headers, resp_body, elapsed)

    except urllib.error.HTTPError as e:
        elapsed = time.time() - start
        resp_body = e.read().decode("utf-8", errors="replace") if e.fp else ""
        resp_headers = dict(e.headers) if e.headers else {}

        _record_request({
            "timestamp": time.time(),
            "method": method,
            "url": url,
            "request_headers": headers,
            "request_body": body[:500] if body else "",
            "status": e.code,
            "elapsed": round(elapsed, 2),
        })

        return _format_response(e.code, resp_headers, resp_body, elapsed)

    except urllib.error.URLError as e:
        elapsed = time.time() - start
        return f"Connection error ({elapsed:.2f}s): {e.reason}"

    except Exception as e:
        elapsed = time.time() - start
        return f"Request failed ({elapsed:.2f}s): {e}"


# ── Tool registration ────────────────────────────────────────────────

@register_tool(
    name="api_request",
    description=(
        "Make an HTTP request (GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS). "
        "Returns status code, headers, and formatted body. "
        "Supports JSON bodies, Bearer/Basic auth, custom headers."
    ),
    parameters={
        "method": {"description": "HTTP method: GET, POST, PUT, DELETE, PATCH, HEAD, OPTIONS", "required": True},
        "url": {"description": "The URL to request", "required": True},
        "headers": {"description": "JSON string of request headers, e.g. '{\"Accept\": \"application/json\"}'", "required": False},
        "body": {"description": "Request body (string or JSON string)", "required": False},
        "auth": {"description": "Auth string: 'Bearer <token>' or 'user:password' for Basic auth", "required": False},
        "timeout": {"description": "Request timeout in seconds (default 30)", "required": False},
    },
    dangerous=False,
)
def api_request(
    method: str = "GET",
    url: str = "",
    headers: str = "",
    body: str = "",
    auth: str = "",
    timeout: str | int = 30,
    **kwargs,
) -> str:
    """Execute an HTTP request and return formatted response."""
    if not url:
        return "URL is required."

    # Parse headers from JSON string
    parsed_headers = {}
    if headers:
        if isinstance(headers, str):
            try:
                parsed_headers = json.loads(headers)
            except json.JSONDecodeError:
                # Try key: value format
                for line in headers.split(","):
                    if ":" in line:
                        k, v = line.split(":", 1)
                        parsed_headers[k.strip()] = v.strip()
        elif isinstance(headers, dict):
            parsed_headers = headers

    timeout_val = int(timeout) if timeout else 30

    return _make_request(
        method=method,
        url=url,
        headers=parsed_headers,
        body=body,
        auth=auth,
        timeout=timeout_val,
    )


# ── Slash command handler ────────────────────────────────────────────

def handle_api_command(arg: str) -> str:
    """Handle /api slash command.

    /api GET https://example.com/endpoint
    /api POST https://example.com/endpoint {"key": "value"}
    /api history          - show recent requests
    /api replay <index>   - replay a saved request
    /api clear            - clear history
    """
    arg = arg.strip()
    if not arg:
        return (
            "Usage:\n"
            "  /api <METHOD> <URL> [body]\n"
            "  /api history           - show recent requests\n"
            "  /api replay <index>    - replay a saved request\n"
            "  /api clear             - clear request history\n"
            "\n"
            "Examples:\n"
            "  /api GET https://httpbin.org/get\n"
            "  /api POST https://httpbin.org/post {\"name\": \"test\"}\n"
            '  /api GET https://api.example.com/data -H Authorization: Bearer tok123'
        )

    parts = arg.split(maxsplit=2)

    # Sub-commands
    if parts[0].lower() == "history":
        history = _load_history()
        if not history:
            return "No request history."
        lines = ["Recent requests:"]
        for i, entry in enumerate(history[-20:]):
            idx = len(history) - 20 + i if len(history) > 20 else i
            status = entry.get("status", "?")
            elapsed = entry.get("elapsed", 0)
            lines.append(
                f"  [{idx}] {entry.get('method', '?')} {entry.get('url', '?')} "
                f"-> {status} ({elapsed}s)"
            )
        return "\n".join(lines)

    if parts[0].lower() == "replay":
        if len(parts) < 2:
            return "Usage: /api replay <index>"
        try:
            idx = int(parts[1])
            history = _load_history()
            if idx < 0 or idx >= len(history):
                return f"Invalid index. Range: 0-{len(history)-1}"
            entry = history[idx]
            return _make_request(
                method=entry.get("method", "GET"),
                url=entry.get("url", ""),
                headers=entry.get("request_headers", {}),
                body=entry.get("request_body", ""),
            )
        except ValueError:
            return "Index must be a number."

    if parts[0].lower() == "clear":
        _save_history([])
        return "Request history cleared."

    # Parse: METHOD URL [BODY]
    method = parts[0].upper()
    valid_methods = {"GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"}
    if method not in valid_methods:
        return f"Unknown method: {method}. Supported: {', '.join(sorted(valid_methods))}"

    if len(parts) < 2:
        return f"URL required. Usage: /api {method} <url>"

    url = parts[1]
    body = parts[2] if len(parts) > 2 else ""

    # Quick validation
    parsed = urlparse(url)
    if not parsed.scheme:
        url = "https://" + url

    return _make_request(method=method, url=url, body=body)
