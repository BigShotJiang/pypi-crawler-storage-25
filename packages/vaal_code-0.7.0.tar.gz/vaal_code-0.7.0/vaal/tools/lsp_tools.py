"""LSP-like code intelligence tools — grep/glob based, no LSP server needed."""

import os
import re
import subprocess

from .registry import register_tool


def _run_grep(pattern: str, path: str, extra_args: list[str] | None = None) -> list[str]:
    """Run a grep/findstr search and return matching lines."""
    path = os.path.abspath(path)

    # Try ripgrep first, then grep, then findstr (Windows)
    for cmd_name in ("rg", "grep"):
        try:
            args = [cmd_name, "-rn", "--no-heading"]
            if extra_args:
                args.extend(extra_args)
            args.extend([pattern, path])
            result = subprocess.run(
                args,
                capture_output=True, text=True, timeout=15,
                cwd=os.getcwd(),
            )
            if result.returncode <= 1:  # 0=found, 1=not found
                return [l for l in result.stdout.splitlines() if l.strip()]
        except FileNotFoundError:
            continue
        except subprocess.TimeoutExpired:
            return ["Error: search timed out"]

    # Fallback: pure Python walk
    return _python_grep(pattern, path)


def _python_grep(pattern: str, path: str) -> list[str]:
    """Pure Python recursive grep fallback."""
    results = []
    try:
        pat = re.compile(pattern)
    except re.error:
        pat = re.compile(re.escape(pattern))

    target = os.path.abspath(path)
    if os.path.isfile(target):
        walk_targets = [(os.path.dirname(target), [], [os.path.basename(target)])]
    else:
        walk_targets = os.walk(target)

    skip_dirs = {".git", "__pycache__", "node_modules", ".venv", "venv", ".tox", "build", "dist"}
    text_exts = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rs", ".c", ".cpp", ".h",
                 ".hpp", ".rb", ".php", ".swift", ".kt", ".scala", ".sh", ".bash", ".zsh",
                 ".css", ".html", ".xml", ".json", ".yaml", ".yml", ".toml", ".md", ".txt",
                 ".brs", ".xml"}

    count = 0
    for root, dirs, files in walk_targets:
        dirs[:] = [d for d in dirs if d not in skip_dirs]
        for fname in files:
            ext = os.path.splitext(fname)[1].lower()
            if ext not in text_exts:
                continue
            fpath = os.path.join(root, fname)
            try:
                with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                    for i, line in enumerate(f, 1):
                        if pat.search(line):
                            results.append(f"{fpath}:{i}:{line.rstrip()}")
                            count += 1
                            if count >= 200:
                                results.append("... (truncated at 200 matches)")
                                return results
            except (OSError, PermissionError):
                continue
    return results


@register_tool(
    name="find_definition",
    description="Find where a symbol (class, function, variable) is defined in a file or directory. Searches for def/class/const/let/var/function patterns.",
    parameters={
        "symbol": {"description": "The symbol name to find the definition of", "required": True},
        "path": {"description": "File or directory to search in (default: current directory)", "required": False},
    },
)
def find_definition(symbol: str, path: str = ".", **kwargs) -> str:
    path = os.path.abspath(path)

    # Build a pattern that matches common definition forms
    patterns = [
        rf"(def|class|function|const|let|var|export\s+(?:default\s+)?(?:function|class|const|let|var))\s+{re.escape(symbol)}\b",
        rf"^\s*{re.escape(symbol)}\s*=",  # Python/JS assignment at module level
        rf"(type|interface|enum|struct)\s+{re.escape(symbol)}\b",  # Type definitions
    ]

    all_results = []
    for pat in patterns:
        matches = _run_grep(pat, path)
        all_results.extend(matches)

    if not all_results:
        return f"No definition found for '{symbol}' in {path}"

    # Deduplicate
    seen = set()
    unique = []
    for line in all_results:
        if line not in seen:
            seen.add(line)
            unique.append(line)

    return "\n".join(unique[:50])


@register_tool(
    name="find_references",
    description="Find all references to a symbol in a file or directory.",
    parameters={
        "symbol": {"description": "The symbol name to find references for", "required": True},
        "path": {"description": "File or directory to search in (default: current directory)", "required": False},
    },
)
def find_references(symbol: str, path: str = ".", **kwargs) -> str:
    path = os.path.abspath(path)
    pattern = rf"\b{re.escape(symbol)}\b"
    results = _run_grep(pattern, path)

    if not results:
        return f"No references found for '{symbol}' in {path}"

    if len(results) > 100:
        results = results[:100]
        results.append(f"... (showing first 100 of many matches)")

    return "\n".join(results)


@register_tool(
    name="list_symbols",
    description="List all classes, functions, and top-level assignments in a file.",
    parameters={
        "file_path": {"description": "Path to the source file to analyze", "required": True},
    },
)
def list_symbols(file_path: str, **kwargs) -> str:
    file_path = os.path.abspath(file_path)

    if not os.path.isfile(file_path):
        return f"File not found: {file_path}"

    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except (OSError, PermissionError) as e:
        return f"Error reading file: {e}"

    ext = os.path.splitext(file_path)[1].lower()
    symbols = {"classes": [], "functions": [], "variables": []}

    lines = content.splitlines()
    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        if ext in (".py",):
            # Python
            m = re.match(r"^class\s+(\w+)", line)
            if m:
                symbols["classes"].append((m.group(1), i))
                continue
            m = re.match(r"^(?:async\s+)?def\s+(\w+)", line)
            if m:
                symbols["functions"].append((m.group(1), i))
                continue
            m = re.match(r"^([A-Z_][A-Z_0-9]*)\s*=", line)
            if m:
                symbols["variables"].append((m.group(1), i))
                continue

        elif ext in (".js", ".ts", ".jsx", ".tsx"):
            # JavaScript/TypeScript
            m = re.match(r"^(?:export\s+)?class\s+(\w+)", stripped)
            if m:
                symbols["classes"].append((m.group(1), i))
                continue
            m = re.match(r"^(?:export\s+)?(?:async\s+)?function\s+(\w+)", stripped)
            if m:
                symbols["functions"].append((m.group(1), i))
                continue
            m = re.match(r"^(?:export\s+)?(?:const|let|var)\s+(\w+)", stripped)
            if m:
                symbols["variables"].append((m.group(1), i))
                continue

        elif ext in (".java", ".kt"):
            m = re.match(r".*\bclass\s+(\w+)", stripped)
            if m:
                symbols["classes"].append((m.group(1), i))
                continue
            m = re.match(r".*\b(?:public|private|protected|static|void|int|String|boolean|fun)\s+(\w+)\s*\(", stripped)
            if m:
                symbols["functions"].append((m.group(1), i))
                continue

        elif ext in (".go",):
            m = re.match(r"^type\s+(\w+)\s+struct", stripped)
            if m:
                symbols["classes"].append((m.group(1), i))
                continue
            m = re.match(r"^func\s+(?:\([^)]*\)\s+)?(\w+)", stripped)
            if m:
                symbols["functions"].append((m.group(1), i))
                continue

        elif ext in (".rs",):
            m = re.match(r"^(?:pub\s+)?struct\s+(\w+)", stripped)
            if m:
                symbols["classes"].append((m.group(1), i))
                continue
            m = re.match(r"^(?:pub\s+)?(?:async\s+)?fn\s+(\w+)", stripped)
            if m:
                symbols["functions"].append((m.group(1), i))
                continue

        else:
            # Generic: look for common patterns
            m = re.match(r"^(?:class|struct|type|interface|enum)\s+(\w+)", stripped)
            if m:
                symbols["classes"].append((m.group(1), i))
                continue
            m = re.match(r"^(?:def|func|function|fn|sub)\s+(\w+)", stripped)
            if m:
                symbols["functions"].append((m.group(1), i))
                continue

    parts = []
    for category, items in symbols.items():
        if items:
            parts.append(f"{category}:")
            for name, lineno in items:
                parts.append(f"  {name} (line {lineno})")
    if not parts:
        return f"No symbols found in {file_path}"
    return "\n".join(parts)


@register_tool(
    name="file_tree",
    description="Show project directory tree. Cross-platform, no external dependencies.",
    parameters={
        "path": {"description": "Root directory (default: current directory)", "required": False},
        "max_depth": {"description": "Maximum depth to traverse (default: 3)", "required": False},
        "show_files": {"description": "Show files, not just directories (default: true)", "required": False},
    },
)
def file_tree(path: str = ".", max_depth: str | int = 3, show_files: str | bool = True, **kwargs) -> str:
    path = os.path.abspath(path)
    max_depth = int(max_depth) if max_depth else 3
    if isinstance(show_files, str):
        show_files = show_files.lower() not in ("false", "0", "no")

    skip_dirs = {".git", "__pycache__", "node_modules", ".venv", "venv", ".tox",
                 "build", "dist", ".next", ".cache", ".pytest_cache", ".mypy_cache",
                 "out", "target", ".idea", ".vscode"}

    lines = [os.path.basename(path) + "/"]
    _tree_recurse(path, "", max_depth, 0, show_files, skip_dirs, lines)

    if len(lines) > 500:
        lines = lines[:500]
        lines.append("... (truncated at 500 entries)")

    return "\n".join(lines)


def _tree_recurse(dirpath: str, prefix: str, max_depth: int, depth: int,
                  show_files: bool, skip_dirs: set, lines: list):
    if depth >= max_depth:
        return

    try:
        entries = sorted(os.listdir(dirpath))
    except (OSError, PermissionError):
        return

    dirs = [e for e in entries if os.path.isdir(os.path.join(dirpath, e)) and e not in skip_dirs]
    files = [e for e in entries if os.path.isfile(os.path.join(dirpath, e))] if show_files else []

    items = [(d, True) for d in dirs] + [(f, False) for f in files]

    for idx, (name, is_dir) in enumerate(items):
        is_last = idx == len(items) - 1
        connector = "└── " if is_last else "├── "
        display = name + "/" if is_dir else name
        lines.append(f"{prefix}{connector}{display}")

        if is_dir:
            extension = "    " if is_last else "│   "
            _tree_recurse(
                os.path.join(dirpath, name),
                prefix + extension,
                max_depth, depth + 1,
                show_files, skip_dirs, lines,
            )
