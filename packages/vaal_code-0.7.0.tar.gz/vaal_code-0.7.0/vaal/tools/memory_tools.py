"""Memory tools — let the LLM save, search, and list persistent memories."""

from .registry import register_tool


@register_tool(
    name="save_memory",
    description="Save a persistent memory entry. Memories persist across sessions and are auto-loaded into context. Use this to remember user preferences, project details, important findings, or feedback.",
    parameters={
        "name": {"description": "Short descriptive name for the memory (e.g. 'user prefers tabs')", "required": True},
        "content": {"description": "The memory content (markdown supported)", "required": True},
        "type": {"description": "Memory type: user, feedback, project, or reference (default: user)", "required": False},
        "description": {"description": "One-line description of what this memory captures", "required": False},
    },
)
def save_memory_tool(name: str, content: str, type: str = "user", description: str = "", **kwargs) -> str:
    from vaal.core.memory import MemoryStore
    try:
        store = MemoryStore()
        entry = store.save_memory(name=name, content=content, type=type, description=description)
        return f"Memory saved: '{entry.name}' (type={entry.type})"
    except Exception as e:
        return f"[error saving memory: {e}]"


@register_tool(
    name="search_memory",
    description="Search through persistent memories by keyword. Returns matching memories ranked by relevance.",
    parameters={
        "query": {"description": "Search query (keywords to match against memory names, descriptions, and content)", "required": True},
    },
)
def search_memory_tool(query: str, **kwargs) -> str:
    from vaal.core.memory import MemoryStore
    try:
        store = MemoryStore()
        results = store.search_memory(query)
        if not results:
            return "(no memories match that query)"

        lines = []
        for entry in results[:10]:
            lines.append(f"## {entry.name} ({entry.type})")
            if entry.description:
                lines.append(f"  {entry.description}")
            # Show first 200 chars of content
            preview = entry.content[:200]
            if len(entry.content) > 200:
                preview += "..."
            lines.append(f"  {preview}")
            lines.append("")
        return "\n".join(lines)
    except Exception as e:
        return f"[error searching memories: {e}]"


@register_tool(
    name="list_memories",
    description="List all persistent memories. Shows name, type, and description for each.",
    parameters={
        "type": {"description": "Filter by type: user, feedback, project, or reference (default: all)", "required": False},
    },
)
def list_memories_tool(type: str = "", **kwargs) -> str:
    from vaal.core.memory import MemoryStore
    try:
        store = MemoryStore()
        type_filter = type if type else None
        entries = store.list_memories(type_filter=type_filter)
        if not entries:
            return "(no memories saved)"

        lines = []
        for entry in entries:
            desc = f" - {entry.description}" if entry.description else ""
            lines.append(f"  {entry.name} [{entry.type}]{desc}")
        return "\n".join(lines)
    except Exception as e:
        return f"[error listing memories: {e}]"
