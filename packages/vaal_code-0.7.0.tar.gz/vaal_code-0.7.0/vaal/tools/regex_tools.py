"""Regex tools — build and test regular expressions."""

import re
from typing import Optional

from .registry import register_tool


@register_tool(
    name="build_regex",
    description="Build a regular expression from an English description. Returns the regex pattern and an explanation of what it matches.",
    parameters={
        "description": {
            "description": "English description of what to match (e.g. 'email addresses', 'URLs starting with https', 'phone numbers with optional country code')",
            "required": True,
        },
        "flavor": {
            "description": "Regex flavor: python (default), javascript, or pcre",
            "required": False,
        },
    },
)
def build_regex(description: str, flavor: str = "python", **kwargs) -> str:
    """Build a regex from description. The LLM typically handles this,
    but we provide common patterns as a fast path."""

    # Common pattern library for instant results
    patterns = {
        "email": {
            "pattern": r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}",
            "explanation": "Matches standard email addresses: local@domain.tld",
        },
        "url": {
            "pattern": r"https?://[^\s<>\"']+",
            "explanation": "Matches HTTP and HTTPS URLs",
        },
        "ip": {
            "pattern": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
            "explanation": "Matches IPv4 addresses (does not validate range 0-255)",
        },
        "ipv4": {
            "pattern": r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b",
            "explanation": "Matches valid IPv4 addresses (0.0.0.0 - 255.255.255.255)",
        },
        "phone": {
            "pattern": r"(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}",
            "explanation": "Matches phone numbers with optional country code, various separators",
        },
        "date": {
            "pattern": r"\d{4}[-/]\d{2}[-/]\d{2}",
            "explanation": "Matches dates in YYYY-MM-DD or YYYY/MM/DD format",
        },
        "time": {
            "pattern": r"\d{1,2}:\d{2}(?::\d{2})?(?:\s*[APap][Mm])?",
            "explanation": "Matches times like 12:30, 9:00:00, 3:45 PM",
        },
        "hex color": {
            "pattern": r"#(?:[0-9a-fA-F]{3}){1,2}\b",
            "explanation": "Matches hex color codes (#FFF or #FFFFFF)",
        },
        "uuid": {
            "pattern": r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}",
            "explanation": "Matches UUID format (xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx)",
        },
        "semver": {
            "pattern": r"\bv?\d+\.\d+\.\d+(?:-[a-zA-Z0-9.]+)?(?:\+[a-zA-Z0-9.]+)?\b",
            "explanation": "Matches semantic version numbers (e.g., 1.2.3, v2.0.0-beta.1)",
        },
        "mac address": {
            "pattern": r"(?:[0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}",
            "explanation": "Matches MAC addresses (AA:BB:CC:DD:EE:FF or AA-BB-CC-DD-EE-FF)",
        },
        "slug": {
            "pattern": r"[a-z0-9]+(?:-[a-z0-9]+)*",
            "explanation": "Matches URL slugs (lowercase-words-separated-by-hyphens)",
        },
        "variable": {
            "pattern": r"[a-zA-Z_]\w*",
            "explanation": "Matches valid variable names (letter or underscore, then word chars)",
        },
        "integer": {
            "pattern": r"-?\d+",
            "explanation": "Matches integers with optional negative sign",
        },
        "float": {
            "pattern": r"-?\d+\.?\d*(?:[eE][+-]?\d+)?",
            "explanation": "Matches floating point numbers with optional scientific notation",
        },
        "html tag": {
            "pattern": r"<([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>.*?</\1>",
            "explanation": "Matches paired HTML tags with content (non-greedy)",
        },
        "import": {
            "pattern": r"^(?:import\s+.+|from\s+\S+\s+import\s+.+)$",
            "explanation": "Matches Python import statements",
        },
    }

    # Check for exact or fuzzy match in pattern library
    desc_lower = description.lower().strip()
    for key, info in patterns.items():
        if key in desc_lower or desc_lower in key:
            result = f"Pattern: {info['pattern']}\n"
            result += f"Explanation: {info['explanation']}\n"
            result += f"Flavor: {flavor}\n"
            # Validate the pattern compiles
            try:
                re.compile(info["pattern"])
                result += "Status: Valid (compiles successfully)"
            except re.error as e:
                result += f"Status: Compile error - {e}"
            return result

    # For descriptions not in our library, return guidance for the LLM
    return (
        f"No built-in pattern for: {description}\n"
        f"Flavor: {flavor}\n\n"
        f"Please construct a regex pattern that matches: {description}\n"
        f"Consider edge cases and provide the pattern with an explanation."
    )


@register_tool(
    name="test_regex",
    description="Test a regular expression against sample strings. Shows matches, groups, and highlights.",
    parameters={
        "pattern": {
            "description": "The regex pattern to test",
            "required": True,
        },
        "test_strings": {
            "description": "Newline-separated strings to test against",
            "required": True,
        },
        "flags": {
            "description": "Regex flags: i (ignorecase), m (multiline), s (dotall), x (verbose). Combine like 'im'.",
            "required": False,
        },
    },
)
def test_regex(pattern: str, test_strings: str, flags: str = "", **kwargs) -> str:
    """Test a regex against sample strings and show results."""

    # Parse flags
    flag_map = {
        "i": re.IGNORECASE,
        "m": re.MULTILINE,
        "s": re.DOTALL,
        "x": re.VERBOSE,
    }
    combined_flags = 0
    for f in flags.lower():
        if f in flag_map:
            combined_flags |= flag_map[f]

    # Compile pattern
    try:
        compiled = re.compile(pattern, combined_flags)
    except re.error as e:
        return f"[regex compile error: {e}]"

    # Test each string
    lines = test_strings.split("\n")
    results = []
    total_matches = 0

    for line in lines:
        if not line:
            continue

        matches = list(compiled.finditer(line))

        if matches:
            total_matches += len(matches)
            results.append(f"  MATCH: {line!r}")
            for i, m in enumerate(matches):
                results.append(f"    [{i}] Full match: {m.group()!r} (span {m.start()}-{m.end()})")
                # Show named groups
                if m.groupdict():
                    for name, val in m.groupdict().items():
                        if val is not None:
                            results.append(f"        {name} = {val!r}")
                # Show numbered groups
                elif m.groups():
                    for gi, g in enumerate(m.groups(), 1):
                        if g is not None:
                            results.append(f"        group({gi}) = {g!r}")

            # Show highlighted version (mark matches with brackets)
            highlighted = line
            offset = 0
            for m in matches:
                start = m.start() + offset
                end = m.end() + offset
                highlighted = highlighted[:start] + ">>>" + highlighted[start:end] + "<<<" + highlighted[end:]
                offset += 6  # len(">>>") + len("<<<")
            results.append(f"    Highlighted: {highlighted}")
        else:
            results.append(f"  NO MATCH: {line!r}")

    # Summary
    summary = [
        f"Pattern: /{pattern}/{flags}",
        f"Tested: {len([l for l in lines if l])} strings",
        f"Total matches: {total_matches}",
        "",
    ]

    return "\n".join(summary + results)
