"""Plugin tools — let the LLM create, manage, and hot-load plugins for the user."""

import json
import os
import importlib
import sys
from pathlib import Path

from .registry import register_tool, _tools
from ..core.config import VAAL_DIR

PLUGINS_DIR = VAAL_DIR / "plugins"


@register_tool(
    name="create_plugin",
    description=(
        "Create a new vaal plugin from a user's request. Generates a Python file in "
        "~/.vaal/plugins/ that registers custom tools. The plugin is hot-loaded immediately "
        "so the new tools are available right away.\n\n"
        "The 'tools' parameter is a JSON array of tool definitions. Each tool has:\n"
        "- name: unique tool name\n"
        "- description: what the tool does\n"
        "- parameters: dict of param_name -> {description, required}\n"
        "- code: the Python function body (will be wrapped in a function)\n"
        "- dangerous: whether it needs user approval (default false)\n\n"
        "Example tools value:\n"
        '[{"name": "word_count", "description": "Count words in a file", '
        '"parameters": {"path": {"description": "File path", "required": true}}, '
        '"code": "content = open(path).read()\\nreturn str(len(content.split()))", '
        '"dangerous": false}]'
    ),
    parameters={
        "plugin_name": {
            "description": "Name for the plugin (lowercase, no spaces). E.g. 'text_utils', 'docker_helper'.",
            "required": True,
        },
        "description": {
            "description": "One-line description of what this plugin does.",
            "required": True,
        },
        "tools": {
            "description": "JSON array of tool definitions (see tool description for format).",
            "required": True,
        },
        "imports": {
            "description": "Optional Python import statements needed by the tools (one per line).",
            "required": False,
        },
    },
)
def create_plugin(plugin_name: str, description: str, tools: str, imports: str = "") -> str:
    """Generate and hot-load a plugin."""
    # Validate name
    name = plugin_name.strip().lower().replace(" ", "_").replace("-", "_")
    if not name.isidentifier():
        return json.dumps({"error": f"Invalid plugin name: {name}. Must be a valid Python identifier."})

    # Parse tools
    try:
        if isinstance(tools, str):
            tool_defs = json.loads(tools)
        else:
            tool_defs = tools
    except json.JSONDecodeError as e:
        return json.dumps({"error": f"Invalid tools JSON: {e}"})

    if not isinstance(tool_defs, list) or not tool_defs:
        return json.dumps({"error": "tools must be a non-empty JSON array of tool definitions."})

    # Build the plugin source code
    lines = [
        f'"""{description}"""',
        "",
    ]

    # Add imports
    if imports:
        for imp in imports.strip().splitlines():
            imp = imp.strip()
            if imp:
                lines.append(imp)
        lines.append("")

    lines.append("")
    lines.append("def register(registry):")
    lines.append(f'    """{description}"""')

    for tdef in tool_defs:
        tname = tdef.get("name", "unnamed_tool")
        tdesc = tdef.get("description", "")
        tparams = tdef.get("parameters", {})
        tcode = tdef.get("code", "return 'not implemented'")
        tdangerous = tdef.get("dangerous", False)

        # Build parameter signature
        param_names = list(tparams.keys())
        sig = ", ".join(f"{p}: str" for p in param_names) if param_names else ""

        # Build parameter schema
        param_schema_lines = []
        for pname, pinfo in tparams.items():
            if isinstance(pinfo, dict):
                pdesc = pinfo.get("description", "")
                preq = pinfo.get("required", False)
            else:
                pdesc = str(pinfo)
                preq = True
            req_str = "True" if preq else "False"
            param_schema_lines.append(
                f'            "{pname}": {{"description": "{pdesc}", "required": {req_str}}},'
            )

        lines.append("")
        lines.append(f"    def {tname}({sig}) -> str:")
        lines.append(f'        """{tdesc}"""')
        # Indent the user's code
        for code_line in tcode.splitlines():
            lines.append(f"        {code_line}")
        lines.append("")

        # Register call
        lines.append(f"    registry.register_tool(")
        lines.append(f'        name="{tname}",')
        lines.append(f'        description="""{tdesc}""",')
        lines.append(f"        parameters={{")
        for ps_line in param_schema_lines:
            lines.append(ps_line)
        lines.append(f"        }},")
        lines.append(f"        handler={tname},")
        lines.append(f"        dangerous={tdangerous},")
        lines.append(f"    )")

    source = "\n".join(lines) + "\n"

    # Save the plugin
    PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
    plugin_path = PLUGINS_DIR / f"{name}.py"

    # Check for existing plugin
    overwritten = plugin_path.exists()
    plugin_path.write_text(source, encoding="utf-8")

    # Hot-load the plugin
    load_errors = []
    try:
        from ..core.plugins import PluginRegistry
        registry = PluginRegistry()
        module_name = f"vaal_plugin_{name}"

        # Remove old module if reloading
        if module_name in sys.modules:
            del sys.modules[module_name]

        spec = importlib.util.spec_from_file_location(module_name, plugin_path)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)

            register_fn = getattr(module, "register", None)
            if register_fn:
                register_fn(registry)
            else:
                load_errors.append("Plugin has no register() function")
    except Exception as e:
        load_errors.append(str(e))

    # Build result
    tool_names = [t.get("name", "?") for t in tool_defs]
    result = {
        "plugin": name,
        "path": str(plugin_path),
        "tools_created": tool_names,
        "overwritten": overwritten,
        "hot_loaded": len(load_errors) == 0,
        "total_tools": len(_tools),
    }
    if load_errors:
        result["load_errors"] = load_errors
        result["message"] = f"Plugin saved but failed to load: {'; '.join(load_errors)}"
    else:
        result["message"] = f"Plugin '{name}' created with {len(tool_names)} tool(s): {', '.join(tool_names)}. Available now."

    return json.dumps(result, indent=2)


@register_tool(
    name="delete_plugin",
    description="Delete a plugin by name, removing its file and unregistering its tools.",
    parameters={
        "plugin_name": {
            "description": "Name of the plugin to delete.",
            "required": True,
        },
    },
    dangerous=True,
)
def delete_plugin(plugin_name: str) -> str:
    """Delete a plugin and unregister its tools."""
    name = plugin_name.strip().lower().replace(" ", "_").replace("-", "_")
    plugin_path = PLUGINS_DIR / f"{name}.py"

    if not plugin_path.exists():
        return json.dumps({"error": f"Plugin '{name}' not found at {plugin_path}"})

    # Find tools registered by this plugin
    import re
    try:
        content = plugin_path.read_text(encoding="utf-8")
        tool_names = re.findall(r'name="([^"]+)"', content)
        removed = []
        for tn in tool_names:
            if tn in _tools:
                del _tools[tn]
                removed.append(tn)
    except Exception:
        removed = []

    plugin_path.unlink()

    # Clean up module
    module_name = f"vaal_plugin_{name}"
    if module_name in sys.modules:
        del sys.modules[module_name]

    return json.dumps({
        "plugin": name,
        "deleted": True,
        "tools_removed": removed,
        "message": f"Plugin '{name}' deleted. Removed tools: {', '.join(removed) if removed else 'none'}.",
    }, indent=2)


@register_tool(
    name="list_plugins",
    description="List all installed plugins and their tools.",
    parameters={},
)
def list_plugins_tool() -> str:
    """List all plugins."""
    if not PLUGINS_DIR.exists():
        return json.dumps({"plugins": [], "message": "No plugins directory."})

    plugins = []
    for p in sorted(PLUGINS_DIR.glob("*.py")):
        if p.name.startswith("_"):
            continue
        try:
            content = p.read_text(encoding="utf-8")
            import re
            import ast
            tool_names = re.findall(r'name="([^"]+)"', content)
            try:
                tree = ast.parse(content)
                docstring = ast.get_docstring(tree) or ""
            except Exception:
                docstring = ""
            plugins.append({
                "name": p.stem,
                "description": docstring,
                "tools": tool_names,
                "size": p.stat().st_size,
            })
        except Exception as e:
            plugins.append({"name": p.stem, "error": str(e)})

    return json.dumps({
        "plugins": plugins,
        "count": len(plugins),
        "message": f"{len(plugins)} plugin(s) installed.",
    }, indent=2)
