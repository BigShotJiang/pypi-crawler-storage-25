"""Database tools — query SQLite, MySQL, PostgreSQL databases."""

import os
import json
import sqlite3
from .registry import register_tool


class DatabaseConnection:
    """Manages a database connection from a connection string.

    Supported formats:
        sqlite:///path/to/db.sqlite
        sqlite:///relative.db
        mysql://user:pass@host:port/dbname
        postgresql://user:pass@host:port/dbname
        postgres://user:pass@host:port/dbname
    """

    def __init__(self):
        self.conn = None
        self.db_type: str = ""  # "sqlite", "mysql", "postgresql"
        self.connection_string: str = ""
        self._dsn_parts: dict = {}

    def connect(self, connection_string: str) -> str:
        """Connect to a database. Returns status message."""
        self.close()
        self.connection_string = connection_string

        if connection_string.startswith("sqlite"):
            return self._connect_sqlite(connection_string)
        elif connection_string.startswith("mysql"):
            return self._connect_mysql(connection_string)
        elif connection_string.startswith("postgres"):
            return self._connect_postgres(connection_string)
        else:
            # Try as plain file path (assume SQLite)
            if os.path.isfile(connection_string) or connection_string.endswith((".db", ".sqlite", ".sqlite3")):
                return self._connect_sqlite(f"sqlite:///{connection_string}")
            return f"Unsupported connection string: {connection_string}"

    def close(self):
        """Close the current connection."""
        if self.conn:
            try:
                self.conn.close()
            except Exception:
                pass
            self.conn = None
            self.db_type = ""

    @property
    def is_connected(self) -> bool:
        return self.conn is not None

    def execute(self, query: str, params: tuple = ()) -> tuple[list[str], list[list]]:
        """Execute a query. Returns (column_names, rows)."""
        if not self.conn:
            raise RuntimeError("Not connected. Use /db connect <connection_string> first.")

        if self.db_type == "sqlite":
            return self._execute_sqlite(query, params)
        elif self.db_type == "mysql":
            return self._execute_mysql(query, params)
        elif self.db_type == "postgresql":
            return self._execute_postgres(query, params)
        raise RuntimeError(f"Unknown db_type: {self.db_type}")

    def list_tables(self) -> list[str]:
        """List all tables in the database."""
        if not self.conn:
            raise RuntimeError("Not connected.")

        if self.db_type == "sqlite":
            cols, rows = self._execute_sqlite(
                "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
            )
            return [r[0] for r in rows]
        elif self.db_type == "mysql":
            cols, rows = self._execute_mysql("SHOW TABLES")
            return [r[0] for r in rows]
        elif self.db_type == "postgresql":
            cols, rows = self._execute_postgres(
                "SELECT tablename FROM pg_tables WHERE schemaname = 'public' ORDER BY tablename"
            )
            return [r[0] for r in rows]
        return []

    def table_schema(self, table: str) -> str:
        """Get the schema for a specific table."""
        if not self.conn:
            raise RuntimeError("Not connected.")

        if self.db_type == "sqlite":
            cols, rows = self._execute_sqlite(f"PRAGMA table_info('{table}')")
            if not rows:
                return f"Table '{table}' not found."
            lines = [f"Table: {table}", f"{'Column':<25} {'Type':<15} {'Nullable':<10} {'Default':<15} {'PK'}"]
            lines.append("-" * 75)
            for row in rows:
                # cid, name, type, notnull, dflt_value, pk
                nullable = "NO" if row[3] else "YES"
                default = str(row[4]) if row[4] is not None else ""
                pk = "PK" if row[5] else ""
                lines.append(f"{row[1]:<25} {row[2]:<15} {nullable:<10} {default:<15} {pk}")
            return "\n".join(lines)

        elif self.db_type == "mysql":
            cols, rows = self._execute_mysql(f"DESCRIBE `{table}`")
            if not rows:
                return f"Table '{table}' not found."
            lines = [f"Table: {table}"]
            header = "  ".join(f"{c:<20}" for c in cols)
            lines.append(header)
            lines.append("-" * len(header))
            for row in rows:
                lines.append("  ".join(f"{str(v):<20}" for v in row))
            return "\n".join(lines)

        elif self.db_type == "postgresql":
            query = (
                "SELECT column_name, data_type, is_nullable, column_default "
                "FROM information_schema.columns "
                f"WHERE table_name = '{table}' AND table_schema = 'public' "
                "ORDER BY ordinal_position"
            )
            cols, rows = self._execute_postgres(query)
            if not rows:
                return f"Table '{table}' not found."
            lines = [f"Table: {table}", f"{'Column':<25} {'Type':<20} {'Nullable':<10} {'Default'}"]
            lines.append("-" * 75)
            for row in rows:
                lines.append(f"{row[0]:<25} {row[1]:<20} {row[2]:<10} {str(row[3] or '')}")
            return "\n".join(lines)

        return "Unsupported database type."

    # ── SQLite ────────────────────────────────────────────────────────

    def _connect_sqlite(self, conn_str: str) -> str:
        db_path = conn_str.replace("sqlite:///", "").replace("sqlite://", "")
        if not db_path:
            return "SQLite path is empty."
        abs_path = os.path.abspath(db_path)
        try:
            self.conn = sqlite3.connect(abs_path)
            self.db_type = "sqlite"
            return f"Connected to SQLite: {abs_path}"
        except Exception as e:
            return f"SQLite connection failed: {e}"

    def _execute_sqlite(self, query: str, params: tuple = ()) -> tuple[list[str], list[list]]:
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        if cursor.description:
            cols = [desc[0] for desc in cursor.description]
            rows = [list(row) for row in cursor.fetchall()]
        else:
            self.conn.commit()
            cols = ["affected_rows"]
            rows = [[cursor.rowcount]]
        return cols, rows

    # ── MySQL ─────────────────────────────────────────────────────────

    def _connect_mysql(self, conn_str: str) -> str:
        try:
            import pymysql
        except ImportError:
            return "MySQL support requires pymysql: pip install pymysql"
        parts = self._parse_dsn(conn_str)
        try:
            self.conn = pymysql.connect(
                host=parts.get("host", "localhost"),
                port=int(parts.get("port", 3306)),
                user=parts.get("user", "root"),
                password=parts.get("password", ""),
                database=parts.get("database", ""),
                charset="utf8mb4",
            )
            self.db_type = "mysql"
            return f"Connected to MySQL: {parts.get('host')}:{parts.get('port')}/{parts.get('database')}"
        except Exception as e:
            return f"MySQL connection failed: {e}"

    def _execute_mysql(self, query: str, params: tuple = ()) -> tuple[list[str], list[list]]:
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        if cursor.description:
            cols = [desc[0] for desc in cursor.description]
            rows = [list(row) for row in cursor.fetchall()]
        else:
            self.conn.commit()
            cols = ["affected_rows"]
            rows = [[cursor.rowcount]]
        return cols, rows

    # ── PostgreSQL ────────────────────────────────────────────────────

    def _connect_postgres(self, conn_str: str) -> str:
        try:
            import psycopg2
        except ImportError:
            return "PostgreSQL support requires psycopg2: pip install psycopg2-binary"
        parts = self._parse_dsn(conn_str)
        try:
            self.conn = psycopg2.connect(
                host=parts.get("host", "localhost"),
                port=int(parts.get("port", 5432)),
                user=parts.get("user", "postgres"),
                password=parts.get("password", ""),
                dbname=parts.get("database", ""),
            )
            self.conn.autocommit = True
            self.db_type = "postgresql"
            return f"Connected to PostgreSQL: {parts.get('host')}:{parts.get('port')}/{parts.get('database')}"
        except Exception as e:
            return f"PostgreSQL connection failed: {e}"

    def _execute_postgres(self, query: str, params: tuple = ()) -> tuple[list[str], list[list]]:
        cursor = self.conn.cursor()
        cursor.execute(query, params)
        if cursor.description:
            cols = [desc[0] for desc in cursor.description]
            rows = [list(row) for row in cursor.fetchall()]
        else:
            cols = ["affected_rows"]
            rows = [[cursor.rowcount]]
        return cols, rows

    # ── Helpers ───────────────────────────────────────────────────────

    @staticmethod
    def _parse_dsn(dsn: str) -> dict:
        """Parse a connection string into parts.

        Format: scheme://user:password@host:port/database
        """
        from urllib.parse import urlparse
        parsed = urlparse(dsn)
        return {
            "user": parsed.username or "",
            "password": parsed.password or "",
            "host": parsed.hostname or "localhost",
            "port": parsed.port or (3306 if "mysql" in dsn else 5432),
            "database": parsed.path.lstrip("/") if parsed.path else "",
        }


# ── Module-level singleton ────────────────────────────────────────────

_db: DatabaseConnection | None = None


def get_db() -> DatabaseConnection:
    global _db
    if _db is None:
        _db = DatabaseConnection()
    return _db


# ── Format results as table ──────────────────────────────────────────

def _format_table(columns: list[str], rows: list[list], max_col_width: int = 40) -> str:
    """Format query results as an ASCII table."""
    if not columns:
        return "(no results)"

    # Stringify all values
    str_rows = []
    for row in rows:
        str_rows.append([str(v) if v is not None else "NULL" for v in row])

    # Calculate column widths
    widths = [len(c) for c in columns]
    for row in str_rows:
        for i, val in enumerate(row):
            if i < len(widths):
                widths[i] = max(widths[i], min(len(val), max_col_width))

    def _trunc(val, w):
        if len(val) > w:
            return val[:w-3] + "..."
        return val

    # Header
    header = " | ".join(c.ljust(widths[i]) for i, c in enumerate(columns))
    separator = "-+-".join("-" * widths[i] for i in range(len(columns)))

    lines = [header, separator]
    for row in str_rows[:200]:  # Cap at 200 rows
        line = " | ".join(
            _trunc(row[i] if i < len(row) else "", widths[i]).ljust(widths[i])
            for i in range(len(columns))
        )
        lines.append(line)

    if len(rows) > 200:
        lines.append(f"... ({len(rows) - 200} more rows)")

    lines.append(f"\n({len(rows)} row{'s' if len(rows) != 1 else ''})")
    return "\n".join(lines)


# ── Tool registration ────────────────────────────────────────────────

@register_tool(
    name="db_query",
    description=(
        "Execute a SQL query against the connected database. "
        "Supports SQLite (built-in), MySQL (pymysql), PostgreSQL (psycopg2). "
        "Connect first with /db connect <connection_string>. "
        "Results are formatted as ASCII tables."
    ),
    parameters={
        "query": {"description": "The SQL query to execute", "required": True},
        "connection_string": {
            "description": "Optional connection string to connect before querying (sqlite:///path, mysql://user:pass@host/db, postgresql://...)",
            "required": False,
        },
    },
    dangerous=True,
)
def db_query(query: str, connection_string: str = "", **kwargs) -> str:
    """Execute a SQL query and return formatted results."""
    db = get_db()

    # Auto-connect if connection string provided
    if connection_string:
        msg = db.connect(connection_string)
        if "failed" in msg.lower():
            return msg

    if not db.is_connected:
        return "Not connected to any database. Use /db connect <connection_string> or pass connection_string parameter."

    try:
        cols, rows = db.execute(query)
        return _format_table(cols, rows)
    except Exception as e:
        return f"Query error: {e}"


def handle_db_command(arg: str) -> str:
    """Handle /db slash commands.

    /db connect <connection_string>  - connect to database
    /db tables                       - list tables
    /db schema <table>               - show table schema
    /db <query>                      - execute query
    /db                              - show status
    """
    db = get_db()
    arg = arg.strip()

    if not arg:
        if db.is_connected:
            return f"Connected to {db.db_type}: {db.connection_string}"
        return "Not connected. Use /db connect <connection_string>"

    parts = arg.split(maxsplit=1)
    sub = parts[0].lower()
    sub_arg = parts[1] if len(parts) > 1 else ""

    if sub == "connect":
        if not sub_arg:
            return "Usage: /db connect <connection_string>\nExamples:\n  /db connect sqlite:///mydb.sqlite\n  /db connect mysql://user:pass@localhost/dbname\n  /db connect postgresql://user:pass@localhost/dbname"
        return db.connect(sub_arg)

    elif sub == "disconnect":
        db.close()
        return "Disconnected."

    elif sub == "tables":
        if not db.is_connected:
            return "Not connected. Use /db connect <connection_string> first."
        try:
            tables = db.list_tables()
            if not tables:
                return "No tables found."
            lines = [f"Tables ({len(tables)}):"]
            for t in tables:
                lines.append(f"  {t}")
            return "\n".join(lines)
        except Exception as e:
            return f"Error: {e}"

    elif sub == "schema":
        if not db.is_connected:
            return "Not connected. Use /db connect <connection_string> first."
        if not sub_arg:
            return "Usage: /db schema <table_name>"
        try:
            return db.table_schema(sub_arg)
        except Exception as e:
            return f"Error: {e}"

    else:
        # Treat as raw SQL query
        if not db.is_connected:
            return "Not connected. Use /db connect <connection_string> first."
        try:
            cols, rows = db.execute(arg)
            return _format_table(cols, rows)
        except Exception as e:
            return f"Query error: {e}"
