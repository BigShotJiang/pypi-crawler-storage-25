"""Interaction tools — let the LLM ask the user questions and manage plans."""
import json
from .registry import register_tool


@register_tool(
    name="ask_user",
    description="Ask the user a question and wait for their response. Use when you need clarification or a decision from the user.",
    parameters={
        "question": {"description": "The question to ask the user", "required": True},
    },
)
def ask_user(question: str, **kwargs) -> str:
    """Ask user a question, return their answer."""
    from rich.console import Console
    console = Console()
    console.print(f"\n  [bold]Question:[/] {question}")
    try:
        answer = input("  > ").strip()
        return answer if answer else "(no answer)"
    except (EOFError, KeyboardInterrupt):
        return "(user cancelled)"


@register_tool(
    name="enter_plan_mode",
    description="Switch to planning mode. Create a structured implementation plan before writing code.",
    parameters={
        "title": {"description": "Plan title", "required": True},
        "steps": {"description": "JSON array of step descriptions", "required": True},
    },
)
def enter_plan_mode(title: str, steps: str, **kwargs) -> str:
    import json as _json
    from ..core.plans import create_plan
    try:
        step_list = _json.loads(steps) if isinstance(steps, str) else steps
    except _json.JSONDecodeError:
        step_list = [s.strip() for s in steps.split("\n") if s.strip()]
    plan = create_plan(title=title, step_descriptions=step_list)
    return _json.dumps({"plan_id": plan.title, "steps": len(step_list), "message": f"Plan '{title}' created with {len(step_list)} steps."})


@register_tool(
    name="exit_plan_mode",
    description="Exit planning mode and mark the current plan as complete.",
    parameters={},
)
def exit_plan_mode(**kwargs) -> str:
    from ..core.plans import get_active_plan
    plan = get_active_plan()
    if not plan:
        return json.dumps({"error": "No active plan"})
    # Mark all remaining steps as done
    while plan.progress_pct < 1.0:
        plan.advance()
    plan.save()
    return json.dumps({"message": f"Plan '{plan.title}' completed.", "progress": plan.progress})
