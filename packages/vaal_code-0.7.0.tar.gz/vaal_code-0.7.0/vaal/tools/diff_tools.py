"""Diff tools — show unified diffs and apply patches."""

import difflib
from pathlib import Path

from .registry import register_tool


@register_tool(
    name="show_diff",
    description="Show a unified diff between two files, or between a file and provided content.",
    parameters={
        "file_a": {"description": "Path to the first file (or 'before' file)", "required": True},
        "file_b": {"description": "Path to the second file (optional if 'content_b' given)", "required": False},
        "content_b": {"description": "New content to compare against file_a (alternative to file_b)", "required": False},
        "context_lines": {"description": "Lines of context around changes (default 3)", "required": False},
    },
)
def show_diff(file_a: str, file_b: str = "", content_b: str = "", context_lines: str | int = 3, **kwargs) -> str:
    n = int(context_lines) if context_lines else 3

    try:
        path_a = Path(file_a)
        if not path_a.exists():
            return f"[error: file not found: {file_a}]"
        lines_a = path_a.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
        label_a = file_a
    except Exception as e:
        return f"[error reading {file_a}: {e}]"

    if file_b:
        try:
            path_b = Path(file_b)
            if not path_b.exists():
                return f"[error: file not found: {file_b}]"
            lines_b = path_b.read_text(encoding="utf-8", errors="replace").splitlines(keepends=True)
            label_b = file_b
        except Exception as e:
            return f"[error reading {file_b}: {e}]"
    elif content_b:
        lines_b = content_b.splitlines(keepends=True)
        label_b = f"{file_a} (modified)"
    else:
        return "[error: provide either file_b or content_b]"

    diff = difflib.unified_diff(lines_a, lines_b, fromfile=label_a, tofile=label_b, n=n)
    result = "".join(diff)
    return result[:50000] or "(no differences)"


@register_tool(
    name="apply_patch",
    description="Apply a unified diff patch to a file. DANGEROUS — modifies files.",
    parameters={
        "file_path": {"description": "Path to the file to patch", "required": True},
        "patch": {"description": "The unified diff patch text to apply", "required": True},
    },
    dangerous=True,
)
def apply_patch(file_path: str, patch: str, **kwargs) -> str:
    """Apply a unified diff patch to a file.

    Parses hunks from unified diff format and applies them sequentially.
    """
    try:
        path = Path(file_path)
        if not path.exists():
            return f"[error: file not found: {file_path}]"

        original = path.read_text(encoding="utf-8", errors="replace").splitlines()
        result = list(original)

        # Parse hunks from the patch
        hunks = []
        current_hunk = None
        for line in patch.splitlines():
            # Skip file headers
            if line.startswith("---") or line.startswith("+++"):
                continue
            # Hunk header: @@ -start,count +start,count @@
            if line.startswith("@@"):
                import re
                m = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", line)
                if m:
                    current_hunk = {
                        "old_start": int(m.group(1)),
                        "old_count": int(m.group(2) or 1),
                        "new_start": int(m.group(3)),
                        "new_count": int(m.group(4) or 1),
                        "lines": [],
                    }
                    hunks.append(current_hunk)
                continue
            if current_hunk is not None:
                current_hunk["lines"].append(line)

        if not hunks:
            return "[error: no valid hunks found in patch]"

        # Apply hunks in reverse order so line numbers stay valid
        hunks.reverse()
        for hunk in hunks:
            old_start = hunk["old_start"] - 1  # 0-indexed
            # Build old and new line lists from the hunk
            old_lines = []
            new_lines = []
            for line in hunk["lines"]:
                if line.startswith("-"):
                    old_lines.append(line[1:])
                elif line.startswith("+"):
                    new_lines.append(line[1:])
                elif line.startswith(" "):
                    old_lines.append(line[1:])
                    new_lines.append(line[1:])
                else:
                    # Context line without prefix (some patches omit the space)
                    old_lines.append(line)
                    new_lines.append(line)

            # Verify the old lines match
            actual = result[old_start:old_start + len(old_lines)]
            if actual != old_lines:
                # Try fuzzy match (strip trailing whitespace)
                actual_stripped = [l.rstrip() for l in actual]
                old_stripped = [l.rstrip() for l in old_lines]
                if actual_stripped != old_stripped:
                    return (
                        f"[error: patch does not match at line {old_start + 1}. "
                        f"Expected {len(old_lines)} lines starting with: "
                        f"{repr(old_lines[0] if old_lines else '(empty)')}]"
                    )

            # Replace
            result[old_start:old_start + len(old_lines)] = new_lines

        path.write_text("\n".join(result) + ("\n" if original and original[-1] == "" else ""), encoding="utf-8")
        return f"Patch applied to {file_path} ({len(hunks)} hunk{'s' if len(hunks) != 1 else ''})"

    except Exception as e:
        return f"[error: {e}]"
