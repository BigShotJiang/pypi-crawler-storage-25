"""File tools — read, write, edit files."""

import os
from pathlib import Path

from .registry import register_tool


def _record_undo_before(file_path: str, description: str = ""):
    """Record file state before a write/edit for undo support."""
    try:
        from ..core.undo_system import get_undo_system
        undo = get_undo_system()
        undo.record_write(file_path, description)
    except Exception:
        pass


def _record_undo_after(file_path: str):
    """Record file state after a write/edit for undo support."""
    try:
        from ..core.undo_system import get_undo_system
        undo = get_undo_system()
        undo.record_write_complete(file_path)
    except Exception:
        pass


@register_tool(
    name="read",
    description="Read a file's contents. Returns numbered lines. Always read before editing.",
    parameters={
        "file_path": {"description": "Absolute path to the file", "required": True},
        "offset": {"description": "Line number to start from (0-based)", "required": False},
        "limit": {"description": "Max lines to read (default 500)", "required": False},
    },
)
def read_tool(file_path: str, offset: str | int = 0, limit: str | int = 500, **kwargs) -> str:
    offset = int(offset) if offset else 0
    limit = int(limit) if limit else 500
    try:
        path = Path(file_path)
        if not path.exists():
            return f"[error: file not found: {file_path}]"
        if not path.is_file():
            return f"[error: not a file: {file_path}]"

        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
        total = len(lines)
        selected = lines[offset:offset + limit]

        numbered = []
        for i, line in enumerate(selected, start=offset + 1):
            numbered.append(f"{i:>6}\t{line}")

        result = "\n".join(numbered)
        if offset + limit < total:
            result += f"\n\n[... {total - offset - limit} more lines]"
        return result
    except Exception as e:
        return f"[error: {e}]"


@register_tool(
    name="write",
    description="Write content to a file. Creates the file if it doesn't exist. Overwrites if it does.",
    parameters={
        "file_path": {"description": "Absolute path to write to", "required": True},
        "content": {"description": "The content to write", "required": True},
    },
    dangerous=True,
)
def write_tool(file_path: str, content: str, **kwargs) -> str:
    try:
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        _record_undo_before(file_path, f"write {os.path.basename(file_path)}")
        path.write_text(content, encoding="utf-8")
        _record_undo_after(file_path)
        lines = content.count("\n") + 1
        return f"File written: {file_path} ({lines} lines)"
    except Exception as e:
        return f"[error: {e}]"


@register_tool(
    name="edit",
    description="Replace a specific string in a file. The old_string must be unique in the file.",
    parameters={
        "file_path": {"description": "Absolute path to the file", "required": True},
        "old_string": {"description": "The exact text to find and replace", "required": True},
        "new_string": {"description": "The replacement text", "required": True},
    },
    dangerous=True,
)
def edit_tool(file_path: str, old_string: str, new_string: str, **kwargs) -> str:
    try:
        path = Path(file_path)
        if not path.exists():
            return f"[error: file not found: {file_path}]"

        content = path.read_text(encoding="utf-8", errors="replace")
        count = content.count(old_string)

        if count == 0:
            return "[error: old_string not found in file]"
        if count > 1:
            return f"[error: old_string found {count} times — must be unique. Add more context.]"

        _record_undo_before(file_path, f"edit {os.path.basename(file_path)}")
        new_content = content.replace(old_string, new_string, 1)
        path.write_text(new_content, encoding="utf-8")
        _record_undo_after(file_path)
        return f"Edit applied to {file_path}"
    except Exception as e:
        return f"[error: {e}]"
