"""SSH tools -- execute commands on remote hosts via persistent SSH connections."""

from .registry import register_tool


@register_tool(
    name="ssh_exec",
    description="Execute a command on a connected remote host via SSH. Use /ssh connect <user@host> first to establish a connection.",
    parameters={
        "command": {"description": "The shell command to execute on the remote host", "required": True},
        "timeout": {"description": "Command timeout in seconds (default: 30)", "required": False},
    },
    dangerous=True,
)
def ssh_exec(command: str = "", timeout: str = "30", **kwargs) -> str:
    """Execute a command on the connected remote SSH host."""
    if not command:
        return "[error: no command provided]"

    try:
        timeout_int = int(timeout)
    except (ValueError, TypeError):
        timeout_int = 30

    from ..core.ssh_remote import get_ssh_manager

    mgr = get_ssh_manager()
    if not mgr.is_connected:
        return "[error: not connected to any remote host. Use /ssh connect <user@host> first]"

    output, returncode = mgr.run_command(command, timeout=timeout_int)

    result = output if output else "(no output)"
    if returncode != 0:
        result += f"\n[exit code: {returncode}]"
    return result
