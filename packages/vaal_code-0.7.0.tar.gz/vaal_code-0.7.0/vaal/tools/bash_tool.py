"""Bash tool — execute shell commands."""

import subprocess
import os
import threading

from .registry import register_tool

# Track background processes so they can be listed/killed
_bg_processes: list[dict] = []


@register_tool(
    name="bash",
    description=(
        "Execute a shell command and return its output. Use for running tests, git, builds, etc.\n\n"
        "IMPORTANT: For long-running commands (servers, watchers, tails), set background=true. "
        "This starts the process in the background and returns immediately with the PID. "
        "Without background=true, commands that don't exit will freeze for timeout seconds.\n\n"
        "Examples:\n"
        "- background=true: python -m http.server 8000, npm run dev, docker compose up\n"
        "- normal: ls, git status, python script.py, npm test"
    ),
    parameters={
        "command": {"description": "The shell command to execute", "required": True},
        "timeout": {"description": "Timeout in seconds (default 30)", "required": False},
        "background": {"description": "Run in background (for servers/watchers). Returns PID immediately.", "required": False},
    },
    dangerous=True,
)
def bash_tool(command: str, timeout: str | int = 30, background: str = "false", **kwargs) -> str:
    timeout = int(timeout) if timeout else 30
    is_bg = str(background).lower() in ("true", "yes", "1")

    # Auto-detect background intent: trailing & (Unix), or known server commands
    if not is_bg:
        stripped = command.rstrip()
        # Unix-style background operator — doesn't work on Windows
        if stripped.endswith(" &") or stripped.endswith("\t&"):
            is_bg = True
            command = stripped[:-1].rstrip()
        # Common long-running patterns
        elif any(pat in command.lower() for pat in [
            "http.server", "npm run dev", "npm start", "yarn dev",
            "flask run", "uvicorn", "gunicorn", "python -m http",
            "live-server", "serve ", "docker compose up",
            "ngrok", "tail -f",
        ]):
            is_bg = True

    if is_bg:
        return _run_background(command)

    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=os.getcwd(),
            env={**os.environ, "TERM": "dumb"},
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            if output:
                output += "\n"
            output += result.stderr
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output[:50000] or "(no output)"
    except subprocess.TimeoutExpired:
        return f"[command timed out after {timeout}s — use background=true for long-running commands like servers]"
    except Exception as e:
        return f"[error: {e}]"


def _run_background(command: str) -> str:
    """Start a command in background, return immediately with PID."""
    try:
        proc = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=os.getcwd(),
            env={**os.environ, "TERM": "dumb"},
        )
        entry = {
            "pid": proc.pid,
            "command": command[:100],
            "process": proc,
        }
        _bg_processes.append(entry)

        # Capture first few lines of output in background thread
        first_output = []
        def _reader():
            try:
                for i, line in enumerate(proc.stdout):
                    if i < 5:
                        first_output.append(line.decode("utf-8", errors="replace").rstrip())
            except Exception:
                pass
        t = threading.Thread(target=_reader, daemon=True)
        t.start()
        t.join(timeout=1.0)  # Wait 1s for initial output

        result = f"Started in background (PID {proc.pid})\nCommand: {command}"
        if first_output:
            result += "\nInitial output:\n" + "\n".join(first_output)
        return result

    except Exception as e:
        return f"[error starting background process: {e}]"


def list_background() -> list[dict]:
    """List background processes."""
    alive = []
    for entry in _bg_processes:
        proc = entry["process"]
        alive.append({
            "pid": entry["pid"],
            "command": entry["command"],
            "running": proc.poll() is None,
        })
    return alive


def kill_background(pid: int) -> str:
    """Kill a background process by PID."""
    for entry in _bg_processes:
        if entry["pid"] == pid:
            proc = entry["process"]
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()
                return f"Killed PID {pid}"
            else:
                return f"PID {pid} already exited"
    return f"PID {pid} not found"


@register_tool(
    name="powershell",
    description="Execute a PowerShell command (Windows). Use for Windows-specific operations like registry, COM objects, .NET calls, or when PowerShell-specific cmdlets are needed.",
    parameters={
        "command": {"description": "PowerShell command to execute", "required": True},
        "timeout": {"description": "Timeout in seconds (default 30)", "required": False},
    },
    dangerous=True,
)
def powershell_tool(command: str, timeout: str | int = 30, **kwargs) -> str:
    timeout = int(timeout) if timeout else 30
    try:
        result = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", command],
            capture_output=True, text=True, timeout=timeout, cwd=os.getcwd(),
        )
        output = ""
        if result.stdout: output += result.stdout
        if result.stderr:
            if output: output += "\n"
            output += result.stderr
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"
        return output[:50000] or "(no output)"
    except subprocess.TimeoutExpired:
        return f"[command timed out after {timeout}s]"
    except FileNotFoundError:
        return "[error: PowerShell not found on this system]"
    except Exception as e:
        return f"[error: {e}]"
