"""Notebook tools — Jupyter-like Python code execution and .ipynb editing."""

import subprocess
import sys
import os
import json
import tempfile
import textwrap

from .registry import register_tool


def _build_script(code: str) -> str:
    """Wrap user code so we capture stdout, stderr, and the last expression value."""
    # We wrap the code in a script that:
    # 1. Executes all statements
    # 2. Attempts to eval the last expression and print a sentinel + its repr
    lines = code.strip().splitlines()
    if not lines:
        return code

    # Try to detect if the last line is an expression (not assignment, not control flow)
    last_line = lines[-1].strip()
    is_expr = (
        last_line
        and not last_line.startswith(("import ", "from ", "del ", "raise ", "pass", "break", "continue", "return "))
        and "=" not in last_line.split("#")[0].split("(")[0]  # rough heuristic
        and not last_line.endswith(":")
    )

    sentinel = "__VAAL_RESULT_8f3a__"

    if is_expr and len(lines) > 0:
        # Execute all lines except last, then eval the last line
        preamble = "\n".join(lines[:-1])
        script = textwrap.dedent(f"""\
import sys as _sys
try:
{textwrap.indent(preamble, '    ')}
    _result = eval({repr(last_line)})
    if _result is not None:
        print(f"{sentinel}{{repr(_result)}}")
except Exception as _e:
    print(f"Error: {{type(_e).__name__}}: {{_e}}", file=_sys.stderr)
    _sys.exit(1)
""")
    else:
        script = textwrap.dedent(f"""\
import sys as _sys
try:
{textwrap.indent(code, '    ')}
except Exception as _e:
    print(f"Error: {{type(_e).__name__}}: {{_e}}", file=_sys.stderr)
    _sys.exit(1)
""")

    return script


@register_tool(
    name="run_python",
    description="Execute a Python code snippet and return stdout, stderr, and the last expression's value. Uses a subprocess for safety.",
    parameters={
        "code": {"description": "Python code to execute", "required": True},
        "timeout": {"description": "Timeout in seconds (default 30)", "required": False},
    },
)
def run_python(code: str, timeout: str | int = 30, **kwargs) -> str:
    timeout = int(timeout) if timeout else 30

    script = _build_script(code)

    # Write to temp file and execute
    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".py", prefix="vaal_nb_")
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(script)

        result = subprocess.run(
            [sys.executable, tmp_path],
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=os.getcwd(),
        )

        sentinel = "__VAAL_RESULT_8f3a__"
        stdout = result.stdout
        stderr = result.stderr.strip()
        return_value = None

        # Extract the sentinel return value from stdout
        out_lines = []
        for line in stdout.splitlines():
            if line.startswith(sentinel):
                return_value = line[len(sentinel):]
            else:
                out_lines.append(line)

        stdout_clean = "\n".join(out_lines).strip()

        parts = []
        if stdout_clean:
            parts.append(f"stdout:\n{stdout_clean}")
        if stderr:
            parts.append(f"stderr:\n{stderr}")
        if return_value is not None:
            parts.append(f"result: {return_value}")
        if result.returncode != 0 and not stderr:
            parts.append(f"exit code: {result.returncode}")

        if not parts:
            return "(no output)"
        return "\n\n".join(parts)

    except subprocess.TimeoutExpired:
        return f"Error: execution timed out after {timeout}s"
    except Exception as e:
        return f"Error: {type(e).__name__}: {e}"
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


def _read_notebook(path: str) -> tuple[dict | None, str]:
    """Read and parse a .ipynb file. Returns (notebook_dict, error)."""
    try:
        abs_path = os.path.abspath(path)
        with open(abs_path, "r", encoding="utf-8") as f:
            nb = json.load(f)
        if "cells" not in nb:
            return None, f"Invalid notebook format: missing 'cells' key"
        return nb, ""
    except FileNotFoundError:
        return None, f"Notebook not found: {path}"
    except json.JSONDecodeError as e:
        return None, f"Invalid JSON in notebook: {e}"
    except Exception as e:
        return None, f"Error reading notebook: {e}"


def _write_notebook(path: str, nb: dict) -> str:
    """Write a notebook dict to a .ipynb file. Returns error or empty string."""
    try:
        abs_path = os.path.abspath(path)
        with open(abs_path, "w", encoding="utf-8", newline="\n") as f:
            json.dump(nb, f, indent=1, ensure_ascii=False)
            f.write("\n")
        return ""
    except Exception as e:
        return f"Error writing notebook: {e}"


def _format_cell(cell: dict, index: int) -> str:
    """Format a single cell for display."""
    cell_type = cell.get("cell_type", "unknown")
    source = "".join(cell.get("source", []))
    outputs = cell.get("outputs", [])

    lines = [f"--- Cell {index} [{cell_type}] ---"]
    lines.append(source.rstrip())

    if outputs:
        for out in outputs:
            if out.get("output_type") == "stream":
                text = "".join(out.get("text", []))
                lines.append(f"[output] {text.rstrip()}")
            elif out.get("output_type") in ("execute_result", "display_data"):
                data = out.get("data", {})
                if "text/plain" in data:
                    text = "".join(data["text/plain"])
                    lines.append(f"[result] {text.rstrip()}")
            elif out.get("output_type") == "error":
                lines.append(f"[error] {out.get('ename', '')}: {out.get('evalue', '')}")

    return "\n".join(lines)


@register_tool(
    name="notebook_read",
    description=(
        "Read a Jupyter notebook (.ipynb) file and return its cells with content and outputs. "
        "Use this to inspect notebook contents before editing."
    ),
    parameters={
        "path": {
            "description": "Path to the .ipynb file.",
            "required": True,
        },
        "cell_index": {
            "description": "Read only a specific cell by index (0-based). Omit to read all cells.",
            "required": False,
        },
    },
)
def notebook_read(path: str, cell_index: str = "") -> str:
    nb, err = _read_notebook(path)
    if err:
        return f"[error: {err}]"

    cells = nb["cells"]

    if cell_index:
        try:
            idx = int(cell_index)
            if idx < 0 or idx >= len(cells):
                return f"[error: cell index {idx} out of range (0-{len(cells)-1})]"
            return _format_cell(cells[idx], idx)
        except ValueError:
            return f"[error: invalid cell index: {cell_index}]"

    parts = [f"Notebook: {path} ({len(cells)} cells)"]
    for i, cell in enumerate(cells):
        parts.append(_format_cell(cell, i))
    return "\n\n".join(parts)


@register_tool(
    name="notebook_edit",
    description=(
        "Edit a Jupyter notebook (.ipynb) cell. Can insert, replace, or delete cells. "
        "Specify the cell index and the new content. Cell type defaults to 'code'."
    ),
    parameters={
        "path": {
            "description": "Path to the .ipynb file.",
            "required": True,
        },
        "action": {
            "description": "Action: 'replace', 'insert_after', 'insert_before', 'delete'. Default: replace.",
            "required": True,
        },
        "cell_index": {
            "description": "Target cell index (0-based).",
            "required": True,
        },
        "content": {
            "description": "New cell content (source code or markdown). Not needed for delete.",
            "required": False,
        },
        "cell_type": {
            "description": "Cell type: 'code' or 'markdown'. Default: code.",
            "required": False,
        },
    },
)
def notebook_edit(path: str, action: str, cell_index: str, content: str = "", cell_type: str = "code") -> str:
    nb, err = _read_notebook(path)
    if err:
        return f"[error: {err}]"

    cells = nb["cells"]

    try:
        idx = int(cell_index)
    except ValueError:
        return f"[error: invalid cell index: {cell_index}]"

    # Build a new cell
    def _make_cell(src: str, ctype: str) -> dict:
        # Split into lines with newlines preserved (notebook format)
        source_lines = [line + "\n" for line in src.split("\n")]
        if source_lines:
            source_lines[-1] = source_lines[-1].rstrip("\n")  # Last line has no trailing newline
        cell = {
            "cell_type": ctype,
            "metadata": {},
            "source": source_lines,
        }
        if ctype == "code":
            cell["execution_count"] = None
            cell["outputs"] = []
        return cell

    action = action.lower().strip()

    if action == "replace":
        if idx < 0 or idx >= len(cells):
            return f"[error: cell index {idx} out of range (0-{len(cells)-1})]"
        cells[idx] = _make_cell(content, cell_type)

    elif action == "insert_after":
        if idx < -1 or idx >= len(cells):
            return f"[error: cell index {idx} out of range (-1 to {len(cells)-1})]"
        cells.insert(idx + 1, _make_cell(content, cell_type))

    elif action == "insert_before":
        if idx < 0 or idx > len(cells):
            return f"[error: cell index {idx} out of range (0-{len(cells)})]"
        cells.insert(idx, _make_cell(content, cell_type))

    elif action == "delete":
        if idx < 0 or idx >= len(cells):
            return f"[error: cell index {idx} out of range (0-{len(cells)-1})]"
        deleted = cells.pop(idx)
        err = _write_notebook(path, nb)
        if err:
            return f"[error: {err}]"
        return f"Deleted cell {idx} ({deleted.get('cell_type', 'unknown')}). Notebook now has {len(cells)} cells."

    else:
        return f"[error: unknown action '{action}'. Use: replace, insert_after, insert_before, delete]"

    err = _write_notebook(path, nb)
    if err:
        return f"[error: {err}]"

    return f"Notebook updated: {action} at cell {idx}. {len(cells)} cells total."
