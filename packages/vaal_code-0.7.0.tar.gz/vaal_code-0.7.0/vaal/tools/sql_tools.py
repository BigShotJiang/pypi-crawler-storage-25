"""SQL tools — build and explain SQL queries."""

import re

from .registry import register_tool


@register_tool(
    name="build_sql",
    description="Build a SQL query from an English description. Generates standard SQL that works with most databases.",
    parameters={
        "description": {
            "description": "English description of the query (e.g. 'find all users who signed up in the last 30 days and have more than 5 orders')",
            "required": True,
        },
        "dialect": {
            "description": "SQL dialect: standard (default), mysql, postgresql, sqlite",
            "required": False,
        },
        "tables": {
            "description": "Comma-separated table names to use, or a brief schema description (e.g. 'users(id,name,email,created_at), orders(id,user_id,total,created_at)')",
            "required": False,
        },
    },
)
def build_sql(description: str, dialect: str = "standard", tables: str = "", **kwargs) -> str:
    """Build a SQL query from description. Provides structured guidance
    for the LLM to generate the actual query."""

    # Parse table hints if provided
    table_info = ""
    if tables:
        table_info = f"\nAvailable tables/schema: {tables}\n"

    # Common query templates for simple cases
    desc_lower = description.lower().strip()

    # Simple select all
    if re.match(r"^(get|find|show|list|select)\s+(all\s+)?(from\s+)?(\w+)$", desc_lower):
        table = desc_lower.split()[-1]
        return f"SELECT *\nFROM {table};"

    # Count
    if re.match(r"^count\s+(all\s+)?(\w+)$", desc_lower):
        table = desc_lower.split()[-1]
        return f"SELECT COUNT(*)\nFROM {table};"

    # For complex queries, provide structured guidance
    result_parts = [
        f"Query description: {description}",
        f"Dialect: {dialect}",
    ]
    if table_info:
        result_parts.append(table_info)

    # Detect query type from description
    query_type = _detect_query_type(desc_lower)
    result_parts.append(f"Detected query type: {query_type}")

    # Provide the appropriate template
    templates = {
        "select": "SELECT <columns>\nFROM <table>\nWHERE <conditions>\nORDER BY <column> [ASC|DESC]\nLIMIT <n>;",
        "join": "SELECT <columns>\nFROM <table1>\n[INNER|LEFT|RIGHT] JOIN <table2> ON <table1.col> = <table2.col>\nWHERE <conditions>;",
        "aggregate": "SELECT <column>, COUNT(*)|SUM()|AVG()|MAX()|MIN()\nFROM <table>\nWHERE <conditions>\nGROUP BY <column>\nHAVING <aggregate_condition>;",
        "insert": "INSERT INTO <table> (<columns>)\nVALUES (<values>);",
        "update": "UPDATE <table>\nSET <column> = <value>\nWHERE <conditions>;",
        "delete": "DELETE FROM <table>\nWHERE <conditions>;",
        "create": "CREATE TABLE <table> (\n  id SERIAL PRIMARY KEY,\n  <column> <type> [NOT NULL] [DEFAULT <value>],\n  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP\n);",
        "subquery": "SELECT <columns>\nFROM <table>\nWHERE <column> IN (\n  SELECT <column> FROM <table2> WHERE <conditions>\n);",
    }

    template = templates.get(query_type, templates["select"])
    result_parts.append(f"\nTemplate:\n{template}")

    # Dialect-specific notes
    dialect_notes = {
        "mysql": "MySQL notes: Use LIMIT for pagination, backticks for identifiers, AUTO_INCREMENT for serial.",
        "postgresql": "PostgreSQL notes: Use LIMIT/OFFSET, double quotes for identifiers, SERIAL/GENERATED for auto-increment, supports CTEs and window functions.",
        "sqlite": "SQLite notes: Use LIMIT/OFFSET, INTEGER PRIMARY KEY for auto-increment, no ALTER TABLE DROP COLUMN (before 3.35).",
    }
    if dialect.lower() in dialect_notes:
        result_parts.append(f"\n{dialect_notes[dialect.lower()]}")

    return "\n".join(result_parts)


@register_tool(
    name="explain_sql",
    description="Explain what a SQL query does in plain English. Breaks down each clause and identifies potential issues.",
    parameters={
        "query": {
            "description": "The SQL query to explain",
            "required": True,
        },
    },
)
def explain_sql(query: str, **kwargs) -> str:
    """Explain a SQL query by breaking it down into components."""

    query_clean = query.strip().rstrip(";")
    if not query_clean:
        return "[error: empty query]"

    parts = []
    parts.append(f"Query:\n```sql\n{query}\n```\n")

    # Detect query type
    first_word = query_clean.split()[0].upper() if query_clean.split() else ""

    parts.append(f"**Type**: {first_word} statement\n")

    # Parse and explain major clauses
    clauses_found = []

    # SELECT
    select_match = re.search(r'\bSELECT\s+(.*?)(?=\bFROM\b)', query_clean, re.IGNORECASE | re.DOTALL)
    if select_match:
        cols = select_match.group(1).strip()
        if cols == "*":
            clauses_found.append("**SELECT**: All columns")
        else:
            clauses_found.append(f"**SELECT**: Columns/expressions: {cols}")

    # FROM
    from_match = re.search(r'\bFROM\s+(.*?)(?=\bWHERE\b|\bGROUP\b|\bORDER\b|\bLIMIT\b|\bJOIN\b|\bLEFT\b|\bRIGHT\b|\bINNER\b|\bOUTER\b|\bCROSS\b|\bHAVING\b|$)', query_clean, re.IGNORECASE | re.DOTALL)
    if from_match:
        clauses_found.append(f"**FROM**: {from_match.group(1).strip()}")

    # JOINs
    join_matches = re.findall(r'((?:LEFT|RIGHT|INNER|OUTER|CROSS|FULL)?\s*JOIN\s+\S+\s+(?:ON\s+.+?)(?=\bWHERE\b|\bGROUP\b|\bORDER\b|\bLIMIT\b|\bJOIN\b|\bLEFT\b|\bRIGHT\b|$))', query_clean, re.IGNORECASE | re.DOTALL)
    for j in join_matches:
        clauses_found.append(f"**JOIN**: {j.strip()}")

    # WHERE
    where_match = re.search(r'\bWHERE\s+(.*?)(?=\bGROUP\b|\bORDER\b|\bLIMIT\b|\bHAVING\b|$)', query_clean, re.IGNORECASE | re.DOTALL)
    if where_match:
        clauses_found.append(f"**WHERE**: Filters rows where {where_match.group(1).strip()}")

    # GROUP BY
    group_match = re.search(r'\bGROUP\s+BY\s+(.*?)(?=\bHAVING\b|\bORDER\b|\bLIMIT\b|$)', query_clean, re.IGNORECASE | re.DOTALL)
    if group_match:
        clauses_found.append(f"**GROUP BY**: Groups results by {group_match.group(1).strip()}")

    # HAVING
    having_match = re.search(r'\bHAVING\s+(.*?)(?=\bORDER\b|\bLIMIT\b|$)', query_clean, re.IGNORECASE | re.DOTALL)
    if having_match:
        clauses_found.append(f"**HAVING**: Filters groups where {having_match.group(1).strip()}")

    # ORDER BY
    order_match = re.search(r'\bORDER\s+BY\s+(.*?)(?=\bLIMIT\b|$)', query_clean, re.IGNORECASE | re.DOTALL)
    if order_match:
        clauses_found.append(f"**ORDER BY**: Sorts by {order_match.group(1).strip()}")

    # LIMIT
    limit_match = re.search(r'\bLIMIT\s+(\d+)', query_clean, re.IGNORECASE)
    if limit_match:
        clauses_found.append(f"**LIMIT**: Returns at most {limit_match.group(1)} rows")

    # INSERT
    insert_match = re.search(r'\bINSERT\s+INTO\s+(\S+)', query_clean, re.IGNORECASE)
    if insert_match:
        clauses_found.append(f"**INSERT INTO**: Adds rows to `{insert_match.group(1)}`")

    # UPDATE
    update_match = re.search(r'\bUPDATE\s+(\S+)', query_clean, re.IGNORECASE)
    if update_match:
        clauses_found.append(f"**UPDATE**: Modifies rows in `{update_match.group(1)}`")

    # SET
    set_match = re.search(r'\bSET\s+(.*?)(?=\bWHERE\b|$)', query_clean, re.IGNORECASE | re.DOTALL)
    if set_match:
        clauses_found.append(f"**SET**: Changes {set_match.group(1).strip()}")

    # DELETE
    delete_match = re.search(r'\bDELETE\s+FROM\s+(\S+)', query_clean, re.IGNORECASE)
    if delete_match:
        clauses_found.append(f"**DELETE FROM**: Removes rows from `{delete_match.group(1)}`")

    if clauses_found:
        parts.append("**Breakdown:**")
        for clause in clauses_found:
            parts.append(f"- {clause}")

    # Potential issues / warnings
    warnings = []
    if first_word in ("UPDATE", "DELETE") and not where_match:
        warnings.append("WARNING: No WHERE clause on UPDATE/DELETE — this will affect ALL rows!")
    if "SELECT *" in query_clean.upper():
        warnings.append("Note: SELECT * returns all columns — consider specifying only needed columns for performance.")
    if re.search(r"'\s*OR\s+1\s*=\s*1", query_clean, re.IGNORECASE):
        warnings.append("WARNING: Possible SQL injection pattern detected (OR 1=1).")
    if re.search(r'LIKE\s+[\'"]%', query_clean, re.IGNORECASE):
        warnings.append("Note: Leading wildcard in LIKE prevents index usage — may be slow on large tables.")

    if warnings:
        parts.append("\n**Warnings:**")
        for w in warnings:
            parts.append(f"- {w}")

    return "\n".join(parts)


def _detect_query_type(desc: str) -> str:
    """Detect the type of SQL query from a description."""
    desc = desc.lower()

    if any(w in desc for w in ["create", "new table", "define table", "schema"]):
        return "create"
    if any(w in desc for w in ["insert", "add row", "add record", "add new"]):
        return "insert"
    if any(w in desc for w in ["update", "change", "modify", "set"]):
        return "update"
    if any(w in desc for w in ["delete", "remove", "drop"]):
        return "delete"
    if any(w in desc for w in ["join", "combine", "merge", "relate", "with their"]):
        return "join"
    if any(w in desc for w in ["count", "sum", "average", "avg", "total", "group", "aggregate", "per", "each"]):
        return "aggregate"
    if any(w in desc for w in ["where", "in", "exists", "not in", "subquery", "nested"]):
        return "subquery"

    return "select"
