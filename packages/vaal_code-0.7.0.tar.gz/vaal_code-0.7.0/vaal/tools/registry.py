"""Tool registry — all available tools and their metadata."""

from dataclasses import dataclass
from typing import Callable


@dataclass
class ToolDef:
    name: str
    description: str
    parameters: dict  # JSON schema-like description
    handler: Callable
    dangerous: bool = False


_tools: dict[str, ToolDef] = {}


def register_tool(
    name: str,
    description: str,
    parameters: dict,
    dangerous: bool = False,
):
    """Decorator to register a tool handler."""
    def decorator(func):
        _tools[name] = ToolDef(
            name=name,
            description=description,
            parameters=parameters,
            handler=func,
            dangerous=dangerous,
        )
        return func
    return decorator


def get_tool(name: str) -> ToolDef | None:
    return _tools.get(name)


def all_tools() -> dict[str, ToolDef]:
    return _tools


def tool_descriptions_text() -> str:
    lines = []
    for name, tool in _tools.items():
        lines.append(f"## {name}")
        lines.append(tool.description)
        if tool.parameters:
            lines.append("Parameters:")
            for param, info in tool.parameters.items():
                req = " (required)" if info.get("required") else ""
                lines.append(f"  - {param}: {info.get('description', '')}{req}")
        lines.append("")
    return "\n".join(lines)
