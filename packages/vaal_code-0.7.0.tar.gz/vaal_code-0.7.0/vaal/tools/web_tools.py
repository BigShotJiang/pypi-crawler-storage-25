"""Web tools — fetch URLs and search the web."""

import re
import urllib.request
import urllib.parse
import urllib.error
import ssl

from .registry import register_tool


def _strip_html(html: str) -> str:
    """Strip HTML tags and decode entities to get readable plain text."""
    # Remove script and style blocks entirely
    text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL | re.IGNORECASE)
    # Remove HTML comments
    text = re.sub(r"<!--.*?-->", "", text, flags=re.DOTALL)
    # Convert block elements to newlines
    text = re.sub(r"<(?:br|p|div|h[1-6]|li|tr|blockquote)[^>]*>", "\n", text, flags=re.IGNORECASE)
    # Strip remaining tags
    text = re.sub(r"<[^>]+>", "", text)
    # Decode common HTML entities
    entities = {
        "&amp;": "&", "&lt;": "<", "&gt;": ">", "&quot;": '"',
        "&#39;": "'", "&apos;": "'", "&nbsp;": " ", "&ndash;": "-",
        "&mdash;": "--", "&hellip;": "...", "&laquo;": "<<", "&raquo;": ">>",
    }
    for entity, char in entities.items():
        text = text.replace(entity, char)
    # Decode numeric entities
    text = re.sub(r"&#(\d+);", lambda m: chr(int(m.group(1))), text)
    text = re.sub(r"&#x([0-9a-fA-F]+);", lambda m: chr(int(m.group(1), 16)), text)
    # Collapse whitespace
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n[ \t]+", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _fetch_url(url: str, timeout: int = 15) -> str:
    """Fetch a URL and return the response body as text."""
    ctx = ssl.create_default_context()
    # Some sites have bad certs; fall back gracefully
    ctx.check_hostname = True
    ctx.verify_mode = ssl.CERT_REQUIRED

    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; Vaal/1.0; +https://github.com/vaal)",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
    }
    req = urllib.request.Request(url, headers=headers)

    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            charset = resp.headers.get_content_charset() or "utf-8"
            body = resp.read(500_000)  # 500KB limit
            return body.decode(charset, errors="replace")
    except urllib.error.HTTPError as e:
        return f"[HTTP {e.code}: {e.reason}]"
    except urllib.error.URLError as e:
        return f"[error: {e.reason}]"
    except Exception as e:
        return f"[error: {e}]"


@register_tool(
    name="web_fetch",
    description="Fetch a URL and return its content as readable plain text (HTML stripped).",
    parameters={
        "url": {"description": "The URL to fetch", "required": True},
        "raw": {"description": "Return raw HTML without stripping (true/false, default false)", "required": False},
    },
)
def web_fetch(url: str, raw: str = "", **kwargs) -> str:
    if not url.startswith(("http://", "https://")):
        url = "https://" + url

    body = _fetch_url(url)
    if body.startswith("[error:") or body.startswith("[HTTP"):
        return body

    if str(raw).lower() in ("true", "1", "yes"):
        return body[:50000]

    text = _strip_html(body)
    return text[:50000] or "(empty page)"


@register_tool(
    name="web_search",
    description="Search the web using DuckDuckGo. Returns a list of results with titles, URLs, and snippets.",
    parameters={
        "query": {"description": "Search query", "required": True},
        "max_results": {"description": "Max results to return (default 8)", "required": False},
    },
)
def web_search(query: str, max_results: str | int = 8, **kwargs) -> str:
    n = int(max_results) if max_results else 8

    encoded = urllib.parse.quote_plus(query)
    url = f"https://html.duckduckgo.com/html/?q={encoded}"

    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
    }
    req = urllib.request.Request(url, headers=headers)

    try:
        ctx = ssl.create_default_context()
        with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
            charset = resp.headers.get_content_charset() or "utf-8"
            html = resp.read(500_000).decode(charset, errors="replace")
    except Exception as e:
        return f"[error: search failed: {e}]"

    # Parse DuckDuckGo HTML results
    results = []
    # Each result is in a <div class="result ..."> or similar
    # Extract links from result__a and snippets from result__snippet
    link_pattern = re.compile(
        r'<a[^>]+class="result__a"[^>]*href="([^"]*)"[^>]*>(.*?)</a>',
        re.DOTALL | re.IGNORECASE,
    )
    snippet_pattern = re.compile(
        r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>',
        re.DOTALL | re.IGNORECASE,
    )

    links = link_pattern.findall(html)
    snippets = snippet_pattern.findall(html)

    for i, (href, title_html) in enumerate(links[:n]):
        title = _strip_html(title_html).strip()
        # DuckDuckGo wraps URLs in a redirect; extract the actual URL
        if "uddg=" in href:
            match = re.search(r"uddg=([^&]+)", href)
            if match:
                href = urllib.parse.unquote(match.group(1))
        snippet = ""
        if i < len(snippets):
            snippet = _strip_html(snippets[i]).strip()

        results.append(f"{i+1}. {title}\n   {href}\n   {snippet}")

    if not results:
        return f"(no results found for: {query})"

    return "\n\n".join(results)
