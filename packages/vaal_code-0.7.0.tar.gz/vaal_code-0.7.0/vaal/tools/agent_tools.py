"""Agent tools -- tools the LLM can use to spawn and manage sub-agents."""

import json
import os

from .registry import register_tool
from ..core.agent import get_agent_pool, AgentStatus
from ..core.task_manager import get_task_manager, TaskStatus
from ..core.llm import build_system_prompt, get_ollama_tools
from ..core.config import DEFAULT_MODEL


def _get_default_tools():
    """Get the default tools list in Ollama format for sub-agents."""
    from .registry import all_tools
    return get_ollama_tools(all_tools())


# Built-in specialized agent types with tailored system prompts
AGENT_TYPES = {
    "explore": {
        "label_prefix": "explore",
        "system_suffix": (
            "\nYou are an EXPLORE agent — specialized for fast codebase exploration. "
            "Your job is to find files, search code, and answer questions about the codebase structure. "
            "Use glob to find files by pattern, grep to search content, read to examine files. "
            "Be thorough: check multiple naming conventions, look in test files, check imports. "
            "Report back with file paths, line numbers, and relevant code snippets. "
            "Do NOT modify any files. Read-only exploration only."
        ),
        "max_rounds": 15,
    },
    "plan": {
        "label_prefix": "plan",
        "system_suffix": (
            "\nYou are a PLAN agent — a software architect that designs implementation plans. "
            "Explore the codebase to understand existing patterns, then create a step-by-step plan. "
            "Identify which files need to be created or modified, consider architectural trade-offs, "
            "and note potential risks. Output a clear numbered plan with file paths. "
            "Do NOT implement anything — only plan and document."
        ),
        "max_rounds": 12,
    },
    "verify": {
        "label_prefix": "verify",
        "system_suffix": (
            "\nYou are a VERIFICATION agent. Your job is to verify that work was done correctly. "
            "Run tests, check that files exist, verify code compiles, confirm expected behavior. "
            "Use bash to run test commands, read files to check content, grep to verify patterns. "
            "Report PASS or FAIL for each check with evidence. Be thorough and skeptical."
        ),
        "max_rounds": 10,
    },
    "code-review": {
        "label_prefix": "review",
        "system_suffix": (
            "\nYou are a CODE REVIEW agent. Review the specified code for: "
            "security vulnerabilities (CRITICAL), bugs and logic errors (HIGH), "
            "performance issues (MEDIUM), style and maintainability (LOW). "
            "Read the files, check git diff if relevant, and provide structured feedback. "
            "For each issue, include: file:line, severity, description, and suggested fix. "
            "Do NOT modify any files."
        ),
        "max_rounds": 10,
    },
    "general": {
        "label_prefix": "agent",
        "system_suffix": (
            "\nYou are a sub-agent spawned to handle a specific task. "
            "Complete the task fully using your tools, then provide a clear summary of what you did."
        ),
        "max_rounds": 10,
    },
}


@register_tool(
    name="spawn_agent",
    description=(
        "Spawn a background sub-agent to work on an independent task in parallel. "
        "The sub-agent gets its own conversation loop with full tool access and runs "
        "in a background thread. Use this for tasks that can proceed independently "
        "while you continue other work. Returns the agent ID for status checking.\n\n"
        "Built-in agent types (use the 'agent_type' parameter):\n"
        "- 'explore' — fast codebase exploration, read-only\n"
        "- 'plan' — software architecture and implementation planning\n"
        "- 'verify' — run tests, check files, verify correctness\n"
        "- 'code-review' — security/bug/style review of code\n"
        "- 'general' — default, full autonomy (default if omitted)"
    ),
    parameters={
        "task": {
            "description": "Clear description of what the sub-agent should accomplish.",
            "required": True,
        },
        "label": {
            "description": "Short label for this agent (shown in status). E.g. 'fix tests', 'refactor utils'.",
            "required": True,
        },
        "agent_type": {
            "description": "Built-in agent type: explore, plan, verify, code-review, general. Defaults to general.",
            "required": False,
        },
        "model": {
            "description": "Model to use for the sub-agent. Defaults to the current model if not specified.",
            "required": False,
        },
        "max_rounds": {
            "description": "Maximum tool-call rounds. Defaults vary by agent type.",
            "required": False,
        },
    },
)
def spawn_agent(task: str, label: str, agent_type: str = "general", model: str = "", max_rounds: str = "") -> str:
    """Spawn a sub-agent to work on a task."""
    pool = get_agent_pool()
    tm = get_task_manager()

    # Resolve agent type
    atype = AGENT_TYPES.get(agent_type.lower().strip(), AGENT_TYPES["general"])

    # Create a linked task
    t = tm.create(title=label, description=task)

    # Build system prompt for the sub-agent
    system_prompt = build_system_prompt()
    system_prompt += atype["system_suffix"]

    # Resolve max rounds: explicit param > agent type default > 10
    rounds = atype["max_rounds"]
    if max_rounds:
        try:
            rounds = int(max_rounds)
        except (ValueError, TypeError):
            pass

    # Resolve model: explicit param > config agent_model > DEFAULT_MODEL
    resolved_model = model
    if not resolved_model:
        try:
            from ..core.user_config import UserConfig
            uc = UserConfig()
            resolved_model = uc.agent_model
        except Exception:
            pass
    if not resolved_model:
        resolved_model = DEFAULT_MODEL

    agent = pool.spawn(
        label=f"[{atype['label_prefix']}] {label}",
        system_prompt=system_prompt,
        user_prompt=task,
        model=resolved_model,
        tools=_get_default_tools(),
        max_rounds=rounds,
        task_id=t.id,
    )

    return json.dumps({
        "agent_id": agent.id,
        "task_id": t.id,
        "label": label,
        "agent_type": agent_type,
        "status": "spawned",
        "message": f"Sub-agent [{atype['label_prefix']}] '{label}' started in background. Use check_agent('{agent.id}') to monitor.",
    }, indent=2)


@register_tool(
    name="check_agent",
    description=(
        "Check the status and result of a running or completed sub-agent. "
        "Returns the agent's current status, and if complete, its final output."
    ),
    parameters={
        "agent_id": {
            "description": "The agent ID returned by spawn_agent.",
            "required": True,
        },
    },
)
def check_agent(agent_id: str) -> str:
    """Check status of a sub-agent."""
    pool = get_agent_pool()
    agent = pool.get(agent_id)

    if not agent:
        return json.dumps({"error": f"No agent found with ID '{agent_id}'"})

    info = {
        "agent_id": agent.id,
        "label": agent.label,
        "status": agent.status.value,
        "model": agent.model,
    }

    if agent.is_done and agent.result:
        info["rounds"] = agent.result.rounds
        info["tool_calls"] = agent.result.tool_calls_made
        info["elapsed"] = f"{agent.result.elapsed:.1f}s"
        if agent.result.error:
            info["error"] = agent.result.error
        if agent.result.content:
            info["output"] = agent.result.content

    return json.dumps(info, indent=2)


@register_tool(
    name="list_agents",
    description=(
        "List all active and completed sub-agents with their status. "
        "Useful to see what background work is in progress."
    ),
    parameters={},
)
def list_agents() -> str:
    """List all agents in the pool."""
    pool = get_agent_pool()
    agents = pool.list_agents()

    if not agents:
        return json.dumps({"agents": [], "message": "No agents spawned."})

    return json.dumps({"agents": agents, "total": len(agents)}, indent=2)
