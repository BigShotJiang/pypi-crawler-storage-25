"""Search tools — glob and grep."""

import subprocess
import os
from pathlib import Path
import fnmatch

from .registry import register_tool


@register_tool(
    name="glob",
    description="Find files matching a glob pattern. Returns file paths sorted by modification time.",
    parameters={
        "pattern": {"description": "Glob pattern (e.g. '**/*.py', 'src/**/*.ts')", "required": True},
        "path": {"description": "Directory to search in (default: cwd)", "required": False},
    },
)
def glob_tool(pattern: str, path: str = "", **kwargs) -> str:
    try:
        base = Path(path) if path else Path.cwd()
        matches = sorted(base.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)

        if not matches:
            return "(no files matched)"

        # Limit output
        total = len(matches)
        shown = matches[:100]
        lines = [str(m) for m in shown]
        result = "\n".join(lines)
        if total > 100:
            result += f"\n\n[... {total - 100} more files]"
        return result
    except Exception as e:
        return f"[error: {e}]"


@register_tool(
    name="grep",
    description="Search file contents using regex. Returns matching lines with file paths and line numbers.",
    parameters={
        "pattern": {"description": "Regex pattern to search for", "required": True},
        "path": {"description": "File or directory to search in (default: cwd)", "required": False},
        "glob_filter": {"description": "Glob to filter files (e.g. '*.py')", "required": False},
        "context": {"description": "Lines of context around matches (default 0)", "required": False},
    },
)
def grep_tool(pattern: str, path: str = "", glob_filter: str = "", context: str | int = 0, **kwargs) -> str:
    context = int(context) if context else 0
    try:
        search_path = path or os.getcwd()
        cmd = ["rg", "--no-heading", "--line-number", "--color", "never"]

        if context > 0:
            cmd.extend(["-C", str(context)])
        if glob_filter:
            cmd.extend(["--glob", glob_filter])

        cmd.extend(["--max-count", "200"])
        cmd.append(pattern)
        cmd.append(search_path)

        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

        if result.returncode == 1:
            return "(no matches)"
        if result.returncode != 0:
            # Fallback to Python grep if rg not available
            return _python_grep(pattern, search_path, glob_filter, context)

        output = result.stdout
        if len(output) > 50000:
            output = output[:50000] + "\n\n[... output truncated]"
        return output or "(no matches)"
    except FileNotFoundError:
        return _python_grep(pattern, path or os.getcwd(), glob_filter, context)
    except subprocess.TimeoutExpired:
        return "[grep timed out]"
    except Exception as e:
        return f"[error: {e}]"


def _python_grep(pattern: str, search_path: str, glob_filter: str, context: int) -> str:
    """Fallback grep using Python re module."""
    import re

    try:
        regex = re.compile(pattern)
    except re.error as e:
        return f"[invalid regex: {e}]"

    base = Path(search_path)
    results = []
    count = 0

    if base.is_file():
        files = [base]
    else:
        file_pattern = glob_filter or "**/*"
        files = [f for f in base.glob(file_pattern) if f.is_file()]

    for fp in files[:1000]:
        try:
            text = fp.read_text(encoding="utf-8", errors="replace")
            for i, line in enumerate(text.splitlines(), 1):
                if regex.search(line):
                    results.append(f"{fp}:{i}:{line}")
                    count += 1
                    if count >= 200:
                        break
        except Exception:
            continue
        if count >= 200:
            break

    return "\n".join(results) if results else "(no matches)"
