"""Remote control — connects OUT to a relay server for remote web control.

Vaal polls the relay for prompts, processes them, and posts responses back.
Works behind NAT/firewalls — vaal connects out, never needs incoming ports.
"""

import json
import secrets
import threading
import time
from pathlib import Path

import httpx

from .config import VAAL_DIR

REMOTE_TOKEN_FILE = VAAL_DIR / "remote_token"
DEFAULT_RELAY = "https://e-e.tools/vaal/relay.php"


def _generate_token() -> str:
    token = secrets.token_urlsafe(24)
    VAAL_DIR.mkdir(exist_ok=True)
    REMOTE_TOKEN_FILE.write_text(token, encoding="utf-8")
    return token


def _get_token() -> str:
    if REMOTE_TOKEN_FILE.exists():
        return REMOTE_TOKEN_FILE.read_text(encoding="utf-8").strip()
    return _generate_token()


class RemoteRelay:
    """Connects to a relay server and polls for remote prompts."""

    def __init__(self, relay_url: str = DEFAULT_RELAY, session_name: str = "default"):
        self.relay_url = relay_url.rstrip("/")
        self.session_name = session_name
        self.token = _get_token()
        self.active_model = ""
        self._poll_thread: threading.Thread | None = None
        self._stop = threading.Event()
        self._prompt_callback = None
        self._last_prompt_ts = time.time()
        self._registered = False

    def _headers(self) -> dict:
        return {"X-Vaal-Token": self.token, "Content-Type": "application/json"}

    def _api(self, action: str, method: str = "GET", data: dict = None) -> dict:
        """Call the relay API."""
        url = f"{self.relay_url}?action={action}&session={self.session_name}&token={self.token}"
        try:
            if method == "POST":
                r = httpx.post(url, headers=self._headers(), json=data or {}, timeout=20)
            else:
                r = httpx.get(url, headers=self._headers(), timeout=20)
            return r.json() if r.status_code == 200 else {"error": f"HTTP {r.status_code}: {r.text[:100]}"}
        except httpx.TimeoutException:
            return {"error": "timeout"}
        except Exception as e:
            return {"error": str(e)}

    def register(self) -> bool:
        """Register token with the relay. Tries POST then GET."""
        result = self._api("register", method="POST")
        if "ok" not in result:
            # Fallback to GET
            result = self._api("register")
        self._registered = "ok" in result
        return self._registered


    def set_prompt_callback(self, callback):
        """Set callback(prompt: str, responder: ResponseSender)."""
        self._prompt_callback = callback

    def send_response(self, msg_type: str, **kwargs):
        """Send a response chunk to the relay."""
        data = {"type": msg_type, **kwargs}
        result = self._api("send_response", method="POST", data=data)
        if "error" in result:
            import sys
            sys.stderr.write(f"[relay] send_response failed: {result['error']}\n")
            sys.stderr.flush()

    def update_status(self):
        """Update vaal's status on the relay."""
        self._api("status_update", method="POST", data={
            "model": self.active_model,
            "online": True,
        })

    def start(self) -> tuple[bool, str]:
        """Start polling the relay for prompts. Generates fresh token + clears old data."""
        if self._poll_thread and self._poll_thread.is_alive():
            return False, "Already running"

        # Fresh token every time
        self.token = _generate_token()

        # Register new token with relay
        if not self.register():
            return False, f"Failed to register with relay at {self.relay_url}"

        # Purge old session data
        self._api("clear", method="GET")

        self.update_status()

        self._stop.clear()
        self._last_prompt_ts = time.time()
        self._poll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._poll_thread.start()

        return True, f"Connected to relay\n  URL: {self.relay_url}\n  Token: {self.token}\n  Web UI: https://e-e.tools/vaal/?token={self.token}"

    def stop(self):
        """Stop polling."""
        self._stop.set()
        if self._poll_thread:
            self._poll_thread.join(timeout=3)
            self._poll_thread = None

    @property
    def is_running(self) -> bool:
        return self._poll_thread is not None and self._poll_thread.is_alive()

    def _poll_loop(self):
        """Background thread: poll relay for new prompts."""
        status_interval = 0
        while not self._stop.is_set():
            try:
                # Poll for prompts
                result = self._api(f"poll_prompts&since={self._last_prompt_ts}")
                prompts = result.get("prompts", [])

                for p in prompts:
                    self._last_prompt_ts = p.get("timestamp", time.time())
                    content = p.get("content", "")
                    if content and self._prompt_callback:
                        responder = RelayResponder(self)
                        self._prompt_callback(content, responder)

                # Update status every 15 seconds
                status_interval += 1
                if status_interval >= 6:  # 6 * 2.5s = 15s
                    self.update_status()
                    status_interval = 0

            except Exception:
                pass

            self._stop.wait(2.5)  # Poll every 2.5 seconds


class RelayResponder:
    """Provides a send interface for response callbacks."""

    def __init__(self, relay: RemoteRelay):
        self._relay = relay

    def send_streaming(self, token: str):
        self._relay.send_response("streaming", token=token)

    def send_stream_end(self):
        self._relay.send_response("stream_end")

    def send_tool_call(self, name: str, detail: str = ""):
        self._relay.send_response("tool_call", name=name, detail=detail)

    def send_tool_result(self, preview: str = ""):
        self._relay.send_response("tool_result", preview=preview)

    def send_error(self, message: str):
        self._relay.send_response("error", message=message)

    def send_response(self, content: str):
        self._relay.send_response("response", content=content)


# Singleton
_remote: RemoteRelay | None = None


def get_remote_server(relay_url: str = DEFAULT_RELAY) -> RemoteRelay:
    global _remote
    if _remote is None:
        _remote = RemoteRelay(relay_url=relay_url)
    return _remote
