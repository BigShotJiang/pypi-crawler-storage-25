"""Multi-provider LLM backend — Ollama, OpenAI, Anthropic, and any OpenAI-compatible API."""

import json
import os
from typing import Generator
from dataclasses import dataclass

import httpx


@dataclass
class ProviderConfig:
    """Configuration for an LLM provider."""
    name: str           # "ollama", "openai", "anthropic", "custom"
    base_url: str       # API base URL
    api_key: str = ""   # API key (empty for Ollama)
    model: str = ""     # Model name/ID
    max_tokens: int = 4096


# ── Provider registry ────────────────────────────────────────────────

BUILTIN_PROVIDERS = {
    "ollama": {
        "name": "ollama",
        "base_url": "http://localhost:11434",
        "requires_key": False,
        "models_endpoint": "/api/tags",
        "chat_endpoint": "/api/chat",
        "format": "ollama",
    },
    "openai": {
        "name": "openai",
        "base_url": "https://api.openai.com/v1",
        "requires_key": True,
        "key_env": "OPENAI_API_KEY",
        "models_endpoint": "/models",
        "chat_endpoint": "/chat/completions",
        "format": "openai",
    },
    "codex": {
        "name": "codex",
        "base_url": "https://api.openai.com/v1",
        "requires_key": True,
        "key_env": "OPENAI_API_KEY",
        "models_endpoint": None,
        "chat_endpoint": "/responses",
        "format": "responses",
    },
    "anthropic": {
        "name": "anthropic",
        "base_url": "https://api.anthropic.com",
        "requires_key": True,
        "key_env": "ANTHROPIC_API_KEY",
        "models_endpoint": None,
        "chat_endpoint": "/v1/messages",
        "format": "anthropic",
    },
    "groq": {
        "name": "groq",
        "base_url": "https://api.groq.com/openai/v1",
        "requires_key": True,
        "key_env": "GROQ_API_KEY",
        "models_endpoint": "/models",
        "chat_endpoint": "/chat/completions",
        "format": "openai",
    },
    "openrouter": {
        "name": "openrouter",
        "base_url": "https://openrouter.ai/api/v1",
        "requires_key": True,
        "key_env": "OPENROUTER_API_KEY",
        "models_endpoint": "/models",
        "chat_endpoint": "/chat/completions",
        "format": "openai",
    },
    "deepseek": {
        "name": "deepseek",
        "base_url": "https://api.deepseek.com/v1",
        "requires_key": True,
        "key_env": "DEEPSEEK_API_KEY",
        "models_endpoint": "/models",
        "chat_endpoint": "/chat/completions",
        "format": "openai",
    },
    "together": {
        "name": "together",
        "base_url": "https://api.together.xyz/v1",
        "requires_key": True,
        "key_env": "TOGETHER_API_KEY",
        "models_endpoint": "/models",
        "chat_endpoint": "/chat/completions",
        "format": "openai",
    },
    "airllm": {
        "name": "airllm",
        "base_url": "",
        "requires_key": False,
        "models_endpoint": None,
        "chat_endpoint": None,
        "format": "airllm",
    },
}

# Default models for each provider
DEFAULT_MODELS = {
    "ollama": "qwen3:8b",
    "openai": "gpt-4o",
    "codex": "o3",
    "anthropic": "claude-opus-4-6",
    "groq": "llama-3.3-70b-versatile",
    "openrouter": "anthropic/claude-sonnet-4",
    "deepseek": "deepseek-chat",
    "together": "meta-llama/Llama-3.3-70B-Instruct-Turbo",
}


def parse_model_string(model_str: str) -> tuple[str, str]:
    """Parse 'provider:model' or 'provider/model' into (provider, model).
    If no provider prefix, assumes 'ollama'.

    Examples:
        'qwen3:8b'                    -> ('ollama', 'qwen3:8b')
        'openai:gpt-4o'              -> ('openai', 'gpt-4o')
        'anthropic:claude-sonnet-4-20250514' -> ('anthropic', 'claude-sonnet-4-20250514')
        'groq:llama-3.3-70b'         -> ('groq', 'llama-3.3-70b')
        'openrouter:anthropic/claude-sonnet-4' -> ('openrouter', 'anthropic/claude-sonnet-4')
    """
    # Check for known provider prefixes
    for provider in BUILTIN_PROVIDERS:
        prefix = f"{provider}:"
        if model_str.startswith(prefix):
            return provider, model_str[len(prefix):]

    # No prefix — default to ollama
    return "ollama", model_str


def get_provider_info(provider_name: str) -> dict | None:
    return BUILTIN_PROVIDERS.get(provider_name)


def get_api_key(provider_name: str) -> str:
    """Get API key from environment, ~/.vaal/keys.json, or Claude Code config."""
    info = BUILTIN_PROVIDERS.get(provider_name, {})
    env_var = info.get("key_env", "")

    # 1. For Anthropic, check bridge JWT FIRST (Max/Pro — no billing, best rate limits)
    if provider_name == "anthropic":
        try:
            from .bridge import get_bridge
            bridge = get_bridge()
            if bridge.refresh_if_needed() and bridge.worker_jwt:
                return bridge.worker_jwt
        except Exception:
            pass
        # Fallback to OAuth token
        key = _get_claude_code_key()
        if key:
            return key

    # 2. Check ~/.vaal/keys.json
    from .config import VAAL_DIR
    keys_file = VAAL_DIR / "keys.json"
    if keys_file.exists():
        try:
            keys = json.loads(keys_file.read_text(encoding="utf-8"))
            key = keys.get(provider_name, "")
            if key:
                return key
        except Exception:
            pass

    # 3. Check environment variables (API key — may incur billing)
    if env_var:
        key = os.environ.get(env_var, "")
        if key:
            # NEVER silently use a paid API key — always warn
            import sys
            sys.stderr.write(f"\n  ⚠ WARNING: Using {env_var} environment variable (may incur billing).\n")
            sys.stderr.write(f"  To use Max/Pro instead: /login anthropic\n")
            sys.stderr.write(f"  To suppress: unset {env_var}\n\n")
            sys.stderr.flush()
            return key

    # 4. For OpenAI/Codex, check common config locations
    if provider_name in ("openai", "codex"):
        key = _get_openai_config_key()
        if key:
            return key

    # 5. Codex shares the OpenAI key — fall back to openai's stored key
    if provider_name == "codex":
        # Check openai's keys.json entry
        from .config import VAAL_DIR
        keys_file = VAAL_DIR / "keys.json"
        if keys_file.exists():
            try:
                keys = json.loads(keys_file.read_text(encoding="utf-8"))
                key = keys.get("openai", "")
                if key:
                    return key
            except Exception:
                pass

    return ""


def _get_vaal_oauth() -> dict | None:
    """Get Vaal's own stored OAuth credentials."""
    from .config import VAAL_DIR
    creds_file = VAAL_DIR / "credentials.json"
    if creds_file.exists():
        try:
            creds = json.loads(creds_file.read_text(encoding="utf-8"))
            oauth = creds.get("claudeAiOauth", {})
            if oauth.get("accessToken"):
                return oauth
        except Exception:
            pass
    return None


def _save_vaal_oauth(oauth: dict):
    """Save OAuth credentials to Vaal's own file (not Claude Code's)."""
    from .config import VAAL_DIR
    VAAL_DIR.mkdir(exist_ok=True)
    creds_file = VAAL_DIR / "credentials.json"
    creds = {}
    if creds_file.exists():
        try:
            creds = json.loads(creds_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    creds["claudeAiOauth"] = oauth
    creds.pop("anthropic_logged_out", None)  # Clear logout flag on login
    creds_file.write_text(json.dumps(creds, indent=2), encoding="utf-8")


def _clear_vaal_oauth():
    """Remove OAuth from Vaal's credentials and mark as explicitly logged out."""
    from .config import VAAL_DIR
    creds_file = VAAL_DIR / "credentials.json"
    creds = {}
    if creds_file.exists():
        try:
            creds = json.loads(creds_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    creds.pop("claudeAiOauth", None)
    creds["anthropic_logged_out"] = True  # Prevent re-import from Claude Code
    VAAL_DIR.mkdir(exist_ok=True)
    creds_file.write_text(json.dumps(creds, indent=2), encoding="utf-8")


def _get_claude_code_oauth() -> dict | None:
    """Read Claude Code's OAuth (read-only — never write to this)."""
    from pathlib import Path
    claude_dir = Path.home() / ".claude"
    for fname in [".credentials.json", "credentials.json"]:
        creds_file = claude_dir / fname
        if creds_file.exists():
            try:
                creds = json.loads(creds_file.read_text(encoding="utf-8"))
                oauth = creds.get("claudeAiOauth", {})
                if oauth.get("accessToken"):
                    return oauth
            except Exception:
                pass
    return None


def get_active_oauth() -> dict | None:
    """Get OAuth credentials — checks Vaal's own store first, then Claude Code's (read-only copy)."""
    from .config import VAAL_DIR

    # Check if user explicitly logged out — don't re-import
    creds_file = VAAL_DIR / "credentials.json"
    if creds_file.exists():
        try:
            creds = json.loads(creds_file.read_text(encoding="utf-8"))
            if creds.get("anthropic_logged_out"):
                return None  # User logged out, don't auto-import
        except Exception:
            pass

    # 1. Vaal's own credentials
    oauth = _get_vaal_oauth()
    if oauth:
        return oauth
    # 2. Copy from Claude Code (read-only) into Vaal's store
    cc_oauth = _get_claude_code_oauth()
    if cc_oauth:
        _save_vaal_oauth(cc_oauth)
        return cc_oauth
    return None


def _refresh_claude_oauth(oauth: dict) -> dict | None:
    """Refresh an expired Claude OAuth token."""
    refresh_token = oauth.get("refreshToken", "")
    if not refresh_token:
        return None

    try:
        r = httpx.post(
            "https://platform.claude.com/v1/oauth/token",
            json={
                "grant_type": "refresh_token",
                "refresh_token": refresh_token,
                "client_id": "9d1c250a-e61b-44d9-88ed-5944d1962f5e",
            },
            timeout=15,
        )
        if r.status_code == 200:
            import time
            data = r.json()
            # expires_in is seconds from now, convert to millisecond timestamp
            expires_in = data.get("expires_in", 28800)
            expires_at = int(time.time() * 1000) + (expires_in * 1000)
            return {
                "accessToken": data.get("access_token", ""),
                "refreshToken": data.get("refresh_token", refresh_token),
                "expiresAt": expires_at,
                "scopes": oauth.get("scopes", []),
                "subscriptionType": oauth.get("subscriptionType", "max"),
                "rateLimitTier": oauth.get("rateLimitTier", ""),
            }
    except Exception:
        pass
    return None


def get_claude_max_token() -> str:
    """Get a valid Claude Max/Pro OAuth access token, refreshing if needed."""
    import time

    oauth = get_active_oauth()
    if not oauth:
        return ""

    access_token = oauth.get("accessToken", "")
    expires_at = oauth.get("expiresAt", 0)

    # Check if expired (expires_at is in milliseconds)
    now_ms = int(time.time() * 1000)
    if expires_at and now_ms > expires_at - 60000:  # 1 min buffer
        # Try refresh first
        refreshed = _refresh_claude_oauth(oauth)
        if refreshed:
            _save_vaal_oauth(refreshed)
            return refreshed.get("accessToken", "")

        # Refresh failed — grab fresh token from Claude Code
        cc_oauth = _get_claude_code_oauth()
        if cc_oauth:
            cc_expires = cc_oauth.get("expiresAt", 0)
            if cc_expires and now_ms < cc_expires - 60000:
                _save_vaal_oauth(cc_oauth)
                return cc_oauth.get("accessToken", "")

        return ""

    return access_token


def _get_claude_code_key() -> str:
    """Try to get Anthropic API key from Claude Code's config or OAuth."""
    # First try OAuth (Max/Pro subscription)
    token = get_claude_max_token()
    if token:
        return token

    # Fallback: check for raw API key in credentials
    from pathlib import Path
    claude_dir = Path.home() / ".claude"
    for fname in [".credentials.json", "credentials.json"]:
        creds_file = claude_dir / fname
        if creds_file.exists():
            try:
                creds = json.loads(creds_file.read_text(encoding="utf-8"))
                key = creds.get("apiKey", "") or creds.get("api_key", "")
                if key:
                    return key
            except Exception:
                pass

    return ""


def _get_openai_config_key() -> str:
    """Try to get OpenAI key from common config locations."""
    from pathlib import Path

    # ~/.openai/credentials
    openai_dir = Path.home() / ".openai"
    if (openai_dir / "credentials").exists():
        try:
            text = (openai_dir / "credentials").read_text(encoding="utf-8")
            for line in text.splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    if "key" in k.lower():
                        return v.strip()
        except Exception:
            pass

    return ""


def save_api_key(provider_name: str, key: str):
    """Save API key to ~/.vaal/keys.json."""
    from .config import VAAL_DIR
    VAAL_DIR.mkdir(exist_ok=True)
    keys_file = VAAL_DIR / "keys.json"
    keys = {}
    if keys_file.exists():
        try:
            keys = json.loads(keys_file.read_text(encoding="utf-8"))
        except Exception:
            pass
    keys[provider_name] = key
    keys_file.write_text(json.dumps(keys, indent=2), encoding="utf-8")


def check_provider_connection(provider_name: str) -> bool:
    """Check if a provider is reachable and configured."""
    info = BUILTIN_PROVIDERS.get(provider_name)
    if not info:
        return False

    if info["requires_key"]:
        key = get_api_key(provider_name)
        if not key:
            # Codex shares OpenAI key — try that
            if provider_name == "codex":
                key = get_api_key("openai")
                if not key:
                    return False
            else:
                return False

    if provider_name == "ollama":
        try:
            r = httpx.get(f"{info['base_url']}/api/tags", timeout=3)
            return r.status_code == 200
        except Exception:
            return False

    if provider_name == "airllm":
        try:
            import airllm  # noqa: F401
            return True
        except ImportError:
            return False

    # For API providers, just check if key exists
    return True


def list_provider_models(provider_name: str) -> list[str]:
    """List available models for a provider."""
    info = BUILTIN_PROVIDERS.get(provider_name)
    if not info:
        return []

    if provider_name == "ollama":
        try:
            r = httpx.get(f"{info['base_url']}/api/tags", timeout=5)
            return [m["name"] for m in r.json().get("models", [])]
        except Exception:
            return []

    if provider_name == "anthropic":
        return [
            "claude-opus-4-6",
            "claude-sonnet-4-6",
            "claude-opus-4-20250514",
            "claude-sonnet-4-20250514",
            "claude-haiku-4-5-20251001",
        ]

    if provider_name == "codex":
        return [
            "o3",
            "o4-mini",
            "gpt-4.1",
            "gpt-4.1-mini",
            "gpt-4.1-nano",
        ]

    if provider_name == "airllm":
        from .airllm_provider import list_cached_models
        return list_cached_models()

    # OpenAI-compatible: fetch from /models
    endpoint = info.get("models_endpoint")
    if not endpoint:
        return []

    key = get_api_key(provider_name)
    try:
        r = httpx.get(
            f"{info['base_url']}{endpoint}",
            headers={"Authorization": f"Bearer {key}"},
            timeout=10,
        )
        data = r.json().get("data", [])
        return [m["id"] for m in data][:50]
    except Exception:
        return []


# ── Streaming implementations ────────────────────────────────────────

def stream_openai_compatible(
    messages: list[dict],
    tools: list[dict] | None,
    model: str,
    base_url: str,
    api_key: str,
    max_tokens: int = 4096,
) -> Generator[dict, None, None]:
    """Stream from any OpenAI-compatible API (OpenAI, Groq, OpenRouter, etc.)."""
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    body = {
        "model": model,
        "messages": messages,
        "stream": True,
        "max_tokens": max_tokens,
        "temperature": 0.3,
    }
    if tools:
        body["tools"] = tools

    with httpx.stream(
        "POST",
        f"{base_url}/chat/completions",
        headers=headers,
        json=body,
        timeout=None,
    ) as r:
        for line in r.iter_lines():
            if not line or not line.startswith("data: "):
                continue
            data_str = line[6:]
            if data_str.strip() == "[DONE]":
                yield {"done": True, "eval_count": 0, "eval_duration": 0}
                break
            try:
                data = json.loads(data_str)
                choice = data.get("choices", [{}])[0]
                delta = choice.get("delta", {})
                result = {}

                if delta.get("content"):
                    result["content"] = delta["content"]

                if delta.get("tool_calls"):
                    # OpenAI tool calls come incrementally
                    for tc in delta["tool_calls"]:
                        if tc.get("function", {}).get("name"):
                            result.setdefault("tool_calls", [])
                            result["tool_calls"].append(tc)

                if choice.get("finish_reason") == "tool_calls":
                    # Accumulate tool calls from usage
                    pass

                if result:
                    yield result

            except json.JSONDecodeError:
                continue


def stream_anthropic(
    messages: list[dict],
    tools: list[dict] | None,
    model: str,
    api_key: str,
    max_tokens: int = 4096,
) -> Generator[dict, None, None]:
    """Stream from Anthropic's Messages API.

    For Max/Pro OAuth users, uses the bridge session system (code sessions)
    which has different rate limits than the direct API.
    """
    api_url = "https://api.anthropic.com"

    # Try bridge session first for OAuth tokens (Max/Pro — no billing, better rate limits)
    if api_key.startswith("sk-ant-oat") or api_key.startswith("sk-ant-si-"):
        try:
            from .bridge import get_bridge
            bridge = get_bridge()
            if bridge.refresh_if_needed():
                headers = bridge.get_api_headers()
                api_url = bridge.get_api_url()
            else:
                # Bridge failed — fall back to direct OAuth
                headers = {
                    "Authorization": f"Bearer {api_key}",
                    "anthropic-version": "2023-06-01",
                    "anthropic-beta": "oauth-2025-04-20,claude-code-20250219",
                    "Content-Type": "application/json",
                    "x-app": "cli",
                }
        except Exception:
            headers = {
                "Authorization": f"Bearer {api_key}",
                "anthropic-version": "2023-06-01",
                "anthropic-beta": "oauth-2025-04-20",
                "Content-Type": "application/json",
            }
    else:
        headers = {
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }

    # Convert OpenAI-style messages to Anthropic format
    system_text = ""
    api_messages = []
    for m in messages:
        if m["role"] == "system":
            system_text = m["content"]
        elif m["role"] == "tool":
            # Merge consecutive tool results into a single user message
            tool_use_id = m.get("tool_use_id", "tool_0")
            tool_result_block = {"type": "tool_result", "tool_use_id": tool_use_id, "content": m["content"]}
            if api_messages and api_messages[-1]["role"] == "user" and isinstance(api_messages[-1]["content"], list):
                # Append to existing tool_result user message
                api_messages[-1]["content"].append(tool_result_block)
            else:
                api_messages.append({
                    "role": "user",
                    "content": [tool_result_block]
                })
        elif m["role"] == "assistant" and isinstance(m.get("content"), list):
            # Already structured content blocks (tool_use blocks)
            api_messages.append({"role": "assistant", "content": m["content"]})
        else:
            api_messages.append({"role": m["role"], "content": m["content"]})

    # Convert tools to Anthropic format
    anthropic_tools = None
    if tools:
        anthropic_tools = []
        for t in tools:
            func = t.get("function", {})
            anthropic_tools.append({
                "name": func["name"],
                "description": func.get("description", ""),
                "input_schema": func.get("parameters", {"type": "object", "properties": {}}),
            })

    body = {
        "model": model,
        "max_tokens": max_tokens,
        "stream": True,
        "messages": api_messages,
        "temperature": 0.3,
    }
    if system_text:
        body["system"] = system_text
    if anthropic_tools:
        body["tools"] = anthropic_tools

    with httpx.stream(
        "POST",
        f"{api_url}/v1/messages",
        headers=headers,
        json=body,
        timeout=None,
    ) as r:
        # Check for HTTP errors before streaming
        if r.status_code != 200:
            try:
                error_body = r.read().decode("utf-8", errors="replace")
                error_data = json.loads(error_body) if error_body.startswith("{") else {}
                error_msg = error_data.get("error", {}).get("message", error_body[:200])
            except Exception:
                error_msg = f"HTTP {r.status_code}"
            raise RuntimeError(f"Anthropic API error ({r.status_code}): {error_msg}")

        current_tool_name = ""
        current_tool_input = ""
        current_tool_id = ""

        for line in r.iter_lines():
            if not line or not line.startswith("data: "):
                continue
            try:
                data = json.loads(line[6:])
                event_type = data.get("type", "")

                if event_type == "content_block_delta":
                    delta = data.get("delta", {})
                    if delta.get("type") == "text_delta":
                        yield {"content": delta.get("text", "")}
                    elif delta.get("type") == "input_json_delta":
                        current_tool_input += delta.get("partial_json", "")

                elif event_type == "content_block_start":
                    block = data.get("content_block", {})
                    if block.get("type") == "tool_use":
                        current_tool_name = block.get("name", "")
                        current_tool_id = block.get("id", f"tool_{current_tool_name}")
                        current_tool_input = ""

                elif event_type == "content_block_stop":
                    if current_tool_name:
                        try:
                            args = json.loads(current_tool_input) if current_tool_input else {}
                        except json.JSONDecodeError:
                            args = {}
                        yield {
                            "tool_calls": [{
                                "id": current_tool_id,
                                "function": {
                                    "name": current_tool_name,
                                    "arguments": args,
                                }
                            }]
                        }
                        current_tool_name = ""
                        current_tool_input = ""
                        current_tool_id = ""

                elif event_type == "message_stop":
                    yield {"done": True, "eval_count": 0, "eval_duration": 0}

                elif event_type == "message_delta":
                    usage = data.get("usage", {})
                    if usage:
                        yield {
                            "done": True,
                            "eval_count": usage.get("output_tokens", 0),
                            "eval_duration": 0,
                        }

                elif event_type == "error":
                    error = data.get("error", {})
                    raise RuntimeError(f"Anthropic stream error: {error.get('message', str(error))}")

            except json.JSONDecodeError:
                continue


def stream_responses_api(
    messages: list[dict],
    tools: list[dict] | None,
    model: str,
    api_key: str,
    base_url: str = "https://api.openai.com/v1",
    max_tokens: int = 4096,
) -> Generator[dict, None, None]:
    """Stream from OpenAI's Responses API (used by Codex CLI).

    The Responses API has a different message and tool format than Chat Completions:
    - Tools use flat {name, description, parameters} instead of nested {function: {name, parameters}}
    - Messages use 'input' array instead of 'messages' array
    - System prompt goes in 'instructions' field
    - Tool results use {type: "function_call_output", call_id, output} format
    """
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }

    # Convert messages to Responses API input format
    instructions = ""
    input_items = []

    for m in messages:
        role = m.get("role", "")
        content = m.get("content", "")

        if role == "system":
            instructions = content if isinstance(content, str) else str(content)

        elif role == "user":
            if isinstance(content, str):
                input_items.append({
                    "type": "message",
                    "role": "user",
                    "content": content,
                })
            elif isinstance(content, list):
                # Handle structured content (tool_result blocks from Anthropic format)
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_result":
                        input_items.append({
                            "type": "function_call_output",
                            "call_id": block.get("tool_use_id", "call_0"),
                            "output": block.get("content", ""),
                        })
                    elif isinstance(block, dict) and block.get("type") == "text":
                        input_items.append({
                            "type": "message",
                            "role": "user",
                            "content": block.get("text", ""),
                        })

        elif role == "assistant":
            if isinstance(content, str):
                input_items.append({
                    "type": "message",
                    "role": "assistant",
                    "content": content,
                })
            elif isinstance(content, list):
                # Handle tool_use blocks
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_use":
                        input_items.append({
                            "type": "function_call",
                            "id": block.get("id", "call_0"),
                            "call_id": block.get("id", "call_0"),
                            "name": block.get("name", ""),
                            "arguments": json.dumps(block.get("input", {})),
                        })
                    elif isinstance(block, dict) and block.get("type") == "text":
                        input_items.append({
                            "type": "message",
                            "role": "assistant",
                            "content": block.get("text", ""),
                        })

        elif role == "tool":
            input_items.append({
                "type": "function_call_output",
                "call_id": m.get("tool_use_id", "call_0"),
                "output": content if isinstance(content, str) else str(content),
            })

    # Convert tools to Responses API format (flat, not nested in "function")
    responses_tools = None
    if tools:
        responses_tools = []
        for t in tools:
            func = t.get("function", {})
            params = func.get("parameters", {"type": "object", "properties": {}})
            # Responses API requires strict mode — ensure additionalProperties is set
            if "additionalProperties" not in params:
                params = {**params, "additionalProperties": False}
            # Ensure all properties are in required (strict mode)
            if "properties" in params and "required" not in params:
                params["required"] = list(params["properties"].keys())
            responses_tools.append({
                "type": "function",
                "name": func["name"],
                "description": func.get("description", ""),
                "parameters": params,
                "strict": True,
            })

    body = {
        "model": model,
        "input": input_items,
        "stream": True,
        "max_output_tokens": max_tokens,
        "temperature": 0.3,
    }
    if instructions:
        body["instructions"] = instructions
    if responses_tools:
        body["tools"] = responses_tools

    with httpx.stream(
        "POST",
        f"{base_url}/responses",
        headers=headers,
        json=body,
        timeout=None,
    ) as r:
        if r.status_code != 200:
            try:
                error_body = r.read().decode("utf-8", errors="replace")
                error_data = json.loads(error_body) if error_body.startswith("{") else {}
                error_msg = error_data.get("error", {}).get("message", error_body[:200])
            except Exception:
                error_msg = f"HTTP {r.status_code}"
            raise RuntimeError(f"Responses API error ({r.status_code}): {error_msg}")

        current_call_id = ""
        current_func_name = ""
        current_func_args = ""

        for line in r.iter_lines():
            if not line or not line.startswith("data: "):
                continue
            data_str = line[6:]
            if data_str.strip() == "[DONE]":
                yield {"done": True, "eval_count": 0, "eval_duration": 0}
                break
            try:
                data = json.loads(data_str)
                event_type = data.get("type", "")

                # Text output delta
                if event_type == "response.output_text.delta":
                    delta = data.get("delta", "")
                    if delta:
                        yield {"content": delta}

                # Function call arguments delta
                elif event_type == "response.function_call_arguments.delta":
                    current_func_args += data.get("delta", "")

                # Function call started
                elif event_type == "response.output_item.added":
                    item = data.get("item", {})
                    if item.get("type") == "function_call":
                        current_call_id = item.get("call_id", item.get("id", "call_0"))
                        current_func_name = item.get("name", "")
                        current_func_args = ""

                # Function call complete
                elif event_type == "response.function_call_arguments.done":
                    if current_func_name:
                        try:
                            args = json.loads(current_func_args) if current_func_args else {}
                        except json.JSONDecodeError:
                            args = {}
                        yield {
                            "tool_calls": [{
                                "id": current_call_id,
                                "function": {
                                    "name": current_func_name,
                                    "arguments": args,
                                }
                            }]
                        }
                        current_func_name = ""
                        current_func_args = ""
                        current_call_id = ""

                # Response complete
                elif event_type == "response.completed":
                    response = data.get("response", {})
                    usage = response.get("usage", {})
                    yield {
                        "done": True,
                        "eval_count": usage.get("output_tokens", 0),
                        "eval_duration": 0,
                    }

                # Error
                elif event_type == "error":
                    error = data.get("error", {})
                    raise RuntimeError(f"Responses API stream error: {error.get('message', str(error))}")

            except json.JSONDecodeError:
                continue


def _normalize_ollama_tool_calls(raw_calls: list) -> list:
    """Normalize Ollama tool calls to unified format.

    Ollama may return arguments as dict or JSON string, and may omit IDs.
    This normalizes to: {"id": str, "function": {"name": str, "arguments": dict}}
    """
    normalized = []
    for i, tc in enumerate(raw_calls):
        func = tc.get("function", {})
        name = func.get("name", "")
        args = func.get("arguments", {})
        # Arguments might be a JSON string instead of dict
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except (json.JSONDecodeError, TypeError):
                args = {}
        if not isinstance(args, dict):
            args = {}
        normalized.append({
            "id": tc.get("id", f"tool_{name}_{i}"),
            "function": {
                "name": name,
                "arguments": args,
            },
        })
    return normalized


def stream_ollama(
    messages: list[dict],
    tools: list[dict] | None,
    model: str,
    base_url: str,
    max_tokens: int = 4096,
    think: bool = False,
) -> Generator[dict, None, None]:
    """Stream from Ollama API."""
    from .llm import model_supports_tools
    use_tools = tools if (tools and model_supports_tools(model)) else None

    with httpx.stream(
        "POST",
        f"{base_url}/api/chat",
        json={
            "model": model,
            "messages": messages,
            "tools": use_tools,
            "stream": True,
            "think": think,
            "options": {
                "num_predict": max_tokens,
                "temperature": 0.3,
            },
        },
        timeout=None,
    ) as r:
        for line in r.iter_lines():
            if not line:
                continue
            data = json.loads(line)
            msg = data.get("message", {})
            result = {}
            if msg.get("thinking"):
                result["thinking"] = msg["thinking"]
            if msg.get("content"):
                result["content"] = msg["content"]
            if msg.get("tool_calls"):
                result["tool_calls"] = _normalize_ollama_tool_calls(msg["tool_calls"])
            if data.get("done"):
                result["done"] = True
                result["eval_count"] = data.get("eval_count", 0)
                result["eval_duration"] = data.get("eval_duration", 0)
            if result:
                yield result


# ── Unified streaming interface ──────────────────────────────────────

def stream_provider(
    provider_name: str,
    model: str,
    messages: list[dict],
    tools: list[dict] | None = None,
    max_tokens: int = 4096,
    think: bool = False,
) -> Generator[dict, None, None]:
    """Unified streaming interface for all providers.
    Yields dicts with 'content', 'thinking', 'tool_calls', 'done' keys."""

    info = BUILTIN_PROVIDERS.get(provider_name)
    if not info:
        yield {"content": f"[error: unknown provider '{provider_name}']", "done": True}
        return

    fmt = info["format"]

    if fmt == "ollama":
        yield from stream_ollama(messages, tools, model, info["base_url"], max_tokens, think)

    elif fmt == "anthropic":
        key = get_api_key(provider_name)
        if not key:
            yield {"content": f"[error: no API key for {provider_name}. Run /provider {provider_name} to configure]", "done": True}
            return
        yield from stream_anthropic(messages, tools, model, key, max_tokens)

    elif fmt == "responses":
        key = get_api_key(provider_name)
        if not key:
            yield {"content": f"[error: no API key for {provider_name}. Run /login openai <key> to configure]", "done": True}
            return
        yield from stream_responses_api(messages, tools, model, key, info["base_url"], max_tokens)

    elif fmt == "openai":
        key = get_api_key(provider_name)
        if not key:
            yield {"content": f"[error: no API key for {provider_name}. Run /provider {provider_name} to configure]", "done": True}
            return
        yield from stream_openai_compatible(messages, tools, model, info["base_url"], key, max_tokens)

    elif fmt == "airllm":
        from .airllm_provider import stream_airllm
        yield from stream_airllm(messages, tools or [], model, max_tokens)
