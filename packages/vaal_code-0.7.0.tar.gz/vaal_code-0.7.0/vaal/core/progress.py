"""Progress tracking — multi-step operation progress bars using Rich."""

import time
from typing import Optional
from dataclasses import dataclass, field

from rich.console import Console
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    TaskProgressColumn,
    TimeRemainingColumn,
    TimeElapsedColumn,
)
from rich.panel import Panel
from rich.text import Text

from .theme import VAAL_BLUE, VAAL_CYAN, VAAL_DIM, VAAL_GREEN, VAAL_THEME


@dataclass
class TrackerInfo:
    """Metadata for an active progress tracker."""
    name: str
    description: str
    total: float
    completed: float = 0.0
    started_at: float = field(default_factory=time.time)
    status: str = "running"  # running, paused, completed, failed


class ProgressTracker:
    """Manages multiple concurrent progress tracking operations.

    Usage:
        tracker = ProgressTracker(console)

        # For a known-length operation
        with tracker.task("Downloading model", total=100) as t:
            for chunk in download():
                t.advance(len(chunk))

        # For an indeterminate operation
        with tracker.task("Scanning files") as t:
            for f in files:
                t.update(description=f"Scanning {f}")
    """

    def __init__(self, console: Optional[Console] = None):
        self._console = console or Console(theme=VAAL_THEME)
        self._active: dict[str, TrackerInfo] = {}
        self._history: list[TrackerInfo] = []

    @property
    def active_count(self) -> int:
        return len(self._active)

    @property
    def active_trackers(self) -> dict[str, TrackerInfo]:
        return dict(self._active)

    def task(self, name: str, total: Optional[float] = None, description: str = "") -> "TaskContext":
        """Create a new tracked task context manager.

        Args:
            name: Display name for the task.
            total: Total units of work (None for indeterminate).
            description: Optional longer description.

        Returns:
            TaskContext that can be used as a context manager.
        """
        return TaskContext(self, name, total=total, description=description)

    def _register(self, name: str, info: TrackerInfo):
        self._active[name] = info

    def _complete(self, name: str, status: str = "completed"):
        info = self._active.pop(name, None)
        if info:
            info.status = status
            self._history.append(info)

    def _update(self, name: str, completed: float):
        if name in self._active:
            self._active[name].completed = completed

    def print_status(self):
        """Print status of all active and recent trackers."""
        console = self._console

        if not self._active and not self._history:
            console.print(f"[{VAAL_DIM}]  No active progress trackers.[/]")
            return

        console.print()
        console.print(f"[bold {VAAL_BLUE}]  Progress Trackers[/]")
        console.print(f"[{VAAL_DIM}]  {'─' * 40}[/]")

        # Active
        for name, info in self._active.items():
            elapsed = time.time() - info.started_at
            pct = (info.completed / info.total * 100) if info.total else 0
            bar = _make_bar(pct) if info.total else "..."

            console.print(
                f"  [{VAAL_CYAN}]{bar}[/] "
                f"[bold]{name}[/] "
                f"[{VAAL_DIM}]{info.completed:.0f}/{info.total or '?'} "
                f"({elapsed:.1f}s)[/]"
            )
            if info.description:
                console.print(f"    [{VAAL_DIM}]{info.description}[/]")

        # Recent completed (last 5)
        recent = self._history[-5:]
        if recent:
            console.print(f"\n  [{VAAL_DIM}]Recent:[/]")
            for info in recent:
                elapsed = time.time() - info.started_at
                icon = "done" if info.status == "completed" else "fail"
                style = VAAL_GREEN if info.status == "completed" else "#ab2b3f"
                console.print(
                    f"    [{style}]{icon}[/] "
                    f"[{VAAL_DIM}]{info.name} ({elapsed:.1f}s)[/]"
                )

        console.print()

    def summary_line(self) -> str:
        """One-line summary for status bar."""
        if not self._active:
            return ""
        names = list(self._active.keys())
        if len(names) == 1:
            info = self._active[names[0]]
            if info.total:
                pct = info.completed / info.total * 100
                return f"{names[0]} {pct:.0f}%"
            return names[0]
        return f"{len(names)} tasks"


class TaskContext:
    """Context manager for a single tracked task."""

    def __init__(self, tracker: ProgressTracker, name: str,
                 total: Optional[float] = None, description: str = ""):
        self._tracker = tracker
        self._name = name
        self._total = total
        self._description = description
        self._completed = 0.0
        self._progress: Optional[Progress] = None
        self._task_id = None

    def __enter__(self):
        info = TrackerInfo(
            name=self._name,
            description=self._description,
            total=self._total or 0,
        )
        self._tracker._register(self._name, info)

        # Create Rich progress bar
        columns = [
            SpinnerColumn(style=VAAL_BLUE),
            TextColumn(f"[bold {VAAL_BLUE}]{self._name}[/]"),
        ]
        if self._total:
            columns.extend([
                BarColumn(bar_width=30, style=VAAL_DIM, complete_style=VAAL_CYAN),
                TaskProgressColumn(),
                TimeRemainingColumn(),
            ])
        else:
            columns.append(TextColumn(f"[{VAAL_DIM}]{{task.description}}[/]"))

        self._progress = Progress(
            *columns,
            console=self._tracker._console,
            transient=True,
        )
        self._progress.start()
        self._task_id = self._progress.add_task(
            self._description,
            total=self._total,
        )
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._progress:
            self._progress.stop()
        status = "failed" if exc_type else "completed"
        self._tracker._complete(self._name, status)
        return False

    def advance(self, amount: float = 1.0):
        """Advance progress by amount."""
        self._completed += amount
        self._tracker._update(self._name, self._completed)
        if self._progress and self._task_id is not None:
            self._progress.update(self._task_id, advance=amount)

    def update(self, description: str = "", completed: Optional[float] = None):
        """Update task description or set absolute progress."""
        if completed is not None:
            self._completed = completed
            self._tracker._update(self._name, self._completed)
        if self._progress and self._task_id is not None:
            kwargs = {}
            if description:
                kwargs["description"] = description
            if completed is not None:
                kwargs["completed"] = completed
            self._progress.update(self._task_id, **kwargs)


def _make_bar(pct: float, width: int = 20) -> str:
    """Create a simple text progress bar."""
    filled = int(width * pct / 100)
    empty = width - filled
    return f"[{'█' * filled}{'░' * empty}] {pct:.0f}%"


# ── Global singleton ────────────────────────────────────────────────

_global_tracker: Optional[ProgressTracker] = None


def get_progress_tracker(console: Optional[Console] = None) -> ProgressTracker:
    """Get or create the global progress tracker."""
    global _global_tracker
    if _global_tracker is None:
        _global_tracker = ProgressTracker(console)
    return _global_tracker


def reset_progress_tracker():
    """Reset the global tracker."""
    global _global_tracker
    _global_tracker = None
