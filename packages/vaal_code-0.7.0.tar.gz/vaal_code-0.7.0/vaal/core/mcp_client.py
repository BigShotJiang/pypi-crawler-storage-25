"""MCP (Model Context Protocol) client — connect to MCP servers via stdio or HTTP."""

import json
import subprocess
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import VAAL_DIR

MCP_CONFIG_FILE = VAAL_DIR / "mcp_servers.json"


@dataclass
class MCPTool:
    """A tool exposed by an MCP server."""
    name: str
    description: str
    input_schema: dict
    server_name: str


@dataclass
class MCPServer:
    """A connected MCP server."""
    name: str
    command: list[str]
    tools: list[MCPTool] = field(default_factory=list)
    process: subprocess.Popen | None = None
    _request_id: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)
    _connected: bool = False

    @property
    def connected(self) -> bool:
        return self._connected and self.process is not None and self.process.poll() is None

    def _next_id(self) -> int:
        self._request_id += 1
        return self._request_id

    def _send_request(self, method: str, params: dict | None = None) -> dict | None:
        """Send a JSON-RPC request to the MCP server and wait for response."""
        if not self.process or self.process.poll() is not None:
            return None

        req_id = self._next_id()
        request = {
            "jsonrpc": "2.0",
            "id": req_id,
            "method": method,
        }
        if params:
            request["params"] = params

        try:
            with self._lock:
                msg = json.dumps(request) + "\n"
                self.process.stdin.write(msg)
                self.process.stdin.flush()

                # Read response line
                line = self.process.stdout.readline()
                if not line:
                    return None

                response = json.loads(line.strip())
                return response
        except (BrokenPipeError, OSError, json.JSONDecodeError):
            return None

    def connect(self) -> bool:
        """Start the MCP server subprocess and initialize."""
        try:
            self.process = subprocess.Popen(
                self.command,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
        except (FileNotFoundError, OSError) as e:
            return False

        # Send initialize request
        response = self._send_request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {
                "name": "vaal",
                "version": "0.6",
            },
        })

        if not response or "error" in response:
            self.disconnect()
            return False

        # Send initialized notification
        try:
            notification = json.dumps({
                "jsonrpc": "2.0",
                "method": "notifications/initialized",
            }) + "\n"
            self.process.stdin.write(notification)
            self.process.stdin.flush()
        except Exception:
            pass

        self._connected = True
        return True

    def list_tools(self) -> list[MCPTool]:
        """Request the list of tools from the server."""
        if not self.connected:
            return []

        response = self._send_request("tools/list")
        if not response or "error" in response:
            return []

        result = response.get("result", {})
        tools_data = result.get("tools", [])

        self.tools = []
        for t in tools_data:
            tool = MCPTool(
                name=t.get("name", ""),
                description=t.get("description", ""),
                input_schema=t.get("inputSchema", {"type": "object", "properties": {}}),
                server_name=self.name,
            )
            self.tools.append(tool)

        return self.tools

    def call_tool(self, tool_name: str, arguments: dict | None = None) -> Any:
        """Call a tool on the MCP server and return the result."""
        if not self.connected:
            return {"error": "Server not connected"}

        params = {"name": tool_name}
        if arguments:
            params["arguments"] = arguments

        response = self._send_request("tools/call", params)
        if not response:
            return {"error": "No response from server"}

        if "error" in response:
            return {"error": response["error"].get("message", "Unknown error")}

        result = response.get("result", {})
        # Extract text content from result
        content = result.get("content", [])
        if content:
            texts = []
            for block in content:
                if block.get("type") == "text":
                    texts.append(block.get("text", ""))
            return "\n".join(texts) if texts else result

        return result

    def disconnect(self):
        """Shut down the MCP server subprocess."""
        self._connected = False
        if self.process:
            try:
                self.process.stdin.close()
            except Exception:
                pass
            try:
                self.process.terminate()
                self.process.wait(timeout=5)
            except Exception:
                try:
                    self.process.kill()
                except Exception:
                    pass
            self.process = None
        self.tools = []


class MCPManager:
    """Manages multiple MCP server connections."""

    def __init__(self):
        self.servers: dict[str, MCPServer] = {}
        self._load_config()

    def _load_config(self):
        """Load saved MCP server configurations."""
        if MCP_CONFIG_FILE.exists():
            try:
                data = json.loads(MCP_CONFIG_FILE.read_text(encoding="utf-8"))
                # Config format: {"servers": {"name": {"command": [...]}}}
                for name, cfg in data.get("servers", {}).items():
                    command = cfg.get("command", [])
                    if command:
                        self.servers[name] = MCPServer(
                            name=name,
                            command=command,
                        )
            except Exception:
                pass

    def _save_config(self):
        """Save MCP server configurations."""
        VAAL_DIR.mkdir(exist_ok=True)
        data = {
            "servers": {
                name: {"command": server.command}
                for name, server in self.servers.items()
            }
        }
        MCP_CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def connect(self, name: str, command: str | list[str]) -> tuple[bool, str]:
        """Connect to an MCP server.

        Args:
            name: Display name for the server
            command: Shell command string or list to spawn the server

        Returns:
            (success, message)
        """
        if isinstance(command, str):
            import shlex
            cmd_list = shlex.split(command)
        else:
            cmd_list = command

        if not cmd_list:
            return False, "Empty command"

        # Disconnect existing server with same name
        if name in self.servers and self.servers[name].connected:
            self.servers[name].disconnect()

        server = MCPServer(name=name, command=cmd_list)
        if not server.connect():
            return False, f"Failed to start MCP server: {' '.join(cmd_list)}"

        tools = server.list_tools()
        self.servers[name] = server
        self._save_config()

        tool_names = [t.name for t in tools]
        return True, f"Connected to '{name}' with {len(tools)} tools: {', '.join(tool_names[:10])}"

    def disconnect(self, name: str) -> tuple[bool, str]:
        """Disconnect from an MCP server."""
        if name not in self.servers:
            return False, f"No server named '{name}'"

        self.servers[name].disconnect()
        del self.servers[name]
        self._save_config()
        return True, f"Disconnected from '{name}'"

    def list_servers(self) -> list[dict]:
        """List all configured servers and their status."""
        result = []
        for name, server in self.servers.items():
            result.append({
                "name": name,
                "command": " ".join(server.command),
                "connected": server.connected,
                "tools": [t.name for t in server.tools],
            })
        return result

    def get_all_tools(self) -> list[MCPTool]:
        """Get all tools from all connected servers."""
        tools = []
        for server in self.servers.values():
            if server.connected:
                tools.extend(server.tools)
        return tools

    def call_tool(self, tool_name: str, arguments: dict | None = None) -> Any:
        """Call a tool by name, finding the right server automatically."""
        for server in self.servers.values():
            if not server.connected:
                continue
            for tool in server.tools:
                if tool.name == tool_name:
                    return server.call_tool(tool_name, arguments)
        return {"error": f"Tool '{tool_name}' not found on any connected server"}

    def disconnect_all(self):
        """Disconnect from all servers."""
        for server in self.servers.values():
            server.disconnect()
        self.servers.clear()


# Singleton
_manager: MCPManager | None = None


def get_mcp_manager() -> MCPManager:
    """Get the global MCP manager instance."""
    global _manager
    if _manager is None:
        _manager = MCPManager()
    return _manager
