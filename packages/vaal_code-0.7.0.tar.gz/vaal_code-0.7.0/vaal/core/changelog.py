"""Changelog — view prompt history with the file changes each prompt produced.

Parses session data to correlate user prompts with the tool calls (write, edit,
bash, apply_patch, etc.) that followed, showing what actually changed.
"""

import json
import os
import time
from pathlib import Path
from dataclasses import dataclass, field

from .config import SESSIONS_DIR, HISTORY_FILE, ensure_dirs


@dataclass
class FileChange:
    """A single file change extracted from a tool call."""
    tool: str           # "write", "edit", "bash", "apply_patch", etc.
    file_path: str      # Affected file path (short)
    description: str    # One-line summary of what happened


@dataclass
class PromptEntry:
    """A prompt with its associated changes."""
    timestamp: float
    iso: str
    prompt: str
    model: str
    session_id: str
    changes: list[FileChange] = field(default_factory=list)
    tool_calls: int = 0


def _short_path(path: str) -> str:
    """Shorten a file path for display."""
    if not path:
        return ""
    # Try to make relative to cwd
    try:
        rel = os.path.relpath(path)
        if not rel.startswith(".."):
            return rel.replace("\\", "/")
    except ValueError:
        pass
    # Just use basename with parent
    p = Path(path)
    if len(p.parts) > 2:
        return f"…/{p.parts[-2]}/{p.name}"
    return p.name


def _extract_changes_from_messages(messages: list[dict], start_idx: int, end_idx: int) -> tuple[list[FileChange], int]:
    """Extract file changes from session messages between two user messages.

    Scans assistant messages for tool_use blocks and the subsequent tool results
    to identify file modifications.

    Returns (changes, tool_call_count).
    """
    changes = []
    tool_count = 0
    has_cloud_tools = False  # Track if we found cloud-style tool_use blocks

    i = start_idx
    while i < end_idx:
        msg = messages[i]
        role = msg.get("role", "")

        # Handle cloud-style assistant messages with content blocks
        if role == "assistant":
            content = msg.get("content", "")
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "tool_use":
                        has_cloud_tools = True
                        tool_count += 1
                        name = block.get("name", "")
                        inp = block.get("input", {})
                        change = _classify_tool_call(name, inp)
                        if change:
                            changes.append(change)

        # Handle tool result messages — for Ollama-style (no tool_use blocks)
        # we parse the result content to detect file changes
        elif role == "tool":
            if not has_cloud_tools:
                tool_count += 1
            content = str(msg.get("content", ""))
            # Only extract from tool results if we didn't already get it from
            # the cloud-style tool_use blocks
            if not has_cloud_tools:
                if "Wrote " in content and " bytes to " in content:
                    try:
                        path = content.split(" bytes to ")[-1].strip().rstrip(".")
                        changes.append(FileChange("write", _short_path(path), f"Created/wrote {_short_path(path)}"))
                    except (IndexError, ValueError):
                        pass
                elif "Replaced 1 occurrence" in content or "Applied edit" in content:
                    changes.append(FileChange("edit", "", "Edited file"))

        i += 1

    return changes, tool_count


def _classify_tool_call(name: str, args: dict) -> FileChange | None:
    """Classify a tool call as a file change, or None if it's not a change."""
    if name == "write":
        path = args.get("file_path", args.get("path", ""))
        short = _short_path(path)
        content = args.get("content", "")
        lines = content.count("\n") + 1 if content else 0
        return FileChange("write", short, f"Wrote {short} ({lines} lines)")

    elif name == "edit":
        path = args.get("file_path", "")
        short = _short_path(path)
        old = args.get("old_string", "")
        new = args.get("new_string", "")
        if old and not new:
            return FileChange("edit", short, f"Deleted from {short}")
        elif not old and new:
            return FileChange("edit", short, f"Inserted into {short}")
        else:
            return FileChange("edit", short, f"Updated {short}")

    elif name == "apply_patch":
        path = args.get("file_path", "")
        short = _short_path(path)
        return FileChange("apply_patch", short, f"Patched {short}")

    elif name == "bash":
        cmd = args.get("command", "")
        # Detect file-modifying commands
        first_line = cmd.split("\n")[0].strip()
        for pattern in ["mkdir", "rm ", "mv ", "cp ", "touch ", "echo ", "> ", ">> ", "sed ", "cat >", "pip install", "npm install", "git "]:
            if pattern in first_line:
                return FileChange("bash", "", f"$ {first_line[:60]}")
        return None

    elif name == "git_commit":
        msg = args.get("message", "")
        files = args.get("files", "")
        return FileChange("git_commit", files, f"Committed: {msg[:50]}")

    elif name == "notebook_edit":
        path = args.get("path", "")
        action = args.get("action", "")
        short = _short_path(path)
        return FileChange("notebook_edit", short, f"{action} cell in {short}")

    return None


def _find_user_message_indices(messages: list[dict]) -> list[int]:
    """Find indices of all user messages (excluding system)."""
    indices = []
    for i, msg in enumerate(messages):
        if msg.get("role") == "user":
            content = str(msg.get("content", ""))
            # Skip system-injected messages (sub-agent results, auto-fix, etc.)
            if content.startswith("[Sub-agent "):
                continue
            indices.append(i)
    return indices


def _load_session_safe(session_id: str) -> dict | None:
    """Load a session file, returning None on any error."""
    try:
        path = SESSIONS_DIR / f"{session_id}.json"
        if not path.exists():
            return None
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def build_changelog(limit: int = 20) -> list[PromptEntry]:
    """Build a changelog: prompt history entries enriched with file changes.

    For each prompt in history.jsonl, loads the corresponding session and
    extracts the tool calls / file changes that followed that prompt.
    """
    ensure_dirs()
    if not HISTORY_FILE.exists():
        return []

    # Load all history entries
    all_entries = []
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                all_entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    entries = all_entries[-limit:]

    # Cache loaded sessions
    session_cache: dict[str, dict | None] = {}

    results = []
    for entry in entries:
        sid = entry.get("session_id", "")
        prompt_text = entry.get("prompt", "")
        ts = entry.get("timestamp", 0)

        pe = PromptEntry(
            timestamp=ts,
            iso=entry.get("iso", "?"),
            prompt=prompt_text,
            model=entry.get("model", "?"),
            session_id=sid,
        )

        # Try to find changes from the session
        if sid and sid not in session_cache:
            session_cache[sid] = _load_session_safe(sid)

        session_data = session_cache.get(sid)
        if session_data:
            messages = session_data.get("messages", [])
            user_indices = _find_user_message_indices(messages)

            # Find which user message matches this prompt
            matched_idx = None
            for ui in user_indices:
                msg_content = str(messages[ui].get("content", ""))
                # Prompts are stored with CWD prefix: "[CWD: ...]\n<prompt>"
                if prompt_text in msg_content:
                    # Check timestamp proximity if available
                    msg_ts = messages[ui].get("timestamp", 0)
                    if msg_ts and ts:
                        # Within 5 seconds = match
                        if abs(msg_ts - ts) < 5:
                            matched_idx = ui
                            break
                    else:
                        matched_idx = ui
                        break

            if matched_idx is not None:
                # Find the end boundary (next user message or end of messages)
                next_user = len(messages)
                for ui in user_indices:
                    if ui > matched_idx:
                        next_user = ui
                        break

                changes, tool_count = _extract_changes_from_messages(
                    messages, matched_idx + 1, next_user
                )
                pe.changes = changes
                pe.tool_calls = tool_count

        results.append(pe)

    return results


def build_changelog_for_session(session_id: str) -> list[PromptEntry]:
    """Build a changelog for a specific session by walking its messages directly."""
    session_data = _load_session_safe(session_id)
    if not session_data:
        return []

    messages = session_data.get("messages", [])
    model = session_data.get("model", "?")
    user_indices = _find_user_message_indices(messages)

    results = []
    for j, ui in enumerate(user_indices):
        msg = messages[ui]
        content = str(msg.get("content", ""))
        ts = msg.get("timestamp", 0)

        # Strip CWD prefix
        prompt = content
        if prompt.startswith("[CWD:"):
            newline = prompt.find("\n")
            if newline >= 0:
                prompt = prompt[newline + 1:]

        # Find end boundary
        next_user = user_indices[j + 1] if j + 1 < len(user_indices) else len(messages)

        changes, tool_count = _extract_changes_from_messages(messages, ui + 1, next_user)

        pe = PromptEntry(
            timestamp=ts,
            iso=time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts)) if ts else "?",
            prompt=prompt,
            model=model,
            session_id=session_id,
            changes=changes,
            tool_calls=tool_count,
        )
        results.append(pe)

    return results
