"""Vaal theme — crimson corruption, Vaal orb aesthetic."""

from rich.theme import Theme

# Crimson corruption palette
VAAL_RED = "#ab2b3f"          # Primary crimson (was VAAL_BLUE)
VAAL_CRIMSON = "#cc3333"      # Accent crimson (was VAAL_BLUE_LIGHT)
VAAL_DEEP = "#8b1a2b"         # Dim crimson (was VAAL_BLUE_DIM)
VAAL_GOLD = "#d4a373"         # Stats/metrics (was VAAL_CYAN)
VAAL_GREEN = "#2c7a39"        # Success
VAAL_ERROR = "#ff4455"        # Error (brighter for visibility)
VAAL_YELLOW = "#966c1e"       # Warning
VAAL_DIM = "#888888"          # Dim/subtle text
VAAL_DIMMER = "#555555"       # Even dimmer

# Legacy aliases — existing code references these names
VAAL_BLUE = VAAL_RED
VAAL_BLUE_LIGHT = VAAL_CRIMSON
VAAL_BLUE_DIM = VAAL_DEEP
VAAL_CYAN = VAAL_GOLD

# Theme for rich console
VAAL_THEME = Theme({
    "vaal.prompt": f"bold {VAAL_RED}",
    "vaal.user_label": "bold white",
    "vaal.assistant_label": f"bold {VAAL_RED}",
    "vaal.tool_prefix": f"{VAAL_DIM}",
    "vaal.tool_name": f"bold {VAAL_RED}",
    "vaal.tool_output": f"{VAAL_DIM}",
    "vaal.success": f"{VAAL_GREEN}",
    "vaal.error": f"{VAAL_ERROR}",
    "vaal.warning": f"{VAAL_YELLOW}",
    "vaal.dim": f"{VAAL_DIM}",
    "vaal.dimmer": f"{VAAL_DIMMER}",
    "vaal.status": f"{VAAL_DIM}",
    "vaal.stats": f"{VAAL_GOLD}",
    "vaal.spinner": f"{VAAL_RED}",
    "vaal.permission": f"bold {VAAL_RED}",
    "vaal.key": f"bold {VAAL_DIM}",
    # Markdown overrides
    "markdown.h1": f"bold {VAAL_RED}",
    "markdown.h2": f"bold {VAAL_RED}",
    "markdown.h3": f"bold {VAAL_RED}",
    "markdown.link": f"{VAAL_GOLD} underline",
    "markdown.item.number": f"bold {VAAL_GOLD}",
    "markdown.item.bullet": f"{VAAL_GOLD}",
    "markdown.code": f"bold #e0e0e0 on #1a1a2e",
})

# Tool output prefix (Claude's ⎿ character)
TOOL_PREFIX = "  ⎿  "

# Spinner frames
SPINNER_FRAMES = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
