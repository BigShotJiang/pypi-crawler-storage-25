"""Scheduler — run prompts on recurring intervals in background threads."""

import json
import os
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path

from .config import VAAL_DIR

SCHEDULE_RESULTS_DIR = VAAL_DIR / "schedule_results"


def _parse_interval(interval_str: str) -> float | None:
    """Parse an interval string like '5m', '1h', '30s' into seconds.

    Returns None if unparseable.
    """
    m = re.match(r"^(\d+)\s*(s|sec|secs|m|min|mins|h|hr|hrs|hour|hours)$", interval_str.strip().lower())
    if not m:
        return None
    value = int(m.group(1))
    unit = m.group(2)
    if unit.startswith("s"):
        return float(value)
    elif unit.startswith("m"):
        return float(value * 60)
    elif unit.startswith("h"):
        return float(value * 3600)
    return None


@dataclass
class ScheduleResult:
    """Result from a single scheduled run."""
    run_number: int
    timestamp: float
    output: str
    error: str = ""


@dataclass
class ScheduledTask:
    """A recurring scheduled task."""
    task_id: str
    interval_str: str
    interval_seconds: float
    prompt: str
    created_at: float = field(default_factory=time.time)
    run_count: int = 0
    last_run: float = 0.0
    results: list[ScheduleResult] = field(default_factory=list)
    _thread: threading.Thread | None = field(default=None, repr=False)
    _stop_event: threading.Event = field(default_factory=threading.Event, repr=False)
    _active: bool = False

    @property
    def active(self) -> bool:
        return self._active and not self._stop_event.is_set()

    def to_dict(self) -> dict:
        return {
            "task_id": self.task_id,
            "interval_str": self.interval_str,
            "interval_seconds": self.interval_seconds,
            "prompt": self.prompt,
            "created_at": self.created_at,
            "run_count": self.run_count,
            "last_run": self.last_run,
            "active": self.active,
        }


class Scheduler:
    """Manages recurring scheduled prompts."""

    def __init__(self):
        self._tasks: dict[str, ScheduledTask] = {}
        self._next_id = 1
        self._lock = threading.Lock()
        self._runner = None  # Will be set to a callable(prompt) -> str

    def set_runner(self, runner):
        """Set the function that runs prompts. Signature: runner(prompt: str) -> str"""
        self._runner = runner

    def schedule(self, interval_str: str, prompt: str) -> ScheduledTask | None:
        """Create a new scheduled task.

        Args:
            interval_str: Interval like '5m', '1h', '30s'
            prompt: The prompt to run

        Returns:
            The created task, or None if interval is invalid.
        """
        seconds = _parse_interval(interval_str)
        if seconds is None:
            return None
        if seconds < 10:
            seconds = 10  # Minimum 10 seconds

        with self._lock:
            task_id = f"sched-{self._next_id}"
            self._next_id += 1

        task = ScheduledTask(
            task_id=task_id,
            interval_str=interval_str,
            interval_seconds=seconds,
            prompt=prompt,
        )

        with self._lock:
            self._tasks[task_id] = task

        # Start the background thread
        self._start_task(task)
        return task

    def _start_task(self, task: ScheduledTask):
        """Start the background thread for a task."""
        task._stop_event.clear()
        task._active = True

        def _run_loop():
            while not task._stop_event.is_set():
                # Wait for interval
                task._stop_event.wait(task.interval_seconds)
                if task._stop_event.is_set():
                    break

                # Run the prompt
                task.run_count += 1
                task.last_run = time.time()
                output = ""
                error = ""

                if self._runner:
                    try:
                        output = self._runner(task.prompt)
                    except Exception as e:
                        error = str(e)
                else:
                    error = "No runner configured"

                result = ScheduleResult(
                    run_number=task.run_count,
                    timestamp=time.time(),
                    output=output,
                    error=error,
                )

                # Keep last 50 results in memory
                task.results.append(result)
                if len(task.results) > 50:
                    task.results = task.results[-50:]

                # Save result to disk
                self._save_result(task, result)

            task._active = False

        thread = threading.Thread(target=_run_loop, daemon=True, name=f"scheduler-{task.task_id}")
        task._thread = thread
        thread.start()

    def _save_result(self, task: ScheduledTask, result: ScheduleResult):
        """Save a schedule result to disk."""
        try:
            SCHEDULE_RESULTS_DIR.mkdir(parents=True, exist_ok=True)
            result_file = SCHEDULE_RESULTS_DIR / f"{task.task_id}.jsonl"
            entry = {
                "run": result.run_number,
                "timestamp": result.timestamp,
                "prompt": task.prompt,
                "output": result.output[:5000],  # Cap output size
                "error": result.error,
            }
            with open(result_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            pass

    def stop(self, task_id: str) -> bool:
        """Stop a scheduled task.

        Returns True if found and stopped.
        """
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return False

        task._stop_event.set()
        if task._thread and task._thread.is_alive():
            task._thread.join(timeout=2)

        with self._lock:
            if task_id in self._tasks:
                del self._tasks[task_id]

        return True

    def stop_all(self):
        """Stop all scheduled tasks."""
        with self._lock:
            task_ids = list(self._tasks.keys())
        for tid in task_ids:
            self.stop(tid)

    def list_tasks(self) -> list[dict]:
        """List all scheduled tasks."""
        with self._lock:
            return [task.to_dict() for task in self._tasks.values()]

    def get_results(self, task_id: str, limit: int = 10) -> list[ScheduleResult]:
        """Get recent results for a task."""
        with self._lock:
            task = self._tasks.get(task_id)
            if not task:
                return []
            return task.results[-limit:]

    def get_task(self, task_id: str) -> ScheduledTask | None:
        """Get a task by ID."""
        with self._lock:
            return self._tasks.get(task_id)


# Singleton
_scheduler: Scheduler | None = None


def get_scheduler() -> Scheduler:
    """Get the global scheduler instance."""
    global _scheduler
    if _scheduler is None:
        _scheduler = Scheduler()
    return _scheduler
