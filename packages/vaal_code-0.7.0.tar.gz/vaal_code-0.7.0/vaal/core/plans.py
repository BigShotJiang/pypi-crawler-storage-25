"""Implementation planning — persistent plans with step tracking."""

import json
import time
import uuid
from pathlib import Path
from dataclasses import dataclass, field

from .config import PLANS_DIR, ensure_dirs


@dataclass
class Step:
    description: str
    status: str = "pending"       # pending, in_progress, done, skipped
    notes: str = ""

    def to_dict(self) -> dict:
        return {
            "description": self.description,
            "status": self.status,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Step":
        return cls(
            description=data.get("description", ""),
            status=data.get("status", "pending"),
            notes=data.get("notes", ""),
        )


@dataclass
class Plan:
    plan_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    title: str = ""
    steps: list[Step] = field(default_factory=list)
    current_step: int = 0
    status: str = "active"        # active, completed, abandoned
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    @property
    def progress(self) -> str:
        if not self.steps:
            return "0/0"
        done = sum(1 for s in self.steps if s.status in ("done", "skipped"))
        return f"{done}/{len(self.steps)}"

    @property
    def progress_pct(self) -> float:
        if not self.steps:
            return 0.0
        done = sum(1 for s in self.steps if s.status in ("done", "skipped"))
        return done / len(self.steps)

    def advance(self):
        """Mark current step done and move to next."""
        if self.current_step < len(self.steps):
            self.steps[self.current_step].status = "done"
            self.current_step += 1
            if self.current_step < len(self.steps):
                self.steps[self.current_step].status = "in_progress"
            else:
                self.status = "completed"
        self.updated_at = time.time()

    def skip_current(self):
        """Skip current step and move to next."""
        if self.current_step < len(self.steps):
            self.steps[self.current_step].status = "skipped"
            self.current_step += 1
            if self.current_step < len(self.steps):
                self.steps[self.current_step].status = "in_progress"
            else:
                self.status = "completed"
        self.updated_at = time.time()

    def start(self):
        """Start the plan — mark first step in_progress."""
        if self.steps and self.steps[0].status == "pending":
            self.steps[0].status = "in_progress"
            self.current_step = 0
        self.updated_at = time.time()

    def add_note(self, step_index: int, note: str):
        """Add a note to a specific step."""
        if 0 <= step_index < len(self.steps):
            existing = self.steps[step_index].notes
            if existing:
                self.steps[step_index].notes = f"{existing}\n{note}"
            else:
                self.steps[step_index].notes = note
            self.updated_at = time.time()

    def to_dict(self) -> dict:
        return {
            "plan_id": self.plan_id,
            "title": self.title,
            "steps": [s.to_dict() for s in self.steps],
            "current_step": self.current_step,
            "status": self.status,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Plan":
        return cls(
            plan_id=data.get("plan_id", str(uuid.uuid4())[:8]),
            title=data.get("title", ""),
            steps=[Step.from_dict(s) for s in data.get("steps", [])],
            current_step=data.get("current_step", 0),
            status=data.get("status", "active"),
            created_at=data.get("created_at", time.time()),
            updated_at=data.get("updated_at", time.time()),
        )

    def save(self):
        """Save plan to disk."""
        ensure_dirs()
        path = PLANS_DIR / f"{self.plan_id}.json"
        path.write_text(json.dumps(self.to_dict(), indent=2), encoding="utf-8")

    @classmethod
    def load(cls, plan_id: str) -> "Plan":
        path = PLANS_DIR / f"{plan_id}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls.from_dict(data)

    def to_display(self) -> str:
        """Render plan as a readable string for display."""
        status_icons = {
            "pending": "  ",
            "in_progress": "->",
            "done": "ok",
            "skipped": "--",
        }
        lines = [
            f"Plan: {self.title} [{self.plan_id}]",
            f"Status: {self.status} ({self.progress})",
            "",
        ]
        for i, step in enumerate(self.steps):
            icon = status_icons.get(step.status, "  ")
            marker = f"[{icon}]"
            lines.append(f"  {i+1}. {marker} {step.description}")
            if step.notes:
                for note_line in step.notes.splitlines():
                    lines.append(f"        {note_line}")
        return "\n".join(lines)

    def to_prompt_section(self) -> str:
        """Build a prompt section describing the current plan state."""
        lines = [
            f"## Active Plan: {self.title}",
            f"Progress: {self.progress} steps complete",
            "",
        ]
        for i, step in enumerate(self.steps):
            prefix = ">>>" if i == self.current_step else "   "
            lines.append(f"{prefix} {i+1}. [{step.status}] {step.description}")
            if step.notes:
                lines.append(f"       Notes: {step.notes}")
        return "\n".join(lines)


def list_plans(status_filter: str | None = None) -> list[Plan]:
    """List all saved plans, optionally filtered by status."""
    ensure_dirs()
    plans = []
    for f in sorted(PLANS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            data = json.loads(f.read_text(encoding="utf-8"))
            plan = Plan.from_dict(data)
            if status_filter and plan.status != status_filter:
                continue
            plans.append(plan)
        except Exception:
            continue
    return plans


def get_active_plan() -> Plan | None:
    """Get the most recently updated active plan, if any."""
    active = list_plans(status_filter="active")
    return active[0] if active else None


def create_plan(title: str, step_descriptions: list[str]) -> Plan:
    """Create and save a new plan."""
    steps = [Step(description=desc) for desc in step_descriptions]
    plan = Plan(title=title, steps=steps)
    plan.start()
    plan.save()
    return plan
