"""Split pane — file preview panel above the prompt."""

import os
import sys
import time
import threading

ESC = "\033"
RESET = f"{ESC}[0m"
DIM = f"{ESC}[2m"
BOLD = f"{ESC}[1m"
C_BLUE = f"{ESC}[38;5;63m"
C_CYAN = f"{ESC}[38;5;80m"
C_DIM = f"{ESC}[38;5;242m"
C_WHITE = f"{ESC}[37m"
BOX_TOP_LEFT = "\u250c"
BOX_TOP_RIGHT = "\u2510"
BOX_BOTTOM_LEFT = "\u2514"
BOX_BOTTOM_RIGHT = "\u2518"
BOX_H = "\u2500"
BOX_V = "\u2502"


class SplitPane:
    """Shows the last N lines of a watched file above the prompt.

    Usage:
        pane = SplitPane()
        pane.set_file("src/main.py")   # /split src/main.py
        pane.render()                   # call before each prompt
        pane.disable()                  # /split off
    """

    def __init__(self, preview_lines: int = 20):
        self.enabled: bool = False
        self.file_path: str | None = None
        self.preview_lines: int = preview_lines
        self._last_mtime: float = 0.0
        self._cached_lines: list[str] = []
        self._watcher_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._on_change_callback = None

    # ── Public API ────────────────────────────────────────────────────

    def set_file(self, path: str) -> str:
        """Set the file to watch. Returns a status message."""
        abs_path = os.path.abspath(path)
        if not os.path.isfile(abs_path):
            return f"File not found: {path}"
        self.file_path = abs_path
        self.enabled = True
        self._last_mtime = 0.0
        self._refresh_cache()
        self._start_watcher()
        short = os.path.basename(abs_path)
        return f"Split pane watching: {short} (last {self.preview_lines} lines)"

    def disable(self) -> str:
        """Disable split pane."""
        self.enabled = False
        self.file_path = None
        self._cached_lines = []
        self._stop_watcher()
        return "Split pane disabled."

    def set_change_callback(self, callback):
        """Set callback invoked when watched file changes (for auto-refresh)."""
        self._on_change_callback = callback

    def render(self) -> str:
        """Return the preview panel as a string to print above the prompt."""
        if not self.enabled or not self.file_path:
            return ""
        self._refresh_cache()
        if not self._cached_lines:
            return ""
        return self._format_panel()

    def handle_command(self, arg: str) -> str:
        """Handle /split command arguments.

        /split <file>  - set file
        /split off     - disable
        /split         - show status
        """
        arg = arg.strip()
        if not arg:
            if self.enabled and self.file_path:
                short = os.path.basename(self.file_path)
                return f"Split pane active: {short} (last {self.preview_lines} lines). Use /split off to disable."
            return "Split pane is off. Use /split <file> to watch a file."
        if arg.lower() == "off":
            return self.disable()
        return self.set_file(arg)

    # ── Internal ──────────────────────────────────────────────────────

    def _refresh_cache(self):
        """Re-read the file if it has been modified."""
        if not self.file_path or not os.path.isfile(self.file_path):
            return
        try:
            mtime = os.path.getmtime(self.file_path)
            if mtime == self._last_mtime and self._cached_lines:
                return
            self._last_mtime = mtime
            with open(self.file_path, "r", encoding="utf-8", errors="replace") as f:
                all_lines = f.readlines()
            # Take last N lines
            start = max(0, len(all_lines) - self.preview_lines)
            self._cached_lines = [
                line.rstrip("\n\r") for line in all_lines[start:]
            ]
        except Exception:
            self._cached_lines = ["[error reading file]"]

    def _format_panel(self) -> str:
        """Format the file preview as a bordered panel."""
        if not self.file_path:
            return ""

        short_name = os.path.basename(self.file_path)
        try:
            total_lines = sum(1 for _ in open(self.file_path, "r", encoding="utf-8", errors="replace"))
        except Exception:
            total_lines = len(self._cached_lines)

        start_line = max(1, total_lines - self.preview_lines + 1)

        # Determine width
        try:
            term_width = os.get_terminal_size().columns
        except Exception:
            term_width = 80
        inner_width = min(term_width - 4, 120)

        lines = []

        # Top border with filename
        title = f" {short_name} (lines {start_line}-{total_lines}) "
        remaining = inner_width - len(title)
        left_dash = remaining // 2
        right_dash = remaining - left_dash
        lines.append(
            f"  {C_DIM}{BOX_TOP_LEFT}{BOX_H * left_dash}{RESET}"
            f"{C_CYAN}{BOLD}{title}{RESET}"
            f"{C_DIM}{BOX_H * right_dash}{BOX_TOP_RIGHT}{RESET}"
        )

        # Content lines with line numbers
        for i, content in enumerate(self._cached_lines):
            line_num = start_line + i
            num_str = f"{line_num:>4}"
            # Truncate long lines
            max_content = inner_width - 7  # 4 num + 2 padding + 1 border
            if len(content) > max_content:
                content = content[:max_content - 3] + "..."
            pad = inner_width - len(num_str) - len(content) - 3
            if pad < 0:
                pad = 0
            lines.append(
                f"  {C_DIM}{BOX_V}{RESET} {C_DIM}{num_str}{RESET} {C_WHITE}{content}{RESET}"
                f"{' ' * pad}{C_DIM}{BOX_V}{RESET}"
            )

        # Bottom border
        lines.append(f"  {C_DIM}{BOX_BOTTOM_LEFT}{BOX_H * inner_width}{BOX_BOTTOM_RIGHT}{RESET}")

        return "\n".join(lines)

    def _start_watcher(self):
        """Start background thread that watches for file changes."""
        self._stop_watcher()
        self._stop_event.clear()
        self._watcher_thread = threading.Thread(
            target=self._watch_loop, daemon=True
        )
        self._watcher_thread.start()

    def _stop_watcher(self):
        """Stop the background watcher thread."""
        self._stop_event.set()
        self._watcher_thread = None

    def _watch_loop(self):
        """Poll file mtime and invoke callback on change."""
        while not self._stop_event.is_set():
            if self.file_path and os.path.isfile(self.file_path):
                try:
                    mtime = os.path.getmtime(self.file_path)
                    if mtime != self._last_mtime:
                        self._refresh_cache()
                        if self._on_change_callback:
                            self._on_change_callback()
                except Exception:
                    pass
            self._stop_event.wait(1.0)  # Check every second
