"""Interactive login screen — provider selection and authentication."""

import sys
import os
import subprocess
import time

ESC = "\033"
HIDE_CURSOR = f"{ESC}[?25l"
SHOW_CURSOR = f"{ESC}[?25h"
CLEAR_SCREEN = f"{ESC}[2J{ESC}[H"
ALT_SCREEN_ON = f"{ESC}[?1049h"
ALT_SCREEN_OFF = f"{ESC}[?1049l"
CLEAR_LINE = f"{ESC}[2K"
RESET = f"{ESC}[0m"
BOLD = f"{ESC}[1m"
C_BLUE = f"{ESC}[38;5;63m"
C_CYAN = f"{ESC}[38;5;80m"
C_GREEN = f"{ESC}[38;5;34m"
C_YELLOW = f"{ESC}[38;5;178m"
C_DIM = f"{ESC}[38;5;242m"
C_WHITE = f"{ESC}[37m"
C_BOLD_WHITE = f"{ESC}[1;37m"
C_BG_SELECT = f"{ESC}[48;5;236m"
C_PURPLE = f"{ESC}[38;5;141m"


def _write(s):
    sys.stdout.write(s)
    sys.stdout.flush()


def _read_key():
    if sys.platform == "win32":
        import msvcrt
        key = msvcrt.getwch()
        if key in ("\x00", "\xe0"):
            key2 = msvcrt.getwch()
            if key2 == "H": return "up"
            elif key2 == "P": return "down"
            return "special"
        elif key == "\r": return "enter"
        elif key == "\x1b": return "escape"
        elif key == "\x08": return "backspace"
        elif key == "\x03": return "escape"
        return key
    else:
        import tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "A": return "up"
                    elif ch3 == "B": return "down"
                return "escape"
            elif ch == "\r": return "enter"
            elif ch == "\x7f" or ch == "\x08": return "backspace"
            elif ch == "\x03": return "escape"
            return ch
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _read_line_raw(prompt: str = "  > ") -> str:
    """Read a line of input in alt screen (can't use normal input())."""
    _write(SHOW_CURSOR)
    _write(prompt)
    buf = []
    while True:
        key = _read_key()
        if key == "enter":
            _write("\n")
            return "".join(buf).strip()
        elif key == "escape":
            _write("\n")
            return ""
        elif key == "backspace":
            if buf:
                buf.pop()
                _write("\b \b")
        elif key in ("up", "down", "special"):
            continue
        elif len(key) == 1 and (key.isprintable() or key in ("-", "_")):
            buf.append(key)
            _write(key)


PROVIDERS = [
    {
        "name": "anthropic",
        "display": "Anthropic (Claude)",
        "description": "Claude Opus, Sonnet, Haiku",
        "auth_methods": ["oauth", "api_key"],
        "env_var": "ANTHROPIC_API_KEY",
    },
    {
        "name": "openai",
        "display": "OpenAI",
        "description": "GPT-4o, o3",
        "auth_methods": ["api_key"],
        "env_var": "OPENAI_API_KEY",
    },
    {
        "name": "groq",
        "display": "Groq",
        "description": "Fast Llama, Mixtral inference",
        "auth_methods": ["api_key"],
        "env_var": "GROQ_API_KEY",
    },
    {
        "name": "openrouter",
        "display": "OpenRouter",
        "description": "Multi-provider gateway",
        "auth_methods": ["api_key"],
        "env_var": "OPENROUTER_API_KEY",
    },
    {
        "name": "deepseek",
        "display": "DeepSeek",
        "description": "DeepSeek V3, R1",
        "auth_methods": ["api_key"],
        "env_var": "DEEPSEEK_API_KEY",
    },
    {
        "name": "together",
        "display": "Together AI",
        "description": "Open source model hosting",
        "auth_methods": ["api_key"],
        "env_var": "TOGETHER_API_KEY",
    },
]


def _get_provider_status(provider: dict) -> tuple[str, str]:
    """Returns (status_icon, status_text) for a provider."""
    from .providers import get_api_key, get_active_oauth

    name = provider["name"]

    if name == "anthropic":
        oauth = get_active_oauth()
        if oauth:
            sub = oauth.get("subscriptionType", "")
            if sub:
                return f"{C_GREEN}✓{RESET}", f"{C_GREEN}Max subscription{RESET}"
            return f"{C_GREEN}✓{RESET}", f"{C_GREEN}OAuth connected{RESET}"
        key = get_api_key(name)
        if key:
            return f"{C_GREEN}✓{RESET}", f"{C_GREEN}API key set{RESET}"
        # Check env
        env_key = os.environ.get(provider["env_var"], "")
        if env_key:
            return f"{C_GREEN}✓{RESET}", f"{C_GREEN}API key (env){RESET}"
        return f"{C_DIM}✗{RESET}", f"{C_DIM}not connected{RESET}"
    else:
        key = get_api_key(name)
        if key:
            return f"{C_GREEN}✓{RESET}", f"{C_GREEN}API key set{RESET}"
        env_key = os.environ.get(provider.get("env_var", ""), "")
        if env_key:
            return f"{C_GREEN}✓{RESET}", f"{C_GREEN}API key (env){RESET}"
        return f"{C_DIM}✗{RESET}", f"{C_DIM}not connected{RESET}"


def login_screen() -> str | None:
    """Interactive login screen. Returns provider name that was logged in, or None."""

    selected = 0

    _write(ALT_SCREEN_ON)
    _write(HIDE_CURSOR)

    try:
        while True:
            _write(CLEAR_SCREEN)

            _write(f"\n  {C_BLUE}{BOLD}Login to a Provider{RESET}\n\n")

            for i, prov in enumerate(PROVIDERS):
                icon, status = _get_provider_status(prov)
                is_sel = i == selected

                if is_sel:
                    _write(f"  {C_BG_SELECT}{C_CYAN}❯{RESET} {C_BG_SELECT}{C_BOLD_WHITE}{prov['display']:25s}{RESET}")
                    _write(f" {C_BG_SELECT}{C_DIM}{prov['description']:30s}{RESET}")
                    _write(f" {C_BG_SELECT}{icon} {status}{C_BG_SELECT}{RESET}\n")
                else:
                    _write(f"    {C_WHITE}{prov['display']:25s}{RESET}")
                    _write(f" {C_DIM}{prov['description']:30s}{RESET}")
                    _write(f" {icon} {status}\n")

            _write(f"\n  {C_DIM}↑↓ navigate  {RESET}{C_CYAN}enter{RESET} {C_DIM}login  {RESET}{C_CYAN}esc{RESET} {C_DIM}back{RESET}")

            key = _read_key()

            if key == "up":
                selected = max(0, selected - 1)
            elif key == "down":
                selected = min(len(PROVIDERS) - 1, selected + 1)
            elif key == "enter":
                prov = PROVIDERS[selected]
                result = _handle_provider_login(prov)
                if result:
                    _write(ALT_SCREEN_OFF)
                    _write(SHOW_CURSOR)
                    return result
                # Login cancelled or failed — stay in the screen
                _write(HIDE_CURSOR)
                continue
            elif key in ("escape",):
                _write(ALT_SCREEN_OFF)
                _write(SHOW_CURSOR)
                return None

    except Exception:
        _write(ALT_SCREEN_OFF)
        _write(SHOW_CURSOR)
        return None
    finally:
        _write(ALT_SCREEN_OFF)
        _write(SHOW_CURSOR)


def _handle_provider_login(provider: dict) -> str | None:
    """Handle login for a specific provider. Returns provider name on success."""
    from .providers import save_api_key, get_api_key, get_active_oauth

    name = provider["name"]

    _write(CLEAR_SCREEN)
    _write(f"\n  {C_BLUE}{BOLD}Login: {provider['display']}{RESET}\n\n")

    if name == "anthropic":
        # Check existing OAuth
        oauth = get_active_oauth()
        if oauth:
            sub = oauth.get("subscriptionType", "unknown")
            _write(f"  {C_GREEN}Already connected: Claude {sub.title()} (OAuth){RESET}\n\n")
            _write(f"  {C_DIM}Press any key to go back...{RESET}")
            _read_key()
            return None

        _write(f"  {C_CYAN}Choose authentication method:{RESET}\n\n")
        _write(f"  {C_BOLD_WHITE}1.{RESET} {C_WHITE}Browser OAuth{RESET} {C_DIM}(Max/Pro subscription — opens browser){RESET}\n")
        _write(f"     {C_DIM}Login with your Anthropic account, no API key needed{RESET}\n\n")
        _write(f"  {C_BOLD_WHITE}2.{RESET} {C_WHITE}API Key{RESET} {C_DIM}(pay-per-use, separate billing){RESET}\n")
        _write(f"     {C_DIM}Get your key from console.anthropic.com{RESET}\n\n")

        _write(f"  {C_DIM}Press 1, 2, or esc to cancel:{RESET}\n")

        while True:
            key = _read_key()
            if key == "1":
                return _do_claude_oauth()
            elif key == "2":
                return _do_api_key_login(provider)
            elif key in ("escape",):
                return None
    else:
        return _do_api_key_login(provider)


def _do_claude_oauth() -> str | None:
    """Perform Vaal's own OAuth login — opens browser, local callback server."""
    from .providers import _save_vaal_oauth
    from .oauth import run_oauth_flow

    _write(CLEAR_SCREEN)
    _write(f"\n  {C_BLUE}{BOLD}Anthropic OAuth Login{RESET}\n\n")
    _write(f"  {C_WHITE}Launching browser for Anthropic login...{RESET}\n\n")

    spinner = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    frame = [0]

    def on_status(msg):
        s = spinner[frame[0] % len(spinner)]
        frame[0] += 1
        _write(f"\r  {C_CYAN}{s}{RESET} {C_DIM}{msg}{RESET}          ")

    oauth = run_oauth_flow(on_status=on_status)

    if oauth and oauth.get("accessToken"):
        _save_vaal_oauth(oauth)
        sub = oauth.get("subscriptionType", "Max")
        _write(f"\n\n  {C_GREEN}{BOLD}✓ Connected! Claude {sub.title()} subscription.{RESET}\n")
        time.sleep(2)
        return "anthropic"
    else:
        _write(f"\n\n  {C_YELLOW}Login failed or cancelled.{RESET}\n")
        time.sleep(2)
        return None


def _do_api_key_login(provider: dict) -> str | None:
    """Prompt for API key entry."""
    name = provider["name"]

    _write(CLEAR_SCREEN)
    _write(f"\n  {C_BLUE}{BOLD}API Key: {provider['display']}{RESET}\n\n")

    from .providers import get_api_key
    existing = get_api_key(name)
    if existing:
        masked = existing[:8] + "..." + existing[-4:] if len(existing) > 12 else "***"
        _write(f"  {C_DIM}Current key: {masked}{RESET}\n\n")

    _write(f"  {C_WHITE}Paste your API key:{RESET}\n")

    key_input = _read_line_raw(f"  {C_CYAN}>{RESET} ")

    if key_input:
        from .providers import save_api_key
        save_api_key(name, key_input)
        _write(f"\n  {C_GREEN}{BOLD}✓ API key saved for {provider['display']}{RESET}\n")
        time.sleep(1.5)
        return name
    else:
        _write(f"\n  {C_DIM}Cancelled.{RESET}\n")
        time.sleep(1)
        return None


def get_auth_type(provider_name: str) -> str:
    """Get the authentication type for display: 'max', 'pro', 'api', or 'none'."""
    from .providers import get_api_key, get_active_oauth

    if provider_name == "anthropic":
        oauth = get_active_oauth()
        if oauth:
            sub = oauth.get("subscriptionType", "").lower()
            if sub in ("max", "pro"):
                return sub
            return "oauth"
        key = get_api_key("anthropic")
        if key and key.startswith("sk-ant-oat"):
            return "max"  # OAuth token
        if key:
            return "api"
        return "none"
    else:
        key = get_api_key(provider_name)
        return "api" if key else "none"
