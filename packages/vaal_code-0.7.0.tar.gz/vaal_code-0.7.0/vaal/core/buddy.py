"""Vaal Orb — animated eye companion in the terminal."""

import json
import time
import threading
from pathlib import Path
from .config import VAAL_DIR

BUDDY_FILE = VAAL_DIR / "buddy.json"

# Vaal eye orb sprite — 5 lines tall
# {EYE} gets replaced with current animation state
SPRITE_TEMPLATE = [
    "  .---.",
    " /  _  \\",
    "(  ({EYE})  )",
    " \\ --- /",
    "  '---'",
]

# Animation states
EYES = {
    "normal":     "●",
    "blink":      "─",
    "look_left":  "●",   # eye line shifts left
    "look_right": "●",   # eye line shifts right
    "thinking":   "◉",
}

# Full line overrides for look states (line index 2)
EYE_LINES = {
    "normal":     "(  (●)  )",
    "blink":      "(  (─)  )",
    "look_left":  "( (● )  )",
    "look_right": "(  ( ●) )",
    "thinking":   "(  (◉)  )",
}


class VaalOrb:
    """Animated Vaal eye orb companion."""

    def __init__(self):
        self._state = "normal"
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None
        self._running = False
        self._on_change = None  # callback when state changes

    @property
    def state(self) -> str:
        with self._lock:
            return self._state

    @state.setter
    def state(self, value: str):
        with self._lock:
            if value in EYES and value != self._state:
                self._state = value
                if self._on_change:
                    try:
                        self._on_change()
                    except Exception:
                        pass

    def set_thinking(self, thinking: bool):
        """Set thinking state during LLM generation."""
        if thinking:
            self.state = "thinking"
        elif self._state == "thinking":
            self.state = "normal"

    def render(self) -> list[str]:
        """Render current sprite state as list of lines."""
        state = self.state
        lines = list(SPRITE_TEMPLATE)
        lines[2] = EYE_LINES.get(state, EYE_LINES["normal"])
        return lines

    def start_animation(self, on_change=None):
        """Start idle animation loop."""
        self._on_change = on_change
        self._running = True
        self._schedule_next()

    def stop_animation(self):
        """Stop idle animation."""
        self._running = False
        if self._timer:
            self._timer.cancel()
            self._timer = None

    def _schedule_next(self):
        """Schedule next animation event."""
        if not self._running:
            return
        import random
        delay = random.uniform(3.0, 5.0)
        self._timer = threading.Timer(delay, self._animate)
        self._timer.daemon = True
        self._timer.start()

    def _animate(self):
        """Perform one animation cycle."""
        if not self._running or self._state == "thinking":
            self._schedule_next()
            return

        import random
        action = random.choices(
            ["blink", "look_left", "look_right"],
            weights=[70, 15, 15],
            k=1,
        )[0]

        self.state = action

        if action == "blink":
            hold = 0.2
        else:
            hold = 1.0

        def _restore():
            if self._running and self._state != "thinking":
                self.state = "normal"
            self._schedule_next()

        t = threading.Timer(hold, _restore)
        t.daemon = True
        t.start()


# Singleton
_orb: VaalOrb | None = None


def get_orb() -> VaalOrb:
    """Get or create the singleton Vaal orb."""
    global _orb
    if _orb is None:
        _orb = VaalOrb()
    return _orb


def render_sprite(buddy: dict | None = None) -> list[str]:
    """Render current orb sprite. buddy param ignored, kept for compat."""
    return get_orb().render()


def get_buddy() -> dict:
    """Return a buddy-compatible dict. Always returns the Vaal orb."""
    return {"name": "Vaal", "species": "orb"}


def save_buddy(buddy: dict):
    """No-op — Vaal orb doesn't need persistence."""
    pass


def hatch_buddy(user_id: str = "anon", name: str = "", personality: str = "") -> dict:
    """Return the Vaal orb. No hatching needed."""
    return get_buddy()


def roll_buddy(user_id: str = "anon") -> dict:
    """Return the Vaal orb. No rolling needed."""
    return get_buddy()


def play_hatch_animation(buddy: dict):
    """No-op — the Vaal orb doesn't hatch."""
    pass


def format_buddy_card(buddy: dict) -> str:
    """Format Vaal orb as display card."""
    lines = ["  Vaal", "  Corruption Orb", ""]
    for sl in get_orb().render():
        lines.append(f"  {sl}")
    return "\n".join(lines)
