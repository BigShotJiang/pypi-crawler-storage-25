"""Task tracking -- like Claude Code's TodoWrite for managing work items."""

import uuid
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class TaskStatus(str, Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    BLOCKED = "blocked"


# Status display symbols
STATUS_ICONS = {
    TaskStatus.PENDING: "[ ]",
    TaskStatus.IN_PROGRESS: "[~]",
    TaskStatus.COMPLETED: "[x]",
    TaskStatus.BLOCKED: "[!]",
}

STATUS_STYLES = {
    TaskStatus.PENDING: "dim",
    TaskStatus.IN_PROGRESS: "bold yellow",
    TaskStatus.COMPLETED: "bold green",
    TaskStatus.BLOCKED: "bold red",
}


@dataclass
class Task:
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:6])
    title: str = ""
    status: TaskStatus = TaskStatus.PENDING
    description: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    agent_id: Optional[str] = None  # If assigned to a sub-agent

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "status": self.status.value,
            "description": self.description,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "agent_id": self.agent_id,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Task":
        return cls(
            id=data["id"],
            title=data["title"],
            status=TaskStatus(data["status"]),
            description=data.get("description", ""),
            created_at=data.get("created_at", time.time()),
            updated_at=data.get("updated_at", time.time()),
            agent_id=data.get("agent_id"),
        )


class TaskManager:
    """Manages a list of tasks within a session."""

    def __init__(self):
        self._tasks: dict[str, Task] = {}

    def create(self, title: str, description: str = "") -> Task:
        """Create a new task."""
        task = Task(title=title, description=description)
        self._tasks[task.id] = task
        return task

    def get(self, task_id: str) -> Optional[Task]:
        """Get a task by ID or prefix match."""
        if task_id in self._tasks:
            return self._tasks[task_id]
        # Prefix match
        for tid, task in self._tasks.items():
            if tid.startswith(task_id):
                return task
        return None

    def update(self, task_id: str, status: Optional[TaskStatus] = None,
               title: Optional[str] = None, description: Optional[str] = None) -> Optional[Task]:
        """Update a task's fields."""
        task = self.get(task_id)
        if not task:
            return None
        if status is not None:
            task.status = status
        if title is not None:
            task.title = title
        if description is not None:
            task.description = description
        task.updated_at = time.time()
        return task

    def complete(self, task_id: str) -> Optional[Task]:
        """Mark a task as completed."""
        return self.update(task_id, status=TaskStatus.COMPLETED)

    def list_all(self) -> list[Task]:
        """Return all tasks ordered by creation time."""
        return sorted(self._tasks.values(), key=lambda t: t.created_at)

    def list_by_status(self, status: TaskStatus) -> list[Task]:
        """Return tasks with a specific status."""
        return [t for t in self.list_all() if t.status == status]

    @property
    def summary(self) -> str:
        """One-line summary of task counts."""
        total = len(self._tasks)
        if total == 0:
            return "No tasks"
        done = sum(1 for t in self._tasks.values() if t.status == TaskStatus.COMPLETED)
        active = sum(1 for t in self._tasks.values() if t.status == TaskStatus.IN_PROGRESS)
        return f"{done}/{total} done, {active} active"

    def format_list(self) -> str:
        """Format all tasks for display (plain text)."""
        tasks = self.list_all()
        if not tasks:
            return "  No tasks."
        lines = []
        for t in tasks:
            icon = STATUS_ICONS[t.status]
            agent_tag = f" (agent:{t.agent_id})" if t.agent_id else ""
            lines.append(f"  {icon} {t.id} {t.title}{agent_tag}")
            if t.description:
                lines.append(f"       {t.description}")
        return "\n".join(lines)

    def to_list(self) -> list[dict]:
        """Serialize all tasks."""
        return [t.to_dict() for t in self.list_all()]

    def load_from(self, data: list[dict]):
        """Restore tasks from serialized data."""
        self._tasks.clear()
        for d in data:
            task = Task.from_dict(d)
            self._tasks[task.id] = task


# Module-level singleton -- shared across the session
_instance: Optional[TaskManager] = None


def get_task_manager() -> TaskManager:
    """Get or create the global TaskManager."""
    global _instance
    if _instance is None:
        _instance = TaskManager()
    return _instance


def reset_task_manager():
    """Reset the global instance (for /clear)."""
    global _instance
    _instance = TaskManager()
