"""Fixed bottom prompt layout — output scrolls above, prompt stays at bottom.

Layout (bottom of terminal):
  ──────────────────────────────────────    ( ·  · )
  > cursor here                             (      )
  ──────────────────────────────────────     `----´
  ? for shortcuts                            Blob
"""

import os
import sys
import threading


class FixedLayout:
    """Terminal layout with scrolling output and fixed bottom."""

    def __init__(self):
        self._lock = threading.Lock()
        self._term_h = 24
        self._term_w = 80
        self._active = False
        self._sprite = []
        self._buddy_name = ""
        self._status_left = ""
        self._status_right = ""

    def _size(self):
        try:
            s = os.get_terminal_size()
            self._term_w = s.columns
            self._term_h = s.lines
        except Exception:
            pass

    @property
    def _bottom_h(self) -> int:
        """Height of fixed bottom area."""
        # sprite height + 1 name + 1 status = sprite+2, minimum 4
        return max(len(self._sprite) + 2, 4)

    def activate(self):
        self._size()
        self._active = True
        self._set_scroll_region()
        self.redraw_bottom()

    def deactivate(self):
        if not self._active:
            return
        self._active = False
        sys.stdout.write("\033[r")  # Reset scroll region
        sys.stdout.write(f"\033[{self._term_h};1H\n")
        sys.stdout.flush()

    def set_buddy(self, sprite: list[str], name: str):
        self._sprite = sprite
        self._buddy_name = name
        if self._active:
            self._set_scroll_region()
            self.redraw_bottom()

    def set_status(self, left: str = "", right: str = ""):
        self._status_left = left
        self._status_right = right
        if self._active:
            self._draw_status_row()

    def _set_scroll_region(self):
        self._size()
        end = self._term_h - self._bottom_h
        if end < 1:
            end = 1
        sys.stdout.write(f"\033[1;{end}r")
        sys.stdout.flush()

    def redraw_bottom(self):
        """Redraw the entire fixed bottom area."""
        with self._lock:
            self._size()
            w = self._term_w
            bh = self._bottom_h
            top_row = self._term_h - bh + 1

            sprite = self._sprite
            name = self._buddy_name
            sprite_w = max((len(s) for s in sprite), default=0)
            rcol = w - sprite_w - 1 if sprite else w
            sep_w = (rcol - 2) if sprite else (w - 2)

            # Save cursor
            sys.stdout.write("\033[s")

            # We have these rows from top_row to self._term_h:
            # Row 0: ────────────────   sprite[0]
            # Row 1: > (prompt)         sprite[1]
            # ...                       sprite[N-1]
            # Row N: ────────────────    Name
            # Row N+1: status left       status right

            row = top_row

            # Top separator + sprite[0]
            sys.stdout.write(f"\033[{row};1H\033[2K\033[2m{'─' * sep_w}\033[0m")
            if sprite:
                sys.stdout.write(f"\033[{rcol}G\033[2m{sprite[0]}\033[0m")
            row += 1

            # Prompt row + sprite[1] (prompt rendered by raw_input, just place sprite)
            for i in range(1, len(sprite)):
                sys.stdout.write(f"\033[{row};1H\033[2K")
                sys.stdout.write(f"\033[{rcol}G\033[2m{sprite[i]}\033[0m")
                row += 1

            # If sprite was shorter than needed, fill empty rows
            while row < self._term_h - 1:
                sys.stdout.write(f"\033[{row};1H\033[2K")
                row += 1

            # Bottom separator + name
            sys.stdout.write(f"\033[{row};1H\033[2K\033[2m{'─' * sep_w}\033[0m")
            if name:
                pad = max(0, (sprite_w - len(name)) // 2)
                sys.stdout.write(f"\033[{rcol + pad}G\033[2;3m{name}\033[0m")
            row += 1

            # Status bar (last row)
            sys.stdout.write(f"\033[{row};1H\033[2K")
            if self._status_left:
                sys.stdout.write(f"\033[2m  {self._status_left}\033[0m")
            if self._status_right:
                rlen = len(self._status_right)
                sys.stdout.write(f"\033[{w - rlen - 1}G\033[2m{self._status_right}\033[0m")

            # Restore cursor
            sys.stdout.write("\033[u")
            sys.stdout.flush()

    def _draw_status_row(self):
        with self._lock:
            self._size()
            w = self._term_w
            row = self._term_h
            sys.stdout.write(f"\033[s\033[{row};1H\033[2K")
            if self._status_left:
                sys.stdout.write(f"\033[2m  {self._status_left}\033[0m")
            if self._status_right:
                rlen = len(self._status_right)
                sys.stdout.write(f"\033[{w - rlen - 1}G\033[2m{self._status_right}\033[0m")
            sys.stdout.write("\033[u")
            sys.stdout.flush()

    def move_to_prompt(self):
        """Move cursor to the > prompt row."""
        row = self._term_h - self._bottom_h + 2  # row after top separator
        sys.stdout.write(f"\033[{row};1H")
        sys.stdout.flush()

    @property
    def prompt_row(self) -> int:
        return self._term_h - self._bottom_h + 2

    @property
    def is_active(self) -> bool:
        return self._active


_layout: FixedLayout | None = None

def get_layout() -> FixedLayout:
    global _layout
    if _layout is None:
        _layout = FixedLayout()
    return _layout
