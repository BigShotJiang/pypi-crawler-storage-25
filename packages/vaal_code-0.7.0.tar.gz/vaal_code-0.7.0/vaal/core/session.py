"""Session management — conversation persistence and history."""

import json
import uuid
import time
from pathlib import Path
from dataclasses import dataclass, field

from .config import SESSIONS_DIR, HISTORY_FILE, ensure_dirs


@dataclass
class Session:
    session_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    messages: list[dict] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    model: str = ""
    cwd: str = ""
    total_tokens: int = 0
    tool_calls: int = 0

    def add_message(self, role: str, content: str):
        self.messages.append({
            "role": role,
            "content": content,
            "timestamp": time.time(),
        })

    def get_chat_messages(self) -> list[dict]:
        """Return messages in the format expected by the LLM API."""
        out = []
        for m in self.messages:
            msg = {"role": m["role"], "content": m["content"]}
            if "tool_use_id" in m:
                msg["tool_use_id"] = m["tool_use_id"]
            out.append(msg)
        return out

    def save(self):
        ensure_dirs()
        path = SESSIONS_DIR / f"{self.session_id}.json"
        data = {
            "session_id": self.session_id,
            "model": self.model,
            "cwd": self.cwd,
            "created_at": self.created_at,
            "total_tokens": self.total_tokens,
            "tool_calls": self.tool_calls,
            "messages": self.messages,
        }
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, session_id: str) -> "Session":
        path = SESSIONS_DIR / f"{session_id}.json"
        data = json.loads(path.read_text(encoding="utf-8"))
        session = cls(
            session_id=data["session_id"],
            messages=data["messages"],
            created_at=data["created_at"],
            model=data.get("model", ""),
            cwd=data.get("cwd", ""),
            total_tokens=data.get("total_tokens", 0),
            tool_calls=data.get("tool_calls", 0),
        )
        return session

    @staticmethod
    def list_sessions() -> list[dict]:
        ensure_dirs()
        sessions = []
        for f in sorted(SESSIONS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                sessions.append({
                    "id": data["session_id"],
                    "model": data.get("model", "?"),
                    "messages": len(data.get("messages", [])),
                    "created": data.get("created_at", 0),
                })
            except Exception:
                continue
        return sessions


def append_history(entry: dict):
    ensure_dirs()
    with open(HISTORY_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")
