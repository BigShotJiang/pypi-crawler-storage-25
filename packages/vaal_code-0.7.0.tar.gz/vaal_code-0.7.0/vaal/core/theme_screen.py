"""Interactive terminal theme picker with live preview."""

import sys

from .terminal_theme import (
    THEMES, apply_theme, reset_theme, save_preference, load_preference,
)

ESC = "\033"
HIDE_CURSOR = f"{ESC}[?25l"
SHOW_CURSOR = f"{ESC}[?25h"
CLEAR_SCREEN = f"{ESC}[2J{ESC}[H"
CLEAR_LINE = f"{ESC}[2K"
ALT_SCREEN_ON = f"{ESC}[?1049h"
ALT_SCREEN_OFF = f"{ESC}[?1049l"
RESET = f"{ESC}[0m"
BOLD = f"{ESC}[1m"


def _write(s):
    sys.stdout.write(s)
    sys.stdout.flush()


def _read_key():
    if sys.platform == "win32":
        import msvcrt
        key = msvcrt.getwch()
        if key in ("\x00", "\xe0"):
            key2 = msvcrt.getwch()
            if key2 == "H": return "up"
            elif key2 == "P": return "down"
            return "special"
        elif key == "\r": return "enter"
        elif key == "\x1b": return "escape"
        elif key == "\x03": return "escape"
        return key
    else:
        import tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "A": return "up"
                    elif ch3 == "B": return "down"
                return "escape"
            elif ch == "\r": return "enter"
            elif ch == "\x03": return "escape"
            return ch
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _color_block(hex_color: str) -> str:
    """Render a colored block using 24-bit ANSI color from a hex string."""
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    return f"{ESC}[48;2;{r};{g};{b}m  {RESET}"


def _fg_color(hex_color: str, text: str) -> str:
    """Render text in a 24-bit foreground color."""
    r = int(hex_color[1:3], 16)
    g = int(hex_color[3:5], 16)
    b = int(hex_color[5:7], 16)
    return f"{ESC}[38;2;{r};{g};{b}m{text}{RESET}"


def _render_theme_preview(name: str, theme: dict, selected: bool) -> list[str]:
    """Render a theme preview block. Returns list of lines."""
    lines = []
    sel_marker = f"{BOLD}>{RESET} " if selected else "  "
    highlight = BOLD if selected else ""

    # Name + description
    lines.append(f"  {sel_marker}{highlight}{name:8s}{RESET}  {theme['description']}")

    # Color swatch — 16 ANSI colors as blocks
    swatch = "      "
    for i, color in enumerate(theme["ansi"]):
        swatch += _color_block(color)
        if i == 7:
            swatch += " "  # gap between normal and bright
    lines.append(swatch)

    # FG/BG/Cursor preview
    fg = _fg_color(theme["foreground"], "foreground")
    cursor = _fg_color(theme["cursor"], "cursor")
    bg_hex = theme["background"]
    bg_r, bg_g, bg_b = int(bg_hex[1:3], 16), int(bg_hex[3:5], 16), int(bg_hex[5:7], 16)
    bg_block = f"{ESC}[48;2;{bg_r};{bg_g};{bg_b}m bg {RESET}"
    lines.append(f"      {fg}  {cursor}  {bg_block}")

    # Sample text using theme colors
    sample_parts = []
    if len(theme["ansi"]) >= 7:
        sample_parts.append(_fg_color(theme["ansi"][1], "error"))
        sample_parts.append(_fg_color(theme["ansi"][2], "success"))
        sample_parts.append(_fg_color(theme["ansi"][4], "info"))
        sample_parts.append(_fg_color(theme["ansi"][5], "highlight"))
        sample_parts.append(_fg_color(theme["ansi"][6], "accent"))
    lines.append(f"      {' '.join(sample_parts)}")

    return lines


def theme_screen() -> str | None:
    """
    Interactive theme picker. Applies themes live as you navigate.
    Returns the chosen theme name, or None if cancelled.
    """
    theme_names = list(THEMES.keys())
    previous_theme = load_preference()
    selected = 0

    # Start at current theme
    for i, name in enumerate(theme_names):
        if name == previous_theme:
            selected = i
            break

    _write(HIDE_CURSOR)
    # Do NOT use alt screen — we need colors to apply to the real terminal
    # Alt screen has its own color state that gets discarded on exit
    # Instead, save cursor position and clear screen area

    try:
        while True:
            _write(CLEAR_SCREEN)

            # Apply live preview
            current_name = theme_names[selected]
            apply_theme(current_name)

            # Title
            _write(f"\n  {BOLD}Terminal Theme{RESET}\n")
            _write(f"  Colors apply live as you navigate.\n\n")

            # Render all themes
            for i, name in enumerate(theme_names):
                theme = THEMES[name]
                is_selected = (i == selected)
                lines = _render_theme_preview(name, theme, is_selected)
                for line in lines:
                    _write(f"{line}\n")
                _write("\n")

            # Footer
            active_label = ""
            if theme_names[selected] == previous_theme:
                active_label = "  (current)"
            _write(f"  {BOLD}{theme_names[selected]}{RESET}{active_label}\n\n")
            _write(f"  up/down navigate  enter confirm  esc cancel\n")

            key = _read_key()

            if key == "up":
                selected = max(0, selected - 1)
            elif key == "down":
                selected = min(len(theme_names) - 1, selected + 1)
            elif key == "enter":
                chosen = theme_names[selected]
                save_preference(chosen)
                apply_theme(chosen)
                _write(SHOW_CURSOR)
                return chosen
            elif key in ("escape", "q"):
                # Revert to previous theme
                apply_theme(previous_theme)
                _write(SHOW_CURSOR)
                return None

    except Exception:
        # On error, restore previous
        apply_theme(previous_theme)
        _write(SHOW_CURSOR)
        return None
    finally:
        _write(SHOW_CURSOR)
