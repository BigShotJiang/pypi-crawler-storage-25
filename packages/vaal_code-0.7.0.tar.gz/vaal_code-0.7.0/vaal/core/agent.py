"""Agent system -- manages LLM conversation loops with tool use, including sub-agents."""

import uuid
import time
import threading
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, Callable

from .config import MAX_TURNS_PER_MESSAGE, DEFAULT_MODEL
from .task_manager import get_task_manager, TaskStatus


class AgentStatus(str, Enum):
    IDLE = "idle"
    THINKING = "thinking"
    RUNNING_TOOL = "running_tool"
    COMPLETE = "complete"
    ERROR = "error"


STATUS_LABELS = {
    AgentStatus.IDLE: "idle",
    AgentStatus.THINKING: "thinking...",
    AgentStatus.RUNNING_TOOL: "running tool...",
    AgentStatus.COMPLETE: "done",
    AgentStatus.ERROR: "error",
}


@dataclass
class AgentResult:
    """The final output of an agent run."""
    agent_id: str
    content: str = ""
    tool_calls_made: int = 0
    rounds: int = 0
    error: Optional[str] = None
    elapsed: float = 0.0


@dataclass
class Agent:
    """A single agentic loop that runs a conversation with tool calling."""

    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    model: str = DEFAULT_MODEL
    messages: list[dict] = field(default_factory=list)
    tools: list[dict] = field(default_factory=list)  # Ollama-format tool defs
    tool_defs: dict = field(default_factory=dict)     # Our ToolDef registry subset
    max_rounds: int = MAX_TURNS_PER_MESSAGE
    status: AgentStatus = AgentStatus.IDLE
    result: Optional[AgentResult] = None
    task_id: Optional[str] = None  # Linked task in TaskManager
    label: str = ""  # Human-readable description
    parent_id: Optional[str] = None

    # Internal
    _thread: Optional[threading.Thread] = field(default=None, repr=False)
    _on_complete: Optional[Callable] = field(default=None, repr=False)

    def run(
        self,
        permissions=None,
        ask_fn=None,
        on_status: Optional[Callable] = None,
    ) -> AgentResult:
        """Execute the agentic loop synchronously.

        Sends messages to the LLM, processes tool calls, feeds results back,
        and repeats until the LLM responds with no tool calls or max_rounds hit.

        Args:
            permissions: PermissionManager instance for tool approval.
            ask_fn: Callback for interactive tool approval (None for sub-agents = auto-approve safe).
            on_status: Optional callback(agent_id, status) for status updates.
        """
        from .llm import chat_with_tools_stream
        from .tool_executor import execute_tool, format_tool_result

        start = time.time()
        rounds = 0
        total_tool_calls = 0
        last_content = ""

        # Mark linked task as in progress
        if self.task_id:
            tm = get_task_manager()
            tm.update(self.task_id, status=TaskStatus.IN_PROGRESS)

        try:
            while rounds < self.max_rounds:
                rounds += 1
                self.status = AgentStatus.THINKING
                if on_status:
                    on_status(self.id, self.status)

                # Stream the response and collect it
                content_parts = []
                tool_calls = []

                try:
                    for chunk in chat_with_tools_stream(
                        self.messages, self.tools, model=self.model
                    ):
                        if chunk.get("content"):
                            content_parts.append(chunk["content"])
                        if chunk.get("tool_calls"):
                            tool_calls.extend(chunk["tool_calls"])
                except Exception as e:
                    self.status = AgentStatus.ERROR
                    self.result = AgentResult(
                        agent_id=self.id,
                        error=str(e),
                        rounds=rounds,
                        elapsed=time.time() - start,
                    )
                    if self.task_id:
                        tm = get_task_manager()
                        tm.update(self.task_id, status=TaskStatus.BLOCKED)
                    return self.result

                content = "".join(content_parts)
                if content:
                    last_content = content

                # Build assistant message — include tool_use content blocks for Anthropic compatibility
                if tool_calls:
                    assistant_content = []
                    if content:
                        assistant_content.append({"type": "text", "text": content})
                    for tc in tool_calls:
                        func = tc.get("function", {})
                        assistant_content.append({
                            "type": "tool_use",
                            "id": tc.get("id", f"tool_{func.get('name', 'unknown')}"),
                            "name": func.get("name", ""),
                            "input": func.get("arguments", {}),
                        })
                    self.messages.append({"role": "assistant", "content": assistant_content})
                else:
                    self.messages.append({"role": "assistant", "content": content or ""})

                if not tool_calls:
                    # Done -- no more tool calls
                    break

                # Execute tool calls
                self.status = AgentStatus.RUNNING_TOOL
                if on_status:
                    on_status(self.id, self.status)

                for tc in tool_calls:
                    func = tc.get("function", {})
                    tool_name = func.get("name", "")
                    tool_args = func.get("arguments", {})
                    tool_use_id = tc.get("id", f"tool_{tool_name}")

                    if permissions:
                        result_text, executed = execute_tool(
                            tool_name, tool_args, permissions, ask_fn
                        )
                    else:
                        # Sub-agent without permissions: execute directly
                        from ..tools.registry import get_tool
                        tool = get_tool(tool_name)
                        if tool:
                            try:
                                result_text = tool.handler(**tool_args)
                                executed = True
                            except Exception as e:
                                result_text = f"[tool error: {e}]"
                                executed = False
                        else:
                            result_text = f"[error: unknown tool '{tool_name}']"
                            executed = False

                    total_tool_calls += 1
                    formatted = format_tool_result(tool_name, result_text)
                    self.messages.append({"role": "tool", "tool_use_id": tool_use_id, "content": formatted})

        except Exception as e:
            self.status = AgentStatus.ERROR
            self.result = AgentResult(
                agent_id=self.id,
                error=str(e),
                rounds=rounds,
                tool_calls_made=total_tool_calls,
                elapsed=time.time() - start,
            )
            return self.result

        self.status = AgentStatus.COMPLETE
        if on_status:
            on_status(self.id, self.status)

        # Mark linked task as complete
        if self.task_id:
            tm = get_task_manager()
            tm.complete(self.task_id)

        self.result = AgentResult(
            agent_id=self.id,
            content=last_content,
            tool_calls_made=total_tool_calls,
            rounds=rounds,
            elapsed=time.time() - start,
        )
        return self.result

    def run_in_background(
        self,
        permissions=None,
        ask_fn=None,
        on_complete: Optional[Callable] = None,
        on_status: Optional[Callable] = None,
    ):
        """Start the agent loop in a background thread.

        Args:
            on_complete: Callback(AgentResult) when agent finishes.
            on_status: Callback(agent_id, status) for status updates.
        """
        self._on_complete = on_complete

        def _run():
            result = self.run(permissions=permissions, ask_fn=ask_fn, on_status=on_status)
            if self._on_complete:
                self._on_complete(result)

        self._thread = threading.Thread(target=_run, daemon=True, name=f"agent-{self.id}")
        self._thread.start()

    @property
    def is_running(self) -> bool:
        return self.status in (AgentStatus.THINKING, AgentStatus.RUNNING_TOOL)

    @property
    def is_done(self) -> bool:
        return self.status in (AgentStatus.COMPLETE, AgentStatus.ERROR)


class AgentPool:
    """Manages multiple concurrent agents (sub-agents)."""

    def __init__(self):
        self._agents: dict[str, Agent] = {}
        self._results: dict[str, AgentResult] = {}
        self._lock = threading.Lock()

    def spawn(
        self,
        label: str,
        system_prompt: str,
        user_prompt: str,
        model: str = DEFAULT_MODEL,
        tools: list[dict] = None,
        tool_defs: dict = None,
        max_rounds: int = 10,
        parent_id: str = None,
        permissions=None,
        task_id: str = None,
    ) -> Agent:
        """Create and start a background sub-agent.

        Args:
            label: Human-readable description of what this agent does.
            system_prompt: System message for the agent.
            user_prompt: The task/instruction for the agent.
            model: LLM model to use.
            tools: Ollama-format tool definitions.
            tool_defs: Tool registry definitions.
            max_rounds: Maximum tool-call rounds.
            parent_id: ID of the parent agent.
            permissions: PermissionManager for tool approval.
            task_id: TaskManager task ID to link.

        Returns:
            The spawned Agent (already running in background).
        """
        agent = Agent(
            model=model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            tools=tools or [],
            tool_defs=tool_defs or {},
            max_rounds=max_rounds,
            label=label,
            parent_id=parent_id,
            task_id=task_id,
        )

        # Link task to agent
        if task_id:
            tm = get_task_manager()
            task = tm.get(task_id)
            if task:
                task.agent_id = agent.id

        with self._lock:
            self._agents[agent.id] = agent

        def on_complete(result: AgentResult):
            with self._lock:
                self._results[agent.id] = result

        agent.run_in_background(
            permissions=permissions,
            on_complete=on_complete,
        )

        return agent

    def get(self, agent_id: str) -> Optional[Agent]:
        """Get an agent by ID or prefix."""
        with self._lock:
            if agent_id in self._agents:
                return self._agents[agent_id]
            for aid, agent in self._agents.items():
                if aid.startswith(agent_id):
                    return agent
        return None

    def get_result(self, agent_id: str) -> Optional[AgentResult]:
        """Get a completed agent's result."""
        with self._lock:
            return self._results.get(agent_id)

    def list_agents(self) -> list[dict]:
        """Return summary info for all agents."""
        with self._lock:
            out = []
            for aid, agent in self._agents.items():
                info = {
                    "id": aid,
                    "label": agent.label,
                    "status": agent.status.value,
                    "model": agent.model,
                    "task_id": agent.task_id,
                    "is_running": agent.is_running,
                }
                result = self._results.get(aid)
                if result:
                    info["rounds"] = result.rounds
                    info["tool_calls"] = result.tool_calls_made
                    info["elapsed"] = f"{result.elapsed:.1f}s"
                    if result.error:
                        info["error"] = result.error
                out.append(info)
            return out

    def collect_completed(self) -> list[AgentResult]:
        """Pop all completed results (for injection into parent conversation)."""
        completed = []
        with self._lock:
            done_ids = [aid for aid, agent in self._agents.items() if agent.is_done]
            for aid in done_ids:
                if aid in self._results:
                    completed.append(self._results.pop(aid))
        return completed

    @property
    def active_count(self) -> int:
        with self._lock:
            return sum(1 for a in self._agents.values() if a.is_running)

    @property
    def total_count(self) -> int:
        with self._lock:
            return len(self._agents)

    def status_summary(self) -> str:
        """One-line summary for the status bar."""
        active = self.active_count
        total = self.total_count
        if total == 0:
            return ""
        return f"{active}/{total} agents"


# Module-level singleton
_pool: Optional[AgentPool] = None


def get_agent_pool() -> AgentPool:
    """Get or create the global AgentPool."""
    global _pool
    if _pool is None:
        _pool = AgentPool()
    return _pool


def reset_agent_pool():
    """Reset the global pool (for /clear)."""
    global _pool
    _pool = AgentPool()
