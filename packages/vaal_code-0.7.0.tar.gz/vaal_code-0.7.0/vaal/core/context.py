"""Context management — token estimation and auto-compaction."""

from __future__ import annotations


def estimate_tokens(text) -> int:
    """Rough token estimate: words * 1.3. Handles str or list content blocks."""
    if not text:
        return 0
    if isinstance(text, list):
        # Anthropic content blocks — sum text from all blocks
        total = 0
        for block in text:
            if isinstance(block, dict):
                if block.get("type") == "text":
                    total += estimate_tokens(block.get("text", ""))
                elif block.get("type") == "tool_use":
                    total += estimate_tokens(str(block.get("input", {})))
                elif block.get("type") == "tool_result":
                    total += estimate_tokens(block.get("content", ""))
                else:
                    total += 10  # rough estimate for other block types
            elif isinstance(block, str):
                total += estimate_tokens(block)
        return total
    if not isinstance(text, str):
        return 10
    words = len(text.split())
    return max(1, int(words * 1.3))


def estimate_messages_tokens(messages: list[dict]) -> int:
    """Estimate total tokens across a list of messages."""
    total = 0
    for m in messages:
        content = m.get("content", "")
        total += estimate_tokens(content)
        # Small overhead per message for role/formatting
        total += 4
    return total


class ContextManager:
    """Tracks context window usage and auto-compacts when needed."""

    COMPACT_THRESHOLD = 0.80  # compact at 80% of max
    KEEP_RECENT = 20  # keep last N messages (plus system prompt)

    def __init__(self, max_tokens: int = 8192):
        self.max_tokens = max_tokens

    def usage(self, messages: list[dict]) -> tuple[int, int]:
        """Return (used_tokens, max_tokens)."""
        used = estimate_messages_tokens(messages)
        return used, self.max_tokens

    def usage_pct(self, messages: list[dict]) -> float:
        used, mx = self.usage(messages)
        return used / mx if mx > 0 else 0.0

    def should_compact(self, messages: list[dict]) -> bool:
        """True when context usage exceeds the compaction threshold."""
        return self.usage_pct(messages) >= self.COMPACT_THRESHOLD

    def compact_messages(self, messages: list[dict]) -> list[dict]:
        """Compact message list by summarizing old messages.

        Keeps:
        - The system prompt (first message if role == system)
        - A single summary message replacing everything in between
        - The last KEEP_RECENT messages
        """
        # Need at least system + keep_recent + some messages to compact
        min_to_compact = self.KEEP_RECENT + 3  # system + at least 2 old + recent
        if len(messages) < min_to_compact:
            return messages

        # Split out system prompt
        has_system = messages[0]["role"] == "system" if messages else False
        system_msgs = messages[:1] if has_system else []
        rest = messages[1:] if has_system else messages

        if len(rest) <= self.KEEP_RECENT:
            return messages

        old_messages = rest[:-self.KEEP_RECENT]
        recent_messages = rest[-self.KEEP_RECENT:]

        # Build a summary of the old conversation
        summary_parts = []
        for m in old_messages:
            role = m.get("role", "unknown")
            content = m.get("content", "")

            # Handle structured content blocks (Anthropic tool_use format)
            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            text_parts.append(block.get("text", "")[:100])
                        elif block.get("type") == "tool_use":
                            text_parts.append(f"[tool_use: {block.get('name', '?')}]")
                        elif block.get("type") == "tool_result":
                            text_parts.append(f"[tool_result]")
                content = " ".join(text_parts) if text_parts else "(structured content)"

            if not isinstance(content, str):
                content = str(content)[:200]

            if role == "user":
                # Extract the actual user text (strip CWD prefix)
                lines = content.split("\n", 1)
                text = lines[1] if len(lines) > 1 and lines[0].startswith("[CWD:") else content
                summary_parts.append(f"- User: {text[:200]}")
            elif role == "assistant" and content and content != "(tool calls)":
                summary_parts.append(f"- Assistant: {content[:200]}")
            elif role == "tool":
                summary_parts.append(f"- Tool: {content[:100]}")

        summary_text = "[Earlier conversation compacted]\n" + "\n".join(summary_parts)

        import time
        summary_msg = {
            "role": "user",
            "content": summary_text,
            "timestamp": time.time(),
        }

        # Ensure the recent messages start with proper role alternation
        # (can't start with 'tool' or have consecutive same-role messages for Anthropic)
        cleaned_recent = []
        for msg in recent_messages:
            if msg["role"] == "tool" and not cleaned_recent:
                continue  # Skip orphaned tool results at the start
            # Convert any structured assistant content to string for compacted context
            if msg["role"] == "assistant" and isinstance(msg.get("content"), list):
                text_parts = []
                for block in msg["content"]:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif isinstance(block, dict) and block.get("type") == "tool_use":
                        text_parts.append(f"(called {block.get('name', '?')})")
                msg = {**msg, "content": " ".join(text_parts) or "(tool calls)"}
            cleaned_recent.append(msg)

        return system_msgs + [summary_msg] + cleaned_recent
