"""Plugin system — load Python plugins that register custom tools."""

import importlib.util
import logging
import sys
from pathlib import Path

from .config import VAAL_DIR

logger = logging.getLogger(__name__)

PLUGINS_DIR = VAAL_DIR / "plugins"


class PluginRegistry:
    """Registry interface passed to plugin register() functions.

    Provides a clean API for plugins to register tools without needing
    to import vaal internals directly.
    """

    def __init__(self):
        self._registered: list[str] = []

    def register_tool(
        self,
        name: str,
        description: str,
        parameters: dict,
        handler,
        dangerous: bool = False,
    ):
        """Register a new tool from a plugin.

        Args:
            name: Unique tool name.
            description: What the tool does.
            parameters: Dict of param_name -> {"description": ..., "required": bool}.
            handler: Callable(**params) -> str.
            dangerous: Whether this tool requires user confirmation.
        """
        from ..tools.registry import ToolDef, _tools

        if name in _tools:
            logger.warning("Plugin tried to register tool '%s' but it already exists; skipping", name)
            return

        _tools[name] = ToolDef(
            name=name,
            description=description,
            parameters=parameters,
            handler=handler,
            dangerous=dangerous,
        )
        self._registered.append(name)
        logger.info("Plugin registered tool: %s", name)

    @property
    def tools_registered(self) -> list[str]:
        return list(self._registered)


def load_plugins() -> list[str]:
    """Scan ~/.vaal/plugins/ and import all .py files.

    Each plugin must export a `register(registry)` function.
    Returns list of successfully loaded plugin names.
    """
    if not PLUGINS_DIR.exists():
        return []

    registry = PluginRegistry()
    loaded: list[str] = []

    for plugin_path in sorted(PLUGINS_DIR.glob("*.py")):
        if plugin_path.name.startswith("_"):
            continue

        module_name = f"vaal_plugin_{plugin_path.stem}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, plugin_path)
            if spec is None or spec.loader is None:
                logger.warning("Cannot load plugin '%s': invalid module spec", plugin_path.name)
                continue

            module = importlib.util.module_from_spec(spec)
            # Put in sys.modules so the plugin can do relative imports if needed
            sys.modules[module_name] = module
            spec.loader.exec_module(module)

            register_fn = getattr(module, "register", None)
            if register_fn is None:
                logger.warning("Plugin '%s' has no register() function; skipping", plugin_path.name)
                # Clean up
                sys.modules.pop(module_name, None)
                continue

            register_fn(registry)
            loaded.append(plugin_path.stem)
            logger.info("Loaded plugin: %s", plugin_path.stem)

        except Exception as e:
            logger.warning("Failed to load plugin '%s': %s", plugin_path.name, e)
            # Clean up on failure
            sys.modules.pop(module_name, None)

    if loaded:
        logger.info(
            "Plugins loaded: %d (%s), tools registered: %s",
            len(loaded), ", ".join(loaded), ", ".join(registry.tools_registered) or "none",
        )

    return loaded
