"""Collaborative mode -- multi-instance context sharing via shared session files."""

import json
import os
import time
import uuid
import threading
import random
from pathlib import Path
from dataclasses import dataclass, field

from .config import VAAL_DIR

COLLAB_DIR = VAAL_DIR / "collab"

# Instance colors for distinguishing participants
INSTANCE_COLORS = [
    "#5f87ff",  # blue
    "#87d75f",  # green
    "#d7875f",  # orange
    "#af5fff",  # purple
    "#5fd7d7",  # cyan
    "#d75f87",  # pink
    "#d7d75f",  # yellow
    "#5fd787",  # mint
]

INSTANCE_NAMES = [
    "alpha", "bravo", "charlie", "delta",
    "echo", "foxtrot", "golf", "hotel",
]


def _generate_room_code() -> str:
    """Generate a 6-character alphanumeric room code."""
    chars = "abcdefghjkmnpqrstuvwxyz23456789"
    return "".join(random.choice(chars) for _ in range(6))


@dataclass
class CollabMessage:
    instance_id: str
    instance_name: str
    instance_color: str
    content: str
    timestamp: float = field(default_factory=time.time)
    msg_type: str = "chat"  # chat, join, leave, system

    def to_dict(self) -> dict:
        return {
            "instance_id": self.instance_id,
            "instance_name": self.instance_name,
            "instance_color": self.instance_color,
            "content": self.content,
            "timestamp": self.timestamp,
            "msg_type": self.msg_type,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "CollabMessage":
        return cls(
            instance_id=data["instance_id"],
            instance_name=data["instance_name"],
            instance_color=data.get("instance_color", "#5f87ff"),
            content=data["content"],
            timestamp=data.get("timestamp", 0.0),
            msg_type=data.get("msg_type", "chat"),
        )


class FileLock:
    """Simple file-based lock using a .lock file."""

    def __init__(self, path: Path):
        self.lock_path = path.with_suffix(path.suffix + ".lock")

    def acquire(self, timeout: float = 5.0) -> bool:
        deadline = time.time() + timeout
        while time.time() < deadline:
            try:
                fd = os.open(str(self.lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
                os.write(fd, str(os.getpid()).encode())
                os.close(fd)
                return True
            except FileExistsError:
                # Check if lock is stale (older than 30 seconds)
                try:
                    age = time.time() - self.lock_path.stat().st_mtime
                    if age > 30:
                        self.release()
                        continue
                except FileNotFoundError:
                    continue
                time.sleep(0.05)
        return False

    def release(self):
        try:
            self.lock_path.unlink()
        except FileNotFoundError:
            pass

    def __enter__(self):
        if not self.acquire():
            raise TimeoutError("Could not acquire file lock")
        return self

    def __exit__(self, *args):
        self.release()


class CollabSession:
    """A collaborative session backed by a shared JSON file."""

    def __init__(self, room_code: str):
        self.room_code = room_code
        COLLAB_DIR.mkdir(parents=True, exist_ok=True)
        self.file_path = COLLAB_DIR / f"{room_code}.json"
        self.lock = FileLock(self.file_path)
        self.instance_id = str(uuid.uuid4())[:8]
        self._last_read_index = 0
        self._poll_thread: threading.Thread | None = None
        self._stop_event = threading.Event()
        self._message_callback = None

        # Pick a unique name/color
        idx = hash(self.instance_id) % len(INSTANCE_NAMES)
        self.instance_name = INSTANCE_NAMES[idx]
        self.instance_color = INSTANCE_COLORS[idx]

    def create(self) -> str:
        """Create a new collab session. Returns room code."""
        data = {
            "room_code": self.room_code,
            "created_at": time.time(),
            "participants": [],
            "messages": [],
        }
        with self.lock:
            self.file_path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        return self.room_code

    def exists(self) -> bool:
        return self.file_path.exists()

    def _read_data(self) -> dict:
        try:
            return json.loads(self.file_path.read_text(encoding="utf-8"))
        except (FileNotFoundError, json.JSONDecodeError):
            return {"room_code": self.room_code, "participants": [], "messages": []}

    def _write_data(self, data: dict):
        self.file_path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def join(self) -> bool:
        """Join the collab session. Returns True if successful."""
        if not self.exists():
            return False
        with self.lock:
            data = self._read_data()
            participant = {
                "instance_id": self.instance_id,
                "instance_name": self.instance_name,
                "instance_color": self.instance_color,
                "joined_at": time.time(),
            }
            data["participants"].append(participant)
            # Post a join message
            join_msg = CollabMessage(
                instance_id=self.instance_id,
                instance_name=self.instance_name,
                instance_color=self.instance_color,
                content=f"{self.instance_name} joined the session",
                msg_type="join",
            )
            data["messages"].append(join_msg.to_dict())
            self._write_data(data)
            self._last_read_index = len(data["messages"])
        return True

    def leave(self):
        """Leave the collab session."""
        self._stop_event.set()
        if self._poll_thread and self._poll_thread.is_alive():
            self._poll_thread.join(timeout=3)

        if not self.exists():
            return
        with self.lock:
            data = self._read_data()
            data["participants"] = [
                p for p in data["participants"]
                if p["instance_id"] != self.instance_id
            ]
            leave_msg = CollabMessage(
                instance_id=self.instance_id,
                instance_name=self.instance_name,
                instance_color=self.instance_color,
                content=f"{self.instance_name} left the session",
                msg_type="leave",
            )
            data["messages"].append(leave_msg.to_dict())
            self._write_data(data)

    def send_message(self, content: str, msg_type: str = "chat"):
        """Send a message to the collab session."""
        if not self.exists():
            return
        msg = CollabMessage(
            instance_id=self.instance_id,
            instance_name=self.instance_name,
            instance_color=self.instance_color,
            content=content,
            msg_type=msg_type,
        )
        with self.lock:
            data = self._read_data()
            data["messages"].append(msg.to_dict())
            self._write_data(data)

    def get_new_messages(self) -> list[CollabMessage]:
        """Get messages posted since last read, excluding own messages."""
        if not self.exists():
            return []
        with self.lock:
            data = self._read_data()
        all_msgs = data.get("messages", [])
        new_msgs = []
        for raw in all_msgs[self._last_read_index:]:
            msg = CollabMessage.from_dict(raw)
            if msg.instance_id != self.instance_id:
                new_msgs.append(msg)
        self._last_read_index = len(all_msgs)
        return new_msgs

    def get_participants(self) -> list[dict]:
        """Get current participants."""
        if not self.exists():
            return []
        with self.lock:
            data = self._read_data()
        return data.get("participants", [])

    def start_polling(self, callback):
        """Start background thread that polls for new messages every 2 seconds."""
        self._message_callback = callback
        self._stop_event.clear()
        self._poll_thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._poll_thread.start()

    def _poll_loop(self):
        while not self._stop_event.is_set():
            try:
                new_msgs = self.get_new_messages()
                if new_msgs and self._message_callback:
                    for msg in new_msgs:
                        self._message_callback(msg)
            except Exception:
                pass  # Silently ignore poll errors
            self._stop_event.wait(2.0)


# Module-level active session
_active_collab: CollabSession | None = None


def get_active_collab() -> CollabSession | None:
    return _active_collab


def collab_start(on_message=None) -> tuple[bool, str]:
    """Start a new collab session. Returns (success, room_code_or_error)."""
    global _active_collab
    if _active_collab:
        return False, f"Already in a collab session: {_active_collab.room_code}"

    code = _generate_room_code()
    session = CollabSession(code)
    session.create()
    if not session.join():
        return False, "Failed to join newly created session"

    if on_message:
        session.start_polling(on_message)

    _active_collab = session
    return True, code


def collab_join(code: str, on_message=None) -> tuple[bool, str]:
    """Join an existing collab session. Returns (success, message)."""
    global _active_collab
    if _active_collab:
        return False, f"Already in a collab session: {_active_collab.room_code}"

    session = CollabSession(code.strip().lower())
    if not session.exists():
        return False, f"No collab session found with code: {code}"

    if not session.join():
        return False, "Failed to join session"

    if on_message:
        session.start_polling(on_message)

    _active_collab = session
    return True, f"Joined session {code} as {session.instance_name}"


def collab_leave() -> tuple[bool, str]:
    """Leave the current collab session. Returns (success, message)."""
    global _active_collab
    if not _active_collab:
        return False, "Not in a collab session"

    code = _active_collab.room_code
    _active_collab.leave()
    _active_collab = None
    return True, f"Left session {code}"


def collab_send(content: str) -> tuple[bool, str]:
    """Send a message to the current collab session."""
    if not _active_collab:
        return False, "Not in a collab session"
    _active_collab.send_message(content)
    return True, "Message sent"


def collab_info() -> dict | None:
    """Get info about the current collab session."""
    if not _active_collab:
        return None
    return {
        "room_code": _active_collab.room_code,
        "instance_id": _active_collab.instance_id,
        "instance_name": _active_collab.instance_name,
        "instance_color": _active_collab.instance_color,
        "participants": _active_collab.get_participants(),
    }
