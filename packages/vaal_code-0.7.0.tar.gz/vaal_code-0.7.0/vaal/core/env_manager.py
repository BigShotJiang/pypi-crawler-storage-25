"""Environment variable management."""

import os
import re
from pathlib import Path


class EnvManager:
    """Manages environment variables for the session.

    Supports:
    - Listing relevant env vars
    - Setting session-scoped vars
    - Loading .env files
    - Diffing .env vs .env.example
    """

    # Common env var patterns that are "relevant" to a project
    RELEVANT_PREFIXES = (
        "DATABASE", "DB_", "REDIS", "MONGO",
        "API_", "SECRET", "KEY", "TOKEN",
        "AWS_", "AZURE_", "GCP_", "GOOGLE_",
        "NODE_ENV", "FLASK_", "DJANGO_",
        "PORT", "HOST", "URL", "ENDPOINT",
        "SMTP_", "MAIL_", "EMAIL_",
        "LOG_", "DEBUG",
        "APP_", "VAAL_",
        "OPENAI", "ANTHROPIC", "OLLAMA",
        "GITHUB_", "CI", "CD",
    )

    # Env var names that should never be displayed in full
    SENSITIVE_PATTERNS = re.compile(
        r"(SECRET|PASSWORD|PASS|KEY|TOKEN|CREDENTIAL|AUTH|PRIVATE)",
        re.IGNORECASE,
    )

    def __init__(self, cwd: str | None = None):
        self.cwd = cwd or os.getcwd()
        self._session_vars: dict[str, str] = {}

    # ── Public API ────────────────────────────────────────────────────

    def list_env(self) -> str:
        """List environment variables relevant to the project."""
        lines = []

        # 1. Session-set vars
        if self._session_vars:
            lines.append("Session variables:")
            for key, val in sorted(self._session_vars.items()):
                lines.append(f"  {key}={self._mask_value(key, val)}")
            lines.append("")

        # 2. Loaded .env files
        env_files = self._find_env_files()
        if env_files:
            lines.append("Detected .env files:")
            for f in env_files:
                rel = os.path.relpath(f, self.cwd)
                lines.append(f"  {rel}")
            lines.append("")

        # 3. Relevant env vars from os.environ
        relevant = {}
        for key, val in os.environ.items():
            if any(key.upper().startswith(p) for p in self.RELEVANT_PREFIXES):
                relevant[key] = val

        if relevant:
            lines.append("Relevant environment variables:")
            for key in sorted(relevant.keys()):
                lines.append(f"  {key}={self._mask_value(key, relevant[key])}")
        else:
            lines.append("No known project-relevant environment variables detected.")

        return "\n".join(lines)

    def set_var(self, key: str, value: str) -> str:
        """Set an environment variable for the session."""
        key = key.strip()
        value = value.strip()
        if not key:
            return "Usage: /env set KEY=VALUE"

        os.environ[key] = value
        self._session_vars[key] = value
        masked = self._mask_value(key, value)
        return f"Set {key}={masked} (session-scoped)"

    def load_env_file(self, path: str = "") -> str:
        """Load variables from a .env file into the environment."""
        if not path:
            # Auto-detect
            candidates = [".env", ".env.local"]
            found = None
            for c in candidates:
                full = os.path.join(self.cwd, c)
                if os.path.isfile(full):
                    found = full
                    break
            if not found:
                return "No .env file found. Usage: /env load <path>"
            path = found
        else:
            if not os.path.isabs(path):
                path = os.path.join(self.cwd, path)

        if not os.path.isfile(path):
            return f"File not found: {path}"

        loaded = 0
        skipped = 0
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    # Skip comments and empty lines
                    if not line or line.startswith("#"):
                        continue
                    # Parse KEY=VALUE (with optional quotes)
                    match = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)=(.*)$', line)
                    if match:
                        key = match.group(1)
                        val = match.group(2).strip()
                        # Remove surrounding quotes
                        if (val.startswith('"') and val.endswith('"')) or \
                           (val.startswith("'") and val.endswith("'")):
                            val = val[1:-1]
                        # Strip inline comments (only for unquoted values)
                        if "#" in val and not (match.group(2).strip().startswith('"') or match.group(2).strip().startswith("'")):
                            val = val.split("#")[0].strip()
                        os.environ[key] = val
                        self._session_vars[key] = val
                        loaded += 1
                    else:
                        skipped += 1
        except Exception as e:
            return f"Error reading {path}: {e}"

        rel = os.path.relpath(path, self.cwd)
        result = f"Loaded {loaded} variable{'s' if loaded != 1 else ''} from {rel}"
        if skipped:
            result += f" ({skipped} line{'s' if skipped != 1 else ''} skipped)"
        return result

    def diff_env(self) -> str:
        """Compare .env with .env.example to find missing/extra variables."""
        env_file = os.path.join(self.cwd, ".env")
        example_file = None

        # Find the example file
        for name in (".env.example", ".env.sample", ".env.template"):
            candidate = os.path.join(self.cwd, name)
            if os.path.isfile(candidate):
                example_file = candidate
                break

        if not example_file:
            return "No .env.example/.env.sample/.env.template found in project root."

        if not os.path.isfile(env_file):
            return f".env file not found. {os.path.basename(example_file)} exists but .env is missing."

        env_vars = self._parse_env_file(env_file)
        example_vars = self._parse_env_file(example_file)

        env_keys = set(env_vars.keys())
        example_keys = set(example_vars.keys())

        missing = example_keys - env_keys
        extra = env_keys - example_keys
        common = env_keys & example_keys

        # Check for empty values where example has a placeholder
        empty_vals = []
        for key in common:
            if not env_vars[key] and example_vars[key]:
                empty_vals.append(key)

        lines = [f"Comparing .env vs {os.path.basename(example_file)}:"]
        lines.append("")

        if missing:
            lines.append(f"Missing in .env ({len(missing)}):")
            for key in sorted(missing):
                hint = f"  (example: {example_vars[key][:40]})" if example_vars[key] else ""
                lines.append(f"  - {key}{hint}")
            lines.append("")

        if extra:
            lines.append(f"Extra in .env (not in example) ({len(extra)}):")
            for key in sorted(extra):
                lines.append(f"  + {key}")
            lines.append("")

        if empty_vals:
            lines.append(f"Empty in .env but has value in example ({len(empty_vals)}):")
            for key in sorted(empty_vals):
                lines.append(f"  ! {key}")
            lines.append("")

        if not missing and not extra and not empty_vals:
            lines.append("All variables match. No differences found.")

        return "\n".join(lines)

    def handle_command(self, arg: str) -> str:
        """Handle /env slash command.

        /env              - list relevant env vars
        /env set KEY=VALUE - set for session
        /env load [file]  - load .env file
        /env diff         - compare .env vs .env.example
        """
        arg = arg.strip()

        if not arg:
            return self.list_env()

        parts = arg.split(maxsplit=1)
        sub = parts[0].lower()
        sub_arg = parts[1] if len(parts) > 1 else ""

        if sub == "set":
            if "=" in sub_arg:
                key, val = sub_arg.split("=", 1)
                return self.set_var(key, val)
            return "Usage: /env set KEY=VALUE"

        elif sub == "load":
            return self.load_env_file(sub_arg)

        elif sub == "diff":
            return self.diff_env()

        else:
            # Maybe they typed /env KEY=VALUE
            if "=" in arg:
                key, val = arg.split("=", 1)
                return self.set_var(key, val)
            return (
                "Usage:\n"
                "  /env              - list relevant env vars\n"
                "  /env set KEY=VAL  - set for session\n"
                "  /env load [file]  - load .env file\n"
                "  /env diff         - compare .env vs .env.example"
            )

    # ── Internal ──────────────────────────────────────────────────────

    def _mask_value(self, key: str, value: str) -> str:
        """Mask sensitive values for display."""
        if self.SENSITIVE_PATTERNS.search(key):
            if len(value) <= 4:
                return "****"
            return value[:2] + "*" * (len(value) - 4) + value[-2:]
        return value

    def _find_env_files(self) -> list[str]:
        """Find .env* files in the project root."""
        files = []
        for name in sorted(os.listdir(self.cwd)):
            if name.startswith(".env") and os.path.isfile(os.path.join(self.cwd, name)):
                files.append(os.path.join(self.cwd, name))
        return files

    @staticmethod
    def _parse_env_file(path: str) -> dict[str, str]:
        """Parse a .env file into key-value pairs."""
        result = {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    match = re.match(r'^([A-Za-z_][A-Za-z0-9_]*)=(.*)$', line)
                    if match:
                        key = match.group(1)
                        val = match.group(2).strip()
                        if (val.startswith('"') and val.endswith('"')) or \
                           (val.startswith("'") and val.endswith("'")):
                            val = val[1:-1]
                        result[key] = val
        except Exception:
            pass
        return result
