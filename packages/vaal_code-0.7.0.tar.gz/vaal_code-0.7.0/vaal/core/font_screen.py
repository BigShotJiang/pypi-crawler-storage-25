"""Interactive font picker for terminal customization."""

import sys

ESC = "\033"
HIDE_CURSOR = f"{ESC}[?25l"
SHOW_CURSOR = f"{ESC}[?25h"
CLEAR_SCREEN = f"{ESC}[2J{ESC}[H"
CLEAR_LINE = f"{ESC}[2K"
RESET = f"{ESC}[0m"
BOLD = f"{ESC}[1m"
DIM = f"{ESC}[2m"

FONTS = [
    ("Cascadia Code", "Microsoft, ligatures, Windows Terminal default"),
    ("JetBrains Mono", "JetBrains, ligatures, very popular for coding"),
    ("Fira Code", "Mozilla, ligatures, open source"),
    ("Consolas", "Microsoft, Windows built-in classic"),
    ("Courier New", "Universal monospace, every system has it"),
    ("Source Code Pro", "Adobe, clean and readable"),
    ("Hack", "Open source, optimized for source code"),
    ("Iosevka", "Narrow, customizable, many variants"),
    ("MonoLisa", "Premium, designed for long coding sessions"),
    ("Victor Mono", "Cursive italics, ligatures, open source"),
    ("Berkeley Mono", "Premium, clean geometric design"),
    ("Comic Mono", "Comic Sans Mono — unironically readable"),
]


def _write(s):
    sys.stdout.write(s)
    sys.stdout.flush()


def _read_key():
    if sys.platform == "win32":
        import msvcrt
        key = msvcrt.getwch()
        if key in ("\x00", "\xe0"):
            key2 = msvcrt.getwch()
            if key2 == "H": return "up"
            elif key2 == "P": return "down"
            return "special"
        elif key == "\r": return "enter"
        elif key == "\x1b": return "escape"
        elif key == "\x03": return "escape"
        return key
    else:
        import tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "A": return "up"
                    elif ch3 == "B": return "down"
                return "escape"
            elif ch == "\r": return "enter"
            elif ch == "\x03": return "escape"
            return ch
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _try_set_font(font_name: str) -> bool:
    """
    Attempt to set terminal font via OSC 50.
    This works in xterm, mintty, and some other terminals.
    Windows Terminal does NOT support OSC 50 — font must be set in settings.json.
    Returns True if sequence was sent (not necessarily if it worked).
    """
    try:
        sys.stdout.write(f"\033]50;{font_name}\007")
        sys.stdout.flush()
        return True
    except Exception:
        return False


def font_screen() -> str | None:
    """
    Interactive font picker.
    Returns the chosen font name, or None if cancelled.
    """
    selected = 0
    font_applied = False

    _write(HIDE_CURSOR)

    try:
        while True:
            _write(CLEAR_SCREEN)

            _write(f"\n  {BOLD}Terminal Font{RESET}\n\n")

            # Warning about terminal support
            _write(f"  {DIM}Font changes via escape sequences have limited support.{RESET}\n")
            _write(f"  {DIM}Windows Terminal: set font in Settings > Profile > Appearance.{RESET}\n\n")

            for i, (name, desc) in enumerate(FONTS):
                if i == selected:
                    _write(f"  {BOLD}> {name:22s}{RESET}  {desc}\n")
                else:
                    _write(f"    {DIM}{name:22s}{RESET}  {DIM}{desc}{RESET}\n")

            _write(f"\n  {BOLD}Preview text:{RESET}\n")
            _write(f"  The quick brown fox jumps over the lazy dog.\n")
            _write(f"  0123456789 {{}}[]() <> !=== => -> :: ||\n")
            _write(f"  fi fl ft ff ffi ffl  <!-- -->  ++ --\n")

            _write(f"\n  up/down navigate  enter select  esc cancel\n")

            if font_applied:
                _write(f"\n  {BOLD}Font change sent.{RESET} If nothing changed, your terminal\n")
                _write(f"  may not support OSC 50. See instructions below.\n")

            key = _read_key()

            if key == "up":
                selected = max(0, selected - 1)
            elif key == "down":
                selected = min(len(FONTS) - 1, selected + 1)
            elif key == "enter":
                font_name = FONTS[selected][0]
                _try_set_font(font_name)
                font_applied = True

                # Show instructions for manual setup
                _write(CLEAR_SCREEN)
                _write(f"\n  {BOLD}Font: {font_name}{RESET}\n\n")
                _write(f"  OSC 50 escape sent. If your terminal supports it, the\n")
                _write(f"  font should have changed.\n\n")
                _write(f"  {BOLD}For Windows Terminal:{RESET}\n")
                _write(f"  1. Open Settings (Ctrl+,)\n")
                _write(f"  2. Select your profile\n")
                _write(f"  3. Appearance > Font face > \"{font_name}\"\n\n")
                _write(f"  {BOLD}For settings.json:{RESET}\n")
                _write(f'  "profiles": {{ "defaults": {{ "font": {{ "face": "{font_name}" }} }} }}\n\n')
                _write(f"  {DIM}Press any key to return...{RESET}\n")

                _write(SHOW_CURSOR)
                _read_key()
                return font_name

            elif key in ("escape", "q"):
                _write(SHOW_CURSOR)
                return None

    except Exception:
        _write(SHOW_CURSOR)
        return None
    finally:
        _write(SHOW_CURSOR)
