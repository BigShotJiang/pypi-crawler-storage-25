"""Voice input — speech recognition for hands-free prompting."""

import sys
import threading
import time


class VoiceInput:
    """Voice input using the SpeechRecognition library.

    Supports Google Speech Recognition (free, no API key) and
    OpenAI Whisper (local, if installed).
    """

    def __init__(self):
        self._available = False
        self._sr = None
        self._recognizer = None
        self._microphone = None
        self._active = False
        self._engine = "google"  # "google" or "whisper"

        # Try to import speech_recognition
        try:
            import speech_recognition as sr
            self._sr = sr
            self._recognizer = sr.Recognizer()
            # Adjust for ambient noise sensitivity
            self._recognizer.energy_threshold = 300
            self._recognizer.dynamic_energy_threshold = True
            self._recognizer.pause_threshold = 1.0
            self._available = True
        except ImportError:
            self._available = False

    @property
    def available(self) -> bool:
        """Whether voice input is available on this system."""
        return self._available

    @property
    def active(self) -> bool:
        """Whether voice mode is currently on."""
        return self._active

    @active.setter
    def active(self, value: bool):
        self._active = value

    def toggle(self) -> bool:
        """Toggle voice mode on/off. Returns new state."""
        if not self._available:
            return False
        self._active = not self._active
        return self._active

    def status_message(self) -> str:
        """Return a human-readable status string."""
        if not self._available:
            return (
                "Voice input not available. Install speech_recognition:\n"
                "  pip install SpeechRecognition pyaudio\n"
                "\n"
                "On Windows, PyAudio may need:\n"
                "  pip install pipwin && pipwin install pyaudio\n"
                "\n"
                "On macOS:\n"
                "  brew install portaudio && pip install pyaudio\n"
                "\n"
                "On Linux:\n"
                "  sudo apt install portaudio19-dev && pip install pyaudio"
            )
        if self._active:
            return f"Voice mode ON (engine: {self._engine})"
        return "Voice mode OFF"

    def set_engine(self, engine: str):
        """Set the recognition engine: 'google' or 'whisper'."""
        if engine in ("google", "whisper"):
            self._engine = engine

    def listen_once(self, timeout: float = 10.0, phrase_limit: float = 30.0) -> str | None:
        """Listen for a single phrase and return transcribed text.

        Args:
            timeout: Max seconds to wait for speech to start.
            phrase_limit: Max seconds of speech to capture.

        Returns:
            Transcribed text, or None on failure.
        """
        if not self._available:
            return None

        sr = self._sr
        try:
            mic = sr.Microphone()
        except (OSError, AttributeError):
            return None

        try:
            with mic as source:
                # Brief ambient noise calibration
                self._recognizer.adjust_for_ambient_noise(source, duration=0.5)

                # Show that we're listening
                _show_listening_indicator(True)

                try:
                    audio = self._recognizer.listen(
                        source,
                        timeout=timeout,
                        phrase_time_limit=phrase_limit,
                    )
                finally:
                    _show_listening_indicator(False)

            # Transcribe
            return self._transcribe(audio)

        except sr.WaitTimeoutError:
            return None
        except sr.UnknownValueError:
            return None
        except Exception:
            return None

    def _transcribe(self, audio) -> str | None:
        """Transcribe audio using the selected engine."""
        sr = self._sr
        try:
            if self._engine == "whisper":
                return self._transcribe_whisper(audio)
            else:
                # Google Speech Recognition (free, no API key)
                text = self._recognizer.recognize_google(audio)
                return text.strip() if text else None
        except sr.UnknownValueError:
            return None
        except sr.RequestError:
            # Google API error — try whisper fallback
            return self._transcribe_whisper(audio)

    def _transcribe_whisper(self, audio) -> str | None:
        """Transcribe using local Whisper model if available."""
        try:
            text = self._recognizer.recognize_whisper(audio, model="base", language="english")
            return text.strip() if text else None
        except Exception:
            return None

    def push_to_talk(self, key_held_check=None, timeout: float = 60.0) -> str | None:
        """Record while a condition is true (push-to-talk style).

        Args:
            key_held_check: Callable that returns True while recording should continue.
                           If None, records for up to timeout seconds.
            timeout: Max recording duration in seconds.

        Returns:
            Transcribed text, or None on failure.
        """
        if not self._available:
            return None

        sr = self._sr
        try:
            mic = sr.Microphone()
        except (OSError, AttributeError):
            return None

        try:
            with mic as source:
                self._recognizer.adjust_for_ambient_noise(source, duration=0.3)
                _show_listening_indicator(True)

                # Use a shorter phrase_time_limit for push-to-talk
                try:
                    audio = self._recognizer.listen(
                        source,
                        timeout=timeout,
                        phrase_time_limit=timeout,
                    )
                finally:
                    _show_listening_indicator(False)

            return self._transcribe(audio)

        except Exception:
            return None

    def get_audio_level(self) -> float | None:
        """Get current ambient audio level (0.0-1.0). Returns None if unavailable."""
        if not self._available or not self._recognizer:
            return None
        try:
            # Normalize energy threshold to a 0-1 range
            energy = self._recognizer.energy_threshold
            return min(1.0, energy / 4000.0)
        except Exception:
            return None


def _show_listening_indicator(on: bool):
    """Show/hide a visual indicator that we're recording."""
    if on:
        sys.stdout.write("\r  \033[38;5;196m\u25cf\033[0m \033[2mListening...\033[0m")
        sys.stdout.flush()
    else:
        sys.stdout.write("\r\033[K")
        sys.stdout.flush()
