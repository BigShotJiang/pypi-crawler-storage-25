"""Permission system for tool execution."""

from .config import DANGEROUS_TOOLS, INTERNET_TOOLS


class PermissionManager:
    def __init__(self, mode: str = "auto"):
        self.mode = mode  # "ask", "auto", "yolo"
        self._session_approvals: set[str] = set()
        self._deny_names: set[str] = set()
        self._deny_prefixes: set[str] = set()
        self._internet_enabled: bool = True

    @property
    def internet_enabled(self) -> bool:
        return self._internet_enabled

    @internet_enabled.setter
    def internet_enabled(self, value: bool):
        self._internet_enabled = value

    def deny_tool(self, name: str):
        """Block a specific tool by exact name."""
        self._deny_names.add(name)

    def deny_prefix(self, prefix: str):
        """Block all tools whose name starts with prefix."""
        self._deny_prefixes.add(prefix)

    def is_internet_blocked(self, tool_name: str) -> bool:
        """Check if a tool is blocked because internet is disabled."""
        return not self._internet_enabled and tool_name in INTERNET_TOOLS

    def is_denied(self, tool_name: str) -> bool:
        """Check if a tool is explicitly denied or internet-blocked."""
        if tool_name in self._deny_names:
            return True
        if self.is_internet_blocked(tool_name):
            return True
        return any(tool_name.startswith(p) for p in self._deny_prefixes)

    def needs_approval(self, tool_name: str) -> bool:
        if self.is_denied(tool_name):
            return True  # Denied tools always need approval (and will be blocked)
        if self.mode == "yolo":
            return False
        if self.mode == "ask":
            return tool_name not in self._session_approvals
        # auto mode
        return tool_name in DANGEROUS_TOOLS and tool_name not in self._session_approvals

    def approve(self, tool_name: str, remember: bool = False):
        if remember:
            self._session_approvals.add(tool_name)

    def approve_all(self):
        self._session_approvals.update(DANGEROUS_TOOLS)
