"""Framework/language migration helper — guided project migration."""

import os
import re
from pathlib import Path
from typing import Optional
from dataclasses import dataclass, field

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.markdown import Markdown

from .theme import VAAL_BLUE, VAAL_CYAN, VAAL_DIM, VAAL_GREEN, VAAL_YELLOW, VAAL_RED, VAAL_THEME


# Known migration mappings with file patterns and common transformations
MIGRATION_PROFILES = {
    ("flask", "fastapi"): {
        "name": "Flask to FastAPI",
        "file_patterns": ["**/*.py", "requirements.txt", "Pipfile", "pyproject.toml", "setup.py", "setup.cfg"],
        "markers": {
            "source": ["from flask import", "import flask", "@app.route", "Flask(__name__)"],
            "config": ["requirements.txt", "Pipfile", "pyproject.toml"],
        },
        "steps": [
            "Replace `flask` with `fastapi` and `uvicorn` in dependencies",
            "Convert `Flask(__name__)` to `FastAPI()` app initialization",
            "Convert `@app.route` decorators to `@app.get`/`@app.post`/etc.",
            "Replace `request.args` with function parameters + Query()",
            "Replace `request.form` with Pydantic models or Form()",
            "Replace `request.json` (or `get_json()`) with Pydantic request body models",
            "Convert `jsonify()` returns to direct dict/model returns",
            "Replace `render_template()` with Jinja2Templates if needed",
            "Convert `before_request`/`after_request` to FastAPI middleware or dependencies",
            "Replace Flask-SQLAlchemy with SQLAlchemy async sessions",
            "Update test client from Flask's to httpx.AsyncClient / TestClient",
            "Add `uvicorn.run()` or update entry point for ASGI server",
        ],
    },
    ("js", "ts"): {
        "name": "JavaScript to TypeScript",
        "file_patterns": ["**/*.js", "**/*.jsx", "package.json", "jsconfig.json", ".eslintrc*"],
        "markers": {
            "source": [".js", ".jsx"],
            "config": ["package.json", "jsconfig.json"],
        },
        "steps": [
            "Add `typescript` and `@types/node` to devDependencies",
            "Create `tsconfig.json` with appropriate compiler options",
            "Rename `.js` files to `.ts` and `.jsx` to `.tsx`",
            "Add type annotations to function parameters and return types",
            "Replace `require()` with `import` statements where needed",
            "Add interface/type definitions for data structures",
            "Fix any `any` types with proper type definitions",
            "Add type declarations for untyped third-party modules",
            "Update build scripts in package.json for tsc compilation",
            "Convert jsconfig.json to tsconfig.json if present",
            "Update ESLint config for TypeScript (@typescript-eslint)",
        ],
    },
    ("react", "vue"): {
        "name": "React to Vue 3",
        "file_patterns": ["**/*.jsx", "**/*.tsx", "**/*.js", "**/*.ts", "package.json"],
        "markers": {
            "source": ["from 'react'", "import React", "useState", "useEffect", "jsx"],
            "config": ["package.json"],
        },
        "steps": [
            "Replace react/react-dom with vue in dependencies",
            "Convert JSX components to Vue SFC (.vue) files with <template>, <script setup>, <style>",
            "Replace `useState` with `ref()` or `reactive()`",
            "Replace `useEffect` with `onMounted`, `watch`, `watchEffect`",
            "Replace `useContext` with `provide`/`inject`",
            "Convert props destructuring to `defineProps<>()`",
            "Replace `children` prop with `<slot />`",
            "Convert React Router to Vue Router",
            "Replace conditional rendering (`&&`, ternary) with `v-if`/`v-else`",
            "Convert `.map()` rendering to `v-for` directives",
            "Replace className with class",
            "Convert event handlers (`onClick`) to `@click` etc.",
            "Update state management (Redux/Zustand to Pinia)",
        ],
    },
    ("vue", "react"): {
        "name": "Vue 3 to React",
        "file_patterns": ["**/*.vue", "**/*.js", "**/*.ts", "package.json"],
        "markers": {
            "source": ["<template>", "<script setup>", "import { ref", "import { reactive"],
            "config": ["package.json"],
        },
        "steps": [
            "Replace vue with react/react-dom in dependencies",
            "Convert Vue SFC (.vue) files to JSX/TSX components",
            "Replace `ref()` and `reactive()` with `useState`",
            "Replace `onMounted`/`watch`/`watchEffect` with `useEffect`",
            "Replace `provide`/`inject` with React Context",
            "Convert `defineProps` to component props interface",
            "Replace `<slot />` with `children` prop",
            "Convert Vue Router to React Router",
            "Replace `v-if`/`v-else` with conditional rendering (&&, ternary)",
            "Convert `v-for` to `.map()` rendering",
            "Replace `class` with `className`",
            "Convert `@click` etc. to `onClick` handlers",
            "Update state management (Pinia to Redux/Zustand)",
        ],
    },
    ("express", "fastify"): {
        "name": "Express to Fastify",
        "file_patterns": ["**/*.js", "**/*.ts", "package.json"],
        "markers": {
            "source": ["require('express')", "from 'express'", "express()"],
            "config": ["package.json"],
        },
        "steps": [
            "Replace `express` with `fastify` in dependencies",
            "Convert `express()` to `fastify()` initialization",
            "Convert middleware to Fastify plugins via `fastify.register()`",
            "Replace `app.use()` middleware with Fastify hooks (onRequest, preHandler, etc.)",
            "Convert `req.body`, `req.query`, `req.params` (same names, add JSON schemas)",
            "Replace `res.json()` with `reply.send()`",
            "Replace `res.status().json()` with `reply.code().send()`",
            "Add JSON Schema validation for routes",
            "Convert error handling middleware to Fastify `setErrorHandler()`",
            "Update test setup for Fastify's `inject()` method",
        ],
    },
    ("django", "fastapi"): {
        "name": "Django to FastAPI",
        "file_patterns": ["**/*.py", "requirements.txt", "manage.py", "**/urls.py", "**/views.py", "**/models.py"],
        "markers": {
            "source": ["from django", "import django", "urlpatterns"],
            "config": ["requirements.txt", "manage.py", "settings.py"],
        },
        "steps": [
            "Replace Django with FastAPI, SQLAlchemy (or Tortoise ORM), Alembic in dependencies",
            "Convert Django models to SQLAlchemy models or Pydantic schemas",
            "Convert URL patterns (urls.py) to FastAPI router decorators",
            "Convert Django views to FastAPI endpoint functions",
            "Replace Django ORM queries with SQLAlchemy queries",
            "Convert Django forms to Pydantic models",
            "Replace Django templates with Jinja2 or separate frontend",
            "Convert Django middleware to FastAPI middleware",
            "Replace Django auth with FastAPI security (OAuth2, JWT)",
            "Convert Django management commands to CLI scripts (Click/Typer)",
            "Set up Alembic for database migrations (replaces Django migrations)",
            "Update WSGI deployment to ASGI (uvicorn/gunicorn+uvicorn)",
        ],
    },
    ("pip", "uv"): {
        "name": "pip to uv",
        "file_patterns": ["requirements*.txt", "pyproject.toml", "setup.py", "setup.cfg", "Makefile", "Dockerfile", "*.yml", "*.yaml"],
        "markers": {
            "source": ["pip install", "pip freeze"],
            "config": ["requirements.txt", "pyproject.toml"],
        },
        "steps": [
            "Install uv: `curl -LsSf https://astral.sh/uv/install.sh | sh`",
            "Replace `pip install -r requirements.txt` with `uv pip install -r requirements.txt`",
            "Replace `pip install <pkg>` with `uv pip install <pkg>`",
            "Replace `pip freeze` with `uv pip freeze`",
            "Convert requirements.txt to pyproject.toml `[project.dependencies]` if desired",
            "Update CI/CD pipelines (GitHub Actions, etc.) to use uv",
            "Update Dockerfiles to install and use uv",
            "Replace venv creation: `uv venv` instead of `python -m venv`",
        ],
    },
}


@dataclass
class MigrationPlan:
    """A generated migration plan."""
    name: str
    source: str
    target: str
    files_affected: list[str] = field(default_factory=list)
    steps: list[dict] = field(default_factory=list)  # {step, description, files}
    scan_summary: str = ""


def get_migration_profile(source: str, target: str) -> Optional[dict]:
    """Look up a known migration profile."""
    key = (source.lower().strip(), target.lower().strip())
    return MIGRATION_PROFILES.get(key)


def scan_project_for_migration(cwd: str, source: str, target: str) -> MigrationPlan:
    """Scan the project directory to identify files relevant to migration."""
    profile = get_migration_profile(source, target)
    plan = MigrationPlan(
        name=profile["name"] if profile else f"{source} to {target}",
        source=source,
        target=target,
    )

    if not profile:
        plan.scan_summary = (
            f"No built-in migration profile for {source} -> {target}. "
            f"The model will analyze the project and create a custom migration plan."
        )
        return plan

    # Scan for matching files
    from pathlib import Path
    root = Path(cwd)

    matched_files = []
    for pattern in profile["file_patterns"]:
        try:
            for p in root.glob(pattern):
                if p.is_file() and ".git" not in p.parts and "node_modules" not in p.parts:
                    rel = str(p.relative_to(root)).replace("\\", "/")
                    if rel not in matched_files:
                        matched_files.append(rel)
        except Exception:
            continue

    plan.files_affected = sorted(matched_files)[:200]  # Cap at 200 files

    # Check markers to confirm source framework is present
    markers_found = []
    for marker_file in matched_files[:50]:  # Only check first 50
        try:
            content = (root / marker_file).read_text(encoding="utf-8", errors="replace")
            for marker in profile["markers"].get("source", []):
                if marker in content:
                    markers_found.append(f"`{marker}` in {marker_file}")
        except Exception:
            continue

    # Build steps
    for i, step_desc in enumerate(profile["steps"], 1):
        plan.steps.append({
            "step": i,
            "description": step_desc,
            "status": "pending",
        })

    summary_parts = [
        f"Found {len(matched_files)} files matching migration patterns.",
    ]
    if markers_found:
        summary_parts.append(f"Confirmed {source} markers: {', '.join(markers_found[:5])}")
        if len(markers_found) > 5:
            summary_parts.append(f"  ...and {len(markers_found) - 5} more")

    plan.scan_summary = "\n".join(summary_parts)

    return plan


def format_migration_plan(plan: MigrationPlan) -> str:
    """Format a migration plan as markdown for display."""
    lines = [
        f"# Migration Plan: {plan.name}",
        "",
        f"**From**: {plan.source}  ",
        f"**To**: {plan.target}",
        "",
    ]

    if plan.scan_summary:
        lines.append("## Scan Results")
        lines.append(plan.scan_summary)
        lines.append("")

    if plan.files_affected:
        lines.append(f"## Files to Modify ({len(plan.files_affected)})")
        for f in plan.files_affected[:30]:
            lines.append(f"- `{f}`")
        if len(plan.files_affected) > 30:
            lines.append(f"- ... and {len(plan.files_affected) - 30} more")
        lines.append("")

    if plan.steps:
        lines.append("## Migration Steps")
        for step in plan.steps:
            icon = {"pending": "[ ]", "done": "[x]", "skipped": "[-]"}.get(step["status"], "[ ]")
            lines.append(f"{step['step']}. {icon} {step['description']}")
        lines.append("")

    return "\n".join(lines)


def build_migration_prompt(plan: MigrationPlan) -> str:
    """Build a prompt for the model to help execute migration."""
    plan_text = format_migration_plan(plan)

    prompt = f"""I want to migrate this project from {plan.source} to {plan.target}.

Here is the migration plan:

{plan_text}

Please help me execute this migration step by step. For each step:
1. Show me what needs to change
2. Ask for confirmation before making changes
3. Make the changes using the edit/write tools
4. Verify the changes work

Start with step 1. Show a diff preview of proposed changes before applying them."""

    return prompt


def print_migration_plan(console: Console, plan: MigrationPlan):
    """Print the migration plan to console."""
    md = format_migration_plan(plan)

    header = Text()
    header.append("Migration Plan", style=f"bold {VAAL_BLUE}")

    console.print()
    console.print(Panel(
        Markdown(md),
        title=header,
        border_style=VAAL_BLUE,
        padding=(1, 2),
    ))
    console.print()
