"""Self-repair — when vaal crashes, it reads the traceback, asks the LLM to fix it, and patches itself."""

import os
import re
import sys
import traceback
from pathlib import Path

from .theme import VAAL_GREEN, VAAL_RED, VAAL_CYAN

# Only repair files inside vaal's own source tree
VAAL_ROOT = str(Path(__file__).resolve().parent.parent)

MAX_REPAIR_ATTEMPTS = 3
_repair_count = 0


def _safe_print(msg: str):
    """Print that won't crash even if Rich console is dead."""
    try:
        from .repl import console
        console.print(msg)
    except Exception:
        # Fallback to raw stderr
        import re as _re
        clean = _re.sub(r'\[/?[^\]]*\]', '', msg)  # strip Rich markup
        sys.stderr.write(clean + "\n")
        sys.stderr.flush()


def _is_vaal_file(filepath: str) -> bool:
    try:
        return str(Path(filepath).resolve()).startswith(VAAL_ROOT)
    except Exception:
        return False


def _extract_crash_info(exc_type, exc_value, exc_tb) -> dict:
    tb_lines = traceback.format_exception(exc_type, exc_value, exc_tb)
    full_traceback = "".join(tb_lines)

    frames = traceback.extract_tb(exc_tb)
    vaal_frames = [f for f in frames if _is_vaal_file(f.filename)]

    crash_file = ""
    crash_line = 0
    crash_func = ""
    if vaal_frames:
        last = vaal_frames[-1]
        crash_file = last.filename
        crash_line = last.lineno
        crash_func = last.name

    return {
        "exception_type": exc_type.__name__ if exc_type else "Unknown",
        "exception_message": str(exc_value),
        "traceback": full_traceback,
        "crash_file": crash_file,
        "crash_line": crash_line,
        "crash_func": crash_func,
    }


def _read_crash_context(filepath: str, line_num: int, context: int = 15) -> str:
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            all_lines = f.readlines()
        start = max(0, line_num - context - 1)
        end = min(len(all_lines), line_num + context)
        numbered = []
        for i, line in enumerate(all_lines[start:end], start=start + 1):
            marker = " >> " if i == line_num else "    "
            numbered.append(f"{i:4d}{marker}{line.rstrip()}")
        return "\n".join(numbered)
    except Exception as e:
        return f"(could not read file: {e})"


def _build_repair_prompt(info: dict, file_context: str) -> str:
    return f"""You are debugging a Python CLI tool called Vaal. It just crashed:

```
{info['traceback']}
```

Crash in `{info['crash_file']}` line {info['crash_line']} in `{info['crash_func']}()`.

Code around crash:

```python
{file_context}
```

Fix this crash. Respond with ONLY:

FILE: <filepath>
OLD:
```
<exact lines to replace>
```
NEW:
```
<replacement lines>
```

Rules:
- Fix ONLY the crash, nothing else.
- OLD must match the file exactly (whitespace matters).
- Minimal fix — fewest lines changed.
"""


def _parse_repair_response(response: str) -> list[dict]:
    edits = []
    pattern = re.compile(
        r'FILE:\s*(.+?)\s*\n'
        r'OLD:\s*\n```[^\n]*\n(.*?)```\s*\n'
        r'NEW:\s*\n```[^\n]*\n(.*?)```',
        re.DOTALL
    )
    for match in pattern.finditer(response):
        filepath = match.group(1).strip()
        old_text = match.group(2)
        new_text = match.group(3)
        if old_text.endswith("\n"):
            old_text = old_text[:-1]
        if new_text.endswith("\n"):
            new_text = new_text[:-1]
        if old_text and filepath:
            edits.append({"file": filepath, "old": old_text, "new": new_text})
    return edits


def _apply_edit(filepath: str, old_text: str, new_text: str) -> tuple[bool, str]:
    """Apply edit with fuzzy matching."""
    try:
        content = Path(filepath).read_text(encoding="utf-8")

        # Strategy 1: Exact match
        if old_text in content:
            if content.count(old_text) > 1:
                return False, "matches multiple locations"
            new_content = content.replace(old_text, new_text, 1)
            Path(filepath).write_text(new_content, encoding="utf-8")
            return True, "applied"

        # Strategy 2: Line-by-line match ignoring trailing whitespace
        old_lines = [l.rstrip() for l in old_text.split("\n")]
        content_lines = content.split("\n")
        for i in range(len(content_lines) - len(old_lines) + 1):
            window = [l.rstrip() for l in content_lines[i:i + len(old_lines)]]
            if window == old_lines:
                before = content_lines[:i]
                after = content_lines[i + len(old_lines):]
                new_content = "\n".join(before + new_text.split("\n") + after)
                Path(filepath).write_text(new_content, encoding="utf-8")
                return True, "applied (whitespace-normalized)"

        # Strategy 3: Match by stripped content with flexible indentation
        old_stripped = [l.strip() for l in old_text.strip().split("\n") if l.strip()]
        if old_stripped:
            for i, cline in enumerate(content_lines):
                if cline.strip() == old_stripped[0]:
                    match = True
                    for j, ol in enumerate(old_stripped[1:], 1):
                        if i + j >= len(content_lines) or content_lines[i + j].strip() != ol:
                            match = False
                            break
                    if match:
                        indent = len(cline) - len(cline.lstrip())
                        indent_str = cline[:indent]
                        new_lines = []
                        for nl in new_text.split("\n"):
                            stripped = nl.lstrip()
                            if not stripped:
                                new_lines.append("")
                            else:
                                extra = len(nl) - len(stripped)
                                new_first = len(new_text.split("\n")[0]) - len(new_text.split("\n")[0].lstrip())
                                new_lines.append(indent_str + " " * max(0, extra - new_first) + stripped)
                        before = content_lines[:i]
                        after = content_lines[i + len(old_stripped):]
                        new_content = "\n".join(before + new_lines + after)
                        Path(filepath).write_text(new_content, encoding="utf-8")
                        return True, "applied (fuzzy-indent)"

        return False, "old_text not found in file"
    except Exception as e:
        return False, str(e)


def attempt_self_repair(exc_type, exc_value, exc_tb, model: str = "") -> bool:
    """Attempt to fix a crash in vaal's own code.

    Patches the file on disk. The fix takes effect on the next user message
    (Python re-reads function code on next call for most cases) or on restart.
    Returns True if patched successfully.
    """
    global _repair_count

    if _repair_count >= MAX_REPAIR_ATTEMPTS:
        _safe_print(f"\n  [bold red]Self-repair limit ({MAX_REPAIR_ATTEMPTS}). Restart vaal to apply previous fixes.[/]")
        return False

    _repair_count += 1

    info = _extract_crash_info(exc_type, exc_value, exc_tb)
    if not info["crash_file"] or not _is_vaal_file(info["crash_file"]):
        return False

    _safe_print(f"\n  [bold red]Crash[/] [dim]({_repair_count}/{MAX_REPAIR_ATTEMPTS})[/dim]")
    _safe_print(f"  ⎿  [red]{info['exception_type']}: {info['exception_message']}[/]")
    _safe_print(f"  ⎿  [dim]{info['crash_file']}:{info['crash_line']} in {info['crash_func']}()[/dim]")
    _safe_print(f"  [dim]Asking LLM to fix...[/dim]")

    file_context = _read_crash_context(info["crash_file"], info["crash_line"])
    prompt = _build_repair_prompt(info, file_context)

    try:
        from .llm import chat_with_tools_stream
        if not model:
            from .config import DEFAULT_MODEL
            try:
                from .user_config import UserConfig
                model = UserConfig().default_model or DEFAULT_MODEL
            except Exception:
                model = DEFAULT_MODEL

        messages = [
            {"role": "system", "content": "You are a Python debugging expert. Fix crashes with minimal, precise edits."},
            {"role": "user", "content": prompt},
        ]

        content_parts = []
        for chunk in chat_with_tools_stream(messages, [], model=model):
            if chunk.get("content"):
                content_parts.append(chunk["content"])

        response = "".join(content_parts).strip()
        if not response:
            _safe_print(f"  [red]LLM returned empty response.[/]")
            return False

        edits = _parse_repair_response(response)
        if not edits:
            _safe_print(f"  [red]Could not parse fix from response.[/]")
            return False

        all_ok = True
        for edit in edits:
            filepath = edit["file"]
            if not os.path.isabs(filepath):
                filepath = os.path.join(VAAL_ROOT, filepath)
            ok, msg = _apply_edit(filepath, edit["old"], edit["new"])
            if ok:
                short = filepath.replace(VAAL_ROOT + os.sep, "").replace("\\", "/")
                _safe_print(f"  [dim]✓ Patched[/dim] [dim]{short}[/dim]")
            else:
                _safe_print(f"  [red]Edit failed ({filepath}): {msg}[/]")
                all_ok = False

        if all_ok:
            _safe_print(f"  [dim]✓ Fixed on disk. Restart vaal to apply.[/dim]")
            return True
        else:
            _safe_print(f"  [red]Some edits failed.[/]")
            return False

    except Exception as e:
        _safe_print(f"  [red]Self-repair error: {e}[/]")
        return False


def reset_repair_count():
    global _repair_count
    _repair_count = 0
