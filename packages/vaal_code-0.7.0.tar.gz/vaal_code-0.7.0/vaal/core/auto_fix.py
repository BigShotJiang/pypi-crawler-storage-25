"""Auto-fix on error — intercept bash failures and ask the LLM to fix them."""

import re


# Global toggle
_enabled = False
MAX_FIX_ATTEMPTS = 3


def is_enabled() -> bool:
    return _enabled


def toggle() -> bool:
    """Toggle auto-fix mode. Returns new state."""
    global _enabled
    _enabled = not _enabled
    return _enabled


def set_enabled(val: bool):
    global _enabled
    _enabled = val


def detect_bash_failure(tool_name: str, result: str) -> str | None:
    """Check if a bash tool result indicates failure.

    Returns the error text if it failed, None otherwise.
    """
    if tool_name != "bash":
        return None
    # Look for the [exit code: N] marker where N != 0
    match = re.search(r'\[exit code: (\d+)\]', result)
    if match and match.group(1) != "0":
        return result
    # Also catch tool-level errors
    if result.startswith("[error:") or result.startswith("[command timed out"):
        return result
    return None


def build_fix_prompt(command: str, error_output: str, attempt: int) -> str:
    """Build the prompt to send to the LLM asking it to fix the error."""
    attempt_note = ""
    if attempt > 1:
        attempt_note = f" (attempt {attempt}/{MAX_FIX_ATTEMPTS} — previous fix did not resolve the issue)"
    return (
        f"[AUTO-FIX]{attempt_note} The previous bash command failed:\n\n"
        f"```\n{command}\n```\n\n"
        f"Error output:\n```\n{error_output}\n```\n\n"
        f"Analyze the error and fix it. Run the corrected command or make "
        f"the necessary file edits to resolve the issue."
    )
