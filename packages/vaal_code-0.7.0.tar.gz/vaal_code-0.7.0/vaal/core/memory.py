"""Persistent memory system — markdown files with frontmatter in ~/.vaal/memory/."""

import re
import time
from pathlib import Path
from dataclasses import dataclass, field

from .config import MEMORY_DIR, ensure_dirs


MEMORY_TYPES = ("user", "feedback", "project", "reference")
INDEX_FILE = "MEMORY.md"


@dataclass
class MemoryEntry:
    name: str
    content: str
    type: str = "user"
    description: str = ""
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    def to_markdown(self) -> str:
        """Serialize to markdown with YAML-style frontmatter."""
        lines = [
            "---",
            f"name: {self.name}",
            f"type: {self.type}",
            f"description: {self.description}",
            f"created_at: {self.created_at}",
            f"updated_at: {self.updated_at}",
            "---",
            "",
            self.content,
        ]
        return "\n".join(lines)

    @classmethod
    def from_markdown(cls, text: str, filename: str = "") -> "MemoryEntry":
        """Parse a markdown file with frontmatter."""
        match = re.match(r"^---\s*\n(.*?)\n---\s*\n(.*)", text, re.DOTALL)
        if not match:
            # No frontmatter — treat entire text as content
            name = Path(filename).stem if filename else "untitled"
            return cls(name=name, content=text.strip())

        frontmatter, body = match.group(1), match.group(2)
        meta = {}
        for line in frontmatter.splitlines():
            if ":" in line:
                key, val = line.split(":", 1)
                meta[key.strip()] = val.strip()

        return cls(
            name=meta.get("name", Path(filename).stem if filename else "untitled"),
            type=meta.get("type", "user"),
            description=meta.get("description", ""),
            created_at=float(meta.get("created_at", time.time())),
            updated_at=float(meta.get("updated_at", time.time())),
            content=body.strip(),
        )


def _slug(name: str) -> str:
    """Convert a memory name to a safe filename slug."""
    s = re.sub(r"[^\w\s-]", "", name.lower())
    s = re.sub(r"[\s]+", "_", s.strip())
    return s or "untitled"


class MemoryStore:
    """Persistent memory backed by ~/.vaal/memory/ directory."""

    def __init__(self, directory: Path | None = None):
        self.directory = directory or MEMORY_DIR
        ensure_dirs()

    def _path_for(self, name: str) -> Path:
        return self.directory / f"{_slug(name)}.md"

    def save_memory(self, name: str, content: str, type: str = "user", description: str = "") -> MemoryEntry:
        """Save or update a memory entry."""
        if type not in MEMORY_TYPES:
            type = "user"

        path = self._path_for(name)

        # Preserve created_at if updating
        existing = self.get_memory(name)
        created = existing.created_at if existing else time.time()

        entry = MemoryEntry(
            name=name,
            content=content,
            type=type,
            description=description,
            created_at=created,
            updated_at=time.time(),
        )
        path.write_text(entry.to_markdown(), encoding="utf-8")
        self._rebuild_index()
        return entry

    def get_memory(self, name: str) -> MemoryEntry | None:
        """Get a specific memory by name."""
        path = self._path_for(name)
        if not path.exists():
            return None
        try:
            text = path.read_text(encoding="utf-8")
            return MemoryEntry.from_markdown(text, path.name)
        except Exception:
            return None

    def delete_memory(self, name: str) -> bool:
        """Delete a memory entry. Returns True if deleted."""
        path = self._path_for(name)
        if path.exists():
            path.unlink()
            self._rebuild_index()
            return True
        return False

    def list_memories(self, type_filter: str | None = None) -> list[MemoryEntry]:
        """List all memories, optionally filtered by type."""
        entries = []
        for f in sorted(self.directory.glob("*.md")):
            if f.name == INDEX_FILE:
                continue
            try:
                text = f.read_text(encoding="utf-8")
                entry = MemoryEntry.from_markdown(text, f.name)
                if type_filter and entry.type != type_filter:
                    continue
                entries.append(entry)
            except Exception:
                continue
        return entries

    def search_memory(self, query: str) -> list[MemoryEntry]:
        """Fuzzy search through memories by name, description, and content."""
        query_lower = query.lower()
        terms = query_lower.split()
        results = []

        for entry in self.list_memories():
            searchable = f"{entry.name} {entry.description} {entry.content}".lower()
            # Score: how many query terms appear in the searchable text
            score = sum(1 for t in terms if t in searchable)
            if score > 0:
                results.append((score, entry))

        # Sort by score descending, then by updated_at descending
        results.sort(key=lambda x: (-x[0], -x[1].updated_at))
        return [entry for _, entry in results]

    def get_relevant_memories(self, context: str = "", max_entries: int = 10) -> list[MemoryEntry]:
        """Get memories relevant to the current context for system prompt injection.

        If context is provided, returns search results; otherwise returns most recent.
        """
        if context:
            return self.search_memory(context)[:max_entries]
        # Fall back to most recently updated
        entries = self.list_memories()
        entries.sort(key=lambda e: e.updated_at, reverse=True)
        return entries[:max_entries]

    def to_prompt_section(self, context: str = "", max_entries: int = 10) -> str:
        """Build a system prompt section from relevant memories."""
        entries = self.get_relevant_memories(context, max_entries)
        if not entries:
            return ""

        lines = ["# Memories", ""]
        for entry in entries:
            lines.append(f"## {entry.name} ({entry.type})")
            if entry.description:
                lines.append(f"*{entry.description}*")
            lines.append("")
            lines.append(entry.content)
            lines.append("")
        return "\n".join(lines)

    def _rebuild_index(self):
        """Rebuild the MEMORY.md index file."""
        entries = self.list_memories()
        lines = [
            "# Vaal Memory Index",
            "",
            f"Total memories: {len(entries)}",
            "",
            "| Name | Type | Description |",
            "|------|------|-------------|",
        ]
        for e in entries:
            desc = e.description[:60] if e.description else ""
            lines.append(f"| {e.name} | {e.type} | {desc} |")

        index_path = self.directory / INDEX_FILE
        index_path.write_text("\n".join(lines), encoding="utf-8")
