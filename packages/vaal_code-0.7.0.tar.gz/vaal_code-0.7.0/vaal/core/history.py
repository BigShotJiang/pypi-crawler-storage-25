"""Prompt history tracking — logs every user prompt to ~/.vaal/history.jsonl."""

import json
import time
from pathlib import Path

from .config import HISTORY_FILE, ensure_dirs


def record_prompt(prompt: str, model: str, session_id: str):
    """Append a prompt entry to the history file."""
    ensure_dirs()
    entry = {
        "timestamp": time.time(),
        "iso": time.strftime("%Y-%m-%d %H:%M:%S"),
        "prompt": prompt,
        "model": model,
        "session_id": session_id,
    }
    with open(HISTORY_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


def load_history(limit: int = 20) -> list[dict]:
    """Load the most recent `limit` history entries."""
    ensure_dirs()
    if not HISTORY_FILE.exists():
        return []

    entries = []
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    return entries[-limit:]


def format_history(entries: list[dict]) -> str:
    """Format history entries for display."""
    if not entries:
        return "  No history yet."

    lines = []
    for e in entries:
        ts = e.get("iso", "?")
        model = e.get("model", "?")
        sid = e.get("session_id", "?")
        prompt = e.get("prompt", "")
        # Truncate long prompts
        if len(prompt) > 80:
            prompt = prompt[:77] + "..."
        lines.append(f"  {ts}  [{model}]  ({sid})  {prompt}")
    return "\n".join(lines)
