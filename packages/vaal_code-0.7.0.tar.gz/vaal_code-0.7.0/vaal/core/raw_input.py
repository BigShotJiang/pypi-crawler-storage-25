"""Raw terminal input with cursor movement, history, and special key handling."""

import os
import sys

_history: list[str] = []
_history_pos: int = -1
_history_loaded: bool = False


def load_persistent_history(limit: int = 100):
    """Load prompt history from disk into the input history buffer."""
    global _history, _history_loaded
    if _history_loaded:
        return
    _history_loaded = True
    try:
        from .history import load_history
        entries = load_history(limit=limit)
        for e in entries:
            prompt = e.get("prompt", "").strip()
            if prompt and (not _history or _history[-1] != prompt):
                _history.append(prompt)
    except Exception:
        pass


def _write(s):
    sys.stdout.write(s)
    sys.stdout.flush()


def read_prompt(prompt_str: str = "> ") -> tuple[str, str | None]:
    """Read user input with full editing support.

    Returns (text, trigger).
    - trigger = "slash" if '/' typed as first char
    - trigger = "down" if down arrow pressed on empty line
    - trigger = None for normal input (Enter pressed)
    """
    global _history_pos, _prev_wrap_rows
    _history_pos = -1
    _prev_wrap_rows = 1

    load_persistent_history()

    _write(prompt_str)

    if sys.platform == "win32":
        return _read_win(prompt_str)
    else:
        return _read_unix(prompt_str)


def add_to_history(text: str):
    """Add a completed input to history."""
    if text and (not _history or _history[-1] != text):
        _history.append(text)


CONT_PROMPT = "  \033[2m...\033[0m "  # Continuation prompt for multiline


_prev_wrap_rows = 1  # track how many terminal rows the previous render used


def _redraw(prompt_str: str, buf: list, cursor: int):
    """Redraw the input line(s) with cursor at position."""
    global _prev_wrap_rows
    text = "".join(buf)
    lines = text.split("\n")

    if len(lines) == 1:
        # Calculate how many terminal rows this will occupy
        try:
            import shutil
            term_width = shutil.get_terminal_size().columns
        except Exception:
            term_width = 80
        # Prompt visible length (strip ANSI)
        import re
        prompt_visible = len(re.sub(r'\033\[[^m]*m', '', prompt_str))
        total_chars = prompt_visible + len(text)
        wrap_rows = max(1, (total_chars + term_width - 1) // term_width)

        # Move up to clear all rows from previous render
        if _prev_wrap_rows > 1:
            _write(f"\033[{_prev_wrap_rows - 1}A")
        # Rewrite prompt+text, clear to end of line
        _write(f"\r{prompt_str}{text}\033[K")
        _prev_wrap_rows = wrap_rows

        back = len(buf) - cursor
        if back > 0:
            _write(f"\033[{back}D")
    else:
        # Multiline: clear and redraw all lines
        # Move to first line
        if len(lines) > 1:
            _write(f"\033[{len(lines) - 1}A")
        for i, line in enumerate(lines):
            p = prompt_str if i == 0 else CONT_PROMPT
            _write(f"\r\033[2K{p}{line}")
            if i < len(lines) - 1:
                _write("\n")
        # Position cursor
        # Find which line and column the cursor is at
        pos = 0
        cur_line = 0
        cur_col = 0
        for i, ch in enumerate(buf):
            if i == cursor:
                break
            if ch == "\n":
                cur_line += 1
                cur_col = 0
            else:
                cur_col += 1
        # Move to cursor line
        lines_from_end = len(lines) - 1 - cur_line
        if lines_from_end > 0:
            _write(f"\033[{lines_from_end}A")
        p_len = len(prompt_str.replace("\033[1;37m", "").replace("\033[0m", "").replace("\033[2m", "")) if cur_line == 0 else 6
        _write(f"\r\033[{p_len + cur_col + 1}G")


def _read_win(prompt_str: str) -> tuple[str, str | None]:
    import msvcrt
    global _history_pos

    buf = []
    cursor = 0  # Cursor position within buf

    while True:
        ch = msvcrt.getwch()

        if ch in ("\x00", "\xe0"):
            key2 = msvcrt.getwch()
            if key2 == "H":
                # Up arrow — history
                if _history:
                    if _history_pos == -1:
                        _history_pos = len(_history) - 1
                    elif _history_pos > 0:
                        _history_pos -= 1
                    buf = list(_history[_history_pos])
                    cursor = len(buf)
                    _redraw(prompt_str, buf, cursor)
                continue
            elif key2 == "P":
                # Down arrow
                if not buf:
                    # Empty line — trigger command palette
                    _write(f"\r\033[2K")
                    return "", "down"
                if _history_pos != -1:
                    _history_pos += 1
                    if _history_pos >= len(_history):
                        _history_pos = -1
                        buf = []
                    else:
                        buf = list(_history[_history_pos])
                    cursor = len(buf)
                    _redraw(prompt_str, buf, cursor)
                continue
            elif key2 == "K":
                # Left arrow
                if cursor > 0:
                    cursor -= 1
                    _write("\033[D")
                continue
            elif key2 == "M":
                # Right arrow
                if cursor < len(buf):
                    cursor += 1
                    _write("\033[C")
                continue
            elif key2 == "G":
                # Home
                cursor = 0
                _redraw(prompt_str, buf, cursor)
                continue
            elif key2 == "O":
                # End
                cursor = len(buf)
                _redraw(prompt_str, buf, cursor)
                continue
            elif key2 == "S":
                # Delete
                if cursor < len(buf):
                    buf.pop(cursor)
                    _redraw(prompt_str, buf, cursor)
                continue
            continue

        if ch == "\r":
            # Paste detection: if more characters are immediately available,
            # this \r is part of a paste (Windows Terminal sends \r\n per line).
            if msvcrt.kbhit():
                # Drain ALL queued characters at once (the full paste)
                import time
                paste_chars = []
                # The triggering \r might be followed by \n (Windows \r\n).
                # Peek at next char — if it's \n, consume it (part of \r\n pair).
                # Don't insert a newline yet — only real line breaks in the
                # pasted text should create newlines.
                next_c = msvcrt.getwch()
                if next_c == "\n":
                    # This was \r\n — check if MORE chars follow (real paste)
                    # or if this was just Enter being slow
                    if not msvcrt.kbhit():
                        time.sleep(0.02)
                    if not msvcrt.kbhit():
                        # No more chars — this was just Enter, not a paste
                        if buf and buf[-1] == "\\":
                            buf[-1] = "\n"
                            cursor = len(buf)
                            _write("\n")
                            _write(CONT_PROMPT)
                            continue
                        _write("\n")
                        text = "".join(buf).strip()
                        if text:
                            add_to_history(text)
                        return text, None
                    # More chars — this is a real paste, the \r\n is a line break
                    paste_chars.append("\n")
                elif next_c in ("\x00", "\xe0"):
                    msvcrt.getwch()  # Consume special key
                elif next_c == "\r":
                    paste_chars.append("\n")  # Another \r = line break
                else:
                    paste_chars.append(next_c)  # Regular char after \r

                while True:
                    if msvcrt.kbhit():
                        c = msvcrt.getwch()
                        if c == "\r":
                            paste_chars.append("\n")
                        elif c == "\n":
                            continue  # Skip \n after \r (Windows \r\n)
                        elif c in ("\x00", "\xe0"):
                            msvcrt.getwch()  # Consume special key second byte
                        else:
                            paste_chars.append(c)
                    else:
                        # Brief pause to catch any remaining paste chars
                        time.sleep(0.02)
                        if not msvcrt.kbhit():
                            break

                # Strip trailing newlines (the final \r\n of the paste)
                while paste_chars and paste_chars[-1] == "\n":
                    paste_chars.pop()

                if not paste_chars:
                    # Empty paste — treat as Enter
                    _write("\n")
                    text = "".join(buf).strip()
                    if text:
                        add_to_history(text)
                    return text, None

                # Collapse soft-wrapped lines: if the paste looks like a
                # single paragraph with line breaks from terminal wrapping
                # (no blank lines, no code indicators), join into one line.
                paste_text = "".join(paste_chars)
                if "\n" in paste_text:
                    paste_lines = paste_text.split("\n")
                    # Check if this is a soft-wrapped paragraph vs real multiline
                    # Real multiline: has blank lines, code fences, or bullet points
                    _has_structure = any(
                        l.strip() == "" or
                        l.strip().startswith("```") or
                        l.strip().startswith("- ") or
                        l.strip().startswith("* ") or
                        (len(l) > 0 and l[0] in " \t")  # indented = code
                        for l in paste_lines
                    )
                    if not _has_structure:
                        # Looks like soft-wrapped text — join with spaces
                        paste_chars = list(" ".join(l for l in paste_lines if l))

                # Insert all pasted characters into buffer
                for c in paste_chars:
                    buf.insert(cursor, c)
                    cursor += 1

                # Count how many lines the buffer now has
                text = "".join(buf)
                num_lines = text.count("\n") + 1

                # Move to start of prompt line and clear down, then
                # print blank lines so _redraw can move up correctly
                _write(f"\r\033[2K")
                if num_lines > 1:
                    for _ in range(num_lines - 1):
                        _write("\n\033[2K")
                    # Move back up to the first line
                    _write(f"\033[{num_lines - 1}A")

                _redraw(prompt_str, buf, cursor)
                continue

            # No more chars available — this is a real Enter press
            # Check if line ends with \ — continuation
            if buf and buf[-1] == "\\":
                buf[-1] = "\n"  # Replace \ with newline
                cursor = len(buf)
                _write("\n")
                _write(CONT_PROMPT)
                continue
            _write("\n")
            text = "".join(buf).strip()
            if text:
                add_to_history(text)
            return text, None

        if ch == "\n":
            # Shift+Enter or standalone newline — multiline continuation
            buf.insert(cursor, "\n")
            cursor += 1
            _write("\n")
            _write(CONT_PROMPT)
            continue

        if ch == "\x01":
            # Ctrl+A — move cursor to beginning of line
            cursor = 0
            _redraw(prompt_str, buf, cursor)
            continue

        if ch == "\x05":
            # Ctrl+E — move cursor to end of line
            cursor = len(buf)
            _redraw(prompt_str, buf, cursor)
            continue

        if ch == "\x03":
            raise KeyboardInterrupt

        if ch == "\x04" or ch == "\x1a":
            raise EOFError

        if ch == "\x08":
            # Backspace
            if cursor > 0:
                buf.pop(cursor - 1)
                cursor -= 1
                _redraw(prompt_str, buf, cursor)
            continue

        if ch == "\x16":
            # Ctrl+V — check for image first, then text
            _pasted_something = False
            try:
                from .image_input import get_clipboard_image
                img = get_clipboard_image()
                if img:
                    # Image found — insert [image] marker
                    marker = "[image]"
                    for c in marker:
                        buf.insert(cursor, c)
                        cursor += 1
                    _redraw(prompt_str, buf, cursor)
                    _pasted_something = True
            except Exception:
                pass
            if not _pasted_something:
                try:
                    from .clipboard import paste_from_clipboard
                    pasted = paste_from_clipboard()
                    if pasted:
                        for c in pasted:
                            if c == "\r":
                                continue
                            buf.insert(cursor, c)
                            cursor += 1
                        _redraw(prompt_str, buf, cursor)
                except Exception:
                    pass
            continue

        if ch == "\t":
            # Tab completion for file paths
            text = "".join(buf[:cursor])
            # Get the last whitespace-delimited token as the partial path
            tokens = text.split()
            if tokens:
                word = tokens[-1]
                word_start = text.rfind(word)
                try:
                    import glob as _glob
                    # Normalize backslashes to forward slashes for glob
                    pattern = word.replace("\\", "/") + "*"
                    matches = _glob.glob(pattern)
                    if not matches:
                        # Try with backslashes on Windows
                        pattern_bs = word + "*"
                        matches = _glob.glob(pattern_bs)
                    if len(matches) == 1:
                        # Single match — replace the word with the match
                        replacement = matches[0].replace("\\", "/")
                        # If it's a directory, append /
                        import os as _os
                        if _os.path.isdir(replacement) and not replacement.endswith("/"):
                            replacement += "/"
                        # Remove old word from buf and insert replacement
                        new_buf = list(text[:word_start] + replacement)
                        buf[:cursor] = new_buf
                        cursor = len(new_buf)
                        _redraw(prompt_str, buf, cursor)
                    elif len(matches) > 1:
                        # Find common prefix for partial completion
                        common = os.path.commonprefix([m.replace("\\", "/") for m in matches])
                        if len(common) > len(word):
                            new_buf = list(text[:word_start] + common)
                            buf[:cursor] = new_buf
                            cursor = len(new_buf)
                            _redraw(prompt_str, buf, cursor)
                        else:
                            # Show matches below prompt
                            _write("\n")
                            display = [m.replace("\\", "/") for m in matches]
                            for m in display[:20]:
                                _write(f"  {m}\n")
                            if len(display) > 20:
                                _write(f"  ... {len(display) - 20} more\n")
                            _redraw(prompt_str, buf, cursor)
                except Exception:
                    pass
            continue

        if ch == "/" and len(buf) == 0:
            _write(f"\r\033[2K")
            return "/", "slash"

        # Normal character
        buf.insert(cursor, ch)
        cursor += 1
        _redraw(prompt_str, buf, cursor)


def _read_unix(prompt_str: str) -> tuple[str, str | None]:
    import tty
    import termios
    global _history_pos

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)

    buf = []
    cursor = 0

    try:
        tty.setcbreak(fd)

        while True:
            ch = sys.stdin.read(1)

            if ch == "\n" or ch == "\r":
                # Check for \ continuation
                if buf and buf[-1] == "\\":
                    buf[-1] = "\n"
                    cursor = len(buf)
                    _write("\n")
                    _write(CONT_PROMPT)
                    continue
                _write("\n")
                text = "".join(buf).strip()
                if text:
                    add_to_history(text)
                return text, None

            if ch == "\x03":
                raise KeyboardInterrupt

            if ch == "\x04":
                raise EOFError

            if ch == "\x1b":
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "A":
                        # Up — history
                        if _history:
                            if _history_pos == -1:
                                _history_pos = len(_history) - 1
                            elif _history_pos > 0:
                                _history_pos -= 1
                            buf = list(_history[_history_pos])
                            cursor = len(buf)
                            _redraw(prompt_str, buf, cursor)
                    elif ch3 == "B":
                        # Down
                        if not buf:
                            _write(f"\r\033[2K")
                            return "", "down"
                        if _history_pos != -1:
                            _history_pos += 1
                            if _history_pos >= len(_history):
                                _history_pos = -1
                                buf = []
                            else:
                                buf = list(_history[_history_pos])
                            cursor = len(buf)
                            _redraw(prompt_str, buf, cursor)
                    elif ch3 == "D":
                        # Left
                        if cursor > 0:
                            cursor -= 1
                            _write("\033[D")
                    elif ch3 == "C":
                        # Right
                        if cursor < len(buf):
                            cursor += 1
                            _write("\033[C")
                    elif ch3 == "H":
                        cursor = 0
                        _redraw(prompt_str, buf, cursor)
                    elif ch3 == "F":
                        cursor = len(buf)
                        _redraw(prompt_str, buf, cursor)
                    elif ch3 == "3":
                        # Delete key (sends \x1b[3~)
                        sys.stdin.read(1)  # consume ~
                        if cursor < len(buf):
                            buf.pop(cursor)
                            _redraw(prompt_str, buf, cursor)
                continue

            if ch == "\x7f" or ch == "\x08":
                if cursor > 0:
                    buf.pop(cursor - 1)
                    cursor -= 1
                    _redraw(prompt_str, buf, cursor)
                continue

            if ch == "\x16":
                # Ctrl+V — paste from clipboard
                try:
                    from .clipboard import paste_from_clipboard
                    pasted = paste_from_clipboard()
                    if pasted:
                        for c in pasted:
                            if c == "\r":
                                continue
                            buf.insert(cursor, c)
                            cursor += 1
                        _redraw(prompt_str, buf, cursor)
                except Exception:
                    pass
                continue

            if ch == "\t":
                # Tab completion for file paths
                text = "".join(buf[:cursor])
                tokens = text.split()
                if tokens:
                    word = tokens[-1]
                    word_start = text.rfind(word)
                    try:
                        import glob as _glob
                        pattern = word + "*"
                        matches = _glob.glob(pattern)
                        if len(matches) == 1:
                            replacement = matches[0]
                            if os.path.isdir(replacement) and not replacement.endswith("/"):
                                replacement += "/"
                            new_buf = list(text[:word_start] + replacement)
                            buf[:cursor] = new_buf
                            cursor = len(new_buf)
                            _redraw(prompt_str, buf, cursor)
                        elif len(matches) > 1:
                            common = os.path.commonprefix(matches)
                            if len(common) > len(word):
                                new_buf = list(text[:word_start] + common)
                                buf[:cursor] = new_buf
                                cursor = len(new_buf)
                                _redraw(prompt_str, buf, cursor)
                            else:
                                _write("\n")
                                for m in matches[:20]:
                                    _write(f"  {m}\n")
                                if len(matches) > 20:
                                    _write(f"  ... {len(matches) - 20} more\n")
                                _redraw(prompt_str, buf, cursor)
                    except Exception:
                        pass
                continue

            if ch == "/" and len(buf) == 0:
                _write(f"\r\033[2K")
                return "/", "slash"

            buf.insert(cursor, ch)
            cursor += 1
            _redraw(prompt_str, buf, cursor)

    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
