"""LLM client — talks to Ollama with native tool calling."""

import json
from typing import Generator

import httpx

from .config import OLLAMA_HOST, DEFAULT_MODEL, MAX_OUTPUT_TOKENS


SYSTEM_PROMPT_TEMPLATE = """\
You are Vaal, an AI coding agent with full filesystem and shell access via tools.

Working directory: {cwd}
Platform: {platform}
Shell: {shell}

Your tools: glob, grep, read, write, edit, bash, find_definition, find_references, list_symbols, file_tree, run_python, web_fetch, web_search, spawn_agent, check_agent, list_agents, todo_create, todo_update, todo_list, git_status, git_diff, git_log, git_commit, git_branch, notebook_read, notebook_edit

You MUST use tools to complete tasks. Do not describe what you would do — do it.

Rules:
- Use ABSOLUTE paths: {cwd}/path/to/file
- glob: find files by pattern (e.g. pattern="**/*.py")
- read: read a file (always read before editing)
- edit: modify a file (provide exact old_string and new_string)
- write: create a new file (provide file_path and content)
- bash: run shell commands ({shell} syntax, not {anti_shell})
- grep: search file contents by regex
- Chain multiple tool calls. After each result, continue until the task is fully done.
"""


def build_system_prompt(project_instructions: str | None = None, project_info: str | None = None) -> str:
    import os, platform as plat
    cwd = os.getcwd().replace("\\", "/")
    is_windows = plat.system() == "Windows"
    prompt = SYSTEM_PROMPT_TEMPLATE.format(
        cwd=cwd,
        platform=plat.system(),
        shell="PowerShell/cmd" if is_windows else "bash",
        anti_shell="Unix ls/cat" if is_windows else "Windows cmd",
    )
    if project_info:
        prompt += f"\n{project_info}\n"
    if project_instructions:
        prompt += f"\n# Project Instructions\n{project_instructions}\n"
    return prompt


def get_ollama_tools(tool_defs: dict) -> list[dict]:
    """Convert our tool definitions to Ollama's tool format.

    Uses enriched descriptions for core tools to help smaller models
    understand when and how to use each tool correctly.
    """
    # Slightly enriched descriptions for core tools
    ENRICHED = {
        "read": "Read a file. Returns numbered lines. Read before editing.",
        "write": "Create or overwrite a file with content.",
        "edit": "Edit a file. Provide exact old_string to find and new_string to replace it with.",
        "bash": "Run a shell command (git, tests, builds, etc).",
        "glob": "Find files by name pattern (e.g. '**/*.py').",
        "grep": "Search file contents by regex pattern.",
    }

    tools = []
    for name, tdef in tool_defs.items():
        properties = {}
        required = []
        for pname, pinfo in tdef.parameters.items():
            properties[pname] = {
                "type": "string",
                "description": pinfo.get("description", ""),
            }
            if pinfo.get("required"):
                required.append(pname)

        desc = ENRICHED.get(name, tdef.description)

        tools.append({
            "type": "function",
            "function": {
                "name": name,
                "description": desc,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required,
                },
            },
        })
    return tools


def check_connection(model: str = "") -> bool:
    """Check if the provider for the given model is reachable."""
    if model:
        from .providers import parse_model_string, check_provider_connection
        provider, _ = parse_model_string(model)
        return check_provider_connection(provider)
    # Default: check Ollama
    try:
        r = httpx.get(f"{OLLAMA_HOST}/api/tags", timeout=3)
        return r.status_code == 200
    except Exception:
        return False


def list_models(provider: str = "ollama") -> list[str]:
    """List models for a provider."""
    from .providers import list_provider_models
    return list_provider_models(provider)


# Models known to not support native tool calling (heretic/abliterated, raw GGUFs, etc.)
# For these, we skip the tools param to avoid hanging.
# Models known to break with Ollama's native tool calling.
# These either return empty responses or hang when tools param is passed.
NO_TOOL_KEYWORDS = {
    "heretic", "abliterated", "uncensored",
    "deepseek",  # DeepSeek models choke on tools param
    "gemma",     # Some Gemma variants don't support tools
}

# Cache: models we've confirmed don't work with tools at runtime
_tool_broken_models: set = set()


def model_supports_tools(model: str) -> bool:
    """Check if a model supports native Ollama tool calling."""
    lower = model.lower()
    if lower in _tool_broken_models:
        return False
    return not any(tag in lower for tag in NO_TOOL_KEYWORDS)


def mark_tools_broken(model: str):
    """Mark a model as not supporting tools (detected at runtime)."""
    _tool_broken_models.add(model.lower())


def chat_with_tools_stream(
    messages: list[dict],
    tools: list[dict],
    model: str = DEFAULT_MODEL,
    think: bool = False,
) -> Generator[dict, None, None]:
    """Streaming chat with tool support. Routes to the correct provider.
    Yields chunks with content/tool_calls/done keys."""
    from .providers import parse_model_string, stream_provider

    provider, model_id = parse_model_string(model)

    # Cloud models get more output tokens for large file writes
    # Capable local models (Qwen 3, Llama 3.1) also get more
    output_limit = MAX_OUTPUT_TOKENS
    if provider in ("anthropic", "openai", "codex", "openrouter"):
        output_limit = 16384
    elif provider == "ollama":
        # Qwen 3, Llama 3.x, Mistral — all support longer outputs
        output_limit = MAX_OUTPUT_TOKENS  # Now 8192 from config
    elif provider == "airllm":
        # Respect airllm config max_new_tokens; stream_airllm caps internally
        from .airllm_provider import get_airllm_config
        output_limit = get_airllm_config().get("max_new_tokens") or 512

    yield from stream_provider(
        provider_name=provider,
        model=model_id,
        messages=messages,
        tools=tools,
        max_tokens=output_limit,
        think=think,
    )


def stream_chat(
    messages: list[dict],
    model: str = DEFAULT_MODEL,
    think: bool = False,
) -> Generator[dict, None, None]:
    """Stream chat completion (no tools). Yields chunks."""
    with httpx.stream(
        "POST",
        f"{OLLAMA_HOST}/api/chat",
        json={
            "model": model,
            "messages": messages,
            "stream": True,
            "think": think,
            "options": {
                "num_predict": MAX_OUTPUT_TOKENS,
                "temperature": 0.3,
            },
        },
        timeout=None,
    ) as r:
        for line in r.iter_lines():
            if not line:
                continue
            data = json.loads(line)
            msg = data.get("message", {})
            result = {}
            if msg.get("thinking"):
                result["thinking"] = msg["thinking"]
            if msg.get("content"):
                result["content"] = msg["content"]
            if data.get("done"):
                result["done"] = True
                result["eval_count"] = data.get("eval_count", 0)
                result["eval_duration"] = data.get("eval_duration", 0)
            if result:
                yield result
