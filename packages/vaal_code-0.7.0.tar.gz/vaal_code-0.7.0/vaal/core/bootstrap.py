"""Project bootstrap — detect language, tooling, and tech stack for a directory."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field, asdict
from pathlib import Path

from .config import VAAL_DIR, ensure_dirs

PROJECTS_DIR = VAAL_DIR / "projects"

# Extension -> language mapping
LANG_EXTENSIONS = {
    ".py": "Python",
    ".js": "JavaScript",
    ".ts": "TypeScript",
    ".tsx": "TypeScript (React)",
    ".jsx": "JavaScript (React)",
    ".rs": "Rust",
    ".go": "Go",
    ".php": "PHP",
    ".java": "Java",
    ".kt": "Kotlin",
    ".swift": "Swift",
    ".rb": "Ruby",
    ".c": "C",
    ".cpp": "C++",
    ".cs": "C#",
    ".lua": "Lua",
    ".zig": "Zig",
    ".ex": "Elixir",
    ".exs": "Elixir",
    ".hs": "Haskell",
    ".scala": "Scala",
    ".sh": "Shell",
    ".brs": "BrightScript",
}

# Package manager detection: filename -> (manager_name, associated_language)
PACKAGE_MANAGERS = {
    "package.json": ("npm/yarn", "JavaScript/TypeScript"),
    "requirements.txt": ("pip", "Python"),
    "pyproject.toml": ("pip/poetry", "Python"),
    "setup.py": ("setuptools", "Python"),
    "Pipfile": ("pipenv", "Python"),
    "Cargo.toml": ("cargo", "Rust"),
    "go.mod": ("go modules", "Go"),
    "composer.json": ("composer", "PHP"),
    "Gemfile": ("bundler", "Ruby"),
    "pom.xml": ("maven", "Java"),
    "build.gradle": ("gradle", "Java/Kotlin"),
    "build.gradle.kts": ("gradle", "Kotlin"),
    "mix.exs": ("mix", "Elixir"),
    "stack.yaml": ("stack", "Haskell"),
    "cabal.project": ("cabal", "Haskell"),
    "Package.swift": ("spm", "Swift"),
    "deno.json": ("deno", "TypeScript"),
    "bun.lockb": ("bun", "JavaScript/TypeScript"),
}

# Test framework detection: filename or marker -> framework name
TEST_FRAMEWORKS = {
    "pytest.ini": "pytest",
    "setup.cfg": "pytest",  # often contains [tool:pytest]
    "conftest.py": "pytest",
    "jest.config.js": "jest",
    "jest.config.ts": "jest",
    "vitest.config.ts": "vitest",
    "vitest.config.js": "vitest",
    ".mocharc.yml": "mocha",
    "karma.conf.js": "karma",
    "phpunit.xml": "phpunit",
    "phpunit.xml.dist": "phpunit",
}

# Build system detection
BUILD_SYSTEMS = {
    "Makefile": "make",
    "CMakeLists.txt": "cmake",
    "Dockerfile": "docker",
    "docker-compose.yml": "docker-compose",
    "docker-compose.yaml": "docker-compose",
    "Taskfile.yml": "task",
    "justfile": "just",
    "Rakefile": "rake",
    "webpack.config.js": "webpack",
    "vite.config.ts": "vite",
    "vite.config.js": "vite",
    "rollup.config.js": "rollup",
    "turbo.json": "turborepo",
    "nx.json": "nx",
}


@dataclass
class ProjectInfo:
    """Detected project information."""
    cwd: str = ""
    languages: list[str] = field(default_factory=list)
    primary_language: str = ""
    package_managers: list[str] = field(default_factory=list)
    is_git_repo: bool = False
    test_frameworks: list[str] = field(default_factory=list)
    build_systems: list[str] = field(default_factory=list)
    has_readme: bool = False
    has_ci: bool = False

    def to_prompt_section(self) -> str:
        """Format project info as a system prompt section."""
        lines = ["# Detected Project Info"]
        if self.primary_language:
            lines.append(f"Primary language: {self.primary_language}")
        if self.languages:
            lines.append(f"Languages: {', '.join(self.languages)}")
        if self.package_managers:
            lines.append(f"Package managers: {', '.join(self.package_managers)}")
        if self.is_git_repo:
            lines.append("Git repository: yes")
        if self.test_frameworks:
            lines.append(f"Test frameworks: {', '.join(self.test_frameworks)}")
        if self.build_systems:
            lines.append(f"Build systems: {', '.join(self.build_systems)}")
        return "\n".join(lines)


def _dir_hash(cwd: str) -> str:
    """Stable hash for a directory path."""
    return hashlib.sha256(cwd.encode()).hexdigest()[:12]


def _cache_path(cwd: str) -> Path:
    return PROJECTS_DIR / f"{_dir_hash(cwd)}.json"


def scan_project(cwd: str) -> ProjectInfo:
    """Scan a directory to detect project type, language, tooling, etc."""
    root = Path(cwd)
    info = ProjectInfo(cwd=cwd)

    # Git repo?
    info.is_git_repo = (root / ".git").exists()

    # README
    info.has_readme = any((root / f).exists() for f in ("README.md", "README.rst", "README.txt", "README"))

    # CI
    info.has_ci = any((root / p).exists() for p in (".github/workflows", ".gitlab-ci.yml", ".circleci", "Jenkinsfile"))

    # Scan top-level + one level down for marker files
    scan_dirs = [root]
    try:
        scan_dirs.extend(d for d in root.iterdir() if d.is_dir() and not d.name.startswith(".") and d.name not in ("node_modules", "__pycache__", ".git", "venv", ".venv", "dist", "build", "target"))
    except PermissionError:
        pass

    # Count file extensions for language detection
    ext_counts: dict[str, int] = {}
    for d in scan_dirs:
        try:
            for f in d.iterdir():
                if f.is_file():
                    ext = f.suffix.lower()
                    if ext in LANG_EXTENSIONS:
                        ext_counts[ext] = ext_counts.get(ext, 0) + 1
        except PermissionError:
            continue

    # Determine languages from extensions
    lang_set: set[str] = set()
    for ext, count in ext_counts.items():
        lang_set.add(LANG_EXTENSIONS[ext])
    info.languages = sorted(lang_set)

    # Primary language = most files
    if ext_counts:
        top_ext = max(ext_counts, key=lambda e: ext_counts[e])
        info.primary_language = LANG_EXTENSIONS[top_ext]

    # Package managers
    pm_set: set[str] = set()
    for filename, (manager, _lang) in PACKAGE_MANAGERS.items():
        if (root / filename).exists():
            pm_set.add(manager)
    info.package_managers = sorted(pm_set)

    # Test frameworks
    tf_set: set[str] = set()
    for filename, framework in TEST_FRAMEWORKS.items():
        if (root / filename).exists():
            tf_set.add(framework)
    # Also check pyproject.toml for pytest
    pyproject = root / "pyproject.toml"
    if pyproject.exists():
        try:
            content = pyproject.read_text(encoding="utf-8", errors="replace")
            if "pytest" in content:
                tf_set.add("pytest")
        except Exception:
            pass
    # Check package.json for jest/vitest
    pkg_json = root / "package.json"
    if pkg_json.exists():
        try:
            pkg = json.loads(pkg_json.read_text(encoding="utf-8"))
            dev_deps = {**pkg.get("devDependencies", {}), **pkg.get("dependencies", {})}
            if "jest" in dev_deps:
                tf_set.add("jest")
            if "vitest" in dev_deps:
                tf_set.add("vitest")
            if "mocha" in dev_deps:
                tf_set.add("mocha")
            if "playwright" in dev_deps or "@playwright/test" in dev_deps:
                tf_set.add("playwright")
        except Exception:
            pass
    # Cargo.toml always has cargo test
    if (root / "Cargo.toml").exists():
        tf_set.add("cargo test")
    if (root / "go.mod").exists():
        tf_set.add("go test")
    info.test_frameworks = sorted(tf_set)

    # Build systems
    bs_set: set[str] = set()
    for filename, system in BUILD_SYSTEMS.items():
        if (root / filename).exists():
            bs_set.add(system)
    info.build_systems = sorted(bs_set)

    # Cache result
    _save_cache(cwd, info)

    return info


def _save_cache(cwd: str, info: ProjectInfo):
    """Save project info to cache."""
    ensure_dirs()
    PROJECTS_DIR.mkdir(exist_ok=True)
    path = _cache_path(cwd)
    path.write_text(json.dumps(asdict(info), indent=2), encoding="utf-8")


def load_cached_project(cwd: str) -> ProjectInfo | None:
    """Load cached project info if it exists."""
    path = _cache_path(cwd)
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return ProjectInfo(**data)
    except Exception:
        return None
