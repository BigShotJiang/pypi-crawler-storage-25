"""Watch mode — re-run a command when source files change."""

import os
import time
import subprocess
import threading
from datetime import datetime


# Watched extensions
WATCH_EXTENSIONS = {".py", ".js", ".ts", ".rs", ".go", ".jsx", ".tsx"}

# Polling interval in seconds
POLL_INTERVAL = 2.0


class FileWatcher:
    """Polls the working directory for file changes and re-runs a command."""

    def __init__(self, command: str, directory: str | None = None):
        self.command = command
        self.directory = directory or os.getcwd()
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._last_run: str | None = None
        self._run_count = 0
        self._snapshots: dict[str, float] = {}  # path -> mtime

    @property
    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    @property
    def status(self) -> str:
        if not self.is_running:
            return "stopped"
        return (
            f"watching {self.directory} | command: {self.command} | "
            f"runs: {self._run_count} | last: {self._last_run or 'never'}"
        )

    def _scan_files(self) -> dict[str, float]:
        """Walk directory and collect mtime for watched file types."""
        result = {}
        try:
            for root, dirs, files in os.walk(self.directory):
                # Skip hidden dirs, node_modules, __pycache__, .git, etc.
                dirs[:] = [
                    d for d in dirs
                    if not d.startswith(".")
                    and d not in ("node_modules", "__pycache__", ".git", "venv", ".venv", "target", "build", "dist")
                ]
                for f in files:
                    _, ext = os.path.splitext(f)
                    if ext in WATCH_EXTENSIONS:
                        full = os.path.join(root, f)
                        try:
                            result[full] = os.path.getmtime(full)
                        except OSError:
                            pass
        except OSError:
            pass
        return result

    def _detect_changes(self) -> list[str]:
        """Compare current snapshot with previous. Return changed file paths."""
        current = self._scan_files()
        changed = []

        for path, mtime in current.items():
            old_mtime = self._snapshots.get(path)
            if old_mtime is None or mtime > old_mtime:
                changed.append(path)

        # Detect deleted files too (not strictly needed for re-run, but good to track)
        self._snapshots = current
        return changed

    def _run_command(self, changed_files: list[str]):
        """Execute the watched command and print output with timestamp."""
        now = datetime.now().strftime("%H:%M:%S")
        self._last_run = now
        self._run_count += 1

        # Show which files triggered the run
        short_files = [os.path.basename(f) for f in changed_files[:5]]
        extra = f" (+{len(changed_files) - 5} more)" if len(changed_files) > 5 else ""
        trigger_str = ", ".join(short_files) + extra

        print(f"\n\033[38;5;63m[{now}]\033[0m \033[2mchanged: {trigger_str}\033[0m")
        print(f"\033[38;5;63m[{now}]\033[0m \033[1m$ {self.command}\033[0m")

        try:
            result = subprocess.run(
                self.command,
                shell=True,
                capture_output=False,
                text=True,
                timeout=120,
                cwd=self.directory,
                env={**os.environ, "TERM": "dumb"},
            )
            if result.returncode != 0:
                print(f"\033[38;5;63m[{now}]\033[0m \033[31mexit code: {result.returncode}\033[0m")
            else:
                print(f"\033[38;5;63m[{now}]\033[0m \033[32mdone\033[0m")
        except subprocess.TimeoutExpired:
            print(f"\033[38;5;63m[{now}]\033[0m \033[31mtimed out after 120s\033[0m")
        except Exception as e:
            print(f"\033[38;5;63m[{now}]\033[0m \033[31merror: {e}\033[0m")

    def _poll_loop(self):
        """Main polling loop, runs in background thread."""
        # Take initial snapshot
        self._snapshots = self._scan_files()

        while not self._stop_event.is_set():
            self._stop_event.wait(POLL_INTERVAL)
            if self._stop_event.is_set():
                break

            changed = self._detect_changes()
            if changed:
                self._run_command(changed)

    def start(self):
        """Start watching in a background thread."""
        if self.is_running:
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._thread.start()

    def stop(self):
        """Stop watching."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
            self._thread = None


# ── Singleton watcher ────────────────────────────────────────────────

_active_watcher: FileWatcher | None = None


def get_watcher() -> FileWatcher | None:
    return _active_watcher


def start_watch(command: str, directory: str | None = None) -> FileWatcher:
    """Start (or replace) the active file watcher."""
    global _active_watcher
    if _active_watcher and _active_watcher.is_running:
        _active_watcher.stop()
    _active_watcher = FileWatcher(command, directory)
    _active_watcher.start()
    return _active_watcher


def stop_watch() -> bool:
    """Stop the active watcher. Returns True if one was running."""
    global _active_watcher
    if _active_watcher and _active_watcher.is_running:
        _active_watcher.stop()
        _active_watcher = None
        return True
    _active_watcher = None
    return False
