"""Error/stack trace explanation — auto-detect and explain errors."""

import re
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text
from rich.markdown import Markdown

from .theme import VAAL_BLUE, VAAL_RED, VAAL_CYAN, VAAL_DIM, VAAL_GREEN, VAAL_THEME


# Patterns for detecting stack traces in output
_TRACEBACK_PATTERNS = [
    # Python traceback
    re.compile(r'Traceback \(most recent call last\):', re.MULTILINE),
    re.compile(r'^\s*File ".+", line \d+', re.MULTILINE),
    # Node.js / JavaScript
    re.compile(r'^\s+at .+ \(.+:\d+:\d+\)', re.MULTILINE),
    re.compile(r'^(?:TypeError|ReferenceError|SyntaxError|RangeError|Error):.*', re.MULTILINE),
    # Rust
    re.compile(r"^thread '.+' panicked at", re.MULTILINE),
    # Go
    re.compile(r'^goroutine \d+ \[.+\]:', re.MULTILINE),
    # Java / JVM
    re.compile(r'^\s+at [a-zA-Z0-9_.]+\(.+\.java:\d+\)', re.MULTILINE),
    re.compile(r'^Exception in thread ".+"', re.MULTILINE),
    # C/C++ segfault
    re.compile(r'Segmentation fault', re.MULTILINE),
    # Generic error patterns
    re.compile(r'^ERROR:', re.MULTILINE | re.IGNORECASE),
    re.compile(r'^FATAL:', re.MULTILINE | re.IGNORECASE),
    # Compiler errors
    re.compile(r'^.+:\d+:\d+: error:', re.MULTILINE),
    # Cargo / rustc
    re.compile(r'^error\[\w+\]:', re.MULTILINE),
]

# Patterns to extract file:line references
_FILE_LINE_PATTERNS = [
    re.compile(r'File "(.+?)", line (\d+)'),              # Python
    re.compile(r'at .+? \((.+?):(\d+):\d+\)'),            # Node.js
    re.compile(r'(.+?\.(?:java|kt)):(\d+)'),               # Java/Kotlin
    re.compile(r'(.+?):(\d+):\d+: error:'),                # GCC/Clang
    re.compile(r'(.+?\.rs):(\d+):\d+'),                    # Rust
    re.compile(r'(.+?\.go):(\d+)'),                        # Go
]


def detect_error(output: str) -> bool:
    """Check if output contains a stack trace or error."""
    if not output:
        return False
    for pattern in _TRACEBACK_PATTERNS:
        if pattern.search(output):
            return True
    return False


def extract_error_context(output: str) -> dict:
    """Extract structured info from an error output."""
    info = {
        "language": "unknown",
        "error_type": "",
        "error_message": "",
        "file_references": [],
        "raw": output,
    }

    # Detect language and extract details
    if re.search(r'Traceback \(most recent call last\):', output):
        info["language"] = "python"
        # Get the last line which is usually the exception
        lines = output.strip().splitlines()
        for line in reversed(lines):
            line = line.strip()
            if line and not line.startswith("File ") and not line.startswith("Traceback"):
                if ":" in line:
                    parts = line.split(":", 1)
                    info["error_type"] = parts[0].strip()
                    info["error_message"] = parts[1].strip()
                else:
                    info["error_message"] = line
                break

    elif re.search(r'^\s+at .+ \(.+:\d+:\d+\)', output, re.MULTILINE):
        info["language"] = "javascript/node.js"
        lines = output.strip().splitlines()
        for line in lines:
            line = line.strip()
            if re.match(r'^(TypeError|ReferenceError|SyntaxError|RangeError|Error):', line):
                parts = line.split(":", 1)
                info["error_type"] = parts[0].strip()
                info["error_message"] = parts[1].strip()
                break

    elif re.search(r"^thread '.+' panicked at", output, re.MULTILINE):
        info["language"] = "rust"
        m = re.search(r"panicked at '(.+?)'", output)
        if m:
            info["error_message"] = m.group(1)
            info["error_type"] = "panic"

    elif re.search(r'^goroutine \d+ \[.+\]:', output, re.MULTILINE):
        info["language"] = "go"
        info["error_type"] = "goroutine panic"

    elif re.search(r'^\s+at [a-zA-Z0-9_.]+\(.+\.java:\d+\)', output, re.MULTILINE):
        info["language"] = "java"
        lines = output.strip().splitlines()
        for line in lines:
            line = line.strip()
            if re.match(r'^(Exception|Error|java\.\w+)', line):
                parts = line.split(":", 1)
                info["error_type"] = parts[0].strip()
                info["error_message"] = parts[1].strip() if len(parts) > 1 else ""
                break

    elif re.search(r'^error\[\w+\]:', output, re.MULTILINE):
        info["language"] = "rust"
        info["error_type"] = "compiler error"

    elif re.search(r'^.+:\d+:\d+: error:', output, re.MULTILINE):
        info["language"] = "c/c++"
        info["error_type"] = "compiler error"

    # Extract file:line references
    for pattern in _FILE_LINE_PATTERNS:
        for match in pattern.finditer(output):
            ref = {"file": match.group(1), "line": int(match.group(2))}
            if ref not in info["file_references"]:
                info["file_references"].append(ref)

    return info


def format_error_explanation(context: dict, explanation: str) -> str:
    """Format the error explanation for display."""
    lines = []

    # Header
    lang = context["language"]
    err_type = context["error_type"]
    err_msg = context["error_message"]

    if err_type:
        lines.append(f"**{err_type}**: {err_msg}" if err_msg else f"**{err_type}**")
    elif err_msg:
        lines.append(f"**Error**: {err_msg}")

    if lang != "unknown":
        lines.append(f"*Language*: {lang}")

    # File references
    if context["file_references"]:
        lines.append("")
        lines.append("**Locations:**")
        for ref in context["file_references"][:5]:
            lines.append(f"- `{ref['file']}:{ref['line']}`")

    # Explanation from model
    if explanation:
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append(explanation)

    return "\n".join(lines)


def build_explain_prompt(error_output: str) -> str:
    """Build the prompt to send to the model for error explanation."""
    context = extract_error_context(error_output)

    prompt = f"""Analyze this error output and explain:
1. **What went wrong** — the root cause in plain English
2. **Why** — what conditions or code caused this
3. **How to fix** — specific actionable steps
4. **Relevant location** — which file:line to look at

Be concise. Use bullet points. Do not repeat the full stack trace.

```
{error_output[-3000:]}
```"""

    return prompt


def print_error_panel(console: Console, error_output: str, explanation: Optional[str] = None):
    """Print a formatted error explanation panel."""
    context = extract_error_context(error_output)

    header = Text()
    header.append("Error Detected", style=f"bold {VAAL_RED}")
    if context["language"] != "unknown":
        header.append(f" ({context['language']})", style=VAAL_DIM)

    body_lines = []

    if context["error_type"]:
        body_lines.append(f"[bold {VAAL_RED}]{context['error_type']}[/]: {context['error_message']}")
    elif context["error_message"]:
        body_lines.append(f"[bold {VAAL_RED}]Error[/]: {context['error_message']}")

    if context["file_references"]:
        body_lines.append("")
        for ref in context["file_references"][:5]:
            body_lines.append(f"  [{VAAL_CYAN}]{ref['file']}:{ref['line']}[/]")

    if explanation:
        body_lines.append("")
        body_lines.append(f"[{VAAL_DIM}]{'─' * 40}[/]")
        body_lines.append("")
        body_lines.append(explanation)

    body = "\n".join(body_lines)

    console.print()
    console.print(Panel(
        body,
        title=header,
        border_style=VAAL_RED,
        padding=(1, 2),
    ))
    console.print()
