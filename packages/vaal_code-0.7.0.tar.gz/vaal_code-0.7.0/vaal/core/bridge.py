"""Bridge session — connect to Anthropic's code session API like Claude Code does.

Flow:
1. POST /v1/code/sessions → create session, get session_id
2. POST /v1/code/sessions/{id}/bridge → register as worker, get worker_jwt + api_base_url
3. Use worker_jwt with Anthropic SDK-style calls to /v1/messages on api_base_url
4. Different rate limit bucket than direct API — uses Max subscription limits
"""

import json
import time
import httpx

from .config import VAAL_DIR

BRIDGE_CACHE = VAAL_DIR / "bridge_session.json"
API_BASE = "https://api.anthropic.com"
ANTHROPIC_VERSION = "2023-06-01"


class BridgeSession:
    """Manages a code session with Anthropic's bridge API."""

    def __init__(self):
        self.session_id: str = ""
        self.worker_jwt: str = ""
        self.api_base_url: str = ""
        self.worker_epoch: int = 0
        self.jwt_expires_at: float = 0.0
        self._load_cached()

    def _oauth_headers(self, token: str) -> dict:
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "anthropic-version": ANTHROPIC_VERSION,
        }

    def _get_oauth_token(self) -> str:
        """Get fresh OAuth token."""
        from .providers import get_claude_max_token
        return get_claude_max_token()

    def _load_cached(self):
        """Load cached session from disk."""
        if BRIDGE_CACHE.exists():
            try:
                data = json.loads(BRIDGE_CACHE.read_text(encoding="utf-8"))
                self.session_id = data.get("session_id", "")
                self.worker_jwt = data.get("worker_jwt", "")
                self.api_base_url = data.get("api_base_url", "")
                self.worker_epoch = data.get("worker_epoch", 0)
                self.jwt_expires_at = data.get("jwt_expires_at", 0.0)
            except Exception:
                pass

    def _save_cache(self):
        """Cache session to disk."""
        VAAL_DIR.mkdir(exist_ok=True)
        BRIDGE_CACHE.write_text(json.dumps({
            "session_id": self.session_id,
            "worker_jwt": self.worker_jwt,
            "api_base_url": self.api_base_url,
            "worker_epoch": self.worker_epoch,
            "jwt_expires_at": self.jwt_expires_at,
        }, indent=2), encoding="utf-8")

    @property
    def is_valid(self) -> bool:
        """Check if we have a valid, non-expired session."""
        if not self.session_id or not self.worker_jwt:
            return False
        if self.jwt_expires_at and time.time() > self.jwt_expires_at - 60:
            return False
        return True

    def create_session(self) -> bool:
        """Create a new code session."""
        token = self._get_oauth_token()
        if not token:
            return False

        try:
            r = httpx.post(
                f"{API_BASE}/v1/code/sessions",
                headers=self._oauth_headers(token),
                json={"title": "vaal", "bridge": {}},
                timeout=15,
            )
            if r.status_code not in (200, 201):
                return False

            data = r.json()
            session = data.get("session", {})
            sid = session.get("id", "")
            if not sid:
                return False

            self.session_id = sid
            return True
        except Exception:
            return False

    def register_bridge(self) -> bool:
        """Register as bridge worker to get worker_jwt."""
        if not self.session_id:
            return False

        token = self._get_oauth_token()
        if not token:
            return False

        try:
            r = httpx.post(
                f"{API_BASE}/v1/code/sessions/{self.session_id}/bridge",
                headers=self._oauth_headers(token),
                json={},
                timeout=15,
            )
            if r.status_code != 200:
                return False

            data = r.json()
            self.worker_jwt = data.get("worker_jwt", "")
            self.api_base_url = data.get("api_base_url", "")
            expires_in = data.get("expires_in", 3600)
            self.jwt_expires_at = time.time() + expires_in
            raw_epoch = data.get("worker_epoch", 0)
            self.worker_epoch = int(raw_epoch) if isinstance(raw_epoch, (int, float, str)) else 0

            if not self.worker_jwt or not self.api_base_url:
                return False

            self._save_cache()
            return True
        except Exception:
            return False

    def connect(self) -> bool:
        """Full connection: create session + register bridge."""
        # Try reusing cached session first
        if self.is_valid:
            return True

        # Try re-registering with existing session
        if self.session_id:
            if self.register_bridge():
                return True

        # Create fresh session
        if not self.create_session():
            return False
        return self.register_bridge()

    def refresh_if_needed(self) -> bool:
        """Refresh the worker JWT if expired."""
        if self.is_valid:
            return True
        return self.connect()

    def get_api_headers(self) -> dict:
        """Get headers for making API calls through the bridge."""
        return {
            "Authorization": f"Bearer {self.worker_jwt}",
            "anthropic-version": ANTHROPIC_VERSION,
            "anthropic-beta": "oauth-2025-04-20,claude-code-20250219",
            "Content-Type": "application/json",
            "x-app": "cli",
        }

    def get_api_url(self) -> str:
        """Get the base URL for API calls."""
        return self.api_base_url or API_BASE


# Singleton
_bridge: BridgeSession | None = None


def get_bridge() -> BridgeSession:
    global _bridge
    if _bridge is None:
        _bridge = BridgeSession()
    return _bridge
