"""Vim mode toggle for Vaal REPL."""


class VimMode:
    """Tracks vim mode state. Not a full vim implementation --
    just a toggle flag that shows [VIM] in the prompt."""

    def __init__(self, enabled: bool = False):
        self._enabled = enabled

    @property
    def enabled(self) -> bool:
        return self._enabled

    def toggle(self) -> bool:
        """Toggle vim mode. Returns the new state."""
        self._enabled = not self._enabled
        return self._enabled

    def enable(self):
        self._enabled = True

    def disable(self):
        self._enabled = False

    def prompt_indicator(self) -> str:
        """Return the indicator string to prepend to the prompt, or empty."""
        if self._enabled:
            return "[VIM] "
        return ""
