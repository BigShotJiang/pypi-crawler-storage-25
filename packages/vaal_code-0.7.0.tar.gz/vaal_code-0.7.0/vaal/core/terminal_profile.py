"""Auto-setup Windows Terminal profile with Vaal Orb icon and theme."""

import json
import os
import sys
from pathlib import Path

VAAL_PROFILE_GUID = "{d3adb33f-7aa1-4000-8000-c07707e0d000}"
VAAL_PROFILE_NAME = "corrupted"


def get_wt_settings_path() -> Path | None:
    """Find Windows Terminal settings.json."""
    candidates = [
        Path(os.environ.get("LOCALAPPDATA", "")) / "Packages" / "Microsoft.WindowsTerminal_8wekyb3d8bbwe" / "LocalState" / "settings.json",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows Terminal" / "settings.json",
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def get_icon_path() -> str:
    return str(Path.home() / ".vaal" / "icon.ico").replace("\\", "/")


def get_vaal_profile() -> dict:
    """Build the Vaal terminal profile dict."""
    icon = get_icon_path()
    python_exe = sys.executable.replace("\\", "/")

    return {
        "guid": VAAL_PROFILE_GUID,
        "name": VAAL_PROFILE_NAME,
        "commandline": f'"{python_exe}" -m vaal',
        "startingDirectory": "%USERPROFILE%\\Desktop\\projects",
        "icon": icon,
        "colorScheme": "Vaal Orb",
        "cursorShape": "filledBox",
        "font": {
            "face": "Cascadia Code",
            "size": 12,
        },
        "padding": "8",
        "hidden": False,
    }


def get_vaal_color_scheme() -> dict:
    """Build the Vaal Orb color scheme for Windows Terminal."""
    return {
        "name": "Vaal Orb",
        "background": "#0A0008",
        "foreground": "#D4C4C8",
        "cursorColor": "#BF1F3E",
        "selectionBackground": "#3A1030",
        "black": "#0A0008",
        "red": "#BF1F3E",
        "green": "#6A3FA0",
        "yellow": "#8B1A4A",
        "blue": "#4A1A8B",
        "purple": "#9B30FF",
        "cyan": "#5769F7",
        "white": "#D4C4C8",
        "brightBlack": "#555555",
        "brightRed": "#FF4466",
        "brightGreen": "#9B6FD0",
        "brightYellow": "#BF4070",
        "brightBlue": "#7B5FBF",
        "brightPurple": "#C4A0FF",
        "brightCyan": "#7B8BF9",
        "brightWhite": "#FFFFFF",
    }


def install_profile() -> tuple[bool, str]:
    """Install or update the Vaal profile in Windows Terminal settings.
    Returns (success, message)."""
    settings_path = get_wt_settings_path()
    if not settings_path:
        return False, "Windows Terminal settings.json not found"

    try:
        with open(settings_path, "r", encoding="utf-8") as f:
            # Windows Terminal settings can have comments — strip them
            content = f.read()
            # Simple comment stripping (// comments)
            lines = []
            for line in content.splitlines():
                stripped = line.lstrip()
                if stripped.startswith("//"):
                    continue
                lines.append(line)
            settings = json.loads("\n".join(lines))
    except Exception as e:
        return False, f"Failed to read settings: {e}"

    # Add color scheme
    schemes = settings.setdefault("schemes", [])
    scheme_names = [s.get("name") for s in schemes]
    vaal_scheme = get_vaal_color_scheme()
    if "Vaal Orb" in scheme_names:
        idx = scheme_names.index("Vaal Orb")
        schemes[idx] = vaal_scheme
    else:
        schemes.append(vaal_scheme)

    # Add profile
    profiles = settings.setdefault("profiles", {})
    profile_list = profiles.setdefault("list", [])
    profile_guids = [p.get("guid") for p in profile_list]
    vaal_profile = get_vaal_profile()

    if VAAL_PROFILE_GUID in profile_guids:
        idx = profile_guids.index(VAAL_PROFILE_GUID)
        profile_list[idx] = vaal_profile
    else:
        # Insert at the beginning so it shows first
        profile_list.insert(0, vaal_profile)

    # Add keybinding: Ctrl+V sends raw \x16 to app instead of terminal paste
    # This lets vaal handle clipboard images via Ctrl+V
    # Windows Terminal uses "keybindings" in older versions, "actions" in newer
    actions = settings.setdefault("actions", [])

    # Remove any existing sendInput for \x16 (from previous installs)
    actions[:] = [
        a for a in actions
        if not (isinstance(a, dict) and isinstance(a.get("command"), dict)
                and a["command"].get("action") == "sendInput"
                and a["command"].get("input") == "\x16")
    ]

    # Add the Ctrl+V passthrough with both command and keys at top level
    actions.append({
        "command": {"action": "sendInput", "input": "\u0016"},
        "keys": "ctrl+v"
    })

    # Also check/add in legacy keybindings array
    keybindings = settings.get("keybindings", None)
    if isinstance(keybindings, list):
        keybindings[:] = [k for k in keybindings if k.get("keys", "").lower() != "ctrl+v"]
        keybindings.append({"command": {"action": "sendInput", "input": "\u0016"}, "keys": "ctrl+v"})

    # Write back
    try:
        with open(settings_path, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=4)
        return True, f"Profile installed! Look for '{VAAL_PROFILE_NAME}' in Windows Terminal"
    except Exception as e:
        return False, f"Failed to write settings: {e}"


def uninstall_profile() -> tuple[bool, str]:
    """Remove the Vaal profile from Windows Terminal."""
    settings_path = get_wt_settings_path()
    if not settings_path:
        return False, "Windows Terminal settings.json not found"

    try:
        with open(settings_path, "r", encoding="utf-8") as f:
            content = f.read()
            lines = [l for l in content.splitlines() if not l.lstrip().startswith("//")]
            settings = json.loads("\n".join(lines))

        # Remove profile
        profiles = settings.get("profiles", {}).get("list", [])
        settings["profiles"]["list"] = [p for p in profiles if p.get("guid") != VAAL_PROFILE_GUID]

        # Remove scheme
        schemes = settings.get("schemes", [])
        settings["schemes"] = [s for s in schemes if s.get("name") != "Vaal Orb"]

        with open(settings_path, "w", encoding="utf-8") as f:
            json.dump(settings, f, indent=4)
        return True, "Profile removed"
    except Exception as e:
        return False, f"Failed: {e}"
