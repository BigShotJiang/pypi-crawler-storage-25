"""Desktop notifications — cross-platform toast/alert system."""

import os
import sys
import time
import subprocess
import threading
from dataclasses import dataclass


@dataclass
class NotificationConfig:
    enabled: bool = True
    auto_threshold_seconds: float = 30.0  # Auto-notify when response takes longer


class NotificationManager:
    """Cross-platform desktop notification manager.

    Sends notifications when:
    - Long-running tasks complete (> threshold seconds)
    - Sub-agents finish
    - Scheduled tasks trigger
    """

    def __init__(self):
        self.config = NotificationConfig()
        self._platform = sys.platform
        self._has_win10toast: bool | None = None

    # ── Public API ────────────────────────────────────────────────────

    def toggle(self, state: str | None = None) -> str:
        """Toggle notifications on/off.

        Args:
            state: "on", "off", or None to toggle
        """
        if state is None:
            self.config.enabled = not self.config.enabled
        elif state.lower() == "on":
            self.config.enabled = True
        elif state.lower() == "off":
            self.config.enabled = False
        else:
            return f"Unknown state: {state}. Use /notify on|off"
        status = "enabled" if self.config.enabled else "disabled"
        return f"Desktop notifications {status}."

    def notify(self, title: str, message: str, urgent: bool = False):
        """Send a desktop notification (non-blocking)."""
        if not self.config.enabled:
            return
        thread = threading.Thread(
            target=self._send, args=(title, message, urgent), daemon=True
        )
        thread.start()

    def notify_if_slow(self, elapsed: float, description: str = "Model response"):
        """Send notification if elapsed time exceeds threshold."""
        if elapsed >= self.config.auto_threshold_seconds:
            minutes = elapsed / 60
            if minutes >= 1:
                time_str = f"{minutes:.1f}m"
            else:
                time_str = f"{elapsed:.0f}s"
            self.notify(
                "Vaal - Task Complete",
                f"{description} finished ({time_str})",
            )

    def notify_agent_complete(self, agent_id: str, label: str, elapsed: float):
        """Notify when a sub-agent finishes."""
        time_str = f"{elapsed:.0f}s" if elapsed < 60 else f"{elapsed/60:.1f}m"
        self.notify(
            "Vaal - Agent Complete",
            f"Agent {agent_id} ({label}) finished in {time_str}",
        )

    def notify_task_trigger(self, task_name: str):
        """Notify when a scheduled task triggers."""
        self.notify(
            "Vaal - Task Triggered",
            f"Scheduled task: {task_name}",
        )

    def handle_command(self, arg: str) -> str:
        """Handle /notify command.

        /notify         - show status / toggle
        /notify on      - enable
        /notify off     - disable
        """
        arg = arg.strip().lower()
        if not arg:
            status = "enabled" if self.config.enabled else "disabled"
            return (
                f"Notifications: {status} "
                f"(auto-notify after {self.config.auto_threshold_seconds:.0f}s). "
                f"Use /notify on|off to toggle."
            )
        return self.toggle(arg)

    # ── Platform-specific dispatch ────────────────────────────────────

    def _send(self, title: str, message: str, urgent: bool = False):
        """Dispatch notification to OS-specific implementation."""
        try:
            if self._platform == "win32":
                self._send_windows(title, message, urgent)
            elif self._platform == "darwin":
                self._send_macos(title, message)
            else:
                self._send_linux(title, message, urgent)
        except Exception:
            # Notifications are best-effort; never crash the app
            pass

    def _send_windows(self, title: str, message: str, urgent: bool):
        """Windows notification: try win10toast, then PowerShell toast, then ctypes MessageBox."""
        # Attempt 1: win10toast (nicest UX)
        if self._has_win10toast is None:
            try:
                from win10toast import ToastNotifier
                self._has_win10toast = True
            except ImportError:
                self._has_win10toast = False

        if self._has_win10toast:
            try:
                from win10toast import ToastNotifier
                toaster = ToastNotifier()
                toaster.show_toast(
                    title, message,
                    duration=5,
                    threaded=True,
                )
                return
            except Exception:
                pass

        # Attempt 2: PowerShell toast notification
        try:
            ps_script = (
                "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, "
                "ContentType = WindowsRuntime] | Out-Null; "
                "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom, "
                "ContentType = WindowsRuntime] | Out-Null; "
                "$template = '<toast><visual><binding template=\"ToastGeneric\">"
                f"<text>{_escape_xml(title)}</text>"
                f"<text>{_escape_xml(message)}</text>"
                "</binding></visual></toast>'; "
                "$xml = New-Object Windows.Data.Xml.Dom.XmlDocument; "
                "$xml.LoadXml($template); "
                "$toast = [Windows.UI.Notifications.ToastNotification]::new($xml); "
                "[Windows.UI.Notifications.ToastNotificationManager]"
                "::CreateToastNotifier('Vaal').Show($toast)"
            )
            subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_script],
                capture_output=True, timeout=10,
            )
            return
        except Exception:
            pass

        # Attempt 3: ctypes MessageBox (blocking, so run in thread)
        if urgent:
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(
                    0, message, title, 0x40  # MB_ICONINFORMATION
                )
            except Exception:
                pass

    def _send_macos(self, title: str, message: str):
        """macOS notification via osascript."""
        script = (
            f'display notification "{_escape_applescript(message)}" '
            f'with title "{_escape_applescript(title)}"'
        )
        subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, timeout=10,
        )

    def _send_linux(self, title: str, message: str, urgent: bool):
        """Linux notification via notify-send."""
        cmd = ["notify-send"]
        if urgent:
            cmd.extend(["-u", "critical"])
        cmd.extend([title, message])
        subprocess.run(cmd, capture_output=True, timeout=10)


def _escape_xml(s: str) -> str:
    """Escape special characters for XML."""
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )


def _escape_applescript(s: str) -> str:
    """Escape special characters for AppleScript strings."""
    return s.replace("\\", "\\\\").replace('"', '\\"')


# ── Module-level singleton ────────────────────────────────────────────

_manager: NotificationManager | None = None


def get_notification_manager() -> NotificationManager:
    """Get the global notification manager singleton."""
    global _manager
    if _manager is None:
        _manager = NotificationManager()
    return _manager
