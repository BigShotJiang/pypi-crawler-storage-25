"""Clipboard integration — copy/paste with pyperclip fallback to platform commands."""

import subprocess
import sys


def copy_to_clipboard(text: str) -> bool:
    """Copy text to system clipboard. Returns True on success."""
    # Try pyperclip first
    try:
        import pyperclip
        pyperclip.copy(text)
        return True
    except (ImportError, Exception):
        pass

    # Platform fallback
    try:
        if sys.platform == "darwin":
            proc = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-8"))
            return proc.returncode == 0
        elif sys.platform == "win32":
            proc = subprocess.Popen(["clip.exe"], stdin=subprocess.PIPE)
            proc.communicate(text.encode("utf-16le"))
            return proc.returncode == 0
        else:
            # Linux — try xclip, then xsel, then wl-copy (Wayland)
            for cmd in (["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"], ["wl-copy"]):
                try:
                    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
                    proc.communicate(text.encode("utf-8"))
                    if proc.returncode == 0:
                        return True
                except FileNotFoundError:
                    continue
    except Exception:
        pass

    return False


def paste_from_clipboard() -> str | None:
    """Read text from system clipboard. Returns None on failure."""
    # Try pyperclip first
    try:
        import pyperclip
        return pyperclip.paste()
    except (ImportError, Exception):
        pass

    # Platform fallback
    try:
        if sys.platform == "darwin":
            result = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                return result.stdout
        elif sys.platform == "win32":
            result = subprocess.run(
                ["powershell", "-Command", "Get-Clipboard"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.rstrip("\r\n")
        else:
            for cmd in (["xclip", "-selection", "clipboard", "-o"], ["xsel", "--clipboard", "--output"], ["wl-paste"]):
                try:
                    result = subprocess.run(cmd, capture_output=True, text=True, timeout=5)
                    if result.returncode == 0:
                        return result.stdout
                except FileNotFoundError:
                    continue
    except Exception:
        pass

    return None
