"""Interactive TUI screens — arrow key navigation, selection, progress."""

import sys
import os
import subprocess
import time
from dataclasses import dataclass

from .theme import VAAL_BLUE, VAAL_CYAN, VAAL_GREEN, VAAL_YELLOW, VAAL_DIM

# ANSI codes
ESC = "\033"
HIDE_CURSOR = f"{ESC}[?25l"
SHOW_CURSOR = f"{ESC}[?25h"
CLEAR_LINE = f"{ESC}[2K"
CLEAR_SCREEN = f"{ESC}[2J{ESC}[H"
ALT_SCREEN_ON = f"{ESC}[?1049h"
ALT_SCREEN_OFF = f"{ESC}[?1049l"
RESET = f"{ESC}[0m"
BOLD = f"{ESC}[1m"

C_BLUE = f"{ESC}[38;5;63m"
C_CYAN = f"{ESC}[38;5;80m"
C_GREEN = f"{ESC}[38;5;34m"
C_YELLOW = f"{ESC}[38;5;178m"
C_DIM = f"{ESC}[38;5;242m"
C_WHITE = f"{ESC}[37m"
C_BOLD_WHITE = f"{ESC}[1;37m"
C_BG_SELECT = f"{ESC}[48;5;236m"
C_PURPLE = f"{ESC}[38;5;141m"


def _write(s):
    sys.stdout.write(s)
    sys.stdout.flush()


def _read_key():
    if sys.platform == "win32":
        import msvcrt
        key = msvcrt.getwch()
        if key in ("\x00", "\xe0"):
            key2 = msvcrt.getwch()
            if key2 == "H": return "up"
            elif key2 == "P": return "down"
            return f"special:{key2}"
        elif key == "\r": return "enter"
        elif key == "\x1b": return "escape"
        elif key == "q": return "quit"
        elif key == "\x03": return "escape"
        return key
    else:
        import tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "A": return "up"
                    elif ch3 == "B": return "down"
                return "escape"
            elif ch == "\r": return "enter"
            elif ch == "q": return "quit"
            elif ch == "\x03": return "escape"
            return ch
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


# ── Unified model list item ──────────────────────────────────────────

@dataclass
class _Item:
    display_name: str
    model_id: str       # full string to return (e.g. "anthropic:claude-opus-4-6")
    is_cloud: bool
    installed: bool
    active: bool
    recommended: bool
    size_str: str       # "5.2 GB" or ":cloud"
    category: str
    compat: str         # "optimal", "slower", "cloud"
    downloadable: bool  # local + not installed


def _render_item(item: _Item, selected: bool) -> str:
    bg = C_BG_SELECT if selected else ""
    end = RESET if selected else ""

    # Icon
    if item.active:
        icon = f"{C_BLUE}{BOLD}→{RESET}"
    elif item.installed:
        icon = f"{C_GREEN}✓{RESET}"
    else:
        icon = f"{C_DIM}✗{RESET}"

    # Name
    if selected:
        name = f"{C_BOLD_WHITE}{item.display_name:30s}{RESET}"
    elif item.active:
        name = f"{C_BLUE}{BOLD}{item.display_name:30s}{RESET}"
    elif item.installed:
        name = f"{C_GREEN}{item.display_name:30s}{RESET}"
    else:
        name = f"{C_DIM}{item.display_name:30s}{RESET}"

    # Size / cloud tag
    if item.is_cloud:
        tag = item.size_str  # e.g. "cloud max", "cloud api"
        if "max" in tag:
            size = f"{C_PURPLE}{BOLD}cloud max{RESET}"
        elif "pro" in tag:
            size = f"{C_PURPLE}{BOLD}cloud pro{RESET}"
        else:
            size = f"{C_PURPLE}cloud api{RESET}"
    else:
        size = f"{C_DIM}{item.size_str:>8s}{RESET}"

    # Category
    cat = f"{C_DIM}{item.category:12s}{RESET}"

    # Compat
    if item.compat == "cloud":
        comp = f"{C_PURPLE}api{RESET}"
    elif item.compat == "optimal":
        comp = f"{C_GREEN}optimal{RESET}"
    else:
        comp = f"{C_YELLOW}slower{RESET}"

    # Tags
    tags = ""
    if item.active:
        tags += f"  {C_BLUE}{BOLD}[active]{RESET}"
    if item.recommended:
        tags += f"  {C_CYAN}(recommended){RESET}"

    return f"  {bg}{icon}  {name} {size}  {cat} {comp}{tags}{end}"


def _get_cloud_items(current_model: str) -> list[_Item]:
    """Build cloud model items from authenticated providers."""
    from .providers import get_api_key
    from .login_screen import get_auth_type

    cloud_catalog = {
        "anthropic": [
            ("claude-opus-4-6", "claude", "Claude Opus 4.6"),
            ("claude-sonnet-4-6", "claude", "Claude Sonnet 4.6"),
            ("claude-haiku-4-5-20251001", "claude", "Claude Haiku 4.5"),
        ],
        "openai": [
            ("gpt-4o", "openai", "GPT-4o"),
            ("gpt-4o-mini", "openai", "GPT-4o Mini"),
            ("o3", "openai", "o3 Reasoning"),
        ],
        "groq": [
            ("llama-3.3-70b-versatile", "groq", "Llama 3.3 70B (Groq)"),
        ],
        "deepseek": [
            ("deepseek-chat", "deepseek", "DeepSeek V3"),
            ("deepseek-reasoner", "deepseek", "DeepSeek R1"),
        ],
    }

    items = []
    for provider, models in cloud_catalog.items():
        key = get_api_key(provider)
        if not key:
            continue

        auth = get_auth_type(provider)  # "max", "pro", "api", "oauth"
        if auth in ("max", "pro"):
            cloud_tag = f"cloud {auth}"
        else:
            cloud_tag = "cloud api"

        for model_id, category, pretty_name in models:
            full_id = f"{provider}:{model_id}"
            items.append(_Item(
                display_name=pretty_name,
                model_id=full_id,
                is_cloud=True,
                installed=True,
                active=_model_matches(full_id, current_model),
                recommended=False,
                size_str=cloud_tag,
                category=category,
                compat="cloud",
                downloadable=False,
            ))
    return items


def models_screen(current_model: str, mgr):
    """Interactive model selection. Returns model string or None."""
    mgr.refresh_installed()
    visible = mgr.get_visible_models()
    best_rec = mgr.get_recommended()
    best_rec_name = best_rec.name if best_rec else None

    # Build ordered flat list: local first, then cloud
    items: list[_Item] = []
    for entry, compat in visible:
        inst = mgr.is_installed(entry.name)
        items.append(_Item(
            display_name=entry.display_name, model_id=entry.name, is_cloud=False,
            installed=inst, active=_model_matches(entry.name, current_model),
            recommended=(best_rec_name is not None and entry.name == best_rec_name),
            size_str=f"{entry.size_gb:5.1f} GB", category=entry.category,
            compat=compat, downloadable=not inst,
        ))

    cloud = _get_cloud_items(current_model)
    items.extend(cloud)

    if not items:
        _write(f"  {C_DIM}No models available.{RESET}\n")
        return None

    selected = 0
    for i, it in enumerate(items):
        if it.active:
            selected = i
            break

    # Find where cloud section starts
    cloud_start = next((i for i, it in enumerate(items) if it.is_cloud), len(items))
    has_cloud = cloud_start < len(items)

    _write(HIDE_CURSOR)
    try:
        _write(ALT_SCREEN_ON)

        while True:
            _write(CLEAR_SCREEN)

            _write(f"\n  {C_BLUE}{BOLD}GPU:{RESET} {mgr.hardware.summary()}\n")

            # Local header
            if cloud_start > 0:
                _write(f"\n  {C_DIM}── Local ─────────────────────────────────────────────{RESET}\n")

            for i in range(cloud_start):
                _write(f"{CLEAR_LINE}{_render_item(items[i], i == selected)}\n")

            # Cloud header
            if has_cloud:
                _write(f"\n  {C_PURPLE}── Cloud ─────────────────────────────────────────────{RESET}\n")

            for i in range(cloud_start, len(items)):
                _write(f"{CLEAR_LINE}{_render_item(items[i], i == selected)}\n")

            # Footer
            _write(f"\n")
            sel = items[selected]
            if sel.is_cloud:
                _write(f"  {C_DIM}↑↓ navigate  {RESET}{C_CYAN}enter{RESET} {C_DIM}switch to cloud model  {RESET}{C_CYAN}esc{RESET} {C_DIM}back{RESET}")
            elif sel.installed:
                _write(f"  {C_DIM}↑↓ navigate  {RESET}{C_CYAN}enter{RESET} {C_DIM}switch to model  {RESET}{C_CYAN}esc{RESET} {C_DIM}back{RESET}")
            else:
                _write(f"  {C_DIM}↑↓ navigate  {RESET}{C_CYAN}enter{RESET} {C_DIM}download & switch  {RESET}{C_CYAN}esc{RESET} {C_DIM}back{RESET}")

            key = _read_key()

            if key == "up":
                selected = max(0, selected - 1)
            elif key == "down":
                selected = min(len(items) - 1, selected + 1)
            elif key == "enter":
                sel = items[selected]

                if sel.is_cloud:
                    # Check if provider has both API key and OAuth (max/pro)
                    provider = sel.model_id.split(":")[0]
                    if provider == "anthropic":
                        auth_choice = _prompt_auth_type(provider)
                        if auth_choice is None:
                            continue  # Cancelled, stay in models screen
                        # auth_choice is "max" or "api" — both use same model_id
                        # but we tag it so the status bar knows
                    _write(ALT_SCREEN_OFF)
                    _write(SHOW_CURSOR)
                    return sel.model_id
                elif sel.installed:
                    _write(ALT_SCREEN_OFF)
                    _write(SHOW_CURSOR)
                    return sel.model_id
                else:
                    # Download — stay in alt screen for progress
                    _write(CLEAR_SCREEN)
                    _write(SHOW_CURSOR)
                    success = _download_model(sel.model_id)
                    if success:
                        mgr.refresh_installed()
                        _write(ALT_SCREEN_OFF)
                        return sel.model_id
                    else:
                        _write(f"\n  {C_YELLOW}Download failed. Press any key...{RESET}")
                        _read_key()
                        _write(HIDE_CURSOR)
                        continue

            elif key in ("escape", "quit"):
                _write(ALT_SCREEN_OFF)
                _write(SHOW_CURSOR)
                return None

    except Exception:
        _write(ALT_SCREEN_OFF)
        _write(SHOW_CURSOR)
        return None
    finally:
        _write(ALT_SCREEN_OFF)
        _write(SHOW_CURSOR)


def _prompt_auth_type(provider: str) -> str | None:
    """If provider has both OAuth (max/pro) and API key, prompt which to use.
    Returns 'max', 'api', or None (cancelled)."""
    from .providers import get_api_key, get_active_oauth
    import os

    has_oauth = get_active_oauth() is not None
    has_api_key = bool(os.environ.get("ANTHROPIC_API_KEY", ""))
    if not has_api_key:
        # Check vaal keys
        from .config import VAAL_DIR
        import json
        keys_file = VAAL_DIR / "keys.json"
        if keys_file.exists():
            try:
                keys = json.loads(keys_file.read_text(encoding="utf-8"))
                has_api_key = bool(keys.get(provider, ""))
            except Exception:
                pass

    # If only one option, use it directly
    if has_oauth and not has_api_key:
        return "max"
    if has_api_key and not has_oauth:
        return "api"
    if not has_oauth and not has_api_key:
        return "api"  # Shouldn't happen if we're here, but fallback

    # Both available — prompt
    _write(CLEAR_SCREEN)
    _write(f"\n  {C_BLUE}{BOLD}Authentication Method{RESET}\n\n")

    options = [
        ("max", "Max/Pro Subscription", "Uses your Anthropic subscription (no extra cost)"),
        ("api", "API Key", "Pay-per-use billing via API key"),
    ]
    selected = 0

    while True:
        _write(CLEAR_SCREEN)
        _write(f"\n  {C_BLUE}{BOLD}How to authenticate?{RESET}\n\n")

        for i, (key, label, desc) in enumerate(options):
            if i == selected:
                _write(f"  {C_BG_SELECT}{C_CYAN}❯{RESET} {C_BG_SELECT}{C_BOLD_WHITE}{label}{RESET} {C_BG_SELECT}{C_DIM}{desc}{RESET}\n")
            else:
                _write(f"    {C_WHITE}{label}{RESET} {C_DIM}{desc}{RESET}\n")

        _write(f"\n  {C_DIM}↑↓ navigate  {RESET}{C_CYAN}enter{RESET} {C_DIM}select  {RESET}{C_CYAN}esc{RESET} {C_DIM}cancel{RESET}")

        k = _read_key()
        if k == "up":
            selected = max(0, selected - 1)
        elif k == "down":
            selected = min(len(options) - 1, selected + 1)
        elif k == "enter":
            return options[selected][0]
        elif k in ("escape", "quit"):
            return None


def _download_model(model_name: str) -> bool:
    _write(f"\n  {C_CYAN}Downloading {model_name}...{RESET}\n\n")
    try:
        proc = subprocess.Popen(
            ["ollama", "pull", model_name],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", bufsize=1,
        )
        for line in proc.stdout:
            line = line.strip()
            if line:
                _write(f"\r{CLEAR_LINE}  {C_DIM}{line[:80]}{RESET}")
        proc.wait()
        _write(f"\r{CLEAR_LINE}")
        if proc.returncode == 0:
            _write(f"  {C_GREEN}✓ {model_name} downloaded successfully{RESET}\n")
            time.sleep(1)
            return True
        else:
            _write(f"  {C_YELLOW}✗ Download failed{RESET}\n")
            return False
    except Exception as e:
        _write(f"\r{CLEAR_LINE}  {C_YELLOW}Error: {e}{RESET}\n")
        return False


def _model_matches(catalog_name: str, current: str) -> bool:
    cn = catalog_name.replace(":latest", "").lower()
    cu = current.replace(":latest", "").lower()
    return cn == cu or cn in cu or cu in cn
