"""Vaal Preview Server — serves HTML with interactive inspector overlay.

Serves files on localhost with the Vaal Inspector overlay injected.
Users click elements and describe changes; Vaal edits the source and
hot-reloads the page.

Usage:
    /preview <file_or_dir>     — serve a file or directory
    /preview stop              — stop the preview server
    /preview                   — show status
"""

import json
import os
import re
import threading
import time
import hashlib
import struct
import base64
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from typing import Optional, Callable
from urllib.parse import urlparse, unquote

from .preview_overlay import get_overlay_injection


# ── WebSocket helpers (minimal, no dependencies) ─────────────────────────────

def _ws_handshake(request_headers: dict) -> bytes:
    """Build WebSocket upgrade response."""
    key = request_headers.get("Sec-WebSocket-Key", "")
    GUID = "258EAFA5-E914-47DA-95CA-5AB5DC799C07"
    accept = base64.b64encode(
        hashlib.sha1((key + GUID).encode()).digest()
    ).decode()
    return (
        "HTTP/1.1 101 Switching Protocols\r\n"
        "Upgrade: websocket\r\n"
        "Connection: Upgrade\r\n"
        f"Sec-WebSocket-Accept: {accept}\r\n"
        "\r\n"
    ).encode()


def _ws_encode_frame(data: str) -> bytes:
    """Encode a WebSocket text frame."""
    payload = data.encode("utf-8")
    frame = bytearray()
    frame.append(0x81)  # FIN + text opcode
    length = len(payload)
    if length < 126:
        frame.append(length)
    elif length < 65536:
        frame.append(126)
        frame.extend(struct.pack(">H", length))
    else:
        frame.append(127)
        frame.extend(struct.pack(">Q", length))
    frame.extend(payload)
    return bytes(frame)


class WebSocketServer:
    """Minimal WebSocket server for live reload notifications."""

    def __init__(self, port: int):
        self.port = port
        self.clients: list = []
        self._lock = threading.Lock()
        self._server_socket = None
        self._thread = None
        self._running = False

    def start(self):
        import socket
        self._running = True
        self._server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self._server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self._server_socket.settimeout(1.0)
        self._server_socket.bind(("0.0.0.0", self.port))
        self._server_socket.listen(5)
        self._thread = threading.Thread(target=self._accept_loop, daemon=True)
        self._thread.start()

    def _accept_loop(self):
        while self._running:
            try:
                conn, addr = self._server_socket.accept()
                threading.Thread(target=self._handle_client, args=(conn,), daemon=True).start()
            except OSError:
                if not self._running:
                    break
                continue

    def _handle_client(self, conn):
        try:
            data = conn.recv(4096).decode("utf-8", errors="replace")
            if "Upgrade: websocket" not in data and "upgrade: websocket" not in data:
                conn.close()
                return

            # Parse headers
            headers = {}
            for line in data.split("\r\n")[1:]:
                if ": " in line:
                    k, v = line.split(": ", 1)
                    headers[k] = v

            # Send handshake
            conn.sendall(_ws_handshake(headers))

            with self._lock:
                self.clients.append(conn)

            # Keep connection alive — read and discard frames
            conn.settimeout(30.0)
            while self._running:
                try:
                    chunk = conn.recv(1024)
                    if not chunk:
                        break
                    # Check for close frame (opcode 0x8)
                    if chunk[0] & 0x0F == 0x8:
                        break
                except (OSError, TimeoutError):
                    break

        except Exception:
            pass
        finally:
            with self._lock:
                if conn in self.clients:
                    self.clients.remove(conn)
            try:
                conn.close()
            except Exception:
                pass

    def broadcast(self, message: dict):
        """Send a JSON message to all connected clients."""
        frame = _ws_encode_frame(json.dumps(message))
        with self._lock:
            dead = []
            for client in self.clients:
                try:
                    client.sendall(frame)
                except Exception:
                    dead.append(client)
            for d in dead:
                self.clients.remove(d)
                try:
                    d.close()
                except Exception:
                    pass

    def notify_reload(self):
        """Tell all clients to reload."""
        self.broadcast({"type": "reload"})

    def notify_status(self, message: str, level: str = "working", duration: int = 3000):
        """Show a toast on all clients."""
        self.broadcast({"type": "status", "message": message, "level": level, "duration": duration})

    def stop(self):
        self._running = False
        if self._server_socket:
            try:
                self._server_socket.close()
            except Exception:
                pass
        with self._lock:
            for c in self.clients:
                try:
                    c.close()
                except Exception:
                    pass
            self.clients.clear()


# ── Preview HTTP Handler ─────────────────────────────────────────────────────

class PreviewHandler(SimpleHTTPRequestHandler):
    """Serves files with Vaal overlay injected into HTML pages."""

    # Class-level config (set before starting server)
    serve_root: str = "."
    ws_port: int = 0
    _feedback_callback: list = []  # Wrapped in list to prevent descriptor binding
    source_file: Optional[str] = None  # The actual source file being previewed

    def log_message(self, format, *args):
        """Suppress default logging."""
        pass

    def translate_path(self, path):
        """Map URL paths to the serve root directory."""
        path = unquote(urlparse(path).path)
        # Strip leading /
        path = path.lstrip("/")
        # Map to serve root
        full = os.path.join(self.serve_root, path)
        return os.path.normpath(full)

    def do_GET(self):
        """Serve files, injecting overlay into HTML."""
        parsed = urlparse(self.path)
        url_path = unquote(parsed.path)

        # Vaal API endpoints
        if url_path.startswith("/__vaal__/"):
            self._handle_vaal_api(url_path)
            return

        # If root "/" and we have a specific source file, serve it directly
        if url_path in ("/", "") and self.source_file and os.path.isfile(self.source_file):
            self._serve_html_with_overlay(self.source_file)
            return

        # Resolve file path
        file_path = self.translate_path(self.path)

        # If directory, look for index.html
        if os.path.isdir(file_path):
            index = os.path.join(file_path, "index.html")
            if os.path.exists(index):
                file_path = index
            else:
                # Generate directory listing
                self._serve_directory_listing(file_path, url_path)
                return

        if not os.path.exists(file_path):
            self.send_error(404, f"File not found: {url_path}")
            return

        # Check if HTML — inject overlay
        if file_path.lower().endswith((".html", ".htm")):
            self._serve_html_with_overlay(file_path)
        else:
            # Serve as-is (CSS, JS, images, etc.)
            super().do_GET()

    def do_POST(self):
        """Handle feedback from the overlay."""
        parsed = urlparse(self.path)
        url_path = unquote(parsed.path)

        if url_path == "/__vaal__/feedback":
            self._handle_feedback()
        else:
            self.send_error(404)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def _serve_html_with_overlay(self, file_path: str):
        """Read HTML file, inject overlay, serve it."""
        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                html = f.read()
        except Exception as e:
            self.send_error(500, str(e))
            return

        # Inject overlay before </body> or at end
        overlay = get_overlay_injection(ws_port=self.ws_port)

        if "</body>" in html.lower():
            # Insert before </body>
            idx = html.lower().rfind("</body>")
            html = html[:idx] + overlay + html[idx:]
        elif "</html>" in html.lower():
            idx = html.lower().rfind("</html>")
            html = html[:idx] + overlay + html[idx:]
        else:
            html += overlay

        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.end_headers()
        self.wfile.write(body)

    def _serve_directory_listing(self, dir_path: str, url_path: str):
        """Generate a styled directory listing."""
        try:
            entries = sorted(os.listdir(dir_path))
        except OSError:
            self.send_error(403, "Permission denied")
            return

        items = []
        for entry in entries:
            full = os.path.join(dir_path, entry)
            is_dir = os.path.isdir(full)
            icon = "📁" if is_dir else "📄"
            href = url_path.rstrip("/") + "/" + entry + ("/" if is_dir else "")
            size = "" if is_dir else f'<span style="color:#666;font-size:12px">{os.path.getsize(full):,} bytes</span>'
            items.append(
                f'<a href="{href}" style="display:flex;align-items:center;gap:8px;padding:6px 12px;'
                f'color:#e0e0e0;text-decoration:none;border-radius:4px"'
                f' onmouseover="this.style.background=\'#2a2a4a\'"'
                f' onmouseout="this.style.background=\'transparent\'">'
                f'{icon} <span style="flex:1">{entry}</span>{size}</a>'
            )

        html = f"""<!DOCTYPE html>
<html><head><title>Vaal Preview — {url_path}</title>
<style>
body {{ background: #1a1a2e; color: #e0e0e0; font-family: 'JetBrains Mono', monospace; margin: 0; padding: 20px; }}
h1 {{ color: #8338ec; font-size: 18px; border-bottom: 1px solid #2a2a4a; padding-bottom: 10px; }}
</style></head><body>
<h1>⊙ {url_path}</h1>
{''.join(items)}
</body></html>"""

        overlay = get_overlay_injection(ws_port=self.ws_port)
        html = html.replace("</body>", overlay + "</body>")

        body = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_vaal_api(self, path: str):
        """Handle /__vaal__/* API routes."""
        if path == "/__vaal__/status":
            self._send_json({"status": "ok", "inspecting": True, "source": self.source_file})
        else:
            self.send_error(404)

    def _handle_feedback(self):
        """Process feedback from the overlay inspector."""
        try:
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length)
            data = json.loads(raw.decode("utf-8"))
        except Exception as e:
            self._send_json({"success": False, "error": f"Invalid request: {e}"}, 400)
            return

        prompt = data.get("prompt", "")
        element = data.get("element", {})

        if not prompt:
            self._send_json({"success": False, "error": "No prompt provided"}, 400)
            return

        # Call the feedback handler (runs the LLM)
        # Callback stored in a list to avoid Python's descriptor binding
        callback = self._feedback_callback[0] if self._feedback_callback else None
        if callback:
            try:
                result = callback(prompt, element, data)
                self._send_json({"success": True, "result": result})
            except Exception as e:
                self._send_json({"success": False, "error": str(e)}, 500)
        else:
            self._send_json({"success": False, "error": "No feedback handler configured"}, 500)

    def _send_json(self, data: dict, status: int = 200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)


# ── File Watcher ─────────────────────────────────────────────────────────────

class FileWatcher:
    """Watch files for changes and trigger reload."""

    def __init__(self, path: str, callback: Callable, interval: float = 0.5):
        self.path = os.path.abspath(path)
        self.callback = callback
        self.interval = interval
        self._running = False
        self._thread = None
        self._mtimes: dict[str, float] = {}

    def start(self):
        self._running = True
        self._scan_mtimes()
        self._thread = threading.Thread(target=self._watch_loop, daemon=True)
        self._thread.start()

    def _scan_mtimes(self):
        """Snapshot modification times."""
        self._mtimes.clear()
        if os.path.isfile(self.path):
            self._mtimes[self.path] = os.path.getmtime(self.path)
        elif os.path.isdir(self.path):
            for root, dirs, files in os.walk(self.path):
                # Skip hidden dirs and node_modules
                dirs[:] = [d for d in dirs if not d.startswith(".") and d != "node_modules"]
                for f in files:
                    if f.endswith((".html", ".htm", ".css", ".js", ".json", ".svg")):
                        fp = os.path.join(root, f)
                        try:
                            self._mtimes[fp] = os.path.getmtime(fp)
                        except OSError:
                            pass

    def _watch_loop(self):
        while self._running:
            time.sleep(self.interval)
            changed = False

            if os.path.isfile(self.path):
                try:
                    mt = os.path.getmtime(self.path)
                    if self.path in self._mtimes and mt != self._mtimes[self.path]:
                        changed = True
                    self._mtimes[self.path] = mt
                except OSError:
                    pass
            elif os.path.isdir(self.path):
                for root, dirs, files in os.walk(self.path):
                    dirs[:] = [d for d in dirs if not d.startswith(".") and d != "node_modules"]
                    for f in files:
                        if f.endswith((".html", ".htm", ".css", ".js", ".json", ".svg")):
                            fp = os.path.join(root, f)
                            try:
                                mt = os.path.getmtime(fp)
                                if fp in self._mtimes and mt != self._mtimes[fp]:
                                    changed = True
                                elif fp not in self._mtimes:
                                    changed = True  # New file
                                self._mtimes[fp] = mt
                            except OSError:
                                pass

            if changed:
                try:
                    self.callback()
                except Exception:
                    pass

    def stop(self):
        self._running = False


# ── Preview Server Manager ───────────────────────────────────────────────────

class PreviewServer:
    """Manages the preview server lifecycle."""

    def __init__(self):
        self.http_server: Optional[HTTPServer] = None
        self.ws_server: Optional[WebSocketServer] = None
        self.file_watcher: Optional[FileWatcher] = None
        self.http_thread: Optional[threading.Thread] = None
        self.port: int = 0
        self.ws_port: int = 0
        self.serve_path: str = ""
        self.source_file: Optional[str] = None
        self._running = False
        self._feedback_callback: Optional[Callable] = None

    @property
    def is_running(self) -> bool:
        return self._running

    def start(
        self,
        path: str,
        port: int = 5555,
        feedback_callback: Optional[Callable] = None,
        open_browser: bool = True,
    ):
        """Start serving a file or directory with the overlay."""
        if self._running:
            self.stop()

        path = os.path.abspath(path)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Path not found: {path}")

        self.serve_path = path
        self.port = port
        self.ws_port = port + 1
        self._feedback_callback = feedback_callback

        # Determine serve root and source file
        if os.path.isfile(path):
            self.source_file = path
            serve_root = os.path.dirname(path)
            start_url = "/" + os.path.basename(path)
        else:
            self.source_file = None
            serve_root = path
            start_url = "/"

        # Configure handler
        PreviewHandler.serve_root = serve_root
        PreviewHandler.ws_port = self.ws_port
        PreviewHandler._feedback_callback = [feedback_callback] if feedback_callback else []
        PreviewHandler.source_file = self.source_file

        # Start WebSocket server
        self.ws_server = WebSocketServer(self.ws_port)
        self.ws_server.start()

        # Start HTTP server
        self.http_server = HTTPServer(("0.0.0.0", self.port), PreviewHandler)
        self.http_thread = threading.Thread(target=self.http_server.serve_forever, daemon=True)
        self.http_thread.start()

        # Start file watcher
        self.file_watcher = FileWatcher(
            serve_root,
            callback=self._on_file_change,
        )
        self.file_watcher.start()

        self._running = True

        # Open browser
        if open_browser:
            import webbrowser
            url = f"http://localhost:{self.port}{start_url}"
            webbrowser.open(url)

        return f"http://localhost:{self.port}{start_url}"

    def _on_file_change(self):
        """Called when watched files change — notify clients to reload."""
        if self.ws_server:
            self.ws_server.notify_reload()

    def notify_reload(self):
        """Manually trigger a reload on all clients."""
        if self.ws_server:
            self.ws_server.notify_reload()

    def notify_status(self, message: str, level: str = "working", duration: int = 3000):
        """Show a toast on all connected clients."""
        if self.ws_server:
            self.ws_server.notify_status(message, level, duration)

    def stop(self):
        """Stop all servers and watchers."""
        self._running = False

        if self.file_watcher:
            self.file_watcher.stop()
            self.file_watcher = None

        if self.http_server:
            self.http_server.shutdown()
            self.http_server = None

        if self.ws_server:
            self.ws_server.stop()
            self.ws_server = None

        self.http_thread = None

    def status(self) -> dict:
        """Return current server status."""
        return {
            "running": self._running,
            "port": self.port,
            "ws_port": self.ws_port,
            "path": self.serve_path,
            "source_file": self.source_file,
            "url": f"http://localhost:{self.port}" if self._running else None,
            "clients": len(self.ws_server.clients) if self.ws_server else 0,
        }


# ── Feedback Handler Builder ─────────────────────────────────────────────────

def build_feedback_handler(
    session,
    model: str,
    permissions,
    source_path: str,
    preview_server: "PreviewServer",
):
    """Build a feedback callback that uses the current LLM session to process
    element feedback and edit the source file.

    Returns a callable: (prompt, element_context, full_data) -> str
    """
    from .llm import chat_with_tools_stream, get_ollama_tools, build_system_prompt
    from .tool_executor import execute_tool, format_tool_result
    from ..tools.registry import all_tools

    def handle_feedback(prompt: str, element: dict, data: dict) -> str:
        """Process user feedback on an element — run LLM to edit the source."""

        # Build a focused prompt for the LLM
        selector = element.get("selector", "unknown")
        tag = element.get("tag", "unknown")
        classes = element.get("classes", [])
        text_preview = element.get("text", "")[:100]
        outer_html = element.get("outerHTML", "")[:1500]
        styles = element.get("computedStyle", {})
        page_url = data.get("page_url", "/")

        # Determine the source file to edit
        source = source_path
        if os.path.isdir(source):
            # Try to find the HTML file from the page URL
            page_file = page_url.lstrip("/") or "index.html"
            candidate = os.path.join(source, page_file)
            if os.path.exists(candidate):
                source = candidate
            else:
                # Find first HTML file
                for f in os.listdir(source):
                    if f.endswith((".html", ".htm")):
                        source = os.path.join(source, f)
                        break

        # Read the current source
        try:
            with open(source, "r", encoding="utf-8") as f:
                current_source = f.read()
        except Exception:
            current_source = "(could not read source file)"

        feedback_prompt = f"""The user is previewing an HTML page and has selected a specific element to modify.

## User's Request
"{prompt}"

## Selected Element
- **Selector:** `{selector}`
- **Tag:** `<{tag}>`
- **Classes:** {', '.join(classes) if classes else 'none'}
- **Text content:** "{text_preview}"
- **Outer HTML:**
```html
{outer_html}
```

## Computed Styles
{json.dumps(styles, indent=2)}

## Source File
Path: `{source}`

```html
{current_source}
```

## Instructions
Edit the source file at `{source}` to fulfill the user's request for the selected element.
- Use the `edit` tool to make precise changes to the file
- Only modify what's needed to address the user's request
- Keep changes minimal and focused on the selected element
- If the user asks for a style change, prefer inline styles or adding a <style> block
- Do NOT add or modify any elements with IDs starting with "vaal-"
- Do NOT remove or modify the Vaal Inspector overlay code

Make the edit now."""

        # Build messages for the LLM
        ollama_tools = get_ollama_tools(all_tools())

        messages = [
            {"role": "system", "content": build_system_prompt()},
            {"role": "user", "content": feedback_prompt},
        ]

        def auto_approve(name, params):
            return True

        # Run tool loop
        max_rounds = 5
        final_content = ""

        for _ in range(max_rounds):
            content = ""
            tool_calls = []

            for chunk in chat_with_tools_stream(messages, ollama_tools, model=model):
                if chunk.get("content"):
                    token = chunk["content"]
                    if "<think>" not in token and "</think>" not in token:
                        content += token
                if chunk.get("tool_calls"):
                    tool_calls.extend(chunk["tool_calls"])

            content = content.strip()
            final_content = content

            if not tool_calls:
                break

            messages.append({"role": "assistant", "content": content or "(tool calls)"})

            for tc in tool_calls:
                func = tc.get("function", {})
                tool_name = func.get("name", "")
                tool_args = func.get("arguments", {})

                result, executed = execute_tool(tool_name, tool_args, permissions, auto_approve)
                formatted = format_tool_result(tool_name, result)
                messages.append({"role": "tool", "content": formatted})

        # Trigger reload after edit
        if preview_server and preview_server.ws_server:
            preview_server.ws_server.notify_reload()

        return final_content

    return handle_feedback


# ── Convenience: start preview from REPL ─────────────────────────────────────

# Global singleton
_preview_server: Optional[PreviewServer] = None


def get_preview_server() -> PreviewServer:
    """Get or create the global preview server instance."""
    global _preview_server
    if _preview_server is None:
        _preview_server = PreviewServer()
    return _preview_server


def start_preview(
    path: str,
    port: int = 5555,
    session=None,
    model: str = "",
    permissions=None,
    open_browser: bool = True,
) -> str:
    """Start the preview server for a path. Returns the URL."""
    server = get_preview_server()

    # Build feedback handler if we have session context
    feedback_cb = None
    if model and permissions:
        feedback_cb = build_feedback_handler(
            session=session,
            model=model,
            permissions=permissions,
            source_path=os.path.abspath(path),
            preview_server=server,
        )

    url = server.start(
        path=path,
        port=port,
        feedback_callback=feedback_cb,
        open_browser=open_browser,
    )
    return url


def stop_preview():
    """Stop the preview server."""
    global _preview_server
    if _preview_server:
        _preview_server.stop()


def preview_status() -> dict:
    """Get preview server status."""
    server = get_preview_server()
    return server.status()
