"""Hook system — run shell commands on tool and response events."""

import json
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .config import VAAL_DIR

logger = logging.getLogger(__name__)

HOOKS_FILE = VAAL_DIR / "hooks.json"


@dataclass
class Hook:
    name: str
    event: str  # "pre_tool", "post_tool", "on_response"
    command: str  # shell command to execute
    enabled: bool = True


def load_hooks() -> list[Hook]:
    """Load hooks from ~/.vaal/hooks.json.

    Expected format:
    [
        {
            "name": "log_tool_use",
            "event": "pre_tool",
            "command": "echo 'Running tool: $VAAL_TOOL_NAME'",
            "enabled": true
        }
    ]
    """
    if not HOOKS_FILE.exists():
        return []

    try:
        data = json.loads(HOOKS_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            logger.warning("hooks.json: expected a list, got %s", type(data).__name__)
            return []
        hooks = []
        for entry in data:
            if not isinstance(entry, dict):
                continue
            event = entry.get("event", "")
            if event not in ("pre_tool", "post_tool", "on_response"):
                logger.warning("hooks.json: unknown event type '%s' in hook '%s'", event, entry.get("name", "?"))
                continue
            hooks.append(Hook(
                name=entry.get("name", "unnamed"),
                event=event,
                command=entry.get("command", ""),
                enabled=entry.get("enabled", True),
            ))
        return hooks
    except (json.JSONDecodeError, OSError) as e:
        logger.warning("Failed to load hooks.json: %s", e)
        return []


def run_hooks(event: str, context: dict[str, Any], hooks: list[Hook] | None = None) -> list[dict]:
    """Run all enabled hooks matching the given event.

    Context dict is passed as environment variables prefixed with VAAL_:
        - tool_name  -> VAAL_TOOL_NAME
        - tool_result -> VAAL_TOOL_RESULT
        - response   -> VAAL_RESPONSE  (truncated to 4KB for safety)

    Returns a list of result dicts: [{"name": ..., "returncode": ..., "stdout": ..., "stderr": ...}]
    """
    if hooks is None:
        hooks = load_hooks()

    results = []
    matching = [h for h in hooks if h.event == event and h.enabled and h.command]

    if not matching:
        return results

    # Build env vars from context
    import os
    env = os.environ.copy()
    for key, value in context.items():
        env_key = f"VAAL_{key.upper()}"
        str_val = str(value)
        # Truncate large values to avoid env var limits
        if len(str_val) > 4096:
            str_val = str_val[:4096] + "...[truncated]"
        env[env_key] = str_val

    for hook in matching:
        try:
            proc = subprocess.run(
                hook.command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=30,
                env=env,
            )
            results.append({
                "name": hook.name,
                "returncode": proc.returncode,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
            })
            if proc.returncode != 0:
                logger.warning(
                    "Hook '%s' exited with code %d: %s",
                    hook.name, proc.returncode, proc.stderr.strip(),
                )
        except subprocess.TimeoutExpired:
            logger.warning("Hook '%s' timed out after 30s", hook.name)
            results.append({
                "name": hook.name,
                "returncode": -1,
                "stdout": "",
                "stderr": "timed out after 30s",
            })
        except OSError as e:
            logger.warning("Hook '%s' failed to run: %s", hook.name, e)
            results.append({
                "name": hook.name,
                "returncode": -1,
                "stdout": "",
                "stderr": str(e),
            })

    return results
