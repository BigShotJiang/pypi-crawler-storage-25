"""OAuth flow for Anthropic — PKCE authorization code flow with local callback server."""

import base64
import hashlib
import http.server
import json
import os
import secrets
import socket
import threading
import time
import urllib.parse
import webbrowser

import httpx

# Anthropic OAuth endpoints
AUTHORIZE_URL = "https://claude.ai/oauth/authorize"
TOKEN_URL = "https://platform.claude.com/v1/oauth/token"

# Use Claude Code's public client ID — it's a public client (no secret needed for PKCE)
CLIENT_ID = "9d1c250a-e61b-44d9-88ed-5944d1962f5e"

SCOPES = "user:inference user:profile user:sessions:claude_code user:mcp_servers user:file_upload"


def _find_free_port() -> int:
    """Find an available port for the callback server."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _generate_pkce() -> tuple[str, str]:
    """Generate PKCE code_verifier and code_challenge."""
    verifier = secrets.token_urlsafe(43)  # 43 bytes = 57 chars base64url
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


def _generate_state() -> str:
    return secrets.token_urlsafe(32)


class _OAuthCallbackHandler(http.server.BaseHTTPRequestHandler):
    """HTTP handler that captures the OAuth callback."""

    auth_code = None
    state_received = None
    error = None

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        if parsed.path == "/callback":
            if "code" in params:
                _OAuthCallbackHandler.auth_code = params["code"][0]
                _OAuthCallbackHandler.state_received = params.get("state", [None])[0]
                self.send_response(200)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(b"""
                <html><body style="background:#0a0008;color:#d4c4c8;font-family:monospace;display:flex;justify-content:center;align-items:center;height:100vh;margin:0">
                <div style="text-align:center">
                <h1 style="color:#bf1f3e">&#x2713; Vaal Connected</h1>
                <p>You can close this tab and return to the terminal.</p>
                </div></body></html>
                """)
            elif "error" in params:
                _OAuthCallbackHandler.error = params.get("error_description", params["error"])[0]
                self.send_response(400)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(f"<html><body><h1>Error: {_OAuthCallbackHandler.error}</h1></body></html>".encode())
            else:
                self.send_response(404)
                self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, format, *args):
        pass  # Suppress server logs


def run_oauth_flow(on_status=None) -> dict | None:
    """Run the full OAuth PKCE flow.

    Args:
        on_status: callback(message: str) for status updates

    Returns:
        OAuth token dict with accessToken, refreshToken, etc. or None on failure.
    """
    def status(msg):
        if on_status:
            on_status(msg)

    port = _find_free_port()
    redirect_uri = f"http://localhost:{port}/callback"
    verifier, challenge = _generate_pkce()
    state = _generate_state()

    # Build authorization URL
    params = {
        "client_id": CLIENT_ID,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "scope": SCOPES,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
    }
    auth_url = f"{AUTHORIZE_URL}?{urllib.parse.urlencode(params)}"

    # Reset handler state
    _OAuthCallbackHandler.auth_code = None
    _OAuthCallbackHandler.state_received = None
    _OAuthCallbackHandler.error = None

    # Start local callback server
    server = http.server.HTTPServer(("127.0.0.1", port), _OAuthCallbackHandler)
    server.timeout = 1
    server_thread = threading.Thread(target=lambda: None, daemon=True)

    status("Opening browser for login...")

    # Open browser
    try:
        webbrowser.open(auth_url)
        status("Browser opened — complete the login there")
    except Exception:
        status(f"Open this URL in your browser:\n{auth_url}")

    # Wait for callback (up to 5 minutes)
    deadline = time.time() + 300
    try:
        while time.time() < deadline:
            server.handle_request()  # Blocks for up to server.timeout (1s)

            if _OAuthCallbackHandler.auth_code:
                break
            if _OAuthCallbackHandler.error:
                status(f"Error: {_OAuthCallbackHandler.error}")
                return None

            elapsed = int(time.time() - (deadline - 300))
            status(f"Waiting for browser login... ({elapsed}s)")
    finally:
        server.server_close()

    if not _OAuthCallbackHandler.auth_code:
        status("Timed out waiting for login")
        return None

    # Verify state
    if _OAuthCallbackHandler.state_received != state:
        status("Security error: state mismatch")
        return None

    auth_code = _OAuthCallbackHandler.auth_code
    status("Got authorization code, exchanging for token...")

    # Exchange code for token
    try:
        r = httpx.post(
            TOKEN_URL,
            headers={"Content-Type": "application/json"},
            json={
                "grant_type": "authorization_code",
                "code": auth_code,
                "redirect_uri": redirect_uri,
                "client_id": CLIENT_ID,
                "code_verifier": verifier,
                "state": state,
            },
            timeout=30,
        )

        if r.status_code != 200:
            # Try JSON error first
            try:
                err = r.json()
                msg = err.get("error", {}).get("message", r.text[:200])
            except Exception:
                msg = r.text[:200]
            status(f"Token exchange failed ({r.status_code}): {msg}")
            return None

        data = r.json()

        # Build our OAuth token dict
        oauth = {
            "accessToken": data.get("access_token", ""),
            "refreshToken": data.get("refresh_token", ""),
            "expiresAt": int(time.time() * 1000) + data.get("expires_in", 3600) * 1000,
            "scopes": SCOPES.split(),
            "subscriptionType": "",  # Will be detected on first API call
            "rateLimitTier": "",
        }

        # Try to detect subscription type
        try:
            profile_r = httpx.get(
                "https://api.anthropic.com/v1/me",
                headers={
                    "Authorization": f"Bearer {oauth['accessToken']}",
                    "anthropic-version": "2023-06-01",
                },
                timeout=10,
            )
            if profile_r.status_code == 200:
                profile = profile_r.json()
                oauth["subscriptionType"] = profile.get("subscription_type", "max")
                oauth["rateLimitTier"] = profile.get("rate_limit_tier", "")
        except Exception:
            oauth["subscriptionType"] = "max"  # Assume max if we can't check

        if not oauth["subscriptionType"]:
            oauth["subscriptionType"] = "max"

        status(f"Connected! {oauth['subscriptionType'].title()} subscription")
        return oauth

    except Exception as e:
        status(f"Token exchange error: {e}")
        return None
