"""Chain-of-thought visualization — collapsible thinking display with diff preview."""

import re
from typing import Optional

from rich.console import Console, Group
from rich.panel import Panel
from rich.text import Text
from rich.syntax import Syntax

from .theme import VAAL_BLUE, VAAL_CYAN, VAAL_DIM, VAAL_GREEN, VAAL_RED, VAAL_THEME

# ANSI color codes for direct terminal output
_ESC = "\033"
_GREEN = f"{_ESC}[32m"
_RED = f"{_ESC}[31m"
_RESET = f"{_ESC}[0m"
_DIM = f"{_ESC}[2m"
_BOLD = f"{_ESC}[1m"


class CotDisplay:
    """Manages chain-of-thought display state."""

    def __init__(self, enabled: bool = True):
        self.enabled = enabled
        self._last_thinking: Optional[str] = None

    def toggle(self, state: Optional[bool] = None):
        """Toggle or set thinking display."""
        if state is not None:
            self.enabled = state
        else:
            self.enabled = not self.enabled

    def format_thinking(self, thinking_text: str) -> Optional[Panel]:
        """Format thinking tokens into a collapsible panel with numbered steps."""
        if not self.enabled or not thinking_text:
            return None

        self._last_thinking = thinking_text

        # Parse thinking into numbered steps
        steps = _parse_thinking_steps(thinking_text)

        body = Text()
        for i, step in enumerate(steps, 1):
            body.append(f"  {i}. ", style=f"bold {VAAL_CYAN}")
            body.append(step.strip(), style=VAAL_DIM)
            body.append("\n")

        header = Text()
        header.append("Thinking", style=f"bold {VAAL_BLUE}")
        header.append(f" ({len(steps)} steps)", style=VAAL_DIM)

        return Panel(
            body,
            title=header,
            border_style=VAAL_BLUE,
            padding=(0, 1),
            expand=False,
        )

    def print_thinking(self, console: Console, thinking_text: str):
        """Print thinking tokens to console if enabled."""
        panel = self.format_thinking(thinking_text)
        if panel:
            console.print()
            console.print(panel)

    @property
    def last_thinking(self) -> Optional[str]:
        return self._last_thinking


def _parse_thinking_steps(text: str) -> list[str]:
    """Parse thinking text into discrete reasoning steps."""
    # Try to split on numbered patterns first (1. or 1) or - bullets)
    numbered = re.split(r'\n\s*(?:\d+[.)]\s+|[-*]\s+)', text)
    if len(numbered) > 1:
        # First element might be a preamble, include it as step 1 if non-empty
        steps = [s.strip() for s in numbered if s.strip()]
        return steps if steps else [text.strip()]

    # Fall back to splitting on sentence boundaries / newlines
    parts = re.split(r'\n\n+', text)
    if len(parts) > 1:
        return [p.strip() for p in parts if p.strip()]

    # Single block — split on sentences if long enough
    sentences = re.split(r'(?<=[.!?])\s+', text)
    if len(sentences) > 2:
        # Group into reasonable-sized steps
        steps = []
        current = []
        for s in sentences:
            current.append(s)
            if len(" ".join(current)) > 100:
                steps.append(" ".join(current))
                current = []
        if current:
            steps.append(" ".join(current))
        return steps

    return [text.strip()]


def format_diff_preview(old_content: str, new_content: str, filename: str = "") -> str:
    """Format a diff preview with git-style coloring using Rich markup.

    Shows lines removed in red with - prefix and lines added in green with + prefix.
    """
    import difflib

    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    diff = difflib.unified_diff(
        old_lines,
        new_lines,
        fromfile=f"a/{filename}" if filename else "before",
        tofile=f"b/{filename}" if filename else "after",
        n=3,
    )

    output_lines = []
    for line in diff:
        line_stripped = line.rstrip("\n")
        if line.startswith("---") or line.startswith("+++"):
            output_lines.append(f"[bold {VAAL_DIM}]{_escape_markup(line_stripped)}[/]")
        elif line.startswith("@@"):
            output_lines.append(f"[{VAAL_CYAN}]{_escape_markup(line_stripped)}[/]")
        elif line.startswith("-"):
            output_lines.append(f"[{VAAL_RED}]{_escape_markup(line_stripped)}[/]")
        elif line.startswith("+"):
            output_lines.append(f"[{VAAL_GREEN}]{_escape_markup(line_stripped)}[/]")
        else:
            output_lines.append(f"[{VAAL_DIM}]{_escape_markup(line_stripped)}[/]")

    return "\n".join(output_lines)


def format_diff_preview_ansi(old_content: str, new_content: str, filename: str = "") -> str:
    """Format a diff preview using raw ANSI codes (for non-Rich output)."""
    import difflib

    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    diff = difflib.unified_diff(
        old_lines,
        new_lines,
        fromfile=f"a/{filename}" if filename else "before",
        tofile=f"b/{filename}" if filename else "after",
        n=3,
    )

    output_lines = []
    for line in diff:
        line_stripped = line.rstrip("\n")
        if line.startswith("---") or line.startswith("+++"):
            output_lines.append(f"{_BOLD}{_DIM}{line_stripped}{_RESET}")
        elif line.startswith("@@"):
            output_lines.append(f"{_ESC}[36m{line_stripped}{_RESET}")
        elif line.startswith("-"):
            output_lines.append(f"{_RED}- {line_stripped[1:]}{_RESET}")
        elif line.startswith("+"):
            output_lines.append(f"{_GREEN}+ {line_stripped[1:]}{_RESET}")
        else:
            output_lines.append(f"{_DIM} {line_stripped}{_RESET}")

    return "\n".join(output_lines)


def print_diff_panel(console: Console, old_content: str, new_content: str, filename: str = ""):
    """Print a diff panel to the console with colored additions/removals."""
    diff_text = format_diff_preview(old_content, new_content, filename)
    if not diff_text:
        console.print(f"[{VAAL_DIM}]  (no changes)[/]")
        return

    header = Text()
    header.append("Changes", style=f"bold {VAAL_BLUE}")
    if filename:
        header.append(f" {filename}", style=VAAL_CYAN)

    console.print()
    console.print(Panel(
        diff_text,
        title=header,
        border_style=VAAL_BLUE,
        padding=(0, 1),
    ))


def _escape_markup(text: str) -> str:
    """Escape Rich markup characters in text."""
    return text.replace("[", "\\[").replace("]", "\\]")
