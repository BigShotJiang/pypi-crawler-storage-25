"""OpenAI-compatible HTTP API server — proxies to Ollama with tool execution."""

import json
import time
import uuid
from http.server import HTTPServer, BaseHTTPRequestHandler
from typing import Any

from .config import OLLAMA_HOST, DEFAULT_MODEL, MAX_OUTPUT_TOKENS, load_project_instructions
from .llm import (
    chat_with_tools_stream,
    build_system_prompt,
    check_connection,
    list_models,
    get_ollama_tools,
    model_supports_tools,
)
from .tool_executor import execute_tool
from .permissions import PermissionManager

from ..tools.registry import all_tools


def _auto_permission_ask(name: str, params: dict) -> bool:
    """Server mode auto-approves all tool calls (no interactive prompt)."""
    return True


class VaalAPIHandler(BaseHTTPRequestHandler):
    """Handles OpenAI-compatible API requests."""

    server_version = "vaal/0.1.0"
    ollama_tools = None
    system_prompt = None
    permissions = None

    def log_message(self, format, *args):
        """Suppress default request logging to stderr."""
        pass

    def _send_json(self, data: dict, status: int = 200):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_error(self, message: str, status: int = 400):
        self._send_json({
            "error": {
                "message": message,
                "type": "invalid_request_error",
                "code": None,
            }
        }, status=status)

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length", 0))
        if length == 0:
            return {}
        raw = self.rfile.read(length)
        return json.loads(raw.decode("utf-8"))

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type, Authorization")
        self.end_headers()

    def do_GET(self):
        if self.path == "/health":
            connected = check_connection()
            self._send_json({
                "status": "ok" if connected else "degraded",
                "ollama": connected,
                "version": self.server_version,
            })

        elif self.path == "/v1/models":
            models = list_models()
            model_list = []
            for m in models:
                model_list.append({
                    "id": m,
                    "object": "model",
                    "created": int(time.time()),
                    "owned_by": "ollama",
                })
            self._send_json({
                "object": "list",
                "data": model_list,
            })

        else:
            self._send_error("Not found", 404)

    def do_POST(self):
        if self.path == "/v1/chat/completions":
            self._handle_chat_completions()
        else:
            self._send_error("Not found", 404)

    def _handle_chat_completions(self):
        try:
            body = self._read_body()
        except (json.JSONDecodeError, ValueError) as e:
            self._send_error(f"Invalid JSON: {e}")
            return

        model = body.get("model", DEFAULT_MODEL)
        messages = body.get("messages", [])
        stream = body.get("stream", False)
        temperature = body.get("temperature")
        max_tokens = body.get("max_tokens", MAX_OUTPUT_TOKENS)

        if not messages:
            self._send_error("messages is required")
            return

        # Inject system prompt if none provided
        if messages[0].get("role") != "system":
            messages.insert(0, {"role": "system", "content": self.system_prompt})

        if stream:
            self._handle_stream(model, messages, temperature, max_tokens)
        else:
            self._handle_non_stream(model, messages, temperature, max_tokens)

    def _handle_non_stream(self, model: str, messages: list, temperature: float | None, max_tokens: int):
        """Non-streaming: run tool loop, return final response."""
        chat_id = f"chatcmpl-{uuid.uuid4().hex[:12]}"
        max_rounds = 10

        for _ in range(max_rounds):
            # Collect full response
            content = ""
            tool_calls_raw = []
            eval_count = 0

            try:
                for chunk in chat_with_tools_stream(messages, self.ollama_tools, model=model):
                    if chunk.get("content"):
                        token = chunk["content"]
                        # Strip think tags
                        if "<think>" not in token and "</think>" not in token:
                            content += token
                    if chunk.get("tool_calls"):
                        tool_calls_raw.extend(chunk["tool_calls"])
                    if chunk.get("done"):
                        eval_count = chunk.get("eval_count", 0)
            except Exception as e:
                self._send_error(f"Ollama error: {e}", 502)
                return

            content = content.strip()

            if not tool_calls_raw:
                # No tool calls — return final response
                self._send_json({
                    "id": chat_id,
                    "object": "chat.completion",
                    "created": int(time.time()),
                    "model": model,
                    "choices": [{
                        "index": 0,
                        "message": {
                            "role": "assistant",
                            "content": content,
                        },
                        "finish_reason": "stop",
                    }],
                    "usage": {
                        "prompt_tokens": 0,
                        "completion_tokens": eval_count,
                        "total_tokens": eval_count,
                    },
                })
                return

            # Execute tools and feed results back
            messages.append({"role": "assistant", "content": content or "(tool calls)"})

            for tc in tool_calls_raw:
                func = tc.get("function", {})
                tool_name = func.get("name", "")
                tool_args = func.get("arguments", {})

                result, executed = execute_tool(
                    tool_name, tool_args, self.permissions, _auto_permission_ask
                )
                from .tool_executor import format_tool_result
                formatted = format_tool_result(tool_name, result)
                messages.append({"role": "tool", "content": formatted})

        # Exhausted rounds
        self._send_json({
            "id": chat_id,
            "object": "chat.completion",
            "created": int(time.time()),
            "model": model,
            "choices": [{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": content or "(max tool rounds reached)",
                },
                "finish_reason": "stop",
            }],
            "usage": {
                "prompt_tokens": 0,
                "completion_tokens": 0,
                "total_tokens": 0,
            },
        })

    def _handle_stream(self, model: str, messages: list, temperature: float | None, max_tokens: int):
        """SSE streaming response with tool execution loop."""
        chat_id = f"chatcmpl-{uuid.uuid4().hex[:12]}"
        max_rounds = 10

        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Connection", "keep-alive")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()

        def send_sse(data: dict):
            line = f"data: {json.dumps(data)}\n\n"
            self.wfile.write(line.encode("utf-8"))
            self.wfile.flush()

        for _ in range(max_rounds):
            tool_calls_raw = []
            content = ""

            try:
                for chunk in chat_with_tools_stream(messages, self.ollama_tools, model=model):
                    if chunk.get("content"):
                        token = chunk["content"]
                        if "<think>" not in token and "</think>" not in token:
                            content += token
                            send_sse({
                                "id": chat_id,
                                "object": "chat.completion.chunk",
                                "created": int(time.time()),
                                "model": model,
                                "choices": [{
                                    "index": 0,
                                    "delta": {"content": token},
                                    "finish_reason": None,
                                }],
                            })
                    if chunk.get("tool_calls"):
                        tool_calls_raw.extend(chunk["tool_calls"])
            except Exception:
                break

            content = content.strip()

            if not tool_calls_raw:
                # Send final chunk
                send_sse({
                    "id": chat_id,
                    "object": "chat.completion.chunk",
                    "created": int(time.time()),
                    "model": model,
                    "choices": [{
                        "index": 0,
                        "delta": {},
                        "finish_reason": "stop",
                    }],
                })
                self.wfile.write(b"data: [DONE]\n\n")
                self.wfile.flush()
                return

            # Execute tools
            messages.append({"role": "assistant", "content": content or "(tool calls)"})
            for tc in tool_calls_raw:
                func = tc.get("function", {})
                tool_name = func.get("name", "")
                tool_args = func.get("arguments", {})

                result, executed = execute_tool(
                    tool_name, tool_args, self.permissions, _auto_permission_ask
                )
                from .tool_executor import format_tool_result
                formatted = format_tool_result(tool_name, result)
                messages.append({"role": "tool", "content": formatted})

        # Exhausted rounds — close stream
        self.wfile.write(b"data: [DONE]\n\n")
        self.wfile.flush()


def run_server(port: int = 8484, model: str = DEFAULT_MODEL):
    """Start the OpenAI-compatible API server."""
    if not check_connection():
        print(f"[ERROR] Cannot connect to Ollama at {OLLAMA_HOST}")
        print("Start Ollama first, then try again.")
        return

    # Prepare shared state
    project_instructions = load_project_instructions()
    system_prompt = build_system_prompt(project_instructions=project_instructions)
    ollama_tools = get_ollama_tools(all_tools())
    permissions = PermissionManager(mode="yolo")

    VaalAPIHandler.ollama_tools = ollama_tools
    VaalAPIHandler.system_prompt = system_prompt
    VaalAPIHandler.permissions = permissions

    server = HTTPServer(("0.0.0.0", port), VaalAPIHandler)
    print(f"Vaal server running on http://localhost:{port}")
    print(f"  Model: {model}")
    print(f"  Endpoints:")
    print(f"    POST /v1/chat/completions")
    print(f"    GET  /v1/models")
    print(f"    GET  /health")
    print(f"  Press Ctrl+C to stop.")

    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        server.shutdown()
