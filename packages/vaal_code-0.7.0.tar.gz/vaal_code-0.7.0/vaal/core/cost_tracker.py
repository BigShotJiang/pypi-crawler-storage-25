"""Cost tracking — per-event token usage with labels and timestamps."""

from __future__ import annotations

import time
from dataclasses import dataclass, field


@dataclass
class CostEvent:
    label: str
    input_tokens: int
    output_tokens: int
    timestamp: float = field(default_factory=time.time)


class CostTracker:
    """Tracks token usage across LLM calls within a session."""

    def __init__(self):
        self.events: list[CostEvent] = []

    def record(self, label: str, input_tokens: int, output_tokens: int):
        """Record a token usage event."""
        self.events.append(CostEvent(
            label=label,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        ))

    @property
    def total_input(self) -> int:
        return sum(e.input_tokens for e in self.events)

    @property
    def total_output(self) -> int:
        return sum(e.output_tokens for e in self.events)

    @property
    def total_tokens(self) -> int:
        return self.total_input + self.total_output

    def summary(self) -> str:
        """Return a formatted summary of all cost events."""
        lines = []
        lines.append(f"Token Usage Summary ({len(self.events)} calls)")
        lines.append(f"{'─' * 50}")
        lines.append(f"  {'Label':<25s} {'Input':>8s} {'Output':>8s} {'Total':>8s}")
        lines.append(f"  {'─' * 25} {'─' * 8} {'─' * 8} {'─' * 8}")

        for e in self.events:
            total = e.input_tokens + e.output_tokens
            lines.append(f"  {e.label:<25s} {e.input_tokens:>8d} {e.output_tokens:>8d} {total:>8d}")

        lines.append(f"  {'─' * 25} {'─' * 8} {'─' * 8} {'─' * 8}")
        lines.append(f"  {'TOTAL':<25s} {self.total_input:>8d} {self.total_output:>8d} {self.total_tokens:>8d}")
        return "\n".join(lines)
