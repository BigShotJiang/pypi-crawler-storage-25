"""Dependency analysis -- scan, audit, and update project dependencies."""

import subprocess
import os
import re
import json
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Dependency:
    name: str
    current_version: str
    latest_version: str = ""
    dep_file: str = ""
    has_vulnerability: bool = False
    vulnerability_info: str = ""


@dataclass
class DepFile:
    path: str
    kind: str  # requirements.txt, package.json, Cargo.toml, go.mod, pyproject.toml
    dependencies: list[Dependency]


def _run(args: list[str], cwd: str | None = None, timeout: int = 60) -> tuple[str, int]:
    """Run a command and return (output, returncode)."""
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd or os.getcwd(),
        )
        output = result.stdout or ""
        if result.stderr:
            if output:
                output += "\n"
            output += result.stderr
        return output.strip(), result.returncode
    except FileNotFoundError:
        return f"[error: {args[0]} not found on PATH]", 1
    except subprocess.TimeoutExpired:
        return f"[error: command timed out after {timeout}s]", 1
    except Exception as e:
        return f"[error: {e}]", 1


def scan_dep_files(directory: str = "") -> list[DepFile]:
    """Scan a directory for dependency files and parse them."""
    base = Path(directory) if directory else Path.cwd()
    dep_files = []

    # requirements.txt
    for req_file in base.rglob("requirements*.txt"):
        if ".venv" in str(req_file) or "node_modules" in str(req_file):
            continue
        deps = _parse_requirements_txt(req_file)
        if deps:
            dep_files.append(DepFile(
                path=str(req_file),
                kind="requirements.txt",
                dependencies=deps,
            ))

    # pyproject.toml
    for pyproject in base.rglob("pyproject.toml"):
        if ".venv" in str(pyproject) or "node_modules" in str(pyproject):
            continue
        deps = _parse_pyproject_toml(pyproject)
        if deps:
            dep_files.append(DepFile(
                path=str(pyproject),
                kind="pyproject.toml",
                dependencies=deps,
            ))

    # package.json
    for pkg_json in base.rglob("package.json"):
        if "node_modules" in str(pkg_json):
            continue
        deps = _parse_package_json(pkg_json)
        if deps:
            dep_files.append(DepFile(
                path=str(pkg_json),
                kind="package.json",
                dependencies=deps,
            ))

    # Cargo.toml
    for cargo in base.rglob("Cargo.toml"):
        if "target" in str(cargo):
            continue
        deps = _parse_cargo_toml(cargo)
        if deps:
            dep_files.append(DepFile(
                path=str(cargo),
                kind="Cargo.toml",
                dependencies=deps,
            ))

    # go.mod
    for gomod in base.rglob("go.mod"):
        deps = _parse_go_mod(gomod)
        if deps:
            dep_files.append(DepFile(
                path=str(gomod),
                kind="go.mod",
                dependencies=deps,
            ))

    return dep_files


def _parse_requirements_txt(path: Path) -> list[Dependency]:
    """Parse requirements.txt for dependencies."""
    deps = []
    try:
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or line.startswith("-"):
                continue
            # Match: package==version, package>=version, package~=version, package
            m = re.match(r"^([a-zA-Z0-9_.-]+)\s*(?:[=~!<>]=?\s*([^\s,;#]+))?", line)
            if m:
                deps.append(Dependency(
                    name=m.group(1),
                    current_version=m.group(2) or "unspecified",
                    dep_file=str(path),
                ))
    except Exception:
        pass
    return deps


def _parse_pyproject_toml(path: Path) -> list[Dependency]:
    """Parse pyproject.toml for dependencies (basic parsing without toml lib)."""
    deps = []
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
        # Look for dependencies list
        in_deps = False
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("dependencies") and "=" in stripped:
                in_deps = True
                continue
            if in_deps:
                if stripped == "]":
                    in_deps = False
                    continue
                # Match quoted dependency strings like "requests>=2.28"
                m = re.match(r'["\']([a-zA-Z0-9_.-]+)\s*(?:[=~!<>]=?\s*([^\s,;"\']+))?', stripped)
                if m:
                    deps.append(Dependency(
                        name=m.group(1),
                        current_version=m.group(2) or "unspecified",
                        dep_file=str(path),
                    ))
    except Exception:
        pass
    return deps


def _parse_package_json(path: Path) -> list[Dependency]:
    """Parse package.json for dependencies."""
    deps = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        for section in ("dependencies", "devDependencies"):
            for name, version in data.get(section, {}).items():
                deps.append(Dependency(
                    name=name,
                    current_version=version.lstrip("^~>=<"),
                    dep_file=str(path),
                ))
    except Exception:
        pass
    return deps


def _parse_cargo_toml(path: Path) -> list[Dependency]:
    """Parse Cargo.toml for dependencies (basic parsing)."""
    deps = []
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
        in_deps = False
        for line in content.splitlines():
            stripped = line.strip()
            if stripped in ("[dependencies]", "[dev-dependencies]", "[build-dependencies]"):
                in_deps = True
                continue
            if stripped.startswith("[") and in_deps:
                in_deps = False
                continue
            if in_deps and "=" in stripped:
                # Simple: name = "version" or name = { version = "x" }
                m = re.match(r'([a-zA-Z0-9_-]+)\s*=\s*"([^"]*)"', stripped)
                if m:
                    deps.append(Dependency(
                        name=m.group(1),
                        current_version=m.group(2),
                        dep_file=str(path),
                    ))
                else:
                    # Table form: name = { version = "x", ... }
                    m2 = re.match(r'([a-zA-Z0-9_-]+)\s*=\s*\{.*version\s*=\s*"([^"]*)"', stripped)
                    if m2:
                        deps.append(Dependency(
                            name=m2.group(1),
                            current_version=m2.group(2),
                            dep_file=str(path),
                        ))
    except Exception:
        pass
    return deps


def _parse_go_mod(path: Path) -> list[Dependency]:
    """Parse go.mod for dependencies."""
    deps = []
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
        in_require = False
        for line in content.splitlines():
            stripped = line.strip()
            if stripped.startswith("require ("):
                in_require = True
                continue
            if stripped == ")" and in_require:
                in_require = False
                continue
            if in_require:
                parts = stripped.split()
                if len(parts) >= 2 and not parts[0].startswith("//"):
                    deps.append(Dependency(
                        name=parts[0],
                        current_version=parts[1],
                        dep_file=str(path),
                    ))
            elif stripped.startswith("require "):
                parts = stripped.split()
                if len(parts) >= 3:
                    deps.append(Dependency(
                        name=parts[1],
                        current_version=parts[2],
                        dep_file=str(path),
                    ))
    except Exception:
        pass
    return deps


def format_dep_report(dep_files: list[DepFile]) -> str:
    """Format dependency scan results as a readable report."""
    if not dep_files:
        return "No dependency files found."

    lines = []
    total_deps = 0
    for df in dep_files:
        rel_path = df.path
        try:
            rel_path = os.path.relpath(df.path)
        except ValueError:
            pass
        lines.append(f"\n  {df.kind}: {rel_path}")
        lines.append(f"  {'─' * 50}")
        for dep in df.dependencies:
            vuln_flag = " [VULN]" if dep.has_vulnerability else ""
            latest = f" -> {dep.latest_version}" if dep.latest_version and dep.latest_version != dep.current_version else ""
            lines.append(f"    {dep.name:30s} {dep.current_version:15s}{latest}{vuln_flag}")
            if dep.vulnerability_info:
                lines.append(f"      {dep.vulnerability_info}")
            total_deps += 1
        lines.append("")

    lines.insert(0, f"  Found {total_deps} dependencies across {len(dep_files)} files:")
    return "\n".join(lines)


def suggest_update_commands(dep_files: list[DepFile]) -> str:
    """Generate update commands for each dependency file type."""
    lines = []
    seen_kinds = set()

    for df in dep_files:
        if df.kind in seen_kinds:
            continue
        seen_kinds.add(df.kind)
        rel_path = df.path
        try:
            rel_path = os.path.relpath(df.path)
        except ValueError:
            pass

        if df.kind == "requirements.txt":
            lines.append(f"  # Update Python deps ({rel_path}):")
            lines.append(f"    pip install --upgrade -r {rel_path}")
            lines.append(f"    pip-compile --upgrade {rel_path}  # if using pip-tools")
            lines.append("")
        elif df.kind == "pyproject.toml":
            lines.append(f"  # Update Python deps ({rel_path}):")
            lines.append(f"    pip install --upgrade .")
            lines.append("")
        elif df.kind == "package.json":
            pkg_dir = os.path.dirname(rel_path) or "."
            lines.append(f"  # Update Node deps ({rel_path}):")
            lines.append(f"    cd {pkg_dir} && npm update")
            lines.append(f"    cd {pkg_dir} && npm outdated  # check for major updates")
            lines.append(f"    cd {pkg_dir} && npx npm-check-updates -u  # update package.json")
            lines.append("")
        elif df.kind == "Cargo.toml":
            lines.append(f"  # Update Rust deps ({rel_path}):")
            lines.append(f"    cargo update")
            lines.append("")
        elif df.kind == "go.mod":
            lines.append(f"  # Update Go deps ({rel_path}):")
            lines.append(f"    go get -u ./...")
            lines.append(f"    go mod tidy")
            lines.append("")

    if not lines:
        return "  No dependency files found to update."
    return "\n".join(lines)


def run_audit(dep_files: list[DepFile]) -> str:
    """Run security audit tools for detected dependency types."""
    lines = []
    seen_kinds = set()

    for df in dep_files:
        if df.kind in seen_kinds:
            continue
        seen_kinds.add(df.kind)
        rel_path = df.path
        try:
            rel_path = os.path.relpath(df.path)
        except ValueError:
            pass
        pkg_dir = os.path.dirname(df.path) or os.getcwd()

        if df.kind in ("requirements.txt", "pyproject.toml"):
            lines.append(f"\n  Python audit ({rel_path}):")
            lines.append(f"  {'─' * 40}")
            output, code = _run("pip-audit", cwd=pkg_dir)
            if code == 1 and "not found" in output.lower():
                # Try safety as fallback
                output, code = _run("safety check", cwd=pkg_dir)
                if code == 1 and "not found" in output.lower():
                    lines.append("    pip-audit and safety not installed.")
                    lines.append("    Install: pip install pip-audit")
                else:
                    lines.append(f"    {output}")
            else:
                for line in output.splitlines()[:30]:
                    lines.append(f"    {line}")

        elif df.kind == "package.json":
            lines.append(f"\n  npm audit ({rel_path}):")
            lines.append(f"  {'─' * 40}")
            output, code = _run(["npm", "audit", "--json"], cwd=pkg_dir, timeout=120)
            if code == 1 and "not found" in output.lower():
                lines.append("    npm not found on PATH.")
            else:
                try:
                    audit_data = json.loads(output.split("\n")[0] if output else "{}")
                    vulns = audit_data.get("vulnerabilities", {})
                    if not vulns:
                        lines.append("    No vulnerabilities found.")
                    else:
                        for name, info in list(vulns.items())[:20]:
                            sev = info.get("severity", "unknown")
                            lines.append(f"    {sev.upper():10s} {name}: {info.get('title', 'N/A')}")
                except (json.JSONDecodeError, IndexError):
                    for line in output.splitlines()[:20]:
                        lines.append(f"    {line}")

        elif df.kind == "Cargo.toml":
            lines.append(f"\n  Cargo audit ({rel_path}):")
            lines.append(f"  {'─' * 40}")
            output, code = _run(["cargo", "audit"], cwd=pkg_dir)
            if code == 1 and "not found" in output.lower():
                lines.append("    cargo-audit not installed.")
                lines.append("    Install: cargo install cargo-audit")
            else:
                for line in output.splitlines()[:30]:
                    lines.append(f"    {line}")

    if not lines:
        return "  No dependency files found to audit."
    return "\n".join(lines)


def _run(args, cwd=None, timeout=60):
    """Wrapper that accepts string or list."""
    if isinstance(args, str):
        args = args.split()
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd or os.getcwd(),
        )
        output = result.stdout or ""
        if result.stderr:
            if output:
                output += "\n"
            output += result.stderr
        return output.strip(), result.returncode
    except FileNotFoundError:
        return f"[error: {args[0]} not found on PATH]", 1
    except subprocess.TimeoutExpired:
        return f"[error: timed out after {timeout}s]", 1
    except Exception as e:
        return f"[error: {e}]", 1
