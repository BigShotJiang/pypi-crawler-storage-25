"""Interactive REPL — Claude Code style interface in blue."""

import os
import sys
import time
import re
import io
import json

from rich.console import Console, Group
from rich.markdown import Markdown
from rich.panel import Panel
from rich.prompt import Confirm
from rich.text import Text
from rich.rule import Rule
from rich.live import Live
from rich.layout import Layout
from rich.columns import Columns

from .config import DEFAULT_MODEL, DEFAULT_PERMISSION_MODE, MAX_CONTEXT_TOKENS, MAX_TURNS_PER_MESSAGE, MAX_SESSION_TOKENS, load_project_instructions
from .llm import chat_with_tools_stream, build_system_prompt, check_connection, list_models, get_ollama_tools
from .session import Session
from .permissions import PermissionManager
from .tool_executor import execute_tool, format_tool_result, get_last_bash_failure, clear_last_bash_failure
from .auto_fix import is_enabled as autofix_enabled, toggle as autofix_toggle, build_fix_prompt, MAX_FIX_ATTEMPTS
from .watch_mode import get_watcher, start_watch, stop_watch
from .branching import BranchManager
from .theme import VAAL_THEME, VAAL_BLUE, VAAL_BLUE_DIM, VAAL_CYAN, VAAL_GREEN, VAAL_RED, VAAL_YELLOW, VAAL_DIM, VAAL_CRIMSON, VAAL_GOLD, TOOL_PREFIX, SPINNER_FRAMES
from .history import record_prompt
from .user_config import UserConfig
from .keybindings import KeybindingManager
from .model_manager import init_manager, get_manager, pull_model, remove_model, is_first_run
from .output_styles import OutputStyleManager
from .context import ContextManager
from .cost_tracker import CostTracker
from .bootstrap import scan_project, load_cached_project
from .task_manager import get_task_manager, reset_task_manager, TaskStatus, STATUS_ICONS, STATUS_STYLES
from .agent import get_agent_pool, reset_agent_pool
from .image_input import is_image_path, encode_image, build_image_message, build_ollama_image_message, get_clipboard_image

# Lazy-loaded imports (only used in specific command handlers or run_repl init):
# .changelog (build_changelog, build_changelog_for_session) -> /changelog
# .history (load_history, format_history) -> /history
# .vim_mode (VimMode) -> run_repl init
# .voice (VoiceInput) -> run_repl init
# .mcp_client (get_mcp_manager) -> /mcp
# .scheduler (get_scheduler) -> /schedule
# .split_pane (SplitPane) -> /split
# .notifications (get_notification_manager) -> /notify
# .undo_system (get_undo_system) -> /undo, /redo
# .env_manager (EnvManager) -> /env

from ..tools import bash_tool, file_tools, search_tools, agent_tools, notebook_tools, lsp_tools, git_tools, web_tools, diff_tools, memory_tools, ssh_tools
from ..tools import db_tools, api_tools, todo_tools, plugin_tools, interaction_tools
from ..tools.registry import all_tools

_out = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace") if sys.platform == "win32" else sys.stdout
console = Console(theme=VAAL_THEME, file=_out, force_terminal=True)

MAX_TOOL_ROUNDS = 15

_debug_tools = False

# ── Session file tracking ───────────────────────────────────────────
_session_files: dict[str, str] = {}  # path -> last_action (read/written/edited)

# ── Pinned files ────────────────────────────────────────────────────
_pinned_files: list[str] = []

# ── Error loop detection ────────────────────────────────────────────
_recent_errors: list[str] = []

# ── Effort level ────────────────────────────────────────────────────
_effort_level = "high"

# ── Status tracking ──────────────────────────────────────────────────
# Approximate $/1M token pricing for cost estimation
CLOUD_PRICING = {
    "claude-opus-4-6": {"input": 15.0, "output": 75.0},
    "claude-sonnet-4-6": {"input": 3.0, "output": 15.0},
    "claude-haiku-4-5": {"input": 0.8, "output": 4.0},
    "gpt-4o": {"input": 2.5, "output": 10.0},
    "gpt-4o-mini": {"input": 0.15, "output": 0.6},
    "gpt-4.1": {"input": 2.0, "output": 8.0},
    "gpt-4.1-mini": {"input": 0.4, "output": 1.6},
    "gpt-4.1-nano": {"input": 0.1, "output": 0.4},
    "o3": {"input": 10.0, "output": 40.0},
    "o4-mini": {"input": 1.1, "output": 4.4},
    "deepseek-chat": {"input": 0.27, "output": 1.10},
    "deepseek-reasoner": {"input": 0.55, "output": 2.19},
}


def _beautify_model_name(model: str) -> str:
    """Make model names pretty for display."""
    mapping = {
        "qwen3:8b": "Qwen 3 8B",
        "qwen3:4b": "Qwen 3 4B",
        "qwen3.5:9b": "Qwen 3.5 9B",
        "qwen3.5:27b": "Qwen 3.5 27B",
        "qwen2.5:14b": "Qwen 2.5 14B",
        "qwen2.5:32b": "Qwen 2.5 32B",
        "qwen2.5:72b": "Qwen 2.5 72B",
        "qwen3.5-9b-heretic": "Qwen 3.5 9B Heretic",
        "mistral:7b": "Mistral 7B",
        "llama3.1:70b": "Llama 3.1 70B",
        "anthropic:claude-opus-4-6": "Claude Opus 4.6",
        "anthropic:claude-sonnet-4-6": "Claude Sonnet 4.6",
        "anthropic:claude-haiku-4-5-20251001": "Claude Haiku 4.5",
        "openai:gpt-4o": "GPT-4o",
        "openai:gpt-4o-mini": "GPT-4o Mini",
        "openai:o3": "o3",
        "codex:o3": "o3 (Codex)",
        "codex:o4-mini": "o4-mini (Codex)",
        "codex:gpt-4.1": "GPT-4.1 (Codex)",
        "codex:gpt-4.1-mini": "GPT-4.1 Mini (Codex)",
        "codex:gpt-4.1-nano": "GPT-4.1 Nano (Codex)",
        "groq:llama-3.3-70b-versatile": "Llama 3.3 70B (Groq)",
        "deepseek:deepseek-chat": "DeepSeek V3",
        "deepseek:deepseek-reasoner": "DeepSeek R1",
    }
    return mapping.get(model, model)


def _is_cloud_model(model: str) -> bool:
    from .providers import parse_model_string
    prov, _ = parse_model_string(model)
    return prov != "ollama"


def _is_anthropic_model(model: str) -> bool:
    from .providers import parse_model_string
    prov, _ = parse_model_string(model)
    return prov == "anthropic"


def _get_cloud_label(model: str) -> str:
    """Get the auth label for a cloud model."""
    from .providers import parse_model_string, get_api_key
    prov, _ = parse_model_string(model)
    if prov == "ollama":
        return "local"
    key = get_api_key(prov)
    if not key:
        return "no key"
    if key.startswith("sk-ant-si-"):
        return "max"  # Bridge JWT = Max subscription
    if key.startswith("sk-ant-oat"):
        return "pro"  # OAuth token = Pro/Max
    return "api"


class Stats:
    def __init__(self):
        self.total_tokens = 0
        self.total_time = 0.0
        self.tool_calls = 0
        self.messages = 0
        self.model = ""
        self.est_cost = 0.0  # Estimated cost in $ for cloud models
        self.tool_usage: dict[str, int] = {}  # per-tool call counts
        self.session_start = time.time()  # when this session started

    def record_cloud_usage(self, model: str, input_tokens: int, output_tokens: int):
        """Estimate cost for cloud API usage."""
        from .providers import parse_model_string
        _, model_id = parse_model_string(model)
        # Match pricing by prefix
        for key, pricing in CLOUD_PRICING.items():
            if key in model_id:
                self.est_cost += (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000
                break

    def status_line(self) -> Text:
        avg_tps = self.total_tokens / self.total_time if self.total_time > 0 else 0
        pretty = _beautify_model_name(self.model)
        is_cloud = _is_cloud_model(self.model)

        line = Text()
        line.append("─ ", style="dim")
        line.append(f"{pretty}", style=f"bold {VAAL_BLUE}")
        if is_cloud:
            label = _get_cloud_label(self.model)
            line.append(f" ({label})", style="dim")
        line.append(f" · ", style="dim")
        line.append(f"{self.total_tokens} tokens", style="dim")
        line.append(f" · ", style="dim")
        if is_cloud and self.est_cost > 0:
            line.append(f"~${self.est_cost:.4f}", style="dim")
        else:
            line.append(f"{avg_tps:.0f} tok/s", style="dim")
        line.append(f" · ", style="dim")
        line.append(f"{self.tool_calls} tools", style="dim")
        line.append(f" · ", style="dim")
        line.append(f"{self.messages} msgs", style="dim")

        # Show agent/task status if any are active
        pool = get_agent_pool()
        agent_summary = pool.status_summary()
        if agent_summary:
            line.append(f" · ", style="dim")
            line.append(agent_summary, style=VAAL_YELLOW)

        tm = get_task_manager()
        task_summary = tm.summary
        if tm.list_all():
            line.append(f" · ", style="dim")
            line.append(task_summary, style=VAAL_GREEN)

        line.append(f" ─", style="dim")
        return line

stats = Stats()


# ── Text-based tool calling (fallback for models without native tool support) ──

_TEXT_TOOL_INSTRUCTIONS = """\
Your native tool calling is not working. Instead, output tool calls as XML tags in your response text.

FORMAT — wrap each tool call in <tool_call> tags with a JSON object:
<tool_call>{"name": "TOOL_NAME", "arguments": {"param": "value"}}</tool_call>

AVAILABLE TOOLS:
- glob: Find files. Args: pattern (required), path (optional)
  <tool_call>{"name": "glob", "arguments": {"pattern": "**/*.py"}}</tool_call>

- read: Read a file. Args: file_path (required), offset, limit (optional)
  <tool_call>{"name": "read", "arguments": {"file_path": "/absolute/path/file.py"}}</tool_call>

- write: Create/overwrite a file. Args: file_path, content (required)
  <tool_call>{"name": "write", "arguments": {"file_path": "/path/new.py", "content": "print('hello')"}}</tool_call>

- edit: Edit a file. Args: file_path, old_string, new_string (required)
  <tool_call>{"name": "edit", "arguments": {"file_path": "/path/file.py", "old_string": "old code", "new_string": "new code"}}</tool_call>

- bash: Run a shell command. Args: command (required)
  <tool_call>{"name": "bash", "arguments": {"command": "ls -la"}}</tool_call>

- grep: Search file contents. Args: pattern (required), path (optional)
  <tool_call>{"name": "grep", "arguments": {"pattern": "def main", "path": "/project/src"}}</tool_call>

RULES:
1. Output ONE tool call at a time, then STOP and wait for the result.
2. After you see the tool result, decide what to do next.
3. Use absolute paths.
4. Do NOT output code as text — use write/edit tools.

Now do the task. Start by calling glob or read to explore the codebase."""


# ── Text tool call extraction (fallback for local models) ────────────

def _extract_text_tool_calls(text: str) -> list[dict]:
    """Try to extract tool calls from text output.

    Some local models (Qwen, Llama) sometimes output tool calls as JSON
    in the response text instead of using the native tool calling API.
    Common patterns:
    - {"name": "read", "arguments": {"file_path": "..."}}
    - ```json\n{"name": "tool", ...}\n```
    - <tool_call>{"name": "tool", ...}</tool_call>
    """
    import re

    calls = []

    # Pattern 1: <tool_call>...</tool_call> tags (Qwen 3 uses these)
    tag_matches = re.findall(r'<tool_call>\s*(\{.*?\})\s*</tool_call>', text, re.DOTALL)
    for match in tag_matches:
        tc = _parse_tool_json(match)
        if tc:
            calls.append(tc)

    if calls:
        return calls

    # Pattern 2: ```json blocks containing tool calls
    json_blocks = re.findall(r'```(?:json)?\s*(\{[^`]*\})\s*```', text, re.DOTALL)
    for block in json_blocks:
        tc = _parse_tool_json(block)
        if tc:
            calls.append(tc)

    if calls:
        return calls

    # Pattern 3: Raw JSON object with "name" and "arguments" keys
    # Only try this if the entire text looks like a single JSON call
    stripped = text.strip()
    if stripped.startswith("{") and stripped.endswith("}"):
        tc = _parse_tool_json(stripped)
        if tc:
            calls.append(tc)

    return calls


def _parse_tool_json(text: str) -> dict | None:
    """Try to parse a JSON string as a tool call."""
    try:
        data = json.loads(text)
        if not isinstance(data, dict):
            return None

        # Format: {"name": "tool_name", "arguments": {...}}
        name = data.get("name", "")
        args = data.get("arguments", data.get("parameters", {}))
        if name and isinstance(args, dict):
            return {
                "id": f"tool_{name}",
                "function": {"name": name, "arguments": args},
            }

        # Format: {"function": {"name": "...", "arguments": {...}}}
        func = data.get("function", {})
        if func.get("name"):
            args = func.get("arguments", {})
            if isinstance(args, str):
                try:
                    args = json.loads(args)
                except Exception:
                    args = {}
            return {
                "id": f"tool_{func['name']}",
                "function": {"name": func["name"], "arguments": args},
            }
    except (json.JSONDecodeError, TypeError):
        pass
    return None


# ── Display helpers ──────────────────────────────────────────────────

def _write(s: str):
    _out.write(s)
    _out.flush()


def print_status():
    """Print the status bar."""
    console.print(stats.status_line())


def refresh_screen(model: str, mode: str, cwd: str, minimal: bool = False):
    """Clear screen and reprint the header — used on init and model change."""
    _write("\033[2J\033[H")  # Clear screen, cursor to top
    print_header(model, mode, cwd, minimal=minimal)


def print_header(model: str, mode: str, cwd: str, minimal: bool = False):
    try:
        from vaal import __version__
    except Exception:
        __version__ = "0.6.210"

    short_cwd = cwd.replace("\\", "/")
    home = os.path.expanduser("~").replace("\\", "/")
    if short_cwd.startswith(home):
        short_cwd = "~" + short_cwd[len(home):]

    pretty = _beautify_model_name(model)
    is_cloud = _is_cloud_model(model)
    cloud_tag = f"({_get_cloud_label(model)})" if is_cloud else "(local)"

    if minimal:
        C = "\033[38;2;171;43;63m"
        D = "\033[2m"
        R = "\033[0m"
        _write(f"\n{C}\u2733{R} {pretty} {cloud_tag} {D}@ {short_cwd}{R}\n\n")
        return

    try:
        term_w = os.get_terminal_size().columns
    except Exception:
        term_w = 80
    box_w = min(term_w - 2, 70)
    inner = box_w - 2  # space inside the box

    C = "\033[38;2;171;43;63m"    # Crimson
    W = "\033[1;37m"              # Bold white
    D = "\033[2m"                 # Dim
    R = "\033[0m"                 # Reset

    def box_line(text: str, vis_len: int) -> str:
        # inner includes the space after │ so pad = inner - 1 - vis_len
        pad = " " * max(0, inner - 1 - vis_len)
        return f"{C}\u2502{R} {text}{pad}{C}\u2502{R}"

    # Check for project instructions
    project_instructions = load_project_instructions()
    md_count = 0
    if project_instructions:
        for name in ("CLAUDE.md", "VAAL.md", "claude.md", "vaal.md"):
            if os.path.exists(os.path.join(cwd, name)):
                md_count += 1

    md_text = f"{md_count} project instruction file{'s' if md_count != 1 else ''} found"
    model_text = f"model: {pretty} {cloud_tag}"
    cwd_text = f"cwd: {short_cwd}"
    tips_text = "/help for help, /status for your current setup"
    title_text = f"\u2733 Vaal v{__version__}"

    _write(f"\n{C}\u256d{'─' * (box_w - 2)}\u256e{R}\n")
    _write(box_line(f"{W}{title_text}{R}", len(title_text)) + "\n")
    _write(box_line("", 0) + "\n")
    _write(box_line(f"{D}{tips_text}{R}", len(tips_text)) + "\n")
    _write(box_line("", 0) + "\n")
    _write(box_line(f"{D}{cwd_text}{R}", len(cwd_text)) + "\n")
    if md_count:
        _write(box_line(f"{D}{md_text}{R}", len(md_text)) + "\n")
    _write(box_line(f"{D}{model_text}{R}", len(model_text)) + "\n")
    _write(box_line("", 0) + "\n")
    _write(f"{C}\u2570{'─' * (box_w - 2)}\u256f{R}\n\n")


def print_separator():
    """Thin dim line between exchanges."""
    console.print()


def _short_path(path: str) -> str:
    """Shorten a path relative to cwd if possible."""
    try:
        cwd = os.getcwd().replace("\\", "/")
        p = path.replace("\\", "/")
        if p.startswith(cwd + "/"):
            return p[len(cwd) + 1:]
    except Exception:
        pass
    return path


def print_tool_call(name: str, args: dict):
    """Print tool call header — Claude Code style with ⎿ prefix."""
    console.print()

    if _debug_tools:
        console.print(f"  [bold]{name}[/]")
        for k, v in args.items():
            val_str = str(v)
            for line in val_str.splitlines()[:50]:
                console.print(f"  ⎿  [dim]{k}: {line}[/dim]")
        return

    if name == "read":
        path = _short_path(args.get("file_path", args.get("path", "")))
        off = args.get("offset", "")
        lim = args.get("limit", "")
        range_info = ""
        if off or lim:
            range_info = f" [dim](lines {off or '0'}-{int(off or 0) + int(lim or 500)})[/dim]"
        console.print(f"  [bold]Read[/] [dim]{path}[/dim]{range_info}")

    elif name == "edit":
        path = _short_path(args.get("file_path", ""))
        old = args.get("old_string", "")
        preview = old.split("\n")[0][:60] if old else ""
        console.print(f"  [bold]Edit[/] [dim]{path}[/dim]")
        if preview:
            console.print(f"  ⎿  [dim]{preview}{'…' if len(old) > 60 else ''}[/dim]")

    elif name == "write":
        path = _short_path(args.get("file_path", args.get("path", "")))
        content = args.get("content", "")
        line_count = content.count("\n") + 1 if content else 0
        console.print(f"  [bold]Write[/] [dim]{path}[/dim] [dim]({line_count} lines)[/dim]")

    elif name == "bash":
        cmd = args.get("command", "")
        cmd_lines = cmd.strip().split("\n")
        console.print(f"  [bold]Bash[/]")
        for cl in cmd_lines[:3]:
            console.print(f"  ⎿  [dim]$ {cl[:120]}[/dim]")
        if len(cmd_lines) > 3:
            console.print(f"  ⎿  [dim]… {len(cmd_lines) - 3} more lines[/dim]")

    elif name == "glob":
        pat = args.get("pattern", "")
        path = args.get("path", ".")
        console.print(f"  [bold]Glob[/] [dim]{pat}[/dim] [dim]in {_short_path(path)}[/dim]")

    elif name == "grep":
        pat = args.get("pattern", "")
        path = args.get("path", ".")
        console.print(f"  [bold]Grep[/] [dim]/{pat}/[/dim] [dim]in {_short_path(path)}[/dim]")

    elif name == "web_fetch":
        url = args.get("url", "")
        console.print(f"  [bold]Fetch[/] [dim]{url}[/dim]")

    elif name == "web_search":
        query = args.get("query", "")
        console.print(f"  [bold]Search[/] [dim]\"{query}\"[/dim]")

    elif name == "api_request":
        method = args.get("method", "GET").upper()
        url = args.get("url", "")
        console.print(f"  [bold]{method}[/] [dim]{url}[/dim]")

    elif name == "run_python":
        code = args.get("code", "")
        first_line = code.split("\n")[0][:80]
        total = code.count("\n") + 1
        console.print(f"  [bold]Python[/] [dim]{first_line}{'…' if total > 1 else ''}[/dim]")

    elif name == "spawn_agent":
        atype = args.get("agent_type", "general")
        label = args.get("label", "")
        console.print(f"  [bold]Agent[/] [dim]{atype}: {label}[/dim]")

    elif name == "check_agent":
        aid = args.get("agent_id", "?")[:8]
        console.print(f"  [dim]Checking agent {aid}…[/dim]")

    elif name.startswith("git_"):
        action = name.replace("git_", "")
        detail = ""
        if "message" in args:
            detail = f' [dim]"{args["message"][:60]}"[/dim]'
        elif "branch" in args:
            detail = f" [dim]{args['branch']}[/dim]"
        console.print(f"  [bold]Git {action}[/]{detail}")

    elif name.startswith("todo_"):
        action = name.replace("todo_", "")
        title = args.get("title", args.get("id", ""))
        console.print(f"  [bold]Todo {action}[/] [dim]{title}[/dim]")

    elif name.startswith("notebook_"):
        action = "Read" if "read" in name else "Edit"
        path = _short_path(args.get("path", ""))
        console.print(f"  [bold]Notebook {action}[/] [dim]{path}[/dim]")

    elif name in ("find_definition", "find_references", "list_symbols"):
        symbol = args.get("symbol", args.get("file_path", ""))
        console.print(f"  [bold]{name.replace('_', ' ').title()}[/] [dim]{symbol}[/dim]")

    elif name == "file_tree":
        path = _short_path(args.get("path", "."))
        console.print(f"  [bold]File Tree[/] [dim]{path}[/dim]")

    elif name == "create_plugin":
        pname = args.get("plugin_name", "")
        console.print(f"  [bold]Create Plugin[/] [dim]{pname}[/dim]")

    else:
        detail_parts = []
        for k in ("file_path", "path", "url", "query", "command", "name", "task"):
            if k in args:
                detail_parts.append(str(args[k])[:80])
        detail = " ".join(detail_parts)
        console.print(f"  [bold]{name}[/] [dim]{detail}[/dim]")


def print_tool_result(name: str, result: str):
    """Print styled tool call + result in Claude Code style — compact one-liners."""
    if _debug_tools:
        lines = result.splitlines()
        for line in lines[:200]:
            console.print(f"  ⎿  [dim]{line}[/dim]")
        if len(lines) > 200:
            console.print(f"  ⎿  [dim]… {len(lines) - 200} more lines[/dim]")
        return

    if name == "read":
        lines = result.splitlines()
        console.print(f"  ⎿  [dim]{len(lines)} lines[/dim]")

    elif name == "edit":
        if "error" in result.lower() or "not found" in result.lower():
            console.print(f"  ⎿  [bold red]{result.strip()[:100]}[/]")
        else:
            rlines = result.strip().splitlines()
            console.print(f"  ⎿  [dim]{rlines[0][:80] if rlines else 'done'}[/dim]")

    elif name == "write":
        if "error" in result.lower():
            console.print(f"  ⎿  [bold red]{result.strip()[:100]}[/]")
        else:
            console.print(f"  ⎿  [dim]wrote file[/dim]")

    elif name == "bash":
        lines = result.strip().splitlines()
        if not lines:
            console.print(f"  ⎿  [dim](no output)[/dim]")
        elif len(lines) <= 8:
            for line in lines:
                console.print(f"  ⎿  [dim]{line}[/dim]")
        else:
            for line in lines[:6]:
                console.print(f"  ⎿  [dim]{line}[/dim]")
            console.print(f"  ⎿  [dim]… {len(lines) - 6} more lines[/dim]")

    elif name in ("glob", "grep"):
        lines = [l for l in result.strip().splitlines() if l.strip()]
        if not lines:
            console.print(f"  ⎿  [dim]No matches[/dim]")
        else:
            console.print(f"  ⎿  [dim]{len(lines)} match{'es' if len(lines) != 1 else ''}[/dim]")
            for line in lines[:5]:
                console.print(f"     [dim]{line[:100]}[/dim]")
            if len(lines) > 5:
                console.print(f"     [dim]… {len(lines) - 5} more[/dim]")

    elif name == "spawn_agent":
        try:
            import json as _json
            data = _json.loads(result)
            agent_id = data.get("agent_id", "?")[:8]
            console.print(f"  ⎿  [dim]spawned id={agent_id}[/dim]")
        except Exception:
            console.print(f"  ⎿ [dim]{result[:80]}[/dim]")

    elif name == "check_agent":
        try:
            import json as _json
            data = _json.loads(result)
            status = data.get("status", "?")
            label = data.get("label", "")
            elapsed = data.get("elapsed", "")
            rounds = data.get("rounds", "")
            tools = data.get("tool_calls", "")
            style = VAAL_GREEN if status == "complete" else (VAAL_YELLOW if status in ("thinking", "running_tool") else "dim")
            detail_parts = [f"[{style}]{status}[/]"]
            if label:
                detail_parts.append(f"[dim]{label}[/dim]")
            if elapsed:
                detail_parts.append(f"[dim]{elapsed}[/dim]")
            if rounds:
                detail_parts.append(f"[dim]{rounds} rounds[/dim]")
            if tools:
                detail_parts.append(f"[dim]{tools} tools[/dim]")
            console.print(f"  ⎿  {' · '.join(detail_parts)}")
            if data.get("output"):
                out_lines = data["output"].strip().splitlines()
                for line in out_lines[:6]:
                    console.print(f"     [dim]{line}[/dim]")
                if len(out_lines) > 4:
                    console.print(f"  ⎿  [dim]… {len(out_lines) - 4} more lines[/dim]")
        except Exception:
            console.print(f"\n  [dim]{result[:80]}[/dim]")

    elif name == "list_agents":
        try:
            import json as _json
            data = _json.loads(result)
            agents = data.get("agents", [])
            if not agents:
                console.print(f"\n  [dim]No agents[/dim]")
            else:
                console.print()
                for a in agents[:8]:
                    s = a.get("status", "?")
                    style = VAAL_GREEN if s == "complete" else (VAAL_YELLOW if s in ("thinking", "running_tool") else "dim")
                    console.print(f"  [{style}]{s:12}[/] [dim]{a.get('label', a.get('id', '?'))}[/dim]")
        except Exception:
            console.print(f"\n  [dim]{result[:80]}[/dim]")

    elif name in ("todo_create", "todo_update", "todo_list"):
        try:
            import json as _json
            data = _json.loads(result)
            if "todos" in data:
                todos = data.get("todos", [])
                summary = data.get("summary", f"{len(todos)} todos")
                console.print(f"\n  [dim]{summary}[/dim]")
            else:
                console.print(f"\n  [dim]{data.get('message', result[:60])}[/dim]")
        except Exception:
            console.print(f"\n  [dim]{result[:60]}[/dim]")

    elif name == "web_fetch":
        lines = result.strip().splitlines()
        console.print(f"  ⎿  [dim]{len(lines)} lines[/dim]")
        for line in lines[:3]:
            console.print(f"     [dim]{line[:100]}[/dim]")
        if len(lines) > 3:
            console.print(f"     [dim]… {len(lines) - 3} more lines[/dim]")

    elif name == "web_search":
        lines = result.strip().splitlines()
        console.print(f"  ⎿  [dim]{len(lines)} results[/dim]")
        for line in lines[:4]:
            console.print(f"     [dim]{line[:100]}[/dim]")
        if len(lines) > 4:
            console.print(f"     [dim]… {len(lines) - 4} more lines[/dim]")

    elif name == "api_request":
        lines = result.strip().splitlines()
        for line in lines[:6]:
            if "status" in line.lower() or "time" in line.lower():
                console.print(f"  ⎿  [bold]{line}[/]")
            else:
                console.print(f"  ⎿  [dim]{line[:100]}[/dim]")
        if len(lines) > 6:
            console.print(f"  ⎿  [dim]… {len(lines) - 6} more lines[/dim]")

    elif name in ("git_status", "git_diff", "git_log", "git_branch", "git_stash",
                   "git_commit", "git_worktree_list", "git_worktree_create", "git_worktree_remove"):
        lines = result.strip().splitlines()
        if len(lines) <= 5:
            for line in lines:
                console.print(f"  ⎿  [dim]{line}[/dim]")
        else:
            for line in lines[:3]:
                console.print(f"  ⎿  [dim]{line}[/dim]")
            console.print(f"  ⎿  [dim]… {len(lines) - 3} more lines[/dim]")

    elif name in ("find_definition", "find_references", "list_symbols", "file_tree"):
        lines = result.strip().splitlines()
        console.print(f"  ⎿  [dim]{len(lines)} result{'s' if len(lines) != 1 else ''}[/dim]")

    else:
        # Generic — compact
        lines = result.strip().splitlines()
        if not lines:
            return
        if len(lines) <= 4:
            for line in lines:
                console.print(f"  ⎿  [dim]{line[:100]}[/dim]")
        else:
            for line in lines[:3]:
                console.print(f"  ⎿  [dim]{line[:100]}[/dim]")
            console.print(f"  ⎿  [dim]… {len(lines) - 3} more lines[/dim]")


def render_assistant_message(text: str):
    """Render assistant response as styled markdown."""
    console.print()
    try:
        md = Markdown(text, code_theme="monokai")
        console.print(md, width=min(console.width - 4, 90))
    except Exception:
        console.print(text)
    console.print()


def ask_tool_permission(name: str, params: dict) -> bool:
    console.print()
    console.print(f"  [bold]Allow {name}?[/]")
    for k, v in params.items():
        display = str(v)[:200]
        console.print(f"  ⎿  [dim]{k}: {display}[/dim]")
    console.print()
    return Confirm.ask(f"  [bold]y/n[/]", default=True)


# ── Streaming ────────────────────────────────────────────────────────

def _sanitize_messages(messages: list[dict]) -> list[dict]:
    """Fix message sequences for Anthropic API compatibility.

    Anthropic requires:
    - Strict user/assistant alternation
    - tool_result must follow an assistant message with tool_use
    - No consecutive same-role messages (except system at start)
    - Content must be string or list of content blocks
    """
    if not messages:
        return messages

    cleaned = []

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")

        # Skip empty messages
        if not content and role != "system":
            continue

        # Convert tool messages to user messages with tool_result blocks
        if role == "tool":
            tool_use_id = msg.get("tool_use_id", "tool_0")
            content_str = content if isinstance(content, str) else str(content)
            new_msg = {
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": tool_use_id, "content": content_str}],
            }
            # Merge with previous user message if it's also tool_result
            if cleaned and cleaned[-1]["role"] == "user" and isinstance(cleaned[-1]["content"], list):
                last_content = cleaned[-1]["content"]
                if last_content and isinstance(last_content[0], dict) and last_content[0].get("type") == "tool_result":
                    cleaned[-1]["content"].append(new_msg["content"][0])
                    continue
            cleaned.append(new_msg)
            continue

        # Merge consecutive same-role messages
        if cleaned and cleaned[-1]["role"] == role and role != "system":
            prev_content = cleaned[-1]["content"]
            # Both strings — concatenate
            if isinstance(prev_content, str) and isinstance(content, str):
                cleaned[-1]["content"] = prev_content + "\n" + content
            # Both lists — extend
            elif isinstance(prev_content, list) and isinstance(content, list):
                cleaned[-1]["content"].extend(content)
            # Mixed — convert to string
            elif isinstance(prev_content, str) and isinstance(content, list):
                text_parts = [prev_content]
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                cleaned[-1]["content"] = "\n".join(text_parts)
            continue

        # Ensure assistant content with tool_use blocks is valid
        if role == "assistant" and isinstance(content, list):
            # Make sure all blocks have required fields
            valid_blocks = []
            for block in content:
                if isinstance(block, dict):
                    if block.get("type") == "tool_use":
                        if "id" in block and "name" in block:
                            valid_blocks.append(block)
                    elif block.get("type") == "text":
                        valid_blocks.append(block)
                    else:
                        valid_blocks.append(block)
            if valid_blocks:
                cleaned.append({**msg, "content": valid_blocks})
            elif content:
                # Fallback — convert to text
                cleaned.append({**msg, "content": str(content)})
            continue

        cleaned.append(msg)

    # Final check: ensure first non-system message is user role
    first_non_system = next((i for i, m in enumerate(cleaned) if m["role"] != "system"), None)
    if first_non_system is not None and cleaned[first_non_system]["role"] != "user":
        # Insert a placeholder user message
        cleaned.insert(first_non_system, {"role": "user", "content": "(continuing conversation)"})

    # Ensure last message before assistant response isn't assistant
    # (the API call sends these messages then expects an assistant response)
    if cleaned and cleaned[-1]["role"] == "assistant":
        # The most recent message is assistant — this means we're in a tool-call loop
        # and need a user message (tool_result) after it. If there isn't one,
        # the API will fail. This shouldn't happen normally but catches edge cases.
        pass

    return cleaned


def _flatten_messages(messages: list[dict]) -> list[dict]:
    """Nuclear option: strip all structured content and tool messages.

    Converts everything to plain user/assistant text messages so the
    conversation can continue even with corrupted history.
    """
    flat = []
    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "")

        # Keep system messages as-is
        if role == "system":
            flat.append({"role": "system", "content": content if isinstance(content, str) else str(content)})
            continue

        # Skip tool messages entirely
        if role == "tool":
            continue

        # Flatten structured content to text
        if isinstance(content, list):
            text_parts = []
            for block in content:
                if isinstance(block, dict):
                    if block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif block.get("type") == "tool_use":
                        text_parts.append(f"(used tool: {block.get('name', '?')})")
                    elif block.get("type") == "tool_result":
                        text_parts.append(f"(tool result)")
            content = " ".join(text_parts) if text_parts else "(structured content)"

        if not isinstance(content, str):
            content = str(content)

        if not content.strip():
            continue

        # Merge consecutive same-role
        if flat and flat[-1]["role"] == role:
            flat[-1]["content"] += "\n" + content
        else:
            flat.append({"role": role, "content": content})

    # Make sure it ends with user message
    if flat and flat[-1]["role"] != "user":
        flat.append({"role": "user", "content": "(please continue)"})

    return flat


_empty_retries = 0

def stream_response(chat_messages, ollama_tools, model, think):
    """Stream response, then render final result as rich markdown.
    Returns (content, tool_calls, eval_count, eval_duration)."""
    global _empty_retries
    content = ""
    tool_calls = []
    eval_count = 0
    eval_duration = 0
    in_think_tag = False
    showed_thinking = False
    spinner_idx = 0
    token_count = 0
    stream_start = time.time()
    _last_spinner_update = 0.0
    from .buddy import get_orb
    orb = get_orb()
    orb.set_thinking(True)

    # Collect response with animated spinner
    _write(f"\n  \033[2mthinking…\033[0m")

    def _update_spinner(msg: str):
        nonlocal _last_spinner_update, spinner_idx
        now = time.time()
        if now - _last_spinner_update < 0.2:
            return
        _last_spinner_update = now
        spinner_idx += 1
        s = SPINNER_FRAMES[spinner_idx % len(SPINNER_FRAMES)]
        _write(f"\r  \033[2m{s} {msg}\033[0m\033[K")

    for chunk in chat_with_tools_stream(chat_messages, ollama_tools, model=model, think=think):
        _elapsed = int(time.time() - stream_start)

        if chunk.get("thinking"):
            if not showed_thinking:
                showed_thinking = True
            _update_spinner(f"({_elapsed}s · thinking...)")

        if chunk.get("content"):
            token = chunk["content"]

            if in_think_tag:
                if "</think>" in token:
                    in_think_tag = False
                    after = token.split("</think>", 1)[1]
                    if after:
                        content += after
                        token_count += 1
                else:
                    _update_spinner(f"({_elapsed}s · thinking...)")
                continue

            if "<think>" in token:
                in_think_tag = True
                if not showed_thinking:
                    showed_thinking = True
                continue

            content += token
            token_count += 1
            _update_spinner(f"({_elapsed}s · ↓ {token_count} tokens)")

        if chunk.get("tool_calls"):
            tool_calls.extend(chunk["tool_calls"])

        if chunk.get("done"):
            eval_count = chunk.get("eval_count", 0) or token_count
            eval_duration = chunk.get("eval_duration", 0)

    content = content.strip()

    # Clear the spinner line
    _write(f"\r\033[K")

    # Fallback: some local models (Qwen, etc.) output tool calls as JSON text
    # instead of using the native tool calling API. Try to extract them.
    if content and not tool_calls and not _is_cloud_model(model):
        extracted = _extract_text_tool_calls(content)
        if extracted:
            tool_calls = extracted
            # Strip tool call tags from content, keep any surrounding text
            import re as _re
            _cleaned = _re.sub(r'<tool_call>\s*\{.*?\}\s*</tool_call>', '', content, flags=_re.DOTALL).strip()
            _cleaned = _re.sub(r'```(?:json)?\s*\{[^`]*\}\s*```', '', _cleaned, flags=_re.DOTALL).strip()
            content = _cleaned

    if not content and not tool_calls:
        # Empty response handling
        if _is_anthropic_model(model) and _empty_retries < 3:
            _empty_retries += 1
            if _empty_retries <= 1:
                # First retry: re-sanitize messages
                console.print(f"[dim]  (empty response — sanitizing and retrying...)[/dim]")
                clean = _sanitize_messages(chat_messages)
                return stream_response(clean, ollama_tools, model, think)
            else:
                # Nuclear: flatten everything to plain text
                console.print(f"[dim]  (empty response — flattening history...)[/dim]")
                clean_msgs = _flatten_messages(chat_messages)
                return stream_response(clean_msgs, ollama_tools, model, think)
        elif not _is_cloud_model(model):
            from .llm import model_supports_tools, mark_tools_broken
            if ollama_tools and model_supports_tools(model):
                mark_tools_broken(model)
                console.print(f"[dim]  (retrying without tools...)[/dim]")
                return stream_response(chat_messages, None, model, think)
            # Tools already broken or not passed — don't loop, just return empty
        _empty_retries = 0
        orb.set_thinking(False)
        return content, tool_calls, eval_count, eval_duration

    _empty_retries = 0

    # Render final response as rich markdown
    if content:
        console.print()
        try:
            md = Markdown(content, code_theme="monokai")
            console.print(md, width=min(console.width - 4, 90))
        except Exception:
            console.print(content)

    orb.set_thinking(False)
    return content, tool_calls, eval_count, eval_duration


# ── Main REPL ────────────────────────────────────────────────────────

def run_repl(model: str = DEFAULT_MODEL, permission_mode: str = DEFAULT_PERMISSION_MODE, resume: str = None, think: bool = False, minimal: bool = False):
    if not check_connection(model):
        from .providers import parse_model_string, get_api_key
        prov, _ = parse_model_string(model)
        has_key = bool(get_api_key(prov))

        if prov == "ollama" and not has_key:
            # No Ollama and no cloud key — first run setup
            console.print()
            console.print(f"  [bold {VAAL_BLUE}]Welcome to Vaal![/]")
            console.print()
            console.print(f"  [dim]No LLM provider configured. Choose one:[/dim]")
            console.print()
            console.print(f"  [bold]1.[/] Install Ollama (free, local) — https://ollama.ai")
            console.print(f"  [bold]2.[/] Use an API key (cloud) — run vaal then use /login")
            console.print(f"  [bold]3.[/] Register at e-e.tools — run vaal then use /register")
            console.print()
            console.print(f"  [dim]To start with a cloud model:[/dim]")
            console.print(f"  [dim]  python -m vaal -m anthropic:claude-sonnet-4-20250514[/dim]")
            console.print()
            # Don't exit — let them into the REPL so they can /login
        elif prov == "ollama":
            console.print(f"[vaal.error]  Cannot connect to Ollama at localhost:11434[/]")
            console.print(f"[dim]  Start Ollama first, or use a cloud model: python -m vaal -m anthropic:claude-sonnet-4-20250514[/dim]")
            sys.exit(1)
        elif not has_key:
            console.print(f"[vaal.error]  No API key for {prov}.[/]")
            console.print(f"[dim]  Run vaal and use: /login {prov} <your-api-key>[/dim]")
            # Don't exit — let them /login
        else:
            console.print(f"[vaal.error]  Cannot connect to {prov}. Check your API key.[/]")
            console.print(f"[dim]  Run: /login {prov} <your-api-key>[/dim]")
            sys.exit(1)

    # Initialize model manager (hardware detection + installed check)
    mgr = init_manager()

    # First-run experience
    first_run = is_first_run()

    # Load user config and initialize components
    user_config = UserConfig()
    keybindings = KeybindingManager()
    from .vim_mode import VimMode
    from .voice import VoiceInput
    vim = VimMode(enabled=user_config.vim_mode)
    voice = VoiceInput()
    styles = OutputStyleManager()
    styles.set_style(user_config.output_style)

    # Use saved model/mode if not explicitly overridden
    if model == DEFAULT_MODEL and user_config.default_model != DEFAULT_MODEL:
        model = user_config.default_model
    if permission_mode == DEFAULT_PERMISSION_MODE and user_config.permission_mode != DEFAULT_PERMISSION_MODE:
        permission_mode = user_config.permission_mode

    permissions = PermissionManager(mode=permission_mode)
    permissions.internet_enabled = user_config.internet_enabled

    # Initialize context manager — cloud models have huge context, don't compact aggressively
    _ctx_max = 200000 if _is_cloud_model(model) else MAX_CONTEXT_TOKENS
    ctx_manager = ContextManager(max_tokens=_ctx_max)
    cost_tracker = CostTracker()

    # Bootstrap project detection
    cwd = os.getcwd().replace("\\", "/")
    project_info = load_cached_project(cwd) or scan_project(cwd)
    project_info_prompt = project_info.to_prompt_section() if project_info and project_info.languages else None

    if resume:
        try:
            session = Session.load(resume)
            console.print(f"[dim]  Resumed session {session.session_id}[/dim]")
            # Away summary
            import time as _time
            last_msg_time = session.messages[-1].get("timestamp", 0) if session.messages else 0
            if last_msg_time:
                idle_secs = _time.time() - last_msg_time
                if idle_secs > 60:
                    if idle_secs > 3600:
                        idle_str = f"{idle_secs/3600:.1f}h"
                    elif idle_secs > 60:
                        idle_str = f"{int(idle_secs/60)}m"
                    else:
                        idle_str = f"{int(idle_secs)}s"
                    console.print(f"[dim]  Idle for {idle_str}[/dim]")
        except Exception:
            console.print(f"[vaal.error]  Could not load session: {resume}[/]")
            return
    else:
        session = Session(model=model, cwd=os.getcwd())

    project_instructions = load_project_instructions()
    style_injection = styles.get_prompt_injection()
    system_prompt = build_system_prompt(
        project_instructions=project_instructions,
        project_info=project_info_prompt,
    )
    # Inject output style directive into system prompt
    if style_injection and styles.current != "default":
        system_prompt += f"\n\n## Output Style\n{style_injection}"

    # Inject persistent memories into system prompt
    from .memory import MemoryStore
    memory_store = MemoryStore()
    memory_section = memory_store.to_prompt_section()
    if memory_section:
        system_prompt += f"\n\n{memory_section}"

    # Inject active plan into system prompt
    from .plans import get_active_plan
    active_plan = get_active_plan()
    if active_plan:
        system_prompt += f"\n\n{active_plan.to_prompt_section()}"

    if not session.messages:
        session.add_message("system", system_prompt)

    # Load plugins
    from .plugins import load_plugins
    loaded_plugins = load_plugins()

    ollama_tools = get_ollama_tools(all_tools())

    stats.model = model
    print_header(model, permission_mode, cwd, minimal=minimal)

    # Auto-create VAAL.md if it doesn't exist
    if not project_instructions:
        vaal_md_path = os.path.join(cwd, "VAAL.md")
        if not os.path.exists(vaal_md_path):
            try:
                from .init_project import run_init
                _init_path, _init_content = run_init()
                project_instructions = _init_content
                console.print(f"[dim]  Auto-generated VAAL.md[/dim]")
            except Exception:
                pass  # Non-critical

    if not permissions.internet_enabled:
        console.print(f"[{VAAL_RED}]  Internet access disabled (/internet to re-enable)[/]")

    # First-run: show hardware + model recommendations
    if first_run:
        _show_first_run(mgr)

    # Check vaal account — prompt login on first run
    vaal_user = get_vaal_user()
    if not vaal_user:
        console.print()
        console.print(f"  [bold {VAAL_BLUE}]Welcome to Vaal![/]")
        console.print()
        console.print(f"  [dim]Create an account to sync settings & use remote control.[/dim]")
        console.print()
        console.print(f"  [bold]1[/] [dim]Register[/dim]          /register")
        console.print(f"  [bold]2[/] [dim]Login[/dim]             /login vaal")
        console.print(f"  [bold]3[/] [dim]Skip[/dim]              just press Enter")
        console.print()
        try:
            choice = input("  > ").strip()
            if choice == "1":
                try:
                    _handle_register_command("")
                except Exception:
                    console.print(f"  [dim]Could not connect to server. You can /register later.[/dim]")
            elif choice == "2":
                try:
                    _handle_vaal_login("", {})
                except Exception:
                    console.print(f"  [dim]Could not connect to server. You can /login vaal later.[/dim]")
        except (EOFError, KeyboardInterrupt):
            pass
        console.print()
    # If no working model, prompt to configure one
    if not check_connection(model):
        from .providers import get_api_key, parse_model_string
        prov, _ = parse_model_string(model)
        if not get_api_key(prov):
            console.print()
            console.print(f"  [dim]No LLM configured. Set one up:[/dim]")
            console.print(f"  [bold]1[/] [dim]Browse models[/dim]       /models")
            console.print(f"  [bold]2[/] [dim]Add API key[/dim]         /login anthropic <key>")
            console.print(f"  [bold]3[/] [dim]Use Ollama[/dim]          install from ollama.ai")
            console.print()
            try:
                choice = input("  > ").strip()
                if choice == "1":
                    from .interactive import model_picker
                    picked = model_picker(model)
                    if picked:
                        model = picked
                        user_config.default_model = model
                        user_config.save()
                elif choice == "2":
                    console.print(f"  [dim]Run: /login <provider> <api-key>[/dim]")
            except (EOFError, KeyboardInterrupt):
                pass
            console.print()

    active_model = [model]

    # Bundle components for handle_command access
    task_manager = get_task_manager()
    agent_pool = get_agent_pool()

    branch_manager = BranchManager()

    components = {
        "user_config": user_config,
        "keybindings": keybindings,
        "vim": vim,
        "voice": voice,
        "styles": styles,
        "cost_tracker": cost_tracker,
        "ctx_manager": ctx_manager,
        "task_manager": task_manager,
        "agent_pool": agent_pool,
        "branch_manager": branch_manager,
    }

    def print_prompt_line():
        """Print a clean prompt — no sprites, no box, just like Claude Code."""
        pass

    def print_prompt_bottom():
        """No-op — clean prompt needs no bottom block."""
        pass

    # Check if any models are installed — if not, open model selector
    from .llm import list_models as _check_models
    if not _check_models():
        console.print(f"\n[{VAAL_YELLOW}]  No models installed. Opening model selector...[/]")
        from .interactive import models_screen
        result = models_screen(active_model[0], mgr)
        if result:
            active_model[0] = result
            session.model = result
            stats.model = result
            user_config.default_model = result
            user_config.save()
            session.save()
            refresh_screen(result, permission_mode, cwd)

    # Initial prompt
    print_prompt_line()

    # Start Vaal orb idle animation
    from .buddy import get_orb as _get_orb
    _vaal_orb = _get_orb()
    _vaal_orb.start_animation()

    from .raw_input import read_prompt
    from .multiline import is_multiline_trigger, read_multiline

    # Track last assistant response for /copy
    last_response = [""]
    components["last_response"] = last_response

    from .self_repair import attempt_self_repair, reset_repair_count

    _ctrl_c_count = 0
    _last_ctrl_c = 0.0

    def _do_quit():
        """Save and exit cleanly."""
        try:
            from .buddy import get_orb as _quit_orb
            _quit_orb().stop_animation()
        except Exception:
            pass
        console.print(f"\n[dim]  Session saved. Goodbye.[/dim]")
        user_config.save()
        session.save()
        if stats.messages > 5:
            try:
                from .memory import MemoryStore
                store = MemoryStore()
                user_msgs = [m.get("content", "")[:100] for m in session.messages if m.get("role") == "user" and isinstance(m.get("content"), str)]
                if user_msgs:
                    summary = "Session topics: " + "; ".join(user_msgs[:5])
                    store.save_memory(name=f"session_{session.session_id}", content=summary, memory_type="project", description=f"Session {session.session_id} summary")
                    console.print(f"[dim]  Auto-saved session memory[/dim]")
            except Exception:
                pass

    while True:
        try:
            vim_indicator = "[VIM] " if vim.enabled else ""
            prompt_str = f"{vim_indicator}\033[1;37m> \033[0m"
            user_input, trigger = read_prompt(prompt_str)
            print_prompt_bottom()  # Complete the buddy block after input
            _ctrl_c_count = 0  # Reset on successful input
        except KeyboardInterrupt:
            now = time.time()
            if now - _last_ctrl_c < 2.0:
                # Double Ctrl+C within 2 seconds — quit
                _do_quit()
                break
            _last_ctrl_c = now
            _ctrl_c_count += 1
            console.print(f"\n[dim]  Press Ctrl+C again to exit, or type /help[/dim]")
            print_prompt_line()
            continue
        except EOFError:
            _do_quit()
            break

        if trigger == "slash":
            from .command_palette import command_palette
            chosen = command_palette()
            if chosen:
                user_input = chosen
            else:
                continue
        elif trigger == "down":
            from .command_palette import command_palette
            chosen = command_palette()
            if chosen:
                user_input = chosen
            else:
                continue

        # Multiline input: if the line starts with """, ''', or ```
        if user_input and is_multiline_trigger(user_input):
            try:
                user_input = read_multiline(user_input)
            except (EOFError, KeyboardInterrupt):
                continue

        if not user_input:
            continue

        # Bare "exit" or "quit" typed as prompt — treat as /quit
        if user_input.strip().lower() in ("exit", "quit"):
            _do_quit()
            break

        if user_input.startswith("/"):
            result = handle_command(user_input, session, active_model, permissions, components)
            if isinstance(result, str) and result.startswith("paste:"):
                # /paste returns pasted text to process as user input
                user_input = result[6:]
            elif result:
                continue
            else:
                break

        if user_input.startswith("!"):
            shell_cmd = user_input[1:].strip()
            if shell_cmd:
                os.system(shell_cmd)
            continue

        # ── Main processing — wrapped for self-repair ──
        try:
            _self_repair_ok = True

            # Check session token budget before processing
            if stats.total_tokens >= MAX_SESSION_TOKENS:
                console.print(f"\n[vaal.warning]  Session token budget exceeded ({stats.total_tokens}/{MAX_SESSION_TOKENS}). Use /clear or start a new session.[/]")
                continue

            # Check for [image] marker from Ctrl+V or clipboard image
            _attached_image = False
            _has_marker = "[image]" in user_input
            try:
                from .image_input import get_clipboard_image, build_image_message, build_ollama_image_message
                _clip_img = get_clipboard_image() if _has_marker else None
                if _clip_img:
                    # Strip the [image] marker from the text
                    user_input = user_input.replace("[image]", "").strip()
                    _b64, _mt = _clip_img
                    _size_kb = len(_b64) * 3 // 4 // 1024
                    console.print(f"  [dim]📎 Image attached ({_size_kb} KB)[/dim]")
                    # Build image message with the user's text as the prompt
                    cwd = os.getcwd().replace("\\", "/")
                    _prompt = f"[CWD: {cwd}]\n{user_input}"
                    model = active_model[0]
                    if _is_cloud_model(model):
                        _img_msg = build_image_message(_b64, _mt, _prompt)
                    else:
                        _img_msg = build_ollama_image_message(_b64, _prompt)
                    _img_msg["timestamp"] = __import__("time").time()
                    session.messages.append(_img_msg)
                    _attached_image = True
            except Exception:
                pass

            if not _attached_image:
                cwd = os.getcwd().replace("\\", "/")
                augmented = f"[CWD: {cwd}]\n{user_input}"
                # Inject pinned file contents
                if _pinned_files:
                    pin_context = ""
                    for pf in _pinned_files:
                        try:
                            content = open(pf, encoding="utf-8", errors="replace").read()
                            pin_context += f"\n\n[Pinned file: {pf}]\n```\n{content[:5000]}\n```"
                        except Exception:
                            pass
                    if pin_context:
                        augmented += pin_context
                session.add_message("user", augmented)
            record_prompt(user_input, active_model[0], session.session_id)
            stats.messages += 1

            if stats.messages % 5 == 0:
                session.save()

            _ctx_pct = ctx_manager.usage_pct(session.messages)
            if _ctx_pct >= 0.90:
                console.print(f"[{VAAL_YELLOW}]  ⚠ Context at {_ctx_pct:.0%} — auto-compacting...[/]")
            elif _ctx_pct >= 0.75:
                console.print(f"[dim]  Context at {_ctx_pct:.0%}[/dim]")

            if ctx_manager.should_compact(session.messages):
                old_count = len(session.messages)
                session.messages = ctx_manager.compact_messages(session.messages)
                new_count = len(session.messages)
                if new_count < old_count:
                    console.print(f"[dim]  Auto-compacted: {old_count} -> {new_count} messages[/dim]")

            # Inject session files note into system context
            if _session_files and session.messages and session.messages[0]["role"] == "system":
                _modified = {p: a for p, a in _session_files.items() if a in ("written", "edited")}
                _sys_content = session.messages[0]["content"]
                _marker = "\n\n## Files modified this session"
                if _marker in _sys_content:
                    _sys_content = _sys_content[:_sys_content.index(_marker)]
                if _modified:
                    _file_list = ", ".join(f"{p} ({a})" for p, a in _modified.items())
                    _sys_content += f"{_marker}\n{_file_list}"
                session.messages[0]["content"] = _sys_content

            start = time.time()
            rounds = 0
            eval_count = 0
            max_rounds = MAX_TURNS_PER_MESSAGE

            while rounds < max_rounds:
                rounds += 1

                if stats.total_tokens >= MAX_SESSION_TOKENS:
                    console.print(f"\n[vaal.warning]  Token budget exceeded. Use /clear.[/]")
                    print_prompt_line()
                    break

                chat_messages = session.get_chat_messages()
                if _is_anthropic_model(active_model[0]):
                    chat_messages = _sanitize_messages(chat_messages)
                from .context import estimate_messages_tokens
                input_est = estimate_messages_tokens(chat_messages)

                try:
                    content, tool_calls, eval_count, eval_duration = stream_response(
                        chat_messages, ollama_tools, active_model[0], think
                    )
                except (NameError, TypeError, AttributeError, KeyError, IndexError) as e:
                    # Code bugs — let self-repair catch these
                    raise
                except Exception as e:
                    # Network/API errors — retry once, then report
                    err_msg = str(e)
                    if any(kw in err_msg.lower() for kw in ["getaddrinfo", "connection", "timeout", "ssl", "refused", "reset"]):
                        console.print(f"\n  [dim]Network error: {err_msg[:80]} — retrying...[/dim]")
                        import time as _time
                        _time.sleep(2)
                        try:
                            content, tool_calls, eval_count, eval_duration = stream_response(
                                chat_messages, ollama_tools, active_model[0], think
                            )
                        except Exception as e2:
                            console.print(f"\n  [bold red]✗Network error[/] [dim]{e2}[/dim]")
                            console.print(f"  [dim]Check your internet connection and try again.[/dim]")
                            print_prompt_line()
                            break
                    else:
                        console.print(f"\n  [bold red]✗Error[/] [dim]{e}[/dim]")
                        print_prompt_line()
                        break

                if tool_calls and _is_anthropic_model(active_model[0]):
                    assistant_content = []
                    if content:
                        assistant_content.append({"type": "text", "text": content})
                    for tc in tool_calls:
                        func = tc.get("function", {})
                        assistant_content.append({
                            "type": "tool_use",
                            "id": tc.get("id", f"tool_{func.get('name', 'unknown')}"),
                            "name": func.get("name", ""),
                            "input": func.get("arguments", {}),
                        })
                    session.messages.append({
                        "role": "assistant",
                        "content": assistant_content,
                        "timestamp": __import__("time").time(),
                    })
                else:
                    session.add_message("assistant", content or "(tool calls)")
                if content:
                    last_response[0] = content

                label = f"round_{rounds}" if tool_calls else "response"
                cost_tracker.record(label=label, input_tokens=input_est, output_tokens=eval_count)

                elapsed = time.time() - start
                stats.total_tokens += eval_count
                stats.total_time += elapsed
                if _is_cloud_model(active_model[0]):
                    stats.record_cloud_usage(active_model[0], input_est, eval_count)

                # Detect local model not using tools on first turn — nudge once
                if not tool_calls and content and not _is_cloud_model(active_model[0]) and rounds == 1:
                    _lower_content = content.lower()
                    _intent_phrases = ["let me", "i'll ", "i will", "let's", "going to",
                                       "start by", "first,", "step 1", "begin by"]
                    if any(p in _lower_content for p in _intent_phrases) and len(content) < 500:
                        console.print(f"\n  [dim](nudging to use tools...)[/dim]")
                        session.add_message("assistant", content)
                        session.add_message("user",
                            "Use your tools now. Call glob to find files, read to examine them, "
                            "edit or write to change them, bash to run commands."
                        )
                        continue

                if not tool_calls:
                    console.print()
                    _parts = []
                    if elapsed > 0:
                        if elapsed >= 3600:
                            _h, _rem = divmod(int(elapsed), 3600)
                            _m, _s = divmod(_rem, 60)
                            _parts.append(f"{_h}h {_m}m {_s}s")
                        elif elapsed >= 60:
                            _m, _s = divmod(int(elapsed), 60)
                            _parts.append(f"{_m}m {_s}s")
                        else:
                            _parts.append(f"{elapsed:.0f}s")
                    if eval_count > 0:
                        _parts.append(f"{eval_count} tokens")
                        if eval_duration > 0:
                            _parts.append(f"{eval_count / (eval_duration / 1e9):.0f} tok/s")
                        elif elapsed > 0:
                            _parts.append(f"{eval_count / elapsed:.0f} tok/s")
                    if stats.tool_calls > 0:
                        _parts.append(f"{stats.tool_calls} tool calls")
                    _pool = get_agent_pool()
                    if _pool.total_count > 0:
                        _parts.append(f"{_pool.active_count}/{_pool.total_count} agents")
                    if _parts:
                        console.print(f"  [dim]{' · '.join(_parts)}[/dim]")
                    print_prompt_line()
                    break

                for tc in tool_calls:
                    func = tc.get("function", {})
                    tool_name = func.get("name", "")
                    tool_args = func.get("arguments", {})
                    tool_use_id = tc.get("id", f"tool_{tool_name}")
                    print_tool_call(tool_name, tool_args)
                    result, executed = execute_tool(tool_name, tool_args, permissions, ask_tool_permission)
                    session.tool_calls += 1
                    stats.tool_calls += 1
                    stats.tool_usage[tool_name] = stats.tool_usage.get(tool_name, 0) + 1
                    formatted = format_tool_result(tool_name, result)
                    print_tool_result(tool_name, formatted)
                    # Track files touched this session
                    if tool_name in ("read", "write", "edit"):
                        _fpath = tool_args.get("file_path", "")
                        if _fpath:
                            _action_map = {"read": "read", "write": "written", "edit": "edited"}
                            _session_files[_fpath] = _action_map[tool_name]
                    # Track tool errors for loop detection
                    if "[error" in formatted.lower():
                        _err_line = formatted.strip().splitlines()[0] if formatted.strip() else ""
                        _recent_errors.append(_err_line)
                        if len(_recent_errors) > 10:
                            _recent_errors.pop(0)
                        _same = sum(1 for e in _recent_errors if e == _err_line)
                        if _same >= 3:
                            console.print(f"  [{VAAL_YELLOW}]⚠ Detected error loop — same error 3 times. Escalating...[/]")
                            _recent_errors.clear()
                            session.add_message("user", "You've been getting the same error repeatedly. Step back, analyze the root cause differently, and try a completely different approach.")
                    session.messages.append({
                        "role": "tool",
                        "tool_use_id": tool_use_id,
                        "content": formatted,
                        "timestamp": __import__("time").time(),
                    })

                if autofix_enabled():
                    failure = get_last_bash_failure()
                    if failure:
                        clear_last_bash_failure()
                        error_key = failure["error_output"].strip().splitlines()[-1] if failure["error_output"].strip() else ""
                        # Error loop detection
                        _recent_errors.append(error_key)
                        if len(_recent_errors) > 10:
                            _recent_errors.pop(0)
                        _same_count = sum(1 for e in _recent_errors if e == error_key)
                        if _same_count >= 3:
                            console.print(f"  [{VAAL_YELLOW}]⚠ Detected error loop — same error 3 times. Escalating...[/]")
                            _recent_errors.clear()
                            session.add_message("user", "You've been getting the same error repeatedly. Step back, analyze the root cause differently, and try a completely different approach.")
                        else:
                            fix_prompt = build_fix_prompt(failure["command"], failure["error_output"], 1)
                            console.print(f"  [{VAAL_YELLOW}]auto-fix[/]")
                            session.add_message("user", fix_prompt)

                _agent_pool = get_agent_pool()
                _completed = _agent_pool.collect_completed()
                for _ar in _completed:
                    _amsg = f"[Sub-agent {_ar.agent_id} completed: {_ar.rounds} rounds, {_ar.tool_calls_made} tool calls, {_ar.elapsed:.1f}s]\n"
                    if _ar.error:
                        _amsg += f"Error: {_ar.error}"
                    elif _ar.content:
                        _amsg += _ar.content
                    else:
                        _amsg += "(no output)"
                    session.add_message("user", _amsg)
                    console.print()
                    _status = f"[bold red]error[/]" if _ar.error else f"[{VAAL_GREEN}]done[/]"
                    console.print(f"  [bold]Agent[/] [dim]{_ar.agent_id[:8]}[/dim] {_status} [dim]{_ar.elapsed:.1f}s · {_ar.rounds} rounds · {_ar.tool_calls_made} tools[/dim]")
                    if _ar.error:
                        console.print(f"  ⎿  [red]{_ar.error}[/]")
                    elif _ar.content:
                        _content_lines = _ar.content.strip().splitlines()
                        for _cl in _content_lines[:15]:
                            console.print(f"  ⎿  [dim]{_cl}[/dim]")
                        if len(_content_lines) > 15:
                            console.print(f"  ⎿  [dim]… {len(_content_lines) - 15} more lines[/dim]")

            else:
                console.print(f"\n[vaal.warning]  Turn limit reached ({max_rounds} rounds). Stopping.[/]")
                print_prompt_line()

            session.total_tokens += eval_count
            session.save()
            reset_repair_count()

        except KeyboardInterrupt:
            # Ctrl+C during processing — cancel current response, return to prompt
            _write(f"\r\033[K")
            console.print(f"\n  [dim]Cancelled.[/dim]")
            session.save()
            print_prompt_line()
            continue
        except EOFError:
            raise
        except Exception:
            exc_type, exc_value, exc_tb = sys.exc_info()
            fixed = attempt_self_repair(exc_type, exc_value, exc_tb, model=active_model[0])
            if not fixed:
                console.print(f"\n  [bold red]✗Crash[/] [dim]{exc_type.__name__ if exc_type else 'Error'}: {exc_value}[/dim]")
                console.print(f"  [dim]Session saved. Continuing...[/dim]")
                session.save()
            print_prompt_line()
            continue


# ── Slash commands ───────────────────────────────────────────────────

def handle_command(cmd: str, session: Session, active_model: list, permissions: PermissionManager, components: dict = None) -> bool:
    model = active_model[0]
    parts = cmd.split(maxsplit=1)
    command = parts[0].lower()
    arg = parts[1] if len(parts) > 1 else ""

    # Unpack components
    user_config = components.get("user_config") if components else None
    keybindings = components.get("keybindings") if components else None
    vim = components.get("vim") if components else None
    voice = components.get("voice") if components else None
    styles = components.get("styles") if components else None

    if command in ("/quit", "/exit"):
        session.save()
        console.print(f"[dim]  Session saved. Goodbye.[/dim]")
        return False

    elif command == "/help":
        console.print()
        console.print(f"[bold {VAAL_BLUE}]  Commands[/]")
        console.print(f"[dim]  {'─' * 40}[/dim]")
        cmds = [
            ("/help", "Show this help"),
            ("/quit", "Exit and save session"),
            ("/clear", "Clear conversation"),
            ("/model <name>", "Switch model"),
            ("/models", "List compatible models with hardware info"),
            ("/pull <model>", "Download a model via Ollama"),
            ("/remove <model>", "Remove a downloaded model"),
            ("/delete <model>", "Alias for /remove"),
            ("/login [provider]", "Login with API key / OAuth"),
            ("/logout <provider>", "Remove API key / OAuth"),
            ("/provider [name]", "List/switch API providers"),
            ("/history", "Show last 20 prompts"),
            ("/changelog", "Prompt history with file changes"),
            ("/cost", "Show token usage breakdown"),
            ("/yolo", "Auto-approve all tools"),
            ("/internet", "Toggle internet access for tools"),
            ("/session", "Show session info"),
            ("/sessions", "List saved sessions"),
            ("/compact", "Compress history"),
            ("/theme", "Terminal color theme picker"),
            ("/font", "Terminal font picker"),
            ("/icon", "Set terminal icon (instructions)"),
            ("/memory", "List/search persistent memories"),
            ("/plan", "Create a new implementation plan"),
            ("/plans", "List all plans"),
            ("/resume", "Interactive session picker to resume"),
            ("/init", "Generate VAAL.md for current project"),
            ("/task <action>", "Manage tasks (create/update/complete)"),
            ("/tasks", "Show all tasks with status"),
            ("/agents", "Show all sub-agents"),
            ("!<cmd>", "Run shell command"),
            ("/copy", "Copy last response to clipboard"),
            ("/paste", "Paste clipboard content as input"),
            ("/autofix", "Toggle auto-fix on bash errors"),
            ("/watch <cmd>", "Watch files, re-run command on change"),
            ("/watch stop", "Stop file watcher"),
            ("/branch [name]", "Fork conversation into a branch"),
            ("/branches", "List all branches"),
            ("/switch <name>", "Switch to a different branch"),
            ("/merge <name>", "Merge branch into current conversation"),
            ("/image <path>", "Send an image for analysis"),
            ("/paste-image", "Paste image from clipboard for analysis"),
            ("/voice", "Toggle voice input mode"),
            ("/mcp <action>", "MCP server (connect/list/disconnect)"),
            ("/schedule <int> <p>", "Run prompt on recurring interval"),
            ("/split <file>", "File preview pane above prompt"),
            ("/notify on|off", "Toggle desktop notifications"),
            ("/undo", "Undo last file change (or /undo all)"),
            ("/redo", "Redo last undone change"),
            ("/pin <file>", "Pin a file to always include in context"),
            ("/unpin <file>", "Remove a pinned file"),
            ("/cost [verbose]", "Show running cost estimate"),
            ("/db <action>", "Database tools (connect/query/schema)"),
            ("/api <METHOD> <URL>", "HTTP API testing"),
            ("/env", "Environment variable management"),
            ("/collab <action>", "Collaborative sessions (start/join/leave)"),
            ("/review [file]", "Code review on diff or file"),
            ("/review-pr <num>", "Review a GitHub pull request"),
            ("/deps [audit]", "Scan and audit project dependencies"),
            ("/ssh <action>", "SSH remote (connect/run/disconnect)"),
            ("/explain <error>", "Explain an error or stack trace"),
            ("/migrate <src> <dst>", "Migration helper (e.g. flask fastapi)"),
            ("/plugin", "Manage plugins (list/create/remove/reload/info)"),
            ("/agentmodel <model>", "Set model for subagents"),
            ("/register", "Create a vaal account on e-e.tools"),
            ("/login vaal", "Login to your vaal account"),
            ("/remote start|stop", "Remote control from web browser"),
            ("/buddy", "Your companion (hatch/show/reroll/name)"),
            ("/doctor", "System health diagnostics"),
            ("/preview <path>", "Live preview with interactive inspector"),
            ("/preview stop", "Stop preview server"),
            ("/deny <tool>", "Block a tool by name or prefix"),
            ("/directory [path]", "Change working directory (alias: /cd)"),
            ("/effort [level]", "Set inference effort (low/medium/high/max)"),
            ("/add-dir <path>", "Add directory to context"),
            ("/summary", "Generate session summary"),
            ("/stats", "Detailed usage statistics"),
            ("/rewind [N]", "Branch from a past message"),
            ("/debug-tool", "Toggle verbose tool output"),
            ("/commit [msg]", "Auto-generate commit message and commit"),
            ("/test [pattern]", "Detect framework and run tests"),
            ("/pr [title]", "Create a pull request"),
            ("/diff [file]", "Show uncommitted changes"),
            ("/files", "List all files touched this session"),
        ]
        for name, desc in cmds:
            console.print(f"  [bold {VAAL_BLUE}]{name:20s}[/bold {VAAL_BLUE}] [dim]{desc}[/dim]")
        console.print()

    elif command == "/clear":
        system_msg = session.messages[0] if session.messages and session.messages[0]["role"] == "system" else None
        session.messages.clear()
        if system_msg:
            session.messages.append(system_msg)
        # Reset cost tracker, tasks, and agents on clear
        if components and "cost_tracker" in components:
            components["cost_tracker"].events.clear()
        reset_task_manager()
        reset_agent_pool()
        _session_files.clear()
        if components:
            components["task_manager"] = get_task_manager()
            components["agent_pool"] = get_agent_pool()
        console.print(f"[dim]  Conversation cleared.[/dim]")

    elif command == "/model":
        if arg:
            active_model[0] = arg
            session.model = arg
            stats.model = arg
            if user_config:
                user_config.default_model = arg
                user_config.save()
            session.save()
            cwd = os.getcwd().replace("\\", "/")
            refresh_screen(arg, permissions.mode, cwd)
        else:
            console.print(f"  Model: [bold]{active_model[0]}[/bold]")

    elif command == "/models":
        from .interactive import models_screen
        from .model_manager import get_manager
        mgr = get_manager()
        if not mgr.hardware:
            mgr.detect()
        result = models_screen(active_model[0], mgr)
        if result:
            active_model[0] = result
            session.model = result
            stats.model = result
            if user_config:
                user_config.default_model = result
                user_config.save()
            session.save()
            cwd = os.getcwd().replace("\\", "/")
            refresh_screen(result, permissions.mode, cwd)

    elif command == "/pull":
        if not arg:
            console.print(f"[dim]  Usage: /pull <model_name>[/dim]")
        else:
            _handle_pull(arg.strip())

    elif command in ("/remove", "/delete"):
        if not arg:
            console.print(f"[dim]  Usage: /remove <model_name>[/dim]")
        else:
            _handle_remove(arg.strip())
            # If no models left, prompt model selection
            from .llm import list_models as _lm
            if not _lm():
                console.print(f"\n[{VAAL_YELLOW}]  No models installed. Opening model selector...[/]")
                from .interactive import models_screen
                from .model_manager import get_manager
                mgr = get_manager()
                mgr.refresh_installed()
                result = models_screen(active_model[0], mgr)
                if result:
                    active_model[0] = result
                    session.model = result
                    stats.model = result
                    if user_config:
                        user_config.default_model = result
                        user_config.save()
                    session.save()
                    cwd_now = os.getcwd().replace("\\", "/")
                    refresh_screen(result, permissions.mode, cwd_now)

    elif command == "/login":
        if not arg:
            # Interactive login screen with arrow navigation
            from .login_screen import login_screen
            result = login_screen()
            if result:
                # Refresh screen after login
                cwd_now = os.getcwd().replace("\\", "/")
                refresh_screen(active_model[0], permissions.mode, cwd_now)
        else:
            # Direct: /login provider [key]
            from .providers import BUILTIN_PROVIDERS, save_api_key, get_api_key, DEFAULT_MODELS
            parts_login = arg.strip().split(maxsplit=1)
            provider_name = parts_login[0].lower()
            key_arg = parts_login[1] if len(parts_login) > 1 else ""

            if provider_name == "vaal":
                _handle_vaal_login(key_arg, components)
            elif provider_name not in BUILTIN_PROVIDERS:
                console.print(f"[vaal.error]  Unknown provider: {provider_name}[/]")
            elif key_arg:
                save_api_key(provider_name, key_arg)
                console.print(f"[vaal.success]  ✓ API key saved for {provider_name}[/]")
                default_model = DEFAULT_MODELS.get(provider_name, "")
                if default_model:
                    console.print(f"[dim]  Switch with: /model {provider_name}:{default_model}[/dim]")
            else:
                # No key provided — open interactive for that provider
                from .login_screen import login_screen
                result = login_screen()
                if result:
                    cwd_now = os.getcwd().replace("\\", "/")
                    refresh_screen(active_model[0], permissions.mode, cwd_now)

    elif command == "/logout":
        from .logout_screen import logout_screen
        from .providers import parse_model_string
        result = logout_screen()
        if result:
            # If logged out of current model's provider, switch to local
            cur_prov, _ = parse_model_string(active_model[0])
            if cur_prov == result:
                active_model[0] = "qwen3:8b"
                session.model = "qwen3:8b"
                stats.model = "qwen3:8b"
            cwd_now = os.getcwd().replace("\\", "/")
            refresh_screen(active_model[0], permissions.mode, cwd_now)

    elif command == "/provider":
        from .providers import BUILTIN_PROVIDERS, get_api_key, save_api_key, DEFAULT_MODELS
        if not arg:
            # List providers
            console.print()
            console.print(f"[bold {VAAL_BLUE}]  Providers[/]")
            console.print(f"[dim]  {'─' * 40}[/dim]")
            current_provider = "ollama"
            if user_config:
                current_provider = user_config.get("provider", "ollama")
            for name, info in BUILTIN_PROVIDERS.items():
                key_status = ""
                if info["requires_key"]:
                    key = get_api_key(name)
                    key_status = f"  [{VAAL_GREEN}]✓ key set[/]" if key else f"  [dim]✗ no key[/dim]"
                else:
                    key_status = f"  [{VAAL_GREEN}]✓ local[/]"
                active = f"  [{VAAL_CYAN}]← active[/]" if name == current_provider else ""
                default_model = DEFAULT_MODELS.get(name, "")
                console.print(f"  [bold]{name:15s}[/bold]{key_status}{active}")
                if default_model:
                    console.print(f"  {'':15s}  [dim]default: {default_model}[/dim]")
            console.print()
            console.print(f"[dim]  Usage: /provider <name> [api_key][/dim]")
            console.print(f"[dim]  Switch: /model <provider>:<model>  (e.g. /model openai:gpt-4o)[/dim]")
            console.print()
        else:
            parts_p = arg.strip().split(maxsplit=1)
            provider_name = parts_p[0].lower()
            api_key_arg = parts_p[1] if len(parts_p) > 1 else ""

            if provider_name not in BUILTIN_PROVIDERS:
                console.print(f"[vaal.error]  Unknown provider: {provider_name}[/]")
                console.print(f"[dim]  Available: {', '.join(BUILTIN_PROVIDERS.keys())}[/dim]")
            else:
                info = BUILTIN_PROVIDERS[provider_name]
                if api_key_arg:
                    save_api_key(provider_name, api_key_arg)
                    console.print(f"[vaal.success]  API key saved for {provider_name}[/]")
                elif info["requires_key"] and not get_api_key(provider_name):
                    console.print(f"[{VAAL_YELLOW}]  {provider_name} requires an API key.[/]")
                    console.print(f"[dim]  Run: /provider {provider_name} sk-your-key-here[/dim]")
                    console.print(f"[dim]  Or set env var: {info.get('key_env', '')}[/dim]")
                else:
                    # Switch to this provider with its default model
                    default_model = DEFAULT_MODELS.get(provider_name, "")
                    full_model = f"{provider_name}:{default_model}" if provider_name != "ollama" else default_model
                    active_model[0] = full_model
                    session.model = full_model
                    stats.model = full_model
                    if user_config:
                        user_config.set("provider", provider_name)
                        user_config.default_model = full_model
                        user_config.save()
                    session.save()
                    cwd_now = os.getcwd().replace("\\", "/")
                    refresh_screen(full_model, permissions.mode, cwd_now)

    elif command == "/yolo":
        permissions.approve_all()
        permissions.mode = "yolo"
        console.print(f"[vaal.warning]  YOLO mode — all tools auto-approved[/]")

    elif command == "/internet":
        new_state = not permissions.internet_enabled
        permissions.internet_enabled = new_state
        if user_config:
            user_config.internet_enabled = new_state
            user_config.save()
        if new_state:
            console.print(f"[{VAAL_GREEN}]  Internet access enabled — web_fetch, web_search, api_request, ssh_exec available[/]")
        else:
            from .config import INTERNET_TOOLS
            console.print(f"[{VAAL_RED}]  Internet access disabled — blocked tools: {', '.join(sorted(INTERNET_TOOLS))}[/]")

    elif command == "/session":
        console.print(f"  [dim]ID:[/dim]         {session.session_id}")
        console.print(f"  [dim]Model:[/dim]      {session.model}")
        console.print(f"  [dim]Messages:[/dim]   {len(session.messages)}")
        console.print(f"  [dim]Tool calls:[/dim] {session.tool_calls}")
        console.print(f"  [dim]Tokens:[/dim]     {session.total_tokens}")
        # Show context usage
        if components and "ctx_manager" in components:
            ctx = components["ctx_manager"]
            used, mx = ctx.usage(session.messages)
            pct = ctx.usage_pct(session.messages)
            console.print(f"  [dim]Context:[/dim]    {used}/{mx} ({pct:.0%})")
        console.print(f"  [dim]Budget:[/dim]     {stats.total_tokens}/{MAX_SESSION_TOKENS} session tokens")

    elif command == "/sessions":
        # Use the interactive resume picker
        _handle_resume_command(session, active_model)

    elif command == "/history":
        limit = 20
        if arg:
            try:
                limit = int(arg)
            except ValueError:
                pass
        from .history import load_history
        entries = load_history(limit=limit)
        if not entries:
            console.print(f"[dim]  No history yet.[/dim]")
        else:
            console.print()
            for e in entries:
                ts = e.get("iso", "?")
                m = e.get("model", "?")
                sid = e.get("session_id", "?")
                prompt = e.get("prompt", "")
                if len(prompt) > 70:
                    prompt = prompt[:67] + "..."
                console.print(f"  [dim]{ts}[/dim]  [{VAAL_CYAN}]{m}[/]  [dim]({sid})[/dim]  {prompt}")
            console.print()

    elif command == "/changelog":
        limit = 20
        target_session = None
        if arg:
            # /changelog <number> — limit count
            # /changelog <session_id> — specific session
            try:
                limit = int(arg)
            except ValueError:
                target_session = arg.strip()

        from .changelog import build_changelog, build_changelog_for_session
        if target_session:
            entries = build_changelog_for_session(target_session)
        else:
            entries = build_changelog(limit=limit)

        if not entries:
            console.print(f"[dim]  No history yet.[/dim]")
        else:
            console.print()
            console.print(f"[bold {VAAL_BLUE}]  Changelog[/]")
            console.print()
            for pe in entries:
                # Truncate prompt for display
                prompt = pe.prompt
                if len(prompt) > 65:
                    prompt = prompt[:62] + "..."
                # Header line: timestamp, prompt
                console.print(f"  [dim]{pe.iso}[/dim]  {prompt}")
                # Model + session info
                console.print(f"  [dim]  [{VAAL_CYAN}]{pe.model}[/]  ({pe.session_id})[/dim]", end="")
                if pe.tool_calls > 0:
                    console.print(f"  [dim]· {pe.tool_calls} tool calls[/dim]", end="")
                console.print()
                # File changes
                if pe.changes:
                    for ch in pe.changes:
                        if ch.tool == "write":
                            icon = f"[{VAAL_GREEN}]+[/]"
                        elif ch.tool == "edit":
                            icon = f"[{VAAL_YELLOW}]~[/]"
                        elif ch.tool == "git_commit":
                            icon = f"[{VAAL_CYAN}]⊛[/]"
                        elif ch.tool == "bash":
                            icon = f"[dim]$[/dim]"
                        elif ch.tool == "apply_patch":
                            icon = f"[{VAAL_YELLOW}]⊕[/]"
                        else:
                            icon = f"[dim]·[/dim]"
                        console.print(f"    {icon} {ch.description}")
                else:
                    if pe.tool_calls > 0:
                        console.print(f"    [dim]  (no file changes)[/dim]")
                    else:
                        console.print(f"    [dim]  (chat only)[/dim]")
                console.print()
            console.print()

    elif command == "/cost":
        _handle_cost_command(arg, components)

    elif command == "/compact":
        if components and "ctx_manager" in components:
            ctx = components["ctx_manager"]
            old_count = len(session.messages)
            session.messages = ctx.compact_messages(session.messages)
            new_count = len(session.messages)
            if new_count < old_count:
                used, mx = ctx.usage(session.messages)
                console.print(f"[dim]  Compacted {old_count} -> {new_count} messages. Context: {used}/{mx}[/dim]")
            else:
                console.print(f"[dim]  Conversation too short to compact.[/dim]")
        else:
            # Fallback: original compact logic
            if len(session.messages) > 12:
                system = session.messages[:1]
                recent = session.messages[-10:]
                session.messages = system + [{"role": "user", "content": "[earlier conversation compacted]", "timestamp": time.time()}] + recent
                console.print(f"[dim]  Compacted to {len(session.messages)} messages.[/dim]")
            else:
                console.print(f"[dim]  Conversation too short to compact.[/dim]")

    elif command == "/theme":
        from .theme_screen import theme_screen
        result = theme_screen()
        if result:
            console.print(f"[dim]  Theme set to: {result}[/dim]")
        else:
            console.print(f"[dim]  Theme unchanged.[/dim]")
        # Refresh screen after theme change (clears screen artifacts)
        cwd_now = os.getcwd().replace("\\", "/")
        refresh_screen(active_model[0], permissions.mode, cwd_now)

    elif command == "/font":
        from .font_screen import font_screen
        result = font_screen()
        if result:
            console.print(f"[dim]  Font selection: {result}[/dim]")
        # Refresh screen
        cwd_now = os.getcwd().replace("\\", "/")
        refresh_screen(active_model[0], permissions.mode, cwd_now)

    elif command == "/icon":
        console.print()
        console.print(f"[bold {VAAL_BLUE}]  Terminal Icon[/]")
        console.print(f"[dim]  {'─' * 40}[/dim]")
        console.print(f"  Terminal icons are set via your terminal's profile settings,")
        console.print(f"  not via escape sequences.")
        console.print()
        console.print(f"  [bold]Windows Terminal:[/bold]")
        console.print(f"  1. Open Settings (Ctrl+,)")
        console.print(f"  2. Select your profile (e.g. PowerShell, Command Prompt)")
        console.print(f"  3. Under 'Icon', browse to your .ico or .png file")
        console.print()
        console.print(f"  [bold]settings.json:[/bold]")
        console.print(f'  "profiles": {{ "list": [{{ "icon": "C:/path/to/icon.ico" }}] }}')
        console.print()
        console.print(f"  [dim]Tip: Use a Vaal Orb image from Path of Exile as the icon.[/dim]")
        console.print(f"  [dim]Save a .ico file to ~/.vaal/icon.ico for easy reference.[/dim]")
        console.print()


    elif command == "/init":
        from .init_project import run_init
        console.print()
        console.print(f"[bold {VAAL_BLUE}]  Scanning project...[/]")
        try:
            vaal_path, content_md = run_init()
            console.print(f"  [bold {VAAL_GREEN}]VAAL.md generated[/] at {vaal_path}")
            preview_lines = content_md.splitlines()[:20]
            for line in preview_lines:
                console.print(f"  [dim]{line}[/dim]")
            if len(content_md.splitlines()) > 20:
                console.print(f"  [dim]... ({len(content_md.splitlines()) - 20} more lines)[/dim]")
            console.print()
        except Exception as e:
            console.print(f"  [bold red]Error:[/] {e}")
            console.print()

    elif command in ("/tasks", "/task", "/agents"):
        _handle_task_agent_command(command, arg, session, active_model, permissions, components)

    elif command == "/copy":
        from .clipboard import copy_to_clipboard
        last_resp = components.get("last_response", [""])[0] if components else ""
        if not last_resp:
            console.print(f"[dim]  No response to copy yet.[/dim]")
        elif copy_to_clipboard(last_resp):
            preview = last_resp[:60].replace(chr(10), " ")
            if len(last_resp) > 60:
                preview += "..."
            console.print(f"[dim]  Copied to clipboard ({len(last_resp)} chars): {preview}[/dim]")
        else:
            console.print(f"[vaal.error]  Failed to copy to clipboard. Install pyperclip or ensure xclip/clip.exe is available.[/]")

    elif command == "/paste":
        from .clipboard import paste_from_clipboard
        pasted = paste_from_clipboard()
        if pasted is None:
            console.print(f"[vaal.error]  Failed to read clipboard. Install pyperclip or ensure xclip/clip.exe is available.[/]")
        elif not pasted.strip():
            console.print(f"[dim]  Clipboard is empty.[/dim]")
        else:
            preview = pasted[:80].replace(chr(10), " ")
            if len(pasted) > 80:
                preview += "..."
            console.print(f"[dim]  Pasting from clipboard ({len(pasted)} chars): {preview}[/dim]")
            return "paste:" + pasted

    elif command == "/memory":
        _handle_memory_command(arg)

    elif command == "/plan":
        _handle_plan_command(arg, active_model)

    elif command == "/plans":
        _handle_plans_command()

    elif command == "/resume":
        _handle_resume_command(session, active_model)

    elif command == "/autofix":
        new_state = autofix_toggle()
        if new_state:
            console.print(f"[{VAAL_GREEN}]  Auto-fix enabled — bash errors will be auto-sent to the LLM (up to {MAX_FIX_ATTEMPTS} attempts)[/]")
        else:
            console.print(f"[dim]  Auto-fix disabled.[/dim]")

    elif command == "/watch":
        if arg.strip().lower() == "stop":
            if stop_watch():
                console.print(f"[dim]  Watcher stopped.[/dim]")
            else:
                console.print(f"[dim]  No active watcher.[/dim]")
        elif arg.strip():
            cwd_now = os.getcwd().replace("\\", "/")
            watcher = start_watch(arg.strip(), cwd_now)
            console.print(f"[{VAAL_GREEN}]  Watching for changes in {cwd_now}[/]")
            console.print(f"[dim]  Command: {arg.strip()}[/dim]")
            console.print(f"[dim]  Use /watch stop to stop.[/dim]")
        else:
            watcher = get_watcher()
            if watcher and watcher.is_running:
                console.print(f"[{VAAL_CYAN}]  {watcher.status}[/]")
            else:
                console.print(f"[dim]  No active watcher. Usage: /watch <command>[/dim]")
                console.print(f"[dim]  Example: /watch pytest tests/[/dim]")

    elif command == "/branch":
        bm = components.get("branch_manager") if components else None
        if not bm:
            console.print(f"[vaal.error]  Branch manager not available.[/]")
        else:
            # Parse: /branch [name] [-m model]
            branch_name = None
            branch_model = ""
            if arg:
                parts_b = arg.split()
                i = 0
                while i < len(parts_b):
                    if parts_b[i] == "-m" and i + 1 < len(parts_b):
                        branch_model = parts_b[i + 1]
                        i += 2
                    else:
                        if branch_name is None:
                            branch_name = parts_b[i]
                        i += 1
            try:
                branch = bm.create_branch(
                    name=branch_name,
                    messages=session.messages,
                    model=branch_model or active_model[0],
                )
                console.print(f"[{VAAL_GREEN}]  Created branch '{branch.name}' ({branch.message_count()} messages)[/]")
                if branch_model:
                    console.print(f"[dim]  Model: {branch_model}[/dim]")
                console.print(f"[dim]  Use /switch {branch.name} to switch to it.[/dim]")
            except ValueError as e:
                console.print(f"[vaal.error]  {e}[/]")

    elif command == "/branches":
        bm = components.get("branch_manager") if components else None
        if not bm:
            console.print(f"[vaal.error]  Branch manager not available.[/]")
        else:
            branches = bm.list_branches()
            if not branches:
                console.print(f"[dim]  No branches yet. Current conversation is 'main'.[/dim]")
                console.print(f"[dim]  Use /branch [name] to create one.[/dim]")
            else:
                console.print()
                console.print(f"[bold {VAAL_BLUE}]  Branches[/]")
                console.print(f"[dim]  {'─' * 40}[/dim]")
                # Also show main
                active_tag = f" [{VAAL_CYAN}]<- active[/]" if bm.current_branch == "main" and "main" not in [b["name"] for b in branches] else ""
                console.print(f"  [{VAAL_BLUE}]main[/] [dim]({len(session.messages)} msgs, model: {active_model[0]}){active_tag}[/dim]")
                for b in branches:
                    active = f" [{VAAL_CYAN}]<- active[/]" if b["active"] else ""
                    console.print(f"  [{VAAL_BLUE}]{b['name']}[/] [dim]({b['messages']} msgs, model: {b['model']}){active}[/dim]")
                console.print()

    elif command == "/switch":
        bm = components.get("branch_manager") if components else None
        if not bm:
            console.print(f"[vaal.error]  Branch manager not available.[/]")
        elif not arg.strip():
            console.print(f"[dim]  Usage: /switch <branch_name>[/dim]")
        else:
            target = arg.strip()
            try:
                new_messages, new_model = bm.switch_to(target, session.messages, active_model[0])
                session.messages = new_messages
                if new_model:
                    active_model[0] = new_model
                    session.model = new_model
                    stats.model = new_model
                console.print(f"[{VAAL_GREEN}]  Switched to branch '{target}' ({len(new_messages)} messages)[/]")
                if new_model:
                    console.print(f"[dim]  Model: {_beautify_model_name(new_model)}[/dim]")
            except ValueError as e:
                console.print(f"[vaal.error]  {e}[/]")

    elif command == "/merge":
        bm = components.get("branch_manager") if components else None
        if not bm:
            console.print(f"[vaal.error]  Branch manager not available.[/]")
        elif not arg.strip():
            console.print(f"[dim]  Usage: /merge <branch_name>[/dim]")
        else:
            target = arg.strip()
            try:
                merged, added = bm.merge_from(target, session.messages)
                session.messages = merged
                console.print(f"[{VAAL_GREEN}]  Merged {added} messages from '{target}' into current conversation.[/]")
            except ValueError as e:
                console.print(f"[vaal.error]  {e}[/]")

    elif command == "/image":
        if not arg.strip():
            console.print(f"[dim]  Usage: /image <path-to-image> [prompt][/dim]")
            console.print(f"[dim]  Example: /image screenshot.png What does this show?[/dim]")
        else:
            _handle_image_command(arg, session, active_model)

    elif command == "/paste-image":
        _handle_paste_image_command(arg, session, active_model)

    elif command == "/voice":
        if voice:
            if not voice.available:
                console.print(f"[dim]{voice.status_message()}[/dim]")
            else:
                new_state = voice.toggle()
                console.print(f"[{VAAL_GREEN if new_state else VAAL_DIM}]  Voice mode {'ON' if new_state else 'OFF'}[/]")
                if new_state:
                    console.print(f"[dim]  Engine: {voice._engine}. Say something at the prompt to use voice input.[/dim]")
                    # Do a single listen right now
                    console.print(f"[dim]  Listening for a voice command now...[/dim]")
                    text = voice.listen_once(timeout=8)
                    if text:
                        console.print(f"[{VAAL_CYAN}]  Heard: {text}[/]")
                        return "paste:" + text
                    else:
                        console.print(f"[dim]  No speech detected. Voice mode still on — use /voice to toggle off.[/dim]")
        else:
            console.print(f"[dim]  Voice input not initialized.[/dim]")

    elif command == "/mcp":
        _handle_mcp_command(arg)

    elif command == "/schedule":
        _handle_schedule_command(arg, active_model)

    elif command == "/collab":
        _handle_collab_command(arg)

    elif command == "/review":
        result = _handle_review_command(arg, session, active_model, components)
        if isinstance(result, str) and result.startswith("paste:"):
            return result

    elif command == "/review-pr":
        result = _handle_review_pr_command(arg, session, active_model, components)
        if isinstance(result, str) and result.startswith("paste:"):
            return result

    elif command == "/deps":
        _handle_deps_command(arg)

    elif command == "/ssh":
        _handle_ssh_command(arg)

    elif command == "/split":
        split_pane = components.get("split_pane") if components else None
        if split_pane is None:
            from .split_pane import SplitPane
            split_pane = SplitPane()
            if components is not None:
                components["split_pane"] = split_pane
        msg = split_pane.handle_command(arg)
        console.print(f"  [dim]{msg}[/dim]")

    elif command == "/notify":
        from .notifications import get_notification_manager
        nm = get_notification_manager()
        msg = nm.handle_command(arg)
        console.print(f"  [dim]{msg}[/dim]")

    elif command == "/undo":
        from .undo_system import get_undo_system
        undo = get_undo_system()
        if arg.strip().lower() == "all":
            count = 0
            while undo.undo_count > 0:
                peek = undo.peek_undo()
                success, msg = undo.undo()
                if success:
                    count += 1
                    console.print(f"  [{VAAL_GREEN}]{msg}[/]")
                else:
                    console.print(f"  [dim]{msg}[/dim]")
                    break
            if count == 0:
                console.print(f"  [dim]Nothing to undo.[/dim]")
            else:
                console.print(f"  [{VAAL_GREEN}]Undone {count} operation(s).[/]")
        else:
            peek = undo.peek_undo()
            if peek:
                console.print(f"  [dim]Will undo: {peek.summary()}[/dim]")
            success, msg = undo.undo()
            style = VAAL_GREEN if success else "dim"
            console.print(f"  [{style}]{msg}[/]")
            if success and peek:
                import subprocess
                _undo_path = peek.file_path
                try:
                    _git_result = subprocess.run(
                        ["git", "diff", "--stat", _undo_path],
                        capture_output=True, text=True, timeout=5,
                        cwd=os.path.dirname(_undo_path) or "."
                    )
                    if _git_result.stdout.strip():
                        for _gl in _git_result.stdout.strip().splitlines()[:5]:
                            console.print(f"  [dim]  git: {_gl}[/dim]")
                except Exception:
                    pass

    elif command == "/redo":
        from .undo_system import get_undo_system
        undo = get_undo_system()
        peek = undo.peek_redo()
        if peek:
            console.print(f"  [dim]Will redo: {peek.summary()}[/dim]")
        success, msg = undo.redo()
        style = VAAL_GREEN if success else "dim"
        console.print(f"  [{style}]{msg}[/]")

    elif command == "/pin":
        _handle_pin_command(arg, session)

    elif command == "/unpin":
        _handle_unpin_command(arg)

    elif command == "/db":
        from ..tools.db_tools import handle_db_command
        msg = handle_db_command(arg)
        console.print(f"  {msg}")

    elif command == "/api":
        from ..tools.api_tools import handle_api_command
        msg = handle_api_command(arg)
        console.print(f"  {msg}")

    elif command == "/env":
        env_mgr = components.get("env_manager") if components else None
        if env_mgr is None:
            from .env_manager import EnvManager
            env_mgr = EnvManager()
            if components is not None:
                components["env_manager"] = env_mgr
        msg = env_mgr.handle_command(arg)
        console.print(f"  {msg}")

    elif command == "/explain":
        result = _handle_explain_command(arg, session)
        if isinstance(result, str) and result.startswith("paste:"):
            return result

    elif command == "/migrate":
        _handle_migrate_command(arg, session)

    elif command in ("/plugin", "/plugins"):
        _handle_plugin_command(arg, components)

    elif command == "/agentmodel":
        _handle_agentmodel_command(arg, components)

    elif command == "/register":
        _handle_register_command(arg)

    elif command == "/remote":
        _handle_remote_command(arg, active_model, session, components)

    elif command == "/buddy":
        _handle_buddy_command(arg)

    elif command == "/doctor":
        _handle_doctor_command(active_model)

    elif command == "/deny":
        _handle_deny_command(arg, permissions)

    elif command in ("/directory", "/cd"):
        if not arg:
            cwd_now = os.getcwd().replace("\\", "/")
            console.print(f"  [bold]{cwd_now}[/bold]")
        else:
            target = os.path.expanduser(arg.strip())
            target = os.path.abspath(target)
            if not os.path.exists(target):
                console.print(f"[red]  Directory not found: {target}[/red]")
            elif not os.path.isdir(target):
                console.print(f"[red]  Not a directory: {target}[/red]")
            else:
                os.chdir(target)
                cwd_now = os.getcwd().replace("\\", "/")

                # Re-scan project info for the new directory
                new_project_info = load_cached_project(cwd_now) or scan_project(cwd_now)
                new_project_info_prompt = new_project_info.to_prompt_section() if new_project_info and new_project_info.languages else None

                # Reload project instructions (VAAL.md) from new directory
                new_project_instructions = load_project_instructions()

                # Rebuild system prompt with new CWD and project context
                new_system_prompt = build_system_prompt(
                    project_instructions=new_project_instructions,
                    project_info=new_project_info_prompt,
                )
                # Re-inject output style if active
                if styles and styles.current != "default":
                    style_inj = styles.get_prompt_injection()
                    if style_inj:
                        new_system_prompt += f"\n\n## Output Style\n{style_inj}"
                # Re-inject memories
                from .memory import MemoryStore
                mem_section = MemoryStore().to_prompt_section()
                if mem_section:
                    new_system_prompt += f"\n\n{mem_section}"
                # Re-inject active plan
                from .plans import get_active_plan
                plan = get_active_plan()
                if plan:
                    new_system_prompt += f"\n\n{plan.to_prompt_section()}"

                # Update the system message in the session
                if session.messages and session.messages[0]["role"] == "system":
                    session.messages[0]["content"] = new_system_prompt
                session.cwd = cwd_now

                refresh_screen(active_model[0], permissions.mode, cwd_now)
                console.print(f"[dim]  Changed directory to: {cwd_now}[/dim]")

    elif command == "/preview":
        _handle_preview_command(arg, session, active_model, permissions)

    elif command == "/effort":
        _handle_effort_command(arg)

    elif command == "/add-dir":
        _handle_add_dir_command(arg, session)

    elif command == "/summary":
        _handle_summary_command(session)

    elif command == "/stats":
        _handle_usage_stats_command(session, active_model, components)

    elif command == "/rewind":
        _handle_rewind_command(arg, session)

    elif command == "/debug-tool":
        _handle_debug_tool_command(arg)

    elif command == "/commit":
        _handle_commit_command(arg, session)

    elif command == "/test":
        result = _handle_test_command(arg, session)
        if isinstance(result, str) and result.startswith("paste:"):
            return result

    elif command == "/pr":
        _handle_pr_command(arg, session)

    elif command == "/diff":
        _handle_diff_command(arg, session)

    elif command == "/files":
        if not _session_files:
            console.print(f"[dim]  No files touched this session.[/dim]")
        else:
            console.print(f"[bold {VAAL_BLUE}]  Files this session:[/]")
            for fpath, action in _session_files.items():
                # Show relative path if possible
                try:
                    rel = os.path.relpath(fpath)
                except ValueError:
                    rel = fpath
                style = VAAL_GREEN if action in ("written", "edited") else "dim"
                console.print(f"    [{style}]{action:8s}[/] {rel}")

    else:
        console.print(f"[dim]  Unknown command: {command}. Type /help[/dim]")

    return True


def _handle_image_command(arg: str, session, active_model: list):
    """Handle /image <path> [prompt] — send an image for analysis."""
    parts = arg.strip().split(maxsplit=1)
    image_path = parts[0]
    prompt = parts[1] if len(parts) > 1 else "Describe this image in detail."

    try:
        b64_data, media_type = encode_image(image_path)
    except FileNotFoundError as e:
        console.print(f"[vaal.error]  {e}[/]")
        return
    except ValueError as e:
        console.print(f"[vaal.error]  {e}[/]")
        return

    model = active_model[0]
    if model.startswith("anthropic:") or "claude" in model.lower():
        msg = build_image_message(b64_data, media_type, prompt)
    else:
        msg = build_ollama_image_message(b64_data, prompt)

    session.messages.append({**msg, "timestamp": __import__("time").time()})
    size_kb = len(b64_data) * 3 // 4 // 1024
    console.print(f"[dim]  Attached image: {image_path} ({size_kb} KB, {media_type})[/dim]")
    console.print(f"[dim]  Prompt: {prompt}[/dim]")
    console.print(f"[dim]  Image added to conversation. Send a follow-up message or press Enter to analyze.[/dim]")


def _handle_paste_image_command(arg: str, session, active_model: list):
    """Handle /paste-image [prompt] — paste image from clipboard for analysis."""
    prompt = arg.strip() if arg.strip() else "Describe this image in detail."

    console.print(f"[dim]  Checking clipboard for image...[/dim]")
    result = get_clipboard_image()

    if result is None:
        console.print(f"[vaal.error]  No image found in clipboard. Copy an image first (e.g. screenshot, right-click > Copy Image).[/]")
        return

    b64_data, media_type = result

    model = active_model[0]
    if model.startswith("anthropic:") or "claude" in model.lower():
        msg = build_image_message(b64_data, media_type, prompt)
    else:
        msg = build_ollama_image_message(b64_data, prompt)

    session.messages.append({**msg, "timestamp": __import__("time").time()})
    size_kb = len(b64_data) * 3 // 4 // 1024
    console.print(f"[{VAAL_GREEN}]  Pasted image from clipboard ({size_kb} KB, {media_type})[/]")
    console.print(f"[dim]  Prompt: {prompt}[/dim]")
    console.print(f"[dim]  Image added to conversation. Send a follow-up message or press Enter to analyze.[/dim]")


def _handle_mcp_command(arg: str):
    """Handle /mcp connect|list|disconnect|tools commands."""
    from .mcp_client import get_mcp_manager
    mgr = get_mcp_manager()
    parts = arg.strip().split(maxsplit=2) if arg.strip() else []
    action = parts[0].lower() if parts else "list"

    if action == "list":
        servers = mgr.list_servers()
        if not servers:
            console.print(f"[dim]  No MCP servers configured. Use /mcp connect <name> <command>[/dim]")
        else:
            console.print(f"\n[bold {VAAL_BLUE}]  MCP Servers[/]")
            console.print(f"[dim]  {'─' * 40}[/dim]")
            for s in servers:
                status = f"[{VAAL_GREEN}]connected[/]" if s["connected"] else "[dim]disconnected[/dim]"
                console.print(f"  [{VAAL_CYAN}]{s['name']}[/] {status}")
                console.print(f"  [dim]  cmd: {s['command']}[/dim]")
                if s["tools"]:
                    console.print(f"  [dim]  tools: {', '.join(s['tools'][:10])}[/dim]")
            console.print()

    elif action == "connect" and len(parts) >= 3:
        name = parts[1]
        command = parts[2]
        console.print(f"[dim]  Connecting to MCP server '{name}'...[/dim]")
        success, message = mgr.connect(name, command)
        style = VAAL_GREEN if success else "vaal.error"
        console.print(f"  [{style}]{message}[/]")

    elif action == "disconnect" and len(parts) >= 2:
        name = parts[1]
        success, message = mgr.disconnect(name)
        style = VAAL_GREEN if success else "vaal.error"
        console.print(f"  [{style}]{message}[/]")

    elif action == "tools":
        tools = mgr.get_all_tools()
        if not tools:
            console.print(f"[dim]  No tools available. Connect an MCP server first.[/dim]")
        else:
            console.print(f"\n[bold {VAAL_BLUE}]  MCP Tools ({len(tools)})[/]")
            for t in tools:
                console.print(f"  [{VAAL_CYAN}]{t.name}[/] [dim]({t.server_name})[/dim]")
                if t.description:
                    console.print(f"  [dim]  {t.description[:80]}[/dim]")
            console.print()

    else:
        console.print(f"[dim]  Usage: /mcp connect <name> <command> | /mcp list | /mcp disconnect <name> | /mcp tools[/dim]")


def _handle_schedule_command(arg: str, active_model: list):
    """Handle /schedule <interval> <prompt> | /schedule list | /schedule stop <id>."""
    from .scheduler import get_scheduler
    scheduler = get_scheduler()
    parts = arg.strip().split(maxsplit=1) if arg.strip() else []
    action = parts[0].lower() if parts else "list"

    if action == "list":
        tasks = scheduler.list_tasks()
        if not tasks:
            console.print(f"[dim]  No scheduled tasks. Use /schedule <interval> <prompt> (e.g. /schedule 5m check status)[/dim]")
        else:
            console.print(f"\n[bold {VAAL_BLUE}]  Scheduled Tasks[/]")
            console.print(f"[dim]  {'─' * 40}[/dim]")
            for t in tasks:
                status = f"[{VAAL_GREEN}]active[/]" if t["active"] else "[dim]stopped[/dim]"
                console.print(f"  [{VAAL_CYAN}]{t['task_id']}[/] {status} every {t['interval_str']}")
                console.print(f"  [dim]  prompt: {t['prompt'][:60]}[/dim]")
                console.print(f"  [dim]  runs: {t['run_count']}[/dim]")
            console.print()

    elif action == "stop" and len(parts) >= 2:
        task_id = parts[1].strip()
        if scheduler.stop(task_id):
            console.print(f"  [{VAAL_GREEN}]Stopped {task_id}[/]")
        else:
            console.print(f"[dim]  Task not found: {task_id}[/dim]")

    elif action == "stop-all":
        scheduler.stop_all()
        console.print(f"  [{VAAL_GREEN}]Stopped all scheduled tasks.[/]")

    else:
        # Try to parse as interval + prompt
        import re
        m = re.match(r"^(\d+\s*(?:s|sec|secs|m|min|mins|h|hr|hrs|hour|hours))\s+(.+)$", arg.strip(), re.IGNORECASE)
        if m:
            interval_str = m.group(1).strip()
            prompt = m.group(2).strip()
            task = scheduler.schedule(interval_str, prompt)
            if task:
                console.print(f"  [{VAAL_GREEN}]Scheduled '{task.task_id}': every {interval_str}[/]")
                console.print(f"  [dim]  prompt: {prompt[:60]}[/dim]")
            else:
                console.print(f"[vaal.error]  Invalid interval: {interval_str}. Use e.g. 30s, 5m, 1h[/]")
        else:
            console.print(f"[dim]  Usage: /schedule <interval> <prompt> | /schedule list | /schedule stop <id> | /schedule stop-all[/dim]")


def _handle_collab_command(arg: str):
    """Handle /collab start|join|leave|send|info commands."""
    from .collaborative import collab_start, collab_join, collab_leave, collab_send, collab_info

    parts = arg.strip().split(maxsplit=1) if arg.strip() else []
    action = parts[0].lower() if parts else "info"

    if action == "start":
        success, result = collab_start()
        if success:
            console.print(f"  [{VAAL_GREEN}]Collab session started! Room code: [{VAAL_CYAN}]{result}[/][/]")
            console.print(f"  [dim]  Share this code with others: /collab join {result}[/dim]")
        else:
            console.print(f"[vaal.error]  {result}[/]")

    elif action == "join" and len(parts) >= 2:
        code = parts[1].strip()
        success, message = collab_join(code)
        style = VAAL_GREEN if success else "vaal.error"
        console.print(f"  [{style}]{message}[/]")

    elif action == "leave":
        success, message = collab_leave()
        style = VAAL_GREEN if success else "dim"
        console.print(f"  [{style}]{message}[/]")

    elif action == "send" and len(parts) >= 2:
        content = parts[1].strip()
        success, message = collab_send(content)
        style = VAAL_GREEN if success else "vaal.error"
        console.print(f"  [{style}]{message}[/]")

    elif action == "info":
        info = collab_info()
        if not info:
            console.print(f"[dim]  Not in a collab session. Use /collab start or /collab join <code>[/dim]")
        else:
            console.print(f"\n[bold {VAAL_BLUE}]  Collab Session[/]")
            console.print(f"  [dim]Room:[/dim] [{VAAL_CYAN}]{info['room_code']}[/]")
            console.print(f"  [dim]You:[/dim] {info['instance_name']}")
            participants = info.get("participants", [])
            console.print(f"  [dim]Participants ({len(participants)}):[/dim]")
            for p in participants:
                console.print(f"    [{p.get('instance_color', 'dim')}]{p['instance_name']}[/]")
            console.print()

    else:
        console.print(f"[dim]  Usage: /collab start | /collab join <code> | /collab leave | /collab send <msg> | /collab info[/dim]")


def _handle_review_command(arg: str, session, active_model: list, components):
    """Handle /review [file] — review uncommitted changes or a specific file."""
    from .code_review import get_diff, get_file_content, build_review_prompt
    from rich.text import Text

    if arg.strip():
        # Review a specific file
        content, error = get_file_content(arg.strip())
        if error:
            console.print(Text(f"  {error}", style="vaal.error"))
            return
        prompt = build_review_prompt(content, context=f"File: {arg.strip()}", review_type="file")
    else:
        # Review uncommitted diff
        diff, error = get_diff()
        if error:
            console.print(Text(f"  {error}", style="dim"))
            return
        prompt = build_review_prompt(diff, review_type="diff")

    console.print(f"[dim]  Sending for review...[/dim]")
    return "paste:" + prompt


def _handle_review_pr_command(arg: str, session, active_model: list, components):
    """Handle /review-pr <number> — review a GitHub pull request."""
    from .code_review import get_pr_diff, get_pr_info, build_review_prompt

    if not arg.strip():
        console.print(f"[dim]  Usage: /review-pr <pr-number>[/dim]")
        return

    pr_num = arg.strip()
    console.print(f"[dim]  Fetching PR #{pr_num}...[/dim]")

    pr_info, info_err = get_pr_info(pr_num)
    diff, diff_err = get_pr_diff(pr_num)

    if diff_err:
        from rich.text import Text
        console.print(Text(f"  {diff_err}", style="vaal.error"))
        return

    context = ""
    if pr_info:
        context = f"PR #{pr_num}: {pr_info.get('title', '')}\n{pr_info.get('body', '')[:500]}"

    prompt = build_review_prompt(diff, context=context, review_type="pr")
    console.print(f"[dim]  Sending PR diff for review...[/dim]")
    return "paste:" + prompt


def _handle_deps_command(arg: str):
    """Handle /deps [audit] — scan and audit project dependencies."""
    from .deps import scan_dep_files, format_dep_report, run_audit

    action = arg.strip().lower() if arg.strip() else "scan"

    console.print(f"[dim]  Scanning dependencies...[/dim]")
    dep_files = scan_dep_files()

    if not dep_files:
        console.print(f"[dim]  No dependency files found (requirements.txt, package.json, Cargo.toml, go.mod).[/dim]")
        return

    report = format_dep_report(dep_files)
    console.print(f"\n{report}")

    if action == "audit":
        console.print(f"[dim]  Running security audit...[/dim]")
        audit_result = run_audit(dep_files)
        console.print(f"\n{audit_result}")


def _handle_ssh_command(arg: str):
    """Handle /ssh connect|run|disconnect|info commands."""
    from .ssh_remote import get_ssh_manager

    mgr = get_ssh_manager()
    parts = arg.strip().split(maxsplit=1) if arg.strip() else []
    action = parts[0].lower() if parts else "info"

    if action == "connect" and len(parts) >= 2:
        target = parts[1].strip()
        console.print(f"[dim]  Connecting to {target}...[/dim]")
        success, message = mgr.connect(target)
        style = VAAL_GREEN if success else "vaal.error"
        console.print(f"  [{style}]{message}[/]")

    elif action == "run" and len(parts) >= 2:
        command = parts[1].strip()
        if not mgr.is_connected:
            console.print(f"[vaal.error]  Not connected. Use /ssh connect <user@host> first.[/]")
            return
        console.print(f"[dim]  Running on {mgr.connection.display}: {command}[/dim]")
        output, code = mgr.run_command(command)
        if output:
            console.print(output)
        if code != 0:
            console.print(f"[dim]  Exit code: {code}[/dim]")

    elif action == "disconnect":
        success, message = mgr.disconnect()
        style = VAAL_GREEN if success else "dim"
        console.print(f"  [{style}]{message}[/]")

    elif action == "info":
        info = mgr.info()
        if not info:
            console.print(f"[dim]  Not connected. Use /ssh connect <user@host>[/dim]")
        else:
            status = f"[{VAAL_GREEN}]connected[/]" if info["connected"] else "[dim]disconnected[/dim]"
            console.print(f"  [{VAAL_CYAN}]{info['target']}[/] {status}")
            if info.get("uptime_seconds"):
                mins = info["uptime_seconds"] // 60
                console.print(f"  [dim]  uptime: {mins}m[/dim]")

    else:
        console.print(f"[dim]  Usage: /ssh connect <user@host> | /ssh run <command> | /ssh disconnect | /ssh info[/dim]")


def _handle_explain_command(arg: str, session):
    """Handle /explain <error text> — explain an error or stack trace."""
    from .error_explain import detect_error, build_explain_prompt

    if not arg.strip():
        console.print(f"[dim]  Usage: /explain <error output or stack trace>[/dim]")
        console.print(f"[dim]  Paste the error output after /explain[/dim]")
        return

    error_text = arg.strip()
    prompt = build_explain_prompt(error_text)
    return "paste:" + prompt


def _handle_migrate_command(arg: str, session):
    """Handle /migrate <source> <target> — guided migration helper."""
    from .migration import get_migration_profile, scan_project_for_migration, print_migration_plan

    parts = arg.strip().split()
    if len(parts) < 2:
        console.print(f"[dim]  Usage: /migrate <source> <target>[/dim]")
        console.print(f"[dim]  Examples: /migrate flask fastapi, /migrate js ts, /migrate react nextjs[/dim]")
        return

    source, target = parts[0].lower(), parts[1].lower()
    profile = get_migration_profile(source, target)
    if not profile:
        console.print(f"[dim]  No migration profile for {source} -> {target}.[/dim]")
        console.print(f"[dim]  Available: flask->fastapi, js->ts, react->nextjs, express->fastify, vue2->vue3, webpack->vite, jest->vitest[/dim]")
        return

    console.print(f"[dim]  Scanning project for {profile['name']} migration...[/dim]")
    plan = scan_project_for_migration(os.getcwd(), source, target)
    print_migration_plan(console, plan)


def _handle_agentmodel_command(arg: str, components):
    """Handle /agentmodel [model] — set or show the model used by subagents."""
    uc = components.get("user_config") if components else None
    if uc is None:
        from .user_config import UserConfig
        uc = UserConfig()

    if not arg.strip():
        current = uc.agent_model
        if current:
            console.print(f"  [dim]Agent model:[/dim] [{VAAL_CYAN}]{current}[/]")
        else:
            console.print(f"  [dim]Agent model:[/dim] [dim](uses main model)[/dim]")
        console.print(f"  [dim]Usage: /agentmodel <model> — set agent model[/dim]")
        console.print(f"  [dim]       /agentmodel clear   — reset to main model[/dim]")
        return

    if arg.strip().lower() == "clear":
        uc.agent_model = ""
        uc.save()
        console.print(f"  [{VAAL_GREEN}]Agent model cleared — subagents will use the main model.[/]")
        return

    model_name = arg.strip()
    uc.agent_model = model_name
    uc.save()
    console.print(f"  [{VAAL_GREEN}]Agent model set to:[/] [{VAAL_CYAN}]{model_name}[/]")
    console.print(f"  [dim]All new subagents will use this model. Use /agentmodel clear to reset.[/dim]")


def _handle_preview_command(arg: str, session, active_model: list, permissions):
    """Handle /preview — live preview with interactive inspector overlay.

    /preview <file_or_dir>  — serve with overlay, open browser
    /preview stop           — stop the preview server
    /preview                — show status
    """
    from .preview_server import start_preview, stop_preview, preview_status, get_preview_server

    arg = arg.strip()

    if not arg:
        # Show status
        status = preview_status()
        if status["running"]:
            console.print(f"\n[bold {VAAL_BLUE}]  ⊙ Preview Server[/]")
            console.print(f"[dim]  {'─' * 40}[/dim]")
            console.print(f"  [bold]URL:[/bold]     [{VAAL_BLUE}]{status['url']}[/]")
            console.print(f"  [bold]Path:[/bold]    {status['path']}")
            console.print(f"  [bold]Clients:[/bold] {status['clients']} connected")
            console.print(f"  [bold]WS Port:[/bold] {status['ws_port']}")
            console.print(f"\n[dim]  Use /preview stop to stop.[/dim]")
        else:
            console.print(f"[dim]  No preview server running.[/dim]")
            console.print(f"[dim]  Usage: /preview <file_or_dir> — serve with interactive inspector[/dim]")
            console.print(f"[dim]  Example: /preview index.html[/dim]")
            console.print(f"[dim]  Example: /preview ./dist[/dim]")
        return

    if arg.lower() == "stop":
        status = preview_status()
        if status["running"]:
            stop_preview()
            console.print(f"[dim]  Preview server stopped.[/dim]")
        else:
            console.print(f"[dim]  No preview server running.[/dim]")
        return

    # Parse optional port: /preview file.html 8080
    parts = arg.split()
    path = parts[0]
    port = 5555
    if len(parts) > 1:
        try:
            port = int(parts[1])
        except ValueError:
            pass

    # Resolve path
    if not os.path.isabs(path):
        path = os.path.join(os.getcwd(), path)
    path = os.path.abspath(path)

    if not os.path.exists(path):
        console.print(f"[red]  Path not found: {path}[/red]")
        return

    model = active_model[0]

    try:
        url = start_preview(
            path=path,
            port=port,
            session=session,
            model=model,
            permissions=permissions,
            open_browser=True,
        )
        console.print(f"\n[bold {VAAL_BLUE}]  ⊙ Preview Server Started[/]")
        console.print(f"[dim]  {'─' * 40}[/dim]")
        console.print(f"  [{VAAL_BLUE}]{url}[/]")
        console.print(f"  [dim]Serving:[/dim] {path}")
        console.print(f"\n  [dim]• Click the purple ⊙ orb to inspect elements[/dim]")
        console.print(f"  [dim]• Or press Ctrl+Shift+V in the browser[/dim]")
        console.print(f"  [dim]• Click any element → describe what to change[/dim]")
        console.print(f"  [dim]• Vaal edits the source and hot-reloads[/dim]")
        console.print(f"\n[dim]  Use /preview stop to stop.[/dim]")
    except OSError as e:
        if "Address already in use" in str(e) or "10048" in str(e):
            console.print(f"[red]  Port {port} is already in use. Try: /preview {parts[0]} {port + 10}[/red]")
        else:
            console.print(f"[red]  Failed to start preview: {e}[/red]")
    except Exception as e:
        console.print(f"[red]  Failed to start preview: {e}[/red]")


def _handle_remote_command(arg: str, active_model: list, session, components):
    """Handle /remote [start|stop|status|token] — remote control via relay."""
    from .remote_control import get_remote_server, _get_token, _generate_token

    action = arg.strip().lower() if arg.strip() else "start"

    if action == "start":
        relay = get_remote_server()
        relay.active_model = active_model[0]

        def on_remote_prompt(prompt, responder):
            """Process a remote prompt — full agentic loop with tool execution."""
            from .llm import chat_with_tools_stream
            from .tool_executor import execute_tool, format_tool_result
            from .permissions import PermissionManager

            cwd = os.getcwd().replace("\\", "/")
            session.add_message("user", f"[CWD: {cwd}]\n[remote] {prompt}")
            console.print(f"\n  [dim][remote] {prompt[:80]}[/dim]")

            # Remote uses yolo mode — no interactive approval possible
            remote_perms = PermissionManager(mode="yolo")
            max_rounds = 20

            try:
                for _round in range(max_rounds):
                    chat_messages = session.get_chat_messages()
                    if _is_anthropic_model(active_model[0]):
                        chat_messages = _sanitize_messages(chat_messages)

                    content = ""
                    tool_calls = []
                    token_buffer = ""
                    last_flush = time.time()

                    for chunk in chat_with_tools_stream(
                        chat_messages, get_ollama_tools(all_tools()), model=active_model[0]
                    ):
                        if chunk.get("content"):
                            token = chunk["content"]
                            content += token
                            token_buffer += token
                            now = time.time()
                            if now - last_flush > 0.5 or "\n" in token_buffer:
                                responder.send_streaming(token_buffer)
                                token_buffer = ""
                                last_flush = now
                        if chunk.get("tool_calls"):
                            tool_calls.extend(chunk["tool_calls"])

                    if token_buffer:
                        responder.send_streaming(token_buffer)

                    # Add assistant message
                    if tool_calls and _is_anthropic_model(active_model[0]):
                        assistant_content = []
                        if content:
                            assistant_content.append({"type": "text", "text": content})
                        for tc in tool_calls:
                            func = tc.get("function", {})
                            assistant_content.append({
                                "type": "tool_use",
                                "id": tc.get("id", f"tool_{func.get('name', 'unknown')}"),
                                "name": func.get("name", ""),
                                "input": func.get("arguments", {}),
                            })
                        session.messages.append({
                            "role": "assistant", "content": assistant_content,
                            "timestamp": time.time(),
                        })
                    else:
                        session.add_message("assistant", content or "")

                    if not tool_calls:
                        # Done — no more tools to call
                        if content:
                            responder.send_stream_end()
                            console.print()
                            try:
                                md = Markdown(content, code_theme="monokai")
                                console.print(md, width=min(console.width - 4, 90))
                            except Exception:
                                console.print(content)
                            console.print()
                        else:
                            responder.send_response("(no response)")
                        break

                    # Execute tool calls
                    for tc in tool_calls:
                        func = tc.get("function", {})
                        tool_name = func.get("name", "")
                        tool_args = func.get("arguments", {})
                        tool_use_id = tc.get("id", f"tool_{tool_name}")

                        responder.send_tool_call(tool_name, str(tool_args)[:80])
                        console.print(f"  [dim][remote] tool: {tool_name}[/dim]")

                        result, executed = execute_tool(tool_name, tool_args, remote_perms)
                        formatted = format_tool_result(tool_name, result)

                        responder.send_tool_result(formatted[:200])

                        session.messages.append({
                            "role": "tool", "tool_use_id": tool_use_id,
                            "content": formatted, "timestamp": time.time(),
                        })

            except Exception as e:
                responder.send_error(str(e))
                console.print(f"  [bold red]✗Remote error:[/] [dim]{e}[/dim]")

        relay.set_prompt_callback(on_remote_prompt)
        ok, msg = relay.start()
        if ok:
            console.print(f"  [dim]✓[/dim] [bold]Remote control active[/]")
            for line in msg.split("\n"):
                console.print(f"  [dim]{line}[/dim]")
        else:
            console.print(f"  [vaal.error]{msg}[/]")

    elif action == "stop":
        relay = get_remote_server()
        relay.stop()
        console.print(f"  [{VAAL_GREEN}]Remote control stopped.[/]")

    elif action == "token":
        parts = arg.strip().split()
        if len(parts) > 1 and parts[1] == "new":
            token = _generate_token()
            console.print(f"  [{VAAL_GREEN}]New token:[/] {token}")
        else:
            token = _get_token()
            console.print(f"  [dim]Token:[/dim] {token}")
            console.print(f"  [dim]Use /remote token new to regenerate[/dim]")

    elif action == "status":
        relay = get_remote_server()
        if relay.is_running:
            console.print(f"  [dim]✓[/dim] [bold]Remote control connected[/]")
            console.print(f"  [dim]Relay: {relay.relay_url}[/dim]")
            console.print(f"  [dim]Token: {_get_token()}[/dim]")
            console.print(f"  [dim]Web UI: https://e-e.tools/vaal/?token={_get_token()}[/dim]")
        else:
            console.print(f"  [dim]Not connected. Type /remote to start.[/dim]")

    else:
        console.print(f"[dim]  Usage: /remote | /remote stop | /remote status | /remote token[/dim]")


VAAL_API = "https://e-e.tools/vaal/api.php"

from .config import VAAL_DIR as _VAAL_DIR
VAAL_TOKEN_FILE = _VAAL_DIR / "vaal_account.json"


def _vaal_api(action: str, method: str = "GET", data: dict = None, token: str = "") -> dict | None:
    """Call the vaal API with graceful error handling. Returns response dict or None."""
    import httpx
    url = f"{VAAL_API}?action={action}"
    if token:
        url += f"&token={token}"
    try:
        if method == "POST":
            r = httpx.post(url, json=data or {}, timeout=8)
        else:
            r = httpx.get(url, timeout=8)
        return r.json()
    except httpx.ConnectError:
        console.print(f"  [dim]Could not reach e-e.tools — check your internet and try again.[/dim]")
        return None
    except httpx.TimeoutException:
        console.print(f"  [dim]Server timed out — try again later.[/dim]")
        return None
    except Exception:
        console.print(f"  [dim]Connection failed — try again later.[/dim]")
        return None


def _handle_vaal_login(token_or_empty: str, components):
    """Handle /login vaal [token] — authenticate with e-e.tools."""
    if token_or_empty:
        token = token_or_empty.strip()
    else:
        console.print(f"\n  [{VAAL_BLUE}]Vaal Account Login[/]")
        console.print(f"  [dim]Register at https://e-e.tools/vaal/ or use /register[/dim]\n")
        try:
            username = input("  Username or email: ").strip()
            if not username:
                console.print(f"  [dim]Cancelled.[/dim]")
                return
            password = input("  Password: ").strip()
            if not password:
                console.print(f"  [dim]Cancelled.[/dim]")
                return
        except (EOFError, KeyboardInterrupt):
            console.print(f"\n  [dim]Cancelled.[/dim]")
            return

        console.print(f"  [dim]Logging in...[/dim]")
        result = _vaal_api("login", method="POST", data={"username": username, "password": password})
        if not result:
            return
        if not result.get("ok"):
            console.print(f"  [dim]{result.get('error', 'Login failed')}[/dim]")
            return
        token = result["token"]
        # Save immediately — don't need a separate validate call
        _VAAL_DIR.mkdir(exist_ok=True)
        VAAL_TOKEN_FILE.write_text(json.dumps({
            "token": token, "username": result["username"],
        }, indent=2), encoding="utf-8")
        console.print(f"  [dim]✓[/dim] [bold]Logged in as {result['username']}[/]")
        return

    # Direct token login — validate it
    console.print(f"  [dim]Validating token...[/dim]")
    result = _vaal_api("validate", token=token)
    if not result:
        return
    if result.get("valid"):
        _VAAL_DIR.mkdir(exist_ok=True)
        VAAL_TOKEN_FILE.write_text(json.dumps({
            "token": token, "username": result["username"],
        }, indent=2), encoding="utf-8")
        console.print(f"  [dim]✓[/dim] [bold]Authenticated as {result['username']}[/]")
    else:
        console.print(f"  [dim]Invalid token. Register at https://e-e.tools/vaal/[/dim]")


def _handle_register_command(arg: str):
    """Handle /register — create a vaal account on e-e.tools."""
    console.print(f"\n  [{VAAL_BLUE}]Create Vaal Account[/]\n")
    try:
        username = input("  Username (3-20 chars): ").strip()
        email = input("  Email: ").strip()
        password = input("  Password (6+ chars): ").strip()
        password2 = input("  Confirm password: ").strip()
    except (EOFError, KeyboardInterrupt):
        console.print(f"\n  [dim]Cancelled.[/dim]")
        return

    if password != password2:
        console.print(f"  [dim]Passwords don't match.[/dim]")
        return

    result = _vaal_api("register", method="POST", data={
        "username": username, "email": email, "password": password,
    })
    if not result:
        return
    if result.get("ok"):
        token = result["token"]
        _VAAL_DIR.mkdir(exist_ok=True)
        VAAL_TOKEN_FILE.write_text(json.dumps({
            "token": token, "username": username,
        }, indent=2), encoding="utf-8")
        console.print(f"  [dim]✓[/dim] [bold]Account created! Logged in as {username}[/]")
    else:
        console.print(f"  [dim]{result.get('error', 'Registration failed')}[/dim]")


def get_vaal_user() -> dict | None:
    """Get the logged-in vaal user, or None."""
    if VAAL_TOKEN_FILE.exists():
        try:
            return json.loads(VAAL_TOKEN_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return None


def _handle_buddy_command(arg: str):
    """Handle /buddy [hatch|show|reroll|name] — companion system."""
    from .buddy import get_buddy, hatch_buddy, format_buddy_card, roll_buddy, save_buddy, RARITY_COLORS

    action = arg.strip().lower().split(maxsplit=1) if arg.strip() else ["show"]
    cmd = action[0]
    cmd_arg = action[1] if len(action) > 1 else ""

    buddy = get_buddy()

    if cmd == "hatch" or (cmd == "show" and not buddy):
        # Hatch a new buddy
        from .buddy import play_hatch_animation
        user = get_vaal_user()
        user_id = user["username"] if user else "anon"
        buddy = hatch_buddy(user_id)
        play_hatch_animation(buddy)
        # Show stats after animation
        stats_dict = buddy.get("stats", {})
        for stat, val in stats_dict.items():
            bar = "█" * (val // 10) + "░" * (10 - val // 10)
            console.print(f"  [dim]{stat:10s}[/dim] [{VAAL_CYAN}]{bar}[/] {val}")
        console.print()

    elif cmd == "show":
        rcolor = RARITY_COLORS.get(buddy["rarity"], "dim")
        console.print()
        console.print(f"[{rcolor}]{format_buddy_card(buddy)}[/]")
        console.print()

    elif cmd == "reroll":
        from .buddy import play_hatch_animation
        import secrets
        seed = secrets.token_hex(8)
        bones = roll_buddy(seed)
        buddy = {**bones, "name": bones["species"].title(), "personality": "A rerolled companion", "hatched_at": int(time.time())}
        save_buddy(buddy)
        play_hatch_animation(buddy)
        stats_dict = buddy.get("stats", {})
        for stat, val in stats_dict.items():
            bar = "█" * (val // 10) + "░" * (10 - val // 10)
            console.print(f"  [dim]{stat:10s}[/dim] [{VAAL_CYAN}]{bar}[/] {val}")
        console.print()

    elif cmd == "name" and cmd_arg:
        if not buddy:
            console.print(f"  [dim]No buddy yet. Use /buddy hatch[/dim]")
            return
        buddy["name"] = cmd_arg
        save_buddy(buddy)
        console.print(f"  [{VAAL_GREEN}]Renamed to {cmd_arg}[/]")

    else:
        console.print(f"[dim]  /buddy          — Show your buddy[/dim]")
        console.print(f"[dim]  /buddy hatch    — Hatch a new buddy[/dim]")
        console.print(f"[dim]  /buddy reroll   — Reroll (random seed)[/dim]")
        console.print(f"[dim]  /buddy name X   — Rename your buddy[/dim]")


def _handle_doctor_command(active_model: list):
    """Handle /doctor — system health diagnostics."""
    import sys
    import shutil
    import platform as plat

    console.print(f"\n[bold {VAAL_BLUE}]  Vaal Doctor[/]")
    console.print(f"[dim]  {'─' * 40}[/dim]")

    # Python
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    console.print(f"  [{VAAL_GREEN}]OK[/] Python {py_ver} ({plat.python_implementation()})")

    # Platform
    console.print(f"  [{VAAL_GREEN}]OK[/] Platform: {plat.system()} {plat.release()}")

    # Current model
    model = active_model[0] if active_model else "none"
    console.print(f"  [dim]--[/dim] Active model: {model}")

    # Ollama
    try:
        import httpx
        from .config import OLLAMA_HOST
        r = httpx.get(f"{OLLAMA_HOST}/api/tags", timeout=3)
        if r.status_code == 200:
            data = r.json()
            model_count = len(data.get("models", []))
            console.print(f"  [{VAAL_GREEN}]OK[/] Ollama: connected ({model_count} models installed)")
        else:
            console.print(f"  [{VAAL_YELLOW}]--[/] Ollama: responded with {r.status_code}")
    except Exception:
        console.print(f"  [dim]--[/dim] Ollama: not running (local models unavailable)")

    # Provider auth
    from pathlib import Path
    keys_file = Path.home() / ".vaal" / "keys.json"
    creds_file = Path.home() / ".vaal" / "credentials.json"
    authed_providers = []
    if keys_file.exists():
        try:
            import json
            keys = json.loads(keys_file.read_text(encoding="utf-8"))
            authed_providers.extend(k.replace("_api_key", "") for k, v in keys.items() if v)
        except Exception:
            pass
    if creds_file.exists():
        try:
            import json
            creds = json.loads(creds_file.read_text(encoding="utf-8"))
            if creds.get("access_token"):
                authed_providers.append("anthropic (oauth)")
            elif creds.get("claudeAiOauth"):
                authed_providers.append("anthropic (oauth)")
        except Exception:
            pass
    # Also check Claude Code credentials as fallback
    cc_creds = Path.home() / ".claude" / ".credentials.json"
    if cc_creds.exists() and "anthropic" not in " ".join(authed_providers):
        try:
            import json
            cc = json.loads(cc_creds.read_text(encoding="utf-8"))
            if cc.get("claudeAiOauth") or cc.get("access_token"):
                authed_providers.append("anthropic (claude-code)")
        except Exception:
            pass
    if authed_providers:
        console.print(f"  [{VAAL_GREEN}]OK[/] Providers: {', '.join(authed_providers)}")
    else:
        console.print(f"  [dim]--[/dim] Providers: none configured (use /login)")

    # Git
    git_path = shutil.which("git")
    if git_path:
        import subprocess
        try:
            result = subprocess.run(["git", "--version"], capture_output=True, text=True, timeout=5)
            ver = result.stdout.strip()
            console.print(f"  [{VAAL_GREEN}]OK[/] {ver}")
        except Exception:
            console.print(f"  [{VAAL_GREEN}]OK[/] git found at {git_path}")
    else:
        console.print(f"  [vaal.error]MISS[/] git: not found on PATH")

    # ripgrep
    rg_path = shutil.which("rg")
    if rg_path:
        console.print(f"  [{VAAL_GREEN}]OK[/] ripgrep: found")
    else:
        console.print(f"  [dim]--[/dim] ripgrep: not found (grep will use Python fallback)")

    # Tool count
    from ..tools.registry import all_tools as get_all_tools
    tool_count = len(get_all_tools())
    console.print(f"  [{VAAL_GREEN}]OK[/] Tools: {tool_count} registered")

    # Plugin count
    from .plugins import PLUGINS_DIR
    plugin_count = len(list(PLUGINS_DIR.glob("*.py"))) if PLUGINS_DIR.exists() else 0
    if plugin_count:
        console.print(f"  [{VAAL_GREEN}]OK[/] Plugins: {plugin_count}")
    else:
        console.print(f"  [dim]--[/dim] Plugins: none (use /plugin create)")

    # Disk space
    try:
        usage = shutil.disk_usage(os.getcwd())
        free_gb = usage.free / (1024 ** 3)
        style = VAAL_GREEN if free_gb > 5 else VAAL_YELLOW
        console.print(f"  [{style}]OK[/] Disk: {free_gb:.1f} GB free")
    except Exception:
        pass

    # Data dir
    from .config import VAAL_DIR
    console.print(f"  [dim]--[/dim] Data dir: {VAAL_DIR}")
    console.print()


def _handle_stats_command(session, active_model: list, components: dict):
    """Handle /stats — comprehensive session and usage statistics dashboard."""
    import platform as plat
    from pathlib import Path
    from .config import VAAL_DIR, SESSIONS_DIR, HISTORY_FILE, MAX_CONTEXT_TOKENS
    from ..tools.registry import all_tools as get_all_tools
    from .plugins import PLUGINS_DIR

    now = time.time()
    uptime_secs = now - stats.session_start
    hours, remainder = divmod(int(uptime_secs), 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        uptime_str = f"{hours}h {minutes}m {secs}s"
    elif minutes > 0:
        uptime_str = f"{minutes}m {secs}s"
    else:
        uptime_str = f"{secs}s"

    pretty_model = _beautify_model_name(active_model[0])
    is_cloud = _is_cloud_model(active_model[0])

    # ── Header ──
    console.print()
    console.print(f"  [bold {VAAL_BLUE}]⬡ Session Statistics[/]")
    console.print(f"  [dim]{'─' * 50}[/dim]")

    # ── Session overview ──
    console.print(f"  [bold {VAAL_BLUE}]Session[/]")
    console.print(f"    [dim]ID:[/dim]          {session.session_id}")
    console.print(f"    [dim]Model:[/dim]       [bold]{pretty_model}[/bold]", end="")
    if is_cloud:
        label = _get_cloud_label(active_model[0])
        console.print(f" [#af87ff]{label}[/]")
    else:
        console.print()
    console.print(f"    [dim]Uptime:[/dim]      {uptime_str}")
    console.print(f"    [dim]Messages:[/dim]    {stats.messages}")
    console.print(f"    [dim]CWD:[/dim]         {os.getcwd().replace(chr(92), '/')}")
    console.print()

    # ── Token usage ──
    console.print(f"  [bold {VAAL_BLUE}]Tokens[/]")
    console.print(f"    [dim]Total:[/dim]       [{VAAL_CYAN}]{stats.total_tokens:,}[/]")
    if stats.total_time > 0:
        avg_tps = stats.total_tokens / stats.total_time
        console.print(f"    [dim]Speed:[/dim]       [{VAAL_CYAN}]{avg_tps:.1f} tok/s avg[/]")
    if components and "ctx_manager" in components:
        ctx = components["ctx_manager"]
        used, mx = ctx.usage(session.messages)
        pct = ctx.usage_pct(session.messages)
        bar_width = 20
        filled = int(pct * bar_width)
        bar = "█" * filled + "░" * (bar_width - filled)
        bar_color = VAAL_GREEN if pct < 0.6 else (VAAL_YELLOW if pct < 0.8 else VAAL_RED)
        console.print(f"    [dim]Context:[/dim]     [{bar_color}]{bar}[/] {used:,}/{mx:,} ({pct:.0%})")
    if is_cloud and stats.est_cost > 0:
        console.print(f"    [dim]Est. cost:[/dim]   [{VAAL_CYAN}]${stats.est_cost:.4f}[/]")
    if components and "cost_tracker" in components:
        tracker = components["cost_tracker"]
        if tracker.events:
            console.print(f"    [dim]LLM calls:[/dim]   {len(tracker.events)}")
            console.print(f"    [dim]Input tok:[/dim]   [{VAAL_CYAN}]{tracker.total_input:,}[/]")
            console.print(f"    [dim]Output tok:[/dim]  [{VAAL_CYAN}]{tracker.total_output:,}[/]")
    console.print()

    # ── Tool usage ──
    console.print(f"  [bold {VAAL_BLUE}]Tools[/]")
    console.print(f"    [dim]Total calls:[/dim] [{VAAL_CYAN}]{stats.tool_calls}[/]")
    if stats.tool_usage:
        # Sort by count descending
        sorted_tools = sorted(stats.tool_usage.items(), key=lambda x: x[1], reverse=True)
        console.print(f"    [dim]Breakdown:[/dim]")
        for tool_name, count in sorted_tools[:15]:
            bar_len = min(count, 30)
            bar = "▓" * bar_len
            console.print(f"      [{VAAL_CYAN}]{tool_name:20s}[/] [{VAAL_DIM}]{bar}[/] {count}")
    else:
        console.print(f"    [dim]No tool calls yet.[/dim]")
    console.print()

    # ── Agents & Tasks ──
    pool = get_agent_pool()
    tm = get_task_manager()
    all_tasks = tm.list_all()
    agents = pool.status_summary()
    if all_tasks or agents:
        console.print(f"  [bold {VAAL_BLUE}]Agents & Tasks[/]")
        if agents:
            console.print(f"    [dim]Agents:[/dim]      {agents}")
        if all_tasks:
            done = sum(1 for t in all_tasks if t.status == TaskStatus.DONE)
            total = len(all_tasks)
            console.print(f"    [dim]Tasks:[/dim]       {done}/{total} complete")
        console.print()

    # ── Historical stats ──
    console.print(f"  [bold {VAAL_BLUE}]Lifetime[/]")

    # Session count
    try:
        session_count = len(list(SESSIONS_DIR.glob("*.json"))) if SESSIONS_DIR.exists() else 0
        console.print(f"    [dim]Sessions:[/dim]    {session_count}")
    except Exception:
        pass

    # Prompt history count
    try:
        if HISTORY_FILE.exists():
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                prompt_count = sum(1 for line in f if line.strip())
            console.print(f"    [dim]Prompts:[/dim]     {prompt_count:,}")
        else:
            console.print(f"    [dim]Prompts:[/dim]     0")
    except Exception:
        console.print(f"    [dim]Prompts:[/dim]     ?")

    # Memory count
    from .config import MEMORY_DIR
    try:
        mem_count = len(list(MEMORY_DIR.glob("*.md"))) if MEMORY_DIR.exists() else 0
        if mem_count:
            console.print(f"    [dim]Memories:[/dim]    {mem_count}")
    except Exception:
        pass

    # Plugin count
    try:
        plugin_count = len(list(PLUGINS_DIR.glob("*.py"))) if PLUGINS_DIR.exists() else 0
        if plugin_count:
            console.print(f"    [dim]Plugins:[/dim]     {plugin_count}")
    except Exception:
        pass

    # Tool count
    tool_count = len(get_all_tools())
    console.print(f"    [dim]Tools:[/dim]       {tool_count} registered")

    # Data dir size
    try:
        total_size = 0
        if VAAL_DIR.exists():
            for f in VAAL_DIR.rglob("*"):
                if f.is_file():
                    total_size += f.stat().st_size
        if total_size > 0:
            if total_size > 1024 * 1024:
                size_str = f"{total_size / (1024 * 1024):.1f} MB"
            else:
                size_str = f"{total_size / 1024:.0f} KB"
            console.print(f"    [dim]Data size:[/dim]   {size_str}")
    except Exception:
        pass

    console.print()


def _handle_deny_command(arg: str, permissions):
    """Handle /deny <tool_name_or_prefix> — block tools by name or prefix."""
    if not arg.strip():
        if permissions._deny_names or permissions._deny_prefixes:
            console.print(f"\n[bold {VAAL_BLUE}]  Denied Tools[/]")
            if permissions._deny_names:
                console.print(f"  [dim]Names:[/dim] {', '.join(sorted(permissions._deny_names))}")
            if permissions._deny_prefixes:
                console.print(f"  [dim]Prefixes:[/dim] {', '.join(sorted(permissions._deny_prefixes))}")
            console.print()
        else:
            console.print(f"[dim]  No tools denied. Usage:[/dim]")
            console.print(f"[dim]    /deny <tool_name>     — Block a specific tool[/dim]")
            console.print(f"[dim]    /deny prefix:<prefix> — Block tools starting with prefix[/dim]")
            console.print(f"[dim]    /deny clear           — Remove all deny rules[/dim]")
        return

    parts = arg.strip().split()
    action = parts[0].lower()

    if action == "clear":
        permissions._deny_names.clear()
        permissions._deny_prefixes.clear()
        console.print(f"  [{VAAL_GREEN}]Cleared all deny rules.[/]")
    elif action.startswith("prefix:"):
        prefix = action[7:]
        if prefix:
            permissions.deny_prefix(prefix)
            console.print(f"  [{VAAL_GREEN}]Denied prefix: {prefix}*[/]")
    else:
        permissions.deny_tool(action)
        console.print(f"  [{VAAL_GREEN}]Denied tool: {action}[/]")


def _handle_plugin_command(arg: str, components):
    """Handle /plugin list|create|remove|reload|info commands."""
    from .plugins import load_plugins, PLUGINS_DIR
    from ..tools.registry import all_tools, _tools

    parts = arg.strip().split(maxsplit=1) if arg.strip() else []
    action = parts[0].lower() if parts else "list"
    plugin_arg = parts[1].strip() if len(parts) > 1 else ""

    if action == "list":
        if not PLUGINS_DIR.exists() or not list(PLUGINS_DIR.glob("*.py")):
            console.print(f"[dim]  No plugins installed. Use /plugin create <name> to make one.[/dim]")
            console.print(f"[dim]  Plugin directory: {PLUGINS_DIR}[/dim]")
            return

        console.print(f"\n[bold {VAAL_BLUE}]  Plugins[/]")
        console.print(f"[dim]  {'─' * 40}[/dim]")
        for p in sorted(PLUGINS_DIR.glob("*.py")):
            if p.name.startswith("_"):
                continue
            name = p.stem
            size = p.stat().st_size
            # Check if it has a register function
            try:
                content = p.read_text(encoding="utf-8")
                has_register = "def register(" in content
                tool_count = content.count("registry.register_tool(")
                status = f"[{VAAL_GREEN}]{tool_count} tool{'s' if tool_count != 1 else ''}[/]" if has_register else "[dim]no register()[/dim]"
            except Exception:
                status = "[dim]unreadable[/dim]"
            console.print(f"  [{VAAL_CYAN}]{name}[/] {status} [dim]({size} bytes)[/dim]")
        console.print(f"\n  [dim]Dir: {PLUGINS_DIR}[/dim]")
        console.print()

    elif action == "create" and plugin_arg:
        name = plugin_arg.replace(" ", "_").replace("-", "_").lower()
        if not name.isidentifier():
            console.print(f"[vaal.error]  Invalid plugin name: {name}. Must be a valid Python identifier.[/]")
            return

        PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
        plugin_path = PLUGINS_DIR / f"{name}.py"
        if plugin_path.exists():
            console.print(f"[vaal.error]  Plugin '{name}' already exists at {plugin_path}[/]")
            return

        template = f'''"""Vaal plugin: {name}

This plugin registers custom tools that the LLM can use.
Place this file in ~/.vaal/plugins/ and restart vaal (or /plugin reload).
"""


def register(registry):
    """Called by vaal on startup. Use registry.register_tool() to add tools."""

    @_tool(registry,
        name="{name}_example",
        description="Example tool from the {name} plugin. Replace this with your own.",
        parameters={{
            "input": {{"description": "The input to process", "required": True}},
        }},
    )
    def example_tool(input: str) -> str:
        return f"Plugin {name} received: {{input}}"


def _tool(registry, name, description, parameters, dangerous=False):
    """Helper decorator to register a tool."""
    def decorator(func):
        registry.register_tool(
            name=name,
            description=description,
            parameters=parameters,
            handler=func,
            dangerous=dangerous,
        )
        return func
    return decorator
'''
        plugin_path.write_text(template, encoding="utf-8")
        console.print(f"  [{VAAL_GREEN}]Created plugin: {plugin_path}[/]")
        console.print(f"  [dim]  Edit the file, then /plugin reload to activate.[/dim]")

    elif action == "remove" and plugin_arg:
        name = plugin_arg.replace(" ", "_").replace("-", "_").lower()
        plugin_path = PLUGINS_DIR / f"{name}.py"
        if not plugin_path.exists():
            console.print(f"[vaal.error]  Plugin '{name}' not found.[/]")
            return

        # Remove tools registered by this plugin
        try:
            content = plugin_path.read_text(encoding="utf-8")
            # Find tool names registered
            import re
            tool_names = re.findall(r'name="([^"]+)"', content)
            removed_tools = []
            for tn in tool_names:
                if tn in _tools:
                    del _tools[tn]
                    removed_tools.append(tn)
        except Exception:
            removed_tools = []

        plugin_path.unlink()
        console.print(f"  [{VAAL_GREEN}]Removed plugin: {name}[/]")
        if removed_tools:
            console.print(f"  [dim]  Unregistered tools: {', '.join(removed_tools)}[/dim]")

    elif action == "reload":
        # Track tools before reload
        tools_before = set(_tools.keys())

        loaded = load_plugins()

        tools_after = set(_tools.keys())
        new_tools = tools_after - tools_before

        if loaded:
            console.print(f"  [{VAAL_GREEN}]Reloaded {len(loaded)} plugin{'s' if len(loaded) != 1 else ''}: {', '.join(loaded)}[/]")
            if new_tools:
                console.print(f"  [dim]  New tools: {', '.join(new_tools)}[/dim]")
            # Refresh the ollama tools list if components available
            if components:
                from .llm import get_ollama_tools
                from ..tools.registry import all_tools as get_all_tools
                # The tools are in the global registry, subagents will pick them up automatically
                console.print(f"  [dim]  Tool registry updated ({len(_tools)} total tools)[/dim]")
        else:
            console.print(f"[dim]  No plugins found to load.[/dim]")

    elif action == "info" and plugin_arg:
        name = plugin_arg.replace(" ", "_").replace("-", "_").lower()
        plugin_path = PLUGINS_DIR / f"{name}.py"
        if not plugin_path.exists():
            console.print(f"[vaal.error]  Plugin '{name}' not found.[/]")
            return

        content = plugin_path.read_text(encoding="utf-8")
        # Extract docstring
        import ast
        try:
            tree = ast.parse(content)
            docstring = ast.get_docstring(tree) or "(no description)"
        except Exception:
            docstring = "(parse error)"

        import re
        tool_names = re.findall(r'name="([^"]+)"', content)
        lines = content.count("\n") + 1

        console.print(f"\n[bold {VAAL_BLUE}]  Plugin: {name}[/]")
        console.print(f"  [dim]{docstring}[/dim]")
        console.print(f"  [dim]Path: {plugin_path}[/dim]")
        console.print(f"  [dim]Size: {plugin_path.stat().st_size} bytes, {lines} lines[/dim]")
        if tool_names:
            console.print(f"  [dim]Tools: {', '.join(tool_names)}[/dim]")
            # Show which are actually registered
            for tn in tool_names:
                if tn in _tools:
                    td = _tools[tn]
                    console.print(f"    [{VAAL_CYAN}]{tn}[/] — {td.description[:60]}")
                else:
                    console.print(f"    [dim]{tn} (not loaded)[/dim]")
        console.print()

    elif action == "search" and plugin_arg:
        _registry_search(plugin_arg)

    elif action == "install" and plugin_arg:
        _registry_install(plugin_arg)

    elif action == "publish" and plugin_arg:
        _registry_publish(plugin_arg, PLUGINS_DIR)

    elif action == "browse":
        _registry_browse()

    elif action == "dir":
        PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
        console.print(f"  [dim]{PLUGINS_DIR}[/dim]")

    else:
        console.print(f"[dim]  Usage:[/dim]")
        console.print(f"[dim]    /plugin list              — Show installed plugins[/dim]")
        console.print(f"[dim]    /plugin create <name>     — Create a new plugin from template[/dim]")
        console.print(f"[dim]    /plugin remove <name>     — Remove a plugin[/dim]")
        console.print(f"[dim]    /plugin reload            — Reload all plugins[/dim]")
        console.print(f"[dim]    /plugin info <name>       — Show plugin details[/dim]")
        console.print(f"[dim]    /plugin dir               — Show plugin directory path[/dim]")
        console.print(f"[dim]    /plugin search <query>    — Search the plugin registry[/dim]")
        console.print(f"[dim]    /plugin install <name>    — Install a plugin from the registry[/dim]")
        console.print(f"[dim]    /plugin publish <name>    — Publish a local plugin to the registry[/dim]")
        console.print(f"[dim]    /plugin browse            — Browse top plugins from the registry[/dim]")


VAAL_REGISTRY = "https://e-e.tools/vaal/registry.php"


def _registry_api(action: str, method: str = "GET", data: dict = None, params: dict = None, token: str = "") -> dict | None:
    """Call the vaal registry API with graceful error handling."""
    import httpx
    url = f"{VAAL_REGISTRY}?action={action}"
    if params:
        for k, v in params.items():
            url += f"&{k}={v}"
    headers = {}
    if token:
        headers["X-Vaal-Token"] = token
    try:
        if method == "POST":
            r = httpx.post(url, json=data or {}, headers=headers, timeout=10)
        else:
            r = httpx.get(url, headers=headers, timeout=10)
        return r.json()
    except httpx.ConnectError:
        console.print(f"  [dim]Could not reach e-e.tools — check your internet and try again.[/dim]")
        return None
    except httpx.TimeoutException:
        console.print(f"  [dim]Server timed out — try again later.[/dim]")
        return None
    except Exception:
        console.print(f"  [dim]Connection failed — try again later.[/dim]")
        return None


def _registry_search(query: str):
    """Search the plugin registry."""
    console.print(f"  [dim]Searching registry for '{query}'...[/dim]")
    data = _registry_api("list", params={"query": query})
    if not data:
        return
    plugins = data.get("plugins", [])
    if not plugins:
        console.print(f"  [dim]No plugins found matching '{query}'.[/dim]")
        return
    console.print(f"\n[bold {VAAL_BLUE}]  Registry Results[/] [dim]({len(plugins)} found)[/dim]")
    console.print(f"[dim]  {'─' * 50}[/dim]")
    for p in plugins:
        desc = p.get("description", "") or ""
        desc_short = (desc[:60] + "...") if len(desc) > 63 else desc
        console.print(f"  [{VAAL_CYAN}]{p['name']}[/] [dim]v{p.get('version', '?')}[/dim] by [bold]{p.get('author', '?')}[/]  [dim]({p.get('installs', 0)} installs)[/dim]")
        if desc_short:
            console.print(f"    [dim]{desc_short}[/dim]")
    console.print(f"\n  [dim]Install with: /plugin install <name>[/dim]\n")


def _registry_install(name: str):
    """Install a plugin from the registry."""
    from .plugins import load_plugins, PLUGINS_DIR
    name = name.replace(" ", "_").replace("-", "_").lower()

    console.print(f"  [dim]Fetching plugin '{name}' from registry...[/dim]")
    data = _registry_api("get", params={"name": name})
    if not data:
        return
    if data.get("error"):
        console.print(f"  [dim]{data['error']}[/dim]")
        return

    code = data.get("code")
    if not code:
        console.print(f"  [dim]Plugin has no code — skipping.[/dim]")
        return

    PLUGINS_DIR.mkdir(parents=True, exist_ok=True)
    plugin_path = PLUGINS_DIR / f"{name}.py"
    if plugin_path.exists():
        console.print(f"  [dim]Plugin '{name}' already exists locally. Overwriting...[/dim]")

    plugin_path.write_text(code, encoding="utf-8")
    console.print(f"  [{VAAL_GREEN}]Installed:[/] {name} v{data.get('version', '?')} by {data.get('author', '?')}")

    # Hot-load
    loaded = load_plugins()
    if loaded:
        console.print(f"  [dim]Loaded {len(loaded)} plugin{'s' if len(loaded) != 1 else ''}.[/dim]")

    # Increment install count (fire-and-forget)
    _registry_api("install_count", params={"name": name})


def _registry_publish(name: str, plugins_dir):
    """Publish a local plugin to the registry."""
    name = name.replace(" ", "_").replace("-", "_").lower()
    plugin_path = plugins_dir / f"{name}.py"
    if not plugin_path.exists():
        console.print(f"  [dim]Plugin '{name}' not found locally at {plugin_path}[/dim]")
        return

    user = get_vaal_user()
    if not user or not user.get("token"):
        console.print(f"  [dim]You must be logged in to publish. Use /login vaal first.[/dim]")
        return

    code = plugin_path.read_text(encoding="utf-8")

    # Extract description from module docstring
    description = ""
    try:
        import ast
        tree = ast.parse(code)
        description = ast.get_docstring(tree) or ""
    except Exception:
        pass

    # Extract version from code if present
    version = "1.0.0"
    try:
        import re
        ver_match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', code)
        if ver_match:
            version = ver_match.group(1)
    except Exception:
        pass

    console.print(f"  [dim]Publishing '{name}' to registry...[/dim]")
    data = _registry_api("publish", method="POST", data={
        "name": name,
        "description": description,
        "version": version,
        "code": code,
    }, token=user["token"])
    if not data:
        return
    if data.get("ok"):
        action = "Updated" if data.get("updated") else "Published"
        console.print(f"  [{VAAL_GREEN}]{action}:[/] {data.get('message', name)}")
    else:
        console.print(f"  [dim]{data.get('error', 'Publish failed')}[/dim]")


def _registry_browse():
    """Browse top plugins from the registry."""
    console.print(f"  [dim]Fetching top plugins...[/dim]")
    data = _registry_api("list")
    if not data:
        return
    plugins = data.get("plugins", [])
    if not plugins:
        console.print(f"  [dim]No plugins in the registry yet.[/dim]")
        return
    shown = plugins[:20]
    console.print(f"\n[bold {VAAL_BLUE}]  Plugin Registry[/] [dim](top {len(shown)})[/dim]")
    console.print(f"[dim]  {'─' * 50}[/dim]")
    for i, p in enumerate(shown, 1):
        desc = p.get("description", "") or ""
        desc_short = (desc[:55] + "...") if len(desc) > 58 else desc
        console.print(f"  [{VAAL_CYAN}]{i:>2}.[/] [{VAAL_CYAN}]{p['name']}[/] [dim]v{p.get('version', '?')}[/dim]  [dim]{p.get('installs', 0)} installs[/dim]")
        if desc_short:
            console.print(f"      [dim]{desc_short}[/dim]")
    console.print(f"\n  [dim]Install with: /plugin install <name>[/dim]\n")


def _handle_effort_command(arg: str):
    """Handle /effort [level] — set or show inference effort level."""
    global _effort_level
    valid_levels = ("low", "medium", "high", "max")
    if not arg.strip():
        console.print(f"  [{VAAL_CYAN}]Effort level:[/] [bold]{_effort_level}[/bold]")
        console.print(f"  [dim]Options: {', '.join(valid_levels)}[/dim]")
        return
    level = arg.strip().lower()
    if level not in valid_levels:
        console.print(f"  [{VAAL_RED}]Invalid level: {level}[/]")
        console.print(f"  [dim]Options: {', '.join(valid_levels)}[/dim]")
        return
    _effort_level = level
    console.print(f"  [{VAAL_GREEN}]Effort level set to:[/] [bold]{_effort_level}[/bold]")


def _handle_add_dir_command(arg: str, session):
    """Handle /add-dir <path> — add a directory to context."""
    if not arg.strip():
        console.print(f"  [dim]Usage: /add-dir <path>[/dim]")
        return
    target = os.path.expanduser(arg.strip())
    target = os.path.abspath(target)
    if not os.path.isdir(target):
        console.print(f"  [{VAAL_RED}]Not a directory: {target}[/]")
        return
    console.print(f"  [dim]Scanning {target}...[/dim]")
    project_info = scan_project(target)
    if not project_info or not project_info.languages:
        console.print(f"  [{VAAL_YELLOW}]No project info detected in {target}[/]")
        return
    section = project_info.to_prompt_section()
    # Append to system prompt
    if session.messages and session.messages[0]["role"] == "system":
        session.messages[0]["content"] += f"\n\n## Added Directory: {target}\n{section}"
    console.print(f"  [{VAAL_GREEN}]Added to context:[/] {target}")
    if project_info.primary_language:
        console.print(f"    [dim]Primary language:[/dim] [{VAAL_CYAN}]{project_info.primary_language}[/]")
    if project_info.languages:
        console.print(f"    [dim]Languages:[/dim]        [{VAAL_CYAN}]{', '.join(project_info.languages)}[/]")
    if project_info.package_managers:
        console.print(f"    [dim]Package managers:[/dim] [{VAAL_CYAN}]{', '.join(project_info.package_managers)}[/]")
    if project_info.is_git_repo:
        console.print(f"    [dim]Git repo:[/dim]         [{VAAL_CYAN}]yes[/]")


def _handle_summary_command(session):
    """Handle /summary — generate a session summary."""
    now = time.time()
    elapsed = now - session.created_at
    hours, remainder = divmod(int(elapsed), 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        elapsed_str = f"{hours}h {minutes}m {secs}s"
    elif minutes > 0:
        elapsed_str = f"{minutes}m {secs}s"
    else:
        elapsed_str = f"{secs}s"

    msg_count = len(session.messages)
    tool_call_count = 0
    tool_counts: dict[str, int] = {}
    for msg in session.messages:
        if msg.get("role") == "tool":
            tool_call_count += 1
            # Extract tool name from the message
            name = msg.get("name", "unknown")
            tool_counts[name] = tool_counts.get(name, 0) + 1

    console.print()
    console.print(f"  [bold {VAAL_BLUE}]Session Summary[/]")
    console.print(f"  [dim]{'─' * 40}[/dim]")
    console.print(f"    [dim]Messages:[/dim]     [{VAAL_CYAN}]{msg_count}[/]")
    console.print(f"    [dim]Tool calls:[/dim]   [{VAAL_CYAN}]{tool_call_count}[/]")
    console.print(f"    [dim]Elapsed:[/dim]      [{VAAL_CYAN}]{elapsed_str}[/]")
    console.print()

    if tool_counts:
        console.print(f"  [bold {VAAL_BLUE}]Tools Used[/]")
        sorted_tools = sorted(tool_counts.items(), key=lambda x: x[1], reverse=True)
        for name, count in sorted_tools:
            console.print(f"    [{VAAL_CYAN}]{name:20s}[/] {count}")
    else:
        console.print(f"  [dim]No tool calls in this session.[/dim]")
    console.print()


def _handle_usage_stats_command(session, active_model: list, components: dict):
    """Handle /stats — detailed usage statistics."""
    now = time.time()
    duration = now - session.created_at
    hours, remainder = divmod(int(duration), 3600)
    minutes, secs = divmod(remainder, 60)
    if hours > 0:
        dur_str = f"{hours}h {minutes}m {secs}s"
    elif minutes > 0:
        dur_str = f"{minutes}m {secs}s"
    else:
        dur_str = f"{secs}s"

    console.print()
    console.print(f"  [bold {VAAL_BLUE}]Usage Statistics[/]")
    console.print(f"  [dim]{'─' * 40}[/dim]")

    # Session duration
    console.print(f"    [dim]Duration:[/dim]     [{VAAL_CYAN}]{dur_str}[/]")

    # Total tokens
    console.print(f"    [dim]Total tokens:[/dim] [{VAAL_CYAN}]{stats.total_tokens:,}[/]")

    # Cost estimate
    if components and "cost_tracker" in components:
        tracker = components["cost_tracker"]
        if tracker.events:
            summary = tracker.summary()
            console.print(f"    [dim]Cost summary:[/dim]")
            for line in summary.split("\n"):
                console.print(f"      [{VAAL_DIM}]{line}[/]")
        else:
            console.print(f"    [dim]Cost:[/dim]         [{VAAL_DIM}]no data yet[/]")
    else:
        console.print(f"    [dim]Cost:[/dim]         [{VAAL_DIM}]no tracker[/]")

    # Tool call count
    console.print(f"    [dim]Tool calls:[/dim]   [{VAAL_CYAN}]{stats.tool_calls}[/]")

    # Agent count
    pool = get_agent_pool()
    console.print(f"    [dim]Agents:[/dim]       [{VAAL_CYAN}]{pool.total_count}[/]")

    console.print()


def _handle_commit_command(arg: str, session):
    """Handle /commit [message] — auto-generate commit message and commit."""
    import subprocess

    # Check if we're in a git repo
    check = subprocess.run(["git", "rev-parse", "--is-inside-work-tree"], capture_output=True, text=True)
    if check.returncode != 0:
        console.print(f"[{VAAL_RED}]  Not inside a git repository.[/]")
        return

    if arg.strip():
        # User provided a message — commit directly
        message = arg.strip()
        full_msg = message + "\n\nCo-Authored-By: Vaal <vaal@e-e.tools>"
        result = subprocess.run(["git", "commit", "-m", full_msg], capture_output=True, text=True)
        if result.returncode == 0:
            console.print(f"[{VAAL_GREEN}]  Committed:[/] {message}")
        else:
            console.print(f"[{VAAL_RED}]  Commit failed:[/] {result.stderr.strip()}")
        return

    # Check staged changes
    stat_result = subprocess.run(["git", "diff", "--cached", "--stat"], capture_output=True, text=True)
    diff_result = subprocess.run(["git", "diff", "--cached"], capture_output=True, text=True)

    if not diff_result.stdout.strip():
        # Nothing staged — stage everything
        console.print(f"[{VAAL_YELLOW}]  Nothing staged. Running git add -A...[/]")
        subprocess.run(["git", "add", "-A"], capture_output=True, text=True)
        stat_result = subprocess.run(["git", "diff", "--cached", "--stat"], capture_output=True, text=True)
        diff_result = subprocess.run(["git", "diff", "--cached"], capture_output=True, text=True)
        if not diff_result.stdout.strip():
            console.print(f"[{VAAL_DIM}]  No changes to commit.[/]")
            return

    # Show staged summary
    console.print(f"\n[{VAAL_CYAN}]  Staged changes:[/]")
    for line in stat_result.stdout.strip().split("\n"):
        console.print(f"[{VAAL_DIM}]    {line}[/]")

    # Generate commit message via LLM
    console.print(f"\n[{VAAL_DIM}]  Generating commit message...[/]")
    diff_text = diff_result.stdout[:8000]  # Limit diff size for LLM
    from .llm import chat_with_tools_stream
    gen_messages = [
        {"role": "system", "content": (
            "You are a commit message generator. Given a git diff, output ONLY a concise "
            "commit message (1-2 lines). No markdown, no explanation, just the message."
        )},
        {"role": "user", "content": f"Generate a concise commit message for these changes:\n\n{diff_text}"},
    ]
    generated = ""
    model = session.model if hasattr(session, "model") else "qwen3:8b"
    for chunk in chat_with_tools_stream(gen_messages, [], model=model, think=False):
        if chunk.get("content"):
            generated += chunk["content"]
    generated = generated.strip().strip('"').strip("'")

    if not generated:
        console.print(f"[{VAAL_RED}]  Failed to generate commit message.[/]")
        return

    console.print(f"\n[{VAAL_GREEN}]  Message:[/] {generated}")
    try:
        confirm = input("  Commit? [Y/n]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        console.print(f"\n[{VAAL_DIM}]  Cancelled.[/]")
        return

    if confirm in ("", "y", "yes"):
        full_msg = generated + "\n\nCo-Authored-By: Vaal <vaal@e-e.tools>"
        result = subprocess.run(["git", "commit", "-m", full_msg], capture_output=True, text=True)
        if result.returncode == 0:
            console.print(f"[{VAAL_GREEN}]  Committed successfully.[/]")
        else:
            console.print(f"[{VAAL_RED}]  Commit failed:[/] {result.stderr.strip()}")
    else:
        console.print(f"[{VAAL_DIM}]  Cancelled.[/]")


def _handle_test_command(arg: str, session):
    """Handle /test [pattern] — detect and run tests."""
    import subprocess

    # Detect test framework
    framework = None
    cmd_parts = []

    if os.path.exists("pytest.ini") or os.path.exists("setup.cfg") or os.path.exists("pyproject.toml"):
        # Check pyproject.toml for pytest
        if os.path.exists("pyproject.toml"):
            try:
                with open("pyproject.toml", "r") as f:
                    content = f.read()
                if "pytest" in content or "tool.pytest" in content:
                    framework = "pytest"
            except Exception:
                pass
        if not framework and (os.path.exists("pytest.ini") or os.path.exists("setup.cfg")):
            framework = "pytest"
        if not framework and os.path.exists("pyproject.toml"):
            framework = "pytest"  # Default for Python projects
        if framework == "pytest":
            cmd_parts = ["pytest", "-v"]
            if arg.strip():
                cmd_parts.append(arg.strip())

    if not framework and os.path.exists("package.json"):
        framework = "npm"
        cmd_parts = ["npm", "test"]

    if not framework and os.path.exists("Cargo.toml"):
        framework = "cargo"
        cmd_parts = ["cargo", "test"]
        if arg.strip():
            cmd_parts.append(arg.strip())

    if not framework and os.path.exists("go.mod"):
        framework = "go"
        cmd_parts = ["go", "test", "./..."]

    if not framework:
        # Fallback: try pytest anyway
        framework = "pytest"
        cmd_parts = ["pytest", "-v"]
        if arg.strip():
            cmd_parts.append(arg.strip())

    console.print(f"[{VAAL_CYAN}]  Running: {' '.join(cmd_parts)}[/]")
    console.print()

    result = subprocess.run(cmd_parts, capture_output=True, text=True)
    output = result.stdout + result.stderr

    # Display output
    for line in output.split("\n"):
        if "PASSED" in line or "passed" in line or "ok" in line.lower():
            console.print(f"[{VAAL_GREEN}]  {line}[/]")
        elif "FAILED" in line or "failed" in line or "FAIL" in line or "error" in line.lower():
            console.print(f"[{VAAL_RED}]  {line}[/]")
        else:
            console.print(f"[{VAAL_DIM}]  {line}[/]")

    # Parse results
    passed = 0
    failed = 0
    if framework == "pytest":
        import re as _re
        m = _re.search(r"(\d+) passed", output)
        if m:
            passed = int(m.group(1))
        m = _re.search(r"(\d+) failed", output)
        if m:
            failed = int(m.group(1))
    elif framework == "cargo":
        import re as _re
        m = _re.search(r"test result: .* (\d+) passed.*(\d+) failed", output)
        if m:
            passed = int(m.group(1))
            failed = int(m.group(2))

    console.print()
    if passed or failed:
        console.print(f"  [{VAAL_GREEN}]{passed} passed[/]  [{VAAL_RED}]{failed} failed[/]")

    # Offer auto-fix on failures
    if failed > 0 and result.returncode != 0:
        try:
            fix_input = input("  Fix these failures? [Y/n]: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            return
        if fix_input in ("", "y", "yes"):
            failure_text = output[-4000:]  # Last 4000 chars of output
            return "paste:" + f"The test suite failed. Here is the output:\n\n```\n{failure_text}\n```\n\nPlease analyze the failures and fix them."


def _handle_pr_command(arg: str, session):
    """Handle /pr [title] — create a pull request."""
    import subprocess

    # Get current branch
    branch_result = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True)
    if branch_result.returncode != 0 or not branch_result.stdout.strip():
        console.print(f"[{VAAL_RED}]  Not on a git branch.[/]")
        return
    branch = branch_result.stdout.strip()

    if branch in ("main", "master"):
        console.print(f"[{VAAL_YELLOW}]  You're on {branch}. Create a feature branch first.[/]")
        return

    # Get commits not in main
    base_branch = "main"
    # Try main first, fall back to master
    check_main = subprocess.run(["git", "rev-parse", "--verify", "main"], capture_output=True, text=True)
    if check_main.returncode != 0:
        check_master = subprocess.run(["git", "rev-parse", "--verify", "master"], capture_output=True, text=True)
        if check_master.returncode == 0:
            base_branch = "master"
        else:
            console.print(f"[{VAAL_RED}]  Could not find main or master branch.[/]")
            return

    commits_result = subprocess.run(["git", "log", f"{base_branch}..HEAD", "--oneline"], capture_output=True, text=True)
    stat_result = subprocess.run(["git", "diff", f"{base_branch}..HEAD", "--stat"], capture_output=True, text=True)

    commits = commits_result.stdout.strip()
    diff_stat = stat_result.stdout.strip()

    if not commits:
        console.print(f"[{VAAL_YELLOW}]  No commits ahead of {base_branch}.[/]")
        return

    console.print(f"\n[{VAAL_CYAN}]  Branch:[/] {branch}")
    console.print(f"[{VAAL_CYAN}]  Commits:[/]")
    for line in commits.split("\n"):
        console.print(f"[{VAAL_DIM}]    {line}[/]")

    # Generate title if not provided
    title = arg.strip() if arg.strip() else None
    if not title:
        console.print(f"\n[{VAAL_DIM}]  Generating PR title...[/]")
        from .llm import chat_with_tools_stream
        gen_messages = [
            {"role": "system", "content": (
                "You are a PR title generator. Given git commits, output ONLY a concise PR title "
                "(under 70 chars). No markdown, no explanation, just the title."
            )},
            {"role": "user", "content": f"Generate a PR title from these commits:\n\n{commits}"},
        ]
        model = session.model if hasattr(session, "model") else "qwen3:8b"
        title = ""
        for chunk in chat_with_tools_stream(gen_messages, [], model=model, think=False):
            if chunk.get("content"):
                title += chunk["content"]
        title = title.strip().strip('"').strip("'")

    if not title:
        console.print(f"[{VAAL_RED}]  Failed to generate PR title.[/]")
        return

    body = f"## Changes\n\n{commits}\n\n## Stats\n\n```\n{diff_stat}\n```"

    console.print(f"\n[{VAAL_GREEN}]  Title:[/] {title}")

    # Push branch
    console.print(f"[{VAAL_DIM}]  Pushing to origin...[/]")
    push_result = subprocess.run(["git", "push", "-u", "origin", branch], capture_output=True, text=True)
    if push_result.returncode != 0:
        console.print(f"[{VAAL_RED}]  Push failed:[/] {push_result.stderr.strip()}")
        return

    # Create PR
    console.print(f"[{VAAL_DIM}]  Creating pull request...[/]")
    pr_result = subprocess.run(
        ["gh", "pr", "create", "--title", title, "--body", body],
        capture_output=True, text=True,
    )
    if pr_result.returncode == 0:
        pr_url = pr_result.stdout.strip()
        console.print(f"\n[{VAAL_GREEN}]  PR created:[/] {pr_url}")
    else:
        console.print(f"[{VAAL_RED}]  PR creation failed:[/] {pr_result.stderr.strip()}")


def _handle_diff_command(arg: str, session):
    """Handle /diff — show uncommitted changes with Rich formatting."""
    import subprocess

    # Check if we're in a git repo
    check = subprocess.run(["git", "rev-parse", "--is-inside-work-tree"], capture_output=True, text=True)
    if check.returncode != 0:
        console.print(f"[{VAAL_RED}]  Not inside a git repository.[/]")
        return

    file_arg = arg.strip() if arg.strip() else None
    diff_args_unstaged = ["git", "diff"]
    diff_args_staged = ["git", "diff", "--cached"]
    if file_arg:
        diff_args_unstaged.append(file_arg)
        diff_args_staged.append(file_arg)

    unstaged = subprocess.run(diff_args_unstaged, capture_output=True, text=True)
    staged = subprocess.run(diff_args_staged, capture_output=True, text=True)

    unstaged_text = unstaged.stdout.strip()
    staged_text = staged.stdout.strip()

    if not unstaged_text and not staged_text:
        console.print(f"[{VAAL_DIM}]  No uncommitted changes{' for ' + file_arg if file_arg else ''}.[/]")
        return

    def _render_diff(diff_text: str, label: str):
        """Render a diff with Rich colors."""
        console.print(f"\n[bold {VAAL_CYAN}]  {label}[/]")
        console.print(f"[{VAAL_DIM}]  {'─' * 50}[/]")
        current_file = ""
        for line in diff_text.split("\n"):
            if line.startswith("diff --git"):
                # Extract file name
                parts = line.split(" b/")
                current_file = parts[-1] if len(parts) > 1 else line
                console.print(f"\n  [bold {VAAL_CYAN}]{current_file}[/]")
            elif line.startswith("@@"):
                console.print(f"  [{VAAL_YELLOW}]{line}[/]")
            elif line.startswith("+") and not line.startswith("+++"):
                console.print(f"  [{VAAL_GREEN}]{line}[/]")
            elif line.startswith("-") and not line.startswith("---"):
                console.print(f"  [{VAAL_RED}]{line}[/]")
            elif line.startswith("---") or line.startswith("+++"):
                continue  # Skip file headers (already shown)
            else:
                console.print(f"  [{VAAL_DIM}]{line}[/]")

    # Show stat summary
    stat_result = subprocess.run(
        ["git", "diff", "--stat"] + ([file_arg] if file_arg else []),
        capture_output=True, text=True,
    )
    stat_cached = subprocess.run(
        ["git", "diff", "--cached", "--stat"] + ([file_arg] if file_arg else []),
        capture_output=True, text=True,
    )
    if stat_cached.stdout.strip():
        console.print(f"\n[bold {VAAL_GREEN}]  Staged files:[/]")
        for line in stat_cached.stdout.strip().split("\n"):
            console.print(f"  [{VAAL_DIM}]  {line}[/]")
    if stat_result.stdout.strip():
        console.print(f"\n[bold {VAAL_YELLOW}]  Unstaged files:[/]")
        for line in stat_result.stdout.strip().split("\n"):
            console.print(f"  [{VAAL_DIM}]  {line}[/]")

    if staged_text:
        _render_diff(staged_text, "Staged Changes")
    if unstaged_text:
        _render_diff(unstaged_text, "Unstaged Changes")
    console.print()


def _handle_task_agent_command(command, arg, session, active_model, permissions, components):
    """Handle /tasks, /task, and /agents commands."""
    if command == "/tasks":
        tm = get_task_manager()
        console.print()
        console.print(f"[bold {VAAL_BLUE}]  Tasks[/]")
        console.print(f"[dim]  {'─' * 40}[/dim]")
        tasks = tm.list_all()
        if not tasks:
            console.print(f"  [dim]No tasks. Use /task create <title> to add one.[/dim]")
        else:
            for t in tasks:
                icon = STATUS_ICONS[t.status]
                style = STATUS_STYLES[t.status]
                agent_tag = f" [{VAAL_DIM}](agent:{t.agent_id})[/]" if t.agent_id else ""
                console.print(f"  [{style}]{icon}[/] [{VAAL_CYAN}]{t.id}[/] {t.title}{agent_tag}")
                if t.description:
                    console.print(f"  [dim]    {t.description}[/dim]")
            console.print()
            console.print(f"  [dim]{tm.summary}[/dim]")
        console.print()

    elif command == "/task":
        tm = get_task_manager()
        sub_parts = arg.split(maxsplit=1) if arg else []
        action = sub_parts[0].lower() if sub_parts else ""
        task_arg = sub_parts[1] if len(sub_parts) > 1 else ""

        if action == "create" and task_arg:
            t = tm.create(title=task_arg)
            console.print(f"  [{VAAL_GREEN}]Created task {t.id}: {t.title}[/]")
        elif action == "complete" and task_arg:
            t = tm.complete(task_arg.strip())
            if t:
                console.print(f"  [{VAAL_GREEN}]Completed: {t.title}[/]")
            else:
                console.print(f"  [dim]Task not found: {task_arg}[/dim]")
        elif action == "update" and task_arg:
            update_parts = task_arg.split(maxsplit=1)
            if len(update_parts) == 2:
                tid, new_status = update_parts
                try:
                    status_val = TaskStatus(new_status)
                    t = tm.update(tid.strip(), status=status_val)
                    if t:
                        console.print(f"  [{VAAL_GREEN}]Updated {t.id} -> {status_val.value}[/]")
                    else:
                        console.print(f"  [dim]Task not found: {tid}[/dim]")
                except ValueError:
                    console.print(f"  [dim]Invalid status: {new_status}. Use: pending, in_progress, completed, blocked[/dim]")
            else:
                console.print(f"  [dim]Usage: /task update <id> <status>[/dim]")
        elif action == "list":
            _handle_task_agent_command("/tasks", "", session, active_model, permissions, components)
        else:
            console.print(f"  [dim]Usage: /task create <title> | /task complete <id> | /task update <id> <status> | /task list[/dim]")

    elif command == "/agents":
        pool = get_agent_pool()
        console.print()
        console.print(f"[bold {VAAL_BLUE}]  Agents[/]")
        console.print(f"[dim]  {'─' * 40}[/dim]")
        agents = pool.list_agents()
        if not agents:
            console.print(f"  [dim]No agents spawned.[/dim]")
        else:
            for a in agents:
                status_style = VAAL_GREEN if a["status"] == "complete" else (VAAL_YELLOW if a["is_running"] else "dim red")
                console.print(f"  [{VAAL_CYAN}]{a['id']}[/] [{status_style}]{a['status']}[/] {a['label']}")
                if a.get("elapsed"):
                    console.print(f"  [dim]    {a.get('rounds', 0)} rounds, {a.get('tool_calls', 0)} tools, {a['elapsed']}[/dim]")
                if a.get("error"):
                    console.print(f"  [dim red]    Error: {a['error']}[/dim red]")
        console.print()
        console.print(f"  [dim]{pool.status_summary() or 'No active agents'}[/dim]")
        console.print()


# ── Memory, plan, resume command handlers ─────────────────────────────

def _handle_memory_command(arg: str):
    from .memory import MemoryStore
    store = MemoryStore()
    if arg:
        results = store.search_memory(arg)
        if not results:
            console.print(f"[dim]  No memories matching '{arg}'.[/dim]")
        else:
            console.print()
            for entry in results[:15]:
                desc = f" - {entry.description}" if entry.description else ""
                console.print(f"  [{VAAL_BLUE}]{entry.name}[/] [dim][{entry.type}]{desc}[/dim]")
                preview = entry.content[:120].replace("\n", " ")
                if len(entry.content) > 120:
                    preview += "..."
                console.print(f"    [dim]{preview}[/dim]")
            console.print()
    else:
        entries = store.list_memories()
        if not entries:
            console.print(f"[dim]  No memories saved. The model can save memories using the save_memory tool,[/dim]")
            console.print(f"[dim]  or you can ask it to remember something.[/dim]")
        else:
            console.print()
            console.print(f"[bold {VAAL_BLUE}]  Memories ({len(entries)})[/]")
            console.print(f"[dim]  {'─' * 40}[/dim]")
            for entry in entries:
                desc = f" - {entry.description}" if entry.description else ""
                console.print(f"  [{VAAL_BLUE}]{entry.name}[/] [dim][{entry.type}]{desc}[/dim]")
            console.print()


def _handle_plan_command(arg: str, active_model: list):
    from .plans import create_plan
    if not arg:
        console.print(f"[dim]  Usage: /plan <description of what you want to do>[/dim]")
        console.print(f"[dim]  Example: /plan refactor the auth system to use middleware[/dim]")
        return
    console.print(f"[dim]  Creating plan from description...[/dim]")
    from .llm import chat_with_tools_stream
    plan_prompt = [
        {"role": "system", "content": (
            "You are a planning assistant. Given a task description, output ONLY a JSON object "
            "with two keys: \"title\" (short title, under 60 chars) and \"steps\" (array of step "
            "description strings). Output raw JSON only, no markdown fences, no explanation."
        )},
        {"role": "user", "content": f"Create an implementation plan for: {arg}"},
    ]
    plan_text = ""
    for chunk in chat_with_tools_stream(plan_prompt, [], model=active_model[0], think=False):
        if chunk.get("content"):
            plan_text += chunk["content"]
    try:
        import json as _json
        cleaned = plan_text.strip()
        if cleaned.startswith("```"):
            cleaned = "\n".join(cleaned.split("\n")[1:])
        if cleaned.endswith("```"):
            cleaned = "\n".join(cleaned.split("\n")[:-1])
        plan_data = _json.loads(cleaned.strip())
        title = plan_data.get("title", arg[:60])
        steps = plan_data.get("steps", [])
        if not steps:
            console.print(f"[dim]  Model returned no steps. Try a more specific description.[/dim]")
        else:
            plan = create_plan(title, steps)
            console.print()
            console.print(f"[bold {VAAL_BLUE}]  Plan created: {plan.title}[/]")
            console.print(f"[dim]  ID: {plan.plan_id} | Steps: {len(plan.steps)}[/dim]")
            console.print()
            for i, step in enumerate(plan.steps):
                icon = f"[{VAAL_GREEN}]->[/]" if i == 0 else f"[dim]  [/dim]"
                console.print(f"  {icon} {i+1}. {step.description}")
            console.print()
    except Exception as e:
        console.print(f"[vaal.error]  Failed to parse plan: {e}[/]")
        console.print(f"[dim]  Raw output: {plan_text[:300]}[/dim]")


def _handle_plans_command():
    from .plans import list_plans as _list_plans
    plans = _list_plans()
    if not plans:
        console.print(f"[dim]  No plans saved. Use /plan <description> to create one.[/dim]")
    else:
        console.print()
        console.print(f"[bold {VAAL_BLUE}]  Plans ({len(plans)})[/]")
        console.print(f"[dim]  {'─' * 50}[/dim]")
        for p in plans[:20]:
            status_color = VAAL_GREEN if p.status == "completed" else (VAAL_YELLOW if p.status == "active" else VAAL_DIM)
            console.print(f"  [{VAAL_BLUE}]{p.plan_id}[/]  [{status_color}]{p.status:10s}[/]  {p.progress:5s}  {p.title}")
        console.print()
        console.print(f"[dim]  Tip: The model can reference and update plans during execution.[/dim]")
        console.print()


def _handle_resume_command(session, active_model: list):
    from .interactive import _read_key, _write as _iwrite
    from .interactive import ALT_SCREEN_ON, ALT_SCREEN_OFF, HIDE_CURSOR, SHOW_CURSOR, CLEAR_SCREEN, RESET, BOLD
    from .interactive import C_BLUE, C_CYAN, C_DIM, C_BG_SELECT, C_BOLD_WHITE

    sessions_list = Session.list_sessions()
    if not sessions_list:
        console.print(f"[dim]  No saved sessions to resume.[/dim]")
        return

    previews = []
    for s in sessions_list[:30]:
        try:
            full = Session.load(s["id"])
            first_user_msg = ""
            for m in full.messages:
                if m.get("role") == "user":
                    content = m.get("content", "")
                    if content.startswith("[CWD:"):
                        content = content.split("\n", 1)[-1] if "\n" in content else content
                    first_user_msg = content[:80]
                    break
            age_secs = time.time() - s.get("created", 0)
            if age_secs < 3600:
                age_str = f"{int(age_secs/60)}m ago"
            elif age_secs < 86400:
                age_str = f"{int(age_secs/3600)}h ago"
            else:
                age_str = f"{int(age_secs/86400)}d ago"
            previews.append({
                "id": s["id"],
                "model": s.get("model", "?"),
                "messages": s.get("messages", 0),
                "age": age_str,
                "preview": first_user_msg or "(empty session)",
            })
        except Exception:
            continue

    if not previews:
        console.print(f"[dim]  No valid sessions to resume.[/dim]")
        return

    selected = 0
    _iwrite(ALT_SCREEN_ON + HIDE_CURSOR)
    try:
        while True:
            _iwrite(CLEAR_SCREEN)
            _iwrite(f"\n  {C_BLUE}{BOLD}Resume Session{RESET}\n")
            _iwrite(f"  {C_DIM}{'─' * 50}{RESET}\n")
            _iwrite(f"  {C_DIM}Up/Down to select, Enter to resume, Escape to cancel{RESET}\n\n")

            for i, p in enumerate(previews):
                bg = C_BG_SELECT if i == selected else ""
                end = RESET if i == selected else ""
                arrow = f"{C_BLUE}{BOLD}->{RESET}" if i == selected else "  "
                _iwrite(f"  {bg}{arrow} {C_CYAN}{p['id']}{RESET}{bg}  {p['model']:20s}  {p['messages']:3d} msgs  {p['age']:>8s}{end}\n")
                preview_text = p['preview'][:60]
                if len(p['preview']) > 60:
                    preview_text += "..."
                _iwrite(f"  {bg}     {C_DIM}{preview_text}{RESET}{end}\n")

            key = _read_key()
            if key == "up" and selected > 0:
                selected -= 1
            elif key == "down" and selected < len(previews) - 1:
                selected += 1
            elif key == "enter":
                chosen_id = previews[selected]["id"]
                _iwrite(ALT_SCREEN_OFF + SHOW_CURSOR)
                try:
                    resumed = Session.load(chosen_id)
                    session.session_id = resumed.session_id
                    session.messages = resumed.messages
                    session.created_at = resumed.created_at
                    session.model = resumed.model
                    session.cwd = resumed.cwd
                    session.total_tokens = resumed.total_tokens
                    session.tool_calls = resumed.tool_calls
                    active_model[0] = resumed.model or active_model[0]
                    stats.model = active_model[0]
                    console.print(f"[dim]  Resumed session {chosen_id} ({previews[selected]['messages']} messages)[/dim]")
                except Exception as e:
                    console.print(f"[vaal.error]  Failed to load session: {e}[/]")
                break
            elif key in ("escape", "quit"):
                _iwrite(ALT_SCREEN_OFF + SHOW_CURSOR)
                break
    except Exception:
        _iwrite(ALT_SCREEN_OFF + SHOW_CURSOR)


# ── Model management display helpers ────────────────────────────────

def _show_models_display(current_model: str):
    """Display the smart model list with hardware info and compatibility."""
    mgr = get_manager()
    if not mgr.hardware:
        mgr.detect()
    mgr.refresh_installed()

    console.print()
    console.print(f"  [bold {VAAL_BLUE}]GPU:[/] {mgr.hardware.summary()}")
    console.print()

    visible = mgr.get_visible_models()
    if not visible:
        console.print(f"  [dim]No compatible models found for your hardware.[/dim]")
        console.print()
        return

    # Get the single best recommended model
    best_rec = mgr.get_recommended()

    # Also show any installed models NOT in catalog
    installed_from_ollama = list_models()
    catalog_names = {e.name for e in mgr.catalog}

    for entry, compat in visible:
        installed = mgr.is_installed(entry.name)
        is_active = _model_matches(entry.name, current_model)

        # Icon: → active, ✓ installed, ✗ not installed
        if is_active:
            icon = f"[bold {VAAL_BLUE}]→[/]"
        elif installed:
            icon = f"[{VAAL_GREEN}]✓[/]"
        else:
            icon = f"[dim]✗[/dim]"

        # Name styling
        if is_active:
            name_style = f"bold {VAAL_BLUE}"
        elif installed:
            name_style = f"{VAAL_GREEN}"
        else:
            name_style = "dim"

        # Size
        size_str = f"{entry.size_gb:5.1f} GB"

        # Category
        cat_str = entry.category

        # Compatibility tag
        if compat == "optimal":
            compat_str = f"[{VAAL_GREEN}]optimal[/]"
        else:
            compat_str = f"[{VAAL_YELLOW}]slower[/]"

        # Only show (recommended) on the single best model
        rec_str = f" [{VAAL_CYAN}](recommended)[/]" if (best_rec and entry.name == best_rec.name) else ""

        # Active tag
        active_str = f"  [bold {VAAL_BLUE}][active][/]" if is_active else ""

        console.print(
            f"  {icon}  [{name_style}]{entry.name:28s}[/]  "
            f"[dim]{size_str}[/dim]  [dim]{cat_str:12s}[/dim]  "
            f"{compat_str}{rec_str}{active_str}"
        )

    # Show installed models not in catalog
    extra = []
    for m in installed_from_ollama:
        # Normalize: strip :latest
        base = m.replace(":latest", "") if m.endswith(":latest") else m
        if base not in catalog_names and m not in catalog_names:
            extra.append(m)

    if extra:
        console.print()
        console.print(f"  [dim]Other installed models (not in catalog):[/dim]")
        for m in extra:
            is_active = _model_matches(m, current_model)
            if is_active:
                console.print(f"  [bold {VAAL_BLUE}]->  {m}[/]  [bold {VAAL_BLUE}][active][/]")
            else:
                console.print(f"  [dim]    {m}[/dim]")

    console.print()


def _model_matches(catalog_name: str, active_name: str) -> bool:
    """Check if a catalog model name matches the active model (handling :latest etc)."""
    a = catalog_name.lower().replace(":latest", "")
    b = active_name.lower().replace(":latest", "")
    return a == b or a.startswith(b) or b.startswith(a)


def _handle_pull(model_name: str):
    """Pull a model — routes to HuggingFace for airllm: prefix, Ollama otherwise."""
    console.print(f"  [{VAAL_BLUE}]Pulling {model_name}...[/]")
    console.print()

    if model_name.startswith("airllm:"):
        hf_model_id = model_name[len("airllm:"):]
        from .airllm_provider import parse_airllm_model_string, pull_airllm_model
        hf_model_id, _ = parse_airllm_model_string(hf_model_id)
        try:
            for line in pull_airllm_model(hf_model_id):
                if line.startswith("[error"):
                    console.print(f"  [{VAAL_RED}]{line}[/]")
                else:
                    _write(f"\r  \033[K\033[2m{line[:100]}\033[0m\n")
            console.print(f"  [{VAAL_GREEN}]Done: {hf_model_id}[/]")
        except Exception as e:
            console.print(f"  [{VAAL_RED}]Error: {e}[/]")
        console.print()
        return

    try:
        proc = pull_model(model_name)
        last_line = ""
        for line in iter(proc.stdout.readline, ""):
            line = line.rstrip()
            if line:
                if "%" in line or "pulling" in line.lower() or "verifying" in line.lower():
                    _write(f"\r  \033[K\033[2m{line[:80]}\033[0m")
                else:
                    _write(f"\r  \033[K\033[2m{line[:80]}\033[0m\n")
                last_line = line

        proc.wait()
        _write("\r\033[K")

        if proc.returncode == 0:
            console.print(f"  [{VAAL_GREEN}]Successfully pulled {model_name}[/]")
            mgr = get_manager()
            mgr.refresh_installed()
        else:
            console.print(f"  [{VAAL_RED}]Failed to pull {model_name}[/]")
            if last_line:
                console.print(f"  [dim]{last_line}[/dim]")
    except FileNotFoundError:
        console.print(f"  [{VAAL_RED}]Ollama not found. Is it installed?[/]")
    except Exception as e:
        console.print(f"  [{VAAL_RED}]Error: {e}[/]")

    console.print()


def _handle_remove(model_name: str):
    """Remove a model."""
    success, message = remove_model(model_name)
    if success:
        console.print(f"  [{VAAL_GREEN}]{message}[/]")
        mgr = get_manager()
        mgr.refresh_installed()
    else:
        console.print(f"  [{VAAL_RED}]{message}[/]")
    console.print()


def _show_first_run(mgr):
    """Display first-run hardware info and model recommendations."""
    console.print()
    console.print(f"  [bold {VAAL_BLUE}]First run detected — scanning hardware...[/]")
    console.print()
    console.print(f"  [bold {VAAL_BLUE}]GPU:[/] {mgr.hardware.summary()}")
    console.print()

    visible = mgr.get_visible_models()
    recommended = mgr.get_recommended()

    if visible:
        console.print(f"  [bold {VAAL_BLUE}]Compatible models for your hardware:[/]")
        console.print()
        for entry, compat in visible[:8]:  # show top 8
            rec = f" [{VAAL_CYAN}]<-- recommended[/]" if entry == recommended else ""
            compat_tag = f"[{VAAL_GREEN}]optimal[/]" if compat == "optimal" else f"[{VAAL_YELLOW}]slower[/]"
            console.print(
                f"    [dim]{entry.name:28s}  {entry.size_gb:5.1f} GB  {entry.category:12s}[/dim]  {compat_tag}{rec}"
            )
        console.print()

    if recommended:
        console.print(f"  Run [bold {VAAL_CYAN}]/pull {recommended.name}[/] to download the recommended model")
    else:
        console.print(f"  Run [bold {VAAL_CYAN}]/pull <model>[/] to download a model")

    console.print(f"  Run [bold {VAAL_CYAN}]/models[/] to see all compatible models")
    console.print()


# ── /rewind and /debug-tool command handlers ───────────────────────────

def _handle_rewind_command(arg: str, session):
    """Handle /rewind — interactive message picker to branch from."""
    msgs = session.messages
    if not msgs:
        console.print(f"[dim]  No messages to rewind to.[/dim]")
        return

    # Show last 20 messages
    start = max(0, len(msgs) - 20)
    console.print()
    console.print(f"[bold {VAAL_BLUE}]  Message history[/]")
    console.print(f"[dim]  {'─' * 40}[/dim]")
    for i in range(start, len(msgs)):
        m = msgs[i]
        role = m.get("role", "?")
        content = m.get("content", "")
        if role == "tool":
            preview = "(tool result)"
        elif isinstance(content, list):
            preview = "(tool calls)"
        elif isinstance(content, str):
            preview = content.replace("\n", " ")[:60]
        else:
            preview = str(content)[:60]
        console.print(f"  [{i}] {role}: {preview}")
    console.print()

    # Get index
    if arg.strip():
        try:
            idx = int(arg.strip())
        except ValueError:
            console.print(f"[dim]  Invalid index: {arg}[/dim]")
            return
    else:
        try:
            raw = input("  Rewind to message #: ")
            idx = int(raw.strip())
        except (ValueError, EOFError, KeyboardInterrupt):
            console.print(f"[dim]  Cancelled.[/dim]")
            return

    if idx < 0 or idx >= len(msgs):
        console.print(f"[dim]  Index out of range (0-{len(msgs) - 1}).[/dim]")
        return

    old_count = len(msgs)
    session.messages = msgs[:idx + 1]
    console.print(f"[dim]  Rewound to message {idx}. Dropped {old_count - idx - 1} messages.[/dim]")


def _handle_debug_tool_command(arg: str):
    """Handle /debug-tool — toggle verbose tool output."""
    global _debug_tools
    _debug_tools = not _debug_tools
    state = "ON" if _debug_tools else "OFF"
    console.print(f"[dim]  Debug tool output: {state}[/dim]")


def _handle_pin_command(arg: str, session):
    """Handle /pin <file> — pin a file to always include in context."""
    global _pinned_files
    if not arg.strip():
        if not _pinned_files:
            console.print(f"[dim]  No pinned files. Usage: /pin <file_path>[/dim]")
        else:
            console.print(f"  [{VAAL_CYAN}]Pinned files:[/]")
            for pf in _pinned_files:
                exists = os.path.isfile(pf)
                status = f"[{VAAL_GREEN}]ok[/]" if exists else "[red]missing[/]"
                console.print(f"    {status} {pf}")
        return

    file_path = os.path.abspath(arg.strip())
    if not os.path.isfile(file_path):
        console.print(f"  [red]File not found: {file_path}[/]")
        return

    if file_path in _pinned_files:
        console.print(f"  [dim]Already pinned: {file_path}[/dim]")
        return

    _pinned_files.append(file_path)
    try:
        content = open(file_path, encoding="utf-8", errors="replace").read()
        size = len(content)
        lines = content.count("\n") + 1
        console.print(f"  [{VAAL_GREEN}]Pinned:[/] {file_path} ({lines} lines, {size} chars)")
        if size > 5000:
            console.print(f"  [dim]Note: content will be truncated to 5000 chars in context[/dim]")
    except Exception as e:
        console.print(f"  [{VAAL_GREEN}]Pinned:[/] {file_path} [dim](could not preview: {e})[/dim]")


def _handle_unpin_command(arg: str):
    """Handle /unpin <file> — remove a pinned file."""
    global _pinned_files
    if not arg.strip():
        if not _pinned_files:
            console.print(f"[dim]  No pinned files.[/dim]")
        else:
            console.print(f"[dim]  Usage: /unpin <file_path>[/dim]")
            console.print(f"[dim]  Pinned files:[/dim]")
            for pf in _pinned_files:
                console.print(f"    [dim]{pf}[/dim]")
        return

    file_path = os.path.abspath(arg.strip())
    if file_path in _pinned_files:
        _pinned_files.remove(file_path)
        console.print(f"  [{VAAL_GREEN}]Unpinned:[/] {file_path}")
    else:
        # Try matching by basename
        matches = [pf for pf in _pinned_files if os.path.basename(pf) == arg.strip()]
        if matches:
            _pinned_files.remove(matches[0])
            console.print(f"  [{VAAL_GREEN}]Unpinned:[/] {matches[0]}")
        else:
            console.print(f"  [dim]Not pinned: {file_path}[/dim]")


def _handle_cost_command(arg: str, components: dict):
    """Handle /cost — show running cost estimate."""
    tracker = components.get("cost_tracker") if components else None
    if not tracker:
        console.print(f"[dim]  Cost tracking not available.[/dim]")
        return

    if not tracker.events:
        console.print(f"[dim]  No LLM calls recorded yet.[/dim]")
        return

    verbose = arg.strip().lower() in ("verbose", "v", "-v")

    console.print()
    console.print(f"  [{VAAL_CYAN}]Token Usage & Cost Estimate[/]")
    console.print(f"  [dim]{'=' * 50}[/dim]")
    console.print(f"  Input tokens:  [{VAAL_GREEN}]{tracker.total_input:>10,}[/]")
    console.print(f"  Output tokens: [{VAAL_GREEN}]{tracker.total_output:>10,}[/]")
    console.print(f"  Total tokens:  [{VAAL_GREEN}]{tracker.total_tokens:>10,}[/]")

    # Calculate cost estimate using Opus pricing as default
    input_cost = tracker.total_input * 0.015 / 1000
    output_cost = tracker.total_output * 0.075 / 1000
    total_cost = input_cost + output_cost

    console.print(f"  [dim]{'─' * 50}[/dim]")
    console.print(f"  Input cost:    [dim]${input_cost:>9.4f}[/dim]  [dim]($0.015/1K tokens)[/dim]")
    console.print(f"  Output cost:   [dim]${output_cost:>9.4f}[/dim]  [dim]($0.075/1K tokens)[/dim]")
    console.print(f"  [{VAAL_CYAN}]Estimated total: ${total_cost:.4f}[/]")

    # Also show from stats if available
    if stats.est_cost > 0:
        console.print(f"  [dim]Model-adjusted:  ${stats.est_cost:.4f}[/dim]")

    if verbose:
        console.print()
        summary = tracker.summary()
        for line in summary.splitlines():
            console.print(f"  [{VAAL_CYAN}]{line}[/]")

    console.print()
