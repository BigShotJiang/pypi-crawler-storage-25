"""Conversation branching — fork, switch, merge conversation branches."""

import copy
import time


class Branch:
    """A named conversation branch with its own message list and model."""

    def __init__(self, name: str, messages: list[dict], model: str = ""):
        self.name = name
        self.messages: list[dict] = messages
        self.model: str = model
        self.created_at: float = time.time()

    def message_count(self) -> int:
        return len(self.messages)


class BranchManager:
    """Manages conversation branches within a session."""

    def __init__(self):
        self._branches: dict[str, Branch] = {}
        self._current: str = "main"
        self._counter: int = 0

    @property
    def current_branch(self) -> str:
        return self._current

    def create_branch(
        self,
        name: str | None,
        messages: list[dict],
        model: str = "",
    ) -> Branch:
        """Fork the current conversation into a new branch.

        Args:
            name: Branch name (auto-generated if None).
            messages: Current message list to snapshot.
            model: Model to use for this branch (empty = inherit current).

        Returns:
            The new Branch.
        """
        if name is None:
            self._counter += 1
            name = f"branch-{self._counter}"

        if name in self._branches:
            raise ValueError(f"Branch '{name}' already exists")

        # Deep copy messages so branches are independent
        branch = Branch(
            name=name,
            messages=copy.deepcopy(messages),
            model=model,
        )
        self._branches[name] = branch
        return branch

    def list_branches(self) -> list[dict]:
        """List all branches with metadata."""
        result = []
        for name, branch in self._branches.items():
            result.append({
                "name": name,
                "messages": branch.message_count(),
                "model": branch.model or "(inherited)",
                "active": name == self._current,
                "created_at": branch.created_at,
            })
        return result

    def switch_to(self, name: str, current_messages: list[dict], current_model: str) -> tuple[list[dict], str]:
        """Switch to a different branch.

        Saves the current conversation state into the current branch (or 'main')
        before switching.

        Args:
            name: Branch name to switch to.
            current_messages: Current message list to save.
            current_model: Current model to save.

        Returns:
            (messages, model) from the target branch.
        """
        if name not in self._branches:
            raise ValueError(f"Branch '{name}' not found")

        # Save current state
        if self._current not in self._branches:
            # First switch away from main — auto-save main
            self._branches[self._current] = Branch(
                name=self._current,
                messages=copy.deepcopy(current_messages),
                model=current_model,
            )
        else:
            self._branches[self._current].messages = copy.deepcopy(current_messages)
            self._branches[self._current].model = current_model

        # Switch
        target = self._branches[name]
        self._current = name
        return copy.deepcopy(target.messages), target.model

    def merge_from(self, name: str, current_messages: list[dict]) -> list[dict]:
        """Merge content from a branch into the current conversation.

        Appends all non-system messages from the source branch that aren't
        already in the current conversation (by comparing timestamps).

        Args:
            name: Branch to merge from.
            current_messages: Current message list.

        Returns:
            Updated message list with merged content.
        """
        if name not in self._branches:
            raise ValueError(f"Branch '{name}' not found")

        source = self._branches[name]
        # Collect timestamps of current messages for dedup
        current_timestamps = {
            m.get("timestamp", 0) for m in current_messages
        }

        merged = list(current_messages)
        added = 0
        for msg in source.messages:
            # Skip system messages and duplicates
            if msg["role"] == "system":
                continue
            ts = msg.get("timestamp", 0)
            if ts and ts in current_timestamps:
                continue
            merged.append(copy.deepcopy(msg))
            added += 1

        return merged, added

    def has_branch(self, name: str) -> bool:
        return name in self._branches

    def delete_branch(self, name: str) -> bool:
        """Delete a branch. Cannot delete current branch."""
        if name == self._current:
            return False
        if name in self._branches:
            del self._branches[name]
            return True
        return False
