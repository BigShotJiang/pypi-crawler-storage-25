"""Code review -- analyze uncommitted changes or specific files via the model."""

import subprocess
import os
import re
from dataclasses import dataclass
from enum import Enum


class Severity(Enum):
    CRITICAL = "critical"
    WARNING = "warning"
    SUGGESTION = "suggestion"
    NITPICK = "nitpick"


SEVERITY_STYLES = {
    Severity.CRITICAL: ("bold red", "!!"),
    Severity.WARNING: ("#d7875f", "!"),
    Severity.SUGGESTION: ("#5f87ff", "~"),
    Severity.NITPICK: ("dim", "."),
}


@dataclass
class ReviewComment:
    file: str
    line: int | None
    severity: Severity
    message: str
    suggestion: str = ""

    def format_plain(self) -> str:
        style_char = SEVERITY_STYLES[self.severity][1]
        loc = f"{self.file}"
        if self.line:
            loc += f":{self.line}"
        out = f"  [{style_char}] {self.severity.value.upper():12s} {loc}\n      {self.message}"
        if self.suggestion:
            out += f"\n      -> {self.suggestion}"
        return out


def _run_git(args: list[str], cwd: str | None = None) -> tuple[str, int]:
    """Run a git command and return (output, returncode)."""
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=cwd or os.getcwd(),
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
        output = result.stdout or ""
        if result.stderr:
            output += "\n" + result.stderr
        return output.strip(), result.returncode
    except FileNotFoundError:
        return "[error: git not found on PATH]", 1
    except subprocess.TimeoutExpired:
        return "[error: git command timed out]", 1
    except Exception as e:
        return f"[error: {e}]", 1


def _run_gh(args: list[str], cwd: str | None = None) -> tuple[str, int]:
    """Run a gh CLI command and return (output, returncode)."""
    try:
        result = subprocess.run(
            ["gh"] + args,
            capture_output=True,
            text=True,
            timeout=60,
            cwd=cwd or os.getcwd(),
        )
        output = result.stdout or ""
        if result.stderr:
            output += "\n" + result.stderr
        return output.strip(), result.returncode
    except FileNotFoundError:
        return "[error: gh CLI not found. Install from https://cli.github.com]", 1
    except subprocess.TimeoutExpired:
        return "[error: gh command timed out]", 1
    except Exception as e:
        return f"[error: {e}]", 1


def get_diff(staged: bool = False, file_path: str = "") -> tuple[str, str]:
    """Get git diff content. Returns (diff_text, error)."""
    args = ["diff"]
    if staged:
        args.append("--cached")
    if file_path:
        args.extend(["--", file_path])
    output, code = _run_git(args)
    if code != 0:
        return "", output
    if not output.strip():
        # Try staged if unstaged was empty
        if not staged and not file_path:
            output, code = _run_git(["diff", "--cached"])
            if code == 0 and output.strip():
                return output, ""
        return "", "No changes found."
    return output, ""


def get_file_content(file_path: str) -> tuple[str, str]:
    """Read a file for review. Returns (content, error)."""
    try:
        abs_path = os.path.abspath(file_path)
        with open(abs_path, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        return content, ""
    except FileNotFoundError:
        return "", f"File not found: {file_path}"
    except Exception as e:
        return "", f"Error reading file: {e}"


def get_pr_diff(pr_number: int | str) -> tuple[str, str]:
    """Get the diff for a GitHub PR. Returns (diff_text, error)."""
    output, code = _run_gh(["pr", "diff", str(pr_number)])
    if code != 0:
        return "", output
    return output, ""


def get_pr_info(pr_number: int | str) -> tuple[dict, str]:
    """Get PR metadata. Returns (info_dict, error)."""
    output, code = _run_gh([
        "pr", "view", str(pr_number),
        "--json", "title,body,author,state,additions,deletions,files"
    ])
    if code != 0:
        return {}, output
    try:
        import json
        return json.loads(output), ""
    except Exception:
        return {}, "Failed to parse PR info"


def build_review_prompt(diff: str, context: str = "", review_type: str = "diff") -> str:
    """Build the prompt to send to the model for code review."""
    if review_type == "file":
        return f"""You are a senior code reviewer. Review the following file and provide feedback.

For each issue found, output it in EXACTLY this format (one per issue):

[SEVERITY] file:line_number
message
-> suggestion (optional)

Where SEVERITY is one of: CRITICAL, WARNING, SUGGESTION, NITPICK

Focus on:
- Security vulnerabilities (CRITICAL)
- Bugs and logic errors (CRITICAL/WARNING)
- Performance issues (WARNING)
- Code style and maintainability (SUGGESTION)
- Minor improvements (NITPICK)

Be specific with line numbers. Be concise. Do NOT add commentary outside the review format.

{context}

```
{diff}
```"""

    if review_type == "pr":
        return f"""You are a senior code reviewer. Review this pull request diff and provide feedback.

For each issue found, output it in EXACTLY this format (one per issue):

[SEVERITY] file:line_number
message
-> suggestion (optional)

Where SEVERITY is one of: CRITICAL, WARNING, SUGGESTION, NITPICK

Focus on:
- Security vulnerabilities (CRITICAL)
- Bugs and logic errors (CRITICAL/WARNING)
- Performance issues (WARNING)
- Code style and maintainability (SUGGESTION)
- Minor improvements (NITPICK)

Be specific with file paths and line numbers from the diff. Be concise.

{context}

```diff
{diff}
```"""

    return f"""You are a senior code reviewer. Review the following git diff and provide feedback.

For each issue found, output it in EXACTLY this format (one per issue):

[SEVERITY] file:line_number
message
-> suggestion (optional)

Where SEVERITY is one of: CRITICAL, WARNING, SUGGESTION, NITPICK

Focus on:
- Security vulnerabilities (CRITICAL)
- Bugs and logic errors (CRITICAL/WARNING)
- Performance issues (WARNING)
- Code style and maintainability (SUGGESTION)
- Minor improvements (NITPICK)

Be specific with line numbers from the diff. Be concise. Do NOT add commentary outside the review format.

```diff
{diff}
```"""


def parse_review_response(response: str) -> list[ReviewComment]:
    """Parse the model's review response into structured comments."""
    comments = []
    lines = response.strip().splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        # Match: [SEVERITY] file:line or [SEVERITY] file
        m = re.match(r"\[(\w+)\]\s+(.+?)(?::(\d+))?\s*$", line)
        if m:
            severity_str = m.group(1).upper()
            file_path = m.group(2).strip()
            line_num = int(m.group(3)) if m.group(3) else None

            try:
                severity = Severity(severity_str.lower())
            except ValueError:
                severity = Severity.SUGGESTION

            # Next line is the message
            message = ""
            suggestion = ""
            i += 1
            while i < len(lines):
                next_line = lines[i].strip()
                if next_line.startswith("->"):
                    suggestion = next_line[2:].strip()
                    i += 1
                elif next_line and not re.match(r"\[(\w+)\]", next_line):
                    if message:
                        message += " " + next_line
                    else:
                        message = next_line
                    i += 1
                else:
                    break

            if message:
                comments.append(ReviewComment(
                    file=file_path,
                    line=line_num,
                    severity=severity,
                    message=message,
                    suggestion=suggestion,
                ))
        else:
            i += 1

    return comments
