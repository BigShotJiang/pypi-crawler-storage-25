"""Interactive logout screen — select an authorized provider to disconnect."""

import sys
import json
from pathlib import Path

ESC = "\033"
HIDE_CURSOR = f"{ESC}[?25l"
SHOW_CURSOR = f"{ESC}[?25h"
CLEAR_SCREEN = f"{ESC}[2J{ESC}[H"
ALT_SCREEN_ON = f"{ESC}[?1049h"
ALT_SCREEN_OFF = f"{ESC}[?1049l"
RESET = f"{ESC}[0m"
BOLD = f"{ESC}[1m"
C_BLUE = f"{ESC}[38;5;63m"
C_CYAN = f"{ESC}[38;5;80m"
C_GREEN = f"{ESC}[38;5;34m"
C_RED = f"{ESC}[38;5;167m"
C_DIM = f"{ESC}[38;5;242m"
C_WHITE = f"{ESC}[37m"
C_BOLD_WHITE = f"{ESC}[1;37m"
C_BG_SELECT = f"{ESC}[48;5;236m"


def _write(s):
    sys.stdout.write(s)
    sys.stdout.flush()


def _read_key():
    if sys.platform == "win32":
        import msvcrt
        key = msvcrt.getwch()
        if key in ("\x00", "\xe0"):
            key2 = msvcrt.getwch()
            if key2 == "H": return "up"
            elif key2 == "P": return "down"
            return "special"
        elif key == "\r": return "enter"
        elif key == "\x1b": return "escape"
        elif key == "\x03": return "escape"
        return key
    else:
        import tty, termios
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = sys.stdin.read(1)
            if ch == "\x1b":
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "A": return "up"
                    elif ch3 == "B": return "down"
                return "escape"
            elif ch == "\r": return "enter"
            elif ch == "\x03": return "escape"
            return ch
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)


def _get_authorized_providers() -> list[dict]:
    """Get list of providers that are currently authenticated."""
    from .providers import BUILTIN_PROVIDERS, get_api_key, get_active_oauth
    from .login_screen import get_auth_type

    authorized = []

    for name, info in BUILTIN_PROVIDERS.items():
        if not info["requires_key"]:
            continue
        key = get_api_key(name)
        if not key:
            continue

        auth = get_auth_type(name)
        if name == "anthropic":
            oauth = get_active_oauth()
            if oauth:
                sub = oauth.get("subscriptionType", "")
                display = f"Anthropic (Claude {sub.title()})" if sub else "Anthropic (OAuth)"
            else:
                display = "Anthropic (API key)"
        else:
            display = info.get("name", name).title()
            if name == "openai":
                display = "OpenAI"
            elif name == "groq":
                display = "Groq"
            elif name == "openrouter":
                display = "OpenRouter"
            elif name == "deepseek":
                display = "DeepSeek"
            elif name == "together":
                display = "Together AI"

        authorized.append({
            "name": name,
            "display": display,
            "auth_type": auth,
        })

    return authorized


def _do_logout(provider_name: str) -> bool:
    """Perform the actual logout. Only clears Vaal's own credentials — never touches Claude Code."""
    from .config import VAAL_DIR

    if provider_name == "anthropic":
        # Clear Vaal's OAuth only (not Claude Code's)
        from .providers import _clear_vaal_oauth
        _clear_vaal_oauth()

    # Clear from vaal keys
    keys_file = VAAL_DIR / "keys.json"
    if keys_file.exists():
        try:
            keys = json.loads(keys_file.read_text(encoding="utf-8"))
            keys.pop(provider_name, None)
            keys_file.write_text(json.dumps(keys, indent=2), encoding="utf-8")
        except Exception:
            pass

    return True


def logout_screen() -> str | None:
    """Interactive logout screen. Returns provider name that was logged out, or None."""
    providers = _get_authorized_providers()

    if not providers:
        _write(ALT_SCREEN_ON)
        _write(CLEAR_SCREEN)
        _write(f"\n  {C_DIM}No providers are currently authenticated.{RESET}\n")
        _write(f"\n  {C_DIM}Press any key...{RESET}")
        _read_key()
        _write(ALT_SCREEN_OFF)
        return None

    selected = 0

    _write(ALT_SCREEN_ON)
    _write(HIDE_CURSOR)

    try:
        while True:
            _write(CLEAR_SCREEN)

            _write(f"\n  {C_RED}{BOLD}Logout{RESET}\n")
            _write(f"  {C_DIM}Select a provider to disconnect{RESET}\n\n")

            for i, prov in enumerate(providers):
                is_sel = i == selected
                auth_tag = f"{C_CYAN}{prov['auth_type']}{RESET}" if prov["auth_type"] else ""

                if is_sel:
                    _write(f"  {C_BG_SELECT}{C_RED}❯{RESET} {C_BG_SELECT}{C_BOLD_WHITE}{prov['display']:35s}{RESET} {C_BG_SELECT}{auth_tag}{C_BG_SELECT}{RESET}\n")
                else:
                    _write(f"    {C_GREEN}{prov['display']:35s}{RESET} {auth_tag}\n")

            _write(f"\n  {C_DIM}↑↓ navigate  {RESET}{C_RED}enter{RESET} {C_DIM}logout  {RESET}{C_CYAN}esc{RESET} {C_DIM}cancel{RESET}")

            key = _read_key()

            if key == "up":
                selected = max(0, selected - 1)
            elif key == "down":
                selected = min(len(providers) - 1, selected + 1)
            elif key == "enter":
                prov = providers[selected]
                _write(CLEAR_SCREEN)
                _write(f"\n  {C_DIM}Logging out of {prov['display']}...{RESET}\n")

                success = _do_logout(prov["name"])

                if success:
                    _write(f"\n  {C_GREEN}✓ Logged out of {prov['display']}{RESET}\n")
                else:
                    _write(f"\n  {C_RED}Failed to logout{RESET}\n")

                import time
                time.sleep(1.5)
                _write(ALT_SCREEN_OFF)
                _write(SHOW_CURSOR)
                return prov["name"]

            elif key in ("escape",):
                _write(ALT_SCREEN_OFF)
                _write(SHOW_CURSOR)
                return None

    except Exception:
        _write(ALT_SCREEN_OFF)
        _write(SHOW_CURSOR)
        return None
    finally:
        _write(ALT_SCREEN_OFF)
        _write(SHOW_CURSOR)
