"""Undo/redo system — tracks file changes made by the model."""

import os
import json
import shutil
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path


UNDO_DIR = Path.home() / ".vaal" / "undo_stack"
MAX_STACK_DEPTH = 50
STATE_FILE = UNDO_DIR / "state.json"


@dataclass
class FileOperation:
    """A single file change operation."""
    op_id: int
    timestamp: float
    file_path: str
    operation: str  # "write", "edit", "create", "delete"
    description: str  # Human-readable description
    before_path: str  # Path to the saved before-state (or empty for create)
    after_path: str   # Path to the saved after-state (or empty for delete)

    def summary(self) -> str:
        """One-line summary for display."""
        short = os.path.basename(self.file_path)
        age = time.time() - self.timestamp
        if age < 60:
            age_str = f"{int(age)}s ago"
        elif age < 3600:
            age_str = f"{int(age/60)}m ago"
        else:
            age_str = f"{int(age/3600)}h ago"
        return f"[{self.op_id}] {self.operation} {short} ({age_str}) - {self.description}"


class UndoSystem:
    """Tracks file operations and allows undo/redo.

    Before-state files are stored in ~/.vaal/undo_stack/
    Stack depth capped at MAX_STACK_DEPTH operations.
    """

    def __init__(self):
        self._undo_stack: list[FileOperation] = []
        self._redo_stack: list[FileOperation] = []
        self._next_id: int = 1
        UNDO_DIR.mkdir(parents=True, exist_ok=True)
        self._load_state()

    # ── Recording operations ──────────────────────────────────────────

    def record_write(self, file_path: str, description: str = ""):
        """Record a file write. Call BEFORE the write with the current content."""
        abs_path = os.path.abspath(file_path)
        before_path = ""
        after_path = ""

        # Save before-state if file exists
        if os.path.isfile(abs_path):
            before_path = str(UNDO_DIR / f"op_{self._next_id}_before")
            shutil.copy2(abs_path, before_path)
            op_type = "edit"
        else:
            op_type = "create"

        op = FileOperation(
            op_id=self._next_id,
            timestamp=time.time(),
            file_path=abs_path,
            operation=op_type,
            description=description or f"{op_type} {os.path.basename(abs_path)}",
            before_path=before_path,
            after_path="",  # Will be filled after write completes
        )
        self._next_id += 1
        self._undo_stack.append(op)
        self._redo_stack.clear()  # New operation invalidates redo stack
        self._trim_stack()
        self._save_state()
        return op

    def record_write_complete(self, file_path: str):
        """Call AFTER a write completes to snapshot the after-state."""
        abs_path = os.path.abspath(file_path)
        # Find the most recent operation for this file
        for op in reversed(self._undo_stack):
            if op.file_path == abs_path and not op.after_path:
                if os.path.isfile(abs_path):
                    after_path = str(UNDO_DIR / f"op_{op.op_id}_after")
                    shutil.copy2(abs_path, after_path)
                    op.after_path = after_path
                self._save_state()
                return

    def record_delete(self, file_path: str, description: str = ""):
        """Record a file deletion. Call BEFORE the delete."""
        abs_path = os.path.abspath(file_path)
        before_path = ""
        if os.path.isfile(abs_path):
            before_path = str(UNDO_DIR / f"op_{self._next_id}_before")
            shutil.copy2(abs_path, before_path)

        op = FileOperation(
            op_id=self._next_id,
            timestamp=time.time(),
            file_path=abs_path,
            operation="delete",
            description=description or f"delete {os.path.basename(abs_path)}",
            before_path=before_path,
            after_path="",
        )
        self._next_id += 1
        self._undo_stack.append(op)
        self._redo_stack.clear()
        self._trim_stack()
        self._save_state()
        return op

    # ── Undo / Redo ───────────────────────────────────────────────────

    def peek_undo(self) -> FileOperation | None:
        """Show what will be undone without applying."""
        return self._undo_stack[-1] if self._undo_stack else None

    def peek_redo(self) -> FileOperation | None:
        """Show what will be redone without applying."""
        return self._redo_stack[-1] if self._redo_stack else None

    def undo(self) -> tuple[bool, str]:
        """Undo the last file operation. Returns (success, message)."""
        if not self._undo_stack:
            return False, "Nothing to undo."

        op = self._undo_stack.pop()

        try:
            if op.operation in ("write", "edit"):
                # Restore before-state
                if op.before_path and os.path.isfile(op.before_path):
                    # Save current state as after (for redo)
                    if os.path.isfile(op.file_path):
                        after_path = str(UNDO_DIR / f"op_{op.op_id}_after")
                        shutil.copy2(op.file_path, after_path)
                        op.after_path = after_path
                    shutil.copy2(op.before_path, op.file_path)
                    self._redo_stack.append(op)
                    self._save_state()
                    return True, f"Undone: {op.description} ({os.path.basename(op.file_path)})"
                else:
                    return False, f"Before-state not found for {os.path.basename(op.file_path)}."

            elif op.operation == "create":
                # Remove created file
                if os.path.isfile(op.file_path):
                    # Save for redo
                    after_path = str(UNDO_DIR / f"op_{op.op_id}_after")
                    shutil.copy2(op.file_path, after_path)
                    op.after_path = after_path
                    os.remove(op.file_path)
                    self._redo_stack.append(op)
                    self._save_state()
                    return True, f"Undone: created {os.path.basename(op.file_path)} (file removed)"
                return False, f"File already gone: {os.path.basename(op.file_path)}"

            elif op.operation == "delete":
                # Restore deleted file
                if op.before_path and os.path.isfile(op.before_path):
                    os.makedirs(os.path.dirname(op.file_path), exist_ok=True)
                    shutil.copy2(op.before_path, op.file_path)
                    self._redo_stack.append(op)
                    self._save_state()
                    return True, f"Undone: delete {os.path.basename(op.file_path)} (file restored)"
                return False, f"Before-state not found for deleted file."

        except Exception as e:
            return False, f"Undo failed: {e}"

        return False, "Unknown operation type."

    def redo(self) -> tuple[bool, str]:
        """Redo the last undone operation. Returns (success, message)."""
        if not self._redo_stack:
            return False, "Nothing to redo."

        op = self._redo_stack.pop()

        try:
            if op.operation in ("write", "edit"):
                # Apply after-state
                if op.after_path and os.path.isfile(op.after_path):
                    shutil.copy2(op.after_path, op.file_path)
                    self._undo_stack.append(op)
                    self._save_state()
                    return True, f"Redone: {op.description} ({os.path.basename(op.file_path)})"
                return False, f"After-state not found for {os.path.basename(op.file_path)}."

            elif op.operation == "create":
                # Re-create file
                if op.after_path and os.path.isfile(op.after_path):
                    os.makedirs(os.path.dirname(op.file_path), exist_ok=True)
                    shutil.copy2(op.after_path, op.file_path)
                    self._undo_stack.append(op)
                    self._save_state()
                    return True, f"Redone: create {os.path.basename(op.file_path)}"
                return False, f"After-state not found."

            elif op.operation == "delete":
                # Re-delete
                if os.path.isfile(op.file_path):
                    os.remove(op.file_path)
                    self._undo_stack.append(op)
                    self._save_state()
                    return True, f"Redone: delete {os.path.basename(op.file_path)}"
                return False, f"File not found to delete: {os.path.basename(op.file_path)}"

        except Exception as e:
            return False, f"Redo failed: {e}"

        return False, "Unknown operation type."

    # ── Query ─────────────────────────────────────────────────────────

    def undo_stack_info(self) -> list[str]:
        """Return summaries of all operations in the undo stack."""
        return [op.summary() for op in reversed(self._undo_stack)]

    def redo_stack_info(self) -> list[str]:
        """Return summaries of all operations in the redo stack."""
        return [op.summary() for op in reversed(self._redo_stack)]

    @property
    def undo_count(self) -> int:
        return len(self._undo_stack)

    @property
    def redo_count(self) -> int:
        return len(self._redo_stack)

    # ── Persistence ───────────────────────────────────────────────────

    def _save_state(self):
        """Persist stack state to disk."""
        try:
            data = {
                "next_id": self._next_id,
                "undo": [asdict(op) for op in self._undo_stack],
                "redo": [asdict(op) for op in self._redo_stack],
            }
            STATE_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _load_state(self):
        """Load stack state from disk."""
        if not STATE_FILE.is_file():
            return
        try:
            data = json.loads(STATE_FILE.read_text(encoding="utf-8"))
            self._next_id = data.get("next_id", 1)
            self._undo_stack = [
                FileOperation(**op) for op in data.get("undo", [])
            ]
            self._redo_stack = [
                FileOperation(**op) for op in data.get("redo", [])
            ]
            # Clean out entries whose backup files no longer exist
            self._undo_stack = [
                op for op in self._undo_stack
                if not op.before_path or os.path.isfile(op.before_path)
            ]
        except Exception:
            self._undo_stack = []
            self._redo_stack = []

    def _trim_stack(self):
        """Trim undo stack to MAX_STACK_DEPTH, cleaning up old backup files."""
        while len(self._undo_stack) > MAX_STACK_DEPTH:
            old = self._undo_stack.pop(0)
            self._cleanup_op_files(old)

    def _cleanup_op_files(self, op: FileOperation):
        """Remove backup files for an operation."""
        for path in (op.before_path, op.after_path):
            if path and os.path.isfile(path):
                try:
                    os.remove(path)
                except Exception:
                    pass

    def clear(self):
        """Clear all undo/redo history."""
        for op in self._undo_stack + self._redo_stack:
            self._cleanup_op_files(op)
        self._undo_stack.clear()
        self._redo_stack.clear()
        self._save_state()


# ── Module-level singleton ────────────────────────────────────────────

_system: UndoSystem | None = None


def get_undo_system() -> UndoSystem:
    """Get the global undo system singleton."""
    global _system
    if _system is None:
        _system = UndoSystem()
    return _system
