"""Generate the Vaal Orb icon for Windows Terminal."""

import math
from pathlib import Path


def generate_vaal_icon():
    """Generate a Vaal Orb .ico file at ~/.vaal/icon.ico"""
    from PIL import Image

    size = 256
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))

    cx, cy = size // 2, size // 2
    r = size // 2 - 10

    for y in range(size):
        for x in range(size):
            dx = x - cx
            dy = y - cy
            dist = math.sqrt(dx * dx + dy * dy)
            if dist <= r:
                nd = dist / r
                # Core: deep purple, edge: crimson
                t = nd ** 0.8
                pr = int(30 * (1 - t) + 191 * t)
                pg = int(10 * (1 - t) + 31 * t)
                pb = int(60 * (1 - t) + 62 * t)

                # Blue corruption streaks
                angle = math.atan2(dy, dx)
                streak = math.sin(angle * 5 + nd * 8) * 0.3
                if streak > 0 and nd > 0.3:
                    pb = min(255, int(pb + streak * 150))
                    pr = max(0, int(pr - streak * 30))

                alpha = 255 if nd < 0.85 else int(255 * (1 - (nd - 0.85) / 0.15))
                img.putpixel((x, y), (pr, pg, pb, alpha))

    # Highlight spot
    hx, hy = cx - int(r * 0.3), cy - int(r * 0.3)
    hr = r * 0.25
    for y in range(size):
        for x in range(size):
            dx = x - hx
            dy = y - hy
            dist = math.sqrt(dx * dx + dy * dy)
            if dist < hr:
                nd = dist / hr
                alpha = int(120 * (1 - nd))
                px = img.getpixel((x, y))
                if px[3] > 0:
                    nr = min(255, px[0] + alpha)
                    ng = min(255, px[1] + alpha // 3)
                    nb = min(255, px[2] + alpha // 2)
                    img.putpixel((x, y), (nr, ng, nb, px[3]))

    icon_path = Path.home() / ".vaal" / "icon.ico"
    icon_path.parent.mkdir(exist_ok=True)
    img.save(str(icon_path), format="ICO", sizes=[(256, 256), (64, 64), (48, 48), (32, 32), (16, 16)])
    return str(icon_path)
