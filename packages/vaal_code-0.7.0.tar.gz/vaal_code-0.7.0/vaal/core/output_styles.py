"""Output styles -- control assistant response verbosity and format."""

from pathlib import Path
from .config import VAAL_DIR


STYLES_DIR = VAAL_DIR / "output-styles"

# Built-in styles (name -> system prompt injection)
BUILTIN_STYLES = {
    "default": (
        "Respond naturally. Use markdown formatting where appropriate. "
        "Show your reasoning when it adds clarity."
    ),
    "minimal": (
        "Be extremely concise. Give the shortest correct answer. "
        "No preamble, no filler. Skip explanations unless asked. "
        "Use code blocks for code, bullet points for lists, nothing else."
    ),
    "detailed": (
        "Be thorough and detailed. Explain your reasoning step by step. "
        "Show your thinking process. Include context, alternatives considered, "
        "and potential caveats. Use headers and structured formatting."
    ),
}


class OutputStyleManager:
    """Manages output styles from built-ins and user-defined markdown files."""

    def __init__(self):
        self._current: str = "default"
        self._custom_styles: dict[str, str] = {}
        self._load_custom_styles()

    def _load_custom_styles(self):
        """Load custom styles from ~/.vaal/output-styles/*.md files."""
        self._custom_styles.clear()
        if not STYLES_DIR.exists():
            return
        for md_file in STYLES_DIR.glob("*.md"):
            name = md_file.stem
            try:
                content = md_file.read_text(encoding="utf-8", errors="replace").strip()
                if content:
                    self._custom_styles[name] = content
            except OSError:
                pass

    @property
    def current(self) -> str:
        return self._current

    def set_style(self, name: str) -> bool:
        """Switch to a style by name. Returns True if found."""
        if name in BUILTIN_STYLES or name in self._custom_styles:
            self._current = name
            return True
        return False

    def get_prompt_injection(self) -> str:
        """Return the system prompt text for the current style."""
        if self._current in self._custom_styles:
            return self._custom_styles[self._current]
        return BUILTIN_STYLES.get(self._current, BUILTIN_STYLES["default"])

    def available_styles(self) -> list[str]:
        """List all available style names (builtin + custom)."""
        names = list(BUILTIN_STYLES.keys())
        for name in sorted(self._custom_styles.keys()):
            if name not in names:
                names.append(name)
        return names

    def is_builtin(self, name: str) -> bool:
        return name in BUILTIN_STYLES

    def reload(self):
        """Reload custom styles from disk."""
        self._load_custom_styles()
