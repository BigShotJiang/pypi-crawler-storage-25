"""Vaal Preview Overlay — injected JS/CSS for interactive element inspection.

When Vaal serves a preview on localhost, this overlay is injected into the page.
Users can hover/click elements (like inspect element), then type a prompt to
tell Vaal what to fix. The feedback is sent back to Vaal which edits the source
and hot-reloads the page.
"""

# ── Overlay CSS ──────────────────────────────────────────────────────────────

OVERLAY_CSS = r"""
/* ── Vaal Inspector Overlay ─────────────────────────────────────────── */

#vaal-overlay-highlight {
    position: fixed;
    pointer-events: none;
    border: 2px solid #e63946;
    background: rgba(230, 57, 70, 0.08);
    z-index: 2147483646;
    transition: all 0.08s ease-out;
    display: none;
    border-radius: 3px;
    box-shadow: 0 0 12px rgba(230, 57, 70, 0.25);
}

#vaal-overlay-selected {
    position: fixed;
    pointer-events: none;
    border: 2px solid #8338ec;
    background: rgba(131, 56, 236, 0.10);
    z-index: 2147483645;
    display: none;
    border-radius: 3px;
    box-shadow: 0 0 16px rgba(131, 56, 236, 0.3);
}

#vaal-overlay-tag {
    position: fixed;
    pointer-events: none;
    z-index: 2147483647;
    font-family: 'JetBrains Mono', 'Cascadia Code', 'Fira Code', monospace;
    font-size: 11px;
    color: #fff;
    background: #e63946;
    padding: 2px 8px;
    border-radius: 3px;
    display: none;
    white-space: nowrap;
    box-shadow: 0 2px 8px rgba(0,0,0,0.3);
}

#vaal-prompt-panel {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 2147483647;
    background: #1a1a2e;
    border-top: 2px solid #8338ec;
    padding: 0;
    font-family: 'JetBrains Mono', 'Cascadia Code', 'Fira Code', monospace;
    display: none;
    box-shadow: 0 -4px 24px rgba(0,0,0,0.5);
}

#vaal-prompt-panel .vaal-panel-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8px 16px;
    background: #16162a;
    border-bottom: 1px solid #2a2a4a;
}

#vaal-prompt-panel .vaal-panel-header .vaal-title {
    color: #8338ec;
    font-weight: bold;
    font-size: 12px;
    letter-spacing: 0.5px;
}

#vaal-prompt-panel .vaal-panel-header .vaal-selector {
    color: #e63946;
    font-size: 11px;
    max-width: 50%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

#vaal-prompt-panel .vaal-panel-header .vaal-close {
    color: #666;
    cursor: pointer;
    font-size: 14px;
    padding: 2px 6px;
    border-radius: 3px;
}
#vaal-prompt-panel .vaal-panel-header .vaal-close:hover {
    color: #e63946;
    background: rgba(230, 57, 70, 0.15);
}

#vaal-prompt-panel .vaal-panel-body {
    display: flex;
    padding: 10px 16px 12px;
    gap: 10px;
    align-items: flex-end;
}

#vaal-prompt-input {
    flex: 1;
    background: #0d0d1a;
    border: 1px solid #2a2a4a;
    border-radius: 6px;
    color: #e0e0e0;
    font-family: inherit;
    font-size: 13px;
    padding: 10px 14px;
    outline: none;
    resize: none;
    min-height: 20px;
    max-height: 120px;
}
#vaal-prompt-input:focus {
    border-color: #8338ec;
    box-shadow: 0 0 0 2px rgba(131, 56, 236, 0.2);
}
#vaal-prompt-input::placeholder {
    color: #555;
}

#vaal-prompt-send {
    background: #8338ec;
    color: #fff;
    border: none;
    border-radius: 6px;
    padding: 10px 20px;
    font-family: inherit;
    font-size: 13px;
    font-weight: bold;
    cursor: pointer;
    white-space: nowrap;
    letter-spacing: 0.5px;
}
#vaal-prompt-send:hover {
    background: #9b59b6;
}
#vaal-prompt-send:disabled {
    background: #444;
    cursor: not-allowed;
}

#vaal-status-toast {
    position: fixed;
    top: 16px;
    right: 16px;
    z-index: 2147483647;
    font-family: 'JetBrains Mono', 'Cascadia Code', monospace;
    font-size: 12px;
    padding: 8px 16px;
    border-radius: 6px;
    display: none;
    box-shadow: 0 4px 16px rgba(0,0,0,0.4);
    transition: opacity 0.3s;
}
#vaal-status-toast.success {
    background: #1a3a2a;
    color: #4ade80;
    border: 1px solid #22c55e;
}
#vaal-status-toast.error {
    background: #3a1a1a;
    color: #f87171;
    border: 1px solid #ef4444;
}
#vaal-status-toast.working {
    background: #1a1a3a;
    color: #a78bfa;
    border: 1px solid #8338ec;
}

/* Toggle button */
#vaal-toggle-btn {
    position: fixed;
    bottom: 16px;
    right: 16px;
    z-index: 2147483647;
    width: 44px;
    height: 44px;
    border-radius: 50%;
    background: #8338ec;
    color: #fff;
    border: 2px solid #6b21a8;
    cursor: pointer;
    font-size: 20px;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 4px 16px rgba(131, 56, 236, 0.4);
    transition: all 0.2s;
}
#vaal-toggle-btn:hover {
    transform: scale(1.1);
    box-shadow: 0 4px 24px rgba(131, 56, 236, 0.6);
}
#vaal-toggle-btn.active {
    background: #e63946;
    border-color: #c1121f;
    box-shadow: 0 4px 16px rgba(230, 57, 70, 0.4);
}

/* Breadcrumb path display */
#vaal-element-path {
    position: fixed;
    bottom: 60px;
    left: 16px;
    z-index: 2147483647;
    font-family: 'JetBrains Mono', 'Cascadia Code', monospace;
    font-size: 11px;
    color: #888;
    background: rgba(26, 26, 46, 0.95);
    padding: 4px 10px;
    border-radius: 4px;
    border: 1px solid #2a2a4a;
    display: none;
    max-width: 80%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}
"""

# ── Overlay JavaScript ───────────────────────────────────────────────────────

OVERLAY_JS = r"""
(function() {
    'use strict';

    // ── State ───────────────────────────────────────────────────────
    let inspecting = false;
    let selectedElement = null;
    let hoveredElement = null;

    // ── Create DOM elements ─────────────────────────────────────────
    function createOverlayElements() {
        // Highlight box (hover)
        const highlight = document.createElement('div');
        highlight.id = 'vaal-overlay-highlight';
        document.body.appendChild(highlight);

        // Selected box
        const selected = document.createElement('div');
        selected.id = 'vaal-overlay-selected';
        document.body.appendChild(selected);

        // Tag label
        const tag = document.createElement('div');
        tag.id = 'vaal-overlay-tag';
        document.body.appendChild(tag);

        // Element path breadcrumb
        const path = document.createElement('div');
        path.id = 'vaal-element-path';
        document.body.appendChild(path);

        // Status toast
        const toast = document.createElement('div');
        toast.id = 'vaal-status-toast';
        document.body.appendChild(toast);

        // Toggle button
        const toggle = document.createElement('button');
        toggle.id = 'vaal-toggle-btn';
        toggle.innerHTML = '⊙';
        toggle.title = 'Toggle Vaal Inspector (Ctrl+Shift+I)';
        document.body.appendChild(toggle);

        // Prompt panel
        const panel = document.createElement('div');
        panel.id = 'vaal-prompt-panel';
        panel.innerHTML = `
            <div class="vaal-panel-header">
                <span class="vaal-title">⊙ VAAL INSPECTOR</span>
                <span class="vaal-selector" id="vaal-selected-selector"></span>
                <span class="vaal-close" id="vaal-panel-close">✕</span>
            </div>
            <div class="vaal-panel-body">
                <textarea id="vaal-prompt-input" rows="1"
                    placeholder="Describe what to change... (Enter to send, Shift+Enter for newline)"></textarea>
                <button id="vaal-prompt-send">Fix it ⚡</button>
            </div>
        `;
        document.body.appendChild(panel);

        return { highlight, selected, tag, path, toast, toggle, panel };
    }

    const els = createOverlayElements();

    // ── Utility: get CSS selector for element ───────────────────────
    function getSelector(el) {
        if (!el || el === document.body || el === document.documentElement) return 'body';

        // Try ID first
        if (el.id && !el.id.startsWith('vaal-')) {
            return '#' + CSS.escape(el.id);
        }

        // Build path
        const parts = [];
        let current = el;
        while (current && current !== document.body && current !== document.documentElement) {
            let selector = current.tagName.toLowerCase();

            if (current.id && !current.id.startsWith('vaal-')) {
                selector = '#' + CSS.escape(current.id);
                parts.unshift(selector);
                break;
            }

            // Add classes (skip vaal- classes)
            const classes = Array.from(current.classList || [])
                .filter(c => !c.startsWith('vaal-'))
                .slice(0, 2);
            if (classes.length) {
                selector += '.' + classes.map(c => CSS.escape(c)).join('.');
            }

            // Add nth-child if needed for uniqueness
            const parent = current.parentElement;
            if (parent) {
                const siblings = Array.from(parent.children).filter(
                    s => s.tagName === current.tagName
                );
                if (siblings.length > 1) {
                    const idx = siblings.indexOf(current) + 1;
                    selector += ':nth-child(' + idx + ')';
                }
            }

            parts.unshift(selector);
            current = current.parentElement;
        }

        return parts.join(' > ');
    }

    // ── Utility: get element description ────────────────────────────
    function describeElement(el) {
        let desc = el.tagName.toLowerCase();
        if (el.id) desc += '#' + el.id;
        if (el.className && typeof el.className === 'string') {
            const cls = el.className.split(/\s+/).filter(c => c && !c.startsWith('vaal-')).slice(0, 3);
            if (cls.length) desc += '.' + cls.join('.');
        }
        // Add text preview
        const text = (el.textContent || '').trim().slice(0, 40);
        if (text) desc += ' "' + text + (el.textContent.trim().length > 40 ? '…' : '') + '"';
        return desc;
    }

    // ── Utility: get element context for AI ─────────────────────────
    function getElementContext(el) {
        const rect = el.getBoundingClientRect();
        const styles = window.getComputedStyle(el);

        return {
            selector: getSelector(el),
            tag: el.tagName.toLowerCase(),
            id: el.id || null,
            classes: Array.from(el.classList || []).filter(c => !c.startsWith('vaal-')),
            text: (el.textContent || '').trim().slice(0, 200),
            outerHTML: el.outerHTML.slice(0, 2000),
            innerHTML: el.innerHTML.slice(0, 1000),
            attributes: Array.from(el.attributes || []).reduce((acc, a) => {
                if (!a.name.startsWith('vaal-')) acc[a.name] = a.value;
                return acc;
            }, {}),
            rect: {
                x: Math.round(rect.x),
                y: Math.round(rect.y),
                width: Math.round(rect.width),
                height: Math.round(rect.height),
            },
            computedStyle: {
                display: styles.display,
                position: styles.position,
                color: styles.color,
                backgroundColor: styles.backgroundColor,
                fontSize: styles.fontSize,
                fontFamily: styles.fontFamily,
                padding: styles.padding,
                margin: styles.margin,
                border: styles.border,
                borderRadius: styles.borderRadius,
                flexDirection: styles.flexDirection,
                justifyContent: styles.justifyContent,
                alignItems: styles.alignItems,
                gap: styles.gap,
                width: styles.width,
                height: styles.height,
                overflow: styles.overflow,
                opacity: styles.opacity,
                zIndex: styles.zIndex,
            },
            parentTag: el.parentElement ? el.parentElement.tagName.toLowerCase() : null,
            childCount: el.children.length,
            siblingIndex: el.parentElement
                ? Array.from(el.parentElement.children).indexOf(el)
                : 0,
        };
    }

    // ── Position highlight box over element ─────────────────────────
    function positionBox(box, el) {
        const rect = el.getBoundingClientRect();
        box.style.left = rect.left + 'px';
        box.style.top = rect.top + 'px';
        box.style.width = rect.width + 'px';
        box.style.height = rect.height + 'px';
        box.style.display = 'block';
    }

    // ── Show tag label ──────────────────────────────────────────────
    function showTag(el) {
        const rect = el.getBoundingClientRect();
        const tag = els.tag;
        tag.textContent = describeElement(el);
        tag.style.display = 'block';

        // Position above element, or below if no room
        let top = rect.top - 24;
        if (top < 4) top = rect.bottom + 4;
        tag.style.left = Math.max(4, rect.left) + 'px';
        tag.style.top = top + 'px';
    }

    // ── Show element path breadcrumb ────────────────────────────────
    function showPath(el) {
        const parts = [];
        let current = el;
        while (current && current !== document.documentElement) {
            let label = current.tagName.toLowerCase();
            if (current.id) label += '#' + current.id;
            else if (current.className && typeof current.className === 'string') {
                const cls = current.className.split(/\s+/).filter(c => c && !c.startsWith('vaal-'))[0];
                if (cls) label += '.' + cls;
            }
            parts.unshift(label);
            current = current.parentElement;
        }
        els.path.textContent = parts.join(' › ');
        els.path.style.display = inspecting ? 'block' : 'none';
    }

    // ── Toast notifications ─────────────────────────────────────────
    function showToast(message, type, duration) {
        const t = els.toast;
        t.textContent = message;
        t.className = type || 'working';
        t.style.display = 'block';
        t.style.opacity = '1';
        if (duration) {
            setTimeout(() => {
                t.style.opacity = '0';
                setTimeout(() => { t.style.display = 'none'; }, 300);
            }, duration);
        }
    }

    // ── Toggle inspect mode ─────────────────────────────────────────
    function toggleInspect() {
        inspecting = !inspecting;
        els.toggle.classList.toggle('active', inspecting);
        document.body.style.cursor = inspecting ? 'crosshair' : '';

        if (!inspecting) {
            els.highlight.style.display = 'none';
            els.tag.style.display = 'none';
            els.path.style.display = 'none';
            hoveredElement = null;
        }
    }

    // ── Open prompt panel for selected element ──────────────────────
    function openPromptPanel(el) {
        selectedElement = el;
        positionBox(els.selected, el);

        const selectorDisplay = document.getElementById('vaal-selected-selector');
        selectorDisplay.textContent = getSelector(el);

        els.panel.style.display = 'block';
        const input = document.getElementById('vaal-prompt-input');
        input.value = '';
        input.focus();

        // Move toggle button up above panel
        els.toggle.style.bottom = '80px';
    }

    // ── Close prompt panel ──────────────────────────────────────────
    function closePanel() {
        els.panel.style.display = 'none';
        els.selected.style.display = 'none';
        selectedElement = null;
        els.toggle.style.bottom = '16px';
    }

    // ── Send feedback to Vaal ───────────────────────────────────────
    async function sendFeedback(prompt) {
        if (!selectedElement) return;

        const context = getElementContext(selectedElement);
        const sendBtn = document.getElementById('vaal-prompt-send');
        const input = document.getElementById('vaal-prompt-input');

        sendBtn.disabled = true;
        sendBtn.textContent = '⟳ Working...';
        showToast('⟳ Vaal is working on it...', 'working');

        try {
            const response = await fetch('/__vaal__/feedback', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    prompt: prompt,
                    element: context,
                    page_url: window.location.pathname,
                    page_title: document.title,
                    viewport: {
                        width: window.innerWidth,
                        height: window.innerHeight,
                    },
                    full_html: document.documentElement.outerHTML.slice(0, 50000),
                }),
            });

            const result = await response.json();

            if (result.success) {
                showToast('✓ Applied! Reloading...', 'success', 2000);
                input.value = '';
                closePanel();
                // Hot reload after short delay
                setTimeout(() => { window.location.reload(); }, 800);
            } else {
                showToast('✗ ' + (result.error || 'Failed'), 'error', 4000);
            }
        } catch (err) {
            showToast('✗ Connection error: ' + err.message, 'error', 4000);
        } finally {
            sendBtn.disabled = false;
            sendBtn.textContent = 'Fix it ⚡';
        }
    }

    // ── Event: mousemove (hover highlight) ──────────────────────────
    document.addEventListener('mousemove', function(e) {
        if (!inspecting) return;

        const el = document.elementFromPoint(e.clientX, e.clientY);
        if (!el || el.id?.startsWith('vaal-') || el.closest('#vaal-prompt-panel') || el === els.toggle) {
            return;
        }

        if (el !== hoveredElement) {
            hoveredElement = el;
            positionBox(els.highlight, el);
            showTag(el);
            showPath(el);
        }
    }, true);

    // ── Event: click (select element) ───────────────────────────────
    document.addEventListener('click', function(e) {
        if (!inspecting) return;

        // Don't intercept clicks on vaal UI
        const target = e.target;
        if (target.id?.startsWith('vaal-') || target.closest('#vaal-prompt-panel') || target === els.toggle) {
            return;
        }

        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();

        // Select the element
        openPromptPanel(target);

        // Exit inspect mode after selection
        inspecting = false;
        els.toggle.classList.remove('active');
        document.body.style.cursor = '';
        els.highlight.style.display = 'none';
        els.tag.style.display = 'none';
        els.path.style.display = 'none';
    }, true);

    // ── Event: toggle button ────────────────────────────────────────
    els.toggle.addEventListener('click', function(e) {
        e.stopPropagation();
        if (els.panel.style.display === 'block') {
            closePanel();
        }
        toggleInspect();
    });

    // ── Event: close panel ──────────────────────────────────────────
    document.getElementById('vaal-panel-close').addEventListener('click', function(e) {
        e.stopPropagation();
        closePanel();
    });

    // ── Event: send button ──────────────────────────────────────────
    document.getElementById('vaal-prompt-send').addEventListener('click', function() {
        const input = document.getElementById('vaal-prompt-input');
        const prompt = input.value.trim();
        if (prompt) sendFeedback(prompt);
    });

    // ── Event: Enter to send, Shift+Enter for newline ───────────────
    document.getElementById('vaal-prompt-input').addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            const prompt = this.value.trim();
            if (prompt) sendFeedback(prompt);
        }
        // Escape closes panel
        if (e.key === 'Escape') {
            closePanel();
        }
    });

    // ── Event: auto-resize textarea ─────────────────────────────────
    document.getElementById('vaal-prompt-input').addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 120) + 'px';
    });

    // ── Keyboard shortcut: Ctrl+Shift+V to toggle ───────────────────
    document.addEventListener('keydown', function(e) {
        // Ctrl+Shift+V = toggle inspector
        if (e.ctrlKey && e.shiftKey && e.key === 'V') {
            e.preventDefault();
            toggleInspect();
        }
        // Escape = exit inspect mode or close panel
        if (e.key === 'Escape') {
            if (els.panel.style.display === 'block') {
                closePanel();
            } else if (inspecting) {
                toggleInspect();
            }
        }
    });

    // ── WebSocket for live reload ───────────────────────────────────
    function connectWS() {
        const wsPort = window.__VAAL_WS_PORT__ || (parseInt(location.port) + 1);
        try {
            const ws = new WebSocket('ws://localhost:' + wsPort);
            ws.onmessage = function(e) {
                const msg = JSON.parse(e.data);
                if (msg.type === 'reload') {
                    showToast('⟳ Reloading...', 'working', 1000);
                    setTimeout(() => window.location.reload(), 300);
                } else if (msg.type === 'status') {
                    showToast(msg.message, msg.level || 'working', msg.duration || 3000);
                }
            };
            ws.onclose = function() {
                // Reconnect after delay
                setTimeout(connectWS, 2000);
            };
            ws.onerror = function() {};
        } catch(e) {
            // WebSocket not available, fall back to polling
            setTimeout(connectWS, 5000);
        }
    }
    connectWS();

    // ── Initial toast ───────────────────────────────────────────────
    showToast('⊙ Vaal Inspector ready — click the orb or Ctrl+Shift+V', 'success', 3000);

    console.log('%c⊙ Vaal Inspector loaded', 'color: #8338ec; font-weight: bold; font-size: 14px;');
    console.log('%cClick the purple orb (bottom-right) or press Ctrl+Shift+V to inspect elements', 'color: #888;');
})();
"""


def get_overlay_injection(ws_port: int = 0) -> str:
    """Return the full <style> + <script> block to inject into HTML pages."""
    ws_line = f"window.__VAAL_WS_PORT__ = {ws_port};" if ws_port else ""
    return f"""
<!-- Vaal Inspector Overlay -->
<style>{OVERLAY_CSS}</style>
<script>{ws_line}\n{OVERLAY_JS}</script>
"""
