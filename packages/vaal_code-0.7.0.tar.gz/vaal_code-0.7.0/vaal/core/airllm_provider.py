"""AirLLM local inference provider for VAAL."""

from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any, Generator

# Patching point for tests
_HF_CACHE_DIR = Path.home() / ".cache" / "huggingface" / "hub"

# Model cache: key = "hf_model_id:compression"
_model_cache: dict[str, Any] = {}
_model_cache_lock = threading.Lock()
_model_load_locks: dict[str, threading.Lock] = {}

COMPRESSION_FLAGS = {"4bit", "8bit", "none"}


def parse_airllm_model_string(model_str: str) -> tuple[str, str | None]:
    """Split 'meta-llama/Llama-3.1-8B:4bit' -> ('meta-llama/Llama-3.1-8B', '4bit').

    Recognized compression flags: 4bit, 8bit, none.
    Anything else stays as part of the model ID.
    """
    parts = model_str.rsplit(":", 1)
    if len(parts) == 2 and parts[1].lower() in COMPRESSION_FLAGS:
        compression = None if parts[1].lower() == "none" else parts[1].lower()
        return parts[0], compression
    return model_str, None


def get_airllm_config() -> dict:
    """Read airllm settings from ~/.vaal/config.json."""
    from .config import VAAL_DIR
    config_file = VAAL_DIR / "config.json"
    defaults: dict[str, Any] = {
        "compression": None,
        "layer_shards_saving_path": None,
        "prefetching": True,
        "max_new_tokens": 512,
    }
    if not config_file.exists():
        return defaults
    try:
        cfg = json.loads(config_file.read_text(encoding="utf-8"))
        return {**defaults, **cfg.get("airllm", {})}
    except Exception:
        return defaults


def get_hf_token() -> str:
    """Get HuggingFace token from ~/.vaal/keys.json."""
    from .config import VAAL_DIR
    keys_file = VAAL_DIR / "keys.json"
    if not keys_file.exists():
        return ""
    try:
        return json.loads(keys_file.read_text(encoding="utf-8")).get("huggingface", "")
    except Exception:
        return ""


def build_tool_system_prompt(tools: list[dict]) -> str:
    """Format tools as JSON schema for injection into system prompt."""
    if not tools:
        return ""
    tool_list = []
    for tool in tools:
        func = tool.get("function", tool)
        tool_list.append({
            "name": func.get("name", ""),
            "description": func.get("description", ""),
            "parameters": func.get("parameters", {}),
        })
    tools_json = json.dumps(tool_list, indent=2)
    return (
        'You have access to tools. To use a tool, output exactly this JSON on its own line and nothing else:\n'
        '{"tool": "tool_name", "parameters": {"param": "value"}}\n'
        'Output one tool call at a time, then stop. Do not explain it.\n\n'
        f'Available tools:\n{tools_json}\n'
    )


def parse_tool_calls(text: str) -> list[dict] | None:
    """Scan model output for tool call JSON. Returns VAAL tool_calls format or None."""
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            obj = json.loads(line)
            if "tool" in obj and isinstance(obj.get("parameters"), dict):
                tool_name = obj["tool"]
                return [{
                    "id": f"tool_{tool_name}",
                    "function": {
                        "name": tool_name,
                        "arguments": obj["parameters"],
                    },
                }]
        except (json.JSONDecodeError, ValueError):
            continue
    return None


def list_cached_models() -> list[str]:
    """Scan HF cache for downloaded models. Returns sorted 'org/model' strings."""
    if not _HF_CACHE_DIR.exists():
        return []
    models = []
    for entry in _HF_CACHE_DIR.iterdir():
        if entry.is_dir() and entry.name.startswith("models--"):
            parts = entry.name[len("models--"):].split("--", 1)
            if len(parts) == 2:
                models.append(f"{parts[0]}/{parts[1]}")
    return sorted(models)


def load_model(hf_model_id: str, compression_override: str | None) -> Any:
    """Load and cache an AirLLM model. First call shards the model to disk."""
    cache_key = f"{hf_model_id}:{compression_override}"

    with _model_cache_lock:
        if cache_key in _model_cache:
            return _model_cache[cache_key]
        if cache_key not in _model_load_locks:
            _model_load_locks[cache_key] = threading.Lock()
        key_lock = _model_load_locks[cache_key]

    with key_lock:
        with _model_cache_lock:
            if cache_key in _model_cache:
                return _model_cache[cache_key]

        from airllm import AutoModel
        cfg = get_airllm_config()

        kwargs: dict[str, Any] = {}
        effective_compression = compression_override if compression_override is not None else cfg["compression"]
        if effective_compression:
            kwargs["compression"] = effective_compression
        if cfg["layer_shards_saving_path"]:
            kwargs["layer_shards_saving_path"] = cfg["layer_shards_saving_path"]
        hf_token = get_hf_token()
        if hf_token:
            kwargs["hf_token"] = hf_token
        if not cfg["prefetching"]:
            kwargs["prefetching"] = False

        model = AutoModel.from_pretrained(hf_model_id, **kwargs)
        with _model_cache_lock:
            _model_cache[cache_key] = model
        return model


def format_messages(tokenizer: Any, messages: list[dict], tools: list[dict]) -> Any:
    """Apply chat template with injected tool prompt. Returns CUDA input_ids tensor."""
    msgs = list(messages)
    if tools:
        tool_prompt = build_tool_system_prompt(tools)
        if msgs and msgs[0]["role"] == "system":
            msgs[0] = {"role": "system", "content": tool_prompt + "\n" + msgs[0]["content"]}
        else:
            msgs.insert(0, {"role": "system", "content": tool_prompt})

    try:
        text = tokenizer.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    except Exception:
        parts = []
        for msg in msgs:
            content = msg.get("content", "")
            if isinstance(content, list):
                content = " ".join(c.get("text", "") for c in content if isinstance(c, dict))
            parts.append(f"{msg['role']}: {content}")
        parts.append("assistant:")
        text = "\n".join(parts)

    tokens = tokenizer(
        [text],
        return_tensors="pt",
        return_attention_mask=False,
        truncation=True,
        max_length=2048,
        padding=False,
    )
    return tokens["input_ids"].cuda()


def stream_airllm(
    messages: list[dict],
    tools: list[dict] | None,
    model_str: str,
    max_tokens: int,
) -> Generator[dict, None, None]:
    """Main streaming entry point. Yields chunks with content/tool_calls/done keys."""
    try:
        import airllm  # noqa: F401
    except ImportError:
        yield {"content": "[error: airllm not installed. Run: pip install airllm]", "done": True}
        return

    hf_model_id, compression_override = parse_airllm_model_string(model_str)
    cfg = get_airllm_config()
    _cfg_max = cfg.get("max_new_tokens") or 512
    effective_max_tokens = min(max_tokens, _cfg_max) if max_tokens else _cfg_max

    try:
        yield {"content": f"[loading {hf_model_id}...]"}
        model = load_model(hf_model_id, compression_override)
    except Exception as e:
        yield {"content": f"[error loading model: {e}]", "done": True}
        return

    try:
        input_ids = format_messages(model.tokenizer, messages, tools or [])
    except Exception as e:
        yield {"content": f"[error tokenizing: {e}]", "done": True}
        return

    buffer = ""

    try:
        from transformers import TextIteratorStreamer
        streamer = TextIteratorStreamer(model.tokenizer, skip_prompt=True, skip_special_tokens=True)
        _thread_error: list[Exception | None] = [None]

        def _run_generate() -> None:
            try:
                model.generate(
                    input_ids,
                    max_new_tokens=effective_max_tokens,
                    use_cache=True,
                    return_dict_in_generate=True,
                    streamer=streamer,
                )
            except Exception as exc:
                _thread_error[0] = exc
                streamer.text_queue.put(streamer.stop_signal)

        thread = threading.Thread(target=_run_generate, daemon=True)
        thread.start()
        for token_text in streamer:
            buffer += token_text
            if token_text:
                yield {"content": token_text}
        thread.join(timeout=300)
        if thread.is_alive():
            yield {"content": "[warning: generation timed out after 300s]", "done": True}
            return
        if _thread_error[0]:
            raise _thread_error[0]
    except Exception:
        # Fallback: synchronous generate
        try:
            output = model.generate(
                input_ids,
                max_new_tokens=effective_max_tokens,
                use_cache=True,
                return_dict_in_generate=True,
            )
            full_text = model.tokenizer.decode(output.sequences[0], skip_special_tokens=True)
            prompt_text = model.tokenizer.decode(input_ids[0], skip_special_tokens=True)
            if full_text.startswith(prompt_text):
                full_text = full_text[len(prompt_text):]
            buffer = full_text.strip()
            if buffer:
                yield {"content": buffer}
        except Exception as e:
            yield {"content": f"[error during generation: {e}]", "done": True}
            return

    if tools:
        tool_calls = parse_tool_calls(buffer)
        if tool_calls:
            yield {"tool_calls": tool_calls}

    yield {"done": True}


def pull_airllm_model(hf_model_id: str, hf_token: str = "") -> Generator[str, None, None]:
    """Download a HuggingFace model. Yields progress/status strings."""
    try:
        from huggingface_hub import snapshot_download
    except ImportError:
        yield "[error: huggingface_hub not installed. Run: pip install huggingface_hub]"
        return

    cfg = get_airllm_config()
    kwargs: dict[str, Any] = {"repo_id": hf_model_id}
    token = hf_token or get_hf_token()
    if token:
        kwargs["token"] = token
    if cfg["layer_shards_saving_path"]:
        kwargs["local_dir"] = cfg["layer_shards_saving_path"]

    yield f"Downloading {hf_model_id} from HuggingFace..."
    try:
        try:
            from huggingface_hub import utils as _hf_utils
            _hf_utils.disable_progress_bars()
        except Exception:
            pass

        local_path = snapshot_download(**kwargs)

        try:
            from huggingface_hub import utils as _hf_utils
            _hf_utils.enable_progress_bars()
        except Exception:
            pass

        yield f"Done. Model saved to: {local_path}"
    except Exception as e:
        msg = str(e)
        if "401" in msg or "gated" in msg.lower() or "access" in msg.lower():
            yield "[error: model requires authentication. Run /login huggingface <token>]"
        else:
            yield f"[error: {msg}]"
