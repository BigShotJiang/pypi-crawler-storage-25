"""Multiline input support — enter multiline mode with triple quotes or triple backticks."""

import sys


MULTILINE_TRIGGERS = ('"""', "'''", "```")
CONTINUATION_PROMPT = "  ... "


def is_multiline_trigger(text: str) -> bool:
    """Check if the input text starts a multiline block."""
    stripped = text.strip()
    return stripped in MULTILINE_TRIGGERS or any(stripped.startswith(t) for t in MULTILINE_TRIGGERS)


def get_trigger_token(text: str) -> str | None:
    """Return the trigger token if text starts with one, else None."""
    stripped = text.strip()
    for token in MULTILINE_TRIGGERS:
        if stripped == token or stripped.startswith(token):
            return token
    return None


def read_multiline(first_line: str) -> str:
    """Read multiline input until the closing trigger is found.

    first_line: the initial line the user typed (may contain text after the trigger).
    Returns the full collected text (without the trigger delimiters).
    """
    token = get_trigger_token(first_line)
    if token is None:
        return first_line

    # Text after the opening trigger on the first line
    after_trigger = first_line.strip()[len(token):]

    # Check if the closing trigger is on the same line (e.g. ```code```)
    if token in after_trigger:
        idx = after_trigger.index(token)
        return after_trigger[:idx]

    lines = []
    if after_trigger:
        lines.append(after_trigger)

    if sys.platform == "win32":
        return _collect_win(token, lines)
    else:
        return _collect_unix(token, lines)


def _write(s: str):
    sys.stdout.write(s)
    sys.stdout.flush()


def _collect_win(token: str, lines: list[str]) -> str:
    """Collect multiline input on Windows using msvcrt."""
    import msvcrt

    buf = []
    _write(CONTINUATION_PROMPT)

    while True:
        ch = msvcrt.getwch()

        if ch in ("\x00", "\xe0"):
            msvcrt.getwch()  # consume extended key
            continue

        if ch == "\x03":
            raise KeyboardInterrupt

        if ch == "\x04" or ch == "\x1a":
            # Ctrl+D / Ctrl+Z — cancel multiline, return what we have
            _write("\n")
            lines.append("".join(buf))
            return "\n".join(lines)

        if ch == "\r":
            line = "".join(buf)
            _write("\n")

            # Check if this line ends the multiline block
            if token in line:
                idx = line.index(token)
                if idx > 0:
                    lines.append(line[:idx])
                return "\n".join(lines)

            lines.append(line)
            buf = []
            _write(CONTINUATION_PROMPT)
            continue

        if ch == "\x08":
            # Backspace
            if buf:
                buf.pop()
                _write("\b \b")
            continue

        buf.append(ch)
        _write(ch)


def _collect_unix(token: str, lines: list[str]) -> str:
    """Collect multiline input on Unix using raw terminal."""
    import tty
    import termios

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    buf = []

    try:
        tty.setcbreak(fd)
        _write(CONTINUATION_PROMPT)

        while True:
            ch = sys.stdin.read(1)

            if ch == "\x03":
                raise KeyboardInterrupt

            if ch == "\x04":
                _write("\n")
                lines.append("".join(buf))
                return "\n".join(lines)

            if ch == "\n" or ch == "\r":
                line = "".join(buf)
                _write("\n")

                if token in line:
                    idx = line.index(token)
                    if idx > 0:
                        lines.append(line[:idx])
                    return "\n".join(lines)

                lines.append(line)
                buf = []
                _write(CONTINUATION_PROMPT)
                continue

            if ch == "\x1b":
                # Escape sequence — consume and ignore
                ch2 = sys.stdin.read(1)
                if ch2 == "[":
                    ch3 = sys.stdin.read(1)
                    if ch3 == "3":
                        sys.stdin.read(1)  # consume ~
                continue

            if ch == "\x7f" or ch == "\x08":
                if buf:
                    buf.pop()
                    _write("\b \b")
                continue

            buf.append(ch)
            _write(ch)

    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
