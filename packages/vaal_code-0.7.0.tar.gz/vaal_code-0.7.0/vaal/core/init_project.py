"""Project init — generate VAAL.md with detected project info."""

from __future__ import annotations

import os
from pathlib import Path

from .bootstrap import scan_project, ProjectInfo


def _detect_entry_points(root: Path) -> list[str]:
    """Find likely entry point files."""
    candidates = [
        "main.py", "app.py", "server.py", "index.py", "manage.py", "cli.py",
        "main.go", "main.rs", "main.js", "main.ts", "index.js", "index.ts",
        "app.js", "app.ts", "server.js", "server.ts",
        "Main.java", "App.java",
        "main.swift", "AppDelegate.swift",
        "main.c", "main.cpp",
        "index.php", "index.html",
    ]
    found = []
    for c in candidates:
        if (root / c).exists():
            found.append(c)
    # Also check src/ directory
    src = root / "src"
    if src.is_dir():
        for c in candidates:
            if (src / c).exists():
                found.append(f"src/{c}")
    return found


def _detect_test_commands(info: ProjectInfo) -> list[str]:
    """Infer test commands from detected frameworks."""
    commands = []
    for fw in info.test_frameworks:
        if fw == "pytest":
            commands.append("pytest")
        elif fw == "jest":
            commands.append("npx jest")
        elif fw == "vitest":
            commands.append("npx vitest run")
        elif fw == "mocha":
            commands.append("npx mocha")
        elif fw == "playwright":
            commands.append("npx playwright test")
        elif fw == "cargo test":
            commands.append("cargo test")
        elif fw == "go test":
            commands.append("go test ./...")
        elif fw == "phpunit":
            commands.append("./vendor/bin/phpunit")
    return commands


def _detect_build_commands(info: ProjectInfo) -> list[str]:
    """Infer build commands from detected build systems."""
    commands = []
    for bs in info.build_systems:
        if bs == "make":
            commands.append("make")
        elif bs == "cmake":
            commands.append("cmake --build build")
        elif bs in ("docker", "docker-compose"):
            commands.append(f"{bs} build" if bs == "docker" else f"{bs} up --build")
        elif bs == "webpack":
            commands.append("npx webpack")
        elif bs in ("vite",):
            commands.append("npx vite build")
        elif bs == "task":
            commands.append("task")
        elif bs == "just":
            commands.append("just")
    # Language-specific defaults
    if "cargo" in info.package_managers:
        commands.append("cargo build")
    if "go modules" in info.package_managers and not commands:
        commands.append("go build ./...")
    return commands


def _build_directory_tree(root: Path, max_depth: int = 2, prefix: str = "") -> str:
    """Build a simple directory tree string."""
    IGNORE = {
        ".git", "node_modules", "__pycache__", ".venv", "venv",
        "dist", "build", "target", ".idea", ".vscode", ".mypy_cache",
        ".pytest_cache", ".tox", "egg-info", ".eggs", ".next",
    }

    lines = []
    try:
        entries = sorted(root.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
    except PermissionError:
        return ""

    # Filter
    entries = [e for e in entries if e.name not in IGNORE and not e.name.startswith(".")]
    dirs = [e for e in entries if e.is_dir()]
    files = [e for e in entries if e.is_file()]

    # Show files first (up to 15), then dirs
    shown_files = files[:15]
    for f in shown_files:
        lines.append(f"{prefix}{f.name}")
    if len(files) > 15:
        lines.append(f"{prefix}... ({len(files) - 15} more files)")

    for d in dirs:
        lines.append(f"{prefix}{d.name}/")
        if max_depth > 1:
            subtree = _build_directory_tree(d, max_depth=max_depth - 1, prefix=prefix + "  ")
            if subtree:
                lines.append(subtree)

    return "\n".join(lines)


def generate_vaal_md(cwd: str | None = None, llm_summary: str = "") -> str:
    """Generate VAAL.md content for the project at cwd.

    Args:
        cwd: Project directory (defaults to os.getcwd())
        llm_summary: Optional LLM-generated project summary to include.

    Returns:
        The VAAL.md content as a string.
    """
    cwd = cwd or os.getcwd()
    root = Path(cwd)
    info = scan_project(cwd)

    sections = []

    # Header
    project_name = root.name
    sections.append(f"# {project_name}\n")

    # LLM summary or auto-generated summary
    if llm_summary:
        sections.append(llm_summary.strip())
        sections.append("")
    else:
        desc_parts = []
        if info.primary_language:
            desc_parts.append(f"A {info.primary_language} project")
        if info.package_managers:
            desc_parts.append(f"using {', '.join(info.package_managers)}")
        if desc_parts:
            sections.append(" ".join(desc_parts) + ".")
            sections.append("")

    # Project info
    sections.append("## Project Info\n")
    rows = []
    if info.primary_language:
        rows.append(f"- **Language**: {info.primary_language}")
    if info.languages and len(info.languages) > 1:
        rows.append(f"- **Other languages**: {', '.join(l for l in info.languages if l != info.primary_language)}")
    if info.package_managers:
        rows.append(f"- **Package manager**: {', '.join(info.package_managers)}")
    if info.build_systems:
        rows.append(f"- **Build system**: {', '.join(info.build_systems)}")
    if info.test_frameworks:
        rows.append(f"- **Test framework**: {', '.join(info.test_frameworks)}")
    if info.is_git_repo:
        rows.append("- **Version control**: Git")
    if info.has_ci:
        rows.append("- **CI/CD**: Detected")
    if rows:
        sections.append("\n".join(rows))
        sections.append("")

    # Entry points
    entry_points = _detect_entry_points(root)
    if entry_points:
        sections.append("## Entry Points\n")
        for ep in entry_points:
            sections.append(f"- `{ep}`")
        sections.append("")

    # Directory structure
    tree = _build_directory_tree(root)
    if tree:
        sections.append("## Structure\n")
        sections.append("```")
        sections.append(tree)
        sections.append("```")
        sections.append("")

    # Commands
    test_cmds = _detect_test_commands(info)
    build_cmds = _detect_build_commands(info)

    if test_cmds or build_cmds:
        sections.append("## Commands\n")
        if build_cmds:
            sections.append("### Build")
            sections.append("```bash")
            for cmd in build_cmds:
                sections.append(cmd)
            sections.append("```")
            sections.append("")
        if test_cmds:
            sections.append("### Test")
            sections.append("```bash")
            for cmd in test_cmds:
                sections.append(cmd)
            sections.append("```")
            sections.append("")

    return "\n".join(sections)


def run_init(cwd: str | None = None) -> tuple[str, str]:
    """Run the /init command — scan and generate VAAL.md.

    Returns:
        (vaal_md_path, content) — the path where VAAL.md was written and its content.
    """
    cwd = cwd or os.getcwd()
    root = Path(cwd)

    content = generate_vaal_md(cwd)
    out_path = root / "VAAL.md"
    out_path.write_text(content, encoding="utf-8")

    return str(out_path), content
