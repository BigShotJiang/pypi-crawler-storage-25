"""Terminal theme system — OSC escape sequences for terminal color customization."""

import sys
import json
from pathlib import Path
from .config import VAAL_DIR


# ── Theme definitions ───────────────────────────────────────────────

THEMES = {
    "vaal": {
        "description": "Vaal Orb — crimson & corruption purple",
        "background": "#0a0008",
        "foreground": "#d4c4c8",
        "cursor": "#bf1f3e",
        "ansi": [
            "#0a0008",  # 0  Black: bg color
            "#bf1f3e",  # 1  Red: blood crimson
            "#6a3fa0",  # 2  Green: corrupted purple
            "#8b1a4a",  # 3  Yellow: dark magenta-red
            "#4a1a8b",  # 4  Blue: deep corruption purple
            "#9b30ff",  # 5  Magenta: vaal purple
            "#5769f7",  # 6  Cyan: corruption blue
            "#d4c4c8",  # 7  White: pale pinkish-gray
            "#1a0012",  # 8  Bright black: slightly lighter bg
            "#e63358",  # 9  Bright red: brighter crimson
            "#8b5fbf",  # 10 Bright green: lighter purple
            "#a83060",  # 11 Bright yellow: lighter magenta
            "#6a3aab",  # 12 Bright blue: lighter corruption
            "#b060ff",  # 13 Bright magenta: lighter vaal
            "#7b8bf9",  # 14 Bright cyan: lighter blue
            "#f0e0e8",  # 15 Bright white: warm white
        ],
    },
    "dark": {
        "description": "Dark — original Vaal dark blue-black",
        "background": "#0d1117",
        "foreground": "#e0e0e0",
        "cursor": "#5769f7",
        "ansi": [
            "#0d1117",  # 0  Black
            "#ab2b3f",  # 1  Red
            "#2c7a39",  # 2  Green
            "#966c1e",  # 3  Yellow
            "#5769f7",  # 4  Blue
            "#af87ff",  # 5  Magenta
            "#5bc0be",  # 6  Cyan
            "#e0e0e0",  # 7  White
            "#555555",  # 8  Bright black
            "#ff6b7a",  # 9  Bright red
            "#4ade80",  # 10 Bright green
            "#fbbf24",  # 11 Bright yellow
            "#7b8bf9",  # 12 Bright blue
            "#c4b5fd",  # 13 Bright magenta
            "#67e8f9",  # 14 Bright cyan
            "#ffffff",  # 15 Bright white
        ],
    },
    "light": {
        "description": "Light — pale background, dark text",
        "background": "#fafafa",
        "foreground": "#1a1a2e",
        "cursor": "#4a1a8b",
        "ansi": [
            "#1a1a2e",  # 0  Black
            "#b91c1c",  # 1  Red
            "#15803d",  # 2  Green
            "#a16207",  # 3  Yellow
            "#4a1a8b",  # 4  Blue
            "#7c3aed",  # 5  Magenta
            "#0891b2",  # 6  Cyan
            "#f5f5f5",  # 7  White
            "#6b7280",  # 8  Bright black
            "#ef4444",  # 9  Bright red
            "#22c55e",  # 10 Bright green
            "#eab308",  # 11 Bright yellow
            "#6366f1",  # 12 Bright blue
            "#a78bfa",  # 13 Bright magenta
            "#06b6d4",  # 14 Bright cyan
            "#fafafa",  # 15 Bright white
        ],
    },
    "mono": {
        "description": "Mono — grayscale, no color distraction",
        "background": "#0c0c0c",
        "foreground": "#c8c8c8",
        "cursor": "#ffffff",
        "ansi": [
            "#0c0c0c",  # 0  Black
            "#808080",  # 1  Red -> gray
            "#a0a0a0",  # 2  Green -> lighter gray
            "#707070",  # 3  Yellow -> mid gray
            "#909090",  # 4  Blue -> gray
            "#b0b0b0",  # 5  Magenta -> light gray
            "#a0a0a0",  # 6  Cyan -> gray
            "#c8c8c8",  # 7  White
            "#404040",  # 8  Bright black
            "#999999",  # 9  Bright red
            "#bbbbbb",  # 10 Bright green
            "#888888",  # 11 Bright yellow
            "#aaaaaa",  # 12 Bright blue
            "#cccccc",  # 13 Bright magenta
            "#bbbbbb",  # 14 Bright cyan
            "#ffffff",  # 15 Bright white
        ],
    },
    "blood": {
        "description": "Blood — deep red on black, monochrome crimson",
        "background": "#080000",
        "foreground": "#cc4444",
        "cursor": "#ff2222",
        "ansi": [
            "#080000",  # 0  Black
            "#cc2222",  # 1  Red
            "#882222",  # 2  Green -> dark red
            "#aa3333",  # 3  Yellow -> mid red
            "#661111",  # 4  Blue -> deep red
            "#dd3333",  # 5  Magenta -> bright red
            "#993333",  # 6  Cyan -> red
            "#cc4444",  # 7  White -> red-gray
            "#330000",  # 8  Bright black
            "#ff4444",  # 9  Bright red
            "#aa4444",  # 10 Bright green
            "#cc5555",  # 11 Bright yellow
            "#884444",  # 12 Bright blue
            "#ee5555",  # 13 Bright magenta
            "#bb4444",  # 14 Bright cyan
            "#ff6666",  # 15 Bright white
        ],
    },
}

DEFAULT_THEME = "vaal"
PREFS_FILE = VAAL_DIR / "terminal_theme.json"


def _osc(s: str):
    """Write an OSC escape sequence."""
    sys.stdout.write(s)


def apply_theme(theme_name: str) -> bool:
    """Apply terminal colors via OSC escape sequences. Returns True on success."""
    theme = THEMES.get(theme_name)
    if not theme:
        return False

    w = sys.stdout.write
    w(f"\033]10;{theme['foreground']}\007")   # Foreground
    w(f"\033]11;{theme['background']}\007")   # Background
    w(f"\033]12;{theme['cursor']}\007")       # Cursor

    for i, color in enumerate(theme["ansi"]):
        w(f"\033]4;{i};{color}\007")

    sys.stdout.flush()
    return True


def reset_theme():
    """Reset terminal to default colors via OSC 110/111/112 and palette reset."""
    w = sys.stdout.write
    w("\033]110\007")  # Reset foreground
    w("\033]111\007")  # Reset background
    w("\033]112\007")  # Reset cursor
    # Reset all 16 ANSI palette colors
    for i in range(16):
        w(f"\033]104;{i}\007")
    sys.stdout.flush()


def save_preference(theme_name: str):
    """Save theme preference to disk."""
    VAAL_DIR.mkdir(exist_ok=True)
    with open(PREFS_FILE, "w", encoding="utf-8") as f:
        json.dump({"terminal_theme": theme_name}, f)


def load_preference() -> str:
    """Load saved theme preference, or return default."""
    try:
        if PREFS_FILE.exists():
            with open(PREFS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                name = data.get("terminal_theme", DEFAULT_THEME)
                if name in THEMES:
                    return name
    except (json.JSONDecodeError, OSError):
        pass
    return DEFAULT_THEME


def get_theme_names() -> list[str]:
    """Return list of available theme names."""
    return list(THEMES.keys())


def get_theme(name: str) -> dict | None:
    """Get a theme dict by name."""
    return THEMES.get(name)
