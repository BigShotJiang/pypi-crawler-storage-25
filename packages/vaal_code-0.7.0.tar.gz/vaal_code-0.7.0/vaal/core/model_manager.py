"""Smart model management — hardware detection, catalog, compatibility filtering."""

import json
import subprocess
import re
from pathlib import Path
from dataclasses import dataclass, field, asdict
from typing import Optional

from .config import VAAL_DIR

CATALOG_FILE = VAAL_DIR / "model_catalog.json"


# ── Hardware detection ──────────────────────────────────────────────

@dataclass
class HardwareInfo:
    gpu_name: str = "Unknown"
    vram_gb: float = 0.0
    ram_gb: float = 0.0

    def summary(self) -> str:
        parts = []
        if self.gpu_name != "Unknown":
            parts.append(f"{self.gpu_name} ({self.vram_gb:.0f} GB VRAM)")
        else:
            parts.append("No GPU detected")
        parts.append(f"RAM: {self.ram_gb:.0f} GB")
        return " | ".join(parts)


def detect_hardware() -> HardwareInfo:
    """Detect GPU and RAM using subprocess commands (no extra deps)."""
    info = HardwareInfo()

    # GPU via nvidia-smi
    try:
        result = subprocess.run(
            ["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"],
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode == 0 and result.stdout.strip():
            line = result.stdout.strip().split("\n")[0]
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 2:
                info.gpu_name = parts[0]
                try:
                    info.vram_gb = float(parts[1]) / 1024  # MiB -> GB
                except ValueError:
                    pass
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass

    # RAM — try platform-appropriate methods
    info.ram_gb = _detect_ram()

    return info


def _detect_ram() -> float:
    """Get total system RAM in GB."""
    import sys

    if sys.platform == "win32":
        # Try wmic first
        try:
            result = subprocess.run(
                ["wmic", "ComputerSystem", "get", "TotalPhysicalMemory"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                for line in result.stdout.strip().split("\n"):
                    line = line.strip()
                    if line.isdigit():
                        return float(line) / (1024 ** 3)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        # Fallback: powershell
        try:
            result = subprocess.run(
                ["powershell", "-Command",
                 "(Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip().isdigit():
                return float(result.stdout.strip()) / (1024 ** 3)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
    else:
        # Linux/macOS: /proc/meminfo or sysctl
        try:
            with open("/proc/meminfo", "r") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        kb = int(line.split()[1])
                        return kb / (1024 ** 2)
        except (FileNotFoundError, OSError):
            pass

        try:
            result = subprocess.run(
                ["sysctl", "-n", "hw.memsize"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0 and result.stdout.strip().isdigit():
                return float(result.stdout.strip()) / (1024 ** 3)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    return 0.0


# ── Model catalog ───────────────────────────────────────────────────

@dataclass
class ModelEntry:
    name: str                    # ollama pull name, e.g. "qwen3:8b"
    display_name: str            # human-friendly name
    size_gb: float               # approximate download/disk size
    vram_required_gb: float      # minimum VRAM to run well
    ram_required_gb: float       # minimum RAM if partially offloading
    description: str             # one-line description
    recommended: bool = False    # best for this VRAM tier
    category: str = "general"    # general, coding, uncensored

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "ModelEntry":
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


# Default catalog covering different VRAM tiers
DEFAULT_CATALOG: list[ModelEntry] = [
    # 4-6 GB VRAM tier
    ModelEntry(
        name="llama3.2:3b",
        display_name="Llama 3.2 3B",
        size_gb=2.0,
        vram_required_gb=3.5,
        ram_required_gb=4.0,
        description="Fast, compact general-purpose model from Meta",
        recommended=False,
        category="general",
    ),
    ModelEntry(
        name="qwen3:4b",
        display_name="Qwen 3 4B",
        size_gb=2.7,
        vram_required_gb=4.0,
        ram_required_gb=5.0,
        description="Small but capable model with thinking support",
        recommended=True,
        category="general",
    ),

    # 8 GB VRAM tier
    ModelEntry(
        name="mistral:7b",
        display_name="Mistral 7B",
        size_gb=4.1,
        vram_required_gb=6.0,
        ram_required_gb=8.0,
        description="Solid general-purpose model from Mistral AI",
        recommended=False,
        category="general",
    ),
    ModelEntry(
        name="qwen3:8b",
        display_name="Qwen 3 8B",
        size_gb=5.2,
        vram_required_gb=6.5,
        ram_required_gb=8.0,
        description="Best balance of speed and quality for 8GB cards",
        recommended=True,
        category="general",
    ),
    ModelEntry(
        name="deepseek-coder-v2:16b",
        display_name="DeepSeek Coder V2 16B",
        size_gb=8.9,
        vram_required_gb=7.5,
        ram_required_gb=10.0,
        description="Specialized coding model with strong completions",
        recommended=False,
        category="coding",
    ),

    # 12 GB VRAM tier
    ModelEntry(
        name="qwen3.5:9b",
        display_name="Qwen 3.5 9B",
        size_gb=6.9,
        vram_required_gb=8.0,
        ram_required_gb=10.0,
        description="Latest Qwen with excellent reasoning",
        recommended=True,
        category="general",
    ),
    ModelEntry(
        name="qwen2.5:14b",
        display_name="Qwen 2.5 14B",
        size_gb=9.2,
        vram_required_gb=10.0,
        ram_required_gb=12.0,
        description="Larger Qwen with strong instruction following",
        recommended=False,
        category="general",
    ),
    ModelEntry(
        name="qwen3.5-9b-heretic",
        display_name="Qwen 3.5 9B Heretic",
        size_gb=8.9,
        vram_required_gb=9.0,
        ram_required_gb=11.0,
        description="Uncensored variant of Qwen 3.5 9B",
        recommended=False,
        category="uncensored",
    ),

    # 16 GB+ VRAM tier
    ModelEntry(
        name="qwen3.5:27b",
        display_name="Qwen 3.5 27B",
        size_gb=17.0,
        vram_required_gb=14.0,
        ram_required_gb=20.0,
        description="Large Qwen model with strong reasoning and coding",
        recommended=True,
        category="general",
    ),
    ModelEntry(
        name="qwen2.5:32b",
        display_name="Qwen 2.5 32B",
        size_gb=20.0,
        vram_required_gb=16.0,
        ram_required_gb=24.0,
        description="High-quality general model for 16GB+ cards",
        recommended=False,
        category="general",
    ),
    ModelEntry(
        name="qwen2.5-coder:32b",
        display_name="Qwen 2.5 Coder 32B",
        size_gb=20.0,
        vram_required_gb=16.0,
        ram_required_gb=24.0,
        description="Top-tier coding model from Qwen family",
        recommended=False,
        category="coding",
    ),

    # 24 GB+ VRAM tier
    ModelEntry(
        name="qwen2.5:72b",
        display_name="Qwen 2.5 72B",
        size_gb=47.0,
        vram_required_gb=24.0,
        ram_required_gb=48.0,
        description="Flagship Qwen — near frontier quality",
        recommended=True,
        category="general",
    ),
    ModelEntry(
        name="llama3.1:70b",
        display_name="Llama 3.1 70B",
        size_gb=43.0,
        vram_required_gb=24.0,
        ram_required_gb=48.0,
        description="Meta's large open model with broad capabilities",
        recommended=False,
        category="general",
    ),
]


# ── Model Manager ──────────────────────────────────────────────────

class ModelManager:
    """Manages model catalog, hardware detection, and compatibility."""

    def __init__(self):
        self.hardware: Optional[HardwareInfo] = None
        self.catalog: list[ModelEntry] = []
        self._installed_models: set[str] = set()

    def detect(self):
        """Run hardware detection."""
        self.hardware = detect_hardware()

    def load_catalog(self):
        """Load catalog from disk or use defaults."""
        if CATALOG_FILE.exists():
            try:
                with open(CATALOG_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                self.catalog = [ModelEntry.from_dict(d) for d in data]
                return
            except (json.JSONDecodeError, OSError, TypeError):
                pass
        self.catalog = list(DEFAULT_CATALOG)
        self.save_catalog()

    def save_catalog(self):
        """Persist catalog to disk."""
        VAAL_DIR.mkdir(exist_ok=True)
        with open(CATALOG_FILE, "w", encoding="utf-8") as f:
            json.dump([e.to_dict() for e in self.catalog], f, indent=2)

    def refresh_installed(self):
        """Check which catalog models are installed via ollama list."""
        self._installed_models.clear()
        try:
            result = subprocess.run(
                ["ollama", "list"],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0:
                for line in result.stdout.strip().split("\n")[1:]:  # skip header
                    if line.strip():
                        # First column is model name (NAME)
                        model_name = line.split()[0].strip()
                        self._installed_models.add(model_name)
                        # Also add without :latest suffix for matching
                        if model_name.endswith(":latest"):
                            self._installed_models.add(model_name[:-7])
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

    def is_installed(self, model_name: str) -> bool:
        """Check if a model is installed."""
        # Check exact match and with :latest
        return (
            model_name in self._installed_models
            or f"{model_name}:latest" in self._installed_models
            # Also check if any installed model starts with this name
            or any(m.startswith(model_name) for m in self._installed_models)
        )

    def compatibility(self, entry: ModelEntry) -> str:
        """
        Return compatibility tier for a model given detected hardware.
        Returns: "optimal" | "slower" | "hidden"
        """
        if not self.hardware:
            return "optimal"  # can't detect, show everything

        vram = self.hardware.vram_gb
        ram = self.hardware.ram_gb

        # Fits entirely in VRAM
        if entry.vram_required_gb <= vram:
            return "optimal"

        # Doesn't fit in VRAM but can spill to RAM
        total_available = vram + ram
        if entry.ram_required_gb <= ram and entry.vram_required_gb <= total_available:
            return "slower"

        return "hidden"

    def get_visible_models(self) -> list[tuple[ModelEntry, str]]:
        """Return (entry, compatibility) pairs for models that can run on this machine."""
        results = []
        for entry in self.catalog:
            compat = self.compatibility(entry)
            if compat != "hidden":
                results.append((entry, compat))
        return results

    def get_recommended(self) -> Optional[ModelEntry]:
        """Get the best recommended model that fits this hardware."""
        visible = self.get_visible_models()
        # Find the largest recommended model that runs at "optimal"
        best = None
        for entry, compat in visible:
            if entry.recommended and compat == "optimal":
                if best is None or entry.vram_required_gb > best.vram_required_gb:
                    best = entry
        # Fallback: any optimal model
        if not best:
            for entry, compat in visible:
                if compat == "optimal":
                    if best is None or entry.vram_required_gb > best.vram_required_gb:
                        best = entry
        return best

    def find_model(self, query: str) -> Optional[ModelEntry]:
        """Find a model in catalog by name (exact or partial match)."""
        query_lower = query.lower().strip()
        # Exact match
        for entry in self.catalog:
            if entry.name.lower() == query_lower:
                return entry
        # Partial match
        for entry in self.catalog:
            if query_lower in entry.name.lower() or query_lower in entry.display_name.lower():
                return entry
        return None


# ── Singleton for easy access ──────────────────────────────────────

_manager: Optional[ModelManager] = None


def get_manager() -> ModelManager:
    """Get or create the global ModelManager instance."""
    global _manager
    if _manager is None:
        _manager = ModelManager()
        _manager.load_catalog()
    return _manager


def init_manager() -> ModelManager:
    """Initialize manager with hardware detection and installed model check."""
    mgr = get_manager()
    mgr.detect()
    mgr.refresh_installed()
    return mgr


# ── Pull / Remove with progress ───────────────────────────────────

def pull_model(model_name: str) -> subprocess.Popen:
    """Start ollama pull as a subprocess. Returns the Popen object for progress reading."""
    return subprocess.Popen(
        ["ollama", "pull", model_name],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1,
    )


def remove_model(model_name: str) -> tuple[bool, str]:
    """Remove a model via ollama rm. Returns (success, message)."""
    try:
        result = subprocess.run(
            ["ollama", "rm", model_name],
            capture_output=True, text=True, timeout=30,
        )
        if result.returncode == 0:
            return True, result.stdout.strip() or f"Removed {model_name}"
        else:
            return False, result.stderr.strip() or f"Failed to remove {model_name}"
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return False, str(e)


def is_first_run() -> bool:
    """Check if this is first launch (no config file exists)."""
    config_file = VAAL_DIR / "config.json"
    return not config_file.exists()
