"""Skills system — markdown files with frontmatter that inject context on trigger match."""

import logging
import re
from dataclasses import dataclass
from pathlib import Path

from .config import VAAL_DIR

logger = logging.getLogger(__name__)

SKILLS_DIR = VAAL_DIR / "skills"


@dataclass
class Skill:
    name: str
    description: str
    trigger: str  # regex pattern to match against user input
    content: str  # markdown body to inject as context
    file_path: Path

    @property
    def compiled_trigger(self) -> re.Pattern | None:
        try:
            return re.compile(self.trigger, re.IGNORECASE)
        except re.error:
            return None


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """Parse YAML-like frontmatter from a markdown file.

    Expected format:
    ---
    name: My Skill
    description: Does something useful
    trigger: /mycommand|some keyword pattern
    ---
    Body content here...

    Returns (frontmatter_dict, body_content).
    """
    text = text.lstrip()
    if not text.startswith("---"):
        return {}, text

    # Find closing ---
    end_idx = text.find("---", 3)
    if end_idx == -1:
        return {}, text

    frontmatter_block = text[3:end_idx].strip()
    body = text[end_idx + 3:].strip()

    # Simple key: value parser (no nested YAML, keeping it dependency-free)
    meta: dict[str, str] = {}
    for line in frontmatter_block.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        colon_idx = line.find(":")
        if colon_idx == -1:
            continue
        key = line[:colon_idx].strip().lower()
        value = line[colon_idx + 1:].strip()
        # Strip surrounding quotes if present
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]
        meta[key] = value

    return meta, body


def load_skills() -> list[Skill]:
    """Load all skill markdown files from ~/.vaal/skills/.

    Each .md file should have frontmatter with name, description, and trigger fields.
    """
    if not SKILLS_DIR.exists():
        return []

    skills: list[Skill] = []

    for skill_path in sorted(SKILLS_DIR.glob("*.md")):
        try:
            text = skill_path.read_text(encoding="utf-8", errors="replace")
            meta, body = _parse_frontmatter(text)

            name = meta.get("name", skill_path.stem)
            description = meta.get("description", "")
            trigger = meta.get("trigger", "")

            if not trigger:
                logger.warning("Skill '%s' has no trigger pattern; skipping", skill_path.name)
                continue

            if not body.strip():
                logger.warning("Skill '%s' has no content body; skipping", skill_path.name)
                continue

            skill = Skill(
                name=name,
                description=description,
                trigger=trigger,
                content=body,
                file_path=skill_path,
            )

            # Validate the regex compiles
            if skill.compiled_trigger is None:
                logger.warning("Skill '%s' has invalid trigger regex '%s'; skipping", name, trigger)
                continue

            skills.append(skill)
            logger.info("Loaded skill: %s (trigger: %s)", name, trigger)

        except OSError as e:
            logger.warning("Failed to read skill file '%s': %s", skill_path.name, e)

    return skills


def match_skill(user_input: str, skills: list[Skill]) -> Skill | None:
    """Find the first skill whose trigger pattern matches the user input.

    Checks for:
    1. Exact slash-command match (e.g., /mycommand)
    2. Regex search against the full input

    Returns the matching Skill or None.
    """
    if not skills or not user_input:
        return None

    user_input_stripped = user_input.strip()

    for skill in skills:
        pattern = skill.compiled_trigger
        if pattern is None:
            continue

        # Try matching
        if pattern.search(user_input_stripped):
            logger.info("Skill '%s' matched input", skill.name)
            return skill

    return None
