"""SSH remote execution -- persistent SSH connections via ControlMaster."""

import subprocess
import os
import time
import tempfile
import signal
from pathlib import Path
from dataclasses import dataclass

from .config import VAAL_DIR

SSH_DIR = VAAL_DIR / "ssh"


@dataclass
class SSHConnection:
    user: str
    host: str
    port: int = 22
    control_path: str = ""
    connected: bool = False
    connected_at: float = 0.0

    @property
    def target(self) -> str:
        return f"{self.user}@{self.host}"

    @property
    def display(self) -> str:
        if self.port != 22:
            return f"{self.user}@{self.host}:{self.port}"
        return self.target


class SSHManager:
    """Manages a persistent SSH connection using ControlMaster."""

    def __init__(self):
        self._connection: SSHConnection | None = None
        SSH_DIR.mkdir(parents=True, exist_ok=True)

    @property
    def connection(self) -> SSHConnection | None:
        return self._connection

    @property
    def is_connected(self) -> bool:
        if not self._connection or not self._connection.connected:
            return False
        # Verify the control socket still works
        return self._check_control_socket()

    def _control_path(self, user: str, host: str, port: int) -> str:
        return str(SSH_DIR / f"ctl-{user}-{host}-{port}")

    def _check_control_socket(self) -> bool:
        """Check if the ControlMaster socket is alive."""
        if not self._connection:
            return False
        try:
            result = subprocess.run(
                [
                    "ssh",
                    "-o", f"ControlPath={self._connection.control_path}",
                    "-O", "check",
                    self._connection.target,
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception:
            return False

    def connect(self, target: str, port: int = 22) -> tuple[bool, str]:
        """Connect to a remote host. target is 'user@host' or 'host'.
        Returns (success, message)."""
        if self._connection and self._connection.connected:
            return False, f"Already connected to {self._connection.display}. Disconnect first."

        # Parse target
        if "@" in target:
            user, host = target.split("@", 1)
        else:
            user = os.environ.get("USER", os.environ.get("USERNAME", "root"))
            host = target

        # Handle host:port notation
        if ":" in host:
            host, port_str = host.rsplit(":", 1)
            try:
                port = int(port_str)
            except ValueError:
                pass

        control_path = self._control_path(user, host, port)

        # Start a ControlMaster connection in the background
        cmd = [
            "ssh",
            "-o", f"ControlPath={control_path}",
            "-o", "ControlMaster=yes",
            "-o", "ControlPersist=600",  # Keep alive for 10 minutes after last use
            "-o", "StrictHostKeyChecking=accept-new",
            "-o", "ConnectTimeout=10",
            "-o", "ServerAliveInterval=30",
            "-o", "ServerAliveCountMax=3",
            "-p", str(port),
            "-N",  # No command, just open the tunnel
            f"{user}@{host}",
        ]

        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            # Wait up to 15 seconds for connection
            try:
                _, stderr = proc.communicate(timeout=15)
                stderr_text = stderr.decode("utf-8", errors="replace").strip() if stderr else ""
                if proc.returncode != 0 and proc.returncode is not None:
                    return False, f"SSH connection failed: {stderr_text or 'unknown error'}"
            except subprocess.TimeoutExpired:
                # The -N process hangs forever (expected for ControlMaster)
                # Check if the socket was actually created
                pass

            # Give a moment for the socket to appear, then verify
            time.sleep(0.5)

            self._connection = SSHConnection(
                user=user,
                host=host,
                port=port,
                control_path=control_path,
                connected=True,
                connected_at=time.time(),
            )

            if self._check_control_socket():
                return True, f"Connected to {self._connection.display}"
            else:
                self._connection = None
                return False, "SSH connection established but control socket verification failed. Check your SSH credentials."

        except FileNotFoundError:
            return False, "ssh command not found. Ensure OpenSSH is installed."
        except Exception as e:
            return False, f"SSH connection error: {e}"

    def run_command(self, command: str, timeout: int = 30) -> tuple[str, int]:
        """Execute a command on the remote host via the persistent connection.
        Returns (output, returncode)."""
        if not self._connection or not self._connection.connected:
            return "[error: not connected. Use /ssh connect <user@host> first]", 1

        if not self._check_control_socket():
            self._connection.connected = False
            return "[error: SSH connection lost. Reconnect with /ssh connect]", 1

        cmd = [
            "ssh",
            "-o", f"ControlPath={self._connection.control_path}",
            "-o", "ControlMaster=no",
            "-p", str(self._connection.port),
            self._connection.target,
            command,
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
            )
            output = result.stdout or ""
            if result.stderr:
                if output:
                    output += "\n"
                output += result.stderr
            return output.strip(), result.returncode
        except subprocess.TimeoutExpired:
            return f"[error: command timed out after {timeout}s]", 1
        except Exception as e:
            return f"[error: {e}]", 1

    def disconnect(self) -> tuple[bool, str]:
        """Disconnect from the remote host."""
        if not self._connection:
            return False, "Not connected."

        display = self._connection.display

        # Send exit command to ControlMaster
        try:
            subprocess.run(
                [
                    "ssh",
                    "-o", f"ControlPath={self._connection.control_path}",
                    "-O", "exit",
                    self._connection.target,
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
        except Exception:
            pass

        # Clean up socket file
        try:
            socket_path = Path(self._connection.control_path)
            if socket_path.exists():
                socket_path.unlink()
        except Exception:
            pass

        self._connection = None
        return True, f"Disconnected from {display}"

    def info(self) -> dict | None:
        """Get info about the current connection."""
        if not self._connection:
            return None
        alive = self._check_control_socket() if self._connection.connected else False
        uptime = time.time() - self._connection.connected_at if self._connection.connected_at else 0
        return {
            "target": self._connection.display,
            "user": self._connection.user,
            "host": self._connection.host,
            "port": self._connection.port,
            "connected": alive,
            "uptime_seconds": int(uptime),
        }


# Module-level singleton
_ssh_manager: SSHManager | None = None


def get_ssh_manager() -> SSHManager:
    global _ssh_manager
    if _ssh_manager is None:
        _ssh_manager = SSHManager()
    return _ssh_manager
