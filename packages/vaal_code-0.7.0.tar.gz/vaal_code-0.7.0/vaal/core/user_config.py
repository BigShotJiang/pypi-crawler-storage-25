"""User configuration — persisted to ~/.vaal/config.json."""

import json
from pathlib import Path
from .config import VAAL_DIR, DEFAULT_MODEL, DEFAULT_PERMISSION_MODE


CONFIG_FILE = VAAL_DIR / "config.json"

_DEFAULTS = {
    "default_model": DEFAULT_MODEL,
    "permission_mode": DEFAULT_PERMISSION_MODE,
    "agent_model": "",  # empty = use main model
    "vim_mode": False,
    "voice_enabled": False,
    "internet_enabled": True,
    "theme": "default",
    "output_style": "default",
    "provider": "ollama",
    "terminal_theme": "vaal",
}


class UserConfig:
    """Load / save user preferences from ~/.vaal/config.json."""

    def __init__(self):
        self._data: dict = dict(_DEFAULTS)
        self.load()

    # ── properties ──────────────────────────────────────────────────

    @property
    def default_model(self) -> str:
        return self._data.get("default_model", _DEFAULTS["default_model"])

    @default_model.setter
    def default_model(self, value: str):
        self._data["default_model"] = value

    @property
    def permission_mode(self) -> str:
        return self._data.get("permission_mode", _DEFAULTS["permission_mode"])

    @permission_mode.setter
    def permission_mode(self, value: str):
        self._data["permission_mode"] = value

    @property
    def vim_mode(self) -> bool:
        return self._data.get("vim_mode", False)

    @vim_mode.setter
    def vim_mode(self, value: bool):
        self._data["vim_mode"] = value

    @property
    def voice_enabled(self) -> bool:
        return self._data.get("voice_enabled", False)

    @voice_enabled.setter
    def voice_enabled(self, value: bool):
        self._data["voice_enabled"] = value

    @property
    def theme(self) -> str:
        return self._data.get("theme", "default")

    @theme.setter
    def theme(self, value: str):
        self._data["theme"] = value

    @property
    def output_style(self) -> str:
        return self._data.get("output_style", "default")

    @output_style.setter
    def output_style(self, value: str):
        self._data["output_style"] = value

    @property
    def internet_enabled(self) -> bool:
        return self._data.get("internet_enabled", True)

    @internet_enabled.setter
    def internet_enabled(self, value: bool):
        self._data["internet_enabled"] = value

    @property
    def agent_model(self) -> str:
        return self._data.get("agent_model", "")

    @agent_model.setter
    def agent_model(self, value: str):
        self._data["agent_model"] = value

    # ── persistence ─────────────────────────────────────────────────

    def load(self):
        """Load config from disk, filling missing keys with defaults."""
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    stored = json.load(f)
                for k, v in _DEFAULTS.items():
                    self._data[k] = stored.get(k, v)
            except (json.JSONDecodeError, OSError):
                self._data = dict(_DEFAULTS)
        else:
            self._data = dict(_DEFAULTS)

    def save(self):
        """Write current config to disk."""
        VAAL_DIR.mkdir(exist_ok=True)
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(self._data, f, indent=2)

    def get(self, key: str, default=None):
        return self._data.get(key, default)

    def set(self, key: str, value):
        self._data[key] = value

    def as_dict(self) -> dict:
        return dict(self._data)
