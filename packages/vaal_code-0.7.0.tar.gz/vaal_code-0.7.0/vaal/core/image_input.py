"""Image input — send images to multimodal LLMs for analysis."""

import base64
import mimetypes
import os
from pathlib import Path

# Supported image extensions
IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}


def is_image_path(text: str) -> bool:
    """Check if text looks like a path to an image file."""
    text = text.strip().strip('"').strip("'")
    if not text:
        return False
    ext = Path(text).suffix.lower()
    return ext in IMAGE_EXTENSIONS


def encode_image(path: str) -> tuple[str, str]:
    """Read and base64-encode an image file.

    Returns (base64_data, media_type) or raises FileNotFoundError / ValueError.
    """
    path = path.strip().strip('"').strip("'")
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"Image not found: {p}")
    if not p.is_file():
        raise ValueError(f"Not a file: {p}")

    ext = p.suffix.lower()
    if ext not in IMAGE_EXTENSIONS:
        raise ValueError(f"Unsupported image format: {ext}")

    # Determine MIME type
    media_type = mimetypes.guess_type(str(p))[0]
    if not media_type:
        mime_map = {
            ".png": "image/png",
            ".jpg": "image/jpeg",
            ".jpeg": "image/jpeg",
            ".gif": "image/gif",
            ".webp": "image/webp",
            ".bmp": "image/bmp",
        }
        media_type = mime_map.get(ext, "image/png")

    data = p.read_bytes()
    b64 = base64.standard_b64encode(data).decode("ascii")
    return b64, media_type


def build_image_message(base64_data: str, media_type: str, prompt: str = "Describe this image.") -> dict:
    """Build a user message with an image content block for Anthropic format.

    Returns a message dict with content as a list of blocks.
    """
    return {
        "role": "user",
        "content": [
            {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": media_type,
                    "data": base64_data,
                },
            },
            {
                "type": "text",
                "text": prompt,
            },
        ],
    }


def build_ollama_image_message(base64_data: str, prompt: str = "Describe this image.") -> dict:
    """Build a user message with an image for Ollama multimodal models.

    Ollama expects images as a list of base64 strings in the message.
    """
    return {
        "role": "user",
        "content": prompt,
        "images": [base64_data],
    }


def get_clipboard_image() -> tuple[str, str] | None:
    """Try to get an image from the system clipboard.

    Returns (base64_data, media_type) or None if no image in clipboard.
    """
    import sys
    import subprocess
    import tempfile

    if sys.platform == "win32":
        # Use PowerShell to check clipboard for image
        try:
            ps_script = (
                "$img = Get-Clipboard -Format Image; "
                "if ($img) { "
                "$ms = New-Object System.IO.MemoryStream; "
                "$img.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); "
                "[Convert]::ToBase64String($ms.ToArray()) "
                "}"
            )
            result = subprocess.run(
                ["powershell", "-Command", ps_script],
                capture_output=True, text=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip(), "image/png"
        except Exception:
            pass

    elif sys.platform == "darwin":
        # macOS: use pngpaste or osascript
        try:
            with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
                tmp_path = tmp.name
            result = subprocess.run(
                ["pngpaste", tmp_path],
                capture_output=True, timeout=10,
            )
            if result.returncode == 0 and os.path.exists(tmp_path):
                data = Path(tmp_path).read_bytes()
                os.unlink(tmp_path)
                if data:
                    return base64.standard_b64encode(data).decode("ascii"), "image/png"
            if os.path.exists(tmp_path):
                os.unlink(tmp_path)
        except (FileNotFoundError, Exception):
            pass

    else:
        # Linux: try xclip
        try:
            result = subprocess.run(
                ["xclip", "-selection", "clipboard", "-t", "image/png", "-o"],
                capture_output=True, timeout=10,
            )
            if result.returncode == 0 and result.stdout:
                return base64.standard_b64encode(result.stdout).decode("ascii"), "image/png"
        except (FileNotFoundError, Exception):
            pass

    return None
