"""Keybinding configuration — loaded from ~/.vaal/keybindings.json."""

import json
from pathlib import Path
from .config import VAAL_DIR


KEYBINDINGS_FILE = VAAL_DIR / "keybindings.json"

DEFAULT_KEYBINDINGS = {
    "ctrl+c": "exit",
    "ctrl+l": "clear_screen",
    "ctrl+k": "clear_conversation",
    "ctrl+r": "search_history",
    "tab": "accept_suggestion",
    "shift+tab": "cycle_permission_mode",
}

# Human-readable descriptions for display
_DESCRIPTIONS = {
    "exit": "Exit vaal",
    "clear_screen": "Clear terminal screen",
    "clear_conversation": "Clear conversation history",
    "search_history": "Search command history",
    "accept_suggestion": "Accept current suggestion",
    "cycle_permission_mode": "Cycle permission mode (ask/auto/yolo)",
}


class KeybindingManager:
    """Manages keybinding configuration."""

    def __init__(self):
        self._bindings: dict[str, str] = dict(DEFAULT_KEYBINDINGS)
        self._load()

    def _load(self):
        """Load keybindings from file, writing defaults on first run."""
        if KEYBINDINGS_FILE.exists():
            try:
                with open(KEYBINDINGS_FILE, "r", encoding="utf-8") as f:
                    stored = json.load(f)
                # Merge: stored overrides defaults, but keep any new defaults
                merged = dict(DEFAULT_KEYBINDINGS)
                merged.update(stored)
                self._bindings = merged
            except (json.JSONDecodeError, OSError):
                self._bindings = dict(DEFAULT_KEYBINDINGS)
                self._save()
        else:
            self._bindings = dict(DEFAULT_KEYBINDINGS)
            self._save()

    def _save(self):
        """Write current keybindings to disk."""
        VAAL_DIR.mkdir(exist_ok=True)
        with open(KEYBINDINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(self._bindings, f, indent=2)

    def lookup(self, key_combo: str) -> str | None:
        """Look up the action for a key combination.

        Returns the action name or None if unbound.
        """
        return self._bindings.get(key_combo.lower())

    def get_key_for_action(self, action: str) -> str | None:
        """Reverse lookup: find the key bound to an action."""
        for key, act in self._bindings.items():
            if act == action:
                return key
        return None

    def set_binding(self, key_combo: str, action: str):
        """Set a keybinding and persist."""
        self._bindings[key_combo.lower()] = action
        self._save()

    def remove_binding(self, key_combo: str):
        """Remove a keybinding and persist."""
        self._bindings.pop(key_combo.lower(), None)
        self._save()

    def all_bindings(self) -> dict[str, str]:
        """Return all current bindings."""
        return dict(self._bindings)

    def format_table(self) -> list[tuple[str, str, str]]:
        """Return list of (key, action, description) for display."""
        rows = []
        for key, action in sorted(self._bindings.items()):
            desc = _DESCRIPTIONS.get(action, action)
            rows.append((key, action, desc))
        return rows
