from pathlib import Path

from canvasapi.course import Course

from ..resources import AnnouncementInfo


def deploy_announcement(course: Course, announcement_info: dict, _: Path) -> tuple[AnnouncementInfo, None]:
    if announcement_id := announcement_info.get('canvas_id'):
        canvas_announcement = course.get_discussion_topic(announcement_id)
        canvas_announcement.update(**announcement_info)

    else:
        canvas_announcement = course.create_discussion_topic(**announcement_info)

    announcement_object_info: AnnouncementInfo = {
        'id': canvas_announcement.id,
        'title': canvas_announcement.title,
        'uri': f'/courses/{course.id}/discussion_topics/{canvas_announcement.id}',

        # Following fields have been observed to be missing in some cases
        'url': getattr(canvas_announcement, 'html_url', None)
    }

    return announcement_object_info, None
