from pathlib import Path

from canvasapi.course import Course

from ..resources import AssignmentGroupInfo


def deploy_group(course: Course, group_data: dict, _: Path) -> tuple[AssignmentGroupInfo, None]:
    if group_id := group_data.get('canvas_id'):
        group = course.get_assignment_group(group_id)
    else:
        group = course.create_assignment_group(name=group_data["name"])

    group.edit(**group_data)
    if group_data.get('rules'):
        course.update(course={
            'apply_assignment_group_weights': True,
        })

    group_object_info: AssignmentGroupInfo = {
        'id': group.id
    }

    return group_object_info, None
