import unittest

from sheaftask import TaskSpec, execution_order, ready_tasks, validate_tasks


class TaskTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tasks = [
            TaskSpec("collect", priority=2),
            TaskSpec("normalize", depends_on=("collect",), priority=1),
            TaskSpec("report", depends_on=("normalize",), priority=1),
        ]

    def test_validate_tasks_rejects_missing_dependencies(self) -> None:
        with self.assertRaises(ValueError):
            validate_tasks([TaskSpec("report", depends_on=("missing",))])

    def test_ready_tasks(self) -> None:
        ready = ready_tasks(self.tasks, completed={"collect"})
        self.assertEqual([task.key for task in ready], ["normalize"])

    def test_execution_order(self) -> None:
        self.assertEqual(execution_order(self.tasks), ["collect", "normalize", "report"])


if __name__ == "__main__":
    unittest.main()

