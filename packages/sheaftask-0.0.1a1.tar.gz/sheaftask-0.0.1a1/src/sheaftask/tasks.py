from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class TaskSpec:
    key: str
    depends_on: tuple[str, ...] = ()
    priority: int = 0
    tags: tuple[str, ...] = ()


def validate_tasks(tasks: list[TaskSpec]) -> None:
    keys = [task.key for task in tasks]
    if len(keys) != len(set(keys)):
        raise ValueError("task keys must be unique")

    known = set(keys)
    for task in tasks:
        missing = set(task.depends_on) - known
        if missing:
            raise ValueError(f"unknown dependencies for {task.key}: {sorted(missing)}")


def ready_tasks(tasks: list[TaskSpec], *, completed: set[str]) -> list[TaskSpec]:
    validate_tasks(tasks)
    return sorted(
        [
            task
            for task in tasks
            if task.key not in completed and set(task.depends_on).issubset(completed)
        ],
        key=lambda task: (-task.priority, task.key),
    )


def execution_order(tasks: list[TaskSpec]) -> list[str]:
    validate_tasks(tasks)
    completed: set[str] = set()
    order: list[str] = []

    while len(completed) < len(tasks):
        ready = ready_tasks(tasks, completed=completed)
        if not ready:
            raise ValueError("task graph contains a cycle")
        task = ready[0]
        completed.add(task.key)
        order.append(task.key)

    return order

