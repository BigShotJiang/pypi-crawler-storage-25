def project_info() -> dict[str, str]:
    return {
        "name": "sheaftask",
        "stage": "bootstrap",
        "homepage": "https://sheaflab.com",
        "repository": "https://github.com/SheafLab/sheaftask-python",
    }

