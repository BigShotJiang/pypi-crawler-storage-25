# sheaftask

`sheaftask` is the official Python package namespace for lightweight task-graph
planning helpers used by the SheafLab project.

This initial public release exposes a small but real surface: defining task
specs, validating dependency references, computing ready tasks, and generating
a deterministic execution order for compact task sets.

## Install

```bash
pip install sheaftask
```

## Usage

```python
from sheaftask import TaskSpec, execution_order, ready_tasks

tasks = [
    TaskSpec("collect", priority=2),
    TaskSpec("normalize", depends_on=("collect",), priority=1),
    TaskSpec("report", depends_on=("normalize",), priority=1),
]

order = execution_order(tasks)
ready = ready_tasks(tasks, completed={"collect"})
```

## Status

- Project stage: pre-alpha
- Package scope: bootstrap task-planning utilities only
- Main project site: https://sheaflab.com

