# opentrash

> Cloud-native geospatial tools for residential waste operations.

!!! note "Work in progress"
    This documentation site is being built lesson by lesson alongside the
    package itself. Right now it's a skeleton — check back as the project grows.

`opentrash` is an open source Python package for analyzing residential solid
waste collection operations using GPS telematics, enterprise waste-management
data, and municipal parcel layers.

## What it does

**RouteView** — given one route and one day, produces a self-contained
interactive HTML map: route polygon, GPS trail, landfill tips, parcels served
vs missed, and tonnage delivered.

**Patterns** — given a long GPS history, detects each parcel's weekly and
biweekly service signature. An optional companion to RouteView.

## Installation

```bash
pip install opentrash
```

!!! warning
    The package is at version `0.0.0` (name placeholder). It is not yet
    functional. Follow the project to know when the first usable release lands.

## Learn how it's built

Want to understand how this package is built from scratch? There's a full
course that walks through it lesson by lesson. See the course hub (link to be
added).

## About

`opentrash` is an open source project under
[AI Research Corps (AIRC)](https://airesearchcorps.org/), a 501(c)(3) nonprofit.

Source-available under a non-commercial license.
