"""opentrash — cloud-native geospatial tools for residential waste operations.

This package is being built lesson by lesson. At Phase 0 it is an empty
skeleton; each lesson adds a module (core, prep, tonnage, patterns, routeview,
and so on). See the course hub for the lesson series.
"""

__version__ = "0.0.0"
