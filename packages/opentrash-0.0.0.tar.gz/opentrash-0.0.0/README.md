# opentrash

> Cloud-native geospatial tools for residential waste operations.

`opentrash` is an open source Python package for analyzing residential solid
waste collection operations using GPS telematics, enterprise waste-management
data, and municipal parcel layers. It produces **RouteView** — a self-contained
interactive HTML map for any route on any day — and detects per-parcel weekly
and biweekly service **patterns** over time.

The same tools enterprise fleet software sells for six figures, built on open
standards and open data, runnable on a laptop.

## Status

🚧 **Phase 0 — skeleton.** Version `0.0.0` is a name placeholder; the package is
not yet functional. It is being built lesson by lesson alongside its
documentation site and a public course.

## What it will do

- **RouteView** — one route + one day → an interactive HTML map (route polygon,
  GPS trail, landfill tips, parcels served vs missed, tonnage).
- **Patterns** — long GPS history → per-parcel weekly/biweekly service
  signatures, as a portable parquet file RouteView can optionally consume.

## Roadmap

- **RouteEdit** — interactive route-editing tool, sister to RouteView.
- **Sample synthetic data** — redistributable dataset for tutorials.
- **Cloud-hosted demo** — publicly browsable RouteView instance.
- **Hardware integrations** — RFID container reader, vehicle LiDAR.

## Documentation

The documentation site is built with MkDocs Material and deployed to GitHub
Pages. To preview locally:

```bash
pip install mkdocs-material
mkdocs serve
```

## Development

```bash
conda create -n opentrash python=3.11 -y
conda activate opentrash
pip install -e ".[dev,docs]"
```

## License

Source-available under a non-commercial license. See [LICENSE](LICENSE).
Commercial licensing inquiries: contact AIRC.

## About

An open source project under
[AI Research Corps (AIRC)](https://airesearchcorps.org/), a 501(c)(3) nonprofit.
