# Security Policy

`mgf-django` is a federation sibling of [`mgf-common`](https://pypi.org/project/mgf-common/),
shipping Django integration adapters (AppConfig, request-id +
context middleware, JsonFormatter, DjangoSettingsBridge). A
vulnerability here may affect every Django consumer that
depends on it, so we take security reports seriously.

## Supported versions

In the 0.x window, **only the latest MINOR receives security
patches.** Per [SemVer 0.x](https://semver.org/#spec-item-4) and
rule **AP-03** from `mgf-common/docs/standards/API_DESIGN.md`,
each MINOR release MAY break the public API; we do not
branch-and-backport across minors. Security fixes ship as the
next PATCH on the latest MINOR.

| Version | Supported |
|---------|-----------|
| `0.2.x`  | ✅ — latest MINOR; security patches ship as `0.2.Y` |
| `< 0.2`  | ❌ — pre-publish development; upgrade to `0.2.x` |

When a security fix lands, the [`CHANGELOG.md`](CHANGELOG.md)
entry for the fixing release names the affected versions and
the upgrade path.

## Reporting a vulnerability

**Please do not open a public issue or pull request** until we have
had a chance to triage and patch.

To report a vulnerability privately, choose one of:

- **Email:** `bassam.alsanie@gmail.com` with subject prefix
  `[mgf-django security]`.
- **Codeberg private security advisory:** open a private
  vulnerability report via
  [the repository's Security tab](https://codeberg.org/magogi-admin/mgf-django/security).

### What to include

- A description of the vulnerability and its impact.
- Steps to reproduce — a minimal failing test or shell transcript
  is ideal.
- The version(s) of `mgf-django` affected, plus the pinned
  `mgf-common` and `django` versions.
- Python version + OS.
- Any suggested mitigations or patches you have in mind.

### What to expect

| Stage | Timeline |
|---|---|
| Acknowledgement | within 3 business days |
| Initial assessment + severity rating | within 7 business days |
| Patch + release | within 30 days for high-severity, 90 days for medium |
| Credit + public disclosure | coordinated with the reporter |

We follow a **90-day default embargo**, extendable by mutual
agreement if a patch is not yet ready. After the embargo expires
(or after a patch ships, whichever is first), the vulnerability is
disclosed in the [`CHANGELOG.md`](CHANGELOG.md) entry for the
fixing release, with credit to the reporter unless declined.

## Scope

**In scope:**

- Code in `src/mgf/django/` (the published `mgf-django` package).
- Build / release infrastructure (`pyproject.toml`, the manual
  release flow specified in
  [`mgf-common/docs/standards/RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md)).

**Out of scope:**

- Vulnerabilities in `mgf-common` itself — report to
  [`mgf-common/SECURITY.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/SECURITY.md).
- Vulnerabilities in `django` or its dependencies — report to
  the [Django security team](https://docs.djangoproject.com/en/stable/internals/security/)
  or the upstream project; we bump pins as soon as a patched
  release is available.
- Vulnerabilities in a consumer's own Django project that do
  not stem from `mgf-django` code — please report there.
- Self-inflicted DoS (e.g., running with `DEBUG = True` in
  production).

## Hardening recommendations for consumers

Consumers of `mgf-django` adopt the
[`mgf-common/docs/standards/SECURITY_STANDARD.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/SECURITY_STANDARD.md)
engineering standard as their baseline. The Rules box at the top
of that document is the bar; the §15 mechanical-enforcement matrix
is the contract for what every consumer's CI should check.
Web-specific overlays (request-id propagation, CSRF + CORS
posture, session-cookie security headers) live in
[`mgf-common/docs/standards/web/`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/web/).

## A note on the standards

`mgf-django` is a **federation sibling** under the project-shape
taxonomy from
[`mgf-common/docs/standards/DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) §2.0.
The cross-project engineering standards live in `mgf-common`; this
project inherits them. See [`docs/standards/README.md`](docs/standards/README.md)
for the pointer.
