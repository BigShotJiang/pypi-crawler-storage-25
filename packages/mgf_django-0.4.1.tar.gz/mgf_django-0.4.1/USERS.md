# USERS — who depends on mgf-django

> **Purpose:** mgf-django's user roll. Lists every consumer project and
> federation sibling that imports `mgf.django.*`.
> **Maintained by:** the mgf-common owner (Bassam — mgf-common owns the
> federation per the one-big-library mindset).
> **Per standard DOC-16** (v2.9): every `mgf-*` library MUST maintain a
> `USERS.md` at repo root.

Last verified: 2026-05-18 (post-mgf-django v0.4.0 release with
ThrottleMiddleware).

---

## §1 Consumer projects (external users)

| Project        | Location                                  | Import sites | Status                                | Surfaces used  |
|----------------|-------------------------------------------|-------------:|---------------------------------------|----------------|
| **inthewords** | `/home/bassam/PycharmProjects/inthewords` | 0 *(planned)* | Planned adoption — pinned to mgf-common 0.31 today | n/a yet         |

**Zero-consumer reality (today).** mgf-django is shipped but has **no
runtime adopters yet**. inthewords is the only candidate consumer; it's
pinned to mgf-common 0.31 and hasn't picked up mgf-django middleware /
helpers yet.

**Why ship without adopters?** mgf-django was extracted from mgf-common
preemptively per the "split adapters by runtime shape" federation rule
(see `feedback_split_by_runtime_shape` memory). It lives so that when
inthewords does adopt Django-specific helpers, the surface is already
there.

mgf-django is also **not yet on PyPI** (blocker B-1 in
`docs/inprogress/pre_release_check.md` — first-publish gated on token
availability + private PyPI server setup).

---

## §2 Federation siblings (`mgf-*` libraries)

No siblings depend on mgf-django today. It is leaf-only.

---

## §3 What a "user" change MUST trigger

See [`../mgf_common/USERS.md`](../mgf_common/USERS.md) §3. The current
zero-consumer status gives mgf-django freedom to break shape until the
first adopter pins it — this is deliberate, not a problem.

When inthewords adopts the throttle middleware (the most likely first
adoption), update this table and verify their `MGF_ADOPTION.md`
declares the new dependency.

---

## §4 How this list is maintained

```sh
for proj in VManager inthewords PlasmaMapper iosRecovery; do
  grep -rE "(from|import) +mgf\.django" "/home/bassam/PycharmProjects/$proj" \
    --include='*.py' | wc -l
done
```

Re-run before each MINOR release. The first non-zero count flips
mgf-django from "preemptive surface" to "real library with users".
