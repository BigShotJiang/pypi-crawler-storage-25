# Public API — `mgf-django`

> ⚠️ **This file documents `master` HEAD.** Names listed here may
> be unreleased. To learn what your installed wheel actually
> ships, run `pip show mgf-django` and compare against the git tag
> matching the published version.

This document is the **contract list** for `mgf-django`. Every name
listed below is a public name that consumers MAY depend on.

The contract terms are defined in
[`mgf-common/docs/standards/API_DESIGN.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/API_DESIGN.md). In
short:

- **Stability tiers:**
  - `experimental` — MAY change shape in any MINOR release
    (the 0.x window keeps everything experimental in practice).
  - `stable` — follows the deprecation cycle; removal only in MAJOR.
  - `deprecated` — slated for removal; emits `DeprecationWarning`.
- **Names not listed below are private.** Anything starting with
  `_` (underscore-prefixed module names like `_apps.py`) is
  internal and MAY change without notice.
- **The 0.x window applies.** Per [SemVer](https://semver.org/) 0.x
  semantics, MINOR releases MAY break the public API. Pin tightly:
  `mgf-django = ">=0.X.0,<0.Y"`.

---

## `mgf.django`

Top-level Django integration adapters. Closed-box: depends on
`mgf-common` + `django` only.

| Name | Tier | Description |
|---|---|---|
| `MgfCommonConfig` | experimental | Django `AppConfig` subclass. `name = "mgf.django"`, `label = "mgf_django"`. `ready()` calls `mgf.common.bootstrap()` exactly once per process via a module-level guard. Idempotent across re-imports (test `override_settings`, autoreload). `atexit` hook unwinds the bootstrap stack on shutdown. |
| `MgfRequestIdMiddleware` | experimental | Sync-mode Django middleware. Injects/forwards `X-Request-Id` per request (UUID4 generated when missing). Sets `request.mgf_request_id` for view access. Echoes the id in the response. Shares the `mgf.common._request_id` contextvar with `mgf.fastapi.RequestIdMiddleware` for end-to-end Django↔FastAPI correlation. |
| `MgfContextMiddleware` | experimental | Sync-mode Django middleware. Exposes `mgf.common.current_context()` on `request.mgf_context`. Install AFTER `MgfRequestIdMiddleware`. Falls back to `request.mgf_context = None` if bootstrap hasn't run. |
| `JsonFormatter` | experimental | No-arg wrapper around `mgf.common.observability.JsonFormatter`. Compatible with Django's `LOGGING['formatters']` `'()': '...'` factory syntax. Same redaction + OTel correlation as the underlying formatter. |
| `DjangoSettingsBridge` | experimental | Read-only `BaseAppSettings`-compatible snapshot of `django.conf.settings`. Construct via `DjangoSettingsBridge.from_django()`. Exposes: `debug`, `allowed_hosts`, `installed_apps`, `time_zone`, `use_tz`, `language_code`, `secret_key_present` (boolean — the key itself is NEVER carried), `mgf_app_name`, `mgf_app_version`. |

### Behaviours guaranteed at the public surface

- `MgfCommonConfig.ready()` calls `mgf.common.bootstrap()` exactly
  once per process. Multiple `ready()` calls are no-ops.
- `MgfRequestIdMiddleware` and `mgf.fastapi.RequestIdMiddleware`
  share the same contextvar, so a Django app that calls a FastAPI
  service via internal RPC propagates the same request id
  end-to-end (assuming the upstream call sets the header).
- `MgfContextMiddleware` MUST install AFTER
  `MgfRequestIdMiddleware` so the request id is bound to the
  contextvar before the view runs.
- `DjangoSettingsBridge.from_django()` snapshots Django settings
  at construction time. Mutation of `django.conf.settings` after
  construction (rare in production, occasional in tests via
  `override_settings`) is NOT reflected — construct a fresh bridge.
- `DjangoSettingsBridge` MUST NOT carry `SECRET_KEY` itself.
  `secret_key_present` is the only signal; dumping the bridge
  (`model_dump_json`) MUST NOT expose the secret.

---

## App label

The Django app label is `"mgf_django"` (Django labels can't
contain dots, so the package can't be its own label). **Renamed at
the v0.31 sibling extraction** from `"mgf_common"` (its name when
the module lived under `mgf.common.django` in mgf-common ≤ v0.30).

This is a runtime BREAKING change for any Django consumer that
hardcoded `"mgf_common"`. Typical references:

```python
from django.apps import apps

# Old (mgf-common ≤ v0.30):
config = apps.get_app_config("mgf_common")

# New (mgf-django v0.1+):
config = apps.get_app_config("mgf_django")
```

The label is also visible in admin URLs (`/admin/mgf_django/...`),
migration filenames, and any code that reads
`AppConfig.label` programmatically.

---

## What stays in `mgf-common`, NOT here

- **`AppError`, `OperationError`, `ConfigError`** and the rest of
  the typed exception hierarchy — `mgf.common.exceptions`.
- **`bootstrap`, `app_name`, `app_version`, `current_context`,
  `current_request_id`** — `mgf.common`.
- **`BaseAppSettings`, `MgfSettings`, `settings_config`** —
  `mgf.common.config` / `mgf.common.settings`.
- **`Redactor`, `JsonFormatter` (the base class)** —
  `mgf.common.observability`.

`mgf-django` reaches into `mgf.common._request_id` (a contextvar
shared across all framework siblings for request-id correlation);
that's a deliberate exception to the closed-box rule, mirrored in
`mgf.fastapi._request_id`. Otherwise, the sibling consumes
mgf-common only through its public surface.

The runtime dep is `mgf-common>=0.31,<0.32`.
