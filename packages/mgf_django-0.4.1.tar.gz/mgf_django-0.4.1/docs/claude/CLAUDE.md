# mgf-django — Claude Reference

Dense lookup document. No prose. Facts only.

> **See also:** [`mgf-common/docs/claude/CLAUDE.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/claude/CLAUDE.md)
> — cornerstone reference shared across the federation. The
> cross-cutting patterns (atomic-write, never-raises observers,
> redaction layering) documented there apply to this sibling
> too. THIS file is the mgf-django-specific addenda.

---

## Project shape

- **Federation sibling** of `mgf-common` (per
  [`DOCUMENTATION.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/DOCUMENTATION.md) §2.0).
- **Conformance target:** L2 — inherited via
  `mgf-common>=0.33,<0.34`.
- **PyPI:** `mgf-django` (first published at v0.2.0;
  v0.1.0 was prepped but never published — see
  [`CHANGELOG.md`](../../CHANGELOG.md) for the rationale).
- **Codeberg:** `magogi-admin/mgf-django`; default branch `main`.

## File map (where things live)

| Path | Purpose |
|---|---|
| `src/mgf/django/__init__.py` | Re-exports the 5 public names from `_apps.py` / `_middleware.py` / `_logging.py` / `_settings.py`. PEP 420 namespace package — no top-level `mgf/__init__.py`. |
| `src/mgf/django/apps.py` | Imports `MgfCommonConfig` from `_apps.py` so Django's `INSTALLED_APPS` discovery (which walks for `apps.py` per package) finds it. Both `mgf.django.MgfCommonConfig` and `apps.py`-side import work; the canonical name is the dotted re-export. |
| `src/mgf/django/_apps.py` | `MgfCommonConfig(AppConfig)` — `ready()` calls `mgf.common.bootstrap()` exactly once per process via a module-level guard; `atexit` hook unwinds the bootstrap stack on shutdown. |
| `src/mgf/django/_middleware.py` | `MgfRequestIdMiddleware` + `MgfContextMiddleware` — sync-mode Django middleware. Shares the `mgf.common._request_id` contextvar with `mgf.fastapi.RequestIdMiddleware`. |
| `src/mgf/django/_logging.py` | `JsonFormatter` no-arg wrapper around `mgf.common.observability.JsonFormatter` for Django `LOGGING['formatters']`. |
| `src/mgf/django/_settings.py` | `DjangoSettingsBridge` — read-only `BaseAppSettings`-compatible snapshot of `django.conf.settings`. NEVER carries `SECRET_KEY` itself; exposes `secret_key_present` boolean only. |
| `PUBLIC_API.md` | Contract list — every public name with stability tier + description (per **AP-10**). |
| `CHANGELOG.md` | Per-release record (Keep a Changelog format). |
| `SECURITY.md` | Vulnerability-reporting policy (per **SC-12**). |
| `docs/standards/README.md` | Pointer-only stub — points at `mgf-common/docs/standards/`. NOT a duplicate. |
| `docs/cutover/v0.1.0.md` | Maiden-voyage migration guide (the rename from `mgf.common.django.*` → `mgf.django.*`). |
| `docs/recipes/django.md` | Full Django-settings.py walkthrough. |

## Cross-cutting patterns

1. **Bootstrap exactly once.** `MgfCommonConfig.ready()` calls
   `mgf.common.bootstrap()` with a module-level
   `_BOOTSTRAP_DONE` guard. Multiple `ready()` calls (Django's
   `override_settings`, the autoreloader, the test runner) are
   no-ops. The `atexit` hook unwinds the bootstrap stack on
   shutdown.

2. **Request-id sharing.** `MgfRequestIdMiddleware` reads/sets
   the same `mgf.common._request_id` contextvar that
   `mgf.fastapi.RequestIdMiddleware` uses. A Django app that
   makes an internal RPC to a FastAPI service (or vice versa)
   propagates the same `X-Request-Id` end-to-end, ASSUMING the
   upstream call sets the header.

3. **Middleware install order.** `MgfRequestIdMiddleware` MUST
   come BEFORE `MgfContextMiddleware` so the request id is
   bound to the contextvar before the context middleware
   resolves the active `AppContext`.

4. **Django app label = `mgf_django`** (not `mgf.django`).
   Django labels can't contain dots; the package previously
   used `mgf_common` as a stable label, but at the v0.1
   sibling extraction the label moved to `mgf_django` to match
   the new module path. Any consumer config that hardcoded
   `apps.get_app_config("mgf_common")` MUST update to
   `"mgf_django"`.

5. **`DjangoSettingsBridge` snapshots at construction time.**
   Mutation of `django.conf.settings` after the bridge is
   constructed (rare in production, occasional in tests via
   `override_settings`) is NOT reflected — construct a fresh
   bridge.

## Build and release

The canonical sequence per
[`mgf-common/docs/standards/RELEASING.md`](https://codeberg.org/magogi-admin/mgf_common/src/branch/main/docs/standards/RELEASING.md):

1. Bump `version` in `pyproject.toml`.
2. Add the `[X.Y.Z] — YYYY-MM-DD` entry in `CHANGELOG.md` in
   the same commit.
3. Update `PUBLIC_API.md` if the public surface changed
   (validated by `tests/unit/test_public_api_doc.py` against
   `__all__`).
4. Run the full test suite locally (`pytest`).
5. Run `mypy --strict src/mgf/django/`.
6. Build: `uv build`.
7. `twine check dist/*` — both wheel and sdist MUST pass.
8. Commit (`chore: cut vX.Y.Z`).
9. Tag annotated: `git tag -a vX.Y.Z -m '...'`.
10. Push commit + tag: `git push origin main && git push origin vX.Y.Z`.
11. Upload: `twine upload dist/*`.
12. Post-publish smoke: `pip install --upgrade mgf-django==X.Y.Z`
    in a clean venv; import every public name.

## Common pitfalls

- **Forgetting to add `mgf.django` to `INSTALLED_APPS`.** The
  middleware works (the contextvar exists at import time) but
  `bootstrap()` never runs — `mgf-common` features that depend
  on it (OTel correlation, crash reporter, redactor) silently
  no-op. Symptom: log records have no `trace_id`/`span_id`.
- **Middleware order swapped.** `MgfContextMiddleware` BEFORE
  `MgfRequestIdMiddleware` → context resolves before the
  request id is bound → context's request-id field is `None`.
- **Bridge cached at module top.** A consumer that does
  `BRIDGE = DjangoSettingsBridge.from_django()` at module-load
  time captures `django.conf.settings` BEFORE Django's
  settings loader runs in some test arrangements. Construct
  per-request or per-test instead.
- **Async views.** All three middleware are sync-mode only.
  Mixed sync/async middleware in Django requires the
  `async_capable = True` flag, which `MgfRequestIdMiddleware`
  + `MgfContextMiddleware` do NOT set. Pin a future-async-shape
  upgrade behind a feature flag.

## Recently-touched areas

(Rolling list, last N changes. Update on every commit that
changes a load-bearing fact.)

- **v0.2.0 prep (2026-05-15)** — added v2.6/v2.7 compliance
  files (this CLAUDE.md + SECURITY.md + docs/standards/README.md
  pointer); bumped mgf-common pin >=0.33,<0.34 (in v0.1.0 prep
  commit `d07c20e`); v0.1.0 tag deleted in favour of v0.2.0
  as the maiden publish.
- **v0.1.0 extraction (2026-05-10)** — initial extraction
  from `mgf-common[django]` per the federation split plan.
  Five public names; 18 unit tests at parity with the
  pre-extraction shape.

---

*Last updated: 2026-05-15.*
