"""PC-04: ``JsonFormatter`` ``Redactor`` construction cost pin.

Django's ``LOGGING['formatters']`` config wires one formatter, so
the cost is one-shot per process — but test runs that re-init
Django repeatedly (pytest-django with ``override_settings(LOGGING=...)``
blocks) build N redactors. A regression in
``Redactor.default()`` allocation cost (e.g., a pattern table that
grows from 50 to 5000 entries) would slow the test suite without
showing up in production telemetry.

Pin: ``JsonFormatter()`` construction stays under 2 ms median across
20 iterations. Local: ~50-200 µs.

Marker: ``perf``. Run via ``pytest -m perf``.
"""

from __future__ import annotations

import statistics
import time

import pytest

from mgf.django import JsonFormatter

pytestmark = pytest.mark.perf

_ITERATIONS = 20
_PER_CONSTRUCT_BUDGET_MS = 2.0


def test_jsonformatter_construction_under_budget() -> None:
    # Warm-up: load the Redactor module's cached default rules.
    JsonFormatter()

    durations_ms: list[float] = []
    for _ in range(_ITERATIONS):
        start = time.perf_counter()
        JsonFormatter()
        durations_ms.append((time.perf_counter() - start) * 1000.0)

    median_ms = statistics.median(durations_ms)

    assert median_ms < _PER_CONSTRUCT_BUDGET_MS, (
        f"PC-04: JsonFormatter() construction median is "
        f"{median_ms:.2f} ms (budget {_PER_CONSTRUCT_BUDGET_MS:.1f} ms). "
        f"A regression in Redactor.default() allocation would push "
        f"this up. Test suites that re-init Django repeatedly would "
        f"feel this as overall suite slowdown."
    )
