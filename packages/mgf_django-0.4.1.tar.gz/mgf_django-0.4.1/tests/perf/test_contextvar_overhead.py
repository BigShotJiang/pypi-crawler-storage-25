"""PC-05: ``_REQUEST_ID_VAR.set / .reset`` overhead pin.

PEP 567 contextvars are fast (sub-µs per op on CPython) but not
free. The `MgfRequestIdMiddleware` per-request critical section
calls `_REQUEST_ID_VAR.set(request_id)` + `.reset(token)` once
per request. For a 1000 req/s app, that's 2000 contextvar ops
per second on this code path; a regression that adds even 1 µs
each compounds.

Pin: set+reset combined stays under 5 µs/iteration. Local: sub-µs.

Marker: ``perf``. Run via ``pytest -m perf``.
"""

from __future__ import annotations

import time

import pytest

from mgf.django._middleware import _REQUEST_ID_VAR

pytestmark = pytest.mark.perf

_ITERATIONS = 100_000
_SET_RESET_BUDGET_US = 5.0


def test_contextvar_set_reset_under_budget() -> None:
    # Warm-up: prime any CPython internals.
    token = _REQUEST_ID_VAR.set("warmup")
    _REQUEST_ID_VAR.reset(token)

    start = time.perf_counter()
    for i in range(_ITERATIONS):
        token = _REQUEST_ID_VAR.set(f"req-{i}")
        _REQUEST_ID_VAR.reset(token)
    elapsed_s = time.perf_counter() - start
    per_iter_us = (elapsed_s / _ITERATIONS) * 1e6

    assert per_iter_us < _SET_RESET_BUDGET_US, (
        f"PC-05: contextvar set+reset overhead is {per_iter_us:.2f} µs/iter "
        f"(budget {_SET_RESET_BUDGET_US:.1f} µs). At 1000 req/s this is "
        f"{per_iter_us * 1000:.0f} µs of per-second context overhead. A "
        f"regression here usually means a CPython upgrade flipped the "
        f"contextvar fast path off, or someone added stack-walking to "
        f"the var. Investigate."
    )
