"""Pytest config for the mgf.django perf tests.

Configures Django settings before any mgf.django imports happen
inside the perf tests. The settings here are **byte-identical**
to `tests/unit/conftest.py`'s configure call (including
`MGF_COMMON_APP_NAME="test-app"`) — when both conftests run in
the same session, whichever fires `pytest_configure` first wins,
and the OTHER must short-circuit on the `configured` guard. If
the perf-conftest's settings drifted from the unit-conftest's,
unit tests asserting on `app_name == "test-app"` would fail
when run together with perf tests. Drift detection: any change
here should mirror `tests/unit/conftest.py`.

Omits the unit-test-specific autouse fixtures (those exist to
reset state between functional cases; perf tests measure raw
cost and don't need re-bootstrap).
"""

from __future__ import annotations


def pytest_configure(config):
    import django
    from django.conf import settings as django_settings

    if django_settings.configured:
        return

    django_settings.configure(
        DEBUG=False,
        SECRET_KEY="test-secret-key-not-for-production",
        ALLOWED_HOSTS=["*"],
        INSTALLED_APPS=[
            "django.contrib.contenttypes",
            "django.contrib.auth",
            "mgf.django",
        ],
        DATABASES={
            "default": {
                "ENGINE": "django.db.backends.sqlite3",
                "NAME": ":memory:",
            },
        },
        TIME_ZONE="UTC",
        USE_TZ=True,
        LANGUAGE_CODE="en-us",
        ROOT_URLCONF="tests.unit._urls",
        MIDDLEWARE=[
            "mgf.django.MgfRequestIdMiddleware",
            "mgf.django.MgfContextMiddleware",
        ],
        MGF_COMMON_APP_NAME="test-app",
        MGF_COMMON_APP_VERSION="0.0.1",
    )
    django.setup()
