# imansur-ytb

A professional, modular AI pipeline for high-quality YouTube media ingestion and technical translation.

## Philosophy: Modular Pipeline Architecture
This library is designed as a series of **independent pipeline components**. Each module is decoupled, meaning you can use the downloader without the translator, or provide your own transcripts to the translation engine.

## Installation

```bash
pip install imansur-ytb
```

## Module 1: Media (The Collector)
Handles media downloading with zero-touch FFmpeg management.

```python
from imansur_ytb import get_video

# Returns a list of metadata dictionaries containing file paths
media_list = get_video("https://youtube.com/watch?v=...", audio_only=True)
```

## Module 2: Translator (The Intelligence)
A standalone technical translation engine optimized for English-to-Turkish dubbing scripts. It features **AI Term Discovery** and persistent SQLite memory.

```python
from imansur_ytb import translate_transcript

# Use as a standalone tool for any transcript JSON
translated_data = translate_transcript(
    transcript_path="my_transcript.json",
    api_key="YOUR_GEMINI_KEY", # or set GEMINI_API_KEY in .env
    verbose=True
)
```

### Key Features of Module 2:
- **Zero-Config .env Support**: Automatically picks up `GEMINI_API_KEY`.
- **SQLite Glossary**: Ships with a default 1300+ term technical dictionary.
- **Auto-Learning**: Discovers new terms during translation and updates the local glossary.
- **Consistency**: Uses a double-pass AI logic to ensure terminology remains consistent across the entire transcript.

## Parameter Reference

### `translate_transcript(...)`
| Parameter | Type | Default | Description |
| :--- | :--- | :--- | :--- |
| `transcript_path` | `str` | *Required* | Path to the input JSON transcript |
| `api_key` | `str` | `None` | Gemini API Key (Will check `.env` if None) |
| `model` | `str` | `"gemini-2.0-flash"` | AI Model (Optimized for Flash) |
## Module 3: Synthesis (The Voice)
Converts text or transcripts to high-quality neural speech using `edge-tts`.

```python
from imansur_ytb import synthesize_text, synthesize_transcript

# 1. Simple TTS (for PBX/Switchboard)
synthesize_text("Hoş geldiniz!", "welcome.mp3", voice="tr-TR-AhmetNeural")

# 2. Pipeline Dubbing (Timed & Synced)
synthesize_transcript("tr_transcript.json", output_file="full_dub.mp3", verbose=True)
```

### Key Features of Module 3:
- **Free & Unlimited**: No API tokens required (uses Microsoft Edge TTS).
- **Auto-Sync**: Automatically calculates if a segment needs to be sped up to fit the video timing.
- **Timed Merging**: Uses FFmpeg to place audio segments at exact timestamps with correct silences.

---
*Developed by imansur - Building the future of AI Dubbing.*
