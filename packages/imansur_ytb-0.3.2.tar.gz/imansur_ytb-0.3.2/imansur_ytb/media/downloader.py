"""
YTDub Ingestor Module - Standalone YouTube Downloader
Part of the YTDub AI Pipeline.
"""

import os
import json
import yt_dlp
import re
import ssl
import certifi
import requests
import warnings

# Nuclear SSL Fix: Monkeypatch requests to disable verification globally
# This is required for environments where SSL certificates are completely broken (e.g., some Mac Python 3.14 builds)
from requests.packages.urllib3.exceptions import InsecureRequestWarning
warnings.simplefilter('ignore', InsecureRequestWarning)

original_get = requests.get
def patched_get(*args, **kwargs):
    kwargs['verify'] = False
    return original_get(*args, **kwargs)
requests.get = patched_get

# Also patch Session to be sure
original_session_request = requests.Session.request
def patched_session_request(self, *args, **kwargs):
    kwargs['verify'] = False
    return original_session_request(self, *args, **kwargs)
requests.Session.request = patched_session_request

# Universal SSL Fix (Fallback for other libraries)
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context

import static_ffmpeg
from static_ffmpeg import run as static_ffmpeg_run
from youtube_transcript_api import YouTubeTranscriptApi

# Initialize zero-touch FFmpeg dependency management and get paths
ffmpeg_path, _ = static_ffmpeg_run.get_or_fetch_platform_executables_else_raise()
ffmpeg_dir = os.path.dirname(ffmpeg_path)

# Ensure FFmpeg has executable permissions (Crucial for macOS/Linux)
try:
    os.chmod(ffmpeg_path, 0o755)
except Exception:
    pass

def sanitize_filename(filename):
    """
    Remove invalid characters from a filename and replace spaces with underscores.
    """
    return re.sub(r'[\\/*?:"<>|]', "", filename).replace(" ", "_")

def get_video(url, get_best_quality=True, audio_only=False, get_transcript=True, rename=None, audio_format="mp3", quiet=True):
    """
    Download video or playlist from YouTube with optional transcript retrieval.
    
    Args:
        url (str): The YouTube video or playlist URL.
        get_best_quality (bool): Whether to download the best available quality (merges streams if needed).
        audio_only (bool): If True, downloads only the audio track.
        get_transcript (bool): If True, attempts to download the English transcript as a JSON file.
        rename (str): Optional prefix or full name for the output file(s). 
                      For playlists, it serves as the directory name.
        audio_format (str): Desired audio format (mp3, m4a, wav, flac, aac). Default is "mp3".
        quiet (bool): If True, suppresses yt-dlp logs. Set to False for debugging.
        
    Returns:
        list: A list of dictionaries containing metadata and paths for each downloaded item.
    """
    results = []

    # Configure base yt-dlp options
    ydl_opts = {
        'quiet': quiet,
        'no_warnings': quiet,
        'extract_flat': False,
        'ffmpeg_location': ffmpeg_dir, # Explicitly tell yt-dlp where ffmpeg is
    }

    if audio_only:
        ydl_opts.update({
            'format': 'bestaudio/best',
            'postprocessors': [{
                'key': 'FFmpegExtractAudio',
                'preferredcodec': audio_format,
                'preferredquality': '192',
            }],
        })
    elif get_best_quality:
        ydl_opts.update({
            'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        })

    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        try:
            info = ydl.extract_info(url, download=False)
            is_playlist = 'entries' in info
            entries = info.get('entries', [info])
            
            if is_playlist and rename:
                output_dir = os.path.join(os.getcwd(), rename)
            else:
                output_dir = os.getcwd()
                
            os.makedirs(output_dir, exist_ok=True)
            
            for index, entry in enumerate(entries, start=1):
                v_id = entry.get('id')
                v_title = entry.get('title')
                
                if rename:
                    base_name = f"{rename}_{index}" if is_playlist else rename
                else:
                    base_name = sanitize_filename(v_title)

                file_ext = audio_format if audio_only else "mp4"
                final_filename = f"{base_name}.{file_ext}"
                target_path = os.path.join(output_dir, final_filename)
                
                print(f"[*] Downloading: {v_title} -> {final_filename}")
                
                ydl_opts_exec = dict(ydl_opts)
                ydl_opts_exec['outtmpl'] = target_path
                
                with yt_dlp.YoutubeDL(ydl_opts_exec) as ydl_exec:
                    ydl_exec.download([entry.get('webpage_url') or f"https://www.youtube.com/watch?v={v_id}"])

                result_item = {
                    "id": v_id,
                    "title": v_title,
                    "file_path": target_path,
                    "transcript_path": None
                }

                if get_transcript:
                    try:
                        transcript_file = os.path.join(output_dir, f"{base_name}_transcript.json")
                        transcript_list = YouTubeTranscriptApi().list(v_id)
                        transcript = transcript_list.find_transcript(['en', 'en-US', 'en-GB'])
                        fetched_transcript = transcript.fetch().to_raw_data()
                        
                        with open(transcript_file, 'w', encoding='utf-8') as f:
                            json.dump(fetched_transcript, f, ensure_ascii=False, indent=2)
                        result_item["transcript_path"] = transcript_file
                        print(f"[+] Transcript saved: {transcript_file}")
                    except Exception as e:
                        print(f"[!] Transcript error ({v_id}): {e}")

                results.append(result_item)

            return results

        except Exception as e:
            print(f"[!] Error during ingest: {e}")
            return []
