import os
import json
import sqlite3
import httpx
import re
import shutil
import warnings
import threading
import time
from pathlib import Path
from dotenv import load_dotenv
from concurrent.futures import ThreadPoolExecutor, as_completed

# Load environment variables from .env file if it exists
load_dotenv()

# Global lock for thread-safe DB operations
db_lock = threading.Lock()

# --- DEFAULT FALLBACK PROMPT ---
DEFAULT_PROMPT = """ROLÜN: Profesyonel dublaj senaristisin. {duration_context}
VİDEO URL: {video_url}
GÖREVİN: İngilizce altyazıyı Türkçe'ye çevir.

KRİTİK TALİMATLAR:
1. GÖRSEL BAĞLAM: Videodaki görsel içeriği anlayarak transkripti bu bağlama göre çevir.
2. JUMBO FRAMES: Mümkün olan yerlerde birden fazla satırı tek bir AKICI Türkçe cümlede birleştir. 
3. COMPRESSION: Dublaj süresine uyması için cümleleri en kısa, öz ve akıcı haliyle kur.
4. FILLER REMOVAL: "Actually", "you know", "I think", "so" gibi dolgu kelimelerini at.
5. GLOSSARY: Bu terimleri asla değiştirme: {glossary}
6. AI DISCOVERY: Yeni teknik terimler görürsen; a) Orijinal bırak. b) Türkçe fonetik okunuşlarını belirle.
7. INTEGRITY: ID {start_idx} ile {end_idx} arasını eksiksiz kullan.

ÇIKTI FORMATI (JSON):
{
  "segments": [{"ids": [id1, id2], "text": "..."}],
  "new_terms": {"Kelime": "okunuşu"}
}

GİRDİ:
{json_data}"""

class Translator:
    def __init__(self, db_path="glossary.db"):
        self.user_db_path = db_path
        self._initialize_db()

    def _initialize_db(self):
        """Initializes user DB from default package DB if it doesn't exist."""
        with db_lock:
            if not os.path.exists(self.user_db_path):
                pkg_db = Path(__file__).parent / "data" / "default_glossary.db"
                if pkg_db.exists():
                    shutil.copy(pkg_db, self.user_db_path)
                else:
                    self._create_empty_db_raw()

    def _create_empty_db_raw(self):
        conn = sqlite3.connect(self.user_db_path)
        c = conn.cursor()
        c.execute('CREATE TABLE IF NOT EXISTS terms (id INTEGER PRIMARY KEY AUTOINCREMENT, term TEXT UNIQUE NOT NULL, phonetic TEXT NOT NULL)')
        c.execute('CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)')
        c.execute("INSERT OR REPLACE INTO metadata (key, value) VALUES (?, ?)", ("system_prompt", DEFAULT_PROMPT))
        conn.commit()
        conn.close()

    def get_db_connection(self):
        return sqlite3.connect(self.user_db_path)

    def get_terms(self):
        with db_lock:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT term FROM terms")
            terms = [row[0] for row in cursor.fetchall()]
            conn.close()
            return terms

    def add_new_terms(self, new_terms):
        with db_lock:
            conn = self.get_db_connection()
            cursor = conn.cursor()
            added_count = 0
            for term, phonetic in new_terms.items():
                try:
                    cursor.execute("INSERT INTO terms (term, phonetic) VALUES (?, ?)", (term, phonetic))
                    added_count += 1
                except sqlite3.IntegrityError:
                    pass
            conn.commit()
            conn.close()
            return added_count

    def get_prompt(self):
        try:
            with db_lock:
                conn = self.get_db_connection()
                cursor = conn.cursor()
                cursor.execute("SELECT value FROM metadata WHERE key = 'system_prompt'")
                row = cursor.fetchone()
                conn.close()
                return row[0] if row else DEFAULT_PROMPT
        except:
            return DEFAULT_PROMPT

    def call_gemini(self, api_key, prompt, model="gemini-2.5-flash", verbose=False):
        model_id = model.split("/")[-1]
        url = f"https://generativelanguage.googleapis.com/v1/models/{model_id}:generateContent?key={api_key}"
        
        payload = {
            "contents": [{"parts": [{"text": prompt}]}],
            "safetySettings": [
                {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_NONE"},
                {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_NONE"}
            ]
        }

        # RETRY LOGIC (3 Attempts, 5s Delay)
        max_retries = 3
        last_error = None
        
        for attempt in range(1, max_retries + 1):
            try:
                if verbose and attempt > 1:
                    print(f"    [!] Retrying API call (Attempt {attempt}/{max_retries})...")
                
                with httpx.Client(timeout=120.0) as client:
                    response = client.post(url, json=payload)
                    response.raise_for_status()
                    
                    data = response.json()
                    raw_text = data['candidates'][0]['content']['parts'][0]['text']
                    
                    match = re.search(r'\{.*\}', raw_text, re.DOTALL)
                    return json.loads(match.group()) if match else json.loads(raw_text)
            except Exception as e:
                last_error = e
                if attempt < max_retries:
                    time.sleep(5)
                else:
                    if verbose: print(f"    [X] All {max_retries} attempts failed for this chunk.")
                    raise last_error

def translate_transcript(transcript_path, api_key=None, model="gemini-2.5-flash", db_path="glossary.db", verbose=False):
    """Translates a transcript file into Turkish using AI discovery and SQLite glossary."""
    if not api_key:
        api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        print("\n[!] HINT: 'api_key' bulunamadı.")
        api_key = input("\nLütfen Gemini API Key'inizi buraya yapıştırın: ").strip()
        if not api_key: raise ValueError("API Key eksik.")

    if not os.path.exists(transcript_path):
        raise FileNotFoundError(f"Transcript file not found: {transcript_path}")
        
    with open(transcript_path, "r", encoding="utf-8") as f:
        transcript = json.load(f)

    translator = Translator(db_path)
    system_prompt_template = translator.get_prompt()
    chunk_size = 40
    
    def process_pass(pass_name="Pass"):
        current_glossary = translator.get_terms()
        pass_found_new = False
        
        chunks = []
        for i in range(0, len(transcript), chunk_size):
            chunks.append((i, transcript[i:i + chunk_size]))
            
        pass_results = {}
        total_chunks = len(chunks)
        
        if verbose: print(f"[*] {pass_name}: Total {total_chunks} chunks to process in parallel.")

        def process_single_chunk(chunk_data):
            idx, chunk = chunk_data
            chunk_id = idx // chunk_size + 1
            start_time = time.time()
            
            if verbose: print(f"    [>] Starting Chunk {chunk_id}/{total_chunks}...")
            
            duration_val = sum(item['duration'] for item in chunk)
            duration_context = f"[TIMING]: Bu bölümün süresi {duration_val:.2f} sn."
            
            prompt = system_prompt_template.replace("{duration_context}", duration_context)
            prompt = prompt.replace("{glossary}", ", ".join(current_glossary))
            prompt = prompt.replace("{start_idx}", str(idx))
            prompt = prompt.replace("{end_idx}", str(idx + len(chunk) - 1))
            prompt = prompt.replace("{json_data}", json.dumps(chunk, ensure_ascii=False))
            prompt = prompt.replace("{video_url}", "Unknown")

            result = translator.call_gemini(api_key, prompt, model, verbose)
            
            elapsed = time.time() - start_time
            if verbose: print(f"    [✓] Chunk {chunk_id} completed in {elapsed:.1f}s.")
            return idx, result

        with ThreadPoolExecutor(max_workers=5) as executor:
            future_to_chunk = {executor.submit(process_single_chunk, c): c for c in chunks}
            for future in as_completed(future_to_chunk):
                try:
                    idx, response_json = future.result()
                    new_terms = response_json.get("new_terms", {})
                    if new_terms:
                        added = translator.add_new_terms(new_terms)
                        if added > 0:
                            pass_found_new = True
                            if verbose: print(f"    [+] New Terms Discovered: {list(new_terms.keys())}")
                    pass_results[idx] = response_json.get("segments", [])
                except Exception as e:
                    print(f"    [!] FATAL error in chunk at index {future_to_chunk[future][0]}: {e}")

        combined_output = []
        for idx in sorted(pass_results.keys()):
            combined_output.extend(pass_results[idx])
        return combined_output, pass_found_new

    # --- PHASE 1 ---
    if verbose: print(f"\n{'='*20} PHASE 1: DISCOVERY {'='*20}")
    first_pass_result, found_new = process_pass("Phase 1")
    
    # --- PHASE 2 ---
    final_segments = first_pass_result
    if found_new:
        if verbose: print(f"\n{'='*20} PHASE 2: CONSISTENCY {'='*20}")
        final_segments, _ = process_pass("Phase 2")
    
    # Post-process
    final_transcript = []
    for segment in final_segments:
        ids = segment.get("ids", [])
        if not ids: continue
        try:
            orig_segments = [transcript[idx] for idx in ids if idx < len(transcript)]
            if not orig_segments: continue
            final_transcript.append({
                "start": orig_segments[0]["start"],
                "duration": sum(s["duration"] for s in orig_segments),
                "text": segment["text"]
            })
        except: continue
    
    output_path = transcript_path.replace(".json", "_tr.json")
    if output_path == transcript_path: output_path = "transcript_tr.json"
    
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(final_transcript, f, ensure_ascii=False, indent=2)
        
    if verbose: print(f"\n[SUCCESS] Final translation saved to: {output_path}\n")
    return final_transcript
