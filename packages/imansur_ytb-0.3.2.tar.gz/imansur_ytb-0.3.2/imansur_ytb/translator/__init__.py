from .logic import translate_transcript
