from .logic import synthesize_text, synthesize_transcript
