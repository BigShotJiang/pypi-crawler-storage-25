import os
import json
import asyncio
import subprocess
import shutil
import sqlite3
import edge_tts
import time
import re
from pathlib import Path

# --- PHONETIC REPLACEMENT LOGIC ---
def _apply_phonetics(text, db_path):
    """Replaces terms in text with their phonetic readings from DB."""
    if not os.path.exists(db_path):
        return text
    
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT term, phonetic FROM terms")
        rows = cursor.fetchall()
        conn.close()
        
        # Sort by length descending to avoid partial matches (e.g., 'Fast' before 'FastAPI')
        rows.sort(key=lambda x: len(x[0]), reverse=True)
        
        for term, phonetic in rows:
            # Case insensitive replacement with word boundaries
            pattern = re.compile(re.escape(term), re.IGNORECASE)
            text = pattern.sub(phonetic, text)
    except Exception as e:
        print(f"[!] Phonetic Error: {e}")
        
    return text

def _get_audio_duration(file_path):
    """Uses ffprobe to get exact duration of an audio file."""
    cmd = [
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(file_path)
    ]
    result = subprocess.run(cmd, capture_output=True, text=True)
    try:
        return float(result.stdout.strip())
    except:
        return 0.0

async def _text_to_speech(text, output_path, voice="tr-TR-AhmetNeural", rate="+0%", pitch="+0Hz"):
    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(output_path)

def synthesize_text(text, output_path, voice="tr-TR-AhmetNeural", rate="+0%", pitch="+0Hz", db_path="glossary.db"):
    """Synthesizes text, applying phonetics from DB if available."""
    processed_text = _apply_phonetics(text, db_path)
    asyncio.run(_text_to_speech(processed_text, output_path, voice, rate, pitch))
    return output_path

def synthesize_transcript(transcript_path, output_file="final_dub.mp3", voice="tr-TR-AhmetNeural", db_path="glossary.db", verbose=False):
    """Synthesizes transcript with phonetic support and anti-collision logic."""
    if not os.path.exists(transcript_path):
        raise FileNotFoundError(f"Transcript not found: {transcript_path}")

    with open(transcript_path, "r", encoding="utf-8") as f:
        transcript = json.load(f)

    temp_dir = Path("temp_segments")
    temp_dir.mkdir(exist_ok=True)
    
    segment_files = []
    
    if verbose: print(f"[*] Starting synthesis for {len(transcript)} segments...")

    for i, entry in enumerate(transcript):
        text = entry['text']
        start = entry['start']
        target_duration = entry['duration']
        
        # Determine available gap until next segment to prevent overlap
        max_available_time = target_duration
        if i < len(transcript) - 1:
            next_start = transcript[i+1]['start']
            max_available_time = next_start - start
            # Add a tiny buffer (0.1s) to prevent exact overlaps
            max_available_time = max(0.5, max_available_time - 0.1)

        # 1. Initial synthesis to check duration
        seg_path = temp_dir / f"seg_{i}.wav"
        synthesize_text(text, str(seg_path), voice=voice, db_path=db_path)
        
        actual_duration = _get_audio_duration(seg_path)
        
        # 2. If it exceeds available time, re-synthesize with speed-up
        if actual_duration > max_available_time:
            speed_up_factor = (actual_duration / max_available_time) - 1
            rate_val = int(min(100, speed_up_factor * 100))
            rate = f"+{rate_val}%"
            if verbose: 
                print(f"    [!] Segment {i} collision detected ({actual_duration:.2fs} > {max_available_time:.2fs}).")
                print(f"    [!] Speeding up by {rate}...")
            synthesize_text(text, str(seg_path), voice=voice, rate=rate, db_path=db_path)
            
        segment_files.append((seg_path, start))

    if verbose: print(f"[*] Merging with collision-free amix...")
    
    inputs = []
    filter_parts = []
    for i, (path, start) in enumerate(segment_files):
        inputs.extend(["-i", str(path)])
        delay_ms = int(start * 1000)
        filter_parts.append(f"[{i}]adelay={delay_ms}|{delay_ms}[a{i}]")
    
    mix_labels = "".join([f"[a{i}]" for i in range(len(segment_files))])
    filter_complex = f"{';'.join(filter_parts)};{mix_labels}amix=inputs={len(segment_files)}:normalize=0[out]"
    
    cmd = ["ffmpeg", "-y", *inputs, "-filter_complex", filter_complex, "-map", "[out]"]
    if output_file.endswith(".mp3"): cmd.extend(["-ab", "192k"])
    cmd.append(output_file)
    
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        if verbose: print(f"[+] Final output: {output_file}")
    except subprocess.CalledProcessError as e:
        print(f"[!] FFmpeg Error: {e.stderr.decode()}")
        raise e
    finally:
        shutil.rmtree(temp_dir)

    return output_file
