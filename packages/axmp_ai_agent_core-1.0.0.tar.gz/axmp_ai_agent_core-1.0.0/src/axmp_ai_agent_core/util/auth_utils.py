"""Authentication utility functions."""

from __future__ import annotations

from axmp_openapi_helper import AuthConfig, AuthenticationType

from axmp_ai_agent_core.entity.backend_server import BackendServer


def create_auth_config_from_backend_server(backend_server: BackendServer) -> AuthConfig:
    """Create AuthConfig from backend server auth settings.

    This is a shared utility function used by both McpServerInstanceService
    and McpServerService to ensure consistent AuthConfig creation.

    Args:
        backend_server: The backend server entity containing auth settings

    Returns:
        AuthConfig configured based on the backend server's auth type
    """
    auth_type = backend_server.auth_type or AuthenticationType.NONE

    if auth_type == AuthenticationType.API_KEY:
        return AuthConfig(
            type=auth_type,
            api_key_name=backend_server.auth_header_key,
        )
    return AuthConfig(type=auth_type)
