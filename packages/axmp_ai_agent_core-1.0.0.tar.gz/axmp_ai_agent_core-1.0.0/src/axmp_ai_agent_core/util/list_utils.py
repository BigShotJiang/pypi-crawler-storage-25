"""This module contains the constants and enums used for pagination and sorting."""

from enum import StrEnum
from typing import Any, Callable, Iterable, List, Sequence

DEFAULT_PAGE_NUMBER = 1
"""Pagination constants. Default page number is 1"""
DEFAULT_PAGE_SIZE = 10
"""Pagination constants. Default page size is 10"""
DEFAULT_CARD_PAGE_SIZE = 12
"""Pagination constants. Default card page size is 12"""
MAX_PAGE_SIZE = 1000
"""Pagination constants. Maximum page size is 100"""
MAX_LIMIT = 1000
"""Maximum limit for the list without pagination. Maximum limit is 1000"""


class SortDirection(StrEnum):
    """Sort direction enum."""

    ASC = "asc"
    DESC = "desc"


def paginate_list[T](
    items: Sequence[T],
    *,
    page_number: int = DEFAULT_PAGE_NUMBER,
    page_size: int = DEFAULT_PAGE_SIZE,
) -> List[T]:
    """Return items for the requested page.

    Args:
        items: The full list of items to paginate
        page_number: The page number (1-indexed)
        page_size: The number of items per page

    Returns:
        List of items for the requested page
    """
    if page_size <= 0:
        return list(items)

    start_index = max(page_number - 1, 0) * page_size
    end_index = start_index + page_size
    return list(items[start_index:end_index])


def sort_list[T](
    items: Iterable[T],
    *,
    sort_field: str | None = None,
    sort_direction: SortDirection | str = SortDirection.ASC,
    use_metadata_extractors: bool = False,
    extractors: dict[str, Callable[[Any], Any]] | None = None,
) -> List[T]:
    """Sort items based on field and direction.

    Args:
        items: The items to sort
        sort_field: The field to sort by
        sort_direction: The direction to sort (asc/desc)
        use_metadata_extractors: If True, use default metadata extractors
        extractors: Optional custom extractors (overrides metadata extractors)

    Returns:
        Sorted list of items
    """
    if not sort_field:
        return list(items)

    # Use custom extractors if provided, otherwise use metadata extractors if requested
    if not extractors and use_metadata_extractors:
        extractors = get_metadata_sort_extractors()

    if not extractors:
        return list(items)

    key_fn = extractors.get(sort_field)
    if not key_fn:
        return list(items)

    reverse = str(sort_direction).lower() == "desc"
    return sorted(list(items), key=key_fn, reverse=reverse)


def sort_and_paginate_list[T](
    items: Iterable[T],
    *,
    sort_field: str | None = None,
    sort_direction: SortDirection | str = SortDirection.ASC,
    page_number: int = DEFAULT_PAGE_NUMBER,
    page_size: int = DEFAULT_PAGE_SIZE,
    use_metadata_extractors: bool = False,
    extractors: dict[str, Callable[[Any], Any]] | None = None,
) -> tuple[List[T], int]:
    """Sort and paginate a list of items.

    Args:
        items: The items to sort and paginate
        sort_field: The field to sort by
        sort_direction: The direction to sort (asc/desc)
        page_number: The page number (1-indexed)
        page_size: The number of items per page
        use_metadata_extractors: If True, use default metadata extractors
        extractors: Optional custom extractors (overrides metadata extractors)

    Returns:
        Tuple of (paginated items, total count)
    """
    # First sort the items
    sorted_items = sort_list(
        items,
        sort_field=sort_field,
        sort_direction=sort_direction,
        use_metadata_extractors=use_metadata_extractors,
        extractors=extractors,
    )

    # Get total count
    total_count = len(sorted_items)

    # Then paginate
    paginated_items = paginate_list(
        sorted_items,
        page_number=page_number,
        page_size=page_size,
    )

    return paginated_items, total_count


def extract_instance_id(resource: Any) -> str | None:
    """Extract instance-id from Kubernetes resource metadata labels.

    Args:
        resource: Kubernetes resource with metadata

    Returns:
        instance-id label value or None if not present
    """
    if not hasattr(resource, "metadata") or not resource.metadata:
        return None
    labels = resource.metadata.get("labels", {})
    return labels.get("instance-id")


def remove_duplicates_by_key[T](
    items: Iterable[T],
    key_extractor: Callable[[T], str | None],
) -> List[T]:
    """Remove duplicates from a list based on a key extractor function.

    Args:
        items: The items to deduplicate
        key_extractor: Function to extract the deduplication key from each item

    Returns:
        List with duplicates removed (preserves first occurrence)
    """
    deduplicated_items = []
    seen_keys = set()

    for item in items:
        key = key_extractor(item)

        # If no key, always include (can't deduplicate without key)
        if key is None:
            deduplicated_items.append(item)
            continue

        # Skip if we've seen this key before
        if key in seen_keys:
            continue

        # First time seeing this key, add it
        seen_keys.add(key)
        deduplicated_items.append(item)

    return deduplicated_items


def remove_duplicates[T](items: Iterable[T]) -> List[T]:
    """Remove duplicates from Kubernetes resources based on instance-id label."""
    deduplicated_items: List[T] = []
    seen_instance_ids: set[str] = set()

    for item in items:
        metadata = getattr(item, "metadata", {}) or {}
        labels = metadata.get("labels", {}) if isinstance(metadata, dict) else {}
        instance_id = labels.get("instance-id")

        if instance_id is None:
            deduplicated_items.append(item)
            continue

        if instance_id in seen_instance_ids:
            continue

        seen_instance_ids.add(instance_id)
        deduplicated_items.append(item)

    return deduplicated_items


def get_metadata_sort_extractors() -> dict[str, Callable[[Any], Any]]:
    """Get extractors for sorting resources by metadata fields.

    Returns:
        Dictionary mapping sort field names to extraction functions
    """

    def metadata_value(instance: Any, key: str, default: str = "") -> str:
        """Extract value from instance metadata."""
        metadata = getattr(instance, "metadata", {}) or {}
        return metadata.get(key, default)

    return {
        "name": lambda inst: metadata_value(inst, "name"),
        "created_at": lambda inst: metadata_value(inst, "creationTimestamp"),
        "updated_at": lambda inst: metadata_value(
            inst,
            "updateTimestamp",
            metadata_value(inst, "creationTimestamp"),
        ),
        "status": lambda inst: inst.status.phase
        if hasattr(inst, "status") and inst.status
        else "",
    }
