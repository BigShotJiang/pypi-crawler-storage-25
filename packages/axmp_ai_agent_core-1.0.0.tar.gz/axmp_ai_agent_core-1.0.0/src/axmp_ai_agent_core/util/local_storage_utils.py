"""Local storage utilities."""

import os
import shutil
from typing import List

from axmp_ai_agent_core.entity.image_upload_target import ImageUploadTarget
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.setting import core_settings
from axmp_ai_agent_core.util.files_utils import IMAGE_EXTENSIONS

TEMPLATE_IMAGE_ROOT_DIR = "templates"
CUSTOM_IMAGE_ROOT_DIR = "custom"
DEFAULT_ICON_FILENAMES: dict[ImageUploadTarget, tuple[str, ...]] = {
    ImageUploadTarget.AGENT: ("agent.png",),
    ImageUploadTarget.MCP_SERVER: ("mcp.png", "mcp-server.png"),
    ImageUploadTarget.SKILL: ("skill.png",),
}


def _format_category_name(name: str) -> str | None:
    """Format a category name for display."""
    if not name:
        return name

    parts = [part for part in name.strip().split("_") if part]
    if not parts:
        return name

    formatted_parts = [f"{part[:1].upper()}{part[1:]}" for part in parts]
    return " & ".join(formatted_parts)


def _to_image_relative_path(abs_path: str) -> str | None:
    """Convert an absolute path to a relative path under any known image root."""
    abs_path = os.path.abspath(abs_path)
    root = core_settings.image_path
    if root:
        root_abs = os.path.abspath(root)
        if abs_path.startswith(root_abs):
            relative = os.path.relpath(abs_path, root_abs)
            return relative.replace("\\", "/")
    return None


def _build_full_image_url(relative_path: str) -> str:
    """Build a full URL from a relative image path."""
    clean_path = relative_path.replace("\\", "/").lstrip("/")
    return f"{core_settings.image_server_endpoint}/{clean_path}"


def _resolve_custom_image_root(
    image_type: ImageUploadTarget, create: bool = False
) -> str | None:
    """Resolve the custom image directory for the given image type."""
    base_dir = os.path.join(
        core_settings.image_path, CUSTOM_IMAGE_ROOT_DIR, image_type.value
    )
    if os.path.isdir(base_dir):
        return base_dir

    if not create:
        return None

    try:
        os.makedirs(base_dir, exist_ok=True)
    except OSError:
        return None
    return base_dir if os.path.isdir(base_dir) else None


def _resolve_template_image_root(
    image_type: ImageUploadTarget, create: bool = False
) -> str | None:
    """Resolve the template image root directory for the given image type."""
    candidate = os.path.join(
        core_settings.image_path, TEMPLATE_IMAGE_ROOT_DIR, image_type.value
    )
    if os.path.isdir(candidate):
        return candidate

    if not create:
        return None

    try:
        os.makedirs(candidate, exist_ok=True)
    except OSError:
        return None
    if os.path.isdir(candidate):
        return candidate

    return None


async def setup_default_images():
    """Set up default images from templates."""
    for image_type in ImageUploadTarget.get_all_targets():
        default_image_dir = f"{core_settings.default_image_path}/templates/{image_type}"
        public_image_dir = f"{core_settings.image_path}/templates/{image_type}"

        if not os.path.isdir(default_image_dir):
            # Skip if source directory does not exist
            continue

        os.makedirs(public_image_dir, exist_ok=True)

        # Recursively copy the entire folder tree while preserving structure
        for dirpath, _dirnames, filenames in os.walk(default_image_dir):
            rel_dir = os.path.relpath(dirpath, default_image_dir)
            target_dir = (
                public_image_dir
                if rel_dir == "."
                else os.path.join(public_image_dir, rel_dir)
            )
            os.makedirs(target_dir, exist_ok=True)

            for filename in filenames:
                src_file = os.path.join(dirpath, filename)
                dst_file = os.path.join(target_dir, filename)
                try:
                    shutil.copy2(src_file, dst_file)
                except OSError:
                    # Ignore copy errors for individual files to avoid failing startup
                    continue


def get_default_icon_url(image_type: ImageUploadTarget) -> str | None:
    """Return the default icon URL for the given image type, if available."""
    filenames = DEFAULT_ICON_FILENAMES.get(image_type, ())
    image_root = core_settings.image_path
    if not image_root:
        return None

    base_dir = os.path.join(
        image_root, TEMPLATE_IMAGE_ROOT_DIR, image_type.value, "default"
    )
    for filename in filenames:
        abs_candidate = os.path.join(base_dir, filename)
        if os.path.isfile(abs_candidate):
            relative_path = _to_image_relative_path(abs_candidate)
            if relative_path:
                return _build_full_image_url(relative_path)

    return None


async def get_template_icon_url(image_type: ImageUploadTarget) -> List[dict]:
    """List template images grouped by category.

    Returns a list of objects: {"category": <str>, "images": [<url>, ...]}
    """
    root_dir = _resolve_template_image_root(image_type)
    if not root_dir:
        return []

    # Collect URLs grouped by category (first-level folder under the type)
    category_to_urls: dict[str, list[str]] = {}
    for dirpath, _dirnames, filenames in os.walk(root_dir):
        for filename in filenames:
            ext = os.path.splitext(filename)[1].lower()
            if ext not in IMAGE_EXTENSIONS:
                continue
            abs_path = os.path.join(dirpath, filename)
            rel_path = os.path.relpath(abs_path, root_dir).replace("\\", "/")
            dir_part = os.path.dirname(rel_path).replace("\\", "/")
            raw_category = dir_part.split("/")[0] if dir_part else ""
            # skip default category from result
            if raw_category.lower() == "default":
                continue
            category = _format_category_name(raw_category)
            web_path = f"{TEMPLATE_IMAGE_ROOT_DIR}/{image_type.value}/{rel_path}"
            full_url = f"{core_settings.image_server_endpoint}/{web_path}"
            category_to_urls.setdefault(category, []).append(full_url)

    # Build sorted list response
    result: List[dict] = []
    for category in sorted(category_to_urls.keys()):
        images = sorted(category_to_urls[category])
        result.append({"category": category, "icons": images})
    return result


async def upload_file_to_local_storage(
    file_bytes: bytes,
    filename: str,
    image_type: ImageUploadTarget,
) -> str:
    """Upload a file to local storage and return the full URL."""
    # Ensure the custom image directory exists for the given image type
    base_dir = _resolve_custom_image_root(image_type, create=True)
    if not base_dir:
        raise ValueError(
            f"Custom image directory does not exist and could not be created: "
            f"{os.path.join(core_settings.image_path, CUSTOM_IMAGE_ROOT_DIR, image_type.value)}"
        )

    # Sanitize filename to prevent path traversal (e.g., "../../etc/passwd")
    filename = os.path.basename(filename)
    if not filename:
        raise CoreServiceException(
            CoreError.BAD_REQUEST,
            details="Invalid filename.",
        )

    base_name, extension = os.path.splitext(filename)
    unique_filename = filename

    # If the file already exists, add a number to the filename
    full_file_path = os.path.join(base_dir, unique_filename)
    counter = 1

    while os.path.exists(full_file_path):
        unique_filename = f"{base_name}_{counter}{extension}"
        full_file_path = os.path.join(base_dir, unique_filename)
        counter += 1

    with open(full_file_path, "wb") as file:
        file.write(file_bytes)

    relative_path = _to_image_relative_path(full_file_path)
    if not relative_path:
        relative_path = f"{CUSTOM_IMAGE_ROOT_DIR}/{image_type.value}/{unique_filename}"
    return _build_full_image_url(relative_path)
