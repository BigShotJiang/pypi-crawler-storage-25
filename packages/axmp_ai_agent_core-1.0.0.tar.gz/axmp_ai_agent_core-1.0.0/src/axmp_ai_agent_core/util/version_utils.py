"""Version parsing and generation utilities."""

from typing import Awaitable, Callable

from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)


def parse_version(version_str: str) -> int:
    """Parse version string (e.g., 'v1', 'V1', '1') to integer.

    Args:
        version_str: Version string that may or may not have 'v' prefix.

    Returns:
        The version as an integer.

    Raises:
        ValueError: If the version string cannot be parsed to an integer.
    """
    trimmed = version_str.strip().lower()
    if trimmed.startswith("v"):
        trimmed = trimmed[1:]

    if not trimmed.isdigit():
        raise ValueError(f"Invalid version format: {version_str}")

    return int(trimmed)


def safe_parse_version(version_str: str) -> int:
    """Parse version string with CoreServiceException on error.

    Args:
        version_str: Version string (e.g., 'v1', 'V1', '1')

    Returns:
        The version as an integer.

    Raises:
        CoreServiceException: BAD_REQUEST if version format is invalid.
    """
    try:
        return parse_version(version_str)
    except ValueError as e:
        raise CoreServiceException(
            CoreError.BAD_REQUEST,
            details=f"Invalid version format: '{version_str}'. {e}",
        )


async def generate_next_version(
    get_max_version_fn: Callable[[], Awaitable[int]],
) -> int:
    """Generate next sequential version number.

    This is a common utility for generating the next version by querying
    the current max version from a repository.

    Args:
        get_max_version_fn: Async function that returns the current max version.
            Should return 0 if no versions exist.

    Returns:
        Next version number (max_version + 1).

    Example:
        >>> version = await generate_next_version(
        ...     lambda: repository.get_max_version(profile_id=id)
        ... )
    """
    max_version = await get_max_version_fn()
    return max_version + 1
