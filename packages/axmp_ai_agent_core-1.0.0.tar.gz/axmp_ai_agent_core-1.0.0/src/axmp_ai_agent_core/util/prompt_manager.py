"""Prompt file loading with ConfigMap override and package default fallback.

디렉토리 스캔 기반 프롬프트 로딩 모듈.
ConfigMap 디렉토리(CORE_PROMPTS_DIR)에 파일이 있으면 우선 사용하고,
없거나 빈 파일이면 패키지 내장 default-prompts로 fallback한다.
"""

import logging
from enum import StrEnum
from pathlib import Path

logger = logging.getLogger(__name__)

_DEFAULT_PROMPTS_DIR = Path(__file__).parent.parent / "default-prompts"


class PromptFile(StrEnum):
    """Prompt file name constants."""

    DEFAULT_TEMPLATE = "default_template.yaml"
    MCP_PLAYGROUND_AGENT = "mcp_playground_agent.yaml"
    SKILL_ASSISTANT = "skill-assistant.md"


def _resolve_path(filename: str) -> Path:
    """Resolve prompt file path with ConfigMap priority and package fallback.

    Args:
        filename: prompt file name (e.g. "skill-assistant.md").

    Returns:
        Absolute path to the prompt file.

    Raises:
        ValueError: if filename contains path separators or '..'.
        FileNotFoundError: if the file is not found in either location.
    """
    if "/" in filename or "\\" in filename or ".." in filename:
        msg = f"Invalid prompt filename (path traversal not allowed): {filename}"
        raise ValueError(msg)

    # Lazy import to avoid circular dependency at module load time
    from axmp_ai_agent_core.setting import core_settings

    # 1. ConfigMap directory (CORE_PROMPTS_DIR)
    if core_settings.prompts_dir:
        configmap_path = Path(core_settings.prompts_dir) / filename
        if configmap_path.is_file() and configmap_path.read_text(encoding="utf-8").strip():
            logger.debug("Prompt resolved from ConfigMap: %s", configmap_path)
            return configmap_path

    # 2. Package default-prompts fallback
    default_path = _DEFAULT_PROMPTS_DIR / filename
    if default_path.is_file():
        logger.debug("Prompt resolved from default: %s", default_path)
        return default_path

    msg = f"Prompt file not found: {filename}"
    raise FileNotFoundError(msg)


def get_prompt_path(filename: str) -> Path:
    """Return absolute path to the prompt file.

    Use when the caller needs a file path (e.g. LangChain ``load_prompt()``).

    Args:
        filename: prompt file name (e.g. "mcp_playground_agent.yaml").

    Returns:
        Absolute ``Path`` to the prompt file.

    Raises:
        ValueError: if filename contains path separators or '..'.
        FileNotFoundError: if the file is not found in either location.
    """
    return _resolve_path(filename)


def get_prompt(filename: str) -> str:
    """Return prompt file content as text.

    Use when the caller needs the raw content directly.

    Args:
        filename: prompt file name (e.g. "skill-assistant.md").

    Returns:
        File content as a string.

    Raises:
        ValueError: if filename contains path separators or '..'.
        FileNotFoundError: if the file is not found in either location.
    """
    return _resolve_path(filename).read_text(encoding="utf-8")
