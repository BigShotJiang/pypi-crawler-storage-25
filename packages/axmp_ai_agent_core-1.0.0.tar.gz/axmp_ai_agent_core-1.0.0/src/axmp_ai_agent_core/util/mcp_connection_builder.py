"""MCP connection builder utilities."""

from __future__ import annotations

import logging
from datetime import timedelta
from typing import Any

from langchain_mcp_adapters.client import (
    SSEConnection,
    StdioConnection,
    StreamableHttpConnection,
)

from axmp_ai_agent_core.agent.spec.types import TransportType
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.setting import core_settings
from axmp_ai_agent_core.util.mcp_utils import validate_url

logger = logging.getLogger(__name__)

# Valid commands for stdio transport
VALID_STDIO_COMMANDS = ["npx", "uvx", "node", "python3"]

# Transport type mapping to library values.
# langchain_mcp_adapters expects: "stdio", "streamable_http", "sse"
TRANSPORT_TYPE_MAP: dict[str | TransportType, str] = {
    TransportType.STDIO: "stdio",
    TransportType.HTTP: "streamable_http",
    TransportType.SSE: "sse",
    TransportType.STREAMABLE_HTTP_DASH: "streamable_http",
    TransportType.STREAMABLE_HTTP_UNDERSCORE: "streamable_http",
}


def get_library_transport_value(transport: str | TransportType) -> str:
    """Convert transport type to library-compatible string value.

    Args:
        transport: Transport type as enum or string.

    Returns:
        Transport value string expected by langchain_mcp_adapters.

    Raises:
        ValueError: If the transport type is not supported.
    """
    # Normalize to TransportType enum first (handles "http", "streamable-http" etc.)
    if not isinstance(transport, TransportType):
        try:
            transport = TransportType(transport)
        except ValueError:
            raise ValueError(f"Unsupported transport type: {transport}")
    result = TRANSPORT_TYPE_MAP.get(transport)
    if result is None:
        raise ValueError(f"Unsupported transport type: {transport}")
    return result


def infer_transport_type(server_config: dict[str, Any]) -> str:
    """Infer transport type from server config fields.

    Args:
        server_config: Server configuration dictionary.

    Returns:
        Transport type string (raw value from config or inferred).

    Raises:
        CoreServiceException: If transport cannot be inferred.
    """
    transport = server_config.get("transport")
    if transport:
        if isinstance(transport, TransportType):
            return transport.value
        return str(transport)

    if "command" in server_config and "args" in server_config:
        return TransportType.STDIO.value
    elif "url" in server_config:
        return TransportType.HTTP.value
    else:
        raise CoreServiceException(
            CoreError.BAD_REQUEST,
            details="Cannot infer transport type. Config must have 'command'+'args' (stdio) or 'url' (streamable-http).",
        )


def build_mcp_connection(
    server_name: str,
    server_config: dict[str, Any],
    *,
    strict: bool = True,
) -> StdioConnection | StreamableHttpConnection | SSEConnection | None:
    """Build an MCP connection object from server config.

    Args:
        server_name: Name of the MCP server.
        server_config: Server configuration dictionary.
        strict: If True, raise exceptions on validation errors. If False, log warnings and return None.

    Returns:
        Connection object, or None if strict=False and validation fails.

    Raises:
        CoreServiceException: If strict=True and validation fails.
    """
    transport_raw = infer_transport_type(server_config)

    try:
        library_transport = get_library_transport_value(transport_raw)
    except ValueError:
        if strict:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Unsupported transport type: {transport_raw}",
            )
        logger.warning(
            "Unsupported transport type: %s for server %s", transport_raw, server_name
        )
        return None

    if library_transport == "stdio":
        return _build_stdio_connection(
            server_name, server_config, library_transport, strict=strict
        )
    elif library_transport == "streamable_http":
        return _build_streamable_http_connection(
            server_name, server_config, library_transport, strict=strict
        )
    elif library_transport == "sse":
        return _build_sse_connection(
            server_name, server_config, library_transport, strict=strict
        )
    else:
        if strict:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Unsupported transport type: {transport_raw}",
            )
        logger.warning(
            "Unsupported transport type: %s for server %s", transport_raw, server_name
        )
        return None


def _build_stdio_connection(
    server_name: str,
    server_config: dict[str, Any],
    library_transport: str,
    *,
    strict: bool,
) -> StdioConnection | None:
    """Build a stdio MCP connection.

    Args:
        server_name: Name of the MCP server.
        server_config: Server configuration dictionary.
        library_transport: Library transport string value.
        strict: If True, raise exceptions on validation errors.

    Returns:
        StdioConnection object, or None if strict=False and validation fails.

    Raises:
        CoreServiceException: If strict=True and validation fails.
    """
    command = server_config.get("command")
    args = server_config.get("args", [])

    if not command:
        if strict:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Missing 'command' field for stdio server {server_name}",
            )
        logger.warning("Missing 'command' field for stdio server %s", server_name)
        return None

    if strict and command not in VALID_STDIO_COMMANDS:
        raise CoreServiceException(
            CoreError.BAD_REQUEST,
            details=f"Invalid command: {command}, must be one of {VALID_STDIO_COMMANDS}",
        )

    env = server_config.get("env", {})
    connection: StdioConnection = {
        "transport": library_transport,  # type: ignore[typeddict-item]
        "command": command,
        "args": args,
        "session_kwargs": {
            "read_timeout_seconds": timedelta(
                seconds=core_settings.mcp_connection_timeout
            ),
        },
    }
    if env:
        connection["env"] = env
    return connection


def _build_streamable_http_connection(
    server_name: str,
    server_config: dict[str, Any],
    library_transport: str,
    *,
    strict: bool,
) -> StreamableHttpConnection | None:
    """Build a streamable-http MCP connection.

    Args:
        server_name: Name of the MCP server.
        server_config: Server configuration dictionary.
        library_transport: Library transport string value.
        strict: If True, raise exceptions on validation errors.

    Returns:
        StreamableHttpConnection object, or None if strict=False and validation fails.

    Raises:
        CoreServiceException: If strict=True and validation fails.
    """
    url = server_config.get("url")
    if not url:
        if strict:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Missing 'url' field for streamable-http server {server_name}",
            )
        logger.warning("Missing 'url' field for streamable-http server %s", server_name)
        return None

    if strict and not validate_url(url):
        raise CoreServiceException(
            CoreError.BAD_REQUEST,
            details=(
                f"Invalid url: {url}, must start with http:// or https:// "
                "and match a general URL or Kubernetes FQDN pattern"
            ),
        )

    connection: StreamableHttpConnection = {
        "transport": library_transport,  # type: ignore[typeddict-item]
        "url": url,
        "timeout": timedelta(seconds=server_config.get("timeout", 30.0)),
        "sse_read_timeout": timedelta(
            seconds=server_config.get("sse_read_timeout", 300.0)
        ),
        "session_kwargs": {
            "read_timeout_seconds": timedelta(
                seconds=core_settings.mcp_connection_timeout
            ),
        },
    }
    headers = server_config.get("headers")
    if headers:
        connection["headers"] = headers
    return connection


def _build_sse_connection(
    server_name: str,
    server_config: dict[str, Any],
    library_transport: str,
    *,
    strict: bool,
) -> SSEConnection | None:
    """Build an SSE MCP connection.

    Args:
        server_name: Name of the MCP server.
        server_config: Server configuration dictionary.
        library_transport: Library transport string value.
        strict: If True, raise exceptions on validation errors.

    Returns:
        SSEConnection object, or None if strict=False and validation fails.

    Raises:
        CoreServiceException: If strict=True and validation fails.
    """
    url = server_config.get("url")
    if not url:
        if strict:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Missing 'url' field for SSE server {server_name}",
            )
        logger.warning("Missing 'url' field for SSE server %s", server_name)
        return None

    connection: SSEConnection = {
        "transport": library_transport,  # type: ignore[typeddict-item]
        "url": url,
        "timeout": server_config.get("timeout", 5.0),
        "sse_read_timeout": server_config.get("sse_read_timeout", 300.0),
        "session_kwargs": {
            "read_timeout_seconds": timedelta(
                seconds=core_settings.mcp_connection_timeout
            ),
        },
    }
    headers = server_config.get("headers")
    if headers:
        connection["headers"] = headers
    return connection
