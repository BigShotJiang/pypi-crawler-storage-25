"""Common utility modules for caching, file handling, and data processing."""
