"""MongoDB 검색 유틸리티.

공통:
    - get_escaped_regex_pattern: MongoDB regex 검색용 패턴 생성 (전체 Repository에서 사용)

한국어 토큰화 파이프라인 (search_tokens 기반 검색):
    - KoreanTextNormalizer: 공백 정리, 특수문자 제거, 영문 소문자화
    - KoreanTokenizer: Kiwi 형태소 분석 → 명사/영문/숫자 추출
    - AliasExpander: 도메인 용어 양방향 별칭 확장 (search_aliases.yaml)
    - build_search_tokens: 위 3단계 + 중복 제거 + 정렬

다른 Entity에 토큰 검색을 적용하려면:
    1. Entity에 ``search_tokens: list[str] = Field(default_factory=list)`` 추가
    2. Service의 create/update에서 ``build_search_tokens(name=..., description=...)`` 호출
    3. Repository의 ``_build_keyword_filter`` 에서 토큰 기반 검색 구현
       - ``KoreanTokenizer.extract_tokens()`` 로 검색어 토큰화
       - ``AliasExpander.expand()`` 로 각 토큰의 alias 확장
       - search_tokens 필드에 $and/$in 쿼리 구성
       - 토큰화 불가 시 ``get_escaped_regex_pattern()`` 으로 regex fallback
    4. find_all의 exclude_fields에 ``"search_tokens"`` 추가
    5. MongoDB index 생성: ``db.{collection}.createIndex({"search_tokens": 1})``
    참고 구현: ``SkillRepository._build_keyword_filter``, ``SkillService.create_skill``
"""

import os
import re

import yaml
from kiwipiepy import Kiwi

# ---------------------------------------------------------------------------
# Regex pattern helpers (기존)
# ---------------------------------------------------------------------------


def get_escaped_regex_pattern(search_text: str | None) -> str:
    """Get pattern for search text.

    Escapes special characters and return pattern for mongodb search.
    """
    escaped_search_text = (
        re.sub(r"([.*+?^${}()|\[\]\\])", r"\\\1", search_text) if search_text else None
    )

    return f".*{escaped_search_text}.*" if escaped_search_text else ".*"


# ---------------------------------------------------------------------------
# Korean tokenization pipeline
# ---------------------------------------------------------------------------

# Kiwi 인스턴스 — 모듈 레벨에서 1회 생성, 이후 재사용 (초기화 ~1초)
_kiwi = Kiwi()

# 검색용 추출 대상 품사
# NNG: 일반명사, NNP: 고유명사, SL: 외국어(영문), SN: 숫자
_INCLUDE_TAGS = {"NNG", "NNP", "SL", "SN"}


class KoreanTextNormalizer:
    """텍스트 정규화 — 특수문자 제거, 공백 정리, 영문 소문자화."""

    # 한글, 영숫자, 공백만 남기고 나머지 제거
    _SPECIAL_CHARS_RE = re.compile(r"[^\w\s가-힣]")
    _MULTI_SPACE_RE = re.compile(r"\s+")

    @classmethod
    def normalize(cls, text: str) -> str:
        """Normalize text for tokenization."""
        text = cls._SPECIAL_CHARS_RE.sub(" ", text)
        text = cls._MULTI_SPACE_RE.sub(" ", text).strip()
        return text.lower()


class KoreanTokenizer:
    """Kiwi 형태소 분석 기반 토큰 추출.

    명사, 영문, 숫자만 추출하고 조사/어미는 자동 제외.
    1글자 토큰은 의미가 약하므로 제외한다 ("를", "을" 등 추가 방어).

    Kiwi가 "k8s" 같은 영문+숫자 조합을 "k", "8", "s"로 분리하는 문제가 있으므로,
    공백 구분 단어 중 영숫자 조합(2글자 이상)은 Kiwi 전에 먼저 보존한다.
    """

    # 영문+숫자 조합 패턴 (2글자 이상)
    _ALPHANUMERIC_RE = re.compile(r"[a-z0-9]{2,}")

    @classmethod
    def extract_tokens(cls, text: str) -> set[str]:
        """Extract meaningful tokens (nouns, english, numbers) from text."""
        if not text:
            return set()

        # 1. 영숫자 조합 토큰을 먼저 추출 (Kiwi가 분리하기 전에 보존)
        alphanumeric_tokens = set(cls._ALPHANUMERIC_RE.findall(text))

        # 2. Kiwi 형태소 분석으로 한국어 명사 추출
        kiwi_tokens = {
            t.form.lower()
            for t in _kiwi.tokenize(text)
            if t.tag in _INCLUDE_TAGS and len(t.form) >= 2
        }

        return alphanumeric_tokens | kiwi_tokens


class AliasExpander:
    """도메인 용어 양방향 별칭 확장.

    그룹 내 모든 용어가 서로 alias — "k8s"가 있으면 "kubernetes", "쿠버네티스"도 추가.
    인덱싱 시와 검색 시 모두 같은 확장을 적용하여 양쪽에서 매칭 가능.

    alias 데이터는 search_aliases.yaml 파일에서 로드한다.
    모듈 로드 시 1회 구축하여 메모리에 유지 (~50KB).
    """

    _ALIAS_PATH = os.path.join(os.path.dirname(__file__), "search_aliases.yaml")
    _lookup: dict[str, set[str]] = {}

    @classmethod
    def _build_lookup(cls) -> None:
        """Build the alias lookup table from YAML file.

        같은 term이 여러 그룹에 등장하면 자동으로 merge하여
        alias 체인이 끊기지 않도록 한다.
        """
        if cls._lookup:
            return
        lookup: dict[str, set[str]] = {}
        try:
            with open(cls._ALIAS_PATH, encoding="utf-8") as f:
                data = yaml.safe_load(f)
        except FileNotFoundError:
            import logging

            logging.getLogger(__name__).warning(
                "search_aliases.yaml not found at %s — alias expansion disabled",
                cls._ALIAS_PATH,
            )
            cls._lookup = {}
            return

        if not isinstance(data, dict):
            cls._lookup = {}
            return

        for group in data.get("alias_groups", []):
            normalized = {term.lower() for term in group}
            # 이미 등록된 term이 있으면 기존 그룹과 merge
            for term in normalized:
                if term in lookup:
                    normalized = normalized | lookup[term]
            # merge된 전체 그룹을 모든 term에 할당
            for term in normalized:
                lookup[term] = normalized

        cls._lookup = lookup  # atomic assignment

    @classmethod
    def expand(cls, tokens: set[str]) -> set[str]:
        """Expand tokens with their aliases."""
        expanded = set(tokens)
        for token in tokens:
            if token in cls._lookup:
                expanded.update(cls._lookup[token])
        return expanded


# Eager init — 모듈 로드 시 lookup 테이블 구축 (레이스 컨디션 방지)
AliasExpander._build_lookup()


def build_search_tokens(*, name: str | None, description: str | None) -> list[str]:
    """Build search tokens from Skill name and description.

    파이프라인: normalize → tokenize → alias expand → 중복 제거 → 정렬.
    create/update 시 호출하여 Skill.search_tokens에 저장한다.
    """
    all_tokens: set[str] = set()

    for text in [name, description]:
        if not text:
            continue
        normalized = KoreanTextNormalizer.normalize(text)
        tokens = KoreanTokenizer.extract_tokens(normalized)
        all_tokens.update(tokens)

    # Alias 확장 — "k8s"가 있으면 "kubernetes", "쿠버네티스"도 추가
    all_tokens = AliasExpander.expand(all_tokens)

    return sorted(all_tokens)
