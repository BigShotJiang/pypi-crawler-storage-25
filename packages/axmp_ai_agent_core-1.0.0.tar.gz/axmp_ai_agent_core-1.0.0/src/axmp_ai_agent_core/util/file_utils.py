"""File utilities for Skill file management."""

from __future__ import annotations

import asyncio
import logging
import os
import shutil
import uuid
from pathlib import Path

logger = logging.getLogger(__name__)

ALLOWED_EXTENSIONS = {
    ".py",
    ".js",
    ".ts",
    ".sh",
    ".json",
    ".csv",
    ".txt",
    ".yaml",
    ".yml",
    ".md",
}
MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
MAX_TOTAL_SIZE = 50 * 1024 * 1024  # 50MB


def _validate_path_containment(*, path: str, base: str) -> str:
    """Validate that resolved path is contained within base directory.

    Return the resolved path if valid, raise ValueError if path traversal detected.
    """
    resolved = os.path.realpath(path)
    base_resolved = os.path.realpath(base)
    if not resolved.startswith(base_resolved + os.sep):
        msg = f"Path traversal detected: {path}"
        raise ValueError(msg)
    return resolved


async def save_skill_file(
    *,
    skill_id: str,
    filename: str,
    content: bytes,
    data_path: str,
) -> tuple[str, str]:
    """Save a Skill file to local storage.

    Return (file_id, relative_file_path).
    """
    # Path Traversal 방지 — basename만 추출
    filename = os.path.basename(filename)
    if not filename:
        msg = "Invalid filename"
        raise ValueError(msg)

    # 확장자 검증
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        msg = f"Unsupported file extension: {ext}"
        raise ValueError(msg)

    # 크기 검증
    if len(content) > MAX_FILE_SIZE:
        msg = f"File too large: {len(content)} bytes (max {MAX_FILE_SIZE})"
        raise ValueError(msg)

    # file_id 기반 고유 경로 생성
    file_id = str(uuid.uuid4())
    dir_path = os.path.join(data_path, "skills", skill_id, file_id)
    full_path = os.path.join(dir_path, filename)

    def _write():
        os.makedirs(dir_path, exist_ok=True)
        with open(full_path, "wb") as f:
            f.write(content)

    await asyncio.to_thread(_write)

    # 상대 경로 저장 (data_path 이후 부분)
    relative_path = os.path.join("skills", skill_id, file_id, filename)
    return file_id, relative_path


async def delete_skill_file_from_storage(*, file_path: str, data_path: str) -> bool:
    """Delete a Skill file from storage (removes file_id directory)."""
    full_path = os.path.join(data_path, file_path)
    file_dir = os.path.dirname(full_path)

    # Path traversal 방지
    _validate_path_containment(path=file_dir, base=data_path)

    if os.path.exists(file_dir):
        await asyncio.to_thread(shutil.rmtree, file_dir)
        return True
    return False


async def delete_skill_directory(*, skill_id: str, data_path: str) -> None:
    """Delete the entire skill file directory. Used on Skill deletion."""
    skill_dir = os.path.join(data_path, "skills", skill_id)

    # Path traversal 방지
    try:
        _validate_path_containment(path=skill_dir, base=data_path)
    except ValueError:
        logger.warning(f"Path traversal detected for skill directory: {skill_dir}")
        return

    if os.path.exists(skill_dir):
        try:
            await asyncio.to_thread(shutil.rmtree, skill_dir)
        except OSError:
            logger.warning(f"Failed to delete skill directory: {skill_dir}")
