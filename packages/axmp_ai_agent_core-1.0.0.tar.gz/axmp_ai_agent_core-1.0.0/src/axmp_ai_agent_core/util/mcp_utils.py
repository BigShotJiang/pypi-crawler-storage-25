"""MCP utility functions."""

import re
from urllib.parse import urlparse

from mcp import McpError
from mcp.types import (
    CONNECTION_CLOSED,
    INTERNAL_ERROR,
    INVALID_PARAMS,
    INVALID_REQUEST,
    METHOD_NOT_FOUND,
    PARSE_ERROR,
)


def get_mcp_error_message(mcp_error: McpError, server_name: str) -> tuple[str, str]:
    """Get user-friendly error message and action guidance for MCP errors.

    Args:
        mcp_error: The McpError exception.
        server_name: The name of the MCP server.

    Returns:
        Tuple of (error_message, action_guidance).
    """
    error_code = mcp_error.error.code
    error_message = mcp_error.error.message or str(mcp_error)

    if error_code == CONNECTION_CLOSED:
        return (
            f"MCP server '{server_name}' connection was closed unexpectedly.",
            "Please check if the MCP server is running and accessible. "
            "The connection may have been interrupted. Try reconnecting or check the server status.",
        )
    elif error_code == PARSE_ERROR:
        return (
            f"Failed to parse response from MCP server '{server_name}'. "
            f"Error: {error_message}",
            "The server returned invalid JSON. Please check the MCP server configuration "
            "and ensure the server is responding correctly. Contact the server administrator if the issue persists.",
        )
    elif error_code == INVALID_REQUEST:
        return (
            f"Invalid request sent to MCP server '{server_name}'. "
            f"Error: {error_message}",
            "The request format is incorrect. Please verify the MCP server configuration "
            "and ensure all required parameters are provided correctly.",
        )
    elif error_code == METHOD_NOT_FOUND:
        return (
            f"Requested method not found on MCP server '{server_name}'. "
            f"Error: {error_message}",
            "The MCP server does not support the requested method. "
            "Please check the server capabilities and update your configuration accordingly.",
        )
    elif error_code == INVALID_PARAMS:
        return (
            f"Invalid parameters provided to MCP server '{server_name}'. "
            f"Error: {error_message}",
            "One or more parameters in the request are invalid. "
            "Please review the MCP server configuration and ensure all parameters match the server's requirements.",
        )
    elif error_code == INTERNAL_ERROR:
        return (
            f"Internal error occurred on MCP server '{server_name}'. "
            f"Error: {error_message}",
            "The MCP server encountered an internal error. "
            "Please try again later or contact the server administrator if the issue persists.",
        )
    else:
        return (
            f"Unknown error from MCP server '{server_name}' (code: {error_code}). "
            f"Error: {error_message}",
            "An unexpected error occurred. Please check the MCP server configuration "
            "and try again. If the problem continues, contact support.",
        )


def validate_url(url: str) -> bool:
    """Validate URL pattern.

    Validates that the URL:
    1. Starts with http:// or https://
    2. Matches either a general URL pattern or Kubernetes FQDN pattern

    Args:
        url: The URL string to validate.

    Returns:
        True if the URL is valid, False otherwise.
    """
    if not url:
        return False

    if not url.startswith(("http://", "https://")):
        return False

    try:
        parsed = urlparse(url)
        hostname = parsed.hostname

        if not hostname:
            return False

        # Kubernetes FQDN pattern
        k8s_fqdn_pattern = (
            r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*"
            r"(\.svc(\.cluster\.local)?)?$"
        )

        # General URL hostname pattern
        general_hostname_pattern = (
            r"^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?"
            r"(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$"
        )

        if re.match(k8s_fqdn_pattern, hostname.lower()) or re.match(
            general_hostname_pattern, hostname
        ):
            return True

        return False
    except Exception:
        return False
