"""Secret mask utilities."""


def mask_secret(
    value: str | None,
    /,
    *,
    unmasked_prefix: int = 0,
    unmasked_suffix: int = 0,
    mask_char: str = "*",
) -> str | None:
    """Mask the secret value."""
    if value is None:
        return None
    s = str(value)
    n = len(s)
    # if the length of the string is less than the unmasked prefix and suffix, return the mask character
    if n <= unmasked_prefix + unmasked_suffix:
        return mask_char * n
    if unmasked_suffix:
        return (
            s[:unmasked_prefix]
            + (mask_char * (n - unmasked_prefix - unmasked_suffix))
            + s[-unmasked_suffix:]
        )
    return s[:unmasked_prefix] + (mask_char * (n - unmasked_prefix))
