"""Skill history repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.skill_history import SkillHistory
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters
from axmp_ai_agent_core.util.list_utils import MAX_LIMIT
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class SkillHistoryRepository(BaseRepository[SkillHistory]):
    """Skill history repository."""

    async def insert(
        self, *, item: SkillHistory, session: AsyncIOMotorClientSession | None = None
    ) -> str:
        """Insert a new SkillHistory snapshot."""
        if item.created_at is None:
            item.created_at = datetime.now(DEFAULT_TIME_ZONE)
            item.updated_at = item.created_at

        history_dict = item.model_dump(
            by_alias=True, exclude={"id", "created_at", "updated_at"}
        )
        history_dict["created_at"] = item.created_at
        history_dict["updated_at"] = item.updated_at

        result: InsertOneResult = await self._collection.insert_one(
            history_dict, session=session
        )
        return str(result.inserted_id)

    async def find_by_skill_id(
        self,
        *,
        skill_id: str,
        page_number: int = 1,
        page_size: int = 50,
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[SkillHistory]:
        """Find all history entries for a Skill, newest version first."""
        if page_number < 1:
            page_number = 1
        if page_size < 1:
            page_size = 50

        skip = page_size * (page_number - 1)
        filter = {"skill_id": skill_id}

        cursor = (
            self._collection.find(filter, session=session)
            .sort("version", pymongo.DESCENDING)
            .skip(skip)
            .limit(page_size)
        )

        histories = []
        async for document in cursor:
            histories.append(SkillHistory(**document))

        return histories

    async def find_by_skill_id_and_version(
        self,
        *,
        skill_id: str,
        version: int,
        session: AsyncIOMotorClientSession | None = None,
    ) -> SkillHistory:
        """Find a specific version of a Skill history."""
        filter = {"skill_id": skill_id, "version": version}
        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(f"skill_id={skill_id}, version={version}")

        return SkillHistory(**document)

    async def count_by_skill_id(
        self,
        *,
        skill_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count history entries for a Skill."""
        return await self._collection.count_documents(
            filter={"skill_id": skill_id}, session=session
        )

    async def get_latest_version(
        self,
        *,
        skill_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Get the latest version number for a Skill. Return 0 if no history."""
        document = await self._collection.find_one(
            filter={"skill_id": skill_id},
            sort=[("version", pymongo.DESCENDING)],
            projection={"version": 1},
            session=session,
        )

        if document is None:
            return 0

        return document["version"]

    async def find_versions_by_skill_id(
        self,
        *,
        skill_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[dict[str, Any]]:
        """Find all history entries for a Skill with only _id and version (lightweight).

        Return list of {"id": str, "version": int}, sorted by version ASC (oldest first).
        """
        cursor = self._collection.find(
            {"skill_id": skill_id},
            projection={"_id": 1, "version": 1},
            session=session,
        ).sort("version", pymongo.ASCENDING)

        results = []
        async for document in cursor:
            results.append({"id": str(document["_id"]), "version": document["version"]})

        return results

    async def delete_many_by_ids(
        self,
        *,
        item_ids: list[str],
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Delete multiple history entries by IDs. Return deleted count."""
        if not item_ids:
            return 0

        object_ids = [ObjectId(item_id) for item_id in item_ids]
        result = await self._collection.delete_many(
            filter={"_id": {"$in": object_ids}}, session=session
        )
        return result.deleted_count

    async def exists_with_file_id(
        self,
        *,
        skill_id: str,
        file_id: str,
        exclude_history_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> bool:
        """Check if any other History references the given file_id (excluding one)."""
        try:
            exclude_oid = ObjectId(exclude_history_id)
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        doc = await self._collection.find_one(
            {
                "skill_id": skill_id,
                "files.file_id": file_id,
                "_id": {"$ne": exclude_oid},
            },
            projection={"_id": 1},
            session=session,
        )
        return doc is not None

    async def delete_by_skill_id(
        self,
        *,
        skill_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Delete all history entries for a Skill. Return deleted count."""
        result = await self._collection.delete_many(
            filter={"skill_id": skill_id}, session=session
        )
        return result.deleted_count

    # =========================================================================
    # BaseRepository abstract methods — required but not used for SkillHistory
    # =========================================================================

    async def update(
        self, *, item: SkillHistory, session: AsyncIOMotorClientSession | None = None
    ) -> SkillHistory | None:
        """Not supported — SkillHistory is immutable."""
        raise NotImplementedError("SkillHistory is immutable and cannot be updated")

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete a single SkillHistory entry by ID."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> SkillHistory | None:
        """Find a SkillHistory by ID. Used for cleanup with file handling."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)
        if document is None:
            return None

        return SkillHistory(**document)

    async def find_all(
        self,
        *,
        query_parameters: BaseQueryParameters,
        page_number: int = 1,
        page_size: int = 50,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[SkillHistory]:
        """Not supported — use find_by_skill_id instead."""
        raise NotImplementedError("Use find_by_skill_id instead")

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: BaseQueryParameters,
        max_limit: int = MAX_LIMIT,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[SkillHistory]:
        """Not supported — use find_by_skill_id instead."""
        raise NotImplementedError("Use find_by_skill_id instead")

    async def count(
        self,
        *,
        query_parameters: BaseQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Not supported — use count_by_skill_id instead."""
        raise NotImplementedError("Use count_by_skill_id instead")

    async def find_all_query(
        self,
        *,
        query_parameters: BaseQueryParameters,
    ) -> dict[str, Any]:
        """Not supported."""
        raise NotImplementedError("Not supported for SkillHistory")
