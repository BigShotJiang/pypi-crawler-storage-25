"""MongoDB collection name constants."""

from enum import StrEnum


class CollectionName(StrEnum):
    """MongoDB collection name constant."""

    # Agent
    AGENT_PROFILE = "agent_profile"
    AGENT_PROFILE_HISTORY = "agent_profile_history"
    AGENT_PROVISION_STATUS = "agent_provision_status"
    AGENT_CATALOG = "agent_catalog"

    # MCP
    MCP_SERVER_PROFILE = "mcp_server_profile"
    MCP_SERVER_PROFILE_HISTORY = "mcp_server_profile_history"
    MCP_SERVER_PROVISION_STATUS = "mcp_server_provision_status"
    MCP_REGISTRY = "mcp_registry"

    # Skill
    SKILL = "skill"
    SKILL_HISTORY = "skill_history"
    SKILL_LIKE = "skill_like"

    # Chat
    CONVERSATION = "chat_conversation"
    CHAT_FILE = "chat_file"
    CHAT_MEMORY = "chat_memory"

    # Auth
    USER = "oauth_user"
    GROUP = "groups"
    ROLE = "roles"
    USER_CREDENTIAL = "user_credential"
    OAUTH_PROVIDER = "oauth_provider"

    # Backend Server
    BACKEND_SERVER = "backend_server"

    # LLM
    LLM_PROVIDER = "llm_provider"

    # Infra
    KUBERNETES_CONFIG = "kubernetes_config"
