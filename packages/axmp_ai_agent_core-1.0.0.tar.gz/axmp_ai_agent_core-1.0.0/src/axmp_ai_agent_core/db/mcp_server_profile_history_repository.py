"""MCP server profile history repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.mcp_server_profile_history import McpServerProfileHistory
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.mcp_server_profile_history_query import (
    McpServerProfileHistoryQueryParameters,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE
from axmp_ai_agent_core.util.version_utils import parse_version

logger = logging.getLogger("appLogger")


class McpServerProfileHistoryRepository(BaseRepository[McpServerProfileHistory]):
    """MCP server profile history repository."""

    async def get_max_version(
        self,
        *,
        mcp_server_profile_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Get the max version of the MCP server profile history."""
        cursor = self._collection.aggregate(
            [
                {"$match": {"mcp_server_profile_id": mcp_server_profile_id}},
                {"$group": {"_id": None, "maxVersion": {"$max": "$version"}}},
            ],
            session=session,
        )
        documents = await cursor.to_list(length=1)
        if not documents or len(documents) == 0:
            return 0
        max_version = documents[0]["maxVersion"]
        # Handle legacy string version format (e.g., "v1", "v2")
        if isinstance(max_version, str):
            return parse_version(max_version)
        return max_version

    async def insert(
        self,
        *,
        item: McpServerProfileHistory,
        session: AsyncIOMotorClientSession | None = None,
    ) -> str:
        """Insert a new MCP server profile history into the repository."""
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)

        history_dict = item.model_dump(by_alias=True, exclude=["id"])
        history_dict["created_at"] = item.created_at

        result: InsertOneResult = await self._collection.insert_one(
            history_dict, session=session
        )

        return str(result.inserted_id)

    async def update(
        self,
        *,
        item: McpServerProfileHistory,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProfileHistory | None:
        """Update an MCP server profile history in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        history_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
            ],
        )
        history_dict["updated_at"] = item.updated_at

        update = [{"$set": history_dict}]

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        if document is None:
            raise ObjectNotFoundException(item.id)

        return McpServerProfileHistory(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete an MCP server profile history from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> McpServerProfileHistory | None:
        """Find an MCP server profile history by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return McpServerProfileHistory(**document)

    async def find_by_profile_id_and_version(
        self,
        *,
        profile_id: str,
        version: int,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProfileHistory | None:
        """Find an MCP server profile history by profile_id and version."""
        try:
            filter = {"mcp_server_profile_id": profile_id, "version": version}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(f"{profile_id}:{version}")

        return McpServerProfileHistory(**document)

    async def find_by_profile_id_with_pagination(
        self,
        *,
        profile_id: str,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[McpServerProfileHistory]:
        """Find all history entries for a specific profile with pagination."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        filter = {"mcp_server_profile_id": profile_id}
        logger.debug(f"Searching history with filter: {filter}")

        cursor = (
            self._collection.find(filter, session=session)
            .sort("version", pymongo.DESCENDING)
            .skip(skip)
            .limit(limit)
        )

        history_entries = []
        async for document in cursor:
            if document is not None:
                history_entries.append(McpServerProfileHistory(**document))

        return history_entries

    async def find_all(
        self,
        *,
        query_parameters: McpServerProfileHistoryQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = [
            "mcp_server_profile_data",
        ],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[McpServerProfileHistory]:
        """Find all MCP server profile histories in the repository."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "created_at"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(
                filter, projection=projection if projection else None, session=session
            )
            .sort(sort_field, direction)
            .skip(skip)
            .limit(limit)
        )

        histories = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    histories.append(McpServerProfileHistory(**document))

        return histories

    async def count(
        self,
        *,
        query_parameters: McpServerProfileHistoryQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of MCP server profile histories in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        return await self._collection.count_documents(filter=filter)

    async def find_all_query(
        self, *, query_parameters: McpServerProfileHistoryQueryParameters
    ) -> Dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter: Dict[str, Any] = {}

        if query_parameters.mcp_server_profile_id:
            filter["mcp_server_profile_id"] = query_parameters.mcp_server_profile_id

        if query_parameters.created_by:
            filter["created_by"] = query_parameters.created_by

        if query_parameters.updated_by:
            filter["updated_by"] = query_parameters.updated_by

        if query_parameters.access_permission:
            filter.update(
                await self._build_shared_target_filter(
                    access_permission=query_parameters.access_permission
                )
            )

        return filter

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: McpServerProfileHistoryQueryParameters,
        max_limit: int = MAX_LIMIT,  # if max_limit is 0, don't apply limit
        exclude_fields: list[str] = [
            "mcp_server_profile_data",
        ],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[McpServerProfileHistory]:
        """Find all MCP server profile histories without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "created_at"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        # Create base cursor without limit
        # Note: Now includes all fields including api_spec
        cursor = (
            self._collection.find(
                filter, projection=projection if projection else None, session=session
            )
            .sort(sort_field, direction)
            .limit(max_limit)
        )

        histories = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    histories.append(McpServerProfileHistory(**document))

        logger.debug(f"Found {len(histories)} history entries")

        return histories

    async def delete_by_profile_id(
        self, *, profile_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> int:
        """Delete all history records for a specific profile by mcp_server_profile_id."""
        try:
            filter = {"mcp_server_profile_id": profile_id}

            # Count documents before deletion for logging
            # count_before = await self._collection.count_documents(filter)

            # Delete all matching documents
            result = await self._collection.delete_many(filter, session=session)

            deleted_count = result.deleted_count
            logger.info(
                f"Deleted {deleted_count} history records for profile {profile_id}"
            )

            return deleted_count

        except Exception as e:
            logger.error(
                f"Error deleting history records for profile {profile_id}: {e}"
            )
            raise

    async def delete_oldest_versions(
        self,
        *,
        profile_id: str,
        keep_count: int = 50,
        provisioned_versions: list[int] | None = None,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Delete oldest history versions for a specific profile, keeping only the latest ones.

        Optimized: Uses MongoDB query-level filtering to minimize memory usage.
        - count_documents() for counting (no document loading)
        - projection to fetch only _id field
        - $nin operator for DB-level filtering of protected versions
        - limit to fetch only deletion candidates

        Args:
            profile_id: The ID of the MCP server profile
            keep_count: Number of latest versions to keep (default: 50)
            provisioned_versions: List of version numbers that are currently deployed
                and should be protected from deletion. When multiple clusters have
                different versions deployed, all deployed versions are protected.

        Returns:
            Number of deleted history records
        """
        try:
            # 1. Count total documents (no document loading)
            total_count = await self._collection.count_documents(
                {"mcp_server_profile_id": profile_id},
                session=session,
            )

            if total_count <= keep_count:
                logger.info(f"No deletion needed: {total_count} <= {keep_count}")
                return 0

            # 2. Calculate number of documents to delete
            delete_count = total_count - keep_count

            # 3. Build query with DB-level filtering for protected versions
            query: Dict[str, Any] = {"mcp_server_profile_id": profile_id}

            # Use $nin to exclude protected versions at DB level
            if provisioned_versions:
                query["version"] = {"$nin": provisioned_versions}

            # 4. Fetch only _id of deletion candidates (projection + limit)
            cursor = (
                self._collection.find(
                    query,
                    {"_id": 1},  # projection: fetch only _id
                    session=session,
                )
                .sort("version", pymongo.ASCENDING)  # Oldest first
                .limit(delete_count)
            )

            ids_to_delete = [doc["_id"] async for doc in cursor]

            if not ids_to_delete:
                return 0

            # 5. Execute deletion
            result = await self._collection.delete_many(
                {"_id": {"$in": ids_to_delete}},
                session=session,
            )

            logger.info(
                f"Retention policy applied: deleted {result.deleted_count} oldest history records "
                f"for profile {profile_id}, keeping {keep_count} latest versions"
            )

            return result.deleted_count

        except Exception as e:
            logger.error(
                f"Error applying retention policy for profile {profile_id}: {e}"
            )
            raise
