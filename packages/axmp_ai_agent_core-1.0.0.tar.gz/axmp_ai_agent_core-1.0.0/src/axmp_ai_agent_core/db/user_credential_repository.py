"""User credential repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import pymongo
from axmp_openapi_helper import AuthenticationType
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult
from zmp_authentication_provider.utils.encryption_utils import decrypt, encrypt

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.shared_target import SharedTarget
from axmp_ai_agent_core.entity.user_credential import (
    AWS_BEDROCK,
    UserCredential,
    UserCredentialType,
)
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
    ValueErrorException,
)
from axmp_ai_agent_core.filter.user_credential_query import (
    UserCredentialQueryParameters,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class UserCredentialRepository(BaseRepository[UserCredential]):
    """User credential repository."""

    def _encrypt_auth_config(self, auth_config) -> dict:
        """Encrypt sensitive fields in auth_config and return as dict."""
        if auth_config.type == AuthenticationType.BASIC:
            return {
                "type": auth_config.type,
                "username": auth_config.username,
                "password": encrypt(auth_config.password).hex(),
            }
        elif auth_config.type == AuthenticationType.BEARER:
            return {
                "type": auth_config.type,
                "bearer_token": encrypt(auth_config.bearer_token).hex(),
            }
        elif auth_config.type == AuthenticationType.API_KEY:
            return {
                "type": auth_config.type,
                "api_key_name": auth_config.api_key_name,
                "api_key_value": encrypt(auth_config.api_key_value).hex(),
            }
        elif auth_config.type == AuthenticationType.OAUTH:
            return {
                "type": auth_config.type,
                "oauth_provider_id": auth_config.oauth_provider_id,
                "client_id": auth_config.client_id,
                "client_secret": encrypt(auth_config.client_secret).hex(),
                "grant_type": auth_config.grant_type,
                "scopes": auth_config.scopes,
                "forward_token_to_backend": auth_config.forward_token_to_backend,
            }
        elif auth_config.type == AuthenticationType.NONE:
            return {
                "type": auth_config.type,
            }
        else:
            raise ValueErrorException(
                f"Unsupported authentication type: {auth_config.type}"
            )

    def _encrypt_llm_credential(self, item: UserCredential) -> dict:
        """Encrypt LLM provider credential fields and return as dict."""
        if item.provider == AWS_BEDROCK:
            return {
                "aws_access_key_id": encrypt(item.aws_access_key_id).hex(),
                "aws_secret_access_key": encrypt(item.aws_secret_access_key).hex(),
                "region_name": item.region_name,
            }
        return {"llm_api_key": encrypt(item.llm_api_key).hex()}

    def _encrypt_credential(
        self, *, item: UserCredential, credential_dict: dict
    ) -> None:
        """Encrypt credential fields in-place based on credential type."""
        if item.credential_type == UserCredentialType.LLM_PROVIDER:
            credential_dict.update(self._encrypt_llm_credential(item))
        elif item.auth_config is not None:
            credential_dict["auth_config"] = self._encrypt_auth_config(item.auth_config)

    def _decrypt_auth_config(self, auth_config) -> dict:
        """Decrypt sensitive fields in auth_config and return as dict."""
        if auth_config.type == AuthenticationType.BASIC:
            return {
                "type": auth_config.type,
                "username": auth_config.username,
                "password": decrypt(bytes.fromhex(auth_config.password)),
            }
        elif auth_config.type == AuthenticationType.BEARER:
            return {
                "type": auth_config.type,
                "bearer_token": decrypt(bytes.fromhex(auth_config.bearer_token)),
            }
        elif auth_config.type == AuthenticationType.API_KEY:
            return {
                "type": auth_config.type,
                "api_key_name": auth_config.api_key_name,
                "api_key_value": decrypt(bytes.fromhex(auth_config.api_key_value)),
            }
        elif auth_config.type == AuthenticationType.OAUTH:
            return {
                "type": auth_config.type,
                "oauth_provider_id": auth_config.oauth_provider_id,
                "client_id": auth_config.client_id,
                "client_secret": decrypt(bytes.fromhex(auth_config.client_secret)),
                "grant_type": auth_config.grant_type,
                "scopes": auth_config.scopes,
                "forward_token_to_backend": auth_config.forward_token_to_backend,
            }
        elif auth_config.type == AuthenticationType.NONE:
            return {
                "type": auth_config.type,
            }
        else:
            raise ValueErrorException(
                f"Unsupported authentication type: {auth_config.type}"
            )

    def _decrypt_llm_credential(self, credential: UserCredential) -> None:
        """Decrypt LLM provider credential fields in-place."""
        if credential.provider == AWS_BEDROCK:
            if credential.aws_access_key_id is not None:
                credential.aws_access_key_id = decrypt(
                    bytes.fromhex(credential.aws_access_key_id)
                )
            if credential.aws_secret_access_key is not None:
                credential.aws_secret_access_key = decrypt(
                    bytes.fromhex(credential.aws_secret_access_key)
                )
        else:
            if credential.llm_api_key is not None:
                credential.llm_api_key = decrypt(bytes.fromhex(credential.llm_api_key))

    def _decrypt_credential(self, credential: UserCredential) -> None:
        """Decrypt credential fields in-place based on credential type."""
        if credential.credential_type == UserCredentialType.LLM_PROVIDER:
            self._decrypt_llm_credential(credential)
        elif credential.auth_config is not None:
            credential.auth_config = self._decrypt_auth_config(credential.auth_config)

    async def insert(
        self, *, item: UserCredential, session: AsyncIOMotorClientSession | None = None
    ) -> str:
        """Insert a new user credential into the repository."""
        if item.created_at is None:
            item.created_at = datetime.now(DEFAULT_TIME_ZONE)
            item.updated_at = item.created_at

        user_credential_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at", "updated_at"]
        )
        user_credential_dict["created_at"] = item.created_at
        user_credential_dict["updated_at"] = item.updated_at

        self._encrypt_credential(item=item, credential_dict=user_credential_dict)

        result: InsertOneResult = await self._collection.insert_one(
            user_credential_dict, session=session
        )

        return str(result.inserted_id)

    async def update(
        self, *, item: UserCredential, session: AsyncIOMotorClientSession | None = None
    ) -> UserCredential | None:
        """Update a user credential in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        if item.updated_at is None:
            item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        user_credential_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
                "shared_target",
            ],
        )
        user_credential_dict["updated_at"] = item.updated_at

        update = {"$set": user_credential_dict}

        self._encrypt_credential(item=item, credential_dict=user_credential_dict)

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )
        if document is None:
            raise ObjectNotFoundException(item.id)

        updated = UserCredential(**document)
        self._decrypt_credential(updated)

        return updated

    async def update_shared_target(
        self,
        *,
        item_id: str,
        shared_target: SharedTarget,
        updated_by: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> UserCredential:
        """Update only shared_target and audit fields for a user credential."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        updated_at = datetime.now(DEFAULT_TIME_ZONE)

        update = [
            {
                "$set": {
                    "shared_target": shared_target.model_dump(),
                    "updated_by": updated_by,
                    "updated_at": updated_at,
                }
            }
        ]

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        if document is None:
            raise ObjectNotFoundException(item_id)

        return UserCredential(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete a user credential from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> UserCredential | None:
        """Find a user credential by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        user_credential = UserCredential(**document)
        self._decrypt_credential(user_credential)

        return user_credential

    async def count_by_provider_key(
        self, *, provider_key: str, session: AsyncIOMotorClientSession | None = None
    ) -> int:
        """Count the number of user credentials by provider key."""
        filter = {"provider": provider_key}
        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all(
        self,
        *,
        query_parameters: UserCredentialQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = [
            "llm_api_key",
            "auth_config.api_key_value",
            "auth_config.password",
            "auth_config.bearer_token",
            "auth_config.client_secret",
        ],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[UserCredential]:
        """Find all user credentials in the repository."""
        if exclude_fields and include_fields:
            if len(exclude_fields) > 0 and len(include_fields) > 0:
                raise ValueErrorException(
                    "exclude_fields and include_fields cannot be used together"
                )

        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        logger.debug(
            f"page_number={page_number}, page_size={page_size} so skip: {skip}, limit: {limit}"
        )

        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "display_name"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .skip(skip)
            .limit(limit)
        )

        user_credentials = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    user_credentials.append(UserCredential(**document))

        return user_credentials

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: UserCredentialQueryParameters,
        max_limit: int = MAX_LIMIT,  # if max_limit is 0, don't apply limit
        exclude_fields: list[str] = [
            "llm_api_key",
            "auth_config.api_key_value",
            "auth_config.password",
            "auth_config.bearer_token",
            "auth_config.client_secret",
        ],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[UserCredential]:
        """Find all user credentials in the repository without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "display_name"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = self._collection.find(
            filter, projection=projection, session=session
        ).sort(sort_field, direction)

        if max_limit > 0:
            cursor = cursor.limit(max_limit)

        user_credentials = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    user_credentials.append(UserCredential(**document))

        logger.debug(f"Found {len(user_credentials)} user credentials")

        return user_credentials

    async def count(
        self,
        *,
        query_parameters: UserCredentialQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of user credentials in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self, *, query_parameters: UserCredentialQueryParameters
    ) -> dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter: dict[str, Any] = {}

        if query_parameters.username:
            filter["username"] = query_parameters.username

        if query_parameters.credential_type:
            filter["credential_type"] = query_parameters.credential_type.value

        if query_parameters.access_permission:
            shared_target_filter = await self._build_shared_target_filter(
                access_permission=query_parameters.access_permission
            )
            if filter:
                filter = {"$and": [filter, shared_target_filter]}
            else:
                filter = shared_target_filter

        return filter
