"""Kubernetes configuration repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.kubernetes_config import KubernetesConfig
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.configuration_query import (
    KubernetesConfigQueryParameters,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class KubernetesConfigRepository(BaseRepository[KubernetesConfig]):
    """Kubernetes configuration repository."""

    async def insert(
        self,
        *,
        item: KubernetesConfig,
        session: AsyncIOMotorClientSession | None = None,
    ) -> str:
        """Insert a new kubernetes configuration into the repository."""
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)

        kubernetes_config_dict = item.model_dump(by_alias=True, exclude=["id"])
        kubernetes_config_dict["created_at"] = item.created_at

        result: InsertOneResult = await self._collection.insert_one(
            kubernetes_config_dict, session=session
        )

        return str(result.inserted_id)

    async def update(
        self,
        *,
        item: KubernetesConfig,
        session: AsyncIOMotorClientSession | None = None,
    ) -> KubernetesConfig | None:
        """Update a kubernetes configuration in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        kubernetes_config_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
            ],
        )
        kubernetes_config_dict["updated_at"] = item.updated_at

        update = {"$set": kubernetes_config_dict}

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )
        if document is None:
            raise ObjectNotFoundException(item.id)

        return KubernetesConfig(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete a kubernetes configuration from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        await self._collection.find_one_and_delete(query, session=session)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> KubernetesConfig | None:
        """Find a kubernetes configuration by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return KubernetesConfig(**document)

    async def find_all(
        self,
        *,
        query_parameters: KubernetesConfigQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: List[str] = [],
        include_fields: List[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[KubernetesConfig]:
        """Find all kubernetes configurations in the repository."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        logger.debug(
            f"page_number={page_number}, page_size={page_size} so skip: {skip}, limit: {limit}"
        )

        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "name"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .skip(skip)
            .limit(limit)
        )

        kubernetes_configs = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    kubernetes_configs.append(KubernetesConfig(**document))

        return kubernetes_configs

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: KubernetesConfigQueryParameters,
        max_limit: int = MAX_LIMIT,
        include_fields: List[str] = [],
        exclude_fields: List[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[KubernetesConfig]:
        """Find all kubernetes configurations in the repository without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "name"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .limit(max_limit)
        )

        kubernetes_configs = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    kubernetes_configs.append(KubernetesConfig(**document))

        return kubernetes_configs

    async def count(
        self,
        *,
        query_parameters: KubernetesConfigQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count kubernetes configurations in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self, *, query_parameters: KubernetesConfigQueryParameters
    ) -> Dict[str, Any]:
        """Build query filter for find_all operations."""
        filter = {}

        if query_parameters.name is not None:
            filter["name"] = {
                "$regex": get_escaped_regex_pattern(query_parameters.name),
                "$options": "i",
            }

        if query_parameters.description is not None:
            filter["description"] = {
                "$regex": get_escaped_regex_pattern(query_parameters.description),
                "$options": "i",
            }

        if query_parameters.status is not None:
            filter["status"] = query_parameters.status.value

        if query_parameters.created_by is not None:
            filter["created_by"] = {
                "$regex": get_escaped_regex_pattern(query_parameters.created_by),
                "$options": "i",
            }

        if query_parameters.updated_by is not None:
            filter["updated_by"] = {
                "$regex": get_escaped_regex_pattern(query_parameters.updated_by),
                "$options": "i",
            }

        # Handle labels search
        if query_parameters.labels is not None and len(query_parameters.labels) > 0:
            label_conditions = []
            for label in query_parameters.labels:
                if ":" in label:
                    key, value = label.split(":", 1)
                    label_conditions.append(
                        {
                            f"labels.{key}": {
                                "$regex": get_escaped_regex_pattern(value),
                                "$options": "i",
                            }
                        }
                    )
                else:
                    # Search in all label values
                    label_conditions.append(
                        {
                            "labels": {
                                "$regex": get_escaped_regex_pattern(label),
                                "$options": "i",
                            }
                        }
                    )

            if len(label_conditions) == 1:
                filter.update(label_conditions[0])
            else:
                filter["$and"] = label_conditions

        return filter
