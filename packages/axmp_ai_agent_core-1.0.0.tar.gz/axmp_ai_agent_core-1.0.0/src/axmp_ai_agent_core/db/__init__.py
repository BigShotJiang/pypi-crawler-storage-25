"""Repository layer for MongoDB async operations via Motor driver."""
