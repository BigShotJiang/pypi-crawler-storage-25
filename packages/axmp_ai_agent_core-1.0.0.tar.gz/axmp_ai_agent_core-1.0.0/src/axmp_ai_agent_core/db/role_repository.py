"""Role repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.errors import DuplicateKeyError
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.user_rbac import (
    Role,
)
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
    ValueErrorException,
)
from axmp_ai_agent_core.filter.user_rbac_query import RoleQueryParameters
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class RoleRepository(BaseRepository[Role]):
    """Role repository."""

    async def insert(
        self, *, item: Role, session: AsyncIOMotorClientSession | None = None
    ) -> str:
        """Insert a role into the repository."""
        if item.created_at is None:
            item.created_at = datetime.now(DEFAULT_TIME_ZONE)

        role_dict = item.model_dump(by_alias=True, exclude=["id"])
        role_dict["created_at"] = item.created_at

        try:
            result: InsertOneResult = await self._collection.insert_one(
                role_dict, session=session
            )

            return str(result.inserted_id)
        except DuplicateKeyError as e:
            raise ValueErrorException(
                f"Role name {item.name} already exists. Details: {e}"
            )

    async def update(
        self, *, item: Role, session: AsyncIOMotorClientSession | None = None
    ) -> Role | None:
        """Update a role in the repository."""
        if item.id is None:
            raise InvalidObjectIDException("Role ID is required for update")

        try:
            object_id = ObjectId(item.id)
        except (InvalidId, TypeError):
            raise InvalidObjectIDException(f"Invalid ObjectId: {item.id}")

        if item.updated_at is None:
            item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        role_dict = item.model_dump(by_alias=True, exclude=["id"])
        role_dict["updated_at"] = item.updated_at

        result = await self._collection.find_one_and_update(
            filter={"_id": object_id},
            update={"$set": role_dict},
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        if result is None:
            raise ObjectNotFoundException(f"Role with ID {item.id} not found")

        return Role(**result)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete a role from the repository."""
        try:
            object_id = ObjectId(item_id)
        except (InvalidId, TypeError):
            raise InvalidObjectIDException(f"Invalid ObjectId: {item_id}")

        result = await self._collection.find_one_and_delete(
            filter={"_id": object_id}, session=session
        )

        if result is None:
            raise ObjectNotFoundException(f"Role with ID {item_id} not found")

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> Role:
        """Find a role by ID."""
        try:
            object_id = ObjectId(item_id)
        except (InvalidId, TypeError):
            raise InvalidObjectIDException(f"Invalid ObjectId: {item_id}")

        document = await self._collection.find_one(
            filter={"_id": object_id}, session=session
        )

        if document is None:
            raise ObjectNotFoundException(f"Role with ID {item_id} not found")

        return Role(**document)

    async def find_by_name(
        self, *, name: str, session: AsyncIOMotorClientSession | None = None
    ) -> Role:
        """Find a role by name."""
        document = await self._collection.find_one(
            filter={"name": name}, session=session
        )

        if document is None:
            raise ObjectNotFoundException(f"Role with name {name} not found")

        return Role(**document)

    async def find_all(
        self,
        *,
        query_parameters: RoleQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] | None = None,
        include_fields: list[str] | None = None,
    ) -> list[Role]:
        """Find all roles with pagination and filtering."""
        if page_number is None or page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER

        if page_size is None or page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        query_filter = await self.find_all_query(query_parameters=query_parameters)

        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        sort_field = query_parameters.sort_field
        sort_order = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        skip = (page_number - 1) * page_size
        limit = min(page_size, MAX_LIMIT)

        cursor = (
            self._collection.find(query_filter, projection=projection, session=session)
            .sort(sort_field, sort_order)
            .skip(skip)
            .limit(limit)
        )

        roles = []
        async for document in cursor:
            roles.append(Role(**document))

        return roles

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: RoleQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
        exclude_fields: list[str] | None = None,
        include_fields: list[str] | None = None,
    ) -> list[Role]:
        """Find all roles without pagination."""
        query_filter = await self.find_all_query(query_parameters=query_parameters)

        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        sort_field = query_parameters.sort_field
        sort_order = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        cursor = (
            self._collection.find(query_filter, projection=projection, session=session)
            .sort(sort_field, sort_order)
            .limit(MAX_LIMIT)
        )

        roles = []
        async for document in cursor:
            roles.append(Role(**document))

        return roles

    async def count(
        self,
        *,
        query_parameters: RoleQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count roles based on query parameters."""
        query_filter = await self.find_all_query(query_parameters=query_parameters)
        return await self._collection.count_documents(query_filter, session=session)

    async def find_all_query(
        self, *, query_parameters: RoleQueryParameters
    ) -> dict[str, Any]:
        """Build query filter for find_all operations."""
        query_filter: dict[str, Any] = {}

        if query_parameters.keyword:
            escaped_keyword = get_escaped_regex_pattern(query_parameters.keyword)
            query_filter["$or"] = [
                {"name": {"$regex": escaped_keyword, "$options": "i"}},
                {"description": {"$regex": escaped_keyword, "$options": "i"}},
            ]

        if query_parameters.types:
            query_filter["type"] = {"$in": query_parameters.types}

        return query_filter
