"""MCP server provision status repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.mcp_server_provision_status import (
    McpServerProvisionStatus,
)
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.mcp_server_provision_status_query import (
    McpServerProvisionStatusQueryParameters,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class McpServerProvisionStatusRepository(
    BaseRepository[McpServerProvisionStatus],
):
    """MCP server provision status repository."""

    async def find_non_terminated_statuses(
        self, *, session: AsyncIOMotorClientSession | None = None
    ) -> list[McpServerProvisionStatus]:
        """Find all provision statuses except TERMINATED."""
        filter_query = {"status": {"$ne": "TERMINATED"}}

        cursor = self._collection.find(filter_query, session=session)
        documents = []

        async for document in cursor:
            documents.append(McpServerProvisionStatus(**document))

        return documents

    async def upsert_by_profile_and_cluster(
        self,
        *,
        item: McpServerProvisionStatus,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProvisionStatus:
        """Upsert (insert or update) an MCP server provision status by profile_id and cluster_id."""
        filter = {
            "profile_id": item.profile_id,
            "cluster_id": item.cluster_id,
        }

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)

        provision_status_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at"]
        )
        provision_status_dict["updated_at"] = item.updated_at

        update = {
            "$set": provision_status_dict,
            "$setOnInsert": {"created_at": item.created_at},
        }

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            upsert=True,
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        return McpServerProvisionStatus(**document)

    async def insert(
        self,
        *,
        item: McpServerProvisionStatus,
        session: AsyncIOMotorClientSession | None = None,
    ) -> str:
        """Insert a new MCP server provision status into the repository."""
        created_at = datetime.now(DEFAULT_TIME_ZONE)

        item_dict = item.model_dump(by_alias=True, exclude=["id"])
        item_dict["created_at"] = created_at

        result: InsertOneResult = await self._collection.insert_one(
            item_dict, session=session
        )
        return str(result.inserted_id)

    async def update(
        self,
        *,
        item: McpServerProvisionStatus,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProvisionStatus | None:
        """Update a MCP server provision status in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        updated_at = datetime.now(DEFAULT_TIME_ZONE)

        item_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
            ],
        )
        item_dict["updated_at"] = updated_at
        update = {"$set": item_dict}

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        if document is None:
            raise ObjectNotFoundException(item.id)

        return McpServerProvisionStatus(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete a MCP server provision status from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> McpServerProvisionStatus:
        """Find a MCP server provision status by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return McpServerProvisionStatus(**document)

    async def find_by_cluster_and_name_and_namespace(
        self,
        *,
        cluster_id: str,
        name: str,
        namespace: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProvisionStatus | None:
        """Find an MCP server provision status by cluster_id, name, and namespace."""
        filter_query = {"cluster_id": cluster_id, "name": name, "namespace": namespace}
        document = await self._collection.find_one(filter=filter_query, session=session)
        if document is None:
            return None
        return McpServerProvisionStatus(**document)

    async def find_by_profile_id(
        self, *, profile_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> list[McpServerProvisionStatus]:
        """Find all MCP server provision statuses by profile ID."""
        filter_query = {"profile_id": profile_id}

        cursor = self._collection.find(filter_query, session=session)
        documents = []

        async for document in cursor:
            documents.append(McpServerProvisionStatus(**document))

        return documents

    async def find_by_profile_id_and_cluster_id(
        self,
        *,
        profile_id: str,
        cluster_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProvisionStatus:
        """Find a MCP server provision status by profile ID and cluster ID."""
        filter_query = {
            "profile_id": profile_id,
            "cluster_id": cluster_id,
        }

        document = await self._collection.find_one(filter=filter_query, session=session)

        if document is None:
            raise ObjectNotFoundException(f"{profile_id}:{cluster_id}")

        return McpServerProvisionStatus(**document)

    async def find_by_cluster_id(
        self,
        *,
        cluster_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[McpServerProvisionStatus]:
        """Find all MCP server provision statuses by cluster ID."""
        filter_query = {"cluster_id": cluster_id}

        cursor = self._collection.find(filter_query, session=session)
        documents = []

        async for document in cursor:
            documents.append(McpServerProvisionStatus(**document))

        return documents

    async def find_by_profile_id_and_version_and_cluster_id(
        self,
        *,
        profile_id: str,
        profile_version: int,
        cluster_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProvisionStatus:
        """Find a MCP server provision status by profile ID and version and cluster ID."""
        filter_query = {
            "profile_id": profile_id,
            "profile_version": profile_version,
            "cluster_id": cluster_id,
        }

        document = await self._collection.find_one(filter=filter_query, session=session)

        if document is None:
            raise ObjectNotFoundException(
                f"{profile_id}:{profile_version}:{cluster_id}"
            )

        return McpServerProvisionStatus(**document)

    async def find_all(
        self,
        *,
        query_parameters: McpServerProvisionStatusQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[McpServerProvisionStatus]:
        """Find all MCP server provision statuses with pagination."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        filter_query = await self.find_all_query(query_parameters=query_parameters)

        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        sort_field = query_parameters.sort_field
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        skip = (page_number - 1) * page_size
        limit = min(page_size, MAX_LIMIT)

        cursor = (
            self._collection.find(filter_query, projection=projection, session=session)
            .sort(sort_field, direction)
            .skip(skip)
            .limit(limit)
        )

        documents = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    documents.append(McpServerProvisionStatus(**document))

        return documents

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: McpServerProvisionStatusQueryParameters,
        max_limit: int = MAX_LIMIT,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[McpServerProvisionStatus]:
        """Find all MCP server provision statuses without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "created_at"

        filter_query = await self.find_all_query(query_parameters=query_parameters)

        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter_query, projection=projection, session=session)
            .sort(sort_field, direction)
            .limit(max_limit if max_limit > 0 else MAX_LIMIT)
        )

        documents = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    documents.append(McpServerProvisionStatus(**document))

        return documents

    async def count(
        self,
        *,
        query_parameters: McpServerProvisionStatusQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of MCP server provision statuses."""
        filter_query = await self.find_all_query(query_parameters=query_parameters)
        return await self._collection.count_documents(
            filter=filter_query, session=session
        )

    async def find_all_query(
        self,
        *,
        query_parameters: McpServerProvisionStatusQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter_query: dict[str, Any] = {}

        if query_parameters.keyword:
            keyword_regex = {
                "$regex": get_escaped_regex_pattern(query_parameters.keyword),
                "$options": "i",
            }
            filter_query["$or"] = [
                {"profile_id": keyword_regex},
                {"cluster_id": keyword_regex},
                {"name": keyword_regex},
                {"description": keyword_regex},
            ]

        if query_parameters.profile_id:
            filter_query["profile_id"] = query_parameters.profile_id

        if query_parameters.profile_version:
            filter_query["profile_version"] = query_parameters.profile_version

        if query_parameters.cluster_id:
            filter_query["cluster_id"] = query_parameters.cluster_id

        if query_parameters.instance_id:
            filter_query["instance_id"] = query_parameters.instance_id

        if query_parameters.is_published is not None:
            filter_query["is_published"] = query_parameters.is_published

        if query_parameters.status:
            filter_query["status"] = query_parameters.status

        if query_parameters.name:
            filter_query["name"] = query_parameters.name

        if query_parameters.namespace:
            filter_query["namespace"] = query_parameters.namespace

        return filter_query

    async def find_by_instance_id(
        self,
        *,
        instance_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProvisionStatus | None:
        """Find a MCP server provision status by instance ID.

        Args:
            instance_id: The unique instance ID (from K8s label 'instance-id')
            session: Optional MongoDB session for transaction support

        Returns:
            McpServerProvisionStatus if found, None otherwise
        """
        filter_query = {"instance_id": instance_id}

        document = await self._collection.find_one(filter=filter_query, session=session)

        if document is None:
            return None

        return McpServerProvisionStatus(**document)

    async def remove_provision_statuses_by_profile_id(
        self, *, profile_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> int:
        """Remove all provision statuses by profile ID.

        Args:
            profile_id: The profile ID to remove all provision statuses for

        Returns:
            Number of deleted documents
        """
        filter_query = {"profile_id": profile_id}

        result = await self._collection.delete_many(filter_query, session=session)
        return result.deleted_count

    async def remove_provision_status_by_profile_id_and_cluster_id(
        self,
        *,
        profile_id: str,
        cluster_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> bool:
        """Remove a specific provision status by profile_id and cluster_id."""
        filter_query = {
            "profile_id": profile_id,
            "cluster_id": cluster_id,
        }
        document = await self._collection.find_one_and_delete(
            filter_query, session=session
        )
        if document is None:
            raise ObjectNotFoundException(f"{profile_id}:{cluster_id}")

        return True

    async def remove_provision_status_by_profile_id_and_version_and_cluster_id(
        self,
        *,
        profile_id: str,
        profile_version: int,
        cluster_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> bool:
        """Remove a specific provision status by profile_id, profile_version and cluster_id.

        Args:
            profile_id: The profile ID
            profile_version: The profile version
            cluster_id: The cluster ID

        Returns:
            True if document was deleted, False if not found

        Raises:
            ObjectNotFoundException: If the document is not found
        """
        filter_query = {
            "profile_id": profile_id,
            "profile_version": profile_version,
            "cluster_id": cluster_id,
        }

        document = await self._collection.find_one_and_delete(
            filter_query, session=session
        )

        if document is None:
            raise ObjectNotFoundException(
                f"{profile_id}:{profile_version}:{cluster_id}"
            )

        return True

    async def get_provisioned_versions_by_profile_id(
        self,
        *,
        profile_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[int]:
        """Get all provisioned profile versions for a given profile ID.

        Returns the list of unique profile_version values that are currently
        deployed for the specified profile. This is used to protect deployed
        versions from being deleted during history cleanup.

        Args:
            profile_id: The profile ID to get provisioned versions for
            session: Optional MongoDB session for transaction support

        Returns:
            List of unique profile_version integers that are currently deployed
        """
        pipeline = [
            {"$match": {"profile_id": profile_id}},
            {"$group": {"_id": "$profile_version"}},
        ]

        results = await self._collection.aggregate(pipeline, session=session).to_list(
            None
        )

        return [r["_id"] for r in results if r["_id"] is not None]
