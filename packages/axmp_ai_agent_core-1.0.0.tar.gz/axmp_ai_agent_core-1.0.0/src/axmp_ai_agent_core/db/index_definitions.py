"""MongoDB index definitions for all collections."""

from dataclasses import dataclass, field

import pymongo

from axmp_ai_agent_core.db.collection_name import CollectionName


@dataclass(frozen=True)
class IndexDefinition:
    """Define a single MongoDB index."""

    collection: CollectionName
    name: str
    fields: list[tuple[str, int]] = field(default_factory=list)
    unique: bool = False


INDEX_DEFINITIONS: list[IndexDefinition] = [
    # =========================================================================
    # skill
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.SKILL,
        name="idx_skill_name",
        fields=[("name", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.SKILL,
        name="idx_skill_system_name",
        fields=[("system_name", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.SKILL,
        name="idx_skill_search_tokens",
        fields=[("search_tokens", pymongo.ASCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.SKILL,
        name="idx_skill_categories",
        fields=[("categories", pymongo.ASCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.SKILL,
        name="idx_skill_like_count",
        fields=[("like_count", pymongo.DESCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.SKILL,
        name="idx_skill_shared_type",
        fields=[("shared_target.shared_type", pymongo.ASCENDING)],
    ),
    # =========================================================================
    # skill_history
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.SKILL_HISTORY,
        name="idx_skill_history_skill_id_version",
        fields=[("skill_id", pymongo.ASCENDING), ("version", pymongo.DESCENDING)],
    ),
    # =========================================================================
    # skill_like
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.SKILL_LIKE,
        name="idx_skill_like_skill_username",
        fields=[("skill_id", pymongo.ASCENDING), ("username", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.SKILL_LIKE,
        name="idx_skill_like_skill_created_at",
        fields=[("skill_id", pymongo.ASCENDING), ("created_at", pymongo.DESCENDING)],
    ),
    # =========================================================================
    # agent_profile
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.AGENT_PROFILE,
        name="idx_agent_profile_name",
        fields=[("name", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.AGENT_PROFILE,
        name="idx_agent_profile_system_name",
        fields=[("system_name", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.AGENT_PROFILE,
        name="idx_agent_profile_shared_type",
        fields=[("shared_target.shared_type", pymongo.ASCENDING)],
    ),
    # =========================================================================
    # agent_profile_history
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.AGENT_PROFILE_HISTORY,
        name="idx_agent_history_profile_id_version",
        fields=[
            ("agent_profile_id", pymongo.ASCENDING),
            ("version", pymongo.DESCENDING),
        ],
    ),
    # =========================================================================
    # agent_provision_status
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.AGENT_PROVISION_STATUS,
        name="idx_agent_provision_profile_id",
        fields=[("profile_id", pymongo.ASCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.AGENT_PROVISION_STATUS,
        name="idx_agent_provision_profile_cluster",
        fields=[("profile_id", pymongo.ASCENDING), ("cluster_id", pymongo.ASCENDING)],
        unique=True,
    ),
    # =========================================================================
    # agent_catalog
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.AGENT_CATALOG,
        name="idx_agent_catalog_categories",
        fields=[("categories", pymongo.ASCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.AGENT_CATALOG,
        name="idx_agent_catalog_name",
        fields=[("name", pymongo.ASCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.AGENT_CATALOG,
        name="idx_agent_catalog_agent_type",
        fields=[("agent_type", pymongo.ASCENDING)],
    ),
    # =========================================================================
    # mcp_server_profile
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.MCP_SERVER_PROFILE,
        name="idx_mcp_profile_system_name",
        fields=[("system_name", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.MCP_SERVER_PROFILE,
        name="idx_mcp_profile_status_created_at",
        fields=[("status", pymongo.ASCENDING), ("created_at", pymongo.DESCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.MCP_SERVER_PROFILE,
        name="idx_mcp_profile_shared_type",
        fields=[("shared_target.shared_type", pymongo.ASCENDING)],
    ),
    # =========================================================================
    # mcp_server_profile_history
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.MCP_SERVER_PROFILE_HISTORY,
        name="idx_mcp_history_profile_id_version",
        fields=[
            ("mcp_server_profile_id", pymongo.ASCENDING),
            ("version", pymongo.DESCENDING),
        ],
    ),
    # =========================================================================
    # mcp_server_provision_status
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.MCP_SERVER_PROVISION_STATUS,
        name="idx_mcp_provision_profile_cluster",
        fields=[("profile_id", pymongo.ASCENDING), ("cluster_id", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.MCP_SERVER_PROVISION_STATUS,
        name="idx_mcp_provision_cluster",
        fields=[("cluster_id", pymongo.ASCENDING)],
    ),
    # =========================================================================
    # mcp_registry
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.MCP_REGISTRY,
        name="idx_mcp_registry_name",
        fields=[("name", pymongo.ASCENDING)],
        unique=True,
    ),
    # =========================================================================
    # chat_conversation
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.CONVERSATION,
        name="idx_conversation_thread_id",
        fields=[("thread_id", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.CONVERSATION,
        name="idx_conversation_agent_id",
        fields=[("agent_id", pymongo.ASCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.CONVERSATION,
        name="idx_conversation_project_id",
        fields=[("project_id", pymongo.ASCENDING)],
    ),
    IndexDefinition(
        collection=CollectionName.CONVERSATION,
        name="idx_conversation_user_starred",
        fields=[
            ("user_id", pymongo.ASCENDING),
            ("starred", pymongo.ASCENDING),
            ("created_at", pymongo.DESCENDING),
        ],
    ),
    # =========================================================================
    # oauth_user
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.USER,
        name="idx_user_username",
        fields=[("username", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.USER,
        name="idx_user_email",
        fields=[("email", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.USER,
        name="idx_user_iss_sub",
        fields=[("iss", pymongo.ASCENDING), ("sub", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.USER,
        name="idx_user_group_ids",
        fields=[("group_ids", pymongo.ASCENDING)],
    ),
    # =========================================================================
    # groups
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.GROUP,
        name="idx_group_code",
        fields=[("code", pymongo.ASCENDING)],
        unique=True,
    ),
    IndexDefinition(
        collection=CollectionName.GROUP,
        name="idx_group_parent_code",
        fields=[("parent_code", pymongo.ASCENDING)],
    ),
    # =========================================================================
    # roles
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.ROLE,
        name="idx_role_name",
        fields=[("name", pymongo.ASCENDING)],
        unique=True,
    ),
    # =========================================================================
    # llm_provider
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.LLM_PROVIDER,
        name="idx_llm_provider_key",
        fields=[("key", pymongo.ASCENDING)],
        unique=True,
    ),
    # =========================================================================
    # oauth_provider
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.OAUTH_PROVIDER,
        name="idx_oauth_provider_system_name",
        fields=[("system_name", pymongo.ASCENDING)],
        unique=True,
    ),
    # =========================================================================
    # user_credential
    # =========================================================================
    IndexDefinition(
        collection=CollectionName.USER_CREDENTIAL,
        name="idx_credential_owner_name",
        fields=[
            ("username", pymongo.ASCENDING),
            ("display_name", pymongo.ASCENDING),
        ],
    ),
    IndexDefinition(
        collection=CollectionName.USER_CREDENTIAL,
        name="idx_credential_shared_type",
        fields=[("shared_target.shared_type", pymongo.ASCENDING)],
    ),
]
