"""Agent catalog repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.agent_catalog import (
    AgentCatalog,
)
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.agent_catalog_query import AgentCatalogQueryParameters
from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class AgentCatalogRepository(BaseRepository[AgentCatalog]):
    """Agent catalog repository."""

    async def insert(
        self,
        *,
        item: AgentCatalog,
        session: AsyncIOMotorClientSession | None = None,
    ) -> str:
        """Insert a new agent catalog into the repository."""
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)
        item.updated_at = item.created_at

        # model_dump will convert datetime to string
        # so we need to set again datetime filed with datetime object
        agent_catalog_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at", "updated_at"]
        )

        agent_catalog_dict["created_at"] = item.created_at
        agent_catalog_dict["updated_at"] = item.updated_at

        result: InsertOneResult = await self._collection.insert_one(
            agent_catalog_dict, session=session
        )

        return str(result.inserted_id)

    async def update(
        self,
        *,
        item: AgentCatalog,
        session: AsyncIOMotorClientSession | None = None,
    ) -> AgentCatalog | None:
        """Update an agent catalog in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        # model_dump will convert datetime to string
        # so we need to set again datetime filed with datetime object
        agent_catalog_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
            ],
        )
        agent_catalog_dict["updated_at"] = item.updated_at

        update = [{"$set": agent_catalog_dict}]

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        if document is None:
            raise ObjectNotFoundException(item.id)

        return AgentCatalog(**document)

    async def delete(
        self,
        *,
        item_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> bool:
        """Delete an agent catalog from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self,
        *,
        item_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> AgentCatalog | None:
        """Find an agent catalog by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return AgentCatalog(**document)

    async def find_all(
        self,
        *,
        query_parameters: AgentCatalogQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = ["agent_card"],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[AgentCatalog]:
        """Find all agent catalogs in the repository."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        logger.debug(
            f"page_number={page_number}, page_size={page_size} so skip: {skip}, limit: {limit}"
        )

        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "updated_at"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(
                filter,
                projection=projection if projection else None,
                session=session,
            )
            .sort(sort_field, direction)
            .skip(skip)
            .limit(limit)
        )

        # convert cursor to list of agent catalogs
        agent_catalogs = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    agent_catalogs.append(AgentCatalog(**document))

        return agent_catalogs

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: BaseQueryParameters,
        max_limit: int = MAX_LIMIT,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[AgentCatalog]:
        """Find all agent catalogs in the repository without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "updated_at"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(
                filter,
                projection=projection if projection else None,
                session=session,
            )
            .sort(sort_field, direction)
            .limit(max_limit)
        )

        # convert cursor to list of agent catalogs
        agent_catalogs = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    agent_catalogs.append(AgentCatalog(**document))

        logger.debug(f"Found {len(agent_catalogs)} agent catalogs")

        return agent_catalogs

    async def count(
        self,
        *,
        query_parameters: AgentCatalogQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of agent catalogs in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self,
        *,
        query_parameters: AgentCatalogQueryParameters,
    ) -> Dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter: Dict[str, Any] = {}

        if query_parameters.keyword:
            keyword_regex = {
                "$regex": get_escaped_regex_pattern(query_parameters.keyword),
                "$options": "i",
            }
            filter["$or"] = [
                {"name": keyword_regex},
                {"system_name": keyword_regex},
                {"description": keyword_regex},
            ]

        # AgentCatalog specific filters
        if query_parameters.resource_type:
            filter["resource_type"] = query_parameters.resource_type

        if query_parameters.agent_type:
            filter["agent_type"] = query_parameters.agent_type

        if query_parameters.application_type:
            filter["application_type"] = query_parameters.application_type

        if query_parameters.categories:
            # Use $in operator to find documents where categories array contains any of the specified categories
            filter["categories"] = {"$in": query_parameters.categories}

        if query_parameters.version:
            filter["version"] = query_parameters.version

        if query_parameters.created_by:
            filter["created_by"] = query_parameters.created_by

        if query_parameters.updated_by:
            filter["updated_by"] = query_parameters.updated_by

        return filter

    async def find_all_categories(
        self, session: AsyncIOMotorClientSession | None = None
    ) -> List[str]:
        """Get all unique categories from agent catalogs."""
        categories = await self._collection.distinct(
            "categories",
            session=session,  # type: ignore[arg-type]
        )
        return sorted([cat for cat in categories if cat is not None])
