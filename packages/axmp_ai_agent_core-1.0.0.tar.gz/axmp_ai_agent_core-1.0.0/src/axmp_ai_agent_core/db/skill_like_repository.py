"""Skill like repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.skill_like import SkillLike
from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters
from axmp_ai_agent_core.util.list_utils import MAX_LIMIT
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class SkillLikeRepository(BaseRepository[SkillLike]):
    """Skill like repository."""

    async def insert(
        self, *, item: SkillLike, session: AsyncIOMotorClientSession | None = None
    ) -> str:
        """Insert a new SkillLike."""
        if item.created_at is None:
            item.created_at = datetime.now(DEFAULT_TIME_ZONE)
            item.updated_at = item.created_at

        like_dict = item.model_dump(
            by_alias=True, exclude={"id", "created_at", "updated_at"}
        )
        like_dict["created_at"] = item.created_at
        like_dict["updated_at"] = item.updated_at

        result: InsertOneResult = await self._collection.insert_one(
            like_dict, session=session
        )
        return str(result.inserted_id)

    async def delete_by_skill_and_user(
        self,
        *,
        skill_id: str,
        username: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> bool:
        """Delete a like by skill_id and username. Return True if deleted."""
        result = await self._collection.delete_one(
            {"skill_id": skill_id, "username": username}, session=session
        )
        return result.deleted_count > 0

    async def find_by_skill_and_user(
        self,
        *,
        skill_id: str,
        username: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> SkillLike | None:
        """Find a like by skill_id and username. Return None if not found."""
        document = await self._collection.find_one(
            {"skill_id": skill_id, "username": username}, session=session
        )
        if document is None:
            return None
        return SkillLike(**document)

    async def count_by_skill_id(
        self,
        *,
        skill_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count likes for a Skill."""
        return await self._collection.count_documents(
            {"skill_id": skill_id}, session=session
        )

    async def get_trending_skill_ids(
        self,
        *,
        since: datetime,
        limit: int = 10,
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[dict[str, Any]]:
        """Get trending skill IDs by like count in a period.

        Return list of {"_id": skill_id, "like_count": N}, sorted by like_count DESC.
        """
        pipeline = [
            {"$match": {"created_at": {"$gte": since}}},
            {"$group": {"_id": "$skill_id", "like_count": {"$sum": 1}}},
            {"$sort": {"like_count": -1}},
            {"$limit": limit},
        ]

        cursor = self._collection.aggregate(pipeline, session=session)
        results = []
        async for document in cursor:
            results.append(document)
        return results

    async def delete_by_skill_id(
        self,
        *,
        skill_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Delete all likes for a Skill. Return deleted count."""
        result = await self._collection.delete_many(
            {"skill_id": skill_id}, session=session
        )
        return result.deleted_count

    async def find_liked_skill_ids(
        self,
        *,
        skill_ids: list[str],
        username: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> set[str]:
        """Find which skill_ids the user has liked. Return set of liked skill_ids."""
        if not skill_ids:
            return set()

        cursor = self._collection.find(
            {"skill_id": {"$in": skill_ids}, "username": username},
            {"skill_id": 1},
            session=session,
        )
        return {doc["skill_id"] async for doc in cursor}

    # =========================================================================
    # BaseRepository abstract methods — required but not used for SkillLike
    # =========================================================================

    async def update(
        self, *, item: SkillLike, session: AsyncIOMotorClientSession | None = None
    ) -> SkillLike | None:
        """Not supported — SkillLike is immutable (toggle = delete + insert)."""
        raise NotImplementedError("SkillLike is immutable")

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Not supported — use delete_by_skill_and_user instead."""
        raise NotImplementedError("Use delete_by_skill_and_user instead")

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> SkillLike | None:
        """Not supported — use find_by_skill_and_user instead."""
        raise NotImplementedError("Use find_by_skill_and_user instead")

    async def find_all(
        self,
        *,
        query_parameters: BaseQueryParameters,
        page_number: int = 1,
        page_size: int = 50,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[SkillLike]:
        """Not supported."""
        raise NotImplementedError("Not supported for SkillLike")

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: BaseQueryParameters,
        max_limit: int = MAX_LIMIT,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[SkillLike]:
        """Not supported."""
        raise NotImplementedError("Not supported for SkillLike")

    async def count(
        self,
        *,
        query_parameters: BaseQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Not supported — use count_by_skill_id instead."""
        raise NotImplementedError("Use count_by_skill_id instead")

    async def find_all_query(
        self,
        *,
        query_parameters: BaseQueryParameters,
    ) -> dict[str, Any]:
        """Not supported."""
        raise NotImplementedError("Not supported for SkillLike")
