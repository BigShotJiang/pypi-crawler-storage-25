"""MCP Registry repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.mcp_registry import McpRegistry, Status
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.mcp_registry_query import McpRegistryQueryParameters
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class McpRegistryRepository(BaseRepository[McpRegistry]):
    """MCP Registry repository."""

    async def insert(
        self, *, item: McpRegistry, session: AsyncIOMotorClientSession | None = None
    ) -> str:
        """Insert a new MCP Registry into the repository."""
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)
        item.updated_at = item.created_at

        mcp_registry_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at", "updated_at"]
        )
        mcp_registry_dict["created_at"] = item.created_at
        mcp_registry_dict["updated_at"] = item.updated_at

        if item.id:
            try:
                mcp_registry_dict["_id"] = ObjectId(item.id)
            except InvalidId as e:
                raise InvalidObjectIDException(e)

        result: InsertOneResult = await self._collection.insert_one(
            mcp_registry_dict, session=session
        )
        return str(result.inserted_id)

    async def update(
        self, *, item: McpRegistry, session: AsyncIOMotorClientSession | None = None
    ) -> McpRegistry | None:
        """Update an MCP Registry in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        mcp_registry_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
            ],
        )
        mcp_registry_dict["updated_at"] = item.updated_at

        update = {"$set": mcp_registry_dict}

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        if document is None:
            raise ObjectNotFoundException(item.id)

        return McpRegistry(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete an MCP Registry from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> McpRegistry | None:
        """Find an MCP Registry by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return McpRegistry(**document)

    async def find_by_name(
        self, *, name: str, session: AsyncIOMotorClientSession | None = None
    ) -> McpRegistry | None:
        """Find an MCP Registry by name."""
        filter = {"name": name}
        document = await self._collection.find_one(
            filter=filter, projection={"tools": 0}, session=session
        )

        if document is None:
            return None

        return McpRegistry(**document)

    async def find_by_status(
        self, *, status: Status, session: AsyncIOMotorClientSession | None = None
    ) -> List[McpRegistry]:
        """Find MCP Registries by status."""
        filter = {"status": status}
        cursor = self._collection.find(
            filter=filter, projection={"tools": 0}, session=session
        )

        mcp_registries = []
        async for document in cursor:
            if document is not None:
                mcp_registries.append(McpRegistry(**document))

        return mcp_registries

    async def find_all(
        self,
        *,
        query_parameters: McpRegistryQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[McpRegistry]:
        """Find all MCP Registries in the repository."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "name"

        filter = await self.find_all_query(query_parameters=query_parameters)

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .skip(skip)
            .limit(limit)
        )

        mcp_registries = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    mcp_registries.append(McpRegistry(**document))

        return mcp_registries

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: McpRegistryQueryParameters,
        max_limit: int = MAX_LIMIT,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[McpRegistry]:
        """Find all MCP Registries in the repository without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "name"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        # Exclude tools field to avoid BaseTool instantiation issues
        if not projection:
            projection = {"tools": 0}
        elif "tools" not in projection:
            projection["tools"] = 0

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .limit(max_limit)
        )

        mcp_registries = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    mcp_registries.append(McpRegistry(**document))

        logger.debug(f"Found {len(mcp_registries)} MCP registries")

        return mcp_registries

    async def count(
        self,
        *,
        query_parameters: McpRegistryQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of MCP Registries in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)
        logger.debug(f"Filter: {filter}")
        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self,
        *,
        query_parameters: McpRegistryQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> Dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter: Dict[str, Any] = {}

        if query_parameters.keyword:
            keyword_regex = {
                "$regex": get_escaped_regex_pattern(query_parameters.keyword),
                "$options": "i",
            }
            filter["$or"] = [
                {"name": keyword_regex},
                {"description": keyword_regex},
            ]

        if query_parameters.categories:
            # Use $in operator to find documents where categories array contains any of the specified categories
            filter["categories"] = {"$in": query_parameters.categories}

        if query_parameters.resource_types:
            filter["resource_type"] = {"$in": query_parameters.resource_types}

        if query_parameters.version:
            filter["version"] = query_parameters.version

        if query_parameters.status:
            filter["status"] = query_parameters.status

        if query_parameters.created_by:
            filter["created_by"] = query_parameters.created_by

        if query_parameters.updated_by:
            filter["updated_by"] = query_parameters.updated_by

        if query_parameters.is_published is not None:
            filter["is_published"] = query_parameters.is_published

        if query_parameters.labels:
            for label in query_parameters.parsed_labels:
                filter.update({f"labels.{label.key}": label.value})

        return filter

    async def get_categories_with_count(
        self, session: AsyncIOMotorClientSession | None = None
    ) -> dict[str, int]:
        """Get all categories with their counts."""
        # MongoDB Aggregation Pipeline을 사용하여 카테고리별 개수 집계
        # 로직 혼란스러워서 한글로 주석 작성
        pipeline = [
            # Step 1: $unwind - categories 배열을 개별 문서로 분해
            # 예: {categories: ["api", "database"]} -> {categories: "api"}, {categories: "database"}
            {"$unwind": "$categories"},
            # Step 2: $group - categories 필드별로 그룹화하고 개수 집계
            # _id: 그룹화 기준 필드 (categories), count: 각 그룹의 문서 개수
            {"$group": {"_id": "$categories", "count": {"$sum": 1}}},
            # Step 3: $sort - count 필드를 기준으로 내림차순 정렬 (가장 많은 카테고리부터)
            {"$sort": {"count": -1}},
        ]

        cursor = self._collection.aggregate(pipeline, session=session)
        categories_with_count = {}

        async for document in cursor:
            category = document["_id"]
            count = document["count"]
            if category:
                categories_with_count[category] = count

        return categories_with_count
