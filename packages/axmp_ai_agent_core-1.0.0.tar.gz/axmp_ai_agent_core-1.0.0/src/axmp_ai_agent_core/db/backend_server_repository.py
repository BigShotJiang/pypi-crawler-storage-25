"""Backend server repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.backend_server import BackendServer
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
    ValueErrorException,
)
from axmp_ai_agent_core.filter.backend_server_query import (
    BackendServerQueryParameters,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class BackendServerRepository(BaseRepository[BackendServer]):
    """Backend server repository."""

    async def insert(
        self, *, item: BackendServer, session: AsyncIOMotorClientSession | None = None
    ) -> str:
        """Insert a new backend server into the repository."""
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)
        item.updated_at = item.created_at

        backend_server_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at", "updated_at"]
        )
        backend_server_dict["created_at"] = item.created_at
        backend_server_dict["updated_at"] = item.updated_at

        result: InsertOneResult = await self._collection.insert_one(
            backend_server_dict, session=session
        )

        return str(result.inserted_id)

    async def update(
        self,
        *,
        item: BackendServer,
        session: AsyncIOMotorClientSession | None = None,
    ) -> BackendServer | None:
        """Update a backend server in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        backend_server_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
                "updated_at",
                "swagger_json",
            ],
        )
        backend_server_dict["updated_at"] = item.updated_at

        update = {"$set": backend_server_dict}

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )
        if document is None:
            raise ObjectNotFoundException(item.id)

        if item.swagger_json:
            document["swagger_json"] = item.swagger_json
            await self._collection.replace_one(
                filter=filter,
                replacement=document,
                session=session,
            )

        return BackendServer(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete a backend server from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> BackendServer | None:
        """Find a backend server by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return BackendServer(**document)

    async def get_id_by_name_and_domain(
        self,
        *,
        name: str,
        domain: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> str | None:
        """Get the ID of a backend server by name and domain."""
        try:
            filter = {"name": name, "domain": domain}
        except InvalidId:
            return None

        document = await self._collection.find_one(filter=filter, session=session)
        logger.debug(f"document: {document}")
        document_id = document["_id"] if document else None
        return str(document_id)

    async def find_all(
        self,
        *,
        query_parameters: BackendServerQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = ["swagger_json"],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[BackendServer]:
        """Find all backend servers in the repository."""
        if exclude_fields and include_fields:
            if len(exclude_fields) > 0 and len(include_fields) > 0:
                raise ValueErrorException(
                    "exclude_fields and include_fields cannot be used together"
                )

        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        logger.debug(
            f"page_number={page_number}, page_size={page_size} so skip: {skip}, limit: {limit}"
        )

        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "name"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .skip(skip)
            .limit(limit)
        )

        backend_servers = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    backend_servers.append(BackendServer(**document))

        return backend_servers

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: BackendServerQueryParameters,
        max_limit: int = MAX_LIMIT,  # if max_limit is 0, don't apply limit
        exclude_fields: list[str] = [],
        include_fields: list[str] = [
            "name",
            "system_name",
            "description",
            "domain",
            "base_path",
        ],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[BackendServer]:
        """Find all backend servers in the repository without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "name"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .limit(max_limit)
        )

        backend_servers = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    backend_servers.append(BackendServer(**document))

        logger.debug(f"Found {len(backend_servers)} backend servers")

        return backend_servers

    async def count(
        self,
        *,
        query_parameters: BackendServerQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of backend servers in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self,
        *,
        query_parameters: BackendServerQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> Dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter: Dict[str, Any] = {}

        if query_parameters.keyword:
            keyword_regex = {
                "$regex": get_escaped_regex_pattern(query_parameters.keyword),
                "$options": "i",
            }
            filter["$or"] = [
                {"system_name": keyword_regex},
                {"name": keyword_regex},
                {"description": keyword_regex},
            ]

        if query_parameters.name:
            filter["name"] = query_parameters.name

        if query_parameters.system_name:
            filter["system_name"] = query_parameters.system_name

        if query_parameters.created_by:
            filter["created_by"] = query_parameters.created_by

        if query_parameters.updated_by:
            filter["updated_by"] = query_parameters.updated_by

        if query_parameters.status:
            filter["status"] = query_parameters.status

        if query_parameters.labels:
            for label in query_parameters.parsed_labels:
                filter.update({f"labels.{label.key}": label.value})

        return filter
