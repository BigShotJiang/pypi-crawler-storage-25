"""Initialize MongoDB indexes for all collections at application startup."""

from __future__ import annotations

import logging
from itertools import groupby

from motor.motor_asyncio import AsyncIOMotorDatabase

from axmp_ai_agent_core.db.index_definitions import INDEX_DEFINITIONS, IndexDefinition

logger = logging.getLogger(__name__)

_PRIMARY_INDEX_NAME = "_id_"


def _normalize_key(key) -> list[tuple[str, int | str]]:
    """Normalize an index key to an ordered list for comparison.

    MongoDB may return numeric directions as float (e.g. -1.0) due to wire
    protocol encoding. Special index types like "text" or "2dsphere" stay as
    strings. Order is preserved because compound index field order is semantic.
    """
    return [
        (field, int(direction) if isinstance(direction, (int, float)) else direction)
        for field, direction in dict(key).items()
    ]


async def _create_or_replace_index(
    *,
    collection_name: str,
    database: AsyncIOMotorDatabase,
    defn: IndexDefinition,
) -> None:
    """Create an index, replacing it if the definition has changed."""
    collection = database[collection_name]

    existing_indexes = {
        idx["name"]: idx
        for idx in await collection.list_indexes().to_list(None)
        if idx["name"] != _PRIMARY_INDEX_NAME
    }

    new_key = _normalize_key(defn.fields)

    if defn.name in existing_indexes:
        existing = existing_indexes[defn.name]
        if _normalize_key(existing["key"]) == new_key and existing.get("unique", False) == defn.unique:
            return

        logger.warning("Replacing changed index %s on %s", defn.name, collection_name)
        await collection.drop_index(defn.name)
    else:
        for old_name, old_idx in existing_indexes.items():
            if _normalize_key(old_idx["key"]) == new_key:
                logger.warning(
                    "Replacing legacy index %s -> %s on %s",
                    old_name,
                    defn.name,
                    collection_name,
                )
                await collection.drop_index(old_name)
                break

    kwargs: dict = {"name": defn.name}
    if defn.unique:
        kwargs["unique"] = True

    await collection.create_index(defn.fields, **kwargs)


async def ensure_all_indexes(*, database: AsyncIOMotorDatabase) -> None:
    """Create all indexes defined in INDEX_DEFINITIONS idempotently.

    - Same name + same definition → skipped.
    - Same name + changed fields or options → dropped and recreated.
    - Indexes are grouped by collection to minimise round-trips.
    """
    sorted_defs = sorted(INDEX_DEFINITIONS, key=lambda d: d.collection)
    grouped = groupby(sorted_defs, key=lambda d: d.collection)

    errors: list[str] = []

    for collection_name, definitions in grouped:
        for defn in definitions:
            try:
                await _create_or_replace_index(
                    collection_name=collection_name,
                    database=database,
                    defn=defn,
                )
                logger.debug(
                    "Ensured index %s on %s (unique=%s)",
                    defn.name,
                    collection_name,
                    defn.unique,
                )
            except Exception:
                logger.exception(
                    "Failed to create index %s on %s",
                    defn.name,
                    collection_name,
                )
                errors.append(f"{collection_name}.{defn.name}")

    if errors:
        raise RuntimeError(
            f"Failed to create {len(errors)} index(es): {', '.join(errors)}"
        )

    logger.info("All %d indexes ensured.", len(INDEX_DEFINITIONS))
