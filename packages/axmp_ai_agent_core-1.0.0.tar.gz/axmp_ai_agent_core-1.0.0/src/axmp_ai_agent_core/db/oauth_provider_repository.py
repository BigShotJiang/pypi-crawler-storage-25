"""OAuth Provider repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.oauth_provider import OAuthProvider, OAuthProviderType
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.oauth_provider_query import (
    OAuthProviderQueryParameters,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class OAuthProviderRepository(BaseRepository[OAuthProvider]):
    """OAuth Provider repository."""

    async def insert(
        self,
        *,
        item: OAuthProvider,
        session: AsyncIOMotorClientSession | None = None,
    ) -> str:
        """Insert a new OAuth provider into the repository."""
        if item.created_at is None:
            item.created_at = datetime.now(DEFAULT_TIME_ZONE)

        provider_dict = item.model_dump(by_alias=True, exclude=["id"])
        provider_dict["created_at"] = item.created_at

        result: InsertOneResult = await self._collection.insert_one(
            provider_dict, session=session
        )

        return str(result.inserted_id)

    async def update(
        self,
        *,
        item: OAuthProvider,
        session: AsyncIOMotorClientSession | None = None,
    ) -> OAuthProvider | None:
        """Update an OAuth provider in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        if item.updated_at is None:
            item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        provider_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
            ],
        )
        provider_dict["updated_at"] = item.updated_at

        update = {"$set": provider_dict}

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )
        if document is None:
            raise ObjectNotFoundException(item.id)

        return OAuthProvider(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete an OAuth provider from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> OAuthProvider | None:
        """Find an OAuth provider by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return OAuthProvider(**document)

    async def find_all(
        self,
        *,
        query_parameters: OAuthProviderQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[OAuthProvider]:
        """Find all OAuth providers in the repository."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = (
            query_parameters.sort_field.value
            if hasattr(query_parameters.sort_field, "value")
            else "created_at"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)
        pipeline = [
            {"$match": filter},
            {"$sort": {sort_field: direction}},
            {"$skip": skip},
            {"$limit": limit},
        ]

        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )
        if projection:
            pipeline.append({"$project": projection})

        cursor = self._collection.aggregate(pipeline, session=session)

        providers = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    providers.append(OAuthProvider(**document))

        return providers

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: OAuthProviderQueryParameters,
        max_limit: int = MAX_LIMIT,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[OAuthProvider]:
        """Find all OAuth providers in the repository without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = (
            query_parameters.sort_field.value
            if hasattr(query_parameters.sort_field, "value")
            else "created_at"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = self._collection.find(
            filter, projection=projection if projection else None, session=session
        ).sort(sort_field, direction)

        if max_limit > 0:
            cursor = cursor.limit(max_limit)

        providers = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    providers.append(OAuthProvider(**document))

        return providers

    async def count(
        self,
        *,
        query_parameters: OAuthProviderQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of OAuth providers in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)

        return await self._collection.count_documents(filter=filter, session=session)

    async def find_by_system_name(
        self, *, system_name: str, session: AsyncIOMotorClientSession | None = None
    ) -> OAuthProvider | None:
        """Find an OAuth provider by system_name."""
        filter = {"system_name": system_name}

        document = await self._collection.find_one(filter=filter, session=session)

        return OAuthProvider(**document) if document else None

    async def count_by_provider_type(
        self,
        *,
        provider_type: OAuthProviderType,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count OAuth providers by provider type."""
        filter = {"provider_type": provider_type.value}

        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self,
        *,
        query_parameters: OAuthProviderQueryParameters,
    ) -> dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter: dict[str, Any] = {}

        if query_parameters.keyword:
            keyword_regex = {
                "$regex": get_escaped_regex_pattern(query_parameters.keyword),
                "$options": "i",
            }
            filter["$or"] = [
                {"name": keyword_regex},
                {"system_name": keyword_regex},
            ]

        if query_parameters.statuses:
            filter["status"] = {"$in": query_parameters.statuses}

        if query_parameters.provider_types:
            filter["provider_type"] = {"$in": query_parameters.provider_types}

        if query_parameters.created_by:
            filter["created_by"] = query_parameters.created_by

        if query_parameters.updated_by:
            filter["updated_by"] = query_parameters.updated_by

        if query_parameters.access_permission:
            shared_target_filter = await self._build_shared_target_filter(
                access_permission=query_parameters.access_permission
            )
            if filter:
                filter = {"$and": [filter, shared_target_filter]}
            else:
                filter = shared_target_filter

        return filter
