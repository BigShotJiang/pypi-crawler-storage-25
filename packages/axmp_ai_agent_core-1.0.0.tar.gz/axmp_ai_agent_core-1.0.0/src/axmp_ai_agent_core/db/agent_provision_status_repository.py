"""Agent Provision Status repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.agent_provision_status import AgentProvisionStatus
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class AgentProvisionStatusRepository(
    BaseRepository[AgentProvisionStatus],
):
    """Agent Provision Status repository."""

    async def find_non_terminated_statuses(
        self, *, session: AsyncIOMotorClientSession | None = None
    ) -> list[AgentProvisionStatus]:
        """Find all provision statuses except TERMINATED."""
        filter_query = {"status": {"$ne": "TERMINATED"}}

        cursor = self._collection.find(filter_query, session=session)
        documents = []

        async for document in cursor:
            documents.append(AgentProvisionStatus(**document))

        return documents

    async def insert(
        self,
        *,
        item: AgentProvisionStatus,
        session: AsyncIOMotorClientSession | None = None,
    ) -> str:
        """Insert a new agent provision status into the repository."""
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)

        provision_status_dict = item.model_dump(by_alias=True, exclude=["id"])
        provision_status_dict["created_at"] = item.created_at

        result: InsertOneResult = await self._collection.insert_one(
            provision_status_dict,
            session=session,
        )

        return str(result.inserted_id)

    async def update(
        self,
        *,
        item: AgentProvisionStatus,
        session: AsyncIOMotorClientSession | None = None,
    ) -> AgentProvisionStatus | None:
        """Update an agent provision status in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        provision_status_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
            ],
        )
        provision_status_dict["updated_at"] = item.updated_at

        update = {"$set": provision_status_dict}

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )
        if document is None:
            raise ObjectNotFoundException(item.id)

        return AgentProvisionStatus(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete an agent provision status from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> AgentProvisionStatus | None:
        """Find an agent provision status by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return AgentProvisionStatus(**document)

    async def find_by_instance_id(
        self,
        *,
        instance_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> AgentProvisionStatus | None:
        """Find an agent provision status by instance ID.

        Args:
            instance_id: The unique instance ID (from K8s label 'instance-id')
            session: Optional MongoDB session for transaction support

        Returns:
            AgentProvisionStatus if found, None otherwise
        """
        filter_query = {"instance_id": instance_id}

        document = await self._collection.find_one(filter=filter_query, session=session)

        if document is None:
            return None

        return AgentProvisionStatus(**document)

    async def find_by_cluster_and_name_and_namespace(
        self,
        *,
        cluster_id: str,
        name: str,
        namespace: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> AgentProvisionStatus | None:
        """Find an agent provision status by cluster_id, name, and namespace."""
        filter_query = {"cluster_id": cluster_id, "name": name, "namespace": namespace}
        document = await self._collection.find_one(filter=filter_query, session=session)
        if document is None:
            return None
        return AgentProvisionStatus(**document)

    async def find_by_profile_and_cluster(
        self,
        *,
        profile_id: str,
        cluster_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> AgentProvisionStatus | None:
        """Find an agent provision status by profile_id and cluster_id."""
        filter = {
            "profile_id": profile_id,
            "cluster_id": cluster_id,
        }

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            return None

        return AgentProvisionStatus(**document)

    async def find_by_profile_and_version_and_cluster(
        self,
        *,
        profile_id: str,
        version: int,
        cluster_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> AgentProvisionStatus | None:
        """Find an agent provision status by profile_id and cluster_id."""
        filter = {
            "profile_id": profile_id,
            "profile_version": version,
            "cluster_id": cluster_id,
        }

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            return None

        return AgentProvisionStatus(**document)

    async def find_all_by_profile_id(
        self, *, profile_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> list[AgentProvisionStatus]:
        """Find all agent provision statuses by profile_id across all clusters."""
        filter = {"profile_id": profile_id}

        cursor = self._collection.find(filter, session=session)

        provision_statuses = []
        async for document in cursor:
            if document is not None:
                provision_statuses.append(AgentProvisionStatus(**document))

        return provision_statuses

    async def get_provisioned_versions_by_profile_id(
        self, *, profile_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> list[str]:
        """Get all unique provisioned versions for a profile_id.

        Returns a list of unique version strings (e.g., ['v1', 'v2', 'v3'])
        """
        pipeline = [
            {"$match": {"profile_id": profile_id}},
            {"$group": {"_id": "$profile_version"}},
            {"$sort": {"_id": 1}},
        ]

        cursor = self._collection.aggregate(pipeline, session=session)

        versions = []
        async for doc in cursor:
            if doc.get("_id"):
                versions.append(doc["_id"])

        return versions

    async def upsert_by_profile_and_cluster(
        self,
        *,
        item: AgentProvisionStatus,
        session: AsyncIOMotorClientSession | None = None,
    ) -> AgentProvisionStatus:
        """Upsert (insert or update) an agent provision status by profile_id and cluster_id."""
        filter = {
            "profile_id": item.profile_id,
            "cluster_id": item.cluster_id,
        }

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)

        provision_status_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at"]
        )
        provision_status_dict["updated_at"] = item.updated_at

        update = {
            "$set": provision_status_dict,
            "$setOnInsert": {"created_at": item.created_at},
        }

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            upsert=True,
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        return AgentProvisionStatus(**document)

    async def find_all(
        self,
        *,
        query_parameters: BaseQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[AgentProvisionStatus]:
        """Find all agent provision statuses in the repository."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        filter = await self.find_all_query(
            query_parameters=query_parameters,
        )

        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        sort_field = query_parameters.sort_field
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        skip = (page_number - 1) * page_size
        limit = min(page_size, MAX_LIMIT)

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .skip(skip)
            .limit(limit)
        )

        provision_statuses = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    provision_statuses.append(AgentProvisionStatus(**document))

        return provision_statuses

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: BaseQueryParameters,
        max_limit: int = MAX_LIMIT,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[AgentProvisionStatus]:
        """Find all agent provision statuses in the repository without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = query_parameters.sort_field or "created_at"

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        # Build projection
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(
                filter, projection=projection if projection else None, session=session
            )
            .sort(sort_field, direction)
            .limit(max_limit)
        )

        provision_statuses = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    provision_statuses.append(AgentProvisionStatus(**document))

        return provision_statuses

    async def count(
        self,
        *,
        query_parameters: BaseQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of agent provision statuses in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)

        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self, *, query_parameters: BaseQueryParameters
    ) -> dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter_query: dict[str, Any] = {}

        keyword = getattr(query_parameters, "keyword", None)
        if keyword:
            keyword_regex = {
                "$regex": get_escaped_regex_pattern(keyword),
                "$options": "i",
            }
            filter_query["$or"] = [
                {"profile_id": keyword_regex},
                {"cluster_id": keyword_regex},
                {"cluster_name": keyword_regex},
                {"name": keyword_regex},
                {"instance_id": keyword_regex},
            ]

        profile_id = getattr(query_parameters, "profile_id", None)
        if profile_id:
            filter_query["profile_id"] = profile_id

        profile_version = getattr(query_parameters, "profile_version", None)
        if profile_version:
            filter_query["profile_version"] = profile_version

        cluster_id = getattr(query_parameters, "cluster_id", None)
        if cluster_id:
            filter_query["cluster_id"] = cluster_id

        status = getattr(query_parameters, "status", None)
        if status:
            filter_query["status"] = status

        return filter_query
