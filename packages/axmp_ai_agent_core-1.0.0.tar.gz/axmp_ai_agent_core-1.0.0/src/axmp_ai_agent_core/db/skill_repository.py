"""Skill repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.shared_target import SharedType
from axmp_ai_agent_core.entity.skill import Skill
from axmp_ai_agent_core.entity.user_rbac import AccessPermission
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.skill_query import (
    SkillQueryParameters,
    SkillScope,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import (
    AliasExpander,
    KoreanTextNormalizer,
    KoreanTokenizer,
    get_escaped_regex_pattern,
)
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class SkillRepository(BaseRepository[Skill]):
    """Skill repository."""

    async def insert(
        self, *, item: Skill, session: AsyncIOMotorClientSession | None = None
    ) -> str:
        """Insert a new Skill."""
        if item.created_at is None:
            item.created_at = datetime.now(DEFAULT_TIME_ZONE)
            item.updated_at = item.created_at

        skill_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at", "updated_at"]
        )
        skill_dict["created_at"] = item.created_at
        skill_dict["updated_at"] = item.updated_at

        result: InsertOneResult = await self._collection.insert_one(
            skill_dict, session=session
        )
        return str(result.inserted_id)

    async def update(
        self, *, item: Skill, session: AsyncIOMotorClientSession | None = None
    ) -> Skill | None:
        """Update a Skill."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        skill_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at", "created_by"]
        )
        skill_dict["updated_at"] = item.updated_at

        document = await self._collection.find_one_and_update(
            filter=filter,
            update={"$set": skill_dict},
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        if document is None:
            raise ObjectNotFoundException(item.id)

        return Skill(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete a Skill."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> Skill | None:
        """Find a Skill by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return Skill(**document)

    async def find_all(
        self,
        *,
        query_parameters: SkillQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[Skill]:
        """Find all Skills with pagination."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip = page_size * (page_number - 1)
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )
        sort_field = query_parameters.sort_field or "updated_at"

        filter = await self.find_all_query(query_parameters=query_parameters)
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .skip(skip)
            .limit(page_size)
        )

        skills = []
        async for document in cursor:
            skills.append(Skill(**document))

        return skills

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: SkillQueryParameters,
        max_limit: int = MAX_LIMIT,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[Skill]:
        """Find all Skills without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )
        sort_field = query_parameters.sort_field or "updated_at"

        filter = await self.find_all_query(query_parameters=query_parameters)
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )

        cursor = (
            self._collection.find(filter, projection=projection, session=session)
            .sort(sort_field, direction)
            .limit(max_limit)
        )

        skills = []
        async for document in cursor:
            skills.append(Skill(**document))

        return skills

    async def count(
        self,
        *,
        query_parameters: SkillQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count Skills matching query."""
        filter = await self.find_all_query(query_parameters=query_parameters)
        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self,
        *,
        query_parameters: SkillQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> dict[str, Any]:
        """Build MongoDB filter from query parameters."""
        filter = self._build_field_filter(query_parameters=query_parameters)

        filter = self._merge_or_filters(
            base=filter,
            additional=self._build_keyword_filter(keyword=query_parameters.keyword),
        )

        filter = self._merge_or_filters(
            base=filter,
            additional=self._build_scope_filter(
                scope=query_parameters.scope,
                current_username=query_parameters.current_username,
                current_group_ids=query_parameters.current_group_ids,
            ),
        )

        if query_parameters.access_permission:
            shared_target_filter = await self._build_shared_target_filter(
                access_permission=query_parameters.access_permission
            )
            if filter:
                filter = {"$and": [filter, shared_target_filter]}
            else:
                filter = shared_target_filter

        return filter

    @staticmethod
    def _build_keyword_filter(*, keyword: str | None) -> dict[str, Any]:
        """Build keyword search filter using tokenized search_tokens.

        검색어를 Kiwi로 토큰화한 뒤 search_tokens 필드와 매칭한다.
        각 원본 토큰에 대해 alias 그룹이 있으면 $in으로 OR 매칭,
        원본 토큰이 여러 개면 $and로 모두 매칭되어야 한다.
        토큰화가 안 되는 검색어(1글자 등)는 기존 regex fallback.
        """
        if not keyword or not keyword.strip():
            return {}

        # 검색어에서 원본 토큰만 추출 (alias 확장 없이)
        normalized = KoreanTextNormalizer.normalize(keyword)
        original_tokens = KoreanTokenizer.extract_tokens(normalized)

        if not original_tokens:
            # fallback: 기존 regex 검색 (1글자 검색어 등)
            keyword_regex = {
                "$regex": get_escaped_regex_pattern(keyword),
                "$options": "i",
            }
            return {
                "$or": [
                    {"name": keyword_regex},
                    {"system_name": keyword_regex},
                    {"description": keyword_regex},
                ]
            }

        # 각 원본 토큰에 대해: 해당 토큰 OR alias 중 하나라도 매칭
        # 원본 토큰이 여러 개면 모든 토큰 그룹이 매칭되어야 함 ($and)
        conditions = []
        for token in sorted(original_tokens):
            aliases = AliasExpander.expand({token})
            if len(aliases) > 1:
                # alias 그룹이 있으면 $in으로 OR 매칭
                conditions.append({"search_tokens": {"$in": sorted(aliases)}})
            else:
                # alias 없으면 단일 토큰 매칭
                conditions.append({"search_tokens": token})

        if len(conditions) == 1:
            return conditions[0]
        return {"$and": conditions}

    @staticmethod
    def _build_field_filter(
        *, query_parameters: SkillQueryParameters
    ) -> dict[str, Any]:
        """Build exact-match field filters."""
        filter: dict[str, Any] = {}

        if query_parameters.name:
            filter["name"] = query_parameters.name

        if query_parameters.system_name:
            filter["system_name"] = query_parameters.system_name

        if query_parameters.categories:
            filter["categories"] = {"$in": query_parameters.categories}

        if query_parameters.shared_type and query_parameters.exclude_shared_type:
            msg = "shared_type and exclude_shared_type are mutually exclusive"
            raise ValueError(msg)

        if query_parameters.shared_type:
            filter["shared_target.shared_type"] = query_parameters.shared_type
        elif query_parameters.exclude_shared_type:
            filter["shared_target.shared_type"] = {
                "$ne": query_parameters.exclude_shared_type
            }

        if query_parameters.created_by:
            filter["created_by"] = query_parameters.created_by

        if query_parameters.updated_by:
            filter["updated_by"] = query_parameters.updated_by

        if query_parameters.labels:
            for label in query_parameters.parsed_labels:
                filter[f"labels.{label.key}"] = label.value

        return filter

    @staticmethod
    def _merge_or_filters(
        *, base: dict[str, Any], additional: dict[str, Any]
    ) -> dict[str, Any]:
        """Merge two filters, handling top-level operator key collisions.

        $or, $and 등 같은 키가 양쪽에 있으면 {**base, **additional}로 하나가 유실된다.
        충돌하는 키가 있으면 $and로 감싸서 양쪽 모두 적용되도록 한다.
        """
        if not additional:
            return base
        if not base:
            return additional

        conflicting_keys = set(base.keys()) & set(additional.keys())
        if conflicting_keys:
            return {"$and": [base, additional]}

        return {**base, **additional}

    async def find_by_name(
        self,
        *,
        name: str,
        exclude_id: str | None = None,
        session: AsyncIOMotorClientSession | None = None,
    ) -> Skill | None:
        """Find a Skill by name for duplicate checking.

        Optionally exclude a specific ID (for update operations).
        """
        filter: dict[str, Any] = {"name": name}

        if exclude_id:
            try:
                filter["_id"] = {"$ne": ObjectId(exclude_id)}
            except InvalidId as e:
                raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            return None

        return Skill(**document)

    async def find_by_system_name(
        self,
        *,
        system_name: str,
        exclude_id: str | None = None,
        session: AsyncIOMotorClientSession | None = None,
    ) -> Skill | None:
        """Find a Skill by system_name for duplicate checking.

        Optionally exclude a specific ID (for update operations).
        """
        filter: dict[str, Any] = {"system_name": system_name}

        if exclude_id:
            try:
                filter["_id"] = {"$ne": ObjectId(exclude_id)}
            except InvalidId as e:
                raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            return None

        return Skill(**document)

    async def increment_like_count(
        self,
        *,
        item_id: str,
        delta: int,
        session: AsyncIOMotorClientSession | None = None,
    ) -> None:
        """Increment or decrement like_count by delta using $inc."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        await self._collection.update_one(
            filter=filter,
            update={"$inc": {"like_count": delta}},
            session=session,
        )

    async def find_by_ids(
        self,
        *,
        ids: list[str],
        exclude_shared_type: str | None = None,
        access_permission: AccessPermission | None = None,
        exclude_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> list[Skill]:
        """Find Skills by a list of IDs with optional filters.

        Used for Trending — fetch Skills by aggregation result IDs in one query.
        """
        if not ids:
            return []

        # Skip invalid ObjectId strings instead of failing the entire query
        object_ids = []
        for item_id in ids:
            try:
                object_ids.append(ObjectId(item_id))
            except InvalidId:
                logger.warning(f"Skipping invalid ObjectId in find_by_ids: {item_id}")

        if not object_ids:
            return []

        filter: dict[str, Any] = {"_id": {"$in": object_ids}}

        if exclude_shared_type:
            filter["shared_target.shared_type"] = {"$ne": exclude_shared_type}

        if access_permission:
            shared_target_filter = await self._build_shared_target_filter(
                access_permission=access_permission
            )
            filter = {"$and": [filter, shared_target_filter]}

        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=[]
        )

        cursor = self._collection.find(filter, projection=projection, session=session)

        skills = []
        async for document in cursor:
            skills.append(Skill(**document))

        return skills

    @staticmethod
    def _build_scope_filter(
        *,
        scope: SkillScope | None,
        current_username: str | None,
        current_group_ids: list[str] | None = None,
    ) -> dict[str, Any]:
        """Build scope tab filter for Skill listing.

        ALL → 빈 필터 (access_permission 필터가 처리, $or 중복 방지).
        SHARED → shared_users + shared_groups 모두 확인.
        """
        if scope is None or scope == SkillScope.ALL:
            return {}

        if scope == SkillScope.PUBLIC:
            return {"shared_target.shared_type": SharedType.PUBLIC.value}

        if current_username is None:
            msg = "current_username is required for MY and SHARED scopes"
            raise ValueError(msg)

        if scope == SkillScope.MY:
            return {"created_by": current_username}

        if scope == SkillScope.SHARED:
            conditions: list[dict[str, Any]] = [
                {
                    "shared_target.shared_users": {
                        "$elemMatch": {"username": current_username}
                    }
                },
            ]
            if current_group_ids:
                conditions.append(
                    {
                        "shared_target.shared_groups": {
                            "$elemMatch": {
                                "group_id": {"$in": current_group_ids}
                            }
                        }
                    }
                )
            return {"$or": conditions} if len(conditions) > 1 else conditions[0]

        return {}

    async def get_category_counts(
        self,
        *,
        filter: dict[str, Any],
    ) -> list[dict]:
        """Get category counts within the given filter.

        MongoDB aggregation: $match → $unwind → $group → $sort → $project.
        categories가 빈 배열인 Skill은 $unwind에서 제외된다.

        Returns:
            [{"name": "monitoring", "count": 2}, ...] (count 내림차순)
        """
        pipeline = [
            {"$match": filter},
            {"$unwind": "$categories"},
            {"$group": {"_id": "$categories", "count": {"$sum": 1}}},
            {"$sort": {"count": -1}},
            {"$project": {"_id": 0, "name": "$_id", "count": 1}},
        ]
        results = []
        async for doc in self._collection.aggregate(pipeline):
            results.append(doc)
        return results
