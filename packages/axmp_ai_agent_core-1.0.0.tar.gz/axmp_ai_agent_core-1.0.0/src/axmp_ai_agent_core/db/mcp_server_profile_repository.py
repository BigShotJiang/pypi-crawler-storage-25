"""MCP server profile repository."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, Dict, List

import pymongo
from bson import ObjectId
from bson.errors import InvalidId
from motor.motor_asyncio import AsyncIOMotorClientSession
from pymongo import ReturnDocument
from pymongo.results import InsertOneResult

from axmp_ai_agent_core.db.base_repository import BaseRepository
from axmp_ai_agent_core.entity.mcp_server_profile import McpServerProfile
from axmp_ai_agent_core.entity.shared_target import SharedTarget
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.filter.mcp_server_profile_query import (
    McpServerProfileQueryParameters,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    MAX_LIMIT,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import get_escaped_regex_pattern
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class McpServerProfileRepository(BaseRepository[McpServerProfile]):
    """MCP server profile repository."""

    async def insert(
        self,
        *,
        item: McpServerProfile,
        session: AsyncIOMotorClientSession | None = None,
    ) -> str:
        """Insert a new MCP server profile into the repository."""
        item.created_at = datetime.now(DEFAULT_TIME_ZONE)
        item.updated_at = item.created_at

        mcp_profile_dict = item.model_dump(
            by_alias=True, exclude=["id", "created_at", "updated_at"]
        )
        mcp_profile_dict["created_at"] = item.created_at
        mcp_profile_dict["updated_at"] = item.updated_at

        result: InsertOneResult = await self._collection.insert_one(
            mcp_profile_dict, session=session
        )

        return str(result.inserted_id)

    async def update(
        self,
        *,
        item: McpServerProfile,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProfile | None:
        """Update an MCP server profile in the repository."""
        try:
            filter = {"_id": ObjectId(item.id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        item.updated_at = datetime.now(DEFAULT_TIME_ZONE)

        profile_dict = item.model_dump(
            by_alias=True,
            exclude=[
                "id",
                "created_at",
                "created_by",
                "updated_at",
            ],
        )
        profile_dict["updated_at"] = item.updated_at

        update = {"$set": profile_dict}

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )
        if document is None:
            raise ObjectNotFoundException(item.id)

        return McpServerProfile(**document)

    async def update_shared_target(
        self,
        *,
        item_id: str,
        shared_target: SharedTarget,
        updated_by: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProfile:
        """Update only shared_target and audit fields for an MCP server profile."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        updated_at = datetime.now(DEFAULT_TIME_ZONE)

        update = [
            {
                "$set": {
                    "shared_target": shared_target.model_dump(),
                    "updated_by": updated_by,
                    "updated_at": updated_at,
                }
            }
        ]

        document = await self._collection.find_one_and_update(
            filter=filter,
            update=update,
            return_document=ReturnDocument.AFTER,
            session=session,
        )

        if document is None:
            raise ObjectNotFoundException(item_id)

        return McpServerProfile(**document)

    async def delete(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> bool:
        """Delete an MCP server profile from the repository."""
        try:
            query = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one_and_delete(query, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return True

    async def find_by_id(
        self, *, item_id: str, session: AsyncIOMotorClientSession | None = None
    ) -> McpServerProfile | None:
        """Find an MCP server profile by ID."""
        try:
            filter = {"_id": ObjectId(item_id)}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return McpServerProfile(**document)

    async def find_by_id_and_version(
        self,
        *,
        item_id: str,
        version: int,
        session: AsyncIOMotorClientSession | None = None,
    ) -> McpServerProfile | None:
        """Find an MCP server profile by ID and version.

        This method matches the document by `_id` and version field.
        """
        try:
            filter = {"_id": ObjectId(item_id), "version": version}
        except InvalidId as e:
            raise InvalidObjectIDException(e)

        document = await self._collection.find_one(filter=filter, session=session)

        if document is None:
            raise ObjectNotFoundException(item_id)

        return McpServerProfile(**document)

    async def find_all(
        self,
        *,
        query_parameters: McpServerProfileQueryParameters,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        exclude_fields: list[str] = [],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[McpServerProfile]:
        """Find all MCP server profiles in the repository."""
        if page_number < 1:
            page_number = DEFAULT_PAGE_NUMBER
        if page_size < 1:
            page_size = DEFAULT_PAGE_SIZE

        skip, limit = (page_size * (page_number - 1), page_size)

        logger.debug(
            f"page_number={page_number}, page_size={page_size} so skip: {skip}, limit: {limit}"
        )

        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = (
            query_parameters.sort_field.value
            if hasattr(query_parameters.sort_field, "value")
            else "created_at"
        )

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)
        pipeline = [
            # Stage 1: Match with base filters
            {"$match": filter},
            # Stage 2: Exclude flow field for list view
            {
                "$project": {
                    "flow": 0,
                }
            },
            # Stage 3: Sort
            {"$sort": {sort_field: direction}},
            # Stage 4: Pagination
            {"$skip": skip},
            {"$limit": limit},
        ]

        # Build projection if needed
        projection = await self._build_projection(
            exclude_fields=exclude_fields, include_fields=include_fields
        )
        if projection:
            pipeline.append({"$project": projection})

        cursor = self._collection.aggregate(pipeline, session=session)

        mcp_profiles = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    mcp_profiles.append(McpServerProfile(**document))

        return mcp_profiles

    async def find_all_without_pagination(
        self,
        *,
        query_parameters: McpServerProfileQueryParameters,
        max_limit: int = MAX_LIMIT,  # if max_limit is 0, don't apply limit
        exclude_fields: list[str] = ["flow"],
        include_fields: list[str] = [],
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[McpServerProfile]:
        """Find all MCP server profiles in the repository without pagination."""
        direction = (
            pymongo.ASCENDING
            if query_parameters.sort_direction == SortDirection.ASC
            else pymongo.DESCENDING
        )

        sort_field = (
            query_parameters.sort_field.value
            if hasattr(query_parameters.sort_field, "value")
            else "created_at"
        )

        logger.debug(
            f"sort_field: {query_parameters.sort_field}, direction: {query_parameters.sort_direction} ({direction})"
        )

        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        # Build projection
        projection = {}
        if exclude_fields:
            for field in exclude_fields:
                projection[field] = 0
        if include_fields:
            for field in include_fields:
                projection[field] = 1
        cursor = self._collection.find(
            filter, projection=projection if projection else None, session=session
        ).sort(sort_field, direction)

        if max_limit > 0:
            cursor = cursor.limit(max_limit)

        mcp_profiles = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    mcp_profiles.append(McpServerProfile(**document))

        logger.debug(f"Found {len(mcp_profiles)} MCP server profiles")

        return mcp_profiles

    async def count(
        self,
        *,
        query_parameters: McpServerProfileQueryParameters,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count the number of MCP server profiles in the repository."""
        filter = await self.find_all_query(query_parameters=query_parameters)

        logger.debug(f"Filter: {filter}")

        return await self._collection.count_documents(filter=filter, session=session)

    async def find_by_name(
        self, *, name: str, session: AsyncIOMotorClientSession | None = None
    ) -> McpServerProfile | None:
        """Find an MCP server profile by name."""
        filter = {"name": name}

        document = await self._collection.find_one(filter=filter, session=session)

        return McpServerProfile(**document) if document else None

    async def find_by_system_name(
        self, *, system_name: str, session: AsyncIOMotorClientSession | None = None
    ) -> McpServerProfile | None:
        """Find an MCP server profile by system_name."""
        filter = {"system_name": system_name}

        document = await self._collection.find_one(filter=filter, session=session)

        return McpServerProfile(**document) if document else None

    async def find_by_backend_server_id(
        self,
        *,
        backend_server_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> List[McpServerProfile]:
        """Find MCP server profiles that contain a backend server node with the specified backend_server_id."""
        filter = {
            "flow.nodes": {
                "$elemMatch": {
                    "type": "Backend-Server",
                    "data.backend_server_id": backend_server_id,
                }
            }
        }

        cursor = self._collection.find(filter=filter, session=session)

        mcp_profiles = []
        if cursor is not None:
            async for document in cursor:
                if document is not None:
                    mcp_profiles.append(McpServerProfile(**document))

        return mcp_profiles

    async def count_by_oauth_provider_id(
        self,
        *,
        oauth_provider_id: str,
        session: AsyncIOMotorClientSession | None = None,
    ) -> int:
        """Count MCP server profiles referencing the given OAuth provider ID."""
        filter = {
            "flow.nodes": {
                "$elemMatch": {
                    "data.auth_config.oauth_provider_id": oauth_provider_id,
                }
            }
        }
        return await self._collection.count_documents(filter=filter, session=session)

    async def find_all_query(
        self,
        *,
        query_parameters: McpServerProfileQueryParameters,
    ) -> Dict[str, Any]:
        """Generate a query for the find_all and count functions."""
        filter: Dict[str, Any] = {}

        if query_parameters.keyword:
            keyword_regex = {
                "$regex": get_escaped_regex_pattern(query_parameters.keyword),
                "$options": "i",
            }
            filter["$or"] = [
                {"name": keyword_regex},
                {"system_name": keyword_regex},
                {"description": keyword_regex},
            ]

        if query_parameters.statuses:
            filter["status"] = {"$in": query_parameters.statuses}

        if query_parameters.created_by:
            filter["created_by"] = query_parameters.created_by

        if query_parameters.updated_by:
            filter["updated_by"] = query_parameters.updated_by

        if query_parameters.access_permission:
            shared_target_filter = await self._build_shared_target_filter(
                access_permission=query_parameters.access_permission
            )
            if filter:
                filter = {"$and": [filter, shared_target_filter]}
            else:
                filter = shared_target_filter

        logger.debug(f"Filter: {filter}")

        return filter
