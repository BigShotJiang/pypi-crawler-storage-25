"""K8s Resource Manager Factory.

This module provides a factory class for creating K8sResourceManager instances,
centralizing the creation logic and error handling for Kubernetes resource management.
"""

from axmp_ai_agent_core.db.kubernetes_config_repository import (
    KubernetesConfigQueryParameters,
    KubernetesConfigRepository,
)
from axmp_ai_agent_core.entity.kubernetes_config import KubernetesConfig
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.k8s.k8s_resource_manager import K8sResourceManager
from axmp_ai_agent_core.k8s.model.agent_instance import AgentInstance
from axmp_ai_agent_core.k8s.model.custom_resource import AIAgentCRD, McpServerCRD
from axmp_ai_agent_core.k8s.model.mcp_server_instance import McpServerInstance


class K8sManagerFactory:
    """Factory for creating K8sResourceManager instances.

    This factory provides a centralized way to create K8sResourceManager instances
    for both MCP Server and Agent resources, with standardized error handling.

    The factory supports two creation patterns:
    - Async methods (create_*_manager): Include DB lookup by cluster_id
    - Sync methods (create_*_manager_from_config): Use pre-loaded KubernetesConfig
    """

    def __init__(
        self, kubernetes_config_repository: KubernetesConfigRepository
    ) -> None:
        """Initialize the factory with the kubernetes config repository.

        Args:
            kubernetes_config_repository: Repository for KubernetesConfig entities
        """
        self._kubernetes_config_repository = kubernetes_config_repository

    async def get_all_kubernetes_configs(self) -> list[KubernetesConfig]:
        """Get all KubernetesConfig entities.

        Returns:
            List of all KubernetesConfig entities
        """
        return await self._kubernetes_config_repository.find_all_without_pagination(
            query_parameters=KubernetesConfigQueryParameters()
        )

    async def get_kubernetes_config(self, cluster_id: str) -> KubernetesConfig:
        """Get KubernetesConfig with standardized error handling.

        Args:
            cluster_id: The cluster ID to look up

        Returns:
            KubernetesConfig entity

        Raises:
            CoreServiceException: If cluster not found (ID_NOT_FOUND)
                                  or invalid ID format (INVALID_OBJECTID)
        """
        try:
            return await self._kubernetes_config_repository.find_by_id(
                item_id=cluster_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Kubernetes config not found: {cluster_id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid cluster ID: {cluster_id}",
            )

    # ===== MCP Server Instance =====

    async def create_mcp_server_manager(
        self, cluster_id: str
    ) -> K8sResourceManager[McpServerInstance]:
        """Create MCP server manager from cluster_id.

        This async method performs a DB lookup to get the cluster config,
        then creates the manager.

        Args:
            cluster_id: The Kubernetes cluster ID

        Returns:
            K8sResourceManager configured for McpServerInstance resources

        Raises:
            CoreServiceException: If cluster not found or invalid ID
        """
        config = await self.get_kubernetes_config(cluster_id)
        return self.create_mcp_server_manager_from_config(config)

    def create_mcp_server_manager_from_config(
        self, cluster_config: KubernetesConfig
    ) -> K8sResourceManager[McpServerInstance]:
        """Create MCP server manager from pre-loaded config.

        This sync method creates a manager without DB lookup, useful when
        the config is already available (e.g., from batch operations).

        Args:
            cluster_config: Pre-loaded KubernetesConfig entity

        Returns:
            K8sResourceManager configured for McpServerInstance resources
        """
        return K8sResourceManager[McpServerInstance](
            resource_group=McpServerCRD.GROUP,
            resource_version=McpServerCRD.VERSION,
            resource_plural=McpServerCRD.PLURAL,
            resource_class=McpServerInstance,
            cluster_config=cluster_config,
        )

    # ===== Agent Instance =====

    async def create_agent_manager(
        self, cluster_id: str
    ) -> K8sResourceManager[AgentInstance]:
        """Create agent manager from cluster_id.

        This async method performs a DB lookup to get the cluster config,
        then creates the manager.

        Args:
            cluster_id: The Kubernetes cluster ID

        Returns:
            K8sResourceManager configured for AgentInstance resources

        Raises:
            CoreServiceException: If cluster not found or invalid ID
        """
        config = await self.get_kubernetes_config(cluster_id)
        return self.create_agent_manager_from_config(config)

    def create_agent_manager_from_config(
        self, cluster_config: KubernetesConfig
    ) -> K8sResourceManager[AgentInstance]:
        """Create agent manager from pre-loaded config.

        This sync method creates a manager without DB lookup, useful when
        the config is already available (e.g., from batch operations).

        Args:
            cluster_config: Pre-loaded KubernetesConfig entity

        Returns:
            K8sResourceManager configured for AgentInstance resources
        """
        return K8sResourceManager[AgentInstance](
            resource_group=AIAgentCRD.GROUP,
            resource_version=AIAgentCRD.VERSION,
            resource_plural=AIAgentCRD.PLURAL,
            resource_class=AgentInstance,
            cluster_config=cluster_config,
        )
