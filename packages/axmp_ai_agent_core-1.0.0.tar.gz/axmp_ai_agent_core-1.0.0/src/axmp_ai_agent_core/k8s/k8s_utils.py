"""Kubernetes utility functions."""

from __future__ import annotations

import json
import re
from typing import TYPE_CHECKING, Any, Callable

from axmp_ai_agent_core.entity.kubernetes_config import DEFAULT_PORT
from axmp_ai_agent_core.k8s.model.base_instance import BaseInstance

if TYPE_CHECKING:
    from axmp_ai_agent_core.entity import AgentProfile
    from axmp_ai_agent_core.entity.kubernetes_config import KubernetesConfig


# ===========================================
# Name Validation Functions
# ===========================================


def sanitize_kubernetes_name(name: str) -> str:
    """Sanitize a name to be valid for Kubernetes resources.

    Kubernetes names must:
    - contain only lowercase letters, numbers, and hyphens
    - start with a letter
    - end with a letter or number
    - be at most 63 characters
    """
    # Convert to lowercase and replace invalid characters with hyphens
    sanitized = re.sub(r"[^a-z0-9-]", "-", name.lower())
    # Remove consecutive hyphens
    sanitized = re.sub(r"-+", "-", sanitized)
    # Ensure starts with letter
    if sanitized and not sanitized[0].isalpha():
        sanitized = "r-" + sanitized
    # Remove leading/trailing hyphens
    sanitized = sanitized.strip("-")
    # Truncate to 63 characters
    if len(sanitized) > 63:
        sanitized = sanitized[:63].rstrip("-")
    return sanitized or "resource"


# ===========================================
# Metadata Utility Functions
# ===========================================


def apply_annotations(
    *,
    manifest: dict[str, Any],
    description: str | None,
    profile_version: str,
) -> None:
    """Ensure annotations exist and apply deployment metadata.

    Kubernetes requires annotation values to be strings. Cast defensively.
    """
    metadata = manifest.setdefault("metadata", {})
    annotations = metadata.setdefault("annotations", {})
    annotations["description"] = "" if description is None else str(description)
    annotations["profile_version"] = str(profile_version)


def ensure_labels(
    *,
    manifest: dict[str, Any],
    labels: dict[str, str | None],
) -> None:
    """Ensure labels exist and update with provided values."""
    metadata = manifest.setdefault("metadata", {})
    manifest_labels = metadata.setdefault("labels", {})
    manifest_labels.update({k: v for k, v in labels.items() if v is not None})


# ===========================================
# Runtime Configuration Functions
# ===========================================


def create_env_vars(
    resource_type: str, profile_data: AgentProfile, port: int
) -> list[dict[str, str]]:
    """Create environment variables for the runtime."""
    profile_name = profile_data.system_name
    profile_id = profile_data.id
    prefix = resource_type.upper().replace("-", "_")
    return [
        {"name": f"AXMP_{prefix}_NAME", "value": profile_name},
        {"name": f"AXMP_{prefix}_PORT", "value": str(port)},
        {"name": f"AXMP_{prefix}_PROFILE_ID", "value": profile_id},
        {
            "name": f"AXMP_{prefix}_PROFILE_BASE_PATH",
            "value": f"/app/{resource_type.replace('-', '_')}_profiles",
        },
    ]


def create_configmap_data(
    profile_data: AgentProfile,
) -> dict[str, str]:
    """Build ConfigMap data for deployment."""
    configmap_data = {}

    # Store core configuration as JSON
    core_config = {
        "agent_type": profile_data.agent_type.value
        if profile_data.agent_type
        else None,
        "runtime_type": profile_data.runtime_type.value
        if profile_data.runtime_type
        else None,
        "deployment_mode": profile_data.deployment_mode.value
        if profile_data.deployment_mode
        else None,
    }

    # Remove None values
    core_config = {k: v for k, v in core_config.items() if v is not None}
    configmap_data["config.json"] = json.dumps(core_config, indent=2)

    # TODO: implement this later for agent provisioning
    # Store authentication config if present
    # if profile_data.auth_config:
    #     configmap_data["auth_config.json"] = profile_data.auth_config.model_dump_json(
    #         indent=2,
    #         by_alias=True,
    #         exclude_none=True,
    #     )

    # Store endpoint config if present
    # if profile_data.endpoint_config:
    #     configmap_data["endpoint_config.json"] = (
    #         profile_data.endpoint_config.model_dump_json(
    #             indent=2,
    #             by_alias=True,
    #             exclude_none=True,
    #         )
    #     )

    # Store flow data as JSON (contains nodes, edges, and complete workflow)
    if profile_data.flow:
        configmap_data["flow.json"] = profile_data.flow.model_dump_json(
            indent=2,
            by_alias=True,
            exclude_none=True,
        )

    return configmap_data


def build_k8s_runtime_config(
    *,
    cluster_config: KubernetesConfig,
    profile_data: AgentProfile,
    resource_type: str = "agent",
) -> tuple[dict, list[dict]]:
    """Prepare external runtime configs and common cluster metadata."""
    port = DEFAULT_PORT

    configmap_data = create_configmap_data(profile_data=profile_data)
    env_vars = create_env_vars(
        profile_data=profile_data,
        resource_type=resource_type,
        port=port,
    )

    return (configmap_data, env_vars)


# ===========================================
# Manifest Builder Functions
# ===========================================


def get_or_create_instance_id(
    existing_instance: BaseInstance | None,
    id_generator: Callable[[], str],
) -> str:
    """Get existing instance ID or create new one.

    Args:
        existing_instance: Existing instance with metadata.labels.instance-id
        id_generator: Function to generate new instance ID

    Returns:
        Instance ID string
    """
    if existing_instance:
        labels = existing_instance.metadata.labels or {}
        instance_id = labels.get("instance-id")
        if not instance_id:
            from axmp_ai_agent_core.exception.service_exceptions import (
                CoreError,
                CoreServiceException,
            )

            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="Existing instance does not have instance-id label",
            )
        return instance_id
    else:
        return id_generator()


def prepare_instance_labels(
    *,
    cluster_name: str,
    instance_id: str,
    cluster_id: str,
    profile_id: str,
    created_by: str,
    updated_by: str,
    existing_instance: BaseInstance | None = None,
) -> dict[str, str]:
    """Prepare instance labels for deployment."""
    labels = {
        "cluster-name": cluster_name,
        "instance-id": instance_id,
        "cluster-id": cluster_id,
        "profile-id": profile_id,
    }

    if existing_instance:
        existing_labels = existing_instance.metadata.labels or {}
        existing_created_by = existing_labels.get("created-by")
        labels["created-by"] = (
            existing_created_by if existing_created_by else updated_by
        )
    else:
        labels["created-by"] = created_by

    labels["updated-by"] = updated_by

    return labels


def build_instance_labels(
    *,
    manifest: dict[str, Any],
    cluster_name: str,
    instance_id: str,
    cluster_id: str,
    profile_id: str,
    created_by: str,
    updated_by: str,
    existing_instance: BaseInstance | None = None,
) -> dict[str, str]:
    """Prepare labels and apply them to the manifest's metadata.labels.

    Returns the computed labels for optional external use.
    """
    labels = prepare_instance_labels(
        cluster_name=cluster_name,
        instance_id=instance_id,
        cluster_id=cluster_id,
        profile_id=profile_id,
        created_by=created_by,
        updated_by=updated_by,
        existing_instance=existing_instance,
    )

    ensure_labels(manifest=manifest, labels=labels)
    return labels
