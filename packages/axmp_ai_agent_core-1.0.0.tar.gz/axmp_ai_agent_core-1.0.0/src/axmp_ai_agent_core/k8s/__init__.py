"""Kubernetes integration for managing agent and MCP server CRDs."""
