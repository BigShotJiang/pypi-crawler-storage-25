"""Kubernetes custom resource models for agent and MCP server instances."""
