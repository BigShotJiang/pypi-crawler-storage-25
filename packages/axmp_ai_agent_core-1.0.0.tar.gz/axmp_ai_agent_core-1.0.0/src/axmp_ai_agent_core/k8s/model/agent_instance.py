"""Agent Instance Entity. This entity is used to store the instance of the agent."""

from __future__ import annotations

from axmp_ai_agent_core.k8s.model.base_instance import (
    BaseInstance,
    BaseInstanceSpec,
    BaseInstanceStatus,
)


class AgentInstanceSpec(BaseInstanceSpec):
    """Agent instance specification."""

    pass


class AgentInstanceStatus(BaseInstanceStatus):
    """Agent instance status (simplified for actual usage)."""

    pass


class AgentInstance(BaseInstance):
    """AI Agent instance entity."""

    kind: str = "AiAgent"
    # Note: When creating an instance in the service, could there be cases without a spec? If not, remove allowing None.
    spec: AgentInstanceSpec | None = None
    status: AgentInstanceStatus | None = None
