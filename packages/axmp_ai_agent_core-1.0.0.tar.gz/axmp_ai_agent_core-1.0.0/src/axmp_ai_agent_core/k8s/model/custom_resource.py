"""Custom resource entity."""

from enum import StrEnum
from typing import Any, Dict, List, Union

from pydantic import BaseModel, Field


class Phase(StrEnum):
    """AxMcpServer phase status."""

    PENDING = "Pending"
    RUNNING = "Running"
    FAILED = "Failed"
    SUCCEEDED = "Succeeded"
    UNKNOWN = "Unknown"
    PARTIALLY_READY = "PartiallyReady"
    TERMINATED = "TERMINATED"


class LoadBalancingType(StrEnum):
    """Load balancing algorithm type."""

    ROUND_ROBIN = "round_robin"
    SESSION_AFFINITY = "session_affinity"


class StudioProvisionType(StrEnum):
    """Studio provisioning type."""

    INTERNAL = "internal"


class ServiceType(StrEnum):
    """Service type."""

    CLUSTER_IP = "ClusterIP"
    NODE_PORT = "NodePort"
    LOAD_BALANCER = "LoadBalancer"


class NetworkProtocol(StrEnum):
    """Network protocol."""

    TCP = "TCP"
    UDP = "UDP"
    SCTP = "SCTP"


class ImagePullPolicy(StrEnum):
    """Image pull policy."""

    ALWAYS = "Always"
    IF_NOT_PRESENT = "IfNotPresent"
    NEVER = "Never"


class RestartPolicy(StrEnum):
    """Restart policy."""

    ALWAYS = "Always"
    ON_FAILURE = "OnFailure"
    NEVER = "Never"


class SessionAffinity(StrEnum):
    """Session affinity."""

    NONE = "None"
    CLIENT_IP = "ClientIP"


class ExposeType(StrEnum):
    """Expose type for service."""

    CLUSTER_IP = "CLUSTER_IP"
    NODE_PORT = "NODE_PORT"
    LOAD_BALANCER = "LOAD_BALANCER"


# ===== CRD CONFIGURATIONS =====
class AIAgentCRD:
    """AIAgent CRD configuration."""

    GROUP = "platform.axmp.skcloud.io"
    VERSION = "v1"
    PLURAL = "aiagents"
    KIND = "AIAgent"


class McpServerCRD:
    """McpServer CRD configuration."""

    GROUP = "platform.axmp.skcloud.io"
    VERSION = "v1"
    PLURAL = "mcpservers"
    KIND = "McpServer"


# ===== MODELS =====
class EnvVar(BaseModel):
    """Environment variable."""

    name: str
    value: str | None = None
    value_from: Dict[str, Any] | None = Field(default=None, alias="valueFrom")


class ResourceRequirements(BaseModel):
    """Resource requirements."""

    cpu: str | None = None
    memory: str | None = None


class Resources(BaseModel):
    """Resource specification."""

    requests: ResourceRequirements | None = None
    limits: ResourceRequirements | None = None


class Capabilities(BaseModel):
    """Security capabilities."""

    add: List[str] | None = None
    drop: List[str] | None = None


class SeccompProfile(BaseModel):
    """Seccomp profile."""

    type: str


class SecurityContext(BaseModel):
    """Security context."""

    run_as_user: int | None = Field(default=None, alias="runAsUser")
    run_as_group: int | None = Field(default=None, alias="runAsGroup")
    run_as_non_root: bool | None = Field(default=None, alias="runAsNonRoot")
    read_only_root_filesystem: bool | None = Field(
        default=None, alias="readOnlyRootFilesystem"
    )
    allow_privilege_escalation: bool | None = Field(
        default=None, alias="allowPrivilegeEscalation"
    )
    privileged: bool | None = None
    proc_mount: str | None = Field(default=None, alias="procMount")
    apparmor_profile: str | None = Field(default=None, alias="apparmorProfile")
    capabilities: Capabilities | None = None
    seccomp_profile: SeccompProfile | None = Field(default=None, alias="seccompProfile")


class VolumeMount(BaseModel):
    """Volume mount."""

    name: str
    mount_path: str = Field(..., alias="mountPath")
    sub_path: str | None = Field(default=None, alias="subPath")


class Container(BaseModel):
    """Container specification."""

    name: str
    image: str
    image_pull_policy: ImagePullPolicy | None = Field(
        default=None, alias="imagePullPolicy"
    )
    command: List[str] | None = None
    args: List[str] | None = None
    env: List[EnvVar] | None = None
    resources: Resources | None = None
    security_context: SecurityContext | None = Field(
        default=None, alias="securityContext"
    )
    volume_mounts: List[VolumeMount] | None = Field(default=None, alias="volumeMounts")


class SessionAffinityConfig(BaseModel):
    """Session affinity configuration."""

    timeout_seconds: int | None = Field(default=None, alias="timeoutSeconds")


class NetworkPolicyPort(BaseModel):
    """Network policy port."""

    port: Union[str, int] | None = None
    protocol: NetworkProtocol | None = None
    end_port: int | None = Field(default=None, alias="endPort")


class IPBlock(BaseModel):
    """IP block specification."""

    cidr: str
    except_cidrs: List[str] | None = Field(default=None, alias="except")


class LabelSelector(BaseModel):
    """Label selector."""

    match_labels: Dict[str, str] | None = Field(default=None, alias="matchLabels")


class NetworkPolicyPeer(BaseModel):
    """Network policy peer."""

    ip_block: IPBlock | None = Field(default=None, alias="ipBlock")
    namespace_selector: LabelSelector | None = Field(
        default=None, alias="namespaceSelector"
    )
    pod_selector: LabelSelector | None = Field(default=None, alias="podSelector")


class NetworkPolicyIngressRule(BaseModel):
    """Network policy ingress rule."""

    from_peers: List[NetworkPolicyPeer] | None = Field(default=None, alias="from")
    ports: List[NetworkPolicyPort] | None = None


class NetworkPolicyEgressRule(BaseModel):
    """Network policy egress rule."""

    to_peers: List[NetworkPolicyPeer] | None = Field(default=None, alias="to")
    ports: List[NetworkPolicyPort] | None = None


class NetworkPolicySpec(BaseModel):
    """Network policy spec."""

    pod_selector: LabelSelector = Field(..., alias="podSelector")
    policy_types: List[str] | None = Field(default=None, alias="policyTypes")
    ingress: List[NetworkPolicyIngressRule] | None = None
    egress: List[NetworkPolicyEgressRule] | None = None


class NetworkPolicy(BaseModel):
    """Network policy."""

    name: str
    spec: NetworkPolicySpec


class Port(BaseModel):
    """Port specification."""

    port: int
    target_port: int | None = Field(default=None, alias="targetPort")
    protocol: NetworkProtocol | None = None
    node_port: int | None = Field(default=None, alias="nodePort")


class RollingUpdateStrategy(BaseModel):
    """Rolling update strategy."""

    max_surge: str | None = Field(default=None, alias="maxSurge")
    max_unavailable: str | None = Field(default=None, alias="maxUnavailable")


class Toleration(BaseModel):
    """Toleration."""

    key: str
    operator: str | None = None
    value: str | None = None
    effect: str | None = None


class NodeSelectorRequirement(BaseModel):
    """Node selector requirement for affinity."""

    key: str
    operator: str | None = None
    values: List[str] | None = None


class Affinity(BaseModel):
    """Node affinity configuration."""

    match_expressions: List[NodeSelectorRequirement] | None = Field(
        default=None, alias="matchExpressions"
    )


class TopologySpreadConstraint(BaseModel):
    """Topology spread constraint."""

    max_skew: int | None = Field(default=None, alias="maxSkew")
    topology_key: str | None = Field(default=None, alias="topologyKey")
    when_unsatisfiable: str | None = Field(default=None, alias="whenUnsatisfiable")
    label_selector: LabelSelector | None = Field(default=None, alias="labelSelector")


class Endpoints(BaseModel):
    """Endpoints configuration."""

    external: str | None = None
    internal: List[str] | None = None
    ports: List[str] | None = None
    service_ip: str | None = Field(default=None, alias="serviceIP")


class ConfigMapVolume(BaseModel):
    """Model for Kubernetes ConfigMap volume."""

    name: str


class SecretVolume(BaseModel):
    """Model for Kubernetes Secret volume."""

    secret_name: str = Field(..., alias="secretName")


class EmptyDirVolume(BaseModel):
    """Model for Kubernetes EmptyDir volume."""

    size_limit: str | None = Field(default=None, alias="sizeLimit")


class Volume(BaseModel):
    """Model for Kubernetes Volume."""

    name: str
    config_map: ConfigMapVolume | None = Field(default=None, alias="configMap")
    secret: SecretVolume | None = None
    empty_dir: EmptyDirVolume | None = Field(default=None, alias="emptyDir")


class LoadBalancer(BaseModel):
    """Model for Kubernetes LoadBalancer(Service)."""

    session_affinity: str | None = Field(default=None, alias="sessionAffinity")
    session_affinity_config: SessionAffinityConfig | None = Field(
        default=None, alias="sessionAffinityConfig"
    )


class AutoScaling(BaseModel):
    """Model for Kubernetes HPA (AutoScaling)."""

    min_replicas: int | None = Field(default=None, alias="minReplicas")
    max_replicas: int | None = Field(default=None, alias="maxReplicas")
    target_cpu_utilization_percentage: int | None = Field(
        default=None, alias="targetCPUUtilizationPercentage"
    )
    target_memory_utilization_percentage: int | None = Field(
        default=None, alias="targetMemoryUtilizationPercentage"
    )


class ConfigMapConfig(BaseModel):
    """Model for Kubernetes ConfigMap data."""

    data: Dict[str, str] | None = None


class LocalObjectReference(BaseModel):
    """Model for Kubernetes LocalObjectReference."""

    name: str


class Metadata(BaseModel):
    """Model for Kubernetes ObjectMeta."""

    name: str | None = None
    namespace: str | None = None
    uid: str | None = None
    resource_version: str | None = Field(default=None, alias="resourceVersion")
    generation: int | None = None
    creation_timestamp: str | None = Field(default=None, alias="creationTimestamp")
    labels: Dict[str, str] | None = None
    annotations: Dict[str, str] | None = None


class Strategy(BaseModel):
    """Model for Kubernetes Deployment Strategy."""

    type: str
    rolling_update: RollingUpdateStrategy | None = Field(
        default=None, alias="rollingUpdate"
    )
