"""Instance Entity. This entity is used to store the instance of the instance."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Dict, List

from pydantic import BaseModel, ConfigDict, Field

from axmp_ai_agent_core.k8s.model.custom_resource import (
    Affinity,
    AutoScaling,
    ConfigMapConfig,
    Container,
    Endpoints,
    LoadBalancer,
    LocalObjectReference,
    Metadata,
    NetworkPolicy,
    Phase,
    Port,
    SecurityContext,
    Strategy,
    Toleration,
    TopologySpreadConstraint,
    Volume,
)


class InstanceRunStatus(StrEnum):
    """Instance status choices aligned with the MCP Server CR phase."""

    PENDING = Phase.PENDING.value
    RUNNING = Phase.RUNNING.value
    FAILED = Phase.FAILED.value
    SUCCEEDED = Phase.SUCCEEDED.value
    UNKNOWN = Phase.UNKNOWN.value
    PARTIALLY_READY = Phase.PARTIALLY_READY.value
    TERMINATED = Phase.TERMINATED.value


class BaseInstanceSpec(BaseModel):
    """Agent instance specification."""

    replicas: int
    containers: List[Container]
    ports: List[Port]
    profile_configmap_config: ConfigMapConfig | None = Field(
        default=None, alias="profileConfigMapConfig"
    )
    swagger_configmap_config: ConfigMapConfig | None = Field(
        default=None, alias="swaggerConfigMapConfig"
    )
    internal_endpoint: List[str] | None = Field(default=None, alias="internalEndpoint")
    external_endpoint: str | None = Field(default=None, alias="externalEndpoint")
    service_type: str | None = Field(default=None, alias="serviceType")
    ingress_class_name: str | None = Field(default=None, alias="ingressClassName")
    tls_secret_name: str | None = Field(default=None, alias="tlsSecretName")
    labels: Dict[str, str] | None = None
    annotations: Dict[str, str] | None = Field(default=None, alias="annotations")
    node_selector: Dict[str, str] | None = Field(default=None, alias="nodeSelector")
    tolerations: List[Toleration] | None = None
    topology_spread_constraints: List[TopologySpreadConstraint] | None = Field(
        default=None, alias="topologySpreadConstraints"
    )
    restart_policy: str | None = Field(default=None, alias="restartPolicy")
    security_context: SecurityContext | None = Field(
        default=None, alias="securityContext"
    )
    strategy: Strategy | None = None
    auto_scaling: AutoScaling | None = Field(default=None, alias="autoScaling")
    load_balancer: LoadBalancer | None = Field(default=None, alias="loadBalancer")
    network_policies: List[NetworkPolicy] | None = Field(
        default=None, alias="networkPolicies"
    )
    volumes: List[Volume] | None = None
    image_pull_secrets: List[LocalObjectReference] | None = Field(
        default=None, alias="imagePullSecrets"
    )
    affinity: Affinity | None = None

    model_config = ConfigDict(
        revalidate_instances="always",
        populate_by_name=True,
        extra="ignore",
    )


class BaseInstanceStatus(BaseModel):
    """Agent instance status (simplified for actual usage)."""

    phase: Phase | None = None
    replicas: int | None = None
    ready_replicas: int | None = Field(default=None, alias="readyReplicas")
    observed_generation: int | None = Field(default=None, alias="observedGeneration")
    last_update_time: datetime | None = Field(default=None, alias="lastUpdateTime")
    last_reconcile_time: datetime | None = Field(
        default=None, alias="lastReconcileTime"
    )
    last_error_time: datetime | None = Field(default=None, alias="lastErrorTime")
    last_error: str | None = Field(default=None, alias="lastError")
    error_count: int | None = Field(default=None, alias="errorCount")
    endpoints: Endpoints | None = None

    model_config = ConfigDict(revalidate_instances="always", extra="ignore")


class BaseInstance(BaseModel):
    """Instance entity."""

    api_version: str = Field(
        "platform.axmp.skcloud.io/v1",
        alias="apiVersion",
        description="The API version of the instance.",
    )
    kind: str = Field(
        None,
        description="The kind of the instance.",
    )
    metadata: Metadata = Field(
        None,
        description="The metadata of the instance.",
    )
    spec: BaseInstanceSpec = Field(
        None,
        description="The spec of the instance.",
    )
    status: BaseInstanceStatus | None = Field(
        None,
        description="The status of the instance.",
    )

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="ignore",
    )
