"""MCP Server Instance Entity. This entity is used to store the instance of the mcp server."""

from axmp_ai_agent_core.k8s.model.base_instance import (
    BaseInstance,
    BaseInstanceSpec,
    BaseInstanceStatus,
)


class McpServerInstanceSpec(BaseInstanceSpec):
    """MCP Server instance specification."""

    pass


class McpServerInstanceStatus(BaseInstanceStatus):
    """MCP Server instance status (simplified for actual usage)."""

    pass


class McpServerInstance(BaseInstance):
    """MCP Server instance entity."""

    kind: str = "McpServer"
    # Note: When creating an instance in the service, could there be cases without a spec? If not, remove allowing None.
    spec: McpServerInstanceSpec | None = None
    status: McpServerInstanceStatus | None = None
