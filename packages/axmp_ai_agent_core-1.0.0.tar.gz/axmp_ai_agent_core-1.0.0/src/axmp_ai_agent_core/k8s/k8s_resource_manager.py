"""Unified Kubernetes management service combining deployment, query, and parsing utilities."""

from __future__ import annotations

import asyncio
import json
import logging
from typing import NoReturn

import yaml
from kubernetes import client, config
from kubernetes.client.rest import ApiException

from axmp_ai_agent_core.entity.kubernetes_config import KubernetesConfig
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.k8s.model.base_instance import BaseInstance
from axmp_ai_agent_core.k8s.model.custom_resource import Phase


class K8sResourceManager[T: BaseInstance]:
    """Unified Kubernetes management service combining deployment, query, and parsing capabilities."""

    def __init__(
        self,
        *,
        resource_group: str,
        resource_version: str,
        resource_plural: str,
        resource_class: type[T],
        cluster_config: KubernetesConfig,
    ) -> None:
        """Initialize unified K8s manager with shared dependencies.

        Args:
            resource_group: CRD group (e.g., "platform.axmp.skcloud.io")
            resource_version: CRD version (e.g., "v1")
            resource_plural: CRD plural name (e.g., "aiagents", "mcpservers")
            resource_class: Resource class bound to BaseInstance (e.g., McpServerInstance, AgentInstance)
            cluster_config: Kubernetes cluster configuration
        """
        self._logger = logging.getLogger(__name__)
        self._group = resource_group
        self._version = resource_version
        self._plural = resource_plural
        self._resource_class = resource_class
        self._cluster_name = cluster_config.name

        # Initialize Kubernetes API clients with isolated configuration
        # IMPORTANT: Create a new Configuration object first to avoid race conditions.
        # Using load_kube_config_from_dict() without client_configuration parameter
        # modifies the global default configuration, which can cause issues when
        # multiple clusters are accessed concurrently from different threads/requests.
        config_dict = yaml.safe_load(cluster_config.kubeconfig)
        client_configuration = client.Configuration()
        config.load_kube_config_from_dict(
            config_dict=config_dict,
            client_configuration=client_configuration,
        )
        api_client = client.ApiClient(configuration=client_configuration)
        self._custom_api = client.CustomObjectsApi(api_client)
        self._core_api = client.CoreV1Api(api_client)

    # ===========================================
    # Public API Methods
    # ===========================================

    async def create(
        self,
        *,
        instance: T,
        namespace: str = "axmp-system",
    ) -> T:
        """Create a new instance in Kubernetes.

        Args:
            instance: InstanceType entity to create
            namespace: Kubernetes namespace (default: "axmp-system")

        Returns:
            Created instance entity
        """
        try:
            manifest = instance.model_dump(
                by_alias=True,
                exclude_none=True,
                mode="json",
            )

            name = manifest.get("metadata", {}).get("name")
            self._logger.info(
                f"Creating {self._plural} resource '{name}' in namespace '{namespace}'"
            )

            created_manifest = await asyncio.to_thread(
                self._custom_api.create_namespaced_custom_object,
                group=self._group,
                version=self._version,
                namespace=namespace,
                plural=self._plural,
                body=manifest,
            )

            self._logger.info(f"Successfully created {self._plural} resource '{name}'")

            created_instance = self._resource_class.model_validate(created_manifest)
            # Parse and return the created instance
            return created_instance

        except ApiException as k8s_exc:
            self._raise_api_exception(k8s_exc, operation="create")
        except CoreServiceException:
            raise
        except Exception as exc:
            self._logger.exception("Unexpected error during create operation")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"[Cluster: {self._cluster_name}] Failed to create resource due to unexpected error.",
            ) from exc

    async def get_all(
        self,
        *,
        labels: list[str] | None = None,
        keyword: str | None = None,
        status: Phase | None = None,
        created_by: str | None = None,
        updated_by: str | None = None,
    ) -> list[T]:
        """Get all instances from Kubernetes cluster across all namespaces.

        This method retrieves all custom resources of the specified plural/kind
        from all namespaces in the cluster, then applies filters.

        Args:
            labels: Label selectors (e.g., ["profile-id=123"])
            keyword: Search keyword for name or description (client-side filter)
            status: Filter by phase status (e.g., Phase.RUNNING, Phase.PENDING)
            created_by: Filter by creator
            updated_by: Filter by updater

        Returns:
            List of instance entities matching the filters.
            Returns empty list if no resources found.
        """
        try:
            # Build label selector for server-side filtering
            label_selector = self._build_label_selector(
                labels=labels,
                created_by=created_by,
                updated_by=updated_by,
            )

            # Retrieve all custom resources across all namespaces
            # Use asyncio.to_thread() to avoid blocking the event loop
            crd_list = await asyncio.to_thread(
                self._custom_api.list_cluster_custom_object,
                group=self._group,
                version=self._version,
                plural=self._plural,
                label_selector=label_selector if label_selector else None,
            )

            items = crd_list.get("items", [])
            resources: list[T] = []

            for item in items:
                model_resource = self._resource_class.model_validate(item)

                # Apply client-side filters (keyword, status)
                if self._matches_filters(
                    resource=model_resource,
                    keyword=keyword,
                    status=status,
                    created_by=created_by,
                    updated_by=updated_by,
                ):
                    resources.append(model_resource)

            return resources

        except ApiException as exc:
            if exc.status == 404:
                # No resources found is not an error for list operations
                self._logger.debug(
                    f"No {self._plural} resources found in cluster '{self._cluster_name}'"
                )
                return []
            self._raise_api_exception(exc, operation="list")
        except CoreServiceException:
            raise
        except Exception as exc:
            self._logger.exception("Unexpected error during list operation")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"[Cluster: {self._cluster_name}] Failed to list resources due to unexpected error.",
            ) from exc

    async def get(
        self,
        *,
        name: str,
        namespace: str = "axmp-system",
    ) -> T | None:
        """Get a single instance by name.

        Args:
            name: Instance name
            namespace: Kubernetes namespace (default: "axmp-system")

        Returns:
            Instance entity or None if not found
        """
        try:
            manifest = await asyncio.to_thread(
                self._custom_api.get_namespaced_custom_object,
                group=self._group,
                version=self._version,
                namespace=namespace,
                plural=self._plural,
                name=name,
            )

            model_resource = self._resource_class.model_validate(manifest)
            return model_resource

        except ApiException as exc:
            if exc.status == 404:
                return None
            self._raise_api_exception(exc, operation="get")
        except CoreServiceException:
            raise
        except Exception as exc:
            self._logger.exception("Unexpected error during get operation")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"[Cluster: {self._cluster_name}] Failed to get resource due to unexpected error.",
            ) from exc

    async def update(
        self,
        *,
        instance: T,
    ) -> T:
        """Update an existing instance in Kubernetes.

        Args:
            instance: Updated instance entity
            namespace: Kubernetes namespace (default: "axmp-system")

        Returns:
            Updated instance entity
        """
        name = instance.metadata.name
        if not name:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="Instance metadata.name is required for update.",
            )
        namespace = instance.metadata.namespace
        try:
            updated_manifest = instance.model_dump(
                by_alias=True,
                exclude_none=True,
                mode="json",
            )
            updated_manifest.get("metadata", {}).pop("resourceVersion", None)

            patched_manifest = await asyncio.to_thread(
                self._custom_api.patch_namespaced_custom_object,
                group=self._group,
                version=self._version,
                namespace=namespace,
                plural=self._plural,
                name=name,
                body=updated_manifest,
            )

            self._logger.info(f"Successfully updated {self._plural} resource '{name}'")

            updated_instance = self._resource_class.model_validate(patched_manifest)
            return updated_instance

        except ApiException as exc:
            self._raise_api_exception(exc, operation="update")
        except CoreServiceException:
            raise
        except Exception as exc:
            self._logger.exception("Unexpected error during update operation")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"[Cluster: {self._cluster_name}] Failed to update resource due to unexpected error.",
            ) from exc

    async def delete(
        self,
        *,
        name: str,
        namespace: str = "axmp-system",
    ) -> bool:
        """Delete an instance from Kubernetes.

        Args:
            name: Instance name
            namespace: Kubernetes namespace (default: "axmp-system")

        Returns:
            True if deleted successfully, False otherwise
        """
        try:
            await asyncio.to_thread(
                self._custom_api.delete_namespaced_custom_object,
                group=self._group,
                version=self._version,
                namespace=namespace,
                plural=self._plural,
                name=name,
            )

            self._logger.info(f"Successfully deleted {self._plural} resource '{name}'")
            return True

        except ApiException as exc:
            if exc.status == 404:
                self._logger.warning(
                    f"Resource '{name}' not found in cluster '{self._cluster_name}', "
                    "treating as success"
                )
                return True
            self._raise_api_exception(exc, operation="delete")
        except CoreServiceException:
            raise
        except Exception as exc:
            self._logger.exception("Unexpected error during delete operation")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"[Cluster: {self._cluster_name}] Failed to delete resource due to unexpected error.",
            ) from exc

    async def scale(
        self,
        *,
        name: str,
        namespace: str = "axmp-system",
        replicas: int,
    ) -> bool:
        """Scale an instance to specified number of replicas.

        Scaling behavior:
        - To 0: Saves current replicas to 'before-replicas' label for later restoration
        - From 0 to N: Uses 'before-replicas' value if exists, then removes the label
        - Other cases: Removes 'before-replicas' label if exists

        Args:
            name: Instance name
            namespace: Kubernetes namespace (default: "axmp-system")
            replicas: Desired number of replicas (must be >= 0)

        Returns:
            True if scaled successfully, False otherwise
        """
        if replicas < 0:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="Replicas must be non-negative.",
            )

        try:
            got_manifest = await asyncio.to_thread(
                self._custom_api.get_namespaced_custom_object,
                group=self._group,
                version=self._version,
                namespace=namespace,
                plural=self._plural,
                name=name,
            )

            current_replicas = got_manifest.get("spec", {}).get("replicas", 1)
            labels = got_manifest.setdefault("metadata", {}).setdefault("labels", {})
            before_replicas = labels.get("before-replicas")

            # Determine target replicas and label handling
            if replicas == 0:
                # Scaling to 0: save current replicas for later restoration
                target_replicas = 0
                if current_replicas > 0:
                    labels["before-replicas"] = str(current_replicas)
                    self._logger.info(
                        f"Scaling {name} to 0 replicas, saving before-replicas={current_replicas}"
                    )
                else:
                    self._logger.info(f"Scaling {name} to 0 replicas (already at 0)")

            elif current_replicas == 0 and before_replicas:
                # Scaling up from 0: use before-replicas value, then delete label
                # Setting label to None in JSON Merge Patch deletes the label in K8s
                target_replicas = int(before_replicas)
                labels["before-replicas"] = None
                self._logger.info(
                    f"Restoring {name} from 0 using before-replicas={target_replicas}"
                )

            else:
                # Normal scaling: delete before-replicas label if exists
                target_replicas = replicas
                if "before-replicas" in labels:
                    labels["before-replicas"] = None
                self._logger.info(
                    f"Scaling {name} in namespace {namespace} to {target_replicas} replicas"
                )

            # Apply the scale change
            if "spec" in got_manifest:
                got_manifest["spec"]["replicas"] = target_replicas

            await asyncio.to_thread(
                self._custom_api.patch_namespaced_custom_object,
                group=self._group,
                version=self._version,
                namespace=namespace,
                plural=self._plural,
                name=name,
                body=got_manifest,
            )

            self._logger.info(
                f"Successfully scaled {name} to {target_replicas} replicas"
            )

            return True
        except ApiException as exc:
            self._raise_api_exception(exc, operation="scale")
        except CoreServiceException:
            raise
        except Exception as exc:
            self._logger.exception("Unexpected error during scale operation")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"[Cluster: {self._cluster_name}] Failed to scale resource due to unexpected error.",
            ) from exc

    async def upsert(
        self,
        *,
        instance: T,
        namespace: str = "axmp-system",
    ) -> T:
        """Create or update an instance in Kubernetes (upsert behavior).

        If the resource exists, it will be patched. If not, it will be created.

        Args:
            instance: InstanceType entity to create or update
            namespace: Kubernetes namespace (default: "axmp-system")

        Returns:
            The upserted instance entity
        """
        manifest = instance.model_dump(
            by_alias=True,
            exclude_none=True,
            mode="json",
        )
        name = manifest.get("metadata", {}).get("name")

        try:
            self._logger.info(
                f"Upserting {self._plural} resource '{name}' in namespace '{namespace}'"
            )

            try:
                result = await asyncio.to_thread(
                    self._custom_api.patch_namespaced_custom_object,
                    group=self._group,
                    version=self._version,
                    namespace=namespace,
                    plural=self._plural,
                    name=name,
                    body=manifest,
                )
                self._logger.info(
                    f"Successfully patched {self._plural} resource '{name}'"
                )
            except ApiException as exc:
                if getattr(exc, "status", None) == 404:
                    self._logger.info(
                        f"{self._plural} resource '{name}' not found; creating instead"
                    )
                    result = await asyncio.to_thread(
                        self._custom_api.create_namespaced_custom_object,
                        group=self._group,
                        version=self._version,
                        namespace=namespace,
                        plural=self._plural,
                        body=manifest,
                    )
                    self._logger.info(
                        f"Successfully created {self._plural} resource '{name}'"
                    )
                else:
                    raise

            return self._resource_class.model_validate(result)

        except ApiException as exc:
            self._raise_api_exception(exc, operation="upsert")
        except CoreServiceException:
            raise
        except Exception as exc:
            self._logger.exception("Unexpected error during upsert operation")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"[Cluster: {self._cluster_name}] Failed to upsert resource due to unexpected error.",
            ) from exc

    # ===========================================
    # Private Methods
    # ===========================================

    def _extract_k8s_error_message(self, k8s_exc: ApiException) -> str:
        """Extract error message from Kubernetes ApiException."""
        try:
            if hasattr(k8s_exc, "body") and k8s_exc.body:
                error_body = json.loads(k8s_exc.body)
                if isinstance(error_body, dict) and "message" in error_body:
                    return error_body["message"]
                if isinstance(error_body, dict) and "reason" in error_body:
                    return error_body["reason"]
        except (json.JSONDecodeError, AttributeError, TypeError):
            pass

        if hasattr(k8s_exc, "reason") and k8s_exc.reason:
            return k8s_exc.reason

        return f"Kubernetes API error (status: {getattr(k8s_exc, 'status', 'unknown')})"

    def _raise_api_exception(
        self,
        exc: ApiException,
        operation: str,
    ) -> NoReturn:
        """Raise CoreServiceException with appropriate error type based on status code.

        Args:
            exc: The ApiException from Kubernetes client
            operation: Description of the operation (e.g., "list", "get", "create")

        Raises:
            CoreServiceException: With appropriate error type and cluster name in message
        """
        status_code = getattr(exc, "status", None)
        error_message = self._extract_k8s_error_message(exc)
        cluster_info = f"[Cluster: {self._cluster_name}]"

        if status_code == 401:
            self._logger.warning(
                f"Unauthorized access to cluster '{self._cluster_name}' during {operation}: {exc}"
            )
            raise CoreServiceException(
                CoreError.SESSION_EXPIRED,
                details=f"{cluster_info} Unauthorized access to Kubernetes cluster. "
                f"Please check your credentials. {error_message}",
            ) from exc

        if status_code == 403:
            self._logger.warning(
                f"Forbidden access to cluster '{self._cluster_name}' during {operation}: {exc}"
            )
            raise CoreServiceException(
                CoreError.PERMISSION_DENIED,
                details=f"{cluster_info} Permission denied for this operation. "
                f"Please check your RBAC permissions. {error_message}",
            ) from exc

        # Other errors
        self._logger.error(
            f"Kubernetes API error on cluster '{self._cluster_name}' during {operation}: {exc}"
        )
        raise CoreServiceException(
            CoreError.INTERNAL_SERVER_ERROR,
            details=f"{cluster_info} Failed to {operation} resource in Kubernetes. {error_message}",
        ) from exc

    def requires_service_recreation(
        self,
        *,
        existing_instance: T,
        updated_instance: T,
    ) -> bool:
        """Determine if the Kubernetes service must be recreated."""
        existing_type = existing_instance.spec.service_type
        updated_type = updated_instance.spec.service_type

        if existing_type != updated_type:
            return True

        # Extract nodePort from existing instance
        existing_ports = existing_instance.spec.ports
        existing_port = None
        if existing_ports:
            for port in existing_ports:
                node_port = port.node_port
                if node_port:
                    existing_port = node_port
                    break

        # Extract nodePort from updated instance
        updated_ports = updated_instance.spec.ports
        updated_port = None
        if updated_ports:
            for port in updated_ports:
                node_port = port.node_port
                if node_port:
                    updated_port = node_port
                    break

        return existing_port != updated_port and (
            existing_port is not None or updated_port is not None
        )

    async def delete_service(self, *, service_name: str, namespace: str) -> bool:
        """Delete the backing Kubernetes service if it exists."""
        self._logger.info(
            "Deleting service %s from namespace %s", service_name, namespace
        )

        try:
            await asyncio.to_thread(
                self._core_api.delete_namespaced_service,
                name=service_name,
                namespace=namespace,
            )
            self._logger.info(
                "Deleted service %s from namespace %s",
                service_name,
                namespace,
            )
            return True

        except ApiException as api_exc:
            if api_exc.status == 404:
                self._logger.warning(
                    "Service %s not found in cluster '%s' during deletion; "
                    "treating as success",
                    service_name,
                    self._cluster_name,
                )
                return True
            self._raise_api_exception(api_exc, operation="delete service")
        except CoreServiceException:
            raise
        except Exception as exc:
            self._logger.exception("Unexpected error during delete service operation")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"[Cluster: {self._cluster_name}] Failed to delete service due to unexpected error.",
            ) from exc

    def _build_label_selector(
        self,
        *,
        labels: list[str] | None = None,
        created_by: str | None = None,
        updated_by: str | None = None,
    ) -> str:
        """Build label selector string for kubernetes API."""
        label_selectors: list[str] = []

        if labels:
            for label in labels:
                if ":" in label:
                    key, value = label.split(":", 1)
                    label_selectors.append(f"{key}={value}")
                else:
                    label_selectors.append(label)

        if created_by:
            label_selectors.append(f"created-by={created_by}")

        if updated_by:
            label_selectors.append(f"updated-by={updated_by}")

        return ",".join(label_selectors) if label_selectors else ""

    def _matches_filters(
        self,
        *,
        resource: T,
        keyword: str | None = None,
        status: Phase | None = None,
        created_by: str | None = None,
        updated_by: str | None = None,
    ) -> bool:
        """Check if a resource matches provided filters."""
        metadata = resource.metadata
        labels = metadata.labels or {}

        if status:
            resource_status = getattr(resource, "status", None)
            server_phase = (
                getattr(resource_status, "phase", None) if resource_status else None
            )
            if server_phase != status:
                return False

        if created_by:
            created_by_label = labels.get("created-by")
            if created_by_label != created_by:
                return False

        if updated_by:
            updated_by_label = labels.get("updated-by")
            if updated_by_label != updated_by:
                return False

        if keyword:
            keyword = keyword.lower()
            resource_name = (metadata.name or "").lower()
            resource_annotations = metadata.annotations or {}
            resource_description = resource_annotations.get("description", "").lower()

            if keyword not in resource_name and keyword not in resource_description:
                return False

        return True
