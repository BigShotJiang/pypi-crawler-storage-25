"""This module contains the service layer for provisioning functionality."""

from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import UTC, datetime
from socket import gaierror
from typing import Any, AsyncGenerator
from urllib.parse import urlencode

try:
    from builtins import ExceptionGroup
except ImportError:
    # Python < 3.11 compatibility
    ExceptionGroup = None

try:
    from httpx import ConnectError as HttpxConnectError
except ImportError:
    HttpxConnectError = None


from axmp_openapi_helper import (
    AuthenticationType,
    MultiOpenAPISpecConfig,
)
from bson import ObjectId
from langchain_core.messages import HumanMessage
from langchain_core.prompts import load_prompt
from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph.state import CompiledStateGraph
from sse_starlette.sse import ServerSentEvent

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig, NeedAuthMCPServer
from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.clients.factory import UserMCPClientFactory
from axmp_ai_agent_core.agent.playground.mcp_server_playground_agent_profile import (
    build_playground_spec_profile,
)
from axmp_ai_agent_core.agent.spec.profile_node_data import LLMSpecData
from axmp_ai_agent_core.agent.spec.types import MCPServerType
from axmp_ai_agent_core.agent.streaming.sse_generator import stream_agent_events
from axmp_ai_agent_core.agent.util.agent_cache import AsyncTTLQueue
from axmp_ai_agent_core.agent.util.agent_cache_key_format import (
    mcp_server_instance_playground_agent_cache_key,
)
from axmp_ai_agent_core.agent.util.chat_file_utils import (
    ChatFile as AgentChatFile,
)
from axmp_ai_agent_core.agent.util.chat_file_utils import (
    generate_multimodal_messages,
)
from axmp_ai_agent_core.agent.util.mcp_client_manager import McpServer
from axmp_ai_agent_core.agent.wrapper.single_agent_wrapper import SingleAgentWrapper
from axmp_ai_agent_core.db.backend_server_repository import (
    BackendServerRepository,
)
from axmp_ai_agent_core.db.chat_file_repository import ChatFileRepository
from axmp_ai_agent_core.db.llm_provider_repository import LlmProviderRepository
from axmp_ai_agent_core.db.mcp_registry_repository import McpRegistryRepository
from axmp_ai_agent_core.db.mcp_server_profile_history_repository import (
    McpServerProfileHistoryRepository,
)
from axmp_ai_agent_core.db.mcp_server_profile_repository import (
    McpServerProfileRepository,
)
from axmp_ai_agent_core.db.mcp_server_provision_status_repository import (
    McpServerProvisionStatusRepository,
)
from axmp_ai_agent_core.db.user_credential_repository import UserCredentialRepository
from axmp_ai_agent_core.db.user_repository import UserRepository
from axmp_ai_agent_core.entity.kubernetes_config import (
    DEFAULT_PORT,
    DeploymentConfig,
    KubernetesConfig,
)
from axmp_ai_agent_core.entity.mcp_registry import (
    ExtendedAPIServerConfig,
    McpRegistry,
    McpServerInstancePublishData,
    ResourceType,
    Status,
    TransportType,
)
from axmp_ai_agent_core.entity.mcp_server_profile import (
    McpServerConfigJson,
    McpServerConfigJsonCombined,
    McpServerNodeData,
    McpServerProfile,
    McpServerProfileNodeType,
)
from axmp_ai_agent_core.entity.mcp_server_profile_history import (
    McpServerProfileHistory,
)
from axmp_ai_agent_core.entity.mcp_server_provision_status import (
    McpServerConfigs,
    McpServerProvisionStatus,
)
from axmp_ai_agent_core.exception.db_exceptions import (
    ObjectNotFoundException,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.mcp_server_instance_query import (
    McpServerInstanceQueryParameters,
)
from axmp_ai_agent_core.filter.mcp_server_provision_status_query import (
    McpServerProvisionStatusQueryParameters,
)
from axmp_ai_agent_core.k8s.k8s_manager_factory import K8sManagerFactory
from axmp_ai_agent_core.k8s.k8s_resource_manager import (
    K8sResourceManager,
)
from axmp_ai_agent_core.k8s.k8s_utils import (
    get_or_create_instance_id,
    prepare_instance_labels,
)
from axmp_ai_agent_core.k8s.model.custom_resource import (
    ConfigMapConfig,
    EnvVar,
    LocalObjectReference,
    Phase,
    ResourceRequirements,
    Resources,
)
from axmp_ai_agent_core.k8s.model.mcp_server_instance import (
    McpServerInstance,
)
from axmp_ai_agent_core.service.oauth_provider_service import OAuthProviderService
from axmp_ai_agent_core.service.util.instance_sync_utils import (
    evict_stale_cache,
    handle_orphaned_instances,
)
from axmp_ai_agent_core.setting import (
    core_settings,
    mcp_server_settings,
)
from axmp_ai_agent_core.util.auth_utils import create_auth_config_from_backend_server
from axmp_ai_agent_core.util.prompt_manager import PromptFile, get_prompt_path
from axmp_ai_agent_core.util.version_utils import safe_parse_version

logger = logging.getLogger(__name__)


class McpServerInstanceService:
    """Service class for provisioning functionality."""

    # Transport type constants
    _TRANSPORT_HTTP = TransportType.HTTP.value  # For MCP server JSON config storage
    _TRANSPORT_LIBRARY = (
        TransportType.STREAMABLE_HTTP_UNDERSCORE.value
    )  # For langchain-mcp-adapters library boundary

    @staticmethod
    def _is_connection_error(exc: BaseException) -> bool:
        """Check if exception is a connection-related error."""
        # Direct type check
        if isinstance(exc, gaierror):
            return True
        if HttpxConnectError and isinstance(exc, HttpxConnectError):
            return True

        # ExceptionGroup handling (Python 3.11+)
        if ExceptionGroup and isinstance(exc, ExceptionGroup):
            return any(
                McpServerInstanceService._is_connection_error(sub_ex)
                for sub_ex in exc.exceptions
            )

        # Fallback: check exception class name for wrapped errors
        exc_type_name = type(exc).__name__
        return exc_type_name in (
            "ConnectError",
            "ConnectionError",
            "ConnectionRefusedError",
        )

    def __init__(
        self,
        backend_server_repository: BackendServerRepository,
        k8s_manager_factory: K8sManagerFactory,
        mcp_server_profile_history_repository: McpServerProfileHistoryRepository,
        mcp_server_profile_repository: McpServerProfileRepository,
        mcp_server_provision_status_repository: McpServerProvisionStatusRepository,
        mcp_registry_repository: McpRegistryRepository,
        oauth_provider_service: OAuthProviderService,
        user_repository: UserRepository | None = None,
        user_credential_repository: UserCredentialRepository | None = None,
        llm_provider_repository: LlmProviderRepository | None = None,
        agent_cache: AsyncTTLQueue | None = None,
        oauth_mcp_server_registry: OAuthMCPServerRegistry | None = None,
        mcp_client_factory: UserMCPClientFactory | None = None,
        chat_file_repository: ChatFileRepository | None = None,
    ):
        """Initialize the McpServerInstanceService."""
        self._backend_server_repository: BackendServerRepository = (
            backend_server_repository
        )
        self._k8s_manager_factory: K8sManagerFactory = k8s_manager_factory
        self._mcp_server_profile_history_repository: McpServerProfileHistoryRepository = mcp_server_profile_history_repository
        self._mcp_server_profile_repository: McpServerProfileRepository = (
            mcp_server_profile_repository
        )
        self._mcp_server_provision_status_repository: McpServerProvisionStatusRepository = mcp_server_provision_status_repository
        self._mcp_registry_repository: McpRegistryRepository = mcp_registry_repository
        self._oauth_provider_service: OAuthProviderService = oauth_provider_service
        self._user_repository = user_repository
        self._user_credential_repository = user_credential_repository
        self._llm_provider_repository = llm_provider_repository
        self._agent_cache = agent_cache
        self._oauth_mcp_server_registry = oauth_mcp_server_registry
        self._mcp_client_factory = mcp_client_factory
        self._chat_file_repository = chat_file_repository
        # Cache for status sync optimization: skip DB write when status unchanged
        # Key: (cluster_id, name, namespace), Value: (Phase, config_hash)
        self._status_cache: dict[tuple[str, str, str], tuple[Phase, int | None]] = {}

    async def _wait_for_instance_ready(
        self,
        manager: K8sResourceManager,
        name: str,
        namespace: str,
        *,
        timeout: float = 10,
        interval: float = 1,
    ) -> bool:
        """Poll until instance exists in K8s or timeout."""
        try:
            async with asyncio.timeout(timeout):
                while True:
                    if await manager.get(name=name, namespace=namespace) is not None:
                        return True
                    await asyncio.sleep(interval)
        except TimeoutError:
            logger.warning(f"Instance creation timeout after {timeout}s: {name}")
            return False

    async def get_mcp_server_instances(
        self,
        *,
        query_parameters: McpServerInstanceQueryParameters,
        page_number: int,
        page_size: int,
    ) -> list[McpServerProvisionStatus]:
        """Get MCP server instances from database with pagination.

        This method queries the provision status database instead of K8s API,
        providing faster response times and reduced load on K8s clusters.

        Args:
            query_parameters: Query parameters for filtering instances
            page_number: Page number (1-based)
            page_size: Number of items per page

        Returns:
            List of McpServerProvisionStatus entities matching the query
        """
        # Convert McpServerInstanceQueryParameters to McpServerProvisionStatusQueryParameters
        provision_query = McpServerProvisionStatusQueryParameters(
            keyword=query_parameters.keyword,
            cluster_id=query_parameters.cluster_id,
            namespace=query_parameters.namespace,
            status=query_parameters.status,
            sort_field=query_parameters.sort_field,
            sort_direction=query_parameters.sort_direction,
        )

        return await self._mcp_server_provision_status_repository.find_all(
            query_parameters=provision_query,
            page_number=page_number,
            page_size=page_size,
        )

    async def get_mcp_server_instances_count(
        self, *, query_parameters: McpServerInstanceQueryParameters
    ) -> int:
        """Count MCP server instances matching the query.

        Args:
            query_parameters: Query parameters for filtering instances

        Returns:
            Total count of matching instances
        """
        provision_query = McpServerProvisionStatusQueryParameters(
            keyword=query_parameters.keyword,
            cluster_id=query_parameters.cluster_id,
            namespace=query_parameters.namespace,
            status=query_parameters.status,
        )

        return await self._mcp_server_provision_status_repository.count(
            query_parameters=provision_query
        )

    async def k8s_get_mcp_server_instance(
        self, *, instance_id: str
    ) -> McpServerInstance:
        """Find MCP server instance by instance-id using DB provision status lookup."""
        provision_status = (
            await self._mcp_server_provision_status_repository.find_by_instance_id(
                instance_id=instance_id
            )
        )
        if not provision_status:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server provision status not found: {instance_id}",
            )

        manager = await self._k8s_manager_factory.create_mcp_server_manager(
            provision_status.cluster_id
        )
        instance = await manager.get(
            name=provision_status.name,
            namespace=provision_status.namespace,
        )
        if not instance:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server instance not found in K8s: {instance_id}",
            )
        return instance

    async def k8s_update_mcp_server_instance(
        self,
        *,
        updated_mcp_server_instance: McpServerInstance,
        cluster_id: str,
    ) -> McpServerInstance:
        """Update an advanced MCP server instance."""
        manager = await self._k8s_manager_factory.create_mcp_server_manager(cluster_id)

        return await manager.update(
            instance=updated_mcp_server_instance,
        )

    async def _prepare_instance_spec(
        self,
        *,
        mcp_server_instance: McpServerInstance,
        profile_id: str,
        mcp_server_profile_data: McpServerProfile,
        deployment_config: DeploymentConfig,
    ) -> None:
        """Set configmap, env vars, resources, and image_pull_secrets on the instance spec."""
        profile_cm_data = await self._create_profile_configmap_data(
            profile_id, mcp_server_profile_data
        )
        swagger_cm_data = await self._create_swagger_configmap_data(
            profile_id, mcp_server_profile_data
        )
        mcp_server_instance.spec.profile_configmap_config = ConfigMapConfig(
            data=profile_cm_data
        )
        mcp_server_instance.spec.swagger_configmap_config = ConfigMapConfig(
            data=swagger_cm_data
        )

        env_vars = [
            EnvVar(
                name="AXMP_MCP_SERVER_NAME", value=mcp_server_instance.metadata.name
            ),
            EnvVar(name="AXMP_MCP_PORT", value=str(DEFAULT_PORT)),
            EnvVar(name="AXMP_MCP_PROFILE_ID", value=profile_id),
            EnvVar(name="AXMP_MCP_PROFILE_BASE_PATH", value="/app/mcp_profiles"),
        ]
        # Add OAuth auth_config fields as individual env vars (extracted from MCP_SERVER node)
        if mcp_server_profile_data.flow and mcp_server_profile_data.flow.nodes:
            for node in mcp_server_profile_data.flow.nodes:
                if (
                    node.node_type == McpServerProfileNodeType.MCP_SERVER
                    and isinstance(node.data, McpServerNodeData)
                    and node.data.auth_config is not None
                ):
                    auth = node.data.auth_config
                    env_vars.append(
                        EnvVar(
                            name="AXMP_MCP_USE_AUTHORIZATION",
                            value=str(bool(auth.oauth_provider_id)),
                        )
                    )
                    # OAuth provider lookup via oauth_provider_id
                    if auth.oauth_provider_id:
                        env_vars.append(
                            EnvVar(
                                name="AXMP_OAUTH_REQUIRE_AUTHORIZATION_CONSENT",
                                value="True",
                            )
                        )
                        provider = (
                            await self._oauth_provider_service.get_oauth_provider_by_id(
                                id=auth.oauth_provider_id
                            )
                        )
                        env_vars.append(
                            EnvVar(
                                name="AXMP_OAUTH_PROVIDER",
                                value=str(provider.provider_type),
                            )
                        )
                        if mcp_server_instance.spec.external_endpoint:
                            env_vars.append(
                                EnvVar(
                                    name="AXMP_OAUTH_BASE_URL",
                                    value=f"https://{mcp_server_instance.spec.external_endpoint}",
                                )
                            )
                        if provider.issuer_url is not None:
                            env_vars.append(
                                EnvVar(
                                    name="AXMP_OAUTH_ISSUER_URL",
                                    value=provider.issuer_url,
                                )
                            )
                        if auth.client_id is not None:
                            env_vars.append(
                                EnvVar(
                                    name="AXMP_OAUTH_CLIENT_ID",
                                    value=auth.client_id,
                                )
                            )
                        if auth.client_secret is not None:
                            env_vars.append(
                                EnvVar(
                                    name="AXMP_OAUTH_CLIENT_SECRET",
                                    value=auth.client_secret,
                                )
                            )
                        env_vars.append(
                            EnvVar(
                                name="AXMP_MCP_FORWARD_TOKEN_TO_BACKEND",
                                value=str(auth.forward_token_to_backend),
                            )
                        )
                    break

        default_resources = Resources(
            requests=ResourceRequirements(
                cpu=deployment_config.cpu_request,
                memory=deployment_config.memory_request,
            ),
            limits=ResourceRequirements(
                cpu=deployment_config.cpu_limit,
                memory=deployment_config.memory_limit,
            ),
        )

        for container in mcp_server_instance.spec.containers:
            container.env = env_vars + (container.env or [])
            if container.resources is None:
                container.resources = default_resources

        secrets_name = mcp_server_settings.image_pull_secrets
        mcp_server_instance.spec.image_pull_secrets = [
            LocalObjectReference(name=secrets_name)
        ]

    def _prepare_instance_metadata(
        self,
        *,
        mcp_server_instance: McpServerInstance,
        profile_id: str,
        profile_version: int,
        cluster_config: KubernetesConfig,
        mcp_server_profile_data: McpServerProfile,
        created_by: str,
        updated_by: str,
        namespace: str,
        existing_instance: McpServerInstance | None,
    ) -> str:
        """Set namespace, annotations, labels on the instance and return instance_id."""
        mcp_server_instance.metadata.namespace = namespace
        annotations = mcp_server_instance.metadata.annotations or {}
        annotations["description"] = mcp_server_profile_data.description or ""
        annotations["profile_version"] = f"v{profile_version}"
        mcp_server_instance.metadata.annotations = annotations

        instance_id = get_or_create_instance_id(
            existing_instance, lambda: str(ObjectId())
        )
        labels = prepare_instance_labels(
            cluster_name=cluster_config.name,
            instance_id=instance_id,
            cluster_id=str(cluster_config.id),
            profile_id=profile_id,
            created_by=created_by,
            updated_by=updated_by,
            existing_instance=existing_instance,
        )
        mcp_server_instance.metadata.labels = {
            **(mcp_server_instance.metadata.labels or {}),
            **labels,
        }
        return instance_id

    async def _deploy_to_k8s(
        self,
        *,
        manager: K8sResourceManager,
        mcp_server_instance: McpServerInstance,
        existing_instance: McpServerInstance | None,
        namespace: str,
    ) -> None:
        """Create or update the instance in K8s."""
        if existing_instance is None:
            await manager.create(instance=mcp_server_instance, namespace=namespace)
            return

        if existing_instance and manager.requires_service_recreation(
            existing_instance=existing_instance,
            updated_instance=mcp_server_instance,
        ):
            await manager.upsert(instance=mcp_server_instance, namespace=namespace)
            await self._wait_for_instance_ready(
                manager,
                name=mcp_server_instance.metadata.name,
                namespace=namespace,
            )
            await manager.delete_service(
                service_name=f"{existing_instance.metadata.name}-svc",
                namespace=namespace,
            )
        else:
            await manager.upsert(instance=mcp_server_instance, namespace=namespace)

    async def _create_initial_provision_status(
        self,
        *,
        mcp_server_instance: McpServerInstance,
        profile_id: str,
        profile_version: int,
        cluster_config: KubernetesConfig,
        description: str,
        instance_id: str,
    ) -> None:
        """Create initial provision status in DB.

        Actual status/endpoints will be updated by sync_all_instances_status().
        """
        labels = mcp_server_instance.metadata.labels or {}
        name = mcp_server_instance.metadata.name
        namespace = (
            mcp_server_instance.metadata.namespace or mcp_server_settings.namespace
        )
        provision_status = McpServerProvisionStatus(
            profile_id=profile_id,
            profile_version=profile_version,
            cluster_id=cluster_config.id,
            cluster_name=cluster_config.name,
            namespace=namespace,
            description=description,
            instance_id=instance_id,
            is_published=False,
            labels=labels,
            name=name,
            status=Phase.UNKNOWN,
        )
        await (
            self._mcp_server_provision_status_repository.upsert_by_profile_and_cluster(
                item=provision_status
            )
        )
        # Invalidate status cache: the upsert just reset DB.status to UNKNOWN.
        # Without this, the next sync cycle can cache-hit and skip the correction
        # indefinitely, leaving DB.status stuck at UNKNOWN while K8s is RUNNING.
        self._status_cache.pop((cluster_config.id, name, namespace), None)

    async def execute_provisioning(
        self,
        *,
        mcp_server_instance: McpServerInstance,
        profile_id: str,
        profile_version: int,
        created_by: str,
        updated_by: str,
        cluster_config: KubernetesConfig,
        profile_history: McpServerProfileHistory,
        provision_status: McpServerProvisionStatus | None,
    ) -> McpServerInstance:
        """Create or update an MCP server instance."""
        try:
            # 1. Create K8sResourceManager
            manager = self._k8s_manager_factory.create_mcp_server_manager_from_config(
                cluster_config
            )

            # 2. Prepare profile data
            profile_data = profile_history.mcp_server_profile_data
            if isinstance(profile_data, McpServerProfile):
                mcp_server_profile_data = profile_data
            else:
                mcp_server_profile_data = McpServerProfile(**profile_data)
            deployment_config = cluster_config.deployment_config
            namespace = (
                mcp_server_instance.metadata.namespace or mcp_server_settings.namespace
            )

            # 3. Set configmap, env, resources, image_pull_secrets
            await self._prepare_instance_spec(
                mcp_server_instance=mcp_server_instance,
                profile_id=profile_id,
                mcp_server_profile_data=mcp_server_profile_data,
                deployment_config=deployment_config,
            )

            # 4. Find existing instance (for update scenarios)
            if provision_status is not None:
                existing_instance = await manager.get(
                    name=provision_status.name,
                    namespace=provision_status.namespace,
                )
            else:
                existing_instance = None

            # 5. Set metadata (namespace, annotations, labels) and resolve instance ID
            instance_id = self._prepare_instance_metadata(
                mcp_server_instance=mcp_server_instance,
                profile_id=profile_id,
                profile_version=profile_version,
                cluster_config=cluster_config,
                mcp_server_profile_data=mcp_server_profile_data,
                created_by=created_by,
                updated_by=updated_by,
                namespace=namespace,
                existing_instance=existing_instance,
            )

            # 6. Create or update in K8s
            await self._deploy_to_k8s(
                manager=manager,
                mcp_server_instance=mcp_server_instance,
                existing_instance=existing_instance,
                namespace=namespace,
            )

            # 6-1. Verify deployment (post-deploy existence check)
            deployed_instance = await manager.get(
                name=mcp_server_instance.metadata.name,
                namespace=namespace,
            )
            if not deployed_instance:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"MCP server instance not found after deployment: "
                    f"{mcp_server_instance.metadata.name}",
                )

            # 7. Create initial provision status in DB
            await self._create_initial_provision_status(
                mcp_server_instance=mcp_server_instance,
                profile_id=profile_id,
                profile_version=profile_version,
                cluster_config=cluster_config,
                description=mcp_server_profile_data.description or "",
                instance_id=instance_id,
            )

            return deployed_instance

        except CoreServiceException:
            raise
        except Exception as exc:
            operation = "deployment" if provision_status is None else "patching"
            logger.exception(f"MCP server {operation} failed")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"MCP server {operation} failed due to unexpected error.",
            ) from exc

    async def delete_mcp_server_instance(
        self,
        *,
        instance_id: str,
    ) -> bool:
        """Delete an MCP server instance: K8s resource + provision status."""
        provision_status = (
            await self._mcp_server_provision_status_repository.find_by_instance_id(
                instance_id=instance_id
            )
        )
        if not provision_status:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server provision status not found: {instance_id}",
            )

        await self.k8s_delete_mcp_server_instance(
            provision_status.name,
            provision_status.cluster_id,
            provision_status.namespace,
        )

        await self._mcp_server_provision_status_repository.delete(
            item_id=str(provision_status.id)
        )
        return True

    async def k8s_delete_mcp_server_instance(
        self,
        name: str,
        cluster_id: str,
        namespace: str,
    ) -> bool:
        """Delete mcp server instance by mcp server id."""
        manager = await self._k8s_manager_factory.create_mcp_server_manager(cluster_id)
        return await manager.delete(
            name=name,
            namespace=namespace,
        )

    async def k8s_stop_mcp_server_instance(
        self, *, name: str, cluster_id: str, namespace: str
    ) -> bool:
        """Stop internal server by setting CRD replicas to 0 and saving current replicas count in labels."""
        manager = await self._k8s_manager_factory.create_mcp_server_manager(cluster_id)
        return await manager.scale(
            name=name,
            namespace=namespace,
            replicas=0,
        )

    async def k8s_resume_mcp_server_instance(
        self, *, name: str, cluster_id: str, namespace: str
    ) -> bool:
        """Resume internal server by restoring CRD replicas from before-replicas label."""
        manager = await self._k8s_manager_factory.create_mcp_server_manager(cluster_id)
        return await manager.scale(
            name=name,
            namespace=namespace,
            replicas=1,
        )

    async def build_mcp_registry_by_instance(
        self,
        *,
        instance: McpServerInstance,
        iss: str,
        sub: str,
        username: str,
        mcp_server_configs: McpServerConfigs,
    ) -> tuple[McpRegistry, McpServer | None, bool]:
        """Build an MCP Registry for the given instance and user identity.

        Returns a 3-tuple of (mcp_registry, mcp_server, initialized):

        - `mcp_registry`: always populated so the UI can render metadata even
          when tool discovery is blocked.
        - `mcp_server`: represents the MCP server state. When OAuth login is
          needed, carries `connected=False` and a populated `auth_url` the
          frontend redirects to; otherwise `connected=True` and `tools` is
          filled. None when no server config is available.
        - `initialized`: True only when tool discovery succeeded. False
          means the server is pending auth — the caller must not treat the
          registry as fully usable yet.

        `iss`/`sub` are required because per-user OAuth tokens are attached
        when talking to tool endpoints; without the user identity we cannot
        honor server-side user scoping.
        """
        try:
            profile = await self._get_profile_by_instance(instance)

            # Resolve user from iss/sub for per-user OAuth token lookup
            user = None
            if self._user_repository is not None:
                try:
                    user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
                except ObjectNotFoundException as e:
                    raise CoreServiceException(
                        CoreError.BAD_REQUEST,
                        details=f"User not found: {e}",
                    )

            # Some callers populate only `internal` (single-endpoint setup); in that
            # case we treat it as `external` so downstream logic has a single entry.
            if mcp_server_configs.external is None:
                mcp_server_configs.external = mcp_server_configs.internal

            instance_id = instance.metadata.labels.get("instance-id")

            mcp_server: McpServer | None = None
            initialized: bool = True

            if profile and profile.id and mcp_server_configs.external is not None:
                (
                    mcp_server,
                    initialized,
                ) = await self._fetch_tools_with_oauth(
                    mcp_server_configs=mcp_server_configs,
                    profile=profile,
                    user_id=user.id if user is not None else None,
                )

            mcp_registry = McpRegistry(
                id=instance_id,
                created_by=username,
                updated_by=username,
                name=profile.name if profile else None,
                description=profile.description if profile else None,
                categories=[],
                version="",
                mcp_server_json=mcp_server_configs.external,
                internal_mcp_server_json=mcp_server_configs.internal,
                profile_id=profile.id if profile else None,
                profile_version=profile.version if profile else None,
                labels=profile.labels if profile else {},
                icon_url=profile.icon_url if profile else None,
                transport_type=TransportType.HTTP,
                resource_type=ResourceType.INTERNAL,
                is_published=False,
                status=Status.ACTIVE,
                tools=[],
            )

            return mcp_registry, mcp_server, initialized

        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error getting MCP registry by instance: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP registry: {e}",
            )

    def _build_mcp_server_configs_from_config_json(
        self, config_json: McpServerConfigJson
    ) -> list[MCPServerConfig]:
        """Convert an `McpServerConfigJson.mcpServers` dict to MCPServerConfig list."""
        configs: list[MCPServerConfig] = []
        for server_name, raw in (config_json.mcpServers or {}).items():
            if not isinstance(raw, dict):
                logger.warning(
                    "Skipping MCP server '%s' — config is not a dict", server_name
                )
                continue
            try:
                configs.append(
                    MCPServerConfig(
                        server_id=server_name,
                        transport=TransportType.HTTP,
                        url=raw.get("url"),
                        headers=raw.get("headers"),
                    )
                )
            except Exception as e:
                logger.warning(
                    "Skipping MCP server '%s' — invalid config: %s", server_name, e
                )
        return configs

    def _build_auth_url(self, user_id: str, server_id: str) -> str | None:
        """Build the OAuth login URL for the given user+server pair."""
        if (
            self._oauth_mcp_server_registry is None
            or not self._oauth_mcp_server_registry.auth_login_url
        ):
            return None
        return (
            f"{self._oauth_mcp_server_registry.auth_login_url}"
            f"?{urlencode({'user_id': user_id, 'server_id': server_id})}"
        )

    def _build_need_auth_server(
        self,
        *,
        mcp_configs: list[MCPServerConfig],
        pending_server_ids: set[str],
        user_id: str,
        profile: McpServerProfile | None,
    ) -> McpServer:
        """Build a single McpServer for the first server needing auth."""
        server_id = next(
            (
                cfg.server_id
                for cfg in mcp_configs
                if cfg.server_id in pending_server_ids
            ),
            mcp_configs[0].server_id if mcp_configs else "",
        )
        auth_url = self._build_auth_url(user_id=user_id, server_id=server_id)
        return McpServer(
            server_id=server_id,
            server_name=server_id,
            is_oauth_server=True,
            connected=False,
            tools=[],
            registry_id=profile.id if profile else None,
            resource_type=MCPServerType.INTERNAL,
            transport_type=TransportType.HTTP,
            icon_url=profile.icon_url if profile else None,
            auth_url=auth_url,
        )

    async def _fetch_tools_with_oauth(
        self,
        *,
        mcp_server_configs: McpServerConfigs,
        profile: McpServerProfile | None,
        user_id: str | None,
    ) -> tuple[McpServer | None, bool]:
        """Fetch tools from MCP server with OAuth support and external→internal fallback.

        Uses UserMCPClientFactory to attach per-user Bearer tokens when the server
        is registered as OAuth-capable. When the server needs authentication
        (pending tokens) or tool discovery ultimately fails with an auth error,
        returns a McpServer with `connected=False` and a populated `auth_url`,
        plus `initialized=False`.

        Returns:
            Tuple of (mcp_server, initialized).
        """
        # Per-user Bearer token attachment requires all three collaborators
        # (registry, client factory, user repo) plus a resolved user_id. Any
        # missing piece means we cannot scope the request to a user, so we
        # fall back to the non-OAuth discovery path instead of issuing an
        # unauthenticated request that would either 401 or leak a shared token.
        if (
            self._oauth_mcp_server_registry is None
            or self._mcp_client_factory is None
            or self._user_repository is None
            or user_id is None
        ):
            return await self._fetch_tools_legacy(mcp_server_configs, profile)

        external_configs = self._build_mcp_server_configs_from_config_json(
            mcp_server_configs.external
        )
        if not external_configs:
            logger.warning("No valid MCP server configs found — returning empty tools")
            return None, True

        # Register external endpoints with the OAuth registry (idempotent, cached)
        await self._oauth_mcp_server_registry.add_servers(external_configs)

        # Check which servers still need user authentication
        try:
            pending = await self._mcp_client_factory.get_pending_auth_servers(
                user_id=user_id, servers=external_configs
            )
        except Exception as e:
            logger.warning("Failed to check pending auth servers: %s", e)
            pending = []

        pending_server_ids = {p["server_id"] for p in pending}
        if pending_server_ids:
            logger.info(
                "MCP servers require OAuth authentication: %s", pending_server_ids
            )
            mcp_server = self._build_need_auth_server(
                mcp_configs=external_configs,
                pending_server_ids=pending_server_ids,
                user_id=user_id,
                profile=profile,
            )
            return mcp_server, False

        # All servers authenticated (or non-OAuth) — fetch tools via OAuth-aware client
        try:
            all_tools, per_server_tools = await self._get_tools_via_oauth_client(
                configs=external_configs, user_id=user_id
            )
            logger.info("Successfully connected to external MCP server endpoint")
        except Exception as e:
            logger.warning(
                "External endpoint failed (%s: %s) — trying internal endpoint",
                type(e).__name__,
                e,
            )
            return await self._fetch_tools_with_oauth_internal_fallback(
                mcp_server_configs=mcp_server_configs,
                profile=profile,
                user_id=user_id,
                external_error=e,
            )

        mcp_server = McpServer(
            server_id=external_configs[0].server_id,
            server_name=external_configs[0].server_id,
            is_oauth_server=True,
            connected=True,
            tools=all_tools,
            registry_id=profile.id if profile else None,
            resource_type=MCPServerType.INTERNAL,
            transport_type=TransportType.HTTP,
            icon_url=profile.icon_url if profile else None,
            auth_url=None,
        )
        return mcp_server, True

    async def _fetch_tools_with_oauth_internal_fallback(
        self,
        *,
        mcp_server_configs: McpServerConfigs,
        profile: McpServerProfile | None,
        user_id: str,
        external_error: BaseException,
    ) -> tuple[McpServer | None, bool]:
        """Retry tool discovery using the internal endpoint, then surface auth errors."""
        if mcp_server_configs.internal is None:
            logger.error("No internal endpoint configured; cannot fall back")
            return self._handle_tool_fetch_failure(
                configs=self._build_mcp_server_configs_from_config_json(
                    mcp_server_configs.external
                ),
                profile=profile,
                user_id=user_id,
                error=external_error,
            )

        internal_configs = self._build_mcp_server_configs_from_config_json(
            mcp_server_configs.internal
        )
        if not internal_configs:
            return self._handle_tool_fetch_failure(
                configs=self._build_mcp_server_configs_from_config_json(
                    mcp_server_configs.external
                ),
                profile=profile,
                user_id=user_id,
                error=external_error,
            )

        await self._oauth_mcp_server_registry.add_servers(internal_configs)

        # Re-check pending auth after registering the internal URL. Internal endpoints
        # may expose a different PRM, so the server_id may be newly flagged as pending.
        try:
            pending = await self._mcp_client_factory.get_pending_auth_servers(
                user_id=user_id, servers=internal_configs
            )
        except Exception as e:
            logger.warning("Failed to check pending auth servers (internal): %s", e)
            pending = []

        pending_server_ids = {p["server_id"] for p in pending}
        if pending_server_ids:
            logger.info(
                "MCP servers require OAuth authentication (internal): %s",
                pending_server_ids,
            )
            mcp_server = self._build_need_auth_server(
                mcp_configs=internal_configs,
                pending_server_ids=pending_server_ids,
                user_id=user_id,
                profile=profile,
            )
            return mcp_server, False

        try:
            all_tools, per_server_tools = await self._get_tools_via_oauth_client(
                configs=internal_configs, user_id=user_id
            )
            logger.info("Successfully connected to internal MCP server endpoint")
        except Exception as internal_e:
            logger.error("Internal MCP server endpoint also failed: %s", internal_e)
            return self._handle_tool_fetch_failure(
                configs=internal_configs,
                profile=profile,
                user_id=user_id,
                error=internal_e,
            )

        mcp_server = McpServer(
            server_id=internal_configs[0].server_id,
            server_name=internal_configs[0].server_id,
            is_oauth_server=True,
            connected=True,
            tools=all_tools,
            registry_id=profile.id if profile else None,
            resource_type=MCPServerType.INTERNAL,
            transport_type=TransportType.HTTP,
            icon_url=profile.icon_url if profile else None,
            auth_url=None,
        )
        return mcp_server, True

    def _handle_tool_fetch_failure(
        self,
        *,
        configs: list[MCPServerConfig],
        profile: McpServerProfile | None,
        user_id: str,
        error: BaseException,
    ) -> tuple[McpServer | None, bool]:
        """Classify a terminal tool-fetch failure as transport vs. auth.

        Connection-level failures (DNS/TCP/TLS against both external and
        internal endpoints) cannot be resolved by the user and are raised so
        the caller gets a real error. Everything else — most importantly a
        401 from an OAuth-protected endpoint where a pre-flight check
        passed but the tool call was rejected — is converted into a
        need-auth response. Without this conversion a stale or revoked token
        would present to the user as an empty tool list with no recovery
        affordance, which is the symptom that motivated this function.
        """
        if self._is_connection_error(error):
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=(
                    "MCP server connection failed on both external and "
                    f"internal endpoints: {error}"
                ),
            )

        # Treat non-connection errors (e.g. 401 Unauthorized) as needing auth so the
        # frontend can surface a login URL instead of silently showing empty tools.
        logger.warning(
            "Treating non-connection error as need-auth: %s: %s",
            type(error).__name__,
            error,
        )
        pending_server_ids = {cfg.server_id for cfg in configs}
        mcp_server = self._build_need_auth_server(
            mcp_configs=configs,
            pending_server_ids=pending_server_ids,
            user_id=user_id,
            profile=profile,
        )
        return mcp_server, False

    async def _get_tools_via_oauth_client(
        self,
        *,
        configs: list[MCPServerConfig],
        user_id: str,
    ) -> tuple[list[Any], dict[str, list[Any]]]:
        """Create an OAuth-aware MultiServerMCPClient and fetch tools per server."""
        client = await self._mcp_client_factory.create_shared_client(
            servers=configs, fallback_user_id=user_id
        )
        all_tools: list[Any] = []
        per_server_tools: dict[str, list[Any]] = {}
        for cfg in configs:
            try:
                server_tools = await client.get_tools(server_name=cfg.server_id)
            except Exception:
                # Propagate to trigger the external→internal fallback in the caller
                raise
            per_server_tools[cfg.server_id] = server_tools
            all_tools.extend(server_tools)
        return all_tools, per_server_tools

    async def _fetch_tools_legacy(
        self,
        mcp_server_configs: McpServerConfigs,
        profile: McpServerProfile | None,
    ) -> tuple[McpServer | None, bool]:
        """Non-OAuth tool discovery path used when user scoping is unavailable.

        Taken only when the OAuth collaborators or the user identity are
        missing — see `_fetch_tools_with_oauth` for the guard. Because we
        cannot attach a per-user Bearer token here, requests go out with
        whatever headers the config declares and no user scoping is
        honored. Production DI always wires the OAuth collaborators, so
        this path is expected to execute only under direct construction
        (e.g. unit-test fixtures) where the OAuth machinery is irrelevant.
        """
        if (
            mcp_server_configs.external is None
            or not mcp_server_configs.external.mcpServers
        ):
            return None, True

        system_name = list(mcp_server_configs.external.mcpServers.keys())[0]
        mcp_server_configs.external.mcpServers[system_name]["transport"] = (
            self._TRANSPORT_LIBRARY
        )
        raw_tools: list[Any] = []
        try:
            mcp_client = MultiServerMCPClient(
                mcp_server_configs.external.mcpServers,
            )
            raw_tools = await mcp_client.get_tools()
        except Exception as e:
            logger.warning("Legacy external endpoint failed: %s", e)
            if mcp_server_configs.internal is not None:
                try:
                    mcp_server_configs.internal.mcpServers[system_name]["transport"] = (
                        self._TRANSPORT_LIBRARY
                    )
                    mcp_client_internal = MultiServerMCPClient(
                        mcp_server_configs.internal.mcpServers,
                    )
                    raw_tools = await mcp_client_internal.get_tools()
                except Exception as internal_e:
                    logger.error("Legacy internal endpoint also failed: %s", internal_e)
                    if self._is_connection_error(internal_e):
                        raise CoreServiceException(
                            CoreError.INTERNAL_SERVER_ERROR,
                            details=(
                                "MCP server connection failed on both external "
                                f"and internal endpoints: {internal_e}"
                            ),
                        )
                    raw_tools = []
        finally:
            # Restore original transport key
            if mcp_server_configs.external and system_name in (
                mcp_server_configs.external.mcpServers or {}
            ):
                mcp_server_configs.external.mcpServers[system_name]["transport"] = (
                    self._TRANSPORT_HTTP
                )
            if mcp_server_configs.internal and system_name in (
                mcp_server_configs.internal.mcpServers or {}
            ):
                mcp_server_configs.internal.mcpServers[system_name]["transport"] = (
                    self._TRANSPORT_HTTP
                )

        mcp_server = McpServer(
            server_id=system_name,
            server_name=system_name,
            is_oauth_server=True,
            connected=True,
            tools=raw_tools,
            registry_id=profile.id if profile else None,
            resource_type=MCPServerType.INTERNAL,
            transport_type=TransportType.HTTP,
            icon_url=profile.icon_url if profile else None,
            auth_url=None,
        )
        return mcp_server, True

    async def _get_profile_by_instance(
        self, instance: McpServerInstance
    ) -> McpServerProfile:
        """Get McpServerProfile from instance metadata (profile history lookup)."""
        profile_version_str = instance.metadata.annotations.get("profile_version", "v0")
        # Handle "v1" format (new) and legacy timestamp format (마이그레이션 전 데이터)
        try:
            profile_version = safe_parse_version(profile_version_str)
        except CoreServiceException:
            # Legacy timestamp format - 마이그레이션 필요
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Legacy timestamp version format detected: {profile_version_str}. "
                "Please run migration script: scripts/migrate_mcp_profile_version.py",
            )
        profile_id = instance.metadata.labels.get("profile-id", "")
        profile_history = await self._mcp_server_profile_history_repository.find_by_profile_id_and_version(
            profile_id=profile_id, version=profile_version
        )
        return profile_history.mcp_server_profile_data

    async def _build_publish_data_by_instance(
        self, instance: McpServerInstance
    ) -> McpServerInstancePublishData:
        """Build MCP server publish data (config JSONs) from instance."""
        internal_endpoints = (
            instance.status.endpoints.internal
            if instance.status and instance.status.endpoints
            else None
        )
        external_endpoints = (
            instance.status.endpoints.external
            if instance.status and instance.status.endpoints
            else None
        )
        if not internal_endpoints:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="No internal endpoint found",
            )

        external_url = external_endpoints
        internal_url = internal_endpoints[0]

        external_scheme = "https" if instance.spec.tls_secret_name else "http"

        profile = await self._get_profile_by_instance(instance)
        system_name = profile.system_name

        api_spec = await self._generate_api_spec(profile=profile)
        backend_servers = []
        if api_spec and "backends" in api_spec:
            backend_servers = api_spec["backends"]

        headers = {}
        for backend_server in backend_servers:
            backend_server_name = backend_server.get("server_name", "")

            auth_config = backend_server.get("auth_config", {})
            auth_type = auth_config.get("type", "None")

            if auth_type == "Basic":
                headers[
                    f"{backend_server_name}{core_settings.mcp_server_separator}username"
                ] = "your-user-name"
                headers[
                    f"{backend_server_name}{core_settings.mcp_server_separator}password"
                ] = "your-password"
            elif auth_type == "Bearer":
                headers[
                    f"{backend_server_name}{core_settings.mcp_server_separator}bearer_token"
                ] = "your-bearer-token"
            elif auth_type == "ApiKey":
                headers[
                    f"{backend_server_name}{core_settings.mcp_server_separator}{auth_config.get('api_key_name', 'api_key_name')}"
                ] = "your-api-key"

        mcp_server_json = {
            system_name: {
                "transport": self._TRANSPORT_HTTP,
                "url": f"{external_scheme}://{external_url}/mcp",
                "headers": headers,
            }
        }

        internal_mcp_server_json = {
            system_name: {
                "transport": self._TRANSPORT_HTTP,
                "url": f"http://{internal_url}/mcp",
                "headers": headers,
            }
        }

        return McpServerInstancePublishData(
            mcp_server_json=mcp_server_json,
            internal_mcp_server_json=internal_mcp_server_json,
            transport_type=TransportType.HTTP,
            resource_type=ResourceType.INTERNAL,
            is_external=bool(external_url),
        )

    async def get_mcp_server_config_json_by_instance(
        self, instance: McpServerInstance
    ) -> McpServerConfigJsonCombined:
        """Get MCP server config JSON by instance - returns both external and internal JSON."""
        publish_data = await self._build_publish_data_by_instance(instance)

        external_mcp_server_json = None
        if publish_data.is_external:
            external_mcp_server_json = McpServerConfigJson(
                mcpServers=publish_data.mcp_server_json
            )
        internal_mcp_server_json = McpServerConfigJson(
            mcpServers=publish_data.internal_mcp_server_json
        )

        return McpServerConfigJsonCombined(
            mcp_server_json=external_mcp_server_json,
            internal_mcp_server_json=internal_mcp_server_json,
        )

    def _validate_instance_metadata(
        self,
        *,
        instance_id: str | None,
        cluster_id: str | None,
        name: str | None,
    ) -> None:
        """Validate required K8s instance metadata fields.

        Args:
            instance_id: The instance ID from labels
            cluster_id: The cluster ID from labels
            name: The resource name from metadata

        Raises:
            CoreServiceException: If any required field is missing
        """
        if not instance_id:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Missing required label 'instance-id' in K8s instance",
            )
        if not cluster_id:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Missing required label 'cluster-id' in K8s instance",
            )
        if not name:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Missing required field 'metadata.name' in K8s instance",
            )

    async def _sync_provision_status_metadata(
        self,
        *,
        instance: McpServerInstance,
        profile_id: str,
        profile_version: int,
        cluster_id: str,
        cluster_name: str,
        mcp_config_json: McpServerConfigs | None = None,
        use_cache: bool = False,
    ) -> bool:
        """Synchronize K8s instance metadata to DB provision status.

        This method updates or creates a provision status record with metadata
        from the K8s instance, enabling efficient DB-based queries.

        Args:
            instance: The K8s McpServerInstance with current metadata
            profile_id: The MCP server profile ID
            profile_version: The profile version
            cluster_id: The cluster ID (KubernetesConfig._id)
            cluster_name: The cluster name
            mcp_config_json: Optional MCP server config JSON
            use_cache: If True, check cache and skip DB write when status unchanged

        Returns:
            True if DB was updated, False if skipped (status unchanged)
        """
        labels = instance.metadata.labels or {}
        annotations = instance.metadata.annotations or {}

        instance_id = labels.get("instance-id")
        label_cluster_id = labels.get("cluster-id")
        name = instance.metadata.name
        # Use getattr chaining for more Pythonic null-safe access
        status = (
            getattr(getattr(instance, "status", None), "phase", None) or Phase.UNKNOWN
        )

        self._validate_instance_metadata(
            instance_id=instance_id,
            cluster_id=label_cluster_id,
            name=name,
        )

        # Cache check: skip DB read/write when both phase and config are unchanged
        namespace = instance.metadata.namespace or mcp_server_settings.namespace
        cache_key = (cluster_id, name, namespace)
        config_hash = (
            hash(mcp_config_json.model_dump_json()) if mcp_config_json else None
        )
        if use_cache:
            cached = self._status_cache.get(cache_key)
            if cached and cached[0] == status and cached[1] == config_hash:
                logger.debug(
                    f"Skipping MCP server instance {name}: status unchanged ({status})"
                )
                return False

        description = annotations.get("description")

        # Look up existing provision status by K8s identity
        provision_status = await self._mcp_server_provision_status_repository.find_by_cluster_and_name_and_namespace(
            cluster_id=cluster_id,
            name=name,
            namespace=namespace,
        )

        if not provision_status:
            # DB record not found → skip (provisioning creates the record)
            logger.warning(
                f"Skipping MCP instance {name}: no DB record found "
                f"for cluster={cluster_id}, namespace={namespace}"
            )
            return False

        # Profile ID validation: DB profile_id vs K8s label profile-id
        if provision_status.profile_id != profile_id:
            logger.warning(
                f"Profile ID mismatch for MCP instance {name}: "
                f"db={provision_status.profile_id}, k8s={profile_id} → marking UNKNOWN"
            )
            updated_provision_status = provision_status.model_copy(
                update={"status": Phase.UNKNOWN}
            )
            await self._mcp_server_provision_status_repository.update(
                item=updated_provision_status
            )
            if use_cache:
                self._status_cache[cache_key] = (Phase.UNKNOWN, None)
            return True

        # Update existing record with new metadata (immutable pattern)
        update_fields = {
            "cluster_id": cluster_id,
            "cluster_name": cluster_name,
            "namespace": namespace,
            "description": description,
            "instance_id": instance_id,
            "labels": labels,
            "name": name,
            "status": status,
        }
        update_fields["mcp_config_json"] = mcp_config_json

        # Change detection: only UPDATE when metadata actually differs
        has_changes = any(
            getattr(provision_status, field, None) != value
            for field, value in update_fields.items()
        )
        if not has_changes:
            logger.debug(f"Skipping MCP instance {name}: no metadata changes")
            if use_cache:
                self._status_cache[cache_key] = (status, config_hash)
            return False

        updated_provision_status = provision_status.model_copy(update=update_fields)

        await self._mcp_server_provision_status_repository.update(
            item=updated_provision_status
        )
        logger.info(
            f"Updated provision status metadata for profile_id={profile_id}, "
            f"instance_id={instance_id}"
        )

        # Update cache after successful DB write (only when use_cache=True)
        if use_cache:
            self._status_cache[cache_key] = (status, config_hash)

        return True

    async def _generate_api_spec(
        self, *, profile: McpServerProfile
    ) -> dict[str, Any] | None:
        """Generate API spec for the profile using helper."""
        if not profile.flow or not profile.flow.nodes:
            return None

        api_server_configs: list[ExtendedAPIServerConfig] = []

        for node in profile.flow.nodes:
            if node.node_type == McpServerProfileNodeType.BACKEND_SERVER and node.data:
                backend_server_id = node.data.backend_server_id
                tool_config = node.data.tool_config

                if not backend_server_id or not tool_config:
                    continue

                try:
                    backend_server = await self._backend_server_repository.find_by_id(
                        item_id=backend_server_id
                    )
                except ObjectNotFoundException:
                    logger.warning(
                        f"Backend server {backend_server_id} not found, skipping"
                    )
                    continue

                api_server_configs.append(
                    ExtendedAPIServerConfig(
                        server_name=backend_server.system_name,
                        endpoint=backend_server.domain,
                        base_path=backend_server.base_path,
                        timeout=10,
                        tls_verify=True,
                        spec_file_path=f"backend_server_{backend_server_id}.json",
                        tool_config=tool_config,
                        auth_config=create_auth_config_from_backend_server(
                            backend_server
                        ),
                        system_name=backend_server.system_name,
                    )
                )

        if not api_server_configs:
            return None

        return MultiOpenAPISpecConfig(backends=api_server_configs).model_dump()

    async def _create_profile_configmap_data(
        self, profile_id: str, mcp_server_profile_data: McpServerProfile
    ) -> dict[str, str]:
        """Create ConfigMap data for MCP Profile configuration (tool mappings, endpoints, auth)."""
        configmap_data = {}

        api_spec: dict[str, Any] = {}
        api_spec = await self._generate_api_spec(profile=mcp_server_profile_data)

        if api_spec:
            configmap_data[f"mcp_profile_{profile_id}.json"] = json.dumps(
                api_spec, indent=2
            )

        return configmap_data

    async def _create_swagger_configmap_data(
        self, profile_id: str, mcp_server_profile_data: McpServerProfile
    ) -> dict[str, str]:
        """Create ConfigMap data for Backend Server OpenAPI/Swagger specifications."""
        configmap_data = {}

        api_spec: dict[str, Any] = {}
        api_spec = await self._generate_api_spec(profile=mcp_server_profile_data)

        if not api_spec:
            return configmap_data

        backend_servers = []
        raw_backends = api_spec.get("backends", [])
        if isinstance(raw_backends, list):
            backend_servers = raw_backends
        else:
            logger.warning(
                f"Invalid backends format: {type(raw_backends)}, expected list"
            )

        for backend_server in backend_servers:
            if not isinstance(backend_server, dict):
                continue

            spec_file_path = backend_server.get("spec_file_path")
            if not spec_file_path:
                continue

            match = re.match(r"backend_server_([a-fA-F0-9]+)\.json", spec_file_path)
            if not match:
                continue

            backend_server_id = match.group(1)
            try:
                backend_server_entity = (
                    await self._backend_server_repository.find_by_id(
                        item_id=backend_server_id
                    )
                )
            except ObjectNotFoundException:
                logger.warning(f"BackendServer {backend_server_id} not found, skipping")
                continue

            # backend server swagger json
            if backend_server_entity.swagger_json:
                configmap_data[f"backend_server_{backend_server_id}.json"] = json.dumps(
                    backend_server_entity.swagger_json, indent=2
                )

        return configmap_data

    async def _update_mcp_registry_mcp_server_json(
        self,
        *,
        instance: McpServerInstance,
        updated_by: str,
    ) -> None:
        """Update MCP Registry mcp_server_json. Raises on failure."""
        instance_id = instance.metadata.labels.get("instance-id", "")

        existing_registry = await self._mcp_registry_repository.find_by_id(
            item_id=instance_id
        )
        if not existing_registry:
            return  # No registry to update

        publish_data = await self._build_publish_data_by_instance(instance)
        update_fields: dict = {"updated_by": updated_by}
        if publish_data.is_external:
            update_fields["mcp_server_json"] = McpServerConfigJson(
                mcpServers=publish_data.mcp_server_json
            )
        update_fields["internal_mcp_server_json"] = McpServerConfigJson(
            mcpServers=publish_data.internal_mcp_server_json
        )
        updated_registry = existing_registry.model_copy(update=update_fields)

        await self._mcp_registry_repository.update(item=updated_registry)

    # router에서 profile_id로 provision_status 리스트를 찾아서 넘겨주면, 그걸로 다 지우도록
    # 즉,mcp profile 지워지면 연계로 instance 다 지우는 로직으로 개선
    async def delete_mcp_server_instances_by_profile_id(
        self, *, profile_id: str
    ) -> int:
        """Delete all MCP server instances by profile ID."""
        logger.info(f"Deleting all MCP server instances by profile_id: {profile_id}")

        try:
            provision_statuses = (
                await self._mcp_server_provision_status_repository.find_by_profile_id(
                    profile_id=profile_id
                )
            )

            if not provision_statuses:
                logger.info(f"No provision statuses found for profile_id: {profile_id}")
                return 0

            deleted_count = 0

            for provision_status in provision_statuses:
                try:
                    kubernetes_config = (
                        await self._k8s_manager_factory.get_kubernetes_config(
                            cluster_id=provision_status.cluster_id
                        )
                    )

                    manager = await self._k8s_manager_factory.create_mcp_server_manager(
                        kubernetes_config.id
                    )
                    mcp_server_instance = await manager.get(
                        name=provision_status.name,
                        namespace=provision_status.namespace,
                    )

                    if mcp_server_instance:
                        kubernetes_delete_success = (
                            await self.k8s_delete_mcp_server_instance(
                                name=mcp_server_instance.metadata.name,
                                cluster_id=kubernetes_config.id,
                                namespace=mcp_server_instance.metadata.namespace
                                or mcp_server_settings.namespace,
                            )
                        )

                        if kubernetes_delete_success:
                            deleted_count += 1
                            logger.info(
                                f"Successfully deleted MCP server instance {provision_status.id} from cluster {kubernetes_config.name}"
                            )
                        else:
                            logger.warning(
                                f"Failed to delete MCP server instance {provision_status.id} from cluster {kubernetes_config.name}"
                            )
                    else:
                        logger.warning(
                            f"MCP server instance {provision_status.id} not found in cluster {kubernetes_config.name}"
                        )
                        deleted_count += 1

                except Exception as e:
                    logger.error(
                        f"Error deleting MCP server instance {provision_status.id}: {str(e)}"
                    )
                    continue

            logger.info(
                f"Successfully deleted {deleted_count} MCP server instances for profile_id: {profile_id}"
            )
            return deleted_count

        except Exception as e:
            logger.error(
                f"Failed to delete MCP server instances by profile_id: {str(e)}"
            )
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to delete MCP server instances by profile_id: {str(e)}",
            )

    async def sync_all_instances_status(self) -> int:
        """Synchronize all MCP server instance statuses from K8s clusters to MongoDB.

        This method retrieves the actual state from K8s clusters and updates MongoDB.
        Uses caching to skip DB writes when status is unchanged (conditional update).

        Additionally, this method:
        - Marks orphaned instances (exist in DB but not in K8s) as TERMINATED
        - Evicts stale entries from the status cache to prevent memory leaks

        This method is designed to be called periodically by Studio (e.g., every 5 minutes).
        The polling interval is controlled by Studio, not by this Core module.

        Returns:
            Number of instances actually updated (0 if all cached)
        """
        total_count = 0
        updated_count = 0

        # 1. Get all non-TERMINATED provision statuses from DB
        all_db_statuses = await self._mcp_server_provision_status_repository.find_non_terminated_statuses()
        db_status_map: dict[tuple[str, str, str], McpServerProvisionStatus] = {
            (s.cluster_id, s.name, s.namespace): s for s in all_db_statuses
        }

        # 2. Get all K8s cluster configurations
        all_clusters = await self._k8s_manager_factory.get_all_kubernetes_configs()

        # 3. Track K8s instance keys for orphan detection
        k8s_instance_keys: set[tuple[str, str, str]] = set()

        for cluster_config in all_clusters:
            try:
                manager = (
                    self._k8s_manager_factory.create_mcp_server_manager_from_config(
                        cluster_config
                    )
                )

                # 4. Get all MCP server instances from the cluster
                instances = await manager.get_all()

                for instance in instances:
                    try:
                        labels = instance.metadata.labels or {}
                        profile_id = labels.get("profile-id")

                        if not profile_id:
                            continue

                        # Track this instance key
                        key = (
                            cluster_config.id,
                            instance.metadata.name,
                            instance.metadata.namespace
                            or mcp_server_settings.namespace,
                        )
                        k8s_instance_keys.add(key)

                        total_count += 1

                        # 5. Sync each instance status to MongoDB (conditional update)
                        if await self._sync_instance_to_db(instance, cluster_config):
                            updated_count += 1
                    except Exception as e:
                        logger.warning(
                            f"Failed to sync instance {instance.metadata.name}: {e}"
                        )
                        continue

            except Exception as e:
                logger.warning(f"Failed to sync cluster {cluster_config.name}: {e}")
                continue

        # 6. Mark orphaned instances as TERMINATED (exist in DB but not in K8s)
        terminated_count = await handle_orphaned_instances(
            db_status_map=db_status_map,
            k8s_instance_keys=k8s_instance_keys,
            repository=self._mcp_server_provision_status_repository,
            logger=logger,
            instance_type="MCP server instance",
        )

        # 7. Cache eviction: remove stale entries (not in K8s)
        evict_stale_cache(
            status_cache=self._status_cache,
            k8s_instance_keys=k8s_instance_keys,
            logger=logger,
            instance_type="MCP server",
        )

        logger.debug(
            f"Sync completed: {updated_count}/{total_count} updated, "
            f"{terminated_count} terminated"
        )
        return updated_count

    async def _sync_instance_to_db(
        self,
        instance: McpServerInstance,
        cluster_config: KubernetesConfig,
    ) -> bool:
        """Sync a single instance status to DB (conditional update).

        Uses caching to skip DB writes when status is unchanged.

        Args:
            instance: The K8s McpServerInstance with current state
            cluster_config: The cluster configuration

        Returns:
            True if DB was updated, False if skipped (status unchanged)
        """
        labels = instance.metadata.labels or {}
        profile_id = labels.get("profile-id")

        if not profile_id:
            logger.debug(
                f"Skipping instance {instance.metadata.name}: no profile-id label"
            )
            return False

        # Parse profile_version (v1 -> 1)
        version_str = (instance.metadata.annotations or {}).get("profile_version", "v0")
        try:
            profile_version = safe_parse_version(version_str)
        except CoreServiceException:
            logger.warning(
                f"Skipping instance {instance.metadata.name}: "
                f"invalid version format {version_str}"
            )
            return False

        # Generate MCP config JSON if endpoints are available
        mcp_config_json = None
        if instance.status and instance.status.endpoints:
            try:
                config_combined = await self.get_mcp_server_config_json_by_instance(
                    instance
                )
                mcp_config_json = McpServerConfigs(
                    internal=config_combined.internal_mcp_server_json,
                    external=config_combined.mcp_server_json,
                )
            except Exception as e:
                # Config generation failure shouldn't stop status sync
                logger.debug(
                    f"Could not generate MCP config for {instance.metadata.name}: {e}"
                )

        return await self._sync_provision_status_metadata(
            instance=instance,
            profile_id=profile_id,
            profile_version=profile_version,
            cluster_id=cluster_config.id,
            cluster_name=cluster_config.name,
            mcp_config_json=mcp_config_json,
            use_cache=True,
        )

    async def _build_playground_agent(
        self,
        *,
        user_id: str,
        connections: dict[str, Any],
        llm_provider: str,
        llm_model: str,
        llm_api_key_id: str,
        checkpointer: InMemorySaver | None = None,
    ) -> tuple[
        CompiledStateGraph | None,
        list[BaseTool] | None,
        bool,
        list[NeedAuthMCPServer],
        MCPServerConfig | None,
    ]:
        """Build a playground agent from connections and LLM config.

        Returns:
            Tuple of (compiled agent graph, tool list, need_auth, pending_auth_servers).
        """
        # 1. Fetch LLM credentials
        try:
            user_credential = await self._user_credential_repository.find_by_id(
                item_id=llm_api_key_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User credential not found: {llm_api_key_id}",
            )

        # 2. Fetch LLM provider
        try:
            llm_provider_id = await self._llm_provider_repository.get_id_by_key(
                key=llm_provider
            )
            llm_provider_entity = await self._llm_provider_repository.find_by_id(
                item_id=llm_provider_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"LLM provider not found: {llm_provider}",
            )

        # 3. Build LLMSpecData from credentials
        llm_spec_data = LLMSpecData(
            provider=llm_provider,
            base_url=llm_provider_entity.base_url,
            default_model_id=llm_model,
            api_key=user_credential.llm_api_key,
            aws_access_key_id=user_credential.aws_access_key_id,
            aws_secret_access_key=user_credential.aws_secret_access_key,
            aws_region_name=user_credential.region_name,
        )

        # 4. Convert connections to mcp_server_configs list
        mcp_server_json_configs: list[dict[str, Any]] = []
        for server_name, connection in connections.items():
            mcp_server_json_configs.append({server_name: dict(connection)})

        # 5. Build system prompt
        try:
            system_prompt_text = load_prompt(
                get_prompt_path(PromptFile.MCP_PLAYGROUND_AGENT)
            ).format(
                system_time=datetime.now(tz=UTC).isoformat(),
            )
        except Exception as e:
            logger.error("Error loading prompt: %s", e)
            system_prompt_text = (
                "You are a helpful assistant. Please answer the question."
            )

        # 6. Build SingleAgentSpecProfile via playground factory
        agent_spec_profile = build_playground_spec_profile(
            llm_spec_data=llm_spec_data,
            mcp_server_configs=mcp_server_json_configs,
            system_prompt=system_prompt_text,
        )

        # 7. Create SingleAgentWrapper and build agent
        wrapper = SingleAgentWrapper(
            agent_spec=agent_spec_profile,
            oauth_mcp_server_registry=self._oauth_mcp_server_registry,
            mcp_client_factory=self._mcp_client_factory,
            checkpointer=checkpointer,
        )

        # 8. Check MCP authentication
        (
            need_auth,
            pending_auth,
            mcp_server_configs,
        ) = await wrapper.need_mcp_authentication(user_id=user_id)

        if need_auth:
            return (
                None,
                None,
                True,
                pending_auth,
                mcp_server_configs[0] if mcp_server_configs else None,
            )

        # 9. Build agent
        agent = await wrapper.build_agent(user_id=user_id)

        # 10. Get tools from all MCP servers
        tools: list[BaseTool] = []
        for config in mcp_server_configs:
            tools.extend(await wrapper.get_mcp_server_tools(config.server_id))

        return (
            agent,
            tools,
            False,
            [],
            mcp_server_configs[0],
        )

    async def create_mcp_server_instance_playground(
        self,
        *,
        profile_id: str,
        cluster_id: str,
        iss: str,
        sub: str,
        llm_provider: str,
        llm_model: str,
        llm_api_key_id: str,
        backend_server_auth_configs: list,
        checkpointer: InMemorySaver | None = None,
    ) -> tuple[McpServerProvisionStatus, McpServer, CompiledStateGraph | None]:
        """Create MCP server instance playground agent.

        Build a playground agent from a deployed MCP server instance,
        using the instance's mcpServers JSON configuration.

        Args:
            profile_id: MCP server profile ID.
            cluster_id: Kubernetes cluster ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            llm_provider: LLM provider key (e.g. "openai").
            llm_model: LLM model name (e.g. "gpt-4.1-mini").
            llm_api_key_id: UserCredential ID for LLM API key.
            backend_server_auth_configs: Backend server auth configurations.
            checkpointer: LangGraph checkpointer (defaults to InMemorySaver).

        Returns:
            Tuple of (McpServerProvisionStatus, McpServer, compiled agent graph).
        """
        # 0. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 1. Cache key + evict existing
        cache_key = mcp_server_instance_playground_agent_cache_key(profile_id, user.id)
        if self._agent_cache is not None:
            await self._agent_cache.delete(cache_key)
            logger.info("Evicted cached MCP instance agent for profile %s", profile_id)

        # 2. Fetch provision status by profile_id + cluster_id
        try:
            provision_status = await self._mcp_server_provision_status_repository.find_by_profile_id_and_cluster_id(
                profile_id=profile_id, cluster_id=cluster_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server provision status not found: {profile_id}:{cluster_id}",
            )

        mcp_profile_history = await self._mcp_server_profile_history_repository.find_by_profile_id_and_version(
            profile_id=provision_status.profile_id,
            version=provision_status.profile_version,
        )

        provisioned_mcp_profile = mcp_profile_history.mcp_server_profile_data
        if not provisioned_mcp_profile:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server profile not found: {profile_id}",
            )

        # Check authentication type of MCP server
        mcp_server_node_data: McpServerNodeData | None = (
            provisioned_mcp_profile.get_mcp_server_node_data()
        )
        if mcp_server_node_data is None:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server node data not found: {profile_id}",
            )

        authentication_type = mcp_server_node_data.auth_config.type

        mcp_connection = {}
        if authentication_type == AuthenticationType.OAUTH:
            # NOTE: OAuth MCP Server should have the public endpoint in external.mcpServers using the ingress gateway
            if (
                provision_status.mcp_config_json is None
                or provision_status.mcp_config_json.external is None
                or provision_status.mcp_config_json.external.mcpServers is None
            ):
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Instance {profile_id}:{cluster_id} missing mcp_config_json.external.mcpServers",
                )
            mcp_connection = provision_status.mcp_config_json.external.mcpServers
        else:
            # NOTE: handle other authentication types
            if (
                provision_status.mcp_config_json is None
                or provision_status.mcp_config_json.internal is None
            ):
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Instance {profile_id}:{cluster_id} missing mcp_config_json.internal.mcpServers",
                )
            mcp_connection = provision_status.mcp_config_json.internal.mcpServers

        # 3. Extract mcpServers from provision status
        # NOTE: OAuth MCP Server should have the public endpoint in external.mcpServers using the ingress gateway
        # So we SHOULD use external.mcpServers instead of internal.mcpServers

        server_name = next(iter(mcp_connection))
        connection = dict(mcp_connection[server_name])

        if connection.get("transport") is None:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Instance {profile_id}:{cluster_id} missing 'transport' key",
            )

        # 4. Inject backend auth headers
        headers = connection.get("headers", {})
        for auth_cfg in backend_server_auth_configs:
            backend_server = await self._backend_server_repository.find_by_id(
                item_id=auth_cfg.server_id
            )
            separator = core_settings.mcp_server_separator
            if auth_cfg.auth_config.type == AuthenticationType.BASIC:
                headers[f"{backend_server.system_name}{separator}username"] = (
                    auth_cfg.auth_config.username
                )
                headers[f"{backend_server.system_name}{separator}password"] = (
                    auth_cfg.auth_config.password
                )
            elif auth_cfg.auth_config.type == AuthenticationType.BEARER:
                headers[f"{backend_server.system_name}{separator}bearer_token"] = (
                    auth_cfg.auth_config.bearer_token
                )
            elif auth_cfg.auth_config.type == AuthenticationType.API_KEY:
                headers[
                    f"{backend_server.system_name}{separator}{auth_cfg.auth_config.api_key_name}"
                ] = auth_cfg.auth_config.api_key_value

        connection["headers"] = headers
        connections = {server_name: connection}

        # 5. Build agent
        (
            agent,
            tools,
            need_auth,
            pending_auth,
            mcp_server_config,
        ) = await self._build_playground_agent(
            user_id=user.id,
            connections=connections,
            llm_provider=llm_provider,
            llm_model=llm_model,
            llm_api_key_id=llm_api_key_id,
            checkpointer=checkpointer,
        )

        if not mcp_server_config:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server config not found for profile {profile_id}",
            )

        # 6. Handle OAuth authentication required
        if need_auth:
            need_auth_mcp_server: NeedAuthMCPServer = pending_auth[0]
            logger.warning(
                "MCP server %s requires authentication: %s",
                need_auth_mcp_server.server_id,
                need_auth_mcp_server.auth_url,
            )
            mcp_server = McpServer(
                server_id=mcp_server_config.server_id,
                server_name=need_auth_mcp_server.server_id,
                is_oauth_server=mcp_server_config.is_oauth_server,
                connected=False,
                tools=[],
                resource_type=ResourceType.INTERNAL,
                transport_type=TransportType.HTTP,
                auth_url=need_auth_mcp_server.auth_url,
                error_message=mcp_server_config.error_message,
            )
            return provision_status, mcp_server, None

        # 7. Cache the compiled graph
        if self._agent_cache is not None:
            await self._agent_cache.put(cache_key, agent)
            logger.info(
                "Cached MCP instance playground agent for profile %s", profile_id
            )

        connected = not bool(mcp_server_config.error_message)

        # 8. Build McpServer response
        mcp_server = McpServer(
            server_id=mcp_server_config.server_id,
            server_name=server_name,
            is_oauth_server=mcp_server_config.is_oauth_server,
            connected=connected,
            tools=tools or [],
            resource_type=ResourceType.INTERNAL,
            transport_type=TransportType.HTTP,
            error_message=mcp_server_config.error_message,
        )

        return provision_status, mcp_server, agent

    async def validate_agent_initialized(
        self,
        profile_id: str,
        iss: str,
        sub: str,
    ) -> None:
        """Validate the playground agent is initialized."""
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST, details=f"User not found: {e}"
            )

        if self._agent_cache is not None:
            cached_agent = await self._get_cached_agent(
                profile_id=profile_id,
                user_id=user.id,
            )
            if cached_agent is None:
                raise CoreServiceException(
                    CoreError.AGENT_NOT_FOUND,
                    details=f"Cached agent not found in the cache for profile {profile_id} and user {user.id}. You should initialize the agent first.",
                )
            return
        else:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Cache not found in the server",
            )

    async def stream_playground_completion(
        self,
        *,
        profile_id: str,
        thread_id: str,
        iss: str,
        sub: str,
        prompt: str,
        llm_model: str | None = None,
        files: list[str] | None = None,
    ) -> AsyncGenerator[ServerSentEvent, None]:
        """Stream MCP server instance playground completion as SSE events.

        You should validate the playground agent initialized before calling this method.

        Args:
            profile_id: MCP server profile ID.
            thread_id: Conversation thread ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            prompt: User prompt text.
            llm_model: LLM model override.
            files: List of file IDs for multimodal messages.

        Returns:
            Async generator of ServerSentEvent.
        """
        # 0. Find user
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 1. Retrieve cached agent
        agent = await self._get_cached_agent(profile_id=profile_id, user_id=user.id)

        if agent is None:
            raise CoreServiceException(
                CoreError.AGENT_NOT_FOUND,
                details=f"MCP server instance playground agent not found for profile: {profile_id} and user: {user.id}",
            )

        # 2. Resolve LLM model
        effective_model = llm_model or core_settings.default_model

        # 3. Build RunnableConfig
        config = self._build_runnable_config(
            thread_id=thread_id,
            user_id=user.id,
        )

        # 4. Build inputs
        chat_files = []
        if files:
            chat_files = await self._get_chat_files_for_playground(files)
        messages = generate_multimodal_messages(chat_files, prompt, effective_model)
        inputs = {"messages": [HumanMessage(content=messages)]}

        # 5. Stream SSE events
        async for event in stream_agent_events(
            agent=agent,
            thread_id=thread_id,
            inputs=inputs,
            config=config,
        ):
            yield event

    async def _get_cached_agent(
        self, profile_id: str, user_id: str
    ) -> CompiledStateGraph:
        """Retrieve a cached MCP instance playground agent."""
        cache_key = mcp_server_instance_playground_agent_cache_key(
            profile_id=profile_id, username=user_id
        )
        agent = None
        if self._agent_cache is not None:
            agent = await self._agent_cache.get(cache_key)

        if agent is None:
            logger.warning(
                "MCP instance playground agent not found in cache for profile %s and user %s",
                profile_id,
                user_id,
            )
        return agent

    def _build_runnable_config(
        self,
        *,
        thread_id: str,
        user_id: str,
        llm_model: str | None = None,
    ) -> dict[str, Any]:
        """Build a RunnableConfig dict for agent execution."""
        return {
            "configurable": {
                "thread_id": thread_id,
                "user_id": user_id,
            },
            "recursion_limit": core_settings.recursion_limit,
        }

    async def _get_chat_files_for_playground(
        self, file_ids: list[str]
    ) -> list[AgentChatFile]:
        """Fetch chat files and convert to agent ChatFile format."""
        chat_files = []
        for file_id in file_ids:
            if not file_id:
                continue
            try:
                entity = await self._chat_file_repository.find_by_id(item_id=file_id)
                chat_files.append(
                    AgentChatFile(
                        upload_url=entity.upload_url,
                        file_name=entity.file_name,
                        mime_type=entity.mime_type,
                        project_id=entity.project_id,
                    )
                )
            except Exception as e:
                logger.warning("Failed to fetch chat file %s: %s", file_id, e)
        return chat_files
