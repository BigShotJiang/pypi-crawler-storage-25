"""Business logic services for agent, MCP server, and workspace operations."""
