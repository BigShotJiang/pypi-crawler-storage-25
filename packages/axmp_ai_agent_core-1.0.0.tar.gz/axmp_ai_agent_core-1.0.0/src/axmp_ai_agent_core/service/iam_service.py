"""This module contains the service for the user."""

from __future__ import annotations

import logging

from motor.motor_asyncio import AsyncIOMotorClient
from zmp_authentication_provider.scheme.auth_model import TokenData

from axmp_ai_agent_core.db.group_repository import GroupRepository
from axmp_ai_agent_core.db.role_repository import RoleRepository
from axmp_ai_agent_core.db.user_credential_repository import UserCredentialRepository
from axmp_ai_agent_core.db.user_repository import UserRepository
from axmp_ai_agent_core.entity.shared_target import SharedTarget, SharedType
from axmp_ai_agent_core.entity.user_credential import (
    UserCredential,
    UserCredentialType,
)
from axmp_ai_agent_core.entity.user_rbac import (
    Group,
    GroupTree,
    Role,
    SystemPredefinedRole,
    User,
)
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
    ValueErrorException,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.user_credential_query import (
    UserCredentialQueryParameters,
)
from axmp_ai_agent_core.filter.user_rbac_query import (
    GroupQueryParameters,
    RoleQueryParameters,
    UserQueryParameters,
)

logger = logging.getLogger(__name__)


class IAMService:
    """The service for the IAM (Identity and Access Management).

    This service provides the following functionalities:
    - User management
    - Group management
    - Role management
    - User credential management
    - User permission management
    - User role management
    - User group management
    """

    def __init__(
        self,
        client: AsyncIOMotorClient,
        user_repository: UserRepository,
        group_repository: GroupRepository,
        role_repository: RoleRepository,
        user_credential_repository: UserCredentialRepository,
    ):
        """Initialize the user service."""
        self._client = client
        self._user_repository: UserRepository = user_repository
        self._group_repository: GroupRepository = group_repository
        self._role_repository: RoleRepository = role_repository
        self._user_credential_repository: UserCredentialRepository = (
            user_credential_repository
        )

    async def create_user_credential(self, *, user_credential: UserCredential) -> str:
        """Create a new user credential with transaction support."""
        return await self._user_credential_repository.insert(item=user_credential)

    async def get_user_credential_by_id(self, *, id: str) -> UserCredential:
        """Get a user credential by ID."""
        try:
            return await self._user_credential_repository.find_by_id(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user credential ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User credential not found: {id}",
            )

    async def modify_user_credential(
        self, *, user_credential: UserCredential
    ) -> UserCredential:
        """Update a user credential."""
        try:
            return await self._user_credential_repository.update(item=user_credential)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user credential ID format: {user_credential.id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User credential not found: {user_credential.id}",
            )

    async def remove_user_credential_by_id(self, *, id: str) -> bool:
        """Delete a user credential."""
        try:
            return await self._user_credential_repository.delete(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user credential ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User credential not found: {id}",
            )

    async def modify_user_credential_shared_target(
        self,
        *,
        id: str,
        shared_target: SharedTarget,
        updated_by: str,
    ) -> UserCredential:
        """Update the shared_target for a user credential."""
        try:
            return await self._user_credential_repository.update_shared_target(
                item_id=id,
                shared_target=shared_target,
                updated_by=updated_by,
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user credential ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User credential not found: {id}",
            )

    async def get_user_credentials(
        self,
        query_parameters: UserCredentialQueryParameters | None = None,
    ) -> list[UserCredential]:
        """Get user credentials with query parameters.

        Args:
            query_parameters: Query parameters for filtering.
                - username only: Returns credentials owned by that user.
                - access_permission only: Returns credentials accessible to user
                  (owned + shared).
                - IMPORTANT: Do NOT use both username and access_permission together.
                  They are combined with $and which may produce unexpected results.

        Returns:
            List of user credentials matching the query.
        """
        if query_parameters is None:
            query_parameters = UserCredentialQueryParameters()
        return await self._user_credential_repository.find_all_without_pagination(
            query_parameters=query_parameters,
        )

    async def get_user_credentials_by_username(
        self, *, username: str
    ) -> list[UserCredential]:
        """Get user credentials by username."""
        query_parameters = UserCredentialQueryParameters(username=username)
        return await self._user_credential_repository.find_all_without_pagination(
            query_parameters=query_parameters,
        )

    async def get_user_credentials_by_username_and_type(
        self, *, username: str, credential_type: UserCredentialType
    ) -> list[UserCredential]:
        """Get user credentials by username and credential type."""
        try:
            query_parameters = UserCredentialQueryParameters(
                username=username, credential_type=credential_type
            )
            return await self._user_credential_repository.find_all_without_pagination(
                query_parameters=query_parameters,
            )
        except ValueError:
            logger.warning(f"Invalid credential type: {credential_type}")
            return []

    async def get_user_by_id(self, *, id: str) -> User:
        """Get a user by ID."""
        try:
            user = await self._user_repository.find_by_id(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {id}",
            )

        # NOTE: user.groups does not have the role details. so we need to get the groups from the database
        if user.groups is not None:
            detail_groups = await self._get_user_detail_groups(user=user)
            # re-assign the groups
            user.groups = detail_groups

        # user.group_ids = None
        # user.role_ids = None
        return user

    async def get_user_by_username(self, *, username: str) -> User:
        """Get a user by username."""
        try:
            user = await self._user_repository.find_by_username(username=username)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {username}",
            )

        # NOTE: user.groups does not have the role details. so we need to get the groups from the database
        if user.groups is not None:
            detail_groups = await self._get_user_detail_groups(user=user)
            # re-assign the groups
            user.groups = detail_groups

        # user.group_ids = None
        # user.role_ids = None
        return user

    async def get_user_by_iss_sub(self, *, iss: str, sub: str) -> User:
        """Get a user by iss and sub."""
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {iss}:{sub}",
            )

        # NOTE: user.groups does not have the role details. so we need to get the groups from the database
        if user.groups is not None:
            detail_groups = await self._get_user_detail_groups(user=user)
            # re-assign the groups
            user.groups = detail_groups

        # user.group_ids = None
        # user.role_ids = None
        return user

    async def _get_user_detail_groups(self, *, user: User) -> list[Group]:
        """Get the detail groups of the user."""
        if user.groups is None:
            return []

        detail_groups: list[Group] = []
        for group in user.groups:
            detail_group: Group = await self._group_repository.find_by_id(
                item_id=group.id
            )
            detail_groups.append(detail_group)
        return detail_groups

    async def check_read_permission(
        self,
        *,
        oauth_user: TokenData,
        shared_target: SharedTarget | None = SharedTarget(
            shared_type=SharedType.PRIVATE
        ),
        create_by: str,
        system_defined_role: list[SystemPredefinedRole] = [
            SystemPredefinedRole.SYSTEM_ADMINISTRATOR
        ],
    ) -> None:
        """Check if the user has read permission for the shared target."""
        if shared_target is None:
            shared_target = SharedTarget(shared_type=SharedType.PRIVATE)
        if shared_target.shared_type == SharedType.PUBLIC:
            return
        else:
            user = await self.get_user_by_iss_sub(
                iss=oauth_user.iss, sub=oauth_user.sub
            )
            if shared_target.shared_type == SharedType.RESTRICTED:
                if (
                    not any(user.has_role(role) for role in system_defined_role)
                    and user.username != create_by
                    and not user.has_read_permission(shared_target)
                ):
                    raise CoreServiceException(
                        CoreError.PERMISSION_DENIED,
                        details="You are not authorized to read this shared target.",
                    )
            elif shared_target.shared_type == SharedType.PRIVATE:
                if (
                    not any(user.has_role(role) for role in system_defined_role)
                    and user.username != create_by
                ):
                    raise CoreServiceException(
                        CoreError.PERMISSION_DENIED,
                        details="You are not authorized to read this shared target.",
                    )
            else:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details="Invalid shared target type.",
                )

    async def check_write_permission(
        self,
        *,
        oauth_user: TokenData,
        shared_target: SharedTarget | None = SharedTarget(
            shared_type=SharedType.PRIVATE
        ),
        create_by: str,
        system_defined_role: list[SystemPredefinedRole] = [
            SystemPredefinedRole.SYSTEM_ADMINISTRATOR
        ],
    ) -> None:
        """Check if the user has write permission for the shared target."""
        if shared_target is None:
            shared_target = SharedTarget(shared_type=SharedType.PRIVATE)
        user = await self.get_user_by_iss_sub(iss=oauth_user.iss, sub=oauth_user.sub)
        if shared_target.shared_type in [SharedType.PUBLIC, SharedType.PRIVATE]:
            # NOTE: The user who is owner or has system predefined role
            # can only write the shared target when the shared data is public or private
            if (
                not any(user.has_role(role) for role in system_defined_role)
                and user.username != create_by
            ):
                raise CoreServiceException(
                    CoreError.PERMISSION_DENIED,
                    details="You are not authorized to write this shared target.",
                )

        elif shared_target.shared_type in [SharedType.RESTRICTED]:
            # NOTE: The user who is owner or has system predefined role or has write permission
            # can only write the shared target when the shared target is restricted
            if (
                not any(user.has_role(role) for role in system_defined_role)
                and user.username != create_by
                and not user.has_write_permission(shared_target)
            ):
                raise CoreServiceException(
                    CoreError.PERMISSION_DENIED,
                    details="You are not authorized to write this shared target.",
                )
        else:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="Invalid shared target type.",
            )

    async def get_users_by_group_id(self, *, group_id: str) -> list[User]:
        """Get users by group ID."""
        try:
            users = await self._user_repository.find_all_by_group_id(group_id=group_id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Group not found: {group_id}",
            )
        return users

    async def add_group_to_user(
        self, *, user_id: str, group_id: str, updated_by: str
    ) -> User:
        """Add a group to a user without duplication (atomic partial update)."""
        try:
            await self._group_repository.find_by_id(item_id=group_id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid group ID format: {group_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Group ID {group_id} not found",
            )

        try:
            return await self._user_repository.add_group_to_user(
                user_id=user_id, group_id=group_id, updated_by=updated_by
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user ID format: {user_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {user_id}",
            )

    async def remove_group_from_user(
        self, *, user_id: str, group_id: str, updated_by: str
    ) -> User:
        """Remove a group from a user (atomic partial update)."""
        try:
            await self._group_repository.find_by_id(item_id=group_id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid group ID format: {group_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Group ID {group_id} not found",
            )
        try:
            return await self._user_repository.remove_group_from_user(
                user_id=user_id, group_id=group_id, updated_by=updated_by
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user ID format: {user_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {user_id}",
            )

    async def modify_user(self, *, user: User) -> User:
        """Update a user."""
        # check if group codes are valid
        if user.group_ids:
            try:
                for group_id in user.group_ids:
                    await self._group_repository.find_by_id(item_id=group_id)
            except InvalidObjectIDException:
                raise CoreServiceException(
                    CoreError.INVALID_OBJECTID,
                    details=f"Invalid group ID format: {group_id}",
                )
            except ObjectNotFoundException:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Group ID {group_id} not found",
                )

        # check if role codes are valid
        if user.role_ids:
            try:
                for role_id in user.role_ids:
                    await self._role_repository.find_by_id(item_id=role_id)
            except InvalidObjectIDException:
                raise CoreServiceException(
                    CoreError.INVALID_OBJECTID,
                    details=f"Invalid role ID format: {role_id}",
                )
            except ObjectNotFoundException:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Role ID {role_id} not found",
                )

        try:
            updated_user = await self._user_repository.update(item=user)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user ID format: {user.id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {user.id}",
            )

        try:
            user = await self._user_repository.find_by_id(item_id=updated_user.id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user ID format: {updated_user.id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {user.id}",
            )

        # return user.model_dump(exclude=["group_ids", "role_ids"])
        # user.group_ids = None
        # user.role_ids = None
        return user

    async def remove_user_by_id(self, *, id: str) -> bool:
        """Delete a user."""
        try:
            return await self._user_repository.delete(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid user ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {id}",
            )

    async def get_all_users(
        self,
        *,
        query_parameters: UserQueryParameters,
        page_number: int = 1,
        page_size: int = 20,
    ) -> list[User]:
        """Get all users with pagination."""
        return await self._user_repository.find_all(
            query_parameters=query_parameters,
            page_number=page_number,
            page_size=page_size,
            exclude_fields=["group_ids", "role_ids"],
        )

    async def get_all_users_without_pagination(
        self, *, query_parameters: UserQueryParameters
    ) -> list[User]:
        """Get all users without pagination."""
        return await self._user_repository.find_all_without_pagination(
            query_parameters=query_parameters,
            exclude_fields=[
                "default_agent_id",
                "group_ids",
                "groups",
                "role_ids",
                "roles",
                "created_at",
                "updated_at",
                "created_by",
                "updated_by",
            ],
        )

    async def count_users(self, *, query_parameters: UserQueryParameters) -> int:
        """Count users."""
        return await self._user_repository.count(query_parameters=query_parameters)

    async def create_group(self, *, group: Group) -> str:
        """Create a new group."""
        # check if parent group exists
        if group.parent_code:
            try:
                await self._group_repository.find_by_code(code=group.parent_code)
            except ObjectNotFoundException:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Parent group {group.parent_code} not found",
                )

        # check if role ids are valid
        if group.role_ids:
            try:
                for role_id in group.role_ids:
                    await self._role_repository.find_by_id(item_id=role_id)
            except ObjectNotFoundException:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Role ID {role_id} not found",
                )

        try:
            return await self._group_repository.insert(item=group)
        except ValueErrorException:
            raise CoreServiceException(
                CoreError.DUPLICATE_FOUND,
                details=f"Group code {group.code} already exists",
            )

    async def get_group_by_id(self, *, id: str) -> Group:
        """Get a group by ID."""
        try:
            group = await self._group_repository.find_by_id(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid group ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Group not found: {id}",
            )
        group.role_ids = None
        return group

    async def get_group_by_code(self, *, code: str) -> Group:
        """Get a group by code."""
        try:
            group = await self._group_repository.find_by_code(code=code)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Group not found: {code}",
            )
        group.role_ids = None
        return group

    async def modify_group(self, *, group: Group) -> Group:
        """Update a group."""
        # check if parent group exists
        if group.parent_code:
            try:
                await self._group_repository.find_by_code(code=group.parent_code)
            except InvalidObjectIDException:
                raise CoreServiceException(
                    CoreError.INVALID_OBJECTID,
                    details=f"Invalid group ID format: {group.parent_code}",
                )
            except ObjectNotFoundException:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Parent group {group.parent_code} not found",
                )

        # check if role ids are valid
        if group.role_ids:
            try:
                for role_id in group.role_ids:
                    await self._role_repository.find_by_id(item_id=role_id)
            except InvalidObjectIDException:
                raise CoreServiceException(
                    CoreError.INVALID_OBJECTID,
                    details=f"Invalid role ID format: {role_id}",
                )
            except ObjectNotFoundException:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Role ID {role_id} not found",
                )

        try:
            group = await self._group_repository.update(item=group)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid group ID format: {group.id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Group not found: {group.id}",
            )

        try:
            updated_group = await self._group_repository.find_by_id(item_id=group.id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid group ID format: {group.id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Group not found: {group.id}",
            )

        updated_group.role_ids = None
        return updated_group

    async def remove_group_by_id(self, *, id: str) -> bool:
        """Delete a group."""
        # check if group has children
        total_children = await self._group_repository.count(
            query_parameters=GroupQueryParameters(parent_code=id)
        )
        if total_children > 0:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Group {id} has children({total_children}). Please delete or move the children first.",
            )

        try:
            return await self._group_repository.delete(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid group ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Group not found: {id}",
            )

    async def get_groups_by_parent_code(self, *, parent_code: str) -> list[Group]:
        """Get groups by parent code."""
        return await self._group_repository.find_by_parent_code(parent_code=parent_code)

    async def get_all_groups(
        self,
        *,
        query_parameters: GroupQueryParameters,
        page_number: int = 1,
        page_size: int = 20,
    ) -> list[Group]:
        """Get all groups with pagination."""
        return await self._group_repository.find_all(
            query_parameters=query_parameters,
            page_number=page_number,
            page_size=page_size,
            exclude_fields=["role_ids"],
        )

    async def get_all_groups_without_pagination(
        self, *, query_parameters: GroupQueryParameters
    ) -> list[Group]:
        """Get all groups without pagination."""
        return await self._group_repository.find_all_without_pagination(
            query_parameters=query_parameters,
            include_fields=["id", "code", "name"],
        )

    async def count_groups(self, *, query_parameters: GroupQueryParameters) -> int:
        """Count groups."""
        return await self._group_repository.count(query_parameters=query_parameters)

    async def get_groups_for_tree(
        self, *, parent_code: str | None = None
    ) -> list[GroupTree]:
        """Get groups for tree."""
        group_trees: list[GroupTree] = []
        await self._build_tree(parent_code=parent_code, group_trees=group_trees)
        return group_trees

    async def _build_tree(
        self,
        *,
        parent_code: str | None = None,
        depth: int = 0,
        group_trees: list[GroupTree] | None = None,
    ) -> list[GroupTree]:
        """Build a group tree."""
        if group_trees is None:
            group_trees = []

        groups: list[Group] = await self._group_repository.find_tree_without_pagination(
            query_parameters=GroupQueryParameters(parent_code=parent_code),
            exclude_fields=[
                "role_ids",
            ],
        )

        if groups is None or len(groups) == 0:
            return []

        for group in groups:
            group_tree = GroupTree(**group.model_dump())
            group_tree.depth = depth
            group_trees.append(group_tree)

            children = await self._build_tree(
                parent_code=group_tree.code, depth=depth + 1, group_trees=group_trees
            )
            group_tree.has_children = len(children) > 0

            logger.debug(
                f"Node: {group_tree.code}, Depth: {group_tree.depth}, Has Children: {group_tree.has_children} ({len(children)})"
            )

        return group_trees

    async def create_role(self, *, role: Role) -> str:
        """Create a new role."""
        try:
            return await self._role_repository.insert(item=role)
        except ValueErrorException:
            raise CoreServiceException(
                CoreError.DUPLICATE_FOUND,
                details=f"Role name {role.name} already exists",
            )

    async def get_role_by_id(self, *, id: str) -> Role:
        """Get a role by ID."""
        try:
            return await self._role_repository.find_by_id(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid role ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Role not found: {id}",
            )

    async def modify_role(self, *, role: Role) -> Role:
        """Update a role."""
        try:
            return await self._role_repository.update(item=role)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid role ID format: {role.id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Role not found: {role.id}",
            )

    async def remove_role_by_id(self, *, id: str) -> bool:
        """Delete a role."""
        try:
            return await self._role_repository.delete(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid role ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Role not found: {id}",
            )

    async def get_all_roles(
        self,
        *,
        query_parameters: RoleQueryParameters,
        page_number: int = 1,
        page_size: int = 20,
    ) -> list[Role]:
        """Get all roles with pagination."""
        return await self._role_repository.find_all(
            query_parameters=query_parameters,
            page_number=page_number,
            page_size=page_size,
        )

    async def get_all_roles_without_pagination(
        self, *, query_parameters: RoleQueryParameters
    ) -> list[Role]:
        """Get all roles without pagination."""
        return await self._role_repository.find_all_without_pagination(
            query_parameters=query_parameters,
            include_fields=["id", "name", "description"],
        )

    async def count_roles(self, *, query_parameters: RoleQueryParameters) -> int:
        """Count roles."""
        return await self._role_repository.count(query_parameters=query_parameters)
