"""Kubernetes configuration service."""

from __future__ import annotations

import logging

import yaml
from kubernetes import client, config
from kubernetes.client.rest import ApiException
from motor.motor_asyncio import AsyncIOMotorClient

from axmp_ai_agent_core.db.kubernetes_config_repository import (
    KubernetesConfigRepository,
)
from axmp_ai_agent_core.entity.kubernetes_config import (
    ConnectionStatus,
    KubernetesConfig,
)
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.exception.kubernetes_exceptions import (
    raise_k8s_backend_exception,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.configuration_query import (
    KubernetesConfigQueryParameters,
)
from axmp_ai_agent_core.setting import core_settings
from axmp_ai_agent_core.util.list_utils import MAX_LIMIT, SortDirection

logger = logging.getLogger(__name__)


class KubernetesConfigService:
    """Kubernetes configuration service."""

    def __init__(
        self,
        client: AsyncIOMotorClient,
        kubernetes_config_repository: KubernetesConfigRepository,
    ):
        """Initialize the kubernetes configuration service."""
        self._client = client
        self._kubernetes_config_repository: KubernetesConfigRepository = (
            kubernetes_config_repository
        )

    async def _test_kubernetes_connection(self, kubeconfig_content: str) -> bool:
        """Test kubernetes connection using dict-based kubeconfig only (no temp file)."""
        try:
            loaded = yaml.safe_load(kubeconfig_content) if kubeconfig_content else None
            if not isinstance(loaded, dict):
                raise CoreServiceException(
                    CoreError.INVALID_KUBECONFIG,
                    details="Parsed kubeconfig is not a dict",
                )

            if not hasattr(config, "load_kube_config_from_dict"):
                raise CoreServiceException(
                    CoreError.INVALID_KUBECONFIG,
                    details="kubernetes client missing load_kube_config_from_dict",
                )

            client_configuration = client.Configuration()
            config.load_kube_config_from_dict(
                config_dict=loaded,
                client_configuration=client_configuration,
            )
            api_client = client.ApiClient(configuration=client_configuration)
            v1 = client.VersionApi(api_client)
            v1.get_code()
            return True

        except yaml.YAMLError as e:
            raise CoreServiceException(
                CoreError.INVALID_KUBECONFIG,
                details=f"Invalid YAML format: {e}",
            )
        except config.ConfigException as e:
            raise CoreServiceException(
                CoreError.INVALID_KUBECONFIG,
                details=f"Invalid kubeconfig configuration: {e}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            raise CoreServiceException(
                CoreError.KUBERNETES_CONNECTION_FAILED,
                details=f"Failed to connect to Kubernetes cluster: {e}",
            )

    async def _evaluate_connection(
        self, kubeconfig_content: str
    ) -> tuple[ConnectionStatus, str | None]:
        """Evaluate connection and return simplified status and warning.

        Returns (Connected, None) on success, otherwise (Error, message).
        """
        try:
            await self._test_kubernetes_connection(kubeconfig_content)
            return ConnectionStatus.CONNECTED, None
        except CoreServiceException as e:
            message = f"Connection test failed: {str(e.details) if hasattr(e, 'details') and e.details else str(e)}"
            return ConnectionStatus.ERROR, message

    def _extract_server_from_kubeconfig(self, kubeconfig_content: str) -> str | None:
        """Extract the Kubernetes API server URL from kubeconfig YAML.

        Strategy:
        - Parse YAML safely
        - Use `current-context` to locate the matching context
        - Map context.cluster -> clusters[].name and return clusters[].cluster.server
        - Fallbacks: if current-context invalid, use the first cluster server if only one exists
        """
        try:
            loaded = yaml.safe_load(kubeconfig_content) if kubeconfig_content else None
            if not isinstance(loaded, dict):
                return None

            clusters = loaded.get("clusters") or []
            contexts = loaded.get("contexts") or []
            current_context_name = loaded.get("current-context")

            def find_cluster_server_by_name(cluster_name: str) -> str | None:
                for c in clusters:
                    try:
                        if c.get("name") == cluster_name:
                            cluster_obj = c.get("cluster") or {}
                            server_val = cluster_obj.get("server")
                            if isinstance(server_val, str) and server_val:
                                return server_val
                    except Exception:
                        continue
                return None

            # Prefer current-context mapping
            if isinstance(current_context_name, str) and current_context_name:
                for ctx in contexts:
                    try:
                        if ctx.get("name") == current_context_name:
                            ctx_cluster = (ctx.get("context") or {}).get("cluster")
                            if isinstance(ctx_cluster, str) and ctx_cluster:
                                server_val = find_cluster_server_by_name(ctx_cluster)
                                if server_val:
                                    return server_val
                    except Exception:
                        continue

            # Fallback: single cluster definition
            if isinstance(clusters, list) and len(clusters) == 1:
                try:
                    cluster_obj = (clusters[0] or {}).get("cluster") or {}
                    server_val = cluster_obj.get("server")
                    if isinstance(server_val, str) and server_val:
                        return server_val
                except Exception:
                    return None

            return None
        except Exception:
            return None

    async def _assert_unique_name(
        self, *, name: str, exclude_id: str | None = None
    ) -> None:
        """Ensure the name is unique. If `exclude_id` is given, ignore that document."""
        query_parameters = KubernetesConfigQueryParameters(name=name)
        existing_configs = (
            await self._kubernetes_config_repository.find_all_without_pagination(
                query_parameters=query_parameters
            )
        )

        # Since repository uses regex matching for name, enforce exact match (case-insensitive)
        def is_exact_name_match(config_name: str, target_name: str) -> bool:
            return (config_name or "").strip().lower() == (
                target_name or ""
            ).strip().lower()

        for existing in existing_configs:
            if is_exact_name_match(existing.name, name):
                if exclude_id is None or existing.id != exclude_id:
                    raise CoreServiceException(
                        CoreError.DUPLICATE_FOUND,
                        details=f"Kubernetes config with name '{name}' already exists",
                    )

    async def create_kubernetes_config(
        self, *, kubernetes_config: KubernetesConfig
    ) -> str:
        """Create a new kubernetes configuration."""
        try:
            # Check for existing config with same name
            await self._assert_unique_name(name=kubernetes_config.name)

            # Evaluate connection and set status/warning
            status, warning = await self._evaluate_connection(
                kubernetes_config.kubeconfig
            )
            kubernetes_config.status = status
            kubernetes_config.warning_message = warning

            # Extract and store server URL regardless of connection test result
            kubernetes_config.server = self._extract_server_from_kubeconfig(
                kubernetes_config.kubeconfig
            )

            return await self._kubernetes_config_repository.insert(
                item=kubernetes_config
            )

        except CoreServiceException:
            raise
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to create kubernetes config: {e}",
            )

    async def get_kubernetes_config_by_id(self, *, id: str) -> KubernetesConfig:
        """Get a kubernetes configuration by ID."""
        try:
            return await self._kubernetes_config_repository.find_by_id(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Kubernetes config not found: {id}",
            )

    async def modify_kubernetes_config(
        self, *, kubernetes_config: KubernetesConfig
    ) -> KubernetesConfig:
        """Update a kubernetes configuration."""
        try:
            # Get existing data
            original = await self._kubernetes_config_repository.find_by_id(
                item_id=kubernetes_config.id
            )

            # Check for duplicate name if name is changed (excluding self)
            if kubernetes_config.name != original.name:
                await self._assert_unique_name(
                    name=kubernetes_config.name, exclude_id=kubernetes_config.id
                )

            # Test kubernetes connection if kubeconfig is changed
            if kubernetes_config.kubeconfig != original.kubeconfig:
                status, warning = await self._evaluate_connection(
                    kubernetes_config.kubeconfig
                )
                kubernetes_config.status = status
                kubernetes_config.warning_message = warning
                # Extract and store server URL for updated kubeconfig
                kubernetes_config.server = self._extract_server_from_kubeconfig(
                    kubernetes_config.kubeconfig
                )
            else:
                # Keep original status and warning message if kubeconfig is not changed
                kubernetes_config.status = original.status
                kubernetes_config.warning_message = original.warning_message
                kubernetes_config.server = original.server

            return await self._kubernetes_config_repository.update(
                item=kubernetes_config
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {kubernetes_config.id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Kubernetes config not found: {kubernetes_config.id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to update kubernetes config: {e}",
            )

    async def remove_kubernetes_config_by_id(self, *, id: str) -> bool:
        """Delete a kubernetes configuration."""
        try:
            return await self._kubernetes_config_repository.delete(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Kubernetes config not found: {id}",
            )

    async def get_kubernetes_configs(
        self,
        *,
        query_parameters: KubernetesConfigQueryParameters,
        page_number: int = 1,
        page_size: int = 10,
    ) -> list[KubernetesConfig]:
        """Get all kubernetes configurations."""
        try:
            return await self._kubernetes_config_repository.find_all(
                query_parameters=query_parameters,
                page_number=page_number,
                page_size=page_size,
            )
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get kubernetes configs: {e}",
            )

    async def get_kubernetes_configs_count(
        self, *, query_parameters: KubernetesConfigQueryParameters
    ) -> int:
        """Get the count of kubernetes configurations."""
        try:
            return await self._kubernetes_config_repository.count(
                query_parameters=query_parameters
            )
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get kubernetes configs count: {e}",
            )

    async def get_all_kubernetes_configs(
        self, *, page_number: int = 1, page_size: int = 10
    ) -> list[KubernetesConfig]:
        """Get all kubernetes configurations without any filters."""
        try:
            # Create empty query parameters with updated_at DESC sorting to match find_all_simple behavior
            query_parameters = KubernetesConfigQueryParameters(
                sort_field="updated_at", sort_direction=SortDirection.DESC
            )

            return await self._kubernetes_config_repository.find_all(
                query_parameters=query_parameters,
                page_number=page_number,
                page_size=page_size,
            )
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get all kubernetes configs: {e}",
            )

    async def get_kubernetes_configs_total_count(self) -> int:
        """Get the total count of all kubernetes configurations."""
        try:
            # Create empty query parameters to count all configurations
            query_parameters = KubernetesConfigQueryParameters()
            return await self._kubernetes_config_repository.count(
                query_parameters=query_parameters
            )
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get kubernetes configs total count: {e}",
            )

    async def test_kubernetes_connection(self, *, kubeconfig_content: str) -> bool:
        """Test kubernetes connection with the provided kubeconfig."""
        try:
            return await self._test_kubernetes_connection(kubeconfig_content)
        except CoreServiceException:
            raise
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to test kubernetes connection: {e}",
            )

    async def test_kubernetes_connection_by_id(self, *, id: str) -> bool:
        """Test kubernetes connection by configuration ID."""
        try:
            kubernetes_config = await self._kubernetes_config_repository.find_by_id(
                item_id=id
            )
            return await self._test_kubernetes_connection(kubernetes_config.kubeconfig)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Kubernetes config not found: {id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to test kubernetes connection by id: {e}",
            )

    async def test_kubernetes_connection_by_id_and_update(
        self, *, id: str, updated_by: str | None = None
    ) -> KubernetesConfig:
        """Test connection by ID and update status (and server) accordingly.

        - On success: set status CONNECTED, clear warning_message
        - On failure: set status ERROR, set warning_message
        - Always refresh `server` from kubeconfig
        - Optionally set `updated_by`
        """
        try:
            kubernetes_config = await self._kubernetes_config_repository.find_by_id(
                item_id=id
            )

            status, warning = await self._evaluate_connection(
                kubernetes_config.kubeconfig
            )
            kubernetes_config.status = status
            kubernetes_config.warning_message = warning

            kubernetes_config.server = self._extract_server_from_kubeconfig(
                kubernetes_config.kubeconfig
            )
            if updated_by:
                kubernetes_config.updated_by = updated_by

            updated = await self._kubernetes_config_repository.update(
                item=kubernetes_config
            )
            return updated
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Kubernetes config not found: {id}",
            )
        except CoreServiceException:
            # If connection test raised but we handled mapping above, we shouldn't arrive here.
            # Keep for completeness.
            raise
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to test and update kubernetes connection by id: {e}",
            )

    async def get_kubernetes_configs_simple(
        self,
    ) -> list[KubernetesConfig]:
        """Get simplified list of kubernetes configurations without pagination.

        This method limits the number of returned items internally using MAX_LIMIT
        to avoid returning an unbounded list, and maps the entity into a reduced
        response model suitable for lightweight clients.
        """
        try:
            query_parameters = KubernetesConfigQueryParameters(
                sort_field="updated_at", sort_direction=SortDirection.DESC
            )

            kubernetes_configs = (
                await self._kubernetes_config_repository.find_all_without_pagination(
                    query_parameters=query_parameters,
                    max_limit=MAX_LIMIT,
                    include_fields=["id", "name", "status", "server"],
                )
            )

            return kubernetes_configs

        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get simplified kubernetes configs: {e}",
            )

    async def get_namespaces_by_kubernetes_config(
        self, *, kubernetes_config: KubernetesConfig
    ) -> list[str]:
        """Get used axmp-system labels namespaces by kubernetes configuration."""
        try:
            client_configuration = client.Configuration()
            config.load_kube_config_from_dict(
                config_dict=yaml.safe_load(kubernetes_config.kubeconfig),
                client_configuration=client_configuration,
            )

            api_client = client.ApiClient(configuration=client_configuration)
            core_api = client.CoreV1Api(api_client)

            namespace_objects = core_api.list_namespace(
                label_selector=core_settings.axmp_provision_target_label
            ).items

            axmp_namespaces = []
            for namespace_obj in namespace_objects:
                axmp_namespaces.append({"name": namespace_obj.metadata.name})

            return axmp_namespaces
        except ApiException as error:
            status_code = getattr(error, "status", None)
            log_level = "warning" if status_code in (401, 403) else "error"
            raise_k8s_backend_exception(logger=logger, error=error, log_level=log_level)

    async def get_node_port_usage_by_kubernetes_config(
        self, *, kubernetes_config: KubernetesConfig
    ) -> list[str]:
        """Get NodePort usage for a specific Kubernetes configuration."""
        try:
            client_configuration = client.Configuration()
            config.load_kube_config_from_dict(
                config_dict=yaml.safe_load(kubernetes_config.kubeconfig),
                client_configuration=client_configuration,
            )

            api_client = client.ApiClient(configuration=client_configuration)
            core_api = client.CoreV1Api(api_client)

            all_services = []
            namespaces = core_api.list_namespace()
            for namespace in namespaces.items:
                try:
                    services = core_api.list_namespaced_service(namespace.metadata.name)
                    all_services.extend(services.items)
                except ApiException as e:
                    raise_k8s_backend_exception(
                        logger=logger, error=e, log_level="warning"
                    )
        except ApiException as e:
            raise_k8s_backend_exception(logger=logger, error=e, log_level="error")

        used_node_ports = []
        for service in all_services:
            if service.spec.type == "NodePort":
                for port in service.spec.ports:
                    if port.node_port:
                        used_node_ports.append(port.node_port)

        used_node_ports = sorted(list(set(used_node_ports)))

        return used_node_ports
