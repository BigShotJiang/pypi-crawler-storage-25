"""OAuth Provider service."""

from __future__ import annotations

import logging

from axmp_ai_agent_core.db.mcp_server_profile_repository import (
    McpServerProfileRepository,
)
from axmp_ai_agent_core.db.oauth_provider_repository import OAuthProviderRepository
from axmp_ai_agent_core.entity.oauth_provider import (
    SINGLE_INSTANCE_PROVIDER_TYPES,
    OAuthProvider,
    OAuthProviderStatus,
    OAuthProviderType,
)
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.oauth_provider_query import (
    OAuthProviderQueryParameters,
)

logger = logging.getLogger(__name__)


class OAuthProviderService:
    """OAuth Provider service."""

    def __init__(
        self,
        oauth_provider_repository: OAuthProviderRepository,
        mcp_server_profile_repository: McpServerProfileRepository,
    ):
        """Initialize the OAuth Provider service."""
        self._oauth_provider_repository = oauth_provider_repository
        self._mcp_server_profile_repository = mcp_server_profile_repository

    async def create_oauth_provider(
        self, *, oauth_provider: OAuthProvider
    ) -> OAuthProvider:
        """Create a new OAuth provider."""
        try:
            await self._check_duplicate_system_name(
                system_name=oauth_provider.system_name
            )
            await self._check_single_instance_constraint(
                provider_type=oauth_provider.provider_type
            )
            self._check_required_oauth_endpoints(oauth_provider=oauth_provider)

            provider_id = await self._oauth_provider_repository.insert(
                item=oauth_provider
            )

            logger.info(
                f"Created OAuth provider '{oauth_provider.system_name}' with id={provider_id}"
            )

            return await self._oauth_provider_repository.find_by_id(item_id=provider_id)
        except (CoreServiceException, InvalidObjectIDException):
            raise
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Failed to retrieve created OAuth provider",
            )
        except Exception as e:
            logger.error(f"Error creating OAuth provider: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to create OAuth provider: {e}",
            )

    async def get_oauth_provider_by_id(self, *, id: str) -> OAuthProvider:
        """Get an OAuth provider by ID."""
        try:
            return await self._oauth_provider_repository.find_by_id(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"OAuth provider not found: {id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid OAuth provider ID: {id}",
            )

    async def get_oauth_providers(
        self,
        *,
        query_parameters: OAuthProviderQueryParameters,
        page_number: int,
        page_size: int,
    ) -> list[OAuthProvider]:
        """Get OAuth providers with pagination."""
        try:
            return await self._oauth_provider_repository.find_all(
                query_parameters=query_parameters,
                page_number=page_number,
                page_size=page_size,
            )
        except Exception as e:
            logger.error(f"Error getting OAuth providers: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get OAuth providers: {e}",
            )

    async def get_oauth_providers_count(
        self,
        *,
        query_parameters: OAuthProviderQueryParameters,
    ) -> int:
        """Count OAuth providers matching query parameters."""
        try:
            return await self._oauth_provider_repository.count(
                query_parameters=query_parameters
            )
        except Exception as e:
            logger.error(f"Error counting OAuth providers: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to count OAuth providers: {e}",
            )

    async def get_oauth_providers_simple(self) -> list[OAuthProvider]:
        """Get active OAuth providers with minimal fields for config-data."""
        try:
            query_parameters = OAuthProviderQueryParameters(
                statuses=[OAuthProviderStatus.ACTIVE]
            )
            return await self._oauth_provider_repository.find_all_without_pagination(
                query_parameters=query_parameters,
                include_fields=["id", "name", "system_name", "icon_url", "provider_type"],
            )
        except Exception as e:
            logger.error(f"Error getting simplified OAuth providers: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get simplified OAuth providers: {e}",
            )

    async def modify_oauth_provider(
        self, *, oauth_provider: OAuthProvider
    ) -> OAuthProvider:
        """Modify an existing OAuth provider."""
        try:
            existing = await self._oauth_provider_repository.find_by_id(
                item_id=oauth_provider.id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"OAuth provider not found: {oauth_provider.id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid OAuth provider ID: {oauth_provider.id}",
            )

        if oauth_provider.system_name != existing.system_name:
            logger.warning(
                f"Rejected system_name change attempt: '{existing.system_name}' → '{oauth_provider.system_name}'"
            )
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="system_name cannot be changed after creation",
            )

        if oauth_provider.provider_type != existing.provider_type:
            logger.warning(
                f"Rejected provider_type change attempt: '{existing.provider_type}' → '{oauth_provider.provider_type}'"
            )
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="provider_type cannot be changed after creation",
            )

        self._check_required_oauth_endpoints(oauth_provider=oauth_provider)

        try:
            result = await self._oauth_provider_repository.update(item=oauth_provider)
            logger.info(f"Modified OAuth provider '{oauth_provider.id}'")
            return result
        except Exception as e:
            logger.error(f"Error modifying OAuth provider: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to modify OAuth provider: {e}",
            )

    async def remove_oauth_provider_by_id(self, *, id: str) -> bool:
        """Remove an OAuth provider by ID."""
        try:
            await self._oauth_provider_repository.find_by_id(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"OAuth provider not found: {id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid OAuth provider ID: {id}",
            )

        reference_count = (
            await self._mcp_server_profile_repository.count_by_oauth_provider_id(
                oauth_provider_id=id
            )
        )
        if reference_count > 0:
            logger.warning(
                f"Cannot delete OAuth provider '{id}': referenced by {reference_count} MCP server profile(s)"
            )
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"OAuth provider is referenced by {reference_count} MCP server profile(s)",
            )

        try:
            result = await self._oauth_provider_repository.delete(item_id=id)
            logger.info(f"Removed OAuth provider '{id}'")
            return result
        except Exception as e:
            logger.error(f"Error removing OAuth provider: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to remove OAuth provider: {e}",
            )

    async def activate_oauth_provider(
        self, *, id: str, updated_by: str
    ) -> OAuthProvider:
        """Activate an OAuth provider."""
        try:
            existing = await self._oauth_provider_repository.find_by_id(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"OAuth provider not found: {id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid OAuth provider ID: {id}",
            )

        existing = existing.model_copy(
            update={
                "status": OAuthProviderStatus.ACTIVE,
                "updated_by": updated_by,
                "updated_at": None,
            }
        )

        try:
            result = await self._oauth_provider_repository.update(item=existing)
            logger.info(f"Activated OAuth provider '{id}'")
            return result
        except Exception as e:
            logger.error(f"Error activating OAuth provider: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to activate OAuth provider: {e}",
            )

    async def deactivate_oauth_provider(
        self, *, id: str, updated_by: str
    ) -> OAuthProvider:
        """Deactivate an OAuth provider."""
        try:
            existing = await self._oauth_provider_repository.find_by_id(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"OAuth provider not found: {id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid OAuth provider ID: {id}",
            )

        existing = existing.model_copy(
            update={
                "status": OAuthProviderStatus.INACTIVE,
                "updated_by": updated_by,
                "updated_at": None,
            }
        )

        try:
            result = await self._oauth_provider_repository.update(item=existing)
            logger.info(f"Deactivated OAuth provider '{id}'")
            return result
        except Exception as e:
            logger.error(f"Error deactivating OAuth provider: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to deactivate OAuth provider: {e}",
            )

    async def _check_duplicate_system_name(self, *, system_name: str) -> None:
        """Check duplicate system_name."""
        logger.info(f"Checking duplicate system_name: '{system_name}'")

        if not system_name or system_name.strip() == "":
            logger.warning("System name is None or empty, skipping duplicate check")
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="OAuth provider system_name is required",
            )

        existing = await self._oauth_provider_repository.find_by_system_name(
            system_name=system_name
        )

        if existing:
            logger.warning(
                f"OAuth provider with system_name '{system_name}' already exists (id={existing.id})"
            )
            raise CoreServiceException(
                CoreError.DUPLICATE_FOUND,
                details=f"OAuth provider with system_name '{system_name}' already exists",
            )

        logger.info(f"No duplicate found for system_name '{system_name}'")

    async def _check_single_instance_constraint(
        self, *, provider_type: OAuthProviderType
    ) -> None:
        """Check single-instance constraint for certain provider types."""
        if provider_type not in SINGLE_INSTANCE_PROVIDER_TYPES:
            return

        count = await self._oauth_provider_repository.count_by_provider_type(
            provider_type=provider_type
        )
        if count > 0:
            logger.warning(
                f"Single-instance provider type '{provider_type}' already registered"
            )
            raise CoreServiceException(
                CoreError.DUPLICATE_FOUND,
                details=f"Provider type '{provider_type}' allows only one instance",
            )

    def _check_required_oauth_endpoints(self, *, oauth_provider: OAuthProvider) -> None:
        """Check required OAuth endpoints based on issuer_url presence.

        Rules:
        1. issuer_url present → OK (OIDC Discovery handles endpoint resolution)
        2. issuer_url absent → token_endpoint required
        3. issuer_url absent + authorization_code grant → authorization_endpoint required
        """
        if oauth_provider.issuer_url and oauth_provider.issuer_url.strip():
            return

        if (
            not oauth_provider.token_endpoint
            or not oauth_provider.token_endpoint.strip()
        ):
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="Either issuer_url or token_endpoint must be provided",
            )

        grant_types = oauth_provider.grant_types_supported or []
        if "authorization_code" in grant_types and (
            not oauth_provider.authorization_endpoint
            or not oauth_provider.authorization_endpoint.strip()
        ):
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="authorization_endpoint is required when grant_types_supported contains 'authorization_code' and issuer_url is not provided",
            )
