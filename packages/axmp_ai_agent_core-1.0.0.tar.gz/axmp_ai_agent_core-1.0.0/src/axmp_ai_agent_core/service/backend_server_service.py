"""Backend server service."""

from __future__ import annotations

import logging

import httpx
from motor.motor_asyncio import AsyncIOMotorClient
from zmp_authentication_provider.exceptions import InvalidObjectIDException

from axmp_ai_agent_core.db.backend_server_repository import BackendServerRepository
from axmp_ai_agent_core.db.collection_name import CollectionName
from axmp_ai_agent_core.db.mcp_server_profile_repository import (
    McpServerProfileRepository,
)
from axmp_ai_agent_core.entity.backend_server import (
    BackendServer,
)
from axmp_ai_agent_core.exception.db_exceptions import ObjectNotFoundException
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.backend_server_query import (
    BackendServerQueryParameters,
)

logger = logging.getLogger(__name__)


class BackendServerService:
    """Backend server service."""

    def __init__(
        self,
        client: AsyncIOMotorClient,
        backend_server_repository: BackendServerRepository,
        mcp_server_profile_repository: McpServerProfileRepository,
    ):
        """Initialize the backend server service."""
        self._client = client
        self._backend_server_repository: BackendServerRepository = (
            backend_server_repository
        )
        self._mcp_server_profile_repository: McpServerProfileRepository = (
            mcp_server_profile_repository
        )

    async def _fetch_swagger_json(self, swagger_url: str) -> dict:
        """Fetch swagger JSON from the given URL."""
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.get(swagger_url)
                response.raise_for_status()
                return response.json()
        except httpx.HTTPStatusError as e:
            logger.error(f"HTTP error fetching swagger JSON from {swagger_url}: {e}")
            if e.response.status_code == 404:
                raise CoreServiceException(
                    CoreError.SWAGGER_NOT_FOUND,
                    swagger_url=swagger_url,
                )
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to fetch swagger JSON: {e.response.status_code} , {e}",
            )
        except httpx.RequestError as e:
            logger.error(f"Request error fetching swagger JSON from {swagger_url}: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to fetch swagger JSON: {e}",
            )
        except Exception as e:
            logger.error(
                f"Unexpected error fetching swagger JSON from {swagger_url}: {e}"
            )
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to fetch swagger JSON: {e}",
            )

    def count_apis_in_swagger_json(self, swagger_json: dict) -> int:
        """Parse swagger JSON and return the total number of APIs."""
        try:
            api_count = 0

            # Check if it's OpenAPI 3.x
            if "openapi" in swagger_json and swagger_json["openapi"].startswith("3"):
                # OpenAPI 3.x format
                if "paths" in swagger_json:
                    for path, path_item in swagger_json["paths"].items():
                        # Count each HTTP method for this path
                        for method in [
                            "get",
                            "post",
                            "put",
                            "delete",
                            "patch",
                            "head",
                            "options",
                            "trace",
                        ]:
                            if method in path_item:
                                api_count += 1

            # Check if it's Swagger 2.x
            elif "swagger" in swagger_json and swagger_json["swagger"].startswith("2"):
                # Swagger 2.x format
                if "paths" in swagger_json:
                    for path, path_item in swagger_json["paths"].items():
                        # Count each HTTP method for this path
                        for method in [
                            "get",
                            "post",
                            "put",
                            "delete",
                            "patch",
                            "head",
                            "options",
                        ]:
                            if method in path_item:
                                api_count += 1

            logger.info(f"Total API count in swagger JSON: {api_count}")
            return api_count

        except Exception as e:
            logger.error(f"Error counting APIs in swagger JSON: {e}")
            return 0

    async def create_backend_server(self, *, backend_server: BackendServer) -> str:
        """Create a new backend server."""
        try:
            query_parameters = BackendServerQueryParameters(
                name=backend_server.name,
            )
            existing_servers_by_name = (
                await self._backend_server_repository.find_all_without_pagination(
                    query_parameters=query_parameters
                )
            )

            if existing_servers_by_name:
                logger.error(
                    f"Backend server with name {backend_server.name} already exists"
                )
                raise CoreServiceException(
                    CoreError.DUPLICATE_FOUND,
                    details=f"Backend server name already exists: {backend_server.name}",
                )

            query_parameters = BackendServerQueryParameters(
                system_name=backend_server.system_name,
            )
            existing_servers_by_system_name = (
                await self._backend_server_repository.find_all_without_pagination(
                    query_parameters=query_parameters
                )
            )

            if existing_servers_by_system_name:
                logger.error(
                    f"Backend server with system_name {backend_server.system_name} already exists"
                )
                raise CoreServiceException(
                    CoreError.DUPLICATE_FOUND,
                    details=f"Backend server system_name already exists: {backend_server.system_name}",
                )

            if backend_server.swagger_url and not backend_server.swagger_json:
                logger.info(
                    f"Auto-fetching swagger JSON from {backend_server.swagger_url}"
                )
                try:
                    swagger_json = await self._fetch_swagger_json(
                        backend_server.swagger_url
                    )
                    backend_server.swagger_json = swagger_json
                    logger.info(
                        f"Successfully fetched swagger JSON from {backend_server.swagger_url}"
                    )
                except CoreServiceException:
                    # Re-raise the exception as it's already properly formatted
                    raise
                except Exception as e:
                    logger.error(f"Unexpected error during swagger JSON fetch: {e}")
                    raise CoreServiceException(
                        CoreError.INTERNAL_SERVER_ERROR,
                        details=f"Failed to process swagger JSON: {e}",
                    )

            if backend_server.swagger_json:
                swagger_json = backend_server.swagger_json
                # For OpenAPI 3.0, update servers array
                if "openapi" in swagger_json and swagger_json["openapi"].startswith(
                    "3"
                ):
                    if "servers" in swagger_json and swagger_json["servers"]:
                        # Update the first server URL
                        server_url = backend_server.domain
                        if backend_server.base_path:
                            server_url += backend_server.base_path
                        swagger_json["servers"][0]["url"] = server_url
                    else:
                        # Create servers array if it doesn't exist
                        server_url = backend_server.domain
                        if backend_server.base_path:
                            server_url += backend_server.base_path
                        swagger_json["servers"] = [{"url": server_url}]
                # For Swagger 2.0, update host and basePath
                elif "swagger" in swagger_json and swagger_json["swagger"].startswith(
                    "2"
                ):
                    swagger_json["host"] = backend_server.domain.replace(
                        "https://", ""
                    ).replace("http://", "")
                    if backend_server.base_path:
                        swagger_json["basePath"] = backend_server.base_path

                backend_server.swagger_json = swagger_json
                logger.info(
                    f"Updated host/basePath in swagger JSON with domain: {backend_server.domain}, base_path: {backend_server.base_path}"
                )
            # Count APIs in swagger JSON
            backend_server.api_count = self.count_apis_in_swagger_json(swagger_json)

            return await self._backend_server_repository.insert(item=backend_server)

        except CoreServiceException:
            # Re-raise StudioBackendException as is to preserve the original error type
            raise
        except Exception as e:
            logger.error(f"Error creating backend server: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to create backend server: {e}",
            )

    async def get_backend_server_by_id(self, *, id: str) -> BackendServer:
        """Get a backend server by ID."""
        try:
            return await self._backend_server_repository.find_by_id(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Backend server not found: {id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )

    async def modify_backend_server(
        self, *, backend_server: BackendServer
    ) -> BackendServer:
        """Update a backend server."""
        try:
            original = await self._backend_server_repository.find_by_id(
                item_id=backend_server.id
            )

            backend_server.system_name = original.system_name

            query_parameters = BackendServerQueryParameters(
                name=backend_server.name,
            )
            existing_servers_by_name = (
                await self._backend_server_repository.find_all_without_pagination(
                    query_parameters=query_parameters
                )
            )
            for server in existing_servers_by_name:
                if server.id != backend_server.id:
                    logger.error(
                        f"Backend server with name {backend_server.name} already exists (id={server.id})"
                    )
                    raise CoreServiceException(
                        CoreError.DUPLICATE_FOUND,
                        details=f"Backend server name already exists: {backend_server.name}",
                    )

            if backend_server.swagger_url and not backend_server.swagger_json:
                logger.info(
                    f"Auto-fetching swagger JSON from {backend_server.swagger_url}"
                )
                try:
                    swagger_json = await self._fetch_swagger_json(
                        backend_server.swagger_url
                    )
                    backend_server.swagger_json = swagger_json
                    logger.info(
                        f"Successfully fetched swagger JSON from {backend_server.swagger_url}"
                    )
                except CoreServiceException:
                    # Re-raise the exception as it's already properly formatted
                    raise
                except Exception as e:
                    logger.error(f"Unexpected error during swagger JSON fetch: {e}")
                    raise CoreServiceException(
                        CoreError.INTERNAL_SERVER_ERROR,
                        details=f"Failed to process swagger JSON: {e}",
                    )

            if backend_server.swagger_json:
                swagger_json = backend_server.swagger_json
                # For OpenAPI 3.0, update servers array
                if "openapi" in swagger_json and swagger_json["openapi"].startswith(
                    "3"
                ):
                    if "servers" in swagger_json and swagger_json["servers"]:
                        # Update the first server URL
                        server_url = backend_server.domain
                        if backend_server.base_path:
                            server_url += backend_server.base_path
                        swagger_json["servers"][0]["url"] = server_url
                    else:
                        # Create servers array if it doesn't exist
                        server_url = backend_server.domain
                        if backend_server.base_path:
                            server_url += backend_server.base_path
                        swagger_json["servers"] = [{"url": server_url}]
                # For Swagger 2.0, update host and basePath
                elif "swagger" in swagger_json and swagger_json["swagger"].startswith(
                    "2"
                ):
                    swagger_json["host"] = backend_server.domain.replace(
                        "https://", ""
                    ).replace("http://", "")
                    if backend_server.base_path:
                        swagger_json["basePath"] = backend_server.base_path

                backend_server.swagger_json = swagger_json
                logger.info(
                    f"Updated host/basePath in swagger JSON with domain: {backend_server.domain}, base_path: {backend_server.base_path}"
                )
            # Count APIs in swagger JSON
            backend_server.api_count = self.count_apis_in_swagger_json(swagger_json)

            return await self._backend_server_repository.update(item=backend_server)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Backend server not found: {backend_server.id}",
            )
        except CoreServiceException:
            # Re-raise StudioBackendException as is to preserve the original error type
            raise
        except Exception as e:
            logger.error(f"Error updating backend server: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to update backend server: {e}",
            )

    async def remove_backend_server_by_id(self, *, id: str) -> bool:
        """Delete a backend server."""
        try:
            mcp_profiles = (
                await self._mcp_server_profile_repository.find_by_backend_server_id(
                    backend_server_id=id
                )
            )

            if mcp_profiles:
                profile_names = [profile.name for profile in mcp_profiles]
                raise CoreServiceException(
                    CoreError.INTERNAL_SERVER_ERROR,
                    document=CollectionName.BACKEND_SERVER,
                    field="reference",
                    details=f"Backend server is being used by MCP profiles: {', '.join(profile_names)}. Please remove it from these mcp profiles first.",
                )

            return await self._backend_server_repository.delete(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Backend server not found: {id}",
            )
        except CoreServiceException:
            # Re-raise CoreServiceException as is to preserve the original error type
            raise
        except Exception as e:
            logger.error(f"Error deleting backend server: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to delete backend server: {e}",
            )

    async def get_backend_servers(
        self,
        *,
        query_parameters: BackendServerQueryParameters,
        page_number: int = 1,
        page_size: int = 10,
    ) -> list[BackendServer]:
        """Get backend servers."""
        try:
            return await self._backend_server_repository.find_all(
                query_parameters=query_parameters,
                page_number=page_number,
                page_size=page_size,
            )
        except Exception as e:
            logger.error(f"Error getting backend servers: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get backend servers: {e}",
            )

    async def get_backend_servers_count(
        self, *, query_parameters: BackendServerQueryParameters
    ) -> int:
        """Get backend servers count."""
        return await self._backend_server_repository.count(
            query_parameters=query_parameters
        )
