"""Agent instance service."""

from __future__ import annotations

import logging
from typing import Any

from bson import ObjectId

from axmp_ai_agent_core.agent.spec.profile_base import (
    AuthenticationConfig,
    EndpointConfig,
)
from axmp_ai_agent_core.agent.spec.types import DeploymentMode
from axmp_ai_agent_core.db.agent_profile_history_repository import (
    AgentProfileHistoryRepository,
)
from axmp_ai_agent_core.db.agent_profile_repository import AgentProfileRepository
from axmp_ai_agent_core.db.agent_provision_status_repository import (
    AgentProvisionStatusRepository,
)
from axmp_ai_agent_core.entity import AgentProfile
from axmp_ai_agent_core.entity.agent_provision_status import AgentProvisionStatus
from axmp_ai_agent_core.entity.kubernetes_config import KubernetesConfig
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.agent_instance_query import (
    AgentInstanceQueryParameters,
)
from axmp_ai_agent_core.filter.agent_profile_provision_status_query import (
    AgentProfileProvisionStatusQueryParameters,
)
from axmp_ai_agent_core.k8s.k8s_manager_factory import K8sManagerFactory
from axmp_ai_agent_core.k8s.k8s_utils import (
    get_or_create_instance_id,
    prepare_instance_labels,
)
from axmp_ai_agent_core.k8s.model.agent_instance import AgentInstance
from axmp_ai_agent_core.k8s.model.custom_resource import Phase
from axmp_ai_agent_core.service.util.instance_sync_utils import (
    evict_stale_cache,
    handle_orphaned_instances,
)
from axmp_ai_agent_core.setting import agent_settings

logger = logging.getLogger(__name__)


class AgentInstanceService:
    """Agent instance service."""

    def __init__(
        self,
        agent_profile_repository: AgentProfileRepository,
        agent_profile_history_repository: AgentProfileHistoryRepository,
        k8s_manager_factory: K8sManagerFactory,
        agent_provision_status_repository: AgentProvisionStatusRepository,
    ):
        """Initialize the agent instance service."""
        self._agent_profile_repository: AgentProfileRepository = (
            agent_profile_repository
        )
        self._agent_profile_history_repository: AgentProfileHistoryRepository = (
            agent_profile_history_repository
        )
        self._k8s_manager_factory: K8sManagerFactory = k8s_manager_factory
        self._agent_provision_status_repository: AgentProvisionStatusRepository = (
            agent_provision_status_repository
        )
        # Cache for status sync optimization: skip DB write when status unchanged
        # Key: (cluster_id, name, namespace), Value: Phase
        self._status_cache: dict[tuple[str, str, str], Phase] = {}

    async def get_agent_instances(
        self,
        *,
        query_parameters: AgentInstanceQueryParameters,
        page_number: int = 1,
        page_size: int = 10,
    ) -> list[AgentProvisionStatus]:
        """Get agent instances from database with pagination.

        This method queries the provision status database instead of K8s API,
        providing faster response times and reduced load on K8s clusters.

        Args:
            query_parameters: Query parameters for filtering instances
            page_number: Page number (1-based)
            page_size: Number of items per page

        Returns:
            List of AgentProvisionStatus entities matching the query
        """
        # Convert AgentInstanceQueryParameters to AgentProfileProvisionStatusQueryParameters
        # Build query params dict, only including non-None values
        query_params: dict[str, Any] = {
            "keyword": query_parameters.keyword,
            "cluster_id": query_parameters.cluster_id,
            "status": query_parameters.status,
        }
        if query_parameters.sort_field is not None:
            query_params["sort_field"] = query_parameters.sort_field
        if query_parameters.sort_direction is not None:
            query_params["sort_direction"] = query_parameters.sort_direction

        provision_query = AgentProfileProvisionStatusQueryParameters(**query_params)

        return await self._agent_provision_status_repository.find_all(
            query_parameters=provision_query,
            page_number=page_number,
            page_size=page_size,
        )

    async def get_agent_instances_count(
        self, *, query_parameters: AgentInstanceQueryParameters
    ) -> int:
        """Count agent instances matching the query.

        Args:
            query_parameters: Query parameters for filtering instances

        Returns:
            Total count of matching instances
        """
        provision_query = AgentProfileProvisionStatusQueryParameters(
            keyword=query_parameters.keyword,
            cluster_id=query_parameters.cluster_id,
            status=query_parameters.status,
        )

        return await self._agent_provision_status_repository.count(
            query_parameters=provision_query
        )

    async def get_agent_instance_by_id(
        self, instance_id: str | None = None
    ) -> AgentInstance:
        """Find agent instance by instance-id using DB provision status lookup."""
        provision_status = (
            await self._agent_provision_status_repository.find_by_instance_id(
                instance_id=instance_id
            )
        )
        if not provision_status:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent provision status not found for instance: {instance_id}",
            )

        manager = await self._k8s_manager_factory.create_agent_manager(
            provision_status.cluster_id
        )
        instance = await manager.get(
            name=provision_status.name,
            namespace=provision_status.namespace,
        )
        if not instance:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent instance not found in cluster: {instance_id}",
            )
        return instance

    async def update_agent_instance(
        self,
        *,
        existing_agent_instance: AgentInstance,
        updated_agent_instance: AgentInstance,
        updated_by: str,
        cluster_config: KubernetesConfig,
    ) -> AgentInstance:
        """Update an advanced agent instance."""
        try:
            manager = self._k8s_manager_factory.create_agent_manager_from_config(
                cluster_config
            )
            await manager.update(instance=updated_agent_instance)

            profile_id = (updated_agent_instance.metadata.labels or {}).get(
                "profile-id"
            )
            resources = await manager.get_all(
                labels=[f"profile-id={profile_id}"],
            )
            if not resources:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Agent instance not found: {profile_id}",
                )
            return resources[0]
        except CoreServiceException:
            raise
        except Exception as exc:
            logger.exception("Advanced update failed due to unexpected error")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Advanced update failed due to unexpected error.",
            ) from exc

    async def delete_agent_instance(
        self,
        *,
        instance_id: str,
    ) -> bool:
        """Delete an agent instance: K8s resource + provision status."""
        provision_status = (
            await self._agent_provision_status_repository.find_by_instance_id(
                instance_id=instance_id
            )
        )
        if not provision_status:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent provision status not found: {instance_id}",
            )

        manager = await self._k8s_manager_factory.create_agent_manager(
            provision_status.cluster_id
        )
        await manager.delete(
            name=provision_status.name,
            namespace=provision_status.namespace,
        )

        await self._agent_provision_status_repository.delete(
            item_id=str(provision_status.id)
        )
        return True

    async def stop_agent_instance(
        self, *, name: str, cluster_id: str, namespace: str
    ) -> bool:
        """Stop an agent instance by scaling replicas to zero."""
        manager = await self._k8s_manager_factory.create_agent_manager(cluster_id)
        return await manager.scale(name=name, namespace=namespace, replicas=0)

    async def resume_agent_instance(
        self, *, name: str, cluster_id: str, namespace: str
    ) -> bool:
        """Resume an agent instance by restoring replicas."""
        manager = await self._k8s_manager_factory.create_agent_manager(cluster_id)
        return await manager.scale(name=name, namespace=namespace, replicas=1)

    async def validate_and_get_provision_status(
        self, *, profile_id: str, version: int, cluster_id: str
    ) -> AgentProvisionStatus | None:
        """Validate no duplicate and get provision status with single DB query."""
        try:
            existing_provision = await self._agent_provision_status_repository.find_by_profile_and_cluster(
                profile_id=profile_id,
                cluster_id=cluster_id,
            )
            if existing_provision:
                if existing_provision.profile_version == version:
                    # Same version = duplicate error
                    raise CoreServiceException(
                        CoreError.DUPLICATE_FOUND,
                        details=f"Agent provision status already exists: {profile_id}, v{version} on cluster {cluster_id}",
                    )
                # Different version = return for update
                return existing_provision
            # No provision = return None for new creation
            return None
        except CoreServiceException:
            raise

    async def get_provision_status_by_profile_id_and_version_and_cluster_id(
        self, *, profile_id: str, version: int, cluster_id: str
    ) -> AgentProvisionStatus | None:
        """Get provision status by profile ID, version and cluster ID."""
        return await self._agent_provision_status_repository.find_by_profile_and_version_and_cluster(
            profile_id=profile_id,
            version=version,
            cluster_id=cluster_id,
        )

    async def execute_provisioning(
        self,
        *,
        agent_instance: AgentInstance,
        provision_status: AgentProvisionStatus | None,
        profile: AgentProfile,
        cluster_config: KubernetesConfig,
        auth_config: AuthenticationConfig,
        endpoint_config: EndpointConfig,
        deployment_mode: DeploymentMode,
        created_by: str,
        updated_by: str,
    ) -> AgentInstance:
        """Create or update a basic agent instance."""
        try:
            cluster_id = cluster_config.id
            cluster_name = cluster_config.name
            profile_id = profile.id

            manager = self._k8s_manager_factory.create_agent_manager_from_config(
                cluster_config
            )

            # Find existing instance (for update scenarios)
            if provision_status is not None:
                existing_instance = await manager.get(
                    name=provision_status.name,
                    namespace=provision_status.namespace,
                )
            else:
                existing_instance = None

            # Get existing instance ID or create new one
            instance_id = get_or_create_instance_id(
                existing_instance, lambda: str(ObjectId())
            )

            # Prepare the labels
            labels = prepare_instance_labels(
                cluster_name=cluster_name,
                instance_id=instance_id,
                cluster_id=cluster_id,
                profile_id=profile_id,
                created_by=created_by,
                updated_by=updated_by,
                existing_instance=existing_instance,
            )
            agent_instance.metadata.labels = {
                **(agent_instance.metadata.labels or {}),
                **labels,
            }

            # Deploy the instance
            if existing_instance is None:
                await manager.create(
                    instance=agent_instance,
                    namespace=agent_instance.metadata.namespace
                    or agent_settings.namespace,
                )
            else:
                await manager.upsert(
                    instance=agent_instance,
                    namespace=agent_instance.metadata.namespace
                    or agent_settings.namespace,
                )
            deployed_instance = await manager.get(
                name=agent_instance.metadata.name,
                namespace=agent_instance.metadata.namespace or agent_settings.namespace,
            )
            if not deployed_instance:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Agent instance not found: {agent_instance.metadata.name}",
                )
            # Record provision status with all new fields
            provision_status = AgentProvisionStatus(
                profile_id=profile_id,
                profile_version=profile.version if profile.version else 1,
                cluster_id=cluster_id,
                cluster_name=cluster_name,
                namespace=agent_instance.metadata.namespace or agent_settings.namespace,
                instance_id=instance_id,
                name=agent_instance.metadata.name,
                status=Phase.UNKNOWN,
                labels=agent_instance.metadata.labels,
                auth_config=auth_config,
                endpoint_config=endpoint_config,
                deployment_mode=deployment_mode,
                created_by=created_by,
                updated_by=updated_by,
            )
            await self._agent_provision_status_repository.upsert_by_profile_and_cluster(
                item=provision_status
            )
            # Invalidate status cache: the upsert just reset DB.status to UNKNOWN.
            # Without this, the next sync cycle can cache-hit and skip the correction
            # indefinitely, leaving DB.status stuck at UNKNOWN while K8s is RUNNING.
            self._status_cache.pop(
                (
                    cluster_id,
                    agent_instance.metadata.name,
                    agent_instance.metadata.namespace or agent_settings.namespace,
                ),
                None,
            )
            return deployed_instance

        except CoreServiceException:
            raise
        except Exception as exc:
            operation = "deployment" if provision_status is None else "patching"
            logger.exception(f"Agent {operation} failed")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Agent {operation} failed due to unexpected error.",
            ) from exc

    async def sync_all_instances_status(self) -> int:
        """Synchronize all Agent instance statuses from K8s clusters to MongoDB.

        This method retrieves the actual state from K8s clusters and updates MongoDB.
        Uses caching to skip DB writes when status is unchanged (conditional update).

        Additionally, this method:
        - Marks orphaned instances (exist in DB but not in K8s) as TERMINATED
        - Evicts stale entries from the status cache to prevent memory leaks

        This method is designed to be called periodically by Studio (e.g., every 5 minutes).
        The polling interval is controlled by Studio, not by this Core module.

        Returns:
            Number of instances actually updated (0 if all cached)
        """
        total_count = 0
        updated_count = 0

        # 1. Get all non-TERMINATED provision statuses from DB
        all_db_statuses = (
            await self._agent_provision_status_repository.find_non_terminated_statuses()
        )
        db_status_map: dict[tuple[str, str, str], AgentProvisionStatus] = {
            (s.cluster_id, s.name, s.namespace): s for s in all_db_statuses
        }

        # 2. Get all K8s cluster configurations
        all_clusters = await self._k8s_manager_factory.get_all_kubernetes_configs()

        # 3. Track K8s instance keys for orphan detection
        k8s_instance_keys: set[tuple[str, str, str]] = set()

        for cluster_config in all_clusters:
            try:
                manager = self._k8s_manager_factory.create_agent_manager_from_config(
                    cluster_config
                )

                # 4. Get all Agent instances from the cluster
                instances = await manager.get_all()

                for instance in instances:
                    try:
                        labels = instance.metadata.labels or {}
                        profile_id = labels.get("profile-id")

                        if not profile_id:
                            continue

                        # Track this instance key
                        key = (
                            cluster_config.id,
                            instance.metadata.name,
                            instance.metadata.namespace or agent_settings.namespace,
                        )
                        k8s_instance_keys.add(key)

                        total_count += 1

                        # 5. Sync to DB (conditional update - only when status changed)
                        if await self._sync_instance_to_db(instance, cluster_config):
                            updated_count += 1

                    except Exception as e:
                        logger.warning(
                            f"Failed to sync agent instance {instance.metadata.name}: {e}"
                        )
                        continue

            except Exception as e:
                logger.warning(f"Failed to sync cluster {cluster_config.name}: {e}")
                continue

        # 6. Mark orphaned instances as TERMINATED (exist in DB but not in K8s)
        terminated_count = await handle_orphaned_instances(
            db_status_map=db_status_map,
            k8s_instance_keys=k8s_instance_keys,
            repository=self._agent_provision_status_repository,
            logger=logger,
            instance_type="Agent instance",
        )

        # 7. Cache eviction: remove stale entries (not in K8s)
        evict_stale_cache(
            status_cache=self._status_cache,
            k8s_instance_keys=k8s_instance_keys,
            logger=logger,
            instance_type="Agent",
        )

        logger.debug(
            f"Sync completed: {updated_count}/{total_count} updated, "
            f"{terminated_count} terminated"
        )
        return updated_count

    async def _sync_instance_to_db(
        self,
        instance: AgentInstance,
        cluster_config: KubernetesConfig,
    ) -> bool:
        """Sync a single agent instance status to DB (conditional update).

        Uses caching to skip DB writes when status is unchanged.

        Args:
            instance: The K8s AgentInstance with current state
            cluster_config: The cluster configuration

        Returns:
            True if DB was updated, False if skipped (status unchanged)
        """
        labels = instance.metadata.labels or {}
        profile_id = labels.get("profile-id")
        instance_id = labels.get("instance-id")

        if not profile_id:
            logger.debug(
                f"Skipping agent instance {instance.metadata.name}: no profile-id label"
            )
            return False

        if not instance_id:
            logger.debug(
                f"Skipping agent instance {instance.metadata.name}: no instance-id label"
            )
            return False

        # Extract current status
        current_status = instance.status.phase if instance.status else Phase.UNKNOWN

        # Cache key: (cluster_id, name, namespace)
        name = instance.metadata.name
        namespace = instance.metadata.namespace or agent_settings.namespace
        cache_key = (cluster_config.id, name, namespace)

        # Check cache - skip DB write if status unchanged
        cached_status = self._status_cache.get(cache_key)
        if cached_status == current_status:
            logger.debug(
                f"Skipping agent instance {instance.metadata.name}: "
                f"status unchanged ({current_status})"
            )
            return False

        # Status changed or cache miss → DB write
        # Look up existing provision status by K8s identity
        existing_status = await self._agent_provision_status_repository.find_by_cluster_and_name_and_namespace(
            cluster_id=cluster_config.id,
            name=name,
            namespace=namespace,
        )

        if not existing_status:
            # DB record not found → skip (provisioning creates the record)
            logger.warning(
                f"Skipping agent instance {name}: no DB record found "
                f"for cluster={cluster_config.id}, namespace={namespace}"
            )
            return False

        # Profile ID validation: DB profile_id vs K8s label profile-id
        if existing_status.profile_id != profile_id:
            logger.warning(
                f"Profile ID mismatch for agent instance {name}: "
                f"db={existing_status.profile_id}, k8s={profile_id} → marking UNKNOWN"
            )
            updated_status = existing_status.model_copy(
                update={"status": Phase.UNKNOWN}
            )
            await self._agent_provision_status_repository.update(item=updated_status)
            self._status_cache[cache_key] = Phase.UNKNOWN
            return True

        # Extract profile version from annotations
        annotations = instance.metadata.annotations or {}
        version_str = annotations.get("profile_version", "v1")
        try:
            profile_version = int(version_str.lstrip("v")) if version_str else 1
        except ValueError:
            profile_version = 1

        # Update existing status using immutable pattern with all fields
        update_fields = {
            "profile_version": profile_version,
            "cluster_id": cluster_config.id,
            "cluster_name": cluster_config.name,
            "namespace": namespace,
            "instance_id": instance_id,
            "name": name,
            "status": current_status,
            "labels": labels,
        }

        # Change detection: only UPDATE when metadata actually differs
        has_changes = any(
            getattr(existing_status, field, None) != value
            for field, value in update_fields.items()
        )
        if not has_changes:
            logger.debug(f"Skipping agent instance {name}: no metadata changes")
            self._status_cache[cache_key] = current_status
            return False

        updated_status = existing_status.model_copy(update=update_fields)
        await self._agent_provision_status_repository.update(item=updated_status)

        # Update cache after successful DB write
        self._status_cache[cache_key] = current_status

        logger.debug(
            f"Synced agent instance {instance.metadata.name} to DB, "
            f"profile_id={profile_id}, version={profile_version}, status={current_status}"
        )
        return True
