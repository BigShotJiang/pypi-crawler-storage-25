"""Skill service."""

from __future__ import annotations

import io
import logging
import mimetypes
import os
import zipfile
from datetime import datetime, timedelta

from motor.motor_asyncio import AsyncIOMotorClient

from axmp_ai_agent_core.agent.spec.types import SkillFileType
from axmp_ai_agent_core.db.agent_profile_repository import AgentProfileRepository
from axmp_ai_agent_core.db.skill_history_repository import SkillHistoryRepository
from axmp_ai_agent_core.db.skill_like_repository import SkillLikeRepository
from axmp_ai_agent_core.db.skill_repository import SkillRepository
from axmp_ai_agent_core.entity.skill import Skill, SkillFile
from axmp_ai_agent_core.entity.skill_history import SkillHistory
from axmp_ai_agent_core.entity.skill_like import SkillLike
from axmp_ai_agent_core.entity.user_rbac import AccessPermission, User
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.skill_query import (
    SkillQueryParameters,
    SkillScope,
    SkillSortField,
)
from axmp_ai_agent_core.setting import core_settings
from axmp_ai_agent_core.util.file_utils import (
    MAX_TOTAL_SIZE,
    delete_skill_directory,
    delete_skill_file_from_storage,
    save_skill_file,
)
from axmp_ai_agent_core.util.list_utils import (
    DEFAULT_PAGE_NUMBER,
    DEFAULT_PAGE_SIZE,
    SortDirection,
)
from axmp_ai_agent_core.util.search_utils import build_search_tokens
from axmp_ai_agent_core.util.time_utils import DEFAULT_TIME_ZONE

logger = logging.getLogger(__name__)


class SkillService:
    """Skill service."""

    def __init__(
        self,
        client: AsyncIOMotorClient,
        skill_repository: SkillRepository,
        skill_history_repository: SkillHistoryRepository,
        skill_like_repository: SkillLikeRepository,
        agent_profile_repository: AgentProfileRepository,
    ):
        """Initialize the Skill service."""
        self._client = client
        self._skill_repository = skill_repository
        self._skill_history_repository = skill_history_repository
        self._skill_like_repository = skill_like_repository
        self._agent_profile_repository = agent_profile_repository

    # =========================================================================
    # CRUD
    # =========================================================================

    async def create_skill(self, *, skill: Skill) -> str:
        """Create a new Skill (without History — v1 History is created on first Save/PUT)."""
        await self._check_duplicate_name(name=skill.name)
        await self._check_duplicate_system_name(system_name=skill.system_name)

        # Generate search tokens (Kiwi morphological analysis + alias expansion)
        skill.search_tokens = build_search_tokens(
            name=skill.name, description=skill.description
        )

        inserted_id = await self._skill_repository.insert(item=skill)

        logger.info(
            f"Created skill: id={inserted_id}, name={skill.name}, system_name={skill.system_name}"
        )
        return inserted_id

    async def get_skill_by_id(self, *, id: str) -> Skill:
        """Get a Skill by ID."""
        try:
            return await self._skill_repository.find_by_id(item_id=id)
        except ObjectNotFoundException:
            logger.warning(f"Skill not found: id={id}")
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND, details=f"Skill not found: {id}"
            )
        except InvalidObjectIDException:
            logger.warning(f"Invalid skill ID: id={id}")
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID, details=f"Invalid Skill ID: {id}"
            )

    async def get_skills(
        self,
        *,
        keyword: str | None = None,
        scope: SkillScope | None = None,
        categories: list[str] | None = None,
        sort_field: str | None = None,
        sort_direction: SortDirection = SortDirection.DESC,
        page_number: int = DEFAULT_PAGE_NUMBER,
        page_size: int = DEFAULT_PAGE_SIZE,
        current_user: User,
        is_admin: bool = False,
        exclude_fields: list[str] | None = None,
        include_fields: list[str] | None = None,
    ) -> list[Skill]:
        """Get Skills with pagination."""
        query_parameters = self._build_query_parameters(
            keyword=keyword,
            scope=scope,
            categories=categories,
            current_user=current_user,
            is_admin=is_admin,
            sort_field=sort_field,
            sort_direction=sort_direction,
        )
        return await self._skill_repository.find_all(
            query_parameters=query_parameters,
            page_number=page_number,
            page_size=page_size,
            exclude_fields=exclude_fields
            if exclude_fields is not None
            else ["instruction", "search_tokens"],
            include_fields=include_fields or [],
        )

    async def get_skills_simple(
        self,
        *,
        keyword: str | None = None,
        scope: SkillScope | None = None,
        current_user: User,
        is_admin: bool = False,
    ) -> list[Skill]:
        """Get skills with minimal fields for config-data."""
        query_parameters = self._build_query_parameters(
            keyword=keyword,
            scope=scope,
            categories=None,
            current_user=current_user,
            is_admin=is_admin,
        )
        return await self._skill_repository.find_all_without_pagination(
            query_parameters=query_parameters,
            include_fields=["_id", "name", "icon_url"],
        )

    async def count_skills(
        self,
        *,
        keyword: str | None = None,
        scope: SkillScope | None = None,
        categories: list[str] | None = None,
        current_user: User,
        is_admin: bool = False,
    ) -> int:
        """Count Skills matching query parameters."""
        query_parameters = self._build_query_parameters(
            keyword=keyword,
            scope=scope,
            categories=categories,
            current_user=current_user,
            is_admin=is_admin,
        )
        return await self._skill_repository.count(query_parameters=query_parameters)

    async def update_skill(self, *, skill: Skill) -> Skill:
        """Update a Skill with change detection and version history.

        Compares against the last History snapshot (not the current Skill entity).
        - No History → first Save after Create → v1 History creation
        - Has History → compare instruction/files → version increment if changed
        """
        await self._check_duplicate_name(name=skill.name, exclude_id=str(skill.id))

        # Check if Skill exists
        await self.get_skill_by_id(id=str(skill.id))

        # Regenerate search tokens (always regenerate regardless of name/description changes - for simplicity)
        skill.search_tokens = build_search_tokens(
            name=skill.name, description=skill.description
        )

        # Check the latest History version
        latest_version = await self._skill_history_repository.get_latest_version(
            skill_id=str(skill.id)
        )

        if latest_version == 0:
            # No History = first Save after Create -> create v1 History
            skill.version = 1
            updated = await self._skill_repository.update(item=skill)
            history = self._build_history_snapshot(
                skill=updated,
                skill_id=str(skill.id),
                version=1,
            )
            await self._skill_history_repository.insert(item=history)
            logger.info(f"Updated skill with new version: id={skill.id}, version=1")
            return updated

        # History exists -> compare with the last History snapshot
        last_history = (
            await self._skill_history_repository.find_by_skill_id_and_version(
                skill_id=str(skill.id), version=latest_version
            )
        )

        if self._has_content_changed(current=skill, last_history=last_history):
            skill.version = latest_version + 1

            async with await self._client.start_session() as session:
                async with session.start_transaction():
                    updated = await self._skill_repository.update(
                        item=skill, session=session
                    )
                    history = self._build_history_snapshot(
                        skill=updated,
                        skill_id=str(skill.id),
                        version=skill.version,
                    )
                    await self._skill_history_repository.insert(
                        item=history, session=session
                    )

            logger.info(
                f"Updated skill with new version: id={skill.id}, version={skill.version}"
            )

            # NOTE: cleanup executed outside the transaction.
            # Only Owner/Admin can modify a Skill, so concurrent writes to the same Skill
            # are practically impossible. Reconsider including in transaction if concurrent editing is added later.
            await self._cleanup_old_history(skill_id=str(skill.id))

            return updated

        try:
            result = await self._skill_repository.update(item=skill)
            logger.info(f"Updated skill: id={skill.id}, name={skill.name}")
            return result
        except ObjectNotFoundException:
            logger.warning(f"Skill not found: id={skill.id}")
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND, details=f"Skill not found: {skill.id}"
            )

    async def delete_skill_by_id(self, *, id: str) -> bool:
        """Delete a Skill and all associated history and likes.

        NOTE: cascade delete (history, likes) executed outside the transaction.
        If the process crashes after Skill deletion, orphaned records may remain,
        but since the Skill itself is deleted, there is no functional impact.
        """
        try:
            result = await self._skill_repository.delete(item_id=id)
        except ObjectNotFoundException:
            logger.warning(f"Skill not found: id={id}")
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND, details=f"Skill not found: {id}"
            )
        except InvalidObjectIDException:
            logger.warning(f"Invalid skill ID: id={id}")
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID, details=f"Invalid Skill ID: {id}"
            )

        history_deleted = await self._skill_history_repository.delete_by_skill_id(
            skill_id=id
        )
        like_deleted = await self._skill_like_repository.delete_by_skill_id(skill_id=id)

        # Delete the entire physical file directory
        await delete_skill_directory(skill_id=id, data_path=core_settings.data_path)

        logger.info(f"Deleted skill: id={id}")
        if history_deleted > 0:
            logger.info(f"Deleted all histories for skill: id={id}")
        if like_deleted > 0:
            logger.info(f"Deleted all likes for skill: id={id}")

        return result

    # =========================================================================
    # History & Pinning
    # =========================================================================

    async def get_skill_history(
        self,
        *,
        skill_id: str,
        page_number: int = 1,
        page_size: int = 50,
    ) -> list[SkillHistory]:
        """Get version history for a Skill."""
        await self.get_skill_by_id(id=skill_id)
        return await self._skill_history_repository.find_by_skill_id(
            skill_id=skill_id,
            page_number=page_number,
            page_size=page_size,
        )

    async def get_skill_history_version(
        self, *, skill_id: str, version: int
    ) -> SkillHistory:
        """Get a specific version snapshot of a Skill."""
        await self.get_skill_by_id(id=skill_id)
        try:
            return await self._skill_history_repository.find_by_skill_id_and_version(
                skill_id=skill_id, version=version
            )
        except ObjectNotFoundException:
            logger.warning(
                f"Skill history version not found: skill_id={skill_id}, version={version}"
            )
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Skill history not found: skill_id={skill_id}, version={version}",
            )

    async def pin_skill_version(
        self, *, skill_id: str, version: int, updated_by: str
    ) -> Skill:
        """Pin a specific version for a Skill."""
        skill = await self.get_skill_by_id(id=skill_id)

        await self.get_skill_history_version(skill_id=skill_id, version=version)

        pinned_skill = skill.model_copy(
            update={"pinned_version": version, "updated_by": updated_by}
        )

        try:
            result = await self._skill_repository.update(item=pinned_skill)
            logger.info(f"Pinned skill version: skill_id={skill_id}, version={version}")
            return result
        except ObjectNotFoundException:
            logger.warning(f"Skill not found: id={skill_id}")
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND, details=f"Skill not found: {skill_id}"
            )

    async def count_skill_history(self, *, skill_id: str) -> int:
        """Count history entries for a Skill."""
        return await self._skill_history_repository.count_by_skill_id(skill_id=skill_id)

    async def find_referencing_agents(self, *, skill_id: str) -> list[dict[str, str]]:
        """Find agent profiles that reference the given skill.

        Return a list of dicts with agent_id and agent_name.
        Empty list means no agents reference this skill.
        """
        return await self._agent_profile_repository.find_by_skill_id(skill_id=skill_id)

    # =========================================================================
    # Files
    # =========================================================================

    async def upload_skill_file(
        self,
        *,
        skill_id: str,
        file_type: SkillFileType,
        filename: str,
        content: bytes,
        uploaded_by: str,
    ) -> Skill:
        """Upload a file to a Skill. Replace if same filename+file_type exists.

        Does not increment version — version increases only on Save.
        """
        skill = await self.get_skill_by_id(id=skill_id)

        # Replace if same filename + file_type exists (physical file preserved)
        old_file = next(
            (
                f
                for f in skill.files
                if f.filename == filename and f.file_type == file_type
            ),
            None,
        )

        # Verify total file size (deduct old file size on replace)
        old_file_size = old_file.file_size if old_file else 0
        total_size = (
            sum(f.file_size for f in skill.files) - old_file_size + len(content)
        )
        if total_size > MAX_TOTAL_SIZE:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Total file size exceeds limit ({MAX_TOTAL_SIZE} bytes)",
            )

        if old_file:
            skill.files = [f for f in skill.files if f.file_id != old_file.file_id]

        # Save file
        try:
            file_id, file_path = await save_skill_file(
                skill_id=skill_id,
                filename=filename,
                content=content,
                data_path=core_settings.data_path,
            )
        except ValueError as e:
            raise CoreServiceException(CoreError.BAD_REQUEST, details=str(e))

        # Add metadata
        mime_type, _ = mimetypes.guess_type(filename)
        skill_file = SkillFile(
            file_id=file_id,
            file_type=file_type,
            filename=filename,
            file_path=file_path,
            file_size=len(content),
            mime_type=mime_type,
        )
        skill.files.append(skill_file)
        skill.updated_by = uploaded_by

        result = await self._skill_repository.update(item=skill)
        logger.info(
            f"Uploaded file to skill: skill_id={skill_id}, filename={filename}, "
            f"file_type={file_type}, file_id={file_id}"
        )
        return result

    async def download_skill_file(
        self, *, skill_id: str, file_id: str, version: int | None = None
    ) -> tuple[str, str]:
        """Get file path and filename for download.

        If version is specified, look up the file in that version's SkillHistory snapshot.
        Otherwise use pinned_version (if set) or the current Skill (latest).
        """
        skill = await self.resolve_skill_version(skill_id=skill_id, version=version)

        target_file = next((f for f in skill.files if f.file_id == file_id), None)
        if not target_file:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND, details=f"File not found: {file_id}"
            )

        full_path = os.path.join(core_settings.data_path, target_file.file_path)
        if not os.path.exists(full_path):
            logger.warning(
                "File not found on disk: skill_id=%s, file_id=%s, file_path=%s",
                skill_id,
                file_id,
                target_file.file_path,
            )
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"File not found on disk: {file_id}",
            )

        return full_path, target_file.filename

    async def delete_skill_file(
        self, *, skill_id: str, file_id: str, deleted_by: str
    ) -> Skill:
        """Delete a file from Skill metadata only.

        Physical file is preserved for History references.
        Cleaned up during History cleanup or Skill deletion.
        """
        skill = await self.get_skill_by_id(id=skill_id)

        target_file = next((f for f in skill.files if f.file_id == file_id), None)
        if not target_file:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND, details=f"File not found: {file_id}"
            )

        skill.files = [f for f in skill.files if f.file_id != file_id]
        skill.updated_by = deleted_by

        result = await self._skill_repository.update(item=skill)
        logger.info(f"Deleted file from skill: skill_id={skill_id}, file_id={file_id}")
        return result

    # =========================================================================
    # Like & Trending
    # =========================================================================

    async def toggle_like(self, *, skill_id: str, username: str) -> dict:
        """Toggle like on a Skill (transactional). Return {"liked": bool, "like_count": int}."""
        skill = await self.get_skill_by_id(id=skill_id)

        async with await self._client.start_session() as session:
            async with session.start_transaction():
                existing = await self._skill_like_repository.find_by_skill_and_user(
                    skill_id=skill_id, username=username, session=session
                )

                if existing:
                    await self._skill_like_repository.delete_by_skill_and_user(
                        skill_id=skill_id, username=username, session=session
                    )
                    await self._skill_repository.increment_like_count(
                        item_id=skill_id, delta=-1, session=session
                    )
                    new_count = max(0, skill.like_count - 1)
                    liked = False
                else:
                    like = SkillLike(
                        skill_id=skill_id, username=username, created_by=username
                    )
                    await self._skill_like_repository.insert(item=like, session=session)
                    await self._skill_repository.increment_like_count(
                        item_id=skill_id, delta=1, session=session
                    )
                    new_count = skill.like_count + 1
                    liked = True

        logger.info(
            f"Skill like toggled: skill_id={skill_id}, username={username}, liked={liked}"
        )
        return {"liked": liked, "like_count": new_count}

    async def get_like_status(self, *, skill_id: str, username: str) -> dict:
        """Get like status for a Skill. Return {"liked": bool, "like_count": int}."""
        skill = await self.get_skill_by_id(id=skill_id)
        existing = await self._skill_like_repository.find_by_skill_and_user(
            skill_id=skill_id, username=username
        )
        return {"liked": existing is not None, "like_count": skill.like_count}

    async def get_liked_skill_ids(
        self, *, skill_ids: list[str], username: str
    ) -> set[str]:
        """Get the set of skill_ids that the user has liked."""
        return await self._skill_like_repository.find_liked_skill_ids(
            skill_ids=skill_ids, username=username
        )

    async def get_skill_categories(
        self,
        *,
        scope: SkillScope | None = None,
        categories: list[str] | None = None,
        current_user: User,
        is_admin: bool = False,
    ) -> dict:
        """Get category counts within the current filter.

        Reuses find_all_query to apply scope + access_permission filters.
        keyword is intentionally excluded to return category counts for the entire scope.
        """
        query_parameters = self._build_query_parameters(
            keyword=None,
            scope=scope,
            categories=categories,
            current_user=current_user,
            is_admin=is_admin,
        )
        filter = await self._skill_repository.find_all_query(
            query_parameters=query_parameters
        )
        category_counts = await self._skill_repository.get_category_counts(
            filter=filter
        )
        return {"categories": category_counts}

    # =========================================================================
    # Export (SKILL.md / ZIP)
    # =========================================================================

    async def build_skill_md(
        self,
        *,
        skill_id: str,
        version: int | None = None,
    ) -> str:
        """Build complete SKILL.md text (YAML frontmatter + instruction body).

        Shared between API endpoint (clipboard copy) and internal uses (Playground/Agent).
        """
        skill = await self.resolve_skill_version(skill_id=skill_id, version=version)
        return _build_skill_md_text(skill=skill)

    async def build_skill_zip(
        self,
        *,
        skill_id: str,
        version: int | None = None,
    ) -> tuple[io.BytesIO, str]:
        """Build Skill ZIP (SKILL.md + attached files).

        Returns:
            Tuple of (zip_buffer, filename). The filename is "{system_name}.zip".
        """
        skill = await self.resolve_skill_version(skill_id=skill_id, version=version)
        skill_md = _build_skill_md_text(skill=skill)

        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("SKILL.md", skill_md)

            for file in skill.files:
                target_dir = _file_type_to_dir(file.file_type)
                zip_path = f"{target_dir}/{file.filename}"
                full_path = os.path.join(core_settings.data_path, file.file_path)

                if os.path.exists(full_path):
                    zf.write(full_path, zip_path)
                else:
                    logger.warning(
                        "File not found, skipping in ZIP: skill_id=%s, file=%s",
                        skill_id,
                        file.file_path,
                    )

        zip_buffer.seek(0)
        return zip_buffer, f"{skill.system_name}.zip"

    async def resolve_skill_version(
        self,
        *,
        skill_id: str,
        version: int | None = None,
    ) -> Skill:
        """Resolve version and return a Skill with the resolved version's data.

        Explicit version specified -> Query in SkillHistory and build a Skill (raises 404 if not found).
        No version specified -> Use pinned_version -> Query SkillHistory / Fallback to current Skill (latest).
        Skill query is only performed when version/pinned doesn't resolve (prevents unnecessary DB queries).
        """
        if version is not None:
            try:
                history = (
                    await self._skill_history_repository.find_by_skill_id_and_version(
                        skill_id=skill_id, version=version
                    )
                )
            except ObjectNotFoundException as e:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Skill version not found: {skill_id} v{version}",
                ) from e
            return _skill_from_history(history=history, version=version)

        # No version specified -> Query Skill (need to check pinned)
        skill = await self.get_skill_by_id(id=skill_id)

        if skill.pinned_version:
            try:
                history = (
                    await self._skill_history_repository.find_by_skill_id_and_version(
                        skill_id=skill_id, version=skill.pinned_version
                    )
                )
            except ObjectNotFoundException:
                logger.warning(
                    "Pinned version %s not found for skill %s, falling back to latest",
                    skill.pinned_version,
                    skill_id,
                )
                history = None
            if history:
                return _skill_from_history(
                    history=history, version=skill.pinned_version
                )

        return skill

    async def get_trending_skills(
        self,
        *,
        access_permission: AccessPermission | None,
        limit: int = 10,
    ) -> dict:
        """Get trending Skills with auto fallback (7d → 30d → all).

        Return {"period": "7d"|"30d"|"all", "skills": list[Skill]}.
        """
        # 1st: 7-day trending
        since_7d = datetime.now(DEFAULT_TIME_ZONE) - timedelta(days=7)
        result = await self._get_trending_by_period(
            since=since_7d, access_permission=access_permission, limit=limit
        )
        if len(result) >= limit:
            return {"period": "7d", "skills": result}

        # 2nd: 30-day trending
        since_30d = datetime.now(DEFAULT_TIME_ZONE) - timedelta(days=30)
        result = await self._get_trending_by_period(
            since=since_30d, access_permission=access_permission, limit=limit
        )
        if len(result) >= limit:
            return {"period": "30d", "skills": result}

        # 3rd: all-time popular (fallback)
        # access_permission filter handles visibility (own PRIVATE is visible, others' PRIVATE is excluded)
        query = SkillQueryParameters(
            sort_field=SkillSortField.LIKE_COUNT,
            sort_direction=SortDirection.DESC,
            access_permission=access_permission,
        )
        skills = await self._skill_repository.find_all(
            query_parameters=query,
            page_number=1,
            page_size=limit,
            exclude_fields=["instruction", "search_tokens"],
        )
        return {"period": "all", "skills": skills}

    # =========================================================================
    # Private helpers
    # =========================================================================

    def _build_query_parameters(
        self,
        *,
        keyword: str | None,
        scope: SkillScope | None,
        categories: list[str] | None,
        current_user: User,
        is_admin: bool,
        sort_field: str | None = None,
        sort_direction: SortDirection = SortDirection.DESC,
    ) -> SkillQueryParameters:
        """Build SkillQueryParameters with admin/scope branching logic."""
        if is_admin and scope == SkillScope.ALL:
            return SkillQueryParameters(
                keyword=keyword,
                categories=categories,
                sort_field=sort_field,
                sort_direction=sort_direction,
            )

        return SkillQueryParameters(
            keyword=keyword,
            scope=scope,
            categories=categories,
            current_username=current_user.username,
            current_group_ids=current_user.group_ids,
            access_permission=current_user.access_permission,
            sort_field=sort_field,
            sort_direction=sort_direction,
        )

    async def _get_trending_by_period(
        self,
        *,
        since: datetime,
        access_permission: AccessPermission | None,
        limit: int,
    ) -> list[Skill]:
        """Get trending Skills for a specific period using aggregation + $in lookup."""
        trending = await self._skill_like_repository.get_trending_skill_ids(
            since=since, limit=limit * 2
        )
        if not trending:
            return []

        skill_ids = [item["_id"] for item in trending]
        # access_permission filter handles visibility (own PRIVATE is visible, others' PRIVATE is excluded)
        skills = await self._skill_repository.find_by_ids(
            ids=skill_ids,
            access_permission=access_permission,
            exclude_fields=["instruction", "search_tokens"],
        )

        # Preserve aggregation order (most liked first)
        id_order = {sid: idx for idx, sid in enumerate(skill_ids)}
        skills.sort(key=lambda s: id_order.get(str(s.id), float("inf")))

        return skills[:limit]

    @staticmethod
    def _has_content_changed(*, current: Skill, last_history: SkillHistory) -> bool:
        """Check if instruction or files changed vs last History snapshot."""
        return (
            current.instruction != last_history.instruction
            or current.files != last_history.files
        )

    @staticmethod
    def _build_history_snapshot(
        *,
        skill: Skill,
        skill_id: str,
        version: int,
    ) -> SkillHistory:
        """Build a SkillHistory snapshot from a Skill."""
        return SkillHistory(
            skill_id=skill_id,
            version=version,
            name=skill.name,
            system_name=skill.system_name,
            description=skill.description,
            instruction=skill.instruction,
            categories=skill.categories,
            icon_url=skill.icon_url,
            files=skill.files,
            created_by=skill.created_by,
            updated_by=skill.updated_by,
            created_at=skill.created_at,
            updated_at=skill.updated_at,
        )

    async def _cleanup_old_history(self, *, skill_id: str) -> None:
        """Delete oldest history entries when exceeding max count.

        Protect pinned versions and versions referenced by agents.
        Also cleans up orphaned physical files from deleted histories.
        """
        max_count = core_settings.skill_history_max_count

        count = await self._skill_history_repository.count_by_skill_id(
            skill_id=skill_id
        )
        if count <= max_count:
            return

        delete_count = count - max_count

        # Collect protected versions
        protected_versions: set[int] = set()

        skill = await self._skill_repository.find_by_id(item_id=skill_id)
        if skill.pinned_version:
            protected_versions.add(skill.pinned_version)

        # Lightweight fetch: only _id and version, sorted oldest first
        versions = await self._skill_history_repository.find_versions_by_skill_id(
            skill_id=skill_id
        )

        # Collect IDs to delete (oldest first, skip protected)
        ids_to_delete: list[str] = []
        for entry in versions:
            if len(ids_to_delete) >= delete_count:
                break
            if entry["version"] in protected_versions:
                continue
            ids_to_delete.append(entry["id"])

        # Individual deletion (including file cleanup)
        deleted = 0
        for history_id in ids_to_delete:
            history = await self._skill_history_repository.find_by_id(
                item_id=history_id
            )
            if history:
                await self._delete_history_with_files(
                    history=history, current_skill=skill
                )
                deleted += 1

        if deleted > 0:
            logger.info(
                f"Cleaned up {deleted} old history entries for skill: id={skill_id}"
            )

    async def _delete_history_with_files(
        self, *, history: SkillHistory, current_skill: Skill
    ) -> None:
        """Delete a History entry and clean up orphaned physical files."""
        current_file_ids = {f.file_id for f in current_skill.files}

        for file in history.files:
            # Do not touch files currently used by the current Skill
            if file.file_id in current_file_ids:
                continue
            # Only delete files not referenced by any other History
            if not await self._skill_history_repository.exists_with_file_id(
                skill_id=history.skill_id,
                file_id=file.file_id,
                exclude_history_id=str(history.id),
            ):
                try:
                    await delete_skill_file_from_storage(
                        file_path=file.file_path, data_path=core_settings.data_path
                    )
                except (OSError, ValueError):
                    logger.warning(
                        f"Failed to delete orphan file: file_id={file.file_id}, "
                        f"file_path={file.file_path}"
                    )

        # History record deletion is always executed regardless of file cleanup failure
        await self._skill_history_repository.delete(item_id=str(history.id))

    async def _check_duplicate_name(
        self, *, name: str | None, exclude_id: str | None = None
    ) -> None:
        """Check if a Skill with the given name already exists."""
        if name is None:
            return

        existing = await self._skill_repository.find_by_name(
            name=name, exclude_id=exclude_id
        )
        if existing:
            logger.warning(f"Duplicate skill name: {name}")
            raise CoreServiceException(
                CoreError.DUPLICATE_FOUND,
                details=f"Skill with name '{name}' already exists",
            )

    async def _check_duplicate_system_name(
        self, *, system_name: str | None, exclude_id: str | None = None
    ) -> None:
        """Check if a Skill with the given system_name already exists."""
        if system_name is None:
            return

        existing = await self._skill_repository.find_by_system_name(
            system_name=system_name, exclude_id=exclude_id
        )
        if existing:
            logger.warning(f"Duplicate skill system_name: {system_name}")
            raise CoreServiceException(
                CoreError.DUPLICATE_FOUND,
                details=f"Skill with system_name '{system_name}' already exists",
            )


# ===========================================================================
# Module-level helpers
# ===========================================================================

_FILE_TYPE_DIR_MAP = {
    SkillFileType.SCRIPT: "scripts",
    SkillFileType.REFERENCE: "references",
    SkillFileType.ASSET: "assets",
}


def _file_type_to_dir(file_type: SkillFileType) -> str:
    """Map SkillFileType to Agent Skills spec directory name."""
    return _FILE_TYPE_DIR_MAP.get(file_type, "assets")


def _skill_from_history(*, history: SkillHistory, version: int) -> Skill:
    """Build a Skill entity from a SkillHistory snapshot."""
    return Skill(
        id=history.skill_id,
        name=history.name,
        system_name=history.system_name,
        description=history.description,
        instruction=history.instruction,
        categories=history.categories,
        icon_url=history.icon_url,
        files=history.files,
        version=version,
        created_at=history.created_at,
        updated_at=history.updated_at,
        created_by=history.created_by,
        updated_by=history.updated_by,
    )


def _build_skill_md_text(*, skill: Skill) -> str:
    """Build SKILL.md text from YAML frontmatter + instruction body."""
    frontmatter = (
        f"---\n"
        f"name: {skill.system_name}\n"
        f"version: {skill.version}\n"
        f"description: {skill.description or ''}\n"
        f"---\n"
    )
    body = skill.instruction or ""
    return f"{frontmatter}\n{body}"
