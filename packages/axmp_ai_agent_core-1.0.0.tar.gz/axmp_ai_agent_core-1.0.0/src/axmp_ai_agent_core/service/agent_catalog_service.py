"""This module contains the service for the agent catalog."""

from __future__ import annotations

import logging
from typing import List

from motor.motor_asyncio import AsyncIOMotorClient

from axmp_ai_agent_core.db.agent_catalog_repository import AgentCatalogRepository
from axmp_ai_agent_core.entity.agent_catalog import (
    AgentCatalog,
)
from axmp_ai_agent_core.exception.db_exceptions import ObjectNotFoundException
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.agent_catalog_query import AgentCatalogQueryParameters

logger = logging.getLogger(__name__)


class AgentCatalogService:
    """The service for the agent catalog."""

    def __init__(
        self,
        client: AsyncIOMotorClient,
        agent_catalog_repository: AgentCatalogRepository,
    ):
        """Initialize the agent catalog service."""
        self._client = client
        self._agent_catalog_repository: AgentCatalogRepository = (
            agent_catalog_repository
        )

    async def get_agent_catalog_by_id(self, *, id: str) -> AgentCatalog:
        """Get an agent catalog by ID."""
        try:
            agent_catalog = await self._agent_catalog_repository.find_by_id(item_id=id)
            return agent_catalog
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent catalog not found: {id}",
            )

    async def get_agent_catalogs(
        self,
        *,
        query_parameters: AgentCatalogQueryParameters,
        page_number: int = 1,
        page_size: int = 10,
    ) -> List[AgentCatalog]:
        """Get agent catalogs with pagination."""
        return await self._agent_catalog_repository.find_all(
            query_parameters=query_parameters,
            page_number=page_number,
            page_size=page_size,
        )

    async def get_agent_catalogs_count(
        self, *, query_parameters: AgentCatalogQueryParameters
    ) -> int:
        """Get the total count of agent catalogs."""
        return await self._agent_catalog_repository.count(
            query_parameters=query_parameters
        )

    async def create_agent_catalog(self, *, agent_catalog: AgentCatalog) -> str:
        """Create a new simple agent catalog."""
        return await self._agent_catalog_repository.insert(item=agent_catalog)

    async def modify_agent_catalog(
        self, *, agent_catalog: AgentCatalog
    ) -> AgentCatalog:
        """Modify a simple agent catalog."""
        try:
            updated_agent_catalog = await self._agent_catalog_repository.update(
                item=agent_catalog
            )
            return updated_agent_catalog
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent catalog not found: {agent_catalog.id}",
            )

    async def remove_agent_catalog_by_id(self, *, id: str) -> bool:
        """Remove an agent catalog by ID."""
        try:
            return await self._agent_catalog_repository.delete(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent catalog not found: {id}",
            )

    async def get_agent_catalog_categories(self) -> List[str]:
        """Get all unique categories from agent catalogs."""
        return await self._agent_catalog_repository.find_all_categories()
