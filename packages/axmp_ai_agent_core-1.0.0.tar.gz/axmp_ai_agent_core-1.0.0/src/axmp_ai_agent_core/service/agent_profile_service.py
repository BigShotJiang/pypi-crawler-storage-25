"""This module contains the service for the agent."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any, AsyncGenerator

from axmp_openapi_helper import AuthenticationType
from langchain.chat_models import BaseChatModel
from langchain_core.messages import HumanMessage, messages_to_dict
from langgraph.checkpoint.memory import InMemorySaver, MemorySaver
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.base import BaseStore
from langgraph.store.memory import InMemoryStore
from langgraph.types import Checkpointer, Command
from motor.motor_asyncio import AsyncIOMotorClient
from sse_starlette.sse import ServerSentEvent
from typing_extensions import deprecated

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig, NeedAuthMCPServer
from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.clients.factory import UserMCPClientFactory
from axmp_ai_agent_core.agent.spec.profile_base import SpecBaseEdge
from axmp_ai_agent_core.agent.spec.profile_node_data import (
    AgentSpecData,
    ChatbotTriggerSpecData,
    HumanInTheLoopMiddlewareSpec,
    LLMSpecData,
    McpServerSpecData,
    MemorySpecData,
    PIIMiddlewareSpec,
    SchedulerTriggerSpecData,
    SkillSpecData,
    SkillSpecFileData,
    SubAgentSpecData,
    SummarizationMiddlewareSpec,
    WebhookTriggerSpecData,
)
from axmp_ai_agent_core.agent.spec.profiles.deepagent_profile import (
    DeepAgentSpecFlow,
    DeepAgentSpecNode,
    DeepAgentSpecProfile,
)
from axmp_ai_agent_core.agent.spec.profiles.singleagent_profile import (
    SingleAgentSpecFlow,
    SingleAgentSpecNode,
    SingleAgentSpecProfile,
)
from axmp_ai_agent_core.agent.spec.types import (
    MCPServerType,
    NodeType,
    ProfileStatus,
    ProfileType,
    TransportType,
)
from axmp_ai_agent_core.agent.streaming.sse_generator import stream_agent_events
from axmp_ai_agent_core.agent.util.agent_cache import AsyncTTLQueue
from axmp_ai_agent_core.agent.util.agent_cache_key_format import (
    agent_cache_key,
    agent_playground_agent_cache_key,
    agent_wrapper_cache_key,
)
from axmp_ai_agent_core.agent.util.cached_agent import CachedAgent
from axmp_ai_agent_core.agent.util.chat_file_utils import (
    ChatFile as AgentChatFile,
)
from axmp_ai_agent_core.agent.util.chat_file_utils import (
    generate_multimodal_messages,
)
from axmp_ai_agent_core.agent.util.load_chat_model import load_chat_model
from axmp_ai_agent_core.agent.util.mcp_client_manager import McpServer
from axmp_ai_agent_core.agent.wrapper import (
    BaseAgentWrapper,
    DeepAgentContext,
    DeepAgentWrapper,
    SingleAgentContext,
    SingleAgentWrapper,
)
from axmp_ai_agent_core.db.agent_profile_history_repository import (
    AgentProfileHistoryRepository,
)
from axmp_ai_agent_core.db.agent_profile_repository import AgentProfileRepository
from axmp_ai_agent_core.db.agent_provision_status_repository import (
    AgentProvisionStatusRepository,
)
from axmp_ai_agent_core.db.chat_file_repository import ChatFileRepository
from axmp_ai_agent_core.db.chat_memory_repository import ChatMemoryRepository
from axmp_ai_agent_core.db.conversation_repository import ConversationRepository
from axmp_ai_agent_core.db.llm_provider_repository import LlmProviderRepository
from axmp_ai_agent_core.db.skill_history_repository import SkillHistoryRepository
from axmp_ai_agent_core.db.skill_repository import SkillRepository
from axmp_ai_agent_core.db.user_credential_repository import UserCredentialRepository
from axmp_ai_agent_core.db.user_repository import UserRepository
from axmp_ai_agent_core.entity import AgentProfile
from axmp_ai_agent_core.entity.agent_profile_deepagent import (
    DeepAgentProfile,
    DeepAgentProfileFlow,
    DeepAgentProfileNode,
)
from axmp_ai_agent_core.entity.agent_profile_history import AgentProfileHistory
from axmp_ai_agent_core.entity.agent_profile_node_data import (
    AgentNodeData,
    ChatbotTriggerNodeData,
    ExternalMcpServerNodeData,
    HumanInTheLoopMiddlewareConfig,
    InternalMcpServerNodeData,
    LLMNodeData,
    MemoryNodeData,
    PIIMiddlewareConfig,
    SchedulerTriggerNodeData,
    SkillNodeData,
    SubAgentNodeData,
    SummarizationMiddlewareConfig,
    WebhookTriggerNodeData,
)
from axmp_ai_agent_core.entity.agent_profile_singleagent import (
    SingleAgentProfileFlow,
    SingleAgentProfileNode,
)
from axmp_ai_agent_core.entity.agent_provision_status import AgentProvisionStatus
from axmp_ai_agent_core.entity.base_profile import Edge
from axmp_ai_agent_core.entity.chat_file import ChatFile
from axmp_ai_agent_core.entity.llm_provider import LlmModel
from axmp_ai_agent_core.entity.shared_target import SharedTarget
from axmp_ai_agent_core.entity.skill import Skill
from axmp_ai_agent_core.entity.user_credential import UserCredentialType
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.agent_profile_history_query import (
    AgentProfileHistoryQueryParameters,
)
from axmp_ai_agent_core.filter.agent_profile_provision_status_query import (
    AgentProfileProvisionStatusQueryParameters,
)
from axmp_ai_agent_core.filter.agent_profile_query import AgentProfileQueryParameters
from axmp_ai_agent_core.filter.chat_file_query import ChatFilesQueryParameters
from axmp_ai_agent_core.setting import core_settings
from axmp_ai_agent_core.util.version_utils import generate_next_version

logger = logging.getLogger(__name__)

MCP_SERVER_CONFIG_KEY = "mcpServers"


class AgentProfileService:
    """The service for the agent."""

    def __init__(
        self,
        client: AsyncIOMotorClient,
        agent_profile_repository: AgentProfileRepository,
        chat_file_repository: ChatFileRepository,
        llm_provider_repository: LlmProviderRepository,
        user_credential_repository: UserCredentialRepository,
        chat_memory_repository: ChatMemoryRepository,
        conversation_repository: ConversationRepository,
        agent_profile_history_repository: AgentProfileHistoryRepository,
        agent_provision_status_repository: AgentProvisionStatusRepository,
        skill_repository: SkillRepository,
        skill_history_repository: SkillHistoryRepository,
        user_repository: UserRepository,
        oauth_mcp_server_registry: OAuthMCPServerRegistry,
        mcp_client_factory: UserMCPClientFactory,
        agent_cache: AsyncTTLQueue,
        checkpointer: Checkpointer | None = None,
        store: BaseStore | None = None,
        redis_client: Any | None = None,
    ):
        """Initialize the agent service."""
        self._client = client
        self._agent_profile_repository: AgentProfileRepository = (
            agent_profile_repository
        )
        self._chat_file_repository: ChatFileRepository = chat_file_repository
        self._llm_provider_repository: LlmProviderRepository = llm_provider_repository
        self._user_credential_repository: UserCredentialRepository = (
            user_credential_repository
        )
        self._chat_memory_repository: ChatMemoryRepository = chat_memory_repository
        self._conversation_repository: ConversationRepository = conversation_repository
        self._agent_profile_history_repository: AgentProfileHistoryRepository = (
            agent_profile_history_repository
        )
        self._agent_provision_status_repository: AgentProvisionStatusRepository = (
            agent_provision_status_repository
        )
        self._skill_repository = skill_repository
        self._skill_history_repository = skill_history_repository
        self._user_repository = user_repository
        self._oauth_mcp_server_registry = oauth_mcp_server_registry
        self._mcp_client_factory = mcp_client_factory
        self._agent_cache = agent_cache
        self._checkpointer = checkpointer
        self._store = store
        self._redis_client = redis_client

    # ---- Cancel flag helpers (Redis-based, cross-pod safe) ----
    _CANCEL_KEY_PREFIX = "agent:cancel:"
    _CANCEL_KEY_TTL = 60

    async def _set_cancel_flag(self, thread_id: str) -> None:
        """Set cancellation flag in Redis."""
        if self._redis_client:
            await self._redis_client.set(
                f"{self._CANCEL_KEY_PREFIX}{thread_id}",
                "1",
                ex=self._CANCEL_KEY_TTL,
            )

    async def _check_cancel_flag(self, thread_id: str) -> bool:
        """Check if cancellation flag is set in Redis."""
        if self._redis_client:
            try:
                return (
                    await self._redis_client.exists(
                        f"{self._CANCEL_KEY_PREFIX}{thread_id}"
                    )
                    > 0
                )
            except Exception:
                return False
        return False

    async def _clear_cancel_flag(self, thread_id: str) -> None:
        """Clear cancellation flag from Redis."""
        if self._redis_client:
            await self._redis_client.delete(f"{self._CANCEL_KEY_PREFIX}{thread_id}")

    async def get_agent_profiles(
        self,
        *,
        query_parameters: AgentProfileQueryParameters,
        page_number: int = 1,
        page_size: int = 10,
    ) -> list[AgentProfile]:
        """Get agent profiles with root node information via pipeline."""
        return await self._agent_profile_repository.find_all(
            query_parameters=query_parameters,
            page_number=page_number,
            page_size=page_size,
        )

    async def get_agent_profile_by_id(self, *, id: str) -> AgentProfile:
        """Get an agent profile by ID."""
        try:
            agent_profile = await self._agent_profile_repository.find_by_id(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent profile not found: {id}",
            )

        return agent_profile

    async def get_latest_agent_profile_from_history(self, *, id: str) -> AgentProfile:
        """Get the latest version of the agent profile from the history."""
        try:
            agent_profile = await self._agent_profile_repository.find_by_id(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile ID format: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent profile not found: {id}",
            )

        latest_version = await self._agent_profile_history_repository.get_max_version(
            agent_profile_id=id
        )

        if latest_version == 0:
            raise CoreServiceException(
                CoreError.NO_STABLE_VERSION_FOUND,
                details=f"The agent profile ({agent_profile.name}) has no stable version",
            )

        agent_profile_history = (
            await self._agent_profile_history_repository.find_by_profile_id_and_version(
                profile_id=id,
                version=latest_version,
            )
        )

        return agent_profile_history.agent_profile_data

    async def get_agent_profile_skills(
        self, *, profile_id: str, version: int
    ) -> list[dict[str, str]]:
        """Get the skill list of the agent profile by the version.

        Args:
            profile_id: Agent profile ID.
            version: Agent profile version.

        Returns:
            List of skill dicts with ``id`` and ``name``.

        Raises:
            CoreServiceException: If agent profile not found.
        """
        agent_profile: AgentProfile | None = None

        try:
            agent_profile = await self.get_agent_profile_by_id(id=profile_id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile ID format: {profile_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Agent profile not found for profile: {profile_id}",
            )

        # not current version in the agent_profile, get from history
        if version != agent_profile.version:
            try:
                agent_profile_history = await self._agent_profile_history_repository.find_by_profile_id_and_version(
                    profile_id=profile_id,
                    version=version,
                )
            except InvalidObjectIDException:
                raise CoreServiceException(
                    CoreError.INVALID_OBJECTID,
                    details=f"Invalid agent profile ID format: {profile_id}",
                )
            except ObjectNotFoundException:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Agent profile not found for profile: {profile_id} and version: {version}",
                )

            agent_profile: AgentProfile = agent_profile_history.agent_profile_data

        if not isinstance(agent_profile, DeepAgentProfile):
            return []

        if not agent_profile.flow or not agent_profile.flow.nodes:
            return []

        return [
            {
                "id": node.data.skill_id,
                "name": node.data.name,
                "icon_url": node.data.icon_url,
            }
            for node in agent_profile.flow.nodes
            if node.node_type == NodeType.SKILL
        ]

    async def upsert_agent_profile(
        self, *, agent_profile: AgentProfile
    ) -> AgentProfile:
        """Upsert an agent profile and return the upserted entity."""
        if agent_profile.id:
            # Update path
            # 1st. check if the agent profile exists
            try:
                current_agent_profile = await self._agent_profile_repository.find_by_id(
                    item_id=agent_profile.id
                )
            except InvalidObjectIDException:
                raise CoreServiceException(
                    CoreError.INVALID_OBJECTID,
                    details=f"Invalid agent profile ID format: {agent_profile.id}",
                )
            except ObjectNotFoundException:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Agent profile not found: {agent_profile.id}",
                )

            # 2nd. check if the name is duplicated
            if current_agent_profile.name != agent_profile.name:
                duplicate_agent_profile = (
                    await self._agent_profile_repository.find_by_name(
                        name=agent_profile.name
                    )
                )
                if (
                    duplicate_agent_profile
                    and duplicate_agent_profile.id != agent_profile.id
                ):
                    raise CoreServiceException(
                        CoreError.DUPLICATE_FOUND,
                        details=f"Agent profile name is duplicated: {agent_profile.name}",
                    )

            # 3rd. check if the trigger type
            if agent_profile.flow and agent_profile.flow.nodes:
                trigger_node = None
                try:
                    trigger_node = agent_profile.get_node_by_type(NodeType.TRIGGER)
                except ValueError:
                    pass  # trigger node is not found, so we can ignore this during draft update

                if trigger_node and trigger_node.data:
                    if agent_profile.trigger_type is not None:
                        if agent_profile.trigger_type != trigger_node.data.trigger_type:
                            raise CoreServiceException(
                                CoreError.BAD_REQUEST,
                                details=f"Trigger type is not match {agent_profile.trigger_type}:{trigger_node.data.trigger_type}",
                            )
                    else:
                        agent_profile.trigger_type = trigger_node.data.trigger_type

            # 4th. check if the status is COMPLETED
            if current_agent_profile.status == ProfileStatus.COMPLETED:
                agent_profile.version = (
                    await self._generate_sequential_agent_profile_version(
                        agent_profile.id
                    )
                )
                agent_profile.status = ProfileStatus.DRAFT
            else:
                # Preserve existing version while staying in DRAFT
                agent_profile.version = current_agent_profile.version
                agent_profile.status = ProfileStatus.DRAFT

            # 5th. update the agent profile
            return await self._agent_profile_repository.update(item=agent_profile)

        else:
            # Create path
            # 1st. check if the system name is duplicated
            current_agent_profile = (
                await self._agent_profile_repository.find_by_system_name(
                    system_name=agent_profile.system_name
                )
            )
            if current_agent_profile:
                raise CoreServiceException(
                    CoreError.DUPLICATE_FOUND,
                    details=f"Agent profile system name is duplicated: {agent_profile.system_name}",
                )

            # 2nd. check if the name is duplicated
            current_agent_profile = await self._agent_profile_repository.find_by_name(
                name=agent_profile.name
            )
            if current_agent_profile:
                raise CoreServiceException(
                    CoreError.DUPLICATE_FOUND,
                    details=f"Agent profile name is duplicated: {agent_profile.name}",
                )

            # 3rd. check if the trigger type
            if agent_profile.flow and agent_profile.flow.nodes:
                trigger_node = None
                try:
                    trigger_node = agent_profile.get_node_by_type(NodeType.TRIGGER)
                except ValueError:
                    pass  # trigger node is not found, so we can ignore this during first version creation

                if trigger_node and trigger_node.data:
                    if agent_profile.trigger_type is not None:
                        if agent_profile.trigger_type != trigger_node.data.trigger_type:
                            raise CoreServiceException(
                                CoreError.BAD_REQUEST,
                                details=f"Trigger type is not match {agent_profile.trigger_type}:{trigger_node.data.trigger_type}",
                            )
                    else:
                        agent_profile.trigger_type = trigger_node.data.trigger_type

            # 4th. set the status to DRAFT and generate the version
            agent_profile.status = ProfileStatus.DRAFT
            agent_profile.version = (
                await self._generate_sequential_agent_profile_version()
            )

            # 5th. insert the agent profile
            profile_id = await self._agent_profile_repository.insert(item=agent_profile)

            # 6th. return the agent profile
            return await self.get_agent_profile_by_id(id=profile_id)

    async def modify_agent_profile(
        self, *, agent_profile: AgentProfile, comment: str | None = None
    ) -> AgentProfile:
        """Update an agent profile with field validation and duplication checks."""
        # 1st. check if the agent profile exists
        try:
            current_agent_profile = await self._agent_profile_repository.find_by_id(
                item_id=agent_profile.id
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile ID format: {agent_profile.id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent profile not found: {agent_profile.id}",
            )

        # 2nd. check if the name is duplicated
        if current_agent_profile.name != agent_profile.name:
            duplicate_profile = await self._agent_profile_repository.find_by_name(
                name=agent_profile.name
            )
            if duplicate_profile and duplicate_profile.id != agent_profile.id:
                raise CoreServiceException(
                    CoreError.DUPLICATE_FOUND,
                    details=f"Agent profile name is duplicated: {agent_profile.name}",
                )

        # 3rd. should not change the system name
        agent_profile.system_name = current_agent_profile.system_name

        # 4th. check if the trigger type
        trigger_node = None
        if agent_profile.flow and agent_profile.flow.nodes:
            try:
                trigger_node = agent_profile.get_node_by_type(NodeType.TRIGGER)
            except ValueError:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details="Trigger node is required for the agent profile",
                )

        if trigger_node and trigger_node.data:
            if agent_profile.trigger_type is not None:
                if agent_profile.trigger_type != trigger_node.data.trigger_type:
                    raise CoreServiceException(
                        CoreError.BAD_REQUEST,
                        details=f"Trigger type is not match {agent_profile.trigger_type}:{trigger_node.data.trigger_type}",
                    )
            else:
                agent_profile.trigger_type = trigger_node.data.trigger_type

        # 5th. set the status to COMPLETED and generate the version
        if current_agent_profile.status == ProfileStatus.DRAFT:
            agent_profile.version = current_agent_profile.version
            agent_profile.status = ProfileStatus.COMPLETED
        else:
            agent_profile.version = (
                await self._generate_sequential_agent_profile_version(agent_profile.id)
            )
            agent_profile.status = ProfileStatus.COMPLETED

        # 6th. create the agent profile history
        agent_profile_history = AgentProfileHistory(
            agent_profile_id=agent_profile.id,
            version=agent_profile.version,
            comment=comment or "Agent profile version updated",
            agent_profile_data={
                **agent_profile.model_dump(by_alias=True),
                "id": agent_profile.id,
            },
            created_by=agent_profile.created_by,
        )

        history_id = await self._agent_profile_history_repository.insert(
            item=agent_profile_history
        )
        logger.info(
            f"Saved profile history for profile {agent_profile.id} at {agent_profile_history.version}, history_id: {history_id}"
        )

        # 7th. update the agent profile
        return await self._agent_profile_repository.update(item=agent_profile)

    async def modify_agent_profile_is_published_to_workspace(
        self, *, agent_profile_id: str, is_published_to_workspace: bool, updated_by: str
    ) -> AgentProfile:
        """Update the is_published_to_workspace field for an agent profile."""
        return await self._agent_profile_repository.update_is_published_to_workspace(
            item_id=agent_profile_id,
            is_published_to_workspace=is_published_to_workspace,
            updated_by=updated_by,
        )

    async def modify_agent_profile_shared_target(
        self, *, agent_profile_id: str, shared_target: SharedTarget, updated_by: str
    ) -> AgentProfile:
        """Update only shared_target on an existing profile without touching unique fields."""
        # Ensure the profile exists
        try:
            _ = await self._agent_profile_repository.find_by_id(
                item_id=agent_profile_id
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile ID format: {agent_profile_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent profile not found: {agent_profile_id}",
            )

        return await self._agent_profile_repository.update_shared_target(
            item_id=agent_profile_id, shared_target=shared_target, updated_by=updated_by
        )

    async def modify_agent_profile_configs(
        self, *, agent_profile: AgentProfile
    ) -> AgentProfile:
        """Update auth_config and endpoint_config on an existing profile without touching unique fields."""
        return await self._agent_profile_repository.update(item=agent_profile)

    async def remove_agent_profile_by_id(self, *, id: str) -> bool:
        """Delete an agent profile and all its histories and conversations."""
        # Check if profile is in use by provisioned instances
        provision_statuses = (
            await self._agent_provision_status_repository.find_all_by_profile_id(
                profile_id=id
            )
        )
        if provision_statuses:
            instance_names = [ps.name for ps in provision_statuses]
            raise CoreServiceException(
                CoreError.PROFILE_IN_USE,
                details=f"Agent profile '{id}' is in use by instances: {', '.join(instance_names)}",
            )

        # Delete histories, conversations, and profile in a transaction
        async with await self._client.start_session() as session:
            async with session.start_transaction():
                await self._agent_profile_history_repository.delete_by_agent_profile_id(
                    agent_profile_id=id, session=session
                )
                logger.info("Deleted all histories for agent profile: %s", id)

                await self._conversation_repository.delete_by_agent_id(
                    agent_id=id, session=session
                )
                logger.info("Deleted all conversations for agent profile: %s", id)

                try:
                    result = await self._agent_profile_repository.delete(
                        item_id=id, session=session
                    )
                except InvalidObjectIDException:
                    raise CoreServiceException(
                        CoreError.INVALID_OBJECTID,
                        details=f"Invalid agent profile ID format: {id}",
                    )
                except ObjectNotFoundException:
                    raise CoreServiceException(
                        CoreError.ID_NOT_FOUND,
                        details=f"Agent profile not found: {id}",
                    )

                return result

    async def get_profile_histories(
        self,
        *,
        query_parameters: AgentProfileHistoryQueryParameters,
    ) -> list[AgentProfileHistory]:
        """Get all agent profile histories with pagination."""
        try:
            histories_results = await self._agent_profile_history_repository.find_all_without_pagination(
                query_parameters=query_parameters,
                max_limit=0,
            )
            return histories_results
        except Exception as e:
            logger.error(f"Error getting all agent profile histories: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get all agent profile histories: {e}",
            )

    async def get_profile_history_by_id_and_version(
        self,
        *,
        profile_id: str,
        profile_version: int,
    ) -> AgentProfileHistory:
        """Get agent profile history by ID and version."""
        try:
            return await self._agent_profile_history_repository.find_by_profile_id_and_version(
                profile_id=profile_id,
                version=profile_version,
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile history ID format: {profile_id}:{profile_version}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent profile history not found: {profile_id}:{profile_version}",
            )

    async def remove_profile_history_by_id_and_version(
        self,
        *,
        profile_id: str,
        profile_version: int,
    ) -> AgentProfileHistory:
        """Remove agent profile history by ID and version."""
        try:
            history = await self._agent_profile_history_repository.find_by_profile_id_and_version(
                profile_id=profile_id,
                version=profile_version,
            )

            return await self._agent_profile_history_repository.delete(
                item_id=history.id
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile history ID format: {profile_id}:{profile_version}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent profile history not found: {profile_id}:{profile_version}",
            )

    async def get_agent_profiles_count(
        self, *, query_parameters: AgentProfileQueryParameters
    ) -> int:
        """Get agent profiles count."""
        return await self._agent_profile_repository.count(
            query_parameters=query_parameters
        )

    async def create_chat_file(
        self,
        *,
        chat_file: ChatFile,
    ) -> ChatFile:
        """Create a new file for a project. Just save ChatFiles to DB."""
        file_id = await self._chat_file_repository.insert(item=chat_file)

        return await self.get_chat_file(file_id=file_id)

    async def get_chat_file(self, *, file_id: str) -> ChatFile:
        """Get a file by file_id."""
        try:
            chat_file = await self._chat_file_repository.find_by_id(item_id=file_id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid file ID format: {file_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"File not found: {file_id}",
            )
        return chat_file

    async def remove_chat_file(self, *, file_id: str) -> bool:
        """Delete a file from a project by file_id."""
        # TODO: Implement S3 file deletion
        try:
            return await self._chat_file_repository.delete(item_id=file_id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid file ID format: {file_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"File not found: {file_id}",
            )

    async def get_chat_files(
        self,
        *,
        query_parameters: ChatFilesQueryParameters,
    ) -> list[ChatFile]:
        """Get files by file_ids."""
        return await self._chat_file_repository.find_all_without_pagination(
            query_parameters=query_parameters,
        )

    async def get_chat_files_count(
        self,
        *,
        query_parameters: ChatFilesQueryParameters,
    ) -> int:
        """Get files count by file_ids."""
        return await self._chat_file_repository.count(query_parameters=query_parameters)

    async def get_agent_profiles_simple(
        self,
        *,
        query_parameters: AgentProfileQueryParameters,
    ) -> list[AgentProfile]:
        """Get agent profiles simple."""
        return await self._agent_profile_repository.find_all_without_pagination(
            query_parameters=query_parameters,
            include_fields=[
                "id",
                "name",
                "agent_type",
                "icon_url",
                "status",
                "runtime_type",
                "created_by",
            ],
            exclude_fields=[],
        )

    def _convert_hitl_middleware(
        self,
        config: HumanInTheLoopMiddlewareConfig | None,
    ) -> HumanInTheLoopMiddlewareSpec | None:
        """Convert HumanInTheLoopMiddlewareConfig to HumanInTheLoopMiddlewareSpec."""
        if config is None or not config.enabled:
            return None
        # Flatten: dict[mcp_server_id, dict[tool_name, config]] → dict[tool_name, config]
        interrupt_on = {}
        for _mcp_server_id, tool_configs in config.interrupt_configs.items():
            for tool_name, tool_config in tool_configs.items():
                interrupt_on[tool_name] = {
                    "allowed_decisions": tool_config.allowed_decisions,
                }
        return HumanInTheLoopMiddlewareSpec(interrupt_on=interrupt_on)

    def _convert_pii_middlewares(
        self,
        config: PIIMiddlewareConfig | None,
    ) -> list[PIIMiddlewareSpec] | None:
        """Convert PIIMiddlewareConfig to list[PIIMiddlewareSpec]."""
        if config is None or not config.enabled:
            return None
        return [
            PIIMiddlewareSpec(
                pii_type=m.pii_type,
                strategy=m.strategy,
                detector=m.detector,
                apply_to_input=m.apply_to_input,
                apply_to_output=m.apply_to_output,
                apply_to_tool_results=m.apply_to_tool_results,
            )
            for m in config.pii_middlewares
        ]

    async def _convert_summarization_middleware(
        self,
        config: SummarizationMiddlewareConfig | None,
    ) -> SummarizationMiddlewareSpec | None:
        """Convert SummarizationMiddlewareConfig to SummarizationMiddlewareSpec."""
        if config is None or not config.enabled:
            return None
        # 1. Get LLM provider
        llm_provider = await self._llm_provider_repository.find_by_id(
            item_id=config.provider_id
        )
        fully_specified_name = f"{llm_provider.key}/{config.model_id}"

        # 2. Get API key
        user_credential = await self._user_credential_repository.find_by_id(
            item_id=config.api_key_credential_id
        )

        # 3. Load chat model
        model: BaseChatModel = load_chat_model(
            fully_specified_name=fully_specified_name,
            api_key=user_credential.llm_api_key,
            aws_access_key_id=user_credential.aws_access_key_id,
            aws_secret_access_key=user_credential.aws_secret_access_key,
            aws_region_name=user_credential.region_name,
        )

        # 4. Convert triggers: dict[type, value] → ContextSize tuple or list
        trigger = None
        if config.triggers:
            trigger = [
                (trigger_type, value) for trigger_type, value in config.triggers.items()
            ]
            if len(trigger) == 1:
                trigger = trigger[0]

        # 5. Convert keep: dict[type, value] → ContextSize tuple
        # NOTE: for fraction, we should set the max_input_token into the baseChatModel
        keep = ("messages", 20)  # default
        if config.keep:
            keep_item = next(iter(config.keep.items()))
            keep = (keep_item[0], keep_item[1])

        return SummarizationMiddlewareSpec(
            model=model,
            trigger=trigger,
            keep=keep,
        )

    async def create_agent_wrapper_based_on_profile(
        self,
        *,
        agent_profile: AgentProfile,
        checkpointer: MemorySaver,
        store: BaseStore,
    ) -> BaseAgentWrapper:
        """Transform an agent profile to a DeepAgentWrapper or SingleAgentWrapper."""
        if agent_profile.agent_type == ProfileType.DEEP_AGENT:
            flow: DeepAgentProfileFlow = agent_profile.flow
            if flow is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Agent profile flow is not found: {agent_profile.id}",
                )

            profile_edges: list[Edge] = flow.edges
            if profile_edges is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Agent profile edges is not found: {agent_profile.id}",
                )

            profile_nodes: list[DeepAgentProfileNode] = flow.nodes
            if profile_nodes is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Agent profile nodes is not found: {agent_profile.id}",
                )

            spec_nodes: list[DeepAgentSpecNode] = []
            spec_edges: list[SpecBaseEdge] = []
            # 1st. Transform edges from profile into spec
            for edge in profile_edges:
                spec_edges.append(
                    SpecBaseEdge(
                        id=edge.id,
                        source=edge.source,
                        target=edge.target,
                        edge_type=edge.edge_type,
                    )
                )

            # 2nd. Transform nodes from profile into spec
            for node in profile_nodes:
                if node.node_type == NodeType.TRIGGER:
                    trigger_node_data: (
                        ChatbotTriggerNodeData
                        | WebhookTriggerNodeData
                        | SchedulerTriggerNodeData
                    ) = node.data

                    if isinstance(trigger_node_data, ChatbotTriggerNodeData):
                        spec_nodes.append(
                            DeepAgentSpecNode(
                                id=node.id,
                                node_type=NodeType.TRIGGER,
                                root_node=node.root_node,
                                data=ChatbotTriggerSpecData(
                                    trigger_type=trigger_node_data.trigger_type,
                                    init_message=trigger_node_data.init_message,
                                ),
                            )
                        )
                    elif isinstance(trigger_node_data, WebhookTriggerNodeData):
                        spec_nodes.append(
                            DeepAgentSpecNode(
                                id=node.id,
                                node_type=NodeType.TRIGGER,
                                root_node=node.root_node,
                                data=WebhookTriggerSpecData(
                                    trigger_type=trigger_node_data.trigger_type,
                                ),
                            )
                        )
                    elif isinstance(trigger_node_data, SchedulerTriggerNodeData):
                        spec_nodes.append(
                            DeepAgentSpecNode(
                                id=node.id,
                                node_type=NodeType.TRIGGER,
                                root_node=node.root_node,
                                data=SchedulerTriggerSpecData(
                                    trigger_type=trigger_node_data.trigger_type,
                                    cron_expression=trigger_node_data.cron_expression,
                                    timezone=trigger_node_data.timezone,
                                ),
                            )
                        )
                    else:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"Invalid trigger node data: {trigger_node_data}",
                        )
                elif node.node_type == NodeType.AI_AGENT:
                    agent_node_data: AgentNodeData = node.data
                    # NOTE: for the issue #19, we need to validate the system prompt
                    try:
                        agent_data = AgentSpecData(
                            name=agent_node_data.name,
                            system_prompt=agent_node_data.system_prompt,
                            hitl_middleware=self._convert_hitl_middleware(
                                agent_node_data.hitl_middleware_config
                            ),
                            pii_middlewares=self._convert_pii_middlewares(
                                agent_node_data.pii_middleware_config
                            ),
                            summarization_middleware=await self._convert_summarization_middleware(
                                agent_node_data.summarization_middleware_config
                            ),
                        )
                    except ValueError as e:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"System prompt contains potentially dangerous content: {e}",
                        )

                    spec_nodes.append(
                        DeepAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.AI_AGENT,
                            root_node=True,
                            data=agent_data,
                        )
                    )
                elif node.node_type == NodeType.SUB_AGENT:
                    subagent_node_data: SubAgentNodeData = node.data
                    try:
                        subagent_data = SubAgentSpecData(
                            name=subagent_node_data.name,
                            system_prompt=subagent_node_data.system_prompt,
                            description=subagent_node_data.description,
                            hitl_middleware=self._convert_hitl_middleware(
                                subagent_node_data.hitl_middleware_config
                            ),
                            pii_middlewares=self._convert_pii_middlewares(
                                subagent_node_data.pii_middleware_config
                            ),
                            summarization_middleware=await self._convert_summarization_middleware(
                                subagent_node_data.summarization_middleware_config
                            ),
                        )
                    except ValueError as e:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"System prompt contains potentially dangerous content: {e}",
                        )
                    spec_nodes.append(
                        DeepAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.SUB_AGENT,
                            root_node=False,
                            data=subagent_data,
                        )
                    )
                elif node.node_type == NodeType.LLM:
                    llm_node_data: LLMNodeData = node.data

                    llm_provider = await self._llm_provider_repository.find_by_id(
                        item_id=llm_node_data.provider_id
                    )
                    user_credential = await self._user_credential_repository.find_by_id(
                        item_id=llm_node_data.api_key_credential_id
                    )

                    if llm_node_data.api_key_owner_username != user_credential.username:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"API key owner username is not match: {llm_node_data.api_key_owner_username} != {user_credential.username}",
                        )
                    if (
                        user_credential.credential_type
                        != UserCredentialType.LLM_PROVIDER
                    ):
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"Credential type is not LLM_PROVIDER: {user_credential.credential_type}",
                        )

                    spec_nodes.append(
                        DeepAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.LLM,
                            root_node=False,
                            data=LLMSpecData(
                                provider=llm_provider.key,
                                base_url=llm_provider.base_url or None,
                                default_model_id=llm_node_data.default_model or None,
                                temperature=llm_node_data.temperature,
                                max_tokens=llm_node_data.max_tokens,
                                api_key=user_credential.llm_api_key,
                                aws_access_key_id=user_credential.aws_access_key_id,
                                aws_secret_access_key=user_credential.aws_secret_access_key,
                                aws_region_name=user_credential.region_name,
                                max_retries=llm_node_data.max_retries,
                                request_timeout=llm_node_data.request_timeout,
                                streaming=llm_node_data.streaming,
                            ),
                        )
                    )
                elif node.node_type == NodeType.MEMORY:
                    memory_node_data: MemoryNodeData = node.data
                    agent_memory = await self._chat_memory_repository.find_by_id(
                        item_id=memory_node_data.memory_id
                    )

                    spec_nodes.append(
                        DeepAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.MEMORY,
                            root_node=False,
                            data=MemorySpecData(
                                memory_type=memory_node_data.memory_type,
                                db_uri=agent_memory.db_uri,
                            ),
                        )
                    )
                elif node.node_type == NodeType.MCP_SERVER:
                    mcp_server_data: (
                        InternalMcpServerNodeData | ExternalMcpServerNodeData
                    ) = node.data

                    if mcp_server_data.mcp_config_json is None:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"The MCP server {mcp_server_data.name} doesn't have mcp_config_json",
                        )

                    mcp_connection: dict[str, Any] = (
                        mcp_server_data.mcp_config_json.mcpServers
                    )

                    if not mcp_connection:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"The MCP server {mcp_server_data.name} doesn't have {MCP_SERVER_CONFIG_KEY} key",
                        )

                    server_name = next(iter(mcp_connection))
                    connection = mcp_connection[server_name]
                    # NOTE: langgraph mcp adapter requires the transport key
                    if connection.get("transport") is None:
                        connection["transport"] = "stdio"
                    else:
                        if connection.get("transport") in (
                            TransportType.STREAMABLE_HTTP_DASH,
                            TransportType.STREAMABLE_HTTP_UNDERSCORE,
                            TransportType.HTTP,
                        ):
                            connection["transport"] = (
                                TransportType.STREAMABLE_HTTP_UNDERSCORE.value
                            )

                    # build the headers for the internal MCP server using the backend server auth configs
                    # NOTE: currently, openapi-mcp-server supports only the headers of the backend servers
                    # TODO: support the headers of the MCP server later
                    if mcp_server_data.resource_type == MCPServerType.INTERNAL:
                        headers = connection.get("headers", {})
                        for (
                            backend_auth_config
                        ) in mcp_server_data.backend_server_auth_configs:
                            if (
                                backend_auth_config.auth_config.type
                                == AuthenticationType.BASIC
                            ):
                                headers[
                                    f"{backend_auth_config.server_system_name}{core_settings.mcp_server_separator}username"
                                ] = backend_auth_config.auth_config.username
                                headers[
                                    f"{backend_auth_config.server_system_name}{core_settings.mcp_server_separator}password"
                                ] = backend_auth_config.auth_config.password
                            elif (
                                backend_auth_config.auth_config.type
                                == AuthenticationType.BEARER
                            ):
                                headers[
                                    f"{backend_auth_config.server_system_name}{core_settings.mcp_server_separator}bearer_token"
                                ] = backend_auth_config.auth_config.bearer_token
                            elif (
                                backend_auth_config.auth_config.type
                                == AuthenticationType.API_KEY
                            ):
                                headers[
                                    f"{backend_auth_config.server_system_name}{core_settings.mcp_server_separator}{backend_auth_config.auth_config.api_key_name}"
                                ] = backend_auth_config.auth_config.api_key_value

                        connection["headers"] = headers

                    logger.debug("MCP server: %s, connection: [redacted]", server_name)

                    new_connection: dict[str, Any] = {}
                    new_connection[server_name] = connection

                    spec_nodes.append(
                        DeepAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.MCP_SERVER,
                            root_node=False,
                            data=McpServerSpecData(
                                config=new_connection,
                            ),
                        )
                    )
                elif node.node_type == NodeType.SKILL:
                    skill_node_data: SkillNodeData = node.data
                    # NOTE: No version specified -> Query Skill (need to check pinned)
                    skill = await self._get_pinned_skill(
                        skill_id=skill_node_data.skill_id
                    )

                    spec_nodes.append(
                        DeepAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.SKILL,
                            root_node=False,
                            data=SkillSpecData(
                                name=skill.system_name,
                                description=skill.description or "",
                                body_content=skill.instruction or "",
                                files=[
                                    SkillSpecFileData(
                                        file_type=sf.file_type,
                                        filename=sf.filename,
                                        file_path=Path(core_settings.data_path)
                                        / sf.file_path,
                                    )
                                    for sf in skill.files
                                ],
                            ),
                        )
                    )

            # 3rd. Create the DeepAgentSpecFlow
            deep_agent_spec_flow = DeepAgentSpecFlow(
                nodes=spec_nodes,
                edges=spec_edges,
            )

            # 4th. Create the DeepAgentSpecProfile
            try:
                agent_spec_profile = DeepAgentSpecProfile(
                    id=agent_profile.id,
                    version=agent_profile.version,
                    name=agent_profile.name,
                    system_name=agent_profile.system_name,
                    agent_type=agent_profile.agent_type,
                    runtime_type=agent_profile.runtime_type,
                    flow=deep_agent_spec_flow,
                )
            except Exception as e:
                logger.error(f"Error creating agent spec profile: {e}")
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Error creating agent spec profile: {e}",
                )

            logger.debug(
                "Agent spec profile created for: %s",
                agent_spec_profile.model_dump_json(indent=2),
            )

            wrapper = DeepAgentWrapper(
                agent_spec=agent_spec_profile,
                oauth_mcp_server_registry=self._oauth_mcp_server_registry,
                mcp_client_factory=self._mcp_client_factory,
                checkpointer=checkpointer,
                store=store,
                context_schema=DeepAgentContext,
            )
            return wrapper

        elif agent_profile.agent_type == ProfileType.SINGLE_AGENT:
            flow: SingleAgentProfileFlow = agent_profile.flow
            if flow is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Agent profile flow is not found: {agent_profile.id}",
                )

            profile_edges: list[Edge] = flow.edges
            if profile_edges is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Agent profile edges is not found: {agent_profile.id}",
                )

            profile_nodes: list[SingleAgentProfileNode] = flow.nodes
            if profile_nodes is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Agent profile nodes is not found: {agent_profile.id}",
                )

            spec_nodes: list[SingleAgentSpecNode] = []
            spec_edges: list[SpecBaseEdge] = []
            # 1st. Transform edges from profile into spec
            for edge in profile_edges:
                spec_edges.append(
                    SpecBaseEdge(
                        id=edge.id,
                        source=edge.source,
                        target=edge.target,
                        edge_type=edge.edge_type,
                    )
                )

            # 2nd. Transform nodes from profile into spec
            for node in profile_nodes:
                if node.node_type == NodeType.TRIGGER:
                    trigger_node_data: (
                        ChatbotTriggerNodeData
                        | WebhookTriggerNodeData
                        | SchedulerTriggerNodeData
                    ) = node.data

                    if isinstance(trigger_node_data, ChatbotTriggerNodeData):
                        spec_nodes.append(
                            SingleAgentSpecNode(
                                id=node.id,
                                node_type=NodeType.TRIGGER,
                                root_node=node.root_node,
                                data=ChatbotTriggerSpecData(
                                    trigger_type=trigger_node_data.trigger_type,
                                    init_message=trigger_node_data.init_message,
                                ),
                            )
                        )
                    elif isinstance(trigger_node_data, WebhookTriggerNodeData):
                        spec_nodes.append(
                            SingleAgentSpecNode(
                                id=node.id,
                                node_type=NodeType.TRIGGER,
                                root_node=node.root_node,
                                data=WebhookTriggerSpecData(
                                    trigger_type=trigger_node_data.trigger_type,
                                ),
                            )
                        )
                    elif isinstance(trigger_node_data, SchedulerTriggerNodeData):
                        spec_nodes.append(
                            SingleAgentSpecNode(
                                id=node.id,
                                node_type=NodeType.TRIGGER,
                                root_node=node.root_node,
                                data=SchedulerTriggerSpecData(
                                    trigger_type=trigger_node_data.trigger_type,
                                    cron_expression=trigger_node_data.cron_expression,
                                    timezone=trigger_node_data.timezone,
                                ),
                            )
                        )
                    else:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"Invalid trigger node data: {trigger_node_data}",
                        )
                elif node.node_type == NodeType.AI_AGENT:
                    agent_node_data: AgentNodeData = node.data
                    try:
                        agent_data = AgentSpecData(
                            name=agent_node_data.name,
                            system_prompt=agent_node_data.system_prompt,
                            hitl_middleware=self._convert_hitl_middleware(
                                agent_node_data.hitl_middleware_config
                            ),
                            pii_middlewares=self._convert_pii_middlewares(
                                agent_node_data.pii_middleware_config
                            ),
                            summarization_middleware=await self._convert_summarization_middleware(
                                agent_node_data.summarization_middleware_config
                            ),
                        )
                    except ValueError as e:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"System prompt contains potentially dangerous content: {e}",
                        )

                    spec_nodes.append(
                        SingleAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.AI_AGENT,
                            root_node=True,
                            data=agent_data,
                        )
                    )
                elif node.node_type == NodeType.LLM:
                    llm_node_data: LLMNodeData = node.data

                    llm_provider = await self._llm_provider_repository.find_by_id(
                        item_id=llm_node_data.provider_id
                    )
                    user_credential = await self._user_credential_repository.find_by_id(
                        item_id=llm_node_data.api_key_credential_id
                    )

                    if llm_node_data.api_key_owner_username != user_credential.username:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"API key owner username is not match: {llm_node_data.api_key_owner_username} != {user_credential.username}",
                        )
                    if (
                        user_credential.credential_type
                        != UserCredentialType.LLM_PROVIDER
                    ):
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"Credential type is not LLM_PROVIDER: {user_credential.credential_type}",
                        )

                    spec_nodes.append(
                        SingleAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.LLM,
                            root_node=False,
                            data=LLMSpecData(
                                provider=llm_provider.key,
                                base_url=llm_provider.base_url or None,
                                default_model_id=llm_node_data.default_model or None,
                                temperature=llm_node_data.temperature,
                                max_tokens=llm_node_data.max_tokens,
                                api_key=user_credential.llm_api_key,
                                aws_access_key_id=user_credential.aws_access_key_id,
                                aws_secret_access_key=user_credential.aws_secret_access_key,
                                aws_region_name=user_credential.region_name,
                                max_retries=llm_node_data.max_retries,
                                request_timeout=llm_node_data.request_timeout,
                                streaming=llm_node_data.streaming,
                            ),
                        )
                    )
                elif node.node_type == NodeType.MEMORY:
                    memory_node_data: MemoryNodeData = node.data
                    agent_memory = await self._chat_memory_repository.find_by_id(
                        item_id=memory_node_data.memory_id
                    )

                    spec_nodes.append(
                        SingleAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.MEMORY,
                            root_node=False,
                            data=MemorySpecData(
                                memory_type=memory_node_data.memory_type,
                                db_uri=agent_memory.db_uri,
                            ),
                        )
                    )
                elif node.node_type == NodeType.MCP_SERVER:
                    mcp_server_data: (
                        InternalMcpServerNodeData | ExternalMcpServerNodeData
                    ) = node.data

                    if mcp_server_data.mcp_config_json is None:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"The MCP server {mcp_server_data.name} doesn't have mcp_config_json",
                        )

                    mcp_connection: dict[str, Any] = (
                        mcp_server_data.mcp_config_json.mcpServers
                    )

                    if not mcp_connection:
                        raise CoreServiceException(
                            CoreError.BAD_REQUEST,
                            details=f"The MCP server {mcp_server_data.name} doesn't have {MCP_SERVER_CONFIG_KEY} key",
                        )

                    server_name = next(iter(mcp_connection))
                    connection = mcp_connection[server_name]
                    if connection.get("transport") is None:
                        connection["transport"] = TransportType.STDIO.value
                    else:
                        if connection.get("transport") in (
                            TransportType.STREAMABLE_HTTP_DASH,
                            TransportType.STREAMABLE_HTTP_UNDERSCORE,
                            TransportType.HTTP,
                        ):
                            connection["transport"] = TransportType.HTTP.value

                    if mcp_server_data.resource_type == MCPServerType.INTERNAL:
                        headers = connection.get("headers", {})
                        for (
                            backend_auth_config
                        ) in mcp_server_data.backend_server_auth_configs:
                            if (
                                backend_auth_config.auth_config.type
                                == AuthenticationType.BASIC
                            ):
                                headers[
                                    f"{backend_auth_config.server_system_name}{core_settings.mcp_server_separator}username"
                                ] = backend_auth_config.auth_config.username
                                headers[
                                    f"{backend_auth_config.server_system_name}{core_settings.mcp_server_separator}password"
                                ] = backend_auth_config.auth_config.password
                            elif (
                                backend_auth_config.auth_config.type
                                == AuthenticationType.BEARER
                            ):
                                headers[
                                    f"{backend_auth_config.server_system_name}{core_settings.mcp_server_separator}bearer_token"
                                ] = backend_auth_config.auth_config.bearer_token
                            elif (
                                backend_auth_config.auth_config.type
                                == AuthenticationType.API_KEY
                            ):
                                headers[
                                    f"{backend_auth_config.server_system_name}{core_settings.mcp_server_separator}{backend_auth_config.auth_config.api_key_name}"
                                ] = backend_auth_config.auth_config.api_key_value

                        connection["headers"] = headers

                    logger.debug("MCP server: %s, connection: [redacted]", server_name)

                    new_connection: dict[str, Any] = {}
                    new_connection[server_name] = connection

                    spec_nodes.append(
                        SingleAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.MCP_SERVER,
                            root_node=False,
                            data=McpServerSpecData(
                                config=new_connection,
                            ),
                        )
                    )
                elif node.node_type == NodeType.SKILL:
                    skill_node_data: SkillNodeData = node.data
                    # NOTE: Skill (need to check pinned)
                    skill = await self._get_pinned_skill(
                        skill_id=skill_node_data.skill_id
                    )
                    spec_nodes.append(
                        SingleAgentSpecNode(
                            id=node.id,
                            node_type=NodeType.SKILL,
                            root_node=False,
                            data=SkillSpecData(
                                name=skill.system_name,
                                description=skill.description or "",
                                body_content=skill.instruction or "",
                                files=[
                                    SkillSpecFileData(
                                        file_type=sf.file_type,
                                        filename=sf.filename,
                                        file_path=Path(core_settings.data_path)
                                        / sf.file_path,
                                    )
                                    for sf in skill.files
                                ],
                            ),
                        )
                    )

            # 3rd. Create the SingleAgentSpecFlow
            single_agent_spec_flow = SingleAgentSpecFlow(
                nodes=spec_nodes,
                edges=spec_edges,
            )

            # 4th. Create the SingleAgentSpecProfile
            try:
                agent_spec_profile = SingleAgentSpecProfile(
                    id=agent_profile.id,
                    version=agent_profile.version,
                    name=agent_profile.name,
                    system_name=agent_profile.system_name,
                    agent_type=agent_profile.agent_type,
                    runtime_type=agent_profile.runtime_type,
                    flow=single_agent_spec_flow,
                )
            except Exception as e:
                logger.error(f"Error creating agent spec profile: {e}")
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Error creating agent spec profile: {e}",
                )

            logger.debug(
                "Agent spec profile created for: %s",
                agent_spec_profile.model_dump_json(indent=2),
            )

            wrapper = SingleAgentWrapper(
                agent_spec=agent_spec_profile,
                oauth_mcp_server_registry=self._oauth_mcp_server_registry,
                mcp_client_factory=self._mcp_client_factory,
                checkpointer=checkpointer,
                store=store,
                context_schema=SingleAgentContext,
            )
            return wrapper

        elif agent_profile.agent_type == ProfileType.A2A_HOST_AGENT:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="A2A_HOST_AGENT profile type is not yet supported.",
            )
        elif agent_profile.agent_type == ProfileType.WORKFLOW:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="WORKFLOW profile type is not yet supported.",
            )
        else:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Invalid agent profile type: {agent_profile.agent_type}",
            )

    async def _get_pinned_skill(self, skill_id: str) -> Skill:
        """Get the pinned version of a skill."""
        skill = await self._skill_repository.find_by_id(item_id=skill_id)

        if skill.pinned_version:
            try:
                history = (
                    await self._skill_history_repository.find_by_skill_id_and_version(
                        skill_id=skill_id, version=skill.pinned_version
                    )
                )
            except ObjectNotFoundException:
                logger.warning(
                    "Pinned version %s not found for skill %s, falling back to latest",
                    skill.pinned_version,
                    skill_id,
                )
                history = None
            if history:
                return Skill(
                    id=history.skill_id,
                    name=history.name,
                    system_name=history.system_name,
                    description=history.description,
                    instruction=history.instruction,
                    categories=history.categories,
                    icon_url=history.icon_url,
                    files=history.files,
                    version=skill.pinned_version,
                    created_at=history.created_at,
                    updated_at=history.updated_at,
                    created_by=history.created_by,
                    updated_by=history.updated_by,
                )

        return skill

    async def disconnect_mcp_server(self, user_id: str, server_id: str) -> bool:
        """Disconnect a user's OAuth token for a specific MCP server.

        Clear the stored OAuth tokens so the user is no longer authenticated
        to the given MCP server. On the next agent request the existing
        ``need_mcp_authentication`` check will detect the missing token and
        prompt re-authentication automatically.

        Args:
            user_id: User identifier.
            server_id: MCP server identifier.

        Returns:
            True if disconnected successfully.

        Raises:
            CoreServiceException: If server not found in registry.
        """
        result = await self._mcp_client_factory.disconnect_user_server(
            user_id, server_id
        )
        if not result:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server '{server_id}' not found in OAuth registry or no token exists for user.",
            )
        return True

    async def create_playground_agent(
        self,
        *,
        profile_id: str,
        iss: str,
        sub: str,
        checkpointer: MemorySaver | None = None,
        store: BaseStore | None = None,
    ) -> tuple[AgentProfile, list[McpServer], CompiledStateGraph, bool]:
        """Create, build, cache, and return a playground agent.

        Args:
            profile_id: Agent profile ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            checkpointer: LangGraph checkpointer for state persistence.
            store: LangGraph store for agent data.

        Returns:
            Tuple of (agent profile, MCP server list, compiled agent graph, need_auth).
        """
        # 0. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )
        # 1. Cache key
        cache_key = agent_playground_agent_cache_key(profile_id, user.id)

        # 2. Evict existing cached agent
        _cached_agent = None
        if self._agent_cache is not None:
            _cached_agent = await self._agent_cache.get(cache_key)
            if _cached_agent is not None:
                await self._agent_cache.delete(cache_key)
                logger.info("Evicted cached agent for profile %s", profile_id)
                logger.info("Cache stats %s", await self._agent_cache.get_stats())

        # 3. Fetch agent profile
        agent_profile = await self.get_agent_profile_by_id(id=profile_id)

        # NOTE: playground is not needed to persist
        effective_checkpointer = InMemorySaver()
        effective_store = InMemoryStore()

        wrapper = await self.create_agent_wrapper_based_on_profile(
            agent_profile=agent_profile,
            checkpointer=effective_checkpointer,
            store=effective_store,
        )

        # 5. Check MCP authentication
        (
            need_auth,
            pending_auth,
            mcp_server_configs,
        ) = await wrapper.need_mcp_authentication(user.id)

        # 6. Get all MCP server nodes from agent profile
        profile_mcp_nodes = agent_profile.get_all_mcp_server_nodes()
        # validate mcp nodes size with mcp server configs
        # NOTE: duplicated mcp-server was skipped in wrapper.build_agent and spec_profile.get_all_mcp_server_nodes()
        if len(profile_mcp_nodes) != len(mcp_server_configs):
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server configs and profile MCP nodes do not match: {len(profile_mcp_nodes)} != {len(mcp_server_configs)}",
            )

        # 7. Build the agent graph (always build regardless of auth status)
        final_agent = await wrapper.build_agent(user.id)

        # 8. Cache the compiled graph only when all MCP servers are authenticated
        if not need_auth and self._agent_cache is not None:
            await self._agent_cache.put(
                cache_key,
                CachedAgent(
                    graph=final_agent,
                    mcp_server_configs=mcp_server_configs,
                ),
            )
            logger.info(
                "Cached the playground agent for agent profile %s", agent_profile.id
            )
            logger.info("Cache stats: %s", await self._agent_cache.get_stats())

        # 9. Get MCP servers for response
        mcp_servers: list[McpServer] = []
        for pmcp in profile_mcp_nodes:
            (
                server_id,
                mcp_need_auth,
                mcp_auth_url,
            ) = await self._need_auth_to_mcp_server(
                mcp_connection=pmcp.data.mcp_config_json.mcpServers,
                pending_auth=pending_auth,
            )

            _effective_mcp_config = await self._get_mcp_server_config(
                server_id=server_id,
                mcp_server_configs=mcp_server_configs,
            )
            if _effective_mcp_config is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"MCP server {server_id} not found in mcp_server_configs",
                )

            _connected = (
                not mcp_need_auth and _effective_mcp_config.error_message is None
            )

            mcp_servers.append(
                McpServer(
                    server_id=server_id,
                    server_name=pmcp.data.name,
                    is_oauth_server=_effective_mcp_config.is_oauth_server,
                    connected=_connected,
                    tools=await wrapper.get_mcp_server_tools(server_id),
                    registry_id=pmcp.data.registry_id,
                    resource_type=pmcp.data.resource_type,
                    transport_type=pmcp.data.transport_type,
                    icon_url=pmcp.data.icon_url,
                    auth_url=mcp_auth_url,
                    error_message=_effective_mcp_config.error_message,
                )
            )

        return agent_profile, mcp_servers, final_agent, need_auth

    async def create_workspace_agent(
        self,
        *,
        profile_id: str,
        iss: str,
        sub: str,
    ) -> tuple[AgentProfile, list[McpServer], CompiledStateGraph, bool]:
        """Create, build, cache, and return a workspace agent.

        Args:
            profile_id: Agent profile ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            checkpointer: LangGraph checkpointer for state persistence.
            store: LangGraph store for agent data.

        Returns:
            Tuple of (agent profile, MCP server list, compiled agent graph, need_auth).
        """
        # 1st. check the agent profile by ID
        agent_profile = None
        try:
            agent_profile = await self._agent_profile_repository.find_by_id(
                item_id=profile_id
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile ID format: {profile_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent profile not found: {profile_id}",
            )

        # 2nd. check if the agent profile is published to the workspace
        if not agent_profile.is_published_to_workspace:
            raise CoreServiceException(
                CoreError.NOT_PUBLISHED_TO_WORKSPACE,
                details=f"The agent profile {agent_profile.name} is not published to the workspace.",
            )

        # 3rd. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 4th. Check the agent cache store
        if self._agent_cache is None:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Agent cache is not initialized",
            )

        # 5th. Build agent wrapper from spec or cached wrapper
        # NOTE : workspace agent should use its own checkpointer and store
        # although it has another checkpointer and store in the profile
        effective_checkpointer = self._checkpointer
        effective_store = self._store

        _wrapper_cache_key = agent_wrapper_cache_key(profile_id)
        _cached_wrapper = await self._agent_cache.get(_wrapper_cache_key)
        latest_agent_profile = await self.get_latest_agent_profile_from_history(
            id=agent_profile.id
        )
        current_wrapper = None
        _wrapper_updated = False
        if _cached_wrapper:
            # if the cached wrapper's version is not equal to the latest agent profile's version,
            # it means the agent profile has been updated, so we need to create a new agent wrapper
            # using the latest agent profile
            if _cached_wrapper.agent_spec.version != latest_agent_profile.version:
                current_wrapper = await self.create_agent_wrapper_based_on_profile(
                    agent_profile=latest_agent_profile,
                    checkpointer=effective_checkpointer,
                    store=effective_store,
                )
                # Cache the new wrapper
                await self._agent_cache.delete(_wrapper_cache_key)
                await self._agent_cache.put(_wrapper_cache_key, current_wrapper)
                _wrapper_updated = True
            else:
                current_wrapper = _cached_wrapper
        else:
            current_wrapper = await self.create_agent_wrapper_based_on_profile(
                agent_profile=latest_agent_profile,
                checkpointer=effective_checkpointer,
                store=effective_store,
            )
            # Cache the new wrapper
            await self._agent_cache.put(_wrapper_cache_key, current_wrapper)

        # 6th. Check MCP authentication for specific user
        (
            need_auth,
            pending_auth,
            mcp_server_configs,
        ) = await current_wrapper.need_mcp_authentication(user.id)

        # 6. Get all MCP server nodes from agent profile
        profile_mcp_nodes = latest_agent_profile.get_all_mcp_server_nodes()
        # validate mcp nodes size with mcp server configs
        if len(profile_mcp_nodes) != len(mcp_server_configs):
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server configs and profile MCP nodes do not match: {len(profile_mcp_nodes)} != {len(mcp_server_configs)}",
            )

        # 7. Build the agent graph from cache or current wrapper (always build regardless of auth status)
        _agent_cache_key = agent_cache_key(profile_id)
        _cached_entry: CachedAgent | None = await self._agent_cache.get(
            _agent_cache_key
        )
        current_agent = None
        if _cached_entry and not _wrapper_updated and not need_auth:
            current_agent = _cached_entry.graph
        else:
            # Invalidate stale agent cache only if wrapper was updated
            # NOTE: Do not delete cache on need_auth — another user's cached agent should remain
            if _cached_entry and _wrapper_updated:
                await self._agent_cache.delete(_agent_cache_key)

            current_agent = await current_wrapper.build_agent(user.id)

            # Cache the agent only when all MCP servers are authenticated
            if not need_auth:
                await self._agent_cache.put(
                    _agent_cache_key,
                    CachedAgent(
                        graph=current_agent,
                        mcp_server_configs=mcp_server_configs,
                    ),
                )
                logger.info(
                    "Cached the workspace agent for agent profile %s",
                    agent_profile.id,
                )
                logger.info("Cache stats: %s", await self._agent_cache.get_stats())

        # 8. Get MCP servers for response
        mcp_servers: list[McpServer] = []
        for pmcp in profile_mcp_nodes:
            (
                server_id,
                mcp_need_auth,
                mcp_auth_url,
            ) = await self._need_auth_to_mcp_server(
                mcp_connection=pmcp.data.mcp_config_json.mcpServers,
                pending_auth=pending_auth,
            )

            _effective_mcp_config = await self._get_mcp_server_config(
                server_id=server_id,
                mcp_server_configs=mcp_server_configs,
            )
            if _effective_mcp_config is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"MCP server {server_id} not found in mcp_server_configs",
                )

            _connected = (
                not mcp_need_auth and _effective_mcp_config.error_message is None
            )

            mcp_servers.append(
                McpServer(
                    server_id=server_id,
                    server_name=pmcp.data.name,
                    is_oauth_server=_effective_mcp_config.is_oauth_server,
                    connected=_connected,
                    tools=await current_wrapper.get_mcp_server_tools(server_id),
                    registry_id=pmcp.data.registry_id,
                    resource_type=pmcp.data.resource_type,
                    transport_type=pmcp.data.transport_type,
                    icon_url=pmcp.data.icon_url,
                    auth_url=mcp_auth_url,
                    error_message=_effective_mcp_config.error_message,
                )
            )

        return latest_agent_profile, mcp_servers, current_agent, need_auth

    async def _get_mcp_server_config(
        self, server_id: str, mcp_server_configs: list[MCPServerConfig]
    ) -> MCPServerConfig | None:
        """Get MCP server config."""
        for mcp_config in mcp_server_configs:
            if mcp_config.server_id == server_id:
                return mcp_config
        return None

    async def _need_auth_to_mcp_server(
        self, mcp_connection: dict[str, Any], pending_auth: list[NeedAuthMCPServer]
    ) -> tuple[str, bool, str | None]:
        """Check if the MCP server is connected.

        Returns:
            Tuple of (server_id, need_auth, auth_url)
        """
        if not mcp_connection:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"The MCP server doesn't have {MCP_SERVER_CONFIG_KEY} key",
            )

        server_id = next(iter(mcp_connection))
        for auth in pending_auth:
            if auth.server_id == server_id:
                return server_id, True, auth.auth_url

        return server_id, False, None

    async def _get_mcp_server_id(self, mcp_connection: dict[str, Any]) -> str:
        """Get MCP server id."""
        if not mcp_connection:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"The MCP server doesn't have {MCP_SERVER_CONFIG_KEY} key",
            )

        server_id = next(iter(mcp_connection))
        if not server_id:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="The MCP server doesn't have server id",
            )

        return server_id

    async def validate_agent_initialized(
        self,
        profile_id: str,
        iss: str,
        sub: str,
        is_playground: bool,
    ) -> tuple[AgentProfile | None, list[McpServer], CompiledStateGraph, bool]:
        """Validate that an agent is cached, auto-recreating on cache miss.

        Acts as the "ensure agent exists" gate. On cache miss, transparently
        rebuilds the agent via create_playground_agent or create_workspace_agent
        so that subsequent calls to stream/resume/cancel/get_messages find it
        in local cache.

        Returns:
            Tuple of (agent_profile, mcp_servers, compiled_agent, need_auth).
            - Cache hit: (None, [], cached_agent, False)
            - Cache miss + success: (profile, mcp_servers, compiled_agent, False)
            - Cache miss + MCP auth needed: (profile, mcp_servers, None, True)
        """
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {e}",
            )

        if self._agent_cache is None:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Cache not found in the server",
            )

        cached = await self._get_cached_agent(
            profile_id=profile_id,
            user_id=user.id,
            is_playground=is_playground,
        )
        if cached is not None:
            # Check if any OAuth MCP servers lost their tokens (e.g. after disconnect)
            if cached.mcp_server_configs:
                pending = await self._mcp_client_factory.get_pending_auth_servers(
                    user_id=user.id, servers=cached.mcp_server_configs
                )
                if pending:
                    logger.info(
                        "Cached agent for profile %s has %d pending OAuth "
                        "server(s) for user %s, forcing rebuild.",
                        profile_id,
                        len(pending),
                        user.id,
                    )
                    # Fall through to rebuild path below
                else:
                    return None, [], cached.graph, False
            else:
                return None, [], cached.graph, False

        # Cache miss or token validation failed — auto-recreate the agent on this instance
        logger.info(
            "Agent cache miss for profile %s, user %s (playground=%s). "
            "Auto-recreating agent on this instance.",
            profile_id,
            user.id,
            is_playground,
        )

        if is_playground:
            return await self.create_playground_agent(
                profile_id=profile_id,
                iss=iss,
                sub=sub,
            )
        else:
            return await self.create_workspace_agent(
                profile_id=profile_id,
                iss=iss,
                sub=sub,
            )

    async def stream_agent_completion(
        self,
        *,
        profile_id: str,
        thread_id: str,
        iss: str,
        sub: str,
        prompt: str,
        is_playground: bool,
        llm_model: str | None = None,
        files: list[str] | None = None,
    ) -> AsyncGenerator[ServerSentEvent, None]:
        """Stream agent completion as SSE events.

        You should validate the agent initialized before calling this method.
        ```python
        await agent_service.validate_agent_initialized(
            profile_id=profile_id,
            iss=oauth_user.iss,
            sub=oauth_user.sub,
            is_playground=True,
        )
        ```
        Args:
            profile_id: Agent profile ID.
            thread_id: Conversation thread ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            prompt: User prompt text.
            is_playground: Whether the agent is playground agent.
            llm_model: LLM model override (e.g. "openai/gpt-4.1-mini").
            files: List of file IDs for multimodal messages.

        Returns:
            Async generator of ServerSentEvent.

        Raises:
            CoreServiceException: If cached agent not found.
        """
        # 0. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 1. Retrieve cached agent
        _cached = await self._get_cached_agent(
            profile_id=profile_id, user_id=user.id, is_playground=is_playground
        )

        if _cached is None:
            raise CoreServiceException(
                CoreError.AGENT_NOT_FOUND,
                details=f"Playground agent not found in cache for profile: {profile_id} and user: {user.id}",
            )
        cached_agent = _cached.graph

        # 2. Resolve LLM model
        effective_model = llm_model or core_settings.default_model

        # 3. Build RunnableConfig
        config = self._build_runnable_config(
            thread_id=thread_id,
            user_id=user.id,
            # llm_model=effective_model,
        )

        # 4. Build inputs
        chat_files = []
        if files:
            chat_files = await self._get_chat_files(files)
        messages = generate_multimodal_messages(chat_files, prompt, effective_model)
        inputs = {"messages": [HumanMessage(content=messages)]}

        # 5. Clear any stale cancel flag before streaming
        await self._clear_cancel_flag(thread_id)

        # 6. Stream SSE events
        async for event in stream_agent_events(
            agent=cached_agent,
            thread_id=thread_id,
            # llm_model=effective_model,
            inputs=inputs,
            config=config,
            cancel_check=lambda: self._check_cancel_flag(thread_id),
        ):
            yield event

        # 7. Clean up cancel flag after streaming
        await self._clear_cancel_flag(thread_id)

    async def resume_agent_completion(
        self,
        *,
        profile_id: str,
        thread_id: str,
        iss: str,
        sub: str,
        decisions: list[dict[str, Any]],
        is_playground: bool,
        llm_model: str | None = None,
    ) -> AsyncGenerator[ServerSentEvent, None]:
        """Resume an interrupted agent with HITL decisions.

        You should validate the agent initialized before calling this method.
        ```python
        await agent_service.validate_agent_initialized(
            profile_id=profile_id,
            iss=oauth_user.iss,
            sub=oauth_user.sub,
            is_playground=True,
        )
        ```
        Args:
            profile_id: Agent profile ID.
            thread_id: Conversation thread ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            decisions: List of HITL decisions (approve/edit/reject).
            is_playground: Whether the agent is playground agent.
            llm_model: LLM model override.

        Returns:
            Async generator of ServerSentEvent.

        Raises:
            CoreServiceException: If cached agent not found or no conversation state.
        """
        # 0. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 1. Retrieve cached agent
        _cached = await self._get_cached_agent(
            profile_id=profile_id, user_id=user.id, is_playground=is_playground
        )

        if _cached is None:
            raise CoreServiceException(
                CoreError.AGENT_NOT_FOUND,
                details=f"Playground agent not found in cache for profile: {profile_id} and user: {user.id}",
            )
        cached_agent = _cached.graph

        # 2. Resolve LLM model
        # effective_model = llm_model or core_settings.default_model

        # 3. Build config
        config = self._build_runnable_config(
            thread_id=thread_id,
            user_id=user.id,
            # llm_model=effective_model,
        )

        # 4. Validate conversation state exists
        state = await cached_agent.aget_state(config)
        if not state or not state.values:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"No conversation history found for thread: {thread_id}",
            )

        # 5. Enrich reject decisions with explicit LLM instructions
        # to prevent the LLM from retrying the same tool call in an infinite loop.
        enriched_decisions = []
        for decision in decisions:
            if decision.get("type") == "reject":
                user_message = decision.get("message") or ""
                enriched_message = (
                    f"[REJECTED BY USER] {user_message}\n"
                    "The user has explicitly rejected this tool call. "
                    "Do NOT retry the same tool. "
                    "Respond to the user acknowledging the rejection and suggest alternatives or ask what they'd like to do instead."
                )
                enriched_decisions.append({**decision, "message": enriched_message})
            else:
                enriched_decisions.append(decision)

        # 6. Build Command from decisions
        inputs = Command(resume={"decisions": enriched_decisions})

        # 7. Clear any stale cancel flag before streaming
        await self._clear_cancel_flag(thread_id)

        # 8. Stream SSE events
        async for event in stream_agent_events(
            agent=cached_agent,
            thread_id=thread_id,
            # llm_model=effective_model,
            inputs=inputs,
            config=config,
            cancel_check=lambda: self._check_cancel_flag(thread_id),
        ):
            yield event

        # 9. Clean up cancel flag after streaming
        await self._clear_cancel_flag(thread_id)

    async def cancel_agent_completion(
        self,
        *,
        profile_id: str,
        thread_id: str,
        iss: str,
        sub: str,
        is_playground: bool,
    ) -> dict[str, Any]:
        """Cancel an active agent conversation via Redis cancel flag.

        Sets a Redis-based cancellation signal that the streaming loop checks
        periodically. Works across Kubernetes pods.

        Args:
            profile_id: Agent profile ID.
            thread_id: Conversation thread ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            is_playground: Whether the agent is a playground agent.

        Returns:
            Dict with ``messages`` (list of message dicts) and ``created_at``.

        Raises:
            CoreServiceException: If user, agent, or conversation not found.
        """
        # 1. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 2. Retrieve cached agent
        _cached = await self._get_cached_agent(
            profile_id=profile_id, user_id=user.id, is_playground=is_playground
        )

        if _cached is None:
            raise CoreServiceException(
                CoreError.AGENT_NOT_FOUND,
                details=f"Agent not found in cache for profile: {profile_id} and user: {user.id}",
            )
        cached_agent = _cached.graph

        # 3. Build config
        config = self._build_runnable_config(
            thread_id=thread_id,
            user_id=user.id,
        )

        try:
            # 4. Set Redis cancel flag so the streaming loop detects it
            await self._set_cancel_flag(thread_id)
            logger.info("Cancel flag set for thread: %s", thread_id)

            # 5. Get current state
            state = await cached_agent.aget_state(config)

            if state is None:
                return {"messages": [], "created_at": None}

            if "messages" not in state.values or len(state.values["messages"]) == 0:
                return {"messages": [], "created_at": state.created_at}

            return {
                "messages": messages_to_dict(state.values["messages"]),
                "created_at": state.created_at,
            }

        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(
                "Error cancelling conversation for thread %s: %s", thread_id, str(e)
            )
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to cancel conversation: {str(e)}",
            )

    async def get_conversation_messages_by_thread_id(
        self,
        *,
        profile_id: str,
        thread_id: str,
        iss: str,
        sub: str,
        is_playground: bool,
    ) -> dict[str, Any]:
        """Get conversation messages by thread ID.

        Args:
            profile_id: Agent profile ID.
            thread_id: Conversation thread ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            is_playground: Whether the agent is a playground agent.

        Returns:
            Dict with ``messages`` (list of message dicts) and ``created_at``.

        Raises:
            CoreServiceException: If user, agent, or conversation not found.
        """
        # 1. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 2. Retrieve cached agent
        _cached = await self._get_cached_agent(
            profile_id=profile_id, user_id=user.id, is_playground=is_playground
        )

        if _cached is None:
            raise CoreServiceException(
                CoreError.AGENT_NOT_FOUND,
                details=f"Agent({profile_id}) not found in cache",
            )
        cached_agent = _cached.graph

        # 3. Build config
        config = self._build_runnable_config(
            thread_id=thread_id,
            user_id=user.id,
        )

        # 4. Get current state
        state = await cached_agent.aget_state(config)

        if (
            state is None
            or "messages" not in state.values
            or len(state.values["messages"]) == 0
        ):
            raise CoreServiceException(
                CoreError.MESSAGE_NOT_FOUND,
                details=f"the thread id is {thread_id}",
            )

        return {
            "messages": messages_to_dict(state.values["messages"]),
            "created_at": state.created_at,
        }

    async def get_conversation_messages_by_thread_id_and_agent(
        self,
        *,
        agent: CompiledStateGraph,
        thread_id: str,
        iss: str,
        sub: str,
    ) -> dict[str, Any]:
        """Get conversation messages by thread ID.

        Args:
            agent: CompiledStateGraph.
            thread_id: Conversation thread ID.
            iss: OIDC issuer.
            sub: OIDC subject.

        Returns:
            Dict with ``messages`` (list of message dicts) and ``created_at``.

        Raises:
            CoreServiceException: If user, agent, or conversation not found.
        """
        # 1. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 3. Build config
        config = self._build_runnable_config(
            thread_id=thread_id,
            user_id=user.id,
        )

        # 4. Get current state
        state = await agent.aget_state(config)

        if (
            state is None
            or "messages" not in state.values
            or len(state.values["messages"]) == 0
        ):
            raise CoreServiceException(
                CoreError.MESSAGE_NOT_FOUND,
                details=f"the thread id is {thread_id}",
            )

        return {
            "messages": messages_to_dict(state.values["messages"]),
            "created_at": state.created_at,
        }

    async def _get_cached_agent(
        self, profile_id: str, user_id: str, is_playground: bool
    ) -> CachedAgent | None:
        """Retrieve a cached agent by profile ID and username.

        Return a ``CachedAgent`` wrapping the compiled graph and its MCP
        server configs so callers can validate OAuth token status on cache
        hits.  Legacy raw ``CompiledStateGraph`` entries (from before this
        change) are transparently wrapped with an empty config list.
        """
        cache_key = None
        if is_playground:
            cache_key = agent_playground_agent_cache_key(
                profile_id=profile_id, username=user_id
            )
        else:
            cache_key = agent_cache_key(profile_id)

        cached = None
        if self._agent_cache is not None:
            cached = await self._agent_cache.get(cache_key)

        if cached is None:
            logger.warning(
                "Agent not found for profile: %s and user: %s in the cache",
                profile_id,
                user_id,
            )
            return None

        return cached

    def _build_runnable_config(
        self,
        *,
        thread_id: str,
        user_id: str,
        llm_model: str | None = None,
    ) -> dict[str, Any]:
        """Build a RunnableConfig dict for agent execution."""
        return {
            "configurable": {
                "thread_id": thread_id,
                "user_id": user_id,
                # "model": llm_model,  # TODO: check the model changing is supported or not from the deepagent
            },
            "recursion_limit": core_settings.recursion_limit,
        }

    async def _get_chat_files(self, file_ids: list[str]) -> list[AgentChatFile]:
        """Fetch chat files and convert to agent ChatFile format.

        Args:
            file_ids: List of file IDs to fetch.

        Returns:
            List of AgentChatFile for multimodal message generation.
        """
        chat_files = []
        for file_id in file_ids:
            if not file_id:
                continue
            try:
                entity = await self._chat_file_repository.find_by_id(item_id=file_id)
                chat_files.append(
                    AgentChatFile(
                        upload_url=entity.upload_url,
                        file_name=entity.file_name,
                        mime_type=entity.mime_type,
                        project_id=entity.project_id,
                    )
                )
            except Exception as e:
                logger.warning("Failed to fetch chat file %s: %s", file_id, e)
        return chat_files

    @deprecated("Use DeepAgentProfile.get_node_by_type() instead.")
    async def get_agent_profile_node_by_type(
        self, nodes: list[DeepAgentProfileNode], node_type: NodeType
    ) -> DeepAgentProfileNode:
        """Get the agent profile node by the node type.

        .. deprecated::
            Use :meth:`DeepAgentProfile.get_node_by_type` instead.
        """
        if node_type == NodeType.MCP_SERVER:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server node is not supported: {node_type}",
            )

        for node in nodes:
            if node.node_type == node_type:
                return node

        raise CoreServiceException(
            CoreError.BAD_REQUEST,
            details=f"Agent profile node is not found: {node_type}",
        )

    async def get_llm_models(self, provider_id: str) -> list[LlmModel]:
        """Get the LLM models by the provider id."""
        try:
            llm_provider = await self._llm_provider_repository.find_by_id(
                item_id=provider_id
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid provider ID format: {provider_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Provider not found: {provider_id}",
            )
        return llm_provider.models if llm_provider.models is not None else []

    async def delete_agent_profile_history_by_id(self, *, history_id: str) -> bool:
        """Delete a single agent profile history by history ID."""
        try:
            # Check if agent profile history exists
            await self._agent_profile_history_repository.find_by_id(item_id=history_id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Agent profile history not found: {history_id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid agent profile history ID format: {history_id}",
            )

        return await self._agent_profile_history_repository.delete(item_id=history_id)

    async def _generate_sequential_agent_profile_version(
        self, agent_profile_id: str | None = None
    ) -> int:
        """Generate next version for agent profile in v1, v2, v3 format."""
        # If agent_profile_id is empty or None, treat as no existing versions
        if agent_profile_id is None:
            return 1
        return await generate_next_version(
            lambda: self._agent_profile_history_repository.get_max_version(
                agent_profile_id=agent_profile_id
            )
        )

    # TODO: Convert to simplified response
    async def get_provision_statuses_by_profile_id(
        self, *, profile_id: str
    ) -> list[AgentProvisionStatus]:
        """Get all agent provision statuses by profile ID with simplified response."""
        provisions = (
            await self._agent_provision_status_repository.find_all_without_pagination(
                query_parameters=AgentProfileProvisionStatusQueryParameters(
                    profile_id=profile_id,
                    profile_version=None,
                    cluster_id=None,
                )
            )
        )

        return provisions
