"""MCP Server Profile service."""

from __future__ import annotations

import json
import logging
import os
import tempfile
from datetime import UTC, datetime, timedelta
from typing import Any, AsyncGenerator

from axmp_openapi_helper import (
    APIServerConfig,
    AuthConfig,
    AuthenticationType,
    MultiOpenAPISpecConfig,
    RouteMap,
    ToolConfig,
)
from axmp_openapi_helper.openapi.axmp_api_models import AxmpOpenAPI
from axmp_openapi_helper.utils.converter import Converter
from langchain_core.messages import HumanMessage
from langchain_core.prompts import load_prompt
from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import StdioConnection
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph.state import CompiledStateGraph
from motor.motor_asyncio import AsyncIOMotorClient
from sse_starlette.sse import ServerSentEvent

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig, NeedAuthMCPServer
from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.clients.factory import UserMCPClientFactory
from axmp_ai_agent_core.agent.playground.mcp_server_playground_agent_profile import (
    build_playground_spec_profile,
)
from axmp_ai_agent_core.agent.spec.profile_node_data import LLMSpecData
from axmp_ai_agent_core.agent.spec.types import ProfileStatus
from axmp_ai_agent_core.agent.streaming.sse_generator import stream_agent_events
from axmp_ai_agent_core.agent.util.agent_cache import AsyncTTLQueue
from axmp_ai_agent_core.agent.util.agent_cache_key_format import (
    mcp_playground_agent_cache_key,
)
from axmp_ai_agent_core.agent.util.chat_file_utils import (
    ChatFile as AgentChatFile,
)
from axmp_ai_agent_core.agent.util.chat_file_utils import (
    generate_multimodal_messages,
)
from axmp_ai_agent_core.agent.util.mcp_client_manager import McpServer
from axmp_ai_agent_core.agent.wrapper.single_agent_wrapper import SingleAgentWrapper
from axmp_ai_agent_core.db.backend_server_repository import BackendServerRepository
from axmp_ai_agent_core.db.chat_file_repository import ChatFileRepository
from axmp_ai_agent_core.db.llm_provider_repository import LlmProviderRepository
from axmp_ai_agent_core.db.mcp_server_profile_history_repository import (
    McpServerProfileHistoryRepository,
)
from axmp_ai_agent_core.db.mcp_server_profile_repository import (
    McpServerProfileRepository,
)
from axmp_ai_agent_core.db.mcp_server_provision_status_repository import (
    McpServerProvisionStatusRepository,
)
from axmp_ai_agent_core.db.user_credential_repository import UserCredentialRepository
from axmp_ai_agent_core.db.user_repository import UserRepository
from axmp_ai_agent_core.entity.backend_server import (
    BackendServer,
)
from axmp_ai_agent_core.entity.mcp_server_auth_config import (
    McpServerAuthConfig,
    McpServerAuthorizationConfig,
    McpServerBackendServerAuthConfig,
)
from axmp_ai_agent_core.entity.mcp_server_profile import (
    McpServerProfile,
    McpServerProfileNodeType,
)
from axmp_ai_agent_core.entity.mcp_server_profile_history import (
    McpServerProfileHistory,
)
from axmp_ai_agent_core.entity.mcp_server_provision_status import (
    McpServerConfigs,
    McpServerProvisionStatus,
)
from axmp_ai_agent_core.entity.shared_target import SharedTarget
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.mcp_server_profile_history_query import (
    McpServerProfileHistoryQueryParameters,
)
from axmp_ai_agent_core.filter.mcp_server_profile_query import (
    McpServerProfileQueryParameters,
)
from axmp_ai_agent_core.filter.mcp_server_provision_status_query import (
    McpServerProvisionStatusQueryParameters,
)
from axmp_ai_agent_core.setting import core_settings
from axmp_ai_agent_core.util.auth_utils import create_auth_config_from_backend_server
from axmp_ai_agent_core.util.prompt_manager import PromptFile, get_prompt_path
from axmp_ai_agent_core.util.version_utils import generate_next_version

logger = logging.getLogger(__name__)


class McpServerService:
    """MCP Server Profile service."""

    def __init__(
        self,
        client: AsyncIOMotorClient,
        mcp_server_profile_repository: McpServerProfileRepository,
        backend_server_repository: BackendServerRepository,
        mcp_server_profile_history_repository: McpServerProfileHistoryRepository,
        mcp_server_provision_status_repository: McpServerProvisionStatusRepository,
        user_repository: UserRepository,
        llm_provider_repository: LlmProviderRepository,
        user_credential_repository: UserCredentialRepository,
        chat_file_repository: ChatFileRepository,
        agent_cache: AsyncTTLQueue,
        oauth_mcp_server_registry: OAuthMCPServerRegistry | None = None,
        mcp_client_factory: UserMCPClientFactory | None = None,
    ):
        """Initialize the MCP server service."""
        self._client = client
        self._mcp_server_profile_repository = mcp_server_profile_repository
        self._backend_server_repository = backend_server_repository
        self._mcp_server_profile_history_repository = (
            mcp_server_profile_history_repository
        )
        self._mcp_server_provision_status_repository = (
            mcp_server_provision_status_repository
        )
        self._user_repository = user_repository
        self._llm_provider_repository = llm_provider_repository
        self._user_credential_repository = user_credential_repository
        self._chat_file_repository = chat_file_repository
        self._agent_cache = agent_cache
        self._oauth_mcp_server_registry = oauth_mcp_server_registry
        self._mcp_client_factory = mcp_client_factory

    async def get_profiles(
        self,
        *,
        query_params: McpServerProfileQueryParameters,
        page_number: int,
        page_size: int,
    ) -> list[McpServerProfile]:
        """Get MCP server profiles with pagination."""
        try:
            return await self._mcp_server_profile_repository.find_all(
                query_parameters=query_params,
                page_number=page_number,
                page_size=page_size,
            )
        except Exception as e:
            logger.error(f"Error getting MCP server profiles: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP server profiles: {e}",
            )

    async def get_internal_profiles(
        self,
        *,
        query_parameters: McpServerProfileQueryParameters,
    ) -> list[McpServerProfile]:
        """Get internal MCP server profiles ."""
        try:
            mcp_server_profiles = await self._mcp_server_profile_repository.find_all(
                query_parameters=query_parameters,
                include_fields=["id", "name", "icon_url"],
            )
            return mcp_server_profiles
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP server profiles : {e}",
            )

    async def get_authorization_config_by_profile_id(
        self, *, profile_id: str
    ) -> McpServerAuthorizationConfig:
        """Get authorization config by profile ID."""
        mcp_server_profile = await self._mcp_server_profile_repository.find_by_id(
            item_id=profile_id
        )

        return await self._get_authorization_config_from_mcp_server_profile(
            mcp_server_profile=mcp_server_profile
        )

    async def get_authorization_config_by_profile_id_and_version(
        self, *, profile_id: str, version: int
    ) -> McpServerAuthorizationConfig:
        """Get authorization config by profile ID and version."""
        # 1st, get profile history
        try:
            profile_history = await self._mcp_server_profile_history_repository.find_by_profile_id_and_version(
                profile_id=profile_id, version=version
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile history not found: {profile_id}:{version}",
            )

        # 2nd, generate mcp-server-profile with profile_history.mcp_server_profile_data
        if isinstance(profile_history.mcp_server_profile_data, McpServerProfile):
            mcp_server_profile = profile_history.mcp_server_profile_data
        else:
            mcp_server_profile = McpServerProfile(
                **profile_history.mcp_server_profile_data
            )

        return await self._get_authorization_config_from_mcp_server_profile(
            mcp_server_profile=mcp_server_profile
        )

    async def _get_authorization_config_from_mcp_server_profile(
        self, *, mcp_server_profile: McpServerProfile
    ) -> McpServerAuthorizationConfig:
        """Get authorization config from mcp-server-profile."""
        if mcp_server_profile.flow is None:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"MCP server profile's flow is not found: {mcp_server_profile.id}",
            )

        # Find root MCP-Server node and get auth_config from node.data
        mcp_server_auth_config: McpServerAuthConfig | None = None

        for node in mcp_server_profile.flow.nodes:
            if node.node_type == McpServerProfileNodeType.MCP_SERVER and node.root_node:
                if node.data is None or node.data.auth_config is None:
                    raise CoreServiceException(
                        CoreError.ID_NOT_FOUND,
                        details=f"MCP server auth config is not found: {mcp_server_profile.id}",
                    )
                mcp_server_auth_config = McpServerAuthConfig(
                    profile_id=mcp_server_profile.id,
                    auth_config=node.data.auth_config,
                )
                break

        if mcp_server_auth_config is None:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server root node is not found: {mcp_server_profile.id}",
            )

        backend_server_auth_configs: list[McpServerBackendServerAuthConfig] = []

        for node in mcp_server_profile.flow.nodes:
            if node.node_type == McpServerProfileNodeType.BACKEND_SERVER:
                if node.data.backend_server_id is None:
                    raise CoreServiceException(
                        CoreError.ID_NOT_FOUND,
                        details=f"Backend server ID is not found: {node.data.name}",
                    )

                try:
                    backend_server = await self._backend_server_repository.find_by_id(
                        item_id=node.data.backend_server_id
                    )
                except ObjectNotFoundException:
                    raise CoreServiceException(
                        CoreError.ID_NOT_FOUND,
                        details=f"Backend server not found: {node.data.backend_server_id}",
                    )
                except InvalidObjectIDException:
                    raise CoreServiceException(
                        CoreError.INVALID_OBJECTID,
                        details=f"Invalid object ID: {node.data.backend_server_id}",
                    )

                auth_config = create_auth_config_from_backend_server(backend_server)

                backend_server_auth_configs.append(
                    McpServerBackendServerAuthConfig(
                        server_id=backend_server.id,
                        server_name=backend_server.name,
                        server_system_name=backend_server.system_name,
                        auth_config=auth_config,
                    )
                )

        return McpServerAuthorizationConfig(
            mcp_server_auth_config=mcp_server_auth_config,
            backend_server_auth_configs=backend_server_auth_configs,
        )

    async def get_profiles_for_list(
        self,
        *,
        query_params: McpServerProfileQueryParameters,
        page_number: int,
        page_size: int,
    ) -> list[McpServerProfile]:
        """Get MCP server profiles for list view (excluding flow)."""
        try:
            profiles = await self._mcp_server_profile_repository.find_all(
                query_parameters=query_params,
                page_number=page_number,
                page_size=page_size,
            )

            return profiles
        except Exception as e:
            logger.error(f"Error getting MCP server profiles for list: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP server profiles for list: {e}",
            )

    async def get_profile_by_id(
        self, *, profile_id: str, is_get_tool_count: bool = False
    ) -> McpServerProfile:
        """Get an MCP server profile by ID."""
        try:
            profile = await self._mcp_server_profile_repository.find_by_id(
                item_id=profile_id
            )
            if is_get_tool_count:
                await self.update_tool_counts(profile=profile)
            return profile
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile not found: {profile_id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {profile_id}",
            )
        except Exception as e:
            logger.error(f"Error getting MCP server profile by ID {profile_id}: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP server profile: {e}",
            )

    async def _generate_sequential_mcp_profile_version(
        self, mcp_server_profile_id: str | None = None
    ) -> int:
        """Generate next version for MCP server profile in v1, v2, v3 format."""
        if mcp_server_profile_id is None:
            return 1
        return await generate_next_version(
            lambda: self._mcp_server_profile_history_repository.get_max_version(
                mcp_server_profile_id=mcp_server_profile_id
            )
        )

    async def _save_profile_history(
        self,
        *,
        profile_id: str,
        profile_data: McpServerProfile,
        comment: str,
        created_by: str,
        version: int | None = None,
    ) -> None:
        """Save profile to history."""
        try:
            if version is None:
                version = await self._generate_sequential_mcp_profile_version(
                    profile_id
                )

            profile_data_dict = profile_data.model_dump()

            profile_data_dict["id"] = profile_id

            history_entry = McpServerProfileHistory(
                mcp_server_profile_id=profile_id,
                version=version,
                comment=comment,
                mcp_server_profile_data=profile_data_dict,
                created_by=created_by or "system",
            )

            # Get all provisioned versions to protect from deletion
            provisioned_versions = await self._mcp_server_provision_status_repository.get_provisioned_versions_by_profile_id(
                profile_id=profile_id
            )

            # Retention policy: keep only the latest 50 versions
            await self._mcp_server_profile_history_repository.delete_oldest_versions(
                profile_id=profile_id,
                keep_count=50,
                provisioned_versions=provisioned_versions,
            )

            logger.info(
                f"Retention policy applied: deleted oldest versions, keeping latest 50 for profile {profile_id}"
            )

            history_id = await self._mcp_server_profile_history_repository.insert(
                item=history_entry
            )
            logger.info(
                f"Saved profile history for profile {profile_id} at {history_entry.version}, history_id: {history_id}"
            )
        except Exception as history_error:
            logger.warning(f"Failed to save profile history: {history_error}")

    async def _check_duplicate_name(self, *, name: str) -> None:
        """Check duplicate name."""
        logger.info(f"Checking duplicate name: '{name}'")

        if not name or name.strip() == "":
            logger.warning("Name is None or empty, skipping duplicate check")
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="Profile name is required (from MCP-Server node data)",
            )

        existing_profiles_by_name = (
            await self._mcp_server_profile_repository.find_by_name(name=name)
        )

        if existing_profiles_by_name:
            logger.error(
                f"MCP profile with name '{name}' already exists (id={existing_profiles_by_name.id})"
            )
            raise CoreServiceException(
                CoreError.DUPLICATE_FOUND,
                details=f"MCP server profile with name '{name}' already exists",
            )

        logger.info(f"No duplicate found for name '{name}'")

    async def _check_duplicate_system_name(self, *, system_name: str) -> None:
        """Check duplicate system_name."""
        logger.info(f"Checking duplicate system_name: '{system_name}'")

        if not system_name or system_name.strip() == "":
            logger.warning("System name is None or empty, skipping duplicate check")
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details="Profile system_name is required (from MCP-Server node data)",
            )

        existing_profiles_by_system_name = (
            await self._mcp_server_profile_repository.find_by_system_name(
                system_name=system_name
            )
        )

        if existing_profiles_by_system_name:
            logger.error(
                f"MCP profile with system_name '{system_name}' already exists (id={existing_profiles_by_system_name.id})"
            )
            raise CoreServiceException(
                CoreError.DUPLICATE_FOUND,
                details=f"MCP server profile with system_name '{system_name}' already exists",
            )

        logger.info(f"No duplicate found for system_name '{system_name}'")

    async def _validate_backend_server_references(
        self, *, profile: McpServerProfile
    ) -> None:
        """Validate that all referenced backend servers in the profile exist in the database and update backend_count."""
        logger.info(
            "Validating backend server references and updating backend count..."
        )

        if not profile.flow or not profile.flow.nodes:
            logger.warning("No flow or nodes to validate")
            return

        backend_server_nodes = [
            node
            for node in profile.flow.nodes
            if node.node_type == McpServerProfileNodeType.BACKEND_SERVER
        ]

        # Validate each backend server reference
        for node in backend_server_nodes:
            if not node.data:
                logger.error(f"Backend-Server node {node.id} is missing data")
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Backend-Server node {node.id} is missing data",
                )

            backend_server_id = getattr(node.data, "backend_server_id", None)
            if not backend_server_id:
                logger.error(
                    f"Backend-Server node {node.id} is missing backend_server_id"
                )
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"Backend-Server node {node.id} is missing backend_server_id",
                )

            try:
                # Check if the backend server exists in the database
                await self._backend_server_repository.find_by_id(
                    item_id=backend_server_id
                )
                logger.debug(f"Backend server {backend_server_id} exists and is valid")
            except ObjectNotFoundException:
                logger.error(
                    f"Referenced backend server {backend_server_id} not found in database"
                )
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Backend server referenced in node {node.id} does not exist: {backend_server_id}",
                )
            except Exception as e:
                logger.error(
                    f"Error validating backend server {backend_server_id}: {e}"
                )
                raise CoreServiceException(
                    CoreError.INTERNAL_SERVER_ERROR,
                    details=f"Failed to validate backend server {backend_server_id}: {e}",
                )

        logger.info(
            f"Backend server references validation passed for {len(backend_server_nodes)} nodes"
        )
        profile.backend_count = len(backend_server_nodes)

    async def update_tool_counts(self, *, profile: McpServerProfile) -> None:
        """Update tool counts for all backend server nodes and root node."""
        logger.info("Updating tool counts for profile...")

        if not profile.flow or not profile.flow.nodes:
            logger.warning("No flow or nodes to update tool counts")
            return

        total_tool_count = 0

        for node in profile.flow.nodes:
            if node.node_type == McpServerProfileNodeType.MCP_SERVER:
                continue

            if not node.data:
                logger.warning(
                    f"Node {node.id} is missing data, skipping tool count update"
                )
                continue

            backend_server_id = getattr(node.data, "backend_server_id", None)
            if not backend_server_id:
                logger.warning(
                    f"Node {node.id} is missing backend_server_id, skipping tool count update"
                )
                continue

            try:
                data = await self.get_tool_list_for_backend_server(
                    profile=profile, backend_server_id=backend_server_id
                )

                if data:
                    if "tool_count" in data:
                        node_tool_count = data["tool_count"]
                        total_tool_count += node_tool_count
                        node.data.tool_count = node_tool_count
                        logger.debug(
                            f"Updated node {node.id} tool count to {node_tool_count}"
                        )
                    if "api_count" in data:
                        node.data.api_count = data["api_count"]
                        logger.debug(
                            f"Updated node {node.id} api count to {data['api_count']}"
                        )
                else:
                    logger.warning(f"No tool count data for node {node.id}")
                    node.data.tool_count = 0

            except Exception as e:
                logger.error(f"Error updating tool count for node {node.id}: {e}")
                node.data.tool_count = 0

        # Update profile tool count
        profile.tool_count = total_tool_count
        logger.info(f"Tool count update completed. Total tools: {total_tool_count}")

    async def upsert_profile(self, *, profile: McpServerProfile) -> McpServerProfile:
        """Create or update MCP server profile based on ID presence."""
        try:
            is_update = profile.id is not None

            await self._validate_backend_server_references(profile=profile)
            profile.status = ProfileStatus.DRAFT
            await self.update_tool_counts(profile=profile)
            profile_id = None
            if is_update:
                existing = await self.get_profile_by_id(profile_id=profile.id)
                if existing.name != profile.name:
                    await self._check_duplicate_name(name=profile.name)
                updated_profile = await self._mcp_server_profile_repository.update(
                    item=profile
                )
                profile_id = updated_profile.id
            else:
                await self._check_duplicate_name(name=profile.name)
                await self._check_duplicate_system_name(system_name=profile.system_name)
                profile_id = await self._mcp_server_profile_repository.insert(
                    item=profile
                )

            return await self.get_profile_by_id(
                profile_id=profile_id, is_get_tool_count=False
            )

        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile not found: {profile.id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error upserting MCP server profile: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to upsert MCP server profile: {e}",
            )

    async def modify_mcp_server_profile_shared_target(
        self,
        *,
        mcp_server_profile_id: str,
        shared_target: SharedTarget,
        updated_by: str,
    ) -> McpServerProfile:
        """Update only shared_target on an existing profile without touching unique fields."""
        try:
            _ = await self._mcp_server_profile_repository.find_by_id(
                item_id=mcp_server_profile_id
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid MCP server profile ID format: {mcp_server_profile_id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile not found: {mcp_server_profile_id}",
            )

        return await self._mcp_server_profile_repository.update_shared_target(
            item_id=mcp_server_profile_id,
            shared_target=shared_target,
            updated_by=updated_by,
        )

    async def final_save_profile(
        self, *, profile: McpServerProfile, comment: str
    ) -> McpServerProfile:
        """Create or update MCP server profile based on ID presence."""
        try:
            existing = await self.get_profile_by_id(profile_id=profile.id)
            await self._validate_backend_server_references(profile=profile)
            profile.version = await self._generate_sequential_mcp_profile_version(
                profile.id
            )
            profile.status = ProfileStatus.COMPLETED
            await self.update_tool_counts(profile=profile)
            if existing.name != profile.name:
                await self._check_duplicate_name(name=profile.name)
            updated_profile = await self._mcp_server_profile_repository.update(
                item=profile
            )
            # save profile history
            await self._save_profile_history(
                profile_id=profile.id,
                profile_data=profile,
                comment=comment,
                created_by=profile.updated_by,
                version=profile.version,
            )
            profile_id = updated_profile.id

            return await self.get_profile_by_id(
                profile_id=profile_id, is_get_tool_count=False
            )

        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile not found: {profile.id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error upserting MCP server profile: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to upsert MCP server profile: {e}",
            )

    async def get_profile_histories(
        self,
        *,
        query_parameters: McpServerProfileHistoryQueryParameters,
    ) -> list[McpServerProfileHistory]:
        """Get all MCP server profile histories with pagination."""
        try:
            histories_results = await self._mcp_server_profile_history_repository.find_all_without_pagination(
                query_parameters=query_parameters,
                max_limit=0,
            )
            return histories_results
        except Exception as e:
            logger.error(f"Error getting all MCP server profile histories: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get all MCP server profile histories: {e}",
            )

    async def get_profiles_count(
        self, *, query_parameters: McpServerProfileQueryParameters
    ) -> int:
        """Count MCP server profiles."""
        try:
            return await self._mcp_server_profile_repository.count(
                query_parameters=query_parameters
            )
        except Exception as e:
            logger.error(f"Error counting MCP server profiles: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to count MCP server profiles: {e}",
            )

    async def remove_profile_by_id(self, *, profile_id: str) -> bool:
        """Delete an MCP server profile."""
        try:
            await self.get_profile_by_id(profile_id=profile_id)

            provision_statuses = (
                await self._mcp_server_provision_status_repository.find_by_profile_id(
                    profile_id=profile_id
                )
            )
            if provision_statuses:
                instance_names = [ps.name for ps in provision_statuses]
                raise CoreServiceException(
                    CoreError.PROFILE_IN_USE,
                    details=f"MCP server profile '{profile_id}' is in use by instances: {', '.join(instance_names)}",
                )

            return await self._mcp_server_profile_repository.delete(item_id=profile_id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile not found: {profile_id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error deleting MCP server profile: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to delete MCP server profile: {e}",
            )

    async def remove_profile_history_by_profile_id(self, *, profile_id: str) -> int:
        """Delete an MCP server profile history."""
        try:
            await self.get_profile_by_id(profile_id=profile_id)

            return (
                await self._mcp_server_profile_history_repository.delete_by_profile_id(
                    profile_id=profile_id
                )
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile not found: {profile_id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error deleting MCP server profile history: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to delete MCP server profile history: {e}",
            )

    async def create_multi_openapi_spec(
        self,
        *,
        profile_id: str,
        backend_servers: dict[str, BackendServer],
        backend_server_auth_configs: dict[str, AuthConfig],
    ) -> MultiOpenAPISpecConfig:
        """Create multi OpenAPI spec."""
        mcp_server_profile = await self.get_profile_by_id(profile_id=profile_id)
        if mcp_server_profile.flow is None:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile's flow is not found: {profile_id}",
            )
        if mcp_server_profile.flow.nodes is None:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile's nodes are not found: {profile_id}",
            )

        backend_server_tool_configs: dict[str, ToolConfig] = {}
        for node in mcp_server_profile.flow.nodes:
            if node.node_type == McpServerProfileNodeType.BACKEND_SERVER:
                if node.data is None:
                    raise CoreServiceException(
                        CoreError.ID_NOT_FOUND,
                        details=f"Backend server node data is not found: {node.id}",
                    )
                if node.data.tool_config is None:
                    raise CoreServiceException(
                        CoreError.ID_NOT_FOUND,
                        details=f"Backend server node tool config is not found: {node.id}",
                    )
                backend_server_tool_configs[node.data.backend_server_id] = (
                    node.data.tool_config
                )

        api_server_configs: list[APIServerConfig] = []
        for backend_server_id, backend_server in backend_servers.items():
            auth_config = backend_server_auth_configs[backend_server_id]
            tool_config = backend_server_tool_configs[backend_server_id]
            if auth_config is None:
                raise CoreServiceException(
                    CoreError.ID_NOT_FOUND,
                    details=f"Backend server auth config not found: {backend_server_id}",
                )

            api_server_configs.append(
                APIServerConfig(
                    server_name=backend_server.name,
                    endpoint=backend_server.domain,
                    base_path=backend_server.base_path,
                    spec_file_path=f"backend_server_{backend_server_id}.json",
                    tool_config=tool_config,
                    auth_config=auth_config,
                )
            )

        multi_openapi_spec_config = MultiOpenAPISpecConfig(backends=api_server_configs)

        return multi_openapi_spec_config

    async def get_tool_list_for_backend_server(
        self, *, profile: McpServerProfile, backend_server_id: str
    ) -> list[dict] | None:
        """Get tool list for a specific backend server in MCP server profile."""
        logger.info(
            f"Get tool list for backend server {backend_server_id} in profile {profile.id}"
        )

        # Find the backend server node
        backend_server_node = None
        for node in profile.flow.nodes:
            if node.node_type == McpServerProfileNodeType.BACKEND_SERVER:
                if node.data.backend_server_id == backend_server_id:
                    backend_server_node = node
                    break

        if backend_server_node is None:
            return None

        # Get backend server details
        backend_server = await self._backend_server_repository.find_by_id(
            item_id=backend_server_id
        )

        # Extract tool information from the node data
        tools = []
        existing_path_method_combinations = (
            set()
        )  # Track existing path-method combinations

        if (
            backend_server_node.data.tool_config
            and backend_server_node.data.tool_config.api_maps
        ):
            for api_map in backend_server_node.data.tool_config.api_maps:
                for method_spec in api_map.methods:
                    path_method_key = f"{api_map.path}:{method_spec.method}"
                    if path_method_key in existing_path_method_combinations:
                        continue

                    tool = _extract_tools_from_path_method(
                        backend_server=backend_server,
                        path_method=path_method_key,
                    )
                    if not tool:
                        raise CoreServiceException(
                            CoreError.INTERNAL_SERVER_ERROR,
                            details=f"Tool is not found for path: {api_map.path}, method: {method_spec.method} in backend server: {backend_server_id}",
                        )
                    tool_info = {
                        "path": api_map.path,
                        "method": method_spec.method,
                        "tool_name": method_spec.tool_name,
                        "description": method_spec.description,
                        "parameters": tool.get("parameters", {}),
                    }
                    tools.append(tool_info)
                    existing_path_method_combinations.add(path_method_key)

        if (
            backend_server_node.data.tool_config
            and backend_server_node.data.tool_config.route_maps
        ):
            route_map_tools = self._extract_tools_from_route_maps(
                backend_server=backend_server,
                route_maps=backend_server_node.data.tool_config.route_maps,
                existing_path_method_combinations=existing_path_method_combinations,
            )
            tools.extend(route_map_tools)

        data = {
            "backend_server_id": backend_server_id,
            "backend_server_name": backend_server.name,
            "backend_server_system_name": backend_server.system_name,
            "tools": tools,
            "tool_count": len(tools),
            "api_count": backend_server.api_count,
        }

        return data

    async def search_tools_in_backend_server(
        self, *, backend_server_id: str, route_maps: list[RouteMap]
    ) -> list[dict]:
        """Search tools in backend server using tool search request."""
        logger.info(f"Search tools in backend server: {backend_server_id}")

        # Get backend server details
        backend_server = await self._backend_server_repository.find_by_id(
            item_id=backend_server_id
        )

        if not backend_server.swagger_json:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Swagger JSON not found for backend server: {backend_server_id}",
            )

        # Collect all operations from route maps in tool search request
        # Extract tool information from the node data
        tools = []
        existing_path_method_combinations = (
            set()
        )  # Track existing path-method combinations

        tools = self._extract_tools_from_route_maps(
            backend_server=backend_server,
            route_maps=route_maps,
            existing_path_method_combinations=existing_path_method_combinations,
        )

        return tools

    async def get_profile_history_by_id_and_version(
        self,
        *,
        profile_id: str,
        profile_version: int,
    ) -> McpServerProfileHistory:
        """Get MCP server profile history by ID and version."""
        try:
            return await self._mcp_server_profile_history_repository.find_by_profile_id_and_version(
                profile_id=profile_id,
                version=profile_version,
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile history not found: {profile_id}:v{profile_version}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {profile_id}:{profile_version}",
            )

    async def get_openapi_tags(
        self,
        *,
        backend_server_id: str,
    ) -> list[str]:
        """Get OpenAPI tags from backend server."""
        try:
            backend_server = await self._backend_server_repository.find_by_id(
                item_id=backend_server_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Backend server not found: {backend_server_id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {backend_server_id}",
            )

        if not backend_server.swagger_json:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Swagger JSON not found for backend server: {backend_server_id}",
            )
        axmp_open_api_spec = AxmpOpenAPI.from_spec_dict(backend_server.swagger_json)

        return axmp_open_api_spec.get_tags()

    def _extract_tools_from_route_maps(
        self,
        *,
        backend_server: BackendServer,
        route_maps: list[RouteMap],
        existing_path_method_combinations: set,
    ) -> list[dict]:
        """Extract tools from route maps using OpenAPI specification.

        Args:
            backend_server: Backend server containing swagger JSON
            route_maps: List of route maps to process
            existing_path_method_combinations: Set of existing path-method combinations

        Returns:
            List of tool information dictionaries
        """
        tools = []

        if not route_maps:
            return tools

        axmp_open_api_spec = AxmpOpenAPI.from_spec_dict(backend_server.swagger_json)

        tags = axmp_open_api_spec.get_tags()
        logger.info(f"Tags: {tags}")

        for route_map in route_maps:
            operations = axmp_open_api_spec.get_operations_by_tag_method_pattern(
                tags=route_map.tags,
                methods=route_map.methods,
                regex=route_map.pattern,
            )
            if len(operations) == 0:
                continue
            convert_tools = Converter.operations_to_tools(
                server_name=backend_server.name,
                base_path=backend_server.base_path,
                axmp_open_api=axmp_open_api_spec,
                operations=operations,
            )
            for tool in convert_tools:
                path_method_key = f"{tool.path}:{tool.method}"

                # Check if this path-method combination already exists
                if path_method_key not in existing_path_method_combinations:
                    tool_info = {
                        "path": tool.path,
                        "method": tool.method.upper(),
                        "tool_name": tool.name,
                        "description": tool.description,
                        "parameters": "",
                    }
                    tools.append(tool_info)
                    existing_path_method_combinations.add(path_method_key)
                else:
                    logger.debug(f"Skipping duplicate tool: {path_method_key}")

        return tools

    async def validate_and_get_provision_status(
        self, *, profile_id: str, version: int, cluster_id: str
    ) -> McpServerProvisionStatus | None:
        """Validate no duplicate and get provision status.

        Returns:
            Existing provision status if found with different version, None if not found

        Raises:
            CoreServiceException: DUPLICATE_FOUND if same version already provisioned
        """
        try:
            existing = await self.get_provision_status_by_profile_id_and_cluster_id(
                profile_id=profile_id,
                cluster_id=cluster_id,
            )
            if existing.profile_version == version:
                raise CoreServiceException(
                    CoreError.DUPLICATE_FOUND,
                    details=f"MCP server already provisioned: {profile_id}, v{version}",
                )
            return existing
        except CoreServiceException as e:
            if e.status_code == 404:
                return None
            raise

    async def get_provision_status_by_profile_id_and_cluster_id(
        self,
        *,
        profile_id: str,
        cluster_id: str,
    ) -> McpServerProvisionStatus:
        """Get MCP server provision status by profile ID and cluster ID."""
        try:
            return await self._mcp_server_provision_status_repository.find_by_profile_id_and_cluster_id(
                profile_id=profile_id,
                cluster_id=cluster_id,
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Provision status not found for profile {profile_id} on cluster {cluster_id}",
            )
        except Exception as e:
            logger.error(f"Error getting MCP server provision status: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP server provision status. profile_id: {profile_id}, cluster_id: {cluster_id}",
            )

    async def get_provision_status_by_profile_id_and_version_and_cluster_id(
        self,
        *,
        profile_id: str,
        profile_version: int,
        cluster_id: str,
    ) -> McpServerProvisionStatus:
        """Get MCP server provision status by profile ID, version and cluster ID."""
        try:
            provision_status = await self._mcp_server_provision_status_repository.find_by_profile_id_and_version_and_cluster_id(
                profile_id=profile_id,
                profile_version=profile_version,
                cluster_id=cluster_id,
            )
            return provision_status
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Provision status not found for profile {profile_id} version {profile_version} on cluster {cluster_id}",
            )
        except Exception as e:
            logger.error(f"Error getting MCP server provision status: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP server provision status: profile_id: {profile_id}, profile_version: {profile_version}, cluster_id: {cluster_id}",
            )

    async def get_mcp_server_config_json_by_profile_id_and_cluster_id(
        self,
        *,
        profile_id: str,
        cluster_id: str,
    ) -> McpServerConfigs:
        """Get MCP server config JSON by profile ID and cluster ID."""
        try:
            provision_status = await self._mcp_server_provision_status_repository.find_by_profile_id_and_cluster_id(
                profile_id=profile_id,
                cluster_id=cluster_id,
            )

            logger.info(
                f"Retrieved MCP server config JSON for profile {profile_id} "
                f"on cluster {cluster_id}"
            )

            if provision_status.mcp_config_json is None:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details=f"MCP config JSON not yet available for profile {profile_id} on cluster {cluster_id}. "
                    "The instance may still be initializing.",
                )

            return provision_status.mcp_config_json
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Provision status not found for profile {profile_id} on cluster {cluster_id}",
            )
        except Exception as e:
            logger.error(f"Error getting MCP server config JSON: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP server config JSON. profile_id: {profile_id}, cluster_id: {cluster_id}",
            )

    async def remove_provision_status_by_id(self, *, provision_status_id: str) -> bool:
        """Remove MCP server provision status."""
        try:
            return await self._mcp_server_provision_status_repository.delete(
                item_id=provision_status_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Provision status not found: {provision_status_id}",
            )
        except Exception as e:
            logger.error(f"Error removing MCP server provision status: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to remove MCP server provision status. provision_status_id: {provision_status_id}",
            )

    async def get_provision_statuses_by_profile_id(
        self, *, profile_id: str
    ) -> list[McpServerProvisionStatus]:
        """Get all MCP server provision statuses by profile ID."""
        return await self._mcp_server_provision_status_repository.find_all_without_pagination(
            query_parameters=McpServerProvisionStatusQueryParameters(
                profile_id=profile_id,
                profile_version=None,
                cluster_id=None,
            ),
            exclude_fields=[
                "mcp_config_json",
            ],
        )

    async def remove_provision_statuses_by_profile_id(self, *, profile_id: str) -> int:
        """Remove all MCP server provision statuses by profile ID."""
        try:
            return await self._mcp_server_provision_status_repository.remove_provision_statuses_by_profile_id(
                profile_id=profile_id
            )

        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile not found: {profile_id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(
                f"Error removing MCP server provision statuses by profile: {e}"
            )
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to remove MCP server provision statuses by profile. profile_id: {profile_id}",
            )

    async def remove_provision_status_by_profile_id_and_cluster_id(
        self, *, profile_id: str, cluster_id: str
    ) -> bool:
        """Remove MCP server provision status by profile ID and cluster ID."""
        try:
            return await self._mcp_server_provision_status_repository.remove_provision_status_by_profile_id_and_cluster_id(
                profile_id=profile_id, cluster_id=cluster_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP server profile not found: {profile_id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(
                f"Error removing MCP server provision statuses by profile and cluster: {e}"
            )
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to remove MCP server provision statuses by profile and cluster. profile_id: {profile_id}, cluster_id: {cluster_id}",
            )

    async def create_mcp_server_playground(
        self,
        *,
        profile_id: str,
        iss: str,
        sub: str,
        llm_provider: str,
        llm_model: str,
        llm_api_key_id: str,
        backend_server_auth_configs: list[McpServerBackendServerAuthConfig],
        checkpointer: InMemorySaver | None = None,
    ) -> tuple[McpServerProfile, McpServer, CompiledStateGraph | None]:
        """Create MCP server playground agent.

        Args:
            profile_id: MCP server profile ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            llm_provider: LLM provider key (e.g. "openai").
            llm_model: LLM model name (e.g. "gpt-4.1-mini").
            llm_api_key_id: UserCredential ID for LLM API key.
            backend_server_auth_configs: Backend server auth configurations.
            checkpointer: LangGraph checkpointer (defaults to InMemorySaver).

        Returns:
            Tuple of (MCP server profile, MCP server, compiled agent graph).
        """
        # 0. Find user by iss and sub
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 1. Cache key + evict existing
        cache_key = mcp_playground_agent_cache_key(profile_id, user.id)
        if self._agent_cache is not None:
            await self._agent_cache.delete(cache_key)
            logger.info("Evicted cached MCP agent for profile %s", profile_id)
            logger.info("Cache stats: %s", await self._agent_cache.get_stats())

        # 2. Fetch MCP server profile
        mcp_server_profile = await self.get_profile_by_id(profile_id=profile_id)

        # 3. Create temp directory and save backend server API specs
        temp_dir = tempfile.gettempdir()
        spec_dir = os.path.join(temp_dir, "mcp_profiles")
        os.makedirs(spec_dir, exist_ok=True)

        backend_servers: dict[str, Any] = {}
        for node in mcp_server_profile.flow.nodes:
            if node.node_type == McpServerProfileNodeType.BACKEND_SERVER:
                backend_server = await self._backend_server_repository.find_by_id(
                    item_id=node.data.backend_server_id
                )
                backend_servers[backend_server.id] = backend_server

                api_spec = backend_server.swagger_json
                if api_spec is None:
                    raise CoreServiceException(
                        CoreError.ID_NOT_FOUND,
                        details=f"Backend server API spec not found: {backend_server.id}",
                    )

                spec_file = os.path.join(
                    spec_dir, f"backend_server_{backend_server.id}.json"
                )
                with open(spec_file, "w", encoding="utf-8") as f:
                    json.dump(api_spec, f, indent=2)
                logger.debug("Saved backend server API spec to: %s", spec_file)

        # 4. Build auth config dict and create multi-openapi spec
        auth_config_dict: dict[str, AuthConfig] = {}
        for auth_cfg in backend_server_auth_configs:
            auth_config_dict[auth_cfg.server_id] = auth_cfg.auth_config

        multi_openapi_spec_config = await self.create_multi_openapi_spec(
            profile_id=profile_id,
            backend_servers=backend_servers,
            backend_server_auth_configs=auth_config_dict,
        )
        if multi_openapi_spec_config is None:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Multi openapi spec config not found: {profile_id}",
            )
        spec_file = os.path.join(spec_dir, f"mcp_profile_{profile_id}.json")
        with open(spec_file, "w", encoding="utf-8") as f:
            json.dump(multi_openapi_spec_config.model_dump(), f, indent=2)
        logger.debug("Saved multi openapi spec config to: %s", spec_file)

        # 5. Serialize auth configs to CLI args format
        auth_configs_str: list[str] = []
        for server_id, auth_cfg in auth_config_dict.items():
            bs = backend_servers.get(server_id)
            if bs is None:
                continue
            if auth_cfg.type == AuthenticationType.API_KEY:
                auth_configs_str.append(
                    f"{bs.system_name}:{auth_cfg.api_key_name}={auth_cfg.api_key_value}"
                )
            elif auth_cfg.type == AuthenticationType.BASIC:
                auth_configs_str.append(
                    f"{bs.system_name}:username={auth_cfg.username}"
                )
                auth_configs_str.append(
                    f"{bs.system_name}:password={auth_cfg.password}"
                )
            elif auth_cfg.type == AuthenticationType.BEARER:
                auth_configs_str.append(
                    f"{bs.system_name}:bearer_token={auth_cfg.bearer_token}"
                )

        # 6. Build StdioConnection for axmp_openapi_mcp_server subprocess
        stdio_args = [
            "-m",
            "axmp_openapi_fastmcp_server",
            "--transport",
            "stdio",
            "--profile-base-path",
            spec_dir,
            "--profile-id",
            profile_id,
        ]
        if auth_configs_str:
            stdio_args.extend(
                [
                    "--backend-server-auth-configs",
                    ",".join(auth_configs_str),
                ]
            )

        stdio_connection = StdioConnection(
            transport="stdio",
            command=core_settings.python_path,
            args=stdio_args,
            session_kwargs={
                "read_timeout_seconds": timedelta(
                    seconds=core_settings.mcp_connection_timeout
                ),
            },
        )

        # 7. Fetch LLM credentials
        try:
            user_credential = await self._user_credential_repository.find_by_id(
                item_id=llm_api_key_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User credential not found: {llm_api_key_id}",
            )

        # 8. Fetch LLM provider for base_url
        try:
            llm_provider_id = await self._llm_provider_repository.get_id_by_key(
                key=llm_provider
            )
            llm_provider_entity = await self._llm_provider_repository.find_by_id(
                item_id=llm_provider_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"LLM provider not found: {llm_provider}",
            )

        # 9. Build LLMSpecData from credentials
        llm_spec_data = LLMSpecData(
            provider=llm_provider,
            base_url=llm_provider_entity.base_url,
            default_model_id=llm_model,
            api_key=user_credential.llm_api_key,
            aws_access_key_id=user_credential.aws_access_key_id,
            aws_secret_access_key=user_credential.aws_secret_access_key,
            aws_region_name=user_credential.region_name,
        )

        # 10. Build MCP server config for the playground profile
        mcp_server_config = {
            mcp_server_profile.system_name: {
                "transport": "stdio",
                "command": stdio_connection["command"],
                "args": stdio_connection["args"],
            }
        }

        # 11. Build system prompt
        try:
            system_prompt_text = load_prompt(
                get_prompt_path(PromptFile.MCP_PLAYGROUND_AGENT)
            ).format(
                system_time=datetime.now(tz=UTC).isoformat(),
            )
        except Exception as e:
            logger.error("Error loading prompt: %s", e)
            system_prompt_text = (
                "You are a helpful assistant. Please answer the question."
            )

        # 12. Build SingleAgentSpecProfile via playground factory
        agent_spec_profile = build_playground_spec_profile(
            llm_spec_data=llm_spec_data,
            mcp_server_configs=[mcp_server_config],
            system_prompt=system_prompt_text,
        )

        # 13. Create SingleAgentWrapper and build agent
        wrapper = SingleAgentWrapper(
            agent_spec=agent_spec_profile,
            oauth_mcp_server_registry=self._oauth_mcp_server_registry,
            mcp_client_factory=self._mcp_client_factory,
            checkpointer=checkpointer,
        )

        (
            need_auth,
            pending_auth,
            mcp_server_configs,
        ) = await wrapper.need_mcp_authentication(user_id=user.id)

        _effective_mcp_config: MCPServerConfig = (
            mcp_server_configs[0] if mcp_server_configs else None
        )
        if _effective_mcp_config is None:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server config not found for profile {profile_id}",
            )

        if need_auth:
            need_auth_mcp_server: NeedAuthMCPServer = pending_auth[0]
            logger.warning(
                "MCP server %s requires authentication: %s",
                need_auth_mcp_server.server_id,
                need_auth_mcp_server.auth_url,
            )

            mcp_server = McpServer(
                server_id=_effective_mcp_config.server_id,
                server_name=mcp_server_profile.name,
                is_oauth_server=_effective_mcp_config.is_oauth_server,
                connected=False,
                tools=[],
                transport_type=mcp_server_profile.transport_type,
                icon_url=mcp_server_profile.icon_url,
                auth_url=need_auth_mcp_server.auth_url,
            )

            # Tuple of (MCP server profile, MCP server, compiled agent graph).
            return mcp_server_profile, mcp_server, None

        agent = await wrapper.build_agent(user_id=user.id)

        # 14. Get tools from all MCP servers(only one server for now)
        tools: list[BaseTool] = await wrapper.get_mcp_server_tools(
            mcp_server_profile.system_name
        )

        # 15. Cache the compiled graph
        if self._agent_cache is not None:
            await self._agent_cache.put(cache_key, agent)
            logger.info("Cached MCP playground agent for profile %s", profile_id)
            logger.info("Cache stats: %s", await self._agent_cache.get_stats())

        connected = not bool(_effective_mcp_config.error_message)

        mcp_server = McpServer(
            server_id=_effective_mcp_config.server_id,
            server_name=mcp_server_profile.system_name,
            is_oauth_server=_effective_mcp_config.is_oauth_server,
            connected=connected,
            tools=tools,
            transport_type=mcp_server_profile.transport_type,
            icon_url=mcp_server_profile.icon_url,
            error_message=_effective_mcp_config.error_message,
        )

        return mcp_server_profile, mcp_server, agent

    async def validate_agent_initialized(
        self,
        profile_id: str,
        iss: str,
        sub: str,
    ) -> None:
        """Get cached agent."""
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User not found: {e}",
            )

        if self._agent_cache is not None:
            cached_agent = await self._get_cached_agent(
                profile_id=profile_id,
                user_id=user.id,
            )
            if cached_agent is None:
                raise CoreServiceException(
                    CoreError.AGENT_NOT_FOUND,
                    details=f"Cached agent not found in the cache for profile {profile_id} and user {user.id}. You should initialize the agent first.",
                )
            return
        else:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Cache not found in the server",
            )

    async def stream_playground_completion(
        self,
        *,
        profile_id: str,
        thread_id: str,
        iss: str,
        sub: str,
        prompt: str,
        llm_model: str | None = None,
        files: list[str] | None = None,
    ) -> AsyncGenerator[ServerSentEvent, None]:
        """Stream MCP server playground completion as SSE events.

        You should validate the playground agent initialized before calling this method.
        ```python
        await mcp_server_service.validate_agent_initialized(
            profile_id=profile_id,
            iss=oauth_user.iss,
            sub=oauth_user.sub,
        )
        ```

        Args:
            profile_id: MCP server profile ID.
            thread_id: Conversation thread ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            prompt: User prompt text.
            llm_model: LLM model override.
            temperature: Temperature override.
            max_tokens: Max tokens override.
            files: List of file IDs for multimodal messages.

        Returns:
            Async generator of ServerSentEvent.
        """
        # 0. Find user
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"User not found: {e}",
            )

        # 1. Retrieve cached agent
        agent = await self._get_cached_agent(profile_id=profile_id, user_id=user.id)

        if agent is None:
            raise CoreServiceException(
                CoreError.AGENT_NOT_FOUND,
                details=f"MCP server playground agent not found for profile: {profile_id} and user: {user.id}",
            )

        # 2. Resolve LLM model
        effective_model = llm_model or core_settings.default_model

        # 3. Build RunnableConfig
        config = self._build_runnable_config(
            thread_id=thread_id,
            user_id=user.id,
            # llm_model=effective_model,
        )

        # 4. Build inputs
        chat_files = []
        if files:
            chat_files = await self._get_chat_files_for_playground(files)
        messages = generate_multimodal_messages(chat_files, prompt, effective_model)
        inputs = {"messages": [HumanMessage(content=messages)]}

        # 5. Stream SSE events
        async for event in stream_agent_events(
            agent=agent,
            thread_id=thread_id,
            # llm_model=effective_model,
            inputs=inputs,
            config=config,
        ):
            yield event

    async def _get_cached_agent(
        self, profile_id: str, user_id: str
    ) -> CompiledStateGraph:
        """Retrieve a cached MCP playground agent.

        Raises:
            CoreServiceException: If agent not found in cache.
        """
        cache_key = mcp_playground_agent_cache_key(
            profile_id=profile_id, username=user_id
        )
        agent = None
        if self._agent_cache is not None:
            agent = await self._agent_cache.get(cache_key)

        if agent is None:
            logger.warning(
                "MCP playground agent not found in cache for profile %s and user %s",
                profile_id,
                user_id,
            )
        return agent

    def _build_runnable_config(
        self,
        *,
        thread_id: str,
        user_id: str,
        llm_model: str | None = None,
    ) -> dict[str, Any]:
        """Build a RunnableConfig dict for agent execution."""
        return {
            "configurable": {
                "thread_id": thread_id,
                "user_id": user_id,
                # "model": llm_model,  # TODO: check the compiled agent supports the dynamic model during runtime
            },
            "recursion_limit": core_settings.recursion_limit,
        }

    async def _get_chat_files_for_playground(
        self, file_ids: list[str]
    ) -> list[AgentChatFile]:
        """Fetch chat files and convert to agent ChatFile format."""
        chat_files = []
        for file_id in file_ids:
            if not file_id:
                continue
            try:
                entity = await self._chat_file_repository.find_by_id(item_id=file_id)
                chat_files.append(
                    AgentChatFile(
                        upload_url=entity.upload_url,
                        file_name=entity.file_name,
                        mime_type=entity.mime_type,
                        project_id=entity.project_id,
                    )
                )
            except Exception as e:
                logger.warning("Failed to fetch chat file %s: %s", file_id, e)
        return chat_files


def _extract_tools_from_path_method(
    *,
    backend_server: BackendServer,
    path_method: str,
) -> dict:
    """Extract tools from path-method combination using OpenAPI specification.

    Args:
        backend_server: Backend server containing swagger JSON
        path_method: Path-method combination string (e.g., "/api/users:GET")
        existing_path_method_combinations: Set of existing path-method combinations

    Returns:
        List of tool information dictionaries
    """
    tool_info = {}

    if not path_method or ":" not in path_method:
        logger.warning(f"Invalid path-method format: {path_method}")
        return tool_info

    try:
        # Parse path and method from the path_method string
        path, method = path_method.split(":", 1)

        # Create AxmpOpenAPI instance from swagger JSON
        axmp_open_api_spec = AxmpOpenAPI.from_spec_dict(backend_server.swagger_json)

        # Get operations for the specific path and method
        operation = axmp_open_api_spec.get_operation_by_path_method(
            path=path, method=method
        )

        if not operation:
            logger.debug(f"No operations found for path-method: {path_method}")
            return tool_info

        operations = []
        operations.append((path, method, operation))
        # Convert operations to tools
        convert_tools = Converter.operations_to_tools(
            server_name=backend_server.name,
            base_path=backend_server.base_path,
            axmp_open_api=axmp_open_api_spec,
            operations=operations,
        )

        # Extract tool information
        for tool in convert_tools:
            tool_info = {
                "path": tool.path,
                "method": tool.method.upper(),
                "tool_name": tool.name,
                "description": tool.description,
                "parameters": "",
            }

    except Exception as e:
        logger.error(f"Error extracting tools from path-method {path_method}: {str(e)}")

    return tool_info
