"""MCP Registry service."""

from __future__ import annotations

import copy
import logging
import time
from datetime import UTC, datetime
from typing import Any, AsyncGenerator
from urllib.parse import urlencode

from axmp_openapi_helper import AuthenticationType
from bson import ObjectId
from langchain_core.messages import HumanMessage
from langchain_core.prompts import load_prompt
from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph.state import CompiledStateGraph
from mcp import McpError
from sse_starlette.sse import ServerSentEvent

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig, NeedAuthMCPServer
from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.clients.factory import UserMCPClientFactory
from axmp_ai_agent_core.agent.playground.mcp_server_playground_agent_profile import (
    build_playground_spec_profile,
)
from axmp_ai_agent_core.agent.spec.profile_node_data import LLMSpecData
from axmp_ai_agent_core.agent.streaming.sse_generator import stream_agent_events
from axmp_ai_agent_core.agent.util.agent_cache import AsyncTTLQueue
from axmp_ai_agent_core.agent.util.agent_cache_key_format import (
    mcp_registry_playground_agent_cache_key,
)
from axmp_ai_agent_core.agent.util.chat_file_utils import (
    ChatFile as AgentChatFile,
)
from axmp_ai_agent_core.agent.util.chat_file_utils import (
    generate_multimodal_messages,
)
from axmp_ai_agent_core.agent.util.mcp_client_manager import McpServer
from axmp_ai_agent_core.agent.wrapper.single_agent_wrapper import SingleAgentWrapper
from axmp_ai_agent_core.db.backend_server_repository import BackendServerRepository
from axmp_ai_agent_core.db.chat_file_repository import ChatFileRepository
from axmp_ai_agent_core.db.llm_provider_repository import LlmProviderRepository
from axmp_ai_agent_core.db.mcp_registry_repository import McpRegistryRepository
from axmp_ai_agent_core.db.mcp_server_provision_status_repository import (
    McpServerProvisionStatusRepository,
)
from axmp_ai_agent_core.db.user_credential_repository import UserCredentialRepository
from axmp_ai_agent_core.db.user_repository import UserRepository
from axmp_ai_agent_core.entity.mcp_registry import (
    McpRegistry,
    ResourceType,
    Status,
)
from axmp_ai_agent_core.exception.db_exceptions import ObjectNotFoundException
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.mcp_registry_query import (
    McpRegistryQueryParameters,
)
from axmp_ai_agent_core.setting import core_settings
from axmp_ai_agent_core.util.mcp_connection_builder import (
    build_mcp_connection,
    infer_transport_type,
)
from axmp_ai_agent_core.util.mcp_utils import get_mcp_error_message
from axmp_ai_agent_core.util.prompt_manager import PromptFile, get_prompt_path

logger = logging.getLogger(__name__)


class McpRegistryService:
    """MCP Registry service."""

    def __init__(
        self,
        mcp_registry_repository: McpRegistryRepository,
        user_repository: UserRepository,
        llm_provider_repository: LlmProviderRepository,
        user_credential_repository: UserCredentialRepository,
        backend_server_repository: BackendServerRepository,
        chat_file_repository: ChatFileRepository,
        agent_cache: AsyncTTLQueue,
        mcp_server_provision_status_repository: McpServerProvisionStatusRepository,
        oauth_mcp_server_registry: OAuthMCPServerRegistry,
        mcp_client_factory: UserMCPClientFactory,
    ):
        """Initialize the MCP Registry service."""
        self._mcp_registry_repository = mcp_registry_repository
        self._user_repository = user_repository
        self._llm_provider_repository = llm_provider_repository
        self._user_credential_repository = user_credential_repository
        self._backend_server_repository = backend_server_repository
        self._chat_file_repository = chat_file_repository
        self._agent_cache = agent_cache
        self._mcp_server_provision_status_repository = (
            mcp_server_provision_status_repository
        )
        self._oauth_mcp_server_registry = oauth_mcp_server_registry
        self._mcp_client_factory = mcp_client_factory

    async def create_mcp_registry(self, *, mcp_registry: McpRegistry) -> McpRegistry:
        """Create a new MCP Registry."""
        try:
            existing_registry = await self._mcp_registry_repository.find_by_name(
                name=mcp_registry.name
            )

            if existing_registry:
                logger.error(
                    f"MCP Registry with name {mcp_registry.name} already exists"
                )
                raise CoreServiceException(
                    CoreError.DUPLICATE_FOUND,
                    details=f"MCP Registry with name {mcp_registry.name} already exists",
                )

            mcp_registry_entity = mcp_registry.model_copy(
                update={
                    "categories": mcp_registry.categories or [],
                    "labels": mcp_registry.labels or {},
                    "is_published": True,
                }
            )

            item_id = await self._mcp_registry_repository.insert(
                item=mcp_registry_entity
            )

            created_registry = await self._mcp_registry_repository.find_by_id(
                item_id=item_id
            )

            if created_registry.resource_type == ResourceType.INTERNAL:
                await self._update_provision_publish_status(
                    instance_id=item_id, is_published=True
                )

            return created_registry

        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error creating MCP Registry: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to create MCP Registry: {e}",
            )

    async def _update_provision_publish_status(
        self, *, instance_id: str, is_published: bool
    ) -> None:
        """Update is_published on McpServerProvisionStatus for internal resources."""
        if self._mcp_server_provision_status_repository is None:
            return
        try:
            provision_status = (
                await self._mcp_server_provision_status_repository.find_by_instance_id(
                    instance_id=instance_id
                )
            )
            if provision_status is None:
                logger.warning(
                    f"Provision status not found for instance_id={instance_id}, "
                    "skipping is_published update"
                )
                return

            updated = provision_status.model_copy(update={"is_published": is_published})
            await self._mcp_server_provision_status_repository.update(item=updated)
            logger.info(
                f"Updated provision status is_published={is_published} "
                f"for instance_id={instance_id}"
            )
        except Exception as e:
            logger.warning(
                f"Failed to update provision status is_published "
                f"for instance_id={instance_id}: {e}"
            )

    async def get_mcp_registry_by_id(self, *, id: str) -> McpRegistry:
        """Get an MCP Registry by ID."""
        try:
            return await self._mcp_registry_repository.find_by_id(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP Registry not found: {id}",
            )

    async def get_mcp_registries(
        self,
        *,
        query_parameters: McpRegistryQueryParameters,
        page_number: int = 1,
        page_size: int = 10,
        exclude_fields: list[str] | None = None,
        include_fields: list[str] | None = None,
    ) -> list[McpRegistry]:
        """Get MCP Registries by query parameters."""
        try:
            return await self._mcp_registry_repository.find_all(
                query_parameters=query_parameters,
                page_number=page_number,
                page_size=page_size,
                exclude_fields=exclude_fields or [],
                include_fields=include_fields or [],
            )
        except Exception as e:
            logger.error(f"Error getting MCP registries with tools by query: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP registries with tools by query: {e}",
            )

    async def get_external_profiles(
        self,
        *,
        query_parameters: McpRegistryQueryParameters,
    ) -> list[McpRegistry]:
        """Get external MCP server profiles ."""
        try:
            mcp_server_profiles = await self._mcp_registry_repository.find_all(
                query_parameters=query_parameters,
                include_fields=["id", "name", "icon_url"],
            )
            return mcp_server_profiles
        except Exception as e:
            logger.error(f"Error getting external MCP server profiles: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get external MCP server profiles: {e}",
            )

    async def get_mcp_registries_count(
        self,
        *,
        query_parameters: McpRegistryQueryParameters,
    ) -> int:
        """Get count of MCP Registries by query parameters."""
        try:
            return await self._mcp_registry_repository.count(
                query_parameters=query_parameters
            )
        except Exception as e:
            logger.error(f"Error getting MCP registries count: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get MCP registries count: {e}",
            )

    async def update_mcp_registry(
        self, *, id: str, mcp_registry: McpRegistry, updated_by: str
    ) -> McpRegistry:
        """Update an MCP Registry."""
        try:
            existing_mcp_registry = await self._mcp_registry_repository.find_by_id(
                item_id=id
            )

            if mcp_registry.name and mcp_registry.name != existing_mcp_registry.name:
                duplicate_registry = await self._mcp_registry_repository.find_by_name(
                    name=mcp_registry.name
                )
                if duplicate_registry and str(duplicate_registry.id) != id:
                    logger.error(
                        f"MCP Registry with name {mcp_registry.name} already exists"
                    )
                    raise CoreServiceException(
                        CoreError.DUPLICATE_FOUND,
                        details=f"MCP Registry with name {mcp_registry.name} already exists",
                    )

            # Extract only explicitly provided fields and merge into the existing registry
            # - model_fields_set: fields explicitly passed to the constructor (including None)
            # - exclude: immutable fields retain their existing values regardless of the request
            _IMMUTABLE_FIELDS = {
                "id",
                "created_by",
                "created_at",
                "updated_at",
                "status",
            }
            patch = mcp_registry.model_dump(
                include=mcp_registry.model_fields_set - _IMMUTABLE_FIELDS,
            )
            patch["updated_by"] = updated_by

            updated_mcp_registry = existing_mcp_registry.model_copy(update=patch)

            result = await self._mcp_registry_repository.update(
                item=updated_mcp_registry
            )

            # Sync provision_status.is_published when is_published changes on INTERNAL registry
            if (
                result.resource_type == ResourceType.INTERNAL
                and "is_published" in mcp_registry.model_fields_set
                and result.is_published != existing_mcp_registry.is_published
            ):
                await self._update_provision_publish_status(
                    instance_id=id, is_published=result.is_published
                )

            return result

        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP Registry not found: {id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error updating MCP Registry: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to update MCP Registry: {e}",
            )

    async def delete_mcp_registry(self, *, id: str) -> bool:
        """Delete an MCP Registry."""
        try:
            registry = await self._mcp_registry_repository.find_by_id(item_id=id)
            result = await self._mcp_registry_repository.delete(item_id=id)

            if registry.resource_type == ResourceType.INTERNAL:
                await self._update_provision_publish_status(
                    instance_id=id, is_published=False
                )

            return result
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP Registry not found: {id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error deleting MCP registry {id}: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to delete MCP registry: {e}",
            )

    async def get_categories_with_count(self) -> tuple[dict[str, int], int]:
        """Get all categories with their counts and total count."""
        try:
            categories_with_count = (
                await self._mcp_registry_repository.get_categories_with_count()
            )

            total = await self._mcp_registry_repository.count(
                query_parameters=McpRegistryQueryParameters()
            )
            return categories_with_count, total
        except Exception as e:
            logger.error(f"Error getting categories with count: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get categories with count: {e}",
            )

    async def update_mcp_registry_publish_status(
        self, *, id: str, is_published: bool, updated_by: str
    ) -> McpRegistry:
        """Toggle is_published and sync to provision_status for INTERNAL registries."""
        try:
            mcp_registry = await self._mcp_registry_repository.find_by_id(item_id=id)

            mcp_registry.is_published = is_published
            mcp_registry.updated_by = updated_by

            result = await self._mcp_registry_repository.update(item=mcp_registry)

            if mcp_registry.resource_type == ResourceType.INTERNAL:
                await self._update_provision_publish_status(
                    instance_id=id, is_published=is_published
                )

            return result
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP Registry not found: {id}",
            )
        except CoreServiceException:
            raise
        except Exception as e:
            logger.error(f"Error updating MCP registry publish status {id}: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to update MCP registry publish status: {e}",
            )

    async def update_mcp_registry_status(
        self, *, id: str, status: Status, updated_by: str
    ) -> McpRegistry:
        """Update MCP Registry status.

        .. deprecated::
            The ``status`` field is no longer used in any business logic.
        """
        try:
            mcp_registry = await self._mcp_registry_repository.find_by_id(item_id=id)

            mcp_registry.status = status
            mcp_registry.updated_by = updated_by

            return await self._mcp_registry_repository.update(item=mcp_registry)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"MCP Registry not found: {id}",
            )
        except Exception as e:
            logger.error(f"Error updating MCP registry status {id}: {e}")
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to update MCP registry status: {e}",
            )

    # ──────────────────────────────────────────────────────────────────────
    # Playground methods
    # ──────────────────────────────────────────────────────────────────────

    async def get_publish_data_from_external_mcp(
        self,
        *,
        mcp_servers: dict[str, Any],
        iss: str,
        sub: str,
        name: str | None = None,
        description: str | None = None,
        categories: list[str] | None = None,
        updated_by: str,
    ) -> tuple[McpRegistry, bool, McpServer]:
        """Discover tools from external MCP server config and return non-persisted McpRegistry.

        Checks OAuth authentication status for MCP servers before tool discovery.

        Args:
            mcp_servers: mcpServers configuration dict.
            iss: OIDC issuer.
            sub: OIDC subject.
            name: Registry name.
            description: Registry description.
            categories: Registry categories.
            updated_by: Username of the requester.

        Returns:
            Tuple of (McpRegistry, need_auth, McpServer).
        """
        # 0. Find user
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST, details=f"User not found: {e}"
            )

        start_time = time.time()
        connections = {}
        last_transport = None

        if mcp_servers:
            for server_name, server_config in mcp_servers.items():
                last_transport = infer_transport_type(server_config)
                connection = build_mcp_connection(
                    server_name, server_config, strict=True
                )
                if connection is not None:
                    connections[server_name] = connection

        # Clean PATH env from mcp_servers (deep copy to avoid mutating input)
        cleaned_servers = copy.deepcopy(mcp_servers)
        for server_config in cleaned_servers.values():
            if "env" in server_config and "PATH" in server_config["env"]:
                del server_config["env"]["PATH"]

        # Build common McpRegistry fields
        registry_id = str(ObjectId())
        last_server_name = next(iter(cleaned_servers), "") if cleaned_servers else ""

        # 1. Build MCPServerConfig list for OAuth check
        mcp_server_configs = []
        for server_name, server_config in mcp_servers.items():
            transport = infer_transport_type(server_config)
            config = MCPServerConfig(
                server_id=server_name,
                transport=transport,
                url=server_config.get("url"),
                headers=server_config.get("headers"),
                command=server_config.get("command"),
                args=server_config.get("args"),
                env=server_config.get("env"),
                cwd=server_config.get("cwd"),
            )
            mcp_server_configs.append(config)

        # 2. Register servers and check OAuth authentication
        logger.debug(
            "OAuth check: registering %d servers: %s",
            len(mcp_server_configs),
            [(c.server_id, c.transport, c.url) for c in mcp_server_configs],
        )
        await self._oauth_mcp_server_registry.add_servers(mcp_server_configs)

        oauth_discovery_failed_server: str | None = None
        for cfg in mcp_server_configs:
            has = await self._oauth_mcp_server_registry.has_server(cfg.server_id)
            logger.debug("OAuth check: has_server('%s') = %s", cfg.server_id, has)
            if has:
                try:
                    discovery = await self._oauth_mcp_server_registry.discover(
                        cfg.server_id
                    )

                    if discovery.requires_oauth:
                        cfg.is_oauth_server = True

                except Exception as e:
                    logger.warning(
                        "OAuth discovery failed for server '%s': %s",
                        cfg.server_id,
                        e,
                    )
                    oauth_discovery_failed_server = cfg.server_id

        # NOTE: mcp_server_configs should be one for this function
        _effective_mcp_config = mcp_server_configs[0] if mcp_server_configs else None
        if _effective_mcp_config is None:
            raise CoreServiceException(
                CoreError.BAD_REQUEST, details="No MCP servers found"
            )

        # If OAuth discovery itself failed (e.g. DCR registration error),
        # the server requires OAuth but registration couldn't complete.
        # Treat as need_auth so the frontend can show the auth prompt.
        if oauth_discovery_failed_server:
            auth_url = (
                (
                    f"{self._oauth_mcp_server_registry.auth_login_url}"
                    f"?{urlencode({'user_id': user.id, 'server_id': oauth_discovery_failed_server})}"
                )
                if self._oauth_mcp_server_registry.auth_login_url
                else None
            )
            logger.warning(
                "OAuth discovery failed for server %s, returning need_auth=True",
                oauth_discovery_failed_server,
            )
            mcp_registry = McpRegistry(
                id=registry_id,
                created_by=updated_by,
                updated_by=updated_by,
                name=name or oauth_discovery_failed_server,
                description=description or "",
                categories=categories or [],
                version="",
                mcp_server_json={"mcpServers": cleaned_servers},
                profile_id=None,
                profile_version=None,
                labels={},
                icon_url=None,
                transport_type=last_transport,
                resource_type="external",
                is_published=False,
                status=Status.ACTIVE,
                tools=[],
            )
            mcp_server = McpServer(
                server_id=_effective_mcp_config.server_id,
                server_name=mcp_registry.name,
                is_oauth_server=_effective_mcp_config.is_oauth_server,
                connected=False,
                tools=[],
                transport_type=last_transport,
                resource_type="external",
                auth_url=auth_url,
            )
            return mcp_registry, True, mcp_server

        # Check pending auth servers
        try:
            pending = await self._mcp_client_factory.get_pending_auth_servers(
                user_id=user.id, servers=mcp_server_configs
            )
        except Exception as e:
            logger.warning("Failed to check pending auth servers: %s", e)
            pending = []

        logger.debug("OAuth check: pending=%s", pending)

        if pending:
            need_auth_server = pending[0]
            auth_url = (
                f"{self._oauth_mcp_server_registry.auth_login_url}"
                f"?{urlencode({'user_id': user.id, 'server_id': need_auth_server['server_id']})}"
            )
            logger.warning(
                "MCP server %s requires authentication: %s",
                need_auth_server["server_id"],
                auth_url,
            )

            mcp_registry = McpRegistry(
                id=registry_id,
                created_by=updated_by,
                updated_by=updated_by,
                name=name or last_server_name,
                description=description or "",
                categories=categories or [],
                version="",
                mcp_server_json={"mcpServers": cleaned_servers},
                profile_id=None,
                profile_version=None,
                labels={},
                icon_url=None,
                transport_type=last_transport,
                resource_type="external",
                is_published=False,
                status=Status.ACTIVE,
                tools=[],
            )
            mcp_server = McpServer(
                server_id=_effective_mcp_config.server_id,
                server_name=mcp_registry.name,
                is_oauth_server=_effective_mcp_config.is_oauth_server,
                connected=False,
                tools=[],
                transport_type=last_transport,
                resource_type="external",
                auth_url=auth_url,
            )
            return mcp_registry, True, mcp_server

        # 3. Tool discovery via OAuth-aware client factory
        multi_server_mcp_client: MultiServerMCPClient | None = None
        has_auth_error = False
        auth_error_server: str | None = None
        try:
            multi_server_mcp_client = await (
                self._mcp_client_factory.create_shared_client(
                    servers=mcp_server_configs, fallback_user_id=user.id
                )
            )
        except Exception as e:
            logger.warning("Failed to connect MCP servers: %s", e)
            if self._detect_auth_error_in_exception(e):
                has_auth_error = True
                auth_error_server = (
                    mcp_server_configs[0].server_id
                    if mcp_server_configs
                    else last_server_name
                )
            multi_server_mcp_client = None

        mcp_tools: list[BaseTool] = []
        if multi_server_mcp_client:
            for mcp_server_config in mcp_server_configs:
                _tools: list[BaseTool] = []
                try:
                    _tools = await multi_server_mcp_client.get_tools(
                        server_name=mcp_server_config.server_id
                    )
                except Exception as e:
                    logger.warning(
                        "Failed to get MCP tools for server '%s': %s",
                        mcp_server_config.server_id,
                        e,
                    )
                    if self._detect_auth_error_in_exception(e):
                        has_auth_error = True
                        auth_error_server = mcp_server_config.server_id
                mcp_tools.extend(_tools)

        total_time = time.time() - start_time
        logger.info(
            "Tool discovery completed in %.2fs, %d tools found",
            total_time,
            len(mcp_tools),
        )

        # 4. If auth error detected and no tools found, return need_auth
        if has_auth_error and not mcp_tools:
            failed_server = auth_error_server or last_server_name
            logger.warning(
                "Tool discovery failed with auth error for server %s, "
                "returning need_auth=True",
                failed_server,
            )
            auth_url = None
            if (
                self._oauth_mcp_server_registry is not None
                and self._oauth_mcp_server_registry.auth_login_url
            ):
                auth_url = (
                    f"{self._oauth_mcp_server_registry.auth_login_url}"
                    f"?{urlencode({'user_id': user.id, 'server_id': failed_server})}"
                )

            mcp_registry = McpRegistry(
                id=registry_id,
                created_by=updated_by,
                updated_by=updated_by,
                name=name or failed_server,
                description=description or "",
                categories=categories or [],
                version="",
                mcp_server_json={"mcpServers": cleaned_servers},
                profile_id=None,
                profile_version=None,
                labels={},
                icon_url=None,
                transport_type=last_transport,
                resource_type="external",
                is_published=False,
                status=Status.ACTIVE,
                tools=[],
            )
            mcp_server = McpServer(
                server_id=_effective_mcp_config.server_id,
                server_name=mcp_registry.name,
                is_oauth_server=_effective_mcp_config.is_oauth_server,
                connected=False,
                tools=[],
                transport_type=last_transport,
                resource_type="external",
                auth_url=auth_url,
            )
            return mcp_registry, True, mcp_server

        # 5. Normal result — connected only if client was created and tools found or no errors
        connected = multi_server_mcp_client is not None

        mcp_registry = McpRegistry(
            id=registry_id,
            created_by=updated_by,
            updated_by=updated_by,
            name=name or last_server_name,
            description=description or "",
            categories=categories or [],
            version="",
            mcp_server_json={"mcpServers": cleaned_servers},
            profile_id=None,
            profile_version=None,
            labels={},
            icon_url=None,
            transport_type=last_transport,
            resource_type="external",
            is_published=False,
            status=Status.ACTIVE,
            tools=[],
        )
        mcp_server = McpServer(
            server_id=_effective_mcp_config.server_id,
            server_name=mcp_registry.name,
            is_oauth_server=_effective_mcp_config.is_oauth_server,
            connected=connected,
            tools=mcp_tools,
            transport_type=last_transport,
            resource_type="external",
        )

        return mcp_registry, False, mcp_server

    async def create_mcp_registry_playground_external(
        self,
        *,
        registry_id: str,
        iss: str,
        sub: str,
        mcp_server_json: dict[str, Any],
        llm_provider: str,
        llm_model: str,
        llm_api_key_id: str,
        checkpointer: InMemorySaver | None = None,
    ) -> tuple[McpRegistry, McpServer, CompiledStateGraph | None]:
        """Create external MCP registry playground agent.

        Args:
            registry_id: MCP registry ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            mcp_server_json: MCP server JSON with mcpServers key.
            llm_provider: LLM provider key.
            llm_model: LLM model name.
            llm_api_key_id: UserCredential ID.
            checkpointer: LangGraph checkpointer.

        Returns:
            Tuple of (McpRegistry, McpServer, compiled agent graph).
        """
        # 0. Find user
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST, details=f"User not found: {e}"
            )

        # 1. Cache eviction
        cache_key = mcp_registry_playground_agent_cache_key(registry_id, user.id)
        if self._agent_cache is not None:
            await self._agent_cache.delete(cache_key)
            logger.info("Evicted cached MCP registry agent for %s", registry_id)

        # 2. Fetch registry + validate resource type
        mcp_registry = await self.get_mcp_registry_by_id(id=registry_id)
        if mcp_registry.resource_type == ResourceType.INTERNAL:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Registry {registry_id} resource_type is internal, use internal endpoint",
            )

        # 3. Extract connections from DTO
        mcp_servers = mcp_server_json.get("mcpServers")
        if not mcp_servers:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Registry {registry_id} missing 'mcpServers' key",
            )

        connections = {}
        for server_name, server_config in mcp_servers.items():
            connection = build_mcp_connection(server_name, server_config, strict=True)
            if connection is not None:
                connections[server_name] = connection

        # 4. Build agent
        (
            agent,
            tools,
            need_auth,
            pending_auth,
            mcp_server_config,
        ) = await self._build_playground_agent(
            user_id=user.id,
            connections=connections,
            llm_provider=llm_provider,
            llm_model=llm_model,
            llm_api_key_id=llm_api_key_id,
            checkpointer=checkpointer,
        )

        if not mcp_server_config:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server config not found for registry {registry_id}",
            )

        # 5. Handle OAuth authentication required
        if need_auth:
            need_auth_mcp_server: NeedAuthMCPServer = pending_auth[0]
            logger.warning(
                "MCP server %s requires authentication: %s",
                need_auth_mcp_server.server_id,
                need_auth_mcp_server.auth_url,
            )
            mcp_server = McpServer(
                server_id=mcp_server_config.server_id,
                server_name=mcp_registry.name,
                is_oauth_server=mcp_server_config.is_oauth_server,
                connected=False,
                tools=[],
                registry_id=mcp_registry.id,
                resource_type=mcp_registry.resource_type,
                transport_type=mcp_registry.transport_type,
                icon_url=mcp_registry.icon_url,
                auth_url=need_auth_mcp_server.auth_url,
                error_message=mcp_server_config.error_message,
            )
            return mcp_registry, mcp_server, None

        # 6. Cache
        if self._agent_cache is not None:
            await self._agent_cache.put(cache_key, agent)
            logger.info("Cached MCP registry playground agent for %s", registry_id)

        connected = not bool(mcp_server_config.error_message)

        mcp_server = McpServer(
            server_id=mcp_server_config.server_id,
            server_name=mcp_registry.name,
            is_oauth_server=mcp_server_config.is_oauth_server,
            connected=connected,
            tools=tools,
            registry_id=mcp_registry.id,
            resource_type=mcp_registry.resource_type,
            transport_type=mcp_registry.transport_type,
            icon_url=mcp_registry.icon_url,
            error_message=mcp_server_config.error_message,
        )

        return mcp_registry, mcp_server, agent

    async def create_mcp_registry_playground_internal(
        self,
        *,
        registry_id: str,
        iss: str,
        sub: str,
        llm_provider: str,
        llm_model: str,
        llm_api_key_id: str,
        backend_server_auth_configs: list,
        checkpointer: InMemorySaver | None = None,
    ) -> tuple[McpRegistry, McpServer, CompiledStateGraph | None]:
        """Create internal MCP registry playground agent.

        Args:
            registry_id: MCP registry ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            llm_provider: LLM provider key.
            llm_model: LLM model name.
            llm_api_key_id: UserCredential ID.
            backend_server_auth_configs: Backend server auth configurations.
            checkpointer: LangGraph checkpointer.

        Returns:
            Tuple of (McpRegistry, McpServer, compiled agent graph).
        """
        # 0. Find user
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST, details=f"User not found: {e}"
            )

        # 1. Cache eviction
        cache_key = mcp_registry_playground_agent_cache_key(registry_id, user.id)
        if self._agent_cache is not None:
            await self._agent_cache.delete(cache_key)
            logger.info("Evicted cached MCP registry agent for %s", registry_id)

        # 2. Fetch registry + validate resource type
        mcp_registry = await self.get_mcp_registry_by_id(id=registry_id)
        if mcp_registry.resource_type == ResourceType.EXTERNAL:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Registry {registry_id} resource_type is external, use external endpoint",
            )

        # 3. Extract connections from registry
        if (
            mcp_registry.mcp_server_json is None
            or mcp_registry.mcp_server_json.mcpServers is None
        ):
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Registry {registry_id} missing 'mcpServers' key",
            )

        mcp_connection = mcp_registry.mcp_server_json.mcpServers
        server_name = next(iter(mcp_connection))
        connection = dict(mcp_connection[server_name])  # copy to avoid mutating

        if connection.get("transport") is None:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Registry {registry_id} missing 'transport' key",
            )

        # 4. Inject backend auth headers
        headers = connection.get("headers", {})
        for auth_cfg in backend_server_auth_configs:
            backend_server = await self._backend_server_repository.find_by_id(
                item_id=auth_cfg.server_id
            )
            separator = core_settings.mcp_server_separator
            if auth_cfg.auth_config.type == AuthenticationType.BASIC:
                headers[f"{backend_server.system_name}{separator}username"] = (
                    auth_cfg.auth_config.username
                )
                headers[f"{backend_server.system_name}{separator}password"] = (
                    auth_cfg.auth_config.password
                )
            elif auth_cfg.auth_config.type == AuthenticationType.BEARER:
                headers[f"{backend_server.system_name}{separator}bearer_token"] = (
                    auth_cfg.auth_config.bearer_token
                )
            elif auth_cfg.auth_config.type == AuthenticationType.API_KEY:
                headers[
                    f"{backend_server.system_name}{separator}{auth_cfg.auth_config.api_key_name}"
                ] = auth_cfg.auth_config.api_key_value

        connection["headers"] = headers
        connections = {server_name: connection}

        # 5. Build agent
        (
            agent,
            tools,
            need_auth,
            pending_auth,
            mcp_server_config,
        ) = await self._build_playground_agent(
            user_id=user.id,
            connections=connections,
            llm_provider=llm_provider,
            llm_model=llm_model,
            llm_api_key_id=llm_api_key_id,
            checkpointer=checkpointer,
        )

        if not mcp_server_config:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"MCP server config not found for registry {registry_id}",
            )

        # 6. Handle OAuth authentication required
        if need_auth:
            need_auth_mcp_server: NeedAuthMCPServer = pending_auth[0]
            logger.warning(
                "MCP server %s requires authentication: %s",
                need_auth_mcp_server.server_id,
                need_auth_mcp_server.auth_url,
            )
            mcp_server = McpServer(
                server_id=mcp_server_config.server_id,
                server_name=mcp_registry.name,
                is_oauth_server=mcp_server_config.is_oauth_server,
                connected=False,
                tools=[],
                registry_id=mcp_registry.id,
                resource_type=mcp_registry.resource_type,
                transport_type=mcp_registry.transport_type,
                icon_url=mcp_registry.icon_url,
                auth_url=need_auth_mcp_server.auth_url,
                error_message=mcp_server_config.error_message,
            )
            return mcp_registry, mcp_server, None

        # 7. Cache
        if self._agent_cache is not None:
            await self._agent_cache.put(cache_key, agent)
            logger.info("Cached MCP registry playground agent for %s", registry_id)

        connected = not bool(mcp_server_config.error_message)

        mcp_server = McpServer(
            server_id=mcp_server_config.server_id,
            server_name=mcp_registry.name,
            is_oauth_server=mcp_server_config.is_oauth_server,
            connected=connected,
            tools=tools,
            registry_id=mcp_registry.id,
            resource_type=mcp_registry.resource_type,
            transport_type=mcp_registry.transport_type,
            icon_url=mcp_registry.icon_url,
            error_message=mcp_server_config.error_message,
        )

        return mcp_registry, mcp_server, agent

    async def validate_agent_initialized(
        self,
        registry_id: str,
        iss: str,
        sub: str,
    ) -> None:
        """Validate the playground agent is initialized."""
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST, details=f"User not found: {e}"
            )

        if self._agent_cache is not None:
            cached_agent = await self._get_cached_agent(
                registry_id=registry_id,
                user_id=user.id,
            )
            if cached_agent is None:
                raise CoreServiceException(
                    CoreError.AGENT_NOT_FOUND,
                    details=f"Cached agent not found in the cache for registry {registry_id} and user {user.id}. You should initialize the agent first.",
                )
            return
        else:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details="Cache not found in the server",
            )

    async def stream_playground_completion(
        self,
        *,
        registry_id: str,
        thread_id: str,
        iss: str,
        sub: str,
        prompt: str,
        llm_model: str | None = None,
        files: list[str] | None = None,
    ) -> AsyncGenerator[ServerSentEvent, None]:
        """Stream MCP registry playground completion as SSE events.

        You should validate the playground agent initialized before calling this method.
        ```python
        await mcp_registry_service.validate_agent_initialized(
            registry_id=registry_id,
            iss=oauth_user.iss,
            sub=oauth_user.sub,
        )
        ```

        Args:
            registry_id: MCP registry ID.
            thread_id: Thread ID.
            iss: OIDC issuer.
            sub: OIDC subject.
            prompt: Prompt.
            llm_model: LLM model name.
            files: List of file paths.

        Returns:
            Async generator of SSE events.
        """
        try:
            user = await self._user_repository.find_by_iss_sub(iss=iss, sub=sub)
        except ObjectNotFoundException as e:
            raise CoreServiceException(
                CoreError.BAD_REQUEST, details=f"User not found: {e}"
            )

        agent = await self._get_cached_agent(registry_id=registry_id, user_id=user.id)

        if agent is None:
            raise CoreServiceException(
                CoreError.AGENT_NOT_FOUND,
                details=f"MCP registry playground agent not found for: {registry_id} and user: {user.id}",
            )

        effective_model = llm_model or core_settings.default_model

        config = self._build_runnable_config(
            thread_id=thread_id,
            user_id=user.id,
            # llm_model=effective_model,
        )

        chat_files = []
        if files:
            chat_files = await self._get_chat_files_for_playground(files)
        messages = generate_multimodal_messages(chat_files, prompt, effective_model)
        inputs = {"messages": [HumanMessage(content=messages)]}

        async for event in stream_agent_events(
            agent=agent,
            thread_id=thread_id,
            # llm_model=effective_model,
            inputs=inputs,
            config=config,
        ):
            yield event

    async def refresh_mcp_registry(
        self,
        *,
        registry_id: str,
        updated_by: str,
    ) -> McpRegistry:
        """Refresh tools for an MCP registry by re-discovering from stored connections.

        Args:
            registry_id: MCP registry ID.
            updated_by: Username.

        Returns:
            McpRegistry with updated tools (non-persisted).
        """
        mcp_registry = await self.get_mcp_registry_by_id(id=registry_id)

        mcp_servers = (
            mcp_registry.mcp_server_json.mcpServers
            if mcp_registry.mcp_server_json
            else None
        )

        connections = {}
        if mcp_servers:
            for server_name, server_config in mcp_servers.items():
                connection = build_mcp_connection(
                    server_name, server_config, strict=False
                )
                if connection is not None:
                    connections[server_name] = connection

        tools, _ = await self._discover_tools_from_connections(connections)

        mcp_registry.tools = tools
        mcp_registry.updated_by = updated_by

        return mcp_registry

    # ──────────────────────────────────────────────────────────────────────
    # Private helpers
    # ──────────────────────────────────────────────────────────────────────

    # (field_name, default_value) — shared with McpServerInstanceService._TOOL_FIELDS
    _TOOL_FIELDS: list[tuple[str, Any]] = [
        ("name", "unknown-tool"),
        ("description", ""),
        ("return_direct", False),
        ("verbose", False),
        ("tags", None),
        ("metadata", None),
        ("handle_tool_error", False),
        ("handle_validation_error", False),
        ("response_format", None),
    ]

    @staticmethod
    def _safe_serialize_args_schema(schema_cls: Any) -> dict[str, Any]:
        """Safely serialize args_schema to a JSON Schema dict.

        Attempts ``model_json_schema()`` so the frontend receives the full
        JSON Schema (``properties``, ``$defs``, …).  If the call fails —
        e.g. because of a deprecated Pydantic config on a dynamically
        generated model — falls back to ``{}``.
        """
        if schema_cls is None:
            return {}
        if isinstance(schema_cls, dict):
            return schema_cls
        if hasattr(schema_cls, "model_json_schema"):
            try:
                return schema_cls.model_json_schema()
            except Exception:
                return {}
        return {}

    @staticmethod
    def _serialize_tool(tool: Any) -> dict[str, Any]:
        """Serialize a single MCP tool object to a plain dict.

        Unlike ``McpServerInstanceService._serialize_tool`` (which uses
        plain ``getattr`` for ``args_schema``), this method converts
        ``args_schema`` via ``_safe_serialize_args_schema`` so that
        dynamically-generated Pydantic models are safely turned into
        JSON Schema dicts for the frontend.
        """
        tool_dict = {
            field: getattr(tool, field, default)
            for field, default in McpRegistryService._TOOL_FIELDS
        }
        tool_dict["args_schema"] = McpRegistryService._safe_serialize_args_schema(
            getattr(tool, "args_schema", None)
        )
        return tool_dict

    @staticmethod
    def _is_auth_error(exc: BaseException) -> bool:
        """Check if an exception indicates an authentication failure (HTTP 401)."""
        error_str = str(exc).lower()
        return (
            "401" in error_str
            or "unauthorized" in error_str
            or "invalid_token" in error_str
        )

    @staticmethod
    def _detect_auth_error_in_exception(exc: Exception) -> bool:
        """Detect auth errors, unwrapping ExceptionGroups if needed."""
        if isinstance(exc, ExceptionGroup):
            return any(
                McpRegistryService._is_auth_error(sub_exc) for sub_exc in exc.exceptions
            )
        return McpRegistryService._is_auth_error(exc)

    async def _discover_tools_from_connections(
        self, connections: dict[str, Any]
    ) -> tuple[list[dict], list[dict]]:
        """Discover tools from MCP server connections.

        Returns:
            Tuple of (tools_list, errors_list).
            Each error dict contains: server_name, error, is_auth_error.
        """
        tools = []
        errors = []

        if not connections:
            return tools, errors

        total_servers = len(connections)
        successful_servers = 0
        failed_servers = 0

        logger.info("Starting tools extraction from %d MCP servers", total_servers)

        for server_name, connection in connections.items():
            server_start_time = time.time()
            try:
                # TODO: need to refactor using the UserMCPClientFactory
                single_client = MultiServerMCPClient({server_name: connection})
                raw_tools = await single_client.get_tools()

                for tool in raw_tools:
                    try:
                        tools.append(self._serialize_tool(tool))
                    except Exception as e:
                        logger.warning(
                            "Failed to serialize tool %s from server %s: %s",
                            getattr(tool, "name", "unknown"),
                            server_name,
                            e,
                        )
                        continue

                processing_time = time.time() - server_start_time
                successful_servers += 1
                logger.info(
                    "Extracted %d tools from server %s (%.2fs)",
                    len(raw_tools),
                    server_name,
                    processing_time,
                )
            except Exception as e:
                processing_time = time.time() - server_start_time
                failed_servers += 1
                is_auth = self._detect_auth_error_in_exception(e)
                errors.append(
                    {
                        "server_name": server_name,
                        "error": str(e),
                        "is_auth_error": is_auth,
                    }
                )
                logger.warning(
                    "Failed to extract tools from server %s (%.2fs, auth_error=%s): %s",
                    server_name,
                    processing_time,
                    is_auth,
                    e,
                )
                continue

        logger.info(
            "Tools extraction: %d/%d servers OK, %d failed, %d tools total",
            successful_servers,
            total_servers,
            failed_servers,
            len(tools),
        )

        return tools, errors

    async def _build_playground_agent(
        self,
        *,
        user_id: str,
        connections: dict[str, Any],
        llm_provider: str,
        llm_model: str,
        llm_api_key_id: str,
        checkpointer: InMemorySaver | None = None,
    ) -> tuple[
        CompiledStateGraph | None,
        list[BaseTool] | None,
        bool,
        list[NeedAuthMCPServer],
        MCPServerConfig | None,
    ]:
        """Build a playground agent from connections and LLM config.

        Returns:
            Tuple of (compiled agent graph, tool list, need_auth, pending_auth_servers, mcp_server_config).
        """
        # 1. Fetch LLM credentials
        try:
            user_credential = await self._user_credential_repository.find_by_id(
                item_id=llm_api_key_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"User credential not found: {llm_api_key_id}",
            )

        # 2. Fetch LLM provider
        try:
            llm_provider_id = await self._llm_provider_repository.get_id_by_key(
                key=llm_provider
            )
            llm_provider_entity = await self._llm_provider_repository.find_by_id(
                item_id=llm_provider_id
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"LLM provider not found: {llm_provider}",
            )

        # 3. Build LLMSpecData from credentials
        llm_spec_data = LLMSpecData(
            provider=llm_provider,
            base_url=llm_provider_entity.base_url,
            default_model_id=llm_model,
            api_key=user_credential.llm_api_key,
            aws_access_key_id=user_credential.aws_access_key_id,
            aws_secret_access_key=user_credential.aws_secret_access_key,
            aws_region_name=user_credential.region_name,
        )

        # 4. Convert connections to mcp_server_configs list
        mcp_server_json_configs: list[dict[str, Any]] = []
        for server_name, connection in connections.items():
            mcp_server_json_configs.append({server_name: dict(connection)})

        # 5. Build system prompt
        try:
            system_prompt_text = load_prompt(
                get_prompt_path(PromptFile.MCP_PLAYGROUND_AGENT)
            ).format(
                system_time=datetime.now(tz=UTC).isoformat(),
            )
        except Exception as e:
            logger.error("Error loading prompt: %s", e)
            system_prompt_text = (
                "You are a helpful assistant. Please answer the question."
            )

        # 6. Build SingleAgentSpecProfile via playground factory
        agent_spec_profile = build_playground_spec_profile(
            llm_spec_data=llm_spec_data,
            mcp_server_configs=mcp_server_json_configs,
            system_prompt=system_prompt_text,
        )

        # 7. Create SingleAgentWrapper and build agent
        wrapper = SingleAgentWrapper(
            agent_spec=agent_spec_profile,
            oauth_mcp_server_registry=self._oauth_mcp_server_registry,
            mcp_client_factory=self._mcp_client_factory,
            checkpointer=checkpointer,
        )

        # 8. Check MCP authentication
        (
            need_auth,
            pending_auth,
            mcp_server_configs,
        ) = await wrapper.need_mcp_authentication(user_id=user_id)
        if need_auth:
            return (
                None,
                None,
                True,
                pending_auth,
                mcp_server_configs[0] if mcp_server_configs else None,
            )

        # 9. Build agent
        agent = await wrapper.build_agent(user_id=user_id)

        # 10. Get tools from all MCP servers(only one server for now)
        tools: list[BaseTool] = []
        for config in mcp_server_configs:
            tools.extend(await wrapper.get_mcp_server_tools(config.server_id))

        return (
            agent,
            tools,
            False,
            [],
            mcp_server_configs[0],
        )

    # TODO: need to refactor later
    async def _initialize_agent_safely(self, init_coro, server_name: str) -> None:
        """Initialize agent with comprehensive error handling.

        Args:
            init_coro: Coroutine to await (e.g. agent initialization).
            server_name: Server name for error messages.

        Raises:
            CoreServiceException: With appropriate error based on exception type.
        """
        try:
            await init_coro
        except McpError as e:
            error_message, action_guidance = get_mcp_error_message(e, server_name)
            logger.error(
                "Failed to initialize MCP agent for '%s': %s",
                server_name,
                error_message,
            )
            raise CoreServiceException(
                CoreError.BAD_REQUEST, details=f"{error_message} {action_guidance}"
            )
        except TimeoutError:
            logger.error("MCP server timeout for '%s'", server_name)
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"MCP server '{server_name}' connection timeout.",
            )
        except Exception as e:
            if isinstance(e, ExceptionGroup):
                error_details = []
                connection_error = False
                timeout_error = False

                for sub_exc in e.exceptions:
                    exc_str = str(sub_exc)
                    if any(
                        s in exc_str
                        for s in (
                            "ConnectError",
                            "gaierror",
                            "nodename nor servname",
                            "Name or service not known",
                        )
                    ):
                        connection_error = True
                    elif "timeout" in exc_str.lower():
                        timeout_error = True
                        error_details.append(f"Connection timeout: {exc_str}")
                    else:
                        error_details.append(f"{type(sub_exc).__name__}: {exc_str}")

                if connection_error:
                    raise CoreServiceException(
                        CoreError.BAD_REQUEST,
                        details=f"Failed to connect to MCP server '{server_name}'. {' '.join(error_details)}",
                    )
                elif timeout_error:
                    raise CoreServiceException(
                        CoreError.INTERNAL_SERVER_ERROR,
                        details=f"MCP server '{server_name}' timeout. {' '.join(error_details)}",
                    )
                else:
                    raise CoreServiceException(
                        CoreError.INTERNAL_SERVER_ERROR,
                        details=f"Failed to initialize MCP agent for '{server_name}': {'; '.join(error_details)}",
                    )
            else:
                exc_str = str(e)
                if any(
                    s in exc_str
                    for s in ("ConnectError", "gaierror", "nodename nor servname")
                ):
                    raise CoreServiceException(
                        CoreError.BAD_REQUEST,
                        details=f"Failed to connect to MCP server '{server_name}': {exc_str}",
                    )
                elif "timeout" in exc_str.lower():
                    raise CoreServiceException(
                        CoreError.INTERNAL_SERVER_ERROR,
                        details=f"MCP server '{server_name}' timeout: {exc_str}",
                    )
                else:
                    raise CoreServiceException(
                        CoreError.INTERNAL_SERVER_ERROR,
                        details=f"Failed to initialize MCP agent for '{server_name}': {type(e).__name__}: {exc_str}",
                    )

    async def _get_cached_agent(
        self, registry_id: str, user_id: str
    ) -> CompiledStateGraph:
        """Retrieve a cached MCP registry playground agent."""
        cache_key = mcp_registry_playground_agent_cache_key(
            registry_id=registry_id, username=user_id
        )
        agent = None
        if self._agent_cache is not None:
            agent = await self._agent_cache.get(cache_key)

        if agent is None:
            logger.warning(
                "MCP registry playground agent not found in cache for registry %s and user %s",
                registry_id,
                user_id,
            )
        return agent

    def _build_runnable_config(
        self,
        *,
        thread_id: str,
        user_id: str,
        llm_model: str | None = None,
    ) -> dict[str, Any]:
        """Build a RunnableConfig dict for agent execution."""
        return {
            "configurable": {
                "thread_id": thread_id,
                "user_id": user_id,
                # "model": llm_model,  # TODO: check the compiled agent supports the dynamic model during runtime
            },
            "recursion_limit": core_settings.recursion_limit,
        }

    async def _get_chat_files_for_playground(
        self, file_ids: list[str]
    ) -> list[AgentChatFile]:
        """Fetch chat files and convert to agent ChatFile format."""
        chat_files = []
        for file_id in file_ids:
            if not file_id:
                continue
            try:
                entity = await self._chat_file_repository.find_by_id(item_id=file_id)
                chat_files.append(
                    AgentChatFile(
                        upload_url=entity.upload_url,
                        file_name=entity.file_name,
                        mime_type=entity.mime_type,
                        project_id=entity.project_id,
                    )
                )
            except Exception as e:
                logger.warning("Failed to fetch chat file %s: %s", file_id, e)
        return chat_files
