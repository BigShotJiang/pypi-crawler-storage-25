"""This module contains the service for the configuration."""

from __future__ import annotations

import logging

from motor.motor_asyncio import AsyncIOMotorClient

from axmp_ai_agent_core.agent.spec.types import TriggerType
from axmp_ai_agent_core.db.chat_memory_repository import ChatMemoryRepository
from axmp_ai_agent_core.db.llm_provider_repository import LlmProviderRepository
from axmp_ai_agent_core.db.user_credential_repository import UserCredentialRepository
from axmp_ai_agent_core.entity.chat_memory import ChatMemory
from axmp_ai_agent_core.entity.llm_provider import LlmProvider, LlmProviderStatus
from axmp_ai_agent_core.exception.db_exceptions import (
    InvalidObjectIDException,
    ObjectNotFoundException,
)
from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)
from axmp_ai_agent_core.filter.configuration_query import (
    ChatMemoryQueryParameters,
    LlmProviderQueryParameters,
)
from axmp_ai_agent_core.util.list_utils import MAX_LIMIT, SortDirection

logger = logging.getLogger(__name__)


class ConfigurationService:
    """The service for the configuration."""

    def __init__(
        self,
        client: AsyncIOMotorClient,
        llm_provider_repository: LlmProviderRepository,
        chat_memory_repository: ChatMemoryRepository,
        user_credential_repository: UserCredentialRepository,
    ):
        """Initialize the configuration service."""
        self._client = client
        self._llm_provider_repository: LlmProviderRepository = llm_provider_repository
        self._chat_memory_repository: ChatMemoryRepository = chat_memory_repository
        self._user_credential_repository: UserCredentialRepository = (
            user_credential_repository
        )

    async def get_triggers_simple(self) -> list[dict[str, str]]:
        """Get supported trigger types (simple)."""
        triggers = []
        for trigger_type in TriggerType:
            triggers.append({"name": trigger_type.value})
        return triggers
        # return [
        #     TriggerSimple(name="chatbot"),
        #     TriggerSimple(name="webhook"),
        #     TriggerSimple(name="scheduler"),
        # ]

    async def get_llm_provider_by_id(self, *, id: str) -> LlmProvider:
        """Get an LLM provider by ID."""
        try:
            llm_provider = await self._llm_provider_repository.find_by_id(item_id=id)
            return llm_provider
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"LLM provider not found: {id}",
            )

    async def get_llm_provider_by_key(self, *, key: str) -> LlmProvider | None:
        """Get an LLM provider by key."""
        try:
            provider_id = await self._llm_provider_repository.get_id_by_key(key=key)
            if provider_id:
                return await self._llm_provider_repository.find_by_id(
                    item_id=provider_id
                )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"LLM provider not found: {key}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {key}",
            )

        return None

    async def get_llm_providers(
        self,
        *,
        query_parameters: LlmProviderQueryParameters,
        page_number: int = 1,
        page_size: int = 10,
    ) -> list[LlmProvider]:
        """Get LLM providers with pagination."""
        return await self._llm_provider_repository.find_all(
            query_parameters=query_parameters,
            page_number=page_number,
            page_size=page_size,
        )

    async def get_llm_providers_without_pagination(
        self,
        *,
        query_parameters: LlmProviderQueryParameters,
    ) -> list[LlmProvider]:
        """Get LLM providers without pagination."""
        return await self._llm_provider_repository.find_all_without_pagination(
            query_parameters=query_parameters,
        )

    async def get_llm_providers_simple(
        self,
    ) -> list[LlmProvider]:
        """Get LLM providers (simple)."""
        try:
            query_parameters = LlmProviderQueryParameters(
                statuses=[LlmProviderStatus.ACTIVE],
                sort_field="updated_at",
                sort_direction=SortDirection.DESC,
            )

            llm_providers = (
                await self._llm_provider_repository.find_all_without_pagination(
                    query_parameters=query_parameters,
                    max_limit=MAX_LIMIT,
                    include_fields=["id", "key", "display_name", "icon_url", "status"],
                )
            )

            return llm_providers
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get simplified LLM providers: {e}",
            )

    async def get_llm_providers_count(
        self, *, query_parameters: LlmProviderQueryParameters
    ) -> int:
        """Get the total count of LLM providers."""
        return await self._llm_provider_repository.count(
            query_parameters=query_parameters
        )

    async def create_llm_provider(self, *, llm_provider: LlmProvider) -> str:
        """Create a new LLM provider."""
        return await self._llm_provider_repository.insert(item=llm_provider)

    async def modify_llm_provider(self, *, llm_provider: LlmProvider) -> LlmProvider:
        """Modify an LLM provider."""
        try:
            updated_llm_provider = await self._llm_provider_repository.update(
                item=llm_provider
            )
            return updated_llm_provider
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"LLM provider not found: {llm_provider.id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {llm_provider.id}",
            )

    async def remove_llm_provider_by_id(self, *, id: str) -> bool:
        """Remove an LLM provider by ID."""
        provider = await self._llm_provider_repository.find_by_id(item_id=id)
        count = await self._user_credential_repository.count_by_provider_key(
            provider_key=provider.key
        )
        if count > 0:
            raise CoreServiceException(
                CoreError.BAD_REQUEST,
                details=f"Cannot delete the LLM provider because it is still in use by {count} user credentials",
            )

        try:
            return await self._llm_provider_repository.delete(item_id=id)
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"LLM provider not found: {id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )

    async def set_llm_provider_status(
        self, *, id: str, status: LlmProviderStatus, updated_by: str | None = None
    ) -> LlmProvider:
        """Set the status of an LLM provider.

        This is a shared method used by activate/deactivate endpoints and PUT updates.
        Idempotent: if already in the target status, returns success without error.
        """
        try:
            llm_provider = await self._llm_provider_repository.find_by_id(item_id=id)
            previous_status = llm_provider.status
            llm_provider.status = status
            if updated_by:
                llm_provider.updated_by = updated_by
            updated_provider = await self._llm_provider_repository.update(
                item=llm_provider
            )
            logger.info(
                f"LLM provider status changed: id={id}, "
                f"previous_status={previous_status}, new_status={status.value}, "
                f"updated_by={updated_by}"
            )
            return updated_provider
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"LLM provider not found: {id}",
            )
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )

    async def activate_llm_provider(
        self, *, id: str, updated_by: str | None = None
    ) -> LlmProvider:
        """Activate an LLM provider (set status to ACTIVE)."""
        return await self.set_llm_provider_status(
            id=id, status=LlmProviderStatus.ACTIVE, updated_by=updated_by
        )

    async def deactivate_llm_provider(
        self, *, id: str, updated_by: str | None = None
    ) -> LlmProvider:
        """Deactivate an LLM provider (set status to INACTIVE)."""
        return await self.set_llm_provider_status(
            id=id, status=LlmProviderStatus.INACTIVE, updated_by=updated_by
        )

    # Chat Memory CRUD functions
    async def get_chat_memory_by_id(self, *, id: str) -> ChatMemory:
        """Get a chat memory by ID."""
        try:
            return await self._chat_memory_repository.find_by_id(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Chat memory not found: {id}",
            )

    async def get_chat_memory_by_is_default(self) -> ChatMemory:
        """Get a chat memory by is_default."""
        query_parameters = ChatMemoryQueryParameters(is_default=True)
        chat_memories = await self._chat_memory_repository.find_all_without_pagination(
            query_parameters=query_parameters,
            exclude_fields=["db_uri"],
        )
        if chat_memories and len(chat_memories) > 0:
            return chat_memories[0]
        else:
            raise CoreServiceException(
                CoreError.RETRIEVAL_FAILED,
                details="Failed to get the default chat memory",
            )

    async def get_chat_memories(
        self,
        *,
        query_parameters: ChatMemoryQueryParameters,
        page_number: int = 1,
        page_size: int = 10,
    ) -> list[ChatMemory]:
        """Get chat memories with pagination."""
        return await self._chat_memory_repository.find_all(
            query_parameters=query_parameters,
            page_number=page_number,
            page_size=page_size,
        )

    async def get_chat_memories_without_pagination(
        self,
        *,
        query_parameters: ChatMemoryQueryParameters,
    ) -> list[ChatMemory]:
        """Get chat memories without pagination."""
        return await self._chat_memory_repository.find_all_without_pagination(
            query_parameters=query_parameters,
        )

    async def get_chat_memories_simple(
        self,
    ) -> list[ChatMemory]:
        """Get chat memories (simple)."""
        try:
            query_parameters = ChatMemoryQueryParameters(
                sort_field="updated_at", sort_direction=SortDirection.DESC
            )

            chat_memories = (
                await self._chat_memory_repository.find_all_without_pagination(
                    query_parameters=query_parameters,
                    max_limit=MAX_LIMIT,
                    include_fields=[
                        "id",
                        "name",
                        "icon_url",
                        "memory_type",
                        "is_default",
                    ],
                )
            )

            return chat_memories
        except Exception as e:
            raise CoreServiceException(
                CoreError.INTERNAL_SERVER_ERROR,
                details=f"Failed to get simplified chat memories: {e}",
            )

    async def get_chat_memories_count(
        self, *, query_parameters: ChatMemoryQueryParameters
    ) -> int:
        """Get the total count of chat memories."""
        return await self._chat_memory_repository.count(
            query_parameters=query_parameters
        )

    async def create_chat_memory(self, *, chat_memory: ChatMemory) -> str:
        """Create a new chat memory."""
        return await self._chat_memory_repository.insert(item=chat_memory)

    async def modify_chat_memory(self, *, chat_memory: ChatMemory) -> ChatMemory:
        """Modify a chat memory."""
        async with await self._client.start_session() as session:
            async with session.start_transaction():
                try:
                    if chat_memory.is_default:
                        count = await self._chat_memory_repository.update_is_default_to_false(
                            session=session
                        )
                        logger.info(f"Updated {count} chat memories to false")

                    return await self._chat_memory_repository.update(
                        item=chat_memory, session=session
                    )
                except InvalidObjectIDException:
                    raise CoreServiceException(
                        CoreError.INVALID_OBJECTID,
                        details=f"Invalid object ID: {chat_memory.id}",
                    )
                except ObjectNotFoundException:
                    raise CoreServiceException(
                        CoreError.ID_NOT_FOUND,
                        details=f"Chat memory not found: {chat_memory.id}",
                    )

    async def remove_chat_memory_by_id(self, *, id: str) -> bool:
        """Remove a chat memory by ID."""
        try:
            chat_memory = await self._chat_memory_repository.find_by_id(item_id=id)
            if chat_memory.is_default:
                raise CoreServiceException(
                    CoreError.BAD_REQUEST,
                    details="Cannot delete the default chat memory",
                )

            return await self._chat_memory_repository.delete(item_id=id)
        except InvalidObjectIDException:
            raise CoreServiceException(
                CoreError.INVALID_OBJECTID,
                details=f"Invalid object ID: {id}",
            )
        except ObjectNotFoundException:
            raise CoreServiceException(
                CoreError.ID_NOT_FOUND,
                details=f"Chat memory not found: {id}",
            )
