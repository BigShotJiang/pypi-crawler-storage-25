"""Common instance synchronization utilities.

This module provides shared functionality for Agent and MCP Server instance
synchronization, reducing code duplication between services.
"""

from __future__ import annotations

import logging
from typing import Any, Protocol

from axmp_ai_agent_core.k8s.model.custom_resource import Phase


class ProvisionStatusLike(Protocol):
    """Protocol for provision status entities (duck typing)."""

    def model_copy(self, *, update: dict[str, Any]) -> Any:
        """Create a copy with updated fields."""
        ...


class ProvisionStatusRepositoryLike(Protocol):
    """Protocol for provision status repositories (duck typing)."""

    async def update(self, *, item: Any) -> Any:
        """Update a provision status item."""
        ...


async def handle_orphaned_instances[T: ProvisionStatusLike](
    *,
    db_status_map: dict[tuple[str, str, str], T],
    k8s_instance_keys: set[tuple[str, str, str]],
    repository: ProvisionStatusRepositoryLike,
    logger: logging.Logger,
    instance_type: str = "instance",
) -> int:
    """Mark orphaned instances as TERMINATED.

    Orphaned instances are those that exist in the database but no longer
    exist in Kubernetes clusters. This function marks them as TERMINATED
    to reflect their actual state.

    Args:
        db_status_map: Mapping of (cluster_id, name, namespace) to provision status
        k8s_instance_keys: Set of (cluster_id, name, namespace) keys from K8s
        repository: Repository to use for updates
        logger: Logger for logging messages
        instance_type: Type name for log messages (e.g., "Agent instance")

    Returns:
        Number of instances marked as TERMINATED
    """
    terminated_count = 0
    orphaned_keys = set(db_status_map.keys()) - k8s_instance_keys

    for key in orphaned_keys:
        try:
            status = db_status_map[key]
            updated_status = status.model_copy(update={"status": Phase.TERMINATED})
            await repository.update(item=updated_status)
            terminated_count += 1
            logger.info(
                f"Marked orphaned {instance_type} as TERMINATED: "
                f"cluster={key[0]}, name={key[1]}, namespace={key[2]}"
            )
        except Exception as e:
            logger.warning(
                f"Failed to mark orphaned {instance_type} as TERMINATED: "
                f"cluster={key[0]}, name={key[1]}, namespace={key[2]}, error={e}"
            )

    return terminated_count


def evict_stale_cache(
    *,
    status_cache: dict[tuple[str, str, str], Any],
    k8s_instance_keys: set[tuple[str, str, str]],
    logger: logging.Logger,
    instance_type: str = "instance",
) -> int:
    """Remove stale entries from the status cache.

    Stale entries are those that exist in the cache but no longer exist
    in Kubernetes clusters. Removing them prevents memory leaks and
    ensures cache accuracy.

    Args:
        status_cache: Status cache dictionary (modified in-place)
        k8s_instance_keys: Set of (cluster_id, name, namespace) keys from K8s
        logger: Logger for logging messages
        instance_type: Type name for log messages (e.g., "Agent")

    Returns:
        Number of evicted entries
    """
    stale_cache_keys = set(status_cache.keys()) - k8s_instance_keys

    for key in stale_cache_keys:
        del status_cache[key]

    if stale_cache_keys:
        logger.debug(
            f"Evicted {len(stale_cache_keys)} stale entries from {instance_type} status cache"
        )

    return len(stale_cache_keys)
