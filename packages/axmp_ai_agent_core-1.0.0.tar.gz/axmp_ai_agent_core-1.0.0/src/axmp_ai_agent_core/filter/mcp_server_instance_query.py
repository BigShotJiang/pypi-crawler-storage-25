"""Mcp server instance query."""

from enum import StrEnum

from pydantic import Field

from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class McpServerInstanceSortField(StrEnum):
    """Mcp server instance sort field enum."""

    NAME = "name"
    SYSTEM_NAME = "system_name"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"
    STATUS = "status"


class McpServerInstanceQueryParameters(BaseQueryParameters):
    """Mcp server instance query parameters."""

    keyword: str | None = Field(
        None, description="Search keyword for name, description"
    )
    cluster_id: str | None = Field(
        None, description="The cluster ID of the mcp server instance."
    )
    labels: list[str] | None = Field(
        None, description="The labels of the mcp server instance. e.g.) 'type:api'"
    )
    status: str | None = Field(
        None, description="The status of the mcp server instance."
    )
    created_by: str | None = Field(
        None, description="The created by of the mcp server instance."
    )
    updated_by: str | None = Field(
        None, description="The updated by of the mcp server instance."
    )
    namespace: str | None = Field(
        None, description="The namespace of the mcp server instance."
    )
    sort_field: McpServerInstanceSortField = Field(
        McpServerInstanceSortField.UPDATED_AT,
        description="The field to sort by. default: updated_at",
    )
