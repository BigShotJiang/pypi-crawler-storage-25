"""MCP server provision status query parameters."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class McpServerProvisionStatusSortField(StrEnum):
    """MCP server provision status sort fields."""

    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"
    PROFILE_ID = "profile_id"
    CLUSTER_ID = "cluster_id"
    NAME = "name"
    STATUS = "status"
    CLUSTER_NAME = "cluster_name"


class McpServerProvisionStatusQueryParameters(BaseQueryParameters):
    """MCP server provision status query parameters."""

    keyword: str | None = Field(
        None, description="Search keyword for profile_id, name, description"
    )
    profile_id: str | None = Field(None, description="Filter by profile ID")
    profile_version: int | None = Field(None, description="Filter by profile version")
    cluster_id: str | None = Field(
        None, description="Filter by K8s cluster ID (KubernetesConfig._id)"
    )
    instance_id: str | None = Field(
        None, description="Filter by unique instance ID (from label)"
    )
    is_published: bool | None = Field(
        None, description="Filter by published status to registry"
    )
    status: str | None = Field(
        None, description="Filter by instance phase status (e.g., Running, Pending)"
    )
    name: str | None = Field(None, description="Filter by K8s resource name")
    namespace: str | None = Field(None, description="Filter by K8s namespace")
