"""MCP Server Profile History query parameters."""

from enum import StrEnum

from axmp_ai_agent_core.filter.base_search_query import (
    BaseQueryParameters,
    SortDirection,
)


class McpServerProfileHistorySortField(StrEnum):
    """MCP Server Profile History sort field enum."""

    VERSION = "version"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class McpServerProfileHistoryQueryParameters(BaseQueryParameters):
    """MCP Server Profile History query parameters."""

    mcp_server_profile_id: str | None = None
    version: str | None = None
    created_by: str | None = None
    updated_by: str | None = None
    sort_field: McpServerProfileHistorySortField = (
        McpServerProfileHistorySortField.VERSION
    )
    sort_direction: SortDirection = SortDirection.DESC
