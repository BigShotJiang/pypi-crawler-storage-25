"""Agent profile provision status query parameters."""

from __future__ import annotations

from enum import StrEnum

from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class AgentProfileProvisionStatusSortField(StrEnum):
    """Agent profile provision status sort fields."""

    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"
    PROFILE_ID = "profile_id"
    CLUSTER_ID = "cluster_id"


class AgentProfileProvisionStatusQueryParameters(BaseQueryParameters):
    """Agent profile provision status query parameters."""

    keyword: str | None = None
    profile_id: str | None = None
    profile_version: int | None = None
    cluster_id: str | None = None
    status: str | None = None
