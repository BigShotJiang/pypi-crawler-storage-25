"""MCP Registry DTOs."""

from enum import StrEnum

from axmp_ai_agent_core.entity.mcp_registry import ResourceType, Status
from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


# McpRegistrySortField is used by router. so is it necessary to keep it here?
# if not, we can remove it and move it to the router in studio application code
class McpRegistrySortField(StrEnum):
    """MCP Registry sort field."""

    NAME = "name"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"
    CATEGORIES = "categories"
    VERSION = "version"


class McpRegistryQueryParameters(BaseQueryParameters):
    """MCP Registry query parameters."""

    keyword: str | None = None
    categories: list[str] | None = None
    resource_types: list[ResourceType] | None = None
    version: str | None = None
    status: Status | None = None
    created_by: str | None = None
    updated_by: str | None = None
    is_published: bool | None = None
