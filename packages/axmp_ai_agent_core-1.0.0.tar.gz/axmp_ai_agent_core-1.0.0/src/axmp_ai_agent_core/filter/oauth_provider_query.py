"""OAuth Provider query parameters."""

from enum import StrEnum

from axmp_ai_agent_core.entity.oauth_provider import (
    OAuthProviderStatus,
    OAuthProviderType,
)
from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class OAuthProviderSortField(StrEnum):
    """OAuth Provider sort field enum."""

    NAME = "name"
    SYSTEM_NAME = "system_name"
    PROVIDER_TYPE = "provider_type"
    STATUS = "status"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class OAuthProviderQueryParameters(BaseQueryParameters):
    """OAuth Provider query parameters."""

    keyword: str | None = None
    statuses: list[OAuthProviderStatus] | None = None
    provider_types: list[OAuthProviderType] | None = None
    created_by: str | None = None
    updated_by: str | None = None
    sort_field: OAuthProviderSortField = OAuthProviderSortField.CREATED_AT
