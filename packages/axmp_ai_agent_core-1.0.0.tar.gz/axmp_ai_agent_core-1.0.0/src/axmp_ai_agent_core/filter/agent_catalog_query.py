"""Agent catalog query."""

from enum import StrEnum
from typing import List

from axmp_ai_agent_core.entity.agent_catalog import (
    AgentType,
    ApplicationType,
    ResourceType,
)
from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class AgentCatalogSortField(StrEnum):
    """Agent catalog sort field."""

    NAME = "name"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class AgentCatalogQueryParameters(BaseQueryParameters):
    """Agent catalog query."""

    keyword: str | None = None  # Search in name, system_name, description
    resource_type: ResourceType | None = None
    agent_type: AgentType | None = None
    application_type: ApplicationType | None = None
    categories: List[str] | None = None
    version: str | None = None
    created_by: str | None = None
    updated_by: str | None = None
