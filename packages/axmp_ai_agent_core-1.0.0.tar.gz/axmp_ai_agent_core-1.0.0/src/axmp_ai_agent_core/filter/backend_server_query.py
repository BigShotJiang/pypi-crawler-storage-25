"""Backend server query."""

from enum import StrEnum

from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class BackendServerSortField(StrEnum):
    """Backend server sort field."""

    NAME = "name"
    VERSION = "version"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"


class BackendServerQueryParameters(BaseQueryParameters):
    """Backend server query."""

    keyword: str | None = None  # Search in name, system_name, description, labels
    name: str | None = None
    system_name: str | None = None
    version: int | None = None
    status: str | None = None  # active | inactive
    search: str | None = None  # General search term
    created_by: str | None = None
    updated_by: str | None = None
