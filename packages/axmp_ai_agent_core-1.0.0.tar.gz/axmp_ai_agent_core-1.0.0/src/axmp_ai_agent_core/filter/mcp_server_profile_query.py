"""MCP Server Profile query parameters."""

from enum import StrEnum

from axmp_ai_agent_core.agent.spec.types import ProfileStatus
from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class McpServerProfileSortField(StrEnum):
    """MCP Server Profile sort field enum."""

    NAME = "name"
    SYSTEM_NAME = "system_name"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"
    STATUS = "status"


class McpServerProfileQueryParameters(BaseQueryParameters):
    """MCP Server Profile query parameters."""

    keyword: str | None = None  # Search in name, system_name, description
    name: str | None = None  # Exact match for duplicate check
    system_name: str | None = None  # Exact match for duplicate check
    statuses: list[ProfileStatus] | None = None
    created_by: str | None = None
    updated_by: str | None = None
    sort_field: McpServerProfileSortField = McpServerProfileSortField.CREATED_AT
