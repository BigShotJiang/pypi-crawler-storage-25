"""Skill query parameters."""

from __future__ import annotations

from enum import StrEnum

from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class SkillSortField(StrEnum):
    """Skill sort fields."""

    NAME = "name"
    CREATED_AT = "created_at"
    UPDATED_AT = "updated_at"
    LIKE_COUNT = "like_count"


class SkillScope(StrEnum):
    """Skill scope tab filter."""

    MY = "MY"
    SHARED = "SHARED"
    PUBLIC = "PUBLIC"
    ALL = "ALL"


class SkillQueryParameters(BaseQueryParameters):
    """Skill query parameters."""

    keyword: str | None = None
    name: str | None = None
    system_name: str | None = None
    categories: list[str] | None = None
    shared_type: str | None = None
    scope: SkillScope | None = None
    current_username: str | None = None
    current_group_ids: list[str] | None = None
    exclude_shared_type: str | None = None
    created_by: str | None = None
    updated_by: str | None = None
