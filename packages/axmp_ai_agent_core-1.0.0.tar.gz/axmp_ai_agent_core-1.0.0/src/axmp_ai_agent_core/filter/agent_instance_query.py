"""Agent Instance query parameters."""

from enum import StrEnum

from pydantic import Field

from axmp_ai_agent_core.filter.base_search_query import BaseQueryParameters


class AgentInstanceSortField(StrEnum):
    """Agent instance sort field enum."""

    PROVISIONED_VERSION = "provisioned_version"
    STATUS = "status"
    RUNTIME_TYPE = "runtime_type"
    STARTED_AT = "started_at"
    STOPPED_AT = "stopped_at"
    LAST_ACTIVE_AT = "last_active_at"


class AgentInstanceQueryParameters(BaseQueryParameters):
    """Agent instance query parameters."""

    keyword: str | None = Field(
        None, description="Search keyword for name, description"
    )
    cluster_id: str | None = Field(
        None, description="The cluster ID of the agent instance."
    )
    labels: list[str] | None = Field(
        None, description="The labels of the agent instance. e.g.) 'type:api'"
    )
    status: str | None = Field(None, description="The status of the agent instance.")
    created_by: str | None = Field(
        None, description="The created by of the agent instance."
    )
    updated_by: str | None = Field(
        None, description="The updated by of the agent instance."
    )
    sort_field: AgentInstanceSortField = Field(
        AgentInstanceSortField.LAST_ACTIVE_AT,
        description="The field to sort by. default: last_active_at",
    )
