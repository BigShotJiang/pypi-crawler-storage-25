"""Base wrapper for agent implementations."""

from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from urllib.parse import urlencode

from langchain_core.tools import BaseTool
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.base import BaseStore
from langgraph.store.memory import InMemoryStore
from langgraph.types import Checkpointer

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig, NeedAuthMCPServer
from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.clients.factory import UserMCPClientFactory
from axmp_ai_agent_core.agent.spec.profile_base import SpecBaseNode, SpecBaseProfile
from axmp_ai_agent_core.setting import get_core_settings

logger = logging.getLogger(__name__)


def _extract_error_message(exc: BaseException) -> str:
    """Extract meaningful error messages from exceptions, unwrapping ExceptionGroup recursively."""
    if isinstance(exc, ExceptionGroup):
        messages = []
        for sub_exc in exc.exceptions:
            messages.append(_extract_error_message(sub_exc))
        return "; ".join(messages)
    return f"{type(exc).__name__}: {exc}"


class BaseAgentWrapper(ABC):
    """Abstract base wrapper for agent implementations."""

    def __init__(
        self,
        agent_spec: SpecBaseProfile,
        oauth_mcp_server_registry: OAuthMCPServerRegistry,
        mcp_client_factory: UserMCPClientFactory,
        checkpointer: Checkpointer | None = None,
        store: BaseStore | None = None,
    ):
        """Initialize BaseAgentWrapper."""
        self.agent_spec = agent_spec
        self.oauth_mcp_server_registry = oauth_mcp_server_registry
        self.mcp_client_factory = mcp_client_factory
        self.checkpointer = checkpointer or InMemorySaver()
        self.store = store or InMemoryStore()
        self.core_settings = get_core_settings()
        self._mcp_server_and_tools: dict[str, list[BaseTool]] = {}
        self._mcp_server_configs: list[MCPServerConfig] = []

    @property
    def mcp_server_and_tools(self) -> dict[str, list[BaseTool]]:
        """Get MCP server and tools."""
        return self._mcp_server_and_tools

    @property
    def mcp_server_configs(self) -> list[MCPServerConfig]:
        """Get MCP server configs."""
        return self._mcp_server_configs

    async def set_mcp_server_error_message(
        self, server_name: str, error_message: str
    ) -> None:
        """Set error message to MCP server config."""
        for mcp_server_config in self._mcp_server_configs:
            if mcp_server_config.server_id == server_name:
                mcp_server_config.error_message = error_message
                break

    async def add_mcp_server_tools(
        self, server_name: str, tools: list[BaseTool]
    ) -> None:
        """Add MCP server tools."""
        if server_name in self._mcp_server_and_tools:
            logger.warning(f"MCP server '{server_name}' already exists.")
        self._mcp_server_and_tools[server_name] = tools

    async def get_mcp_server_tools(self, server_name: str) -> list[BaseTool]:
        """Get MCP server tools."""
        if server_name not in self._mcp_server_and_tools:
            logger.warning(f"MCP server '{server_name}' not found.")
            return []
        return self._mcp_server_and_tools[server_name]

    async def need_mcp_authentication(
        self, user_id: str
    ) -> tuple[bool, list[NeedAuthMCPServer], list[MCPServerConfig] | None]:
        """Check MCP authentication status and register HTTP servers to OAuth registry.

        Iterate all MCP server nodes in the agent spec, register HTTP/streamable-HTTP
        servers to the OAuth registry, and return which servers still need authentication.

        Args:
            user_id: User ID to check MCP authentication status for.

        Returns:
            tuple[bool, list[NeedAuthMCPServer], list[MCPServerConfig] | None]:
                Tuple of (need_auth, pending_auth, mcp_server_configs).
                need_auth: True if there are pending auth servers, False otherwise.
                pending_auth: List of NeedAuthMCPServer objects for servers that need authentication.
                mcp_server_configs: List of MCPServerConfig objects for all MCP servers.
        """
        mcp_server_nodes = self.agent_spec.get_all_mcp_server_nodes()

        self._mcp_server_configs = []
        for mcp_server_node in mcp_server_nodes:
            if mcp_server_node.data is None:
                logger.warning(
                    "MCP server node '%s' has no data, skipping", mcp_server_node.id
                )
                continue

            _mcp_server_config = None
            try:
                _mcp_server_config = self._convert_mcpservers_to_mcp_server_configs(
                    mcp_server_node
                )
            except ValueError as e:
                logger.warning(
                    "MCP server node '%s' has invalid config, skipping: %s",
                    mcp_server_node.id,
                    e,
                )
                continue

            if _mcp_server_config is None:
                continue

            self._mcp_server_configs.append(_mcp_server_config)

        # set mcp server configs into oauth mcp server registry (saved only the http type mcp-servers)
        await self.oauth_mcp_server_registry.add_servers(self._mcp_server_configs)

        pending = await self.mcp_client_factory.get_pending_auth_servers(
            user_id=user_id, servers=self._mcp_server_configs
        )

        if pending:
            pending_auth = [
                NeedAuthMCPServer(
                    server_id=server.get("server_id"),
                    auth_url=(
                        f"{self.oauth_mcp_server_registry.auth_login_url}"
                        f"?{urlencode({'user_id': user_id, 'server_id': server.get('server_id', '')})}"
                    ),
                )
                for server in pending
            ]
            logger.warning(
                "User %s has %d unauthenticated server(s)", user_id, len(pending)
            )
            return True, pending_auth, self._mcp_server_configs
        else:
            return False, [], self._mcp_server_configs

    def _convert_mcpservers_to_mcp_server_configs(
        self, mcp_server_node: SpecBaseNode
    ) -> MCPServerConfig | None:
        """Convert MCP server node to MCPServerConfig.

        Args:
            mcp_server_node: MCP server node to convert.

        Returns:
            MCPServerConfig converted from the MCP server node.
        """
        mcp_connection = mcp_server_node.data.config
        if not mcp_connection:
            logger.warning(
                "MCP server node '%s' has empty config, skipping",
                mcp_server_node.id,
            )
            return None

        if not isinstance(mcp_connection, dict):
            logger.warning(
                "MCP server node '%s' has invalid config type, skipping",
                mcp_server_node.id,
            )
            return None

        server_name = next(iter(mcp_connection))
        connection = mcp_connection[server_name]
        if connection.get("transport") is None:
            raise ValueError(
                f"The MCP server {mcp_server_node.id} is not a valid MCP server "
                f"because it doesn't have 'transport' key",
            )

        return MCPServerConfig(server_id=server_name, **connection)

    @abstractmethod
    async def build_agent(self, user_id: str) -> CompiledStateGraph:
        """Build the agent graph.

        Args:
            user_id: User ID to build the agent for.

        Returns:
            CompiledStateGraph: Compiled state graph of the agent.
        """
