"""Wrapper for DeepAgent."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime

from deepagents import SubAgent, create_deep_agent
from deepagents.backends import StoreBackend
from deepagents.backends.utils import create_file_data
from langchain.agents.middleware import (
    HumanInTheLoopMiddleware,
    PIIMiddleware,
    SummarizationMiddleware,
    ToolRetryMiddleware,
)
from langchain.agents.middleware.types import AgentMiddleware
from langchain_core.tools import BaseTool
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.errors import GraphBubbleUp
from langgraph.graph.state import CompiledStateGraph

# from langgraph.store.base import BaseStore
from langgraph.store.memory import InMemoryStore
from langgraph.types import Checkpointer

from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.clients.factory import UserMCPClientFactory
from axmp_ai_agent_core.agent.spec.profile_node_data import (
    LLMSpecData,
    McpServerSpecData,
    MemorySpecData,
    SkillSpecData,
)
from axmp_ai_agent_core.agent.spec.profiles.deepagent_profile import (
    DeepAgentSpecNode,
    DeepAgentSpecProfile,
)
from axmp_ai_agent_core.agent.spec.types import NodeType
from axmp_ai_agent_core.agent.util.load_chat_model import load_chat_model
from axmp_ai_agent_core.agent.wrapper.base_agent_wrapper import (
    BaseAgentWrapper,
    _extract_error_message,
)

logger = logging.getLogger(__name__)


def _reraise_graph_interrupt(exc: Exception) -> str:
    """Re-raise GraphBubbleUp so LangGraph handles interrupts properly."""
    if isinstance(exc, GraphBubbleUp):
        raise exc
    return f"Tool failed with {type(exc).__name__}: {exc}. Please try again."


@dataclass
class DeepAgentContext:
    """Context for DeepAgent."""

    user_id: str


class DeepAgentWrapper(BaseAgentWrapper):
    """Wrapper for DeepAgent."""

    def __init__(
        self,
        agent_spec: DeepAgentSpecProfile,
        oauth_mcp_server_registry: OAuthMCPServerRegistry,
        mcp_client_factory: UserMCPClientFactory,
        checkpointer: Checkpointer | None = None,
        store: InMemoryStore | None = None,  # TODO: support other stores e.g.) Postgres
        context_schema: type[DeepAgentContext] | None = None,
    ):
        """Initialize DeepAgentWrapper."""
        super().__init__(
            agent_spec=agent_spec,
            oauth_mcp_server_registry=oauth_mcp_server_registry,
            mcp_client_factory=mcp_client_factory,
            checkpointer=checkpointer,
            store=store,
        )
        self.context_schema = context_schema

    async def build_agent(self, user_id: str) -> CompiledStateGraph:
        """Build the agent.

        Args:
            user_id: User ID to build the agent for.

        Returns:
            CompiledStateGraph: Compiled state graph of the agent(DeepAgent).
        """
        # 1st. get all subagent nodes
        # -----------------------------------------------------------------------
        subagent_nodes: list[DeepAgentSpecNode] = self.agent_spec.get_sub_agents()

        # 2nd. create each subagent using subagent spec nodes
        # -----------------------------------------------------------------------
        sub_agents: list[SubAgent] = []
        sub_agent_index = 0
        for subagent_node in subagent_nodes:
            # 2.1 - lookup the children nodes of subagent for each subagent spec node
            subagent_spec = subagent_node.data
            elements = self.agent_spec.get_elements_of_sub_agent(
                sub_agent_id=subagent_node.id
            )
            llm_spec: LLMSpecData | None = None
            mcp_specs: list[McpServerSpecData] = []
            skill_specs: list[SkillSpecData] = []

            for element in elements:
                if element.node_type == NodeType.LLM:
                    llm_spec = element.data
                elif element.node_type == NodeType.MCP_SERVER:
                    mcp_specs.append(element.data)
                elif element.node_type == NodeType.SKILL:
                    skill_specs.append(element.data)

            if llm_spec is None:
                raise ValueError(
                    f"Sub-agent '{subagent_spec.name}' has no LLM node connected."
                )

            logger.debug("Sub-agent '%s' LLM: %s", subagent_spec.name, llm_spec)
            logger.debug(
                "Sub-agent '%s' MCP count: %d", subagent_spec.name, len(mcp_specs)
            )
            logger.debug(
                "Sub-agent '%s' Skill count: %d", subagent_spec.name, len(skill_specs)
            )

            # 2.2 - middleware definitions of subagent for each subagent spec node
            middlewares: list[AgentMiddleware] = []
            middlewares.append(
                ToolRetryMiddleware(
                    max_retries=1,
                    on_failure=_reraise_graph_interrupt,
                    retry_on=lambda exc: not isinstance(exc, GraphBubbleUp),
                )
            )  # default middleware

            hitl_dump = {}
            if subagent_spec.hitl_middleware:
                hitl_dump = subagent_spec.hitl_middleware.model_dump()
                # NOTE: use the interrupt_on in the subagent spec node instead of middleware
                # middlewares.append(
                #     HumanInTheLoopMiddleware(
                #         interrupt_on=hitl_dump.get("interrupt_on") or {},
                #         description_prefix=hitl_dump.get("description_prefix") or "",
                #     )
                # )
            if subagent_spec.pii_middlewares:
                for pii_middleware in subagent_spec.pii_middlewares:
                    middlewares.append(
                        PIIMiddleware(
                            pii_type=pii_middleware.pii_type,
                            strategy=pii_middleware.strategy,
                            detector=pii_middleware.detector,
                            apply_to_input=pii_middleware.apply_to_input,
                            apply_to_output=pii_middleware.apply_to_output,
                            apply_to_tool_results=pii_middleware.apply_to_tool_results,
                        )
                    )
            if subagent_spec.summarization_middleware:
                middlewares.append(
                    SummarizationMiddleware(
                        model=subagent_spec.summarization_middleware.model,
                        trigger=subagent_spec.summarization_middleware.trigger,
                        keep=subagent_spec.summarization_middleware.keep,
                        trim_tokens_to_summarize=subagent_spec.summarization_middleware.trim_tokens_to_summarize,
                    )
                )

            # 2.3 - create the skill md and put into the store backend for each subagent spec node
            _profile_id = self.agent_spec.id or "default"
            subagent_skill_path = f"{self.core_settings.agent_skills_path}/{_profile_id}/sub_agent_{sub_agent_index}"
            for skill_spec in skill_specs:
                skill_file = f"{subagent_skill_path}/{skill_spec.name}/SKILL.md"

                self.store.put(
                    namespace=("filesystem",),
                    key=skill_file,
                    value=create_file_data(skill_spec.build_skill_markdown()),
                )

                for skill_file_data in skill_spec.files:
                    store_key = f"{subagent_skill_path}/{skill_spec.name}/{skill_file_data.dir_name}/{skill_file_data.filename}"
                    if not skill_file_data.file_path.exists():
                        logger.warning(
                            "Skill file not found, skipping: %s",
                            skill_file_data.file_path,
                        )
                        continue
                    content = skill_file_data.file_path.read_bytes()
                    self.store.put(
                        namespace=("filesystem",),
                        key=store_key,
                        value=create_file_data(
                            content.decode("utf-8", errors="replace")
                        ),
                    )

            # 2.4 - create the mcp server configs for each mcp spec node of subagent
            sub_agent_mcp_server_nodes = (
                self.agent_spec.get_mcp_server_nodes_of_sub_agent(
                    sub_agent_id=subagent_node.id
                )
            )
            sub_agent_mcp_server_configs = []
            for mcp_server_node in sub_agent_mcp_server_nodes:
                if mcp_server_node.data is None:
                    logger.warning(
                        "MCP server node '%s' has no data, skipping", mcp_server_node.id
                    )
                    continue

                _mcp_server_config = None
                try:
                    _mcp_server_config = self._convert_mcpservers_to_mcp_server_configs(
                        mcp_server_node=mcp_server_node
                    )
                except ValueError as e:
                    logger.warning(
                        "MCP server node '%s' has invalid config, skipping: %s",
                        mcp_server_node.id,
                        e,
                    )
                    continue

                if _mcp_server_config is None:
                    continue
                else:
                    sub_agent_mcp_server_configs.append(_mcp_server_config)

            multi_server_mcp_client: MultiServerMCPClient | None = None
            try:
                multi_server_mcp_client = await (
                    self.mcp_client_factory.create_shared_client(
                        servers=sub_agent_mcp_server_configs, fallback_user_id=user_id
                    )
                )
            except Exception as e:
                logger.warning(
                    "Failed to connect MCP servers for sub-agent '%s', continuing without MCP tools: %s",
                    subagent_spec.name,
                    e,
                )
                multi_server_mcp_client = None

            mcp_tools: list[BaseTool] = []
            if multi_server_mcp_client:
                for mcp_server_config in sub_agent_mcp_server_configs:
                    _tools: list[BaseTool] = []
                    try:
                        _tools = await multi_server_mcp_client.get_tools(
                            server_name=mcp_server_config.server_id
                        )
                    except Exception as e:
                        error_msg = _extract_error_message(e)
                        logger.warning(
                            "Failed to get MCP tools for sub-agent '%s', continuing without MCP tools: %s",
                            subagent_spec.name,
                            error_msg,
                        )
                        _tools = []

                        # NOTE: set error message to mcp server config of the wrapper's mcp server configs
                        await self.set_mcp_server_error_message(
                            server_name=mcp_server_config.server_id,
                            error_message=error_msg,
                        )

                    mcp_tools.extend(_tools)
                    await self.add_mcp_server_tools(
                        server_name=mcp_server_config.server_id, tools=_tools
                    )

            logger.info(
                "Sub-agent '%s' loaded %d MCP tool(s): %s",
                subagent_spec.name,
                len(mcp_tools),
                [t.name for t in mcp_tools],
            )

            # 2.5 - create subagent for each subagent spec node
            chat_model = load_chat_model(
                fully_specified_name=f"{llm_spec.provider}:{llm_spec.default_model_id}",
                api_key=llm_spec.api_key or None,
                base_url=llm_spec.base_url or None,
                aws_access_key_id=llm_spec.aws_access_key_id or None,
                aws_secret_access_key=llm_spec.aws_secret_access_key or None,
                aws_region_name=llm_spec.aws_region_name or None,
                max_tokens=llm_spec.max_tokens,
                temperature=llm_spec.temperature,
                max_retries=llm_spec.max_retries,
                request_timeout=llm_spec.request_timeout,
                streaming=llm_spec.streaming,
            )

            sub_agent = SubAgent(
                name=subagent_spec.name,
                description=subagent_spec.description,
                model=chat_model,
                tools=mcp_tools,
                system_prompt=f"{subagent_spec.system_prompt}\n\nSystem Time: {datetime.now(UTC).isoformat()}",
                middleware=middlewares,
                skills=[subagent_skill_path],
                interrupt_on=hitl_dump.get("interrupt_on") or {},
            )

            sub_agents.append(sub_agent)
            sub_agent_index += 1

        # 3rd. create main agent using the ai-agent spec node
        # -----------------------------------------------------------------------
        main_agent_node: DeepAgentSpecNode | None = self.agent_spec.get_main_agent()
        if main_agent_node is None:
            raise ValueError("Main agent spec node not found.")
        main_agent_spec = main_agent_node.data

        # 3.1 - lookup the children nodes of main agent
        elements = self.agent_spec.get_elements_of_main_agent(
            main_agent_id=main_agent_node.id
        )
        # 3.2 - get trigger spec node
        trigger_spec: DeepAgentSpecNode | None = self.agent_spec.get_trigger_node()
        if trigger_spec is None:
            raise ValueError("Trigger spec node not found.")
        llm_spec: LLMSpecData | None = None
        memory_spec: MemorySpecData | None = None
        mcp_specs: list[McpServerSpecData] = []
        skill_specs: list[SkillSpecData] = []

        for element in elements:
            if element.node_type == NodeType.LLM:
                llm_spec = element.data
            elif element.node_type == NodeType.MEMORY:
                memory_spec = element.data
            elif element.node_type == NodeType.MCP_SERVER:
                mcp_specs.append(element.data)
            elif element.node_type == NodeType.SKILL:
                skill_specs.append(element.data)

        logger.debug("Main Agent's Trigger: %s", trigger_spec)
        logger.debug("Main Agent's LLM: %s", llm_spec)
        logger.debug("Main Agent's Memory: %s", memory_spec)
        logger.debug("Main Agent's MCP count: %d", len(mcp_specs))
        logger.debug("Main Agent's Skill count: %d", len(skill_specs))

        if llm_spec is None:
            raise ValueError(
                f"Main agent '{main_agent_spec.name}' has no LLM node connected."
            )

        # 3.3 - middleware definitions of main agent
        middlewares = []
        middlewares.append(
            ToolRetryMiddleware(
                max_retries=2,
                on_failure=_reraise_graph_interrupt,
                retry_on=lambda exc: not isinstance(exc, GraphBubbleUp),
            )
        )  # default middleware

        if main_agent_spec.hitl_middleware:
            hitl_dump = main_agent_spec.hitl_middleware.model_dump()
            middlewares.append(
                HumanInTheLoopMiddleware(
                    interrupt_on=hitl_dump.get("interrupt_on") or {},
                    description_prefix=hitl_dump.get("description_prefix") or "",
                )
            )
        if main_agent_spec.pii_middlewares:
            for pii_middleware in main_agent_spec.pii_middlewares:
                middlewares.append(
                    PIIMiddleware(
                        pii_type=pii_middleware.pii_type,
                        strategy=pii_middleware.strategy,
                        detector=pii_middleware.detector or None,
                        apply_to_input=pii_middleware.apply_to_input or True,
                        apply_to_output=pii_middleware.apply_to_output or False,
                        apply_to_tool_results=pii_middleware.apply_to_tool_results
                        or False,
                    )
                )
        if main_agent_spec.summarization_middleware:
            middlewares.append(
                SummarizationMiddleware(
                    model=main_agent_spec.summarization_middleware.model,
                    trigger=main_agent_spec.summarization_middleware.trigger,
                    keep=main_agent_spec.summarization_middleware.keep,
                    trim_tokens_to_summarize=main_agent_spec.summarization_middleware.trim_tokens_to_summarize,
                )
            )

        # 3.4 - create the skill md and put into the store backend for main agent
        _profile_id = self.agent_spec.id or "default"
        main_agent_skill_path = (
            f"{self.core_settings.agent_skills_path}/{_profile_id}/main_agent"
        )
        for skill_spec in skill_specs:
            skill_file = f"{main_agent_skill_path}/{skill_spec.name}/SKILL.md"

            self.store.put(
                namespace=("filesystem",),
                key=skill_file,
                value=create_file_data(skill_spec.build_skill_markdown()),
            )

            for skill_file_data in skill_spec.files:
                store_key = f"{main_agent_skill_path}/{skill_spec.name}/{skill_file_data.dir_name}/{skill_file_data.filename}"
                if not skill_file_data.file_path.exists():
                    logger.warning(
                        "Skill file not found, skipping: %s",
                        skill_file_data.file_path,
                    )
                    continue
                content = skill_file_data.file_path.read_bytes()
                self.store.put(
                    namespace=("filesystem",),
                    key=store_key,
                    value=create_file_data(content.decode("utf-8", errors="replace")),
                )

        # 3.5 - create the mcp server configs for each mcp spec node of main agent
        main_agent_mcp_server_nodes = (
            self.agent_spec.get_mcp_server_nodes_of_main_agent(
                main_agent_id=main_agent_node.id
            )
        )
        main_agent_mcp_server_configs = []
        for mcp_server_node in main_agent_mcp_server_nodes:
            if mcp_server_node.data is None:
                logger.warning(
                    "MCP server node '%s' has no data, skipping", mcp_server_node.id
                )
                continue

            _mcp_server_config = None
            try:
                _mcp_server_config = self._convert_mcpservers_to_mcp_server_configs(
                    mcp_server_node=mcp_server_node
                )
            except ValueError as e:
                logger.warning(
                    "MCP server node '%s' has invalid config, skipping: %s",
                    mcp_server_node.id,
                    e,
                )
                continue

            if _mcp_server_config is None:
                continue
            else:
                main_agent_mcp_server_configs.append(_mcp_server_config)

        multi_server_mcp_client: MultiServerMCPClient | None = None
        try:
            multi_server_mcp_client = await (
                self.mcp_client_factory.create_shared_client(
                    servers=main_agent_mcp_server_configs, fallback_user_id=user_id
                )
            )
        except Exception as e:
            logger.warning(
                "Failed to connect MCP servers for main agent, continuing without MCP tools: %s",
                e,
            )
            multi_server_mcp_client = None

        mcp_tools: list[BaseTool] = []
        if multi_server_mcp_client:
            for mcp_server_config in main_agent_mcp_server_configs:
                _tools: list[BaseTool] = []
                try:
                    _tools = await multi_server_mcp_client.get_tools(
                        server_name=mcp_server_config.server_id
                    )
                except Exception as e:
                    error_msg = _extract_error_message(e)
                    logger.warning(
                        "Failed to get MCP tools for main agent, continuing without MCP tools: %s",
                        error_msg,
                    )
                    _tools = []
                    # NOTE: set error message to mcp server config of the wrapper's mcp server configs
                    await self.set_mcp_server_error_message(
                        server_name=mcp_server_config.server_id, error_message=error_msg
                    )

                mcp_tools.extend(_tools)
                await self.add_mcp_server_tools(
                    server_name=mcp_server_config.server_id, tools=_tools
                )

        logger.info(
            "Main agent '%s' loaded %d MCP tool(s): %s",
            main_agent_spec.name,
            len(mcp_tools),
            [t.name for t in mcp_tools],
        )

        # 4th. create deep agent using subagents
        chat_model = load_chat_model(
            fully_specified_name=f"{llm_spec.provider}:{llm_spec.default_model_id}",
            api_key=llm_spec.api_key or None,
            base_url=llm_spec.base_url or None,
            aws_access_key_id=llm_spec.aws_access_key_id or None,
            aws_secret_access_key=llm_spec.aws_secret_access_key or None,
            aws_region_name=llm_spec.aws_region_name or None,
            max_tokens=llm_spec.max_tokens,
            temperature=llm_spec.temperature,
            max_retries=llm_spec.max_retries,
            request_timeout=llm_spec.request_timeout,
            streaming=llm_spec.streaming,
        )

        deep_agent = create_deep_agent(
            name=main_agent_spec.name,
            model=chat_model,
            tools=mcp_tools,
            system_prompt=f"{main_agent_spec.system_prompt}\n\nSystem Time: {datetime.now(UTC).isoformat()}",
            middleware=middlewares,
            subagents=sub_agents,
            context_schema=self.context_schema,
            checkpointer=self.checkpointer,
            store=self.store,
            backend=(lambda rt: StoreBackend(rt)),
            skills=[main_agent_skill_path],
        )

        return deep_agent
