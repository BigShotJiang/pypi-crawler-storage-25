"""Wrapper for SingleAgent."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import UTC, datetime

from langchain.agents import create_agent
from langchain.agents.middleware import (
    HumanInTheLoopMiddleware,
    PIIMiddleware,
    SummarizationMiddleware,
    ToolRetryMiddleware,
)
from langchain.agents.middleware.types import AgentMiddleware
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.errors import GraphBubbleUp
from langgraph.graph.state import CompiledStateGraph
from langgraph.store.memory import InMemoryStore
from langgraph.types import Checkpointer

from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.clients.factory import UserMCPClientFactory
from axmp_ai_agent_core.agent.spec.profile_node_data import (
    LLMSpecData,
    McpServerSpecData,
    MemorySpecData,
    SkillSpecData,
)
from axmp_ai_agent_core.agent.spec.profiles.singleagent_profile import (
    SingleAgentSpecNode,
    SingleAgentSpecProfile,
)
from axmp_ai_agent_core.agent.spec.types import NodeType
from axmp_ai_agent_core.agent.util.load_chat_model import load_chat_model
from axmp_ai_agent_core.agent.wrapper.base_agent_wrapper import (
    BaseAgentWrapper,
    _extract_error_message,
)

logger = logging.getLogger(__name__)


def _reraise_graph_interrupt(exc: Exception) -> str:
    """Re-raise GraphBubbleUp so LangGraph handles interrupts properly."""
    if isinstance(exc, GraphBubbleUp):
        raise exc
    return f"Tool failed with {type(exc).__name__}: {exc}. Please try again."


@dataclass
class SingleAgentContext:
    """Context for SingleAgent."""

    user_id: str


class SingleAgentWrapper(BaseAgentWrapper):
    """Wrapper for SingleAgent."""

    def __init__(
        self,
        agent_spec: SingleAgentSpecProfile,
        oauth_mcp_server_registry: OAuthMCPServerRegistry,
        mcp_client_factory: UserMCPClientFactory,
        checkpointer: Checkpointer | None = None,
        store: InMemoryStore | None = None,
        context_schema: type[SingleAgentContext] | None = None,
    ):
        """Initialize SingleAgentWrapper."""
        super().__init__(
            agent_spec=agent_spec,
            oauth_mcp_server_registry=oauth_mcp_server_registry,
            mcp_client_factory=mcp_client_factory,
            checkpointer=checkpointer,
            store=store,
        )
        self.context_schema = context_schema

    async def build_agent(self, user_id: str) -> CompiledStateGraph:
        """Build the single agent.

        Args:
            user_id: User ID to build the agent for.

        Returns:
            CompiledStateGraph: Compiled state graph of the agent.

        Raises:
            ValueError: If the agent is misconfigured.
        """
        # 1st. Get the agent node
        agent_node: SingleAgentSpecNode | None = self.agent_spec.get_agent_node()
        if agent_node is None:
            raise ValueError("Agent spec node not found.")
        agent_spec_data = agent_node.data

        # 3rd. Get agent children and classify them
        elements = self.agent_spec.get_agent_elements()

        llm_spec: LLMSpecData | None = None
        memory_spec: MemorySpecData | None = None
        mcp_specs: list[McpServerSpecData] = []
        skill_specs: list[SkillSpecData] = []

        for element in elements:
            if element.node_type == NodeType.LLM:
                llm_spec = element.data
            elif element.node_type == NodeType.MEMORY:
                memory_spec = element.data
            elif element.node_type == NodeType.MCP_SERVER:
                mcp_specs.append(element.data)
            elif element.node_type == NodeType.SKILL:
                skill_specs.append(element.data)

        logger.debug("Agent's LLM: %s", llm_spec)
        logger.debug("Agent's Memory: %s", memory_spec)
        logger.debug("Agent's MCP count: %d", len(mcp_specs))
        logger.debug("Agent's Skill count: %d", len(skill_specs))

        if llm_spec is None:
            raise ValueError(
                f"Agent '{agent_spec_data.name}' has no LLM node connected."
            )

        # 4th. Build middlewares
        middlewares: list[AgentMiddleware] = []
        middlewares.append(
            ToolRetryMiddleware(
                max_retries=2,
                on_failure=_reraise_graph_interrupt,
                retry_on=lambda exc: not isinstance(exc, GraphBubbleUp),
            )
        )

        if agent_spec_data.hitl_middleware:
            middlewares.append(
                HumanInTheLoopMiddleware(
                    interrupt_on=agent_spec_data.hitl_middleware.interrupt_on or {},
                    description_prefix=agent_spec_data.hitl_middleware.description_prefix
                    or "",
                )
            )
        if agent_spec_data.pii_middlewares:
            for pii_middleware in agent_spec_data.pii_middlewares:
                middlewares.append(
                    PIIMiddleware(
                        pii_type=pii_middleware.pii_type,
                        strategy=pii_middleware.strategy,
                        detector=pii_middleware.detector or None,
                        apply_to_input=pii_middleware.apply_to_input or True,
                        apply_to_output=pii_middleware.apply_to_output or False,
                        apply_to_tool_results=pii_middleware.apply_to_tool_results
                        or False,
                    )
                )
        if agent_spec_data.summarization_middleware:
            middlewares.append(
                SummarizationMiddleware(
                    model=agent_spec_data.summarization_middleware.model,
                    trigger=agent_spec_data.summarization_middleware.trigger,
                    keep=agent_spec_data.summarization_middleware.keep,
                    trim_tokens_to_summarize=agent_spec_data.summarization_middleware.trim_tokens_to_summarize,
                )
            )

        # 5th. Store skills in InMemoryStore
        # NOTE: Langchain create_agent doesn't support skills parameter, so we don't store skills in InMemoryStore for now
        # TODO: uncomment when create_agent supports skills parameter
        # ----------------------------------------------------------------------------------------------------------------
        # _profile_id = self.agent_spec.id or "default"
        # agent_skill_path = (
        #     f"{self.core_settings.agent_skills_path}/{_profile_id}/single_agent"
        # )
        # for skill_spec in skill_specs:
        #     skill_file = f"{agent_skill_path}/{skill_spec.name}/SKILL.md"

        #     self.store.put(
        #         namespace=("filesystem",),
        #         key=skill_file,
        #         value=create_file_data(skill_spec.build_skill_markdown()),
        #     )

        #     for skill_file_data in skill_spec.files:
        #         store_key = f"{agent_skill_path}/{skill_spec.name}/{skill_file_data.dir_name}/{skill_file_data.filename}"
        #         if not skill_file_data.file_path.exists():
        #             logger.warning(
        #                 "Skill file not found, skipping: %s",
        #                 skill_file_data.file_path,
        #             )
        #             continue
        #         content = skill_file_data.file_path.read_bytes()
        #         self.store.put(
        #             namespace=("filesystem",),
        #             key=store_key,
        #             value=create_file_data(content.decode("utf-8", errors="replace")),
        #         )
        # ----------------------------------------------------------------------------------------------------------------

        # 6th. Create MCP client and get tools
        mcp_server_nodes = self.agent_spec.get_all_mcp_server_nodes()
        mcp_server_configs = []
        for mcp_server_node in mcp_server_nodes:
            if mcp_server_node.data is None:
                logger.warning(
                    "MCP server node '%s' has no data, skipping", mcp_server_node.id
                )
                continue

            _mcp_server_config = None
            try:
                _mcp_server_config = self._convert_mcpservers_to_mcp_server_configs(
                    mcp_server_node=mcp_server_node
                )
            except ValueError as e:
                logger.warning(
                    "MCP server node '%s' has invalid config, skipping: %s",
                    mcp_server_node.id,
                    e,
                )
                continue

            if _mcp_server_config is None:
                continue
            else:
                mcp_server_configs.append(_mcp_server_config)

        multi_server_mcp_client: MultiServerMCPClient | None = None
        try:
            multi_server_mcp_client = await (
                self.mcp_client_factory.create_shared_client(
                    servers=mcp_server_configs, fallback_user_id=user_id
                )
            )
        except Exception as e:
            logger.warning(
                "Failed to connect MCP servers for agent, continuing without MCP tools: %s",
                e,
            )
            multi_server_mcp_client = None

        mcp_tools = []
        if multi_server_mcp_client:
            for mcp_server_config in mcp_server_configs:
                _tools = []
                try:
                    _tools = await multi_server_mcp_client.get_tools(
                        server_name=mcp_server_config.server_id
                    )
                except Exception as e:
                    error_msg = _extract_error_message(e)
                    logger.warning(
                        "Failed to get MCP tools for agent '%s', continuing without MCP tools: %s",
                        agent_spec_data.name,
                        error_msg,
                    )
                    _tools = []
                    # NOTE: set error message to mcp server config of the wrapper's mcp server configs
                    await self.set_mcp_server_error_message(
                        server_name=mcp_server_config.server_id, error_message=error_msg
                    )

                mcp_tools.extend(_tools)
                await self.add_mcp_server_tools(
                    server_name=mcp_server_config.server_id, tools=_tools
                )

        logger.info(
            "Agent '%s' loaded %d MCP tool(s): %s",
            agent_spec_data.name,
            len(mcp_tools),
            [t.name for t in mcp_tools],
        )

        # 7th. Create the single agent
        chat_model = load_chat_model(
            fully_specified_name=f"{llm_spec.provider}:{llm_spec.default_model_id}",
            api_key=llm_spec.api_key or None,
            base_url=llm_spec.base_url or None,
            aws_access_key_id=llm_spec.aws_access_key_id or None,
            aws_secret_access_key=llm_spec.aws_secret_access_key or None,
            aws_region_name=llm_spec.aws_region_name or None,
            max_tokens=llm_spec.max_tokens,
            temperature=llm_spec.temperature,
            max_retries=llm_spec.max_retries,
            request_timeout=llm_spec.request_timeout,
            streaming=llm_spec.streaming,
        )

        agent = create_agent(
            name=agent_spec_data.name,
            model=chat_model,
            tools=mcp_tools,
            middleware=middlewares,
            context_schema=self.context_schema,
            checkpointer=self.checkpointer,
            store=self.store,
            system_prompt=f"{agent_spec_data.system_prompt}\n\nSystem Time: {datetime.now(UTC).isoformat()}",
        )

        return agent
