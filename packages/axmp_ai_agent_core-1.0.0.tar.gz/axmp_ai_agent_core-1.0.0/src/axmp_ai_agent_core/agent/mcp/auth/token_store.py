"""Token storage utilities for OAuth authentication."""

from __future__ import annotations

import logging

from fastmcp.client.auth.oauth import TokenStorageAdapter
from key_value.aio.protocols.key_value import AsyncKeyValue
from key_value.aio.wrappers.prefix_keys import PrefixKeysWrapper
from mcp.shared.auth import OAuthToken

logger = logging.getLogger(__name__)


class UserTokenStoreFactory:
    """Factory for creating per-user token storage adapters.

    Uses PrefixKeysWrapper to namespace tokens by user_id, so each user's
    tokens are isolated within the shared encrypted storage backend.
    """

    def __init__(self, base_store: AsyncKeyValue) -> None:
        """Initialize UserTokenStoreFactory."""
        self._base_store = base_store

    def get_user_store(self, user_id: str) -> AsyncKeyValue:
        """Get a namespaced key-value store for a specific user."""
        return PrefixKeysWrapper(self._base_store, prefix=f"user:{user_id}:")

    def get_token_storage_adapter(
        self, user_id: str, server_url: str
    ) -> TokenStorageAdapter:
        """Get a TokenStorageAdapter scoped to a specific user and server."""
        user_store = self.get_user_store(user_id)
        return TokenStorageAdapter(async_key_value=user_store, server_url=server_url)

    async def get_user_token(self, user_id: str, server_url: str) -> OAuthToken | None:
        """Get a user's token for a server."""
        adapter = self.get_token_storage_adapter(user_id, server_url)
        return await adapter.get_tokens()

    async def has_valid_token(self, user_id: str, server_url: str) -> bool:
        """Check if a user has a stored token for a server."""
        token = await self.get_user_token(user_id, server_url)
        return token is not None
