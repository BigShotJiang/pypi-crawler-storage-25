"""Token endpoint authentication utilities for OAuth."""

from __future__ import annotations

import base64
from urllib.parse import quote


def prepare_token_auth(
    client_id: str,
    client_secret: str | None,
    auth_method: str | None,
    data: dict,
    headers: dict,
) -> tuple[dict, dict]:
    """Apply token endpoint authentication per RFC 6749 Section 2.3.

    Handles:
    - client_secret_basic: HTTP Basic auth header
    - client_secret_post: client_secret in POST body
    - none: no additional authentication (public clients)

    Args:
        client_id: OAuth client ID.
        client_secret: OAuth client secret (may be None for public clients).
        auth_method: Token endpoint auth method from client registration.
        data: POST body dict (may be mutated).
        headers: HTTP headers dict (may be mutated).

    Returns:
        Tuple of (data, headers) with authentication applied.
    """
    if auth_method == "client_secret_basic" and client_secret:
        credentials = f"{quote(client_id)}:{quote(client_secret)}"
        headers["Authorization"] = (
            f"Basic {base64.b64encode(credentials.encode()).decode()}"
        )
        data = {k: v for k, v in data.items() if k != "client_secret"}
    elif auth_method == "client_secret_post" and client_secret:
        data["client_secret"] = client_secret
    # else: auth_method == "none" or no secret — no extra auth
    return data, headers
