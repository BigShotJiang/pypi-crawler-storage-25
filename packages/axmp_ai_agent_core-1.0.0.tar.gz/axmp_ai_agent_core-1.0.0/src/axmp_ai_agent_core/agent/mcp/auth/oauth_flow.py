"""OAuth flow manager for web-based multi-user authentication."""

from __future__ import annotations

import logging
import secrets
from urllib.parse import urlencode

import httpx
from key_value.aio.adapters.pydantic import PydanticAdapter
from key_value.aio.stores.base import BaseStore
from mcp.client.auth.oauth2 import PKCEParameters
from mcp.shared.auth import OAuthToken

from axmp_ai_agent_core.agent.mcp.auth.models import OAuthFlowState
from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.auth.token_store import UserTokenStoreFactory
from axmp_ai_agent_core.agent.mcp.auth.utils import prepare_token_auth
from axmp_ai_agent_core.setting import get_core_settings

logger = logging.getLogger(__name__)

# Maximum number of expired flows to clean up per sweep
_CLEANUP_BATCH_SIZE = 50


class OAuthFlowManager:
    """Manages OAuth authorization code flows for web-based multi-user auth.

    Handles:
    - Generating authorization URLs (start_flow)
    - Processing OAuth callbacks (handle_callback)
    - Token exchange and storage
    """

    def __init__(
        self,
        registry: OAuthMCPServerRegistry,
        token_store_factory: UserTokenStoreFactory,
        callback_redirect_uris: list[str],
        base_store: BaseStore | None = None,
    ) -> None:
        """Initialize the OAuth flow manager."""
        self._registry = registry
        self._token_store_factory = token_store_factory
        self._callback_redirect_uri = callback_redirect_uris[0]
        self._pending_flows: dict[str, OAuthFlowState] = {}
        core_settings = get_core_settings()
        self._pending_flows_storage: PydanticAdapter | None = (
            PydanticAdapter(
                default_collection=core_settings.mcp_oauth_pending_flows_collection,
                key_value=base_store,
                pydantic_model=OAuthFlowState,
                raise_on_validation_error=True,
            )
            if base_store is not None
            else None
        )

        self._core_settings = get_core_settings()

    @property
    def registry(self) -> OAuthMCPServerRegistry:
        """Get the registry."""
        return self._registry

    @property
    def token_store_factory(self) -> UserTokenStoreFactory:
        """Get the token store factory."""
        return self._token_store_factory

    @property
    def callback_redirect_uri(self) -> str:
        """Get the callback redirect URI."""
        return self._callback_redirect_uri

    def _cleanup_expired_flows(self) -> None:
        """Remove expired pending flows to prevent memory leaks.

        Skipped when Redis storage is available (TTL handles expiration).
        """
        if self._pending_flows_storage:
            return
        expired_keys = [k for k, v in self._pending_flows.items() if v.is_expired()][
            :_CLEANUP_BATCH_SIZE
        ]
        for key in expired_keys:
            del self._pending_flows[key]
        if expired_keys:
            logger.debug("Cleaned up %d expired OAuth flows", len(expired_keys))

    async def start_flow(
        self, user_id: str, server_id: str, referer: str | None = None
    ) -> str:
        """Start an OAuth authorization flow and return the authorization URL.

        Args:
            user_id: Unique user identifier.
            server_id: MCP server identifier.
            referer: Referer URL to redirect to after successful authentication.

        Returns:
            Authorization URL to redirect the user's browser to.
        """
        # 0. Lazy cleanup of expired flows
        self._cleanup_expired_flows()

        # 0.1 Check if server requires OAuth via discovery
        discovery = await self._registry.discover(server_id)
        if not discovery.requires_oauth:
            raise ValueError(
                f"Server '{server_id}' does not require OAuth authentication. "
                f"PRM discovery indicates OAuth is not needed."
            )

        oauth_metadata = discovery.oauth_metadata
        client_info = discovery.client_info

        if not oauth_metadata:
            raise ValueError(f"No OAuth metadata discovered for server '{server_id}'")
        if not client_info or not client_info.client_id:
            raise ValueError(
                f"No client info available for server '{server_id}'. "
                f"Dynamic Client Registration (DCR) is not supported by this server. "
                f"Please configure client_id and client_secret manually in the "
                f"MCP server profile."
            )

        # 2. Generate PKCE parameters
        pkce = PKCEParameters.generate()

        # 3. Generate state parameter
        state = secrets.token_urlsafe(32)

        # 4. Build redirect URI
        redirect_uri = self._callback_redirect_uri

        # 5. Build authorization URL
        authorization_endpoint = str(oauth_metadata.authorization_endpoint)
        params = {
            "response_type": "code",
            "client_id": client_info.client_id,
            "redirect_uri": redirect_uri,
            "state": state,
            "code_challenge": pkce.code_challenge,
            "code_challenge_method": "S256",
        }

        # Add scope from DCR client info if available
        if client_info.scope:
            params["scope"] = client_info.scope

        authorization_url = f"{authorization_endpoint}?{urlencode(params)}"

        logger.debug(
            "Authorization URL for user=%s server=%s: %s",
            user_id,
            server_id,
            authorization_url,
        )

        logger.debug("Redirect URI: %s", redirect_uri)
        logger.debug("Client ID (from DCR/static): %s", client_info.client_id)

        # 6. Store pending flow state
        flow_state = OAuthFlowState(
            user_id=user_id,
            server_id=server_id,
            state=state,
            code_verifier=pkce.code_verifier,
            redirect_uri=redirect_uri,
            oauth_metadata=oauth_metadata,
            client_info=client_info,
            referer=referer,
        )
        if self._pending_flows_storage:
            await self._pending_flows_storage.put(key=state, value=flow_state, ttl=600)
        else:
            self._pending_flows[state] = flow_state

        logger.info("OAuth flow started for user=%s server=%s", user_id, server_id)
        return authorization_url

    async def handle_callback(
        self, code: str, state: str
    ) -> tuple[str, str, str | None]:
        """Handle OAuth callback: exchange code for tokens and store them.

        Args:
            code: Authorization code from the OAuth provider.
            state: State parameter to look up the pending flow.

        Returns:
            Tuple of (user_id, server_id, referer).
        """
        # 1. Look up and validate pending flow
        if self._pending_flows_storage:
            flow_state = await self._pending_flows_storage.get(key=state)
            if flow_state:
                # Atomic ownership: if delete returns False, another request
                # already consumed this state (replay attack prevention).
                deleted = await self._pending_flows_storage.delete(key=state)
                if not deleted:
                    flow_state = None
        else:
            flow_state = self._pending_flows.pop(state, None)
        if not flow_state:
            raise ValueError("Invalid or expired OAuth state parameter")

        if flow_state.is_expired():
            raise ValueError("OAuth flow has expired (TTL exceeded)")

        # 2. Build token exchange request
        oauth_metadata = flow_state.oauth_metadata
        client_info = flow_state.client_info
        token_endpoint = str(oauth_metadata.token_endpoint)

        data: dict = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": flow_state.redirect_uri,
            "client_id": client_info.client_id,
            "code_verifier": flow_state.code_verifier,
        }
        headers: dict = {"Content-Type": "application/x-www-form-urlencoded"}

        # 3. Apply token endpoint authentication
        data, headers = prepare_token_auth(
            client_id=client_info.client_id,
            client_secret=client_info.client_secret,
            auth_method=client_info.token_endpoint_auth_method,
            data=data,
            headers=headers,
        )

        # 4. Exchange code for tokens
        async with httpx.AsyncClient(
            verify=self._core_settings.http_ssl_verify
        ) as client:
            resp = await client.post(token_endpoint, data=data, headers=headers)
            if resp.status_code != 200:
                raise ValueError(
                    f"Token exchange failed: {resp.status_code} {resp.text}"
                )

            token = OAuthToken.model_validate_json(resp.content)

        # 5. Store tokens and client info
        server_config = await self._registry.get_server(flow_state.server_id)
        adapter = self._token_store_factory.get_token_storage_adapter(
            user_id=flow_state.user_id,
            server_url=server_config.url,
        )
        await adapter.set_tokens(token)
        await adapter.set_client_info(client_info)

        logger.info(
            "OAuth callback handled: user=%s server=%s",
            flow_state.user_id,
            flow_state.server_id,
        )
        return flow_state.user_id, flow_state.server_id, flow_state.referer
