"""FastAPI router for OAuth authentication endpoints.

@Deprecated: This router is deprecated and will be removed in a future version.
Plz implement OAuth flow in the MCP server itself in the application using this router as a reference.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from axmp_ai_agent_core.agent.mcp.auth.models import ServerAuthStatus, UserAuthStatus
from axmp_ai_agent_core.agent.mcp.auth.oauth_flow import OAuthFlowManager

logger = logging.getLogger(__name__)

router = APIRouter(tags=["mcp-auth"])


def _base_html(
    *,
    title: str,
    page_title: str,
    subtitle: str,
    bg_gradient: str,
    icon_gradient: str,
    icon_svg: str,
    body_content: str,
    btn_gradient: str,
    btn_shadow_color: str,
) -> str:
    """Render a styled page with a close button."""
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{page_title}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, {bg_gradient});
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }}
        .card {{
            background: white;
            border-radius: 16px;
            padding: 48px 40px;
            text-align: center;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.15);
            max-width: 420px;
            width: 90%;
            animation: slideUp 0.5s ease-out;
        }}
        @keyframes slideUp {{
            from {{ opacity: 0; transform: translateY(20px); }}
            to {{ opacity: 1; transform: translateY(0); }}
        }}
        .icon {{
            width: 72px;
            height: 72px;
            background: linear-gradient(135deg, {icon_gradient});
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            animation: scaleIn 0.4s ease-out 0.2s both;
        }}
        @keyframes scaleIn {{
            from {{ transform: scale(0); }}
            to {{ transform: scale(1); }}
        }}
        .icon svg {{
            width: 36px;
            height: 36px;
            stroke: white;
            stroke-width: 3;
            fill: none;
        }}
        h1 {{
            font-size: 24px;
            color: #1a1a2e;
            margin-bottom: 8px;
            font-weight: 700;
        }}
        .subtitle {{
            color: #6b7280;
            font-size: 15px;
            margin-bottom: 32px;
            line-height: 1.5;
        }}
        .info {{
            background: #f8fafc;
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 32px;
            text-align: left;
        }}
        .info-row {{
            display: flex;
            justify-content: space-between;
            padding: 6px 0;
            font-size: 13px;
        }}
        .info-label {{
            color: #9ca3af;
            font-weight: 500;
        }}
        .info-value {{
            color: #374151;
            font-weight: 600;
        }}
        .error-detail {{
            background: #fef2f2;
            border: 1px solid #fecaca;
            border-radius: 10px;
            padding: 16px;
            margin-bottom: 32px;
            text-align: left;
            color: #991b1b;
            font-size: 13px;
            word-break: break-word;
        }}
        .close-btn {{
            background: linear-gradient(135deg, {btn_gradient});
            color: white;
            border: none;
            border-radius: 10px;
            padding: 14px 48px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.15s, box-shadow 0.15s;
            width: 100%;
        }}
        .close-btn:hover {{
            transform: translateY(-1px);
            box-shadow: 0 6px 20px {btn_shadow_color};
        }}
        .close-btn:active {{
            transform: translateY(0);
        }}
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">
            <svg viewBox="0 0 24 24">{icon_svg}</svg>
        </div>
        <h1>{title}</h1>
        <p class="subtitle">{subtitle}</p>
        {body_content}
        <button class="close-btn" onclick="window.close()">Close</button>
    </div>
</body>
</html>"""


def _success_html(user_id: str, server_id: str) -> str:
    """Render a success page after authentication."""
    from html import escape

    return _base_html(
        title="Authentication Complete",
        page_title="Authentication Complete",
        subtitle="OAuth authentication completed successfully.<br>You may close this window.",
        bg_gradient="#667eea 0%, #764ba2 100%",
        icon_gradient="#4ade80, #22c55e",
        icon_svg='<polyline points="20 6 9 17 4 12"></polyline>',
        body_content=f"""<div class="info">
            <div class="info-row">
                <span class="info-label">User</span>
                <span class="info-value">{escape(user_id)}</span>
            </div>
            <div class="info-row">
                <span class="info-label">Server</span>
                <span class="info-value">{escape(server_id)}</span>
            </div>
        </div>""",
        btn_gradient="#667eea 0%, #764ba2 100%",
        btn_shadow_color="rgba(102, 126, 234, 0.4)",
    )


def _error_html(title: str, detail: str) -> str:
    """Render an error page with a close button."""
    from html import escape

    return _base_html(
        title=escape(title),
        page_title="Authentication Failed",
        subtitle="An error occurred during authentication.",
        bg_gradient="#f87171 0%, #dc2626 100%",
        icon_gradient="#f87171, #dc2626",
        icon_svg='<line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line>',
        body_content=f'<div class="error-detail">{escape(detail)}</div>',
        btn_gradient="#6b7280 0%, #4b5563 100%",
        btn_shadow_color="rgba(107, 114, 128, 0.4)",
    )


@router.get("/mcp-auth/login")
async def login(
    request: Request,
    user_id: str = Query(..., description="Unique user identifier"),
    server_id: str = Query(..., description="MCP server identifier"),
) -> RedirectResponse:
    """Start OAuth login flow — redirects user's browser to the authorization server."""
    flow_manager: OAuthFlowManager = request.app.state.oauth_flow_manager

    try:
        authorization_url = await flow_manager.start_flow(user_id, server_id)
        return RedirectResponse(url=authorization_url, status_code=302)
    except ValueError as e:
        logger.error("OAuth login error: %s", e)
        return JSONResponse(
            status_code=400,
            content={"error": "bad_request", "message": str(e)},
        )
    except Exception as e:
        logger.exception("OAuth login unexpected error")
        return JSONResponse(
            status_code=500,
            content={"error": "internal_error", "message": str(e)},
        )


@router.get("/mcp-auth/callback")
async def callback(
    request: Request,
    state: str = Query(..., description="OAuth state parameter"),
    code: str | None = Query(default=None, description="Authorization code"),
    error: str | None = Query(default=None, description="OAuth error code"),
    error_description: str | None = Query(
        default=None, description="OAuth error description"
    ),
) -> JSONResponse:
    """Handle OAuth callback — exchanges authorization code for tokens.

    Per RFC 6749 Section 4.1.2.1, the authorization server may redirect
    with an error instead of a code (e.g. when the user denies access).
    """
    flow_manager = request.app.state.oauth_flow_manager

    # Handle OAuth error responses (RFC 6749 Section 4.1.2.1)
    if error:
        detail = error_description or error
        logger.warning(
            "OAuth error callback: error=%s description=%s", error, error_description
        )
        return JSONResponse(
            status_code=400,
            content={
                "error": "oauth_error",
                "oauth_error": error,
                "message": f"Authorization denied: {detail}",
            },
        )

    if not code:
        return JSONResponse(
            status_code=400,
            content={"error": "bad_request", "message": "Missing authorization code"},
        )

    try:
        user_id, server_id = await flow_manager.handle_callback(code, state)
        return HTMLResponse(
            status_code=200,
            content=_success_html(user_id, server_id),
        )
    except ValueError as e:
        logger.error("OAuth callback error: %s", e)
        return HTMLResponse(
            status_code=400,
            content=_error_html("Request Error", str(e)),
        )
    except Exception as e:
        logger.exception("OAuth callback unexpected error")
        return HTMLResponse(
            status_code=500,
            content=_error_html("Server Error", str(e)),
        )


@router.get("/mcp-auth/status")
async def status(
    request: Request,
    user_id: str = Query(..., description="Unique user identifier"),
) -> JSONResponse:
    """Check authentication status for a user across all configured servers."""
    registry = request.app.state.oauth_flow_manager.registry
    token_store_factory = request.app.state.oauth_flow_manager.token_store_factory

    servers = await registry.list_servers()
    auth_status = UserAuthStatus(user_id=user_id)

    for server in servers:
        adapter = token_store_factory.get_token_storage_adapter(
            user_id=user_id, server_url=server.url
        )
        token = await adapter.get_tokens()

        # Determine if server requires OAuth via discovery
        discovery = await registry.discover(server.server_id)
        requires_auth = discovery.requires_oauth

        server_status = ServerAuthStatus(
            server_id=server.server_id,
            requires_auth=requires_auth,
            authenticated=token is not None if requires_auth else True,
            has_refresh_token=bool(token and token.refresh_token),
        )
        auth_status.servers[server.server_id] = server_status

    return JSONResponse(
        status_code=200,
        content=auth_status.model_dump(),
    )
