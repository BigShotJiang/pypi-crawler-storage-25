"""MCP server config and OAuth flow state models."""

from __future__ import annotations

import time

from mcp.shared.auth import OAuthClientInformationFull, OAuthMetadata
from pydantic import BaseModel, Field, model_validator

from axmp_ai_agent_core.agent.spec.types import TransportType


class MCPServerConfig(BaseModel):
    """MCP server config. Supports both http (streamable-http) and stdio transport."""

    server_id: str = Field(
        ..., description="Unique server identifier (e.g. 'studio', 'notion')"
    )
    transport: TransportType = Field(
        default=TransportType.HTTP, description="Transport type"
    )

    # --- HTTP transport only ---
    url: str | None = Field(
        default=None,
        description="MCP server endpoint URL (required for http transport)",
    )
    headers: dict[str, str] | None = Field(default=None, description="HTTP headers")

    # --- stdio transport only ---
    command: str | None = Field(
        default=None, description="Command to run (required for stdio transport)"
    )
    args: list[str] | None = Field(default=None, description="Command arguments")
    env: dict[str, str] | None = Field(
        default=None, description="Environment variables"
    )
    cwd: str | None = Field(default=None, description="Working directory")

    # --- OAuth related (http + OAuth only) ---
    client_id: str | None = Field(
        default=None, description="Pre-registered client ID (skips DCR)"
    )
    client_secret: str | None = Field(
        default=None, description="Pre-registered client secret"
    )
    is_oauth_server: bool = Field(
        default=False, description="Whether the server is OAuth server"
    )

    # --- Error message during get_tools ---
    error_message: str | None = Field(
        default=None, description="Error message during get_tools"
    )

    @model_validator(mode="after")
    def validate_transport_fields(self):
        """Validate transport-specific fields."""
        if (
            self.transport
            in (
                TransportType.HTTP,
                TransportType.STREAMABLE_HTTP_DASH,
                TransportType.STREAMABLE_HTTP_UNDERSCORE,
            )
            and not self.url
        ):
            raise ValueError(f"url is required when transport='{self.transport}'.")
        if self.transport == TransportType.STDIO and not self.command:
            raise ValueError("command is required when transport='stdio'.")
        return self


class NeedAuthMCPServer(BaseModel):
    """Need auth MCP server."""

    server_id: str
    auth_url: str


class OAuthFlowState(BaseModel):
    """State for a pending OAuth authorization flow."""

    user_id: str
    server_id: str
    state: str = Field(..., description="OAuth state parameter")
    code_verifier: str = Field(..., description="PKCE code verifier")
    redirect_uri: str = Field(..., description="Callback redirect URI")
    created_at: float = Field(default_factory=time.time)
    oauth_metadata: OAuthMetadata
    client_info: OAuthClientInformationFull
    referer: str | None = Field(default=None, description="Referer URL")

    model_config = {"arbitrary_types_allowed": True}

    def is_expired(self, ttl: float = 600.0) -> bool:
        """Check if the flow state has expired."""
        return (time.time() - self.created_at) > ttl


class ServerAuthStatus(BaseModel):
    """Authentication status for a single server."""

    server_id: str
    requires_auth: bool = True
    authenticated: bool = False
    has_refresh_token: bool = False


class UserAuthStatus(BaseModel):
    """Authentication status for a user across all servers."""

    user_id: str
    servers: dict[str, ServerAuthStatus] = Field(default_factory=dict)
