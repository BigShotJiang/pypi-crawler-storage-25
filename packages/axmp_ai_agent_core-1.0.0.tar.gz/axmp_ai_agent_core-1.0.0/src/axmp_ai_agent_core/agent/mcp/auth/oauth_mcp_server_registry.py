"""OAuth MCP server registry for managing OAuth-enabled MCP servers."""

from __future__ import annotations

import logging
import time

import httpx
from key_value.aio.adapters.pydantic import PydanticAdapter
from key_value.aio.stores.base import BaseStore
from mcp.client.auth.utils import (
    build_oauth_authorization_server_metadata_discovery_urls,
    build_protected_resource_metadata_discovery_urls,
    create_client_registration_request,
    create_oauth_metadata_request,
    handle_auth_metadata_response,
    handle_protected_resource_response,
    handle_registration_response,
)
from mcp.shared.auth import (
    OAuthClientInformationFull,
    OAuthClientMetadata,
    OAuthMetadata,
    ProtectedResourceMetadata,
)
from pydantic import AnyHttpUrl, BaseModel

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig
from axmp_ai_agent_core.agent.spec.types import TransportType
from axmp_ai_agent_core.setting import get_core_settings

logger = logging.getLogger(__name__)

# Redis TTL for server configs (seconds). Servers are re-registered on every
# request via add_servers(), so active servers refresh their TTL automatically.
# Orphaned entries (removed from agent spec) expire after this period.
_SERVER_REDIS_TTL = 86400  # 24 hours


class ServerOAuthProfile(BaseModel):
    """Cached result of OAuth metadata discovery for a server."""

    model_config = {"arbitrary_types_allowed": True}

    protected_resource_metadata: ProtectedResourceMetadata | None = None
    oauth_metadata: OAuthMetadata | None = None
    client_info: OAuthClientInformationFull | None = None

    @property
    def requires_oauth(self) -> bool:
        """Whether the server requires OAuth authentication (OASM was discovered)."""
        return self.oauth_metadata is not None

    @property
    def oauth_ready(self) -> bool:
        """Whether the OAuth flow is fully configured and ready to execute."""
        return self.oauth_metadata is not None and self.client_info is not None


class OAuthMCPServerRegistry:
    """Registry managing OAuth-enabled MCP server configurations and metadata discovery.

    Requires a Redis-backed BaseStore for persistence. All server configs and
    discovery results are stored in Redis only — no in-memory caching — to
    ensure consistency across multiple replicas in Kubernetes deployments.

    Handles:
    - Server config management by server_id
    - Protected Resource Metadata (PRM) discovery
    - OAuth Authorization Server Metadata (OASM) discovery
    - Dynamic Client Registration (DCR) or static client info creation
    """

    def __init__(
        self,
        auth_login_url: str,
        callback_redirect_uris: list[str],
        client_name: str = "NPO MCP Client",
        base_store: BaseStore | None = None,
    ) -> None:
        """Initialize the registry."""
        if base_store is None:
            raise ValueError(
                "OAuthMCPServerRegistry requires a Redis-backed base_store"
            )
        self._registered_server_ids: set[str] = set()
        self._auth_login_url = auth_login_url
        self._callback_redirect_uris = callback_redirect_uris
        self._client_name = client_name
        self._core_settings = get_core_settings()
        self._client_info_storage: PydanticAdapter | None = (
            PydanticAdapter(
                default_collection=self._core_settings.mcp_dcr_client_info_collection,
                key_value=base_store,
                pydantic_model=OAuthClientInformationFull,
                raise_on_validation_error=True,
            )
            if base_store is not None
            else None
        )
        self._discovery_cache_storage: PydanticAdapter | None = (
            PydanticAdapter(
                default_collection=self._core_settings.mcp_oauth_discovery_cache_collection,
                key_value=base_store,
                pydantic_model=ServerOAuthProfile,
                raise_on_validation_error=False,
            )
            if base_store is not None
            else None
        )
        self._servers_storage: PydanticAdapter | None = (
            PydanticAdapter(
                default_collection=self._core_settings.mcp_oauth_servers_collection,
                key_value=base_store,
                pydantic_model=MCPServerConfig,
                raise_on_validation_error=True,
            )
            if base_store is not None
            else None
        )

    async def _persist_discovery_cache(
        self, server_id: str, result: ServerOAuthProfile
    ) -> None:
        """Persist discovery cache to Redis (best-effort)."""
        if self._discovery_cache_storage:
            try:
                await self._discovery_cache_storage.put(
                    key=server_id, value=result, ttl=3600
                )
            except Exception:
                logger.debug(
                    "Failed to persist discovery cache for '%s' to Redis",
                    server_id,
                    exc_info=True,
                )

    @property
    def auth_login_url(self) -> str:
        """Get the auth login URL."""
        return self._auth_login_url

    @property
    def callback_redirect_uris(self) -> list[str]:
        """Get the callback redirect URIs."""
        return self._callback_redirect_uris

    async def get_server(self, server_id: str) -> MCPServerConfig:
        """Get registered server config from Redis."""
        if self._servers_storage:
            try:
                server = await self._servers_storage.get(key=server_id)
                if server:
                    return server
            except Exception:
                logger.warning(
                    "Failed to load server '%s' from Redis", server_id, exc_info=True
                )
        raise ValueError(f"Unknown server_id: {server_id}")

    async def list_servers(self) -> list[MCPServerConfig]:
        """List all registered servers.

        Without a key-scan API on BaseStore, this returns servers that have
        been registered via add_servers() in the current process lifetime.
        The caller should ensure add_servers() has been invoked with the
        full set first.
        """
        servers = []
        for sid in self._registered_server_ids:
            try:
                server = await self.get_server(sid)
                servers.append(server)
            except ValueError:
                continue
        return servers

    async def add_server(self, server: MCPServerConfig) -> None:
        """Register or update OAuth server (upsert).

        Always writes to Redis with the latest config.
        Invalidates discovery cache when server info changes.
        """
        if server.transport not in (
            TransportType.HTTP,
            TransportType.STREAMABLE_HTTP_DASH,
            TransportType.STREAMABLE_HTTP_UNDERSCORE,
        ):
            logger.warning(
                "Server '%s' has invalid transport '%s', skipping because OAuth supported only HTTP",
                server.server_id,
                server.transport,
            )
            return

        # Invalidate discovery cache if server config changed
        if self._servers_storage:
            try:
                existing = await self._servers_storage.get(key=server.server_id)
                if existing is not None and existing != server:
                    if self._discovery_cache_storage:
                        await self._discovery_cache_storage.delete(key=server.server_id)
                    logger.info(
                        "Server '%s' config changed, invalidated discovery cache",
                        server.server_id,
                    )
            except Exception:
                logger.debug(
                    "Failed to check existing server '%s' in Redis",
                    server.server_id,
                    exc_info=True,
                )

        if self._servers_storage:
            try:
                await self._servers_storage.put(
                    key=server.server_id, value=server, ttl=_SERVER_REDIS_TTL
                )
            except Exception:
                logger.warning(
                    "Failed to persist server '%s' to Redis",
                    server.server_id,
                    exc_info=True,
                )
        self._registered_server_ids.add(server.server_id)
        logger.info("Registered OAuth server '%s'", server.server_id)

    async def add_servers(self, servers: list[MCPServerConfig]) -> None:
        """Register or update multiple OAuth servers (upsert)."""
        for server in servers:
            await self.add_server(server)

    async def update_server(self, server: MCPServerConfig) -> None:
        """Update existing server config. Also invalidates discovery cache."""
        if not self._servers_storage:
            raise ValueError("Redis storage is required for update_server")
        stored = await self._servers_storage.get(key=server.server_id)
        if not stored:
            raise ValueError(f"Unknown server_id: {server.server_id}")
        try:
            await self._servers_storage.put(
                key=server.server_id, value=server, ttl=_SERVER_REDIS_TTL
            )
        except Exception:
            logger.warning(
                "Failed to update server '%s' in Redis",
                server.server_id,
                exc_info=True,
            )
        if self._discovery_cache_storage:
            try:
                await self._discovery_cache_storage.delete(key=server.server_id)
            except Exception:
                logger.warning(
                    "Failed to delete discovery cache for '%s' from Redis",
                    server.server_id,
                    exc_info=True,
                )
        self._registered_server_ids.add(server.server_id)
        logger.info("Updated OAuth server '%s'", server.server_id)

    async def remove_server(self, server_id: str) -> None:
        """Remove server and clean up discovery cache."""
        self._registered_server_ids.discard(server_id)
        if self._servers_storage:
            try:
                await self._servers_storage.delete(key=server_id)
            except Exception:
                logger.warning(
                    "Failed to delete server '%s' from Redis", server_id, exc_info=True
                )
        if self._discovery_cache_storage:
            try:
                await self._discovery_cache_storage.delete(key=server_id)
            except Exception:
                logger.warning(
                    "Failed to delete discovery cache for '%s' from Redis",
                    server_id,
                    exc_info=True,
                )
        logger.info("Removed OAuth server '%s'", server_id)

    async def has_server(self, server_id: str) -> bool:
        """Check if server is registered."""
        if self._servers_storage:
            try:
                server = await self._servers_storage.get(key=server_id)
                if server:
                    return True
            except Exception:
                logger.warning(
                    "Failed to check server '%s' in Redis", server_id, exc_info=True
                )
        return False

    def _resolve_token_auth_method(
        self,
        oauth_metadata: OAuthMetadata | None,
        has_client_secret: bool,
    ) -> str:
        """Determine optimal auth method from OASM's token_endpoint_auth_methods_supported."""
        if not has_client_secret:
            return "none"

        supported = (
            oauth_metadata.token_endpoint_auth_methods_supported
            if oauth_metadata
            else None
        )
        if supported:
            for preferred in ("client_secret_basic", "client_secret_post"):
                if preferred in supported:
                    return preferred

        # No OASM or no match → RFC 6749 default
        return "client_secret_basic"

    async def discover(self, server_id: str) -> ServerOAuthProfile:
        """Discover OAuth metadata for a server (cached per server_id).

        PRM probe → if PRM found, proceed with OAuth (graceful skip on failure).
        If no PRM, skip (no OAuth needed).

        Steps:
        1. PRM discovery via well-known URLs
        2. OASM discovery using authorization_servers from PRM
        3. DCR or static client info creation
        """
        # Check Redis cache
        if self._discovery_cache_storage:
            try:
                cached = await self._discovery_cache_storage.get(key=server_id)
                if cached is not None:
                    return cached
            except Exception:
                logger.debug(
                    "Failed to load discovery cache for '%s' from Redis",
                    server_id,
                    exc_info=True,
                )

        server = await self.get_server(server_id)
        result = ServerOAuthProfile()

        async with httpx.AsyncClient(
            verify=self._core_settings.http_ssl_verify
        ) as client:
            # Step 1: Protected Resource Metadata discovery
            result.protected_resource_metadata = await self._discover_prm(
                client, server.url
            )

            if result.protected_resource_metadata is None:
                logger.info(
                    "No PRM found for server '%s' — OAuth not required",
                    server_id,
                )
                await self._persist_discovery_cache(server_id, result)
                return result

            # Step 2: OAuth Authorization Server Metadata discovery
            auth_server_url: str | None = None
            if result.protected_resource_metadata.authorization_servers:
                auth_server_url = str(
                    result.protected_resource_metadata.authorization_servers[0]
                )

            result.oauth_metadata = await self._discover_oasm(
                client, auth_server_url, server.url
            )

            if result.oauth_metadata is None:
                logger.warning(
                    "PRM found but OASM discovery failed for server '%s' — "
                    "skipping OAuth",
                    server_id,
                )
                await self._persist_discovery_cache(server_id, result)
                return result

            # Step 3: Client registration or static client info
            result.client_info = await self._get_or_register_client(
                client, server, result.oauth_metadata
            )

            if result.client_info is None:
                logger.warning(
                    "Client registration failed for server '%s' — skipping OAuth",
                    server_id,
                )

        await self._persist_discovery_cache(server_id, result)
        logger.info("Discovery complete for server '%s'", server_id)
        return result

    async def _discover_prm(
        self, client: httpx.AsyncClient, server_url: str
    ) -> ProtectedResourceMetadata | None:
        """Discover Protected Resource Metadata via well-known URLs."""
        urls = build_protected_resource_metadata_discovery_urls(
            www_auth_url=None, server_url=server_url
        )

        for url in urls:
            try:
                request = create_oauth_metadata_request(url)
                response = await client.send(
                    httpx.Request(
                        method=request.method,
                        url=str(request.url),
                        headers=dict(request.headers),
                    )
                )
                metadata = await handle_protected_resource_response(response)
                if metadata:
                    logger.debug("PRM discovered at %s", url)
                    return metadata
            except Exception:
                logger.debug("PRM discovery failed at %s", url, exc_info=True)
                continue

        logger.debug("No PRM found for %s", server_url)
        return None

    async def _discover_oasm(
        self,
        client: httpx.AsyncClient,
        auth_server_url: str | None,
        server_url: str,
    ) -> OAuthMetadata | None:
        """Discover OAuth Authorization Server Metadata."""
        urls = build_oauth_authorization_server_metadata_discovery_urls(
            auth_server_url=auth_server_url, server_url=server_url
        )

        for url in urls:
            try:
                request = create_oauth_metadata_request(url)
                response = await client.send(
                    httpx.Request(
                        method=request.method,
                        url=str(request.url),
                        headers=dict(request.headers),
                    )
                )
                should_continue, metadata = await handle_auth_metadata_response(
                    response
                )
                if metadata:
                    logger.debug("OASM discovered at %s", url)
                    return metadata
                if not should_continue:
                    break
            except Exception:
                logger.debug("OASM discovery failed at %s", url, exc_info=True)
                continue

        logger.warning("No OASM found for server_url=%s", server_url)
        return None

    async def _get_or_register_client(
        self,
        client: httpx.AsyncClient,
        server: MCPServerConfig,
        oauth_metadata: OAuthMetadata | None,
    ) -> OAuthClientInformationFull | None:
        """Get static client info or perform Dynamic Client Registration.

        Returns None if OAuth metadata is unavailable and no static client_id
        is configured (instead of raising).
        """
        redirect_uris = [AnyHttpUrl(u) for u in self._callback_redirect_uris]

        if server.client_id:
            # Static client info — skip DCR and persistent storage
            logger.debug("Using static client info for server '%s'", server.server_id)
            return OAuthClientInformationFull(
                client_id=server.client_id,
                client_secret=server.client_secret,
                client_name=self._client_name,
                redirect_uris=redirect_uris,
                grant_types=["authorization_code", "refresh_token"],
                response_types=["code"],
                scope="",
                token_endpoint_auth_method=self._resolve_token_auth_method(
                    oauth_metadata,
                    has_client_secret=bool(server.client_secret),
                ),
            )

        # Check persistent storage for a previously registered DCR result
        if self._client_info_storage:
            try:
                stored = await self._client_info_storage.get(key=server.server_id)
                if stored is not None:
                    logger.info(
                        "Reusing persisted DCR client info for server '%s'",
                        server.server_id,
                    )
                    return stored
            except Exception:
                logger.warning(
                    "Failed to load persisted DCR client info for server '%s', "
                    "will re-register",
                    server.server_id,
                    exc_info=True,
                )

        # Dynamic Client Registration requires OAuth metadata
        if not oauth_metadata:
            logger.warning(
                "No OAuth metadata for server '%s', skipping client registration.",
                server.server_id,
            )
            return None

        # Check if the server supports Dynamic Client Registration
        if not oauth_metadata.registration_endpoint:
            logger.warning(
                "No registration_endpoint in OAuth metadata for server '%s' — "
                "DCR not supported. Provide client_id/client_secret in server config.",
                server.server_id,
            )
            return None

        client_metadata = OAuthClientMetadata(
            client_name=self._client_name,
            redirect_uris=redirect_uris,
            grant_types=["authorization_code", "refresh_token"],
            response_types=["code"],
            scope="",
        )

        parsed_issuer = str(oauth_metadata.issuer)
        auth_base_url = parsed_issuer.rstrip("/")

        request = create_client_registration_request(
            auth_server_metadata=oauth_metadata,
            client_metadata=client_metadata,
            auth_base_url=auth_base_url,
        )

        try:
            response = await client.send(
                httpx.Request(
                    method=request.method,
                    url=str(request.url),
                    headers=dict(request.headers),
                    content=request.content,
                )
            )
            client_info = await handle_registration_response(response)
        except Exception:
            logger.warning(
                "Dynamic Client Registration failed for server '%s' — "
                "DCR not supported. Provide client_id/client_secret in server config.",
                server.server_id,
                exc_info=True,
            )
            return None

        logger.info("DCR complete for server '%s'", server.server_id)

        # Persist DCR result so refresh tokens survive app restarts
        if self._client_info_storage and client_info is not None:
            try:
                ttl: int | None = None
                if client_info.client_secret_expires_at:
                    ttl = client_info.client_secret_expires_at - int(time.time())
                    if ttl <= 0:
                        ttl = None
                await self._client_info_storage.put(
                    key=server.server_id, value=client_info, ttl=ttl
                )
                logger.debug(
                    "Persisted DCR client info for server '%s' (ttl=%s)",
                    server.server_id,
                    ttl,
                )
            except Exception:
                logger.warning(
                    "Failed to persist DCR client info for server '%s'",
                    server.server_id,
                    exc_info=True,
                )

        return client_info
