"""Handlers for MCP connection and authentication failures."""

import logging
from urllib.parse import urlencode

import httpcore
import httpx
from fastapi.responses import JSONResponse

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig, NeedAuthMCPServer
from axmp_ai_agent_core.agent.mcp.auth.token_store import UserTokenStoreFactory
from axmp_ai_agent_core.agent.mcp.clients.factory import UserMCPClientFactory
from axmp_ai_agent_core.agent.spec.types import TransportType

logger = logging.getLogger(__name__)


class MCPConnectionError(Exception):
    """Raised when an MCP server is unreachable."""

    def __init__(self, server_id: str, server_url: str, cause: BaseException):
        """Initialize MCPConnectionError."""
        self.server_id = server_id
        self.server_url = server_url
        super().__init__(
            f"Cannot connect to MCP server '{server_id}' ({server_url}): {cause}"
        )


def _extract_auth_failure_urls(exc: BaseException) -> set[str]:
    """Extract MCP server URLs from 401 auth errors within ExceptionGroups.

    Handles nested ExceptionGroups from anyio/asyncio TaskGroups and
    plain httpx.HTTPStatusError exceptions.
    """
    urls: set[str] = set()

    if isinstance(exc, ExceptionGroup):
        for sub_exc in exc.exceptions:
            urls.update(_extract_auth_failure_urls(sub_exc))
    elif isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code == 401:
        urls.add(str(exc.request.url))

    return urls


def _is_connection_error(exc: BaseException) -> bool:
    """Check if an exception (possibly an ExceptionGroup) contains connection errors."""
    if isinstance(exc, ExceptionGroup):
        return any(_is_connection_error(sub) for sub in exc.exceptions)
    return isinstance(exc, (httpx.ConnectError | httpcore.ConnectError))


def handle_connection_failure(exc: BaseException) -> JSONResponse | None:
    """Handle connection failures by returning a 502 JSONResponse.

    Returns a 502 JSONResponse if the exception is an MCPConnectionError
    or contains connection errors, or None otherwise.
    """
    if isinstance(exc, MCPConnectionError):
        logger.warning(
            "MCP server connection failure: server=%s url=%s",
            exc.server_id,
            exc.server_url,
        )
        return JSONResponse(
            status_code=502,
            content={
                "error": "bad_gateway",
                "message": "Cannot connect to MCP server. Please check if the server is running.",
                "server_id": exc.server_id,
                "server_url": exc.server_url,
            },
        )

    if _is_connection_error(exc):
        logger.warning("MCP server connection failure: %s", exc)
        return JSONResponse(
            status_code=502,
            content={
                "error": "bad_gateway",
                "message": "Cannot connect to MCP server. Please check if the server is running.",
                "detail": str(exc),
            },
        )

    return None


async def handle_authentication_failure(
    exc: BaseException,
    user_id: str,
    agent_cache: dict,
    agent_cache_key: str,
    auth_login_url: str,
    client_factory: UserMCPClientFactory,
    token_factory: UserTokenStoreFactory,
    mcp_server_configs: list[MCPServerConfig],
) -> JSONResponse | None:
    """Handle auth failures from _init_agent by clearing stale tokens.

    Args:
        exc: Exception to handle.
        user_id: User ID.
        agent_cache: Agent cache.
        auth_login_url: Auth login URL.
        client_factory: User MCP client factory.
        token_factory: User token store factory.
        mcp_server_configs: MCP server configs.

    Returns:
        JSONResponse if the exception contains auth failures, None otherwise.
    """
    failed_urls = _extract_auth_failure_urls(exc)
    if not failed_urls:
        return None

    logger.warning("Auth failure for user=%s urls=%s", user_id, failed_urls)

    failed_urls_normalized = {u.rstrip("/") for u in failed_urls}

    for server in mcp_server_configs:
        if (
            server.transport
            in (
                TransportType.HTTP,
                TransportType.STREAMABLE_HTTP_DASH,
                TransportType.STREAMABLE_HTTP_UNDERSCORE,
            )
            and server.url
            and server.url.rstrip("/") in failed_urls_normalized
        ):
            adapter = token_factory.get_token_storage_adapter(
                user_id=user_id, server_url=server.url
            )

            await adapter.clear()

            logger.info(
                "Invalidated tokens for user=%s server=%s",
                user_id,
                server.server_id,
            )

    # delete agent cache
    agent_cache.pop(agent_cache_key, None)

    pending = await client_factory.get_pending_auth_servers(
        user_id=user_id, servers=mcp_server_configs
    )

    pending_auth = [
        NeedAuthMCPServer(
            server_id=s["server_id"],
            auth_url=(
                f"{auth_login_url}"
                f"?{urlencode({'user_id': user_id, 'server_id': s['server_id']})}"
            ),
        )
        for s in pending
    ]

    return JSONResponse(
        status_code=401,
        content={
            "error": "unauthorized",
            "message": "Token expired. Re-authentication required.",
            "pending_auth": [s.model_dump() for s in pending_auth],
        },
    )
