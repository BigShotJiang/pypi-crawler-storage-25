"""Token endpoint authentication utilities for OAuth."""

from __future__ import annotations

import logging
from collections.abc import AsyncGenerator

import httpx
from fastmcp.client.auth.oauth import TokenStorageAdapter
from langchain_core.runnables.config import var_child_runnable_config
from mcp.shared.auth import OAuthMetadata, OAuthToken

from axmp_ai_agent_core.agent.mcp.auth.token_store import UserTokenStoreFactory
from axmp_ai_agent_core.agent.mcp.auth.utils import prepare_token_auth
from axmp_ai_agent_core.setting import get_core_settings

logger = logging.getLogger(__name__)


class RefreshableBearerAuth(httpx.Auth):
    """HTTPX Auth that attaches Bearer tokens and refreshes on 401.

    Unlike fastmcp's BearerAuth (static token), this reads tokens from
    a TokenStorageAdapter and automatically refreshes when receiving 401.
    """

    requires_response_body = True

    def __init__(
        self,
        token_storage: TokenStorageAdapter,
        oauth_metadata: OAuthMetadata | None,
        server_url: str,
    ) -> None:
        """Initialize RefreshableBearerAuth."""
        self._token_storage = token_storage
        self._oauth_metadata = oauth_metadata
        self._server_url = server_url
        self._core_settings = get_core_settings()

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        """Async auth flow for Bearer tokens."""
        token = await self._token_storage.get_tokens()

        if token is None:
            # No token available — let the request go through unauthenticated
            response = yield request
            return

        # Attach Bearer token
        request.headers["Authorization"] = f"Bearer {token.access_token}"
        response = yield request

        # If 401 and we have a refresh token, try refreshing
        if response.status_code == 401 and token.refresh_token:
            new_token = await self._try_refresh(token)
            if new_token:
                request.headers["Authorization"] = f"Bearer {new_token.access_token}"
                yield request

    async def _try_refresh(self, current_token: OAuthToken) -> OAuthToken | None:
        """Attempt to refresh the access token."""
        if not current_token.refresh_token:
            return None

        client_info = await self._token_storage.get_client_info()
        if not client_info or not client_info.client_id:
            logger.warning("Cannot refresh token: no client info stored")
            return None

        # Determine token endpoint
        token_endpoint: str | None = None
        if self._oauth_metadata and self._oauth_metadata.token_endpoint:
            token_endpoint = str(self._oauth_metadata.token_endpoint)

        if not token_endpoint:
            logger.warning("Cannot refresh token: no token_endpoint in metadata")
            return None

        data: dict = {
            "grant_type": "refresh_token",
            "refresh_token": current_token.refresh_token,
            "client_id": client_info.client_id,
        }
        headers: dict = {"Content-Type": "application/x-www-form-urlencoded"}

        data, headers = prepare_token_auth(
            client_id=client_info.client_id,
            client_secret=client_info.client_secret,
            auth_method=client_info.token_endpoint_auth_method,
            data=data,
            headers=headers,
        )

        logger.debug(f"data: {data}")
        logger.debug(f"headers: {headers}")

        try:
            async with httpx.AsyncClient(
                verify=self._core_settings.http_ssl_verify
            ) as client:
                resp = await client.post(token_endpoint, data=data, headers=headers)
                if resp.status_code != 200:
                    logger.warning(
                        "Token refresh failed: %d %s", resp.status_code, resp.text
                    )
                    # If the refresh token is no longer valid on the server
                    # (e.g., server restart lost in-memory tokens), clear stale
                    # tokens from disk so the next request triggers re-auth.
                    if "invalid_grant" in resp.text:
                        logger.info(
                            "Clearing stale tokens for %s (invalid_grant)",
                            self._server_url,
                        )
                        await self._token_storage.clear()
                    return None

                new_token = OAuthToken.model_validate_json(resp.content)
                # Preserve refresh token if new response doesn't include one
                if not new_token.refresh_token and current_token.refresh_token:
                    new_token = new_token.model_copy(
                        update={"refresh_token": current_token.refresh_token}
                    )
                await self._token_storage.set_tokens(new_token)
                logger.info("Token refreshed successfully for %s", self._server_url)
                return new_token
        except Exception:
            logger.exception("Token refresh error for %s", self._server_url)
            return None


class DynamicUserBearerAuth(httpx.Auth):
    """HTTPX Auth that resolves the current user from LangGraph config.

    Instead of being bound to a fixed user's tokens at creation time,
    this reads the user_id from LangGraph's var_child_runnable_config
    ContextVar at each request, enabling a single shared MCP connection
    to serve all users.
    """

    requires_response_body = True

    def __init__(
        self,
        token_store_factory: UserTokenStoreFactory,
        oauth_metadata: OAuthMetadata | None,
        server_url: str,
        fallback_user_id: str | None = None,
    ) -> None:
        """Initialize DynamicUserBearerAuth."""
        self._token_store_factory = token_store_factory
        self._oauth_metadata = oauth_metadata
        self._server_url = server_url
        self._fallback_user_id = fallback_user_id
        self._core_settings = get_core_settings()

    def _get_current_user_id(self) -> str:
        """Extract user_id from the current LangGraph execution context.

        Falls back to fallback_user_id when called outside of LangGraph
        tool execution (e.g. during get_tools() at init time).
        """
        config = var_child_runnable_config.get(None)
        if config is not None:
            configurable = config.get("configurable", {})
            user_id = configurable.get("user_id")
            if user_id:
                return user_id

        if self._fallback_user_id:
            return self._fallback_user_id

        raise RuntimeError(
            "No user_id available — neither LangGraph config nor fallback_user_id is set"
        )

    async def async_auth_flow(
        self, request: httpx.Request
    ) -> AsyncGenerator[httpx.Request, httpx.Response]:
        """Async auth flow for Bearer tokens."""
        user_id = self._get_current_user_id()
        adapter = self._token_store_factory.get_token_storage_adapter(
            user_id=user_id, server_url=self._server_url
        )
        token = await adapter.get_tokens()

        if token is None:
            response = yield request
            return

        request.headers["Authorization"] = f"Bearer {token.access_token}"
        response = yield request

        # If 401 and we have a refresh token, try refreshing
        if response.status_code == 401 and token.refresh_token:
            new_token = await self._try_refresh(adapter, token)
            if new_token:
                request.headers["Authorization"] = f"Bearer {new_token.access_token}"
                yield request

    async def _try_refresh(
        self, adapter: TokenStorageAdapter, current_token: OAuthToken
    ) -> OAuthToken | None:
        """Attempt to refresh the access token (reuses RefreshableBearerAuth logic)."""
        if not current_token.refresh_token:
            return None

        client_info = await adapter.get_client_info()
        if not client_info or not client_info.client_id:
            logger.warning("Cannot refresh token: no client info stored")
            return None

        token_endpoint: str | None = None
        if self._oauth_metadata and self._oauth_metadata.token_endpoint:
            token_endpoint = str(self._oauth_metadata.token_endpoint)

        if not token_endpoint:
            logger.warning("Cannot refresh token: no token_endpoint in metadata")
            return None

        data: dict = {
            "grant_type": "refresh_token",
            "refresh_token": current_token.refresh_token,
            "client_id": client_info.client_id,
        }
        headers: dict = {"Content-Type": "application/x-www-form-urlencoded"}

        data, headers = prepare_token_auth(
            client_id=client_info.client_id,
            client_secret=client_info.client_secret,
            auth_method=client_info.token_endpoint_auth_method,
            data=data,
            headers=headers,
        )

        try:
            async with httpx.AsyncClient(
                verify=self._core_settings.http_ssl_verify
            ) as client:
                resp = await client.post(token_endpoint, data=data, headers=headers)
                if resp.status_code != 200:
                    logger.warning(
                        "Token refresh failed: %d %s", resp.status_code, resp.text
                    )
                    if "invalid_grant" in resp.text:
                        logger.info("Clearing stale tokens for user (invalid_grant)")
                        await adapter.clear()
                    return None

                new_token = OAuthToken.model_validate_json(resp.content)
                if not new_token.refresh_token and current_token.refresh_token:
                    new_token = new_token.model_copy(
                        update={"refresh_token": current_token.refresh_token}
                    )
                await adapter.set_tokens(new_token)
                logger.info("Token refreshed successfully for %s", self._server_url)
                return new_token
        except Exception:
            logger.exception("Token refresh error for %s", self._server_url)
            return None
