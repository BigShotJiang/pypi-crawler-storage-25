"""MCP client factory for creating per-user MCP clients."""

from __future__ import annotations

import logging

from langchain_mcp_adapters.client import MultiServerMCPClient

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig
from axmp_ai_agent_core.agent.mcp.auth.oauth_mcp_server_registry import (
    OAuthMCPServerRegistry,
)
from axmp_ai_agent_core.agent.mcp.auth.token_store import UserTokenStoreFactory
from axmp_ai_agent_core.agent.mcp.clients.auth import (
    DynamicUserBearerAuth,
    RefreshableBearerAuth,
)

logger = logging.getLogger(__name__)


class UserMCPClientFactory:
    """Factory for creating per-user MCP clients with per-user OAuth tokens.

    Creates MultiServerMCPClient instances where each connection uses
    the user's own tokens via RefreshableBearerAuth (for OAuth servers)
    or connects without auth (for non-OAuth servers).
    """

    def __init__(
        self,
        registry: OAuthMCPServerRegistry,
        token_store_factory: UserTokenStoreFactory,
    ) -> None:
        """Initialize UserMCPClientFactory."""
        self._registry = registry
        self._token_store_factory = token_store_factory

    async def create_client(
        self,
        user_id: str,
        servers: list[MCPServerConfig],
    ) -> MultiServerMCPClient:
        """Create a MultiServerMCPClient with available servers.

        For OAuth servers, only includes those with valid tokens.
        For non-OAuth servers, connects without auth.
        stdio servers connect directly without auth.

        Args:
            user_id: User identifier to load tokens for.
            servers: List of server configs to include.

        Returns:
            MultiServerMCPClient configured for each available server.
        """
        connections: dict[str, dict] = {}

        for server in servers:
            # --- stdio transport ---
            if server.transport == "stdio":
                conn: dict = {
                    "transport": "stdio",
                    "command": server.command,
                }
                if server.args:
                    conn["args"] = server.args
                if server.env:
                    conn["env"] = server.env
                if server.cwd:
                    conn["cwd"] = server.cwd
                connections[server.server_id] = conn
                continue

            # --- http transport ---
            if await self._registry.has_server(server.server_id):
                # In registry → OAuth-capable server
                discovery = await self._registry.discover(server.server_id)
                if discovery.oauth_ready:
                    has_token = await self._token_store_factory.has_valid_token(
                        user_id, server.url
                    )
                    if not has_token:
                        logger.debug(
                            "Skipping OAuth server '%s' for user '%s': no token",
                            server.server_id,
                            user_id,
                        )
                        continue

                    token_adapter = self._token_store_factory.get_token_storage_adapter(
                        user_id=user_id, server_url=server.url
                    )
                    auth = RefreshableBearerAuth(
                        token_storage=token_adapter,
                        oauth_metadata=discovery.oauth_metadata,
                        server_url=server.url,
                    )
                    connections[server.server_id] = {
                        "transport": "http",
                        "url": server.url,
                        "headers": server.headers,
                        "auth": auth,
                    }
                else:
                    connections[server.server_id] = {
                        "transport": "http",
                        "url": server.url,
                        "headers": server.headers,
                    }
            else:
                # Not in registry → non-OAuth HTTP server
                logger.debug(
                    "Connecting to server '%s' without OAuth (not in registry)",
                    server.server_id,
                )
                connections[server.server_id] = {
                    "transport": "http",
                    "url": server.url,
                    "headers": server.headers,
                }

        if not connections:
            logger.warning("No available servers found for user '%s'", user_id)

        return MultiServerMCPClient(connections)

    async def create_shared_client(
        self,
        servers: list[MCPServerConfig],
        fallback_user_id: str | None = None,
    ) -> MultiServerMCPClient:
        """Create a shared MCP client using DynamicUserBearerAuth.

        Unlike create_client() which binds to a specific user's tokens,
        this uses DynamicUserBearerAuth to resolve the current user from
        LangGraph's config at each request time.

        For OAuth servers, assumes at least one user has valid tokens
        (caller should verify with get_available_servers beforehand).

        Args:
            servers: List of server configs to include.

        Returns:
            MultiServerMCPClient with dynamic per-request user auth.
        """
        connections: dict[str, dict] = {}

        for server in servers:
            # --- stdio transport ---
            if server.transport == "stdio":
                conn: dict = {
                    "transport": "stdio",
                    "command": server.command,
                }
                if server.args:
                    conn["args"] = server.args
                if server.env:
                    conn["env"] = server.env
                if server.cwd:
                    conn["cwd"] = server.cwd
                connections[server.server_id] = conn
                continue

            # --- http transport ---
            if await self._registry.has_server(server.server_id):
                discovery = await self._registry.discover(server.server_id)
                if discovery.oauth_ready:
                    auth = DynamicUserBearerAuth(
                        token_store_factory=self._token_store_factory,
                        oauth_metadata=discovery.oauth_metadata,
                        server_url=server.url,
                        fallback_user_id=fallback_user_id,
                    )
                    connections[server.server_id] = {
                        "transport": "http",
                        "url": server.url,
                        "headers": server.headers,
                        "auth": auth,
                    }
                else:
                    connections[server.server_id] = {
                        "transport": "http",
                        "url": server.url,
                        "headers": server.headers,
                    }
            else:
                logger.debug(
                    "Connecting to server '%s' without OAuth (not in registry)",
                    server.server_id,
                )
                connections[server.server_id] = {
                    "transport": "http",
                    "url": server.url,
                    "headers": server.headers,
                }

        if not connections:
            logger.warning("No servers configured for shared client")

        return MultiServerMCPClient(connections)

    async def get_available_servers(
        self,
        user_id: str,
        servers: list[MCPServerConfig],
    ) -> list[str]:
        """Return list of server_ids available for the user.

        stdio servers are always available.
        Non-OAuth http servers are always available.
        OAuth http servers are available only if the user has valid tokens.
        """
        available = []
        for server in servers:
            if server.transport == "stdio":
                available.append(server.server_id)
                continue

            if await self._registry.has_server(server.server_id):
                discovery = await self._registry.discover(server.server_id)
                if discovery.oauth_ready:
                    if await self._token_store_factory.has_valid_token(
                        user_id, server.url
                    ):
                        available.append(server.server_id)
                elif not discovery.requires_oauth:
                    available.append(server.server_id)
            else:
                # Not in registry → non-OAuth http, always available
                available.append(server.server_id)
        return available

    async def get_pending_auth_servers(
        self,
        user_id: str,
        servers: list[MCPServerConfig],
    ) -> list[dict[str, str]]:
        """Return list of servers that require OAuth but lack valid tokens.

        Each entry contains server_id for building auth URLs.
        """
        pending = []
        for server in servers:
            if server.transport == "stdio":
                continue
            if not await self._registry.has_server(server.server_id):
                continue
            try:
                discovery = await self._registry.discover(server.server_id)
            except ValueError:
                logger.warning(
                    "Server '%s' disappeared from registry during discovery, skipping",
                    server.server_id,
                )
                continue
            if discovery.requires_oauth:
                server.is_oauth_server = True
                has_token = await self._token_store_factory.has_valid_token(
                    user_id, server.url
                )
                if not has_token:
                    pending.append({"server_id": server.server_id})
        return pending

    async def disconnect_user_server(self, user_id: str, server_id: str) -> bool:
        """Disconnect a user from an OAuth MCP server by clearing stored tokens.

        Args:
            user_id: User identifier.
            server_id: MCP server identifier.

        Returns:
            True if tokens were cleared, False if server not found or no token existed.
        """
        try:
            server = await self._registry.get_server(server_id)
        except ValueError:
            logger.debug(
                "Server '%s' not in registry, nothing to disconnect", server_id
            )
            return False

        if not await self._token_store_factory.has_valid_token(user_id, server.url):
            logger.debug(
                "No token for user='%s' server='%s', nothing to clear",
                user_id,
                server_id,
            )
            return False

        adapter = self._token_store_factory.get_token_storage_adapter(
            user_id=user_id, server_url=server.url
        )
        await adapter.clear()

        logger.info("Disconnected user='%s' from server='%s'", user_id, server_id)
        return True
