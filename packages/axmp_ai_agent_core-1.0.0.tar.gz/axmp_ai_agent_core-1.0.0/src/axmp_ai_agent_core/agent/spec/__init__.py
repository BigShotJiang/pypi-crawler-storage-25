"""AXMP AI Agent Specification Package."""
