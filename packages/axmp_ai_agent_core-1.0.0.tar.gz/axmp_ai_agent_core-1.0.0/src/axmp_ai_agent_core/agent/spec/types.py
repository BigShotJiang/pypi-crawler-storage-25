"""A profile of an AI agent."""

from __future__ import annotations

from enum import StrEnum


class ProfileType(StrEnum):
    """AgentProfileType Entity. This entity is used to store the type of the agent profile."""

    SINGLE_AGENT = "single-agent"
    A2A_HOST_AGENT = "a2a-host-agent"
    WORKFLOW = "workflow"
    DEEP_AGENT = "deep-agent"


class ProfileStatus(StrEnum):
    """ProfileStatus Entity. This entity is used to store the status of the profile."""

    DRAFT = "DRAFT"
    COMPLETED = "COMPLETED"


class RuntimeType(StrEnum):
    """AgentRuntimeType Entity. This entity is used to store the type of the agent runtime."""

    WORKSPACE = "workspace"
    STANDALONE = "standalone"


class DeploymentMode(StrEnum):
    """AgentDeploymentMode Entity. This entity is used to store the deployment mode of the agent."""

    # IN_MEMORY_AGENT = "in-memory-agent"
    BACKEND_SERVER = "backend-server"
    A2A_REMOTE_AGENT = "a2a-remote-agent"


class UsageType(StrEnum):
    """UsageType Entity. This entity is used to store the usage type of the agent."""

    PERSONAL = "personal"
    BUSINESS = "business"


class MCPServerType(StrEnum):
    """MCPServerType Entity. This entity is used to store the type of the MCP server."""

    INTERNAL = "internal"
    EXTERNAL = "external"


class NodeType(StrEnum):
    """AgentProfileNodeType Entity. This entity is used to store the type of the node."""

    TRIGGER = "trigger"
    AI_AGENT = "ai-agent"
    LLM = "llm"
    MEMORY = "memory"
    MCP_SERVER = "mcp-server"
    REMOTE_AGENT = "remote-agent"
    SUB_AGENT = "sub-agent"
    SKILL = "skill"


class TriggerType(StrEnum):
    """TriggerType Entity. This entity is used to store the type of the trigger."""

    # WORKSPACE = "workspace"
    CHATBOT = "chatbot"
    WEBHOOK = "webhook"
    SCHEDULER = "scheduler"
    # TODO: milestone 2
    # A2A_HOST_AGENT = "a2a-host-agent"


class DomainType(StrEnum):
    """DomainType Entity. This entity is used to store the type of the domain."""

    SYSTEM = "system"  ## TODO:Clearly specify the meaning of the system domain
    CUSTOM = "custom"


class AuthenticationType(StrEnum):
    """Authentication Type entity."""

    NONE = "None"
    BASIC = "Basic"
    BEARER = "Bearer"
    API_KEY = "ApiKey"
    IDP = "IdentityProvider"


class TransportType(StrEnum):
    """Transport type for MCP and Gateway.

    HTTP is the canonical transport type for this project.
    Other HTTP variants (STREAMABLE_HTTP, STREAMABLE_HTTP_DASH, STREAMABLE_HTTP_UNDERSCORE)
    are kept for backward compatibility.
    At the langchain-mcp-adapters library boundary, HTTP is converted to "streamable_http"
    via TRANSPORT_TYPE_MAP.
    """

    STDIO = "stdio"
    HTTP = "http"
    # NOTE: for backward compatibility
    SSE = "sse"
    STREAMABLE_HTTP_DASH = "streamable-http"
    STREAMABLE_HTTP_UNDERSCORE = "streamable_http"
    """This is a standard type of langchain-mcp-adapter"""
    # NOTE: deprecated
    STREAMABLE_HTTP = "streamable-http"

    @classmethod
    def _missing_(cls, value: object) -> TransportType | None:
        """Normalize non-exact transport type strings to enum members.

        NOTE: StrEnum matches exact values (e.g., "http" → HTTP, "streamable-http" → STREAMABLE_HTTP)
        before calling _missing_. This method handles case-insensitive and variant lookups only.
        STREAMABLE_HTTP_DASH is an alias for STREAMABLE_HTTP (both have value "streamable-http").
        """
        if not isinstance(value, str):
            return None
        normalized = value.lower().replace("-", "_")
        for member in cls:
            if member.value == normalized:
                return member
        return None


class AgentMemoryType(StrEnum):
    """Chat memory type."""

    POSTGRES = "POSTGRESQL"
    REDIS = "REDIS"


class SkillFileType(StrEnum):
    """Skill file type — follows Agent Skills spec directory structure."""

    SCRIPT = "SCRIPT"
    REFERENCE = "REFERENCE"
    ASSET = "ASSET"
