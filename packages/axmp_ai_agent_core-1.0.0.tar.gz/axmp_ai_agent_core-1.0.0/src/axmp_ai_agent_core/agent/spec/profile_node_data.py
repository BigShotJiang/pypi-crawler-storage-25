"""A profile of an AI agent."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Literal

from croniter import croniter
from langchain.chat_models import BaseChatModel
from pydantic import BaseModel, Field, field_validator

from axmp_ai_agent_core.agent.spec.types import (
    AgentMemoryType,
    SkillFileType,
    TriggerType,
)


class ChatbotTriggerSpecData(BaseModel):
    """Chatbot Trigger Node Data entity."""

    trigger_type: TriggerType = Field(
        default=TriggerType.CHATBOT, description="The type of the trigger node."
    )
    init_message: str | None = Field(
        None,
        description="The init message of the trigger node.",
        min_length=1,
        max_length=2000,
    )


class WebhookTriggerSpecData(BaseModel):
    """Webhook Trigger Node Data entity."""

    trigger_type: TriggerType = Field(
        default=TriggerType.WEBHOOK, description="The type of the trigger node."
    )


class SchedulerTriggerSpecData(BaseModel):
    """Scheduler Trigger Node Data entity."""

    trigger_type: TriggerType = Field(
        default=TriggerType.SCHEDULER, description="The type of the trigger node."
    )
    cron_expression: str = Field(
        ...,
        description="The cron expression of the trigger node.",
        min_length=1,
        max_length=255,
    )
    timezone: str | None = Field(
        None,
        description="The timezone of the trigger node.",
        min_length=1,
        max_length=255,
    )

    @field_validator("cron_expression")
    @classmethod
    def validate_cron_expression(cls, value: str) -> str:
        """Validate that the cron expression is valid using croniter.

        Args:
            value: The cron expression to validate.

        Returns:
            The validated cron expression.

        Raises:
            ValueError: If the cron expression is invalid.
        """
        try:
            croniter(value)
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid cron expression: {value}") from e
        return value


TriggerSpecData = (
    ChatbotTriggerSpecData | WebhookTriggerSpecData | SchedulerTriggerSpecData
)

DecisionType = Literal["approve", "edit", "reject"]


class InterruptOnConfig(BaseModel):
    """Interrupt on config entity."""

    allowed_decisions: list[DecisionType] = Field(
        ["approve", "reject", "edit"],
        description="The allowed decisions of the interrupt on config.",
    )
    description: str | None = Field(
        None,
        description="The description of the interrupt on config.",
    )


class HumanInTheLoopMiddlewareSpec(BaseModel):
    """Human In The Loop Middleware entity."""

    interrupt_on: dict[str, InterruptOnConfig] = Field(
        ...,
        description="The interrupt on of the human in the loop middleware.",
    )
    description_prefix: str | None = Field(
        "Tool execution pending approval",
        description="The description prefix of the human in the loop middleware.",
        min_length=1,
        max_length=255,
    )


PIIType = Literal["email", "credit_card", "ip", "mac_address", "url", "custom"]
PIIStrategy = Literal["block", "redact", "mask", "hash"]


class PIIMiddlewareSpec(BaseModel):
    """PII Middleware entity."""

    pii_type: PIIType | str = Field(
        ...,
        description="The pii type of the pii detection middleware.",
    )
    strategy: PIIStrategy = Field(
        "redact",
        description="The strategy of the pii detection middleware.",
    )
    detector: str | None = Field(
        None,
        description="The detector of the pii detection middleware. regex pattern.",
    )

    @field_validator("detector", mode="before")
    @classmethod
    def _empty_detector_to_none(cls, v: str | None) -> str | None:
        """Convert empty string detector to None to use built-in detector."""
        if isinstance(v, str) and not v.strip():
            return None
        return v

    apply_to_input: bool = Field(
        True,
        description="Whether to apply the pii detection middleware to the input.",
    )
    apply_to_output: bool = Field(
        False,
        description="Whether to apply the pii detection middleware to the output.",
    )
    apply_to_tool_results: bool = Field(
        False,
        description="Whether to apply the pii detection middleware to the tool results.",
    )


ContextFraction = tuple[Literal["fraction"], float]
ContextTokens = tuple[Literal["tokens"], int]
ContextMessages = tuple[Literal["messages"], int]
ContextSize = ContextFraction | ContextTokens | ContextMessages
_DEFAULT_MESSAGES_TO_KEEP = 20
_DEFAULT_TRIM_TOKEN_LIMIT = 4000


class SummarizationMiddlewareSpec(BaseModel):
    """Summarization Middleware entity."""

    model: str | BaseChatModel = Field(
        ...,
        description="The model of the summarization middleware.",
    )
    trigger: ContextSize | list[ContextSize] | None = None
    keep: ContextSize = ("messages", _DEFAULT_MESSAGES_TO_KEEP)
    # token_counter: TokenCounter = count_tokens_approximately, # ignore
    # summary_prompt: str = DEFAULT_SUMMARY_PROMPT, # ignore
    trim_tokens_to_summarize: int | None = _DEFAULT_TRIM_TOKEN_LIMIT


class AgentSpecData(BaseModel):
    """Agent Node Data entity."""

    name: str = Field(
        ...,
        description="The name of the agent node.",
        min_length=1,
        max_length=255,
        # pattern=r"^[a-zA-Z0-9 _-]+$",
    )
    system_prompt: str | None = Field(
        None,
        description="The system prompt of the agent node.",
        min_length=1,
        # NOTE: No max length for system prompt
        # max_length=2000,
    )

    hitl_middleware: HumanInTheLoopMiddlewareSpec | None = Field(
        None,
        description="The human in the loop middleware of the agent node.",
    )

    pii_middlewares: list[PIIMiddlewareSpec] | None = Field(
        None,
        description="The pii middleware of the agent node.",
    )

    summarization_middleware: SummarizationMiddlewareSpec | None = Field(
        None,
        description="The summarization middleware of the agent node.",
    )

    @field_validator("system_prompt")
    @classmethod
    def validate_system_prompt_content(cls, value: str | None) -> str | None:
        """Validate system prompt content for potentially dangerous patterns.

        Args:
            value: The system prompt content to validate.

        Returns:
            The validated system prompt content.

        Raises:
            ValueError: If the system prompt contains potentially dangerous content.
        """
        if value is None or value == "":
            return value

        # Patterns that could indicate potentially dangerous content
        dangerous_patterns = [
            # Code injection attempts - use with parentheses
            r"(?i)\b(?:exec|eval|compile|__import__|getattr|setattr|delattr|globals|locals|vars|dir)\s*\(",
            # File system operations - more specific patterns
            r"(?i)\b(?:os\.system|subprocess\.(?:run|call|check_output|popen)|shutil\.(?:rmtree|move|copy))\s*\(",
            r'(?i)\bopen\s*\(\s*["\'][^"\']*["\'][^)]*["\']w["\']',  # open() with write mode
            # Network operations with method calls
            r"(?i)\b(?:requests\.(?:get|post|put|delete)|urllib\.request\.urlopen|socket\.socket)\s*\(",
            # System commands
            r'(?i)\b(?:system|shell|bash|cmd|powershell)\s*\([^)]*["\'][^"\']*["\'][^)]*\)',
            # Database operations - actual SQL commands
            r"(?i)\b(?:select\s+.*\s+from|insert\s+into|update\s+.*\s+set|delete\s+from|drop\s+table|create\s+table)\s+",
            # Credential assignments - actual assignments
            r'(?i)\b(?:password|passwd|secret|token|key|credential|api_key|access_key)\s*[:=]\s*["\'][a-zA-Z0-9_-]{3,}["\']',
            # Script tags and HTML/JS injection
            r"(?i)<\s*script\b[^>]*>.*</script>",
            r'(?i)\bon(?:click|load|error|focus|blur)\s*=\s*["\'][^"\']*["\']',
            # Environment variables access with brackets
            r'(?i)\b(?:getenv\s*\(\s*["\']|os\.environ\s*\[\s*["\'])[^"\']+["\']\s*[\]\)]',
            # Process manipulation with parentheses
            r"(?i)\b(?:kill|signal|fork|spawn)\s*\([^)]*\)",
        ]

        for pattern in dangerous_patterns:
            if re.search(pattern, value):
                raise ValueError(
                    f"System prompt contains potentially dangerous content. "
                    f"Pattern matched: {pattern}"
                )

        return value


class SubAgentSpecData(AgentSpecData):
    """Sub Agent Node Data entity."""

    description: str | None = Field(
        None,
        description="The description of the sub agent node.",
        min_length=1,
        max_length=9999,
    )


class LLMSpecData(BaseModel):
    """LLM Node Data entity."""

    provider: str = Field(
        ..., description="The provider of the LLM node.", min_length=1, max_length=255
    )
    base_url: str | None = Field(
        None,
        description="The base url of the LLM node.",
        min_length=1,
        max_length=255,
    )
    default_model_id: str | None = Field(
        None,
        description="The default model of the LLM node.",
        min_length=1,
        max_length=255,
    )
    temperature: float = Field(
        0.0,
        description="The temperature of the LLM node.",
        ge=0,
        le=1,
    )
    max_tokens: int = Field(
        5000,
        description="The max tokens of the LLM node.",
        ge=5000,
        # NOTE: TBD max length for max tokens
        le=1000000,
    )
    api_key: str | None = Field(
        None,
        description="The API key of the LLM node.",
        min_length=1,
        max_length=255,
    )
    aws_access_key_id: str | None = Field(
        None,
        description="The AWS access key id of the LLM node.",
        min_length=1,
        max_length=255,
    )
    aws_secret_access_key: str | None = Field(
        None,
        description="The AWS secret access key of the LLM node.",
        min_length=1,
        max_length=255,
    )
    aws_region_name: str | None = Field(
        None,
        description="The AWS region of the LLM node.",
        min_length=1,
        max_length=50,
    )
    max_retries: int = Field(
        2,
        description="The max retries of the LLM node.",
        ge=0,
        le=10,
    )
    request_timeout: int = Field(
        300,
        description="The request timeout of the LLM node.",
        ge=1,
        le=3600,
    )
    streaming: bool = Field(
        True,
        description="The streaming of the LLM node.",
    )


class MemorySpecData(BaseModel):
    """Agent Memory Data entity."""

    memory_type: AgentMemoryType = Field(
        ..., description="The type of the memory node."
    )
    db_uri: str = Field(..., description="The DB URI of the memory node.")


class McpServerSpecData(BaseModel):
    """MCP Server entity."""

    config: dict[str, Any] = Field(
        ...,
        description="The config of the external MCP server node.",
    )


class A2ARemoteAgentSpecData(BaseModel):
    """Remote Agent Node Data entity."""

    name: str = Field(
        ...,
        description="The name of the remote agent node.",
        min_length=1,
        max_length=255,
    )
    agent_card_url: str = Field(
        ...,
        description="The agent card url of the remote agent node.",
        min_length=1,
        max_length=255,
    )
    # TODO: Add the data for the remote agent node


class SkillSpecFileData(BaseModel):
    """File metadata for a skill file attached to a SkillSpecData."""

    file_type: SkillFileType = Field(
        ..., description="File type (SCRIPT, REFERENCE, ASSET)"
    )
    filename: str = Field(..., description="Original filename")
    file_path: Path = Field(..., description="Absolute path to the file on storage")

    @property
    def dir_name(self) -> str:
        """Map file_type to Agent Skills spec directory name."""
        _map = {
            SkillFileType.SCRIPT: "scripts",
            SkillFileType.REFERENCE: "references",
            SkillFileType.ASSET: "assets",
        }
        return _map.get(self.file_type, "assets")


class SkillSpecData(BaseModel):
    """Metadata for a skill per Agent Skills specification (https://agentskills.io/specification)."""

    path: str | None = Field(
        None,
        description="Path to the SKILL.md file.",
    )

    name: str = Field(
        ...,
        description="Skill identifier.",
        pattern=r"^[a-z0-9](?:-?[a-z0-9])*$",
        min_length=1,
        max_length=64,
    )
    """
    Constraints per Agent Skills specification:

    - 1-64 characters
    - Unicode lowercase alphanumeric and hyphens only (`a-z` and `-`).
    - Must not start or end with `-`
    - Must not contain consecutive `--`
    - Must match the parent directory name containing the `SKILL.md` file
    """

    description: str = Field(
        ...,
        description="What the skill does.",
        min_length=1,
        max_length=1024,
    )
    """
    Constraints per Agent Skills specification:

    - 1-1024 characters
    - Should describe both what the skill does and when to use it
    - Should include specific keywords that help agents identify relevant tasks
    """

    license: str | None = Field(
        None,
        description="License name or reference to bundled license file.",
    )

    compatibility: str | None = Field(
        None,
        description="Environment requirements.",
    )

    metadata: dict[str, str] | None = Field(
        None,
        description="Arbitrary key-value mapping for additional metadata.",
    )

    allowed_tools: list[str] | None = Field(
        None,
        description="Tool names the skill recommends using.",
    )

    body_content: str = Field(
        ...,
        description="Body content of the skill.",
    )

    files: list[SkillSpecFileData] = Field(
        default_factory=list,
        description="Attached skill files (scripts, references, assets)",
    )

    def build_skill_markdown(self) -> str:
        """Build the skill markdown."""
        lines = ["---"]
        lines.append(f"name: {self.name}")
        lines.append(f"description: {self.description}")
        if self.license is not None:
            lines.append(f"license: {self.license}")
        if self.compatibility is not None:
            lines.append(f"compatibility: {self.compatibility}")
        if self.metadata:
            lines.append("metadata:")
            for k, v in self.metadata.items():
                lines.append(f"  {k}: {v}")
        if self.allowed_tools:
            lines.append(f"allowed_tools: {' '.join(self.allowed_tools)}")
        lines.append("---")
        lines.append("")
        lines.append(self.body_content)
        lines.append("")
        return "\n".join(lines)
