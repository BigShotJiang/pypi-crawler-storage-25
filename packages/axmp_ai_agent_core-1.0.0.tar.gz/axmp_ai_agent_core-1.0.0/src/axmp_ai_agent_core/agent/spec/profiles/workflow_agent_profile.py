"""A profile of an AI agent."""

from __future__ import annotations

from pydantic import Field, model_validator

from axmp_ai_agent_core.agent.spec.profile_base import (
    SpecBaseFlow,
    SpecBaseNode,
    SpecBaseProfile,
)
from axmp_ai_agent_core.agent.spec.profile_node_data import (
    AgentSpecData,
    ChatbotTriggerSpecData,
    LLMSpecData,
    McpServerSpecData,
    MemorySpecData,
    SchedulerTriggerSpecData,
    WebhookTriggerSpecData,
)


class WorkflowAgentSpecNode(SpecBaseNode):
    """Node Entity. This entity is used to store the node of the workflow agent."""

    data: (
        ChatbotTriggerSpecData
        | WebhookTriggerSpecData
        | SchedulerTriggerSpecData
        | AgentSpecData
        | LLMSpecData
        | MemorySpecData
        | McpServerSpecData
        | None
    ) = None

    @model_validator(mode="after")
    def validate_node_data(self) -> WorkflowAgentSpecNode:
        """Validate the node data."""
        # TODO: Implement validation logic

        return self


class WorkflowAgentSpecFlow(SpecBaseFlow):
    """A flow of an AI agent."""

    nodes: list[WorkflowAgentSpecNode] | None = Field(
        None,
        description="The nodes of the flow.",
    )


class WorkflowAgentSpecProfile(SpecBaseProfile):
    """A profile of an AI agent."""

    # NOTE: Override the nodes of the BaseProfile
    flow: WorkflowAgentSpecFlow | None = None

    @model_validator(mode="after")
    def validate_profile_restrictions(self) -> WorkflowAgentSpecProfile:
        """Validate that only AI_AGENT type node can be root node.

        If there is a non-AI_AGENT type node with root_node=True, raise validation error.
        """
        if not self.flow and not self.flow.nodes:
            return self

        # TODO: Implement validation logic

        return self
