"""A profile of a single agent."""

from __future__ import annotations

from collections import Counter

from pydantic import Field, model_validator

from axmp_ai_agent_core.agent.spec.profile_base import (
    SpecBaseEdge,
    SpecBaseFlow,
    SpecBaseNode,
    SpecBaseProfile,
)
from axmp_ai_agent_core.agent.spec.profile_node_data import (
    AgentSpecData,
    ChatbotTriggerSpecData,
    LLMSpecData,
    McpServerSpecData,
    MemorySpecData,
    SchedulerTriggerSpecData,
    # SkillSpecData,
    WebhookTriggerSpecData,
)
from axmp_ai_agent_core.agent.spec.types import NodeType

# --- Limit constants ---
MAX_TRIGGER_NODES = 1
MAX_SKILL_NODES = 10
MAX_MCP_SERVER_NODES = 10
MAX_MEMORY_NODES = 1

# node_type -> allowed data classes mapping
_NODE_TYPE_DATA_MAP: dict[NodeType, tuple[type, ...]] = {
    NodeType.TRIGGER: (
        ChatbotTriggerSpecData,
        WebhookTriggerSpecData,
        SchedulerTriggerSpecData,
    ),
    NodeType.AI_AGENT: (AgentSpecData,),
    NodeType.LLM: (LLMSpecData,),
    NodeType.MEMORY: (MemorySpecData,),
    NodeType.MCP_SERVER: (McpServerSpecData,),
    # NodeType.SKILL: (SkillSpecData,), # NOTE: Unsupported the skill by langchain api
}


class SingleAgentSpecNode(SpecBaseNode):
    """Node entity for a single agent profile."""

    data: (
        ChatbotTriggerSpecData
        | WebhookTriggerSpecData
        | SchedulerTriggerSpecData
        | AgentSpecData
        | LLMSpecData
        | MemorySpecData
        | McpServerSpecData
        # | SkillSpecData
    ) = Field(..., description="The data of the node.")

    @model_validator(mode="after")
    def validate_node_data(self) -> SingleAgentSpecNode:
        """Validate the node data matches the node type."""
        if self.node_type is None:
            raise ValueError("Node type must be set.")

        if self.data is None:
            return self

        allowed = _NODE_TYPE_DATA_MAP.get(self.node_type)
        if allowed is None:
            raise ValueError(f"Unknown node type: {self.node_type}")

        if not isinstance(self.data, allowed):
            raise ValueError(
                f"Node data type {type(self.data).__name__} is not valid "
                f"for node type {self.node_type.value}."
            )
        return self


class SingleAgentSpecFlow(SpecBaseFlow):
    """A flow of a single agent."""

    nodes: list[SingleAgentSpecNode] | None = Field(
        None,
        description="The nodes of the flow.",
    )


class SingleAgentSpecProfile(SpecBaseProfile):
    """A profile of a single agent."""

    flow: SingleAgentSpecFlow | None = None

    @model_validator(mode="after")
    def validate_profile_restrictions(self) -> SingleAgentSpecProfile:
        """Validate profile-level restrictions for the single agent.

        Enforce structural constraints on the node graph including
        root node rules, global node counts, and agent child constraints.
        """
        if not self.flow or not self.flow.nodes:
            return self

        nodes = self.flow.nodes
        edges = self.flow.edges or []

        validate_singleagent_flow(nodes=nodes, edges=edges)

        return self

    def get_agent_node(self) -> SingleAgentSpecNode | None:
        """Get the AI agent node of the single agent profile."""
        return next(
            (n for n in self.flow.nodes if n.node_type == NodeType.AI_AGENT), None
        )

    def get_trigger_node(self) -> SingleAgentSpecNode:
        """Get the trigger node of the single agent profile."""
        trigger_nodes = [n for n in self.flow.nodes if n.node_type == NodeType.TRIGGER]
        if len(trigger_nodes) > MAX_TRIGGER_NODES:
            raise ValueError(
                f"At most {MAX_TRIGGER_NODES} TRIGGER node is allowed. "
                f"Found {len(trigger_nodes)}."
            )
        if len(trigger_nodes) <= 0:
            raise ValueError("At least one TRIGGER node is required.")

        return trigger_nodes[0]

    def get_agent_elements(self) -> list[SingleAgentSpecNode]:
        """Get the child elements of the AI agent node."""
        agent_node = self.get_agent_node()
        if agent_node is None or agent_node.id is None or self.flow is None:
            return []

        target_node_ids = {
            edge.target for edge in self.flow.edges if edge.source == agent_node.id
        }

        return [node for node in self.flow.nodes if node.id in target_node_ids]

    def get_all_mcp_server_nodes(self) -> list[SingleAgentSpecNode]:
        """Get the MCP server nodes of the single agent profile."""
        return [n for n in self.flow.nodes if n.node_type == NodeType.MCP_SERVER]

    def get_all_skill_nodes(self) -> list[SingleAgentSpecNode]:
        """Get the skill nodes of the single agent profile."""
        raise NotImplementedError("Single agent profile does not support skill nodes.")


def validate_singleagent_flow(
    nodes: list[SingleAgentSpecNode], edges: list[SpecBaseEdge]
):
    """Validate the single agent flow."""
    node_map: dict[str, SingleAgentSpecNode] = {}
    type_counts: Counter[NodeType] = Counter()
    for node in nodes:
        if node.id is not None:
            node_map[node.id] = node
        if node.node_type is not None:
            type_counts[node.node_type] += 1

    # --- Global constraints ---

    # AI_AGENT: exactly 1, must be root_node=True
    ai_agent_nodes = [n for n in nodes if n.node_type == NodeType.AI_AGENT]
    if len(ai_agent_nodes) != 1:
        raise ValueError(
            f"Exactly one AI_AGENT node is required. Found {len(ai_agent_nodes)}."
        )
    if not ai_agent_nodes[0].root_node:
        raise ValueError("AI_AGENT node must have root_node=True.")

    # Only AI_AGENT can be root_node
    for node in nodes:
        if node.node_type != NodeType.AI_AGENT and node.root_node:
            raise ValueError(
                f"Only AI_AGENT type node can be root node. "
                f"Found {node.node_type.value} type node with root_node=True."
            )

    # TRIGGER: max MAX_TRIGGER_NODES
    if type_counts[NodeType.TRIGGER] > MAX_TRIGGER_NODES:
        raise ValueError(
            f"At most {MAX_TRIGGER_NODES} TRIGGER node is allowed. "
            f"Found {type_counts[NodeType.TRIGGER]}."
        )

    # SUB_AGENT: not allowed in single agent
    if type_counts[NodeType.SUB_AGENT] > 0:
        raise ValueError(
            "SUB_AGENT nodes are not allowed in a single agent profile. "
            f"Found {type_counts[NodeType.SUB_AGENT]}."
        )

    # REMOTE_AGENT: not allowed in single agent
    if type_counts[NodeType.REMOTE_AGENT] > 0:
        raise ValueError(
            "REMOTE_AGENT nodes are not allowed in a single agent profile. "
            f"Found {type_counts[NodeType.REMOTE_AGENT]}."
        )

    # --- Build children map from edges ---
    children_by_source: dict[str, list[str]] = {}
    for edge in edges:
        if edge.source is not None and edge.target is not None:
            children_by_source.setdefault(edge.source, []).append(edge.target)

    # --- Agent (AI_AGENT) child constraints ---
    agent = ai_agent_nodes[0]
    if agent.id is not None:
        agent_children = children_by_source.get(agent.id, [])
        child_types: Counter[NodeType] = Counter()
        for child_id in agent_children:
            child = node_map.get(child_id)
            if child and child.node_type is not None:
                child_types[child.node_type] += 1

        if child_types[NodeType.LLM] != 1:
            raise ValueError(
                f"Agent must have exactly 1 LLM node. "
                f"Found {child_types[NodeType.LLM]}."
            )
        if child_types[NodeType.MEMORY] > MAX_MEMORY_NODES:
            raise ValueError(
                f"Agent can have at most {MAX_MEMORY_NODES} MEMORY node. "
                f"Found {child_types[NodeType.MEMORY]}."
            )
        if child_types[NodeType.SKILL] > MAX_SKILL_NODES:
            raise ValueError(
                f"Agent can have at most {MAX_SKILL_NODES} SKILL nodes. "
                f"Found {child_types[NodeType.SKILL]}."
            )
        if child_types[NodeType.MCP_SERVER] > MAX_MCP_SERVER_NODES:
            raise ValueError(
                f"Agent can have at most {MAX_MCP_SERVER_NODES} MCP_SERVER nodes. "
                f"Found {child_types[NodeType.MCP_SERVER]}."
            )
        if child_types[NodeType.SUB_AGENT] > 0:
            raise ValueError(
                "Agent cannot have SUB_AGENT child nodes in a single agent profile."
            )
