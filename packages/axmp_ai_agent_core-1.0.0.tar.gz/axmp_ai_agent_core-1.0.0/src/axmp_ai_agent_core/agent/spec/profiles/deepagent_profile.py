"""A profile of a deep agent."""

from __future__ import annotations

from collections import Counter
from typing import Any

from pydantic import Field, model_validator

from axmp_ai_agent_core.agent.spec.profile_base import (
    SpecBaseEdge,
    SpecBaseFlow,
    SpecBaseNode,
    SpecBaseProfile,
)
from axmp_ai_agent_core.agent.spec.profile_node_data import (
    AgentSpecData,
    ChatbotTriggerSpecData,
    LLMSpecData,
    McpServerSpecData,
    MemorySpecData,
    SchedulerTriggerSpecData,
    SkillSpecData,
    SubAgentSpecData,
    WebhookTriggerSpecData,
)
from axmp_ai_agent_core.agent.spec.types import NodeType

# --- Limit constants ---
MAX_TRIGGER_NODES = 1
MAX_SUB_AGENT_NODES = 10
MAX_SKILL_NODES = 10
MAX_MCP_SERVER_NODES = 10
MAX_MEMORY_NODES = 1

# node_type -> allowed data classes mapping
_NODE_TYPE_DATA_MAP: dict[NodeType, tuple[type, ...]] = {
    NodeType.TRIGGER: (
        ChatbotTriggerSpecData,
        WebhookTriggerSpecData,
        SchedulerTriggerSpecData,
    ),
    NodeType.AI_AGENT: (AgentSpecData,),
    NodeType.SUB_AGENT: (SubAgentSpecData,),
    NodeType.LLM: (LLMSpecData,),
    NodeType.MEMORY: (MemorySpecData,),
    NodeType.MCP_SERVER: (McpServerSpecData,),
    NodeType.SKILL: (SkillSpecData,),
}


class DeepAgentSpecNode(SpecBaseNode):
    """Node Entity. This entity is used to store the node of the deep agent."""

    data: (
        ChatbotTriggerSpecData
        | WebhookTriggerSpecData
        | SchedulerTriggerSpecData
        | AgentSpecData
        | SubAgentSpecData
        | LLMSpecData
        | MemorySpecData
        | McpServerSpecData
        | SkillSpecData
    ) = Field(..., description="The data of the node.")

    @model_validator(mode="after")
    def validate_node_data(self) -> DeepAgentSpecNode:
        """Validate the node data matches the node type."""
        if self.node_type is None:
            raise ValueError("Node type must be set.")

        if self.data is None:
            return self

        allowed = _NODE_TYPE_DATA_MAP.get(self.node_type)
        if allowed is None:
            raise ValueError(f"Unknown node type: {self.node_type}")

        if not isinstance(self.data, allowed):
            raise ValueError(
                f"Node data type {type(self.data).__name__} is not valid "
                f"for node type {self.node_type.value}."
            )
        return self


class DeepAgentSpecFlow(SpecBaseFlow):
    """A flow of a deep agent."""

    nodes: list[DeepAgentSpecNode] | None = Field(
        None,
        description="The nodes of the flow.",
    )


class DeepAgentSpecProfile(SpecBaseProfile):
    """A profile of a deep agent."""

    # NOTE: Override the nodes of the BaseProfile
    flow: DeepAgentSpecFlow | None = None

    @model_validator(mode="after")
    def validate_profile_restrictions(self) -> DeepAgentSpecProfile:
        """Validate profile-level restrictions for the deep agent.

        Enforce structural constraints on the node graph including
        root node rules, global node counts, and per-agent child constraints.
        """
        if not self.flow or not self.flow.nodes:
            return self

        nodes = self.flow.nodes
        edges = self.flow.edges or []

        validate_deepagent_flow(nodes=nodes, edges=edges)

        return self

    def get_sub_agents(self) -> list[DeepAgentSpecNode]:
        """Get the sub agents nodes of the deep agent profile."""
        return [n for n in self.flow.nodes if n.node_type == NodeType.SUB_AGENT]

    def get_main_agent(self) -> DeepAgentSpecNode | None:
        """Get the main agent node of the deep agent profile."""
        return next(
            (n for n in self.flow.nodes if n.node_type == NodeType.AI_AGENT), None
        )

    def get_trigger_node(self) -> DeepAgentSpecNode:
        """Get the trigger node of the deep agent profile."""
        trigger_nodes = [n for n in self.flow.nodes if n.node_type == NodeType.TRIGGER]
        if len(trigger_nodes) > MAX_TRIGGER_NODES:
            raise ValueError(
                f"At most {MAX_TRIGGER_NODES} TRIGGER node is allowed. "
                f"Found {len(trigger_nodes)}."
            )
        if len(trigger_nodes) <= 0:
            raise ValueError("At least one TRIGGER node is required.")

        return trigger_nodes[0]

    def get_elements_of_sub_agent(self, sub_agent_id: str) -> list[DeepAgentSpecNode]:
        """Get the elements of the sub agent with the given id."""
        if sub_agent_id is None or self.flow is None:
            return []

        target_node_ids = {
            edge.target for edge in self.flow.edges if edge.source == sub_agent_id
        }

        return [node for node in self.flow.nodes if node.id in target_node_ids]

    def get_elements_of_main_agent(
        self, main_agent_id: str, include_sub_agents: bool = False
    ) -> list[DeepAgentSpecNode]:
        """Get the elements of the main agent with the given id."""
        if main_agent_id is None or self.flow is None:
            return []

        target_node_ids = {
            edge.target for edge in self.flow.edges if edge.source == main_agent_id
        }

        return [
            node
            for node in self.flow.nodes
            if node.id in target_node_ids
            and (include_sub_agents or node.node_type != NodeType.SUB_AGENT)
        ]

    def get_all_mcp_server_nodes(self) -> list[DeepAgentSpecNode]:
        """Get the mcp server nodes of the deep agent profile."""
        # NOTE : the same mcp-server can be binded to multiple agent nodes. So we need to get the unique mcp server nodes.
        seen_ids: set[str] = set()
        unique_mcp_nodes = []
        for node in self.flow.nodes:
            if node.node_type == NodeType.MCP_SERVER:
                mcp_server_id = self._get_mcp_server_id_from_mcp_connection(
                    node.data.config
                )
                if mcp_server_id not in seen_ids:
                    seen_ids.add(mcp_server_id)
                    unique_mcp_nodes.append(node)

        return unique_mcp_nodes

    def _get_mcp_server_id_from_mcp_connection(
        self, mcp_connection: dict[str, Any]
    ) -> str:
        """Get mcp server id from mcp connections.

        Args:
            mcp_connection: The mcp connection.
            It should be
            ```json
            {
                "server_name": {
                    "transport_type": "http",
                    "url": "http://localhost:8000"
                }
            }
            ```

        Returns:
            The mcp server id.
        """
        if mcp_connection is None or len(mcp_connection) == 0:
            raise ValueError(
                "The MCP connection is empty",
            )

        server_id = next(iter(mcp_connection))
        if not server_id:
            raise ValueError(
                "The MCP server doesn't have server id",
            )
        return server_id

    def get_mcp_server_nodes_of_sub_agent(
        self, sub_agent_id: str
    ) -> list[DeepAgentSpecNode]:
        """Get the mcp server nodes of the sub agent with the given id."""
        return [
            n
            for n in self.get_elements_of_sub_agent(sub_agent_id=sub_agent_id)
            if n.node_type == NodeType.MCP_SERVER
        ]

    def get_mcp_server_nodes_of_main_agent(
        self, main_agent_id: str
    ) -> list[DeepAgentSpecNode]:
        """Get the mcp server nodes of the main agent with the given id."""
        return [
            n
            for n in self.get_elements_of_main_agent(main_agent_id=main_agent_id)
            if n.node_type == NodeType.MCP_SERVER
        ]

    def get_all_skill_nodes(self) -> list[DeepAgentSpecNode]:
        """Get the skill nodes of the deep agent profile."""
        # NOTE : the same skill can be binded to multiple agent nodes. So we need to get the unique skill nodes.
        seen_ids: set[str] = set()
        unique_skill_nodes = []
        for node in self.flow.nodes:
            if node.node_type == NodeType.SKILL and node.data.name not in seen_ids:
                seen_ids.add(node.data.name)
                unique_skill_nodes.append(node)
        return unique_skill_nodes

    def get_skill_nodes_of_sub_agent(
        self, sub_agent_id: str
    ) -> list[DeepAgentSpecNode]:
        """Get the skill nodes of the sub agent with the given id."""
        return [
            n
            for n in self.get_elements_of_sub_agent(sub_agent_id=sub_agent_id)
            if n.node_type == NodeType.SKILL
        ]

    def get_skill_nodes_of_main_agent(
        self, main_agent_id: str
    ) -> list[DeepAgentSpecNode]:
        """Get the skill nodes of the main agent with the given id."""
        return [
            n
            for n in self.get_elements_of_main_agent(main_agent_id=main_agent_id)
            if n.node_type == NodeType.SKILL
        ]


def validate_deepagent_flow(nodes: list[DeepAgentSpecNode], edges: list[SpecBaseEdge]):
    """Validate the deep agent flow."""
    node_map: dict[str, DeepAgentSpecNode] = {}
    type_counts: Counter[NodeType] = Counter()
    for node in nodes:
        if node.id is not None:
            node_map[node.id] = node
        if node.node_type is not None:
            type_counts[node.node_type] += 1

    # --- Global constraints ---

    # AI_AGENT: exactly 1, must be root_node=True
    ai_agent_nodes = [n for n in nodes if n.node_type == NodeType.AI_AGENT]
    if len(ai_agent_nodes) != 1:
        raise ValueError(
            f"Exactly one AI_AGENT node is required. Found {len(ai_agent_nodes)}."
        )
    if not ai_agent_nodes[0].root_node:
        raise ValueError("AI_AGENT node must have root_node=True.")

    # Only AI_AGENT can be root_node
    for node in nodes:
        if node.node_type != NodeType.AI_AGENT and node.root_node:
            raise ValueError(
                f"Only AI_AGENT type node can be root node. "
                f"Found {node.node_type.value} type node with root_node=True."
            )

    # TRIGGER: max MAX_TRIGGER_NODES
    if type_counts[NodeType.TRIGGER] > MAX_TRIGGER_NODES:
        raise ValueError(
            f"At most {MAX_TRIGGER_NODES} TRIGGER node is allowed. "
            f"Found {type_counts[NodeType.TRIGGER]}."
        )

    # SUB_AGENT: max MAX_SUB_AGENT_NODES
    if type_counts[NodeType.SUB_AGENT] > MAX_SUB_AGENT_NODES:
        raise ValueError(
            f"At most {MAX_SUB_AGENT_NODES} SUB_AGENT nodes are allowed. "
            f"Found {type_counts[NodeType.SUB_AGENT]}."
        )

    # --- Build children map from edges ---
    children_by_source: dict[str, list[str]] = {}
    for edge in edges:
        if edge.source is not None and edge.target is not None:
            children_by_source.setdefault(edge.source, []).append(edge.target)

    # --- Main Agent (AI_AGENT) child constraints ---
    main_agent = ai_agent_nodes[0]
    if main_agent.id is not None:
        main_children = children_by_source.get(main_agent.id, [])
        main_child_types: Counter[NodeType] = Counter()
        for child_id in main_children:
            child = node_map.get(child_id)
            if child and child.node_type is not None:
                main_child_types[child.node_type] += 1

        if main_child_types[NodeType.LLM] != 1:
            raise ValueError(
                f"Main Agent must have exactly 1 LLM node. "
                f"Found {main_child_types[NodeType.LLM]}."
            )
        if main_child_types[NodeType.MEMORY] > MAX_MEMORY_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_MEMORY_NODES} MEMORY node. "
                f"Found {main_child_types[NodeType.MEMORY]}."
            )
        if main_child_types[NodeType.SKILL] > MAX_SKILL_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_SKILL_NODES} SKILL nodes. "
                f"Found {main_child_types[NodeType.SKILL]}."
            )
        if main_child_types[NodeType.MCP_SERVER] > MAX_MCP_SERVER_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_MCP_SERVER_NODES} MCP_SERVER nodes. "
                f"Found {main_child_types[NodeType.MCP_SERVER]}."
            )
        if main_child_types[NodeType.SUB_AGENT] > MAX_SUB_AGENT_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_SUB_AGENT_NODES} SUB_AGENT nodes. "
                f"Found {main_child_types[NodeType.SUB_AGENT]}."
            )

    # --- Sub Agent child constraints ---
    sub_agent_nodes = [n for n in nodes if n.node_type == NodeType.SUB_AGENT]
    for sub_agent in sub_agent_nodes:
        if sub_agent.id is None:
            continue
        sub_children = children_by_source.get(sub_agent.id, [])
        sub_child_types: Counter[NodeType] = Counter()
        for child_id in sub_children:
            child = node_map.get(child_id)
            if child and child.node_type is not None:
                sub_child_types[child.node_type] += 1

        # Sub Agent must have exactly 1 LLM
        if sub_child_types[NodeType.LLM] != 1:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' must have exactly 1 LLM node. "
                f"Found {sub_child_types[NodeType.LLM]}."
            )
        # Sub Agent: max MAX_SKILL_NODES SKILLs
        if sub_child_types[NodeType.SKILL] > MAX_SKILL_NODES:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' can have at most {MAX_SKILL_NODES} SKILL nodes. "
                f"Found {sub_child_types[NodeType.SKILL]}."
            )
        # Sub Agent: max MAX_MCP_SERVER_NODES MCP_SERVERs
        if sub_child_types[NodeType.MCP_SERVER] > MAX_MCP_SERVER_NODES:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' can have at most {MAX_MCP_SERVER_NODES} MCP_SERVER nodes. "
                f"Found {sub_child_types[NodeType.MCP_SERVER]}."
            )
        # Sub Agent cannot have nested SUB_AGENTs
        if sub_child_types[NodeType.SUB_AGENT] > 0:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' cannot have nested SUB_AGENT nodes."
            )
        # Sub Agent cannot have MEMORY nodes
        if sub_child_types[NodeType.MEMORY] > 0:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' cannot have MEMORY nodes. "
                f"Only the Main Agent can have MEMORY."
            )
