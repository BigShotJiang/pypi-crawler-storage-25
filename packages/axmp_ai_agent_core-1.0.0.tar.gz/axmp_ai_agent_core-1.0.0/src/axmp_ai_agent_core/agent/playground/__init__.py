"""MCP Server Playground agent profile factory."""

from axmp_ai_agent_core.agent.playground.mcp_server_playground_agent_profile import (
    build_playground_spec_profile,
)

__all__ = ["build_playground_spec_profile"]
