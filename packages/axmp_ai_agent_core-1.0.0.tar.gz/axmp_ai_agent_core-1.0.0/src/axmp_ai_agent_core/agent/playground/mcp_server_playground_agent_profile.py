"""Factory for building MCP Server Playground agent profiles."""

from __future__ import annotations

import uuid
from typing import Any

from axmp_ai_agent_core.agent.spec.profile_base import SpecBaseEdge
from axmp_ai_agent_core.agent.spec.profile_node_data import (
    AgentSpecData,
    ChatbotTriggerSpecData,
    LLMSpecData,
    McpServerSpecData,
)
from axmp_ai_agent_core.agent.spec.profiles.singleagent_profile import (
    SingleAgentSpecFlow,
    SingleAgentSpecNode,
    SingleAgentSpecProfile,
)
from axmp_ai_agent_core.agent.spec.types import NodeType, ProfileType

_PLAYGROUND_AGENT_NAME = "mcp-playground-agent"
_PLAYGROUND_PROFILE_NAME = "MCP Playground"


def build_playground_spec_profile(
    *,
    llm_spec_data: LLMSpecData,
    mcp_server_configs: list[dict[str, Any]] | None = None,
    system_prompt: str | None = None,
) -> SingleAgentSpecProfile:
    """Build a SingleAgentSpecProfile for MCP Server Playground.

    Args:
        llm_spec_data: LLM configuration for the playground agent.
        mcp_server_configs: List of MCP server config dicts.
            Each dict should follow the McpServerSpecData.config format:
            ``{"server_name": {"transport": "...", "url": "...", ...}}``.
        system_prompt: System prompt for the agent. If None, a default is used.

    Returns:
        A fully validated SingleAgentSpecProfile ready for SingleAgentWrapper.
    """
    # --- Node IDs ---
    trigger_id = _gen_id()
    agent_id = _gen_id()
    llm_id = _gen_id()

    # --- Trigger node (chatbot) ---
    trigger_node = SingleAgentSpecNode(
        id=trigger_id,
        node_type=NodeType.TRIGGER,
        root_node=False,
        data=ChatbotTriggerSpecData(),
    )

    # --- AI Agent node (root) ---
    agent_node = SingleAgentSpecNode(
        id=agent_id,
        node_type=NodeType.AI_AGENT,
        root_node=True,
        data=AgentSpecData(
            name=_PLAYGROUND_AGENT_NAME,
            system_prompt=system_prompt,
        ),
    )

    # --- LLM node ---
    llm_node = SingleAgentSpecNode(
        id=llm_id,
        node_type=NodeType.LLM,
        root_node=False,
        data=llm_spec_data,
    )

    # --- Edges: trigger→agent, agent→llm ---
    edges: list[SpecBaseEdge] = [
        SpecBaseEdge(
            id=_gen_id(),
            source=trigger_id,
            target=agent_id,
        ),
        SpecBaseEdge(
            id=_gen_id(),
            source=agent_id,
            target=llm_id,
        ),
    ]

    # --- MCP Server nodes ---
    nodes: list[SingleAgentSpecNode] = [trigger_node, agent_node, llm_node]

    for mcp_config in mcp_server_configs or []:
        mcp_node_id = _gen_id()
        mcp_node = SingleAgentSpecNode(
            id=mcp_node_id,
            node_type=NodeType.MCP_SERVER,
            root_node=False,
            data=McpServerSpecData(config=mcp_config),
        )
        nodes.append(mcp_node)
        edges.append(
            SpecBaseEdge(
                id=_gen_id(),
                source=agent_id,
                target=mcp_node_id,
            )
        )

    # --- Assemble profile ---
    return SingleAgentSpecProfile(
        id=_gen_id(),
        name=_PLAYGROUND_PROFILE_NAME,
        system_name=_PLAYGROUND_AGENT_NAME,
        agent_type=ProfileType.SINGLE_AGENT,
        flow=SingleAgentSpecFlow(
            nodes=nodes,
            edges=edges,
        ),
    )


def _gen_id() -> str:
    """Generate a unique node/edge ID."""
    return uuid.uuid4().hex[:12]
