"""This module defines the data structures for chat messages.

The data structures are used to define the data structures for chat messages.
"""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Annotated, Any, List, Literal

from pydantic import BaseModel, Field


class ChatRole(StrEnum):
    """The role of a message."""

    HUMAN = "human"
    AI = "ai"
    SYSTEM = "system"
    TOOL = "tool"


class ActionModel(BaseModel):
    """The model for the action of a tool call."""

    name: str = Field(..., min_length=1, description="Tool name")
    args: dict = Field(default_factory=dict, description="Tool arguments")


class ApproveDecisionModel(BaseModel):
    """The model for approve."""

    type: Literal["approve"] = "approve"


class EditDecisionModel(BaseModel):
    """The model for edit."""

    type: Literal["edit"] = "edit"
    edited_action: ActionModel


class RejectDecisionModel(BaseModel):
    """The model for reject."""

    type: Literal["reject"] = "reject"
    message: str | None = Field(None, description="Optional rejection reason")


DecisionModel = Annotated[
    ApproveDecisionModel | EditDecisionModel | RejectDecisionModel,
    Field(discriminator="type"),
]


class ChatRequest(BaseModel):
    """A request for a chat, which has a thread_id and a list of messages."""

    locale: str | None = Field(default="ko_KR")
    timezone: str | None = Field(default="Asia/Seoul")
    files: List[str] | None = Field(default=None)
    prompt: str | None = Field(default=None)
    llm_model: str | None = Field(default="openai/gpt-4o")
    project_id: str | None = Field(
        default=None,
        description="The project ID. If the conversation is the project chat, the project ID is required.",
    )
    web_search_enabled: bool | None = Field(
        default=False,
        description="Whether to enable web search.",
    )
    deep_research_enabled: bool | None = Field(
        default=False,
        description="Whether to enable deep research.",
    )


class ResumeRequest(BaseModel):
    """A request for a resume."""

    decisions: list[DecisionModel] = Field(
        ...,
        description="The decision of the human-in-the-loop.",
    )


class ActionRequest(BaseModel):
    """Request for an action that requires review."""

    name: str = Field(..., description="Tool or action name")
    args: dict[str, Any] = Field(default_factory=dict, description="Action arguments")
    description: str | None = Field(
        None, description="Human-readable description of the action"
    )


class ReviewConfig(BaseModel):
    """Configuration for reviewing an action request."""

    action_name: str = Field(..., description="Name of the action to review")
    allowed_decisions: list[Literal["approve", "edit", "reject"]] = Field(
        default_factory=list,
        description="Allowed review decisions (e.g. approve, edit, reject)",
    )


class Interrupt(BaseModel):
    """Interrupt requiring user review of pending action requests."""

    id: str = Field(..., description="Unique interrupt identifier")
    action_requests: list[ActionRequest] = Field(
        default_factory=list, description="Pending action requests"
    )
    review_configs: list[ReviewConfig] = Field(
        default_factory=list, description="Review configurations per action"
    )


# Citation structure
# ------------------------------------------------------------------------------
# {
#     "type": "knowledge",
#     "title": "Reliable, Flexible Hosting at\\u3010Z.com Cloud\\u3011",
#     "url": "https://cloud.z.com/mm/",
#     "snippet": "xxxxx",
#     "metadata": {
#         "type": "webpage_metadata",
#         "site_domain": "z.com",
#         "favicon_url": "https://www.google.com/s2/favicons?sz=64&domain=z.com",
#         "site_name": "Z"
#     },
#     "is_missing": false
# }
# ------------------------------------------------------------------------------
class Metadata(BaseModel):
    """The model for the metadata of citation."""

    type_: str | None = Field(
        default=None, description="type of the metadata", alias="type"
    )
    site_domain: str | None = Field(
        default=None, description="site domain of the metadata"
    )
    favicon_url: str | None = Field(
        default=None, description="favicon url of the metadata"
    )
    site_name: str | None = Field(default=None, description="site name of the metadata")


class Citation(BaseModel):
    """The model for the citation."""

    type_: str | None = Field(
        default=None, description="type of the citation", alias="type"
    )
    source: str | None = Field(default=None, description="source of the citation")
    title: str | None = Field(default=None, description="title of the citation")
    snippet: str | None = Field(default=None, description="snippet of the citation")
    metadata: Metadata | None = Field(
        default=None, description="metadata of the citation"
    )


class EventStreamDataType(StrEnum):
    """The type of a message."""

    MESSAGE_START = "message_start"
    MESSAGE_STOP = "message_stop"
    CONTENT_BLOCK_START = "content_block_start"
    CONTENT_BLOCK_STOP = "content_block_stop"
    CONTENT_BLOCK_DELTA = "content_block_delta"
    # New types
    PROCESSING_MESSAGE = "processing_message"
    TOOL_CALL = "tool_call"
    TOOL_CALL_RESULT = "tool_call_result"
    INTERRUPT = "interrupt"


# Sample SSE Data
# ------------------------------------------------------------------------------
# event: message_start
# data: {"event":"message_start","message":{"thread_id":"adfasdfdfdf","type_":"message","role":"ai","model":"","content":[]}}

# event: content_block_start
# data: {"event":"content_block_start","content_block":{"start_timestamp":"2026-03-22T19:10:06.257761","type_":"text","citations":[]}}

# event: tool_call
# data: {"event":"tool_call","data":{"ns_id":"ns_mainagent","agent_name":"MainAgent","tool_call_id":"toolu_017F4c8CNHuMoKSgn2RJjCTx","tool_name":"read_file","tool_args":{"file_path":"/skills/main-agent/studio-agent-profiles-report/SKILL.md"}}}

# event: tool_call_result
# data: {"event":"tool_call_result","data":{"tool_call_id":"toolu_017F4c8CNHuMoKSgn2RJjCTx","content":"     1\t---\n     2\tname: studio-agent-profiles-report\n     3\tdescription: 에이전트 프로필 목록을 조회하고 Markdown으로 정리하여 Notion 페이지로 생성하는 스킬. agent profile report, 에이전트 보고서\n     4\t---\n     5\t\n     6\t## When to Use This Skill\n     7\t\n     8\tStudio Agent Profiles Report를 생성할 때, 반드시 아래와 같이 해야 합니다.\n     9\t\n    10\t## Instructions\n    11\t\n    12\t1. studio-agent의 get_agents_simple Tool을 사용하여 Agent List를 가져옵니다.\n    13\t2. studio-agent의 get_agent_profile_by_id Tool을 사용하여 가장 마지막 Agent의 상세 프로필을 가져옵니다.\n    14\t3. Markdown으로 Agent List와 Agent Detail 정보를 정리하여 studio-agent-profiles.md 파일을 생성합니다.\n    15\t4. notion-agent의 notion-create-pages Tool을 사용하여 studio-agent-profiles.md 파일 내용으로 Notion에 페이지로 생성합니다.\n    16\t5. studio-agent-profiles.md 파일을 삭제합니다.\n    17\t\n    18\t\n    19\t## Report Content\n    20\t### 1. Overview\n    21\t- 전체 Agent 수\n    22\t- COMPLETED\n    23\t- DRAFT\n    24\t- Agent 타입\n    25\t\n    26\t### 2. Agent List\n    27\t테이블 형식으로 작성하고 필드는 아래 참고.\n    28\t- Agent 이름\n    29\t- Agent ID\n    30\t- 상태\n    31\t- Runtime 타입\n    32\t- 생성자\n    33\t\n    34\t### 3. Summary\n    35\t- 상태별 요약\n    36\t\n    37\t### 4. 작성일, 작성자 정보 기입\n    38\t- 작성일: YYYY-MM-DD\n    39\t- 작성자: [작성자 이름]","status":"success"}}

# event: processing_message
# data: {"event":"processing_message","data":{"ns_id":"ns_subagent_6d958ff8-eb08-a304-e2ce-e624fa927f8a","agent_name":"StudioAgent","content":"Here is the **complete raw response** from the `get_agents_simple` tool, listing all agents with their full details:\n\n---\n\n## 📋 Full Agent List (13 Agents Total)\n\n| # | Name | ID | Status | Runtime Type | Type | Created By |\n|---|------|----|--------|--------------|------|------------|\n| 1 | **AI Platform Analyze Agent** | `6973f3158d0e3377b25984e1` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 2 | **Alert Management Agent** | `68f85f53e99cc4118371b535` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 3 | **Alert Report Generator** | `692d24acabbc50a936371efc` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 4 | **Cloud Strategy Intelligence Agent** | `696061a98d0e3377b25984a9` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 5 | **K8s Management Agent** | `692e52d85504cfafce3dd527` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 6 | **Movie Management Agent** | `69185783b5c3dcdcfe7775b7` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 7 | **Redis Agent** | `68f11fa7b2c5addcf03399bf` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 8 | **Test Strategy Intelligence Agent** | `6960f5db8d0e3377b25984af` | ✅ COMPLETED | workspace | single-agent | cloudzcp-admin |\n| 9 | **User Management Agent** | `692911c9abbc50a936371ed8` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 10 | **Web Search Agent** | `68f117a0b2c5addcf03399b6` | DRAFT | workspace | single-agent | cloudzcp-admin |\n| 11 | **Biz Support Reporter** | `697b0aa23f586569a06dc7df` | DRAFT | standalone | single-agent | cloudzcp-admin |\n| 12 | **EnableX Platform 2026 Support Ticket** | `698003023f586569a06dc7ec` | DRAFT | standalone | single-agent | cloudzcp-admin |\n| 13 | **OPMATE Agent** | `69ba0a207220b9c7850a6198` | ✅ COMPLETED | standalone | single-agent | cloudzcp-admin |\n\n---\n\n### 📊 Summary\n- **Total Agents:** 13\n- **All agents** are of type: `single-agent`\n- **All agents** are created by: `cloudzcp-admin`\n- **Status Breakdown:**\n  - ✅ `COMPLETED`: 2 agents (**Test Strategy Intelligence Agent**, **OPMATE Agent**)\n  - 🟡 `DRAFT`: 11 agents\n- **Runtime Type Breakdown:**\n  - `workspace`: 10 agents\n  - `standalone`: 3 agents (**Biz Support Reporter**, **EnableX Platform 2026 Support Ticket**, **OPMATE Agent**)"}}

# event: content_block_delta
# data: {"event":"content_block_delta","delta":{"text":"008"}}
# ...
# ...
# event: content_block_delta
# data: {"event":"content_block_delta","delta":{"text":"d"}}

# event: content_block_stop
# data: {"event":"content_block_stop","content_block":{"stop_timestamp":"2026-03-22T19:13:30.426485","type_":"text","citations":[]}}

# event: message_stop
# data: {"event":"message_stop","message":{"thread_id":"adfasdfdfdf","type_":"message","role":"ai","content":[]}}

# ------------------------------------------------------------------------------


class EventStreamMessage(BaseModel):
    """A message in a stream."""

    thread_id: str = Field(..., description="Thread ID", min_length=1, max_length=255)
    type_: Literal["message"] = Field(default="message", alias="type")
    role: ChatRole | None = Field(default=ChatRole.AI)
    model: str | None = Field(default=None)
    parent_uuid: str | None = Field(default=None)
    uuid: str | None = Field(default=None)
    content: List[str] = Field(default_factory=list)
    stop_reason: str | None = Field(default=None)
    stop_sequence: str | None = Field(default=None)


class EventStreamContentBlock(BaseModel):
    """A content block, which has a type and a content."""

    start_timestamp: datetime | None = Field(default=None)
    stop_timestamp: datetime | None = Field(default=None)
    type_: Literal["text", "image", "file"] = Field(default="text", alias="type")
    text: str | None = Field(default=None)
    citations: List[Citation] = Field(default_factory=list)


# for task tool the langchain deepagent
# ------------------------------------------------------------------------------
# {
#   "tool_call_id": "toolu_01VuxSqoLrdcjgyHL4Xfgp3s",
#   "tool_name": "task",
#   "args": {"description": "c694\n", "subagent_type": "NotionAgent"},
#   "agent_name": "MainAgent",
#   "ns_id": "ns_mainagent"
# }
class TaskArgs(BaseModel):
    """Arguments for the task tool."""

    description: str | None = Field(default=None)
    subagent_type: str | None = Field(default=None)


# for write_todos tool of the langchain deepagent
# ------------------------------------------------------------------------------
# {
#   "tool_call_id": "toolu_014N44P67PXaTan5Y2V3u9vQ",
#   "tool_name": "write_todos",
#   "args": {
#       "todos": [
#           {"content": "StudioAgent\ub85c Agent \ubaa9\ub85d \uc870\ud68c (get_agents_simple)", "status": "completed"},
#           {"content": "\ub9c8\uc9c0\ub9c9 Agent\uc758 \uc0c1\uc138 \ud504\ub85c\ud544 \uc870\ud68c (get_agent_profile_by_id) - OPMATE Agent", "status": "in_progress"},
#           {"content": "Markdown \ud30c\uc77c \uc0dd\uc131 (studio-agent-profiles.md)", "status": "pending"},
#           {"content": "NotionAgent\ub85c Notion \ud398\uc774\uc9c0 \uc0dd\uc131", "status": "pending"},
#           {"content": "studio-agent-profiles.md \ud30c\uc77c \uc0ad\uc81c", "status": "pending"}
#       ]
#   },
#   "agent_name": "MainAgent",
#   "ns_id": "ns_mainagent"
# }
class Todo(BaseModel):
    """A todo item."""

    content: str | None = Field(default=None)
    status: str | None = Field(default=None)


class WriteTodosArgs(BaseModel):
    """Arguments for the write_todos tool."""

    todos: List[Todo] | None = Field(default=None)


# for read_file tool of the langchain deepagent
# -------------------------------------------------------------------------------
# {
#   "tool_call_id": "toolu_012XT96U2D5MACabNqiBvjve",
#   "tool_name": "read_file",
#   "args": {"file_path": "/skills/mainagent/studio-agent-profiles/SKILL.md"},
#   "agent_name": "MainAgent",
#   "ns_id": "ns_mainagent"
# }
class ReadFileArgs(BaseModel):
    """Arguments for the read_file tool."""

    file_path: str | None = Field(default=None)


class ToolCall(BaseModel):
    """A tool call."""

    ns_id: str | None = Field(default=None)
    agent_name: str | None = Field(default=None)
    tool_call_id: str | None = Field(default=None)
    tool_name: str | None = Field(default=None)
    tool_args: str | dict | TaskArgs | WriteTodosArgs | ReadFileArgs | None = Field(
        default=None
    )
    """all tool_args are dict from the langchain deepagent
    TasgArgs, WriteTodosArgs, ReadFileArgs are just for type hinting and frontend API Guide
    """


class ToolCallResult(BaseModel):
    """A delta for a tool call content block."""

    tool_call_id: str | None = Field(default=None)
    content: str | dict | None = Field(default=None)
    status: str | None = Field(default=None)


# {
# "ns_id": "ns_subagent_b50018a4-cea1-61bd-0ec5-25830579ced7",
# "agent_name": "NotionAgent",
# "content": "\uc0dd\uc131\ud558\uaca0\uc2b5\ub2c8\ub2e4."
# }
class ProcessingMessage(BaseModel):
    """A delta for a process message content block."""

    ns_id: str | None = Field(default=None)
    agent_name: str | None = Field(default=None)
    content: str | None = Field(default=None)


class AIMessageDelta(BaseModel):
    """A delta for a text content block."""

    text: str | None = Field(default=None)


class EventStreamInterrupt(BaseModel):
    """A delta for an interrupt content block."""

    ns_id: str | None = Field(default=None)
    interrupts: List[dict[str, Any]] | None = Field(default=None)


EventStreamData = ToolCall | ToolCallResult | ProcessingMessage | EventStreamInterrupt


class ChatStreamResponse(BaseModel):
    """A response for a chat stream, which has a type, index, delta, content_block, and message."""

    event: EventStreamDataType
    delta: AIMessageDelta | None = Field(default=None)
    data: EventStreamData | None = Field(default=None)
    content_block: EventStreamContentBlock | None = Field(
        default=None
    )  # for type is (content_block_start, content_block_stop)
    message: EventStreamMessage | None = Field(
        default=None
    )  # for type is (message_start, message_stop)
