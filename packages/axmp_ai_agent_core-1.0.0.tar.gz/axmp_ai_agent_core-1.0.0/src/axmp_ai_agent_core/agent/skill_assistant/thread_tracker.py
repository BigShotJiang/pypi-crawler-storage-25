"""Thread tracker for Skill Assistant with InMemorySaver cleanup integration."""

import logging
import time
from collections.abc import Callable

from langgraph.checkpoint.memory import InMemorySaver

from axmp_ai_agent_core.agent.util.agent_cache import TTLQueue, TTLQueueConfig

logger = logging.getLogger(__name__)


class _CallbackTTLQueue(TTLQueue):
    """TTLQueue extension that invokes a callback when items are removed.

    The callback is invoked inside the lock for eviction, cleanup, and delete.
    Ensure the callback completes quickly to avoid blocking.

    NOTE: _evict_oldest and _cleanup_expired_items duplicate parent logic
    to inject the callback before deletion. Keep in sync with TTLQueue.
    """

    def __init__(
        self,
        config: TTLQueueConfig,
        on_remove: Callable[[str], None],
    ):
        """Initialize with a removal callback.

        Args:
            config: TTL queue configuration.
            on_remove: called with the item key when an item is removed.
                Invoked inside the lock — must be fast and synchronous.
        """
        self._on_remove = on_remove
        super().__init__(config)

    def _evict_oldest(self) -> None:
        """Evict the oldest item, calling the removal callback first."""
        if not self._items:
            return

        oldest_key = min(self._items.keys(), key=lambda k: self._items[k].expire_at)
        self._on_remove(oldest_key)
        del self._items[oldest_key]
        self.logger.debug("Evicted oldest item: %s", oldest_key)

        if self._stats is not None:
            self._stats["evictions"] += 1

    def _cleanup_expired_items(self) -> None:
        """Clean up expired items, calling the removal callback for each."""
        with self._lock:
            current_time = time.time()
            expired_keys = [
                key
                for key, item in self._items.items()
                if current_time > item.expire_at
            ]

            for key in expired_keys:
                self._on_remove(key)
                del self._items[key]

            if expired_keys and self._stats is not None:
                self._stats["cleanup_removals"] += len(expired_keys)

            if expired_keys:
                self.logger.debug("Cleaned up %d expired items", len(expired_keys))

    def delete(self, id: str) -> bool:
        """Delete an item, calling the removal callback on success."""
        if not isinstance(id, str):
            raise ValueError("ID must be a string")

        with self._lock:
            if id in self._items:
                self._on_remove(id)
                del self._items[id]
                if self._stats is not None:
                    self._stats["deletes"] += 1
                return True
        return False


class SkillAssistantThreadTracker:
    """Track Skill Assistant threads with TTL and InMemorySaver cleanup.

    Thread 메타데이터 구조:
        {
            "username": str,
            "turns": int,              # 대화 횟수 (max_turns 검사용)
            "last_instruction": str|None  # 마지막으로 Agent에 전달한 instruction
        }

    last_instruction을 메타데이터에 포함하는 이유:
        - current_instruction(최대 100KB)이 매 요청마다 user message에 포함되면
          InMemorySaver 히스토리에 누적되어 토큰이 폭발한다.
        - 변경됐을 때만 메시지에 포함하기 위해 "마지막으로 보낸 값"을 추적한다.
        - 별도 dict로 관리하면 TTL 만료/eviction 시 정리되지 않아 메모리 누수가 발생한다.
        - 메타데이터에 포함하면 thread와 동일한 수명으로 자동 정리된다.

    When a thread is removed (TTL expiry, eviction, or explicit delete),
    the corresponding InMemorySaver thread is also deleted.

    Note: The on_remove callback runs inside the TTLQueue lock.
    InMemorySaver.delete_thread() is synchronous and operates on an in-memory
    dict, so this is fast. If InMemorySaver is replaced with a DB-backed
    implementation, the callback should be changed to async.
    """

    def __init__(
        self,
        *,
        config: TTLQueueConfig,
        memory_saver: InMemorySaver,
    ):
        """Initialize the thread tracker.

        Args:
            config: TTL queue configuration for thread management.
            memory_saver: LangGraph InMemorySaver to clean up on thread removal.
        """
        self._memory_saver = memory_saver
        self._tracker = _CallbackTTLQueue(
            config=config,
            on_remove=self._on_thread_removed,
        )

    def _on_thread_removed(self, thread_id: str) -> None:
        """Clean up InMemorySaver when a thread is removed."""
        try:
            self._memory_saver.delete_thread(thread_id)
            logger.debug("Deleted InMemorySaver thread: thread_id=%s", thread_id)
        except Exception:
            logger.warning(
                f"Failed to delete InMemorySaver thread: thread_id={thread_id}",
                exc_info=True,
            )

    def put(self, thread_id: str, value: dict, ttl: int | None = None) -> None:
        """Register a thread.

        value should include: username, turns (0), last_instruction (None).
        """
        self._tracker.put(thread_id, value, ttl)

    def get(self, thread_id: str) -> dict | None:
        """Look up a thread and refresh its TTL."""
        return self._tracker.get(thread_id)

    def delete(self, thread_id: str) -> bool:
        """Delete a thread and its InMemorySaver data."""
        return self._tracker.delete(thread_id)

    def update_metadata(self, thread_id: str, key: str, value: object) -> bool:
        """Update a single metadata field atomically.

        Lock을 잡고 수행하여 동시 요청 시 race condition을 방지한다.

        Returns False if the thread does not exist or is expired.
        """
        with self._tracker._lock:
            item = self._tracker._items.get(thread_id)
            if item and not item.is_expired():
                item.value[key] = value
                return True
        return False

    def increment_turns(self, thread_id: str) -> int:
        """Increment the turns counter atomically and return the new value.

        Lock을 잡고 수행하여 동시 요청 시 race condition을 방지한다.

        Returns 0 if the thread does not exist.
        """
        with self._tracker._lock:
            item = self._tracker._items.get(thread_id)
            if item and not item.is_expired():
                item.value["turns"] = item.value.get("turns", 0) + 1
                item.reset_ttl(self._tracker.config.default_ttl)
                return item.value["turns"]
        return 0

    def stop(self) -> None:
        """Stop the cleanup thread."""
        self._tracker.stop()
