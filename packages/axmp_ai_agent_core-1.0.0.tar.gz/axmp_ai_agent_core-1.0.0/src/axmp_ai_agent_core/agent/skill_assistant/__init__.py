"""Skill Assistant agent for AI-powered SKILL.md generation."""
