"""Tool definitions for Skill Assistant agent."""

from langchain_core.tools import tool


@tool
def show_diff(changes: str) -> str:
    """Show proposed changes in a human-readable diff summary.

    changes is a + / - style change summary text.
    Not a precise unified diff, but a summary easy for humans to read.
    The frontend renders this text as a diff block.

    Example:
      + ### Error Handling (newly added)
      + - Alert ID lookup failure → request ID re-check
      - Removed existing content
    """
    return changes


@tool
def apply_instruction(full_instruction: str) -> str:
    """Apply the full SKILL.md body text to the editor.

    full_instruction is the complete SKILL.md body text, not just the changed parts.
    The frontend replaces the editor content with this text.

    Rules:
    1. On initial generation (Flow 1): call directly without show_diff
    2. On improvement (conversation): show changes via show_diff first,
       then call only after user confirms
    """
    return "applied"


SKILL_ASSISTANT_TOOLS = [show_diff, apply_instruction]
