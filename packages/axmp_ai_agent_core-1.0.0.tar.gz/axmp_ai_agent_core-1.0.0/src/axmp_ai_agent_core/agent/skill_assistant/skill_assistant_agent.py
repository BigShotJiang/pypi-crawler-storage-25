"""Skill Assistant agent definition."""

import logging

from langchain.agents import create_agent
from langchain_core.language_models import BaseChatModel
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph.state import CompiledStateGraph

from axmp_ai_agent_core.agent.skill_assistant.skill_assistant_tools import (
    SKILL_ASSISTANT_TOOLS,
)

logger = logging.getLogger(__name__)


def create_skill_assistant_agent(
    *,
    llm: BaseChatModel,
    checkpointer: InMemorySaver,
    system_prompt: str,
) -> CompiledStateGraph:
    """Create the Skill Assistant agent.

    Args:
        llm: pre-configured LLM instance.
        checkpointer: InMemorySaver for conversation history per thread.
        system_prompt: 시스템 프롬프트 (skill-assistant.md, 앱 기동 시 1회 로드).
    """
    agent = create_agent(
        model=llm,
        tools=SKILL_ASSISTANT_TOOLS,
        checkpointer=checkpointer,
        system_prompt=system_prompt,
        name="SkillAssistantAgent",
    )

    logger.info("Skill Assistant agent created")
    return agent
