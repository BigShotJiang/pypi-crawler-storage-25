"""SSE generator for agent events."""

import logging
import time
from collections.abc import Awaitable, Callable
from datetime import UTC, datetime
from typing import AsyncGenerator

from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    ToolMessage,
)
from langgraph.graph.state import CompiledStateGraph
from langgraph.types import Command
from sse_starlette.sse import ServerSentEvent

from axmp_ai_agent_core.agent.model.chat_messages import (
    AIMessageDelta,
    ChatRole,
    ChatStreamResponse,
    EventStreamContentBlock,
    EventStreamDataType,
    EventStreamInterrupt,
    EventStreamMessage,
    ProcessingMessage,
    ToolCall,
    ToolCallResult,
)

logger = logging.getLogger(__name__)


async def stream_error_events(
    *,
    thread_id: str,
    error_message: str,
) -> AsyncGenerator[ServerSentEvent, None]:
    """Stream an error as a complete SSE event sequence.

    Yield a minimal but valid SSE lifecycle (message_start → content_block_start →
    content_block_delta → content_block_stop → message_stop) so that the frontend
    chat UI can render the error inside a normal chat bubble instead of receiving
    an HTTP error response that the SSE client cannot display.

    Args:
        thread_id: The conversation thread ID.
        error_message: The human-readable error text to display in the chat bubble.

    Returns:
        An async generator of SSE events.
    """
    # message_start
    yield _sse_processing(
        response=ChatStreamResponse(
            event=EventStreamDataType.MESSAGE_START,
            message=EventStreamMessage(
                thread_id=thread_id,
                type="message",
                role=ChatRole.AI,
                model="",
                content=[],
            ),
        ),
    )

    # content_block_start
    yield _sse_processing(
        response=ChatStreamResponse(
            event=EventStreamDataType.CONTENT_BLOCK_START,
            content_block=EventStreamContentBlock(
                start_timestamp=datetime.now(UTC),
                type="text",
                citations=[],
            ),
        ),
    )

    # content_block_delta with error message
    yield _sse_processing(
        response=ChatStreamResponse(
            event=EventStreamDataType.CONTENT_BLOCK_DELTA,
            delta=AIMessageDelta(
                text=error_message,
            ),
        ),
    )

    # content_block_stop
    yield _sse_processing(
        response=ChatStreamResponse(
            event=EventStreamDataType.CONTENT_BLOCK_STOP,
            content_block=EventStreamContentBlock(
                start_timestamp=None,
                stop_timestamp=datetime.now(UTC),
                text=None,
                citations=[],
            ),
        ),
    )

    # message_stop
    yield _sse_processing(
        response=ChatStreamResponse(
            event=EventStreamDataType.MESSAGE_STOP,
            message=EventStreamMessage(
                thread_id=thread_id,
                type="message",
                role=ChatRole.AI,
                stop_reason="error",
            ),
        ),
    )


def _sse_processing(
    response: ChatStreamResponse,
) -> ServerSentEvent:
    """Create an SSE event for processing."""
    return ServerSentEvent(
        event=response.event,
        data=response.model_dump_json(exclude_none=True),
    )


async def stream_agent_events(
    agent: CompiledStateGraph,
    thread_id: str,
    inputs: dict | Command,
    config: dict,
    llm_model: str | None = None,
    stream_mode: list[str] | None = None,
    subgraphs: bool = True,
    cancel_check: Callable[[], Awaitable[bool]] | None = None,
) -> AsyncGenerator[ServerSentEvent, None]:
    """Stream agent events as SSE.

    Args:
        agent: The compiled state graph.
        thread_id: The thread ID.
        llm_model: The LLM model name. This is used only for the model name in the SSE events.
        inputs: The inputs to the agent.
        config: The configuration for the agent.
        stream_mode: The stream mode.
        subgraphs: Whether to stream subgraphs.

    Returns:
        An async generator of SSE events.
    """
    if stream_mode is None:
        stream_mode = ["updates", "messages"]

    # message_start
    yield _sse_processing(
        response=ChatStreamResponse(
            event=EventStreamDataType.MESSAGE_START,
            message=EventStreamMessage(
                thread_id=thread_id,
                type="message",
                role=ChatRole.AI,
                model="",
                parent_uuid=None,
                uuid=None,
                content=[],
                stop_reason=None,
                stop_sequence=None,
            ),
        ),
    )

    # block_start
    yield _sse_processing(
        response=ChatStreamResponse(
            event=EventStreamDataType.CONTENT_BLOCK_START,
            content_block=EventStreamContentBlock(
                start_timestamp=datetime.now(UTC),
                type="text",
                citations=[],
            ),
        ),
    )

    cancelled = False
    last_cancel_check = time.monotonic()

    try:
        async for _chunk in agent.astream(
            inputs,
            config=config,
            stream_mode=stream_mode,
            subgraphs=subgraphs,
            version="v2",
        ):
            # Check for cancellation every 1 second
            if cancel_check and time.monotonic() - last_cancel_check > 1.0:
                if await cancel_check():
                    logger.info("Cancellation detected for thread: %s", thread_id)
                    cancelled = True
                    break
                last_cancel_check = time.monotonic()

            _ns = _chunk["ns"]
            _stream_mode = _chunk["type"]  # for backward compatibility
            _data = _chunk["data"]

            is_subagent = any(s.startswith("tools:") for s in _ns)
            ns_id = None
            if is_subagent:
                # Extract the tool call ID from the namespace
                subagent_task_id = next(
                    s.split(":")[1] for s in _ns if s.startswith("tools:")
                )
                ns_id = "ns_subagent_" + subagent_task_id
            else:
                ns_id = "ns_mainagent"

            if _stream_mode == "updates":
                # NOTE : process for interrupts on the main only
                if not is_subagent and "__interrupt__" in _data:
                    interrupt_tuple = _data["__interrupt__"]
                    interrupts = []
                    for interrupt in interrupt_tuple:
                        interrupts.append(
                            {
                                "id": interrupt.id,
                                "action_requests": interrupt.value.get(
                                    "action_requests", []
                                ),
                                "review_configs": interrupt.value.get(
                                    "review_configs", []
                                ),
                            }
                        )
                    logger.debug(f">>> [Event:Interrupts] [NS: {ns_id}] {interrupts}")
                    # yield interrupts
                    yield _sse_processing(
                        response=ChatStreamResponse(
                            event=EventStreamDataType.INTERRUPT,
                            data=EventStreamInterrupt(
                                interrupts=interrupts, ns_id=ns_id
                            ),
                        )
                    )

                for _node_name, _node_data in _data.items():
                    # 1st. model node
                    if _node_name == "model":
                        messages = _node_data.get("messages", None)
                        if messages:
                            last_message = messages[-1]
                            if isinstance(last_message, AIMessage):
                                agent_name = last_message.name

                                # NOTE: yield only subagent messages
                                if is_subagent and last_message.content:
                                    if isinstance(last_message.content, str):
                                        logger.debug(
                                            f">>> [Event:Model] [NS: {ns_id}] [Agent: {agent_name}]\n\t{last_message.content[:100]}..."
                                        )
                                    elif isinstance(last_message.content, list):
                                        for _ctnt in last_message.content:
                                            if isinstance(_ctnt, str):
                                                logger.debug(
                                                    f">>> [Event:Model] [NS: {ns_id}] [Agent: {agent_name}]\n\t{_ctnt[:100]}..."
                                                )
                                                # yield ai message text
                                                yield _sse_processing(
                                                    response=ChatStreamResponse(
                                                        event=EventStreamDataType.PROCESSING_MESSAGE,
                                                        data=ProcessingMessage(
                                                            ns_id=ns_id,
                                                            agent_name=agent_name,
                                                            content=_ctnt,
                                                        ),
                                                    )
                                                )
                                            elif isinstance(_ctnt, dict):
                                                if _ctnt.get("type") == "text":
                                                    logger.debug(
                                                        f">>> [Event:Model] [NS: {ns_id}] [Agent: {agent_name}]\n\t{_ctnt.get('text', '')[:100]}..."
                                                    )
                                                    # yield ai message text
                                                    yield _sse_processing(
                                                        response=ChatStreamResponse(
                                                            event=EventStreamDataType.PROCESSING_MESSAGE,
                                                            data=ProcessingMessage(
                                                                ns_id=ns_id,
                                                                agent_name=agent_name,
                                                                content=_ctnt.get(
                                                                    "text", ""
                                                                ),
                                                            ),
                                                        )
                                                    )
                                                else:
                                                    # NOTE: ignore for dict type now
                                                    pass

                                # NOTE: yield tool calls of all models(main and subagents)
                                if last_message.tool_calls:
                                    for tool_call in last_message.tool_calls:
                                        tc_id = tool_call.get("id", "")
                                        tc_name = tool_call.get("name", "")
                                        tc_args = tool_call.get("args", {})

                                        logger.debug(
                                            f">>> [Event:ToolCall] [NS: {ns_id}] [Agent: {agent_name}]\n\tID: {tc_id}\n\tName: {tc_name}\n\tArgs: {tc_args}"
                                        )
                                        # yield tool call
                                        yield _sse_processing(
                                            response=ChatStreamResponse(
                                                event=EventStreamDataType.TOOL_CALL,
                                                data=ToolCall(
                                                    ns_id=ns_id,
                                                    agent_name=agent_name,
                                                    tool_call_id=tc_id,
                                                    tool_name=tc_name,
                                                    tool_args=tc_args,
                                                ),
                                            )
                                        )

                    # 2nd. yield tool call results
                    # NOTE: trigger cases
                    # -----------------------------------------------------------
                    # 1. main agent tool
                    # 2. a task tool for the subagent execution
                    # 3. subagent tool
                    # -----------------------------------------------------------
                    elif _node_name == "tools":
                        # NOTE : tool call results of all models(main and subagents)
                        messages = _node_data.get("messages", None)
                        if messages:
                            last_message = messages[-1]
                            if isinstance(last_message, ToolMessage):
                                tc_id = last_message.tool_call_id
                                content = None
                                # 1st. use the ToolMessage.artifact["structured_content"]
                                # 2nd. if artifact is not exist, use the ToolMessage.content
                                if (
                                    last_message.artifact
                                    and isinstance(last_message.artifact, dict)
                                    and "structured_content" in last_message.artifact
                                ):
                                    content = last_message.artifact[
                                        "structured_content"
                                    ]
                                else:
                                    content = (
                                        last_message.content
                                        if isinstance(last_message.content, str)
                                        else str(last_message.content)
                                    )
                                status = last_message.status

                                logger.debug(
                                    f">>> [Event: ToolCallResult] [NS: {ns_id}]\n\tID: {tc_id}\n\tStatus: {status}\n\tContent: {type(content)} ..."
                                )
                                # yield tool call result
                                yield _sse_processing(
                                    response=ChatStreamResponse(
                                        event=EventStreamDataType.TOOL_CALL_RESULT,
                                        data=ToolCallResult(
                                            tool_call_id=tc_id,
                                            status=status,
                                            content=content,
                                        ),
                                    )
                                )

            elif _stream_mode == "messages":
                # NOTE : process for messages only AI Message Chunk
                _chk, _metadata = _data
                # NOTE : yield only main agent
                if not is_subagent:
                    if isinstance(_chk, AIMessageChunk):
                        if _chk.content:
                            if isinstance(_chk.content, str):
                                # yield ai message text
                                yield _sse_processing(
                                    response=ChatStreamResponse(
                                        event=EventStreamDataType.CONTENT_BLOCK_DELTA,
                                        delta=AIMessageDelta(
                                            text=_chk.content,
                                        ),
                                    )
                                )
                            elif isinstance(_chk.content, list):
                                for _cnt in _chk.content:
                                    if isinstance(_cnt, dict):
                                        if _cnt.get("type") == "text":
                                            # yield ai message text
                                            yield _sse_processing(
                                                response=ChatStreamResponse(
                                                    event=EventStreamDataType.CONTENT_BLOCK_DELTA,
                                                    delta=AIMessageDelta(
                                                        text=_cnt["text"],
                                                    ),
                                                )
                                            )
                                        else:
                                            ...  # ignore other types e.g.) tool_use

        if cancelled:
            # Notify client that the conversation was cancelled
            yield _sse_processing(
                response=ChatStreamResponse(
                    event=EventStreamDataType.CONTENT_BLOCK_DELTA,
                    delta=AIMessageDelta(
                        text="\n\n[Conversation cancelled]",
                    ),
                )
            )

        # block_stop
        yield _sse_processing(
            response=ChatStreamResponse(
                event=EventStreamDataType.CONTENT_BLOCK_STOP,
                content_block=EventStreamContentBlock(
                    start_timestamp=None,
                    stop_timestamp=datetime.now(UTC),
                    text=None,
                    citations=[],
                ),
            ),
        )

        # message_stop
        yield _sse_processing(
            response=ChatStreamResponse(
                event=EventStreamDataType.MESSAGE_STOP,
                message=EventStreamMessage(
                    thread_id=thread_id,
                    type="message",
                    role=ChatRole.AI,
                    stop_reason="cancelled" if cancelled else None,
                ),
            ),
        )

    except Exception as e:
        logger.error("Stream error: %s", e, exc_info=True)

        # block_delta for the error
        error_description = str(e) if str(e) else type(e).__name__
        yield _sse_processing(
            response=ChatStreamResponse(
                event=EventStreamDataType.CONTENT_BLOCK_DELTA,
                delta=AIMessageDelta(
                    text=f"\n\nSorry, something went wrong while processing your request. Please try again later.\n\nError details: {error_description}",
                ),
            )
        )

        # block_stop
        yield _sse_processing(
            response=ChatStreamResponse(
                event=EventStreamDataType.CONTENT_BLOCK_STOP,
                content_block=EventStreamContentBlock(
                    start_timestamp=None,
                    stop_timestamp=datetime.now(UTC),
                    text=None,
                    citations=[],
                ),
            ),
        )

        # message_stop
        yield _sse_processing(
            response=ChatStreamResponse(
                event=EventStreamDataType.MESSAGE_STOP,
                message=EventStreamMessage(
                    thread_id=thread_id, type="message", role=ChatRole.AI
                ),
            ),
        )
