"""Agent cache key format."""

AGENT_CACHE_KEY_FORMAT = "agent-{agent_id}"
"""Agent cache key format."""

AGENT_WRAPPER_CACHE_KEY_FORMAT = "agent-wrapper-{agent_id}"
"""Agent wrapper cache key format."""

PLAYGROUND_AGENT_CACHE_KEY_FORMAT = "agent-{profile_id}-{username}"
"""Playground agent cache key format."""

MCP_PLAYGROUND_AGENT_CACHE_KEY_FORMAT = "mcp-{profile_id}-{username}"
"""MCP playground agent cache key format."""

MCP_REGISTRY_PLAYGROUND_AGENT_CACHE_KEY_FORMAT = "registry-{registry_id}-{username}"
"""MCP registry playground agent cache key format."""

MCP_INSTANCE_PLAYGROUND_AGENT_CACHE_KEY_FORMAT = "mcp-instance-{profile_id}-{username}"
"""MCP server instance playground agent cache key format."""


def agent_cache_key(agent_id: str) -> str:
    """Format the agent cache key."""
    return AGENT_CACHE_KEY_FORMAT.format(agent_id=agent_id)


def agent_wrapper_cache_key(agent_id: str) -> str:
    """Format the agent wrapper cache key."""
    return AGENT_WRAPPER_CACHE_KEY_FORMAT.format(agent_id=agent_id)


def agent_playground_agent_cache_key(profile_id: str, username: str) -> str:
    """Format the playground agent cache key."""
    return PLAYGROUND_AGENT_CACHE_KEY_FORMAT.format(
        profile_id=profile_id, username=username
    )


def mcp_playground_agent_cache_key(profile_id: str, username: str) -> str:
    """Format the MCP playground agent cache key."""
    return MCP_PLAYGROUND_AGENT_CACHE_KEY_FORMAT.format(
        profile_id=profile_id, username=username
    )


def mcp_registry_playground_agent_cache_key(registry_id: str, username: str) -> str:
    """Format the MCP registry playground agent cache key."""
    return MCP_REGISTRY_PLAYGROUND_AGENT_CACHE_KEY_FORMAT.format(
        registry_id=registry_id, username=username
    )


def mcp_server_instance_playground_agent_cache_key(
    profile_id: str, username: str
) -> str:
    """Format the MCP server instance playground agent cache key."""
    return MCP_INSTANCE_PLAYGROUND_AGENT_CACHE_KEY_FORMAT.format(
        profile_id=profile_id, username=username
    )
