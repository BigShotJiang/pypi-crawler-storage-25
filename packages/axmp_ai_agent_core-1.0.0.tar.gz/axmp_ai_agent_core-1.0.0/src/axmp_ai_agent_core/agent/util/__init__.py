"""Agent utility modules for caching, model loading, and MCP client management."""
