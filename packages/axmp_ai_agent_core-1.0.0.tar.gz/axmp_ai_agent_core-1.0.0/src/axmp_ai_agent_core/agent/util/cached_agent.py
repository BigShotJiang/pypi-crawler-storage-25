"""Cached agent model for in-process agent cache."""

from __future__ import annotations

from dataclasses import dataclass, field

from langgraph.graph.state import CompiledStateGraph

from axmp_ai_agent_core.agent.mcp.auth.models import MCPServerConfig


@dataclass
class CachedAgent:
    """Cached agent graph bundled with MCP server configs for auth validation.

    Store MCP server configs alongside the compiled graph so that
    ``validate_agent_initialized`` can perform a lightweight Redis-based
    token check on cache hits without needing the full wrapper object.
    """

    graph: CompiledStateGraph
    mcp_server_configs: list[MCPServerConfig] = field(default_factory=list)
