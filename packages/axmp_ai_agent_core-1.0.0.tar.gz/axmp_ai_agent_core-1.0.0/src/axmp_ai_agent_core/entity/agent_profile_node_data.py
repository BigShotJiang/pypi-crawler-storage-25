"""Agent Profile Node Data entities for ReactFlow UI."""

from __future__ import annotations

from typing import Any, Literal

from axmp_openapi_helper import (
    AuthConfig,
)
from croniter import croniter
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from axmp_ai_agent_core.agent.spec.profile_node_data import (
    DecisionType,
    PIIMiddlewareSpec,
)
from axmp_ai_agent_core.agent.spec.types import (
    AgentMemoryType,
    MCPServerType,
    TransportType,
    TriggerType,
)


class ChatbotTriggerNodeData(BaseModel):
    """Chatbot Trigger Node Data entity."""

    data_type: Literal["chatbot-trigger"] = "chatbot-trigger"
    trigger_type: TriggerType = Field(
        default=TriggerType.CHATBOT,
        description="The type of the trigger node.",
    )
    init_message: str | None = Field(
        None,
        description="The init message of the trigger node.",
        min_length=1,
        max_length=2000,
    )

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )


class WebhookTriggerNodeData(BaseModel):
    """Webhook Trigger Node Data entity."""

    data_type: Literal["webhook-trigger"] = "webhook-trigger"
    trigger_type: TriggerType = Field(
        default=TriggerType.WEBHOOK,
        description="The type of the trigger node.",
    )

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )


class SchedulerTriggerNodeData(BaseModel):
    """Scheduler Trigger Node Data entity."""

    data_type: Literal["scheduler-trigger"] = "scheduler-trigger"
    trigger_type: TriggerType = Field(
        default=TriggerType.SCHEDULER,
        description="The type of the trigger node.",
    )
    cron_expression: str = Field(
        ...,
        description="The cron expression of the trigger node.",
        min_length=1,
        max_length=255,
    )
    timezone: str | None = Field(
        None,
        description="The timezone of the trigger node.",
        min_length=1,
        max_length=255,
    )

    @field_validator("cron_expression")
    @classmethod
    def validate_cron_expression(cls, value: str) -> str:
        """Validate that the cron expression is valid using croniter."""
        try:
            croniter(value)
        except (ValueError, TypeError) as e:
            raise ValueError(f"Invalid cron expression: {value}") from e
        return value

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )


class InterruptOnConfig(BaseModel):
    """Interrupt On Config entity."""

    allowed_decisions: list[DecisionType] = Field(
        ["approve", "reject", "edit"],
        description="The allowed decisions of the interrupt on config.",
    )


class HumanInTheLoopMiddlewareConfig(BaseModel):
    """Human In The Loop Middleware Config entity."""

    enabled: bool = Field(
        False,
        description="Whether the human in the loop middleware is enabled.",
    )
    interrupt_configs: dict[str, dict[str, InterruptOnConfig]] = Field(
        ...,
        description="The interrupt configs of the human in the loop middleware.",
    )
    """
    {
        "mcp_swerver_id": {
            "tool_1": {
                "allowed_decisions": ["approve", "reject", "edit"],
            },
            "tool_2": {
                "allowed_decisions": ["approve", "reject", "edit"],
            },
        },
        "mcp_swerver_id_2": {
            "tool_1": {
                "allowed_decisions": ["approve", "reject", "edit"],
            },
        },
    }
    """


class PIIMiddlewareConfig(BaseModel):
    """PII Middleware Config entity."""

    enabled: bool = Field(
        False,
        description="Whether the pii detection middleware is enabled.",
    )
    pii_middlewares: list[PIIMiddlewareSpec] = Field(
        ...,
        description="The pii middlewares of the pii detection middleware.",
    )


SummarizationType = Literal["tokens", "messages", "fraction"]


class SummarizationMiddlewareConfig(BaseModel):
    """Summarization Middleware Config entity."""

    enabled: bool = Field(
        False,
        description="Whether the summarization middleware is enabled.",
    )

    provider_id: str = Field(
        "",
        description="The provider of the summarization middleware.",
        max_length=255,
    )
    model_id: str = Field(
        "",
        description="The model of the summarization middleware.",
        max_length=255,
    )
    api_key_owner_username: str = Field(
        "",
        description="The username of the API key owner of the LLM provider.",
        max_length=255,
    )
    api_key_credential_id: str = Field(
        "",
        description="The API key credential id of the LLM provider.",
        max_length=255,
    )
    max_input_tokens: int = Field(
        128_000,
        description="The maximum input tokens (context window) of the model. Required for fractional token limits.",
    )
    triggers: dict[SummarizationType, int | float] | None = Field(
        None,
        description="The triggers of the summarization middleware.",
    )
    keep: dict[SummarizationType, int | float] | None = Field(
        None,
        description="The keep of the summarization middleware. Should be one of tokens, messages, fraction.",
    )

    @model_validator(mode="after")
    def validate_enabled_fields(self) -> SummarizationMiddlewareConfig:
        """Validate that required fields are non-empty when enabled."""
        if self.enabled:
            required_fields = [
                "provider_id",
                "model_id",
                "api_key_owner_username",
                "api_key_credential_id",
            ]
            for field_name in required_fields:
                if not getattr(self, field_name):
                    raise ValueError(
                        f"{field_name} is required when summarization is enabled"
                    )
        return self


class AgentNodeData(BaseModel):
    """Agent Node Data entity."""

    data_type: Literal["agent"] = "agent"
    name: str = Field(
        ...,
        description="The name of the agent node.",
        min_length=1,
        max_length=255,
        # pattern=r"^[a-zA-Z0-9 _-]+$",
    )
    system_prompt: str | None = Field(
        None,
        description="The system prompt of the agent node.",
        min_length=1,
        # NOTE: No max length for system prompt
        # max_length=2000,
    )
    hitl_middleware_config: HumanInTheLoopMiddlewareConfig | None = Field(
        None,
        description="The human in the loop middleware config of the agent node.",
    )
    pii_middleware_config: PIIMiddlewareConfig | None = Field(
        None,
        description="The pii middleware config of the agent node.",
    )
    summarization_middleware_config: SummarizationMiddlewareConfig | None = Field(
        None,
        description="The summarization middleware config of the agent node.",
    )
    description: str | None = Field(
        None,
        description="The description of the agent node.",
        min_length=1,
        max_length=9999,
    )

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )


class SubAgentNodeData(AgentNodeData):
    """Sub Agent Node Data entity."""

    data_type: Literal["sub-agent"] = "sub-agent"
    description: str | None = Field(
        None,
        description="The description of the sub agent node.",
        min_length=1,
        max_length=9999,
    )


class SkillNodeData(BaseModel):
    """Skill Node Data entity."""

    data_type: Literal["skill"] = "skill"
    skill_id: str = Field(
        ..., description="The skill id.", min_length=1, max_length=255
    )
    name: str = Field(..., description="Skill identifier.", min_length=1, max_length=64)
    icon_url: str | None = Field(
        None,
        description="The icon url of the skill node.",
        min_length=1,
        max_length=255,
    )
    version: int = Field(1, description="Current version number")

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )


class LLMNodeData(BaseModel):
    """LLM Node Data entity."""

    data_type: Literal["llm"] = "llm"
    provider_id: str = Field(
        ..., description="The provider of the LLM node.", min_length=1, max_length=255
    )
    provider_name: str | None = Field(
        None,
        description="The provider name of the LLM node.",
        min_length=1,
        max_length=255,
    )
    icon_url: str | None = Field(
        None,
        description="The icon url of the LLM node.",
        min_length=1,
        max_length=255,
    )
    default_model: str | None = Field(
        None,
        description="The default model of the LLM node.",
        min_length=1,
        max_length=255,
    )
    temperature: float = Field(
        0,
        description="The temperature of the LLM node.",
        ge=0,
        le=1,
    )
    max_tokens: int = Field(
        5000,
        description="The max tokens of the LLM node.",
        ge=5000,
        # NOTE: TBD max length for max tokens
        le=1000000,
    )
    api_key_owner_username: str = Field(
        ...,
        description="The username of the API key owner of the LLM provider.",
        min_length=1,
        max_length=255,
    )
    api_key_credential_id: str = Field(
        ...,
        description="The API key credential id of the LLM provider.",
        min_length=1,
        max_length=255,
    )
    max_retries: int = Field(
        2,
        description="The max retries of the LLM node.",
        ge=0,
        le=10,
    )
    request_timeout: int = Field(
        300,
        description="The request timeout of the LLM node.",
        ge=1,
        le=3600,
    )
    streaming: bool = Field(
        True,
        description="The streaming of the LLM node.",
    )
    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )


class MemoryNodeData(BaseModel):
    """Memory Node Data entity."""

    data_type: Literal["memory"] = "memory"
    memory_id: str = Field(
        ...,
        description="The chat memory id of the memory node.",
        min_length=1,
        max_length=255,
    )
    memory_name: str | None = Field(
        None,
        description="The memory name of the memory node.",
        min_length=1,
        max_length=255,
    )
    memory_type: AgentMemoryType = Field(
        ..., description="The type of the memory node."
    )
    icon_url: str | None = Field(
        None,
        description="The icon url of the memory node.",
        min_length=1,
        max_length=255,
    )
    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )


class McpServerConfigJson(BaseModel):
    """MCP Server config json."""

    mcpServers: dict[str, Any] = Field(default_factory=dict)


class McpServerBackendServerAuthConfig(BaseModel):
    """MCP Server Playground Backend Server Auth Config."""

    server_id: str = Field(..., description="Backend server ID")
    server_name: str = Field(..., description="Backend server name")
    server_system_name: str = Field(..., description="Backend server system name")
    auth_config: AuthConfig = Field(..., description="Backend server auth config")


class InternalMcpServerNodeData(BaseModel):
    """MCP Server entity.

    Only include the data for the right sidebar of the reactflow.
    """

    data_type: Literal["internal-mcp-server"] = "internal-mcp-server"
    resource_type: MCPServerType = MCPServerType.INTERNAL
    transport_type: TransportType | None = None
    registry_id: str = Field(
        ...,
        description="The server instance id of the MCP server node.",
        min_length=1,
        max_length=255,
    )
    name: str = Field(
        ...,
        description="The name of the MCP server node.",
        min_length=1,
        max_length=255,
    )
    icon_url: str | None = Field(
        None,
        description="The icon url of the MCP server node.",
        min_length=1,
        max_length=255,
    )
    auth_config: AuthConfig = Field(
        ..., description="The authentication config of the MCP server node."
    )
    backend_server_auth_configs: list[McpServerBackendServerAuthConfig] = Field(
        [], description="The authentication configs of the backend server nodes."
    )
    mcp_config_json: McpServerConfigJson | None = Field(
        None,
        description="The config of the internal MCP server node.",
    )

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )


class ExternalMcpServerNodeData(BaseModel):
    """External MCP Server entity.

    Only include the data for the right sidebar of the reactflow.
    """

    data_type: Literal["external-mcp-server"] = "external-mcp-server"
    resource_type: MCPServerType = MCPServerType.EXTERNAL
    transport_type: TransportType | None = None
    registry_id: str = Field(
        ...,
        description="The server id of the external MCP server node.",
        min_length=1,
        max_length=255,
    )
    name: str = Field(
        ...,
        description="The name of the external MCP server node.",
        min_length=1,
        max_length=255,
    )
    icon_url: str | None = Field(
        None,
        description="The icon url of the MCP server node.",
        min_length=1,
        max_length=255,
    )
    mcp_config_json: McpServerConfigJson | None = Field(
        None,
        description="The config of the external MCP server node.",
    )

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )
