"""OAuth user entity."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel


class AccessType(StrEnum):
    """Access type."""

    READ = "READ"
    WRITE = "WRITE"
    ALL = "ALL"


class SharedUser(BaseModel):
    """Shared user entity."""

    username: str
    email: str | None = None
    given_name: str | None = None
    family_name: str | None = None
    access_type: AccessType = AccessType.READ


class SharedGroup(BaseModel):
    """Shared group entity."""

    group_id: str
    group_name: str | None = None
    access_type: AccessType = AccessType.READ


class SharedType(StrEnum):
    """Shared type."""

    PRIVATE = "PRIVATE"
    PUBLIC = "PUBLIC"
    RESTRICTED = "RESTRICTED"


class SharedTarget(BaseModel):
    """Shared target entity."""

    shared_type: SharedType = SharedType.PRIVATE
    shared_users: list[SharedUser] | None = None
    shared_groups: list[SharedGroup] | None = None
