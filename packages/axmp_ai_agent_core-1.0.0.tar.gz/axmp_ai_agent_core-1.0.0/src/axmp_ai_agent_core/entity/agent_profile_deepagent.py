"""Reactflow Profile Entity. This entity is used to store the profile of the reactflow."""

from __future__ import annotations

from collections import Counter
from typing import Any

from pydantic import Field, model_validator

from axmp_ai_agent_core.agent.spec.profile_base import (
    SpecBaseEdge,
)
from axmp_ai_agent_core.agent.spec.profiles.deepagent_profile import (
    MAX_MCP_SERVER_NODES,
    MAX_MEMORY_NODES,
    MAX_SKILL_NODES,
    MAX_SUB_AGENT_NODES,
    MAX_TRIGGER_NODES,
)
from axmp_ai_agent_core.agent.spec.types import (
    NodeType,
)
from axmp_ai_agent_core.entity.agent_profile_node_data import (
    AgentNodeData,
    ChatbotTriggerNodeData,
    ExternalMcpServerNodeData,
    InternalMcpServerNodeData,
    LLMNodeData,
    MemoryNodeData,
    SchedulerTriggerNodeData,
    SkillNodeData,
    SubAgentNodeData,
    WebhookTriggerNodeData,
)
from axmp_ai_agent_core.entity.base_profile import (
    BaseFlow,
    BaseNode,
    BaseProfile,
)


class DeepAgentProfileNode(BaseNode):
    """Node Entity. This entity is used to store the node of the reactflow."""

    data: (
        ChatbotTriggerNodeData
        | WebhookTriggerNodeData
        | SchedulerTriggerNodeData
        | SubAgentNodeData
        | AgentNodeData
        | LLMNodeData
        | MemoryNodeData
        | InternalMcpServerNodeData
        | ExternalMcpServerNodeData
        | SkillNodeData
    ) = Field(..., description="The data of the node.", discriminator="data_type")

    @model_validator(mode="after")
    def validate_type(self) -> DeepAgentProfileNode:
        """Validate that the type of the node is valid."""
        if self.node_type not in [
            NodeType.TRIGGER,
            NodeType.AI_AGENT,
            NodeType.SUB_AGENT,
            NodeType.LLM,
            NodeType.MEMORY,
            NodeType.MCP_SERVER,
            NodeType.REMOTE_AGENT,
            NodeType.SKILL,
        ]:
            raise ValueError(f"Invalid node type: {self.node_type}")

        if self.node_type == NodeType.TRIGGER:
            if not isinstance(
                self.data,
                ChatbotTriggerNodeData
                | WebhookTriggerNodeData
                | SchedulerTriggerNodeData,
            ):
                raise ValueError(f"Invalid trigger node data: {self.data}")

        if self.node_type == NodeType.AI_AGENT:
            if not isinstance(self.data, AgentNodeData):
                raise ValueError(f"Invalid AI agent node data: {self.data}")

        if self.node_type == NodeType.SUB_AGENT:
            if not isinstance(self.data, SubAgentNodeData):
                raise ValueError(f"Invalid sub agent node data: {self.data}")

        if self.node_type == NodeType.LLM:
            if not isinstance(self.data, LLMNodeData):
                raise ValueError(f"Invalid LLM node data: {self.data}")

        if self.node_type == NodeType.MEMORY:
            if not isinstance(self.data, MemoryNodeData):
                raise ValueError(f"Invalid memory node data: {self.data}")

        if self.node_type == NodeType.MCP_SERVER:
            if not isinstance(
                self.data, InternalMcpServerNodeData | ExternalMcpServerNodeData
            ):
                raise ValueError(f"Invalid MCP server node data: {self.data}")

        if self.node_type == NodeType.SKILL:
            if not isinstance(self.data, SkillNodeData):
                raise ValueError(f"Invalid skill node data: {self.data}")

        return self


class DeepAgentProfileFlow(BaseFlow):
    """Flow Entity. This entity is used to store the flow of the reactflow."""

    nodes: list[DeepAgentProfileNode] | None = Field(
        default_factory=list, description="The nodes of the flow."
    )


class DeepAgentProfile(BaseProfile):
    """Reactflow Agent Profile Entity. This entity is used to store the profile of the reactflow."""

    flow: DeepAgentProfileFlow | None = Field(
        None, description="The flow of the profile."
    )

    @property
    def root_node(self) -> AgentNodeData | None:
        """Get AgentNodeData of the root AI agent node in the profile flow."""
        if not self.flow or not self.flow.nodes:
            return None

        for node in self.flow.nodes:
            if node.root_node:
                if node.node_type == NodeType.AI_AGENT:
                    if node.data and isinstance(node.data, AgentNodeData):
                        return node.data

        return None

    def get_llm_node_of_root_node(self) -> LLMNodeData | None:
        """Get LLMNodeData of the root AI agent node in the profile flow."""
        if not self.flow or not self.flow.nodes or not self.flow.edges:
            return None

        root_node = next(
            (
                n
                for n in self.flow.nodes
                if n.node_type == NodeType.AI_AGENT and n.root_node
            ),
            None,
        )
        if root_node is None or root_node.id is None:
            return None

        child_ids = {e.target for e in self.flow.edges if e.source == root_node.id}
        for node in self.flow.nodes:
            if (
                node.id in child_ids
                and node.node_type == NodeType.LLM
                and isinstance(node.data, LLMNodeData)
            ):
                return node.data

        return None

    def get_node_by_type(self, node_type: NodeType) -> DeepAgentProfileNode | None:
        """Get the agent profile node by the node type."""
        if not self.flow or not self.flow.nodes:
            return None

        for node in self.flow.nodes:
            if node.node_type == node_type:
                return node

        return None

    def validate_profile_restrictions(self) -> DeepAgentProfile:
        """Validate the profile restrictions."""
        validate_deepagent_flow(nodes=self.flow.nodes, edges=self.flow.edges)

        return self

    def get_all_mcp_server_nodes(self) -> list[DeepAgentProfileNode]:
        """Get the mcp server nodes of the deep agent profile."""
        # NOTE : the same mcp-server can be binded to multiple agent nodes. So we need to get the unique mcp server nodes.
        seen_ids: set[str] = set()
        unique_mcp_nodes = []
        for node in self.flow.nodes:
            if node.node_type == NodeType.MCP_SERVER:
                mcp_server_id = self._get_mcp_server_id_from_mcp_connection(
                    node.data.mcp_config_json.mcpServers
                )
                if mcp_server_id not in seen_ids:
                    seen_ids.add(mcp_server_id)
                    unique_mcp_nodes.append(node)

        return unique_mcp_nodes

    def _get_mcp_server_id_from_mcp_connection(
        self, mcp_connection: dict[str, Any]
    ) -> str:
        """Get mcp server id from mcp connections.

        Args:
            mcp_connection: The mcp connection.
            It should be
            ```json
            {
                "server_name": {
                    "server_id": "mcp-server-id",
                    "server_type": "mcp",
                    "server_url": "http://localhost:8080"
                }
            }
            ```

        Returns:
            The mcp server id.
        """
        if mcp_connection is None or len(mcp_connection) == 0:
            raise ValueError(
                "The MCP connection is empty",
            )

        server_id = next(iter(mcp_connection))
        if not server_id:
            raise ValueError(
                "The MCP server doesn't have server id",
            )
        return server_id

    def get_all_skill_nodes(self) -> list[DeepAgentProfileNode]:
        """Get the skill nodes of the deep agent profile."""
        # NOTE : the same skill can be binded to multiple agent nodes. So we need to get the unique skill nodes.
        seen_ids: set[str] = set()
        unique_skill_nodes = []
        for node in self.flow.nodes:
            if node.node_type == NodeType.SKILL and node.data.name not in seen_ids:
                seen_ids.add(node.data.name)
                unique_skill_nodes.append(node)
        return unique_skill_nodes


def validate_deepagent_flow(
    nodes: list[DeepAgentProfileNode], edges: list[SpecBaseEdge]
):
    """Validate the deep agent flow."""
    node_map: dict[str, DeepAgentProfileNode] = {}
    type_counts: Counter[NodeType] = Counter()
    for node in nodes:
        if node.id is not None:
            node_map[node.id] = node
        if node.node_type is not None:
            type_counts[node.node_type] += 1

    # --- Global constraints ---

    # AI_AGENT: exactly 1, must be root_node=True
    ai_agent_nodes = [n for n in nodes if n.node_type == NodeType.AI_AGENT]
    if len(ai_agent_nodes) != 1:
        raise ValueError(
            f"Exactly one AI_AGENT node is required. Found {len(ai_agent_nodes)}."
        )
    if not ai_agent_nodes[0].root_node:
        raise ValueError("AI_AGENT node must have root_node=True.")

    # Only AI_AGENT can be root_node
    for node in nodes:
        if node.node_type != NodeType.AI_AGENT and node.root_node:
            raise ValueError(
                f"Only AI_AGENT type node can be root node. "
                f"Found {node.node_type.value} type node with root_node=True."
            )

    # TRIGGER: max MAX_TRIGGER_NODES
    if type_counts[NodeType.TRIGGER] > MAX_TRIGGER_NODES:
        raise ValueError(
            f"At most {MAX_TRIGGER_NODES} TRIGGER node is allowed. "
            f"Found {type_counts[NodeType.TRIGGER]}."
        )

    # SUB_AGENT: max MAX_SUB_AGENT_NODES
    if type_counts[NodeType.SUB_AGENT] > MAX_SUB_AGENT_NODES:
        raise ValueError(
            f"At most {MAX_SUB_AGENT_NODES} SUB_AGENT nodes are allowed. "
            f"Found {type_counts[NodeType.SUB_AGENT]}."
        )

    # --- Build children map from edges ---
    children_by_source: dict[str, list[str]] = {}
    for edge in edges:
        if edge.source is not None and edge.target is not None:
            children_by_source.setdefault(edge.source, []).append(edge.target)

    # --- Main Agent (AI_AGENT) child constraints ---
    main_agent = ai_agent_nodes[0]
    if main_agent.id is not None:
        main_children = children_by_source.get(main_agent.id, [])
        main_child_types: Counter[NodeType] = Counter()
        for child_id in main_children:
            child = node_map.get(child_id)
            if child and child.node_type is not None:
                main_child_types[child.node_type] += 1

        if main_child_types[NodeType.LLM] != 1:
            raise ValueError(
                f"Main Agent must have exactly 1 LLM node. "
                f"Found {main_child_types[NodeType.LLM]}."
            )
        if main_child_types[NodeType.MEMORY] > MAX_MEMORY_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_MEMORY_NODES} MEMORY node. "
                f"Found {main_child_types[NodeType.MEMORY]}."
            )
        if main_child_types[NodeType.SKILL] > MAX_SKILL_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_SKILL_NODES} SKILL nodes. "
                f"Found {main_child_types[NodeType.SKILL]}."
            )
        if main_child_types[NodeType.MCP_SERVER] > MAX_MCP_SERVER_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_MCP_SERVER_NODES} MCP_SERVER nodes. "
                f"Found {main_child_types[NodeType.MCP_SERVER]}."
            )
        if main_child_types[NodeType.SUB_AGENT] > MAX_SUB_AGENT_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_SUB_AGENT_NODES} SUB_AGENT nodes. "
                f"Found {main_child_types[NodeType.SUB_AGENT]}."
            )

    # --- Sub Agent child constraints ---
    sub_agent_nodes = [n for n in nodes if n.node_type == NodeType.SUB_AGENT]
    for sub_agent in sub_agent_nodes:
        if sub_agent.id is None:
            continue
        sub_children = children_by_source.get(sub_agent.id, [])
        sub_child_types: Counter[NodeType] = Counter()
        for child_id in sub_children:
            child = node_map.get(child_id)
            if child and child.node_type is not None:
                sub_child_types[child.node_type] += 1

        # Sub Agent must have exactly 1 LLM
        if sub_child_types[NodeType.LLM] != 1:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' must have exactly 1 LLM node. "
                f"Found {sub_child_types[NodeType.LLM]}."
            )
        # Sub Agent: max MAX_SKILL_NODES SKILLs
        if sub_child_types[NodeType.SKILL] > MAX_SKILL_NODES:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' can have at most {MAX_SKILL_NODES} SKILL nodes. "
                f"Found {sub_child_types[NodeType.SKILL]}."
            )
        # Sub Agent: max MAX_MCP_SERVER_NODES MCP_SERVERs
        if sub_child_types[NodeType.MCP_SERVER] > MAX_MCP_SERVER_NODES:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' can have at most {MAX_MCP_SERVER_NODES} MCP_SERVER nodes. "
                f"Found {sub_child_types[NodeType.MCP_SERVER]}."
            )
        # Sub Agent cannot have nested SUB_AGENTs
        if sub_child_types[NodeType.SUB_AGENT] > 0:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' cannot have nested SUB_AGENT nodes."
            )
        # Sub Agent cannot have MEMORY nodes
        if sub_child_types[NodeType.MEMORY] > 0:
            raise ValueError(
                f"Sub Agent '{sub_agent.id}' cannot have MEMORY nodes. "
                f"Only the Main Agent can have MEMORY."
            )
