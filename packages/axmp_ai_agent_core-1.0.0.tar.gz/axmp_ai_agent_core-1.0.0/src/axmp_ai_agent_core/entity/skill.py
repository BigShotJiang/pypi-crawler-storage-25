"""Skill entity."""

from __future__ import annotations

import re

from pydantic import BaseModel, Field, field_validator

from axmp_ai_agent_core.agent.spec.types import SkillFileType
from axmp_ai_agent_core.entity.base_model import NamedCoreBaseModel
from axmp_ai_agent_core.entity.shared_target import SharedTarget

_SYSTEM_NAME_PATTERN = re.compile(r"^[a-z0-9]([a-z0-9-]*[a-z0-9])?$")
_SYSTEM_NAME_MAX_LENGTH = 64


class SkillFile(BaseModel):
    """Embedded file metadata within a Skill."""

    file_id: str = Field(..., description="Unique file identifier")
    file_type: SkillFileType = Field(
        ..., description="File type (script/reference/asset)"
    )
    filename: str = Field(..., description="Original filename")
    file_path: str = Field(..., description="Storage path")
    file_size: int = Field(0, description="File size in bytes")
    mime_type: str | None = Field(
        None, description="MIME type (auto-detected on upload)"
    )


class Skill(NamedCoreBaseModel):
    """Skill entity — instruction-based reusable module for AI Agents."""

    description: str | None = Field(
        None, max_length=1024, description="Skill description (plain text)"
    )
    instruction: str | None = Field(
        None,
        max_length=100000,
        description="SKILL.md body content (Markdown, no frontmatter, max ~1250 lines)",
    )
    categories: list[str] = Field(
        default_factory=list, max_length=10, description="Category tags (max 10)"
    )
    icon_url: str | None = Field(None, description="Skill icon URL")
    shared_target: SharedTarget | None = Field(
        None, description="Sharing configuration"
    )
    version: int = Field(1, description="Current version number")
    pinned_version: int | None = Field(
        None, description="Pinned version for Agent reference. None = use latest"
    )
    like_count: int = Field(0, description="Denormalized like count")
    files: list[SkillFile] = Field(
        default_factory=list, description="Attached file metadata"
    )
    search_tokens: list[str] = Field(
        default_factory=list,
        description="Tokenized search index (Kiwi + alias, auto-generated)",
    )

    @field_validator("system_name")
    @classmethod
    def validate_system_name(cls, v: str | None) -> str:
        """Validate system_name follows Agent Skills spec.

        System_name of Skill is required (name field in Agent Skills spec).
        Rules: lowercase + digits + hyphens only, 1-64 chars,
        no leading/trailing hyphens, no consecutive hyphens.
        """
        if v is None:
            msg = "system_name is required for Skill"
            raise ValueError(msg)
        if len(v) > _SYSTEM_NAME_MAX_LENGTH:
            msg = f"system_name must be at most {_SYSTEM_NAME_MAX_LENGTH} characters"
            raise ValueError(msg)
        if "--" in v:
            msg = "system_name must not contain consecutive hyphens"
            raise ValueError(msg)
        if not _SYSTEM_NAME_PATTERN.match(v):
            msg = "system_name must match pattern: lowercase letters, digits, and single hyphens (no leading/trailing hyphens)"
            raise ValueError(msg)
        return v
