"""OAuth Provider entity."""

from __future__ import annotations

from enum import StrEnum

from pydantic import Field

from axmp_ai_agent_core.entity.base_model import NamedCoreBaseModel


class OAuthProviderType(StrEnum):
    """OAuth provider type enum."""

    GOOGLE = "google"
    GITHUB = "github"
    GITLAB = "gitlab"
    MICROSOFT = "microsoft"
    SLACK = "slack"
    KEYCLOAK = "keycloak"
    AUTH0 = "auth0"
    OKTA = "okta"
    AWS_COGNITO = "aws_cognito"
    CUSTOM = "custom"


SINGLE_INSTANCE_PROVIDER_TYPES: frozenset[OAuthProviderType] = frozenset(
    {
        OAuthProviderType.GOOGLE,
        OAuthProviderType.GITHUB,
        OAuthProviderType.GITLAB,
        OAuthProviderType.MICROSOFT,
        OAuthProviderType.SLACK,
    }
)


class OAuthProviderStatus(StrEnum):
    """OAuth provider status enum."""

    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class OAuthProvider(NamedCoreBaseModel):
    """OAuth Provider entity.

    Represent a centrally registered OAuth provider for MCP server authentication.
    """

    description: str | None = Field(None, max_length=2000)
    provider_type: OAuthProviderType
    status: OAuthProviderStatus = Field(default=OAuthProviderStatus.ACTIVE)
    icon_url: str | None = None
    issuer_url: str | None = None
    token_endpoint: str | None = None
    authorization_endpoint: str | None = None
    grant_types_supported: list[str] | None = None
    scopes_supported: list[str] | None = None
    extra_params: dict[str, str] | None = None
