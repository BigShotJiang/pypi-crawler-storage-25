"""MCP Server Profile entity."""

from __future__ import annotations

from enum import StrEnum
from typing import Any, Dict

from axmp_openapi_helper import (
    AuthConfig,
    ToolConfig,
)
from pydantic import BaseModel, Field, field_serializer, model_validator

from axmp_ai_agent_core.agent.spec.types import ProfileStatus, TransportType
from axmp_ai_agent_core.entity.base_model import NamedCoreBaseModel
from axmp_ai_agent_core.entity.base_profile import (
    BaseFlow,
    BaseNode,
)
from axmp_ai_agent_core.entity.shared_target import SharedTarget

MCP_SERVER_CONFIG_KEY = "mcpServers"


class McpServerConfigJson(BaseModel):
    """MCP Server config json."""

    mcpServers: Dict[str, Any] = Field(default_factory=dict)


class McpServerConfigJsonCombined(BaseModel):
    """Combined MCP server config json data."""

    mcp_server_json: McpServerConfigJson | None = None
    internal_mcp_server_json: McpServerConfigJson | None = None


class McpServerProfileNodeType(StrEnum):
    """McpServerProfileNodeType Entity. This entity is used to store the type of the node."""

    BACKEND_SERVER = "Backend-Server"
    MCP_SERVER = "MCP-Server"


class BackendServerNodeData(BaseModel):
    """MCP Backend Server entity."""

    # type: McpServerProfileNodeType = McpServerProfileNodeType.BACKEND_SERVER
    backend_server_id: str = Field(
        ...,
        description="The backend server id of the backend server node.",
    )
    name: str = Field(
        ...,
        description="The name of the backend server.",
        min_length=1,
        max_length=255,
    )
    tool_config: ToolConfig | None = Field(
        None,
        description="The tool config of the backend server node.",
    )
    tool_count: int = Field(
        0,
        description="The number of tools in the MCP server node.",
    )
    api_count: int = Field(
        0,
        description="The number of APIs in the backend server node.",
    )


class McpServerNodeData(BaseModel):
    """MCP Server node data - for flow visualization."""

    name: str = Field(
        ...,
        description="The name of the MCP server node.",
        min_length=1,
        max_length=255,
    )
    auth_config: AuthConfig | None = Field(
        None,
        description="The authentication config of the MCP server.",
    )


class McpServerProfileNode(BaseNode):
    """Node Entity. This entity is used to store the node."""

    node_type: McpServerProfileNodeType = Field(
        default=McpServerProfileNodeType.MCP_SERVER,
        description="The type of the node.",
    )
    data: BackendServerNodeData | McpServerNodeData | None = None


class McpServerProfileFlow(BaseFlow):
    """Flow Entity. This entity is used to store the flow."""

    nodes: list[McpServerProfileNode] | None = None

    @model_validator(mode="after")
    def validate_root_node(self) -> McpServerProfileFlow:
        """Validate that only MCP_SERVER type node can be root node.

        If there is a non-MCP_SERVER type node with root_node=True, raise validation error.
        """
        if not self.nodes:
            return self

        root_node_count = 0
        for node in self.nodes:
            if node.node_type != McpServerProfileNodeType.MCP_SERVER and node.root_node:
                raise ValueError(
                    f"Only MCP_SERVER type node can be root node. Found {node.node_type} type node with root_node=True"
                )

            if node.root_node:
                root_node_count += 1

        if root_node_count > 1:
            raise ValueError(
                f"Only one MCP_SERVER type node can be root node. Found {root_node_count} MCP_SERVER type nodes with root_node=True"
            )

        return self


class McpServerProfile(NamedCoreBaseModel):
    """MCP Server Profile Entity."""

    description: str | None = Field(None, max_length=2000)
    icon_url: str | None = None
    tool_count: int = Field(default=0)
    version: int | None = None
    labels: dict[str, str] = Field(default_factory=dict)
    transport_type: TransportType = Field(default=TransportType.HTTP)
    backend_count: int = Field(default=0)
    status: ProfileStatus = Field(default=ProfileStatus.DRAFT)
    shared_target: SharedTarget | None = None
    flow: McpServerProfileFlow | None = None

    @field_serializer("version", when_used="json")
    def _serialize_version(self, version: int | None) -> str | None:
        """Serialize version field to 'vN' format for JSON output."""
        if version is None:
            return None
        return f"v{version}"

    def get_mcp_server_node_data(self) -> McpServerNodeData | None:
        """Get the MCP server node from the flow."""
        if not self.flow or not self.flow.nodes:
            return None
        for node in self.flow.nodes:
            if node.node_type == McpServerProfileNodeType.MCP_SERVER:
                return node.data
        return None
