"""Agent Provision Status Entity."""

from __future__ import annotations

from pydantic import ConfigDict, Field, field_serializer

from axmp_ai_agent_core.agent.spec.profile_base import (
    AuthenticationConfig,
    EndpointConfig,
)
from axmp_ai_agent_core.agent.spec.types import DeploymentMode
from axmp_ai_agent_core.entity.base_model import CoreBaseModel
from axmp_ai_agent_core.k8s.model.custom_resource import Phase


class AgentProvisionStatus(CoreBaseModel):
    """Agent Provision Status Entity.

    Schema is aligned with McpServerProvisionStatus for consistency.
    """

    profile_id: str = Field(
        ...,
        description="The ID of the agent profile that was provisioned",
        min_length=1,
        max_length=255,
    )
    profile_version: int = Field(
        ...,
        description="The version of the agent profile that was provisioned",
    )

    @field_serializer("profile_version", when_used="json")
    def _serialize_profile_version(self, profile_version: int) -> str:
        return f"v{profile_version}"

    # K8s related fields (aligned with McpServerProvisionStatus)
    cluster_id: str = Field(
        ...,
        description="KubernetesConfig._id — identifies the target K8s cluster",
        min_length=1,
        max_length=255,
    )
    cluster_name: str = Field(
        ...,
        description="K8s cluster name",
    )
    namespace: str = Field(
        ...,
        description="K8s namespace where the instance is deployed",
        min_length=1,
        max_length=255,
    )
    instance_id: str = Field(
        ...,
        description="Unique instance ID (from label 'instance-id')",
    )
    name: str = Field(
        ...,
        description="K8s resource name (metadata.name)",
    )
    status: Phase = Field(
        default=Phase.UNKNOWN,
        description="Instance phase status",
    )
    labels: dict[str, str] | None = Field(
        None,
        description="User-defined labels",
    )

    # Agent-specific fields
    deployment_mode: DeploymentMode | None = Field(
        None,
        description="The deployment mode of the agent",
    )
    auth_config: AuthenticationConfig | None = Field(
        None,
        description="Authentication configuration for the agent",
    )
    endpoint_config: EndpointConfig | None = Field(
        None,
        description="Endpoint configuration for the agent",
    )

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )
