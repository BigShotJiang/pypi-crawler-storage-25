"""Agent Catalog Entity. This entity is used to store the catalog of the agent."""

from __future__ import annotations

from enum import StrEnum

from a2a.types import AgentCard, AgentProvider

from axmp_ai_agent_core.entity.base_model import CoreBaseModel


class ResourceType(StrEnum):
    """Resource Type."""

    INTERNAL = "internal"
    EXTERNAL = "external"


class AgentType(StrEnum):
    """Agent Type."""

    SINGLE_AGENT = "single_agent"
    A2A_SERVER = "a2a_server"
    A2A_HOST_AGENT = "a2a_host_agent"


class ApplicationType(StrEnum):
    """Application Type."""

    CHATBOT = "chatbot"
    WEBHOOK = "webhook"
    SCHEDULER = "scheduler"


class AgentCatalog(CoreBaseModel):
    """Agent Catalog Entity. This entity is used to store the catalog of the agent."""

    name: str | None = None
    icon_url: str | None = None
    description: str | None = None
    categories: list[str] | None = None
    agent_type: AgentType | None = None
    resource_type: ResourceType | None = None
    application_type: ApplicationType | None = None
    version: str | None = None
    provider: AgentProvider | None = None
    agent_card_endpoint: str | None = None
    service_endpoint: str | None = None
    doc_url: str | None = None
    agent_card: AgentCard | None = None
