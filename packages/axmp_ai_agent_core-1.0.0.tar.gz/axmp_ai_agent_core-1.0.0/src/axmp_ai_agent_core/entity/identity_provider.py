"""LLM provider entity."""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel

from axmp_ai_agent_core.entity.base_model import CoreBaseModel


class IdentityProviderStatus(StrEnum):
    """Identity provider status."""

    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class IdentityProtocol(StrEnum):
    """Identity type."""

    OPENID = "OPENID"
    SAML = "SAML"


class OpenIDConnectProvider(BaseModel):
    """OpenID provider entity."""

    # OpenID  metadata
    issuer: str
    client_id: str
    client_secret: str
    redirect_uri: str
    scope: str = "openid profile email"
    algorithm: str = "RS256"
    # Required endpoints
    jwks_uri: str
    authorization_endpoint: str
    token_endpoint: str
    userinfo_endpoint: str | None = None
    # Optional endpoints
    introspection_endpoint: str | None = None
    end_session_endpoint: str | None = None
    registration_endpoint: str | None = None
    # Common metadata
    grant_types: str = "authorization_code"
    response_types: str = "code"
    subject_types: str = "public"


class SAMLProvider(BaseModel):
    """SAML provider entity."""

    # IdP endpoints and identifiers
    server_url: str
    entity_id: str
    metadata_url: str | None = None
    metadata_xml: str | None = None

    # SP endpoints (from the perspective of this app)
    assertion_consumer_service_url: str
    single_logout_service_url: str | None = None

    # Certificates/keys
    signing_certificate: str | None = None
    signing_private_key: str | None = None
    encryption_certificate: str | None = None

    # Protocol preferences
    nameid_format: str = "urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress"
    sso_binding: str = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"
    slo_binding: str = "urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"
    signature_algorithm: str = "RSA_SHA256"
    digest_algorithm: str = "SHA256"
    authn_context_class_ref: str | None = (
        "urn:oasis:names:tc:SAML:2.0:ac:classes:PasswordProtectedTransport"
    )

    # Security/validation flags
    want_assertions_signed: bool = True
    want_response_signed: bool = False
    encrypt_assertions: bool = False
    allow_idp_initiated: bool = False
    clock_skew_seconds: int = 120

    # Attribute mappings (IdP attribute name -> local field)
    attribute_mapping: dict[str, str] | None = None


class IdentityProvider(CoreBaseModel):
    """Identity provider entity."""

    name: str
    icon_url: str | None = None
    type: IdentityProtocol = IdentityProtocol.OPENID
    status: IdentityProviderStatus = IdentityProviderStatus.ACTIVE
    provider: OpenIDConnectProvider | SAMLProvider = None
