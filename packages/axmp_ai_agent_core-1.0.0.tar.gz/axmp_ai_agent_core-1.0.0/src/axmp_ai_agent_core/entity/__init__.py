"""Pydantic entity models with MongoDB ObjectId and audit field support."""

from .agent_profile_deepagent import (
    DeepAgentProfile,
    DeepAgentProfileFlow,
    DeepAgentProfileNode,
)
from .agent_profile_singleagent import (
    SingleAgentProfile,
    SingleAgentProfileFlow,
    SingleAgentProfileNode,
)

AgentProfile = DeepAgentProfile | SingleAgentProfile

__all__ = [
    "AgentProfile",
    "DeepAgentProfile",
    "DeepAgentProfileFlow",
    "DeepAgentProfileNode",
    "SingleAgentProfile",
    "SingleAgentProfileFlow",
    "SingleAgentProfileNode",
]
