"""MCP server provision status entity."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_serializer

from axmp_ai_agent_core.entity.base_model import CoreBaseModel
from axmp_ai_agent_core.entity.mcp_server_profile import McpServerConfigJson
from axmp_ai_agent_core.k8s.model.custom_resource import Phase


class McpServerConfigs(BaseModel):
    """MCP server combined entity."""

    internal: McpServerConfigJson
    external: McpServerConfigJson | None = None


class McpServerProvisionStatus(CoreBaseModel):
    """MCP server provision status entity."""

    profile_id: str
    profile_version: int = Field(
        ...,
        description="The version of the MCP server profile",
    )

    @field_serializer("profile_version", when_used="json")
    def _serialize_profile_version(self, profile_version: int) -> str:
        return f"v{profile_version}"

    cluster_id: str = Field(
        ...,
        description="KubernetesConfig._id — identifies the target K8s cluster",
    )
    mcp_config_json: McpServerConfigs | None = None
    cluster_name: str = Field(..., description="K8s cluster name")
    namespace: str = Field(
        ...,
        description="K8s namespace where the instance is deployed",
        min_length=1,
        max_length=255,
    )
    description: str | None = Field(
        None, description="Instance description (from annotation)"
    )
    instance_id: str = Field(
        ..., description="Unique instance ID (from label 'instance-id')"
    )
    is_published: bool = Field(False, description="Whether published to registry")
    labels: dict[str, str] | None = Field(None, description="User-defined labels")
    name: str = Field(..., description="K8s resource name (metadata.name)")
    status: Phase = Field(..., description="Instance phase status")

    model_config = ConfigDict(
        populate_by_name=True,
        arbitrary_types_allowed=True,
        extra="forbid",
    )
