"""MCP Registry entity."""

from enum import StrEnum
from typing import Any, Dict, List

from axmp_openapi_helper import APIServerConfig
from langchain_core.tools import BaseTool
from pydantic import BaseModel, field_serializer

from axmp_ai_agent_core.entity.base_model import CoreBaseModel
from axmp_ai_agent_core.entity.mcp_server_profile import (
    McpServerConfigJson,
    TransportType,
)


class ResourceType(StrEnum):
    """Resource type."""

    INTERNAL = "internal"
    EXTERNAL = "external"


class Status(StrEnum):
    """Status.

    .. deprecated::
        This field is no longer used in any business logic.
    """

    ACTIVE = "active"
    INACTIVE = "inactive"


class McpRegistry(CoreBaseModel):
    """MCP Registry entity."""

    name: str | None = None
    description: str | None = None
    categories: List[str] | None = None
    version: str | None = None
    mcp_server_json: McpServerConfigJson | None = None
    internal_mcp_server_json: McpServerConfigJson | None = None
    profile_id: str | None = None
    profile_version: int | None = None
    labels: Dict[str, str] | None = None
    icon_url: str | None = None
    transport_type: TransportType | None = None
    resource_type: ResourceType | None = None
    is_published: bool | None = None
    status: Status | None = None  # deprecated: not used in business logic
    tools: list[dict[str, Any]] | None = None

    @field_serializer("profile_version", when_used="json")
    def _serialize_profile_version(self, profile_version: int | None) -> str | None:
        return f"v{profile_version}" if profile_version is not None else None


class McpServerInstancePublishData(BaseModel):
    """InternalServer publish data."""

    mcp_server_json: Dict[str, Any]
    internal_mcp_server_json: Dict[str, Any]
    transport_type: TransportType = TransportType.HTTP
    resource_type: str = ResourceType.INTERNAL
    is_external: bool = False


class ExtendedAPIServerConfig(APIServerConfig):
    """Extended APIServerConfig with additional system_name field."""

    system_name: str | None = None


class ExternalMcpPublishData(BaseModel):
    """External MCP publish data."""

    version: str
    mcp_server_json: Dict[str, Any]
    internal_mcp_server_json: Dict[str, Any] | None = None
    tools: list[BaseTool]
