"""MCP server profile history entity."""

from pydantic import Field, field_serializer

from axmp_ai_agent_core.entity.base_model import CoreBaseModel
from axmp_ai_agent_core.entity.mcp_server_profile import McpServerProfile


class McpServerProfileHistory(CoreBaseModel):
    """MCP server profile history entity."""

    mcp_server_profile_id: str = Field(
        ..., description="Reference to mcp_server_profiles ObjectId"
    )
    version: int = Field(..., description="Sequential version number (1, 2, 3, ...)")
    comment: str | None = Field(
        None, max_length=1000, description="Change description written by user"
    )
    mcp_server_profile_data: McpServerProfile = Field(
        None, description="Complete mcp_server_profiles data at that time"
    )

    @field_serializer("version", when_used="json")
    def _serialize_version(self, version: int | None) -> str | None:
        if version is None:
            return None
        return f"v{version}"
