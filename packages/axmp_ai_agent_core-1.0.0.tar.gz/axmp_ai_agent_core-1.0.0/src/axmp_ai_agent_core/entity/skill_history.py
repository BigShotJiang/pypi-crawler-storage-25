"""Skill history entity."""

from __future__ import annotations

from pydantic import Field

from axmp_ai_agent_core.entity.base_model import CoreBaseModel
from axmp_ai_agent_core.entity.skill import SkillFile


class SkillHistory(CoreBaseModel):
    """Skill version history — full snapshot of a Skill at a specific version."""

    skill_id: str = Field(..., description="Reference to parent Skill")
    version: int = Field(..., description="Version number")
    name: str | None = Field(None, description="Skill name at this version")
    system_name: str | None = Field(None, description="System name at this version")
    description: str | None = Field(None, description="Description at this version")
    instruction: str | None = Field(None, description="SKILL.md body at this version")
    categories: list[str] = Field(default_factory=list)
    icon_url: str | None = None
    files: list[SkillFile] = Field(
        default_factory=list, description="File metadata snapshot"
    )
    comment: str | None = Field(None, description="Optional version comment")
