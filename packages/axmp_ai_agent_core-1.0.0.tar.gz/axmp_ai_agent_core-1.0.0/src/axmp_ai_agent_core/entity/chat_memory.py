"""LLM provider entity."""

from __future__ import annotations

from enum import StrEnum

from axmp_ai_agent_core.agent.spec.types import AgentMemoryType
from axmp_ai_agent_core.entity.base_model import CoreBaseModel


class ChatMemoryStatus(StrEnum):
    """Chat memory status."""

    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"


class ChatMemory(CoreBaseModel):
    """Chat memory entity."""

    name: str
    memory_type: AgentMemoryType | None = None
    status: ChatMemoryStatus | None = None
    icon_url: str | None = None
    db_uri: str | None = None
    is_default: bool | None = None
