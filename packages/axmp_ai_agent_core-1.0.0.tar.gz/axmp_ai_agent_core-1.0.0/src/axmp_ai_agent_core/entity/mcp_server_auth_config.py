"""MCP Server Auth Config."""

from __future__ import annotations

from axmp_openapi_helper import AuthConfig
from pydantic import BaseModel, Field


class McpServerAuthConfig(BaseModel):
    """MCP Server Auth Config."""

    profile_id: str = Field(..., description="MCP server profile ID")
    auth_config: AuthConfig = Field(..., description="MCP server auth config")


class McpServerBackendServerAuthConfig(BaseModel):
    """MCP Server Backend Server Auth Config."""

    server_id: str = Field(..., description="Backend server ID")
    server_name: str | None = Field(None, description="Backend server name")
    server_system_name: str | None = Field(
        None, description="Backend server system name"
    )
    auth_config: AuthConfig = Field(..., description="Backend server auth config")


class McpServerAuthorizationConfig(BaseModel):
    """MCP Server Playground Config Response DTO."""

    mcp_server_auth_config: McpServerAuthConfig | None = Field(
        None,
        description="MCP server auth config",
    )

    backend_server_auth_configs: list[McpServerBackendServerAuthConfig] = Field(
        [], description="Backend server auth configs"
    )
