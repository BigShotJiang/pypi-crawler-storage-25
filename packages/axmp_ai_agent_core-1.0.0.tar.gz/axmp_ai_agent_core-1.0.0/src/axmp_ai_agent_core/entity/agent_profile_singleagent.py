"""Reactflow Profile Entity. This entity is used to store the profile of the reactflow."""

from __future__ import annotations

from collections import Counter

from pydantic import Field, model_validator

from axmp_ai_agent_core.agent.spec.profile_base import (
    SpecBaseEdge,
)
from axmp_ai_agent_core.agent.spec.profiles.singleagent_profile import (
    MAX_MCP_SERVER_NODES,
    MAX_MEMORY_NODES,
    MAX_SKILL_NODES,
    MAX_TRIGGER_NODES,
)
from axmp_ai_agent_core.agent.spec.types import (
    NodeType,
)
from axmp_ai_agent_core.entity.agent_profile_node_data import (
    AgentNodeData,
    ChatbotTriggerNodeData,
    ExternalMcpServerNodeData,
    InternalMcpServerNodeData,
    LLMNodeData,
    MemoryNodeData,
    SchedulerTriggerNodeData,
    # SkillNodeData,
    WebhookTriggerNodeData,
)
from axmp_ai_agent_core.entity.base_profile import (
    BaseFlow,
    BaseNode,
    BaseProfile,
)


class SingleAgentProfileNode(BaseNode):
    """Node Entity. This entity is used to store the node of the reactflow."""

    data: (
        ChatbotTriggerNodeData
        | WebhookTriggerNodeData
        | SchedulerTriggerNodeData
        | AgentNodeData
        | LLMNodeData
        | MemoryNodeData
        | InternalMcpServerNodeData
        | ExternalMcpServerNodeData
        # | SkillNodeData   # Unsupported by langchain create_agent()
    ) = Field(..., description="The data of the node.", discriminator="data_type")

    @model_validator(mode="after")
    def validate_type(self) -> SingleAgentProfileNode:
        """Validate that the type of the node is valid."""
        if self.node_type not in [
            NodeType.TRIGGER,
            NodeType.AI_AGENT,
            NodeType.LLM,
            NodeType.MEMORY,
            NodeType.MCP_SERVER,
            # NodeType.SKILL,
        ]:
            raise ValueError(f"Invalid node type: {self.node_type}")

        if self.node_type == NodeType.TRIGGER:
            if not isinstance(
                self.data,
                ChatbotTriggerNodeData
                | WebhookTriggerNodeData
                | SchedulerTriggerNodeData,
            ):
                raise ValueError(f"Invalid trigger node data: {self.data}")

        if self.node_type == NodeType.AI_AGENT:
            if not isinstance(self.data, AgentNodeData):
                raise ValueError(f"Invalid AI agent node data: {self.data}")

        if self.node_type == NodeType.LLM:
            if not isinstance(self.data, LLMNodeData):
                raise ValueError(f"Invalid LLM node data: {self.data}")

        if self.node_type == NodeType.MEMORY:
            if not isinstance(self.data, MemoryNodeData):
                raise ValueError(f"Invalid memory node data: {self.data}")

        if self.node_type == NodeType.MCP_SERVER:
            if not isinstance(
                self.data, InternalMcpServerNodeData | ExternalMcpServerNodeData
            ):
                raise ValueError(f"Invalid MCP server node data: {self.data}")

        # if self.node_type == NodeType.SKILL:
        #     if not isinstance(self.data, SkillNodeData):
        #         raise ValueError(f"Invalid skill node data: {self.data}")

        return self


class SingleAgentProfileFlow(BaseFlow):
    """Flow Entity. This entity is used to store the flow of the reactflow."""

    nodes: list[SingleAgentProfileNode] | None = Field(
        default_factory=list, description="The nodes of the flow."
    )


class SingleAgentProfile(BaseProfile):
    """Reactflow Agent Profile Entity. This entity is used to store the profile of the reactflow."""

    flow: SingleAgentProfileFlow | None = Field(
        None, description="The flow of the profile."
    )

    @property
    def root_node(self) -> AgentNodeData | None:
        """Get AgentNodeData of the root AI agent node in the profile flow."""
        if not self.flow or not self.flow.nodes:
            return None

        for node in self.flow.nodes:
            if node.root_node:
                if node.node_type == NodeType.AI_AGENT:
                    if node.data and isinstance(node.data, AgentNodeData):
                        return node.data

        return None

    def get_llm_node_of_root_node(self) -> LLMNodeData | None:
        """Get LLMNodeData of the root AI agent node in the profile flow."""
        if not self.flow or not self.flow.nodes or not self.flow.edges:
            return None

        root_node = next(
            (
                n
                for n in self.flow.nodes
                if n.node_type == NodeType.AI_AGENT and n.root_node
            ),
            None,
        )
        if root_node is None or root_node.id is None:
            return None

        child_ids = {e.target for e in self.flow.edges if e.source == root_node.id}
        for node in self.flow.nodes:
            if (
                node.id in child_ids
                and node.node_type == NodeType.LLM
                and isinstance(node.data, LLMNodeData)
            ):
                return node.data

        return None

    def get_node_by_type(self, node_type: NodeType) -> SingleAgentProfileNode | None:
        """Get the agent profile node by the node type."""
        if not self.flow or not self.flow.nodes:
            return None

        for node in self.flow.nodes:
            if node.node_type == node_type:
                return node

        return None

    def validate_profile_restrictions(self) -> SingleAgentProfile:
        """Validate the profile restrictions."""
        validate_singleagent_flow(nodes=self.flow.nodes, edges=self.flow.edges)

        return self

    def get_all_mcp_server_nodes(self) -> list[SingleAgentProfileNode]:
        """Get the mcp server nodes of the single agent profile."""
        return [n for n in self.flow.nodes if n.node_type == NodeType.MCP_SERVER]

    def get_all_skill_nodes(self) -> list[SingleAgentProfileNode]:
        """Get the skill nodes of the single agent profile."""
        raise NotImplementedError("Single agent profile does not support skill nodes.")


def validate_singleagent_flow(
    nodes: list[SingleAgentProfileNode], edges: list[SpecBaseEdge]
):
    """Validate the single agent flow."""
    node_map: dict[str, SingleAgentProfileNode] = {}
    type_counts: Counter[NodeType] = Counter()
    for node in nodes:
        if node.id is not None:
            node_map[node.id] = node
        if node.node_type is not None:
            type_counts[node.node_type] += 1

    # --- Global constraints ---

    # AI_AGENT: exactly 1, must be root_node=True
    ai_agent_nodes = [n for n in nodes if n.node_type == NodeType.AI_AGENT]
    if len(ai_agent_nodes) != 1:
        raise ValueError(
            f"Exactly one AI_AGENT node is required. Found {len(ai_agent_nodes)}."
        )
    if not ai_agent_nodes[0].root_node:
        raise ValueError("AI_AGENT node must have root_node=True.")

    # Only AI_AGENT can be root_node
    for node in nodes:
        if node.node_type != NodeType.AI_AGENT and node.root_node:
            raise ValueError(
                f"Only AI_AGENT type node can be root node. "
                f"Found {node.node_type.value} type node with root_node=True."
            )

    # TRIGGER: max MAX_TRIGGER_NODES
    if type_counts[NodeType.TRIGGER] > MAX_TRIGGER_NODES:
        raise ValueError(
            f"At most {MAX_TRIGGER_NODES} TRIGGER node is allowed. "
            f"Found {type_counts[NodeType.TRIGGER]}."
        )

    # SUB_AGENT: not allowed in single agent
    if type_counts[NodeType.SUB_AGENT] > 0:
        raise ValueError(
            "SUB_AGENT nodes are not allowed in a single agent profile. "
            f"Found {type_counts[NodeType.SUB_AGENT]}."
        )

    # REMOTE_AGENT: not allowed in single agent
    if type_counts[NodeType.REMOTE_AGENT] > 0:
        raise ValueError(
            "REMOTE_AGENT nodes are not allowed in a single agent profile. "
            f"Found {type_counts[NodeType.REMOTE_AGENT]}."
        )

    # --- Build children map from edges ---
    children_by_source: dict[str, list[str]] = {}
    for edge in edges:
        if edge.source is not None and edge.target is not None:
            children_by_source.setdefault(edge.source, []).append(edge.target)

    # --- Main Agent (AI_AGENT) child constraints ---
    main_agent = ai_agent_nodes[0]
    if main_agent.id is not None:
        main_children = children_by_source.get(main_agent.id, [])
        main_child_types: Counter[NodeType] = Counter()
        for child_id in main_children:
            child = node_map.get(child_id)
            if child and child.node_type is not None:
                main_child_types[child.node_type] += 1

        if main_child_types[NodeType.LLM] != 1:
            raise ValueError(
                f"Main Agent must have exactly 1 LLM node. "
                f"Found {main_child_types[NodeType.LLM]}."
            )
        if main_child_types[NodeType.MEMORY] > MAX_MEMORY_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_MEMORY_NODES} MEMORY node. "
                f"Found {main_child_types[NodeType.MEMORY]}."
            )
        if main_child_types[NodeType.SKILL] > MAX_SKILL_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_SKILL_NODES} SKILL nodes. "
                f"Found {main_child_types[NodeType.SKILL]}."
            )
        if main_child_types[NodeType.MCP_SERVER] > MAX_MCP_SERVER_NODES:
            raise ValueError(
                f"Main Agent can have at most {MAX_MCP_SERVER_NODES} MCP_SERVER nodes. "
                f"Found {main_child_types[NodeType.MCP_SERVER]}."
            )
        if main_child_types[NodeType.SUB_AGENT] > 0:
            raise ValueError(
                "Agent cannot have SUB_AGENT child nodes in a single agent profile."
            )
