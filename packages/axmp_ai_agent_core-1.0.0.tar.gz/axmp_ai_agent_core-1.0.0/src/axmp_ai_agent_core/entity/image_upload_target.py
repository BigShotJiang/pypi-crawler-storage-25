"""Image upload target."""

from enum import Enum


class ImageUploadTarget(Enum):
    """Image upload target."""

    AGENT = "agent"
    MCP_SERVER = "mcp-server"
    LLM_PROVIDER = "llm-provider"
    CHAT_MEMORY = "chat-memory"
    VECTOR_STORE = "vectorstore"
    IDP = "identity-provider"
    SKILL = "skill"

    @classmethod
    def get_all_targets(cls) -> list[str]:
        """Get all targets."""
        return [target.value for target in cls]
