"""Kubernetes configuration entity."""

from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field, field_validator, model_validator

from axmp_ai_agent_core.entity.base_model import CoreBaseModel


class ConnectionStatus(StrEnum):
    """Connection status simplified."""

    PENDING = "Pending"
    CONNECTED = "Connected"
    ERROR = "Error"


DEFAULT_PORT = 21000


class DeploymentConfig(BaseModel):
    """Default container resource settings for Kubernetes deployments.

    Attributes:
        replicas: Default replica count for deployments.
        cpu_request: CPU resource request for containers.
        cpu_limit: CPU resource limit for containers.
        memory_request: Memory resource request for containers.
        memory_limit: Memory resource limit for containers.
    """

    replicas: int = Field(default=1)
    cpu_request: str = Field(default="100m", alias="cpuRequest")
    cpu_limit: str = Field(default="100m", alias="cpuLimit")
    memory_request: str = Field(default="128Mi", alias="memoryRequest")
    memory_limit: str = Field(default="128Mi", alias="memoryLimit")

    model_config = {"populate_by_name": True}

    @model_validator(mode="before")
    @classmethod
    def _coerce_none_to_defaults(cls, data: Any) -> Any:
        """Handle None/missing fields from MongoDB for backward compatibility.

        - If data is None, return empty dict so Pydantic uses field defaults.
        - If cpuLimit/memoryLimit are missing, fall back to cpuRequest/memoryRequest
          so that limits are never lower than requests.
        """
        if data is None:
            return {}
        if isinstance(data, dict):
            if "cpuLimit" not in data and "cpu_limit" not in data:
                fallback = data.get("cpuRequest") or data.get("cpu_request")
                if fallback is not None:
                    data["cpuLimit"] = fallback
            if "memoryLimit" not in data and "memory_limit" not in data:
                fallback = data.get("memoryRequest") or data.get("memory_request")
                if fallback is not None:
                    data["memoryLimit"] = fallback
        return data


class KubernetesConfig(CoreBaseModel):
    """Kubernetes configuration entity."""

    name: str
    description: str | None = None
    kubeconfig: str | None = None  # Kubeconfig YAML content
    status: ConnectionStatus = ConnectionStatus.PENDING
    server: str | None = None
    deployment_config: DeploymentConfig = Field(default_factory=DeploymentConfig)
    warning_message: str | None = None  # Warning message for connection test failures

    @field_validator("status", mode="before")
    @classmethod
    def _coerce_status_enum(cls, value: Any) -> "ConnectionStatus":
        """Coerce legacy values to the simplified enum.

        - Accepts case-insensitive strings
        - Maps legacy 'Disconnected'/'Testing' variants to 'Pending'
        - Keeps 'Connected'/'Error' as-is
        """
        if isinstance(value, ConnectionStatus):
            return value
        if isinstance(value, str):
            try:
                # Try exact value match first (e.g., 'Connected', 'Pending', 'Error')
                return ConnectionStatus(value)
            except ValueError:
                upper_val = value.upper()
                mapping = {
                    "PENDING": ConnectionStatus.PENDING,
                    "CONNECTED": ConnectionStatus.CONNECTED,
                    "ERROR": ConnectionStatus.ERROR,
                    # Legacy values mapped to Pending
                    "DISCONNECTED": ConnectionStatus.PENDING,
                    "TESTING": ConnectionStatus.PENDING,
                }
                if upper_val in mapping:
                    return mapping[upper_val]
        # Let pydantic raise a proper error for invalid type/value
        return value
