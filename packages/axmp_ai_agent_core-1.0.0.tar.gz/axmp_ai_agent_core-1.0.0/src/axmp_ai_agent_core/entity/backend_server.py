"""Backend server entity."""

from typing import Any, Dict

from axmp_openapi_helper.openapi.multi_openapi_spec import AuthenticationType
from pydantic import Field

from axmp_ai_agent_core.entity.base_model import NamedCoreBaseModel


class BackendServer(NamedCoreBaseModel):
    """Backend server entity."""

    version: str = Field("1.0.0", description="Backend server version")
    description: str | None = Field(None, description="Backend server description")
    labels: Dict[str, str] | None = Field(None, description="Labels information")
    swagger_url: str | None = Field(None, description="Swagger documentation URL")
    # TODO: type should be OpenAPI
    swagger_json: Dict[str, Any] | None = Field(
        None, description="Swagger specification JSON"
    )
    domain: str = Field(..., description="Backend server domain")
    base_path: str = Field(..., description="Base API path")
    auth_type: AuthenticationType | None = Field(
        AuthenticationType.NONE, description="Authentication type"
    )
    auth_header_key: str | None = Field(None, description="Authentication header key")
    api_count: int = Field(0, description="API count")
