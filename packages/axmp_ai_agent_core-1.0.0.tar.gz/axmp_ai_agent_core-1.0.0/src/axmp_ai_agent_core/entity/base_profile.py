"""Reactflow Profile Entity. This entity is used to store the profile of the reactflow."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel, Field, field_serializer, model_validator

from axmp_ai_agent_core.agent.spec.types import (
    MCPServerType,
    NodeType,
    ProfileStatus,
    ProfileType,
    RuntimeType,
    TriggerType,
    UsageType,
)
from axmp_ai_agent_core.entity.base_model import NamedCoreBaseModel
from axmp_ai_agent_core.entity.shared_target import SharedTarget


# Edge definition
# ------------------------------------------------------------
class Edge(BaseModel):
    """Edge Entity. This entity is used to store the edge of the reactflow."""

    source: str | None = Field(None, description="The source of the edge.")
    sourceHandle: str | None = Field(None, description="The source handle of the edge.")
    target: str | None = Field(None, description="The target of the edge.")
    targetHandle: str | None = Field(None, description="The target handle of the edge.")
    strokeWidth: int = Field(2, description="The stroke width of the edge.")
    animated: bool = Field(False, description="The animation of the edge.")
    edge_type: str | None = Field(None, description="The type of the edge.")
    id: str | None = Field(None, description="The id of the edge.")
    selected: bool = Field(False, description="The selected of the edge.")


# Node definition
# ------------------------------------------------------------
class Position(BaseModel):
    """Position Entity. This entity is used to store the position of the node."""

    x: float = Field(..., description="The x coordinate of the position.")
    y: float = Field(..., description="The y coordinate of the position.")


class Measured(BaseModel):
    """Measured Entity. This entity is used to store the measured of the node."""

    width: int = Field(..., description="The width of the measured.")
    height: int = Field(..., description="The height of the measured.")


_NODE_TYPE_TO_DATA_TYPE: dict[str, str] = {
    "ai-agent": "agent",
    "sub-agent": "sub-agent",
    "llm": "llm",
    "memory": "memory",
    "skill": "skill",
}


def _inject_data_type(data: dict[str, Any]) -> dict[str, Any]:
    """Inject data_type into node data dict if missing, based on node_type."""
    if isinstance(data.get("data"), dict) and "data_type" not in data["data"]:
        node_type = data.get("node_type")
        if node_type == "trigger":
            trigger_type = data["data"].get(
                "trigger_type", TriggerType.CHATBOT
            )  # default value
            data["data"]["data_type"] = f"{trigger_type}-trigger"
        elif node_type == "mcp-server":
            resource_type = data["data"].get(
                "resource_type", MCPServerType.INTERNAL
            )  # default value
            data["data"]["data_type"] = f"{resource_type}-mcp-server"
        elif node_type in _NODE_TYPE_TO_DATA_TYPE:
            data["data"]["data_type"] = _NODE_TYPE_TO_DATA_TYPE[node_type]
    return data


class BaseNode(BaseModel):
    """BaseNode Entity. This entity is used to store the node of the reactflow.

    This is the base class for all nodes.
    """

    id: str | None = Field(None, description="The id of the node.")
    position: Position | None = Field(None, description="The position of the node.")
    measured: Measured | None = Field(None, description="The measured of the node.")
    style: Measured | None = Field(None, description="The style of the node.")
    selected: bool = Field(False, description="The selected of the node.")
    draggable: bool = Field(True, description="The draggable of the node.")
    focusable: bool = Field(True, description="The focusable of the node.")
    selectable: bool = Field(True, description="The selectable of the node.")
    dragging: bool = Field(False, description="The dragging of the node.")
    root_node: bool = Field(False, description="The root node of the node.")
    node_type: NodeType = Field(..., description="The type of the node.")

    @model_validator(mode="before")
    @classmethod
    def inject_data_type(cls, data: Any) -> Any:
        """Inject data_type for discriminated union when missing."""
        if isinstance(data, dict):
            return _inject_data_type(data)
        return data


# Flow definition
# ------------------------------------------------------------
class Viewport(BaseModel):
    """Viewport Entity. This entity is used to store the viewport of the reactflow."""

    x: float = Field(..., description="The x coordinate of the viewport.")
    y: float = Field(..., description="The y coordinate of the viewport.")
    zoom: float = Field(..., description="The zoom level of the viewport.")


class BaseFlow(BaseModel):
    """BaseFlow Entity. This entity is used to store the flow of the reactflow.

    This is the base class for all flows.
    """

    edges: list[Edge] | None = Field(None, description="The edges of the flow.")
    viewport: Viewport | None = Field(None, description="The viewport of the flow.")
    # NOTE: Following fields should be defined in the subclass
    # nodes: list[BaseNode] | None = None


# Profile definition
# ------------------------------------------------------------
class BaseProfile(ABC, NamedCoreBaseModel):
    """Reactflow Agent Profile Entity. This entity is used to store the profile of the reactflow."""

    description: str | None = Field(
        None,
        description="The description of the agent node.",
        min_length=1,
        max_length=2000,
    )
    icon_url: str | None = Field(
        None,
        description="The icon url of the agent node.",
        min_length=1,
        max_length=255,
    )
    version: int | None = Field(None, description="The version of the agent node.")
    agent_type: ProfileType = Field(
        default=ProfileType.DEEP_AGENT,
        description="The type of the agent profile.",
    )
    status: ProfileStatus = Field(
        default=ProfileStatus.DRAFT,
        description="The status of the agent profile.",
    )
    runtime_type: RuntimeType = Field(
        default=RuntimeType.WORKSPACE,
        description="The runtime type of the agent profile.",
    )
    usage_type: UsageType | None = Field(
        None,
        description="The usage type of the agent profile.",
    )
    idle_time: int | None = Field(
        None,
        description="The idle timeout of the agent instance.",
    )
    labels: dict[str, str] | None = Field(
        None, description="The labels of the agent node."
    )

    trigger_type: TriggerType | None = Field(
        None,
        description="The trigger type of the agent profile.",
    )

    is_published_to_workspace: bool | None = Field(
        None,
        description="Whether the agent profile is published to the workspace.",
    )

    shared_target: SharedTarget | None = Field(
        None,
        description="The shared target of the agent profile.",
    )

    # NOTE: Following fields should be defined in the subclass
    # flow: BaseFlow | None = None

    @field_serializer("version", when_used="json")
    def _serialize_version(self, version: int | None) -> str | None:
        if version is None:
            return None
        else:
            return f"v{version}"

    @abstractmethod
    def validate_profile_restrictions(self) -> BaseProfile:
        """Validate the profile restrictions."""
        pass

    @abstractmethod
    def get_node_by_type(self, node_type: NodeType) -> BaseNode | list[BaseNode] | None:
        """Get the agent profile node by the node type."""
        pass

    @abstractmethod
    def root_node(self) -> BaseNode | None:
        """Get the root node of the profile."""
        pass

    @abstractmethod
    def get_all_mcp_server_nodes(self) -> list[BaseNode]:
        """Get the mcp server nodes of the agent profile."""
        pass

    @abstractmethod
    def get_all_skill_nodes(self) -> list[BaseNode]:
        """Get the skill nodes of the agent profile."""
        pass
