"""Skill like entity."""

from __future__ import annotations

from pydantic import Field

from axmp_ai_agent_core.entity.base_model import CoreBaseModel


class SkillLike(CoreBaseModel):
    """Skill like — one record per user per skill."""

    skill_id: str = Field(..., description="Reference to Skill")
    username: str = Field(..., description="User who liked")
