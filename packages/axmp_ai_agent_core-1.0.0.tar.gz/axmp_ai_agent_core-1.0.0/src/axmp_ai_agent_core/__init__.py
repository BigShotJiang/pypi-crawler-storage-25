"""AI agent core framework built on LangGraph/LangChain with MCP server support."""
