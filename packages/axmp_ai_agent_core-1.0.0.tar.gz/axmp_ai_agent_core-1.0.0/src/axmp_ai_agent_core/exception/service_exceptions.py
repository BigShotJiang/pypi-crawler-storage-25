"""Exceptions for AI Agent Studio."""

from enum import Enum
from http import HTTPStatus

from fastapi import HTTPException
from pydantic import BaseModel


class Error(BaseModel):
    """Error model."""

    http_status: int | None
    code: str | None
    message: str | None


class CoreError(Enum):
    """Core error model."""

    ID_NOT_FOUND = Error(
        code="E001",
        http_status=HTTPStatus.NOT_FOUND,
        message="The item was not found. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    INVALID_OBJECTID = Error(
        code="E002",
        http_status=HTTPStatus.BAD_REQUEST,
        message="The input value was invalid. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    BAD_REQUEST = Error(
        code="E003",
        http_status=HTTPStatus.BAD_REQUEST,
        message="Bad request. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    DUPLICATE_FOUND = Error(
        code="E004",
        http_status=HTTPStatus.CONFLICT,
        message="Duplicate item found. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    PERMISSION_DENIED = Error(
        code="E005",
        http_status=HTTPStatus.FORBIDDEN,
        message="Permission denied. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    SESSION_EXPIRED = Error(
        code="E007",
        http_status=HTTPStatus.UNAUTHORIZED,
        message="The session is expired. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    RETRIEVAL_FAILED = Error(
        code="E008",
        http_status=HTTPStatus.BAD_REQUEST,
        message="Failed to retrieve data. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    INTERNAL_SERVER_ERROR = Error(
        code="E009",
        http_status=HTTPStatus.INTERNAL_SERVER_ERROR,
        message="Internal server error. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    MESSAGE_NOT_FOUND = Error(
        code="E010",
        http_status=HTTPStatus.NOT_FOUND,
        message="The message was not found. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    NOT_PUBLISHED_TO_WORKSPACE = Error(
        code="E011",
        http_status=HTTPStatus.FORBIDDEN,
        message="The agent profile is not published to the workspace. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    NO_STABLE_VERSION_FOUND = Error(
        code="E012",
        http_status=HTTPStatus.BAD_REQUEST,
        message="The agent profile has no stable version. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    SWAGGER_NOT_FOUND = Error(
        code="E013",
        http_status=HTTPStatus.NOT_FOUND,
        message="Swagger JSON not found at URL: {swagger_url}",
    )
    """The keyword argument '{swagger_url}' should be present in the message string"""

    INVALID_KUBECONFIG = Error(
        code="E014",
        http_status=HTTPStatus.BAD_REQUEST,
        message="Invalid kubeconfig format. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    KUBERNETES_CONNECTION_FAILED = Error(
        code="E015",
        http_status=HTTPStatus.BAD_REQUEST,
        message="Failed to connect to Kubernetes cluster. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    NOT_SUPPORTED = Error(
        code="E016",
        http_status=HTTPStatus.BAD_REQUEST,
        message="Not supported. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    PROVIDER_INACTIVE = Error(
        code="E017",
        http_status=HTTPStatus.CONFLICT,
        message="LLM provider is inactive. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    INCOMPLETE_DATA = Error(
        code="E018",
        http_status=HTTPStatus.CONFLICT,
        message="Incomplete data. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    PROFILE_IN_USE = Error(
        code="E019",
        http_status=HTTPStatus.CONFLICT,
        message="Profile is currently in use by provisioned instances. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    SKILL_IN_USE = Error(
        code="E020",
        http_status=HTTPStatus.CONFLICT,
        message="Skill is currently referenced by agent(s). Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""

    AGENT_NOT_FOUND = Error(
        code="E021",
        http_status=HTTPStatus.NOT_FOUND,
        message="Agent not found. Details: {details}",
    )
    """The keyword argument '{details}' should be present in the message string"""


class CoreServiceException(HTTPException):
    """Core service exception."""

    def __init__(self, error: CoreError, **kwargs):
        """Initialize the Core service exception."""
        self.status_code = error.value.http_status
        self.code = error.value.code
        self.detail = error.value.message.format(**kwargs)
        super().__init__(status_code=self.status_code, detail=self.detail)
