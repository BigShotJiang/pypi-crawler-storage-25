"""Exceptions for AI Agent Studio."""

from __future__ import annotations

import logging
from enum import Enum
from typing import Any, NoReturn

from axmp_ai_agent_core.exception.service_exceptions import (
    CoreError,
    CoreServiceException,
)


class K8sError(Enum):
    """Mapping of Kubernetes API status codes to CoreError values."""

    UNAUTHORIZED = (
        401,
        CoreError.SESSION_EXPIRED,
        {"details": "Unauthorized access to Kubernetes cluster"},
        "Unauthorized access to Kubernetes cluster: %s",
    )
    FORBIDDEN = (
        403,
        CoreError.PERMISSION_DENIED,
        {"details": "Forbidden access to Kubernetes cluster"},
        "Forbidden access to Kubernetes cluster: %s",
    )
    NOT_FOUND = (
        404,
        CoreError.ID_NOT_FOUND,
        {
            "document": "Kubernetes API endpoint",
            "object_id": "cluster",
        },
        "Kubernetes API endpoint not found: %s",
    )
    OTHER = (
        None,
        CoreError.INTERNAL_SERVER_ERROR,
        {"details": "Kubernetes API error."},
        "Kubernetes API error: %s",
    )

    @property
    def status_code(self) -> int | None:
        """Return mapped HTTP status code."""
        return self.value[0]

    @property
    def studio_error(self) -> CoreError:
        """Return corresponding CoreError."""
        return self.value[1]

    @property
    def default_kwargs(self) -> dict[str, Any]:
        """Return default keyword arguments for the exception."""
        return dict(self.value[2])

    @property
    def log_message(self) -> str:
        """Return default log message template for this error."""
        return self.value[3]

    @classmethod
    def from_status_code(cls, status_code: int) -> K8sError:
        """Return enum entry matching status_code, defaulting to OTHER."""
        for item in cls:
            if item.status_code == status_code:
                return item
        return cls.OTHER


def raise_k8s_backend_exception(
    *, logger: logging.Logger, error: Any, log_level: str = "error"
) -> NoReturn:
    """Raise StudioBackendException mapped from Kubernetes ApiException."""
    status = getattr(error, "status", None)
    k8s_error = K8sError.from_status_code(status)

    log_callable = getattr(logger, log_level, logger.error)
    log_callable(k8s_error.log_message, error)

    raise CoreServiceException(
        k8s_error.studio_error,
        **k8s_error.default_kwargs,
    ) from error
