"""Standardized error definitions and custom exception classes."""
