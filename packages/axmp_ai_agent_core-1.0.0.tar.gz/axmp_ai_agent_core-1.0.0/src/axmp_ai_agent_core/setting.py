"""Base settings for AI Agent Studio."""

from functools import lru_cache
from typing import Literal

from pydantic_settings import BaseSettings, SettingsConfigDict


class AIServiceKeySettings(BaseSettings):
    """Settings for AIServiceKey."""

    model_config: SettingsConfigDict = SettingsConfigDict(
        env_file=".env", extra="ignore"
    )
    openai_api_key: str | None = None
    anthropic_api_key: str | None = None


ai_service_key_settings = AIServiceKeySettings()


@lru_cache(maxsize=1)
def get_ai_service_key_settings() -> AIServiceKeySettings:
    """Get AI service key settings."""
    return AIServiceKeySettings()


class CoreSettings(BaseSettings):
    """Settings for AI Agent Core."""

    model_config: SettingsConfigDict = SettingsConfigDict(
        env_prefix="CORE_", env_file=".env", extra="ignore"
    )

    domain: str = "0.0.0.0"
    api_endpoint: str
    web_endpoint: str
    default_model: str = "openai/gpt-4.1-mini"
    default_model_max_tokens: int = 5000
    recursion_limit: int = 30
    stream_mode: Literal["messages", "values", "updates"] = "messages"
    temperature: float = 0
    csrf_safe_methods: str = "GET;HEAD;OPTIONS;TRACE;POST;PUT;DELETE;PATCH"
    python_path: str = "/application/.venv/bin/python"
    mcp_connection_timeout: float = 30.0
    image_max_size_mb: int = 3
    pdf_max_size_mb: int = 10
    image_path: str = "/application/public/images"
    default_image_path: str = "/application/public/default-images"
    image_server_endpoint: str = "http://0.0.0.0:7700/images"
    agent_icon_path: str = "/agent/agent.png"
    mcp_server_icon_path: str = "/mcp-server/mcp.png"
    skill_icon_path: str = "/skill/default/skill.png"
    axmp_provision_target_label: str = "platform.axmp/target=instance"
    mcp_server_separator: str = "---"
    agent_cache_ttl: int = 3600
    agent_cache_max_size: int = 100
    agent_cache_cleanup_interval: int = 60
    agent_skills_path: str = "/application/agent/.skills"
    skill_history_max_count: int = 20
    data_path: str = "/application/data"
    mcp_oauth_login_url: str
    mcp_oauth_callback_redirect_uris: list[str]
    mcp_oauth_client_name: str = "NPO MCP Client"
    mcp_oauth_encryption_key: str
    mcp_oauth_redis_collection: str = "mcp-oauth-client-tokens"  # NOTE: This is not used in the current implementation.
    mcp_dcr_client_info_collection: str = "mcp-dcr-client-info"
    mcp_oauth_pending_flows_collection: str = "mcp-oauth-pending-flows"
    mcp_oauth_discovery_cache_collection: str = "mcp-oauth-discovery-cache"
    mcp_oauth_servers_collection: str = "mcp-oauth-servers"
    prompts_dir: str = ""

    # Skill Assistant — Thread 관리
    skill_assistant_thread_ttl: int = 1800
    skill_assistant_max_threads: int = 100
    skill_assistant_cleanup_interval: int = 60
    skill_assistant_max_turns: int = 20

    # Skill Assistant — LLM 설정
    skill_assistant_llm_provider: str = "openai"
    skill_assistant_llm_model: str = "gpt-4o"
    skill_assistant_llm_api_key: str = ""
    skill_assistant_llm_base_url: str | None = None
    skill_assistant_llm_temperature: float = 0.7
    skill_assistant_llm_max_tokens: int = 5000

    # K8s sync scheduler settings
    k8s_sync_enabled: bool = False
    k8s_sync_interval_seconds: int = 300  # Default 5 minutes

    http_ssl_verify: bool = True


core_settings = CoreSettings()


@lru_cache(maxsize=1)
def get_core_settings() -> CoreSettings:
    """Get core settings."""
    return CoreSettings()


class MongoDBSettings(BaseSettings):
    """Settings for MongoDB."""

    model_config: SettingsConfigDict = SettingsConfigDict(
        env_prefix="MONGODB_", env_file=".env", extra="ignore"
    )

    hostname: str
    port: int
    username: str
    password: str
    database: str
    connection_timeout_ms: int = 5000
    heartbeat_frequency_ms: int = 10000
    retry_writes: bool = True
    retry_reads: bool = True
    direct_connection: bool = False

    @property
    def uri(self) -> str:
        """Get MongoDB connection URI."""
        return f"mongodb://{self.username}:{self.password}@{self.hostname}:{self.port}/{self.database}"


mongodb_settings = MongoDBSettings()


@lru_cache(maxsize=1)
def get_mongodb_settings() -> MongoDBSettings:
    """Get MongoDB settings."""
    return MongoDBSettings()


class S3Settings(BaseSettings):
    """Settings for AWS S3."""

    model_config: SettingsConfigDict = SettingsConfigDict(
        env_prefix="AWS_", env_file=".env", extra="ignore"
    )
    access_key_id: str
    secret_access_key: str
    default_region: str
    s3_bucket_name: str
    s3_bucket_root: str


s3_settings = S3Settings()


@lru_cache(maxsize=1)
def get_s3_settings() -> S3Settings:
    """Get S3 settings."""
    return S3Settings()


class PostgreSQLSettings(BaseSettings):
    """Settings for PostgreSQL."""

    model_config: SettingsConfigDict = SettingsConfigDict(
        env_prefix="POSTGRESQL_", env_file=".env", extra="ignore"
    )

    hostname: str
    port: int
    username: str
    password: str
    database: str
    # Connection timeout settings
    connect_timeout: int = 10
    # TCP keepalive settings
    tcp_keepalives_idle: int = 600  # 10 minutes
    tcp_keepalives_interval: int = 30  # 30 seconds
    tcp_keepalives_count: int = 3
    # SSL settings
    sslmode: str = "prefer"
    # Application name for connection identification
    application_name: str = "axmp-ai-agent-core"
    # Connection pool settings
    pool_min_size: int = 1
    pool_max_size: int = 5

    @property
    def db_uri(self) -> str:
        """Return the connection string for the PostgreSQL database."""
        return f"postgresql://{self.username}:{self.password}@{self.hostname}:{self.port}/{self.database}"

    @property
    def db_uri_with_params(self) -> str:
        """Return the connection string with additional parameters for connection stability."""
        params = [
            f"connect_timeout={self.connect_timeout}",
            f"sslmode={self.sslmode}",
            f"application_name={self.application_name}",
            f"keepalives_idle={self.tcp_keepalives_idle}",
            f"keepalives_interval={self.tcp_keepalives_interval}",
            f"keepalives_count={self.tcp_keepalives_count}",
        ]

        param_string = "&".join(params)
        return f"{self.db_uri}?{param_string}"


postgresql_settings = PostgreSQLSettings()


@lru_cache(maxsize=1)
def get_postgresql_settings() -> PostgreSQLSettings:
    """Get PostgreSQL settings."""
    return PostgreSQLSettings()


class McpServerSettings(BaseSettings):
    """Settings for MCP Server."""

    model_config: SettingsConfigDict = SettingsConfigDict(
        env_prefix="ZMP_MCP_SERVER_", env_file=".env", extra="ignore"
    )

    image: str = "zcr.cloudzcp.net/cloudzcp/axmp-openapi-mcp-server"
    image_tag: str = "latest"
    image_pull_secrets: str = "zcr-cloudzcp-net-robot-secret"
    namespace: str = "axmp-system"

    @property
    def full_image(self) -> str:
        """Get full image name with tag."""
        return f"{self.image}:{self.image_tag}"


mcp_server_settings = McpServerSettings()


@lru_cache(maxsize=1)
def get_mcp_server_settings() -> McpServerSettings:
    """Get MCP server settings."""
    return McpServerSettings()


class AgentSettings(BaseSettings):
    """Settings for AI Agent."""

    model_config: SettingsConfigDict = SettingsConfigDict(
        env_prefix="ZMP_AGENT_", env_file=".env", extra="ignore"
    )

    image: str = "zcr.cloudzcp.net/cloudzcp/axmp-ai-agent"
    image_tag: str = "latest"
    image_pull_secrets: str = "zcr-cloudzcp-net-robot-secret"
    namespace: str = "axmp-system"

    @property
    def full_image(self) -> str:
        """Get full image name with tag."""
        return f"{self.image}:{self.image_tag}"


agent_settings = AgentSettings()


@lru_cache(maxsize=1)
def get_agent_settings() -> AgentSettings:
    """Get agent settings."""
    return AgentSettings()
