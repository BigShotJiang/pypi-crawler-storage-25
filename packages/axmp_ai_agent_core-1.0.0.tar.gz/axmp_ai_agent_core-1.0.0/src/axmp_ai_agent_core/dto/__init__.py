"""Data transfer objects for API response envelopes."""
