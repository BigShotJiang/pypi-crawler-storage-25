from __future__ import annotations

import json
import re
import shutil
import sys
from pathlib import Path

import pytest

from tests.cli_support import run_cli

from stipul.cli import demo_cmd


def _session_dir_from_output(stdout: str) -> Path:
    match = re.search(
        r"^\s*stipul verify (?P<session>.+)$",
        stdout,
        re.MULTILINE,
    )
    assert match is not None
    return Path(match.group("session").strip())


def test_demo_proof_prints_verified_receipt_and_tamper_payoff() -> None:
    result = run_cli("demo", "proof")

    assert result.returncode == 0
    assert "\033[" not in result.stdout
    assert "reason: allowed_tool" in result.stdout
    assert "Trust: VERIFIED" in result.stdout
    assert "  Chain: INTACT" in result.stdout
    assert "  Seal:  VALID" in result.stdout
    assert "  Decisions: 3" in result.stdout
    assert "Step 1 — View the current seal:" in result.stdout
    assert "Step 2 — Verify the session as-is:" in result.stdout
    assert "Step 3 — Now tamper with the seal:" in result.stdout
    assert "Step 4 — Re-verify the session:" in result.stdout
    assert "Watch Trust: VERIFIED become Trust: REJECTED." not in result.stdout
    assert "Proof complete" in result.stdout

    session_dir = _session_dir_from_output(result.stdout)
    seal_path = session_dir / "seal.json"

    try:
        session_match = re.search(
            r"^Session: (?P<session_id>[0-9a-f-]{36})$",
            result.stdout,
            re.MULTILINE,
        )
        assert session_match is not None
        session_id = session_match.group("session_id")

        assert session_dir.is_absolute()
        assert session_dir.exists()
        assert seal_path.exists()
        assert str(seal_path) in result.stdout
        assert f"  Fingerprint: {session_id} | INTACT | VALID | 3 decisions | " in result.stdout

        seal_payload = json.loads(seal_path.read_text(encoding="utf-8"))
        assert (
            f"sed -i 's/\"terminal_sequence_id\": {seal_payload['terminal_sequence_id']}"
            f"/\"terminal_sequence_id\": 999/' {seal_path}"
        ) in result.stdout
        assert f"sed -i 's/\"version\": 1/\"version\": 42/' {seal_path}" in result.stdout
        seal_payload["terminal_sequence_id"] = 999
        seal_path.write_text(
            json.dumps(seal_payload, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

        verify_result = run_cli("verify", str(session_dir))

        assert verify_result.returncode == 2
        assert "Trust: REJECTED" in verify_result.stdout
        assert "Chain: INTACT" in verify_result.stdout
        assert "Seal: INVALID" in verify_result.stdout
    finally:
        shutil.rmtree(session_dir.parent, ignore_errors=True)


def test_demo_proof_session_id_is_real_uuid() -> None:
    import uuid as _uuid

    result = run_cli("demo", "proof")
    assert result.returncode == 0
    session_dir = _session_dir_from_output(result.stdout)
    try:
        first_line = (session_dir / "events.jsonl").read_text(encoding="utf-8").splitlines()[0]
        session_id = json.loads(first_line)["session_id"]
        parsed = _uuid.UUID(session_id)
        assert session_id != "11111111-1111-1111-1111-111111111111"
        assert parsed.version == 4
        assert str(parsed) == session_id
    finally:
        shutil.rmtree(session_dir.parent, ignore_errors=True)


def test_demo_proof_trust_block_colorizes_values_for_tty(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    class _TTY:
        def isatty(self) -> bool:
            return True

    session_dir = tmp_path / "session"
    session_dir.mkdir()
    with demo_cmd._demo_charter_path() as charter_path:
        demo_cmd._run_proof_session(session_dir, charter_path)

    monkeypatch.setattr(sys, "stdout", _TTY())
    output = demo_cmd._render_output(session_dir)

    assert "Trust: \033[32mVERIFIED\033[0m" in output
    assert "  Chain: \033[32mINTACT\033[0m" in output
    assert "  Seal:  \033[32mVALID\033[0m" in output
