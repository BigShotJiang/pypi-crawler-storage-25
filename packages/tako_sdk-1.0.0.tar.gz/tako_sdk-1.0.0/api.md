# Search

Types:

```python
from tako.types import OutputSettings, Results, SourceIndex, SourceIndexSegment
```

Methods:

- <code title="post /v1/knowledge_search">client.search.<a href="./src/tako/resources/search.py">create</a>(\*\*<a href="src/tako/types/search_create_params.py">params</a>) -> <a href="./src/tako/types/results.py">Results</a></code>

# Images

Methods:

- <code title="get /v1/image/{pub_id}/">client.images.<a href="./src/tako/resources/images.py">retrieve</a>(pub_id, \*\*<a href="src/tako/types/image_retrieve_params.py">params</a>) -> BinaryAPIResponse</code>

# Beta

Types:

```python
from tako.types import BetaGetFileUploadURLResponse
```

Methods:

- <code title="get /v1/beta/file_upload_url">client.beta.<a href="./src/tako/resources/beta/beta.py">get_file_upload_url</a>(\*\*<a href="src/tako/types/beta_get_file_upload_url_params.py">params</a>) -> <a href="./src/tako/types/beta_get_file_upload_url_response.py">BetaGetFileUploadURLResponse</a></code>

## Visualize

Types:

```python
from tako.types.beta import VisualizeRequest
```

Methods:

- <code title="post /v1/beta/visualize">client.beta.visualize.<a href="./src/tako/resources/beta/visualize.py">create</a>(\*\*<a href="src/tako/types/beta/visualize_create_params.py">params</a>) -> <a href="./src/tako/types/results.py">Results</a></code>

## FileConnector

Types:

```python
from tako.types.beta import (
    FileConnectorMetadata,
    FileConnectorCreateResponse,
    FileConnectorListResponse,
)
```

Methods:

- <code title="post /v1/beta/file_connector">client.beta.file_connector.<a href="./src/tako/resources/beta/file_connector.py">create</a>(\*\*<a href="src/tako/types/beta/file_connector_create_params.py">params</a>) -> <a href="./src/tako/types/beta/file_connector_create_response.py">FileConnectorCreateResponse</a></code>
- <code title="get /v1/beta/file_connector">client.beta.file_connector.<a href="./src/tako/resources/beta/file_connector.py">list</a>(\*\*<a href="src/tako/types/beta/file_connector_list_params.py">params</a>) -> <a href="./src/tako/types/beta/file_connector_list_response.py">FileConnectorListResponse</a></code>

## Files

Types:

```python
from tako.types.beta import FileRetrieveResponse, FileUpdateResponse
```

Methods:

- <code title="get /v1/beta/files/{file_id}/">client.beta.files.<a href="./src/tako/resources/beta/files.py">retrieve</a>(file_id) -> <a href="./src/tako/types/beta/file_retrieve_response.py">FileRetrieveResponse</a></code>
- <code title="patch /v1/beta/files/{file_id}/">client.beta.files.<a href="./src/tako/resources/beta/files.py">update</a>(file_id, \*\*<a href="src/tako/types/beta/file_update_params.py">params</a>) -> <a href="./src/tako/types/beta/file_update_response.py">FileUpdateResponse</a></code>
- <code title="delete /v1/beta/files/{file_id}/">client.beta.files.<a href="./src/tako/resources/beta/files.py">delete</a>(file_id) -> None</code>

# Agents

Types:

```python
from tako.types import AgentGetStatusResponse
```

Methods:

- <code title="get /v1/agents/status">client.agents.<a href="./src/tako/resources/agents.py">get_status</a>(\*\*<a href="src/tako/types/agent_get_status_params.py">params</a>) -> <a href="./src/tako/types/agent_get_status_response.py">AgentGetStatusResponse</a></code>
