# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import httpx
import pytest
from respx import MockRouter

from tako import Tako, AsyncTako
from tako._response import (
    BinaryAPIResponse,
    AsyncBinaryAPIResponse,
    StreamedBinaryAPIResponse,
    AsyncStreamedBinaryAPIResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestImages:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_retrieve(self, client: Tako, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/image/pub_id/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        image = client.images.retrieve(
            pub_id="pub_id",
        )
        assert image.is_closed
        assert image.json() == {"foo": "bar"}
        assert cast(Any, image.is_closed) is True
        assert isinstance(image, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_method_retrieve_with_all_params(self, client: Tako, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/image/pub_id/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        image = client.images.retrieve(
            pub_id="pub_id",
            dark_mode=True,
            height=0,
            hide_footer=True,
            width=0,
        )
        assert image.is_closed
        assert image.json() == {"foo": "bar"}
        assert cast(Any, image.is_closed) is True
        assert isinstance(image, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_raw_response_retrieve(self, client: Tako, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/image/pub_id/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        image = client.images.with_raw_response.retrieve(
            pub_id="pub_id",
        )

        assert image.is_closed is True
        assert image.http_request.headers.get("X-Stainless-Lang") == "python"
        assert image.json() == {"foo": "bar"}
        assert isinstance(image, BinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_streaming_response_retrieve(self, client: Tako, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/image/pub_id/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        with client.images.with_streaming_response.retrieve(
            pub_id="pub_id",
        ) as image:
            assert not image.is_closed
            assert image.http_request.headers.get("X-Stainless-Lang") == "python"

            assert image.json() == {"foo": "bar"}
            assert cast(Any, image.is_closed) is True
            assert isinstance(image, StreamedBinaryAPIResponse)

        assert cast(Any, image.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    def test_path_params_retrieve(self, client: Tako) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `pub_id` but received ''"):
            client.images.with_raw_response.retrieve(
                pub_id="",
            )


class TestAsyncImages:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_retrieve(self, async_client: AsyncTako, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/image/pub_id/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        image = await async_client.images.retrieve(
            pub_id="pub_id",
        )
        assert image.is_closed
        assert await image.json() == {"foo": "bar"}
        assert cast(Any, image.is_closed) is True
        assert isinstance(image, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_method_retrieve_with_all_params(self, async_client: AsyncTako, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/image/pub_id/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        image = await async_client.images.retrieve(
            pub_id="pub_id",
            dark_mode=True,
            height=0,
            hide_footer=True,
            width=0,
        )
        assert image.is_closed
        assert await image.json() == {"foo": "bar"}
        assert cast(Any, image.is_closed) is True
        assert isinstance(image, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_raw_response_retrieve(self, async_client: AsyncTako, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/image/pub_id/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))

        image = await async_client.images.with_raw_response.retrieve(
            pub_id="pub_id",
        )

        assert image.is_closed is True
        assert image.http_request.headers.get("X-Stainless-Lang") == "python"
        assert await image.json() == {"foo": "bar"}
        assert isinstance(image, AsyncBinaryAPIResponse)

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_streaming_response_retrieve(self, async_client: AsyncTako, respx_mock: MockRouter) -> None:
        respx_mock.get("/v1/image/pub_id/").mock(return_value=httpx.Response(200, json={"foo": "bar"}))
        async with async_client.images.with_streaming_response.retrieve(
            pub_id="pub_id",
        ) as image:
            assert not image.is_closed
            assert image.http_request.headers.get("X-Stainless-Lang") == "python"

            assert await image.json() == {"foo": "bar"}
            assert cast(Any, image.is_closed) is True
            assert isinstance(image, AsyncStreamedBinaryAPIResponse)

        assert cast(Any, image.is_closed) is True

    @parametrize
    @pytest.mark.respx(base_url=base_url)
    async def test_path_params_retrieve(self, async_client: AsyncTako) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `pub_id` but received ''"):
            await async_client.images.with_raw_response.retrieve(
                pub_id="",
            )
