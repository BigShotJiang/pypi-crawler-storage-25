# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tako import Tako, AsyncTako
from tako.types import BetaGetFileUploadURLResponse
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestBeta:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_file_upload_url(self, client: Tako) -> None:
        beta = client.beta.get_file_upload_url(
            file_name="file_name",
        )
        assert_matches_type(BetaGetFileUploadURLResponse, beta, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_file_upload_url_with_all_params(self, client: Tako) -> None:
        beta = client.beta.get_file_upload_url(
            file_name="file_name",
            display_name="display_name",
            file_context="file_context",
            source="source",
        )
        assert_matches_type(BetaGetFileUploadURLResponse, beta, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get_file_upload_url(self, client: Tako) -> None:
        response = client.beta.with_raw_response.get_file_upload_url(
            file_name="file_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        beta = response.parse()
        assert_matches_type(BetaGetFileUploadURLResponse, beta, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get_file_upload_url(self, client: Tako) -> None:
        with client.beta.with_streaming_response.get_file_upload_url(
            file_name="file_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            beta = response.parse()
            assert_matches_type(BetaGetFileUploadURLResponse, beta, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncBeta:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_file_upload_url(self, async_client: AsyncTako) -> None:
        beta = await async_client.beta.get_file_upload_url(
            file_name="file_name",
        )
        assert_matches_type(BetaGetFileUploadURLResponse, beta, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_file_upload_url_with_all_params(self, async_client: AsyncTako) -> None:
        beta = await async_client.beta.get_file_upload_url(
            file_name="file_name",
            display_name="display_name",
            file_context="file_context",
            source="source",
        )
        assert_matches_type(BetaGetFileUploadURLResponse, beta, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get_file_upload_url(self, async_client: AsyncTako) -> None:
        response = await async_client.beta.with_raw_response.get_file_upload_url(
            file_name="file_name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        beta = await response.parse()
        assert_matches_type(BetaGetFileUploadURLResponse, beta, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get_file_upload_url(self, async_client: AsyncTako) -> None:
        async with async_client.beta.with_streaming_response.get_file_upload_url(
            file_name="file_name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            beta = await response.parse()
            assert_matches_type(BetaGetFileUploadURLResponse, beta, path=["response"])

        assert cast(Any, response.is_closed) is True
