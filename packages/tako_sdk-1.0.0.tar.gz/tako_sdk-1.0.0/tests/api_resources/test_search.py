# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tako import Tako, AsyncTako
from tako.types import Results
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestSearch:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Tako) -> None:
        search = client.search.create(
            inputs={},
        )
        assert_matches_type(Results, search, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Tako) -> None:
        search = client.search.create(
            inputs={
                "count": 0,
                "current_view": "current_view",
                "question": "question",
                "text": "text",
                "x_file_source_ids": [
                    {
                        "file_id": "file_id",
                        "file_context": "file_context",
                        "ontology_context": "ontology_context",
                        "private_index_id": "private_index_id",
                        "segment_id": "segment_id",
                    }
                ],
            },
            country_code="country_code",
            locale="locale",
            output_settings={"knowledge_card_settings": {"image_dark_mode": True}},
            search_effort="fast",
            source_indexes=["tako"],
        )
        assert_matches_type(Results, search, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Tako) -> None:
        response = client.search.with_raw_response.create(
            inputs={},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        search = response.parse()
        assert_matches_type(Results, search, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Tako) -> None:
        with client.search.with_streaming_response.create(
            inputs={},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            search = response.parse()
            assert_matches_type(Results, search, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncSearch:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncTako) -> None:
        search = await async_client.search.create(
            inputs={},
        )
        assert_matches_type(Results, search, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncTako) -> None:
        search = await async_client.search.create(
            inputs={
                "count": 0,
                "current_view": "current_view",
                "question": "question",
                "text": "text",
                "x_file_source_ids": [
                    {
                        "file_id": "file_id",
                        "file_context": "file_context",
                        "ontology_context": "ontology_context",
                        "private_index_id": "private_index_id",
                        "segment_id": "segment_id",
                    }
                ],
            },
            country_code="country_code",
            locale="locale",
            output_settings={"knowledge_card_settings": {"image_dark_mode": True}},
            search_effort="fast",
            source_indexes=["tako"],
        )
        assert_matches_type(Results, search, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncTako) -> None:
        response = await async_client.search.with_raw_response.create(
            inputs={},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        search = await response.parse()
        assert_matches_type(Results, search, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncTako) -> None:
        async with async_client.search.with_streaming_response.create(
            inputs={},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            search = await response.parse()
            assert_matches_type(Results, search, path=["response"])

        assert cast(Any, response.is_closed) is True
