# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tako import Tako, AsyncTako
from tako.types import Results
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestVisualize:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Tako) -> None:
        visualize = client.beta.visualize.create()
        assert_matches_type(Results, visualize, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Tako) -> None:
        visualize = client.beta.visualize.create(
            connected_private_index_id="connected_private_index_id",
            csv=["string"],
            file_id="file_id",
            file_ids=["string"],
            output_settings={"knowledge_card_settings": {"image_dark_mode": True}},
            query="query",
            segment_id="segment_id",
            viz_component_type="bar",
        )
        assert_matches_type(Results, visualize, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Tako) -> None:
        response = client.beta.visualize.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        visualize = response.parse()
        assert_matches_type(Results, visualize, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Tako) -> None:
        with client.beta.visualize.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            visualize = response.parse()
            assert_matches_type(Results, visualize, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncVisualize:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncTako) -> None:
        visualize = await async_client.beta.visualize.create()
        assert_matches_type(Results, visualize, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncTako) -> None:
        visualize = await async_client.beta.visualize.create(
            connected_private_index_id="connected_private_index_id",
            csv=["string"],
            file_id="file_id",
            file_ids=["string"],
            output_settings={"knowledge_card_settings": {"image_dark_mode": True}},
            query="query",
            segment_id="segment_id",
            viz_component_type="bar",
        )
        assert_matches_type(Results, visualize, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncTako) -> None:
        response = await async_client.beta.visualize.with_raw_response.create()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        visualize = await response.parse()
        assert_matches_type(Results, visualize, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncTako) -> None:
        async with async_client.beta.visualize.with_streaming_response.create() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            visualize = await response.parse()
            assert_matches_type(Results, visualize, path=["response"])

        assert cast(Any, response.is_closed) is True
