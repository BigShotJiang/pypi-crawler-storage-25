# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tako import Tako, AsyncTako
from tests.utils import assert_matches_type
from tako.types.beta import (
    FileConnectorListResponse,
    FileConnectorCreateResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestFileConnector:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Tako) -> None:
        file_connector = client.beta.file_connector.create(
            file_url="file_url",
        )
        assert_matches_type(FileConnectorCreateResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Tako) -> None:
        file_connector = client.beta.file_connector.create(
            file_url="file_url",
            connected_private_index_id="connected_private_index_id",
            display_name="display_name",
            file_context="file_context",
            file_id="file_id",
            generate_ontology=True,
            link_world_ontology=True,
            prepend_schema_context=True,
            segment_id="segment_id",
            source="source",
        )
        assert_matches_type(FileConnectorCreateResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Tako) -> None:
        response = client.beta.file_connector.with_raw_response.create(
            file_url="file_url",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file_connector = response.parse()
        assert_matches_type(FileConnectorCreateResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Tako) -> None:
        with client.beta.file_connector.with_streaming_response.create(
            file_url="file_url",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file_connector = response.parse()
            assert_matches_type(FileConnectorCreateResponse, file_connector, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list(self, client: Tako) -> None:
        file_connector = client.beta.file_connector.list()
        assert_matches_type(FileConnectorListResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Tako) -> None:
        file_connector = client.beta.file_connector.list(
            file_id="file_id",
        )
        assert_matches_type(FileConnectorListResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Tako) -> None:
        response = client.beta.file_connector.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file_connector = response.parse()
        assert_matches_type(FileConnectorListResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Tako) -> None:
        with client.beta.file_connector.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file_connector = response.parse()
            assert_matches_type(FileConnectorListResponse, file_connector, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncFileConnector:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncTako) -> None:
        file_connector = await async_client.beta.file_connector.create(
            file_url="file_url",
        )
        assert_matches_type(FileConnectorCreateResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncTako) -> None:
        file_connector = await async_client.beta.file_connector.create(
            file_url="file_url",
            connected_private_index_id="connected_private_index_id",
            display_name="display_name",
            file_context="file_context",
            file_id="file_id",
            generate_ontology=True,
            link_world_ontology=True,
            prepend_schema_context=True,
            segment_id="segment_id",
            source="source",
        )
        assert_matches_type(FileConnectorCreateResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncTako) -> None:
        response = await async_client.beta.file_connector.with_raw_response.create(
            file_url="file_url",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file_connector = await response.parse()
        assert_matches_type(FileConnectorCreateResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncTako) -> None:
        async with async_client.beta.file_connector.with_streaming_response.create(
            file_url="file_url",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file_connector = await response.parse()
            assert_matches_type(FileConnectorCreateResponse, file_connector, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncTako) -> None:
        file_connector = await async_client.beta.file_connector.list()
        assert_matches_type(FileConnectorListResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncTako) -> None:
        file_connector = await async_client.beta.file_connector.list(
            file_id="file_id",
        )
        assert_matches_type(FileConnectorListResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncTako) -> None:
        response = await async_client.beta.file_connector.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        file_connector = await response.parse()
        assert_matches_type(FileConnectorListResponse, file_connector, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncTako) -> None:
        async with async_client.beta.file_connector.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            file_connector = await response.parse()
            assert_matches_type(FileConnectorListResponse, file_connector, path=["response"])

        assert cast(Any, response.is_closed) is True
