# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import Literal

import httpx

from ..types import search_create_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.results import Results
from ..types.output_settings_param import OutputSettingsParam

__all__ = ["SearchResource", "AsyncSearchResource"]


class SearchResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> SearchResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return SearchResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SearchResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return SearchResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        inputs: search_create_params.Inputs,
        country_code: str | Omit = omit,
        locale: str | Omit = omit,
        output_settings: Optional[OutputSettingsParam] | Omit = omit,
        search_effort: Optional[Literal["fast", "medium", "deep", "auto"]] | Omit = omit,
        source_indexes: Optional[Iterable[search_create_params.SourceIndex]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Results:
        """
        Search for knowledge

        Args:
          country_code: ISO3166-1 alpha-2 country code (e.g., 'US', 'CA', 'GB')

          locale: ISO 639-1 language code (e.g., 'en', 'es', 'fr')

          output_settings: Settings for controlling outputs of the knowledge search request

          search_effort: Effort level for the search.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/knowledge_search",
            body=maybe_transform(
                {
                    "inputs": inputs,
                    "country_code": country_code,
                    "locale": locale,
                    "output_settings": output_settings,
                    "search_effort": search_effort,
                    "source_indexes": source_indexes,
                },
                search_create_params.SearchCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Results,
        )


class AsyncSearchResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncSearchResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncSearchResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSearchResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return AsyncSearchResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        inputs: search_create_params.Inputs,
        country_code: str | Omit = omit,
        locale: str | Omit = omit,
        output_settings: Optional[OutputSettingsParam] | Omit = omit,
        search_effort: Optional[Literal["fast", "medium", "deep", "auto"]] | Omit = omit,
        source_indexes: Optional[Iterable[search_create_params.SourceIndex]] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Results:
        """
        Search for knowledge

        Args:
          country_code: ISO3166-1 alpha-2 country code (e.g., 'US', 'CA', 'GB')

          locale: ISO 639-1 language code (e.g., 'en', 'es', 'fr')

          output_settings: Settings for controlling outputs of the knowledge search request

          search_effort: Effort level for the search.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/knowledge_search",
            body=await async_maybe_transform(
                {
                    "inputs": inputs,
                    "country_code": country_code,
                    "locale": locale,
                    "output_settings": output_settings,
                    "search_effort": search_effort,
                    "source_indexes": source_indexes,
                },
                search_create_params.SearchCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Results,
        )


class SearchResourceWithRawResponse:
    def __init__(self, search: SearchResource) -> None:
        self._search = search

        self.create = to_raw_response_wrapper(
            search.create,
        )


class AsyncSearchResourceWithRawResponse:
    def __init__(self, search: AsyncSearchResource) -> None:
        self._search = search

        self.create = async_to_raw_response_wrapper(
            search.create,
        )


class SearchResourceWithStreamingResponse:
    def __init__(self, search: SearchResource) -> None:
        self._search = search

        self.create = to_streamed_response_wrapper(
            search.create,
        )


class AsyncSearchResourceWithStreamingResponse:
    def __init__(self, search: AsyncSearchResource) -> None:
        self._search = search

        self.create = async_to_streamed_response_wrapper(
            search.create,
        )
