# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
#
# Hand-written additions: tako_data property, reconnect()

from __future__ import annotations

import httpx

from ..types import agent_get_status_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._streaming import Stream, AsyncStream
from .._base_client import make_request_options
from ..lib.streaming import AgentStreamEvent
from ..lib.tako_data import (
    TakoDataResource,
    AsyncTakoDataResource,
    reconnect as _reconnect,
    async_reconnect as _async_reconnect,
)
from ..types.agent_get_status_response import AgentGetStatusResponse

__all__ = ["AgentsResource", "AsyncAgentsResource"]


class AgentsResource(SyncAPIResource):
    @cached_property
    def tako_data(self) -> TakoDataResource:
        return TakoDataResource(self._client)

    @cached_property
    def with_raw_response(self) -> AgentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return AgentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AgentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return AgentsResourceWithStreamingResponse(self)

    def get_status(
        self,
        *,
        task_id: str,
        since_index: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AgentGetStatusResponse:
        """
        Poll for the status of an async agent task.

        Args:
          task_id: UUID of the async task

          since_index: Return events starting from this index (0-based)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/agents/status",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "task_id": task_id,
                        "since_index": since_index,
                    },
                    agent_get_status_params.AgentGetStatusParams,
                ),
            ),
            cast_to=AgentGetStatusResponse,
        )

    def reconnect(
        self,
        task_id: str,
        *,
        last_seq: int = -1,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Stream[AgentStreamEvent]:
        """Reconnect to an agent task's event stream."""
        return _reconnect(self, task_id, last_seq=last_seq, extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout)


class AsyncAgentsResource(AsyncAPIResource):
    @cached_property
    def tako_data(self) -> AsyncTakoDataResource:
        return AsyncTakoDataResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncAgentsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncAgentsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncAgentsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return AsyncAgentsResourceWithStreamingResponse(self)

    async def get_status(
        self,
        *,
        task_id: str,
        since_index: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AgentGetStatusResponse:
        """
        Poll for the status of an async agent task.

        Args:
          task_id: UUID of the async task

          since_index: Return events starting from this index (0-based)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/agents/status",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "task_id": task_id,
                        "since_index": since_index,
                    },
                    agent_get_status_params.AgentGetStatusParams,
                ),
            ),
            cast_to=AgentGetStatusResponse,
        )

    async def reconnect(
        self,
        task_id: str,
        *,
        last_seq: int = -1,
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncStream[AgentStreamEvent]:
        """Reconnect to an agent task's event stream."""
        return await _async_reconnect(self, task_id, last_seq=last_seq, extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout)


class AgentsResourceWithRawResponse:
    def __init__(self, agents: AgentsResource) -> None:
        self._agents = agents

        self.get_status = to_raw_response_wrapper(
            agents.get_status,
        )


class AsyncAgentsResourceWithRawResponse:
    def __init__(self, agents: AsyncAgentsResource) -> None:
        self._agents = agents

        self.get_status = async_to_raw_response_wrapper(
            agents.get_status,
        )


class AgentsResourceWithStreamingResponse:
    def __init__(self, agents: AgentsResource) -> None:
        self._agents = agents

        self.get_status = to_streamed_response_wrapper(
            agents.get_status,
        )


class AsyncAgentsResourceWithStreamingResponse:
    def __init__(self, agents: AsyncAgentsResource) -> None:
        self._agents = agents

        self.get_status = async_to_streamed_response_wrapper(
            agents.get_status,
        )
