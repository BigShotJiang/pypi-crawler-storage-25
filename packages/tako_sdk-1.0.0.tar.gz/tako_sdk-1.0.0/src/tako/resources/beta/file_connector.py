# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.beta import file_connector_list_params, file_connector_create_params
from ..._base_client import make_request_options
from ...types.beta.file_connector_list_response import FileConnectorListResponse
from ...types.beta.file_connector_create_response import FileConnectorCreateResponse

__all__ = ["FileConnectorResource", "AsyncFileConnectorResource"]


class FileConnectorResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> FileConnectorResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return FileConnectorResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> FileConnectorResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return FileConnectorResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        file_url: str,
        connected_private_index_id: Optional[str] | Omit = omit,
        display_name: Optional[str] | Omit = omit,
        file_context: Optional[str] | Omit = omit,
        file_id: Optional[str] | Omit = omit,
        generate_ontology: Optional[bool] | Omit = omit,
        link_world_ontology: Optional[bool] | Omit = omit,
        prepend_schema_context: Optional[bool] | Omit = omit,
        segment_id: Optional[str] | Omit = omit,
        source: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileConnectorCreateResponse:
        """Connect a file to the Tako platform.

        Tako will download the file and store it in
        the Tako platform. For file updated to be propagated to the Tako platform, call
        the file_connector endpoint with the file_id and the file_url when the file is
        updated.

        Args:
          file_url: URL of the file to connect to

          connected_private_index_id: ID of the connected private index to connect to.

          display_name: Name to display in the Tako UI for the file.

          file_context: Context of the file as a freeform string. This is used to help Tako understand
              the file.

          file_id: ID of the file to connect to. If not provided, a new file ID will be generated

          generate_ontology: Whether to generate or update the ontology for this file.

          link_world_ontology: Whether to link the private index ontology with the world ontology through
              deduplication.

          prepend_schema_context: Whether to prepend the schema context to the dataset context

          segment_id: ID of the segment of the source index to connect to.

          source: Source of the file to connect to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/beta/file_connector",
            body=maybe_transform(
                {
                    "file_url": file_url,
                    "connected_private_index_id": connected_private_index_id,
                    "display_name": display_name,
                    "file_context": file_context,
                    "file_id": file_id,
                    "generate_ontology": generate_ontology,
                    "link_world_ontology": link_world_ontology,
                    "prepend_schema_context": prepend_schema_context,
                    "segment_id": segment_id,
                    "source": source,
                },
                file_connector_create_params.FileConnectorCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileConnectorCreateResponse,
        )

    def list(
        self,
        *,
        file_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileConnectorListResponse:
        """Get a list of files that were connected to.

        If file_id is provided, get the file
        with the given ID. Otherwise, get all files that were connected to.

        Args:
          file_id: ID of the file to get

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/beta/file_connector",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform({"file_id": file_id}, file_connector_list_params.FileConnectorListParams),
            ),
            cast_to=FileConnectorListResponse,
        )


class AsyncFileConnectorResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncFileConnectorResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncFileConnectorResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncFileConnectorResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return AsyncFileConnectorResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        file_url: str,
        connected_private_index_id: Optional[str] | Omit = omit,
        display_name: Optional[str] | Omit = omit,
        file_context: Optional[str] | Omit = omit,
        file_id: Optional[str] | Omit = omit,
        generate_ontology: Optional[bool] | Omit = omit,
        link_world_ontology: Optional[bool] | Omit = omit,
        prepend_schema_context: Optional[bool] | Omit = omit,
        segment_id: Optional[str] | Omit = omit,
        source: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileConnectorCreateResponse:
        """Connect a file to the Tako platform.

        Tako will download the file and store it in
        the Tako platform. For file updated to be propagated to the Tako platform, call
        the file_connector endpoint with the file_id and the file_url when the file is
        updated.

        Args:
          file_url: URL of the file to connect to

          connected_private_index_id: ID of the connected private index to connect to.

          display_name: Name to display in the Tako UI for the file.

          file_context: Context of the file as a freeform string. This is used to help Tako understand
              the file.

          file_id: ID of the file to connect to. If not provided, a new file ID will be generated

          generate_ontology: Whether to generate or update the ontology for this file.

          link_world_ontology: Whether to link the private index ontology with the world ontology through
              deduplication.

          prepend_schema_context: Whether to prepend the schema context to the dataset context

          segment_id: ID of the segment of the source index to connect to.

          source: Source of the file to connect to

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/beta/file_connector",
            body=await async_maybe_transform(
                {
                    "file_url": file_url,
                    "connected_private_index_id": connected_private_index_id,
                    "display_name": display_name,
                    "file_context": file_context,
                    "file_id": file_id,
                    "generate_ontology": generate_ontology,
                    "link_world_ontology": link_world_ontology,
                    "prepend_schema_context": prepend_schema_context,
                    "segment_id": segment_id,
                    "source": source,
                },
                file_connector_create_params.FileConnectorCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=FileConnectorCreateResponse,
        )

    async def list(
        self,
        *,
        file_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> FileConnectorListResponse:
        """Get a list of files that were connected to.

        If file_id is provided, get the file
        with the given ID. Otherwise, get all files that were connected to.

        Args:
          file_id: ID of the file to get

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/beta/file_connector",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"file_id": file_id}, file_connector_list_params.FileConnectorListParams
                ),
            ),
            cast_to=FileConnectorListResponse,
        )


class FileConnectorResourceWithRawResponse:
    def __init__(self, file_connector: FileConnectorResource) -> None:
        self._file_connector = file_connector

        self.create = to_raw_response_wrapper(
            file_connector.create,
        )
        self.list = to_raw_response_wrapper(
            file_connector.list,
        )


class AsyncFileConnectorResourceWithRawResponse:
    def __init__(self, file_connector: AsyncFileConnectorResource) -> None:
        self._file_connector = file_connector

        self.create = async_to_raw_response_wrapper(
            file_connector.create,
        )
        self.list = async_to_raw_response_wrapper(
            file_connector.list,
        )


class FileConnectorResourceWithStreamingResponse:
    def __init__(self, file_connector: FileConnectorResource) -> None:
        self._file_connector = file_connector

        self.create = to_streamed_response_wrapper(
            file_connector.create,
        )
        self.list = to_streamed_response_wrapper(
            file_connector.list,
        )


class AsyncFileConnectorResourceWithStreamingResponse:
    def __init__(self, file_connector: AsyncFileConnectorResource) -> None:
        self._file_connector = file_connector

        self.create = async_to_streamed_response_wrapper(
            file_connector.create,
        )
        self.list = async_to_streamed_response_wrapper(
            file_connector.list,
        )
