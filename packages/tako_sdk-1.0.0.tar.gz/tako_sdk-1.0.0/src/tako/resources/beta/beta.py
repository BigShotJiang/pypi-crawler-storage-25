# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from .files import (
    FilesResource,
    AsyncFilesResource,
    FilesResourceWithRawResponse,
    AsyncFilesResourceWithRawResponse,
    FilesResourceWithStreamingResponse,
    AsyncFilesResourceWithStreamingResponse,
)
from ...types import beta_get_file_upload_url_params
from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from .visualize import (
    VisualizeResource,
    AsyncVisualizeResource,
    VisualizeResourceWithRawResponse,
    AsyncVisualizeResourceWithRawResponse,
    VisualizeResourceWithStreamingResponse,
    AsyncVisualizeResourceWithStreamingResponse,
)
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from .file_connector import (
    FileConnectorResource,
    AsyncFileConnectorResource,
    FileConnectorResourceWithRawResponse,
    AsyncFileConnectorResourceWithRawResponse,
    FileConnectorResourceWithStreamingResponse,
    AsyncFileConnectorResourceWithStreamingResponse,
)
from ...types.beta_get_file_upload_url_response import BetaGetFileUploadURLResponse

__all__ = ["BetaResource", "AsyncBetaResource"]


class BetaResource(SyncAPIResource):
    @cached_property
    def visualize(self) -> VisualizeResource:
        return VisualizeResource(self._client)

    @cached_property
    def file_connector(self) -> FileConnectorResource:
        return FileConnectorResource(self._client)

    @cached_property
    def files(self) -> FilesResource:
        return FilesResource(self._client)

    @cached_property
    def with_raw_response(self) -> BetaResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return BetaResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> BetaResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return BetaResourceWithStreamingResponse(self)

    def get_file_upload_url(
        self,
        *,
        file_name: str,
        display_name: str | Omit = omit,
        file_context: str | Omit = omit,
        source: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BetaGetFileUploadURLResponse:
        """
        Get a presigned URL for uploading a file to the Tako platform.

        Args:
          file_name: Name of the file

          display_name: Display name for the file

          file_context: Context or description for the file

          source: Source attribution for the file

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/beta/file_upload_url",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "file_name": file_name,
                        "display_name": display_name,
                        "file_context": file_context,
                        "source": source,
                    },
                    beta_get_file_upload_url_params.BetaGetFileUploadURLParams,
                ),
            ),
            cast_to=BetaGetFileUploadURLResponse,
        )


class AsyncBetaResource(AsyncAPIResource):
    @cached_property
    def visualize(self) -> AsyncVisualizeResource:
        return AsyncVisualizeResource(self._client)

    @cached_property
    def file_connector(self) -> AsyncFileConnectorResource:
        return AsyncFileConnectorResource(self._client)

    @cached_property
    def files(self) -> AsyncFilesResource:
        return AsyncFilesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncBetaResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncBetaResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncBetaResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return AsyncBetaResourceWithStreamingResponse(self)

    async def get_file_upload_url(
        self,
        *,
        file_name: str,
        display_name: str | Omit = omit,
        file_context: str | Omit = omit,
        source: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BetaGetFileUploadURLResponse:
        """
        Get a presigned URL for uploading a file to the Tako platform.

        Args:
          file_name: Name of the file

          display_name: Display name for the file

          file_context: Context or description for the file

          source: Source attribution for the file

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/beta/file_upload_url",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "file_name": file_name,
                        "display_name": display_name,
                        "file_context": file_context,
                        "source": source,
                    },
                    beta_get_file_upload_url_params.BetaGetFileUploadURLParams,
                ),
            ),
            cast_to=BetaGetFileUploadURLResponse,
        )


class BetaResourceWithRawResponse:
    def __init__(self, beta: BetaResource) -> None:
        self._beta = beta

        self.get_file_upload_url = to_raw_response_wrapper(
            beta.get_file_upload_url,
        )

    @cached_property
    def visualize(self) -> VisualizeResourceWithRawResponse:
        return VisualizeResourceWithRawResponse(self._beta.visualize)

    @cached_property
    def file_connector(self) -> FileConnectorResourceWithRawResponse:
        return FileConnectorResourceWithRawResponse(self._beta.file_connector)

    @cached_property
    def files(self) -> FilesResourceWithRawResponse:
        return FilesResourceWithRawResponse(self._beta.files)


class AsyncBetaResourceWithRawResponse:
    def __init__(self, beta: AsyncBetaResource) -> None:
        self._beta = beta

        self.get_file_upload_url = async_to_raw_response_wrapper(
            beta.get_file_upload_url,
        )

    @cached_property
    def visualize(self) -> AsyncVisualizeResourceWithRawResponse:
        return AsyncVisualizeResourceWithRawResponse(self._beta.visualize)

    @cached_property
    def file_connector(self) -> AsyncFileConnectorResourceWithRawResponse:
        return AsyncFileConnectorResourceWithRawResponse(self._beta.file_connector)

    @cached_property
    def files(self) -> AsyncFilesResourceWithRawResponse:
        return AsyncFilesResourceWithRawResponse(self._beta.files)


class BetaResourceWithStreamingResponse:
    def __init__(self, beta: BetaResource) -> None:
        self._beta = beta

        self.get_file_upload_url = to_streamed_response_wrapper(
            beta.get_file_upload_url,
        )

    @cached_property
    def visualize(self) -> VisualizeResourceWithStreamingResponse:
        return VisualizeResourceWithStreamingResponse(self._beta.visualize)

    @cached_property
    def file_connector(self) -> FileConnectorResourceWithStreamingResponse:
        return FileConnectorResourceWithStreamingResponse(self._beta.file_connector)

    @cached_property
    def files(self) -> FilesResourceWithStreamingResponse:
        return FilesResourceWithStreamingResponse(self._beta.files)


class AsyncBetaResourceWithStreamingResponse:
    def __init__(self, beta: AsyncBetaResource) -> None:
        self._beta = beta

        self.get_file_upload_url = async_to_streamed_response_wrapper(
            beta.get_file_upload_url,
        )

    @cached_property
    def visualize(self) -> AsyncVisualizeResourceWithStreamingResponse:
        return AsyncVisualizeResourceWithStreamingResponse(self._beta.visualize)

    @cached_property
    def file_connector(self) -> AsyncFileConnectorResourceWithStreamingResponse:
        return AsyncFileConnectorResourceWithStreamingResponse(self._beta.file_connector)

    @cached_property
    def files(self) -> AsyncFilesResourceWithStreamingResponse:
        return AsyncFilesResourceWithStreamingResponse(self._beta.files)
