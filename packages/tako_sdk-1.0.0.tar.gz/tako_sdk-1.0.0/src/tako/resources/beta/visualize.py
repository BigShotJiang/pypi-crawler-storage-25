# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from typing_extensions import Literal

import httpx

from ..._types import Body, Omit, Query, Headers, NotGiven, SequenceNotStr, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ...types.beta import visualize_create_params
from ..._base_client import make_request_options
from ...types.results import Results
from ...types.output_settings_param import OutputSettingsParam

__all__ = ["VisualizeResource", "AsyncVisualizeResource"]


class VisualizeResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> VisualizeResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return VisualizeResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> VisualizeResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return VisualizeResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        connected_private_index_id: Optional[str] | Omit = omit,
        csv: Optional[SequenceNotStr[str]] | Omit = omit,
        file_id: Optional[str] | Omit = omit,
        file_ids: Union[SequenceNotStr[str], Iterable[visualize_create_params.FileIDsUnionMember1]] | Omit = omit,
        output_settings: Optional[OutputSettingsParam] | Omit = omit,
        query: Optional[str] | Omit = omit,
        segment_id: Optional[str] | Omit = omit,
        viz_component_type: Optional[
            Literal[
                "bar",
                "grouped_bar",
                "stacked_bar",
                "timeseries",
                "area_timeseries",
                "stacked_area_timeseries",
                "pie",
                "choropleth",
                "map",
                "bubble_map",
                "scatter",
                "boxplot",
                "heatmap",
                "timeline",
                "waterfall",
                "histogram",
                "table",
                "treemap",
                "top_level_metric",
            ]
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Results:
        """
        Visualize a dataset

        Args:
          connected_private_index_id: The connected private index id of the dataset to visualize

          csv: List of serialized CSV strings to visualize

          file_id: The file id of the dataset to visualize. This is deprecated and will be removed
              in the future. Use `file_ids` instead.

          file_ids: The file ids of the datasets to visualize

          output_settings: Settings for controlling outputs of the knowledge search request

          query: Query with instructions to visualize the dataset

          segment_id: The segment id of the dataset to visualize

          viz_component_type: The type of visualization component to use

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/beta/visualize",
            body=maybe_transform(
                {
                    "connected_private_index_id": connected_private_index_id,
                    "csv": csv,
                    "file_id": file_id,
                    "file_ids": file_ids,
                    "output_settings": output_settings,
                    "query": query,
                    "segment_id": segment_id,
                    "viz_component_type": viz_component_type,
                },
                visualize_create_params.VisualizeCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Results,
        )


class AsyncVisualizeResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncVisualizeResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncVisualizeResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncVisualizeResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return AsyncVisualizeResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        connected_private_index_id: Optional[str] | Omit = omit,
        csv: Optional[SequenceNotStr[str]] | Omit = omit,
        file_id: Optional[str] | Omit = omit,
        file_ids: Union[SequenceNotStr[str], Iterable[visualize_create_params.FileIDsUnionMember1]] | Omit = omit,
        output_settings: Optional[OutputSettingsParam] | Omit = omit,
        query: Optional[str] | Omit = omit,
        segment_id: Optional[str] | Omit = omit,
        viz_component_type: Optional[
            Literal[
                "bar",
                "grouped_bar",
                "stacked_bar",
                "timeseries",
                "area_timeseries",
                "stacked_area_timeseries",
                "pie",
                "choropleth",
                "map",
                "bubble_map",
                "scatter",
                "boxplot",
                "heatmap",
                "timeline",
                "waterfall",
                "histogram",
                "table",
                "treemap",
                "top_level_metric",
            ]
        ]
        | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Results:
        """
        Visualize a dataset

        Args:
          connected_private_index_id: The connected private index id of the dataset to visualize

          csv: List of serialized CSV strings to visualize

          file_id: The file id of the dataset to visualize. This is deprecated and will be removed
              in the future. Use `file_ids` instead.

          file_ids: The file ids of the datasets to visualize

          output_settings: Settings for controlling outputs of the knowledge search request

          query: Query with instructions to visualize the dataset

          segment_id: The segment id of the dataset to visualize

          viz_component_type: The type of visualization component to use

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/beta/visualize",
            body=await async_maybe_transform(
                {
                    "connected_private_index_id": connected_private_index_id,
                    "csv": csv,
                    "file_id": file_id,
                    "file_ids": file_ids,
                    "output_settings": output_settings,
                    "query": query,
                    "segment_id": segment_id,
                    "viz_component_type": viz_component_type,
                },
                visualize_create_params.VisualizeCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Results,
        )


class VisualizeResourceWithRawResponse:
    def __init__(self, visualize: VisualizeResource) -> None:
        self._visualize = visualize

        self.create = to_raw_response_wrapper(
            visualize.create,
        )


class AsyncVisualizeResourceWithRawResponse:
    def __init__(self, visualize: AsyncVisualizeResource) -> None:
        self._visualize = visualize

        self.create = async_to_raw_response_wrapper(
            visualize.create,
        )


class VisualizeResourceWithStreamingResponse:
    def __init__(self, visualize: VisualizeResource) -> None:
        self._visualize = visualize

        self.create = to_streamed_response_wrapper(
            visualize.create,
        )


class AsyncVisualizeResourceWithStreamingResponse:
    def __init__(self, visualize: AsyncVisualizeResource) -> None:
        self._visualize = visualize

        self.create = async_to_streamed_response_wrapper(
            visualize.create,
        )
