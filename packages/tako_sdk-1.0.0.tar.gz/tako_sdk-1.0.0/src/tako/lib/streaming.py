from __future__ import annotations

import time
import logging
from types import TracebackType
from typing import TYPE_CHECKING, Any, Dict, Iterator, Optional, AsyncIterator
from typing_extensions import Self, Literal

import httpx

from .._types import RequestOptions
from .._models import BaseModel
from .._streaming import Stream, AsyncStream

if TYPE_CHECKING:
    from .._client import Tako, AsyncTako

__all__ = ["AgentStreamEvent", "AgentStream", "AsyncAgentStream"]

log = logging.getLogger(__name__)
_RETRIABLE = (httpx.NetworkError, httpx.TimeoutException, httpx.RemoteProtocolError)
_STREAM_PATH = "/v1/agents/stream/{task_id}/"


def _reconnect_opts(task_id: str, last_seq: int, timeout: float) -> tuple[str, RequestOptions]:
    from .._utils import path_template
    from .._base_client import make_request_options
    return (
        path_template(_STREAM_PATH, task_id=task_id),
        make_request_options(timeout=timeout, query={"last_seq": last_seq} if last_seq >= 0 else None),
    )


class AgentStreamEvent(BaseModel):
    seq: int
    task_id: str
    category: Literal["content", "activity", "control"]
    block: Dict[str, Any]


class AgentStream:
    task_id: Optional[str]
    last_seq: int

    def __init__(self, *, stream: Stream[AgentStreamEvent], client: Tako, max_retries: int = 5, reconnect_timeout: float = 120.0) -> None:
        self._stream: Stream[AgentStreamEvent] = stream
        self._client = client
        self._max_retries = max_retries
        self._reconnect_timeout = reconnect_timeout
        self.task_id = None
        self.last_seq = -1

    def __iter__(self) -> Iterator[AgentStreamEvent]:
        retries = 0
        while True:
            try:
                for event in self._stream:
                    self.task_id = event.task_id
                    self.last_seq = event.seq
                    retries = 0
                    yield event
                return
            except _RETRIABLE:
                if self.task_id is None or retries >= self._max_retries:
                    raise
                retries += 1
                delay = min(0.5 * (2 ** (retries - 1)), 10)
                log.info("Connection lost (task=%s seq=%d), reconnect in %.1fs (%d/%d)", self.task_id, self.last_seq, delay, retries, self._max_retries)
                time.sleep(delay)
                self._stream.close()
                path, opts = _reconnect_opts(self.task_id, self.last_seq, self._reconnect_timeout)
                self._stream = self._client.get(path, options=opts, cast_to=AgentStreamEvent, stream=True, stream_cls=Stream[AgentStreamEvent])

    def close(self) -> None:
        self._stream.close()

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, exc_tb: TracebackType | None) -> None:
        self.close()


class AsyncAgentStream:
    task_id: Optional[str]
    last_seq: int

    def __init__(self, *, stream: AsyncStream[AgentStreamEvent], client: AsyncTako, max_retries: int = 5, reconnect_timeout: float = 120.0) -> None:
        self._stream: AsyncStream[AgentStreamEvent] = stream
        self._client = client
        self._max_retries = max_retries
        self._reconnect_timeout = reconnect_timeout
        self.task_id = None
        self.last_seq = -1

    async def __aiter__(self) -> AsyncIterator[AgentStreamEvent]:
        import asyncio
        retries = 0
        while True:
            try:
                async for event in self._stream:
                    self.task_id = event.task_id
                    self.last_seq = event.seq
                    retries = 0
                    yield event
                return
            except _RETRIABLE:
                if self.task_id is None or retries >= self._max_retries:
                    raise
                retries += 1
                delay = min(0.5 * (2 ** (retries - 1)), 10)
                log.info("Connection lost (task=%s seq=%d), reconnect in %.1fs (%d/%d)", self.task_id, self.last_seq, delay, retries, self._max_retries)
                await asyncio.sleep(delay)
                await self._stream.close()
                path, opts = _reconnect_opts(self.task_id, self.last_seq, self._reconnect_timeout)
                self._stream = await self._client.get(path, options=opts, cast_to=AgentStreamEvent, stream=True, stream_cls=AsyncStream[AgentStreamEvent])

    async def close(self) -> None:
        await self._stream.close()

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(self, exc_type: type[BaseException] | None, exc: BaseException | None, exc_tb: TracebackType | None) -> None:
        await self.close()
