"""Hand-written agent resources — in lib/ so Stainless never touches it."""
from __future__ import annotations

from typing import Optional
from typing_extensions import Literal

import httpx

from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import path_template
from .streaming import AgentStream, AgentStreamEvent, AsyncAgentStream
from .._resource import SyncAPIResource, AsyncAPIResource
from .._streaming import Stream, AsyncStream
from .._base_client import make_request_options

__all__ = ["TakoDataResource", "AsyncTakoDataResource", "reconnect", "async_reconnect"]

_STREAM_URL = "/v1/agents/tako_data/stream"
_RECONNECT_URL = "/v1/agents/stream/{task_id}/"


class TakoDataResource(SyncAPIResource):
    def stream(self, *, query: str, effort: Optional[Literal["fast", "medium", "deep", "auto"]] | Omit = omit,
               extra_headers: Headers | None = None, extra_query: Query | None = None,
               extra_body: Body | None = None, timeout: float | httpx.Timeout | None | NotGiven = not_given) -> AgentStream:
        """Dispatch an agent task and stream its execution via SSE."""
        raw: Stream[AgentStreamEvent] = self._post(
            _STREAM_URL, body={"query": query, "effort": effort},
            options=make_request_options(extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout),
            cast_to=AgentStreamEvent, stream=True, stream_cls=Stream[AgentStreamEvent])
        return AgentStream(stream=raw, client=self._client)


class AsyncTakoDataResource(AsyncAPIResource):
    async def stream(self, *, query: str, effort: Optional[Literal["fast", "medium", "deep", "auto"]] | Omit = omit,
                     extra_headers: Headers | None = None, extra_query: Query | None = None,
                     extra_body: Body | None = None, timeout: float | httpx.Timeout | None | NotGiven = not_given) -> AsyncAgentStream:
        """Dispatch an agent task and stream its execution via SSE."""
        raw: AsyncStream[AgentStreamEvent] = await self._post(
            _STREAM_URL, body={"query": query, "effort": effort},
            options=make_request_options(extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout),
            cast_to=AgentStreamEvent, stream=True, stream_cls=AsyncStream[AgentStreamEvent])
        return AsyncAgentStream(stream=raw, client=self._client)


def reconnect(resource: SyncAPIResource, task_id: str, *, last_seq: int = -1,
              extra_headers: Headers | None = None, extra_query: Query | None = None,
              extra_body: Body | None = None, timeout: float | httpx.Timeout | None | NotGiven = not_given) -> Stream[AgentStreamEvent]:
    """Reconnect to an agent task's event stream."""
    q: dict[str, object] = {"last_seq": last_seq} if last_seq >= 0 else {}
    return resource._get(
        path_template(_RECONNECT_URL, task_id=task_id),
        options=make_request_options(extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout, query=q or None),
        cast_to=AgentStreamEvent, stream=True, stream_cls=Stream[AgentStreamEvent])


async def async_reconnect(resource: AsyncAPIResource, task_id: str, *, last_seq: int = -1,
                           extra_headers: Headers | None = None, extra_query: Query | None = None,
                           extra_body: Body | None = None, timeout: float | httpx.Timeout | None | NotGiven = not_given) -> AsyncStream[AgentStreamEvent]:
    """Reconnect to an agent task's event stream (async)."""
    q: dict[str, object] = {"last_seq": last_seq} if last_seq >= 0 else {}
    return await resource._get(
        path_template(_RECONNECT_URL, task_id=task_id),
        options=make_request_options(extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout, query=q or None),
        cast_to=AgentStreamEvent, stream=True, stream_cls=AsyncStream[AgentStreamEvent])
