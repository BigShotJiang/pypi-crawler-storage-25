# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, TypeAlias

from .._models import BaseModel

__all__ = [
    "Results",
    "Outputs",
    "OutputsKnowledgeCard",
    "OutputsKnowledgeCardMethodology",
    "OutputsKnowledgeCardSourceIndex",
    "OutputsKnowledgeCardSourceIndexKnowledgeSearchSourceIndexSegment",
    "OutputsKnowledgeCardSource",
    "OutputsKnowledgeCardSourceSourceIndex",
    "OutputsKnowledgeCardSourceSourceIndexKnowledgeSearchSourceIndexSegment",
    "OutputsKnowledgeCardSourceSourceIndexKnowledgeSearchSourcePrivateIndex",
    "OutputsKnowledgeCardIdealVizDecision",
]


class OutputsKnowledgeCardMethodology(BaseModel):
    methodology_description: Optional[str] = None
    """The description of the methodology"""

    methodology_name: Optional[str] = None
    """The name of the methodology"""


class OutputsKnowledgeCardSourceIndexKnowledgeSearchSourceIndexSegment(BaseModel):
    """A segment of a source index.

    Within a source index, a segment is a subset of the data.
    For connected data, a segment is a subset of connected files. A segment may be used for
    multi-tenant data e.g. using a segment per customer.
    """

    index_type: Literal["tako", "web", "connected_data", "tako_deep_v2"]

    segment_id: str
    """An ID for a segment of a source index"""


OutputsKnowledgeCardSourceIndex: TypeAlias = Union[
    Literal["tako", "web", "connected_data", "tako_deep_v2"],
    OutputsKnowledgeCardSourceIndexKnowledgeSearchSourceIndexSegment,
]


class OutputsKnowledgeCardSourceSourceIndexKnowledgeSearchSourceIndexSegment(BaseModel):
    """A segment of a source index.

    Within a source index, a segment is a subset of the data.
    For connected data, a segment is a subset of connected files. A segment may be used for
    multi-tenant data e.g. using a segment per customer.
    """

    index_type: Literal["tako", "web", "connected_data", "tako_deep_v2"]

    segment_id: str
    """An ID for a segment of a source index"""


class OutputsKnowledgeCardSourceSourceIndexKnowledgeSearchSourcePrivateIndex(BaseModel):
    index_type: Literal["tako", "web", "connected_data", "tako_deep_v2"]

    private_index_id: str
    """An ID for a private index"""

    segment_id: Optional[str] = None
    """An ID for a segment of a source index (optional for private indexes)"""


OutputsKnowledgeCardSourceSourceIndex: TypeAlias = Union[
    Literal["tako", "web", "connected_data", "tako_deep_v2"],
    OutputsKnowledgeCardSourceSourceIndexKnowledgeSearchSourceIndexSegment,
    OutputsKnowledgeCardSourceSourceIndexKnowledgeSearchSourcePrivateIndex,
]


class OutputsKnowledgeCardSource(BaseModel):
    source_description: Optional[str] = None
    """The description of the source"""

    source_index: OutputsKnowledgeCardSourceSourceIndex
    """The index of the source"""

    source_name: Optional[str] = None
    """The name of the source"""

    url: Optional[str] = None
    """The URL of the source"""


class OutputsKnowledgeCardIdealVizDecision(BaseModel):
    """
    Documents a decision made by Tako's ideal viz logic for a specific ChartJS property.

    .. deprecated::
        This class is deprecated in favor of the structured VizDecisions system.
        Use VizDecisions with specific decision types (AggregationDecision, VizTypeDecision, etc.)
        instead. The new system provides:
        - Structured decision tracking with typed fields
        - Override support (apply_override, reset_to_default)
        - Better LLM context generation (get_summary_for_llm)

        Example migration:
            # Old way (deprecated):
            decisions.append(IdealVizDecision(
                property_path="y_aggregation",
                reason="Applied PCSS due to different units"
            ))

            # New way:
            viz_decisions.set_decision(
                DecisionType.LEFT_AXIS_AGGREGATION,
                AggregationDecision(
                    value="pcss",
                    source=DecisionSource.DATA_DRIVEN,
                    reason_code="different_units",
                    reason_display="Applied PCSS due to different units",
                )
            )

        This class will be removed in a future version.
    """

    property_path: str
    """ChartJS property path"""

    reason: str
    """Why this decision was made"""

    property_path_display_name: Optional[str] = None
    """Human-friendly display name for the property path"""


class OutputsKnowledgeCard(BaseModel):
    card_id: Optional[str] = None
    """The unique ID of the knowledge card"""

    card_type: Optional[str] = None
    """The type of card"""

    data_url: Optional[str] = None
    """URL of downloadable data of the knowledge card.

    This needs to be enabled on an account level. Contact support to enable this
    feature.
    """

    description: Optional[str] = None
    """The description of the knowledge card"""

    embed_url: Optional[str] = None
    """URL of an embeddable iframe of the knowledge card"""

    image_url: Optional[str] = None
    """URL of a static image of the knowledge card"""

    methodologies: Optional[List[OutputsKnowledgeCardMethodology]] = None
    """The methodologies of the knowledge card"""

    relevance: Optional[Literal["High", "Medium", "Low"]] = None
    """How relevant this knowledge card is to the search query"""

    source_indexes: Optional[List[OutputsKnowledgeCardSourceIndex]] = None
    """The source indexes of the knowledge card"""

    sources: Optional[List[OutputsKnowledgeCardSource]] = None
    """The sources of the knowledge card"""

    title: Optional[str] = None
    """The title of the knowledge card"""

    visualization_data: Optional[Dict[str, object]] = None
    """The visualization data of the knowledge card"""

    webpage_url: Optional[str] = None
    """URL of a webpage hosting the interactive knowledge card"""

    ideal_viz_decisions: Optional[List[OutputsKnowledgeCardIdealVizDecision]] = None
    """Decisions made by Tako's ideal viz logic when constructing this visualization.

    DEPRECATED: Use ChartConfig.viz_decisions for the new structured system with
    override support.
    """


class Outputs(BaseModel):
    answer: Optional[str] = None

    knowledge_cards: Optional[List[OutputsKnowledgeCard]] = None


class Results(BaseModel):
    outputs: Optional[Outputs] = None

    request_id: Optional[str] = None
