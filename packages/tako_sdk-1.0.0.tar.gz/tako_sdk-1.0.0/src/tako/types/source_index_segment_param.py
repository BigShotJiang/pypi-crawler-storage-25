# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

from .source_index import SourceIndex

__all__ = ["SourceIndexSegmentParam"]


class SourceIndexSegmentParam(TypedDict, total=False):
    index_type: Required[SourceIndex]

    segment_id: Required[str]
