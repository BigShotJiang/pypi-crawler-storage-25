# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["AgentGetStatusParams"]


class AgentGetStatusParams(TypedDict, total=False):
    task_id: Required[str]
    """UUID of the async task"""

    since_index: int
    """Return events starting from this index (0-based)"""
