# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from typing_extensions import Literal, Required, TypeAlias, TypedDict

from . import source_index
from .output_settings_param import OutputSettingsParam
from .source_index_segment_param import SourceIndexSegmentParam

__all__ = [
    "SearchCreateParams",
    "Inputs",
    "InputsXFileSourceID",
    "SourceIndex",
    "SourceIndexKnowledgeSearchSourcePrivateIndex",
]


class SearchCreateParams(TypedDict, total=False):
    inputs: Required[Inputs]

    country_code: str
    """ISO3166-1 alpha-2 country code (e.g., 'US', 'CA', 'GB')"""

    locale: str
    """ISO 639-1 language code (e.g., 'en', 'es', 'fr')"""

    output_settings: Optional[OutputSettingsParam]
    """Settings for controlling outputs of the knowledge search request"""

    search_effort: Optional[Literal["fast", "medium", "deep", "auto"]]
    """Effort level for the search."""

    source_indexes: Optional[Iterable[SourceIndex]]


class InputsXFileSourceID(TypedDict, total=False):
    file_id: Required[str]

    file_context: Optional[str]

    ontology_context: Optional[str]

    private_index_id: Optional[str]

    segment_id: Optional[str]


class Inputs(TypedDict, total=False):
    count: Optional[int]

    current_view: Optional[str]

    question: Optional[str]

    text: Optional[str]

    x_file_source_ids: Optional[Iterable[InputsXFileSourceID]]


class SourceIndexKnowledgeSearchSourcePrivateIndex(TypedDict, total=False):
    index_type: Required[source_index.SourceIndex]

    private_index_id: Required[str]

    segment_id: Optional[str]


SourceIndex: TypeAlias = Union[
    source_index.SourceIndex, SourceIndexSegmentParam, SourceIndexKnowledgeSearchSourcePrivateIndex
]
