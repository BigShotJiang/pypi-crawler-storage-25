# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["SourceIndex"]

SourceIndex: TypeAlias = Literal["tako", "tako_deep_v2", "web", "web_pipeline", "connected_data", "tako_llm_hydrate"]
