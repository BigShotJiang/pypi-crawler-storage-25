# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, TypedDict

__all__ = ["BetaGetFileUploadURLParams"]


class BetaGetFileUploadURLParams(TypedDict, total=False):
    file_name: Required[str]
    """Name of the file"""

    display_name: str
    """Display name for the file"""

    file_context: str
    """Context or description for the file"""

    source: str
    """Source attribution for the file"""
