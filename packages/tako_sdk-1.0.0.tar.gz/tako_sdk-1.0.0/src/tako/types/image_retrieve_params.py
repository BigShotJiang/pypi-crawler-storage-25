# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["ImageRetrieveParams"]


class ImageRetrieveParams(TypedDict, total=False):
    dark_mode: bool
    """Render in dark mode"""

    height: int
    """Image height in pixels"""

    hide_footer: bool
    """Hide the chart footer"""

    width: int
    """Image width in pixels"""
