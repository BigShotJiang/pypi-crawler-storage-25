# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["AgentGetStatusResponse", "Event"]


class Event(BaseModel):
    id: int

    data: Dict[str, object]


class AgentGetStatusResponse(BaseModel):
    created_at: datetime

    events: List[Event]

    status: Literal["PENDING", "IN_PROGRESS", "COMPLETED", "FAILED", "INTERRUPTED"]

    task_id: str

    thread_id: Optional[str] = None

    error: Optional[str] = None

    message: Optional[str] = None

    result: Optional[Dict[str, object]] = None
