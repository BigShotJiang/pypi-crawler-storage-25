# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict

from .._models import BaseModel

__all__ = ["BetaGetFileUploadURLResponse"]


class BetaGetFileUploadURLResponse(BaseModel):
    fields: Dict[str, str]
    """Fields to specify in the request to upload the file"""

    file_id: str
    """ID of the file that can be referenced in the input to the visualize endpoint"""

    key: str
    """Key of the file in the S3 bucket"""

    url: str
    """URL to upload the file to"""
