# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..._models import BaseModel
from .file_connector_metadata import FileConnectorMetadata

__all__ = ["FileConnectorCreateResponse"]


class FileConnectorCreateResponse(BaseModel):
    id: str
    """ID of the file that was created or connected to"""

    message: str
    """Message indicating the result of the file connector operation"""

    metadata: FileConnectorMetadata
    """Metadata of the file that was created or connected to"""
