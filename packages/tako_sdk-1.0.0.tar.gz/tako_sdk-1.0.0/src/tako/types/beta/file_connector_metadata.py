# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = ["FileConnectorMetadata"]


class FileConnectorMetadata(BaseModel):
    id: str
    """ID of the file that was created or connected to"""

    created_at: str
    """ISO 8601 timestamp of when the file was created or connected to"""

    ontology_state: Optional[str] = None
    """State of the ontology for the file"""

    updated_at: str
    """ISO 8601 timestamp of when the file was last updated"""

    file_context: Optional[str] = None
    """Context of the file as a freeform string.

    This is used to help Tako understand the file.
    """

    prepend_schema_context: Optional[bool] = None
    """Whether to prepend the schema context to the dataset context"""

    schema_id: Optional[str] = None
    """ID of the schema that the file is connected to"""

    segment_id: Optional[str] = None
    """ID of the segment of the source index to connect to."""

    source: Optional[str] = None
    """Source of the file to connect to"""
