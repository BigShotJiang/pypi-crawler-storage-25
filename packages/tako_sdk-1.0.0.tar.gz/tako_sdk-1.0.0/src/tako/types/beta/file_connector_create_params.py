# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["FileConnectorCreateParams"]


class FileConnectorCreateParams(TypedDict, total=False):
    file_url: Required[str]
    """URL of the file to connect to"""

    connected_private_index_id: Optional[str]
    """ID of the connected private index to connect to."""

    display_name: Optional[str]
    """Name to display in the Tako UI for the file."""

    file_context: Optional[str]
    """Context of the file as a freeform string.

    This is used to help Tako understand the file.
    """

    file_id: Optional[str]
    """ID of the file to connect to. If not provided, a new file ID will be generated"""

    generate_ontology: Optional[bool]
    """Whether to generate or update the ontology for this file."""

    link_world_ontology: Optional[bool]
    """
    Whether to link the private index ontology with the world ontology through
    deduplication.
    """

    prepend_schema_context: Optional[bool]
    """Whether to prepend the schema context to the dataset context"""

    segment_id: Optional[str]
    """ID of the segment of the source index to connect to."""

    source: Optional[str]
    """Source of the file to connect to"""
