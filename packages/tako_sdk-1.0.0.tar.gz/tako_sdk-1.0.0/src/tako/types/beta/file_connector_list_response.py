# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from ..._models import BaseModel
from .file_connector_metadata import FileConnectorMetadata

__all__ = ["FileConnectorListResponse"]


class FileConnectorListResponse(BaseModel):
    files: List[FileConnectorMetadata]
    """List of files that were connected to"""
