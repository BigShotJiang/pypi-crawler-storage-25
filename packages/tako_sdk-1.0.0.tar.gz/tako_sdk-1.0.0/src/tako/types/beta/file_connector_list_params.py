# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["FileConnectorListParams"]


class FileConnectorListParams(TypedDict, total=False):
    file_id: str
    """ID of the file to get"""
