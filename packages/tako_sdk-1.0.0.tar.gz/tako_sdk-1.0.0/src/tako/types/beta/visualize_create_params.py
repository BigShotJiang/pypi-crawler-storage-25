# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union, Iterable, Optional
from typing_extensions import Literal, Required, TypedDict

from ..._types import SequenceNotStr
from ..output_settings_param import OutputSettingsParam

__all__ = ["VisualizeCreateParams", "FileIDsUnionMember1"]


class VisualizeCreateParams(TypedDict, total=False):
    connected_private_index_id: Optional[str]
    """The connected private index id of the dataset to visualize"""

    csv: Optional[SequenceNotStr[str]]
    """List of serialized CSV strings to visualize"""

    file_id: Optional[str]
    """The file id of the dataset to visualize.

    This is deprecated and will be removed in the future. Use `file_ids` instead.
    """

    file_ids: Union[SequenceNotStr[str], Iterable[FileIDsUnionMember1]]
    """The file ids of the datasets to visualize"""

    output_settings: Optional[OutputSettingsParam]
    """Settings for controlling outputs of the knowledge search request"""

    query: Optional[str]
    """Query with instructions to visualize the dataset"""

    segment_id: Optional[str]
    """The segment id of the dataset to visualize"""

    viz_component_type: Optional[
        Literal[
            "bar",
            "grouped_bar",
            "stacked_bar",
            "timeseries",
            "area_timeseries",
            "stacked_area_timeseries",
            "pie",
            "choropleth",
            "map",
            "bubble_map",
            "scatter",
            "boxplot",
            "heatmap",
            "timeline",
            "waterfall",
            "histogram",
            "table",
            "treemap",
            "top_level_metric",
        ]
    ]
    """The type of visualization component to use"""


class FileIDsUnionMember1(TypedDict, total=False):
    file_id: Required[str]

    file_context: Optional[str]

    ontology_context: Optional[str]

    private_index_id: Optional[str]

    segment_id: Optional[str]
