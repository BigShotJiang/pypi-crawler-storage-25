# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["FileRetrieveResponse", "Schema"]


class Schema(BaseModel):
    schema_id: str

    display_name: Optional[str] = None


class FileRetrieveResponse(BaseModel):
    file_id: str

    cleaned: Optional[bool] = None

    connected_private_index: Optional[str] = None

    file_context: Optional[str] = None

    file_url: Optional[str] = None

    key: Optional[str] = None

    last_updated_at: Optional[datetime] = None

    og_key: Optional[str] = None

    schema_: Optional[Schema] = FieldInfo(alias="schema", default=None)

    segment_id: Optional[str] = None

    source: Optional[str] = None
