# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Optional
from typing_extensions import Required, TypedDict

__all__ = ["OutputSettingsParam", "KnowledgeCardSettings"]


class KnowledgeCardSettings(TypedDict, total=False):
    """Settings for the knowledge card outputs"""

    image_dark_mode: Optional[bool]
    """Whether to make the knowledge card image dark mode"""


class OutputSettingsParam(TypedDict, total=False):
    knowledge_card_settings: Required[KnowledgeCardSettings]
    """Settings for the knowledge card outputs"""
