"""Base model for generated Pydantic models.

Configures `populate_by_name=True` so that models accept both snake_case
field names and their camelCase aliases when constructing instances.
"""

from pydantic import BaseModel, ConfigDict


class ApiBaseModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
