"""RFQ-specific type definitions for the Silhouette API."""

from enum import Enum


class RfqEvent(str, Enum):
    """RFQ WebSocket event types matching silhouette-mvp-enclave-node."""

    INTENT_CREATED = "rfq:intent:created"
    INTENT_FILLED = "rfq:intent:filled"
    QUOTE_ACCEPTED = "rfq:quote:accepted"
    EXPIRED = "rfq:expired"


__all__ = ["RfqEvent"]
