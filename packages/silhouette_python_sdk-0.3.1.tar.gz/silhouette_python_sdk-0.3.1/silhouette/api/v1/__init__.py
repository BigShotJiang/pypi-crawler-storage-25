"""Silhouette API v1 client (under construction)."""
