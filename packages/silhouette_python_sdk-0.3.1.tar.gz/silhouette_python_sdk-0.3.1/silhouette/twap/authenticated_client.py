"""Authenticated TWAP client with SIWE-based authentication."""

import logging
import threading
from functools import wraps
from typing import Any

import eth_account
from eth_account.signers.local import LocalAccount

from silhouette.api.auth import sign_siwe_message

from .client import AuthenticationExpiredError, TwapClient, TwapClientError

logger = logging.getLogger(__name__)


class AuthenticationError(TwapClientError):
    """Exception raised when authentication flow fails."""


def handle_401_retry(method):
    """Decorator to handle 401 responses by re-logging in via SIWE and retrying once."""

    @wraps(method)
    def wrapper(self, *args, **kwargs):
        try:
            return method(self, *args, **kwargs)
        except AuthenticationExpiredError:
            logger.info("Authentication expired, re-logging in via SIWE")
            try:
                self.login()
            except Exception as e:
                raise AuthenticationError("Failed to re-authenticate", details=str(e)) from e

            try:
                return method(self, *args, **kwargs)
            except AuthenticationExpiredError as err:
                raise AuthenticationError(
                    "Authentication failed after re-login",
                    details="The operation failed with 401 even after re-authentication",
                ) from err

    return wrapper


class AuthenticatedTwapClient:
    """TWAP client with SIWE authentication.

    Usage:
        client = AuthenticatedTwapClient(base_url, private_key)
        agent_address = client.register()
        # approve agent on Hyperliquid
        client.login()
        # now trade
        client.create_twap_order(...)
    """

    def __init__(self, base_url: str, private_key: str, chain_id: int = 1) -> None:
        self._base_url = base_url
        self._chain_id = chain_id
        self._wallet: LocalAccount = eth_account.Account.from_key(private_key)
        self._jwt_token: str | None = None
        self._login_lock = threading.Lock()

        self._twap_client = TwapClient(
            base_url=base_url,
            token_getter=lambda: self._jwt_token,
        )

    def register(self) -> str:
        """Register wallet with Stratagem. Returns the agent address to approve on Hyperliquid."""
        result = self._twap_client.register(self._wallet.address)
        agent_address: str = result["agentAddress"]
        logger.info("Registered wallet, agent address: %s", agent_address)
        return agent_address

    def login(self) -> None:
        """Authenticate via SIWE to get a server-issued JWT."""
        with self._login_lock:
            message, signature = sign_siwe_message(self._wallet, self._base_url, self._chain_id)
            result = self._twap_client.login(message, signature)
            self._jwt_token = result["token"]
            logger.info("SIWE login successful")

    @handle_401_retry
    def create_twap_order(self, order_data: dict[str, Any]) -> dict[str, Any]:
        return self._twap_client.create_twap_order(order_data)

    @handle_401_retry
    def get_order(self, order_id: str) -> dict[str, Any]:
        return self._twap_client.get_order(order_id)

    @handle_401_retry
    def cancel_order(self, order_id: str) -> dict[str, Any]:
        return self._twap_client.cancel_order(order_id)

    @handle_401_retry
    def pause_order(self, order_id: str) -> dict[str, Any]:
        return self._twap_client.pause_order(order_id)

    @handle_401_retry
    def resume_order(self, order_id: str) -> dict[str, Any]:
        return self._twap_client.resume_order(order_id)

    @handle_401_retry
    def get_orders_by_user(self) -> list[dict[str, Any]]:
        return self._twap_client.get_orders_by_user()

    def get_wallet_address(self) -> str:
        return self._wallet.address

    def get_health_check(self) -> dict[str, Any]:
        return self._twap_client.get_health_check()
