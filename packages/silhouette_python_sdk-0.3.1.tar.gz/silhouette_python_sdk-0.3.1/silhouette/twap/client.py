"""TWAP client HTTP layer for Silhouette SDK."""

import logging
from collections.abc import Callable
from typing import Any, cast

import httpx

from .interfaces import TwapClientInterface

logger = logging.getLogger(__name__)


class TwapClientError(Exception):
    """Base exception for TWAP client errors."""

    def __init__(self, message: str, details: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.details = details

    def __str__(self) -> str:
        if self.details is not None and self.details.strip():
            return f"{self.message}: {self.details}"
        return self.message


class AuthenticationExpiredError(TwapClientError):
    """Exception raised when authentication token has expired (401 response)."""

    def __init__(self, message: str = "Authentication token expired", details: str | None = None) -> None:
        super().__init__(message, details)


class TwapClient(TwapClientInterface):
    """HTTP client for TWAP scheduler API."""

    def __init__(
        self,
        base_url: str,
        token_getter: Callable[[], str | None],
        http_client: httpx.Client | None = None,
    ) -> None:
        if not base_url or not isinstance(base_url, str) or not base_url.strip():
            raise TwapClientError("Base URL is required")

        self._base_url = base_url.rstrip("/")
        self._token_getter = token_getter
        self._http_client = http_client

    def _get_auth_headers(self) -> dict[str, str]:
        token = self._token_getter()
        if not token:
            raise TwapClientError("No authentication token available")
        return {"Authorization": f"Bearer {token}"}

    def _request(
        self,
        method: str,
        path: str,
        *,
        headers: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
    ) -> httpx.Response:
        url = f"{self._base_url}{path}"
        kwargs: dict[str, Any] = {}
        if headers is not None:
            kwargs["headers"] = headers
        if json is not None:
            kwargs["json"] = json

        if self._http_client is not None:
            return self._http_client.request(method, url, **kwargs)
        return httpx.request(method, url, **kwargs)

    def _check_response_status(self, response: httpx.Response, operation: str) -> None:
        if response.status_code == 401:
            raise AuthenticationExpiredError(details=response.text or "Received 401 Unauthorized response")
        elif response.status_code >= 400:
            raise TwapClientError(f"{operation} failed with status {response.status_code}", details=response.text or "")

    # --- Auth endpoints (no JWT required) ---

    def register(self, wallet_address: str) -> dict[str, Any]:
        """Register wallet with the scheduler. Returns { agentAddress }."""
        if not isinstance(wallet_address, str) or not wallet_address.strip():
            raise TwapClientError("Wallet address must be a non-empty string")

        response = self._request("POST", "/v0/auth/register", json={"walletAddress": wallet_address})
        self._check_response_status(response, "Registration")
        return cast(dict[str, Any], response.json())

    def login(self, message: str, signature: str) -> dict[str, Any]:
        """Login with SIWE message and signature. Returns { token }."""
        response = self._request("POST", "/v0/auth/login", json={"message": message, "signature": signature})
        self._check_response_status(response, "Login")
        return cast(dict[str, Any], response.json())

    # --- Order endpoints (JWT required) ---

    def create_twap_order(self, order_data: dict[str, Any]) -> dict[str, Any]:
        if not isinstance(order_data, dict):
            raise TwapClientError("Order data must be a dictionary")

        headers = self._get_auth_headers()
        payload = order_data.copy()
        payload.pop("wallet_id", None)

        response = self._request("POST", "/v0/orders/twap", headers=headers, json=payload)
        self._check_response_status(response, "Order creation")
        return cast(dict[str, Any], response.json())

    def get_order(self, order_id: str) -> dict[str, Any]:
        if not isinstance(order_id, str) or not order_id.strip():
            raise TwapClientError("Order ID must be a non-empty string")

        headers = self._get_auth_headers()
        response = self._request("GET", f"/v0/orders/twap/{order_id}", headers=headers)
        self._check_response_status(response, "Order retrieval")
        return cast(dict[str, Any], response.json())

    def cancel_order(self, order_id: str) -> dict[str, Any]:
        if not isinstance(order_id, str) or not order_id.strip():
            raise TwapClientError("Order ID must be a non-empty string")

        headers = self._get_auth_headers()
        response = self._request("PUT", f"/v0/orders/{order_id}/cancel", headers=headers)
        self._check_response_status(response, "Order cancellation")
        return cast(dict[str, Any], response.json())

    def pause_order(self, order_id: str) -> dict[str, Any]:
        if not isinstance(order_id, str) or not order_id.strip():
            raise TwapClientError("Order ID must be a non-empty string")

        headers = self._get_auth_headers()
        response = self._request("PUT", f"/v0/orders/{order_id}/pause", headers=headers)
        self._check_response_status(response, "Order pause")
        return cast(dict[str, Any], response.json())

    def resume_order(self, order_id: str) -> dict[str, Any]:
        if not isinstance(order_id, str) or not order_id.strip():
            raise TwapClientError("Order ID must be a non-empty string")

        headers = self._get_auth_headers()
        response = self._request("PUT", f"/v0/orders/{order_id}/resume", headers=headers)
        self._check_response_status(response, "Order resume")
        return cast(dict[str, Any], response.json())

    def get_orders_by_user(self) -> list[dict[str, Any]]:
        headers = self._get_auth_headers()
        response = self._request("GET", "/v0/orders/user", headers=headers)
        self._check_response_status(response, "Order retrieval")

        parsed = response.json()
        if not isinstance(parsed, list):
            return []
        return parsed

    def get_task_status(self, task_id: str) -> dict[str, Any]:
        if not isinstance(task_id, str) or not task_id.strip():
            raise TwapClientError("Task ID must be a non-empty string")

        headers = self._get_auth_headers()
        response = self._request("GET", f"/v0/orders/task/{task_id}", headers=headers)
        self._check_response_status(response, "Task status retrieval")
        return cast(dict[str, Any], response.json())

    def get_health_check(self) -> dict[str, Any]:
        response = self._request("GET", "/health")
        self._check_response_status(response, "Health check")
        return cast(dict[str, Any], response.json())
