"""Silhouette TWAP (Time-Weighted Average Price) Client."""

from .authenticated_client import AuthenticatedTwapClient, AuthenticationError
from .client import AuthenticationExpiredError, TwapClient, TwapClientError
from .interfaces import TwapClientInterface

__all__ = [
    "TwapClientInterface",
    "TwapClient",
    "TwapClientError",
    "AuthenticationExpiredError",
    "AuthenticatedTwapClient",
    "AuthenticationError",
]
