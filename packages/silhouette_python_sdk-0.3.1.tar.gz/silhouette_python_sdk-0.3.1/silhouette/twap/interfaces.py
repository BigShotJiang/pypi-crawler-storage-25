"""Interfaces for TWAP client integration."""

from abc import ABC, abstractmethod
from typing import Any


class TwapClientInterface(ABC):
    """Interface for TWAP client implementations."""

    @abstractmethod
    def create_twap_order(self, order_data: dict[str, Any]) -> dict[str, Any]:
        """Create a TWAP order."""
        pass

    @abstractmethod
    def get_order(self, order_id: str) -> dict[str, Any]:
        """Get order details by ID."""
        pass

    @abstractmethod
    def cancel_order(self, order_id: str) -> dict[str, Any]:
        """Cancel an order by order ID."""
        pass

    @abstractmethod
    def pause_order(self, order_id: str) -> dict[str, Any]:
        """Pause an order."""
        pass

    @abstractmethod
    def resume_order(self, order_id: str) -> dict[str, Any]:
        """Resume an order."""
        pass

    @abstractmethod
    def get_orders_by_user(self) -> list[dict[str, Any]]:
        """Get orders for a specific user."""
        pass

    @abstractmethod
    def register(self, wallet_address: str) -> dict[str, Any]:
        """Register wallet with the scheduler service."""
        pass

    @abstractmethod
    def login(self, message: str, signature: str) -> dict[str, Any]:
        """Login with SIWE message and signature."""
        pass

    @abstractmethod
    def get_task_status(self, task_id: str) -> dict[str, Any]:
        """Get task status by task ID."""
        pass

    @abstractmethod
    def get_health_check(self) -> dict[str, Any]:
        """Get health check status from the scheduler service."""
        pass
