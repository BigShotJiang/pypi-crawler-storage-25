<h1 align="center">telemetry</h1>

<p align="center">

</p>

<p align="center">

<a href="https://opensource.org/licenses/MIT">
    <img src="https://img.shields.io/pypi/l/telemetry" alt="License">
</a>
<a href="https://pypi.org/project/exasol-telemetry-client/">
    <img src="https://img.shields.io/pypi/dm/exasol-telemetry-client" alt="Downloads">
</a>
<a href="https://pypi.org/project/exasol-telemetry-client/">
    <img src="https://img.shields.io/pypi/pyversions/exasol-telemetry-client" alt="Supported Python Versions">
</a>
<a href="https://pypi.org/project/exasol-telemetry-client/">
    <img src="https://img.shields.io/pypi/v/exasol-telemetry-client" alt="PyPi Package">
</a>
</p>

## 🚀 Features

## 🔌️ Prerequisites

- [Python](https://www.python.org/) >= 3.10

## 💾 Installation

```shell
pip install exasol-telemetry
```

## 📚 Documentation

[Python Client documentation](doc/client-python.rst)

For further details, check out the latest [documentation](https://exasol.github.io/telemetry/).
