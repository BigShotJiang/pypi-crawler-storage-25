import BSPDA

for id, pockets in BSPDA.get_multiple_protein_pockets(["1BID","1BIB"]).items():
    for p in pockets:
        print(f"   [POCKET {id} {p.pocket_id}] {p.classification}")
        print(f"     Vol: {p.volume} A^3 | Unp: {p.p_unp:.1f}% | Pos: {p.p_pos:.1f}% | Neg: {p.p_neg:.1f}%")

