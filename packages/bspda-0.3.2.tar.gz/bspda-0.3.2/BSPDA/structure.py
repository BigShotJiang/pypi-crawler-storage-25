import Bio.PDB
from rdkit import Chem
import numpy as np
import numpy.typing as npt

class ProteinStructure:
    """
    This class handles the initialization, downloading, and preprocessing of 3D protein structures.
    It bridges the gap between raw PDB files and the chemical/geometric representations needed 
    for cavity detection.
    """
    def __init__(self, pdb_id: str, work_dir: str):
        # Always convert to lowercase to avoid operating system file-naming mismatches
        self.pdb_id = pdb_id.lower()
        self.work_dir = work_dir
        
        # self.mol will hold the RDKit Molecule object
        self.mol: Chem.Mol | None = None
        
        # self.coords will hold an Nx3 numpy array of raw X, Y, Z coordinates.
        # This is isolated for fast math operations (like KDTree distance calculations) later.
        self.coords: npt.NDArray[np.float64] | None = None

    def downloadPDB(self) -> None:
        """
        Downloads a target PDB file from the RCSB database and loads it into RDKit.
        Includes a crucial fallback mechanism for common RDKit valency parsing errors,
        and safe error handling to prevent C++ crashes from killing batch runs.
        """
        # Initialize BioPython's PDB downloader
        pdbl = Bio.PDB.PDBList()
        
        # Retrieve the file from the internet and save it to the specified working directory.
        # It defaults to the '.ent' extension (PDB's native archival format).
        pdb_filepath: str = pdbl.retrieve_pdb_file(self.pdb_id, pdir=self.work_dir, file_format='pdb')

        # Use try-except to catch severe C++ level RDKit crashes without stopping the whole program
        try:
            # Attempt to load the text file into a 3D chemical representation.
            # removeHs=False: keep Hydrogen atoms because their presence affects the Van der Waals 
            # volume of the pocket and the calculation of partial charges.
            self.mol = Chem.MolFromPDBFile(pdb_filepath, removeHs=False)
            
            # RDKit is a strict chemical engine. PDB files often contain metal ions (Zn, Mg, Fe) sitting 
            # very close to protein residues. RDKit's default behavior ("proximityBonding=True") tries to 
            # draw covalent bonds between atoms that are close together. This frequently results in a metal 
            # atom having 6+ bonds, which breaks RDKit's strict valency rules, causing it to return `None`.
            if self.mol is None:
                print(f"[WARNING] Valency error in {self.pdb_id}. Adjusting proximityBonding...")
                
                # Retry loading, but tell RDKit to completely ignore distance-based bond guessing.
                # It will only rely on the standard amino-acid connectivity templates.
                self.mol = Chem.MolFromPDBFile(
                    pdb_filepath, 
                    removeHs=False, 
                    proximityBonding=False
                )
                
        except Exception as e:
            # If RDKit hits a catastrophic parsing error (like bad periodic table elements)
            print(f"[ERROR] RDKit encountered a fatal parsing error for {self.pdb_id}: {e}")
            self.mol = None

        # If it STILL fails, the PDB file is likely corrupted or entirely unrecognizable.
        if self.mol is None:
            raise ValueError(f"RDKit failed to process the clean structure of: {self.pdb_id}")

    def strip_htm(self) -> None:
        """
        Cleans the protein by removing bulk water, ions, and co-crystallized ligands. 
        This step is essential because if a crystal structure already has a drug or a cluster 
        of water molecules sitting inside its active site, our grid generator will physically 
        hit those atoms and think the pocket is a solid wall. To find the "empty space", 
        we must first evict all non-protein occupants.
        """
        # Standard RDKit Mol objects are static to make them fast and memory-efficient.
        # To delete atoms, we must convert it into a Read-Write Molecule (RWMol).
        rw_mol = Chem.RWMol(self.mol)
        
        # When deleting item at index 5, the item at index 6 instantly becomes index 5. 
        # If looping forward (0 to N), deleting an atom corrupts the remaining indices, 
        # leading to an 'Index Out Of Bounds' crash. By looping backwards (N to 0), 
        # deleting an atom only shifts the indices of atoms that have been already processed, 
        # leaving the upcoming atoms completely safe.
        for i in range(rw_mol.GetNumAtoms()-1, -1, -1):
            atom: Chem.Atom = rw_mol.GetAtomWithIdx(i)
            
            # Extract the specific PDB block information for this atom
            pdb_info: Chem.AtomPDBResidueInfo = atom.GetPDBResidueInfo()
            
            # In the PDB file format standard:
            # - 'ATOM' entries represent standard amino acid chain components.
            # - 'HETATM' (Hetero-atom) entries represent everything else (drugs, waters, buffer salts).
            # If there is no PDB info, or it is explicitly marked as a HETATM, then it is deleted.
            if not pdb_info or pdb_info.GetIsHeteroAtom():
                rw_mol.RemoveAtom(i)
                
        # Convert the editable molecule back to a standard, static RDKit Molecule
        self.mol = rw_mol.GetMol()
        
        # Extract the final Nx3 coordinate matrix for the cleaned structure.
        # This isolated numpy array will be fed directly to the GridGenerator and KDTree later.
        self.coords = self.mol.GetConformer().GetPositions()