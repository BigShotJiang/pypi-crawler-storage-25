import os
import sys
import argparse
import numpy as np
import pandas as pd
from scipy.spatial import distance
import Bio.PDB
import concurrent.futures

from BSPDA import get_pockets

def extract_coords(structure, res_code):
    """Generic coordinate extractor for any residue/ion code."""
    coords = []
    for model in structure:
        for chain in model:
            for residue in chain:
                if residue.get_resname().strip() == res_code:
                    for atom in residue:
                        coords.append(atom.get_coord())
    return np.array(coords)

def process_target_family(prot_id, group, output_dir, target_col, is_ion_mode):
    """
    Worker function that processes a single Protein_ID family.
    Runs entirely in its own separate CPU process.
    """
    # Initialize BioPython objects INSIDE the worker to avoid process-sharing crashes
    pdbl = Bio.PDB.PDBList()
    parser = Bio.PDB.PDBParser(QUIET=True)
    aligner = Bio.PDB.CEAligner()
    
    family_results = []
    print(f"\n[Worker Started] === Target Family: {prot_id} ===")
    
    ref_rows = group[group['Type'] == 'Complex'] if 'Type' in group.columns else group
    if ref_rows.empty:
        print(f"  [!] No 'Complex' reference for {prot_id}. Skipping.")
        return family_results
        
    ref_row = ref_rows.iloc[0]
    ref_pdb = ref_row['PDB_ID'].lower()
    target_code = ref_row[target_col]
    
    work_dir = os.path.join(output_dir, prot_id)
    os.makedirs(work_dir, exist_ok=True)
    
    # Download reference structure
    pdbl.retrieve_pdb_file(ref_pdb, pdir=work_dir, file_format='pdb')
    ref_file = os.path.join(work_dir, f"pdb{ref_pdb}.ent")
    
    for _, row in group.iterrows():
        tgt_pdb = row['PDB_ID'].lower()
        p_type = row.get('Type', 'Complex')
        
        print(f"[{prot_id}] ---> {tgt_pdb.upper()} ({p_type})")
        pdbl.retrieve_pdb_file(tgt_pdb, pdir=work_dir, file_format='pdb')
        tgt_file = os.path.join(work_dir, f"pdb{tgt_pdb}.ent")
        
        try:
            ref_st = parser.get_structure("ref", ref_file)
            
            if p_type == 'Unbound':
                tgt_st = parser.get_structure("tgt", tgt_file)
                aligner.set_reference(tgt_st)
                aligner.align(ref_st)
                true_coords = extract_coords(ref_st, target_code)
            else:
                tgt_st = parser.get_structure("tgt", tgt_file)
                true_coords = extract_coords(tgt_st, target_code)

            if len(true_coords) == 0:
                print(f"[{prot_id}]  [!] Target {target_code} not found. Skipping.")
                continue

            # RUN BSPDA PIPELINE
            predicted_pockets = get_pockets(input_pdb=tgt_file, working_dir=work_dir)
            predicted_pockets.sort(key=lambda x: x.volume, reverse=True)

            my_hit_rank, my_d_near, my_class = -1, float('inf'), "N/A"

            for rank, pocket in enumerate(predicted_pockets, start=1):
                centroid = np.mean(pocket.probes, axis=0)
                dist = np.min(distance.cdist([centroid], true_coords))
                
                if dist < my_d_near:
                    my_d_near = dist
                
                if dist <= 4.0 and my_hit_rank == -1:
                    my_hit_rank = rank
                    my_class = pocket.classification

            # Store Results
            status = "SUCCESS" if my_hit_rank != -1 else "FAILED"
            print(f"[{prot_id}]  Rank: {my_hit_rank} | D_near: {my_d_near:.2f} | {status}")

            res_entry = {
                "Protein_ID": prot_id,
                "PDB_ID": tgt_pdb.upper(),
                "Type": p_type,
                "Target_Code": target_code,
                "Hit_Rank": my_hit_rank if my_hit_rank != -1 else "N/A",
                "D_near_A": round(my_d_near, 2),
                "Predicted_Type": my_class,
                "Success": status
            }
            if is_ion_mode: res_entry["Target_Ion_Name"] = row.get('Ion_Name', 'Unknown')
            
            family_results.append(res_entry)

        except Exception as e:
            print(f"[{prot_id}]  [!] Error: {e}")
            
    return family_results

def run_pipeline_eval(input_csv, output_dir, max_workers):
    os.makedirs(output_dir, exist_ok=True)
    df = pd.read_csv(input_csv)
    
    # Detect Mode: Ion vs Ligand
    is_ion_mode = 'Ion_Code' in df.columns
    target_col = 'Ion_Code' if is_ion_mode else 'Target_Ligand'
    
    grouped = df.groupby('Protein_ID')
    all_results = []

    print(f"Starting parallel evaluation with {max_workers} CPU workers...")

    # PARALLEL EXECUTION BLOCK
    with concurrent.futures.ProcessPoolExecutor(max_workers=max_workers) as executor:
        # Submit all target families to the worker pool
        future_to_prot = {
            executor.submit(process_target_family, prot_id, group, output_dir, target_col, is_ion_mode): prot_id 
            for prot_id, group in grouped
        }
        
        # As each worker finishes its family, collect the results
        for future in concurrent.futures.as_completed(future_to_prot):
            try:
                family_results = future.result()
                all_results.extend(family_results) # Flatten the list of lists
            except Exception as exc:
                prot_id = future_to_prot[future]
                print(f"[!] Family {prot_id} generated an exception: {exc}")

    # Save to CSV
    output_csv = os.path.join(output_dir, "validation_results.csv")
    pd.DataFrame(all_results).to_csv(output_csv, index=False)
    print(f"\nDone! Results saved to {output_csv}")

def main_terminal_eval():
    parser = argparse.ArgumentParser(description="Unified BSPDA Evaluator")
    
    parser.add_argument("input", help="Input CSV (Ions or Ligands)")
    parser.add_argument("-o","--output", required=True, help="Output directory")
    parser.add_argument("-t","--threads", type=int, default=4, help="Number of parallel CPU processes to run")
    
    args = parser.parse_args()
    
    # Pass the parsed terminal arguments into your core function
    run_pipeline_eval(args.input, args.output, args.threads)

# --- 2. KEEP THIS FOR LOCAL TESTING ---
if __name__ == "__main__":
    main_terminal_eval()