import os
import sys
import argparse
import numpy as np
from rdkit import Chem

# Import all the specialized modules from the local package
from .structure import ProteinStructure
from .geometry import GridGenerator
from .detector import PocketDetector
from .classifier import PocketClassifier, PocketProperties
from .io import Exporter

# __all__ dictates the "Public API" of the package. If a user types `from cavity_surveil import *`, Python looks at this list to know exactly which classes and functions to give them. It hides internal/secret functions.
__all__ = [
    "ProteinStructure",
    "GridGenerator",
    "PocketDetector",
    "PocketClassifier",
    "PocketProperties",
    "Exporter",
    "terminal_pipeline",
    "get_pockets",
    "get_multiple_protein_pockets",
    "run_pipeline_eval"
]

def get_pockets(input_pdb: str, working_dir: str = os.getcwd()) -> list[PocketProperties]:
    struct = ProteinStructure(pdb_id=input_pdb, work_dir=working_dir)
    struct.downloadPDB()
    if struct.mol is None:
        raise ValueError(f"Failed to load PDB file: {input_pdb}. Ensure the path is correct.")
    struct.strip_htm()
    
    # 2. VDW Radii setup (required for Geometry and FreeSASA)
    ptable = Chem.GetPeriodicTable()
    vdw_radii = np.array([ptable.GetRvdw(atom.GetAtomicNum()) for atom in struct.mol.GetAtoms()])
    
    # 3. Generate 3D Grid & Apply Flood Fill
    grid_gen = GridGenerator(struct.coords, vdw_radii)
    surface_probes = grid_gen.get_valid_surface_points()
    
    # 4. Ray-casting Scoring & Clustering
    detector = PocketDetector(struct.coords)
    
    # Score probes to generate buriedness scores
    detector.score_probes(surface_probes)
   
    deep_mask = detector.scores > 18
    deep_probes = surface_probes[deep_mask]
    deep_scores = detector.scores[deep_mask]
    
    # Generate clusters
    clusters = detector.cluster_pockets(surface_probes)
    
    if not clusters:
        print("No valid pockets found. Exiting.")
        return []

    # 5. Chemical Classification
    classifier = PocketClassifier(struct.mol)
    pockets = classifier.analyze_clusters(deep_probes, deep_scores, clusters)

    return pockets

def get_multiple_protein_pockets(input_pdbs: list, working_dir: str = os.getcwd()) -> dict[str,list[PocketProperties]]:
    results = dict()
    for pdb in input_pdbs:
        results[pdb] = get_pockets(pdb,working_dir)
    return results

def terminal_pipeline(input_pdb: str, output_dir: str) -> list[PocketProperties]:
    """
    The main programmatic API. This is the clean, silent function meant to be 
    used inside Jupyter Notebooks or imported into other Python software.
    """
    # 1. Structure Preparation
    struct = ProteinStructure(pdb_id=input_pdb, work_dir=output_dir)
    struct.downloadPDB()
    if struct.mol is None:
        raise ValueError(f"Failed to load PDB file: {input_pdb}. Ensure the path is correct.")
    
    # Remove water and old drugs so the pockets are empty
    struct.strip_htm()
    
    # 2. Extract Van der Waals Radii (Needed for geometry grids)
    ptable = Chem.GetPeriodicTable()
    vdw_radii = np.array([ptable.GetRvdw(atom.GetAtomicNum()) for atom in struct.mol.GetAtoms()])
    
    # 3. Generate 3D Grid & Apply Flood Fill to get the protein's surface shell
    grid_gen = GridGenerator(struct.coords, vdw_radii)
    surface_probes = grid_gen.get_valid_surface_points()
    
    # 4. Ray-casting Scoring
    detector = PocketDetector(struct.coords)
    detector.score_probes(surface_probes)
   
    # Replicate the deep mask logic here so there is the exact filtered coordinate arrays to pass down into the Classifier later.
    deep_mask = detector.scores > 18
    deep_probes = surface_probes[deep_mask]
    deep_scores = detector.scores[deep_mask]
    
    # 5. Group the points into distinct volumes
    clusters = detector.cluster_pockets(surface_probes)
    
    # Safety catch: If it's a perfectly smooth protein with no pockets, stop here.
    if not clusters:
        print("No valid pockets found. Exiting.")
        return []

    # 6. Chemical Classification (Calculate SASA and Partial Charges)
    classifier = PocketClassifier(struct.mol)
    pockets = classifier.analyze_clusters(deep_probes, deep_scores, clusters)

    return pockets

def get_multiple_protein_pockets(input_pdbs: list, working_dir: str = os.getcwd()) -> dict[str,list[PocketProperties]]:
    """
    A convenience wrapper. It takes a list of PDB IDs, runs the pipeline on all of them,
    and returns a Dictionary mapping the PDB ID to its list of found pockets.
    """
    results = dict()
    for pdb in input_pdbs:
        results[pdb] = get_pockets(pdb, working_dir)
    return results

def terminal_pipeline(input_pdb: str, output_dir: str, is_multiple: bool) -> list[PocketProperties]:
    """
    The verbose orchestration function used for the Command Line Interface (CLI).
    It does exactly what get_pockets() does, but adds helpful `print()` statements 
    so the user can watch the progress in their terminal, and it triggers the Exporter.
    """
    print(f"--- Starting Pocket Detection Pipeline ---")
    print(f"Input file: {input_pdb}")
    print(f"Output directory: {output_dir}")
    
    os.makedirs(output_dir, exist_ok=True)
    
    # 1. Load and prepare the protein structure
    print("1. Loading protein structure...")
    struct = ProteinStructure(pdb_id=input_pdb, work_dir=output_dir)
    struct.downloadPDB()
    
    if struct.mol is None:
        raise ValueError(f"Failed to load PDB into Mol Structure file: {input_pdb}. Ensure the path is correct.")
    
    print(f"Downloaded PDB to: {struct.pdb_id}")
    struct.strip_htm()
    
    # 2. VDW Radii setup
    ptable = Chem.GetPeriodicTable()
    vdw_radii = np.array([ptable.GetRvdw(atom.GetAtomicNum()) for atom in struct.mol.GetAtoms()])
    
    # 3. Generate Grid
    print("2. Generating 3D grid and identifying surface points...")
    grid_gen = GridGenerator(struct.coords, vdw_radii)
    surface_probes = grid_gen.get_valid_surface_points()
    
    # 4. Ray-casting & Clustering
    print("3. Scoring buriedness and clustering pockets...")
    detector = PocketDetector(struct.coords)
    detector.score_probes(surface_probes)
    
    # NOTE: Because the `@_filter_shallow` decorator intercepted `cluster_pockets` 
    # and hid the filtering process inside itself, we manually recreate the filter here
    # so we have the exact `deep_probes` arrays to pass into the Chemistry Classifier next.
    deep_mask = detector.scores > 18
    deep_probes = surface_probes[deep_mask]
    deep_scores = detector.scores[deep_mask]
    
    clusters = detector.cluster_pockets(surface_probes)
    print(f"   -> Found {len(clusters)} valid pockets (>= 40 A^3).")
    
    if not clusters:
        print("No valid pockets found. Exiting pipeline.")
        return []

    # 5. Chemical Classification
    print("\n4. Analyzing pocket chemistry (SASA)...")
    classifier = PocketClassifier(struct.mol)
    pockets = classifier.analyze_clusters(deep_probes, deep_scores, clusters)
    
    # Print a beautiful terminal report of the final classifications
    for p in pockets:
        print(f"   [POCKET {p.pocket_id}] {p.classification}")
        print(f"     Vol: {p.volume} A^3 | Unp: {p.p_unp:.1f}% | Pos: {p.p_pos:.1f}% | Neg: {p.p_neg:.1f}%")
              
    # 6. Export step: Create visual files for PyMOL so the user can see the 3D result
    print("\n5. Exporting results...")
    pdb_filename = f"scored_pockets_{input_pdb}.pdb"
    pdb_out_path = os.path.join(output_dir, pdb_filename)
    
    # Generate the dummy atoms that represent the pocket volume
    Exporter.save_pdb(struct.mol, pockets, pdb_out_path)
    
    # Generate the Python/PyMOL macro script that colors everything beautifully
    if is_multiple:
        Exporter.write_pymol_multiple_scripts(output_dir, pdb_filename, len(pockets), input_pdb)
    else:
        Exporter.write_pymol_script(output_dir, pdb_filename, len(pockets), input_pdb)
    
    print("--- Pipeline Complete ---")
    return pockets

def main_terminal_run():
    """
    The Command Line Interface (CLI) entry point.
    This uses the 'argparse' library to read flags typed by the user in the terminal.
    For example: `python __init__.py 1bid -o ./results --multiple`
    """
    parser = argparse.ArgumentParser(description="3D Protein Pocket Detection & Classification Pipeline")
    
    # Positional argument (mandatory)
    parser.add_argument(
        "input", 
        type=str, 
        help="Path to the input PDB file."
    )

    # Optional flag for output directory (-o or --output)
    parser.add_argument(
        "-o", "--output", 
        type=str, 
        required=False,
        default= os.path.join(os.getcwd(),"scored_pockets.pdb"),
        help="Path to the output directory where PDBs and PyMOL scripts will be saved."
    )

    # Optional boolean flag (-m). If the user types it, it becomes True. Otherwise False.
    parser.add_argument(
        "-m", "--multiple", 
        action="store_true",
        help="Create Separated pyMol scripts instead of one with multiple scenes"
    )
    
    # Parse what the user actually typed in the terminal
    args = parser.parse_args()
    
    # Dispatch those typed variables into our main pipeline function
    # Execute the pipeline with parsed arguments
    terminal_pipeline(args.input, args.output, args.multiple)

# This standard Python idiom ensures that `main_terminal_run()` is ONLY executed if the user runs this file directly from the terminal (e.g., `python __init__.py`). If this file is merely IMPORTED by another script, it skips this block.
if __name__ == "__main__":
    main_terminal_run()