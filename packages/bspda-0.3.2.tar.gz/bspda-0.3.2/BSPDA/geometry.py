import numpy as np
import numpy.typing as npt
from scipy.spatial import KDTree
from scipy.ndimage import label

class GridGenerator:
    """
    This class generates a 3D grid (voxel space) around the protein to map out the 'empty space'.
    Instead of randomly searching for pockets, it systematically checks every coordinate 
    in a bounding box to build a precise 'mold' or 'skin' of the protein's surface.
    """
    def __init__(self, coords: npt.NDArray[np.float64], vdw_radii: npt.NDArray[np.float64], resolution: float = 1.0, padding: float = 8.0):
        self.coords = coords          # Exact X, Y, Z coordinates of all protein atoms
        self.vdw_radii = vdw_radii    # The physical size (Van der Waals radius) of each atom
        
        # resolution can be defined as the distance between our grid points. 
        # 1.0 Å is the gold standard because it provides high detail while 
        # keeping the number of total points computationally manageable.
        self.res = resolution         
        
        # 'padding' adds extra space around the extreme edges of the protein.
        # This guarantees the grid completely swallows the protein, and ensures 
        # the absolute corners of the grid are 100% guaranteed to be in empty space.
        self.padding = padding        

    def get_valid_surface_points(self) -> npt.NDArray[np.float64]:
        """
        Generates a 3D voxel grid, identifies the empty space, uses a flood-fill 
        algorithm to isolate the exterior solvent, and extracts a thin 'shell' 
        of grid points wrapping around the protein's surface.
        """
        # 1. Create the grid
        # Find the minimum and maximum X, Y, Z coordinates of the protein and stretch the box outward by the padding quantity (8.0 Å by default).
        min_coords: npt.NDArray[np.float64] = self.coords.min(axis=0) - self.padding
        max_coords: npt.NDArray[np.float64] = self.coords.max(axis=0) + self.padding
        
        # np.arange creates 1D measure for the X, Y, and Z axes, spaced by 1.0 Å.
        grid_x: npt.NDArray[np.float64] = np.arange(min_coords[0], max_coords[0], self.res)
        grid_y: npt.NDArray[np.float64] = np.arange(min_coords[1], max_coords[1], self.res)
        grid_z: npt.NDArray[np.float64] = np.arange(min_coords[2], max_coords[2], self.res)
        
        # Keep track of the 3D dimensions of the grid (e.g.: a grid of 60x50x55 points)
        grid_shape: tuple[int, int, int] = (len(grid_x), len(grid_y), len(grid_z))
        
        # np.meshgrid intersects the 3 rulers to create a solid 3D block of coordinates.
        xv, yv, zv = np.meshgrid(grid_x, grid_y, grid_z, indexing='ij')
        
        # Flatten the 3D block into a simple 2D list of [X, Y, Z] points so scipy's mathematical functions can process it.
        all_grid_points: npt.NDArray[np.float64] = np.column_stack((xv.ravel(), yv.ravel(), zv.ravel()))

        # 2. Spatial partitioning and clash detection
        # A KDTree organizes the protein atoms into a spatial map. Instead of measuring distance to all atoms, it instantly finds the closest one.
        protein_tree = KDTree(self.coords)
        # For every point in the hrid, find the absolute nearest protein atom.
        # 'distances' = distance to that atom. 'indices' = which atom it is.
        distances, indices = protein_tree.query(all_grid_points, k=1)    
        # To know if a grid point is "inside" an atom, one must subtract the atom's physical radius.
        # A voxel is considered "empty space" if its distance to the nearest atom's center 
        # is greater than that atom's Van der Waals radius PLUS an extra 1.0 Å buffer.
        # This 1.0 Å buffer mimics the size of a water molecule rolling over the surface.
        surface_distances: npt.NDArray[np.float64] = distances - self.vdw_radii[indices]
        is_empty_space_3d = (surface_distances >= 1.0).reshape(grid_shape)

        # 3. Flood-fill algorithm
        # is_empty_space_3d is a 3D matrix of True (empty space) and False (solid protein).
        # However, proteins have totally enclosed internal cavities that are not important either for this pipeline.
        # scipy.ndimage purs voxels into the grid. Connected grid spheres get grouped under a shared ID, and then identified as "True". Those inside the protein are identified as "False", since are not connected to the outerspace.
        labeled_space, _ = label(is_empty_space_3d)
        
        # Because 8.0 Å were used for padding, the point at coordinate [0, 0, 0] (the extreme corner of the box) is outside the protein.
        # Therefore, whatever label ID the corner got, is the "bulk solvent".
        is_bulk_solvent = (labeled_space == labeled_space[0, 0, 0]).ravel()
        
        # 4. Extract the solvent probe
        # A valid surface probe must be:
        # 1. Connected to the outside ocean (is_bulk_solvent == True)
        # 2. Within 4.5 Ångstroms of the protein's center atoms.
        # This deletes all the grid points too far of the protein to actually itneract with it.
        valid_mask = is_bulk_solvent & (distances <= 4.5)
        # Return only the exact [X, Y, Z] coordinates of the tight surface shell.
        # These points will be passed to detector.py to see which ones are buried in deep pockets.
        return all_grid_points[valid_mask]