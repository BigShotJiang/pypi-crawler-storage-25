import os
from rdkit import Chem
from .classifier import PocketProperties

class Exporter:
    """Handles writing the final 3D coordinates and visualization scripts to disk."""
    
    # Expand the PyMOL colors to 30 to ensure large proteins with many pockets do not immediately recycle colors, making visual distinction easier.
    PYMOL_COLORS = [
        "red", "blue", "green", "magenta", "yellow", 
        "cyan", "orange", "purple", "pink", "teal",
        "marine", "salmon", "limon", "wheat", "slate", 
        "sand", "violet", "ruby", "emerald", "aquamarine",
        "brown", "olive", "paleyellow", "lightblue", "lightpink", 
        "palegreen", "deepblue", "firebrick", "chocolate", "forest"
    ]

    @staticmethod
    def save_pdb(mol: Chem.Mol, pockets: list[PocketProperties], filepath: str) -> None:
        """Appends the pocket probes to the protein PDB and saves it."""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        
        # 1. Get the protein PDB block and remove the "END" marker sp probe atoms can be safely appended at the bottom.
        lines: list[str] = Chem.MolToPDBBlock(mol).splitlines()
        if lines and lines[-1] == "END":
            lines = lines[:-1] 

        # 2. Append all the probes as dummy Oxygen (O) atoms.
        atom_idx = 1
        for pocket in pockets:
            res_name = f"P{pocket.pocket_id:02d}"  # Creates unique residue names like P01, P02
            
            for p, score in zip(pocket.probes, pocket.scores):
                # PDB is a STRICT fixed-width text format. Spacing is mathematically important.
                # Here, we "trick" the format by putting our "buriedness score" into the 
                # B-factor column (normally reserved for temperature/flexibility).
                line = (f"HETATM{(atom_idx%99999):5d}  O   {res_name} P{(pocket.pocket_id%9999):4d}    "
                        f"{p[0]:8.3f}{p[1]:8.3f}{p[2]:8.3f}  1.00{score:6.2f}           O")
                lines.append(line)
                atom_idx += 1
                
        lines.append("END")

        with open(filepath, 'w') as f:
            f.write("\n".join(lines) + "\n")

    @staticmethod
    def write_pymol_multiple_scripts(out_dir: str, pdb_filename: str, num_pockets: int) -> None:
        """Generates the four specific .pml visualization scripts."""
        os.makedirs(out_dir, exist_ok=True)
        
        # 1. Common base settings
        # Loads the PDB, sets the protein as a semi-transparent surface, and hides the probes initially
        base_setup = f"""load {pdb_filename}, pocket_system
select protein_atoms, not resn P*
hide everything, pocket_system
show cartoon, protein_atoms
show surface, protein_atoms
set transparency, 0.5, protein_atoms
"""
        # 2. Protein surface coloring logic
        grey_protein = "color gray70, protein_atoms\n\n"
        # PDB files typically don't store partial charges. To visualize electrostatics natively in PyMOL, color known acidic residues (Asp, Glu) red and basic residues (Arg, Lys, His) blue.
        electrostatic_protein = """# Simulate Electrostatic Surface via Residues
color white, protein_atoms
color red, protein_atoms and resn asp+glu
color blue, protein_atoms and resn arg+lys+his
\n"""

        # 3. Pocket grids (dots) coloring logic
        # `spectrum b` reads the B-factor column (where we stored the buriedness score).
        # Yellow = Score 18 (shallow), Red = Score 30 (deepest).
        gradient_pockets = """# Gradient Pocket Grids based on Buriedness (B-factor)
select pocket_probes, resn P*
show spheres, pocket_probes
set sphere_scale, 0.25, pocket_probes
spectrum b, yellow_red, pocket_probes, minimum=18, maximum=30
\n"""

        # Iterates through every pocket and assigns a unique solid color to it.
        discrete_pockets = "# Discrete Pocket Grids based on Binding Site ID\n"
        for i in range(num_pockets):
            pkt_id = i + 1
            res_name = f"P{pkt_id:02d}"
            color = Exporter.PYMOL_COLORS[i % len(Exporter.PYMOL_COLORS)]
            discrete_pockets += (f"select pkt{pkt_id}, resn {res_name}\n"
                                 f"show spheres, pkt{pkt_id}\n"
                                 f"set sphere_scale, 0.3, pkt{pkt_id}\n"
                                 f"color {color}, pkt{pkt_id}\n")
        discrete_pockets += "\n"

        # 4. Common footer settings
        # Cleans up the background and lighting for better screenshots
        footer_pymol = """bg_color white\nset ray_shadows, 0\ndeselect\norient"""

        # 5. Assemble and write the 4 specific scripts
        # We simply concatenate the string blocks to form the 4 desired permutations
        scripts = {
            "1_grey_surface_gradient_dots.pml": base_setup + grey_protein + gradient_pockets + footer_pymol,
            "2_grey_surface_discrete_dots.pml": base_setup + grey_protein + discrete_pockets + footer_pymol,
            "3_electro_surface_gradient_dots.pml": base_setup + electrostatic_protein + gradient_pockets + footer_pymol,
            "4_electro_surface_discrete_dots.pml": base_setup + electrostatic_protein + discrete_pockets + footer_pymol
        }

        for filename, content in scripts.items():
            filepath = os.path.join(out_dir, filename)
            with open(filepath, 'w') as f:
                f.write(content)
                
        print(f"Generated 4 PyMOL visualization scripts in: {out_dir}")

    @staticmethod
    def write_pymol_script(out_dir: str, pdb_filename: str,  num_pockets: int, pbd_id: str = "") -> None:
        """Generates a single master .pml script with 4 interactive scenes."""
        os.makedirs(out_dir, exist_ok=True)
        filepath = os.path.join(out_dir, f"render_pockets_{pbd_id}.pml")
        
        # 1. Common base settings
        script = f"""load {pdb_filename}, pocket_system
select protein_atoms, not resn P*
select all_pockets, resn P*

hide everything, pocket_system
show cartoon, protein_atoms
show surface, protein_atoms
set transparency, 0.5, protein_atoms

show spheres, all_pockets
set sphere_scale, 0.3, all_pockets

bg_color white
set ray_shadows, 0
deselect

"""
        # 2. Helper blocks
        # Define these strings once to reuse them when building the scenes
        grey_protein = "color gray70, protein_atoms\n"
        
        electro_protein = """color white, protein_atoms
color red, protein_atoms and resn asp+glu
color blue, protein_atoms and resn arg+lys+his
"""
        gradient_pockets = "spectrum b, yellow_red, all_pockets, minimum=18, maximum=30\n"
        
        discrete_pockets = ""
        for i in range(num_pockets):
            pkt_id = i + 1
            color = Exporter.PYMOL_COLORS[i % len(Exporter.PYMOL_COLORS)]
            discrete_pockets += f"color {color}, resn P{pkt_id:02d}\n"

        # 4. Scene construction
        
        # Scene F1: Grey Surface + Discrete Pockets
        script += "### SCENE F1: Grey Surface + Discrete Pockets ###\n"
        script += grey_protein + discrete_pockets
        script += "scene F1, store, Grey_Discrete\n\n"

        # Scene F2: Grey Surface + Gradient Pockets
        script += "### SCENE F2: Grey Surface + Gradient Pockets ###\n"
        script += grey_protein + gradient_pockets
        script += "scene F2, store, Grey_Gradient\n\n"

        # Scene F3: Electrostatic Surface + Discrete Pockets
        script += "### SCENE F3: Electrostatic Surface + Discrete Pockets ###\n"
        script += electro_protein + discrete_pockets
        script += "scene F3, store, Electro_Discrete\n\n"

        # Scene F4: Electrostatic Surface + Gradient Pockets
        script += "### SCENE F4: Electrostatic Surface + Gradient Pockets ###\n"
        script += electro_protein + gradient_pockets
        script += "scene F4, store, Electro_Gradient\n\n"

        # 4. Finalize
        # Set default view to F1 and orient the camera
        script += "scene F1\norient\n"

        with open(filepath, 'w') as f:
            f.write(script)
            
        print(f"Generated master PyMOL script with scenes in: {out_dir}")
        print(" -> In PyMOL, use keys F1, F2, F3, and F4 to switch between views")
