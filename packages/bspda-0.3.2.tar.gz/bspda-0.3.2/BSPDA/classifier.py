import numpy as np
import numpy.typing as npt
from scipy.spatial import KDTree
from rdkit import Chem
from rdkit.Chem import rdPartialCharges
import freesasa
from dataclasses import dataclass

@dataclass
class PocketProperties:
    """
    A lightweight data structure to hold the complete chemical and geometric profile of a single pocket. Using a @dataclass makes it very easy to pass this data to pandas dataframes or save it as a JSON later.
    """
    pocket_id: int
    volume: int
    classification: str
    p_unp: float                     # Percentage of Unpolar (hydrophobic) surface area
    p_pos: float                     # Percentage of Positive surface area
    p_neg: float                     # Percentage of Negative surface area
    lining_residues: list[str]       # The specific amino acids forming the pocket
    probes: npt.NDArray[np.float64]  # The 3D coordinates of the empty space
    scores: npt.NDArray[np.float64]  # The buriedness scores of those coordinates

class PocketClassifier:
    """
    This class bridges 3D geometry with computational chemistry. It calculates the Solvent Accessible Surface Area (SASA) and partial charges of the protein, then maps those chemical properties onto the pockets discovered earlier.
    """
    def __init__(self, mol: Chem.Mol):
        # Work on a copy of the molecule because calculating charges requires modifying the chemical graph (adding hydrogens).
        self.raw_mol = mol 
        self.coords: npt.NDArray[np.float64] | None = None
        self.tree: KDTree | None = None
        self.fs_result: freesasa.Result | None = None
        self.mol_h: Chem.Mol | None = None
        
        # Pre-calculate the chemistry math right when the object is created
        self._prepare_chemistry()

    def _prepare_chemistry(self) -> None:
        """
        Calculates global SASA areas, adds hydrogens, and calculates partial charges. By doing this once for the whole protein, a remarkable amount of time is saved compared to calculating it from scratch for every single pocket.
        """
        # 1. Free-SASA (Free-Solvent Accessible Surface Area)
        # SASA informs of how much of an atom's surface is exposed to the exterior solvent (which also include what is inside of the pocket), as opposed to being buried inside the protein core.
        ptable = Chem.GetPeriodicTable()
        # FreeSASA needs the Van der Waals radius for every atom based on its element.
        radii = [ptable.GetRvdw(a.GetAtomicNum()) for a in self.raw_mol.GetAtoms()]
        self.coords = self.raw_mol.GetConformer().GetPositions()
        # FreeSASA requires a flat 1D list of coordinates (e.g., [x1, y1, z1, x2, y2, z2...])
        flat_coords = self.coords.flatten().tolist()
        self.fs_result = freesasa.calcCoord(flat_coords, radii)
        # Build the spatial KDTree for the protein atoms to easily find them later.
        self.tree = KDTree(self.coords)
        
        # 2. Gasteiger partial charges
        # Gasteiger charges evaluate how electronegativity pulls electrons across covalent bonds. For instance, Oxygen pulls electrons away from Carbon, making Oxygen slightly negative and Carbon slightly positive.
        # Because hydrogen atoms share electrons, they must be added to the RDKit molecule before calculating charges, otherwise the valency math is wrong.
        self.mol_h = Chem.AddHs(self.raw_mol, addCoords=True)
        rdPartialCharges.ComputeGasteigerCharges(self.mol_h)

    def _classify_single_pocket(self, pocket_id: int, probes: npt.NDArray[np.float64], scores: npt.NDArray[np.float64]) -> PocketProperties:
        """
        Evaluates the chemistry of a single pocket by analyzing the specific atoms that make up its walls, and then assigns it a biological classification.
        """
        # 1. Find the Wall Atoms
        # Returns a list of lists (one list of neighboring atoms per probe, within 4.5 Å).
        atoms_near: list[list[int]] = self.tree.query_ball_point(probes, r=4.5)
        # Flatten the list of lists into a Python 'set'. A set automatically deletes duplicates. If 5 different probes all detect the same Carbon atom, that Carbon atom is counted only once!
        pocket_atom_idx: set[int] = {atom for sublist in atoms_near for atom in sublist}
        
        a_pos, a_neg, a_unp, total_s = 0.0, 0.0, 0.0, 0.0
        pocket_residues = set() # To store unique amino acid names
        
        # 2. Analyze the chemistry of the wall
        for idx in pocket_atom_idx:
            # Get the exact exposed surface area of this specific atom
            area: float = self.fs_result.atomArea(idx)
            # Retrieve the Gasteiger partial charge calculated earlier
            q: float = self.mol_h.GetAtomWithIdx(idx).GetDoubleProp('_GasteigerCharge')
            
            total_s += area
            # We categorize the atom's surface area based on its electrical charge.
            # +/- 0.15 is a standard cheminformatics threshold for "highly polar".
            # Everything between -0.15 and +0.15 is considered non-polar (oily/hydrophobic).
            if q > 0.15: 
                a_pos += area
            elif q < -0.15: 
                a_neg += area
            else: 
                a_unp += area
            # Extract the amino acid identity (e.g., "TRP", "LYS") from the raw PDB data.
            atom = self.raw_mol.GetAtomWithIdx(idx)
            pdb_info = atom.GetPDBResidueInfo()
            if pdb_info:
                res_name = pdb_info.GetResidueName().strip()
                res_num = pdb_info.GetResidueNumber()
                chain_id = pdb_info.GetChainId().strip()
                # Format string to have the format: "TRP156(A)"
                pocket_residues.add(f"{res_name}{res_num}({chain_id})")
        # Sort the residues numerically so they look clean in the final report. The lambda function strips the letters, leaving just the number (e.g., "156") for sorting.
        sorted_residues = sorted(list(pocket_residues), key=lambda x: int(''.join(filter(str.isdigit, x))))
        # The volume is simply the number of 1.0 Å grid points that fit inside the pocket.
        volume: int = len(probes)
        # Safety catch to prevent division by zero in case a weird pocket has 0 surface area
        norm_area = total_s if total_s > 0 else 1.0
        # 3. Calculate final percentages
        p_unp = (a_unp / norm_area) * 100
        p_pos = (a_pos / norm_area) * 100
        p_neg = (a_neg / norm_area) * 100

        # 4. Heuristics classification
        # We apply biological rules of thumb (based on the references) to guess the pocket's biological function.
        if volume > 500:
            classification = "Primary Binding Site"
        # High negative surface binds positive co-factors/metals
        elif p_neg > 50:
            classification = "Electrostatic Anchor Site for Cations"
        # High positive surface binds positive co-factors/metals
        elif p_pos > 50:
            classification = "Electrostatic Anchor Site for Anions"
        elif p_unp > 60:
            classification = "Hydrophobic Patch"
        else:
            classification = "Unkown Pocket"
            
        # Pack all this computed data into a neat DataClass and return it
        return PocketProperties(
            pocket_id=pocket_id,
            volume=volume,
            classification=classification,
            p_unp=p_unp,
            p_pos=p_pos,
            p_neg=p_neg,
            lining_residues=sorted_residues,
            probes=probes,
            scores=scores
        )
    
    def analyze_clusters(
        self, 
        deep_probes: npt.NDArray[np.float64], 
        deep_scores: npt.NDArray[np.int_], 
        clusters: list[list[int]]
    ) -> list[PocketProperties]:
        """
        The main public method. It loops through the groups of points identified by the PocketDetector and dispatches them one by one to the classifier.
        """
        results: list[PocketProperties] = []
        
        for i, cluster_indices in enumerate(clusters):
            # Extract the actual 3D coordinates and scores for this specific group
            cluster_probes = deep_probes[cluster_indices]
            cluster_scores = deep_scores[cluster_indices]
            # Send them to the chemistry engine
            pocket_data = self._classify_single_pocket(i + 1, cluster_probes, cluster_scores)
            results.append(pocket_data)
        # Return a list of fully characterized PocketProperties objects
        return results