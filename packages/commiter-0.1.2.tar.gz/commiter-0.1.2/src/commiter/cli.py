import click
import sys
import time
import fnmatch
from typing import List
from .git import is_git_repository, execute_commit, execute_push, create_and_checkout_branch, get_changed_files
from .config import load_or_create_config, save_config
from .tui import run_tui
from .ai import fetch_proposed_commits, is_ollama_running, get_ollama_models, ensure_ollama_running, post_process_commits

def run_setup(config: dict):
    click.secho("\n--- commiter interactive setup ---", fg="cyan", bold=True)
    click.secho("Let's configure your AI and commit preferences.\n")
    
    config["provider"] = click.prompt("AI Provider", type=click.Choice(["gemini", "openai", "anthropic", "ollama"]), default=config.get("provider", "gemini"))
    
    if config["provider"] == "ollama":
        click.secho("\n--- Ollama Configuration ---", fg="cyan")
        if not ensure_ollama_running():
             click.secho("Error: Could not launch Ollama. Please ensure it's installed and in your PATH.", fg="red")
             config["ollama_model"] = click.prompt("Enter Ollama model name manually", default="llama3")
        else:
             # If it was freshly started, we need to wait and show info
             if not is_ollama_running():
                 tips = [
                     "Use 'commiter -c 3' for quick atomic commits.",
                     "Ctrl+K in TUI opens the professional Command Palette.",
                     "Atomic commits keep your git history clean and readable.",
                     "--push flag automatically pushes after successful commits.",
                     "Include only specific files with '--include *.py'.",
                     "Truncate huge diffs automatically to save AI context window."
                 ]
                 import random
                 random.shuffle(tips)
                 
                 with click.progressbar(length=10, label="Starting Ollama service...") as bar:
                     for i in range(10):
                         if is_ollama_running():
                             bar.update(10)
                             break
                         # Show a tip instead of just waiting
                         bar.label = f"Starting Ollama... [cyan]Tip: {tips[i % len(tips)]}[/cyan]"
                         time.sleep(1)
                         bar.update(1)
             
             if not is_ollama_running():
                 click.secho("\nWarning: Ollama is taking too long to start. Manual input required.", fg="yellow")
                 config["ollama_model"] = click.prompt("Enter Ollama model name manually", default="llama3")
             else:
                 models = get_ollama_models()
                 if models:
                     click.secho(f"\nDetected local models: {', '.join(models)}", fg="green")
                     config["ollama_model"] = click.prompt("Select model", type=click.Choice(models), default=models[0] if models else "llama3")
                 else:
                     click.secho("\nNo models detected. Download some with 'ollama run <model>'.", fg="yellow")
                     config["ollama_model"] = click.prompt("Enter Ollama model name manually", default="llama3")
        # Ollama usually doesn't need an API key for local use
        config["api_key"] = "LOCAL"
    else:
        current_key = config.get("api_key", "")
        if current_key in ["YOUR_API_KEY_HERE", "LOCAL"]:
            current_key = ""
        prompt_key_text = f"{config['provider'].capitalize()} API Key"
        config["api_key"] = click.prompt(prompt_key_text, default=current_key or "YOUR_API_KEY_HERE", hide_input=True)

    
    click.secho("\nPersona options formatting:", fg="yellow")
    click.secho("1. senior dev: properly formatted and correct")
    click.secho("2. junior dev: less structured but highly detailed")
    click.secho("3. newbie:     not heavily structured, very simple & explanatory in simple words")
    config["persona"] = click.prompt("Commit persona", type=click.Choice(["senior dev", "junior dev", "newbie"]), default=config.get("persona", "senior dev"))
    
    save_config(config)
    
    # Optional connection test
    if config["api_key"] not in ["", "YOUR_API_KEY_HERE", "LOCAL"]:
        if click.confirm("\nWould you like to test the API connection now?"):
            from .ai import validate_api_key
            click.echo("Testing connection...")
            if validate_api_key(config["provider"], config["api_key"]):
                click.secho("✓ Connection successful!", fg="green")
            else:
                click.secho("✗ Connection failed! Please check your API key and internet.", fg="red")

    click.secho("\nConfiguration saved!\n", fg="green", bold=True)

def print_preview(commits):
    try:
        from rich.console import Console
        from rich.table import Table
        console = Console()
        table = Table(title="Proposed Commits Preview")
        table.add_column("Message", style="cyan")
        table.add_column("Files", style="green")
        for c in commits:
            table.add_row(c.get("message", "No message"), ", ".join(c.get("files", [])))
        console.print(table)
    except ImportError:
        # Fallback if rich is somehow missing
        for i, c in enumerate(commits, 1):
            click.secho(f"\n{i}. {c.get('message', '')}", fg="cyan")
            click.secho(f"   Files: {', '.join(c.get('files', []))}", fg="green")

def filter_files(files: List[str], include: str, exclude: str) -> List[str]:
    """Filter list of files based on include/exclude glob patterns."""
    filtered = files
    if include:
        filtered = [f for f in filtered if fnmatch.fnmatch(f, include)]
    if exclude:
        filtered = [f for f in filtered if not fnmatch.fnmatch(f, exclude)]
    return filtered

@click.group(invoke_without_command=True)
@click.option("--config-file", help="Path to override config.toml.")
@click.option("--config", "setup_config", is_flag=True, help="Set up or modify your configuration.")
@click.option("-c", "--commits", type=int, help="Target number of commits for headless mode.")
@click.option("-a", "--auto", is_flag=True, help="Automatically determine the number of commits.")
@click.option("-y", "--yes", is_flag=True, help="Skip confirmation prompts in headless mode.")
@click.option("--dry-run", is_flag=True, help="Print proposed commits without making git changes.")
@click.option("--preview", is_flag=True, help="Show a rich table preview of the proposed commits.")
@click.option("-m", "--context", help="Additional context to guide the AI commit generation.")
@click.option("-p", "--persona", help="Override the AI persona.")
@click.option("--model", help="Explicitly set the AI model to use.")
@click.option("--no-optimize", is_flag=True, help="Do not truncate/optimize the git diff before sending to AI.")
@click.option("--include", help="Glob pattern to only include specific files.")
@click.option("--exclude", help="Glob pattern to exclude specific files.")
@click.option("--branch", help="Create and checkout a new branch before committing.")
@click.option("--push", is_flag=True, help="Automatically run git push after successful commits.")
@click.option("-v", "--verbose", is_flag=True, help="Enable verbose output.")
@click.pass_context
def main(ctx, config_file, setup_config, commits, auto, yes, dry_run, preview, context, persona, model, no_optimize, include, exclude, branch, push, verbose):
    """commiter — AI-powered git commit grouping."""
    if ctx.invoked_subcommand is not None:
        return

    config = load_or_create_config(config_file)
    
    if setup_config or config.get("api_key", "") in ["", "YOUR_API_KEY_HERE"]:
        run_setup(config)
        if setup_config:
            return

    if not is_git_repository():
        click.secho("Error: Not a git repository.", fg="red", err=True)
        sys.exit(1)
        
    if config.get("provider") == "ollama" and not is_ollama_running():
        click.secho("Starting Ollama service...", fg="cyan")
        if ensure_ollama_running():
            for _ in range(10):
                if is_ollama_running():
                    break
                time.sleep(1)
        if not is_ollama_running():
            click.secho("Error: Ollama service is not running. Start it first with 'ollama serve'.", fg="red", err=True)
            sys.exit(1)

    # Remote check
    from .git import is_behind_remote
    if is_behind_remote():
        click.secho("Warning: Your branch is behind remote. You should probably 'git pull' first.", fg="yellow", bold=True)
        if not yes and not click.confirm("Continue anyway?"):
            sys.exit(0)

    is_headless = bool(commits) or auto or dry_run or include or exclude or branch
    
    if branch:
        click.secho(f"🌿 Creating and Checking out branch: {branch}...", fg="cyan")
        try:
            create_and_checkout_branch(branch)
        except Exception as e:
            click.secho(f"Error: {e}", fg="red", err=True)
            sys.exit(1)

    if is_headless:
        # Determine files to consider
        all_changed = [f.path for f in get_changed_files()]
        target_files = filter_files(all_changed, include, exclude)
        
        if not target_files:
            click.secho("No files to commit after filtering.", fg="yellow")
            sys.exit(0)
            
        if verbose:
            click.secho(f"Targeting {len(target_files)} files: {', '.join(target_files)}", fg="dim")

        req_count = "auto" if auto else (commits or "auto")
        
        # Check for git conflicts
        from .git import has_unmerged_paths
        if has_unmerged_paths():
            click.secho("Error: Git conflicts detected. Resolve them before committing.", fg="red", err=True)
            sys.exit(1)
        
        # Show Tool Tips before fetching
        tips = [
            "Use 'commiter -c 3' for quick atomic commits.",
            "Ctrl+K in TUI opens the professional Command Palette.",
            "Atomic commits keep your git history clean and readable.",
            "--push flag automatically pushes after successful commits.",
            "Include only specific files with '--include *.py'.",
            "Truncate huge diffs automatically to save AI context window."
        ]
        import random
        click.secho(f"Tip: {random.choice(tips)}", fg="cyan", italic=True)

        click.secho(f"Fetching proposed commits (Requested: {req_count})...", fg="blue")
        
        try:
            import subprocess
            branch_result = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True, check=False)
            curr_branch = branch_result.stdout.strip()
            if curr_branch:
                b_context = f"Branch context: {curr_branch}"
                context = f"{b_context}\n{context}" if context else b_context
        except Exception:
            pass

        try:
            proposed = fetch_proposed_commits(
                config, 
                req_count, 
                context=context, 
                persona_override=persona,
                model_override=model,
                optimize=not no_optimize,
                paths=target_files
            )
        except Exception as e:
            click.secho(f"Error: {e}", fg="red", err=True)
            sys.exit(1)
            
        # Apply 'One file, one commit' rule
        proposed = post_process_commits(proposed)
            
        if not proposed:
            click.secho("No commits proposed after applying 'One file, one commit' logic.", fg="yellow")
            sys.exit(0)
            
        if preview or dry_run or verbose:
            print_preview(proposed)
            
        if dry_run:
            click.secho("\nDry run complete. No commits were executed.", fg="yellow")
            sys.exit(0)
            
        if not yes:
            # Always show preview before confirmation in interactive headless mode
            # even if --preview wasn't explicitly passed.
            if not preview and not verbose:
                print_preview(proposed)
                
            if not click.confirm(f"\nReady to execute {len(proposed)} commits?"):
                click.secho("Aborted.", fg="yellow")
                sys.exit(0)
                
        # Execute natively
        click.secho("\nExecuting commits...", fg="cyan", bold=True)
        i = 1
        executed_count = 0
        while i <= len(proposed):
            commit = proposed[i-1]
            msg = commit.get("message", "Commit")
            files = commit.get("files", [])
            
            click.secho(f"({i}/{len(proposed)}) Committing: {msg}... ", nl=False, fg="cyan")
            try:
                result = execute_commit(files, msg)
                if result == "SKIPPED_NO_CHANGES":
                    click.secho("SKIPPED (No changes remaining)", fg="yellow")
                else:
                    click.secho(f"✓ {result}", fg="green")
                    executed_count += 1
                i += 1
            except Exception as e:
                click.secho(f"✗ Failed! {e}", fg="red")
                if yes:
                    click.secho("Halting due to failure (--yes mode).", fg="red")
                    break
                
                choice = click.prompt(
                    "\n[R]etry current, [S]kip, [M]anually edit message, [A]bort",
                    type=click.Choice(["r", "s", "m", "a"], case_sensitive=False),
                    default="r"
                ).lower()
                
                if choice == "r":
                    continue
                elif choice == "s":
                    i += 1
                    continue
                elif choice == "m":
                    new_msg = click.prompt("New commit message", default=msg)
                    proposed[i-1]["message"] = new_msg
                    continue
                else: # abort
                    click.secho("Aborted remaining commits.", fg="yellow")
                    break
        
        if push:
            click.secho("\nPushing to remote...", fg="cyan", bold=True)
            try:
                output = execute_push()
                click.secho(f"✓ Push successful:\n{output}", fg="green")
            except Exception as e:
                click.secho(f"✗ Push failed! {e}", fg="red")
                
        if executed_count > 0:
            import json
            from pathlib import Path
            try:
                state_file = Path.home() / ".commiter" / "last_run.json"
                with open(state_file, "w") as f:
                    json.dump({"commits": executed_count}, f)
            except Exception: pass
                
        sys.exit(0)
    
    # Standard Interactive TUI
    if not is_headless:
        # Quick check for files, but don't exit since TUI has its own refresh
        if not get_changed_files():
            click.secho("Notice: No changes detected yet. Opening TUI (you can stage/modify files and hit 'r' to refresh).", fg="yellow")
            
    selected_commits = run_tui(config)
    
    if selected_commits is not None:
        if len(selected_commits) > 0:
            import json
            from pathlib import Path
            try:
                state_file = Path.home() / ".commiter" / "last_run.json"
                with open(state_file, "w") as f:
                    json.dump({"commits": len(selected_commits)}, f)
            except Exception: pass
        click.secho("Execution finished!", fg="green")

@main.command()
def undo():
    """Undo the commits from the last commiter run."""
    import json
    import subprocess
    from pathlib import Path
    
    state_file = Path.home() / ".commiter" / "last_run.json"
    if not state_file.exists():
        click.secho("Error: No previous commiter run found.", fg="red", err=True)
        sys.exit(1)
        
    try:
        with open(state_file, "r") as f:
            state = json.load(f)
        count = state.get("commits", 0)
        if count <= 0:
            click.secho("Notice: Last run had 0 executed commits.", fg="yellow")
            sys.exit(0)
            
        if click.confirm(f"Are you sure you want to undo the last {count} commits? (This will keep your file changes)"):
            subprocess.run(["git", "reset", "--soft", f"HEAD~{count}"], check=True)
            click.secho(f"✓ Successfully ran 'git reset --soft HEAD~{count}'!", fg="green", bold=True)
            state_file.unlink(missing_ok=True)
    except subprocess.CalledProcessError:
        click.secho("Error: Failed to reset git HEAD. You might not have enough commits.", fg="red", err=True)
    except Exception as e:
        click.secho(f"Error reading last run state: {e}", fg="red", err=True)

@main.command()
def init():
    """Start and connect to the configured AI service automatically."""
    from .ai import ensure_ollama_running, is_ollama_running, validate_api_key
    import time
    import os
    
    click.secho("Initializing Commiter...", fg="cyan", bold=True)
    config = load_or_create_config()
    provider = config.get("provider", "gemini")
    
    if provider == "ollama":
        click.secho("Checking Ollama service...", fg="cyan")
        
        if is_ollama_running():
            click.secho("✓ Ollama is already running!", fg="green")
            sys.exit(0)
            
        click.secho("Starting Ollama background process...", fg="cyan")
        if ensure_ollama_running():
            with click.progressbar(length=10, label="Waiting for Ollama to boot...") as bar:
                for _ in range(10):
                    if is_ollama_running():
                        bar.update(10)
                        break
                    time.sleep(1)
                    bar.update(1)
                    
        if is_ollama_running():
            click.secho("\n✓ Successfully started and connected to Ollama!", fg="green", bold=True)
        else:
            click.secho("\n✗ Failed to start Ollama. Ensure it is installed and added to your PATH.", fg="red", err=True)
            sys.exit(1)
    else:
        api_key = os.environ.get("COMMITER_API_KEY") or config.get("api_key")
        
        click.secho(f"Checking connection to {provider.capitalize()} API...", fg="cyan")
        
        if not api_key or api_key == "YOUR_API_KEY_HERE":
            click.secho(f"✗ No valid API key found for {provider.capitalize()}. Please run 'commiter --config' to set it up.", fg="red", err=True)
            sys.exit(1)
            
        if validate_api_key(provider, api_key):
            click.secho(f"✓ Successfully connected to {provider.capitalize()} API!", fg="green", bold=True)
        else:
            click.secho(f"✗ Failed to connect to {provider.capitalize()} API. Please check your API key and internet connection.", fg="red", err=True)
            sys.exit(1)

if __name__ == "__main__":
    main()
