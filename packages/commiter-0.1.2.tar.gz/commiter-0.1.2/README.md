# Commiter AI 🤖

AI-powered git commit grouping. Intelligently splits your messy changes into atomic, well-described commits.

## Features
- **Intelligent Grouping**: Automatically groups lines and files into logical commits using AI.
- **Interactive TUI**: Review and refine proposed commits in a beautiful terminal interface.
- **Headless CLI**: High-performance CLI flags for power users.
- **Persona Support**: Choose between "senior dev", "junior dev", or "newbie" commit styles.
- **Diff Optimization**: Handles large diffs by intelligently truncating less relevant parts.
- **Filtering**: Target specific files or patterns for commit.
- **Branching**: Create new branches on the fly.
- **Auto-Push**: Seamlessly push your changes after committing.


## Quick Start
Run `commiter` to start the interactive TUI. Use arrow keys to navigate, `Space` to toggle commits, and `Enter` to execute.

## Power User CLI
Commiter supports a wide range of flags for quick headless execution:

### Basic Headless Flow
```bash
# Auto-group all changes and execute
commiter --auto --yes

# Auto-group and preview before confirming
commiter --auto --preview

# Instruct AI to make exactly 3 commits
commiter --commits 3 --yes
```

### Filtering and Context
```bash
# Only consider python files in src/
commiter --auto --include "src/*.py" --preview

# Exclude documentation
commiter --auto --exclude "docs/*"

# Provide specific hints to the AI
commiter --auto --context "Refactor the authentication logic to use JWT"
```

### Workflow Automation
```bash
# Create a new branch, commit everything, and push
commiter --auto --branch feature/login-v2 --yes --push

# Do a dry run to see what AI suggests without changing anything
commiter --auto --dry-run
```

### Advanced Overrides
```bash
# Override the AI model for a single run
commiter --auto --model gemini-2.0-flash

# Disable diff truncation (send the full diff to AI)
commiter --auto --no-optimize

# Override the commit persona
commiter --auto --persona "junior dev"
```

## Requirements
- Python >= 3.10
- Git
- Valid API key for Gemini (default), OpenAI, or Anthropic.

## Configuration
On first run, `commiter` will guide you through an interactive setup to save your API key and preferences to `~/.commiter/config.toml`. You can always re-run the setup with:
```bash
commiter --config
```

## License
MIT
