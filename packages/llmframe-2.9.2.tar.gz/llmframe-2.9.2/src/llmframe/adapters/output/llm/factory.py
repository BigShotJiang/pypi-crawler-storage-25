"""Public factories for ready-to-use shared LLM adapters."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from llmframe.adapters.output.persistence import JsonFileBatchRequestStoreAdapter, JsonFileWriterAdapter

from .llm_adapter import LlmAdapter
from .providers.openai import build_openai_provider

if TYPE_CHECKING:
    from llmframe.application.ports import BatchRequestStorePort, JsonArtifactWriterPort

    from .providers.openai import OpenAIClientSettings

DEFAULT_BATCH_REQUEST_OUTPUT_DIR = Path("artifacts/llm-batches")
DEFAULT_DEBUG_JSON_OUTPUT_DIR = Path("artifacts/llm-debug")


def _resolve_batch_request_store(
    *,
    batch_request_store: BatchRequestStorePort | None,
    batch_request_output_dir: Path | None,
) -> BatchRequestStorePort:
    """Resolve the batch request store used by the public factory."""
    if batch_request_store is not None:
        return batch_request_store

    return JsonFileBatchRequestStoreAdapter(base_dir=batch_request_output_dir or DEFAULT_BATCH_REQUEST_OUTPUT_DIR)


def _resolve_debug_json_writer(
    *,
    debug_json_writer: JsonArtifactWriterPort | None,
    debug_json_enabled: bool,
    debug_json_output_dir: Path | None,
) -> JsonArtifactWriterPort | None:
    """Resolve the debug JSON writer used by the public factory."""
    if debug_json_writer is not None:
        return debug_json_writer
    if not debug_json_enabled:
        return None
    return JsonFileWriterAdapter(base_dir=debug_json_output_dir or DEFAULT_DEBUG_JSON_OUTPUT_DIR)


def build_openai_llm_adapter(  # noqa: PLR0913
    *,
    settings: OpenAIClientSettings,
    model: str,
    batch_request_store: BatchRequestStorePort | None = None,
    batch_request_output_dir: Path | None = None,
    debug_json_writer: JsonArtifactWriterPort | None = None,
    debug_json_enabled: bool = False,
    debug_json_output_dir: Path | None = None,
) -> LlmAdapter:
    """Build a ready-to-use shared ``LlmAdapter`` backed by OpenAI.

    Args:
        settings: OpenAI transport configuration.
        model: Model identifier used for text and structured requests.
        batch_request_store: Optional persistent store for submitted batch metadata.
        batch_request_output_dir: Optional output directory used for the default batch request store.
        debug_json_writer: Optional writer for request/response debug snapshots.
        debug_json_enabled: Whether debug snapshot writing is enabled.
        debug_json_output_dir: Optional output directory used for the default JSON file writer.

    Returns:
        A provider-neutral ``LlmAdapter`` configured with an OpenAI provider.
    """
    resolved_debug_json_writer = _resolve_debug_json_writer(
        debug_json_writer=debug_json_writer,
        debug_json_enabled=debug_json_enabled,
        debug_json_output_dir=debug_json_output_dir,
    )
    resolved_batch_request_store = _resolve_batch_request_store(
        batch_request_store=batch_request_store,
        batch_request_output_dir=batch_request_output_dir,
    )
    provider = build_openai_provider(
        settings,
        debug_json_writer=resolved_debug_json_writer,
        debug_json_enabled=debug_json_enabled,
    )
    return LlmAdapter(
        client=provider,
        model=model,
        batch_request_store=resolved_batch_request_store,
        debug_json_writer=resolved_debug_json_writer,
        debug_json_enabled=debug_json_enabled,
    )
