from context_pilot import Action, EvictionConfig, FileState, evaluate


def test_evaluate_under_pressure():
    # Context budget is 10k, we are using 5k (50%), pressure threshold is 80%
    config = EvictionConfig(max_context_tokens=10000, pressure_threshold=0.8)
    
    states = [
        FileState(path="stale.py", added_at_turn=1, last_read_turn=1, token_count=5000)
    ]
    
    # Should not suggest anything because pressure is only 50%
    results = evaluate(states, current_turn=10, config=config)
    assert len(results) == 0


def test_evaluate_over_pressure_suggests_drop():
    # Context budget is 10k, we are using 9k (90%), pressure threshold is 80%
    config = EvictionConfig(max_context_tokens=10000, pressure_threshold=0.8, compress_before_drop=False)
    
    states = [
        FileState(path="stale.py", added_at_turn=1, last_read_turn=1, edit_count=0, token_count=9000)
    ]
    
    results = evaluate(states, current_turn=10, config=config)
    
    assert len(results) == 1
    assert results[0].path == "stale.py"
    assert results[0].action == Action.DROP


def test_evaluate_over_pressure_suggests_compress():
    # Context budget is 10k, we are using 9k (90%), threshold 80%
    config = EvictionConfig(max_context_tokens=10000, pressure_threshold=0.8, compress_before_drop=True)
    
    states = [
        FileState(path="stale.py", added_at_turn=1, last_read_turn=1, edit_count=0, token_count=9000)
    ]
    
    # Provide highly compressible dummy source code
    dummy_source = '"""Docstring"""\n' * 500 + 'def a():\n    return 1\n'
    file_contents = {"stale.py": dummy_source}
    
    results = evaluate(states, current_turn=10, config=config, file_contents=file_contents)
    
    assert len(results) == 1
    assert results[0].path == "stale.py"
    assert results[0].action == Action.COMPRESS
