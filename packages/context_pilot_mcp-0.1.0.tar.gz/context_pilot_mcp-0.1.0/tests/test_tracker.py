import os
from pathlib import Path

from context_pilot import EventType, Tracker


def test_tracker_initialization(tmp_path):
    tracker = Tracker(session_dir=tmp_path)
    assert tracker.current_turn == 0
    assert len(tracker.get_all_states()) == 0


def test_tracker_record_events(tmp_path):
    tracker = Tracker(session_dir=tmp_path)
    
    tracker.record("file1.py", EventType.ADDED, turn=1)
    state = tracker.get_state("file1.py")
    assert state is not None
    assert state.added_at_turn == 1
    assert state.read_count == 0
    
    tracker.record("file1.py", EventType.READ, turn=2)
    state = tracker.get_state("file1.py")
    assert state.last_read_turn == 2
    assert state.read_count == 1
    
    tracker.record("file1.py", EventType.EDITED, turn=3)
    state = tracker.get_state("file1.py")
    assert state.last_edit_turn == 3
    assert state.edit_count == 1
    
    assert tracker.current_turn == 3


def test_tracker_advance_turn(tmp_path):
    tracker = Tracker(session_dir=tmp_path)
    assert tracker.current_turn == 0
    tracker.advance_turn()
    assert tracker.current_turn == 1
    tracker.advance_turn()
    assert tracker.current_turn == 2


def test_tracker_save_and_load(tmp_path):
    tracker1 = Tracker(session_dir=tmp_path)
    tracker1.record("file1.py", EventType.ADDED, turn=5)
    tracker1.record("file1.py", EventType.EDITED, turn=5)
    tracker1.save()
    
    tracker2 = Tracker(session_dir=tmp_path)
    loaded = tracker2.load()
    assert loaded is True
    
    assert tracker2.current_turn == 5
    state = tracker2.get_state("file1.py")
    assert state is not None
    assert state.added_at_turn == 5
    assert state.edit_count == 1


def test_tracker_remove(tmp_path):
    tracker = Tracker(session_dir=tmp_path)
    tracker.record("file1.py", EventType.ADDED, turn=1)
    tracker.record("file2.py", EventType.ADDED, turn=1)
    
    assert len(tracker.get_all_states()) == 2
    tracker.remove("file1.py")
    assert len(tracker.get_all_states()) == 1
    assert tracker.get_state("file1.py") is None
    assert tracker.get_state("file2.py") is not None
