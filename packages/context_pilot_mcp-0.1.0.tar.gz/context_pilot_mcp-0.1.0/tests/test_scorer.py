from context_pilot import EvictionConfig, FileState, compute_staleness, score_all


def test_compute_staleness_fresh_file():
    config = EvictionConfig(stale_after_turns=5, edit_stickiness=3)
    state = FileState(
        path="fresh.py",
        added_at_turn=1,
        last_read_turn=10,
        last_edit_turn=10,
        edit_count=1,
        token_count=1000,
    )
    
    staleness = compute_staleness(
        state=state,
        current_turn=10,
        config=config,
        total_context_tokens=10000,
    )
    
    # 0 decay + 0 edit penalty + 0.06 token pressure + 0.15 dep = 0.21
    assert staleness < 0.25


def test_compute_staleness_stale_file():
    config = EvictionConfig(stale_after_turns=5, edit_stickiness=3)
    state = FileState(
        path="stale.py",
        added_at_turn=1,
        last_read_turn=2,
        last_edit_turn=0,
        edit_count=0,
        token_count=1000,
    )
    
    staleness = compute_staleness(
        state=state,
        current_turn=10, # 8 turns since last ref
        config=config,
        total_context_tokens=10000,
    )
    
    # High turn decay + 1.0 edit penalty
    assert staleness > 0.6


def test_compute_staleness_edit_stickiness():
    config = EvictionConfig(stale_after_turns=5, edit_stickiness=3)
    state = FileState(
        path="sticky.py",
        added_at_turn=1,
        last_read_turn=10,
        last_edit_turn=10,
        edit_count=5,
        token_count=1000,
    )
    
    # Turn 10: fresh
    s1 = compute_staleness(state, 10, config, 10000)
    
    # Turn 12: 2 turns ago, still within stickiness (3)
    s2 = compute_staleness(state, 12, config, 10000)
    
    # Turn 15: 5 turns ago, stickiness gone
    s3 = compute_staleness(state, 15, config, 10000)
    
    assert s1 < s2 < s3


def test_score_all():
    config = EvictionConfig(stale_after_turns=5, edit_stickiness=3)
    states = [
        FileState(path="stale.py", added_at_turn=1, last_read_turn=1, edit_count=0, token_count=1000),
        FileState(path="fresh.py", added_at_turn=10, last_read_turn=10, edit_count=1, token_count=1000),
    ]
    
    scored = score_all(states, current_turn=10, config=config)
    
    # Should be sorted by staleness descending
    assert len(scored) == 2
    assert scored[0].path == "stale.py"
    assert scored[1].path == "fresh.py"
    assert scored[0].staleness > scored[1].staleness
