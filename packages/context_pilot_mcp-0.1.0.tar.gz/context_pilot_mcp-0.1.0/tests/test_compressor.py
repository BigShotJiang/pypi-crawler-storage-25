from context_pilot import compress_file, compress_file_generic


def test_compress_file_strips_docstrings():
    source = '''
def hello(name: str):
    """This is a docstring that should be removed."""
    print("Debug message")
    if name:
        return f"Hello, {name}"
    return "Hello, World"
'''
    compressed, ratio = compress_file(source)
    
    assert 'docstring' not in compressed
    assert 'print' not in compressed
    assert 'def hello(name: str):' in compressed
    assert 'if name:' in compressed
    assert 'return' in compressed
    assert ratio < 1.0


def test_compress_file_keeps_class_structure():
    source = '''
class MyService:
    """Service docstring."""
    
    def process(self):
        """Process docstring."""
        log.info("Processing...")
        return True
'''
    compressed, ratio = compress_file(source)
    
    assert 'class MyService:' in compressed
    assert 'def process(self):' in compressed
    assert 'return True' in compressed
    assert 'docstring' not in compressed
    assert 'log.info' not in compressed


def test_compress_file_generic_strips_comments():
    source = '''
// This is a comment
function hello() {
    /* Block comment
       spanning lines */
    return "hello";
}
'''
    compressed, ratio = compress_file_generic(source)
    assert 'comment' not in compressed
    assert 'function hello()' in compressed
    assert 'return "hello";' in compressed
    assert ratio < 1.0
