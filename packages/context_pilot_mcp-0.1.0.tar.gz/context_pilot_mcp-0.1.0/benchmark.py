"""Benchmark script to measure token savings using context-pilot."""

import os
from pathlib import Path

from context_pilot import (
    EventType,
    EvictionConfig,
    Tracker,
    compress_file,
    estimate_tokens,
    evaluate,
)


def run_benchmark():
    # We will use some of the larger files from the Aider codebase
    project_root = Path(__file__).parent.parent
    files_to_test = [
        "aider/aider/coders/base_coder.py",
        "aider/aider/commands.py",
        "aider/aider/repomap.py",
    ]

    print("=== Phase 1: AST Compression Benchmarks ===")
    total_original_tokens = 0
    total_compressed_tokens = 0
    file_contents = {}

    for rel_path in files_to_test:
        fpath = project_root / rel_path
        if not fpath.exists():
            continue
            
        source = fpath.read_text(encoding="utf-8")
        file_contents[str(fpath)] = source
        
        orig_tokens = estimate_tokens(source)
        total_original_tokens += orig_tokens
        
        compressed_source, _ = compress_file(source)
        comp_tokens = estimate_tokens(compressed_source)
        total_compressed_tokens += comp_tokens
        
        savings = 1.0 - (comp_tokens / orig_tokens)
        print(f"File: {rel_path}")
        print(f"  Original:   {orig_tokens:,} tokens")
        print(f"  Compressed: {comp_tokens:,} tokens")
        print(f"  Reduction:  {savings:.0%} savings\n")

    if total_original_tokens > 0:
        overall_savings = 1.0 - (total_compressed_tokens / total_original_tokens)
        print(f"Total Compression Reduction: {overall_savings:.0%}\n")

    print("=== Phase 2: Session Simulation (10 turns) ===")
    # Simulate a user session
    tracker = Tracker()
    tracker.clear()
    
    # Turn 0: User adds base_coder and commands
    tracker.record(str(project_root / "aider/aider/coders/base_coder.py"), EventType.ADDED, turn=0)
    tracker.record(str(project_root / "aider/aider/commands.py"), EventType.ADDED, turn=0)
    tracker.update_token_count(str(project_root / "aider/aider/coders/base_coder.py"), estimate_tokens(file_contents[str(project_root / "aider/aider/coders/base_coder.py")]))
    tracker.update_token_count(str(project_root / "aider/aider/commands.py"), estimate_tokens(file_contents[str(project_root / "aider/aider/commands.py")]))
    
    # Turn 1-3: User works heavily in base_coder
    tracker.advance_turn()
    tracker.record(str(project_root / "aider/aider/coders/base_coder.py"), EventType.EDITED)
    
    tracker.advance_turn()
    tracker.record(str(project_root / "aider/aider/coders/base_coder.py"), EventType.EDITED)
    
    tracker.advance_turn()
    tracker.record(str(project_root / "aider/aider/coders/base_coder.py"), EventType.EDITED)
    
    # Turn 4: User adds repomap to context
    tracker.advance_turn()
    tracker.record(str(project_root / "aider/aider/repomap.py"), EventType.ADDED)
    tracker.update_token_count(str(project_root / "aider/aider/repomap.py"), estimate_tokens(file_contents[str(project_root / "aider/aider/repomap.py")]))
    
    # Turn 5-10: User works exclusively in repomap. base_coder is ignored, commands was never touched.
    for i in range(5, 11):
        tracker.advance_turn()
        tracker.record(str(project_root / "aider/aider/repomap.py"), EventType.EDITED)
        
    print(f"Current Turn: {tracker.current_turn}")
    
    # Evaluate eviction (Assume 16k context window, pressure threshold 0.7)
    # Total tokens original: base_coder + commands + repomap
    config = EvictionConfig(max_context_tokens=16000, pressure_threshold=0.7)
    
    results = evaluate(
        states=tracker.get_all_states(),
        current_turn=tracker.current_turn,
        config=config,
        file_contents=file_contents,
    )
    
    print("\nEviction Engine Results:")
    tokens_recovered = 0
    for r in results:
        action_name = r.action.name
        print(f"  - {r.path.split('/')[-1]}: {action_name} ({r.reason})")
        tokens_recovered += r.tokens_recoverable
        
    print(f"\nTokens Recovered by Evictor: {tokens_recovered:,} tokens")
    
if __name__ == "__main__":
    run_benchmark()
