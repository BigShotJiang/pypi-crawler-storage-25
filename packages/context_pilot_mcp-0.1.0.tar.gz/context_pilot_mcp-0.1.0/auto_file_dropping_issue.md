# Feature: Auto-drop stale files from chat context

## Problem

Aider pulls files in but never drops them. Over a multi-turn session the context fills up with files that were relevant 10 turns ago. The only option is manually running `/drop`.

This hits local model users hardest — with 4K-32K windows, carrying stale files means you overflow by turn 6 on anything non-trivial. Cloud users pay for it too, literally.

## What already exists

The **repo map** re-ranks the rest of the repo every turn using tree-sitter + PageRank, but it only covers files *outside* the chat. It answers "what should I look at next?" — not "what am I carrying for no reason?"

`/drop` is manual. `check_tokens()` warns you when you're full and tells you to `/drop`, but doesn't help you figure out *which* files. `/context` mode suggests files to add, never to remove.

There's no per-file relevance tracking across turns.

## Proposal

Track usage metadata for every file in the chat:

- When it was added
- When it was last referenced (by user or LLM)
- Whether it was edited or just read
- Its token cost

Use this to compute a staleness score and either auto-drop or prompt the user. The basic idea:

```
⚠ Context 87% full. These files haven't been used in 5+ turns:
  [3,420 tok] src/api/routes.py (last ref: turn 7, now: turn 12)
  [1,890 tok] tests/test_utils.py (last ref: turn 4, never edited)
Drop? [y/n/select]
```

### Decision strategies I'm exploring

- **Turn-based decay** — files not referenced in N turns get flagged. Simple baseline.
- **Token-pressure trigger** — only evaluate when context exceeds a threshold (80%). No churn when there's room.
- **Edit stickiness** — recently edited files stay longer than files that were only read.
- **Call-graph awareness** — use the repo map's existing graph. If file A imports from file B and B is being actively edited, keep A even if it hasn't been directly mentioned.
- **Hybrid with confirmation** — combine the heuristics, surface candidates, let the user decide. Safer default.

### Interaction modes

- `--suggest-drop` (default) — prompt when context pressure is high
- `--auto-drop` — drop automatically past threshold
- `--no-auto-drop` — current behavior

### Bonus: AST-level file compression

For files that are borderline — relevant enough to keep but expensive — compress them before considering eviction. Strip docstrings, comments, logging statements, inline thin wrappers. Keep signatures, control flow, return/raise. This could recover 60-80% of tokens from a file without losing the structural context the LLM needs.

This means the eviction pipeline has two stages: **compress first, evict second**. A 4K file compressed to 800 tokens might not need to be dropped at all.

### Transparency

Enhanced `/tokens` that shows per-file stats:

```
File                        Tokens  Last Ref  Edits  Stale
────────────────────────────────────────────────────────────
src/core/engine.py           4,200   T12       3      5%
src/models/user.py           2,100   T11       1      20%
src/api/routes.py            3,420   T7        2      75%
tests/test_utils.py          1,890   T4        0      95% ←
```

## Where this would live in the codebase

- Tracking hooks: `base_coder.py` (in `send_message` and `reply_completed`)
- Eviction logic: new module, called from `check_tokens()` path
- Compression: standalone AST utility, similar to existing `repomap.py` tree-sitter usage
- Config: new flags in `main.py` arg parser

## Related

- `/drop` — [commands.py](https://github.com/Aider-AI/aider/blob/main/aider/commands.py)
- Repo map — [repomap.py](https://github.com/Aider-AI/aider/blob/main/aider/repomap.py)
- Context coder — [context_coder.py](https://github.com/Aider-AI/aider/blob/main/aider/coders/context_coder.py)
- Token overflow — `check_tokens()` in [base_coder.py](https://github.com/Aider-AI/aider/blob/main/aider/coders/base_coder.py)
