"""context-pilot: Universal context manager for AI coding agents."""

from .compressor import compress_file, compress_file_generic, estimate_tokens
from .evictor import evaluate, format_status_table, format_suggestions
from .graph import build_import_graph, compute_importance, get_dependencies, get_dependents
from .scorer import compute_staleness, score_all
from .tracker import Tracker
from .types import Action, EventType, EvictionConfig, EvictionResult, FileEvent, FileState

__all__ = [
    "Action",
    "EventType",
    "EvictionConfig",
    "EvictionResult",
    "FileEvent",
    "FileState",
    "Tracker",
    "compute_staleness",
    "score_all",
    "compress_file",
    "compress_file_generic",
    "estimate_tokens",
    "build_import_graph",
    "compute_importance",
    "get_dependencies",
    "get_dependents",
    "evaluate",
    "format_status_table",
    "format_suggestions",
]
