"""Staleness scoring engine.

Computes a 0.0–1.0 staleness score for each tracked file based on:
  - Turn decay (how long since last reference)
  - Edit recency (recently edited files are sticky)
  - Token cost (expensive files are more valuable to free)
  - Dependency graph (files imported by active files stay)
  - Structural importance (AST complexity from LLM_DIET's pruner concept)
"""

from __future__ import annotations

import math

from .types import EvictionConfig, FileState


# Weight distribution for the staleness formula.
# These should sum to 1.0.
W_TURN_DECAY = 0.40
W_EDIT_RECENCY = 0.25
W_TOKEN_COST = 0.20
W_DEPENDENCY = 0.15


def compute_staleness(
    state: FileState,
    current_turn: int,
    config: EvictionConfig,
    total_context_tokens: int = 0,
    is_dependency_of_active: bool = False,
    importance: float = 0.0,
) -> float:
    """Compute staleness score for a single file.

    Returns a float between 0.0 (completely fresh) and 1.0 (dead weight).

    Args:
        state: Current file tracking state.
        current_turn: The current conversation turn number.
        config: Eviction configuration parameters.
        total_context_tokens: Total tokens currently used across all files.
        is_dependency_of_active: Whether this file is imported by a file
            that was edited in the last 2 turns.
        importance: Optional AST-derived importance score (0.0–1.0).
            Higher values = more complex/important code = harder to drop.
    """
    turns_since_last = current_turn - state.last_any_turn

    # ------------------------------------------------------------------
    # Factor 1: Turn decay (0.0 = just referenced, 1.0 = long gone)
    # ------------------------------------------------------------------
    # Sigmoid-shaped decay: slow at first, steep around stale_after_turns,
    # then flattens toward 1.0.
    if turns_since_last <= 0:
        turn_decay = 0.0
    else:
        # k controls steepness. At stale_after_turns, decay ≈ 0.5.
        k = 1.5
        midpoint = config.stale_after_turns
        turn_decay = 1.0 / (1.0 + math.exp(-k * (turns_since_last - midpoint)))

    # ------------------------------------------------------------------
    # Factor 2: Edit recency bonus (0.0 = recently edited, 1.0 = never/long ago)
    # ------------------------------------------------------------------
    if state.edit_count == 0:
        edit_penalty = 1.0  # never edited — no stickiness
    else:
        turns_since_edit = current_turn - state.last_edit_turn
        if turns_since_edit <= 0:
            edit_penalty = 0.0  # just edited
        elif turns_since_edit <= config.edit_stickiness:
            # Linear decay over stickiness window
            edit_penalty = turns_since_edit / config.edit_stickiness
        else:
            edit_penalty = 1.0

    # ------------------------------------------------------------------
    # Factor 3: Token cost weight (higher cost = more valuable to free)
    # ------------------------------------------------------------------
    # This one is inverted: high token cost means HIGH staleness contribution
    # because we want to prioritize dropping expensive files.
    if total_context_tokens > 0 and state.token_count > 0:
        cost_ratio = state.token_count / total_context_tokens
        # Scale: a file using 50%+ of context is very expensive
        token_pressure = min(cost_ratio * 3.0, 1.0)
    else:
        token_pressure = 0.5  # neutral when we don't know

    # ------------------------------------------------------------------
    # Factor 4: Dependency bonus (reduce staleness if actively depended on)
    # ------------------------------------------------------------------
    if is_dependency_of_active:
        dep_score = 0.0  # fully protected
    else:
        dep_score = 1.0  # no protection

    # ------------------------------------------------------------------
    # Combine
    # ------------------------------------------------------------------
    raw = (
        W_TURN_DECAY * turn_decay
        + W_EDIT_RECENCY * edit_penalty
        + W_TOKEN_COST * token_pressure
        + W_DEPENDENCY * dep_score
    )

    # Apply importance discount: important files (high AST complexity)
    # get up to 30% staleness reduction.
    if importance > 0:
        importance_discount = importance * 0.3
        raw = raw * (1.0 - importance_discount)

    return max(0.0, min(1.0, raw))


def score_all(
    states: list[FileState],
    current_turn: int,
    config: EvictionConfig,
    dependency_map: dict[str, set[str]] | None = None,
    importance_map: dict[str, float] | None = None,
) -> list[FileState]:
    """Score all tracked files and update their staleness values in-place.

    Args:
        states: List of file states to score.
        current_turn: Current conversation turn.
        config: Eviction config.
        dependency_map: Optional mapping of file -> set of files it imports.
            Used to determine if a file is depended on by an active file.
        importance_map: Optional mapping of file -> AST importance (0.0–1.0).

    Returns:
        The same list, with staleness values updated and sorted by staleness desc.
    """
    total_tokens = sum(s.token_count for s in states)

    # Find actively edited files (edited within last 2 turns)
    active_files = {
        s.path for s in states
        if s.edit_count > 0 and (current_turn - s.last_edit_turn) <= 2
    }

    # Build reverse dependency lookup: who imports this file?
    active_dependents: set[str] = set()
    if dependency_map:
        for active_file in active_files:
            deps = dependency_map.get(active_file, set())
            active_dependents.update(deps)

    dep_map = dependency_map or {}
    imp_map = importance_map or {}

    for state in states:
        is_dep = state.path in active_dependents
        importance = imp_map.get(state.path, 0.0)

        state.staleness = compute_staleness(
            state=state,
            current_turn=current_turn,
            config=config,
            total_context_tokens=total_tokens,
            is_dependency_of_active=is_dep,
            importance=importance,
        )

    states.sort(key=lambda s: s.staleness, reverse=True)
    return states
