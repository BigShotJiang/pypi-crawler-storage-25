"""Shared types and configuration for context-pilot."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Literal


class Action(Enum):
    """What to do with a file after evaluation."""
    KEEP = "keep"
    COMPRESS = "compress"
    DROP = "drop"


class EventType(Enum):
    """Types of file interactions tracked across turns."""
    ADDED = "added"           # File entered context
    READ = "read"             # Agent read the file
    EDITED = "edited"         # Agent wrote to the file
    MENTIONED = "mentioned"   # File name appeared in agent output
    USER_REF = "user_ref"     # User referenced the file


@dataclass
class FileEvent:
    """A single tracked interaction with a file."""
    file: str
    event: EventType
    turn: int
    timestamp: float = 0.0


@dataclass
class FileState:
    """Current accumulated state for a tracked file."""
    path: str
    added_at_turn: int
    last_read_turn: int = 0
    last_edit_turn: int = 0
    last_mention_turn: int = 0
    last_user_ref_turn: int = 0
    read_count: int = 0
    edit_count: int = 0
    mention_count: int = 0
    token_count: int = 0
    compressed: bool = False
    staleness: float = 0.0       # 0.0 = fresh, 1.0 = dead weight

    @property
    def last_any_turn(self) -> int:
        """Most recent turn this file was touched in any way."""
        return max(
            self.added_at_turn,
            self.last_read_turn,
            self.last_edit_turn,
            self.last_mention_turn,
            self.last_user_ref_turn,
        )


@dataclass
class EvictionConfig:
    """Tunable parameters for the eviction engine."""
    mode: Literal["suggest", "auto", "off"] = "suggest"
    pressure_threshold: float = 0.8       # trigger at 80% context usage
    stale_after_turns: int = 5            # unreferenced turns before considered stale
    edit_stickiness: int = 3              # edited files stay N extra turns
    compress_before_drop: bool = True     # try compression before eviction
    max_context_tokens: int = 128_000     # model context window
    min_staleness_to_flag: float = 0.6    # minimum staleness to surface as candidate

    @classmethod
    def load_from_file(cls, path: str | Path = ".context-pilot.toml") -> "EvictionConfig":
        """Load configuration from a TOML file if it exists, else return defaults."""
        import tomllib
        from pathlib import Path
        
        p = Path(path)
        if not p.exists():
            return cls()
            
        try:
            with p.open("rb") as f:
                data = tomllib.load(f)
                
            pilot_cfg = data.get("context-pilot", {})
            if not pilot_cfg:
                return cls()
                
            # Filter kwargs to only those that match fields
            valid_keys = cls.__dataclass_fields__.keys()
            kwargs = {k: v for k, v in pilot_cfg.items() if k in valid_keys}
            return cls(**kwargs)
        except Exception:
            return cls()


@dataclass
class EvictionResult:
    """One file's evaluation outcome."""
    path: str
    action: Action
    reason: str
    staleness: float
    tokens_recoverable: int = 0
