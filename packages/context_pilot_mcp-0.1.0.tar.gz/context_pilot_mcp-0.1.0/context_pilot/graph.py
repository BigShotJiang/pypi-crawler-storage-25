"""Lightweight file-level dependency graph.

Tracks which files import which other files. Used by the scorer to protect
files that are dependencies of actively-edited files.

Adapted from LLM_DIET's graph_builder.py — simplified to file-level only
(no function/method/class nodes). Fast to build, minimal memory.
"""

from __future__ import annotations

import ast
import os
import re
from pathlib import Path
from typing import Any


def build_import_graph(root: str | Path, files: list[str] | None = None) -> dict[str, set[str]]:
    """Build a file-level import graph.

    Returns a dict mapping each file to the set of files it imports.
    Only tracks imports that resolve to files within the project.

    Args:
        root: Project root directory.
        files: Optional list of files to scan. If None, scans all .py files.
    """
    root = Path(root).resolve()

    if files is None:
        files = _find_python_files(root)

    # Normalize all file paths
    file_set = {str(Path(f).resolve()) for f in files}

    # Build module → file mapping for resolution
    module_to_file: dict[str, str] = {}
    for fpath in file_set:
        rel = os.path.relpath(fpath, root)
        module = _path_to_module(rel)
        if module:
            module_to_file[module] = fpath

    # Scan imports
    graph: dict[str, set[str]] = {}
    for fpath in file_set:
        imports = _extract_imports(fpath)
        resolved: set[str] = set()
        for module_name in imports:
            target = _resolve_import(module_name, module_to_file)
            if target and target != fpath:
                resolved.add(target)
        graph[fpath] = resolved

    return graph


def get_dependents(graph: dict[str, set[str]], file: str) -> set[str]:
    """Return the set of files that import the given file (reverse lookup)."""
    dependents: set[str] = set()
    for source, imports in graph.items():
        if file in imports:
            dependents.add(source)
    return dependents


def get_dependencies(graph: dict[str, set[str]], file: str) -> set[str]:
    """Return the set of files that the given file imports."""
    return graph.get(file, set())


def compute_importance(graph: dict[str, set[str]]) -> dict[str, float]:
    """Compute a simple importance score for each file based on fan-in.

    Files imported by many other files are more important.
    Returns scores normalized to 0.0–1.0.
    """
    fan_in: dict[str, int] = {}
    for _source, imports in graph.items():
        for target in imports:
            fan_in[target] = fan_in.get(target, 0) + 1

    if not fan_in:
        return {}

    max_fan = max(fan_in.values())
    if max_fan == 0:
        return {}

    return {
        fpath: count / max_fan
        for fpath, count in fan_in.items()
    }


# ---------------------------------------------------------------------------
# Import extraction
# ---------------------------------------------------------------------------

def _extract_imports(filepath: str) -> list[str]:
    """Extract import module names from a Python file."""
    try:
        source = Path(filepath).read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source)
    except (SyntaxError, OSError):
        return []

    modules: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                modules.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                modules.append(node.module)

    return modules


def _resolve_import(module_name: str, module_to_file: dict[str, str]) -> str | None:
    """Try to resolve a module name to a known project file."""
    # Exact match
    if module_name in module_to_file:
        return module_to_file[module_name]

    # Try progressively shorter prefixes (a.b.c → a.b → a)
    parts = module_name.split(".")
    for i in range(len(parts), 0, -1):
        prefix = ".".join(parts[:i])
        if prefix in module_to_file:
            return module_to_file[prefix]

    return None


# ---------------------------------------------------------------------------
# Path utilities
# ---------------------------------------------------------------------------

def _path_to_module(rel_path: str) -> str | None:
    """Convert a relative file path to a Python module name."""
    rel_path = rel_path.replace(os.sep, "/")
    if not rel_path.endswith(".py"):
        return None

    # Strip .py extension
    module = rel_path[:-3]

    # Handle __init__.py
    if module.endswith("/__init__"):
        module = module[:-9]

    # Convert path separators to dots
    module = module.replace("/", ".")

    return module if module else None


def _find_python_files(root: Path) -> list[str]:
    """Find all .py files under root, excluding common noise dirs."""
    skip_dirs = {".git", ".venv", "venv", "node_modules", "__pycache__",
                 ".tox", ".mypy_cache", ".pytest_cache", "dist", "build",
                 ".eggs", "*.egg-info"}

    files: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root):
        # Prune directories in-place
        dirnames[:] = [d for d in dirnames if d not in skip_dirs and not d.endswith(".egg-info")]

        for fname in filenames:
            if fname.endswith(".py"):
                files.append(os.path.join(dirpath, fname))

    return files
