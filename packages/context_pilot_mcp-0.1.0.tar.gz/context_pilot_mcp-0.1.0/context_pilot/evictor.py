"""Eviction decision engine.

Takes scored file states + token budget and decides: keep, compress, or drop.
This is the brain of context-pilot.

Pipeline:
1. Score all files (via scorer)
2. Check if context pressure exceeds threshold
3. If yes: iterate from most stale, try compress first, then drop
4. Stop when projected usage drops below threshold
"""

from __future__ import annotations

from .compressor import compress_file, compress_file_generic, estimate_tokens
from .scorer import score_all
from .types import Action, EvictionConfig, EvictionResult, FileState


def evaluate(
    states: list[FileState],
    current_turn: int,
    config: EvictionConfig,
    dependency_map: dict[str, set[str]] | None = None,
    importance_map: dict[str, float] | None = None,
    file_contents: dict[str, str] | None = None,
) -> list[EvictionResult]:
    """Evaluate all tracked files and return eviction decisions.

    Args:
        states: Current file states from the tracker.
        current_turn: Current conversation turn number.
        config: Eviction configuration.
        dependency_map: Optional file → imports mapping.
        importance_map: Optional file → importance (0.0–1.0) mapping.
        file_contents: Optional file → source code mapping. Required for
            compression estimates. If not provided, compression ratio
            estimates are skipped.

    Returns:
        List of EvictionResult for files that should be acted on.
        Files that should be kept (action=KEEP) are not included unless
        they were evaluated and explicitly retained.
    """
    if not states:
        return []

    if config.mode == "off":
        return []

    # Step 1: Score everything
    scored = score_all(
        states=states,
        current_turn=current_turn,
        config=config,
        dependency_map=dependency_map,
        importance_map=importance_map,
    )

    # Step 2: Check pressure
    total_tokens = sum(s.token_count for s in scored)
    pressure = total_tokens / config.max_context_tokens if config.max_context_tokens > 0 else 0.0

    if pressure < config.pressure_threshold:
        # No pressure — nothing to do
        return []

    # Step 3: Build eviction plan
    results: list[EvictionResult] = []
    tokens_to_free = total_tokens - int(config.max_context_tokens * config.pressure_threshold * 0.9)
    tokens_freed = 0

    for state in scored:
        if tokens_freed >= tokens_to_free:
            break

        if state.staleness < config.min_staleness_to_flag:
            continue

        # Try compression first
        if config.compress_before_drop and not state.compressed and file_contents:
            source = file_contents.get(state.path)
            if source:
                compressed, ratio = _try_compress(state.path, source)
                if ratio < 0.6:  # compression saved 40%+
                    savings = state.token_count - int(state.token_count * ratio)
                    results.append(EvictionResult(
                        path=state.path,
                        action=Action.COMPRESS,
                        reason=f"stale ({state.staleness:.0%}), compressible to {ratio:.0%}",
                        staleness=state.staleness,
                        tokens_recoverable=savings,
                    ))
                    tokens_freed += savings
                    continue

        # Drop it
        results.append(EvictionResult(
            path=state.path,
            action=Action.DROP,
            reason=_build_reason(state, current_turn),
            staleness=state.staleness,
            tokens_recoverable=state.token_count,
        ))
        tokens_freed += state.token_count

    return results


def format_suggestions(results: list[EvictionResult]) -> str:
    """Format eviction results as a human-readable suggestion block."""
    if not results:
        return ""

    drops = [r for r in results if r.action == Action.DROP]
    compresses = [r for r in results if r.action == Action.COMPRESS]
    total_savings = sum(r.tokens_recoverable for r in results)

    lines: list[str] = []

    if compresses:
        lines.append("Files that can be compressed:")
        for r in compresses:
            lines.append(f"  [{r.tokens_recoverable:,} tok saved] {_short_path(r.path)} — {r.reason}")

    if drops:
        if compresses:
            lines.append("")
        lines.append("Files recommended for removal:")
        for r in drops:
            lines.append(f"  [{r.tokens_recoverable:,} tok] {_short_path(r.path)} — {r.reason}")

    lines.append(f"\nTotal recoverable: ~{total_savings:,} tokens")
    return "\n".join(lines)


def format_status_table(states: list[FileState], current_turn: int) -> str:
    """Format a status table showing all tracked files and their metrics."""
    if not states:
        return "No files tracked."

    # Header
    lines = [
        f"{'File':<40} {'Tokens':>7} {'Added':>6} {'Last':>6} {'Edits':>6} {'Stale':>7}",
        "─" * 76,
    ]

    for s in sorted(states, key=lambda x: x.staleness, reverse=True):
        name = _short_path(s.path)
        if len(name) > 38:
            name = "..." + name[-35:]

        # Staleness bar
        filled = int(s.staleness * 8)
        bar = "█" * filled + "░" * (8 - filled)

        flag = " ←" if s.staleness >= 0.6 else ""
        lines.append(
            f"{name:<40} {s.token_count:>7,} "
            f"{'T' + str(s.added_at_turn):>6} "
            f"{'T' + str(s.last_any_turn):>6} "
            f"{s.edit_count:>6} "
            f"{bar} {s.staleness:>4.0%}{flag}"
        )

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _try_compress(path: str, source: str) -> tuple[str, float]:
    """Try to compress a file and return (compressed, ratio)."""
    if path.endswith(".py"):
        return compress_file(source)
    else:
        return compress_file_generic(source)


def _build_reason(state: FileState, current_turn: int) -> str:
    """Build a human-readable reason string."""
    turns_ago = current_turn - state.last_any_turn
    parts = [f"stale ({state.staleness:.0%})"]

    if turns_ago > 0:
        parts.append(f"last ref {turns_ago} turns ago")

    if state.edit_count == 0:
        parts.append("never edited")

    return ", ".join(parts)


def _short_path(path: str) -> str:
    """Return last 2 path segments for display."""
    parts = path.replace("\\", "/").split("/")
    return "/".join(parts[-2:]) if len(parts) > 1 else path
