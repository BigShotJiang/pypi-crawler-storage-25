"""AST-based file compression.

Adapted from LLM_DIET's compressor.py and shadow_server.py.
Extended to work on full files (not just individual functions).

Keeps: signatures, control flow, return/raise, imports, class defs
Drops: docstrings, comments, logging/print, pure-constant assignments
"""

from __future__ import annotations

import ast
import re
import textwrap
from typing import Iterable


# Statements we always drop from function bodies.
_PRINT_NAMES: frozenset[str] = frozenset({"print", "pprint", "pp"})
_LOG_ATTRS: frozenset[str] = frozenset({
    "debug", "info", "warning", "warn", "error", "exception", "log", "critical",
})

# Max body lines to keep per function when doing structural compression.
_MAX_BODY_LINES = 8


# ---------------------------------------------------------------------------
# AST predicates (from LLM_DIET pruner + compressor)
# ---------------------------------------------------------------------------

def _is_debug_log(stmt: ast.stmt) -> bool:
    """True if stmt is a bare print/logging call."""
    if not isinstance(stmt, ast.Expr) or not isinstance(stmt.value, ast.Call):
        return False
    func = stmt.value.func
    if isinstance(func, ast.Name):
        return func.id in _PRINT_NAMES
    if isinstance(func, ast.Attribute):
        return func.attr in _LOG_ATTRS
    return False


def _is_docstring(stmt: ast.stmt) -> bool:
    return (
        isinstance(stmt, ast.Expr)
        and isinstance(stmt.value, ast.Constant)
        and isinstance(stmt.value.value, str)
    )


def _is_comment_only(line: str) -> bool:
    stripped = line.strip()
    return stripped.startswith("#") or not stripped


# ---------------------------------------------------------------------------
# Function-level compression (from LLM_DIET shadow_server._compress_fn)
# ---------------------------------------------------------------------------

def _compress_function(code: str) -> str:
    """Compress a single function: keep signature + first N body lines + return/raise."""
    dedented = textwrap.dedent(code).rstrip()
    lines = dedented.splitlines()
    if not lines:
        return code

    try:
        tree = ast.parse(dedented)
        fn = tree.body[0]
        if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            raise ValueError
    except Exception:
        # Can't parse — fall back to line truncation
        if len(lines) <= _MAX_BODY_LINES + 1:
            return dedented
        return "\n".join(lines[:_MAX_BODY_LINES + 1]) + f"\n    # ... ({len(lines) - _MAX_BODY_LINES - 1} more lines)"

    body_stmts = fn.body
    body_start = body_stmts[0].lineno - 1

    sig_lines = lines[:body_start]
    raw_body = lines[body_start:]

    # Drop docstrings and debug logs
    body_stmts_to_keep = []
    for i, stmt in enumerate(body_stmts):
        # Drop leading docstring
        if i == 0 and _is_docstring(stmt):
            continue
        # Drop print/log statements
        if _is_debug_log(stmt):
            continue
        body_stmts_to_keep.append(stmt)
        
    if not body_stmts_to_keep:
        # Fallback if empty
        return "\n".join(sig_lines + ["    pass"])
        
    # Re-unparse the filtered body using AST
    # But since we want to preserve original formatting where possible, 
    # we'll build a set of line numbers to keep.
    lines_to_keep = set()
    for stmt in body_stmts_to_keep:
        start = stmt.lineno - 1
        end = getattr(stmt, "end_lineno", stmt.lineno)
        for ln in range(start, end):
            lines_to_keep.add(ln)
            
    # Now reconstruct the body from the original lines
    filtered_raw_body = []
    for ln in range(body_start, len(lines)):
        line = lines[ln]
        # Always drop comment-only and blank lines
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if ln in lines_to_keep:
            filtered_raw_body.append(line)

    body = filtered_raw_body

    if len(body) <= _MAX_BODY_LINES:
        return "\n".join(sig_lines + body)

    kept = body[:_MAX_BODY_LINES]
    remaining = body[_MAX_BODY_LINES:]

    # Grab return/raise statements beyond the cutoff
    tail_extras: list[str] = []
    for stmt in body_stmts:
        if not isinstance(stmt, (ast.Return, ast.Raise)):
            continue
        rel = stmt.lineno - 1 - body_start
        if rel >= _MAX_BODY_LINES and 0 <= rel < len(body):
            tail_extras.append(body[rel])
        if len(tail_extras) >= 2:
            break

    result = sig_lines + kept
    result.append(f"    # ... ({len(remaining)} more lines)")
    result.extend(tail_extras)
    return "\n".join(result)


# ---------------------------------------------------------------------------
# File-level compression
# ---------------------------------------------------------------------------

def compress_file(source: str, keywords: Iterable[str] | None = None) -> tuple[str, float]:
    """Compress a Python source file.

    Returns (compressed_source, compression_ratio).
    Ratio = compressed_size / original_size (lower = more savings).

    Strategy:
    1. Parse the entire file as AST
    2. For each function/method: compress using _compress_function
    3. For module-level code: keep imports, drop docstrings/comments/constants
    4. Reassemble
    """
    if not source or not source.strip():
        return source, 1.0

    original_size = len(source)

    try:
        tree = ast.parse(source)
    except SyntaxError:
        # Can't parse — fall back to line-based stripping
        compressed = _strip_comments_and_docstrings(source)
        return compressed, len(compressed) / original_size

    output_blocks: list[str] = []
    source_lines = source.splitlines()

    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # Extract original source for this function
            fn_source = _extract_node_source(source_lines, node)
            compressed_fn = _compress_function(fn_source)
            output_blocks.append(compressed_fn)

        elif isinstance(node, ast.ClassDef):
            # Keep class signature + compress its methods
            output_blocks.append(_compress_class(source_lines, node))

        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            # Always keep imports
            output_blocks.append(_extract_node_source(source_lines, node))

        elif isinstance(node, ast.Assign):
            # Keep assignments that look like config (__all__, VERSION, etc.)
            src = _extract_node_source(source_lines, node)
            if _is_meaningful_assignment(node):
                output_blocks.append(src)

        elif _is_docstring(node):
            # Drop module-level docstrings
            continue

        elif isinstance(node, ast.Expr) and _is_debug_log(node):
            # Drop module-level print/log calls
            continue

        else:
            # Keep everything else (if/try at module level, etc.)
            output_blocks.append(_extract_node_source(source_lines, node))

    compressed = "\n\n".join(block for block in output_blocks if block.strip())
    if not compressed.endswith("\n"):
        compressed += "\n"

    ratio = len(compressed) / original_size if original_size > 0 else 1.0
    return compressed, ratio


def _compress_class(source_lines: list[str], cls: ast.ClassDef) -> str:
    """Compress a class: keep definition line + compress methods."""
    # Class signature (class Foo(Base):)
    class_line_start = cls.lineno - 1
    if cls.body:
        class_line_end = cls.body[0].lineno - 2
    else:
        class_line_end = class_line_start

    header = "\n".join(source_lines[class_line_start:class_line_end + 1])
    parts = [header]

    for node in cls.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            fn_src = _extract_node_source(source_lines, node)
            parts.append(textwrap.indent(_compress_function(fn_src), "    "))
        elif _is_docstring(node):
            continue  # drop class docstring
        elif isinstance(node, ast.Assign) and _is_meaningful_assignment(node):
            parts.append("    " + _extract_node_source(source_lines, node).strip())
        elif isinstance(node, ast.Expr) and _is_debug_log(node):
            continue
        else:
            parts.append(textwrap.indent(_extract_node_source(source_lines, node), "    "))

    return "\n".join(parts)


def _extract_node_source(source_lines: list[str], node: ast.AST) -> str:
    """Extract original source lines for an AST node."""
    start = node.lineno - 1
    end = getattr(node, "end_lineno", node.lineno)
    return "\n".join(source_lines[start:end])


def _is_meaningful_assignment(node: ast.Assign) -> bool:
    """True for assignments that look like config/constants worth keeping."""
    for target in node.targets:
        if isinstance(target, ast.Name):
            name = target.id
            # Keep dunder vars, ALL_CAPS constants, common config names
            if name.startswith("__") and name.endswith("__"):
                return True
            if name.isupper():
                return True
            if name in ("app", "router", "blueprint", "db", "engine"):
                return True
    return False


def _strip_comments_and_docstrings(source: str) -> str:
    """Fallback compression: strip comments and blank lines."""
    lines = []
    for line in source.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        # Strip inline comments (rough heuristic)
        cleaned = re.sub(r'\s+#[^"\']*$', "", line).rstrip()
        if cleaned.strip():
            lines.append(cleaned)
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Non-Python fallback
# ---------------------------------------------------------------------------

def compress_file_generic(source: str) -> tuple[str, float]:
    """Language-agnostic compression: strip comments, blank lines, docstrings.

    Works for JS/TS/Go/etc. Less aggressive than AST-based compression
    but still useful.
    """
    if not source or not source.strip():
        return source, 1.0

    original_size = len(source)
    lines: list[str] = []
    in_block_comment = False

    for line in source.splitlines():
        stripped = line.strip()

        # Block comments (/* ... */)
        if in_block_comment:
            if "*/" in stripped:
                in_block_comment = False
            continue
        if stripped.startswith("/*"):
            if "*/" not in stripped:
                in_block_comment = True
            continue

        # Line comments
        if stripped.startswith("//") or stripped.startswith("#"):
            continue

        # Blank lines
        if not stripped:
            continue

        lines.append(line)

    compressed = "\n".join(lines)
    ratio = len(compressed) / original_size if original_size > 0 else 1.0
    return compressed, ratio


def estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token for code."""
    return len(text) // 4
