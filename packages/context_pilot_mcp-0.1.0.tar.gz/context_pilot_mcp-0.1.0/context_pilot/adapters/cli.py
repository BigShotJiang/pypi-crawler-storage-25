"""CLI adapter for context-pilot."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from context_pilot import (
    EventType,
    EvictionConfig,
    Tracker,
    evaluate,
    format_status_table,
    format_suggestions,
)

app = typer.Typer(help="context-pilot: Universal context manager for AI coding agents.")
console = Console()

# We store the session in the current directory by default
SESSION_DIR = Path(".context-pilot")


def get_tracker() -> Tracker:
    tracker = Tracker(session_dir=SESSION_DIR)
    tracker.load()
    return tracker


@app.command()
def track(
    file: str = typer.Argument(..., help="Path to the file"),
    event: EventType = typer.Option(..., "--event", "-e", help="Event type: added, read, edited, mentioned, user_ref"),
    tokens: int = typer.Option(0, "--tokens", "-t", help="Token count of the file"),
    turn: Optional[int] = typer.Option(None, "--turn", help="Turn number (defaults to advancing current turn)"),
):
    """Track a file event."""
    tracker = get_tracker()
    
    if turn is None:
        # If no turn is specified, we either use the current turn or advance if this is a new interaction phase
        turn = tracker.current_turn

    tracker.record(file, event, turn=turn)
    if tokens > 0:
        tracker.update_token_count(file, tokens)
        
    tracker.save()
    console.print(f"[green]Recorded {event.value} for {file} at turn {turn}[/green]")


@app.command()
def advance():
    """Advance the current turn counter by 1."""
    tracker = get_tracker()
    turn = tracker.advance_turn()
    tracker.save()
    console.print(f"[blue]Advanced to turn {turn}[/blue]")


@app.command()
def remove(file: str = typer.Argument(..., help="Path to the file to untrack")):
    """Stop tracking a file (e.g. if it was dropped from context)."""
    tracker = get_tracker()
    tracker.remove(file)
    tracker.save()
    console.print(f"[yellow]Removed {file} from tracking[/yellow]")


@app.command()
def status():
    """Show current tracking status of all files."""
    tracker = get_tracker()
    states = tracker.get_all_states()
    
    if not states:
        console.print("No files currently tracked.")
        return
        
    # We can use the library's built-in formatter, or rich for better CLI UI
    # Here we'll just use the library formatter for consistency
    console.print(format_status_table(states, tracker.current_turn))


@app.command()
def evaluate_context(
    budget: int = typer.Option(128000, "--budget", "-b", help="Max token budget"),
    pressure: float = typer.Option(0.8, "--pressure", "-p", help="Pressure threshold (0.0 to 1.0)"),
):
    """Evaluate context and suggest files to drop or compress."""
    tracker = get_tracker()
    states = tracker.get_all_states()
    
    config = EvictionConfig.load_from_file()
    if budget != 128000:
        config.max_context_tokens = budget
    if pressure != 0.8:
        config.pressure_threshold = pressure
    
    # Load file contents for compression estimation
    file_contents = {}
    for state in states:
        try:
            file_contents[state.path] = Path(state.path).read_text(encoding="utf-8")
        except OSError:
            pass

    results = evaluate(
        states=states,
        current_turn=tracker.current_turn,
        config=config,
        file_contents=file_contents,
    )
    
    if not results:
        console.print("[green]Context is healthy, no evictions needed.[/green]")
        return
        
    console.print(format_suggestions(results))


@app.command()
def clear():
    """Clear all tracking state."""
    tracker = get_tracker()
    tracker.clear()
    tracker.save()
    console.print("[yellow]Cleared all tracking state.[/yellow]")


if __name__ == "__main__":
    app()
