"""MCP Server Adapter for context-pilot.

This allows tools like Claude Code, Cursor, and Antigravity to use
context-pilot as an MCP server.

It provides tools for:
- read_file: Intercepts reads to track usage and optionally compress
- suggest_drops: Surfaces eviction candidates
- drop_file: Mark a file as dropped
- status: View context staleness
"""

from __future__ import annotations

import os
from pathlib import Path

from mcp.server.fastmcp import FastMCP

from context_pilot import (
    EventType,
    EvictionConfig,
    Tracker,
    evaluate,
    format_status_table,
    format_suggestions,
    compress_file,
    compress_file_generic,
)

mcp = FastMCP("context-pilot")
SESSION_DIR = Path(os.environ.get("CONTEXT_PILOT_DIR", ".context-pilot"))


def _get_tracker() -> Tracker:
    """Load or initialize the tracker."""
    tracker = Tracker(session_dir=SESSION_DIR)
    tracker.load()
    return tracker


@mcp.tool()
def read_file(path: str, compress_if_stale: bool = True) -> str:
    """Read a file from disk. Automatically tracks the read event and compresses stale files.
    
    Args:
        path: Path to the file to read.
        compress_if_stale: If True, compresses the file (strips comments/docs) if it's considered stale.
    """
    try:
        content = Path(path).read_text(encoding="utf-8")
    except OSError as e:
        return f"Error reading file {path}: {e}"

    tracker = _get_tracker()
    tracker.record(path, EventType.READ)
    tracker.update_token_count(path, len(content) // 4)
    
    # Check if we should compress
    state = tracker.get_state(path)
    if compress_if_stale and state and state.staleness > 0.5 and not state.compressed:
        if path.endswith(".py"):
            compressed, _ = compress_file(content)
        else:
            compressed, _ = compress_file_generic(content)
        
        tracker.mark_compressed(path, len(compressed) // 4)
        tracker.save()
        return compressed

    tracker.save()
    return content


@mcp.tool()
def suggest_drops(budget: int = 128000, pressure: float = 0.8) -> str:
    """Evaluate context and suggest files to drop or compress.
    
    Args:
        budget: Maximum token budget for context window.
        pressure: Threshold (0.0 to 1.0) above which to suggest drops.
    """
    tracker = _get_tracker()
    states = tracker.get_all_states()
    
    if not states:
        return "No files are currently being tracked."

    config = EvictionConfig.load_from_file()
    # Override with MCP params if they were explicitly provided (we assume defaults if they match exactly)
    if budget != 128000:
        config.max_context_tokens = budget
    if pressure != 0.8:
        config.pressure_threshold = pressure

    # Note: we skip compression estimates here for speed, just evaluating staleness
    results = evaluate(
        states=states,
        current_turn=tracker.current_turn,
        config=config,
    )
    
    if not results:
        return "Context is healthy, no evictions needed."

    return format_suggestions(results)


@mcp.tool()
def drop_file(path: str) -> str:
    """Drop a file from the context manager's tracking.
    
    Call this after you (the agent) have removed the file from your context window.
    """
    tracker = _get_tracker()
    tracker.remove(path)
    tracker.save()
    return f"Successfully stopped tracking {path}."


@mcp.tool()
def status() -> str:
    """Show current tracking status and staleness of all files."""
    tracker = _get_tracker()
    states = tracker.get_all_states()
    if not states:
        return "No files are currently being tracked."
        
    return format_status_table(states, tracker.current_turn)


@mcp.tool()
def advance_turn() -> str:
    """Advance the turn counter. Call this when starting a new task or subtask."""
    tracker = _get_tracker()
    turn = tracker.advance_turn()
    tracker.save()
    return f"Advanced to turn {turn}."


if __name__ == "__main__":
    mcp.run()
