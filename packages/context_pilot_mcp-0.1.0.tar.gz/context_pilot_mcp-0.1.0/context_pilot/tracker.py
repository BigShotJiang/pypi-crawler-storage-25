"""Per-file event tracking and state management.

The tracker is an append-only event log with computed current state per file.
It's agent-agnostic — the adapter tells us what happened, we record it.
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from .types import EventType, FileEvent, FileState


class Tracker:
    """Records file interactions and maintains per-file state."""

    def __init__(self, session_dir: str | Path | None = None):
        self._events: list[FileEvent] = []
        self._states: dict[str, FileState] = {}
        self._current_turn: int = 0
        self._session_dir = Path(session_dir) if session_dir else Path(".context-pilot")

    # ------------------------------------------------------------------
    # Core API
    # ------------------------------------------------------------------

    def record(self, file: str, event: EventType, turn: int | None = None) -> None:
        """Record a file interaction event."""
        if turn is not None:
            self._current_turn = max(self._current_turn, turn)
        else:
            turn = self._current_turn

        ev = FileEvent(file=file, event=event, turn=turn, timestamp=time.time())
        self._events.append(ev)

        # Lazily create state on first event
        if file not in self._states:
            self._states[file] = FileState(path=file, added_at_turn=turn)

        self._apply_event(ev)

    def advance_turn(self) -> int:
        """Increment and return the current turn number."""
        self._current_turn += 1
        return self._current_turn

    @property
    def current_turn(self) -> int:
        return self._current_turn

    def get_state(self, file: str) -> FileState | None:
        """Current state for a single file, or None if untracked."""
        return self._states.get(file)

    def get_all_states(self) -> list[FileState]:
        """All currently tracked files and their state."""
        return list(self._states.values())

    def get_tracked_files(self) -> list[str]:
        """List of all files currently being tracked."""
        return list(self._states.keys())

    def remove(self, file: str) -> None:
        """Stop tracking a file (it was dropped from context)."""
        self._states.pop(file, None)

    def update_token_count(self, file: str, tokens: int) -> None:
        """Update the token count for a file. Called by the adapter."""
        state = self._states.get(file)
        if state:
            state.token_count = tokens

    def mark_compressed(self, file: str, new_token_count: int) -> None:
        """Mark a file as compressed and update its token count."""
        state = self._states.get(file)
        if state:
            state.compressed = True
            state.token_count = new_token_count

    # ------------------------------------------------------------------
    # State mutation from events
    # ------------------------------------------------------------------

    def _apply_event(self, ev: FileEvent) -> None:
        """Update file state from an event."""
        state = self._states[ev.file]

        match ev.event:
            case EventType.ADDED:
                state.added_at_turn = ev.turn
            case EventType.READ:
                state.last_read_turn = ev.turn
                state.read_count += 1
            case EventType.EDITED:
                state.last_edit_turn = ev.turn
                state.edit_count += 1
            case EventType.MENTIONED:
                state.last_mention_turn = ev.turn
                state.mention_count += 1
            case EventType.USER_REF:
                state.last_user_ref_turn = ev.turn

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Persist tracker state to disk."""
        self._session_dir.mkdir(parents=True, exist_ok=True)
        data = {
            "current_turn": self._current_turn,
            "states": {
                path: _state_to_dict(s)
                for path, s in self._states.items()
            },
            "event_count": len(self._events),
        }
        session_file = self._session_dir / "session.json"
        session_file.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def load(self) -> bool:
        """Load tracker state from disk. Returns True if loaded successfully."""
        session_file = self._session_dir / "session.json"
        if not session_file.exists():
            return False
        try:
            data = json.loads(session_file.read_text(encoding="utf-8"))
            self._current_turn = data.get("current_turn", 0)
            for path, sd in data.get("states", {}).items():
                self._states[path] = _dict_to_state(path, sd)
            return True
        except (json.JSONDecodeError, KeyError):
            return False

    def clear(self) -> None:
        """Reset all tracking state."""
        self._events.clear()
        self._states.clear()
        self._current_turn = 0


# ------------------------------------------------------------------
# Serialization helpers
# ------------------------------------------------------------------

def _state_to_dict(s: FileState) -> dict[str, Any]:
    return {
        "added_at_turn": s.added_at_turn,
        "last_read_turn": s.last_read_turn,
        "last_edit_turn": s.last_edit_turn,
        "last_mention_turn": s.last_mention_turn,
        "last_user_ref_turn": s.last_user_ref_turn,
        "read_count": s.read_count,
        "edit_count": s.edit_count,
        "mention_count": s.mention_count,
        "token_count": s.token_count,
        "compressed": s.compressed,
        "staleness": s.staleness,
    }


def _dict_to_state(path: str, d: dict[str, Any]) -> FileState:
    return FileState(
        path=path,
        added_at_turn=d.get("added_at_turn", 0),
        last_read_turn=d.get("last_read_turn", 0),
        last_edit_turn=d.get("last_edit_turn", 0),
        last_mention_turn=d.get("last_mention_turn", 0),
        last_user_ref_turn=d.get("last_user_ref_turn", 0),
        read_count=d.get("read_count", 0),
        edit_count=d.get("edit_count", 0),
        mention_count=d.get("mention_count", 0),
        token_count=d.get("token_count", 0),
        compressed=d.get("compressed", False),
        staleness=d.get("staleness", 0.0),
    )
