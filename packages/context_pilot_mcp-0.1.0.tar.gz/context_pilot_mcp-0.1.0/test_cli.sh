#!/bin/bash
set -e

# clear
context-pilot clear

# turn 1
echo "--- Turn 1 ---"
context-pilot track src/api/routes.py --event added --tokens 3420
context-pilot track src/models/user.py --event added --tokens 2100
context-pilot advance

# turn 2
echo "--- Turn 2 ---"
context-pilot track src/api/routes.py --event read
context-pilot track tests/test_utils.py --event added --tokens 1890
context-pilot advance

# turn 3
echo "--- Turn 3 ---"
context-pilot track src/api/routes.py --event edited
context-pilot track src/core/engine.py --event added --tokens 4200
context-pilot advance

# turn 4
echo "--- Turn 4 ---"
context-pilot track tests/test_utils.py --event read
context-pilot advance

# turns 5-10: lots of action on routes and engine, nothing on test_utils
for i in {5..10}; do
  context-pilot track src/api/routes.py --event mentioned
  context-pilot track src/core/engine.py --event edited
  context-pilot advance
done

# turns 11-12: only user model
for i in {11..12}; do
  context-pilot track src/models/user.py --event read
  context-pilot advance
done

echo "--- Current Status ---"
context-pilot status

echo "--- Evaluate Context (Budget 10000, Pressure 0.8) ---"
# Total tokens: 3420 + 2100 + 1890 + 4200 = 11610
# threshold = 8000, we are at 11610, need to drop ~4000
context-pilot evaluate-context --budget 10000 --pressure 0.8
