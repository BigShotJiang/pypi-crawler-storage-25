# Context Management for Aider

Aider currently manages context by pulling files into its environment but does not drop them automatically. This can lead to performance issues, especially when dealing with large repositories or numerous files.

## Proposed Solution

To improve local model performance and manage the relevance of files in context, we propose building a smart context manager that tracks file relevance and evicts stale files. This will help maintain an optimal set of files in the context, ensuring that only the most relevant ones are used for generating responses.

### Features

1. **Relevance Tracking**: The context manager should track how frequently each file is accessed or referenced during interactions.
2. **Stale File Eviction**: Files that have not been used recently can be automatically evicted to free up space and improve performance.
3. **Updatable Context**: Provide a mechanism to update the context, showing which files were added, their relevance score, and whether they should be kept or dropped.

### Methods for Decision Making

- **Relevance Score Calculation**: Assign a relevance score based on file access frequency and recency.
- **Threshold-Based Eviction**: Set a threshold for relevance scores below which files are considered stale and can be evicted.
- **User Feedback Loop**: Allow users to provide feedback on the relevance of files, adjusting the context manager's decisions accordingly.

### Implementation Plan

1. **Initial Setup**: Implement basic tracking of file access and relevance scoring.
2. **Eviction Mechanism**: Develop a mechanism to automatically evict stale files based on the relevance scores.
3. **User Interface for Context Management**: Create an interface to display the current context, including file details and relevance scores.

### Exploration

We are currently exploring methods to implement this smart context manager effectively. Feedback and suggestions from users will be invaluable in refining this approach.

---

This description outlines the proposed solution and provides a roadmap for implementing the smart context manager in Aider.
