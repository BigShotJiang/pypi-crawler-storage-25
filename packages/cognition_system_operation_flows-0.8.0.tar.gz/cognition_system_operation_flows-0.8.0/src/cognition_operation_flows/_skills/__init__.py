"""Private skills implementation package."""

