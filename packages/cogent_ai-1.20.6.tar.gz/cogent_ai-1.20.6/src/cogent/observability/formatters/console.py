"""
Console Formatters - Rich console output for events.

Provides formatters for common event categories with colored,
human-readable output.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from cogent.observability.formatters.base import BaseFormatter

if TYPE_CHECKING:
    from cogent.observability.core.config import FormatConfig, Theme
    from cogent.observability.core.event import Event


# ANSI color codes
class Colors:
    """ANSI escape codes for terminal colors."""

    RESET = "\033[0m"
    BOLD = "\033[1m"
    DIM = "\033[2m"
    ITALIC = "\033[3m"

    RED = "\033[31m"
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    BLUE = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN = "\033[36m"
    WHITE = "\033[37m"


class Styler:
    """Applies theme colors based on config."""

    def __init__(self, use_colors: bool = True, theme: Theme | None = None) -> None:
        self.use_colors = use_colors
        if theme is None:
            from cogent.observability.core.config import Theme as _Theme

            self._theme = _Theme()
        else:
            self._theme = theme

    def _wrap(self, text: str, style: str) -> str:
        if not self.use_colors or not style:
            return text
        return style + text + Colors.RESET

    def agent(self, text: str) -> str:
        return self._wrap(text, self._theme.agent)

    def muted_agent(self, text: str) -> str:
        """Dimmed agent style for delegated/nested runs."""
        return self._wrap(text, Colors.DIM + self._theme.agent)

    def tool(self, text: str) -> str:
        return self._wrap(text, self._theme.tool)

    def success(self, text: str) -> str:
        return self._wrap(text, self._theme.success)

    def error(self, text: str) -> str:
        return self._wrap(text, self._theme.error)

    def warning(self, text: str) -> str:
        return self._wrap(text, self._theme.warning)

    def info(self, text: str) -> str:
        return self._wrap(text, self._theme.info)

    def dim(self, text: str) -> str:
        return self._wrap(text, self._theme.dim)

    def bold(self, text: str) -> str:
        return self._wrap(text, self._theme.bold)

    def content(self, text: str) -> str:
        """Default terminal color for readable body content."""
        return text

    def italic(self, text: str) -> str:
        """Italic dim — for LLM reasoning and thinking text."""
        return self._wrap(text, self._theme.italic)

    def muted_info(self, text: str) -> str:
        """Dimmed info style for delegated/nested labels."""
        return self._wrap(text, Colors.DIM + self._theme.info)

    def muted_success(self, text: str) -> str:
        """Dimmed success style for delegated/nested labels."""
        return self._wrap(text, Colors.DIM + self._theme.success)


class AgentFormatter(BaseFormatter):
    """Formats agent.* events."""

    patterns = ["agent.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        agent_name = event.get("agent_name", "Agent")
        formatted_name = self.format_name(agent_name)
        is_delegated = bool(event.get("parent_run_id"))
        name_part = (
            s.muted_agent(formatted_name) if is_delegated else s.agent(formatted_name)
        )

        action = event.action

        if action == "invoked":
            task = event.get("task", "")
            run_id = event.correlation_id or ""
            run_id_str = f" {s.dim(run_id[:8])}" if run_id else ""
            input_source = str(event.get("input_source", "")).strip().lower()
            if input_source in {"user", "agent", "system"}:
                input_label = self._label(input_source, "input")
            elif event.get("parent_run_id"):
                input_label = self._label("agent", "input")
            else:
                input_label = self._label("user", "input")
            label_part = (
                s.muted_info(input_label) if is_delegated else s.info(input_label)
            )

            # Build compact context hint: (user:thread), (user), or (thread)
            _uid = event.get("user_id")
            _tid = event.get("thread_id")
            if _uid and _tid:
                ctx_str = f" {s.dim(f'({_uid}:{_tid})')}"
            elif _uid:
                ctx_str = f" {s.dim(f'({_uid})')}"
            elif _tid:
                ctx_str = f" {s.dim(f'({_tid})')}"
            else:
                ctx_str = ""

            if task:
                task = str(task).replace("\n", " ")
                if config.truncate:
                    task = self.truncate(task, config.truncate)
                return f"{name_part} {label_part}{run_id_str}{ctx_str}\n  {s.content(task)}"
            return None

        elif action == "thinking":
            return None

        elif action == "reasoning":
            thought = event.get("thought_preview", "")
            if thought:
                if config.truncate:
                    thought = self.truncate(thought, config.truncate)
                return f"{name_part} {s.dim(self._label('agent', 'reasoning'))}\n  {s.italic(thought)}"
            return f"{name_part} {s.dim(self._label('agent', 'reasoning'))}"

        elif action == "acting":
            return f"{name_part} {s.dim(self._label('agent', 'acting'))}"

        elif action == "responded":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                duration_str = f" ({self.format_duration(event.data['duration_ms'])})"

            # Token info
            tokens = event.get("tokens", {})
            token_str = ""
            if tokens and tokens.get("total"):
                total = tokens["total"]
                token_str = f" • {s.dim(f'{total} tokens')}"
            response_str = ""
            preview = event.get("response_preview") or event.get("response", "")
            if preview:
                preview = str(preview)
                # Unwrap StructuredResult — show only the .data repr
                if preview.startswith("StructuredResult("):
                    try:
                        from cogent.agent.output import StructuredResult

                        raw = event.get("response")
                        if isinstance(raw, StructuredResult):
                            preview = repr(raw.data)
                    except Exception:
                        pass
                preview = preview.replace("\n", " ")
                if config.truncate:
                    preview = self.truncate(preview, config.truncate)
                response_str = f"\n  {s.content(preview)}"

            duration_part = (
                s.muted_success(duration_str)
                if (duration_str and is_delegated)
                else s.success(duration_str)
                if duration_str
                else ""
            )
            completed_label = self._label("agent", "completed")
            label_part = (
                s.muted_success(completed_label)
                if is_delegated
                else s.success(completed_label)
            )
            return f"{name_part} {label_part}{duration_part}{token_str}{response_str}"

        elif action == "error":
            error = event.get("error", "Unknown error")
            return f"{name_part} {s.error(self._label('agent', 'error'))}\n  {s.error(str(error))}"

        # Default for unknown agent actions
        return f"{name_part} {s.dim(self._label('agent', action))}"


class ToolFormatter(BaseFormatter):
    """Formats tool.* and subagent.* events."""

    patterns = ["tool.*", "subagent.*"]

    def _name_prefix(self, event: Event, is_subagent: bool) -> str:  # noqa: ARG002
        """Return 'a2a://' or 'mcp://' prefix, or empty string."""
        if is_subagent and event.get("subagent_type") == "a2a":
            return "a2a://"
        if not is_subagent:
            src = str(event.get("tool_source", ""))
            if src.startswith("mcp"):
                return "mcp://"
        return ""

    def _name_address(self, event: Event, is_subagent: bool) -> str:
        """Return '@host:port' or '@servername' suffix, or empty string."""
        if is_subagent and event.get("subagent_type") == "a2a":
            url = event.get("subagent_url", "")
            if url:
                from urllib.parse import urlparse

                netloc = urlparse(str(url)).netloc
                return f"@{netloc}"
        if not is_subagent:
            src = str(event.get("tool_source", ""))
            if src.startswith("mcp:"):
                return f"@{src[4:]}"
        return ""

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        is_subagent_event = event.category == "subagent"
        name_key = "subagent_name" if is_subagent_event else "tool_name"
        fallback_key = "subagent" if is_subagent_event else "tool"
        tool_name = event.get(name_key, event.get(fallback_key, event.category))
        agent_name = event.get("agent_name", "")
        call_id = event.get("call_id", "")

        # Short ID for display (first 8 chars)
        short_id = call_id[:8] if call_id else ""

        agent_prefix = f"{s.agent(self.format_name(agent_name))} " if agent_name else ""
        action = event.action

        def info_label(text: str) -> str:
            return s.muted_info(text) if is_subagent_event else s.info(text)

        def success_label(text: str) -> str:
            return s.muted_success(text) if is_subagent_event else s.success(text)

        if action == "called":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            if is_subagent_event:
                task = event.get("task")
                body = ""
                if task:
                    task_preview = str(task).replace("\n", " ")
                    if config.truncate:
                        task_preview = self.truncate(task_preview, config.truncate)
                    body = f"\n  {s.tool(self._name_prefix(event, is_subagent_event) + tool_name + self._name_address(event, is_subagent_event))} {s.content(task_preview)}"
                else:
                    body = f"\n  {s.tool(self._name_prefix(event, is_subagent_event) + tool_name + self._name_address(event, is_subagent_event))}"
                label = self._label("subagent", "call")
                return f"{agent_prefix}{info_label(label)} {id_str}{body}"
            else:
                args = event.get("args", {})
                args_str = ""
                if args:
                    args_str = ", ".join(f"{k}={v!r}" for k, v in args.items())
                display_name = (
                    self._name_prefix(event, is_subagent_event)
                    + tool_name
                    + self._name_address(event, is_subagent_event)
                )
                label = self._label("tool", "call")
                call_expr = (
                    f"{display_name}({args_str})" if args_str else f"{display_name}()"
                )
                return f"{agent_prefix}{info_label(label)} {id_str.rstrip()}\n  {s.tool(call_expr)}"

        elif action == "result":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                duration_str = f" ({self.format_duration(event.data['duration_ms'])})"

            id_str = f"{s.dim(short_id)} " if short_id else ""
            result = event.get("result_preview", str(event.get("result", "")))
            result_str = ""
            if result:
                result = str(result).replace("\n", " ")
                if config.truncate:
                    result = self.truncate(result, config.truncate)
                result_formatted = self._format_result(result)
                result_str = f" {s.content(result_formatted)}"

            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            duration_part = success_label(duration_str) if duration_str else ""
            label = (
                self._label("subagent", "result")
                if is_subagent_event
                else self._label("tool", "result")
            )
            ok_mark = "OK" if not config.use_unicode else "✓"
            status = f"{success_label(ok_mark)}{duration_part}"
            return f"{agent_prefix}{success_label(label)} {id_str}{status} {s.tool(display_name)}{result_str}"

        elif action == "failed":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error = event.get("error", "Unknown error")
            error_type = event.get("error_type")
            error_body = f"{error_type}: {error}" if error_type else str(error)
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            label = self._label("tool", "failed")
            err_mark = "‼" if config.use_unicode else "!!"
            return f"{agent_prefix}{s.error(label)} {id_str}{s.error(err_mark)} {s.tool(display_name)} {s.error(error_body)}"

        elif action == "retry":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error = event.get("error", "Unknown error")
            error_type = event.get("error_type")
            attempt = event.get("attempt")
            max_retries = event.get("max_retries")
            error_body = f"{error_type}: {error}" if error_type else str(error)
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            label = self._label("tool", "retry")
            retry_badge = (
                f"(↻{attempt}/{max_retries})"
                if (config.use_unicode and attempt and max_retries)
                else "(↻)"
                if config.use_unicode
                else f"(R{attempt}/{max_retries})"
                if (attempt and max_retries)
                else "(R)"
            )
            err_mark = "‼" if config.use_unicode else "!!"
            return f"{agent_prefix}{s.warning(label)} {id_str}{s.warning(retry_badge)} {s.error(err_mark)} {s.tool(display_name)} {s.error(error_body)}"

        elif action == "error":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error = event.get("error", "Unknown error")
            error_type = event.get("error_type")
            error_body = f"{error_type}: {error}" if error_type else str(error)
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            label = (
                self._label("subagent", "error")
                if is_subagent_event
                else self._label("tool", "error")
            )
            err_mark = "‼" if config.use_unicode else "!!"
            return f"{agent_prefix}{s.error(label)} {id_str}{s.error(err_mark)} {s.tool(display_name)} {s.error(error_body)}"

        elif action == "escalated":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            error = event.get("error", "Unknown error")
            error_type = event.get("error_type")
            error_body = f"{error_type}: {error}" if error_type else str(error)
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            label = self._label("tool", "escalated")
            esc_mark = "(->agent)" if not config.use_unicode else "(↗agent)"
            return f"{agent_prefix}{s.warning(label)} {id_str}{s.warning(esc_mark)} {s.tool(display_name)} {s.dim(error_body)}"
        elif action == "waiting":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            callback_id = event.get("callback_id", "")
            timeout = event.get("timeout", 0)
            interval = event.get("interval", 0)
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            label = self._label("tool", "waiting")
            wait_mark = "\u23f3" if config.use_unicode else "WAITING"
            if timeout is None:
                detail = f" interval={interval:.0f}s"
            elif timeout:
                detail = f" timeout={timeout:.0f}s interval={interval:.0f}s"
            else:
                detail = ""
            return f"{agent_prefix}{s.warning(label)} {id_str}{s.warning(wait_mark)} {s.tool(display_name)}{s.dim(detail)}"
        elif action == "suspended":
            id_str = f"{s.dim(short_id)} " if short_id else ""
            callback_id = event.get("callback_id", "")
            message = event.get("message", "")
            display_name = (
                self._name_prefix(event, is_subagent_event)
                + tool_name
                + self._name_address(event, is_subagent_event)
            )
            label = self._label("tool", "suspended")
            pause_mark = "\u23f8" if config.use_unicode else "PAUSED"
            cb_str = f" callback_id={callback_id}" if callback_id else ""
            msg_str = ""
            if message:
                msg_preview = str(message).replace("\n", " ")
                if config.truncate:
                    msg_preview = self.truncate(msg_preview, config.truncate)
                msg_str = f" {s.content(repr(msg_preview))}"
            return f"{agent_prefix}{s.warning(label)} {id_str}{s.warning(pause_mark)} {s.tool(display_name)}{s.dim(cb_str)}{msg_str}"
        return f"{agent_prefix}{s.dim(self._label(event.category, action))} {s.tool(tool_name)}"

    def _format_result(self, result: str) -> str:
        """Format result value, handling dict-like strings."""
        import ast

        # Try to parse as Python literal (dict, list, etc.)
        try:
            parsed = ast.literal_eval(result)
            if isinstance(parsed, dict):
                # Format as {key='value', ...}
                parts = [f"{k}={v!r}" for k, v in parsed.items()]
                return "{" + ", ".join(parts) + "}"
            elif isinstance(parsed, (list, tuple)):
                return repr(parsed)
            else:
                return repr(parsed)
        except (ValueError, SyntaxError):
            # Not a Python literal, return as quoted string
            return repr(result)


class TaskFormatter(BaseFormatter):
    """Formats task.* events."""

    patterns = ["task.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        action = event.action

        if action == "started":
            task = event.get("task_name", event.get("task", "task"))
            task = str(task)
            if config.truncate:
                task = self.truncate(task, config.truncate)
            return f"{s.success(self._label('task', 'started'))} {task}"

        elif action == "completed":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                duration_str = f" ({self.format_duration(event.data['duration_ms'])})"
            duration_part = s.success(duration_str) if duration_str else ""
            return f"{s.success(self._label('task', 'completed'))}{duration_part}"

        elif action == "failed":
            error = event.get("error", "Unknown error")
            error = str(error)
            if config.truncate:
                error = self.truncate(error, config.truncate)
            return f"{s.error(self._label('task', 'failed'))}\n  {s.error(error)}"

        return f"{s.dim(self._label('task', action))}"


class LLMFormatter(BaseFormatter):
    """Formats llm.* events with thinking/reasoning display."""

    patterns = ["llm.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        agent_name = event.get("agent_name", "LLM")
        formatted_name = self.format_name(agent_name)
        action = event.action

        if action == "request":
            model = event.get("model", "")
            provider = event.get("provider", "")
            model_label = (
                f"{provider}/{model}" if provider and provider != "unknown" else model
            )
            messages: list[dict[str, str]] = event.get("messages", [])
            msg_count = event.get("message_count", len(messages))
            tools = event.get("tools_available", [])
            tools_str = f" • {len(tools)} tools" if tools else ""
            header = f"  {s.dim(self._label('request'))} {s.dim(model_label)} ({msg_count} msgs){s.dim(tools_str)}"
            if messages:
                lines = []
                for m in messages:
                    role = m.get("role", "?")
                    content = m.get("content", "")
                    if config.truncate:
                        content = self.truncate(content, config.truncate)
                    lines.append(f"    {s.dim(role)}: {s.content(content)}")
                return header + "\n" + "\n".join(lines)
            return header

        elif action == "response":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                duration_str = f" ({self.format_duration(event.data['duration_ms'])})"

            # Token info with reasoning breakdown
            tokens = event.get("tokens", {})
            token_str = self._format_tokens(tokens, s)

            # Thinking summary
            thinking_preview = event.get("thinking_preview", "")
            thinking_str = ""
            if thinking_preview:
                preview = thinking_preview
                if config.truncate:
                    preview = self.truncate(preview, config.truncate)
                thinking_str = f"\n    {s.dim('[thinking]')} {s.italic(preview)}"

            # Tool calls
            has_tools = event.get("has_tool_calls", False)
            finish_str = f" → {s.tool('tool_calls')}" if has_tools else ""

            duration_part = s.success(duration_str) if duration_str else ""
            return f"  {s.success(self._label('response'))}{duration_part}{token_str}{finish_str}{thinking_str}"

        elif action == "thinking":
            # Dedicated thinking event
            thinking_content = event.get("thinking", event.get("content", ""))
            thinking_tokens = event.get("thinking_tokens", 0)

            tokens_str = f" ({thinking_tokens} tokens)" if thinking_tokens else ""

            if thinking_content:
                preview = thinking_content
                if config.truncate:
                    preview = self.truncate(preview, config.truncate)
                return f"  {s.info(self._label('thinking'))}{s.dim(tokens_str)}\n    {s.italic(preview)}"
            elif thinking_tokens:
                # OpenAI o-series: has reasoning tokens but no exposed content
                return f"  {s.info(self._label('reasoning'))}{s.dim(tokens_str)} {s.dim('(content not exposed)')}"
            return f"  {s.info(self._label('thinking'))}"

        elif action == "tool_decision":
            tools = event.get("tools_selected", [])
            subagents = event.get("subagents_selected", [])
            regular_tools = event.get("regular_tools_selected", [])
            reasoning = event.get("reasoning", "")

            # Determine label and collect all tool names for body
            has_subagents = bool(subagents)
            has_tools = bool(regular_tools)
            if has_subagents and has_tools:
                label = self._label("tool-decision")
            elif has_subagents:
                label = self._label("subagent-decision")
            else:
                label = self._label("tool-decision")

            all_names: list[str] = list(subagents) + list(regular_tools) or tools
            if len(all_names) > 5:
                all_names = all_names[:5] + [f"... (+{len(all_names) - 5})"]
            tools_body = f"\n  {s.content(', '.join(all_names))}" if all_names else ""

            reason_str = ""
            if reasoning:
                reason_text = reasoning.strip()
                if config.truncate:
                    reason_text = self.truncate(reason_text, config.truncate)
                reason_str = f"\n  {s.italic(reason_text)}"

            return f"{s.agent(formatted_name)} {s.info(label)}{tools_body}{reason_str}"

        return f"{s.agent(formatted_name)} {s.dim(self._label(action))}"

    def _format_tokens(self, tokens: dict, s: Styler) -> str:
        """Format token usage with reasoning breakdown."""
        if not tokens:
            return ""

        parts = []

        # Total tokens
        total = tokens.get("total", tokens.get("total_tokens", 0))
        if total:
            parts.append(f"{total} tokens")

        # Prompt/completion breakdown
        prompt = tokens.get("prompt", tokens.get("prompt_tokens", 0))
        completion = tokens.get("completion", tokens.get("completion_tokens", 0))
        if prompt or completion:
            parts.append(f"in={prompt}/out={completion}")

        # Reasoning/thinking tokens
        reasoning = tokens.get("reasoning", tokens.get("reasoning_tokens", 0))
        if reasoning:
            parts.append(f"reasoning={reasoning}")

        if parts:
            return f" • {s.dim(' '.join(parts))}"
        return ""


class StreamFormatter(BaseFormatter):
    """Formats stream.* events."""

    patterns = ["stream.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        agent_name = event.get("agent_name", "Agent")
        formatted_name = self.format_name(agent_name)
        action = event.action

        if action == "start":
            model = event.get("model", "")
            model_str = f" {s.dim(f'({model})')}" if model else ""
            return f"{s.agent(formatted_name)} {s.info(self._label('stream', 'start'))}{model_str}"

        elif action == "token":
            return None

        elif action == "end":
            duration_str = ""
            if config.show_duration and "duration_ms" in event.data:
                ms = event.data["duration_ms"]
                token_count = event.get("token_count", 0)
                if token_count > 0 and ms > 0:
                    tok_per_sec = token_count / (ms / 1000)
                    duration_str = f" ({ms / 1000:.1f}s, {tok_per_sec:.0f} tok/s)"
                else:
                    duration_str = f" ({self.format_duration(ms)})"
            duration_part = s.success(duration_str) if duration_str else ""
            return f"{s.agent(formatted_name)} {s.success(self._label('stream', 'end'))}{duration_part}"

        elif action == "error":
            error = event.get("error", "Stream error")
            return f"{s.agent(formatted_name)} {s.error(self._label('stream', 'error'))}\n  {s.error(str(error))}"

        return None


class OutputFormatter(BaseFormatter):
    """Formats output.* events.

    `output.generated` is primarily useful for capture, export, and downstream
    subscriptions. The console already shows the final completion line via
    `agent.responded`, so we suppress this event in human-readable terminal
    output to avoid duplicate noise.
    """

    patterns = ["output.generated"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        _ = event
        _ = config
        return None


class MemoryFormatter(BaseFormatter):
    """Formats memory.* events.

    Each memory system gets a distinct label so the source is immediately
    identifiable when scanning logs:

    - ``[conversation-*]`` — thread-based message history
    - ``[acc-*]``          — bounded cognitive compression
    - ``[memory-*]``       — non-agentic auto-retrieval
    - ``[episodic-*]``     — graph-backed experience recall
    - ``[cache-*]``        — semantic tool-output cache

    Agentic knowledge memory (tools) uses ``[tool-*]`` from the ToolFormatter.

    ``memory.write`` / ``memory.read`` / ``memory.delete`` / ``memory.search``
    are suppressed because the tool events (``remember(…)`` / ``recall(…)`` /
    ``forget(…)`` / ``search_memories(…)``) already surface the same operations
    at a higher, more useful level.
    """

    patterns = ["memory.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        indent = config.indent
        action = event.action

        # --- Suppress store-level ops (already shown by tool events) ---
        if action in ("write", "read", "delete", "clear", "search"):
            return None

        # --- Non-agentic auto-retrieval ---
        if action == "retrieved":
            count = event.get("results_count", 0)
            retriever_name = event.get("retriever", "")
            top_scores = event.get("top_scores", [])
            query = event.get("query", "")
            duration = event.get("duration_ms", 0)

            # Build call expression: retriever(query='...')
            call_args = []
            if query:
                short_q = query[:60] + ("…" if len(query) > 60 else "")
                call_args.append(f"query='{short_q}'")
            name = retriever_name or "retrieve"
            call_expr = f"{name}({', '.join(call_args)})"

            # Trailing metrics
            trailing = []
            trailing.append(f"{count} result{'s' if count != 1 else ''}")
            if top_scores:
                score_str = ", ".join(f"{sc:.2f}" for sc in top_scores)
                trailing.append(f"scores=[{score_str}]")
            if duration:
                trailing.append(f"{duration:.0f}ms")
            trailing_str = f" • {' • '.join(trailing)}" if trailing else ""
            return (
                f"{indent}{s.dim(self._label('memory', 'retrieved'))} "
                f"{s.dim(call_expr)}{s.dim(trailing_str)}"
            )

        # --- Conversation load/save ---
        # The ``mode`` field distinguishes transcript from ACC.
        if action == "conversation.loaded":
            mode = event.get("mode", "transcript")
            layer = "acc" if mode == "acc" else "conversation"
            tid = event.get("thread_id", "")
            msg_count = event.get("message_count", 0)
            if msg_count:
                call_expr = f"{tid}(messages={msg_count})"
            else:
                call_expr = f"{tid}() • new"
            return f"{indent}{s.dim(self._label(layer, 'loaded'))} {s.dim(call_expr)}"

        if action == "conversation.saved":
            mode = event.get("mode", "transcript")
            layer = "acc" if mode == "acc" else "conversation"
            tid = event.get("thread_id", "")
            msg_count = event.get("message_count", 0)
            call_args = []
            if msg_count:
                call_args.append(f"messages={msg_count}")
            call_expr = f"{tid}({', '.join(call_args)})"
            return f"{indent}{s.dim(self._label(layer, 'saved'))} {s.dim(call_expr)}"

        # --- ACC context / update ---
        if action == "acc.context_formatted":
            has_ctx = event.get("has_context", False)
            chars = event.get("context_chars", 0)
            stats = event.get("acc_stats")
            if has_ctx and stats:
                breakdown = (
                    f"{stats.get('constraints', 0)} constraints, "
                    f"{stats.get('entities', 0)} entities, "
                    f"{stats.get('actions', 0)} actions, "
                    f"{stats.get('context', 0)} context"
                )
                detail = (
                    f"{chars} chars • {stats.get('total_items', 0)} items ({breakdown})"
                )
            elif has_ctx:
                detail = f"{chars} chars injected"
            else:
                detail = "no prior state"
            return f"{indent}{s.dim(self._label('acc', 'context'))} {s.dim(detail)}"

        if action == "acc.updated":
            stats = event.get("acc_stats")
            if stats:
                breakdown = (
                    f"{stats.get('constraints', 0)} constraints, "
                    f"{stats.get('entities', 0)} entities, "
                    f"{stats.get('actions', 0)} actions, "
                    f"{stats.get('context', 0)} context"
                )
                detail = f"{stats.get('total_items', 0)} items ({breakdown})"
            else:
                tool_count = event.get("tool_calls_count", 0)
                detail = (
                    f"compressed {tool_count} tool call{'s' if tool_count != 1 else ''}"
                    if tool_count
                    else "compressed turn"
                )
            return f"{indent}{s.dim(self._label('acc', 'updated'))} {s.dim(detail)}"

        # --- Semantic cache ---
        if action in ("cache.hit", "cache.miss", "cache.write"):
            tool = event.get("tool_name", "")
            raw_key = event.get("cache_key", "")
            # Strip "toolname:" prefix for display
            display_key = raw_key.split(":", 1)[1] if ":" in raw_key else raw_key

            if action == "cache.hit":
                raw_matched = event.get("matched_key", "")
                matched_display = (
                    raw_matched.split(":", 1)[1] if ":" in raw_matched else raw_matched
                )
                score = event.get("similarity")
                parts = [s.dim(tool)]
                if display_key and matched_display and display_key != matched_display:
                    parts.append(
                        s.dim(f"'{display_key}' → matched '{matched_display}'")
                    )
                    if score is not None:
                        parts.append(s.dim(f"(similarity={score:.2f})"))
                elif display_key:
                    parts.append(s.dim(f"'{display_key}'"))
                return f"{indent}{s.dim(self._label('cache', 'hit'))} {' '.join(parts)}"

            detail = f"{tool} • {display_key}" if display_key else tool
            label = "miss" if action == "cache.miss" else "write"
            return f"{indent}{s.dim(self._label('cache', label))} {s.dim(detail)}"

        # --- L4: Episodic memory ---
        if action == "episodic.recalled":
            count = event.get("observations_count", 0)
            query = event.get("query", "")
            sources = event.get("source_threads", {})
            parts = []
            if query:
                short_q = query[:60] + ("…" if len(query) > 60 else "")
                parts.append(f"query='{short_q}'")
            parts.append(f"{count} observation{'s' if count != 1 else ''}")
            if sources:
                threads = ", ".join(sources)
                parts.append(
                    f"from {len(sources)} episode{'s' if len(sources) != 1 else ''} ({threads})"
                )
            return (
                f"{indent}{s.dim(self._label('episodic', 'recalled'))} "
                f"{s.dim(' • '.join(parts))}"
            )

        if action == "episodic.recorded":
            tid = event.get("thread_id", "")
            ep_id = event.get("episode_id", "")
            count = event.get("observations_count", 0)
            short_ep = ep_id[:8] if ep_id else ""
            call_args = []
            if short_ep:
                call_args.append(f"episode={short_ep}")
            call_args.append(f"observations={count}")
            call_expr = f"{tid}({', '.join(call_args)})"
            return f"{indent}{s.dim(self._label('episodic', 'recorded'))} {s.dim(call_expr)}"

        if action == "episodic.reflected":
            ep_id = event.get("episode_id", "")
            count = event.get("reflections_count", 0)
            short_ep = ep_id[:8] if ep_id else ""
            call_args = []
            if short_ep:
                call_args.append(f"episode={short_ep}")
            call_args.append(f"lessons={count}")
            call_expr = f"reflect({', '.join(call_args)})"
            return f"{indent}{s.dim(self._label('episodic', 'reflected'))} {s.dim(call_expr)}"

        # Unknown memory sub-event — dim fallback
        return f"{indent}{s.dim(self._label('memory', action))}"


class RetrievalFormatter(BaseFormatter):
    """Formats retrieval.* events.

    Labels:

    - ``[retrieval-start]``     — retrieval query initiated
    - ``[retrieval-complete]``  — results returned
    - ``[retrieval-error]``     — retrieval failed
    - ``[retrieval-indexing]``  — summary index document processed
    - ``[retrieval-indexed]``   — summary index build completed
    """

    patterns = ["retrieval.*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:
        s = Styler(config.use_colors, config.theme)
        indent = config.indent
        action = event.action
        retriever = event.get("retriever", "")

        if action == "start":
            query = event.get("query", "")
            k = event.get("k", 4)
            call_args = []
            if query:
                short_q = query[:60] + ("…" if len(query) > 60 else "")
                call_args.append(f"query='{short_q}'")
            call_args.append(f"k={k}")
            name = retriever or "retrieve"
            call_expr = f"{name}({', '.join(call_args)})"
            return (
                f"{indent}{s.info(self._label('retrieval', 'start'))}\n"
                f"{indent}  {s.tool(call_expr)}"
            )

        if action == "complete":
            count = event.get("results_count", 0)
            top_scores = event.get("top_scores", [])
            duration = event.get("duration_ms", 0)
            name = retriever or "retrieve"

            trailing = []
            trailing.append(f"{count} result{'s' if count != 1 else ''}")
            if top_scores:
                score_str = ", ".join(f"{sc:.2f}" for sc in top_scores)
                trailing.append(f"scores=[{score_str}]")
            if duration:
                trailing.append(self.format_duration(duration))
            trailing_str = f" {' • '.join(trailing)}" if trailing else ""
            ok_mark = "✓" if config.use_unicode else "OK"
            return (
                f"{indent}{s.success(self._label('retrieval', 'complete'))} "
                f"{s.success(ok_mark)} {s.tool(name)}{s.dim(trailing_str)}"
            )

        if action == "error":
            error = event.get("error", "Unknown error")
            duration = event.get("duration_ms", 0)
            name = retriever or "retrieve"
            duration_str = f" ({self.format_duration(duration)})" if duration else ""
            err_mark = "‼" if config.use_unicode else "!!"
            return (
                f"{indent}{s.error(self._label('retrieval', 'error'))} "
                f"{s.error(err_mark)} {s.tool(name)}{s.dim(duration_str)} "
                f"{s.error(str(error))}"
            )

        # --- Summary index events ---
        if action == "summary_index.start":
            doc_count = event.get("documents_count", 0)
            suffix = "s" if doc_count != 1 else ""
            return (
                f"{indent}{s.info(self._label('retrieval', 'indexing'))} "
                f"{s.dim(f'{doc_count} document{suffix}')}"
            )

        if action == "summary_index.document_summarized":
            idx = event.get("doc_index", 0)
            total = event.get("doc_total", 0)
            duration = event.get("duration_ms", 0)
            duration_str = f" ({self.format_duration(duration)})" if duration else ""
            return (
                f"{indent}  {s.dim(self._label('retrieval', 'summarized'))} "
                f"{s.dim(f'{idx}/{total}')}{s.dim(duration_str)}"
            )

        if action == "summary_index.complete":
            doc_count = event.get("documents_count", 0)
            summary_count = event.get("summaries_count", 0)
            duration = event.get("duration_ms", 0)
            duration_str = f" ({self.format_duration(duration)})" if duration else ""
            ok_mark = "✓" if config.use_unicode else "OK"
            return (
                f"{indent}{s.success(self._label('retrieval', 'indexed'))} "
                f"{s.success(ok_mark)} "
                f"{s.dim(f'{summary_count} summaries from {doc_count} docs')}"
                f"{s.dim(duration_str)}"
            )

        if action == "summary_index.error":
            error = event.get("error", "Unknown error")
            duration = event.get("duration_ms", 0)
            duration_str = f" ({self.format_duration(duration)})" if duration else ""
            err_mark = "‼" if config.use_unicode else "!!"
            return (
                f"{indent}{s.error(self._label('retrieval', 'index-error'))} "
                f"{s.error(err_mark)}{s.dim(duration_str)} {s.error(str(error))}"
            )

        # Unknown retrieval sub-event — dim fallback
        return f"{indent}{s.dim(self._label('retrieval', action))}"


class DefaultFormatter(BaseFormatter):
    """Fallback formatter for unhandled events.

    Unrecognised event types are suppressed from console output.  They still
    flow through the event bus (available to ``observer.on()`` subscribers)
    and are stored by ``capture=`` patterns.
    """

    patterns = ["*"]

    def format(self, event: Event, config: FormatConfig) -> str | None:  # noqa: ARG002
        return None
