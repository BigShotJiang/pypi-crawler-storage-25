"""Suspend — signal that a tool needs to complete out-of-band.

Raise ``Suspend`` from a tool to tell the agent loop:
*"I can't finish right now — save my temporary result and stop.
 The application will call ``agent.resume()`` later with the real result."*

When the delay is short enough to poll, pass a ``check`` callback and a
``timeout``.  The executor will call ``check()`` every ``interval`` seconds.
If ``check()`` returns a non-``None`` string before the deadline, the tool
completes normally — no suspension, no external resume needed.  If the
timeout expires first, the run suspends as usual.

Pass ``timeout=None`` to poll indefinitely — the tool keeps waiting until
``check()`` returns a result.  The run never suspends.  Use this when the
external service always has a polling endpoint.

Examples::

    # Immediate suspend (pure push-only, no polling endpoint)
    raise SuspendError(callback_id=job_id, message="Waiting for approval.")

    # Auto-wait up to 30 s, then suspend if still pending
    raise SuspendError(
        callback_id=job_id,
        message="Report generating...",
        check=lambda: poll_job(job_id),   # () -> str | None
        timeout=30.0,
        interval=2.0,
    )

    # Wait indefinitely — tool handles its own lifecycle
    raise SuspendError(
        callback_id=job_id,
        message="Waiting for approval...",
        check=lambda: approval_api.status(job_id),
        timeout=None,
        interval=60.0,
    )
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any


class SuspendError(Exception):
    """Raised by a tool to pause the agent run until an external result arrives.

    Attributes:
        callback_id: Application-defined identifier for matching the resume
            call to this suspension (e.g. a job ID, approval ID, ticket number).
        message: Interim result string returned to the LLM so it can
            acknowledge the suspension before the run ends.
        check: Optional polling callback ``() -> str | None`` (sync or async).
            Return a string to auto-resolve; return ``None`` to keep waiting.
        timeout: Maximum seconds to poll before actually suspending.
            ``0`` (default) means suspend immediately.  ``None`` means poll
            indefinitely until ``check()`` returns a result.
        interval: Seconds between consecutive ``check()`` calls (default ``2``).
    """

    __slots__ = ("callback_id", "check", "interval", "message", "timeout")

    def __init__(
        self,
        *,
        callback_id: str,
        message: str = "",
        check: Callable[[], str | None]
        | Callable[[], Awaitable[str | None]]
        | None = None,
        timeout: float | None = 0.0,
        interval: float = 2.0,
    ) -> None:
        self.callback_id = callback_id
        self.message = message or f"Operation suspended (callback_id={callback_id})"
        self.check: Callable[[], Any] | None = check
        self.timeout: float | None = timeout
        self.interval = max(0.1, interval)
        super().__init__(self.message)


# Backward-compatible alias
Suspend = SuspendError
