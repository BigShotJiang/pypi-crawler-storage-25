"""Model catalog for Cogent.

Provides a queryable record of LLM models populated by **live provider API
calls** rather than a bundled static JSON file.  The catalog has no source of
truth other than the providers themselves — call a factory method to fetch
fresh data, query it in memory, and optionally save the result to disk for
offline use or caching.

Design principles
-----------------
* No bundled data — stale data is worse than no data.
* ``ModelInfo`` is an immutable value object; the same type works for live data
  and persisted snapshots.
* ``ModelCatalog`` wraps a list of ``ModelInfo`` objects with filter/query
  helpers.  It is always constructed from a list — fetching and caching are
  handled by the async class-method factories.
* ``save()`` / ``load()`` offer simple JSON persistence for caching; the
  format carries a ``fetched_at`` timestamp so callers can decide whether to
  refresh.

Usage::

    from cogent.models.catalog import ModelCatalog

    # Fetch from a single provider
    catalog = await ModelCatalog.from_provider("openai")

    # Fetch from OpenRouter — 200+ models, live pricing, one request
    catalog = await ModelCatalog.from_openrouter()

    # Query (same API regardless of how the catalog was built)
    catalog.list_models(provider="openai")
    catalog.list_models(capability="tools", status="active")
    catalog.cheapest(capability="tools")
    catalog.get_model("gpt-4o")

    # Persist for later / offline use
    catalog.save("~/.cogent/models.json")
    catalog = ModelCatalog.load("~/.cogent/models.json")
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

# Status lifecycle:
#   unknown   → not yet confirmed
#   preview   → available but API contract may change
#   active    → stable, fully supported
#   deprecated → provider has published a removal notice
#   shut_down  → confirmed no longer accepting requests
ModelStatus = Literal["active", "deprecated", "preview", "shut_down", "unknown"]


@dataclass(slots=True, frozen=True)
class ModelInfo:
    """Lifecycle, pricing, and capability metadata for a single model.

    Attributes:
        id: Provider-side model identifier (e.g. ``"gpt-4o"``).
        provider: Cogent provider key (e.g. ``"openai"``, ``"anthropic"``).
        family: Logical model family for grouping versions (e.g. ``"gpt-4o"``).
        status: Lifecycle status.
        added_at: ISO-8601 date when the model was first cataloged.
        last_seen_at: ISO-8601 date of the most recent successful scan.
        deprecation_notice_date: ISO-8601 date the provider published the
            deprecation announcement.
        deprecation_effective_date: ISO-8601 date the provider states the
            model will stop accepting requests.
        deprecated_by: Model ID of the recommended successor, if any.
        context_window: Maximum input context in tokens, if known.
        max_output_tokens: Maximum tokens the model can generate per request.
        input_cost_per_1m: USD cost per 1 million input tokens.
        output_cost_per_1m: USD cost per 1 million output tokens.
        cached_input_cost_per_1m: USD cost per 1 million cached input tokens.
        capabilities: Tuple of capability tags — ``"chat"``, ``"tools"``,
            ``"vision"``, ``"reasoning"``, ``"prompt_caching"``, ``"batch"``,
            ``"audio"``, ``"embedding"``.
    """

    id: str
    provider: str
    family: str | None = None
    status: ModelStatus = "unknown"
    added_at: str | None = None
    last_seen_at: str | None = None
    deprecation_notice_date: str | None = None
    deprecation_effective_date: str | None = None
    deprecated_by: str | None = None
    context_window: int | None = None
    max_output_tokens: int | None = None
    input_cost_per_1m: float | None = None
    output_cost_per_1m: float | None = None
    cached_input_cost_per_1m: float | None = None
    capabilities: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "provider": self.provider,
            "family": self.family,
            "status": self.status,
            "added_at": self.added_at,
            "last_seen_at": self.last_seen_at,
            "deprecation_notice_date": self.deprecation_notice_date,
            "deprecation_effective_date": self.deprecation_effective_date,
            "deprecated_by": self.deprecated_by,
            "context_window": self.context_window,
            "max_output_tokens": self.max_output_tokens,
            "input_cost_per_1m": self.input_cost_per_1m,
            "output_cost_per_1m": self.output_cost_per_1m,
            "cached_input_cost_per_1m": self.cached_input_cost_per_1m,
            "capabilities": list(self.capabilities),
        }


class ModelCatalog:
    """Queryable collection of model metadata.

    Build one with a factory method or construct directly from a list of
    :class:`ModelInfo` objects (useful in tests).

    All query methods are synchronous and operate on whatever data the instance
    was constructed with.  Fetching is done once, up front, by the factory.
    """

    def __init__(
        self,
        models: list[ModelInfo],
        fetched_at: str | None = None,
    ) -> None:
        self._models = list(models)
        self.fetched_at = fetched_at
        # Primary index: provider:id
        self._by_provider_id: dict[str, ModelInfo] = {
            f"{m.provider}:{m.id}": m for m in models
        }
        # Secondary index: bare id — active wins over other statuses
        self._by_id: dict[str, ModelInfo] = {}
        for m in sorted(models, key=lambda x: x.status != "active"):
            if m.id not in self._by_id:
                self._by_id[m.id] = m

    # ------------------------------------------------------------------
    # Async factories
    # ------------------------------------------------------------------

    @classmethod
    async def from_provider(
        cls,
        provider: str,
        api_key: str | None = None,
    ) -> ModelCatalog:
        """Fetch the model list from a provider's API.

        Args:
            provider: Provider name — ``"openai"``, ``"anthropic"``,
                ``"groq"``, ``"mistral"``, ``"gemini"``, ``"xai"``,
                ``"deepseek"``, ``"cerebras"``, ``"cohere"``,
                or ``"openrouter"``.
            api_key: Override the API key; otherwise the environment variable
                for that provider is used.

        Returns:
            :class:`ModelCatalog` populated with live data.
        """
        fetcher = _FETCHERS.get(provider.lower())
        if fetcher is None:
            raise ValueError(
                f"No fetcher for provider {provider!r}. Supported: {sorted(_FETCHERS)}"
            )
        models = await fetcher(api_key)
        now = datetime.now(UTC).isoformat()
        return cls(models, fetched_at=now)

    @classmethod
    async def from_openrouter(cls, api_key: str | None = None) -> ModelCatalog:
        """Fetch all models from OpenRouter in a single request.

        OpenRouter exposes 200+ models from OpenAI, Anthropic, Google, Meta,
        Mistral, and others — with live pricing and context-window data.  This
        is the richest single-call source for cross-provider model metadata.

        Args:
            api_key: OpenRouter API key; falls back to ``OPENROUTER_API_KEY``.

        Returns:
            :class:`ModelCatalog` populated with live OpenRouter data.
        """
        models = await _fetch_openrouter(api_key)
        now = datetime.now(UTC).isoformat()
        return cls(models, fetched_at=now)

    # ------------------------------------------------------------------
    # Queries  (same API whether built from live data or loaded from disk)
    # ------------------------------------------------------------------

    def list_models(
        self,
        provider: str | None = None,
        status: ModelStatus | None = "active",
        capability: str | None = None,
    ) -> list[ModelInfo]:
        """Return models matching the given filters.

        Args:
            provider: Limit to a specific provider (case-insensitive).
            status: Limit by status. Pass ``None`` to return all statuses.
            capability: Limit to models that have this capability tag
                (e.g. ``"tools"``, ``"vision"``, ``"reasoning"``).

        Returns:
            Filtered list of :class:`ModelInfo`.
        """
        results: list[ModelInfo] = self._models
        if provider:
            prov = provider.lower()
            results = [m for m in results if m.provider == prov]
        if status is not None:
            results = [m for m in results if m.status == status]
        if capability:
            results = [m for m in results if capability in m.capabilities]
        return results

    def list_providers(self) -> list[str]:
        """Return sorted list of providers that have at least one active model."""
        return sorted({m.provider for m in self._models if m.status == "active"})

    def get_model(self, model_id: str, provider: str | None = None) -> ModelInfo | None:
        """Look up a model by ID.

        Args:
            model_id: Model identifier (e.g. ``"gpt-4o"``).
            provider: Constrain lookup to a specific provider.

        Returns:
            :class:`ModelInfo` or ``None`` if not found.
        """
        if provider:
            return self._by_provider_id.get(f"{provider.lower()}:{model_id}")
        return self._by_id.get(model_id)

    def is_available(self, model_id: str, provider: str | None = None) -> bool:
        """Return ``True`` if the model's status is ``active``."""
        info = self.get_model(model_id, provider)
        return info is not None and info.status == "active"

    def find_latest(self, family: str, provider: str | None = None) -> ModelInfo | None:
        """Return the most recently added active model in a family.

        Args:
            family: Family name (e.g. ``"gpt-4o"``).
            provider: Optional provider filter.

        Returns:
            :class:`ModelInfo` with the latest ``added_at``, or ``None``.
        """
        candidates = [
            m
            for m in self._models
            if m.family == family
            and m.status == "active"
            and (provider is None or m.provider == provider.lower())
        ]
        if not candidates:
            return None
        return max(candidates, key=lambda m: m.added_at or "0000-00-00")

    def find_by_family(
        self, family: str, provider: str | None = None
    ) -> list[ModelInfo]:
        """Return all models (any status) in a family, oldest to newest."""
        results = [
            m
            for m in self._models
            if m.family == family
            and (provider is None or m.provider == provider.lower())
        ]
        return sorted(results, key=lambda m: m.added_at or "0000-00-00")

    def cheapest(
        self,
        provider: str | None = None,
        capability: str | None = None,
        by: str = "input",
    ) -> ModelInfo | None:
        """Return the active model with the lowest token price.

        Args:
            provider: Optional provider filter.
            capability: Optional capability filter (e.g. ``"tools"``).
            by: Cost dimension — ``"input"`` (default), ``"output"``,
                or ``"avg"`` (average of input + output costs).

        Returns:
            Cheapest :class:`ModelInfo`, or ``None`` if no pricing data.
        """
        candidates = self.list_models(provider=provider, capability=capability)
        if not candidates:
            return None

        def _key(m: ModelInfo) -> float:
            if by == "output":
                v = m.output_cost_per_1m
            elif by == "avg":
                i, o = m.input_cost_per_1m, m.output_cost_per_1m
                v = (i + o) / 2 if i is not None and o is not None else None
            else:
                v = m.input_cost_per_1m
            return v if v is not None else float("inf")

        ranked = sorted(candidates, key=_key)
        best = ranked[0] if ranked else None
        if best and _key(best) == float("inf"):
            return None
        return best

    def summary(self) -> dict[str, dict[str, int]]:
        """Return per-provider model counts grouped by status."""
        result: dict[str, dict[str, int]] = {}
        for m in self._models:
            counts = result.setdefault(m.provider, {})
            counts[m.status] = counts.get(m.status, 0) + 1
        return result

    # ------------------------------------------------------------------
    # Persistence  (for caching — no schema versioning)
    # ------------------------------------------------------------------

    def save(self, path: Path | str) -> None:
        """Write the catalog to a JSON file for caching or offline use.

        The saved format is a plain ``{"fetched_at": ..., "models": [...]}``
        object — there is no schema versioning because this is considered an
        ephemeral snapshot, not a source of truth.

        Args:
            path: Destination file path (``~`` is expanded).
        """
        p = Path(path).expanduser()
        p.parent.mkdir(parents=True, exist_ok=True)
        data = {
            "fetched_at": self.fetched_at,
            "models": sorted(
                [m.to_dict() for m in self._models],
                key=lambda d: (d["provider"], d["id"]),
            ),
        }
        p.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

    @classmethod
    def load(cls, path: Path | str) -> ModelCatalog:
        """Load a catalog from a file previously written by :meth:`save`.

        Args:
            path: Path to the JSON file (``~`` is expanded).

        Returns:
            :class:`ModelCatalog` with the persisted models.
        """
        p = Path(path).expanduser()
        raw = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(raw, list):
            # Bare list — legacy compat
            return cls([_model_from_dict(m) for m in raw])
        models = [_model_from_dict(m) for m in raw.get("models", [])]
        return cls(models, fetched_at=raw.get("fetched_at"))

    # ------------------------------------------------------------------
    # Dunder
    # ------------------------------------------------------------------

    def __len__(self) -> int:
        return len(self._models)

    def __repr__(self) -> str:
        active = sum(1 for m in self._models if m.status == "active")
        return (
            f"ModelCatalog(total={len(self._models)}, active={active}, "
            f"fetched_at={self.fetched_at!r})"
        )


# ---------------------------------------------------------------------------
# Per-provider async fetchers
# ---------------------------------------------------------------------------


async def _fetch_openai(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the OpenAI models API."""
    import re

    from openai import AsyncOpenAI

    from cogent.config import get_api_key

    key = api_key or get_api_key("openai")
    client = AsyncOpenAI(api_key=key)
    response = await client.models.list()

    skip_types = (
        "audio",
        "realtime",
        "image",
        "transcribe",
        "tts",
        "search",
        "deep-research",
        "codex",
        "instruct",
    )
    models: list[ModelInfo] = []
    today = datetime.now(UTC).date().isoformat()

    for m in response.data:
        mid = m.id
        if not any(mid.startswith(p) for p in ("gpt-", "o1", "o3", "o4")):
            continue
        if any(s in mid for s in skip_types):
            continue
        if re.search(r"-20\d{2}-\d{2}-\d{2}$", mid) or re.search(r"-20\d{6}$", mid):
            continue
        models.append(
            ModelInfo(
                id=mid,
                provider="openai",
                status="active",
                last_seen_at=today,
                capabilities=("chat", "tools"),
            )
        )
    return sorted(models, key=lambda m: m.id)


async def _fetch_anthropic(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the Anthropic models API."""
    import anthropic

    from cogent.config import get_api_key

    key = api_key or get_api_key("anthropic")
    client = anthropic.AsyncAnthropic(api_key=key)
    today = datetime.now(UTC).date().isoformat()

    models: list[ModelInfo] = []
    response = await client.models.list(limit=100)
    for m in response.data:
        models.append(
            ModelInfo(
                id=m.id,
                provider="anthropic",
                status="active",
                last_seen_at=today,
                capabilities=("chat", "tools", "vision"),
            )
        )
    return sorted(models, key=lambda m: m.id)


async def _fetch_groq(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the Groq models API."""
    from openai import AsyncOpenAI

    from cogent.config import get_api_key

    key = api_key or get_api_key("groq")
    client = AsyncOpenAI(base_url="https://api.groq.com/openai/v1", api_key=key)
    response = await client.models.list()

    skip_types = ("whisper", "prompt-guard", "orpheus", "safeguard")
    today = datetime.now(UTC).date().isoformat()
    models: list[ModelInfo] = []

    for m in response.data:
        mid = m.id
        if any(s in mid for s in skip_types):
            continue
        # Namespaced models (provider/name) need groq: prefix for cogent routing
        cogent_id = f"groq:{mid}" if "/" in mid else mid
        models.append(
            ModelInfo(
                id=cogent_id,
                provider="groq",
                status="active",
                last_seen_at=today,
                capabilities=("chat", "tools"),
            )
        )
    return sorted(models, key=lambda m: m.id)


async def _fetch_mistral(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the Mistral models API."""
    import httpx

    from cogent.config import get_api_key

    key = api_key or get_api_key("mistral")
    today = datetime.now(UTC).date().isoformat()

    skip_types = (
        "embed",
        "moderation",
        "ocr",
        "voxtral",
        "pixtral",
        "tts",
        "transcribe",
        "realtime",
        "vibe",
        "leanstral",
        "latest",
    )
    models: list[ModelInfo] = []

    async with httpx.AsyncClient() as client:
        r = await client.get(
            "https://api.mistral.ai/v1/models",
            headers={"Authorization": f"Bearer {key}"},
            timeout=15,
        )
        r.raise_for_status()
        for m in r.json().get("data", []):
            mid = m["id"]
            if any(s in mid for s in skip_types):
                continue
            models.append(
                ModelInfo(
                    id=mid,
                    provider="mistral",
                    status="active",
                    last_seen_at=today,
                    capabilities=("chat", "tools"),
                )
            )
    return sorted(models, key=lambda m: m.id)


async def _fetch_gemini(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the Gemini models API."""
    from google import genai

    from cogent.config import get_api_key

    key = api_key or get_api_key("gemini")
    client = genai.Client(api_key=key)
    today = datetime.now(UTC).date().isoformat()

    skip = ("aqa", "exp", "thinking", "learnlm", "preview", "latest", "it-")
    models: list[ModelInfo] = []

    for m in client.models.list():
        mid = m.name.removeprefix("models/")
        if "gemini" not in mid:
            continue
        if any(p in mid for p in skip):
            continue
        ctx = getattr(m, "input_token_limit", None)
        models.append(
            ModelInfo(
                id=mid,
                provider="gemini",
                status="active",
                last_seen_at=today,
                context_window=ctx,
                capabilities=("chat", "tools", "vision"),
            )
        )
    return sorted(models, key=lambda m: m.id)


async def _fetch_xai(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the xAI models API."""
    from openai import AsyncOpenAI

    from cogent.config import get_api_key

    key = api_key or get_api_key("xai")
    client = AsyncOpenAI(base_url="https://api.x.ai/v1", api_key=key)
    response = await client.models.list()

    skip_types = ("imagine", "image", "video", "multi-agent")
    today = datetime.now(UTC).date().isoformat()
    models: list[ModelInfo] = []

    for m in response.data:
        mid = m.id
        if any(s in mid for s in skip_types):
            continue
        models.append(
            ModelInfo(
                id=mid,
                provider="xai",
                status="active",
                last_seen_at=today,
                capabilities=("chat", "tools"),
            )
        )
    return sorted(models, key=lambda m: m.id)


async def _fetch_deepseek(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the DeepSeek models API."""
    from openai import AsyncOpenAI

    from cogent.config import get_api_key

    key = api_key or get_api_key("deepseek")
    client = AsyncOpenAI(base_url="https://api.deepseek.com/v1", api_key=key)
    response = await client.models.list()

    today = datetime.now(UTC).date().isoformat()
    models: list[ModelInfo] = []

    for m in response.data:
        models.append(
            ModelInfo(
                id=m.id,
                provider="deepseek",
                status="active",
                last_seen_at=today,
                capabilities=("chat", "tools"),
            )
        )
    return sorted(models, key=lambda m: m.id)


async def _fetch_cerebras(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the Cerebras models API."""
    from cerebras.cloud.sdk import AsyncCerebras

    from cogent.config import get_api_key

    key = api_key or get_api_key("cerebras")
    client = AsyncCerebras(api_key=key)
    today = datetime.now(UTC).date().isoformat()
    models: list[ModelInfo] = []

    async for m in await client.models.list():
        models.append(
            ModelInfo(
                id=m.id,
                provider="cerebras",
                status="active",
                last_seen_at=today,
                capabilities=("chat", "tools"),
            )
        )
    return sorted(models, key=lambda m: m.id)


async def _fetch_cohere(api_key: str | None) -> list[ModelInfo]:
    """Fetch from the Cohere models API."""
    import httpx

    from cogent.config import get_api_key

    key = api_key or get_api_key("cohere")
    today = datetime.now(UTC).date().isoformat()
    models: list[ModelInfo] = []

    async with httpx.AsyncClient() as client:
        r = await client.get(
            "https://api.cohere.com/v2/models",
            headers={"Authorization": f"Bearer {key}", "Accept": "application/json"},
            timeout=15,
        )
        r.raise_for_status()
        for m in r.json().get("models", []):
            mid = m.get("name", "")
            endpoints = m.get("endpoints", [])
            if "chat" not in endpoints and "generate" not in endpoints:
                continue
            models.append(
                ModelInfo(
                    id=mid,
                    provider="cohere",
                    status="active",
                    last_seen_at=today,
                    context_window=m.get("context_length"),
                    capabilities=("chat", "tools")
                    if "chat" in endpoints
                    else ("chat",),
                )
            )
    return sorted(models, key=lambda m: m.id)


async def _fetch_openrouter(api_key: str | None) -> list[ModelInfo]:
    """Fetch all models from the OpenRouter models endpoint.

    Returns rich metadata including live pricing and context windows for
    200+ models across all major providers.
    """
    import httpx

    from cogent.config import get_api_key

    key = api_key or get_api_key("openrouter")
    today = datetime.now(UTC).date().isoformat()

    headers: dict[str, str] = {"Accept": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"

    async with httpx.AsyncClient() as client:
        r = await client.get(
            "https://openrouter.ai/api/v1/models",
            headers=headers,
            timeout=20,
        )
        r.raise_for_status()

    models: list[ModelInfo] = []
    for m in r.json().get("data", []):
        mid = m.get("id", "")
        if not mid:
            continue

        # Provider is the first segment of "provider/model-name"
        provider = mid.split("/")[0] if "/" in mid else "openrouter"

        # Pricing — OpenRouter returns per-token; convert to per-1M
        pricing = m.get("pricing", {}) or {}

        def _to_per_1m(val: str | float | None) -> float | None:
            if val is None:
                return None
            try:
                f = float(val)
                return round(f * 1_000_000, 6) if f else None
            except (TypeError, ValueError):
                return None

        input_cost = _to_per_1m(pricing.get("prompt"))
        output_cost = _to_per_1m(pricing.get("completion"))
        cached_input_cost = _to_per_1m(pricing.get("input_cache_read"))

        ctx = m.get("context_length")
        top_provider = m.get("top_provider") or {}
        max_out = top_provider.get("max_completion_tokens")

        # Capabilities — infer from architecture / modality fields
        arch = m.get("architecture") or {}
        modality = arch.get("modality", "") or ""
        caps: list[str] = ["chat"]
        if "image" in modality or "vision" in modality:
            caps.append("vision")
        if arch.get("tokenizer") == "Mistral":
            pass  # no extra inference
        caps.append("tools")  # assume tools unless marked otherwise

        models.append(
            ModelInfo(
                id=mid,
                provider=provider,
                status="active",
                last_seen_at=today,
                context_window=int(ctx) if ctx else None,
                max_output_tokens=int(max_out) if max_out else None,
                input_cost_per_1m=input_cost,
                output_cost_per_1m=output_cost,
                cached_input_cost_per_1m=cached_input_cost,
                capabilities=tuple(caps),
            )
        )
    return sorted(models, key=lambda m: m.id)


# Registry of per-provider fetchers
_FETCHERS: dict[str, Any] = {
    "openai": _fetch_openai,
    "anthropic": _fetch_anthropic,
    "groq": _fetch_groq,
    "mistral": _fetch_mistral,
    "gemini": _fetch_gemini,
    "google": _fetch_gemini,
    "xai": _fetch_xai,
    "deepseek": _fetch_deepseek,
    "cerebras": _fetch_cerebras,
    "cohere": _fetch_cohere,
    "openrouter": _fetch_openrouter,
}


# ---------------------------------------------------------------------------
# Internal helper
# ---------------------------------------------------------------------------


def _model_from_dict(d: dict[str, Any]) -> ModelInfo:
    caps = tuple(d.get("capabilities") or [])
    return ModelInfo(
        id=d["id"],
        provider=d["provider"],
        family=d.get("family"),
        status=d.get("status", "unknown"),
        added_at=d.get("added_at"),
        last_seen_at=d.get("last_seen_at"),
        deprecation_notice_date=d.get("deprecation_notice_date"),
        deprecation_effective_date=d.get("deprecation_effective_date"),
        deprecated_by=d.get("deprecated_by"),
        context_window=d.get("context_window"),
        max_output_tokens=d.get("max_output_tokens"),
        input_cost_per_1m=d.get("input_cost_per_1m"),
        output_cost_per_1m=d.get("output_cost_per_1m"),
        cached_input_cost_per_1m=d.get("cached_input_cost_per_1m"),
        capabilities=caps,
    )
