"""
NativeExecutor - High-performance native executor.

Key optimizations:
1. Direct asyncio loop (no graph framework overhead)
2. Parallel tool execution with asyncio.gather
3. Cached model binding for zero-overhead tool calls
4. Minimal prompt construction
5. LLM resilience with automatic retry for rate limits

Includes standalone `run()` function for quick execution without Agent class.
"""

from __future__ import annotations

import asyncio
import inspect
from collections.abc import Callable
from typing import TYPE_CHECKING

from cogent.agent.output import (
    ListItemError,
    OutputValidationError,
    ResponseSchema,
    StructuredResult,
    build_correction_message,
    build_list_correction_message,
    build_structured_prompt,
    get_best_method,
    validate_and_parse,
)
from cogent.agent.resilience import ModelResilience, RetryPolicy
from cogent.core.context import EMPTY_CONTEXT, RunContext

# Native message types
from cogent.core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    MessageMetadata,
    SystemMessage,
    ToolMessage,
)
from cogent.core.response import Artifact
from cogent.core.utils import model_identifier, model_provider
from cogent.interceptors.base import (
    InterceptContext,
    Interceptor,
    Phase,
    StopExecution,
    run_interceptors,
)
from cogent.models.base import BaseChatModel
from cogent.models.openai import OpenAIChat
from cogent.tools.base import BaseTool, ToolResult
from cogent.tools.suspend import Suspend as _Suspend

if TYPE_CHECKING:
    from cogent.agent import Agent


def _bind_tools(
    model: BaseChatModel, tools: list, parallel_tool_calls: bool = True
) -> BaseChatModel:
    """Bind tools to a model, passing parallel_tool_calls only when the model supports it."""
    sig = inspect.signature(model.bind_tools)
    if "parallel_tool_calls" in sig.parameters:
        return model.bind_tools(tools, parallel_tool_calls=parallel_tool_calls)
    return model.bind_tools(tools)


async def run(
    task: str,
    tools: list[BaseTool] | None = None,
    model: str | BaseChatModel = "gpt-5.4-mini",
    system_prompt: str | None = None,
    max_iterations: int = 25,
    max_tool_calls_per_turn: int = 50,
    resilience: bool = True,
    verbose: bool = False,
) -> str:
    """Execute a task with tools using native execution.

    Standalone function - no Agent class required.
    Uses native SDK for maximum performance.

    Args:
        task: The task to execute.
        tools: List of tools (created with @tool decorator).
        model: Model name or any native chat model instance.
        system_prompt: Optional system prompt.
        max_iterations: Maximum LLM call iterations.
        max_tool_calls_per_turn: Maximum tool calls per LLM response (default: 50).
        resilience: Enable automatic retry for rate limits (default: True).
        verbose: Print retry/error information (default: False).

    Returns:
        The final answer string.

    Example:
        from cogent import run, tool

        @tool
        def search(query: str) -> str:
            '''Search the web.'''
            return f"Results for {query}"

        result = await run(
            "Search for Python tutorials",
            tools=[search],
        )

        # With different providers
        from cogent.models.anthropic import AnthropicChat

        result = await run(
            "Explain quantum computing",
            model=AnthropicChat(model="claude-sonnet-4-6"),
        )
    """
    # Create or use model
    chat_model = OpenAIChat(model=model) if isinstance(model, str) else model

    # Bind tools if provided
    tools = tools or []
    tool_map = {t.name: t for t in tools}

    if tools:
        bound_model = _bind_tools(chat_model, tools, parallel_tool_calls=True)
    else:
        bound_model = chat_model

    # Setup resilience for LLM calls
    model_resilience = None
    if resilience:

        def on_retry(attempt: int, error: Exception, delay: float) -> None:
            if verbose:
                print(
                    f"⏳ LLM retry {attempt}: {str(error)[:80]}... (waiting {delay:.1f}s)"
                )

        def on_error(error: Exception, attempts: int) -> None:
            if verbose:
                print(f"❌ LLM failed after {attempts} attempts: {error}")

        model_resilience = ModelResilience(
            retry_policy=RetryPolicy.default(),
            on_retry=on_retry,
            on_error=on_error,
        )

    # Build initial messages using native message types
    messages: list[BaseMessage] = []
    if system_prompt:
        messages.append(SystemMessage(system_prompt))
    messages.append(HumanMessage(task))

    # Execution loop
    for _ in range(max_iterations):
        # LLM call with resilience
        if model_resilience:
            exec_result = await model_resilience.execute(bound_model.ainvoke, messages)
            if not exec_result.success:
                raise exec_result.error or RuntimeError("LLM call failed after retries")
            response: AIMessage = exec_result.result
        else:
            response: AIMessage = await bound_model.ainvoke(messages)

        messages.append(response)

        if not response.tool_calls:
            return response.content or ""

        # Check per-turn tool limit
        num_tool_calls = len(response.tool_calls)
        if num_tool_calls > max_tool_calls_per_turn:
            return (
                response.content
                or f"Tool call limit exceeded: {num_tool_calls} tools requested, max {max_tool_calls_per_turn} per turn"
            )

        # Execute tools with concurrency limiting
        semaphore = asyncio.Semaphore(20)  # Max 20 concurrent

        async def execute_with_limit(tc):
            async with semaphore:  # noqa: B023
                return await _execute_tool_native(tc, tool_map)

        tool_results = await asyncio.gather(
            *[execute_with_limit(tc) for tc in response.tool_calls],
            return_exceptions=True,
        )

        for result, tc in zip(tool_results, response.tool_calls, strict=False):
            tool_id = tc.get("id", "")
            if isinstance(result, Exception):
                messages.append(ToolMessage(f"Error: {result}", tool_call_id=tool_id))
            else:
                messages.append(result)

    return "Max iterations reached"


async def _execute_tool_native(
    tool_call: dict[str, object],
    tool_map: dict[str, BaseTool],
) -> ToolMessage:
    """Execute a single tool call (returns native ToolMessage)."""
    tool_name = tool_call.get("name", "")
    args = tool_call.get("args", {})
    tool_id = tool_call.get("id", "")

    tool = tool_map.get(tool_name)
    if tool is None:
        return ToolMessage(f"Error: Unknown tool '{tool_name}'", tool_call_id=tool_id)

    try:
        result = await tool.ainvoke(args)
        if isinstance(result, ToolResult):
            content = result.content
        else:
            content = str(result) if result is not None else ""
        return ToolMessage(content, tool_call_id=tool_id)
    except Exception as e:
        return ToolMessage(f"Error: {e}", tool_call_id=tool_id)


# We need BaseExecutor at class definition time
import contextlib  # noqa: E402

from cogent.executors.base import BaseExecutor  # noqa: E402


class NativeExecutor(BaseExecutor):
    """
    High-performance native executor - the default choice.

    Features:
    - Direct asyncio loop (no graph framework)
    - Parallel tool execution with asyncio.gather
    - Cached bound model for fast tool binding
    - Minimal prompt construction
    - LLM resilience with automatic retry for rate limits

    Trade-offs:
    - No taskboard/working memory
    - No event streaming
    - Limited tool error recovery (but LLM calls are resilient)

    Use for:
    - Most agent tasks (default executor)
    - Latency-critical applications
    - Simple to complex multi-tool tasks

    Example:
        from cogent.executors import NativeExecutor

        executor = NativeExecutor(agent)
        result = await executor.execute("Research ACME Corp and calculate metrics")
    """

    __slots__ = (
        "_bound_model",
        "_tool_map",
        "_max_tool_calls_per_turn",
        "_max_concurrent_tools",
        "_model_resilience",
        "_suspended",
        "_suspend_callback_id",
        "_suspend_tool_call_id",
    )

    def __init__(
        self,
        agent: Agent,
        max_tool_calls_per_turn: int = 50,
        max_concurrent_tools: int = 20,
        resilience: bool = True,
    ) -> None:
        """Initialize NativeExecutor.

        Args:
            agent: The agent to execute.
            max_tool_calls_per_turn: Maximum tool calls per LLM response (default: 50).
            max_concurrent_tools: Maximum tools executing concurrently (default: 20).
            resilience: Enable automatic retry for LLM rate limits (default: True).
        """
        super().__init__(agent)
        self._max_tool_calls_per_turn = max_tool_calls_per_turn
        self._max_concurrent_tools = max_concurrent_tools

        # Pre-cache everything at construction time
        self._bound_model = None
        self._tool_map: dict[str, BaseTool] = {}
        self._model_resilience: ModelResilience | None = None
        self._suspended = False
        self._suspend_callback_id: str | None = None
        self._suspend_tool_call_id: str | None = None
        self._artifacts: list[Artifact] = []

        # Setup model resilience
        if resilience:
            # If the agent has an explicit resilience config, honor it for LLM calls.
            # This prevents long hangs in high-concurrency flows by allowing
            # fast-fail or tighter timeouts.
            agent_resilience_cfg = None
            try:
                agent_resilience_cfg = getattr(
                    getattr(self.agent, "config", None), "resilience_config", None
                )
            except Exception:
                agent_resilience_cfg = None

            retry_policy = RetryPolicy.default()
            timeout_seconds = 120.0
            if agent_resilience_cfg is not None:
                retry_policy = agent_resilience_cfg.get_retry_policy("")
                timeout_seconds = float(agent_resilience_cfg.timeout_seconds or 120.0)

            # Create on_retry callback that logs to the observer
            async def _log_retry(attempt: int, error: Exception, delay: float) -> None:
                """Log retry attempt via the observer."""
                observer = getattr(self.agent, "observer", None)
                if observer:
                    self._emit_observer_event(
                        observer,
                        "agent.thinking",
                        run_context=None,
                        agent=self.agent.name or "agent",
                        agent_name=self.agent.name or "agent",
                        message=f"⏳ LLM retry {attempt}: {str(error)[:60]}... (waiting {delay:.1f}s)",
                    )

            def on_retry_sync(attempt: int, error: Exception, delay: float) -> None:
                """Sync wrapper that prints retry info."""
                import sys

                print(
                    f"⏳ LLM retry {attempt}: {str(error)[:80]}... (waiting {delay:.1f}s)",
                    file=sys.stderr,
                )

            self._model_resilience = ModelResilience(
                retry_policy=retry_policy,
                timeout_seconds=timeout_seconds,
                tracker=getattr(self, "tracker", None),
                on_retry=on_retry_sync,
            )

        self._initialize_cache()

    def _initialize_cache(self) -> None:
        """Pre-cache model binding and tool map."""
        # Cache bound model with parallel tool calls enabled
        if self.agent.all_tools:
            # Enable parallel_tool_calls for batched tool execution
            self._bound_model = _bind_tools(
                self.agent.model, self.agent.all_tools, parallel_tool_calls=True
            )
            # Cache tool lookup map
            self._tool_map = {t.name: t for t in self.agent.all_tools}
        else:
            self._bound_model = self.agent.model

    @staticmethod
    def _lineage_data(
        run_context: RunContext | None,
        *,
        step_id: str | None = None,
        tool_call_id: str | None = None,
    ) -> dict[str, object]:
        """Build a consistent lineage payload for built-in runtime events."""
        payload: dict[str, object] = {}
        if run_context and run_context.run_id:
            payload["run_id"] = run_context.run_id
        if run_context and run_context.parent_run_id:
            payload["parent_run_id"] = run_context.parent_run_id
        if step_id:
            payload["step_id"] = step_id
        if tool_call_id:
            payload["tool_call_id"] = tool_call_id
        if run_context:
            user_id = run_context.metadata.get("user_id")
            if user_id is not None:
                payload["user_id"] = user_id
            thread_id = run_context.metadata.get("thread_id")
            if thread_id is not None:
                payload["thread_id"] = thread_id
        return payload

    def _emit_observer_event(
        self,
        observer: object | None,
        event_type: str,
        *,
        run_context: RunContext | None = None,
        step_id: str | None = None,
        tool_call_id: str | None = None,
        **data: object,
    ) -> None:
        """Emit an observer event with run lineage when available."""
        if observer is None:
            return

        event_correlation_id: str | None = None
        if run_context and run_context.run_id:
            event_correlation_id = run_context.run_id
        else:
            candidate_run_id = data.get("run_id")
            if isinstance(candidate_run_id, str) and candidate_run_id:
                event_correlation_id = candidate_run_id

        lineage = self._lineage_data(
            run_context,
            step_id=step_id,
            tool_call_id=tool_call_id,
        )
        # Merge lineage as defaults — explicit event data takes precedence.
        merged = {**lineage, **data}

        observer.emit(
            event_type,
            correlation_id=event_correlation_id,
            **merged,
        )

    async def execute(
        self,
        task: str,
        context: dict[str, object] | RunContext | None = None,
    ) -> str:
        """Execute task with observability support.

        Uses a tight asyncio loop with parallel tool execution.

        event_correlation_id: str | None = None
        if run_context and run_context.run_id:
            event_correlation_id = run_context.run_id
        else:
            candidate_run_id = data.get("run_id")
            if isinstance(candidate_run_id, str) and candidate_run_id:
                event_correlation_id = candidate_run_id
        Emits events for observability when event_bus is attached.
        Automatically retries on rate limits and transient errors.

            correlation_id=event_correlation_id,
        before the main execution loop.

        If the agent has structured output configured, validates and parses
        the response according to the schema.

        Args:
            task: The task to execute.
            context: Optional context - can be a dict or RunContext.
                     If dict, it's used for message building only.
                     If RunContext, it's also passed to tools and interceptors.

        Returns:
            If output schema configured: StructuredResult with parsed data.
            Otherwise: The final answer string.
        """
        import time

        # Normalize context: convert dict to RunContext with metadata
        run_context: RunContext
        context_dict: dict[str, object] | None = None
        if context is None:
            run_context = EMPTY_CONTEXT
        elif isinstance(context, RunContext):
            run_context = context
            context_dict = context.metadata if context.metadata else None
        else:
            # Dict passed - store in metadata
            run_context = RunContext(metadata=context)
            context_dict = context

        # Auto-populate query field if empty (task lineage tracking)
        if not run_context.query:
            # Create a copy with query set (preserve immutability principle)
            import copy

            run_context = copy.copy(run_context)
            run_context.query = task

        # Set agent reference on context for tool access (e.g., cache)
        run_context.agent = self.agent

        observer = getattr(self.agent, "observer", None)
        agent_name = self.agent.name or "agent"

        async def emit_event(
            event_type: str,
            data: dict[str, object],
            *,
            step_id: str | None = None,
            tool_call_id: str | None = None,
        ) -> None:
            self._emit_observer_event(
                observer,
                event_type,
                run_context=run_context,
                step_id=step_id,
                tool_call_id=tool_call_id,
                **data,
            )

        # Update resilience tracker if we have one
        if self._model_resilience and hasattr(self, "tracker"):
            self._model_resilience.tracker = self.tracker

        # Track execution timing
        execution_start = time.perf_counter()

        # Emit agent invoked event (not USER_INPUT - that's for user-facing input)
        await emit_event(
            "agent.invoked",
            {
                "agent": agent_name,
                "agent_name": agent_name,
                "task": task[:200] + "..." if len(task) > 200 else task,
            },
            step_id="step-0",
        )

        # Flush deferred memory events so they appear right after [user-input]
        for evt_type, evt_data in getattr(self.agent, "_deferred_memory_events", []):
            self._emit_observer_event(
                observer,
                evt_type,
                run_context=run_context,
                step_id="step-0",
                **evt_data,
            )
        self.agent._deferred_memory_events = []

        # Build messages once
        messages = self._build_messages(task, context_dict)

        # === REASONING PHASE ===
        # If reasoning is enabled, think through the problem first
        reasoning_config = getattr(self.agent, "_reasoning_config", None)
        if reasoning_config is not None:
            await self._execute_reasoning(
                task, context_dict, messages, observer, agent_name
            )

        # === STRUCTURED OUTPUT ===
        # If structured output is configured, use specialized execution with retry
        output_config = getattr(self.agent, "_output_config", None)
        if output_config is not None:
            return await self._execute_with_structured_output(
                task, context_dict, messages, observer, agent_name, run_context
            )

        # === STANDARD EXECUTION ===
        # No structured output - use main loop directly
        return await self._execute_main_loop(
            task,
            context_dict,
            messages,
            observer,
            agent_name,
            execution_start,
            run_context,
        )

    async def execute_messages(
        self,
        *,
        task: str,
        messages: list[BaseMessage],
        context: dict[str, object] | RunContext | None = None,
    ) -> str | StructuredResult:
        """Execute using a pre-built message list.

        This enables event-driven execution without converting event
        context into a single prompt string. The provided `messages` are used
        as-is (interceptors may still modify them).

        Args:
            task: High-level task label used for observability and completion checks.
            messages: Pre-built message list to send to the model.
            context: Optional context (dict or RunContext). Dict is stored as metadata.

        Returns:
            Final answer string (or structured output result if configured).
        """
        import time

        # Normalize context
        run_context: RunContext
        context_dict: dict[str, object] | None = None
        if context is None:
            run_context = EMPTY_CONTEXT
        elif isinstance(context, RunContext):
            run_context = context
            context_dict = context.metadata if context.metadata else None
        else:
            run_context = RunContext(metadata=context)
            context_dict = context

        if not messages:
            raise ValueError("execute_messages requires at least one message")

        # Ensure system prompt is present if agent has one and caller didn't include it
        sys_prompt = self.agent.config.system_prompt
        if sys_prompt and not isinstance(messages[0], SystemMessage):
            messages = [SystemMessage(content=sys_prompt), *messages]

        observer = getattr(self.agent, "observer", None)
        agent_name = self.agent.name or "agent"

        if self._model_resilience and hasattr(self, "tracker"):
            self._model_resilience.tracker = self.tracker

        execution_start = time.perf_counter()

        self._emit_observer_event(
            observer,
            "agent.invoked",
            run_context=run_context,
            step_id="step-0",
            agent=agent_name,
            agent_name=agent_name,
            task=task[:200] + "..." if len(task) > 200 else task,
        )

        # Flush deferred memory events so they appear right after [user-input]
        for evt_type, evt_data in getattr(self.agent, "_deferred_memory_events", []):
            self._emit_observer_event(
                observer,
                evt_type,
                run_context=run_context,
                step_id="step-0",
                **evt_data,
            )
        self.agent._deferred_memory_events = []

        # If reasoning is enabled, run it against the provided messages context.
        reasoning_config = getattr(self.agent, "_reasoning_config", None)
        if reasoning_config is not None:
            await self._execute_reasoning(
                task, context_dict, messages, observer, agent_name
            )

        # Structured output path: keep existing behavior for now.
        output_config = getattr(self.agent, "_output_config", None)
        if output_config is not None:
            # Reuse the structured output executor; it rebuilds messages from an effective task.
            # This preserves correctness, even though it doesn't preserve custom message shapes.
            return await self._execute_with_structured_output(
                task, context_dict, messages, observer, agent_name, run_context
            )

        return await self._execute_main_loop(
            task,
            context_dict,
            messages,
            observer,
            agent_name,
            execution_start,
            run_context,
        )

    def _build_messages(
        self,
        task: str,
        context: dict[str, object] | None,
    ) -> list[BaseMessage]:
        """Build minimal message list.

        Args:
            task: The task string.
            context: Optional context dict.

        Returns:
            List of messages for the LLM.
        """
        messages: list[BaseMessage] = []

        # System prompt (if any)
        sys_prompt = self.agent.config.system_prompt
        if sys_prompt:
            messages.append(SystemMessage(content=sys_prompt))

        # Include conversation history from agent state (loaded from thread_id)
        if self.agent.state.message_history:
            messages.extend(self.agent.state.message_history)

        # User message with task
        # Strip internal framework keys so they don't pollute the LLM prompt.
        internal_context_keys = {"run_id", "parent_run_id", "step_id"}
        user_context = (
            {k: v for k, v in context.items() if k not in internal_context_keys}
            if context
            else None
        )
        user_content = f"{task}\n\nContext: {user_context}" if user_context else task

        messages.append(HumanMessage(content=user_content))
        return messages

    def _process_output(
        self,
        raw_content: str,
    ) -> str | StructuredResult:
        """Process raw output through structured output schema if configured.

        Args:
            raw_content: Raw LLM response content.

        Returns:
            If output schema configured: StructuredResult with parsed data.
            Otherwise: The raw content string.
        """
        output_config = getattr(self.agent, "_output_config", None)
        if output_config is None:
            return raw_content

        # Try to validate and parse
        try:
            data = validate_and_parse(raw_content, output_config.schema)
            return StructuredResult(
                data=data,
                raw=raw_content if output_config.include_raw else None,
                valid=True,
                attempts=1,
                method=get_best_method(self.agent.model, output_config),
            )
        except OutputValidationError as e:
            # Return invalid result
            return StructuredResult(
                data=None,
                raw=raw_content,
                valid=False,
                error=str(e),
                attempts=1,
                method=get_best_method(self.agent.model, output_config),
            )
        except Exception as e:
            return StructuredResult(
                data=None,
                raw=raw_content,
                valid=False,
                error=f"Unexpected error: {e}",
                attempts=1,
            )

    async def _execute_with_structured_output(
        self,
        task: str,
        context: dict[str, object] | None,
        messages: list[BaseMessage],
        observer: object | None,
        agent_name: str,
        run_context: RunContext | None = None,
    ) -> str | StructuredResult:
        """Execute with structured output support and intelligent retry.

        On the first attempt, the schema instruction is injected into the task.
        On each subsequent attempt the model sees the full conversation so far
        (including its own previous bad output) plus a corrective human turn
        that quotes the exact validation error.  This mirrors the standard
        self-correction / Reflexion pattern and gives the model real signal to
        fix its mistake rather than blindly re-running the same prompt.

        Non-retryable LLM errors (auth failures, bad requests that are not the
        json-mode 400 fallback) propagate immediately — the inner
        ``ModelResilience`` already handles rate-limits and server errors with
        proper exponential backoff, so the structured-output loop never needs
        to second-guess those.

        Args:
            task: The task to execute.
            context: Optional context dict.
            messages: Initial messages (unused; rebuilt internally).
            observer: Observer for observability.
            agent_name: Agent name for events.
            run_context: Optional RunContext for tools and interceptors.

        Returns:
            StructuredResult if output schema configured, else raw string.
        """
        import time

        output_config: ResponseSchema | None = getattr(
            self.agent, "_output_config", None
        )
        if output_config is None:
            # No structured output - delegate to normal flow
            # This should not be called, but handle gracefully
            return await self._execute_main_loop(
                task,
                context,
                messages,
                observer,
                agent_name,
                time.perf_counter(),
                run_context,
            )

        # Structured output enabled
        max_attempts = (
            output_config.max_retries + 1 if output_config.retry_on_error else 1
        )

        # Use json mode on any model that exposes with_json_mode(). This
        # constrains output to valid JSON at the API level rather than relying
        # solely on prompt injection — critical for reasoning models (e.g.
        # Nemotron, DeepSeek R1) that bleed <think> blocks into content.
        # If the model/provider returns HTTP 400 for the response_format param
        # (not all routed models support it) we transparently fall back to the
        # original bound model and continue with prompt-only extraction.
        original_bound_model = self._bound_model
        _using_json_mode = False
        try:
            try:
                if hasattr(self.agent.model, "with_json_mode"):
                    self._bound_model = self.agent.model.with_json_mode()
                    _using_json_mode = True
                    # Re-bind tools on the json-mode copy if the agent has any.
                    if self.agent.all_tools:
                        self._bound_model = _bind_tools(
                            self._bound_model,
                            self.agent.all_tools,
                            parallel_tool_calls=True,
                        )
            except Exception:
                # If json-mode setup fails for any reason, fall back to the
                # original bound model so execution still proceeds.
                _using_json_mode = False

            # Build messages once with the schema instruction embedded in the
            # initial human turn.  The list is mutated in-place by
            # _execute_main_loop (AI + tool messages are appended), so carrying
            # it across retries gives the model the full conversation history.
            effective_task = build_structured_prompt(task, output_config)
            current_messages = self._build_messages(effective_task, context)

            raw_result: str = ""
            last_error: str | None = None

            # --- Partial list retry state ---
            # When a list[T] validation partially succeeds, we carry forward
            # the valid items and only ask the model to fix the failed ones.
            _list_valid: dict[int, object] | None = None
            _list_failed_indices: list[int] | None = None
            _list_total: int = 0

            for attempt in range(1, max_attempts + 1):
                # Execute main loop — catch 400 "bad request" errors that arise
                # when a provider doesn't support response_format and fall back
                # to plain prompt-injection so we don't retry a doomed request.
                try:
                    raw_result = await self._execute_main_loop(
                        effective_task,
                        context,
                        current_messages,
                        observer,
                        agent_name,
                        time.perf_counter(),
                        run_context,
                    )
                except Exception as llm_err:
                    err_str = str(llm_err)
                    if _using_json_mode and (
                        "400" in err_str or "Bad Request" in err_str
                    ):
                        # Provider rejected response_format — disable json mode
                        # and retry with prompt-only for the remaining attempts.
                        _using_json_mode = False
                        self._bound_model = original_bound_model
                        raw_result = await self._execute_main_loop(
                            effective_task,
                            context,
                            current_messages,
                            observer,
                            agent_name,
                            time.perf_counter(),
                            run_context,
                        )
                    else:
                        # All other LLM errors (auth failures, timeouts after
                        # ModelResilience exhausted its retries, etc.) are
                        # non-retryable at this level — propagate immediately.
                        raise

                # Try to validate
                try:
                    if _list_valid is not None and _list_failed_indices is not None:
                        # We're retrying only the failed items from a list.
                        # The model should return a JSON array of fixes in the
                        # same order as the failed indices we listed.
                        from typing import get_args

                        from cogent.agent.output import parse_json_output

                        item_type = get_args(output_config.schema)[0]
                        try:
                            fixes = parse_json_output(raw_result)
                        except Exception as parse_err:
                            raise OutputValidationError(
                                f"Failed to parse list fix response: {parse_err}",
                                schema=output_config.schema,
                                raw_output=raw_result,
                            ) from parse_err

                        if not isinstance(fixes, list):
                            fixes = [fixes]

                        # Validate each fix and merge into the valid set.
                        still_failed: dict[int, tuple[object, str]] = {}
                        for fix_item, orig_idx in zip(
                            fixes, _list_failed_indices, strict=False
                        ):
                            try:
                                _list_valid[orig_idx] = validate_and_parse(
                                    fix_item, item_type
                                )
                            except (OutputValidationError, Exception) as fix_e:
                                still_failed[orig_idx] = (fix_item, str(fix_e))

                        if not still_failed:
                            # All fixes valid — reassemble the full list.
                            data = [_list_valid[i] for i in range(_list_total)]
                            return StructuredResult(
                                data=data,
                                raw=(raw_result if output_config.include_raw else None),
                                valid=True,
                                attempts=attempt,
                                method=get_best_method(self.agent.model, output_config),
                            )

                        # Some fixes still failed — raise ListItemError to
                        # continue the retry loop with the remaining failures.
                        n_total = len(_list_valid) + len(still_failed)
                        raise ListItemError(
                            f"{len(still_failed)} of {n_total} list items "
                            f"still failed validation",
                            schema=output_config.schema,
                            raw_output=raw_result,
                            valid_items=_list_valid,
                            failed_items=still_failed,
                        )
                    else:
                        data = validate_and_parse(raw_result, output_config.schema)
                    return StructuredResult(
                        data=data,
                        raw=raw_result if output_config.include_raw else None,
                        valid=True,
                        attempts=attempt,
                        method=get_best_method(self.agent.model, output_config),
                    )
                except OutputValidationError as e:
                    last_error = str(e)

                    # Track partial list results for targeted retry.
                    if isinstance(e, ListItemError):
                        _list_valid = dict(e.valid_items)
                        _list_failed_indices = sorted(e.failed_items.keys())
                        _list_total = len(e.valid_items) + len(e.failed_items)

                    self._emit_observer_event(
                        observer,
                        "agent.error",
                        run_context=run_context,
                        step_id=f"step-{attempt}",
                        agent=agent_name,
                        agent_name=agent_name,
                        error=f"Structured output validation failed (attempt {attempt}/{max_attempts}): {last_error}",
                        error_type="validation",
                    )

                    if attempt >= max_attempts:
                        _resilience = getattr(self.agent, "_resilience", None)

                        # --- Fallback model escalation ---
                        # If a fallback_model is configured, give it one
                        # extra attempt with the full correction history
                        # before applying on_exhaustion.
                        _fallback = (
                            _resilience.config.fallback_model if _resilience else None
                        )
                        if _fallback is not None:
                            from cogent.models import resolve_and_create_model

                            if isinstance(_fallback, str):
                                _fallback = resolve_and_create_model(_fallback)

                            if isinstance(_fallback, BaseChatModel):
                                # Append correction for the last failure so
                                # the fallback model sees it.
                                current_messages.append(
                                    HumanMessage(
                                        content=build_correction_message(
                                            raw_result, last_error
                                        )
                                    )
                                )
                                # Swap to fallback model (with json mode if
                                # supported).
                                if hasattr(_fallback, "with_json_mode"):
                                    self._bound_model = _fallback.with_json_mode()
                                else:
                                    self._bound_model = _fallback
                                if self.agent.all_tools:
                                    self._bound_model = _bind_tools(
                                        self._bound_model,
                                        self.agent.all_tools,
                                        parallel_tool_calls=True,
                                    )

                                self._emit_observer_event(
                                    observer,
                                    "agent.error",
                                    run_context=run_context,
                                    step_id="step-fallback",
                                    agent=agent_name,
                                    agent_name=agent_name,
                                    error=f"Escalating to fallback model after {attempt} failed attempts",
                                    error_type="fallback_escalation",
                                )

                                try:
                                    raw_result = await self._execute_main_loop(
                                        effective_task,
                                        context,
                                        current_messages,
                                        observer,
                                        agent_name,
                                        time.perf_counter(),
                                        run_context,
                                    )
                                    data = validate_and_parse(
                                        raw_result, output_config.schema
                                    )
                                    return StructuredResult(
                                        data=data,
                                        raw=(
                                            raw_result
                                            if output_config.include_raw
                                            else None
                                        ),
                                        valid=True,
                                        attempts=attempt + 1,
                                        method=get_best_method(
                                            self.agent.model, output_config
                                        ),
                                    )
                                except Exception as fallback_err:
                                    last_error = str(fallback_err)
                                    # Fall through to on_exhaustion

                        _on_exhaust = (
                            _resilience.config.on_exhaustion
                            if _resilience
                            else "return"
                        )
                        if _on_exhaust == "raise":
                            raise OutputValidationError(
                                f"Structured output validation failed after "
                                f"{attempt} attempts: {last_error}",
                                schema=output_config.schema,
                                raw_output=raw_result,
                            ) from e
                        return StructuredResult(
                            data=None,
                            raw=raw_result,
                            valid=False,
                            error=last_error,
                            attempts=attempt,
                            method=get_best_method(self.agent.model, output_config),
                        )

                    # Carry the conversation forward for self-correction.
                    # _execute_main_loop already appended the model's AIMessage
                    # to current_messages (it mutates the list in-place), so we
                    # only need to add the corrective human turn.  The model
                    # will see:
                    #   ... original schema prompt ...
                    #   AI:    <bad output from this attempt>
                    #   Human: ⚠️ error + quote of the bad output
                    #   AI:    <hopefully correct output>
                    if isinstance(e, ListItemError):
                        correction = build_list_correction_message(e)
                    else:
                        correction = build_correction_message(raw_result, last_error)
                    current_messages.append(HumanMessage(content=correction))
        finally:
            self._bound_model = original_bound_model

        # Should not reach here
        _resilience = getattr(self.agent, "_resilience", None)
        _on_exhaust = _resilience.config.on_exhaustion if _resilience else "return"
        if _on_exhaust == "raise":
            raise OutputValidationError(
                "Structured output validation exhausted all retries",
                schema=output_config.schema,
                raw_output="",
            )
        return StructuredResult(data=None, valid=False, error="Max retries exceeded")

    async def _execute_main_loop(
        self,
        task: str,
        context: dict[str, object] | None,
        messages: list[BaseMessage],
        observer: object | None,
        agent_name: str,
        execution_start: float,
        run_context: RunContext | None = None,
    ) -> str:
        """Execute the main agent loop (extracted for reuse with structured output).

        Args:
            task: The task string.
            context: Optional context dict.
            messages: Message list.
            observer: Observer for observability.
            agent_name: Agent name for events.
            execution_start: Start time for duration tracking.
            run_context: Optional RunContext for tools and interceptors.

        Returns:
            Raw response content string.
        """
        import time

        async def emit_event(
            event_type: str,
            data: dict[str, object],
            *,
            step_id: str | None = None,
            tool_call_id: str | None = None,
        ) -> None:
            self._emit_observer_event(
                observer,
                event_type,
                run_context=run_context,
                step_id=step_id,
                tool_call_id=tool_call_id,
                **data,
            )

        total_tool_calls = 0
        model_calls = 0

        # Store messages reference for token aggregation
        self._last_messages = messages

        # Get interceptors from agent
        interceptors: list[Interceptor] = getattr(self.agent, "_interceptors", [])

        # Shared state for interceptors across the execution
        intercept_state: dict[str, object] = {}

        # Current tools (can be modified by ToolGate interceptors)
        current_tools = list(self.agent.all_tools) if self.agent.all_tools else []

        # Current model (can be modified by Failover interceptors)
        current_model = self._bound_model

        # Current system prompt (can be modified by PromptAdapter interceptors)
        current_prompt = self.agent.config.system_prompt

        # Helper to create context for a phase
        def make_ctx(
            phase: Phase,
            **extra: object,
        ) -> InterceptContext:
            return InterceptContext(
                agent=self.agent,
                phase=phase,
                task=task,
                messages=[
                    {
                        "role": getattr(m, "role", "unknown"),
                        "content": getattr(m, "content", ""),
                    }
                    for m in messages
                ],
                state=intercept_state,
                run_context=run_context,
                tools=current_tools,
                model_calls=model_calls,
                tool_calls=total_tool_calls,
                **extra,
            )

        # PRE_RUN interceptors
        if interceptors:
            try:
                result = await run_interceptors(interceptors, make_ctx(Phase.PRE_RUN))
                if not result.proceed:
                    return result.final_response or "Execution stopped by interceptor"
                # Apply tool filtering if modified
                if result.modified_tools is not None:
                    current_tools = result.modified_tools
                # Apply prompt modification if set
                if result.modified_prompt is not None:
                    current_prompt = result.modified_prompt
                    # Rebuild messages with new prompt
                    if messages and isinstance(messages[0], SystemMessage):
                        messages[0] = SystemMessage(content=current_prompt)
                    elif current_prompt:
                        messages.insert(0, SystemMessage(content=current_prompt))
            except StopExecution as e:
                return e.response

        for iteration in range(self.max_iterations):
            step_id = f"step-{iteration + 1}"
            self.agent._set_observability_step(step_id)

            # PRE_THINK interceptors
            if interceptors:
                try:
                    result = await run_interceptors(
                        interceptors, make_ctx(Phase.PRE_THINK)
                    )
                    if not result.proceed:
                        return (
                            result.final_response or "Execution stopped by interceptor"
                        )
                    # Apply message modification if set
                    if result.modified_messages is not None:
                        # Convert dict messages to LangChain messages
                        new_messages: list[BaseMessage] = []
                        for msg in result.modified_messages:
                            role = msg.get("role", "user")
                            content = msg.get("content", "")
                            if role == "system":
                                new_messages.append(SystemMessage(content=content))
                            elif role == "assistant":
                                new_messages.append(AIMessage(content=content))
                            else:  # user or unknown
                                new_messages.append(HumanMessage(content=content))
                        messages = new_messages
                    # Apply tool filtering if modified
                    if result.modified_tools is not None:
                        current_tools = result.modified_tools
                    # Apply model switch if modified
                    if result.modified_model is not None:
                        current_model = result.modified_model
                        if current_tools:
                            current_model = _bind_tools(
                                current_model, current_tools, parallel_tool_calls=True
                            )
                    # Apply prompt modification if set
                    if result.modified_prompt is not None:
                        current_prompt = result.modified_prompt
                        if messages and isinstance(messages[0], SystemMessage):
                            messages[0] = SystemMessage(content=current_prompt)
                except StopExecution as e:
                    return e.response

            # Emit thinking event
            await emit_event(
                "agent.thinking",
                {
                    "agent": agent_name,
                    "agent_name": agent_name,
                    "iteration": iteration + 1,
                },
                step_id=step_id,
            )

            # Emit LLM request event (for deep observability)
            await emit_event(
                "llm.request",
                {
                    "agent_name": agent_name,
                    "model": model_identifier(self.agent.model),
                    "provider": model_provider(self.agent.model),
                    "messages": [
                        {
                            "role": getattr(m, "role", "unknown"),
                            "content": str(getattr(m, "content", ""))[:500],
                        }
                        for m in messages
                    ],
                    "message_count": len(messages),
                    "system_prompt": (current_prompt or "")[:300]
                    if current_prompt
                    else "",
                    "tools_available": [t.name for t in current_tools]
                    if current_tools
                    else [],
                    "prompt": task,
                    "iteration": iteration + 1,
                },
                step_id=step_id,
            )

            loop_start = time.perf_counter()

            # LLM call with resilience
            if self._model_resilience:
                exec_result = await self._model_resilience.execute(
                    self._bound_model.ainvoke, messages
                )
                if not exec_result.success:
                    self._emit_observer_event(
                        observer,
                        "agent.error",
                        run_context=run_context,
                        step_id=step_id,
                        agent=agent_name,
                        agent_name=agent_name,
                        error=str(exec_result.error),
                        error_type=exec_result.error_type,
                        attempts=exec_result.attempts,
                    )
                    raise exec_result.error or RuntimeError(
                        f"LLM call failed after {exec_result.attempts} attempts"
                    )
                response: AIMessage = exec_result.result
            else:
                response: AIMessage = await self._bound_model.ainvoke(messages)

            loop_duration_ms = (time.perf_counter() - loop_start) * 1000
            model_calls += 1
            messages.append(response)

            # Emit LLM response event (for deep observability)
            tool_calls = response.tool_calls or []
            # Defensive: some providers/SDKs may omit tool_call IDs.
            # Azure/OpenAI validators require each tool result to reference a
            # preceding assistant message with tool_calls containing matching IDs.
            for i, tc in enumerate(tool_calls):
                if isinstance(tc, dict) and not tc.get("id"):
                    tc["id"] = f"call_{iteration + 1}_{i}"

            # Extract thinking/reasoning content if available
            thinking_content = getattr(response, "thinking", None)
            thoughts_content = getattr(response, "thoughts", None)

            # Extract token usage including reasoning tokens
            token_data = {}
            if hasattr(response, "metadata") and response.metadata:
                meta = response.metadata
                if hasattr(meta, "tokens") and meta.tokens:
                    token_data = {
                        "prompt": meta.tokens.prompt_tokens,
                        "completion": meta.tokens.completion_tokens,
                        "total": meta.tokens.total_tokens,
                        "reasoning": meta.tokens.reasoning_tokens,
                    }

            if observer:
                llm_response_data = {
                    "agent_name": agent_name,
                    "iteration": iteration + 1,
                    "content": (response.content or "")[:500],
                    "content_length": len(response.content or ""),
                    "tool_calls": [
                        {
                            "name": tc.get("name", "?"),
                            "args": str(tc.get("args", {}))[:100],
                        }
                        for tc in tool_calls[:5]
                    ]
                    if tool_calls
                    else [],
                    "has_tool_calls": bool(tool_calls),
                    "finish_reason": "tool_calls" if tool_calls else "stop",
                    "duration_ms": loop_duration_ms,
                    "tokens": token_data,
                }

                # Add thinking preview if available
                if thinking_content:
                    llm_response_data["thinking_preview"] = thinking_content[:300]
                    llm_response_data["thinking_length"] = len(thinking_content)
                elif thoughts_content:
                    llm_response_data["thinking_preview"] = thoughts_content[:300]
                    llm_response_data["thinking_length"] = len(thoughts_content)

                await emit_event(
                    "llm.response",
                    llm_response_data,
                    step_id=step_id,
                )

                # Emit dedicated thinking event only when content is exposed
                # (e.g. DeepSeek-R1 via OpenRouter). OpenAI o-series reasoning
                # tokens are already reflected in the llm.response token breakdown.
                thinking_content_str = thinking_content or thoughts_content or ""
                if thinking_content_str:
                    reasoning_tokens = token_data.get("reasoning", 0)
                    await emit_event(
                        "llm.thinking",
                        {
                            "agent_name": agent_name,
                            "iteration": iteration + 1,
                            "thinking": thinking_content_str,
                            "thinking_tokens": reasoning_tokens,
                        },
                        step_id=step_id,
                    )

            # Emit tool decision event if tools were selected
            if tool_calls and observer:
                # Separate tools into subagents and regular tools
                tools_selected = [tc.get("name", "?") for tc in tool_calls]
                subagents_selected = []
                regular_tools_selected = []

                if hasattr(self.agent, "_subagent_registry"):
                    for tool_name in tools_selected:
                        if self.agent._subagent_registry.has_subagent(tool_name):
                            subagents_selected.append(tool_name)
                        else:
                            regular_tools_selected.append(tool_name)
                else:
                    regular_tools_selected = tools_selected

                await emit_event(
                    "llm.tool_decision",
                    {
                        "agent_name": agent_name,
                        "iteration": iteration + 1,
                        "tools_selected": tools_selected,
                        "subagents_selected": subagents_selected,
                        "regular_tools_selected": regular_tools_selected,
                        "reasoning": (response.content or "")[:200]
                        if response.content
                        else "",
                    },
                    step_id=step_id,
                )

            # POST_THINK interceptors
            if interceptors:
                try:
                    result = await run_interceptors(
                        interceptors,
                        make_ctx(Phase.POST_THINK, model_response=response),
                    )
                    if not result.proceed:
                        return (
                            result.final_response or "Execution stopped by interceptor"
                        )
                except StopExecution as e:
                    return e.response

            # Check for tool calls (use already extracted tool_calls)
            if not tool_calls:
                duration_ms = (time.perf_counter() - execution_start) * 1000
                final_output = response.content or ""

                # POST_RUN interceptors
                if interceptors:
                    with contextlib.suppress(StopExecution):
                        await run_interceptors(interceptors, make_ctx(Phase.POST_RUN))

                self._emit_observer_event(
                    observer,
                    "output.generated",
                    run_context=run_context,
                    step_id=step_id,
                    agent=agent_name,
                    agent_name=agent_name,
                    output=final_output,
                    content=final_output,
                    duration_ms=duration_ms,
                )

                # Final response events are emitted by Agent._run_impl with richer metadata
                # (tokens, tool_calls, model, success flags, etc.). The executor only emits
                # output.generated here so result payloads are available without duplicating
                # agent.responded.

                # Sync messages to agent state for token aggregation
                self.agent.state._message_history = messages

                return final_output

            # Generate UUIDs for tool calls (for proper observability tracking)
            import uuid

            tool_call_ids = [str(uuid.uuid4())[:8] for _ in response.tool_calls]

            # Inject UUIDs into dicts so _run_single_tool uses the same ID
            for tc, cid in zip(response.tool_calls, tool_call_ids, strict=False):
                tc["call_id"] = cid

            # Emit tool call events
            for i, tc in enumerate(response.tool_calls):
                tool_name = tc.get("name", "unknown")
                call_id = tool_call_ids[i]

                # Check if this is a subagent
                is_subagent = hasattr(
                    self.agent, "_subagent_registry"
                ) and self.agent._subagent_registry.has_subagent(tool_name)

                event_type = "subagent.called" if is_subagent else "tool.called"
                payload: dict[str, object] = {
                    "agent": agent_name,
                    "agent_name": agent_name,
                    "call_id": call_id,
                    "args": tc.get("args", {}),
                }
                if is_subagent:
                    payload["subagent"] = tool_name
                    payload["subagent_name"] = tool_name
                    task_value = tc.get("args", {}).get("task")
                    if task_value is not None:
                        payload["task"] = task_value
                    # Tag A2A remote subagents so the console can label them.
                    _sa = self.agent._subagent_registry.get_subagent(tool_name)
                    from cogent.agent.a2a import A2AAgent as _A2AAgent  # lazy

                    if isinstance(_sa, _A2AAgent):
                        payload["subagent_type"] = "a2a"
                        payload["subagent_url"] = _sa._url
                    else:
                        payload["subagent_type"] = "local"
                else:
                    payload["tool"] = tool_name
                    payload["tool_name"] = tool_name
                    payload["is_subagent"] = False
                    # Tag MCP-sourced tools so the console can label them.
                    _bt = self._tool_map.get(tool_name)
                    if _bt and getattr(_bt, "source", ""):
                        payload["tool_source"] = _bt.source

                await emit_event(
                    event_type,
                    payload,
                    step_id=step_id,
                    tool_call_id=call_id,
                )

            # Check per-turn tool call limit
            num_calls = len(response.tool_calls)
            if num_calls > self._max_tool_calls_per_turn:
                limit_output = (
                    response.content
                    or f"Tool call limit exceeded: {num_calls} tools in one turn, max {self._max_tool_calls_per_turn} per turn"
                )
                duration_ms = (time.perf_counter() - execution_start) * 1000
                self._emit_observer_event(
                    observer,
                    "output.generated",
                    run_context=run_context,
                    step_id=step_id,
                    agent=agent_name,
                    agent_name=agent_name,
                    output=limit_output,
                    content=limit_output,
                    duration_ms=duration_ms,
                    limited=True,
                )
                return limit_output

            # After a Suspend the LLM gets one final turn to
            # acknowledge, but must not execute additional tools.
            if self._suspended:
                return response.content or "Run suspended — awaiting external result."

            # Execute tools with PRE_ACT/POST_ACT interceptors
            tool_results = await self._execute_tools_with_interceptors(
                response.tool_calls,
                interceptors,
                make_ctx,
                run_context,
            )
            messages.extend(tool_results)
            total_tool_calls += num_calls

            # Emit tool result events (use same UUIDs from tool.called)
            for i, result in enumerate(tool_results):
                tc = response.tool_calls[i] if i < len(response.tool_calls) else {}
                tool_name = tc.get("name", "unknown")
                call_id = tool_call_ids[i] if i < len(tool_call_ids) else ""

                # Check if this is a subagent
                is_subagent = hasattr(
                    self.agent, "_subagent_registry"
                ) and self.agent._subagent_registry.has_subagent(tool_name)

                result_preview = (
                    result.content[:500]
                    if len(result.content) > 500
                    else result.content
                )
                if is_subagent:
                    child_run_id = result.metadata.correlation_id
                    is_error = result.content.startswith(
                        "Error:"
                    ) or result.content.startswith("Subagent error:")
                    event_type = "subagent.error" if is_error else "subagent.result"
                    _sa = self.agent._subagent_registry.get_subagent(tool_name)
                    from cogent.agent.a2a import A2AAgent as _A2AAgent  # lazy

                    _sa_type = "a2a" if isinstance(_sa, _A2AAgent) else "local"
                    payload = {
                        "agent": agent_name,
                        "agent_name": agent_name,
                        "subagent": tool_name,
                        "subagent_name": tool_name,
                        "subagent_type": _sa_type,
                        "call_id": call_id,
                        "subagent_run_id": child_run_id,
                    }
                    if result.metadata.duration is not None:
                        payload["duration_ms"] = result.metadata.duration * 1000
                    if isinstance(_sa, _A2AAgent):
                        payload["subagent_url"] = _sa._url
                    if is_error:
                        payload["error"] = result_preview
                    else:
                        payload["result"] = result_preview
                else:
                    # Skip tool.result when tool.escalated or tool.suspended
                    # was already emitted by _run_single_tool.
                    if result_preview.startswith("Error:"):
                        continue
                    if self._suspended and call_id == self._suspend_tool_call_id:
                        continue
                    event_type = "tool.result"
                    _bt = self._tool_map.get(tool_name)
                    payload = {
                        "agent": agent_name,
                        "agent_name": agent_name,
                        "tool": tool_name,
                        "tool_name": tool_name,
                        "call_id": call_id,
                        "is_subagent": False,
                        "result": result_preview,
                    }
                    if _bt and getattr(_bt, "source", ""):
                        payload["tool_source"] = _bt.source
                    if result.metadata.duration is not None:
                        payload["duration_ms"] = result.metadata.duration * 1000

                await emit_event(
                    event_type,
                    payload,
                    step_id=step_id,
                    tool_call_id=call_id,
                )

        # Max iterations reached - POST_RUN
        if interceptors:
            with contextlib.suppress(StopExecution):
                await run_interceptors(interceptors, make_ctx(Phase.POST_RUN))

        if messages:
            last = messages[-1]
            if isinstance(last, AIMessage):
                return last.content or "Max iterations reached"
        return "Max iterations reached"

    async def _execute_tools_with_interceptors(
        self,
        tool_calls: list[dict[str, object]],
        interceptors: list[Interceptor],
        make_ctx: Callable[..., InterceptContext],
        run_context: RunContext | None = None,
    ) -> list[ToolMessage]:
        """Execute tools with PRE_ACT/POST_ACT interceptor hooks.

        Args:
            tool_calls: List of tool call dicts from LLM.
            interceptors: List of interceptors.
            make_ctx: Context factory function.
            run_context: Optional RunContext to pass to tools.

        Returns:
            List of ToolMessage results.
        """
        import time

        if not interceptors:
            # No interceptors - use fast parallel path
            return await self._execute_tools_parallel(tool_calls, run_context)

        results: list[ToolMessage] = []

        for tc in tool_calls:
            tool_name = tc.get("name", "unknown")
            tool_id = tc.get("id", f"call_{tool_name}")
            tool_args = tc.get("args", {})

            # PRE_ACT
            try:
                pre_result = await run_interceptors(
                    interceptors,
                    make_ctx(
                        Phase.PRE_ACT,
                        tool_name=tool_name,
                        tool_args=tool_args,
                    ),
                )
                if not pre_result.proceed:
                    # Tool blocked by interceptor
                    results.append(
                        ToolMessage(
                            content=pre_result.final_response or "Tool call blocked",
                            tool_call_id=tool_id,
                            metadata=MessageMetadata(
                                correlation_id=run_context.run_id
                                if run_context
                                else None,
                                duration=0.0,
                            ),
                        )
                    )
                    continue
                if pre_result.skip_action:
                    results.append(
                        ToolMessage(
                            content="Tool call skipped",
                            tool_call_id=tool_id,
                            metadata=MessageMetadata(
                                correlation_id=run_context.run_id
                                if run_context
                                else None,
                                duration=0.0,
                            ),
                        )
                    )
                    continue
                # Apply modified args if any
                if pre_result.modified_tool_args:
                    tool_args = pre_result.modified_tool_args
            except StopExecution as e:
                results.append(
                    ToolMessage(
                        content=e.response,
                        tool_call_id=tool_id,
                        metadata=MessageMetadata(
                            correlation_id=run_context.run_id if run_context else None,
                            duration=0.0,
                        ),
                    )
                )
                continue

            # Execute the tool
            start_time = time.time()
            tool = self._tool_map.get(tool_name)
            if tool:
                try:
                    if hasattr(tool, "ainvoke"):
                        result = await tool.ainvoke(tool_args, ctx=run_context)
                    else:
                        result = tool.invoke(tool_args, ctx=run_context)
                    if isinstance(result, ToolResult):
                        result_str = result.content
                        if result.artifact is not None:
                            self._artifacts.append(
                                Artifact(
                                    data=result.artifact,
                                    name=result.name or tool_name,
                                    mime_type=result.mime_type,
                                    tool_name=tool_name,
                                    tool_call_id=str(tool_id) if tool_id else "",
                                )
                            )
                    else:
                        result_str = str(result) if result is not None else ""
                except _Suspend as suspend:
                    resolved = await self._poll_suspend(
                        suspend,
                        run_context=run_context,
                        tool_name=tool_name,
                        tool_id=str(tool_id) if tool_id else "",
                    )
                    if resolved is not None:
                        result_str = resolved
                    else:
                        self._suspended = True
                        self._suspend_callback_id = suspend.callback_id
                        self._suspend_tool_call_id = tool_id
                        result_str = suspend.message
                except Exception as e:
                    result_str = f"Error: {e}"
            else:
                result_str = f"Unknown tool: {tool_name}"
            duration = time.time() - start_time

            # POST_ACT
            with contextlib.suppress(StopExecution):
                await run_interceptors(
                    interceptors,
                    make_ctx(
                        Phase.POST_ACT,
                        tool_name=tool_name,
                        tool_args=tool_args,
                        tool_result=result_str,
                    ),
                )
                # POST_ACT can't stop execution, just observe

            results.append(
                ToolMessage(
                    content=result_str,
                    tool_call_id=tool_id,
                    metadata=MessageMetadata(
                        correlation_id=run_context.run_id if run_context else None,
                        duration=duration,
                    ),
                )
            )

        return results

    async def _execute_reasoning(
        self,
        task: str,
        context: dict[str, object] | None,
        messages: list[BaseMessage],
        observer: object | None,
        agent_name: str,
    ) -> dict[str, object]:
        """Execute reasoning phase before main loop.

        Performs a thinking phase where the agent analyzes the task,
        breaks it down, and plans the approach.

        Args:
            task: The task to reason about.
            context: Optional context dict.
            messages: Current message list (will be modified in-place).
            observer: Observer for observability.
            agent_name: Name of the agent.

        Returns:
            Dict with reasoning results (thinking_steps, plan, etc).
        """
        from cogent.agent.reasoning import (
            REASONING_SYSTEM_PROMPT,
            STYLE_INSTRUCTIONS,
            ReasoningConfig,
            ThinkingStep,
            build_reasoning_prompt,
            estimate_confidence,
            extract_ready,
            extract_thinking,
        )

        config: ReasoningConfig = getattr(self.agent, "_reasoning_config", None)
        if config is None:
            return {}

        # Prepare reasoning results
        thinking_steps: list[ThinkingStep] = []

        # Build reasoning-enhanced system prompt
        style_instructions = STYLE_INSTRUCTIONS.get(config.style, "")
        reasoning_system = f"{REASONING_SYSTEM_PROMPT}".format(
            style_instructions=style_instructions
        )

        # Emit reasoning event (start)
        self._emit_observer_event(
            observer,
            "agent.reasoning",
            run_context=None,
            agent=agent_name,
            agent_name=agent_name,
            phase="start",
            reasoning_type="analysis",
            round=0,
            style=config.style.value,
            thought_preview=f"Beginning {config.style.value} reasoning...",
            **self.agent._lineage_fields(step_id="reasoning-0"),
        )

        # Create reasoning messages
        reasoning_messages: list[BaseMessage] = [
            SystemMessage(content=reasoning_system),
            HumanMessage(content=build_reasoning_prompt(config, task, context)),
        ]

        # Use raw model without tools for reasoning (prevents tool_calls during thinking)
        reasoning_model = self.agent.model

        # Run thinking rounds
        final_thinking = ""
        for round_num in range(1, config.max_thinking_rounds + 1):
            # LLM call for thinking (use raw model, not bound model)
            if self._model_resilience:
                exec_result = await self._model_resilience.execute(
                    reasoning_model.ainvoke, reasoning_messages
                )
                if not exec_result.success:
                    break  # Stop reasoning on error, continue to main loop
                response: AIMessage = exec_result.result
            else:
                response: AIMessage = await reasoning_model.ainvoke(reasoning_messages)

            content = response.content or ""

            # Extract thinking and ready signal from response
            thinking, cleaned = extract_thinking(content)
            is_ready = extract_ready(content)

            if thinking:
                final_thinking = thinking
                confidence = estimate_confidence(thinking)

                step = ThinkingStep(
                    round=round_num,
                    thought=thinking,
                    reasoning_type="analysis" if round_num == 1 else "refinement",
                    confidence=confidence,
                )
                thinking_steps.append(step)

                # Emit reasoning event (step)
                self._emit_observer_event(
                    observer,
                    "agent.reasoning",
                    run_context=None,
                    agent=agent_name,
                    agent_name=agent_name,
                    phase="thinking",
                    reasoning_type=step.reasoning_type,
                    round=round_num,
                    thought_preview=thinking,
                    confidence=confidence,
                    **self.agent._lineage_fields(step_id=f"reasoning-{round_num}"),
                )

                # Check if AI signaled it's ready to proceed
                if is_ready:
                    break

                # Also check confidence threshold if configured
                if (
                    config.require_confidence
                    and confidence >= config.require_confidence
                ):
                    break

                # Add thinking to messages for next round (if doing multiple rounds)
                if round_num < config.max_thinking_rounds:
                    reasoning_messages.append(response)
                    reasoning_messages.append(
                        HumanMessage(
                            content="Good analysis. Can you refine your approach further? "
                            "Consider edge cases or alternative approaches."
                        )
                    )
            else:
                # No <thinking> block found, use content as final plan
                final_thinking = content[:500]
                break

        # Emit reasoning event (complete)
        self._emit_observer_event(
            observer,
            "agent.reasoning",
            run_context=None,
            agent=agent_name,
            agent_name=agent_name,
            phase="complete",
            reasoning_type="reflection",
            round=len(thinking_steps),
            thinking_rounds=len(thinking_steps),
            final_confidence=thinking_steps[-1].confidence if thinking_steps else None,
            thought_preview=f"✓ Reasoning complete ({len(thinking_steps)} rounds)",
            **self.agent._lineage_fields(step_id=f"reasoning-{len(thinking_steps)}"),
        )

        # Inject reasoning context into main messages
        if final_thinking and config.show_thinking:
            # Add thinking as an assistant message so the LLM sees it
            messages.append(
                AIMessage(content=f"<thinking>\n{final_thinking}\n</thinking>")
            )

        return {
            "thinking_steps": thinking_steps,
            "final_thinking": final_thinking,
            "rounds": len(thinking_steps),
        }

    async def _execute_tools_parallel(
        self,
        tool_calls: list[dict[str, object]],
        run_context: RunContext | None = None,
    ) -> list[ToolMessage]:
        """Execute all tool calls in parallel using asyncio.gather with concurrency limiting.

        Args:
            tool_calls: List of tool call dictionaries from the LLM.
            run_context: Optional RunContext to pass to tools.

        Returns:
            List of ToolMessage results in the same order.
        """
        # Semaphore to limit concurrent tool execution
        semaphore = asyncio.Semaphore(self._max_concurrent_tools)

        async def execute_with_limit(tc):
            async with semaphore:
                return await self._run_single_tool(tc, run_context)

        # Execute all tools with concurrency limiting
        results = await asyncio.gather(
            *(execute_with_limit(tc) for tc in tool_calls),
            return_exceptions=True,
        )

        # Convert results to ToolMessages
        messages: list[ToolMessage] = []
        for result, tc in zip(results, tool_calls, strict=False):
            tool_id = tc.get("id", "")

            if isinstance(result, _Suspend):
                # Suspend escaped _run_single_tool (shouldn't happen, but
                # handle defensively so it doesn't become a generic error).
                self._suspended = True
                self._suspend_callback_id = result.callback_id
                messages.append(
                    ToolMessage(
                        content=result.message,
                        tool_call_id=tool_id,
                    )
                )
            elif isinstance(result, Exception):
                messages.append(
                    ToolMessage(
                        content=f"Error: {result}",
                        tool_call_id=tool_id,
                    )
                )
            else:
                messages.append(result)

        return messages

    async def _run_subagent(
        self,
        subagent_name: str,
        args: dict[str, object],
        tool_id: str,
        run_context: RunContext | None = None,
    ) -> ToolMessage:
        """Execute a subagent and preserve Response metadata.

        Args:
            subagent_name: Name of the subagent to execute.
            args: Arguments dict (should contain 'task' key).
            tool_id: Tool call ID for the ToolMessage.
            run_context: Optional RunContext to propagate.

        Returns:
            ToolMessage with the subagent's response content.
        """
        import time

        from cogent.core import ToolCall

        # Extract task from args
        task = args.get("task", "")
        if not task or not isinstance(task, str):
            error_msg = (
                f"Missing or invalid 'task' parameter for subagent {subagent_name}"
            )

            # Track failed subagent call
            if hasattr(self.agent, "state"):
                self.agent.state.tool_calls.append(
                    ToolCall(
                        tool_name=subagent_name,
                        arguments=args,
                        result=None,
                        duration=0.0,
                        success=False,
                        error=error_msg,
                    )
                )

            return ToolMessage(
                content=f"Error: {error_msg}",
                tool_call_id=tool_id,
                metadata=MessageMetadata(
                    correlation_id=run_context.run_id if run_context else None,
                    duration=0.0,
                ),
            )

        start_time = time.time()
        try:
            # Execute subagent via registry (preserves Response object)
            response = await self.agent._subagent_registry.execute(
                subagent_name,
                task,
                context=run_context,
            )

            duration = time.time() - start_time

            # Track successful subagent call in agent state
            if hasattr(self.agent, "state"):
                self.agent.state.tool_calls.append(
                    ToolCall(
                        tool_name=subagent_name,
                        arguments=args,
                        result=response.content,
                        duration=duration,
                        success=response.success,
                        error=response.error.message if response.error else None,
                    )
                )

            # Return content as ToolMessage (LLM sees string, but Response is cached)
            # If subagent had structured output, serialize as JSON so the parent LLM
            # receives clean, parseable data rather than a Python repr string.
            from cogent.agent.output import StructuredResult

            if (
                isinstance(response.content, StructuredResult)
                and response.content.valid
                and response.content.data is not None
            ):
                data = response.content.data
                if hasattr(data, "model_dump_json"):
                    content = data.model_dump_json()
                else:
                    import dataclasses
                    import json

                    content = json.dumps(
                        dataclasses.asdict(data)
                        if dataclasses.is_dataclass(data)
                        else vars(data)
                    )
            else:
                content = str(response.content) if response.content is not None else ""

            # If subagent failed, include error info
            if response.error:
                content = f"Subagent error: {response.error.message}\n\n{content}"

            return ToolMessage(
                content=content,
                tool_call_id=tool_id,
                metadata=MessageMetadata(
                    correlation_id=response.metadata.correlation_id,
                    duration=duration,
                ),
            )

        except Exception as e:
            duration = time.time() - start_time
            error_msg = f"Subagent execution failed: {str(e)}"

            # Track failed subagent call
            if hasattr(self.agent, "state"):
                self.agent.state.tool_calls.append(
                    ToolCall(
                        tool_name=subagent_name,
                        arguments=args,
                        result=None,
                        duration=duration,
                        success=False,
                        error=error_msg,
                    )
                )

            return ToolMessage(
                content=f"Error: {error_msg}",
                tool_call_id=tool_id,
                metadata=MessageMetadata(
                    correlation_id=run_context.run_id if run_context else None,
                    duration=duration,
                ),
            )

    async def _poll_suspend(
        self,
        suspend: _Suspend,
        *,
        run_context: RunContext | None,
        tool_name: str,
        tool_id: str,
    ) -> str | None:
        """Poll a Suspend's ``check`` callback until it resolves or times out.

        Returns:
            The resolved result string, or ``None`` if the timeout expired.
        """
        import inspect
        import time

        check = suspend.check
        if check is None:
            return None
        # timeout=0 (default) means suspend immediately, no polling
        if suspend.timeout is not None and suspend.timeout <= 0:
            return None

        indefinite = suspend.timeout is None
        agent_name = getattr(self.agent, "name", None) or "agent"
        observer = getattr(self.agent, "observer", None)

        self._emit_observer_event(
            observer,
            "tool.waiting",
            run_context=run_context,
            tool_call_id=str(tool_id) if tool_id else None,
            agent=agent_name,
            agent_name=agent_name,
            tool=tool_name,
            tool_name=tool_name,
            call_id=str(tool_id) if tool_id else "",
            callback_id=suspend.callback_id,
            message=suspend.message,
            timeout=suspend.timeout,
            interval=suspend.interval,
        )

        deadline = None if indefinite else time.monotonic() + suspend.timeout
        while True:
            result = check()
            if inspect.isawaitable(result):
                result = await result

            if result is not None:
                return str(result)

            if deadline is not None:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    return None
                await asyncio.sleep(min(suspend.interval, remaining))
            else:
                await asyncio.sleep(suspend.interval)

    async def _run_single_tool(
        self,
        tool_call: dict[str, object],
        run_context: RunContext | None = None,
    ) -> ToolMessage:
        """Execute a single tool call.

        Args:
            tool_call: Tool call dict with name, args, id.
            run_context: Optional RunContext to pass to the tool.

        Returns:
            ToolMessage with the result.
        """
        import time

        from cogent.core import ToolCall

        tool_name = tool_call.get("name", "")
        args = tool_call.get("args", {})
        tool_id = tool_call.get("call_id", tool_call.get("id", ""))

        # Track for metrics (but don't emit events)
        self._track_tool_call(tool_name, args)

        # Check if this is a subagent call
        if hasattr(
            self.agent, "_subagent_registry"
        ) and self.agent._subagent_registry.has_subagent(tool_name):
            return await self._run_subagent(tool_name, args, tool_id, run_context)

        # Get tool from cache
        tool = self._tool_map.get(tool_name)
        if tool is None:
            # Track failed tool call in agent state
            if hasattr(self.agent, "state"):
                self.agent.state.tool_calls.append(
                    ToolCall(
                        tool_name=tool_name,
                        arguments=args,
                        result=None,
                        duration=0.0,
                        success=False,
                        error=f"Unknown tool '{tool_name}'",
                    )
                )

            return ToolMessage(
                content=f"Error: Unknown tool '{tool_name}'",
                tool_call_id=tool_id,
                metadata=MessageMetadata(
                    correlation_id=run_context.run_id if run_context else None,
                    duration=0.0,
                ),
            )

        start_time = time.time()

        # Route through ToolResilience when configured on the agent.
        resilience = getattr(self.agent, "_resilience", None)
        if resilience is not None:
            from cogent.agent.resilience import ToolResilience

            if isinstance(resilience, ToolResilience):
                try:
                    exec_result = await resilience.execute(
                        tool_fn=tool.invoke,
                        tool_name=tool_name,
                        args=args,
                        tool_obj=tool,
                        ctx=run_context,
                        call_id=str(tool_id)
                        if tool_id
                        else None,  # same UUID as tool.called
                        correlation_id=run_context.run_id if run_context else None,
                    )
                except _Suspend as suspend:
                    # Try auto-resolve via polling before suspending
                    resolved = await self._poll_suspend(
                        suspend,
                        run_context=run_context,
                        tool_name=tool_name,
                        tool_id=str(tool_id) if tool_id else "",
                    )
                    if resolved is not None:
                        duration = time.time() - start_time
                        self._track_tool_result(tool_name, resolved, 0)
                        if hasattr(self.agent, "state"):
                            self.agent.state.tool_calls.append(
                                ToolCall(
                                    tool_name=tool_name,
                                    arguments=args,
                                    result=resolved,
                                    duration=duration,
                                    success=True,
                                    error=None,
                                )
                            )
                        return ToolMessage(
                            content=resolved,
                            tool_call_id=tool_id,
                            metadata=MessageMetadata(
                                correlation_id=run_context.run_id
                                if run_context
                                else None,
                                duration=duration,
                            ),
                        )

                    duration = time.time() - start_time
                    self._suspended = True
                    self._suspend_callback_id = suspend.callback_id
                    self._suspend_tool_call_id = str(tool_id) if tool_id else None

                    # Emit tool.suspended event
                    observer = getattr(self.agent, "observer", None)
                    self._emit_observer_event(
                        observer,
                        "tool.suspended",
                        run_context=run_context,
                        tool_call_id=str(tool_id) if tool_id else None,
                        agent=getattr(self.agent, "name", None) or "agent",
                        agent_name=getattr(self.agent, "name", None) or "agent",
                        tool=tool_name,
                        tool_name=tool_name,
                        call_id=str(tool_id) if tool_id else "",
                        callback_id=suspend.callback_id,
                        message=suspend.message,
                        duration_ms=duration * 1000,
                    )

                    if hasattr(self.agent, "state"):
                        self.agent.state.tool_calls.append(
                            ToolCall(
                                tool_name=tool_name,
                                arguments=args,
                                result=suspend.message,
                                duration=duration,
                                success=True,
                                error=None,
                            )
                        )

                    return ToolMessage(
                        content=suspend.message,
                        tool_call_id=tool_id,
                        metadata=MessageMetadata(
                            correlation_id=run_context.run_id if run_context else None,
                            duration=duration,
                        ),
                    )

                duration = time.time() - start_time
                if exec_result.success:
                    result = exec_result.result
                    content, artifact = self._unwrap_tool_result(
                        result, tool_name, str(tool_id) if tool_id else ""
                    )

                    self._track_tool_result(tool_name, result, 0)
                    if hasattr(self.agent, "state"):
                        self.agent.state.emitted_events.extend(exec_result.retry_events)
                        self.agent.state.tool_calls.append(
                            ToolCall(
                                tool_name=tool_name,
                                arguments=args,
                                result=result,
                                duration=duration,
                                success=True,
                                error=None,
                            )
                        )
                    return ToolMessage(
                        content=content,
                        tool_call_id=tool_id,
                        metadata=MessageMetadata(
                            correlation_id=run_context.run_id if run_context else None,
                            duration=duration,
                        ),
                    )
                else:
                    err = exec_result.error or RuntimeError(
                        f"Tool {tool_name!r} failed"
                    )
                    self._track_tool_error(tool_name, str(err))
                    if hasattr(self.agent, "state"):
                        self.agent.state.emitted_events.extend(exec_result.retry_events)
                        self.agent.state.tool_calls.append(
                            ToolCall(
                                tool_name=tool_name,
                                arguments=args,
                                result=None,
                                duration=duration,
                                success=False,
                                error=str(err),
                            )
                        )
                    message_to_agent = f"Error: {err}"
                    observer = getattr(self.agent, "observer", None)
                    self._emit_observer_event(
                        observer,
                        "tool.escalated",
                        run_context=run_context,
                        tool_call_id=str(tool_id) if tool_id else None,
                        agent=getattr(self.agent, "name", None) or "agent",
                        agent_name=getattr(self.agent, "name", None) or "agent",
                        tool=tool_name,
                        tool_name=tool_name,
                        call_id=str(tool_id) if tool_id else "",
                        error=str(err),
                        error_type=type(err).__name__,
                        attempts=exec_result.attempts,
                        message_to_agent=message_to_agent,
                    )
                    return ToolMessage(
                        content=message_to_agent,
                        tool_call_id=tool_id,
                        metadata=MessageMetadata(
                            correlation_id=run_context.run_id if run_context else None,
                            duration=duration,
                        ),
                    )

        try:
            # Direct invocation with context support
            if inspect.iscoroutinefunction(getattr(tool, "func", None)):
                result = await tool.ainvoke(args, ctx=run_context)
            else:
                # Run sync tools in thread pool to not block
                result = await asyncio.to_thread(tool.invoke, args, run_context)

            duration = time.time() - start_time
            self._track_tool_result(tool_name, result, 0)
            content, artifact = self._unwrap_tool_result(
                result, tool_name, str(tool_id) if tool_id else ""
            )

            # Track successful tool call in agent state
            if hasattr(self.agent, "state"):
                self.agent.state.tool_calls.append(
                    ToolCall(
                        tool_name=tool_name,
                        arguments=args,
                        result=result,
                        duration=duration,
                        success=True,
                        error=None,
                    )
                )

            return ToolMessage(
                content=content,
                tool_call_id=tool_id,
                metadata=MessageMetadata(
                    correlation_id=run_context.run_id if run_context else None,
                    duration=duration,
                ),
            )

        except _Suspend as suspend:
            # Try auto-resolve via polling before suspending
            resolved = await self._poll_suspend(
                suspend,
                run_context=run_context,
                tool_name=tool_name,
                tool_id=str(tool_id) if tool_id else "",
            )
            if resolved is not None:
                duration = time.time() - start_time
                self._track_tool_result(tool_name, resolved, 0)
                if hasattr(self.agent, "state"):
                    self.agent.state.tool_calls.append(
                        ToolCall(
                            tool_name=tool_name,
                            arguments=args,
                            result=resolved,
                            duration=duration,
                            success=True,
                            error=None,
                        )
                    )
                return ToolMessage(
                    content=resolved,
                    tool_call_id=tool_id,
                    metadata=MessageMetadata(
                        correlation_id=run_context.run_id if run_context else None,
                        duration=duration,
                    ),
                )

            duration = time.time() - start_time
            self._suspended = True
            self._suspend_callback_id = suspend.callback_id
            self._suspend_tool_call_id = str(tool_id) if tool_id else None

            # Emit tool.suspended event
            observer = getattr(self.agent, "observer", None)
            self._emit_observer_event(
                observer,
                "tool.suspended",
                run_context=run_context,
                tool_call_id=str(tool_id) if tool_id else None,
                agent=getattr(self.agent, "name", None) or "agent",
                agent_name=getattr(self.agent, "name", None) or "agent",
                tool=tool_name,
                tool_name=tool_name,
                call_id=str(tool_id) if tool_id else "",
                callback_id=suspend.callback_id,
                message=suspend.message,
                duration_ms=duration * 1000,
            )

            if hasattr(self.agent, "state"):
                self.agent.state.tool_calls.append(
                    ToolCall(
                        tool_name=tool_name,
                        arguments=args,
                        result=suspend.message,
                        duration=duration,
                        success=True,
                        error=None,
                    )
                )

            return ToolMessage(
                content=suspend.message,
                tool_call_id=tool_id,
                metadata=MessageMetadata(
                    correlation_id=run_context.run_id if run_context else None,
                    duration=duration,
                ),
            )

        except Exception as e:
            duration = time.time() - start_time
            self._track_tool_error(tool_name, str(e))

            # Track failed tool call in agent state
            if hasattr(self.agent, "state"):
                self.agent.state.tool_calls.append(
                    ToolCall(
                        tool_name=tool_name,
                        arguments=args,
                        result=None,
                        duration=duration,
                        success=False,
                        error=str(e),
                    )
                )

            return ToolMessage(
                content=f"Error: {e}",
                tool_call_id=tool_id,
                metadata=MessageMetadata(
                    correlation_id=run_context.run_id if run_context else None,
                    duration=duration,
                ),
            )

    def _unwrap_tool_result(
        self,
        result: object,
        tool_name: str,
        tool_call_id: str,
    ) -> tuple[str, object | None]:
        """Extract content and optional artifact from a tool return value.

        If *result* is a :class:`ToolResult`, its ``content`` becomes the LLM
        message and its ``artifact`` is appended to ``self._artifacts``.
        Otherwise the whole value is stringified as before.

        Returns:
            ``(content_for_llm, artifact_or_none)``
        """
        if isinstance(result, ToolResult):
            if result.artifact is not None:
                self._artifacts.append(
                    Artifact(
                        data=result.artifact,
                        name=result.name or tool_name,
                        mime_type=result.mime_type,
                        tool_name=tool_name,
                        tool_call_id=tool_call_id,
                    )
                )
            return result.content, result.artifact
        return str(result) if result is not None else "", None


class SequentialExecutor(NativeExecutor):
    """
    NativeExecutor with sequential tool execution.

    Like NativeExecutor but executes tools one at a time for
    tasks that require step-by-step reasoning. Also includes
    LLM resilience for automatic retry on rate limits.

    Use when:
    - Tools depend on previous tool results
    - Order of execution matters
    - Debugging tool sequences
    """

    async def execute(
        self,
        task: str,
        context: dict[str, object] | None = None,
    ) -> str:
        """Execute with sequential tool handling.

        Args:
            task: The task to execute.
            context: Optional context.

        Returns:
            Final answer string.
        """
        messages = self._build_messages(task, context)
        total_tool_calls = 0

        for _ in range(self.max_iterations):
            # LLM call with resilience
            if self._model_resilience:
                exec_result = await self._model_resilience.execute(
                    self._bound_model.ainvoke, messages
                )
                if not exec_result.success:
                    raise exec_result.error or RuntimeError("LLM call failed")
                response: AIMessage = exec_result.result
            else:
                response: AIMessage = await self._bound_model.ainvoke(messages)

            messages.append(response)

            if not response.tool_calls:
                return response.content or ""

            # Check per-turn limit
            if len(response.tool_calls) > self._max_tool_calls_per_turn:
                return (
                    response.content
                    or f"Tool call limit exceeded: {len(response.tool_calls)} tools in one turn, max {self._max_tool_calls_per_turn} per turn"
                )

            # Execute tools sequentially
            for tc in response.tool_calls:
                result = await self._run_single_tool(tc)
                messages.append(result)
                total_tool_calls += 1

        if messages:
            last = messages[-1]
            if isinstance(last, AIMessage):
                return last.content or "Max iterations reached"
        return "Max iterations reached"
