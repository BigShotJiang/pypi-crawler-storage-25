"""Community detection and summarization for knowledge graphs.

Provides community detection (partitioning nodes into clusters of densely
connected entities) and LLM-powered community summarization for global
query-focused summarization, following the GraphRAG approach.

Reference:
    - Edge et al. "From Local to Global: A Graph RAG Approach" (arXiv:2404.16130)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cogent.graph.graph import Graph
    from cogent.retriever.utils.llm_adapter import LLMProtocol


COMMUNITY_SUMMARY_PROMPT = """You are given a group of related entities and their relationships from a knowledge graph.

Entities:
{entities}

Relationships:
{relationships}

Write a concise summary (2-4 sentences) that captures the key themes, roles, and connections within this group. Focus on what makes this group coherent and what topics it covers.

Summary:"""


@dataclass
class Community:
    """A cluster of related entities in a knowledge graph.

    Attributes:
        id: Unique community identifier.
        entity_ids: Node IDs belonging to this community.
        level: Hierarchy level (0 = leaf).
        summary: LLM-generated summary of the community.
        metadata: Additional metadata (e.g., density, cohesion).
    """

    id: str
    entity_ids: list[str]
    level: int = 0
    summary: str | None = None
    metadata: dict[str, object] = field(default_factory=dict)

    @property
    def size(self) -> int:
        return len(self.entity_ids)


async def detect_communities(
    graph: Graph,
    *,
    resolution: float = 1.0,
    min_size: int = 1,
) -> list[Community]:
    """Run community detection on a graph and return Community objects.

    Delegates to the engine's community_detection method. Works with
    both NetworkXEngine (Louvain) and NativeEngine (label propagation).

    Args:
        graph: Graph to partition.
        resolution: Higher values produce more, smaller communities
            (only used by Louvain/NetworkXEngine).
        min_size: Minimum community size to include.

    Returns:
        List of Community objects, sorted by size descending.

    Raises:
        TypeError: If the engine doesn't support community detection.
    """
    if not hasattr(graph.engine, "community_detection"):
        raise TypeError(
            f"{type(graph.engine).__name__} does not support "
            "community_detection. Use NetworkXEngine or NativeEngine."
        )

    # Engine returns list[set[str]]
    try:
        raw = graph.engine.community_detection(resolution=resolution)
    except TypeError:
        # NativeEngine doesn't take resolution
        raw = graph.engine.community_detection()

    communities: list[Community] = []
    for i, node_set in enumerate(raw):
        if len(node_set) < min_size:
            continue
        communities.append(
            Community(
                id=f"community_{i}",
                entity_ids=sorted(node_set),
            )
        )

    # Sort by size descending
    communities.sort(key=lambda c: c.size, reverse=True)

    # Re-number IDs after sorting
    for i, c in enumerate(communities):
        c.id = f"community_{i}"

    return communities


async def summarize_communities(
    communities: list[Community],
    graph: Graph,
    llm: LLMProtocol,
    *,
    max_entities_per_summary: int = 30,
) -> list[Community]:
    """Generate LLM summaries for each community.

    Fetches entity details and relationships from the graph, then
    asks the LLM to summarize each community's content.

    Args:
        communities: Communities to summarize (modified in place).
        graph: Graph containing entity details.
        llm: LLM for summary generation.
        max_entities_per_summary: Cap entity count in prompt to control cost.

    Returns:
        The same community list, with summaries populated.
    """
    for community in communities:
        entity_ids = community.entity_ids[:max_entities_per_summary]

        # Gather entity details
        entity_lines: list[str] = []
        for eid in entity_ids:
            entity = await graph.storage.get_entity(eid)
            if entity:
                attrs = ", ".join(
                    f"{k}={v}"
                    for k, v in entity.attributes.items()
                    if k not in ("chunk_ids", "doc_id")
                )
                line = f"- {entity.id} ({entity.entity_type})"
                if attrs:
                    line += f": {attrs}"
                entity_lines.append(line)

        # Gather relationships within community
        rel_lines: list[str] = []
        entity_set = set(entity_ids)
        for eid in entity_ids:
            rels = await graph.storage.get_relationships(eid)
            for rel in rels:
                if rel.source_id in entity_set and rel.target_id in entity_set:
                    line = f"- {rel.source_id} --[{rel.relation}]--> {rel.target_id}"
                    if line not in rel_lines:
                        rel_lines.append(line)

        entities_text = "\n".join(entity_lines) if entity_lines else "(none)"
        rels_text = "\n".join(rel_lines) if rel_lines else "(none)"

        prompt = COMMUNITY_SUMMARY_PROMPT.format(
            entities=entities_text,
            relationships=rels_text,
        )

        try:
            community.summary = await llm.generate(prompt)
        except Exception:
            community.summary = None

    return communities


async def query_communities(
    query: str,
    communities: list[Community],
    llm: LLMProtocol,
    *,
    top_k: int = 5,
) -> list[tuple[Community, str]]:
    """Answer a global query using community summaries (map-reduce).

    For each community with a summary, asks the LLM to generate a partial
    answer. Returns the top-k most relevant (community, partial_answer) pairs.

    This implements the "map" phase of GraphRAG's map-reduce approach.

    Args:
        query: User question.
        communities: Communities with summaries.
        llm: LLM for generating partial answers.
        top_k: Number of communities to include.

    Returns:
        List of (Community, partial_answer) tuples.
    """
    summarized = [c for c in communities if c.summary]
    if not summarized:
        return []

    # Score communities by asking LLM for relevance + partial answer
    prompt_template = (
        "Given this community summary:\n{summary}\n\n"
        "Question: {query}\n\n"
        "If this community is relevant to the question, provide a brief "
        "answer based on the summary. If not relevant, respond with just "
        '"NOT_RELEVANT".\n\nAnswer:'
    )

    results: list[tuple[Community, str]] = []
    for community in summarized[: top_k * 2]:  # check more than we need
        prompt = prompt_template.format(
            summary=community.summary,
            query=query,
        )

        try:
            answer = await llm.generate(prompt)
            answer = answer.strip()
            if answer and answer.upper() != "NOT_RELEVANT":
                results.append((community, answer))
        except Exception:
            continue

        if len(results) >= top_k:
            break

    return results
