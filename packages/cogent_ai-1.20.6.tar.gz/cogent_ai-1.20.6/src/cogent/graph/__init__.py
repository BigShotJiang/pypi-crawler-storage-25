"""Knowledge Graph module for Cogent.

This module provides a clean, modern API for building and querying knowledge graphs.
"""

from cogent.graph import visualization as visualization
from cogent.graph.community import Community as Community
from cogent.graph.community import detect_communities as detect_communities
from cogent.graph.community import query_communities as query_communities
from cogent.graph.community import summarize_communities as summarize_communities
from cogent.graph.engines import Engine as Engine
from cogent.graph.engines import NativeEngine as NativeEngine
from cogent.graph.graph import Graph as Graph
from cogent.graph.models import Entity as Entity
from cogent.graph.models import Relationship as Relationship
from cogent.graph.query import QueryPattern as QueryPattern
from cogent.graph.query import QueryResult as QueryResult
from cogent.graph.query import match as match
from cogent.graph.query import parse_pattern as parse_pattern
from cogent.graph.storage import FileStorage as FileStorage
from cogent.graph.storage import MemoryStorage as MemoryStorage
from cogent.graph.storage import Storage as Storage
from cogent.graph.storage import _has_sqlalchemy

if _has_sqlalchemy:
    from cogent.graph.storage import SQLStorage as SQLStorage

_base_all = [
    "Graph",
    "Entity",
    "Relationship",
    "Community",
    "detect_communities",
    "summarize_communities",
    "query_communities",
    "Engine",
    "NativeEngine",
    "Storage",
    "MemoryStorage",
    "FileStorage",
    "QueryPattern",
    "QueryResult",
    "parse_pattern",
    "match",
    "visualization",
]

if _has_sqlalchemy:
    _base_all.append("SQLStorage")

# Conditionally import NetworkXEngine
try:
    from cogent.graph.engines import NetworkXEngine

    __all__ = [*_base_all, "NetworkXEngine"]
except ImportError:
    __all__ = _base_all
