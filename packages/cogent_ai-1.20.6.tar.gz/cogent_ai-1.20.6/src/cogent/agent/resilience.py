"""
Resilience - retry and intelligent recovery for agents.

Two tiers:

1. **Systematic retry** (``RetryPolicy``):
   Developer-controlled.  Configure max attempts, backoff strategy, delays,
   and which exceptions are retryable.  The framework executes the policy
   mechanically without any built-in opinions about what is right.

2. **Intelligent retry** (``on_exhaustion="return"``):
   When systematic retries are exhausted, error context (tool name, args,
   error message) is returned to the agent loop so the LLM can decide what
   to do next - reformulate the call, pick a different tool, or give up and
   explain why.  The intelligence lives in the model, not in hardcoded
   heuristics.

``ResilienceConfig`` is the single configuration entry point::

    config = ResilienceConfig(
        max_retries=3,
        strategy="exponential_jitter",
    )

``ModelResilience`` wraps LLM calls with the same systematic retry, handling
rate-limit and server-error patterns that are retryable at the API level.
"""

from __future__ import annotations

import asyncio
import inspect
import random
import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING, Any, Literal

if TYPE_CHECKING:
    from cogent.observability.observer import Observer
    from cogent.observability.progress import ProgressTracker


# ---------------------------------------------------------------------------
# Retry strategy
# ---------------------------------------------------------------------------


class RetryStrategy(StrEnum):
    """Backoff strategies for systematic retry."""

    NONE = "none"
    FIXED = "fixed"
    LINEAR = "linear"
    EXPONENTIAL = "exponential"
    EXPONENTIAL_JITTER = "exponential_jitter"


@dataclass
class RetryPolicy:
    """
    Developer-controlled retry policy.

    Attributes:
        max_retries: Maximum number of retry attempts after the first failure.
            0 means no retry.
        strategy: Delay backoff strategy.
        base_delay: Base delay in seconds.
        max_delay: Maximum delay cap in seconds.
        jitter_factor: Random jitter factor (0.0-1.0), active for
            EXPONENTIAL_JITTER only.
        retryable_exceptions: Exception types that always trigger a retry.
        non_retryable_exceptions: Exception types that never trigger a retry
            (takes precedence over retryable_exceptions).

    Example::

        policy = RetryPolicy(
            max_retries=3,
            strategy=RetryStrategy.EXPONENTIAL_JITTER,
            base_delay=1.0,
            max_delay=30.0,
        )

        policy = RetryPolicy.no_retry()
    """

    max_retries: int = 3
    strategy: RetryStrategy = RetryStrategy.EXPONENTIAL_JITTER
    base_delay: float = 1.0
    max_delay: float = 60.0
    jitter_factor: float = 0.25
    retryable_exceptions: tuple[type[Exception], ...] = (
        TimeoutError,
        ConnectionError,
        OSError,
    )
    non_retryable_exceptions: tuple[type[Exception], ...] = (
        ValueError,
        TypeError,
        PermissionError,
        KeyError,
    )
    retryable_patterns: tuple[str, ...] = (
        "rate limit",
        "rate_limit",
        "ratelimit",
        "too many requests",
        "429",
        "resource exhausted",
        "resourceexhausted",
        "quota exceeded",
        "quota_exceeded",
        "temporarily unavailable",
        "service unavailable",
        "503",
        "502",
        "500",
        "server error",
        "overloaded",
        "capacity",
        "try again",
        "retry",
    )

    def get_delay(self, attempt: int) -> float:
        """Return delay in seconds before the next retry.

        Args:
            attempt: 1-based attempt number that just failed.
        """
        if self.strategy == RetryStrategy.NONE:
            return 0.0
        if self.strategy == RetryStrategy.FIXED:
            delay = self.base_delay
        elif self.strategy == RetryStrategy.LINEAR:
            delay = self.base_delay * attempt
        elif self.strategy in (
            RetryStrategy.EXPONENTIAL,
            RetryStrategy.EXPONENTIAL_JITTER,
        ):
            delay = self.base_delay * (2 ** (attempt - 1))
        else:
            delay = self.base_delay
        delay = min(delay, self.max_delay)
        if self.strategy == RetryStrategy.EXPONENTIAL_JITTER:
            delay += delay * self.jitter_factor * random.random()
        return delay

    def should_retry(self, exception: Exception, attempt: int) -> bool:
        """Return whether exception should trigger another retry.

        Args:
            exception: The exception raised on this attempt.
            attempt: 1-based attempt number that just failed.
        """
        if attempt > self.max_retries:
            return False
        if self.strategy == RetryStrategy.NONE:
            return False
        if isinstance(exception, self.non_retryable_exceptions):
            return False
        if isinstance(exception, self.retryable_exceptions):
            return True
        error_msg = str(exception).lower()
        error_type = type(exception).__name__.lower()
        if any(p in error_msg or p in error_type for p in self.retryable_patterns):
            return True
        if isinstance(exception, (RuntimeError, Exception)):
            non_retryable_patterns = [
                "not found",
                "unauthorized",
                "forbidden",
                "invalid argument",
                "invalid_argument",
                "not supported",
                "not implemented",
                "authentication",
                "permission denied",
                "incorrect api key",
                "invalid api key",
                "invalid api_key",
                "api key",
                "api_key",
                "auth token",
                "auth_token",
                "401",
            ]
            return not any(p in error_msg for p in non_retryable_patterns)
        return False

    @classmethod
    def no_retry(cls) -> RetryPolicy:
        """Policy with no retry (fail immediately)."""
        return cls(max_retries=0, strategy=RetryStrategy.NONE)

    @classmethod
    def default(cls) -> RetryPolicy:
        """Default policy: three retries with exponential jitter."""
        return cls()


# ---------------------------------------------------------------------------
# Resilience configuration
# ---------------------------------------------------------------------------


@dataclass
class ResilienceConfig:
    """
    Resilience configuration for an agent.

    Attributes:
        max_retries: Maximum number of retries after the first failure.
            0 means no retry.
        strategy: Backoff strategy. Accepts a string (e.g.
            ``"exponential_jitter"``) or a ``RetryStrategy`` value.
        base_delay: Base delay in seconds between retries.
        max_delay: Maximum delay cap in seconds.
        jitter_factor: Random jitter factor (0.0–1.0), active for
            ``"exponential_jitter"`` only.
        on_exhaustion: What to do when retries are exhausted (applies to
            both tool calls and structured output validation).
            ``"return"`` returns gracefully with error info — the caller
            inspects ``Response.error`` or ``StructuredResult.valid``.
            ``"raise"`` propagates the exception to the caller.
            The deprecated value ``"ask_agent"`` is treated as ``"return"``.
        fallback_model: Optional model to escalate to when the primary model
            exhausts structured-output retries.  Accepts a model string
            (e.g. ``"gpt4"``) or a ``BaseChatModel`` instance.  When set,
            the fallback gets one extra attempt with the full correction
            history before ``on_exhaustion`` is applied.
        timeout_seconds: Per-tool-call timeout in seconds.  None disables it.
        tool_overrides: Per-tool overrides keyed by tool name.  Each value is
            a flat dict with any subset of the fields above, e.g.
            ``{"payment_api": {"max_retries": 0}}``.

    Example::

        ResilienceConfig(max_retries=3, strategy="exponential_jitter")

        ResilienceConfig(max_retries=0, on_exhaustion="raise")

        ResilienceConfig(
            max_retries=3,
            strategy="fixed",
            base_delay=0.5,
            tool_overrides={"payment_api": {"max_retries": 0}},
        )
    """

    max_retries: int = 3
    strategy: RetryStrategy | str = RetryStrategy.EXPONENTIAL_JITTER
    base_delay: float = 1.0
    max_delay: float = 60.0
    jitter_factor: float = 0.25
    on_exhaustion: Literal["raise", "return"] = "return"
    fallback_model: Any = None
    timeout_seconds: float | None = 60.0
    tool_overrides: dict[str, dict[str, Any]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if isinstance(self.strategy, str):
            self.strategy = RetryStrategy(self.strategy)
        if self.on_exhaustion == "ask_agent":  # type: ignore[comparison-overlap]
            import warnings

            warnings.warn(
                'on_exhaustion="ask_agent" is deprecated, use "return" instead',
                DeprecationWarning,
                stacklevel=2,
            )
            object.__setattr__(self, "on_exhaustion", "return")

    def get_retry_policy(self, tool_name: str) -> RetryPolicy:
        """Return the effective retry policy for tool_name."""
        override = self.tool_overrides.get(tool_name, {})
        raw_strategy = override.get("strategy", self.strategy)
        return RetryPolicy(
            max_retries=override.get("max_retries", self.max_retries),
            strategy=RetryStrategy(raw_strategy),
            base_delay=override.get("base_delay", self.base_delay),
            max_delay=override.get("max_delay", self.max_delay),
            jitter_factor=override.get("jitter_factor", self.jitter_factor),
        )

    def get_timeout(self, tool_name: str) -> float | None:
        """Return the effective timeout for tool_name."""
        override = self.tool_overrides.get(tool_name, {})
        return override.get("timeout_seconds", self.timeout_seconds)


# ---------------------------------------------------------------------------
# Execution result
# ---------------------------------------------------------------------------


@dataclass
class ExecutionResult:
    """Result of a resilient tool execution."""

    success: bool
    result: object | None = None
    error: Exception | None = None
    tool_used: str = ""
    attempts: int = 1
    total_time_ms: float = 0.0
    # Populated when all retries are exhausted and on_exhaustion="return".
    agent_context: dict[str, Any] | None = None
    # Events emitted during retry attempts (tool.error), for result.events.
    retry_events: list[Any] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Tool resilience layer
# ---------------------------------------------------------------------------


class ToolResilience:
    """
    Wraps a single tool call with systematic retry and optional intelligent
    recovery.

    Create one instance per ResilienceConfig and reuse across calls.
    """

    def __init__(
        self,
        config: ResilienceConfig | None = None,
        tracker: ProgressTracker | None = None,
        observer: Observer | None = None,
        agent_name: str = "",
    ) -> None:
        self.config = config or ResilienceConfig()
        self.tracker = tracker
        self.observer = observer
        self.agent_name = agent_name

    def _emit_retry(
        self,
        tool: str,
        attempt: int,
        max_retries: int,
        delay: float,
        error: Exception | None = None,
        call_id: str | None = None,
        correlation_id: str | None = None,
    ) -> object | None:
        if self.tracker:
            self.tracker.update(
                f"Retry {attempt}/{max_retries} for {tool} in {delay:.1f}s"
            )
        if self.observer is not None:
            return self.observer.emit(
                "tool.retry",
                correlation_id=correlation_id,
                tool=tool,
                tool_name=tool,
                agent_name=self.agent_name,
                call_id=call_id or "",
                error=str(error) if error else "unknown error",
                error_type=type(error).__name__ if error else "Exception",
                attempt=attempt,
                max_retries=max_retries,
                retry_delay=delay,
            )
        return None

    async def execute(
        self,
        tool_fn: Callable[..., Any],
        tool_name: str,
        args: dict[str, Any],
        tool_obj: Any | None = None,
        ctx: Any | None = None,
        call_id: str | None = None,
        correlation_id: str | None = None,
    ) -> ExecutionResult:
        """Execute tool_fn with retry according to self.config.

        Args:
            tool_fn: The tool invoke callable.
            tool_name: Tool name for logging and error context.
            args: Arguments passed to the tool.
            tool_obj: Optional tool object; ainvoke is preferred when present.
            correlation_id: Run ID for grouping events in the observer.

        Returns:
            ExecutionResult - always returns, never raises.
        """
        start = time.time()
        result = ExecutionResult(success=False, tool_used=tool_name)
        retry_policy = self.config.get_retry_policy(tool_name)
        timeout = self.config.get_timeout(tool_name)
        last_error: Exception | None = None

        for attempt in range(retry_policy.max_retries + 1):
            result.attempts = attempt + 1
            try:
                coro = self._invoke(tool_fn, args, tool_obj, ctx)
                if timeout is not None:
                    raw = await asyncio.wait_for(coro, timeout=timeout)
                else:
                    raw = await coro
                result.success = True
                result.result = raw
                result.total_time_ms = (time.time() - start) * 1000
                return result
            except TimeoutError:
                last_error = TimeoutError(
                    f"Tool {tool_name!r} timed out after {timeout}s"
                )
            except Exception as exc:
                # Suspend is a control-flow signal, not a retryable error
                from cogent.tools.suspend import Suspend

                if isinstance(exc, Suspend):
                    raise
                last_error = exc

            if (
                last_error
                and attempt == 0
                and retry_policy.max_retries > 0
                and self.observer is not None
            ):
                # Emit the initial failure before any retry events so the
                # observer can show it as the first branch line.
                self.observer.emit(
                    "tool.failed",
                    correlation_id=correlation_id,
                    tool=tool_name,
                    tool_name=tool_name,
                    agent_name=self.agent_name,
                    call_id=call_id or "",
                    error=str(last_error),
                    error_type=type(last_error).__name__,
                )

            if last_error and retry_policy.should_retry(last_error, attempt + 1):
                delay = retry_policy.get_delay(attempt + 1)
                evt = self._emit_retry(
                    tool_name,
                    attempt + 1,
                    retry_policy.max_retries,
                    delay,
                    last_error,
                    call_id,
                    correlation_id,
                )
                if evt is not None:
                    result.retry_events.append(evt)
                await asyncio.sleep(delay)
            else:
                break

        result.error = last_error
        result.total_time_ms = (time.time() - start) * 1000

        # Always populate agent_context so the agent loop can attempt
        # recovery regardless of on_exhaustion setting.
        result.agent_context = {
            "tool": tool_name,
            "args": args,
            "error": str(last_error),
            "error_type": type(last_error).__name__ if last_error else "Unknown",
            "attempts": result.attempts,
        }

        return result

    @staticmethod
    async def _invoke(
        tool_fn: Callable[..., Any],
        args: dict[str, Any],
        tool_obj: object | None,
        ctx: Any | None = None,
    ) -> Any:
        if tool_obj is not None and hasattr(tool_obj, "ainvoke"):
            return await tool_obj.ainvoke(args, ctx=ctx)
        if inspect.iscoroutinefunction(tool_fn):
            return await tool_fn(args)
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: tool_fn(args))


# ---------------------------------------------------------------------------
# Model resilience (LLM-level retry)
# ---------------------------------------------------------------------------


@dataclass
class ModelExecutionResult:
    """Result of a resilient LLM call."""

    success: bool
    result: object | None = None
    error: Exception | None = None
    attempts: int = 1
    total_time_ms: float = 0.0
    error_type: str | None = None


class ModelResilience:
    """
    Retry wrapper for LLM API calls.

    Handles transient API errors (rate limits, server errors, timeouts) using
    the same RetryPolicy mechanism as tool execution.

    Example::

        resilience = ModelResilience(
            retry_policy=RetryPolicy(max_retries=5, base_delay=2.0),
        )
        result = await resilience.execute(model.ainvoke, messages)
        if result.success:
            response = result.result
        else:
            raise result.error
    """

    def __init__(
        self,
        retry_policy: RetryPolicy | None = None,
        timeout_seconds: float = 120.0,
        on_retry: Callable[[int, Exception, float], None] | None = None,
        on_error: Callable[[Exception, int], None] | None = None,
        on_success: Callable[[int], None] | None = None,
        tracker: ProgressTracker | None = None,
    ) -> None:
        self.retry_policy = retry_policy or RetryPolicy.default()
        self.timeout = timeout_seconds
        self.on_retry = on_retry
        self.on_error = on_error
        self.on_success = on_success
        self.tracker = tracker
        self._total_calls = 0
        self._total_retries = 0
        self._total_failures = 0

    def _classify_error(self, error: Exception) -> str:
        s = str(error).lower()
        n = type(error).__name__.lower()
        if any(p in s or p in n for p in ["rate", "429", "resourceexhausted", "quota"]):
            return "rate_limit"
        if any(p in s for p in ["timeout", "timed out"]):
            return "timeout"
        if any(p in s for p in ["connection", "network"]):
            return "connection"
        if any(p in s for p in ["500", "502", "503", "server error", "unavailable"]):
            return "server_error"
        if any(p in s for p in ["invalid", "malformed"]):
            return "invalid_request"
        return "api_error"

    async def execute(
        self,
        model_fn: Callable[..., Any],
        *args: Any,
        **kwargs: Any,
    ) -> ModelExecutionResult:
        """Execute model_fn with retry.

        Args:
            model_fn: The model callable (e.g. model.ainvoke).
            *args: Forwarded positional arguments.
            **kwargs: Forwarded keyword arguments.
        """
        self._total_calls += 1
        start = time.time()
        result = ModelExecutionResult(success=False)
        last_error: Exception | None = None

        for attempt in range(self.retry_policy.max_retries + 1):
            result.attempts = attempt + 1
            try:
                raw = await asyncio.wait_for(
                    model_fn(*args, **kwargs), timeout=self.timeout
                )
                result.success = True
                result.result = raw
                result.total_time_ms = (time.time() - start) * 1000
                if self.on_success:
                    self.on_success(attempt + 1)
                if attempt > 0 and self.tracker:
                    self.tracker.update(f"LLM succeeded after {attempt + 1} attempts")
                return result
            except TimeoutError:
                last_error = TimeoutError(f"LLM call timed out after {self.timeout}s")
            except Exception as exc:
                last_error = exc

            error_type = self._classify_error(last_error)
            result.error_type = error_type

            if last_error and self.retry_policy.should_retry(last_error, attempt + 1):
                delay = self.retry_policy.get_delay(attempt + 1)
                self._total_retries += 1
                if self.on_retry:
                    self.on_retry(attempt + 1, last_error, delay)
                if self.tracker:
                    self.tracker.update(
                        f"LLM retry {attempt + 1}/{self.retry_policy.max_retries}"
                        f" ({error_type}) - waiting {delay:.1f}s"
                    )
                await asyncio.sleep(delay)
            else:
                break

        result.error = last_error
        result.total_time_ms = (time.time() - start) * 1000
        self._total_failures += 1
        if self.on_error:
            self.on_error(last_error, result.attempts)
        if self.tracker:
            self.tracker.update(
                f"LLM failed after {result.attempts} attempts ({result.error_type})"
            )
        return result

    @property
    def stats(self) -> dict[str, int]:
        """Cumulative call / retry / failure counts."""
        return {
            "total_calls": self._total_calls,
            "total_retries": self._total_retries,
            "total_failures": self._total_failures,
        }

    def reset_stats(self) -> None:
        """Reset statistics."""
        self._total_calls = 0
        self._total_retries = 0
        self._total_failures = 0
