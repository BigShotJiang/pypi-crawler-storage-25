"""Episodic memory backed by a knowledge graph.

Gives agents structured memory across turns and sessions.  An *episode*
captures a sequence of observations (user messages, tool results,
reflections) as graph entities linked by temporal edges.  An LLM-driven
extraction step builds a **semantic layer** of entities and relationships
from each turn, enabling graph-based retrieval that returns structured
facts rather than raw conversation transcripts.

Inspired by AriGraph (arXiv:2407.04363) and Graphiti/Zep.

Architecture::

    Episodic layer            Semantic layer
    ──────────────            ──────────────
    Episode ──FOLLOWED_BY──▶ Episode
      │                        │
      └─ OBSERVED_IN ◀── Observation ──MENTIONS──▶ Entity
                            │  NEXT  │               │
                            ▼        ▼          RELATES_TO
                          Obs_2    Obs_3              │
                                                   Entity

After each turn the LLM extracts entities and relationships from the
conversation.  Entities are deduplicated by normalized name.
Relationships become ``RELATES_TO`` edges with a ``label`` attribute.
Observations link to the entities they mention via ``MENTIONS`` edges.

Recall extracts query entities, resolves them in the graph, and uses
BFS + PPR to find connected facts — returning structured knowledge
rather than dumping raw conversation history.

Typical usage::

    from cogent.graph import Graph
    from cogent.memory.episodic import EpisodicMemory

    graph = Graph()
    episodic = EpisodicMemory(graph, model=my_model)

    ep = await episodic.start_episode(agent="assistant", thread_id="t-1")
    obs = await episodic.record_turn(
        ep.id, "Tell me about Rome", "Rome is the capital of Italy..."
    )
    # Entities like "Rome", "Italy" are auto-extracted and linked

    # Later — recall returns structured facts, not raw messages
    facts = await episodic.recall("Italian cities")
"""

from __future__ import annotations

import asyncio
import contextlib
import json
import logging
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from cogent.graph.graph import Graph

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass(slots=True)
class Episode:
    """A bounded sequence of observations forming one coherent interaction.

    Attributes:
        id: Unique episode identifier.
        agent: Name of the agent that owns this episode.
        thread_id: Conversation thread this episode belongs to.
        user_id: Identifier for the user this episode belongs to. When set,
            recall and list operations can filter by user to enforce privacy
            boundaries in multi-user deployments.
        started_at: When the episode began.
        closed_at: When the episode ended (``None`` while open).
        outcome: Free-text result label set on close (e.g. "success", "error").
        metadata: Arbitrary key-value data.
    """

    id: str
    agent: str
    thread_id: str | None = None
    user_id: str | None = None
    started_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    closed_at: datetime | None = None
    outcome: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    @property
    def is_open(self) -> bool:
        return self.closed_at is None


@dataclass(slots=True)
class Observation:
    """A single event recorded inside an episode.

    Attributes:
        id: Unique observation identifier.
        episode_id: Parent episode.
        content: Free-text content (user message, tool output, reflection …).
        kind: Category tag — ``"user"``, ``"assistant"``, ``"tool"``, ``"reflection"``.
        timestamp: When the observation was recorded.
        metadata: Arbitrary key-value data.
    """

    id: str
    episode_id: str
    content: str
    kind: str = "observation"
    timestamp: datetime = field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class RecalledFact:
    """A structured fact retrieved from the semantic graph during recall.

    Attributes:
        subject: Source entity name.
        relation: Relationship label.
        object: Target entity name.
        source_episode: Episode ID where this fact was first observed.
        timestamp: When the fact was recorded.
        importance: Importance weight (1-5).  5 = permanent/safety-critical,
            1 = ephemeral.
    """

    subject: str
    relation: str
    object: str
    source_episode: str | None = None
    timestamp: datetime | None = None
    importance: int = 2


# ---------------------------------------------------------------------------
# Constants — entity types and relation labels used inside the graph
# ---------------------------------------------------------------------------

_EPISODE_TYPE = "Episode"
_OBSERVATION_TYPE = "Observation"
_SEMANTIC_TYPE = "SemanticEntity"  # Extracted entities (people, concepts, etc.)

_NEXT_OBS = "NEXT"  # Temporal link between successive observations
_OBSERVED_IN = "OBSERVED_IN"  # Observation → Episode
_MENTIONS = "MENTIONS"  # Observation → semantic entity
_FOLLOWED_BY = "FOLLOWED_BY"  # Episode → Episode (within a thread)
_RELATES_TO = "RELATES_TO"  # Semantic entity → semantic entity (with label)

# Canonical relation types — extraction outputs one of these, specific
# nuance goes into the ``label`` attribute on the edge.
CANONICAL_RELATIONS: frozenset[str] = frozenset(
    {
        "prefers",
        "avoids",
        "constrained_by",
        "was_advised",
        "tried",
        "succeeded_at",
        "failed_at",
        "plans_to",
        "interested_in",
        "includes",
        "related_to",
    }
)

# Minimum token-overlap ratio for two entity names to be considered the
# same entity during fuzzy dedup.  0.0 disables merging.
_MERGE_THRESHOLD: float = 0.5


# ---------------------------------------------------------------------------
# LLM prompts
# ---------------------------------------------------------------------------

_EXTRACT_PROMPT = """\
You are building an episodic memory graph for a personal assistant.
Extract ONLY information worth remembering about this specific user
and this specific interaction.  Do NOT extract general world knowledge
the model already knows.

User: {user_message}
Assistant: {assistant_message}
{existing_graph}
Return a JSON object with:
- "entities": list of {{"name": "...", "type": "Topic|Preference|Goal|Person|Place|Organization|Event"}}
- "relationships": list of {{"source": "...", "relation": "...", "target": "...", "importance": N, "label": "..."}}

Entity names MUST be 1-4 words.  Use short noun phrases, not sentences.
- Good: "Nut allergy", "$50/week budget", "One-pan meals"
- Bad:  "Cheap beginner meals avoiding nuts and spices" (too long)

REUSE existing entity names from the graph above when they match what this
turn discusses.  Only create a new entity when the concept is genuinely new.
Connect new facts to EXISTING entities rather than creating parallel subgraphs.

RELATION and DIRECTION — read each triple as "source RELATION target":
  prefers        — WHO/WHAT prefers CHOICE
                   "Beginner cooking" prefers "Non-spicy meals"
  avoids         — WHO/WHAT avoids THING_AVOIDED
                   "Beginner cooking" avoids "Spicy food"
  constrained_by — ACTIVITY constrained_by LIMIT
                   "Meal planning" constrained_by "$50/week budget"
                   "Meal planning" constrained_by "Nut allergy"
  was_advised    — CONTEXT was_advised ADVICE
                   "One-pan meals" was_advised "Garlic-butter pasta"
  tried          — PERSON/CONTEXT tried THING
                   "Pasta making" tried "Garlic-butter recipe"
  succeeded_at   — PERSON/CONTEXT succeeded_at THING
                   "Pasta making" succeeded_at "First pasta dish"
  failed_at      — PERSON/CONTEXT failed_at THING
  plans_to       — PERSON/CONTEXT plans_to GOAL
                   "Cooking journey" plans_to "Cook more at home"
  interested_in  — TOPIC interested_in SUBTOPIC
  includes       — WHOLE includes PART
                   "One-pan meals" includes "Egg fried rice"
  related_to     — catch-all when nothing else fits

ANTI-HUB RULE: No single entity should appear in more than 3 relationships
per turn.  If you find yourself connecting everything to one node, create
more specific intermediate entities instead.
- Bad:  "Home cooking" → 8 different targets (star topology)
- Good: "Meal planning" constrained_by "$50/week budget",
        "Meal planning" constrained_by "Nut allergy",
        "One-pan meals" includes "Garlic-butter pasta",
        "Cooking journey" succeeded_at "First pasta dish"

LABEL is a short (2-4 word) descriptive phrase that adds specificity beyond
the canonical relation.  Examples:
- relation="constrained_by", label="tight weekly budget"
- relation="was_advised", label="easy one-pan pasta"
- relation="avoids", label="hates spicy food"

IMPORTANCE is 1-5:
  5 = permanent safety/health fact (allergy, medical condition)
  4 = durable preference or hard constraint (budget, diet, equipment)
  3 = specific advice given or goal stated
  2 = topic explored or question asked
  1 = ephemeral detail (tried something once, minor observation)

Do NOT create a "User" node. The graph already belongs to the user.
Keep it concise — typically 2-5 triples per turn.

JSON:"""

_EXTRACT_QUERY_PROMPT = """\
Given a user query and a list of known entities from their memory graph,
return the entities most relevant to answering the query.

Query: {query}

Known entities:
{entity_list}

Return a JSON array of entity names from the list above.
Only include entities that are relevant. Return [] if none match.

JSON:"""


# ---------------------------------------------------------------------------
# EpisodicMemory
# ---------------------------------------------------------------------------


class EpisodicMemory:
    """Graph-backed episodic memory with LLM-driven entity extraction.

    Maintains two interleaved layers inside a single :class:`Graph`:

    * **Episodic layer** — episodes and temporally ordered observations.
    * **Semantic layer** — entities and relationships extracted from
      observations by an LLM, linked via ``MENTIONS`` and ``RELATES_TO``
      edges.

    When a ``model`` is provided, :meth:`record_turn` automatically
    extracts entities and relationships and builds the semantic graph.
    :meth:`recall` uses graph traversal (BFS + PPR) seeded from query
    entities to retrieve structured :class:`RecalledFact` objects rather
    than raw conversation transcripts.

    When no model is available extraction is skipped and recall falls
    back to keyword-based observation matching (backwards compatible).

    Args:
        graph: Knowledge graph backend.  Defaults to an in-memory graph.
        model: Chat model for entity extraction.  When ``None``,
            extraction is skipped and the memory operates in
            observation-only mode (backwards compatible).
        top_k: Maximum facts returned by :meth:`recall`.
        scope: Recall boundary: ``"user"``, ``"agent"``, or ``"global"``.
        reflection: Reflection cadence (``False``, ``True``, or ``int``).
    """

    def __init__(
        self,
        graph: Graph | None = None,
        *,
        model: Any = None,
        top_k: int = 5,
        scope: str = "user",
        reflection: bool | int = False,
    ) -> None:
        if graph is None:
            from cogent.graph.graph import Graph as _Graph

            graph = _Graph()
        self._graph = graph
        self._model = model
        self.top_k = top_k
        self.scope = scope
        self.reflection_cadence: int = (
            0 if not reflection else (1 if reflection is True else int(reflection))
        )
        self._open_episodes: dict[str, Episode] = {}
        # Track last observation per episode for temporal chaining
        self._last_obs: dict[str, str] = {}
        # Track last episode per thread for FOLLOWED_BY chaining
        self._last_episode: dict[str, str] = {}
        # Background extraction tasks (prevent GC of fire-and-forget tasks)
        self._bg_tasks: set[asyncio.Task[Any]] = set()

    @property
    def graph(self) -> Graph:
        return self._graph

    @property
    def model(self) -> Any:
        return self._model

    @model.setter
    def model(self, value: Any) -> None:
        self._model = value

    # ----- episode lifecycle ------------------------------------------------

    async def start_episode(
        self,
        agent: str,
        thread_id: str | None = None,
        *,
        user_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Episode:
        """Begin a new episode.

        Args:
            agent: Owning agent name.
            thread_id: Optional thread / conversation ID.
            user_id: Optional user identifier for privacy isolation.
            metadata: Extra data stored on the episode entity.

        Returns:
            The newly created :class:`Episode`.
        """
        ep = Episode(
            id=f"ep_{uuid.uuid4().hex[:12]}",
            agent=agent,
            thread_id=thread_id,
            user_id=user_id,
            metadata=metadata or {},
        )

        await self._graph.add_entity(
            ep.id,
            _EPISODE_TYPE,
            agent=ep.agent,
            thread_id=ep.thread_id or "",
            user_id=ep.user_id or "",
            started_at=ep.started_at.isoformat(),
            outcome="",
            **ep.metadata,
        )

        # Chain to previous episode in the same thread
        if thread_id and thread_id in self._last_episode:
            prev_id = self._last_episode[thread_id]
            await self._graph.add_relationship(prev_id, _FOLLOWED_BY, ep.id)

        if thread_id:
            self._last_episode[thread_id] = ep.id

        self._open_episodes[ep.id] = ep
        return ep

    async def close_episode(
        self,
        episode_id: str,
        *,
        outcome: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Episode:
        """Close an open episode.

        Args:
            episode_id: ID of the episode to close.
            outcome: Free-text description of the episode result.
            metadata: Extra metadata to merge.

        Returns:
            The closed :class:`Episode`.

        Raises:
            KeyError: If the episode is not open.
        """
        ep = self._open_episodes.pop(episode_id, None)
        if ep is None:
            raise KeyError(f"No open episode with id {episode_id!r}")

        ep.closed_at = datetime.now(UTC)
        ep.outcome = outcome

        if metadata:
            ep.metadata.update(metadata)

        # Update graph entity attributes
        entity = await self._graph.get_entity(episode_id)
        if entity:
            entity.update_attributes(
                closed_at=ep.closed_at.isoformat(),
                outcome=outcome or "",
                **ep.metadata,
            )

        # Clean up temporal tracking
        self._last_obs.pop(episode_id, None)
        return ep

    # ----- observations -----------------------------------------------------

    async def add_observation(
        self,
        episode_id: str,
        content: str,
        *,
        kind: str = "observation",
        metadata: dict[str, Any] | None = None,
    ) -> Observation:
        """Record an observation inside an open episode.

        Observations are chained with temporal ``NEXT`` edges and linked to
        their parent episode via ``OBSERVED_IN``.

        Args:
            episode_id: Parent episode (must be open).
            content: Free-text event content.
            kind: Category — ``"user"``, ``"assistant"``, ``"tool"``, ``"reflection"``.
            metadata: Extra data.

        Returns:
            The created :class:`Observation`.

        Raises:
            KeyError: If the episode is not open.
        """
        if episode_id not in self._open_episodes:
            raise KeyError(f"No open episode with id {episode_id!r}")

        obs = Observation(
            id=f"obs_{uuid.uuid4().hex[:12]}",
            episode_id=episode_id,
            content=content,
            kind=kind,
            metadata=metadata or {},
        )

        await self._graph.add_entity(
            obs.id,
            _OBSERVATION_TYPE,
            episode_id=episode_id,
            content=content,
            kind=kind,
            timestamp=obs.timestamp.isoformat(),
            **(metadata or {}),
        )

        # Link observation → episode
        await self._graph.add_relationship(obs.id, _OBSERVED_IN, episode_id)

        # Chain to previous observation (temporal ordering)
        prev_obs_id = self._last_obs.get(episode_id)
        if prev_obs_id is not None:
            await self._graph.add_relationship(prev_obs_id, _NEXT_OBS, obs.id)

        self._last_obs[episode_id] = obs.id
        return obs

    # ----- semantic linking -------------------------------------------------

    async def link_entity(
        self,
        observation_id: str,
        entity_id: str,
    ) -> None:
        """Link an observation to a semantic entity already in the graph.

        Creates a ``MENTIONS`` edge from the observation to the entity.
        The entity must already exist (add it via ``graph.add_entity``).

        Args:
            observation_id: The observation doing the mentioning.
            entity_id: The semantic entity being referenced.

        Raises:
            ValueError: If either node does not exist in the graph.
        """
        obs = await self._graph.get_entity(observation_id)
        target = await self._graph.get_entity(entity_id)
        if obs is None:
            raise ValueError(f"Observation {observation_id!r} not found in graph")
        if target is None:
            raise ValueError(f"Entity {entity_id!r} not found in graph")

        await self._graph.add_relationship(observation_id, _MENTIONS, entity_id)

    # ----- entity extraction ------------------------------------------------

    async def extract_and_link(
        self,
        observation_ids: list[str],
        user_message: str,
        assistant_message: str,
        *,
        model: Any = None,
    ) -> tuple[list[str], list[tuple[str, str, str]]]:
        """Extract entities and relationships from a turn via LLM.

        Adds extracted entities to the semantic graph layer (with fuzzy
        deduplication), creates ``MENTIONS`` edges from the observations,
        and creates ``RELATES_TO`` edges with a canonical relation type
        and importance score.

        Args:
            observation_ids: Observation node IDs to link entities to.
            user_message: The user's message text.
            assistant_message: The assistant's response text.
            model: Chat model override.  Falls back to ``self._model``.

        Returns:
            Tuple of ``(entity_ids, relationships)`` where relationships
            are ``(source_id, label, target_id)`` triples.
        """
        llm = model or self._model
        if llm is None:
            return [], []

        # --- build index of existing semantic entities for fuzzy merge ---
        all_ents = await self._graph.get_all_entities()
        existing_names: dict[str, str] = {}
        existing_entity_names: list[str] = []
        for e in all_ents:
            if e.entity_type == _SEMANTIC_TYPE:
                ename = e.attributes.get("name", "").lower()
                if ename:
                    existing_names[ename] = e.id
                    existing_entity_names.append(e.attributes.get("name", ""))

        # --- build graph context for the LLM ---
        existing_graph_section = ""
        if existing_entity_names:
            graph_lines = [
                "Existing graph (reuse these entity names when applicable):",
                f"Entities: {', '.join(existing_entity_names)}",
            ]
            existing_rels = await self._graph.get_relationships(relation=_RELATES_TO)
            if existing_rels:
                graph_lines.append("Edges:")
                for r in existing_rels[:30]:  # cap to avoid prompt bloat
                    src = await self._graph.get_entity(r.source_id)
                    tgt = await self._graph.get_entity(r.target_id)
                    sn = src.attributes.get("name", r.source_id) if src else r.source_id
                    tn = tgt.attributes.get("name", r.target_id) if tgt else r.target_id
                    lbl = r.attributes.get("label", r.relation)
                    canon = r.attributes.get("canonical", r.relation)
                    graph_lines.append(f"  {sn} --{canon}({lbl})--> {tn}")
            existing_graph_section = "\n".join(graph_lines) + "\n"

        prompt = _EXTRACT_PROMPT.format(
            user_message=user_message[:2000],
            assistant_message=assistant_message[:2000],
            existing_graph=existing_graph_section,
        )

        raw_entities, raw_rels = await _llm_extract(llm, prompt)

        # --- add entities to semantic graph (with fuzzy dedup) ---
        entity_ids: list[str] = []
        name_to_id: dict[str, str] = {}

        for ent in raw_entities:
            name = ent.get("name", "").strip()
            etype = ent.get("type", "Concept").strip()
            if not name:
                continue

            name_lower = name.lower()

            # Check for fuzzy match against existing entities
            merge_id = _find_merge_target(name_lower, existing_names)
            if merge_id is not None:
                eid = merge_id
                existing = await self._graph.get_entity(eid)
                if existing is not None:
                    count = int(existing.attributes.get("mention_count", 0)) + 1
                    existing.update_attributes(
                        mention_count=count,
                        last_seen=datetime.now(UTC).isoformat(),
                    )
            else:
                eid = _normalize_entity_id(name)
                existing = await self._graph.get_entity(eid)
                if existing is None:
                    await self._graph.add_entity(
                        eid,
                        _SEMANTIC_TYPE,
                        name=name,
                        semantic_type=etype,
                        first_seen=datetime.now(UTC).isoformat(),
                        last_seen=datetime.now(UTC).isoformat(),
                        mention_count=1,
                    )
                    existing_names[name_lower] = eid
                else:
                    count = int(existing.attributes.get("mention_count", 0)) + 1
                    existing.update_attributes(
                        mention_count=count,
                        last_seen=datetime.now(UTC).isoformat(),
                    )

            name_to_id[name_lower] = eid
            entity_ids.append(eid)

        # --- link observations → entities via MENTIONS ---
        for obs_id in observation_ids:
            for eid in entity_ids:
                with contextlib.suppress(ValueError, Exception):
                    await self._graph.add_relationship(obs_id, _MENTIONS, eid)

        # --- add relationships as RELATES_TO edges ---
        relationships: list[tuple[str, str, str]] = []
        for rel in raw_rels:
            src_name = rel.get("source", "").strip().lower()
            tgt_name = rel.get("target", "").strip().lower()
            relation = rel.get("relation", "").strip()
            label = rel.get("label", "").strip() or relation
            importance = int(rel.get("importance", 2))
            importance = max(1, min(5, importance))
            if not (src_name and tgt_name and relation):
                continue

            # Normalize relation to canonical set
            canonical = relation if relation in CANONICAL_RELATIONS else "related_to"

            src_id = (
                name_to_id.get(src_name)
                or _find_merge_target(src_name, existing_names)
                or _normalize_entity_id(src_name)
            )
            tgt_id = (
                name_to_id.get(tgt_name)
                or _find_merge_target(tgt_name, existing_names)
                or _normalize_entity_id(tgt_name)
            )

            # Ensure both endpoints exist
            for nid, nname in [(src_id, src_name), (tgt_id, tgt_name)]:
                if await self._graph.get_entity(nid) is None:
                    await self._graph.add_entity(
                        nid,
                        _SEMANTIC_TYPE,
                        name=nname.title(),
                        semantic_type="Concept",
                        first_seen=datetime.now(UTC).isoformat(),
                        last_seen=datetime.now(UTC).isoformat(),
                        mention_count=1,
                    )
                    existing_names[nname] = nid

            with contextlib.suppress(ValueError, Exception):
                await self._graph.add_relationship(
                    src_id,
                    _RELATES_TO,
                    tgt_id,
                    label=label,
                    canonical=canonical,
                    importance=importance,
                    first_seen=datetime.now(UTC).isoformat(),
                )

            relationships.append((src_id, label, tgt_id))

        return entity_ids, relationships

    # ----- convenience: record a full turn -----------------------------------

    async def record_turn(
        self,
        episode_id: str,
        user_message: str,
        assistant_message: str,
        *,
        tool_calls: list[dict[str, Any]] | list[Any] | None = None,
        model: Any = None,
    ) -> list[Observation]:
        """Record a turn and extract entities into the semantic graph.

        Creates observations for the user message, tool calls, and
        assistant response.  When a model is available, runs LLM-based
        entity extraction and links observations to semantic entities.

        Args:
            episode_id: Parent episode (must be open).
            user_message: The user's input.
            assistant_message: The assistant's response.
            tool_calls: Optional tool call data.
            model: Chat model override for extraction.

        Returns:
            The observations created (in temporal order).
        """
        observations: list[Observation] = []
        observations.append(
            await self.add_observation(episode_id, user_message, kind="user")
        )
        if tool_calls:
            for tc in tool_calls:
                summary, meta = self._format_tool_observation(tc)
                observations.append(
                    await self.add_observation(
                        episode_id, summary, kind="tool", metadata=meta
                    )
                )
        observations.append(
            await self.add_observation(episode_id, assistant_message, kind="assistant")
        )

        # --- LLM entity extraction (background — don't block the caller) ---
        llm = model or self._model
        if llm is not None:
            obs_ids = [obs.id for obs in observations]
            task = asyncio.create_task(
                self._safe_extract(obs_ids, user_message, assistant_message, llm)
            )
            self._bg_tasks.add(task)
            task.add_done_callback(self._bg_tasks.discard)

        return observations

    async def _safe_extract(
        self,
        obs_ids: list[str],
        user_message: str,
        assistant_message: str,
        model: Any,
    ) -> None:
        """Run extraction in background, swallowing errors."""
        try:
            await self.extract_and_link(
                obs_ids, user_message, assistant_message, model=model
            )
        except Exception:
            _log.debug("background entity extraction failed", exc_info=True)

    async def drain(self) -> None:
        """Await all pending background extraction tasks.

        Most callers do not need this directly — :meth:`get_entities` and
        :meth:`get_facts` drain automatically.  Useful in tests or when
        shutting down to ensure no fire-and-forget tasks are abandoned.
        """
        if self._bg_tasks:
            await asyncio.gather(*self._bg_tasks, return_exceptions=True)

    @staticmethod
    def _format_tool_observation(tc: Any) -> tuple[str, dict[str, Any]]:
        """Build observation content and metadata from a tool call.

        Handles both plain dicts and :class:`~cogent.core.response.ToolCall`
        dataclass instances.
        """
        # --- Rich ToolCall object (has .tool_name, .success, etc.) ---
        if hasattr(tc, "tool_name") and hasattr(tc, "success"):
            name = tc.tool_name
            args = getattr(tc, "arguments", {})
            duration_ms = round(getattr(tc, "duration", 0) * 1000)

            if tc.success:
                result_str = str(getattr(tc, "result", ""))
                preview = result_str[:120] + ("…" if len(result_str) > 120 else "")
                summary = f"tool:{name}({args}) → OK {duration_ms}ms {preview}"
            else:
                error = getattr(tc, "error", None) or "unknown error"
                summary = f"tool:{name}({args}) → FAILED {duration_ms}ms {error}"

            meta: dict[str, Any] = {
                "name": name,
                "args": args,
                "success": tc.success,
                "duration_ms": duration_ms,
            }
            if tc.success:
                result_str = str(getattr(tc, "result", ""))
                meta["result_preview"] = result_str[:500]
            else:
                meta["error"] = getattr(tc, "error", None)
            return summary, meta

        # --- Plain dict (legacy / manual calls) ---
        name = tc.get("name", "?")
        args = tc.get("args", {})
        summary = f"tool:{name}({args})"
        return summary, dict(tc)

    # ----- recall -----------------------------------------------------------

    async def get_episode(self, episode_id: str) -> Episode | None:
        """Retrieve an episode by ID (from graph, not just open cache)."""
        entity = await self._graph.get_entity(episode_id)
        if entity is None or entity.entity_type != _EPISODE_TYPE:
            return None
        return _entity_to_episode(entity)

    async def get_observations(self, episode_id: str) -> list[Observation]:
        """Get all observations for an episode in temporal order.

        Args:
            episode_id: The episode to query.

        Returns:
            Observations sorted by timestamp.
        """
        rels = await self._graph.get_relationships(
            target_id=episode_id, relation=_OBSERVED_IN
        )
        observations: list[Observation] = []
        for rel in rels:
            entity = await self._graph.get_entity(rel.source_id)
            if entity and entity.entity_type == _OBSERVATION_TYPE:
                observations.append(_entity_to_observation(entity))

        observations.sort(key=lambda o: o.timestamp)
        return observations

    async def list_episodes(
        self,
        agent: str | None = None,
        thread_id: str | None = None,
        *,
        user_id: str | None = None,
        limit: int | None = None,
    ) -> list[Episode]:
        """List episodes, optionally filtered by agent, thread, or user.

        Args:
            agent: Filter by agent name.
            thread_id: Filter by thread ID.
            user_id: Filter by user ID.
            limit: Maximum episodes to return (most recent first).

        Returns:
            Episodes sorted most-recent-first.
        """
        entities = await self._graph.get_all_entities()
        episodes: list[Episode] = []
        for e in entities:
            if e.entity_type != _EPISODE_TYPE:
                continue
            if agent and e.attributes.get("agent") != agent:
                continue
            if thread_id and e.attributes.get("thread_id") != thread_id:
                continue
            if user_id and e.attributes.get("user_id") != user_id:
                continue
            episodes.append(_entity_to_episode(e))

        episodes.sort(key=lambda ep: ep.started_at, reverse=True)
        if limit:
            episodes = episodes[:limit]
        return episodes

    async def recall(
        self,
        query: str,
        *,
        top_k: int = 5,
        agent: str | None = None,
        thread_id: str | None = None,
        user_id: str | None = None,
        model: Any = None,
    ) -> list[RecalledFact]:
        """Recall structured facts relevant to a query via graph traversal.

        Strategy:

        1. Extract query entities via LLM (or keyword fallback).
        2. Resolve extracted names to semantic entity nodes in the graph.
        3. BFS from seed entities collecting ``RELATES_TO`` edges as facts.
        4. If PPR is available, rank by Personalized PageRank scores.
        5. Return structured :class:`RecalledFact` objects.

        When no model is available or no semantic entities exist, falls
        back to keyword-based observation matching (backwards compatible).

        Args:
            query: Free-text recall query.
            top_k: Maximum facts to return.
            agent: Filter by agent scope.
            thread_id: Filter by thread scope.
            user_id: Filter by user scope.
            model: Chat model override for query entity extraction.

        Returns:
            Structured facts sorted by relevance.
        """
        llm = model or self._model
        all_entities = await self._graph.get_all_entities()
        semantic_entities = {
            e.id: e for e in all_entities if e.entity_type == _SEMANTIC_TYPE
        }

        if not semantic_entities:
            return await self._recall_observations_as_facts(
                query, top_k=top_k, agent=agent, thread_id=thread_id, user_id=user_id
            )

        # --- Step 1: Extract query entities ---
        seed_ids = await self._resolve_query_seeds(query, semantic_entities, llm)

        if not seed_ids:
            seed_ids = self._keyword_seed_entities(query, semantic_entities)

        if not seed_ids:
            return await self._recall_observations_as_facts(
                query, top_k=top_k, agent=agent, thread_id=thread_id, user_id=user_id
            )

        # --- Step 2: Collect facts via BFS from seeds ---
        facts = await self._bfs_collect_facts(seed_ids, max_depth=2)

        # --- Step 3: Rank by importance, recency, and PPR ---
        now = datetime.now(UTC)

        ppr_scores: dict[str, float] = {}
        if hasattr(self._graph.engine, "personalized_pagerank"):
            ppr_scores = self._graph.personalized_pagerank(seed_ids, top_k=None)

        def _fact_score(fact: RecalledFact) -> float:
            # PPR topology score (0-1 range)
            src_id = _normalize_entity_id(fact.subject)
            tgt_id = _normalize_entity_id(fact.object)
            ppr = ppr_scores.get(src_id, 0) + ppr_scores.get(tgt_id, 0)

            # Importance (1-5 from extraction, default 2)
            importance = fact.importance / 5.0

            # Recency decay — half-life of 7 days
            if fact.timestamp:
                age_days = max((now - fact.timestamp).total_seconds() / 86400, 0)
                recency = 2.0 ** (-age_days / 7.0)
            else:
                recency = 0.5

            return (0.3 * ppr) + (0.5 * importance) + (0.2 * recency)

        facts.sort(key=_fact_score, reverse=True)

        # --- Step 4: Scope filtering ---
        if agent or thread_id or user_id:
            facts = await self._filter_facts_by_scope(
                facts, all_entities, agent=agent, thread_id=thread_id, user_id=user_id
            )

        return facts[:top_k]

    async def _resolve_query_seeds(
        self,
        query: str,
        semantic_entities: dict[str, Any],
        llm: Any | None,
    ) -> list[str]:
        """Extract query entities via LLM and resolve to graph node IDs.

        Sends the full list of known entity names to the LLM so it can
        select the most relevant ones directly — no brittle substring
        matching required.
        """
        if llm is None:
            return self._keyword_seed_entities(query, semantic_entities)

        # Build name → id map and entity list for the prompt
        entity_names: dict[str, str] = {}
        name_list: list[str] = []
        for eid, e in semantic_entities.items():
            name = e.attributes.get("name", "")
            if name:
                entity_names[name.lower()] = eid
                name_list.append(name)

        if not name_list:
            return []

        prompt = _EXTRACT_QUERY_PROMPT.format(
            query=query,
            entity_list="\n".join(f"- {n}" for n in name_list),
        )
        try:
            response = await llm.ainvoke(prompt)
            content = (
                response.content if hasattr(response, "content") else str(response)
            )
            text = content.strip()
            if text.startswith("```"):
                text = text.split("\n", 1)[-1]
                if text.endswith("```"):
                    text = text[:-3]
                text = text.strip()
            names = json.loads(text)
            if not isinstance(names, list):
                names = []
        except Exception:
            names = []

        if not names:
            return self._keyword_seed_entities(query, semantic_entities)

        # Resolve returned names to entity IDs (exact match + fuzzy fallback)
        resolved: list[str] = []
        for name in names:
            name_lower = str(name).lower()
            if name_lower in entity_names:
                resolved.append(entity_names[name_lower])
            else:
                merge_id = _find_merge_target(name_lower, entity_names)
                if merge_id is not None:
                    resolved.append(merge_id)

        return resolved

    @staticmethod
    def _keyword_seed_entities(
        query: str,
        semantic_entities: dict[str, Any],
    ) -> list[str]:
        """Fallback: find semantic entities whose name overlaps query terms."""
        terms = {t.lower() for t in query.split() if len(t) >= 3}
        seeds: list[str] = []
        for eid, e in semantic_entities.items():
            name = str(e.attributes.get("name", "")).lower()
            if any(term in name or name in term for term in terms):
                seeds.append(eid)
        return seeds

    async def _bfs_collect_facts(
        self,
        seed_ids: list[str],
        *,
        max_depth: int = 2,
    ) -> list[RecalledFact]:
        """BFS from seed entities collecting ``RELATES_TO`` edges as facts."""
        visited: set[str] = set()
        frontier = set(seed_ids)
        facts: list[RecalledFact] = []
        seen_edges: set[tuple[str, str, str]] = set()

        for _depth in range(max_depth):
            if not frontier:
                break
            next_frontier: set[str] = set()
            for nid in frontier:
                if nid in visited:
                    continue
                visited.add(nid)

                for rel in await self._graph.get_relationships(
                    source_id=nid, relation=_RELATES_TO
                ):
                    edge_key = (
                        rel.source_id,
                        rel.attributes.get("label", ""),
                        rel.target_id,
                    )
                    if edge_key in seen_edges:
                        continue
                    seen_edges.add(edge_key)

                    src_e = await self._graph.get_entity(rel.source_id)
                    tgt_e = await self._graph.get_entity(rel.target_id)
                    src_name = (
                        src_e.attributes.get("name", rel.source_id)
                        if src_e
                        else rel.source_id
                    )
                    tgt_name = (
                        tgt_e.attributes.get("name", rel.target_id)
                        if tgt_e
                        else rel.target_id
                    )

                    ep_id = await self._find_source_episode(rel.source_id)
                    ts_str = rel.attributes.get("first_seen", "")
                    ts = datetime.fromisoformat(ts_str) if ts_str else None
                    imp = int(rel.attributes.get("importance", 2))

                    facts.append(
                        RecalledFact(
                            subject=str(src_name),
                            relation=str(rel.attributes.get("label", _RELATES_TO)),
                            object=str(tgt_name),
                            source_episode=ep_id,
                            timestamp=ts,
                            importance=imp,
                        )
                    )
                    next_frontier.add(rel.target_id)

                for rel in await self._graph.get_relationships(
                    target_id=nid, relation=_RELATES_TO
                ):
                    edge_key = (
                        rel.source_id,
                        rel.attributes.get("label", ""),
                        rel.target_id,
                    )
                    if edge_key in seen_edges:
                        continue
                    seen_edges.add(edge_key)

                    src_e = await self._graph.get_entity(rel.source_id)
                    tgt_e = await self._graph.get_entity(rel.target_id)
                    src_name = (
                        src_e.attributes.get("name", rel.source_id)
                        if src_e
                        else rel.source_id
                    )
                    tgt_name = (
                        tgt_e.attributes.get("name", rel.target_id)
                        if tgt_e
                        else rel.target_id
                    )

                    ep_id = await self._find_source_episode(rel.source_id)
                    ts_str = rel.attributes.get("first_seen", "")
                    ts = datetime.fromisoformat(ts_str) if ts_str else None
                    imp = int(rel.attributes.get("importance", 2))

                    facts.append(
                        RecalledFact(
                            subject=str(src_name),
                            relation=str(rel.attributes.get("label", _RELATES_TO)),
                            object=str(tgt_name),
                            source_episode=ep_id,
                            timestamp=ts,
                            importance=imp,
                        )
                    )
                    next_frontier.add(rel.source_id)

            frontier = next_frontier - visited

        return facts

    async def _find_source_episode(self, entity_id: str) -> str | None:
        """Trace entity → MENTIONS ← observation → OBSERVED_IN → episode."""
        mentions_rels = await self._graph.get_relationships(
            target_id=entity_id, relation=_MENTIONS
        )
        for rel in mentions_rels:
            obs_rels = await self._graph.get_relationships(
                source_id=rel.source_id, relation=_OBSERVED_IN
            )
            for obs_rel in obs_rels:
                return obs_rel.target_id
        return None

    async def _filter_facts_by_scope(
        self,
        facts: list[RecalledFact],
        all_entities: list[Any],
        *,
        agent: str | None = None,
        thread_id: str | None = None,
        user_id: str | None = None,
    ) -> list[RecalledFact]:
        """Filter facts by episode scope."""
        ep_lookup = {e.id: e for e in all_entities if e.entity_type == _EPISODE_TYPE}
        filtered: list[RecalledFact] = []
        for fact in facts:
            if fact.source_episode and fact.source_episode in ep_lookup:
                ep = ep_lookup[fact.source_episode]
                if agent and ep.attributes.get("agent") != agent:
                    continue
                if thread_id and ep.attributes.get("thread_id") != thread_id:
                    continue
                if user_id and ep.attributes.get("user_id") != user_id:
                    continue
            filtered.append(fact)
        return filtered

    async def _recall_observations_as_facts(
        self,
        query: str,
        *,
        top_k: int = 5,
        agent: str | None = None,
        thread_id: str | None = None,
        user_id: str | None = None,
    ) -> list[RecalledFact]:
        """Legacy fallback: keyword recall over observations, wrapped as facts."""
        query_terms = {t.lower() for t in query.split() if len(t) >= 3}
        all_entities = await self._graph.get_all_entities()

        obs_entities: dict[str, Any] = {}
        seeds: list[str] = []
        for e in all_entities:
            if e.entity_type != _OBSERVATION_TYPE:
                continue
            obs_entities[e.id] = e
            content = str(e.attributes.get("content", "")).lower()
            if any(term in content for term in query_terms):
                seeds.append(e.id)

        if not obs_entities:
            return []

        ranked_ids = sorted(
            seeds or list(obs_entities.keys()),
            key=lambda nid: str(obs_entities[nid].attributes.get("timestamp", "")),
            reverse=True,
        )

        if agent or thread_id or user_id:
            ep_lookup = {
                e.id: e for e in all_entities if e.entity_type == _EPISODE_TYPE
            }
            filtered: list[str] = []
            for nid in ranked_ids:
                ep_id = obs_entities[nid].attributes.get("episode_id")
                if ep_id and ep_id in ep_lookup:
                    ep = ep_lookup[ep_id]
                    if agent and ep.attributes.get("agent") != agent:
                        continue
                    if thread_id and ep.attributes.get("thread_id") != thread_id:
                        continue
                    if user_id and ep.attributes.get("user_id") != user_id:
                        continue
                filtered.append(nid)
            ranked_ids = filtered

        results: list[RecalledFact] = []
        for nid in ranked_ids[:top_k]:
            obs = _entity_to_observation(obs_entities[nid])
            results.append(
                RecalledFact(
                    subject=obs.kind,
                    relation="said",
                    object=obs.content,
                    source_episode=obs.episode_id,
                    timestamp=obs.timestamp,
                )
            )
        return results

    # ----- semantic graph queries -------------------------------------------

    async def get_entities(self) -> list[dict[str, Any]]:
        """Return all semantic entities in the graph."""
        await self.drain()
        all_ents = await self._graph.get_all_entities()
        return [
            {
                "id": e.id,
                "name": e.attributes.get("name", ""),
                "type": e.attributes.get("semantic_type", ""),
                "mention_count": e.attributes.get("mention_count", 0),
            }
            for e in all_ents
            if e.entity_type == _SEMANTIC_TYPE
        ]

    async def get_facts(self) -> list[RecalledFact]:
        """Return all ``RELATES_TO`` facts in the graph."""
        await self.drain()
        all_rels = await self._graph.get_relationships(relation=_RELATES_TO)
        facts: list[RecalledFact] = []
        for rel in all_rels:
            src = await self._graph.get_entity(rel.source_id)
            tgt = await self._graph.get_entity(rel.target_id)
            src_name = (
                src.attributes.get("name", rel.source_id) if src else rel.source_id
            )
            tgt_name = (
                tgt.attributes.get("name", rel.target_id) if tgt else rel.target_id
            )
            ts_str = rel.attributes.get("first_seen", "")
            facts.append(
                RecalledFact(
                    subject=str(src_name),
                    relation=str(rel.attributes.get("label", "")),
                    object=str(tgt_name),
                    timestamp=datetime.fromisoformat(ts_str) if ts_str else None,
                )
            )
        return facts

    # ----- reflection -------------------------------------------------------

    async def reflect(
        self,
        model: Any,
        *,
        episode_id: str | None = None,
        agent: str | None = None,
        thread_id: str | None = None,
        max_observations: int = 20,
    ) -> list[Observation]:
        """Synthesize recent observations into higher-level lessons.

        Reads observations from a specific episode or across recent episodes,
        asks an LLM to identify patterns and lessons, and stores each lesson
        as an :class:`Observation` with ``kind="reflection"`` in the episodic
        graph.

        Inspired by the *reflection* step in Generative Agents (Park et al.,
        2023) and the *learning actions* concept from CoALA (Sumers et al.,
        2024).

        Args:
            model: A ``BaseChatModel`` instance (with ``with_structured_output``
                and ``ainvoke`` support).  Typically the agent's own model.
            episode_id: Reflect on observations from this specific episode.
                When omitted, gathers observations across recent episodes
                filtered by *agent* and/or *thread_id*.
            agent: Filter observations by agent name (used when *episode_id*
                is not provided).
            thread_id: Filter observations by thread (used when *episode_id*
                is not provided).
            max_observations: Maximum observations to feed the LLM.

        Returns:
            Reflection observations created (one per lesson), stored in the
            episodic graph under the given *episode_id* (or the most recent
            matching episode).

        Raises:
            ValueError: If no observations are found to reflect on.
        """
        # --- gather observations ---
        if episode_id:
            observations = await self.get_observations(episode_id)
        else:
            observations = await self._gather_recent_observations(
                agent=agent, thread_id=thread_id, limit=max_observations
            )

        if not observations:
            raise ValueError("No observations found to reflect on.")

        observations = observations[-max_observations:]

        # Determine target episode for storing reflections
        target_episode_id = episode_id or observations[-1].episode_id

        # --- format for LLM ---
        obs_lines = []
        for obs in observations:
            prefix = obs.kind.upper()
            obs_lines.append(f"[{prefix}] {obs.content}")
        observations_text = "\n".join(obs_lines)

        prompt = _REFLECTION_PROMPT.format(
            observations=observations_text,
            count=len(observations),
        )

        # --- LLM call ---
        from pydantic import BaseModel, Field

        class ReflectionOutput(BaseModel):
            """Lessons distilled from recent agent observations."""

            lessons: list[str] = Field(
                description=(
                    "Concise, actionable lessons or patterns observed. "
                    "Each lesson should be a single statement."
                ),
                min_length=1,
            )

        try:
            result = await model.with_structured_output(ReflectionOutput).ainvoke(
                prompt
            )
            lessons = result.lessons
        except Exception:
            # Fallback: plain text response, split by newlines
            response = await model.ainvoke(prompt)
            content = (
                response.content if hasattr(response, "content") else str(response)
            )
            lessons = [
                line.lstrip("0123456789.-) ").strip()
                for line in content.strip().splitlines()
                if line.strip() and not line.strip().startswith("#")
            ]

        if not lessons:
            return []

        # --- store as reflection observations ---
        reflections: list[Observation] = []
        for lesson in lessons:
            obs = await self.add_observation(
                target_episode_id,
                lesson,
                kind="reflection",
                metadata={"source_observations": len(observations)},
            )
            reflections.append(obs)

        return reflections

    async def _gather_recent_observations(
        self,
        *,
        agent: str | None = None,
        thread_id: str | None = None,
        limit: int = 20,
    ) -> list[Observation]:
        """Collect observations across recent episodes."""
        episodes = await self.list_episodes(agent=agent, thread_id=thread_id, limit=5)
        observations: list[Observation] = []
        for ep in reversed(episodes):  # oldest first
            obs_list = await self.get_observations(ep.id)
            observations.extend(obs_list)
            if len(observations) >= limit:
                break
        return observations[:limit]


_REFLECTION_PROMPT = """You are analyzing {count} observations from an AI agent's recent interactions.

{observations}

Based on these observations, identify the most important patterns, lessons, and insights. Focus on:

1. Recurring patterns or user preferences
2. What approaches worked well or failed
3. Tool effectiveness — which tools succeeded and which struggled
4. Knowledge the agent should carry forward to future interactions

Provide concise, actionable lessons. Each lesson should be a single clear statement that would help the agent perform better in future interactions. Aim for 3-5 lessons."""


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _entity_to_episode(entity: Any) -> Episode:
    attrs = entity.attributes
    closed_str = attrs.get("closed_at", "")
    closed_at = datetime.fromisoformat(closed_str) if closed_str else None
    started_str = attrs.get("started_at", "")
    started_at = (
        datetime.fromisoformat(started_str) if started_str else entity.created_at
    )
    extra_keys = {
        "agent",
        "thread_id",
        "user_id",
        "started_at",
        "closed_at",
        "outcome",
    }
    metadata = {k: v for k, v in attrs.items() if k not in extra_keys}
    return Episode(
        id=entity.id,
        agent=attrs.get("agent", ""),
        thread_id=attrs.get("thread_id") or None,
        user_id=attrs.get("user_id") or None,
        started_at=started_at,
        closed_at=closed_at,
        outcome=attrs.get("outcome") or None,
        metadata=metadata,
    )


def _entity_to_observation(entity: Any) -> Observation:
    attrs = entity.attributes
    ts_str = attrs.get("timestamp", "")
    timestamp = datetime.fromisoformat(ts_str) if ts_str else entity.created_at
    extra_keys = {"episode_id", "content", "kind", "timestamp"}
    metadata = {k: v for k, v in attrs.items() if k not in extra_keys}
    return Observation(
        id=entity.id,
        episode_id=attrs.get("episode_id", ""),
        content=attrs.get("content", ""),
        kind=attrs.get("kind", "observation"),
        timestamp=timestamp,
        metadata=metadata,
    )


def _normalize_entity_id(name: str) -> str:
    """Normalize an entity name into a stable graph node ID."""
    return "se_" + name.strip().lower().replace(" ", "_").replace("'", "")


def _token_overlap(a: str, b: str) -> float:
    """Token-level Jaccard similarity between two lowercased strings."""
    tokens_a = set(a.lower().split())
    tokens_b = set(b.lower().split())
    if not tokens_a or not tokens_b:
        return 0.0
    return len(tokens_a & tokens_b) / len(tokens_a | tokens_b)


def _find_merge_target(
    name: str,
    existing: dict[str, str],
    threshold: float = _MERGE_THRESHOLD,
) -> str | None:
    """Find an existing entity name that is close enough to merge into.

    Uses two heuristics (whichever fires first):

    1. **Substring containment** — if either name fully contains the
       other (after lowering), they refer to the same concept.  This
       catches prefix/suffix variations like "budget" vs "$50/week
       budget" that token-overlap misses.
    2. **Jaccard token overlap** — standard bag-of-words similarity.

    Args:
        name: New entity name (lowercased).
        existing: Map of ``{lowered_name: entity_id}`` for all existing
            semantic entities.
        threshold: Minimum Jaccard token overlap to consider a match.

    Returns:
        The entity ID to merge into, or ``None`` if no match.
    """
    best_id: str | None = None
    best_score: float = 0.0
    for ename, eid in existing.items():
        # Substring containment — catches "budget" ⊂ "$50/week budget"
        if len(name) >= 3 and len(ename) >= 3 and (name in ename or ename in name):
            return eid
        score = _token_overlap(name, ename)
        if score > best_score and score >= threshold:
            best_score = score
            best_id = eid
    return best_id


async def _llm_extract(
    llm: Any, prompt: str
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Call LLM and parse JSON extraction result."""
    try:
        response = await llm.ainvoke(prompt)
        content = response.content if hasattr(response, "content") else str(response)
        text = content.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[-1]
            if text.endswith("```"):
                text = text[:-3]
            text = text.strip()
        data = json.loads(text)
        return data.get("entities", []), data.get("relationships", [])
    except (json.JSONDecodeError, Exception):
        return [], []
