"""Graph-based retriever using Personalized PageRank.

Uses knowledge graph structure and Personalized PageRank (PPR) to find
relevant documents via entity-centric graph traversal. Inspired by
HippoRAG (NeurIPS 2024) and fast-graphrag.

Pipeline:
1. Documents are chunked, entities/relationships extracted via LLM,
   and stored in a Graph with chunk attribution on entity attributes.
2. At query time, entities are extracted from the query, PPR runs from
   those seeds, and chunks linked to high-scoring nodes are returned.
3. Optionally combined with vector similarity for hybrid retrieval.

Reference:
    - Gutiérrez et al. "HippoRAG" (arXiv:2405.14831, NeurIPS 2024)
    - Guo et al. "LightRAG" (arXiv:2410.05779)
"""

from __future__ import annotations

import hashlib
import json
from typing import TYPE_CHECKING, Any

from cogent.retriever.base import BaseRetriever, RetrievalResult
from cogent.retriever.utils.llm_adapter import adapt_llm

if TYPE_CHECKING:
    from cogent.core import Document
    from cogent.graph.graph import Graph
    from cogent.models import Model
    from cogent.retriever.utils.llm_adapter import LLMProtocol
    from cogent.vectorstore import VectorStore


EXTRACT_ENTITIES_PROMPT = """Extract the key entities from this text.

Text:
{text}

Return a JSON object:
{{
    "entities": [
        {{"name": "entity name", "type": "Person|Organization|Location|Concept|Technology|Product|Event|Other"}}
    ],
    "relationships": [
        {{"source": "entity1", "relation": "relationship_type", "target": "entity2"}}
    ]
}}

Extract all meaningful entities and their relationships:"""


EXTRACT_QUERY_ENTITIES_PROMPT = """Identify the key entities mentioned in this question.

Question: {query}

Return a JSON array of entity names only:
["entity1", "entity2"]

Entities:"""


class GraphRetriever(BaseRetriever):
    """Retriever using Personalized PageRank over a knowledge graph.

    Builds a knowledge graph from documents with entity-to-chunk attribution,
    then retrieves by running PPR from query-mentioned entities and collecting
    the chunks associated with high-scoring graph nodes.

    This is more effective than naive entity matching for multi-hop questions
    because PPR propagates relevance through the graph structure.

    Args:
        llm: Language model for entity/relationship extraction.
        graph: Optional Graph instance. Defaults to ``Graph()`` (NetworkX
            engine, in-memory storage). Pass a custom graph when you need
            a specific engine or persistent storage.
        vectorstore: Optional vector store for hybrid retrieval.
        alpha: PPR damping factor. Higher = more exploration.
        chunk_size: Text chunk size for document processing.
        graph_weight: Weight for graph-based scores in hybrid mode (0-1).

    Example:
        >>> from cogent.retriever import GraphRetriever
        >>> from cogent.models import create_chat
        >>>
        >>> model = create_chat("openai", model="gpt-4o-mini")
        >>> retriever = GraphRetriever(llm=model)
        >>>
        >>> await retriever.add_documents(documents)
        >>> results = await retriever.retrieve("Who manages Project X?", k=5)
    """

    _name: str = "graph_ppr"

    def __init__(
        self,
        llm: Model,
        graph: Graph | None = None,
        vectorstore: VectorStore | None = None,
        *,
        alpha: float = 0.85,
        chunk_size: int = 1000,
        graph_weight: float = 0.7,
        enable_community_search: bool = False,
        name: str | None = None,
    ) -> None:
        if graph is None:
            from cogent.graph.graph import Graph as _Graph

            graph = _Graph()
        self._graph = graph
        self._llm: LLMProtocol = adapt_llm(llm)
        self._vectorstore = vectorstore
        self._alpha = alpha
        self._chunk_size = chunk_size
        self._graph_weight = graph_weight
        self._enable_community_search = enable_community_search

        # chunk_id → (Document, chunk_text)
        self._chunks: dict[str, tuple[Document, str]] = {}

        # Community cache (populated by build_communities)
        self._communities: list | None = None

        if name:
            self._name = name

    @property
    def graph(self) -> Graph:
        """The underlying knowledge graph."""
        return self._graph

    # ------------------------------------------------------------------
    # Indexing
    # ------------------------------------------------------------------

    async def add_documents(self, documents: list[Document]) -> list[str]:
        """Index documents into the graph and optional vector store.

        For each document:
        1. Split into chunks.
        2. Extract entities and relationships via LLM.
        3. Add entities to graph with chunk/doc attribution.
        4. Add relationships to graph.
        5. Optionally embed chunks into the vector store.

        Args:
            documents: Documents to index.

        Returns:
            List of document IDs.
        """
        ids: list[str] = []

        for doc in documents:
            doc_id = doc.id or hashlib.md5(doc.text.encode()).hexdigest()[:12]
            chunks = self._chunk_text(doc.text)

            for i, chunk in enumerate(chunks):
                chunk_id = f"{doc_id}_chunk_{i}"
                self._chunks[chunk_id] = (doc, chunk)

                entities, relationships = await self._extract_graph_data(chunk)

                # Add entities with chunk attribution
                entity_names: list[str] = []
                for ent in entities:
                    ent_name = ent["name"]
                    ent_type = ent.get("type", "Entity")
                    entity_names.append(ent_name)

                    existing = await self._graph.storage.get_entity(ent_name)
                    if existing:
                        # Append this chunk to existing entity's chunk list
                        chunk_ids = list(existing.attributes.get("chunk_ids", []))
                        if chunk_id not in chunk_ids:
                            chunk_ids.append(chunk_id)
                        existing.update_attributes(chunk_ids=chunk_ids)
                    else:
                        await self._graph.add_entity(
                            ent_name,
                            ent_type,
                            chunk_ids=[chunk_id],
                            doc_id=doc_id,
                        )

                for rel in relationships:
                    try:
                        await self._graph.add_relationship(
                            rel["source"],
                            rel["relation"],
                            rel["target"],
                            doc_id=doc_id,
                        )
                    except (ValueError, KeyError):
                        # Skip relationships referencing missing entities
                        continue

                # Add chunk to vector store
                if self._vectorstore:
                    await self._vectorstore.add_texts(
                        [chunk],
                        metadatas=[
                            {
                                "doc_id": doc_id,
                                "chunk_id": chunk_id,
                                "entity_names": entity_names,
                            }
                        ],
                    )

            ids.append(doc_id)

        return ids

    async def build_communities(
        self,
        *,
        resolution: float = 1.0,
        min_size: int = 2,
    ) -> None:
        """Detect communities and generate summaries.

        Should be called after add_documents to enable community-based
        global search. Stores results internally for use during retrieval.

        Args:
            resolution: Higher values produce more, smaller communities.
            min_size: Minimum community size to include.
        """
        from cogent.graph.community import detect_communities, summarize_communities

        self._communities = await detect_communities(
            self._graph,
            resolution=resolution,
            min_size=min_size,
        )

        if self._communities:
            self._communities = await summarize_communities(
                self._communities,
                self._graph,
                self._llm,
            )

    # ------------------------------------------------------------------
    # Retrieval
    # ------------------------------------------------------------------

    async def retrieve_with_scores(
        self,
        query: str,
        k: int = 4,
        filter: dict[str, object] | None = None,
        **kwargs: object,
    ) -> list[RetrievalResult]:
        """Retrieve chunks by running PPR from query entities.

        Steps:
        1. Extract entities from the query via LLM.
        2. Match extracted names to graph nodes (fuzzy).
        3. Run Personalized PageRank from matched seed nodes.
        4. Collect chunks linked to top-scoring graph nodes.
        5. Optionally blend with vector similarity scores.
        """
        # Step 1: extract query entities
        seed_names = await self._extract_query_entities(query)

        # Step 2: match to graph nodes
        seed_nodes = self._resolve_seeds(seed_names)

        if not seed_nodes:
            # Fallback: community-based global search if enabled
            if self._enable_community_search and self._communities:
                return await self._community_retrieve(query, k)
            # Fallback: vector-only if no graph seeds found
            if self._vectorstore:
                return await self._vector_retrieve(query, k)
            return []

        # Step 3: PPR
        try:
            ppr_scores = self._graph.personalized_pagerank(
                seed_entity_ids=seed_nodes,
                alpha=self._alpha,
            )
        except (TypeError, ValueError):
            if self._vectorstore:
                return await self._vector_retrieve(query, k)
            return []

        # Step 4: map PPR scores → chunk scores
        chunk_scores: dict[str, float] = {}
        for entity_id, score in ppr_scores.items():
            entity = await self._graph.storage.get_entity(entity_id)
            if entity is None:
                continue

            chunk_ids = entity.attributes.get("chunk_ids", [])
            if not isinstance(chunk_ids, list):
                continue

            for cid in chunk_ids:
                if cid in self._chunks:
                    # Max-pool: keep highest entity score per chunk
                    chunk_scores[cid] = max(chunk_scores.get(cid, 0.0), score)

        # Step 5: hybrid blending
        if self._vectorstore:
            vector_results = await self._vector_retrieve(query, k * 2)
            vector_map: dict[str, float] = {}
            for vr in vector_results:
                cid = vr.metadata.get("chunk_id", "")
                if cid:
                    vector_map[cid] = vr.score

            # Merge: union of both retrieval sets
            all_chunk_ids = set(chunk_scores) | set(vector_map)
            merged: dict[str, float] = {}
            gw = self._graph_weight
            vw = 1.0 - gw
            for cid in all_chunk_ids:
                g = chunk_scores.get(cid, 0.0)
                v = vector_map.get(cid, 0.0)
                merged[cid] = gw * g + vw * v

            chunk_scores = merged

        # Sort and build results
        ranked = sorted(chunk_scores.items(), key=lambda x: x[1], reverse=True)[:k]

        results: list[RetrievalResult] = []
        for chunk_id, score in ranked:
            if chunk_id not in self._chunks:
                continue

            doc, chunk_text = self._chunks[chunk_id]

            # Build a lightweight document for the chunk
            from cogent.core.document import Document as CoreDoc
            from cogent.core.document import DocumentMetadata

            chunk_meta = DocumentMetadata(id=chunk_id)
            if hasattr(doc, "metadata") and isinstance(doc.metadata, DocumentMetadata):
                chunk_meta = DocumentMetadata(
                    id=chunk_id,
                    source=doc.metadata.source,
                    source_type=doc.metadata.source_type,
                    parent_id=doc.id if hasattr(doc, "id") else None,
                    custom=dict(doc.metadata.custom) if doc.metadata.custom else {},
                )

            chunk_doc = CoreDoc(
                text=chunk_text,
                metadata=chunk_meta,
            )

            results.append(
                RetrievalResult(
                    document=chunk_doc,
                    score=score,
                    retriever_name=self.name,
                    metadata={
                        "retrieval_method": "graph_ppr",
                        "chunk_id": chunk_id,
                        "seed_entities": seed_nodes,
                    },
                )
            )

        return results

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _extract_graph_data(
        self, text: str
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        """Extract entities and relationships from a text chunk."""
        prompt = EXTRACT_ENTITIES_PROMPT.format(text=text[:4000])
        response = await self._llm.generate(prompt)

        try:
            data = json.loads(response)
            return data.get("entities", []), data.get("relationships", [])
        except json.JSONDecodeError:
            return [], []

    async def _extract_query_entities(self, query: str) -> list[str]:
        """Extract entity names from a user query."""
        prompt = EXTRACT_QUERY_ENTITIES_PROMPT.format(query=query)
        response = await self._llm.generate(prompt)

        try:
            names = json.loads(response)
            if isinstance(names, list):
                return [str(n) for n in names]
        except json.JSONDecodeError:
            pass

        return []

    def _resolve_seeds(self, names: list[str]) -> list[str]:
        """Match extracted entity names to actual graph node IDs.

        Uses case-insensitive substring matching as a lightweight
        fuzzy resolution strategy.
        """
        if not names:
            return []

        # Build a lowercase lookup from existing graph nodes
        # Engine nodes are the source of truth
        try:
            all_nodes = list(self._graph.engine._nodes.keys())
        except AttributeError:
            try:
                all_nodes = list(self._graph.engine.graph.nodes())
            except AttributeError:
                return []

        node_lower = {nid.lower(): nid for nid in all_nodes}

        matched: list[str] = []
        for name in names:
            key = name.lower()
            # Exact match first
            if key in node_lower:
                matched.append(node_lower[key])
                continue

            # Substring match (query entity contained in node, or vice versa)
            for nlow, nid in node_lower.items():
                if key in nlow or nlow in key:
                    matched.append(nid)
                    break

        return matched

    async def _community_retrieve(self, query: str, k: int) -> list[RetrievalResult]:
        """Global search using community summaries."""
        from cogent.graph.community import query_communities

        if not self._communities:
            return []

        pairs = await query_communities(
            query,
            self._communities,
            self._llm,
            top_k=k,
        )

        results: list[RetrievalResult] = []
        for community, partial_answer in pairs:
            from cogent.core.document import Document as CoreDoc
            from cogent.core.document import DocumentMetadata

            doc = CoreDoc(
                text=partial_answer,
                metadata=DocumentMetadata(
                    id=community.id,
                    custom={
                        "community_entities": community.entity_ids[:10],
                        "community_summary": community.summary or "",
                    },
                ),
            )
            results.append(
                RetrievalResult(
                    document=doc,
                    score=1.0 / (len(results) + 1),  # rank-based score
                    retriever_name=self.name,
                    metadata={
                        "retrieval_method": "community_global",
                        "community_id": community.id,
                    },
                )
            )

        return results

    async def _vector_retrieve(self, query: str, k: int) -> list[RetrievalResult]:
        """Fallback: pure vector retrieval."""
        if not self._vectorstore:
            return []

        search_results = await self._vectorstore.search(query, k=k)
        results: list[RetrievalResult] = []
        for sr in search_results:
            results.append(
                RetrievalResult(
                    document=sr.document,
                    score=sr.score,
                    retriever_name=self.name,
                    metadata={
                        "retrieval_method": "vector_fallback",
                        **sr.document.metadata,
                    },
                )
            )
        return results

    def _chunk_text(self, text: str) -> list[str]:
        """Split text into chunks at sentence/paragraph boundaries."""
        chunks: list[str] = []
        start = 0

        while start < len(text):
            end = start + self._chunk_size
            chunk = text[start:end]

            if end < len(text):
                for sep in ["\n\n", ". ", ".\n"]:
                    last_sep = chunk.rfind(sep)
                    if last_sep > self._chunk_size // 2:
                        chunk = chunk[: last_sep + len(sep)]
                        break

            stripped = chunk.strip()
            if stripped:
                chunks.append(stripped)

            start += len(chunk)

        return chunks
