# Structured Output Examples

Dedicated examples for Cogent's structured output system.

## Examples

| File | What it covers |
|------|---------------|
| [`schema_types.py`](schema_types.py) | All 11 supported schema types: Pydantic, dataclass, TypedDict, JSON Schema, primitives, Literal, collections, Union, Enum, None, dict |
| [`field_guidance.py`](field_guidance.py) | Steering LLM output with `Field(description=...)`, `Field(examples=[...])`, and constraints (`ge`, `le`, `min_length`, `max_length`) |
| [`few_shot_examples.py`](few_shot_examples.py) | Model-level few-shot examples via `model_config = ConfigDict(json_schema_extra={"examples": [...]})` |
| [`advanced_patterns.py`](advanced_patterns.py) | `ResponseSchema` config, nested models, reusing schemas, extracting lists |

## Key Concepts

### Field Guidance Flows Automatically

Pydantic `Field` metadata becomes part of the JSON schema that the model sees. No extra configuration needed:

```python
class Report(BaseModel):
    title: str = Field(
        description="Concise 5-8 word title",
        examples=["Q4 Revenue Exceeded Targets"],
    )
    score: int = Field(
        description="Overall quality rating",
        ge=1, le=10,
        examples=[8, 4],
    )
```

The generated JSON schema includes `"description"`, `"examples"`, `"minimum"`, `"maximum"` — the model uses all of it.

### Model-Level Examples

For full few-shot output examples, use `model_config`:

```python
class Note(BaseModel):
    model_config = ConfigDict(json_schema_extra={
        "examples": [
            {"category": "added", "title": "Streaming support", "breaking": False},
            {"category": "fixed", "title": "Memory leak in tool loop", "breaking": False},
        ]
    })
    category: str
    title: str
    breaking: bool
```

### Schema Passed at Run Time

Structured output schemas are passed per-call via `returns=`:

```python
agent = Agent(name="Helper", model="gpt-5.4", instructions="...")
result = await agent.run("Analyze this text", returns=MyModel)
result.content.data  # → MyModel instance
```

## Run

```bash
uv run python examples/structured_output/schema_types.py
uv run python examples/structured_output/field_guidance.py
uv run python examples/structured_output/few_shot_examples.py
uv run python examples/structured_output/advanced_patterns.py
```
