"""SONAR Intelligence MCP Server.

Exposes SONAR's KYB due diligence, competitive intelligence, strategic
accounts research, and adverse media screening tools to MCP-compatible
AI clients (Claude Desktop, Claude Code, Cursor, etc.).

Two transports from one codebase:

  - **stdio** (default, for local install) — ``python -m getsonar_mcp`` or
    ``uvx getsonar-mcp``. Each customer runs the server locally, configures
    their API key via the ``SONAR_API_KEY`` env var, and adds the command
    to their MCP client config. No infrastructure required.

  - **streamable-http** (remote/hosted) — ``python -m getsonar_mcp.http_server``
    starts an HTTP MCP endpoint suitable for Render / Cloud Run. Customers
    paste a single URL into their MCP client config; OAuth handles auth.
    See ``http_server.py`` and ``oauth.py`` for the deployment story.
"""

__version__ = "0.1.9"
