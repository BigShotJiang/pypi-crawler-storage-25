# veyra-python

[![PyPI](https://img.shields.io/pypi/v/veyra.svg)](https://pypi.org/project/veyra/)
[![Python Versions](https://img.shields.io/pypi/pyversions/veyra.svg)](https://pypi.org/project/veyra/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![CI](https://img.shields.io/badge/ci-passing-brightgreen.svg)](#)

The official Veyra Python SDK: sync + async clients, typed models, streaming, pagination, retries, and rich API exceptions.

## Installation

```bash
pip install veyra
```

## Quickstart (Sync)

```python
import veyra

client = veyra.Veyra()
completion = client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Hello!"}],
    reasoning={"effort": "low"},
)
print(completion.choices[0].message.content)
```

## Quickstart (Async)

```python
import asyncio
import veyra

async def main() -> None:
    async with veyra.AsyncVeyra() as client:
        completion = await client.chat.completions.create(
            model="gpt-5.4-mini",
            messages=[{"role": "user", "content": "Hello from async"}],
        )
        print(completion.choices[0].message.content)

asyncio.run(main())
```

## Authentication

Set environment variable:

```bash
export VEYRA_API_KEY="veyra_sk_..."
```

Or pass explicitly:

```python
client = veyra.Veyra(api_key="veyra_sk_...")
```

## Resources at a glance

| Namespace | Method |
|---|---|
| `client.chat.completions` | `create(...)` |
| `client.completions` | `create(...)` |
| `client.responses` | `create(...)` |
| `client.embeddings` | `create(...)` |
| `client.images.generations` | `create(...)` |
| `client.audio.transcriptions` | `create(...)` |
| `client.models` | `list()`, `retrieve(id)` |
| `client.quota` | `status()`, `list_plans()`, `list_public_plans()` |
| `client.billing.usage` | `list()`, `daily_summary()`, `monthly_summary()`, `conversation_summary(id)` |
| `client.billing.profile` | `retrieve()`, `upsert(...)`, `access()` |
| `client.api_keys` | `create(...)`, `list()`, `update(...)`, `revoke(...)` |
| `client.assistant` | `chat(...)` |
| `client.health` | `check()`, `ready()` |

## Streaming

```python
import veyra

client = veyra.Veyra()
with client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Count to 3"}],
    stream=True,
) as stream:
    for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="")
```

## Responses reasoning

```python
response = client.responses.create(
    model="gpt-5.4-mini",
    input="Summarize the tradeoff in one sentence.",
    reasoning={"effort": "medium", "summary": "auto"},
    max_output_tokens=128,
)
print(response.output[0].content[0].text)
```

## Error handling

```python
import veyra

client = veyra.Veyra()
try:
    client.chat.completions.create(
        model="gpt-5.4-mini",
        messages=[{"role": "user", "content": "Hello"}],
    )
except veyra.RateLimitError as exc:
    print("Retry after:", exc.retry_after)
except veyra.APIError as exc:
    print(exc.status_code, exc.code, exc)
```

## Pagination

```python
for record in client.billing.usage.list(limit=100):
    print(record.model, record.total_tokens)
```

## Retries and timeouts

```python
client = veyra.Veyra(max_retries=4, timeout=30)
client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Hello"}],
    timeout=10,
)
```

## Raw responses

```python
raw = client.with_raw_response.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Hi"}],
)
print(raw.request_id)
print(raw.http_status)
```

## Async streaming

```python
import asyncio
import veyra

async def main() -> None:
    async with veyra.AsyncVeyra() as client:
        stream = await client.chat.completions.create(
            model="gpt-5.4-mini",
            messages=[{"role": "user", "content": "Count to 3"}],
            stream=True,
        )
        async with stream:
            async for chunk in stream:
                print(chunk.choices[0].delta.content or "", end="")

asyncio.run(main())
```

Full docs: `docs/`
