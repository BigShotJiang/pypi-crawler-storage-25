# Release Process

## Current Release

- Version: `1.0.1`
- Tag: `v1.0.1`
- Package version source: `veyra/_version.py`
- Validation target: `ruff check veyra tests scripts`, `mypy veyra`, `pytest`

## 1.0.1 Release Notes

This release updates the SDK for the current Veyra backend API surface:

- reasoning and passthrough request fields for chat completions and responses.
- flexible response parsing for reasoning output and nullable response content.
- conversation-level billing usage summaries.
- comprehensive API reference and usage documentation.
- expanded regression tests across serialization, streaming, parsing, raw response metadata, and multipart uploads.

## Prerequisites

- Clean working tree.
- Passing CI on the target branch.
- Updated `CHANGELOG.md`.

## 1. Prepare Version

Update version in:

- `veyra/_version.py`

Confirm build metadata and package config are consistent.

## 2. Validate Locally

```bash
ruff check veyra tests scripts
mypy veyra
pytest
python -m build
```

## 3. Commit Release Changes

```bash
git add -A
git commit -m "release: vX.Y.Z"
```

## 4. Tag

```bash
git tag -a vX.Y.Z -m "release: vX.Y.Z"
```

## 5. Push

```bash
git push origin <branch>
git push origin vX.Y.Z
```

Pushing the tag triggers the release workflow and package publishing flow.
