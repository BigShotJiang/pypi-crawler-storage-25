from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any

import httpx
import pytest

from veyra import AsyncVeyra, Veyra


@dataclass
class _RecordedRoute:
    responses: deque[httpx.Response]
    calls: int = 0
    last_request: httpx.Request | None = None


class MockRouter:
    def __init__(self, base_url: str = "https://api.veyra.ai") -> None:
        self.base_url = base_url
        self._routes: dict[tuple[str, str], _RecordedRoute] = {}
        self._default = httpx.Response(
            404, json={"error": {"code": "not_found", "message": "No mock"}}
        )
        self.transport = httpx.MockTransport(self._handler)
        self.async_transport = self.transport

    def add(
        self,
        method: str,
        path: str,
        *,
        status_code: int = 200,
        json_body: Any | None = None,
        headers: dict[str, str] | None = None,
        text: str | None = None,
        repeat: int = 1,
    ) -> None:
        request = httpx.Request(method.upper(), self.base_url + path)
        responses: deque[httpx.Response] = deque()
        for _ in range(repeat):
            if json_body is not None:
                responses.append(
                    httpx.Response(status_code, json=json_body, headers=headers, request=request)
                )
            elif text is not None:
                responses.append(
                    httpx.Response(status_code, text=text, headers=headers, request=request)
                )
            else:
                responses.append(httpx.Response(status_code, headers=headers, request=request))

        self._routes[(method.upper(), path)] = _RecordedRoute(responses=responses)

    def add_sequence(
        self,
        method: str,
        path: str,
        sequence: list[tuple[int, Any]],
    ) -> None:
        responses: deque[httpx.Response] = deque()
        for status, payload in sequence:
            request = httpx.Request(method.upper(), self.base_url + path)
            responses.append(httpx.Response(status, json=payload, request=request))
        self._routes[(method.upper(), path)] = _RecordedRoute(responses=responses)

    def call_count(self, method: str, path: str) -> int:
        route = self._routes.get((method.upper(), path))
        if route is None:
            return 0
        return route.calls

    def last_request(self, method: str, path: str) -> httpx.Request:
        route = self._routes[(method.upper(), path)]
        assert route.last_request is not None
        return route.last_request

    def _handler(self, request: httpx.Request) -> httpx.Response:
        key = (request.method.upper(), request.url.path)
        route = self._routes.get(key)
        if route is None:
            return self._default

        route.calls += 1
        route.last_request = request

        if not route.responses:
            return self._default

        response = route.responses.popleft() if len(route.responses) > 1 else route.responses[0]

        return httpx.Response(
            response.status_code,
            headers=response.headers,
            content=response.content,
            request=request,
        )


@pytest.fixture
def respx_mock() -> MockRouter:
    return MockRouter()


@pytest.fixture
def sync_client(respx_mock: MockRouter) -> Veyra:
    client = Veyra(api_key="veyra_sk_test_fixture", http_client=respx_mock.transport)
    yield client
    client.close()


@pytest.fixture
async def async_client(respx_mock: MockRouter) -> AsyncVeyra:
    client = AsyncVeyra(api_key="veyra_sk_test_fixture", http_client=respx_mock.async_transport)
    yield client
    await client.aclose()
