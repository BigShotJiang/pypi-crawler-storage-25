from __future__ import annotations

import pytest

from tests.integration._helpers import assert_auth_headers, request_json
from veyra import ModelNotAvailableError


def test_chat_create_success_with_retry(sync_client, respx_mock) -> None:
    success = {
        "id": "chatcmpl-1",
        "object": "chat.completion",
        "created": 1,
        "model": "gpt-5.4-mini",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "hello"},
                "finish_reason": "stop",
            }
        ],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
    }
    respx_mock.add_sequence(
        "POST",
        "/v1/chat/completions",
        [
            (503, {"error": {"code": "provider_unavailable", "message": "down"}}),
            (503, {"error": {"code": "provider_unavailable", "message": "down"}}),
            (200, success),
        ],
    )

    completion = sync_client.chat.completions.create(
        model="gpt-5.4-mini",
        messages=[{"role": "user", "content": "hi"}],
    )

    assert completion.id == "chatcmpl-1"
    assert respx_mock.call_count("POST", "/v1/chat/completions") == 3

    req = respx_mock.last_request("POST", "/v1/chat/completions")
    assert_auth_headers(req)
    body = request_json(req)
    assert body["model"] == "gpt-5.4-mini"


def test_chat_create_forwards_reasoning_and_extra_fields(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/chat/completions",
        json_body={
            "id": "chatcmpl-2",
            "object": "chat.completion",
            "created": 1,
            "model": "gpt-5.4-mini",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "ok"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {
                "prompt_tokens": 1,
                "prompt_tokens_details": {"cached_tokens": 0},
                "completion_tokens": 2,
                "completion_tokens_details": {"reasoning_tokens": 1},
                "total_tokens": 3,
            },
        },
    )

    completion = sync_client.chat.completions.create(
        model="gpt-5.4-mini",
        messages=[{"role": "developer", "content": "Be brief"}, {"role": "user", "content": "hi"}],
        reasoning={"effort": "low", "summary": "auto"},
        response_format={"type": "json_object"},
        parallel_tool_calls=False,
        truncation="auto",
        metadata={"conversation_id": "conv_1"},
        tools=[{"type": "function", "function": {"name": "lookup"}}],
        tool_choice="auto",
        extra_body={"service_tier": "default"},
    )

    assert completion.usage is not None
    assert completion.usage.completion_tokens_details == {"reasoning_tokens": 1}

    req = respx_mock.last_request("POST", "/v1/chat/completions")
    body = request_json(req)
    assert body["reasoning"] == {"effort": "low", "summary": "auto"}
    assert body["response_format"] == {"type": "json_object"}
    assert body["parallel_tool_calls"] is False
    assert body["truncation"] == "auto"
    assert body["metadata"] == {"conversation_id": "conv_1"}
    assert body["tools"] == [{"type": "function", "function": {"name": "lookup"}}]
    assert body["service_tier"] == "default"


def test_chat_create_error_mapping(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/chat/completions",
        status_code=403,
        json_body={"error": {"code": "model_not_available", "message": "blocked"}},
    )

    with pytest.raises(ModelNotAvailableError):
        sync_client.chat.completions.create(
            model="gpt-5.4-mini",
            messages=[{"role": "user", "content": "hi"}],
        )
