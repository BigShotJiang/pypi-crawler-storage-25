from __future__ import annotations

import io


def test_audio_transcription_create(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/audio/transcriptions",
        json_body={"text": "transcribed text"},
    )

    fh = io.BytesIO(b"audio-bytes")
    response = sync_client.audio.transcriptions.create(file=fh, model="whisper-1")
    assert response.text == "transcribed text"

    request = respx_mock.last_request("POST", "/v1/audio/transcriptions")
    assert request.headers["Content-Type"].startswith("multipart/form-data")
