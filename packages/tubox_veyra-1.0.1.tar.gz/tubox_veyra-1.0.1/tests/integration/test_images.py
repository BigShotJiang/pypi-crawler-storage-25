from __future__ import annotations

import pytest

from veyra import VeyraError


def test_images_create(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/images/generations",
        json_body={
            "created": 1,
            "data": [
                {"url": "https://example.com/img.png", "b64_json": None, "revised_prompt": None}
            ],
        },
    )

    response = sync_client.images.generations.create(model="gpt-image-2", prompt="logo")
    assert response.data[0].url == "https://example.com/img.png"


def test_images_validation(sync_client) -> None:
    with pytest.raises(VeyraError):
        sync_client.images.generations.create(model="gpt-image-2", prompt="logo", n=11)
