from __future__ import annotations

import pytest

from veyra import PermissionDeniedError


def test_api_key_crud(sync_client, respx_mock) -> None:
    create_payload = {
        "id": "k1",
        "name": "automation-key",
        "key": "veyra_sk_secret",
        "key_prefix": "veyra_sk_a",
        "scopes": ["chat:read"],
        "created_at": "2026-05-01T00:00:00Z",
    }
    read_payload = {
        "id": "k1",
        "name": "automation-key",
        "key_prefix": "veyra_sk_a",
        "scopes": ["chat:read"],
        "is_active": True,
    }
    respx_mock.add("POST", "/v1/api-keys", json_body=create_payload)
    respx_mock.add("GET", "/v1/api-keys", json_body=[read_payload])
    respx_mock.add("PATCH", "/v1/api-keys/k1", json_body=read_payload)
    respx_mock.add("DELETE", "/v1/api-keys/k1", status_code=200, json_body={"message": "ok"})

    created = sync_client.api_keys.create(name="automation-key", scopes=["chat:read"])
    assert created.id == "k1"
    listed = sync_client.api_keys.list()
    assert listed[0].id == "k1"
    updated = sync_client.api_keys.update("k1", name="automation-key")
    assert updated.name == "automation-key"
    assert sync_client.api_keys.revoke("k1") is None


def test_api_key_error(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/api-keys",
        status_code=403,
        json_body={"error": {"code": "permission_denied", "message": "denied"}},
    )
    with pytest.raises(PermissionDeniedError):
        sync_client.api_keys.create(name="x", scopes=["chat:read"])
