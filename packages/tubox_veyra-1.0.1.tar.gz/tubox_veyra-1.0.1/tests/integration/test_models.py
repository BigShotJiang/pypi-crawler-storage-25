from __future__ import annotations

import pytest

from veyra import NotFoundError


def test_models_list_and_retrieve(sync_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/models",
        json_body={
            "object": "list",
            "data": [{"id": "gpt-5.4-mini", "object": "model", "created": 0, "owned_by": "veyra"}],
        },
    )
    respx_mock.add(
        "GET",
        "/v1/models/gpt-5.4-mini",
        json_body={"id": "gpt-5.4-mini", "object": "model", "created": 0, "owned_by": "veyra"},
    )

    listing = sync_client.models.list()
    assert listing.data[0].id == "gpt-5.4-mini"

    model = sync_client.models.retrieve("gpt-5.4-mini")
    assert model.owned_by == "veyra"


def test_models_retrieve_not_found(sync_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/models/missing",
        status_code=404,
        json_body={"error": {"code": "model_not_found", "message": "missing"}},
    )
    with pytest.raises(NotFoundError):
        sync_client.models.retrieve("missing")
