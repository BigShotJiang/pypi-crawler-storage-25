from __future__ import annotations

import json

import httpx


def request_json(request: httpx.Request) -> dict[str, object]:
    if not request.content:
        return {}
    return json.loads(request.content.decode("utf-8"))


def assert_auth_headers(request: httpx.Request) -> None:
    assert request.headers["Authorization"] == "Bearer veyra_sk_test_fixture"
    assert request.headers["User-Agent"].startswith("veyra-python/")
