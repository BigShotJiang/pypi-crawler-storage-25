from __future__ import annotations


def test_health_endpoints(sync_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/health",
        json_body={"status": "healthy", "app": "Veyra", "version": "1.0.0", "environment": "test"},
    )
    respx_mock.add(
        "GET",
        "/health/ready",
        json_body={"status": "ready", "checks": {"database": "ok", "redis": "ok"}},
    )

    assert sync_client.health.check().status == "healthy"
    assert sync_client.health.ready().status == "ready"
