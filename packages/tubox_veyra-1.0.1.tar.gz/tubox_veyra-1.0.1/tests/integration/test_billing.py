from __future__ import annotations

import pytest

from veyra import InternalServerError


def test_billing_usage_and_profile(sync_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/billing/usage",
        json_body=[
            {
                "id": "u1",
                "created_at": "2026-05-01T00:00:00Z",
                "model": "gpt-5.4-mini",
                "prompt_tokens": 1,
                "completion_tokens": 2,
                "total_tokens": 3,
                "status_code": 200,
            }
        ],
        headers={"X-Total-Count": "1"},
    )
    respx_mock.add(
        "GET",
        "/v1/billing/usage/summary/daily",
        json_body={
            "prompt_tokens": 1,
            "completion_tokens": 1,
            "total_tokens": 2,
            "request_count": 1,
        },
    )
    respx_mock.add(
        "GET",
        "/v1/billing/usage/summary/monthly",
        json_body={
            "prompt_tokens": 2,
            "completion_tokens": 2,
            "total_tokens": 4,
            "request_count": 2,
        },
    )
    respx_mock.add(
        "GET",
        "/v1/billing/usage/conversations/conv_1/summary",
        json_body={
            "prompt_tokens": 10,
            "completion_tokens": 5,
            "total_tokens": 15,
            "cached_tokens": 3,
            "total_cost_usd": 0.012345,
            "request_count": 2,
        },
    )
    profile_payload = {
        "billing_email": "billing@veyra.ai",
        "full_name": "Billing",
        "company_name": "Veyra",
        "country_code": "US",
        "line1": "123 Main",
        "city": "Austin",
        "state_region": "TX",
        "postal_code": "78701",
    }
    respx_mock.add("GET", "/v1/billing/profile", json_body=profile_payload)
    respx_mock.add("PUT", "/v1/billing/profile", json_body=profile_payload)
    respx_mock.add(
        "GET",
        "/v1/billing/access",
        json_body={
            "plan": "free",
            "billing_required": True,
            "can_use_models": False,
            "reason": "add billing",
        },
    )

    page = sync_client.billing.usage.list(limit=50)
    assert len(list(page)) == 1
    assert sync_client.billing.usage.daily_summary().request_count == 1
    assert sync_client.billing.usage.monthly_summary().total_tokens == 4
    conversation = sync_client.billing.usage.conversation_summary("conv_1")
    assert conversation.cached_tokens == 3
    assert conversation.total_cost_usd == 0.012345
    assert sync_client.billing.profile.retrieve() is not None
    assert (
        sync_client.billing.profile.upsert(
            billing_email="billing@veyra.ai",
            full_name="Billing",
            country_code="US",
            line1="123 Main",
            city="Austin",
            state_region="TX",
            postal_code="78701",
        ).billing_email
        == "billing@veyra.ai"
    )
    assert sync_client.billing.profile.access().plan == "free"


def test_billing_error(sync_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/billing/usage/summary/daily",
        status_code=500,
        json_body={"error": {"code": "internal_error", "message": "oops"}},
    )
    with pytest.raises(InternalServerError):
        sync_client.billing.usage.daily_summary()
