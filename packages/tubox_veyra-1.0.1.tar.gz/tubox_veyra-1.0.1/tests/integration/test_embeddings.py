from __future__ import annotations

import pytest

from veyra import VeyraError


def test_embeddings_create(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/embeddings",
        json_body={
            "object": "list",
            "data": [{"object": "embedding", "embedding": [0.1, 0.2], "index": 0}],
            "model": "text-embedding-3-small",
            "usage": {"prompt_tokens": 2, "completion_tokens": 0, "total_tokens": 2},
        },
    )

    response = sync_client.embeddings.create(model="text-embedding-3-small", input="hello")
    assert response.data[0].index == 0


def test_embeddings_validation(sync_client) -> None:
    with pytest.raises(VeyraError):
        sync_client.embeddings.create(model="text-embedding-3-small", input=[])
