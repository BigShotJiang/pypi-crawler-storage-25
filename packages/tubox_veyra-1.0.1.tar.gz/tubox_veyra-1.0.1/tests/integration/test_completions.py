from __future__ import annotations

import pytest

from tests.integration._helpers import request_json
from veyra import AuthenticationError, VeyraError


def test_legacy_completions_create(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/completions",
        json_body={
            "id": "c-1",
            "object": "text_completion",
            "created": 1,
            "model": "gpt-5.4-mini",
            "choices": [{"text": "hi", "index": 0, "logprobs": None, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        },
    )

    completion = sync_client.completions.create(model="gpt-5.4-mini", prompt="hello")
    assert completion.choices[0].text == "hi"

    req = respx_mock.last_request("POST", "/v1/completions")
    assert request_json(req)["prompt"] == "hello"


def test_legacy_multi_prompt_raises(sync_client) -> None:
    with pytest.raises(VeyraError):
        sync_client.completions.create(model="gpt-5.4-mini", prompt=["a", "b"])


def test_legacy_error_mapping(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/completions",
        status_code=401,
        json_body={"error": {"code": "invalid_api_key", "message": "bad key"}},
    )
    with pytest.raises(AuthenticationError):
        sync_client.completions.create(model="gpt-5.4-mini", prompt="hello")
