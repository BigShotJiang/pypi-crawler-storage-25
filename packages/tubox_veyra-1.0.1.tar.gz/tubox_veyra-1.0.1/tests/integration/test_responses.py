from __future__ import annotations

import pytest

from tests.integration._helpers import request_json
from veyra import RateLimitError


def test_responses_create(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/responses",
        json_body={
            "id": "resp_1",
            "object": "response",
            "created_at": 1,
            "model": "gpt-5.4-mini",
            "output": [
                {
                    "id": "msg_1",
                    "type": "message",
                    "status": "completed",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "ok", "annotations": []}],
                }
            ],
            "status": "completed",
            "usage": {
                "input_tokens": 1,
                "input_tokens_details": {"cached_tokens": 0},
                "output_tokens": 1,
                "output_tokens_details": {"reasoning_tokens": 0},
                "total_tokens": 2,
            },
        },
    )
    response = sync_client.responses.create(model="gpt-5.4-mini", input="hello")
    assert response.id == "resp_1"


def test_responses_reasoning_request_and_output_shapes(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/responses",
        json_body={
            "id": "resp_reasoning",
            "object": "response",
            "created_at": 1,
            "model": "gpt-5.4-mini",
            "reasoning": {"effort": "medium", "summary": "auto"},
            "output": [
                {
                    "id": "rs_1",
                    "type": "reasoning",
                    "status": "completed",
                    "content": None,
                },
                {
                    "id": "msg_1",
                    "type": "message",
                    "status": "completed",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "ok", "annotations": []}],
                },
            ],
            "status": "completed",
            "usage": {
                "input_tokens": 10,
                "input_tokens_details": {"cached_tokens": 1},
                "output_tokens": 5,
                "output_tokens_details": {"reasoning_tokens": 2},
                "total_tokens": 15,
            },
        },
    )

    response = sync_client.responses.create(
        model="gpt-5.4-mini",
        input="solve",
        instructions="Show only the answer.",
        reasoning={"effort": "medium", "summary": "auto"},
        parallel_tool_calls=False,
        truncation="auto",
        include=["reasoning.encrypted_content"],
        store=False,
        metadata={"conversation_id": "conv_1"},
        extra_body={"service_tier": "default"},
    )

    assert response.reasoning == {"effort": "medium", "summary": "auto"}
    assert response.output[0].content == []
    assert response.output[1].content[0].type == "output_text"
    assert response.usage is not None
    assert response.usage.output_tokens_details is not None
    assert response.usage.output_tokens_details.reasoning_tokens == 2

    req = respx_mock.last_request("POST", "/v1/responses")
    body = request_json(req)
    assert body["reasoning"] == {"effort": "medium", "summary": "auto"}
    assert body["parallel_tool_calls"] is False
    assert body["truncation"] == "auto"
    assert body["include"] == ["reasoning.encrypted_content"]
    assert body["store"] is False
    assert body["metadata"] == {"conversation_id": "conv_1"}
    assert body["service_tier"] == "default"


def test_responses_error(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/responses",
        status_code=429,
        json_body={"error": {"code": "rate_limited", "message": "wait"}},
        headers={"Retry-After": "2"},
    )
    with pytest.raises(RateLimitError):
        sync_client.responses.create(model="gpt-5.4-mini", input="hello")
