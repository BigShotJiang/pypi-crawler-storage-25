from __future__ import annotations

from io import BytesIO

from tests.integration._helpers import assert_auth_headers, request_json


def test_completions_extra_body_and_single_prompt_list(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/completions",
        json_body={
            "id": "c-1",
            "object": "text_completion",
            "created": 1,
            "model": "gpt-5.4-mini",
            "choices": [{"text": "ok", "index": 0, "logprobs": None, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        },
    )

    sync_client.completions.create(
        model="gpt-5.4-mini",
        prompt=["hello"],
        max_tokens=8,
        extra_body={"suffix": "ignored-by-backend-if-unsupported"},
    )

    body = request_json(respx_mock.last_request("POST", "/v1/completions"))
    assert body["prompt"] == "hello"
    assert body["max_tokens"] == 8
    assert body["suffix"] == "ignored-by-backend-if-unsupported"


def test_embeddings_serializes_list_input_and_encoding(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/embeddings",
        json_body={
            "object": "list",
            "data": [
                {"object": "embedding", "embedding": [0.1], "index": 0},
                {"object": "embedding", "embedding": [0.2], "index": 1},
            ],
            "model": "text-embedding-3-small",
            "usage": {"prompt_tokens": 2, "completion_tokens": 0, "total_tokens": 2},
        },
    )

    sync_client.embeddings.create(
        model="text-embedding-3-small",
        input=["alpha", "beta"],
        encoding_format="base64",
    )

    body = request_json(respx_mock.last_request("POST", "/v1/embeddings"))
    assert body == {
        "model": "text-embedding-3-small",
        "input": ["alpha", "beta"],
        "encoding_format": "base64",
    }


def test_images_forwards_generation_options(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/images/generations",
        json_body={"created": 1, "data": [{"b64_json": "abc"}]},
    )

    sync_client.images.generations.create(
        model="gpt-image-2",
        prompt="logo",
        n=2,
        size="1792x1024",
        quality="hd",
        response_format="b64_json",
    )

    body = request_json(respx_mock.last_request("POST", "/v1/images/generations"))
    assert body == {
        "model": "gpt-image-2",
        "prompt": "logo",
        "n": 2,
        "size": "1792x1024",
        "quality": "hd",
        "response_format": "b64_json",
    }


def test_api_keys_update_serializes_all_mutable_fields(sync_client, respx_mock) -> None:
    respx_mock.add(
        "PATCH",
        "/v1/api-keys/k1",
        json_body={
            "id": "k1",
            "name": "renamed",
            "key_prefix": "veyra_sk_a",
            "scopes": ["chat:read", "chat:write"],
            "ip_whitelist": ["203.0.113.0/24"],
            "rate_limit_override": 100,
            "is_active": True,
        },
    )

    sync_client.api_keys.update(
        "k1",
        name="renamed",
        scopes=["chat:read", "chat:write"],
        ip_whitelist=["203.0.113.0/24"],
        rate_limit_override=100,
        expires_in_days=60,
    )

    body = request_json(respx_mock.last_request("PATCH", "/v1/api-keys/k1"))
    assert body == {
        "name": "renamed",
        "scopes": ["chat:read", "chat:write"],
        "ip_whitelist": ["203.0.113.0/24"],
        "rate_limit_override": 100,
        "expires_in_days": 60,
    }


def test_audio_transcription_uses_multipart_form(sync_client, respx_mock) -> None:
    respx_mock.add("POST", "/v1/audio/transcriptions", json_body={"text": "hello"})

    transcript = sync_client.audio.transcriptions.create(
        file=("sample.wav", BytesIO(b"RIFF....WAVE"), "audio/wav"),
        model="whisper-1",
        language="en",
    )

    assert transcript.text == "hello"
    request = respx_mock.last_request("POST", "/v1/audio/transcriptions")
    assert_auth_headers(request)
    assert request.headers["content-type"].startswith("multipart/form-data; boundary=")
    assert b'name="model"' in request.content
    assert b"whisper-1" in request.content
    assert b'name="language"' in request.content
    assert b"en" in request.content
    assert b'filename="sample.wav"' in request.content
