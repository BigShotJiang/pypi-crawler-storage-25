from __future__ import annotations


def test_assistant_chat_and_stream(sync_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/assistant/chat",
        json_body={
            "answer": "hello",
            "model": "account-context",
            "references": ["account:model-access"],
            "blocked": False,
            "requires_login": False,
            "scope_limited": False,
        },
    )
    response = sync_client.assistant.chat(message="hi")
    assert response.answer == "hello"

    done_event = (
        '{"type":"done","answer":"hello","model":"account-context","references":[],'
        '"blocked":false,"requires_login":false,"scope_limited":false}'
    )
    stream_payload = "\n".join(
        [
            'data: {"type":"delta","delta":"hel"}',
            'data: {"type":"delta","delta":"lo"}',
            f"data: {done_event}",
            "data: [DONE]",
        ]
    )
    respx_mock.add(
        "POST",
        "/v1/assistant/chat",
        text=stream_payload,
        headers={"Content-Type": "text/event-stream"},
    )

    chunks = []
    with sync_client.assistant.chat(message="hi", stream=True) as stream:
        for chunk in stream:
            chunks.append(chunk)

    assert len(chunks) == 3
