from __future__ import annotations

import pytest

from veyra import RateLimitError


def test_quota_endpoints(sync_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/quota/status",
        json_body={
            "plan": "free",
            "limits": {
                "daily_tokens": 40000,
                "daily_requests": 50,
                "rpm": 10,
                "tpm": 10000,
                "max_context_tokens": 8192,
                "max_output_tokens": 2048,
            },
            "usage": {
                "tokens_used_today": 1,
                "tokens_remaining_today": 39999,
                "requests_used_today": 1,
                "requests_remaining_today": 49,
                "percentage_used": 0.1,
            },
            "resets_at": "2026-05-04T00:00:00+00:00",
            "time_until_reset": "1h",
        },
    )
    respx_mock.add(
        "GET",
        "/v1/quota/plans",
        json_body=[{"name": "free", "description": "Free", "is_active": True}],
    )
    respx_mock.add(
        "GET",
        "/v1/quota/plans/public",
        json_body=[{"name": "free", "description": "Free", "is_active": True}],
    )

    status = sync_client.quota.status()
    assert status.plan == "free"
    assert sync_client.quota.list_plans()[0].name == "free"
    assert sync_client.quota.list_public_plans()[0].name == "free"


def test_quota_error(sync_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/quota/status",
        status_code=429,
        json_body={"error": {"code": "rate_limited", "message": "slow down"}},
        headers={"Retry-After": "5"},
    )

    with pytest.raises(RateLimitError):
        sync_client.quota.status()
