from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_images_create(async_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/images/generations",
        json_body={
            "created": 1,
            "data": [
                {"url": "https://example.com/img.png", "b64_json": None, "revised_prompt": None}
            ],
        },
    )
    response = await async_client.images.generations.create(model="gpt-image-2", prompt="logo")
    assert response.data[0].url == "https://example.com/img.png"
