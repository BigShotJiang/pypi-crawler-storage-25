from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_billing_usage(async_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/billing/usage",
        json_body=[
            {
                "id": "u1",
                "created_at": "2026-05-01T00:00:00Z",
                "model": "gpt-5.4-mini",
                "total_tokens": 3,
            }
        ],
        headers={"X-Total-Count": "1"},
    )
    respx_mock.add(
        "GET",
        "/v1/billing/usage/conversations/conv_1/summary",
        json_body={
            "prompt_tokens": 10,
            "completion_tokens": 5,
            "total_tokens": 15,
            "cached_tokens": 3,
            "total_cost_usd": 0.012345,
            "request_count": 2,
        },
    )
    page = await async_client.billing.usage.list(limit=50)
    items = [item async for item in page]
    assert len(items) == 1
    conversation = await async_client.billing.usage.conversation_summary("conv_1")
    assert conversation.cached_tokens == 3
