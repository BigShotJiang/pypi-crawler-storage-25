from __future__ import annotations

import pytest

from veyra.lib import aio_collect_stream


@pytest.mark.asyncio
async def test_async_chat_streaming(async_client, respx_mock) -> None:
    chunk_one = (
        '{"id":"chatcmpl-1","object":"chat.completion.chunk","created":1,'
        '"model":"gpt-5.4-mini","choices":[{"index":0,"delta":{"role":"assistant",'
        '"content":"Hel"},"finish_reason":null}]}'
    )
    chunk_two = (
        '{"id":"chatcmpl-1","object":"chat.completion.chunk","created":1,'
        '"model":"gpt-5.4-mini","choices":[{"index":0,"delta":{"content":"lo"},'
        '"finish_reason":"stop"}],"usage":{"prompt_tokens":1,"completion_tokens":1,'
        '"total_tokens":2}}'
    )
    stream_body = "\n".join(
        [
            f"data: {chunk_one}",
            f"data: {chunk_two}",
            "data: [DONE]",
        ]
    )
    respx_mock.add(
        "POST",
        "/v1/chat/completions",
        status_code=200,
        text=stream_body,
        headers={"Content-Type": "text/event-stream"},
    )

    stream = await async_client.chat.completions.create(
        model="gpt-5.4-mini",
        messages=[{"role": "user", "content": "hello"}],
        stream=True,
    )
    async with stream:
        completion = await aio_collect_stream(stream)

    assert completion.choices[0].message.content == "Hello"
