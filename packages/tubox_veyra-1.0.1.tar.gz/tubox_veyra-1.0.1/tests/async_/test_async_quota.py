from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_quota(async_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/quota/status",
        json_body={
            "plan": "free",
            "limits": {
                "daily_tokens": 40000,
                "daily_requests": 50,
                "rpm": 10,
                "tpm": 10000,
                "max_context_tokens": 8192,
                "max_output_tokens": 2048,
            },
            "usage": {
                "tokens_used_today": 1,
                "tokens_remaining_today": 39999,
                "requests_used_today": 1,
                "requests_remaining_today": 49,
                "percentage_used": 0.1,
            },
            "resets_at": "2026-05-04T00:00:00+00:00",
            "time_until_reset": "1h",
        },
    )
    status = await async_client.quota.status()
    assert status.plan == "free"
