from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_health(async_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/health",
        json_body={"status": "healthy", "app": "Veyra", "version": "1.0.0", "environment": "test"},
    )
    status = await async_client.health.check()
    assert status.status == "healthy"
