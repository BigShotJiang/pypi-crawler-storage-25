from __future__ import annotations

import io

import pytest


@pytest.mark.asyncio
async def test_async_audio_transcription(async_client, respx_mock) -> None:
    respx_mock.add("POST", "/v1/audio/transcriptions", json_body={"text": "transcribed text"})
    response = await async_client.audio.transcriptions.create(
        file=io.BytesIO(b"audio"), model="whisper-1"
    )
    assert response.text == "transcribed text"
