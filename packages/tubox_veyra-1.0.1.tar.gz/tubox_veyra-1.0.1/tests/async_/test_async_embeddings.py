from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_embeddings_create(async_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/embeddings",
        json_body={
            "object": "list",
            "data": [{"object": "embedding", "embedding": [0.1, 0.2], "index": 0}],
            "model": "text-embedding-3-small",
            "usage": {"prompt_tokens": 2, "completion_tokens": 0, "total_tokens": 2},
        },
    )
    response = await async_client.embeddings.create(model="text-embedding-3-small", input="hello")
    assert response.data[0].index == 0
