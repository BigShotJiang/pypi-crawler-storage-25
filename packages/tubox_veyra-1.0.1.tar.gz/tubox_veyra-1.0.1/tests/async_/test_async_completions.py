from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_legacy_completions(async_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/completions",
        json_body={
            "id": "c-1",
            "object": "text_completion",
            "created": 1,
            "model": "gpt-5.4-mini",
            "choices": [{"text": "hi", "index": 0, "logprobs": None, "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        },
    )
    completion = await async_client.completions.create(model="gpt-5.4-mini", prompt="hello")
    assert completion.choices[0].text == "hi"
