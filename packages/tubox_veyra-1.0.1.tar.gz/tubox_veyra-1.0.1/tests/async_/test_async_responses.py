from __future__ import annotations

import pytest

from tests.integration._helpers import request_json


@pytest.mark.asyncio
async def test_async_responses_create(async_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/responses",
        json_body={
            "id": "resp_1",
            "object": "response",
            "created_at": 1,
            "model": "gpt-5.4-mini",
            "output": [
                {
                    "id": "msg_1",
                    "type": "message",
                    "status": "completed",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "ok", "annotations": []}],
                }
            ],
            "status": "completed",
            "usage": {
                "input_tokens": 1,
                "input_tokens_details": {"cached_tokens": 0},
                "output_tokens": 1,
                "output_tokens_details": {"reasoning_tokens": 0},
                "total_tokens": 2,
            },
        },
    )
    response = await async_client.responses.create(model="gpt-5.4-mini", input="hello")
    assert response.id == "resp_1"


@pytest.mark.asyncio
async def test_async_responses_reasoning(async_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/responses",
        json_body={
            "id": "resp_2",
            "object": "response",
            "created_at": 1,
            "model": "gpt-5.4-mini",
            "output": [],
            "status": "completed",
            "reasoning": {"effort": "low"},
            "usage": {
                "input_tokens": 1,
                "output_tokens": 1,
                "output_tokens_details": {"reasoning_tokens": 1},
                "total_tokens": 2,
            },
        },
    )
    response = await async_client.responses.create(
        model="gpt-5.4-mini",
        input="hello",
        reasoning={"effort": "low"},
        parallel_tool_calls=False,
    )

    assert response.reasoning == {"effort": "low"}
    req = respx_mock.last_request("POST", "/v1/responses")
    body = request_json(req)
    assert body["reasoning"] == {"effort": "low"}
    assert body["parallel_tool_calls"] is False
