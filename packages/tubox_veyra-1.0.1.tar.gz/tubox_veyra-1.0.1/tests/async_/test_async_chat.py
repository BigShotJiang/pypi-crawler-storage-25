from __future__ import annotations

import pytest

from tests.integration._helpers import request_json


@pytest.mark.asyncio
async def test_async_chat_create(async_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/chat/completions",
        json_body={
            "id": "chatcmpl-1",
            "object": "chat.completion",
            "created": 1,
            "model": "gpt-5.4-mini",
            "choices": [
                {
                    "index": 0,
                    "message": {"role": "assistant", "content": "hello"},
                    "finish_reason": "stop",
                }
            ],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2},
        },
    )

    completion = await async_client.chat.completions.create(
        model="gpt-5.4-mini",
        messages=[{"role": "user", "content": "hi"}],
        reasoning={"effort": "low"},
    )
    assert completion.choices[0].message.content == "hello"

    req = respx_mock.last_request("POST", "/v1/chat/completions")
    assert request_json(req)["reasoning"] == {"effort": "low"}
