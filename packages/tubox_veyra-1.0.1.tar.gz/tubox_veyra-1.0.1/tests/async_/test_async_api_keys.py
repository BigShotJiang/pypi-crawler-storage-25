from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_api_keys(async_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/api-keys",
        json_body={
            "id": "k1",
            "name": "automation-key",
            "key": "veyra_sk_secret",
            "key_prefix": "veyra_sk_a",
            "scopes": ["chat:read"],
            "created_at": "2026-05-01T00:00:00Z",
        },
    )
    created = await async_client.api_keys.create(name="automation-key", scopes=["chat:read"])
    assert created.id == "k1"
