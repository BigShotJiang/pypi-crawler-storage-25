from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_models(async_client, respx_mock) -> None:
    respx_mock.add(
        "GET",
        "/v1/models",
        json_body={
            "object": "list",
            "data": [{"id": "gpt-5.4-mini", "object": "model", "created": 0, "owned_by": "veyra"}],
        },
    )
    respx_mock.add(
        "GET",
        "/v1/models/gpt-5.4-mini",
        json_body={"id": "gpt-5.4-mini", "object": "model", "created": 0, "owned_by": "veyra"},
    )
    listing = await async_client.models.list()
    model = await async_client.models.retrieve("gpt-5.4-mini")
    assert listing.data[0].id == model.id
