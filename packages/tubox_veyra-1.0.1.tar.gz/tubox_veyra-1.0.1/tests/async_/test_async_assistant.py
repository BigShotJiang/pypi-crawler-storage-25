from __future__ import annotations

import pytest


@pytest.mark.asyncio
async def test_async_assistant(async_client, respx_mock) -> None:
    respx_mock.add(
        "POST",
        "/v1/assistant/chat",
        json_body={
            "answer": "hello",
            "model": "account-context",
            "references": ["account:model-access"],
            "blocked": False,
            "requires_login": False,
            "scope_limited": False,
        },
    )
    response = await async_client.assistant.chat(message="hi")
    assert response.answer == "hello"
