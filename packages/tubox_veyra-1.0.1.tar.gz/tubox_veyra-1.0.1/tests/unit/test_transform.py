from __future__ import annotations

from pydantic import Field
from typing_extensions import TypedDict

from veyra._utils._transform import strip_none, to_jsonable
from veyra.types._base import VeyraModel


class AliasModel(VeyraModel):
    snake_name: str = Field(alias="snakeName")


class Item(TypedDict):
    role: str
    content: str


def test_strip_none() -> None:
    payload = {"a": 1, "b": None, "c": [{"d": None, "e": 2}]}
    assert strip_none(payload) == {"a": 1, "c": [{"e": 2}]}


def test_list_of_typeddicts_serialized() -> None:
    msgs: list[Item] = [{"role": "user", "content": "hello"}]
    payload = {"messages": msgs}
    assert to_jsonable(payload) == payload


def test_alias_round_trip() -> None:
    model = AliasModel.model_validate({"snakeName": "value"})
    dumped = model.model_dump(by_alias=True)
    assert dumped["snakeName"] == "value"
