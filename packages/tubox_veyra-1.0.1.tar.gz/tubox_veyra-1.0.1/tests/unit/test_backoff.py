from __future__ import annotations

from veyra._utils._backoff import exponential_backoff_with_jitter


def test_delay_grows_with_attempt() -> None:
    a = exponential_backoff_with_jitter(0, jitter=0)
    b = exponential_backoff_with_jitter(1, jitter=0)
    c = exponential_backoff_with_jitter(2, jitter=0)
    assert a < b < c


def test_cap_enforced() -> None:
    value = exponential_backoff_with_jitter(20, base=1, multiplier=2, cap=5, jitter=0)
    assert value == 5


def test_jitter_within_bounds() -> None:
    delay = exponential_backoff_with_jitter(3, base=1, multiplier=2, jitter=0.25, cap=100)
    nominal = 8
    assert nominal * 0.75 <= delay <= nominal * 1.25
