from __future__ import annotations

import httpx

from veyra._exceptions import (
    APIError,
    AuthenticationError,
    BadRequestError,
    BillingRequiredError,
    ConflictError,
    InternalServerError,
    MaintenanceModeError,
    ModelNotAvailableError,
    NotFoundError,
    PayloadTooLargeError,
    PermissionDeniedError,
    ProviderUnavailableError,
    RateLimitError,
    UnprocessableEntityError,
    make_api_error,
)


def _make(status: int, code: str | None) -> APIError:
    request = httpx.Request("GET", "https://api.veyra.ai/v1/test")
    body = {"error": {"code": code, "message": "boom"}}
    response = httpx.Response(status, json=body, request=request)
    return make_api_error(request=request, response=response, body=body)


def test_status_and_code_mapping() -> None:
    assert isinstance(_make(400, "prompt_injection"), BadRequestError)
    assert isinstance(_make(400, "payload_too_large"), PayloadTooLargeError)
    assert isinstance(_make(401, None), AuthenticationError)
    assert isinstance(_make(402, "billing_required"), BillingRequiredError)
    assert isinstance(_make(403, "model_not_available"), ModelNotAvailableError)
    assert isinstance(_make(403, "anything"), PermissionDeniedError)
    assert isinstance(_make(404, None), NotFoundError)
    assert isinstance(_make(409, None), ConflictError)
    assert isinstance(_make(500, None), InternalServerError)
    assert isinstance(_make(502, None), ProviderUnavailableError)
    assert isinstance(_make(503, "maintenance_mode"), MaintenanceModeError)


def test_unprocessable_details() -> None:
    request = httpx.Request("POST", "https://api.veyra.ai/v1/test")
    body = {
        "error": {
            "code": "validation_error",
            "message": "bad",
            "details": [{"loc": ["body", "field"], "msg": "required", "type": "missing"}],
        }
    }
    response = httpx.Response(422, json=body, request=request)
    err = make_api_error(request=request, response=response, body=body)
    assert isinstance(err, UnprocessableEntityError)
    assert err.details[0].loc == ["body", "field"]


def test_rate_limit_retry_after() -> None:
    request = httpx.Request("GET", "https://api.veyra.ai/v1/test")
    body = {"error": {"code": "rate_limited", "message": "too many"}}
    response = httpx.Response(429, json=body, headers={"Retry-After": "3"}, request=request)
    err = make_api_error(request=request, response=response, body=body)
    assert isinstance(err, RateLimitError)
    assert err.retry_after == 3
