from __future__ import annotations

import httpx
import pytest

from veyra import AuthenticationError, ModelNotAvailableError, Veyra


def test_missing_api_key_raises(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("VEYRA_API_KEY", raising=False)
    with pytest.raises(AuthenticationError):
        Veyra(api_key=None)


def test_env_var_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("VEYRA_API_KEY", "veyra_sk_from_env")
    client = Veyra()
    assert client.api_key == "veyra_sk_from_env"
    client.close()


def test_base_url_override() -> None:
    client = Veyra(api_key="veyra_sk_test", base_url="https://example.org")
    assert str(client.base_url) == "https://example.org"
    client.close()


def test_timeout_defaults_and_custom() -> None:
    client = Veyra(api_key="veyra_sk_test")
    assert isinstance(client.timeout, httpx.Timeout)
    assert client.timeout.connect == 5.0
    client.close()

    custom = Veyra(api_key="veyra_sk_test", timeout=12.5)
    assert custom.timeout.read == 12.5
    custom.close()


def test_context_manager_closes_transport() -> None:
    transport = httpx.MockTransport(
        lambda req: httpx.Response(
            200,
            json={
                "status": "healthy",
                "app": "Veyra",
                "version": "1.0.0",
                "environment": "test",
            },
            request=req,
        )
    )
    with Veyra(api_key="veyra_sk_test", http_client=transport) as client:
        response = client.health.check()
        assert response.status == "healthy"


def test_raw_response_proxy_wraps_data_and_resets_mode() -> None:
    calls = 0

    def handler(req: httpx.Request) -> httpx.Response:
        nonlocal calls
        calls += 1
        return httpx.Response(
            200,
            json={
                "status": "healthy",
                "app": "Veyra",
                "version": "1.0.0",
                "environment": "test",
            },
            headers={"X-Request-ID": "req_raw"},
            request=req,
        )

    client = Veyra(api_key="veyra_sk_test", http_client=httpx.MockTransport(handler))
    raw = client.with_raw_response.health.check()
    assert raw.request_id == "req_raw"
    assert raw.http_status == 200
    assert raw.data.status == "healthy"

    normal = client.health.check()
    assert normal.status == "healthy"
    assert not hasattr(normal, "http_status")
    assert calls == 2
    client.close()


def test_raw_response_proxy_resets_mode_after_error() -> None:
    def handler(req: httpx.Request) -> httpx.Response:
        if req.url.path == "/v1/models/bad":
            return httpx.Response(
                403,
                json={"error": {"code": "model_not_available", "message": "blocked"}},
                request=req,
            )
        return httpx.Response(
            200,
            json={
                "status": "healthy",
                "app": "Veyra",
                "version": "1.0.0",
                "environment": "test",
            },
            request=req,
        )

    client = Veyra(api_key="veyra_sk_test", http_client=httpx.MockTransport(handler))
    with pytest.raises(ModelNotAvailableError):
        client.with_raw_response.models.retrieve("bad")

    assert client.health.check().status == "healthy"
    assert client._raw_response_mode is False
    client.close()
