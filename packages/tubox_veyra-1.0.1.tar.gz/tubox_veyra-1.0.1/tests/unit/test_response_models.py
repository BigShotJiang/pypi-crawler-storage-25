from __future__ import annotations

from veyra.types.chat import ChatCompletion
from veyra.types.responses import Response


def test_response_accepts_reasoning_item_with_null_content() -> None:
    response = Response.model_validate(
        {
            "id": "resp_1",
            "object": "response",
            "created_at": 1,
            "model": "gpt-5.4-mini",
            "status": "completed",
            "reasoning": {"effort": "low"},
            "output": [
                {
                    "id": "rs_1",
                    "type": "reasoning",
                    "status": "completed",
                    "content": None,
                },
                {
                    "id": "msg_1",
                    "type": "message",
                    "status": "completed",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "done"}],
                },
            ],
            "usage": {
                "input_tokens": 10,
                "input_tokens_details": {"cached_tokens": 2},
                "output_tokens": 5,
                "output_tokens_details": {"reasoning_tokens": 3},
                "total_tokens": 15,
            },
        }
    )

    assert response.output[0].content == []
    assert response.output[1].content[0].text == "done"
    assert response.usage is not None
    assert response.usage.input_tokens_details is not None
    assert response.usage.input_tokens_details.cached_tokens == 2
    assert response.usage.output_tokens_details is not None
    assert response.usage.output_tokens_details.reasoning_tokens == 3


def test_response_preserves_unknown_output_content_fields() -> None:
    response = Response.model_validate(
        {
            "id": "resp_2",
            "object": "response",
            "created_at": 1,
            "model": "gpt-5.4-mini",
            "output": [
                {
                    "id": "item_1",
                    "type": "custom",
                    "content": [
                        {
                            "type": "reasoning_summary_text",
                            "text": "summary",
                            "encrypted_content": "ciphertext",
                        }
                    ],
                }
            ],
        }
    )

    content = response.output[0].content[0]
    assert content.type == "reasoning_summary_text"
    assert content.text == "summary"
    assert content.model_extra is not None
    assert content.model_extra["encrypted_content"] == "ciphertext"


def test_chat_completion_preserves_reasoning_and_tool_details() -> None:
    completion = ChatCompletion.model_validate(
        {
            "id": "chatcmpl_1",
            "object": "chat.completion",
            "created": 1,
            "model": "gpt-5.4-mini",
            "choices": [
                {
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": None,
                        "tool_calls": [{"id": "call_1", "type": "function"}],
                    },
                    "finish_reason": "tool_calls",
                    "logprobs": {"content": []},
                }
            ],
            "usage": {
                "prompt_tokens": 4,
                "prompt_tokens_details": {"cached_tokens": 1},
                "completion_tokens": 6,
                "completion_tokens_details": {"reasoning_tokens": 2},
                "total_tokens": 10,
            },
        }
    )

    choice = completion.choices[0]
    assert choice.message.tool_calls == [{"id": "call_1", "type": "function"}]
    assert choice.logprobs == {"content": []}
    assert completion.usage is not None
    assert completion.usage.prompt_tokens_details == {"cached_tokens": 1}
    assert completion.usage.completion_tokens_details == {"reasoning_tokens": 2}
