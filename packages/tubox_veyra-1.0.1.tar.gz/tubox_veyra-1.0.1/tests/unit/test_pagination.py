from __future__ import annotations

from veyra._pagination import SyncPage


def test_single_page_iteration() -> None:
    page = SyncPage(
        items=[1, 2],
        total=2,
        offset=0,
        limit=2,
        has_more=False,
        next_offset=None,
        fetcher=lambda _o, _l: None,
    )
    assert list(page) == [1, 2]


def test_multi_page_auto_advance() -> None:
    second = SyncPage(
        items=[3, 4],
        total=4,
        offset=2,
        limit=2,
        has_more=False,
        next_offset=None,
        fetcher=lambda _o, _l: None,
    )
    first = SyncPage(
        items=[1, 2],
        total=4,
        offset=0,
        limit=2,
        has_more=True,
        next_offset=2,
        fetcher=lambda _o, _l: second,
    )
    assert list(first) == [1, 2, 3, 4]


def test_has_more_false_stops_and_len_uses_total() -> None:
    page = SyncPage(
        items=[1],
        total=10,
        offset=0,
        limit=1,
        has_more=False,
        next_offset=None,
        fetcher=lambda _o, _l: None,
    )
    assert list(page) == [1]
    assert len(page) == 10
