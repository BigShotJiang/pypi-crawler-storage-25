from __future__ import annotations

import httpx
import pytest

from veyra._exceptions import APIError, ProviderUnavailableError, StreamConsumedError
from veyra._streaming import AsyncStream, Stream
from veyra.types.chat import ChatCompletionChunk
from veyra.types.responses import ResponseStreamEvent


def _response_from_lines(lines: list[str]) -> httpx.Response:
    request = httpx.Request("GET", "https://api.veyra.ai/v1/chat/completions")
    content = "\n".join(lines).encode("utf-8")
    return httpx.Response(200, request=request, content=content)


def test_stream_skips_empty_and_stops_on_done() -> None:
    chunk = (
        '{"id":"1","object":"chat.completion.chunk","created":1,"model":"m",'
        '"choices":[{"index":0,"delta":{"content":"Hi"},"finish_reason":null}]}'
    )
    response = _response_from_lines(
        [
            "",
            f"data: {chunk}",
            "data: [DONE]",
        ]
    )
    stream = Stream(response=response, cast_to=ChatCompletionChunk, client=object())
    chunks = list(stream)
    assert len(chunks) == 1
    assert chunks[0].choices[0].delta.content == "Hi"


def test_provider_error_chunk_raises() -> None:
    response = _response_from_lines(
        ['data: {"error": {"code": "provider_unavailable", "message": "nope"}}']
    )
    stream = Stream(response=response, cast_to=ChatCompletionChunk, client=object())
    with pytest.raises(ProviderUnavailableError):
        list(stream)


def test_stream_consumed_error_on_second_iteration() -> None:
    chunk = (
        '{"id":"1","object":"chat.completion.chunk","created":1,"model":"m",'
        '"choices":[{"index":0,"delta":{"content":"Hi"},"finish_reason":null}]}'
    )
    response = _response_from_lines(
        [
            f"data: {chunk}",
            "data: [DONE]",
        ]
    )
    stream = Stream(response=response, cast_to=ChatCompletionChunk, client=object())
    list(stream)
    with pytest.raises(StreamConsumedError):
        list(stream)


def test_stream_ignores_empty_choice_keepalive() -> None:
    chunk = (
        '{"id":"2","object":"chat.completion.chunk","created":1,"model":"m",'
        '"choices":[{"index":0,"delta":{"content":"ok"},"finish_reason":"stop"}]}'
    )
    response = _response_from_lines(
        [
            'data: {"object":"","choices":[]}',
            f"data: {chunk}",
            "data: [DONE]",
        ]
    )
    stream = Stream(response=response, cast_to=ChatCompletionChunk, client=object())
    chunks = list(stream)
    assert len(chunks) == 1
    assert chunks[0].choices[0].delta.content == "ok"


def test_stream_decode_error_includes_sdk_code() -> None:
    response = _response_from_lines(["data: {not-json}"])
    stream = Stream(response=response, cast_to=ChatCompletionChunk, client=object())

    with pytest.raises(APIError) as exc_info:
        list(stream)

    assert exc_info.value.code == "stream_decode_error"


def test_stream_non_provider_error_raises_api_error() -> None:
    response = _response_from_lines(
        ['data: {"error": {"code": "quota_exceeded", "message": "quota"}}']
    )
    stream = Stream(response=response, cast_to=ChatCompletionChunk, client=object())

    with pytest.raises(APIError) as exc_info:
        list(stream)

    assert exc_info.value.code == "quota_exceeded"


def test_response_stream_event_parsing() -> None:
    response = _response_from_lines(
        [
            'event: response.output_text.delta',
            'data: {"type":"response.output_text.delta","delta":"Hel"}',
            'data: {"type":"response.output_text.delta","delta":"lo"}',
            "data: [DONE]",
        ]
    )
    stream = Stream(response=response, cast_to=ResponseStreamEvent, client=object())
    assert [event.delta for event in stream] == ["Hel", "lo"]


@pytest.mark.asyncio
async def test_async_stream_consumed_error_on_second_iteration() -> None:
    chunk = (
        '{"id":"1","object":"chat.completion.chunk","created":1,"model":"m",'
        '"choices":[{"index":0,"delta":{"content":"Hi"},"finish_reason":null}]}'
    )
    response = _response_from_lines([f"data: {chunk}", "data: [DONE]"])
    stream = AsyncStream(response=response, cast_to=ChatCompletionChunk, client=object())

    assert [item async for item in stream][0].choices[0].delta.content == "Hi"
    with pytest.raises(StreamConsumedError):
        [item async for item in stream]
