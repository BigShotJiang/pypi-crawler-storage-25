## Summary

Describe the change and why it is needed.

## Changes

- 

## Validation

- [ ] `ruff check veyra tests scripts`
- [ ] `mypy veyra`
- [ ] `pytest`

## Risk / Rollback

Describe risk level and rollback plan if needed.
