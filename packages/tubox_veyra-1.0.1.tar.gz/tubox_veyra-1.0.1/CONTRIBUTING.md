# Contributing Guide

## Development Setup

1. Clone the repository.
2. Create and activate a virtual environment.
3. Install dependencies:

```bash
python -m pip install --upgrade pip
pip install -e ".[dev]"
```

## Run Quality Checks

Run all checks before opening a PR:

```bash
ruff check veyra tests scripts
mypy veyra
pytest
```

## Coding Standards

- Keep public APIs fully typed.
- Add or update tests for behavior changes.
- Keep changes scoped and avoid unrelated refactors.
- Do not commit secrets, credentials, or local environment files.

## Pull Requests

Every PR should include:

- A clear problem statement.
- A concise summary of changes.
- Test coverage for new behavior.
- Notes on any breaking change.

Use small, focused PRs whenever possible.

## Commit Messages

Use clear, imperative commit messages, for example:

- `fix: make type aliases py39-safe for mypy`
- `ci: replace live smoke with offline mock e2e`
