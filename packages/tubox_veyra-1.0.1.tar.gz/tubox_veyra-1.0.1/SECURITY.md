# Security Policy

## Supported Versions

Security updates are provided for the latest stable major line.

| Version | Supported |
| --- | --- |
| 1.x | Yes |
| < 1.0.0 | No |

## Reporting a Vulnerability

Do not open public GitHub issues for security reports.

Report vulnerabilities privately by email:

- `security@veyra.ai`

Include:

- A clear description of the issue.
- Steps to reproduce or a proof of concept.
- Impact assessment and affected versions.
- Any suggested remediation.

We will acknowledge receipt as soon as possible and provide status updates during triage and remediation.
