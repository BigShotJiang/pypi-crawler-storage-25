# Async Usage

Use `AsyncVeyra` with `async with` for clean connection lifecycle.

## Basic Request

```python
import asyncio
import veyra

async def main() -> None:
    async with veyra.AsyncVeyra() as client:
        response = await client.responses.create(
            model="gpt-5.4-mini",
            input="Summarize Veyra in one sentence.",
            reasoning={"effort": "low"},
        )
        print(response.output[0].content[0].text)

asyncio.run(main())
```

## Streaming

```python
import asyncio
import veyra

async def main() -> None:
    async with veyra.AsyncVeyra() as client:
        stream = await client.chat.completions.create(
            model="gpt-5.4-mini",
            messages=[{"role": "user", "content": "Explain async iterators"}],
            stream=True,
        )
        async with stream:
            async for chunk in stream:
                print(chunk.choices[0].delta.content or "", end="")

asyncio.run(main())
```

## Async Pagination

```python
async with veyra.AsyncVeyra() as client:
    page = await client.billing.usage.list(limit=100)
    async for record in page:
        print(record.model, record.total_tokens)
```

## Closing Clients

Use `async with` when possible. If you construct a long-lived client manually, close it with `await client.aclose()`:

```python
client = veyra.AsyncVeyra()
try:
    models = await client.models.list()
finally:
    await client.aclose()
```

## Sync and Async Separation

Do not call sync resources from async request handlers when you expect high concurrency. Use `AsyncVeyra` through the entire async call path.
