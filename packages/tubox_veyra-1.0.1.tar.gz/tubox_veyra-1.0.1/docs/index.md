# Veyra Python SDK

`veyra-python` is the official API-key SDK for Veyra.

## Features

- Sync and async clients (`Veyra`, `AsyncVeyra`)
- Typed request/response models using Pydantic v2
- Streaming support with typed SSE iterators
- Automatic retries with exponential backoff and jitter
- Rich exception hierarchy mapped from API error codes
- Auto-advancing offset pagination helpers

## API Reference

The API reference pages document both the Python SDK surface and the HTTP behavior exposed by the Veyra backend:

- [Chat](api_reference/chat.md): OpenAI-compatible chat completions, streaming, tools, and reasoning passthrough.
- [Responses](api_reference/responses.md): Responses API, reasoning output, flexible output items, and streaming events.
- [Completions](api_reference/completions.md): Legacy text completion compatibility.
- [Embeddings](api_reference/embeddings.md): Text vector generation and validation.
- [Images](api_reference/images.md): Image generation request/response details.
- [Audio](api_reference/audio.md): Audio transcription uploads.
- [Models](api_reference/models.md): Model listing and retrieval.
- [Quota](api_reference/quota.md): Quota status and plan lists.
- [Billing](api_reference/billing.md): Usage records, summaries, profiles, and billing access.
- [API Keys](api_reference/api_keys.md): Key lifecycle management.
- [Assistant](api_reference/assistant.md): Veyra product assistant and streaming assistant events.

For backend operators or contributors who need route-level behavior, see [Backend API Reference](backend-api-reference.md).
