# Authentication

The SDK authenticates every request with a bearer token. For normal SDK usage this is a Veyra API key beginning with `veyra_sk_`.

## Environment Variable

Set `VEYRA_API_KEY` and construct the client without arguments:

```bash
export VEYRA_API_KEY="veyra_sk_..."
```

```python
import veyra

client = veyra.Veyra()
```

## Explicit API Key

Pass the key directly when you need multiple clients or explicit test configuration:

```python
import veyra

client = veyra.Veyra(api_key="veyra_sk_...")
```

## Base URL

By default, the SDK uses the production Veyra API base URL. Override it for staging, local development, or tests:

```python
client = veyra.Veyra(
    api_key="veyra_sk_...",
    base_url="https://staging.example.com",
)
```

You can also set:

```bash
export VEYRA_BASE_URL="https://staging.example.com"
```

## Headers

The SDK sends:

- `Authorization: Bearer <api_key>`
- `User-Agent: veyra-python/<version>`
- `Accept: application/json`
- `Content-Type: application/json` for JSON requests

Multipart upload endpoints remove the JSON content type automatically so `httpx` can set the correct multipart boundary.

## Per-Request Headers

```python
client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Hi"}],
    extra_headers={"X-Request-ID": "req_local_123"},
)
```

## Key Rotation

For key rotation, create a new client with the rotated key and close old client instances:

```python
old_client.close()
client = veyra.Veyra(api_key="veyra_sk_new")
```

## Missing Key Behavior

If no key is provided and `VEYRA_API_KEY` is not set, client construction raises `AuthenticationError` with code `missing_api_key`.
