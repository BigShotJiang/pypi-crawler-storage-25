# Retries and Timeouts

The SDK retries transient failures and lets you configure timeouts globally or per request.

## Defaults

- `max_retries=2`
- total timeout `60s`
- connect timeout `5s`

Retries apply to:

- connection failures
- timeouts
- HTTP `429`
- HTTP `500`, `502`, `503`, `504`

## Client-Level Configuration

```python
client = veyra.Veyra(max_retries=4, timeout=30)
```

You can pass an `httpx.Timeout` for fine-grained control:

```python
import httpx

client = veyra.Veyra(
    timeout=httpx.Timeout(timeout=90.0, connect=10.0),
)
```

## Per-Request Timeout

```python
client.chat.completions.create(..., timeout=10)
```

Per-request timeout does not mutate the client default.

## Backoff

Backoff uses exponential delay with jitter:

`delay = min(base * multiplier**attempt, cap) ± jitter`

If the backend sends `Retry-After`, that value is preferred. Both numeric seconds and HTTP date values are supported.

## Disabling Retries

```python
client = veyra.Veyra(max_retries=0)
```

This is useful in tests or workflows where the caller owns retry orchestration.

## Streaming Requests

Streaming requests use the same connection and initial response retry behavior. Once a stream response has started, individual events are not retried by the SDK.
