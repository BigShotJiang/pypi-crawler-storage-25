# Migration

This SDK follows semver-style compatibility for public Python APIs.

## From 1.0.0 to 1.0.1+

The 1.0.1 line keeps existing calls compatible and expands support for newer backend features:

- `client.responses.create(...)` accepts reasoning and passthrough fields such as `parallel_tool_calls`, `truncation`, `metadata`, `include`, `store`, and `extra_body`.
- `client.chat.completions.create(...)` accepts reasoning, tool, response-format, stream-options, and extra-body passthrough fields.
- `client.completions.create(...)` accepts `extra_body` for compatibility fields.
- Responses output parsing accepts reasoning items, unknown content types, and `content: null`.
- Usage models preserve cached-token and reasoning-token detail fields.
- `client.billing.usage.conversation_summary(conversation_id)` is available.

Existing basic chat, responses, completions, embeddings, images, audio, models, quota, billing, API-key, and assistant calls continue to work.

## Deprecation Policy

Breaking changes will be preceded by a deprecation cycle with `DeprecationWarning` for at least one minor version when practical.

## Recommended New Code

Prefer:

- `client.responses.create(...)` for newer reasoning-capable workflows.
- `client.chat.completions.create(...)` when you need classic chat-completion compatibility.
- `extra_body={...}` only for fields that are not yet typed by the SDK.

## API Key Handling

No migration is needed for authentication. `VEYRA_API_KEY` and explicit `api_key=...` are unchanged.
