# Streaming

All stream-capable endpoints return `Stream[T]` / `AsyncStream[T]` when `stream=True`.

Supported SDK stream resources:

- `client.chat.completions.create(..., stream=True)`
- `client.completions.create(..., stream=True)`
- `client.responses.create(..., stream=True)`
- `client.assistant.chat(..., stream=True)`

Streams parse server-sent events where each event line starts with `data:` and the terminal event is `data: [DONE]`.

## Chat Streaming

```python
import veyra

client = veyra.Veyra()
with client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Count to 5"}],
    stream=True,
) as stream:
    for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="")
```

## Responses Streaming

```python
with client.responses.create(
    model="gpt-5.4-mini",
    input="Write a haiku.",
    stream=True,
) as stream:
    for event in stream:
        if event.type == "response.output_text.delta":
            print(event.delta or event.text or "", end="")
```

## Async Streaming

```python
async with await client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Count to 3"}],
    stream=True,
) as stream:
    async for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="")
```

## Collecting Chat Streams

Use `collect_stream` helpers to reconstruct a final chat completion object from chat chunks:

```python
from veyra.lib.streaming_helpers import collect_stream

with client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Say hello"}],
    stream=True,
) as stream:
    completion = collect_stream(stream)
```

Async:

```python
from veyra.lib.streaming_helpers import aio_collect_stream

async with await client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Say hello"}],
    stream=True,
) as stream:
    completion = await aio_collect_stream(stream)
```

## Error Behavior

If a stream event contains an API error, the iterator raises the mapped SDK exception. A stream can be consumed once; a second iteration raises `StreamConsumedError`.
