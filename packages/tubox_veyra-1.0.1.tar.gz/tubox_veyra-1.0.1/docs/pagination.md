# Pagination

Offset-paginated endpoints return page objects that can be iterated directly or page by page.

## Usage Records

`client.billing.usage.list()` returns `SyncPage[UsageRecord]`.

```python
for record in client.billing.usage.list(limit=100):
    print(record.model, record.total_tokens)
```

Async usage:

```python
page = await client.billing.usage.list(limit=100)
async for record in page:
    print(record.model, record.total_tokens)
```

## Page Metadata

Each page exposes:

- `items`
- `total`
- `offset`
- `limit`
- `has_more`
- `next_offset`

```python
page = client.billing.usage.list(limit=50)
print(page.total, page.has_more, page.next_offset)
```

## Page Boundaries

Use `iter_pages()` to inspect page boundaries explicitly:

```python
for page in client.billing.usage.list(limit=100).iter_pages():
    print("page offset:", page.offset)
    for record in page.items:
        print(record.id)
```

Async page boundaries:

```python
page = await client.billing.usage.list(limit=100)
async for next_page in page.iter_pages():
    print(next_page.offset)
```

## Supported Endpoints

Currently the SDK exposes auto-advancing pagination for billing usage records. Other list endpoints return backend list payloads directly.
