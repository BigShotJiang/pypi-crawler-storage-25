# Images

Image generation creates images from prompts through the OpenAI-compatible Veyra image endpoint.

## Resource

- Sync: `client.images.generations.create(...)`
- Async: `await client.images.generations.create(...)`
- HTTP: `POST /v1/images/generations`
- Auth: API key or session token with `images:write`
- Rate limit class: expensive model request

## Parameters

| Name | Type | Required | Notes |
|---|---:|---:|---|
| `model` | `str` | yes | Image model id, for example `gpt-image-2`. |
| `prompt` | `str` | yes | Image prompt. |
| `n` | `int` | no | Number of images. SDK validates `1..10`. |
| `size` | `str` | no | One of `1024x1024`, `1024x1792`, `1792x1024`. |
| `quality` | `str` | no | `standard` or `hd`. |
| `response_format` | `str` | no | Usually `url` or `b64_json`, depending on backend support. |
| `extra_headers` | `dict[str, str]` | no | Per-request headers. |
| `timeout` | `float | httpx.Timeout` | no | Image generation can be slower; override as needed. |

## Example

```python
result = client.images.generations.create(
    model="gpt-image-2",
    prompt="A minimal geometric logo for a developer tool",
    size="1024x1024",
    quality="standard",
    response_format="url",
)

print(result.data[0].url)
```

## Response Shape

`ImageGenerationResponse` includes:

- `created`
- `data[]`
- `data[].url`
- `data[].b64_json`
- `data[].revised_prompt`

## SDK Validation

The SDK rejects invalid local values before sending:

- `n < 1` or `n > 10`
- unsupported size
- unsupported quality

## Billing and Usage

The backend enforces model access and billing requirements and records usage metadata for successful generation calls.

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `BillingRequiredError`
- `ModelNotAvailableError`
- `PayloadTooLargeError`
- `RateLimitError`
- `ProviderUnavailableError`
- `UnprocessableEntityError`

## Generated Reference

::: veyra.resources.images.generations.Generations

::: veyra.resources.images.generations.AsyncGenerations
