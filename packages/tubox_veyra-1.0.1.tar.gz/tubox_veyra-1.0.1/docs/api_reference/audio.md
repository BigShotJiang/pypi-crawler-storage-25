# Audio

Audio transcription accepts uploaded audio and returns text.

## Resource

- Sync: `client.audio.transcriptions.create(...)`
- Async: `await client.audio.transcriptions.create(...)`
- HTTP: `POST /v1/audio/transcriptions`
- Auth: API key or session token with `audio:write`
- Rate limit class: heavy model request

## Parameters

| Name | Type | Required | Notes |
|---|---:|---:|---|
| `file` | file-like, `Path`, or upload tuple | yes | `Path`, binary file object, or `(filename, data, content_type)`. |
| `model` | `str` | no | Defaults to `whisper-1`. |
| `language` | `str` | no | Optional language hint. |
| `extra_headers` | `dict[str, str]` | no | Per-request headers. |
| `timeout` | `float | httpx.Timeout` | no | Per-request timeout override. |

## File Inputs

```python
from pathlib import Path

transcript = client.audio.transcriptions.create(
    file=Path("meeting.mp3"),
    model="whisper-1",
)
print(transcript.text)
```

With an explicit upload tuple:

```python
with open("meeting.wav", "rb") as audio:
    transcript = client.audio.transcriptions.create(
        file=("meeting.wav", audio, "audio/wav"),
        language="en",
    )
```

## Response Shape

`AudioTranscription` includes:

- `text`

## Backend Limits

The backend validates allowed content types, empty files, and endpoint size limits. A global request-size middleware can reject very large uploads before endpoint-specific audio validation runs.

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `BillingRequiredError`
- `ModelNotAvailableError`
- `PayloadTooLargeError`
- `BadRequestError`
- `ProviderUnavailableError`
- `UnprocessableEntityError`

## Generated Reference

::: veyra.resources.audio.transcriptions.Transcriptions

::: veyra.resources.audio.transcriptions.AsyncTranscriptions
