# Quota

Quota endpoints expose current usage, plan limits, and public plan information.

## Resources

- Sync status: `client.quota.status()`
- Sync plans: `client.quota.list_plans()`
- Sync public plans: `client.quota.list_public_plans()`
- Async equivalents: `await client.quota.status()`, etc.
- HTTP: `/v1/quota/status`, `/v1/quota/plans`, `/v1/quota/plans/public`

## `status()`

- HTTP: `GET /v1/quota/status`
- Auth: API key or session token with `quota:read`
- Rate limit class: authenticated request

```python
status = client.quota.status()
print(status.plan)
print(status.usage.tokens_remaining_today)
```

`QuotaStatus` includes:

- `plan`
- `limits.daily_tokens`
- `limits.daily_requests`
- `limits.rpm`
- `limits.tpm`
- `limits.max_context_tokens`
- `limits.max_output_tokens`
- `usage.tokens_used_today`
- `usage.tokens_remaining_today`
- `usage.requests_used_today`
- `usage.requests_remaining_today`
- `usage.percentage_used`
- `resets_at`
- `time_until_reset`

## `list_plans()`

- HTTP: `GET /v1/quota/plans`
- Auth: API key or session token with `quota:read`

```python
for plan in client.quota.list_plans():
    print(plan.name, plan.daily_token_limit)
```

## `list_public_plans()`

- HTTP: `GET /v1/quota/plans/public`
- Auth: none at backend level, but the SDK client still includes its configured API key headers

```python
plans = client.quota.list_public_plans()
```

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `RateLimitError`
- `UnprocessableEntityError`

## Generated Reference

::: veyra.resources.quota.Quota

::: veyra.resources.quota.AsyncQuota
