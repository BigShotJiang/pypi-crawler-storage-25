# Assistant

The assistant endpoint is the Veyra product assistant. It can answer public product questions and, when authenticated, account-context questions such as model availability and quota status.

## Resource

- Sync: `client.assistant.chat(...)`
- Async: `await client.assistant.chat(...)`
- HTTP: `POST /v1/assistant/chat`
- Auth: optional at backend level; SDK clients still send their configured key
- Rate limit class: public for `/assistant/chat`; expensive for backward-compatible `/assistant/project-chat`

## Parameters

| Name | Type | Required | Notes |
|---|---:|---:|---|
| `message` | `str` | yes | User message. |
| `history` | sequence of `{role, content}` dicts | no | Previous turns. |
| `stream` | `bool` | no | Returns assistant stream events when true. |
| `extra_headers` | `dict[str, str]` | no | Per-request headers. |
| `timeout` | `float | httpx.Timeout` | no | Per-request timeout override. |

## Example

```python
answer = client.assistant.chat(
    message="Show my available models",
    history=[{"role": "user", "content": "Earlier question"}],
)

print(answer.answer)
print(answer.references)
```

`AssistantResponse` includes:

- `answer`
- `model`
- `references`
- `blocked`
- `requires_login`
- `scope_limited`

## Streaming

```python
with client.assistant.chat(message="Show my available models", stream=True) as stream:
    for event in stream:
        if event.type == "delta":
            print(event.delta or "", end="")
```

Stream event types can include:

- `meta`
- `delta`
- `done`
- backend error events, surfaced as SDK exceptions

## Policy Behavior

The backend can return:

- `blocked=True` for unsafe or secret-exfiltration attempts
- `requires_login=True` for private account questions without a session
- `scope_limited=True` for non-Veyra topics

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `RateLimitError`
- `ProviderUnavailableError`
- `UnprocessableEntityError`

## Generated Reference

::: veyra.resources.assistant.Assistant

::: veyra.resources.assistant.AsyncAssistant
