# Models

Models endpoints list and retrieve models available to the authenticated caller after plan, billing, and user API controls are applied.

## Resources

- Sync list: `client.models.list()`
- Sync retrieve: `client.models.retrieve(model_id)`
- Async list: `await client.models.list()`
- Async retrieve: `await client.models.retrieve(model_id)`
- HTTP: `GET /v1/models`, `GET /v1/models/{model_id}`
- Auth: API key or session token with `chat:read`
- Rate limit class: authenticated request

## List Models

```python
models = client.models.list()
for model in models.data:
    print(model.id, model.owned_by)
```

`ModelList` includes:

- `object`
- `data[]`

Each `ModelInfo` includes:

- `id`
- `object`
- `created`
- `owned_by`

## Retrieve Model

```python
model = client.models.retrieve("gpt-5.4-mini")
print(model.id)
```

If the requested model is unknown or unavailable to the caller, the backend returns `404 model_not_found`, surfaced as `NotFoundError`.

## Availability Filtering

The backend filters models by:

- caller identity and API key scopes
- current quota plan
- user API control settings
- model routing/provider availability

If account-level API access is disabled, the list can be empty even when the API key is syntactically valid.

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `NotFoundError`
- `RateLimitError`

## Generated Reference

::: veyra.resources.models.Models

::: veyra.resources.models.AsyncModels
