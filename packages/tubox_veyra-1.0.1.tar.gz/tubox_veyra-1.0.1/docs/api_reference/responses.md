# Responses

The Responses API is the preferred high-level interface for newer model capabilities, including reasoning output, response-level metadata, and future OpenAI-compatible fields.

## Resource

- Sync: `client.responses.create(...)`
- Async: `await client.responses.create(...)`
- HTTP: `POST /v1/responses`
- Auth: API key or session token with `chat:write`
- Rate limit class: expensive model request

## Parameters

| Name | Type | Required | Notes |
|---|---:|---:|---|
| `model` | `str` | yes | Model id such as `gpt-5.4-mini` or another accessible model. |
| `input` | `str | mapping | sequence` | yes | Text, message-like object, or sequence of text/items. |
| `instructions` | `str` | no | Prepended system/developer guidance. |
| `stream` | `bool` | no | Returns a typed event stream when true. |
| `max_output_tokens` | `int` | no | Maximum generated output tokens. |
| `temperature`, `top_p` | `float` | no | Sampling controls. |
| `response_format` | mapping | no | JSON/schema-style output controls. |
| `reasoning` | mapping | no | Reasoning settings such as `{"effort": "medium", "summary": "auto"}`. |
| `parallel_tool_calls` | `bool` | no | Tool-call scheduling policy. |
| `truncation` | `str` | no | Backend truncation policy, for example `"auto"`. |
| `tools` | iterable of mappings | no | Tool/function definitions. |
| `tool_choice` | `str | mapping` | no | Tool selection policy. |
| `metadata` | mapping | no | User metadata. Useful for conversation or trace ids. |
| `include` | sequence of strings | no | Optional response inclusions, for example reasoning encrypted content where supported. |
| `store` | `bool` | no | Store behavior if the backend supports it. |
| `previous_response_id` | `str` | no | Conversation continuation pointer where supported. |
| `user` | `str` | no | OpenAI-compatible user field. The backend may override for authenticated users. |
| `extra_body` | mapping | no | Escape hatch for newly released fields; overrides SDK-built fields. |
| `extra_headers` | `dict[str, str]` | no | Per-request headers. |
| `timeout` | `float | httpx.Timeout` | no | Per-request timeout override. |

## Basic Example

```python
response = client.responses.create(
    model="gpt-5.4-mini",
    input="Summarize Veyra in one sentence.",
    instructions="Be concise.",
    max_output_tokens=128,
)

text = "".join(
    content.text or ""
    for item in response.output
    for content in item.content
)
print(text)
```

## Reasoning Example

```python
response = client.responses.create(
    model="gpt-5.4-mini",
    input="Give the final answer only: 17 * 19",
    reasoning={"effort": "low", "summary": "auto"},
    max_output_tokens=64,
)

print(response.status)
print(response.reasoning)
if response.usage and response.usage.output_tokens_details:
    print(response.usage.output_tokens_details.reasoning_tokens)
```

The backend can return multiple output item types. For reasoning-capable calls, it may return a `reasoning` item before the final `message` item. The SDK accepts unknown output content types and normalizes `content: null` to an empty list.

## Streaming

```python
with client.responses.create(
    model="gpt-5.4-mini",
    input="Write three words.",
    stream=True,
) as stream:
    for event in stream:
        if event.type == "response.output_text.delta":
            print(event.delta or event.text or "", end="")
```

Events are parsed as `ResponseStreamEvent` and may include:

- `response.created`
- `response.output_text.delta`
- `response.output_text.done`
- `response.completed`
- provider error events, surfaced as SDK exceptions

## Response Shape

`Response` includes:

- `id`, `object`, `created_at`, `model`, `status`
- `instructions`, `metadata`
- `output[]` with flexible `type`, `status`, `role`, and `content[]`
- `reasoning`, `parallel_tool_calls`, `tool_choice`, `tools`, `truncation`
- `usage.input_tokens`, `usage.output_tokens`, `usage.total_tokens`
- `usage.input_tokens_details.cached_tokens`
- `usage.output_tokens_details.reasoning_tokens`

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `BillingRequiredError`
- `ModelNotAvailableError`
- `RateLimitError`
- `ProviderUnavailableError`
- `UnprocessableEntityError`

## Generated Reference

::: veyra.resources.responses.Responses

::: veyra.resources.responses.AsyncResponses
