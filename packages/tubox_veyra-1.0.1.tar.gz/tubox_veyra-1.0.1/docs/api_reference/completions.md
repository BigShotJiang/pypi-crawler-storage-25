# Completions

Legacy text completions are supported for OpenAI compatibility. New applications should prefer chat completions or responses unless they specifically need the legacy `prompt` interface.

## Resource

- Sync: `client.completions.create(...)`
- Async: `await client.completions.create(...)`
- HTTP: `POST /v1/completions`
- Auth: API key or session token with `chat:write`
- Rate limit class: expensive model request

## Parameters

| Name | Type | Required | Notes |
|---|---:|---:|---|
| `model` | `str` | yes | Model id. |
| `prompt` | `str | Sequence[str]` | yes | A string or a single-item list. Multi-prompt arrays are rejected by the SDK to match backend behavior. |
| `stream` | `bool` | no | Returns text completion chunks when true. |
| `max_tokens` | `int` | no | Legacy max output token field. |
| `temperature`, `top_p` | `float` | no | Sampling controls. |
| `stop` | `str | list[str]` | no | Stop sequence or sequences. |
| `user` | `str` | no | OpenAI-compatible user field. |
| `extra_body` | mapping | no | Escape hatch for compatible fields not yet typed by the SDK. |
| `extra_headers` | `dict[str, str]` | no | Per-request headers. |
| `timeout` | `float | httpx.Timeout` | no | Per-request timeout override. |

## Example

```python
completion = client.completions.create(
    model="gpt-5.4-mini",
    prompt="Write one short greeting",
    max_tokens=64,
)
print(completion.choices[0].text)
```

## Streaming

```python
with client.completions.create(
    model="gpt-5.4-mini",
    prompt="Count to three",
    stream=True,
) as stream:
    for chunk in stream:
        print(chunk.choices[0].text or "", end="")
```

## Response Shape

`TextCompletion` includes:

- `id`, `object`, `created`, `model`
- `choices[].text`
- `choices[].index`
- `choices[].finish_reason`
- optional `choices[].logprobs`
- optional `usage`

## Validation

The SDK validates the prompt before sending:

- empty lists are rejected
- multi-prompt lists are rejected
- list items must be strings

## Common Errors

The same model invocation errors apply as chat: authentication, permission, billing, model access, rate limit, provider, and validation errors.

## Generated Reference

::: veyra.resources.completions.Completions

::: veyra.resources.completions.AsyncCompletions
