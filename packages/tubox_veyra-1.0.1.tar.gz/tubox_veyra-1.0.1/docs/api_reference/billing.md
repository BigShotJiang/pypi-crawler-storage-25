# Billing

Billing resources expose usage records, aggregate summaries, billing profile data, and model-access billing status.

## Namespace

- Sync: `client.billing.usage`, `client.billing.profile`
- Async: `client.billing.usage`, `client.billing.profile`
- Auth: API key or session token with `billing:read`
- Rate limit class: authenticated request

## Usage Records

```python
page = client.billing.usage.list(limit=100)
for record in page:
    print(record.created_at, record.model, record.total_tokens)
```

Parameters:

| Name | Type | Notes |
|---|---:|---|
| `since` | `str` | Optional ISO datetime lower bound. |
| `until` | `str` | Optional ISO datetime upper bound. |
| `model` | `str` | Optional model filter. |
| `offset` | `int` | Default `0`. |
| `limit` | `int` | Default `50`; backend max is documented as `500`. |

`list()` returns `SyncPage[UsageRecord]` or `AsyncPage[UsageRecord]`. Pages auto-advance during iteration when the backend indicates more results.

`UsageRecord` accepts backend cost/pricing fields as extra model attributes, including pricing snapshots and `conversation_id` when present.

## Daily and Monthly Summaries

```python
daily = client.billing.usage.daily_summary()
monthly = client.billing.usage.monthly_summary(year=2026, month=5)
print(daily.total_tokens, monthly.request_count)
```

`UsageSummary` includes:

- `prompt_tokens`
- `completion_tokens`
- `total_tokens`
- `request_count`
- optional `cached_tokens`
- optional `total_cost_usd`

## Conversation Summary

```python
summary = client.billing.usage.conversation_summary("conversation-id")
print(summary.total_tokens, summary.total_cost_usd)
```

This calls `GET /v1/billing/usage/conversations/{conversation_id}/summary`.

## Billing Profile

Retrieve the current profile:

```python
profile = client.billing.profile.retrieve()
if profile is None:
    print("No billing profile")
```

Create or update:

```python
profile = client.billing.profile.upsert(
    billing_email="billing@example.com",
    full_name="Example Billing",
    country_code="US",
    line1="123 Main St",
    city="Austin",
    state_region="TX",
    postal_code="78701",
)
```

Card fields are optional, but if any card field is supplied the backend expects the complete card metadata bundle.

## Billing Access

```python
access = client.billing.profile.access()
if not access.can_use_models:
    print(access.reason)
```

`BillingAccess` includes:

- `plan`
- `billing_required`
- `can_use_models`
- `reason`

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `RateLimitError`
- `UnprocessableEntityError`
- `InternalServerError`

## Generated Reference

::: veyra.resources.billing.usage.Usage

::: veyra.resources.billing.usage.AsyncUsage

::: veyra.resources.billing.profile.Profile

::: veyra.resources.billing.profile.AsyncProfile
