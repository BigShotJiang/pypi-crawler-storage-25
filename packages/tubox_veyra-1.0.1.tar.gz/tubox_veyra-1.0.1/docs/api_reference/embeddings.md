# Embeddings

Embeddings convert text into numeric vectors for search, ranking, clustering, retrieval, and classification workflows.

## Resource

- Sync: `client.embeddings.create(...)`
- Async: `await client.embeddings.create(...)`
- HTTP: `POST /v1/embeddings`
- Auth: API key or session token with `embeddings:read`
- Rate limit class: expensive model request

## Parameters

| Name | Type | Required | Notes |
|---|---:|---:|---|
| `model` | `str` | yes | Embedding model id, for example `text-embedding-3-small`. |
| `input` | `str | Sequence[str]` | yes | Single string or list of strings. |
| `encoding_format` | `str` | no | Defaults to `"float"`. |
| `extra_headers` | `dict[str, str]` | no | Per-request headers. |
| `timeout` | `float | httpx.Timeout` | no | Per-request timeout override. |

## Example

```python
embedding = client.embeddings.create(
    model="text-embedding-3-small",
    input=["alpha", "beta"],
)

for item in embedding.data:
    print(item.index, len(item.embedding))
```

## Response Shape

`EmbeddingResponse` includes:

- `object`
- `data[]`
- `data[].embedding`
- `data[].index`
- `model`
- `usage.prompt_tokens`, `usage.total_tokens`

## SDK Validation

The SDK validates common backend limits before making the request:

- string input cannot be empty and has a maximum length
- list input cannot be empty
- list input has a maximum number of items
- each list item must be non-empty text within the item length limit

## Billing and Usage

The backend enforces plan/model access and records usage for successful provider calls. When provider usage is unavailable, token usage may be estimated by the backend.

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `BillingRequiredError`
- `ModelNotAvailableError`
- `RateLimitError`
- `UnprocessableEntityError`
- `ProviderUnavailableError`

## Generated Reference

::: veyra.resources.embeddings.Embeddings

::: veyra.resources.embeddings.AsyncEmbeddings
