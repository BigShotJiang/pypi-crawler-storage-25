# Chat

Chat completions are the primary OpenAI-compatible conversational interface in the SDK.

## Resource

- Sync: `client.chat.completions.create(...)`
- Async: `await client.chat.completions.create(...)`
- HTTP: `POST /v1/chat/completions`
- Auth: API key or session token with `chat:write`
- Rate limit class: expensive model request

## Parameters

| Name | Type | Required | Notes |
|---|---:|---:|---|
| `model` | `str` | yes | Model id such as `gpt-5.4-mini`. |
| `messages` | iterable of message dicts | yes | Supports `system`, `developer`, `user`, `assistant`, `tool`, `function`, and compatible custom message shapes. |
| `stream` | `bool` | no | Returns `Stream[ChatCompletionChunk]` / `AsyncStream[...]` when `True`. |
| `max_completion_tokens` | `int` | no | Maximum generated tokens. |
| `temperature`, `top_p` | `float` | no | Sampling controls. |
| `stop` | `str | list[str]` | no | Stop sequence or sequences. |
| `frequency_penalty`, `presence_penalty` | `float` | no | Penalize repeated tokens or topics. |
| `response_format` | mapping | no | Forwarded to the backend for JSON/schema-style output modes. |
| `reasoning` | mapping | no | Reasoning options, for example `{"effort": "low", "summary": "auto"}`. |
| `parallel_tool_calls` | `bool` | no | Controls parallel tool-call behavior when tools are supplied. |
| `tools` | iterable of mappings | no | Tool/function definitions. |
| `tool_choice` | `str | mapping` | no | Tool selection policy, commonly `"auto"` or a specific tool object. |
| `truncation` | `str` | no | Backend truncation behavior, for example `"auto"`. |
| `metadata` | mapping | no | User-defined metadata passed through to the API. |
| `stream_options` | mapping | no | Stream options such as usage inclusion if supported by the backend. |
| `logprobs`, `top_logprobs`, `seed`, `n`, `user` | mixed | no | OpenAI-compatible passthrough fields. |
| `extra_body` | mapping | no | Escape hatch for newly released request fields before a typed SDK update. Values override SDK-built body fields. |
| `extra_headers` | `dict[str, str]` | no | Per-request headers. |
| `timeout` | `float | httpx.Timeout` | no | Per-request timeout override. |

## Basic Example

```python
import veyra

client = veyra.Veyra()
completion = client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[
        {"role": "system", "content": "You are concise."},
        {"role": "user", "content": "Say hello"},
    ],
    max_completion_tokens=64,
)

print(completion.choices[0].message.content)
```

## Reasoning Example

```python
completion = client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Explain the tradeoff in one sentence."}],
    reasoning={"effort": "low", "summary": "auto"},
    max_completion_tokens=128,
)

if completion.usage and completion.usage.completion_tokens_details:
    print(completion.usage.completion_tokens_details.get("reasoning_tokens"))
```

## Tool Example

```python
completion = client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Look up order 123"}],
    tools=[
        {
            "type": "function",
            "function": {
                "name": "lookup_order",
                "parameters": {
                    "type": "object",
                    "properties": {"order_id": {"type": "string"}},
                    "required": ["order_id"],
                },
            },
        }
    ],
    tool_choice="auto",
)
```

## Streaming

```python
with client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Count to 3"}],
    stream=True,
) as stream:
    for chunk in stream:
        delta = chunk.choices[0].delta
        print(delta.content or "", end="")
```

Async streaming:

```python
async with await client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Count to 3"}],
    stream=True,
) as stream:
    async for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="")
```

## Response Shape

`ChatCompletion` includes:

- `id`, `object`, `created`, `model`
- `choices[].message.role`
- `choices[].message.content`
- optional `choices[].message.tool_calls`
- optional `usage.prompt_tokens`, `usage.completion_tokens`, `usage.total_tokens`
- optional token-detail maps for cached and reasoning token accounting

Stream chunks are `ChatCompletionChunk` objects with `choices[].delta`.

## Common Errors

- `AuthenticationError`: missing or invalid API key.
- `PermissionDeniedError`: key lacks `chat:write`, account API access disabled, or route forbidden.
- `BillingRequiredError`: billing profile required for the user's plan.
- `ModelNotAvailableError`: model not allowed for plan/user controls.
- `RateLimitError`: request/rate/quota limit exceeded.
- `ProviderUnavailableError`: upstream provider failure after sanitization.
- `UnprocessableEntityError`: invalid request payload.

## Raw Response Metadata

```python
raw = client.with_raw_response.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Hi"}],
)
print(raw.request_id, raw.http_status)
completion = raw.data
```

## Generated Reference

::: veyra.resources.chat.completions.Completions

::: veyra.resources.chat.completions.AsyncCompletions
