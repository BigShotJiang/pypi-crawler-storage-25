# API Keys

API key management endpoints create, list, update, and revoke keys for the current account. Newly created secret keys are returned once.

## Resource

- Sync: `client.api_keys`
- Async: `client.api_keys`
- HTTP base: `/v1/api-keys`
- Auth: key or session with `api_keys:manage`
- Rate limit class: authenticated request

## Create

```python
created = client.api_keys.create(
    name="automation",
    scopes=["chat:read", "chat:write"],
    ip_whitelist=["203.0.113.0/24"],
    expires_in_days=30,
)
print(created.key)  # shown once
```

Parameters:

| Name | Type | Required | Notes |
|---|---:|---:|---|
| `name` | `str` | yes | User-visible key name. |
| `scopes` | `list[str]` | yes | Permission scopes. |
| `ip_whitelist` | `list[str]` | no | IPs or CIDR ranges. |
| `expires_in_days` | `int` | no | Key expiry window. |

`APIKeyCreateResponse` includes:

- `id`
- `name`
- `key`
- `key_prefix`
- `scopes`
- `created_at`

## List

```python
for key in client.api_keys.list():
    print(key.id, key.name, key.is_active)
```

List responses never include the full secret key.

## Update

```python
updated = client.api_keys.update(
    "key-id",
    name="renamed",
    scopes=["chat:read"],
    ip_whitelist=None,
    expires_in_days=90,
)
```

Mutable fields:

- `name`
- `scopes`
- `ip_whitelist`
- `rate_limit_override` (persisted by backend, not currently enforced by rate limiting)
- `expires_in_days`

## Revoke

```python
client.api_keys.revoke("key-id")
```

Revoke returns `None` on success.

## Common Scopes

- `chat:read`
- `chat:write`
- `embeddings:read`
- `images:write`
- `audio:write`
- `quota:read`
- `billing:read`
- `api_keys:manage`

## Common Errors

- `AuthenticationError`
- `PermissionDeniedError`
- `ConflictError`
- `NotFoundError`
- `RateLimitError`
- `UnprocessableEntityError`

## Generated Reference

::: veyra.resources.api_keys.APIKeys

::: veyra.resources.api_keys.AsyncAPIKeys
