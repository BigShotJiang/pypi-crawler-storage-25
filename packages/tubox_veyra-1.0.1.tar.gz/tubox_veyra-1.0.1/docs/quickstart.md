# Quickstart

```python
import veyra

client = veyra.Veyra()
result = client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Summarize Veyra in one sentence."}],
    reasoning={"effort": "low"},
)
print(result.choices[0].message.content)
```

```python
import asyncio
import veyra

async def main() -> None:
    async with veyra.AsyncVeyra() as client:
        result = await client.chat.completions.create(
            model="gpt-5.4-mini",
            messages=[{"role": "user", "content": "List 3 Python tips"}],
        )
        print(result.choices[0].message.content)

asyncio.run(main())
```

## Responses reasoning

```python
response = client.responses.create(
    model="gpt-5.4-mini",
    input="Explain the quota tradeoff in one sentence.",
    reasoning={"effort": "medium", "summary": "auto"},
    parallel_tool_calls=False,
)
print(response.output[0].content[0].text)
```
