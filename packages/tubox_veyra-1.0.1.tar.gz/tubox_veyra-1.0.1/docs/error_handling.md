# Error Handling

All HTTP/API failures are mapped to SDK exception classes. Catch specific exceptions when you have a recovery path, and catch `APIError` for general API failures.

## Exception Hierarchy

- `VeyraError`: base SDK exception.
- `APIError`: base class for HTTP API responses.
- `BadRequestError`: 400-level malformed or rejected request.
- `AuthenticationError`: missing/invalid credentials.
- `BillingRequiredError`: model usage requires billing setup.
- `PermissionDeniedError`: forbidden route, scope, or account control.
- `ModelNotAvailableError`: requested model is not available to the caller.
- `NotFoundError`: missing resource.
- `ConflictError`: duplicate or conflicting resource state.
- `UnprocessableEntityError`: validation error with optional `details`.
- `RateLimitError`: 429 with optional `retry_after`.
- `PayloadTooLargeError`: request body too large.
- `MaintenanceModeError`: service maintenance response.
- `ProviderUnavailableError`: sanitized upstream model provider failure.
- `InternalServerError`: 5xx backend failure.
- `APIConnectionError`: network connection failure.
- `APITimeoutError`: request timeout.
- `StreamConsumedError`: attempted to iterate a stream more than once.

## Basic Pattern

```python
import veyra

try:
    ...
except veyra.RateLimitError as exc:
    print(exc.retry_after)
except veyra.APIError as exc:
    print(exc.status_code, exc.code, exc)
```

## Validation Details

Validation errors can include structured details from the backend:

```python
try:
    client.chat.completions.create(model="", messages=[])
except veyra.UnprocessableEntityError as exc:
    for detail in exc.details or []:
        print(detail.loc, detail.msg, detail.type)
```

## Rate Limits

`RateLimitError.retry_after` is parsed from the `Retry-After` response header when present.

```python
try:
    client.responses.create(model="gpt-5.4-mini", input="Hello")
except veyra.RateLimitError as exc:
    print("retry after seconds:", exc.retry_after)
```

## Streaming Errors

Streaming endpoints can emit an error event before `[DONE]`. The stream iterator raises the same SDK exception types used for non-streaming calls.

```python
with client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Hi"}],
    stream=True,
) as stream:
    for chunk in stream:
        ...
```

Once a stream has been consumed or closed, iterating it again raises `StreamConsumedError`.
