"""Print current quota usage."""

import veyra

client = veyra.Veyra()
status = client.quota.status()
print(f"Plan: {status.plan}")
print(f"Requests today: {status.usage.requests_used_today}/{status.limits.daily_requests}")
print(f"Tokens today:   {status.usage.tokens_used_today}/{status.limits.daily_tokens}")
print(f"Resets at:      {status.resets_at}")
