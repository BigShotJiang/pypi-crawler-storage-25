"""Basic non-streaming chat completion."""

import veyra

client = veyra.Veyra()
completion = client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Explain the Veyra quota system in one paragraph."}],
    max_completion_tokens=256,
)
print(completion.choices[0].message.content)
if completion.usage is not None:
    print(f"\n[tokens used: {completion.usage.total_tokens}]")
