"""Async streaming chat completion."""

import asyncio

import veyra


async def main() -> None:
    async with veyra.AsyncVeyra() as client:
        stream = await client.chat.completions.create(
            model="gpt-5.4-mini",
            messages=[{"role": "user", "content": "List three Python best practices."}],
            stream=True,
        )
        async with stream:
            async for chunk in stream:
                print(chunk.choices[0].delta.content or "", end="", flush=True)
    print()


asyncio.run(main())
