"""List last 20 billing usage records."""

import veyra

client = veyra.Veyra()
for record in client.billing.usage.list(limit=20):
    print(f"{record.created_at}  {record.model:<24}  {record.total_tokens:>8} tokens  {record.status_code}")
