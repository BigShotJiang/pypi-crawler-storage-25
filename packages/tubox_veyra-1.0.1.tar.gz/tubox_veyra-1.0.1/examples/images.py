"""Generate an image and print the URL."""

import veyra

client = veyra.Veyra()
result = client.images.generations.create(
    model="gpt-image-2",
    prompt="A minimalist logo for an AI API platform, flat design, dark background",
    size="1024x1024",
    quality="standard",
)
print(result.data[0].url)
