"""Streaming chat completion — print tokens as they arrive."""

import veyra

client = veyra.Veyra()
with client.chat.completions.create(
    model="gpt-5.4-mini",
    messages=[{"role": "user", "content": "Count slowly from 1 to 10."}],
    stream=True,
) as stream:
    for chunk in stream:
        print(chunk.choices[0].delta.content or "", end="", flush=True)
print()
