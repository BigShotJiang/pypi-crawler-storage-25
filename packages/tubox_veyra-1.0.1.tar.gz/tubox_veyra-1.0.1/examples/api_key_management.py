"""Create, list, and revoke an API key."""

import veyra

client = veyra.Veyra()

new_key = client.api_keys.create(
    name="ci-automation",
    scopes=["chat:read", "chat:write"],
    expires_in_days=30,
)
print(f"Created: {new_key.key}")

keys = client.api_keys.list()
for k in keys:
    print(f"{k.id}  {k.name}  active={k.is_active}")

client.api_keys.revoke(new_key.id)
print("Revoked.")
