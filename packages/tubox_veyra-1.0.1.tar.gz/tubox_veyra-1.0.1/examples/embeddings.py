"""Generate embeddings for a list of strings."""

import veyra

client = veyra.Veyra()
response = client.embeddings.create(
    model="text-embedding-3-small",
    input=["Veyra is an AI platform.", "Python SDKs are great."],
)
for item in response.data:
    print(f"index={item.index}  dims={len(item.embedding)}")
