"""Transcribe an audio file."""

from pathlib import Path

import veyra

client = veyra.Veyra()
audio_path = Path("speech.mp3")
result = client.audio.transcriptions.create(file=audio_path, model="whisper-1")
print(result.text)
