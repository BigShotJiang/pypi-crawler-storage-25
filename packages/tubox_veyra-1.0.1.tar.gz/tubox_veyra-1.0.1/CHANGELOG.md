# Changelog

## 1.0.1

- Added SDK support for reasoning-capable request fields on chat completions and responses, including `reasoning`, tool controls, truncation, metadata, include/store controls, and `extra_body` passthrough for newly released backend fields.
- Expanded response models to support reasoning output items, unknown output content types, nullable response item content, cached-token details, and reasoning-token usage details.
- Added `client.billing.usage.conversation_summary(conversation_id)` for conversation-level usage and cost summaries.
- Expanded API reference documentation for every SDK resource with parameters, examples, response shapes, streaming behavior, validation, and error handling.
- Added broader regression coverage for request serialization, multipart uploads, raw response handling, streaming errors, flexible response parsing, and reasoning/token accounting.

## 1.0.0

- First stable production release.
- Sync + async clients from a unified codebase.
- Resource-namespaced API surface with typed request/response models.
- Streaming, pagination, retries, and rich exception mapping.
- GitHub CI/CD workflows for lint, type-check, tests, build, and release publishing.
