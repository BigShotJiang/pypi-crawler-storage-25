from __future__ import annotations

from typing import get_args, get_origin


def is_list(tp: object) -> bool:
    """Return True if the provided annotation is list[T]."""

    return get_origin(tp) is list


def is_optional(tp: object) -> bool:
    """Return True if the annotation is Optional[T]."""

    origin = get_origin(tp)
    if origin is None:
        return False
    return type(None) in get_args(tp)


def extract_type(tp: object) -> object:
    """Extract inner non-None type from Optional[T], otherwise return unchanged."""

    if not is_optional(tp):
        return tp
    args = [arg for arg in get_args(tp) if arg is not type(None)]
    if not args:
        return object
    return args[0]
