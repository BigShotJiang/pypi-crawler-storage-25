from __future__ import annotations

from collections.abc import Sequence

from veyra._exceptions import VeyraError

_ALLOWED_IMAGE_SIZES = {"1024x1024", "1024x1792", "1792x1024"}
_ALLOWED_IMAGE_QUALITY = {"standard", "hd"}


def validate_legacy_prompt(prompt: str | Sequence[str]) -> None:
    """Validate legacy completions prompt rules."""

    if isinstance(prompt, str):
        return
    if len(prompt) == 0:
        raise VeyraError("Prompt list cannot be empty.")
    if len(prompt) > 1:
        raise VeyraError("Multi-prompt arrays are not supported.")


def validate_embeddings_input(input_data: str | Sequence[str]) -> None:
    """Validate embedding input constraints before dispatch."""

    if isinstance(input_data, str):
        if len(input_data) > 30_000:
            raise VeyraError("Embedding input string exceeds 30,000 characters.")
        return

    if len(input_data) == 0:
        raise VeyraError("Embedding input list cannot be empty.")
    if len(input_data) > 256:
        raise VeyraError("Embedding input list cannot exceed 256 items.")

    for item in input_data:
        if len(item) > 30_000:
            raise VeyraError("Each embedding input item must be <= 30,000 characters.")


def validate_image_generation(*, n: int, size: str, quality: str) -> None:
    """Validate image generation payload fields."""

    if n < 1 or n > 10:
        raise VeyraError("Image generations `n` must be between 1 and 10.")
    if size not in _ALLOWED_IMAGE_SIZES:
        raise VeyraError("Image `size` must be one of: 1024x1024, 1024x1792, 1792x1024.")
    if quality not in _ALLOWED_IMAGE_QUALITY:
        raise VeyraError("Image `quality` must be one of: standard, hd.")
