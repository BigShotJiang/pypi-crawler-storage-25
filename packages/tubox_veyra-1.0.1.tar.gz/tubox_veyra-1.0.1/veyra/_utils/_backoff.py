from __future__ import annotations

import random


def exponential_backoff_with_jitter(
    attempt: int,
    base: float = 0.5,
    multiplier: float = 2.0,
    jitter: float = 0.25,
    cap: float = 60.0,
) -> float:
    """Return delay seconds for a retry attempt with bounded jitter."""

    if attempt < 0:
        raise ValueError("attempt must be >= 0")
    if base <= 0:
        raise ValueError("base must be > 0")
    if multiplier < 1:
        raise ValueError("multiplier must be >= 1")
    if jitter < 0:
        raise ValueError("jitter must be >= 0")
    if cap <= 0:
        raise ValueError("cap must be > 0")

    delay = min(base * (multiplier**attempt), cap)
    if jitter == 0:
        return delay
    spread = jitter * delay
    return max(0.0, delay + random.uniform(-spread, spread))
