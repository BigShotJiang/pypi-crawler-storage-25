from __future__ import annotations

from dataclasses import is_dataclass
from typing import cast

from pydantic import BaseModel


def strip_none(value: object) -> object:
    """Recursively remove None values from mappings and lists."""

    if isinstance(value, dict):
        return {k: strip_none(v) for k, v in value.items() if v is not None}
    if isinstance(value, list):
        return [strip_none(item) for item in value]
    if isinstance(value, tuple):
        return tuple(strip_none(item) for item in value)
    return value


def model_to_dict(value: object) -> dict[str, object]:
    """Convert supported model values into a plain dictionary."""

    if isinstance(value, BaseModel):
        return cast(dict[str, object], value.model_dump(exclude_none=True))
    if is_dataclass(value):
        return {
            key: item
            for key, item in value.__dict__.items()
            if not key.startswith("_") and item is not None
        }
    if isinstance(value, dict):
        return cast(dict[str, object], strip_none(value))
    raise TypeError(f"Unsupported value for model_to_dict: {type(value)!r}")


def to_jsonable(value: object) -> object:
    """Convert request payload values to JSON-serializable structures."""

    if isinstance(value, BaseModel):
        return value.model_dump(exclude_none=True)
    if is_dataclass(value):
        return strip_none(value.__dict__)
    if isinstance(value, dict):
        return {key: to_jsonable(item) for key, item in value.items() if item is not None}
    if isinstance(value, list):
        return [to_jsonable(item) for item in value]
    if isinstance(value, tuple):
        return [to_jsonable(item) for item in value]
    return value
