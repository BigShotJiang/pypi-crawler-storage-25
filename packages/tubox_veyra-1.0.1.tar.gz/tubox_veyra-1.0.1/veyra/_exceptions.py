from __future__ import annotations

from email.utils import parsedate_to_datetime
from typing import cast

import httpx

from veyra.types.shared import ErrorDetail


class VeyraError(Exception):
    """Base class for all Veyra SDK errors."""


class APIError(VeyraError):
    """Received an error response from the Veyra API."""

    def __init__(
        self,
        message: str,
        *,
        code: str | None,
        status_code: int,
        request: httpx.Request,
        response: httpx.Response | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.status_code = status_code
        self.request = request
        self.response = response


class BadRequestError(APIError):
    """400 — malformed request body or prompt injection detected."""


class AuthenticationError(APIError):
    """401 — missing, invalid, or revoked API key."""


class BillingRequiredError(APIError):
    """402 — free-plan user has no billing profile."""


class PermissionDeniedError(APIError):
    """403 — API key lacks required permission scope."""


class NotFoundError(APIError):
    """404 — resource (model, key, etc.) does not exist."""


class ConflictError(APIError):
    """409 — duplicate resource (e.g. API key name taken)."""


class UnprocessableEntityError(APIError):
    """422 — validation error with details."""

    def __init__(
        self,
        message: str,
        *,
        code: str | None,
        status_code: int,
        request: httpx.Request,
        response: httpx.Response | None = None,
        details: list[ErrorDetail] | None = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )
        self.details = details or []


class RateLimitError(APIError):
    """429 — rate or quota limit hit; carries retry_after."""

    def __init__(
        self,
        message: str,
        *,
        code: str | None,
        status_code: int,
        request: httpx.Request,
        response: httpx.Response | None = None,
        retry_after: float | None = None,
    ) -> None:
        super().__init__(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )
        self.retry_after = retry_after

    @classmethod
    def from_response(
        cls,
        *,
        message: str,
        code: str | None,
        request: httpx.Request,
        response: httpx.Response,
    ) -> RateLimitError:
        retry_after = _parse_retry_after(response.headers.get("Retry-After"))
        return cls(
            message,
            code=code,
            status_code=response.status_code,
            request=request,
            response=response,
            retry_after=retry_after,
        )


class InternalServerError(APIError):
    """500 — unhandled server error."""


class ProviderUnavailableError(APIError):
    """502 / 503 — upstream model provider unavailable."""


class ModelNotAvailableError(PermissionDeniedError):
    """403 model_not_available — model not in plan or user controls."""


class MaintenanceModeError(APIError):
    """503 maintenance_mode — platform under maintenance."""


class PayloadTooLargeError(BadRequestError):
    """413 payload_too_large — request body exceeded size limit."""


class APIConnectionError(VeyraError):
    """Network-level failure before any HTTP response was received."""

    def __init__(self, message: str, *, request: httpx.Request) -> None:
        super().__init__(message)
        self.request = request


class APITimeoutError(APIConnectionError):
    """Request timed out before receiving a response."""


class StreamConsumedError(VeyraError):
    """A stream was iterated after being closed or consumed."""


def _parse_retry_after(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        return max(0.0, float(value))
    except ValueError:
        pass
    try:
        parsed = parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    return max(0.0, parsed.timestamp() - parsed.now(tz=parsed.tzinfo).timestamp())


def _extract_error(body: dict[str, object]) -> tuple[str | None, str, list[ErrorDetail]]:
    payload = body.get("error", body)
    code = payload.get("code") if isinstance(payload, dict) else None
    message = "Request failed"
    details: list[ErrorDetail] = []

    if isinstance(payload, dict):
        payload_dict = cast(dict[str, object], payload)
        message = str(payload_dict.get("message") or message)
        raw_details = payload_dict.get("details")
        if isinstance(raw_details, list):
            for item in raw_details:
                if isinstance(item, dict):
                    details.append(ErrorDetail.model_validate(item))

    return code, message, details


def make_api_error(
    *,
    request: httpx.Request,
    response: httpx.Response,
    body: dict[str, object],
) -> APIError:
    """Map API status + code payload to a concrete SDK exception class."""

    status_code = response.status_code
    code, message, details = _extract_error(body)

    if status_code == 400:
        if code == "payload_too_large":
            return PayloadTooLargeError(
                message,
                code=code,
                status_code=status_code,
                request=request,
                response=response,
            )
        return BadRequestError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code == 401:
        return AuthenticationError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code == 402:
        return BillingRequiredError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code == 403:
        if code == "model_not_available":
            return ModelNotAvailableError(
                message,
                code=code,
                status_code=status_code,
                request=request,
                response=response,
            )
        return PermissionDeniedError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code == 404:
        return NotFoundError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code == 409:
        return ConflictError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code == 413:
        return PayloadTooLargeError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code == 422:
        return UnprocessableEntityError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
            details=details,
        )

    if status_code == 429:
        return RateLimitError.from_response(
            message=message,
            code=code,
            request=request,
            response=response,
        )

    if status_code == 500:
        return InternalServerError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code == 503 and code == "maintenance_mode":
        return MaintenanceModeError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    if status_code in (502, 503):
        return ProviderUnavailableError(
            message,
            code=code,
            status_code=status_code,
            request=request,
            response=response,
        )

    return APIError(
        message,
        code=code,
        status_code=status_code,
        request=request,
        response=response,
    )
