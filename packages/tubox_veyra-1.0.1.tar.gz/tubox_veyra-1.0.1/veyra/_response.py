from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, TypeVar

import httpx

T = TypeVar("T")


@dataclass
class APIResponse(Generic[T]):
    """Typed response envelope with transport metadata."""

    data: T
    request_id: str | None
    http_status: int
    headers: httpx.Headers
