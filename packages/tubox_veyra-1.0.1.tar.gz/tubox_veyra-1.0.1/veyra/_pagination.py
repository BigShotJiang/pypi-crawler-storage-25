from __future__ import annotations

from collections.abc import AsyncIterator, Awaitable, Callable, Iterator
from typing import Generic, TypeVar

T = TypeVar("T")

_SyncFetcher = Callable[[int, int], "SyncPage[T] | None"]
_AsyncFetcher = Callable[[int, int], Awaitable["AsyncPage[T] | None"]]


class SyncPage(Generic[T]):
    """An auto-advancing offset page iterator."""

    __slots__ = ("items", "total", "offset", "limit", "has_more", "next_offset", "_fetcher")

    def __init__(
        self,
        *,
        items: list[T],
        total: int,
        offset: int,
        limit: int,
        has_more: bool,
        next_offset: int | None,
        fetcher: _SyncFetcher[T],
    ) -> None:
        self.items = items
        self.total = total
        self.offset = offset
        self.limit = limit
        self.has_more = has_more
        self.next_offset = next_offset
        self._fetcher = fetcher

    def __iter__(self) -> Iterator[T]:
        page: SyncPage[T] | None = self
        while page is not None:
            yield from page.items
            page = page.next_page()

    def __len__(self) -> int:
        return self.total

    def current_page(self) -> list[T]:
        return list(self.items)

    def next_page(self) -> SyncPage[T] | None:
        if not self.has_more or self.next_offset is None:
            return None
        return self._fetcher(self.next_offset, self.limit)

    def iter_pages(self) -> Iterator[SyncPage[T]]:
        page: SyncPage[T] | None = self
        while page is not None:
            yield page
            page = page.next_page()


class AsyncPage(Generic[T]):
    """Async variant of ``SyncPage``."""

    __slots__ = ("items", "total", "offset", "limit", "has_more", "next_offset", "_fetcher")

    def __init__(
        self,
        *,
        items: list[T],
        total: int,
        offset: int,
        limit: int,
        has_more: bool,
        next_offset: int | None,
        fetcher: _AsyncFetcher[T],
    ) -> None:
        self.items = items
        self.total = total
        self.offset = offset
        self.limit = limit
        self.has_more = has_more
        self.next_offset = next_offset
        self._fetcher = fetcher

    def __aiter__(self) -> AsyncIterator[T]:
        return self._iter_items()

    async def _iter_items(self) -> AsyncIterator[T]:
        page: AsyncPage[T] | None = self
        while page is not None:
            for item in page.items:
                yield item
            page = await page.next_page()

    async def next_page(self) -> AsyncPage[T] | None:
        if not self.has_more or self.next_offset is None:
            return None
        return await self._fetcher(self.next_offset, self.limit)

    async def iter_pages(self) -> AsyncIterator[AsyncPage[T]]:
        page: AsyncPage[T] | None = self
        while page is not None:
            yield page
            page = await page.next_page()
