from __future__ import annotations

import os
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Generic, TypeVar, Union, cast

import httpx
from pydantic import BaseModel

from veyra._exceptions import (
    APIError,
    AuthenticationError,
    make_api_error,
)
from veyra._response import APIResponse
from veyra._utils._backoff import exponential_backoff_with_jitter
from veyra._utils._transform import to_jsonable
from veyra._version import __version__

DEFAULT_BASE_URL = "https://veyra.tubox.cloud"
DEFAULT_TIMEOUT = httpx.Timeout(timeout=60.0, connect=5.0)
DEFAULT_MAX_RETRIES = 2

HttpxClientT = TypeVar("HttpxClientT", httpx.Client, httpx.AsyncClient)
ModelT = TypeVar("ModelT", bound=BaseModel)
ResponseT = TypeVar("ResponseT")


class BaseClient(Generic[HttpxClientT]):
    """Shared configuration and response utilities for sync/async clients."""

    api_key: str
    base_url: httpx.URL
    timeout: httpx.Timeout
    max_retries: int
    _http: HttpxClientT

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | httpx.Timeout | None = None,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        resolved_key = api_key or os.environ.get("VEYRA_API_KEY", "")
        resolved_base_url = base_url or os.environ.get("VEYRA_BASE_URL", DEFAULT_BASE_URL)

        if not resolved_key:
            request = httpx.Request("GET", resolved_base_url)
            raise AuthenticationError(
                "No API key provided. Pass api_key=... or set VEYRA_API_KEY.",
                code="missing_api_key",
                status_code=401,
                request=request,
                response=None,
            )

        self.api_key = resolved_key
        self.base_url = httpx.URL(resolved_base_url)
        self.timeout = self._coerce_timeout(timeout)
        self.max_retries = max_retries
        self._default_headers = default_headers or {}
        self._raw_response_mode = False

    def _coerce_timeout(self, timeout: float | httpx.Timeout | None) -> httpx.Timeout:
        if isinstance(timeout, (int, float)):
            return httpx.Timeout(timeout)
        if timeout is None:
            return DEFAULT_TIMEOUT
        return timeout

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.api_key}"}

    def _build_headers(self, extra: dict[str, str] | None = None) -> dict[str, str]:
        return {
            "User-Agent": f"veyra-python/{__version__}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            **self._auth_headers(),
            **self._default_headers,
            **(extra or {}),
        }

    def _build_url(self, path: str) -> httpx.URL:
        if path.startswith("http://") or path.startswith("https://"):
            return httpx.URL(path)
        normalized = path if path.startswith("/") else f"/{path}"
        return self.base_url.join(normalized)

    def _parse_json(self, response: httpx.Response) -> dict[str, object] | list[object]:
        if not response.content:
            return {}
        try:
            parsed = response.json()
        except ValueError:
            return {}

        if isinstance(parsed, (dict, list)):
            return parsed
        return {}

    def _parse_error_body(self, response: httpx.Response) -> dict[str, object]:
        parsed = self._parse_json(response)
        if isinstance(parsed, dict):
            return parsed
        return {
            "error": {
                "code": "invalid_error_payload",
                "message": "Unexpected error payload from server.",
            }
        }

    def _raise_for_error(self, response: httpx.Response) -> None:
        body = self._parse_error_body(response)
        raise make_api_error(request=response.request, response=response, body=body)

    def _cast(self, cast_to: type[ModelT], response: httpx.Response) -> ModelT:
        payload = self._parse_json(response)
        return cast_to.model_validate(payload)

    def _cast_list(self, cast_to: type[ModelT], response: httpx.Response) -> list[ModelT]:
        payload = self._parse_json(response)
        if not isinstance(payload, list):
            raise APIError(
                "Expected list response payload.",
                code="invalid_response_shape",
                status_code=response.status_code,
                request=response.request,
                response=response,
            )
        return [cast_to.model_validate(item) for item in payload]

    def _wrap_response(
        self, data: ResponseT, response: httpx.Response
    ) -> ResponseT | APIResponse[ResponseT]:
        if not self._raw_response_mode:
            return data
        return APIResponse(
            data=data,
            request_id=response.headers.get("X-Request-ID"),
            http_status=response.status_code,
            headers=response.headers,
        )

    def _wrap_list_response(
        self, data: list[ModelT], response: httpx.Response
    ) -> list[ModelT] | APIResponse[list[ModelT]]:
        return cast(
            Union[list[ModelT], APIResponse[list[ModelT]]],
            self._wrap_response(data, response),
        )

    def _should_retry(self, response: httpx.Response | None, attempt: int) -> bool:
        if attempt >= self.max_retries:
            return False
        if response is None:
            return True
        return response.status_code in {429, 500, 502, 503, 504}

    def _retry_delay(self, response: httpx.Response | None, attempt: int) -> float:
        if response is not None:
            retry_after = response.headers.get("Retry-After")
            if retry_after is not None:
                try:
                    return max(0.0, float(retry_after))
                except ValueError:
                    try:
                        dt = parsedate_to_datetime(retry_after)
                        now = datetime.now(timezone.utc)
                        if dt.tzinfo is None:
                            dt = dt.replace(tzinfo=timezone.utc)
                        return max(0.0, dt.timestamp() - now.timestamp())
                    except (TypeError, ValueError):
                        pass
        return exponential_backoff_with_jitter(attempt)

    def _request_json_body(self, body: object | None) -> object | None:
        if body is None:
            return None
        return to_jsonable(body)
