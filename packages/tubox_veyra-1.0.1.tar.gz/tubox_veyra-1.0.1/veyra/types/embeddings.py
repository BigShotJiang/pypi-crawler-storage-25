from __future__ import annotations

from typing import Literal

from veyra.types._base import VeyraModel
from veyra.types.shared import Usage


class EmbeddingData(VeyraModel):
    object: Literal["embedding"]
    embedding: list[float]
    index: int


class EmbeddingResponse(VeyraModel):
    object: Literal["list"]
    data: list[EmbeddingData]
    model: str
    usage: Usage
