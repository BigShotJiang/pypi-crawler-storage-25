from __future__ import annotations

from pydantic import ConfigDict

from veyra.types._base import VeyraModel


class Usage(VeyraModel):
    prompt_tokens: int
    prompt_tokens_details: dict[str, object] | None = None
    completion_tokens: int
    completion_tokens_details: dict[str, object] | None = None
    total_tokens: int


class InputTokenDetails(VeyraModel):
    cached_tokens: int | None = None


class OutputTokenDetails(VeyraModel):
    reasoning_tokens: int | None = None


class ResponseUsage(VeyraModel):
    input_tokens: int
    input_tokens_details: InputTokenDetails | None = None
    output_tokens: int
    output_tokens_details: OutputTokenDetails | None = None
    total_tokens: int


class ErrorDetail(VeyraModel):
    model_config = ConfigDict(extra="allow")
    loc: list[str | int]
    msg: str
    type: str


class ErrorEnvelope(VeyraModel):
    code: str
    message: str
    details: list[ErrorDetail] | None = None


class GenericMap(VeyraModel):
    values: dict[str, object] = {}
