from __future__ import annotations

from veyra.types._base import VeyraModel


class HealthStatus(VeyraModel):
    status: str
    app: str | None = None
    version: str | None = None
    environment: str | None = None


class ReadinessStatus(VeyraModel):
    status: str
    checks: dict[str, str]


class WaitlistSignup(VeyraModel):
    message: str
    already_joined: bool
    signup_id: str
    created_at: str


class SupportContact(VeyraModel):
    message: str
    ticket_id: str
