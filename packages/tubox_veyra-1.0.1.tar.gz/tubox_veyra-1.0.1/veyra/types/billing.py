from __future__ import annotations

from veyra.types._base import VeyraModel


class UsageRecord(VeyraModel):
    id: str | None = None
    created_at: str
    model: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    status_code: int | None = None
    request_id: str | None = None


class UsageSummary(VeyraModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    request_count: int
    cached_tokens: int | None = None
    total_cost_usd: float | None = None


class BillingProfile(VeyraModel):
    billing_email: str
    full_name: str
    company_name: str | None = None
    country_code: str
    line1: str
    line2: str | None = None
    city: str
    state_region: str
    postal_code: str
    tax_id: str | None = None
    card_brand: str | None = None
    card_last4: str | None = None
    card_exp_month: int | None = None
    card_exp_year: int | None = None


class BillingProfileUpsert(VeyraModel):
    billing_email: str
    full_name: str
    company_name: str | None = None
    country_code: str
    line1: str
    line2: str | None = None
    city: str
    state_region: str
    postal_code: str
    tax_id: str | None = None
    card_brand: str | None = None
    card_last4: str | None = None
    card_exp_month: int | None = None
    card_exp_year: int | None = None


class BillingAccess(VeyraModel):
    plan: str
    billing_required: bool
    can_use_models: bool
    reason: str | None = None
