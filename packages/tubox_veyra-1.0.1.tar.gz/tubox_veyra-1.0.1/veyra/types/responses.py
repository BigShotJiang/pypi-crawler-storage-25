from __future__ import annotations

import builtins
from typing import Literal

from pydantic import Field, field_validator

from veyra.types._base import VeyraModel
from veyra.types.shared import ResponseUsage


class ResponseOutputContent(VeyraModel):
    type: str
    text: str | None = None
    annotations: list[dict[str, builtins.object]] = Field(default_factory=list)
    summary: list[dict[str, builtins.object]] | None = None


class ResponseOutputTextContent(ResponseOutputContent):
    type: Literal["output_text"]
    text: str


class ResponseOutputItem(VeyraModel):
    id: str
    type: str
    status: str | None = None
    role: str | None = None
    content: list[ResponseOutputContent] = Field(default_factory=list)

    @field_validator("content", mode="before")
    @classmethod
    def _coerce_null_content(cls, value: object) -> object:
        return [] if value is None else value


class ResponseError(VeyraModel):
    code: str | None = None
    message: str | None = None


class Response(VeyraModel):
    id: str
    object: str
    created_at: float | int
    error: ResponseError | None = None
    incomplete_details: dict[str, builtins.object] | None = None
    instructions: str | None = None
    metadata: dict[str, builtins.object] | None = None
    model: str
    output: list[ResponseOutputItem] = Field(default_factory=list)
    parallel_tool_calls: bool | None = None
    temperature: float | None = None
    tool_choice: str | None = None
    tools: list[dict[str, builtins.object]] = Field(default_factory=list)
    top_p: float | None = None
    max_output_tokens: int | None = None
    reasoning: dict[str, builtins.object] | None = None
    truncation: str | None = None
    status: str | None = None
    user: str | None = None
    usage: ResponseUsage | None = None


class ResponseStreamEvent(VeyraModel):
    type: str
    response: Response | None = None
    delta: str | None = None
    item_id: str | None = None
    output_index: int | None = None
    content_index: int | None = None
    text: str | None = None
    status: str | None = None
    usage: ResponseUsage | None = None
    data: dict[str, builtins.object] | None = None
