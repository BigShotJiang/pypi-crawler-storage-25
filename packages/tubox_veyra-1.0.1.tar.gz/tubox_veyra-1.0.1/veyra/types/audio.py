from __future__ import annotations

from veyra.types._base import VeyraModel


class AudioTranscription(VeyraModel):
    text: str
