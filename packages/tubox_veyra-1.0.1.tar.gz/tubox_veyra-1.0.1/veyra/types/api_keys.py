from __future__ import annotations

from veyra.types._base import VeyraModel


class APIKey(VeyraModel):
    id: str
    name: str
    key_prefix: str
    scopes: list[str]
    ip_whitelist: list[str] | None = None
    is_active: bool | None = None
    created_at: str | None = None
    last_used_at: str | None = None
    expires_at: str | None = None
    revoked_at: str | None = None
    usage_count: int | None = None
    rate_limit_override: int | None = None


class APIKeyCreate(VeyraModel):
    name: str
    scopes: list[str]
    ip_whitelist: list[str] | None = None
    expires_in_days: int | None = None


class APIKeyUpdate(VeyraModel):
    name: str | None = None
    scopes: list[str] | None = None
    ip_whitelist: list[str] | None = None
    rate_limit_override: int | None = None
    expires_in_days: int | None = None


class APIKeyCreateResponse(VeyraModel):
    id: str
    name: str
    key: str
    key_prefix: str
    scopes: list[str]
    created_at: str
