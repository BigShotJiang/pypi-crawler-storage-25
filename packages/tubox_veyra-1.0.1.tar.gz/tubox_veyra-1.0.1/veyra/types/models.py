from __future__ import annotations

from typing import Literal

from veyra.types._base import VeyraModel


class ModelInfo(VeyraModel):
    id: str
    object: Literal["model"]
    created: int
    owned_by: str


class ModelList(VeyraModel):
    object: Literal["list"]
    data: list[ModelInfo]
