from __future__ import annotations

from veyra.types._base import VeyraModel


class QuotaLimits(VeyraModel):
    daily_tokens: int
    daily_requests: int
    rpm: int
    tpm: int
    max_context_tokens: int
    max_output_tokens: int


class QuotaUsage(VeyraModel):
    tokens_used_today: int
    tokens_remaining_today: int
    requests_used_today: int
    requests_remaining_today: int
    percentage_used: float


class QuotaStatus(VeyraModel):
    plan: str
    limits: QuotaLimits
    usage: QuotaUsage
    resets_at: str
    time_until_reset: str


class QuotaPlan(VeyraModel):
    name: str
    description: str | None = None
    is_active: bool = True
    limits: QuotaLimits | None = None
