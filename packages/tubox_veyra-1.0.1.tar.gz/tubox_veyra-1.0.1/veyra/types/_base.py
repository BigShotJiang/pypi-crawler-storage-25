from __future__ import annotations

from typing import cast

from pydantic import BaseModel, ConfigDict


class VeyraModel(BaseModel):
    """Base model for all SDK response types."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    def model_dump(self, *args: object, **kwargs: object) -> dict[str, object]:
        kwargs.setdefault("exclude_none", True)
        return cast(
            dict[str, object],
            super().model_dump(*args, **kwargs),  # type: ignore[arg-type]
        )

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.model_dump()!r})"
