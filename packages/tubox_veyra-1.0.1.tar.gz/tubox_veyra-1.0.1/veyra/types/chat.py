from __future__ import annotations

import builtins
from typing import Literal, Union

from typing_extensions import TypeAlias, TypedDict

from veyra.types._base import VeyraModel
from veyra.types.shared import Usage

ChatCompletionMessageContent: TypeAlias = Union[
    str,
    list[dict[str, builtins.object]],
    None,
]


class ChatCompletionSystemMessageParam(TypedDict):
    role: Literal["system"]
    content: ChatCompletionMessageContent


class ChatCompletionDeveloperMessageParam(TypedDict):
    role: Literal["developer"]
    content: ChatCompletionMessageContent


class ChatCompletionUserMessageParam(TypedDict):
    role: Literal["user"]
    content: ChatCompletionMessageContent


class ChatCompletionAssistantMessageParam(TypedDict, total=False):
    role: Literal["assistant"]
    content: ChatCompletionMessageContent
    tool_calls: list[dict[str, builtins.object]]


class ChatCompletionToolMessageParam(TypedDict):
    role: Literal["tool"]
    content: ChatCompletionMessageContent
    tool_call_id: str


class ChatCompletionFunctionMessageParam(TypedDict):
    role: Literal["function"]
    content: ChatCompletionMessageContent
    name: str


class ChatCompletionGenericMessageParam(TypedDict, total=False):
    role: str
    content: builtins.object
    name: str
    tool_call_id: str
    tool_calls: list[dict[str, builtins.object]]


ChatCompletionMessageParam: TypeAlias = Union[
    ChatCompletionSystemMessageParam,
    ChatCompletionDeveloperMessageParam,
    ChatCompletionUserMessageParam,
    ChatCompletionAssistantMessageParam,
    ChatCompletionToolMessageParam,
    ChatCompletionFunctionMessageParam,
    ChatCompletionGenericMessageParam,
]


class ChatCompletionMessage(VeyraModel):
    role: str
    content: str | None = None
    refusal: str | None = None
    tool_calls: list[dict[str, builtins.object]] | None = None


class Choice(VeyraModel):
    index: int
    message: ChatCompletionMessage
    finish_reason: str | None = None
    logprobs: dict[str, builtins.object] | None = None


class ChatCompletion(VeyraModel):
    id: str
    object: str
    created: int
    model: str
    choices: list[Choice]
    usage: Usage | None = None
    system_fingerprint: str | None = None


class ChoiceDelta(VeyraModel):
    role: str | None = None
    content: str | None = None
    refusal: str | None = None
    tool_calls: list[dict[str, builtins.object]] | None = None
    reasoning_content: str | None = None


class StreamChoice(VeyraModel):
    index: int
    delta: ChoiceDelta
    finish_reason: str | None = None


class ChatCompletionChunk(VeyraModel):
    id: str
    object: str
    created: int
    model: str
    choices: list[StreamChoice]
    usage: Usage | None = None
