from __future__ import annotations

from typing import Literal

from veyra.types._base import VeyraModel
from veyra.types.shared import Usage


class TextCompletionChoice(VeyraModel):
    text: str
    index: int
    logprobs: dict[str, str] | None = None
    finish_reason: str | None = None


class TextCompletion(VeyraModel):
    id: str
    object: Literal["text_completion"]
    created: int
    model: str
    choices: list[TextCompletionChoice]
    usage: Usage | None = None


class TextCompletionChunkChoice(VeyraModel):
    text: str
    index: int
    logprobs: dict[str, str] | None = None
    finish_reason: str | None = None


class TextCompletionChunk(VeyraModel):
    id: str
    object: Literal["text_completion"]
    created: int
    model: str
    choices: list[TextCompletionChunkChoice]
    usage: Usage | None = None
