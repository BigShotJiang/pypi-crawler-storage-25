from __future__ import annotations

from veyra.types._base import VeyraModel


class ImageData(VeyraModel):
    url: str | None = None
    b64_json: str | None = None
    revised_prompt: str | None = None


class ImageGenerationResponse(VeyraModel):
    created: int
    data: list[ImageData]
