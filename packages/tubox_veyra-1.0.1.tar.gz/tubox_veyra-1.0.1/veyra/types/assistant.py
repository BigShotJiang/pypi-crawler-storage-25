from __future__ import annotations

from typing_extensions import TypedDict

from veyra.types._base import VeyraModel


class AssistantHistoryMessage(TypedDict):
    role: str
    content: str


class AssistantResponse(VeyraModel):
    answer: str
    model: str
    references: list[str]
    blocked: bool
    requires_login: bool
    scope_limited: bool


class AssistantStreamEvent(VeyraModel):
    type: str
    delta: str | None = None
    answer: str | None = None
    model: str | None = None
    references: list[str] | None = None
    blocked: bool | None = None
    requires_login: bool | None = None
    scope_limited: bool | None = None
