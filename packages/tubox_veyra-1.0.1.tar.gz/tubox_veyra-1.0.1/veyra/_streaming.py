from __future__ import annotations

import json
from collections.abc import AsyncIterator, Iterator
from typing import Generic, TypeVar, cast

import httpx
from pydantic import BaseModel

from veyra._exceptions import APIError, ProviderUnavailableError, StreamConsumedError

T = TypeVar("T", bound=BaseModel)


class Stream(Generic[T]):
    """Wrap an SSE response and yield typed events."""

    __slots__ = ("response", "_cast_to", "_client", "_closed", "_consumed")

    def __init__(self, *, response: httpx.Response, cast_to: type[T], client: object) -> None:
        self.response = response
        self._cast_to = cast_to
        self._client = client
        self._closed = False
        self._consumed = False

    def __iter__(self) -> Iterator[T]:
        if self._closed or self._consumed:
            raise StreamConsumedError("Stream has already been consumed.")
        self._consumed = True

        try:
            for line in self.response.iter_lines():
                text = line.decode("utf-8") if isinstance(line, bytes) else line
                parsed = self._parse_sse_line(text)
                if parsed is _DONE:
                    break
                if parsed is None:
                    continue
                yield cast(T, parsed)
        finally:
            self.close()

    def __enter__(self) -> Stream[T]:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        if not self._closed:
            self.response.close()
            self._closed = True

    def _parse_sse_line(self, line: str) -> T | _DoneSentinel | None:
        stripped = line.strip()
        if not stripped:
            return None
        if not stripped.startswith("data:"):
            return None

        data = stripped[5:].strip()
        if data == "[DONE]":
            return _DONE

        try:
            payload = json.loads(data)
        except json.JSONDecodeError as exc:
            raise APIError(
                "Failed to decode stream chunk.",
                code="stream_decode_error",
                status_code=self.response.status_code,
                request=self.response.request,
                response=self.response,
            ) from exc

        if (
            isinstance(payload, dict)
            and payload.get("object") == ""
            and isinstance(payload.get("choices"), list)
            and len(payload.get("choices", [])) == 0
        ):
            return None

        if isinstance(payload, dict) and "error" in payload:
            error = payload.get("error")
            if isinstance(error, dict):
                code = error.get("code")
                message = str(error.get("message") or "Streaming request failed")
            else:
                code = None
                message = "Streaming request failed"

            if code in {"provider_unavailable", "provider_error"}:
                raise ProviderUnavailableError(
                    message,
                    code=code,
                    status_code=503,
                    request=self.response.request,
                    response=self.response,
                )

            raise APIError(
                message,
                code=code,
                status_code=self.response.status_code,
                request=self.response.request,
                response=self.response,
            )

        return self._cast_to.model_validate(payload)


class AsyncStream(Generic[T]):
    """Async SSE wrapper yielding typed events."""

    __slots__ = ("response", "_cast_to", "_client", "_closed", "_consumed")

    def __init__(self, *, response: httpx.Response, cast_to: type[T], client: object) -> None:
        self.response = response
        self._cast_to = cast_to
        self._client = client
        self._closed = False
        self._consumed = False

    def __aiter__(self) -> AsyncIterator[T]:
        return self._iter_chunks()

    async def _iter_chunks(self) -> AsyncIterator[T]:
        if self._closed or self._consumed:
            raise StreamConsumedError("Stream has already been consumed.")
        self._consumed = True

        try:
            async for line in self.response.aiter_lines():
                parsed = self._parse_sse_line(line)
                if parsed is _DONE:
                    break
                if parsed is None:
                    continue
                yield cast(T, parsed)
        finally:
            await self.aclose()

    async def __aenter__(self) -> AsyncStream[T]:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if not self._closed:
            await self.response.aclose()
            self._closed = True

    def _parse_sse_line(self, line: str) -> T | _DoneSentinel | None:
        stripped = line.strip()
        if not stripped:
            return None
        if not stripped.startswith("data:"):
            return None

        data = stripped[5:].strip()
        if data == "[DONE]":
            return _DONE

        try:
            payload = json.loads(data)
        except json.JSONDecodeError as exc:
            raise APIError(
                "Failed to decode stream chunk.",
                code="stream_decode_error",
                status_code=self.response.status_code,
                request=self.response.request,
                response=self.response,
            ) from exc

        if (
            isinstance(payload, dict)
            and payload.get("object") == ""
            and isinstance(payload.get("choices"), list)
            and len(payload.get("choices", [])) == 0
        ):
            return None

        if isinstance(payload, dict) and "error" in payload:
            error = payload.get("error")
            if isinstance(error, dict):
                code = error.get("code")
                message = str(error.get("message") or "Streaming request failed")
            else:
                code = None
                message = "Streaming request failed"

            if code in {"provider_unavailable", "provider_error"}:
                raise ProviderUnavailableError(
                    message,
                    code=code,
                    status_code=503,
                    request=self.response.request,
                    response=self.response,
                )

            raise APIError(
                message,
                code=code,
                status_code=self.response.status_code,
                request=self.response.request,
                response=self.response,
            )

        return self._cast_to.model_validate(payload)


class _DoneSentinel:
    pass


_DONE = _DoneSentinel()
