from __future__ import annotations

from typing import cast

from veyra._streaming import AsyncStream, Stream
from veyra.types.chat import ChatCompletion, ChatCompletionChunk


def collect_stream(stream: Stream[ChatCompletionChunk]) -> ChatCompletion:
    """Collect a streaming chat completion into a ChatCompletion model."""

    completion_id = ""
    created = 0
    model = ""
    choices: dict[int, dict[str, object]] = {}
    usage: dict[str, object] | None = None

    for chunk in stream:
        completion_id = chunk.id or completion_id
        created = chunk.created or created
        model = chunk.model or model

        if chunk.usage is not None:
            usage = chunk.usage.model_dump(exclude_none=True)

        for piece in chunk.choices:
            state = choices.setdefault(
                piece.index,
                {
                    "index": piece.index,
                    "message": {"role": "assistant", "content": ""},
                    "finish_reason": None,
                },
            )

            if piece.delta.role is not None:
                message = cast(dict[str, str], state["message"])
                message["role"] = piece.delta.role
            if piece.delta.content is not None:
                message = cast(dict[str, str], state["message"])
                message["content"] += piece.delta.content
            if piece.finish_reason is not None:
                state["finish_reason"] = piece.finish_reason

    payload = {
        "id": completion_id,
        "object": "chat.completion",
        "created": created,
        "model": model,
        "choices": [choices[idx] for idx in sorted(choices.keys())],
        "usage": usage,
    }
    return ChatCompletion.model_validate(payload)


async def aio_collect_stream(stream: AsyncStream[ChatCompletionChunk]) -> ChatCompletion:
    """Async version of :func:`collect_stream`."""

    completion_id = ""
    created = 0
    model = ""
    choices: dict[int, dict[str, object]] = {}
    usage: dict[str, object] | None = None

    async for chunk in stream:
        completion_id = chunk.id or completion_id
        created = chunk.created or created
        model = chunk.model or model

        if chunk.usage is not None:
            usage = chunk.usage.model_dump(exclude_none=True)

        for piece in chunk.choices:
            state = choices.setdefault(
                piece.index,
                {
                    "index": piece.index,
                    "message": {"role": "assistant", "content": ""},
                    "finish_reason": None,
                },
            )

            if piece.delta.role is not None:
                message = cast(dict[str, str], state["message"])
                message["role"] = piece.delta.role
            if piece.delta.content is not None:
                message = cast(dict[str, str], state["message"])
                message["content"] += piece.delta.content
            if piece.finish_reason is not None:
                state["finish_reason"] = piece.finish_reason

    payload = {
        "id": completion_id,
        "object": "chat.completion",
        "created": created,
        "model": model,
        "choices": [choices[idx] for idx in sorted(choices.keys())],
        "usage": usage,
    }
    return ChatCompletion.model_validate(payload)
