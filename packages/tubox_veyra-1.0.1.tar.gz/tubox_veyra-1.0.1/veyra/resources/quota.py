from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from veyra.types.quota import QuotaPlan, QuotaStatus

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Quota:
    """Quota sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def status(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> QuotaStatus:
        response = self._client._request(
            "GET",
            "/v1/quota/status",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(QuotaStatus, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def list_plans(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> list[QuotaPlan]:
        response = self._client._request(
            "GET",
            "/v1/quota/plans",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast_list(QuotaPlan, response)
        wrapped = self._client._wrap_list_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def list_public_plans(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> list[QuotaPlan]:
        response = self._client._request(
            "GET",
            "/v1/quota/plans/public",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast_list(QuotaPlan, response)
        wrapped = self._client._wrap_list_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncQuota:
    """Quota async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def status(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> QuotaStatus:
        response = await self._client._request(
            "GET",
            "/v1/quota/status",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(QuotaStatus, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def list_plans(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> list[QuotaPlan]:
        response = await self._client._request(
            "GET",
            "/v1/quota/plans",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast_list(QuotaPlan, response)
        wrapped = self._client._wrap_list_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def list_public_plans(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> list[QuotaPlan]:
        response = await self._client._request(
            "GET",
            "/v1/quota/plans/public",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast_list(QuotaPlan, response)
        wrapped = self._client._wrap_list_response(parsed, response)
        return wrapped  # type: ignore[return-value]
