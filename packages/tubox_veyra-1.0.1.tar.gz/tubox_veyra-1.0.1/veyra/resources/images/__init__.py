from __future__ import annotations

from typing import TYPE_CHECKING

from veyra.resources.images.generations import AsyncGenerations, Generations

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Images:
    """Images namespace."""

    def __init__(self, client: Veyra) -> None:
        self.generations = Generations(client)


class AsyncImages:
    """Async images namespace."""

    def __init__(self, client: AsyncVeyra) -> None:
        self.generations = AsyncGenerations(client)


__all__ = ["Images", "AsyncImages", "Generations", "AsyncGenerations"]
