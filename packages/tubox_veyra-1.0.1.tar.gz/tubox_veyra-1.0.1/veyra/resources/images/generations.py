from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from veyra._utils._transform import strip_none
from veyra._utils._validate import validate_image_generation
from veyra.types.images import ImageGenerationResponse

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Generations:
    """Image generation sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def create(
        self,
        *,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        quality: str = "standard",
        response_format: str = "url",
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ImageGenerationResponse:
        validate_image_generation(n=n, size=size, quality=quality)
        body = strip_none(
            {
                "model": model,
                "prompt": prompt,
                "n": n,
                "size": size,
                "quality": quality,
                "response_format": response_format,
            }
        )
        response = self._client._request(
            "POST",
            "/v1/images/generations",
            body=body,
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(ImageGenerationResponse, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncGenerations:
    """Image generation async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def create(
        self,
        *,
        model: str,
        prompt: str,
        n: int = 1,
        size: str = "1024x1024",
        quality: str = "standard",
        response_format: str = "url",
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ImageGenerationResponse:
        validate_image_generation(n=n, size=size, quality=quality)
        body = strip_none(
            {
                "model": model,
                "prompt": prompt,
                "n": n,
                "size": size,
                "quality": quality,
                "response_format": response_format,
            }
        )
        response = await self._client._request(
            "POST",
            "/v1/images/generations",
            body=body,
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(ImageGenerationResponse, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
