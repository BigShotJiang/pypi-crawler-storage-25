from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from veyra._pagination import AsyncPage, SyncPage
from veyra.types.billing import UsageRecord, UsageSummary

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Usage:
    """Billing usage sync sub-resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def list(
        self,
        *,
        since: str | None = None,
        until: str | None = None,
        model: str | None = None,
        offset: int = 0,
        limit: int = 50,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> SyncPage[UsageRecord]:
        return self._fetch_page(
            since=since,
            until=until,
            model=model,
            offset=offset,
            limit=limit,
            extra_headers=extra_headers,
            timeout=timeout,
        )

    def _fetch_page(
        self,
        *,
        since: str | None,
        until: str | None,
        model: str | None,
        offset: int,
        limit: int,
        extra_headers: dict[str, str] | None,
        timeout: float | httpx.Timeout | None,
    ) -> SyncPage[UsageRecord]:
        params = {
            "since": since,
            "until": until,
            "model": model,
            "offset": offset,
            "limit": limit,
        }
        response = self._client._request(
            "GET",
            "/v1/billing/usage",
            params=params,
            headers=extra_headers,
            timeout=timeout,
        )

        payload = self._client._parse_json(response)
        items: list[UsageRecord]
        total: int
        has_more: bool
        next_offset: int | None

        if isinstance(payload, list):
            items = [UsageRecord.model_validate(item) for item in payload]
            header_total = response.headers.get("X-Total-Count")
            if header_total is not None and header_total.isdigit():
                total = int(header_total)
            else:
                total = offset + len(items)
            has_more = len(items) == limit and (offset + len(items)) < total
            next_offset = offset + len(items) if has_more else None
        else:
            raw_items_obj = (
                payload.get("data", payload.get("items", [])) if isinstance(payload, dict) else []
            )
            raw_items = raw_items_obj if isinstance(raw_items_obj, list) else []
            items = [UsageRecord.model_validate(item) for item in raw_items]
            total = len(items)
            if isinstance(payload, dict):
                raw_total = payload.get("total", offset + len(items))
                if isinstance(raw_total, int):
                    total = raw_total
                elif isinstance(raw_total, str) and raw_total.isdigit():
                    total = int(raw_total)
                else:
                    total = offset + len(items)
            has_more = (
                bool(payload.get("has_more", (offset + len(items)) < total))
                if isinstance(payload, dict)
                else False
            )
            next_offset = None
            if isinstance(payload, dict):
                raw_next_offset = payload.get("next_offset")
                if isinstance(raw_next_offset, int):
                    next_offset = raw_next_offset
                elif isinstance(raw_next_offset, str) and raw_next_offset.isdigit():
                    next_offset = int(raw_next_offset)
            if next_offset is None and has_more:
                next_offset = offset + len(items)

        def fetcher(next_value: int, page_limit: int) -> SyncPage[UsageRecord] | None:
            if next_value < 0:
                return None
            return self._fetch_page(
                since=since,
                until=until,
                model=model,
                offset=next_value,
                limit=page_limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )

        return SyncPage(
            items=items,
            total=total,
            offset=offset,
            limit=limit,
            has_more=has_more,
            next_offset=next_offset,
            fetcher=fetcher,
        )

    def daily_summary(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> UsageSummary:
        response = self._client._request(
            "GET",
            "/v1/billing/usage/summary/daily",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(UsageSummary, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def monthly_summary(
        self,
        *,
        year: int | None = None,
        month: int | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> UsageSummary:
        response = self._client._request(
            "GET",
            "/v1/billing/usage/summary/monthly",
            params={"year": year, "month": month},
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(UsageSummary, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def conversation_summary(
        self,
        conversation_id: str,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> UsageSummary:
        response = self._client._request(
            "GET",
            f"/v1/billing/usage/conversations/{conversation_id}/summary",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(UsageSummary, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncUsage:
    """Billing usage async sub-resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def list(
        self,
        *,
        since: str | None = None,
        until: str | None = None,
        model: str | None = None,
        offset: int = 0,
        limit: int = 50,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AsyncPage[UsageRecord]:
        return await self._fetch_page(
            since=since,
            until=until,
            model=model,
            offset=offset,
            limit=limit,
            extra_headers=extra_headers,
            timeout=timeout,
        )

    async def _fetch_page(
        self,
        *,
        since: str | None,
        until: str | None,
        model: str | None,
        offset: int,
        limit: int,
        extra_headers: dict[str, str] | None,
        timeout: float | httpx.Timeout | None,
    ) -> AsyncPage[UsageRecord]:
        params = {
            "since": since,
            "until": until,
            "model": model,
            "offset": offset,
            "limit": limit,
        }
        response = await self._client._request(
            "GET",
            "/v1/billing/usage",
            params=params,
            headers=extra_headers,
            timeout=timeout,
        )

        payload = self._client._parse_json(response)
        items: list[UsageRecord]
        total: int
        has_more: bool
        next_offset: int | None

        if isinstance(payload, list):
            items = [UsageRecord.model_validate(item) for item in payload]
            header_total = response.headers.get("X-Total-Count")
            if header_total is not None and header_total.isdigit():
                total = int(header_total)
            else:
                total = offset + len(items)
            has_more = len(items) == limit and (offset + len(items)) < total
            next_offset = offset + len(items) if has_more else None
        else:
            raw_items_obj = (
                payload.get("data", payload.get("items", [])) if isinstance(payload, dict) else []
            )
            raw_items = raw_items_obj if isinstance(raw_items_obj, list) else []
            items = [UsageRecord.model_validate(item) for item in raw_items]
            total = len(items)
            if isinstance(payload, dict):
                raw_total = payload.get("total", offset + len(items))
                if isinstance(raw_total, int):
                    total = raw_total
                elif isinstance(raw_total, str) and raw_total.isdigit():
                    total = int(raw_total)
                else:
                    total = offset + len(items)
            has_more = (
                bool(payload.get("has_more", (offset + len(items)) < total))
                if isinstance(payload, dict)
                else False
            )
            next_offset = None
            if isinstance(payload, dict):
                raw_next_offset = payload.get("next_offset")
                if isinstance(raw_next_offset, int):
                    next_offset = raw_next_offset
                elif isinstance(raw_next_offset, str) and raw_next_offset.isdigit():
                    next_offset = int(raw_next_offset)
            if next_offset is None and has_more:
                next_offset = offset + len(items)

        async def fetcher(next_value: int, page_limit: int) -> AsyncPage[UsageRecord] | None:
            if next_value < 0:
                return None
            return await self._fetch_page(
                since=since,
                until=until,
                model=model,
                offset=next_value,
                limit=page_limit,
                extra_headers=extra_headers,
                timeout=timeout,
            )

        return AsyncPage(
            items=items,
            total=total,
            offset=offset,
            limit=limit,
            has_more=has_more,
            next_offset=next_offset,
            fetcher=fetcher,
        )

    async def daily_summary(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> UsageSummary:
        response = await self._client._request(
            "GET",
            "/v1/billing/usage/summary/daily",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(UsageSummary, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def monthly_summary(
        self,
        *,
        year: int | None = None,
        month: int | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> UsageSummary:
        response = await self._client._request(
            "GET",
            "/v1/billing/usage/summary/monthly",
            params={"year": year, "month": month},
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(UsageSummary, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def conversation_summary(
        self,
        conversation_id: str,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> UsageSummary:
        response = await self._client._request(
            "GET",
            f"/v1/billing/usage/conversations/{conversation_id}/summary",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(UsageSummary, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
