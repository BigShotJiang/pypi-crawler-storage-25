from __future__ import annotations

from typing import TYPE_CHECKING

from veyra.resources.billing.profile import AsyncProfile, Profile
from veyra.resources.billing.usage import AsyncUsage, Usage

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Billing:
    """Billing namespace."""

    def __init__(self, client: Veyra) -> None:
        self.usage = Usage(client)
        self.profile = Profile(client)


class AsyncBilling:
    """Async billing namespace."""

    def __init__(self, client: AsyncVeyra) -> None:
        self.usage = AsyncUsage(client)
        self.profile = AsyncProfile(client)


__all__ = ["Billing", "AsyncBilling", "Usage", "AsyncUsage", "Profile", "AsyncProfile"]
