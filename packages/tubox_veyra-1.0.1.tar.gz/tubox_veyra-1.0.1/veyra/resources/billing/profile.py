from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from veyra._utils._transform import strip_none
from veyra.types.billing import BillingAccess, BillingProfile

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Profile:
    """Billing profile sync sub-resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def retrieve(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> BillingProfile | None:
        response = self._client._request(
            "GET",
            "/v1/billing/profile",
            headers=extra_headers,
            timeout=timeout,
        )
        payload = self._client._parse_json(response)
        if isinstance(payload, dict) and payload == {}:
            return None
        parsed = BillingProfile.model_validate(payload)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def upsert(
        self,
        *,
        billing_email: str,
        full_name: str,
        country_code: str,
        line1: str,
        city: str,
        state_region: str,
        postal_code: str,
        company_name: str | None = None,
        line2: str | None = None,
        tax_id: str | None = None,
        card_brand: str | None = None,
        card_last4: str | None = None,
        card_exp_month: int | None = None,
        card_exp_year: int | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> BillingProfile:
        body = strip_none(
            {
                "billing_email": billing_email,
                "full_name": full_name,
                "company_name": company_name,
                "country_code": country_code,
                "line1": line1,
                "line2": line2,
                "city": city,
                "state_region": state_region,
                "postal_code": postal_code,
                "tax_id": tax_id,
                "card_brand": card_brand,
                "card_last4": card_last4,
                "card_exp_month": card_exp_month,
                "card_exp_year": card_exp_year,
            }
        )
        response = self._client._request(
            "PUT",
            "/v1/billing/profile",
            body=body,
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(BillingProfile, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def access(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> BillingAccess:
        response = self._client._request(
            "GET",
            "/v1/billing/access",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(BillingAccess, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncProfile:
    """Billing profile async sub-resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def retrieve(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> BillingProfile | None:
        response = await self._client._request(
            "GET",
            "/v1/billing/profile",
            headers=extra_headers,
            timeout=timeout,
        )
        payload = self._client._parse_json(response)
        if isinstance(payload, dict) and payload == {}:
            return None
        parsed = BillingProfile.model_validate(payload)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def upsert(
        self,
        *,
        billing_email: str,
        full_name: str,
        country_code: str,
        line1: str,
        city: str,
        state_region: str,
        postal_code: str,
        company_name: str | None = None,
        line2: str | None = None,
        tax_id: str | None = None,
        card_brand: str | None = None,
        card_last4: str | None = None,
        card_exp_month: int | None = None,
        card_exp_year: int | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> BillingProfile:
        body = strip_none(
            {
                "billing_email": billing_email,
                "full_name": full_name,
                "company_name": company_name,
                "country_code": country_code,
                "line1": line1,
                "line2": line2,
                "city": city,
                "state_region": state_region,
                "postal_code": postal_code,
                "tax_id": tax_id,
                "card_brand": card_brand,
                "card_last4": card_last4,
                "card_exp_month": card_exp_month,
                "card_exp_year": card_exp_year,
            }
        )
        response = await self._client._request(
            "PUT",
            "/v1/billing/profile",
            body=body,
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(BillingProfile, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def access(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> BillingAccess:
        response = await self._client._request(
            "GET",
            "/v1/billing/access",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(BillingAccess, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
