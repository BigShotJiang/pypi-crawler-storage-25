from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from veyra.types.misc import HealthStatus, ReadinessStatus

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Health:
    """Health sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def check(self, *, timeout: float | httpx.Timeout | None = None) -> HealthStatus:
        response = self._client._request("GET", "/health", timeout=timeout)
        parsed = self._client._cast(HealthStatus, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def ready(self, *, timeout: float | httpx.Timeout | None = None) -> ReadinessStatus:
        response = self._client._request("GET", "/health/ready", timeout=timeout)
        parsed = self._client._cast(ReadinessStatus, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncHealth:
    """Health async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def check(self, *, timeout: float | httpx.Timeout | None = None) -> HealthStatus:
        response = await self._client._request("GET", "/health", timeout=timeout)
        parsed = self._client._cast(HealthStatus, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def ready(self, *, timeout: float | httpx.Timeout | None = None) -> ReadinessStatus:
        response = await self._client._request("GET", "/health/ready", timeout=timeout)
        parsed = self._client._cast(ReadinessStatus, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
