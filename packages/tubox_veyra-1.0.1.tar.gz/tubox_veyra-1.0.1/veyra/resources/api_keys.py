from __future__ import annotations

import builtins
from typing import TYPE_CHECKING

import httpx

from veyra._utils._transform import strip_none
from veyra.types.api_keys import APIKey, APIKeyCreateResponse

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class APIKeys:
    """API key management sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def create(
        self,
        *,
        name: str,
        scopes: builtins.list[str],
        ip_whitelist: builtins.list[str] | None = None,
        expires_in_days: int | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> APIKeyCreateResponse:
        body = strip_none(
            {
                "name": name,
                "scopes": scopes,
                "ip_whitelist": ip_whitelist,
                "expires_in_days": expires_in_days,
            }
        )
        response = self._client._request(
            "POST", "/v1/api-keys", body=body, headers=extra_headers, timeout=timeout
        )
        parsed = self._client._cast(APIKeyCreateResponse, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def list(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> builtins.list[APIKey]:
        response = self._client._request(
            "GET", "/v1/api-keys", headers=extra_headers, timeout=timeout
        )
        parsed = self._client._cast_list(APIKey, response)
        wrapped = self._client._wrap_list_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def update(
        self,
        key_id: str,
        *,
        name: str | None = None,
        scopes: builtins.list[str] | None = None,
        ip_whitelist: builtins.list[str] | None = None,
        rate_limit_override: int | None = None,
        expires_in_days: int | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> APIKey:
        body = strip_none(
            {
                "name": name,
                "scopes": scopes,
                "ip_whitelist": ip_whitelist,
                "rate_limit_override": rate_limit_override,
                "expires_in_days": expires_in_days,
            }
        )
        response = self._client._request(
            "PATCH",
            f"/v1/api-keys/{key_id}",
            body=body,
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(APIKey, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def revoke(
        self,
        key_id: str,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> None:
        self._client._request(
            "DELETE",
            f"/v1/api-keys/{key_id}",
            headers=extra_headers,
            timeout=timeout,
        )
        return None


class AsyncAPIKeys:
    """API key management async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def create(
        self,
        *,
        name: str,
        scopes: builtins.list[str],
        ip_whitelist: builtins.list[str] | None = None,
        expires_in_days: int | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> APIKeyCreateResponse:
        body = strip_none(
            {
                "name": name,
                "scopes": scopes,
                "ip_whitelist": ip_whitelist,
                "expires_in_days": expires_in_days,
            }
        )
        response = await self._client._request(
            "POST", "/v1/api-keys", body=body, headers=extra_headers, timeout=timeout
        )
        parsed = self._client._cast(APIKeyCreateResponse, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def list(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> builtins.list[APIKey]:
        response = await self._client._request(
            "GET", "/v1/api-keys", headers=extra_headers, timeout=timeout
        )
        parsed = self._client._cast_list(APIKey, response)
        wrapped = self._client._wrap_list_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def update(
        self,
        key_id: str,
        *,
        name: str | None = None,
        scopes: builtins.list[str] | None = None,
        ip_whitelist: builtins.list[str] | None = None,
        rate_limit_override: int | None = None,
        expires_in_days: int | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> APIKey:
        body = strip_none(
            {
                "name": name,
                "scopes": scopes,
                "ip_whitelist": ip_whitelist,
                "rate_limit_override": rate_limit_override,
                "expires_in_days": expires_in_days,
            }
        )
        response = await self._client._request(
            "PATCH",
            f"/v1/api-keys/{key_id}",
            body=body,
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(APIKey, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def revoke(
        self,
        key_id: str,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> None:
        await self._client._request(
            "DELETE",
            f"/v1/api-keys/{key_id}",
            headers=extra_headers,
            timeout=timeout,
        )
        return None
