from __future__ import annotations

from typing import TYPE_CHECKING

from veyra.resources.chat.completions import AsyncCompletions, Completions

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Chat:
    """Chat namespace."""

    def __init__(self, client: Veyra) -> None:
        self.completions = Completions(client)


class AsyncChat:
    """Async chat namespace."""

    def __init__(self, client: AsyncVeyra) -> None:
        self.completions = AsyncCompletions(client)


__all__ = ["Chat", "AsyncChat", "Completions", "AsyncCompletions"]
