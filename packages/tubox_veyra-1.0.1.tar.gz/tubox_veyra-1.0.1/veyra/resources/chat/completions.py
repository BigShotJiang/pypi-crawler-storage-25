from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import TYPE_CHECKING, Literal, cast, overload

import httpx

from veyra._streaming import AsyncStream, Stream
from veyra._utils._transform import strip_none
from veyra.types.chat import (
    ChatCompletion,
    ChatCompletionChunk,
    ChatCompletionMessageParam,
)

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Completions:
    """Chat completions sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    @overload
    def create(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        stream: Literal[False] = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_completion_tokens: int | None = None,
        stop: str | list[str] | None = None,
        frequency_penalty: float | None = None,
        presence_penalty: float | None = None,
        response_format: Mapping[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        stream_options: Mapping[str, object] | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        seed: int | None = None,
        n: int | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ChatCompletion: ...

    @overload
    def create(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        stream: Literal[True],
        temperature: float | None = None,
        top_p: float | None = None,
        max_completion_tokens: int | None = None,
        stop: str | list[str] | None = None,
        frequency_penalty: float | None = None,
        presence_penalty: float | None = None,
        response_format: Mapping[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        stream_options: Mapping[str, object] | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        seed: int | None = None,
        n: int | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Stream[ChatCompletionChunk]: ...

    def create(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        stream: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_completion_tokens: int | None = None,
        stop: str | list[str] | None = None,
        frequency_penalty: float | None = None,
        presence_penalty: float | None = None,
        response_format: Mapping[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        stream_options: Mapping[str, object] | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        seed: int | None = None,
        n: int | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ChatCompletion | Stream[ChatCompletionChunk]:
        body = self._build_body(
            model=model,
            messages=messages,
            stream=stream,
            temperature=temperature,
            top_p=top_p,
            max_completion_tokens=max_completion_tokens,
            stop=stop,
            frequency_penalty=frequency_penalty,
            presence_penalty=presence_penalty,
            response_format=response_format,
            reasoning=reasoning,
            parallel_tool_calls=parallel_tool_calls,
            truncation=truncation,
            tools=tools,
            tool_choice=tool_choice,
            metadata=metadata,
            stream_options=stream_options,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            seed=seed,
            n=n,
            user=user,
            extra_body=extra_body,
        )

        response = self._client._request(
            "POST",
            "/v1/chat/completions",
            body=body,
            headers=extra_headers,
            stream=stream,
            timeout=timeout,
        )
        if stream:
            return Stream(response=response, cast_to=ChatCompletionChunk, client=self._client)

        parsed = self._client._cast(ChatCompletion, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def _build_body(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        stream: bool,
        temperature: float | None,
        top_p: float | None,
        max_completion_tokens: int | None,
        stop: str | list[str] | None,
        frequency_penalty: float | None,
        presence_penalty: float | None,
        response_format: Mapping[str, object] | None,
        reasoning: Mapping[str, object] | None,
        parallel_tool_calls: bool | None,
        truncation: str | None,
        tools: Iterable[Mapping[str, object]] | None,
        tool_choice: str | Mapping[str, object] | None,
        metadata: Mapping[str, object] | None,
        stream_options: Mapping[str, object] | None,
        logprobs: bool | None,
        top_logprobs: int | None,
        seed: int | None,
        n: int | None,
        user: str | None,
        extra_body: Mapping[str, object] | None,
    ) -> dict[str, object]:
        body: dict[str, object] = {
            "model": model,
            "messages": list(messages),
            "stream": stream,
            "temperature": temperature,
            "top_p": top_p,
            "max_completion_tokens": max_completion_tokens,
            "stop": stop,
            "frequency_penalty": frequency_penalty,
            "presence_penalty": presence_penalty,
            "response_format": dict(response_format) if response_format is not None else None,
            "reasoning": dict(reasoning) if reasoning is not None else None,
            "parallel_tool_calls": parallel_tool_calls,
            "truncation": truncation,
            "tools": [dict(tool) for tool in tools] if tools is not None else None,
            "tool_choice": dict(tool_choice) if isinstance(tool_choice, Mapping) else tool_choice,
            "metadata": dict(metadata) if metadata is not None else None,
            "stream_options": dict(stream_options) if stream_options is not None else None,
            "logprobs": logprobs,
            "top_logprobs": top_logprobs,
            "seed": seed,
            "n": n,
            "user": user,
        }
        if extra_body is not None:
            body.update(dict(extra_body))
        return cast(dict[str, object], strip_none(body))


class AsyncCompletions:
    """Chat completions async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    @overload
    async def create(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        stream: Literal[False] = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_completion_tokens: int | None = None,
        stop: str | list[str] | None = None,
        frequency_penalty: float | None = None,
        presence_penalty: float | None = None,
        response_format: Mapping[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        stream_options: Mapping[str, object] | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        seed: int | None = None,
        n: int | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ChatCompletion: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        stream: Literal[True],
        temperature: float | None = None,
        top_p: float | None = None,
        max_completion_tokens: int | None = None,
        stop: str | list[str] | None = None,
        frequency_penalty: float | None = None,
        presence_penalty: float | None = None,
        response_format: Mapping[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        stream_options: Mapping[str, object] | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        seed: int | None = None,
        n: int | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AsyncStream[ChatCompletionChunk]: ...

    async def create(
        self,
        *,
        model: str,
        messages: Iterable[ChatCompletionMessageParam],
        stream: bool = False,
        temperature: float | None = None,
        top_p: float | None = None,
        max_completion_tokens: int | None = None,
        stop: str | list[str] | None = None,
        frequency_penalty: float | None = None,
        presence_penalty: float | None = None,
        response_format: Mapping[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        stream_options: Mapping[str, object] | None = None,
        logprobs: bool | None = None,
        top_logprobs: int | None = None,
        seed: int | None = None,
        n: int | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ChatCompletion | AsyncStream[ChatCompletionChunk]:
        body = {
            "model": model,
            "messages": list(messages),
            "stream": stream,
            "temperature": temperature,
            "top_p": top_p,
            "max_completion_tokens": max_completion_tokens,
            "stop": stop,
            "frequency_penalty": frequency_penalty,
            "presence_penalty": presence_penalty,
            "response_format": dict(response_format) if response_format is not None else None,
            "reasoning": dict(reasoning) if reasoning is not None else None,
            "parallel_tool_calls": parallel_tool_calls,
            "truncation": truncation,
            "tools": [dict(tool) for tool in tools] if tools is not None else None,
            "tool_choice": dict(tool_choice) if isinstance(tool_choice, Mapping) else tool_choice,
            "metadata": dict(metadata) if metadata is not None else None,
            "stream_options": dict(stream_options) if stream_options is not None else None,
            "logprobs": logprobs,
            "top_logprobs": top_logprobs,
            "seed": seed,
            "n": n,
            "user": user,
        }
        if extra_body is not None:
            body.update(dict(extra_body))
        body = cast(dict[str, object], strip_none(body))

        response = await self._client._request(
            "POST",
            "/v1/chat/completions",
            body=body,
            headers=extra_headers,
            stream=stream,
            timeout=timeout,
        )
        if stream:
            return AsyncStream(response=response, cast_to=ChatCompletionChunk, client=self._client)

        parsed = self._client._cast(ChatCompletion, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
