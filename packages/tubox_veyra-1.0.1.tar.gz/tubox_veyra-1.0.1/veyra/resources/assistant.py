from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Literal, overload

import httpx

from veyra._streaming import AsyncStream, Stream
from veyra._utils._transform import strip_none
from veyra.types.assistant import AssistantHistoryMessage, AssistantResponse, AssistantStreamEvent

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Assistant:
    """Assistant sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    @overload
    def chat(
        self,
        *,
        message: str,
        history: Sequence[AssistantHistoryMessage] | None = None,
        stream: Literal[False] = False,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AssistantResponse: ...

    @overload
    def chat(
        self,
        *,
        message: str,
        history: Sequence[AssistantHistoryMessage] | None = None,
        stream: Literal[True],
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Stream[AssistantStreamEvent]: ...

    def chat(
        self,
        *,
        message: str,
        history: Sequence[AssistantHistoryMessage] | None = None,
        stream: bool = False,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AssistantResponse | Stream[AssistantStreamEvent]:
        body = strip_none({"message": message, "history": history, "stream": stream})
        response = self._client._request(
            "POST",
            "/v1/assistant/chat",
            body=body,
            headers=extra_headers,
            stream=stream,
            timeout=timeout,
        )

        if stream:
            return Stream(response=response, cast_to=AssistantStreamEvent, client=self._client)

        parsed = self._client._cast(AssistantResponse, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncAssistant:
    """Assistant async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    @overload
    async def chat(
        self,
        *,
        message: str,
        history: Sequence[AssistantHistoryMessage] | None = None,
        stream: Literal[False] = False,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AssistantResponse: ...

    @overload
    async def chat(
        self,
        *,
        message: str,
        history: Sequence[AssistantHistoryMessage] | None = None,
        stream: Literal[True],
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AsyncStream[AssistantStreamEvent]: ...

    async def chat(
        self,
        *,
        message: str,
        history: Sequence[AssistantHistoryMessage] | None = None,
        stream: bool = False,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AssistantResponse | AsyncStream[AssistantStreamEvent]:
        body = strip_none({"message": message, "history": history, "stream": stream})
        response = await self._client._request(
            "POST",
            "/v1/assistant/chat",
            body=body,
            headers=extra_headers,
            stream=stream,
            timeout=timeout,
        )

        if stream:
            return AsyncStream(response=response, cast_to=AssistantStreamEvent, client=self._client)

        parsed = self._client._cast(AssistantResponse, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
