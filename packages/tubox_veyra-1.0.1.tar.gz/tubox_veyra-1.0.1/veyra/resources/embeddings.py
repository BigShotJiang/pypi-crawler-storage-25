from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING

import httpx

from veyra._utils._transform import strip_none
from veyra._utils._validate import validate_embeddings_input
from veyra.types.embeddings import EmbeddingResponse

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Embeddings:
    """Embeddings sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def create(
        self,
        *,
        model: str,
        input: str | Sequence[str],
        encoding_format: str = "float",
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> EmbeddingResponse:
        validate_embeddings_input(input)
        body = strip_none(
            {
                "model": model,
                "input": input,
                "encoding_format": encoding_format,
            }
        )
        response = self._client._request(
            "POST",
            "/v1/embeddings",
            body=body,
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(EmbeddingResponse, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncEmbeddings:
    """Embeddings async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def create(
        self,
        *,
        model: str,
        input: str | Sequence[str],
        encoding_format: str = "float",
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> EmbeddingResponse:
        validate_embeddings_input(input)
        body = strip_none(
            {
                "model": model,
                "input": input,
                "encoding_format": encoding_format,
            }
        )
        response = await self._client._request(
            "POST",
            "/v1/embeddings",
            body=body,
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(EmbeddingResponse, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
