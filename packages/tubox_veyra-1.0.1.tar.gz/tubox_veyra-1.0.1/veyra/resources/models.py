from __future__ import annotations

from typing import TYPE_CHECKING

import httpx

from veyra.types.models import ModelInfo, ModelList

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Models:
    """Models sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def list(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ModelList:
        response = self._client._request(
            "GET", "/v1/models", headers=extra_headers, timeout=timeout
        )
        parsed = self._client._cast(ModelList, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def retrieve(
        self,
        model_id: str,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ModelInfo:
        response = self._client._request(
            "GET",
            f"/v1/models/{model_id}",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(ModelInfo, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncModels:
    """Models async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def list(
        self,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ModelList:
        response = await self._client._request(
            "GET", "/v1/models", headers=extra_headers, timeout=timeout
        )
        parsed = self._client._cast(ModelList, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    async def retrieve(
        self,
        model_id: str,
        *,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> ModelInfo:
        response = await self._client._request(
            "GET",
            f"/v1/models/{model_id}",
            headers=extra_headers,
            timeout=timeout,
        )
        parsed = self._client._cast(ModelInfo, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
