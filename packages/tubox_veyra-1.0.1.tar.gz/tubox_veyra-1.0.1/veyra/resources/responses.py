from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from typing import TYPE_CHECKING, Literal, Union, cast, overload

import httpx
from typing_extensions import TypeAlias

from veyra._streaming import AsyncStream, Stream
from veyra._utils._transform import strip_none
from veyra.types.responses import Response, ResponseStreamEvent

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


ResponseInput: TypeAlias = Union[
    str,
    Mapping[str, object],
    Sequence[Union[str, Mapping[str, object]]],
]


class Responses:
    """Responses API sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    @overload
    def create(
        self,
        *,
        model: str,
        input: ResponseInput,
        instructions: str | None = None,
        stream: Literal[False] = False,
        max_output_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        response_format: dict[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        include: Sequence[str] | None = None,
        store: bool | None = None,
        previous_response_id: str | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Response: ...

    @overload
    def create(
        self,
        *,
        model: str,
        input: ResponseInput,
        instructions: str | None = None,
        stream: Literal[True],
        max_output_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        response_format: dict[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        include: Sequence[str] | None = None,
        store: bool | None = None,
        previous_response_id: str | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Stream[ResponseStreamEvent]: ...

    def create(
        self,
        *,
        model: str,
        input: ResponseInput,
        instructions: str | None = None,
        stream: bool = False,
        max_output_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        response_format: dict[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        include: Sequence[str] | None = None,
        store: bool | None = None,
        previous_response_id: str | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Response | Stream[ResponseStreamEvent]:
        body = self._build_body(
            model=model,
            input=input,
            instructions=instructions,
            stream=stream,
            max_output_tokens=max_output_tokens,
            temperature=temperature,
            top_p=top_p,
            response_format=response_format,
            reasoning=reasoning,
            parallel_tool_calls=parallel_tool_calls,
            truncation=truncation,
            tools=tools,
            tool_choice=tool_choice,
            metadata=metadata,
            include=include,
            store=store,
            previous_response_id=previous_response_id,
            user=user,
            extra_body=extra_body,
        )

        response = self._client._request(
            "POST",
            "/v1/responses",
            body=body,
            headers=extra_headers,
            stream=stream,
            timeout=timeout,
        )

        if stream:
            return Stream(response=response, cast_to=ResponseStreamEvent, client=self._client)

        parsed = self._client._cast(Response, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]

    def _build_body(
        self,
        *,
        model: str,
        input: ResponseInput,
        instructions: str | None,
        stream: bool,
        max_output_tokens: int | None,
        temperature: float | None,
        top_p: float | None,
        response_format: Mapping[str, object] | None,
        reasoning: Mapping[str, object] | None,
        parallel_tool_calls: bool | None,
        truncation: str | None,
        tools: Iterable[Mapping[str, object]] | None,
        tool_choice: str | Mapping[str, object] | None,
        metadata: Mapping[str, object] | None,
        include: Sequence[str] | None,
        store: bool | None,
        previous_response_id: str | None,
        user: str | None,
        extra_body: Mapping[str, object] | None,
    ) -> dict[str, object]:
        body: dict[str, object] = {
            "model": model,
            "input": input,
            "instructions": instructions,
            "stream": stream,
            "max_output_tokens": max_output_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "response_format": dict(response_format) if response_format is not None else None,
            "reasoning": dict(reasoning) if reasoning is not None else None,
            "parallel_tool_calls": parallel_tool_calls,
            "truncation": truncation,
            "tools": [dict(tool) for tool in tools] if tools is not None else None,
            "tool_choice": dict(tool_choice) if isinstance(tool_choice, Mapping) else tool_choice,
            "metadata": dict(metadata) if metadata is not None else None,
            "include": list(include) if include is not None else None,
            "store": store,
            "previous_response_id": previous_response_id,
            "user": user,
        }
        if extra_body is not None:
            body.update(dict(extra_body))
        return cast(dict[str, object], strip_none(body))


class AsyncResponses:
    """Responses API async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    @overload
    async def create(
        self,
        *,
        model: str,
        input: ResponseInput,
        instructions: str | None = None,
        stream: Literal[False] = False,
        max_output_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        response_format: dict[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        include: Sequence[str] | None = None,
        store: bool | None = None,
        previous_response_id: str | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Response: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        input: ResponseInput,
        instructions: str | None = None,
        stream: Literal[True],
        max_output_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        response_format: dict[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        include: Sequence[str] | None = None,
        store: bool | None = None,
        previous_response_id: str | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AsyncStream[ResponseStreamEvent]: ...

    async def create(
        self,
        *,
        model: str,
        input: ResponseInput,
        instructions: str | None = None,
        stream: bool = False,
        max_output_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        response_format: dict[str, object] | None = None,
        reasoning: Mapping[str, object] | None = None,
        parallel_tool_calls: bool | None = None,
        truncation: str | None = None,
        tools: Iterable[Mapping[str, object]] | None = None,
        tool_choice: str | Mapping[str, object] | None = None,
        metadata: Mapping[str, object] | None = None,
        include: Sequence[str] | None = None,
        store: bool | None = None,
        previous_response_id: str | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Response | AsyncStream[ResponseStreamEvent]:
        body: dict[str, object] = {
            "model": model,
            "input": input,
            "instructions": instructions,
            "stream": stream,
            "max_output_tokens": max_output_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "response_format": dict(response_format) if response_format is not None else None,
            "reasoning": dict(reasoning) if reasoning is not None else None,
            "parallel_tool_calls": parallel_tool_calls,
            "truncation": truncation,
            "tools": [dict(tool) for tool in tools] if tools is not None else None,
            "tool_choice": dict(tool_choice) if isinstance(tool_choice, Mapping) else tool_choice,
            "metadata": dict(metadata) if metadata is not None else None,
            "include": list(include) if include is not None else None,
            "store": store,
            "previous_response_id": previous_response_id,
            "user": user,
        }
        if extra_body is not None:
            body.update(dict(extra_body))
        body = cast(dict[str, object], strip_none(body))

        response = await self._client._request(
            "POST",
            "/v1/responses",
            body=body,
            headers=extra_headers,
            stream=stream,
            timeout=timeout,
        )

        if stream:
            return AsyncStream(response=response, cast_to=ResponseStreamEvent, client=self._client)

        parsed = self._client._cast(Response, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
