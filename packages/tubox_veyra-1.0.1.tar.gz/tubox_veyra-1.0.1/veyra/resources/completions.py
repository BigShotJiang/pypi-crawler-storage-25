from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Literal, cast, overload

import httpx

from veyra._exceptions import VeyraError
from veyra._streaming import AsyncStream, Stream
from veyra._utils._transform import strip_none
from veyra._utils._validate import validate_legacy_prompt
from veyra.types.completions import TextCompletion, TextCompletionChunk

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Completions:
    """Legacy text completions sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    @overload
    def create(
        self,
        *,
        model: str,
        prompt: str | Sequence[str],
        stream: Literal[False] = False,
        max_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        stop: str | list[str] | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> TextCompletion: ...

    @overload
    def create(
        self,
        *,
        model: str,
        prompt: str | Sequence[str],
        stream: Literal[True],
        max_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        stop: str | list[str] | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> Stream[TextCompletionChunk]: ...

    def create(
        self,
        *,
        model: str,
        prompt: str | Sequence[str],
        stream: bool = False,
        max_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        stop: str | list[str] | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> TextCompletion | Stream[TextCompletionChunk]:
        validate_legacy_prompt(prompt)

        prompt_value: str | Sequence[str]
        if isinstance(prompt, str):
            prompt_value = prompt
        else:
            if len(prompt) != 1:
                raise VeyraError("Multi-prompt arrays are not supported.")
            prompt_value = prompt[0]

        body: dict[str, object] = {
            "model": model,
            "prompt": prompt_value,
            "stream": stream,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "stop": stop,
            "user": user,
        }
        if extra_body is not None:
            body.update(dict(extra_body))
        body = cast(dict[str, object], strip_none(body))

        response = self._client._request(
            "POST",
            "/v1/completions",
            body=body,
            headers=extra_headers,
            stream=stream,
            timeout=timeout,
        )
        if stream:
            return Stream(response=response, cast_to=TextCompletionChunk, client=self._client)

        parsed = self._client._cast(TextCompletion, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncCompletions:
    """Legacy text completions async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    @overload
    async def create(
        self,
        *,
        model: str,
        prompt: str | Sequence[str],
        stream: Literal[False] = False,
        max_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        stop: str | list[str] | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> TextCompletion: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        prompt: str | Sequence[str],
        stream: Literal[True],
        max_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        stop: str | list[str] | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AsyncStream[TextCompletionChunk]: ...

    async def create(
        self,
        *,
        model: str,
        prompt: str | Sequence[str],
        stream: bool = False,
        max_tokens: int | None = None,
        temperature: float | None = None,
        top_p: float | None = None,
        stop: str | list[str] | None = None,
        user: str | None = None,
        extra_body: Mapping[str, object] | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> TextCompletion | AsyncStream[TextCompletionChunk]:
        validate_legacy_prompt(prompt)

        prompt_value: str | Sequence[str]
        if isinstance(prompt, str):
            prompt_value = prompt
        else:
            if len(prompt) != 1:
                raise VeyraError("Multi-prompt arrays are not supported.")
            prompt_value = prompt[0]

        body: dict[str, object] = {
            "model": model,
            "prompt": prompt_value,
            "stream": stream,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "stop": stop,
            "user": user,
        }
        if extra_body is not None:
            body.update(dict(extra_body))
        body = cast(dict[str, object], strip_none(body))

        response = await self._client._request(
            "POST",
            "/v1/completions",
            body=body,
            headers=extra_headers,
            stream=stream,
            timeout=timeout,
        )
        if stream:
            return AsyncStream(response=response, cast_to=TextCompletionChunk, client=self._client)

        parsed = self._client._cast(TextCompletion, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
