from __future__ import annotations

from typing import TYPE_CHECKING

from veyra.resources.audio.transcriptions import AsyncTranscriptions, Transcriptions

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra


class Audio:
    """Audio namespace."""

    def __init__(self, client: Veyra) -> None:
        self.transcriptions = Transcriptions(client)


class AsyncAudio:
    """Async audio namespace."""

    def __init__(self, client: AsyncVeyra) -> None:
        self.transcriptions = AsyncTranscriptions(client)


__all__ = ["Audio", "AsyncAudio", "Transcriptions", "AsyncTranscriptions"]
