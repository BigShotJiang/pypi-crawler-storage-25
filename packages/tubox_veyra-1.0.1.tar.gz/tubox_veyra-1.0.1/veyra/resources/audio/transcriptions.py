from __future__ import annotations

import io
import mimetypes
from pathlib import Path
from typing import IO, TYPE_CHECKING, Union

import httpx
from typing_extensions import TypeAlias

from veyra.types.audio import AudioTranscription

if TYPE_CHECKING:
    from veyra._client import AsyncVeyra, Veyra

UploadFile: TypeAlias = Union[IO[bytes], Path, tuple[str, IO[bytes], str]]
UploadData: TypeAlias = Union[bytes, str, IO[bytes]]


def _guess_content_type(name: str) -> str:
    guessed, _ = mimetypes.guess_type(name)
    return guessed or "application/octet-stream"


def _prepare_upload(file: UploadFile) -> tuple[str, UploadData, str]:
    if isinstance(file, Path):
        raw = file.read_bytes()
        return file.name, io.BytesIO(raw), _guess_content_type(file.name)

    if isinstance(file, tuple):
        filename, data, content_type = file
        return filename, data, content_type

    filename = getattr(file, "name", "audio.bin")
    filename_str = Path(str(filename)).name
    return filename_str, file, _guess_content_type(filename_str)


class Transcriptions:
    """Audio transcription sync resource."""

    def __init__(self, client: Veyra) -> None:
        self._client = client

    def create(
        self,
        *,
        file: UploadFile,
        model: str = "whisper-1",
        language: str | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AudioTranscription:
        filename, payload, content_type = _prepare_upload(file)
        files = {"file": (filename, payload, content_type)}
        form = {"model": model}
        if language is not None:
            form["language"] = language

        response = self._client._request(
            "POST",
            "/v1/audio/transcriptions",
            headers=extra_headers,
            files=files,
            form=form,
            timeout=timeout,
        )
        parsed = self._client._cast(AudioTranscription, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]


class AsyncTranscriptions:
    """Audio transcription async resource."""

    def __init__(self, client: AsyncVeyra) -> None:
        self._client = client

    async def create(
        self,
        *,
        file: UploadFile,
        model: str = "whisper-1",
        language: str | None = None,
        extra_headers: dict[str, str] | None = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> AudioTranscription:
        filename, payload, content_type = _prepare_upload(file)
        files = {"file": (filename, payload, content_type)}
        form = {"model": model}
        if language is not None:
            form["language"] = language

        response = await self._client._request(
            "POST",
            "/v1/audio/transcriptions",
            headers=extra_headers,
            files=files,
            form=form,
            timeout=timeout,
        )
        parsed = self._client._cast(AudioTranscription, response)
        wrapped = self._client._wrap_response(parsed, response)
        return wrapped  # type: ignore[return-value]
