from __future__ import annotations

import inspect
import time
from collections.abc import Awaitable, Callable, Mapping
from typing import IO, TYPE_CHECKING, Optional, Protocol, Union, cast

import anyio
import httpx
from typing_extensions import TypeAlias

from veyra._base_client import BaseClient
from veyra._exceptions import APIConnectionError, APITimeoutError

if TYPE_CHECKING:
    from veyra.resources.api_keys import APIKeys, AsyncAPIKeys
    from veyra.resources.assistant import Assistant, AsyncAssistant
    from veyra.resources.audio import AsyncAudio, Audio
    from veyra.resources.billing import AsyncBilling, Billing
    from veyra.resources.chat import AsyncChat, Chat
    from veyra.resources.completions import AsyncCompletions, Completions
    from veyra.resources.embeddings import AsyncEmbeddings, Embeddings
    from veyra.resources.health import AsyncHealth, Health
    from veyra.resources.images import AsyncImages, Images
    from veyra.resources.models import AsyncModels, Models
    from veyra.resources.quota import AsyncQuota, Quota
    from veyra.resources.responses import AsyncResponses, Responses

ParamValue: TypeAlias = Union[str, int, float, bool, None]
RequestParams: TypeAlias = Optional[Mapping[str, ParamValue]]
UploadData: TypeAlias = Union[bytes, str, IO[bytes]]
RequestFiles: TypeAlias = Optional[Mapping[str, tuple[str, UploadData, str]]]
RequestForm: TypeAlias = Optional[Mapping[str, str]]


class _RawModeClient(Protocol):
    _raw_response_mode: bool


def _strip_none_map(values: RequestParams) -> dict[str, ParamValue] | None:
    if values is None:
        return None
    compact: dict[str, ParamValue] = {
        key: value for key, value in values.items() if value is not None
    }
    return compact or None


class _RawResponseProxy:
    """Proxy that toggles raw response mode for one call chain."""

    __slots__ = ("_target", "_client")

    def __init__(self, *, target: object, client: _RawModeClient) -> None:
        self._target = target
        self._client = client

    def __getattr__(self, name: str) -> object:
        attr = getattr(self._target, name)

        if callable(attr):
            if inspect.iscoroutinefunction(attr):
                async_callable = cast(Callable[..., Awaitable[object]], attr)

                async def async_wrapper(*args: object, **kwargs: object) -> object:
                    prev = self._client._raw_response_mode
                    self._client._raw_response_mode = True
                    try:
                        return await async_callable(*args, **kwargs)
                    finally:
                        self._client._raw_response_mode = prev

                return async_wrapper

            sync_callable = cast(Callable[..., object], attr)

            def wrapper(*args: object, **kwargs: object) -> object:
                prev = self._client._raw_response_mode
                self._client._raw_response_mode = True
                try:
                    return sync_callable(*args, **kwargs)
                finally:
                    self._client._raw_response_mode = prev

            return wrapper

        primitive = (str, bytes, bool, int, float, type(None))
        if isinstance(attr, primitive):
            return attr

        return _RawResponseProxy(target=attr, client=self._client)


class Veyra(BaseClient[httpx.Client]):
    """Synchronous Veyra API client."""

    chat: Chat
    completions: Completions
    responses: Responses
    embeddings: Embeddings
    images: Images
    audio: Audio
    models: Models
    quota: Quota
    billing: Billing
    api_keys: APIKeys
    assistant: Assistant
    health: Health

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | httpx.Timeout | None = None,
        max_retries: int = 2,
        http_client: httpx.Client | httpx.BaseTransport | None = None,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
        )

        self._owns_http = False
        if isinstance(http_client, httpx.Client):
            self._http = http_client
        else:
            self._http = httpx.Client(
                base_url=str(self.base_url),
                timeout=self.timeout,
                transport=http_client,
                follow_redirects=False,
            )
            self._owns_http = True

        from veyra.resources import (
            api_keys,
            assistant,
            audio,
            billing,
            chat,
            completions,
            embeddings,
            health,
            images,
            models,
            quota,
            responses,
        )

        self.chat = chat.Chat(self)
        self.completions = completions.Completions(self)
        self.responses = responses.Responses(self)
        self.embeddings = embeddings.Embeddings(self)
        self.images = images.Images(self)
        self.audio = audio.Audio(self)
        self.models = models.Models(self)
        self.quota = quota.Quota(self)
        self.billing = billing.Billing(self)
        self.api_keys = api_keys.APIKeys(self)
        self.assistant = assistant.Assistant(self)
        self.health = health.Health(self)

    @property
    def with_raw_response(self) -> _RawResponseProxy:
        return _RawResponseProxy(target=self, client=self)

    def __enter__(self) -> Veyra:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def close(self) -> None:
        if self._owns_http:
            self._http.close()

    def _request(
        self,
        method: str,
        path: str,
        *,
        body: object | None = None,
        params: RequestParams = None,
        headers: dict[str, str] | None = None,
        stream: bool = False,
        files: RequestFiles = None,
        form: RequestForm = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> httpx.Response:
        request_timeout = self._coerce_timeout(timeout) if timeout is not None else self.timeout
        url = self._build_url(path)
        json_body = self._request_json_body(body)
        params_dict = _strip_none_map(params)

        attempt = 0
        while True:
            request_headers = self._build_headers(headers)
            if files is not None:
                request_headers.pop("Content-Type", None)

            try:
                if stream:
                    if files is not None:
                        request = self._http.build_request(
                            method,
                            url,
                            headers=request_headers,
                            params=params_dict,
                            files=files,
                            data=form,
                        )
                    else:
                        request = self._http.build_request(
                            method,
                            url,
                            headers=request_headers,
                            params=params_dict,
                            json=json_body,
                        )
                    request.extensions["timeout"] = request_timeout.as_dict()
                    response = self._http.send(request, stream=True)
                else:
                    if files is not None:
                        response = self._http.request(
                            method,
                            url,
                            headers=request_headers,
                            params=params_dict,
                            files=files,
                            data=form,
                            timeout=request_timeout,
                        )
                    else:
                        response = self._http.request(
                            method,
                            url,
                            headers=request_headers,
                            params=params_dict,
                            json=json_body,
                            timeout=request_timeout,
                        )
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                request = getattr(exc, "request", httpx.Request(method, url))
                if self._should_retry(None, attempt):
                    delay = self._retry_delay(None, attempt)
                    time.sleep(delay)
                    attempt += 1
                    continue
                if isinstance(exc, httpx.TimeoutException):
                    raise APITimeoutError("Request timed out.", request=request) from exc
                raise APIConnectionError("Request failed to connect.", request=request) from exc

            if response.status_code >= 400:
                if self._should_retry(response, attempt):
                    delay = self._retry_delay(response, attempt)
                    response.close()
                    time.sleep(delay)
                    attempt += 1
                    continue
                if stream:
                    response.read()
                self._raise_for_error(response)

            return response


class AsyncVeyra(BaseClient[httpx.AsyncClient]):
    """Asynchronous Veyra API client."""

    chat: AsyncChat
    completions: AsyncCompletions
    responses: AsyncResponses
    embeddings: AsyncEmbeddings
    images: AsyncImages
    audio: AsyncAudio
    models: AsyncModels
    quota: AsyncQuota
    billing: AsyncBilling
    api_keys: AsyncAPIKeys
    assistant: AsyncAssistant
    health: AsyncHealth

    def __init__(
        self,
        *,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float | httpx.Timeout | None = None,
        max_retries: int = 2,
        http_client: httpx.AsyncClient | httpx.AsyncBaseTransport | None = None,
        default_headers: dict[str, str] | None = None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
            default_headers=default_headers,
        )

        self._owns_http = False
        if isinstance(http_client, httpx.AsyncClient):
            self._http = http_client
        else:
            self._http = httpx.AsyncClient(
                base_url=str(self.base_url),
                timeout=self.timeout,
                transport=http_client,
                follow_redirects=False,
            )
            self._owns_http = True

        from veyra.resources import (
            api_keys,
            assistant,
            audio,
            billing,
            chat,
            completions,
            embeddings,
            health,
            images,
            models,
            quota,
            responses,
        )

        self.chat = chat.AsyncChat(self)
        self.completions = completions.AsyncCompletions(self)
        self.responses = responses.AsyncResponses(self)
        self.embeddings = embeddings.AsyncEmbeddings(self)
        self.images = images.AsyncImages(self)
        self.audio = audio.AsyncAudio(self)
        self.models = models.AsyncModels(self)
        self.quota = quota.AsyncQuota(self)
        self.billing = billing.AsyncBilling(self)
        self.api_keys = api_keys.AsyncAPIKeys(self)
        self.assistant = assistant.AsyncAssistant(self)
        self.health = health.AsyncHealth(self)

    @property
    def with_raw_response(self) -> _RawResponseProxy:
        return _RawResponseProxy(target=self, client=self)

    async def __aenter__(self) -> AsyncVeyra:
        return self

    async def __aexit__(self, *_: object) -> None:
        await self.aclose()

    async def aclose(self) -> None:
        if self._owns_http:
            await self._http.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        body: object | None = None,
        params: RequestParams = None,
        headers: dict[str, str] | None = None,
        stream: bool = False,
        files: RequestFiles = None,
        form: RequestForm = None,
        timeout: float | httpx.Timeout | None = None,
    ) -> httpx.Response:
        request_timeout = self._coerce_timeout(timeout) if timeout is not None else self.timeout
        url = self._build_url(path)
        json_body = self._request_json_body(body)
        params_dict = _strip_none_map(params)

        attempt = 0
        while True:
            request_headers = self._build_headers(headers)
            if files is not None:
                request_headers.pop("Content-Type", None)

            try:
                if stream:
                    if files is not None:
                        request = self._http.build_request(
                            method,
                            url,
                            headers=request_headers,
                            params=params_dict,
                            files=files,
                            data=form,
                        )
                    else:
                        request = self._http.build_request(
                            method,
                            url,
                            headers=request_headers,
                            params=params_dict,
                            json=json_body,
                        )
                    request.extensions["timeout"] = request_timeout.as_dict()
                    response = await self._http.send(request, stream=True)
                else:
                    if files is not None:
                        response = await self._http.request(
                            method,
                            url,
                            headers=request_headers,
                            params=params_dict,
                            files=files,
                            data=form,
                            timeout=request_timeout,
                        )
                    else:
                        response = await self._http.request(
                            method,
                            url,
                            headers=request_headers,
                            params=params_dict,
                            json=json_body,
                            timeout=request_timeout,
                        )
            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                request = getattr(exc, "request", httpx.Request(method, url))
                if self._should_retry(None, attempt):
                    delay = self._retry_delay(None, attempt)
                    await anyio.sleep(delay)
                    attempt += 1
                    continue
                if isinstance(exc, httpx.TimeoutException):
                    raise APITimeoutError("Request timed out.", request=request) from exc
                raise APIConnectionError("Request failed to connect.", request=request) from exc

            if response.status_code >= 400:
                if self._should_retry(response, attempt):
                    delay = self._retry_delay(response, attempt)
                    await response.aclose()
                    await anyio.sleep(delay)
                    attempt += 1
                    continue
                if stream:
                    await response.aread()
                self._raise_for_error(response)

            return response
