from __future__ import annotations

import asyncio
import json
import sys
from datetime import datetime, timezone
from typing import cast

import httpx

import veyra

MOCK_API_KEY = "veyra_sk_mock_ci"
MOCK_BASE_URL = "https://mock.api.veyra.local"
MOCK_MODEL = "gpt-5.4-mini"


class MockAPI:
    """In-memory mock API handler for SDK smoke tests."""

    def __init__(self) -> None:
        self.calls: dict[str, int] = {}

    def __call__(self, request: httpx.Request) -> httpx.Response:
        route = f"{request.method} {request.url.path}"
        self.calls[route] = self.calls.get(route, 0) + 1

        self._assert_headers(request)
        if request.method == "GET" and request.url.path == "/health":
            return httpx.Response(
                status_code=200,
                json={
                    "status": "ok",
                    "app": "veyra-api",
                    "version": "1.0.0-mock",
                    "environment": "test",
                },
                request=request,
                headers={"X-Request-ID": "req_mock_health"},
            )

        if request.method == "POST" and request.url.path == "/v1/chat/completions":
            payload = self._decode_json_body(request)
            self._assert_chat_request(payload)
            if bool(payload.get("stream", False)):
                return self._streaming_chat_response(request)
            return self._chat_response(request)

        return httpx.Response(
            status_code=404,
            json={"error": {"code": "not_found", "message": f"Unhandled route: {route}"}},
            request=request,
        )

    def _assert_headers(self, request: httpx.Request) -> None:
        auth = request.headers.get("Authorization")
        if auth != f"Bearer {MOCK_API_KEY}":
            raise AssertionError(f"Unexpected Authorization header: {auth!r}")

        user_agent = request.headers.get("User-Agent", "")
        if not user_agent.startswith("veyra-python/"):
            raise AssertionError(f"Unexpected User-Agent header: {user_agent!r}")

    def _decode_json_body(self, request: httpx.Request) -> dict[str, object]:
        if not request.content:
            return {}
        try:
            parsed = json.loads(request.content.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise AssertionError("Request body is not valid JSON.") from exc
        if not isinstance(parsed, dict):
            raise AssertionError("Expected a JSON object request body.")
        return cast(dict[str, object], parsed)

    def _assert_chat_request(self, payload: dict[str, object]) -> None:
        if payload.get("model") != MOCK_MODEL:
            raise AssertionError(f"Unexpected model: {payload.get('model')!r}")

        messages = payload.get("messages")
        if not isinstance(messages, list) or not messages:
            raise AssertionError("Expected non-empty messages list.")

    def _chat_response(self, request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            status_code=200,
            json={
                "id": "chatcmpl_mock_sync",
                "object": "chat.completion",
                "created": 1710000000,
                "model": MOCK_MODEL,
                "choices": [
                    {
                        "index": 0,
                        "message": {"role": "assistant", "content": "e2e-smoke-ok"},
                        "finish_reason": "stop",
                    }
                ],
                "usage": {"prompt_tokens": 8, "completion_tokens": 3, "total_tokens": 11},
            },
            request=request,
            headers={"X-Request-ID": "req_mock_chat"},
        )

    def _streaming_chat_response(self, request: httpx.Request) -> httpx.Response:
        lines = [
            (
                'data: {"id":"chatcmpl_mock_stream","object":"chat.completion.chunk",'
                '"created":1710000001,"model":"gpt-5.4-mini","choices":[{"index":0,'
                '"delta":{"role":"assistant","content":"e2e-"},"finish_reason":null}]}\n\n'
            ),
            (
                'data: {"id":"chatcmpl_mock_stream","object":"chat.completion.chunk",'
                '"created":1710000001,"model":"gpt-5.4-mini","choices":[{"index":0,'
                '"delta":{"content":"stream-ok"},"finish_reason":"stop"}],'
                '"usage":{"prompt_tokens":8,"completion_tokens":2,"total_tokens":10}}\n\n'
            ),
            "data: [DONE]\n\n",
        ]
        return httpx.Response(
            status_code=200,
            content="".join(lines).encode("utf-8"),
            request=request,
            headers={
                "Content-Type": "text/event-stream",
                "X-Request-ID": "req_mock_chat_stream",
            },
        )


def _run_sync_smoke() -> dict[str, object]:
    api = MockAPI()
    transport = httpx.MockTransport(api)

    with veyra.Veyra(
        api_key=MOCK_API_KEY,
        base_url=MOCK_BASE_URL,
        http_client=transport,
    ) as client:
        health = client.health.check()
        completion = client.chat.completions.create(
            model=MOCK_MODEL,
            messages=[{"role": "user", "content": "Reply exactly with: e2e-smoke-ok"}],
            max_completion_tokens=24,
        )
        completion_text = completion.choices[0].message.content or ""
        if completion_text != "e2e-smoke-ok":
            raise AssertionError(f"Unexpected chat text: {completion_text!r}")

        streamed_chunks: list[str] = []
        with client.chat.completions.create(
            model=MOCK_MODEL,
            messages=[{"role": "user", "content": "Reply exactly with: e2e-stream-ok"}],
            stream=True,
            max_completion_tokens=24,
        ) as stream:
            for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    streamed_chunks.append(chunk.choices[0].delta.content)

        stream_text = "".join(streamed_chunks)
        if stream_text != "e2e-stream-ok":
            raise AssertionError(f"Unexpected stream text: {stream_text!r}")

    return {
        "health.status": health.status,
        "chat.completions.create": completion_text,
        "chat.completions.stream": stream_text,
        "calls": api.calls,
    }


async def _run_async_smoke() -> dict[str, object]:
    api = MockAPI()
    transport = httpx.MockTransport(api)

    async with veyra.AsyncVeyra(
        api_key=MOCK_API_KEY,
        base_url=MOCK_BASE_URL,
        http_client=transport,
    ) as client:
        health = await client.health.check()
        completion = await client.chat.completions.create(
            model=MOCK_MODEL,
            messages=[{"role": "user", "content": "Reply exactly with: e2e-smoke-ok"}],
            max_completion_tokens=24,
        )
        completion_text = completion.choices[0].message.content or ""
        if completion_text != "e2e-smoke-ok":
            raise AssertionError(f"Unexpected async chat text: {completion_text!r}")

        streamed_chunks: list[str] = []
        async with await client.chat.completions.create(
            model=MOCK_MODEL,
            messages=[{"role": "user", "content": "Reply exactly with: e2e-stream-ok"}],
            stream=True,
            max_completion_tokens=24,
        ) as stream:
            async for chunk in stream:
                if chunk.choices and chunk.choices[0].delta.content:
                    streamed_chunks.append(chunk.choices[0].delta.content)

        stream_text = "".join(streamed_chunks)
        if stream_text != "e2e-stream-ok":
            raise AssertionError(f"Unexpected async stream text: {stream_text!r}")

    return {
        "health.status": health.status,
        "chat.completions.create": completion_text,
        "chat.completions.stream": stream_text,
        "calls": api.calls,
    }


def main() -> int:
    results: dict[str, object] = {
        "started_at": datetime.now(timezone.utc).isoformat(),
        "mode": "offline-mock",
        "base_url": MOCK_BASE_URL,
        "model": MOCK_MODEL,
    }
    try:
        results["sync"] = _run_sync_smoke()
        results["async"] = asyncio.run(_run_async_smoke())
        results["ok"] = True
        results["ended_at"] = datetime.now(timezone.utc).isoformat()
        print(json.dumps(results, indent=2))
        return 0
    except Exception as exc:  # noqa: BLE001
        results["ok"] = False
        results["ended_at"] = datetime.now(timezone.utc).isoformat()
        results["error"] = {"type": type(exc).__name__, "message": str(exc)}
        print(json.dumps(results, indent=2), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
