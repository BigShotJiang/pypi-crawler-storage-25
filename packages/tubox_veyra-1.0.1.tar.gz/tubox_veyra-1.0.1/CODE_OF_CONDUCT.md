# Code of Conduct

## Our Standards

Contributors are expected to be respectful, collaborative, and constructive.

Unacceptable behavior includes:

- Harassment or discriminatory language.
- Personal attacks or trolling.
- Publishing private information without consent.

## Enforcement

Project maintainers may remove, edit, or reject comments, commits, code, issues, and other contributions that violate this code.

## Reporting

Report conduct issues privately to:

- `maintainers@veyra.ai`
