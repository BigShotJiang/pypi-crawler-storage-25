# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.
import inspect
import math
import os
import platform
import random
import warnings
from collections.abc import Iterator
from typing import Any, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from packaging.version import InvalidVersion, Version

from featureform.proto import serving_pb2, serving_pb2_grpc

from .enums import DataResourceType, FileFormat
from .feature_view_processor import RealtimeFeatureExecutor
from .grpc_client import GrpcClient
from .register import FeatureColumnResource
from .resources import Model, TrainingSetVariant
from .tls import insecure_channel, secure_channel
from .train_test_split import TrainTestSplit
from .version import check_up_to_date


def check_python_version_compatibility(serialized_version: str) -> None:
    """
    Check Python version compatibility before deserializing a cloudpickle object.

    Cloudpickle objects serialized with one Python version may fail to deserialize
    or behave incorrectly when deserialized with a different version. This function
    checks the version and raises an error for incompatible versions.

    Args:
        serialized_version: The Python version string used during serialization
                           (e.g., "3.9.6"). Empty string is ignored for backwards
                           compatibility with older serializations.

    Raises:
        RuntimeError: If the minor version differs (e.g., 3.9 vs 3.10), as this
                     typically causes cloudpickle incompatibilities.

    Warns:
        UserWarning: If only the patch version differs (e.g., 3.9.6 vs 3.9.7),
                    as this may occasionally cause issues.
    """
    if not serialized_version:
        # No version stored (backwards compatibility with older serializations)
        return

    current_version = platform.python_version()

    # Parse versions using packaging library
    try:
        ser_ver = Version(serialized_version)
        cur_ver = Version(current_version)
    except InvalidVersion:
        # Invalid version format, skip check
        warnings.warn(
            f"Could not parse Python version '{serialized_version}'. "
            f"Skipping version compatibility check.",
            UserWarning,
        )
        return

    # Check major.minor version
    if (ser_ver.major, ser_ver.minor) != (cur_ver.major, cur_ver.minor):
        raise RuntimeError(
            f"Python version mismatch: feature was serialized with Python "
            f"{ser_ver} but current environment is Python {cur_ver}. "
            f"Cloudpickle objects are not compatible across different Python "
            f"minor versions. Please use Python {ser_ver.major}.{ser_ver.minor}.x to "
            f"deserialize this feature."
        )

    # Warn about patch version differences
    if ser_ver.micro != cur_ver.micro:
        warnings.warn(
            f"Python patch version differs: feature was serialized with Python "
            f"{serialized_version} but current environment is Python {current_version}. "
            f"This usually works but may occasionally cause issues.",
            UserWarning,
        )


def check_feature_type(features):
    checked_features = []
    for feature in features:
        if isinstance(feature, tuple):
            checked_features.append(feature)
        elif isinstance(feature, str):
            # TODO: Need to identify how to pull the run id
            checked_features.append((feature, "default"))
        elif isinstance(feature, FeatureColumnResource):
            checked_features.append(feature.name_variant())
        elif hasattr(feature, "name_variant"):
            checked_features.append(feature.name_variant())
        else:
            raise ValueError(
                f"Invalid feature type {type(feature)}; must be a tuple, string, or FeatureColumnResource"
            )
    return checked_features


class ServingClient:
    """
    The serving client is used to retrieve training sets and features for training and serving purposes.
    **Using the Serving Client:**
    ``` py
    import featureform as ff
    from featureform import Client
    client = Client()
    # example:
    dataset = client.training_set("fraud_training", "quickstart")
    training_dataset = dataset.repeat(10).shuffle(1000).batch(8)
    for feature_batch in training_dataset:
        # Train model
    ```
    """

    def __init__(
        self, host=None, local=False, insecure=False, cert_path=None, debug=False
    ):
        # This line ensures that the warning is only raised if ServingClient is instantiated directly
        # TODO: Remove this check once ServingClient is deprecated
        is_instantiated_directed = inspect.stack()[1].function != "__init__"
        if is_instantiated_directed:
            warnings.warn(
                "ServingClient is deprecated and will be removed in future versions; use Client instead.",
                PendingDeprecationWarning,
            )
        """
        Args:
            host (str): The hostname of the Featureform instance.
            insecure (bool): True if connecting to an insecure Featureform endpoint. False if using a self-signed or public TLS certificate
            cert_path (str): The path to a public certificate if using a self-signed certificate.
        """
        if local:
            raise Exception(
                "Local mode is not supported in this version. Use featureform <= 1.12.0 for localmode"
            )

        self.impl = HostedClientImpl(host, insecure, cert_path, debug=debug)
        self._cert_path = cert_path or os.getenv("FEATUREFORM_CERT")
        self._insecure = insecure

    def training_set(
        self,
        name,
        variant="",
        include_label_timestamp=False,
        model: Union[str, Model] = None,
    ) -> "Dataset":
        """Return an iterator that iterates through the specified training set.

        **Examples**:
        ``` py
            client = ff.Client()
            dataset = client.training_set("fraud_training", "quickstart")
            training_dataset = dataset.repeat(10).shuffle(1000).batch(8)
            for feature_batch in training_dataset:
                # Train model
        ```

        Args:
            name (str): Name of training set to be retrieved
            variant (str): Variant of training set to be retrieved

        Returns:
            training_set (Dataset): A training set iterator
        """
        if isinstance(name, TrainingSetVariant):
            variant = name.variant
            name = name.name
        return self.impl.training_set(name, variant, include_label_timestamp, model)

    def features(self, features, entities, model: Union[str, Model] = None):
        """Returns the feature values for the specified entities.

        **Examples**:
        ``` py
            client = ff.Client()
            fpf = client.features([("avg_transactions", "quickstart")], {"user": "C1410926"})
            # Run features through model
        ```

        Args:
            features (list[(str, str)], list[str]): List of Name Variant Tuples
            entities (dict): Dictionary of entity name/value pairs

        Returns:
            features (numpy.Array): An Numpy array of feature values in the order given by the inputs
        """
        features = check_feature_type(features)
        return self.impl.features(features, entities, model)

    def close(self):
        """Closes the connection to the Featureform instance."""
        self.impl.close()

    def batch_features(self, features):
        """
        Return an iterator that iterates over each entity and corresponding features in feats.
        **Example:**
        ```py title="definitions.py"
        for feature_values in client.batch_features([("feature1", "variant"), ("feature2", "variant"), ("feature3", "variant")]):
            print(feature_values)
        ```

        Args:
            features (List[NameVariant]): The features to iterate over

        Returns:
            iterator: An iterator of entity and feature values

        """
        if len(features) == 0:
            raise ValueError("No features provided")
        feature_tuples = check_feature_type(features)
        return self.impl.batch_features(feature_tuples)


class HostedClientImpl:
    def __init__(self, host=None, insecure=False, cert_path=None, debug=False):
        host = host or os.getenv("FEATUREFORM_HOST")
        if host is None:
            raise ValueError(
                "The `host` parameter must be passed or the environment"
                " variable FEATUREFORM_HOST must be set."
            )
        check_up_to_date(False, "serving")
        self._channel = self._create_channel(host, insecure, cert_path)
        self._stub = GrpcClient(
            serving_pb2_grpc.FeatureStub(self._channel),
            debug=debug,
            insecure=insecure,
            host=host,
        )
        # Executor for realtime features (handles caching internally)
        self._realtime_executor = RealtimeFeatureExecutor()

    @staticmethod
    def _create_channel(host, insecure, cert_path):
        if insecure:
            return insecure_channel(host)
        else:
            return secure_channel(host, cert_path)

    def training_set(
        self, name, variation, include_label_timestamp, model: Union[str, Model] = None
    ):
        training_set_stream = TrainingSetStream(self._stub, name, variation, model)

        # Fetch training columns to check for realtime features
        id_proto = serving_pb2.TrainingDataID(name=name, version=variation)
        req = serving_pb2.TrainingDataColumnsRequest(id=id_proto)
        cols = self._stub.TrainingDataColumns(req)

        # Get feature columns for filtering dependencies
        feature_columns = list(cols.feature_columns)

        # Check if any features have realtime definitions
        has_realtime_features = any(
            col.serialized_realtime_definition for col in feature_columns
        )

        # Only wrap with RealtimeTrainingSetStream if realtime features exist
        if has_realtime_features:
            training_set_stream = RealtimeTrainingSetStream(
                training_set_stream,
                feature_columns,
                self._realtime_executor,
            )

        return Dataset(training_set_stream, feature_columns=feature_columns)

    def features(self, features, entities, model: Union[str, Model] = None):
        req = serving_pb2.FeatureServeRequest()
        for name, values in entities.items():
            entity_proto = req.entities.add()
            entity_proto.name = name
            if isinstance(values, list):
                for value in values:  # Assuming 'values' is a list of strings
                    entity_proto.values.append(value)
            elif isinstance(values, str):
                entity_proto.values.append(values)
            else:
                raise ValueError(
                    "Entity values must be either a string or a list of strings"
                )
        for name, variation in features:
            feature_id = req.features.add()
            feature_id.name = name
            feature_id.version = variation
        if model is not None:
            req.model.name = model if isinstance(model, str) else model.name
        resp = self._stub.FeatureServe(req)

        deprecated_values = resp.values
        value_lists = (
            deprecated_values if len(deprecated_values) > 0 else resp.value_lists
        )

        feature_values = []
        for val_list in value_lists:
            entity_values = []
            for val in val_list.values:
                parsed_value = parse_proto_value(val)
                value_type = type(parsed_value)

                # Client-computed features are returned as a byte array
                if value_type == bytes:
                    parsed_value = self._execute_client_computed_feature(
                        parsed_value, entities
                    )
                # Vector features are returned as a Vector32 proto due
                # to the inability to use the `repeated` keyword in
                # in a `oneof` field
                elif value_type == serving_pb2.Vector32:
                    parsed_value = parsed_value.value
                entity_values.append(parsed_value)

            # If theres only one entity row, only return that row
            if len(value_lists) == 1:
                return entity_values
            feature_values.append(entity_values)

        # if only one entity is requested, return a flat list
        if len(entities.keys()) == 1 and type(feature_values[0]) is list:
            return [j for sub in feature_values for j in sub]

        return feature_values

    def batch_features(self, features):
        return FeatureSetIterator(self._stub, features)

    def _execute_client_computed_feature(
        self,
        feature_bytes: bytes,
        entities: Dict[str, Any],
        params: Optional[Dict[str, Any]] = None,
        precomputed_values: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Execute a client-computed realtime feature.

        Args:
            feature_bytes: The serialized RealtimeFeatureDefinition proto
            entities: Entity values for feature lookup (unused, kept for API compatibility)
            params: Optional dictionary of parameter values for RealtimeInputs
            precomputed_values: Optional dictionary of precomputed feature values
                already fetched (used for mixed feature views to avoid re-fetching)

        Returns:
            The computed feature value
        """
        return self._realtime_executor.execute(
            feature_bytes,
            precomputed_values or {},
            params,
        )

    def _get_source_as_df(self, name, variant, limit):
        columns = self._get_source_columns(name, variant)
        data = self._get_source_data(name, variant, limit)
        return pd.DataFrame(data=data, columns=columns)

    def _get_source_data(self, name, variant, limit):
        id = serving_pb2.SourceID(name=name, version=variant)
        req = serving_pb2.SourceDataRequest(id=id, limit=limit)
        resp = self._stub.SourceData(req)
        data = []
        for batch in resp:
            for rows in batch.rows:
                row = [getattr(r, r.WhichOneof("value")) for r in rows.rows]
                data.append(row)
        return data

    def _get_source_columns(self, name, variant):
        id = serving_pb2.SourceID(name=name, version=variant)
        req = serving_pb2.SourceDataRequest(id=id)
        resp = self._stub.SourceColumns(req)
        # The Python type of resp.columns is <class 'google._upb._message.RepeatedScalarContainer'>
        # which is not a "recognized" type by pandas internal type check, which resulted in the following error:
        # `Index(...) must be called with a collection of some kind`
        # To avoid this issue, we convert the resp.columns to a Python list
        return list(resp.columns)

    def nearest(self, name, variant, vector, k):
        id = serving_pb2.FeatureID(name=name, version=variant)
        vec = serving_pb2.Vector32(value=vector)
        req = serving_pb2.NearestRequest(id=id, vector=vec, k=k)
        resp = self._stub.Nearest(req)
        return resp.entities

    def location(self, name: str, variant: str, resource_type: DataResourceType) -> str:
        req = serving_pb2.ResourceIdRequest()
        req.name = name
        req.variant = variant
        req.type = resource_type.value

        resp = self._stub.GetResourceLocation(req)

        return resp.location

    def close(self):
        self._channel.close()


class TrainingSetStream(Iterator):
    def __init__(self, stub, name, version, model: Union[str, Model] = None):
        req = serving_pb2.TrainingDataRequest()
        req.id.name = name
        req.id.version = version
        if model is not None:
            req.model.name = model if isinstance(model, str) else model.name
        self.name = name
        self.version = version
        self._stub = stub
        self._req = req
        self._iter = stub.TrainingData(req)
        self._buf = []
        self._index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self._index >= len(self._buf):
            self._buf = next(self._iter).rows
            self._index = 0

        row = Row(self._buf[self._index])
        self._index += 1
        return row

    def restart(self):
        self._iter = self._stub.TrainingData(self._req)


class RealtimeTrainingSetStream(Iterator):
    """Wraps a TrainingSetStream to compute realtime features during iteration.

    This stream is used when a training set contains realtime features.
    It wraps the underlying stream and, for each row, executes the realtime feature
    functions using the precomputed feature values from the same row.
    """

    def __init__(
        self,
        inner_stream: TrainingSetStream,
        feature_columns: List["serving_pb2.TrainingFeatureColumn"],
        executor: "RealtimeFeatureExecutor",
    ):
        """Initialize the realtime training set stream.

        Args:
            inner_stream: The underlying TrainingSetStream
            feature_columns: List of TrainingFeatureColumn protos with metadata
            executor: RealtimeFeatureExecutor for executing realtime functions
        """
        self._inner_stream = inner_stream
        self._executor = executor
        self._feature_columns = feature_columns

        # Build mapping of column name to serialized realtime definition
        # and identify which columns are realtime vs precomputed
        self._realtime_definitions: Dict[str, bytes] = {}
        self._precomputed_indices: List[int] = []
        self._realtime_indices: List[int] = []
        # Track non-dependency indices for filtering output
        self._non_dependency_indices: List[int] = []

        for i, col in enumerate(feature_columns):
            if col.serialized_realtime_definition:
                self._realtime_definitions[col.column_name] = (
                    col.serialized_realtime_definition
                )
                self._realtime_indices.append(i)
            else:
                self._precomputed_indices.append(i)

            # Track non-dependency features for output filtering
            if not col.is_dependency:
                self._non_dependency_indices.append(i)

    @property
    def name(self):
        return self._inner_stream.name

    @property
    def version(self):
        return self._inner_stream.version

    @property
    def _stub(self):
        """Expose the inner stream's stub for compatibility with Dataset.dataframe()."""
        return self._inner_stream._stub

    def __iter__(self):
        return self

    def __next__(self):
        # Get next row from inner stream
        row = next(self._inner_stream)

        # Build precomputed values dict for realtime function execution.
        # Key by (name, use_inclusive_join) tuple to differentiate between
        # inclusive and exclusive PIT join values for the same backing feature.
        # IMPORTANT: The materialized data only contains precomputed (backing) features,
        # not realtime features. We need to map the precomputed column indices to the
        # actual data indices which are sequential starting from 0.
        precomputed_values = {}
        features = row._features
        for data_idx, col_idx in enumerate(self._precomputed_indices):
            if data_idx < len(features):
                col = self._feature_columns[col_idx]
                # Use tuple key (name, use_inclusive_join) to distinguish
                # inclusive vs exclusive PIT join values
                use_inclusive = getattr(col, "use_inclusive_join", False)
                key = (col.name, use_inclusive)
                precomputed_values[key] = features[data_idx]

        # Compute realtime feature values if any
        realtime_values = {}
        for col_name, serialized_def in self._realtime_definitions.items():
            try:
                value = self._executor.execute(
                    serialized_def, precomputed_values, params={}
                )
                realtime_values[col_name] = value
            except Exception as e:
                # On error, use None as the value
                realtime_values[col_name] = None

        # Build new_features array with same structure as _feature_columns
        # This maps column indices to their values (precomputed or realtime)
        new_features = [None] * len(self._feature_columns)
        new_types = [None] * len(self._feature_columns)

        # Fill in precomputed (backing) feature values at their column positions
        for data_idx, col_idx in enumerate(self._precomputed_indices):
            if data_idx < len(features):
                new_features[col_idx] = features[data_idx]
            if data_idx < len(row._types):
                new_types[col_idx] = row._types[data_idx]

        # Fill in realtime feature values at their column positions
        for col_idx in self._realtime_indices:
            col = self._feature_columns[col_idx]
            if col.column_name in realtime_values:
                new_features[col_idx] = realtime_values[col.column_name]
                # Realtime features typically return float
                new_types[col_idx] = "float"

        # Filter out dependency features - only keep non-dependency indices
        filtered_features = [
            new_features[i]
            for i in self._non_dependency_indices
            if new_features[i] is not None
        ]
        filtered_types = [
            new_types[i]
            for i in self._non_dependency_indices
            if new_types[i] is not None
        ]

        # Update row with filtered features
        row._features = np.array(
            filtered_features, dtype=get_numpy_array_type(filtered_types)
        )
        row._types = filtered_types
        row._row = np.append(row._features, row._label)

        # Filter feature timestamps if present
        # Note: Timestamps are only present for precomputed features in the raw data
        # Realtime features don't have timestamps in the materialized data
        if row._feature_timestamps:
            # Build new_timestamps with same structure as _feature_columns
            new_timestamps = [None] * len(self._feature_columns)
            for data_idx, col_idx in enumerate(self._precomputed_indices):
                if data_idx < len(row._feature_timestamps):
                    new_timestamps[col_idx] = row._feature_timestamps[data_idx]

            # Filter to only keep non-dependency feature timestamps
            row._feature_timestamps = [
                new_timestamps[i] for i in self._non_dependency_indices
            ]

        return row

    def restart(self):
        self._inner_stream.restart()


class LocalStream:
    def __init__(self, datalist, include_label_timestamp):
        self._datalist = datalist
        self._iter = iter(datalist)
        self._include_label_timestamp = include_label_timestamp

    def __iter__(self):
        return iter(self._iter)

    def __next__(self):
        return LocalRow(next(self._iter), self._include_label_timestamp)

    def restart(self):
        self._iter = iter(self._datalist)


class Repeat:
    def __init__(self, repeat_num, stream):
        self.repeat_num = repeat_num
        self._stream = stream

    def __iter__(self):
        return self

    def __next__(self):
        try:
            next_val = next(self._stream)
        except StopIteration:
            self.repeat_num -= 1
            if self.repeat_num >= 0:
                self._stream.restart()
                next_val = next(self._stream)
            else:
                raise

        return next_val


class Shuffle:
    def __init__(self, buffer_size, stream):
        self.buffer_size = buffer_size
        self._shuffled_data_list = []
        self._stream = stream
        self.__setup_buffer()

    def __setup_buffer(self):
        try:
            for _ in range(self.buffer_size):
                self._shuffled_data_list.append(next(self._stream))
        except StopIteration:
            pass

    def restart(self):
        self._stream.restart()
        self.__setup_buffer()

    def __iter__(self):
        return self

    def __next__(self):
        if len(self._shuffled_data_list) == 0:
            raise StopIteration
        random_index = random.randrange(len(self._shuffled_data_list))
        next_row = self._shuffled_data_list.pop(random_index)

        try:
            self._shuffled_data_list.append(next(self._stream))
        except StopIteration:
            pass

        return next_row


class Batch:
    def __init__(self, batch_size, stream):
        self.batch_size = batch_size
        self._stream = stream

    def restart(self):
        self._stream.restart()

    def __iter__(self):
        return self

    def __next__(self):
        rows = BatchRow()
        for _ in range(self.batch_size):
            try:
                next_row = next(self._stream)
                rows.append(next_row)
            except StopIteration:
                if len(rows) == 0:
                    raise
                return rows
        return rows


class Dataset:
    def __init__(self, stream, dataframe=None, feature_columns=None):
        """Repeats the Dataset for the specified number of times

        Args:
            stream (Iterator): An iterable object.
            dataframe: Optional pre-computed dataframe.
            feature_columns: Optional list of TrainingFeatureColumn protos with metadata
                including is_dependency flag for filtering.

        Returns:
            self (Dataset): Returns a Dataset created from the iterable object.
        """
        self._stream = stream
        self._dataframe = dataframe
        self._feature_columns = feature_columns or []

        # Build indices for filtering: which feature indices are NOT dependencies
        self._non_dependency_indices = []
        if feature_columns:
            for i, col in enumerate(feature_columns):
                if not col.is_dependency:
                    self._non_dependency_indices.append(i)

    def train_test_split(
        self,
        test_size: float = 0,
        train_size: float = 0,
        shuffle: bool = True,
        random_state: Optional[int] = None,
        batch_size: int = 1,
    ):
        """
        (This functionality is currently only available for Clickhouse).

        Splits an existing training set into training and testing iterators. The split is processed on the underlying
        provider and calculated at serving time.

        **Examples**:

        ``` py
        import featureform as ff
        client = ff.Client()
        train, test = client
            .training_set("fraud_training", "v1")
            .train_test_split(
                test_size=0.7,
                train_size=0.3,
                shuffle=True,
                random_state=None,
                batch_size=5
            )

        for features, label in train:
            print(features)
            print(label)
            clf.partial_fit(features, label)

        for features, label in test:
            print(features)
            print(label)
            clf.score(features, label)


        # TRAIN OUTPUT
        # np.array([
        #   [1, 1, 3],
        #   [5, 1, 2],
        #   [7, 6, 5],
        #   [8, 3, 3],
        #   [5, 2, 2],
        # ])
        # np.array([2, 4, 2, 3, 4])
        # np.array([
        #   [3, 1, 2],
        #   [5, 4, 5],
        # ])
        # np.array([6, 7])

        # TEST OUTPUT
        # np.array([
        #   [5, 1, 3],
        #   [4, 3, 1],
        #   [6, 6, 7],
        # ])
        # np.array([4, 6, 7])

        ```

        Args:
            test_size (float): The ratio of test set size to train set size. Must be a value between 0 and 1. If excluded
                it will be the complement to the train_size. One of test_size or train_size must be specified.
            train_size (float): The ratio of train set size to train set size. Must be a value between 0 and 1. If excluded
                it will be the complement to the test_size. One of test_size or train_size must be specified.
            shuffle (bool): Whether to shuffle the dataset before splitting.
            random_state (Optional[int]): A random state to shuffle the dataset. If None, the dataset will be shuffled
                randomly on every call. If >0, the value will be used a seed to create random shuffle that can be repeated
                if subsequent calls use the same seed.
            batch_size (int): The size of the batch to return from the iterator. Must be greater than 0.

        Returns:
            train (Iterator): An iterator for training values.
            test (Iterator): An iterator for testing values.
        """
        if batch_size < 1:
            raise ValueError("batch_size must be 1 or greater")

        if random_state is not None and random_state < 0:
            raise ValueError("random_state must be 0 or greater")

        test_size, train_size = self.validate_test_size(test_size, train_size)

        name = self._stream.name
        variant = self._stream.version
        stub = self._stream._stub
        model = self._stream.model if hasattr(self._stream, "model") else None

        train, test = TrainTestSplit(
            stub=stub,
            name=name,
            version=variant,
            model=model,
            test_size=test_size,
            train_size=train_size,
            shuffle=shuffle,
            random_state=(0 if random_state is None else random_state),
            batch_size=batch_size,
        ).split()

        return train, test

    @staticmethod
    def validate_test_size(test_size, train_size):
        # Validate ranges
        if not 0 <= test_size <= 1:
            raise ValueError("test_size must be between 0 and 1")
        if not 0 <= train_size <= 1:
            raise ValueError("train_size must be between 0 and 1")

        # If both are specified but don't sum to 1, it's an error
        if test_size != 0 and train_size != 0 and test_size + train_size != 1:
            raise ValueError("test_size + train_size must equal 1 if both are non-zero")

        # Auto-adjust if one is 0
        if test_size == 0 and train_size > 0:
            test_size = 1 - train_size
        elif train_size == 0 and test_size > 0:
            train_size = 1 - test_size

        return test_size, train_size

    def dataframe(self, spark_session=None):
        """Returns the training set as a Pandas DataFrame or Spark DataFrame.
        Args:
        - spark_session: Optional(SparkSession)


        **Examples**:
        ``` py
            client = Client()
            df = client.training_set("fraud_training", "v1").dataframe()
            print(df.head())
            # Output:
            #                feature_avg_transactions_default             label
            # 0                                25.0                       False
            # 1                             27999.0                       False
            # 2                               459.0                       False
            # 3                              2060.0                        True
            # 4                              1762.5                       False
        ```

        Returns:
            df: Union[pd.DataFrame, pyspark.sql.DataFrame] A DataFrame containing the training set.
        """

        if self._dataframe is not None:
            return self._dataframe
        elif spark_session is not None:
            req = serving_pb2.ResourceIdRequest()
            req.name = self._stream.name
            req.variant = self._stream.version
            req.type = DataResourceType.TRAINING_DATA.value
            resp = self._stream._stub.ResourceLocation(req)

            file_format = FileFormat.get_format(resp.location, default="parquet")
            location = self._sanitize_location(resp.location)
            self._dataframe = self._get_spark_dataframe(
                spark_session, file_format, location
            )
            return self._dataframe
        else:
            name = self._stream.name
            variant = self._stream.version
            stub = self._stream._stub
            id = serving_pb2.TrainingDataID(name=name, version=variant)
            req = serving_pb2.TrainingDataRequest(id=id)
            cols = stub.TrainingDataColumns(req)

            # Get entity column if available (may be empty for backward compatibility)
            # Use getattr for compatibility with older proto definitions
            entity_col = getattr(cols, "entity", "") or None

            # Get timestamp columns if available (may be empty for backward compatibility)
            feature_ts_cols = list(getattr(cols, "feature_timestamps", []) or [])
            label_ts_col = getattr(cols, "label_timestamp", "") or None

            data = [
                r.to_dict(
                    cols.features,
                    cols.label,
                    entity_col,
                    feature_ts_cols or None,
                    label_ts_col,
                )
                for r in self._stream
            ]

            # Build column list: entity (if present), features, realtime features, feature timestamps, label, label timestamp
            columns = []
            if entity_col:
                columns.append(entity_col)
            columns.extend(cols.features)
            if feature_ts_cols:
                columns.extend(feature_ts_cols)
            columns.append(cols.label)
            if label_ts_col:
                columns.append(label_ts_col)

            self._dataframe = pd.DataFrame(data=data, columns=columns)
            self._dataframe.rename(columns={cols.label: "label"}, inplace=True)
            if entity_col:
                self._dataframe.rename(columns={entity_col: "entity"}, inplace=True)
            if label_ts_col:
                self._dataframe.rename(columns={label_ts_col: "label_ts"}, inplace=True)

            # Filter out dependency columns if feature_columns metadata is available
            if self._feature_columns:
                dependency_columns_to_drop = []
                for col in self._feature_columns:
                    if col.is_dependency:
                        # Drop both the feature column and its timestamp column
                        dependency_columns_to_drop.append(col.column_name)
                        if col.timestamp_column:
                            dependency_columns_to_drop.append(col.timestamp_column)

                # Drop columns that exist in the dataframe
                columns_to_drop = [
                    c
                    for c in dependency_columns_to_drop
                    if c in self._dataframe.columns
                ]
                if columns_to_drop:
                    self._dataframe = self._dataframe.drop(columns=columns_to_drop)

            return self._dataframe

    def _sanitize_location(self, location: str) -> str:
        # Returns the location directory rather than a single file if it is part-file.
        # Also converts s3:// to s3a:// if necessary.

        # If the location is a part-file, we want to get the directory instead.
        is_individual_part_file = location.split("/")[-1].startswith("part-")
        if is_individual_part_file:
            location = "/".join(location.split("/")[:-1])

        # If the schema is s3://, we want to convert it to s3a://.
        location = (
            location.replace("s3://", "s3a://")
            if location.startswith("s3://")
            else location
        )

        return location

    def _get_spark_dataframe(self, spark, file_format, location):
        if file_format not in FileFormat.supported_formats():
            raise Exception(
                f"file type '{file_format}' is not supported. Please use 'csv' or 'parquet'"
            )

        try:
            df = (
                spark.read.option("header", "true")
                .option("recursiveFileLookup", "true")
                .format(file_format)
                .load(location)
            )

            label_column_name = ""
            for col in df.columns:
                if col.startswith("Label__"):
                    label_column_name = col
                    break

            if label_column_name != "":
                df = df.withColumnRenamed(label_column_name, "Label")

        except Exception as e:
            raise Exception(
                f"please make sure the spark session has ability to read '{location}': {e}"
            )

        return df

    def from_dataframe(dataframe, include_label_timestamp):
        stream = LocalStream(dataframe.values.tolist(), include_label_timestamp)
        return Dataset(stream, dataframe)

    def pandas(self):
        warnings.warn(
            "Dataset.pandas() is deprecated and will be removed in future versions; use Dataset.dataframe() instead.",
            PendingDeprecationWarning,
        )
        if self._dataframe is None:
            _ = self.dataframe()
        return self._dataframe

    def repeat(self, num):
        """Repeats the Dataset for the specified number of times

        **Examples**:
        ``` py
            client = ff.Client()
            dataset = client.training_set("fraud_training", "quickstart")
            training_dataset = dataset.repeat(10) # Repeats data 10 times
            for feature_batch in training_dataset:
                # Train model
        ```

        Args:
            num (int): The number of times the dataset will be repeated

        Returns:
            self (Dataset): Returns the current Dataset
        """
        if num <= 0:
            raise Exception("Must repeat 1 or more times")
        self._stream = Repeat(num, self._stream)
        if self._dataframe is not None:
            temp_df = self._dataframe
            for i in range(num):
                self._dataframe = pd.concat([self._dataframe, temp_df])
        return self

    def shuffle(self, buffer_size):
        """Swaps random rows within the Dataset.

        **Examples**:
        ``` py
            client = ff.Client()
            dataset = client.training_set("fraud_training", "quickstart")
            training_dataset = dataset.shuffle(100) # Swaps 100 Rows
            for feature_batch in training_dataset:
                # Train model
        ```

        Args:
            buffer_size (int): The number of Dataset rows to be randomly swapped

        Returns:
            self (Dataset): Returns the current Dataset
        """
        if buffer_size <= 0:
            raise Exception("Buffer size must be greater than or equal to 1")
        self._stream = Shuffle(buffer_size, self._stream)
        if self._dataframe is not None:
            self._dataframe = self._dataframe.sample(frac=1)
        return self

    def batch(self, batch_size):
        """Creates a batch row in the Dataset.

        **Examples**:
        ``` py
            client = ff.Client()
            dataset = client.training_set("fraud_training", "quickstart")
            training_dataset = dataset.batch(8) # Creates a batch of 8 Datasets for each row
            for feature_batch in training_dataset:
                # Train model
        ```

        Args:
            batch_size (int): The number of items to be added to each batch

        Returns:
            self (Dataset): Returns the current Dataset
        """
        if batch_size <= 0:
            raise Exception("Batch size must be greater than or equal to 1")
        self._stream = Batch(batch_size, self._stream)
        if self._dataframe is not None:
            self._dataframe = np.array_split(
                self._dataframe, math.ceil(len(self._dataframe) // batch_size)
            )
        return self

    def __iter__(self):
        return self

    def __next__(self):
        next_val = next(self._stream)
        return next_val


class Row:
    def __init__(self, proto_row):
        # Entity may be None for backward compatibility with older training sets
        # or when connecting to older server versions without the entity field
        try:
            if proto_row.HasField("entity"):
                self._entity = parse_proto_value(proto_row.entity)
            else:
                self._entity = None
        except (ValueError, AttributeError):
            self._entity = None
        self._types = [proto_type_to_np_type(feature) for feature in proto_row.features]
        self._features = np.array(
            [parse_proto_value(feature) for feature in proto_row.features],
            dtype=get_numpy_array_type(self._types),
        )
        self._label = parse_proto_value(proto_row.label)
        self._row = np.append(self._features, self._label)

        # Parse feature timestamps if present
        # Timestamps are google.protobuf.Timestamp, use ToDatetime() to convert
        self._feature_timestamps = None
        try:
            if proto_row.feature_timestamps:
                self._feature_timestamps = [
                    parse_proto_timestamp(ts) for ts in proto_row.feature_timestamps
                ]
        except (ValueError, AttributeError):
            self._feature_timestamps = None

        # Parse label timestamp if present
        self._label_timestamp = None
        try:
            if proto_row.HasField("label_timestamp"):
                self._label_timestamp = parse_proto_timestamp(proto_row.label_timestamp)
        except (ValueError, AttributeError):
            self._label_timestamp = None

    def entity(self):
        return self._entity

    def features(self):
        return np.array([self._row[:-1]])

    def label(self):
        return np.array([self._label])

    def feature_timestamps(self):
        """Returns the timestamps for each feature value, or None if not available."""
        return self._feature_timestamps

    def label_timestamp(self):
        """Returns the timestamp for the label value, or None if not available."""
        return self._label_timestamp

    def to_numpy(self):
        return self._row

    def to_dict(
        self,
        feature_columns: List[str],
        label_column: str,
        entity_column: str = None,
        feature_timestamp_columns: List[str] = None,
        label_timestamp_column: str = None,
    ):
        row_dict = {}
        if entity_column and self._entity is not None:
            row_dict[entity_column] = self._entity
        row_dict.update(dict(zip(feature_columns, self._features)))
        row_dict[label_column] = self._label

        # Add feature timestamps if available
        if feature_timestamp_columns and self._feature_timestamps:
            row_dict.update(
                dict(zip(feature_timestamp_columns, self._feature_timestamps))
            )

        # Add label timestamp if available
        if label_timestamp_column and self._label_timestamp is not None:
            row_dict[label_timestamp_column] = self._label_timestamp

        return row_dict

    def __repr__(self):
        return "Entity: {}, Features: {}, Label: {}".format(
            self.entity(), self.features(), self.label()
        )


class LocalRow:
    def __init__(self, row_list, include_label_timestamp, entity=None):
        """
        If include_label_timestamp is true then we want the label to equal to the
        last two columns in the list. Otherwise, just the label will be the last column only.
        """
        self._entity = entity
        self._features = row_list[:-2] if include_label_timestamp else row_list[:-1]
        self._row = row_list
        self._label = row_list[-2:] if include_label_timestamp else row_list[-1]

    def entity(self):
        return self._entity

    def features(self):
        return [self._features]

    def label(self):
        return [self._label]

    def to_numpy(self):
        return np.array(self._row)

    def __repr__(self):
        return "Entity: {}, Features: {}, Label: {}".format(
            self.entity(), self.features(), self.label()
        )


class BatchRow:
    def __init__(self, rows=None):
        self._entities = []
        self._features = []
        self._labels = []
        if rows is None:
            rows = []
        self._rows = rows
        for row in rows:
            self.append(row)

    def append(self, row):
        self._entities.append(row.entity())
        self._features.append(row.features()[0])
        self._labels.append(row.label()[0])
        self._rows.append(row)

    def entity(self):
        return self._entities

    def features(self):
        return self._features

    def label(self):
        return self._labels

    def to_list(self):
        return self._rows

    def __len__(self):
        return len(self._rows)


def parse_proto_value(value):
    """parse_proto_value is used to parse the one of Value message.

    For ListValue types, recursively parses each element and returns a Python list.
    """
    field_name = value.WhichOneof("value")
    raw_value = getattr(value, field_name)

    # For list_value, recursively parse each element
    if field_name == "list_value":
        return [parse_proto_value(v) for v in raw_value.values]

    return raw_value


def parse_proto_timestamp(timestamp):
    """parse_proto_timestamp converts a google.protobuf.Timestamp to a Python datetime.

    Returns None if the timestamp is None.
    """
    if timestamp is None:
        return None
    return timestamp.ToDatetime()


def proto_type_to_np_type(value):
    type_mapping = {
        "str_value": str,
        "int_value": np.int32,
        "int32_value": np.int32,
        "int64_value": np.int64,
        "float_value": np.float32,
        "double_value": np.float64,
        "bool_value": bool,
        "list_value": object,  # Lists are stored as Python objects in numpy arrays
        "vector32_value": object,  # Vectors are also stored as objects
        "uint32_value": np.uint32,
        "uint64_value": np.uint64,
    }
    field_name = value.WhichOneof("value")
    return type_mapping.get(field_name, object)


def get_numpy_array_type(types):
    if all(i == types[0] for i in types):
        return types[0]
    else:
        return "O"


class FeatureSetIterator:
    def __init__(self, stub, features):
        req = serving_pb2.BatchFeatureServeRequest()
        for name, variant in features:
            feature_id = req.features.add()
            feature_id.name = name
            feature_id.version = variant
        self._stub = stub
        self._req = req
        self._iter = stub.BatchFeatureServe(req)
        self._buf = []
        self._index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if self._index >= len(self._buf):
            self._buf = next(self._iter).rows
            self._index = 0

        row = FeatureSetRow(self._buf[self._index]).to_tuple()
        self._index += 1
        return row

    def restart(self):
        self._iter = self._stub.BatchFeatureServe(self._req)


class FeatureSetRow:
    def __init__(self, proto_row):
        self._features = [parse_proto_value(feature) for feature in proto_row.features]
        self._entity = parse_proto_value(proto_row.entity)
        self._row = [self._entity, self._features]

    def features(self):
        return self._row[1]

    def entity(self):
        return [self._entity]

    def to_numpy(self):
        return np.array(self._row)

    def to_tuple(self):
        return tuple((self._entity, self._features))

    def to_dict(self, feature_columns: List[str], entity_column: str):
        row_dict = dict(zip(feature_columns, self._features))
        row_dict[entity_column] = self._entity
        return row_dict

    def __repr__(self):
        return "Features: {} , Entity: {}".format(self.features(), self.entity())
