# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at https://mozilla.org/MPL/2.0/.

"""
Configuration classes for offline store providers.
"""

from __future__ import annotations

import json
import warnings
from dataclasses import dataclass
from typing import Dict, Optional, Union

from typeguard import typechecked

from ..enums import Initialize, RefreshMode, SnowflakeSessionParamKey
from ..proto import metadata_pb2 as pb
from ..secret_provider import Secret, StaticSecret
from .catalogs import SnowflakeCatalog, SnowflakeDynamicTableConfig
from .credentials import GCPCredentials


@typechecked
@dataclass
class PostgresConfig:
    host: str
    port: str
    database: str
    user: str
    password: Union[Secret, str]
    sslmode: str

    def __post_init__(self):
        if isinstance(self.password, str):
            self.password = StaticSecret(self.password)

    def software(self) -> str:
        return "postgres"

    def type(self) -> str:
        return "POSTGRES_OFFLINE"

    def serialize(self) -> bytes:
        config = {
            "Host": self.host,
            "Port": self.port,
            "Username": self.user,
            "Password": self.password.serialize(),
            "Database": self.database,
            "SSLMode": self.sslmode,
        }
        return bytes(json.dumps(config), "utf-8")

    @classmethod
    def deserialize(cls, config: bytes) -> "PostgresConfig":
        config = json.loads(config.decode("utf-8"))
        return cls(
            host=config["Host"],
            port=config["Port"],
            database=config["Database"],
            user=config["Username"],
            password=Secret.deserialize(config["Password"]),
            sslmode=config["SSLMode"],
        )


@typechecked
@dataclass
class ClickHouseConfig:
    host: str
    port: int
    database: str
    user: str
    password: str
    ssl: bool

    def software(self) -> str:
        return "clickhouse"

    def type(self) -> str:
        return "CLICKHOUSE_OFFLINE"

    def serialize(self) -> bytes:
        config = {
            "Host": self.host,
            "Port": self.port,
            "Username": self.user,
            "Password": self.password,
            "Database": self.database,
            "SSL": self.ssl,
        }
        return bytes(json.dumps(config), "utf-8")

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, ClickHouseConfig):
            return False
        return (
            self.host == __value.host
            and self.port == __value.port
            and self.database == __value.database
            and self.user == __value.user
            and self.password == __value.password
            and self.ssl == __value.ssl
        )


@typechecked
@dataclass
class RedshiftConfig:
    host: str
    port: str
    database: str
    user: str
    password: str
    sslmode: str

    def software(self) -> str:
        return "redshift"

    def type(self) -> str:
        return "REDSHIFT_OFFLINE"

    def serialize(self) -> bytes:
        config = {
            "Host": self.host,
            "Port": self.port,
            "Username": self.user,
            "Password": self.password,
            "Database": self.database,
            "SSLMode": self.sslmode,
        }
        return bytes(json.dumps(config), "utf-8")

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, RedshiftConfig):
            return False
        return (
            self.host == __value.host
            and self.port == __value.port
            and self.database == __value.database
            and self.user == __value.user
            and self.password == __value.password
            and self.sslmode == __value.sslmode
        )


@typechecked
@dataclass
class BigQueryConfig:
    project_id: str
    dataset_id: str
    credentials: GCPCredentials

    def software(self) -> str:
        return "bigquery"

    def type(self) -> str:
        return "BIGQUERY_OFFLINE"

    def serialize(self) -> bytes:
        config = {
            "ProjectID": self.project_id,
            "DatasetID": self.dataset_id,
            "Credentials": self.credentials.to_json(),
        }
        return bytes(json.dumps(config), "utf-8")

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, BigQueryConfig):
            return False
        return (
            self.project_id == __value.project_id
            and self.dataset_id == __value.dataset_id
        )


@dataclass
class ResourceSnowflakeConfig:
    dynamic_table_config: Optional[SnowflakeDynamicTableConfig] = None
    warehouse: Optional[str] = None

    def config(self) -> dict:
        return {
            "DynamicTableConfig": (
                self.dynamic_table_config.config()
                if self.dynamic_table_config
                else None
            ),
            "Warehouse": self.warehouse,
        }

    def to_proto(self):
        return pb.ResourceSnowflakeConfig(
            dynamic_table_config=(
                self.dynamic_table_config.to_proto()
                if self.dynamic_table_config
                else None
            ),
            warehouse=self.warehouse,
        )

    @classmethod
    def from_proto(
        cls, config: pb.ResourceSnowflakeConfig
    ) -> "ResourceSnowflakeConfig":
        return cls(
            dynamic_table_config=(
                SnowflakeDynamicTableConfig(
                    target_lag=config.dynamic_table_config.target_lag,
                    refresh_mode=(
                        RefreshMode.from_proto(config.dynamic_table_config.refresh_mode)
                        if config.dynamic_table_config.refresh_mode
                        else None
                    ),
                    initialize=(
                        Initialize.from_proto(config.dynamic_table_config.initialize)
                        if config.dynamic_table_config.initialize
                        else None
                    ),
                )
                if config.dynamic_table_config
                else None
            ),
            warehouse=config.warehouse,
        )


@dataclass
class SnowflakeKeyPairConfig:
    """Configuration for Snowflake key-pair authentication.

    Either private_key or private_key_path must be provided, but not both.

    Note: private_key_path refers to a path on the Featureform server/pod,
    not the client machine. File existence is validated at connection time.

    Only unencrypted private keys are supported; the gosnowflake driver
    does not support encrypted keys.

    Args:
        private_key: PEM-encoded private key content (inline).
        private_key_path: Path to private key file on the server/pod.
    """

    private_key: Optional[str] = None
    private_key_path: Optional[str] = None

    def __post_init__(self):
        if self.private_key and self.private_key_path:
            raise ValueError(
                "Cannot specify both 'private_key' and 'private_key_path'. "
                "Use one or the other."
            )
        if not self.private_key and not self.private_key_path:
            raise ValueError("Must specify either 'private_key' or 'private_key_path'.")

    def to_dict(self) -> dict:
        return {
            "private_key": self.private_key,
            "private_key_path": self.private_key_path,
        }


@typechecked
@dataclass
class SnowflakeConfig:
    """Snowflake offline store configuration.

    Authentication:
        Use key_pair for key-pair authentication (recommended).
        Password authentication is deprecated and will be removed in a future version.
    """

    username: str
    schema: str
    password: Optional[str] = None
    key_pair: Optional[SnowflakeKeyPairConfig] = None
    account: str = ""
    organization: str = ""
    host: str = ""
    database: str = ""
    account_locator: str = ""
    warehouse: str = ""
    role: str = ""
    catalog: Optional[SnowflakeCatalog] = None
    session_params: Optional[Dict[str, str]] = None

    def __post_init__(self):
        # Validate authentication method
        if self.password is not None and self.key_pair is not None:
            raise ValueError(
                "Cannot specify both 'password' and 'key_pair'. Use one or the other."
            )
        if self.password is None and self.key_pair is None:
            raise ValueError(
                "Must provide either 'password' or 'key_pair' for authentication."
            )

        # Emit deprecation warning for password auth
        if self.password is not None:
            warnings.warn(
                "Password authentication is deprecated and will be removed in a future version. "
                "Use key_pair authentication instead. See: "
                "https://docs.snowflake.com/en/user-guide/key-pair-auth",
                DeprecationWarning,
                stacklevel=2,
            )

        if self.session_params:
            for key, _ in self.session_params.items():
                if not SnowflakeSessionParamKey.validate_key(key):
                    warnings.warn(
                        f"Invalid key '{key}' in session_params. This key will be ignored in the Snowflake session."
                    )

        if self.__has_legacy_credentials() and self.__has_current_credentials():
            raise ValueError(
                "Cannot create configure Snowflake with both current and legacy credentials"
            )

        if not self.__has_legacy_credentials() and not self.__has_current_credentials():
            raise ValueError("Cannot create configure Snowflake without credentials")

    def __has_legacy_credentials(self) -> bool:
        return self.account_locator != ""

    def __has_current_credentials(self) -> bool:
        if (self.account != "" and self.organization == "") or (
            self.account == "" and self.organization != ""
        ):
            raise ValueError("Both Snowflake organization and account must be included")
        elif self.account != "" and self.organization != "":
            return True
        else:
            return False

    def software(self) -> str:
        return "Snowflake"

    def type(self) -> str:
        return "SNOWFLAKE_OFFLINE"

    def serialize(self) -> bytes:
        config = {
            "Username": self.username,
            "Password": self.password,
            "Organization": self.organization,
            "AccountLocator": self.account_locator,
            "Account": self.account,
            "Host": self.host,
            "Schema": self.schema,
            "Database": self.database,
            "Warehouse": self.warehouse,
            "Role": self.role,
            "Catalog": self.catalog.config() if self.catalog is not None else None,
            "SessionParams": self.session_params,
            "KeyPair": {
                "PrivateKey": self.key_pair.private_key,
                "PrivateKeyPath": self.key_pair.private_key_path,
            }
            if self.key_pair is not None
            else None,
        }
        return bytes(json.dumps(config), "utf-8")

    @classmethod
    def deserialize(cls, config: bytes) -> "SnowflakeConfig":
        """Deserialize a SnowflakeConfig from bytes.

        Args:
            config: JSON-encoded configuration bytes.

        Returns:
            A SnowflakeConfig instance.
        """
        data = json.loads(config.decode("utf-8"))

        # Extract key_pair if present
        key_pair = None
        key_pair_data = data.get("KeyPair")
        if key_pair_data:
            private_key = key_pair_data.get("PrivateKey")
            private_key_path = key_pair_data.get("PrivateKeyPath")
            if private_key or private_key_path:
                key_pair = SnowflakeKeyPairConfig(
                    private_key=private_key,
                    private_key_path=private_key_path,
                )

        # Extract catalog if present
        catalog = None
        catalog_data = data.get("Catalog")
        if catalog_data:
            table_config_data = catalog_data.get("TableConfig", {})
            target_lag = table_config_data.get("TargetLag")
            refresh_mode_str = table_config_data.get("RefreshMode")
            initialize_str = table_config_data.get("Initialize")

            table_config = SnowflakeDynamicTableConfig(
                target_lag=target_lag,
                refresh_mode=(
                    RefreshMode.from_string(refresh_mode_str)
                    if refresh_mode_str
                    else None
                ),
                initialize=(
                    Initialize.from_string(initialize_str) if initialize_str else None
                ),
            )

            catalog = SnowflakeCatalog(
                external_volume=catalog_data["ExternalVolume"],
                base_location=catalog_data["BaseLocation"],
                table_config=table_config,
            )

        # Convert empty string password to None for proper validation
        password = data.get("Password")
        if password == "":
            password = None

        return cls(
            username=data["Username"],
            password=password,
            key_pair=key_pair,
            account=data.get("Account", ""),
            organization=data.get("Organization", ""),
            host=data.get("Host", ""),
            database=data.get("Database", ""),
            account_locator=data.get("AccountLocator", ""),
            warehouse=data.get("Warehouse", ""),
            role=data.get("Role", ""),
            schema=data["Schema"],
            catalog=catalog,
            session_params=data.get("SessionParams"),
        )

    def __eq__(self, __value: object) -> bool:
        if not isinstance(__value, SnowflakeConfig):
            return False
        is_catalog_equal = (self.catalog is None and __value.catalog is None) or (
            self.catalog is not None
            and __value.catalog is not None
            and self.catalog.external_volume == __value.catalog.external_volume
            and self.catalog.base_location == __value.catalog.base_location
            and self.catalog.table_config.target_lag
            == __value.catalog.table_config.target_lag
            and self.catalog.table_config.refresh_mode
            == __value.catalog.table_config.refresh_mode
            and self.catalog.table_config.initialize
            == __value.catalog.table_config.initialize
        )
        return (
            self.username == __value.username
            and self.password == __value.password
            and self.schema == __value.schema
            and self.account == __value.account
            and self.organization == __value.organization
            and self.host == __value.host
            and self.database == __value.database
            and self.account_locator == __value.account_locator
            and self.warehouse == __value.warehouse
            and self.role == __value.role
            and is_catalog_equal
            and self.session_params == __value.session_params
        )
