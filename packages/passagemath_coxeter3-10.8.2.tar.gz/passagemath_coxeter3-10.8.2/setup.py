#!/usr/bin/env python

# PEP 517 builds do not have . in sys.path
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from sage_setup import sage_setup

sage_setup(['sagemath-coxeter3'],
           recurse_packages=('sage', 'passagemath_coxeter3'),
           spkgs=['coxeter3'],
           package_data={
               "sage.libs.coxeter3": [
                   "coxeter.pxd",
                   "decl.pxd",
               ],
           },
           py_limited_api=False)
