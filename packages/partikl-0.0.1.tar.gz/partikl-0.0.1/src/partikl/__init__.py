"""
Partikl SDK — automated media pipelines for developers.

Under active development. See https://partikl.io for current status.
"""

__version__ = "0.0.1"