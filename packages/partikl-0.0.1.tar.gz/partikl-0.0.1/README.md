# partikl

**Automated media pipelines for developers.**

> ⚠️ Under active development. See [partikl.io](https://partikl.io) for current status.

## Links

- Website: [partikl.io](https://partikl.io)
- Documentation: [partikl.io/docs/sdk/python](https://partikl.io/docs/sdk/python)
- GitHub: [github.com/partikl-io/partikl-py](https://github.com/partikl-io/partikl-py)

## License

MIT