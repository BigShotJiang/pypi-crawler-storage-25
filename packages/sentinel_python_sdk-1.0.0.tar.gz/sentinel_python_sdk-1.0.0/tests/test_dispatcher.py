"""
Tests for sentinel_sdk.dispatcher — SyncDispatcher.

Coverage:
  - 202 response: no retry, no error
  - 4xx response: no retry (permanent client error)
  - 5xx response: retries up to max_retries, then logs warning
  - Network error: retries up to max_retries
  - enabled=False: no HTTP call made (no-op)

All tests mock urllib.request.urlopen to avoid real network I/O.
"""

from __future__ import annotations

import urllib.error
import urllib.request
from unittest.mock import MagicMock, call, patch

import pytest

import sentinel_sdk
from sentinel_sdk.config import SentinelConfig
from sentinel_sdk.dispatcher import _send_with_retry


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def reset_config():
    """Ensure each test starts with a clean SentinelConfig."""
    SentinelConfig._reset()
    yield
    SentinelConfig._reset()


def _configure(enabled: bool = True) -> SentinelConfig:
    return SentinelConfig.configure(
        api_key="test-key-abc123",
        github_repo="acme/test-repo",
        max_retries=3,
        retry_backoff_base=0.0,  # no sleep in tests
        enabled=enabled,
    )


SAMPLE_PAYLOAD = {
    "exceptionType": "ValueError",
    "errorMessage": "test error",
    "stackTrace": "Traceback...",
    "endpoint": "/test",
    "timestamp": "2026-04-09T00:00:00+00:00",
    "githubRepo": "acme/test-repo",
    "language": "python",
}

_URL = "https://nexuspartner.dev/api/v1/exceptions"


# ---------------------------------------------------------------------------
# _send_with_retry unit tests (lower-level)
# ---------------------------------------------------------------------------

def _mock_response(status: int) -> MagicMock:
    """Return a context-manager mock whose .status == status."""
    mock_resp = MagicMock()
    mock_resp.status = status
    mock_resp.__enter__ = lambda s: s
    mock_resp.__exit__ = MagicMock(return_value=False)
    return mock_resp


def test_202_accepted_no_retry() -> None:
    """A 202 response should succeed on the first attempt with no retry."""
    with patch("urllib.request.urlopen", return_value=_mock_response(202)) as mock_open:
        _send_with_retry(_URL, SAMPLE_PAYLOAD, "key", 5.0, 3, 0.0)
    assert mock_open.call_count == 1


def test_4xx_no_retry() -> None:
    """A 401 response is a permanent client error — must not be retried."""
    http_err = urllib.error.HTTPError(_URL, 401, "Unauthorized", {}, None)
    with patch("urllib.request.urlopen", side_effect=http_err) as mock_open:
        _send_with_retry(_URL, SAMPLE_PAYLOAD, "key", 5.0, 3, 0.0)
    assert mock_open.call_count == 1


def test_403_no_retry() -> None:
    """A 403 response must not be retried."""
    http_err = urllib.error.HTTPError(_URL, 403, "Forbidden", {}, None)
    with patch("urllib.request.urlopen", side_effect=http_err) as mock_open:
        _send_with_retry(_URL, SAMPLE_PAYLOAD, "key", 5.0, 3, 0.0)
    assert mock_open.call_count == 1


def test_500_retries_then_gives_up() -> None:
    """A 500 response should be retried max_retries times."""
    http_err = urllib.error.HTTPError(_URL, 500, "Internal Server Error", {}, None)
    with patch("urllib.request.urlopen", side_effect=http_err) as mock_open:
        _send_with_retry(_URL, SAMPLE_PAYLOAD, "key", 5.0, max_retries=3, backoff_base=0.0)
    assert mock_open.call_count == 3


def test_network_error_retries_then_gives_up() -> None:
    """A URLError (network failure) should trigger retries."""
    url_err = urllib.error.URLError("Connection refused")
    with patch("urllib.request.urlopen", side_effect=url_err) as mock_open:
        _send_with_retry(_URL, SAMPLE_PAYLOAD, "key", 5.0, max_retries=3, backoff_base=0.0)
    assert mock_open.call_count == 3


def test_retry_then_success() -> None:
    """Fail twice (5xx) then succeed — should stop after the third attempt."""
    http_err = urllib.error.HTTPError(_URL, 503, "Service Unavailable", {}, None)
    success = _mock_response(202)
    side_effects = [http_err, http_err, success]
    with patch("urllib.request.urlopen", side_effect=side_effects) as mock_open:
        _send_with_retry(_URL, SAMPLE_PAYLOAD, "key", 5.0, max_retries=3, backoff_base=0.0)
    assert mock_open.call_count == 3


# ---------------------------------------------------------------------------
# SyncDispatcher.dispatch — enabled=False guard
# ---------------------------------------------------------------------------

def test_dispatch_no_op_when_disabled() -> None:
    """When enabled=False no HTTP request should be made."""
    _configure(enabled=False)
    with patch("urllib.request.urlopen") as mock_open:
        from sentinel_sdk.dispatcher import SyncDispatcher
        SyncDispatcher.dispatch(SAMPLE_PAYLOAD)
        # Give the thread pool a moment (it shouldn't submit anything)
        import time; time.sleep(0.05)
    assert mock_open.call_count == 0


def test_dispatch_requires_configure() -> None:
    """Dispatching without calling configure() should raise RuntimeError."""
    from sentinel_sdk.dispatcher import SyncDispatcher
    with pytest.raises(RuntimeError, match="configure\\(\\)"):
        SyncDispatcher.dispatch(SAMPLE_PAYLOAD)
