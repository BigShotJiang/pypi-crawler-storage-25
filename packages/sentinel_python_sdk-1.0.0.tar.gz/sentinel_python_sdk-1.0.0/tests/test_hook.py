"""
Tests for sentinel_sdk.hook — sys.excepthook and threading.excepthook override.

Coverage:
  - sys.excepthook is replaced after install_hook()
  - threading.excepthook is replaced after install_hook()
  - Original hooks are restored after uninstall_hook()
  - install_hook() is idempotent (double-install is a no-op)
  - uninstall_hook() is idempotent (double-uninstall is a no-op)
  - Hook invocation dispatches a payload (mocked dispatcher)
  - Exceptions inside the dispatch helper are swallowed (never propagate)
  - configure() must be called first (raises RuntimeError otherwise)
"""

from __future__ import annotations

import sys
import threading
import types
from unittest.mock import MagicMock, patch

import pytest

from sentinel_sdk.config import SentinelConfig
import sentinel_sdk.hook as hook_module
from sentinel_sdk.hook import install_hook, uninstall_hook, is_installed


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def clean_state():
    """Guarantee hooks are uninstalled and config is reset around every test."""
    uninstall_hook()
    SentinelConfig._reset()
    yield
    uninstall_hook()
    SentinelConfig._reset()


def _configure():
    SentinelConfig.configure(
        api_key="hook-test-key",
        github_repo="acme/hook-repo",
        enabled=True,
    )


# ---------------------------------------------------------------------------
# Installation / restoration
# ---------------------------------------------------------------------------

def test_sys_excepthook_replaced_after_install() -> None:
    _configure()
    original = sys.excepthook
    install_hook()
    assert sys.excepthook is not original
    assert is_installed()


def test_threading_excepthook_replaced_after_install() -> None:
    _configure()
    original = threading.excepthook
    install_hook()
    assert threading.excepthook is not original


def test_original_hooks_restored_after_uninstall() -> None:
    _configure()
    original_sys = sys.excepthook
    original_threading = threading.excepthook
    install_hook()
    uninstall_hook()
    assert sys.excepthook is original_sys
    assert threading.excepthook is original_threading
    assert not is_installed()


def test_install_is_idempotent() -> None:
    """Calling install_hook() twice must not nest hooks."""
    _configure()
    install_hook()
    hook_after_first = sys.excepthook
    install_hook()  # second call — must be a no-op
    assert sys.excepthook is hook_after_first


def test_uninstall_is_idempotent() -> None:
    """Calling uninstall_hook() when not installed must not raise."""
    uninstall_hook()  # no-op — should not raise
    _configure()
    install_hook()
    uninstall_hook()
    uninstall_hook()  # second uninstall — also a no-op


# ---------------------------------------------------------------------------
# Dispatch behaviour
# ---------------------------------------------------------------------------

def test_hook_dispatches_payload_on_exception() -> None:
    """When a hook fires, _dispatch_exception must call SyncDispatcher.dispatch."""
    _configure()
    install_hook()

    with patch("sentinel_sdk.hook._dispatch_exception") as mock_dispatch:
        # Simulate calling the installed sys.excepthook directly.
        try:
            raise ValueError("test error")
        except ValueError:
            et, ev, tb = sys.exc_info()

        sys.excepthook(et, ev, tb)
        mock_dispatch.assert_called_once()


def test_dispatch_error_is_swallowed() -> None:
    """If the dispatcher raises, the hook must not propagate the error."""
    _configure()
    install_hook()

    with patch(
        "sentinel_sdk.hook._dispatch_exception",
        side_effect=RuntimeError("dispatch exploded"),
    ):
        # The original hook should still be called even if _dispatch_exception fails.
        # Because our wrapper catches all exceptions from _dispatch_exception,
        # calling sys.excepthook should not raise.
        try:
            raise ValueError("trigger")
        except ValueError:
            et, ev, tb = sys.exc_info()

        # Should not raise — errors are swallowed inside the wrapper.
        sys.excepthook(et, ev, tb)


# ---------------------------------------------------------------------------
# Pre-condition: configure() must be called first
# ---------------------------------------------------------------------------

def test_install_without_configure_raises() -> None:
    with pytest.raises(RuntimeError, match="configure\\(\\)"):
        install_hook()
