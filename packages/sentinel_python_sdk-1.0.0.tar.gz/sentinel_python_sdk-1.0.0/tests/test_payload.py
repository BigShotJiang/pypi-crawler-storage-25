"""
Tests for sentinel_sdk._payload — ExceptionRequest builder.

Coverage:
  - All 7 fields present and correct types
  - language field is always "python"
  - exceptionType fully-qualified format
  - PII scrubbed in errorMessage and stackTrace
  - timestamp is ISO-8601
  - tb=None path (no traceback available)
"""

import re
from datetime import timezone

import pytest

from sentinel_sdk._payload import build_payload, _format_exception_type


REPO = "acme/my-service"
ENDPOINT = "/api/orders"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_exc_info(message: str = "something went wrong"):
    """Return (exc_type, exc_value, tb) for a live exception."""
    try:
        raise ValueError(message)
    except ValueError:
        import sys
        return sys.exc_info()


# ---------------------------------------------------------------------------
# Payload shape
# ---------------------------------------------------------------------------

def test_all_fields_present() -> None:
    exc_type, exc_value, tb = _make_exc_info()
    payload = build_payload(exc_type, exc_value, tb, ENDPOINT, REPO)

    expected_keys = {
        "exceptionType", "errorMessage", "stackTrace",
        "endpoint", "timestamp", "githubRepo", "language",
    }
    assert set(payload.keys()) == expected_keys


def test_language_is_python() -> None:
    exc_type, exc_value, tb = _make_exc_info()
    payload = build_payload(exc_type, exc_value, tb, ENDPOINT, REPO)
    assert payload["language"] == "python"


def test_github_repo_passed_through() -> None:
    exc_type, exc_value, tb = _make_exc_info()
    payload = build_payload(exc_type, exc_value, tb, ENDPOINT, REPO)
    assert payload["githubRepo"] == REPO


def test_endpoint_passed_through() -> None:
    exc_type, exc_value, tb = _make_exc_info()
    payload = build_payload(exc_type, exc_value, tb, ENDPOINT, REPO)
    assert payload["endpoint"] == ENDPOINT


def test_timestamp_is_iso8601() -> None:
    exc_type, exc_value, tb = _make_exc_info()
    payload = build_payload(exc_type, exc_value, tb, ENDPOINT, REPO)
    ts = payload["timestamp"]
    # Must parse without error and include timezone offset (+00:00 or Z)
    from datetime import datetime
    dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
    assert dt.tzinfo is not None


# ---------------------------------------------------------------------------
# exceptionType formatting
# ---------------------------------------------------------------------------

def test_exception_type_includes_module() -> None:
    exc_type, exc_value, tb = _make_exc_info()
    payload = build_payload(exc_type, exc_value, tb, ENDPOINT, REPO)
    # ValueError lives in builtins — format_exception_type omits "builtins."
    assert payload["exceptionType"] == "ValueError"


def test_exception_type_third_party_module() -> None:
    """A non-builtin exception should include its full module path."""
    import importlib
    # Use a real non-builtins exception from the stdlib
    import json
    try:
        json.loads("not-json")
    except json.JSONDecodeError:
        import sys
        et, ev, tb = sys.exc_info()

    result = _format_exception_type(et)
    assert "json" in result.lower()
    assert "JSONDecodeError" in result


# ---------------------------------------------------------------------------
# PII scrubbing in errorMessage and stackTrace
# ---------------------------------------------------------------------------

def test_error_message_pii_scrubbed() -> None:
    try:
        raise RuntimeError("User admin@example.com failed auth with password=s3cret")
    except RuntimeError:
        import sys
        et, ev, tb = sys.exc_info()

    payload = build_payload(et, ev, tb, ENDPOINT, REPO)
    assert "admin@example.com" not in payload["errorMessage"]
    assert "s3cret" not in payload["errorMessage"]
    assert "[EMAIL]" in payload["errorMessage"]
    assert "[REDACTED_SECRET]" in payload["errorMessage"]


def test_stack_trace_pii_scrubbed() -> None:
    """Stack trace should have IPs and emails redacted."""
    try:
        raise ValueError("Connected from 192.168.1.1")
    except ValueError:
        import sys
        et, ev, tb = sys.exc_info()

    payload = build_payload(et, ev, tb, ENDPOINT, REPO)
    assert "192.168.1.1" not in payload["stackTrace"]
    assert "[IP_ADDRESS]" in payload["stackTrace"]


# ---------------------------------------------------------------------------
# No traceback path
# ---------------------------------------------------------------------------

def test_no_traceback_returns_string() -> None:
    payload = build_payload(ValueError, ValueError("oops"), None, ENDPOINT, REPO)
    assert isinstance(payload["stackTrace"], str)
    assert len(payload["stackTrace"]) > 0
