"""
Tests for sentinel_sdk.middleware — SentinelMiddleware (FastAPI integration).

Coverage:
  - Exception in a route triggers _capture (mocked)
  - Exception is re-raised so FastAPI returns 500 (not swallowed)
  - Non-exception request path does NOT trigger _capture
  - Middleware raises RuntimeError at construction if configure() not called
  - endpoint field matches request.url.path
  - language field in captured payload is "python"

Requires: fastapi, httpx (both in dev extras).
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from sentinel_sdk.config import SentinelConfig
from sentinel_sdk.middleware import SentinelMiddleware


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def reset_config():
    SentinelConfig._reset()
    yield
    SentinelConfig._reset()


def _configure():
    SentinelConfig.configure(
        api_key="mw-test-key",
        github_repo="acme/mw-repo",
        enabled=True,
    )


def _build_app() -> FastAPI:
    """Build a minimal FastAPI app with the Sentinel middleware."""
    app = FastAPI()
    app.add_middleware(SentinelMiddleware)

    @app.get("/ok")
    def ok_route():
        return {"status": "ok"}

    @app.get("/boom")
    def boom_route():
        raise ValueError("intentional error")

    return app


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_middleware_requires_configure() -> None:
    """Constructing the middleware without configure() must raise RuntimeError."""
    app = FastAPI()
    with pytest.raises(RuntimeError, match="configure\\(\\)"):
        app.add_middleware(SentinelMiddleware)
        # Middleware __init__ runs when the app is first used.
        with TestClient(app):
            pass


def test_exception_triggers_capture() -> None:
    """An exception in a route must call _capture exactly once."""
    _configure()
    app = _build_app()

    with patch("sentinel_sdk.middleware._capture") as mock_capture:
        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get("/boom")

    assert resp.status_code == 500
    mock_capture.assert_called_once()


def test_exception_is_reraised() -> None:
    """Sentinel must not swallow the exception — FastAPI should still return 500."""
    _configure()
    app = _build_app()

    with patch("sentinel_sdk.middleware._capture"):
        client = TestClient(app, raise_server_exceptions=False)
        resp = client.get("/boom")

    assert resp.status_code == 500


def test_clean_request_does_not_trigger_capture() -> None:
    """A request that completes without error must not call _capture."""
    _configure()
    app = _build_app()

    with patch("sentinel_sdk.middleware._capture") as mock_capture:
        client = TestClient(app)
        resp = client.get("/ok")

    assert resp.status_code == 200
    mock_capture.assert_not_called()


def test_captured_payload_endpoint_matches_path() -> None:
    """The endpoint field in the payload must equal the request path."""
    _configure()
    captured_payloads = []

    def fake_capture(exc, request):
        from sentinel_sdk._payload import build_payload
        from sentinel_sdk.config import SentinelConfig
        cfg = SentinelConfig.get()
        payload = build_payload(
            type(exc), exc, exc.__traceback__,
            str(request.url.path),
            cfg.github_repo,
        )
        captured_payloads.append(payload)

    app = _build_app()

    with patch("sentinel_sdk.middleware._capture", side_effect=fake_capture):
        client = TestClient(app, raise_server_exceptions=False)
        client.get("/boom")

    assert len(captured_payloads) == 1
    assert captured_payloads[0]["endpoint"] == "/boom"


def test_captured_payload_language_is_python() -> None:
    """The language field in the captured payload must always be 'python'."""
    _configure()
    captured_payloads = []

    def fake_capture(exc, request):
        from sentinel_sdk._payload import build_payload
        from sentinel_sdk.config import SentinelConfig
        cfg = SentinelConfig.get()
        payload = build_payload(
            type(exc), exc, exc.__traceback__,
            str(request.url.path),
            cfg.github_repo,
        )
        captured_payloads.append(payload)

    app = _build_app()

    with patch("sentinel_sdk.middleware._capture", side_effect=fake_capture):
        client = TestClient(app, raise_server_exceptions=False)
        client.get("/boom")

    assert captured_payloads[0]["language"] == "python"
