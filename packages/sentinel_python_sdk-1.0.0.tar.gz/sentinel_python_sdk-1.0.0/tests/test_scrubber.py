"""
Tests for sentinel_sdk.scrubber — PiiScrubber.

Coverage:
  - Each of the 5 PII categories: match cases + boundary cases
  - Multi-pattern text (multiple categories in one string)
  - Empty string / no-PII pass-through
  - Credit card with separators and without
"""

import pytest

from sentinel_sdk.scrubber import scrub


# ---------------------------------------------------------------------------
# Category 1: Email addresses
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw, expected", [
    # Standard emails
    ("Contact user@acme.com for help", "Contact [EMAIL] for help"),
    ("admin@example.co.uk replied", "[EMAIL] replied"),
    # Subdomain
    ("dev.ops+tag@mail.internal.example.com", "[EMAIL]"),
    # Already clean — must be unchanged
    ("No email here at all", "No email here at all"),
    # Multiple emails
    (
        "From a@b.com to c@d.org",
        "From [EMAIL] to [EMAIL]",
    ),
])
def test_email_scrubbing(raw: str, expected: str) -> None:
    assert scrub(raw) == expected


# ---------------------------------------------------------------------------
# Category 2: Credit card numbers
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw, expected", [
    # Space-separated
    ("Card: 4111 1111 1111 1111 processed", "Card: [CREDIT_CARD] processed"),
    # Hyphen-separated
    ("CC 4111-1111-1111-1111 expired", "CC [CREDIT_CARD] expired"),
    # No separator (16 digits)
    ("Number 4111111111111111 charged", "Number [CREDIT_CARD] charged"),
    # 15-digit Amex
    ("Amex 378282246310005 used", "Amex [CREDIT_CARD] used"),
    # Not a CC (short number — no match)
    ("Error code 12345 returned", "Error code 12345 returned"),
])
def test_credit_card_scrubbing(raw: str, expected: str) -> None:
    assert scrub(raw) == expected


# ---------------------------------------------------------------------------
# Category 3: IPv4 addresses
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw, expected", [
    ("Connected to 192.168.1.100 port 5432", "Connected to [IP_ADDRESS] port 5432"),
    ("Remote: 10.0.0.1", "Remote: [IP_ADDRESS]"),
    ("Loopback 127.0.0.1 accepted", "Loopback [IP_ADDRESS] accepted"),
    ("Max address 255.255.255.255", "Max address [IP_ADDRESS]"),
    # Not an IP — version string should not be redacted
    ("Version 1.2.3 released", "Version 1.2.3 released"),
])
def test_ipv4_scrubbing(raw: str, expected: str) -> None:
    assert scrub(raw) == expected


# ---------------------------------------------------------------------------
# Category 3b: IPv6 addresses
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw, expected", [
    # Full 8-group form
    (
        "Connected to 2001:0db8:85a3:0000:0000:8a2e:0370:7334",
        "Connected to [IP_ADDRESS]",
    ),
    # Compressed form (:: notation)
    ("Server 2001:db8::1 offline", "Server [IP_ADDRESS] offline"),
    # Loopback
    ("Request from ::1 rejected", "Request from [IP_ADDRESS] rejected"),
    # Version string — must NOT be redacted (dot-separated, fewer than 3 colon groups)
    ("Version 1.2.3 released", "Version 1.2.3 released"),
    # Short colon-pair — must NOT be redacted (only 1 additional colon group)
    ("host:port 80:443 forwarded", "host:port 80:443 forwarded"),
])
def test_ipv6_scrubbing(raw: str, expected: str) -> None:
    assert scrub(raw) == expected


# ---------------------------------------------------------------------------
# Category 4: Bearer / API tokens
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw, expected", [
    # Authorization header style
    (
        "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload.sig",
        "Authorization: Bearer [REDACTED_TOKEN]",
    ),
    (
        "Authorization: Token abc123xyz",
        "Authorization: Token [REDACTED_TOKEN]",
    ),
    # Case-insensitive bearer
    (
        "authorization: bearer sk-abc123",
        "authorization: bearer [REDACTED_TOKEN]",
    ),
    # Well-known prefixes
    ("Found key ghp_AbCdEfGhIjKlMnOpQrStUvWxYz", "Found key [REDACTED_TOKEN]"),
    ("API key re_abcdef1234567890", "API key [REDACTED_TOKEN]"),
    ("Slack token xoxb-123-456-abc", "Slack token [REDACTED_TOKEN]"),
    # No token — unchanged
    ("No authorization header present", "No authorization header present"),
])
def test_bearer_token_scrubbing(raw: str, expected: str) -> None:
    assert scrub(raw) == expected


# ---------------------------------------------------------------------------
# Category 5: Generic secret key-value pairs
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("raw, expected", [
    ("password=s3cr3tV@lue!", "password=[REDACTED_SECRET]"),
    ("api_key=abcdef123456", "api_key=[REDACTED_SECRET]"),
    ("SECRET=hunter2", "SECRET=[REDACTED_SECRET]"),
    ("token=eyJhbGciOiJIUzI1NiJ9", "token=[REDACTED_SECRET]"),
    ("access_token=xyzzy999", "access_token=[REDACTED_SECRET]"),
    # Quoted values
    ('secret="my-secret-value"', 'secret=[REDACTED_SECRET]'),
    # Not a secret field — unchanged
    ("order_count=42 items processed", "order_count=42 items processed"),
])
def test_generic_secret_scrubbing(raw: str, expected: str) -> None:
    assert scrub(raw) == expected


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

def test_empty_string_unchanged() -> None:
    assert scrub("") == ""


def test_no_pii_unchanged() -> None:
    text = "NullPointerException at com.example.Service.process(Service.java:42)"
    assert scrub(text) == text


def test_credit_card_luhn_validation() -> None:
    """Luhn-valid card numbers are scrubbed; Luhn-failing strings are not."""
    # Standard Visa test card — passes Luhn → must be scrubbed
    assert scrub("charged 4111111111111111") == "charged [CREDIT_CARD]"
    # Luhn-failing 16-digit string → must NOT be scrubbed
    assert scrub("ref 1234567890123456 logged") == "ref 1234567890123456 logged"


def test_multiple_categories_in_one_string() -> None:
    raw = (
        "User user@acme.com from 192.168.1.5 used card 4111-1111-1111-1111 "
        "with token ghp_AbCdEfGhIj"
    )
    result = scrub(raw)
    assert "[EMAIL]" in result
    assert "[IP_ADDRESS]" in result
    assert "[CREDIT_CARD]" in result
    assert "[REDACTED_TOKEN]" in result
    # Originals must be gone
    assert "user@acme.com" not in result
    assert "192.168.1.5" not in result
    assert "4111-1111-1111-1111" not in result
    assert "ghp_AbCdEfGhIj" not in result
