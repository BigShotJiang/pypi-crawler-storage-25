"""
sentinel_sdk.scrubber
~~~~~~~~~~~~~~~~~~~~~

Pure, stateless PII scrubbing module.

All five regex patterns are compiled once at module import.  The public
surface is a single function:

    scrub(text: str) -> str

It applies every pattern in order and returns the sanitised string.  The
function never raises; if compilation or substitution somehow fails the
original text is returned unchanged so that payloads are never silently
dropped.

Categories (mirrors sentinel-spring-boot-starter PiiScrubber):
  1. Email addresses
  2. Credit card numbers (13–19 digit sequences with optional separators)
  3. IPv4 addresses
  4. Bearer / API tokens (Authorization headers, well-known key prefixes)
  5. Generic secrets (password=, api_key=, secret=, token= key-value pairs)

No external dependencies.  Importable independently of the rest of the SDK.
"""

from __future__ import annotations

import logging
import re
from typing import Tuple

_log = logging.getLogger("sentinel_sdk.scrubber")

# ---------------------------------------------------------------------------
# Compiled patterns
# ---------------------------------------------------------------------------

# 1. Email addresses
#    Match standard RFC-5321 local-parts and common TLDs.
#    Replaced with [EMAIL].
_EMAIL = re.compile(
    r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}",
    re.IGNORECASE,
)

# 2. Credit card numbers
#    Matches 13–19 digit sequences, optionally separated by spaces or hyphens
#    (e.g. 4111-1111-1111-1111 or 4111111111111111).  Uses a word boundary so
#    long numeric strings like timestamps are not falsely matched.
#    Replaced with [CREDIT_CARD].
_CREDIT_CARD = re.compile(
    r"\b(?:\d[ \-]?){13,18}\d\b",
)

# 3. IPv4 addresses
#    Four octets (0–255) separated by dots.  Word boundaries prevent matching
#    partial version strings like "1.2.3.4.5".
#    Replaced with [IP_ADDRESS].
_IPV4 = re.compile(
    r"\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b",
)

# 3b. IPv6 addresses — full and compressed notation, plus loopback (::1).
#     First branch: one leading hex group followed by 2–7 colon-prefixed groups
#     (each 0–4 hex digits) to allow "::" compression without false-matching
#     short sequences like "80:443" (only 1 additional group).
#     Second branch: bare loopback "::1".
#     Lookbehind/lookahead on [.\w] prevent false matches inside version strings
#     and dotted-quad addresses that were already replaced by _IPV4.
#     Replaced with [IP_ADDRESS].
_IPV6 = re.compile(
    r"(?<![.\w])"
    r"(?:"
    r"[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{0,4}){2,7}"  # full / compressed (≥ 3 colon-sep groups)
    r"|::1"                                            # loopback
    r")"
    r"(?![.\w])",
    re.IGNORECASE,
)

# 4. Bearer / API tokens
#    Targets three sub-patterns in one alternation:
#      a) "Authorization: Bearer <token>" / "Authorization: Token <token>"
#      b) Well-known key prefixes: sk-, ghp_, re_, xoxb-, AIza, pk_live_, pk_test_
#      c) Raw "Bearer <token>" anywhere in text
#    The key/prefix is preserved; only the token value is redacted.
#    Replaced with [REDACTED_TOKEN] (value portion only for a/c).
_BEARER_TOKEN = re.compile(
    r"((?:Authorization\s*:\s*)?(?:Bearer|Token)\s+)\S+|"
    r"\b(?:sk-|ghp_|gho_|re_|xoxb-|AIza|pk_live_|pk_test_)\S+",
    re.IGNORECASE,
)

# 5. Generic secret key-value pairs
#    Matches patterns like:
#      password=s3cret, api_key="abc123", secret: 'xyz', token=abcdef
#    The key name is preserved; only the value is redacted.
#    Replaced with <key>=[REDACTED_SECRET].
_GENERIC_SECRET = re.compile(
    r"((?:password|passwd|api[_\-]?key|secret|token|auth[_\-]?token|access[_\-]?token)"
    r"\s*[=:]\s*)['\"]?\S+['\"]?",
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Luhn checksum helper
# ---------------------------------------------------------------------------

def _luhn_valid(s: str) -> bool:
    """Return True if the digit sequence in *s* passes the Luhn checksum.

    Used as a guard for credit card replacement: only sequences that pass
    the checksum are treated as card numbers, reducing false positives on
    long numeric strings such as order IDs and timestamps.
    """
    digits = [int(c) for c in s if c.isdigit()]
    if len(digits) < 13:
        return False
    total = 0
    for i, d in enumerate(reversed(digits)):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


# Ordered list of (pattern, replacement) pairs — applied left to right.
# For patterns that use a capture group to preserve the key name, the
# replacement is a callable so we can splice in [REDACTED_*] after group 1.
_RULES: Tuple[Tuple[re.Pattern, object], ...] = (
    (_EMAIL,          "[EMAIL]"),
    # Credit card: only replace when the matched digit sequence passes Luhn
    # validation.  This eliminates false positives on order IDs, timestamps,
    # and other long numeric strings that happen to match the length range.
    (_CREDIT_CARD,    lambda m: "[CREDIT_CARD]" if _luhn_valid(m.group()) else m.group()),
    (_IPV4,           "[IP_ADDRESS]"),
    (_IPV6,           "[IP_ADDRESS]"),
    (_BEARER_TOKEN,   lambda m: (m.group(1) + "[REDACTED_TOKEN]") if m.group(1) else "[REDACTED_TOKEN]"),
    (_GENERIC_SECRET, r"\1[REDACTED_SECRET]"),
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def scrub(text: str) -> str:
    """
    Return *text* with all detected PII patterns replaced by safe placeholders.

    Never raises.  If an unexpected error occurs during substitution the
    original *text* is returned unchanged so callers always receive a string.
    """
    if not text:
        return text

    try:
        result = text
        for pattern, replacement in _RULES:
            result = pattern.sub(replacement, result)
        return result
    except Exception:
        _log.error(
            "PiiScrubber encountered an unexpected error; returning original text.",
            exc_info=True,
        )
        return text
