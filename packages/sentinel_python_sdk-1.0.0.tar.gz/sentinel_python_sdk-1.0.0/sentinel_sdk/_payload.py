"""
sentinel_sdk._payload
~~~~~~~~~~~~~~~~~~~~~

Private module.  Builds the ``ExceptionRequest`` JSON dict that the
sentinel-gateway expects on ``POST /api/v1/exceptions``.

The payload contract mirrors ``sentinel-gateway/models.py::ExceptionRequest``
exactly.  Field names are camelCase to match the Pydantic model and the
existing Java SDK wire format.

    {
        "exceptionType": "module.ClassName",
        "errorMessage":  "...",   # PII-scrubbed
        "stackTrace":    "...",   # PII-scrubbed
        "endpoint":      "/api/orders",
        "timestamp":     "2026-04-09T14:22:00.123456+00:00",
        "githubRepo":    "acme/my-service",
        "language":      "python"   ← hardcoded; routes to Python LangGraph nodes
    }

Do not import this module directly — use it via ``sentinel_sdk.hook`` or
``sentinel_sdk.middleware``.
"""

from __future__ import annotations

import traceback
import types
from datetime import datetime, timezone
from typing import Optional, Type

from sentinel_sdk.scrubber import scrub


def build_payload(
    exc_type: Type[BaseException],
    exc_value: BaseException,
    tb: Optional[types.TracebackType],
    endpoint: str,
    github_repo: str,
) -> dict:
    """
    Assemble the ``ExceptionRequest`` payload dict from raw exception info.

    Parameters
    ----------
    exc_type:
        The exception class (e.g. ``ValueError``).
    exc_value:
        The exception instance.
    tb:
        The traceback object, or ``None`` if not available.
    endpoint:
        The HTTP route or label that was active when the exception occurred.
    github_repo:
        The configured ``owner/repo`` string from ``SentinelConfig``.

    Returns
    -------
    dict
        A plain dict ready to be JSON-serialised and posted to the gateway.
    """
    exception_type = _format_exception_type(exc_type)
    error_message = scrub(str(exc_value)) if exc_value is not None else ""
    stack_trace = scrub(_format_traceback(exc_type, exc_value, tb))
    timestamp = datetime.now(timezone.utc).isoformat()

    return {
        "exceptionType": exception_type,
        "errorMessage": error_message,
        "stackTrace": stack_trace,
        "endpoint": endpoint,
        "timestamp": timestamp,
        "githubRepo": github_repo,
        "language": "python",
    }


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _format_exception_type(exc_type: Type[BaseException]) -> str:
    """
    Return the fully-qualified class name: ``"module.ClassName"``.

    Examples
    --------
    ``ValueError``               → ``"builtins.ValueError"``
    ``fastapi.HTTPException``    → ``"fastapi.exceptions.HTTPException"``
    """
    module = getattr(exc_type, "__module__", None) or ""
    qualname = getattr(exc_type, "__qualname__", None) or exc_type.__name__
    if module and module != "builtins":
        return f"{module}.{qualname}"
    return qualname


def _format_traceback(
    exc_type: Type[BaseException],
    exc_value: BaseException,
    tb: Optional[types.TracebackType],
) -> str:
    """
    Return the traceback as a single string, matching the format that the
    Java SDK produces and that the sentinel-agent stack-frame parser expects.

    Uses ``traceback.format_exception`` so the output includes the exception
    type and message at the end — the same convention as Python's default
    ``sys.excepthook`` output.
    """
    if tb is None:
        # No traceback available (e.g. exception raised without one).
        return f"{_format_exception_type(exc_type)}: {exc_value}"

    lines = traceback.format_exception(exc_type, exc_value, tb)
    return "".join(lines)
