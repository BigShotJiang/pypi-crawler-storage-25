"""
sentinel_sdk.middleware
~~~~~~~~~~~~~~~~~~~~~~~~

FastAPI / Starlette middleware that captures unhandled exceptions from HTTP
request handlers and reports them to Sentinel.

Usage
-----
    from fastapi import FastAPI
    from sentinel_sdk import configure, SentinelMiddleware

    configure(api_key="...", github_repo="acme/my-service")

    app = FastAPI()
    app.add_middleware(SentinelMiddleware)

Design notes
------------
* The middleware re-raises every exception it catches so that FastAPI's own
  exception handlers (including custom ``@app.exception_handler`` callbacks)
  still run and the client receives a proper 500 response.  Sentinel only
  observes — it never intercepts.

* ``endpoint`` is set to ``request.url.path`` (e.g. ``"/api/orders"``),
  which mirrors what the Java SDK reads from
  ``HttpServletRequest.getRequestURI()``.

* Dispatch uses ``AsyncDispatcher`` (``asyncio.create_task``) so it is a
  true non-blocking fire-and-forget inside the event loop.  If ``httpx`` is
  not installed the SDK gracefully falls back to ``SyncDispatcher`` (which
  uses a daemon thread) so the middleware works even without the ``[async]``
  extra — at the cost of a thread-pool dispatch instead of a coroutine.

* ``SentinelConfig`` is validated at middleware construction time (inside
  ``__init__``) so misconfiguration surfaces when the application starts,
  not the first time a request fails.
"""

from __future__ import annotations

import logging

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response
from starlette.types import ASGIApp

_log = logging.getLogger("sentinel_sdk.middleware")


class SentinelMiddleware(BaseHTTPMiddleware):
    """
    Starlette ``BaseHTTPMiddleware`` that reports unhandled exceptions to
    the Sentinel gateway.

    Add to a FastAPI application:

        app.add_middleware(SentinelMiddleware)

    ``SentinelConfig.configure()`` must have been called before the
    application starts.
    """

    def __init__(self, app: ASGIApp, **kwargs) -> None:
        super().__init__(app, **kwargs)
        # Validate configuration eagerly at startup — not lazily at first
        # exception.  Raises RuntimeError if configure() was never called.
        from sentinel_sdk.config import SentinelConfig
        SentinelConfig.get()

    async def dispatch(self, request: Request, call_next) -> Response:
        try:
            response = await call_next(request)
            return response
        except Exception as exc:
            _capture(exc, request)
            raise  # Re-raise so FastAPI's exception handlers still run.


# ---------------------------------------------------------------------------
# Internal capture helper
# ---------------------------------------------------------------------------

def _capture(exc: Exception, request: Request) -> None:
    """
    Build the payload and fire it asynchronously.  Never raises.
    """
    try:
        from sentinel_sdk._payload import build_payload
        from sentinel_sdk.config import SentinelConfig

        cfg = SentinelConfig.get()
        endpoint = str(request.url.path)
        payload = build_payload(
            type(exc),
            exc,
            exc.__traceback__,
            endpoint,
            cfg.github_repo,
        )
        _dispatch_payload(payload)
    except Exception:
        _log.warning(
            "Sentinel middleware failed to capture exception; not reported.",
            exc_info=True,
        )


def _dispatch_payload(payload: dict) -> None:
    """
    Prefer ``AsyncDispatcher``; fall back to ``SyncDispatcher`` if httpx is
    not installed.
    """
    try:
        from sentinel_sdk.dispatcher import AsyncDispatcher
        AsyncDispatcher.dispatch(payload)
    except ImportError:
        _log.debug(
            "httpx not available; falling back to SyncDispatcher for middleware."
        )
        from sentinel_sdk.dispatcher import SyncDispatcher
        SyncDispatcher.dispatch(payload)
