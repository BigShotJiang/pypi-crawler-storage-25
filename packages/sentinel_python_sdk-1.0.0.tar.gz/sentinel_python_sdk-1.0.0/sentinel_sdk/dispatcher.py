"""
sentinel_sdk.dispatcher
~~~~~~~~~~~~~~~~~~~~~~~~

Non-blocking HTTP dispatchers for sending exception payloads to the
sentinel-gateway.

Two implementations are provided:

SyncDispatcher
    Uses a single-thread ``ThreadPoolExecutor`` (daemon=True) to fire-and-
    forget.  The calling thread returns immediately.  Uses ``urllib.request``
    from the standard library — zero required extra dependencies.

AsyncDispatcher
    Uses ``asyncio.create_task`` for true async fire-and-forget inside an
    event loop.  Requires the ``[async]`` extra (``httpx``).  Designed for
    FastAPI / Starlette applications.

Both dispatchers:
  - Respect ``SentinelConfig.enabled`` (no-op when False).
  - Retry on 5xx and network errors with exponential backoff + jitter.
  - Never raise into the calling application on failure — all errors are
    logged at WARNING level.
  - Send ``Authorization: Bearer <api_key>`` and ``Content-Type: application/json``.
"""

from __future__ import annotations

import json
import logging
import math
import random
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

_log = logging.getLogger("sentinel_sdk.dispatcher")

_GATEWAY_PATH = "/api/v1/exceptions"

# Status codes that are transient and worth retrying.
_RETRYABLE_STATUS = frozenset({429, 500, 502, 503, 504})


# ---------------------------------------------------------------------------
# Shared send logic (urllib — stdlib only)
# ---------------------------------------------------------------------------

def _send_once(url: str, payload: dict, api_key: str, timeout: float) -> int:
    """
    POST *payload* to *url*.  Returns the HTTP status code.
    Raises ``urllib.error.URLError`` / ``urllib.error.HTTPError`` on failure.
    """
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
            "User-Agent": "sentinel-python-sdk/1.0",
        },
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status


def _send_with_retry(
    url: str,
    payload: dict,
    api_key: str,
    timeout: float,
    max_retries: int,
    backoff_base: float,
) -> None:
    """
    Attempt to POST the payload up to *max_retries* times.

    Retry policy:
      - Only retry on network errors or 5xx / 429 responses.
      - 4xx responses (auth / validation failures) are not retried — they are
        permanent client errors.
      - Backoff: ``backoff_base * 2^attempt + jitter`` seconds (full jitter).
    """
    last_exc: Optional[Exception] = None

    for attempt in range(max_retries):
        try:
            status = _send_once(url, payload, api_key, timeout)

            if status == 202:
                _log.debug("Sentinel payload accepted (202). attempt=%d", attempt)
                return

            if status in _RETRYABLE_STATUS:
                _log.warning(
                    "Sentinel gateway returned retryable status %d. attempt=%d/%d",
                    status,
                    attempt + 1,
                    max_retries,
                )
                last_exc = RuntimeError(f"HTTP {status}")
            else:
                # 4xx — permanent client error, don't retry.
                _log.warning(
                    "Sentinel gateway rejected payload with status %d (not retrying). "
                    "Check api_key and github_repo configuration.",
                    status,
                )
                return

        except urllib.error.HTTPError as exc:
            status = exc.code
            if status in _RETRYABLE_STATUS:
                _log.warning(
                    "Sentinel gateway HTTP error %d. attempt=%d/%d",
                    status,
                    attempt + 1,
                    max_retries,
                )
                last_exc = exc
            else:
                _log.warning(
                    "Sentinel gateway rejected payload with HTTP %d: %s (not retrying).",
                    status,
                    exc.reason,
                )
                return

        except (urllib.error.URLError, OSError, TimeoutError) as exc:
            _log.warning(
                "Sentinel dispatch network error: %s. attempt=%d/%d",
                exc,
                attempt + 1,
                max_retries,
            )
            last_exc = exc

        # Exponential backoff with full jitter before the next attempt.
        if attempt < max_retries - 1:
            ceiling = backoff_base * math.pow(2, attempt)
            sleep_for = random.uniform(0, ceiling)
            _log.debug("Sentinel backoff %.2fs before retry.", sleep_for)
            time.sleep(sleep_for)

    _log.warning(
        "Sentinel failed to deliver exception payload after %d attempt(s). "
        "Last error: %s",
        max_retries,
        last_exc,
    )


# ---------------------------------------------------------------------------
# SyncDispatcher
# ---------------------------------------------------------------------------

class SyncDispatcher:
    """
    Thread-pool-based fire-and-forget dispatcher.

    A single daemon thread handles all sends so the calling application
    thread never blocks.  The executor is created lazily on first use.

    Lifecycle
    ---------
    The executor runs as a daemon — it exits when the main process exits
    without requiring an explicit ``shutdown()`` call.  In-flight sends that
    have not completed when the process exits will be abandoned (acceptable
    trade-off for a fire-and-forget monitoring SDK).
    """

    _executor: Optional[ThreadPoolExecutor] = None
    _executor_lock = threading.Lock() if False else __import__("threading").Lock()

    @classmethod
    def _get_executor(cls) -> ThreadPoolExecutor:
        if cls._executor is None:
            with cls._executor_lock:
                if cls._executor is None:
                    cls._executor = ThreadPoolExecutor(
                        max_workers=1,
                        thread_name_prefix="sentinel-dispatch",
                    )
        return cls._executor

    @classmethod
    def dispatch(cls, payload: dict) -> None:
        """
        Submit *payload* for asynchronous delivery.  Returns immediately.

        If ``SentinelConfig.enabled`` is False this is a deliberate no-op.
        """
        from sentinel_sdk.config import SentinelConfig

        cfg = SentinelConfig.get()
        if not cfg.enabled:
            _log.debug("Sentinel SDK disabled — skipping dispatch.")
            return

        url = cfg.gateway_url + _GATEWAY_PATH

        cls._get_executor().submit(
            _send_with_retry,
            url,
            payload,
            cfg.api_key,
            cfg.timeout_seconds,
            cfg.max_retries,
            cfg.retry_backoff_base,
        )


# ---------------------------------------------------------------------------
# AsyncDispatcher (requires httpx — install sentinel-python-sdk[async])
# ---------------------------------------------------------------------------

class AsyncDispatcher:
    """
    Async fire-and-forget dispatcher for ASGI frameworks (FastAPI, Starlette).

    Requires ``httpx`` (``pip install sentinel-python-sdk[async]``).
    ``dispatch()`` schedules a background coroutine via ``asyncio.create_task``
    so the awaiting coroutine resumes immediately.
    """

    @classmethod
    def dispatch(cls, payload: dict) -> None:
        """
        Schedule an async send and return immediately.

        Must be called from within a running event loop.  Raises
        ``ImportError`` if ``httpx`` is not installed.
        """
        import asyncio

        from sentinel_sdk.config import SentinelConfig

        cfg = SentinelConfig.get()
        if not cfg.enabled:
            _log.debug("Sentinel SDK disabled — skipping async dispatch.")
            return

        url = cfg.gateway_url + _GATEWAY_PATH

        asyncio.create_task(
            cls._send_async(
                url,
                payload,
                cfg.api_key,
                cfg.timeout_seconds,
                cfg.max_retries,
                cfg.retry_backoff_base,
            )
        )

    @staticmethod
    async def _send_async(
        url: str,
        payload: dict,
        api_key: str,
        timeout: float,
        max_retries: int,
        backoff_base: float,
    ) -> None:
        try:
            import httpx
        except ImportError as exc:
            raise ImportError(
                "sentinel-python-sdk[async] requires httpx. "
                "Install it with: pip install sentinel-python-sdk[async]"
            ) from exc

        import asyncio
        import math
        import random

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
            "User-Agent": "sentinel-python-sdk/1.0",
        }
        body = json.dumps(payload, ensure_ascii=False)
        last_exc: Optional[Exception] = None

        async with httpx.AsyncClient(timeout=timeout) as client:
            for attempt in range(max_retries):
                try:
                    resp = await client.post(url, content=body, headers=headers)
                    if resp.status_code == 202:
                        _log.debug(
                            "Sentinel async payload accepted (202). attempt=%d", attempt
                        )
                        return
                    if resp.status_code in _RETRYABLE_STATUS:
                        _log.warning(
                            "Sentinel gateway %d (async). attempt=%d/%d",
                            resp.status_code,
                            attempt + 1,
                            max_retries,
                        )
                        last_exc = RuntimeError(f"HTTP {resp.status_code}")
                    else:
                        _log.warning(
                            "Sentinel gateway rejected async payload %d (not retrying).",
                            resp.status_code,
                        )
                        return
                except (httpx.TimeoutException, httpx.NetworkError) as exc:
                    _log.warning(
                        "Sentinel async dispatch error: %s. attempt=%d/%d",
                        exc,
                        attempt + 1,
                        max_retries,
                    )
                    last_exc = exc

                if attempt < max_retries - 1:
                    ceiling = backoff_base * math.pow(2, attempt)
                    sleep_for = random.uniform(0, ceiling)
                    await asyncio.sleep(sleep_for)

        _log.warning(
            "Sentinel async dispatcher failed after %d attempt(s). Last error: %s",
            max_retries,
            last_exc,
        )
