"""
sentinel_sdk.config
~~~~~~~~~~~~~~~~~~~~

Thread-safe configuration singleton for the Sentinel Python SDK.

Usage
-----
    from sentinel_sdk.config import SentinelConfig

    # Call once at application start-up (e.g. in main.py / settings.py):
    SentinelConfig.configure(
        api_key="your-plaintext-api-key",
        github_repo="acme/my-service",
    )

    # Any other module retrieves the live config:
    cfg = SentinelConfig.get()

The ``configure()`` class method is idempotent — calling it again overwrites
the singleton in place, which is useful during testing.

``get()`` raises ``RuntimeError`` if ``configure()`` was never called so that
misconfiguration surfaces loudly at first use rather than silently at the
moment an exception is dispatched.
"""

from __future__ import annotations

import logging
import os
import threading
from dataclasses import dataclass, field
from typing import Optional

_log = logging.getLogger("sentinel_sdk")

_DEFAULT_GATEWAY_URL = "https://nexuspartner.dev"

_lock = threading.Lock()
_instance: Optional["SentinelConfig"] = None


@dataclass
class SentinelConfig:
    """
    Immutable-by-convention value object holding all SDK settings.

    Do not instantiate directly — use ``SentinelConfig.configure()``.
    """

    api_key: str
    """Plaintext Bearer token issued by the Sentinel portal.  Never logged."""

    github_repo: str
    """Target GitHub repository in ``owner/repo`` format.  Must be on the
    tenant's allowed_github_repos allowlist or the gateway returns 403."""

    gateway_url: str = field(default=_DEFAULT_GATEWAY_URL)
    """Base URL of the sentinel-gateway service (no trailing slash)."""

    timeout_seconds: float = field(default=5.0)
    """Per-attempt HTTP timeout in seconds."""

    max_retries: int = field(default=3)
    """Maximum number of send attempts before giving up (1 = no retry)."""

    retry_backoff_base: float = field(default=0.5)
    """Base delay in seconds for exponential backoff: ``base * 2^attempt``."""

    endpoint_label: str = field(default="<unknown>")
    """Fallback value for the ``endpoint`` payload field when no per-call
    override is provided (e.g. when capturing via ``sys.excepthook`` rather
    than the FastAPI middleware which can read ``request.url.path``)."""

    enabled: bool = field(default=True)
    """Set to ``False`` (or env ``SENTINEL_ENABLED=false``) to suppress all
    network I/O — useful in test environments."""

    # ------------------------------------------------------------------
    # Factory / accessor
    # ------------------------------------------------------------------

    @classmethod
    def configure(
        cls,
        api_key: str,
        github_repo: str,
        gateway_url: str = _DEFAULT_GATEWAY_URL,
        timeout_seconds: float = 5.0,
        max_retries: int = 3,
        retry_backoff_base: float = 0.5,
        endpoint_label: str = "<unknown>",
        enabled: Optional[bool] = None,
    ) -> "SentinelConfig":
        """
        Create (or overwrite) the global Sentinel configuration.

        Must be called once before ``install_hook()`` or the FastAPI
        middleware is added.  Calling it a second time replaces the
        previous configuration — useful when overriding settings in tests.

        Parameters
        ----------
        api_key:
            Plaintext Bearer token from the Sentinel portal.
        github_repo:
            GitHub repository in ``owner/repo`` format.
        gateway_url:
            Base URL of the gateway (override for staging / local dev).
        timeout_seconds:
            Per-attempt HTTP connection+read timeout.
        max_retries:
            Maximum send attempts (minimum 1).
        retry_backoff_base:
            Exponential backoff base (seconds).
        endpoint_label:
            Default ``endpoint`` field value for hook-captured exceptions.
        enabled:
            Explicit enable flag.  When omitted, read from the
            ``SENTINEL_ENABLED`` environment variable (default: ``True``).
        """
        global _instance

        if not api_key or not api_key.strip():
            raise ValueError("sentinel_sdk: api_key must not be empty.")
        if not github_repo or "/" not in github_repo:
            raise ValueError(
                "sentinel_sdk: github_repo must be in 'owner/repo' format."
            )

        if enabled is None:
            env_val = os.getenv("SENTINEL_ENABLED", "true").strip().lower()
            enabled = env_val not in ("false", "0", "no", "off")

        with _lock:
            _instance = cls(
                api_key=api_key,
                github_repo=github_repo,
                gateway_url=gateway_url.rstrip("/"),
                timeout_seconds=timeout_seconds,
                max_retries=max(1, max_retries),
                retry_backoff_base=retry_backoff_base,
                endpoint_label=endpoint_label,
                enabled=enabled,
            )

        # Emit the startup confirmation described in the TDD.
        # api_key is intentionally masked — never log plaintext credentials.
        _log.info(
            "Sentinel SDK initialised. Monitoring repo=%s gateway=%s enabled=%s",
            github_repo,
            gateway_url.rstrip("/"),
            enabled,
        )

        return _instance

    @classmethod
    def get(cls) -> "SentinelConfig":
        """
        Return the active configuration singleton.

        Raises
        ------
        RuntimeError
            If ``configure()`` has not been called yet.
        """
        with _lock:
            if _instance is None:
                raise RuntimeError(
                    "sentinel_sdk: SentinelConfig.configure() must be called before "
                    "the SDK can dispatch exceptions.  Call it once at application "
                    "start-up (e.g. in main.py) before adding the middleware or "
                    "calling install_hook()."
                )
            return _instance

    @classmethod
    def _reset(cls) -> None:
        """
        Clear the singleton.  For use in unit tests only — not part of the
        public API.
        """
        global _instance
        with _lock:
            _instance = None
