"""
sentinel_sdk
~~~~~~~~~~~~

Sentinel Python SDK — automatic exception capture and reporting.

Quick start (global hook)
-------------------------
    import sentinel_sdk

    sentinel_sdk.configure(
        api_key="your-plaintext-api-key",
        github_repo="acme/my-service",
    )
    sentinel_sdk.install_hook()

Quick start (FastAPI)
---------------------
    from fastapi import FastAPI
    from sentinel_sdk import configure, SentinelMiddleware

    configure(api_key="...", github_repo="acme/my-service")

    app = FastAPI()
    app.add_middleware(SentinelMiddleware)

Public API
----------
configure()         — Initialise the SDK (call once at application start-up).
install_hook()      — Override sys.excepthook + threading.excepthook.
uninstall_hook()    — Restore original hooks (useful in tests).
SentinelMiddleware  — Starlette/FastAPI ASGI middleware class.
"""

from sentinel_sdk.config import SentinelConfig as _SentinelConfig
from sentinel_sdk.hook import install_hook, uninstall_hook
from sentinel_sdk.middleware import SentinelMiddleware

__version__ = "1.0.0"
__all__ = ["configure", "install_hook", "uninstall_hook", "SentinelMiddleware"]


def configure(
    api_key: str,
    github_repo: str,
    gateway_url: str = "https://nexuspartner.dev",
    timeout_seconds: float = 5.0,
    max_retries: int = 3,
    retry_backoff_base: float = 0.5,
    endpoint_label: str = "<unknown>",
    enabled: bool | None = None,
) -> None:
    """
    Initialise the Sentinel SDK.

    Must be called once before ``install_hook()`` or adding
    ``SentinelMiddleware`` to a FastAPI application.

    Parameters
    ----------
    api_key:
        Plaintext Bearer token from the Sentinel self-service portal.
    github_repo:
        GitHub repository in ``owner/repo`` format.  Must be registered
        on the tenant's allowlist.
    gateway_url:
        Override for non-production environments (staging, local dev).
        Defaults to the production gateway.
    timeout_seconds:
        Per-attempt HTTP timeout.  Default: 5 s.
    max_retries:
        Maximum number of send attempts before giving up.  Default: 3.
    retry_backoff_base:
        Exponential backoff base in seconds.  Default: 0.5 s.
    endpoint_label:
        Default ``endpoint`` field for hook-captured exceptions (the
        FastAPI middleware overrides this with the actual request path).
    enabled:
        Explicit on/off switch.  Defaults to the ``SENTINEL_ENABLED``
        environment variable (``true`` when unset).
    """
    _SentinelConfig.configure(
        api_key=api_key,
        github_repo=github_repo,
        gateway_url=gateway_url,
        timeout_seconds=timeout_seconds,
        max_retries=max_retries,
        retry_backoff_base=retry_backoff_base,
        endpoint_label=endpoint_label,
        enabled=enabled,
    )
