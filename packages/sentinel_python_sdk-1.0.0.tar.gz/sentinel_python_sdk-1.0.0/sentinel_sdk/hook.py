"""
sentinel_sdk.hook
~~~~~~~~~~~~~~~~~

Installs Sentinel exception capture on both ``sys.excepthook`` (main thread
unhandled exceptions) and ``threading.excepthook`` (background thread
unhandled exceptions).

API
---
    install_hook(endpoint: str = "<unknown>") -> None
    uninstall_hook() -> None

Both functions are idempotent and thread-safe.

Design notes
------------
* The original hooks are stored before installation and fully restored by
  ``uninstall_hook()``.  This makes the SDK safe to use alongside other
  libraries that also wrap ``sys.excepthook`` (e.g. Sentry, Datadog).

* The Sentinel wrapper always calls the original hook after dispatching so
  Python's default traceback printing is preserved.

* ``threading.excepthook`` was added in Python 3.8.  Since we require
  Python ≥ 3.10 it is always available.

* Dispatch is intentionally fire-and-forget via ``SyncDispatcher`` — the
  hook must not block the process while the exception is being handled.
"""

from __future__ import annotations

import logging
import sys
import threading
import types
from typing import Callable, Optional

_log = logging.getLogger("sentinel_sdk.hook")

# ---------------------------------------------------------------------------
# Module-level state (protected by _lock)
# ---------------------------------------------------------------------------

_lock = threading.Lock()

_original_excepthook: Optional[Callable] = None
_original_threading_excepthook: Optional[Callable] = None
_installed: bool = False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def install_hook(endpoint: str = "<unknown>") -> None:
    """
    Override ``sys.excepthook`` and ``threading.excepthook`` to capture
    unhandled exceptions and send them to Sentinel.

    Parameters
    ----------
    endpoint:
        Value for the ``endpoint`` field in the dispatched payload.  Use a
        descriptive label for the process (e.g. ``"worker"`` or
        ``"data-pipeline"``).  The FastAPI middleware provides a more precise
        per-request route label automatically.

    Idempotent — calling this function more than once is a no-op.
    """
    global _original_excepthook, _original_threading_excepthook, _installed

    with _lock:
        if _installed:
            _log.debug("Sentinel hook already installed — skipping.")
            return

        # Validate configuration eagerly so the error surfaces at setup time.
        from sentinel_sdk.config import SentinelConfig
        SentinelConfig.get()  # raises RuntimeError if configure() was not called

        _original_excepthook = sys.excepthook
        _original_threading_excepthook = threading.excepthook

        def _sentinel_excepthook(
            exc_type: type,
            exc_value: BaseException,
            tb: Optional[types.TracebackType],
        ) -> None:
            try:
                _dispatch_exception(exc_type, exc_value, tb, endpoint)
            except Exception:
                _log.warning(
                    "Sentinel excepthook: error during dispatch (swallowed).",
                    exc_info=True,
                )
            # Always call the original hook so Python's traceback printing
            # (or any other registered hook) still runs.
            _original_excepthook(exc_type, exc_value, tb)

        def _sentinel_threading_excepthook(args: threading.ExceptHookArgs) -> None:
            try:
                _dispatch_exception(
                    args.exc_type,
                    args.exc_value,
                    args.exc_traceback,
                    endpoint,
                )
            except Exception:
                _log.warning(
                    "Sentinel threading excepthook: error during dispatch (swallowed).",
                    exc_info=True,
                )
            _original_threading_excepthook(args)

        sys.excepthook = _sentinel_excepthook
        threading.excepthook = _sentinel_threading_excepthook
        _installed = True

    _log.debug("Sentinel sys.excepthook and threading.excepthook installed.")


def uninstall_hook() -> None:
    """
    Restore the original ``sys.excepthook`` and ``threading.excepthook``.

    Idempotent — safe to call even if the hook was never installed.
    Primarily used in test teardown.
    """
    global _original_excepthook, _original_threading_excepthook, _installed

    with _lock:
        if not _installed:
            return

        if _original_excepthook is not None:
            sys.excepthook = _original_excepthook
            _original_excepthook = None

        if _original_threading_excepthook is not None:
            threading.excepthook = _original_threading_excepthook
            _original_threading_excepthook = None

        _installed = False

    _log.debug("Sentinel hooks uninstalled; original hooks restored.")


def is_installed() -> bool:
    """Return ``True`` if the Sentinel hooks are currently active."""
    with _lock:
        return _installed


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _dispatch_exception(
    exc_type: type,
    exc_value: Optional[BaseException],
    tb: Optional[types.TracebackType],
    endpoint: str,
) -> None:
    """
    Build the payload and fire it via ``SyncDispatcher``.

    Never raises — any error during payload construction or dispatch is
    logged at WARNING level and swallowed so the hook does not interfere
    with the application's normal exception handling path.
    """
    try:
        from sentinel_sdk._payload import build_payload
        from sentinel_sdk.config import SentinelConfig
        from sentinel_sdk.dispatcher import SyncDispatcher

        cfg = SentinelConfig.get()
        payload = build_payload(exc_type, exc_value, tb, endpoint, cfg.github_repo)
        SyncDispatcher.dispatch(payload)
    except Exception:
        _log.warning(
            "Sentinel hook encountered an error during dispatch; exception not reported.",
            exc_info=True,
        )
