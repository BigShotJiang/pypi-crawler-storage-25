"""
Matrix-Free IPS Solver for PHP-E
=================================

Solves PHP-E (Pigeonhole Entangled) IPS systems without storing the matrix.

Principle: generate each column during matvec, use it, discard it immediately.
Result: O(rows + cols) RAM instead of O(nnz_matrix).

IMPORTANT — Orbit reduction is INVALID for PHP-E:
  PHP standard (without order) is symmetric under S_{n+1} × S_n.
  PHP-E (with y-variables) breaks this because y_{p,q} = "pigeon p precedes q"
  depends on direction. Permuting pigeons gives y_{p,q} → 1 - y_{σ(p),σ(q)} (flip),
  which is an affine (not permutation) action. This makes orbit reduction produce
  false positives. Only the full (unreduced) system gives correct results.

Adapted from qubit-algebra/qal/php_solver.py for the Selector Complexity Framework.

Author: Carmen Esteban
License: MIT
"""

from __future__ import annotations

import math
import os
import sys
import time
from itertools import combinations
from typing import Optional

import numpy as np
from scipy.sparse.linalg import lsqr, LinearOperator
from scipy.sparse import csr_matrix


# ═══════════════════════════════════════════════════════════════════════════════
# UTILITIES
# ═══════════════════════════════════════════════════════════════════════════════

def _union_sorted(a: tuple, b: tuple) -> tuple:
    """Boolean product: sorted union without duplicates (x²=x in multilinear algebra)."""
    result = []
    i, j = 0, 0
    while i < len(a) and j < len(b):
        if a[i] < b[j]:
            result.append(a[i])
            i += 1
        elif a[i] > b[j]:
            result.append(b[j])
            j += 1
        else:
            result.append(a[i])
            i += 1
            j += 1
    result.extend(a[i:])
    result.extend(b[j:])
    return tuple(result)


class PascalIndex:
    """Combinatorial indexing of multilinear monomials."""

    def __init__(self, num_vars: int, max_degree: int):
        self.num_vars = num_vars
        self.max_degree = max_degree
        n = num_vars + 1
        d = max_degree + 1
        self._C = [[0] * (d + 1) for _ in range(n + 1)]
        for i in range(n + 1):
            self._C[i][0] = 1
            for j in range(1, min(i + 1, d + 1)):
                self._C[i][j] = self._C[i - 1][j - 1] + self._C[i - 1][j]
        self._offsets = [0]
        for k in range(max_degree + 1):
            self._offsets.append(self._offsets[-1] + self._C[num_vars][k])
        self._total = self._offsets[max_degree + 1]

    def total_monomials(self) -> int:
        return self._total

    def combo_to_index(self, combo: tuple) -> int:
        k = len(combo)
        if k == 0:
            return 0
        if k > self.max_degree:
            return -1
        rank = 0
        for i, v in enumerate(combo):
            lo = combo[i - 1] + 1 if i > 0 else 0
            remaining = k - i
            for j in range(lo, v):
                rank += self._C[self.num_vars - j - 1][remaining - 1]
        return self._offsets[k] + rank


# ═══════════════════════════════════════════════════════════════════════════════
# PHP-E SYSTEM — Axioms
# ═══════════════════════════════════════════════════════════════════════════════

class PHPESystem:
    """
    PHP-E(n): n+1 pigeons → n holes + order variables.

    Variables:
      x_{p,h} ∈ {0,1} : pigeon p in hole h
      y_{p,q} ∈ {0,1} : pigeon p precedes pigeon q (for p < q)

    Axioms encode: existence, hole exclusion, pigeon exclusion,
    order consistency, and transitivity.
    """

    def __init__(self, n: int):
        self.n = n
        self.pigeons = list(range(1, n + 2))
        self.holes = list(range(1, n + 1))

        self.var_x: dict[tuple[int, int], int] = {}
        idx = 0
        for p in self.pigeons:
            for h in self.holes:
                self.var_x[(p, h)] = idx
                idx += 1

        self.var_y: dict[tuple[int, int], int] = {}
        for i, p in enumerate(self.pigeons):
            for p2 in self.pigeons[i + 1:]:
                self.var_y[(p, p2)] = idx
                idx += 1

        self.num_vars = idx
        self._build_axioms()

    def _build_axioms(self):
        axioms = []
        var_x, var_y = self.var_x, self.var_y
        pigeons, holes = self.pigeons, self.holes

        # Existence: Prod_h(1 - x_{p,h}) = 0
        for p in pigeons:
            hvars = [var_x[(p, h)] for h in holes]
            terms = []
            for k in range(len(hvars) + 1):
                for subset in combinations(hvars, k):
                    terms.append(((-1.0) ** k, tuple(sorted(subset))))
            axioms.append(terms)

        # Hole exclusion: x_{p,h} * x_{p',h} = 0
        for h in holes:
            for i, p in enumerate(pigeons):
                for p2 in pigeons[i + 1:]:
                    axioms.append([(1.0, tuple(sorted([var_x[(p, h)], var_x[(p2, h)]])))])

        # Pigeon exclusion: x_{p,h} * x_{p,h'} = 0
        for p in pigeons:
            for j, h in enumerate(holes):
                for h2 in holes[j + 1:]:
                    axioms.append([(1.0, tuple(sorted([var_x[(p, h)], var_x[(p, h2)]])))])

        # Order consistency
        for i_p, p in enumerate(pigeons):
            for p2 in pigeons[i_p + 1:]:
                y_idx = var_y[(p, p2)]
                for h in holes:
                    for h2 in holes:
                        if h == h2:
                            continue
                        x1, x2 = var_x[(p, h)], var_x[(p2, h2)]
                        if h < h2:
                            m1 = tuple(sorted([x1, x2]))
                            m2 = tuple(sorted([x1, x2, y_idx]))
                            axioms.append([(1.0, m1), (-1.0, m2)])
                        else:
                            axioms.append([(1.0, tuple(sorted([x1, x2, y_idx])))])

        # Transitivity
        for i_p, p in enumerate(pigeons):
            for j_p, p2 in enumerate(pigeons[i_p + 1:], i_p + 1):
                for p3 in pigeons[j_p + 1:]:
                    y12, y23, y13 = var_y[(p, p2)], var_y[(p2, p3)], var_y[(p, p3)]
                    m_a = tuple(sorted([y12, y23]))
                    m_b = tuple(sorted([y12, y23, y13]))
                    axioms.append([(1.0, m_a), (-1.0, m_b)])
                    m_c = (y13,)
                    m_d = tuple(sorted([y12, y13]))
                    m_e = tuple(sorted([y23, y13]))
                    axioms.append([(1.0, m_c), (-1.0, m_d), (-1.0, m_e), (1.0, m_b)])

        self.axioms = axioms


# ═══════════════════════════════════════════════════════════════════════════════
# FULL SOLVER — Builds complete matrix (for verification / small instances)
# ═══════════════════════════════════════════════════════════════════════════════

def build_full_system(system: PHPESystem, d_max: int, verbose: bool = True):
    """Build the complete IPS matrix."""
    nv = system.num_vars
    pidx = PascalIndex(nv, d_max)
    num_rows = pidx.total_monomials()

    rows, cols, vals = [], [], []
    col_idx = 0
    for axiom in system.axioms:
        deg_ax = max(len(m) for _, m in axiom)
        deg_mult = max(0, d_max - deg_ax)
        for d in range(deg_mult + 1):
            for combo in combinations(range(nv), d):
                for coef, mono in axiom:
                    product = _union_sorted(mono, combo)
                    if len(product) <= d_max:
                        row = pidx.combo_to_index(product)
                        if row >= 0:
                            rows.append(row)
                            cols.append(col_idx)
                            vals.append(coef)
                col_idx += 1

    A = csr_matrix((vals, (rows, cols)), shape=(num_rows, col_idx), dtype=np.float64)
    b = np.zeros(num_rows)
    b[0] = 1.0

    if verbose:
        ram_kb = (A.data.nbytes + A.indices.nbytes + A.indptr.nbytes) / 1024
        print(f"  Full: {num_rows:,} x {col_idx:,}, nnz={A.nnz:,}, "
              f"RAM={ram_kb:.1f} KB")
    return A, b, col_idx


def solve_full(system: PHPESystem, d_max: int, max_iter: int = 5000,
               tol: float = 1e-10, verbose: bool = True) -> dict:
    """Solve by building the complete matrix."""
    t0 = time.perf_counter()
    A, b, _ = build_full_system(system, d_max, verbose=verbose)
    t_build = time.perf_counter() - t0

    t1 = time.perf_counter()
    if A.shape[0] <= 5000 and A.shape[1] <= 50000:
        x, _, _, _ = np.linalg.lstsq(A.toarray(), b, rcond=None)
        solver = "lstsq"
    else:
        result = lsqr(A, b, atol=tol, btol=tol, iter_lim=max_iter)
        x = result[0]
        solver = "LSQR"
    t_solve = time.perf_counter() - t1

    residual = float(np.linalg.norm(A @ x - b))
    feasible = residual < 1e-6
    size_l2 = int(np.sum(np.abs(x) > 1e-8))

    if verbose:
        status = "FEASIBLE" if feasible else "INFEASIBLE"
        print(f"  {status} ({solver}): res={residual:.2e}, SIZE_L2={size_l2:,} "
              f"[{t_build + t_solve:.2f}s]")

    return {
        "feasible": feasible, "residual": residual,
        "size_l2": size_l2, "time": t_build + t_solve,
        "method": f"full ({solver})", "shape": A.shape,
    }


# ═══════════════════════════════════════════════════════════════════════════════
# MATRIX-FREE SOLVER
# ═══════════════════════════════════════════════════════════════════════════════

class MatrixFreeSolver:
    """
    Solver that never stores the matrix.

    Generates each column during matvec, uses it, discards it.
    Memory: O(rows + cols) instead of O(nnz).

    Optionally uses Numba for parallel kernels (falls back to pure Python/scipy).
    """

    PARALLEL_MIN_COLS = 500_000
    JACOBI_MIN_NORM_RATIO = 5.0

    def __init__(self, system: PHPESystem, d_max: int, verbose: bool = True,
                 parallel: str = "auto"):
        self.sys = system
        self.d_max = d_max
        self.pidx = PascalIndex(system.num_vars, d_max)
        self.num_rows = self.pidx.total_monomials()

        self._precompute()

        n_cpu = os.cpu_count() or 1
        self._n_threads = min(n_cpu, 8)
        max_buf = 500 * 1024 * 1024
        while self._n_threads > 1 and self._n_threads * self.num_rows * 8 > max_buf:
            self._n_threads -= 1

        # Try Numba acceleration (optional dependency)
        self._use_numba = False
        self._par_matvec = False
        self._par_rmatvec = False
        try:
            from numba import njit, prange  # noqa: F401
            # Numba kernels would be loaded here if available as a compiled module.
            # For now, the pure Python fallback is used.
        except ImportError:
            pass

        self._compute_col_norms()

        if verbose:
            vec_mb = (self.num_rows + self.num_cols) * 8 / 1024 / 1024
            engine = "Python (scipy)"
            print(f"  Matrix-free: {self.num_rows:,} x {self.num_cols:,} ({engine})")
            print(f"  RAM vectors: ~{vec_mb:.1f} MB")
            if len(self.col_norms) > 0:
                nmin, nmax = self.col_norms.min(), self.col_norms.max()
                ratio = nmax / nmin if nmin > 0 else 999
                print(f"  Column norms: [{nmin:.2f}, {nmax:.2f}] ratio={ratio:.1f}x")

    def _precompute(self):
        """Precompute column structure in numpy arrays (memory-efficient)."""
        nv = self.sys.num_vars
        axioms = self.sys.axioms

        total_cols = 0
        total_mult_elems = 0
        for axiom in axioms:
            deg_ax = max(len(m) for _, m in axiom)
            deg_mult = max(0, self.d_max - deg_ax)
            for d in range(deg_mult + 1):
                nc = math.comb(nv, d)
                total_cols += nc
                total_mult_elems += nc * d

        self.num_cols = total_cols

        col_ax_idx = np.empty(total_cols, dtype=np.int32)
        mult_flat = np.empty(total_mult_elems, dtype=np.int32)
        mult_starts = np.empty(total_cols, dtype=np.int32)
        mult_lengths = np.empty(total_cols, dtype=np.int32)

        col_j = 0
        flat_pos = 0
        for ax_idx, axiom in enumerate(axioms):
            deg_ax = max(len(m) for _, m in axiom)
            deg_mult = max(0, self.d_max - deg_ax)
            for d in range(deg_mult + 1):
                combos = list(combinations(range(nv), d))
                nc = len(combos)
                if nc == 0:
                    continue
                col_ax_idx[col_j:col_j + nc] = ax_idx
                mult_lengths[col_j:col_j + nc] = d
                if d > 0:
                    mult_starts[col_j:col_j + nc] = (
                        np.arange(nc, dtype=np.int64) * d + flat_pos
                    ).astype(np.int32)
                    arr = np.array(combos, dtype=np.int32)
                    mult_flat[flat_pos:flat_pos + nc * d] = arr.ravel()
                else:
                    mult_starts[col_j:col_j + nc] = flat_pos
                col_j += nc
                flat_pos += nc * d

        self._col_pack = {
            'col_ax_idx': col_ax_idx,
            'mult_flat': mult_flat,
            'mult_starts': mult_starts,
            'mult_lengths': mult_lengths,
        }

    def _compute_col_norms(self):
        """Compute ||A[:,j]||_2 for Jacobi preconditioning."""
        self.col_norms = np.ones(self.num_cols)
        if self.num_cols == 0:
            return

        pidx = self.pidx
        axioms = self.sys.axioms
        cp = self._col_pack
        for col_j in range(self.num_cols):
            ax_idx = int(cp['col_ax_idx'][col_j])
            ms = int(cp['mult_starts'][col_j])
            ml = int(cp['mult_lengths'][col_j])
            mult = tuple(cp['mult_flat'][ms:ms + ml])
            norm_sq = 0.0
            for coef, mono in axioms[ax_idx]:
                product = _union_sorted(mono, mult)
                if len(product) <= self.d_max:
                    row = pidx.combo_to_index(product)
                    if row >= 0:
                        norm_sq += coef * coef
            self.col_norms[col_j] = math.sqrt(norm_sq) if norm_sq > 0 else 1.0

    def matvec(self, x):
        """A @ x without storing A."""
        result = np.zeros(self.num_rows)
        pidx = self.pidx
        axioms = self.sys.axioms
        cp = self._col_pack
        for col_j in range(self.num_cols):
            xj = x[col_j]
            if abs(xj) < 1e-15:
                continue
            ax_idx = int(cp['col_ax_idx'][col_j])
            ms = int(cp['mult_starts'][col_j])
            ml = int(cp['mult_lengths'][col_j])
            mult = tuple(cp['mult_flat'][ms:ms + ml])
            for coef, mono in axioms[ax_idx]:
                product = _union_sorted(mono, mult)
                if len(product) <= self.d_max:
                    row = pidx.combo_to_index(product)
                    if row >= 0:
                        result[row] += coef * xj
        return result

    def rmatvec(self, y):
        """A^T @ y without storing A."""
        result = np.zeros(self.num_cols)
        pidx = self.pidx
        axioms = self.sys.axioms
        cp = self._col_pack
        for col_j in range(self.num_cols):
            ax_idx = int(cp['col_ax_idx'][col_j])
            ms = int(cp['mult_starts'][col_j])
            ml = int(cp['mult_lengths'][col_j])
            mult = tuple(cp['mult_flat'][ms:ms + ml])
            val = 0.0
            for coef, mono in axioms[ax_idx]:
                product = _union_sorted(mono, mult)
                if len(product) <= self.d_max:
                    row = pidx.combo_to_index(product)
                    if row >= 0:
                        val += coef * y[row]
            result[col_j] = val
        return result

    def solve(self, max_iter: int = 5000, tol: float = 1e-10,
              verbose: bool = True, precondition: str = "auto") -> dict:
        """Solve with LSQR matrix-free, optional Jacobi preconditioning."""
        b = np.zeros(self.num_rows)
        b[0] = 1.0

        use_jacobi = False
        if self.num_cols > 0:
            nmin, nmax = self.col_norms.min(), self.col_norms.max()
            ratio = nmax / nmin if nmin > 0 else 999
            if precondition == "auto":
                use_jacobi = ratio >= self.JACOBI_MIN_NORM_RATIO
            elif precondition is True:
                use_jacobi = True

        if use_jacobi:
            d_inv = 1.0 / self.col_norms

            def prec_matvec(z):
                return self.matvec(z * d_inv)

            def prec_rmatvec(y):
                return self.rmatvec(y) * d_inv

            op = LinearOperator(
                (self.num_rows, self.num_cols),
                matvec=prec_matvec, rmatvec=prec_rmatvec,
                dtype=np.float64,
            )
        else:
            d_inv = None
            op = LinearOperator(
                (self.num_rows, self.num_cols),
                matvec=self.matvec, rmatvec=self.rmatvec,
                dtype=np.float64,
            )

        if verbose:
            label = "LSQR matrix-free"
            if use_jacobi:
                label += f" + Jacobi (ratio={ratio:.1f}x)"
            print(f"  {label}: max_iter={max_iter}...")
            sys.stdout.flush()

        t0 = time.perf_counter()
        result = lsqr(op, b, atol=tol, btol=tol, iter_lim=max_iter)
        elapsed = time.perf_counter() - t0

        z = result[0]
        iters = result[2]

        x = z * d_inv if d_inv is not None else z

        Ax = self.matvec(x)
        residual = float(np.linalg.norm(Ax - b))
        feasible = residual < 1e-6
        size_l2 = int(np.sum(np.abs(x) > 1e-8))

        if verbose:
            status = "FEASIBLE" if feasible else "INFEASIBLE"
            print(f"  {status}: res={residual:.2e}, iters={iters}, "
                  f"SIZE_L2={size_l2:,} [{elapsed:.1f}s]")

        return {
            "feasible": feasible, "residual": residual,
            "size_l2": size_l2, "iterations": iters, "time": elapsed,
            "method": "matrix_free", "x": x,
        }


# ═══════════════════════════════════════════════════════════════════════════════
# CONVENIENCE: solve PHP-E with auto method selection
# ═══════════════════════════════════════════════════════════════════════════════

def solve_phpe(n: int, d_max: int, method: str = "auto",
               max_iter: int = 5000, tol: float = 1e-10,
               verbose: bool = True) -> dict:
    """
    Solve PHP-E(n) up to degree d_max.

    method: "full" (explicit matrix), "matrix_free", "auto" (picks by size)
    """
    if verbose:
        print(f"\n{'=' * 65}")
        print(f"  PHP-E(n={n}) d={d_max}")
        print(f"{'=' * 65}")

    sys_phpe = PHPESystem(n)
    pidx = PascalIndex(sys_phpe.num_vars, d_max)

    if verbose:
        print(f"  Variables: {sys_phpe.num_vars}")
        print(f"  Axioms: {len(sys_phpe.axioms)}")
        print(f"  Monomials: {pidx.total_monomials():,}")

    if method == "auto":
        method = "full" if pidx.total_monomials() < 50000 else "matrix_free"

    if method == "full":
        if verbose:
            print(f"\n  -- Full Solver --")
        return solve_full(sys_phpe, d_max, max_iter=max_iter,
                          tol=tol, verbose=verbose)
    else:
        if verbose:
            print(f"\n  -- Matrix-Free Solver --")
        mf = MatrixFreeSolver(sys_phpe, d_max, verbose=verbose)
        return mf.solve(max_iter=max_iter, tol=tol, verbose=verbose)


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    d = int(sys.argv[2]) if len(sys.argv) > 2 else 2 * n
    solve_phpe(n, d)
