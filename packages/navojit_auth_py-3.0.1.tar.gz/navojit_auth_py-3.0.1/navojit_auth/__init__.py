import jwt
import datetime
import uuid

class NavojitAuth:
    """
    Navojit Auth v3.0 - The Global Python Engine
    Designed for High-Performance & Cross-Language Compatibility.
    """
    def __init__(self, adapter, secret, prefix="/auth", token_expiry_days=7):
        self.adapter = adapter
        self.secret = secret
        self.prefix = prefix
        self.token_expiry_days = token_expiry_days

    def prepare_payload(self, user, sid=None):
        """Standardized Navojit Payload (Matches JS/Rust/Flutter)"""
        return {
            "sub": str(user.get('id') or user.get('_id')),
            "email": user.get('email'),
            "role": user.get('role', 'member'),
            "orgId": user.get('orgId') or None,
            "sid": sid or str(uuid.uuid4()),
            "iat": datetime.datetime.utcnow(),
            "exp": datetime.datetime.utcnow() + datetime.timedelta(days=self.token_expiry_days)
        }

    def generate_token(self, user):
        """Generates a signed JWT token"""
        payload = self.prepare_payload(user)
        return jwt.encode(payload, self.secret, algorithm="HS256")

    async def verify_otp(self, email, otp):
        """Core Engine: OTP Verification & Auto-Registration"""
        if not otp or len(otp) < 4:
            raise Exception("Invalid OTP. Minimum 4 digits required.")
        
        user = await self.adapter.find_user_by_email(email)
        
        if not user:
            # Self-Healing Architecture: Auto-Onboarding
            user_data = {
                "email": email,
                "role": "member",
                "password": f"NAV_PY_{uuid.uuid4().hex[:8]}"
            }
            user = await self.adapter.create_user(user_data)
        
        # Ab ye naya method use kar raha hai
        token = self.generate_token(user)
        
        return {
            "success": True, 
            "token": token, 
            "engine": "navojit-v3-python-universal"
        }

# Adapter Interface for Developers
class AuthAdapter:
    async def find_user_by_email(self, email): raise NotImplementedError()
    async def create_user(self, data): raise NotImplementedError()
    async def find_user_by_id(self, user_id): raise NotImplementedError()