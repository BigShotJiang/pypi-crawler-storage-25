# QA STLC Agents — Architecture

## Overview

QA STLC Agents is a monorepo of three Model Context Protocol (MCP) servers that
together cover the full Software Test Life Cycle on top of Azure DevOps. Each server
is an independent Python process. A coding agent (Claude Code, GitHub Copilot, Gemini
CLI) installs all three with a single `pip install`, reads the skill files once, and
can then drive the entire STLC pipeline — from work item to running self-healing
Playwright tests — in a single prompt.

```
pip install qa-stlc-agents   ───► qa-test-case-manager
                                   qa-gherkin-generator
                                   qa-playwright-generator
```

---

## Repository Layout

```
qa-stlc-agents/                     (distribution name — hyphens OK here)
├── pyproject.toml                    single package, 3 entry-point scripts
├── Makefile                          install / skills / test / verify / clean
├── CLAUDE.md                         repo rules for Claude Code
├── .gitignore
├── .env.example
│
├── docs/
│   ├── architecture.md               ← this file
│   └── walkthrough.md
│
├── scripts/
│   ├── install-skills.sh             copy skill .md files to .claude/skills/
│   └── generate-mcp-config.py        write .mcp.json with absolute binary paths
│
├── skills/                           one Markdown skill file per agent
│   ├── generate-test-cases.md
│   ├── generate-gherkin.md
│   └── generate-playwright-code.md
│
├── tests/
│   └── test_imports.py               20 unit tests, no live ADO or browser
│
└── src/qa_stlc_agents/
    ├── shared/
    │   └── auth.py                   MSAL silent token cache (shared by all agents)
    ├── agent1/
    │   ├── server.py                 MCP server: qa-test-case-manager
    │   └── tools/ado_workitem.py     ADO REST — fetch WI, create TCs, link TCs
    ├── agent2/
    │   ├── server.py                 MCP server: qa-gherkin-generator
    │   └── tools/ado_gherkin.py      ADO REST — fetch Feature hierarchy, attach .feature
    └── agent3/
        ├── server.py                 MCP server: qa-playwright-generator
        └── tools/ado_attach.py       ADO REST — attach files to work items
```

---

## The Three Agents

### Agent 1 — `qa-test-case-manager`

**Purpose:** Convert ADO work item acceptance criteria into structured test cases
linked back to the work item via `TestedBy-Forward` relation.

**Tools:**

| Tool | ADO API call | What it returns |
|---|---|---|
| `fetch_work_item` | `GET /wit/workitems/{id}?$expand=relations` | Title, AC, description, story points, priority, area/iteration path, parent feature, existing TC count, coverage hints |
| `create_and_link_test_cases` | `POST /wit/workitems/$Test Case` + `PATCH` for link | Created TC IDs, ADO URLs |
| `get_linked_test_cases` | `GET /wit/workitems/{id}/relations` | List of TC titles and IDs already linked |

**Coverage hints** — `_extract_coverage_hints()` reads the acceptance criteria text
and flags which of eleven categories need test cases:

```
toast_notifications  file_size_boundary  post_action_state  platform_specific
computed_values      data_persistence    accessibility       image_manipulation
file_formats         cancel_flows        validation_errors
```

**Test case format** — Each TC is created with XML steps in
`Microsoft.VSTS.TCM.Steps` format (the `_build_steps_xml` function). Area path and
iteration path are auto-inherited from the parent work item.

---

### Agent 2 — `qa-gherkin-generator`

**Purpose:** Convert an ADO Feature work item and its entire child hierarchy into a
Gherkin `.feature` file, then attach it to the Feature.

**Tools:**

| Tool | ADO API call | What it returns |
|---|---|---|
| `fetch_feature_hierarchy` | `GET /wit/workitems/{id}` + child relations | Feature fields, all child PBIs/Bugs with AC, linked test cases with full steps, embedded `_GHERKIN_EXAMPLE` best-practice reference |
| `attach_gherkin_to_feature` | `POST /wit/attachments` + `PATCH /wit/workitems/{id}` | Attachment URL, work item update result |

**File naming** — Attached files are auto-named:
`{feature_id}_{feature_title_kebab}_regression.feature`

**Skill rules** — The `generate-gherkin.md` skill enforces: 5–10 scenarios,
`@smoke` on the primary happy path, `@regression` on all others, `Scenario Outline`
for data-driven boundary tests, `Background` only when 2+ scenarios share identical
preconditions.

---

### Agent 3 — `qa-playwright-generator`

**Purpose:** Convert a Gherkin `.feature` file into production-ready, self-healing
Playwright TypeScript automation code, optionally using a live Chrome DevTools
inspection to generate validated locators.

**Tools:**

| Tool | What it does |
|---|---|
| `inspect_live_page` | Step 0 — CDP inspection of a live Chrome tab |
| `generate_playwright_code` | Gherkin → 4 TypeScript files |
| `scaffold_locator_repository` | Generate 6 shared infrastructure files |
| `attach_code_to_work_item` | Attach `.ts` files to an ADO work item |
| `validate_gherkin_steps` | Parse `.feature` file → all unique step strings |

**Generated TypeScript files (per feature):**

| File | Contents |
|---|---|
| `src/pages/{kebab}/locators.ts` | `{ selector, intent, cdpSignals?, visualIntent? }` per element |
| `src/pages/{kebab}/{kebab}.page.ts` | Page object with all healing layers |
| `src/test/steps/{kebab}.steps.ts` | Cucumber step definitions via PageFixture DI |
| `config/cucumber.js` | Cucumber.js profile entry |

**Generated shared infrastructure files (once per project):**

| File | Purpose |
|---|---|
| `LocatorHealer.ts` | 8-strategy locator resolution chain |
| `LocatorRepository.ts` | Persistent state store for all healing layers |
| `TimingHealer.ts` | Network trace drift detection and auto-healing |
| `VisualIntentChecker.ts` | Element screenshot comparison |
| `DevToolsHealer.ts` | CDP AX tree and bounding box healing |
| `HealingDashboard.ts` | HTTP review server for all AI suggestions |

---

## Authentication

All three agents share a single `shared/auth.py` module. The module is intentionally
identical to the `microsoft/azure-devops-mcp` token cache so that signing into any
Microsoft tool on the developer's machine also authenticates these agents.

```
~/.msal-cache/msal-cache.json   ←  shared with microsoft/azure-devops-mcp
```

**Token acquisition sequence:**

```
1. Load ~/.msal-cache/msal-cache.json
2. msal.acquire_token_silent()
   └─ token found and not expired → return Bearer token (zero UI)

3. msal.acquire_token_interactive()
   └─ open browser once → user logs in → token written to cache
   └─ token valid ~90 days, browser never opens again

CI/CD: set AZURE_CLIENT_ID + AZURE_CLIENT_SECRET + AZURE_TENANT_ID
       → service principal flow, browser never opens
```

**Constants** (must never change — must match `microsoft/azure-devops-mcp`):

| Constant | Value |
|---|---|
| `_ADO_SCOPE` | `499b84ac-1321-427f-aa17-267ca6975798/.default` |
| `_DEFAULT_CLIENT_ID` | `04b07795-8ddb-461a-bbee-02f9e1bf7b46` (Azure CLI) |
| `_CACHE_FILE` | `~/.msal-cache/msal-cache.json` |

---

## Self-Healing Architecture (Agent 3)

The healing system has four independent layers. Layers 1–3 operate at test runtime.
Layer 4 operates both at generation time (Step 0) and at runtime.

```
                        ┌─────────────────────────────────────────┐
                        │         GENERATION TIME (Step 0)         │
                        │                                           │
                        │   inspect_live_page                       │
                        │        │                                  │
                        │        ├─ Accessibility.getFullAXTree     │
                        │        ├─ DOM.getFlattenedDocument        │
                        │        ├─ Runtime.evaluate (validate)     │
                        │        └─ returns ContextMap              │
                        │             │                             │
                        │        generate_playwright_code           │
                        │             │                             │
                        │        locators.ts (CDP-verified)         │
                        └─────────────────────────────────────────┘
                                       │
                                       ▼
                        ┌─────────────────────────────────────────┐
                        │          TEST RUNTIME (3 layers)         │
                        │                                           │
                        │  Action: clickWithHealing(key, sel, intent)
                        │                                           │
                        │  LocatorHealer.resolve()                  │
                        │   1. LocatorRepository.getHealed()        │  ← instant
                        │   2. page.locator(selector)               │  ← 5 s
                        │   3. page.getByRole(role, name)           │  ← 3 s
                        │   4. page.getByLabel(intent)              │  ← 3 s
                        │   5. page.getByText(word)                 │  ← 3 s
                        │   6. DevToolsHealer.findByAxName()        │  ← CDP, no AI
                        │   7. DevToolsHealer.findByBoundingBox()   │  ← CDP, spatial
                        │   8. playwright-cli → Claude AI Vision    │  ← ~10 s
                        │         │                                 │
                        │  TimingHealer                             │
                        │   • network trace per action              │
                        │   • drift > 20% → auto-adjust + queue    │
                        │                                           │
                        │  VisualIntentChecker                      │
                        │   • element screenshot at assertions      │
                        │   • pixel diff vs approved baseline       │
                        │   • diff → queue to HealingDashboard      │
                        └─────────────────────────────────────────┘
                                       │
                                       ▼
                        ┌─────────────────────────────────────────┐
                        │     HealingDashboard :7890               │
                        │                                          │
                        │   GET  /              HTML review UI     │
                        │   GET  /api/pending   all suggestions    │
                        │   POST /api/approve   commit to repo     │
                        │   POST /api/reject    discard            │
                        │   GET  /api/visual    diff image         │
                        └─────────────────────────────────────────┘
```

### LocatorRepository — shared state bus

`LocatorRepository.ts` is the single state file that all four healing layers read and
write. It persists to `test-results/locator-repository.json` between test runs.

| Field | Written by | Read by |
|---|---|---|
| `healedSelector` | LocatorHealer (strategies 2–8) | LocatorHealer strategy 1 |
| `healingHistory` | LocatorHealer | HealingDashboard |
| `lastBoundingBox` | DevToolsHealer.captureBoundingBox | DevToolsHealer.findByBoundingBox |
| `pendingSuggestion` | TimingHealer, VisualIntentChecker, DevToolsHealer | HealingDashboard |
| `successCount / failureCount` | LocatorHealer | HealingDashboard analytics |

### DevToolsHealer — CDP integration

`DevToolsHealer.ts` reuses the Playwright `CDPSession` via
`page.context().newCDPSession(page)`. No separate Chrome process is required.

**At generation time** — `validateSelector()` calls
`Runtime.evaluate("document.querySelectorAll(...).length")`. Only selectors that
match exactly one element reach `locators.ts`. This is the zero-hallucinations
guarantee.

**At runtime, Strategy 7** — `findByAxName()` calls `Accessibility.getFullAXTree`,
scores nodes by intent word overlap (≥ 60% match), resolves the best stable selector
for the matching node using `_bestSelectorForNode` (data-testid > aria-label > id >
placeholder), then validates with `DOM.querySelectorAll`.

**At runtime, Strategy 8** — `findByBoundingBox()` calls
`DOM.getNodeForLocation(cx, cy)` at the last known element center. This handles the
case where a selector fails because the element was re-keyed in the DOM but its
layout position is unchanged. After every successful `clickWithHealing`,
`captureBoundingBox()` updates `lastBoundingBox` in `LocatorRepository`.

**Selector stability ranking** (used by `_bestSelectorForNode`):

| Strategy | Score | Rationale |
|---|---|---|
| `data-testid` | 100 | Explicit test contract, never changes incidentally |
| `aria-role + aria-label` | 90 | Semantic, survives CSS and DOM restructuring |
| Non-generated `id` | 80 | Stable when `id` is not auto-generated |
| `aria-label` alone | 70 | Semantic but can be internationalised |
| `placeholder` | 60 | Input-only, survives minor refactors |
| Role + text (XPath) | 50 | Fallback; validated at runtime by LocatorHealer |

### HealingDashboard — CI/CD approval gate

The dashboard is a zero-dependency Node `http.Server` (no Express) started in
`global-setup.ts` and stopped in `global-teardown.ts`. It reads
`locator-repository.json` on every request — no server restart needed when the file
changes.

All three healing layers write suggestions via `LocatorRepository.queueSuggestion()`.
No suggestion is promoted to `healedSelector` until an engineer clicks Approve. This
is the hard boundary between AI suggestion and committed change.

Setting `HEALING_DASHBOARD_PORT=0` disables the HTTP server entirely for fully
automated pipelines. Suggestions are still written to the JSON file.

---

## MCP Transport

All three agents run over **stdio MCP** — the standard MCP transport for CLI tools.
The coding agent spawns each server as a subprocess and communicates over stdin/stdout.

```json
{
  "mcpServers": {
    "qa-test-case-manager":    { "command": "/path/.venv/bin/qa-test-case-manager" },
    "qa-gherkin-generator":    { "command": "/path/.venv/bin/qa-gherkin-generator" },
    "qa-playwright-generator": { "command": "/path/.venv/bin/qa-playwright-generator" }
  }
}
```

Generate this file automatically with correct absolute paths:
```bash
python3 scripts/generate-mcp-config.py        # Claude Code → .mcp.json
python3 scripts/generate-mcp-config.py --vscode  # VS Code → .vscode/mcp.json
```

---

## Skill Files

Each agent ships a Markdown skill file. Skills are copied into the coding agent's
skill directory (`make skills`) and read at the start of each relevant task. The
skill file encodes all domain rules — complexity classification, granularity rules,
coverage categories, Gherkin style rules, page object constraints — so they do not
need to be repeated in every prompt.

| Skill | Key rules encoded |
|---|---|
| `generate-test-cases.md` | Complexity classification (Simple 3–6 / Medium 6–12 / Complex 12–18), 11 coverage categories, granularity merge rule |
| `generate-gherkin.md` | 5–10 scenarios, @smoke/@regression tags, Background only when 2+ scenarios share preconditions, Scenario Outline for boundary data |
| `generate-playwright-code.md` | Step 0–5 workflow, 4-layer healing rules, page object constraints, HealingDashboard approval workflow |

---

## Data Flow: ADO Work Item → Running Tests

```
ADO Work Item (PBI/Bug)
       │
       │  fetch_work_item (Agent 1)
       │  ├─ title, acceptance criteria, coverage hints
       │  └─ existing test case count (avoid duplicates)
       │
       ▼
Test Cases created in ADO
       │  create_and_link_test_cases (Agent 1)
       │  ├─ XML steps format (Microsoft.VSTS.TCM.Steps)
       │  └─ TestedBy-Forward link to parent PBI
       │
       ▼
Gherkin .feature file
       │  fetch_feature_hierarchy (Agent 2) → write .feature → attach_gherkin_to_feature
       │  ├─ Feature + all child PBIs + linked test steps as context
       │  └─ Best-practice example embedded in API response
       │
       ▼
Chrome DevTools inspection (optional Step 0)
       │  inspect_live_page (Agent 3)
       │  ├─ Accessibility.getFullAXTree → AX nodes
       │  ├─ DOM.querySelectorAll → validate every selector
       │  ├─ DOM.getBoxModel → bounding boxes
       │  └─ Performance.getMetrics → network baselines
       │
       ▼
Playwright TypeScript code (Agent 3)
       │  generate_playwright_code + scaffold_locator_repository
       │  ├─ locators.ts (CDP-verified or Gherkin-inferred)
       │  ├─ {Page}.page.ts (3-layer self-healing page object)
       │  ├─ steps.ts (Cucumber step defs via PageFixture DI)
       │  ├─ LocatorHealer.ts + LocatorRepository.ts
       │  ├─ TimingHealer.ts + VisualIntentChecker.ts
       │  ├─ DevToolsHealer.ts + HealingDashboard.ts
       │  └─ attached to ADO work item for traceability
       │
       ▼
Cucumber test run
       │  ENABLE_SELF_HEALING=true HEALING_DASHBOARD_PORT=7890
       │  cucumber-js --config=config/cucumber.js -p {profile}
       │
       ▼
HealingDashboard :7890
       └─ review pending locator, timing, and visual suggestions
          approve → committed to locator-repository.json
          reject  → discarded
```

---

## Design Decisions

**Why three separate MCP servers rather than one?**
Each agent has a distinct concern and a distinct skill file. A coding agent can use
just Agent 1 (test case generation) without knowing anything about Playwright. Keeping
them separate also means a failure or update in one server does not affect the others.
All three share the `shared/auth.py` module to avoid duplication.

**Why Python for the MCP servers?**
The MCP Python SDK maps cleanly to the stdio transport. Python's `requests` library
covers all ADO REST API needs. The code generation (TypeScript strings) is purely
string manipulation — no TypeScript compiler is needed on the server.

**Why not auto-commit healed selectors?**
AI suggestions are probabilistic. A healed selector that works for one test run may
not be semantically correct. The HealingDashboard makes every AI-generated change
visible, attributable, and reversible before it enters version control.

**Why persist bounding boxes?**
An element that has been successfully clicked has a known, validated position in the
DOM. If the CSS selector later breaks (element re-keyed, class renamed), the position
is often stable. `DevToolsHealer.findByBoundingBox` uses this to find the element by
where it was, not what it was called.

**Why validate selectors at generation time (Step 0)?**
AI-generated selectors frequently match zero or multiple elements in the real DOM.
Running `DOM.querySelectorAll` against the live browser during Step 0 eliminates
this class of error entirely — only selectors that uniquely identify one element reach
`locators.ts`.
