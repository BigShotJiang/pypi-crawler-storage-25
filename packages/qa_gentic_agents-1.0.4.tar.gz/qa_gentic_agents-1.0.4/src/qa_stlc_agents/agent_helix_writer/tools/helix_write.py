"""
helix_write.py — File-system write tool for the Helix QA framework.

Public API:
  inspect_helix_project(helix_root)              -> dict
  write_files_to_helix(helix_root, files, mode)  -> dict
  read_helix_file(helix_root, relative_path)     -> dict
  list_helix_tree(helix_root)                    -> dict

  Framework existence detection
  inspect_helix_project() returns framework_state: "absent"|"partial"|"present"
  and a recommendation of "scaffold_and_tests" or "tests_only".
  write_files_to_helix() accepts that recommendation as its `mode` argument.

Infrastructure file protection
  In mode="tests_only" all six utils/locators/*.ts files are always skipped.
  In mode="scaffold_and_tests" they are written only if absent on disk,
  unless force_scaffold=True is passed.

Within-file deduplication
  For locators.ts  : new const-object entries are merged; duplicate keys skipped.
  For *.steps.ts   : new step blocks are appended; duplicate regex patterns skipped.
  For *.page.ts    : new async methods are appended; duplicate method names skipped.

Interface adapter
  The generator emits repo.updateHealed / repo.incrementSuccess / repo.getBBox etc.
  The existing Helix LocatorRepository only has setHealed / getBestSelector / getHealed.
  _adapt_to_helix_interface() rewrites generated content before writing so it
  compiles cleanly against the Helix interface without manual edits.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

# ── Infrastructure file names ──────────────────────────────────────────────

_INFRA_FILES = {
    "LocatorHealer.ts",
    "LocatorRepository.ts",
    "TimingHealer.ts",
    "VisualIntentChecker.ts",
    "DevToolsHealer.ts",
    "HealingDashboard.ts",
}
_REQUIRED_INFRA = {"LocatorHealer.ts", "LocatorRepository.ts"}
_OPTIONAL_INFRA = _INFRA_FILES - _REQUIRED_INFRA

_INFRA_RE    = re.compile(r"(LocatorHealer|LocatorRepository|TimingHealer|VisualIntentChecker|DevToolsHealer|HealingDashboard)\.ts$")
_LOCATOR_RE  = re.compile(r"locators\.ts$",  re.IGNORECASE)
_PAGE_RE     = re.compile(r"page\.ts$",      re.IGNORECASE)
_STEPS_RE    = re.compile(r"steps\.ts$",     re.IGNORECASE)
_FEATURE_RE  = re.compile(r"\.feature$",     re.IGNORECASE)
_CUCUMBER_RE = re.compile(r"cucumber",       re.IGNORECASE)


# ── Interface adapter ─────────────────────────────────────────────────────

def _adapt_to_helix_interface(content: str) -> str:
    """
    Rewrite generated TypeScript so it compiles against the Helix-QA
    LocatorRepository / LocatorHealer interface.

    Generator emits        → Helix expects
    ─────────────────────────────────────────────────────────────────
    repo.updateHealed(k,s,…) → repo.setHealed(k, s)
    repo.getBBox(key)         → null
    repo.incrementSuccess(k)  → (removed)
    repo.incrementFailure(k)  → (removed)
    repo.queueSuggestion(…)   → (removed)
    repo.updateBoundingBox(…) → (removed)
    this.devtools.captureBoundingBox(…) → (removed)
    fixture().logger          → this.logger
    fixture().locatorRepository → this.repo
    fixture().page            → this.page
    import { Logger } from "winston" → import { HealerLogger }
    import EnvironmentManager → import { environment } from @config/environment
    new EnvironmentManager()  → environment
    this.env.getBaseUrl()     → environment.getConfig().baseUrl
    this.env.getPath('x')     → "x"
    """
    # repo.updateHealed(key, sel, ...) → repo.setHealed(key, sel)
    content = re.sub(
        r"this\.repo\.updateHealed\(\s*([^,)]+),\s*([^,)]+)(?:,[^)]+)?\)",
        r"this.repo.setHealed(\1, \2)",
        content,
    )
    # repo.getBBox(key) → null
    content = re.sub(r"this\.repo\.getBBox\([^)]*\)", "null", content)

    # Remove single-statement method calls that have no Helix equivalent
    for method in ("incrementSuccess", "incrementFailure", "queueSuggestion",
                   "updateBoundingBox", "captureBoundingBox"):
        content = re.sub(
            rf"^\s*(?:this\.repo\.|(?:this\.\w+\.)?){method}\([^)]*\)(?:\.catch\([^)]*\))?;?\s*\n",
            "",
            content,
            flags=re.MULTILINE,
        )

    # fixture() references
    content = re.sub(r"fixture\(\)\.logger\b",            "this.logger", content)
    content = re.sub(r"fixture\(\)\.locatorRepository\b", "this.repo",   content)
    content = re.sub(r"fixture\(\)\.page\b",              "this.page",   content)

    # Winston Logger → Helix HealerLogger
    content = content.replace(
        'import { Logger } from "winston";',
        'import { HealerLogger } from "./LocatorHealer";',
    )
    content = re.sub(r"\bLogger\b(?!\s*=)", "HealerLogger", content)

    # EnvironmentManager → Helix environment singleton
    content = content.replace(
        'import { EnvironmentManager } from "@helper/environment/environmentManager.util";',
        'import { environment } from "@config/environment";',
    )
    content = re.sub(r"\s*this\.env\s*=\s*new EnvironmentManager\(\);?\s*\n", "\n", content)
    content = content.replace("new EnvironmentManager()", "environment")
    content = content.replace("this.env.getBaseUrl()",    "environment.getConfig().baseUrl")
    content = re.sub(r"this\.env\.getPath\(['\"]([^'\"]+)['\"]\)", r'"\1"', content)

    return content


# ── Path resolution ───────────────────────────────────────────────────────

def _resolve_destination(helix_root: Path, file_key: str) -> Path:
    key = file_key.strip()

    if _CUCUMBER_RE.search(key):
        return helix_root / "src" / "config" / "cucumber.config.ts"
    if _INFRA_RE.search(key):
        return helix_root / "src" / "utils" / "locators" / Path(key).name
    if _FEATURE_RE.search(key):
        return helix_root / "src" / "test" / "features" / Path(key).name
    if _STEPS_RE.search(key):
        return helix_root / "src" / "test" / "steps" / Path(key).name
    if _LOCATOR_RE.search(key):
        parts = Path(key).parts
        stem = next(
            (p for p in parts if p not in ("src", "pages", "locators", "utils") and not p.endswith(".ts")),
            "page",
        )
        return helix_root / "src" / "locators" / f"{stem}.locators.ts"
    if _PAGE_RE.search(key):
        return helix_root / "src" / "pages" / Path(key).name

    rel = key.lstrip("/")
    return helix_root / (rel if rel.startswith("src/") else f"src/{rel}")


# ── Within-file merge helpers ─────────────────────────────────────────────

def _merge_locators(existing: str, generated: str) -> tuple[str, list[str], list[str]]:
    """Append locator entries whose keys are not already in existing."""
    existing_keys = set(re.findall(r"^\s{2}(\w+)\s*:", existing, re.MULTILINE))

    new_entries: list[tuple[str, str]] = []
    current_key: str | None = None
    current_lines: list[str] = []

    for line in generated.splitlines():
        key_match = re.match(r"^  (\w+)\s*:\s*\{", line)
        if key_match:
            if current_key:
                new_entries.append((current_key, "\n".join(current_lines)))
            current_key = key_match.group(1)
            current_lines = [line]
        elif current_key:
            current_lines.append(line)
            if re.match(r"^\s*\},?\s*$", line):
                new_entries.append((current_key, "\n".join(current_lines)))
                current_key = None
                current_lines = []

    added: list[str] = []
    skipped: list[str] = []
    append_lines: list[str] = []

    for key, block in new_entries:
        if key in existing_keys:
            skipped.append(key)
        else:
            append_lines.append(block)
            added.append(key)

    if not append_lines:
        return existing, added, skipped

    insertion = "\n" + "\n".join(append_lines)
    merged = re.sub(r"(\n\}\s*as\s+const\s*;)", insertion + r"\1", existing, count=1)
    if merged == existing:
        merged = existing.rstrip() + "\n" + insertion + "\n"
    return merged, added, skipped


def _merge_steps(existing: str, generated: str) -> tuple[str, list[str], list[str]]:
    """Append step blocks whose regex pattern is not already in existing."""
    existing_patterns = set(re.findall(r"/\^([^/]+)\$/", existing))

    step_block_re = re.compile(r"^(Given|When|Then)\(", re.MULTILINE)
    parts = step_block_re.split(generated)

    blocks: list[tuple[str, str]] = []
    i = 1
    while i + 1 < len(parts):
        keyword = parts[i]
        body    = parts[i + 1]
        blocks.append((keyword, keyword + "(" + body))
        i += 2

    added:      list[str] = []
    skipped:    list[str] = []
    new_blocks: list[str] = []

    for _kw, block in blocks:
        pat_match = re.search(r"/\^([^/]+)\$/", block)
        pattern = pat_match.group(1) if pat_match else block[:40]
        if pattern in existing_patterns:
            skipped.append(pattern)
        else:
            new_blocks.append(block)
            added.append(pattern)

    merged = existing.rstrip() + ("\n\n" + "\n".join(new_blocks) if new_blocks else "") + "\n"
    return merged, added, skipped


def _merge_page_methods(existing: str, generated: str) -> tuple[str, list[str], list[str]]:
    """Append async methods whose names are not already in existing."""
    existing_methods = set(re.findall(r"async\s+(\w+)\s*\(", existing))

    method_re = re.compile(r"(  async\s+\w+\s*\([^)]*\)[^{]*\{)", re.MULTILINE)
    raw_parts = method_re.split(generated)

    method_blocks: list[tuple[str, str]] = []
    i = 1
    while i + 1 < len(raw_parts):
        sig          = raw_parts[i]
        body_and_rest = raw_parts[i + 1]
        depth, end = 1, 0
        for ch in body_and_rest:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    break
            end += 1
        method_blocks.append((sig, sig + body_and_rest[: end + 1]))
        i += 2

    added:       list[str] = []
    skipped:     list[str] = []
    new_methods: list[str] = []

    for sig, block in method_blocks:
        name_match = re.search(r"async\s+(\w+)\s*\(", sig)
        name = name_match.group(1) if name_match else sig[:30]
        if name in existing_methods:
            skipped.append(name)
        else:
            new_methods.append(block)
            added.append(name)

    if not new_methods:
        return existing, added, skipped

    insertion = "\n" + "\n\n".join(new_methods) + "\n"
    merged = re.sub(r"\n\}\s*\n?$", insertion + "\n}\n", existing, count=1)
    if merged == existing:
        merged = existing.rstrip() + insertion + "}\n"
    return merged, added, skipped


# ── Framework state inspection ────────────────────────────────────────────

def inspect_helix_project(helix_root: str) -> dict[str, Any]:
    """
    Examine the Helix-QA project root and return a machine-readable verdict.

    framework_state: "absent" | "partial" | "present"
    recommendation:  "scaffold_and_tests" | "tests_only"

    "absent"   helix_root missing, or src/ absent, or both required infra files absent.
    "partial"  src/ exists but one or both required infra files missing.
    "present"  Both LocatorHealer.ts and LocatorRepository.ts exist on disk.
    """
    root = Path(helix_root).expanduser().resolve()

    if not root.exists():
        return {
            "framework_state": "absent",
            "missing_infra": sorted(_INFRA_FILES),
            "existing_infra": [],
            "has_src": False,
            "recommendation": "scaffold_and_tests",
            "message": (
                f"helix_root '{root}' does not exist. "
                "Create the directory and use mode='scaffold_and_tests'."
            ),
        }

    infra_dir = root / "src" / "utils" / "locators"
    has_src   = (root / "src").exists()

    existing_infra   = sorted(f for f in _INFRA_FILES     if (infra_dir / f).exists())
    missing_infra    = sorted(f for f in _INFRA_FILES     if f not in existing_infra)
    missing_required = sorted(f for f in _REQUIRED_INFRA  if f not in existing_infra)

    if not has_src or missing_required:
        state = "absent" if not has_src else "partial"
        return {
            "framework_state": state,
            "missing_infra": missing_infra,
            "existing_infra": existing_infra,
            "has_src": has_src,
            "recommendation": "scaffold_and_tests",
            "message": (
                f"Helix-QA framework is {state}. "
                f"Missing required files: {missing_required}. "
                "Run scaffold_locator_repository, then write_helix_files with mode='scaffold_and_tests'."
            ),
        }

    return {
        "framework_state": "present",
        "missing_infra": missing_infra,
        "existing_infra": existing_infra,
        "has_src": True,
        "recommendation": "tests_only",
        "message": (
            "Helix-QA framework is present. "
            "Infrastructure files will not be touched. "
            "Only test files will be written or merged."
        ),
    }


# ── Main write function ────────────────────────────────────────────────────

def write_files_to_helix(
    helix_root:     str,
    files:          dict[str, str],
    mode:           str  = "scaffold_and_tests",
    force_scaffold: bool = False,
) -> dict[str, Any]:
    """
    Write generated files into the Helix-QA project with full deduplication.

    mode="tests_only"          write locators, pages, steps, features — merge
                               into existing files, skip infra files always.
    mode="scaffold_and_tests"  also write infra files that do not yet exist.
    force_scaffold=True        overwrite existing infra files (use deliberately).
    """
    root = Path(helix_root).expanduser().resolve()
    if not root.exists():
        return {
            "success": False,
            "error": f"helix_root does not exist: {root}",
            "written": [], "skipped": [],
        }

    written:       list[dict] = []
    skipped:       list[dict] = []
    deduplication: dict[str, Any] = {}

    for file_key, raw_content in files.items():
        if not raw_content or not raw_content.strip():
            skipped.append({"file_key": file_key, "reason": "empty content"})
            continue

        # Apply interface adapter to all TypeScript content
        content = _adapt_to_helix_interface(raw_content)

        dest     = _resolve_destination(root, file_key)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest_rel = str(dest.relative_to(root))

        # ── Infrastructure files ───────────────────────────────────────────
        if _INFRA_RE.search(file_key):
            if mode == "tests_only":
                skipped.append({
                    "file_key": file_key, "dest": dest_rel,
                    "reason": "infrastructure file — skipped in tests_only mode",
                })
                continue
            if dest.exists() and not force_scaffold:
                skipped.append({
                    "file_key": file_key, "dest": dest_rel,
                    "reason": "infrastructure file already exists (pass force_scaffold=True to overwrite)",
                })
                continue
            try:
                action = "overwritten" if dest.exists() else "created"
                dest.write_text(content, encoding="utf-8")
                written.append({"file_key": file_key, "dest": dest_rel,
                                 "bytes": len(content.encode()), "action": action})
            except OSError as exc:
                skipped.append({"file_key": file_key, "dest": dest_rel, "reason": str(exc)})
            continue

        # ── Cucumber config: append profile, skip duplicate ────────────────
        if _CUCUMBER_RE.search(file_key):
            try:
                if dest.exists():
                    existing_text  = dest.read_text(encoding="utf-8")
                    profile_match  = re.match(r"\s*(\w+)\s*:", content.strip())
                    profile_name   = profile_match.group(1) if profile_match else None
                    if profile_name and profile_name in existing_text:
                        skipped.append({
                            "file_key": file_key, "dest": dest_rel,
                            "reason": f"profile '{profile_name}' already exists in cucumber.config.ts",
                        })
                        continue
                    dest.write_text(
                        existing_text.rstrip() + "\n\n// --- generated profile ---\n" + content,
                        encoding="utf-8",
                    )
                    written.append({"file_key": file_key, "dest": dest_rel,
                                    "bytes": len(content.encode()), "action": "appended"})
                else:
                    dest.write_text(content, encoding="utf-8")
                    written.append({"file_key": file_key, "dest": dest_rel,
                                    "bytes": len(content.encode()), "action": "created"})
            except OSError as exc:
                skipped.append({"file_key": file_key, "dest": dest_rel, "reason": str(exc)})
            continue

        # ── Feature files: overwrite (they are the Gherkin source of truth) ─
        if _FEATURE_RE.search(file_key):
            try:
                action = "overwritten" if dest.exists() else "created"
                dest.write_text(content, encoding="utf-8")
                written.append({"file_key": file_key, "dest": dest_rel,
                                 "bytes": len(content.encode()), "action": action})
            except OSError as exc:
                skipped.append({"file_key": file_key, "dest": dest_rel, "reason": str(exc)})
            continue

        # ── Merge-aware write for locators / page / steps ─────────────────
        try:
            if not dest.exists():
                dest.write_text(content, encoding="utf-8")
                written.append({"file_key": file_key, "dest": dest_rel,
                                 "bytes": len(content.encode()), "action": "created"})
                continue

            existing_text = dest.read_text(encoding="utf-8")

            if _LOCATOR_RE.search(file_key):
                merged, added, dup = _merge_locators(existing_text, content)
                deduplication[dest_rel] = {
                    "type": "locators", "added_keys": added, "skipped_keys": dup,
                }
            elif _STEPS_RE.search(file_key):
                merged, added, dup = _merge_steps(existing_text, content)
                deduplication[dest_rel] = {
                    "type": "steps", "added_patterns": added, "skipped_patterns": dup,
                }
            elif _PAGE_RE.search(file_key):
                merged, added, dup = _merge_page_methods(existing_text, content)
                deduplication[dest_rel] = {
                    "type": "page", "added_methods": added, "skipped_methods": dup,
                }
            else:
                merged = content
                deduplication[dest_rel] = {"type": "unknown", "action": "overwritten"}

            dest.write_text(merged, encoding="utf-8")
            written.append({"file_key": file_key, "dest": dest_rel,
                             "bytes": len(merged.encode()), "action": "merged"})

        except OSError as exc:
            skipped.append({"file_key": file_key, "dest": dest_rel, "reason": str(exc)})

    return {
        "success": len(written) > 0 or len(skipped) == 0,
        "helix_root": str(root),
        "written": written,
        "skipped": skipped,
        "deduplication": deduplication,
        "summary": {
            "requested": len(files),
            "written":   len(written),
            "skipped":   len(skipped),
        },
    }


# ── Read / list helpers ───────────────────────────────────────────────────

def read_helix_file(helix_root: str, relative_path: str) -> dict[str, Any]:
    root   = Path(helix_root).expanduser().resolve()
    target = (root / relative_path.lstrip("/")).resolve()
    try:
        target.relative_to(root)
    except ValueError:
        return {"success": False, "error": "Path escapes helix_root"}
    if not target.exists():
        return {"success": False, "exists": False, "path": relative_path}
    try:
        content = target.read_text(encoding="utf-8")
        return {"success": True, "exists": True, "path": relative_path,
                "content": content, "bytes": len(content.encode())}
    except OSError as exc:
        return {"success": False, "error": str(exc)}


def list_helix_tree(helix_root: str) -> dict[str, Any]:
    root = Path(helix_root).expanduser().resolve()
    if not root.exists():
        return {"success": False, "error": f"helix_root does not exist: {root}"}

    tree: dict[str, list[str]] = {
        "features": [], "steps": [], "pages": [],
        "locators": [], "utils_locators": [], "other": [],
    }
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if path.suffix not in (".ts", ".feature", ".js"):
            continue
        if any(p in ("node_modules", "dist", "test-results", ".git") for p in path.parts):
            continue
        rel = str(path.relative_to(root))
        if "test/features" in rel or rel.endswith(".feature"):
            tree["features"].append(rel)
        elif "test/steps" in rel and rel.endswith(".ts"):
            tree["steps"].append(rel)
        elif "src/pages" in rel and rel.endswith(".ts"):
            tree["pages"].append(rel)
        elif "src/locators" in rel and rel.endswith(".ts"):
            tree["locators"].append(rel)
        elif "utils/locators" in rel and rel.endswith(".ts"):
            tree["utils_locators"].append(rel)
        else:
            tree["other"].append(rel)

    return {"success": True, "helix_root": str(root), "tree": tree}
