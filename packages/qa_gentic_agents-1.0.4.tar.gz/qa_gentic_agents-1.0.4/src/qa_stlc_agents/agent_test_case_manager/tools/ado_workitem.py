"""
ado_workitem.py — Azure DevOps Work Item REST API calls for the Test Case Manager.

All functions use get_auth_headers() from auth.py — no credentials in this file.

Public API:
  fetch_work_item(org_url, project, work_item_id)        -> dict
  create_test_case(org_url, project, title, steps, ...)  -> dict
  link_test_cases_to_work_item(org_url, project, wi_id, tc_ids) -> dict
  get_linked_test_cases(org_url, project, work_item_id)  -> dict
"""
from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from typing import Dict, List, Optional

import requests

from qa_stlc_agents.shared.auth import get_auth_headers

_API = "7.1"


# ---------------------------------------------------------------------------
# fetch_work_item
# ---------------------------------------------------------------------------

def fetch_work_item(org_url: str, project: str, work_item_id: int) -> dict:
    """Fetch a PBI or Bug with all relevant fields and parent feature."""
    org_url = org_url.rstrip("/")
    headers = get_auth_headers()

    resp = requests.get(
        f"{org_url}/{project}/_apis/wit/workitems/{work_item_id}",
        headers=headers,
        params={"$expand": "relations", "api-version": _API},
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    fields = data.get("fields", {})

    wi_type = fields.get("System.WorkItemType", "")

    # ── Epic guard — test cases must NEVER be created for Epics ─────────────
    if wi_type == "Epic":
        return {
            "error": "epic_not_supported",
            "work_item_type": wi_type,
            "work_item_id": work_item_id,
            "message": (
                f"Work item {work_item_id} is an Epic. "
                "Manual test cases cannot be created or linked to an Epic. "
                "Test cases in ADO are always scoped to PBIs, Bugs, or Features — "
                "never to Epics. To generate tests for this Epic, use "
                "qa-gherkin-generator:fetch_epic_hierarchy to walk its child Features "
                "and PBIs/Bugs, then call create_and_link_test_cases on each individual "
                "Feature or PBI/Bug work item ID, not on the Epic itself."
            ),
        }

    wi = {
        "id": data["id"],
        "type": fields.get("System.WorkItemType", ""),
        "title": fields.get("System.Title", ""),
        "description": _strip_html(fields.get("System.Description", "") or ""),
        "acceptance_criteria": _strip_html(
            fields.get("Microsoft.VSTS.Common.AcceptanceCriteria", "") or ""
        ),
        "repro_steps": _strip_html(
            fields.get("Microsoft.VSTS.TCM.ReproSteps", "") or ""
        ),
        "state": fields.get("System.State", ""),
        "priority": fields.get("Microsoft.VSTS.Common.Priority", ""),
        "story_points": fields.get("Microsoft.VSTS.Scheduling.StoryPoints", ""),
        "tags": fields.get("System.Tags", ""),
        "assigned_to": (
            (fields.get("System.AssignedTo") or {}).get("displayName", "")
        ),
        "area_path": fields.get("System.AreaPath", ""),
        "iteration_path": fields.get("System.IterationPath", ""),
    }

    # Fetch parent feature if present
    parent_feature = None
    for rel in data.get("relations", []):
        if rel.get("rel") == "System.LinkTypes.Hierarchy-Reverse":
            try:
                pr = requests.get(
                    rel["url"] + f"?api-version={_API}",
                    headers=get_auth_headers(),
                    timeout=30,
                )
                if pr.ok:
                    pf = pr.json().get("fields", {})
                    parent_feature = {
                        "id": pr.json().get("id"),
                        "type": pf.get("System.WorkItemType", ""),
                        "title": pf.get("System.Title", ""),
                    }
            except Exception:
                pass
            break

    # Existing linked test cases count
    existing_tc_count = sum(
        1 for r in data.get("relations", [])
        if r.get("rel") == "Microsoft.VSTS.Common.TestedBy-Forward"
    )

    # Coverage hints derived from text
    coverage_hints = _extract_coverage_hints(wi)

    return {
        "work_item": wi,
        "parent_feature": parent_feature,
        "existing_test_cases_count": existing_tc_count,
        "coverage_hints": coverage_hints,
    }


# ---------------------------------------------------------------------------
# create_test_case
# ---------------------------------------------------------------------------

def create_test_case(
    org_url: str,
    project: str,
    title: str,
    steps: List[Dict],
    priority: int = 2,
    area_path: Optional[str] = None,
    iteration_path: Optional[str] = None,
) -> dict:
    """Create a Test Case work item with XML steps in ADO."""
    org_url = org_url.rstrip("/")
    headers = get_auth_headers("application/json-patch+json")

    steps_xml = _build_steps_xml(steps)

    patch = [
        {"op": "add", "path": "/fields/System.Title", "value": title},
        {"op": "add", "path": "/fields/System.State", "value": "Design"},
        {"op": "add", "path": "/fields/Microsoft.VSTS.Common.Priority", "value": priority},
    ]
    if steps_xml:
        patch.append({"op": "add", "path": "/fields/Microsoft.VSTS.TCM.Steps", "value": steps_xml})
    if area_path:
        patch.append({"op": "add", "path": "/fields/System.AreaPath", "value": area_path})
    if iteration_path:
        patch.append({"op": "add", "path": "/fields/System.IterationPath", "value": iteration_path})

    resp = requests.post(
        f"{org_url}/{project}/_apis/wit/workitems/$Test%20Case",
        headers=headers,
        params={"api-version": _API},
        json=patch,
        timeout=30,
    )
    resp.raise_for_status()
    created = resp.json()
    return {
        "success": True,
        "test_case_id": created["id"],
        "title": title,
        "url": created.get("_links", {}).get("html", {}).get("href", ""),
    }


# ---------------------------------------------------------------------------
# link_test_cases_to_work_item
# ---------------------------------------------------------------------------

def link_test_cases_to_work_item(
    org_url: str,
    project: str,
    work_item_id: int,
    test_case_ids: List[int],
) -> dict:
    """Create TestedBy-Forward links from a work item to test cases."""
    org_url = org_url.rstrip("/")
    headers = get_auth_headers("application/json-patch+json")

    relations = [
        {
            "op": "add",
            "path": "/relations/-",
            "value": {
                "rel": "Microsoft.VSTS.Common.TestedBy-Forward",
                "url": f"{org_url}/{project}/_apis/wit/workItems/{tc_id}",
            },
        }
        for tc_id in test_case_ids
    ]

    resp = requests.patch(
        f"{org_url}/{project}/_apis/wit/workitems/{work_item_id}",
        headers=headers,
        params={"api-version": _API},
        json=relations,
        timeout=30,
    )
    resp.raise_for_status()
    return {
        "success": True,
        "work_item_id": work_item_id,
        "linked_count": len(test_case_ids),
        "test_case_ids": test_case_ids,
    }


# ---------------------------------------------------------------------------
# get_linked_test_cases
# ---------------------------------------------------------------------------

def get_linked_test_cases(org_url: str, project: str, work_item_id: int) -> dict:
    """Return all test cases linked via TestedBy to a work item."""
    org_url = org_url.rstrip("/")
    headers = get_auth_headers()

    resp = requests.get(
        f"{org_url}/{project}/_apis/wit/workitems/{work_item_id}",
        headers=headers,
        params={"$expand": "relations", "api-version": _API},
        timeout=30,
    )
    resp.raise_for_status()

    linked = []
    for rel in resp.json().get("relations", []):
        if rel.get("rel") == "Microsoft.VSTS.Common.TestedBy-Forward":
            tc_id = int(rel["url"].split("/")[-1])
            try:
                tc = requests.get(
                    rel["url"] + f"?api-version={_API}",
                    headers=get_auth_headers(),
                    timeout=30,
                )
                if tc.ok:
                    f = tc.json().get("fields", {})
                    linked.append({
                        "id": tc_id,
                        "title": f.get("System.Title", ""),
                        "state": f.get("System.State", ""),
                        "priority": f.get("Microsoft.VSTS.Common.Priority", ""),
                    })
            except Exception:
                linked.append({"id": tc_id})

    return {"work_item_id": work_item_id, "linked_test_cases": linked, "count": len(linked)}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _build_steps_xml(steps: List[Dict]) -> str:
    if not steps:
        return ""

    def esc(s: str) -> str:
        return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

    inner = "".join(
        f'<step id="{i+1}" type="ValidateStep">'
        f'<parameterizedString isformatted="false">{esc(s.get("action",""))}</parameterizedString>'
        f'<parameterizedString isformatted="false">{esc(s.get("expected_result",""))}</parameterizedString>'
        f"<description/></step>"
        for i, s in enumerate(steps)
    )
    return f'<steps id="0" last="{len(steps)}">{inner}</steps>'


def _strip_html(html: str) -> str:
    if not html:
        return ""
    import re
    text = re.sub(r"<br\s*/?>", "\n", html, flags=re.IGNORECASE)
    text = re.sub(r"</p>|</li>|</tr>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"<li[^>]*>", "• ", text, flags=re.IGNORECASE)
    text = re.sub(r"<[^>]+>", "", text)
    for old, new in [("&nbsp;", " "), ("&amp;", "&"), ("&lt;", "<"), ("&gt;", ">"), ("&quot;", '"')]:
        text = text.replace(old, new)
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def _extract_coverage_hints(wi: dict) -> list:
    text = " ".join([wi.get("description", ""), wi.get("acceptance_criteria", "")]).lower()
    checks = [
        (["toast", "notification", "success message", "confirmation"], "toast_notifications"),
        (["mb", "kb", "size limit", "file size", "maximum size"], "file_size_boundary"),
        (["display", "shows", "reflects", "after upload", "after save", "updated"], "post_action_state"),
        (["mobile", "webview", "ios", "android"], "platform_specific"),
        (["initials", "first name", "last name", "derived", "generated"], "computed_values"),
        (["refresh", "reload", "re-login", "persist", "retained"], "data_persistence"),
        (["tab", "keyboard", "accessible", "aria", "wcag", "a11y"], "accessibility"),
        (["crop", "resize", "zoom", "drag", "rotate"], "image_manipulation"),
        (["format", "png", "jpg", "jpeg", "webp", "svg"], "file_formats"),
        (["cancel", "close", "discard", "dismiss"], "cancel_flows"),
    ]
    return [hint for keywords, hint in checks if any(kw in text for kw in keywords)]
