#!/usr/bin/env python3
"""
generate-mcp-config.py — Write MCP server config for Claude Code or VS Code.

Usage:
    python3 scripts/generate-mcp-config.py              # Claude Code  → .mcp.json
    python3 scripts/generate-mcp-config.py --vscode     # VS Code      → .vscode/mcp.json
    python3 scripts/generate-mcp-config.py --print      # Print both, write nothing

The generated config uses absolute paths to this project's .venv binaries so
the MCP servers start without needing the project on PATH.

Windows note: binaries live in .venv\\Scripts\\ not .venv/bin/
"""

import json
import pathlib
import platform
import sys

# ── Paths ─────────────────────────────────────────────────────────────────────
ROOT = pathlib.Path(__file__).parent.parent.resolve()

# Windows uses Scripts/, Unix uses bin/
BIN_DIR = ROOT / ".venv" / ("Scripts" if platform.system() == "Windows" else "bin")

# Binary extension on Windows
EXT = ".exe" if platform.system() == "Windows" else ""

AGENTS = {
    "qa-test-case-manager":    BIN_DIR / f"qa-test-case-manager{EXT}",
    "qa-gherkin-generator":    BIN_DIR / f"qa-gherkin-generator{EXT}",
    "qa-playwright-generator": BIN_DIR / f"qa-playwright-generator{EXT}",
}

# ── Validate binaries exist ───────────────────────────────────────────────────
def check_binaries():
    missing = [name for name, path in AGENTS.items() if not path.exists()]
    if missing:
        print("⚠  Some binaries not found — run `make install` first:")
        for name in missing:
            print(f"   {AGENTS[name]}")
        print()


# ── Config builders ───────────────────────────────────────────────────────────
def claude_config() -> dict:
    """
    Claude Code format (.mcp.json):
    https://docs.claude.ai/en/docs/claude-code/mcp
    """
    return {
        "mcpServers": {
            name: {"command": str(path)}
            for name, path in AGENTS.items()
        }
    }


def vscode_config() -> dict:
    """
    VS Code MCP format (.vscode/mcp.json):
    https://code.visualstudio.com/docs/copilot/chat/mcp-servers

    Uses 'type: stdio' and splits command + args for compatibility with
    both GitHub Copilot and the VS Code MCP extension.
    """
    servers = {}
    for name, path in AGENTS.items():
        servers[name] = {
            "type": "stdio",
            "command": str(path),
            "args": [],
            "env": {
                # Pass through auth env vars if set — useful for CI/CD
                "AZURE_TENANT_ID":     "${env:AZURE_TENANT_ID}",
                "AZURE_CLIENT_ID":     "${env:AZURE_CLIENT_ID}",
                "AZURE_CLIENT_SECRET": "${env:AZURE_CLIENT_SECRET}",
            },
        }
    return {"servers": servers}


# ── Main ──────────────────────────────────────────────────────────────────────
mode = sys.argv[1] if len(sys.argv) > 1 else "--claude"

if mode not in ("--claude", "--vscode", "--print"):
    print(f"Unknown option: {mode}")
    print("Usage: python3 scripts/generate-mcp-config.py [--claude | --vscode | --print]")
    sys.exit(1)

check_binaries()

if mode == "--print":
    print("=== Claude Code  (.mcp.json) ===")
    print(json.dumps(claude_config(), indent=2))
    print("\n=== VS Code  (.vscode/mcp.json) ===")
    print(json.dumps(vscode_config(), indent=2))

elif mode == "--vscode":
    vscode_dir = ROOT / ".vscode"
    vscode_dir.mkdir(exist_ok=True)
    out = vscode_dir / "mcp.json"
    out.write_text(json.dumps(vscode_config(), indent=2) + "\n", encoding="utf-8")
    print(f"✓  Written to {out}")
    print()
    print("Next steps:")
    print("  1. Open VS Code in this workspace")
    print("  2. Install the 'MCP Servers' extension if not already installed")
    print("  3. Reload the window — the three qa-* servers will appear in the MCP panel")
    print("  4. GitHub Copilot Chat will pick them up automatically on next conversation")

else:  # --claude (default)
    out = ROOT / ".mcp.json"
    out.write_text(json.dumps(claude_config(), indent=2) + "\n", encoding="utf-8")
    print(f"✓  Written to {out}")
    print()
    print("Next steps:")
    print("  1. Open this project in Claude Code")
    print("  2. Run: /mcp  (to verify the three servers are loaded)")
    print("  3. Ask: 'Generate test cases for work item #<id> in <project>'")