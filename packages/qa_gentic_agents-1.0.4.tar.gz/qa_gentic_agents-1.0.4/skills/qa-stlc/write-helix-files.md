---
name: write-helix-files
description: >
  Use this skill whenever generated Playwright TypeScript files (locators,
  page objects, step definitions, feature files, healing infrastructure) need
  to be placed into a local Helix-QA project on disk. Triggers after
  generate-playwright-code or scaffold_locator_repository has produced a
  'files' dict. Always calls inspect_helix_project first to determine whether
  the framework exists, then picks the correct write mode automatically.
compatibility:
  tools:
    - qa-helix-writer:inspect_helix_project
    - qa-helix-writer:list_helix_tree
    - qa-helix-writer:read_helix_file
    - qa-helix-writer:write_helix_files
    - qa-playwright-generator:generate_playwright_code
    - qa-playwright-generator:scaffold_locator_repository
---

# Write Helix Files Skill

Place files produced by `qa-playwright-generator` into a local Helix-QA
project. The skill handles two situations automatically:

| Situation | What happens |
|---|---|
| Framework does not exist yet | Scaffold infrastructure + write test files |
| Framework already exists | Merge only the new work item's test files; never touch infrastructure |

---

## Helix-QA Directory Layout

```
<helix_root>/
├── src/
│   ├── locators/                   ← <kebab>.locators.ts          (merged per file)
│   ├── pages/                      ← <Page>.page.ts               (merged per file)
│   ├── test/
│   │   ├── features/               ← <feature>.feature            (overwritten)
│   │   └── steps/                  ← <feature>.steps.ts           (merged per file)
│   ├── utils/
│   │   └── locators/               ← LocatorHealer.ts etc.        (protected)
│   └── config/
│       └── cucumber.config.ts      ← profile blocks appended      (deduplicated)
└── package.json
```

---

## Decision Flow

```
inspect_helix_project(helix_root)
         │
         ├─ framework_state: "absent" or "partial"
         │        │
         │        └─ scaffold_locator_repository(...)
         │                   │
         │                   └─ write_helix_files(..., mode="scaffold_and_tests")
         │                      Writes infra files that don't exist + test files
         │
         └─ framework_state: "present"
                  │
                  └─ write_helix_files(..., mode="tests_only")
                     Merges only locators / page / steps / feature
                     Infrastructure files are NEVER touched
```

---

## Step-by-Step Workflow

### Step 1 — Confirm helix_root

Ask the user for the absolute path to the Helix-QA project root if not provided.
This is the directory containing `package.json` and `src/`.

---

### Step 2 — Inspect framework state

```
qa-helix-writer:inspect_helix_project(helix_root)
```

Read the response:

```json
{
  "framework_state": "present",
  "existing_infra":  ["LocatorHealer.ts", "LocatorRepository.ts", ...],
  "missing_infra":   [],
  "recommendation":  "tests_only",
  "message":         "Helix-QA framework is present. ..."
}
```

**Act on `recommendation` directly — do not ask the user to choose the mode.**

---

### Step 3A — Framework absent or partial → scaffold first

Only when `recommendation` is `"scaffold_and_tests"`:

```
# Generate infrastructure
qa-playwright-generator:scaffold_locator_repository(
  output_dir               = "src/utils/locators",
  enable_ai_vision         = true,
  repository_path          = "test-results/locator-repository.json",
  dashboard_port           = 7890,
  enable_timing_healing    = true,
  enable_visual_regression = true,
  enable_devtools_healer   = true
)
```

Then proceed to Step 4 with `mode="scaffold_and_tests"`.

---

### Step 3B — Framework present → skip scaffold

When `recommendation` is `"tests_only"`, skip Step 3A entirely.
Proceed to Step 4 with `mode="tests_only"`.

---

### Step 4 — Generate test files

Run `generate_playwright_code` for the work item's Gherkin feature:

```
qa-playwright-generator:generate_playwright_code(
  gherkin_content   = <validated .feature file content>,
  page_class_name   = "<PageClass>",
  app_name          = "<app>",
  healing_strategy  = "role-label-text-ai",
  enable_visual_regression = true,
  enable_timing_healing    = true
)
```

---

### Step 5 — Write files

```
qa-helix-writer:write_helix_files(
  helix_root = "<helix_root>",
  files      = <files dict from generate_playwright_code>,
  mode       = "<recommendation from Step 2>"
)
```

The tool handles everything automatically:

**File routing:**

| Generator key | Helix destination |
|---|---|
| `src/pages/<k>/locators.ts` | `src/locators/<k>.locators.ts` |
| `src/pages/<k>/<k>.page.ts` | `src/pages/<k>.page.ts` |
| `src/test/steps/<k>.steps.ts` | `src/test/steps/<k>.steps.ts` |
| `*.feature` | `src/test/features/<k>.feature` |
| `config/cucumber.js (add this profile)` | `src/config/cucumber.config.ts` (appended) |
| `src/utils/locators/Locator*.ts` | `src/utils/locators/<file>` |

**Deduplication per file type:**

| File | Behaviour when file already exists |
|---|---|
| `locators.ts` | New const-object keys appended; existing keys skipped |
| `*.steps.ts` | New step blocks appended; steps with matching regex skipped |
| `*.page.ts` | New async methods appended; existing method names skipped |
| `*.feature` | Overwritten (Gherkin is the source of truth) |
| `cucumber.config.ts` | Profile block appended; duplicate profile names skipped |
| Infrastructure `*.ts` | Protected in `tests_only`; written-if-absent in `scaffold_and_tests` |

**Interface adaptation (applied automatically):**

| Generated code | Rewritten to |
|---|---|
| `repo.updateHealed(k, s, …)` | `repo.setHealed(k, s)` |
| `repo.getBBox(key)` | `null` |
| `repo.incrementSuccess/Failure(…)` | removed |
| `repo.queueSuggestion(…)` | removed |
| `repo.updateBoundingBox(…)` | removed |
| `fixture().logger` | `this.logger` |
| `fixture().locatorRepository` | `this.repo` |
| `fixture().page` | `this.page` |
| `import { Logger } from "winston"` | `import { HealerLogger }` |
| `EnvironmentManager` | Helix `environment` singleton |

---

### Step 6 — Verify the response

```json
{
  "summary": { "requested": 4, "written": 4, "skipped": 0 },
  "deduplication": {
    "src/locators/checkout.locators.ts": {
      "type": "locators",
      "added_keys":   ["checkoutBtn", "summaryTotal"],
      "skipped_keys": ["submitBtn", "cancelBtn"]
    },
    "src/test/steps/checkout.steps.ts": {
      "type": "steps",
      "added_patterns":   ["user completes checkout"],
      "skipped_patterns": ["user logs in"]
    }
  }
}
```

Report the `deduplication` summary to the user so they can confirm which
symbols were added vs skipped.

**Skipped reasons to handle:**

| Reason | Action |
|---|---|
| `"empty content"` | Normal — generator produced no content for that file |
| `"profile '…' already exists"` | Normal — no action needed |
| `"infrastructure file already exists"` | Normal in `tests_only` mode |
| `"infrastructure file — skipped in tests_only mode"` | Normal |
| Any `OSError` | Report path and error to user |

---

## Scaffold vs Regenerate Infrastructure

**First-time setup** (`framework_state` is `"absent"` or `"partial"`):

```
scaffold_locator_repository(...)   # generate 6 infra files
write_helix_files(..., mode="scaffold_and_tests")
# Writes missing infra files + test files
```

**Intentional infrastructure regeneration** (user explicitly requests it):

```
write_helix_files(..., mode="scaffold_and_tests", force_scaffold=true)
# Overwrites ALL infra files — use deliberately
```

**Never** call with `force_scaffold=true` unless the user has explicitly asked
to regenerate the healing infrastructure.

---

## Quality Gates

Before calling `write_helix_files`:

- [ ] `inspect_helix_project` has been called and `recommendation` noted.
- [ ] `mode` matches `recommendation` — never override without user instruction.
- [ ] `force_scaffold` is `false` unless the user explicitly asked to regenerate.
- [ ] The `files` dict comes directly from `generate_playwright_code` or
      `scaffold_locator_repository` — never manually constructed.
- [ ] After writing, the `deduplication` field has been reviewed and reported.
