# dirsql

Rust SDK for `dirsql`. Ephemeral SQL index over a local directory.

[Documentation](https://thekevinscott.github.io/dirsql/?lang=rust)

Also available as [`dirsql` on PyPI](https://pypi.org/project/dirsql/) and [`dirsql` on npm](https://www.npmjs.com/package/dirsql).

## Installation

```bash
cargo add dirsql
```

## API

- `Table::new(...)` for infallible extractors
- `Table::try_new(...)` for fallible extractors
- `DirSQL::new(...)` for synchronous indexing
- `DirSQL::with_ignore(...)` for indexing with ignore patterns
- `DirSQL::query(...)` for SQL queries
- `DirSQL::watch(...)` for an async row-event stream

## License

MIT
