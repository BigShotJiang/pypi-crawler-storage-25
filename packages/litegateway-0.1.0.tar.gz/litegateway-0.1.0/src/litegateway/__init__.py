from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("litegateway")
except PackageNotFoundError:
    __version__ = "unknown"
