"""
Rasteric: A Python geospatial library for raster preprocessing, analysis, visualization, and modeling.
"""

from .raster import (
    # Path utilities
    convpath,
    # Normalization
    normalize,
    norm,
    brighten,
    # Visualization
    plot,
    contour,
    hist,
    # Spatial utilities
    haversine,
    list_tif,
    extract_band_name,
    # Data handling
    stack,
    bandnames,
    getFeatures,
    clip,
    extract,
    savetif,
    mergecsv,
    align_to_shp,
    # Vegetation indices
    ndvi,
    evi,
    savi,
    ndwi,
    gndvi,
    ndmi,
    # Analysis
    zonalstats,
    stats,
    # Conversion
    convras,
    resample,
    reproject,
    # Mosaic
    mosaic,
    # Raster calculator
    calc,
    bandmath,
    # Gap filling
    fillnodata,
    # Time-series
    timeseries,
    change_detect,
    # Cloud masking
    cloudmask,
    # Texture
    texture,
    # Classification
    classify,
    # ML preparation
    sample,
    train_test_split,
    # Thumbnail
    thumbnail,
)
from .utils import fix_path, get_files
from .sen2 import process_sen2, upscale

__version__ = "2.0.0"
__all__ = [
    # Path utilities
    "convpath",
    # Normalization
    "normalize",
    "norm",
    "brighten",
    # Visualization
    "plot",
    "contour",
    "hist",
    # Spatial utilities
    "haversine",
    "list_tif",
    "extract_band_name",
    # Data handling
    "stack",
    "bandnames",
    "getFeatures",
    "clip",
    "extract",
    "savetif",
    "mergecsv",
    "align_to_shp",
    # Vegetation indices
    "ndvi",
    "evi",
    "savi",
    "ndwi",
    "gndvi",
    "ndmi",
    # Analysis
    "zonalstats",
    "stats",
    # Conversion
    "convras",
    "resample",
    "reproject",
    # Mosaic
    "mosaic",
    # Raster calculator
    "calc",
    "bandmath",
    # Gap filling
    "fillnodata",
    # Time-series
    "timeseries",
    "change_detect",
    # Cloud masking
    "cloudmask",
    # Texture
    "texture",
    # Classification
    "classify",
    # ML preparation
    "sample",
    "train_test_split",
    # Thumbnail
    "thumbnail",
    # Utilities
    "fix_path",
    "get_files",
    # Sentinel-2
    "process_sen2",
    "upscale",
]
