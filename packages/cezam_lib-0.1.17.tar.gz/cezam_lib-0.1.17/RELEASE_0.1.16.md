# Mise à jour cezam-lib 0.1.16

Ce document résume les changements livrés avec la version **0.1.16** (branche `release/0.1.16`, commit `feat: add SpecializedDocumentItem and fix gitignore`).

## Objectif fonctionnel

Étendre le schéma des **messages consolidés** entre pipelines pour distinguer les documents « classiques » et ceux **routés vers un pipeline spécialisé**, avec des métadonnées de cible et un indice de comportement legacy.

## Nouveautés API (`pipeline_template`)

### Modèle `SpecializedDocumentItem`

Nouveau modèle Pydantic décrivant un document pris en charge par un pipeline spécialisé :

| Champ | Description |
|--------|-------------|
| `doc_name` | Nom du document |
| `document_type` | Type de document |
| `confidence` | Confiance entre 0.0 et 1.0 |
| `target_pipeline` | Identifiant du pipeline cible |
| `legacy_hint` | `"full"` ou `"skip"` (défaut : `"full"`) — indice pour le traitement legacy |
| `ocr_json_path` | Chemin du JSON OCR associé |

### `ConsolidatedPipelineMessage`

- Nouveau champ optionnel : **`specialized_documents`**, liste de `SpecializedDocumentItem`, vide par défaut (`default_factory=list`).
- Les documents « standards » restent dans **`documents`** (`list[ConsolidatedDocumentItem]`).

### Exports publics

Les symboles suivants sont exportés depuis `cezam_lib.pipeline_template` :

- `ConsolidatedDocumentItem`
- `ConsolidatedPipelineMessage`
- `SpecializedDocumentItem`

(En plus des exports existants : `BasePipeline`, `DataExtractor`, `FusionMessage`, `PipelineMessage`.)

## Qualité et maintenance du dépôt

- **`.gitignore`** : la règle d’exclusion des caches Python a été corrigée (`.pycache/` → `__pycache__/`).
- **Fichiers `.pyc`** : les répertoires `__pycache__/` qui étaient par erreur versionnés ont été retirés de l’index Git (ils ne doivent plus apparaître dans les commits).

## Tests

- Fichier **`tests/test_messages.py`** : tests unitaires sur `SpecializedDocumentItem` et la cohérence des messages consolidés (validation Pydantic, cas limites).
- Mise à jour des tests de structure de package et de la version attendue dans `pyproject.toml`.

## Version du package

La version **0.1.16** est alignée dans :

- `pyproject.toml`
- `src/cezam_lib/__init__.py`
- `src/cezam_lib/cezam_shared/__init__.py`
- `src/cezam_lib/pipeline_template/__init__.py`
- `tests/test_pipeline_config.py`
- `uv.lock`

## Migration pour les consommateurs

1. Mettre à jour la dépendance : `cezam-lib==0.1.16` (ou contrainte équivalente).
2. Si vous sérialisez / désérialisez des **`ConsolidatedPipelineMessage`** :
   - les payloads sans `specialized_documents` restent valides (liste vide par défaut) ;
   - pour les nouveaux flux, renseigner `specialized_documents` selon le routage métier.
3. Importer les types depuis le package template si besoin :

   ```python
   from cezam_lib.pipeline_template import (
       ConsolidatedPipelineMessage,
       SpecializedDocumentItem,
   )
   ```

## Publication

Après fusion de `release/0.1.16` sur la branche suivie par votre CI et création du tag **`v0.1.16`**, la pipeline GitLab peut publier l’artefact sur PyPI comme pour les versions précédentes.
