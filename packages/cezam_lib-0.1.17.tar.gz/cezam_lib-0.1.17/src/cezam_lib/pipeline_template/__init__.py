"""Template de base pour les pipelines spécialisés CEZAM."""

__version__ = "0.1.16"

from .base_pipeline import BasePipeline
from .extractor import DataExtractor
from .messages import (
    ConsolidatedDocumentItem,
    ConsolidatedPipelineMessage,
    FusionMessage,
    PipelineMessage,
    SpecializedDocumentItem,
)

__all__ = [
    "BasePipeline",
    "ConsolidatedDocumentItem",
    "ConsolidatedPipelineMessage",
    "DataExtractor",
    "FusionMessage",
    "PipelineMessage",
    "SpecializedDocumentItem",
]
