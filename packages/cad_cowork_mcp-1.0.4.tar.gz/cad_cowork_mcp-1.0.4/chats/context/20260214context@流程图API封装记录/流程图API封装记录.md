### 前提条件汇总

1、修改老图签名包含【图签】

1、设备位号块的块名更改为【设备位号】，修改对应的块属性名

1、就地仪表块的块名更改为【就地仪表】；集中仪表块的块名更改为【集中仪表】，修改对应的块属性名

1、转管道PL线

要求：仅转为图层名中包含`$ClaudeCAD-GsLcPipeLine`的图层下面的直线






### 图框基点修改

2025-02-05

将图纸里所有流程图图框（块名包含`图框`）的块基点设置为图框的左下角

### 替换图框块

2025-02-05


接着将所有流程图图框（块名包含`图框`）替换为新的图框（块名为`$ClaudeCAD-GsLcDrawFrame`）


### 替换管道文字

2025-02-05


接着将图纸里所有的管道文字替换为`管道块`（块名为`$ClaudeCAD-GsLcPipeNum`）

### 封装技能

仔细阅读整个对话内容，使用skill`@D:\dalong.skills\claude.skills\skill-creator\SKILL.md`创建一个整理流程图的技能（skill）将以下两个操作封装为一个Skill。

整理流程图的技能的技能目前只有这2个操作，后续会不断扩展其他操作，是一个典型的工作流任务。

操作1：修改图框的块基点

操作2：将旧图框替换为新的`claudecad标准图框`。

操作3：替换管道文字为`管道块`


创建的skill放到路径`@D:\dalong.skills\cad-cowork.skill\`下面。

请深度思考后先撰写创建Skill的实施方案供我确认

### 替换设备位号块

2025-02-09

接着使用API命令`api_batch_replace_blocks`将图纸里所有块名为`设备位号`的块替换为`设备块`，其块名为`$ClaudeCAD-GsLcEquipTag`，确保可以继承相同块属性名的值

---

项目`D:\dalong.com\B.MyCreate\01.AI\CAD-CoWork-CsTool`为本项目配套提供API命令服务。
项目`CAD-CoWork-CsTool`里的API命令`api_gslc_tag_text_to_block`是参考项目`D:\dalong.com\B.MyCreate\01.AI\dataflow-cadNet`的功能命令`GsLcTagTextToBlock`，请完成：
1.仔细阅读项目`dataflow-cadNet`里的功能命令`GsLcTagTextToBlock`的实现逻辑，梳理处完整的实现逻辑
2.核对梳理出来的逻辑，检查项目`CAD-CoWork-CsTool`里的API命令`api_gslc_tag_text_to_block`是否实现了相同的逻辑
请先深度思考后再回答！


修改完善API命令`api_gslc_tag_text_to_block`：
1.要替换的7个设备位号块更改为替换为一种claudecad标准设备位号块，块名为`$ClaudeCAD-GsLcEquipTag`
2.取消图层名筛选的条件，这样就不需要用户选择图层名了
3.claudecad标准设备位号块的插入点更改为原版的文字几何范围正中心
请先深度思考后再执行！


### 替换仪表块

2025-02-14


接着使用API命令`api_batch_replace_blocks`将图纸里所有块名为`仪表块`（块名中包含`仪表`的块），替换为claudeCAD标准`仪表块`。如果块属性`功能代号`包含`G`，那么替换为claudeCAD标准`仪表块`的块名为`$ClaudeCAD-GsLcInstrumentL`，否则替换的claudeCAD标准`仪表块`的块名为`$ClaudeCAD-GsLcInstrumentP`
请先深度思考后再执行


增加要求：替换块后确保可以继承相同块属性名的值




更正，claudeCAD标准`仪表块`的块名分别为`$ClaudeCAD-GsLcInstrumentL`和`$ClaudeCAD-GsLcInstrumentP`


项目`D:\dalong.com\B.MyCreate\01.AI\CAD-CoWork-CsTool`为本项目配套提供API命令服务。
使用skill`@D:\dalong.com\B.MyCreate\01.AI\dalong.skills\claude.skills\skill-creator\SKILL.md`迭代优化已有技能（skill）`claudecad-gslc-cleanup`。将刚刚替换`仪表块`的操作增加为`Op4`。
补充：
1.目前只是将业主流程里的设备位号块替换为标准的`仪表块`，后续如果该步骤失败，会继续尝试将流程图里`仪表文字`替换为标准`仪表块`（待后续补充）
2.技能文件`claudecad-gslc-cleanup`中仪表块的块名`GsLcInstrumentL`更改为`$ClaudeCAD-GsLcInstrumentL`；块名`GsLcInstrumentP`更改为`$ClaudeCAD-GsLcInstrumentP`。考虑到兼容性，在项目`CAD-CoWork-CsTool`增加仪表块的常量`$ClaudeCAD-GsLcInstrumentL`和`$ClaudeCAD-GsLcInstrumentP`
请深度思考后再执行

---

项目`D:\dalong.com\B.MyCreate\01.AI\CAD-CoWork-CsTool`为本项目配套提供API命令服务。
项目`CAD-CoWork-CsTool`里的API命令`api_gslc_replace_instrument_block`是参考项目`D:\dalong.com\B.MyCreate\01.AI\dataflow-cadNet`的功能命令`GsLcReplaceInstrumentLBlock`，请完成：
1.仔细阅读项目`dataflow-cadNet`里的功能命令`GsLcReplaceInstrumentLBlock`的实现逻辑，梳理处完整的实现逻辑
2.核对梳理出来的逻辑，检查项目`CAD-CoWork-CsTool`里的API命令`api_gslc_replace_instrument_block`是否实现了相同的逻辑
请先深度思考后再回答！


修改完善API命令`api_gslc_replace_instrument_block`：
2.取消图层名筛选的条件，这样就不需要用户选择图层名了
3.同时替换claudecad标准的就地仪表块和远传仪表块，如图片所示，左侧圆圈外围带正方形的图形替换为远传仪表块，块名为`$ClaudeCAD-GsLcInstrumentP`，右侧只有圆圈的图形替换为就地仪表块，块名为`$ClaudeCAD-GsLcInstrumentL`。根据以上信息构建识别算法。
请先深度思考后再执行！



### 转管道PL线

2025-02-15

新增API命令：批量将直接转为多段线
请深度思考后再执行


将刚刚直接转多段线操作增加为`Op5`。
要求：仅转为图层名中包含`$ClaudeCAD-GsLcPipeLine`的图层下面的直线
请深度思考后再执行
