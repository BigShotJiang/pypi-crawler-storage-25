# 从源头解决互斥参数误报问题 - 实施方案

## 📋 概述

通过在 C# 端扩展元数据模型，在源头标记互斥参数关系，彻底解决 Python 端验证脚本的 26 个误报问题。方案遵循"单一数据源"原则，最小化维护成本。

**问题根源**：
- 验证脚本 `validate_param_consistency.py` 报告 26 个 `name_mismatch` 误报
- 根本原因：不知道 `entityHandle/entityHandles` 是互斥的（二选一），误认为是单复数不匹配
- 当前维护负担：Python 端硬编码 18 条规则，但 C# 端有 29 个命令使用互斥参数

**探索发现**：
- **C# 端**：29 个命令使用互斥参数（主要是 entityHandle/entityHandles 模式）
- **Python 端**：KNOWN_MUTEXES 只覆盖 13 个命令
- **差距**：16 个命令的互斥关系未被识别
- **当前元数据**：无互斥参数字段

---

## 🎯 目标

1. ✅ **消除 26 个误报**：验证脚本识别互斥关系后不再报告 name_mismatch
2. ✅ **单一数据源**：互斥关系只在 C# 端定义一次
3. ✅ **自动化**：无需手动维护 Python 端的 KNOWN_MUTEXES
4. ✅ **向后兼容**：现有 127 个 API 命令正常工作

---

## 🏗️ 架构设计

### 数据流

```
C# 命令定义 (源头真相)
  └─ MutualExclusionGroups: ["entity_input"]
  └─ RecommendedInGroup: true/false
      ↓
ManifestGenerator (导出)
  └─ api_commands_manifest.json
      {
        "mutualExclusionGroups": ["entity_input"],
        "recommendedInGroup": true
      }
      ↓
manifest_parser.py (解析)
  └─ Parameter.mutual_exclusion_groups
      ↓
MutualExclusionDetector (优先使用)
  └─ 自动生成文档 [二选一] 说明
      ↓
ConsistencyValidator (识别互斥)
  └─ 跳过互斥参数，无误报 ✅
```

---

## 📝 实施步骤

### Phase 1: C# 端元数据扩展

#### 1.1 修改 `CommandMetadata.cs`

**文件**: `D:\dalong.com\B.MyCreate\01.AI\CAD-CoWork-CsTool\cowork-cstool\AgentLayer\ApiCommands\Models\CommandMetadata.cs`

**位置**: Line 117-123 (ParameterMetadata 构造函数)

**修改内容**:
```csharp
public class ParameterMetadata
{
    // ... 现有字段保持不变 ...

    /// <summary>
    /// 互斥参数组ID（同一组ID的参数互斥，只能提供其一）
    /// 示例：["entity_input"] 表示与其他标记为 "entity_input" 的参数互斥
    /// </summary>
    public List<string> MutualExclusionGroups { get; set; }

    /// <summary>
    /// 在互斥组中是否为推荐参数
    /// true: 推荐使用（如批量优于单个）
    /// false: 不推荐或无优先级
    /// </summary>
    public bool RecommendedInGroup { get; set; }

    public ParameterMetadata()
    {
        Options = new List<string>();
        Aliases = new List<string>();
        MutualExclusionGroups = new List<string>();  // 新增
        RecommendedInGroup = false;                   // 新增
    }
}
```

#### 1.2 修改 `ManifestGenerator.cs`

**文件**: `D:\dalong.com\B.MyCreate\01.AI\CAD-CoWork-CsTool\cowork-cstool\AgentLayer\ApiCommands\Services\ManifestGenerator.cs`

**位置**: Line 96-107 (参数序列化)

**修改内容**:
```csharp
parameters = m.Parameters?.Select(p => new
{
    name = p.Name,
    displayName = p.DisplayName ?? p.Name,
    description = p.Description ?? "",
    type = p.Type.ToString(),
    required = p.Required,
    defaultValue = p.DefaultValue,
    aliases = p.Aliases?.Count > 0 ? p.Aliases : null,

    // 新增字段（仅在有值时导出）
    mutualExclusionGroups = p.MutualExclusionGroups?.Count > 0
        ? p.MutualExclusionGroups
        : null,
    recommendedInGroup = p.MutualExclusionGroups?.Count > 0
        ? (bool?)p.RecommendedInGroup
        : null
}).ToList(),
```

#### 1.3 Pilot 测试 - 更新 3 个代表性命令

**命令 1**: `ApiMoveEntityCommand.cs` (标准模式)
```csharp
new ParameterMetadata
{
    Name = "entityHandle",
    Type = ParameterType.EntityHandle,
    Required = false,
    MutualExclusionGroups = new List<string> { "entity_input" },
    RecommendedInGroup = false
},
new ParameterMetadata
{
    Name = "entityHandles",
    Type = ParameterType.HandleArray,
    Required = false,
    MutualExclusionGroups = new List<string> { "entity_input" },
    RecommendedInGroup = true  // 批量优先
}
```

**命令 2**: `ApiCreateHatchCommand.cs` (特殊模式)
```csharp
new ParameterMetadata
{
    Name = "boundaryHandles",
    MutualExclusionGroups = new List<string> { "boundary_input" },
    RecommendedInGroup = true  // 边界句柄更精确
},
new ParameterMetadata
{
    Name = "points",
    MutualExclusionGroups = new List<string> { "boundary_input" },
    RecommendedInGroup = false
}
```

**命令 3**: `ApiBatchInsertBlocksCommand.cs` (多组互斥)
```csharp
new ParameterMetadata
{
    Name = "insertions",
    MutualExclusionGroups = new List<string> { "batch_mode", "insert_data" },
    RecommendedInGroup = true
},
new ParameterMetadata
{
    Name = "blockName",
    MutualExclusionGroups = new List<string> { "batch_mode" },
    RecommendedInGroup = false
},
new ParameterMetadata
{
    Name = "insertionPoints",
    MutualExclusionGroups = new List<string> { "insert_data" },
    RecommendedInGroup = false
}
```

---

### Phase 2: Python 端适配

#### 2.1 扩展 `manifest_parser.py`

**文件**: `D:\dalong.com\B.MyCreate\01.AI\CAD-Cowork\mcp-server\scripts\shared\manifest_parser.py`

**位置**: Line 14-21 (Parameter 类)

**修改内容**:
```python
@dataclass
class Parameter:
    """参数定义"""
    name: str
    required: bool
    default_value: Optional[Any] = None
    aliases: List[str] = field(default_factory=list)
    type: Optional[str] = None
    description: Optional[str] = None

    # 新增字段（向后兼容）
    mutual_exclusion_groups: List[str] = field(default_factory=list)
    recommended_in_group: bool = False
```

**位置**: Line 64-84 (解析逻辑)

**修改内容**:
```python
# 在现有参数解析逻辑中添加
mutex_groups = param.get('mutualExclusionGroups', []) or []
recommended = param.get('recommendedInGroup', False)

params_dict[param_name] = Parameter(
    name=param_name,
    required=is_required,
    default_value=default_value,
    aliases=aliases,
    type=param_type,
    description=description,
    mutual_exclusion_groups=mutex_groups,  # 新增
    recommended_in_group=recommended        # 新增
)
```

#### 2.2 更新 `generate_param_table.py`

**文件**: `D:\dalong.com\B.MyCreate\01.AI\CAD-Cowork\mcp-server\scripts\generate_param_table.py`

**位置**: Line 105-128 (MutualExclusionDetector.detect)

**修改内容**:
```python
def detect(self, command: CommandParams, cmd_name: str) -> List[MutuallyExclusiveGroup]:
    """检测互斥参数组（manifest 优先）"""
    groups = []

    # 层0: Manifest 互斥信息（最高优先级，新增）
    manifest_groups = self._detect_from_manifest(command)
    if manifest_groups:
        return manifest_groups  # 有 manifest 数据则直接返回

    # 层1: 静态规则（fallback，保持不变）
    if cmd_name in self.KNOWN_MUTEXES:
        # ... 现有逻辑 ...

    # 层2: 模式匹配（保持不变）
    # ...

    return groups

def _detect_from_manifest(self, command: CommandParams) -> List[MutuallyExclusiveGroup]:
    """从 manifest 提取互斥信息（新增方法）"""
    groups_dict = {}  # {group_id: [param_names]}
    recommended_dict = {}  # {group_id: recommended_param}

    # 遍历所有参数，按组ID聚合
    for param_name, param in command.params.items():
        if not param.mutual_exclusion_groups:
            continue

        for group_id in param.mutual_exclusion_groups:
            if group_id not in groups_dict:
                groups_dict[group_id] = []
            groups_dict[group_id].append(param_name)

            if param.recommended_in_group:
                recommended_dict[group_id] = param_name

    # 转换为 MutuallyExclusiveGroup 对象
    result = []
    for group_id, param_names in groups_dict.items():
        if len(param_names) >= 2:
            result.append(MutuallyExclusiveGroup(
                params=param_names,
                recommended=recommended_dict.get(group_id)
            ))

    return result
```

#### 2.3 修复 `validate_param_consistency.py` (消除误报的关键)

**文件**: `D:\dalong.com\B.MyCreate\01.AI\CAD-Cowork\mcp-server\scripts\validate_param_consistency.py`

**位置**: Line 238-250 (_check_similar_param_names)

**修改内容**:
```python
def _check_similar_param_names(self, cmd_name: str, manifest_params: set, prompt_params: set):
    """检查参数名相似但不完全匹配的情况（如单复数）"""

    # 新增：构建互斥关系集合
    manifest_cmd = self.manifest_parser.get_all_commands().get(cmd_name)
    mutex_pairs = set()

    if manifest_cmd:
        # 从 manifest 提取互斥对
        for param_name, param in manifest_cmd.params.items():
            if not param.mutual_exclusion_groups:
                continue

            for group_id in param.mutual_exclusion_groups:
                # 找到同组的其他参数
                for other_name, other_param in manifest_cmd.params.items():
                    if (other_name != param_name and
                        group_id in other_param.mutual_exclusion_groups):
                        # 添加双向对（排序避免重复）
                        pair = tuple(sorted([param_name, other_name]))
                        mutex_pairs.add(pair)

    # 原有逻辑：检查单复数
    for m_param in manifest_params:
        for p_param in prompt_params:
            # 新增：检查是否是互斥参数
            pair = tuple(sorted([m_param, p_param]))
            if pair in mutex_pairs:
                continue  # ✨ 跳过互斥参数，不报告误报

            # 检查单复数不匹配（原有逻辑）
            if (m_param + 's' == p_param or m_param == p_param + 's'):
                self.issues.append(Issue(
                    severity='ERROR',
                    command=cmd_name,
                    issue_type='name_mismatch',
                    message=f'参数名单复数不匹配...',
                    suggestion=f'统一使用 {m_param}'
                ))
```

---

### Phase 3: 批量更新剩余命令

使用以下模板批量更新剩余 26 个 `entityHandle/entityHandles` 命令：

**受影响的命令**（通过探索确认的 28 个命令）:
1. api_move_entity ✅ (Pilot)
2. api_copy_entity
3. api_rotate_entity
4. api_scale_entity
5. api_mirror_entity
6. api_set_entity_layer
7. api_set_entity_color
8. api_set_entity_properties
9. api_delete_entity
10. api_batch_bring_to_behind
11. api_batch_bring_to_front
12. api_batch_copy
13. api_batch_get_entity_info
14. api_batch_move
15. api_batch_set_attributes
16. api_batch_set_layer
17. api_batch_transform
18. api_calc_bounding_box
19. api_create_block_definition
20. api_get_block_attributes_batch
21. api_get_selection_set
22. api_select_all
23. api_select_by_filter
24. api_select_fence
25. api_select_window
26. api_zoom_object
27. api_export_selection_preview
28. api_window_select_with_filter

**批量修改策略**：
- 在每个命令的 `GetParameterDefinitions()` 中找到 `entityHandle` 和 `entityHandles` 参数
- 添加 `MutualExclusionGroups = new List<string> { "entity_input" }`
- entityHandle: `RecommendedInGroup = false`
- entityHandles: `RecommendedInGroup = true`

---

## ✅ 验证方案

### 1. 编译验证
```bash
cd "D:\dalong.com\B.MyCreate\01.AI\CAD-CoWork-CsTool"
msbuild /t:Build /p:Configuration=Release
# 预期：Build succeeded
```

### 2. Manifest 导出验证
```bash
# 在 AutoCAD 中运行命令
DLApiExportManifest

# 检查互斥字段
jq '.categories[].commands[] | select(.name == "api_move_entity") | .parameters[] | select(.name == "entityHandle")' "%TEMP%\CAD-Cowork\api_commands_manifest.json"

# 预期输出：
# {
#   "name": "entityHandle",
#   "mutualExclusionGroups": ["entity_input"],
#   "recommendedInGroup": false
# }
```

### 3. Python 解析验证
```bash
cd "D:\dalong.com\B.MyCreate\01.AI\CAD-Cowork"
python -c "
from pathlib import Path
from mcp-server.scripts.shared.manifest_parser import ManifestParser
p = ManifestParser(Path('mcp-server/api_commands_manifest.json'))
cmd = p.get_all_commands()['api_move_entity']
print(cmd.params['entityHandle'].mutual_exclusion_groups)
"
# 预期：['entity_input']
```

### 4. 误报消除验证（核心）
```bash
cd "D:\dalong.com\B.MyCreate\01.AI\CAD-Cowork"

# 同步 manifest
.\scripts\sync-manifest.ps1 -AutoFix

# 检查 name_mismatch 数量
python mcp-server\scripts\validate_param_consistency.py 2>&1 | findstr /C:"name_mismatch"

# 预期：无输出（0 个误报）
```

### 5. 端到端测试
```bash
# 完整工作流测试
.\scripts\sync-manifest.ps1 -AutoFix

# 预期输出：
# [Step 2] Validating parameter consistency...
# [SUCCESS] All parameters are consistent ✅
```

---

## 🗂️ 关键文件清单

### C# 端 (CAD-CoWork-CsTool)
- `cowork-cstool/AgentLayer/ApiCommands/Models/CommandMetadata.cs` - 元数据模型定义
- `cowork-cstool/AgentLayer/ApiCommands/Services/ManifestGenerator.cs` - Manifest 导出
- `cowork-cstool/AgentLayer/ApiCommands/Commands/ApiMoveEntityCommand.cs` - Pilot 命令 1
- `cowork-cstool/AgentLayer/ApiCommands/Commands/ApiCreateHatchCommand.cs` - Pilot 命令 2
- `cowork-cstool/AgentLayer/ApiCommands/Commands/ApiBatchInsertBlocksCommand.cs` - Pilot 命令 3

### Python 端 (CAD-Cowork)
- `mcp-server/scripts/shared/manifest_parser.py` - 数据结构定义
- `mcp-server/scripts/generate_param_table.py` - 参数表生成器
- `mcp-server/scripts/validate_param_consistency.py` - 验证器（消除误报的关键）

---

## 🎯 预期成果

1. **误报清零**：26 个 name_mismatch → 0 个
2. **维护简化**：无需手动维护 KNOWN_MUTEXES（18 条规则）
3. **自动化增强**：新命令只需在 C# 端标记一次
4. **文档准确性**：[二选一] 说明自动生成，100% 准确

---

## ⚠️ 风险和注意事项

1. **编译风险**：低（仅新增字段，默认值确保兼容）
2. **运行时风险**：低（Python 端使用 .get() 容错处理）
3. **测试覆盖**：需要在 CAD 环境中测试 manifest 导出
4. **批量修改**：建议使用文本编辑器批量替换功能

---

## 📅 实施时间估算

| 阶段 | 工作内容 | 时间 |
|------|---------|------|
| Phase 1 | C# 元数据扩展 + Pilot 3 个命令 | 1 天 |
| Phase 2 | Python 端适配 + 单元测试 | 1 天 |
| Phase 3 | 批量更新剩余 26 个命令 | 1 天 |
| Phase 4 | 集成测试 + 修复 | 1 天 |
| **总计** | | **4 天** |

---

## 🔄 互斥组命名规范

```
约定：使用 {概念}_{类型} 格式

推荐：
- entity_input     - 实体输入（单个/批量）
- boundary_input   - 边界输入（句柄/点）
- batch_mode       - 批量模式（详细/简化）
- input_source     - 输入源（文件/数据）

避免：
- group1, group2   - 语义不清
- mutex_1          - 缺乏描述性
```

---

## ✨ 额外收益

实施后还会带来：
1. **运行时验证潜力**：MCP Server 可以验证互斥参数冲突
2. **UI 提示增强**：未来可以在界面上高亮互斥参数
3. **测试框架**：自动生成互斥参数的测试用例
4. **API 文档**：自动生成 OpenAPI spec 的 `oneOf` 约束
