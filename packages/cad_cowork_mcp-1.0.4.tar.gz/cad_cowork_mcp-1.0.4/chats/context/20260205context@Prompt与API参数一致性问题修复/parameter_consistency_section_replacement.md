## Parameter Consistency (CRITICAL)

> **Core Principle**: `cad_system_prompt.md` is Agent's ONLY parameter source. Mismatch = API call failure.

### Quick Workflow (Phase 3 Automation)

**After modifying API command parameters in C#**:

1. Rebuild DLL in CAD
2. Run `DLApiExportManifest` in CAD
3. Run `.\scripts\sync-manifest.ps1 -AutoFix` in CAD-Cowork
4. Verify with `python scripts/validate_param_consistency.py`

**This replaces** manual updates to 5 files (cad_system_prompt.md, api_commands_index.md, CLAUDE.md, *.yaml, headers).

**Time saved**: 2-3 hours → 10 seconds

### Common Pitfalls

| Issue | Solution |
|-------|----------|
| **[二选一] parameters** | Use optional column + note below table |
| **Default values** | Mark bool/enum/non-zero (skip null/0/"") |
| **Parameter names** | Use standard name (not aliases) in docs |
| **Return field naming** | Follow Contract-First Principle (see references) |

### Verification Checklist

Before committing, verify C# `GetParameterDefinitions()` matches manifest:

```
□ Parameter names (exact match, case-sensitive)
□ Parameter types (Point3D, String, Double, etc.)
□ Required flags (true/false)
□ Default values
□ Aliases list
□ Options list (for enum-like parameters)
```

**详见**: [references/parameter-consistency.md](references/parameter-consistency.md) for:
- Phase 3 automation tools and workflow
- Contract-First Principle and Return Field Naming
- Mutual exclusion detection patterns (21 known patterns)
- Common inconsistency patterns
- Troubleshooting guide
