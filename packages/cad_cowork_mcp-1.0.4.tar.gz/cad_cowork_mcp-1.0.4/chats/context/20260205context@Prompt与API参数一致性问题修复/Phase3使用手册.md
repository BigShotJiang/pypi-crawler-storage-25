# Phase 3: API 参数表自动生成 - 使用手册

**版本**: 1.0
**更新日期**: 2026-02-06
**适用人员**: CAD-Cowork 项目维护者、API 命令开发者

---

## 📋 目录

- [1. 概述](#1-概述)
- [2. 使用场景](#2-使用场景)
- [3. 工具清单](#3-工具清单)
- [4. 快速开始](#4-快速开始)
- [5. 详细操作指南](#5-详细操作指南)
- [6. 常见问题](#6-常见问题)
- [7. 故障排除](#7-故障排除)
- [8. 高级用法](#8-高级用法)

---

## 1. 概述

### 1.1 Phase 3 是什么？

Phase 3 实现了从 `api_commands_manifest.json` 自动生成 Agent 参数速查表的完整自动化流程，确保参数文档与代码定义始终保持一致。

### 1.2 解决的问题

**之前**：
- ❌ 手动维护 `cad_system_prompt.md` 中的参数表格
- ❌ 参数修改后容易遗漏文档更新
- ❌ 存在 82 个参数不一致问题（准确率仅 51%）
- ❌ 新增命令需同步修改多处

**现在**：
- ✅ 一键自动生成所有参数表格
- ✅ 从单一数据源（manifest.json）生成文档
- ✅ 参数准确率 100%
- ✅ 新增命令后自动同步文档

### 1.3 核心功能

| 功能 | 说明 |
|------|------|
| **自动生成** | 从 manifest.json 生成 87 个命令的参数表格 |
| **互斥检测** | 自动识别 [二选一] 参数（如 entityHandle/entityHandles） |
| **默认值标注** | 智能标注默认值（如 createIfNotExist(默认true)） |
| **参数验证** | 检测文档与 manifest 的参数不一致 |
| **区域保护** | 保留手动说明，只更新表格部分 |

---

## 2. 使用场景

### 场景 1：新增 API 命令

```
开发者在 cad-cowork-cstool 中新增了命令 →
需要更新 Agent 文档
```

**解决方案**: 使用自动同步工作流（见 [4.1](#41-自动同步工作流)）

### 场景 2：修改命令参数

```
修改了 api_draw_circle 的参数定义 →
文档中的参数说明需要同步
```

**解决方案**: 运行 `sync-manifest.ps1 -AutoFix`

### 场景 3：验证参数一致性

```
怀疑文档与代码不一致 →
需要检查所有命令的参数
```

**解决方案**: 运行验证脚本（见 [5.2](#52-参数验证)）

### 场景 4：手动微调表格

```
需要调整某个命令的说明文字 →
但不想影响自动生成
```

**解决方案**: 使用区域标记机制（见 [8.1](#81-理解区域标记)）

---

## 3. 工具清单

### 3.1 核心脚本

| 脚本 | 位置 | 用途 |
|------|------|------|
| **sync-manifest.ps1** | `scripts/` | 自动同步工作流（推荐入口） |
| **generate_param_table.py** | `mcp-server/scripts/` | 生成参数表格 |
| **validate_param_consistency.py** | `mcp-server/scripts/` | 验证参数一致性 |
| **add_region_markers.py** | `mcp-server/scripts/` | 添加区域标记（一次性） |

### 3.2 辅助模块

| 模块 | 位置 | 说明 |
|------|------|------|
| **shared/manifest_parser.py** | `mcp-server/scripts/shared/` | 共享解析器 |

### 3.3 关键文件

| 文件 | 位置 | 角色 |
|------|------|------|
| **api_commands_manifest.json** | `mcp-server/` | 参数定义权威来源 |
| **cad_system_prompt.md** | `mcp-server/prompts/` | Agent 参数速查表 |

---

## 4. 快速开始

### 4.1 自动同步工作流

这是**最常用的操作**，适用于 95% 的场景。

#### 前置条件

1. 在 CAD 中运行 `DLApiExportManifest` 导出最新 manifest
2. 确保导出文件位于 `%TEMP%\CAD-Cowork\api_commands_manifest.json`

#### 操作步骤

```powershell
# 打开 PowerShell（项目根目录）
cd D:\dalong.com\B.MyCreate\01.AI\CAD-Cowork

# 运行自动同步（自动修复模式）
.\scripts\sync-manifest.ps1 -AutoFix
```

#### 执行流程

```
[Step 1] 复制 manifest.json ✓
[Step 2] 验证参数一致性
         ├─ 发现 8 处不一致
         └─ 准备自动修复...
[Step 3] 生成参数表格
         ├─ 绘图类 (10 commands) ✓
         ├─ 修改类 (11 commands) ✓
         ├─ ...
         └─ 更新完成 ✓
[Step 4] 再次验证
         └─ 全部一致 ✓
```

#### 预期结果

- ✅ `mcp-server/api_commands_manifest.json` 已更新
- ✅ `mcp-server/prompts/cad_system_prompt.md` 参数表格已自动生成
- ✅ 所有参数与 manifest 一致

---

### 4.2 仅验证模式

不修改文件，只检查是否存在不一致。

```powershell
.\scripts\sync-manifest.ps1 -ValidateOnly
```

**输出示例**：
```
[WARNING] Parameter inconsistencies detected:
          - 8 ERROR(s)
          - 3 WARNING(s)

Run with -AutoFix to automatically update parameter tables
```

---

## 5. 详细操作指南

### 5.1 生成参数表格

#### 预览模式（不写文件）

```bash
cd mcp-server
python scripts/generate_param_table.py --preview
```

**用途**：查看生成结果，确认无误后再更新。

#### 更新模式（直接写文件）

```bash
python scripts/generate_param_table.py --update
```

**输出示例**：
```
[INFO] Generating parameter tables...
  ✓ 绘图类 (10 commands)
  ✓ 修改类 (11 commands)
  ✓ 批量类 (8 commands)
  ✓ 查询类 (16 commands)
  ✓ 块操作类 (8 commands)
  ✓ 图层类 (7 commands)
  ✓ 空间计算类 (8 commands)
  ✓ 文档管理类 (4 commands)
  ✓ 视图控制类 (5 commands)
  ✓ 选择集类 (7 commands)
  ✓ 事务控制类 (3 commands)

[SUCCESS] Updated mcp-server/prompts/cad_system_prompt.md
```

---

### 5.2 参数验证

#### 基础验证

```bash
cd mcp-server
python scripts/validate_param_consistency.py
```

**输出示例**：
```
=== Validation Report ===

[ERROR] api_move_entity (line 245)
  - frameHandle: 文档标记为必需，实际为可选

[WARNING] api_query_by_attribute (line 256)
  - matchMode 未标注默认值 (默认: 0)

Total: 2 ERROR, 1 WARNING, 0 INFO
```

#### JSON 格式输出

```bash
python scripts/validate_param_consistency.py --format json --output report.json
```

**用途**：便于脚本解析和自动化处理。

---

### 5.3 添加区域标记

**注意**：这是一次性操作，通常只在初始化时使用。

```bash
cd mcp-server
python scripts/add_region_markers.py
```

**功能**：为文档中的 11 个分节添加自动生成标记。

**示例**：
```markdown
<!-- AUTO_GENERATED_SECTION_START: 绘图类 -->
### 绘图类
| 命令 | 必需参数 | 可选参数 |
|------|----------|----------|
| ... 自动生成的表格 ... |
<!-- AUTO_GENERATED_SECTION_END: 绘图类 -->

> [二选一] boundaryHandles（推荐）或 points
```

---

## 6. 常见问题

### Q1: 为什么验证脚本报告 26 个 name_mismatch 误报？

**答**：验证脚本无法识别 `[二选一]` 参数模式，导致误报。这些误报**不影响功能**，文档内容是正确的。

**示例**：
```markdown
| api_create_hatch | - | boundaryHandles, points |
> [二选一] boundaryHandles（推荐）或 points
```

验证脚本会报告"boundaryHandles 和 points 不在同一列"，但这是预期的写法。

**解决方案**：忽略这些误报，或等待验证脚本增强（未来改进）。

---

### Q2: 手动添加的说明会被覆盖吗？

**答**：不会。区域标记机制确保只更新表格部分，手动说明保留在标记外。

**安全区域**（不会被覆盖）：
```markdown
<!-- AUTO_GENERATED_SECTION_END: 绘图类 -->

> [二选一] boundaryHandles（推荐）或 points
> **注意**：使用 points 时需确保点集构成闭合路径
```

---

### Q3: 新增命令后如何同步？

**答**：
1. 在 cad-cowork-cstool 中实现命令
2. 运行 CAD 命令 `DLApiExportManifest`
3. 运行 `.\scripts\sync-manifest.ps1 -AutoFix`

**自动完成**：
- ✅ manifest.json 更新
- ✅ 参数验证
- ✅ 表格生成
- ✅ 再次验证

---

### Q4: 如何自定义默认值显示规则？

**答**：编辑 `generate_param_table.py` 中的 `DefaultValueFormatter` 类。

**当前规则**：
```python
def should_show_default(param: Parameter) -> bool:
    # null/0/空字符串不显示
    if param.default_value in [None, 0, 0.0, "", "null"]:
        return False

    # 布尔型、枚举型、非零数值显示
    return True
```

**示例**：
- `createIfNotExist: true` → `createIfNotExist(默认true)` ✅
- `colorIndex: 256` → `colorIndex(默认256)` ✅
- `layerName: "0"` → `layerName(默认0)` ✅
- `rotation: 0` → `rotation` ❌（不显示）

---

### Q5: 如何添加新的互斥参数检测规则？

**答**：编辑 `generate_param_table.py` 中的 `MutualExclusionDetector.KNOWN_MUTEXES`。

**示例**：
```python
KNOWN_MUTEXES = {
    'api_move_entity': [('entityHandle', 'entityHandles')],
    'api_create_hatch': [('boundaryHandles', 'points')],

    # 添加新规则
    'api_your_command': [
        ('param1', 'param2'),  # 第一组互斥
        ('param3', 'param4'),  # 第二组互斥
    ],
}
```

---

## 7. 故障排除

### 7.1 错误：Source file not found

**现象**：
```
[ERROR] Source file not found: C:\Users\...\Temp\CAD-Cowork\api_commands_manifest.json
```

**原因**：未在 CAD 中运行导出命令。

**解决**：
1. 打开 AutoCAD/浩辰 CAD/中望 CAD
2. 运行命令 `DLApiExportManifest`
3. 确认导出成功提示
4. 重新运行 `sync-manifest.ps1`

---

### 7.2 错误：Destination is up to date

**现象**：
```
[INFO] Destination is up to date, no sync needed
```

**原因**：目标文件比源文件新（可能手动修改过）。

**解决**：
```powershell
# 强制同步
.\scripts\sync-manifest.ps1 -Force -AutoFix
```

---

### 7.3 警告：Missing region markers

**现象**：
```
[WARNING] No region marker found for section: 绘图类
```

**原因**：文档缺少自动生成标记。

**解决**：
```bash
cd mcp-server
python scripts/add_region_markers.py
```

---

### 7.4 错误：Invalid JSON format

**现象**：
```
[ERROR] Invalid JSON format: Expecting value: line 1 column 1
```

**原因**：manifest.json 文件损坏或格式错误。

**解决**：
1. 删除损坏的文件
2. 重新运行 CAD 导出命令
3. 使用 JSON 校验工具检查文件

---

### 7.5 Python 模块导入错误

**现象**：
```
ModuleNotFoundError: No module named 'shared.manifest_parser'
```

**原因**：Python 路径未正确设置。

**解决**：
```bash
# 确保在 mcp-server 目录运行
cd mcp-server
python scripts/generate_param_table.py --update

# 或使用绝对路径
python D:\dalong.com\B.MyCreate\01.AI\CAD-Cowork\mcp-server\scripts\generate_param_table.py --update
```

---

## 8. 高级用法

### 8.1 理解区域标记

区域标记定义了自动生成的边界：

```markdown
<!-- AUTO_GENERATED_SECTION_START: 绘图类 -->
这里的内容会被自动生成覆盖
可以安全删除或忽略
<!-- AUTO_GENERATED_SECTION_END: 绘图类 -->

这里的内容不会被覆盖
可以添加手动说明、示例等
```

**规则**：
- ✅ 标记内：由脚本自动维护，不要手动编辑
- ✅ 标记外：手动维护，不会被覆盖
- ✅ 无标记：追加到文档末尾（新分节）

---

### 8.2 自定义类别映射

编辑 `generate_param_table.py` 中的 `CategoryMapper.CATEGORY_MAPPING`：

```python
CATEGORY_MAPPING = {
    # manifest 类别 → 文档分组名
    "drawing": "绘图类",
    "query": "查询类",

    # 支持中文类别名
    "图层": "图层类",
    "文档": "文档管理类",

    # 添加新类别
    "your_category": "自定义类",

    # GsLc 不在速查表中
    "gslc": None,
}
```

---

### 8.3 批量验证多个文件

```bash
# 验证 manifest 完整性
cd mcp-server
pytest tests/unit/test_api_manifest.py -v

# 验证参数一致性
python scripts/validate_param_consistency.py

# 验证生成逻辑
pytest tests/unit/test_param_table_generation.py -v
```

---

### 8.4 集成到 CI/CD

**GitHub Actions 示例**：

```yaml
name: Validate API Parameters

on: [push, pull_request]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.10'

      - name: Validate parameters
        run: |
          cd mcp-server
          python scripts/validate_param_consistency.py

      - name: Run unit tests
        run: |
          cd mcp-server
          pytest tests/unit/test_param_table_generation.py -v
```

---

### 8.5 手动调整生成逻辑

**场景**：需要特殊处理某个命令的参数显示。

**方法**：编辑 `ParameterTableGenerator.generate()` 方法。

**示例**：为特定命令添加备注
```python
def generate(self) -> Dict[str, TableSection]:
    # ... 现有逻辑 ...

    # 为 api_create_hatch 添加特殊处理
    if cmd_name == 'api_create_hatch':
        row.optional_params.append(
            ('patternName', '默认SOLID（实心填充）')
        )

    # ... 继续处理 ...
```

---

## 9. 维护建议

### 9.1 定期验证

**建议频率**：每次修改 API 命令后

```bash
# 开发流程
1. 修改 cad-cowork-cstool 代码
2. 编译并测试
3. 运行 DLApiExportManifest
4. 运行 sync-manifest.ps1 -AutoFix
5. Git commit 包含文档更新
```

---

### 9.2 版本控制

**建议**：
- ✅ 提交 `api_commands_manifest.json` 到 Git
- ✅ 提交 `cad_system_prompt.md` 到 Git
- ❌ 不提交临时文件（`param_report_*.json`）

---

### 9.3 文档审查

**定期检查**：
1. 验证脚本报告无 ERROR（忽略 name_mismatch 误报）
2. 手动说明是否需要更新
3. 新命令是否有使用示例
4. 互斥参数规则是否完整

---

## 10. 参考资料

### 10.1 相关文档

| 文档 | 位置 |
|------|------|
| API 参数一致性维护指南 | `mcp-server/docs/API参数一致性维护指南.md` |
| Phase 3 完成总结 | `phase3_summary.md` |
| 实施计划 | `.claude/plans/cached-painting-moon.md` |

### 10.2 关键概念

- **单一数据源**：manifest.json 是参数定义的唯一权威来源
- **区域标记**：保护手动内容，只更新自动生成部分
- **互斥参数**：如 entityHandle/entityHandles（单个/批量操作）
- **默认值标注**：布尔型、枚举型、非零数值需标注

### 10.3 联系方式

**遇到问题？**
1. 查看本手册的 [故障排除](#7-故障排除) 章节
2. 运行单元测试确认系统正常
3. 查阅源代码注释

---

**文档版本**: 1.0
**最后更新**: 2026-02-06
**维护者**: CAD-Cowork 项目组
