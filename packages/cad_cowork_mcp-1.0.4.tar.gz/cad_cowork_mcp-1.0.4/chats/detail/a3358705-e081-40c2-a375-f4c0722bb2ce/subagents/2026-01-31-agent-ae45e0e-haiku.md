# SubAgent 对话记录 (haiku)

> 项目: CAD-Cowork
> Session: a3358705-e081-40c2-a375-f4c0722bb2ce

---

## 👤 User [17:54:55]

我需要了解 CAD-MCP 的 MCP server 实现架构，以便设计一个新的路由工具。

请重点探索：
1. `mcp-server/server.py` - 主服务文件，了解现有工具是如何定义的
2. 现有工具的实现模式（如 smart_cad_command, list_api_commands, get_api_command_info）
3. 如何加载 api_commands_manifest.json
4. 工具的参数定义和返回值格式

请提供详细的代码结构分析，包括：
- 工具注册方式
- 参数验证方式
- 返回值格式
- 与 CAD 通信的方式

这是只读探索任务，不要修改任何文件。

---

## 🤖 Assistant [17:54:58]

我来帮你探索 CAD-MCP 的 MCP server 实现架构。让我从关键文件开始深入分析。

---

## 🤖 Assistant [17:54:59]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server"
}
```

❌ Error:

```
EISDIR: illegal operation on a directory, read
```

---

## 🤖 Assistant [17:54:59]

### 🔧 Glob

```json
{
  "pattern": "mcp-server/**/*.py"
}
```

❌ Error:

```
<tool_use_error>Sibling tool call errored</tool_use_error>
```

---

## 🤖 Assistant [17:55:00]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/server.py"
}
```

❌ Error:

```
<tool_use_error>Sibling tool call errored</tool_use_error>
```

---

## 🤖 Assistant [17:55:02]

Let me correct my approach and search properly:

---

## 🤖 Assistant [17:55:02]

### 🔧 Bash

```json
{
  "command": "find /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server -type f -name \"*.py\" | head -20"
}
```

📤 Result:

```
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/batch_executor.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/nlp_processor.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/server.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/tests/conftest.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/tests/fixtures/sample_data.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/tests/fixtures/__init__.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/tests/integration/test_cad_connection.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/tests/integration/test_smart_cad_command.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/tests/integration/__init__.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/tests/mocks/cad_mock.py
/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/tests/mocks/__init__.py
/mnt/d/dalong.c...(truncated)
```

---

## 🤖 Assistant [17:55:03]

### 🔧 Bash

```json
{
  "command": "ls -la /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/"
}
```

📤 Result:

```
total 356
drwxrwxrwx 1 dalong0514 dalong0514   4096 Jan 31 17:23 .
drwxrwxrwx 1 dalong0514 dalong0514   4096 Jan 31 17:23 ..
drwxrwxrwx 1 dalong0514 dalong0514   4096 Jan 25 10:19 .pytest_cache
-rwxrwxrwx 1 dalong0514 dalong0514   1244 Jan 24 11:10 __init__.py
drwxrwxrwx 1 dalong0514 dalong0514   4096 Jan 31 15:11 __pycache__
-rwxrwxrwx 1 dalong0514 dalong0514  10468 Jan 31 17:23 api_commands_index.md
-rwxrwxrwx 1 dalong0514 dalong0514 209929 Jan 31 17:20 api_commands_manifest.json
-rwxrwxrwx 1 dalong0514 dalong0514  22549 Jan 31 10:07 batch_executor.py
-rwxrwxrwx 1 dalong0514 dalong0514  44926 Jan 31 09:24 cad_controller.py
-rwxrwxrwx 1 dalong0514 dalong0514      0 Jan 25 10:19 cad_mcp.log
-rwxrwxrwx 1 dalong0514 dalong0514    301 Jan 24 11:10 config.json
-rwxrwxrwx 1 dalong0514 dalong0514  19041 Jan 24 11:10 nlp_processor.py
drwxrwxrwx 1 dalong0514 dalong0514   4096 Jan 31 17:24 prompts
-rwxrwxrwx 1 dalong0514 dalong0514    621 Jan 26 22:36 pytest.ini
-rwxrwxrwx 1 dalong0514 dalong05...(truncated)
```

---

## 🤖 Assistant [17:55:05]

Now let me read the main server file and related modules:

---

## 🤖 Assistant [17:55:05]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/server.py"
}
```

📤 Result:

```
     1→import os
     2→import sys
     3→import json
     4→import logging
     5→from pathlib import Path
     6→from mcp.server.models import InitializationOptions
     7→import mcp.types as types
     8→from mcp.server import NotificationOptions, Server
     9→import mcp.server.stdio
    10→from pydantic import AnyUrl
    11→from typing import Any, Dict, List
    12→import sys
    13→
    14→sys.dont_write_bytecode = True
    15→
    16→# 使用绝对导入
    17→
    18→from nlp_processor import NLPProcessor
    19→from cad_controller import CADController
    20→from batch_executor import BatchExecutor
    21→
    22→
    23→# 配置Windows环境下的UTF-8编码
    24→# 注意: pytest 会替换 sys.stdin，所以需要检查 reconfigure 方法是否存在
    25→if sys.platform == "win32" and os.environ.get('PYTHONIOENCODING') is None:
    26→    if hasattr(sys.stdin, 'reconfigure'):
    27→        sys.stdin.reconfigure(encoding="utf-8")
    28→    if hasattr(sys.stdout, 'reconfigure'):
    29→        sys.stdout.reconfigure(encoding="utf-8"...(truncated)
```

---

## 🤖 Assistant [17:55:06]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py",
  "limit": 100
}
```

📤 Result:

```
     1→import logging
     2→import math
     3→import time
     4→import os
     5→import json
     6→import tempfile
     7→from typing import Any, Dict, List, Optional, Tuple, Union
     8→
     9→# 直接读取config.json文件
    10→config_path = os.path.join(os.path.dirname(__file__), 'config.json')
    11→with open(config_path, 'r', encoding='utf-8') as f:
    12→    config = json.load(f)
    13→
    14→try:
    15→    import win32com.client
    16→    # pythoncom是pywin32的一部分，不需要单独安装
    17→    import pythoncom
    18→except ImportError:
    19→    logging.error("无法导入win32com.client或pythoncom，请确保已安装pywin32库")
    20→    raise
    21→
    22→logger = logging.getLogger('cad_controller')
    23→
    24→class CADController:
    25→    """CAD控制器类，负责与CAD应用程序交互"""
    26→    
    27→    def __init__(self):
    28→        """初始化CAD控制器"""
    29→        self.app = None
    30→        self.doc = None
    31→        self.entities = {}  # 存储已创建图形的实体引用，用于后续修改
    32→        # 从配置文件加载参数
    33→        s...(truncated)
```

---

## 🤖 Assistant [17:55:06]

### 🔧 Bash

```json
{
  "command": "head -100 /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/api_commands_manifest.json"
}
```

📤 Result:

```
﻿{
  "version": "2.0.0",
  "generatedAt": "2026-01-31 17:20:17",
  "totalCommands": 119,
  "categories": [
    {
      "name": "绘图-基础",
      "nameEn": "drawing",
      "count": 10,
      "commands": [
        {
          "name": "api_create_arc",
          "displayName": "创建圆弧",
          "description": "创建圆弧实体，通过圆心、半径和起止角度定义",
          "parameters": [
            {
              "name": "center",
              "displayName": "圆心",
              "description": "圆弧圆心坐标 [x, y, z]",
              "type": "Point3D",
              "required": true,
              "defaultValue": null,
              "aliases": null
            },
            {
              "name": "radius",
              "displayName": "半径",
              "description": "圆弧半径",
              "type": "Double",
              "required": true,
              "defaultValue": null,
              "aliases": null
            },
            {
              "name": "startAngle",
              "disp...(truncated)
```

---

## 🤖 Assistant [17:55:09]

Great! Now let me explore more about the CADController implementation, batch executor, and the manifest structure:

---

## 🤖 Assistant [17:55:10]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py",
  "offset": 100,
  "limit": 200
}
```

📤 Result:

```
   100→                                pass
   101→                        
   102→                        # 创建新文档
   103→                        self.doc = self.app.Documents.Add()
   104→                    except Exception as new_doc_ex:
   105→                        logger.error(f"创建新文档失败: {str(new_doc_ex)}")
   106→                        raise
   107→                    
   108→            except Exception as app_ex:
   109→                # 如果连接失败，启动一个新实例
   110→                logger.info(f"连接失败，正在启动新的CAD实例: {str(app_ex)}")
   111→                try:
   112→                    # 根据配置的CAD类型启动相应的应用程序
   113→                    app_id = "AutoCAD.Application"
   114→                    app_name = "AutoCAD"
   115→                    
   116→                    if self.cad_type.lower() == "autocad":
   117→                        app_id = "AutoCAD.Application"
   118→                        app_name = "AutoCAD"
   119→                    elif self.cad_type.lower() == "gcad":
   12...(truncated)
```

---

## 🤖 Assistant [17:55:11]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/batch_executor.py",
  "limit": 150
}
```

📤 Result:

```
     1→"""
     2→批量命令执行器
     3→
     4→支持 DAG 依赖管理和参数引用传递，用于一次性执行多个 API 命令。
     5→"""
     6→
     7→import re
     8→import logging
     9→import time
    10→from typing import Any, Dict, List, Optional, Tuple
    11→from collections import defaultdict
    12→
    13→logger = logging.getLogger('batch_executor')
    14→
    15→
    16→class BatchExecutionError(Exception):
    17→    """批量执行错误"""
    18→    pass
    19→
    20→
    21→class CyclicDependencyError(BatchExecutionError):
    22→    """循环依赖错误"""
    23→    pass
    24→
    25→
    26→class ReferenceResolutionError(BatchExecutionError):
    27→    """引用解析错误"""
    28→    pass
    29→
    30→
    31→class BatchExecutor:
    32→    """批量命令执行器，支持 DAG 依赖和参数传递"""
    33→
    34→    # 引用语法正则：${cmd_id.field.path} 或 ${cmd_id.array[0]}
    35→    REFERENCE_PATTERN = re.compile(r'\$\{([^}]+)\}')
    36→
    37→    def __init__(self, cad_controller):
    38→        """
    39→        初始化批量执行器
    40→
    41→        Args:
    42→     ...(truncated)
```

---

## 🤖 Assistant [17:55:11]

### 🔧 Bash

```json
{
  "command": "head -200 /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/api_commands_manifest.json | tail -100"
}
```

📤 Result:

```
              "aliases": [
                "start_point"
              ]
            },
            {
              "name": "point2",
              "displayName": "第二点",
              "description": "第二个定义点 [x, y, z]（角度标注时为第二条线的端点）",
              "type": "Point3D",
              "required": false,
              "defaultValue": null,
              "aliases": [
                "end_point"
              ]
            },
            {
              "name": "point3",
              "displayName": "第三点",
              "description": "角度标注时的角点 [x, y, z]",
              "type": "Point3D",
              "required": false,
              "defaultValue": null,
              "aliases": null
            },
            {
              "name": "dimLinePoint",
              "displayName": "文字位置",
              "description": "标注文字位置 [x, y, z]",
              "type": "Point3D",
              "required": true,
              "defaultValue": null,
              "aliases": [
...(truncated)
```

---

## 🤖 Assistant [17:55:13]

Let me continue exploring the batch executor and check more of the CADController implementation:

---

## 🤖 Assistant [17:55:14]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/batch_executor.py",
  "offset": 150,
  "limit": 200
}
```

📤 Result:

```
   150→            depends_on = cmd.get("depends_on", [])
   151→
   152→            # 检查依赖是否都成功
   153→            dependency_failed = False
   154→            for dep_id in depends_on:
   155→                if dep_id in self.results and not self.results[dep_id].get("success", False):
   156→                    dependency_failed = True
   157→                    break
   158→
   159→            if dependency_failed:
   160→                result = {
   161→                    "id": cmd_id,
   162→                    "command_name": cmd_name,
   163→                    "success": False,
   164→                    "message": f"依赖命令失败，跳过执行",
   165→                    "handle": None,
   166→                    "data": None,
   167→                    "execution_time_ms": 0
   168→                }
   169→                self.results[cmd_id] = result
   170→                results_list.append(result)
   171→                failed_commands.append({"id": cmd_id, "reason": "依赖命令失败"})
   172...(truncated)
```

---

## 🤖 Assistant [17:55:15]

### 🔧 Bash

```json
{
  "command": "grep -n \"execute_api_command\\|smart_cad_command\\|get_api_commands_metadata\\|get_api_command_info\" /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py | head -20"
}
```

📤 Result:

```
799:    def execute_api_command(self, command_name: str, parameters: Dict[str, Any] = None,
814:        return self._execute_api_command_once(command_name, parameters, timeout)
816:    def _execute_api_command_once(self, command_name: str, parameters: Dict[str, Any] = None,
927:    def get_api_commands_metadata(self) -> Dict[str, Any]:
970:    def get_api_command_info(self, command_name: str) -> Dict[str, Any]:
987:            all_commands = self.get_api_commands_metadata()
1009:    def smart_cad_command(self, command_name: str, parameters: Dict[str, Any] = None,
1043:            result = self.execute_api_command(command_name, parameters or {}, timeout)
```

---

## 🤖 Assistant [17:55:15]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py",
  "offset": 850,
  "limit": 150
}
```

📤 Result:

```
   850→            result_path = self._get_api_result_path()
   851→            if os.path.exists(result_path):
   852→                try:
   853→                    os.remove(result_path)
   854→                    logger.debug(f"[API] 已删除旧结果文件")
   855→                except Exception as e:
   856→                    logger.warning(f"[API] 删除旧结果文件失败: {e}")
   857→
   858→            # 写入请求文件
   859→            request_path = self._get_api_request_path()
   860→            with open(request_path, 'w', encoding='utf-8') as f:
   861→                json.dump(request, f, ensure_ascii=False, indent=2)
   862→                f.flush()  # 强制刷新缓冲区
   863→                os.fsync(f.fileno())  # 强制写入磁盘
   864→
   865→            logger.info(f"[API] 写入请求: {command_name}, RequestId: {request_id}")
   866→
   867→            # 等待文件系统同步（Windows 文件系统缓存问题）
   868→            time.sleep(0.03)  # 30ms，已通过 fsync 强制写入
   869→
   870→            # 调用 DLApiExecute 命令
   871→            self.doc.SendComm...(truncated)
```

---

## 🤖 Assistant [17:55:17]

Now let me check the smart_cad_command implementation and understand the overall architecture better:

---

## 🤖 Assistant [17:55:19]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py",
  "offset": 1009,
  "limit": 150
}
```

📤 Result:

```
  1009→    def smart_cad_command(self, command_name: str, parameters: Dict[str, Any] = None,
  1010→                          need_result: bool = None, timeout: float = 10.0) -> Dict[str, Any]:
  1011→        """智能执行 CAD 命令
  1012→
  1013→        自动判断使用 SendCommand（简单命令）或 API Layer（复杂命令）：
  1014→        1. need_result=True 显式指定 → API Layer
  1015→        2. need_result=False 显式指定 → SendCommand
  1016→        3. need_result=None 自动推断：
  1017→           - 命令以 api_ 开头 → API Layer
  1018→           - 参数包含复杂对象（列表/字典）→ API Layer
  1019→           - 命令在 FSD_CAD_COMMANDS 中 → SendCommand
  1020→           - 其他情况 → 尝试 API Layer
  1021→
  1022→        Args:
  1023→            command_name: 命令名称（可以是 cstool 命令或 API 命令）
  1024→            parameters: 命令参数字典（可选）
  1025→            need_result: 是否需要返回结果（如实体 Handle）。None 表示自动判断
  1026→            timeout: 超时时间（秒），默认 10 秒
  1027→
  1028→        Returns:
  1029→            dict: 执行结果，包含 success, message, data 等字段
  1030→        """
  1031→        if not ...(truncated)
```

---

## 🤖 Assistant [17:55:19]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py",
  "offset": 799,
  "limit": 100
}
```

📤 Result:

```
   799→    def execute_api_command(self, command_name: str, parameters: Dict[str, Any] = None,
   800→                           timeout: float = 10.0) -> Dict[str, Any]:
   801→        """执行 cad-cowork-cstool API 命令（快速失败，不自动重试）
   802→
   803→        采用快速失败策略：超时直接返回错误，由 Agent 层决定是否重试。
   804→
   805→        Args:
   806→            command_name: API 命令名称，如 "api_draw_line", "api_draw_circle"
   807→            parameters: 命令参数字典
   808→            timeout: 等待结果的超时时间（秒），默认 10 秒
   809→
   810→        Returns:
   811→            dict: API 执行结果，包含 success, message, data 等字段
   812→        """
   813→        # 快速失败：不自动重试，超时直接返回
   814→        return self._execute_api_command_once(command_name, parameters, timeout)
   815→
   816→    def _execute_api_command_once(self, command_name: str, parameters: Dict[str, Any] = None,
   817→                                  timeout: float = 10.0) -> Dict[str, Any]:
   818→        """执行单次 API 命令（内部方法）
   819→
   820→        通过写入 request.json，调用 DLApiExe...(truncated)
```

---

## 🤖 Assistant [17:55:19]

### 🔧 Bash

```json
{
  "command": "wc -l /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py"
}
```

📤 Result:

```
1111 /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py
```

---

## 🤖 Assistant [17:55:21]

Now let me check the API manifest structure and some helper methods:

---

## 🤖 Assistant [17:55:22]

### 🔧 Bash

```json
{
  "command": "grep -n \"_normalize_result\\|_get_api_request_path\\|_get_api_result_path\\|_ensure_api_dirs\" /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py"
}
```

📤 Result:

```
762:    def _get_api_request_path(self) -> str:
766:    def _get_api_result_path(self) -> str:
770:    def _ensure_api_dirs(self) -> None:
776:    def _normalize_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
834:            self._ensure_api_dirs()
850:            result_path = self._get_api_result_path()
859:            request_path = self._get_api_request_path()
897:                            return self._normalize_result(result)
939:            self._ensure_api_dirs()
983:            self._ensure_api_dirs()
```

---

## 🤖 Assistant [17:55:22]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py",
  "offset": 1060,
  "limit": 50
}
```

📤 Result:

```
  1060→            need_result: 用户显式指定是否需要返回值
  1061→
  1062→        Returns:
  1063→            bool: True 使用 API Layer，False 使用 SendCommand
  1064→        """
  1065→        # 1. 显式指定
  1066→        if need_result is True:
  1067→            logger.debug(f"[智能路由] need_result=True，使用 API Layer")
  1068→            return True
  1069→        if need_result is False:
  1070→            logger.debug(f"[智能路由] need_result=False，使用 SendCommand")
  1071→            return False
  1072→
  1073→        # 2. 自动推断
  1074→        # 2.1 命令名以 api_ 开头
  1075→        if command_name.lower().startswith("api_"):
  1076→            logger.debug(f"[智能路由] 命令名以 api_ 开头，使用 API Layer")
  1077→            return True
  1078→
  1079→        # 2.2 参数包含复杂对象（列表、嵌套字典）
  1080→        if parameters:
  1081→            for key, value in parameters.items():
  1082→                if isinstance(value, (list, tuple)):
  1083→                    logger.debug(f"[智能路由] 参数 '{key}' 包含列表/元组，使用 API Layer")
  1084→             ...(truncated)
```

---

## 🤖 Assistant [17:55:22]

### 🔧 Bash

```json
{
  "command": "tail -50 /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py"
}
```

📤 Result:

```
        Returns:
            bool: True 使用 API Layer，False 使用 SendCommand
        """
        # 1. 显式指定
        if need_result is True:
            logger.debug(f"[智能路由] need_result=True，使用 API Layer")
            return True
        if need_result is False:
            logger.debug(f"[智能路由] need_result=False，使用 SendCommand")
            return False

        # 2. 自动推断
        # 2.1 命令名以 api_ 开头
        if command_name.lower().startswith("api_"):
            logger.debug(f"[智能路由] 命令名以 api_ 开头，使用 API Layer")
            return True

        # 2.2 参数包含复杂对象（列表、嵌套字典）
        if parameters:
            for key, value in parameters.items():
                if isinstance(value, (list, tuple)):
                    logger.debug(f"[智能路由] 参数 '{key}' 包含列表/元组，使用 API Layer")
                    return True
                if isinstance(value, dict):
                    logger.debug(f"[智能路由] 参数 '{key}' 包含字典，使用 API Layer")
                    return True

        # 2.3 默认使用 API Layer（更安全，有返回值）
       ...(truncated)
```

---

## 🤖 Assistant [17:55:24]

Let me get the helper methods:

---

## 🤖 Assistant [17:55:25]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/cad_controller.py",
  "offset": 762,
  "limit": 100
}
```

📤 Result:

```
   762→    def _get_api_request_path(self) -> str:
   763→        """获取 API 请求文件路径"""
   764→        return os.path.join(self._get_api_base_dir(), "request.json")
   765→
   766→    def _get_api_result_path(self) -> str:
   767→        """获取 API 结果文件路径"""
   768→        return os.path.join(self._get_api_base_dir(), "results", "latest.json")
   769→
   770→    def _ensure_api_dirs(self) -> None:
   771→        """确保 API 目录存在"""
   772→        base_dir = self._get_api_base_dir()
   773→        results_dir = os.path.join(base_dir, "results")
   774→        os.makedirs(results_dir, exist_ok=True)
   775→
   776→    def _normalize_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
   777→        """统一 API 结果字段的大小写（C# 使用 PascalCase，Python 习惯 camelCase）"""
   778→        field_mapping = {
   779→            "Success": "success",
   780→            "ErrorCode": "errorCode",
   781→            "Message": "message",
   782→            "Data": "data",
   783→            "RequestId": "request...(truncated)
```

---

## 🤖 Assistant [17:55:25]

### 🔧 Bash

```json
{
  "command": "jq '.categories[0]' /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/api_commands_manifest.json 2>/dev/null | head -80"
}
```

---

## 🤖 Assistant [17:55:28]

Let me check the manifest structure using Python:

---

## 🤖 Assistant [17:55:31]

### 🔧 Bash

```json
{
  "command": "python3 << 'EOF'\nimport json\nwith open('/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/api_commands_manifest.json', 'r', encoding='utf-8-sig') as f:\n    manifest = json.load(f)\n\nprint(\"=== MANIFEST STRUCTURE ===\")\nprint(f\"Version: {manifest.get('version')}\")\nprint(f\"Total Commands: {manifest.get('totalCommands')}\")\nprint(f\"Generated At: {manifest.get('generatedAt')}\")\nprint(f\"\\nCategories ({len(manifest.get('categories', []))}):\")\n\nfor cat in manif...(truncated)
```

📤 Result:

```
=== MANIFEST STRUCTURE ===
Version: 2.0.0
Total Commands: 119
Generated At: 2026-01-31 17:20:17

Categories (13):

  绘图-基础 (drawing) - 10 commands
    Example: api_create_arc
    DisplayName: 创建圆弧
    Description: 创建圆弧实体，通过圆心、半径和起止角度定义
    Parameters: 6 params
      - center (Point3D) [required]
    SupportsSilentMode: True

  查询 (query) - 15 commands
    Example: api_batch_get_entity_info
    DisplayName: 批量获取实体信息
    Description: 批量获取多个实体的详细信息，不提供参数时获取图纸中所有实体信息
    Parameters: 3 params
      - entityHandles (HandleArray) [optional]
    SupportsSilentMode: True

  块操作 (block) - 7 commands
    Example: api_create_block_definition
    DisplayName: 创建块定义
    Description: 从现有实体创建新的块定义
    Parameters: 5 params
      - blockName (BlockName) [required]
    SupportsSilentMode: True
```

---

## 🤖 Assistant [17:55:33]

Perfect! Now let me explore the prompts structure and check the test structure briefly:

---

## 🤖 Assistant [17:55:34]

### 🔧 Bash

```json
{
  "command": "ls -la /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/prompts/"
}
```

📤 Result:

```
total 28
drwxrwxrwx 1 dalong0514 dalong0514  4096 Jan 31 17:24 .
drwxrwxrwx 1 dalong0514 dalong0514  4096 Jan 31 17:23 ..
-rwxrwxrwx 1 dalong0514 dalong0514 24958 Jan 31 17:24 cad_system_prompt.md
```

---

## 🤖 Assistant [17:55:34]

### 🔧 Read

```json
{
  "file_path": "/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/prompts/cad_system_prompt.md",
  "limit": 150
}
```

📤 Result:

```
     1→# CAD 绘图助手系统提示词
     2→
     3→你是一个 CAD 绘图助手，可以通过自然语言控制 {{CAD_NAME}} 进行绘图操作。
     4→
     5→## 重要提示
     6→
     7→**禁止读取任何 JSON 元数据文件**（如 api_commands_metadata.json、api_commands_manifest.json）。
     8→所有命令信息已在下方列出，如需详细参数请使用 `get_api_command_info(command_name)` 工具查询。
     9→
    10→## 核心工具
    11→
    12→### smart_cad_command（必须使用）
    13→**所有 CAD 操作统一使用 `smart_cad_command`**，它会自动选择最优执行方式并返回实体 Handle。
    14→
    15→```json
    16→{"command_name": "api_draw_circle", "parameters": {"center": [100,100,0], "radius": 50}}
    17→```
    18→
    19→### 辅助工具
    20→| 工具 | 用途 |
    21→|------|------|
    22→| `get_api_command_info` | **获取命令的详细参数**（必要时使用） |
    23→| `list_api_commands` | 列出所有可用命令（通常不需要） |
    24→| `batch_execute` | **批量执行多个命令**（推荐，更高效） |
    25→
    26→### 性能优化：优先使用批量执行
    27→
    28→当需要执行 **2 个以上相似操作** 时，使用 `batch_execute` 而非多次调用 `smart_cad_command`：
    29→
    30→```json
    31→// ❌ 低效：3 次调用
    32→smart_cad_command(api_draw_line, ...)
    33→smart_cad_command(api_d...(truncated)
```

---

## 🤖 Assistant [17:55:34]

### 🔧 Bash

```json
{
  "command": "head -100 /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/prompts/cad_system_prompt.md"
}
```

📤 Result:

```
# CAD 绘图助手系统提示词

你是一个 CAD 绘图助手，可以通过自然语言控制 {{CAD_NAME}} 进行绘图操作。

## 重要提示

**禁止读取任何 JSON 元数据文件**（如 api_commands_metadata.json、api_commands_manifest.json）。
所有命令信息已在下方列出，如需详细参数请使用 `get_api_command_info(command_name)` 工具查询。

## 核心工具

### smart_cad_command（必须使用）
**所有 CAD 操作统一使用 `smart_cad_command`**，它会自动选择最优执行方式并返回实体 Handle。

```json
{"command_name": "api_draw_circle", "parameters": {"center": [100,100,0], "radius": 50}}
```

### 辅助工具
| 工具 | 用途 |
|------|------|
| `get_api_command_info` | **获取命令的详细参数**（必要时使用） |
| `list_api_commands` | 列出所有可用命令（通常不需要） |
| `batch_execute` | **批量执行多个命令**（推荐，更高效） |

### 性能优化：优先使用批量执行

当需要执行 **2 个以上相似操作** 时，使用 `batch_execute` 而非多次调用 `smart_cad_command`：

```json
// ❌ 低效：3 次调用
smart_cad_command(api_draw_line, ...)
smart_cad_command(api_draw_line, ...)
smart_cad_command(api_draw_line, ...)

// ✅ 高效：1 次批量调用
batch_execute([
  {"command_name": "api_draw_line", "parameters": {...}},
  {"command_name": "api_draw_line", "parameters":...(truncated)
```

---

## 🤖 Assistant [17:55:36]

Perfect! Now let me create a comprehensive analysis document. Let me gather some final details about the server structure:

---

## 🤖 Assistant [17:55:38]

### 🔧 Bash

```json
{
  "command": "cat /mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/config.json"
}
```

📤 Result:

```
{
    "server": {
        "name": "CAD MCP 服务器",
        "version": "1.0.0"
    },
    "cad": {
        "type": "AUTOCAD", 
        "startup_wait_time": 20,
        "command_delay": 0.5
    },
    "output": {
        "directory": "./output",
        "default_filename": "cad_drawing.dwg"
    }
}
```

---

## 🤖 Assistant [17:55:39]

### 🔧 Bash

```json
{
  "command": "python3 << 'EOF'\nimport json\nwith open('/mnt/d/dalong.com/B.MyCreate/01.AI/CAD-Cowork/mcp-server/api_commands_manifest.json', 'r', encoding='utf-8-sig') as f:\n    manifest = json.load(f)\n\nprint(\"=== FULL MANIFEST STRUCTURE ===\\n\")\nprint(\"Top-level keys:\", list(manifest.keys()))\nprint(f\"\\nTotal Categories: {len(manifest['categories'])}\")\nprint(\"\\nAll Categories:\")\nfor cat in manifest['categories']:\n    print(f\"  - {cat['name']} ({cat['nameEn']}): {cat['count'...(truncated)
```

📤 Result:

```
=== FULL MANIFEST STRUCTURE ===

Top-level keys: ['version', 'generatedAt', 'totalCommands', 'categories']

Total Categories: 13

All Categories:
  - 绘图-基础 (drawing): 10 commands
  - 查询 (query): 15 commands
  - 块操作 (block): 7 commands
  - 批量操作 (batch): 8 commands
  - 空间计算 (spatial): 8 commands
  - 图层管理 (layer): 1 commands
  - 选择集 (selection): 5 commands
  - 工艺流程图 (gslc): 36 commands
  - 事务控制 (transaction): 3 commands
  - 文档 (文档): 4 commands
  - 修改 (修改): 11 commands
  - 图层 (图层): 6 commands
  - 视图 (视图): 5 commands

=== COMPLETE COMMAND EXAMPLE ===

{
  "name": "api_create_arc",
  "displayName": "创建圆弧",
  "description": "创建圆弧实体，通过圆心、半径和起止角度定义",
  "parameters": [
    {
      "name": "center",
      "displayName": "圆心",
      "description": "圆弧圆心坐标 [x, y, z]",
      "type": "Point3D",
      "required": true,
      "defaultValue": null,
      "aliases": null
    },
    {
      "name": "radius",
      "displayName": "半径",
      "description": "圆弧半径",
      "type": "Double",
      "required": ...(truncated)
```

---

## 🤖 Assistant [17:56:35]

Excellent! Now I have all the information I need. Let me compile a comprehensive analysis report:

## CAD-MCP MCP Server 实现架构详细分析

基于我的代码探索，以下是 CAD-MCP 的完整 MCP server 实现架构分析：

---

### 1. 整体架构概览

#### 核心文件结构
```
mcp-server/
├── server.py                      # MCP 服务主文件（486 行）
├── cad_controller.py              # CAD 控制器（1111 行）
├── batch_executor.py              # 批量执行器（~500 行）
├── nlp_processor.py               # NLP 处理器
├── api_commands_manifest.json     # API 命令清单（119 个命令）
├── api_commands_index.md          # 快速参考索引
├── prompts/
│   └── cad_system_prompt.md      # 系统提示词模板
└── config.json                    # 配置文件
```

#### 工作流
```
Agent 客户端 (Claude SDK)
    ↓
MCP Protocol (stdio)
    ↓
server.py (MCP 服务器)
    ↓ (tool calls)
    ├→ smart_cad_command
    ├→ execute_api_command
    ├→ batch_execute
    ├→ get_api_command_info
    └→ list_api_commands
    ↓
CADController (cad_controller.py)
    ├→ execute_api_command → 通过 API Layer (request/result JSON)
    ├→ send_command → 通过 SendCommand (AutoCAD 命令行)
    └→ smart_cad_command → 自动选择最优方式
    ↓
CAD 应用 (COM Interface)
```

---

### 2. 工具注册方式

#### 2.1 工具列表声明 (server.py, 行 164-302)

所有工具在 `@server.list_tools()` 异步函数中注册，返回 `list[types.Tool]` 对象：

```python
@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    return [
        # 工具 1: execute_api_command
        types.Tool(
            name="execute_api_command",
            description="[辅助] 执行 API 命令...",
            inputSchema={
                "type": "object",
                "properties": {
                    "command_name": {"type": "string", ...},
                    "parameters": {"type": "object", ...},
                    "timeout": {"type": "number", ...}
                },
                "required": ["command_name"],
            },
        ),
        
        # 工具 2: list_api_commands
        types.Tool(
            name="list_api_commands",
            description="列出所有可用的 cad-cowork-cstool API 命令...",
            inputSchema={
                "type": "object",
                "properties": {},
                "required": [],
            },
        ),
        
        # 工具 3: get_api_command_info
        types.Tool(
            name="get_api_command_info",
            description="获取指定 API 命令的详细信息...",
            inputSchema={
                "type": "object",
                "properties": {
                    "command_name": {"type": "string", ...}
                },
                "required": ["command_name"],
            },
        ),
        
        # 工具 4: smart_cad_command (核心工具)
        types.Tool(
            name="smart_cad_command",
            description="[核心工具] 执行所有 CAD 操作的统一入口...",
            inputSchema={
                "type": "object",
                "properties": {
                    "command_name": {"type": "string", ...},
                    "parameters": {"type": "object", ...},
                    "need_result": {"type": "boolean", ...},
                    "timeout": {"type": "number", ...}
                },
                "required": ["command_name"],
            },
        ),
        
        # 工具 5: batch_execute (高效批量工具)
        types.Tool(
            name="batch_execute",
            description="批量执行多个 API 命令，支持依赖管理和参数传递...",
            inputSchema={
                "type": "object",
                "properties": {
                    "commands": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "id": {"type": "string"},
                                "command_name": {"type": "string"},
                                "parameters": {"type": "object"},
                                "depends_on": {"type": "array"}
                            },
                            "required": ["id", "command_name"]
                        }
                    },
                    "stop_on_error": {"type": "boolean"},
                    "timeout_per_command": {"type": "number"},
                    "detail_level": {"type": "string", "enum": ["summary", "handles", "full"]},
                    "use_transaction": {"type": "boolean"}
                },
                "required": ["commands"],
            },
        ),
    ]
```

---

### 3. 工具实现处理 (Tool Execution Handler)

#### 3.1 统一的工具调用入口 (server.py, 行 304-439)

```python
@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict[str, Any] | None
) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
    """处理工具执行请求"""
    try:
        # 确保 arguments 是字典
        if arguments is None:
            arguments = {}

        # 根据工具名称分发
        if name == "execute_api_command":
            # ... 处理逻辑
        elif name == "list_api_commands":
            # ... 处理逻辑
        elif name == "get_api_command_info":
            # ... 处理逻辑
        elif name == "smart_cad_command":
            # ... 处理逻辑
        elif name == "batch_execute":
            # ... 处理逻辑
        else:
            raise ValueError(f"未知工具: {name}")
            
    except Exception as e:
        return [types.TextContent(type="text", text=f"错误: {str(e)}")]
```

#### 3.2 工具实现模式示例：execute_api_command

```python
if name == "execute_api_command":
    command_name = arguments.get("command_name")
    parameters = arguments.get("parameters", {})
    timeout = arguments.get("timeout", 10.0)

    if not command_name:
        raise ValueError("缺少 API 命令名称")

    # 确保 CAD 已连接（自动连接）
    if not cad_service.controller.is_running():
        cad_service.start_cad()

    # 调用 CADController 的方法
    result = cad_service.controller.execute_api_command(
        command_name, 
        parameters, 
        timeout
    )
    
    # 返回 JSON 格式结果
    return [types.TextContent(
        type="text", 
        text=json.dumps(result, ensure_ascii=False, indent=2)
    )]
```

---

### 4. 参数验证机制

#### 4.1 工具层面（MCP Framework）

MCP Framework 基于 `inputSchema` 自动验证：
- **必需参数检查**: `"required": ["command_name"]`
- **类型检查**: `"type": "object"`, `"type": "string"` 等
- **枚举检查**: `"enum": ["summary", "handles", "full"]`

#### 4.2 应用层面（CADController）

**execute_api_command 的参数验证**:
```python
def execute_api_command(self, command_name: str, parameters: Dict[str, Any] = None,
                       timeout: float = 10.0) -> Dict[str, Any]:
    # 检查 CAD 是否运行
    if not self.is_running():
        return {"success": False, "errorCode": -8, "message": "CAD未运行"}
    
    # 调用内部实现
    return self._execute_api_command_once(command_name, parameters, timeout)
```

**请求对象构建与验证**:
```python
def _execute_api_command_once(self, command_name: str, ...):
    # 构建请求
    request = {
        "commandName": command_name,
        "requestId": uuid.uuid4().hex[:8],
        "silentMode": True,
        "timeoutMs": int(timeout * 1000),
        "parameters": parameters or {}  # 参数直接传递给 C# 层
    }
    
    # 将请求写入 JSON 文件
    with open(request_path, 'w', encoding='utf-8') as f:
        json.dump(request, f, ensure_ascii=False, indent=2)
```

---

### 5. 返回值格式标准化

#### 5.1 API 命令执行结果（_normalize_result）

所有 API 命令结果经过 `_normalize_result()` 标准化 (cad_controller.py, 行 776-797)：

```python
def _normalize_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
    """统一 API 结果字段的大小写（C# 使用 PascalCase，Python 习惯 camelCase）"""
    field_mapping = {
        "Success": "success",
        "ErrorCode": "errorCode",
        "Message": "message",
        "Data": "data",
        "RequestId": "requestId",
        "CommandName": "commandName",
        "ExecutionTimeMs": "executionTimeMs",
        "Timestamp": "timestamp",
        "CreatedEntityHandles": "createdEntityHandles",
        "ModifiedEntityHandles": "modifiedEntityHandles"
    }
    
    normalized = {}
    for key, value in result.items():
        new_key = field_mapping.get(key, key)
        normalized[new_key] = value
    
    return normalized
```

#### 5.2 统一的返回格式

所有工具返回相同的 JSON 结构：

```json
{
  "success": true|false,
  "errorCode": number,
  "message": string,
  "data": {
    // 命令特定的数据
  },
  "createdEntityHandles": ["27E2C0", "27E2D1"],  // 创建的实体句柄
  "executionTimeMs": 150,
  "requestId": "a1b2c3d4"
}
```

---

### 6. API 命令清单加载与查询

#### 6.1 清单文件结构 (api_commands_manifest.json)

```json
{
  "version": "2.0.0",
  "generatedAt": "2026-01-31 17:20:17",
  "totalCommands": 119,
  "categories": [
    {
      "name": "绘图-基础",
      "nameEn": "drawing",
      "count": 10,
      "commands": [
        {
          "name": "api_create_arc",
          "displayName": "创建圆弧",
          "description": "创建圆弧实体...",
          "parameters": [
            {
              "name": "center",
              "displayName": "圆心",
              "description": "圆弧圆心坐标 [x, y, z]",
              "type": "Point3D",
              "required": true,
              "defaultValue": null,
              "aliases": ["centre"]
            },
            // ... more parameters
          ],
          "supportsSilentMode": true,
          "usageExample": "{ ... }"
        },
        // ... more commands
      ]
    },
    // ... 12 more categories
  ]
}
```

#### 6.2 加载机制 (server.py, 行 74-88)

```python
def load_api_commands_manifest():
    """加载 API 命令清单文件"""
    manifest_path = os.path.join(os.path.dirname(__file__), 'api_commands_manifest.json')
    try:
        # 使用 utf-8-sig 自动处理 BOM（Byte Order Mark）
        with open(manifest_path, 'r', encoding='utf-8-sig') as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"加载 API 命令清单失败: {e}")
        return None

# 全局加载
API_COMMANDS_MANIFEST = load_api_commands_manifest()
```

#### 6.3 命令查询实现

**list_api_commands**：
```python
elif name == "list_api_commands":
    # 优先从 CAD 获取（实时）
    result = None
    try:
        if cad_service.controller.is_running():
            result = cad_service.controller.get_api_commands_metadata()
    except Exception as e:
        logger.warning(f"从 CAD 获取命令列表失败: {e}")
    
    # 备选：使用本地清单
    if result is None or not result.get("success", False):
        if API_COMMANDS_MANIFEST:
            result = {
                "success": True,
                "source": "local_manifest",
                "totalCommands": API_COMMANDS_MANIFEST.get("totalCommands", 0),
                "categories": API_COMMANDS_MANIFEST.get("categories", [])
            }
```

**get_api_command_info**：
```python
elif name == "get_api_command_info":
    command_name = arguments.get("command_name")
    
    # 优先从 CAD 获取
    result = None
    try:
        if cad_service.controller.is_running():
            result = cad_service.controller.get_api_command_info(command_name)
    except Exception as e:
        logger.warning(f"从 CAD 获取命令信息失败: {e}")
    
    # 备选：从本地清单查找
    if result is None or not result.get("success", False):
        if API_COMMANDS_MANIFEST:
            for category in API_COMMANDS_MANIFEST.get("categories", []):
                for cmd in category.get("commands", []):
                    if cmd.get("name") == command_name:
                        result = {
                            "success": True,
                            "source": "local_manifest",
                            "command": cmd,
                            "category": category.get("name")
                        }
                        break
```

---

### 7. CAD 通信方式

#### 7.1 两层通信机制

**第一层：API Layer（参数化命令，推荐）**

```
Agent → MCP Server → CADController.execute_api_command()
    ↓
Write request.json: {commandName, parameters, requestId, timeoutMs}
    ↓
Send "DLApiExecute\n" to CAD via SendCommand
    ↓
Poll result file: results/latest.json (50ms 轮询间隔)
    ↓
解析 result.json，验证 requestId 匹配
    ↓
Return 结构化结果 (Handle, Data, etc.)
```

**代码实现** (cad_controller.py, 行 816-926)：

```python
def _execute_api_command_once(self, command_name: str, parameters: Dict[str, Any] = None,
                              timeout: float = 10.0) -> Dict[str, Any]:
    # 1. 生成唯一请求 ID
    request_id = uuid.uuid4().hex[:8]
    
    # 2. 构建请求对象
    request = {
        "commandName": command_name,
        "requestId": request_id,
        "silentMode": True,
        "timeoutMs": int(timeout * 1000),
        "parameters": parameters or {}
    }
    
    # 3. 写入请求文件
    request_path = self._get_api_request_path()
    with open(request_path, 'w', encoding='utf-8') as f:
        json.dump(request, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())  # 强制写入磁盘
    
    time.sleep(0.03)  # Windows 文件系统缓存
    
    # 4. 触发 CAD 执行
    self.doc.SendCommand("DLApiExecute\n")
    
    # 5. 轮询结果文件
    start_time = time.time()
    poll_interval = 0.05  # 50ms
    
    while time.time() - start_time < timeout:
        time.sleep(poll_interval)
        
        if os.path.exists(result_path):
            with open(result_path, 'r', encoding='utf-8-sig') as f:
                result = json.load(f)
            
            # 验证是否是我们的请求
            if result.get("requestId") == request_id:
                return self._normalize_result(result)
    
    # 超时
    return {
        "success": False,
        "errorCode": -6,
        "message": f"API 命令执行超时 ({timeout}秒)"
    }
```

**第二层：SendCommand（简单命令）**

```
Agent → MCP Server → CADController.send_command()
    ↓
Send "CommandName [Params]\n" to CAD via Document.SendCommand()
    ↓
Sleep command_delay (500ms)
    ↓
Return 简单成功/失败响应
```

**代码实现** (cad_controller.py, 行 177-208)：

```python
def send_command(self, command: str) -> dict:
    """发送命令到 CAD 命令行"""
    if not self.is_running():
        return {"success": False, "message": "CAD未运行"}
    
    try:
        if not command.endswith("\n"):
            command = command + "\n"
        
        self.doc.SendCommand(command)
        time.sleep(self.command_delay)  # 等待命令执行
        
        return {"success": True, "message": f"命令 '{command.strip()}' 已执行"}
    except Exception as e:
        return {"success": False, "message": f"发送命令失败: {str(e)}"}
```

---

### 8. 智能路由机制 (smart_cad_command)

#### 8.1 决策算法 (cad_controller.py, 行 1009-1091)

```python
def smart_cad_command(self, command_name: str, parameters: Dict[str, Any] = None,
                      need_result: bool = None, timeout: float = 10.0) -> Dict[str, Any]:
    """智能执行 CAD 命令 - 自动选择 API Layer 或 SendCommand"""
    
    # 判断使用哪种执行方式
    use_api = self._should_use_api(command_name, parameters, need_result)
    
    if use_api:
        result = self.execute_api_command(command_name, parameters or {}, timeout)
        result["executionMethod"] = "api_layer"
    else:
        params_str = self._build_sendcommand_params(parameters)
        result = self.send_command(f"{command_name} {params_str}".strip())
        result["executionMethod"] = "sendcommand"
    
    return result

def _should_use_api(self, command_name: str, parameters: Dict[str, Any],
                    need_result: bool) -> bool:
    """
    路由决策规则（优先级从高到低）：
    1. need_result=True  → API Layer
    2. need_result=False → SendCommand
    3. 命令以 api_ 开头 → API Layer
    4. 参数包含列表/字典 → API Layer
    5. 默认 → API Layer（更安全）
    """
    
    # 1. 显式指定
    if need_result is True:
        return True
    if need_result is False:
        return False
    
    # 2. 自动推断
    # 2.1 命令名以 api_ 开头
    if command_name.lower().startswith("api_"):
        return True
    
    # 2.2 参数包含复杂对象
    if parameters:
        for key, value in parameters.items():
            if isinstance(value, (list, tuple, dict)):
                return True
    
    # 2.3 默认使用 API Layer
    return True
```

---

### 9. 批量执行器（BatchExecutor）

#### 9.1 特性

**支持**：
- DAG 依赖管理（拓扑排序）
- 参数引用传递（`${cmd_id.field}`）
- 循环依赖检测
- 全局事务支持（可选）
- 三级详细程度返回值

#### 9.2 批量执行流程 (batch_executor.py)

```python
def execute(
    self,
    commands: List[Dict],
    stop_on_error: bool = True,
    timeout_per_command: float = 10.0,
    detail_level: str = "handles",
    use_transaction: bool = False
) -> Dict[str, Any]:
    """
    执行流程：
    1. [可选] 开始全局事务
    2. 验证命令格式
    3. 构建依赖图 & 拓扑排序
    4. 按顺序执行，支持参数引用
    5. 收集结果（成功/失败/跳过）
    6. [可选] 提交或回滚事务
    """
    
    # 1. 全局事务
    if use_transaction:
        begin_result = self.controller.execute_api_command(
            "api_transaction_begin", {}, timeout=timeout_per_command)
        transaction_id = begin_result.get("data", {}).get("transactionId")
    
    # 2. 验证 & 3. 拓扑排序
    validation_error = self._validate_commands(commands)
    execution_order = self._topological_sort(commands)
    
    # 4. 逐个执行
    for cmd_id in execution_order:
        cmd = cmd_index[cmd_id]
        
        # 检查依赖是否成功
        if cmd.get("depends_on"):
            for dep_id in cmd["depends_on"]:
                if dep_id not in self.results or not self.results[dep_id]["success"]:
                    # 依赖失败，跳过
                    continue
        
        # 解析参数引用
        resolved_params = self._resolve_references(cmd.get("parameters", {}))
        
        # 执行命令
        api_result = self.controller.execute_api_command(
            cmd["command_name"],
            resolved_params,
            timeout=timeout_per_command
        )
        
        # 保存结果供后续命令引用
        self.results[cmd_id] = api_result
        handle = api_result.get("createdEntityHandles", [None])[0]
        self.handle_map[cmd_id] = handle
    
    # 6. 事务处理
    if use_transaction and transaction_id:
        if failed_count == 0:
            self.controller.execute_api_command(
                "api_transaction_commit",
                {"transactionId": transaction_id},
                timeout=timeout_per_command
            )
        else:
            self.controller.execute_api_command(
                "api_transaction_rollback",
                {"transactionId": transaction_id},
                timeout=timeout_per_command
            )
```

#### 9.3 参数引用解析

```python
def _resolve_references(self, parameters: Dict[str, Any]) -> Dict[str, Any]:
    """
    解析参数中的引用，如 ${cmd_id.field}
    
    示例：
    - ${line1.createdEntityHandles[0]} → 获取 line1 命令的首个句柄
    - ${circle1.data.radius} → 获取 circle1 返回的 radius
    """
    resolved = {}
    for key, value in parameters.items():
        if isinstance(value, str):
            # 查找所有 ${...} 引用
            matches = self.REFERENCE_PATTERN.findall(value)
            for match in matches:
                # 从 self.results 中查找引用的值
                ref_value = self._extract_nested_value(self.results, match)
                value = value.replace(f"${{{match}}}", str(ref_value))
        resolved[key] = value
    return resolved
```

---

### 10. 系统提示词架构

#### 10.1 提示词文件 (prompts/cad_system_prompt.md)

**特点**：
- 使用 `{{CAD_NAME}}` 占位符适配多个 CAD 类型
- 包含 119 个命令的快速参考
- 包含常用命令的参数速查表
- 强制执行参数规范（camelCase, Point3D 格式等）

#### 10.2 加载与使用

```python
def load_prompt_template(cad_name: str = "CAD") -> str:
    """加载提示词模板文件"""
    template_path = os.path.join(os.path.dirname(__file__), 'prompts', 'cad_system_prompt.md')
    with open(template_path, 'r', encoding='utf-8') as f:
        content = f.read()
    # 替换占位符
    content = content.replace('{{CAD_NAME}}', cad_name)
    return content

PROMPT_TEMPLATE = load_prompt_template("CAD")

@server.get_prompt()
async def handle_get_prompt(name: str, arguments: dict[str, str] | None) -> types.GetPromptResult:
    """获取 CAD 助手提示词"""
    if name != "cad-assistant":
        raise ValueError(f"未知的提示: {name}")
    
    return types.GetPromptResult(
        description="CAD助手提示模板",
        messages=[
            types.PromptMessage(
                role="user",
                content=types.TextContent(type="text", text=PROMPT_TEMPLATE.strip()),
            )
        ],
    )
```

---

### 11. 关键设计模式

| 模式 | 说明 | 实现位置 |
|------|------|--------|
| **快速失败** | API 命令超时直接返回错误，不自动重试 | execute_api_command |
| **自动重连** | CAD 未运行时自动启动 | smart_cad_command, batch_execute |
| **文件轮询** | 通过 JSON 文件进行进程间通信 | _execute_api_command_once |
| **引用传递** | 批量执行中后续命令可引用前置命令输出 | BatchExecutor._resolve_references |
| **拓扑排序** | DAG 依赖管理确保执行顺序 | BatchExecutor._topological_sort |
| **事务支持** | 可选全局事务，失败自动回滚 | batch_execute |
| **标准化结果** | 统一 PascalCase → camelCase 转换 | _normalize_result |
| **双层路由** | 简单命令用 SendCommand，复杂命令用 API Layer | _should_use_api |

---

### 12. 配置文件

**config.json** 结构：
```json
{
  "server": {
    "name": "CAD MCP 服务器",
    "version": "1.0.0"
  },
  "cad": {
    "type": "AUTOCAD",              // 支持: AUTOCAD, GCAD, GSTARCAD, ZWCAD
    "startup_wait_time": 20,        // CAD 启动等待时间（秒）
    "command_delay": 0.5            // 命令执行延迟（秒）
  },
  "output": {
    "directory": "./output",
    "default_filename": "cad_drawing.dwg"
  }
}
```

---

### 13. 错误处理策略

| 错误场景 | 返回码 | 处理方式 |
|----------|--------|---------|
| CAD 未运行 | -8 | 自动启动 CAD |
| API 命令超时 | -6 | 返回超时错误，提供诊断提示 |
| 请求失败 | -1 | 返回详细错误信息 |
| 循环依赖 | - | 在拓扑排序时检测并返回错误 |
| 参数引用失败 | - | 返回引用解析错误，中止批量执行 |
| 依赖命令失败 | - | 跳过依赖命令（可选中止）|

---

### 14. 性能特征

| 指标 | 值 | 说明 |
|------|-----|------|
| API Layer 轮询间隔 | 50ms | 更快响应 |
| API Layer 超时默认值 | 10s | 可配置 |
| SendCommand 延迟 | 500ms | config.json 可配 |
| 文件系统同步延迟 | 30ms | Windows 缓存问题 |
| 批量命令数量 | 无限制 | 只受内存限制 |

---

这是一个非常完整的、生产级别的 MCP 服务器实现，特别适合设计新的路由工具。其核心特点是：

1. **清晰的分层** - 工具层、控制器层、通信层分离
2. **灵活的通信** - 支持两种执行方式的自动选择
3. **完善的参数化** - 通过 manifest 和提示词统一管理 119 个命令
4. **高效的批量执行** - DAG 依赖 + 参数引用
5. **可靠的错误处理** - 快速失败、自动恢复、事务回滚

---
