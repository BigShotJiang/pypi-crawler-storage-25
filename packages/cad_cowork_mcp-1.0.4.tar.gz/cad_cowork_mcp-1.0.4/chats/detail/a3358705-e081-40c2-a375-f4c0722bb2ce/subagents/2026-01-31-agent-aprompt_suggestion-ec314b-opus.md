# SubAgent 对话记录 (opus)

> 项目: CAD-Cowork
> Session: a3358705-e081-40c2-a375-f4c0722bb2ce

---

## 🤖 Assistant [17:47:08]

你说得对，这是一个会随着业务扩展而恶化的架构问题。让我深入分析后给出系统性的解决方案。

## 问题诊断

**当前问题的本质**：

| 维度 | 现状 | 问题 |
|------|------|------|
| 工具数量 | 119 个（GsLc 36 个） | 每次决策面对太多选项 |
| 命令描述 | 功能描述，缺乏边界说明 | 语义重叠导致选择模糊 |
| 架构模式 | 扁平的工具列表 | 无分层路由，全靠 LLM 一次决策 |

**用户输入 "批量生成设备位号" 时 agent 的困惑**：

```
api_gslc_insert_bottom_equip_tags - "批量生成底部设备位号"     ← 正确
api_gslc_auto_number            - "智能编号...设备..."       ← 语义接近
api_gslc_insert_equipment       - "插入设备块"               ← 包含"设备"
```

---

## 解决方案（按推荐优先级排序）

### 方案 1：**分层路由架构**（推荐 - 根本解决）

参考 Anthropic 文档的 **Routing Workflow**：

```
用户输入
    │
    ▼
┌─────────────────────┐
│  第一层：意图路由器   │  ← 先判断操作类型
│  (5-8 个类别)        │
└──────────┬──────────┘
           │
    ┌──────┴──────┬──────────┬──────────┐
    ▼             ▼          ▼          ▼
 ┌──────┐    ┌──────┐   ┌──────┐   ┌──────┐
 │查询类│    │插入类│   │编号类│   │导出类│
 │8个   │    │8个   │   │3个   │   │6个   │
 └──────┘    └──────┘   └──────┘   └──────┘
```

**实现方式**：
```typescript
// 在 smart_cad_command 之前增加路由层
const GSLC_INTENT_CATEGORIES = {
  "查询/获取信息": ["api_gslc_query_*"],
  "插入新元素": ["api_gslc_insert_*"],
  "批量生成/编号": ["api_gslc_insert_bottom_equip_tags", "api_gslc_auto_number"],
  "数据导出": ["api_gslc_export_*"],
  "数据同步": ["api_gslc_sync_*"],
  "刷新/更新": ["api_gslc_brush_*"]
};
```

**优点**：每层决策面对 ≤10 个选项，准确率大幅提升

---

### 方案 2：**关键词触发映射**（快速实施）

在系统提示词中添加明确的「用户意图 → 命令」映射表：

```markdown
## 常见任务命令速查

| 用户说法 | 正确命令 | ❌ 易混淆命令 |
|----------|----------|--------------|
| "批量生成设备位号"、"生成底部位号" | `api_gslc_insert_bottom_equip_tags` | ~~api_gslc_auto_number~~（这是编号，不是生成位号块） |
| "给设备/管道编号"、"自动编号" | `api_gslc_auto_number` | ~~api_gslc_insert_equipment~~（这是插入新设备） |
| "在某位置插入一个设备" | `api_gslc_insert_equipment` | - |
```

**优点**：实施简单，立即见效
**缺点**：不能覆盖所有情况，维护成本随命令增加线性增长

---

### 方案 3：**工具描述优化**（必须做）

参考 Anthropic 文档的 **"Prompt Engineering your Tools"**：

> "A good tool definition often includes example usage, edge cases, input format requirements, and **clear boundaries from other tools**."

当前描述：
```json
"api_gslc_insert_bottom_equip_tags": {
  "description": "在所有图框的底部自动生成设备位号块"
}
```

优化后：
```json
"api_gslc_insert_bottom_equip_tags": {
  "description": "【批量生成位号块】在图框底部区域批量插入设备位号块（BlockReference）。用于：图纸底部的设备位号汇总区域。注意：这不是给设备编号（编号用 api_gslc_auto_number），而是生成新的位号块实体。",
  "whenToUse": "用户说'生成设备位号'、'批量插入位号'、'底部位号'时使用",
  "notToConfuseWith": ["api_gslc_auto_number（编号，不生成新实体）", "api_gslc_insert_equipment（插入设备本身）"]
}
```

---

### 方案 4：**语义预分类器**（可选增强）

在调用 LLM 前，用轻量级方法预筛选候选命令：

```python
def pre_filter_commands(user_input: str, all_commands: list) -> list:
    """基于关键词匹配，缩小命令范围"""
    keywords_map = {
        "批量生成": ["api_gslc_insert_bottom_equip_tags", "api_batch_*"],
        "位号": ["api_gslc_insert_bottom_equip_tags", "api_gslc_insert_equip_tag"],
        "编号": ["api_gslc_auto_number"],
        "插入设备": ["api_gslc_insert_equipment"],
    }
    # 返回候选命令子集（≤15个），而非全部119个
```

---

## 推荐实施路径

```
阶段 1（立即）: 方案 2 + 方案 3
  ├── 在 cad_system_prompt.md 添加「易混淆命令对照表」
  └── 优化 manifest.json 中混淆命令的 description

阶段 2（短期）: 方案 1 的简化版
  ├── 在提示词中按功能分组展示命令（而非扁平列表）
  └── 添加「先确定操作类型，再选命令」的引导

阶段 3（中期）: 完整的分层路由
  └── 代码层面实现两阶段路由架构
```

---

需要我先帮你实施**阶段 1**（优化提示词和命令描述）吗？这可以快速验证效果。

---

## 👤 User [17:47:08]

[SUGGESTION MODE: Suggest what the user might naturally type next into Claude Code.]

FIRST: Look at the user's recent messages and original request.

Your job is to predict what THEY would type - not what you think they should do.

THE TEST: Would they think "I was just about to type that"?

EXAMPLES:
User asked "fix the bug and run tests", bug is fixed → "run the tests"
After code written → "try it out"
Claude offers options → suggest the one the user would likely pick, based on conversation
Claude asks to continue → "yes" or "go ahead"
Task complete, obvious follow-up → "commit this" or "push it"
After error or misunderstanding → silence (let them assess/correct)

Be specific: "run the tests" beats "continue".

NEVER SUGGEST:
- Evaluative ("looks good", "thanks")
- Questions ("what about...?")
- Claude-voice ("Let me...", "I'll...", "Here's...")
- New ideas they didn't ask about
- Multiple sentences

Stay silent if the next step isn't obvious from what the user said.

Format: 2-12 words, match the user's style. Or nothing.

Reply with ONLY the suggestion, no quotes or explanation.

---

## 🤖 Assistant [17:47:11]

API Error: 400 {"type":"error","error":{"type":"invalid_request_error","message":"thinking.enabled.budget_tokens: Input should be greater than or equal to 1024"},"request_id":"req_011CXfF6fJP6sgsD4U5Um7JE"}

---
