"""
批量执行功能测试脚本

使用方法：
1. 确保 CAD 软件已启动
2. 运行: python test_batch.py
"""

import json
from cad_controller import CADController
from batch_executor import BatchExecutor


def test_simple_batch():
    """测试简单批量执行（无依赖）"""
    print("\n=== 测试 1: 简单批量执行 ===")

    controller = CADController()
    if not controller.is_running():
        print("正在连接 CAD...")
        controller.start_cad()

    executor = BatchExecutor(controller)

    commands = [
        {
            "id": "c1",
            "command_name": "api_draw_circle",
            "parameters": {"center": [0, 0, 0], "radius": 30}
        },
        {
            "id": "c2",
            "command_name": "api_draw_circle",
            "parameters": {"center": [100, 0, 0], "radius": 20}
        }
    ]

    result = executor.execute(commands, stop_on_error=True, timeout_per_command=10)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


def test_with_dependency():
    """测试带依赖的批量执行"""
    print("\n=== 测试 2: 带依赖的批量执行 ===")

    controller = CADController()
    if not controller.is_running():
        print("正在连接 CAD...")
        controller.start_cad()

    executor = BatchExecutor(controller)

    commands = [
        {
            "id": "rect1",
            "command_name": "api_draw_rectangle",
            "parameters": {"point1": [0, 0, 0], "point2": [100, 80, 0]}
        },
        {
            "id": "line1",
            "command_name": "api_draw_line",
            "parameters": {"startPoint": [50, 40, 0], "endPoint": [150, 120, 0]},
            "depends_on": ["rect1"]
        }
    ]

    result = executor.execute(commands, stop_on_error=True, timeout_per_command=10)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


def test_parameter_reference():
    """测试参数引用"""
    print("\n=== 测试 3: 参数引用 ===")

    controller = CADController()
    if not controller.is_running():
        print("正在连接 CAD...")
        controller.start_cad()

    executor = BatchExecutor(controller)

    # 注意：这个测试依赖于 api_draw_circle 返回的 data 中包含 center 字段
    commands = [
        {
            "id": "circle1",
            "command_name": "api_draw_circle",
            "parameters": {"center": [200, 200, 0], "radius": 50}
        },
        {
            "id": "line1",
            "command_name": "api_draw_line",
            "parameters": {
                "startPoint": "${circle1.data.center}",
                "endPoint": [300, 300, 0]
            },
            "depends_on": ["circle1"]
        }
    ]

    result = executor.execute(commands, stop_on_error=True, timeout_per_command=10)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return result


def test_cyclic_dependency():
    """测试循环依赖检测"""
    print("\n=== 测试 4: 循环依赖检测 ===")

    controller = CADController()
    executor = BatchExecutor(controller)

    # 故意创建循环依赖: A -> B -> C -> A
    commands = [
        {"id": "a", "command_name": "api_draw_circle", "parameters": {"center": [0,0,0], "radius": 10}, "depends_on": ["c"]},
        {"id": "b", "command_name": "api_draw_circle", "parameters": {"center": [0,0,0], "radius": 10}, "depends_on": ["a"]},
        {"id": "c", "command_name": "api_draw_circle", "parameters": {"center": [0,0,0], "radius": 10}, "depends_on": ["b"]},
    ]

    result = executor.execute(commands)
    print(json.dumps(result, ensure_ascii=False, indent=2))

    # 应该检测到循环依赖并返回错误
    assert result["success"] == False, "应该检测到循环依赖"
    print("✓ 循环依赖检测通过")
    return result


def test_validation():
    """测试命令验证"""
    print("\n=== 测试 5: 命令验证 ===")

    controller = CADController()
    executor = BatchExecutor(controller)

    # 测试空命令列表
    result = executor.execute([])
    print("空列表测试:", result["message"])
    assert result["success"] == False

    # 测试缺少 id
    result = executor.execute([{"command_name": "test"}])
    print("缺少 id 测试:", result["message"])
    assert result["success"] == False

    # 测试重复 id
    result = executor.execute([
        {"id": "same", "command_name": "test"},
        {"id": "same", "command_name": "test"}
    ])
    print("重复 id 测试:", result["message"])
    assert result["success"] == False

    print("✓ 所有验证测试通过")


if __name__ == "__main__":
    import sys

    print("=" * 50)
    print("批量执行功能测试")
    print("=" * 50)

    # 先运行不需要 CAD 的测试
    test_validation()
    test_cyclic_dependency()

    # 如果有 --with-cad 参数，运行需要 CAD 的测试
    if "--with-cad" in sys.argv:
        print("\n" + "=" * 50)
        print("以下测试需要 CAD 软件运行")
        print("=" * 50)
        test_simple_batch()
        test_with_dependency()
        test_parameter_reference()
    else:
        print("\n提示: 添加 --with-cad 参数运行完整测试（需要 CAD 软件）")
        print("例如: python test_batch.py --with-cad")
