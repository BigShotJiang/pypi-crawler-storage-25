### 01

还需封装的：

```json
            {
              "Title": "导出数据",
              "IconKey": "xx.bmp",
              "Command": "GsLcExportCADData"
            },
            {
              "Title": "同步数据",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcSysDataFromClient"
            }



```

GsLcInsertAllBlock





```json
{
  "PaletteTitle": "数智设计-工艺",
  "PaletteWidth": 300,
  "PaletteHeight": 500,
  "Tabs": [
    {
      "TabName": "工艺流程",
      "MenuGroups": [
        {
          "Title": "数据处理",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "导出项目信息关联软件（目前觉得没必要做项目信息校验了）",
              "IconKey": "xx.bmp",
              "Command": "ExportDDProjectInfoBySelect"
            },
            {
              "Title": "导出数据（已封装为API）",
              "IconKey": "xx.bmp",
              "Command": "GsLcExportCADData"
            },
            {
              "Title": "同步数据",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcSysDataFromClient"
            }
          ]
        },
        {
          "Title": "一键修改功能",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "一键刷仪表所在位置",
              "IconKey": "xx.bmp",
              "Command": "GsLcAutoBrushInstrumentLocation"
            },
            {
              "Title": "一键根据相对位置更新校验仪表所在位置",
              "IconKey": "xx.bmp",
              "Command": "GsLcUpdateInstrumentLocation"
            },
            {
              "Title": "一键刷阀门所在位置",
              "IconKey": "xx.bmp",
              "Command": "GsLcAutoBrushValveLocation"
            },
            {
              "Title": "一键根据相对位置更新校验阀门所在位置",
              "IconKey": "xx.bmp",
              "Command": "GsLcUpdateValveLocation"
            },
            {
              "Title": "一键刷管道来去向",
              "IconKey": "xx.bmp",
              "Command": "GsLcAutoBrushPipelineFromTo"
            },
            {
              "Title": "一键根据相对位置更新校验管道来去向",
              "IconKey": "xx.bmp",
              "Command": "GsLcUpdatePipelineFromTo"
            },
            {
              "Title": "一键更新数据所在流程图号",
              "IconKey": "xx.bmp",
              "Command": "UpdateDrawGsLcDrawNumData"
            },
            {
              "Title": "一键更新公用工程块物料代号",
              "IconKey": "xx.bmp",
              "Command": "GsLcAutoBrushPublicPipelineCode"
            },
            {
              "Title": "一键打断流程图管道仪表交叉",
              "IconKey": "xx.bmp",
              "Command": "GsLcInterruptPipeline"
            },
            {
              "Title": "一键生成或更新流程底部设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertAllBottomEquipTag"
            },
            {
              "Title": "一键关联外管箭头块与管道块",
              "IconKey": "xx.bmp",
              "Command": "GsLcAutoAssociateOuterPipeArrowBlockAndPipeBlock"
            },
            {
              "Title": "一键前置仪表阀门块",
              "IconKey": "xx.bmp",
              "Command": "GsLcFrontInstrumentAndValve"
            }
          ]
        },
        {
          "Title": "批量修改功能",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "批量刷仪表阀门所在位置",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcBrushInstrumentLocation"
            },
            {
              "Title": "批量刷公用管道来去向",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcBrushPublicPipeFromTo"
            },
            {
              "Title": "批量刷物料管道来去向",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcBrushPipeFromTo"
            },
            {
              "Title": "根据数据ID更新接图箭头信息",
              "IconKey": "xx.bmp",
              "Command": "GsLcUpdateJoinDrawArrowByRePosition"
            },
            {
              "Title": "批量刷管道仪表块变等级号信息",
              "IconKey": "xx.bmp",
              "Command": "xxGsLcbrushPipeClassChangeMacro"
            },
            {
              "Title": "批量刷管道仪表块变管径信息",
              "IconKey": "xx.bmp",
              "Command": "xxGsLcbrushReducerInfoMacro"
            },
            {
              "Title": "批量生成或更新流程底部设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertBottomEquipTag"
            },
          ]
        },
        {
          "Title": "辅助绘图",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "插入所有组件块",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertAllElementBlock"
            },
            {
              "Title": "转换业主流程块为数据流块",
              "IconKey": "xx.bmp",
              "Command": "GsLcReplaceBlock"
            },
            {
              "Title": "管道仪表阀门自动编号",
              "IconKey": "xx.bmp",
              "Command": "GsLcEnhancedNumber"
            },
            {
              "Title": "绘制主物料管线",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcGeneratePipeLine"
            },
            {
              "Title": "绘制辅助物料管线",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcGeneratePublicPipeLine"
            },
            {
              "Title": "绘制仪表联锁线",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcGenerateInstrumentLine"
            },
            {
              "Title": "插入管道号块",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertPipeNumBlock"
            },
            {
              "Title": "自动生成接图箭头",
              "IconKey": "xx.bmp",
              "Command": "GsLcGenerateJoinDrawArrow"
            },
            {
              "Title": "刷接图箭头信息",
              "IconKey": "xx.bmp",
              "Command": "GsLcBrushJoinDrawArrowndFreeze"
            },
            {
              "Title": "跳转接图箭头",
              "IconKey": "xx.bmp",
              "Command": "GsLcJumpGraphArrow"
            },
            {
              "Title": "自动生成辅助流程图接图",
              "IconKey": "xx.bmp",
              "Command": "xx"
            }
          ]
        },
        {
          "Title": "插入设备位号块",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "插入所有组件块",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertAllElementBlock"
            },
            {
              "Title": "插入容器设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertEquipTagTank"
            },
            {
              "Title": "插入反应釜设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertEquipTagReactor"
            },
            {
              "Title": "插入泵设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertEquipTagPump"
            },
            {
              "Title": "插入换热器设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertEquipTagHeater"
            },
            {
              "Title": "插入离心机设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertEquipTagCentrifuge"
            },
            {
              "Title": "插入真空泵设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertEquipTagVacuum"
            },
            {
              "Title": "插入自定义设备位号",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertEquipTagCustomEquip"
            }
          ]
        },
        {
          "Title": "插入仪表相关块",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "插入所有组件块",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertAllElementBlock"
            },
            {
              "Title": "插入就地仪表",
              "IconKey": "就地仪表.bmp",
              "Command": "DLGsLcInsertInstrumentLBlock"
            },
            {
              "Title": "插入集中仪表",
              "IconKey": "集中仪表.bmp",
              "Command": "DLGsLcInsertInstrumentPBlock"
            },
            {
              "Title": "插入SIS仪表",
              "IconKey": "SIS仪表.bmp",
              "Command": "DLGsLcInsertInstrumentSISBlock"
            },
            {
              "Title": "插入DCS回路号",
              "IconKey": "DCS回路.bmp",
              "Command": "DLGsLcInsertInstrumentElementinterLockLogicBlock"
            },
            {
              "Title": "插入SIS回路号",
              "IconKey": "SIS回路.bmp",
              "Command": "DLGsLcInsertInstrumentElementinterLockLogicSISBlock"
            },
            {
              "Title": "插入开关阀",
              "IconKey": "开关阀.bmp",
              "Command": "DLGsLcInsertValveOnOffBlock"
            },
            {
              "Title": "插入调节阀",
              "IconKey": "调节阀.bmp",
              "Command": "DLGsLcInsertValveControlBlock"
            },
            {
              "Title": "插入自力式调节阀",
              "IconKey": "自力式调节阀.bmp",
              "Command": "DLGsLcInsertValveControlSelfOperateBlock"
            },
            {
              "Title": "插入底阀",
              "IconKey": "底阀.bmp",
              "Command": "DLGsLcInsertValveAutoBottomBlock"
            },
            {
              "Title": "插入隔膜调节阀",
              "IconKey": "隔膜调节阀.bmp",
              "Command": "DLGsLcInsertValveControlDiaphragmBlock"
            },
            {
              "Title": "插入三通调节阀",
              "IconKey": "三通调节阀.bmp",
              "Command": "DLGsLcInsertValveControlTeeBlock"
            },
            {
              "Title": "插入三通开关阀",
              "IconKey": "三通开关阀.bmp",
              "Command": "DLGsLcInsertValveOnOffTeeBlock"
            },
            {
              "Title": "插入三通隔膜开关阀",
              "IconKey": "三通隔膜开关阀.bmp",
              "Command": "DLGsLcInsertValveOnOffTeeDiaphragmBlock"
            },
            {
              "Title": "插入蝶阀开关阀",
              "IconKey": "蝶阀开关阀.bmp",
              "Command": "DLGsLcInsertValveOnOffButterflyBlock"
            },
            {
              "Title": "插入隔膜开关阀",
              "IconKey": "隔膜开关阀.bmp",
              "Command": "DLGsLcInsertValveOnOffDiaphragmBlock"
            },
            {
              "Title": "插入插板开关阀",
              "IconKey": "插板开关阀.bmp",
              "Command": "DLGsLcInsertValveOnOffFlapperBlock"
            }
          ]
        },
        {
          "Title": "插入阀门管件块",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "插入所有组件块",
              "IconKey": "xx.bmp",
              "Command": "DLGsLcInsertAllElementBlock"
            },
            {
              "Title": "插入球阀",
              "IconKey": "球阀.bmp",
              "Command": "DLGsLcInsertGlobalBlock"
            },
            {
              "Title": "插入三通球阀",
              "IconKey": "三通球阀.bmp",
              "Command": "DLGsLcInsertValveBallTeeBlock"
            },
            {
              "Title": "插入截止阀",
              "IconKey": "截止阀.bmp",
              "Command": "DLGsLcInsertValveGlobeBlock"
            },
            {
              "Title": "插入波纹管截止阀",
              "IconKey": "波纹管截止阀.bmp",
              "Command": "DLGsLcInsertValveGlobeRippleBlock"
            },
            {
              "Title": "插入减压阀",
              "IconKey": "减压阀.bmp",
              "Command": "DLGsLcInsertValvePressureReduceBlock"
            },
            {
              "Title": "插入止回阀",
              "IconKey": "止回阀.bmp",
              "Command": "DLGsLcInsertValveCheckBlock"
            },
            {
              "Title": "插入旋启式止回阀",
              "IconKey": "旋启式止回阀.bmp",
              "Command": "DLGsLcInsertValveCheckSwingBlock"
            },
            {
              "Title": "插入旋塞阀",
              "IconKey": "旋塞阀",
              "Command": "DLGsLcInsertValveCockBlock"
            },
            {
              "Title": "插入柱塞阀",
              "IconKey": "柱塞阀",
              "Command": "DLGsLcInsertValvePlungerBlock"
            },
            {
              "Title": "插入针型阀",
              "IconKey": "针型阀.bmp",
              "Command": "DLGsLcInsertValveNeedleBlock"
            },
            {
              "Title": "插入闸阀",
              "IconKey": "闸阀.bmp",
              "Command": "DLGsLcInsertValveGateBlock"
            },
            {
              "Title": "插入插板阀",
              "IconKey": "插板阀.bmp",
              "Command": "DLGsLcInsertValveFlapperBlock"
            },
            {
              "Title": "插入隔膜阀",
              "IconKey": "隔膜阀.bmp",
              "Command": "DLGsLcInsertValveDiaphragmBlock"
            },
            {
              "Title": "插入蝶阀",
              "IconKey": "蝶阀.bmp",
              "Command": "DLGsLcInsertValveButterflyBlock"
            },
            {
              "Title": "插入安全阀",
              "IconKey": "安全阀.bmp",
              "Command": "DLGsLcInsertValveSafetyBlock"
            },
            {
              "Title": "插入爆破片",
              "IconKey": "爆破片.bmp",
              "Command": "DLGsLcInsertValveBlastBlock"
            },
            {
              "Title": "插入疏水阀",
              "IconKey": "疏水阀.bmp",
              "Command": "DLGsLcInsertValveTrapBlock"
            },
            {
              "Title": "插入呼吸阀",
              "IconKey": "呼吸阀.bmp",
              "Command": "DLGsLcInsertValveBreathBlock"
            },
            {
              "Title": "插入带阻火器呼吸阀",
              "IconKey": "带阻火器呼吸阀.bmp",
              "Command": "DLGsLcInsertValveBreathFlameArrestBlock"
            },
            {
              "Title": "插入金属软管",
              "IconKey": "金属软管.bmp",
              "Command": "DLGsLcInsertValveMetalHoseBlock"
            },
            {
              "Title": "插入挠性软管",
              "IconKey": "挠性软管.bmp",
              "Command": "DLGsLcInsertValveFlexibleHoseBlock"
            }
          ]
        },
        {
          "Title": "其他工具",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "不保存并关闭除当前窗口的所有文件",
              "IconKey": "编辑",
              "Command": "DLCommonCloseExceptCurrentDwgNoSave"
            },
            {
              "Title": "打散块保留属性文字",
              "IconKey": "编辑",
              "Command": "ExplodeBlockAndConvertDBText"
            },
            {
              "Title": "修改块基点",
              "IconKey": "编辑",
              "Command": "DLCommandModifyBlockBasePoint"
            },
            {
              "Title": "批量替换块",
              "IconKey": "编辑",
              "Command": "GsLcReplaceBlock"
            },
            {
              "Title": "批量垂直对齐块",
              "IconKey": "编辑",
              "Command": "DLCommonVerticalAlignMultiBlcok"
            },
            {
              "Title": "批量水平对齐块",
              "IconKey": "编辑",
              "Command": "DLCommonHorizontalAlignMultiBlcok"
            },
            {
              "Title": "同步块并保留文字位置",
              "IconKey": "编辑",
              "Command": "SyncBrAttrs"
            },
            {
              "Title": "修改块属性文字高度",
              "IconKey": "编辑",
              "Command": "DLCommandModifyBlockTextHeight"
            }
          ]
        }
      ]
    },
    {
      "TabName": "二维配管",
      "MenuGroups": [
        {
          "Title": "一键修改功能",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "一键生成辅助管道块",
              "IconKey": "second",
              "Command": "GsPgGeneratePipeArrowBlock"
            },
            {
              "Title": "一键切图",
              "IconKey": "second",
              "Command": "GsPgCutDraw"
            },
            {
              "Title": "一键生成轴线号标注",
              "IconKey": "second",
              "Command": "GsPgAxisToPaperSpace"
            },
            {
              "Title": "一键生成楼层标高和指北针",
              "IconKey": "second",
              "Command": "DLGsPgInsertFloorElevAndCompass"
            },
            {
              "Title": "一键生成分界线接图图号",
              "IconKey": "second",
              "Command": "GsPgGenerateDrawingConnection"
            },
            {
              "Title": "一键标注切图边界管道定位",
              "IconKey": "second",
              "Command": "GsPgGeneratePipePositionDimension"
            },
            {
              "Title": "一键生成成品管道和箭头",
              "IconKey": "second",
              "Command": "GsPgInsertPipeElementArrowOnPipeArrowAssist"
            },
            {
              "Title": "一键更新成品管道号标注",
              "IconKey": "second",
              "Command": "GsPgUpdatePipeElementArrow"
            },
            {
              "Title": "一键管架自动编号",
              "IconKey": "second",
              "Command": "DLGsPgNumberPipeRack"
            },
            {
              "Title": "一键校验PL管道数据",
              "IconKey": "second",
              "Command": "DLGsPgCheckPipeLineSynchroStatus"
            }
          ]
        },
        {
          "Title": "批量修改功能",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "批量同步数据-DPS",
              "IconKey": "second",
              "Command": "DPS"
            },
            {
              "Title": "批量调整管道净距",
              "IconKey": "second",
              "Command": "GsPgAdjustTotalPipe"
            },
            {
              "Title": "批量打断管道",
              "IconKey": "second",
              "Command": "DLGsPgBreakPipePolyLineBySelect"
            },
            {
              "Title": "批量更新弯头状态",
              "IconKey": "second",
              "Command": "DLGsPgSynchroniseElbowDire"
            },
            {
              "Title": "批量标注箭头块",
              "IconKey": "second",
              "Command": "GsPgInsertPipeElementArrowGraphAutoDir"
            },
            {
              "Title": "批量标注成品管道号",
              "IconKey": "second",
              "Command": "GsPgInsertPipeElementArrowBySelect"
            },
            {
              "Title": "批量设备位号旁成品管道号",
              "IconKey": "second",
              "Command": "GsPgInsertPipeElementArrowByEquipTag"
            },
            {
              "Title": "批量更新成品管道号",
              "IconKey": "second",
              "Command": "GsPgUpdatePipeElementArrowBySelect"
            },
            {
              "Title": "批量标注阀门管件定位",
              "IconKey": "second",
              "Command": "GsPgDrawBatchPipePosDim"
            },
            {
              "Title": "批量前置块",
              "IconKey": "second",
              "Command": "DLGsPgBatchFrontBlock"
            },
            {
              "Title": "批量后置块",
              "IconKey": "second",
              "Command": "DLGsPgBatchBehindBlock"
            }
          ]
        },
        {
          "Title": "辅助绘图",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "插入所有组件块",
              "IconKey": "second",
              "Command": "GsPgInsertAllPipeElementLisp"
            },
            {
              "Title": "绘制单线管道-DPL",
              "IconKey": "second",
              "Command": "DPL"
            },
            {
              "Title": "绘制双线管道-DPK",
              "IconKey": "second",
              "Command": "DPK"
            },
            {
              "Title": "弯头块切换到终止DPS图层",
              "IconKey": "second",
              "Command": "DLGsPgSwitchDPSBreakLayer"
            },
            {
              "Title": "总管支管自动连接",
              "IconKey": "second",
              "Command": "DLGsPgConnectMainAndBrunchPipeLine"
            },
            {
              "Title": "绘制切图视口矩形",
              "IconKey": "second",
              "Command": "GsPgDrawCutRange"
            }
          ]
        },
        {
          "Title": "插入阀门管件块",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "插入所有组件块",
              "IconKey": "xx.bmp",
              "Command": "GsPgInsertAllPipeElementLisp"
            },
            {
              "Title": "插入数据源管道块",
              "IconKey": "second",
              "Command": "DLGsPgInsertPipeElementArrowAssistBlock"
            },
            {
              "Title": "插入开关阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveOnOffBlock"
            },
            {
              "Title": "插入调节阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveControlBlock"
            },
            {
              "Title": "插入球阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveBallBlock"
            },
            {
              "Title": "插入截止阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveGlobeBlock"
            },
            {
              "Title": "插入闸阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveGateBlock"
            },
            {
              "Title": "插入蝶阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveButterflyBlock"
            },
            {
              "Title": "插入止回阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveCheckBlock"
            },
            {
              "Title": "插入隔膜阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveDiaphragmBlock"
            },
            {
              "Title": "插入疏水阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveTrapBlock"
            },
            {
              "Title": "插入安全阀",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveSafetyBlock"
            },
            {
              "Title": "插入Y型过滤器",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveFilterYBlock"
            },
            {
              "Title": "插入篮式过滤器",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveFilterBasketBlock"
            },
            {
              "Title": "插入金属软件",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveHoseBlock"
            },
            {
              "Title": "插入弯头",
              "IconKey": "second",
              "Command": "DLGsPgInsertPipeElementElbowBlock"
            },
            {
              "Title": "插入双线弯头",
              "IconKey": "second",
              "Command": "DLGsPgInsertPipeElementElbowDoubleLineBlock"
            },
            {
              "Title": "插入异径管",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveReducerBlock"
            },
            {
              "Title": "插入法兰盖",
              "IconKey": "second",
              "Command": "DLGsPgInsertValveFlangeCoverBlock"
            },
            {
              "Title": "管架块",
              "IconKey": "second",
              "Command": "DLGsPgInsertGraphPipeRackBlock"
            }
          ]
        }
      ]
    },
    {
      "TabName": "设备布置",
      "MenuGroups": [
        {
          "Title": "设备布置菜单1",
          "IconKey": "xx.bmp",
          "Items": [
            {
              "Title": "设备布置菜单1-1",
              "IconKey": "second",
              "Command": "LINE"
            },
            {
              "Title": "设备布置菜单1-2",
              "IconKey": "second",
              "Command": "RECTANGLE"
            }
          ]
        }
      ]
    }
  ]
} 
```