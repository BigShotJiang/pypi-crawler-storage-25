"""
错误重试机制测试脚本

测试前确保：
1. CAD 已启动
2. cad-cowork-cstool 插件已加载
"""

import logging

# 配置日志，以便看到重试信息
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

from cad_controller import CADController


def test_normal_execution():
    """测试1：正常执行（不触发重试）"""
    print("\n" + "="*50)
    print("测试1：正常执行（预期：一次成功，无重试）")
    print("="*50)

    controller = CADController()
    if not controller.start_cad():
        print("❌ 无法连接 CAD")
        return False

    # 正常超时时间，应该一次成功
    result = controller.execute_api_command(
        "api_draw_circle",
        {"center": [100, 100, 0], "radius": 30},
        timeout=30.0
    )

    print(f"结果: {result}")

    if result.get("success"):
        print("✅ 测试通过：命令正常执行，无需重试")
        return True
    else:
        print(f"❌ 测试失败：{result.get('message')}")
        return False


def test_timeout_retry():
    """测试2：强制超时触发重试"""
    print("\n" + "="*50)
    print("测试2：强制超时（预期：重试3次后失败）")
    print("="*50)

    controller = CADController()
    if not controller.start_cad():
        print("❌ 无法连接 CAD")
        return False

    # 设置极短超时时间（0.01秒 = 10ms），强制触发超时
    # 轮询间隔是 50ms，所以 10ms 超时肯定无法读取结果
    result = controller.execute_api_command(
        "api_draw_circle",
        {"center": [200, 200, 0], "radius": 20},
        timeout=0.01  # 10ms，肯定会超时
    )

    print(f"结果: {result}")

    # 检查是否显示重试信息
    if "已重试 3 次" in result.get("message", ""):
        print("✅ 测试通过：检测到重试机制生效")
        return True
    else:
        print("⚠️ 结果不符合预期，请检查日志")
        return False


def test_non_timeout_error():
    """测试3：非超时错误（不应重试）"""
    print("\n" + "="*50)
    print("测试3：非超时错误（预期：直接返回错误，不重试）")
    print("="*50)

    controller = CADController()
    if not controller.start_cad():
        print("❌ 无法连接 CAD")
        return False

    # 调用不存在的命令，应该直接返回错误，不重试
    result = controller.execute_api_command(
        "invalid_command_name_12345",
        {},
        timeout=30.0
    )

    print(f"结果: {result}")

    # 非超时错误不应该有重试信息
    if "已重试" not in result.get("message", ""):
        print("✅ 测试通过：非超时错误未触发重试")
        return True
    else:
        print("❌ 测试失败：非超时错误不应该重试")
        return False


if __name__ == "__main__":
    print("错误重试机制测试")
    print("观察日志中的 WARNING 信息，可以看到重试过程")

    results = []

    # 运行测试
    results.append(("正常执行", test_normal_execution()))
    results.append(("超时重试", test_timeout_retry()))
    results.append(("非超时错误", test_non_timeout_error()))

    # 汇总结果
    print("\n" + "="*50)
    print("测试汇总")
    print("="*50)
    for name, passed in results:
        status = "✅ 通过" if passed else "❌ 失败"
        print(f"  {name}: {status}")
