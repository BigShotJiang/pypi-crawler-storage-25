## AutoCAD 功能命令清单

### 一、工艺流程

#### 1.1 数据处理
| 功能名称 | 命令 |
|---------|------|
| 导出项目信息关联软件（废弃，用户手动填项目信息） | ExportDDProjectInfoBySelect |
| 导出数据（已封装为API） | GsLcExportCADData |
| 同步数据 | DLGsLcSysDataFromClient |

#### 1.2 一键修改功能
| 功能名称 | 命令 |
|---------|------|
| 一键刷仪表所在位置 | GsLcAutoBrushInstrumentLocation |
| 一键根据相对位置更新校验仪表所在位置 | GsLcUpdateInstrumentLocation |
| 一键刷阀门所在位置 | GsLcAutoBrushValveLocation |
| 一键根据相对位置更新校验阀门所在位置 | GsLcUpdateValveLocation |
| 一键刷管道来去向 | GsLcAutoBrushPipelineFromTo |
| 一键根据相对位置更新校验管道来去向 | GsLcUpdatePipelineFromTo |
| 一键更新数据所在流程图号 | UpdateDrawGsLcDrawNumData |
| 一键更新公用工程块物料代号 | GsLcAutoBrushPublicPipelineCode |
| 一键打断流程图管道仪表交叉 | GsLcInterruptPipeline |
| 一键生成或更新流程底部设备位号 | DLGsLcInsertAllBottomEquipTag |
| 一键关联外管箭头块与管道块 | GsLcAutoAssociateOuterPipeArrowBlockAndPipeBlock |
| 一键前置仪表阀门块 | GsLcFrontInstrumentAndValve |

#### 1.3 批量修改功能
| 功能名称 | 命令 |
|---------|------|
| 批量刷仪表阀门所在位置 | DLGsLcBrushInstrumentLocation |
| 批量刷公用管道来去向 | DLGsLcBrushPublicPipeFromTo |
| 批量刷物料管道来去向 | DLGsLcBrushPipeFromTo |
| 根据数据ID更新接图箭头信息 | GsLcUpdateJoinDrawArrowByRePosition |
| 批量刷管道仪表块变等级号信息 | xxGsLcbrushPipeClassChangeMacro |
| 批量刷管道仪表块变管径信息 | xxGsLcbrushReducerInfoMacro |
| 批量生成或更新流程底部设备位号 | DLGsLcInsertBottomEquipTag |

#### 1.4 辅助绘图
| 功能名称 | 命令 |
|---------|------|
| 插入所有组件块 | DLGsLcInsertAllElementBlock |
| 转换业主流程块为数据流块 | GsLcReplaceBlock |
| 管道仪表阀门自动编号 | GsLcEnhancedNumber |
| 绘制主物料管线 | DLGsLcGeneratePipeLine |
| 绘制辅助物料管线 | DLGsLcGeneratePublicPipeLine |
| 绘制仪表联锁线 | DLGsLcGenerateInstrumentLine |
| 插入管道号块 | DLGsLcInsertPipeNumBlock |
| 自动生成接图箭头 | GsLcGenerateJoinDrawArrow |
| 刷接图箭头信息 | GsLcBrushJoinDrawArrowndFreeze |
| 跳转接图箭头 | GsLcJumpGraphArrow |
| 自动生成辅助流程图接图 | xx |

#### 1.5 插入设备位号块
| 功能名称 | 命令 |
|---------|------|
| 插入所有组件块 | DLGsLcInsertAllElementBlock |
| 插入容器设备位号 | DLGsLcInsertEquipTagTank |
| 插入反应釜设备位号 | DLGsLcInsertEquipTagReactor |
| 插入泵设备位号 | DLGsLcInsertEquipTagPump |
| 插入换热器设备位号 | DLGsLcInsertEquipTagHeater |
| 插入离心机设备位号 | DLGsLcInsertEquipTagCentrifuge |
| 插入真空泵设备位号 | DLGsLcInsertEquipTagVacuum |
| 插入自定义设备位号 | DLGsLcInsertEquipTagCustomEquip |

#### 1.6 插入仪表相关块
| 功能名称 | 命令 |
|---------|------|
| 插入所有组件块 | DLGsLcInsertAllElementBlock |
| 插入就地仪表 | DLGsLcInsertInstrumentLBlock |
| 插入集中仪表 | DLGsLcInsertInstrumentPBlock |
| 插入SIS仪表 | DLGsLcInsertInstrumentSISBlock |
| 插入DCS回路号 | DLGsLcInsertInstrumentElementinterLockLogicBlock |
| 插入SIS回路号 | DLGsLcInsertInstrumentElementinterLockLogicSISBlock |
| 插入开关阀 | DLGsLcInsertValveOnOffBlock |
| 插入调节阀 | DLGsLcInsertValveControlBlock |
| 插入自力式调节阀 | DLGsLcInsertValveControlSelfOperateBlock |
| 插入底阀 | DLGsLcInsertValveAutoBottomBlock |
| 插入隔膜调节阀 | DLGsLcInsertValveControlDiaphragmBlock |
| 插入三通调节阀 | DLGsLcInsertValveControlTeeBlock |
| 插入三通开关阀 | DLGsLcInsertValveOnOffTeeBlock |
| 插入三通隔膜开关阀 | DLGsLcInsertValveOnOffTeeDiaphragmBlock |
| 插入蝶阀开关阀 | DLGsLcInsertValveOnOffButterflyBlock |
| 插入隔膜开关阀 | DLGsLcInsertValveOnOffDiaphragmBlock |
| 插入插板开关阀 | DLGsLcInsertValveOnOffFlapperBlock |

#### 1.7 插入阀门管件块
| 功能名称 | 命令 |
|---------|------|
| 插入所有组件块 | DLGsLcInsertAllElementBlock |
| 插入球阀 | DLGsLcInsertGlobalBlock |
| 插入三通球阀 | DLGsLcInsertValveBallTeeBlock |
| 插入截止阀 | DLGsLcInsertValveGlobeBlock |
| 插入波纹管截止阀 | DLGsLcInsertValveGlobeRippleBlock |
| 插入减压阀 | DLGsLcInsertValvePressureReduceBlock |
| 插入止回阀 | DLGsLcInsertValveCheckBlock |
| 插入旋启式止回阀 | DLGsLcInsertValveCheckSwingBlock |
| 插入旋塞阀 | DLGsLcInsertValveCockBlock |
| 插入柱塞阀 | DLGsLcInsertValvePlungerBlock |
| 插入针型阀 | DLGsLcInsertValveNeedleBlock |
| 插入闸阀 | DLGsLcInsertValveGateBlock |
| 插入插板阀 | DLGsLcInsertValveFlapperBlock |
| 插入隔膜阀 | DLGsLcInsertValveDiaphragmBlock |
| 插入蝶阀 | DLGsLcInsertValveButterflyBlock |
| 插入安全阀 | DLGsLcInsertValveSafetyBlock |
| 插入爆破片 | DLGsLcInsertValveBlastBlock |
| 插入疏水阀 | DLGsLcInsertValveTrapBlock |
| 插入呼吸阀 | DLGsLcInsertValveBreathBlock |
| 插入带阻火器呼吸阀 | DLGsLcInsertValveBreathFlameArrestBlock |
| 插入金属软管 | DLGsLcInsertValveMetalHoseBlock |
| 插入挠性软管 | DLGsLcInsertValveFlexibleHoseBlock |

#### 1.8 其他工具
| 功能名称 | 命令 |
|---------|------|
| 不保存并关闭除当前窗口的所有文件 | DLCommonCloseExceptCurrentDwgNoSave |
| 打散块保留属性文字 | ExplodeBlockAndConvertDBText |
| 修改块基点 | DLCommandModifyBlockBasePoint |
| 批量替换块 | GsLcReplaceBlock |
| 批量垂直对齐块 | DLCommonVerticalAlignMultiBlcok |
| 批量水平对齐块 | DLCommonHorizontalAlignMultiBlcok |
| 同步块并保留文字位置 | SyncBrAttrs |
| 修改块属性文字高度 | DLCommandModifyBlockTextHeight |

### 二、二维配管

#### 2.1 一键修改功能
| 功能名称 | 命令 |
|---------|------|
| 一键生成辅助管道块 | GsPgGeneratePipeArrowBlock |
| 一键切图 | GsPgCutDraw |
| 一键生成轴线号标注 | GsPgAxisToPaperSpace |
| 一键生成楼层标高和指北针 | DLGsPgInsertFloorElevAndCompass |
| 一键生成分界线接图图号 | GsPgGenerateDrawingConnection |
| 一键标注切图边界管道定位 | GsPgGeneratePipePositionDimension |
| 一键生成成品管道和箭头 | GsPgInsertPipeElementArrowOnPipeArrowAssist |
| 一键更新成品管道号标注 | GsPgUpdatePipeElementArrow |
| 一键管架自动编号 | DLGsPgNumberPipeRack |
| 一键校验PL管道数据 | DLGsPgCheckPipeLineSynchroStatus |

#### 2.2 批量修改功能
| 功能名称 | 命令 |
|---------|------|
| 批量同步数据-DPS | DPS |
| 批量调整管道净距 | GsPgAdjustTotalPipe |
| 批量打断管道 | DLGsPgBreakPipePolyLineBySelect |
| 批量更新弯头状态 | DLGsPgSynchroniseElbowDire |
| 批量标注箭头块 | GsPgInsertPipeElementArrowGraphAutoDir |
| 批量标注成品管道号 | GsPgInsertPipeElementArrowBySelect |
| 批量设备位号旁成品管道号 | GsPgInsertPipeElementArrowByEquipTag |
| 批量更新成品管道号 | GsPgUpdatePipeElementArrowBySelect |
| 批量标注阀门管件定位 | GsPgDrawBatchPipePosDim |
| 批量前置块 | DLGsPgBatchFrontBlock |
| 批量后置块 | DLGsPgBatchBehindBlock |

#### 2.3 辅助绘图
| 功能名称 | 命令 |
|---------|------|
| 插入所有组件块 | GsPgInsertAllPipeElementLisp |
| 绘制单线管道-DPL | DPL |
| 绘制双线管道-DPK | DPK |
| 弯头块切换到终止DPS图层 | DLGsPgSwitchDPSBreakLayer |
| 总管支管自动连接 | DLGsPgConnectMainAndBrunchPipeLine |
| 绘制切图视口矩形 | GsPgDrawCutRange |

#### 2.4 插入阀门管件块
| 功能名称 | 命令 |
|---------|------|
| 插入所有组件块 | GsPgInsertAllPipeElementLisp |
| 插入数据源管道块 | DLGsPgInsertPipeElementArrowAssistBlock |
| 插入开关阀 | DLGsPgInsertValveOnOffBlock |
| 插入调节阀 | DLGsPgInsertValveControlBlock |
| 插入球阀 | DLGsPgInsertValveBallBlock |
| 插入截止阀 | DLGsPgInsertValveGlobeBlock |
| 插入闸阀 | DLGsPgInsertValveGateBlock |
| 插入蝶阀 | DLGsPgInsertValveButterflyBlock |
| 插入止回阀 | DLGsPgInsertValveCheckBlock |
| 插入隔膜阀 | DLGsPgInsertValveDiaphragmBlock |
| 插入疏水阀 | DLGsPgInsertValveTrapBlock |
| 插入安全阀 | DLGsPgInsertValveSafetyBlock |
| 插入Y型过滤器 | DLGsPgInsertValveFilterYBlock |
| 插入篮式过滤器 | DLGsPgInsertValveFilterBasketBlock |
| 插入金属软件 | DLGsPgInsertValveHoseBlock |
| 插入弯头 | DLGsPgInsertPipeElementElbowBlock |
| 插入双线弯头 | DLGsPgInsertPipeElementElbowDoubleLineBlock |
| 插入异径管 | DLGsPgInsertValveReducerBlock |
| 插入法兰盖 | DLGsPgInsertValveFlangeCoverBlock |
| 管架块 | DLGsPgInsertGraphPipeRackBlock |

### 三、设备布置

#### 3.1 设备布置菜单1
| 功能名称 | 命令 |
|---------|------|
| 设备布置菜单1-1 | LINE |
| 设备布置菜单1-2 | RECTANGLE |

---

**统计汇总：**
- 工艺流程：共 88 个功能命令
- 二维配管：共 47 个功能命令
- 设备布置：共 2 个功能命令
- **总计：137 个功能命令**

这份清单已经按照原文件的层级结构整理完成。需要我将其导出为 Markdown 文件吗？

---