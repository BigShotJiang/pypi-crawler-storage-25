"""
Manifest 解析器和共享数据结构

从 api_commands_manifest.json 解析命令参数定义。
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field


@dataclass
class Parameter:
    """参数定义（共享数据类）"""
    name: str
    required: bool
    default_value: Optional[Any] = None
    aliases: List[str] = field(default_factory=list)
    type: Optional[str] = None        # 参数类型（如 String, Integer, Point3D）
    description: Optional[str] = None # 参数描述
    mutual_exclusion_groups: List[str] = field(default_factory=list)  # 互斥参数组ID
    recommended_in_group: bool = False  # 在互斥组中是否为推荐参数


@dataclass
class CommandParams:
    """命令参数集合（共享数据类）"""
    command_name: str
    required: List[str]  # 必需参数名列表
    optional: List[str]  # 可选参数名列表
    params: Dict[str, Parameter]  # 参数详细信息（key: 参数名）


class ManifestParser:
    """Manifest JSON 解析器（共享）"""

    def __init__(self, manifest_path: Path):
        self.manifest_path = Path(manifest_path)
        self.data: Optional[Dict] = None

    def load(self) -> Dict:
        """加载 manifest 文件"""
        with open(self.manifest_path, 'r', encoding='utf-8-sig') as f:
            self.data = json.load(f)
        return self.data

    def get_all_commands(self) -> Dict[str, CommandParams]:
        """
        获取所有命令的参数定义

        Returns:
            Dict[命令名, CommandParams]
        """
        if not self.data:
            self.load()

        result = {}
        for category in self.data.get('categories', []):
            for cmd in category.get('commands', []):
                cmd_name = cmd['name']
                params_dict = {}
                required = []
                optional = []

                for param in cmd.get('parameters', []):
                    param_name = param['name']
                    is_required = param.get('required', False)
                    default_value = param.get('defaultValue')
                    aliases = param.get('aliases', []) or []
                    param_type = param.get('type')
                    description = param.get('description')
                    # 解析互斥信息（新增，使用 .get() 确保向后兼容）
                    mutex_groups = param.get('mutualExclusionGroups', []) or []
                    recommended = param.get('recommendedInGroup', False)

                    params_dict[param_name] = Parameter(
                        name=param_name,
                        required=is_required,
                        default_value=default_value,
                        aliases=aliases,
                        type=param_type,
                        description=description,
                        mutual_exclusion_groups=mutex_groups,
                        recommended_in_group=recommended
                    )

                    if is_required:
                        required.append(param_name)
                    else:
                        optional.append(param_name)

                result[cmd_name] = CommandParams(
                    command_name=cmd_name,
                    required=required,
                    optional=optional,
                    params=params_dict
                )

        return result

    def get_command_category(self, cmd_name: str) -> Optional[str]:
        """
        获取命令所属类别的 nameEn

        Args:
            cmd_name: 命令名（如 api_draw_circle）

        Returns:
            类别名（如 'drawing'），不存在则返回 None
        """
        if not self.data:
            self.load()

        for category in self.data.get('categories', []):
            for cmd in category.get('commands', []):
                if cmd['name'] == cmd_name:
                    return category.get('nameEn', category.get('name'))

        return None
