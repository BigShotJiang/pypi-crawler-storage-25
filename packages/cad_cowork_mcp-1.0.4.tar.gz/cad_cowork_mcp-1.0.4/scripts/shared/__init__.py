"""
共享模块

提供 ManifestParser 和数据类供验证脚本和生成脚本复用。
"""

from .manifest_parser import Parameter, CommandParams, ManifestParser

__all__ = ['Parameter', 'CommandParams', 'ManifestParser']
