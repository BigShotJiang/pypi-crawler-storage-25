#!/usr/bin/env python3
"""
参数速查表自动生成工具

功能：
1. 从 api_commands_manifest.json 读取参数定义
2. 检测互斥参数（如 entityHandle/entityHandles）
3. 格式化默认值（如 defaultValue(默认value)）
4. 生成 Markdown 表格
5. 更新 cad_system_prompt.md 中的区域标记内容

使用：
    python generate_param_table.py --preview        # 预览模式
    python generate_param_table.py --update         # 更新文档
    python generate_param_table.py --output file.md # 输出到指定文件
"""

import re
import sys
import argparse
from pathlib import Path
from typing import Dict, List, Set, Tuple, Optional
from dataclasses import dataclass, field

# 导入共享模块
from shared.manifest_parser import Parameter, CommandParams, ManifestParser


# ============================================================================
# 数据类
# ============================================================================

@dataclass
class MutuallyExclusiveGroup:
    """互斥参数组"""
    params: List[str]  # 参数名列表
    hint: Optional[str] = None  # 消歧说明
    recommended: Optional[str] = None  # 推荐参数


@dataclass
class TableRow:
    """速查表行数据"""
    command_name: str
    required_params: List[str]
    optional_params: List[Tuple[str, Optional[str]]]  # (param_name, default_value_formatted)
    mutual_exclusive_groups: List[MutuallyExclusiveGroup] = field(default_factory=list)


@dataclass
class TableSection:
    """速查表分节"""
    section_name: str  # 如 "绘图类"
    commands: List[TableRow] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)  # [二选一] 等说明


# ============================================================================
# 核心类 1: 互斥参数检测器
# ============================================================================

class MutualExclusionDetector:
    """互斥参数检测器"""

    # 静态规则（已知模式，高优先级）
    KNOWN_MUTEXES = {
        # 修改类：单个/批量操作
        'api_move_entity': [('entityHandle', 'entityHandles')],
        'api_copy_entity': [('entityHandle', 'entityHandles')],
        'api_rotate_entity': [('entityHandle', 'entityHandles')],
        'api_scale_entity': [('entityHandle', 'entityHandles')],
        'api_mirror_entity': [('entityHandle', 'entityHandles')],
        'api_set_entity_layer': [('entityHandle', 'entityHandles')],
        'api_set_entity_color': [('entityHandle', 'entityHandles')],
        'api_set_entity_properties': [('entityHandle', 'entityHandles')],
        'api_delete_entity': [('entityHandle', 'entityHandles')],

        # 绘图类：边界句柄 vs 点列表
        'api_create_hatch': [('boundaryHandles', 'points')],

        # 批量类：详细模式 vs 简化模式
        'api_batch_insert_blocks': [
            ('insertions', 'blockName'),
            ('insertions', 'insertionPoints')
        ],

        # 空间计算：点 vs 实体句柄
        'api_calc_distance': [
            ('point1', 'entityHandle1'),
            ('point2', 'entityHandle2')
        ],
        'api_calc_bounding_box': [('entityHandle', 'entityHandles')],

        # 导入类：单个 vs 批量
        'api_import_block_from_external': [('blockName', 'blockNames')],
        'api_import_layer_from_external': [('layerName', 'layerNames')],

        # 视图控制
        'api_zoom_object': [('entityHandle', 'entityHandles')],

        # 块操作
        'api_modify_block_base_point': [('entityHandle', 'blockName')],
    }

    def detect(self, command: CommandParams, cmd_name: str) -> List[MutuallyExclusiveGroup]:
        """检测互斥参数组（manifest 优先）"""
        groups = []

        # 层0：Manifest 互斥信息（最高优先级，新增）
        manifest_groups = self._detect_from_manifest(command)
        if manifest_groups:
            return manifest_groups  # 有 manifest 数据则直接返回

        # 层1：静态规则（fallback）
        if cmd_name in self.KNOWN_MUTEXES:
            for params_tuple in self.KNOWN_MUTEXES[cmd_name]:
                # 检查这些参数是否都存在于命令的可选参数中
                if all(p in command.optional for p in params_tuple):
                    groups.append(MutuallyExclusiveGroup(
                        params=list(params_tuple),
                        recommended=self._determine_recommended(params_tuple, cmd_name)
                    ))

        # 层2：模式匹配（单复数检测）
        singular_plural = self._detect_singular_plural(set(command.optional))
        for pair in singular_plural:
            # 避免重复检测
            if not any(set(g.params) == set(pair) for g in groups):
                groups.append(MutuallyExclusiveGroup(
                    params=list(pair)
                ))

        return groups

    def _detect_from_manifest(self, command: CommandParams) -> List[MutuallyExclusiveGroup]:
        """从 manifest 提取互斥信息（新增方法）"""
        groups_dict = {}  # {group_id: [param_names]}
        recommended_dict = {}  # {group_id: recommended_param}

        # 遍历所有参数，按组ID聚合
        for param_name, param in command.params.items():
            if not param.mutual_exclusion_groups:
                continue

            for group_id in param.mutual_exclusion_groups:
                if group_id not in groups_dict:
                    groups_dict[group_id] = []
                groups_dict[group_id].append(param_name)

                if param.recommended_in_group:
                    recommended_dict[group_id] = param_name

        # 转换为 MutuallyExclusiveGroup 对象
        result = []
        for group_id, param_names in groups_dict.items():
            if len(param_names) >= 2:  # 至少 2 个参数才算互斥组
                result.append(MutuallyExclusiveGroup(
                    params=param_names,
                    recommended=recommended_dict.get(group_id)
                ))

        return result

    def _detect_singular_plural(self, params: Set[str]) -> List[Tuple[str, str]]:
        """检测单复数参数对（如 entityHandle/entityHandles）"""
        pairs = []
        checked = set()

        for p1 in params:
            if p1 in checked:
                continue

            # 简单 's' 后缀检测
            if p1 + 's' in params:
                pairs.append((p1, p1 + 's'))
                checked.add(p1)
                checked.add(p1 + 's')
            # Handle -> Handles 模式
            elif p1.endswith('Handle') and p1 + 's' in params:
                pairs.append((p1, p1 + 's'))
                checked.add(p1)
                checked.add(p1 + 's')

        return pairs

    def _determine_recommended(self, params: Tuple[str, ...], cmd_name: str) -> Optional[str]:
        """智能推荐参数"""

        # 规则1：边界句柄优于点（更精确）
        if 'boundaryHandles' in params and 'points' in params:
            return 'boundaryHandles'

        # 规则2：详细模式优于简化模式
        if 'insertions' in params:
            return 'insertions'

        # 规则3：批量优于单个（效率更高）
        if any(p.endswith('Handles') for p in params):
            return next(p for p in params if p.endswith('Handles'))

        # 规则4：批量名称优于单个
        if any(p.endswith('Names') for p in params):
            return next(p for p in params if p.endswith('Names'))

        return None


# ============================================================================
# 核心类 2: 默认值格式化器
# ============================================================================

class DefaultValueFormatter:
    """默认值格式化器"""

    @staticmethod
    def should_show_default(param: Parameter) -> bool:
        """判断是否需要标注默认值"""
        if param.default_value is None:
            return False

        # null/0/空字符串不标注
        if param.default_value in [None, "null", "", 0, 0.0]:
            return False

        # 字符串 "0" 也不标注
        if isinstance(param.default_value, str) and param.default_value == "0":
            return False

        # 布尔型必须标注
        if isinstance(param.default_value, bool):
            return True

        # 非零数值必须标注
        if isinstance(param.default_value, (int, float)) and param.default_value != 0:
            return True

        # 枚举型必须标注（字符串且有值）
        if isinstance(param.default_value, str) and param.default_value:
            return True

        return False

    @staticmethod
    def format_default(param: Parameter) -> str:
        """格式化默认值：paramName(默认value)"""
        value = param.default_value

        if isinstance(value, bool):
            return f"默认{str(value).lower()}"
        elif isinstance(value, (int, float)):
            return f"默认{value}"
        else:
            return f"默认{value}"


# ============================================================================
# 核心类 3: 类别映射器
# ============================================================================

class CategoryMapper:
    """类别映射器（manifest 类别 → 文档分组）"""

    CATEGORY_MAPPING = {
        # manifest nameEn → 文档分组名（支持中英文）
        "drawing": "绘图类",
        "query": "查询类",
        "block": "块操作类",
        "batch": "批量类",
        "modification": "修改类",
        "spatial": "空间计算类",
        "layer": "图层类",
        "document": "文档管理类",
        "view": "视图控制类",
        "selection": "选择集类",
        "transaction": "事务控制类",
        "gslc": None,  # GsLc 不在速查表中（命令太多，有专门的章节）

        # 中文类别名（manifest 中的 nameEn 字段使用了中文）
        "图层": "图层类",
        "文档": "文档管理类",
        "修改": "修改类",
        "视图": "视图控制类",
    }

    @classmethod
    def map_category(cls, manifest_category: str) -> Optional[str]:
        """映射类别"""
        return cls.CATEGORY_MAPPING.get(manifest_category)


# ============================================================================
# 核心类 4: 参数表生成器
# ============================================================================

class ParameterTableGenerator:
    """参数速查表生成器"""

    def __init__(self, manifest_path: Path):
        self.manifest_parser = ManifestParser(manifest_path)
        self.detector = MutualExclusionDetector()
        self.formatter = DefaultValueFormatter()
        self.mapper = CategoryMapper()

    def generate(self) -> Dict[str, TableSection]:
        """生成所有分节的速查表"""
        manifest_cmds = self.manifest_parser.get_all_commands()

        sections = {}
        for cmd_name, cmd_params in manifest_cmds.items():
            # 获取分组名
            category_en = self.manifest_parser.get_command_category(cmd_name)
            section_name = self.mapper.map_category(category_en)

            if section_name is None:
                continue  # 跳过 GsLc 等

            # 检测互斥参数
            mutual_groups = self.detector.detect(cmd_params, cmd_name)

            # 格式化可选参数（含默认值）
            optional_with_defaults = []
            for param_name in cmd_params.optional:
                param = cmd_params.params[param_name]
                default_str = None
                if self.formatter.should_show_default(param):
                    default_str = self.formatter.format_default(param)
                optional_with_defaults.append((param_name, default_str))

            # 创建表格行
            row = TableRow(
                command_name=cmd_name,
                required_params=cmd_params.required,
                optional_params=optional_with_defaults,
                mutual_exclusive_groups=mutual_groups
            )

            # 添加到分节
            if section_name not in sections:
                sections[section_name] = TableSection(
                    section_name=section_name,
                    commands=[],
                    notes=[]
                )
            sections[section_name].commands.append(row)

        # 注意：分节说明（notes）应由人工维护，不自动生成
        # 原因：手动说明已经在文档中标记外保留，自动生成会导致重复

        return sections


# ============================================================================
# 核心类 5: Markdown 表格渲染器
# ============================================================================

class MarkdownTableRenderer:
    """Markdown 表格渲染器"""

    @staticmethod
    def render_section(section: TableSection) -> str:
        """渲染一个分节的表格"""
        lines = []
        lines.append(f"### {section.section_name}")
        lines.append("| 命令 | 必需参数 | 可选参数 |")
        lines.append("|------|----------|----------|")

        for row in sorted(section.commands, key=lambda r: r.command_name):
            # 必需参数
            if row.required_params:
                required_str = "[必需] " + ", ".join(row.required_params)
            else:
                required_str = "-"

            # 可选参数（含默认值）
            optional_parts = []
            for param_name, default_str in row.optional_params:
                if default_str:
                    optional_parts.append(f"{param_name}({default_str})")
                else:
                    optional_parts.append(param_name)
            optional_str = ", ".join(optional_parts) if optional_parts else "-"

            lines.append(f"| {row.command_name} | {required_str} | {optional_str} |")

        # 添加说明
        if section.notes:
            lines.append("")
            lines.extend(section.notes)

        return "\n".join(lines)


# ============================================================================
# 核心类 6: 文档更新器
# ============================================================================

class DocumentUpdater:
    """文档更新器（支持区域标记）"""

    def __init__(self, prompt_path: Path):
        self.prompt_path = Path(prompt_path)
        self.content: Optional[str] = None

    def load(self) -> str:
        """加载文档"""
        with open(self.prompt_path, 'r', encoding='utf-8') as f:
            self.content = f.read()
        return self.content

    def save(self, content: Optional[str] = None):
        """保存文档"""
        if content is None:
            content = self.content
        with open(self.prompt_path, 'w', encoding='utf-8') as f:
            f.write(content)

    def update_sections(self, sections: Dict[str, TableSection]) -> str:
        """更新文档中的自动生成区域"""
        if self.content is None:
            self.load()

        for section_name, section in sections.items():
            self._update_section(section_name, section)

        return self.content

    def _update_section(self, section_name: str, section: TableSection):
        """更新单个分节"""
        # 查找区域标记
        start_marker = f"<!-- AUTO_GENERATED_SECTION_START: {section_name} -->"
        end_marker = f"<!-- AUTO_GENERATED_SECTION_END: {section_name} -->"

        pattern = re.compile(
            rf"{re.escape(start_marker)}.*?{re.escape(end_marker)}",
            re.DOTALL
        )

        # 生成新内容
        new_section = MarkdownTableRenderer.render_section(section)
        new_block = f"{start_marker}\n{new_section}\n{end_marker}"

        # 替换（使用 lambda 避免反斜杠转义问题）
        if pattern.search(self.content):
            # 已存在标记，直接替换
            self.content = pattern.sub(lambda m: new_block, self.content)
        else:
            # 不存在标记，输出警告
            print(f"[WARNING] 未找到分节标记：{section_name}，跳过更新", file=sys.stderr)


# ============================================================================
# 主函数
# ============================================================================

def main():
    """主函数"""
    parser = argparse.ArgumentParser(
        description='生成 API 命令参数速查表',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例：
    python generate_param_table.py --preview        # 预览模式（打印到终端）
    python generate_param_table.py --update         # 更新文档
    python generate_param_table.py --output out.md  # 输出到指定文件
        """
    )
    parser.add_argument('--preview', action='store_true', help='预览模式（不写文件）')
    parser.add_argument('--update', action='store_true', help='更新模式（直接写文件）')
    parser.add_argument('--output', type=str, help='输出文件路径')

    args = parser.parse_args()

    # 获取路径
    script_dir = Path(__file__).parent
    mcp_dir = script_dir.parent / 'src' / 'cad_cowork_mcp'

    MANIFEST_PATH = mcp_dir / 'api_commands_manifest.json'
    PROMPT_PATH = mcp_dir / 'prompts' / 'cad_system_prompt.md'

    if not MANIFEST_PATH.exists():
        print(f"[ERROR] 找不到 manifest 文件：{MANIFEST_PATH}", file=sys.stderr)
        sys.exit(1)

    if not PROMPT_PATH.exists() and args.update:
        print(f"[ERROR] 找不到 prompt 文件：{PROMPT_PATH}", file=sys.stderr)
        sys.exit(1)

    # 生成表格
    print("[Step 1] 解析 manifest 文件...", file=sys.stderr)
    generator = ParameterTableGenerator(MANIFEST_PATH)
    sections = generator.generate()

    print(f"[Step 2] 生成 {len(sections)} 个分节的速查表...", file=sys.stderr)
    for section_name, section in sections.items():
        print(f"  ✓ {section_name} ({len(section.commands)} 个命令)", file=sys.stderr)

    # 更新文档
    if args.update:
        print("[Step 3] 更新文档...", file=sys.stderr)
        updater = DocumentUpdater(PROMPT_PATH)
        updater.load()
        updater.update_sections(sections)
        updater.save()
        print(f"[SUCCESS] 已更新 {PROMPT_PATH}", file=sys.stderr)

    elif args.output:
        print(f"[Step 3] 输出到文件 {args.output}...", file=sys.stderr)
        updater = DocumentUpdater(PROMPT_PATH)
        updater.load()
        new_content = updater.update_sections(sections)
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"[SUCCESS] 已输出到 {args.output}", file=sys.stderr)

    elif args.preview:
        print("\n" + "=" * 80, file=sys.stderr)
        print("预览模式：生成的表格内容", file=sys.stderr)
        print("=" * 80 + "\n", file=sys.stderr)
        for section_name, section in sections.items():
            content = MarkdownTableRenderer.render_section(section)
            print(content)
            print()

    else:
        print("[ERROR] 请指定 --preview、--update 或 --output 参数", file=sys.stderr)
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()
