"""Extract Mode A instrument baseline data from snap Excel file.

Column mapping derived from inspecting the Excel:
- Row 7 has top-level merged headers (assembly fields are only in row 7)
- Row 10 has the detail-level Chinese headers for data columns
- Row 11 is first category separator
- Data starts at row 12

Separator detection: col2 (项目号) is empty but the index column has text.
"""
import json
import sys
import io
from pathlib import Path

import openpyxl

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

EXCEL_PATH = Path(r"C:\Users\dalong0514\Downloads\20260406144300-S23C01-08临时仪表数据表.xlsx")
OUTPUT_PATH = Path(r"C:\Users\dalong0514\Downloads\mode_a_instrument_baseline.json")

# Chinese header -> English field name mapping for INSTRUMENT sheet
# Row 10 headers (cols 2-41) + Row 7 headers (cols 42-61)
INST_COL_MAP = {
    2: "sort",               # 项目号 -> mapped to sort (project code)
    3: "drawnum",            # 单体号 -> mapped to drawnum fragment
    4: "dataClass",          # 数据状态简码
    5: "entityHandle",       # CAD对应的仪表唯一标识
    6: "assemblyInstallsize",  # 变管径信息 -> not a direct match, use closest
    7: "name",               # 仪表简码
    8: "instrumentType",     # 仪表类别
    9: "index",              # 序号 (index column)
    10: "functionCode",      # 功能代码
    11: "tag",               # 仪表编号
    12: "function",          # 控制点名称
    13: "simplifyDrawNum",   # 流程图号 -> simplifyDrawNum
    14: "substance",         # 组分及名称
    15: "phase",             # 相态
    16: "density",           # 密度
    17: "designTemp",        # 设计温度
    18: "temp",              # 操作温度
    19: "designPressure",    # 设计压力
    20: "pressure",          # 操作压力
    21: "max",               # 测量量最大值
    22: "nomal",             # 测量量正常值
    23: "min",               # 测量量最小值
    24: "measureUnit",       # 单位
    25: "dynamicViscosity",  # 动力粘度
    26: "other",             # 其他
    27: "halarm",            # 高报警
    28: "lalarm",            # 低报警
    29: "alarm",             # 报警
    30: "lockCode",          # 联锁
    31: "concentrationCode", # 集中程度代码
    32: "location",          # 管段号或设备号
    33: "installsize",       # 尺寸规格
    34: "material",          # 材质
    35: "direction",         # 水平/垂直
    36: "process",           # 过程连接
    37: "comment",           # 仪表类型 -> actually maps to instrumentType...
    # Row 10 says col37=仪表类型, col38=变等级号信息, col39=数据状态, col40=备用参数, col41=备注
    # But let me re-check: the user's field list has 'instrumentType' and 'comment'
    # Row 7 assembly fields:
    42: "functionTag",       # 回路号
    43: "assemblyLocation",  # 组装-管段号或设备号
    44: "assemblyName",      # 测量控制点名称
    45: "assemblyTemp",      # 组装温度
    46: "assemblyPressure",  # 组装压力
    47: "assemblySubstance", # 组装介质
    48: "assemblyPhase",     # 组装相态
    49: "assemblyDensity",   # 组装密度
    50: "assemblyInstallsize",  # 组装的安装尺寸 (overrides col6 mapping)
    51: "simplifyDrawNum",   # 简易流程图号 (overrides col13? let's keep both)
    52: "assemblyMaterial",  # 所在管道和设备的材质
    53: "weight",            # 设备重量
    54: "volume",            # 设备容积
    55: "measureUnit",       # 测量量的单位 (overlaps col24)
    56: "assemblyAlarm",     # 组装报警
    57: "assemblyLockCode",  # 联锁 (row 9 sub-header)
    58: "assemblyConcentrationCode",  # 集中程度代码
    59: "functionCode",      # 功能代码 (overlaps col10)
    60: "assemblyComment",   # 组装备注
}

# For the instrument sheet, let me fix overlapping mappings.
# When there's overlap, the row 7 assembly fields take priority for assembly-prefixed names.
# The core data fields (row 10) take priority for non-assembly names.
# I'll handle overlaps by just using the last value seen.

# Actually, let me reconsider the mapping more carefully based on the user's field list:
# The user wants these specific fields - let me map columns to them precisely.

INST_COL_MAP_FINAL = {
    # Core data fields (row 10 headers, cols 2-41)
    9: "index",
    12: "function",          # 控制点名称
    11: "tag",               # 仪表编号
    7: "name",               # 仪表简码
    13: "drawnum",           # 流程图号
    14: "substance",         # 组分及名称
    15: "phase",             # 相态
    16: "density",           # 密度
    17: "designTemp",        # 设计温度
    18: "temp",              # 操作温度
    19: "designPressure",    # 设计压力
    20: "pressure",          # 操作压力
    21: "max",               # 测量量最大值
    22: "nomal",             # 测量量正常值
    23: "min",               # 测量量最小值
    24: "measureUnit",       # 单位
    25: "dynamicViscosity",  # 动力粘度
    26: "other",             # 其他
    27: "halarm",            # 高报警
    28: "lalarm",            # 低报警
    29: "alarm",             # 报警
    30: "lockCode",          # 联锁
    31: "concentrationCode", # 集中程度代码
    32: "location",          # 管段号或设备号
    33: "installsize",       # 尺寸规格
    34: "material",          # 材质
    35: "direction",         # 水平/垂直
    36: "process",           # 过程连接
    37: "sort",              # 仪表类型 -> sort (classification)
    38: "_varGradeInfo",     # 变等级号信息 (auxiliary)
    39: "_dataStatus",       # 数据状态 (auxiliary)
    40: "_reserveParam",     # 备用参数 (auxiliary)
    41: "comment",           # 备注
    # Assembly fields (row 7 headers, cols 42-61)
    42: "functionTag",       # 回路号
    43: "assemblyLocation",  # 组装-管段号或设备号
    44: "assemblyName",      # 测量控制点名称
    45: "assemblyTemp",      # 组装温度
    46: "assemblyPressure",  # 组装压力
    47: "assemblySubstance", # 组装介质
    48: "assemblyPhase",     # 组装相态
    49: "assemblyDensity",   # 组装密度
    50: "assemblyInstallsize", # 组装的安装尺寸
    51: "simplifyDrawNum",   # 简易流程图号
    52: "assemblyMaterial",  # 所在管道和设备的材质
    53: "weight",            # 设备重量
    54: "volume",            # 设备容积
    # col 55 = 测量量的单位 -> skip (duplicate of col24 measureUnit)
    56: "assemblyAlarm",     # 组装报警
    57: "assemblyLockCode",  # 联锁
    58: "assemblyConcentrationCode", # 集中程度代码
    59: "functionCode",      # 功能代码
    60: "assemblyComment",   # 组装备注
    # Additional non-assembly fields from earlier columns
    8: "instrumentType",     # 仪表类别
    4: "dataClass",          # 数据状态简码
    5: "entityHandle",       # CAD对应的仪表唯一标识
    10: "functionCode",      # 功能代码 (col 10 - primary)
    2: "_projectCode",       # 项目号
    3: "_unitCode",          # 单体号
    6: "_varDiameterInfo",   # 变管径信息
}

# Valve sheet has a different column layout (one extra column for 变管道等级 at col 6)
VALVE_COL_MAP_FINAL = {
    10: "index",
    13: "function",          # 控制点名称
    12: "tag",               # 仪表编号
    8: "name",               # 仪表简码
    14: "drawnum",           # 流程图号
    15: "substance",         # 组分及名称
    16: "phase",             # 相态
    17: "density",           # 密度
    18: "designTemp",        # 设计温度
    19: "temp",              # 操作温度
    20: "designPressure",    # 设计压力
    21: "pressure",          # 操作压力
    22: "max",               # 测量量最大值
    23: "nomal",             # 测量量正常值
    24: "min",               # 测量量最小值
    25: "_valveBefore",      # 阀前
    26: "_valveAfter",       # 阀后
    27: "_valveFullClose",   # 阀门全关
    28: "location",          # 管段号或设备号
    29: "installsize",       # 尺寸规格
    30: "material",          # 材质
    31: "direction",         # 水平/垂直
    32: "_failPosition",     # 失能位置
    33: "_hasHandwheel",     # 是否带手轮
    34: "sort",              # 仪表类型
    35: "_varGradeInfo",     # 变等级号信息
    36: "_dataStatus",       # 数据状态
    37: "_reserveParam",     # 备用参数
    38: "comment",           # 备注
    # Assembly fields (row 7)
    39: "functionTag",       # 回路号
    40: "assemblyLocation",  # 组装-管段号或设备号
    41: "assemblyName",      # 测量控制点名称
    42: "_assemblyFailPos",  # 阀门失能位置
    43: "assemblyTemp",      # 组装温度
    44: "assemblyPressure",  # 组装压力
    45: "assemblyDensity",   # 组装密度
    46: "assemblySubstance", # 组装介质
    47: "assemblyPhase",     # 组装相态
    48: "assemblyInstallsize", # 组装的安装尺寸
    49: "simplifyDrawNum",   # 简易流程图号
    50: "assemblyMaterial",  # 所在管道和设备的材质
    51: "assemblyComment",   # 备注
    # Additional
    9: "instrumentType",     # 仪表类别
    4: "dataClass",          # 数据状态简码
    5: "entityHandle",       # CAD对应的仪表唯一标识
    11: "functionCode",      # 功能代码
    2: "_projectCode",       # 项目号
    3: "_unitCode",          # 单体号
    6: "_varPipeGrade",      # 变管道等级
    7: "_varDiameterInfo",   # 变管径信息
}

# All fields requested by user
ALL_FIELDS = [
    "index", "function", "tag", "name", "drawnum", "substance", "phase",
    "density", "designTemp", "temp", "designPressure", "pressure", "max",
    "nomal", "min", "measureUnit", "dynamicViscosity", "other", "halarm",
    "lalarm", "alarm", "lockCode", "concentrationCode", "location",
    "installsize", "material", "direction", "process", "sort", "comment",
    "functionTag", "assemblyLocation", "assemblyName", "assemblyTemp",
    "assemblyPressure", "assemblySubstance", "assemblyPhase",
    "assemblyDensity", "assemblyInstallsize", "simplifyDrawNum",
    "assemblyMaterial", "weight", "volume", "assemblyAlarm",
    "assemblyLockCode", "assemblyConcentrationCode", "functionCode",
    "assemblyComment", "instrumentType", "dataClass", "entityHandle",
]


def extract_sheet(ws, col_map, project_col=2, separator_col=None):
    """Extract data from a worksheet using the column mapping.

    Args:
        ws: worksheet
        col_map: dict of col_index -> field_name
        project_col: column that has project code (empty = separator)
        separator_col: column that has category label in separator rows
    """
    records = []
    separators = []

    for row_idx in range(11, ws.max_row + 1):
        # Check if separator: project_col is empty
        proj_val = ws.cell(row=row_idx, column=project_col).value
        if proj_val is None or str(proj_val).strip() == "":
            # Check if it's a named separator
            if separator_col:
                sep_val = ws.cell(row=row_idx, column=separator_col).value
                if sep_val is not None and str(sep_val).strip():
                    separators.append(f"Row {row_idx}: {sep_val}")
            continue

        # Extract record
        record = {}
        for col_idx, field_name in col_map.items():
            # Skip internal/auxiliary fields (prefixed with _)
            if field_name.startswith("_"):
                continue
            cell = ws.cell(row=row_idx, column=col_idx)
            val = cell.value
            if val is None:
                record[field_name] = ""
            elif isinstance(val, (int, float)):
                # Keep numbers as-is
                record[field_name] = val
            else:
                record[field_name] = str(val).strip()

        # Ensure all requested fields exist (fill missing with "")
        for field in ALL_FIELDS:
            if field not in record:
                record[field] = ""

        records.append(record)

    print(f"  Extracted {len(records)} data rows")
    print(f"  Skipped {len(separators)} separators: {separators}")
    return records


def main():
    if not EXCEL_PATH.exists():
        print(f"ERROR: File not found: {EXCEL_PATH}")
        sys.exit(1)

    print(f"Loading: {EXCEL_PATH}")
    wb = openpyxl.load_workbook(str(EXCEL_PATH), data_only=True)
    print(f"Sheet names: {wb.sheetnames}")

    # Extract instruments
    print("\n--- Instrument sheet ---")
    ws_inst = wb["仪表临时数据"]
    # For instrument sheet: col 10 has functionCode in row 10 header
    # but in the actual col_map we have col 10 -> functionCode AND col 59 -> functionCode
    # The primary functionCode is col 10 (data area). Col 59 is assembly area.
    # Since col 59 comes after col 10 in dict iteration, col 59 value will overwrite.
    # Let's handle this: read col 10 first as functionCode, col 59 as a separate assembly field.
    instruments = extract_sheet(ws_inst, INST_COL_MAP_FINAL, project_col=2, separator_col=9)

    # Extract valves
    print("\n--- Valve sheet ---")
    ws_valve = wb["阀门临时数据"]
    valves = extract_sheet(ws_valve, VALVE_COL_MAP_FINAL, project_col=2, separator_col=10)

    # Build output
    result = {
        "instruments": instruments,
        "valves": valves,
        "instrument_count": len(instruments),
        "valve_count": len(valves),
    }

    OUTPUT_PATH.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\nSaved to: {OUTPUT_PATH}")
    print(f"  instrument_count: {result['instrument_count']}")
    print(f"  valve_count: {result['valve_count']}")

    # Print samples
    print("\n=== First 2 instruments ===")
    for i, inst in enumerate(instruments[:2]):
        print(f"\n[{i}]")
        for k, v in inst.items():
            if v != "":
                print(f"  {k}: {repr(v)}")

    print("\n=== First 2 valves ===")
    for i, valve in enumerate(valves[:2]):
        print(f"\n[{i}]")
        for k, v in valve.items():
            if v != "":
                print(f"  {k}: {repr(v)}")


if __name__ == "__main__":
    main()
