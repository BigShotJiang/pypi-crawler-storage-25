#!/usr/bin/env python3
"""
为 cad_system_prompt.md 添加区域标记

自动在速查表的每个分节添加 AUTO_GENERATED 标记。
"""

import re
import sys
from pathlib import Path


def add_markers(content: str, section_names: list) -> str:
    """为指定的分节添加区域标记"""

    for section_name in section_names:
        # 查找分节标题（### 分节名）
        pattern = rf"(^###\s+{re.escape(section_name)}\s*$)"

        # 检查是否已有标记
        if f"<!-- AUTO_GENERATED_SECTION_START: {section_name} -->" in content:
            print(f"[SKIP] {section_name} 已有标记")
            continue

        # 在分节标题前添加开始标记
        content = re.sub(
            pattern,
            rf"<!-- AUTO_GENERATED_SECTION_START: {section_name} -->\n\1",
            content,
            flags=re.MULTILINE
        )

        # 查找表格结束位置（下一个空行或下一个分节）
        # 策略：找到标题后的表格，然后在表格后添加结束标记
        section_pattern = rf"<!-- AUTO_GENERATED_SECTION_START: {re.escape(section_name)} -->.*?^###\s+{re.escape(section_name)}\s*$.*?\n(\|[^\n]+\|\s*\n)+?"

        def replace_table(match):
            table_end = match.group(0)
            # 在表格最后一行后添加结束标记
            return table_end + f"<!-- AUTO_GENERATED_SECTION_END: {section_name} -->\n"

        content = re.sub(
            section_pattern,
            replace_table,
            content,
            flags=re.MULTILINE | re.DOTALL
        )

        print(f"[ADD] {section_name} 标记已添加")

    return content


def main():
    # 获取路径
    script_dir = Path(__file__).parent
    mcp_dir = script_dir.parent / 'src' / 'cad_cowork_mcp'
    prompt_path = mcp_dir / 'prompts' / 'cad_system_prompt.md'

    if not prompt_path.exists():
        print(f"[ERROR] 找不到文件：{prompt_path}", file=sys.stderr)
        sys.exit(1)

    # 读取文档
    with open(prompt_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # 需要添加标记的分节（按文档出现顺序）
    section_names = [
        "绘图类",
        "修改类",
        "批量类",
        "查询类",
        "块操作类",
        "图层类",
        "空间计算类",
        "文档管理类",
        "视图控制类",
        "选择集类",
        "事务控制类",
    ]

    # 添加标记
    new_content = add_markers(content, section_names)

    # 保存
    with open(prompt_path, 'w', encoding='utf-8') as f:
        f.write(new_content)

    print(f"\n[SUCCESS] 标记已添加到 {prompt_path}")


if __name__ == '__main__':
    main()
