#!/usr/bin/env python3
"""
参数一致性验证工具

功能：
1. 解析 api_commands_manifest.json 获取标准参数列表
2. 解析 cad_system_prompt.md 速查表获取文档参数
3. 对比差异并生成报告

检查项：
- 参数遗漏（manifest 有但文档没有）
- 参数多余（文档有但 manifest 没有）
- 必需性不一致（必需 vs 可选）
- 参数名不匹配（单复数、拼写）
"""

import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field

# 导入共享模块
from shared.manifest_parser import Parameter, CommandParams, ManifestParser


@dataclass
class Issue:
    """问题记录"""
    severity: str  # ERROR, WARNING, INFO
    command: str
    issue_type: str
    message: str
    suggestion: Optional[str] = None


class PromptParser:
    """System Prompt 速查表解析器"""

    def __init__(self, prompt_path: Path):
        self.prompt_path = prompt_path
        self.content = None

    def load(self) -> str:
        """加载 prompt 文件"""
        with open(self.prompt_path, 'r', encoding='utf-8') as f:
            self.content = f.read()
        return self.content

    def get_all_commands(self) -> Dict[str, CommandParams]:
        """解析速查表，提取所有命令参数"""
        if not self.content:
            self.load()

        result = {}

        # 查找所有参数速查表（以 | 命令 | 必需参数 | 可选参数 | 开头的表格）
        # 匹配表格行：| api_xxx | ... | ... |
        table_pattern = r'\| (api_[a-z_]+) \| (.*?) \| (.*?) \|'

        for match in re.finditer(table_pattern, self.content):
            cmd_name = match.group(1).strip()
            required_str = match.group(2).strip()
            optional_str = match.group(3).strip()

            # 解析必需参数
            required = self._parse_param_list(required_str, is_required=True)

            # 解析可选参数
            optional = self._parse_param_list(optional_str, is_required=False)

            # 合并为 params 字典
            params_dict = {}
            for param_name in required:
                params_dict[param_name] = Parameter(
                    name=param_name,
                    required=True
                )
            for param_name, default_value in optional:
                params_dict[param_name] = Parameter(
                    name=param_name,
                    required=False,
                    default_value=default_value
                )

            result[cmd_name] = CommandParams(
                command_name=cmd_name,
                required=required,
                optional=[p for p, _ in optional],
                params=params_dict
            )

        return result

    def _parse_param_list(self, param_str: str, is_required: bool) -> List:
        """解析参数列表字符串"""
        if param_str == '-' or not param_str:
            return [] if is_required else []

        # 移除 [必需] 前缀
        param_str = re.sub(r'\[必需\]\s*', '', param_str)

        # 处理 [二选一] 等特殊标记
        param_str = re.sub(r'\[二选一\]\s*', '', param_str)

        # 分割参数（逗号分隔）
        params = []
        for param in param_str.split(','):
            param = param.strip()
            if not param or param == '-':
                continue

            # 提取默认值（如果有）
            # 格式：paramName(默认value) 或 paramName(0=xxx/1=xxx)
            default_value = None
            match = re.match(r'([a-zA-Z_]+)\(默认([^)]+)\)', param)
            if match:
                param_name = match.group(1)
                default_value = match.group(2)
            else:
                # 移除括号内的说明
                param_name = re.sub(r'\([^)]+\)', '', param).strip()

            if is_required:
                params.append(param_name)
            else:
                params.append((param_name, default_value))

        return params


class ConsistencyValidator:
    """参数一致性验证器"""

    def __init__(self, manifest_path: Path, prompt_path: Path):
        self.manifest_parser = ManifestParser(manifest_path)
        self.prompt_parser = PromptParser(prompt_path)
        self.issues: List[Issue] = []

    def validate(self) -> List[Issue]:
        """执行验证，返回问题列表"""
        self.issues = []

        manifest_cmds = self.manifest_parser.get_all_commands()
        prompt_cmds = self.prompt_parser.get_all_commands()

        # 检查文档中遗漏的命令
        for cmd_name in manifest_cmds:
            if cmd_name not in prompt_cmds:
                self.issues.append(Issue(
                    severity='ERROR',
                    command=cmd_name,
                    issue_type='missing_command',
                    message=f'命令未在速查表中',
                    suggestion=f'在速查表中添加 {cmd_name} 命令'
                ))

        # 检查文档中多余的命令
        for cmd_name in prompt_cmds:
            if cmd_name not in manifest_cmds:
                self.issues.append(Issue(
                    severity='WARNING',
                    command=cmd_name,
                    issue_type='extra_command',
                    message=f'命令在速查表中但 manifest 中不存在',
                    suggestion=f'从速查表中移除 {cmd_name}'
                ))

        # 对比每个命令的参数
        for cmd_name in manifest_cmds:
            if cmd_name not in prompt_cmds:
                continue

            manifest_params = manifest_cmds[cmd_name]
            prompt_params = prompt_cmds[cmd_name]

            self._validate_command_params(manifest_params, prompt_params)

        return self.issues

    def _validate_command_params(self, manifest: CommandParams, prompt: CommandParams):
        """验证单个命令的参数"""
        cmd_name = manifest.command_name

        # 检查必需参数一致性
        manifest_required = set(manifest.required)
        prompt_required = set(prompt.required)

        # 文档中标记为必需，但实际可选
        for param in prompt_required - manifest_required:
            self.issues.append(Issue(
                severity='ERROR',
                command=cmd_name,
                issue_type='wrong_required',
                message=f'参数 {param} 在文档中标记为必需，但 manifest 中为可选',
                suggestion=f'将 {param} 移到可选参数列'
            ))

        # 文档中标记为可选，但实际必需
        for param in manifest_required - prompt_required:
            # 检查是否在别名中
            if not self._is_param_in_prompt(param, manifest.params[param].aliases, prompt):
                self.issues.append(Issue(
                    severity='ERROR',
                    command=cmd_name,
                    issue_type='missing_required',
                    message=f'必需参数 {param} 未在文档中',
                    suggestion=f'在必需参数列添加 {param}'
                ))

        # 检查可选参数遗漏
        manifest_optional = set(manifest.optional)
        prompt_optional = set(prompt.optional)

        for param in manifest_optional - prompt_optional:
            # 检查别名
            if not self._is_param_in_prompt(param, manifest.params[param].aliases, prompt):
                # 判断重要性（有默认值的参数更重要）
                severity = 'WARNING' if manifest.params[param].default_value is not None else 'INFO'
                self.issues.append(Issue(
                    severity=severity,
                    command=cmd_name,
                    issue_type='missing_optional',
                    message=f'可选参数 {param} 未在文档中（默认值：{manifest.params[param].default_value}）',
                    suggestion=f'在可选参数列添加 {param}'
                ))

        # 检查参数名不匹配（单复数等）
        self._check_similar_param_names(cmd_name, manifest_optional, prompt_optional)

    def _is_param_in_prompt(self, param_name: str, aliases: List[str], prompt: CommandParams) -> bool:
        """检查参数或其别名是否在文档中"""
        all_names = [param_name] + (aliases or [])
        prompt_all_params = set(prompt.required + prompt.optional)
        return any(name in prompt_all_params for name in all_names)

    def _check_similar_param_names(self, cmd_name: str, manifest_params: set, prompt_params: set):
        """检查参数名相似但不完全匹配的情况（如单复数）"""

        # 新增：构建互斥关系集合
        manifest_cmd = self.manifest_parser.get_all_commands().get(cmd_name)
        mutex_pairs = set()

        if manifest_cmd:
            # 从 manifest 提取互斥对
            for param_name, param in manifest_cmd.params.items():
                if not param.mutual_exclusion_groups:
                    continue

                for group_id in param.mutual_exclusion_groups:
                    # 找到同组的其他参数
                    for other_name, other_param in manifest_cmd.params.items():
                        if (other_name != param_name and
                            group_id in other_param.mutual_exclusion_groups):
                            # 添加双向对（排序避免重复）
                            pair = tuple(sorted([param_name, other_name]))
                            mutex_pairs.add(pair)

        # 原有逻辑：检查单复数
        for m_param in manifest_params:
            for p_param in prompt_params:
                # 新增：检查是否是互斥参数
                pair = tuple(sorted([m_param, p_param]))
                if pair in mutex_pairs:
                    continue  # ✨ 跳过互斥参数，不报告误报

                # 检查单复数不匹配（原有逻辑）
                if (m_param + 's' == p_param or m_param == p_param + 's'):
                    self.issues.append(Issue(
                        severity='ERROR',
                        command=cmd_name,
                        issue_type='name_mismatch',
                        message=f'参数名单复数不匹配：manifest 用 {m_param}，文档用 {p_param}',
                        suggestion=f'统一使用 {m_param}（与 manifest 保持一致）'
                    ))

    def generate_report(self, format='text') -> str:
        """生成报告"""
        if format == 'json':
            return self._generate_json_report()
        else:
            return self._generate_text_report()

    def _generate_text_report(self) -> str:
        """生成文本格式报告"""
        lines = []
        lines.append("=" * 80)
        lines.append("参数一致性检查报告")
        lines.append("=" * 80)
        lines.append("")

        # 统计
        errors = [i for i in self.issues if i.severity == 'ERROR']
        warnings = [i for i in self.issues if i.severity == 'WARNING']
        infos = [i for i in self.issues if i.severity == 'INFO']

        lines.append(f"总计：{len(self.issues)} 个问题")
        lines.append(f"  - ERROR: {len(errors)}")
        lines.append(f"  - WARNING: {len(warnings)}")
        lines.append(f"  - INFO: {len(infos)}")
        lines.append("")

        # 按严重程度分组
        for severity, issues in [('ERROR', errors), ('WARNING', warnings), ('INFO', infos)]:
            if not issues:
                continue

            lines.append(f"\n{'=' * 80}")
            lines.append(f"{severity} ({len(issues)} 个)")
            lines.append('=' * 80)

            # 按命令分组
            by_command = {}
            for issue in issues:
                if issue.command not in by_command:
                    by_command[issue.command] = []
                by_command[issue.command].append(issue)

            for cmd_name in sorted(by_command.keys()):
                lines.append(f"\n[{cmd_name}]")
                for issue in by_command[cmd_name]:
                    lines.append(f"  - {issue.message}")
                    if issue.suggestion:
                        lines.append(f"    建议：{issue.suggestion}")

        return '\n'.join(lines)

    def _generate_json_report(self) -> str:
        """生成 JSON 格式报告"""
        data = {
            'total': len(self.issues),
            'error_count': len([i for i in self.issues if i.severity == 'ERROR']),
            'warning_count': len([i for i in self.issues if i.severity == 'WARNING']),
            'info_count': len([i for i in self.issues if i.severity == 'INFO']),
            'issues': [
                {
                    'severity': i.severity,
                    'command': i.command,
                    'type': i.issue_type,
                    'message': i.message,
                    'suggestion': i.suggestion
                }
                for i in self.issues
            ]
        }
        return json.dumps(data, ensure_ascii=False, indent=2)


def main():
    """主函数"""
    # 获取脚本所在目录
    script_dir = Path(__file__).parent
    mcp_dir = script_dir.parent / 'src' / 'cad_cowork_mcp'

    manifest_path = mcp_dir / 'api_commands_manifest.json'
    prompt_path = mcp_dir / 'prompts' / 'cad_system_prompt.md'

    if not manifest_path.exists():
        print(f"错误：找不到 manifest 文件：{manifest_path}", file=sys.stderr)
        sys.exit(1)

    if not prompt_path.exists():
        print(f"错误：找不到 prompt 文件：{prompt_path}", file=sys.stderr)
        sys.exit(1)

    # 解析命令行参数
    verbose = '--verbose' in sys.argv
    format_json = '--format' in sys.argv and 'json' in sys.argv
    output_file = None
    for i, arg in enumerate(sys.argv):
        if arg == '--output' and i + 1 < len(sys.argv):
            output_file = sys.argv[i + 1]

    # 执行验证
    validator = ConsistencyValidator(manifest_path, prompt_path)
    issues = validator.validate()

    # 生成报告
    report_format = 'json' if format_json else 'text'
    report = validator.generate_report(format=report_format)

    # 输出报告
    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report)
    else:
        # Windows CMD 下直接打印可能有编码问题，改为 UTF-8 输出
        if sys.platform == 'win32':
            import codecs
            sys.stdout = codecs.getwriter('utf-8')(sys.stdout.buffer, 'strict')
        print(report)

    # 返回退出码
    error_count = len([i for i in issues if i.severity == 'ERROR'])
    sys.exit(1 if error_count > 0 else 0)


if __name__ == '__main__':
    main()
