#!/usr/bin/env python3
"""
Analyze parameter consistency report and generate summary
"""

import json
from pathlib import Path
from collections import defaultdict


def main():
    report_path = Path(__file__).parent.parent / 'param_report.json'

    with open(report_path, 'r', encoding='utf-8') as f:
        data = json.load(f)

    print("=" * 80)
    print("PARAMETER CONSISTENCY ANALYSIS SUMMARY")
    print("=" * 80)
    print()

    print(f"Total Issues: {data['total']}")
    print(f"  ERROR: {data['error_count']}")
    print(f"  WARNING: {data['warning_count']}")
    print(f"  INFO: {data['info_count']}")
    print()

    # Group by severity and type
    by_type = defaultdict(int)
    for issue in data['issues']:
        key = f"{issue['severity']}:{issue['type']}"
        by_type[key] += 1

    print("Issue Breakdown:")
    for key in sorted(by_type.keys()):
        print(f"  {key}: {by_type[key]}")
    print()

    # CRITICAL: Missing commands
    missing = [i for i in data['issues'] if i['type'] == 'missing_command']
    print(f"=" * 80)
    print(f"CRITICAL: Missing Commands ({len(missing)})")
    print("=" * 80)

    # Group by category
    batch_cmds = []
    gslc_cmds = []
    transaction_cmds = []

    for i in missing:
        cmd = i['command']
        if 'batch' in cmd:
            batch_cmds.append(cmd)
        elif 'gslc' in cmd:
            gslc_cmds.append(cmd)
        elif 'transaction' in cmd:
            transaction_cmds.append(cmd)

    print(f"\nBatch Operations ({len(batch_cmds)}):")
    for cmd in batch_cmds:
        print(f"  - {cmd}")

    print(f"\nGsLc Commands ({len(gslc_cmds)}):")
    gslc_by_type = defaultdict(list)
    for cmd in gslc_cmds:
        if 'brush' in cmd:
            gslc_by_type['brush'].append(cmd)
        elif 'export' in cmd:
            gslc_by_type['export'].append(cmd)
        elif 'sync' in cmd:
            gslc_by_type['sync'].append(cmd)
        elif 'insert' in cmd:
            gslc_by_type['insert'].append(cmd)
        else:
            gslc_by_type['other'].append(cmd)

    for cat, cmds in sorted(gslc_by_type.items()):
        print(f"  {cat} ({len(cmds)}):")
        for cmd in cmds:
            print(f"    - {cmd}")

    print(f"\nTransaction Control ({len(transaction_cmds)}):")
    for cmd in transaction_cmds:
        print(f"  - {cmd}")

    # Wrong required flags
    wrong_req = [i for i in data['issues'] if i['type'] == 'wrong_required']
    print(f"\n" + "=" * 80)
    print(f"Wrong Required Flags ({len(wrong_req)})")
    print("=" * 80)

    # Group by command
    by_cmd = defaultdict(list)
    for i in wrong_req:
        by_cmd[i['command']].append(i)

    for cmd in sorted(by_cmd.keys())[:10]:
        params = [i['message'].split(' ')[1] if len(i['message'].split(' ')) > 1 else '?' for i in by_cmd[cmd]]
        print(f"  {cmd}: {', '.join(params)}")

    if len(by_cmd) > 10:
        print(f"  ... and {len(by_cmd) - 10} more commands")

    # Name mismatches
    name_mis = [i for i in data['issues'] if i['type'] == 'name_mismatch']
    print(f"\n" + "=" * 80)
    print(f"Parameter Name Mismatches ({len(name_mis)})")
    print("=" * 80)

    for i in name_mis:
        # Extract parameter names from message
        cmd = i['command']
        print(f"  {cmd}")
        print(f"    (manifest vs prompt parameter name mismatch)")

    # Missing required
    missing_req = [i for i in data['issues'] if i['type'] == 'missing_required']
    if missing_req:
        print(f"\n" + "=" * 80)
        print(f"Missing Required Parameters ({len(missing_req)})")
        print("=" * 80)
        for i in missing_req:
            print(f"  {i['command']}")

    print()
    print("=" * 80)
    print("RECOMMENDATIONS")
    print("=" * 80)
    print()
    print("Priority 1 - CRITICAL (62 ERROR issues):")
    print("  1. Add 27 missing commands to speed reference tables")
    print("  2. Fix 30 wrong_required parameter flags")
    print("  3. Fix 4 parameter name mismatches (singular/plural)")
    print("  4. Fix 1 missing_required parameter")
    print()
    print("Priority 2 - HIGH (57 WARNING issues):")
    print("  - Add important optional parameters (those with default values)")
    print()
    print("Priority 3 - MEDIUM (54 INFO issues):")
    print("  - Add remaining optional parameters for completeness")
    print()


if __name__ == '__main__':
    main()
