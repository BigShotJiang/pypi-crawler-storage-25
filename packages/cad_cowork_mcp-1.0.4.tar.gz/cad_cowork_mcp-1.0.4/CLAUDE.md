# CAD-Cowork-MCP

通过 MCP（Model Context Protocol）让 AI Agent 控制 CAD 软件的独立 MCP 服务器。

## 开发环境信息

| 配置项 | 详情 |
|--------|------|
| 运行平台 | Windows（依赖 COM 接口） |
| Python 环境 | uv（虚拟环境在 `.venv/`） |
| 包名 | `cad-cowork-mcp`（PyPI） / `cad_cowork_mcp`（Python import） |
| 沟通语言 | 中文 |

## 项目概述

本项目从 `CAD-Cowork`（Electron 桌面应用）中剥离出 MCP 服务器部分，使其成为独立的 MCP 服务，可被 Claude Code、OpenClaw 等任意 AI Agent 客户端调用。

## 安装与使用

```bash
# 外部用户：从 PyPI 安装
uvx cad-cowork-mcp

# 本地开发
uv sync
uv run cad-cowork-mcp
```

Claude Code 配置（`.mcp.json`）：
```jsonc
// 外部用户
{"mcpServers": {"cad-mcp": {"command": "uvx", "args": ["cad-cowork-mcp"]}}}

// 本地开发
{"mcpServers": {"cad-mcp": {"command": "uv", "args": ["run", "--directory", "<项目路径>", "cad-cowork-mcp"]}}}
```

## 系统架构

```
AI Agent 客户端（Claude Code / OpenClaw / 自定义 Agent）
        │
        ▼ (MCP Protocol - stdio)
┌────────────────────────────────────────────────────────┐
│              CAD-MCP Server (Python)                     │
│                                                         │
│  ┌──────────┐ ┌─────────┐ ┌──────────┐ ┌───────────┐ │
│  │  smart_   │ │  batch_ │ │  query_  │ │gslc_route │ │
│  │  cad_cmd  │ │ execute │ │api_cmds  │ │ _command  │ │
│  └─────┬────┘ └────┬────┘ └────┬─────┘ └─────┬─────┘ │
│        └───────────┼──────────┘              │       │
│                    ▼                          │       │
│  ┌──────────────────────────────┐   metrics  │       │
│  │  cad_controller.py (COM)     │  DrawState │       │
│  │  129 API + 88 SendCommand    │◄───────────┘       │
│  └──────────────────┬──────────┘                     │
└─────────────────────────┼──────────────────────────────┘
                          │
                          ▼ (Windows COM)
┌────────────────────────────────────────────────────────┐
│           AutoCAD / 浩辰 CAD / 中望 CAD                  │
└────────────────────────────────────────────────────────┘
```

## 项目结构

```
CAD-Cowork-MCP/
├── pyproject.toml                  # 包定义（依赖、构建、测试配置）
├── .mcp.json                       # MCP 服务器配置（客户端读取）
├── CLAUDE.md                       # 本文件
├── README.md                       # 项目说明
├── LICENSE                         # MIT
│
├── src/cad_cowork_mcp/             # Python 包源码
│   ├── __init__.py                 # 包入口，版本号，config 加载
│   ├── __main__.py                 # python -m cad_cowork_mcp 支持
│   ├── server.py                   # MCP 入口，注册 6 个 Tool
│   ├── cad_controller.py           # CAD COM 接口封装
│   ├── nlp_processor.py            # 自然语言解析（DEPRECATED，MCP 工具链不再使用）
│   ├── batch_executor.py           # 批量执行引擎（DAG 依赖）
│   ├── direct_command.py           # 直接命令（Electron IPC 用）
│   ├── config.json                 # 服务器配置（名称、CAD 类型）
│   ├── api_commands_manifest.json  # 129 个 API 命令定义
│   │
│   ├── metrics.py                  # 可观测性指标（CommandMetrics, SessionMetrics）
│   ├── command_router/             # 命令路由框架
│   │   ├── base_router.py          # BaseCommandRouter 基类
│   │   ├── scorer.py               # ScoringEngine 评分引擎
│   │   ├── types.py                # RoutingResult, CommandCandidate
│   │   └── yaml_loader.py          # 声明式 YAML 域配置加载器
│   │
│   ├── domains/                    # 业务域路由器
│   │   └── gslc/                   # GsLc 工艺流程图
│   │       ├── router.py           # GsLcRouter 实现
│   │       ├── taxonomy.py         # 意图/实体/命令映射（36 个命令）
│   │       └── rules.py            # 负向引导规则（8 对易混淆命令）
│   │
│   └── prompts/                    # 提示词模板
│       └── cad_system_prompt.md    # 系统提示词（{{CAD_NAME}} 占位符）
│
├── tests/                          # 测试（不随包分发）
│   ├── conftest.py                 # pytest 全局 fixtures
│   ├── unit/                       # L1: 单元测试（不需要 CAD）
│   ├── integration/                # L2: 集成测试（需要 CAD）
│   ├── scenarios/                  # L3: YAML 数据驱动场景测试
│   └── data/scenarios/             # YAML 场景文件
│
├── scripts/                        # 工具脚本（不随包分发）
├── docs/                           # 文档
└── chats/                          # 开发记录
```

## MCP 工具（4 个）

| 工具 | 描述 |
|------|------|
| `smart_cad_command` | **[核心]** 执行所有 CAD 操作的统一入口，自动选择最优执行方式 |
| `batch_execute` | 批量执行多个命令，支持 DAG 依赖、参数传递 `${cmd_id.field}` 和 `dry_run` 预检 |
| `query_api_commands` | 查询命令参数（按名称/按分类/全量列表） |
| `gslc_route_command` | **[GsLc 专用]** 工艺流程图命令路由器，调用 api_gslc_* 前必须先使用 |

> 已移除的工具：`execute_api_command`（与 smart_cad_command 重叠）、`list_api_commands` 和 `get_api_command_info`（合并为 `query_api_commands`）

## 与 CsTool 的 IPC 机制

```
MCP Server                          CsTool (C# AutoCAD 插件)
─────────                          ──────────────────────
写入 request.json            →     DLApiExecute 读取请求
                                    执行 API 命令
轮询 results/{requestId}.json ←     同时写入 results/{requestId}.json 和 results/latest.json
```

- **请求路径**：`%TEMP%/CAD-Cowork/request.json`（固定，CsTool 从此读取）
- **结果路径**：优先读 `results/{requestId}.json`（per-request 隔离，无竞态），fallback 到 `results/latest.json`
- **轮询策略**：指数退避（20ms → 200ms 上限）
- **错误码**：CsTool 定义 0 ~ -10 共 11 个错误码，详见 system prompt

## API 命令分类（共 129 个）

| 类别 | 数量 | 示例命令 |
|------|------|----------|
| 绘图-基础 | 10 | `api_draw_line`, `api_draw_circle`, `api_create_polyline` |
| 查询 | 15 | `api_get_entity_info`, `api_query_by_layer`, `api_get_unique_attribute_values` |
| 块操作 | 8 | `api_insert_block`, `api_set_block_attributes`, `api_modify_block_base_point` |
| 实体修改 | 11 | `api_move_entity`, `api_delete_entity` |
| 批量操作 | 11 | `api_batch_move`, `api_batch_copy`, `api_batch_get_block_attributes` |
| 空间计算 | 8 | `api_calc_distance`, `api_calc_area` |
| 图层管理 | 8 | `api_create_layer`, `api_list_layers`, `api_rename_layer` |
| 文档管理 | 4 | `api_save_document`, `api_get_document_info` |
| 视图控制 | 5 | `api_zoom_extents`, `api_zoom_window` |
| 选择集 | 7 | `api_select_all`, `api_select_window` |
| 事务控制 | 3 | `api_transaction_begin`, `api_transaction_commit`, `api_transaction_rollback` |
| 工艺流程图 | 39 | `api_gslc_query_frame_info`, `api_gslc_insert_equipment` |

## 调用示例

```json
// 绘制直线
{"command_name": "api_draw_line", "parameters": {"startPoint": [0,0,0], "endPoint": [100,100,0]}}

// 绘制圆
{"command_name": "api_draw_circle", "parameters": {"center": [100,100,0], "radius": 50}}

// 插入块
{"command_name": "api_insert_block", "parameters": {"blockName": "阀门", "insertionPoint": [100,100,0]}}

// 按图层查询
{"command_name": "api_query_by_layer", "parameters": {"layerName": "设备"}}

// 移动实体
{"command_name": "api_move_entity", "parameters": {"entityHandle": "27E2C0", "fromPoint": [0,0,0], "toPoint": [100,100,0]}}
```

## 业务域命令路由

GsLc 业务域有 36 个 API 命令，存在多组容易混淆的命令：

| 用户意图 | 正确命令 | 常见错误 |
|----------|----------|----------|
| 批量生成设备位号 | `insert_bottom_equip_tags` | `auto_number`（编号 ≠ 生成） |
| 给设备自动编号 | `auto_number` | `insert_equipment`（插入 ≠ 编号） |
| 插入接图箭头 | `insert_join_draw_arrow` | `insert_outer_pipe_arrow`（外管 ≠ 接图） |
| 刷新管道来去向 | `brush_batch_pipes` | `sync_pipe_data`（刷新 ≠ 同步） |
| 插入控制阀 | `insert_control_valve` | `insert_valve`（控制阀 ≠ 普通阀） |

### 路由调用流程

```
涉及 GsLc 概念（设备、管道、仪表、图框...）
  → gslc_route_command(user_intent) → 获取推荐命令 → smart_cad_command

通用操作（绘制、移动、图层...）
  → 直接 smart_cad_command
```

### 扩展新业务域

添加 gsbz/gspg 等模块：
1. 创建 `src/cad_cowork_mcp/domains/xxx/` 目录
2. 实现 `router.py`（继承 `BaseCommandRouter`）
3. 定义 `taxonomy.py`（分类法）
4. 定义 `rules.py`（负向规则）
5. 在 `server.py` 注册 `xxx_route_command` 工具

## 测试

```bash
# 运行所有单元测试（不需要 CAD）
uv run pytest -m unit

# 运行场景测试（需要 CAD 运行）
uv run pytest -m scenario -v -s --timeout=0

# 运行特定阶段的场景
uv run pytest tests/scenarios/test_scenarios.py -k "01_layer" -v
```

| 层级 | 标记 | 说明 | CAD 依赖 |
|------|------|------|----------|
| L1 | `@pytest.mark.unit` | 单元测试（manifest 验证） | 否 |
| L2 | `@pytest.mark.integration` | 基础集成测试 | 是 |
| L3 | `@pytest.mark.scenario` | 场景测试（YAML 数据驱动） | 是 |

## API 命令维护指南

新增/删除/修改 API 命令时，需同步更新：

| 文件 | 优先级 |
|------|--------|
| `src/cad_cowork_mcp/api_commands_manifest.json` | **必须** |
| `src/cad_cowork_mcp/prompts/cad_system_prompt.md` | **必须** |
| `docs/api_commands_index.md` | **必须** |
| `CLAUDE.md`（本文件）API 命令分类表格 | 建议 |
| `tests/data/scenarios/*.yaml` | 建议 |

### 共享提示词模板机制

```
src/cad_cowork_mcp/prompts/cad_system_prompt.md  ← 单一数据源
                    │
        ┌───────────┴───────────┐
        │                       │
        ▼                       ▼
  server.py                AI Agent 客户端
  load_prompt_template()   可读取此文件
        │
        ▼
  替换 {{CAD_NAME}}
  → "CAD" / "AutoCAD" / "浩辰CAD" / "中望CAD"
```

## 看门狗模式（Watchdog）

通过 `CronCreate` 定时任务实现 AI 自主长程工作（30 分钟 - 8 小时），无需人工干预。

### 启动方式

用户发出类似指令时启动：
```
请帮我创建看门狗。任务：XXX。按照 dataflow-to-skill 工作流执行。不要问我任何问题，直接执行。
```

### 工作机制

1. **进度文件** `.claude/watchdog/progress.md` 记录任务步骤和当前状态
2. **CronCreate** 每 3 分钟执行一次看门狗 prompt，检查进度文件
3. 发现未完成步骤 → 立即执行；全部完成 → 回复 HEARTBEAT_OK

### 看门狗 Cron Prompt

```
读取文件 .claude/watchdog/progress.md。
如果当前状态不是 COMPLETED 且有未完成步骤（未勾选的 checkbox），找到第一个未完成步骤，立即执行。
执行完成后更新 progress.md 的 checkbox 和当前状态。
不要问用户任何问题，遇到问题自行决策。
如果所有步骤已完成，将状态改为 COMPLETED，回复 HEARTBEAT_OK。
```

### 行为规则

- **不中断询问**：遇到问题自行决策，不要中途打扰用户
- **即时更新**：每完成一个步骤，立即更新 progress.md
- **容错跳过**：某步骤失败超过 3 次，标注失败原因并跳过，继续下一步
- **参考陷阱**：执行 dataflow-to-skill 类任务时，严格参考其 22 条已知陷阱
