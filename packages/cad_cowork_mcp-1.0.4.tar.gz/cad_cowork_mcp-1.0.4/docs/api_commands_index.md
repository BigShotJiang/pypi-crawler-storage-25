# CAD API 命令索引

> 使用 `get_api_command_info(command_name)` 获取详细参数

## 绘图-基础（10）
| 命令 | 描述 |
|------|------|
| api_draw_line | 绘制直线（startPoint, endPoint） |
| api_draw_circle | 绘制圆（center, radius） |
| api_draw_rectangle | 绘制矩形（corner1, corner2） |
| api_create_polyline | 绘制多段线（points, closed） |
| api_create_arc | 绘制圆弧（center, radius, startAngle, endAngle） |
| api_create_text | 创建单行文字（position, text, height） |
| api_create_mtext | 创建多行文字（position, text, width） |
| api_create_dimension | 创建线性标注（point1, point2, dimLinePoint） |
| api_create_hatch | 创建填充（boundaryHandles, patternName） |
| api_create_leader | 创建引线（points, annotation） |

## 查询（15）
| 命令 | 描述 |
|------|------|
| api_get_entity_info | 获取实体信息（entityHandle） |
| api_get_block_attributes | 获取块属性（entityHandle） |
| api_get_blocks_by_name | 按名称获取块（blockName） |
| api_get_block_definition | 获取块定义信息（blockName） |
| api_batch_get_entity_info | 批量获取实体信息（entityHandles 可选，支持全图扫描/图层/类型过滤） |
| api_query_by_type | 按类型查询实体（entityType） |
| api_query_by_layer | 按图层查询实体（layerName） |
| api_query_by_window | 按窗口范围查询（minPoint, maxPoint） |
| api_query_by_polygon | 按多边形范围查询（points） |
| api_query_nearby_entities | 查询附近实体（center, radius） |
| api_query_connected_entities | 查询连接的实体（entityHandle） |
| api_query_intersecting | 查询相交实体（entityHandle） |
| api_query_by_attribute | 按属性值查询块（attributeName, attributeValue, matchMode: 0=精确/1=包含/2=正则/3=通配符） |
| api_query_all_block_names | 获取所有块名 |
| api_get_unique_attribute_values | 获取属性唯一值（attributeName, blockName, prefix） |

## 块操作（9）
| 命令 | 描述 |
|------|------|
| api_insert_block | 插入块引用（blockName, insertionPoint） |
| api_set_block_attributes | 设置块属性（entityHandle, attributes） |
| api_explode_block | 打散块引用（entityHandle） |
| api_sync_block_references | 同步块引用（blockName） |
| api_create_block_definition | 创建块定义（blockName, basePoint, entityHandles） |
| api_modify_block_definition | 修改块定义（blockName） |
| api_modify_block_base_point | 修改块基点（entityHandle, newBasePoint） |
| api_import_block_from_external | 从外部DWG导入块（blockName, sourceDwgPath） |
| api_rename_block | 重命名块定义：单个(oldBlockName,newBlockName) 或批量(prefix/suffix,pattern) |

## 实体修改（11）
| 命令 | 描述 |
|------|------|
| api_move_entity | 移动实体（entityHandle, fromPoint, toPoint） |
| api_rotate_entity | 旋转实体（entityHandle, basePoint, angle） |
| api_scale_entity | 缩放实体（entityHandle, basePoint, scaleFactor） |
| api_mirror_entity | 镜像实体（entityHandle, point1, point2） |
| api_copy_entity | 复制实体（entityHandle, fromPoint, toPoint） |
| api_set_entity_layer | 设置实体图层（entityHandle, layerName） |
| api_set_entity_color | 设置实体颜色（entityHandle, colorIndex） |
| api_set_entity_properties | 设置实体属性（entityHandle, properties） |
| api_offset_entity | 偏移实体（entityHandle, distance, sidePoint/side） |
| api_trim_extend_entity | 修剪/延伸实体（entityHandle, boundaryHandles） |
| api_delete_entity | 删除实体（entityHandle 或 entityHandles） |

## 批量操作（11）
| 命令 | 描述 |
|------|------|
| api_batch_insert_blocks | 批量插入块（insertions 或 blockName+insertionPoints） |
| api_batch_move | 批量移动（entityHandles, displacement） |
| api_batch_copy | 批量复制（entityHandles, displacement） |
| api_batch_set_layer | 批量设置图层（entityHandles, layerName） |
| api_batch_set_attributes | 批量设置属性（entityHandles, attributes） |
| api_batch_transform | 批量变换（entityHandles, transformType, displacement/basePoint/angle/scaleFactor） |
| api_batch_bring_to_front | 批量前置实体（entityHandles）- 绘图顺序置顶 |
| api_batch_bring_to_behind | 批量后置实体（entityHandles）- 绘图顺序置底 |
| api_batch_get_block_attributes | 批量获取块属性（entityHandles, attributeTags 可选） |
| api_batch_replace_blocks | 批量替换块（oldBlockName, newBlockName, rotationAngle, scale 可选） |
| api_batch_convert_lines_to_polylines | 批量直线转多段线（entityHandles, deleteOriginal 可选） |

## 空间计算（8）
| 命令 | 描述 |
|------|------|
| api_calc_distance | 计算距离（point1, point2 或 entityHandle1, entityHandle2） |
| api_calc_angle | 计算角度（point1, point2, point3） |
| api_calc_area | 计算面积（entityHandle 或 points） |
| api_calc_intersection | 计算交点（entityHandle1, entityHandle2） |
| api_calc_nearest_point | 计算最近点（entityHandle, point） |
| api_calc_bounding_box | 计算包围盒（entityHandle 或 entityHandles） |
| api_calc_centroid | 计算形心（entityHandle） |
| api_point_on_entity | 判断点是否在实体上（entityHandle, point） |

## 图层管理（8）
| 命令 | 描述 |
|------|------|
| api_create_layer | 创建图层（layerName, color） |
| api_delete_layer | 删除图层（layerName） |
| api_set_current_layer | 设置当前图层（layerName） |
| api_get_layer_info | 获取图层信息（layerName） |
| api_list_layers | 列出所有图层 |
| api_set_layer_properties | 设置图层属性（layerName, isOff, isFrozen...） |
| api_import_layer_from_external | 从外部DWG导入图层（layerName, sourceDwgPath） |
| api_rename_layer | 重命名图层（oldName, newName） |

## 文档管理（4）
| 命令 | 描述 |
|------|------|
| api_get_document_info | 获取文档信息 |
| api_save_document | 保存文档（filePath, version） |
| api_get_drawing_extents | 获取图纸范围 |
| api_purge_database | 清理数据库 |

## 视图控制（5）
| 命令 | 描述 |
|------|------|
| api_zoom_extents | 缩放到范围 |
| api_zoom_window | 窗口缩放（minPoint, maxPoint） |
| api_zoom_object | 缩放到对象（entityHandle） |
| api_zoom_center | 中心缩放（center, magnification） |
| api_get_current_view | 获取当前视图 |

## 选择集（7）
| 命令 | 描述 |
|------|------|
| api_select_all | 全选（entityType 可选） |
| api_select_by_filter | 按条件筛选（entityType/layerName/colorIndex/blockName） |
| api_select_window | 窗口选择（minPoint, maxPoint） |
| api_select_fence | 栏选（points） |
| api_get_selection_set | 获取选择集 |
| api_window_select_with_filter | 交互式框选+条件过滤（entityTypes/layerNames/colorIndex） |
| api_export_selection_preview | 导出选择预览图（entityHandles） |

## 事务控制（3）
| 命令 | 描述 |
|------|------|
| api_transaction_begin | 开始全局事务（用于批量操作原子性控制） |
| api_transaction_commit | 提交全局事务（transactionId） |
| api_transaction_rollback | 回滚全局事务（transactionId） |

---

## 参数类型说明

| 类型 | 格式 | 示例 |
|------|------|------|
| Point3D | [x, y, z] | [100, 200, 0] |
| PointArray | [[x1,y1,z1], ...] | [[0,0,0], [100,100,0]] |
| EntityHandle | 十六进制字符串 | "27E2C0" |
| HandleArray | 句柄数组 | ["27E2C0", "27E2D0"] |
| Json | JSON对象 | {"key": "value"} |

## 工艺流程图（39）

### 查询类（8）
| 命令 | 描述 |
|------|------|
| api_gslc_query_frame_info | 查询图框信息（frameHandle 可选） |
| api_gslc_query_equipment_in_frame | 查询图框内设备（frameHandle） |
| api_gslc_query_instrument_in_frame | 查询图框内仪表（frameHandle） |
| api_gslc_query_pipe_in_frame | 查询图框内管道（frameHandle） |
| api_gslc_query_valve_in_frame | 查询图框内阀门（frameHandle） |
| api_gslc_query_join_draw_arrow_in_frame | 查询图框内接图箭头（frameHandle） |
| api_gslc_query_all_entities_in_frame | 查询图框内所有实体（frameHandle） |
| api_gslc_query_entities_by_relative_position | 按相对位置查询实体（referenceHandle） |

### 插入类（8）
| 命令 | 描述 |
|------|------|
| api_gslc_insert_equipment | 插入设备（equipType, position） |
| api_gslc_insert_instrument | 插入仪表（instrumentType, position） |
| api_gslc_insert_control_valve | 插入控制阀门（valveType, position） |
| api_gslc_insert_valve | 插入阀门（valveType, position） |
| api_gslc_insert_pipe | 插入管道（position） |
| api_gslc_insert_join_draw_arrow | 插入接图箭头（position, direction） |
| api_gslc_insert_outer_pipe_arrow | 插入外管箭头（position, arrowType） |
| api_gslc_insert_equip_tag | 插入设备位号（position, tag） |

> 批量插入请使用基础命令 `api_batch_insert_blocks`（支持 entities 参数别名）

### 刷新类（4）
| 命令 | 描述 |
|------|------|
| api_gslc_brush_join_draw_arrow | 刷接图箭头（arrowHandles, relatedPipeHandle） |
| api_gslc_brush_pipeline_elements | 刷管道元素关联（pipeHandle, elementHandles） |
| api_gslc_brush_batch_instruments | 批量刷仪表（brushItems） |
| api_gslc_brush_batch_pipes | 批量刷管道（brushItems） |

### 更新/生成/工具/数据类（20）
| 命令 | 描述 |
|------|------|
| api_gslc_clear_relative_position | 清除相对位置（entityHandles） |

> 更新实体属性请使用基础命令 `api_batch_set_attributes`
> 批量替换块请使用基础命令 `api_batch_replace_blocks`
| api_gslc_generate_equipment_list | 生成设备一览表（frameHandle 可选） |
| api_gslc_insert_bottom_equip_tags | 批量生成底部设备位号（frameHandles 可选） |
| api_gslc_move_to_freeze_layer | 移动到冻结图层（entityHandles） |
| api_gslc_restore_from_freeze_layer | 从冻结图层恢复（entityHandles） |
| api_gslc_auto_number | 自动编号（dataType, numberMode, numberDirection） |
| api_gslc_text_to_pipe_arrow | 管道号文字转块（layerName, pipeNumPattern） |
| api_gslc_tag_text_to_block | 设备位号文字转块（layerName, blockType, wildcardPattern） |
| api_gslc_replace_instrument_block | 散装仪表转块（layerName, minRadius, maxRadius） |
| api_gslc_export_frame_data | 导出图框数据（frameHandle） |
| api_gslc_validate_entity_data | 验证实体数据（frameHandle） |
| api_gslc_export_all_data | 导出全部流程图数据（设备+仪表+管道+阀门），flat JArray 格式（selectionMode/outputPath） |
| api_gslc_sync_pipe_data | 同步管道数据（jsonFilePath/syncData） |
| api_gslc_sync_equipment_data | 同步设备数据（jsonFilePath/syncData） |
| api_gslc_sync_instrument_data | 同步仪表数据（jsonFilePath/syncData） |

---

## 调用方式

```json
// 通过 smart_cad_command 调用
{"command_name": "api_draw_circle", "parameters": {"center": [100,100,0], "radius": 50}}
```
