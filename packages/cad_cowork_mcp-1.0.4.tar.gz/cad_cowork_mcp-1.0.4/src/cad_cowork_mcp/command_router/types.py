"""
命令路由类型定义
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any


@dataclass
class CommandCandidate:
    """命令候选项"""
    command: str                          # 命令名称，如 api_gslc_insert_bottom_equip_tags
    score: float                          # 匹配得分 [0, 1]
    category: str                         # 所属类别，如 insert/query/brush
    reason: str                           # 推荐理由（命令描述）
    why_not: Optional[str] = None         # 为什么不应该选这个（负向引导）
    usage_example: Optional[str] = None   # 使用示例


@dataclass
class RoutingResult:
    """路由结果"""
    domain: str                           # 命令所属域，如 gslc/gsbz/basic
    intent_category: str                  # 识别的意图类别，如 insert/query
    intent_confidence: float              # 意图置信度 [0, 1]
    recommended: Optional[Dict[str, Any]] # 推荐命令（得分最高的候选）
    candidates: List[CommandCandidate]    # 候选列表（最多5个）
    disambiguation_hint: Optional[str] = None  # 消歧提示（当top2得分接近时）


@dataclass
class IntentCategory:
    """意图类别定义"""
    name: str                             # 类别名称
    display_name: str                     # 显示名称
    keywords: List[str] = field(default_factory=list)       # 触发关键词
    anti_keywords: List[str] = field(default_factory=list)  # 反向关键词


@dataclass
class EntityType:
    """实体类型定义"""
    name: str                             # 实体名称
    display_name: str                     # 显示名称
    keywords: List[str] = field(default_factory=list)  # 识别关键词


@dataclass
class CommandMapping:
    """命令映射定义"""
    name: str                             # 命令名称
    intent: str                           # 所属意图类别
    entity: Any                           # 目标实体类型（str 或 List[str]）
    keywords: List[str] = field(default_factory=list)       # 触发关键词
    anti_patterns: List[str] = field(default_factory=list)  # 反模式（降权）
    description: str = ""                 # 命令描述
    differentiator: Optional[str] = None  # 差异化特征
