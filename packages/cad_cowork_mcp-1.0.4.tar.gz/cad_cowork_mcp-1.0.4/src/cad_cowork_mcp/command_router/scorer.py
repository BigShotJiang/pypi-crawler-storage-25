"""
命令评分引擎

评分机制：
- 基础分: 0.5
- 意图匹配: +0.25
- 实体匹配: +0.20
- 关键词匹配: +0.15 (每个，最多3个)
- 反模式惩罚: -0.30 (每个)
- 差异化特征: +0.15
"""

from typing import Dict, List, Any, Optional


class ScoringEngine:
    """评分引擎"""

    # 基础分
    BASE_SCORE = 0.5

    # 权重配置
    WEIGHTS = {
        "intent_match": 0.25,           # 意图匹配
        "entity_match": 0.20,           # 实体类型匹配
        "keyword_match": 0.15,          # 关键词匹配（每个）
        "keyword_max": 3,               # 关键词匹配上限
        "anti_pattern_penalty": -0.30,  # 反模式惩罚（每个）
        "differentiator_match": 0.15,   # 差异化特征匹配
        "context_boost": 0.10,          # 上下文加成
    }

    def calculate_score(
        self,
        user_intent: str,
        command_def: Dict[str, Any],
        intent_category: str,
        recognized_entities: List[str],
        context: Optional[Dict] = None
    ) -> float:
        """
        计算命令得分

        Args:
            user_intent: 用户意图描述
            command_def: 命令定义
            intent_category: 识别出的意图类别
            recognized_entities: 识别出的实体类型列表
            context: 可选上下文

        Returns:
            归一化得分 [0, 1]
        """
        score = self.BASE_SCORE

        # 1. 意图匹配
        if command_def.get("intent") == intent_category:
            score += self.WEIGHTS["intent_match"]

        # 2. 实体匹配
        cmd_entities = command_def.get("entity", [])
        if isinstance(cmd_entities, str):
            cmd_entities = [cmd_entities]
        if any(e in recognized_entities for e in cmd_entities):
            score += self.WEIGHTS["entity_match"]

        # 3. 关键词匹配
        keywords = command_def.get("keywords", [])
        keyword_matches = sum(1 for kw in keywords if kw in user_intent)
        score += self.WEIGHTS["keyword_match"] * min(keyword_matches, self.WEIGHTS["keyword_max"])

        # 4. 反模式惩罚
        anti_patterns = command_def.get("anti_patterns", [])
        anti_matches = sum(1 for kw in anti_patterns if kw in user_intent)
        score += self.WEIGHTS["anti_pattern_penalty"] * anti_matches

        # 5. 差异化特征匹配
        differentiator = command_def.get("differentiator")
        if differentiator:
            # 按中文逗号或英文逗号分割
            diff_keywords = [k.strip() for k in differentiator.replace("，", ",").split(",")]
            if any(kw in user_intent for kw in diff_keywords if kw):
                score += self.WEIGHTS["differentiator_match"]

        # 6. 上下文加成
        if context:
            context_score = self._evaluate_context(context, command_def)
            score += self.WEIGHTS["context_boost"] * context_score

        # 归一化到 [0, 1]
        return max(0.0, min(1.0, score))

    def _evaluate_context(self, context: Dict, command_def: Dict) -> float:
        """
        评估上下文匹配度

        Args:
            context: 上下文信息 (has_frame_handle, has_entity_handles, target_entity_type)
            command_def: 命令定义

        Returns:
            上下文得分 [0, 1]
        """
        score = 0.0

        # 如果有图框句柄，优先推荐需要图框的命令
        if context.get("has_frame_handle"):
            cmd_name = command_def.get("name", "")
            if "frame" in cmd_name.lower() or "in_frame" in cmd_name.lower():
                score += 0.5

        # 如果有实体句柄，优先推荐需要实体的命令
        if context.get("has_entity_handles"):
            keywords = command_def.get("keywords", [])
            if any(kw in ["批量", "刷新", "更新"] for kw in keywords):
                score += 0.3

        # 目标实体类型匹配
        target_type = context.get("target_entity_type")
        if target_type:
            cmd_entities = command_def.get("entity", [])
            if isinstance(cmd_entities, str):
                cmd_entities = [cmd_entities]
            if target_type in cmd_entities:
                score += 0.5

        return min(1.0, score)
