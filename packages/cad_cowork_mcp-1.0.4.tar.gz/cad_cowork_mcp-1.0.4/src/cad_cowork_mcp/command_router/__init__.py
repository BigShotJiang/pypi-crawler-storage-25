"""
命令路由框架

提供业务域命令的智能路由能力，解决 agent 在面对大量相似命令时的选择困难问题。

架构：
    command_router/          # 共享路由框架
    ├── types.py            # 类型定义
    ├── scorer.py           # 评分引擎
    └── base_router.py      # 路由器基类

    domains/                 # 业务域实现
    └── gslc/               # 工艺流程图路由器
        ├── router.py
        ├── taxonomy.py
        └── rules.py

使用方式：
    from domains.gslc.router import GsLcRouter

    router = GsLcRouter()
    result = router.route("批量生成设备位号")
    print(result.recommended)  # api_gslc_insert_bottom_equip_tags
"""

from .types import CommandCandidate, RoutingResult
from .base_router import BaseCommandRouter
from .scorer import ScoringEngine

__all__ = [
    'CommandCandidate',
    'RoutingResult',
    'BaseCommandRouter',
    'ScoringEngine',
]
