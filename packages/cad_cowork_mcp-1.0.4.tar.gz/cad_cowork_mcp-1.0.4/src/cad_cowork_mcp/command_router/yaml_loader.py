"""
声明式业务域配置加载器

从 YAML 配置文件自动生成 Router 实例，新增业务域只需写 YAML 不需要写 Python 代码。

YAML 配置格式示例见: domains/gslc/domain.yaml (若存在)
"""

import logging
import os
from typing import Any, Dict, List, Optional

from .base_router import BaseCommandRouter
from .types import CommandCandidate
from .scorer import ScoringEngine

logger = logging.getLogger('domain_loader')


class YamlDomainRouter(BaseCommandRouter):
    """从 YAML 配置生成的通用域路由器"""

    def __init__(self, config: Dict[str, Any]):
        self._config = config
        self._domain = config["domain"]
        self._intents = config.get("intents", {})
        self._entities = config.get("entities", {})
        self._commands = config.get("commands", {})
        self._negative_rules_config = config.get("negative_rules", [])
        self._disambiguation_hints = config.get("disambiguation_hints", [])
        super().__init__()

    @property
    def domain_name(self) -> str:
        return self._domain

    def _load_taxonomy(self):
        """YAML 配置在 __init__ 中已加载"""
        pass

    def _get_intent_categories(self) -> Dict:
        return self._intents

    def _get_command_mappings(self) -> Dict:
        return self._commands

    def _get_negative_rules(self) -> List:
        rules = []
        for rule_cfg in self._negative_rules_config:
            trigger_expr = rule_cfg.get("trigger", "")
            wrong = rule_cfg.get("wrong_commands", [])
            penalty = rule_cfg.get("penalty", 0.3)
            reason = rule_cfg.get("reason", "")

            # 将字符串表达式编译为 lambda
            # 安全: 只允许 in / not in / and / or 操作
            try:
                trigger_fn = _compile_trigger(trigger_expr)
            except Exception as e:
                logger.warning(f"无法编译规则触发条件: {trigger_expr} — {e}")
                continue

            rules.append({
                "trigger": trigger_fn,
                "wrong": wrong,
                "penalty": penalty,
                "why_not": reason,
            })
        return rules

    def _recognize_entities(self, user_intent: str) -> List[str]:
        recognized = []
        for entity_name, entity_def in self._entities.items():
            keywords = entity_def.get("keywords", [])
            if any(kw in user_intent for kw in keywords):
                recognized.append(entity_name)
        return recognized

    def _generate_candidates(
        self,
        intent: Dict,
        entities: List[str],
        user_intent: str,
        context: Optional[Dict]
    ) -> List[CommandCandidate]:
        candidates = []
        for cmd_name, cmd_def in self._commands.items():
            score = self.scorer.calculate_score(
                intent_match=(intent["category"] == cmd_def.get("intent", "")),
                entity_match=bool(set(entities) & set(cmd_def.get("entities", []))),
                keyword_matches=[kw for kw in cmd_def.get("keywords", []) if kw in user_intent],
                anti_pattern_matches=[kw for kw in cmd_def.get("anti_keywords", []) if kw in user_intent],
                differentiator_match=any(d in user_intent for d in cmd_def.get("differentiators", [])),
                context=context,
                context_features=cmd_def.get("context_features", {})
            )

            full_cmd_name = f"api_{self._domain}_{cmd_name}"
            candidates.append(CommandCandidate(
                command=full_cmd_name,
                score=score,
                category=cmd_def.get("intent", "unknown"),
                reason=cmd_def.get("description", ""),
                why_not=None,
                usage_example=cmd_def.get("usage_example")
            ))
        return candidates

    def _generate_disambiguation_hint(
        self,
        candidates: List[CommandCandidate],
        user_intent: str
    ) -> Optional[str]:
        if len(candidates) < 2:
            return None

        top_two = candidates[:2]
        score_diff = top_two[0].score - top_two[1].score

        if score_diff >= 0.3:
            return None

        # 查找预定义的消歧提示
        cmd_pair = {top_two[0].command, top_two[1].command}
        for hint in self._disambiguation_hints:
            hint_pair = set(hint.get("pair", []))
            # 支持简写（不带 api_domain_ 前缀）
            hint_pair_full = {f"api_{self._domain}_{c}" for c in hint_pair}
            if cmd_pair & hint_pair_full:
                return hint.get("hint", "")

        return f"Top 2 candidates are close: {top_two[0].command} ({top_two[0].score:.2f}) vs {top_two[1].command} ({top_two[1].score:.2f})"


def _compile_trigger(expr: str):
    """将简单的字符串条件表达式编译为 lambda

    安全: 只允许 'in intent' / 'not in intent' / and / or 操作。
    输入示例: '"批量生成" in intent and "编号" not in intent'

    Args:
        expr: 条件表达式字符串

    Returns:
        callable: (user_intent: str) -> bool
    """
    # 用 lambda 包装，intent 变量名映射到参数
    # 安全检查：不允许危险操作
    allowed_tokens = {'in', 'not', 'and', 'or', 'intent', '(', ')'}
    # 提取所有非字符串 token
    import re
    tokens = re.findall(r'[a-zA-Z_]+', expr)
    for token in tokens:
        if token not in allowed_tokens:
            raise ValueError(f"不允许的 token: {token}")

    return lambda intent: eval(expr, {"__builtins__": {}}, {"intent": intent})


def load_domain_from_yaml(yaml_path: str) -> YamlDomainRouter:
    """从 YAML 文件加载域路由器

    Args:
        yaml_path: YAML 配置文件路径

    Returns:
        YamlDomainRouter 实例
    """
    try:
        import yaml
    except ImportError:
        raise ImportError("需要 PyYAML 库来加载 YAML 域配置: pip install pyyaml")

    with open(yaml_path, 'r', encoding='utf-8') as f:
        config = yaml.safe_load(f)

    if "domain" not in config:
        raise ValueError(f"YAML 配置缺少 'domain' 字段: {yaml_path}")

    logger.info(f"从 YAML 加载域路由器: {config['domain']} ({yaml_path})")
    return YamlDomainRouter(config)


def discover_yaml_domains(domains_dir: str) -> Dict[str, YamlDomainRouter]:
    """自动发现并加载目录下所有 domain.yaml 配置

    Args:
        domains_dir: 域目录路径（如 src/cad_cowork_mcp/domains/）

    Returns:
        {domain_name: YamlDomainRouter} 字典
    """
    routers = {}

    if not os.path.isdir(domains_dir):
        return routers

    for entry in os.listdir(domains_dir):
        yaml_path = os.path.join(domains_dir, entry, "domain.yaml")
        if os.path.isfile(yaml_path):
            try:
                router = load_domain_from_yaml(yaml_path)
                routers[router.domain_name] = router
                logger.info(f"发现 YAML 域: {router.domain_name}")
            except Exception as e:
                logger.warning(f"加载域配置失败 {yaml_path}: {e}")

    return routers
