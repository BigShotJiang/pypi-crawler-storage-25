"""
命令路由器基类

所有业务域路由器都继承此类，实现以下抽象方法：
- domain_name: 域名称
- _load_taxonomy: 加载分类法
- _get_intent_categories: 获取意图类别
- _get_command_mappings: 获取命令映射
- _get_negative_rules: 获取负向规则
- _recognize_entities: 识别实体类型
- _generate_candidates: 生成候选命令
- _generate_disambiguation_hint: 生成消歧提示
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Any

from .types import RoutingResult, CommandCandidate
from .scorer import ScoringEngine


class BaseCommandRouter(ABC):
    """命令路由器基类"""

    def __init__(self):
        self.scorer = ScoringEngine()
        self._load_taxonomy()

    @property
    @abstractmethod
    def domain_name(self) -> str:
        """域名称，如 'gslc', 'gsbz'"""
        pass

    @abstractmethod
    def _load_taxonomy(self):
        """加载分类法配置"""
        pass

    @abstractmethod
    def _get_intent_categories(self) -> Dict:
        """获取意图类别定义"""
        pass

    @abstractmethod
    def _get_command_mappings(self) -> Dict:
        """获取命令映射"""
        pass

    @abstractmethod
    def _get_negative_rules(self) -> List:
        """获取负向引导规则"""
        pass

    @abstractmethod
    def _recognize_entities(self, user_intent: str) -> List[str]:
        """识别实体类型"""
        pass

    @abstractmethod
    def _generate_candidates(
        self,
        intent: Dict,
        entities: List[str],
        user_intent: str,
        context: Optional[Dict]
    ) -> List[CommandCandidate]:
        """生成候选命令"""
        pass

    @abstractmethod
    def _generate_disambiguation_hint(
        self,
        candidates: List[CommandCandidate],
        user_intent: str
    ) -> Optional[str]:
        """生成消歧提示"""
        pass

    def route(self, user_intent: str, context: Optional[Dict] = None) -> RoutingResult:
        """
        执行命令路由

        Args:
            user_intent: 用户意图描述
            context: 可选上下文 (has_frame_handle, has_entity_handles, target_entity_type)

        Returns:
            RoutingResult: 路由结果
        """
        # 1. 意图识别
        intent = self._recognize_intent(user_intent)

        # 2. 实体识别
        entities = self._recognize_entities(user_intent)

        # 3. 生成候选并评分
        candidates = self._generate_candidates(intent, entities, user_intent, context)

        # 4. 应用负向规则
        candidates = self._apply_negative_rules(candidates, user_intent)

        # 5. 排序
        candidates.sort(key=lambda x: x.score, reverse=True)

        # 6. 生成消歧提示
        hint = self._generate_disambiguation_hint(candidates, user_intent)

        # 7. 构建结果
        recommended = self._format_recommended(candidates[0]) if candidates else None

        return RoutingResult(
            domain=self.domain_name,
            intent_category=intent["category"],
            intent_confidence=intent["confidence"],
            recommended=recommended,
            candidates=candidates[:5],  # 最多返回5个
            disambiguation_hint=hint
        )

    def _recognize_intent(self, user_intent: str) -> Dict:
        """
        意图识别

        Args:
            user_intent: 用户意图描述

        Returns:
            {"category": str, "confidence": float}
        """
        categories = self._get_intent_categories()
        best_match = {"category": "unknown", "confidence": 0.0}

        for cat_name, cat_def in categories.items():
            # 计算关键词匹配
            keywords = cat_def.get("keywords", [])
            keyword_score = sum(1 for kw in keywords if kw in user_intent)

            # 计算反向关键词惩罚
            anti_keywords = cat_def.get("anti_keywords", [])
            anti_score = sum(1 for kw in anti_keywords if kw in user_intent)

            # 综合得分
            score = keyword_score - anti_score * 0.5
            confidence = min(1.0, score / 3.0)  # 归一化

            if confidence > best_match["confidence"]:
                best_match = {"category": cat_name, "confidence": confidence}

        return best_match

    def _apply_negative_rules(
        self,
        candidates: List[CommandCandidate],
        user_intent: str
    ) -> List[CommandCandidate]:
        """
        应用负向引导规则

        Args:
            candidates: 候选命令列表
            user_intent: 用户意图描述

        Returns:
            应用规则后的候选列表
        """
        rules = self._get_negative_rules()

        for rule in rules:
            trigger = rule.get("trigger")
            if trigger and callable(trigger) and trigger(user_intent):
                wrong_commands = rule.get("wrong", [])
                why_not = rule.get("why_not", "")

                for candidate in candidates:
                    if candidate.command in wrong_commands:
                        # 大幅降低分数
                        candidate.score *= 0.3
                        # 设置负向引导说明
                        candidate.why_not = why_not

        return candidates

    def _format_recommended(self, candidate: CommandCandidate) -> Dict[str, Any]:
        """
        格式化推荐命令

        Args:
            candidate: 得分最高的候选

        Returns:
            推荐命令字典
        """
        return {
            "command": candidate.command,
            "score": round(candidate.score, 2),
            "category": candidate.category,
            "reason": candidate.reason,
            "usage_example": candidate.usage_example
        }
