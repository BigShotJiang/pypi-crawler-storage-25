"""Support running with: python -m cad_cowork_mcp"""

from .server import main_cli

main_cli()
