import logging
import math
import time
import os
import json
import tempfile
from typing import Any, Dict, List, Optional, Tuple, Union

# 直接读取config.json文件
config_path = os.path.join(os.path.dirname(__file__), 'config.json')
with open(config_path, 'r', encoding='utf-8') as f:
    config = json.load(f)

try:
    import win32com.client
    # pythoncom是pywin32的一部分，不需要单独安装
    import pythoncom
except ImportError:
    logging.error("无法导入win32com.client或pythoncom，请确保已安装pywin32库")
    raise

logger = logging.getLogger('cad_controller')

class CADController:
    """CAD控制器类，负责与CAD应用程序交互"""
    
    def __init__(self):
        """初始化CAD控制器"""
        self.app = None
        self.doc = None
        self.entities = {}  # 存储已创建图形的实体引用，用于后续修改
        # 从配置文件加载参数
        self.startup_wait_time = config["cad"]["startup_wait_time"]
        self.command_delay = config["cad"]["command_delay"]
        # 获取CAD类型
        self.cad_type = config["cad"]["type"]
        # 有效的线宽值列表
        self.valid_lineweights = [0, 5, 9, 13, 15, 18, 20, 25, 30, 35, 40, 50, 53, 60, 70, 80, 90, 100, 106, 120, 140, 158, 200, 211]
        logger.info("CAD控制器已初始化")
    
    def start_cad(self) -> bool:
        """启动CAD并创建或打开一个文档"""
        try:
            # 初始化COM
            pythoncom.CoInitialize()
            
            # 存储旧实例引用（如果有）以便后续清理
            old_app = None
            if self.app is not None:
                old_app = self.app
                self.app = None
                self.doc = None
            
            try:
                # 根据配置的CAD类型选择不同的应用程序标识符
                app_id = "AutoCAD.Application"
                app_name = "AutoCAD"
                
                if self.cad_type.lower() == "autocad":
                    app_id = "AutoCAD.Application"
                    app_name = "AutoCAD"
                elif self.cad_type.lower() == "gcad":
                    app_id = "GCAD.Application"
                    app_name = "浩辰CAD"
                elif self.cad_type.lower() == "gstarcad":
                    app_id = "GCAD.Application"
                    app_name = "浩辰CAD"
                elif self.cad_type.lower() == "zwcad":
                    app_id = "ZWCAD.Application"
                    app_name = "中望CAD"
                
                # 尝试连接到已运行的CAD实例
                logger.info(f"尝试连接现有{app_name}实例...")
                try:
                    self.app = win32com.client.GetActiveObject(app_id)
                    logger.info(f"成功连接到已运行的{app_name}实例")
                except Exception as e:
                    logger.info(f"未找到运行中的{app_name}实例，将尝试启动新实例: {str(e)}")  
                    raise

                # 已在上面的代码中处理
                
                # 如果当前没有文档，创建一个新文档
                try:
                    if self.app.Documents.Count == 0:
                        logger.info("创建新文档...")
                        self.doc = self.app.Documents.Add()
                    else:
                        logger.info("获取活动文档...")
                        self.doc = self.app.ActiveDocument
                except Exception as doc_ex:
                    # 如果获取文档失败，强制创建新文档
                    logger.warning(f"获取文档失败，尝试创建新文档: {str(doc_ex)}")
                    try:
                        # 关闭所有打开的文档
                        for i in range(self.app.Documents.Count):
                            try:
                                self.app.Documents.Item(0).Close(False)  # 不保存
                            except:
                                pass
                        
                        # 创建新文档
                        self.doc = self.app.Documents.Add()
                    except Exception as new_doc_ex:
                        logger.error(f"创建新文档失败: {str(new_doc_ex)}")
                        raise
                    
            except Exception as app_ex:
                # 如果连接失败，启动一个新实例
                logger.info(f"连接失败，正在启动新的CAD实例: {str(app_ex)}")
                try:
                    # 根据配置的CAD类型启动相应的应用程序
                    app_id = "AutoCAD.Application"
                    app_name = "AutoCAD"
                    
                    if self.cad_type.lower() == "autocad":
                        app_id = "AutoCAD.Application"
                        app_name = "AutoCAD"
                    elif self.cad_type.lower() == "gcad":
                        app_id = "GCAD.Application"
                        app_name = "浩辰CAD"
                    elif self.cad_type.lower() == "gstarcad":
                        app_id = "GCAD.Application"
                        app_name = "浩辰CAD"
                    elif self.cad_type.lower() == "zwcad":
                        app_id = "ZWCAD.Application"
                        app_name = "中望CAD"
                    
                    logger.info(f"正在启动{app_name}实例...")
                    self.app = win32com.client.Dispatch(app_id)
                    self.app.Visible = True
                    
                    # 等待CAD启动
                    time.sleep(self.startup_wait_time)  # 使用配置的等待时间
                    
                    # 创建新文档
                    logger.info("尝试创建新文档...")
                    # self.doc = self.app.Documents.Add()
                    self.doc = self.app.ActiveDocument
                except Exception as new_app_ex:
                    logger.error(f"启动新CAD实例失败: {str(new_app_ex)}")
                    raise
            
            # 额外安全检查和等待
            time.sleep(2)  # 给CAD更多时间处理文档创建
            
            if self.doc is None:
                raise Exception("无法获取有效的Document对象")
            
            # 尝试读取文档属性以验证其有效性
            try:
                name = self.doc.Name
                logger.info(f"文档名称: {name}")
            except Exception as name_ex:
                logger.error(f"无法读取文档名称: {str(name_ex)}")
                raise Exception("文档对象无效")
            
            logger.info("CAD已成功启动和准备")
            return True
            
        except Exception as e:
            logger.error(f"启动CAD失败: {str(e)}")
            return False
        finally:
            # 清理旧实例
            if old_app is not None:
                try:
                    del old_app
                except:
                    pass
    
        
    def is_running(self) -> bool:
        """检查CAD是否正在运行（验证 COM 对象有效性）"""
        if self.app is None or self.doc is None:
            return False

        # 主动验证 COM 对象是否仍然有效
        try:
            _ = self.doc.Name  # 快速无副作用的属性访问，会触发 RPC 调用
            return True
        except Exception as e:
            logger.warning(f"COM 连接无效: {e}")
            return False

    def _refresh_active_document(self) -> bool:
        """刷新活跃文档引用，确保指向当前打开的图纸

        当用户在 CAD 中切换图纸时，self.doc 可能指向已不活跃的文档。
        此方法会检测并更新 self.doc 指向当前活跃文档。

        Returns:
            bool: 刷新成功返回 True，失败返回 False
        """
        if self.app is None:
            logger.error("Application 对象为空，无法刷新文档")
            return False

        try:
            # 先验证 Application 对象是否有效
            try:
                _ = self.app.Documents.Count
            except Exception as app_e:
                # Application 对象已失效，需要重连
                logger.warning(f"Application 对象已失效: {app_e}")
                return False  # 让调用者触发重连

            # 获取当前活跃文档
            new_doc = self.app.ActiveDocument

            if new_doc is None:
                # 检查是否有打开的文档
                if self.app.Documents.Count > 0:
                    new_doc = self.app.Documents.Item(0)
                    logger.info("ActiveDocument 为空，使用第一个打开的文档")
                else:
                    logger.warning("当前没有打开的文档")
                    return False

            # 检查是否需要更新（通过文档名称判断，避免直接比较 COM 对象）
            try:
                old_name = self.doc.Name if self.doc else None
            except Exception:
                old_name = None  # 旧文档已失效

            try:
                new_name = new_doc.Name
            except Exception as e:
                logger.error(f"无法获取新文档名称: {e}")
                return False

            # 更新文档引用
            if old_name != new_name:
                logger.info(f"检测到图纸切换: '{old_name}' -> '{new_name}'")
                self.doc = new_doc
                # 清理旧的实体缓存（因为实体 Handle 在不同图纸中可能不同）
                self.entities = {}
                logger.info(f"已更新 Document 引用，清空实体缓存")
            elif self.doc is None:
                # 如果 self.doc 为空但名称相同（首次设置）
                self.doc = new_doc
                logger.info(f"设置 Document 引用: {new_name}")

            return True

        except Exception as e:
            error_str = str(e)
            # 检查是否是 COM 断开错误
            if "-2147417848" in error_str or "RPC_E_DISCONNECTED" in error_str.upper():
                logger.warning(f"COM 连接已断开: {e}")
                return False  # 让调用者触发重连

            logger.error(f"刷新活跃文档失败: {e}")
            return False

    def _try_reconnect(self) -> bool:
        """尝试重新连接到 CAD

        当 COM 连接断开时，尝试重新建立连接。
        会先清理旧的 COM 对象，然后重新获取。

        Returns:
            bool: 重连成功返回 True，失败返回 False
        """
        logger.info("尝试重新连接 CAD...")

        try:
            # 先清理旧的 COM 对象引用
            self.app = None
            self.doc = None
            self.entities = {}

            # 重新初始化 COM（确保在当前线程中初始化）
            try:
                pythoncom.CoInitialize()
            except Exception as com_init_e:
                logger.debug(f"COM 已初始化: {com_init_e}")

            # 根据 CAD 类型获取 app_id
            app_id = "AutoCAD.Application"
            if self.cad_type.lower() in ["gcad", "gstarcad"]:
                app_id = "GCAD.Application"
            elif self.cad_type.lower() == "zwcad":
                app_id = "ZWCAD.Application"

            logger.info(f"尝试连接 {app_id}...")

            # 尝试连接到已运行的实例
            try:
                self.app = win32com.client.GetActiveObject(app_id)
                logger.info("GetActiveObject 成功")
            except Exception as get_active_e:
                logger.warning(f"GetActiveObject 失败: {get_active_e}，尝试 Dispatch...")
                # 如果 GetActiveObject 失败，尝试 Dispatch（可能会启动新实例）
                self.app = win32com.client.Dispatch(app_id)
                logger.info("Dispatch 成功")

            # 确保应用可见
            try:
                self.app.Visible = True
            except Exception:
                pass

            # 获取活跃文档
            self.doc = self.app.ActiveDocument

            if self.doc is None:
                # 检查是否有打开的文档
                if self.app.Documents.Count == 0:
                    logger.warning("CAD 中没有打开的文档")
                    return False
                else:
                    self.doc = self.app.Documents.Item(0)

            if self.doc is None:
                logger.warning("重连成功但无法获取文档")
                return False

            # 验证连接
            doc_name = self.doc.Name
            logger.info(f"重新连接成功，当前文档: {doc_name}")

            return True

        except Exception as e:
            logger.error(f"重新连接失败: {e}")
            self.app = None
            self.doc = None
            return False

    def _ensure_valid_connection(self) -> bool:
        """确保有有效的 CAD 连接

        执行操作前调用此方法，会自动处理：
        1. 检查连接是否有效
        2. 刷新文档引用（处理图纸切换）
        3. 必要时尝试重连

        Returns:
            bool: 连接有效返回 True，否则返回 False
        """
        # 首先检查基本连接
        if self.app is None:
            return self._try_reconnect()

        # 刷新文档引用（处理图纸切换的情况）
        if not self._refresh_active_document():
            return self._try_reconnect()

        return True

    def send_command(self, command: str) -> dict:
        """发送命令到 CAD 命令行

        用于调用 AutoCAD 原生命令或已加载的 .NET 插件命令（如 cad-cowork-cstool）

        Args:
            command: 要执行的命令字符串，不需要包含换行符

        Returns:
            dict: 包含 success 和 message 的结果字典
        """
        # 确保有效连接（处理图纸切换等情况）
        if not self._ensure_valid_connection():
            return {"success": False, "message": "CAD未运行或连接已断开，请确保CAD已启动"}

        try:
            # 确保命令以换行符结尾
            if not command.endswith("\n"):
                command = command + "\n"

            # 发送命令到 CAD
            self.doc.SendCommand(command)

            # 等待命令执行完成
            time.sleep(self.command_delay)

            logger.info(f"命令已发送: {command.strip()}")
            return {"success": True, "message": f"命令 '{command.strip()}' 已执行"}

        except Exception as e:
            error_msg = str(e)
            # 检测是否是 COM 连接断开错误
            if "-2147417848" in error_msg or "RPC_E_DISCONNECTED" in error_msg.upper():
                logger.warning("检测到 COM 连接断开，尝试重连...")
                if self._try_reconnect():
                    # 重连成功，重试一次
                    try:
                        self.doc.SendCommand(command)
                        time.sleep(self.command_delay)
                        logger.info(f"重连后命令已发送: {command.strip()}")
                        return {"success": True, "message": f"命令 '{command.strip()}' 已执行（重连后）"}
                    except Exception as retry_e:
                        error_msg = f"重连后发送命令仍然失败: {str(retry_e)}"

            logger.error(f"发送命令失败: {error_msg}")
            return {"success": False, "message": f"发送命令失败: {error_msg}"}

    def save_drawing(self, file_path: str) -> bool:
        """保存当前图纸到指定路径"""
        if not self.is_running():
            logger.error("CAD未运行，无法保存图纸")
            return False
            
        try:
            # 确保目录存在
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            
            # 保存文件
            self.doc.SaveAs(file_path)
            logger.info(f"图纸已保存到: {file_path}")
           
            return True
        except Exception as e:
            logger.error(f"保存图纸失败: {str(e)}")
            return False
    
    def refresh_view(self) -> None:
        """刷新CAD视图"""
        if self.is_running():
            try:
                self.doc.Regen(1)  # acAllViewports = 1
            except Exception as e:
                logger.error(f"刷新视图失败: {str(e)}")
    
    def validate_lineweight(self, lineweight) -> int:
        """验证并返回有效的线宽值
        
        如果提供的线宽值不在有效值列表中，则返回默认值0
        
        Args:
            lineweight: 要验证的线宽值
            
        Returns:
            有效的线宽值
        """
        if lineweight is None:
            return None
            
        # 检查线宽是否在有效值列表中
        if lineweight in self.valid_lineweights:
            return lineweight
        else:
            logger.warning(f"线宽值 {lineweight} 无效，将使用默认值 0")
            return 0
    
    def draw_line(self, start_point: Tuple[float, float, float], 
                 end_point: Tuple[float, float, float], layer: str = None, color: int = None, lineweight=None) -> bool:
        """绘制直线"""
        if not self.is_running():
            return False
            
        try:
            # 确保点是三维的
            if len(start_point) == 2:
                start_point = (start_point[0], start_point[1], 0)
            if len(end_point) == 2:
                end_point = (end_point[0], end_point[1], 0)
      
            # 使用VARIANT包装坐标点数据
            start_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                               [start_point[0], start_point[1], start_point[2]])
            end_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                             [end_point[0], end_point[1], end_point[2]])
            
            # 添加直线
            line = self.doc.ModelSpace.AddLine(start_array, end_array)
            
            # 如果指定了图层，设置图层
            if layer:
                # 确保图层存在
                self.create_layer(layer)
                # 设置实体的图层
                line.Layer = layer
         
            # 如果指定了颜色，设置颜色
            if color is not None:
                line.Color = color

            if lineweight is not None:
                line.LineWeight = self.validate_lineweight(lineweight)
            
            # 刷新视图
            self.refresh_view()

            logger.debug(f"已绘制直线: 起点{start_point}, 终点{end_point}, 图层{layer if layer else '默认'}, 颜色{color if color is not None else '默认'}")
            return line
            
        except Exception as e:
            logger.error(f"绘制直线时出错: {str(e)}")
            return None
    
    def draw_circle(self, center: Tuple[float, float, float], 
                   radius: float, layer: str = None, color: int = None, lineweight=None) -> Any:
        """绘制圆"""
        if not self.is_running():
            return None
            
        try:
            # 确保点是三维的
            if len(center) == 2:
                center = (center[0], center[1], 0)
            
            # 使用VARIANT包装坐标点数据
            center_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                               [center[0], center[1], center[2]])
            
            # 添加圆
            circle = self.doc.ModelSpace.AddCircle(center_array, radius)
            
            # 如果指定了图层，设置图层
            if layer:
                # 确保图层存在
                self.create_layer(layer)
                # 设置实体的图层
                circle.Layer = layer
            
            # 如果指定了颜色，设置颜色
            if color is not None:
                circle.Color = color

            if lineweight is not None:
                circle.LineWeight = self.validate_lineweight(lineweight)
            
            # 刷新视图
            self.refresh_view()
            
            logger.debug(f"已绘制圆: 中心{center}, 半径{radius}, 图层{layer if layer else '默认'}, 颜色{color if color is not None else '默认'}")
            return circle
            
        except Exception as e:
            logger.error(f"绘制圆时出错: {str(e)}")
            return None
    
    def draw_arc(self, center: Tuple[float, float, float], 
                radius: float, start_angle: float, end_angle: float, layer: str = None, color: int = None, lineweight=None) -> Any:
        """绘制圆弧"""
        if not self.is_running():
            return None
            
        try:
            # 确保点是三维的
            if len(center) == 2:
                center = (center[0], center[1], 0)
                
            # 将角度转换为弧度
            start_rad = math.radians(start_angle)
            end_rad = math.radians(end_angle)
            
            # 使用VARIANT包装坐标点数据
            center_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                               [center[0], center[1], center[2]])
            
            # 添加圆弧
            arc = self.doc.ModelSpace.AddArc(center_array, radius, start_rad, end_rad)
            
            # 如果指定了图层，设置图层
            if layer:
                # 确保图层存在
                self.create_layer(layer)
                # 设置实体的图层
                arc.Layer = layer
            
            # 如果指定了颜色，设置颜色
            if color is not None:
                arc.Color = color

            if lineweight is not None:
                arc.LineWeight = self.validate_lineweight(lineweight)
            
            # 刷新视图
            self.refresh_view()
            
            logger.debug(f"已绘制圆弧: 中心{center}, 半径{radius}, 起始角度{start_angle}, 结束角度{end_angle}, 图层{layer if layer else '默认'}, 颜色{color if color is not None else '默认'}")
            return arc
        except Exception as e:
            logger.error(f"绘制圆弧失败: {str(e)}")
            return None
 
    def draw_ellipse(self, center: Tuple[float, float, float], 
                    major_axis: float, minor_axis: float, rotation: float = 0, 
                    layer: str = None, color: int = None, lineweight=None) -> Any:
        """绘制椭圆"""
        if not self.is_running():
            return None
            
        try:
            # 确保点是三维的
            if len(center) == 2:
                center = (center[0], center[1], 0)
            
            if rotation is None:
                rotation = 0

            # 将旋转角度转换为弧度
            rotation_rad = math.radians(rotation)
            
            # 使用VARIANT包装坐标点数据
            center_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                               [center[0], center[1], center[2]])
            
            # 计算椭圆的主轴向量
            major_x = major_axis * math.cos(rotation_rad)
            major_y = major_axis * math.sin(rotation_rad)
            major_vector = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                               [major_x, major_y, 0])
            
            # 添加椭圆
            ellipse = self.doc.ModelSpace.AddEllipse(center_array, major_vector, minor_axis / major_axis)
            
            # 如果指定了图层，设置图层
            if layer:
                # 确保图层存在
                self.create_layer(layer)
                # 设置实体的图层
                ellipse.Layer = layer
            
            # 如果指定了颜色，设置颜色
            if color is not None:
                ellipse.Color = color

            if lineweight is not None:
                ellipse.LineWeight = self.validate_lineweight(lineweight)
            
            # 刷新视图
            self.refresh_view()
            
            logger.debug(f"已绘制椭圆: 中心{center}, 长轴{major_axis}, 短轴{minor_axis}, 旋转角度{rotation}, 图层{layer if layer else '默认'}, 颜色{color if color is not None else '默认'}")
            return ellipse
        except Exception as e:
            logger.error(f"绘制椭圆失败: {str(e)}")
            return None
    
    def draw_polyline(self, points: List[Tuple[float, float, float]], closed: bool = False, layer: str = None, color: int = None, lineweight=None) -> Any:
        """绘制多段线"""
        if not self.is_running():
            return None
            
        try:
            # 确保所有点都是三维的
            processed_points = []
            for point in points:
                if len(point) == 2:
                    processed_points.append((point[0], point[1], 0))
                else:
                    processed_points.append(point)
            
            # 创建点数组
            point_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                                [coord for point in processed_points for coord in point])
            
            # 添加多段线
            polyline = self.doc.ModelSpace.AddPolyline(point_array)
            
            # 如果需要闭合
            if closed and len(processed_points) > 2:
                polyline.Closed = True
            
            # 如果指定了图层，设置图层
            if layer:
                # 确保图层存在
                self.create_layer(layer)
                # 设置实体的图层
                polyline.Layer = layer
            
            # 如果指定了颜色，设置颜色
            if color is not None:
                polyline.Color = color

            if lineweight is not None:
                polyline.LineWeight = self.validate_lineweight(lineweight)
            
            # 刷新视图
            self.refresh_view()

            logger.debug(f"已绘制多段线: {len(points)}个点, {'闭合' if closed else '不闭合'}, 图层{layer if layer else '默认'}, 颜色{color if color is not None else '默认'}")
            return polyline
        except Exception as e:
            logger.error(f"绘制多段线时出错: {str(e)}")
            return None
    
    def draw_rectangle(self, corner1: Tuple[float, float, float], 
                      corner2: Tuple[float, float, float], layer: str = None, color: int = None, lineweight=None) -> Any:
        """绘制矩形"""
        if not self.is_running():
            return None
            
        try:
            # 确保点是三维的
            if len(corner1) == 2:
                corner1 = (corner1[0], corner1[1], 0)
            if len(corner2) == 2:
                corner2 = (corner2[0], corner2[1], 0)
                
            # 计算矩形的四个角点
            x1, y1, z1 = corner1
            x2, y2, z2 = corner2
            
            # 创建矩形的四个点
            points = [
                (x1, y1, z1),
                (x2, y1, z1),
                (x2, y2, z1),
                (x1, y2, z1),
                (x1, y1, z1)  # 闭合矩形
            ]
            
            # 使用多段线绘制矩形
            return self.draw_polyline(points, True, layer, color, lineweight)
        except Exception as e:
            logger.error(f"绘制矩形时出错: {str(e)}")
            return None
    
    def draw_text(self, position: Tuple[float, float, float], 
                 text: str, height: float = 2.5, rotation: float = 0, layer: str = None, color: int = None) -> Any:
        """添加文本"""
        if not self.is_running():
            return None
            
        try:
            # 确保点是三维的
            if len(position) == 2:
                position = (position[0], position[1], 0)
            
            # 使用VARIANT包装坐标点数据
            position_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                                 [position[0], position[1], position[2]])
                
            # 添加文本
            text_obj = self.doc.ModelSpace.AddText(text, position_array, height)
            
            # 设置旋转角度
            if rotation != 0:
                text_obj.Rotation = math.radians(rotation)
            
            # 如果指定了图层，设置图层
            if layer:
                # 确保图层存在
                self.create_layer(layer)
                # 设置实体的图层
                text_obj.Layer = layer
            
            # 如果指定了颜色，设置颜色
            if color is not None:
                text_obj.Color = color
            
            # 刷新视图
            self.refresh_view()
                                
            logger.debug(f"已添加文本: '{text}', 位置{position}, 高度{height}, 旋转{rotation}度, 图层{layer if layer else '默认'}, 颜色{color if color is not None else '默认'}")
            return text_obj
        except Exception as e:
            logger.error(f"添加文本时出错: {str(e)}")
            return None
    
    def draw_hatch(self, points: List[Tuple[float, float, float]], 
                  pattern_name: str = "SOLID", scale: float = 1.0, layer: str = None, color: int = None) -> Any:
        """绘制填充图案
        
        Args:
            points: 填充边界的点集，每个点为二维或三维坐标元组
            pattern_name: 填充图案名称，默认为"SOLID"(实体填充)
            scale: 填充图案比例，默认为1.0
            layer: 图层名称，如果为None则使用当前图层
            color: 颜色索引，如果为None则使用默认颜色
            
        Returns:
            成功返回填充对象，失败返回None
        """
        if not self.is_running():
            return None
            
        try:
            # 确保所有点都是有效的
            if not points or len(points) < 3:
                logger.error("创建填充失败: 至少需要3个点来定义填充边界")
                return None
                
            # 创建闭合多段线作为边界
            closed_polyline = self.draw_polyline(points, closed=True, layer=layer)
            if not closed_polyline:
                logger.error("创建填充失败: 无法创建边界多段线")
                return None
                
            # 创建填充对象 (0表示正常填充，True表示关联边界)
            hatch = self.doc.ModelSpace.AddHatch(0, pattern_name, True)
                
            # 添加外部边界循环
            # 使用VARIANT包装对象数组
            object_ids = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_DISPATCH, [closed_polyline])
            hatch.AppendOuterLoop(object_ids)
                
            # 设置填充图案比例
            hatch.PatternScale = scale
                
            # 如果指定了图层，设置图层
            if layer:
                # 确保图层存在
                self.create_layer(layer)
                # 设置实体的图层
                hatch.Layer = layer
                
            # 如果指定了颜色，设置颜色
            if color is not None:
                hatch.Color = color
                                
            # 更新填充 (计算填充区域)
            hatch.Evaluate()
            
            # 刷新视图
            self.refresh_view()
                
            logger.debug(f"已创建填充: 图案 {pattern_name}, 比例 {scale}, 图层{layer if layer else '默认'}, 颜色{color if color is not None else '默认'}")
            return hatch
        except Exception as e:
            logger.error(f"创建填充时出错: {str(e)}")
            return None
    
    def zoom_extents(self) -> bool:
        """缩放视图以显示所有对象"""
        if not self.is_running():
            return False
            
        try:
            self.doc.ActiveViewport.ZoomExtents()
            logger.info("已缩放视图以显示所有对象")
            return True
        except Exception as e:
            logger.error(f"缩放视图时出错: {str(e)}")
            return False
    
    def close(self) -> None:
        """关闭CAD控制器"""
        try:
            # 释放COM资源
            if self.app is not None:
                del self.app
            pythoncom.CoUninitialize()
        except:
            pass

    
    def create_layer(self, layer_name: str) -> bool:    # , color: Union[int, Tuple[int, int, int]] = 7
        """创建新图层
        
        Args:
            layer_name: 图层名称
            color: 颜色值，可以是CAD颜色索引(int)或RGB颜色值(tuple)
            
        Returns:
            操作是否成功
        """
        if not self.is_running():
            return False
        
        try:
            # 检查图层是否已存在
            for i in range(self.doc.Layers.Count):
                if self.doc.Layers.Item(i).Name == layer_name:
                    # 图层已存在，激活它
                    self.doc.ActiveLayer = self.doc.Layers.Item(i)
                    return True
                
            # 创建新图层
            new_layer = self.doc.Layers.Add(layer_name)
            
            # 图层不设置颜色，设置里面的实体颜色
            # # 设置颜色
            # if isinstance(color, int):
            #     # 使用颜色索引
            #     new_layer.Color = color
            # elif isinstance(color, tuple) and len(color) == 3:
            #     # 使用RGB值
            #     r, g, b = color
            #     # 设置TrueColor
            #     new_layer.TrueColor = self._create_true_color(r, g, b)
            
            # 设置为当前图层
            self.doc.ActiveLayer = new_layer
            logger.info(f"已创建新图层: {layer_name}")  #, 颜色: {color}
            return True
        except Exception as e:
            logger.error(f"创建图层时出错: {str(e)}")
            return False

    def add_dimension(self, start_point: Tuple[float, float, float], 
                     end_point: Tuple[float, float, float],
                     text_position: Tuple[float, float, float] = None, textheight: float = 5,layer: str = None, color: int=None) -> Any:
            """添加线性标注"""
            if not self.is_running():
                return None
            
            try:
                # 确保点是三维的
                if len(start_point) == 2:
                    start_point = (start_point[0], start_point[1], 0)
                if len(end_point) == 2:
                    end_point = (end_point[0], end_point[1], 0)
                
                # 如果未提供文本位置，自动计算
                if text_position is None:
                    # 在起点和终点之间的中点上方
                    mid_x = (start_point[0] + end_point[0]) / 2
                    mid_y = (start_point[1] + end_point[1]) / 2
                    text_position = (mid_x, mid_y + 5, 0)
                elif len(text_position) == 2:
                    text_position = (text_position[0], text_position[1], 0)
                
                # 使用VARIANT包装坐标点数据
                start_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                                 [start_point[0], start_point[1], start_point[2]])
                end_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                               [end_point[0], end_point[1], end_point[2]])
                text_pos_array = win32com.client.VARIANT(pythoncom.VT_ARRAY | pythoncom.VT_R8, 
                                                     [text_position[0], text_position[1], text_position[2]])
                
                # 添加对齐标注
                dimension = self.doc.ModelSpace.AddDimAligned(start_array, end_array, text_pos_array)
                
                # 设置文字高度
                if textheight is not None:
                    dimension.TextHeight = textheight
                
                # 如果指定了图层，设置图层
                if layer:
                    # 确保图层存在
                    self.create_layer(layer)
                    # 设置实体的图层
                    dimension.Layer = layer

                # 如果指定了颜色，设置颜色
                if color is not None:
                    dimension.Color = color
                
                # 刷新视图
                self.refresh_view()

                logger.info(f"已添加标注: 从 {start_point} 到 {end_point}, 图层{layer if layer else '默认'}")
                return dimension
            except Exception as e:
                logger.error(f"添加标注时出错: {str(e)}")
                return None

    # ==================== API Layer 调用方法 ====================
    # 用于调用 cad-cowork-cstool 的参数化 API 命令

    def _get_api_base_dir(self) -> str:
        """获取 API Layer 的基础目录"""
        return os.path.join(tempfile.gettempdir(), "CAD-Cowork")

    def _get_api_request_path(self, request_id: str = None) -> str:
        """获取 API 请求文件路径

        Args:
            request_id: 请求 ID，用于隔离并发请求。None 则使用共享路径（兼容旧版 cstool）
        """
        if request_id:
            return os.path.join(self._get_api_base_dir(), "requests", request_id, "request.json")
        return os.path.join(self._get_api_base_dir(), "request.json")

    def _get_api_result_path(self, request_id: str = None) -> str:
        """获取 API 结果文件路径

        Args:
            request_id: 请求 ID，用于隔离并发请求。None 则使用共享路径（兼容旧版 cstool）
        """
        if request_id:
            return os.path.join(self._get_api_base_dir(), "requests", request_id, "result.json")
        return os.path.join(self._get_api_base_dir(), "results", "latest.json")

    def _ensure_api_dirs(self, request_id: str = None) -> None:
        """确保 API 目录存在

        Args:
            request_id: 请求 ID，会创建独立的请求目录
        """
        base_dir = self._get_api_base_dir()
        results_dir = os.path.join(base_dir, "results")
        os.makedirs(results_dir, exist_ok=True)
        if request_id:
            request_dir = os.path.join(base_dir, "requests", request_id)
            os.makedirs(request_dir, exist_ok=True)

    def _cleanup_request_dir(self, request_id: str) -> None:
        """清理请求隔离目录（最大努力，不报错）"""
        try:
            request_dir = os.path.join(self._get_api_base_dir(), "requests", request_id)
            if os.path.exists(request_dir):
                import shutil
                shutil.rmtree(request_dir, ignore_errors=True)
        except Exception:
            pass

    def _normalize_result(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """统一 API 结果字段的大小写（C# 使用 PascalCase，Python 习惯 camelCase）"""
        field_mapping = {
            "Success": "success",
            "ErrorCode": "errorCode",
            "Message": "message",
            "Data": "data",
            "RequestId": "requestId",
            "CommandName": "commandName",
            "ExecutionTimeMs": "executionTimeMs",
            "Timestamp": "timestamp",
            "CreatedEntityHandles": "createdEntityHandles",
            "ModifiedEntityHandles": "modifiedEntityHandles"
        }

        normalized = {}
        for key, value in result.items():
            # 如果是 PascalCase 键，转换为 camelCase
            new_key = field_mapping.get(key, key)
            normalized[new_key] = value

        return normalized

    def execute_api_command(self, command_name: str, parameters: Dict[str, Any] = None,
                           timeout: float = 10.0) -> Dict[str, Any]:
        """执行 cad-cowork-cstool API 命令（快速失败，不自动重试）

        采用快速失败策略：超时直接返回错误，由 Agent 层决定是否重试。

        Args:
            command_name: API 命令名称，如 "api_draw_line", "api_draw_circle"
            parameters: 命令参数字典
            timeout: 等待结果的超时时间（秒），默认 10 秒

        Returns:
            dict: API 执行结果，包含 success, message, data 等字段
        """
        # 快速失败：不自动重试，超时直接返回
        return self._execute_api_command_once(command_name, parameters, timeout)

    def _execute_api_command_once(self, command_name: str, parameters: Dict[str, Any] = None,
                                  timeout: float = 10.0, _is_retry: bool = False) -> Dict[str, Any]:
        """执行单次 API 命令（内部方法）

        通过写入 request.json，调用 DLApiExecute 命令，然后读取结果文件

        Args:
            command_name: API 命令名称
            parameters: 命令参数字典
            timeout: 等待结果的超时时间（秒）
            _is_retry: 内部标记，True 表示这是重连后的重试调用，防止无限递归

        Returns:
            dict: API 执行结果
        """
        # 确保有效连接（处理图纸切换等情况）
        if not self._ensure_valid_connection():
            return {
                "success": False,
                "errorCode": -9,
                "message": "CAD连接已断开，自动重连失败。请确保CAD已启动并有打开的图纸。",
                "hint": "如果问题持续，请重启 MCP 服务"
            }

        import uuid
        request_id = uuid.uuid4().hex[:8]

        try:
            self._ensure_api_dirs(request_id)

            # 构建请求对象
            request = {
                "commandName": command_name,
                "requestId": request_id,
                "silentMode": True,
                "timeoutMs": int(timeout * 1000),
                "parameters": parameters or {}
            }

            # 写入请求文件（使用共享路径 — cstool 从固定位置读取请求）
            # 同时写入隔离目录（用于结果匹配，避免并发竞态）
            request_path = self._get_api_request_path()
            with open(request_path, 'w', encoding='utf-8') as f:
                json.dump(request, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())

            logger.info(f"[API] 写入请求: {command_name}, RequestId: {request_id}")

            # 等待文件系统同步（Windows 文件系统缓存问题）
            time.sleep(0.03)

            # 调用 DLApiExecute 命令
            self.doc.SendCommand("DLApiExecute\n")

            # 等待结果文件 — 指数退避轮询
            # CsTool 同时写 results/{requestId}.json 和 results/latest.json
            # 优先读 per-request 文件（无竞态），fallback 到 latest.json（兼容旧版 cstool）
            start_time = time.time()
            result_path_per_request = os.path.join(
                self._get_api_base_dir(), "results", f"{request_id}.json"
            )
            result_path_latest = self._get_api_result_path()
            poll_interval = 0.02  # 起始 20ms
            last_error = None

            while time.time() - start_time < timeout:
                time.sleep(poll_interval)

                # 指数退避：20ms → 40ms → 80ms → 160ms → 200ms（上限）
                poll_interval = min(poll_interval * 2, 0.2)

                if time.time() - start_time >= timeout:
                    break

                # 优先检查 per-request 文件（CsTool 写的隔离结果）
                result_path = result_path_per_request if os.path.exists(result_path_per_request) else result_path_latest

                if os.path.exists(result_path):
                    try:
                        with open(result_path, 'r', encoding='utf-8-sig') as f:
                            result = json.load(f)

                        result_request_id = result.get("requestId") or result.get("RequestId")
                        if result_request_id == request_id:
                            elapsed = time.time() - start_time
                            logger.info(f"[API] 命令执行完成: {command_name}, 耗时: {elapsed:.2f}秒, 来源: {'per-request' if result_path == result_path_per_request else 'latest'}")
                            return self._normalize_result(result)
                    except json.JSONDecodeError as e:
                        last_error = f"JSON解析错误: {e}"
                        continue
                    except Exception as e:
                        last_error = str(e)
                        continue

            # 超时
            error_detail = f", 最后错误: {last_error}" if last_error else ""
            return {
                "success": False,
                "errorCode": -6,
                "message": f"API 命令执行超时 ({timeout}秒){error_detail}",
                "requestId": request_id,
                "commandName": command_name,
                "hint": "请检查: 1) cad-cowork-cstool 是否已加载 2) CAD 命令行是否有错误信息"
            }

        except Exception as e:
            error_str = str(e)
            error_code = -1

            # 检测 COM 连接断开错误
            if "-2147417848" in error_str or "RPC_E_DISCONNECTED" in error_str.upper() or "断开连接" in error_str:
                error_code = -9
                logger.warning(f"[API] 检测到 COM 连接断开: {error_str}")

                # 尝试重连并重试（仅在非重试调用时）
                if not _is_retry and self._try_reconnect():
                    logger.info("[API] 重连成功，正在重试命令...")
                    return self._execute_api_command_once(command_name, parameters, timeout, _is_retry=True)
                else:
                    return {
                        "success": False,
                        "errorCode": error_code,
                        "message": f"CAD 连接已断开且自动重连失败: {error_str}",
                        "commandName": command_name,
                        "executionMethod": "api_layer",
                        "hint": "请检查 CAD 是否仍在运行，或重启 MCP 服务"
                    }

            error_msg = f"执行 API 命令失败: {error_str}"
            logger.error(f"[API] {error_msg}")
            return {
                "success": False,
                "errorCode": error_code,
                "message": error_msg,
                "commandName": command_name,
                "executionMethod": "api_layer"
            }

    def get_api_commands_metadata(self) -> Dict[str, Any]:
        """获取所有可用的 API 命令元数据

        调用 DLApiExportMeta 命令导出命令列表，然后读取结果文件

        Returns:
            dict: 包含命令元数据列表
        """
        if not self._ensure_valid_connection():
            return {"success": False, "message": "CAD未运行或连接已断开", "commands": []}

        try:
            self._ensure_api_dirs()

            # 调用导出命令
            self.doc.SendCommand("DLApiExportMeta\n")

            # 等待文件生成
            time.sleep(0.5)

            # 读取元数据文件
            meta_path = os.path.join(self._get_api_base_dir(), "api_commands_metadata.json")

            if os.path.exists(meta_path):
                with open(meta_path, 'r', encoding='utf-8-sig') as f:
                    commands = json.load(f)
                return {
                    "success": True,
                    "commands": commands,
                    "count": len(commands) if isinstance(commands, list) else 0
                }
            else:
                return {
                    "success": False,
                    "message": "元数据文件未生成，请确保 cad-cowork-cstool 已加载",
                    "commands": []
                }

        except Exception as e:
            error_msg = f"获取 API 命令元数据失败: {str(e)}"
            logger.error(f"[API] {error_msg}")
            return {"success": False, "message": error_msg, "commands": []}

    def get_api_command_info(self, command_name: str) -> Dict[str, Any]:
        """获取指定 API 命令的详细信息

        Args:
            command_name: 命令名称

        Returns:
            dict: 命令详细信息
        """
        if not self._ensure_valid_connection():
            return {"success": False, "message": "CAD未运行或连接已断开"}

        try:
            self._ensure_api_dirs()

            # 需要通过交互式命令获取，这里简化处理
            # 先获取所有命令，然后筛选
            all_commands = self.get_api_commands_metadata()

            if not all_commands.get("success"):
                return all_commands

            for cmd in all_commands.get("commands", []):
                if cmd.get("name", "").lower() == command_name.lower():
                    return {"success": True, "command": cmd}

            return {
                "success": False,
                "message": f"未找到命令: {command_name}"
            }

        except Exception as e:
            error_msg = f"获取命令信息失败: {str(e)}"
            logger.error(f"[API] {error_msg}")
            return {"success": False, "message": error_msg}

    # ==================== 智能 CAD 命令 ====================
    # 自动判断使用 SendCommand 还是 API Layer

    def smart_cad_command(self, command_name: str, parameters: Dict[str, Any] = None,
                          need_result: bool = None, timeout: float = 10.0) -> Dict[str, Any]:
        """智能执行 CAD 命令

        自动判断使用 SendCommand（简单命令）或 API Layer（复杂命令）：
        1. need_result=True 显式指定 → API Layer
        2. need_result=False 显式指定 → SendCommand
        3. need_result=None 自动推断：
           - 命令以 api_ 开头 → API Layer
           - 参数包含复杂对象（列表/字典）→ API Layer
           - 命令在 FSD_CAD_COMMANDS 中 → SendCommand
           - 其他情况 → 尝试 API Layer

        Args:
            command_name: 命令名称（可以是 cstool 命令或 API 命令）
            parameters: 命令参数字典（可选）
            need_result: 是否需要返回结果（如实体 Handle）。None 表示自动判断
            timeout: 超时时间（秒），默认 10 秒

        Returns:
            dict: 执行结果，包含 success, message, data 等字段
        """
        if not self.is_running():
            started = self.start_cad()
            if not started:
                return {"success": False, "errorCode": -8, "message": "CAD 未运行且无法启动"}

        # 判断使用哪种执行方式
        use_api = self._should_use_api(command_name, parameters, need_result)
        method_name = "API Layer" if use_api else "SendCommand"
        logger.info(f"[智能路由] 命令 '{command_name}' 使用 {method_name} 执行")

        if use_api:
            # 使用 API Layer（带结构化返回）
            result = self.execute_api_command(command_name, parameters or {}, timeout)
            result["executionMethod"] = "api_layer"
            return result
        else:
            # 使用 SendCommand（快速执行）
            params_str = self._build_sendcommand_params(parameters)
            result = self.send_command(f"{command_name} {params_str}".strip() if params_str else command_name)
            result["executionMethod"] = "sendcommand"
            return result

    def _should_use_api(self, command_name: str, parameters: Dict[str, Any],
                        need_result: bool) -> bool:
        """判断是否使用 API Layer

        Args:
            command_name: 命令名称
            parameters: 命令参数
            need_result: 用户显式指定是否需要返回值

        Returns:
            bool: True 使用 API Layer，False 使用 SendCommand
        """
        # 1. 显式指定
        if need_result is True:
            logger.debug(f"[智能路由] need_result=True，使用 API Layer")
            return True
        if need_result is False:
            logger.debug(f"[智能路由] need_result=False，使用 SendCommand")
            return False

        # 2. 自动推断
        # 2.1 命令名以 api_ 开头
        if command_name.lower().startswith("api_"):
            logger.debug(f"[智能路由] 命令名以 api_ 开头，使用 API Layer")
            return True

        # 2.2 参数包含复杂对象（列表、嵌套字典）
        if parameters:
            for key, value in parameters.items():
                if isinstance(value, (list, tuple)):
                    logger.debug(f"[智能路由] 参数 '{key}' 包含列表/元组，使用 API Layer")
                    return True
                if isinstance(value, dict):
                    logger.debug(f"[智能路由] 参数 '{key}' 包含字典，使用 API Layer")
                    return True

        # 2.3 默认使用 API Layer（更安全，有返回值）
        logger.debug(f"[智能路由] 默认使用 API Layer")
        return True

    def _build_sendcommand_params(self, parameters: Dict[str, Any]) -> str:
        """将字典参数转换为 SendCommand 字符串格式

        Args:
            parameters: 参数字典

        Returns:
            str: 空格分隔的参数字符串
        """
        if not parameters:
            return ""

        # 简单参数转为空格分隔的字符串
        # 注意：只适用于简单值，复杂值应该使用 API Layer
        parts = []
        for value in parameters.values():
            if value is not None and not isinstance(value, (list, dict, tuple)):
                parts.append(str(value))
        return " ".join(parts)
