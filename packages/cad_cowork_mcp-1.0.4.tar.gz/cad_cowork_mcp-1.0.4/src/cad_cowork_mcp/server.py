import os
import sys
import json
import logging
from pathlib import Path
from mcp.server.models import InitializationOptions
import mcp.types as types
from mcp.server import NotificationOptions, Server
import mcp.server.stdio
from pydantic import AnyUrl
from typing import Any, Dict, List
import sys

sys.dont_write_bytecode = True

from .cad_controller import CADController
from .batch_executor import BatchExecutor
from .metrics import CommandMetrics, SessionMetrics


# 配置Windows环境下的UTF-8编码
# 注意: pytest 会替换 sys.stdin，所以需要检查 reconfigure 方法是否存在
if sys.platform == "win32" and os.environ.get('PYTHONIOENCODING') is None:
    if hasattr(sys.stdin, 'reconfigure'):
        sys.stdin.reconfigure(encoding="utf-8")
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding="utf-8")
    if hasattr(sys.stderr, 'reconfigure'):
        sys.stderr.reconfigure(encoding="utf-8")

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('cad_mcp.log', encoding='utf-8')
    ]
)


logger = logging.getLogger('mcp_cad_server')
logger.info("启动 CAD MCP 服务器")


def load_prompt_template(cad_name: str = "CAD", drawing_state: str = "(no CAD activity yet)") -> str:
    """加载提示词模板文件，替换静态和动态占位符

    Args:
        cad_name: CAD 软件名称，用于替换 {{CAD_NAME}} 占位符
        drawing_state: 动态图纸状态字符串，用于替换 {{DRAWING_STATE}} 占位符

    Returns:
        str: 处理后的提示词内容
    """
    template_path = os.path.join(os.path.dirname(__file__), 'prompts', 'cad_system_prompt.md')
    try:
        with open(template_path, 'r', encoding='utf-8') as f:
            content = f.read()
        content = content.replace('{{CAD_NAME}}', cad_name)
        content = content.replace('{{DRAWING_STATE}}', drawing_state)
        logger.info(f"提示词模板已加载: {template_path}")
        return content
    except Exception as e:
        logger.warning(f"加载提示词模板失败: {e}，使用默认提示词")
        return f"""你是一个 CAD 绘图助手，可以通过自然语言控制 {cad_name} 进行绘图操作。
请使用 smart_cad_command 工具执行 API 命令。"""


# 静态模板（启动时加载一次，动态部分在请求时替换）
PROMPT_TEMPLATE_RAW = None
def _load_raw_template():
    global PROMPT_TEMPLATE_RAW
    template_path = os.path.join(os.path.dirname(__file__), 'prompts', 'cad_system_prompt.md')
    try:
        with open(template_path, 'r', encoding='utf-8') as f:
            PROMPT_TEMPLATE_RAW = f.read()
    except Exception as e:
        logger.warning(f"加载提示词模板失败: {e}")
        PROMPT_TEMPLATE_RAW = "你是一个 CAD 绘图助手。请使用 smart_cad_command 工具执行 API 命令。"

_load_raw_template()

# 兼容导出：测试和外部代码可能引用 PROMPT_TEMPLATE
PROMPT_TEMPLATE = load_prompt_template("CAD")


def load_api_commands_manifest():
    """加载 API 命令清单文件"""
    manifest_path = os.path.join(os.path.dirname(__file__), 'api_commands_manifest.json')
    try:
        # 使用 utf-8-sig 自动处理 BOM（Byte Order Mark）
        with open(manifest_path, 'r', encoding='utf-8-sig') as f:
            return json.load(f)
    except Exception as e:
        logger.warning(f"加载 API 命令清单失败: {e}")
        return None

# 全局加载 API 命令清单
API_COMMANDS_MANIFEST = load_api_commands_manifest()
if API_COMMANDS_MANIFEST:
    logger.info(f"API 命令清单已加载，共 {API_COMMANDS_MANIFEST.get('totalCommands', 0)} 个命令")


class Config:

    def __init__(self):
        # 直接读取config.json文件
        config_path = os.path.join(os.path.dirname(__file__), 'config.json')
        with open(config_path, 'r', encoding='utf-8') as f:
            self.config = json.load(f)
        logger.info("配置文件加载成功")

    @property
    def server_name(self) -> str:
        return self.config['server']['name']

    @property
    def server_version(self) -> str:
        return self.config['server']['version']

class DrawingState:
    """轻量级图纸状态快照，随命令执行后更新

    作为动态上下文注入 system prompt，减少 LLM 不必要的查询调用。
    """

    def __init__(self):
        self.active_document: str | None = None
        self.layer_count: int = 0
        self.recent_handles: list[str] = []  # 最近 20 个 handle
        self.last_command: str = ""
        self.last_error: str | None = None
        self.command_count: int = 0

    def update_from_result(self, command_name: str, result: dict) -> None:
        """从命令执行结果更新状态"""
        self.last_command = command_name
        self.command_count += 1

        if not result.get("success"):
            self.last_error = result.get("message", "unknown error")
            return

        self.last_error = None

        # 收集 created + modified handles（CsTool 两个字段都会返回）
        new_handles = []
        new_handles.extend(result.get("createdEntityHandles", []))
        new_handles.extend(result.get("modifiedEntityHandles", []))

        # 从 data 中提取单个 handle
        data = result.get("data", {})
        if isinstance(data, dict) and data.get("entityHandle"):
            handle = data["entityHandle"]
            if handle not in new_handles:
                new_handles.append(handle)

        if new_handles:
            # 去重后合并到 recent_handles（新的在前）
            seen = set(self.recent_handles)
            merged = [h for h in new_handles if h not in seen]
            self.recent_handles = (merged + self.recent_handles)[:20]

    def update_document_info(self, controller) -> None:
        """从 CAD 控制器更新文档信息（轻量，异常安全）"""
        try:
            if controller.doc:
                self.active_document = controller.doc.Name
        except Exception:
            pass

    def to_context_string(self) -> str:
        """生成用于注入 system prompt 的动态上下文字符串"""
        parts = []
        if self.active_document:
            parts.append(f"Active document: {self.active_document}")
        if self.recent_handles:
            parts.append(f"Recent handles ({len(self.recent_handles)}): {', '.join(self.recent_handles[:10])}")
        if self.last_command:
            status = "✓" if not self.last_error else f"✗ {self.last_error}"
            parts.append(f"Last command: {self.last_command} [{status}]")
        parts.append(f"Commands executed this session: {self.command_count}")
        return "\n".join(parts) if parts else "(no CAD activity yet)"


class CADService:
    def __init__(self):
        """初始化CAD服务"""
        self.controller = CADController()
        self.drawing_state = DrawingState()
        self.session_metrics = SessionMetrics()
        logger.info("CAD服务已初始化")

    def start_cad(self):
        """启动CAD"""
        result = self.controller.start_cad()
        if result:
            self.drawing_state.update_document_info(self.controller)
        return result

def _query_api_commands(cad_service: CADService, command_name: str = None, category: str = None) -> dict:
    """统一的命令查询逻辑（合并原 list_api_commands + get_api_command_info）

    Args:
        cad_service: CAD 服务实例
        command_name: 查询指定命令的详细信息
        category: 按分类过滤命令列表

    Returns:
        dict: 查询结果
    """
    if not API_COMMANDS_MANIFEST:
        return {"success": False, "error": "本地 API 命令清单不可用"}

    # 模式 1：查询单个命令的详细信息
    if command_name:
        for cat in API_COMMANDS_MANIFEST.get("categories", []):
            for cmd in cat.get("commands", []):
                if cmd.get("name") == command_name:
                    return {
                        "success": True,
                        "source": "local_manifest",
                        "command": cmd,
                        "category": cat.get("name")
                    }
        return {"success": False, "error": f"未找到命令: {command_name}"}

    # 模式 2：按分类过滤
    if category:
        for cat in API_COMMANDS_MANIFEST.get("categories", []):
            if cat.get("nameEn", "").lower() == category.lower() or cat.get("name", "") == category:
                return {
                    "success": True,
                    "source": "local_manifest",
                    "category": cat.get("name"),
                    "count": cat.get("count", len(cat.get("commands", []))),
                    "commands": [
                        {"name": cmd["name"], "displayName": cmd.get("displayName", ""), "description": cmd.get("description", "")}
                        for cmd in cat.get("commands", [])
                    ]
                }
        return {"success": False, "error": f"未找到分类: {category}"}

    # 模式 3：返回全量命令概览（精简格式，避免 token 爆炸）
    categories_summary = []
    for cat in API_COMMANDS_MANIFEST.get("categories", []):
        categories_summary.append({
            "name": cat.get("name"),
            "nameEn": cat.get("nameEn"),
            "count": cat.get("count", len(cat.get("commands", []))),
            "commands": [cmd["name"] for cmd in cat.get("commands", [])]
        })
    return {
        "success": True,
        "source": "local_manifest",
        "totalCommands": API_COMMANDS_MANIFEST.get("totalCommands", 0),
        "categories": categories_summary
    }


def _format_param_hint(p: dict) -> str:
    """格式化单个参数的提示信息，包含别名"""
    name = p.get("name", "?")
    ptype = p.get("type", "?")
    aliases = p.get("aliases", [])
    if aliases:
        return f"{name}({ptype}, alias: {'/'.join(aliases)})"
    return f"{name}({ptype})"


def _get_command_fix_hint(command_name: str) -> dict | None:
    """从本地 manifest 获取命令的参数格式提示，用于错误恢复

    Args:
        command_name: API 命令名称

    Returns:
        dict | None: 包含 required_params, optional_params, example 的提示信息
    """
    if not API_COMMANDS_MANIFEST:
        return None

    for cat in API_COMMANDS_MANIFEST.get("categories", []):
        for cmd in cat.get("commands", []):
            if cmd.get("name") == command_name:
                params = cmd.get("parameters", [])
                required = [_format_param_hint(p) for p in params if p.get("required")]
                optional = [_format_param_hint(p) for p in params if not p.get("required")]
                hint = {
                    "required_params": ", ".join(required) if required else "(none)",
                    "optional_params": ", ".join(optional) if optional else "(none)",
                }
                example = cmd.get("usageExample")
                if example:
                    hint["example"] = example
                return hint
    return None


async def main():
    """主入口函数"""
    logger.info("启动 CAD MCP 服务器")

    # 加载配置
    config = Config()
    cad_service = CADService()
    server = Server(config.server_name)

    # 注册处理程序
    logger.debug("注册处理程序")

    @server.list_resources()
    async def handle_list_resources() -> list[types.Resource]:
        logger.debug("处理 list_resources 请求")
        return [
            types.Resource(
                uri=AnyUrl("drawing://current"),
                name="当前CAD图纸",
                description="当前CAD图纸的状态",
                mimeType="application/json",
            )
        ]

    @server.read_resource()
    async def handle_read_resource(uri: AnyUrl) -> str:
        logger.debug(f"处理 read_resource 请求，URI: {uri}")
        if uri.scheme != "drawing":
            logger.error(f"不支持的 URI 协议: {uri.scheme}")
            raise ValueError(f"不支持的 URI 协议: {uri.scheme}")

        path = str(uri).replace("drawing://", "")
        if not path or path != "current":
            logger.error(f"未知的资源路径: {path}")
            raise ValueError(f"未知的资源路径: {path}")

        # 刷新文档信息后返回
        cad_service.drawing_state.update_document_info(cad_service.controller)
        state = {
            "active_document": cad_service.drawing_state.active_document,
            "recent_handles": cad_service.drawing_state.recent_handles,
            "last_command": cad_service.drawing_state.last_command,
            "last_error": cad_service.drawing_state.last_error,
            "command_count": cad_service.drawing_state.command_count,
        }
        return json.dumps(state, ensure_ascii=False)


    @server.list_tools()
    async def handle_list_tools() -> list[types.Tool]:
        """列出可用工具"""
        return [
            # ===== 核心执行工具 =====
            types.Tool(
                name="smart_cad_command",
                description=(
                    "Execute a single CAD command. This is the PRIMARY tool for ALL CAD operations.\n\n"
                    "WHEN TO USE:\n"
                    "- Any single CAD operation: draw, query, modify, block, layer, view, selection, spatial calc, etc.\n"
                    "- For GsLc domain commands (api_gslc_*): call gslc_route_command FIRST to get the correct command name, then use this tool.\n\n"
                    "WHEN NOT TO USE:\n"
                    "- Multiple dependent commands in sequence → use batch_execute instead.\n"
                    "- To look up available commands or parameter formats → use query_api_commands instead.\n\n"
                    "PARAMETER FORMAT:\n"
                    "- command_name: exact api_* name (e.g. 'api_draw_circle', 'api_move_entity')\n"
                    "- parameters: JSON object with camelCase keys\n"
                    "- Points are [x, y, z] arrays (z defaults to 0 if omitted)\n"
                    "- Entity handles are hex strings from previous command results (e.g. '27E2C0')\n\n"
                    "RETURNS: {success, data, createdEntityHandles[], executionMethod}\n"
                    "- Save createdEntityHandles for subsequent move/modify/delete operations.\n\n"
                    "COMMON MISTAKES:\n"
                    "- Using api_gslc_* commands directly without gslc_route_command → may pick wrong command due to similar names.\n"
                    "- Passing snake_case parameter names → must be camelCase (e.g. startPoint, not start_point).\n"
                    "- Omitting required parameters → check with query_api_commands first if unsure."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "command_name": {
                            "type": "string",
                            "description": "API command name (e.g. 'api_draw_circle', 'api_move_entity', 'api_query_by_layer')"
                        },
                        "parameters": {
                            "type": "object",
                            "description": "Command parameters as JSON object with camelCase keys. Example: {\"center\": [100,100,0], \"radius\": 50}"
                        },
                        "need_result": {
                            "type": "boolean",
                            "description": "Force execution method: true=API Layer (structured return), false=SendCommand (fast, no return data), omit=auto-detect"
                        },
                        "timeout": {
                            "type": "number",
                            "description": "Timeout in seconds (default: 10)"
                        }
                    },
                    "required": ["command_name"],
                },
            ),

            # ===== 批量执行工具 =====
            types.Tool(
                name="batch_execute",
                description=(
                    "Execute multiple CAD commands in a single call with DAG dependency management.\n\n"
                    "WHEN TO USE:\n"
                    "- Drawing multiple entities that depend on each other (e.g. draw line → move it → copy it).\n"
                    "- Any workflow requiring 2+ sequential commands where later commands reference earlier results.\n\n"
                    "WHEN NOT TO USE:\n"
                    "- Single command → use smart_cad_command instead (simpler, less overhead).\n"
                    "- Independent commands with no dependencies → multiple smart_cad_command calls may be clearer.\n\n"
                    "DEPENDENCY & REFERENCE SYNTAX:\n"
                    "- depends_on: [\"cmd_id\"] → ensures cmd_id completes before this command runs.\n"
                    "- ${cmd_id.handle} → resolves to the first created entity handle from cmd_id.\n"
                    "- ${cmd_id.data.fieldName} → resolves to a nested field in cmd_id's result data.\n"
                    "- ${cmd_id.createdEntityHandles[0]} → resolves to a specific array element.\n\n"
                    "OPTIONS:\n"
                    "- dry_run: true → validate all parameters and dependencies WITHOUT executing. Returns execution plan.\n"
                    "- use_transaction: true → wrap all commands in a transaction; auto-rollback on any failure. WARNING: transactions expire after 30 minutes.\n"
                    "- detail_level: 'summary' (stats only) | 'handles' (stats + handle map, default) | 'full' (all data).\n\n"
                    "RETURNS: {success, summary: {total, successful, failed, total_time_ms}, handle_map, failed_commands[]}\n\n"
                    "EXAMPLE:\n"
                    "commands: [\n"
                    "  {id: 'c1', command_name: 'api_draw_circle', parameters: {center: [0,0,0], radius: 50}},\n"
                    "  {id: 'c2', command_name: 'api_move_entity', parameters: {entityHandle: '${c1.handle}', fromPoint: [0,0,0], toPoint: [100,0,0]}, depends_on: ['c1']}\n"
                    "]"
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "commands": {
                            "type": "array",
                            "description": "Command list with DAG dependencies",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "id": {
                                        "type": "string",
                                        "description": "Unique command ID for dependency references"
                                    },
                                    "command_name": {
                                        "type": "string",
                                        "description": "API command name (e.g. 'api_draw_circle')"
                                    },
                                    "parameters": {
                                        "type": "object",
                                        "description": "Command parameters. Use ${cmd_id.field} to reference previous results."
                                    },
                                    "depends_on": {
                                        "type": "array",
                                        "description": "IDs of commands that must complete before this one",
                                        "items": {"type": "string"}
                                    }
                                },
                                "required": ["id", "command_name"]
                            }
                        },
                        "stop_on_error": {
                            "type": "boolean",
                            "description": "Stop all remaining commands on first failure (default: true)"
                        },
                        "timeout_per_command": {
                            "type": "number",
                            "description": "Timeout per command in seconds (default: 10)"
                        },
                        "detail_level": {
                            "type": "string",
                            "description": "Result verbosity: 'summary', 'handles' (default), 'full'",
                            "enum": ["summary", "handles", "full"],
                            "default": "handles"
                        },
                        "use_transaction": {
                            "type": "boolean",
                            "description": "Wrap all commands in a single transaction with auto-rollback on failure (default: false)",
                            "default": False
                        },
                        "dry_run": {
                            "type": "boolean",
                            "description": "Validate parameters and dependencies only, do NOT execute. Returns execution plan preview. (default: false)",
                            "default": False
                        }
                    },
                    "required": ["commands"],
                },
            ),

            # ===== 命令查询工具 =====
            types.Tool(
                name="query_api_commands",
                description=(
                    "Look up available CAD API commands and their parameter definitions.\n\n"
                    "WHEN TO USE:\n"
                    "- Before calling smart_cad_command, if you are unsure about the exact command name or required parameters.\n"
                    "- To discover what commands are available in a specific category.\n\n"
                    "MODES (set exactly one):\n"
                    "- Neither command_name nor category → returns full command list grouped by category.\n"
                    "- command_name: 'api_draw_circle' → returns detailed parameter definitions and usage example for that command.\n"
                    "- category: 'drawing' → returns all commands in that category.\n\n"
                    "AVAILABLE CATEGORIES: drawing, query, block, modify, batch, spatial, layer, document, view, selection, transaction, gslc\n\n"
                    "RETURNS: {success, source, commands[] or command: {name, parameters[], usageExample}}"
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "command_name": {
                            "type": "string",
                            "description": "Exact command name to look up (e.g. 'api_draw_circle'). Returns detailed parameter info."
                        },
                        "category": {
                            "type": "string",
                            "description": "Filter by category English name (e.g. 'drawing', 'query', 'gslc'). Returns all commands in that category."
                        }
                    },
                    "required": [],
                },
            ),

            # ===== GsLc 业务域路由 =====
            types.Tool(
                name="gslc_route_command",
                description=(
                    "Route GsLc (工艺流程图/Process Flow Diagram) operations to the correct api_gslc_* command.\n\n"
                    "WHEN TO USE:\n"
                    "- ALWAYS call this BEFORE executing any api_gslc_* command.\n"
                    "- When the user mentions GsLc concepts: 设备(equipment), 管道(pipe), 仪表(instrument), 图框(frame), 位号(tag), 阀门(valve), 箭头(arrow).\n\n"
                    "WHEN NOT TO USE:\n"
                    "- General CAD operations (draw, move, layer, query by type/layer) → use smart_cad_command directly.\n\n"
                    "WHY THIS TOOL EXISTS:\n"
                    "GsLc has 36 commands with confusingly similar names. Common mistakes without this tool:\n"
                    "- '批量生成位号' → wrong: auto_number (modifies existing), correct: insert_bottom_equip_tags (creates new)\n"
                    "- '插入接图箭头' → wrong: insert_outer_pipe_arrow (utility pipes), correct: insert_join_draw_arrow (cross-diagram)\n"
                    "- '刷新管道来去向' → wrong: sync_pipe_data (imports from Excel), correct: brush_batch_pipes (refreshes associations)\n\n"
                    "WORKFLOW: gslc_route_command(intent) → get recommended command → smart_cad_command(recommended_command, params)\n\n"
                    "RETURNS: {recommended: {command, score, reason}, candidates[], disambiguation_hint}"
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "user_intent": {
                            "type": "string",
                            "description": "Natural language description of the GsLc operation, e.g. '批量生成设备位号', '插入控制阀', '刷新管道来去向'"
                        },
                        "context": {
                            "type": "object",
                            "description": "Optional context for better routing accuracy",
                            "properties": {
                                "has_frame_handle": {"type": "boolean", "description": "Whether a frame handle is already available"},
                                "has_entity_handles": {"type": "boolean", "description": "Whether entity handles are already available"},
                                "target_entity_type": {"type": "string", "description": "Target entity type (equipment, instrument, pipe, valve, etc.)"}
                            }
                        }
                    },
                    "required": ["user_intent"]
                }
            ),
        ]

    @server.call_tool()
    async def handle_call_tool(
        name: str, arguments: dict[str, Any] | None
    ) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
        """处理工具执行请求"""
        try:
            # 确保 arguments 是字典，允许空参数（某些工具不需要参数）
            if arguments is None:
                arguments = {}

            if name == "smart_cad_command":
                command_name = arguments.get("command_name")
                parameters = arguments.get("parameters")
                need_result = arguments.get("need_result")  # 可能是 None
                timeout = arguments.get("timeout", 10.0)

                if not command_name:
                    raise ValueError("缺少 command_name 参数")

                # 确保 CAD 已连接
                if not cad_service.controller.is_running():
                    cad_service.start_cad()

                cmd_metrics = CommandMetrics(command_name)
                result = cad_service.controller.smart_cad_command(
                    command_name=command_name,
                    parameters=parameters,
                    need_result=need_result,
                    timeout=timeout
                )
                cmd_metrics.finish(result)
                cad_service.session_metrics.record(cmd_metrics)

                # 更新图纸状态
                cad_service.drawing_state.update_from_result(command_name, result)
                cad_service.drawing_state.update_document_info(cad_service.controller)

                # 错误时附加 fix_hint（从本地 manifest 获取正确参数格式）
                if not result.get("success") and result.get("errorCode") in (-3, -4):
                    fix_hint = _get_command_fix_hint(command_name)
                    if fix_hint:
                        result["fix_hint"] = fix_hint

                return [types.TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))]

            elif name == "batch_execute":
                commands = arguments.get("commands")
                stop_on_error = arguments.get("stop_on_error", True)
                timeout_per_command = arguments.get("timeout_per_command", 10.0)
                detail_level = arguments.get("detail_level", "handles")
                use_transaction = arguments.get("use_transaction", False)
                dry_run = arguments.get("dry_run", False)

                if not commands:
                    raise ValueError("缺少 commands 参数")

                # dry_run 模式：只验证不执行
                if dry_run:
                    batch_executor = BatchExecutor(cad_service.controller)
                    result = batch_executor.dry_run(commands)
                    return [types.TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))]

                # 确保 CAD 已连接
                if not cad_service.controller.is_running():
                    cad_service.start_cad()

                batch_executor = BatchExecutor(cad_service.controller)
                result = batch_executor.execute(
                    commands=commands,
                    stop_on_error=stop_on_error,
                    timeout_per_command=timeout_per_command,
                    detail_level=detail_level,
                    use_transaction=use_transaction
                )
                return [types.TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))]

            elif name == "query_api_commands":
                command_name = arguments.get("command_name")
                category = arguments.get("category")
                result = _query_api_commands(cad_service, command_name, category)
                return [types.TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2))]

            elif name == "gslc_route_command":
                from .domains.gslc.router import GsLcRouter

                user_intent = arguments.get("user_intent", "")
                context = arguments.get("context")

                if not user_intent:
                    raise ValueError("缺少 user_intent 参数")

                router = GsLcRouter()
                result = router.route(user_intent, context)

                result_dict = {
                    "domain": result.domain,
                    "intent_category": result.intent_category,
                    "intent_confidence": result.intent_confidence,
                    "recommended": result.recommended,
                    "candidates": [
                        {
                            "command": c.command,
                            "score": c.score,
                            "category": c.category,
                            "reason": c.reason,
                            "why_not": c.why_not
                        } for c in result.candidates
                    ],
                    "disambiguation_hint": result.disambiguation_hint
                }
                return [types.TextContent(type="text", text=json.dumps(result_dict, ensure_ascii=False, indent=2))]

            else:
                raise ValueError(f"未知工具: {name}")

        except Exception as e:
            return [types.TextContent(type="text", text=json.dumps({
                "success": False,
                "error": str(e),
                "tool": name,
            }, ensure_ascii=False, indent=2))]

    @server.list_prompts()
    async def handle_list_prompts() -> list[types.Prompt]:
        logger.debug("处理 list_prompts 请求")
        return [
            types.Prompt(
                name="cad-assistant",
                description="一个用于通过自然语言控制CAD的助手",
                arguments=[],
            )
        ]

    @server.get_prompt()
    async def handle_get_prompt(name: str, arguments: dict[str, str] | None) -> types.GetPromptResult:
        logger.debug(f"处理 get_prompt 请求，名称: {name}，参数: {arguments}")
        if name != "cad-assistant":
            logger.error(f"未知的提示: {name}")
            raise ValueError(f"未知的提示: {name}")

        # 动态注入当前图纸状态
        cad_service.drawing_state.update_document_info(cad_service.controller)
        cad_name = config.config.get("cad", {}).get("type", "CAD")
        prompt = load_prompt_template(cad_name, cad_service.drawing_state.to_context_string())

        return types.GetPromptResult(
            description="CAD助手提示模板",
            messages=[
                types.PromptMessage(
                    role="user",
                    content=types.TextContent(type="text", text=prompt.strip()),
                )
            ],
        )

    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        logger.info("服务器正在使用 stdio 传输运行")
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name=config.server_name,
                server_version=config.server_version,
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

def main_cli():
    """同步入口，供 pyproject.toml [project.scripts] 和 __main__.py 使用"""
    import argparse
    from . import __version__

    parser = argparse.ArgumentParser(description="CAD-Cowork-MCP Server")
    parser.add_argument("--version", action="version", version=f"cad-cowork-mcp {__version__}")
    parser.parse_args()

    import asyncio
    asyncio.run(main())


if __name__ == "__main__":
    main_cli()