"""
GsLc 工艺流程图命令路由器

提供 36 个 GsLc API 命令的智能路由能力。

使用方式：
    from domains.gslc.router import GsLcRouter

    router = GsLcRouter()
    result = router.route("批量生成设备位号")

    print(result.recommended["command"])  # api_gslc_insert_bottom_equip_tags
    print(result.candidates[1].why_not)   # "auto_number 是给已有实体编号，不是生成新位号块"
"""

from .router import GsLcRouter

__all__ = ['GsLcRouter']
