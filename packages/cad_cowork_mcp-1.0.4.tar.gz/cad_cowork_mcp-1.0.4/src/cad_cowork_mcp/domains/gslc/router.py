"""
GsLc 命令路由器

继承 BaseCommandRouter，实现工艺流程图命令的智能路由。
"""

from typing import Dict, List, Optional

from ...command_router.base_router import BaseCommandRouter
from ...command_router.types import CommandCandidate

from .taxonomy import INTENT_CATEGORIES, ENTITY_TYPES, COMMAND_MAPPINGS
from .rules import NEGATIVE_RULES, DISAMBIGUATION_HINTS


class GsLcRouter(BaseCommandRouter):
    """GsLc 工艺流程图命令路由器"""

    @property
    def domain_name(self) -> str:
        return "gslc"

    def _load_taxonomy(self):
        """加载分类法"""
        self.intent_categories = INTENT_CATEGORIES
        self.entity_types = ENTITY_TYPES
        self.command_mappings = COMMAND_MAPPINGS

    def _get_intent_categories(self) -> Dict:
        return self.intent_categories

    def _get_command_mappings(self) -> Dict:
        return self.command_mappings

    def _get_negative_rules(self) -> List:
        return NEGATIVE_RULES

    def _recognize_entities(self, user_intent: str) -> List[str]:
        """
        识别用户意图中的实体类型

        Args:
            user_intent: 用户意图描述

        Returns:
            识别出的实体类型列表
        """
        entities = []
        for entity_name, entity_def in self.entity_types.items():
            keywords = entity_def.get("keywords", [])
            if any(kw in user_intent for kw in keywords):
                entities.append(entity_name)
        return entities if entities else ["unknown"]

    def _generate_candidates(
        self,
        intent: Dict,
        entities: List[str],
        user_intent: str,
        context: Optional[Dict]
    ) -> List[CommandCandidate]:
        """
        生成候选命令

        Args:
            intent: 识别的意图 {"category": str, "confidence": float}
            entities: 识别的实体类型列表
            user_intent: 用户意图描述
            context: 可选上下文

        Returns:
            候选命令列表
        """
        candidates = []

        for cmd_name, cmd_def in self.command_mappings.items():
            # 使用评分引擎计算得分
            score = self.scorer.calculate_score(
                user_intent=user_intent,
                command_def=cmd_def,
                intent_category=intent["category"],
                recognized_entities=entities,
                context=context
            )

            # 创建候选项
            candidate = CommandCandidate(
                command=cmd_name,
                score=score,
                category=cmd_def.get("intent", "unknown"),
                reason=cmd_def.get("description", ""),
                usage_example=f'{{"command_name": "{cmd_name}", "parameters": {{}}}}'
            )

            candidates.append(candidate)

        return candidates

    def _generate_disambiguation_hint(
        self,
        candidates: List[CommandCandidate],
        user_intent: str
    ) -> Optional[str]:
        """
        生成消歧提示

        当 top 2 候选得分接近时，提供区分说明。

        Args:
            candidates: 已排序的候选列表
            user_intent: 用户意图描述

        Returns:
            消歧提示，或 None
        """
        if len(candidates) < 2:
            return None

        top_two = candidates[:2]

        # 如果 top 2 得分差距小于 0.3，提供消歧提示
        if top_two[0].score - top_two[1].score < 0.3:
            pair = (top_two[0].command, top_two[1].command)
            reverse_pair = (top_two[1].command, top_two[0].command)

            # 查找预定义的消歧提示
            hint = DISAMBIGUATION_HINTS.get(pair) or DISAMBIGUATION_HINTS.get(reverse_pair)

            if hint:
                return hint

            # 如果没有预定义提示，但有 why_not，也返回
            if top_two[1].why_not:
                return f"注意区分：{top_two[1].why_not}"

        return None


# 便捷函数
def route_gslc_command(user_intent: str, context: Optional[Dict] = None):
    """
    路由 GsLc 命令（便捷函数）

    Args:
        user_intent: 用户意图描述
        context: 可选上下文

    Returns:
        RoutingResult
    """
    router = GsLcRouter()
    return router.route(user_intent, context)
