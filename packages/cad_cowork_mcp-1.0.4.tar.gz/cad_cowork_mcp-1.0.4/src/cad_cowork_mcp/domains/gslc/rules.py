"""
GsLc 负向引导规则

解决 8 对容易混淆的命令：
1. insert_bottom_equip_tags vs auto_number（批量生成 vs 编号）
2. insert_valve vs insert_control_valve（普通阀门 vs 控制阀）
3. insert_join_draw_arrow vs insert_outer_pipe_arrow（接图 vs 外管）
4. brush_batch_pipes vs sync_pipe_data（刷新 vs 同步）
5. query_instrument_in_frame vs query_valve_in_frame（仪表含控制阀 vs 普通阀门）
6. export_all_data vs export_frame_data（全量 vs 单图框）
7. insert_equip_tag vs insert_bottom_equip_tags（单个 vs 批量）
8. auto_number vs insert_equipment（编号 vs 插入）
"""

NEGATIVE_RULES = [
    # 规则1: 批量生成位号 vs 自动编号
    {
        "name": "batch_generate_vs_auto_number",
        "trigger": lambda inp: ("批量生成" in inp or "生成位号" in inp or "生成设备位号" in inp) and "编号" not in inp,
        "wrong": ["api_gslc_auto_number"],
        "right": "api_gslc_insert_bottom_equip_tags",
        "why_not": "auto_number 是给已有实体编号（修改属性），不是生成新位号块"
    },

    # 规则2: 自动编号 vs 插入/生成
    {
        "name": "auto_number_vs_insert",
        "trigger": lambda inp: "编号" in inp and ("自动" in inp or "重新" in inp or "排序" in inp),
        "wrong": ["api_gslc_insert_bottom_equip_tags", "api_gslc_insert_equip_tag", "api_gslc_insert_equipment"],
        "right": "api_gslc_auto_number",
        "why_not": "insert_xxx 是创建新实体，编号请用 auto_number"
    },

    # 规则3: 接图箭头 vs 外管箭头
    {
        "name": "join_arrow_vs_outer_arrow",
        "trigger": lambda inp: "接图" in inp and "外管" not in inp,
        "wrong": ["api_gslc_insert_outer_pipe_arrow"],
        "right": "api_gslc_insert_join_draw_arrow",
        "why_not": "outer_pipe_arrow 是外管/公用工程来去向，接图连接请用 join_draw_arrow"
    },

    # 规则4: 外管箭头 vs 接图箭头
    {
        "name": "outer_arrow_vs_join_arrow",
        "trigger": lambda inp: ("外管" in inp or "公用工程" in inp or "蒸汽" in inp or "冷却水" in inp) and "接图" not in inp,
        "wrong": ["api_gslc_insert_join_draw_arrow"],
        "right": "api_gslc_insert_outer_pipe_arrow",
        "why_not": "join_draw_arrow 是跨图连接，外管/公用工程来去向请用 outer_pipe_arrow"
    },

    # 规则5: 控制阀 vs 普通阀门
    {
        "name": "control_valve_vs_valve",
        "trigger": lambda inp: ("控制阀" in inp or "调节阀" in inp or "开关阀" in inp or "电动阀" in inp or "气动阀" in inp),
        "wrong": ["api_gslc_insert_valve"],
        "right": "api_gslc_insert_control_valve",
        "why_not": "insert_valve 是普通阀门（球阀/闸阀等），控制阀/调节阀请用 insert_control_valve"
    },

    # 规则6: 普通阀门 vs 控制阀
    {
        "name": "valve_vs_control_valve",
        "trigger": lambda inp: ("阀门" in inp or "球阀" in inp or "闸阀" in inp or "截止阀" in inp or "蝶阀" in inp) and "控制" not in inp and "调节" not in inp and "开关" not in inp,
        "wrong": ["api_gslc_insert_control_valve"],
        "right": "api_gslc_insert_valve",
        "why_not": "insert_control_valve 是仪表控制阀，普通阀门（球阀/闸阀等）请用 insert_valve"
    },

    # 规则7: 刷新关联 vs 同步数据
    {
        "name": "brush_vs_sync",
        "trigger": lambda inp: ("刷新" in inp or "刷" in inp) and ("管道" in inp or "仪表" in inp) and "Excel" not in inp and "导入" not in inp and "同步" not in inp and "JSON" not in inp,
        "wrong": ["api_gslc_sync_pipe_data", "api_gslc_sync_instrument_data", "api_gslc_sync_equipment_data"],
        "right": "api_gslc_brush_batch_pipes",
        "why_not": "sync_xxx 是从外部数据（Excel/JSON）导入，刷新关联请用 brush_xxx"
    },

    # 规则8: 同步数据 vs 刷新关联
    {
        "name": "sync_vs_brush",
        "trigger": lambda inp: ("同步" in inp or "导入" in inp or "Excel" in inp or "JSON" in inp or "从文件" in inp),
        "wrong": ["api_gslc_brush_batch_pipes", "api_gslc_brush_batch_instruments"],
        "right": "api_gslc_sync_pipe_data",
        "why_not": "brush_xxx 是刷新CAD内关联，从外部数据导入请用 sync_xxx"
    }
]

# 消歧提示映射
DISAMBIGUATION_HINTS = {
    ("api_gslc_insert_bottom_equip_tags", "api_gslc_auto_number"):
        "批量生成 ≠ 自动编号。生成是创建新位号块实体，编号是修改现有实体的编号属性",

    ("api_gslc_insert_valve", "api_gslc_insert_control_valve"):
        "普通阀门（球阀/闸阀/截止阀） ≠ 控制阀门（调节阀/开关阀/电动阀）",

    ("api_gslc_insert_join_draw_arrow", "api_gslc_insert_outer_pipe_arrow"):
        "接图箭头（跨图连接） ≠ 外管箭头（公用工程来去向）",

    ("api_gslc_brush_batch_pipes", "api_gslc_sync_pipe_data"):
        "刷新关联 ≠ 同步数据。刷新是CAD内自动计算关联，同步是从外部Excel/JSON导入数据",

    ("api_gslc_insert_equip_tag", "api_gslc_insert_bottom_equip_tags"):
        "单个插入 ≠ 批量生成。insert_equip_tag 需指定位置，insert_bottom_equip_tags 自动在底部生成",

    ("api_gslc_query_instrument_in_frame", "api_gslc_query_valve_in_frame"):
        "仪表查询（包含控制阀） ≠ 阀门查询（仅普通阀门）"
}
