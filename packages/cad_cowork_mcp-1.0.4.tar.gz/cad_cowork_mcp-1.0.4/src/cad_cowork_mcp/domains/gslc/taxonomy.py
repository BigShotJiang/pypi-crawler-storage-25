"""
GsLc 工艺流程图分类法

定义：
- INTENT_CATEGORIES: 意图类别（query/insert/brush/export/sync/tool）
- ENTITY_TYPES: 实体类型（equipment/instrument/pipe/valve/...）
- COMMAND_MAPPINGS: 36 个命令的详细映射
"""

# 意图类别定义
INTENT_CATEGORIES = {
    "query": {
        "display_name": "查询",
        "keywords": ["查询", "获取", "列出", "显示", "查看", "统计", "有哪些", "有多少"],
        "anti_keywords": ["插入", "创建", "生成", "添加"]
    },
    "insert": {
        "display_name": "插入/创建",
        "keywords": ["插入", "创建", "生成", "添加", "放置", "批量生成"],
        "anti_keywords": ["查询", "获取", "删除"]
    },
    "brush": {
        "display_name": "刷新/关联",
        "keywords": ["刷新", "刷", "关联", "绑定", "设置位置", "设置来去向"],
        "anti_keywords": ["插入", "创建", "同步", "导入"]
    },
    "export": {
        "display_name": "导出",
        "keywords": ["导出", "输出", "保存为", "生成报表", "生成表格", "生成清单"],
        "anti_keywords": ["导入", "同步"]
    },
    "sync": {
        "display_name": "同步/导入",
        "keywords": ["同步", "导入", "更新", "从Excel", "从JSON", "从文件"],
        "anti_keywords": ["导出", "刷新"]
    },
    "tool": {
        "display_name": "工具/编号",
        "keywords": ["编号", "自动编号", "验证", "清除", "移动到冻结", "恢复"],
        "anti_keywords": ["生成位号", "创建位号", "插入位号"]
    }
}

# 实体类型定义
ENTITY_TYPES = {
    "equipment": {
        "display_name": "设备",
        "keywords": ["设备", "反应釜", "储罐", "泵", "加热器", "离心机", "真空泵"]
    },
    "equip_tag": {
        "display_name": "设备位号",
        "keywords": ["位号", "设备位号", "TAG", "底部位号", "位号块"]
    },
    "instrument": {
        "display_name": "仪表",
        "keywords": ["仪表", "传感器", "变送器", "温度", "压力", "液位", "流量"]
    },
    "control_valve": {
        "display_name": "控制阀门",
        "keywords": ["控制阀", "调节阀", "开关阀", "电动阀", "气动阀", "自力式"]
    },
    "valve": {
        "display_name": "普通阀门",
        "keywords": ["阀门", "球阀", "闸阀", "截止阀", "止回阀", "蝶阀", "安全阀"]
    },
    "pipe": {
        "display_name": "管道",
        "keywords": ["管道", "管线", "管路", "来去向"]
    },
    "join_draw_arrow": {
        "display_name": "接图箭头",
        "keywords": ["接图", "跨图", "图号", "接续", "接图箭头"]
    },
    "outer_pipe_arrow": {
        "display_name": "外管箭头",
        "keywords": ["外管", "公用工程", "蒸汽", "冷却水", "仪表风", "氮气"]
    },
    "frame": {
        "display_name": "图框",
        "keywords": ["图框", "图幅", "图纸范围", "图纸"]
    }
}

# 36 个 GsLc 命令映射
COMMAND_MAPPINGS = {
    # ========== 插入类 (9) ==========
    "api_gslc_insert_bottom_equip_tags": {
        "intent": "insert",
        "entity": "equip_tag",
        "keywords": ["批量生成位号", "自动生成位号", "底部位号", "生成设备位号", "批量插入位号"],
        "anti_patterns": ["编号", "序号", "重新编号"],
        "description": "在图框底部自动批量生成设备位号块",
        "differentiator": "自动批量生成新实体，不需要指定位置"
    },
    "api_gslc_insert_equip_tag": {
        "intent": "insert",
        "entity": "equip_tag",
        "keywords": ["插入位号", "添加位号", "创建位号", "单个位号"],
        "anti_patterns": ["批量", "自动", "底部"],
        "description": "在指定位置插入单个设备位号块",
        "differentiator": "需要指定具体位置"
    },
    "api_gslc_insert_equipment": {
        "intent": "insert",
        "entity": "equipment",
        "keywords": ["插入设备", "添加设备", "创建设备", "放置设备"],
        "anti_patterns": ["批量", "自动", "位号"],
        "description": "在指定位置插入单个设备块"
    },
    "api_gslc_insert_instrument": {
        "intent": "insert",
        "entity": "instrument",
        "keywords": ["插入仪表", "添加仪表", "创建仪表"],
        "description": "在指定位置插入仪表块"
    },
    "api_gslc_insert_control_valve": {
        "intent": "insert",
        "entity": "control_valve",
        "keywords": ["插入控制阀", "插入调节阀", "添加控制阀", "添加调节阀", "开关阀"],
        "anti_patterns": ["球阀", "闸阀", "截止阀"],
        "description": "在指定位置插入控制阀门（调节阀、开关阀等）"
    },
    "api_gslc_insert_valve": {
        "intent": "insert",
        "entity": "valve",
        "keywords": ["插入阀门", "添加阀门", "插入球阀", "插入闸阀", "插入截止阀"],
        "anti_patterns": ["控制阀", "调节阀", "开关阀"],
        "description": "在指定位置插入普通阀门"
    },
    "api_gslc_insert_pipe": {
        "intent": "insert",
        "entity": "pipe",
        "keywords": ["插入管道", "添加管道", "创建管道"],
        "description": "在指定位置插入管道"
    },
    "api_gslc_insert_join_draw_arrow": {
        "intent": "insert",
        "entity": "join_draw_arrow",
        "keywords": ["插入接图箭头", "添加接图", "跨图连接", "接图"],
        "anti_patterns": ["外管", "公用工程"],
        "description": "插入接图箭头（用于多图纸连接）"
    },
    "api_gslc_insert_outer_pipe_arrow": {
        "intent": "insert",
        "entity": "outer_pipe_arrow",
        "keywords": ["插入外管箭头", "外管", "公用工程箭头", "蒸汽箭头"],
        "anti_patterns": ["接图"],
        "description": "插入外管箭头（公用工程来去向）"
    },

    # ========== 查询类 (8) ==========
    "api_gslc_query_frame_info": {
        "intent": "query",
        "entity": "frame",
        "keywords": ["查询图框", "图框信息", "图框统计", "图框数据"],
        "description": "查询图框信息和统计数据"
    },
    "api_gslc_query_equipment_in_frame": {
        "intent": "query",
        "entity": "equipment",
        "keywords": ["查询设备", "设备列表", "图框内设备", "有哪些设备"],
        "description": "查询图框内的设备实体"
    },
    "api_gslc_query_instrument_in_frame": {
        "intent": "query",
        "entity": "instrument",
        "keywords": ["查询仪表", "仪表列表", "图框内仪表", "有哪些仪表"],
        "description": "查询图框内的仪表（包含控制阀）"
    },
    "api_gslc_query_pipe_in_frame": {
        "intent": "query",
        "entity": "pipe",
        "keywords": ["查询管道", "管道列表", "图框内管道", "有哪些管道"],
        "description": "查询图框内的管道"
    },
    "api_gslc_query_valve_in_frame": {
        "intent": "query",
        "entity": "valve",
        "keywords": ["查询阀门", "阀门列表", "图框内阀门", "有哪些阀门"],
        "description": "查询图框内的普通阀门（不含控制阀）"
    },
    "api_gslc_query_join_draw_arrow_in_frame": {
        "intent": "query",
        "entity": "join_draw_arrow",
        "keywords": ["查询接图箭头", "接图列表", "有哪些接图"],
        "description": "查询图框内的接图箭头"
    },
    "api_gslc_query_all_entities_in_frame": {
        "intent": "query",
        "entity": "frame",
        "keywords": ["查询所有实体", "图框内所有", "全部实体", "所有元素"],
        "description": "查询图框内所有 GsLc 实体"
    },
    "api_gslc_query_entities_by_relative_position": {
        "intent": "query",
        "entity": "equipment",
        "keywords": ["相对位置", "关联实体", "周围实体", "附近实体"],
        "description": "按相对位置查询实体（围绕某设备的仪表/阀门等）"
    },

    # ========== 刷新类 (4) ==========
    "api_gslc_brush_batch_pipes": {
        "intent": "brush",
        "entity": "pipe",
        "keywords": ["刷管道", "管道来去向", "管道关联", "刷新管道", "批量刷管道"],
        "anti_patterns": ["同步", "导入", "Excel", "JSON"],
        "description": "批量刷新管道的来去向关联",
        "differentiator": "关联设备位号，不是同步外部数据"
    },
    "api_gslc_brush_batch_instruments": {
        "intent": "brush",
        "entity": "instrument",
        "keywords": ["刷仪表", "仪表关联", "刷新仪表", "批量刷仪表"],
        "anti_patterns": ["同步", "导入"],
        "description": "批量刷新仪表的关联"
    },
    "api_gslc_brush_join_draw_arrow": {
        "intent": "brush",
        "entity": "join_draw_arrow",
        "keywords": ["刷接图箭头", "接图关联", "刷新接图"],
        "description": "刷新接图箭头关联"
    },
    "api_gslc_brush_pipeline_elements": {
        "intent": "brush",
        "entity": "pipe",
        "keywords": ["刷管道元素", "管道元素关联", "刷新管件"],
        "description": "刷新管道元素关联"
    },

    # ========== 导出类 (6) ==========
    "api_gslc_export_all_data": {
        "intent": "export",
        "entity": "frame",
        "keywords": ["导出全部", "导出所有数据", "全量导出", "导出所有", "导出流程图数据", "导出CAD数据",
                     "导出设备", "设备数据", "导出管道", "管道数据", "导出仪表", "仪表数据", "导出阀门", "阀门数据"],
        "description": "导出全部流程图数据（设备+仪表+管道+阀门），flat JArray 格式"
    },
    "api_gslc_export_frame_data": {
        "intent": "export",
        "entity": "frame",
        "keywords": ["导出图框", "图框数据", "导出单图框"],
        "description": "导出单个图框的数据"
    },
    # 已删除：api_gslc_export_equipment/pipeline/instrument/valve_fitting_data
    # 功能已整合到 api_gslc_export_all_data

    # ========== 同步类 (3) ==========
    "api_gslc_sync_pipe_data": {
        "intent": "sync",
        "entity": "pipe",
        "keywords": ["同步管道", "导入管道", "更新管道数据", "从Excel管道", "从JSON管道"],
        "anti_patterns": ["刷新", "刷"],
        "description": "从外部数据源同步管道属性",
        "differentiator": "从JSON/Excel导入数据更新属性"
    },
    "api_gslc_sync_equipment_data": {
        "intent": "sync",
        "entity": "equipment",
        "keywords": ["同步设备", "导入设备", "更新设备数据", "从Excel设备"],
        "anti_patterns": ["刷新"],
        "description": "从外部数据源同步设备属性"
    },
    "api_gslc_sync_instrument_data": {
        "intent": "sync",
        "entity": "instrument",
        "keywords": ["同步仪表", "导入仪表", "更新仪表数据", "从Excel仪表"],
        "anti_patterns": ["刷新"],
        "description": "从外部数据源同步仪表属性"
    },

    # ========== 工具类 (6) ==========
    "api_gslc_auto_number": {
        "intent": "tool",
        "entity": ["equipment", "instrument", "pipe", "valve"],
        "keywords": ["自动编号", "编号", "序号", "排序编号", "重新编号"],
        "anti_patterns": ["生成位号", "创建位号", "插入位号", "批量生成"],
        "description": "对现有实体进行自动编号（修改编号属性）",
        "differentiator": "修改已有实体的编号属性，不创建新实体"
    },
    "api_gslc_generate_equipment_list": {
        "intent": "tool",
        "entity": "equipment",
        "keywords": ["生成设备一览表", "设备清单", "设备汇总", "设备一览"],
        "description": "生成设备一览表"
    },
    "api_gslc_validate_entity_data": {
        "intent": "tool",
        "entity": "frame",
        "keywords": ["验证数据", "数据检查", "校验", "数据验证"],
        "description": "验证 GsLc 实体数据完整性"
    },
    "api_gslc_clear_relative_position": {
        "intent": "tool",
        "entity": "equipment",
        "keywords": ["清除相对位置", "清除关联", "重置位置"],
        "description": "清除实体的相对位置信息"
    },
    "api_gslc_move_to_freeze_layer": {
        "intent": "tool",
        "entity": "frame",
        "keywords": ["移动到冻结", "冻结图层", "隐藏实体", "冻结"],
        "description": "将实体移动到冻结图层"
    },
    "api_gslc_restore_from_freeze_layer": {
        "intent": "tool",
        "entity": "frame",
        "keywords": ["从冻结恢复", "恢复实体", "取消冻结", "解冻"],
        "description": "从冻结图层恢复实体"
    }
}
