"""
业务域路由器

每个业务域独立实现自己的路由器，共享 command_router 基础框架。

目录结构：
    domains/
    ├── gslc/       # 工艺流程图（GsLc）
    ├── gsbz/       # 报装图（未来）
    ├── gspg/       # 配管图（未来）
    └── ksbz/       # 其他业务（未来）

扩展新业务域：
    1. 创建 domains/xxx/ 目录
    2. 实现 router.py (继承 BaseCommandRouter)
    3. 定义 taxonomy.py (分类法)
    4. 定义 rules.py (负向规则)
    5. 在 server.py 注册 xxx_route_command 工具
"""
