#!/usr/bin/env python
"""
直接命令执行脚本

用于 Electron IPC 直接调用 CAD 命令（绕过 MCP 协议）
通过 subprocess 调用此脚本执行命令并返回结果

注意：此脚本创建独立的 COM 连接，与 MCP Server 的连接互不影响。
如果遇到 MCP 调用异常，可能需要检查 CAD 的命令状态。

Usage:
    python direct_command.py <command_name>
    # 参数通过 stdin 以 JSON 格式传递

Example:
    echo '{"entityTypes": ["LINE", "CIRCLE"]}' | python direct_command.py api_window_select_with_filter
"""

import sys
import json
import os

# 导入 pythoncom 用于 COM 清理
try:
    import pythoncom
    HAS_PYTHONCOM = True
except ImportError:
    HAS_PYTHONCOM = False

from .cad_controller import CADController


def main():
    """主函数：解析命令行参数并执行 CAD 命令"""
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "errorCode": -2,
            "message": "Missing command name",
            "data": None
        }))
        return

    command_name = sys.argv[1]
    parameters = {}

    # 从 stdin 读取参数 JSON（解决 ENAMETOOLONG 问题）
    # Windows 命令行长度限制约 32767 字符，大选择集会超限
    stdin_data = sys.stdin.read().strip()
    if stdin_data:
        try:
            parameters = json.loads(stdin_data)
        except json.JSONDecodeError as e:
            print(json.dumps({
                "success": False,
                "errorCode": -3,
                "message": f"Invalid parameters JSON from stdin: {str(e)}",
                "data": None
            }))
            return

    controller = None
    try:
        # 创建 CAD 控制器
        controller = CADController()

        # 连接 CAD（必须先连接才能执行命令）
        if not controller.start_cad():
            print(json.dumps({
                "success": False,
                "errorCode": -7,
                "message": "无法连接到 CAD，请确保 CAD 已启动",
                "data": None
            }, ensure_ascii=False))
            return

        # 执行命令（使用较长的超时时间，因为截图可能需要较长时间）
        timeout = 60.0 if "preview" in command_name.lower() else 30.0
        result = controller.execute_api_command(
            command_name=command_name,
            parameters=parameters,
            timeout=timeout
        )

        # 输出结果（供调用方捕获）
        print(json.dumps(result, ensure_ascii=False))

    except Exception as e:
        print(json.dumps({
            "success": False,
            "errorCode": -5,
            "message": f"Execution failed: {str(e)}",
            "data": None
        }))
    finally:
        # 清理 COM 连接（帮助释放资源）
        if controller is not None:
            controller.app = None
            controller.doc = None
        if HAS_PYTHONCOM:
            try:
                pythoncom.CoUninitialize()
            except Exception:
                pass  # 忽略清理错误


if __name__ == "__main__":
    main()
