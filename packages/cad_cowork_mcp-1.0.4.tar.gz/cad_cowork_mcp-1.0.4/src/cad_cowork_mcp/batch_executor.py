"""
批量命令执行器

支持 DAG 依赖管理和参数引用传递，用于一次性执行多个 API 命令。
"""

import json
import re
import logging
import time
from typing import Any, Dict, List, Optional, Tuple
from collections import defaultdict

logger = logging.getLogger('batch_executor')


class BatchExecutionError(Exception):
    """批量执行错误"""
    pass


class CyclicDependencyError(BatchExecutionError):
    """循环依赖错误"""
    pass


class ReferenceResolutionError(BatchExecutionError):
    """引用解析错误"""
    pass


class BatchExecutor:
    """批量命令执行器，支持 DAG 依赖和参数传递"""

    # 引用语法正则：${cmd_id.field.path} 或 ${cmd_id.array[0]}
    REFERENCE_PATTERN = re.compile(r'\$\{([^}]+)\}')

    def __init__(self, cad_controller):
        """
        初始化批量执行器

        Args:
            cad_controller: CADController 实例
        """
        self.controller = cad_controller
        self.results: Dict[str, Dict] = {}      # 命令ID -> 执行结果
        self.handle_map: Dict[str, str] = {}    # 命令ID -> 主 Handle

    def dry_run(self, commands: List[Dict]) -> Dict[str, Any]:
        """验证命令列表的格式、依赖关系和参数引用，不实际执行

        用于在批量执行前预检，确认所有参数合法、无循环依赖。

        Args:
            commands: 命令列表（格式同 execute）

        Returns:
            dict: 包含 valid, execution_order, issues[] 的验证结果
        """
        issues: List[str] = []

        # 1. 格式验证
        validation_error = self._validate_commands(commands)
        if validation_error:
            return {
                "valid": False,
                "message": f"命令格式验证失败: {validation_error}",
                "execution_order": [],
                "issues": [validation_error]
            }

        # 2. 拓扑排序（检测循环依赖）
        try:
            execution_order = self._topological_sort(commands)
        except CyclicDependencyError as e:
            return {
                "valid": False,
                "message": f"检测到循环依赖: {str(e)}",
                "execution_order": [],
                "issues": [f"循环依赖: {str(e)}"]
            }

        # 3. 检查参数引用是否引用了存在的命令 ID
        cmd_ids = {cmd["id"] for cmd in commands}
        for cmd in commands:
            params_str = json.dumps(cmd.get("parameters", {}))
            for match in self.REFERENCE_PATTERN.finditer(params_str):
                ref_path = match.group(1)
                ref_cmd_id = ref_path.split(".", 1)[0]
                if ref_cmd_id not in cmd_ids:
                    issues.append(f"命令 '{cmd['id']}' 引用了不存在的命令 ID: '{ref_cmd_id}'")
                # 检查引用的命令是否在当前命令的依赖链中
                depends_on = set(cmd.get("depends_on", []))
                if ref_cmd_id not in depends_on and ref_cmd_id != cmd["id"]:
                    issues.append(
                        f"命令 '{cmd['id']}' 引用了 '{ref_cmd_id}' 的结果，但未在 depends_on 中声明依赖"
                    )

        # 4. 构建执行计划
        cmd_index = {cmd["id"]: cmd for cmd in commands}
        plan = []
        for cmd_id in execution_order:
            cmd = cmd_index[cmd_id]
            plan.append({
                "id": cmd_id,
                "command_name": cmd["command_name"],
                "depends_on": cmd.get("depends_on", []),
                "has_parameter_refs": bool(self.REFERENCE_PATTERN.search(
                    json.dumps(cmd.get("parameters", {}))
                ))
            })

        return {
            "valid": len(issues) == 0,
            "message": "验证通过，可以执行" if not issues else f"发现 {len(issues)} 个问题",
            "execution_order": execution_order,
            "execution_plan": plan,
            "total_commands": len(commands),
            "issues": issues
        }

    def execute(
        self,
        commands: List[Dict],
        stop_on_error: bool = True,
        timeout_per_command: float = 10.0,
        detail_level: str = "handles",
        use_transaction: bool = False
    ) -> Dict[str, Any]:
        """
        执行批量命令

        Args:
            commands: 命令列表，每项包含:
                - id: 命令唯一标识
                - command_name: API 命令名称
                - parameters: 命令参数 (可选)
                - depends_on: 依赖的命令ID列表 (可选)
            stop_on_error: 遇到错误是否停止执行
            timeout_per_command: 每个命令的超时时间（秒）
            detail_level: 返回结果的详细程度
                - "summary": 仅返回统计信息
                - "handles": 返回统计信息和句柄列表（默认）
                - "full": 返回完整数据
            use_transaction: 是否使用全局事务
                - True: 所有命令在同一事务中执行，失败自动回滚
                - False: 每个命令独立事务（默认，保持兼容）

        Returns:
            执行结果字典
        """
        start_time = time.time()
        transaction_id = None

        # 如果启用全局事务，先开始事务
        if use_transaction:
            try:
                begin_result = self.controller.execute_api_command(
                    "api_transaction_begin", {}, timeout=timeout_per_command)
                if not begin_result.get("success"):
                    return {
                        "success": False,
                        "message": f"开始事务失败: {begin_result.get('message', '未知错误')}",
                        "summary": {"total": len(commands), "successful": 0, "failed": len(commands)},
                        "results": [],
                        "handle_map": {},
                        "failed_commands": []
                    }
                transaction_id = begin_result.get("data", {}).get("transactionId")
                logger.info(f"全局事务已开始: {transaction_id}")
            except Exception as e:
                return {
                    "success": False,
                    "message": f"开始事务异常: {str(e)}",
                    "summary": {"total": len(commands), "successful": 0, "failed": len(commands)},
                    "results": [],
                    "handle_map": {},
                    "failed_commands": []
                }

        # 重置状态
        self.results = {}
        self.handle_map = {}

        # 验证命令格式
        validation_error = self._validate_commands(commands)
        if validation_error:
            return {
                "success": False,
                "message": f"命令验证失败: {validation_error}",
                "summary": {"total": len(commands), "successful": 0, "failed": len(commands)},
                "results": [],
                "handle_map": {},
                "failed_commands": [{"id": cmd.get("id", "unknown"), "reason": validation_error} for cmd in commands]
            }

        # 构建命令索引
        cmd_index = {cmd["id"]: cmd for cmd in commands}

        # 构建依赖图并拓扑排序
        try:
            execution_order = self._topological_sort(commands)
        except CyclicDependencyError as e:
            return {
                "success": False,
                "message": f"检测到循环依赖: {str(e)}",
                "summary": {"total": len(commands), "successful": 0, "failed": len(commands)},
                "results": [],
                "handle_map": {},
                "failed_commands": [{"id": cmd["id"], "reason": "循环依赖"} for cmd in commands]
            }

        # 执行结果收集
        successful_count = 0
        failed_count = 0
        results_list = []
        failed_commands = []

        # 按拓扑顺序执行
        for cmd_id in execution_order:
            cmd = cmd_index[cmd_id]
            cmd_name = cmd["command_name"]
            parameters = cmd.get("parameters", {})
            depends_on = cmd.get("depends_on", [])

            # 检查依赖是否都成功
            dependency_failed = False
            for dep_id in depends_on:
                if dep_id in self.results and not self.results[dep_id].get("success", False):
                    dependency_failed = True
                    break

            if dependency_failed:
                result = {
                    "id": cmd_id,
                    "command_name": cmd_name,
                    "success": False,
                    "message": f"依赖命令失败，跳过执行",
                    "handle": None,
                    "data": None,
                    "execution_time_ms": 0
                }
                self.results[cmd_id] = result
                results_list.append(result)
                failed_commands.append({"id": cmd_id, "reason": "依赖命令失败"})
                failed_count += 1

                if stop_on_error:
                    # 标记剩余命令为跳过
                    remaining = execution_order[execution_order.index(cmd_id) + 1:]
                    for remaining_id in remaining:
                        skip_result = {
                            "id": remaining_id,
                            "command_name": cmd_index[remaining_id]["command_name"],
                            "success": False,
                            "message": "因前置命令失败而跳过",
                            "handle": None,
                            "data": None,
                            "execution_time_ms": 0
                        }
                        results_list.append(skip_result)
                        failed_commands.append({"id": remaining_id, "reason": "前置命令失败"})
                        failed_count += 1
                    break
                continue

            # 解析参数引用
            try:
                resolved_params = self._resolve_references(parameters)
            except ReferenceResolutionError as e:
                result = {
                    "id": cmd_id,
                    "command_name": cmd_name,
                    "success": False,
                    "message": f"参数引用解析失败: {str(e)}",
                    "handle": None,
                    "data": None,
                    "execution_time_ms": 0
                }
                self.results[cmd_id] = result
                results_list.append(result)
                failed_commands.append({"id": cmd_id, "reason": str(e)})
                failed_count += 1

                if stop_on_error:
                    break
                continue

            # 执行命令
            cmd_start = time.time()
            try:
                api_result = self.controller.execute_api_command(
                    cmd_name,
                    resolved_params,
                    timeout=timeout_per_command
                )
                cmd_time_ms = int((time.time() - cmd_start) * 1000)

                # 提取 Handle
                handle = None
                if api_result.get("success"):
                    # 尝试从多个可能的位置获取 Handle
                    handles = api_result.get("createdEntityHandles", [])
                    if handles:
                        handle = handles[0]
                    elif api_result.get("data", {}).get("entityHandle"):
                        handle = api_result["data"]["entityHandle"]

                result = {
                    "id": cmd_id,
                    "command_name": cmd_name,
                    "success": api_result.get("success", False),
                    "message": api_result.get("message", ""),
                    "handle": handle,
                    "data": api_result.get("data"),
                    "createdEntityHandles": api_result.get("createdEntityHandles", []),
                    "execution_time_ms": cmd_time_ms
                }

                self.results[cmd_id] = result
                if handle:
                    self.handle_map[cmd_id] = handle

                results_list.append(result)

                if api_result.get("success"):
                    successful_count += 1
                else:
                    failed_count += 1
                    failed_commands.append({
                        "id": cmd_id,
                        "reason": api_result.get("message", "执行失败")
                    })
                    if stop_on_error:
                        break

            except Exception as e:
                cmd_time_ms = int((time.time() - cmd_start) * 1000)
                result = {
                    "id": cmd_id,
                    "command_name": cmd_name,
                    "success": False,
                    "message": f"执行异常: {str(e)}",
                    "handle": None,
                    "data": None,
                    "execution_time_ms": cmd_time_ms
                }
                self.results[cmd_id] = result
                results_list.append(result)
                failed_commands.append({"id": cmd_id, "reason": str(e)})
                failed_count += 1

                if stop_on_error:
                    break

        total_time_ms = int((time.time() - start_time) * 1000)

        # 如果启用全局事务，根据结果决定提交或回滚
        transaction_info = None
        if use_transaction and transaction_id:
            try:
                if failed_count == 0:
                    # 全部成功，提交事务
                    commit_result = self.controller.execute_api_command(
                        "api_transaction_commit",
                        {"transactionId": transaction_id},
                        timeout=timeout_per_command
                    )
                    if commit_result.get("success"):
                        transaction_info = {"status": "committed", "transactionId": transaction_id}
                        logger.info(f"全局事务已提交: {transaction_id}")
                    else:
                        transaction_info = {
                            "status": "commit_failed",
                            "transactionId": transaction_id,
                            "error": commit_result.get("message", "提交失败")
                        }
                        logger.warning(f"事务提交失败: {transaction_id}")
                else:
                    # 有失败，回滚事务
                    self.controller.execute_api_command(
                        "api_transaction_rollback",
                        {"transactionId": transaction_id},
                        timeout=timeout_per_command
                    )
                    transaction_info = {"status": "rolled_back", "transactionId": transaction_id}
                    logger.info(f"全局事务已回滚: {transaction_id}")
            except Exception as e:
                transaction_info = {
                    "status": "error",
                    "transactionId": transaction_id,
                    "error": str(e)
                }
                logger.error(f"事务处理异常: {e}")

        result = self._build_result(
            results_list=results_list,
            successful_count=successful_count,
            failed_count=failed_count,
            total_count=len(commands),
            total_time_ms=total_time_ms,
            failed_commands=failed_commands,
            detail_level=detail_level
        )

        # 添加事务信息到结果中
        if transaction_info:
            result["transaction"] = transaction_info

        return result

    def _validate_commands(self, commands: List[Dict]) -> Optional[str]:
        """
        验证命令列表格式

        Args:
            commands: 命令列表

        Returns:
            错误信息，如果验证通过则返回 None
        """
        if not commands:
            return "命令列表为空"

        seen_ids = set()
        for i, cmd in enumerate(commands):
            if not isinstance(cmd, dict):
                return f"第 {i+1} 个命令不是有效的对象"

            if "id" not in cmd:
                return f"第 {i+1} 个命令缺少 'id' 字段"

            if "command_name" not in cmd:
                return f"命令 '{cmd.get('id', i+1)}' 缺少 'command_name' 字段"

            cmd_id = cmd["id"]
            if cmd_id in seen_ids:
                return f"命令 ID '{cmd_id}' 重复"
            seen_ids.add(cmd_id)

            # 验证依赖引用的命令存在
            depends_on = cmd.get("depends_on", [])
            if not isinstance(depends_on, list):
                return f"命令 '{cmd_id}' 的 'depends_on' 应为数组"

        # 验证所有依赖引用都存在
        for cmd in commands:
            for dep_id in cmd.get("depends_on", []):
                if dep_id not in seen_ids:
                    return f"命令 '{cmd['id']}' 依赖的 '{dep_id}' 不存在"

        return None

    def _topological_sort(self, commands: List[Dict]) -> List[str]:
        """
        对命令进行拓扑排序

        Args:
            commands: 命令列表

        Returns:
            排序后的命令ID列表

        Raises:
            CyclicDependencyError: 存在循环依赖时抛出
        """
        # 构建邻接表和入度表
        graph = defaultdict(list)  # 依赖图：A -> [B, C] 表示 B, C 依赖 A
        in_degree = {}

        for cmd in commands:
            cmd_id = cmd["id"]
            in_degree[cmd_id] = 0

        for cmd in commands:
            cmd_id = cmd["id"]
            for dep_id in cmd.get("depends_on", []):
                graph[dep_id].append(cmd_id)
                in_degree[cmd_id] += 1

        # Kahn's algorithm
        queue = [cmd_id for cmd_id, degree in in_degree.items() if degree == 0]
        result = []

        while queue:
            # 按原始顺序处理入度为0的节点
            node = queue.pop(0)
            result.append(node)

            for neighbor in graph[node]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        if len(result) != len(commands):
            # 找出循环中的节点
            cycle_nodes = [cmd_id for cmd_id, degree in in_degree.items() if degree > 0]
            raise CyclicDependencyError(f"涉及命令: {cycle_nodes}")

        return result

    def _resolve_references(self, obj: Any) -> Any:
        """
        递归解析对象中的引用

        Args:
            obj: 要解析的对象（可以是字典、列表、字符串等）

        Returns:
            解析后的对象

        Raises:
            ReferenceResolutionError: 引用解析失败时抛出
        """
        if isinstance(obj, str):
            return self._resolve_string_references(obj)
        elif isinstance(obj, dict):
            return {k: self._resolve_references(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._resolve_references(item) for item in obj]
        else:
            return obj

    def _resolve_string_references(self, s: str) -> Any:
        """
        解析字符串中的引用

        支持格式：
        - ${cmd_id.handle} - 获取命令的主 Handle
        - ${cmd_id.data.field} - 获取 data 中的字段
        - ${cmd_id.createdEntityHandles[0]} - 获取数组元素

        Args:
            s: 包含引用的字符串

        Returns:
            解析后的值（如果整个字符串是一个引用，返回原始类型；否则返回字符串）
        """
        # 检查是否整个字符串就是一个引用
        match = self.REFERENCE_PATTERN.fullmatch(s)
        if match:
            # 整个字符串是引用，返回原始类型
            return self._get_reference_value(match.group(1))

        # 字符串中包含引用，进行替换（结果为字符串）
        def replace_ref(m):
            value = self._get_reference_value(m.group(1))
            return str(value) if value is not None else ""

        return self.REFERENCE_PATTERN.sub(replace_ref, s)

    def _get_reference_value(self, ref_path: str) -> Any:
        """
        获取引用路径对应的值

        Args:
            ref_path: 引用路径，如 "cmd_id.data.field" 或 "cmd_id.array[0]"

        Returns:
            引用的值

        Raises:
            ReferenceResolutionError: 引用无法解析时抛出
        """
        parts = ref_path.split(".", 1)
        if len(parts) < 1:
            raise ReferenceResolutionError(f"无效的引用格式: {ref_path}")

        cmd_id = parts[0]

        # 检查命令是否已执行
        if cmd_id not in self.results:
            raise ReferenceResolutionError(f"引用的命令 '{cmd_id}' 尚未执行")

        result = self.results[cmd_id]

        # 检查命令是否成功
        if not result.get("success"):
            raise ReferenceResolutionError(f"引用的命令 '{cmd_id}' 执行失败")

        # 如果只有命令ID，返回整个结果
        if len(parts) == 1:
            return result

        # 解析字段路径
        field_path = parts[1]
        return self._navigate_path(result, field_path, cmd_id)

    def _navigate_path(self, obj: Any, path: str, cmd_id: str) -> Any:
        """
        根据路径导航到对象中的值

        Args:
            obj: 起始对象
            path: 路径，如 "data.field" 或 "array[0].name"
            cmd_id: 命令ID（用于错误信息）

        Returns:
            路径对应的值
        """
        current = obj

        # 解析路径（支持 . 分隔和 [index] 数组访问）
        # 例如: "data.items[0].name" -> ["data", "items", "[0]", "name"]
        tokens = re.split(r'\.|\[', path)
        tokens = [t.rstrip(']') for t in tokens if t]

        for token in tokens:
            if current is None:
                raise ReferenceResolutionError(
                    f"命令 '{cmd_id}' 的路径 '{path}' 中间值为 null"
                )

            # 数组索引
            if token.isdigit():
                index = int(token)
                if not isinstance(current, list):
                    raise ReferenceResolutionError(
                        f"命令 '{cmd_id}' 的 '{token}' 不是数组"
                    )
                if index >= len(current):
                    raise ReferenceResolutionError(
                        f"命令 '{cmd_id}' 的数组索引 {index} 越界"
                    )
                current = current[index]
            # 字典键
            elif isinstance(current, dict):
                if token not in current:
                    raise ReferenceResolutionError(
                        f"命令 '{cmd_id}' 的结果中不存在字段 '{token}'"
                    )
                current = current[token]
            else:
                raise ReferenceResolutionError(
                    f"命令 '{cmd_id}' 的 '{token}' 不是有效的路径"
                )

        return current

    def _build_result(
        self,
        results_list: List[Dict],
        successful_count: int,
        failed_count: int,
        total_count: int,
        total_time_ms: int,
        failed_commands: List[Dict],
        detail_level: str
    ) -> Dict[str, Any]:
        """
        根据 detail_level 构建返回结果

        Args:
            results_list: 完整的执行结果列表
            successful_count: 成功数量
            failed_count: 失败数量
            total_count: 总数量
            total_time_ms: 总耗时（毫秒）
            failed_commands: 失败命令列表
            detail_level: 详细程度 ("summary", "handles", "full")

        Returns:
            根据详细程度精简后的结果字典
        """
        # 基础结果（所有模式都包含）
        base_result = {
            "success": failed_count == 0,
            "message": f"批量执行完成: {successful_count}/{total_count} 成功",
            "summary": {
                "total": total_count,
                "successful": successful_count,
                "failed": failed_count,
                "total_time_ms": total_time_ms
            }
        }

        if detail_level == "summary":
            # 最精简：只返回统计和失败信息
            if failed_commands:
                base_result["failed_commands"] = failed_commands
            return base_result

        elif detail_level == "handles":
            # 中等：返回句柄列表，不含完整 data
            base_result["handle_map"] = self.handle_map
            base_result["created_handles"] = [
                r["handle"] for r in results_list
                if r.get("success") and r.get("handle")
            ]
            if failed_commands:
                base_result["failed_commands"] = failed_commands
            return base_result

        else:  # "full"
            # 完整：返回所有数据（原有行为）
            base_result["results"] = results_list
            base_result["handle_map"] = self.handle_map
            base_result["failed_commands"] = failed_commands
            return base_result
