"""
CAD-Cowork-MCP: MCP server for controlling CAD software via COM interface.
"""

__version__ = "1.0.4"

import os
import json
import logging

logger = logging.getLogger('cad_mcp')


def load_config():
    """加载配置文件"""
    config_path = os.path.join(os.path.dirname(__file__), 'config.json')
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        logger.info("配置文件加载成功")
        return config
    except Exception as e:
        logger.error(f"加载配置文件失败: {str(e)}")
        return {
            "server": {
                "name": "CAD MCP Server",
                "version": "1.0.0",
            },
            "cad": {
                "type": "AUTOCAD",
                "startup_wait_time": 20,
                "command_delay": 0.5
            },
            "output": {
                "directory": "output",
                "default_filename": "cad_drawing.dwg"
            }
        }


config = load_config()

__all__ = ['config', '__version__']
