# CAD-Cowork-MCP

MCP server that lets AI Agents control AutoCAD / GstarCAD / ZWCAD via Windows COM interface.

通过 MCP（Model Context Protocol）让 AI Agent 控制 AutoCAD / 浩辰 CAD / 中望 CAD 的独立 MCP 服务器。

## Features

- 129 parameterized API commands covering drawing, querying, modification, batch operations, etc.
- Smart command routing with automatic execution method selection
- Batch execution engine with DAG dependency and cross-command parameter passing (`${cmd_id.field}`)
- GsLc process flow diagram domain-specific command disambiguation
- System prompt template guiding Agents to call commands correctly

## Prerequisites

- **Windows** (requires COM interface)
- **Python 3.10+**
- **AutoCAD / GstarCAD / ZWCAD** (installed and running)
- cad-cowork-cstool .NET plugin loaded in CAD

## Installation

### For Claude Code users

Add to your Claude Code MCP settings:

```json
{
  "mcpServers": {
    "cad-mcp": {
      "command": "uvx",
      "args": ["cad-cowork-mcp"]
    }
  }
}
```

### For other MCP clients

```bash
# Install globally
pip install cad-cowork-mcp

# Or run directly with uvx
uvx cad-cowork-mcp
```

## Configuration

### CAD type

Edit `config.json` (inside the installed package) or set before launching:

| CAD Software | Type Value |
|-------------|-----------|
| AutoCAD | `AUTOCAD` (default) |
| GstarCAD (浩辰 CAD) | `GCAD` |
| ZWCAD (中望 CAD) | `ZWCAD` |

## MCP Tools

| Tool | Description |
|------|-------------|
| `smart_cad_command` | **[Core]** Unified entry point for all CAD operations |
| `batch_execute` | Batch execute multiple commands with DAG dependencies |
| `execute_api_command` | Execute a single API command directly |
| `list_api_commands` | List all 129 available API commands |
| `get_api_command_info` | Get detailed parameter definition for a command |
| `gslc_route_command` | **[GsLc]** Process flow diagram command router |

## Usage Examples

```json
// Draw a line
{"command_name": "api_draw_line", "parameters": {"startPoint": [0,0,0], "endPoint": [100,100,0]}}

// Draw a circle
{"command_name": "api_draw_circle", "parameters": {"center": [100,100,0], "radius": 50}}

// Insert a block
{"command_name": "api_insert_block", "parameters": {"blockName": "valve", "insertionPoint": [100,100,0]}}

// Query by layer
{"command_name": "api_query_by_layer", "parameters": {"layerName": "Equipment"}}

// Move entity
{"command_name": "api_move_entity", "parameters": {"entityHandle": "27E2C0", "fromPoint": [0,0,0], "toPoint": [100,100,0]}}
```

## API Command Categories (129 total)

| Category | Count | Examples |
|----------|-------|----------|
| Drawing | 10 | `api_draw_line`, `api_draw_circle`, `api_create_polyline` |
| Query | 15 | `api_get_entity_info`, `api_query_by_layer` |
| Block | 8 | `api_insert_block`, `api_set_block_attributes` |
| Modify | 11 | `api_move_entity`, `api_delete_entity` |
| Batch | 11 | `api_batch_move`, `api_batch_copy` |
| Spatial | 8 | `api_calc_distance`, `api_calc_area` |
| Layer | 8 | `api_create_layer`, `api_list_layers` |
| Document | 4 | `api_save_document`, `api_get_document_info` |
| View | 5 | `api_zoom_extents`, `api_zoom_window` |
| Selection | 7 | `api_select_all`, `api_select_window` |
| Transaction | 3 | `api_transaction_begin`, `api_transaction_commit` |
| Process Flow (GsLc) | 39 | `api_gslc_query_frame_info`, `api_gslc_insert_equipment` |

## License

MIT
