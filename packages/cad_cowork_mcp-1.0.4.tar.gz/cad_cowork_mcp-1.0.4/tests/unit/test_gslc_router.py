"""
GsLc 路由器单元测试

验证 8 对容易混淆命令的路由准确性。
"""

import pytest

from cad_cowork_mcp.domains.gslc.router import GsLcRouter


@pytest.fixture
def router():
    """创建路由器实例"""
    return GsLcRouter()


class TestBatchGenerateVsAutoNumber:
    """规则1&2：批量生成位号 vs 自动编号"""

    def test_batch_generate_equip_tags(self, router):
        """批量生成位号 → insert_bottom_equip_tags"""
        result = router.route("批量生成设备位号")
        assert result.recommended["command"] == "api_gslc_insert_bottom_equip_tags"

        # insert_bottom_equip_tags 应该是最高分
        assert result.recommended["score"] >= 0.9

    def test_generate_tag_blocks(self, router):
        """生成位号 → insert_bottom_equip_tags"""
        result = router.route("生成设备位号块")
        assert result.recommended["command"] == "api_gslc_insert_bottom_equip_tags"

    def test_auto_number_equipment(self, router):
        """自动编号 → auto_number"""
        result = router.route("给设备自动编号")
        assert result.recommended["command"] == "api_gslc_auto_number"

    def test_renumber_entities(self, router):
        """重新编号 → auto_number"""
        result = router.route("重新编号管道")
        assert result.recommended["command"] == "api_gslc_auto_number"


class TestControlValveVsValve:
    """规则5&6：控制阀 vs 普通阀门"""

    def test_insert_control_valve(self, router):
        """插入控制阀 → insert_control_valve"""
        result = router.route("插入一个控制阀")
        assert result.recommended["command"] == "api_gslc_insert_control_valve"

    def test_insert_regulating_valve(self, router):
        """插入调节阀 → insert_control_valve"""
        result = router.route("插入调节阀")
        assert result.recommended["command"] == "api_gslc_insert_control_valve"

    def test_insert_switch_valve(self, router):
        """插入开关阀 → insert_control_valve"""
        result = router.route("添加开关阀")
        assert result.recommended["command"] == "api_gslc_insert_control_valve"

    def test_insert_normal_valve(self, router):
        """插入普通阀门 → insert_valve"""
        result = router.route("插入阀门")
        assert result.recommended["command"] == "api_gslc_insert_valve"

    def test_insert_ball_valve(self, router):
        """插入球阀 → insert_valve"""
        result = router.route("插入一个球阀")
        assert result.recommended["command"] == "api_gslc_insert_valve"

    def test_insert_gate_valve(self, router):
        """插入闸阀 → insert_valve"""
        result = router.route("添加闸阀")
        assert result.recommended["command"] == "api_gslc_insert_valve"


class TestJoinArrowVsOuterArrow:
    """规则3&4：接图箭头 vs 外管箭头"""

    def test_insert_join_arrow(self, router):
        """插入接图箭头 → insert_join_draw_arrow"""
        result = router.route("插入接图箭头")
        assert result.recommended["command"] == "api_gslc_insert_join_draw_arrow"

    def test_cross_drawing_connection(self, router):
        """跨图连接 → insert_join_draw_arrow"""
        result = router.route("添加跨图连接")
        assert result.recommended["command"] == "api_gslc_insert_join_draw_arrow"

    def test_insert_outer_pipe_arrow(self, router):
        """插入外管箭头 → insert_outer_pipe_arrow"""
        result = router.route("插入外管箭头")
        assert result.recommended["command"] == "api_gslc_insert_outer_pipe_arrow"

    def test_utility_arrow(self, router):
        """公用工程箭头 → insert_outer_pipe_arrow"""
        result = router.route("添加公用工程箭头")
        assert result.recommended["command"] == "api_gslc_insert_outer_pipe_arrow"

    def test_steam_arrow(self, router):
        """蒸汽来源 → insert_outer_pipe_arrow"""
        result = router.route("插入蒸汽外管箭头")
        assert result.recommended["command"] == "api_gslc_insert_outer_pipe_arrow"


class TestBrushVsSync:
    """规则7&8：刷新关联 vs 同步数据"""

    def test_brush_pipes(self, router):
        """刷新管道 → brush_batch_pipes"""
        result = router.route("刷新管道来去向")
        assert result.recommended["command"] == "api_gslc_brush_batch_pipes"

    def test_brush_pipe_association(self, router):
        """刷管道关联 → brush_batch_pipes"""
        result = router.route("刷管道关联")
        assert result.recommended["command"] == "api_gslc_brush_batch_pipes"

    def test_sync_pipe_from_excel(self, router):
        """从Excel同步管道 → sync_pipe_data"""
        result = router.route("从Excel同步管道数据")
        assert result.recommended["command"] == "api_gslc_sync_pipe_data"

    def test_import_pipe_data(self, router):
        """导入管道数据 → sync_pipe_data"""
        result = router.route("导入管道数据")
        assert result.recommended["command"] == "api_gslc_sync_pipe_data"

    def test_sync_from_json(self, router):
        """从JSON更新 → sync_pipe_data"""
        result = router.route("从JSON更新管道属性")
        assert result.recommended["command"] == "api_gslc_sync_pipe_data"


class TestSingleVsBatchInsert:
    """规则7：单个插入 vs 批量生成"""

    def test_insert_single_tag(self, router):
        """插入单个位号 → insert_equip_tag"""
        result = router.route("在指定位置插入单个位号")
        assert result.recommended["command"] == "api_gslc_insert_equip_tag"

    def test_insert_equipment(self, router):
        """插入设备 → insert_equipment"""
        result = router.route("插入一个设备")
        assert result.recommended["command"] == "api_gslc_insert_equipment"


class TestQueryCommands:
    """查询类命令测试"""

    def test_query_frame_info(self, router):
        """查询图框 → query_frame_info"""
        result = router.route("查询图框信息")
        assert result.recommended["command"] == "api_gslc_query_frame_info"

    def test_query_equipment(self, router):
        """查询设备 → query_equipment_in_frame"""
        result = router.route("查询设备列表")
        assert result.recommended["command"] == "api_gslc_query_equipment_in_frame"

    def test_query_instruments(self, router):
        """查询仪表 → query_instrument_in_frame"""
        result = router.route("列出所有仪表")
        assert result.recommended["command"] == "api_gslc_query_instrument_in_frame"

    def test_query_pipes(self, router):
        """查询管道 → query_pipe_in_frame"""
        result = router.route("有哪些管道")
        assert result.recommended["command"] == "api_gslc_query_pipe_in_frame"


class TestExportCommands:
    """导出类命令测试"""

    def test_export_all_data(self, router):
        """全量导出 → export_all_data"""
        result = router.route("导出所有数据")
        assert result.recommended["command"] == "api_gslc_export_all_data"

    def test_export_frame_data(self, router):
        """导出图框 → export_frame_data"""
        result = router.route("导出图框数据")
        assert result.recommended["command"] == "api_gslc_export_frame_data"

    def test_export_equipment(self, router):
        """导出设备 → export_all_data（单独导出命令已整合）"""
        result = router.route("导出设备清单")
        assert result.recommended["command"] == "api_gslc_export_all_data"


class TestDisambiguationHints:
    """消歧提示测试"""

    def test_has_disambiguation_hint_for_similar_scores(self, router):
        """当 top 2 分数接近时应有消歧提示"""
        # 使用可能产生相近分数的输入
        result = router.route("生成")
        # 如果 top 2 分数差距小于 0.3，应该有消歧提示
        if len(result.candidates) >= 2:
            score_diff = result.candidates[0].score - result.candidates[1].score
            if score_diff < 0.3:
                # 可能有消歧提示（取决于具体的候选组合）
                pass  # 消歧提示是可选的


class TestRoutingResult:
    """路由结果结构测试"""

    def test_result_has_required_fields(self, router):
        """结果应包含所有必需字段"""
        result = router.route("批量生成设备位号")

        assert result.domain == "gslc"
        assert result.intent_category is not None
        assert result.intent_confidence >= 0
        assert result.recommended is not None
        assert len(result.candidates) <= 5  # 最多返回 5 个候选

    def test_recommended_command_format(self, router):
        """推荐命令应包含必要信息"""
        result = router.route("插入设备")

        assert "command" in result.recommended
        assert "score" in result.recommended
        assert "reason" in result.recommended
        assert result.recommended["command"].startswith("api_gslc_")

    def test_candidates_have_why_not(self, router):
        """被负向规则惩罚的候选应有 why_not"""
        result = router.route("批量生成设备位号")

        # 查找被惩罚的 auto_number
        auto_number = next(
            (c for c in result.candidates if c.command == "api_gslc_auto_number"),
            None
        )
        if auto_number and auto_number.score < 0.5:
            assert auto_number.why_not is not None
