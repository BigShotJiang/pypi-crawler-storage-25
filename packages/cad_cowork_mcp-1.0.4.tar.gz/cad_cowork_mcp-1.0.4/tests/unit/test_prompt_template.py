"""
PROMPT_TEMPLATE 内容验证测试

验证:
- 核心工具说明
- API 命令参考完整性
"""
import pytest


class TestPromptTemplateContent:
    """PROMPT_TEMPLATE 内容测试"""

    def test_contains_core_tool_section(self, prompt_template):
        """验证包含核心工具说明"""
        assert "smart_cad_command" in prompt_template
        assert "核心工具" in prompt_template or "必须使用" in prompt_template

    def test_api_draw_line_exists(self, prompt_template):
        """验证包含 api_draw_line 命令"""
        assert "api_draw_line" in prompt_template

    def test_api_draw_circle_exists(self, prompt_template):
        """验证包含 api_draw_circle 命令"""
        assert "api_draw_circle" in prompt_template

    def test_api_create_arc_exists(self, prompt_template):
        """验证包含 api_create_arc 命令"""
        assert "api_create_arc" in prompt_template

    def test_api_draw_rectangle_exists(self, prompt_template):
        """验证包含 api_draw_rectangle 命令"""
        assert "api_draw_rectangle" in prompt_template

    def test_api_create_polyline_exists(self, prompt_template):
        """验证包含 api_create_polyline 命令"""
        assert "api_create_polyline" in prompt_template

    def test_api_create_text_exists(self, prompt_template):
        """验证包含 api_create_text 命令"""
        assert "api_create_text" in prompt_template

    def test_api_create_hatch_exists(self, prompt_template):
        """验证包含 api_create_hatch 命令"""
        assert "api_create_hatch" in prompt_template

    def test_api_create_dimension_exists(self, prompt_template):
        """验证包含 api_create_dimension 命令"""
        assert "api_create_dimension" in prompt_template

    def test_api_save_document_exists(self, prompt_template):
        """验证包含 api_save_document 命令"""
        assert "api_save_document" in prompt_template


class TestPromptTemplateAPIReference:
    """PROMPT_TEMPLATE API 命令参考测试"""

    def test_contains_api_command_reference(self, prompt_template):
        """验证包含 API 命令清单章节"""
        assert "API 命令清单" in prompt_template

    def test_contains_drawing_commands(self, prompt_template):
        """验证包含绘图命令"""
        assert "绘图-基础" in prompt_template or "绘图" in prompt_template

    def test_contains_query_commands(self, prompt_template):
        """验证包含查询命令"""
        assert "查询" in prompt_template

    def test_contains_block_commands(self, prompt_template):
        """验证包含块操作命令"""
        assert "块操作" in prompt_template

    def test_contains_modify_commands(self, prompt_template):
        """验证包含修改命令"""
        assert "实体修改" in prompt_template or "修改" in prompt_template

    def test_contains_batch_commands(self, prompt_template):
        """验证包含批量操作命令"""
        assert "批量操作" in prompt_template or "批量" in prompt_template

    def test_contains_layer_commands(self, prompt_template):
        """验证包含图层命令"""
        assert "图层" in prompt_template

    def test_contains_document_commands(self, prompt_template):
        """验证包含文档命令"""
        assert "文档" in prompt_template

    def test_contains_view_commands(self, prompt_template):
        """验证包含视图命令"""
        assert "视图" in prompt_template

    def test_contains_selection_commands(self, prompt_template):
        """验证包含选择集命令"""
        assert "选择" in prompt_template


class TestPromptTemplateExamples:
    """PROMPT_TEMPLATE 示例测试"""

    def test_contains_json_examples(self, prompt_template):
        """验证包含 JSON 调用示例"""
        assert "command_name" in prompt_template
        assert "parameters" in prompt_template

    def test_contains_draw_line_example(self, prompt_template):
        """验证包含绘制直线示例"""
        assert "startPoint" in prompt_template or "start_point" in prompt_template

    def test_contains_draw_circle_example(self, prompt_template):
        """验证包含绘制圆示例"""
        assert "center" in prompt_template
        assert "radius" in prompt_template
