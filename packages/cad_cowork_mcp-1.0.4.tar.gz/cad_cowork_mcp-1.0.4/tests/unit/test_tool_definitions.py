"""
工具定义验证测试

验证:
- 核心工具标记正确
- 工具参数定义完整
"""
import pytest


class TestCoreToolDefinition:
    """核心工具定义测试"""

    def test_smart_cad_command_is_core(self, prompt_template):
        """验证 smart_cad_command 被标记为核心工具"""
        # 检查核心标记
        assert "smart_cad_command" in prompt_template
        # 检查是否有推荐使用的说明
        assert "必须使用" in prompt_template or "核心" in prompt_template or "推荐" in prompt_template

    def test_batch_execute_mentioned(self, prompt_template):
        """验证 batch_execute 工具被提及"""
        assert "batch_execute" in prompt_template

    def test_query_api_commands_mentioned(self, prompt_template):
        """验证 query_api_commands 工具被提及"""
        assert "query_api_commands" in prompt_template

    def test_gslc_route_command_mentioned(self, prompt_template):
        """验证 gslc_route_command 工具被提及"""
        assert "gslc_route_command" in prompt_template


class TestToolCategories:
    """工具分类测试"""

    def test_four_tools_listed(self, prompt_template):
        """验证 4 个工具都在提示词中列出"""
        assert "smart_cad_command" in prompt_template
        assert "batch_execute" in prompt_template
        assert "query_api_commands" in prompt_template
        assert "gslc_route_command" in prompt_template


class TestGsLcCommands:
    """GsLc 业务命令定义测试（使用 API Manifest）"""

    def test_gslc_category_exists(self, api_manifest):
        """验证工艺流程图类别存在"""
        category_names = [c.get("name") for c in api_manifest.get("categories", [])]
        assert "工艺流程图" in category_names, "未找到工艺流程图类别"

    def test_gslc_commands_not_empty(self, api_manifest):
        """验证 GsLc 命令不为空"""
        gslc_commands = []
        for category in api_manifest.get("categories", []):
            if category.get("name") == "工艺流程图":
                gslc_commands = category.get("commands", [])
                break
        assert len(gslc_commands) > 0, "工艺流程图命令为空"

    def test_gslc_commands_have_descriptions(self, api_manifest):
        """验证 GsLc 命令都有描述"""
        for category in api_manifest.get("categories", []):
            if category.get("name") == "工艺流程图":
                for cmd in category.get("commands", []):
                    assert cmd.get("description"), f"命令 {cmd.get('name')} 缺少描述"

    def test_insert_commands_exist(self, api_manifest):
        """验证插入相关命令存在"""
        gslc_commands = []
        for category in api_manifest.get("categories", []):
            if category.get("name") == "工艺流程图":
                gslc_commands = [c.get("name") for c in category.get("commands", [])]
                break
        insert_commands = [c for c in gslc_commands if "insert" in c]
        assert len(insert_commands) > 0, "未找到 GsLc 插入命令"

    def test_query_commands_exist(self, api_manifest):
        """验证查询相关命令存在"""
        gslc_commands = []
        for category in api_manifest.get("categories", []):
            if category.get("name") == "工艺流程图":
                gslc_commands = [c.get("name") for c in category.get("commands", [])]
                break
        query_commands = [c for c in gslc_commands if "query" in c]
        assert len(query_commands) > 0, "未找到 GsLc 查询命令"
