"""
API 命令清单验证测试

验证:
- 清单结构完整性
- 命令分类正确性
- 参数定义完整性
"""
import pytest
from tests.conftest import get_command_from_manifest, get_commands_by_category


class TestManifestStructure:
    """清单结构测试"""

    def test_manifest_has_version(self, api_manifest):
        """验证清单有版本号"""
        assert "version" in api_manifest
        assert api_manifest["version"]

    def test_manifest_has_total_commands(self, api_manifest):
        """验证清单有命令总数"""
        assert "totalCommands" in api_manifest
        assert api_manifest["totalCommands"] > 0

    def test_manifest_has_categories(self, api_manifest):
        """验证清单有分类"""
        assert "categories" in api_manifest
        assert len(api_manifest["categories"]) > 0

    def test_total_commands_matches_actual(self, api_manifest):
        """验证命令总数与实际命令数匹配"""
        actual_count = sum(
            len(cat.get("commands", []))
            for cat in api_manifest.get("categories", [])
        )
        assert actual_count == api_manifest["totalCommands"], \
            f"声明的命令数 {api_manifest['totalCommands']} 与实际 {actual_count} 不匹配"


class TestManifestCategories:
    """清单分类测试"""

    # 当前 manifest 实际分类（根据 api_commands_manifest.json 更新）
    EXPECTED_CATEGORIES = [
        ("绘图-基础", "drawing", 10),
        ("查询", "query", 15),
        ("块操作", "block", 9),
        ("修改", "modify", 11),
        ("批量操作", "batch", 11),
        ("空间计算", "spatial", 8),
        ("图层", "layer", 7),
        ("图层管理", "layer_mgmt", 1),
        ("文档", "document", 4),
        ("视图", "view", 5),
        ("选择集", "selection", 7),
        ("工艺流程图", "gslc", 35),
        ("事务控制", "transaction", 3),
    ]

    def test_all_categories_exist(self, api_manifest):
        """验证所有预期分类存在"""
        category_names = [cat["name"] for cat in api_manifest["categories"]]
        for name, name_en, count in self.EXPECTED_CATEGORIES:
            assert name in category_names, f"缺少分类: {name}"

    @pytest.mark.parametrize("name,name_en,expected_count", EXPECTED_CATEGORIES)
    def test_category_command_count(self, api_manifest, name, name_en, expected_count):
        """验证每个分类的命令数量"""
        commands = get_commands_by_category(api_manifest, name)
        assert len(commands) == expected_count, \
            f"分类 {name} 命令数量应为 {expected_count}，实际为 {len(commands)}"

    def test_category_has_required_fields(self, api_manifest):
        """验证每个分类有必需字段"""
        for category in api_manifest["categories"]:
            assert "name" in category, "分类缺少 name"
            assert "nameEn" in category, "分类缺少 nameEn"
            assert "count" in category, "分类缺少 count"
            assert "commands" in category, "分类缺少 commands"


class TestCommandDefinitions:
    """命令定义测试"""

    def test_command_has_required_fields(self, api_manifest):
        """验证每个命令有必需字段"""
        for category in api_manifest["categories"]:
            for cmd in category.get("commands", []):
                assert "name" in cmd, f"命令缺少 name: {cmd}"
                assert "displayName" in cmd, f"命令 {cmd.get('name')} 缺少 displayName"
                assert "description" in cmd, f"命令 {cmd.get('name')} 缺少 description"
                assert "parameters" in cmd, f"命令 {cmd.get('name')} 缺少 parameters"

    def test_command_names_are_unique(self, api_manifest):
        """验证命令名称唯一"""
        all_names = []
        for category in api_manifest["categories"]:
            for cmd in category.get("commands", []):
                all_names.append(cmd["name"])

        assert len(all_names) == len(set(all_names)), "存在重复的命令名称"

    def test_command_names_follow_convention(self, api_manifest):
        """验证命令名称遵循命名规范 (api_xxx)"""
        for category in api_manifest["categories"]:
            for cmd in category.get("commands", []):
                name = cmd["name"]
                assert name.startswith("api_"), f"命令 {name} 不符合 api_ 前缀规范"


class TestParameterDefinitions:
    """参数定义测试"""

    def test_parameter_has_required_fields(self, api_manifest):
        """验证每个参数有必需字段"""
        for category in api_manifest["categories"]:
            for cmd in category.get("commands", []):
                for param in cmd.get("parameters", []):
                    assert "name" in param, f"命令 {cmd['name']} 的参数缺少 name"
                    assert "type" in param, f"命令 {cmd['name']} 的参数 {param.get('name')} 缺少 type"
                    assert "required" in param, f"命令 {cmd['name']} 的参数 {param.get('name')} 缺少 required"
                    assert "description" in param, f"命令 {cmd['name']} 的参数 {param.get('name')} 缺少 description"

    def test_parameter_types_are_valid(self, api_manifest):
        """验证参数类型有效"""
        valid_types = {
            "String", "StringArray", "Integer", "Double", "Boolean",
            "Point3D", "Point2D", "PointArray",
            "EntityHandle", "HandleArray", "BlockName", "LayerName",
            "Json", "FilePath"
        }

        for category in api_manifest["categories"]:
            for cmd in category.get("commands", []):
                for param in cmd.get("parameters", []):
                    param_type = param.get("type")
                    assert param_type in valid_types, \
                        f"命令 {cmd['name']} 的参数 {param['name']} 类型 {param_type} 无效"


class TestDrawingCommands:
    """绘图命令特定测试"""

    DRAWING_COMMANDS = [
        "api_draw_line",
        "api_draw_circle",
        "api_draw_rectangle",
        "api_create_polyline",
        "api_create_arc",
        "api_create_text",
        "api_create_mtext",
        "api_create_dimension",
        "api_create_hatch",
        "api_create_leader",
    ]

    @pytest.mark.parametrize("command_name", DRAWING_COMMANDS)
    def test_drawing_command_exists(self, api_manifest, command_name):
        """验证绘图命令存在"""
        cmd = get_command_from_manifest(api_manifest, command_name)
        assert cmd is not None, f"绘图命令 {command_name} 不存在"

    def test_draw_line_has_points(self, api_manifest):
        """验证 api_draw_line 有坐标参数"""
        cmd = get_command_from_manifest(api_manifest, "api_draw_line")
        param_names = [p["name"] for p in cmd["parameters"]]
        assert "startPoint" in param_names
        assert "endPoint" in param_names

    def test_draw_circle_has_center_radius(self, api_manifest):
        """验证 api_draw_circle 有圆心和半径参数"""
        cmd = get_command_from_manifest(api_manifest, "api_draw_circle")
        param_names = [p["name"] for p in cmd["parameters"]]
        assert "center" in param_names
        assert "radius" in param_names
