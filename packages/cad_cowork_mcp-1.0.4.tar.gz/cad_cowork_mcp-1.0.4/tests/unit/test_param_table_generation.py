"""
单元测试：参数表生成

测试 generate_param_table.py 的核心类：
- MutualExclusionDetector: 互斥参数检测
- DefaultValueFormatter: 默认值格式化
- CategoryMapper: 类别映射
- ParameterTableGenerator: 表格生成（集成测试）
"""

import pytest
import sys
import json
from pathlib import Path
from typing import List, Dict

# 添加脚本目录到路径
scripts_dir = Path(__file__).parent.parent.parent / "scripts"
sys.path.insert(0, str(scripts_dir))


from shared.manifest_parser import Parameter, CommandParams
from generate_param_table import (
    MutualExclusionDetector,
    DefaultValueFormatter,
    CategoryMapper,
    ParameterTableGenerator,
    TableRow,
    TableSection,
)


# ============================================================================
# 辅助函数
# ============================================================================

def create_mock_param(**kwargs) -> Parameter:
    """创建模拟 Parameter"""
    defaults = {
        'name': 'testParam',
        'required': False,
        'default_value': None,
        'aliases': [],
        'type': None,
        'description': None,
    }
    defaults.update(kwargs)
    return Parameter(**defaults)


def create_mock_command(required: List[str] = None, optional: List[str] = None) -> CommandParams:
    """创建模拟 CommandParams"""
    required = required or []
    optional = optional or []

    params = {}
    for param_name in required:
        params[param_name] = create_mock_param(name=param_name, required=True)
    for param_name in optional:
        params[param_name] = create_mock_param(name=param_name, required=False)

    return CommandParams(
        command_name='test_command',
        required=required,
        optional=optional,
        params=params
    )


# ============================================================================
# 测试类
# ============================================================================

class TestMutualExclusionDetector:
    """互斥参数检测器测试"""

    def test_detect_singular_plural(self):
        """测试单复数检测"""
        detector = MutualExclusionDetector()
        command = create_mock_command(
            optional=['entityHandle', 'entityHandles', 'layerName']
        )

        groups = detector.detect(command, 'test_command')

        # 应该检测到 entityHandle/entityHandles 互斥
        assert len(groups) >= 1
        assert set(groups[0].params) == {'entityHandle', 'entityHandles'}

    def test_detect_known_pattern_create_hatch(self):
        """测试已知模式：api_create_hatch"""
        detector = MutualExclusionDetector()
        command = create_mock_command(
            optional=['boundaryHandles', 'points']
        )

        groups = detector.detect(command, 'api_create_hatch')

        # 应该检测到 boundaryHandles/points 互斥
        assert len(groups) == 1
        assert set(groups[0].params) == {'boundaryHandles', 'points'}
        # 应该推荐 boundaryHandles
        assert groups[0].recommended == 'boundaryHandles'

    def test_detect_known_pattern_move_entity(self):
        """测试已知模式：api_move_entity"""
        detector = MutualExclusionDetector()
        command = create_mock_command(
            required=['fromPoint', 'toPoint'],
            optional=['entityHandle', 'entityHandles']
        )

        groups = detector.detect(command, 'api_move_entity')

        # 应该检测到 entityHandle/entityHandles 互斥
        assert len(groups) == 1
        assert set(groups[0].params) == {'entityHandle', 'entityHandles'}

    def test_detect_multiple_groups(self):
        """测试多组互斥参数"""
        detector = MutualExclusionDetector()
        command = create_mock_command(
            optional=[
                'insertions', 'blockName', 'insertionPoints',
                'entityHandle', 'entityHandles'
            ]
        )

        groups = detector.detect(command, 'api_batch_insert_blocks')

        # 应该检测到多组
        assert len(groups) >= 2

    def test_no_mutex_detected(self):
        """测试无互斥参数"""
        detector = MutualExclusionDetector()
        command = create_mock_command(
            required=['layerName'],
            optional=['color', 'lineType']
        )

        groups = detector.detect(command, 'api_create_layer')

        # 应该没有互斥组
        assert len(groups) == 0


class TestDefaultValueFormatter:
    """默认值格式化器测试"""

    def test_should_show_boolean_default(self):
        """布尔型必须显示默认值"""
        param = create_mock_param(
            name='createIfNotExist',
            default_value=True,
            type='Boolean'
        )
        assert DefaultValueFormatter.should_show_default(param) is True

    def test_should_hide_zero_default(self):
        """0 值不显示默认值"""
        param = create_mock_param(
            name='colorIndex',
            default_value=0,
            type='Integer'
        )
        assert DefaultValueFormatter.should_show_default(param) is False

    def test_should_hide_null_default(self):
        """null 值不显示默认值"""
        param = create_mock_param(
            name='description',
            default_value=None,
            type='String'
        )
        assert DefaultValueFormatter.should_show_default(param) is False

    def test_should_show_non_zero_number(self):
        """非零数值显示默认值"""
        param = create_mock_param(
            name='colorIndex',
            default_value=256,
            type='Integer'
        )
        assert DefaultValueFormatter.should_show_default(param) is True

    def test_should_show_enum_default(self):
        """枚举型（字符串）显示默认值"""
        param = create_mock_param(
            name='dimType',
            default_value='linear',
            type='String'
        )
        assert DefaultValueFormatter.should_show_default(param) is True

    def test_format_boolean_default(self):
        """布尔型格式化"""
        param = create_mock_param(
            name='createIfNotExist',
            default_value=True
        )
        formatted = DefaultValueFormatter.format_default(param)
        assert formatted == '默认true'

    def test_format_enum_default(self):
        """枚举型格式化"""
        param = create_mock_param(
            name='dimType',
            default_value='linear'
        )
        formatted = DefaultValueFormatter.format_default(param)
        assert formatted == '默认linear'

    def test_format_number_default(self):
        """数值型格式化"""
        param = create_mock_param(
            name='scale',
            default_value=1.0
        )
        formatted = DefaultValueFormatter.format_default(param)
        assert formatted == '默认1.0'


class TestCategoryMapper:
    """类别映射器测试"""

    def test_map_drawing_category(self):
        """绘图类别映射"""
        assert CategoryMapper.map_category('drawing') == '绘图类'

    def test_map_query_category(self):
        """查询类别映射"""
        assert CategoryMapper.map_category('query') == '查询类'

    def test_map_chinese_layer_category(self):
        """中文图层类别映射"""
        assert CategoryMapper.map_category('图层') == '图层类'

    def test_map_chinese_document_category(self):
        """中文文档类别映射"""
        assert CategoryMapper.map_category('文档') == '文档管理类'

    def test_map_gslc_returns_none(self):
        """GsLc 不映射到速查表"""
        assert CategoryMapper.map_category('gslc') is None

    def test_map_unknown_returns_none(self):
        """未知类别返回 None"""
        assert CategoryMapper.map_category('unknown') is None


class TestParameterTableGenerator:
    """参数表生成器集成测试"""

    @pytest.fixture
    def generator(self, tmp_path):
        """创建生成器实例（使用真实 manifest）"""
        # 使用项目中的实际 manifest
        manifest_path = Path(__file__).parent.parent.parent / 'src' / 'cad_cowork_mcp' / 'api_commands_manifest.json'
        if not manifest_path.exists():
            pytest.skip("Manifest file not found")

        return ParameterTableGenerator(manifest_path)

    def test_generate_all_sections(self, generator):
        """测试生成所有分节"""
        sections = generator.generate()

        # 应该生成多个分节（非 GsLc）
        assert len(sections) > 0
        assert '绘图类' in sections
        assert '查询类' in sections
        assert '修改类' in sections

    def test_generate_drawing_section(self, generator):
        """测试生成绘图类分节"""
        sections = generator.generate()

        assert '绘图类' in sections
        drawing_section = sections['绘图类']

        # 检查命令数量
        assert len(drawing_section.commands) > 0

        # 检查 api_draw_circle（如果存在）
        circle_cmd = next(
            (c for c in drawing_section.commands if c.command_name == 'api_draw_circle'),
            None
        )
        if circle_cmd:
            assert 'center' in circle_cmd.required_params
            assert 'radius' in circle_cmd.required_params

    def test_generate_modification_section_with_mutex(self, generator):
        """测试修改类含互斥参数"""
        sections = generator.generate()

        if '修改类' not in sections:
            pytest.skip("Modification section not found")

        # 查找 api_move_entity
        move_cmd = next(
            (c for c in sections['修改类'].commands if c.command_name == 'api_move_entity'),
            None
        )

        if move_cmd:
            # 应检测到 entityHandle/entityHandles 互斥
            assert len(move_cmd.mutual_exclusive_groups) > 0

    def test_default_value_formatting(self, generator):
        """测试默认值格式化"""
        sections = generator.generate()

        # 检查所有命令的可选参数
        for section in sections.values():
            for cmd in section.commands:
                for param_name, default_str in cmd.optional_params:
                    # 如果有默认值标注，应该符合格式
                    if default_str:
                        assert default_str.startswith('默认')


class TestTableRowAndSection:
    """测试数据结构"""

    def test_table_row_creation(self):
        """测试 TableRow 创建"""
        row = TableRow(
            command_name='api_test',
            required_params=['param1'],
            optional_params=[('param2', '默认value')],
            mutual_exclusive_groups=[]
        )

        assert row.command_name == 'api_test'
        assert len(row.required_params) == 1
        assert len(row.optional_params) == 1
        assert row.optional_params[0] == ('param2', '默认value')

    def test_table_section_creation(self):
        """测试 TableSection 创建"""
        section = TableSection(
            section_name='测试类',
            commands=[],
            notes=[]
        )

        assert section.section_name == '测试类'
        assert len(section.commands) == 0
        assert len(section.notes) == 0


# ============================================================================
# 运行测试
# ============================================================================

if __name__ == '__main__':
    pytest.main([__file__, '-v'])
