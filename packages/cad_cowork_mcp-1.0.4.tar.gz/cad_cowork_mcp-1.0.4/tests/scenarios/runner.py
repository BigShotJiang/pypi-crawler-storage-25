"""
场景测试执行引擎

提供:
- YAML 场景文件加载
- 变量引用解析
- 命令执行
- 断言检查
- 调试文件输出（request.json, latest.json）
"""
import os
import re
import json
import yaml
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field


@dataclass
class ScenarioContext:
    """
    场景测试上下文

    存储跨场景共享的数据，如 entity handles
    """
    handles: Dict[str, str] = field(default_factory=dict)
    results: Dict[str, Dict] = field(default_factory=dict)
    last_handle: Optional[str] = None
    last_result: Optional[Dict] = None

    def clear(self):
        """清空上下文"""
        self.handles.clear()
        self.results.clear()
        self.last_handle = None
        self.last_result = None

    def save_handle(self, name: str, handle: str):
        """保存 handle"""
        self.handles[name] = handle
        self.last_handle = handle

    def save_result(self, name: str, result: Dict):
        """保存完整结果"""
        self.results[name] = result
        self.last_result = result

    def get_handle(self, name: str) -> Optional[str]:
        """获取 handle"""
        if name == "_last_handle":
            return self.last_handle
        return self.handles.get(name)

    def has_dependency(self, dep: str) -> bool:
        """检查依赖是否存在"""
        return dep in self.handles


class ScenarioRunner:
    """
    场景测试执行器

    负责加载 YAML、解析变量、执行命令、检查断言
    """

    # 变量引用正则：${variable_name}
    VAR_PATTERN = re.compile(r'\$\{([^}]+)\}')

    def __init__(self, cad_service, context: Optional[ScenarioContext] = None):
        """
        初始化执行器

        Args:
            cad_service: CAD 服务实例
            context: 场景上下文，不传则创建新的
        """
        self.cad = cad_service
        self.ctx = context or ScenarioContext()

    @staticmethod
    def load_yaml(yaml_path: Path) -> Dict:
        """
        加载 YAML 场景文件

        Args:
            yaml_path: YAML 文件路径

        Returns:
            解析后的字典
        """
        with open(yaml_path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)

    def resolve_value(self, value: Any) -> Any:
        """
        解析单个值中的变量引用

        Args:
            value: 待解析的值

        Returns:
            解析后的值
        """
        if isinstance(value, str):
            # 检查是否是完整的变量引用 "${var}"
            match = self.VAR_PATTERN.fullmatch(value)
            if match:
                var_name = match.group(1)
                # 支持特殊环境变量
                if var_name == 'TEMP':
                    return os.environ.get('TEMP') or os.environ.get('TMP') or '/tmp'
                return self.ctx.get_handle(var_name)

            # 检查是否包含变量引用（字符串插值）
            def replace_var(m):
                var_name = m.group(1)
                # 支持特殊环境变量
                if var_name == 'TEMP':
                    return os.environ.get('TEMP') or os.environ.get('TMP') or '/tmp'
                handle = self.ctx.get_handle(var_name)
                return handle if handle else m.group(0)

            return self.VAR_PATTERN.sub(replace_var, value)

        elif isinstance(value, list):
            return [self.resolve_value(item) for item in value]

        elif isinstance(value, dict):
            return {k: self.resolve_value(v) for k, v in value.items()}

        return value

    def resolve_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        解析参数字典中的所有变量引用

        Args:
            params: 原始参数字典

        Returns:
            解析后的参数字典
        """
        return self.resolve_value(params)

    def check_dependencies(self, scenario: Dict) -> Tuple[bool, List[str]]:
        """
        检查场景依赖是否满足

        Args:
            scenario: 场景定义

        Returns:
            (是否满足, 缺失的依赖列表)
        """
        depends_on = scenario.get("depends_on", [])
        missing = [dep for dep in depends_on if not self.ctx.has_dependency(dep)]
        return len(missing) == 0, missing

    def execute_command(
        self,
        command_name: str,
        params: Dict[str, Any],
        timeout: float = 10.0
    ) -> Dict[str, Any]:
        """
        执行 CAD API 命令

        Args:
            command_name: 命令名称
            params: 命令参数
            timeout: 超时时间

        Returns:
            命令执行结果
        """
        try:
            result = self.cad.controller.smart_cad_command(
                command_name=command_name,
                parameters=params,
                timeout=timeout
            )
            return result
        except Exception as e:
            return {
                "success": False,
                "error": str(e),
                "exception": type(e).__name__
            }

    def run_scenario(self, scenario: Dict) -> Dict[str, Any]:
        """
        执行单个场景

        Args:
            scenario: 场景定义字典

        Returns:
            执行结果，包含 success, data, error 等字段
        """
        command_name = scenario["command"]
        raw_params = scenario.get("params", {})
        timeout = scenario.get("timeout", 10.0)

        # 解析变量引用
        params = self.resolve_params(raw_params)

        # 打印执行信息
        print(f"\n  [SCENARIO] 执行: {scenario.get('name', command_name)}")
        print(f"  [SCENARIO] 命令: {command_name}")
        print(f"  [SCENARIO] 参数: {params}")

        # 执行命令
        result = self.execute_command(command_name, params, timeout)

        # 记录结果
        success = result.get("success", False)
        print(f"  [SCENARIO] 结果: {'成功' if success else '失败'}")
        if not success:
            print(f"  [SCENARIO] 错误: {result.get('message', result.get('error', '未知'))}")

        # 打印调试文件内容
        self._print_debug_files()

        # 保存 handle 和结果
        if success and scenario.get("save_as"):
            data = result.get("data", {})
            # 优先查找 entityHandle，其次查找其他常见的 handle 字段
            handle = (
                data.get("entityHandle")
                or data.get("blockDefinitionHandle")
                or data.get("layerId")
                or data.get("handle")
            )
            if handle:
                self.ctx.save_handle(scenario["save_as"], handle)
                print(f"  [SCENARIO] 保存: {scenario['save_as']} = {handle}")

        self.ctx.last_result = result

        return result

    def _print_debug_files(self):
        """
        打印调试文件内容（request.json 和 latest.json）

        用于调试 API 命令执行问题
        """
        # 获取 TEMP 目录
        temp_dir = os.environ.get('TEMP') or os.environ.get('TMP') or '/tmp'
        cad_cowork_dir = Path(temp_dir) / 'CAD-Cowork'

        # 打印 request.json
        request_file = cad_cowork_dir / 'request.json'
        if request_file.exists():
            try:
                with open(request_file, 'r', encoding='utf-8') as f:
                    request_data = json.load(f)
                print(f"  [DEBUG] request.json:")
                print(f"          {json.dumps(request_data, ensure_ascii=False, indent=2)}")
            except Exception as e:
                print(f"  [DEBUG] 读取 request.json 失败: {e}")
        else:
            print(f"  [DEBUG] request.json 不存在: {request_file}")

        # 打印 latest.json
        result_file = cad_cowork_dir / 'results' / 'latest.json'
        if result_file.exists():
            try:
                # 使用 utf-8-sig 处理可能的 BOM
                with open(result_file, 'r', encoding='utf-8-sig') as f:
                    result_data = json.load(f)
                print(f"  [DEBUG] latest.json:")
                print(f"          {json.dumps(result_data, ensure_ascii=False, indent=2)}")
            except Exception as e:
                print(f"  [DEBUG] 读取 latest.json 失败: {e}")
        else:
            print(f"  [DEBUG] latest.json 不存在: {result_file}")

    def check_expects(self, result: Dict, expects: Dict) -> List[str]:
        """
        检查结果是否符合预期

        Args:
            result: 命令执行结果
            expects: 预期断言

        Returns:
            错误信息列表，空表示全部通过
        """
        errors = []

        # 检查 success
        if "success" in expects:
            expected_success = expects["success"]
            actual_success = result.get("success", False)
            if actual_success != expected_success:
                errors.append(
                    f"success: 预期 {expected_success}，实际 {actual_success}"
                )

        # 检查错误信息
        if "error_contains" in expects:
            error_msg = result.get("message", "") or result.get("error", "")
            if expects["error_contains"] not in error_msg:
                errors.append(
                    f"error_contains: 预期包含 '{expects['error_contains']}'，"
                    f"实际 '{error_msg}'"
                )

        # 检查数据字段
        if "data" in expects:
            data = result.get("data", {})
            data_expects = expects["data"]

            # 检查必须存在的字段
            for field_name in data_expects.get("has_fields", []):
                if field_name not in data:
                    errors.append(f"data 缺少字段: {field_name}")

            # 检查其他字段
            for key, expected_value in data_expects.items():
                if key == "has_fields":
                    continue

                actual_value = data.get(key)

                if isinstance(expected_value, dict):
                    # 范围或模式检查
                    errors.extend(
                        self._check_value_constraints(key, actual_value, expected_value)
                    )
                else:
                    # 精确匹配
                    if actual_value != expected_value:
                        errors.append(
                            f"data.{key}: 预期 {expected_value}，实际 {actual_value}"
                        )

        return errors

    def _check_value_constraints(
        self,
        field_name: str,
        actual: Any,
        constraints: Dict
    ) -> List[str]:
        """
        检查值约束（范围、包含、正则等）

        Args:
            field_name: 字段名
            actual: 实际值
            constraints: 约束条件

        Returns:
            错误信息列表
        """
        errors = []

        if actual is None:
            errors.append(f"data.{field_name}: 值为 None")
            return errors

        # 数值范围检查
        if "gte" in constraints and actual < constraints["gte"]:
            errors.append(f"data.{field_name}: {actual} < {constraints['gte']} (gte)")

        if "lte" in constraints and actual > constraints["lte"]:
            errors.append(f"data.{field_name}: {actual} > {constraints['lte']} (lte)")

        if "gt" in constraints and actual <= constraints["gt"]:
            errors.append(f"data.{field_name}: {actual} <= {constraints['gt']} (gt)")

        if "lt" in constraints and actual >= constraints["lt"]:
            errors.append(f"data.{field_name}: {actual} >= {constraints['lt']} (lt)")

        # 字符串检查
        if "contains" in constraints:
            if not isinstance(actual, str) or constraints["contains"] not in actual:
                errors.append(
                    f"data.{field_name}: '{actual}' 不包含 '{constraints['contains']}'"
                )

        if "matches" in constraints:
            pattern = constraints["matches"]
            if not isinstance(actual, str) or not re.search(pattern, actual):
                errors.append(
                    f"data.{field_name}: '{actual}' 不匹配模式 '{pattern}'"
                )

        return errors

    def run_scenario_list(
        self,
        scenarios: List[Dict],
        stop_on_failure: bool = False
    ) -> List[Tuple[Dict, Dict, List[str]]]:
        """
        执行场景列表

        Args:
            scenarios: 场景列表
            stop_on_failure: 遇到失败是否停止

        Returns:
            结果列表: [(scenario, result, errors), ...]
        """
        results = []

        for scenario in scenarios:
            # 检查依赖
            deps_ok, missing = self.check_dependencies(scenario)
            if not deps_ok:
                print(f"\n  [SCENARIO] 跳过 '{scenario.get('name')}': 缺少依赖 {missing}")
                results.append((scenario, {"skipped": True, "missing_deps": missing}, []))
                continue

            # 执行场景
            result = self.run_scenario(scenario)

            # 检查断言
            expects = scenario.get("expects", {"success": True})
            errors = self.check_expects(result, expects)

            results.append((scenario, result, errors))

            # 是否停止
            if stop_on_failure and errors:
                print(f"\n  [SCENARIO] 断言失败，停止执行")
                break

        return results
