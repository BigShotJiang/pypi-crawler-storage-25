"""
场景测试 pytest fixtures
"""
import pytest
from typing import Generator
from pathlib import Path

from .runner import ScenarioRunner, ScenarioContext


# 场景数据目录
SCENARIOS_DIR = Path(__file__).parent.parent / "data" / "scenarios"


@pytest.fixture(scope="session")
def scenarios_dir() -> Path:
    """场景数据目录"""
    return SCENARIOS_DIR


@pytest.fixture(scope="module")
def scenario_context() -> ScenarioContext:
    """
    场景上下文（模块级别）

    在同一个测试模块内共享 handles 和 results
    """
    return ScenarioContext()


@pytest.fixture(scope="module")
def scenario_runner(cad_service, scenario_context) -> Generator[ScenarioRunner, None, None]:
    """
    场景执行器（模块级别）

    提供命令执行和断言检查能力
    """
    runner = ScenarioRunner(cad_service, scenario_context)
    yield runner

    # 模块测试结束后清理上下文
    scenario_context.clear()


@pytest.fixture(scope="function")
def fresh_runner(cad_connected) -> Generator[ScenarioRunner, None, None]:
    """
    独立场景执行器（函数级别）

    每个测试函数使用独立的上下文
    """
    ctx = ScenarioContext()
    runner = ScenarioRunner(cad_connected, ctx)
    yield runner
    ctx.clear()


@pytest.fixture
def cleanup_entities(cad_connected, scenario_context):
    """
    测试后清理创建的实体

    自动删除 scenario_context.handles 中的所有实体
    """
    yield

    # 测试后清理
    if scenario_context.handles and cad_connected.controller.is_running():
        for name, handle in list(scenario_context.handles.items()):
            try:
                cad_connected.controller.smart_cad_command(
                    command_name="api_delete_entity",
                    parameters={"entityHandle": handle},
                    timeout=5.0
                )
                print(f"  [CLEANUP] 删除 {name}: {handle}")
            except Exception as e:
                print(f"  [CLEANUP] 删除 {name} 失败: {e}")
