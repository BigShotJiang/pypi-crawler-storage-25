"""
场景测试模块

提供基于 YAML 的数据驱动场景测试能力。
"""
from .runner import ScenarioRunner, ScenarioContext

__all__ = ["ScenarioRunner", "ScenarioContext"]
