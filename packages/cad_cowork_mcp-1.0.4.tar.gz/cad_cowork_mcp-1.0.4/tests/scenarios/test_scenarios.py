"""
场景测试主入口

基于 YAML 数据驱动的参数化测试
"""
import pytest
import yaml
from pathlib import Path
from typing import List, Dict, Any, Tuple

from .runner import ScenarioRunner, ScenarioContext


# 场景数据目录
SCENARIOS_DIR = Path(__file__).parent.parent / "data" / "scenarios"


def load_scenario_file(yaml_path: Path) -> Dict:
    """加载单个场景文件"""
    with open(yaml_path, 'r', encoding='utf-8') as f:
        return yaml.safe_load(f)


def get_scenario_files() -> List[Path]:
    """获取所有场景文件（按文件名排序）"""
    files = []
    for f in sorted(SCENARIOS_DIR.glob("*.yaml")):
        # 跳过 schema 文件
        if f.name == "schema.yaml":
            continue
        files.append(f)
    return files


def load_all_scenarios() -> List[Tuple[str, Dict]]:
    """
    加载所有场景，用于参数化测试

    Returns:
        [(test_id, scenario_dict), ...]
    """
    all_scenarios = []

    for yaml_path in get_scenario_files():
        data = load_scenario_file(yaml_path)
        if not data:
            continue

        file_prefix = yaml_path.stem  # e.g., "01_layer"

        # 加载 setup 场景
        for idx, scenario in enumerate(data.get("setup", [])):
            test_id = f"{file_prefix}/setup/{idx}_{scenario.get('name', 'unnamed')}"
            scenario["_file"] = str(yaml_path)
            scenario["_phase"] = "setup"
            scenario["_index"] = idx
            all_scenarios.append((test_id, scenario))

        # 加载主场景
        for idx, scenario in enumerate(data.get("scenarios", [])):
            test_id = f"{file_prefix}/{idx}_{scenario.get('name', 'unnamed')}"
            scenario["_file"] = str(yaml_path)
            scenario["_phase"] = "main"
            scenario["_index"] = idx
            all_scenarios.append((test_id, scenario))

        # 加载 teardown 场景
        for idx, scenario in enumerate(data.get("teardown", [])):
            test_id = f"{file_prefix}/teardown/{idx}_{scenario.get('name', 'unnamed')}"
            scenario["_file"] = str(yaml_path)
            scenario["_phase"] = "teardown"
            scenario["_index"] = idx
            all_scenarios.append((test_id, scenario))

    return all_scenarios


def load_scenarios_by_file(file_name: str) -> List[Tuple[str, Dict]]:
    """
    加载指定文件的场景

    Args:
        file_name: 文件名（不含路径），如 "01_layer.yaml"
    """
    yaml_path = SCENARIOS_DIR / file_name
    if not yaml_path.exists():
        return []

    data = load_scenario_file(yaml_path)
    if not data:
        return []

    scenarios = []
    file_prefix = yaml_path.stem

    for phase in ["setup", "scenarios", "teardown"]:
        phase_label = "main" if phase == "scenarios" else phase
        for idx, scenario in enumerate(data.get(phase, [])):
            test_id = f"{file_prefix}/{phase_label}/{idx}_{scenario.get('name', 'unnamed')}"
            scenario["_file"] = str(yaml_path)
            scenario["_phase"] = phase_label
            scenario["_index"] = idx
            scenarios.append((test_id, scenario))

    return scenarios


# =============================================================================
# 参数化测试
# =============================================================================

# 模块级别的上下文（跨测试共享 handles）
_module_context = ScenarioContext()


@pytest.fixture(scope="module")
def shared_context():
    """模块共享的场景上下文"""
    global _module_context
    _module_context = ScenarioContext()
    yield _module_context
    _module_context.clear()


@pytest.fixture(scope="module")
def shared_runner(cad_service, shared_context):
    """模块共享的场景执行器"""
    return ScenarioRunner(cad_service, shared_context)


class TestAllScenarios:
    """
    所有场景的参数化测试

    使用方法:
        pytest tests/scenarios/test_scenarios.py -v -s --timeout=0
        pytest tests/scenarios/test_scenarios.py -k "01_layer" -v
        pytest tests/scenarios/test_scenarios.py -k "drawing" -v
    """

    @pytest.mark.scenario
    @pytest.mark.parametrize(
        "test_id,scenario",
        load_all_scenarios(),
        ids=lambda x: x if isinstance(x, str) else x.get("name", "unnamed")
    )
    def test_scenario(self, cad_connected, shared_context, test_id, scenario):
        """执行单个场景测试"""
        runner = ScenarioRunner(cad_connected, shared_context)

        # 检查依赖
        deps_ok, missing = runner.check_dependencies(scenario)
        if not deps_ok:
            pytest.skip(f"缺少依赖: {missing}")

        # 执行场景
        result = runner.run_scenario(scenario)

        # 检查断言
        expects = scenario.get("expects", {"success": True})
        errors = runner.check_expects(result, expects)

        # 断言
        assert not errors, "\n".join(errors)


# =============================================================================
# 工具函数测试
# =============================================================================

class TestScenarioRunner:
    """ScenarioRunner 单元测试"""

    @pytest.mark.unit
    def test_resolve_simple_variable(self):
        """测试简单变量解析"""
        ctx = ScenarioContext()
        ctx.save_handle("my_handle", "ABC123")

        runner = ScenarioRunner(None, ctx)
        result = runner.resolve_value("${my_handle}")

        assert result == "ABC123"

    @pytest.mark.unit
    def test_resolve_variable_in_list(self):
        """测试列表中的变量解析"""
        ctx = ScenarioContext()
        ctx.save_handle("handle1", "AAA")
        ctx.save_handle("handle2", "BBB")

        runner = ScenarioRunner(None, ctx)
        result = runner.resolve_value(["${handle1}", "${handle2}", "literal"])

        assert result == ["AAA", "BBB", "literal"]

    @pytest.mark.unit
    def test_resolve_variable_in_dict(self):
        """测试字典中的变量解析"""
        ctx = ScenarioContext()
        ctx.save_handle("entity", "HANDLE123")

        runner = ScenarioRunner(None, ctx)
        result = runner.resolve_params({
            "entityHandle": "${entity}",
            "offset": [10, 20, 0]
        })

        assert result == {
            "entityHandle": "HANDLE123",
            "offset": [10, 20, 0]
        }

    @pytest.mark.unit
    def test_check_expects_success(self):
        """测试成功断言"""
        runner = ScenarioRunner(None, ScenarioContext())

        result = {"success": True, "data": {"entityHandle": "ABC"}}
        expects = {"success": True, "data": {"has_fields": ["entityHandle"]}}

        errors = runner.check_expects(result, expects)
        assert errors == []

    @pytest.mark.unit
    def test_check_expects_failure(self):
        """测试失败断言"""
        runner = ScenarioRunner(None, ScenarioContext())

        result = {"success": False, "error": "Something went wrong"}
        expects = {"success": True}

        errors = runner.check_expects(result, expects)
        assert len(errors) == 1
        assert "success" in errors[0]

    @pytest.mark.unit
    def test_check_expects_range(self):
        """测试范围断言"""
        runner = ScenarioRunner(None, ScenarioContext())

        result = {"success": True, "data": {"radius": 50.0}}
        expects = {"data": {"radius": {"gte": 49, "lte": 51}}}

        errors = runner.check_expects(result, expects)
        assert errors == []

    @pytest.mark.unit
    def test_check_dependencies(self):
        """测试依赖检查"""
        ctx = ScenarioContext()
        ctx.save_handle("existing", "HANDLE")

        runner = ScenarioRunner(None, ctx)

        # 依赖存在
        scenario1 = {"command": "test", "depends_on": ["existing"]}
        ok1, missing1 = runner.check_dependencies(scenario1)
        assert ok1 is True
        assert missing1 == []

        # 依赖不存在
        scenario2 = {"command": "test", "depends_on": ["not_existing"]}
        ok2, missing2 = runner.check_dependencies(scenario2)
        assert ok2 is False
        assert "not_existing" in missing2
