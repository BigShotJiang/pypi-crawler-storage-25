"""
测试数据样本

提供标准化的测试数据集
"""
from typing import Dict, Any, List

# ============================================================
# 点坐标
# ============================================================

ORIGIN = [0, 0, 0]
POINT_100 = [100, 100, 0]
POINT_200 = [200, 200, 0]
POINT_500 = [500, 500, 0]

# ============================================================
# 绘图参数
# ============================================================

SAMPLE_LINE_PARAMS: Dict[str, Any] = {
    "startPoint": [0, 0, 0],
    "endPoint": [100, 100, 0],
    "layerName": "0"
}

SAMPLE_CIRCLE_PARAMS: Dict[str, Any] = {
    "center": [100, 100, 0],
    "radius": 50,
    "layerName": "0"
}

SAMPLE_RECTANGLE_PARAMS: Dict[str, Any] = {
    "corner1": [0, 0, 0],
    "corner2": [100, 50, 0],
    "layerName": "0"
}

SAMPLE_POLYLINE_PARAMS: Dict[str, Any] = {
    "points": [[0, 0, 0], [50, 50, 0], [100, 0, 0]],
    "closed": False,
    "layerName": "0"
}

SAMPLE_ARC_PARAMS: Dict[str, Any] = {
    "center": [100, 100, 0],
    "radius": 50,
    "startAngle": 0,
    "endAngle": 90,
    "layerName": "0"
}

SAMPLE_TEXT_PARAMS: Dict[str, Any] = {
    "position": [100, 100, 0],
    "text": "Test Text",
    "height": 5,
    "rotation": 0,
    "layerName": "0"
}

# ============================================================
# 查询参数
# ============================================================

SAMPLE_WINDOW_QUERY: Dict[str, Any] = {
    "minPoint": [0, 0, 0],
    "maxPoint": [1000, 1000, 0],
    "crossing": False
}

SAMPLE_NEARBY_QUERY: Dict[str, Any] = {
    "center": [100, 100, 0],
    "radius": 200
}

SAMPLE_TYPE_QUERY: Dict[str, Any] = {
    "entityType": "Circle",
    "layerName": "0"
}

# ============================================================
# 图层参数
# ============================================================

SAMPLE_LAYER_PARAMS: Dict[str, Any] = {
    "layerName": "TestLayer",
    "color": 1,
    "lineType": "Continuous",
    "isPlottable": True
}

# ============================================================
# 块操作参数
# ============================================================

SAMPLE_INSERT_BLOCK_PARAMS: Dict[str, Any] = {
    "blockName": "TestBlock",
    "insertionPoint": [100, 100, 0],
    "xScale": 1.0,
    "yScale": 1.0,
    "rotation": 0
}

# ============================================================
# 批量操作参数
# ============================================================

SAMPLE_BATCH_MOVE_PARAMS: Dict[str, Any] = {
    "entityHandles": [],
    "displacement": [50, 50, 0]
}

SAMPLE_BATCH_COPY_PARAMS: Dict[str, Any] = {
    "entityHandles": [],
    "displacement": [100, 0, 0]
}

# ============================================================
# 空间计算参数
# ============================================================

SAMPLE_DISTANCE_PARAMS: Dict[str, Any] = {
    "point1": [0, 0, 0],
    "point2": [100, 0, 0]
}

SAMPLE_ANGLE_PARAMS: Dict[str, Any] = {
    "point1": [100, 0, 0],
    "point2": [0, 0, 0],
    "point3": [0, 100, 0]
}

SAMPLE_AREA_PARAMS: Dict[str, Any] = {
    "points": [[0, 0], [100, 0], [100, 100], [0, 100]]
}

# ============================================================
# 实体类型列表
# ============================================================

ENTITY_TYPES: List[str] = [
    "Line",
    "Circle",
    "Arc",
    "Ellipse",
    "Polyline",
    "LWPolyline",
    "Spline",
    "DBText",
    "MText",
    "BlockReference",
    "Dimension",
    "AlignedDimension",
    "RotatedDimension",
    "Hatch",
    "Leader",
    "MLeader",
]

# ============================================================
# 颜色索引
# ============================================================

COLOR_BYLAYER = 256
COLOR_BYBLOCK = 0
COLOR_RED = 1
COLOR_YELLOW = 2
COLOR_GREEN = 3
COLOR_CYAN = 4
COLOR_BLUE = 5
COLOR_MAGENTA = 6
COLOR_WHITE = 7

# ============================================================
# 线型
# ============================================================

LINETYPE_CONTINUOUS = "Continuous"
LINETYPE_DASHED = "DASHED"
LINETYPE_CENTER = "CENTER"
LINETYPE_HIDDEN = "HIDDEN"
