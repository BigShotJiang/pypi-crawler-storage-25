# CAD-MCP 测试框架

## 概述

本测试框架为 CAD-MCP 项目的 77 个 API 命令提供系统化测试能力。

## 测试层级

```
┌─────────────────────────────────────────────────────┐
│  L3: 场景测试（Scenario）                            │
│  - YAML 数据驱动测试                                 │
│  - 跨命令依赖链验证                                  │
│  - 需要: CAD 软件运行                               │
│  - 标记: @pytest.mark.scenario                      │
└─────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────┐
│  L2: 集成测试（Integration）                         │
│  - API 命令实际执行                                  │
│  - 需要: CAD 软件运行                               │
│  - 标记: @pytest.mark.integration                   │
└─────────────────────────────────────────────────────┘
┌─────────────────────────────────────────────────────┐
│  L1: 单元测试（Unit）                                │
│  - 命令定义验证                                      │
│  - 参数结构检查                                      │
│  - 不需要 CAD 连接                                  │
│  - 标记: @pytest.mark.unit                          │
└─────────────────────────────────────────────────────┘
```

## 目录结构

```
tests/
├── conftest.py              # 全局 fixtures
├── pytest.ini               # pytest 配置
│
├── unit/                    # L1: 单元测试
│   ├── test_prompt_template.py
│   ├── test_tool_definitions.py
│   └── test_api_manifest.py
│
├── integration/             # L2: 集成测试
│   ├── test_cad_connection.py
│   └── test_smart_cad_command.py
│
├── scenarios/               # L3: 场景测试（数据驱动）
│   ├── __init__.py
│   ├── conftest.py          # 场景 fixtures
│   ├── runner.py            # 场景执行引擎
│   └── test_scenarios.py    # 参数化测试入口
│
├── data/scenarios/          # YAML 测试数据
│   ├── schema.yaml          # Schema 定义
│   ├── 01_layer.yaml        # 图层管理 (7)
│   ├── 02_drawing.yaml      # 绘图基础 (11)
│   ├── 03_query.yaml        # 查询操作 (10)
│   ├── 04_block.yaml        # 块操作 (11)
│   ├── 05_modify.yaml       # 实体修改 (10)
│   ├── 06_batch.yaml        # 批量操作 (9)
│   ├── 07_spatial.yaml      # 空间计算 (9)
│   ├── 08_view.yaml         # 视图控制 (5)
│   ├── 09_document.yaml     # 文档管理 (4)
│   ├── 10_selection.yaml    # 选择集 (5)
│   └── 11_cleanup.yaml      # 清理收尾 (6)
│
├── mocks/                   # Mock 类
│   └── cad_mock.py
│
└── fixtures/                # 测试数据
    └── sample_data.py
```

## 运行测试

### 安装依赖

```bash
cd mcp-server
pip install -r requirements-dev.txt
```

### 运行所有测试

```bash
pytest
```

### 仅运行单元测试（不需要 CAD）

```bash
pytest -m unit
```

### 仅运行集成测试（需要 CAD）

```bash
pytest -m integration
```

### 运行场景测试（需要 CAD）

```bash
# 运行所有场景测试
pytest -m scenario -v -s --timeout=0

# 运行特定阶段的场景
pytest tests/scenarios/test_scenarios.py -k "01_layer" -v
pytest tests/scenarios/test_scenarios.py -k "drawing" -v

# 运行 ScenarioRunner 单元测试（不需要 CAD）
pytest tests/scenarios/test_scenarios.py::TestScenarioRunner -v
```

### 生成覆盖率报告

```bash
pytest --cov=. --cov-report=html
```

### 生成 HTML 报告

```bash
pytest --html=report.html
```

## 测试标记

| 标记 | 说明 |
|------|------|
| `unit` | 单元测试，不需要 CAD |
| `integration` | 基础集成测试，需要 CAD 运行 |
| `scenario` | 场景测试，YAML 数据驱动 |
| `slow` | 慢速测试 |

## API 命令覆盖

| 类别 | 命令数 |
|------|--------|
| 绘图-基础 | 10 |
| 查询 | 15 |
| 块操作 | 6 |
| 实体修改 | 11 |
| 批量操作 | 7 |
| 空间计算 | 8 |
| 图层管理 | 6 |
| 文档管理 | 4 |
| 视图控制 | 5 |
| 选择集 | 5 |
| **总计** | **77** |

## 测试环境要求

### 单元测试
- Python 3.9+
- pytest 及相关依赖

### 集成测试
- Windows 操作系统
- AutoCAD / 浩辰 CAD / 中望 CAD 运行中
- cad-cowork-cstool 插件已加载

## 场景测试（YAML 数据驱动）

### 概述

场景测试采用 YAML 数据驱动方式，将测试数据与执行逻辑分离，支持：

- **变量引用**：`${handle_name}` 语法支持跨场景传递 Handle
- **依赖检查**：`depends_on` 自动跳过缺失依赖的测试
- **断言系统**：支持精确匹配、范围检查、字段存在检查
- **调试输出**：自动打印 `request.json` 和 `latest.json` 内容

### YAML Schema

```yaml
# 场景定义
name: string           # 场景名称（必需）
description: string    # 详细描述（可选）
command: string        # API 命令名（必需）
params: object         # 命令参数（必需）
expects:               # 预期结果（可选）
  success: boolean
  error_contains: string
  data:
    has_fields: [field1, field2]  # 必须存在的字段
    fieldName: expectedValue      # 精确匹配
    fieldName:                    # 范围匹配
      gte: number
      lte: number
      contains: string
      matches: regex
save_as: string        # 保存 handle 的变量名（可选）
depends_on: string[]   # 依赖的变量（可选）
tags: string[]         # 标签（可选）
timeout: number        # 超时秒数（可选，默认 30）
```

### 变量引用语法

```yaml
# 保存 handle
- name: "绘制圆"
  command: api_draw_circle
  params:
    center: [200, 100, 0]
    radius: 50
  save_as: circle_for_hatch

# 引用 handle
- name: "创建填充"
  command: api_create_hatch
  params:
    boundaryHandles: ["${circle_for_hatch}"]
    patternName: "SOLID"
  depends_on: [circle_for_hatch]
```

### 特殊变量

| 变量 | 说明 |
|------|------|
| `${_last_handle}` | 上一个成功操作返回的 handle |
| `${TEMP}` | 系统临时目录路径 |

### 添加新场景

编辑对应的 YAML 文件即可：

```yaml
- name: "新测试场景"
  description: "场景描述"
  command: api_xxx
  params:
    param1: value1
    param2: [1, 2, 3]
  expects:
    success: true
    data:
      has_fields: [entityHandle]
  save_as: new_handle
  tags: [category, subcategory]
```

### 场景文件覆盖

| 阶段 | 文件 | 场景数 | 说明 |
|------|------|--------|------|
| 1 | 01_layer.yaml | 7 | 图层管理 |
| 2 | 02_drawing.yaml | 11 | 绘图基础 |
| 3 | 03_query.yaml | 10 | 查询操作 |
| 4 | 04_block.yaml | 11 | 块操作 |
| 5 | 05_modify.yaml | 10 | 实体修改 |
| 6 | 06_batch.yaml | 9 | 批量操作 |
| 7 | 07_spatial.yaml | 9 | 空间计算 |
| 8 | 08_view.yaml | 5 | 视图控制 |
| 9 | 09_document.yaml | 4 | 文档管理 |
| 10 | 10_selection.yaml | 5 | 选择集 |
| 11 | 11_cleanup.yaml | 6 | 清理收尾 |
| **总计** | **11 个文件** | **87** | - |

### 核心组件

| 组件 | 文件 | 说明 |
|------|------|------|
| ScenarioContext | runner.py | 存储跨场景共享的 handles 和 results |
| ScenarioRunner | runner.py | 场景执行器，负责 YAML 解析、变量解析、命令执行、断言检查 |
| TestAllScenarios | test_scenarios.py | pytest 参数化测试类 |
| TestScenarioRunner | test_scenarios.py | ScenarioRunner 单元测试 |
