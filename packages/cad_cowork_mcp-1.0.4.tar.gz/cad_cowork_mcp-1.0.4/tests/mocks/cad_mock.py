"""
CAD 服务 Mock 类

提供:
- MockCADController: 模拟 CAD 控制器
- MockCADService: 模拟 CAD 服务
"""
from typing import Dict, Any, List, Optional
import uuid


class MockCADController:
    """模拟 CAD 控制器"""

    def __init__(self, connected: bool = True):
        self._connected = connected
        self._entities: Dict[str, Dict[str, Any]] = {}

    @property
    def is_connected(self) -> bool:
        return self._connected

    def connect(self) -> bool:
        self._connected = True
        return True

    def disconnect(self) -> None:
        self._connected = False

    def smart_cad_command(
        self,
        command_name: str,
        parameters: Dict[str, Any],
        timeout: float = 10.0
    ) -> Dict[str, Any]:
        """模拟执行 CAD 命令"""
        if not self._connected:
            return {
                "success": False,
                "error": "CAD 未连接"
            }

        # 模拟绘图命令
        if command_name.startswith("api_draw_") or command_name.startswith("api_create_"):
            return self._mock_draw_command(command_name, parameters)

        # 模拟查询命令
        if command_name.startswith("api_query_") or command_name.startswith("api_get_"):
            return self._mock_query_command(command_name, parameters)

        # 模拟修改命令
        if command_name in ["api_move_entity", "api_rotate_entity", "api_scale_entity"]:
            return self._mock_modify_command(command_name, parameters)

        # 默认成功
        return {"success": True, "data": {}}

    def _mock_draw_command(
        self,
        command_name: str,
        parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """模拟绘图命令"""
        handle = self._generate_handle()
        entity_type = self._get_entity_type(command_name)

        self._entities[handle] = {
            "type": entity_type,
            "parameters": parameters
        }

        return {
            "success": True,
            "data": {
                "entityHandle": handle,
                "entityType": entity_type
            }
        }

    def _mock_query_command(
        self,
        command_name: str,
        parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """模拟查询命令"""
        if command_name == "api_get_entity_info":
            handle = parameters.get("entityHandle")
            if handle in self._entities:
                return {
                    "success": True,
                    "data": self._entities[handle]
                }
            return {
                "success": False,
                "error": f"实体不存在: {handle}"
            }

        if command_name == "api_query_all_block_names":
            return {
                "success": True,
                "data": {
                    "blockNames": ["*Model_Space", "*Paper_Space"]
                }
            }

        if command_name == "api_list_layers":
            return {
                "success": True,
                "data": {
                    "layers": ["0", "Defpoints"]
                }
            }

        return {"success": True, "data": {}}

    def _mock_modify_command(
        self,
        command_name: str,
        parameters: Dict[str, Any]
    ) -> Dict[str, Any]:
        """模拟修改命令"""
        handle = parameters.get("entityHandle")
        if handle not in self._entities:
            return {
                "success": False,
                "error": f"实体不存在: {handle}"
            }

        return {"success": True, "data": {}}

    def _generate_handle(self) -> str:
        """生成模拟句柄"""
        return uuid.uuid4().hex[:8].upper()

    def _get_entity_type(self, command_name: str) -> str:
        """根据命令名获取实体类型"""
        type_map = {
            "api_draw_line": "Line",
            "api_draw_circle": "Circle",
            "api_draw_rectangle": "Polyline",
            "api_create_polyline": "Polyline",
            "api_create_arc": "Arc",
            "api_create_text": "DBText",
            "api_create_mtext": "MText",
            "api_create_dimension": "Dimension",
            "api_create_hatch": "Hatch",
            "api_create_leader": "Leader",
        }
        return type_map.get(command_name, "Entity")

    def delete_entity(self, handle: str) -> bool:
        """删除实体"""
        if handle in self._entities:
            del self._entities[handle]
            return True
        return False


class MockCADService:
    """模拟 CAD 服务"""

    def __init__(self, connected: bool = True):
        self.controller = MockCADController(connected)
