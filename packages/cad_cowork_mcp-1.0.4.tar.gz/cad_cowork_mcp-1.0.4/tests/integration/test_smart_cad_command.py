"""
smart_cad_command 核心工具测试

验证:
- 统一入口功能
- API 命令执行
- 业务命令执行
- 返回值结构
"""
import pytest


@pytest.mark.integration
class TestSmartCadCommandBasic:
    """smart_cad_command 基础测试"""

    def test_execute_api_draw_circle(self, cad_connected, created_entities):
        """测试执行 api_draw_circle"""
        result = cad_connected.controller.smart_cad_command(
            command_name="api_draw_circle",
            parameters={
                "center": [100, 100, 0],
                "radius": 50
            }
        )

        assert isinstance(result, dict)
        if result.get("success"):
            # 成功时应返回 entityHandle
            data = result.get("data", {})
            if "entityHandle" in data:
                created_entities.append(data["entityHandle"])
                assert data["entityHandle"], "entityHandle 不应为空"

    def test_execute_api_draw_line(self, cad_connected, created_entities):
        """测试执行 api_draw_line"""
        result = cad_connected.controller.smart_cad_command(
            command_name="api_draw_line",
            parameters={
                "startPoint": [0, 0, 0],
                "endPoint": [100, 100, 0]
            }
        )

        assert isinstance(result, dict)
        if result.get("success") and result.get("data", {}).get("entityHandle"):
            created_entities.append(result["data"]["entityHandle"])

    def test_execute_api_query_command(self, cad_connected):
        """测试执行查询命令"""
        result = cad_connected.controller.smart_cad_command(
            command_name="api_list_layers",
            parameters={}
        )

        assert isinstance(result, dict)
        # 查询命令应该返回数据或错误信息

    def test_execute_with_invalid_command(self, cad_connected):
        """测试执行无效命令"""
        result = cad_connected.controller.smart_cad_command(
            command_name="api_invalid_command_xyz",
            parameters={}
        )

        assert isinstance(result, dict)
        # 无效命令应该返回错误
        assert not result.get("success") or "error" in str(result).lower()


@pytest.mark.integration
class TestSmartCadCommandReturnValue:
    """smart_cad_command 返回值测试"""

    def test_return_structure_on_success(self, cad_connected, created_entities):
        """验证成功时的返回结构"""
        result = cad_connected.controller.smart_cad_command(
            command_name="api_draw_circle",
            parameters={"center": [200, 200, 0], "radius": 30}
        )

        if result.get("success"):
            assert "data" in result or "success" in result
            if result.get("data", {}).get("entityHandle"):
                created_entities.append(result["data"]["entityHandle"])

    def test_return_structure_on_error(self, cad_connected):
        """验证失败时的返回结构"""
        # 缺少必需参数
        result = cad_connected.controller.smart_cad_command(
            command_name="api_draw_circle",
            parameters={}  # 缺少 center 和 radius
        )

        assert isinstance(result, dict)
        # 应该有错误信息
        if not result.get("success"):
            assert "error" in result or "message" in result or not result.get("success")


@pytest.mark.integration
class TestSmartCadCommandBusinessCommands:
    """smart_cad_command 业务命令测试"""

    def test_execute_dl_command(self, cad_connected):
        """测试执行 DL 开头的业务命令"""
        # 这个命令可能需要特定的块定义存在
        result = cad_connected.controller.smart_cad_command(
            command_name="DLShowStats",
            parameters=None
        )

        # 业务命令可能成功也可能失败（取决于环境）
        # 但应该返回结构化结果
        assert isinstance(result, dict)
