"""
CAD 连接测试

验证:
- CAD 连接状态检测
- CAD 自动启动/连接
- 连接错误处理
"""
import pytest


class TestCADConnection:
    """CAD 连接测试"""

    def test_cad_service_initialization(self, cad_service):
        """验证 CAD 服务可以初始化"""
        assert cad_service is not None
        assert hasattr(cad_service, "controller")
        assert hasattr(cad_service, "nlp_processor")

    def test_cad_controller_has_required_methods(self, cad_service):
        """验证 CAD 控制器有必需方法"""
        controller = cad_service.controller
        required_methods = [
            "is_running",
            "smart_cad_command",
            "execute_api_command",
            "send_command",
        ]
        for method in required_methods:
            assert hasattr(controller, method), f"控制器缺少方法: {method}"

    def test_is_running_returns_bool(self, cad_service):
        """验证 is_running 返回布尔值"""
        result = cad_service.controller.is_running()
        assert isinstance(result, bool)


@pytest.mark.integration
class TestCADConnectionIntegration:
    """CAD 连接集成测试（需要 CAD）"""

    def test_cad_is_connected(self, cad_connected):
        """验证 CAD 已连接"""
        assert cad_connected.controller.is_running()

    def test_can_execute_simple_command(self, cad_connected):
        """验证可以执行简单命令"""
        result = cad_connected.controller.smart_cad_command(
            command_name="api_get_document_info",
            parameters={}
        )
        # 即使失败也应该返回结构化结果
        assert isinstance(result, dict)
        assert "success" in result or "error" in result
