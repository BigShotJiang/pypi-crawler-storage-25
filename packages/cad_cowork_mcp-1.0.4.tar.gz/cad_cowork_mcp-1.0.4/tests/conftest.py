"""
pytest 全局配置和 fixtures

测试层级:
- L1 (unit): 单元测试，不需要 CAD
- L2 (integration): 基础集成测试，需要 CAD 运行
- L3 (scenario): 场景测试，YAML 数据驱动，需要 CAD 运行
"""
import os
import pytest
from typing import Generator, Dict, Any, List, Optional


# ============================================================
# pytest 配置钩子
# ============================================================

def pytest_configure(config):
    """pytest 配置"""
    # 设置环境变量，标识测试模式
    os.environ["TESTING"] = "1"


def pytest_collection_modifyitems(config, items):
    """修改测试收集，自动添加标记"""
    for item in items:
        # 根据路径自动添加标记
        if "unit" in str(item.fspath):
            item.add_marker(pytest.mark.unit)
        elif "integration" in str(item.fspath):
            item.add_marker(pytest.mark.integration)
        elif "scenarios" in str(item.fspath):
            item.add_marker(pytest.mark.scenario)


# ============================================================
# 基础 Fixtures
# ============================================================

@pytest.fixture(scope="session")
def api_manifest() -> Dict[str, Any]:
    """API 命令清单（会话级别）"""
    from cad_cowork_mcp.server import API_COMMANDS_MANIFEST
    assert API_COMMANDS_MANIFEST is not None, "API 命令清单未加载"
    return API_COMMANDS_MANIFEST


@pytest.fixture(scope="session")
def prompt_template() -> str:
    """PROMPT_TEMPLATE 内容"""
    from cad_cowork_mcp.server import PROMPT_TEMPLATE
    return PROMPT_TEMPLATE


# ============================================================
# CAD 服务 Fixtures
# ============================================================

@pytest.fixture(scope="module")
def cad_service():
    """CAD 服务实例（模块级别）"""
    from cad_cowork_mcp.server import CADService
    service = CADService()

    # 尝试连接到 CAD
    try:
        service.start_cad()
    except Exception as e:
        # 连接失败不抛出异常，由 cad_connected fixture 处理跳过
        pass

    yield service


@pytest.fixture(scope="function")
def cad_connected(cad_service) -> Generator:
    """确保 CAD 已连接的 fixture"""
    # 每次测试前确保连接有效
    if not cad_service.controller.is_running():
        try:
            cad_service.start_cad()
        except Exception:
            pass

    if not cad_service.controller.is_running():
        pytest.skip("CAD 未运行或无法连接，跳过集成测试")

    # 确保 COM 连接活跃（重新获取文档引用）
    try:
        cad_service.controller._get_active_document()
    except Exception:
        try:
            cad_service.start_cad()
        except Exception:
            pytest.skip("CAD 连接失败，跳过集成测试")

    yield cad_service


@pytest.fixture(scope="function")
def cad_maybe_connected(cad_service) -> Generator:
    """CAD 可能连接的 fixture（不跳过，返回连接状态）"""
    is_connected = cad_service.controller.is_running()
    yield (cad_service, is_connected)


# ============================================================
# 测试辅助 Fixtures
# ============================================================

@pytest.fixture
def created_entities(cad_connected) -> Generator[List[str], None, None]:
    """
    跟踪测试中创建的实体，测试后自动清理

    用法:
        def test_draw_circle(cad_connected, created_entities):
            result = execute_command(...)
            if result.get("data", {}).get("entityHandle"):
                created_entities.append(result["data"]["entityHandle"])
    """
    entities: List[str] = []
    yield entities

    # 测试后清理创建的实体
    if entities and cad_connected.controller.is_running():
        for handle in entities:
            try:
                cad_connected.controller.smart_cad_command(
                    command_name="api_delete_entity",
                    parameters={"entityHandle": handle},
                    timeout=5.0
                )
            except Exception:
                pass  # 清理失败不影响测试结果


@pytest.fixture
def test_point() -> List[float]:
    """测试用坐标点"""
    return [100.0, 100.0, 0.0]


@pytest.fixture
def test_point_2() -> List[float]:
    """测试用坐标点 2"""
    return [200.0, 200.0, 0.0]


# ============================================================
# Mock Fixtures
# ============================================================

@pytest.fixture
def mock_cad_controller(mocker):
    """Mock CAD 控制器"""
    from tests.mocks.cad_controller_mock import MockCADController
    return MockCADController()


@pytest.fixture
def mock_successful_result() -> Dict[str, Any]:
    """模拟成功的命令结果"""
    return {
        "success": True,
        "data": {
            "entityHandle": "MOCK_HANDLE_123",
            "entityType": "Circle"
        }
    }


@pytest.fixture
def mock_error_result() -> Dict[str, Any]:
    """模拟失败的命令结果"""
    return {
        "success": False,
        "error": "Mock error message"
    }


# ============================================================
# 辅助函数
# ============================================================

def get_command_from_manifest(manifest: Dict, command_name: str) -> Optional[Dict]:
    """从清单中获取命令信息"""
    for category in manifest.get("categories", []):
        for cmd in category.get("commands", []):
            if cmd.get("name") == command_name:
                return cmd
    return None


def get_commands_by_category(manifest: Dict, category_name: str) -> List[Dict]:
    """获取指定类别的所有命令"""
    for category in manifest.get("categories", []):
        if category.get("name") == category_name or category.get("nameEn") == category_name:
            return category.get("commands", [])
    return []
