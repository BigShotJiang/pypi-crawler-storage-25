# jax2onnx/plugins/jax/lax/round.py


from jax import core
import jax

from jax2onnx.converter.typing_support import LoweringContextProtocol
from jax2onnx.plugins._post_check_onnx_graph import expect_graph as EG
from jax2onnx.plugins.plugin_system import PrimitiveLeafPlugin, register_primitive


@register_primitive(
    jaxpr_primitive=jax.lax.round_p.name,
    jax_doc="https://docs.jax.dev/en/latest/_autosummary/jax.lax.round.html",
    onnx=[
        {
            "component": "Round",
            "doc": "https://onnx.ai/onnx/operators/onnx__Round.html",
        }
    ],
    since="0.12.1",
    context="primitives.lax",
    component="round",
    testcases=[
        {
            "testcase": "round",
            "callable": lambda x: jax.lax.round(x),
            "input_shapes": [(3,)],
            "post_check_onnx_graph": EG(
                ["Round:3"],
                no_unused_inputs=True,
            ),
        }
    ],
)
class RoundPlugin(PrimitiveLeafPlugin):
    def lower(self, ctx: LoweringContextProtocol, eqn: "core.JaxprEqn") -> None:
        x_var = eqn.invars[0]
        out_var = eqn.outvars[0]

        x_val = ctx.get_value_for_var(x_var, name_hint=ctx.fresh_name("round_in"))
        out_spec = ctx.get_value_for_var(out_var, name_hint=ctx.fresh_name("round_out"))

        # Derive a safe output name; avoid reusing a name that already has a producer.
        desired_name = out_spec.name
        if getattr(out_spec, "producer", None) is not None:
            desired_name = ctx.fresh_name("round_out")

        result = ctx.builder.Round(x_val, _outputs=[desired_name])
        result.type = out_spec.type
        result.shape = out_spec.shape
        ctx.bind_value_for_var(out_var, result)
