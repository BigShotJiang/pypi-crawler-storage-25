# jax2onnx/plugins/jax/lax/expm1.py


import jax
import numpy as np
from jax import core

from jax2onnx.converter.typing_support import LoweringContextProtocol
from jax2onnx.plugins._axis0_utils import _np_dtype_for_enum
from jax2onnx.plugins._post_check_onnx_graph import expect_graph as EG
from jax2onnx.plugins.plugin_system import PrimitiveLeafPlugin, register_primitive


@register_primitive(
    jaxpr_primitive=jax.lax.expm1_p.name,
    jax_doc="https://docs.jax.dev/en/latest/_autosummary/jax.lax.expm1.html",
    onnx=[
        {"component": "Exp", "doc": "https://onnx.ai/onnx/operators/onnx__Exp.html"},
        {"component": "Sub", "doc": "https://onnx.ai/onnx/operators/onnx__Sub.html"},
    ],
    since="0.12.1",
    context="primitives.lax",
    component="expm1",
    testcases=[
        {
            "testcase": "expm1",
            "callable": lambda x: jax.lax.expm1(x),
            "input_values": [np.array([-1.0, 0.0, 1.0], dtype=np.float32)],
            "post_check_onnx_graph": EG(
                ["Exp:3 -> Sub:3"],
                no_unused_inputs=True,
            ),
        }
    ],
)
class Expm1Plugin(PrimitiveLeafPlugin):
    """Lower ``lax.expm1`` to ONNX via Exp + Sub."""

    def lower(self, ctx: LoweringContextProtocol, eqn: "core.JaxprEqn") -> None:
        x_var = eqn.invars[0]
        out_var = eqn.outvars[0]

        x_val = ctx.get_value_for_var(x_var, name_hint=ctx.fresh_name("expm1_in"))
        out_spec = ctx.get_value_for_var(out_var, name_hint=ctx.fresh_name("expm1_out"))

        desired_name = getattr(out_spec, "name", None) or ctx.fresh_name("expm1_out")
        producer = getattr(out_spec, "producer", lambda: None)
        if callable(producer) and producer() is not None:
            desired_name = ctx.fresh_name("expm1_out")

        exp_val = ctx.builder.Exp(x_val, _outputs=[ctx.fresh_name("expm1_exp")])
        if getattr(x_val, "type", None) is not None:
            exp_val.type = x_val.type
        if getattr(x_val, "shape", None) is not None:
            exp_val.shape = x_val.shape

        dtype_enum = getattr(getattr(exp_val, "type", None), "dtype", None)
        np_dtype = _np_dtype_for_enum(dtype_enum)
        if np_dtype is None:
            aval = getattr(x_var, "aval", None)
            np_dtype = np.dtype(getattr(aval, "dtype", np.float32))

        one_scalar = ctx.bind_const_for_var(object(), np.asarray(1.0, dtype=np_dtype))

        result = ctx.builder.Sub(exp_val, one_scalar, _outputs=[desired_name])
        if getattr(out_spec, "type", None) is not None:
            result.type = out_spec.type
        elif getattr(exp_val, "type", None) is not None:
            result.type = exp_val.type
        if getattr(out_spec, "shape", None) is not None:
            result.shape = out_spec.shape
        elif getattr(exp_val, "shape", None) is not None:
            result.shape = exp_val.shape
        ctx.bind_value_for_var(out_var, result)
