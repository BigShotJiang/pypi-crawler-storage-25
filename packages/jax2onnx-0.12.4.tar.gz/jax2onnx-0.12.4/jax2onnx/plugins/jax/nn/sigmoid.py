# jax2onnx/plugins/jax/nn/sigmoid.py

from __future__ import annotations

from typing import Callable, ClassVar, Final

import jax
from jax.interpreters import ad
import jax.numpy as jnp
from jax.extend.core import Primitive
from numpy.typing import ArrayLike

from jax2onnx.plugins._post_check_onnx_graph import expect_graph as EG
from jax2onnx.plugins._patching import AssignSpec, MonkeyPatchSpec
from jax2onnx.converter.typing_support import LoweringContextProtocol
from jax2onnx.plugins.jax._autodiff_utils import register_jvp_rule
from jax2onnx.plugins.plugin_system import PrimitiveLeafPlugin, register_primitive
from jax2onnx.plugins.jax.nn._builder_utils import (
    lower_unary_elementwise,
    register_unary_elementwise_batch_rule,
)


_SIGMOID_PRIM: Final[Primitive] = Primitive("jax.nn.sigmoid")
_SIGMOID_PRIM.multiple_results = False
_JAX_SIGMOID_ORIG: Final = jax.nn.sigmoid


@register_primitive(
    jaxpr_primitive=_SIGMOID_PRIM.name,
    jax_doc="https://jax.readthedocs.io/en/latest/_autosummary/jax.nn.sigmoid.html",
    onnx=[
        {
            "component": "Sigmoid",
            "doc": "https://onnx.ai/onnx/operators/onnx__Sigmoid.html",
        }
    ],
    since="0.7.1",
    context="primitives.nn",
    component="sigmoid",
    testcases=[
        {
            "testcase": "jaxnn_sigmoid",
            "callable": lambda x: jax.nn.sigmoid(x),
            "input_shapes": [(1,)],
            "post_check_onnx_graph": EG(
                ["Sigmoid:1"],
                no_unused_inputs=True,
            ),
        },
        {
            "testcase": "jaxnn_sigmoid_1",
            "callable": lambda x: jax.nn.sigmoid(x),
            "input_shapes": [(2, 5)],
            "post_check_onnx_graph": EG(
                ["Sigmoid:2x5"],
                no_unused_inputs=True,
            ),
        },
        {
            "testcase": "sigmoid_grad_issue_batch_diff_rules",
            "callable": lambda x: jax.grad(lambda y: jnp.sum(jax.nn.sigmoid(y) ** 2))(
                x
            ),
            "input_shapes": [(2, 3)],
            "run_only_f32_variant": True,
        },
    ],
)
class SigmoidPlugin(PrimitiveLeafPlugin):
    """Lower ``jax.nn.sigmoid`` to ONNX ``Sigmoid`` using the IR pipeline."""

    _PRIM: ClassVar[Primitive] = _SIGMOID_PRIM
    _ABSTRACT_EVAL_BOUND: ClassVar[bool] = False

    @staticmethod
    def abstract_eval(x: jax.core.AbstractValue) -> jax.core.ShapedArray:
        return jax.core.ShapedArray(x.shape, x.dtype)

    def lower(self, ctx: LoweringContextProtocol, eqn: jax.core.JaxprEqn) -> None:
        lower_unary_elementwise(
            ctx,
            eqn,
            op_name="Sigmoid",
            input_hint="sigmoid_in",
            output_hint="sigmoid_out",
        )

    @classmethod
    def ensure_abstract_eval_bound(cls) -> None:
        if not cls._ABSTRACT_EVAL_BOUND:
            cls._PRIM.def_abstract_eval(cls.abstract_eval)
            cls._ABSTRACT_EVAL_BOUND = True

    @classmethod
    def binding_specs(cls) -> list[AssignSpec | MonkeyPatchSpec]:
        def _make_value(
            orig: Callable[..., ArrayLike] | None,
        ) -> Callable[..., ArrayLike]:
            if orig is None:
                raise RuntimeError("Original jax.nn.sigmoid not found")
            return lambda *args, **kwargs: cls._PRIM.bind(*args, **kwargs)

        return [
            AssignSpec("jax.nn", "sigmoid_p", cls._PRIM, delete_if_missing=True),
            MonkeyPatchSpec(
                target="jax.nn",
                attr="sigmoid",
                make_value=_make_value,
                delete_if_missing=False,
            ),
            MonkeyPatchSpec(
                target="flax.linen.activation",
                attr="sigmoid",
                make_value=_make_value,
                delete_if_missing=False,
            ),
            MonkeyPatchSpec(
                target="flax.linen",
                attr="sigmoid",
                make_value=_make_value,
                delete_if_missing=False,
            ),
        ]


@SigmoidPlugin._PRIM.def_impl
def _sigmoid_impl(x: ArrayLike) -> ArrayLike:
    return _JAX_SIGMOID_ORIG(x)


register_unary_elementwise_batch_rule(SigmoidPlugin._PRIM)


def _sigmoid_jvp_rule(
    primals: tuple[ArrayLike, ...], tangents: tuple[ArrayLike, ...], **_: object
) -> tuple[ArrayLike, ArrayLike]:
    (x,) = primals
    (x_dot,) = tangents
    x_dot = ad.instantiate_zeros(x_dot)

    one = jnp.asarray(1.0, dtype=x.dtype)
    neg_x = jax.lax.neg(x)
    denom = jax.lax.add(one, jax.lax.exp(neg_x))
    primal_out = jax.lax.div(one, denom)

    one_minus = jax.lax.sub(one, primal_out)
    local_grad = jax.lax.mul(primal_out, one_minus)
    tangent_out = jax.lax.mul(x_dot, local_grad)
    return primal_out, tangent_out


register_jvp_rule(SigmoidPlugin._PRIM, _sigmoid_jvp_rule)
