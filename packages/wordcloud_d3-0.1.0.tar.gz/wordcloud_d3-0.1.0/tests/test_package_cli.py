from __future__ import annotations

from pathlib import Path
import tomllib

from wordcloud_d3 import __version__
from wordcloud_d3.cli import main, parse_args, render_html


def test_package_exposes_version() -> None:
    assert __version__


def test_pyproject_uses_wordcloud_d3_distribution_and_cli() -> None:
    metadata = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))

    assert metadata["project"]["name"] == "wordcloud-d3"
    assert metadata["project"]["scripts"]["wordcloud-d3"] == "wordcloud_d3.cli:main"


def test_project_metadata_uses_pipicat_and_mit_license() -> None:
    metadata = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    license_text = Path("LICENSE").read_text(encoding="utf-8")

    assert metadata["project"]["authors"] == [{"name": "PiPiCat"}]
    assert metadata["project"]["license"] == "MIT"
    assert metadata["project"]["license-files"] == ["LICENSE"]
    assert "MIT License" in license_text
    assert "Copyright (c) 2026 PiPiCat" in license_text


def test_parse_args_accepts_aspect_ratio_alias_and_defaults_to_jieba(tmp_path: Path) -> None:
    input_path = tmp_path / "freq.txt"
    input_path.write_text("alpha 3\nbeta 2\n", encoding="utf-8")

    args = parse_args([str(input_path), "--mode", "freq", "--asp-ratio", "9:16"])

    assert args.aspect_ratio == "9:16"
    assert args.nlp_backend == "jieba"


def test_parse_args_accepts_any_spacy_model_name(tmp_path: Path) -> None:
    input_path = tmp_path / "text.txt"
    input_path.write_text("hello world", encoding="utf-8")

    args = parse_args(
        [
            str(input_path),
            "--nlp-backend",
            "spacy",
            "--spacy-model",
            "en_core_web_lg",
        ]
    )

    assert args.nlp_backend == "spacy"
    assert args.spacy_model == "en_core_web_lg"


def test_render_html_contains_png_download_controls_and_requested_aspect_ratio() -> None:
    page = render_html(
        words=[{"text": "alpha", "count": 3, "rank": 1}],
        title="Demo Cloud",
        subtitle="one word",
        background_text="",
        red_ratio=0.1,
        gray_ratio=0.25,
        vertical_ratio=0.2,
        aspect_ratio="16:9",
    )

    assert "--cloud-aspect: 16 / 9" in page
    assert 'id="savePngBtn"' in page
    assert "downloadPng" in page
    assert "toDataURL(\"image/png\")" in page


def test_cli_freq_mode_writes_html_with_png_export(tmp_path: Path) -> None:
    input_path = tmp_path / "counts.txt"
    output_path = tmp_path / "cloud.html"
    input_path.write_text("alpha 3\nbeta 2\n", encoding="utf-8")

    result = main(
        [
            str(input_path),
            "--mode",
            "freq",
            "--output",
            str(output_path),
            "--title",
            "Demo Cloud",
            "--aspect-ratio",
            "1:1",
        ]
    )

    assert result == 0
    page = output_path.read_text(encoding="utf-8")
    assert "Demo Cloud" in page
    assert "--cloud-aspect: 1 / 1" in page
    assert 'id="savePngBtn"' in page
