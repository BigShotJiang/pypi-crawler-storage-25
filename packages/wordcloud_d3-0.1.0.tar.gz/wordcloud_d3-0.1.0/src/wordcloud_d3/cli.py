from __future__ import annotations

import argparse
import csv
import html
import importlib
import json
import multiprocessing
import os
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Iterable

try:
    import ahocorasick
except ImportError:  # pragma: no cover - optional speed-up
    ahocorasick = None

try:
    import jieba
except ImportError:  # pragma: no cover - installed through requirements.txt
    jieba = None

try:
    import spacy
except ImportError:  # pragma: no cover - installed through requirements.txt
    spacy = None


PACKAGE_ROOT = Path(__file__).resolve().parent


def resource_root() -> Path:
    return Path(getattr(sys, "_MEIPASS", PACKAGE_ROOT))


def resource_path(*parts: str) -> Path:
    return resource_root().joinpath(*parts)


DEFAULT_LEXICON = resource_path("data", "processed", "idiom_lexicon.csv")
DEFAULT_RESULTS_DIR = Path("results")
DEFAULT_SPACY_MODEL = "zh_core_web_sm"
DEFAULT_POS_FILTER = "NOUN,PROPN,VERB"
DEFAULT_ENTITY_FILTER = "PERSON,ORG,GPE,LOC,FAC,NORP"
VALID_TOKEN_RE = re.compile(r"^[\u4e00-\u9fffA-Za-z0-9]+$")
HEX_COLOR_RE = re.compile(r"^#[0-9a-fA-F]{6}$")
DEFAULT_ASPECT_RATIO = "3:2"
COMMON_ASPECT_RATIOS = {
    "1:1": (1, 1),
    "4:3": (4, 3),
    "3:2": (3, 2),
    "16:9": (16, 9),
    "3:4": (3, 4),
    "2:3": (2, 3),
    "9:16": (9, 16),
}
DEFAULT_HIGH_COLOR = "#d62828"
DEFAULT_LOW_COLOR = "#111111"
DEFAULT_BACKGROUND_COLOR = "#fafaf6"
D3_VENDOR_FILE = "d3.v7.min.js"
D3_CLOUD_VENDOR_FILE = "d3.layout.cloud-1.2.7.min.js"

# Keep this source file ASCII-only so it survives Windows console encodings.
DEFAULT_STOPWORDS = set(
    """
    \u7684 \u5f97 \u5730 \u4e86 \u7740 \u8fc7
    \u548c \u4e0e \u53ca \u6216 \u800c \u5e76 \u4f46
    \u4e5f \u90fd \u5c31 \u8fd8 \u53c8 \u518d \u5f88 \u66f4 \u6700
    \u5728 \u662f \u4e3a \u4ee5 \u4e8e \u5bf9 \u628a \u88ab
    \u4ece \u5411 \u5230 \u7531 \u5c06 \u7b49 \u4e2d \u4e0a \u4e0b
    \u5185 \u5916 \u524d \u540e \u8fd9 \u90a3
    \u8fd9\u4e2a \u90a3\u4e2a \u8fd9\u4e9b \u90a3\u4e9b
    \u6211\u4eec \u4f60\u4eec \u4ed6\u4eec \u5979\u4eec \u5b83\u4eec
    \u81ea\u5df1 \u4e00\u4e2a \u4e00\u79cd \u4e00\u4e9b
    \u6709\u5173 \u8fdb\u884c \u8868\u793a \u901a\u8fc7 \u4ee5\u53ca
    \u56e0\u4e3a \u6240\u4ee5 \u5982\u679c \u540c\u65f6 \u5176\u4e2d
    \u6ca1\u6709 \u4e0d\u662f \u53ef\u4ee5 \u5df2\u7ecf
    \u4eca\u5929 \u6628\u5929 \u660e\u5929
    the and or of to in a an is are was were be been being
    cite
    """
    .split()
)


def normalize_aspect_ratio(value: str | None, default: str = DEFAULT_ASPECT_RATIO) -> str:
    text = str(value or default).strip()
    return text if text in COMMON_ASPECT_RATIOS else default


def aspect_ratio_parts(value: str | None) -> tuple[int, int]:
    return COMMON_ASPECT_RATIOS[normalize_aspect_ratio(value)]


def normalize_hex_color(value: str | None, default: str) -> str:
    text = str(value or "").strip()
    if HEX_COLOR_RE.fullmatch(text):
        return text.lower()
    return default


def _hex_to_rgb(value: str) -> tuple[int, int, int]:
    color = normalize_hex_color(value, DEFAULT_LOW_COLOR).lstrip("#")
    return int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)


def _rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return "#" + "".join(f"{max(0, min(255, channel)):02x}" for channel in rgb)


def blend_hex_colors(start: str, end: str, end_weight: float) -> str:
    start_rgb = _hex_to_rgb(start)
    end_rgb = _hex_to_rgb(end)
    weight = max(0.0, min(1.0, end_weight))
    mixed = tuple(round(a * (1.0 - weight) + b * weight) for a, b in zip(start_rgb, end_rgb))
    return _rgb_to_hex(mixed)


def relative_luminance(value: str) -> float:
    def channel_luminance(channel: int) -> float:
        normalized = channel / 255
        if normalized <= 0.03928:
            return normalized / 12.92
        return ((normalized + 0.055) / 1.055) ** 2.4

    red, green, blue = _hex_to_rgb(value)
    return (
        0.2126 * channel_luminance(red)
        + 0.7152 * channel_luminance(green)
        + 0.0722 * channel_luminance(blue)
    )


def background_word_color(background_color: str, low_color: str) -> str:
    background_luminance = relative_luminance(background_color)
    low_luminance = relative_luminance(low_color)
    if background_luminance < 0.5:
        target = low_color if low_luminance - background_luminance >= 0.30 else "#ffffff"
        return blend_hex_colors(background_color, target, 0.16)
    target = low_color if background_luminance - low_luminance >= 0.30 else "#000000"
    return blend_hex_colors(background_color, target, 0.08)


def read_text(path: Path) -> str:
    failures: list[str] = []
    for encoding in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return path.read_text(encoding=encoding)
        except UnicodeDecodeError as exc:
            failures.append(f"{encoding}: {exc}")
            continue
    text = path.read_text(encoding="utf-8", errors="replace")
    replacement_count = text.count("\ufffd")
    print(
        f"warning: {path} could not be decoded cleanly; "
        f"using utf-8 with {replacement_count} replacement characters.",
        file=sys.stderr,
    )
    if failures:
        print(f"decode attempts failed: {' | '.join(failures[:3])}", file=sys.stderr)
    return text


def vendor_script_path(filename: str) -> Path:
    return resource_path("vendor", filename)


def read_vendor_script(filename: str) -> str:
    path = vendor_script_path(filename)
    if not path.exists():
        raise FileNotFoundError(f"vendor script not found: {path}")
    return path.read_text(encoding="utf-8")


def inline_script(script: str) -> str:
    return script.replace("</script", "<\\/script")


def load_idiom_words(path: Path) -> list[str]:
    if not path.exists():
        raise FileNotFoundError(f"idiom lexicon not found: {path}")

    words: list[str] = []
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        field = "word" if reader.fieldnames and "word" in reader.fieldnames else None
        if field:
            words = [row[field].strip() for row in reader if row.get(field, "").strip()]
        else:
            handle.seek(0)
            raw_reader = csv.reader(handle)
            words = [row[0].strip() for row in raw_reader if row and row[0].strip()]

    return sorted(set(words), key=lambda value: (-len(value), value))


def build_automaton(words: Iterable[str]):
    if ahocorasick is None:
        return None
    automaton = ahocorasick.Automaton()
    for word in words:
        automaton.add_word(word, word)
    automaton.make_automaton()
    return automaton


def count_idioms(text: str, idioms: list[str]) -> Counter[str]:
    counts: Counter[str] = Counter()
    automaton = build_automaton(idioms)
    if automaton is not None:
        for _, word in automaton.iter(text):
            counts[word] += 1
        return counts

    for word in idioms:
        count = text.count(word)
        if count:
            counts[word] = count
    return counts


def parse_frequency_text(text: str) -> Counter[str]:
    counts: Counter[str] = Counter()
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = re.split(r"[\t,\uFF0C ]+", line)
        if len(parts) < 2:
            continue
        word = parts[0].strip()
        try:
            count = int(float(parts[1]))
        except ValueError:
            continue
        if word and count > 0:
            counts[word] += count
    return counts


def load_stopwords(path: Path | None = None) -> set[str]:
    stopwords = set(DEFAULT_STOPWORDS)
    if path is None:
        return stopwords
    if not path.exists():
        raise FileNotFoundError(f"stopwords file not found: {path}")
    for line in read_text(path).splitlines():
        word = line.strip()
        if word and not word.startswith("#"):
            stopwords.add(word)
    return stopwords


def is_valid_display_token(token: str, min_chars: int, stopwords: set[str]) -> bool:
    if not token:
        return False
    if token in stopwords:
        return False
    if len(token) < min_chars:
        return False
    if token.isdigit():
        return False
    return bool(VALID_TOKEN_RE.fullmatch(token))


def tokenize_words(text: str, stopwords: set[str], min_chars: int) -> Counter[str]:
    if jieba is None:
        raise RuntimeError("jieba is required for --mode words. Install it with: pip install jieba")

    counts: Counter[str] = Counter()
    for raw_token in jieba.cut(text, cut_all=False):
        token = raw_token.strip().lower()
        if not is_valid_display_token(token, min_chars, stopwords):
            continue
        counts[token] += 1
    return counts


def parse_filter_csv(value: str) -> set[str]:
    return {item.strip().upper() for item in value.split(",") if item.strip()}


def normalize_token(value: str) -> str:
    return re.sub(r"\s+", "", value.strip().lower())


def iter_text_chunks(text: str, max_chars: int) -> Iterable[str]:
    if max_chars <= 0:
        yield text
        return

    buffer: list[str] = []
    buffer_len = 0
    for part in re.split(r"([\u3002\uff01\uff1f!?\uff1b;\n]+)", text):
        if not part:
            continue
        if len(part) > max_chars:
            if buffer:
                yield "".join(buffer)
                buffer = []
                buffer_len = 0
            for start in range(0, len(part), max_chars):
                yield part[start : start + max_chars]
            continue
        if buffer and buffer_len + len(part) > max_chars:
            yield "".join(buffer)
            buffer = []
            buffer_len = 0
        buffer.append(part)
        buffer_len += len(part)

    if buffer:
        yield "".join(buffer)


def disable_spacy_parser(nlp):
    if "parser" in nlp.pipe_names:
        nlp.disable_pipe("parser")
    return nlp


def load_spacy_model(model_name: str):
    try:
        if model_name == DEFAULT_SPACY_MODEL:
            model_package = importlib.import_module(DEFAULT_SPACY_MODEL)
            return disable_spacy_parser(model_package.load())
    except (ImportError, OSError):
        pass

    if spacy is None:
        raise RuntimeError("spaCy is required for --nlp-backend spacy. Install it with: pip install spacy")
    try:
        nlp = spacy.load(model_name)
    except OSError as exc:
        raise RuntimeError(
            f"spaCy model '{model_name}' is not installed. "
            f"Run: python -m spacy download {model_name}"
        ) from exc
    return disable_spacy_parser(nlp)


def resolve_n_process(value: int) -> int:
    if value == 0:
        cpu_count = os.cpu_count() or 2
        return max(1, min(4, cpu_count - 1))
    return max(1, value)


def update_counts_from_spacy_doc(
    doc,
    *,
    counts: Counter[str],
    stopwords: set[str],
    min_chars: int,
    allowed_pos: set[str],
    allowed_entities: set[str],
) -> None:
    entity_token_indexes: set[int] = set()

    for ent in doc.ents:
        label = ent.label_.upper()
        token = normalize_token(ent.text)
        if label not in allowed_entities:
            continue
        if not is_valid_display_token(token, min_chars, stopwords):
            continue
        counts[token] += 1
        entity_token_indexes.update(range(ent.start, ent.end))

    for index, token_obj in enumerate(doc):
        if index in entity_token_indexes:
            continue
        token = normalize_token(token_obj.text)
        if token_obj.is_space or token_obj.is_punct or token_obj.like_num:
            continue
        if token_obj.pos_.upper() not in allowed_pos:
            continue
        if not is_valid_display_token(token, min_chars, stopwords):
            continue
        counts[token] += 1


def tokenize_spacy_words(
    text: str,
    *,
    stopwords: set[str],
    min_chars: int,
    model_name: str,
    allowed_pos: set[str],
    allowed_entities: set[str],
    chunk_chars: int,
    batch_size: int,
    n_process: int,
    progress: bool,
) -> Counter[str]:
    nlp = load_spacy_model(model_name)
    chunks = [chunk for chunk in iter_text_chunks(text, chunk_chars) if chunk.strip()]
    if not chunks:
        return Counter()

    nlp.max_length = max(nlp.max_length, max(len(chunk) for chunk in chunks) + 100)
    counts: Counter[str] = Counter()
    total = len(chunks)
    if progress:
        print(
            f"spaCy chunks={total} chunk_chars={chunk_chars} "
            f"batch_size={max(1, batch_size)} n_process={n_process}",
            file=sys.stderr,
        )
    for index, doc in enumerate(
        nlp.pipe(chunks, batch_size=max(1, batch_size), n_process=n_process),
        start=1,
    ):
        update_counts_from_spacy_doc(
            doc,
            counts=counts,
            stopwords=stopwords,
            min_chars=min_chars,
            allowed_pos=allowed_pos,
            allowed_entities=allowed_entities,
        )
        if progress and (index == 1 or index == total or index % 25 == 0):
            print(f"spaCy chunks {index}/{total}", file=sys.stderr)
    return counts


def top_words(counts: Counter[str], max_words: int) -> list[dict[str, int | str]]:
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:max_words]
    return [
        {
            "text": word,
            "count": int(count),
            "rank": index + 1,
        }
        for index, (word, count) in enumerate(ranked)
    ]


def render_html(
    *,
    words: list[dict[str, int | str]],
    title: str,
    subtitle: str,
    background_text: str,
    red_ratio: float,
    gray_ratio: float,
    vertical_ratio: float,
    aspect_ratio: str = DEFAULT_ASPECT_RATIO,
    high_color: str = DEFAULT_HIGH_COLOR,
    low_color: str = DEFAULT_LOW_COLOR,
    background_color: str = DEFAULT_BACKGROUND_COLOR,
) -> str:
    aspect_ratio = normalize_aspect_ratio(aspect_ratio)
    aspect_width, aspect_height = aspect_ratio_parts(aspect_ratio)
    aspect_css = f"{aspect_width} / {aspect_height}"
    aspect_number = f"{aspect_width / aspect_height:.6g}"
    high_color = normalize_hex_color(high_color, DEFAULT_HIGH_COLOR)
    low_color = normalize_hex_color(low_color, DEFAULT_LOW_COLOR)
    background_color = normalize_hex_color(background_color, DEFAULT_BACKGROUND_COLOR)
    low_soft_color = blend_hex_colors(low_color, background_color, 0.42)
    low_muted_color = blend_hex_colors(low_color, background_color, 0.68)
    background_word_color_value = background_word_color(background_color, low_color)
    words_json = json.dumps(words, ensure_ascii=False, separators=(",", ":"))
    title_json = json.dumps(title, ensure_ascii=False)
    subtitle_json = json.dumps(subtitle, ensure_ascii=False)
    background_json = json.dumps(background_text, ensure_ascii=False)
    red_ratio_json = json.dumps(red_ratio)
    gray_ratio_json = json.dumps(gray_ratio)
    vertical_ratio_json = json.dumps(vertical_ratio)
    title_html = html.escape(title)
    d3_script = inline_script(read_vendor_script(D3_VENDOR_FILE))
    d3_cloud_script = inline_script(read_vendor_script(D3_CLOUD_VENDOR_FILE))

    return f"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>{title_html}</title>
  <style>
    :root {{
      color-scheme: light;
      --low-color: {low_color};
      --high-color: {high_color};
      --low-soft-color: {low_soft_color};
      --low-muted-color: {low_muted_color};
      --background-color: {background_color};
      --background-word-color: {background_word_color_value};
      --cloud-aspect: {aspect_css};
      --cloud-ratio: {aspect_number};
    }}
    * {{ box-sizing: border-box; }}
    body {{
      margin: 0;
      min-height: 100vh;
      display: grid;
      grid-template-rows: auto 1fr;
      background: var(--background-color);
      color: var(--low-color);
      font-family: "PingFang SC", "Source Han Sans CN", "Microsoft YaHei", "SimHei", "Heiti SC", sans-serif;
    }}
    .topbar {{
      display: flex;
      align-items: center;
      gap: 18px;
      padding: 14px 24px;
      background: var(--background-color);
      border-bottom: 2px solid var(--low-color);
      flex-wrap: wrap;
    }}
    h1 {{ margin: 0; font-size: 18px; font-weight: 900; letter-spacing: 0; }}
    #summary {{ font-size: 12px; color: var(--low-soft-color); }}
    #cloud {{
      position: relative;
      width: min(100%, calc((100vh - 64px) * var(--cloud-ratio)));
      aspect-ratio: var(--cloud-aspect);
      align-self: start;
      justify-self: center;
      overflow: hidden;
      background: var(--background-color);
    }}
    #cloud svg {{ display: block; width: 100%; height: 100%; }}
    .background-text {{
      fill: var(--background-word-color);
      font-weight: 900;
      pointer-events: none;
      user-select: none;
    }}
    .word {{
      font-weight: 900;
      paint-order: stroke fill;
      stroke: rgba(0,0,0,0);
    }}
    .word.red {{ fill: var(--high-color); }}
    .word.dark {{ fill: var(--low-color); }}
    .word.gray {{ fill: var(--low-soft-color); }}
    .word.muted {{ fill: var(--low-muted-color); }}
    #status {{
      font-size: 12px;
      color: var(--low-muted-color);
      letter-spacing: 0;
    }}
    .topbar-actions {{
      margin-left: auto;
      display: flex;
      align-items: center;
      gap: 8px;
    }}
    button {{
      appearance: none;
      border: 2px solid var(--low-color);
      background: var(--low-color);
      color: var(--background-color);
      min-height: 32px;
      padding: 0 12px;
      font: inherit;
      font-size: 12px;
      font-weight: 900;
      cursor: pointer;
    }}
    button:disabled {{
      cursor: wait;
      opacity: 0.45;
    }}
    @media (max-width: 700px) {{
      body {{ grid-template-rows: auto minmax(0, 1fr); }}
      .topbar {{
        display: grid;
        grid-template-columns: 1fr;
        gap: 6px;
        padding: 10px 12px;
      }}
      h1 {{ font-size: 15px; line-height: 1.2; }}
      #summary {{ font-size: 11px; }}
      .topbar-actions {{ margin-left: 0; }}
      button {{ width: 100%; }}
      #cloud {{
        width: min(100%, calc((100svh - 80px) * var(--cloud-ratio)));
      }}
    }}
  </style>
</head>
<body>
  <div class="topbar">
    <h1 id="title"></h1>
    <span id="summary"></span>
    <span id="status">loading...</span>
    <div class="topbar-actions">
      <button id="savePngBtn" type="button" disabled>Save PNG</button>
    </div>
  </div>
  <div id="cloud"></div>
  <script>
    /* Bundled D3 v7; d3.version is available at runtime. */
{d3_script}
  </script>
  <script>
{d3_cloud_script}
  </script>
  <script>
    const titleText = {title_json};
    const subtitleText = {subtitle_json};
    const backgroundText = {background_json};
    const redRatioSetting = {red_ratio_json};
    const grayRatioSetting = {gray_ratio_json};
    const verticalRatioSetting = {vertical_ratio_json};
    const words = {words_json};

    const cloud = document.getElementById("cloud");
    const titleEl = document.getElementById("title");
    const summaryEl = document.getElementById("summary");
    const statusEl = document.getElementById("status");
    const savePngBtn = document.getElementById("savePngBtn");

    titleEl.textContent = titleText;
    summaryEl.textContent = subtitleText;

    const SMALL = 13;
    let BIG = 100;
    let GMAX = 1;
    let layout = null;

    function isMobileViewport() {{
      return window.matchMedia("(max-width: 700px)").matches;
    }}

    function dims() {{
      const r = cloud.getBoundingClientRect();
      const mobile = isMobileViewport();
      return {{
        w: Math.max(mobile ? 360 : 640, Math.round(r.width)),
        h: Math.max(mobile ? 480 : 560, Math.round(r.height)),
      }};
    }}

    function stableHash(text) {{
      let hash = 2166136261;
      for (let i = 0; i < text.length; i += 1) {{
        hash ^= text.charCodeAt(i);
        hash = Math.imul(hash, 16777619);
      }}
      return hash >>> 0;
    }}

    function makeRandom(seed) {{
      let state = seed >>> 0;
      return () => {{
        state += 0x6D2B79F5;
        let value = Math.imul(state ^ (state >>> 15), 1 | state);
        value ^= value + Math.imul(value ^ (value >>> 7), 61 | value);
        return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
      }};
    }}

    function clampRatio(value) {{
      const number = Number(value);
      if (!Number.isFinite(number)) return 0;
      return Math.max(0, Math.min(1, number));
    }}

    function buildClassMap(list) {{
      const total = list.length;
      const redRatio = clampRatio(redRatioSetting);
      const grayRatio = clampRatio(grayRatioSetting);
      const redLimit = redRatio <= 0 ? 0 : Math.min(total, Math.max(1, Math.round(total * redRatio)));
      const grayLimit = Math.min(total - redLimit, Math.round(total * grayRatio));
      const classMap = new Map();

      list.forEach((d, index) => {{
        if (index < redLimit) classMap.set(d.text, "red");
      }});

      const grayCandidates = list
        .slice(redLimit)
        .map(d => ({{ text: d.text, hash: stableHash(d.text) }}))
        .sort((a, b) => a.hash - b.hash)
        .slice(0, grayLimit);

      grayCandidates.forEach(d => {{
        classMap.set(d.text, stableHash(`${{d.text}}-tone`) % 3 === 0 ? "muted" : "gray");
      }});

      list.forEach(d => {{
        if (!classMap.has(d.text)) classMap.set(d.text, "dark");
      }});

      return classMap;
    }}

    function buildVerticalMap(list) {{
      const mobile = isMobileViewport();
      const topLock = mobile ? 10 : 12;
      const verticalRatio = clampRatio(verticalRatioSetting);
      const candidateTotal = Math.max(0, list.length - topLock);
      const verticalLimit = Math.min(candidateTotal, Math.round(list.length * verticalRatio));
      const rotateMap = new Map();
      if (verticalLimit <= 0) return rotateMap;

      list
        .slice(topLock)
        .map(d => ({{ text: d.text, hash: stableHash(`${{d.text}}-rotate`) }}))
        .sort((a, b) => a.hash - b.hash)
        .slice(0, verticalLimit)
        .forEach(d => {{
          rotateMap.set(d.text, d.hash % 2 === 0 ? -90 : 90);
        }});

      return rotateMap;
    }}

    function sizeFor(count) {{
      if (!count || count <= 0) return 0;
      return SMALL + (BIG - SMALL) * Math.sqrt(count / GMAX);
    }}

    function interleaveForLayout(list) {{
      const total = list.length;
      const mobile = isMobileViewport();
      const frontSize = Math.min(total, Math.max(mobile ? 28 : 40, Math.round(total * 0.45)));
      const lanes = mobile ? 3 : 4;
      const rows = Math.ceil(frontSize / lanes);
      const ordered = [];
      const used = new Set();
      for (let row = 0; row < rows; row += 1) {{
        for (let lane = 0; lane < lanes; lane += 1) {{
          const index = lane * rows + row;
          if (index < frontSize && index < total) {{
            ordered.push(list[index]);
            used.add(index);
          }}
        }}
      }}
      for (let index = 0; index < total; index += 1) {{
        if (!used.has(index)) ordered.push(list[index]);
      }}
      return ordered;
    }}

    function buildLayout() {{
      const {{ w, h }} = dims();
      const area = w * h;
      const mobile = isMobileViewport();
      const margin = mobile ? 22 : 16;
      const layoutW = Math.max(mobile ? 332 : 720, w - margin * 2);
      const layoutH = Math.max(mobile ? 430 : 500, h - margin * 2);
      BIG = Math.max(mobile ? 24 : 48, Math.min(mobile ? 38 : 74, Math.sqrt(area) / (mobile ? 20 : 15)));
      GMAX = words.length ? Math.max(...words.map(d => d.count)) : 1;
      const seed = words.reduce((acc, d, i) => (acc ^ ((stableHash(d.text) + Math.imul(i + 1, 2654435761)) >>> 0)) >>> 0, 0x9E3779B9);
      const classMap = buildClassMap(words);
      const verticalMap = buildVerticalMap(words);
      const items = interleaveForLayout(words).map((d) => {{
        return {{
        text: d.text,
        count: d.count,
        rank: d.rank,
        rotate: verticalMap.get(d.text) || 0,
        size: sizeFor(d.count),
        cls: classMap.get(d.text) || "dark",
        }};
      }});

      return new Promise(resolve => {{
        d3.layout.cloud()
          .size([layoutW, layoutH])
          .words(items)
          .padding(mobile ? 0.15 : 0.55)
          .spiral("rectangular")
          .rotate(d => d.rotate)
          .font("PingFang SC, Microsoft YaHei, SimHei, sans-serif")
          .fontWeight(900)
          .fontSize(d => d.size)
          .random(makeRandom(seed))
          .on("end", placed => {{
            layout = {{ width: w, height: h, words: placed, attempted: items.length }};
            resolve(layout);
          }})
          .start();
      }});
    }}

    function mount() {{
      cloud.innerHTML = "";
      const viewPad = isMobileViewport() ? 42 : 0;
      const svg = d3.select(cloud).append("svg")
        .attr("viewBox", `${{-viewPad}} 0 ${{layout.width + viewPad * 2}} ${{layout.height}}`)
        .attr("preserveAspectRatio", "xMidYMid meet");
      if (backgroundText) {{
        svg.append("text")
          .attr("class", "background-text")
          .attr("x", layout.width / 2)
          .attr("y", layout.height / 2)
          .attr("text-anchor", "middle")
          .attr("dominant-baseline", "middle")
          .attr("font-size", Math.min(layout.width, layout.height) * (isMobileViewport() ? 0.72 : 0.42))
          .text(backgroundText);
      }}
      const centerG = svg.append("g")
        .attr("transform", `translate(${{layout.width / 2}},${{layout.height / 2}})`);
      centerG.selectAll("text.word")
        .data(layout.words, d => d.text)
        .enter().append("text")
          .attr("class", d => `word ${{d.cls}}`)
          .attr("text-anchor", "middle")
          .attr("transform", d => `translate(${{d.x}},${{d.y}})rotate(${{d.rotate}})`)
          .attr("font-size", d => d.size)
          .style("opacity", 1)
          .text(d => d.text)
          .append("title").text(d => `${{d.text}}: ${{d.count}}`);
      statusEl.textContent = `${{words.length}} \u8bcd \\u00b7 \u8bcd\u5e93 ${{layout.words.length}}/${{layout.attempted}}`;
      savePngBtn.disabled = false;
    }}

    function safePngName(value) {{
      const base = String(value || "wordcloud")
        .trim()
        .replace(/\\.[^.]+$/, "")
        .replace(/[\\/:*?"<>|]+/g, "-")
        .replace(/\\s+/g, "-");
      return `${{base || "wordcloud"}}.png`;
    }}

    function svgBackgroundColor() {{
      return getComputedStyle(cloud).backgroundColor || "{background_color}";
    }}

    function inlineSvgComputedStyles(sourceSvg, targetSvg) {{
      const sourceNodes = [sourceSvg, ...sourceSvg.querySelectorAll("*")];
      const targetNodes = [targetSvg, ...targetSvg.querySelectorAll("*")];
      sourceNodes.forEach((source, index) => {{
        const target = targetNodes[index];
        if (!target) return;
        const styles = getComputedStyle(source);
        target.setAttribute("fill", styles.fill);
        target.setAttribute("stroke", styles.stroke);
        target.setAttribute("font-family", styles.fontFamily);
        target.setAttribute("font-size", styles.fontSize);
        target.setAttribute("font-weight", styles.fontWeight);
        target.setAttribute("opacity", styles.opacity);
        target.style.fill = styles.fill;
        target.style.stroke = styles.stroke;
        target.style.fontFamily = styles.fontFamily;
        target.style.fontSize = styles.fontSize;
        target.style.fontWeight = styles.fontWeight;
        target.style.opacity = styles.opacity;
        target.style.paintOrder = styles.paintOrder;
      }});
    }}

    function svgToPngDataUrl(svg) {{
      return new Promise((resolve, reject) => {{
        if (!svg) {{
          reject(new Error("No word-cloud SVG is ready to export."));
          return;
        }}
        const clone = svg.cloneNode(true);
        clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
        inlineSvgComputedStyles(svg, clone);
        const viewBox = String(svg.getAttribute("viewBox") || `0 0 ${{svg.clientWidth}} ${{svg.clientHeight}}`)
          .split(/\\s+/)
          .map(Number);
        const width = Math.max(800, Math.round(viewBox[2] || svg.clientWidth || 1200));
        const height = Math.max(600, Math.round(viewBox[3] || svg.clientHeight || 800));
        clone.setAttribute("width", String(width));
        clone.setAttribute("height", String(height));
        const xml = new XMLSerializer().serializeToString(clone);
        const blob = new Blob([xml], {{ type: "image/svg+xml;charset=utf-8" }});
        const url = URL.createObjectURL(blob);
        const image = new Image();
        image.onload = () => {{
          const scale = 2;
          const canvas = document.createElement("canvas");
          canvas.width = width * scale;
          canvas.height = height * scale;
          const ctx = canvas.getContext("2d");
          ctx.fillStyle = svgBackgroundColor();
          ctx.fillRect(0, 0, canvas.width, canvas.height);
          ctx.scale(scale, scale);
          ctx.drawImage(image, 0, 0, width, height);
          URL.revokeObjectURL(url);
          resolve(canvas.toDataURL("image/png"));
        }};
        image.onerror = () => {{
          URL.revokeObjectURL(url);
          reject(new Error("Could not convert the SVG word cloud to PNG."));
        }};
        image.src = url;
      }});
    }}

    async function downloadPng() {{
      savePngBtn.disabled = true;
      statusEl.textContent = "exporting PNG...";
      try {{
        const dataUrl = await svgToPngDataUrl(cloud.querySelector("svg"));
        const link = document.createElement("a");
        link.download = safePngName(titleText);
        link.href = dataUrl;
        document.body.appendChild(link);
        link.click();
        link.remove();
        statusEl.textContent = "PNG saved by browser";
      }} catch (error) {{
        statusEl.textContent = error.message || String(error);
      }} finally {{
        savePngBtn.disabled = !layout;
      }}
    }}

    let resizeT = null;
    savePngBtn.addEventListener("click", downloadPng);
    window.addEventListener("resize", () => {{
      clearTimeout(resizeT);
      resizeT = setTimeout(async () => {{
        statusEl.textContent = "\u91cd\u65b0\u6392\u7248...";
        savePngBtn.disabled = true;
        await buildLayout();
        mount();
      }}, 220);
    }});

    (async () => {{
      if (!words.length) {{
        statusEl.textContent = "\u6ca1\u6709\u53ef\u663e\u793a\u7684\u8bcd";
        return;
      }}
      statusEl.textContent = "\u6392\u7248\u4e2d...";
      await buildLayout();
      mount();
    }})();
  </script>
</body>
</html>
"""


def build_word_counts(args: argparse.Namespace) -> Counter[str]:
    text = read_text(args.input)
    if args.mode == "freq":
        return parse_frequency_text(text)
    if args.mode == "words":
        stopwords = load_stopwords(args.stopwords)
        if args.nlp_backend == "spacy":
            return tokenize_spacy_words(
                text,
                stopwords=stopwords,
                min_chars=args.min_token_chars,
                model_name=args.spacy_model,
                allowed_pos=parse_filter_csv(args.pos_filter),
                allowed_entities=parse_filter_csv(args.entity_filter),
                chunk_chars=args.chunk_chars,
                batch_size=args.batch_size,
                n_process=resolve_n_process(args.n_process),
                progress=not args.quiet,
            )
        return tokenize_words(text, stopwords=stopwords, min_chars=args.min_token_chars)

    idioms = load_idiom_words(args.lexicon)
    if args.min_chars:
        idioms = [word for word in idioms if len(word) >= args.min_chars]
    return count_idioms(text, idioms)


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Generate a static D3 word-cloud HTML from a txt file.")
    parser.add_argument("input", type=Path, help="Input .txt file.")
    parser.add_argument(
        "-o",
        "--output",
        type=Path,
        help="Output .html path. Defaults to results/<input-stem>_wordcloud.html.",
    )
    parser.add_argument("--title", help="HTML title/topbar title. Defaults to input file stem.")
    parser.add_argument("--subtitle", help="Small topbar subtitle.")
    parser.add_argument("--background-text", default="", help="Optional large translucent text behind the word cloud.")
    parser.add_argument("--max-words", type=int, default=120, help="Maximum words in the cloud.")
    parser.add_argument(
        "--aspect-ratio",
        "--asp-ratio",
        dest="aspect_ratio",
        choices=tuple(COMMON_ASPECT_RATIOS),
        default=DEFAULT_ASPECT_RATIO,
        help="Canvas aspect ratio for the word-cloud area.",
    )
    parser.add_argument("--high-color", default=DEFAULT_HIGH_COLOR, help="Hex color for the highest-frequency words.")
    parser.add_argument("--low-color", default=DEFAULT_LOW_COLOR, help="Hex base color for lower-frequency words.")
    parser.add_argument("--background-color", default=DEFAULT_BACKGROUND_COLOR, help="Hex background color.")
    parser.add_argument(
        "--red-ratio",
        type=float,
        default=0.10,
        help="Share of highest-frequency words using the high-frequency color, e.g. 0.10 means the top tenth.",
    )
    parser.add_argument(
        "--gray-ratio",
        type=float,
        default=0.25,
        help="Target share of all displayed words using lighter low-frequency tones.",
    )
    parser.add_argument(
        "--vertical-ratio",
        type=float,
        default=0.20,
        help="Share of words rotated vertically. Highest-frequency locked words stay horizontal.",
    )
    parser.add_argument(
        "--mode",
        choices=("words", "idiom", "freq"),
        default="words",
        help="words: NLP tokenization with stopword/POS/entity filtering; idiom: scan txt with the idiom lexicon; freq: parse lines like 'word 12'.",
    )
    parser.add_argument(
        "--nlp-backend",
        choices=("spacy", "jieba"),
        default="jieba",
        help="NLP backend for --mode words.",
    )
    parser.add_argument(
        "--spacy-model",
        default=DEFAULT_SPACY_MODEL,
        help=(
            "Any installed spaCy pipeline name or local model path for --nlp-backend spacy, "
            "for example en_core_web_sm, en_core_web_lg, zh_core_web_sm, or a custom model directory."
        ),
    )
    parser.add_argument(
        "--pos-filter",
        default=DEFAULT_POS_FILTER,
        help="Comma-separated spaCy POS tags to keep, e.g. NOUN,PROPN,VERB.",
    )
    parser.add_argument(
        "--entity-filter",
        default=DEFAULT_ENTITY_FILTER,
        help="Comma-separated spaCy entity labels to keep as full spans, e.g. PERSON,ORG,GPE,LOC.",
    )
    parser.add_argument("--lexicon", type=Path, default=DEFAULT_LEXICON, help="Idiom lexicon CSV.")
    parser.add_argument("--min-chars", type=int, default=2, help="Minimum idiom length in idiom mode.")
    parser.add_argument("--min-token-chars", type=int, default=2, help="Minimum token length in words mode.")
    parser.add_argument("--stopwords", type=Path, help="Optional newline-delimited stopword file.")
    parser.add_argument(
        "--chunk-chars",
        type=int,
        default=50000,
        help="Characters per spaCy chunk. Use 0 to process the whole file as one document.",
    )
    parser.add_argument("--batch-size", type=int, default=16, help="spaCy pipe batch size.")
    parser.add_argument(
        "--n-process",
        type=int,
        default=1,
        help="spaCy worker processes. Use 0 for auto, or 2-4 for explicit parallel processing.",
    )
    parser.add_argument("--quiet", action="store_true", help="Hide spaCy chunk progress.")
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    multiprocessing.freeze_support()
    args = parse_args(argv)
    if not args.input.exists():
        print(f"input file not found: {args.input}", file=sys.stderr)
        return 2

    output = args.output
    if output is None:
        output = DEFAULT_RESULTS_DIR / f"{args.input.stem}_wordcloud.html"
    output.parent.mkdir(parents=True, exist_ok=True)

    counts = build_word_counts(args)
    words = top_words(counts, max_words=max(1, args.max_words))
    title = args.title or args.input.stem
    subtitle = args.subtitle or f"{len(words)} \u8bcd {chr(183)} \u6765\u6e90 {args.input.name}"
    page = render_html(
        words=words,
        title=title,
        subtitle=subtitle,
        background_text=args.background_text,
        red_ratio=args.red_ratio,
        gray_ratio=args.gray_ratio,
        vertical_ratio=args.vertical_ratio,
        aspect_ratio=args.aspect_ratio,
        high_color=args.high_color,
        low_color=args.low_color,
        background_color=args.background_color,
    )
    output.write_text(page, encoding="utf-8")

    total_hits = sum(int(word["count"]) for word in words)
    print(f"wrote {output}")
    print(f"words={len(words)} total_hits={total_hits} mode={args.mode}")
    if not words:
        print("warning: no words were found; try --mode freq or check the input text.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
