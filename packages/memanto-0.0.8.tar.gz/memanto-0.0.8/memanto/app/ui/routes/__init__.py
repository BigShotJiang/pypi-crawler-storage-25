# MEMANTO Web UI Routes
