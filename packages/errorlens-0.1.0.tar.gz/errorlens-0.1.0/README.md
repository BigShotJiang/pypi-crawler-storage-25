# ErrorLens

A CLI and TUI tool that analyzes codebases for bugs and security issues using multiple AI providers.

---

## Features

- **Multi-provider analysis** — Anthropic (Claude), Groq (Llama 3), and Mistral
- **Two interfaces** — a classic CLI for scripting and a rich Terminal UI (TUI) for interactive use
- **Parallel file processing** — analyzes directories concurrently
- **Multiple output formats** — console, JSON, and Markdown
- **12+ languages supported** — Python, JavaScript, TypeScript, Go, Rust, Java, and more

---

## Installation

**Requirements:** Python 3.8+

```bash
# Clone the repo
git clone https://github.com/your-repo/errorlens.git
cd errorlens

# Create and activate a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install the package (gives you the `errorlens` command)
pip install -e .
```

---

## Configuration

Create a `.env` file in the project root:

```bash
cat > .env << 'EOF'
ANTHROPIC_API_KEY="your-anthropic-api-key"
MISTRAL_API_KEY="your-mistral-api-key"
GROQ_API_KEY="your-groq-api-key"
EOF
```

You only need keys for the providers you plan to use.

| Provider  | Model                  | Notes                  |
|-----------|------------------------|------------------------|
| Anthropic | claude-3-opus-20240229 | Real API call          |
| Groq      | llama3-70b-8192        | Real API call          |
| Mistral   | mistral-large-latest   | Pattern-based (mock)   |

---

## CLI Usage

```bash
# Analyze a single file (all providers)
python main.py path/to/file.py

# Analyze a directory
python main.py path/to/project/

# Choose a specific provider
python main.py file.py --provider anthropic
python main.py file.py --provider groq
python main.py file.py --provider mistral

# Change output format
python main.py file.py --output json
python main.py file.py --output markdown

# Verbose logging
python main.py file.py --verbose

# If installed via pip install -e .
errorlens file.py --provider anthropic
```

### CLI Options

| Flag         | Values                              | Default  |
|--------------|-------------------------------------|----------|
| `--provider` | `anthropic`, `mistral`, `groq`, `all` | `all`  |
| `--output`   | `console`, `json`, `markdown`       | `console`|
| `--verbose`  | —                                   | off      |
| `--config`   | path to JSON config file            | —        |

### Example console output

```
ErrorLens
Analyzing: example_test.py
Provider: groq

==================================================
ERRORLENS ANALYSIS RESULTS
==================================================

File: example_test.py
Language: python
Status: SUCCESS

--- GROQ ANALYSIS ---
Security Issues:
  - Hardcoded credentials found in DB_PASSWORD and API_KEY variables
  - SQL injection vulnerability in login() function
  - Insecure deserialization using pickle.loads()
Potential Bugs:
  - Division by zero possible in complex_calculation()
Code Quality Issues:
  - Unused function detected
Suggestions:
  - Use environment variables for credentials
  - Use parameterized queries
```

---

## TUI Usage

Launch the interactive terminal interface:

```bash
python tui.py
```

### Layout

```
┌─────────────────────────────────────────────────────────┐
│  ErrorLens                                   12:00:00   │
├────────────────┬────────────────────────────────────────┤
│                │                                        │
│  Path          │  Analyzing: example_test.py            │
│  [___________] │  Provider: mistral                     │
│                │  ════════════════════════════════════  │
│  Provider      │                                        │
│  ○ anthropic   │  ✔  example_test.py  [python]          │
│  ○ mistral     │                                        │
│  ○ groq        │  ── MISTRAL ──                         │
│  ● all         │  Security Issues:                      │
│                │    • Hardcoded credentials detected    │
│  [Run Analysis]│    • Insecure pickle deserialization   │
│                │  Potential Bugs:                       │
│  Analyzing...  │    • Division by zero                  │
│                │                                        │
├────────────────┴────────────────────────────────────────┤
│  R Run  C Clear  Q Quit                                 │
└─────────────────────────────────────────────────────────┘
```

### Keybindings

| Key | Action        |
|-----|---------------|
| `R` | Run analysis  |
| `C` | Clear results |
| `Q` | Quit          |

Results are color-coded:
- **Red** — Security issues
- **Yellow** — Potential bugs
- **Cyan** — Code quality issues
- **Green** — Suggestions

---

## Supported Languages

| Language   | Extension(s)   |
|------------|----------------|
| Python     | `.py`          |
| JavaScript | `.js`          |
| TypeScript | `.ts`          |
| Java       | `.java`        |
| C / C++    | `.c`, `.cpp`   |
| Go         | `.go`          |
| Rust       | `.rs`          |
| Ruby       | `.rb`          |
| PHP        | `.php`         |
| Swift      | `.swift`       |
| Kotlin     | `.kt`          |
| C#         | `.cs`          |

---

## Project Structure

```
errorlens/
├── main.py                     # CLI entry point
├── tui.py                      # TUI entry point
├── requirements.txt
├── setup.py
├── .env                        # API keys (not committed)
├── example_test.py             # Sample file with intentional issues
├── core/
│   ├── analyzer.py             # File discovery and analysis orchestration
│   └── config.py               # Configuration and env loading
└── providers/
    ├── anthropic_provider.py   # Anthropic Claude integration
    ├── groq_provider.py        # Groq Llama 3 integration
    ├── mistral_provider.py     # Mistral integration
    └── mock_provider.py        # Offline mock for testing
```

---

## Testing with the Example File

`example_test.py` is bundled with intentional security flaws and bugs — use it to verify your setup:

```bash
python main.py example_test.py --provider groq
```

---

## License

MIT License — see LICENSE for details.
