# Tests for summary_stack_mcp_server
