from summary_stack_mcp_server.server import mcp


def main() -> None:
    mcp.run()


__all__ = ["main", "mcp"]
