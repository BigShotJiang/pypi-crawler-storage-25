import logging
import sys


def _configure_logging() -> None:
    logging.basicConfig(
        level=logging.WARNING,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        stream=sys.stderr,
    )


def main() -> None:
    _configure_logging()
    from summary_stack_mcp_server.server import mcp

    mcp.run()


if __name__ == "__main__":
    main()
