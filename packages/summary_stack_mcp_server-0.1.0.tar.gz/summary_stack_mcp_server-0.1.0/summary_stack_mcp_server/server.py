from fastmcp import FastMCP
from summary_stack_mcp_core import create_summary_stack, get_stack, list_stacks, search_corpus


mcp = FastMCP("summary-stack")

# Register core tools
mcp.tool()(search_corpus)
mcp.tool()(get_stack)
mcp.tool()(list_stacks)
mcp.tool()(create_summary_stack)
