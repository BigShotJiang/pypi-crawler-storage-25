"""Manifest config package."""

