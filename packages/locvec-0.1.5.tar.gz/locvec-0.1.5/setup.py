import os
import sys
import subprocess
from setuptools import setup
from setuptools.command.build_py import build_py
from setuptools.command.develop import develop
import shutil
def compile_cuda():
    if not shutil.which("nvcc"):
        raise RuntimeError(
            "Installation Failed: NVIDIA CUDA Toolkit (nvcc) is required to compile LocVec."
        )

    base_dir = os.path.dirname(__file__)
    target_dir = os.path.join(base_dir, "src", "locvec")
    ext = ".dll" if sys.platform == "win32" else ".so"
    output_path = os.path.join(target_dir, "liblocalvec" + ext)
    
    os.makedirs(target_dir, exist_ok=True)

    sources = [
        "src/cuda/ivf_cuda_backend.cu",
        "src/cuda/kmeans_trainer.cu",
        "src/bridge/ivf_wrapper.c",
        "src/bridge/ivf_allocator.c"
    ]

    print(f"Executing CUDA Build: {output_path}")
    cmd = ["nvcc", "-Xcompiler", "-fPIC", "-shared", "-o", output_path] + sources
    
    try:
        subprocess.check_call(cmd)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"CUDA Compilation failed during setup. Error: {e}")

class CustomBuildPy(build_py):
    def run(self):
        compile_cuda()
        super().run()

class CustomDevelop(develop):
    def run(self):
        compile_cuda()
        super().run()

setup(
    name="locvec",
    version="0.1.5",
    packages=["locvec"],
    package_dir={"": "src"},
    package_data={"locvec": ["*.so", "*.dll"]},
    cmdclass={
        'build_py': CustomBuildPy,
        'develop': CustomDevelop,
    },
)
