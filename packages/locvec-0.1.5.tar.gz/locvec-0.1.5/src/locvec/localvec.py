import ctypes
import numpy as np
import urllib.request
import os
import sys
import torch
import gc
import sqlite3
import json
from sentence_transformers import SentenceTransformer

class LocalVec:
    def __init__(self, db_name="default_db", model_name='all-MiniLM-L6-v2', storage_dir="."):
        os.makedirs(storage_dir, exist_ok=True)
        self.db_prefix = os.path.join(storage_dir, db_name)
        self.c_prefix = self.db_prefix.encode('utf-8')

        base_path = os.path.dirname(__file__)
        ext = ".dll" if sys.platform == "win32" else ".so"
        self.lib_path = os.path.join(base_path, f"liblocalvec{ext}")
        
        if not os.path.exists(self.lib_path):
            raise FileNotFoundError(f"LocVec Core not found at {self.lib_path}")
        self.lib = ctypes.CDLL(self.lib_path)

        self.lib.init_engine.argtypes = [ctypes.c_int, ctypes.c_char_p]
        self.lib.init_engine.restype = ctypes.c_int
        self.lib.cleanup_engine.restype = None
        self.lib.vector_search.argtypes = [np.ctypeslib.ndpointer(dtype=np.float32, ndim=1), ctypes.c_int, ctypes.c_char_p]
        self.lib.vector_search.restype = ctypes.c_int
        self.lib.train_index.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_char_p, ctypes.c_int]
        self.lib.train_index.restype = ctypes.c_int
        self.lib.build_index.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_char_p]
        self.lib.build_index.restype = ctypes.c_int

        self.encoder = SentenceTransformer(model_name)
        self.dims = self.encoder.get_embedding_dimension()

        self.sql_path = f"{self.db_prefix}_text.sqlite"
        self.conn = sqlite3.connect(self.sql_path, check_same_thread=False)
        self.cursor = self.conn.cursor()
        
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS corpus (
                id INTEGER PRIMARY KEY,
                chunk TEXT
            )
        ''')
        self.conn.commit()

        if os.path.exists(f"{self.db_prefix}_ivf_database.bin"):
            self.lib.init_engine(self.dims, self.c_prefix)

    def build_full_index(self, texts, max_iter=100):
        if not texts: return False
        n = len(texts)
        k = max(1, int(np.sqrt(n)))
        
        self.cursor.execute("DELETE FROM corpus")
        for idx, text in enumerate(texts):
            self.cursor.execute("INSERT INTO corpus (id, chunk) VALUES (?, ?)", (idx, text))
        self.conn.commit()

        embeddings = self.encoder.encode(texts, show_progress_bar=True).astype(np.float32)
        embeddings.tofile(f"{self.db_prefix}_offline_embeddings.bin")

        if self.lib.train_index(k, self.dims, self.c_prefix, max_iter) != 0: return False
        if self.lib.build_index(k, self.dims, self.c_prefix) != 0: return False
        
        self.lib.init_engine(self.dims, self.c_prefix)
        return True

    def search(self, query_text, top_k=3):
        if not query_text or not query_text.strip(): return -1, "Empty Query"
        query_vector = self.encoder.encode(query_text).astype(np.float32)
        center_idx = self.lib.vector_search(query_vector, self.dims, self.c_prefix)
        
        if center_idx < 0: return center_idx, "Search Core Error"

        half_window = top_k // 2
        start_idx = max(0, center_idx - half_window)
        end_idx = center_idx + (top_k - half_window) - 1

        self.cursor.execute(
            "SELECT id, chunk FROM corpus WHERE id >= ? AND id <= ?", 
            (start_idx, end_idx)
        )
        rows = self.cursor.fetchall()

        if not rows: return center_idx, "Text not found in SQLite"

        context_chunks = [f"[Source Chunk {r[0]}]: {r[1]}" for r in rows]
        return center_idx, "\n\n".join(context_chunks)

    def query_llm_stream(self, model, query, context, api_url="http://localhost:11434/api/generate", **kwargs):
        prompt = (
            f"### SYSTEM INSTRUCTIONS\n"
            f"You are a specialized technical assistant. Use the provided context "
            f"to answer the query accurately.\n"
            f"If the context is insufficient, state that clearly. Do not hallucinate details.\n\n"
            f"### CONTEXT\n{context}\n\n"
            f"### USER QUERY\n{query}\n\n"
            f"### TECHNICAL RESPONSE:"
        )
        
        options = {"temperature": 0.1, "num_predict": 512}
        options.update(kwargs)

        payload = {"model": model, "prompt": prompt, "stream": True, "options": options}
        req = urllib.request.Request(
            api_url, data=json.dumps(payload).encode('utf-8'), headers={'Content-Type': 'application/json'}
        )
        
        try:
            with urllib.request.urlopen(req) as response:
                for line in response:
                    if line:
                        chunk = json.loads(line.decode('utf-8'))
                        yield chunk.get('response', '')
                        if chunk.get('done'): break
        except Exception as e:
            yield f"\n[Inference Error]: {str(e)}"

    def offload_encoder(self):
        self.encoder.to('cpu')
        torch.cuda.empty_cache()
        gc.collect()

    def __del__(self):
        try:
            if hasattr(self, 'cursor'): self.cursor.close()
            if hasattr(self, 'conn'): self.conn.close()
            if hasattr(self, 'lib'): self.lib.cleanup_engine()
        except:
            pass