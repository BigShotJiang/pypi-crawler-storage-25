#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int start_offset;
    int count;
} ClusterOffset;

float* global_centroids = NULL;
ClusterOffset* global_offsets = NULL;
int* global_id_map = NULL;
float* global_database = NULL;
int global_k = 0;
int total_vectors_indexed = 0;

extern int run_cluster_search(float* cluster_data, float* query, int count, int dims);
extern int train_index_kernel(int k, int dims, const char* db_prefix, int max_iter);
extern int build_ivf_structure(int k, int dims, const char* db_prefix);

#ifdef __cplusplus
extern "C" {
#endif

void cleanup_engine() {
    if (global_centroids) { free(global_centroids); global_centroids = NULL; }
    if (global_offsets) { free(global_offsets); global_offsets = NULL; }
    if (global_id_map) { free(global_id_map); global_id_map = NULL; }
    if (global_database) { free(global_database); global_database = NULL; }
    global_k = 0;
    total_vectors_indexed = 0;
}

int init_engine(int dims, const char* db_prefix) {
    cleanup_engine();
    char filename[512];
    
    sprintf(filename, "%s_ivf_centroids.bin", db_prefix);
    FILE* fc = fopen(filename, "rb");
    if (!fc) return -1;
    fseek(fc, 0, SEEK_END);
    long sz = ftell(fc);
    if (sz <= 0) { fclose(fc); return -1; }
    global_k = sz / (dims * sizeof(float));
    rewind(fc);
    
    global_centroids = (float*)malloc(global_k * dims * sizeof(float));
    if (!global_centroids) { fclose(fc); return -1; }
    fread(global_centroids, sizeof(float), global_k * dims, fc);
    fclose(fc);

    global_offsets = (ClusterOffset*)malloc(global_k * sizeof(ClusterOffset));
    if (!global_offsets) { cleanup_engine(); return -2; }
    sprintf(filename, "%s_ivf_offsets.bin", db_prefix);
    FILE* fo = fopen(filename, "rb");
    if (!fo) { cleanup_engine(); return -2; }
    fread(global_offsets, sizeof(ClusterOffset), global_k, fo);
    fclose(fo);

    total_vectors_indexed = 0;
    for(int i = 0; i < global_k; i++) {
        if (global_offsets[i].count > 0) {
            total_vectors_indexed += global_offsets[i].count;
        }
    }
    if (total_vectors_indexed <= 0) { cleanup_engine(); return -3; }

    global_id_map = (int*)malloc(total_vectors_indexed * sizeof(int));
    if (!global_id_map) { cleanup_engine(); return -4; }
    sprintf(filename, "%s_ivf_id_map.bin", db_prefix);
    FILE* fid = fopen(filename, "rb");
    if (fid) {
        fread(global_id_map, sizeof(int), total_vectors_indexed, fid);
        fclose(fid);
    } else {
        cleanup_engine(); return -4;
    }

    global_database = (float*)malloc((size_t)total_vectors_indexed * dims * sizeof(float));
    if (!global_database) { cleanup_engine(); return -5; }
    sprintf(filename, "%s_ivf_database.bin", db_prefix);
    FILE* fd = fopen(filename, "rb");
    if (fd) {
        fread(global_database, sizeof(float), (size_t)total_vectors_indexed * dims, fd);
        fclose(fd);
    } else {
        cleanup_engine(); return -5;
    }

    return 0;
}

int train_index(int k, int dims, const char* db_prefix, int max_iter) {
    if (k <= 0 || dims <= 0 || !db_prefix) return -1;
    return train_index_kernel(k, dims, db_prefix, max_iter);
}

int build_index(int k, int dims, const char* db_prefix) {
    if (k <= 0 || dims <= 0 || !db_prefix) return -1;
    return build_ivf_structure(k, dims, db_prefix);
}

int vector_search(float* query, int dims, const char* db_prefix) {
    if (!global_centroids || !global_offsets || !global_database || !global_id_map) return -404;
    if (!query || dims <= 0) return -405;

    float min_dist = 1e30f;
    int best_cluster = -1;

    for (int k = 0; k < global_k; ++k) {
        if (global_offsets[k].count <= 0) continue; 
        float dist = 0.0f;
        for (int d = 0; d < dims; ++d) {
            float diff = query[d] - global_centroids[k * dims + d];
            dist += diff * diff;
        }
        if (dist < min_dist) {
            min_dist = dist;
            best_cluster = k;
        }
    }

    if (best_cluster == -1) return -1; 
    if (global_offsets[best_cluster].count <= 0) return -1;

    int target_offset = global_offsets[best_cluster].start_offset;
    int target_count = global_offsets[best_cluster].count;
    
    if (target_offset < 0 || target_count <= 0 || (target_offset + target_count) > total_vectors_indexed) return -1;

    float* cluster_data_ptr = global_database + ((size_t)target_offset * dims);

    int result_idx = run_cluster_search(cluster_data_ptr, query, target_count, dims);
    if (result_idx < 0 || result_idx >= target_count) return -1;
    
    int ivf_idx = target_offset + result_idx;
    return global_id_map[ivf_idx];
}

#ifdef __cplusplus
}
#endif