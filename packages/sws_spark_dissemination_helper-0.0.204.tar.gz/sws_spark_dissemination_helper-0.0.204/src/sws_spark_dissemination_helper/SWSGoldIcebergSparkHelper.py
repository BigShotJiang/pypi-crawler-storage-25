import logging
from copy import copy
from typing import List, Tuple

import pyspark.sql.functions as F
from pyspark.sql import Column, DataFrame, SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.types import DecimalType, FloatType
from sws_api_client import Tags
from sws_api_client.tags import BaseDisseminatedTagTable, TableLayer, TableType

from .constants import DatasetDatatables, IcebergDatabases, IcebergTables
from .SWSPostgresSparkReader import SWSPostgresSparkReader
from .utils import get_or_create_tag, save_cache_csv, upsert_disseminated_table

SIMPLE_NUMERIC_REGEX = r"^[+-]?\d*(\.\d+)?$"
NUMERIC_REGEX = r"^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$"
# Regex to extract decimal places: matches the decimal part and counts its length
DECIMAL_PLACES_REGEX = r"\.(\d+)$"


class SWSGoldIcebergSparkHelper:
    def __init__(
        self,
        spark: SparkSession,
        bucket: str,
        tag_name: str,
        dataset_id: str,
        sws_postgres_spark_reader: SWSPostgresSparkReader,
        iceberg_tables: IcebergTables,
        domain_code: str,
        dataset_details: dict = None,
    ) -> None:
        self.spark: SparkSession = spark
        self.dataset_details: dict = dataset_details
        self.bucket: str = bucket
        self.tag_name: str = tag_name
        self.dataset_id: str = dataset_id
        self.sws_postgres_spark_reader = sws_postgres_spark_reader
        self.iceberg_tables: IcebergTables = iceberg_tables
        self.domain_code = domain_code

        if dataset_details is not None:
            (
                self.dim_columns_w_time,
                self.dim_columns,
                self.time_column,
                self.flag_columns,
            ) = self._get_dim_time_flag_columns()

            self.cols_to_keep_sws = (
                self.dim_columns_w_time + ["value"] + self.flag_columns
            )

            # ----------------
            # Get the codelist -> type mapping (e.g. geographicAreaM49 -> area )
            # ----------------
            self.codelist_type_mapping = (
                self.sws_postgres_spark_reader.get_codelist_type_mapping(
                    self.domain_code,
                    dimension_flag_columns=self.dim_columns_w_time + self.flag_columns,
                )
            )

            self.mapping_dim_col_name_type = {
                col_name: col_type
                for col_name, col_type in self.codelist_type_mapping.items()
                if col_name in self.dim_columns
            }

            self.display_decimals_df = self.sws_postgres_spark_reader.read_pg_table(
                pg_table=DatasetDatatables.DISPLAY_DECIMALS.id,
                custom_schema=DatasetDatatables.DISPLAY_DECIMALS.schema,
            ).filter(
                (col("domain") == lit(self.domain_code))
                | ((col("domain") == lit("DEFAULT")))
            )

    def _get_dim_time_flag_columns(self) -> Tuple[List[str], List[str], str, List[str]]:
        """Extract the dimension columns with time, without time, the time column and the flag columns names."""
        dim_columns_w_time = [
            dimension["id"] for dimension in self.dataset_details.get("dimensions", [])
        ]
        time_column = next(
            dimension["id"]
            for dimension in self.dataset_details.get("dimensions", [])
            if dimension["codelist"]["type"] == "time"
        )
        dim_columns = copy(dim_columns_w_time)
        dim_columns.remove(time_column)

        flag_columns = [flag["id"] for flag in self.dataset_details.get("flags", [])]

        return dim_columns_w_time, dim_columns, time_column, flag_columns

    def apply_diss_flag_filter(self, df: DataFrame) -> DataFrame:
        return df.filter(col("diss_flag"))

    def keep_dim_val_attr_columns(
        self, df: DataFrame, additional_columns: List[str] = []
    ):
        cols_to_keep_sws = self.cols_to_keep_sws
        for additional_column in additional_columns:
            if additional_column in df.columns:
                cols_to_keep_sws = cols_to_keep_sws + [additional_column]
        if "unit_of_measure_symbol" in df.columns:
            cols_to_keep_sws = cols_to_keep_sws + ["unit_of_measure_symbol"]
        return df.select(*cols_to_keep_sws)

    @staticmethod
    def _build_rule_condition(rule) -> Column:
        condition = lit(True)
        if rule["column_1_name"] != "" and rule["column_1_value"] != "":
            values = [v.strip() for v in str(rule["column_1_value"]).split(",")]
            condition &= col(rule["column_1_name"]).isin(values)

        if (
            rule["column_2_name"] is not None
            and rule["column_2_name"] != ""
            and rule["column_2_value"] is not None
            and rule["column_2_value"] != ""
        ):
            values = [v.strip() for v in str(rule["column_2_value"]).split(",")]
            condition &= col(rule["column_2_name"]).isin(values)

        return condition

    @staticmethod
    def _count_actual_decimals(
        value_column: str, precision: int, target_decimals: int
    ) -> Column:
        normalized = F.when(
            F.col(value_column).cast("string").rlike("[eE]"),
            F.format_number(
                F.col(value_column).cast(DecimalType(precision, target_decimals)),
                target_decimals,
            ),
        ).otherwise(F.col(value_column).cast("string"))

        return F.length(F.regexp_extract(normalized, DECIMAL_PLACES_REGEX, 1))

    @staticmethod
    def _round_if_needed(
        value_column: str, rounded_value, actual_decimals, target_decimals: int
    ) -> Column:
        return F.when(actual_decimals >= lit(target_decimals), rounded_value).otherwise(
            col(value_column)
        )

    @staticmethod
    def _chain_when(existing, condition, value):
        if existing is None:
            return F.when(condition, value)
        return existing.when(condition, value)

    @staticmethod
    def _chain_otherwise(existing, default_value):
        if existing is None:
            return default_value
        return existing.otherwise(default_value)

    @staticmethod
    def _clean_number(col: Column) -> Column:
        # Remove commas
        result = F.regexp_replace(col, ",", "")
        # Remove trailing zeros after decimal point
        result = F.regexp_replace(result, "(\\.\\d*?[1-9])0+$", "$1")
        # Remove decimal point if only zeros followed it (e.g., "100." or "100.000")
        result = F.regexp_replace(result, "\\.0*$", "")
        return result

    def round_to_display_decimals(
        self, df: DataFrame, value_column: str = "value", precision: int = 38
    ) -> DataFrame:

        df = df.withColumn("unrounded_value", col(value_column).cast("string"))

        general_default_decimals = (
            self.display_decimals_df.filter(col("domain") == lit("DEFAULT"))
            .select("display_decimals")
            .collect()[0][0]
        )
        domain_default_decimals = self.display_decimals_df.filter(
            (col("domain") == lit(self.domain_code))
            & col("column_1_name").isNull()
            & col("column_2_name").isNull()
        ).select("display_decimals")

        default_decimals = int(
            general_default_decimals
            if domain_default_decimals.count() == 0
            else domain_default_decimals.collect()[0][0]
        )

        domain_specific_rules = self.display_decimals_df.filter(
            (col("domain") == lit(self.domain_code))
            & (
                (col("column_1_name").isNotNull() & col("column_1_value").isNotNull())
                | (col("column_2_name").isNotNull() & col("column_2_value").isNotNull())
            )
        )

        when_decimals = None
        when_rounded = None

        for rule in domain_specific_rules.collect():
            condition = self._build_rule_condition(rule)
            display_decimals = int(rule["display_decimals"])

            actual_decimals = self._count_actual_decimals(
                value_column, precision, display_decimals
            )

            when_decimals = self._chain_when(
                when_decimals, condition, lit(display_decimals)
            )

            rounded_value = F.format_number(
                col(value_column).cast(DecimalType(precision, display_decimals)),
                display_decimals,
            )
            rounded_value = self._round_if_needed(
                value_column, rounded_value, actual_decimals, display_decimals
            )

            when_rounded = self._chain_when(when_rounded, condition, rounded_value)

        # Default rounding
        default_rounded = F.format_number(
            col(value_column).cast(DecimalType(precision, default_decimals)),
            default_decimals,
        )
        actual_decimals_default = self._count_actual_decimals(
            value_column, precision, default_decimals
        )
        default_rounded = self._round_if_needed(
            value_column, default_rounded, actual_decimals_default, default_decimals
        )

        when_decimals = self._chain_otherwise(when_decimals, lit(default_decimals))
        when_rounded = self._chain_otherwise(when_rounded, default_rounded)

        df = df.withColumn("display_decimals", when_decimals)
        df = df.withColumn(value_column, self._clean_number(when_rounded))

        return df

    def read_bronze_data(self) -> DataFrame:
        return self.spark.read.option("tag", self.tag_name).table(
            self.iceberg_tables.BRONZE_DISS_TAG.iceberg_id
        )

    def read_silver_data(self) -> DataFrame:
        return self.spark.read.option("tag", self.tag_name).table(
            self.iceberg_tables.SILVER.iceberg_id
        )

    def gen_gold_sws_disseminated_data(
        self, additional_columns: List[str] = []
    ) -> DataFrame:
        return (
            self.read_silver_data()
            .transform(self.apply_diss_flag_filter)
            .transform(self.keep_dim_val_attr_columns, additional_columns)
        )

    def gen_gold_sws_data(self, additional_columns: List[str] = []) -> DataFrame:
        return self.read_bronze_data().transform(
            self.keep_dim_val_attr_columns, additional_columns
        )

    def gen_gold_sws_validated_data(
        self, additional_columns: List[str] = []
    ) -> DataFrame:
        return self.read_silver_data().transform(
            self.keep_dim_val_attr_columns, additional_columns
        )

    def write_gold_sws_validated_data_to_iceberg_and_csv(
        self, df: DataFrame
    ) -> DataFrame:
        df.writeTo(self.iceberg_tables.GOLD_SWS_VALIDATED.iceberg_id).createOrReplace()

        logging.info(
            f"Gold SWS validated table written to {self.iceberg_tables.GOLD_SWS_VALIDATED.iceberg_id}"
        )

        self.spark.sql(
            f"ALTER TABLE {self.iceberg_tables.GOLD_SWS_VALIDATED.iceberg_id} CREATE OR REPLACE TAG `{self.tag_name}`"
        )

        logging.info(f"gold SWS validated tag '{self.tag_name}' created")

        df_1 = df.coalesce(1)

        save_cache_csv(
            df=df_1,
            bucket=self.bucket,
            prefix=self.iceberg_tables.GOLD_SWS_VALIDATED.csv_prefix,
            tag_name=self.tag_name,
        )

        return df

    def write_gold_sws_data_to_iceberg_and_csv(self, df: DataFrame) -> DataFrame:
        df.writeTo(self.iceberg_tables.GOLD_SWS.iceberg_id).createOrReplace()

        logging.info(
            f"Gold SWS table written to {self.iceberg_tables.GOLD_SWS.iceberg_id}"
        )

        self.spark.sql(
            f"ALTER TABLE {self.iceberg_tables.GOLD_SWS.iceberg_id} CREATE OR REPLACE TAG `{self.tag_name}`"
        )

        logging.info(f"gold SWS tag '{self.tag_name}' created")

        df_1 = df.coalesce(1)

        save_cache_csv(
            df=df_1,
            bucket=self.bucket,
            prefix=self.iceberg_tables.GOLD_SWS.csv_prefix,
            tag_name=self.tag_name,
        )

        return df

    def gen_and_write_gold_sws_data_to_iceberg_and_csv(self) -> DataFrame:
        self.df_gold_sws = self.gen_gold_sws_data()

        self.write_gold_sws_data_to_iceberg_and_csv(self.df_gold_sws)

        return self.df_gold_sws

    def gen_and_write_gold_sws_validated_data_to_iceberg_and_csv(self) -> DataFrame:
        self.df_gold_sws_validated = self.gen_gold_sws_validated_data()

        self.write_gold_sws_validated_data_to_iceberg_and_csv(
            self.df_gold_sws_validated
        )

        return self.df_gold_sws_validated

    def write_gold_sws_disseminated_data_to_iceberg_and_csv(
        self, df: DataFrame
    ) -> DataFrame:
        df.writeTo(
            self.iceberg_tables.GOLD_SWS_DISSEMINATED.iceberg_id
        ).createOrReplace()

        logging.info(
            f"Gold SWS disseminated table written to {self.iceberg_tables.GOLD_SWS_DISSEMINATED.iceberg_id}"
        )

        self.spark.sql(
            f"ALTER TABLE {self.iceberg_tables.GOLD_SWS_DISSEMINATED.iceberg_id} CREATE OR REPLACE TAG `{self.tag_name}`"
        )

        logging.info(f"gold SWS disseminated tag '{self.tag_name}' created")

        df_1 = df.coalesce(1)

        save_cache_csv(
            df=df_1,
            bucket=self.bucket,
            prefix=self.iceberg_tables.GOLD_SWS_DISSEMINATED.csv_prefix,
            tag_name=self.tag_name,
        )

        return df

    def gen_and_write_gold_sws_disseminated_data_to_iceberg_and_csv(self) -> DataFrame:
        self.df_gold_sws_disseminated = self.gen_gold_sws_disseminated_data()

        self.write_gold_sws_disseminated_data_to_iceberg_and_csv(
            self.df_gold_sws_disseminated
        )

        return self.df_gold_sws_disseminated

    def write_gold_sdmx_data_to_iceberg_and_csv(self, df: DataFrame) -> DataFrame:
        df.writeTo(self.iceberg_tables.GOLD_SDMX.iceberg_id).createOrReplace()

        logging.info(
            f"Gold SDMX table written to {self.iceberg_tables.GOLD_SDMX.iceberg_id}"
        )

        self.spark.sql(
            f"ALTER TABLE {self.iceberg_tables.GOLD_SDMX.iceberg_id} CREATE OR REPLACE TAG `{self.tag_name}`"
        )

        logging.info(f"gold SDMX tag '{self.tag_name}' created")

        df_1 = df.coalesce(1)

        save_cache_csv(
            df=df_1,
            bucket=self.bucket,
            prefix=self.iceberg_tables.GOLD_SDMX.csv_prefix,
            tag_name=self.tag_name,
        )

        return df

    def write_gold_pre_sdmx_data_to_iceberg_and_csv(self, df: DataFrame) -> DataFrame:
        """The expected input to this function is the output of the sws disseminated function"""
        for column in self.dim_columns:
            df = df.withColumn(
                column, F.regexp_replace(col(column), lit("\."), lit("_"))
            )
        df = df.withColumnRenamed("value", "OBS_VALUE").withColumnsRenamed(
            {column: column.upper() for column in df.columns}
        )
        df.writeTo(self.iceberg_tables.GOLD_PRE_SDMX.iceberg_id).createOrReplace()

        logging.info(
            f"Gold pre-SDMX table written to {self.iceberg_tables.GOLD_PRE_SDMX.iceberg_id}"
        )

        self.spark.sql(
            f"ALTER TABLE {self.iceberg_tables.GOLD_PRE_SDMX.iceberg_id} CREATE OR REPLACE TAG `{self.tag_name}`"
        )

        logging.info(f"gold pre-SDMX tag '{self.tag_name}' created")

        df_1 = df.coalesce(1)

        save_cache_csv(
            df=df_1,
            bucket=self.bucket,
            prefix=self.iceberg_tables.GOLD_PRE_SDMX.csv_prefix,
            tag_name=self.tag_name,
        )

        return df

    def write_gold_faostat_data_to_iceberg_and_csv(self, df: DataFrame) -> DataFrame:
        """The expected input to this function is the output of the sws disseminated function"""
        df.writeTo(self.iceberg_tables.GOLD_FAOSTAT.iceberg_id).createOrReplace()

        logging.info(
            f"Gold FAOSTAT table written to {self.iceberg_tables.GOLD_FAOSTAT.iceberg_id}"
        )

        self.spark.sql(
            f"ALTER TABLE {self.iceberg_tables.GOLD_FAOSTAT.iceberg_id} CREATE OR REPLACE TAG `{self.tag_name}`"
        )

        logging.info(f"gold FAOSTAT tag '{self.tag_name}' created")

        df_1 = df.coalesce(1)

        save_cache_csv(
            df=df_1,
            bucket=self.bucket,
            prefix=self.iceberg_tables.GOLD_FAOSTAT.csv_prefix,
            tag_name=self.tag_name,
        )

        return df

    def write_gold_faostat_unfiltered_data_to_iceberg_and_csv(
        self, df: DataFrame
    ) -> DataFrame:
        """The expected input to this function is the output of the sws disseminated function"""
        df.writeTo(
            self.iceberg_tables.GOLD_FAOSTAT_UNFILTERED.iceberg_id
        ).createOrReplace()

        logging.info(
            f"Gold FAOSTAT unfiltered table written to {self.iceberg_tables.GOLD_FAOSTAT.iceberg_id}"
        )

        self.spark.sql(
            f"ALTER TABLE {self.iceberg_tables.GOLD_FAOSTAT_UNFILTERED.iceberg_id} CREATE OR REPLACE TAG `{self.tag_name}`"
        )

        logging.info(f"gold FAOSTAT unfiltered tag '{self.tag_name}' created")

        df_1 = df.coalesce(1)

        save_cache_csv(
            df=df_1,
            bucket=self.bucket,
            prefix=self.iceberg_tables.GOLD_FAOSTAT_UNFILTERED.csv_prefix,
            tag_name=self.tag_name,
        )

        return df

    def write_gold_sws_validated_sws_dissemination_tag(
        self, df: DataFrame, tags: Tags
    ) -> DataFrame:
        # Get or create a new tag
        tag = get_or_create_tag(tags, self.dataset_id, self.tag_name, self.tag_name)
        logging.debug(f"Tag: {tag}")

        new_iceberg_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_sws_validated_iceberg",
            name=f"{self.domain_code} gold SWS validated Iceberg",
            description="Gold table containing all the unfiltered tag data, with code correction appplied, in SWS compatible format",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.ICEBERG,
            database=IcebergDatabases.GOLD_DATABASE,
            table=self.iceberg_tables.GOLD_SWS_VALIDATED.table,
            path=self.iceberg_tables.GOLD_SWS_VALIDATED.path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_iceberg_table,
        )
        logging.debug(f"Tag with Added Iceberg Table: {tag}")

        new_diss_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_sws_validated_csv",
            name=f"{self.domain_code} gold SWS validated csv",
            description="Gold table containing all the unfiltered tag data, with code correction appplied, in SWS compatible format, cached in csv",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.CSV,
            path=self.iceberg_tables.GOLD_SWS_VALIDATED.csv_path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_diss_table,
        )
        logging.debug(f"Tag with Added csv Table: {tag}")

        return df

    def write_gold_sws_disseminated_sws_dissemination_tag(
        self, df: DataFrame, tags: Tags
    ) -> DataFrame:
        # Get or create a new tag
        tag = get_or_create_tag(tags, self.dataset_id, self.tag_name, self.tag_name)
        logging.debug(f"Tag: {tag}")

        new_iceberg_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_sws_disseminated_iceberg",
            name=f"{self.domain_code} gold SWS disseminated Iceberg",
            description="Gold table containing only the filtered tag data, with code correction appplied, in SWS compatible format",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.ICEBERG,
            database=IcebergDatabases.GOLD_DATABASE,
            table=self.iceberg_tables.GOLD_SWS_DISSEMINATED.table,
            path=self.iceberg_tables.GOLD_SWS_DISSEMINATED.path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_iceberg_table,
        )
        logging.debug(f"Tag with Added Iceberg Table: {tag}")

        new_diss_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_sws_disseminated_csv",
            name=f"{self.domain_code} gold SWS disseminated csv",
            description="Gold table containing only the filtered tag data, with code correction appplied, in SWS compatible format, cached in csv",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.CSV,
            path=self.iceberg_tables.GOLD_SWS_DISSEMINATED.csv_path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_diss_table,
        )
        logging.debug(f"Tag with Added csv Table: {tag}")

        return df

    def write_gold_sdmx_sws_dissemination_tag(
        self, df: DataFrame, tags: Tags
    ) -> DataFrame:
        # Get or create a new tag
        tag = get_or_create_tag(tags, self.dataset_id, self.tag_name, self.tag_name)
        logging.debug(f"Tag: {tag}")

        new_iceberg_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_sdmx_iceberg",
            name=f"{self.domain_code} gold SDMX Iceberg",
            description="Gold table containing all the cleaned data in SDMX compatible format",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.ICEBERG,
            database=IcebergDatabases.GOLD_DATABASE,
            table=self.iceberg_tables.GOLD_SDMX.table,
            path=self.iceberg_tables.GOLD_SDMX.path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_iceberg_table,
        )
        logging.debug(f"Tag with Added Iceberg Table: {tag}")

        new_diss_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_sdmx_csv",
            name=f"{self.domain_code} gold SDMX csv",
            description="Gold table containing all the cleaned data in SDMX compatible format cached in csv",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.CSV,
            path=self.iceberg_tables.GOLD_SDMX.csv_path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_diss_table,
        )
        logging.debug(f"Tag with Added csv Table: {tag}")

        return df

    def write_gold_pre_sdmx_sws_dissemination_tag(
        self, df: DataFrame, tags: Tags
    ) -> DataFrame:
        # Get or create a new tag
        tag = get_or_create_tag(tags, self.dataset_id, self.tag_name, self.tag_name)
        logging.debug(f"Tag: {tag}")

        new_iceberg_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_pre_sdmx_iceberg",
            name=f"{self.domain_code} gold pre-SDMX Iceberg",
            description="Gold table containing all the cleaned data in SDMX compatible format, ready to be mapped using FMR",
            layer=TableLayer.GOLD,
            private=True,
            debug=True,
            type=TableType.ICEBERG,
            database=IcebergDatabases.GOLD_DATABASE,
            table=self.iceberg_tables.GOLD_PRE_SDMX.table,
            path=self.iceberg_tables.GOLD_PRE_SDMX.path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_iceberg_table,
        )
        logging.debug(f"Tag with Added Iceberg Table: {tag}")

        new_diss_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_pre_sdmx_csv",
            name=f"{self.domain_code} gold pre-SDMX csv",
            description="Gold table containing all the cleaned data in SDMX compatible format, ready to be mapped using FMR and cached in csv",
            layer=TableLayer.GOLD,
            private=True,
            debug=True,
            type=TableType.CSV,
            path=self.iceberg_tables.GOLD_PRE_SDMX.csv_path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_diss_table,
        )
        logging.debug(f"Tag with Added csv Table: {tag}")

        return df

    def write_gold_sws_dissemination_tag(self, df: DataFrame, tags: Tags) -> DataFrame:
        # Get or create a new tag
        tag = get_or_create_tag(tags, self.dataset_id, self.tag_name, self.tag_name)
        logging.debug(f"Tag: {tag}")

        new_iceberg_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_sws_iceberg",
            name=f"{self.domain_code} gold SWS Iceberg",
            description="Gold table containing the tag data without any processing",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.ICEBERG,
            database=IcebergDatabases.GOLD_DATABASE,
            table=self.iceberg_tables.GOLD_SWS.table,
            path=self.iceberg_tables.GOLD_SWS.path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_iceberg_table,
        )
        logging.debug(f"Tag with Added Iceberg Table: {tag}")

        new_diss_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_sws_csv",
            name=f"{self.domain_code} gold SWS csv",
            description="Gold table containing the tag data without any processing cached in csv",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.CSV,
            path=self.iceberg_tables.GOLD_SWS.csv_path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_diss_table,
        )
        logging.debug(f"Tag with Added csv Table: {tag}")

        return df

    def write_gold_faostat_dissemination_tag(
        self, df: DataFrame, tags: Tags
    ) -> DataFrame:
        # Get or create a new tag
        tag = get_or_create_tag(tags, self.dataset_id, self.tag_name, self.tag_name)
        logging.debug(f"Tag: {tag}")

        new_iceberg_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_faostat_iceberg",
            name=f"{self.domain_code} gold FAOSTAT Iceberg",
            description="Gold table containing the tag data in FAOSTAT format",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.ICEBERG,
            database=IcebergDatabases.GOLD_DATABASE,
            table=self.iceberg_tables.GOLD_FAOSTAT.table,
            path=self.iceberg_tables.GOLD_FAOSTAT.path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_iceberg_table,
        )
        logging.debug(f"Tag with Added Iceberg Table: {tag}")

        new_diss_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_faostat_csv",
            name=f"{self.domain_code} gold FAOSTAT csv",
            description="Gold table containing the tag data in FAOSTAT format in csv",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.CSV,
            path=self.iceberg_tables.GOLD_FAOSTAT.csv_path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_diss_table,
        )
        logging.debug(f"Tag with Added csv Table: {tag}")

        return df

    def write_gold_faostat_unfiltered_dissemination_tag(
        self, df: DataFrame, tags: Tags
    ) -> DataFrame:
        # Get or create a new tag
        tag = get_or_create_tag(tags, self.dataset_id, self.tag_name, self.tag_name)
        logging.debug(f"Tag: {tag}")

        new_iceberg_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_faostat_unfiltered_iceberg",
            name=f"{self.domain_code} gold FAOSTAT unfiltered Iceberg",
            description="Gold table containing all the tag data in FAOSTAT format",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.ICEBERG,
            database=IcebergDatabases.GOLD_DATABASE,
            table=self.iceberg_tables.GOLD_FAOSTAT_UNFILTERED.table,
            path=self.iceberg_tables.GOLD_FAOSTAT_UNFILTERED.path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_iceberg_table,
        )
        logging.debug(f"Tag with Added Iceberg Table: {tag}")

        new_diss_table = BaseDisseminatedTagTable(
            id=f"{self.domain_code.lower()}_gold_faostat_unfiltered_csv",
            name=f"{self.domain_code} gold FAOSTAT unfiltered csv",
            description="Gold table containing the tag data in FAOSTAT format in csv",
            layer=TableLayer.GOLD,
            private=True,
            type=TableType.CSV,
            path=self.iceberg_tables.GOLD_FAOSTAT_UNFILTERED.csv_path,
            structure={"columns": df.schema.jsonValue()["fields"]},
        )
        tag = upsert_disseminated_table(
            sws_tags=tags,
            tag=tag,
            dataset_id=self.dataset_id,
            tag_name=self.tag_name,
            table=new_diss_table,
        )
        logging.debug(f"Tag with Added csv Table: {tag}")

        return df


1
frozenset({"2", "1", "3", "4", "6", "7", "8", "5", "9", "0"})
1
1
2
frozenset({"2", "1", "3", "4", "6", "7", "8", "5", "9", "0"})
2
1
1
frozenset({"2", "1", "3", "4", "6", "7", "8", "5", "9", "0"})
1
1
2
frozenset({"2", "1", "3", "4", "6", "7", "8", "5", "9", "0"})
2
1
1
frozenset({"2", "1", "3", "4", "6", "7", "8", "5", "9", "0"})
1
1
1
frozenset({"4", "1", "6", "8", "2", "7", "5", "9", "3", "0"})
1
1
2
frozenset({"4", "1", "6", "8", "2", "7", "5", "9", "3", "0"})
2
1
1
frozenset({"4", "1", "6", "8", "2", "7", "5", "9", "3", "0"})
1
1
2
frozenset({"4", "1", "6", "8", "2", "7", "5", "9", "3", "0"})
2
1
1
frozenset({"4", "1", "6", "8", "2", "7", "5", "9", "3", "0"})
1
1
