from setuptools import setup, find_packages
import os

here = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(here, "README.md"), encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="datatoolpack",
    version="0.7.4",
    description="Official Python SDK for the AutoData ML data preparation pipeline API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="AutoData Team",
    author_email="support@datatoolpack.com",
    url="https://autodata.datatoolpack.com",
    project_urls={
        "Documentation": "https://autodata.datatoolpack.com/docs",
        "Bug Tracker": "https://github.com/datatoolpack/autodata-client/issues",
    },
    packages=find_packages(exclude=["tests*"]),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.25.0",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="autodata machine-learning data-preparation synthetic-data ml-pipeline",
)
