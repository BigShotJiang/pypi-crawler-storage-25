import sys
import os
import io
import pytest

# Ensure the src directory is in the path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))
from ascii_network_diagram import star_diagram

def run_and_capture(nodes, title):
    buf = io.StringIO()
    sys_stdout = sys.stdout
    sys.stdout = buf
    try:
        star_diagram(nodes, title=title)
    finally:
        sys.stdout = sys_stdout
    return buf.getvalue()

def test_star_diagram_2_nodes():
    nodes2 = [
        {"label": "Router, eth0", "vlan": 100, "connection": "CIR-100"},
        {"label": "Router, eth0", "vlan": 100, "connection": "CIR-100"},
    ]
    output = run_and_capture(nodes2, title="2 Node Star Diagram")
    assert output.strip()  # Output should not be empty

def test_star_diagram_3_nodes():
    nodes3 = [
        {"label": "Router, eth0", "vlan": 200, "connection": "CIR-200"},
        {"label": "Router, eth0", "vlan": 201, "connection": "CIR-201"},
        {"label": "Router, eth0", "vlan": 202, "connection": "CIR-202"},
    ]
    output = run_and_capture(nodes3, title="3 Node Star Diagram")
    assert output.strip()

def test_star_diagram_4_nodes():
    nodes4 = [
        {"label": "Router, eth0", "vlan": 300, "connection": "CIR-300"},
        {"label": "Router, eth0", "vlan": 300, "connection": "CIR-301"},
        {"label": "Router, eth0", "vlan": 300, "connection": "CIR-302"},
        {"label": "Router, eth0", "vlan": 300, "connection": "CIR-303"},
    ]
    output = run_and_capture(nodes4, title="4 Node Star Diagram")
    assert output.strip()

def test_star_diagram_5_nodes():
    nodes5 = [
        {"label": "RouterA, Port1", "vlan": 500, "connection": "CIR-500"},
        {"label": "RouterB, Port2", "vlan": 500, "connection": "CIR-500"},
        {"label": "RouterC, Port3", "vlan": 500, "connection": "CIR-500"},
        {"label": "RouterD, Port4", "vlan": 500, "connection": "CIR-500"},
        {"label": "RouterE, Port5", "vlan": 500, "connection": "CIR-500"},
    ]
    output = run_and_capture(nodes5, title="5 Node Star Diagram")
    assert output.strip()

def test_star_diagram_6_nodes():
    nodes6 = [
        {"label": "RouterA, Port1", "vlan": 600, "connection": "CIR-600"},
        {"label": "RouterB, Port2", "vlan": 600, "connection": "CIR-600"},
        {"label": "RouterC, Port3", "vlan": 600, "connection": "CIR-600"},
        {"label": "RouterD, Port4", "vlan": 600, "connection": "CIR-600"},
        {"label": "RouterE, Port5", "vlan": 600, "connection": "CIR-600"},
        {"label": "RouterF, Port6", "vlan": 600, "connection": "CIR-600"},
    ]
    output = run_and_capture(nodes6, title="6 Node Star Diagram")
    assert output.strip()

def test_star_diagram_7_nodes():
    nodes7 = [
        {"label": "RouterA, Port1", "vlan": 700, "connection": "CIR-700"},
        {"label": "RouterB, Port2", "vlan": 700, "connection": "CIR-700"},
        {"label": "RouterC, Port3", "vlan": 700, "connection": "CIR-700"},
        {"label": "RouterD, Port4", "vlan": 700, "connection": "CIR-700"},
        {"label": "RouterE, Port5", "vlan": 700, "connection": "CIR-700"},
        {"label": "RouterF, Port6", "vlan": 700, "connection": "CIR-700"},
        {"label": "RouterG, Port7", "vlan": 700, "connection": "CIR-700"},
    ]
    output = run_and_capture(nodes7, title="7 Node Star Diagram")
    assert output.strip()

def test_star_diagram_8_nodes():
    nodes8 = [
        {"label": "RouterA, Port1", "vlan": 800, "connection": "CIR-800"},
        {"label": "RouterB, Port2", "vlan": 800, "connection": "CIR-800"},
        {"label": "RouterC, Port3", "vlan": 800, "connection": "CIR-800"},
        {"label": "RouterD, Port4", "vlan": 800, "connection": "CIR-800"},
        {"label": "RouterE, Port5", "vlan": 800, "connection": "CIR-800"},
        {"label": "RouterF, Port6", "vlan": 800, "connection": "CIR-800"},
        {"label": "RouterG, Port7", "vlan": 800, "connection": "CIR-800"},
        {"label": "RouterH, Port8", "vlan": 800, "connection": "CIR-800"},
    ]
    output = run_and_capture(nodes8, title="8 Node Star Diagram")
    assert output.strip()

def test_star_diagram_9_nodes():
    nodes9 = [
        {"label": "RouterA, Port1", "vlan": 900, "connection": "CIR-900"},
        {"label": "RouterB, Port2", "vlan": 900, "connection": "CIR-900"},
        {"label": "RouterC, Port3", "vlan": 900, "connection": "CIR-900"},
        {"label": "RouterD, Port4", "vlan": 900, "connection": "CIR-900"},
        {"label": "RouterE, Port5", "vlan": 900, "connection": "CIR-900"},
        {"label": "RouterF, Port6", "vlan": 900, "connection": "CIR-900"},
        {"label": "RouterG, Port7", "vlan": 900, "connection": "CIR-900"},
        {"label": "RouterH, Port8", "vlan": 900, "connection": "CIR-900"},
        {"label": "RouterI, Port9", "vlan": 900, "connection": "CIR-900"},
    ]
    output = run_and_capture(nodes9, title="9 Node Star Diagram")
    assert output.strip()

def test_star_diagram_10_nodes():
    nodes10 = [
        {"label": "RouterA, Port1", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterB, Port2", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterC, Port3", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterD, Port4", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterE, Port5", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterF, Port6", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterG, Port7", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterH, Port8", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterI, Port9", "vlan": 1000, "connection": "CIR-1000"},
        {"label": "RouterJ, Port10", "vlan": 1000, "connection": "CIR-1000"},
    ]
    output = run_and_capture(nodes10, title="10 Node Star Diagram")
    assert output.strip()

def test_star_diagram_11_nodes():
    nodes11 = [
        {"label": "RouterA, Port1", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterB, Port2", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterC, Port3", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterD, Port4", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterE, Port5", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterF, Port6", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterG, Port7", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterH, Port8", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterI, Port9", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterJ, Port10", "vlan": 1100, "connection": "CIR-1100"},
        {"label": "RouterK, Port11", "vlan": 1100, "connection": "CIR-1100"},
    ]
    output = run_and_capture(nodes11, title="11 Node Star Diagram")
    assert output.strip()

def test_star_diagram_12_nodes():
    nodes12 = [
        {"label": "RouterA, Port1", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterB, Port2", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterC, Port3", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterD, Port4", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterE, Port5", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterF, Port6", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterG, Port7", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterH, Port8", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterI, Port9", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterJ, Port10", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterK, Port11", "vlan": 1200, "connection": "CIR-1200"},
        {"label": "RouterL, Port12", "vlan": 1200, "connection": "CIR-1200"},
    ]
    output = run_and_capture(nodes12, title="12 Node Star Diagram")
    assert output.strip()

def test_star_diagram_1_node():
    nodes1 = [
        {"label": "Router, eth0", "vlan": 100, "connection": "CIR-100"},
    ]
    with pytest.raises(Exception) as excinfo:
        star_diagram(nodes1, title="1 Node Star Diagram")
    assert "Not implemented: Only 2-12 nodes supported in this style" in str(excinfo.value)
