
"""
ascii_network_diagram.star_diagram

A simple Python module to generate ASCII star network diagrams for the terminal.
"""

import re
import shutil

ANSI_RESET = re.compile(r"\x1b\[[0-9;]*m")
RESET = "\033[0m"
BOLD = "\033[1m"
ITALIC = "\033[3m"
CYAN = "\033[36m"
YELLOW = "\033[33m"
GREEN = "\033[32m"
MAGENTA = "\033[35m"
RED = "\033[31m"
GRAY = "\033[90m"

def get_terminal_width(default=80):
    try:
        return shutil.get_terminal_size().columns
    except Exception:
        return default  # fallback if not in a real terminal

def colorize(text, color):
    return f"{color}{text}{RESET}"

def visible_length(s: str) -> int:
    """Calculate the visible length of a string, ignoring ANSI escape codes."""
    return len(ANSI_RESET.sub("", s))

def star_diagram(nodes: list[dict], title: str | None = None) -> None:
    """
    Draws a star network diagram in ASCII art.
    Args:
        nodes (list of dict): Each dict must have 'label' (str) for Hostname/Port.
        vlan_id (int, optional): VLAN ID to display (omitted if None).
        circuit_id (str): Circuit ID to display (required).
    """

    terminal_width = get_terminal_width()
    dash_len = 4
    outer_pad = 2
    prepad = 0
    graph_width = 80

    # Determine box width based on longest label
    max_label_len = max(len(n['label']) for n in nodes)
    if max_label_len % 2 != 0:
      max_label_len += 1  # round up to even
    internal_box_width = max_label_len + 2  # 1 space padding each side
    n = len(nodes)

    # Centering the diagram
    def center(text: str, outline: bool = True) -> str:
      if outline:
        tail_pad = max(0, graph_width - visible_length(text))
        print(f"{' ' * prepad}│{' ' * outer_pad}{text}{' ' * tail_pad}{' ' * outer_pad}│")
      else:
        print(text.center(terminal_width))

    # Unicode box drawing, with width parameter
    def box(label) -> list[str]:
        l = internal_box_width
        top = colorize(f"┌{'─' * l}┐", CYAN + BOLD)
        mid = f"{colorize('│', CYAN + BOLD)}{colorize(label.center(l), GREEN + BOLD)}{colorize('│', CYAN + BOLD)}"
        bot = colorize(f"└{'─' * l}┘", CYAN + BOLD)
        return [top, mid, bot]

    # VLAN text with dynamic dashes
    
    def vlan_text(vlan_id: int | None, direction: str) -> str | list[str]:
      if vlan_id:
        vlan = f"({ITALIC + GRAY}vlan {vlan_id}{RESET})" if vlan_id else ""
        if direction == "right":
            return f"─" * dash_len + f" {vlan} "
        elif direction == "left":
            return f" {vlan} " + f"─" * dash_len
        elif direction == "none":
            return f"{vlan}"
      return ""

    def connected_text(connected_name: str | None) -> str:
      return f"{BOLD}{connected_name}{RESET} " if connected_name else ""

    half_box_pad = int(internal_box_width / 2) + 4
    full_box_pad = internal_box_width + 4

    def above_horizontal_bar(top: list[dict], spacing: list[int]) -> list[str | None]:

      lines = []

      if(len(top) == 1):
        top_box = box(top[0]['label'])
        top_connected = connected_text(top[0].get('connection'))
        top_vlan = vlan_text(top[0].get('vlan'), 'none') or False
        pad_to_center = spacing[0]

        lines.append(f"{' ' * int(pad_to_center - visible_length(top_connected) / 2 + 1)}{top_connected}")

        if(top_vlan):
            lines.append(f"{' ' * pad_to_center}╷")
            lines.append(f"{' ' * pad_to_center}╵")
            lines.append(f"{' ' * int(pad_to_center - visible_length(top_vlan) / 2 + 1)}{top_vlan}")
            
        lines.append(f"{' ' * pad_to_center}╷")
        lines.append(f"{' ' * pad_to_center}│")
        lines.append(f"{' ' * pad_to_center}▼")

        lines.append(f"{' ' * int(pad_to_center - visible_length(top_box[0]) / 2)}{top_box[0]}")
        lines.append(f"{' ' * int(pad_to_center - visible_length(top_box[1]) / 2)}{top_box[1]}")
        lines.append(f"{' ' * int(pad_to_center - visible_length(top_box[2]) / 2)}{top_box[2]}")
        
        lines.append(f"{' ' * pad_to_center}▲")
        lines.append(f"{' ' * pad_to_center}║")
        lines.append(f"{' ' * pad_to_center}║")

      elif(len(top) == 2):
        top_left_box = box(top[0]['label'])
        top_left_connected = connected_text(top[0].get('connection'))
        top_left_vlan = vlan_text(top[0].get('vlan'), 'none') or "│"
        top_right_box = box(top[1]['label'])
        top_right_connected = connected_text(top[1].get('connection'))
        top_right_vlan = vlan_text(top[1].get('vlan'), 'none') or "│"
        pad_to_first = spacing[0]
        pad_to_second = spacing[1]

        lines.append(f"{' ' * int(pad_to_first - visible_length(top_left_connected) / 2 + 1)}{top_left_connected}{' ' * int(pad_to_second - visible_length(top_right_connected) + 1)}{top_right_connected}")

        if(top_left_vlan or top_right_vlan):
            lines.append(f"{' ' * pad_to_first}╷{' ' * pad_to_second}╷")
            lines.append(f"{' ' * pad_to_first}╵{' ' * pad_to_second}╵")
            lines.append(f"{' ' * int(pad_to_first - visible_length(top_left_vlan) / 2 + 1)}{top_left_vlan}{' ' * int(pad_to_second - visible_length(top_right_vlan) + 1)}{top_right_vlan}")
            
        lines.append(f"{' ' * pad_to_first}╷{' ' * pad_to_second}╷")
        lines.append(f"{' ' * pad_to_first}│{' ' * pad_to_second}│")
        lines.append(f"{' ' * pad_to_first}▼{' ' * pad_to_second}▼")

        lines.append(f"{' ' * int(pad_to_first - visible_length(top_left_box[0]) / 2)}{top_left_box[0]}{' ' * (pad_to_second - visible_length(top_left_box[0]) + 1)}{top_right_box[0]}")
        lines.append(f"{' ' * int(pad_to_first - visible_length(top_left_box[1]) / 2)}{top_left_box[1]}{' ' * (pad_to_second - visible_length(top_left_box[1]) + 1)}{top_right_box[1]}")
        lines.append(f"{' ' * int(pad_to_first - visible_length(top_left_box[2]) / 2)}{top_left_box[2]}{' ' * (pad_to_second - visible_length(top_left_box[2]) + 1)}{top_right_box[2]}")
        
        lines.append(f"{' ' * pad_to_first}▲{' ' * pad_to_second}▲")
        lines.append(f"{' ' * pad_to_first}║{' ' * pad_to_second}║")
        lines.append(f"{' ' * pad_to_first}║{' ' * pad_to_second}║")

      elif(len(top) == 3):
        top_left_box = box(top[0]['label'])
        top_left_text = f"{connected_text(top[0].get('connection'))}{'─' * dash_len}{vlan_text(top[0].get('vlan'),'left')}▶ {top_left_box[1]} ◀{'═' * (dash_len // 2)}╗"
        top_center_box = box(top[1]['label'])
        top_center_connected = connected_text(top[1].get('connection'))
        top_center_vlan = vlan_text(top[1].get('vlan'), 'none') or "│"
        top_right_box = box(top[2]['label'])
        top_right_text = f"╔{'═' * (dash_len // 2)}▶ {top_right_box[1]} ◀{vlan_text(top[2].get('vlan'),'right')}{'─' * dash_len} {connected_text(top[2].get('connection'))}"
        
        pad_to_first = spacing[0]
        pad_to_second = spacing[1]
        pad_to_third = spacing[2]

        lines.append(f"{' ' * (pad_to_first + pad_to_second + 1 - (visible_length(top_center_connected) // 2))}{top_center_connected}")

        if(top_center_vlan):
            lines.append(f"{' ' * (pad_to_first + pad_to_second + 1)}╷")
            lines.append(f"{' ' * (pad_to_first + pad_to_second + 1)}╵")
            lines.append(f"{' ' * (pad_to_first + pad_to_second + 1 - (visible_length(top_center_vlan) // 2))}{top_center_vlan}")
            
        lines.append(f"{' ' * (pad_to_first + pad_to_second + 1)}╷")
        lines.append(f"{' ' * (pad_to_first + pad_to_second + 1)}│")
        lines.append(f"{' ' * (pad_to_first + pad_to_second + 1)}▼")

        left_edge_of_center_box = pad_to_first + pad_to_second + 2 - (visible_length(top_center_box[0]) // 2)
        space_from_left_to_center = left_edge_of_center_box - pad_to_first + dash_len // 2 + 2
        right_edge_of_center_box = left_edge_of_center_box + visible_length(top_center_box[0])
        lines.append(f"{' ' * (left_edge_of_center_box)}{top_center_box[0]}")
        lines.append(f"{' ' * (left_edge_of_center_box)}{top_center_box[1]}")
        lines.append(f"{' ' * (left_edge_of_center_box-space_from_left_to_center - visible_length(top_left_box[0]))}{top_left_box[0]}{' ' * space_from_left_to_center}{top_center_box[2]}{' ' * space_from_left_to_center}{top_right_box[0]}")
        
        lines.append(f"{' ' * (pad_to_first - visible_length(top_left_text) + 1)}{top_left_text}{' ' * pad_to_second}▲{' ' * pad_to_third}{top_right_text}")
        lines.append(f"{' ' * (pad_to_first - visible_length(top_left_box[2]) - (dash_len // 2 + 2))}{top_left_box[2]}{' ' * (dash_len // 2 + 2)}║{' ' * pad_to_second}║{' ' * pad_to_third}║{' ' * (dash_len // 2 + 2)}{top_right_box[2]}")
        lines.append(f"{' ' * pad_to_first}║{' ' * pad_to_second}║{' ' * pad_to_third}║")

      elif(len(top) == 4):
        top_left_box = box(top[0]['label'])
        top_left_text = f"{connected_text(top[0].get('connection'))}{'─' * dash_len}{vlan_text(top[0].get('vlan'),'left')}▶ {top_left_box[1]} ◀{'═' * (dash_len // 2)}╗"
        top_center_boxes = [box(top[1]['label']), box(top[2]['label'])]
        top_center_text = f"{connected_text(top[1].get('connection'))}{'─' * dash_len}{vlan_text(top[1].get('vlan'),'left')}▶ {top_center_boxes[0][1]} ◀{'═' * (dash_len)}╦{'═' * (dash_len)}▶ {top_center_boxes[1][1]} ◀{vlan_text(top[2].get('vlan'),'right')}{'─' * dash_len} {connected_text(top[2].get('connection'))}"
        top_right_box = box(top[3]['label'])
        top_right_text = f"╔{'═' * (dash_len // 2)}▶ {top_right_box[1]} ◀{vlan_text(top[2].get('vlan'),'right')}{'─' * dash_len} {connected_text(top[2].get('connection'))}"
        
        pad_to_first = spacing[0]
        pad_to_second = spacing[1]
        pad_to_third = spacing[2]

        lines.append(f"{' ' * (pad_to_first + pad_to_second - dash_len - visible_length(top_center_boxes[0][0]) - 1)}{top_center_boxes[0][0]}{' ' * (dash_len * 2 + 5)}{top_center_boxes[1][0]}")
        lines.append(f"{' ' * (pad_to_first + pad_to_second + 2 - (visible_length(top_center_text) // 2))}{top_center_text}")
        lines.append(f"{' ' * (pad_to_first + pad_to_second - dash_len - visible_length(top_center_boxes[0][2]) - 1)}{top_center_boxes[0][2]}{' ' * (dash_len + 2)}║{' ' * (dash_len + 2)}{top_center_boxes[1][2]}")
        lines.append(f"{' ' * (pad_to_first+ pad_to_second + 1)}║")


        lines.append(f"{' ' * (pad_to_first - visible_length(top_left_box[0]) - (dash_len // 2 + 2))}{top_left_box[0]}{' ' * (dash_len // 2 + 3 + pad_to_second )}║{' ' * (pad_to_third + dash_len // 2 + 3)}{top_right_box[0]}")
        
        lines.append(f"{' ' * (pad_to_first - visible_length(top_left_text) + 1)}{top_left_text}{' ' * pad_to_second}║{' ' * pad_to_third}{top_right_text}")
        lines.append(f"{' ' * (pad_to_first - visible_length(top_left_box[2]) - (dash_len // 2 + 2))}{top_left_box[2]}{' ' * (dash_len // 2 + 2)}║{' ' * pad_to_second}║{' ' * pad_to_third}║{' ' * (dash_len // 2 + 2)}{top_right_box[2]}")
        lines.append(f"{' ' * pad_to_first}║{' ' * pad_to_second}║{' ' * pad_to_third}║")

      elif(len(top) == 5):
        top_left_box = box(top[0]['label'])
        top_left_text = f"{connected_text(top[0].get('connection'))}{'─' * dash_len}{vlan_text(top[0].get('vlan'),'left')}▶ {top_left_box[1]} ◀{'═' * (dash_len // 2)}╗"
        top_center_boxes = [box(top[1]['label']), box(top[3]['label'])]
        top_center_text = f"{connected_text(top[1].get('connection'))}{'─' * dash_len}{vlan_text(top[1].get('vlan'),'left')}▶ {top_center_boxes[0][1]} ◀{'═' * (dash_len)}╬{'═' * (dash_len)}▶ {top_center_boxes[1][1]} ◀{vlan_text(top[3].get('vlan'),'right')}{'─' * dash_len} {connected_text(top[3].get('connection'))}"
        top_right_box = box(top[4]['label'])
        top_right_text = f"╔{'═' * (dash_len // 2)}▶ {top_right_box[1]} ◀{vlan_text(top[4].get('vlan'),'right')}{'─' * dash_len} {connected_text(top[4].get('connection'))}"
        top_center_box = box(top[2]['label'])
        top_center_connected = connected_text(top[2].get('connection'))
        top_center_vlan = vlan_text(top[2].get('vlan'), 'none') or "│"
        
        pad_to_first = spacing[0]
        pad_to_second = spacing[1]
        pad_to_third = spacing[2]

        pad_to_center = pad_to_first + pad_to_second + 1

        lines.append(f"{' ' * int(pad_to_center - visible_length(top_center_connected) / 2 + 1)}{top_center_connected}")

        if(top_center_vlan):
            lines.append(f"{' ' * pad_to_center}╷")
            lines.append(f"{' ' * pad_to_center}╵")
            lines.append(f"{' ' * int(pad_to_center - visible_length(top_center_vlan) / 2 + 1)}{top_center_vlan}")
            
        lines.append(f"{' ' * pad_to_center}╷")
        lines.append(f"{' ' * pad_to_center}│")
        lines.append(f"{' ' * pad_to_center}▼")

        lines.append(f"{' ' * int(pad_to_center - visible_length(top_center_box[0]) / 2)}{top_center_box[0]}")
        lines.append(f"{' ' * int(pad_to_center - visible_length(top_center_box[1]) / 2)}{top_center_box[1]}")
        lines.append(f"{' ' * int(pad_to_center - visible_length(top_center_box[2]) / 2)}{top_center_box[2]}")

        lines.append(f"{' ' * pad_to_center}▲")
        lines.append(f"{' ' * (pad_to_first + pad_to_second - dash_len - visible_length(top_center_boxes[0][0]) - 1)}{top_center_boxes[0][0]}{' ' * (dash_len + 2)}║{' ' * (dash_len + 2)}{top_center_boxes[1][0]}")
        lines.append(f"{' ' * (pad_to_first + pad_to_second + 2 - (visible_length(top_center_text) // 2))}{top_center_text}")
        lines.append(f"{' ' * (pad_to_first + pad_to_second - dash_len - visible_length(top_center_boxes[0][2]) - 1)}{top_center_boxes[0][2]}{' ' * (dash_len + 2)}║{' ' * (dash_len + 2)}{top_center_boxes[1][2]}")
        lines.append(f"{' ' * pad_to_center}║")


        lines.append(f"{' ' * (pad_to_first - visible_length(top_left_box[0]) - (dash_len // 2 + 2))}{top_left_box[0]}{' ' * (dash_len // 2 + 3 + pad_to_second )}║{' ' * (pad_to_third + dash_len // 2 + 3)}{top_right_box[0]}")
        
        lines.append(f"{' ' * (pad_to_first - visible_length(top_left_text) + 1)}{top_left_text}{' ' * pad_to_second}║{' ' * pad_to_third}{top_right_text}")
        lines.append(f"{' ' * (pad_to_first - visible_length(top_left_box[2]) - (dash_len // 2 + 2))}{top_left_box[2]}{' ' * (dash_len // 2 + 2)}║{' ' * pad_to_second}║{' ' * pad_to_third}║{' ' * (dash_len // 2 + 2)}{top_right_box[2]}")
        lines.append(f"{' ' * pad_to_first}║{' ' * pad_to_second}║{' ' * pad_to_third}║")

      return lines

    def below_horizontal_bar(bottom: list[dict], spacing: list[int]) -> list[str]:
      blines = []
      lines = above_horizontal_bar(bottom, spacing)
      for line in lines:
        line = (
          line.replace("╵", "__T1__")
                   .replace("╷", "__T2__")
                   .replace("▲", "__T3__")
                   .replace("▼", "__T4__")
                   .replace("└", "__T5__")
                   .replace("┌", "__T6__")
                   .replace("┘", "__T7__")
                   .replace("┐", "__T8__")
                   .replace("╗", "__T9__")
                   .replace("╔", "__T10__")
                   .replace("╦", "__T11__")
                   .replace("__T1__", "╷")
                   .replace("__T2__", "╵")
                   .replace("__T3__", "▼")
                   .replace("__T4__", "▲")
                   .replace("__T5__", "┌")
                   .replace("__T6__", "└")
                   .replace("__T7__", "┐")
                   .replace("__T8__", "┘")
                   .replace("__T9__", "╝")
                   .replace("__T10__", "╚")
                   .replace("__T11__", "╩")
        )
        blines.insert(0, line)
      return blines

    def horizontal_bar(branches: int, lrnodes: list[dict] = nodes[:2], child: bool = False) -> list[str]:
      left_text = f"{connected_text(lrnodes[0].get('connection'))}{'─' * dash_len}{vlan_text(lrnodes[0].get('vlan'),'left')}▶ "
      right_text = f" ◀{vlan_text(lrnodes[1].get('vlan'),'right')}{'─' * dash_len} {connected_text(lrnodes[1].get('connection'))}"
      left = box(lrnodes[0]['label'])
      right = box(lrnodes[1]['label'])
      pad_left = visible_length(left_text)
      left_box_width = visible_length(left[1])

      spacing_top = [] # Spacing for verticals from left col
      spacing_bottom = [] # Spacing for verticals from left col

      if branches in[8, 9, 10, 11, 12]:
        center_line = f" ◀{'═' * dash_len}╬{'═' * (half_box_pad-3)}╬{'═' * (half_box_pad-2)}╬{'═' * dash_len}▶ "
        spacing_bottom = [pad_left + left_box_width + dash_len + 2, half_box_pad-3, half_box_pad-2] # Spacing for vertical from left col
        spacing_top = [pad_left + left_box_width + dash_len + 2, half_box_pad-3, half_box_pad-2] # Spacing for vertical from left col
        across_the_top = f"{' ' * pad_left}{left[0]}{' ' * (dash_len + 2)}║{' ' * (half_box_pad-3)}║{' ' * (half_box_pad-2)}║{' ' * (dash_len + 2)}{right[0]}"
        across_the_bottom = f"{' ' * pad_left}{left[2]}{' ' * (dash_len + 2)}║{' ' * (half_box_pad-3)}║{' ' * (half_box_pad-2)}║{' ' * (dash_len + 2)}{right[2]}"
      elif branches == 7:
        center_line = f" ◀{'═' * dash_len}╬{'═' * (half_box_pad-3)}╦{'═' * (half_box_pad-2)}╬{'═' * dash_len}▶ "
        spacing_bottom = [pad_left + left_box_width + dash_len + 2, half_box_pad-3, half_box_pad-2] # Spacing for vertical from left col
        spacing_top = [pad_left + left_box_width + dash_len + 2, full_box_pad] # Spacing for vertical from left col
        across_the_top = f"{' ' * pad_left}{left[0]}{' ' * (dash_len + 2)}║{' ' * (internal_box_width + 4)}║{' ' * (dash_len + 2)}{right[0]}"
        across_the_bottom = f"{' ' * pad_left}{left[2]}{' ' * (dash_len + 2)}║{' ' * (half_box_pad-3)}║{' ' * (half_box_pad-2)}║{' ' * (dash_len + 2)}{right[2]}"
      elif branches == 6:
        center_line = f" ◀{'═' * dash_len}╬{'═' * full_box_pad}╬{'═' * dash_len}▶ "
        spacing_bottom = [pad_left + left_box_width + dash_len + 2, full_box_pad] # Spacing for vertical from left col
        spacing_top = [pad_left + left_box_width + dash_len + 2, full_box_pad] # Spacing for vertical from left col
        across_the_top = f"{' ' * pad_left}{left[0]}{' ' * (dash_len + 2)}║{' ' * (internal_box_width + 4)}║{' ' * (dash_len + 2)}{right[0]}"
        across_the_bottom = f"{' ' * pad_left}{left[2]}{' ' * (dash_len + 2)}║{' ' * (internal_box_width + 4)}║{' ' * (dash_len + 2)}{right[2]}"
      elif branches == 5:
        center_line = f" ◀{'═' * dash_len}╦{'═' * (half_box_pad-3)}╩{'═' * (half_box_pad-2)}╦{'═' * dash_len}▶ "
        pad_between_boxes = visible_length(center_line)
        spacing_bottom = [pad_left + left_box_width + dash_len + 2, full_box_pad] # Spacing for vertical from left col
        spacing_top = [pad_left + left_box_width + (pad_between_boxes // 2) - 1] # Spacing for vertical from left col
        across_the_top = f"{' ' * pad_left}{left[0]}{' ' * (pad_between_boxes // 2 - 1)}║{' ' * (pad_between_boxes // 2)}{right[0]}"
        across_the_bottom = f"{' ' * pad_left}{left[2]}{' ' * (dash_len + 2)}║{' ' * (internal_box_width + 4)}║{' ' * (dash_len + 2)}{right[2]}"
      elif branches == 4:
        center_line = f" ◀{'═' * dash_len}╦{'═' * full_box_pad}╦{'═' * dash_len}▶ "
        spacing_bottom = [pad_left + left_box_width + dash_len + 2, full_box_pad] # Spacing for vertical from left col
        pad_between_boxes = visible_length(center_line)
        across_the_top = f"{' ' * pad_left}{left[0]}{' ' * pad_between_boxes}{right[0]}"
        across_the_bottom = f"{' ' * pad_left}{left[2]}{' ' * (dash_len + 2)}║{' ' * (internal_box_width + 4)}║{' ' * (dash_len + 2)}{right[2]}"
      elif branches == 3:
        center_line = f" ◀{'═' * half_box_pad}╦{'═' * half_box_pad}▶ "
        pad_between_boxes = visible_length(center_line)
        spacing_bottom = [pad_left + left_box_width + (pad_between_boxes // 2)] # Spacing for vertical from left col
        across_the_top = f"{' ' * pad_left}{left[0]}{' ' * pad_between_boxes}{right[0]}"
        across_the_bottom = f"{' ' * pad_left}{left[2]}{' ' * (pad_between_boxes // 2)}║{' ' * (pad_between_boxes // 2)}{right[2]}"
      else:
        center_line = f" ◀{'═' * dash_len}═{'═' * dash_len}▶ "
        pad_between_boxes = visible_length(center_line)
        across_the_top = f"{' ' * pad_left}{left[0]}{' ' * pad_between_boxes}{right[0]}"
        across_the_bottom = f"{' ' * pad_left}{left[2]}{' ' * pad_between_boxes}{right[2]}"
      
      down_the_middle = f"{left_text}{left[1]}{center_line}{right[1]}{right_text}"
      return [across_the_top, down_the_middle, across_the_bottom], spacing_top, spacing_bottom
      

    if 2 <= n <= 12:
      if n == 2:
        top = []
        lrnodes = nodes[:2]
        bottom = []
      elif n == 3:
        top = []
        lrnodes = [nodes[0], nodes[-1]]
        bottom = [nodes[1]]
      elif n == 4:
        top = []
        lrnodes = [nodes[0], nodes[-1]]
        bottom = nodes[1:3]
      elif n == 5:
        top = [nodes[-1]]
        lrnodes = [nodes[0], nodes[-2]]
        bottom = nodes[1:3]
      elif n == 6:
        top = nodes[-2:]
        lrnodes = [nodes[0], nodes[-3]]
        bottom = nodes[1:3]
      elif n == 7:
        top = nodes[-2:]
        lrnodes = [nodes[0], nodes[-3]]
        bottom = nodes[1:4]
      elif n == 8:
        top = nodes[-3:]
        lrnodes = [nodes[0], nodes[-4]]
        bottom = nodes[1:4]
      elif n == 9:
        top = nodes[-3:]
        lrnodes = [nodes[0], nodes[-4]]
        bottom = nodes[1:5]
      elif n == 10:
        top = nodes[-4:]
        lrnodes = [nodes[0], nodes[-5]]
        bottom = nodes[1:5]
      elif n == 11:
        top = nodes[-4:]
        lrnodes = [nodes[0], nodes[-5]]
        bottom = nodes[1:6]
      elif n == 12:
        top = nodes[-5:]
        lrnodes = [nodes[0], nodes[-6]]
        bottom = nodes[1:6]

      lines, spacing_top, spacing_bottom = horizontal_bar(branches=n, lrnodes=lrnodes)

      graph_width = visible_length(lines[1])
      if graph_width + 2 * outer_pad > terminal_width:
        prepad = 0
        outline = False
        print(colorize("[Warning] Diagram width exceeds terminal width. Consider shortening labels or reducing the number of nodes.", YELLOW + BOLD))
        print()
      else:
        prepad = (terminal_width - graph_width - 2 * outer_pad) // 2
        outline = True

      if outline:
        print(f"{' ' * prepad}┌{'─' * (graph_width + 2 * outer_pad)}┐")
        center("")  # Empty line for spacing

      if title:
        center(f"{' ' * ((graph_width - visible_length(title)) // 2)}{colorize(title, BOLD + MAGENTA)}")
        center("")  # Empty line for spacing
        print(f"{' ' * prepad}├{'─' * (graph_width + 2 * outer_pad)}┤" if outline else "")
        center("")  # Empty line for spacing

      # Above the center line
      above = above_horizontal_bar(top[::-1], spacing_top)
      for line in above:
        center(line)
        
      # Center line
      center(lines[0]) # Top
      center(lines[1]) # Middle
      center(lines[2]) # Bottom

      # Below the center line
      below = below_horizontal_bar(bottom, spacing_bottom)
      for line in below: 
        center(line)

      center("")  # Empty line for spacing
      print(f"{' ' * prepad}└{'─' * (graph_width + 2 * outer_pad)}┘")

    else:
      raise ValueError("Not implemented: Only 2-12 nodes supported in this style")
    
