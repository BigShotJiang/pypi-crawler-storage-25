__version__ = "0.1.0"

from .star_diagram import star_diagram
