"""Auto-pilot integration for LangGraph.

Exposes:

  NeruvaAutoPilot       -- framework-agnostic core. Fetches substrate
                            prompts (route_intent, reflect, extract) and
                            runs them through a caller-supplied LLM.
                            Returns structured results.

  classify_intent_node  -- pre-built LangGraph node factory. Inject
                            into a graph BEFORE your main node so each
                            user turn auto-routes to the right
                            cognitive tool.

  reflect_node          -- pre-built LangGraph node factory. Inject
                            at the end of your graph (or periodically)
                            to self-curate substrate from recent state.

Pattern-C: substrate emits the prompt, caller LLM runs it, results
pushed back via the existing client. Substrate stays $0/call.
"""
from __future__ import annotations

import json
import re
from typing import Any, Callable, Optional

from neruva_langgraph._client import NeruvaClient


_EXTRACTION_PROMPT = (
    "You are a precise triple extractor. Given input text, extract the "
    "factual (subject, predicate, object) triples it asserts. Use "
    "canonical lowercase tokens. Predicates are short verb phrases "
    "(e.g., 'lives_in', 'works_at', 'said', 'is_a').\n\n"
    "Output ONLY a JSON array. No prose. No commentary.\n\n"
    'Example input: "Alice told me she lives in Toronto and works at Acme."\n'
    'Example output: [["alice","lives_in","toronto"],["alice","works_at","acme"]]\n\n'
    "If the text contains no extractable facts, output []."
)


def _strip_json(s: str) -> str:
    s = s.strip()
    m = re.search(r"```(?:json)?\s*(.+?)```", s, re.DOTALL)
    if m:
        return m.group(1).strip()
    for opener, closer in (("{", "}"), ("[", "]")):
        i, j = s.find(opener), s.rfind(closer)
        if 0 <= i < j:
            return s[i:j + 1]
    return s


class NeruvaAutoPilot:
    """Framework-agnostic auto-pilot helper for LangGraph users."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        namespace: str = "default",
        llm_callable: Optional[Callable[[str], str]] = None,
    ) -> None:
        self.client = NeruvaClient(api_key=api_key)
        self.namespace = namespace
        self.llm_callable = llm_callable
        self._auto_kg = f"{namespace}-auto-kg"

    def _invoke(self, prompt: str) -> str:
        if self.llm_callable is None:
            raise RuntimeError(
                "NeruvaAutoPilot was constructed without llm_callable=. "
                "Pass a callable that takes a prompt string and returns "
                "the LLM's text response (e.g., "
                "lambda p: llm.invoke(p).content)."
            )
        return self.llm_callable(prompt)

    def classify_intent(
        self,
        user_message: str,
        recent_context_summary: Optional[str] = None,
    ) -> dict[str, Any]:
        payload = self.client._post(
            "/v1/agent/route_intent_prompt",
            {
                "user_message": user_message,
                "recent_context_summary": recent_context_summary,
            },
        )
        raw = self._invoke(payload["prompt"])
        try:
            return json.loads(_strip_json(raw))
        except Exception:
            return {"primary_intent": "none", "confidence": 0.0}

    def reflect(
        self,
        recent_turns: list[dict[str, Any]],
        auto_write: bool = True,
    ) -> dict[str, Any]:
        payload = self.client._post(
            "/v1/agent/reflect_prompt",
            {"recent_turns": recent_turns},
        )
        raw = self._invoke(payload["prompt"])
        try:
            parsed = json.loads(_strip_json(raw))
        except Exception:
            return {"decisions": [], "facts": [], "mistakes": [], "open_questions": []}
        if auto_write:
            self._write_reflected(parsed)
        return parsed

    def _write_reflected(self, parsed: dict[str, Any]) -> None:
        items = []
        for d in parsed.get("decisions", []) or []:
            items.append({
                "kind": "decision",
                "text": d.get("text", ""),
                "tags": (d.get("tags") or []) + ["auto-reflected"],
            })
        for m in parsed.get("mistakes", []) or []:
            items.append({
                "kind": "mistake",
                "text": m.get("text", "") + (
                    f"  ROOT CAUSE: {m.get('root_cause')}" if m.get("root_cause") else ""
                ),
                "tags": ["auto-reflected"],
            })
        for q in parsed.get("open_questions", []) or []:
            items.append({
                "kind": "open_question",
                "text": q if isinstance(q, str) else q.get("text", ""),
                "tags": ["auto-reflected"],
            })
        if items:
            try:
                self.client._post(f"/v1/records/{self.namespace}", {"items": items})
            except Exception:
                pass
        facts = parsed.get("facts", []) or []
        triples = [
            [f.get("subject", ""), f.get("relation", ""), f.get("object", "")]
            for f in facts
            if f.get("subject") and f.get("relation") and f.get("object")
        ]
        if triples:
            try:
                self.client._post(
                    f"/v1/hd/kg/{self._auto_kg}/facts",
                    {"facts": triples},
                )
            except Exception:
                pass

    def extract_facts(self, text: str, auto_write: bool = True) -> list[list[str]]:
        prompt = _EXTRACTION_PROMPT + "\n\nINPUT:\n" + text
        raw = self._invoke(prompt)
        try:
            triples = json.loads(_strip_json(raw))
        except Exception:
            return []
        if not isinstance(triples, list):
            return []
        clean = [
            t for t in triples
            if isinstance(t, list) and len(t) == 3 and all(isinstance(x, str) for x in t)
        ]
        if auto_write and clean:
            try:
                self.client._post(
                    f"/v1/hd/kg/{self._auto_kg}/facts",
                    {"facts": clean},
                )
            except Exception:
                pass
        return clean


# ---- LangGraph node factories ------------------------------------------

def classify_intent_node(
    auto_pilot: NeruvaAutoPilot,
    message_key: str = "messages",
    output_key: str = "neruva_intent",
) -> Callable[[dict], dict]:
    """Return a LangGraph node that, given graph state with a list of
    messages under `message_key`, classifies the LATEST user message
    and stores the classification under `output_key`.

    Example:
        from neruva_langgraph import NeruvaAutoPilot, classify_intent_node
        ap = NeruvaAutoPilot(api_key="nv_...", namespace="my_app",
                              llm_callable=lambda p: llm.invoke(p).content)
        graph.add_node("classify", classify_intent_node(ap))
        graph.add_edge(START, "classify")
        graph.add_edge("classify", "my_main_node")
    """
    def _node(state: dict) -> dict:
        msgs = state.get(message_key) or []
        last_user = None
        for m in reversed(msgs):
            # Tolerate dict-shaped and LangChain message objects
            role = getattr(m, "type", None) or (m.get("role") if isinstance(m, dict) else None)
            text = getattr(m, "content", None) or (m.get("content") if isinstance(m, dict) else None)
            if role in ("user", "human") and isinstance(text, str) and text.strip():
                last_user = text
                break
        if not last_user:
            return {output_key: {"primary_intent": "none", "confidence": 0.0}}
        try:
            intent = auto_pilot.classify_intent(last_user)
        except Exception:
            intent = {"primary_intent": "none", "confidence": 0.0}
        return {output_key: intent}
    return _node


def reflect_node(
    auto_pilot: NeruvaAutoPilot,
    message_key: str = "messages",
    last_n: int = 10,
) -> Callable[[dict], dict]:
    """Return a LangGraph node that reflects over the last N messages
    and auto-writes structured records (decisions/facts/mistakes/qs).
    Returns the parsed reflection under `state['neruva_reflection']`.

    Wire as the final node of your graph or as a periodic side-effect.
    """
    def _node(state: dict) -> dict:
        msgs = (state.get(message_key) or [])[-last_n:]
        recent_turns = []
        for m in msgs:
            role = getattr(m, "type", None) or (m.get("role") if isinstance(m, dict) else None)
            text = getattr(m, "content", None) or (m.get("content") if isinstance(m, dict) else None)
            if role and isinstance(text, str) and text.strip():
                recent_turns.append({"role": role, "text": text[:4000]})
        if len(recent_turns) < 3:
            return {"neruva_reflection": None}
        try:
            parsed = auto_pilot.reflect(recent_turns, auto_write=True)
        except Exception:
            parsed = None
        return {"neruva_reflection": parsed}
    return _node
