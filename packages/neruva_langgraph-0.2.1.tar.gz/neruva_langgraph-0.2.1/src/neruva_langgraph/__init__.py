"""LangGraph integration for Neruva agent memory.

Two primary plug points covering the LangGraph memory surface:

  NeruvaCheckpointSaver  -- subclass of langgraph.checkpoint.base
                            .BaseCheckpointSaver. Persists graph
                            checkpoints into Records substrate, one
                            namespace per thread_id.

  NeruvaContextStore     -- subclass of langgraph.store.base.BaseStore.
                            Cross-thread, multi-namespace KV store
                            backed by Records.

Optional, for graphs that mix raw LangChain calls inside nodes:

  NeruvaMessageHistory   -- BaseChatMessageHistory mirror of the same
                            wrapper in neruva-langchain.

Install:
    pip install neruva-langgraph

Usage (3 lines):
    from langgraph.graph import StateGraph
    from neruva_langgraph import NeruvaCheckpointSaver
    graph = builder.compile(checkpointer=NeruvaCheckpointSaver(api_key="nv_..."))
"""
from neruva_langgraph.checkpoint import NeruvaCheckpointSaver
from neruva_langgraph.store import NeruvaContextStore

try:
    from neruva_langgraph.history import NeruvaMessageHistory
    _OPTIONAL = ["NeruvaMessageHistory"]
except Exception:  # pragma: no cover - optional dep
    _OPTIONAL = []

try:
    from neruva_langgraph.auto_pilot import (
        NeruvaAutoPilot,
        classify_intent_node,
        reflect_node,
    )
    _AUTOPILOT = ["NeruvaAutoPilot", "classify_intent_node", "reflect_node"]
except Exception:  # pragma: no cover
    _AUTOPILOT = []

from neruva_langgraph.toolbox import NeruvaCodeGraph, NeruvaCognitive

__all__ = [
    "NeruvaCheckpointSaver",
    "NeruvaContextStore",
    "NeruvaCodeGraph",
    "NeruvaCognitive",
] + _OPTIONAL + _AUTOPILOT

from importlib.metadata import PackageNotFoundError, version as _pkg_version

try:
    __version__ = _pkg_version("neruva-langgraph")
except PackageNotFoundError:
    __version__ = "0.0.0+local"
