"""RPC method handlers - thin wrappers around WebTapService.

PUBLIC API:
  - register_handlers: Register all RPC handlers with the framework

Handlers receive RPCContext and delegate to WebTapService for business logic.
Per-target state is managed by ConnectionManager via ctx.service.conn_mgr.
"""

import threading

from webtap.rpc.errors import ErrorCode, RPCError
from webtap.rpc.framework import RPCContext, RPCFramework

_ATTACHED_STATES = ["attached", "inspecting"]
_ATTACHED_ONLY = ["attached"]

__all__ = ["register_handlers"]


def _get_connected_targets(ctx: RPCContext) -> list[dict]:
    """Get minimal target info for response embedding."""
    return [
        {
            "target": conn.target,
            "title": conn.page_info.get("title", ""),
            "url": conn.page_info.get("url", ""),
        }
        for conn in ctx.service.conn_mgr.get_all()
    ]


def _resolve_cdp_session(ctx: RPCContext, target: str | None):
    """Resolve target to CDPSession.

    Args:
        ctx: RPC context
        target: Target ID or None for single connection

    Returns:
        CDPSession instance

    Raises:
        RPCError: If target not found, no connections, or multiple connections without target
    """
    if target:
        conn = ctx.service.get_connection(target)
        if not conn:
            raise RPCError(ErrorCode.INVALID_PARAMS, f"Target '{target}' not found")
        return conn.cdp

    # No target specified - must have exactly one connection
    if len(ctx.service.connections) == 0:
        raise RPCError(ErrorCode.NOT_CONNECTED, "No connections active")
    if len(ctx.service.connections) > 1:
        raise RPCError(ErrorCode.INVALID_PARAMS, "Multiple connections active. Specify target parameter.")

    # Return the only connection's CDPSession
    return next(iter(ctx.service.connections.values())).cdp


def register_handlers(rpc: RPCFramework) -> None:
    """Register all RPC handlers with the framework.

    Args:
        rpc: RPCFramework instance to register handlers with
    """
    rpc.method("watch")(_watch)
    rpc.method("unwatch")(_unwatch)
    rpc.method("targets", broadcasts=False)(_targets)
    rpc.method("status", broadcasts=False)(_status)
    rpc.method("clear", requires_state=_ATTACHED_STATES)(_clear)

    rpc.method("browser.startInspect", requires_state=_ATTACHED_ONLY)(_browser_start_inspect)
    rpc.method("browser.stopInspect", requires_state=_ATTACHED_STATES)(_browser_stop_inspect)
    rpc.method("browser.clear", requires_state=_ATTACHED_STATES)(_browser_clear)

    rpc.method("fetch")(_fetch)

    rpc.method("network", broadcasts=False)(_network)
    rpc.method("request", broadcasts=False)(_request)
    rpc.method("console", broadcasts=False)(_console)
    rpc.method("entry", broadcasts=False)(_entry)

    rpc.method("filters.status", broadcasts=False)(_filters_status)
    rpc.method("filters.add", broadcasts=False)(_filters_add)
    rpc.method("filters.remove", broadcasts=False)(_filters_remove)
    rpc.method("filters.enable", requires_state=_ATTACHED_STATES)(_filters_enable)
    rpc.method("filters.disable", requires_state=_ATTACHED_STATES)(_filters_disable)
    rpc.method("filters.enableAll", requires_state=_ATTACHED_STATES)(_filters_enable_all)
    rpc.method("filters.disableAll", requires_state=_ATTACHED_STATES)(_filters_disable_all)

    rpc.method("navigate", requires_state=_ATTACHED_STATES)(_navigate)
    rpc.method("reload", requires_state=_ATTACHED_STATES)(_reload)
    rpc.method("back", requires_state=_ATTACHED_STATES)(_back)
    rpc.method("forward", requires_state=_ATTACHED_STATES)(_forward)
    rpc.method("history", requires_state=_ATTACHED_STATES, broadcasts=False)(_history)
    rpc.method("page", requires_state=_ATTACHED_STATES, broadcasts=False)(_page)

    rpc.method("js")(_js)
    rpc.method("screenshot", requires_state=_ATTACHED_STATES, broadcasts=False)(_screenshot)

    rpc.method("inject", requires_state=_ATTACHED_STATES)(_inject)
    rpc.method("inject_remove", requires_state=_ATTACHED_STATES)(_inject_remove)
    rpc.method("inject_list", requires_state=_ATTACHED_STATES, broadcasts=False)(_inject_list)

    rpc.method("bind", requires_state=_ATTACHED_STATES)(_bind)
    rpc.method("bind_remove", requires_state=_ATTACHED_STATES)(_bind_remove)

    rpc.method("cdp", requires_state=_ATTACHED_STATES)(_cdp)
    rpc.method("click", requires_state=_ATTACHED_STATES)(_click)
    rpc.method("type", requires_state=_ATTACHED_STATES)(_type)
    rpc.method("errors.dismiss")(_errors_dismiss)

    rpc.method("targets.set")(_targets_set)
    rpc.method("targets.clear")(_targets_clear)
    rpc.method("targets.get", broadcasts=False)(_targets_get)

    rpc.method("ports.add", broadcasts=False)(_ports_add)
    rpc.method("ports.remove", broadcasts=False)(_ports_remove)
    rpc.method("ports.list", broadcasts=False)(_ports_list)


def _watch(ctx: RPCContext, targets: list[str] | None = None, urls: list[str] | None = None) -> dict:
    """Watch targets by ID and/or URL patterns."""
    if not targets and not urls:
        raise RPCError(ErrorCode.INVALID_PARAMS, "Specify targets and/or urls")
    results: dict = {}
    if targets:
        results.update(ctx.service.watch_targets(targets))
    if urls:
        results.update(ctx.service.watch_url_patterns(urls))
    return results


def _unwatch(ctx: RPCContext, targets: list[str] | None = None, urls: list[str] | None = None) -> dict:
    """Stop watching targets and/or URL patterns. Both None = unwatch all."""
    if targets is None and urls is None:
        return ctx.service.unwatch_targets(None)
    results: dict = {}
    if targets:
        results.update(ctx.service.unwatch_targets(targets))
    if urls:
        results.update(ctx.service.unwatch_url_patterns(urls))
    return results


def _targets(ctx: RPCContext) -> dict:
    """List all discoverable targets with watch/attach state."""
    return ctx.service.list_targets()


def _status(ctx: RPCContext) -> dict:
    """Get comprehensive status including connection, events, browser, and fetch details."""
    from webtap.api import get_full_state

    return get_full_state()


def _clear(ctx: RPCContext) -> dict:
    """Clear CDP events from all connected and stashed targets."""
    for conn in ctx.service.connections.values():
        try:
            conn.cdp.clear_events()
        except Exception:
            pass
    # Clean up stashed DBs from disconnected URL-watched targets
    for cdp in list(ctx.service._stashed_dbs.values()):
        cdp.cleanup()
    ctx.service._stashed_dbs.clear()
    ctx.service._detached_urls.clear()
    return {"cleared": ["events"]}


def _browser_start_inspect(ctx: RPCContext, target: str) -> dict:
    """Enable CDP element inspection mode on a specific target."""
    if target not in ctx.service.connections:
        raise RPCError(ErrorCode.INVALID_PARAMS, f"Target '{target}' not connected")

    ctx.service.conn_mgr.set_inspecting(target, True)
    result = ctx.service.dom.start_inspect(target)
    return {**result}


def _browser_stop_inspect(ctx: RPCContext) -> dict:
    """Disable CDP element inspection mode."""
    for target in ctx.service.connections:
        ctx.service.conn_mgr.set_inspecting(target, False)
    result = ctx.service.dom.stop_inspect()
    return {**result}


def _browser_clear(ctx: RPCContext) -> dict:
    """Clear all element selections."""
    ctx.service.dom.clear_selections()
    return {"success": True, "selections": {}}


def _fetch(ctx: RPCContext, rules: dict | None = None) -> dict:
    """Handle fetch configuration.

    API:
        fetch()                              -> get status
        fetch({"capture": False})            -> disable capture globally
        fetch({"capture": True})             -> re-enable capture globally
        fetch({"block": [...], "target": "..."}) -> set block rules for target
        fetch({"mock": {...}, "target": "..."})  -> set mock rules for target
        fetch({"target": "..."})             -> clear rules for target
    """
    if rules is None:
        # No args - return status
        return ctx.service.fetch.get_status()

    # Check for global capture toggle
    if "capture" in rules and len(rules) == 1:
        return ctx.service.fetch.set_capture(rules["capture"])

    # Check for target-specific rules
    if "target" in rules:
        target = rules["target"]
        if target not in ctx.service.connections:
            raise RPCError(ErrorCode.INVALID_PARAMS, f"Target '{target}' not connected")
        return ctx.service.fetch.set_rules(
            target=target,
            block=rules.get("block"),
            mock=rules.get("mock"),
        )

    # Block/mock without target is error
    if "block" in rules or "mock" in rules:
        raise RPCError(ErrorCode.INVALID_PARAMS, "block/mock rules require 'target' parameter")

    return ctx.service.fetch.get_status()


def _network(
    ctx: RPCContext,
    limit: int = 50,
    status: int | None = None,
    method: str | None = None,
    resource_type: str | None = None,
    url: str | None = None,
    state: str | None = None,
    search: str | None = None,
    show_all: bool = False,
    order: str = "desc",
    target: str | list[str] | None = None,
    wait: int | None = None,
) -> dict:
    """Query network requests with inline filters. Optionally wait for matches."""

    def _query() -> list[dict]:
        return ctx.service.network.get_requests(
            limit=limit,
            status=status,
            method=method,
            type_filter=resource_type,
            url=url,
            state=state,
            search=search,
            apply_groups=not show_all,
            order=order,
            target=target,
        )

    requests = _query()

    if requests or wait is None:
        return {"targets": _get_connected_targets(ctx), "requests": requests}

    # Wait mode: block until any network event arrives, then re-query
    match_event = threading.Event()
    timeout_seconds = min(wait, 60)

    cdps = ctx.service.get_query_cdps([target] if isinstance(target, str) else target)

    def on_network_event(event: dict) -> None:
        match_event.set()

    listen_methods = ["Network.responseReceived", "Network.loadingFinished", "Network.loadingFailed"]

    for cdp in cdps:
        for method_name in listen_methods:
            cdp.register_event_callback(method_name, on_network_event)

    try:
        match_event.wait(timeout=timeout_seconds)
        requests = _query()
    finally:
        for cdp in cdps:
            for method_name in listen_methods:
                cdp.unregister_event_callback(method_name, on_network_event)

    return {"targets": _get_connected_targets(ctx), "requests": requests}


def _request(ctx: RPCContext, id: int, target: str, fields: list[str] | None = None) -> dict:
    """Get request details with field selection. Target required (row IDs are per-DB)."""
    entry, resolution = ctx.service.network.get_request_details(id, target=target)
    if not entry:
        raise RPCError(ErrorCode.INVALID_PARAMS, f"Request {id} not found")

    selected = ctx.service.network.select_fields(entry, fields)
    result: dict = {"entry": selected}
    if resolution.get("via") and resolution["via"] != "active":
        result["resolution"] = resolution
    return result


def _console(ctx: RPCContext, limit: int = 50, level: str | None = None, target: str | list[str] | None = None) -> dict:
    """Get console messages."""
    rows = ctx.service.console.get_recent_messages(limit=limit, level=level, target=target)

    messages = []
    for row in rows:
        rowid, msg_level, source, message, timestamp, row_target = row
        messages.append(
            {
                "id": rowid,
                "level": msg_level or "log",
                "source": source or "console",
                "message": message or "",
                "timestamp": float(timestamp) if timestamp else None,
                "target": row_target,
            }
        )

    return {"targets": _get_connected_targets(ctx), "messages": messages}


def _entry(ctx: RPCContext, id: int, target: str, fields: list[str] | None = None) -> dict:
    """Get console entry details with field selection. Target required (row IDs are per-DB)."""
    entry_data, resolution = ctx.service.console.get_entry_details(id, target=target)
    if not entry_data:
        raise RPCError(ErrorCode.INVALID_PARAMS, f"Console entry {id} not found")

    selected = ctx.service.console.select_fields(entry_data, fields)
    result: dict = {"entry": selected}
    if resolution.get("via") and resolution["via"] != "active":
        result["resolution"] = resolution
    return result


def _filters_status(ctx: RPCContext) -> dict:
    """Get all filter groups with enabled status."""
    return ctx.service.filters.get_status()


def _filters_add(ctx: RPCContext, name: str, hide: dict) -> dict:
    """Add a new filter group."""
    ctx.service.filters.add(name, hide)
    return {"added": True, "name": name}


def _filters_remove(ctx: RPCContext, name: str) -> dict:
    """Remove a filter group."""
    result = ctx.service.filters.remove(name)
    if result:
        return {"removed": True, "name": name}
    return {"removed": False, "name": name}


def _filters_enable(ctx: RPCContext, name: str) -> dict:
    """Enable a filter group."""
    result = ctx.service.filters.enable(name)
    if result:
        return {"enabled": True, "name": name}
    raise RPCError(ErrorCode.INVALID_PARAMS, f"Group '{name}' not found")


def _filters_disable(ctx: RPCContext, name: str) -> dict:
    """Disable a filter group."""
    result = ctx.service.filters.disable(name)
    if result:
        return {"disabled": True, "name": name}
    raise RPCError(ErrorCode.INVALID_PARAMS, f"Group '{name}' not found")


def _filters_enable_all(ctx: RPCContext) -> dict:
    """Enable all filter groups."""
    fm = ctx.service.filters
    for name in fm.groups:
        fm.enable(name)
    return {"enabled": list(fm.enabled)}


def _filters_disable_all(ctx: RPCContext) -> dict:
    """Disable all filter groups."""
    ctx.service.filters.disable_all()
    return {"enabled": []}


def _inject(ctx: RPCContext, code: str, target: str) -> dict:
    """Inject a persistent script via Page.addScriptToEvaluateOnNewDocument."""
    try:
        result = ctx.service.execute_on_target(
            target,
            lambda cdp: cdp.execute("Page.addScriptToEvaluateOnNewDocument", {"source": code}),
        )
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))

    identifier = result.get("identifier", "")
    code_preview = code[:80] + ("..." if len(code) > 80 else "")

    ctx.service.track_injection(target, identifier, code_preview)
    return {"identifier": identifier, "code_preview": code_preview}


def _inject_remove(ctx: RPCContext, id: str, target: str) -> dict:
    """Remove a persistent script injection."""
    try:
        ctx.service.execute_on_target(
            target,
            lambda cdp: cdp.execute("Page.removeScriptToEvaluateOnNewDocument", {"identifier": id}),
        )
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))

    ctx.service.remove_injection(target, id)
    return {"removed": True, "identifier": id}


def _inject_list(ctx: RPCContext, target: str) -> dict:
    """List active script injections."""
    injections = ctx.service.get_injections(target)
    return {"injections": injections}


def _bind(ctx: RPCContext, name: str, target: str) -> dict:
    """Register a page-callable binding via Runtime.addBinding."""
    try:
        ctx.service.execute_on_target(
            target,
            lambda cdp: cdp.execute("Runtime.addBinding", {"name": name}),
        )
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))

    ctx.service.register_binding(target, name)
    return {"bound": True, "name": name}


def _bind_remove(ctx: RPCContext, name: str, target: str) -> dict:
    """Remove a page-callable binding."""
    try:
        ctx.service.execute_on_target(
            target,
            lambda cdp: cdp.execute("Runtime.removeBinding", {"name": name}),
        )
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))

    ctx.service.unregister_binding(target, name)
    return {"removed": True, "name": name}


def _cdp(ctx: RPCContext, command: str, params: dict | None = None, target: str | None = None) -> dict:
    """Execute arbitrary CDP command."""
    cdp_session = _resolve_cdp_session(ctx, target)
    result = cdp_session.execute(command, params or {})
    return {"result": result}


def _resolve_selector(ctx: RPCContext, selector: str | None, selection: int | None) -> str:
    """Resolve selector from explicit CSS or selection ID."""
    if selection is not None:
        dom_state = ctx.service.dom.get_state()
        selections = dom_state.get("selections", {})
        sel_key = str(selection)
        if sel_key not in selections:
            available = ", ".join(selections.keys()) if selections else "none"
            raise RPCError(ErrorCode.INVALID_PARAMS, f"Selection #{selection} not found. Available: {available}")
        resolved = selections[sel_key].get("selector")
        if not resolved:
            raise RPCError(ErrorCode.INVALID_PARAMS, f"Selection #{selection} has no CSS selector")
        return resolved
    if not selector:
        raise RPCError(ErrorCode.INVALID_PARAMS, "Either selector or selection is required")
    return selector


def _click(ctx: RPCContext, selector: str, target: str, selection: int | None = None) -> dict:
    """Click element at its center coordinates."""
    resolved = _resolve_selector(ctx, selector, selection)
    try:
        return ctx.service.execute_on_target(target, lambda cdp: _click_impl(ctx.service.input, cdp, resolved))
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _click_impl(input_svc, cdp, selector: str) -> dict:
    """Resolve coordinates and dispatch click."""
    x, y = input_svc.resolve_element_center(cdp, selector)
    input_svc.click_at(cdp, x, y)
    return {"selector": selector, "x": x, "y": y, "clicked": True}


def _type(
    ctx: RPCContext,
    selector: str,
    text: str,
    target: str,
    delay_ms: int = 50,
    selection: int | None = None,
) -> dict:
    """Focus element and type text via CDP Input domain."""
    resolved = _resolve_selector(ctx, selector, selection)
    try:
        return ctx.service.execute_on_target(
            target, lambda cdp: _type_impl(ctx.service.input, cdp, resolved, text, delay_ms)
        )
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _type_impl(input_svc, cdp, selector: str, text: str, delay_ms: int) -> dict:
    """Click to focus, then dispatch key events."""
    from webtap.services.input import _tokenize_input

    x, y = input_svc.resolve_element_center(cdp, selector)
    input_svc.click_at(cdp, x, y)
    input_svc.type_text(cdp, text, delay_ms)
    return {"selector": selector, "typed": True, "length": len(_tokenize_input(text))}


def _errors_dismiss(ctx: RPCContext) -> dict:
    """Dismiss the current error."""
    ctx.service.clear_error()
    return {"success": True}


def _navigate(ctx: RPCContext, url: str, target: str) -> dict:
    """Navigate to URL."""
    try:
        result = ctx.service.execute_on_target(target, lambda cdp: cdp.execute("Page.navigate", {"url": url}))
        return {
            "url": url,
            "frame_id": result.get("frameId"),
            "loader_id": result.get("loaderId"),
            "error": result.get("errorText"),
        }
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _reload(ctx: RPCContext, target: str, ignore_cache: bool = False) -> dict:
    """Reload current page."""
    try:
        ctx.service.execute_on_target(target, lambda cdp: cdp.execute("Page.reload", {"ignoreCache": ignore_cache}))
        return {"reloaded": True, "ignore_cache": ignore_cache}
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _back(ctx: RPCContext, target: str) -> dict:
    """Navigate back in history."""
    try:
        return ctx.service.execute_on_target(target, lambda cdp: _navigate_history_impl(cdp, -1))
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _forward(ctx: RPCContext, target: str) -> dict:
    """Navigate forward in history."""
    try:
        return ctx.service.execute_on_target(target, lambda cdp: _navigate_history_impl(cdp, +1))
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _navigate_history_impl(cdp, direction: int) -> dict:
    """Navigate to history entry by direction offset."""
    result = cdp.execute("Page.getNavigationHistory", {})
    entries = result.get("entries", [])
    current = result.get("currentIndex", 0)
    target_idx = current + direction

    if target_idx < 0:
        return {"navigated": False, "reason": "Already at first entry"}
    if target_idx >= len(entries):
        return {"navigated": False, "reason": "Already at last entry"}

    target_entry = entries[target_idx]
    cdp.execute("Page.navigateToHistoryEntry", {"entryId": target_entry["id"]})

    return {
        "navigated": True,
        "title": target_entry.get("title", ""),
        "url": target_entry.get("url", ""),
        "index": target_idx,
        "total": len(entries),
    }


def _history(ctx: RPCContext, target: str | None = None) -> dict:
    """Get navigation history."""
    cdp_session = _resolve_cdp_session(ctx, target)
    result = cdp_session.execute("Page.getNavigationHistory", {})
    entries = result.get("entries", [])
    current = result.get("currentIndex", 0)

    return {
        "entries": [
            {
                "id": e.get("id"),
                "url": e.get("url", ""),
                "title": e.get("title", ""),
                "type": e.get("transitionType", ""),
                "current": i == current,
            }
            for i, e in enumerate(entries)
        ],
        "current_index": current,
    }


def _page(ctx: RPCContext, target: str | None = None) -> dict:
    """Get current page info with title from DOM."""
    cdp_session = _resolve_cdp_session(ctx, target)
    result = cdp_session.execute("Page.getNavigationHistory", {})
    entries = result.get("entries", [])
    current_index = result.get("currentIndex", 0)

    if not entries or current_index >= len(entries):
        return {"url": "", "title": "", "id": None, "type": ""}

    current = entries[current_index]

    try:
        title_result = cdp_session.execute("Runtime.evaluate", {"expression": "document.title", "returnByValue": True})
        title = title_result.get("result", {}).get("value", current.get("title", ""))
    except Exception:
        title = current.get("title", "")

    return {
        "url": current.get("url", ""),
        "title": title or "Untitled",
        "id": current.get("id"),
        "type": current.get("transitionType", ""),
    }


def _js(
    ctx: RPCContext,
    code: str,
    target: str,
    selection: int | None = None,
    persist: bool = False,
    await_promise: bool = False,
    return_value: bool = True,
) -> dict:
    """Execute JavaScript in browser context."""
    try:
        return ctx.service.execute_on_target(
            target, lambda cdp: _execute_js(ctx, cdp, code, selection, persist, await_promise, return_value)
        )
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _execute_js(ctx, cdp, code, selection, persist, await_promise, return_value) -> dict:
    """Execute JavaScript on a CDP session with optional element binding."""
    if selection is not None and persist:
        raise RPCError(
            ErrorCode.INVALID_PARAMS,
            "Cannot use selection with persist=True. "
            "For element operations with global state, store element manually: "
            "js(target, \"window.el = document.querySelector('...')\", persist=True)",
        )

    if selection is not None:
        dom_state = ctx.service.dom.get_state()
        selections = dom_state.get("selections", {})
        sel_key = str(selection)

        if sel_key not in selections:
            available = ", ".join(selections.keys()) if selections else "none"
            raise RPCError(ErrorCode.INVALID_PARAMS, f"Selection #{selection} not found. Available: {available}")

        js_path = selections[sel_key].get("jsPath")
        if not js_path:
            raise RPCError(ErrorCode.INVALID_PARAMS, f"Selection #{selection} has no jsPath")

        code = f"const element = {js_path};\n{code}"

    result = cdp.execute(
        "Runtime.evaluate",
        {
            "expression": code,
            "awaitPromise": await_promise,
            "returnByValue": return_value,
            "replMode": not persist,
        },
    )

    if result.get("exceptionDetails"):
        exception = result["exceptionDetails"]
        error_text = exception.get("exception", {}).get("description", str(exception))
        raise RPCError(ErrorCode.INTERNAL_ERROR, f"JavaScript error: {error_text}")

    if return_value:
        value = result.get("result", {}).get("value")
        return {"value": value, "executed": True}
    else:
        return {"executed": True}


def _screenshot(
    ctx: RPCContext,
    target: str,
    format: str = "png",
    quality: int | None = None,
    full_page: bool = False,
) -> dict:
    """Capture screenshot of target page."""
    cdp = _resolve_cdp_session(ctx, target)
    params: dict = {"format": format}
    if quality is not None:
        params["quality"] = quality
    if full_page:
        params["captureBeyondViewport"] = True
    result = cdp.execute("Page.captureScreenshot", params)
    return {"data": result["data"], "format": format}


def _targets_set(ctx: RPCContext, targets: list[str]) -> dict:
    """Set tracked targets for default aggregation scope."""
    # Validate all targets exist in connections
    invalid = [t for t in targets if t not in ctx.service.connections]
    if invalid:
        raise RPCError(ErrorCode.INVALID_PARAMS, f"Unknown targets: {invalid}")

    ctx.service.set_tracked_targets(targets)
    return {
        "tracked": ctx.service.tracked_targets,
        "connected": list(ctx.service.connections.keys()),
    }


def _targets_clear(ctx: RPCContext) -> dict:
    """Clear tracked targets (show all)."""
    ctx.service.set_tracked_targets([])
    return {
        "tracked": ctx.service.tracked_targets,
        "connected": list(ctx.service.connections.keys()),
    }


def _targets_get(ctx: RPCContext) -> dict:
    """Get current tracked targets."""
    return {
        "tracked": ctx.service.tracked_targets,
        "connected": list(ctx.service.connections.keys()),
    }


def _ports_add(ctx: RPCContext, port: int) -> dict:
    """Register a Chrome debug port with the daemon."""
    try:
        return ctx.service.register_port(port)
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _ports_remove(ctx: RPCContext, port: int) -> dict:
    """Unregister a port from daemon tracking."""
    try:
        return ctx.service.unregister_port(port)
    except ValueError as e:
        raise RPCError(ErrorCode.INVALID_PARAMS, str(e))


def _ports_list(ctx: RPCContext) -> dict:
    """List all registered ports with their status."""
    return ctx.service.list_ports()
