import os
from typing import TYPE_CHECKING, Any, Optional

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from splink.internals.input_column import InputColumn
from splink.internals.splink_dataframe import SplinkDataFrame

if TYPE_CHECKING:
    from .database_api import SnowflakeAPI


class SnowflakeDataframe(SplinkDataFrame):
    db_api: "SnowflakeAPI"

    @property
    def columns(self) -> list[InputColumn]:
        sql = (
            f"SELECT lower(column_name) FROM information_schema.columns "
            f"WHERE table_name = '{self.physical_name.upper()}' "
            f"AND table_schema = CURRENT_SCHEMA()"
        )
        res = self.db_api._execute_sql_against_backend(sql)
        cols = [col[0] for col in res.fetchall()]
        return [InputColumn(col, sqlglot_dialect_str="snowflake") for col in cols]

    def validate(self):
        """
        Concrete impl of super class; unclear what is expected.

        Pass for now
        """
        pass

    def _create_or_replace_temp_view(self, name: str, physical: str) -> None:
        self.db_api._execute_sql_against_backend(f"DROP VIEW IF EXISTS {name}")
        self.db_api._execute_sql_against_backend(
            f"CREATE TEMP VIEW {name} AS SELECT * FROM {physical}"
        )

    def as_record_dict(self, limit: Optional[int] = None) -> list[dict[str, Any]]:
        sql = f"SELECT * FROM {self.physical_name}"
        if limit:
            sql += f" LIMIT {limit}"

        snowflake_table = self.db_api._execute_sql_against_backend(sql)
        rows = snowflake_table.fetchall()
        column_names = [desc[0].lower() for desc in snowflake_table.description]
        return [dict(zip(column_names, row)) for row in rows]

    # Implemented as per other database backends - nothing special needed.
    def _drop_table_from_database(self, force_non_splink_table=False):
        self._check_drop_table_created_by_splink(force_non_splink_table)
        self.db_api.delete_table_from_database(self.physical_name)

    def to_parquet(self, filepath, overwrite=False):
        """
        Snowflake implementation for parquet writing
        """
        if not overwrite:
            self.check_file_exists(filepath)

        if not filepath.endswith(".parquet"):
            raise SyntaxError(
                f"The filepath you've entered to '{filepath}' is "
                "not a parquet file. Please ensure that the filepath "
                "ends with `.parquet` before retrying."
            )

        # create the directories recursively if they don't exist
        path = os.path.dirname(filepath)
        if path:
            os.makedirs(path, exist_ok=True)

        # Use fetch arrow all in first instance; can stream batches in future if that large
        sql = f"SELECT * FROM {self.physical_name};"
        arrow_table: pa.Table = self.db_api._execute_sql_against_backend(
            sql
        ).fetch_arrow_all()

        pq.write_table(table=arrow_table, where=filepath)

    def to_csv(self, filepath, overwrite=False):
        """
        Snowflake implementation for CSV output.

        Note: this doesn't unload / COPY to a remote location,
        but materialises the CSV where the splink-snowflake client is.
        """
        if not overwrite:
            self.check_file_exists(filepath)

        if not filepath.endswith(".csv"):
            raise SyntaxError(
                f"The filepath you've entered to '{filepath}' is "
                "not a csv file. Please ensure that the filepath "
                "ends with `.csv` before retrying."
            )

        path = os.path.dirname(filepath)
        if path:
            os.makedirs(path, exist_ok=True)

        # Use fetch arrow all in first instance; can stream batches in future if that large
        sql = f"SELECT * FROM {self.physical_name};"
        df: pd.DataFrame = self.db_api._execute_sql_against_backend(
            sql
        ).fetch_pandas_all()

        df.to_csv(filepath)
