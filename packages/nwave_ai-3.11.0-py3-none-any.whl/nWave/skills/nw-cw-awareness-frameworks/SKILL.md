---
name: nw-cw-awareness-frameworks
description: Schwartz 5 levels of awareness with headline strategies, AIDA, PAS, and StoryBrand SB7 frameworks with when-to-use decision table
user-invocable: false
disable-model-invocation: true
---

# Awareness & Structural Frameworks

## Schwartz's 5 Levels of Awareness

Classify the audience before writing. The awareness level determines headline strategy, copy length, and proof density.

| Level | Audience State | Headline Strategy | Copy Length | Proof Need |
|-------|---------------|-------------------|-------------|------------|
| **Most Aware** (~3%) | Knows your product, ready to buy | Direct CTA with pricing. "Get nWave v3.5 now -- $0 for OSS." | Short | Low |
| **Product Aware** (~7%) | Knows your product, not convinced | Value proposition, offers, quality-to-price. Show why yours is best. | Medium | Medium |
| **Solution Aware** (~10%) | Knows solutions exist, not yours | Comparative advantage. Testimonials, case studies, differentiation. | Medium-Long | High |
| **Problem Aware** (~20%) | Feels the pain, no solution in mind | Empathetic acknowledgment. "Tired of ad-hoc AI coding?" Introduce mystery around solutions. | Long | High |
| **Unaware** (~60%) | Does not recognize the problem | Problem-focused, emotional imagery. No product mentions. Indirect, story-driven approach. | Very Long | Very High |

**Classification questions**: Has this person heard of our product? Do they know solutions like ours exist? Do they recognize they have this problem? Are they actively feeling the pain?

**Rule**: Never pitch a product to an unaware audience. Educate first, pitch later.

## Framework Selection Decision Table

| Copy Type | Primary Framework | When to Use |
|-----------|------------------|-------------|
| Product announcement | AIDA | Audience is product-aware or most-aware |
| Pain-point focused (cold email, ad) | PAS | Audience is problem-aware, copy under 300 words |
| Brand narrative (landing page, about) | StoryBrand SB7 | Audience needs the full story, medium-long copy |
| Long-form sales (letter, campaign) | AIDA + Sugarman slide | High-consideration purchase, audience is solution-aware |
| Release notes (existing users) | AIDA (light) | Most-aware audience, focus on what's new |
| Community post (Discord, forum) | PAS or AIDA | Depends on awareness -- PAS if surfacing a problem, AIDA if announcing |

## AIDA (Attention, Interest, Desire, Action)

**Origin**: Elias St. Elmo Lewis, 1898. The oldest and most validated structural framework.

### Structure

**Attention**: Bold headline addressing the reader's core need. Use power words, numbers, or provocative questions. Answer: "What is this?"
- Spend disproportionate effort here -- 80% of persuasion power is in the headline (Ogilvy)
- Test 5-10 headline variants before selecting

**Interest**: Engage with facts, data, logical arguments. Answer: "Why should I care?"
- Connect the headline promise to the reader's specific situation
- Use the Schwartz awareness level to calibrate depth

**Desire**: Shift from logic to emotion. Answer: "What if I had this?"
- Paint the transformed future state
- Use benefits (not features), social proof, aspirational language
- Apply Sugarman's emotional selling: lead with feeling, follow with logic

**Action**: One clear, specific CTA. Answer: "What do I do next?"
- Create urgency (genuine only)
- Remove friction -- every extra step loses readers
- Single CTA per piece. Multiple CTAs cause paralysis.

## PAS (Problem, Agitate, Solution)

**Best for**: Short-form copy under 300 words. Cold emails, social ads, landing page headers.

### Structure

**Problem**: State the reader's specific, relatable pain. Be concrete.
- Bad: "Managing AI workflows is hard."
- Good: "Your AI agents go rogue after 3 turns. You waste $8 on hallucinated code."

**Agitate**: Amplify the emotional weight. Show consequences of inaction.
- Make the reader feel the cost of not solving this
- Use "what if it gets worse" scenarios
- The agitate section should be longer than the problem statement

**Solution**: Present your offering as the natural answer.
- The reader should experience an "of course" moment
- Connect directly to the specific pain raised in step 1
- Never agitate a problem you cannot solve

## StoryBrand SB7 Framework (Donald Miller)

**Best for**: Brand messaging, website copy, campaign narratives. Medium-to-long copy.

### The 7 Elements

1. **Character** (Customer as Hero): What does the customer want? They are the hero. You are not.
2. **Problem**: Define three layers:
   - External: the tangible obstacle ("deployment takes 6 hours")
   - Internal: the emotional frustration ("I feel incompetent")
   - Philosophical: why this should not exist ("developers deserve better tools")
3. **Guide** (Your Brand): Show empathy ("We understand the frustration") + authority ("We've helped 500+ teams")
4. **Plan**: Provide a simple 3-step plan. Complexity kills conversion.
   - Step 1: [Simple first action]
   - Step 2: [What happens next]
   - Step 3: [Outcome achieved]
5. **Call to Action**: Direct CTA ("Start free") + Transitional CTA ("Download the guide") for unready prospects
6. **Success**: Paint the transformed future. "You go from ___ to ___."
7. **Failure**: State the stakes of inaction. Lost money, wasted time, continued frustration.

**Rule**: Never position the brand as the hero. The customer is always the hero. The brand is the guide.

## Combining Frameworks

Frameworks are combinable. Common stacks:
- **AIDA + Cialdini overlay**: Structure with AIDA, apply Cialdini principles in each section
- **PAS opener + AIDA body**: Start with PAS for hook, expand into full AIDA
- **StoryBrand + Halbert editing**: Structure with SB7, then run the 4-pass editing formula
- **Schwartz targeting + any framework**: Always classify awareness first, then select framework
