---
name: nw-cw-halbert-editing
description: Halbert/Sugarman editing formula - greased slide, bucket brigades, open loops, seeds of curiosity, multi-pass editing, read-aloud test
user-invocable: false
disable-model-invocation: true
---

# Halbert/Sugarman Editing Formula

The core editing methodology. Every piece of copy runs through these 4 passes after the first draft.

## The Greased Slide (Sugarman)

Every element of copy -- headline, subhead, first sentence, body -- exists for one purpose: get the reader to read the next sentence. Copy flows from headline to close without pause.

**First Sentence Rule**: Make it so short and compelling that reading the second sentence is automatic.
- Good: "It failed." | "We almost quit." | "Three developers. One week. Zero bugs."
- Bad: "In this article, we will explore the various ways in which our new release improves..."

**Test**: Cover any sentence. Does the reader lose momentum? If removing it changes nothing, delete it. If the reader could stop here, rewrite it.

## Bucket Brigades (Halbert)

Short transitional phrases on separate lines that maintain momentum between paragraphs. They act as micro-hooks that bridge ideas.

**Catalog** (use colons, not periods -- colons signal incompleteness):

| Category | Phrases |
|----------|---------|
| Tension | "But here's the problem:" | "Here's the catch:" | "There's just one thing:" |
| Revelation | "Then it hit me:" | "That's when everything changed:" | "Here's what we found:" |
| Invitation | "Picture this:" | "Imagine:" | "Think about it:" |
| Challenge | "What if...?" | "Still not convinced?" | "Sound familiar?" |
| Momentum | "And it gets better:" | "But wait:" | "That's not all:" |
| Proof | "Don't take my word for it:" | "The numbers speak for themselves:" |

**Placement rules**: Between every major idea shift. After a claim, before proof. After a benefit, before the next benefit. After 3-4 paragraphs of continuous text.

## Open Loops

Pose a question or introduce a concept without immediately resolving it. The reader's brain creates tension that can only be resolved by continuing.

**Techniques**:
- Foreshadowing: "We'll get to the surprising part in a moment."
- Partial reveal: "One change cut our deployment time by 80%. (More on the specific change below.)"
- Numbered promise: "There are three reasons this works. The third one surprised us."

**Resolution rule**: Every open loop opened in the copy must be closed. Unresolved loops create frustration, not curiosity. Track opened loops and verify each is resolved.

## Seeds of Curiosity (Sugarman)

End paragraphs with lines that provoke curiosity about what follows. Distinct from bucket brigades -- seeds are woven into the content itself, not standalone transitions.

**Examples**:
- "But that's not the most interesting part."
- "And the results? Not what anyone expected."
- "The real breakthrough came from an unlikely source."

## The 4-Pass Editing Formula

### Pass 1: Flow (Halbert)

Inject bucket brigades and open loops. Add transitions between ideas. Check: does each paragraph end with forward momentum? Test the greased slide -- read start to finish without stopping. Flag any point where you could stop reading.

### Pass 2: Clarity (Handley + 4Cs)

Short sentences (target: 15-20 words average). One idea per sentence. No jargon the audience doesn't already use. Remove weasel words: "very", "really", "quite", "somewhat", "relatively", "fairly". Remove filler: "in order to" -> "to" | "due to the fact that" -> "because" | "it is important to note that" -> delete | "at the end of the day" -> delete. Check paragraph length: 4 sentences maximum. Add white space.

### Pass 3: Persuasion (Cialdini overlay)

Audit against 6 principles (reciprocity, scarcity, authority, consistency, liking, social proof). Minimum 2-3 present per piece. Replace vague claims with specific numbers: "many customers" -> "2,847 teams" | "significant improvement" -> "40% faster" | "recently" -> "last Tuesday". Add proof elements where claims lack support.

### Pass 4: Read Aloud

Read the final draft aloud (simulate by checking rhythm). Flag sentences that: contain more than one comma-separated clause | use passive voice where active is clearer | sound unnatural when spoken | have identical sentence length for 3+ consecutive sentences (vary rhythm). Fix rhythm by alternating sentence lengths: short. Medium sentence follows. Then a longer sentence that builds and resolves.

## Editing Annotations

After completing all 4 passes, annotate the final copy with framework markers showing which technique was applied where. Format:

```
[BUCKET BRIGADE] "But here's what changed:"
[OPEN LOOP] Foreshadow of pricing reveal
[CIALDINI: Social Proof] User count statistic
[SEED] Curiosity hook at paragraph end
[OGILVY: Specificity] Replaced vague claim with metric
```

Annotations go in a separate section after the final copy, not inline.
