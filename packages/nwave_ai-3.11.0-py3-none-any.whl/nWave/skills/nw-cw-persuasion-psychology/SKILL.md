---
name: nw-cw-persuasion-psychology
description: Cialdini's 6 principles applied to copy, Ogilvy headline rules, power words, emotional vs rational triggers
user-invocable: false
disable-model-invocation: true
---

# Persuasion Psychology for Copy

## Cialdini's 6 Principles -- Copy Techniques

Apply as an overlay after drafting. Audit draft against all 6 principles. Score how many are present. Add missing ones where natural. Target: minimum 2-3 per piece.

| Principle | Copy Technique | Example |
|-----------|---------------|---------|
| **Reciprocity** | Offer free value before asking | "Here's the free migration guide. When you're ready, nWave handles the rest." |
| **Scarcity** | Genuine limits only -- limited seats, real deadlines, actual capacity constraints | "Early access closes Friday -- 200 of 500 spots remain." |
| **Authority** | Expert endorsements, data citations, credentials, "as featured in" | "Based on research from Anthropic's prompt engineering team." |
| **Consistency** | Reference reader's prior commitments or stated values | "You told us TDD matters. nWave enforces it at every step." |
| **Liking** | Conversational tone, shared identity, compliments, storytelling | "We're developers too. We built this because we hated the same thing." |
| **Social Proof** | User counts, testimonials, case studies, ratings | "Join 2,847 teams shipping with confidence." |

**Selection by copy type**:
- Announcements: Authority + Social Proof + Scarcity (if genuine)
- Landing pages: Social Proof + Authority + Liking
- Emails: Reciprocity + Consistency + Liking
- Community posts: Liking + Social Proof

**Ethical constraint**: Every claim must be verifiable. Never fabricate social proof, inflate numbers, or create artificial scarcity.

## Ogilvy's Headline Rules

Headlines carry 80% of the copy's persuasive weight. Invest disproportionate effort here.

**The 5 rules**:
1. **Promise a benefit**: The headline should tell the reader what they get
2. **Deliver news**: New, updated, introducing, finally, now
3. **Include specifics**: Numbers outperform vague claims -- "5 ways" not "several ways"
4. **Appeal to self-interest**: What's in it for the reader, not what you're proud of
5. **Test length**: Long headlines (10+ words) that communicate a complete thought often outperform short clever ones

**Headline formulas**:
- How to [achieve desired outcome] without [feared obstacle]
- [Number] ways to [benefit] in [timeframe]
- The [adjective] guide to [topic] for [audience]
- Why [common approach] fails (and what to do instead)
- [Audience]: Here's how [peer group] [achieved result]

**Test 5-10 variants before selecting**. The first headline is rarely the best.

## Sugarman's Psychological Triggers

Apply as a checklist against draft copy. Each trigger is a tool -- use 3-5 per piece, not all at once.

| Trigger | Application |
|---------|-------------|
| **Curiosity** | Open loops, incomplete reveals, "here's why" structures |
| **Storytelling** | Narrative arc: problem -> struggle -> breakthrough -> result |
| **Specificity** | Exact numbers, dates, names instead of vague claims |
| **Familiarity** | Reference what the audience already knows and trusts |
| **Authority** | Expert backing, research citations, credential signals |
| **Involvement** | Make reader imagine using the product -- "imagine", "picture yourself" |
| **Ownership** | Language that assumes the reader already has it -- "your dashboard", "when you open" |
| **Greed** | Value stacking, bonus content, "you also get" |
| **Exclusivity** | Beta access, insider knowledge, limited availability |
| **Guilt** | Gentle reminder of consequences of inaction |
| **Hope** | Future-state painting, transformation language |
| **Proof of value** | Satisfaction guarantees, risk reversal, free trials |

## Emotional vs Rational Selling

Every purchase is emotional first, then justified with logic (Sugarman). Structure accordingly:

**Emotional triggers** (use to open and close):
- Fear of missing out | Relief from pain | Pride in achievement | Belonging to a group | Security and safety | Excitement about possibility

**Rational proof** (use in the middle):
- Data and statistics | Case studies with metrics | Expert citations | Comparison tables | ROI calculations | Technical specifications

**Copy structure**: Open with emotion -> Prove with data -> Close with emotion.

## Power Words

Words that trigger emotional response. Use to replace weak alternatives.

| Weak | Power Alternative |
|------|------------------|
| good | exceptional, proven, battle-tested |
| new | breakthrough, pioneering, first-of-its-kind |
| free | complimentary, no-cost, on the house |
| fast | instant, lightning-fast, in seconds |
| easy | effortless, one-click, seamless |
| important | essential, non-negotiable, make-or-break |
| big | massive, game-changing, transformative |
| bad | broken, failing, hemorrhaging |
| help | empower, unlock, accelerate |
| try | experience, discover, explore |

**Constraint**: Power words amplify. Overuse them and they become noise. Maximum 2-3 per paragraph. Let the substance do the heavy lifting.

## Weasel Words -- Remove on Sight

These words weaken claims and signal uncertainty. Delete or replace with specifics.

`very` | `really` | `quite` | `somewhat` | `relatively` | `fairly` | `rather` | `slightly` | `arguably` | `basically` | `actually` | `literally` (figurative use) | `honestly` | `in my opinion` | `I think` | `sort of` | `kind of` | `maybe` | `perhaps`

**Fix**: Replace with a specific claim or delete entirely. "Very fast" -> "40ms response time." "Quite popular" -> "Used by 12,000 developers."
