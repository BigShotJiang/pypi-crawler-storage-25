﻿import logging
import threading
import time
import hashlib
import re
from typing import Any, Dict, Optional, Tuple
from acl.config import DEFAULT_MAX_RETRIES
from acl.config import ACLConfiguration
from acl.http import HttpClient
from acl.providers import ProviderRegistry
from acl.exceptions import ACLValidationError, ACLBaseError
from acl.session.manager import SessionManager
from acl.middlewares.retry import RetryMiddleware
from acl.middlewares.recovery import RecoveryMiddleware
from acl.middlewares.loop_detection import LoopDetectionMiddleware
from acl.middlewares.normalization import NormalizationMiddleware
from acl.security import redact_secrets


class ACLClient:
    _BUDGET_INSTRUCTION_TEMPLATE = (
        "You have exactly {budget} tokens to complete your response. "
        "Plan accordingly - write a complete, concise answer. "
        "Do not cut mid-sentence or mid-section. "
        "Ensure the final ending is fully complete and not cut off."
    )
    """
    Phase 3 & 7 â€” Execution Middleware & Modular SDK.
    The client is now an orchestration layer that assembles a pipeline.
    """

    def __init__(
        self, 
        api_key: Optional[str] = None, 
        base_url: Optional[str] = None, 
        timeout_ms: Optional[int] = None,
        **kwargs
    ):
        """
        Initializes the ACLClient.
        Now supports direct keyword arguments for a true plug-and-play experience.
        """
        # 1. Resolve API Key (Options dict for backward compat, or direct arg)
        self.api_key = api_key or kwargs.get("api_key")
        
        if not self.api_key:
            raise ACLValidationError("API key is required. Pass api_key='...' or set ACL_API_KEY environment variable.")

        if not (
            self.api_key.startswith("sk-acl-")
            or self.api_key.startswith("acl_live-")
            or self.api_key.startswith("acl_live_")
        ):
            raise ACLValidationError(
                "Invalid ACL API key format. Expected prefix `sk-acl-`, `acl_live-`, or `acl_live_`."
            )

        # 2. Configuration & HTTP
        self._config = ACLConfiguration(
            api_key=self.api_key,
            base_url=base_url or kwargs.get("base_url"),
            timeout_ms=timeout_ms or kwargs.get("timeout_ms"),
        )
        try:
            configured_retries = int(kwargs.get("max_retries", 1) or 1)
        except (TypeError, ValueError):
            configured_retries = 1
        self._default_max_retries = max(1, configured_retries)
        self._provider_timeout_s = max(1, int((self._config.timeout_ms + 999) / 1000))
        try:
            configured_http_retries = int(
                kwargs.get("http_max_retries", DEFAULT_MAX_RETRIES)
            )
        except (TypeError, ValueError):
            configured_http_retries = DEFAULT_MAX_RETRIES
        self._http_max_retries = max(0, configured_http_retries)
        self._http_client = HttpClient(
            api_key=self._config.api_key,
            base_url=self._config.base_url,
            timeout=self._config.timeout_ms // 1000,
            max_retries=self._http_max_retries,
        )

        # 3. Session Manager (Phase 5)
        self._session_manager = SessionManager(
            policy=kwargs.get("session_policy", "FIFO"),
            limit=kwargs.get("session_limit", 200),
        )

        # Phase 3 â€” Middleware Pipeline Assembly
        # Chain: Retry -> Recovery -> LoopDetection -> Normalization -> Provider
        self._middlewares = [
            RetryMiddleware(),
            RecoveryMiddleware(self._session_manager, self._request_loop_verdict),
            LoopDetectionMiddleware(self._session_manager),
            NormalizationMiddleware(),
        ]

        self._lock = threading.Lock()
        self._sdk_version = "1.9.6"
        self._environment = kwargs.get("environment", "production")
        self._secure_logging = kwargs.get("secure_logging", True)
        self._emit_post_completion_telemetry = kwargs.get(
            "emit_post_completion_telemetry", True
        )
        try:
            self._precheck_cache_ttl_s = max(
                0.0, float(kwargs.get("precheck_cache_ttl_s", 20.0) or 0.0)
            )
        except (TypeError, ValueError):
            self._precheck_cache_ttl_s = 20.0
        try:
            self._precheck_cache_max_entries = max(
                1, int(kwargs.get("precheck_cache_max_entries", 256) or 256)
            )
        except (TypeError, ValueError):
            self._precheck_cache_max_entries = 256
        self._precheck_cache: Dict[str, Tuple[float, Dict[str, Any]]] = {}
        self._precheck_cache_lock = threading.Lock()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def adaptive_window(self, params: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """
        Calculates budget from the ACL Core.
        Supports both direct keyword arguments and a 'params' dictionary.
        """
        params = params or {}
        # Merge direct keyword arguments into params
        full_params = {**params, **kwargs}
        
        # Default integration mode for complete calls
        full_params.setdefault("integration_mode", "complete_mode")
        
        url = "/api/v1/adaptive/window"
        return self._http_client.post(url, json=full_params)

    def complete(self, params: Optional[Dict[str, Any]] = None, **kwargs) -> Dict[str, Any]:
        """
        Orchestrates an LLM completion request using the Universal Adaptation strategy.
        Now supports direct keyword argument usage for a plug-and-play developer experience.
        """
        params = params or {}
        # Merge direct keyword arguments into params for standard processing
        full_params = {**params, **kwargs}
        full_params.setdefault("max_retries", self._default_max_retries)
        # SDK-managed budget only: ignore caller-provided token caps.
        user_supplied_cap = ("max_tokens" in full_params) or ("max_completion_tokens" in full_params)
        full_params.pop("max_tokens", None)
        full_params.pop("max_completion_tokens", None)
        if user_supplied_cap:
            logging.getLogger(__name__).info(
                "Caller-provided max token cap ignored; ACL budget controls output tokens."
            )
        
        prompt = full_params.get("prompt")
        session_id = full_params.get("session_id", "default")

        validation_error = self._validate_complete_inputs(full_params)
        if validation_error:
            return self._error_response(
                error_code=validation_error["error_code"],
                error_message=validation_error["error_message"],
                provider=full_params.get("provider"),
                model=full_params.get("model"),
            )

        # 1. Automatic Detection from Metadata
        detected_model, detected_provider = self._detect_client_model(full_params)

        # 2. Pipeline Execution Context (Reactive mode)
        execution_context = {
            **full_params,
            "session_id": session_id,
            "model": full_params.get("model") or detected_model,
            "provider": full_params.get("provider") or detected_provider,
            "_context_health": {},
        }

        precheck_ms = 0.0
        provider_ms = 0.0
        post_telemetry_ms = 0.0
        wall_clock_start = time.perf_counter()

        # 3. Get Universal Budget & Identity from ACL Core
        try:
            # We send whatever model info we detected/received to the server
            precheck_start = time.perf_counter()
            acl_resp = self._get_precheck_response(
                prompt=prompt,
                session_id=session_id,
                model=execution_context.get("model"),
                activity=full_params.get("activity"),
                metadata=full_params.get("metadata", {}),
            )
            precheck_ms = (time.perf_counter() - precheck_start) * 1000.0

            # Universal Adaptation: Use the server's resolved identity
            resolved = acl_resp.get("resolved_model", {})
            execution_context["model"] = (
                resolved.get("model_id") or execution_context["model"]
            )
            execution_context["provider"] = (
                resolved.get("provider") or execution_context["provider"]
            )

            # Phase 2 â€” Budget Validation
            budget = acl_resp.get("window", {}).get("final_token_budget", 1000)
            is_fast_path = (
                acl_resp.get("is_fast_path", False)
                or acl_resp.get("window", {}).get("is_fast_path", False)
                or acl_resp.get("metadata", {}).get("is_fast_path", False)
                or full_params.get("is_fast_path", False)
            )

            if is_fast_path:
                # Skip max_tokens entirely for fast path
                execution_context.pop("_acl_budget_tokens", None)
            else:
                # Finalize optimization strategy
                self._sync_context_security(execution_context, budget)
                self._inject_budget_instruction(execution_context, budget)

            execution_context["_context_health"] = acl_resp.get("context_health", {})

        except Exception as e:
            # Safe Fallback
            warning_message = "ACL Backend connection failed, falling back to local mode"
            if not self._secure_logging:
                warning_message = (
                    f"{warning_message}: {redact_secrets(str(e))}"
                )
            logging.getLogger(__name__).warning(warning_message)
            self._sync_context_security(execution_context, 1000)
            self._inject_budget_instruction(execution_context, 1000)
            if not execution_context.get("model"):
                execution_context["model"] = "gpt-4o"
            if not execution_context.get("provider"):
                execution_context["provider"] = "openai"

        # 4. Smart Key Selection
        # If 'keys' dict is provided, pick the key based on the provider
        api_key_val = full_params.get("llm_api_key")
        if not api_key_val and "keys" in full_params:
            provider_key = execution_context["provider"].lower()
            api_key_val = full_params["keys"].get(provider_key) or full_params["keys"].get("default")

        if not api_key_val:
            return self._error_response(
                error_code="ACL_ERR_VALIDATION",
                error_message=(
                    "No LLM API key found for resolved provider. "
                    "Pass llm_api_key or keys={'provider': '...'}."
                ),
                provider=execution_context.get("provider"),
                model=execution_context.get("model"),
            )

        key_validation_error = self._validate_provider_key(
            execution_context.get("provider"), api_key_val
        )
        if key_validation_error:
            return self._error_response(
                error_code="ACL_ERR_VALIDATION",
                error_message=key_validation_error,
                provider=execution_context.get("provider"),
                model=execution_context.get("model"),
            )

        # 5. Create Execution Chain
        try:
            provider_instance = ProviderRegistry.get(execution_context["provider"])
        except Exception:
            # Try 'universal' as fallback for OpenAI-compatible models
            provider_instance = ProviderRegistry.get("universal")

        # Standard execution function
        def _execute_provider(ctx: Dict[str, Any]) -> Dict[str, Any]:
            max_tokens = ctx.get("_acl_budget_tokens")
            allowlisted_params = self._provider_params_for_context(
                ctx, execution_context["provider"]
            )
            if max_tokens is not None:
                allowlisted_params["thinking_budget"] = int(max_tokens * 0.65)

            return provider_instance.call(
                prompt=ctx["prompt"],
                model=ctx["model"],
                api_key=api_key_val,
                max_tokens=max_tokens,
                temperature=ctx.get("temperature", 0.7),
                stream=ctx.get("stream", False),
                timeout=self._provider_timeout_s,
                # Strict provider allowlist to prevent ACL internals leaking upstream
                **allowlisted_params,
            )

        # 6. Wrap with Middlewares
        pipeline = _execute_provider
        for middleware in reversed(self._middlewares):

            def _wrap(m=middleware, n=pipeline):
                return lambda ctx: m(ctx, n)

            pipeline = _wrap()

        try:
            provider_start = time.perf_counter()
            result = pipeline(execution_context)
            provider_ms = (time.perf_counter() - provider_start) * 1000.0

            post_telemetry_start = time.perf_counter()
            telemetry_result = self._sync_completion_telemetry(
                execution_context=execution_context,
                response=result,
            )
            retry_budget = self._extract_retry_budget(telemetry_result)
            if self._should_retry_for_truncation(telemetry_result, retry_budget):
                retry_context = dict(execution_context)
                retry_context["_acl_budget_tokens"] = retry_budget
                retry_context["_acl_retry_attempt"] = True
                self._inject_budget_instruction(retry_context, retry_budget)
                retry_provider_start = time.perf_counter()
                retry_result = pipeline(retry_context)
                provider_ms += (time.perf_counter() - retry_provider_start) * 1000.0
                retry_result["retries"] = int(result.get("retries", 0) or 0) + 1
                retry_result["attempts_made"] = max(
                    int(retry_result.get("attempts_made", 1) or 1),
                    int(result.get("attempts_made", 1) or 1) + 1,
                )
                retry_result.setdefault("metadata", {})
                retry_result["metadata"]["acl_retry"] = {
                    "retry_recommended": True,
                    "retry_budget": retry_budget,
                }
                result = retry_result
                self._sync_completion_telemetry(
                    execution_context=retry_context,
                    response=result,
                )
            post_telemetry_ms = (time.perf_counter() - post_telemetry_start) * 1000.0
            wall_clock_ms = (time.perf_counter() - wall_clock_start) * 1000.0
            self._attach_timing_metadata(
                result=result,
                precheck_ms=precheck_ms,
                provider_ms=provider_ms,
                post_telemetry_ms=post_telemetry_ms,
                wall_clock_ms=wall_clock_ms,
            )
            return result
        except ACLBaseError as e:
            return self._error_response(
                error_code=e.error_code or "ACL_ERR_INTERNAL",
                error_message=redact_secrets(e.message),
                provider=execution_context.get("provider"),
                model=execution_context.get("model"),
            )
        except Exception as e:
            return self._error_response(
                error_code="ACL_ERR_INTERNAL",
                error_message=redact_secrets(str(e)),
                provider=execution_context.get("provider"),
                model=execution_context.get("model"),
            )

    def _attach_timing_metadata(
        self,
        result: Dict[str, Any],
        precheck_ms: float,
        provider_ms: float,
        post_telemetry_ms: float,
        wall_clock_ms: float,
    ) -> None:
        if not isinstance(result, dict):
            return
        metadata = result.get("metadata")
        if not isinstance(metadata, dict):
            metadata = {}
            result["metadata"] = metadata
        metadata["acl_timing"] = {
            "precheck_ms": round(precheck_ms, 2),
            "provider_ms": round(provider_ms, 2),
            "post_telemetry_ms": round(post_telemetry_ms, 2),
            "wall_clock_ms": round(wall_clock_ms, 2),
        }

    def _build_precheck_cache_key(
        self,
        prompt: str,
        session_id: str,
        model: Optional[str],
        activity: Optional[str],
        metadata: Optional[Dict[str, Any]],
    ) -> str:
        activity_hint = (
            activity
            or ((metadata or {}).get("activity_id") if isinstance(metadata, dict) else None)
            or ((metadata or {}).get("activity") if isinstance(metadata, dict) else None)
            or "auto"
        )
        prompt_hash = hashlib.sha1(prompt.encode("utf-8", errors="ignore")).hexdigest()[:16]
        model_name = model or "unknown-model"
        return f"{session_id}|{model_name}|{activity_hint}|{prompt_hash}"

    def _get_precheck_response(
        self,
        prompt: str,
        session_id: str,
        model: Optional[str],
        activity: Optional[str],
        metadata: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        payload = {
            "text": prompt,
            "model": model,
            "session_id": session_id,
            "activity": activity,
            "metadata": metadata or {},
        }
        if self._precheck_cache_ttl_s <= 0:
            return self.adaptive_window(payload)

        cache_key = self._build_precheck_cache_key(
            prompt=prompt,
            session_id=session_id,
            model=model,
            activity=activity,
            metadata=metadata,
        )
        now = time.time()
        with self._precheck_cache_lock:
            cached_entry = self._precheck_cache.get(cache_key)
            if cached_entry and cached_entry[0] > now:
                cached_resp = dict(cached_entry[1])
                cached_meta = cached_resp.get("metadata")
                if not isinstance(cached_meta, dict):
                    cached_meta = {}
                    cached_resp["metadata"] = cached_meta
                cached_meta["sdk_precheck_cache_hit"] = True
                return cached_resp
            if cached_entry and cached_entry[0] <= now:
                self._precheck_cache.pop(cache_key, None)

        acl_resp = self.adaptive_window(payload)
        store_now = time.time()
        with self._precheck_cache_lock:
            while len(self._precheck_cache) >= self._precheck_cache_max_entries:
                oldest_key = next(iter(self._precheck_cache))
                self._precheck_cache.pop(oldest_key, None)
            self._precheck_cache[cache_key] = (store_now + self._precheck_cache_ttl_s, dict(acl_resp))
        return acl_resp

    def _dispatch_completion_telemetry(
        self, execution_context: Dict[str, Any], response: Dict[str, Any]
    ) -> None:
        if not self._emit_post_completion_telemetry:
            return

        thread = threading.Thread(
            target=self._sync_completion_telemetry,
            kwargs={
                "execution_context": dict(execution_context),
                "response": dict(response) if isinstance(response, dict) else response,
            },
            daemon=True,
        )
        thread.start()

    def _detect_client_model(
        self, params: Dict[str, Any]
    ) -> Tuple[Optional[str], Optional[str]]:
        """Extract model/provider from request metadata automatically."""
        # Check standard headers or metadata
        metadata = params.get("metadata", {})
        headers = params.get("headers", {})

        # 1. Try metadata first
        model = metadata.get("model") or metadata.get("model_name")
        provider = metadata.get("provider")

        # 2. Try common header patterns
        if not model:
            model = headers.get("X-Model") or headers.get("x-model")

        # 3. Try to infer from API key prefix if present
        llm_key = params.get("llm_api_key", "")
        if not provider and llm_key:
            if llm_key.startswith("sk-ant-"):
                provider = "anthropic"
            elif llm_key.startswith("AIza"):
                provider = "google"
            elif llm_key.startswith("sk-"):
                provider = "openai"

        return model, provider

    def _validate_complete_inputs(self, params: Dict[str, Any]) -> Optional[Dict[str, str]]:
        prompt = params.get("prompt")
        if not isinstance(prompt, str) or not prompt.strip():
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": "Invalid prompt. Pass a non-empty string in `prompt`.",
            }

        explicit_model = params.get("model")
        metadata_model = (params.get("metadata") or {}).get("model")
        metadata_model_name = (params.get("metadata") or {}).get("model_name")
        if explicit_model is not None and (not isinstance(explicit_model, str) or not explicit_model.strip()):
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": "Invalid model. `model` must be a non-empty string when provided.",
            }
        if not explicit_model and not metadata_model and not metadata_model_name:
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": "Model resolution failed. Pass `model` or `metadata.model`.",
            }

        max_retries = params.get("max_retries")
        if max_retries is not None and (not isinstance(max_retries, int) or max_retries < 1 or max_retries > 8):
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": "Invalid max_retries. Use an integer between 1 and 8.",
            }

        llm_key = params.get("llm_api_key")
        keys = params.get("keys")
        if not llm_key and not keys:
            return {
                "error_code": "ACL_ERR_VALIDATION",
                "error_message": (
                    "No provider key found. Pass `llm_api_key` or `keys={'openai': '...', ...}`."
                ),
            }

        return None

    def _validate_provider_key(self, provider: Optional[str], llm_key: str) -> Optional[str]:
        if not isinstance(llm_key, str) or not llm_key.strip():
            return "Invalid llm_api_key. Provide a non-empty API key string."

        provider_name = (provider or "openai").lower()
        if provider_name in ("openai", "universal") and not llm_key.startswith("sk-"):
            return "Invalid OpenAI key format. Expected a key starting with `sk-`."
        if provider_name == "anthropic" and not llm_key.startswith("sk-ant-"):
            return "Invalid Anthropic key format. Expected a key starting with `sk-ant-`."
        if provider_name == "google" and not llm_key.startswith("AIza"):
            return "Invalid Google key format. Expected a key starting with `AIza`."
        return None

    def _provider_params_for_context(
        self, ctx: Dict[str, Any], provider: Optional[str]
    ) -> Dict[str, Any]:
        allowlists = {
            "openai": {
                "base_url",
                "system",
                "messages",
                "top_p",
                "presence_penalty",
                "frequency_penalty",
                "stop",
                "n",
                "logit_bias",
                "user",
                "seed",
                "response_format",
                "tools",
                "tool_choice",
                "parallel_tool_calls",
            },
            "universal": {
                "base_url",
                "system",
                "messages",
                "top_p",
                "presence_penalty",
                "frequency_penalty",
                "stop",
                "n",
                "logit_bias",
                "user",
                "seed",
                "response_format",
                "tools",
                "tool_choice",
                "parallel_tool_calls",
            },
            "anthropic": {
                "system",
                "top_p",
                "top_k",
                "stop_sequences",
                "metadata",
                "tools",
                "tool_choice",
            },
            "google": {
                "topP",
                "topK",
                "candidateCount",
                "stopSequences",
                "responseMimeType",
                "responseSchema",
                "presencePenalty",
                "frequencyPenalty",
                "seed",
                "safetySettings",
            },
        }
        allowed = allowlists.get((provider or "openai").lower(), allowlists["openai"])
        return {k: v for k, v in ctx.items() if k in allowed and v is not None}

    def _strip_budget_instruction(self, text: str) -> str:
        if not text:
            return ""
        pattern = (
            r"\n*\s*You have exactly \d+ tokens to complete your response\.\s*"
            r"Plan accordingly\s*[—-]\s*write a complete, concise answer\.\s*"
            r"Do not cut mid-sentence or mid-section\.\s*"
            r"(Ensure the final ending is fully complete and not cut off\.\s*)?"
        )
        cleaned = re.sub(pattern, "\n", text, flags=re.IGNORECASE)
        return cleaned.strip()

    def _inject_budget_instruction(self, ctx: Dict[str, Any], budget: int) -> None:
        safe_budget = max(1, int(budget or 0))
        instruction = self._BUDGET_INSTRUCTION_TEMPLATE.format(budget=safe_budget)

        system_text = ctx.get("system")
        if isinstance(system_text, str) and system_text.strip():
            merged_system = self._strip_budget_instruction(system_text)
            ctx["system"] = f"{merged_system}\n\n{instruction}" if merged_system else instruction
        elif not system_text:
            ctx["system"] = instruction

        messages = ctx.get("messages")
        if isinstance(messages, list):
            patched_messages = list(messages)
            system_idx = next(
                (
                    idx
                    for idx, msg in enumerate(patched_messages)
                    if isinstance(msg, dict)
                    and str(msg.get("role") or "").lower() == "system"
                ),
                None,
            )
            if system_idx is not None:
                existing = str(patched_messages[system_idx].get("content") or "")
                merged = self._strip_budget_instruction(existing)
                patched_messages[system_idx]["content"] = (
                    f"{merged}\n\n{instruction}" if merged else instruction
                )
            else:
                patched_messages.insert(0, {"role": "system", "content": instruction})
            ctx["messages"] = patched_messages
        elif str(ctx.get("prompt") or "").strip():
            ctx["messages"] = [
                {"role": "system", "content": instruction},
                {"role": "user", "content": str(ctx.get("prompt") or "")},
            ]

    def _error_response(
        self,
        error_code: str,
        error_message: str,
        provider: Optional[str] = None,
        model: Optional[str] = None,
    ) -> Dict[str, Any]:
        return {
            "text": "",
            "response": "",
            "success": False,
            "provider": provider or "unknown",
            "model": model or "unknown",
            "finish_reason": "error",
            "tokens_input": 0,
            "tokens_output": 0,
            "total_tokens": 0,
            "latency_ms": 0,
            "retries": 0,
            "attempts_made": 0,
            "context_health": {},
            "loop_detected": False,
            "error_code": error_code,
            "error_message": redact_secrets(error_message),
            "budget_fallback_used": False,
            "raw_response": None,
        }

    def get_provider_metadata(self) -> Dict[str, Any]:
        """
        Phase 6 â€” Provider Metadata Sync.
        Optionally fetch dynamic capabilities from ACL Core.
        """
        url = "/api/v1/providers/metadata"
        try:
            return self._http_client.get(url)
        except Exception:
            # Fallback â€” local registry summary
            return {"providers": ProviderRegistry._registry.keys()}

    def close_session(self, session_id: str):
        self._session_manager.pop_session(session_id)

    def close(self):
        self.close_all_sessions()
        self._http_client.close()

    def close_all_sessions(self):
        for sid in self._session_manager.list_sessions():
            self.close_session(sid)

    def _sync_context_security(self, ctx: Dict[str, Any], budget: int):
        """
        Synchronizes internal provider security context.
        This ensures that the execution environment is isolated and valid.
        """
        if budget <= 0:
            budget = 500
            ctx["_security_audit_fallback"] = True
        
        # Apply the resolved budget to the underlying provider config
        ctx["_acl_budget_tokens"] = budget

    def _sync_completion_telemetry(
        self, execution_context: Dict[str, Any], response: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Best-effort telemetry sync after provider completion.
        Sends actual output usage + recovery flags back to ACL server.
        """
        if not self._emit_post_completion_telemetry:
            return {}
        if not isinstance(response, dict) or not response.get("success", True):
            return {}

        prompt = execution_context.get("prompt", "")
        if not isinstance(prompt, str) or not prompt.strip():
            return {}

        provider_metadata = self._build_provider_metadata(response)
        payload = {
            "text": prompt,
            "session_id": execution_context.get("session_id", "default"),
            "model_id": execution_context.get("model"),
            "model": execution_context.get("model"),
            "provider": execution_context.get("provider"),
            "integration_mode": "complete_mode",
            "metadata": {
                **(execution_context.get("metadata") or {}),
                "model_id": execution_context.get("model"),
                "provider": execution_context.get("provider"),
                "provider_metadata": provider_metadata,
                "output_tokens_generated": response.get("tokens_output", 0),
                "response_text": response.get("text", ""),
            },
            "provider_metadata": provider_metadata,
            "output_tokens_generated": response.get("tokens_output", 0),
            "attempts_made": response.get("attempts_made", 1),
            "loop_detected": bool(response.get("loop_detected", False)),
            "silent_failure_recovered": bool(
                response.get("attempts_made", 1) > 1 and response.get("success", False)
            ),
            "api_failure_recovered": bool(
                response.get("attempts_made", 1) > 1 and response.get("success", False)
            ),
            "tokens_at_risk": response.get("tokens_saved", 0),
        }

        adaptive_result: Dict[str, Any] = {}
        try:
            adaptive_result = self.adaptive_window(payload)
        except Exception as e:
            warning_message = "Post-completion telemetry sync failed"
            if not self._secure_logging:
                warning_message = f"{warning_message}: {redact_secrets(str(e))}"
            logging.getLogger(__name__).warning(warning_message)

        self._emit_recovery_events(execution_context, response)
        return adaptive_result

    def _emit_recovery_events(
        self, execution_context: Dict[str, Any], response: Dict[str, Any]
    ) -> None:
        """Emit best-effort event logs for loop/failure dashboards."""
        session_id = execution_context.get("session_id", "default")
        model_id = execution_context.get("model", "default-model")
        attempts = int(response.get("attempts_made", 1) or 1)
        output_tokens = int(response.get("tokens_output", 0) or 0)

        if response.get("loop_detected"):
            self._post_event(
                {
                    "event_type": "loop_detected",
                    "session_id": session_id,
                    "model_id": model_id,
                    "session_tokens_used": int(response.get("total_tokens", 0) or 0),
                    "tokens_at_risk": int(response.get("tokens_saved", 0) or 0),
                }
            )

        if attempts > 1 and response.get("success", False):
            self._post_event(
                {
                    "event_type": "api_failure_recovered",
                    "session_id": session_id,
                    "model_id": model_id,
                    "attempt_number": attempts,
                    "http_status": 503,
                }
            )
            self._post_event(
                {
                    "event_type": "silent_failure_recovered",
                    "session_id": session_id,
                    "model_id": model_id,
                    "attempt_number": attempts,
                    "response_token_count": output_tokens,
                }
            )

    def _build_provider_metadata(self, response: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize provider token usage keys expected by ACL backend."""
        prompt_tokens = int(response.get("tokens_input", 0) or 0)
        completion_tokens = int(response.get("tokens_output", 0) or 0)
        total_tokens = int(response.get("total_tokens", 0) or 0)
        raw_response = response.get("raw_response") or {}
        usage = raw_response.get("usage", {}) if isinstance(raw_response, dict) else {}
        completion_details = usage.get("completion_tokens_details", {}) if isinstance(usage, dict) else {}
        output_details = usage.get("output_tokens_details", {}) if isinstance(usage, dict) else {}
        reasoning_tokens = self._coerce_int(
            response.get("reasoning_tokens")
            or response.get("native_tokens_reasoning")
            or usage.get("reasoning_tokens")
            or usage.get("native_tokens_reasoning")
            or completion_details.get("reasoning_tokens")
            or completion_details.get("native_tokens_reasoning")
            or output_details.get("reasoning_tokens")
            or output_details.get("native_tokens_reasoning")
        )
        finish_reason = (
            response.get("finish_reason")
            or self._extract_finish_reason(raw_response)
            or "unknown"
        )

        return {
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "output_tokens": completion_tokens,
            "intended_tokens": total_tokens or (prompt_tokens + completion_tokens),
            "reasoning_tokens": reasoning_tokens,
            "native_tokens_reasoning": reasoning_tokens,
            "finish_reason": finish_reason,
            "provider": response.get("provider"),
        }

    def _extract_finish_reason(self, raw_response: Dict[str, Any]) -> str:
        if not isinstance(raw_response, dict):
            return "unknown"
        choices = raw_response.get("choices", [])
        if isinstance(choices, list) and choices:
            first_choice = choices[0] or {}
            reason = first_choice.get("finish_reason") or first_choice.get("stop_reason")
            if reason:
                return str(reason)
        return str(raw_response.get("finish_reason") or "unknown")

    def _coerce_int(self, value: Any) -> int:
        try:
            return max(0, int(value or 0))
        except (TypeError, ValueError):
            return 0

    def _extract_retry_budget(self, telemetry_result: Dict[str, Any]) -> int:
        if not isinstance(telemetry_result, dict):
            return 0
        return self._coerce_int(
            telemetry_result.get("retry_budget")
            or (telemetry_result.get("window") or {}).get("retry_budget")
        )

    def _should_retry_for_truncation(
        self, telemetry_result: Dict[str, Any], retry_budget: int
    ) -> bool:
        if not isinstance(telemetry_result, dict):
            return False
        retry_recommended = bool(
            telemetry_result.get("retry_recommended")
            or (telemetry_result.get("window") or {}).get("retry_recommended")
        )
        return retry_recommended and retry_budget > 0

    def _post_event(self, body: Dict[str, Any]) -> None:
        """Fire-and-forget /events/log call for resilience counters."""
        try:
            self._http_client.post("/api/v1/events/log", json=body)
        except Exception:
            # Best-effort only; must never impact caller flow.
            return

    def _request_loop_verdict(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Best-effort server policy verdict lookup for loop recovery decisions."""
        try:
            return self._http_client.post("/api/v1/adaptive/loop/verdict", json=payload)
        except Exception:
            return {"status": "fallback", "action": "allow", "reason": "policy_unreachable"}


