"""PropAlgos SDK quickstart — runs anywhere with `pip install propalgos[viz]`."""

import propalgos as pa

# --- fetch data ---
prices = pa.data.prices("SPY", start="2022-01-01")
print(f"Loaded {len(prices)} bars for SPY\n")

# --- generate signal ---
signal = pa.signals.sma_cross(prices, fast=20, slow=100)

# --- backtest ---
result = pa.backtest.run(prices, signal, initial_cash=100_000, fee_bps=5)
result.summary()

# --- metrics ---
print(f"\nSharpe:  {pa.factors.sharpe(result.returns):.2f}")
print(f"Max DD:  {pa.factors.max_drawdown(result.returns):.1%}")

# --- visualize (requires propalgos[viz]) ---
try:
    pa.viz.tearsheet(result)
except ImportError:
    print("\nInstall plotly for charts: pip install 'propalgos[viz]'")
