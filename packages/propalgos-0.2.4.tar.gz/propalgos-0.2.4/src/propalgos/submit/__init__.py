"""Strategy packaging and submission.

Phase 3: package_strategy, validate, submit to leaderboard.
"""


def __getattr__(name: str):
    raise NotImplementedError(
        f"pa.submit.{name} is not yet available — coming in v0.2."
    )
