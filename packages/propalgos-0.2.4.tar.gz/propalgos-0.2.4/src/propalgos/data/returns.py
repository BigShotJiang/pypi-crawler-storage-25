"""Return computation and CSV ingestion utilities.

Pure functions that transform price DataFrames into return series.
No side effects, no network calls.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from propalgos.exceptions import DataError

# Direct cudf.read_csv bypasses cudf.pandas shim dispatch overhead.
try:
    import cudf as _cudf  # type: ignore[import-untyped]

    _CUDF_READ_CSV = _cudf.read_csv
except ImportError:
    _CUDF_READ_CSV = None

from .schemas import OHLCV_COLUMNS


def returns(prices_df: pd.DataFrame, method: str = "simple") -> pd.DataFrame:
    """Compute period returns from a price DataFrame.

    Parameters
    ----------
    prices_df:
        DataFrame containing at least a ``close`` column (single symbol)
        or MultiIndex columns with a ``close`` field (multi symbol).
    method:
        ``"simple"`` for arithmetic returns ``(p1/p0 - 1)``,
        ``"log"`` for logarithmic returns ``ln(p1/p0)``.

    Returns
    -------
    DataFrame of returns with the same index (first row is NaN).
    """
    close = _extract_close(prices_df)
    method = method.strip().lower()

    if method == "simple":
        return close.pct_change()
    if method == "log":
        # Vectorized np.log() — cudf.pandas intercepts ufuncs on Series args
        # via __array_ufunc__. Do NOT wrap in .apply() (per-row CPU fallback).
        ratio = close / close.shift(1)
        return np.log(ratio)

    raise DataError(f"unknown return method {method!r} — expected 'simple' or 'log'")


def cumulative_returns(returns_df: pd.DataFrame) -> pd.DataFrame:
    """Compute cumulative returns from a returns series.

    Uses the compounding formula ``(1 + r).cumprod() - 1``.
    NaN values in the first row are filled with 0 before compounding.

    Parameters
    ----------
    returns_df:
        DataFrame of period returns (output of :func:`returns`).
    """
    filled = returns_df.fillna(0.0)
    return (1.0 + filled).cumprod() - 1.0


def from_csv(path: str | Path) -> pd.DataFrame:
    """Load prices from a local CSV file, normalizing to OHLCV schema.

    The CSV must have a parseable date/datetime index column and at least
    one recognizable OHLCV column (case-insensitive match).

    Parameters
    ----------
    path:
        Filesystem path to the CSV file.

    Returns
    -------
    DataFrame with canonical lowercase OHLCV columns and a DatetimeIndex.
    """
    csv_path = Path(path)
    if not csv_path.exists():
        raise DataError(f"file not found: {csv_path}")

    try:
        # cudf.read_csv supports parse_dates and index_col; fall back to pandas
        # if cudf is unavailable or if the read fails (edge-case formats).
        reader = _CUDF_READ_CSV if _CUDF_READ_CSV is not None else pd.read_csv
        df = reader(csv_path, parse_dates=True, index_col=0)
    except Exception as exc:
        if _CUDF_READ_CSV is not None:
            # Retry with pandas in case cudf's CSV parser can't handle the format
            try:
                df = pd.read_csv(csv_path, parse_dates=True, index_col=0)
            except Exception:
                raise DataError(f"failed to read CSV {csv_path}: {exc}") from exc
        else:
            raise DataError(f"failed to read CSV {csv_path}: {exc}") from exc

    # Normalize column names to lowercase.
    df.columns = pd.Index([c.strip().lower() for c in df.columns])

    present = [c for c in OHLCV_COLUMNS if c in df.columns]
    if not present:
        raise DataError(
            f"no OHLCV columns found in {csv_path} — "
            f"got {list(df.columns)}, expected some of {OHLCV_COLUMNS}"
        )

    result = df[present].copy()

    # Ensure a DatetimeIndex.
    if not isinstance(result.index, pd.DatetimeIndex):
        try:
            result.index = pd.to_datetime(result.index)
        except Exception as exc:
            raise DataError(
                f"could not parse index as dates in {csv_path}: {exc}"
            ) from exc

    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _extract_close(df: pd.DataFrame) -> pd.DataFrame:
    """Pull the 'close' column(s) from a single- or multi-symbol DataFrame."""
    if isinstance(df.columns, pd.MultiIndex):
        # Multi-symbol: select the 'close' field across all symbols.
        try:
            close = df.xs("close", axis=1, level="field")
        except KeyError:
            # Fallback: try level index instead of name.
            try:
                close = df.xs("close", axis=1, level=1)
            except KeyError as exc:
                raise DataError(
                    "multi-symbol DataFrame has no 'close' field in MultiIndex"
                ) from exc
        return close

    if "close" not in df.columns:
        raise DataError(
            f"DataFrame has no 'close' column — got {list(df.columns)}"
        )
    return df[["close"]]
