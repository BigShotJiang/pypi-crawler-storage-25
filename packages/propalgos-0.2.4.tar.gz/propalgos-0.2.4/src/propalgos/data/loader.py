"""Bulk dataset loader — load an entire timeframe parquet (all symbols).

The key missing API for multi-symbol analysis. Returns a tall, stacked
DataFrame with ``symbol``, ``timestamp``, OHLCV, and optionally ``trades``
columns — the shape needed for vectorized cross-universe computations like
``pa.signals.rsi_stacked()``.

Quick start on platform::

    import propalgos as pa

    df = pa.data.load("crypto-kraken", interval="1h")
    # → DataFrame [symbol, timestamp, open, high, low, close, volume, trades]
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path

import pandas as pd

from propalgos.data.staging import is_stale, resolve_stage_dir, stage_file
from propalgos.exceptions import DataError

logger = logging.getLogger(__name__)

# When cudf.pandas is active (installed by propalgos.__init__), pd.read_parquet
# dispatches to cuDF transparently. This flag is for logging/diagnostics only.
try:
    import cudf  # type: ignore[import-untyped]  # noqa: F401
    _GPU_AVAILABLE = True
except ImportError:
    _GPU_AVAILABLE = False

# Interval string -> consolidated parquet minutes suffix
_INTERVAL_TO_MINUTES: dict[str, int] = {
    "1m": 1,
    "5m": 5,
    "15m": 15,
    "30m": 30,
    "60m": 60,
    "1h": 60,
    "4h": 240,
    "12h": 720,
    "1d": 1440,
    "1D": 1440,
    "1wk": 10080,
}

# Module-level cache: (dataset_id, minutes) → DataFrame
_cache: dict[tuple[str, int], pd.DataFrame] = {}

# Datasets whose files have already been bulk-staged to local disk
_staged: set[str] = set()


def _parse_dataset_id(dataset_id: str) -> tuple[str, str]:
    """Parse ``"category-source"`` into ``(category, source)``.

    Raises ``DataError`` if the format is invalid.
    """
    if "-" not in dataset_id:
        raise DataError(
            f"invalid dataset_id {dataset_id!r} — expected 'category-source' "
            f"format (e.g. 'crypto-kraken')"
        )
    category, source = dataset_id.split("-", 1)
    if not category or not source:
        raise DataError(
            f"invalid dataset_id {dataset_id!r} — both category and source "
            f"must be non-empty"
        )
    return category, source


def _resolve_datasets_base() -> Path:
    """Resolve the root datasets directory (same logic as registry.py)."""
    explicit = os.environ.get("PROPALGOS_DATASETS_DIR")
    if explicit:
        p = Path(explicit)
        if p.exists():
            return p

    platform = Path("/home/propalgos/datasets")
    if platform.exists():
        return platform

    local = Path("data")
    if local.exists():
        return local

    raise DataError(
        "no datasets directory found. "
        "Set PROPALGOS_DATASETS_DIR or ensure /home/propalgos/datasets exists."
    )


def _resolve_source_path(category: str, source: str, filename: str) -> Path:
    """Resolve the source path for a consolidated parquet file.

    Today this checks the FUSE mount filesystem. When HTTP/S3-direct sources
    are added, only this function changes — staging/reading/caching stay same.
    """
    base = _resolve_datasets_base()
    return base / category / source / "consolidated" / filename


def preload(
    dataset_id: str,
    intervals: list[str] | None = None,
    *,
    max_workers: int = 8,
) -> dict[str, float]:
    """Stage multiple timeframes to local disk in parallel.

    Saturates GCS/S3 bandwidth by running concurrent FUSE→NVMe copies
    instead of the sequential copy that :func:`load` does per call.

    Parameters
    ----------
    dataset_id:
        Dataset identifier, e.g. ``"crypto-kraken"``.
    intervals:
        List of intervals to stage, e.g. ``["1m", "1h", "1d"]``.
        ``None`` stages all available timeframes found on disk.
    max_workers:
        Thread pool size.  Defaults to 8 (one per timeframe).

    Returns
    -------
    dict[str, float]
        Mapping of interval → staged file size in MB.

    Example
    -------
    ::

        import propalgos as pa

        pa.data.preload("crypto-kraken")          # all timeframes, parallel
        df = pa.data.load("crypto-kraken", "1h")  # instant — already staged
    """
    category, source = _parse_dataset_id(dataset_id)

    if intervals is None:
        # Discover available timeframes from the FUSE mount
        base = _resolve_datasets_base()
        consolidated = base / category / source / "consolidated"
        if not consolidated.exists():
            raise DataError(
                f"dataset directory not found: {consolidated}. "
                f"Check that dataset_id={dataset_id!r} is correct."
            )
        intervals = []
        minutes_to_interval = {v: k for k, v in _INTERVAL_TO_MINUTES.items()}
        for p in sorted(consolidated.glob(f"{source}_*.parquet")):
            suffix = p.stem.split("_", 1)[1]
            if suffix.isdigit():
                minutes = int(suffix)
                label = minutes_to_interval.get(minutes, f"{minutes}m")
                intervals.append(label)

    if not intervals:
        raise DataError(f"no timeframes found for {dataset_id!r}")

    # Build (source_path, dest_path, interval) tuples
    stage_dir = resolve_stage_dir() / category / source
    stage_dir.mkdir(parents=True, exist_ok=True)

    tasks: list[tuple[Path, Path, str, int]] = []
    for iv in intervals:
        minutes = _INTERVAL_TO_MINUTES.get(iv)
        if minutes is None:
            continue
        filename = f"{source}_{minutes}.parquet"
        src = _resolve_source_path(category, source, filename)
        if not src.exists():
            continue
        dst = stage_dir / filename
        tasks.append((src, dst, iv, minutes))

    results: dict[str, float] = {}
    skipped = 0

    def _stage_one(src: Path, dst: Path, iv: str, minutes: int) -> tuple[str, float]:
        if dst.exists() and not is_stale(src, dst):
            return iv, dst.stat().st_size / (1024 * 1024)
        stage_file(src, dst)
        return iv, dst.stat().st_size / (1024 * 1024)

    from concurrent.futures import ThreadPoolExecutor, as_completed

    t0 = time.monotonic()
    with ThreadPoolExecutor(max_workers=min(max_workers, len(tasks))) as pool:
        futures = {
            pool.submit(_stage_one, src, dst, iv, minutes): iv
            for src, dst, iv, minutes in tasks
        }
        for fut in as_completed(futures):
            iv = futures[fut]
            try:
                label, size_mb = fut.result()
                results[label] = round(size_mb, 1)
            except Exception as exc:
                logger.error("Failed to stage %s/%s: %s", dataset_id, iv, exc)

    elapsed = time.monotonic() - t0
    total_mb = sum(results.values())
    logger.info(
        "Preloaded %s: %d files, %.0f MB in %.1fs (%.0f MB/s)",
        dataset_id,
        len(results),
        total_mb,
        elapsed,
        total_mb / elapsed if elapsed > 0 else 0,
    )
    return results


def load(dataset_id: str, interval: str = "1d") -> pd.DataFrame:
    """Load a full stacked DataFrame for a dataset and timeframe.

    Returns a tall DataFrame with all symbols, sorted by ``(symbol, timestamp)``.
    The parquet is staged to local disk on first access (fast NVMe reads),
    and cached in memory for the process lifetime.

    Parameters
    ----------
    dataset_id:
        Dataset identifier in ``"category-source"`` format, e.g.
        ``"crypto-kraken"``.
    interval:
        Bar interval — ``"1d"``, ``"1h"``, ``"5m"``, etc.

    Returns
    -------
    pd.DataFrame
        Stacked DataFrame with columns like ``symbol``, ``timestamp``,
        ``open``, ``high``, ``low``, ``close``, ``volume``.
    """
    category, source = _parse_dataset_id(dataset_id)

    minutes = _INTERVAL_TO_MINUTES.get(interval)
    if minutes is None:
        available = sorted(_INTERVAL_TO_MINUTES.keys())
        raise DataError(
            f"interval {interval!r} not recognized. Available: {available}"
        )

    cache_key = (dataset_id, minutes)
    if cache_key in _cache:
        return _cache[cache_key]

    filename = f"{source}_{minutes}.parquet"
    source_path = _resolve_source_path(category, source, filename)

    if not source_path.exists():
        # List available files for a helpful error
        consolidated_dir = source_path.parent
        if consolidated_dir.exists():
            available_files = sorted(p.name for p in consolidated_dir.glob("*.parquet"))
            raise DataError(
                f"parquet file not found: {source_path}. "
                f"Available files: {available_files}"
            )
        raise DataError(
            f"dataset directory not found: {consolidated_dir}. "
            f"Check that dataset_id={dataset_id!r} is correct and data exists."
        )

    stage_dir = resolve_stage_dir() / category / source
    local = stage_dir / filename

    if local.exists() and not is_stale(source_path, local):
        # Already on NVMe (e.g. pre-staged by notebook kernel) — skip preload
        _staged.add(dataset_id)
    elif dataset_id not in _staged:
        # Not staged — bulk-stage all siblings in parallel
        preload(dataset_id)
        _staged.add(dataset_id)
        # Fallback: preload somehow missed this file
        if not local.exists() or is_stale(source_path, local):
            local.parent.mkdir(parents=True, exist_ok=True)
            stage_file(source_path, local)

    logger.debug("Loading %s (staged, gpu=%s)", local, _GPU_AVAILABLE)
    # Use pd.read_parquet — when cudf.pandas is active, this dispatches to GPU
    # transparently and returns a shimmed proxy object that supports the full
    # pandas API (including .tolist(), .to_string(index=), etc.). Direct
    # cudf.read_parquet() would bypass the shim and return native cuDF objects
    # that break downstream pandas API calls.
    df = pd.read_parquet(local)
    _cache[cache_key] = df
    return df
