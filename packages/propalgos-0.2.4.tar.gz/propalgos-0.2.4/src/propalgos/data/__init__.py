"""Market data access for PropAlgos.

Quick start::

    import propalgos as pa

    df = pa.data.prices("AAPL", start="2023-01-01")
    ret = pa.data.returns(df)
    cum = pa.data.cumulative_returns(ret)

The default backend is yfinance. Swap it out with::

    pa.data.configure(MyCustomProvider())
"""

from __future__ import annotations

from .crypto import CryptoCompositeProvider, CryptoParquetProvider
from .loader import load, preload
from .prices import DataProvider, clear_data_cache as clear_cache, configure, prices
from .registry import list_datasets, list_symbols
from .returns import cumulative_returns, from_csv, returns

__all__ = [
    "CryptoCompositeProvider",
    "CryptoParquetProvider",
    "DataProvider",
    "clear_cache",
    "configure",
    "cumulative_returns",
    "from_csv",
    "list_datasets",
    "list_symbols",
    "load",
    "preload",
    "prices",
    "returns",
]
