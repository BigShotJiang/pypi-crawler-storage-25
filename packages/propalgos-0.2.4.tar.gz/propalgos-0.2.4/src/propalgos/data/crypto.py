"""Crypto OHLCV provider backed by pre-consolidated Parquet files.

Reads the consolidated Parquet files produced by the Kraken/Binance data
pipelines (``kraken_data_util.py``, ``binance_data_util.py``). On the
PropAlgos platform these live on a shared FUSE mount; for local dev they
fall back to a user-specified directory.

Quick start on platform::

    import propalgos as pa
    from propalgos.data.crypto import CryptoParquetProvider

    pa.data.configure(CryptoParquetProvider("kraken"))
    prices = pa.data.prices("BTCUSD", interval="1h", start="2024-01-01")

The consolidated parquet layout is one file per timeframe::

    consolidated/
        kraken_1.parquet     # 1-minute bars
        kraken_5.parquet     # 5-minute bars
        kraken_15.parquet
        kraken_30.parquet    # 30-minute bars
        kraken_60.parquet
        kraken_240.parquet
        kraken_720.parquet   # 12-hour bars
        kraken_1440.parquet  # daily bars
"""

from __future__ import annotations

import logging
import os
import time
from pathlib import Path

import pandas as pd

from propalgos.data.staging import is_stale as _is_stale
from propalgos.data.staging import resolve_stage_dir, stage_file
from propalgos.exceptions import DataError

logger = logging.getLogger(__name__)

# Detect cuDF for logging/diagnostics — actual reads go through pd.read_parquet
# which the cudf.pandas shim dispatches to GPU transparently while preserving
# full pandas API compatibility (tolist, to_string, etc.).
try:
    import cudf as _cudf  # type: ignore[import-untyped]  # noqa: F401
    _CUDF_AVAILABLE = True
except ImportError:
    _CUDF_AVAILABLE = False

# Interval string -> consolidated parquet minutes suffix
_INTERVAL_TO_MINUTES: dict[str, int] = {
    "1m": 1,
    "5m": 5,
    "15m": 15,
    "30m": 30,
    "60m": 60,
    "1h": 60,
    "4h": 240,
    "12h": 720,
    "1d": 1440,
    "1D": 1440,
    "1wk": 10080,
}

# Canonical OHLCV columns expected by the SDK
_OHLCV = ["open", "high", "low", "close", "volume"]


def _resolve_data_dir(exchange: str, data_dir: str | None) -> Path:
    """Resolve the directory containing consolidated parquet files.

    Priority:
    1. Explicit ``data_dir`` argument
    2. ``PROPALGOS_DATASETS_DIR`` env var (platform FUSE mount)
    3. Platform default ``/home/propalgos/datasets``
    4. Local dev fallback ``./data/{exchange}_consolidated``
    """
    if data_dir is not None:
        p = Path(data_dir)
        if p.exists():
            return p
        raise DataError(f"specified data_dir does not exist: {p}")

    platform_base = Path(
        os.environ.get("PROPALGOS_DATASETS_DIR", "/home/propalgos/datasets")
    )
    platform_path = platform_base / f"crypto/{exchange}/consolidated"
    if platform_path.exists():
        return platform_path

    local_path = Path(f"data/{exchange}_consolidated")
    if local_path.exists():
        return local_path

    raise DataError(
        f"no consolidated parquet directory found for exchange={exchange!r}. "
        f"Checked: {platform_path}, {local_path}. "
        f"Set data_dir= or PROPALGOS_DATASETS_DIR= to override."
    )


class CryptoParquetProvider:
    """Read pre-consolidated crypto OHLCV from Parquet files.

    Implements the ``DataProvider`` protocol from ``propalgos.data.prices``.

    Parameters
    ----------
    exchange:
        Exchange name — determines subdirectory and filename prefix.
        Default ``"kraken"``.
    data_dir:
        Explicit path to the consolidated parquet directory. If ``None``,
        auto-detects platform mount or local dev fallback.
    """

    def __init__(self, exchange: str = "kraken", data_dir: str | None = None) -> None:
        self._exchange = exchange.lower()
        self._data_dir = _resolve_data_dir(self._exchange, data_dir)
        self._stage_dir = resolve_stage_dir() / self._exchange
        self._cache: dict[int, pd.DataFrame] = {}
        logger.info(
            "CryptoParquetProvider initialized: exchange=%s dir=%s stage=%s",
            self._exchange,
            self._data_dir,
            self._stage_dir,
        )

    @property
    def name(self) -> str:
        return f"crypto-parquet-{self._exchange}"

    def fetch_prices(
        self,
        symbols: str | list[str],
        start: str | None,
        end: str | None,
        interval: str,
    ) -> pd.DataFrame:
        """Fetch OHLCV data from consolidated parquets.

        Reads the appropriate timeframe file, filters by symbol(s) and date
        range, and returns a DataFrame with canonical OHLCV columns.

        Single symbol  -> DatetimeIndex, flat OHLCV columns
        Multi symbol   -> DatetimeIndex, MultiIndex (symbol, field) columns
        """
        minutes = _INTERVAL_TO_MINUTES.get(interval)
        if minutes is None:
            available = sorted(_INTERVAL_TO_MINUTES.keys())
            raise DataError(
                f"interval {interval!r} not available in consolidated parquets. "
                f"Available: {available}"
            )

        tickers = [symbols] if isinstance(symbols, str) else list(symbols)
        tickers_upper = [s.strip().upper() for s in tickers]

        df = self._load_timeframe(minutes)

        # Filter by symbol(s)
        symbol_col = _detect_symbol_column(df)
        mask = df[symbol_col].str.upper().isin(tickers_upper)
        filtered = df.loc[mask].copy()

        if filtered.empty:
            available_symbols = sorted(df[symbol_col].unique()[:20])
            raise DataError(
                f"no data for {tickers} in {self._exchange} {interval} parquet. "
                f"Sample available symbols: {available_symbols}"
            )

        # Filter by date range
        ts_col = _detect_timestamp_column(filtered)
        filtered[ts_col] = pd.to_datetime(filtered[ts_col], utc=True)
        if start is not None:
            filtered = filtered[filtered[ts_col] >= pd.Timestamp(start, tz="UTC")]
        if end is not None:
            filtered = filtered[filtered[ts_col] < pd.Timestamp(end, tz="UTC")]

        if filtered.empty:
            raise DataError(
                f"no data for {tickers} in range [{start}, {end}) at {interval}"
            )

        multi = len(tickers_upper) > 1
        if multi:
            return self._build_multi(filtered, tickers_upper, symbol_col, ts_col)
        return self._build_single(filtered, ts_col)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _load_timeframe(self, minutes: int) -> pd.DataFrame:
        """Load (and cache) a consolidated parquet file for a given timeframe.

        On first access, copies the parquet from the FUSE mount to local disk
        (stage-to-local). Subsequent reads hit the local copy, avoiding slow
        random-seek patterns over FUSE.
        """
        if minutes in self._cache:
            return self._cache[minutes]

        filename = f"{self._exchange}_{minutes}.parquet"
        source = self._data_dir / filename
        if not source.exists():
            available = sorted(p.name for p in self._data_dir.glob("*.parquet"))
            raise DataError(
                f"parquet file not found: {source}. Available: {available}"
            )

        local = self._stage_dir / filename
        if not local.exists() or _is_stale(source, local):
            local.parent.mkdir(parents=True, exist_ok=True)
            t0 = time.monotonic()
            stage_file(source, local)
            elapsed = time.monotonic() - t0
            size_mb = local.stat().st_size / (1024 * 1024)
            logger.info("Staged %s (%.1f MB) in %.1fs", filename, size_mb, elapsed)

        logger.debug("Loading %s (staged, gpu=%s)", local, _CUDF_AVAILABLE)
        df = pd.read_parquet(local)
        self._cache[minutes] = df
        return df

    @staticmethod
    def _build_single(df: pd.DataFrame, ts_col: str) -> pd.DataFrame:
        """Build a single-symbol OHLCV DataFrame with DatetimeIndex."""
        col_map = _build_column_map(df.columns)
        out = df.rename(columns=col_map)
        out = out.set_index(ts_col if ts_col not in col_map else col_map[ts_col])
        out.index.name = None

        present = [c for c in _OHLCV if c in out.columns]
        if not present:
            raise DataError(
                f"no OHLCV columns found after normalization — got {list(out.columns)}"
            )
        return out[present].sort_index()

    @staticmethod
    def _build_multi(
        df: pd.DataFrame,
        tickers: list[str],
        symbol_col: str,
        ts_col: str,
    ) -> pd.DataFrame:
        """Build a multi-symbol DataFrame with MultiIndex (symbol, field) columns.

        Vectorized via ``set_index`` + ``unstack`` instead of a per-ticker
        Python loop — keeps the entire operation in pandas/cuDF kernels.
        """
        col_map = _build_column_map(df.columns)
        df = df.rename(columns=col_map)
        mapped_ts = col_map.get(ts_col, ts_col)
        mapped_sym = col_map.get(symbol_col, symbol_col)

        present = [c for c in _OHLCV if c in df.columns]
        if not present:
            raise DataError(f"no OHLCV data found for tickers {tickers}")

        # Select only the columns we need, filter to requested tickers
        cols = [mapped_sym, mapped_ts] + present
        df_slim = df[cols]
        df_slim = df_slim[df_slim[mapped_sym].str.upper().isin(tickers)]
        if df_slim.empty:
            raise DataError(f"no OHLCV data found for tickers {tickers}")

        # Vectorized pivot: (timestamp, symbol) → unstacked MultiIndex columns
        df_slim = df_slim.set_index([mapped_ts, mapped_sym])
        combined = df_slim.unstack(level=mapped_sym)
        # Swap levels so outer level is symbol, inner is field
        combined = combined.swaplevel(axis=1).sort_index(axis=1)
        combined.columns.names = ["symbol", "field"]
        combined.index.name = None
        return combined.sort_index()

    def available_symbols(self, interval: str = "1d") -> list[str]:
        """List all symbols available in a given timeframe parquet."""
        minutes = _INTERVAL_TO_MINUTES.get(interval, 1440)
        df = self._load_timeframe(minutes)
        symbol_col = _detect_symbol_column(df)
        return sorted(df[symbol_col].unique().tolist())


class CryptoCompositeProvider:
    """Routes price requests across multiple exchange providers.

    Tries each exchange in order until one has data for the requested symbol.
    Falls through to the next exchange on ``DataError``.
    """

    def __init__(self, exchanges: list[str]) -> None:
        self._providers = [CryptoParquetProvider(ex) for ex in exchanges]
        self._exchange_names = [ex.lower() for ex in exchanges]
        logger.info("CryptoCompositeProvider: exchanges=%s", self._exchange_names)

    @property
    def name(self) -> str:
        return "crypto-composite"

    def fetch_prices(
        self,
        symbols: str | list[str],
        start: str | None,
        end: str | None,
        interval: str,
    ) -> pd.DataFrame:
        errors: list[str] = []
        for provider in self._providers:
            try:
                return provider.fetch_prices(symbols, start, end, interval)
            except DataError as exc:
                errors.append(f"{provider.name}: {exc}")
        raise DataError(
            f"symbol not found on any exchange. Tried: {'; '.join(errors)}"
        )

    def available_symbols(self, interval: str = "1d") -> list[str]:
        symbols: set[str] = set()
        for provider in self._providers:
            try:
                symbols.update(provider.available_symbols(interval))
            except DataError:
                pass
        return sorted(symbols)


# ----------------------------------------------------------------------
# Column detection utilities
# ----------------------------------------------------------------------


def _detect_symbol_column(df: pd.DataFrame) -> str:
    """Find the symbol/pair column in the parquet."""
    candidates = ["symbol", "pair", "ticker", "Symbol", "Pair"]
    for c in candidates:
        if c in df.columns:
            return c
    raise DataError(
        f"cannot detect symbol column — columns are {list(df.columns)}"
    )


def _detect_timestamp_column(df: pd.DataFrame) -> str:
    """Find the timestamp column in the parquet."""
    candidates = ["timestamp", "time", "date", "datetime", "Timestamp", "Date"]
    for c in candidates:
        if c in df.columns:
            return c
    raise DataError(
        f"cannot detect timestamp column — columns are {list(df.columns)}"
    )


def _build_column_map(columns: pd.Index) -> dict[str, str]:
    """Build a mapping from raw column names to lowercase canonical names."""
    out: dict[str, str] = {}
    for c in columns:
        lower = str(c).strip().lower()
        if lower in _OHLCV or lower in ("timestamp", "symbol", "pair", "trades"):
            out[c] = lower
    return out
