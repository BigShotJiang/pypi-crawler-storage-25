"""Canonical schemas for market data.

Defines the OHLCV column contract and request parameter validation.
All data flowing through the SDK normalizes to these names.
"""

from __future__ import annotations

from pydantic import BaseModel, field_validator

OHLCV_COLUMNS: list[str] = ["open", "high", "low", "close", "volume"]
"""Canonical lowercase column names for price data."""


class PriceRequest(BaseModel):
    """Validated parameters for a price data request."""

    symbols: list[str]
    start: str | None = None
    end: str | None = None
    interval: str = "1d"

    @field_validator("symbols", mode="before")
    @classmethod
    def coerce_symbols(cls, v: str | list[str]) -> list[str]:
        if isinstance(v, str):
            return [v.strip().upper()]
        return [s.strip().upper() for s in v]

    @field_validator("symbols")
    @classmethod
    def symbols_nonempty(cls, v: list[str]) -> list[str]:
        if not v:
            raise ValueError("symbols must contain at least one ticker")
        for s in v:
            if not s:
                raise ValueError("symbol cannot be an empty string")
        return v

    @field_validator("interval")
    @classmethod
    def validate_interval(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("interval must be a non-empty string")
        return v.strip()
