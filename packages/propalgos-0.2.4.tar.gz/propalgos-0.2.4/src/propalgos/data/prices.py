"""Price data retrieval with swappable backend providers.

The module exposes a `DataProvider` protocol so backends are interchangeable.
`YFinanceProvider` ships as the default v0.1 implementation. A module-level
`configure()` function lets callers swap the active provider at runtime.
"""

from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

import pandas as pd

from propalgos.exceptions import DataError

from .cache import clear_cache as _clear_cache
from .cache import get_cached, set_cached
from .schemas import OHLCV_COLUMNS, PriceRequest

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Provider protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class DataProvider(Protocol):
    """Contract for any market data backend."""

    @property
    def name(self) -> str:
        """Human-readable provider identifier (used in cache keys)."""
        ...

    def fetch_prices(
        self,
        symbols: str | list[str],
        start: str | None,
        end: str | None,
        interval: str,
    ) -> pd.DataFrame:
        """Fetch OHLCV data and return a DataFrame with canonical column names.

        Single symbol  -> columns = OHLCV_COLUMNS (flat Index)
        Multi symbol   -> columns = MultiIndex of (symbol, field)

        Must raise ``DataError`` on empty results or upstream failures.
        """
        ...


# ---------------------------------------------------------------------------
# yfinance default provider
# ---------------------------------------------------------------------------


class YFinanceProvider:
    """Default data provider backed by ``yfinance``."""

    @property
    def name(self) -> str:
        return "yfinance"

    def fetch_prices(
        self,
        symbols: str | list[str],
        start: str | None,
        end: str | None,
        interval: str,
    ) -> pd.DataFrame:
        yf = _import_yfinance()

        tickers = [symbols] if isinstance(symbols, str) else list(symbols)
        ticker_str = " ".join(tickers)
        multi = len(tickers) > 1

        try:
            raw: pd.DataFrame = yf.download(
                tickers=ticker_str,
                start=start,
                end=end,
                interval=interval,
                progress=False,
                auto_adjust=True,
                group_by="ticker" if multi else "column",
            )
        except Exception as exc:
            raise DataError(f"yfinance download failed: {exc}") from exc

        if raw.empty:
            raise DataError(
                f"no price data returned for {tickers} "
                f"(start={start}, end={end}, interval={interval})"
            )

        return _normalize(raw, tickers, multi)


def _import_yfinance():  # type: ignore[no-untyped-def]
    """Lazy-import yfinance with a clear error on failure."""
    try:
        import yfinance  # type: ignore[import-untyped]

        return yfinance
    except ImportError as exc:
        raise DataError(
            "yfinance is required but not installed. "
            "Install it with: pip install yfinance"
        ) from exc


def _normalize(
    raw: pd.DataFrame,
    tickers: list[str],
    multi: bool,
) -> pd.DataFrame:
    """Normalize yfinance output to the canonical OHLCV schema.

    yfinance returns different column structures depending on how many
    symbols were requested and the library version. This function handles
    both single-symbol (flat columns) and multi-symbol (MultiIndex) cases.
    """
    if multi:
        return _normalize_multi(raw, tickers)
    return _normalize_single(raw)


def _normalize_single(raw: pd.DataFrame) -> pd.DataFrame:
    """Flatten and lowercase a single-symbol DataFrame."""
    # yfinance may return MultiIndex columns like [('Price', 'Close', 'AAPL')]
    # or flat columns like ['Open', 'High', ...]. Handle both.
    if isinstance(raw.columns, pd.MultiIndex):
        # Collapse to the price-field level (second level usually).
        raw = raw.droplevel(level=[i for i in range(raw.columns.nlevels - 1)], axis=1)
        if isinstance(raw.columns, pd.MultiIndex):
            raw.columns = raw.columns.get_level_values(-1)

    col_map = {c: c.strip().lower() for c in raw.columns}
    df = raw.rename(columns=col_map)

    # Keep only canonical columns that exist.
    present = [c for c in OHLCV_COLUMNS if c in df.columns]
    if not present:
        raise DataError(
            f"no OHLCV columns found after normalization — got {list(df.columns)}"
        )
    return df[present]


def _normalize_multi(raw: pd.DataFrame, tickers: list[str]) -> pd.DataFrame:
    """Build a clean MultiIndex (symbol, field) DataFrame from yfinance output."""
    frames: dict[str, pd.DataFrame] = {}

    if isinstance(raw.columns, pd.MultiIndex):
        # yfinance multi-symbol: columns are (Ticker, Field) or (Price, Field, Ticker).
        # Try extracting per-ticker sub-frames.
        for ticker in tickers:
            try:
                sub = raw.xs(ticker, axis=1, level=0, drop_level=True)
            except KeyError:
                # Try the last level (some yfinance versions flip the order).
                try:
                    sub = raw.xs(ticker, axis=1, level=-1, drop_level=True)
                except KeyError:
                    continue

            # Flatten any remaining MultiIndex levels.
            if isinstance(sub.columns, pd.MultiIndex):
                sub.columns = sub.columns.get_level_values(-1)

            col_map = {c: c.strip().lower() for c in sub.columns}
            sub = sub.rename(columns=col_map)
            present = [c for c in OHLCV_COLUMNS if c in sub.columns]
            if present:
                frames[ticker] = sub[present]
    else:
        # Fallback: flat columns — probably single ticker came back despite multi request.
        col_map = {c: c.strip().lower() for c in raw.columns}
        df = raw.rename(columns=col_map)
        present = [c for c in OHLCV_COLUMNS if c in df.columns]
        if present and tickers:
            frames[tickers[0]] = df[present]

    if not frames:
        raise DataError(
            f"no OHLCV data found for tickers {tickers} after normalization"
        )

    combined = pd.concat(frames, axis=1)
    combined.columns.names = ["symbol", "field"]
    return combined


# ---------------------------------------------------------------------------
# Module-level provider management
# ---------------------------------------------------------------------------

_provider: DataProvider = YFinanceProvider()
_explicitly_configured: bool = False


def configure(provider: DataProvider) -> None:
    """Swap the global data provider at runtime."""
    global _provider, _explicitly_configured  # noqa: PLW0603
    if not isinstance(provider, DataProvider):
        raise TypeError(
            f"provider must satisfy the DataProvider protocol, got {type(provider).__name__}"
        )
    _provider = provider
    _explicitly_configured = True


def _maybe_auto_configure() -> None:
    """Auto-detect platform crypto data and configure provider if not explicitly set."""
    global _provider, _explicitly_configured  # noqa: PLW0603
    if _explicitly_configured:
        return
    if not isinstance(_provider, YFinanceProvider):
        return
    try:
        from propalgos.data.registry import list_datasets

        datasets = list_datasets()
        exchanges = [d.get("exchange") or d["source"] for d in datasets if d["category"] == "crypto"]
        if not exchanges:
            return

        if len(exchanges) == 1:
            from propalgos.data.crypto import CryptoParquetProvider
            _provider = CryptoParquetProvider(exchanges[0])
        else:
            from propalgos.data.crypto import CryptoCompositeProvider
            _provider = CryptoCompositeProvider(exchanges)

        _explicitly_configured = True
        logger.info("Auto-configured %s (exchanges=%s)", _provider.name, exchanges)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def prices(
    symbols: str | list[str],
    start: str | None = None,
    end: str | None = None,
    interval: str = "1d",
    cache: bool = True,
) -> pd.DataFrame:
    """Fetch OHLCV price data.

    Single symbol  -> DataFrame with columns ``["open","high","low","close","volume"]``
    Multiple symbols -> DataFrame with MultiIndex columns ``(symbol, field)``

    Parameters
    ----------
    symbols:
        Ticker string or list of tickers.
    start:
        Start date string (inclusive), e.g. ``"2022-01-01"``.
    end:
        End date string (exclusive). Defaults to today.
    interval:
        Bar interval — ``"1d"``, ``"1h"``, ``"5m"``, etc.
    cache:
        If ``True``, check local disk cache before fetching and persist results.
    """
    _maybe_auto_configure()
    req = PriceRequest(symbols=symbols, start=start, end=end, interval=interval)

    # --- cache lookup ---
    if cache:
        cached = get_cached(
            symbols=req.symbols,
            start=req.start,
            end=req.end,
            interval=req.interval,
            provider=_provider.name,
        )
        if cached is not None:
            return cached

    # --- fetch from provider ---
    df = _provider.fetch_prices(
        symbols=req.symbols if len(req.symbols) > 1 else req.symbols[0],
        start=req.start,
        end=req.end,
        interval=req.interval,
    )

    # --- persist to cache ---
    if cache:
        set_cached(
            df=df,
            symbols=req.symbols,
            start=req.start,
            end=req.end,
            interval=req.interval,
            provider=_provider.name,
        )

    return df


def clear_data_cache() -> int:
    """Remove all locally cached data files. Returns number of files removed."""
    return _clear_cache()
