"""Local disk cache for market data.

Stores fetched price DataFrames as parquet files keyed by a hash of the
request parameters. Cache reads/writes are pure function wrappers — no
global state beyond the filesystem.
"""

from __future__ import annotations

import hashlib
import json
import logging
import time
from functools import lru_cache
from pathlib import Path

import pandas as pd

from propalgos.config import get_config

logger = logging.getLogger(__name__)


# Default TTL: 1 day in seconds.
_DEFAULT_TTL_SECONDS: int = 86_400


def _cache_dir() -> Path:
    """Resolve the data cache directory, creating it if needed."""
    base = get_config().cache_dir / "data"
    base.mkdir(parents=True, exist_ok=True)
    return base


def _cache_key(
    symbols: list[str],
    start: str | None,
    end: str | None,
    interval: str,
    provider: str,
) -> str:
    """Deterministic hash of request parameters."""
    payload = json.dumps(
        {
            "symbols": sorted(symbols),
            "start": start,
            "end": end,
            "interval": interval,
            "provider": provider,
        },
        sort_keys=True,
    )
    return hashlib.sha256(payload.encode()).hexdigest()


def _meta_path(parquet_path: Path) -> Path:
    return parquet_path.with_suffix(".meta")


def _write_meta(meta_path: Path, ttl: int) -> None:
    meta_path.write_text(
        json.dumps({"created_at": time.time(), "ttl": ttl}),
        encoding="utf-8",
    )


@lru_cache(maxsize=128)
def _read_meta_cached(meta_path_str: str, mtime_ns: int) -> dict | None:
    """Parse JSON metadata, cached by path + mtime to avoid re-reads."""
    try:
        return json.loads(Path(meta_path_str).read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _is_expired(meta_path: Path) -> bool:
    """Check if the cached entry has exceeded its TTL."""
    if not meta_path.exists():
        return True
    try:
        mtime_ns = meta_path.stat().st_mtime_ns
        meta = _read_meta_cached(str(meta_path), mtime_ns)
        if meta is None:
            return True
        created_at: float = meta["created_at"]
        ttl: int = meta["ttl"]
        return (time.time() - created_at) > ttl
    except (KeyError, TypeError):
        return True


def get_cached(
    symbols: list[str],
    start: str | None,
    end: str | None,
    interval: str,
    provider: str,
    ttl: int = _DEFAULT_TTL_SECONDS,
) -> pd.DataFrame | None:
    """Return a cached DataFrame if present and not expired, else None."""
    key = _cache_key(symbols, start, end, interval, provider)
    path = _cache_dir() / f"{key}.parquet"
    meta = _meta_path(path)

    if not path.exists() or _is_expired(meta):
        return None

    try:
        df = pd.read_parquet(path)
        logger.debug("cache hit for %s (%s)", symbols, key[:12])
        return df
    except Exception:
        logger.debug("cache read failed for %s, treating as miss", key[:12])
        return None


def set_cached(
    df: pd.DataFrame,
    symbols: list[str],
    start: str | None,
    end: str | None,
    interval: str,
    provider: str,
    ttl: int = _DEFAULT_TTL_SECONDS,
) -> None:
    """Persist a DataFrame to the local disk cache."""
    key = _cache_key(symbols, start, end, interval, provider)
    path = _cache_dir() / f"{key}.parquet"
    meta = _meta_path(path)

    try:
        df.to_parquet(path, compression="zstd", write_statistics=True)
        _write_meta(meta, ttl)
        logger.debug("cached %d rows for %s (%s)", len(df), symbols, key[:12])
    except Exception:
        logger.debug("cache write failed for %s, skipping", key[:12])
        # Best-effort — don't blow up the caller over a cache write failure.
        _safe_unlink(path)
        _safe_unlink(meta)


def clear_cache() -> int:
    """Delete all cached data files. Returns count of files removed."""
    cache = _cache_dir()
    removed = 0
    for f in cache.iterdir():
        if f.suffix in (".parquet", ".meta"):
            f.unlink(missing_ok=True)
            removed += 1
    logger.info("cleared %d cache files from %s", removed, cache)
    return removed


def _safe_unlink(path: Path) -> None:
    """Remove a file without raising on missing."""
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass
