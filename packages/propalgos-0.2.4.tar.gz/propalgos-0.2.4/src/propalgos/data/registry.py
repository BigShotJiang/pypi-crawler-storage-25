"""Filesystem-based dataset discovery.

Reads metadata.json (written by refresh_crypto_data.py) for instant dataset
listing. Falls back to parquet scanning only when metadata is missing.

    import propalgos as pa
    pa.data.list_datasets()
    pa.data.list_symbols("kraken", interval="1h")
    pa.data.list_symbols("crypto-kraken", interval="1h")  # dataset_id format
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

import pandas as pd

from propalgos.exceptions import DataError

logger = logging.getLogger(__name__)

# Module-level caches (session lifetime)
_datasets_cache: list[dict[str, Any]] | None = None
_symbols_cache: dict[tuple[str, int], list[str]] = {}


def _resolve_datasets_base() -> Path:
    """Resolve the root datasets directory.

    Priority:
    1. ``PROPALGOS_DATASETS_DIR`` env var
    2. ``/home/propalgos/datasets`` (platform)
    3. ``./data/`` (local dev)
    """
    explicit = os.environ.get("PROPALGOS_DATASETS_DIR")
    if explicit:
        p = Path(explicit)
        if p.exists():
            return p

    platform = Path("/home/propalgos/datasets")
    if platform.exists():
        return platform

    local = Path("data")
    if local.exists():
        return local

    raise DataError(
        "no datasets directory found. "
        "Set PROPALGOS_DATASETS_DIR or ensure /home/propalgos/datasets exists."
    )


# Interval string -> minutes (mirrors crypto.py)
_INTERVAL_TO_MINUTES: dict[str, int] = {
    "1m": 1, "5m": 5, "15m": 15, "30m": 30,
    "60m": 60, "1h": 60, "4h": 240, "12h": 720,
    "1d": 1440, "1D": 1440, "1wk": 10080,
}

_MINUTES_TO_LABEL: dict[int, str] = {
    1: "1m", 5: "5m", 15: "15m", 30: "30m",
    60: "1h", 240: "4h", 720: "12h", 1440: "1d", 10080: "1wk",
}


def list_datasets() -> list[dict[str, Any]]:
    """Discover available datasets by scanning the filesystem.

    Scans all category subdirectories under the datasets root. Returns a list
    of dicts, each describing one dataset::

        [{"id": "crypto-kraken", "source": "kraken", "exchange": "kraken",
          "category": "crypto", "timeframes": ["1m","5m","1h","1d"],
          "symbol_count": 198}, ...]

    The ``"exchange"`` key is present when ``category == "crypto"`` for
    backward compatibility. All datasets include ``"source"``.

    Results are cached for the process lifetime.
    """
    global _datasets_cache  # noqa: PLW0603
    if _datasets_cache is not None:
        return _datasets_cache

    try:
        base = _resolve_datasets_base()
    except DataError:
        _datasets_cache = []
        return _datasets_cache

    datasets: list[dict[str, Any]] = []

    for category_dir in sorted(base.iterdir()):
        if not category_dir.is_dir():
            continue
        category = category_dir.name

        for source_dir in sorted(category_dir.iterdir()):
            if not source_dir.is_dir():
                continue
            consolidated = source_dir / "consolidated"
            if not consolidated.exists():
                continue

            source = source_dir.name
            metadata_path = consolidated / "metadata.json"

            # Fast path: read metadata.json (a few KB, written by refresh pipeline)
            if metadata_path.exists():
                try:
                    meta = json.loads(metadata_path.read_text())
                    entry: dict[str, Any] = {
                        "id": f"{category}-{source}",
                        "source": source,
                        "category": category,
                        "timeframes": meta.get("timeframes", []),
                        "symbol_count": meta.get("pair_count", 0),
                    }
                    if category == "crypto":
                        entry["exchange"] = source
                    if entry["timeframes"]:
                        datasets.append(entry)
                    continue
                except (json.JSONDecodeError, OSError) as exc:
                    logger.debug("Bad metadata.json in %s, falling back to scan: %s", consolidated, exc)

            # Slow fallback: scan parquet filenames for timeframes, read coarsest for symbol count
            parquets = sorted(consolidated.glob("*.parquet"))
            if not parquets:
                continue

            timeframes: list[str] = []
            coarsest_pq: Path | None = None
            coarsest_minutes = 0
            for pq in parquets:
                stem = pq.stem
                parts = stem.rsplit("_", 1)
                if len(parts) == 2:
                    try:
                        minutes = int(parts[1])
                        label = _MINUTES_TO_LABEL.get(minutes, f"{minutes}m")
                        timeframes.append(label)
                        if minutes > coarsest_minutes:
                            coarsest_minutes = minutes
                            coarsest_pq = pq
                    except ValueError:
                        pass

            symbol_count = 0
            if coarsest_pq is not None:
                try:
                    df = pd.read_parquet(coarsest_pq, columns=["symbol"])
                    symbol_count = df["symbol"].nunique()
                except Exception:
                    try:
                        df = pd.read_parquet(coarsest_pq, columns=["pair"])
                        symbol_count = df["pair"].nunique()
                    except Exception:
                        pass

            if timeframes:
                fallback_entry: dict[str, Any] = {
                    "id": f"{category}-{source}",
                    "source": source,
                    "category": category,
                    "timeframes": timeframes,
                    "symbol_count": symbol_count,
                }
                if category == "crypto":
                    fallback_entry["exchange"] = source
                datasets.append(fallback_entry)

    _datasets_cache = datasets
    return _datasets_cache


def list_symbols(source: str, interval: str = "1d", category: str = "crypto") -> list[str]:
    """List all symbols available for a source/exchange at a given interval.

    Accepts either a plain source name (``"kraken"``) or a dataset_id
    (``"crypto-kraken"``). When using dataset_id format, the category is
    parsed automatically.

    Reads the consolidated parquet for the given timeframe and returns
    unique symbol values. Benefits from the stage-to-local layer if
    a ``CryptoParquetProvider`` has already staged the file.
    """
    # Parse dataset_id format: "crypto-kraken" → ("crypto", "kraken")
    if "-" in source:
        category, source = source.split("-", 1)

    source = source.lower()
    minutes = _INTERVAL_TO_MINUTES.get(interval)
    if minutes is None:
        raise DataError(f"unknown interval {interval!r}")

    cache_key = (source, minutes)
    if cache_key in _symbols_cache:
        return _symbols_cache[cache_key]

    from propalgos.data.crypto import CryptoParquetProvider

    provider = CryptoParquetProvider(source)
    symbols = provider.available_symbols(interval)
    _symbols_cache[cache_key] = symbols
    return symbols
