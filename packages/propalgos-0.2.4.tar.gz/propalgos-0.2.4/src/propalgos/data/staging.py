"""Shared staging utilities for parquet data.

Copies remote/FUSE-mounted parquet files to local disk before reading.
This avoids slow random-seek patterns over FUSE and gives fast NVMe reads.

Used by both ``CryptoParquetProvider`` and ``load()`` — single source of
truth for staging directory resolution and staleness detection.
"""

from __future__ import annotations

import logging
import os
import shutil
from pathlib import Path

logger = logging.getLogger(__name__)

# 16 MB copy buffer — default shutil is 64 KB which is painfully slow for
# multi-GB parquet files.
_COPY_BUFSIZE = 16 * 1024 * 1024

# Detect kvikIO for GPU Direct Storage (GDS) zero-copy NVMe→GPU.
try:
    import kvikio  # type: ignore[import-untyped]

    _KVIKIO_AVAILABLE = True
except ImportError:
    _KVIKIO_AVAILABLE = False


def resolve_stage_dir() -> Path:
    """Resolve the local staging directory for parquet copies.

    Priority:
    1. ``PROPALGOS_DATA_STAGE_DIR`` env var
    2. ``/home/propalgos/scratch/.propalgos_staged/`` (platform ephemeral disk)
    3. ``~/.cache/propalgos/staged/`` (off-platform fallback)
    """
    explicit = os.environ.get("PROPALGOS_DATA_STAGE_DIR")
    if explicit:
        return Path(explicit)

    platform_scratch = Path("/home/propalgos/scratch/.propalgos_staged")
    if platform_scratch.parent.exists():
        return platform_scratch

    return Path.home() / ".cache" / "propalgos" / "staged"


def is_stale(source: Path, local: Path) -> bool:
    """Check if the local staged copy is stale relative to the source."""
    try:
        src_stat = source.stat()
        loc_stat = local.stat()
        return src_stat.st_size != loc_stat.st_size or src_stat.st_mtime != loc_stat.st_mtime
    except OSError:
        return True


def stage_file(source: Path, dest: Path) -> None:
    """Copy *source* to *dest* using the fastest available I/O path.

    Three-tier fallback:
    1. **kvikIO** — GPU Direct Storage when available (zero-copy NVMe→GPU DMA)
    2. **shutil with 16 MB buffer** — 250x larger than the 64 KB default
    3. **plain shutil.copy2** — baseline fallback

    Preserves mtime for staleness detection via :func:`is_stale`.
    """
    if _KVIKIO_AVAILABLE:
        try:
            _stage_kvikio(source, dest)
            return
        except Exception:
            logger.debug("kvikIO staging failed, falling back to buffered copy")

    _stage_buffered(source, dest)


def _stage_kvikio(source: Path, dest: Path) -> None:
    """Stage using kvikIO for GDS-capable NVMe drives."""
    nbytes = source.stat().st_size
    with kvikio.CuFile(str(source), "r") as src_f:
        with kvikio.CuFile(str(dest), "w") as dst_f:
            import cupy as cp  # type: ignore[import-untyped]

            buf = cp.empty(nbytes, dtype=cp.uint8)
            src_f.read(buf)
            dst_f.write(buf)
    # Preserve mtime for staleness detection
    src_stat = source.stat()
    os.utime(dest, (src_stat.st_atime, src_stat.st_mtime))


def _stage_buffered(source: Path, dest: Path) -> None:
    """Stage using shutil.copy2 with a large buffer."""
    # Temporarily override the copy buffer size for this operation
    old_bufsize = getattr(shutil, "COPY_BUFSIZE", 64 * 1024)
    try:
        shutil.COPY_BUFSIZE = _COPY_BUFSIZE
        shutil.copy2(source, dest)
    finally:
        shutil.COPY_BUFSIZE = old_bufsize
