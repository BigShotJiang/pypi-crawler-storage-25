"""Account info, balance, and usage.

Phase 3: me(), balance(), usage() via backend auth/balance API.
"""


def __getattr__(name: str):
    raise NotImplementedError(
        f"pa.account.{name} is not yet available — coming in v0.2."
    )
