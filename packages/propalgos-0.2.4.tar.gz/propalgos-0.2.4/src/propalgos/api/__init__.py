"""PropAlgos API client.

Phase 3: httpx-based client with auth injection, retry, structured errors.
"""


def __getattr__(name: str):
    raise NotImplementedError(
        f"pa.api.{name} is not yet available — coming in v0.2. "
        "On-platform notebooks already have backend connectivity."
    )
