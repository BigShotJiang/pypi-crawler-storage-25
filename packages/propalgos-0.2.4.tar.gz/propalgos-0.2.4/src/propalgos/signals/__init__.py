"""Trading signal generators.

Every signal function accepts a prices DataFrame (must contain a ``close``
column) and returns a ``pd.Series`` of int values in {-1, 0, 1}:

- **+1** -- long / bullish
- **-1** -- short / bearish
- **0**  -- flat / no signal (including warmup periods)

Quick start::

    import propalgos as pa

    prices = pa.data.prices("SPY", start="2020-01-01")
    signal = pa.signals.sma_cross(prices, fast=20, slow=100)
"""

from __future__ import annotations

from propalgos.signals.compose import combine
from propalgos.signals.mean_reversion import bollinger_bands, zscore_reversion
from propalgos.signals.momentum import macd, rsi, rsi_reversion
from propalgos.signals.scan import rsi_stacked, scan
from propalgos.signals.trend import ema_cross, sma_cross, trend_filter

__all__ = [
    "bollinger_bands",
    "combine",
    "ema_cross",
    "macd",
    "rsi",
    "rsi_reversion",
    "rsi_stacked",
    "scan",
    "sma_cross",
    "trend_filter",
    "zscore_reversion",
]
