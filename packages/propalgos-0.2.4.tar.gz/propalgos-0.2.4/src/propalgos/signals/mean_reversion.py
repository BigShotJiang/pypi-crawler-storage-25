"""Mean-reversion signal generators.

Each function accepts a prices DataFrame (must contain a 'close' column) and
returns a pd.Series of int values in {-1, 0, 1}. Warmup periods produce 0.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from propalgos.signals.trend import _validate_prices


def bollinger_bands(
    prices: pd.DataFrame,
    period: int = 20,
    num_std: float = 2.0,
) -> pd.Series:
    """Bollinger Band mean-reversion signal.

    +1 when the close drops below the lower band (expect reversion up),
    -1 when the close rises above the upper band (expect reversion down),
    0 when price is inside the bands or during warmup.

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain a ``close`` column.
    period : int
        Rolling window for the middle band (SMA) and standard deviation.
    num_std : float
        Number of standard deviations for band width.

    Returns
    -------
    pd.Series
        Integer series in {-1, 0, 1}.
    """
    close = _validate_prices(prices)

    sma = close.rolling(period).mean()
    std = close.rolling(period).std(ddof=1)

    upper = sma + num_std * std
    lower = sma - num_std * std

    signal = pd.Series(0, index=close.index, dtype=int)
    signal[close < lower] = 1
    signal[close > upper] = -1
    signal.iloc[:period] = 0
    return signal


def zscore_reversion(
    prices: pd.DataFrame,
    period: int = 20,
    entry_z: float = 2.0,
    exit_z: float = 0.5,
) -> pd.Series:
    """Z-score mean-reversion signal.

    Computes a rolling z-score of the close price, then:
    - +1 when z < -entry_z (price far below mean -- expect reversion up)
    - -1 when z > +entry_z (price far above mean -- expect reversion down)
    -  0 when |z| < exit_z (price near mean -- no edge)

    Values between exit_z and entry_z retain the previous signal direction via
    forward-fill, so positions aren't exited too early. During warmup, the
    signal is 0.

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain a ``close`` column.
    period : int
        Rolling window for mean and standard deviation.
    entry_z : float
        Z-score magnitude required to enter a position.
    exit_z : float
        Z-score magnitude below which the position is exited (signal -> 0).

    Returns
    -------
    pd.Series
        Integer series in {-1, 0, 1}.
    """
    close = _validate_prices(prices)

    rolling_mean = close.rolling(period).mean()
    rolling_std = close.rolling(period).std(ddof=1)

    # Avoid division by zero -- when std is 0 the z-score is undefined
    z = (close - rolling_mean) / rolling_std.replace(0.0, np.nan)

    # Build raw signal from entry/exit thresholds
    raw = pd.Series(np.nan, index=close.index, dtype=float)
    raw[z < -entry_z] = 1.0
    raw[z > entry_z] = -1.0
    raw[z.abs() < exit_z] = 0.0

    # Forward-fill the NaN gaps (hysteresis zone between exit_z and entry_z)
    filled = raw.ffill().fillna(0.0)

    signal = filled.astype(int)
    signal.iloc[:period] = 0
    return signal
