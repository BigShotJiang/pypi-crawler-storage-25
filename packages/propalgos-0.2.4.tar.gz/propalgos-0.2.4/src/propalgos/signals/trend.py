"""Trend-following signal generators.

Each function accepts a prices DataFrame (must contain a 'close' column) and
returns a pd.Series of int values in {-1, 0, 1} aligned to the input index.
Warmup periods where indicators are undefined produce 0.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


def _validate_prices(prices: pd.DataFrame) -> pd.Series:
    """Extract and validate the close series from a prices DataFrame.

    Raises:
        ValueError: If the DataFrame is empty.
        KeyError: If 'close' column is missing.
    """
    if prices.empty:
        raise ValueError(
            "prices DataFrame is empty -- provide at least one row of OHLCV data"
        )
    if "close" not in prices.columns:
        raise KeyError(
            f"prices DataFrame must contain a 'close' column. "
            f"Found columns: {list(prices.columns)}"
        )
    return prices["close"]


def sma_cross(
    prices: pd.DataFrame,
    fast: int = 20,
    slow: int = 100,
) -> pd.Series:
    """SMA crossover signal.

    +1 when the fast SMA is above the slow SMA, -1 when below, 0 during the
    warmup window (first *slow* bars where the slow SMA is undefined).

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain a ``close`` column.
    fast : int
        Lookback for the fast simple moving average.
    slow : int
        Lookback for the slow simple moving average.

    Returns
    -------
    pd.Series
        Integer series in {-1, 0, 1}.
    """
    close = _validate_prices(prices)
    fast_sma = close.rolling(fast).mean()
    slow_sma = close.rolling(slow).mean()

    signal = pd.Series(np.int8(0), index=close.index, dtype=int)
    signal[fast_sma > slow_sma] = 1
    signal[fast_sma < slow_sma] = -1
    # NaN during warmup -> 0
    signal.iloc[:slow] = 0
    return signal


def ema_cross(
    prices: pd.DataFrame,
    fast: int = 12,
    slow: int = 26,
) -> pd.Series:
    """EMA crossover signal.

    +1 when the fast EMA is above the slow EMA, -1 when below, 0 during the
    warmup window (first *slow* bars).

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain a ``close`` column.
    fast : int
        Span for the fast exponential moving average.
    slow : int
        Span for the slow exponential moving average.

    Returns
    -------
    pd.Series
        Integer series in {-1, 0, 1}.
    """
    close = _validate_prices(prices)
    fast_ema = close.ewm(span=fast, adjust=False).mean()
    slow_ema = close.ewm(span=slow, adjust=False).mean()

    signal = pd.Series(0, index=close.index, dtype=int)
    signal[fast_ema > slow_ema] = 1
    signal[fast_ema < slow_ema] = -1
    # EMA is technically defined from bar 0, but the first *slow* values are
    # dominated by the seed and carry little information.
    signal.iloc[:slow] = 0
    return signal


def trend_filter(
    prices: pd.DataFrame,
    period: int = 200,
) -> pd.Series:
    """Long-term trend filter.

    +1 when price is above the *period*-bar SMA, -1 when below, 0 during
    the warmup window.

    Useful as a regime overlay -- multiply another signal by this to suppress
    counter-trend entries.

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain a ``close`` column.
    period : int
        Lookback for the simple moving average.

    Returns
    -------
    pd.Series
        Integer series in {-1, 0, 1}.
    """
    close = _validate_prices(prices)
    sma = close.rolling(period).mean()

    signal = pd.Series(0, index=close.index, dtype=int)
    signal[close > sma] = 1
    signal[close < sma] = -1
    signal.iloc[:period] = 0
    return signal
