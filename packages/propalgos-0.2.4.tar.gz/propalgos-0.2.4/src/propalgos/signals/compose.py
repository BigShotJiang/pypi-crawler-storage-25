"""Signal composition utilities.

Combine multiple signal series into a single consensus signal. All input
series must contain values in {-1, 0, 1} and share a compatible index.
"""

from __future__ import annotations

import pandas as pd


_VALID_METHODS = frozenset({"and", "or", "majority"})


def combine(
    signals: list[pd.Series],
    method: str = "and",
) -> pd.Series:
    """Combine multiple signal series into one consensus signal.

    Parameters
    ----------
    signals : list[pd.Series]
        Each series should contain int values in {-1, 0, 1}.
    method : str
        Combination strategy:

        - ``"and"``: all signals must be nonzero and agree on direction.
          Result is the shared direction when unanimous, 0 otherwise.
        - ``"or"``: any nonzero signal counts. Result is the sign of the sum
          (majority vote among nonzero signals), 0 only when the votes cancel.
        - ``"majority"``: strict majority vote across all signals (including
          zeros). Result is the direction that exceeds half the signal count,
          0 on ties or when no direction dominates.

    Returns
    -------
    pd.Series
        Integer series in {-1, 0, 1}.

    Raises
    ------
    ValueError
        If *signals* is empty or *method* is unrecognized.
    """
    if not signals:
        raise ValueError("signals list must contain at least one series")
    if method not in _VALID_METHODS:
        raise ValueError(
            f"unknown method {method!r} -- expected one of {sorted(_VALID_METHODS)}"
        )

    # Align all series into a DataFrame (outer join handles mismatched indices)
    df = pd.concat(signals, axis=1).fillna(0).astype(int)
    n = len(signals)

    if method == "and":
        return _combine_and(df)
    elif method == "or":
        return _combine_or(df)
    else:
        return _combine_majority(df, n)


def _combine_and(df: pd.DataFrame) -> pd.Series:
    """All signals must be nonzero and agree on direction."""
    all_positive = (df > 0).all(axis=1)
    all_negative = (df < 0).all(axis=1)

    result = pd.Series(0, index=df.index, dtype=int)
    result[all_positive] = 1
    result[all_negative] = -1
    return result


def _combine_or(df: pd.DataFrame) -> pd.Series:
    """Any nonzero signal counts; result is the sign of the sum."""
    total = df.sum(axis=1)
    result = pd.Series(0, index=df.index, dtype=int)
    result[total > 0] = 1
    result[total < 0] = -1
    return result


def _combine_majority(df: pd.DataFrame, n: int) -> pd.Series:
    """Strict majority vote; ties resolve to 0."""
    positives = (df > 0).sum(axis=1)
    negatives = (df < 0).sum(axis=1)

    threshold = n / 2.0

    result = pd.Series(0, index=df.index, dtype=int)
    result[positives > threshold] = 1
    result[negatives > threshold] = -1
    return result
