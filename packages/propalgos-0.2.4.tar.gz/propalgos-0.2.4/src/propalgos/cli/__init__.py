"""PropAlgos CLI — Typer-based command interface.

Entry points: `propalgos` and `pa` (both map to cli.main:app).
Phase 3: Full command surface (auth, gpu, session, credits, storage, notebook, doctor).
"""
