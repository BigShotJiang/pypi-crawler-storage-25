"""PropAlgos CLI — quant research toolkit and cloud platform interface.

Entry points: ``propalgos`` and ``pa`` (alias).
"""

from __future__ import annotations

import typer

from propalgos._version import __version__

app = typer.Typer(
    name="propalgos",
    help=(
        "PropAlgos SDK — quant research toolkit and cloud platform CLI.\n\n"
        "Run [bold]propalgos doctor[/bold] to verify your installation, "
        "or [bold]propalgos env[/bold] to inspect your runtime environment."
    ),
    no_args_is_help=True,
    rich_markup_mode="rich",
)


@app.command()
def version() -> None:
    """Print the installed SDK version."""
    typer.echo(f"propalgos {__version__}")


@app.command()
def doctor() -> None:
    """Check SDK dependencies and installation health.

    Verifies that core dependencies (numpy, pandas, httpx, yfinance) are
    importable and reports their versions. Also checks optional packages
    (plotly, keyring) and shows install hints for missing ones.
    """
    typer.echo(f"propalgos {__version__}")
    typer.echo()

    checks = [
        ("numpy", "numpy"),
        ("pandas", "pandas"),
        ("httpx", "httpx"),
        ("yfinance", "yfinance"),
    ]
    typer.echo("Core:")
    for label, module_name in checks:
        try:
            mod = __import__(module_name)
            ver = getattr(mod, "__version__", "?")
            typer.echo(f"  ✓ {label} {ver}")
        except ImportError:
            typer.echo(f"  ✗ {label} — not installed")

    optional = [
        ("plotly", "plotly", "pip install 'propalgos[viz]'"),
        ("keyring", "keyring", "pip install 'propalgos[keyring]'"),
    ]
    typer.echo()
    typer.echo("Optional:")
    for label, module_name, install_hint in optional:
        try:
            mod = __import__(module_name)
            ver = getattr(mod, "__version__", "?")
            typer.echo(f"  ✓ {label} {ver}")
        except ImportError:
            typer.echo(f"  ○ {label} — {install_hint}")


@app.command()
def env() -> None:
    """Print runtime environment summary.

    Detects GPU hardware, installed ML frameworks (PyTorch, TensorFlow,
    JAX, RAPIDS), cloud provider, and PropAlgos instance metadata.
    """
    from propalgos.env import summary

    summary()


if __name__ == "__main__":
    app()
