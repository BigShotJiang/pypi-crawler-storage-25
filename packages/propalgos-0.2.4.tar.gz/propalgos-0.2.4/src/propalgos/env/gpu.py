"""GPU and ML framework detection.

Three-tier GPU detection: nvidia-smi (subprocess, XML) -> torch.cuda -> tensorflow.
Framework scan checks torch, tensorflow, jax, and RAPIDS (cudf/cuml).
All detection is lazy and side-effect-free beyond the initial subprocess call.
"""

from __future__ import annotations

import importlib
import subprocess
import xml.etree.ElementTree as ET
from dataclasses import dataclass


@dataclass(frozen=True)
class GPUInfo:
    """Immutable snapshot of GPU state."""

    available: bool
    name: str | None
    memory_mb: int | None
    driver_version: str | None
    cuda_version: str | None
    count: int


@dataclass(frozen=True)
class FrameworkInfo:
    """Single detected ML framework."""

    name: str
    version: str
    gpu_enabled: bool


# ---------------------------------------------------------------------------
# GPU detection
# ---------------------------------------------------------------------------

def _parse_nvidia_smi_xml(xml_text: str) -> GPUInfo:
    """Parse nvidia-smi --query-gpu XML output into GPUInfo."""
    root = ET.fromstring(xml_text)

    driver_version = _text(root, "driver_version")
    cuda_version = _text(root, "cuda_version")

    gpus = root.findall("gpu")
    count = len(gpus)
    if count == 0:
        return GPUInfo(
            available=False,
            name=None,
            memory_mb=None,
            driver_version=driver_version,
            cuda_version=cuda_version,
            count=0,
        )

    first = gpus[0]
    name = _text(first, "product_name")

    # Memory is reported under <fb_memory_usage><total>15360 MiB</total>
    mem_node = first.find("fb_memory_usage")
    memory_mb = _parse_mib(mem_node, "total") if mem_node is not None else None

    return GPUInfo(
        available=True,
        name=name,
        memory_mb=memory_mb,
        driver_version=driver_version,
        cuda_version=cuda_version,
        count=count,
    )


def _text(element: ET.Element, tag: str) -> str | None:
    child = element.find(tag)
    if child is None or child.text is None:
        return None
    val = child.text.strip()
    return val if val and val.lower() != "n/a" else None


def _parse_mib(parent: ET.Element, tag: str) -> int | None:
    """Extract an integer MiB value like '15360 MiB' -> 15360."""
    child = parent.find(tag)
    if child is None or child.text is None:
        return None
    raw = child.text.strip().lower().replace("mib", "").strip()
    try:
        return int(raw)
    except ValueError:
        return None


def _detect_gpu_nvidia_smi() -> GPUInfo | None:
    """Attempt GPU detection via nvidia-smi XML output."""
    try:
        result = subprocess.run(
            ["nvidia-smi", "-x", "-q"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return None
        return _parse_nvidia_smi_xml(result.stdout)
    except (FileNotFoundError, subprocess.TimeoutExpired, ET.ParseError):
        return None


def _detect_gpu_torch() -> GPUInfo | None:
    """Attempt GPU detection via PyTorch."""
    try:
        import torch  # type: ignore[import-untyped]
    except ImportError:
        return None

    if not torch.cuda.is_available():
        return None

    count = torch.cuda.device_count()
    if count == 0:
        return None

    name = torch.cuda.get_device_name(0)
    memory_mb: int | None = None
    try:
        props = torch.cuda.get_device_properties(0)
        memory_mb = props.total_mem // (1024 * 1024)
    except Exception:  # noqa: BLE001
        pass

    cuda_version: str | None = None
    torch_cuda = getattr(torch.version, "cuda", None)
    if torch_cuda:
        cuda_version = str(torch_cuda)

    return GPUInfo(
        available=True,
        name=name,
        memory_mb=memory_mb,
        driver_version=None,
        cuda_version=cuda_version,
        count=count,
    )


def _detect_gpu_tensorflow() -> GPUInfo | None:
    """Attempt GPU detection via TensorFlow."""
    try:
        import tensorflow as tf  # type: ignore[import-untyped]
    except ImportError:
        return None

    gpus = tf.config.list_physical_devices("GPU")
    if not gpus:
        return None

    # TF doesn't expose device name as cleanly — best-effort
    name: str | None = None
    try:
        details = tf.config.experimental.get_device_details(gpus[0])
        name = details.get("device_name")
    except Exception:  # noqa: BLE001
        pass

    return GPUInfo(
        available=True,
        name=name,
        memory_mb=None,
        driver_version=None,
        cuda_version=None,
        count=len(gpus),
    )


_NO_GPU = GPUInfo(
    available=False,
    name=None,
    memory_mb=None,
    driver_version=None,
    cuda_version=None,
    count=0,
)


def detect_gpu() -> GPUInfo:
    """Detect GPU using a three-tier fallback chain.

    1. nvidia-smi (subprocess, most complete)
    2. torch.cuda (if PyTorch installed)
    3. tensorflow (if TF installed)

    Returns GPUInfo with available=False if nothing is found.
    """
    for detector in (_detect_gpu_nvidia_smi, _detect_gpu_torch, _detect_gpu_tensorflow):
        info = detector()
        if info is not None and info.available:
            return info
    return _NO_GPU


# ---------------------------------------------------------------------------
# Framework detection
# ---------------------------------------------------------------------------

def _probe_framework(
    module_name: str,
    display_name: str,
    version_attr: str = "__version__",
    gpu_check: type[_GPUCheck] | None = None,
) -> FrameworkInfo | None:
    """Try to import a framework and extract version + GPU status."""
    try:
        mod = importlib.import_module(module_name)
    except ImportError:
        return None

    version = getattr(mod, version_attr, "unknown")

    gpu_enabled = False
    if gpu_check is not None:
        gpu_enabled = gpu_check.is_enabled()

    return FrameworkInfo(name=display_name, version=str(version), gpu_enabled=gpu_enabled)


class _GPUCheck:
    """Base class for GPU availability checks per framework."""

    @staticmethod
    def is_enabled() -> bool:
        return False


class _TorchGPU(_GPUCheck):
    @staticmethod
    def is_enabled() -> bool:
        try:
            import torch  # type: ignore[import-untyped]
            return torch.cuda.is_available()
        except Exception:  # noqa: BLE001
            return False


class _TensorFlowGPU(_GPUCheck):
    @staticmethod
    def is_enabled() -> bool:
        try:
            import tensorflow as tf  # type: ignore[import-untyped]
            return len(tf.config.list_physical_devices("GPU")) > 0
        except Exception:  # noqa: BLE001
            return False


class _JaxGPU(_GPUCheck):
    @staticmethod
    def is_enabled() -> bool:
        try:
            import jax  # type: ignore[import-untyped]
            return any(d.platform == "gpu" for d in jax.devices())
        except Exception:  # noqa: BLE001
            return False


class _RapidsGPU(_GPUCheck):
    """RAPIDS libraries are GPU-only by definition."""

    @staticmethod
    def is_enabled() -> bool:
        return True


_FRAMEWORK_SPECS: list[tuple[str, str, str, type[_GPUCheck] | None]] = [
    ("torch", "PyTorch", "__version__", _TorchGPU),
    ("tensorflow", "TensorFlow", "__version__", _TensorFlowGPU),
    ("jax", "JAX", "__version__", _JaxGPU),
    ("cudf", "RAPIDS cuDF", "__version__", _RapidsGPU),
    ("cuml", "RAPIDS cuML", "__version__", _RapidsGPU),
]


def detect_frameworks() -> list[FrameworkInfo]:
    """Scan for installed ML frameworks and report version + GPU status.

    Checks: PyTorch, TensorFlow, JAX, RAPIDS cuDF, RAPIDS cuML.
    Returns only frameworks that are actually importable.
    """
    found: list[FrameworkInfo] = []
    for module_name, display_name, version_attr, gpu_check in _FRAMEWORK_SPECS:
        info = _probe_framework(module_name, display_name, version_attr, gpu_check)
        if info is not None:
            found.append(info)
    return found
