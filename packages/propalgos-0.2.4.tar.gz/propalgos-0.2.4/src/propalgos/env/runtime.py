"""Runtime environment detection.

Detects whether we're inside a PropAlgos-managed instance, which cloud provider
is backing it, and basic platform metadata. Pure env-var reads — no network calls,
no metadata endpoint hits. Everything is derived from what the platform injects.
"""

from __future__ import annotations

import os
import platform
import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class RuntimeInfo:
    """Immutable snapshot of the current runtime environment."""

    on_propalgos: bool
    cloud_provider: str | None  # "aws", "gcp", "azure", None
    region: str | None
    instance_type: str | None
    instance_id: str | None
    python_version: str
    platform: str


def _detect_cloud_provider() -> tuple[str | None, str | None, str | None]:
    """Derive cloud provider, region, and instance type from env vars.

    Returns (provider, region, instance_type). All None if undetectable.
    The platform injects PROPALGOS_CLOUD_PROVIDER on managed instances. If that's
    missing, fall back to provider-specific env vars that are commonly present.
    """
    provider = os.environ.get("PROPALGOS_CLOUD_PROVIDER")
    region = os.environ.get("PROPALGOS_REGION")
    instance_type = os.environ.get("PROPALGOS_INSTANCE_TYPE")

    if provider:
        return provider.lower(), region, instance_type

    # AWS fallback: AWS_DEFAULT_REGION or AWS_REGION is almost always set on EC2
    aws_region = os.environ.get("AWS_DEFAULT_REGION") or os.environ.get("AWS_REGION")
    if aws_region:
        return "aws", aws_region, instance_type

    # GCP fallback: CLOUDSDK_COMPUTE_ZONE or GCP_PROJECT are typical
    gcp_zone = os.environ.get("CLOUDSDK_COMPUTE_ZONE")
    gcp_region = os.environ.get("CLOUDSDK_COMPUTE_REGION")
    gcp_project = os.environ.get("GCP_PROJECT") or os.environ.get("GCLOUD_PROJECT")
    if gcp_zone or gcp_region or gcp_project:
        resolved_region = gcp_region or (gcp_zone.rsplit("-", 1)[0] if gcp_zone else None)
        return "gcp", resolved_region, instance_type

    # Azure fallback: common Azure VM env vars
    azure_region = os.environ.get("AZURE_REGION") or os.environ.get("WEBSITE_SITE_NAME")
    if azure_region:
        return "azure", azure_region, instance_type

    return None, region, instance_type


def detect_runtime() -> RuntimeInfo:
    """Build a RuntimeInfo from the current process environment.

    No network calls. No subprocess invocations. Purely reads env vars and
    sys/platform introspection.
    """
    instance_id = os.environ.get("PROPALGOS_INSTANCE_ID")
    on_propalgos = instance_id is not None

    cloud_provider, region, instance_type = _detect_cloud_provider()

    return RuntimeInfo(
        on_propalgos=on_propalgos,
        cloud_provider=cloud_provider,
        region=region,
        instance_type=instance_type,
        instance_id=instance_id,
        python_version=platform.python_version(),
        platform=sys.platform,
    )
