"""Environment detection for PropAlgos SDK.

Exposes runtime, GPU, and ML framework information as pure data.
Works on-platform and off — degrades gracefully when not running inside
a PropAlgos-managed instance or when no GPU is present.

Usage::

    import propalgos as pa

    pa.env.summary()        # pretty-print everything
    pa.env.gpu()            # -> GPUInfo
    pa.env.in_propalgos()   # -> bool
    pa.env.frameworks()     # -> list[FrameworkInfo]
"""

from __future__ import annotations

from propalgos.env.gpu import GPUInfo, FrameworkInfo, detect_frameworks, detect_gpu
from propalgos.env.runtime import RuntimeInfo, detect_runtime

__all__ = [
    "GPUInfo",
    "FrameworkInfo",
    "RuntimeInfo",
    "detect_frameworks",
    "detect_gpu",
    "detect_runtime",
    "frameworks",
    "gpu",
    "in_propalgos",
    "summary",
]


def in_propalgos() -> bool:
    """True when running inside a PropAlgos-managed environment."""
    return detect_runtime().on_propalgos


def gpu() -> GPUInfo:
    """Detect GPU hardware and driver state."""
    return detect_gpu()


def frameworks() -> list[FrameworkInfo]:
    """Detect installed ML frameworks and their GPU status."""
    return detect_frameworks()


# ---------------------------------------------------------------------------
# summary() — formatted console output
# ---------------------------------------------------------------------------

_DIVIDER = "\u2500" * 40  # ────────


def _format_runtime(rt: RuntimeInfo) -> str:
    """Build the 'Runtime' line."""
    if rt.on_propalgos:
        parts = ["PropAlgos Cloud"]
        cloud_detail: list[str] = []
        if rt.cloud_provider:
            cloud_detail.append(rt.cloud_provider.upper())
        if rt.region:
            cloud_detail.append(rt.region)
        if rt.instance_type:
            cloud_detail.append(rt.instance_type)
        if cloud_detail:
            parts.append(f"({', '.join(cloud_detail)})")
        return " ".join(parts)
    return "Local"


def _format_gpu(gi: GPUInfo) -> str:
    """Build the 'GPU' line."""
    if not gi.available:
        return "No GPU detected"

    parts: list[str] = []
    if gi.name:
        parts.append(gi.name)
    if gi.count > 1:
        parts.append(f"x{gi.count}")
    if gi.memory_mb is not None:
        gb = gi.memory_mb / 1024
        # Show whole number if it's clean, one decimal otherwise
        mem_str = f"{gb:.0f} GB" if gb == int(gb) else f"{gb:.1f} GB"
        parts.append(f"({mem_str})")
    cuda_parts: list[str] = []
    if gi.cuda_version:
        cuda_parts.append(f"CUDA {gi.cuda_version}")
    if gi.driver_version:
        cuda_parts.append(f"driver {gi.driver_version}")
    if cuda_parts:
        parts.append(f"\u2014 {', '.join(cuda_parts)}")
    return " ".join(parts) if parts else "GPU detected (details unavailable)"


def _format_frameworks(fws: list[FrameworkInfo]) -> str:
    """Build the 'Frameworks' line."""
    if not fws:
        return "None detected"
    segments: list[str] = []
    for fw in fws:
        gpu_marker = "GPU \u2713" if fw.gpu_enabled else "CPU"
        segments.append(f"{fw.name} {fw.version} ({gpu_marker})")
    return ", ".join(segments)


def summary() -> None:
    """Print a formatted summary of the current environment to stdout.

    Covers runtime context, Python version, GPU state, and ML frameworks.
    No return value — this is a side effect at the boundary.
    """
    rt = detect_runtime()
    gi = detect_gpu()
    fws = detect_frameworks()

    lines = [
        "",
        "PropAlgos Environment",
        _DIVIDER,
        f"  Runtime:      {_format_runtime(rt)}",
        f"  Python:       {rt.python_version}",
        f"  GPU:          {_format_gpu(gi)}",
        f"  Frameworks:   {_format_frameworks(fws)}",
        "",
    ]
    print("\n".join(lines))
