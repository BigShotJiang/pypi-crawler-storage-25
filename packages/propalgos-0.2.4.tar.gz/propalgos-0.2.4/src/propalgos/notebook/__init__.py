"""Notebook helpers and sample browser.

Phase 3: list_samples, display_df, styled HTML output in Jupyter.
"""


def __getattr__(name: str):
    raise NotImplementedError(
        f"pa.notebook.{name} is not yet available — coming in v0.2."
    )
