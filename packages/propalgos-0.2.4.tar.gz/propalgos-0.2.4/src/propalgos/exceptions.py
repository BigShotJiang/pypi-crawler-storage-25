"""PropAlgos exception hierarchy.

All public exceptions inherit from PropAlgosError so callers can catch broadly
or narrowly as needed. Each carries a human-readable `message` and an optional
machine-readable `code` for programmatic handling.
"""

from __future__ import annotations


class PropAlgosError(Exception):
    """Base exception for all PropAlgos errors."""

    def __init__(self, message: str, *, code: str | None = None) -> None:
        self.message = message
        self.code = code
        super().__init__(message)


class AuthenticationError(PropAlgosError):
    """Raised when authentication fails or tokens are invalid/expired."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(message, code="auth_error")


class APIError(PropAlgosError):
    """Raised when a PropAlgos API call returns an error response."""

    def __init__(
        self,
        message: str,
        *,
        status_code: int | None = None,
        response_body: dict | None = None,
    ) -> None:
        self.status_code = status_code
        self.response_body = response_body or {}
        super().__init__(message, code="api_error")


class InsufficientCreditsError(PropAlgosError):
    """Raised when account balance is too low for the requested operation."""

    def __init__(
        self,
        message: str = "Insufficient credits",
        *,
        balance: float | None = None,
        required: float | None = None,
    ) -> None:
        self.balance = balance
        self.required = required
        super().__init__(message, code="insufficient_credits")


class DataError(PropAlgosError):
    """Raised when market data retrieval or validation fails."""

    def __init__(self, message: str) -> None:
        super().__init__(message, code="data_error")


class BacktestError(PropAlgosError):
    """Raised when a backtest encounters an unrecoverable issue."""

    def __init__(self, message: str) -> None:
        super().__init__(message, code="backtest_error")


class ConfigError(PropAlgosError):
    """Raised when configuration is missing or invalid."""

    def __init__(self, message: str) -> None:
        super().__init__(message, code="config_error")
