"""PropAlgos cloud storage integration.

Phase 3: ls, save, read_csv, download via backend storage API.
"""


def __getattr__(name: str):
    raise NotImplementedError(
        f"pa.storage.{name} is not yet available — coming in v0.2. "
        "On-platform notebooks can use ~/my_data/ which syncs to cloud storage."
    )
