"""Configuration management for PropAlgos SDK.

Resolution order:
1. Explicit arguments to functions
2. Environment variables (PROPALGOS_*)
3. Config file (~/.config/propalgos/config.toml)
4. Defaults

On-platform (inside a PropAlgos notebook), PROPALGOS_TOKEN and
PROPALGOS_API_URL are injected automatically.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path


_DEFAULT_API_URL = "https://api.propalgos.ai"
_CONFIG_DIR = Path.home() / ".config" / "propalgos"
_CONFIG_FILE = _CONFIG_DIR / "config.toml"
_CACHE_DIR = Path.home() / ".cache" / "propalgos"


@dataclass(frozen=True)
class Config:
    """Immutable configuration snapshot."""

    api_url: str = field(default_factory=lambda: os.environ.get("PROPALGOS_API_URL") or os.environ.get("PROPALGOS_BACKEND_URL", _DEFAULT_API_URL))
    token: str | None = field(default_factory=lambda: os.environ.get("PROPALGOS_TOKEN"))
    environment: str = field(default_factory=lambda: os.environ.get("PROPALGOS_ENV", "production"))
    cache_dir: Path = field(default_factory=lambda: Path(os.environ.get("PROPALGOS_CACHE_DIR", str(_CACHE_DIR))))
    config_dir: Path = field(default_factory=lambda: _CONFIG_DIR)

    @property
    def is_on_platform(self) -> bool:
        """True when running inside a PropAlgos-managed environment."""
        return os.environ.get("PROPALGOS_INSTANCE_ID") is not None

    @property
    def instance_id(self) -> str | None:
        return os.environ.get("PROPALGOS_INSTANCE_ID")

    @property
    def user_id(self) -> str | None:
        return os.environ.get("PROPALGOS_USER_ID")


@lru_cache(maxsize=1)
def get_config() -> Config:
    """Return the global config singleton. Cached after first call."""
    return Config()


def reset_config() -> None:
    """Clear cached config — useful for tests."""
    get_config.cache_clear()
