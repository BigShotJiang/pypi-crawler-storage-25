"""Risk analytics as pure functions over return series.

Every function takes a pd.Series of simple (arithmetic) period returns and
produces either a scalar or a derived pd.Series. No state, no side effects.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from propalgos.factors.performance import TRADING_DAYS


def max_drawdown(returns: pd.Series) -> float:
    """Maximum peak-to-trough drawdown.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.

    Returns
    -------
    float
        Max drawdown as a negative number (e.g. -0.25 for a 25% drawdown).
        Returns 0.0 for an empty series.
    """
    if len(returns) == 0:
        return 0.0
    cumulative = (1 + returns).cumprod()
    running_max = cumulative.cummax()
    drawdowns = cumulative / running_max - 1
    return float(drawdowns.min())


def drawdown_series(returns: pd.Series) -> pd.Series:
    """Full drawdown time series.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.

    Returns
    -------
    pd.Series
        Drawdown at each point (negative values indicate being below peak).
    """
    cumulative = (1 + returns).cumprod()
    running_max = cumulative.cummax()
    return cumulative / running_max - 1


def rolling_volatility(returns: pd.Series, window: int = 21) -> pd.Series:
    """Rolling annualized volatility.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.
    window : int
        Lookback window in trading days. Default 21 (~1 month).

    Returns
    -------
    pd.Series
        Annualized rolling standard deviation. Leading NaN values where
        the window has not yet filled.
    """
    return returns.rolling(window=window).std() * np.sqrt(TRADING_DAYS)


def beta(returns: pd.Series, benchmark_returns: pd.Series) -> float:
    """Beta relative to a benchmark.

    Parameters
    ----------
    returns : pd.Series
        Strategy simple period returns.
    benchmark_returns : pd.Series
        Benchmark simple period returns (same index alignment expected).

    Returns
    -------
    float
        Beta coefficient, or 0.0 if benchmark variance is zero.
    """
    aligned = pd.concat([returns, benchmark_returns], axis=1).dropna()
    if len(aligned) < 2:
        return 0.0
    strat = aligned.iloc[:, 0]
    bench = aligned.iloc[:, 1]
    bench_var = bench.var()
    if bench_var == 0:
        return 0.0
    covariance = strat.cov(bench)
    return float(covariance / bench_var)


def var(returns: pd.Series, confidence: float = 0.95) -> float:
    """Historical Value at Risk.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.
    confidence : float
        Confidence level (e.g. 0.95 for 95%).

    Returns
    -------
    float
        VaR as a negative number representing the loss threshold at the
        given confidence level. Returns 0.0 for an empty series.
    """
    if len(returns) == 0:
        return 0.0
    # Use Series.quantile() instead of np.percentile() — works on both
    # pandas and cuDF Series without forcing a CPU roundtrip.
    return float(returns.quantile((1 - confidence)))


def cvar(returns: pd.Series, confidence: float = 0.95) -> float:
    """Conditional Value at Risk (Expected Shortfall).

    The average loss in the worst (1 - confidence) fraction of outcomes.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.
    confidence : float
        Confidence level (e.g. 0.95 for 95%).

    Returns
    -------
    float
        CVaR as a negative number. Returns 0.0 for an empty series.
    """
    if len(returns) == 0:
        return 0.0
    var_threshold = var(returns, confidence)
    tail = returns[returns <= var_threshold]
    if len(tail) == 0:
        return float(var_threshold)
    return float(tail.mean())


def annualized_volatility(returns: pd.Series) -> float:
    """Annualized volatility (standard deviation of returns, scaled).

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.

    Returns
    -------
    float
        Annualized volatility as a decimal.
    """
    if len(returns) == 0:
        return 0.0
    return float(returns.std() * np.sqrt(TRADING_DAYS))
