"""Performance metrics as pure functions over return series.

Every function takes a pd.Series of simple (arithmetic) period returns and
produces a single scalar. No state, no side effects, no mutation.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

TRADING_DAYS: int = 252


def sharpe(returns: pd.Series, rf: float = 0.0) -> float:
    """Annualized Sharpe ratio.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.
    rf : float
        Annualized risk-free rate (e.g. 0.05 for 5%).

    Returns
    -------
    float
        Annualized Sharpe ratio, or 0.0 if volatility is zero.
    """
    excess = returns - rf / TRADING_DAYS
    if excess.std() == 0:
        return 0.0
    return float(excess.mean() / excess.std() * np.sqrt(TRADING_DAYS))


def sortino(returns: pd.Series, rf: float = 0.0) -> float:
    """Annualized Sortino ratio (downside deviation only).

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.
    rf : float
        Annualized risk-free rate.

    Returns
    -------
    float
        Annualized Sortino ratio, or 0.0 if no downside periods exist.
    """
    excess = returns - rf / TRADING_DAYS
    downside = excess[excess < 0]
    if len(downside) == 0 or downside.std() == 0:
        return 0.0
    return float(excess.mean() / downside.std() * np.sqrt(TRADING_DAYS))


def calmar(returns: pd.Series) -> float:
    """Calmar ratio: annualized return / abs(max drawdown).

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.

    Returns
    -------
    float
        Calmar ratio, or 0.0 if max drawdown is zero.
    """
    ann = annualized_return(returns)
    cumulative = (1 + returns).cumprod()
    running_max = cumulative.cummax()
    drawdowns = cumulative / running_max - 1
    mdd = float(drawdowns.min())
    if mdd == 0:
        return 0.0
    return float(ann / abs(mdd))


def total_return(returns: pd.Series) -> float:
    """Total cumulative return.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.

    Returns
    -------
    float
        Total return as a decimal (e.g. 0.10 for 10%).
    """
    return float((1 + returns).prod() - 1)


def annualized_return(returns: pd.Series) -> float:
    """Compound annual growth rate (CAGR).

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.

    Returns
    -------
    float
        Annualized return as a decimal.
    """
    n_periods = len(returns)
    if n_periods == 0:
        return 0.0
    total = (1 + returns).prod()
    if total <= 0:
        return -1.0
    years = n_periods / TRADING_DAYS
    return float(total ** (1 / years) - 1)


def win_rate(returns: pd.Series) -> float:
    """Fraction of positive-return periods.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.

    Returns
    -------
    float
        Win rate in [0.0, 1.0], or 0.0 for an empty series.
    """
    if len(returns) == 0:
        return 0.0
    return float((returns > 0).sum() / len(returns))


def profit_factor(returns: pd.Series) -> float:
    """Gross profits divided by gross losses.

    Parameters
    ----------
    returns : pd.Series
        Simple period returns.

    Returns
    -------
    float
        Profit factor (>1 means profitable), or 0.0 if there are no losses.
    """
    gains = returns[returns > 0].sum()
    losses = returns[returns < 0].sum()
    if losses == 0:
        return 0.0
    return float(abs(gains / losses))
