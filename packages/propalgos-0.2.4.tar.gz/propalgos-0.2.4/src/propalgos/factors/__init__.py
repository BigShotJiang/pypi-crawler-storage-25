"""Performance metrics and risk analytics.

All functions are pure — they accept a pd.Series of simple returns and produce
scalars or derived series. No state, no side effects.

Usage::

    import pandas as pd
    from propalgos.factors import sharpe, max_drawdown

    returns = pd.Series([0.01, -0.005, 0.003, 0.007, -0.002])
    print(sharpe(returns))
    print(max_drawdown(returns))
"""

from __future__ import annotations

from propalgos.factors.performance import (
    TRADING_DAYS,
    annualized_return,
    calmar,
    profit_factor,
    sharpe,
    sortino,
    total_return,
    win_rate,
)
from propalgos.factors.risk import (
    annualized_volatility,
    beta,
    cvar,
    drawdown_series,
    max_drawdown,
    rolling_volatility,
    var,
)

__all__ = [
    "TRADING_DAYS",
    # performance
    "annualized_return",
    "calmar",
    "profit_factor",
    "sharpe",
    "sortino",
    "total_return",
    "win_rate",
    # risk
    "annualized_volatility",
    "beta",
    "cvar",
    "drawdown_series",
    "max_drawdown",
    "rolling_volatility",
    "var",
]
