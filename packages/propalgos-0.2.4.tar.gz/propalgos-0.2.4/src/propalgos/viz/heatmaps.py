"""Heatmap visualizations.

Provides:
- ``heatmap`` — general-purpose heatmap for any (rows x cols) DataFrame
- ``monthly_returns`` — specialized monthly-returns heatmap (years x months)

Both accept either raw data or objects with a ``.returns`` attribute.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

import pandas as pd

from propalgos.viz._compat import _require_plotly, _to_numpy, go
from propalgos.viz.theme import COLORS, COLORSCALES, apply_theme

# ---------------------------------------------------------------------------
# Protocol for BacktestResult duck-typing
# ---------------------------------------------------------------------------

_MONTH_LABELS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]


@runtime_checkable
class _HasReturns(Protocol):
    """Anything that exposes a ``.returns`` pd.Series (e.g. BacktestResult)."""

    @property
    def returns(self) -> pd.Series: ...


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_returns(result_or_returns: Any) -> pd.Series:
    """Normalize input to a pd.Series of daily returns."""
    if isinstance(result_or_returns, pd.Series):
        return result_or_returns
    if isinstance(result_or_returns, _HasReturns):
        return result_or_returns.returns
    raise TypeError(
        f"Expected pd.Series or an object with a .returns attribute, "
        f"got {type(result_or_returns).__name__}"
    )


def _build_monthly_matrix(returns: pd.Series) -> pd.DataFrame:
    """Aggregate daily returns into a (years x 12) monthly return matrix.

    Each cell is the compounded monthly return for that (year, month) pair.
    Missing months are ``NaN``.

    Uses vectorized ``resample`` + ``pivot`` instead of
    ``groupby().apply(lambda)`` so cudf.pandas can accelerate the entire path.
    """
    if not isinstance(returns.index, pd.DatetimeIndex):
        returns = returns.copy()
        returns.index = pd.to_datetime(returns.index)

    # Vectorized compounding per calendar month (no lambda, no Python loop)
    monthly = (1 + returns).resample("ME").prod() - 1

    # Pivot into year × month matrix
    matrix = pd.DataFrame({
        "year": monthly.index.year,
        "month": monthly.index.month,
        "ret": monthly.values,
    })
    matrix = matrix.pivot(index="year", columns="month", values="ret")
    matrix = matrix.reindex(columns=range(1, 13))
    matrix.index.name = "Year"
    matrix.columns = _MONTH_LABELS
    return matrix


def _resolve_colorscale(colorscale: str | list) -> list:
    """Resolve a colorscale name to a Plotly colorscale list.

    Accepts a preset name (``"diverging"``, ``"sequential"``, ``"rsi"``)
    or a raw Plotly colorscale list.
    """
    if isinstance(colorscale, str):
        if colorscale not in COLORSCALES:
            raise ValueError(
                f"Unknown colorscale {colorscale!r}. "
                f"Available: {sorted(COLORSCALES)} or pass a raw list."
            )
        return COLORSCALES[colorscale]
    return colorscale


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def heatmap(
    z: pd.DataFrame,
    colorscale: str | list = "diverging",
    fmt: str = ".1%",
    title: str = "",
    zrange: tuple[float, float] | None = None,
) -> go.Figure:
    """General-purpose heatmap.

    Parameters
    ----------
    z : pd.DataFrame
        Matrix to visualize. Row index = y-axis labels, column names =
        x-axis labels. Values are numeric (``NaN`` renders as blank).
    colorscale : str | list
        Preset name (``"diverging"``, ``"sequential"``, ``"rsi"``) or a
        raw Plotly colorscale list.
    fmt : str
        Format string for cell text (e.g. ``".1%"`` for percentages,
        ``".0f"`` for integers).
    title : str
        Chart title.
    zrange : tuple[float, float] | None
        Explicit ``(zmin, zmax)``. If ``None``, auto-computed as symmetric
        around zero for ``"diverging"`` scales or from data range otherwise.

    Returns
    -------
    go.Figure
        Themed Plotly heatmap.
    """
    _require_plotly()

    resolved_cs = _resolve_colorscale(colorscale)

    x_labels = [str(c) for c in z.columns]
    y_labels = [str(r) for r in z.index]

    # Transfer to CPU once, then format (string ops are CPU-only anyway)
    z_cpu = z.to_pandas() if hasattr(z, "to_pandas") else z
    text_matrix = z_cpu.map(
        lambda v: f"{v:{fmt}}" if pd.notna(v) else ""
    )

    # GPU-native aggregation — stays on device until scalar extraction
    if zrange is not None:
        zmin, zmax = zrange
    elif colorscale == "diverging":
        abs_max = float(z.abs().max().max())
        abs_max = max(abs_max, 1e-6)
        zmin, zmax = -abs_max, abs_max
    else:
        zmin = float(z.min().min())
        zmax = float(z.max().max())
        if zmin == zmax:
            zmin -= 0.5
            zmax += 0.5

    fig = go.Figure(
        data=go.Heatmap(
            z=_to_numpy(z),
            x=x_labels,
            y=y_labels,
            text=_to_numpy(text_matrix),
            texttemplate="%{text}",
            textfont={"size": 11, "color": COLORS["text"]},
            colorscale=resolved_cs,
            zmin=zmin,
            zmax=zmax,
            hovertemplate="%{y} %{x}: %{text}<extra></extra>",
            showscale=True,
            xgap=2,
            ygap=2,
            colorbar={
                "tickfont": {"color": COLORS["text_secondary"]},
                "outlinewidth": 0,
            },
        )
    )

    fig.update_layout(
        title=title,
        yaxis={"autorange": "reversed", "dtick": 1},
        xaxis={"side": "top", "dtick": 1},
        height=max(280, 36 * len(y_labels) + 100),
        width=max(480, 60 * len(x_labels) + 120),
    )

    return apply_theme(fig)


def monthly_returns(result_or_returns: Any) -> go.Figure:
    """Monthly returns heatmap.

    Parameters
    ----------
    result_or_returns : BacktestResult | pd.Series
        Either a ``BacktestResult`` (or any object with a ``.returns``
        attribute) or a raw ``pd.Series`` of daily simple returns.

    Returns
    -------
    go.Figure
        Heatmap with rows = years, columns = months (Jan--Dec).
        Color scale: red (negative) through surface (zero) to green (positive).
        Cell text shows the percentage return.
    """
    returns = _extract_returns(result_or_returns)
    matrix = _build_monthly_matrix(returns)

    return heatmap(
        z=matrix,
        colorscale="diverging",
        fmt="+.1%",
        title="Monthly Returns",
    )
