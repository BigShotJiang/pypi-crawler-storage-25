"""Plotly import guard.

Centralizes the optional-dependency check so every chart function in
``propalgos.viz`` can call ``_require_plotly()`` at the top and get a clean
error message if plotly is not installed.

The guard is deferred — importing ``propalgos.viz`` never fails. The
``ImportError`` only fires when a chart function is actually called.
"""

from __future__ import annotations

from typing import Any

_INSTALL_HINT = "Visualization requires plotly. Install with: pip install 'propalgos[viz]'"

_plotly_available: bool

try:
    import plotly.graph_objects as go  # noqa: F401
    from plotly.subplots import make_subplots  # noqa: F401

    _plotly_available = True
except ImportError:
    _plotly_available = False

    # Provide stub references so static analysis doesn't choke on modules that
    # import ``go`` / ``make_subplots`` at the top level. They are never used
    # at runtime because every public function calls ``_require_plotly()`` first.
    go: Any = None  # type: ignore[assignment]
    make_subplots: Any = None  # type: ignore[assignment]


def _require_plotly() -> None:
    """Raise ``ImportError`` with install instructions if plotly is missing.

    Every public chart function calls this at entry so the error is deferred
    to call time rather than import time.
    """
    if not _plotly_available:
        raise ImportError(_INSTALL_HINT)


def _to_numpy(s: Any) -> Any:
    """GPU-safe extraction to numpy array for Plotly consumption.

    cuDF's ``.values`` returns a cupy array which Plotly doesn't understand.
    This calls ``.to_pandas()`` first when available (cuDF objects), then
    ``.values`` to get a plain numpy array. On regular pandas objects
    ``.to_pandas()`` is a no-op that returns self.
    """
    try:
        return s.to_pandas().values
    except AttributeError:
        return s.values
