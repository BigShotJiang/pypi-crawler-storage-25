"""Interactive candlestick charts with optional indicators and trade signals.

All functions return a ``plotly.graph_objects.Figure`` — the caller decides
when and how to render it (``.show()``, notebook auto-display, or export).
"""

from __future__ import annotations

import re

import pandas as pd

from propalgos.viz._compat import _require_plotly, go
from propalgos.viz.theme import COLORS, apply_theme

# ---------------------------------------------------------------------------
# Indicator parsing
# ---------------------------------------------------------------------------

_INDICATOR_RE = re.compile(r"^(?P<name>[a-z]+)(?P<period>\d+)$")

_SMA_STYLE = {"dash": "solid", "width": 1.5}
_EMA_STYLE = {"dash": "dot", "width": 1.5}

# Colors cycle for overlay lines (skipping the first accent which is the candle body).
_OVERLAY_COLORS = [
    "#818cf8",  # indigo-light
    "#a78bfa",  # violet
    "#38bdf8",  # sky
    "#2dd4bf",  # teal
    "#f472b6",  # pink
]


def _compute_sma(close: pd.Series, period: int) -> pd.Series:
    return close.rolling(period).mean()


def _compute_ema(close: pd.Series, period: int) -> pd.Series:
    return close.ewm(span=period, adjust=False).mean()


def _compute_bb(
    close: pd.Series, period: int, num_std: float = 2.0
) -> tuple[pd.Series, pd.Series, pd.Series]:
    """Bollinger Bands: (middle, upper, lower)."""
    middle = close.rolling(period).mean()
    std = close.rolling(period).std()
    upper = middle + num_std * std
    lower = middle - num_std * std
    return middle, upper, lower


def _add_indicator(
    fig: go.Figure,
    close: pd.Series,
    index: pd.Index,
    spec: str,
    color_idx: int,
) -> int:
    """Parse a single indicator spec, add traces to *fig*, return next color index."""
    match = _INDICATOR_RE.match(spec.lower().strip())
    if match is None:
        return color_idx  # silently skip unparseable specs

    name = match.group("name")
    period = int(match.group("period"))
    color = _OVERLAY_COLORS[color_idx % len(_OVERLAY_COLORS)]

    if name == "sma":
        fig.add_trace(
            go.Scatter(
                x=index,
                y=_compute_sma(close, period),
                mode="lines",
                name=f"SMA {period}",
                line={"color": color, **_SMA_STYLE},
            )
        )
        return color_idx + 1

    if name == "ema":
        fig.add_trace(
            go.Scatter(
                x=index,
                y=_compute_ema(close, period),
                mode="lines",
                name=f"EMA {period}",
                line={"color": color, **_EMA_STYLE},
            )
        )
        return color_idx + 1

    if name == "bb":
        mid, upper, lower = _compute_bb(close, period)
        # Upper band
        fig.add_trace(
            go.Scatter(
                x=index,
                y=upper,
                mode="lines",
                name=f"BB {period} upper",
                line={"color": color, "width": 1, "dash": "dash"},
                showlegend=False,
            )
        )
        # Lower band — filled region to upper
        fig.add_trace(
            go.Scatter(
                x=index,
                y=lower,
                mode="lines",
                name=f"BB {period}",
                line={"color": color, "width": 1, "dash": "dash"},
                fill="tonexty",
                fillcolor=f"rgba({int(color[1:3], 16)},{int(color[3:5], 16)},{int(color[5:7], 16)},0.07)",
            )
        )
        # Middle line
        fig.add_trace(
            go.Scatter(
                x=index,
                y=mid,
                mode="lines",
                name=f"BB {period} mid",
                line={"color": color, "width": 1, "dash": "dot"},
                showlegend=False,
            )
        )
        return color_idx + 1

    return color_idx


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def candles(
    prices: pd.DataFrame,
    indicators: list[str] | None = None,
    signals: pd.Series | None = None,
    title: str | None = None,
) -> go.Figure:
    """Interactive candlestick chart with optional indicators and signal markers.

    Parameters
    ----------
    prices : pd.DataFrame
        Must contain ``open``, ``high``, ``low``, ``close`` columns.
        Index should be datetime.
    indicators : list[str] | None
        Indicator specs parsed as ``{name}{period}``: ``sma20``, ``ema50``,
        ``bb20`` (Bollinger Bands).
    signals : pd.Series | None
        Trade signal series aligned to *prices* index. ``+1`` renders a green
        up-triangle (buy), ``-1`` renders a red down-triangle (sell). Other
        values are ignored.
    title : str | None
        Chart title. Defaults to ``"Price"`` if omitted.

    Returns
    -------
    go.Figure
        Themed Plotly figure. Call ``.show()`` or let a notebook auto-render.
    """
    _require_plotly()

    _validate_ohlc(prices)
    idx = prices.index
    close = prices["close"]

    fig = go.Figure()

    # --- Candlestick trace ---------------------------------------------------
    fig.add_trace(
        go.Candlestick(
            x=idx,
            open=prices["open"],
            high=prices["high"],
            low=prices["low"],
            close=close,
            name="Price",
            increasing_line_color=COLORS["positive"],
            increasing_fillcolor=COLORS["positive"],
            decreasing_line_color=COLORS["negative"],
            decreasing_fillcolor=COLORS["negative"],
        )
    )

    # --- Indicators ----------------------------------------------------------
    if indicators:
        color_idx = 0
        for spec in indicators:
            color_idx = _add_indicator(fig, close, idx, spec, color_idx)

    # --- Signals (buy / sell markers) ----------------------------------------
    if signals is not None:
        aligned = signals.reindex(idx)
        buys = aligned == 1
        sells = aligned == -1

        if buys.any():
            buy_prices = prices.loc[buys, "low"] * 0.98  # slightly below candle
            fig.add_trace(
                go.Scatter(
                    x=buy_prices.index,
                    y=buy_prices,
                    mode="markers",
                    name="Buy",
                    marker={
                        "symbol": "triangle-up",
                        "size": 10,
                        "color": COLORS["positive"],
                        "line": {"width": 1, "color": COLORS["positive"]},
                    },
                )
            )

        if sells.any():
            sell_prices = prices.loc[sells, "high"] * 1.02  # slightly above candle
            fig.add_trace(
                go.Scatter(
                    x=sell_prices.index,
                    y=sell_prices,
                    mode="markers",
                    name="Sell",
                    marker={
                        "symbol": "triangle-down",
                        "size": 10,
                        "color": COLORS["negative"],
                        "line": {"width": 1, "color": COLORS["negative"]},
                    },
                )
            )

    # --- Layout --------------------------------------------------------------
    fig.update_layout(
        title=title or "Price",
        xaxis_title="Date",
        yaxis_title="Price",
        xaxis_rangeslider_visible=False,
        height=520,
    )

    return apply_theme(fig)


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

_REQUIRED_COLUMNS = {"open", "high", "low", "close"}


def _validate_ohlc(prices: pd.DataFrame) -> None:
    """Raise ``ValueError`` if required OHLC columns are missing."""
    missing = _REQUIRED_COLUMNS - set(prices.columns)
    if missing:
        raise ValueError(
            f"prices DataFrame missing required columns: {sorted(missing)}. "
            f"Found: {list(prices.columns)}"
        )
    if prices.empty:
        raise ValueError("prices DataFrame is empty — provide at least one row of OHLCV data")
