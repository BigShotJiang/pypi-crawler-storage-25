"""PropAlgos theme for Plotly figures — dark and light modes.

Defines the canonical color palettes, colorscale presets, and a single
``apply_theme`` function that stamps any Figure with the PropAlgos look.
Every chart in the viz module calls this before returning — external users
can also apply it to custom figures.

Mode is controlled via ``set_mode("dark")`` or ``set_mode("light")``.
Default is dark. ``COLORS`` is a mutable dict that always reflects the
active mode — all chart functions read from it at call time, so switching
mode affects every subsequent chart.
"""

from __future__ import annotations

from typing import Any

from propalgos.viz._compat import go

# ---------------------------------------------------------------------------
# Palettes
# ---------------------------------------------------------------------------

_DARK: dict[str, str] = {
    "bg": "#0a0a0f",
    "surface": "#12121a",
    "text": "#e0e0e8",
    "text_secondary": "#8888a0",
    "accent": "#6366f1",       # indigo
    "positive": "#22c55e",     # green
    "negative": "#ef4444",     # red
    "warning": "#eab308",      # yellow
    "grid": "#1e1e2e",
    "line": "#4f46e5",
}

_LIGHT: dict[str, str] = {
    "bg": "#ffffff",
    "surface": "#f8f8fc",
    "text": "#1a1a2e",
    "text_secondary": "#666680",
    "accent": "#6366f1",       # indigo — same in both modes
    "positive": "#16a34a",     # slightly darker green for white bg
    "negative": "#dc2626",     # slightly darker red for white bg
    "warning": "#ca8a04",      # darker yellow for white bg
    "grid": "#e0e0e8",
    "line": "#4f46e5",
}

# Active palette — mutated in place by set_mode(). Every chart function
# reads from this dict at call time, so mode switches propagate automatically.
COLORS: dict[str, str] = dict(_DARK)

# Plotly template name for current mode.
_template: str = "plotly_dark"

# Extended accent ramp for multi-trace charts.
ACCENT_SEQUENCE: list[str] = [
    "#6366f1",  # indigo
    "#818cf8",  # indigo-light
    "#a78bfa",  # violet
    "#c084fc",  # purple
    "#f472b6",  # pink
    "#38bdf8",  # sky
    "#22d3ee",  # cyan
    "#2dd4bf",  # teal
]

# Font stack — system sans-serif that renders cleanly in notebooks and browsers.
_FONT_FAMILY = "Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"

# ---------------------------------------------------------------------------
# Colorscale presets
# ---------------------------------------------------------------------------

def _build_colorscales(palette: dict[str, str]) -> dict[str, list]:
    """Build colorscale presets from a palette."""
    return {
        "diverging": [
            [0.0, palette["negative"]],
            [0.5, palette["surface"]],
            [1.0, palette["positive"]],
        ],
        "sequential": [
            [0.0, palette["positive"]],
            [0.5, palette["warning"]],
            [1.0, palette["negative"]],
        ],
        "rsi": [
            [0.0, "#008000"],
            [0.3, "#90EE90"],
            [0.5, palette["surface"]],
            [0.7, "#FFA07A"],
            [1.0, "#C80000"],
        ],
    }


COLORSCALES: dict[str, list] = _build_colorscales(_DARK)

# ---------------------------------------------------------------------------
# Mode control
# ---------------------------------------------------------------------------


def set_mode(mode: str) -> None:
    """Set the global theme mode.

    Parameters
    ----------
    mode : ``"dark"`` or ``"light"``
    """
    global _template
    if mode not in ("dark", "light"):
        raise ValueError(f"mode must be 'dark' or 'light', got {mode!r}")

    source = _DARK if mode == "dark" else _LIGHT
    COLORS.clear()
    COLORS.update(source)

    COLORSCALES.clear()
    COLORSCALES.update(_build_colorscales(source))

    _template = "plotly_dark" if mode == "dark" else "plotly_white"


def colors() -> dict[str, str]:
    """Return the active color palette (same object as ``COLORS``)."""
    return COLORS


def colorscales() -> dict[str, list]:
    """Return the active colorscale presets (same object as ``COLORSCALES``)."""
    return COLORSCALES


# ---------------------------------------------------------------------------
# Theme application
# ---------------------------------------------------------------------------


def apply_theme(fig: go.Figure) -> go.Figure:
    """Apply the PropAlgos theme to *fig* and return it (for chaining).

    Reads from the active palette (``COLORS``), so the result reflects
    whichever mode was set via ``set_mode()``.
    """
    axis_defaults: dict[str, Any] = {
        "gridcolor": COLORS["grid"],
        "zerolinecolor": COLORS["grid"],
        "linecolor": COLORS["grid"],
        "tickfont": {"color": COLORS["text_secondary"], "size": 11},
        "title": {"font": {"color": COLORS["text"], "size": 12}},
        "showgrid": True,
        "gridwidth": 1,
    }

    fig.update_layout(
        template=_template,
        paper_bgcolor=COLORS["bg"],
        plot_bgcolor=COLORS["surface"],
        font={
            "family": _FONT_FAMILY,
            "color": COLORS["text"],
            "size": 12,
        },
        title_font={
            "family": _FONT_FAMILY,
            "color": COLORS["text"],
            "size": 16,
        },
        colorway=ACCENT_SEQUENCE,
        margin={"l": 60, "r": 30, "t": 50, "b": 40},
        legend={
            "bgcolor": "rgba(0,0,0,0)",
            "font": {"color": COLORS["text_secondary"], "size": 11},
        },
        xaxis=axis_defaults,
        yaxis=axis_defaults,
        hoverlabel={
            "bgcolor": COLORS["surface"],
            "font_color": COLORS["text"],
            "bordercolor": COLORS["grid"],
        },
    )
    return fig
