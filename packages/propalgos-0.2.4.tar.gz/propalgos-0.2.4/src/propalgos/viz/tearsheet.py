"""Strategy tearsheet — the signature PropAlgos visualization.

Renders a multi-panel Plotly figure covering equity curve, drawdown, monthly
returns, and a key-metrics summary. Designed to be the thing that gets
screenshotted and shared.
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

import pandas as pd

from propalgos.viz._compat import _require_plotly, _to_numpy, go, make_subplots
from propalgos.viz.heatmaps import _build_monthly_matrix, _MONTH_LABELS
from propalgos.viz.theme import COLORS, apply_theme

# ---------------------------------------------------------------------------
# Protocol — anything that quacks like a backtest result
# ---------------------------------------------------------------------------


@runtime_checkable
class _BacktestLike(Protocol):
    """Structural type for backtest result objects.

    At minimum: a ``.returns`` Series. Optional: ``.benchmark_returns``,
    ``.trades``, ``.name``.
    """

    @property
    def returns(self) -> pd.Series: ...


def _get_attr(obj: Any, name: str, default: Any = None) -> Any:
    """Safe attribute access — returns *default* if missing."""
    return getattr(obj, name, default)


# ---------------------------------------------------------------------------
# Metric computation (pure)
# ---------------------------------------------------------------------------


def _compute_metrics(returns: pd.Series) -> dict[str, str]:
    """Derive display-ready metric strings from a daily return series."""
    from propalgos.factors.performance import (
        TRADING_DAYS,
        annualized_return,
        profit_factor,
        sharpe,
        sortino,
        total_return,
        win_rate,
    )
    from propalgos.factors.risk import (
        annualized_volatility,
        cvar,
        max_drawdown,
    )

    n_days = len(returns)
    years = n_days / TRADING_DAYS

    return {
        "Total Return": f"{total_return(returns):+.1%}",
        "CAGR": f"{annualized_return(returns):+.1%}",
        "Sharpe": f"{sharpe(returns):.2f}",
        "Sortino": f"{sortino(returns):.2f}",
        "Max Drawdown": f"{max_drawdown(returns):.1%}",
        "Volatility": f"{annualized_volatility(returns):.1%}",
        "Win Rate": f"{win_rate(returns):.1%}",
        "Profit Factor": f"{profit_factor(returns):.2f}",
        "CVaR 95%": f"{cvar(returns):.2%}",
        "Trading Days": f"{n_days:,}",
        "Period": f"{years:.1f}y",
    }


# ---------------------------------------------------------------------------
# Subplot builders
# ---------------------------------------------------------------------------


def _add_equity_curve(
    fig: go.Figure,
    returns: pd.Series,
    benchmark_returns: pd.Series | None,
    row: int,
    col: int,
) -> None:
    """Equity curve: cumulative wealth index starting at 1.0."""
    equity = (1 + returns).cumprod()

    fig.add_trace(
        go.Scatter(
            x=equity.index,
            y=_to_numpy(equity),
            mode="lines",
            name="Strategy",
            line={"color": COLORS["accent"], "width": 2.2},
            fill="tozeroy",
            fillcolor="rgba(99, 102, 241, 0.08)",
        ),
        row=row,
        col=col,
    )

    if benchmark_returns is not None and len(benchmark_returns) > 0:
        bench_equity = (1 + benchmark_returns).cumprod()
        fig.add_trace(
            go.Scatter(
                x=bench_equity.index,
                y=_to_numpy(bench_equity),
                mode="lines",
                name="Benchmark",
                line={"color": COLORS["text_secondary"], "width": 1.4, "dash": "dot"},
            ),
            row=row,
            col=col,
        )


def _add_drawdown(
    fig: go.Figure,
    returns: pd.Series,
    row: int,
    col: int,
) -> None:
    """Drawdown chart — shaded area below zero."""
    cumulative = (1 + returns).cumprod()
    running_max = cumulative.cummax()
    dd = cumulative / running_max - 1

    fig.add_trace(
        go.Scatter(
            x=dd.index,
            y=_to_numpy(dd),
            mode="lines",
            name="Drawdown",
            line={"color": COLORS["negative"], "width": 1.2},
            fill="tozeroy",
            fillcolor="rgba(239, 68, 68, 0.15)",
            showlegend=False,
        ),
        row=row,
        col=col,
    )


def _add_monthly_heatmap(
    fig: go.Figure,
    returns: pd.Series,
    row: int,
    col: int,
) -> None:
    """Monthly returns heatmap as a subplot."""
    matrix = _build_monthly_matrix(returns)
    # Transfer to CPU once, then format (string ops are CPU-only anyway)
    matrix_cpu = matrix.to_pandas() if hasattr(matrix, "to_pandas") else matrix
    text_matrix = matrix_cpu.map(lambda v: f"{v:+.1%}" if pd.notna(v) else "")

    # GPU-native aggregation — stays on device until scalar extraction
    abs_max = float(matrix.abs().max().max())
    if abs_max == 0:
        abs_max = 0.01

    fig.add_trace(
        go.Heatmap(
            z=_to_numpy(matrix),
            x=_MONTH_LABELS,
            y=[str(y) for y in matrix.index],
            text=_to_numpy(text_matrix),
            texttemplate="%{text}",
            textfont={"size": 10, "color": COLORS["text"]},
            colorscale=[
                [0.0, COLORS["negative"]],
                [0.5, "#1a1a2e"],
                [1.0, COLORS["positive"]],
            ],
            zmin=-abs_max,
            zmax=abs_max,
            showscale=False,
            hovertemplate="%{y} %{x}: %{text}<extra></extra>",
        ),
        row=row,
        col=col,
    )


def _add_metrics_annotation(
    fig: go.Figure,
    metrics: dict[str, str],
    row: int,
    col: int,
) -> None:
    """Render the metrics block as an annotation in the top-right of the
    equity curve subplot.

    Uses a monospaced text block positioned via paper-relative coordinates
    inside the first subplot area.
    """
    lines: list[str] = []
    for label, value in metrics.items():
        lines.append(f"{label:<16s}{value:>10s}")
    block = "\n".join(lines)

    text_color = COLORS["text"]
    fig.add_annotation(
        text=f"<span style='font-family:JetBrains Mono,Fira Code,monospace;font-size:11px;"
             f"line-height:1.55;color:{text_color}'>{block}</span>",
        xref="paper",
        yref="paper",
        x=0.99,
        y=0.99,
        xanchor="right",
        yanchor="top",
        showarrow=False,
        align="left",
        bgcolor="rgba(10, 10, 15, 0.85)",
        bordercolor=COLORS["grid"],
        borderwidth=1,
        borderpad=10,
        font={"size": 11, "family": "JetBrains Mono, Fira Code, monospace"},
    )


# ---------------------------------------------------------------------------
# Notebook detection
# ---------------------------------------------------------------------------


def _in_notebook() -> bool:
    """Heuristic: are we running inside an IPython/Jupyter kernel?"""
    try:
        from IPython import get_ipython  # type: ignore[import-untyped]

        shell = get_ipython()
        if shell is None:
            return False
        # ZMQInteractiveShell = Jupyter notebook/lab kernel
        # TerminalInteractiveShell = plain ipython — skip auto-show there
        return shell.__class__.__name__ == "ZMQInteractiveShell"
    except ImportError:
        return False


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def tearsheet(result: Any) -> go.Figure:
    """Full strategy tearsheet.

    Parameters
    ----------
    result : BacktestResult
        Any object with a ``.returns`` attribute (pd.Series of daily simple
        returns). Optionally may have ``.benchmark_returns`` (pd.Series),
        ``.name`` (str), and ``.trades`` (pd.DataFrame).

    Returns
    -------
    go.Figure
        Multi-panel figure with:

        1. Equity curve (strategy vs benchmark if available)
        2. Drawdown chart
        3. Monthly returns heatmap
        4. Key metrics annotation block (Sharpe, Sortino, Max DD, etc.)

    Notes
    -----
    Auto-calls ``fig.show()`` when running inside a Jupyter notebook so the
    tearsheet renders immediately on cell execution.
    """
    _require_plotly()

    if not isinstance(result, _BacktestLike):
        raise TypeError(
            f"tearsheet() expects an object with a .returns attribute, "
            f"got {type(result).__name__}"
        )

    returns: pd.Series = result.returns
    benchmark_returns: pd.Series | None = _get_attr(result, "benchmark_returns")
    strategy_name: str = _get_attr(result, "name", "Strategy")

    # Compute metrics
    metrics = _compute_metrics(returns)

    # Monthly matrix to size the heatmap rows
    monthly_matrix = _build_monthly_matrix(returns)
    n_years = len(monthly_matrix.index)

    # Row height ratios: equity gets the most, drawdown second, heatmap scales with data
    heatmap_weight = max(0.25, min(0.4, n_years * 0.06))
    equity_weight = 0.45
    dd_weight = 1.0 - equity_weight - heatmap_weight

    fig = make_subplots(
        rows=3,
        cols=1,
        shared_xaxes=False,
        vertical_spacing=0.08,
        row_heights=[equity_weight, dd_weight, heatmap_weight],
        subplot_titles=[
            f"{strategy_name} — Equity Curve",
            "Drawdown",
            "Monthly Returns",
        ],
    )

    # --- Build subplots ------------------------------------------------------
    _add_equity_curve(fig, returns, benchmark_returns, row=1, col=1)
    _add_drawdown(fig, returns, row=2, col=1)
    _add_monthly_heatmap(fig, returns, row=3, col=1)
    _add_metrics_annotation(fig, metrics, row=1, col=1)

    # --- Axis formatting -----------------------------------------------------
    # Equity curve
    fig.update_yaxes(title_text="Cumulative Return", row=1, col=1, tickformat=".2f")
    fig.update_xaxes(showticklabels=False, row=1, col=1)

    # Drawdown
    fig.update_yaxes(title_text="Drawdown", row=2, col=1, tickformat=".0%")
    fig.update_xaxes(showticklabels=True, row=2, col=1)

    # Heatmap
    fig.update_yaxes(autorange="reversed", dtick=1, row=3, col=1)
    fig.update_xaxes(side="top", dtick=1, row=3, col=1)

    # --- Global layout -------------------------------------------------------
    total_height = 380 + 180 + max(120, n_years * 36)
    fig.update_layout(
        height=total_height,
        width=960,
        showlegend=True,
        legend={
            "orientation": "h",
            "yanchor": "bottom",
            "y": 1.02,
            "xanchor": "left",
            "x": 0.0,
        },
    )

    # Style subplot titles
    for annotation in fig.layout.annotations:
        annotation.update(
            font={"size": 13, "color": COLORS["text"], "family": "Inter, sans-serif"}
        )

    fig = apply_theme(fig)

    # Auto-show in notebooks
    if _in_notebook():
        fig.show()

    return fig
