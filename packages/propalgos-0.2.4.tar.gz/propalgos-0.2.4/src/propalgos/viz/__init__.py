"""PropAlgos visualization module — Plotly-based charts with dark/light themes.

Plotly is an optional dependency. Importing this module always succeeds; the
``ImportError`` is deferred to the first actual chart call so that code which
merely type-checks or imports symbols doesn't blow up in environments where
plotly is absent.

Usage::

    from propalgos.viz import tearsheet, candles, monthly_returns, heatmap, strip

    # Backtest result tearsheet (auto-shows in notebooks)
    tearsheet(result)

    # Candlestick chart with indicators
    fig = candles(prices, indicators=["sma20", "sma100", "bb20"])
    fig.show()

    # Standalone monthly returns heatmap
    fig = monthly_returns(result)
    fig.show()

    # General-purpose heatmap (e.g. RSI scanner)
    fig = heatmap(rsi_matrix, colorscale="rsi", fmt=".0f", zrange=(0, 100))
    fig.show()

    # Signal distribution strip plot
    fig = strip(data, x="timeframe", y="rsi", color="symbol",
                thresholds={"Oversold": (0, 30)})
    fig.show()

    # Switch to light mode — all subsequent charts use light palette
    set_mode("light")
"""

from __future__ import annotations

from propalgos.viz.candles import candles
from propalgos.viz.heatmaps import heatmap, monthly_returns
from propalgos.viz.strip import strip
from propalgos.viz.tearsheet import tearsheet
from propalgos.viz.theme import (
    COLORS,
    COLORSCALES,
    apply_theme,
    colors,
    colorscales,
    set_mode,
)

__all__ = [
    "apply_theme",
    "candles",
    "COLORS",
    "COLORSCALES",
    "colors",
    "colorscales",
    "heatmap",
    "monthly_returns",
    "set_mode",
    "strip",
    "tearsheet",
]
