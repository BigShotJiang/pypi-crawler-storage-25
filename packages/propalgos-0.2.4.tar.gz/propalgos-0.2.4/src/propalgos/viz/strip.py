"""Strip (jitter) plot for visualizing signal distributions across categories.

Renders a scatter-strip chart where each point is a data observation, grouped
by a categorical x-axis and colored by a grouping column. Optional horizontal
threshold bands highlight regions of interest (e.g. oversold / overbought zones).
"""

from __future__ import annotations

import pandas as pd

from propalgos.viz._compat import _require_plotly, go
from propalgos.viz.theme import ACCENT_SEQUENCE, COLORS, apply_theme

# ---------------------------------------------------------------------------
# Threshold band colors — muted fills that work on both dark and light bg.
# ---------------------------------------------------------------------------

_BAND_COLORS = [
    ("rgba(34, 197, 94, 0.08)", "rgba(34, 197, 94, 0.3)"),   # green
    ("rgba(239, 68, 68, 0.08)", "rgba(239, 68, 68, 0.3)"),   # red
    ("rgba(234, 179, 8, 0.08)", "rgba(234, 179, 8, 0.3)"),   # yellow
    ("rgba(99, 102, 241, 0.08)", "rgba(99, 102, 241, 0.3)"), # indigo
]


def strip(
    data: pd.DataFrame,
    x: str,
    y: str,
    color: str,
    thresholds: dict[str, tuple[float, float]] | None = None,
    title: str = "",
    y_range: tuple[float, float] | None = None,
) -> go.Figure:
    """Strip plot with optional threshold bands.

    Parameters
    ----------
    data : pd.DataFrame
        Long-form data. Must contain columns named by *x*, *y*, and *color*.
    x : str
        Column for the categorical x-axis (e.g. ``"timeframe"``).
    y : str
        Column for the numeric y-axis (e.g. ``"rsi"``).
    color : str
        Column for color grouping (e.g. ``"symbol"``).
    thresholds : dict[str, tuple[float, float]] | None
        Named horizontal bands rendered as shaded regions. Each entry is
        ``{label: (y0, y1)}``. Example::

            {"Oversold": (0, 30), "Overbought": (70, 100)}

    title : str
        Chart title.
    y_range : tuple[float, float] | None
        Explicit y-axis range. If ``None``, auto-determined by Plotly.

    Returns
    -------
    go.Figure
        Themed Plotly strip chart.
    """
    _require_plotly()

    for col_name, col_label in [(x, "x"), (y, "y"), (color, "color")]:
        if col_name not in data.columns:
            raise ValueError(
                f"{col_label} column {col_name!r} not found in DataFrame. "
                f"Available: {list(data.columns)}"
            )

    groups = data[color].unique()
    fig = go.Figure()

    # One trace per group — jittered along the x category
    for i, group_val in enumerate(groups):
        mask = data[color] == group_val
        subset = data.loc[mask]
        accent = ACCENT_SEQUENCE[i % len(ACCENT_SEQUENCE)]

        fig.add_trace(
            go.Box(
                x=subset[x],
                y=subset[y],
                name=str(group_val),
                boxpoints="all",
                jitter=0.6,
                pointpos=0,
                marker={"color": accent, "size": 6, "opacity": 0.8},
                line={"color": "rgba(0,0,0,0)"},
                fillcolor="rgba(0,0,0,0)",
                hoveron="points",
                hovertemplate=(
                    f"<b>{group_val}</b><br>"
                    f"{x}: %{{x}}<br>"
                    f"{y}: %{{y:.1f}}"
                    "<extra></extra>"
                ),
            )
        )

    # Threshold bands
    if thresholds:
        for i, (label, (y0, y1)) in enumerate(thresholds.items()):
            fill_color, _ = _BAND_COLORS[i % len(_BAND_COLORS)]
            fig.add_hrect(
                y0=y0,
                y1=y1,
                fillcolor=fill_color,
                line_width=0,
                annotation_text=label,
                annotation_position="top left",
                annotation_font={"color": COLORS["text_secondary"], "size": 10},
            )

    # Midpoint line (if y_range is provided, place at center)
    if y_range is not None:
        mid = (y_range[0] + y_range[1]) / 2
        fig.add_hline(
            y=mid, line_dash="dot",
            line_color=COLORS["text_secondary"], opacity=0.4,
        )

    y_axis = {"title": y}
    if y_range is not None:
        y_axis["range"] = list(y_range)

    fig.update_layout(
        title=title,
        xaxis_title=x,
        yaxis=y_axis,
        height=max(400, 24 * len(groups)),
        showlegend=True,
        legend_title=color,
        boxmode="group",
    )

    return apply_theme(fig)
