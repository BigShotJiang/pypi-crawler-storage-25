"""PropAlgos — quant research SDK.

Quick start::

    import propalgos as pa

    prices = pa.data.prices("SPY", start="2020-01-01")
    signal = pa.signals.sma_cross(prices, fast=20, slow=100)
    bt = pa.backtest.run(prices, signal)
    pa.viz.tearsheet(bt)
"""

from __future__ import annotations


def _auto_enable_cudf() -> None:
    """Activate cudf.pandas acceleration when a GPU is available.

    Must run before any pandas import. Activates when cudf.pandas is
    importable (RAPIDS env active). Does NOT require PROPALGOS_INSTANCE_ID —
    if you have RAPIDS installed, you want GPU acceleration.

    Opt out: PROPALGOS_CUDF_AUTO=0

    Sets module-level ``_CUDF_ACTIVE`` so downstream code can check.
    """
    import os
    import logging
    import warnings

    global _CUDF_ACTIVE  # noqa: PLW0603

    if os.environ.get("PROPALGOS_CUDF_AUTO", "1") == "0":
        _CUDF_ACTIVE = False
        return

    try:
        import cudf.pandas  # type: ignore[import-untyped]

        cudf.pandas.install()
        _CUDF_ACTIVE = True
    except ImportError:
        _CUDF_ACTIVE = False
        # Warn if we're on-platform without RAPIDS — this means the image is broken
        if os.environ.get("PROPALGOS_INSTANCE_ID"):
            _logger = logging.getLogger("propalgos")
            _logger.warning(
                "GPU instance detected but cudf.pandas not available. "
                "All operations will run on CPU. Check RAPIDS installation."
            )
            warnings.warn(
                "propalgos: GPU instance detected but cudf is not installed. "
                "Running on CPU — expected ~10x slower for large datasets.",
                RuntimeWarning,
                stacklevel=2,
            )
    except Exception as exc:
        _CUDF_ACTIVE = False
        _logger = logging.getLogger("propalgos")
        _logger.error("cudf.pandas.install() failed: %s. Falling back to CPU.", exc)


_CUDF_ACTIVE: bool = False
_auto_enable_cudf()

from propalgos._version import __version__


def gpu_status() -> dict:
    """Check GPU acceleration and platform status.

    Returns a dict with GPU, platform, and instance diagnostics::

        >>> import propalgos as pa
        >>> pa.gpu_status()
        {
            'cudf_active': True,
            'gpu_available': True,
            'rapids_version': '24.10',
            'device': 'NVIDIA A100-SXM4-40GB',
            'instance_id': 'i-0abc123...',
            'cloud_provider': 'aws',
            'region': 'us-east-1',
            'instance_type': 'p3.2xlarge',
            'on_platform': True,
            'python_version': '3.11.9',
            'sdk_version': '0.1.0',
            'warning': None,
        }
    """
    status: dict = {
        "cudf_active": _CUDF_ACTIVE,
        "gpu_available": False,
        "rapids_version": None,
        "device": None,
        "instance_id": None,
        "cloud_provider": None,
        "region": None,
        "instance_type": None,
        "on_platform": False,
        "python_version": None,
        "sdk_version": __version__,
        "warning": None,
    }

    # Platform / instance info
    try:
        from propalgos.env.runtime import detect_runtime
        rt = detect_runtime()
        status["instance_id"] = rt.instance_id
        status["cloud_provider"] = rt.cloud_provider
        status["region"] = rt.region
        status["instance_type"] = rt.instance_type
        status["on_platform"] = rt.on_propalgos
        status["python_version"] = rt.python_version
    except Exception:
        pass

    # GPU hardware
    try:
        from propalgos.env.gpu import detect_gpus
        gpus = detect_gpus()
        if gpus:
            status["gpu_available"] = True
            status["device"] = gpus[0].name
    except Exception:
        pass

    # cuDF version
    try:
        import cudf  # type: ignore[import-untyped]
        status["rapids_version"] = cudf.__version__
    except ImportError:
        pass

    # Generate warning
    if status["gpu_available"] and not status["cudf_active"]:
        status["warning"] = (
            "GPU detected but cudf.pandas is not active. "
            "All operations are running on CPU. "
            "Install RAPIDS or check your conda environment."
        )
    elif status["on_platform"] and not status["gpu_available"]:
        status["warning"] = (
            "On-platform but no GPU detected. "
            "Check instance type supports GPU acceleration."
        )
    elif not status["gpu_available"] and not status["cudf_active"]:
        status["warning"] = (
            "No GPU detected. Running on CPU. "
            "Expected for local development."
        )

    return status

# Submodule namespaces — imported lazily where possible, but the namespaces
# themselves are always available as `pa.data`, `pa.signals`, etc.
from propalgos import (
    backtest,
    data,
    env,
    factors,
    signals,
    viz,
)

# Top-level convenience shortcuts
from propalgos.data.prices import prices
from propalgos.backtest.engine import run as run_backtest

__all__ = [
    "__version__",
    # namespaces
    "backtest",
    "data",
    "env",
    "factors",
    "signals",
    "viz",
    # shortcuts
    "prices",
    "run_backtest",
    # diagnostics
    "gpu_status",
]
