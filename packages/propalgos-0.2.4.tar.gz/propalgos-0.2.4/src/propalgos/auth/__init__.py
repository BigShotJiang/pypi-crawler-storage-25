"""Authentication and session management.

Phase 3: CLI PKCE flow, token lifecycle, keyring integration.
"""


def __getattr__(name: str):
    raise NotImplementedError(
        f"pa.auth.{name} is not yet available — coming in v0.2. "
        "On-platform notebooks are already authenticated via the Jupyter session."
    )
