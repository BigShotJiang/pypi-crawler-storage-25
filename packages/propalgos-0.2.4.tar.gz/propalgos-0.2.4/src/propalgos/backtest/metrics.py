"""Metric computation for backtest results.

Delegates to ``propalgos.factors.performance`` and ``propalgos.factors.risk``
for individual metric functions, then assembles the full dictionary that
BacktestResult carries. No computation is duplicated here -- this module is
pure orchestration over existing factor functions.
"""

from __future__ import annotations

import pandas as pd

from propalgos.factors import performance as perf
from propalgos.factors import risk


def _alpha(
    returns: pd.Series,
    benchmark_returns: pd.Series,
    beta_value: float,
) -> float:
    """Annualized Jensen's alpha."""
    ann_strat = perf.annualized_return(returns)
    ann_bench = perf.annualized_return(benchmark_returns)
    return float(ann_strat - beta_value * ann_bench)


def compute_metrics(
    returns: pd.Series,
    benchmark_returns: pd.Series | None = None,
    num_trades: int = 0,
    trade_returns: pd.Series | None = None,
) -> dict[str, float]:
    """Compute full performance metrics dict.

    Parameters
    ----------
    returns : pd.Series
        Strategy daily returns (arithmetic).
    benchmark_returns : pd.Series | None
        Benchmark daily returns for relative metrics. Omit if no benchmark.
    num_trades : int
        Count of round-trip trades executed.
    trade_returns : pd.Series | None
        Per-trade return for each trade day (for avg_trade_return).

    Returns
    -------
    dict[str, float]
        Keys: sharpe, sortino, calmar, max_drawdown, total_return,
        annualized_return, annualized_volatility, win_rate, profit_factor,
        num_trades, avg_trade_return, and (if benchmark) beta, alpha.
    """
    metrics: dict[str, float] = {
        "sharpe": perf.sharpe(returns),
        "sortino": perf.sortino(returns),
        "calmar": perf.calmar(returns),
        "max_drawdown": risk.max_drawdown(returns),
        "total_return": perf.total_return(returns),
        "annualized_return": perf.annualized_return(returns),
        "annualized_volatility": risk.annualized_volatility(returns),
        "win_rate": perf.win_rate(returns),
        "profit_factor": perf.profit_factor(returns),
        "num_trades": float(num_trades),
    }

    if trade_returns is not None and len(trade_returns) > 0:
        metrics["avg_trade_return"] = float(trade_returns.mean())
    else:
        metrics["avg_trade_return"] = 0.0

    if benchmark_returns is not None and len(benchmark_returns) > 0:
        beta_val = risk.beta(returns, benchmark_returns)
        metrics["beta"] = beta_val
        metrics["alpha"] = _alpha(returns, benchmark_returns, beta_val)

    return metrics
