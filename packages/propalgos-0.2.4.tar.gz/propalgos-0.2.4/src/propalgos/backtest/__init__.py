"""Vectorized single-asset backtesting engine.

Usage::

    import propalgos as pa
    from propalgos.backtest import run, BacktestResult, CostModel

    result = run(prices, signal, fee_bps=5, slippage_bps=2)
    print(result.summary())
"""

from __future__ import annotations

from propalgos.backtest.costs import CostModel
from propalgos.backtest.engine import run
from propalgos.backtest.results import BacktestResult

__all__ = [
    "BacktestResult",
    "CostModel",
    "run",
]
