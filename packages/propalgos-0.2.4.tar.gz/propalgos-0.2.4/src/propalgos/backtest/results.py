"""BacktestResult -- immutable container for backtest output.

All heavy computation happens upstream in the engine and metrics modules.
This module is a pure data holder with formatting and serialization helpers.
"""

from __future__ import annotations

import json
from dataclasses import dataclass

import pandas as pd

from propalgos.backtest.costs import CostModel


def _series_to_str_dict(s: pd.Series) -> dict[str, object]:
    """Convert a Series to {str(key): value} for JSON-safe dict keys."""
    return {str(k): v for k, v in s.to_dict().items()}


@dataclass(frozen=True)
class BacktestResult:
    """Immutable snapshot of a completed backtest.

    Attributes
    ----------
    equity_curve : pd.Series
        Dollar equity indexed by date.
    returns : pd.Series
        Daily simple returns of the strategy.
    positions : pd.Series
        Position at each bar (-1, 0, or 1).
    trades : pd.DataFrame
        One row per position change. Columns: date, direction, price, cost.
    drawdowns : pd.Series
        Peak-to-trough drawdown fraction at each bar (non-positive).
    benchmark_equity : pd.Series | None
        Benchmark equity curve, if a benchmark was supplied.
    benchmark_returns : pd.Series | None
        Benchmark daily returns, if a benchmark was supplied.
    metrics : dict[str, float]
        Computed performance metrics (sharpe, sortino, etc.).
    initial_cash : float
        Starting capital.
    cost_model : CostModel
        Fee/slippage assumptions used.
    """

    equity_curve: pd.Series
    returns: pd.Series
    positions: pd.Series
    trades: pd.DataFrame
    drawdowns: pd.Series
    benchmark_equity: pd.Series | None
    benchmark_returns: pd.Series | None
    metrics: dict[str, float]
    initial_cash: float
    cost_model: CostModel

    # ------------------------------------------------------------------
    # Serialization
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        """Convert to a plain dict suitable for JSON-like consumers.

        Series/DataFrames are represented as ``{str(index): value}`` dicts
        so that Timestamp keys become ISO date strings.
        """
        result: dict = {
            "equity_curve": _series_to_str_dict(self.equity_curve),
            "returns": _series_to_str_dict(self.returns),
            "positions": _series_to_str_dict(self.positions),
            "trades": self.trades.to_dict(orient="records"),
            "drawdowns": _series_to_str_dict(self.drawdowns),
            "metrics": self.metrics,
            "initial_cash": self.initial_cash,
            "cost_model": {
                "fee_bps": self.cost_model.fee_bps,
                "slippage_bps": self.cost_model.slippage_bps,
            },
        }
        if self.benchmark_equity is not None:
            result["benchmark_equity"] = _series_to_str_dict(self.benchmark_equity)
        if self.benchmark_returns is not None:
            result["benchmark_returns"] = _series_to_str_dict(self.benchmark_returns)
        return result

    def to_json(self) -> str:
        """Serialize to a JSON string with ISO-formatted date keys."""
        return json.dumps(self.to_dict(), default=str, indent=2)

    # ------------------------------------------------------------------
    # Display
    # ------------------------------------------------------------------

    def summary(self) -> str:
        """Return a formatted text summary of key metrics."""
        lines = [
            "=" * 52,
            "  Backtest Summary",
            "=" * 52,
            f"  Initial capital     : ${self.initial_cash:>14,.2f}",
            f"  Final equity        : ${self.equity_curve.iloc[-1]:>14,.2f}",
            f"  Total return        : {self.metrics['total_return']:>14.2%}",
            f"  Annualized return   : {self.metrics['annualized_return']:>14.2%}",
            f"  Annualized vol      : {self.metrics['annualized_volatility']:>14.2%}",
            "-" * 52,
            f"  Sharpe              : {self.metrics['sharpe']:>14.3f}",
            f"  Sortino             : {self.metrics['sortino']:>14.3f}",
            f"  Calmar              : {self.metrics['calmar']:>14.3f}",
            f"  Max drawdown        : {self.metrics['max_drawdown']:>14.2%}",
            "-" * 52,
            f"  Trades              : {int(self.metrics['num_trades']):>14d}",
            f"  Win rate            : {self.metrics['win_rate']:>14.2%}",
            f"  Profit factor       : {self.metrics['profit_factor']:>14.3f}",
            f"  Avg trade return    : {self.metrics['avg_trade_return']:>14.4%}",
            "-" * 52,
            f"  Costs (fee bps)     : {self.cost_model.fee_bps:>14.1f}",
            f"  Costs (slip bps)    : {self.cost_model.slippage_bps:>14.1f}",
        ]

        if "beta" in self.metrics:
            lines.extend([
                "-" * 52,
                f"  Beta                : {self.metrics['beta']:>14.3f}",
                f"  Alpha               : {self.metrics['alpha']:>14.4f}",
            ])

        lines.append("=" * 52)
        return "\n".join(lines)
