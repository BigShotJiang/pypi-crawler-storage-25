"""Transaction cost models for backtesting.

CostModel is a frozen dataclass describing fee + slippage assumptions.
Its ``apply`` method is a pure vectorized transform over a trade-value series.
"""

from __future__ import annotations

from dataclasses import dataclass

import pandas as pd


@dataclass(frozen=True)
class CostModel:
    """Immutable transaction cost specification.

    Parameters
    ----------
    fee_bps : float
        Round-trip brokerage/exchange fee in basis points (e.g. 5.0 = 0.05%).
    slippage_bps : float
        Estimated market-impact slippage in basis points.
    """

    fee_bps: float = 0.0
    slippage_bps: float = 0.0

    def apply(self, trade_value: pd.Series) -> pd.Series:
        """Return total dollar cost for each trade.

        Parameters
        ----------
        trade_value : pd.Series
            Absolute notional value of each position change.

        Returns
        -------
        pd.Series
            Non-negative cost series, same index as *trade_value*.
        """
        rate = (self.fee_bps + self.slippage_bps) / 10_000
        return trade_value.abs() * rate
