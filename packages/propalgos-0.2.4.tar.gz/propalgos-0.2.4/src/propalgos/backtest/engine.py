"""Vectorized single-asset backtesting engine.

The entire simulation is expressed as numpy/pandas array operations -- no
row-by-row iteration. Given a price series and a signal series of {-1, 0, 1},
the engine produces a fully-populated BacktestResult in a single forward pass.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from propalgos.backtest.costs import CostModel
from propalgos.backtest.metrics import compute_metrics
from propalgos.backtest.results import BacktestResult
from propalgos.exceptions import BacktestError
from propalgos.factors import risk


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------

def _validate_inputs(
    prices: pd.DataFrame,
    signal: pd.Series,
) -> tuple[pd.Series, pd.Series]:
    """Extract close prices and validate alignment with signal.

    Returns (close, signal) with matching indices.
    """
    if prices.empty:
        raise BacktestError("prices DataFrame is empty")

    if "close" not in prices.columns:
        raise BacktestError(
            f"prices must contain a 'close' column, found: {list(prices.columns)}"
        )

    close = prices["close"]

    if signal.empty:
        raise BacktestError("signal series is empty")

    # Align on shared index
    shared_idx = close.index.intersection(signal.index)
    if len(shared_idx) == 0:
        raise BacktestError(
            "prices and signal share no common index values -- "
            "check that both use the same date index"
        )

    close = close.loc[shared_idx]
    signal = signal.loc[shared_idx]

    # Validate signal domain
    unique_vals = set(signal.dropna().unique())
    allowed = {-1, 0, 1, -1.0, 0.0, 1.0, np.int64(-1), np.int64(0), np.int64(1)}
    invalid = unique_vals - allowed
    if invalid:
        raise BacktestError(
            f"signal must contain only {{-1, 0, 1}}, found extra values: {invalid}"
        )

    return close, signal.astype(int)


# ---------------------------------------------------------------------------
# Benchmark resolution
# ---------------------------------------------------------------------------

def _resolve_benchmark(
    benchmark: pd.DataFrame | pd.Series | str | None,
    index: pd.DatetimeIndex,
) -> pd.Series | None:
    """Resolve a benchmark argument into a daily-return series aligned to *index*.

    - str  -> fetch via ``propalgos.data.prices`` (lazy import)
    - DataFrame -> extract 'close' column, compute pct_change
    - Series -> use directly (assumed to be returns already)
    - None -> no benchmark
    """
    if benchmark is None:
        return None

    if isinstance(benchmark, str):
        try:
            import propalgos.data.prices as data_mod  # type: ignore[import-untyped]
            bench_prices = data_mod.prices(benchmark)
            bench_close = bench_prices["close"]
            bench_returns = bench_close.pct_change().fillna(0.0)
        except (ImportError, AttributeError) as exc:
            raise BacktestError(
                f"cannot fetch benchmark '{benchmark}' -- propalgos.data.prices "
                f"is not available: {exc}"
            ) from exc
    elif isinstance(benchmark, pd.DataFrame):
        if "close" not in benchmark.columns:
            raise BacktestError(
                "benchmark DataFrame must contain a 'close' column"
            )
        bench_returns = benchmark["close"].pct_change().fillna(0.0)
    elif isinstance(benchmark, pd.Series):
        bench_returns = benchmark
    else:
        raise BacktestError(
            f"benchmark must be a str, DataFrame, Series, or None -- got {type(benchmark)}"
        )

    # Align to the strategy's index
    bench_returns = bench_returns.reindex(index).fillna(0.0)
    return bench_returns


# ---------------------------------------------------------------------------
# Trade extraction
# ---------------------------------------------------------------------------

def _build_trades(
    position: pd.Series,
    close: pd.Series,
    cost_series: pd.Series,
    trade_mask: pd.Series,
) -> pd.DataFrame:
    """Build a trades DataFrame from position changes.

    Columns: date, direction, price, cost.
    """
    trade_dates = position.index[trade_mask]
    if len(trade_dates) == 0:
        return pd.DataFrame(columns=["date", "direction", "price", "cost"])

    pos_diff = position.diff().fillna(0.0)
    # Vectorized direction mapping — avoids lambda in apply() which breaks cuDF
    trade_diff = pos_diff.loc[trade_dates]
    directions = pd.Series("flat", index=trade_diff.index)
    directions[trade_diff > 0] = "long"
    directions[trade_diff < 0] = "short"

    return pd.DataFrame({
        "date": trade_dates,
        "direction": directions.values,
        "price": close.loc[trade_dates].values,
        "cost": cost_series.loc[trade_dates].values,
    })


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run(
    prices: pd.DataFrame,
    signal: pd.Series,
    initial_cash: float = 100_000.0,
    fee_bps: float = 0.0,
    slippage_bps: float = 0.0,
    benchmark: pd.DataFrame | pd.Series | str | None = None,
) -> BacktestResult:
    """Run a vectorized single-asset backtest.

    Parameters
    ----------
    prices : pd.DataFrame
        OHLCV DataFrame. Must contain a ``close`` column with a
        DatetimeIndex (or any monotonic index).
    signal : pd.Series
        Integer signal in {-1, 0, 1} aligned to the same index.
        +1 = long, -1 = short, 0 = flat.
    initial_cash : float
        Starting capital in dollars.
    fee_bps : float
        Round-trip brokerage fee in basis points.
    slippage_bps : float
        Estimated slippage in basis points.
    benchmark : DataFrame | Series | str | None
        Optional benchmark. A string ticker (e.g. ``"SPY"``) will be fetched
        via ``propalgos.data.prices``. A DataFrame must have a ``close``
        column. A Series is treated as pre-computed returns.

    Returns
    -------
    BacktestResult
        Frozen dataclass with equity curve, returns, trades, and metrics.

    Raises
    ------
    BacktestError
        On invalid inputs (empty data, missing columns, misaligned indices).
    """
    close, signal = _validate_inputs(prices, signal)
    cost_model = CostModel(fee_bps=fee_bps, slippage_bps=slippage_bps)

    # 1. Asset returns
    asset_returns = close.pct_change().fillna(0.0)

    # 2. Position: trade on next bar after signal fires (avoid look-ahead)
    position = signal.shift(1).fillna(0).astype(int)

    # 3. Identify trade days (where position changes)
    pos_diff = position.diff().fillna(0.0)
    trade_mask = pos_diff != 0

    # 4. Compute dollar cost per trade day
    trade_notional = pos_diff.abs() * close
    cost_dollars = cost_model.apply(trade_notional)

    # 5. Build equity incrementally to compute proportional cost
    #    strategy_return_t = position_t * asset_return_t - cost_t / equity_{t-1}
    #    We approximate equity_{t-1} using the cumulative product up to t-1.
    #    First pass: gross returns (no costs) to get approximate equity for cost scaling.
    gross_returns = position * asset_returns
    gross_equity = initial_cash * (1 + gross_returns).cumprod()

    # Lagged equity for cost denominator (shift forward; first bar uses initial_cash)
    lagged_equity = gross_equity.shift(1).fillna(initial_cash)
    trade_cost_pct = cost_dollars / lagged_equity
    trade_cost_pct = trade_cost_pct.fillna(0.0)

    # 6. Net strategy returns
    strategy_returns = position * asset_returns - trade_cost_pct

    # 7. Equity curve
    equity_curve = initial_cash * (1 + strategy_returns).cumprod()
    equity_curve.name = "equity"

    # 8. Drawdowns (risk.drawdown_series operates on returns, equivalent to
    #    equity / cummax(equity) - 1 since equity = cash * cumprod(1 + r))
    drawdowns = risk.drawdown_series(strategy_returns)
    drawdowns.name = "drawdown"

    # 9. Trades DataFrame
    trades = _build_trades(position, close, cost_dollars, trade_mask)
    num_trades = len(trades)

    # 10. Trade-day returns for avg_trade_return metric
    trade_returns = strategy_returns[trade_mask] if trade_mask.any() else pd.Series(dtype=float)

    # 11. Benchmark
    bench_returns = _resolve_benchmark(benchmark, close.index)
    bench_equity: pd.Series | None = None
    if bench_returns is not None:
        bench_equity = initial_cash * (1 + bench_returns).cumprod()
        bench_equity.name = "benchmark_equity"

    # 12. Metrics
    metrics = compute_metrics(
        returns=strategy_returns,
        benchmark_returns=bench_returns,
        num_trades=num_trades,
        trade_returns=trade_returns,
    )

    return BacktestResult(
        equity_curve=equity_curve,
        returns=strategy_returns,
        positions=position,
        trades=trades,
        drawdowns=drawdowns,
        benchmark_equity=bench_equity,
        benchmark_returns=bench_returns,
        metrics=metrics,
        initial_cash=initial_cash,
        cost_model=cost_model,
    )
