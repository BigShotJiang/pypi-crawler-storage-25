"""Test the vectorized backtest engine."""

from __future__ import annotations

import pandas as pd
import pytest

from propalgos.backtest import run, BacktestResult, CostModel
from propalgos import signals


class TestBacktestRun:
    def test_basic_run(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        result = run(sample_prices, sig, initial_cash=100_000)

        assert isinstance(result, BacktestResult)
        assert len(result.equity_curve) == len(sample_prices)
        assert len(result.returns) == len(sample_prices)
        assert len(result.positions) == len(sample_prices)
        assert len(result.drawdowns) == len(sample_prices)

    def test_equity_starts_at_initial_cash(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        result = run(sample_prices, sig, initial_cash=50_000)
        assert result.equity_curve.iloc[0] == pytest.approx(50_000, rel=0.01)

    def test_costs_reduce_equity(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        no_cost = run(sample_prices, sig, initial_cash=100_000, fee_bps=0, slippage_bps=0)
        with_cost = run(sample_prices, sig, initial_cash=100_000, fee_bps=10, slippage_bps=5)

        assert with_cost.equity_curve.iloc[-1] <= no_cost.equity_curve.iloc[-1]

    def test_metrics_are_populated(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        result = run(sample_prices, sig)

        required_keys = [
            "sharpe", "sortino", "calmar", "max_drawdown", "total_return",
            "annualized_return", "annualized_volatility", "win_rate",
            "profit_factor", "num_trades",
        ]
        for key in required_keys:
            assert key in result.metrics, f"metric '{key}' missing"
            assert isinstance(result.metrics[key], float), f"metric '{key}' is not float"

    def test_flat_signal_no_trades(self, sample_prices: pd.DataFrame):
        flat_signal = pd.Series(0, index=sample_prices.index, dtype=int)
        result = run(sample_prices, flat_signal)
        assert result.equity_curve.iloc[-1] == pytest.approx(100_000, rel=1e-10)
        assert len(result.trades) == 0

    def test_positions_are_shifted(self, sample_prices: pd.DataFrame):
        """Signal on day t should produce a position on day t+1 (no look-ahead)."""
        sig = pd.Series(0, index=sample_prices.index, dtype=int)
        sig.iloc[10] = 1  # Signal fires on bar 10
        result = run(sample_prices, sig)
        # Position should be 0 at bar 10, 1 at bar 11
        assert result.positions.iloc[10] == 0
        assert result.positions.iloc[11] == 1


class TestBacktestResult:
    def test_to_dict(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        result = run(sample_prices, sig)
        d = result.to_dict()
        assert "equity_curve" in d
        assert "metrics" in d
        assert "trades" in d

    def test_to_json(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        result = run(sample_prices, sig)
        j = result.to_json()
        assert isinstance(j, str)
        assert "sharpe" in j

    def test_summary(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        result = run(sample_prices, sig)
        s = result.summary()
        assert "Sharpe" in s
        assert "Max drawdown" in s


class TestCostModel:
    def test_zero_cost(self):
        model = CostModel(fee_bps=0, slippage_bps=0)
        values = pd.Series([1000, 2000, 500])
        costs = model.apply(values)
        assert (costs == 0).all()

    def test_nonzero_cost(self):
        model = CostModel(fee_bps=10, slippage_bps=5)
        values = pd.Series([10_000.0])
        costs = model.apply(values)
        # (10 + 5) / 10000 * 10000 = 15.0
        assert costs.iloc[0] == pytest.approx(15.0)


class TestInvalidInputs:
    def test_missing_close(self):
        df = pd.DataFrame({"price": [1, 2, 3]})
        sig = pd.Series([0, 1, 0])
        with pytest.raises(Exception):
            run(df, sig)

    def test_empty_data(self):
        df = pd.DataFrame({"close": pd.Series(dtype=float)})
        sig = pd.Series(dtype=int)
        with pytest.raises(Exception):
            run(df, sig)
