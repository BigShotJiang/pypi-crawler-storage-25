"""Tests for propalgos.data — schemas, crypto provider, registry, loader, composite."""

from __future__ import annotations

import os
import shutil
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest

from propalgos.data.schemas import OHLCV_COLUMNS, PriceRequest
from propalgos.exceptions import DataError


# ---------------------------------------------------------------------------
# PriceRequest validation
# ---------------------------------------------------------------------------


class TestPriceRequest:
    def test_single_symbol_coerced_to_list(self):
        req = PriceRequest(symbols="btcusd")
        assert req.symbols == ["BTCUSD"]

    def test_multi_symbol(self):
        req = PriceRequest(symbols=["aapl", " msft "])
        assert req.symbols == ["AAPL", "MSFT"]

    def test_empty_symbols_rejected(self):
        with pytest.raises(ValueError, match="at least one ticker"):
            PriceRequest(symbols=[])

    def test_empty_string_symbol_rejected(self):
        with pytest.raises(ValueError, match="cannot be an empty string"):
            PriceRequest(symbols=[""])

    def test_arbitrary_interval_accepted(self):
        req = PriceRequest(symbols="SPY", interval="4h")
        assert req.interval == "4h"

    def test_blank_interval_rejected(self):
        with pytest.raises(ValueError, match="non-empty"):
            PriceRequest(symbols="SPY", interval="  ")

    def test_defaults(self):
        req = PriceRequest(symbols="ETH")
        assert req.start is None
        assert req.end is None
        assert req.interval == "1d"


# ---------------------------------------------------------------------------
# CryptoParquetProvider with test fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def crypto_data_dir(tmp_path: Path) -> Path:
    """Create a minimal consolidated parquet directory for testing."""
    consolidated = tmp_path / "crypto" / "testex" / "consolidated"
    consolidated.mkdir(parents=True)

    rng = np.random.default_rng(99)
    n = 50
    timestamps = pd.date_range("2025-01-01", periods=n, freq="D", tz="UTC")

    for pair in ["BTCUSD", "ETHUSD"]:
        base = 50000.0 if pair == "BTCUSD" else 3000.0
        close = base + rng.standard_normal(n).cumsum() * 100
        df_pair = pd.DataFrame({
            "timestamp": timestamps,
            "symbol": pair,
            "open": close * (1 + rng.uniform(-0.01, 0.01, n)),
            "high": close * 1.01,
            "low": close * 0.99,
            "close": close,
            "volume": rng.integers(100, 10000, n).astype(float),
        })
        if pair == "BTCUSD":
            combined = df_pair
        else:
            combined = pd.concat([combined, df_pair], ignore_index=True)

    combined.to_parquet(consolidated / "testex_1440.parquet", index=False)
    combined.to_parquet(consolidated / "testex_60.parquet", index=False)
    return tmp_path


class TestCryptoParquetProvider:
    def test_fetch_single_symbol(self, crypto_data_dir: Path):
        from propalgos.data.crypto import CryptoParquetProvider

        provider = CryptoParquetProvider(
            "testex",
            data_dir=str(crypto_data_dir / "crypto" / "testex" / "consolidated"),
        )
        df = provider.fetch_prices("BTCUSD", start=None, end=None, interval="1d")
        assert "close" in df.columns
        assert len(df) == 50

    def test_fetch_multi_symbol(self, crypto_data_dir: Path):
        from propalgos.data.crypto import CryptoParquetProvider

        provider = CryptoParquetProvider(
            "testex",
            data_dir=str(crypto_data_dir / "crypto" / "testex" / "consolidated"),
        )
        df = provider.fetch_prices(
            ["BTCUSD", "ETHUSD"], start=None, end=None, interval="1d"
        )
        assert isinstance(df.columns, pd.MultiIndex)
        assert "BTCUSD" in df.columns.get_level_values(0)
        assert "ETHUSD" in df.columns.get_level_values(0)

    def test_date_range_filter(self, crypto_data_dir: Path):
        from propalgos.data.crypto import CryptoParquetProvider

        provider = CryptoParquetProvider(
            "testex",
            data_dir=str(crypto_data_dir / "crypto" / "testex" / "consolidated"),
        )
        df = provider.fetch_prices(
            "BTCUSD", start="2025-01-10", end="2025-01-20", interval="1d"
        )
        assert len(df) == 10

    def test_invalid_interval_raises(self, crypto_data_dir: Path):
        from propalgos.data.crypto import CryptoParquetProvider

        provider = CryptoParquetProvider(
            "testex",
            data_dir=str(crypto_data_dir / "crypto" / "testex" / "consolidated"),
        )
        with pytest.raises(DataError, match="not available"):
            provider.fetch_prices("BTCUSD", start=None, end=None, interval="3h")

    def test_unknown_symbol_raises(self, crypto_data_dir: Path):
        from propalgos.data.crypto import CryptoParquetProvider

        provider = CryptoParquetProvider(
            "testex",
            data_dir=str(crypto_data_dir / "crypto" / "testex" / "consolidated"),
        )
        with pytest.raises(DataError, match="no data for"):
            provider.fetch_prices("DOGEUSD", start=None, end=None, interval="1d")

    def test_available_symbols(self, crypto_data_dir: Path):
        from propalgos.data.crypto import CryptoParquetProvider

        provider = CryptoParquetProvider(
            "testex",
            data_dir=str(crypto_data_dir / "crypto" / "testex" / "consolidated"),
        )
        symbols = provider.available_symbols("1d")
        assert "BTCUSD" in symbols
        assert "ETHUSD" in symbols


# ---------------------------------------------------------------------------
# CryptoCompositeProvider fallthrough
# ---------------------------------------------------------------------------


class TestCryptoCompositeProvider:
    def test_fallthrough_to_second_exchange(self, crypto_data_dir: Path):
        """First exchange raises DataError, second succeeds."""
        from propalgos.data.crypto import CryptoCompositeProvider, CryptoParquetProvider

        # Create a second exchange dir with only SOLUSD
        consolidated2 = crypto_data_dir / "crypto" / "testex2" / "consolidated"
        consolidated2.mkdir(parents=True)
        rng = np.random.default_rng(7)
        n = 30
        ts = pd.date_range("2025-01-01", periods=n, freq="D", tz="UTC")
        df2 = pd.DataFrame({
            "timestamp": ts,
            "symbol": "SOLUSD",
            "open": rng.uniform(100, 200, n),
            "high": rng.uniform(100, 200, n),
            "low": rng.uniform(100, 200, n),
            "close": rng.uniform(100, 200, n),
            "volume": rng.integers(100, 1000, n).astype(float),
        })
        df2.to_parquet(consolidated2 / "testex2_1440.parquet", index=False)

        # Patch _resolve_data_dir to accept our test dirs
        real_dir = str(crypto_data_dir / "crypto" / "testex" / "consolidated")
        real_dir2 = str(crypto_data_dir / "crypto" / "testex2" / "consolidated")

        p1 = CryptoParquetProvider("testex", data_dir=real_dir)
        p2 = CryptoParquetProvider("testex2", data_dir=real_dir2)

        composite = CryptoCompositeProvider.__new__(CryptoCompositeProvider)
        composite._providers = [p1, p2]
        composite._exchange_names = ["testex", "testex2"]

        # BTCUSD is on testex (first), SOLUSD is on testex2 (second)
        btc = composite.fetch_prices("BTCUSD", None, None, "1d")
        assert "close" in btc.columns

        sol = composite.fetch_prices("SOLUSD", None, None, "1d")
        assert "close" in sol.columns

    def test_all_fail_raises(self, crypto_data_dir: Path):
        from propalgos.data.crypto import CryptoCompositeProvider, CryptoParquetProvider

        real_dir = str(crypto_data_dir / "crypto" / "testex" / "consolidated")
        p1 = CryptoParquetProvider("testex", data_dir=real_dir)

        composite = CryptoCompositeProvider.__new__(CryptoCompositeProvider)
        composite._providers = [p1]
        composite._exchange_names = ["testex"]

        with pytest.raises(DataError, match="not found on any exchange"):
            composite.fetch_prices("NOSYMBOL", None, None, "1d")


# ---------------------------------------------------------------------------
# Registry discovery
# ---------------------------------------------------------------------------


class TestRegistry:
    def test_list_datasets_with_fixture(self, crypto_data_dir: Path):
        from propalgos.data import registry

        # Reset module cache
        registry._datasets_cache = None

        with patch.dict(os.environ, {"PROPALGOS_DATASETS_DIR": str(crypto_data_dir)}):
            datasets = registry.list_datasets()

        assert len(datasets) >= 1
        ds = datasets[0]
        assert ds["exchange"] == "testex"
        assert ds["category"] == "crypto"
        assert "1d" in ds["timeframes"]

        # Clean up cache
        registry._datasets_cache = None

    def test_list_datasets_empty_dir(self, tmp_path: Path):
        from propalgos.data import registry

        registry._datasets_cache = None

        with patch.dict(os.environ, {"PROPALGOS_DATASETS_DIR": str(tmp_path)}):
            datasets = registry.list_datasets()

        assert datasets == []
        registry._datasets_cache = None


# ---------------------------------------------------------------------------
# Stage-to-local staleness check
# ---------------------------------------------------------------------------


class TestStaleness:
    def test_stale_when_size_differs(self, tmp_path: Path):
        from propalgos.data.staging import is_stale

        src = tmp_path / "source.parquet"
        loc = tmp_path / "local.parquet"
        src.write_bytes(b"x" * 100)
        loc.write_bytes(b"x" * 50)
        assert is_stale(src, loc) is True

    def test_not_stale_when_identical(self, tmp_path: Path):
        from propalgos.data.staging import is_stale

        src = tmp_path / "source.parquet"
        loc = tmp_path / "local.parquet"
        src.write_bytes(b"x" * 100)
        shutil.copy2(src, loc)
        assert is_stale(src, loc) is False

    def test_stale_when_local_missing(self, tmp_path: Path):
        from propalgos.data.staging import is_stale

        src = tmp_path / "source.parquet"
        loc = tmp_path / "local.parquet"
        src.write_bytes(b"x" * 100)
        assert is_stale(src, loc) is True

    def test_resolve_stage_dir_env_override(self, tmp_path: Path):
        from propalgos.data.staging import resolve_stage_dir

        with patch.dict(os.environ, {"PROPALGOS_DATA_STAGE_DIR": str(tmp_path / "custom")}):
            result = resolve_stage_dir()
        assert result == tmp_path / "custom"

    def test_resolve_stage_dir_fallback(self):
        from propalgos.data.staging import resolve_stage_dir

        with patch.dict(os.environ, {}, clear=True):
            result = resolve_stage_dir()
        # Should return either platform path or home cache
        assert ".propalgos_staged" in str(result) or "staged" in str(result)


# ---------------------------------------------------------------------------
# Loader (pa.data.load)
# ---------------------------------------------------------------------------


class TestLoader:
    def test_load_valid_dataset(self, crypto_data_dir: Path):
        from propalgos.data import loader

        # Clear module cache
        loader._cache.clear()

        with patch.dict(os.environ, {
            "PROPALGOS_DATASETS_DIR": str(crypto_data_dir),
            "PROPALGOS_DATA_STAGE_DIR": str(crypto_data_dir / "_stage"),
        }):
            df = loader.load("crypto-testex", interval="1d")

        assert "symbol" in df.columns
        assert "close" in df.columns
        assert len(df) == 100  # 50 rows × 2 symbols
        assert set(df["symbol"].unique()) == {"BTCUSD", "ETHUSD"}
        loader._cache.clear()

    def test_load_invalid_dataset_id(self):
        from propalgos.data.loader import load

        with pytest.raises(DataError, match="invalid dataset_id"):
            load("bad")

    def test_load_missing_interval(self, crypto_data_dir: Path):
        from propalgos.data import loader

        loader._cache.clear()

        with patch.dict(os.environ, {
            "PROPALGOS_DATASETS_DIR": str(crypto_data_dir),
            "PROPALGOS_DATA_STAGE_DIR": str(crypto_data_dir / "_stage"),
        }):
            with pytest.raises(DataError, match="not found"):
                loader.load("crypto-testex", interval="5m")
        loader._cache.clear()

    def test_load_missing_dataset(self, crypto_data_dir: Path):
        from propalgos.data import loader

        loader._cache.clear()

        with patch.dict(os.environ, {
            "PROPALGOS_DATASETS_DIR": str(crypto_data_dir),
            "PROPALGOS_DATA_STAGE_DIR": str(crypto_data_dir / "_stage"),
        }):
            with pytest.raises(DataError, match="not found"):
                loader.load("crypto-nonexistent", interval="1d")
        loader._cache.clear()

    def test_load_parses_dataset_id(self):
        from propalgos.data.loader import _parse_dataset_id

        assert _parse_dataset_id("crypto-kraken") == ("crypto", "kraken")
        assert _parse_dataset_id("equities-sp500") == ("equities", "sp500")

        with pytest.raises(DataError):
            _parse_dataset_id("nodash")

    def test_load_uses_memory_cache(self, crypto_data_dir: Path):
        from propalgos.data import loader

        loader._cache.clear()

        with patch.dict(os.environ, {
            "PROPALGOS_DATASETS_DIR": str(crypto_data_dir),
            "PROPALGOS_DATA_STAGE_DIR": str(crypto_data_dir / "_stage"),
        }):
            df1 = loader.load("crypto-testex", interval="1d")
            df2 = loader.load("crypto-testex", interval="1d")

        # Should be the exact same object (memory cache hit)
        assert df1 is df2
        loader._cache.clear()


# ---------------------------------------------------------------------------
# Generalized registry
# ---------------------------------------------------------------------------


class TestRegistryGeneralized:
    def test_list_datasets_multiple_categories(self, crypto_data_dir: Path):
        """Verify list_datasets scans multiple category directories."""
        from propalgos.data import registry

        # Create an equities dataset alongside the existing crypto one
        equities_dir = crypto_data_dir / "equities" / "sp500" / "consolidated"
        equities_dir.mkdir(parents=True)
        rng = np.random.default_rng(42)
        n = 20
        ts = pd.date_range("2025-01-01", periods=n, freq="D", tz="UTC")
        df = pd.DataFrame({
            "timestamp": ts,
            "symbol": "AAPL",
            "open": rng.uniform(150, 160, n),
            "high": rng.uniform(160, 170, n),
            "low": rng.uniform(140, 150, n),
            "close": rng.uniform(150, 160, n),
            "volume": rng.integers(1000, 10000, n).astype(float),
        })
        df.to_parquet(equities_dir / "sp500_1440.parquet", index=False)

        registry._datasets_cache = None

        with patch.dict(os.environ, {"PROPALGOS_DATASETS_DIR": str(crypto_data_dir)}):
            datasets = registry.list_datasets()

        categories = {d["category"] for d in datasets}
        assert "crypto" in categories
        assert "equities" in categories
        assert len(datasets) >= 2
        registry._datasets_cache = None

    def test_list_datasets_backward_compat_exchange_key(self, crypto_data_dir: Path):
        """Crypto datasets should have both 'source' and 'exchange' keys."""
        from propalgos.data import registry

        registry._datasets_cache = None

        with patch.dict(os.environ, {"PROPALGOS_DATASETS_DIR": str(crypto_data_dir)}):
            datasets = registry.list_datasets()

        crypto_ds = [d for d in datasets if d["category"] == "crypto"]
        assert len(crypto_ds) >= 1
        ds = crypto_ds[0]
        assert "source" in ds
        assert "exchange" in ds
        assert ds["source"] == ds["exchange"]
        registry._datasets_cache = None

    def test_list_symbols_accepts_dataset_id(self, crypto_data_dir: Path):
        """list_symbols should accept 'crypto-testex' format."""
        from propalgos.data import registry

        registry._symbols_cache.clear()

        with patch.dict(os.environ, {"PROPALGOS_DATASETS_DIR": str(crypto_data_dir)}):
            symbols = registry.list_symbols("crypto-testex", interval="1d")

        assert "BTCUSD" in symbols
        assert "ETHUSD" in symbols
        registry._symbols_cache.clear()
