"""Test factor/metric calculations for correctness."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from propalgos import factors


class TestSharpe:
    def test_positive_returns(self, sample_returns: pd.Series):
        result = factors.sharpe(sample_returns)
        assert isinstance(result, float)

    def test_zero_volatility(self):
        flat = pd.Series([0.0] * 100)
        assert factors.sharpe(flat) == 0.0

    def test_with_risk_free(self, sample_returns: pd.Series):
        with_rf = factors.sharpe(sample_returns, rf=0.05)
        without_rf = factors.sharpe(sample_returns, rf=0.0)
        assert with_rf < without_rf


class TestSortino:
    def test_basic(self, sample_returns: pd.Series):
        result = factors.sortino(sample_returns)
        assert isinstance(result, float)

    def test_no_downside(self):
        positive_only = pd.Series([0.01, 0.02, 0.005, 0.01])
        assert factors.sortino(positive_only) == 0.0  # no negative returns


class TestMaxDrawdown:
    def test_basic(self, sample_returns: pd.Series):
        result = factors.max_drawdown(sample_returns)
        assert result <= 0.0, "max drawdown should be non-positive"

    def test_all_positive(self):
        # Monotonically increasing: no drawdown
        rets = pd.Series([0.01] * 50)
        assert factors.max_drawdown(rets) == 0.0

    def test_known_drawdown(self):
        # 50% drop: returns that go 1.0 -> 0.5 -> 0.5
        rets = pd.Series([0.0, -0.5, 0.0])
        dd = factors.max_drawdown(rets)
        assert dd == pytest.approx(-0.5, abs=1e-10)


class TestDrawdownSeries:
    def test_shape(self, sample_returns: pd.Series):
        dd = factors.drawdown_series(sample_returns)
        assert len(dd) == len(sample_returns)
        assert (dd <= 0).all(), "drawdown series should be non-positive"


class TestRollingVolatility:
    def test_shape(self, sample_returns: pd.Series):
        vol = factors.rolling_volatility(sample_returns, window=21)
        assert len(vol) == len(sample_returns)
        # First 20 values should be NaN
        assert vol.iloc[:20].isna().all()


class TestBeta:
    def test_against_self(self, sample_returns: pd.Series):
        # Beta of a series against itself should be ~1.0
        b = factors.beta(sample_returns, sample_returns)
        assert b == pytest.approx(1.0, abs=1e-10)

    def test_against_zero(self, sample_returns: pd.Series):
        zero_bench = pd.Series(0.0, index=sample_returns.index)
        # Beta against zero-variance benchmark should be 0
        assert factors.beta(sample_returns, zero_bench) == 0.0


class TestVaR:
    def test_basic(self, sample_returns: pd.Series):
        result = factors.var(sample_returns, confidence=0.95)
        assert isinstance(result, float)
        assert result < 0, "VaR should be negative for typical return series"

    def test_empty(self):
        assert factors.var(pd.Series(dtype=float)) == 0.0


class TestCVaR:
    def test_basic(self, sample_returns: pd.Series):
        result = factors.cvar(sample_returns, confidence=0.95)
        assert isinstance(result, float)
        # CVaR should be <= VaR (more extreme)
        var_val = factors.var(sample_returns, confidence=0.95)
        assert result <= var_val


class TestPerformanceMetrics:
    def test_total_return(self, sample_returns: pd.Series):
        result = factors.total_return(sample_returns)
        assert isinstance(result, float)

    def test_annualized_return(self, sample_returns: pd.Series):
        result = factors.annualized_return(sample_returns)
        assert isinstance(result, float)

    def test_win_rate(self, sample_returns: pd.Series):
        result = factors.win_rate(sample_returns)
        assert 0.0 <= result <= 1.0

    def test_profit_factor(self, sample_returns: pd.Series):
        result = factors.profit_factor(sample_returns)
        assert isinstance(result, float)
        assert result >= 0

    def test_calmar(self, sample_returns: pd.Series):
        result = factors.calmar(sample_returns)
        assert isinstance(result, float)

    def test_annualized_volatility(self, sample_returns: pd.Series):
        result = factors.annualized_volatility(sample_returns)
        assert result >= 0
