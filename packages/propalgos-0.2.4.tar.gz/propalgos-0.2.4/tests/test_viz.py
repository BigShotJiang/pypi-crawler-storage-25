"""Tests for the viz module — heatmap, strip, theme modes, colorscales."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from propalgos.viz.theme import (
    COLORS,
    COLORSCALES,
    _DARK,
    _LIGHT,
    colors,
    colorscales,
    set_mode,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _reset_theme():
    """Ensure every test starts in dark mode and restores it afterward."""
    set_mode("dark")
    yield
    set_mode("dark")


@pytest.fixture
def rsi_matrix() -> pd.DataFrame:
    """Small RSI-like matrix: symbols x timeframes."""
    return pd.DataFrame(
        {
            "1m": [25.0, 72.0, 50.0],
            "5m": [31.0, 68.0, 45.0],
            "15m": [28.0, 75.0, np.nan],
        },
        index=["BTC/USD", "ETH/USD", "SOL/USD"],
    )


@pytest.fixture
def strip_data() -> pd.DataFrame:
    """Long-form data for strip plots."""
    return pd.DataFrame(
        {
            "symbol": ["BTC/USD"] * 3 + ["ETH/USD"] * 3,
            "timeframe": ["1m", "5m", "15m"] * 2,
            "rsi": [25.0, 31.0, 28.0, 72.0, 68.0, 75.0],
        }
    )


# ---------------------------------------------------------------------------
# Theme mode tests
# ---------------------------------------------------------------------------


class TestThemeMode:
    def test_default_is_dark(self):
        assert COLORS["bg"] == _DARK["bg"]
        assert COLORS["text"] == _DARK["text"]

    def test_set_light(self):
        set_mode("light")
        assert COLORS["bg"] == _LIGHT["bg"]
        assert COLORS["text"] == _LIGHT["text"]
        assert COLORS["surface"] == _LIGHT["surface"]

    def test_set_dark_restores(self):
        set_mode("light")
        set_mode("dark")
        assert COLORS["bg"] == _DARK["bg"]

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError, match="must be 'dark' or 'light'"):
            set_mode("neon")

    def test_colors_returns_same_object(self):
        assert colors() is COLORS

    def test_colorscales_returns_same_object(self):
        assert colorscales() is COLORSCALES

    def test_colorscales_update_with_mode(self):
        dark_mid = COLORSCALES["diverging"][1][1]
        set_mode("light")
        light_mid = COLORSCALES["diverging"][1][1]
        assert dark_mid != light_mid
        assert light_mid == _LIGHT["surface"]

    def test_all_dark_keys_present_in_light(self):
        assert set(_DARK.keys()) == set(_LIGHT.keys())

    def test_semantic_colors_shared(self):
        """accent, positive, negative should be similar between modes."""
        # They're not identical (light mode uses slightly darker variants)
        # but the keys are the same
        for key in ("accent", "line"):
            assert _DARK[key] == _LIGHT[key]


# ---------------------------------------------------------------------------
# General heatmap tests
# ---------------------------------------------------------------------------


class TestHeatmap:
    def test_basic_heatmap(self, rsi_matrix):
        from propalgos.viz.heatmaps import heatmap

        fig = heatmap(rsi_matrix, colorscale="rsi", fmt=".0f", zrange=(0, 100))
        assert fig is not None
        assert len(fig.data) == 1
        assert fig.data[0].type == "heatmap"

    def test_diverging_heatmap(self):
        from propalgos.viz.heatmaps import heatmap

        matrix = pd.DataFrame(
            {"A": [-0.05, 0.10], "B": [0.03, -0.02]},
            index=["2023", "2024"],
        )
        fig = heatmap(matrix, colorscale="diverging", fmt="+.1%")
        h = fig.data[0]
        assert h.zmin == pytest.approx(-h.zmax)

    def test_sequential_heatmap(self, rsi_matrix):
        from propalgos.viz.heatmaps import heatmap

        fig = heatmap(rsi_matrix, colorscale="sequential", fmt=".0f")
        assert fig.data[0].zmin is not None

    def test_custom_colorscale(self, rsi_matrix):
        from propalgos.viz.heatmaps import heatmap

        custom_cs = [[0, "blue"], [1, "red"]]
        fig = heatmap(rsi_matrix, colorscale=custom_cs, fmt=".0f", zrange=(0, 100))
        assert fig.data[0].colorscale == tuple(tuple(c) for c in custom_cs)

    def test_unknown_colorscale_raises(self, rsi_matrix):
        from propalgos.viz.heatmaps import heatmap

        with pytest.raises(ValueError, match="Unknown colorscale"):
            heatmap(rsi_matrix, colorscale="nonexistent")

    def test_heatmap_dimensions(self, rsi_matrix):
        from propalgos.viz.heatmaps import heatmap

        fig = heatmap(rsi_matrix, colorscale="rsi", fmt=".0f")
        h = fig.data[0]
        assert h.z.shape == (3, 3)
        assert list(h.x) == ["1m", "5m", "15m"]
        assert list(h.y) == ["BTC/USD", "ETH/USD", "SOL/USD"]

    def test_nan_renders_as_blank(self, rsi_matrix):
        from propalgos.viz.heatmaps import heatmap

        fig = heatmap(rsi_matrix, colorscale="rsi", fmt=".0f")
        # SOL/USD 15m is NaN → text should be ""
        text = fig.data[0].text
        assert text[2][2] == ""

    def test_heatmap_title(self, rsi_matrix):
        from propalgos.viz.heatmaps import heatmap

        fig = heatmap(rsi_matrix, title="RSI Scanner")
        assert fig.layout.title.text == "RSI Scanner"

    def test_heatmap_respects_light_mode(self, rsi_matrix):
        from propalgos.viz.heatmaps import heatmap

        set_mode("light")
        fig = heatmap(rsi_matrix, colorscale="rsi", fmt=".0f")
        assert fig.layout.paper_bgcolor == _LIGHT["bg"]
        assert fig.layout.plot_bgcolor == _LIGHT["surface"]


# ---------------------------------------------------------------------------
# Monthly returns (backward compat)
# ---------------------------------------------------------------------------


class TestMonthlyReturns:
    def test_monthly_returns_from_series(self, sample_returns):
        from propalgos.viz.heatmaps import monthly_returns

        fig = monthly_returns(sample_returns)
        assert fig.data[0].type == "heatmap"

    def test_monthly_returns_from_result(self, sample_returns):
        from propalgos.viz.heatmaps import monthly_returns

        class FakeResult:
            @property
            def returns(self):
                return sample_returns

        fig = monthly_returns(FakeResult())
        assert fig.data[0].type == "heatmap"

    def test_monthly_returns_wrong_type(self):
        from propalgos.viz.heatmaps import monthly_returns

        with pytest.raises(TypeError, match="Expected pd.Series"):
            monthly_returns(42)


# ---------------------------------------------------------------------------
# Strip plot tests
# ---------------------------------------------------------------------------


class TestStrip:
    def test_basic_strip(self, strip_data):
        from propalgos.viz.strip import strip

        fig = strip(strip_data, x="timeframe", y="rsi", color="symbol")
        assert fig is not None
        # One Box trace per unique symbol
        assert len(fig.data) == 2

    def test_strip_with_thresholds(self, strip_data):
        from propalgos.viz.strip import strip

        fig = strip(
            strip_data,
            x="timeframe",
            y="rsi",
            color="symbol",
            thresholds={"Oversold": (0, 30), "Overbought": (70, 100)},
            y_range=(0, 100),
        )
        # Should have shapes for threshold bands
        assert len(fig.layout.shapes) >= 2

    def test_strip_with_title(self, strip_data):
        from propalgos.viz.strip import strip

        fig = strip(strip_data, x="timeframe", y="rsi", color="symbol", title="RSI Distribution")
        assert fig.layout.title.text == "RSI Distribution"

    def test_strip_y_range(self, strip_data):
        from propalgos.viz.strip import strip

        fig = strip(
            strip_data,
            x="timeframe",
            y="rsi",
            color="symbol",
            y_range=(0, 100),
        )
        assert tuple(fig.layout.yaxis.range) == (0, 100)

    def test_strip_missing_column_raises(self, strip_data):
        from propalgos.viz.strip import strip

        with pytest.raises(ValueError, match="not found in DataFrame"):
            strip(strip_data, x="nonexistent", y="rsi", color="symbol")

    def test_strip_respects_light_mode(self, strip_data):
        from propalgos.viz.strip import strip

        set_mode("light")
        fig = strip(strip_data, x="timeframe", y="rsi", color="symbol")
        assert fig.layout.paper_bgcolor == _LIGHT["bg"]

    def test_strip_midpoint_line(self, strip_data):
        from propalgos.viz.strip import strip

        fig = strip(
            strip_data,
            x="timeframe",
            y="rsi",
            color="symbol",
            y_range=(0, 100),
        )
        # Should have a horizontal line at y=50
        shapes = [s for s in fig.layout.shapes if s.type == "line"]
        assert any(s.y0 == 50.0 for s in shapes)
