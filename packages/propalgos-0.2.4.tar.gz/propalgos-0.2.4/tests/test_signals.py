"""Test signal generators produce valid {-1, 0, 1} output."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from propalgos import signals
from propalgos.exceptions import DataError


def _assert_valid_signal(sig: pd.Series) -> None:
    """All values must be in {-1, 0, 1}."""
    assert sig.dtype == int or sig.dtype == "int64", f"expected int dtype, got {sig.dtype}"
    unique = set(sig.unique())
    assert unique.issubset({-1, 0, 1}), f"invalid signal values: {unique}"


class TestSMACross:
    def test_basic(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        _assert_valid_signal(sig)
        assert len(sig) == len(sample_prices)

    def test_warmup_period_is_zero(self, sample_prices: pd.DataFrame):
        slow = 50
        sig = signals.sma_cross(sample_prices, fast=10, slow=slow)
        assert (sig.iloc[:slow] == 0).all(), "warmup period should be all zeros"

    def test_produces_nonzero_signals(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        assert sig.abs().sum() > 0, "should produce at least some nonzero signals"


class TestEMACross:
    def test_basic(self, sample_prices: pd.DataFrame):
        sig = signals.ema_cross(sample_prices, fast=12, slow=26)
        _assert_valid_signal(sig)
        assert len(sig) == len(sample_prices)


class TestRSIReversion:
    def test_basic(self, sample_prices: pd.DataFrame):
        sig = signals.rsi_reversion(sample_prices, period=14, overbought=70, oversold=30)
        _assert_valid_signal(sig)

    def test_warmup_is_zero(self, sample_prices: pd.DataFrame):
        sig = signals.rsi_reversion(sample_prices, period=14)
        # First ~14 bars should be zero due to RSI warmup
        assert sig.iloc[:14].sum() == 0


class TestMACD:
    def test_basic(self, sample_prices: pd.DataFrame):
        sig = signals.macd(sample_prices)
        _assert_valid_signal(sig)


class TestBollingerBands:
    def test_basic(self, sample_prices: pd.DataFrame):
        sig = signals.bollinger_bands(sample_prices, period=20, num_std=2.0)
        _assert_valid_signal(sig)

    def test_warmup_is_zero(self, sample_prices: pd.DataFrame):
        sig = signals.bollinger_bands(sample_prices, period=20)
        assert (sig.iloc[:20] == 0).all()


class TestZScoreReversion:
    def test_basic(self, sample_prices: pd.DataFrame):
        sig = signals.zscore_reversion(sample_prices, period=20, entry_z=2.0, exit_z=0.5)
        _assert_valid_signal(sig)


class TestTrendFilter:
    def test_basic(self, sample_prices: pd.DataFrame):
        sig = signals.trend_filter(sample_prices, period=50)
        _assert_valid_signal(sig)


class TestCombine:
    def test_and_method(self, sample_prices: pd.DataFrame):
        sig_a = signals.sma_cross(sample_prices, fast=10, slow=30)
        sig_b = signals.trend_filter(sample_prices, period=50)
        combined = signals.combine([sig_a, sig_b], method="and")
        _assert_valid_signal(combined)

    def test_or_method(self, sample_prices: pd.DataFrame):
        sig_a = signals.sma_cross(sample_prices, fast=10, slow=30)
        sig_b = signals.rsi_reversion(sample_prices)
        combined = signals.combine([sig_a, sig_b], method="or")
        _assert_valid_signal(combined)

    def test_majority_method(self, sample_prices: pd.DataFrame):
        sig_a = signals.sma_cross(sample_prices, fast=10, slow=30)
        sig_b = signals.trend_filter(sample_prices, period=50)
        sig_c = signals.macd(sample_prices)
        combined = signals.combine([sig_a, sig_b, sig_c], method="majority")
        _assert_valid_signal(combined)

    def test_empty_signals_raises(self):
        with pytest.raises(ValueError, match="at least one"):
            signals.combine([])

    def test_invalid_method_raises(self, sample_prices: pd.DataFrame):
        sig = signals.sma_cross(sample_prices, fast=10, slow=30)
        with pytest.raises(ValueError, match="unknown method"):
            signals.combine([sig], method="invalid")


class TestMissingCloseColumn:
    def test_no_close_raises(self):
        df = pd.DataFrame({"price": [1, 2, 3]})
        with pytest.raises(KeyError):
            signals.sma_cross(df)

    def test_empty_raises(self):
        df = pd.DataFrame({"close": pd.Series(dtype=float)})
        with pytest.raises(ValueError):
            signals.sma_cross(df)


# ---------------------------------------------------------------------------
# rsi raw export
# ---------------------------------------------------------------------------


class TestRsiRaw:
    def test_rsi_exported(self):
        assert hasattr(signals, "rsi")

    def test_rsi_returns_float_series(self, sample_prices: pd.DataFrame):
        result = signals.rsi(sample_prices, period=14)
        assert isinstance(result, pd.Series)
        # First 14 values should be NaN (warmup), rest should be 0-100
        valid = result.dropna()
        assert (valid >= 0).all() and (valid <= 100).all()


# ---------------------------------------------------------------------------
# Stacked DataFrame fixture
# ---------------------------------------------------------------------------


@pytest.fixture
def stacked_df() -> pd.DataFrame:
    """Two-symbol stacked DataFrame for testing rsi_stacked/scan."""
    rng = np.random.default_rng(42)
    n = 100
    timestamps = pd.date_range("2025-01-01", periods=n, freq="h", tz="UTC")
    frames = []
    for symbol, base in [("BTCUSD", 50000.0), ("ETHUSD", 3000.0)]:
        close = base + rng.standard_normal(n).cumsum() * 50
        frames.append(pd.DataFrame({
            "timestamp": timestamps,
            "symbol": symbol,
            "open": close * (1 + rng.uniform(-0.005, 0.005, n)),
            "high": close * 1.005,
            "low": close * 0.995,
            "close": close,
            "volume": rng.integers(100, 5000, n).astype(float),
        }))
    return pd.concat(frames, ignore_index=True)


# ---------------------------------------------------------------------------
# rsi_stacked
# ---------------------------------------------------------------------------


class TestRsiStacked:
    def test_rsi_stacked_basic(self, stacked_df: pd.DataFrame):
        result = signals.rsi_stacked(stacked_df, period=14)
        assert "rsi" in result.columns
        assert len(result) == len(stacked_df)
        # Warmup rows should be NaN
        btc_rows = result[result["symbol"] == "BTCUSD"]
        assert btc_rows["rsi"].iloc[:14].isna().all()

    def test_rsi_stacked_no_leakage(self, stacked_df: pd.DataFrame):
        """RSI at symbol boundary should be NaN (no cross-symbol leakage)."""
        result = signals.rsi_stacked(stacked_df, period=14)
        # Find the first row of the second symbol
        symbols = result["symbol"].values
        boundary_idx = None
        for i in range(1, len(symbols)):
            if symbols[i] != symbols[i - 1]:
                boundary_idx = i
                break
        assert boundary_idx is not None
        # First `period` rows of the new symbol should be NaN
        second_symbol_rsi = result["rsi"].iloc[boundary_idx:boundary_idx + 14]
        assert second_symbol_rsi.isna().all()

    def test_rsi_stacked_values_in_range(self, stacked_df: pd.DataFrame):
        result = signals.rsi_stacked(stacked_df, period=14)
        valid = result["rsi"].dropna()
        assert (valid >= 0).all() and (valid <= 100).all()

    def test_rsi_stacked_matches_single_symbol(self, stacked_df: pd.DataFrame):
        """For a single symbol, rsi_stacked should match pa.signals.rsi."""
        btc = stacked_df[stacked_df["symbol"] == "BTCUSD"].copy().reset_index(drop=True)
        single_rsi = signals.rsi(btc, period=14)

        stacked_result = signals.rsi_stacked(btc.assign(symbol="BTCUSD"), period=14)
        stacked_rsi = stacked_result["rsi"]

        # Compare non-NaN values
        mask = single_rsi.notna() & stacked_rsi.notna()
        np.testing.assert_allclose(
            single_rsi[mask].values,
            stacked_rsi[mask].values,
            rtol=1e-10,
        )

    def test_rsi_stacked_missing_symbol_col(self, stacked_df: pd.DataFrame):
        df = stacked_df.drop(columns=["symbol"])
        with pytest.raises(DataError, match="symbol column"):
            signals.rsi_stacked(df)

    def test_rsi_stacked_missing_close_col(self, stacked_df: pd.DataFrame):
        df = stacked_df.drop(columns=["close"])
        with pytest.raises(DataError, match="close column"):
            signals.rsi_stacked(df)


# ---------------------------------------------------------------------------
# scan
# ---------------------------------------------------------------------------


class TestScan:
    def test_scan_basic(self, stacked_df: pd.DataFrame):
        """scan() with rsi_reversion should produce signal in {-1, 0, 1}."""
        result = signals.scan(stacked_df, signals.rsi_reversion)
        assert "signal" in result.columns
        unique = set(result["signal"].unique())
        assert unique.issubset({-1, 0, 1})

    def test_scan_missing_symbol_col(self, stacked_df: pd.DataFrame):
        df = stacked_df.drop(columns=["symbol"])
        with pytest.raises(DataError, match="symbol column"):
            signals.scan(df, signals.rsi_reversion)

    def test_scan_handles_failing_groups(self):
        """Groups with too few rows should get signal 0, not crash."""
        # Create a tiny group that will fail validation
        df = pd.DataFrame({
            "symbol": ["A"] * 5 + ["B"] * 50,
            "close": list(range(5)) + list(range(50)),
            "timestamp": pd.date_range("2025-01-01", periods=55, freq="h"),
        })

        def strict_signal(group: pd.DataFrame) -> pd.Series:
            if len(group) < 20:
                raise ValueError("too few rows")
            return pd.Series(1, index=group.index, dtype=int)

        result = signals.scan(df, strict_signal)
        # Group A should have signal 0 (failed), group B should have signal 1
        a_signals = result[result["symbol"] == "A"]["signal"]
        b_signals = result[result["symbol"] == "B"]["signal"]
        assert (a_signals == 0).all()
        assert (b_signals == 1).all()
