"""Tests for GPU optimization compatibility — verifies all rewritten functions
produce correct results and that CPU fallback paths work when cuDF is absent.
"""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd
import pytest


# ---------------------------------------------------------------------------
# Log returns (Fix 1.1 — np.log(ratio) instead of ratio.apply(np.log))
# ---------------------------------------------------------------------------


class TestLogReturns:
    def test_log_returns_match_manual(self, sample_prices: pd.DataFrame):
        from propalgos.data.returns import returns

        log_ret = returns(sample_prices, method="log")
        expected = np.log(sample_prices["close"] / sample_prices["close"].shift(1))
        pd.testing.assert_frame_equal(log_ret, expected.to_frame())

    def test_simple_returns_unchanged(self, sample_prices: pd.DataFrame):
        from propalgos.data.returns import returns

        simple = returns(sample_prices, method="simple")
        expected = sample_prices[["close"]].pct_change()
        pd.testing.assert_frame_equal(simple, expected)

    def test_invalid_method_raises(self, sample_prices: pd.DataFrame):
        from propalgos.data.returns import returns
        from propalgos.exceptions import DataError

        with pytest.raises(DataError, match="unknown return method"):
            returns(sample_prices, method="bad")


# ---------------------------------------------------------------------------
# Signal compose _combine_or (Fix 1.2 — boolean indexing)
# ---------------------------------------------------------------------------


class TestCombineOr:
    def test_or_sign_of_sum(self):
        from propalgos.signals.compose import combine

        s1 = pd.Series([1, -1, 0, 1, -1])
        s2 = pd.Series([1, 1, 0, -1, -1])
        result = combine([s1, s2], method="or")
        # sum: [2, 0, 0, 0, -2] → sign: [1, 0, 0, 0, -1]
        expected = pd.Series([1, 0, 0, 0, -1])
        pd.testing.assert_series_equal(result, expected, check_names=False)

    def test_or_values_in_valid_set(self):
        from propalgos.signals.compose import combine

        rng = np.random.default_rng(42)
        signals = [pd.Series(rng.choice([-1, 0, 1], 100)) for _ in range(5)]
        result = combine(signals, method="or")
        assert set(result.unique()).issubset({-1, 0, 1})


# ---------------------------------------------------------------------------
# Cache direct cudf read (Fix 1.3 — fallback when cudf absent)
# ---------------------------------------------------------------------------


class TestCacheCudfFallback:
    def test_cache_roundtrip_without_cudf(self, tmp_path: Path):
        from propalgos.data.cache import get_cached, set_cached

        df = pd.DataFrame({"close": [1.0, 2.0, 3.0]})
        with patch.dict("os.environ", {"XDG_CACHE_HOME": str(tmp_path)}):
            set_cached(df, ["TEST"], "2024-01-01", None, "1d", "test_provider")
            result = get_cached(["TEST"], "2024-01-01", None, "1d", "test_provider")
        assert result is not None
        pd.testing.assert_frame_equal(result, df)


# ---------------------------------------------------------------------------
# stage_file (Fix 1.4 — kvikIO fallback to buffered shutil)
# ---------------------------------------------------------------------------


class TestStageFile:
    def test_stage_file_copies_correctly(self, tmp_path: Path):
        from propalgos.data.staging import stage_file

        source = tmp_path / "source.parquet"
        dest = tmp_path / "dest.parquet"
        content = b"fake parquet content " * 1000
        source.write_bytes(content)

        stage_file(source, dest)

        assert dest.exists()
        assert dest.read_bytes() == content

    def test_stage_file_preserves_mtime(self, tmp_path: Path):
        import os

        from propalgos.data.staging import stage_file

        source = tmp_path / "source.parquet"
        dest = tmp_path / "dest.parquet"
        source.write_bytes(b"data")
        # Set a known mtime
        os.utime(source, (1000000.0, 1000000.0))

        stage_file(source, dest)

        assert abs(dest.stat().st_mtime - 1000000.0) < 1.0

    def test_stage_file_kvikio_fallback(self, tmp_path: Path):
        """When kvikIO import fails, stage_file still works via shutil."""
        from propalgos.data.staging import stage_file

        source = tmp_path / "src.dat"
        dest = tmp_path / "dst.dat"
        source.write_bytes(b"test data")

        # kvikIO is not installed in test env, so this exercises the fallback
        stage_file(source, dest)
        assert dest.read_bytes() == b"test data"


# ---------------------------------------------------------------------------
# _to_numpy helper (Fix 2.2 — GPU-safe Plotly extraction)
# ---------------------------------------------------------------------------


class TestToNumpy:
    def test_plain_series(self):
        from propalgos.viz._compat import _to_numpy

        s = pd.Series([1.0, 2.0, 3.0])
        result = _to_numpy(s)
        np.testing.assert_array_equal(result, np.array([1.0, 2.0, 3.0]))

    def test_plain_dataframe(self):
        from propalgos.viz._compat import _to_numpy

        df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
        result = _to_numpy(df)
        np.testing.assert_array_equal(result, np.array([[1, 3], [2, 4]]))

    def test_calls_to_pandas_when_available(self):
        """Simulates a cuDF-like object that has .to_pandas()."""
        from propalgos.viz._compat import _to_numpy

        class FakeCudfSeries:
            def to_pandas(self):
                return pd.Series([10.0, 20.0])

            def values(self):
                raise RuntimeError("should not be called directly")

        result = _to_numpy(FakeCudfSeries())
        np.testing.assert_array_equal(result, np.array([10.0, 20.0]))


# ---------------------------------------------------------------------------
# _build_monthly_matrix (Fix 2.3 — resample + pivot rewrite)
# ---------------------------------------------------------------------------


class TestBuildMonthlyMatrix:
    def test_shape_and_columns(self, sample_returns: pd.Series):
        from propalgos.viz.heatmaps import _build_monthly_matrix

        matrix = _build_monthly_matrix(sample_returns)
        # sample_returns spans ~200 business days from 2023-01-02
        assert matrix.columns.tolist() == [
            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
        ]
        assert matrix.index.name == "Year"
        assert len(matrix) >= 1  # at least one year

    def test_monthly_compounding_correctness(self):
        """Verify that a known month compounds correctly."""
        from propalgos.viz.heatmaps import _build_monthly_matrix

        # 3 days in January 2024, each +10%
        dates = pd.to_datetime(["2024-01-02", "2024-01-03", "2024-01-04"])
        rets = pd.Series([0.10, 0.10, 0.10], index=dates)
        matrix = _build_monthly_matrix(rets)

        jan_return = matrix.loc[2024, "Jan"]
        expected = (1.1 * 1.1 * 1.1) - 1  # 0.331
        assert abs(jan_return - expected) < 1e-10

    def test_non_datetime_index_converted(self):
        from propalgos.viz.heatmaps import _build_monthly_matrix

        dates = ["2024-01-02", "2024-01-03", "2024-01-04"]
        rets = pd.Series([0.01, 0.02, -0.01], index=dates)
        matrix = _build_monthly_matrix(rets)
        assert 2024 in matrix.index


# ---------------------------------------------------------------------------
# from_csv cudf fallback (Fix 4.1)
# ---------------------------------------------------------------------------


class TestFromCsvFallback:
    def test_from_csv_reads_ohlcv(self, tmp_path: Path):
        from propalgos.data.returns import from_csv

        csv_path = tmp_path / "prices.csv"
        dates = pd.bdate_range("2024-01-02", periods=10)
        df = pd.DataFrame(
            {"Close": range(100, 110), "Volume": range(10)},
            index=dates,
        )
        df.to_csv(csv_path)

        result = from_csv(csv_path)
        assert "close" in result.columns
        assert len(result) == 10
        assert isinstance(result.index, pd.DatetimeIndex)

    def test_from_csv_missing_file_raises(self):
        from propalgos.data.returns import from_csv
        from propalgos.exceptions import DataError

        with pytest.raises(DataError, match="file not found"):
            from_csv("/nonexistent/path.csv")


# ---------------------------------------------------------------------------
# scan() groupby refactor (Fix 3.4)
# ---------------------------------------------------------------------------


class TestScanGroupbyRefactor:
    def test_scan_produces_signal_column(self):
        from propalgos.signals.scan import scan
        from propalgos.signals.trend import sma_cross

        rng = np.random.default_rng(42)
        n = 200
        df = pd.DataFrame({
            "symbol": ["A"] * n + ["B"] * n,
            "timestamp": list(range(n)) * 2,
            "close": np.concatenate([
                100 + rng.standard_normal(n).cumsum(),
                50 + rng.standard_normal(n).cumsum(),
            ]),
        })
        result = scan(df, sma_cross, symbol_col="symbol")
        assert "signal" in result.columns
        assert set(result["signal"].unique()).issubset({-1, 0, 1})

    def test_scan_failing_group_gets_zero(self):
        """Groups that raise get signal=0, not propagated errors."""
        from propalgos.signals.scan import scan

        df = pd.DataFrame({
            "symbol": ["OK"] * 50 + ["TINY"] * 2,
            "timestamp": list(range(50)) + list(range(2)),
            "close": list(range(50)) + [1.0, 2.0],
        })

        def strict_signal(prices):
            if len(prices) < 10:
                raise ValueError("too few rows")
            signal = pd.Series(0, index=prices.index, dtype=int)
            signal.iloc[-1] = 1
            return signal

        result = scan(df, strict_signal, symbol_col="symbol")
        tiny_signals = result[result["symbol"] == "TINY"]["signal"]
        assert (tiny_signals == 0).all()
