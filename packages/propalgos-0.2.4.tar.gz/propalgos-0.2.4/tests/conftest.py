"""Shared fixtures for PropAlgos SDK tests."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest


@pytest.fixture
def sample_prices() -> pd.DataFrame:
    """Deterministic daily OHLCV DataFrame for testing.

    100 trading days with a simple uptrend + noise. Reproducible via fixed seed.
    """
    rng = np.random.default_rng(42)
    n = 200
    dates = pd.bdate_range("2023-01-02", periods=n)

    # Price path: geometric brownian motion with drift
    drift = 0.0003
    vol = 0.015
    log_returns = drift + vol * rng.standard_normal(n)
    log_returns[0] = 0.0
    close = 100.0 * np.exp(np.cumsum(log_returns))

    # Synthetic OHLCV around close
    high = close * (1 + rng.uniform(0, 0.02, n))
    low = close * (1 - rng.uniform(0, 0.02, n))
    open_ = close * (1 + rng.uniform(-0.01, 0.01, n))
    volume = rng.integers(1_000_000, 10_000_000, n)

    return pd.DataFrame(
        {"open": open_, "high": high, "low": low, "close": close, "volume": volume},
        index=dates,
    )


@pytest.fixture
def sample_returns(sample_prices: pd.DataFrame) -> pd.Series:
    """Daily simple returns derived from sample_prices."""
    return sample_prices["close"].pct_change().fillna(0.0)
