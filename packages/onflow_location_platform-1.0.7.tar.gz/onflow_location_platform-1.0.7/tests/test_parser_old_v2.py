import unittest

from onflow_location_platform.parser import parse_address_old


class ParserOldV2Tests(unittest.TestCase):
    def test_accepts_legacy_address_without_quan_prefix(self):
        unit = parse_address_old(
            "59 Nguyễn Sỹ Sách, Phường 15, Tân Bình, Hồ Chí Minh",
            keep_street=True,
            level=3,
        )

        self.assertEqual(unit.street, "59 Nguyễn Sỹ Sách")
        self.assertIsNotNone(unit.province_key)
        self.assertIsNotNone(unit.district_key)
        self.assertIsNotNone(unit.ward_key)


if __name__ == "__main__":
    unittest.main()
