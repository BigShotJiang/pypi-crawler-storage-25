import unittest

from onflow_location_platform.parser.utils import (
    correct_typos,
    extract_street,
    key_normalize,
    replace_from_right,
    unicode_normalize,
    uppercase_first_letters,
)


class ParserUtilsTests(unittest.TestCase):
    def test_unicode_normalize_standardizes_quotes_dashes_and_spacing(self):
        self.assertEqual(unicode_normalize('  “A”  -  B  '), '"A" - B')
        self.assertEqual(unicode_normalize("A-B  C"), "A - B C")

    def test_key_normalize_can_keep_selected_characters_and_accents(self):
        self.assertEqual(
            key_normalize("Phường 15, Quận Tân Bình", keep=[","]),
            "phuong15,quantanbinh",
        )
        self.assertEqual(key_normalize("Đống Đa", decode=False), "đốngđa")

    def test_replace_from_right_replaces_only_the_last_match(self):
        self.assertEqual(replace_from_right("abc,def,def", "def", "xyz"), "abc,def,xyz")

    def test_extract_street_stops_before_parsed_admin_unit(self):
        self.assertEqual(
            extract_street(
                address="59 Nguyễn Sỹ Sách, Phường 15, Tân Bình, Hồ Chí Minh",
                address_key="59nguyensysach,phuong15,tanbinh,hochiminh",
                highest_level_keyword="phuong15",
            ),
            "59 Nguyễn Sỹ Sách",
        )

    def test_correct_typos_and_uppercase_helpers(self):
        self.assertEqual(correct_typos("Hoà Bình, Thuỷ Nguyên"), "Hòa Bình, Thủy Nguyên")
        self.assertEqual(uppercase_first_letters("tan son hoa"), "Tan son hoa")
        self.assertEqual(
            uppercase_first_letters("tan son hoa", all_first_letters=True),
            "Tan Son Hoa",
        )


if __name__ == "__main__":
    unittest.main()
