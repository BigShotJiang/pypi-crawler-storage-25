import unittest

from onflow_location_platform.parser.objects import AdminUnit


class AdminUnitTests(unittest.TestCase):
    def test_format_address_supports_full_and_short_names(self):
        unit = AdminUnit(
            street="12 Le Loi",
            province="Thanh pho Ho Chi Minh",
            district="Quan Tan Binh",
            ward="Phuong Tan Son Hoa",
            short_province="Ho Chi Minh",
            short_district="Tan Binh",
            short_ward="Tan Son Hoa",
        )

        self.assertEqual(
            unit.format_address(),
            "12 Le Loi, Phuong Tan Son Hoa, Quan Tan Binh, Thanh pho Ho Chi Minh",
        )
        self.assertEqual(
            unit.format_address(short_name=True),
            "12 Le Loi, Tan Son Hoa, Tan Binh, Ho Chi Minh",
        )

    def test_legacy_admin_unit_aliases_source_admin_unit(self):
        legacy_unit = AdminUnit(province="Ba Ria - Vung Tau")
        unit = AdminUnit()

        unit.legacy_admin_unit = legacy_unit

        self.assertIs(unit.source_admin_unit, legacy_unit)
        self.assertIs(unit.legacy_admin_unit, legacy_unit)

    def test_repr_hides_district_fields_when_show_district_is_false(self):
        unit = AdminUnit(
            province="Thanh pho Ho Chi Minh",
            district="Quan Tan Binh",
            ward="Phuong Tan Son Hoa",
            district_type="quan",
            show_district=False,
        )

        representation = repr(unit)

        self.assertIn("province", representation)
        self.assertNotIn("district       |", representation)
        self.assertNotIn("district_type", representation)

    def test_repr_includes_district_fields_when_show_district_is_true(self):
        unit = AdminUnit(
            province="Thanh pho Ho Chi Minh",
            district="Quan Tan Binh",
            ward="Phuong Tan Son Hoa",
            district_type="quan",
            show_district=True,
        )

        representation = repr(unit)

        self.assertIn("district        | Quan Tan Binh", representation)
        self.assertIn("district_type   | quan", representation)


if __name__ == "__main__":
    unittest.main()
