from pathlib import Path

from setuptools import find_packages, setup


BASE_DIR = Path(__file__).parent
README_PATH = BASE_DIR / "README.md"

PACKAGE_NAME = "onflow-location-platform"
PACKAGE_VERSION = "1.0.7"
PACKAGE_DESCRIPTION = (
    "OnFlow Location Platform for parsing, converting, and "
    "standardizing Vietnamese administrative units"
)
PACKAGE_URL = "https://github.com/N-H-Logistics/onflow-location-platform"

INSTALL_REQUIRES = [
    "geopy",
    "pandas",
    "shapely",
    "tqdm",
    "unidecode",
]

EXTRAS_REQUIRE = {
    "scripts": [
        "beautifulsoup4",
        "numpy",
        "requests",
        "seleniumbase",
    ],
}

CLASSIFIERS = [
    "Development Status :: 5 - Production/Stable",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Natural Language :: Vietnamese",
    "Operating System :: OS Independent",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3 :: Only",
    "Programming Language :: Python :: 3.7",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "Topic :: Software Development :: Libraries",
    "Topic :: Text Processing",
]


def read_readme() -> str:
    return README_PATH.read_text(encoding="utf-8")


setup(
    name=PACKAGE_NAME,
    version=PACKAGE_VERSION,
    description=PACKAGE_DESCRIPTION,
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    author="OnFlow",
    author_email="opensource@onflow.vn",
    url=PACKAGE_URL,
    project_urls={
        "Homepage": PACKAGE_URL,
        "Repository": PACKAGE_URL,
        "Issues": f"{PACKAGE_URL}/issues",
    },
    keywords=[
        "address parser",
        "administrative units",
        "vietnam",
        "geodata",
        "sdk",
    ],
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    include_package_data=True,
    package_data={
        "onflow_location_platform": [
            "data/ops/*.json",
            "data/ops/*.db",
            "data/*.json",
            "data/*.db",
        ],
    },
    python_requires=">=3.7",
    install_requires=INSTALL_REQUIRES,
    extras_require=EXTRAS_REQUIRE,
    classifiers=CLASSIFIERS,
)
