from .converter_new import convert_address_old_to_new
from .converter_old import convert_address_new_to_old
from .converter_new_by_code import (
    convert_address_old_to_new_by_code,
    convert_province_old_to_new_by_code,
    convert_district_old_to_new_by_code,
    convert_ward_old_to_new_by_code,
    get_new_province_by_new_code,
    get_new_ward_by_new_code,
    get_new_admin_unit_by_new_code,
)
from enum import Enum


class ConvertMode(Enum):
    CONVERT_2025 = "CONVERT_2025"

    @classmethod
    def available(cls, value=False):
        attrs = list(cls)
        if value:
            attrs = [a.value for a in attrs]
        return attrs


__all__ = [
    "ConvertMode",
    "convert_address_new_to_old",
    "convert_address_old_to_new",
    "convert_address_old_to_new_by_code",
    "convert_province_old_to_new_by_code",
    "convert_district_old_to_new_by_code",
    "convert_ward_old_to_new_by_code",
    "get_new_province_by_new_code",
    "get_new_ward_by_new_code",
    "get_new_admin_unit_by_new_code",
]
