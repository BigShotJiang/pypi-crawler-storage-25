import json
from pathlib import Path


MODULE_DIR = Path(__file__).parent.parent


from ..parser import parse_address_new, parse_address_old
from ..parser.utils import get_geo_location, check_point_in_polygon, find_nearest_point

with open(MODULE_DIR / 'data/converter_2025.json', 'r') as f:
    converter_data = json.load(f)


DICT_PROVINCE = converter_data['DICT_PROVINCE']
DICT_PROVINCE_WARD_NO_DIVIDED = converter_data['DICT_PROVINCE_WARD_NO_DIVIDED']
DICT_PROVINCE_WARD_DIVIDED = converter_data['DICT_PROVINCE_WARD_DIVIDED']

def convert_address_old_to_new(address: str):
    '''
    Convert address from old format to new format based on the Vietnam administrative unit changes in 2025
    :param address: str - The old address to convert

    :return: AdminUnit object
    '''

    new_ward_key = None

    old_unit = parse_address_old(address, keep_street=True, level=3)

    new_province_key = next((k for k, v in DICT_PROVINCE.items() if old_unit.province_key and old_unit.province_key in v), None)

    special_zone = ['huyenbachlongvi', 'huyenconco', 'huyenhoangsa', 'huyenlyson', 'huyencondao']
    if old_unit.ward_key or old_unit.district_key in special_zone:
        old_province_district_ward_key = f"{old_unit.province_key}_{old_unit.district_key}_{old_unit.ward_key if old_unit.ward_key else ''}"

        DICT_WARD_NO_DIVIDED = DICT_PROVINCE_WARD_NO_DIVIDED[new_province_key]
        new_ward_key = next((k for k, v in DICT_WARD_NO_DIVIDED.items() if old_province_district_ward_key and old_province_district_ward_key in v), None)

        if not new_ward_key:
            new_wards = DICT_PROVINCE_WARD_DIVIDED.get(new_province_key, {}).get(old_province_district_ward_key, [])

            if not old_unit.street:
                new_ward_key = next((ward['newWardKey'] for ward in new_wards if ward['isDefaultNewWard']), None)

            else:
                old_location = get_geo_location(old_unit.format_address())

                if old_location:
                    old_point = (old_location.latitude, old_location.longitude)

                    containing_points = []
                    new_ward_points = []

                    for ward in new_wards:
                        new_point = (ward['newWardLat'], ward['newWardLon'])
                        new_ward_points.append(new_point)
                        is_contain = check_point_in_polygon(point=old_point, polygon_center=new_point, polygon_area_km2=ward['newWardAreaKm2'])
                        if is_contain:
                            containing_points.append(new_point)

                    nearest_point = find_nearest_point(a_point=old_point, list_of_b_points=new_ward_points)

                    if len(containing_points) == 1:
                        default_ward_point = containing_points[0]
                    else:
                        default_ward_point = nearest_point

                    new_ward_key = next((ward['newWardKey'] for ward in new_wards if (ward['newWardLat'], ward['newWardLon']) == default_ward_point), None)

                else:
                    new_ward_key = next((ward['newWardKey'] for ward in new_wards if ward['isDefaultNewWard']), None)

    new_address_components = [i for i in (old_unit.street, new_ward_key, new_province_key) if i]
    new_address = ','.join(new_address_components)

    level = 2 if new_ward_key else 1
    if not new_ward_key:
        raise ValueError(f"Address '{address}' is invalid old address")
    
    new_unit = parse_address_new(new_address, keep_street=True, level=level)
    new_unit.source_admin_unit = old_unit

    return new_unit
