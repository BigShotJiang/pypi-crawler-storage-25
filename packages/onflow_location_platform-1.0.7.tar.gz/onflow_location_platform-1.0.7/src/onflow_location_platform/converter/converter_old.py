import json
from pathlib import Path
from typing import Union

MODULE_DIR = Path(__file__).parent.parent

from ..parser import parse_address_new, parse_address_old
from ..parser.objects import AdminUnit
from ..parser.utils import get_geo_location, check_point_in_polygon, find_nearest_point, geodesic, key_normalize, unicode_normalize
from ..parser.parser_from_new import DICT_PROVINCE as DICT_NEW_PARSER_PROVINCE

with open(MODULE_DIR / 'data/converter_2025.json', 'r') as f:
    converter_data = json.load(f)


DICT_PROVINCE = converter_data['DICT_PROVINCE']
DICT_PROVINCE_WARD_NO_DIVIDED = converter_data['DICT_PROVINCE_WARD_NO_DIVIDED']
DICT_PROVINCE_WARD_DIVIDED = converter_data['DICT_PROVINCE_WARD_DIVIDED']

# ===========================================================================
# Helpers for convert_address_new_to_old
# ===========================================================================

def _build_old_unit_from_key(old_key: str, source_unit: AdminUnit, parser_fn=parse_address_old) -> AdminUnit:
    '''
    Build a legacy AdminUnit from composite key "{province_key}_{district_key}_{ward_key}".
    `ward_key` can be empty (special zones).
    '''
    parts = old_key.split('_', 2)
    old_province_key = parts[0] if len(parts) > 0 else ''
    old_district_key = parts[1] if len(parts) > 1 else ''
    old_ward_key     = parts[2] if len(parts) > 2 else ''

    street = source_unit.street
    components = [c for c in [street, old_ward_key or None, old_district_key or None, old_province_key] if c]
    addr = ','.join(components)
    level = 3 if old_ward_key else 2 if old_district_key else 1
    unit = parser_fn(addr, keep_street=bool(street), level=level)
    unit.source_admin_unit = source_unit
    return unit


def _find_old_keys(new_province_key: str, new_ward_key: str) -> list:
    '''
    Lookup old composite keys from converter data for a pair (new_province, new_ward).
    Try NO_DIVIDED first, then DIVIDED.
    '''
    ward_no_div = DICT_PROVINCE_WARD_NO_DIVIDED.get(new_province_key, {})
    old_keys = list(ward_no_div.get(new_ward_key, []))
    if old_keys:
        return old_keys

    divided = DICT_PROVINCE_WARD_DIVIDED.get(new_province_key, {})
    old_keys = [old_composite_key for old_composite_key, new_ward_entries in divided.items() if any(w['newWardKey'] == new_ward_key for w in new_ward_entries)]
    return old_keys


def _try_return_as_legacy(address: str, multi_match: str):
    '''
    Try parsing the input as a legacy address. If a province is found, return
    AdminUnit (or list); otherwise return None.
    '''
    legacy_unit = parse_address_old(address, keep_street=True, level=3)
    if not legacy_unit.province_key:
        return None
    return [legacy_unit] if multi_match == 'all' else legacy_unit


def _strategy_first(old_keys: list, source_unit: AdminUnit, build_fn, **_) -> AdminUnit:
    return build_fn(old_keys[0], source_unit)


def _strategy_all(old_keys: list, source_unit: AdminUnit, build_fn, **_) -> list[AdminUnit]:
    return [build_fn(key, source_unit) for key in old_keys]


def _strategy_geo(old_keys: list, source_unit: AdminUnit, address: str, build_fn, **_) -> AdminUnit:
    if source_unit.street:
        location = get_geo_location(address)
        if location:
            new_point = (location.latitude, location.longitude)
            units = [build_fn(key, source_unit) for key in old_keys]
            valid = [unit for unit in units if unit.latitude is not None and unit.longitude is not None]
            if valid:
                best = min(valid, key=lambda unit: geodesic(new_point, (unit.latitude, unit.longitude)).meters)
                return best
    return _strategy_first(old_keys, source_unit, build_fn=build_fn)


_MULTI_MATCH_STRATEGIES = {
    'first': _strategy_first,
    'all':   _strategy_all,
    'geo':   _strategy_geo,
}


def _has_explicit_new_province(address: str) -> bool:
    """
    Strict gate: input must explicitly contain a new province keyword.
    No inference from ward-only text.
    """
    normalized = key_normalize(unicode_normalize(address))
    if not normalized:
        return False
    for province_value in DICT_NEW_PARSER_PROVINCE.values():
        for keyword in province_value.get("provinceKeywords", []):
            if keyword and keyword in normalized:
                return True
    return False


# ===========================================================================
# Public API
# ===========================================================================

def convert_address_new_to_old(
    address: str,
    multi_match: str = 'geo',
) -> Union[AdminUnit, list[AdminUnit]]:
    """
    Strict reverse converter from new address -> legacy address.

    Rules:
    - Must start from a valid new province. If no new province -> return empty AdminUnit/list.
    - Province-only input returns mapped old province(s).
    - Full input (ward + province) maps by converter data.
    - When multiple legacy units match, the strategy is selected by `multi_match`:
      'first' returns the first match, 'all' returns all matches, 'geo' uses geolocation.
    """
    if multi_match not in _MULTI_MATCH_STRATEGIES:
        raise ValueError(f"multi_match must be one of {list(_MULTI_MATCH_STRATEGIES)}")

    if not _has_explicit_new_province(address):
        return [] if multi_match == 'all' else AdminUnit()

    parsed_2025_unit = parse_address_new(address, keep_street=True, level=2)
    province_key_2025 = parsed_2025_unit.province_key
    ward_key_2025 = parsed_2025_unit.ward_key

    # Must start from new-province context.
    if not province_key_2025:
        return [] if multi_match == 'all' else AdminUnit()

    old_province_keys = DICT_PROVINCE.get(province_key_2025, [province_key_2025])

    # Province-only input: return old province mapping directly.
    if not ward_key_2025:
        units = []
        for old_province_key in old_province_keys:
            unit = parse_address_old(old_province_key, keep_street=False, level=1)
            unit.source_admin_unit = parsed_2025_unit
            units.append(unit)
        if multi_match == 'all':
            return units
        return units[0] if units else AdminUnit()

    old_keys = _find_old_keys(province_key_2025, ward_key_2025)
    if not old_keys:
        # Province was valid, but ward could not be mapped.
        return [] if multi_match == 'all' else AdminUnit()

    return _MULTI_MATCH_STRATEGIES[multi_match](
        old_keys=old_keys,
        source_unit=parsed_2025_unit,
        address=address,
        build_fn=lambda key, unit: _build_old_unit_from_key(key, unit, parser_fn=parse_address_old),
    )
