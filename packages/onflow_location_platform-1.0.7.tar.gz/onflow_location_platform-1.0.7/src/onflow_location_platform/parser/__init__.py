from .parser_from_new import parse_address_new
# from .parser_legacy import parse_address_old
from .parser_old_v2 import parse_address_old_v2 as parse_address_old
from enum import Enum

class ParseMode(Enum):
    LEGACY = "LEGACY"
    FROM_2025 = "FROM_2025"

    @classmethod
    def latest(cls):
        merger_modes = [m for m in cls if '_20' in m.name]
        return max(merger_modes, key=lambda m: int(m.value.split("_")[1]))

    @classmethod
    def available(cls, value=False):
        attrs = list(cls)
        if value:
            attrs = [a.value for a in attrs]
        return attrs


__all__ = [
    "ParseMode",
    "parse_address_new",
    "parse_address_old"
]
