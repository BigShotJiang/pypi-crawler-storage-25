import json
import re
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .objects import AdminUnit
from .parser_from_new import parse_address_new
from .utils import extract_street, key_normalize, unicode_normalize

MODULE_DIR = Path(__file__).parent.parent
with open(MODULE_DIR / "data/parser_legacy.json", "r") as f:
    parser_data = json.load(f)

DICT_PROVINCE = parser_data["DICT_PROVINCE"]
DICT_PROVINCE_DISTRICT = parser_data["DICT_PROVINCE_DISTRICT"]
DICT_UNIQUE_DISTRICT_PROVINCE = parser_data["DICT_UNIQUE_DISTRICT_PROVINCE"]
DICT_PROVINCE_DISTRICT_WARD_NO_ACCENTED = parser_data["DICT_PROVINCE_DISTRICT_WARD_NO_ACCENTED"]
DICT_PROVINCE_DISTRICT_WARD_ACCENTED = parser_data["DICT_PROVINCE_DISTRICT_WARD_ACCENTED"]
DICT_PROVINCE_DISTRICT_WARD_SHORT_ACCENTED = parser_data["DICT_PROVINCE_DISTRICT_WARD_SHORT_ACCENTED"]
DICT_PROVINCE_DISTRICT_DIVIDED = parser_data["DICT_PROVINCE_DISTRICT_DIVIDED"]

WARD_DATASETS = [
    DICT_PROVINCE_DISTRICT_WARD_NO_ACCENTED,
    DICT_PROVINCE_DISTRICT_WARD_ACCENTED,
    DICT_PROVINCE_DISTRICT_WARD_SHORT_ACCENTED,
]

MAP_KEYWORD_PROV = defaultdict(set)
MAP_KEYWORD_DIST = defaultdict(set)
MAP_KEYWORD_WARD = defaultdict(set)
VALID_DIST_WARD = set()
VALID_PROV_DIST = set()
VALID_PROV_DIST_WARD = set()


def _add_keyword(target_dict: dict, keyword: str, value: Any) -> None:
    if not keyword:
        return

    normalized_values = {
        key_normalize(keyword, decode=True),
        key_normalize(keyword, decode=False),
    }

    for normalized_keyword in normalized_values:
        if normalized_keyword:
            target_dict[normalized_keyword].add(value)


for province_key, province_value in DICT_PROVINCE.items():
    for keyword in province_value["provinceKeywords"]:
        _add_keyword(MAP_KEYWORD_PROV, keyword, province_key)

for province_key, districts in DICT_PROVINCE_DISTRICT.items():
    for district_key, district_value in districts.items():
        VALID_PROV_DIST.add((province_key, district_key))
        for keyword in district_value["districtKeywords"]:
            _add_keyword(MAP_KEYWORD_DIST, keyword, (province_key, district_key))

for district_key, district_value in DICT_UNIQUE_DISTRICT_PROVINCE.items():
    province_key = district_value["provinceKey"]
    VALID_PROV_DIST.add((province_key, district_key))
    for keyword in district_value["districtKeywords"]:
        _add_keyword(MAP_KEYWORD_DIST, keyword, (province_key, district_key))

for province_key, divided_districts in DICT_PROVINCE_DISTRICT_DIVIDED.items():
    for divided_value in divided_districts.values():
        for district_key, district_hint in divided_value["districts"].items():
            VALID_PROV_DIST.add((province_key, district_key))
            for keyword in district_hint["wardKeywords"]:
                _add_keyword(MAP_KEYWORD_DIST, keyword, (province_key, district_key))

for ward_dataset in WARD_DATASETS:
    for province_key, districts in ward_dataset.items():
        for district_key, wards in districts.items():
            for ward_key, ward_value in wards.items():
                VALID_DIST_WARD.add((province_key, district_key, ward_key))
                VALID_PROV_DIST.add((province_key, district_key))
                VALID_PROV_DIST_WARD.add((province_key, district_key, ward_key))
                for keyword in ward_value["wardKeywords"]:
                    _add_keyword(MAP_KEYWORD_WARD, keyword, (province_key, district_key, ward_key))

PROVINCE_KEYWORDS = sorted(MAP_KEYWORD_PROV.keys(), key=len, reverse=True)
DISTRICT_KEYWORDS = sorted(MAP_KEYWORD_DIST.keys(), key=len, reverse=True)
WARD_KEYWORDS = sorted(MAP_KEYWORD_WARD.keys(), key=len, reverse=True)

PATTERN_PROVINCE = re.compile("|".join(re.escape(k) for k in PROVINCE_KEYWORDS), flags=re.IGNORECASE)
PATTERN_DISTRICT = re.compile("|".join(re.escape(k) for k in DISTRICT_KEYWORDS), flags=re.IGNORECASE)
PATTERN_WARD = re.compile("|".join(re.escape(k) for k in WARD_KEYWORDS), flags=re.IGNORECASE)

# Lookahead patterns allow collecting overlapping matches.
PATTERN_PROVINCE_LOOKAHEAD = re.compile(
    "(?=(" + "|".join(re.escape(k) for k in PROVINCE_KEYWORDS) + "))",
    flags=re.IGNORECASE,
)
PATTERN_DISTRICT_LOOKAHEAD = re.compile(
    "(?=(" + "|".join(re.escape(k) for k in DISTRICT_KEYWORDS) + "))",
    flags=re.IGNORECASE,
)
PATTERN_WARD_LOOKAHEAD = re.compile(
    "(?=(" + "|".join(re.escape(k) for k in WARD_KEYWORDS) + "))",
    flags=re.IGNORECASE,
)
PATTERN_LEGACY_DISTRICT_SIGNAL = re.compile(
    r"(thixa|quan|thanhpho)",
    flags=re.IGNORECASE,
)


@dataclass(frozen=True)
class _Match:
    value: Any
    start: int
    end: int
    keyword: str


@dataclass(frozen=True)
class _Candidate:
    province_key: str
    district_key: str
    ward_key: Optional[str]
    province_match: Optional[_Match]
    district_match: Optional[_Match]
    ward_match: Optional[_Match]


def _collect_matches(pattern: re.Pattern, mapping: dict, *sources: str, overlap: bool = False) -> list[_Match]:
    results = set()
    for source in sources:
        for match in pattern.finditer(source):
            keyword = match.group(1) if overlap else match.group()
            if not keyword:
                continue
            start = match.start()
            end = start + len(keyword)
            for value in mapping.get(keyword, set()):
                results.add(_Match(value=value, start=start, end=end, keyword=keyword))
    return sorted(results, key=lambda item: (item.end, len(item.keyword), -item.start), reverse=True)


def _overlap(first: _Match, second: _Match) -> bool:
    return max(first.start, second.start) < min(first.end, second.end)


def _best_match(matches: list[_Match]) -> Optional[_Match]:
    if not matches:
        return None
    return max(matches, key=lambda item: (item.end, len(item.keyword), -item.start))


def _candidate_rank(candidate: _Candidate) -> tuple:
    matches = [m for m in [candidate.province_match, candidate.district_match, candidate.ward_match] if m]
    return (
        len(matches),
        max(match.end for match in matches),
        sum(len(match.keyword) for match in matches),
        -min(match.start for match in matches),
    )


def _best_candidate(candidates: list[_Candidate]) -> Optional[_Candidate]:
    if not candidates:
        return None
    return max(candidates, key=_candidate_rank)


def _fill_province(unit: AdminUnit, province_key: str) -> None:
    province_value = DICT_PROVINCE[province_key]
    unit.province_key = province_key
    unit.province = province_value["province"]
    unit.short_province = province_value["provinceShort"]
    unit.province_code = province_value["provinceCode"]
    unit.latitude = province_value["provinceLat"]
    unit.longitude = province_value["provinceLon"]


def _fill_district(unit: AdminUnit, province_key: str, district_key: str) -> None:
    district_value = DICT_PROVINCE_DISTRICT.get(province_key, {}).get(district_key)
    if not district_value:
        return
    unit.district_key = district_key
    unit.district = district_value["district"]
    unit.short_district = district_value["districtShort"]
    unit.district_type = district_value["districtType"]
    unit.district_code = district_value["districtCode"]
    unit.latitude = district_value["districtLat"]
    unit.longitude = district_value["districtLon"]


def _fill_ward(unit: AdminUnit, province_key: str, district_key: str, ward_key: str) -> None:
    ward_value = None
    for ward_dataset in WARD_DATASETS:
        ward_value = ward_dataset.get(province_key, {}).get(district_key, {}).get(ward_key)
        if ward_value:
            break
    if not ward_value:
        return
    unit.ward_key = ward_key
    unit.ward = ward_value["ward"]
    unit.short_ward = ward_value["wardShort"]
    unit.ward_type = ward_value["wardType"]
    unit.ward_code = ward_value["wardCode"]
    unit.latitude = ward_value["wardLat"]
    unit.longitude = ward_value["wardLon"]


def parse_address_old_v2(
    address: str,
    keep_street: bool = True,
    level: int = 3,
) -> AdminUnit:
    """
    Parse legacy address by matching province, district and ward in parallel,
    then validating only combinations that exist in parser_legacy.json.

    Rules for level 3:
    - District and ward must be found as a valid pair.
    - If province is not found in text, missing either district or ward returns None immediately.
    - If province is found in text, only valid (province, district, ward) combinations are accepted.
    - Province-only input is allowed and returns the legacy province.
    """
    unit = AdminUnit(show_district=True)
    if level not in [1, 2, 3]:
        raise ValueError("Level must be 1, 2, or 3")

    # Step 1: Normalize raw input into two searchable forms:
    # - no-accent key
    # - accent-preserving key
    address_norm = unicode_normalize(address)
    address_key = key_normalize(address_norm, keep=[","])
    address_key_accented = key_normalize(address_norm, keep=[","], decode=False)

    # Step 2: Collect province/district/ward keyword matches in parallel.
    # Lookahead patterns are used so overlapping keywords are also captured.
    province_matches = _collect_matches(
        PATTERN_PROVINCE_LOOKAHEAD,
        MAP_KEYWORD_PROV,
        address_key,
        address_key_accented,
        overlap=True,
    )
    district_matches = _collect_matches(
        PATTERN_DISTRICT_LOOKAHEAD,
        MAP_KEYWORD_DIST,
        address_key,
        address_key_accented,
        overlap=True,
    )
    ward_matches = _collect_matches(
        PATTERN_WARD_LOOKAHEAD,
        MAP_KEYWORD_WARD,
        address_key,
        address_key_accented,
        overlap=True,
    )

    # Step 3: Build fast lookup maps for compatibility checks.
    province_matches_by_key = defaultdict(list)
    district_matches_by_pair = defaultdict(list)

    for match in province_matches:
        province_matches_by_key[match.value].append(match)

    for match in district_matches:
        district_matches_by_pair[match.value].append(match)

    # Step 4: Build valid dist-ward candidates only.
    # A ward match is kept only when it can pair with a compatible district match.
    dist_ward_candidates = []
    for ward_match in ward_matches:
        province_key, district_key, ward_key = ward_match.value
        if (province_key, district_key, ward_key) not in VALID_PROV_DIST_WARD:
            continue

        compatible_districts = [
            district_match
            for district_match in district_matches_by_pair.get((province_key, district_key), [])
            if not _overlap(district_match, ward_match)
        ]
        best_district_match = _best_match(compatible_districts)
        if best_district_match:
            dist_ward_candidates.append(
                _Candidate(
                    province_key=province_key,
                    district_key=district_key,
                    ward_key=ward_key,
                    province_match=None,
                    district_match=best_district_match,
                    ward_match=ward_match,
                )
            )

    # Step 5: Guard for new-formatted input.
    # In strict legacy mode, reject addresses that are parseable by the 2025 parser.
    # This prevents new-format wards from being coerced into legacy districts.
    unit_new = parse_address_new(address, keep_street=False, level=2)
    has_legacy_district_signal = bool(PATTERN_LEGACY_DISTRICT_SIGNAL.search(address_key))
    has_legacy_dist_ward_candidate = bool(dist_ward_candidates)
    if unit_new.ward_key and not has_legacy_district_signal and not has_legacy_dist_ward_candidate:
        raise ValueError(f"Address '{address}' is invalid old address")

    # Step 6: Resolve the best candidate based on requested parse level.
    if level == 3:
        best_dist_ward_candidate = _best_candidate(dist_ward_candidates)

        # If province is explicitly present, prefer dist-ward candidates that are
        # compatible with at least one matched province token in the same province.
        # This resolves cross-province ambiguities (same district/ward names).
        if province_matches and dist_ward_candidates:
            province_consistent_candidates = []
            for candidate in dist_ward_candidates:
                compatible_provinces = [
                    province_match
                    for province_match in province_matches_by_key.get(candidate.province_key, [])
                    if not _overlap(province_match, candidate.district_match)
                    and not _overlap(province_match, candidate.ward_match)
                ]
                best_province_match = _best_match(compatible_provinces)
                if best_province_match:
                    province_consistent_candidates.append(
                        _Candidate(
                            province_key=candidate.province_key,
                            district_key=candidate.district_key,
                            ward_key=candidate.ward_key,
                            province_match=best_province_match,
                            district_match=candidate.district_match,
                            ward_match=candidate.ward_match,
                        )
                    )
            if province_consistent_candidates:
                best_dist_ward_candidate = _best_candidate(province_consistent_candidates)

        if best_dist_ward_candidate:
            compatible_provinces = [
                province_match
                for province_match in province_matches_by_key.get(best_dist_ward_candidate.province_key, [])
                if not _overlap(province_match, best_dist_ward_candidate.district_match)
                and not _overlap(province_match, best_dist_ward_candidate.ward_match)
            ]
            best_province_match = _best_match(compatible_provinces)
            best_candidate = _Candidate(
                province_key=best_dist_ward_candidate.province_key,
                district_key=best_dist_ward_candidate.district_key,
                ward_key=best_dist_ward_candidate.ward_key,
                province_match=best_province_match,
                district_match=best_dist_ward_candidate.district_match,
                ward_match=best_dist_ward_candidate.ward_match,
            )
        elif province_matches:
            province_match = _best_match(province_matches)
            has_same_province_district = any(
                district_match.value[0] == province_match.value
                for district_match in district_matches
            )
            has_same_province_ward = any(
                ward_match.value[0] == province_match.value
                for ward_match in ward_matches
            )

            if has_same_province_district or has_same_province_ward:
                return unit

            best_candidate = _Candidate(
                province_key=province_match.value,
                district_key="",
                ward_key=None,
                province_match=province_match,
                district_match=None,
                ward_match=None,
            )
        else:
            return unit

    elif level == 2:
        district_candidates = []
        for district_match in district_matches:
            province_key, district_key = district_match.value
            compatible_provinces = [
                province_match
                for province_match in province_matches_by_key.get(province_key, [])
                if not _overlap(province_match, district_match)
            ]
            district_candidates.append(
                _Candidate(
                    province_key=province_key,
                    district_key=district_key,
                    ward_key=None,
                    province_match=_best_match(compatible_provinces),
                    district_match=district_match,
                    ward_match=None,
                )
            )

        if province_matches:
            district_candidates = [candidate for candidate in district_candidates if candidate.province_match]
        best_candidate = _best_candidate(district_candidates)
        if not best_candidate:
            return unit

    else:
        province_match = _best_match(province_matches)
        if province_match:
            best_candidate = _Candidate(
                province_key=province_match.value,
                district_key="",
                ward_key=None,
                province_match=province_match,
                district_match=None,
                ward_match=None,
            )
        else:
            best_candidate = _best_candidate(dist_ward_candidates)
            if not best_candidate and district_matches:
                district_match = _best_match(district_matches)
                best_candidate = _Candidate(
                    province_key=district_match.value[0],
                    district_key=district_match.value[1],
                    ward_key=None,
                    province_match=None,
                    district_match=district_match,
                    ward_match=None,
                )
        if not best_candidate:
            return unit

    # Step 7: Materialize candidate into AdminUnit fields.
    _fill_province(unit, best_candidate.province_key)

    if level >= 2 and best_candidate.district_key:
        _fill_district(unit, best_candidate.province_key, best_candidate.district_key)

    if level == 3 and best_candidate.ward_key:
        _fill_ward(unit, best_candidate.province_key, best_candidate.district_key, best_candidate.ward_key)

    # Step 8: Select the highest resolved keyword for downstream street extraction.
    highest_level_keyword = None
    if level == 3 and best_candidate.ward_match:
        highest_level_keyword = best_candidate.ward_match.keyword
    elif level >= 2 and best_candidate.district_match:
        highest_level_keyword = best_candidate.district_match.keyword
    elif best_candidate.province_match:
        highest_level_keyword = best_candidate.province_match.keyword

    # Step 9: Extract street from the left-side address segment when applicable.
    special_zone = ["huyenbachlongvi", "huyenconco", "huyenhoangsa", "huyenlyson", "huyencondao"]
    if keep_street and (unit.ward_key or (address_key.count(",") >= 3) or (unit.district_key in special_zone)):
        valid_matches = [
            match
            for match in [best_candidate.province_match, best_candidate.district_match, best_candidate.ward_match]
            if match
        ]
        if valid_matches:
            admin_start_pos = min(match.start for match in valid_matches)
            address_key_street = address_key[:admin_start_pos]
            street = extract_street(
                address=address_norm,
                address_key=address_key_street,
                highest_level_keyword=highest_level_keyword,
            )
        else:
            street = extract_street(address=address_norm, address_key=address_key, highest_level_keyword=None)

        if street:
            unit.street = street

    return unit
