# --------------------------------------------------------------------------------
# Copyright (c) 2025 Zehao Yang
#
# Author: Zehao Yang
#
# This module implements data sampling functions:
# • Trigger-based sampling with time and/or price movement conditions
# • Recency-weighted sampling density adjustment
# --------------------------------------------------------------------------------


import _ext.sampler as _sampler


DEFAULT_SAMPLER_PARAMS_DICT = {
    'recency_method': '',
    'recency_limit': 1,
    'is_invalid_skipped': True,
    'trigger_mode': 'any',
    'min_time': 0,
    'min_move': 0
}


def sample_data(features_map, sampler_params_dict):
    features_map = _sampler.sample_data(features_map, sampler_params_dict)
    return features_map
