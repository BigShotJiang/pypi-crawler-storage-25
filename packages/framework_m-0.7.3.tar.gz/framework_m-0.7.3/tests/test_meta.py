"""Tests for the framework-m meta-package."""

from unittest.mock import patch


def test_framework_m_version_fallback() -> None:
    """Test that __version__ falls back to 0.0.0 if package is not installed."""
    import importlib.metadata

    with patch(
        "importlib.metadata.version",
        side_effect=importlib.metadata.PackageNotFoundError,
    ):
        import framework_m

        importlib.reload(framework_m)
        assert framework_m.__version__ == "0.0.0"

    # Reload again without the patch to restore the correct version for other tests
    importlib.reload(framework_m)


def test_framework_m_cli_imports() -> None:
    """Test that the CLI modules can be imported properly."""
    import framework_m.cli
    import framework_m.cli.main

    assert framework_m.cli.utility is not None
    assert framework_m.cli.main.app is not None
