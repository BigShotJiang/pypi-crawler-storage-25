"""RFC-0008 correction integration tests (Phase 12.3)."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import pytest
from framework_m_core.doctypes.activity_log import ActivityLog
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.domain.mixins import DocStatus, SubmittableMixin, VersionedMixin
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_standard.adapters.audit.database_audit import DatabaseAuditAdapter
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from framework_m.core.services.correction import CorrectionService


class CorrectableInvoice(BaseDocType, VersionedMixin, SubmittableMixin):
    """Submittable + versioned DocType for correction-flow integration."""

    customer: str = Field(description="Customer")
    amount: float = Field(default=0.0, description="Amount")


class _SessionBoundRepositoryAdapter:
    """Expose RepositoryProtocol-style methods backed by a bound DB session."""

    def __init__(
        self,
        repo: GenericRepository[Any],
        session: AsyncSession,
    ) -> None:
        self._repo = repo
        self._session = session

    async def get(
        self,
        id: Any,
        as_of: datetime | None = None,
    ) -> Any | None:
        return await self._repo.get(self._session, id, as_of=as_of)

    async def save(
        self,
        entity: Any,
        version: int | None = None,
    ) -> Any:
        return await self._repo.save(self._session, entity, version=version)

    async def list(
        self,
        filters: list[Any] | None = None,
        order_by: list[Any] | None = None,
        limit: int = 20,
        offset: int = 0,
        as_of: datetime | None = None,
    ) -> Any:
        return await self._repo.list_entities(
            self._session,
            filters=filters,
            order_by=order_by,
            limit=limit,
            offset=offset,
            as_of=as_of,
        )


@pytest.fixture
def test_user() -> UserContext:
    """User context used by correction service audit logging."""
    return UserContext(
        id="user-001",
        email="user-001@example.com",
        roles=["Employee"],
    )


@pytest.fixture
async def correction_stack(
    db_session: AsyncSession,
    clean_tables: MetaData,
) -> tuple[
    GenericRepository[CorrectableInvoice],
    object,
    DatabaseAuditAdapter,
    CorrectionService,
]:
    """Create repository/audit/correction service wired to real SQLite tables."""
    mapper = SchemaMapper()
    tables = mapper.create_versioned_tables(
        CorrectableInvoice,
        clean_tables,
        {"compliance": {"versioning_enabled": True}},
    )
    invoice_table, history_table = tables[0], tables[1]
    activity_table = mapper.create_table(ActivityLog, clean_tables)

    conn = await db_session.connection()
    await conn.run_sync(clean_tables.create_all)

    invoice_repo = GenericRepository(CorrectableInvoice, invoice_table)
    activity_repo = GenericRepository(ActivityLog, activity_table)

    invoice_repo_adapter = _SessionBoundRepositoryAdapter(invoice_repo, db_session)
    activity_repo_adapter = _SessionBoundRepositoryAdapter(activity_repo, db_session)

    audit_adapter = DatabaseAuditAdapter(repository=activity_repo_adapter)
    correction_service = CorrectionService(
        repository=invoice_repo_adapter,
        audit=audit_adapter,
    )

    return invoice_repo, history_table, audit_adapter, correction_service


async def _create_submitted_invoice(
    repo: GenericRepository[CorrectableInvoice],
    session: AsyncSession,
    name: str,
) -> CorrectableInvoice:
    """Persist a submitted invoice record for correction tests."""
    invoice = CorrectableInvoice(
        name=name,
        customer="Acme Corp",
        amount=100.0,
    )
    await repo.save(session, invoice)

    invoice.docstatus = DocStatus.SUBMITTED
    await repo.save(session, invoice)

    return invoice


@pytest.mark.asyncio
async def test_rfc_0008_correction_amend_flow(
    correction_stack: tuple[
        GenericRepository[CorrectableInvoice],
        object,
        DatabaseAuditAdapter,
        CorrectionService,
    ],
    db_session: AsyncSession,
    monkeypatch: pytest.MonkeyPatch,
    test_user: UserContext,
) -> None:
    """amend() should cancel the original and create a new draft with new name."""
    monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

    repo, _history_table, audit, correction_service = correction_stack
    original = await _create_submitted_invoice(repo, db_session, "INV-100")

    amended = await correction_service.amend(
        doc=original,
        reason="Typo fix",
        user=test_user,
    )

    persisted_original = await repo.get(db_session, original.id)
    assert persisted_original is not None
    assert persisted_original.docstatus == DocStatus.CANCELLED

    assert amended.id != original.id
    assert amended.name == "INV-100-1"
    assert amended.docstatus == DocStatus.DRAFT

    amended_lookup = await repo.get_by_name(db_session, "INV-100-1")
    assert amended_lookup is not None
    assert amended_lookup.docstatus == DocStatus.DRAFT

    entries = await audit.query(
        filters={"doctype": "CorrectableInvoice", "document_id": "INV-100"},
        limit=100,
        offset=0,
    )
    assert any(entry.action == "amend" for entry in entries)


@pytest.mark.asyncio
async def test_rfc_0008_correction_in_place_edit_flow(
    correction_stack: tuple[
        GenericRepository[CorrectableInvoice],
        object,
        DatabaseAuditAdapter,
        CorrectionService,
    ],
    db_session: AsyncSession,
    monkeypatch: pytest.MonkeyPatch,
    test_user: UserContext,
) -> None:
    """in_place_edit() should keep identity, reset docstatus, and record audit/history."""
    monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

    repo, history_table, audit, correction_service = correction_stack
    original = await _create_submitted_invoice(repo, db_session, "INV-200")

    edited = await correction_service.in_place_edit(
        doc=original,
        reason="Operational correction",
        user=test_user,
    )

    assert edited.id == original.id
    assert edited.name == original.name
    assert edited.docstatus == DocStatus.DRAFT

    persisted = await repo.get(db_session, original.id)
    assert persisted is not None
    assert persisted.docstatus == DocStatus.DRAFT

    history_count = await db_session.scalar(
        select(func.count())
        .select_from(history_table)
        .where(history_table.c.id == original.id)
    )
    assert history_count is not None
    assert history_count >= 3

    entries = await audit.query(
        filters={"doctype": "CorrectableInvoice", "document_id": "INV-200"},
        limit=100,
        offset=0,
    )
    assert any(entry.action == "in_place_edit" for entry in entries)
