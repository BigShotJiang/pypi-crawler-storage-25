"""RFC-0008 versioning integration tests (Phase 12.2)."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime

import pytest
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.domain.mixins import VersionedMixin
from framework_m_core.exceptions import TemporalQueryNotSupportedError
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData, func, select
from sqlalchemy.ext.asyncio import AsyncSession


class VersionedInvoice(BaseDocType, VersionedMixin):
    """Versioned DocType for temporal integration checks."""

    title: str = Field(description="Title")
    total: float = Field(default=0.0, description="Amount")


@pytest.fixture
async def versioned_repo(
    db_session: AsyncSession,
    clean_tables: MetaData,
) -> tuple[GenericRepository[VersionedInvoice], object]:
    """Create a versioned repository with provisioned history table."""
    mapper = SchemaMapper()
    tables = mapper.create_versioned_tables(
        VersionedInvoice,
        clean_tables,
        {"compliance": {"versioning_enabled": True}},
    )

    main_table, history_table = tables[0], tables[1]
    conn = await db_session.connection()
    await conn.run_sync(clean_tables.create_all)

    return GenericRepository(VersionedInvoice, main_table), history_table


@pytest.mark.asyncio
async def test_rfc_0008_versioning_history_and_temporal_query(
    versioned_repo: tuple[GenericRepository[VersionedInvoice], object],
    db_session: AsyncSession,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """Versioned saves should create history and support as_of lookup."""
    monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")

    repo, history_table = versioned_repo

    invoice = VersionedInvoice(name="VINV-001", title="v1", total=10.0)
    await repo.save(db_session, invoice)

    between = datetime.now(UTC)
    await asyncio.sleep(0.01)

    invoice.total = 20.0
    await repo.save(db_session, invoice)

    history_count = await db_session.scalar(
        select(func.count())
        .select_from(history_table)
        .where(history_table.c.id == invoice.id)
    )
    assert history_count == 2

    version_rows = await db_session.execute(
        select(history_table)
        .where(history_table.c.id == invoice.id)
        .order_by(history_table.c._version_no.asc())
    )
    version_numbers = [row._mapping["_version_no"] for row in version_rows.fetchall()]
    assert version_numbers == [1, 2]

    as_of_doc = await repo.get(db_session, invoice.id, as_of=between)
    assert as_of_doc is not None
    assert as_of_doc.total == pytest.approx(10.0)


@pytest.mark.asyncio
async def test_rfc_0008_versioning_disabled_rejects_temporal_query(
    versioned_repo: tuple[GenericRepository[VersionedInvoice], object],
    db_session: AsyncSession,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """as_of must fail fast when versioning is disabled."""
    repo, _history_table = versioned_repo

    invoice = VersionedInvoice(name="VINV-002", title="v1", total=33.0)

    monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "true")
    await repo.save(db_session, invoice)

    monkeypatch.setenv("FRAMEWORK_M_STRONGSYNC_VERSIONING", "false")
    with pytest.raises(TemporalQueryNotSupportedError):
        await repo.get(db_session, invoice.id, as_of=datetime.now(UTC))
