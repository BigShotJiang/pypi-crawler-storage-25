"""RFC-0008 audit integration tests (Phase 12.1)."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from datetime import datetime
from typing import Any

import pytest
from framework_m_core.doctypes.activity_log import ActivityLog
from framework_m_core.domain.base_controller import BaseController
from framework_m_core.domain.base_doctype import BaseDocType, Field
from framework_m_core.domain.mixins import AuditMixin, DocStatus, SubmittableMixin
from framework_m_core.exceptions import ImmutableDocumentError
from framework_m_core.interfaces.audit import AuditEntry, AuditLogProtocol
from framework_m_standard.adapters.audit.database_audit import DatabaseAuditAdapter
from framework_m_standard.adapters.db.generic_repository import GenericRepository
from framework_m_standard.adapters.db.schema_mapper import SchemaMapper
from sqlalchemy import MetaData
from sqlalchemy.ext.asyncio import AsyncSession


class AuditedInvoice(BaseDocType, AuditMixin, SubmittableMixin):
    """Audited + submittable DocType for integration tests."""

    title: str = Field(description="Invoice title")
    total: float = Field(default=0.0, description="Invoice total")


class AuditedInvoiceController(BaseController[AuditedInvoice]):
    """Controller that supports test-time audit adapter injection."""

    audit_adapter: AuditLogProtocol | None = None

    def __init__(self, doc: AuditedInvoice) -> None:
        super().__init__(doc)
        self._audit_adapter = type(self).audit_adapter


class _SessionBoundActivityRepository:
    """Expose RepositoryProtocol-style methods backed by a bound DB session."""

    def __init__(
        self,
        repo: GenericRepository[ActivityLog],
        session: AsyncSession,
    ) -> None:
        self._repo = repo
        self._session = session

    async def get(
        self,
        id: Any,
        as_of: datetime | None = None,
    ) -> ActivityLog | None:
        return await self._repo.get(self._session, id, as_of=as_of)

    async def save(
        self,
        entity: ActivityLog,
        version: int | None = None,
    ) -> ActivityLog:
        return await self._repo.save(self._session, entity, version=version)

    async def list(
        self,
        filters: list[Any] | None = None,
        order_by: list[Any] | None = None,
        limit: int = 20,
        offset: int = 0,
        as_of: datetime | None = None,
    ) -> Any:
        return await self._repo.list_entities(
            self._session,
            filters=filters,
            order_by=order_by,
            limit=limit,
            offset=offset,
            as_of=as_of,
        )


@pytest.fixture
async def audit_stack(
    db_session: AsyncSession,
    clean_tables: MetaData,
) -> AsyncGenerator[
    tuple[GenericRepository[AuditedInvoice], DatabaseAuditAdapter], None
]:
    """Create repositories and a database-backed audit adapter."""
    mapper = SchemaMapper()
    audited_table = mapper.create_table(AuditedInvoice, clean_tables)
    activity_table = mapper.create_table(ActivityLog, clean_tables)

    conn = await db_session.connection()
    await conn.run_sync(clean_tables.create_all)

    invoice_repo = GenericRepository(
        model=AuditedInvoice,
        table=audited_table,
        controller_class=AuditedInvoiceController,
    )
    activity_repo = GenericRepository(model=ActivityLog, table=activity_table)
    audit_repo_adapter = _SessionBoundActivityRepository(activity_repo, db_session)
    audit_adapter = DatabaseAuditAdapter(repository=audit_repo_adapter)

    AuditedInvoiceController.audit_adapter = audit_adapter
    yield invoice_repo, audit_adapter
    AuditedInvoiceController.audit_adapter = None


async def _entries_for_document(
    audit: DatabaseAuditAdapter,
    document_id: str,
) -> list[AuditEntry]:
    """Query all audit entries for an AuditedInvoice by document reference."""
    return await audit.query(
        filters={"doctype": "AuditedInvoice", "document_id": document_id},
        limit=100,
        offset=0,
    )


@pytest.mark.asyncio
async def test_rfc_0008_audit_flow_end_to_end(
    audit_stack: tuple[GenericRepository[AuditedInvoice], DatabaseAuditAdapter],
    db_session: AsyncSession,
) -> None:
    """Insert/update/submit should audit, while submitted edits are blocked."""
    repo, audit = audit_stack

    invoice = AuditedInvoice(name="INV-001", title="Initial", total=10.0)

    # Create -> create audit entry
    await repo.save(db_session, invoice)
    entries_after_create = await _entries_for_document(audit, "INV-001")
    assert any(entry.action == "create" for entry in entries_after_create)

    # Update -> update audit entry with diff
    invoice.total = 25.0
    await repo.save(db_session, invoice)
    entries_after_update = await _entries_for_document(audit, "INV-001")
    update_entries = [
        entry for entry in entries_after_update if entry.action == "update"
    ]
    assert len(update_entries) >= 1
    assert update_entries[0].changes == {"total": {"old": 10.0, "new": 25.0}}

    # Submit -> submit audit entry
    invoice.docstatus = DocStatus.SUBMITTED
    await repo.save(db_session, invoice)
    entries_after_submit = await _entries_for_document(audit, "INV-001")
    assert any(entry.action == "submit" for entry in entries_after_submit)

    # Direct edit on submitted doc -> immutable error and no extra update entry
    update_count_before_illegal = len(
        [entry for entry in entries_after_submit if entry.action == "update"]
    )

    illegal_edit = invoice.model_copy(deep=True)
    illegal_edit.total = 99.0

    with pytest.raises(ImmutableDocumentError):
        await repo.save(db_session, illegal_edit)

    entries_after_illegal = await _entries_for_document(audit, "INV-001")
    update_count_after_illegal = len(
        [entry for entry in entries_after_illegal if entry.action == "update"]
    )
    assert update_count_after_illegal == update_count_before_illegal
