"""Tests for OAuthAdapter (Indie Mode OAuth2 via authlib).

TDD scope (work-item-20 / section 1):
- Authorization URL generation for common providers (Google/GitHub).
- Callback handling that hydrates framework models for linking/auth context.
"""

from __future__ import annotations

import asyncio
from urllib.parse import parse_qs, urlparse

import pytest


@pytest.mark.asyncio
async def test_oauth_adapter_generates_google_authorization_url() -> None:
    """OAuthAdapter should generate a valid Google authorization URL."""
    from framework_m_standard.adapters.auth.oauth import OAuthAdapter

    adapter = OAuthAdapter(
        provider_name="google",
        client_id="google-client-id",
        client_secret="google-client-secret",
        authorization_url="https://accounts.google.com/o/oauth2/v2/auth",
        token_url="https://oauth2.googleapis.com/token",
        userinfo_url="https://www.googleapis.com/oauth2/v3/userinfo",
        scope="openid email profile",
    )

    url = await adapter.get_authorization_url(
        state="state-123",
        redirect_uri="https://app.example.com/api/v1/auth/oauth/google/callback",
    )

    parsed = urlparse(url)
    query = parse_qs(parsed.query)

    assert parsed.scheme == "https"
    assert parsed.netloc == "accounts.google.com"
    assert query["client_id"][0] == "google-client-id"
    assert query["state"][0] == "state-123"
    assert query["redirect_uri"][0].endswith("/oauth/google/callback")


@pytest.mark.asyncio
async def test_oauth_adapter_generates_github_authorization_url() -> None:
    """OAuthAdapter should generate a valid GitHub authorization URL."""
    from framework_m_standard.adapters.auth.oauth import OAuthAdapter

    adapter = OAuthAdapter(
        provider_name="github",
        client_id="github-client-id",
        client_secret="github-client-secret",
        authorization_url="https://github.com/login/oauth/authorize",
        token_url="https://github.com/login/oauth/access_token",
        userinfo_url="https://api.github.com/user",
        scope="read:user user:email",
        emails_url="https://api.github.com/user/emails",
    )

    url = await adapter.get_authorization_url(
        state="state-456",
        redirect_uri="https://app.example.com/api/v1/auth/oauth/github/callback",
    )

    parsed = urlparse(url)
    query = parse_qs(parsed.query)

    assert parsed.scheme == "https"
    assert parsed.netloc == "github.com"
    assert query["client_id"][0] == "github-client-id"
    assert query["state"][0] == "state-456"
    assert query["scope"][0] == "read:user user:email"


@pytest.mark.asyncio
async def test_oauth_adapter_handle_callback_hydrates_social_account_and_user_context(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    """handle_callback should exchange code, fetch profile, and hydrate models."""
    from framework_m_core.interfaces.oauth import OAuth2Token, OAuth2UserInfo
    from framework_m_standard.adapters.auth.oauth import OAuthAdapter

    adapter = OAuthAdapter(
        provider_name="google",
        client_id="google-client-id",
        client_secret="google-client-secret",
        authorization_url="https://accounts.google.com/o/oauth2/v2/auth",
        token_url="https://oauth2.googleapis.com/token",
        userinfo_url="https://www.googleapis.com/oauth2/v3/userinfo",
        scope="openid email profile",
    )

    async def fake_exchange_code(*, code: str, redirect_uri: str) -> OAuth2Token:
        assert code == "oauth-code-123"
        assert redirect_uri.endswith("/oauth/google/callback")
        return await asyncio.sleep(
            0, result=OAuth2Token(access_token="token-abc", token_type="Bearer")
        )

    async def fake_get_user_info(token: OAuth2Token) -> OAuth2UserInfo:
        assert token.access_token == "token-abc"
        return await asyncio.sleep(
            0,
            result=OAuth2UserInfo(
                provider="google",
                provider_user_id="provider-user-1",
                email="jane@example.com",
                display_name="Jane Doe",
                avatar_url="https://cdn.example.com/avatar.png",
            ),
        )

    monkeypatch.setattr(adapter, "exchange_code", fake_exchange_code)
    monkeypatch.setattr(adapter, "get_user_info", fake_get_user_info)

    result = await adapter.handle_callback(
        code="oauth-code-123",
        redirect_uri="https://app.example.com/api/v1/auth/oauth/google/callback",
        local_user_id="user-123",
    )

    assert result.token.access_token == "token-abc"
    assert result.user_info.provider_user_id == "provider-user-1"

    social_account = result.social_account
    assert social_account.provider == "google"
    assert social_account.provider_user_id == "provider-user-1"
    assert social_account.user_id == "user-123"
    assert social_account.email == "jane@example.com"

    user_context = result.user_context
    assert user_context.id == "user-123"
    assert user_context.email == "jane@example.com"
    assert user_context.name == "Jane Doe"
    assert "User" in user_context.roles
