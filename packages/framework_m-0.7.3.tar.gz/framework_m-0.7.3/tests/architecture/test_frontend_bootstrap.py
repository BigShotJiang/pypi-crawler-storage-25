"""Release-gate tests for frontend bootstrap templates.

These tests guard template/static bootstrap parity and prevent regressions
such as sync XHR in startup config loading.
"""

from pathlib import Path

import pytest

REPO_ROOT = Path(__file__).resolve().parents[4]
TEMPLATE_INDEX = (
    REPO_ROOT
    / "apps/studio/src/framework_m_studio/templates/plugin/index.html.template"
)
STATIC_INDEX = (
    REPO_ROOT / "libs/framework-m-standard/src/framework_m_standard/static/index.html"
)


@pytest.fixture(scope="class")
def html_sources() -> list[str]:
    """Provides HTML content from template and static index if it exists."""
    sources = [TEMPLATE_INDEX.read_text(encoding="utf-8")]
    if STATIC_INDEX.exists():
        sources.append(STATIC_INDEX.read_text(encoding="utf-8"))
    return sources


class TestFrontendBootstrap:
    """Release gates for template/static frontend bootstrap files."""

    def test_template_and_static_use_oauth_provider_injection(
        self, html_sources: list[str]
    ) -> None:
        for html in html_sources:
            assert "Array.isArray" in html
            assert "globalThis.__FRAMEWORK_OAUTH_PROVIDERS__" in html

    def test_template_and_static_do_not_use_sync_xhr_bootstrap(
        self, html_sources: list[str]
    ) -> None:
        forbidden_tokens = [
            "new XMLHttpRequest()",
            '.open("GET"',
            ".open('GET'",
            ".send(null)",
        ]
        for html in html_sources:
            for token in forbidden_tokens:
                assert token not in html

    def test_template_and_static_define_runtime_framework_config(
        self, html_sources: list[str]
    ) -> None:
        for html in html_sources:
            assert "__FRAMEWORK_CONFIG__" in html
            assert "apiBaseUrl" in html

    def test_mfe_remotes_are_not_injected_into_html(
        self, html_sources: list[str]
    ) -> None:
        """
        MFE plugin remotes must be discovered at runtime via
        GET /api/v1/frontend/remotes, never injected inline into index.html.

        This test is a permanent architectural gate.
        """
        forbidden_tokens = [
            "__FRAMEWORK_M_REMOTES__",
        ]
        for html in html_sources:
            for token in forbidden_tokens:
                assert token not in html, (
                    f"'{token}' must not be injected into index.html. "
                    "Use GET /api/v1/frontend/remotes instead."
                )
