"""Correction service implementing amend, restore, and in-place edit flows."""

from __future__ import annotations

import re
from typing import Any

from framework_m_core.domain.base_controller import BaseController
from framework_m_core.domain.base_doctype import BaseDocType
from framework_m_core.domain.mixins import DocStatus
from framework_m_core.interfaces.audit import AuditLogProtocol
from framework_m_core.interfaces.auth_context import UserContext
from framework_m_core.interfaces.repository import RepositoryProtocol


class CorrectionService:
    """Service for RFC-0008 correction workflows on submitted documents."""

    def __init__(
        self,
        repository: RepositoryProtocol[BaseDocType],
        audit: AuditLogProtocol,
    ) -> None:
        self._repository = repository
        self._audit = audit

    async def amend(
        self,
        doc: BaseDocType,
        reason: str,
        user: UserContext,
    ) -> BaseDocType:
        """Cancel submitted doc and create a new draft copy with incremented name."""
        self._ensure_submitted(doc)

        cancelled = doc.model_copy(deep=True)
        if hasattr(cancelled, "docstatus"):
            cancelled.docstatus = DocStatus.CANCELLED
        await self._repository.save(cancelled)

        amended = self._clone_with_updates(
            source=doc,
            new_name=self._next_amended_name(doc.name),
            docstatus=DocStatus.DRAFT,
            drop_id=True,
        )
        saved_amended = await self._repository.save(amended)

        await self._audit.log(
            user_id=user.id,
            action="amend",
            doctype=type(doc).__name__,
            document_id=self._document_ref(doc),
            changes=None,
            metadata={"reason": reason},
        )

        return saved_amended

    async def restore(
        self,
        doc: BaseDocType,
        snapshot_data: dict[str, Any],
        reason: str,
        user: UserContext,
    ) -> BaseDocType:
        """Cancel submitted doc and recreate a submitted document from snapshot data."""
        self._ensure_submitted(doc)
        if not snapshot_data:
            raise ValueError("snapshot_data cannot be empty")

        cancelled = doc.model_copy(deep=True)
        if hasattr(cancelled, "docstatus"):
            cancelled.docstatus = DocStatus.CANCELLED
        await self._repository.save(cancelled)

        restored_data = dict(snapshot_data)
        restored_data.pop("id", None)
        restored_data["name"] = self._next_amended_name(doc.name)
        restored_data["docstatus"] = DocStatus.SUBMITTED

        restored_doc = type(doc).model_validate(restored_data)
        saved_restored = await self._repository.save(restored_doc)

        await self._audit.log(
            user_id=user.id,
            action="restore",
            doctype=type(doc).__name__,
            document_id=self._document_ref(doc),
            changes=None,
            metadata={"reason": reason},
        )

        return saved_restored

    async def in_place_edit(
        self,
        doc: BaseDocType,
        reason: str,
        user: UserContext,
    ) -> BaseDocType:
        """Keep same document identity, snapshot history, then reset to draft."""
        if not getattr(type(doc), "_versioning_enabled", False):
            raise ValueError("in_place_edit requires VersionedMixin")

        self._ensure_submitted(doc)

        history_snapshot = doc.model_copy(deep=True)
        await self._repository.save(history_snapshot)

        editable = doc.model_copy(deep=True)
        if hasattr(editable, "docstatus"):
            editable.docstatus = DocStatus.DRAFT

        controller: BaseController[BaseDocType] = BaseController(editable)
        await controller._validate_submitted_changes(editable, doc)

        saved_editable = await self._repository.save(editable)

        await self._audit.log(
            user_id=user.id,
            action="in_place_edit",
            doctype=type(doc).__name__,
            document_id=self._document_ref(doc),
            changes=None,
            metadata={"reason": reason},
        )

        return saved_editable

    def _next_amended_name(self, name: str | None) -> str:
        """Return incremented amended name: INV-001 -> INV-001-1, INV-001-1 -> INV-001-2."""
        base_name = name or "DOC"
        # Only treat trailing numeric segment as amendment counter when
        # a prior amendment segment already exists (at least 2 hyphens).
        if base_name.count("-") < 2:
            return f"{base_name}-1"

        match = re.match(r"^(.*)-(\d+)$", base_name)
        if match is None:
            return f"{base_name}-1"

        prefix = match.group(1)
        number = int(match.group(2))
        return f"{prefix}-{number + 1}"

    def _ensure_submitted(self, doc: BaseDocType) -> None:
        """Validate that the document is in submitted state."""
        if not hasattr(doc, "docstatus"):
            raise ValueError("Only submitted documents can be corrected")

        if doc.docstatus != DocStatus.SUBMITTED:
            raise ValueError("Only submitted documents can be corrected")

    def _clone_with_updates(
        self,
        source: BaseDocType,
        new_name: str,
        docstatus: DocStatus,
        *,
        drop_id: bool,
    ) -> BaseDocType:
        """Clone a document and apply correction-flow identity/status updates."""
        data = source.model_dump(mode="python")
        if drop_id:
            data.pop("id", None)
        data["name"] = new_name
        if "docstatus" in type(source).model_fields:
            data["docstatus"] = docstatus
        return type(source).model_validate(data)

    def _document_ref(self, doc: BaseDocType) -> str:
        """Return preferred audit document reference (name first, then id)."""
        if doc.name:
            return str(doc.name)
        return str(doc.id)


__all__ = ["CorrectionService"]
