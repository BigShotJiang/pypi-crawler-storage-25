"""Service-layer components for Framework M."""

from framework_m.core.services.correction import CorrectionService

__all__ = ["CorrectionService"]
