# API Reference - Converso Media Downloader

## Overview

Converso Media Downloader provides three interfaces:

1. **Python API** - Direct programmatic access
2. **REST API** - HTTP endpoints for remote access
3. **CLI** - Command-line interface

This guide covers all three with complete examples.

---

## Python API

### Installation

```bash
pip install converso-ytdl
```

### Basic Usage

```python
from converso_ytdl import MediaDownloader, DownloadConfig

# Create configuration
config = DownloadConfig(
    output_dir="downloads",
    video_container="mkv",
    verbose=True
)

# Create downloader
downloader = MediaDownloader(config)

# Download video
result = downloader.download_video("https://youtu.be/...", config)
print(result)
```

---

## Classes and Functions

### `DownloadConfig`

Configuration dataclass for all download operations.

```python
from converso_ytdl import DownloadConfig

config = DownloadConfig(
    # Output
    output_dir: str = "downloads",
    output_template: str = "%(title)s.%(ext)s",
    
    # Video settings
    video_quality: str = "best",
    video_container: str = "mkv",  # mkv, mp4, webm
    embed_thumbnail: bool = True,
    embed_metadata: bool = True,
    
    # Audio settings
    audio_codec: str = "flac",      # wav, flac, mp3, aac, opus, ogg
    audio_sample_rate: int = 96000, # Hz
    audio_bit_depth: int = 24,      # bits
    
    # Subtitle settings
    sub_langs: str = "en",          # comma-separated
    sub_format: str = "vtt",        # vtt, srt, ass
    
    # Network
    proxy: str | None = None,
    cookies: str | None = None,
    retries: int = 5,
    socket_timeout: int = 30,
    
    # Batch/Playlist
    workers: int = 2,
    delay: float = 0.5,
    archive: str | None = None,
    
    # Logging
    verbose: bool = False,
    log_file: str | None = None,
    
    # Advanced
    user_agent: str | None = None,
    rate_limit: int | None = None,
)
```

**Example**:
```python
config = DownloadConfig(
    output_dir="my_videos",
    video_container="mp4",
    audio_codec="aac",
    audio_sample_rate=192000,
    workers=4,
    verbose=True,
    log_file="download.log"
)
```

### `DownloadResult`

Result dataclass returned from downloads.

```python
from converso_ytdl import DownloadResult

result = downloader.download_video("https://youtu.be/...", config)

# Access result fields
print(result.status)        # "success", "failed", "cancelled"
print(result.output_file)   # Path to downloaded file
print(result.title)         # Video title
print(result.duration)      # Duration in seconds
print(result.resolution)    # e.g. "1920x1080"
print(result.file_size)     # Size in bytes
print(result.format_id)     # Format ID used
print(result.uploader)      # Channel/uploader name
print(result.upload_date)   # Upload date
print(result.views)         # View count
print(result.error)         # Error message (if failed)
print(result.start_time)    # Datetime when download started
print(result.end_time)      # Datetime when download ended
print(result.duration_sec)  # Time taken in seconds
```

**Methods**:
```python
# Serialize to JSON
json_str = result.to_json()

# Convert to dict
result_dict = result.to_dict()
```

### `MediaDownloader`

Main downloader class.

```python
from converso_ytdl import MediaDownloader, DownloadConfig

downloader = MediaDownloader(config)
```

#### Methods

##### `download_video()`

Download best-quality video.

**Signature**:
```python
def download_video(
    self,
    url: str,
    config: DownloadConfig | None = None
) -> DownloadResult:
    """Download best-quality video from URL."""
```

**Parameters**:
- `url` (str): Video URL
- `config` (DownloadConfig): Override default config

**Returns**: `DownloadResult`

**Example**:
```python
result = downloader.download_video("https://youtu.be/video_id")
if result.status == "success":
    print(f"Downloaded: {result.output_file}")
    print(f"Resolution: {result.resolution}")
else:
    print(f"Error: {result.error}")
```

##### `download_audio()`

Extract audio as WAV, FLAC, MP3, AAC, Opus, or OGG.

**Signature**:
```python
def download_audio(
    self,
    url: str,
    config: DownloadConfig | None = None
) -> DownloadResult:
    """Download audio in configured format."""
```

**Example**:
```python
config = DownloadConfig(
    audio_codec="flac",
    audio_sample_rate=192000,
    audio_bit_depth=24
)

result = downloader.download_audio("https://youtu.be/...", config)
print(f"Downloaded: {result.output_file}")
```

##### `download_playlist()`

Download entire playlist.

**Signature**:
```python
def download_playlist(
    self,
    url: str,
    config: DownloadConfig | None = None
) -> DownloadResult:
    """Download entire playlist."""
```

**Example**:
```python
config = DownloadConfig(
    archive="downloaded.txt"  # Track progress
)

result = downloader.download_playlist(
    "https://www.youtube.com/playlist?list=...",
    config
)
```

##### `batch_download()`

Download multiple URLs with parallel processing.

**Signature**:
```python
def batch_download(
    self,
    urls: list[str],
    config: DownloadConfig | None = None
) -> list[DownloadResult]:
    """Download multiple URLs in parallel."""
```

**Example**:
```python
urls = [
    "https://youtu.be/video1",
    "https://youtu.be/video2",
    "https://youtu.be/video3",
]

config = DownloadConfig(workers=3)
results = downloader.batch_download(urls, config)

for result in results:
    print(f"{result.title}: {result.status}")
```

##### `get_info()`

Get video metadata without downloading.

**Signature**:
```python
def get_info(
    self,
    url: str
) -> dict[str, Any]:
    """Get video information."""
```

**Returns**: Dictionary with video metadata

**Example**:
```python
info = downloader.get_info("https://youtu.be/...")
print(f"Title: {info['title']}")
print(f"Duration: {info['duration']} seconds")
print(f"Uploader: {info['uploader']}")
print(f"Views: {info['view_count']}")
```

##### `list_formats()`

List all available formats for a video.

**Signature**:
```python
def list_formats(
    self,
    url: str
) -> list[dict[str, Any]]:
    """List available formats."""
```

**Returns**: List of format dictionaries

**Example**:
```python
formats = downloader.list_formats("https://youtu.be/...")

# Print first 10 formats
for fmt in formats[:10]:
    print(f"{fmt['format_id']:>6} | {fmt['ext']:>5} | "
          f"{fmt.get('resolution', 'audio')}")
```

##### `upscale_video()`

Upscale video to higher resolution using FFmpeg.

**Signature**:
```python
def upscale_video(
    self,
    input_file: str,
    target_resolution: str = "4k",
    method: str = "lanczos"
) -> DownloadResult:
    """Upscale video to higher resolution."""
```

**Parameters**:
- `input_file` (str): Path to input video
- `target_resolution` (str): "2k", "4k", "8k"
- `method` (str): "lanczos", "bilinear"

**Returns**: `DownloadResult`

**Example**:
```python
result = downloader.upscale_video(
    "video.mkv",
    target_resolution="4k",
    method="lanczos"
)

if result.status == "success":
    print(f"Upscaled: {result.output_file}")
    print(f"New resolution: {result.resolution}")
```

##### `analyze_file()`

Analyze local media file using ffprobe.

**Signature**:
```python
def analyze_file(
    self,
    file_path: str
) -> dict[str, Any]:
    """Analyze media file."""
```

**Returns**: Dictionary with file information

**Example**:
```python
info = downloader.analyze_file("video.mkv")
print(f"Duration: {info['duration']}")
print(f"Video codec: {info['video']['codec']}")
print(f"Audio codec: {info['audio']['codec']}")
print(f"Resolution: {info['video']['width']}x{info['video']['height']}")
```

---

## REST API

### Starting the Server

```bash
# Basic
converso-ytdl-api

# With custom host/port
converso-ytdl-api --host 0.0.0.0 --port 8000

# Full options
converso-ytdl-api \
  --host 127.0.0.1 \
  --port 8000 \
  --reload \
  --workers 4
```

### Base URL and Documentation

Once running:
- **API Base**: `http://localhost:8000/api/v1/`
- **Swagger UI**: `http://localhost:8000/docs`
- **ReDoc**: `http://localhost:8000/redoc`
- **OpenAPI JSON**: `http://localhost:8000/openapi.json`

### Endpoints

#### `GET /health`

Server health status and job statistics.

**Response**:
```json
{
  "status": "healthy",
  "timestamp": "2026-03-30T10:30:00Z",
  "version": "1.0.0",
  "jobs_total": 42,
  "jobs_active": 3,
  "jobs_completed": 39,
  "uptime_seconds": 3600
}
```

**Example**:
```bash
curl http://localhost:8000/health
```

#### `GET /api/v1/info`

Get video metadata without downloading.

**Query Parameters**:
- `url` (str, required): Video URL

**Response**:
```json
{
  "title": "Video Title",
  "duration": 300,
  "uploader": "Channel Name",
  "view_count": 100000,
  "upload_date": "2025-01-01",
  "description": "...",
  "thumbnail": "https://...",
  "formats_available": 50
}
```

**Example**:
```bash
curl "http://localhost:8000/api/v1/info?url=https://youtu.be/..."
```

#### `GET /api/v1/formats`

List available formats for a video.

**Query Parameters**:
- `url` (str, required): Video URL

**Response**:
```json
[
  {
    "format_id": "22",
    "ext": "mp4",
    "resolution": "1280x720",
    "fps": 30,
    "codec": "h.264"
  },
  ...
]
```

**Example**:
```bash
curl "http://localhost:8000/api/v1/formats?url=https://youtu.be/..."
```

#### `POST /api/v1/jobs/video`

Start a video download job (async).

**Request Body**:
```json
{
  "url": "https://youtu.be/...",
  "container": "mkv",
  "embed_thumbnail": true,
  "output_dir": "downloads",
  "webhook_url": "https://your-domain.com/callback"
}
```

**Response**:
```json
{
  "job_id": "550e8400-e29b-41d4-a716-446655440000",
  "status": "queued",
  "created_at": "2026-03-30T10:30:00Z"
}
```

**Example**:
```bash
curl -X POST http://localhost:8000/api/v1/jobs/video \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://youtu.be/...",
    "container": "mkv"
  }'
```

#### `POST /api/v1/jobs/audio`

Start an audio download job.

**Request Body**:
```json
{
  "url": "https://youtu.be/...",
  "codec": "flac",
  "sample_rate": 192000,
  "bit_depth": 24,
  "webhook_url": "https://..."
}
```

**Example**:
```bash
curl -X POST http://localhost:8000/api/v1/jobs/audio \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://youtu.be/...",
    "codec": "flac"
  }'
```

#### `POST /api/v1/jobs/batch`

Start a batch download job.

**Request Body**:
```json
{
  "urls": ["https://youtu.be/1", "https://youtu.be/2"],
  "mode": "video",
  "workers": 2,
  "webhook_url": "https://..."
}
```

#### `POST /api/v1/jobs/playlist`

Download entire playlist.

**Request Body**:
```json
{
  "url": "https://www.youtube.com/playlist?list=...",
  "mode": "audio",
  "webhook_url": "https://..."
}
```

#### `GET /api/v1/jobs`

List all jobs (with optional filtering).

**Query Parameters**:
- `status` (str, optional): Filter by status ("queued", "running", "completed", "failed")
- `limit` (int, optional): Max results (default 50)

**Response**:
```json
[
  {
    "job_id": "550e8400-e29b-41d4-a716-446655440000",
    "status": "completed",
    "created_at": "2026-03-30T10:30:00Z",
    "title": "Video Title"
  }
]
```

**Example**:
```bash
curl "http://localhost:8000/api/v1/jobs?status=completed&limit=10"
```

#### `GET /api/v1/jobs/{job_id}`

Get status of a specific job.

**Response**:
```json
{
  "job_id": "550e8400-e29b-41d4-a716-446655440000",
  "status": "running",
  "progress": 45,
  "title": "Video Title",
  "output_file": "/path/to/video.mkv",
  "created_at": "2026-03-30T10:30:00Z",
  "started_at": "2026-03-30T10:31:00Z",
  "completed_at": null,
  "error": null
}
```

**Example**:
```bash
curl "http://localhost:8000/api/v1/jobs/550e8400-e29b-41d4-a716-446655440000"
```

#### `GET /api/v1/jobs/{job_id}/download`

Stream the output file of a completed job.

**Example**:
```bash
curl "http://localhost:8000/api/v1/jobs/550e8400-e29b-41d4-a716-446655440000/download" \
  -o downloaded_video.mkv
```

#### `DELETE /api/v1/jobs/{job_id}`

Delete a job record (doesn't delete file).

**Example**:
```bash
curl -X DELETE "http://localhost:8000/api/v1/jobs/550e8400-e29b-41d4-a716-446655440000"
```

#### `DELETE /api/v1/jobs`

Delete all completed jobs.

**Example**:
```bash
curl -X DELETE "http://localhost:8000/api/v1/jobs"
```

---

## CLI Reference

### Interactive Mode

```bash
converso-ytdl
```

Menu options:
1. Download video
2. Download audio
3. Batch download
4. Download playlist
5. Get video info
6. List formats
7. Upscale video
8. Analyze file
9. AI guide
10. Exit

### Video Download

```bash
converso-ytdl video "URL" [options]

Options:
  --output-dir DIR          Output directory
  --container FORMAT        Container: mkv, mp4, webm
  --no-thumbnail           Don't embed thumbnail
  --config FILE            JSON config file
```

**Example**:
```bash
converso-ytdl video "https://youtu.be/..." \
  --output-dir my_videos \
  --container mp4
```

### Audio Download

```bash
converso-ytdl audio "URL" [options]

Options:
  --codec CODEC             Audio codec: wav, flac, mp3, aac, opus, ogg
  --sample-rate RATE        Sample rate in Hz (default 96000)
  --bit-depth DEPTH         Bit depth: 16, 24, 32 (default 24)
  --output-dir DIR          Output directory
```

**Example**:
```bash
converso-ytdl audio "https://youtu.be/..." \
  --codec flac \
  --sample-rate 192000 \
  --bit-depth 24
```

### Batch Download

```bash
converso-ytdl batch -f FILE [options]

Options:
  -f FILE                   File with URLs (one per line)
  --mode MODE              Download mode: video or audio
  --workers N              Parallel workers (default 2)
  --delay SECONDS          Delay between downloads
  --output-dir DIR         Output directory
```

**Example**:
```bash
converso-ytdl batch -f urls.txt \
  --mode video \
  --workers 4 \
  --delay 2
```

### Playlist Download

```bash
converso-ytdl playlist "URL" [options]

Options:
  --mode MODE              Download mode: video or audio
  --archive FILE           Archive file for progress tracking
  --output-dir DIR         Output directory
```

**Example**:
```bash
converso-ytdl playlist "https://www.youtube.com/playlist?list=..." \
  --mode audio \
  --archive done.txt
```

### Get Info

```bash
converso-ytdl info "URL"
```

### List Formats

```bash
converso-ytdl formats "URL"
```

### Upscale Video

```bash
converso-ytdl upscale FILE [options]

Options:
  --target RESOLUTION      Target: 2k, 4k, 8k
  --method METHOD         Method: lanczos, bilinear
```

**Example**:
```bash
converso-ytdl upscale video.mkv --target 4k --method lanczos
```

---

## Error Handling

### Common Error Responses

#### Video Not Available
```json
{
  "error": "Video not found or is private",
  "status": 404
}
```

#### Rate Limited
```json
{
  "error": "Rate limited, please retry",
  "retry_after": 60,
  "status": 429
}
```

#### Invalid Request
```json
{
  "error": "Invalid URL format",
  "details": "URL must be http or https",
  "status": 400
}
```

---

## Authentication & Security

### API Server Security

For production:
```bash
# Use firewall to restrict access
# Use HTTPS/SSL
# Run on localhost by default
converso-ytdl-api --host 127.0.0.1

# Access via reverse proxy (nginx, Apache)
```

### Webhook Security

Webhooks sent to your URL:
```json
{
  "job_id": "...",
  "status": "completed",
  "title": "...",
  "output_file": "...",
  "timestamp": "2026-03-30T10:30:00Z"
}
```

Make sure your webhook URL is secure.

---

## Examples

### Python: Download with Error Handling

```python
from converso_ytdl import MediaDownloader, DownloadConfig

config = DownloadConfig(
    output_dir="downloads",
    verbose=True,
    retries=3
)

downloader = MediaDownloader(config)

urls = [
    "https://youtu.be/video1",
    "https://youtu.be/video2",
]

for url in urls:
    try:
        result = downloader.download_video(url)
        if result.status == "success":
            print(f"✓ {result.title}")
        else:
            print(f"✗ {result.title}: {result.error}")
    except Exception as e:
        print(f"✗ Failed to process {url}: {e}")
```

### REST API: Monitor Batch Jobs

```bash
#!/bin/bash

# Start batch download
JOB_ID=$(curl -s -X POST http://localhost:8000/api/v1/jobs/batch \
  -H "Content-Type: application/json" \
  -d '{
    "urls": ["https://youtu.be/1", "https://youtu.be/2"],
    "workers": 2
  }' | jq -r '.job_id')

echo "Started job: $JOB_ID"

# Poll status
while true; do
  STATUS=$(curl -s "http://localhost:8000/api/v1/jobs/$JOB_ID" | jq -r '.status')
  echo "Status: $STATUS"
  
  if [ "$STATUS" = "completed" ] || [ "$STATUS" = "failed" ]; then
    break
  fi
  
  sleep 5
done
```

### CLI: Automated Playlist Backup

```bash
#!/bin/bash

PLAYLIST_URL="https://www.youtube.com/playlist?list=..."
ARCHIVE_FILE="archived_videos.txt"

converso-ytdl playlist "$PLAYLIST_URL" \
  --mode audio \
  --archive "$ARCHIVE_FILE" \
  --output-dir "my_music"

echo "Playlist backup complete!"
```

---

## Best Practices

1. **Always validate URLs** before processing
2. **Use try-catch** for error handling
3. **Log operations** for debugging
4. **Set reasonable timeouts** (30-60 seconds)
5. **Implement retry logic** for network errors
6. **Monitor API rate limits** and cache results
7. **Use appropriate worker counts** (2-4 for most systems)
8. **Keep logs and audit trails**

---

**Last Updated**: March 30, 2026  
**Version**: 1.0.0
