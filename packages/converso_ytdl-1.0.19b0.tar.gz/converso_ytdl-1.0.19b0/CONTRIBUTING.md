# Contributing to Converso Media Downloader

## Welcome! 🎉

Thank you for considering contributing to **Converso Media Downloader**. This document provides guidelines and instructions for contributing to our project.

---

## Code of Conduct

### Our Commitment
We are committed to providing a welcoming and inspiring community for all. Please read and adhere to our [Code of Conduct](CODE_OF_CONDUCT.md) which applies to all spaces managed by the Converso project.

### Core Values
- **Respect**: Treat everyone with dignity and respect
- **Inclusivity**: Welcome contributors of all backgrounds and experience levels
- **Excellence**: Maintain high standards of code quality
- **Collaboration**: Work together toward shared goals

---

## Getting Started

### Prerequisites
- Python 3.8+
- Git
- ffmpeg
- GitHub account

### Setup Development Environment

```bash
# Clone repository
git clone https://github.com/converso-empire/converso-ytdl.git
cd converso-ytdl

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install with development dependencies
pip install -e ".[dev,all]"

# Verify installation
converso-ytdl --version
```

### Verify Setup
```bash
# Run tests
pytest tests/

# Check code formatting
black --check src/
isort --check src/
flake8 src/

# Run security scan
bandit -r src/
```

---

## Types of Contributions

### 🐛 Bug Reports
- **Report security issues**: See [SECURITY.md](SECURITY.md)
- **Public bugs**: Use GitHub Issues
- **What to include**:
  - Clear description of the bug
  - Steps to reproduce
  - Expected vs actual behavior
  - Python version and OS
  - Code samples (if applicable)
  - Logs from `logs/converso_ytdl.log`

### ✨ Feature Requests
- **Use GitHub Discussions**: Propose new ideas
- **What to include**:
  - Clear use case description
  - How it benefits users
  - Example usage
  - Potential implementation approach

### 🔧 Code Contributions
- Bug fixes
- Feature implementation
- Performance improvements
- Documentation updates

### 📚 Documentation
- Update README or guides
- Fix typos or unclear sections
- Add code examples
- Improve API documentation

---

## Development Workflow

### 1. Fork and Clone
```bash
# Fork on GitHub, then:
git clone https://github.com/YOUR_USERNAME/converso-ytdl.git
cd converso-ytdl
git remote add upstream https://github.com/converso-empire/converso-ytdl.git
```

### 2. Create Feature Branch
```bash
# Always branch from latest main
git fetch upstream
git checkout -b feature/your-feature-name upstream/main

# Use meaningful branch names:
# feature/add-subtitle-download
# bugfix/fix-playlist-parsing
# docs/update-readme
# test/add-batch-tests
```

### 3. Make Changes
```bash
# Edit files
# Write tests for new code
# Update documentation

# Format code before committing
black src/
isort src/

# Run tests
pytest tests/
```

### 4. Commit with Good Messages
```bash
# Good commit messages explain the WHY, not just WHAT
git commit -m "feat: add subtitle download support

- Support multiple subtitle languages
- Automatic language detection
- Works with all download modes

Fixes #123"
```

#### Commit Message Format
```
type(scope): subject

body

footer
```

**Types**: `feat`, `fix`, `docs`, `style`, `refactor`, `test`, `chore`
**Scope**: Module or component affected
**Subject**: Clear, present tense, <50 chars
**Body**: Explain changes (what and why)
**Footer**: Reference issues (`Closes #123`)

### 5. Push and Create Pull Request
```bash
# Push to your fork
git push origin feature/your-feature-name

# Create PR on GitHub with:
# - Clear title
# - Description of changes
# - Link to any related issues
# - Screenshots (if UI changes)
# - Checklist of what you've done
```

---

## Code Standards

### Style Guide

#### Python Style (PEP 8 + Black)
```python
# Line length: 100 characters
# Use black for automatic formatting
black src/

# Sort imports
isort src/

# Check with flake8
flake8 src/
```

#### Naming Conventions
```python
# Classes: PascalCase
class MediaDownloader:
    pass

# Functions/variables: snake_case
def download_video(url):
    pass

# Constants: UPPER_SNAKE_CASE
MAX_WORKERS = 4
DEFAULT_OUTPUT_DIR = "downloads"

# Private: Leading underscore
def _internal_method(self):
    pass
```

#### Documentation
```python
def download_video(url: str, config: DownloadConfig) -> DownloadResult:
    """Download best-quality video from URL.
    
    Args:
        url: Video URL (YouTube, etc.)
        config: Download configuration options
        
    Returns:
        DownloadResult: Download status and metadata
        
    Raises:
        NetworkError: If URL is unreachable
        FormatNotFoundError: If no formats available
        
    Example:
        >>> config = DownloadConfig(output_dir="videos")
        >>> downloader = MediaDownloader(config)
        >>> result = downloader.download_video("https://youtu.be/...")
        >>> print(f"Downloaded: {result.output_file}")
    """
```

#### Type Hints (Required)
```python
# All functions must have type hints
def process_url(url: str, workers: int = 2) -> dict[str, Any]:
    """Process multiple URLs."""
    pass

# Variable annotations where helpful
active_jobs: dict[str, JobInfo] = {}
download_paths: list[Path] = []
```

### Code Quality Standards

#### Complexity Limits
- **Functions**: Max 20 lines of actual logic
- **Cyclomatic complexity**: Max 10 per function
- **Classes**: Max 500 lines

#### Error Handling
```python
# Good: Specific exceptions
try:
    data = json.loads(config_text)
except json.JSONDecodeError as e:
    logger.error(f"Invalid JSON in config: {e}")
    raise ConfigError(f"Failed to parse config: {e}") from e

# Bad: Bare except
try:
    data = json.loads(config_text)
except:
    pass
```

#### Logging
```python
# Use appropriate levels
logger.debug("Starting download job...")      # Detailed info
logger.info("Video download complete")        # Important events
logger.warning("Retry #3 for unstable URL")   # Something unusual
logger.error("Failed to open output file")    # Error condition
logger.critical("System memory exhausted")    # Critical failure
```

---

## Testing

### Writing Tests

```python
# File: tests/test_feature.py
import pytest
from converso_ytdl import MediaDownloader, DownloadConfig

class TestDownloadVideo:
    """Tests for video download functionality."""
    
    @pytest.fixture
    def downloader(self):
        """Create downloader instance for testing."""
        config = DownloadConfig(output_dir="test_downloads")
        return MediaDownloader(config)
    
    def test_download_config_creation(self):
        """Test that DownloadConfig creates correctly."""
        config = DownloadConfig(
            output_dir="downloads",
            video_container="mkv"
        )
        assert config.output_dir == "downloads"
        assert config.video_container == "mkv"
    
    def test_invalid_config_raises_error(self):
        """Test that invalid config raises ValueError."""
        with pytest.raises(ValueError):
            DownloadConfig(output_dir="", workers=-1)
    
    def test_download_result_serialization(self):
        """Test that DownloadResult serializes to JSON."""
        from converso_ytdl import DownloadResult
        result = DownloadResult(
            status="success",
            output_file="/path/to/video.mkv"
        )
        json_str = result.to_json()
        assert isinstance(json_str, str)
        assert '"status":"success"' in json_str
```

### Running Tests
```bash
# Run all tests
pytest

# Run specific test file
pytest tests/test_package.py

# Run specific test class
pytest tests/test_package.py::TestDownloadVideo

# Run with coverage
pytest --cov=src/converso_ytdl tests/

# Run with verbose output
pytest -v tests/
```

### Test Requirements
- 📝 All new features **must** have tests
- 🐛 All bug fixes **must** include regression tests
- ✅ Tests must pass on Python 3.8-3.12
- 📊 Code coverage **should** be >80%

---

## Documentation

### Updating README.md
- Keep structure clear and scannable
- Update feature list if adding features
- Add API reference links if relevant
- Include code examples for new functionality
- Update table of contents for major sections

### Creating New Guides
Converso uses several guide files:
- `GETTING_STARTED.md` - Quick 5-min start
- `ARCHITECTURE.md` - System design
- `API_REFERENCE.md` - Endpoint documentation
- `DEPLOYMENT.md` - Deployment/publishing

### Documentation Standards
- Clear, concise language (8th-grade reading level)
- Active voice: "Download videos" not "Videos are downloaded"
- Code samples must be runnable
- Include hyperlinks to related docs
- Use proper markdown formatting

---

## Pull Request Process

### Before Submitting

1. **Update your branch**
   ```bash
   git fetch upstream
   git rebase upstream/main
   ```

2. **Run all checks locally**
   ```bash
   black src/ tests/
   isort src/ tests/
   flake8 src/ tests/
   pytest tests/
   bandit -r src/
   ```

3. **Create focused PRs**
   - One feature per PR
   - One bug fix per PR
   - Keep size reasonable (<400 lines)

### PR Checklist
- [ ] Tests added/updated
- [ ] Documentation updated
- [ ] Code formatted with black and isort
- [ ] All tests passing locally
- [ ] Commit messages are clear
- [ ] No debug code or print statements
- [ ] No credentials or secrets in code
- [ ] Related issues referenced

### Review Process
1. Automated checks run (linting, tests)
2. At least one maintainer reviews
3. Maintainer may request changes
4. Once approved, PR is merged

### After Merge
- Branch is automatically deleted
- PR author mentioned in changelog
- Code appears in next release

---

## Release Process

### Version Numbers
We follow [Semantic Versioning](https://semver.org/):
- **MAJOR** (1.0.0): Breaking changes
- **MINOR** (1.1.0): New features (backward compatible)
- **PATCH** (1.0.1): Bug fixes only

### How Releases Work
1. Maintainer bumps version in `pyproject.toml`
2. Maintainer updates `CHANGELOG.md`
3. Code is pushed to main
4. Git tag created: `v1.0.0`
5. Tag pushed to GitHub
6. GitHub Actions automatically publishes to PyPI

### Becoming a Maintainer
If you consistently contribute quality code and reviews, you may be invited to become a maintainer with release privileges.

---

## Getting Help

### Have Questions?

- 📖 Check [Documentation](README.md)
- 🏗️ See [Architecture Guide](ARCHITECTURE.md)
- 🔍 Search [GitHub Issues](https://github.com/converso-empire/converso-ytdl/issues)
- 💬 Start [GitHub Discussion](https://github.com/converso-empire/converso-ytdl/discussions)
- 🐛 Report [Security Issues](SECURITY.md)

### Development Support
- Python package questions: Check `pyproject.toml` and examples
- yt-dlp questions: See [yt-dlp documentation](https://github.com/yt-dlp/yt-dlp)
- FastAPI questions: See [FastAPI documentation](https://fastapi.tiangolo.com/)

---

## Community

### Code of Conduct
All contributors are expected to follow our [Code of Conduct](CODE_OF_CONDUCT.md). Please be respectful and professional.

### Recognition
Contributors are recognized in:
- GitHub contributors page
- Project CHANGELOG
- Eventual "Credits" section in documentation

### Maintainers
Current maintainers:
- [Converso Engineering Team](https://converso.io/)

---

## License

By contributing to this project, you agree that your contributions will be licensed under the Apache License 2.0.

---

## Examples of Good Contributions

### 🌟 Good: Clear Bug Report
```
Title: Video download fails with private videos

Description:
When attempting to download a private YouTube video 
that I have permission to access, the downloader 
returns a 403 error.

Steps to reproduce:
1. converso-ytdl video "https://youtu.be/PRIVATE_ID"
2. [See error]

Expected: Should download video I have access to
Actual: "[youtube] PRIVATE_ID: 403 Forbidden"

System: Python 3.11, Windows 11, ffmpeg 6.0
```

### 🌟 Good: Focused Feature PR
- Single feature: "Add subtitle language filtering"
- 5 commits, clear messages
- Tests added (8 new tests)
- Documentation updated
- Size: 250 lines

### 🌟 Good: Documentation PR
- Improves clarity of examples
- Adds missing code sample
- Fixes 2 typos
- Links to related docs

---

## FAQ

**Q: How long until my PR is reviewed?**  
A: Usually within 1-2 weeks. Thank you for patience!

**Q: Can I work on X feature?**  
A: Check open issues/discussions first. If not there, open a discussion.

**Q: What if my PR is rejected?**  
A: We provide constructive feedback. Feel free to discuss and iterate.

**Q: How do I report security issues?**  
A: See [SECURITY.md](SECURITY.md) - don't open public issues.

**Q: Can I become a maintainer?**  
A: If you consistently contribute quality work, we'll reach out!

---

## Thank You! 🙏

Your contributions make Converso Media Downloader better for everyone.

For questions or suggestions about this guide, [open an issue](https://github.com/converso-empire/converso-ytdl/issues).

**Happy Contributing!**

---

**Last Updated**: March 30, 2026  
**Version**: 1.0.0
