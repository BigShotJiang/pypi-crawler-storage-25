# Deployment & Publishing Guide

This guide explains how to publish Converso Media Downloader to PyPI.

---

## Prerequisites

1. **GitHub Repository** - Repository with this code
2. **PyPI Account** - https://pypi.org/account/register/
3. **TestPyPI Account** (optional) - https://test.pypi.org/account/register/

---

## Option 1: Trusted Publisher (Recommended)

### 1. Configure PyPI Trusted Publisher

In PyPI (https://pypi.org/manage/account/)):
- Go to "Publishing" → "Add a new pending publisher"
- Repository name: `converso-ytdl` (your actual repo name)
- Workflow name: `.github/workflows/publish.yml`
- Environment name: `pypi`

### 2. Push Release Tag

```bash
git tag v1.0.0
git push origin v1.0.0
```

GitHub Actions will automatically:
- Build the package
- Publish to PyPI

---

## Option 2: PyPI API Token

### 1. Create PyPI API Token

In PyPI (https://pypi.org/manage/account/tokens/):
- Click "Add API token"
- Select "Converso Media Downloader" as the project
- Copy the token (starts with `pypi-...`)

### 2. Add GitHub Secret

In GitHub repository settings:
- Go to "Secrets and variables" → "Actions"
- Create secret: `PYPI_API_TOKEN`
- Value: Paste the token from PyPI

### 3. Push Release Tag

```bash
git tag v1.0.0
git push origin v1.0.0
```

---

## Option 3: Manual Publishing (Development)

### 1. Install Build Tools

```bash
pip install build twine
```

### 2. Build Distribution

```bash
python -m build
```

Creates:
- `dist/converso-ytdl-1.0.0.tar.gz` - Source distribution
- `dist/converso_ytdl-1.0.0-py3-none-any.whl` - Wheel

### 3. Check Package

```bash
twine check dist/*
```

### 4. Test on TestPyPI (Optional)

```bash
twine upload --repository testpypi dist/*
# Enter your TestPyPI credentials
```

Then test installation:
```bash
pip install -i https://test.pypi.org/simple/ converso-ytdl
```

### 5. Publish to PyPI

```bash
twine upload dist/*
# Enter your PyPI credentials
```

---

## Pre-Release Checklist

Before publishing:

- [ ] Update version in `pyproject.toml`
- [ ] Update `CHANGELOG.md` with release notes
- [ ] Run tests: `pytest tests/`
- [ ] Check linting: `flake8 src/ tests/`
- [ ] Verify imports: `python -c "from converso_ytdl import *"`
- [ ] Build locally: `python -m build`
- [ ] Check package: `twine check dist/*`
- [ ] Commit and push changes
- [ ] Create and push git tag

---

## Version Numbering

Use [Semantic Versioning](https://semver.org/):

- `v0.1.0` - alpha/initial release
- `v1.0.0` - first stable release
- `v1.1.0` - new features (minor)
- `v1.1.1` - bug fixes (patch)
- `v2.0.0` - breaking changes (major)

---

## Post-Release

### Verify Publication

1. Check PyPI: https://pypi.org/project/converso-ytdl/
2. Install from PyPI:
   ```bash
   pip install converso-ytdl
   ```
3. Test installation:
   ```bash
   converso-ytdl --version
   converso-ytdl-api --help
   ```

### Create GitHub Release

```bash
git tag v1.0.0
git push origin v1.0.0

# GitHub will create a release automatically
# Add release notes to GitHub release page
```

---

## Updating Metadata

If you need to update package info **without** a new release:

**On PyPI (https://pypi.org/manage/project/converso-ytdl/):**
- Update description
- Update keywords
- Add links
- Manage collaborators

**In source code (for next release):**
- Edit `pyproject.toml`
- Create new git tag
- Push to trigger automated build

---

## Continuous Deployment

The GitHub Actions workflows automatically:

1. **Tests** (`tests.yml`):
   - Run on every push to `main` and `develop`
   - Test on Python 3.8-3.12
   - Check code quality
   - Report coverage

2. **Publishing** (`publish.yml`):
   - Triggers on version tags (`v*`)
   - Builds distribution
   - Publishes to PyPI
   - Creates GitHub release

---

## Troubleshooting

### Package won't build
```bash
python -m build
# Check error output
```

### Import errors
```bash
python -c "from converso_ytdl import MediaDownloader"
# Verify package installed correctly
```

### PyPI upload fails
- Check credentials: `twine --version`
- Check package: `twine check dist/*`
- Check dependencies: ensure all imports work

### GitHub Actions fails
- Check workflow logs in GitHub Actions tab
- Verify secrets are set correctly
- Ensure git tags are pushed: `git push origin v1.0.0`

---

## Security

- **Don't commit secrets** - Use GitHub secrets for API tokens
- **Use trusted publisher** - Safest method for PyPI
- **Review dependencies** - Check for supply chain security
- **Sign tags** - Use `git tag -s` for GPG signing

---

## Support

- 📖 [PyPI Docs](https://packaging.python.org/tutorials/packaging-projects/)
- 🔗 [Build & Publish Guide](https://python-poetry.org/docs/repositories/)
- 💬 [PyPI Support](https://pypi.org/help/)

---

**Ready to publish? Follow Option 1 (Trusted Publisher) for best security!** 🚀
