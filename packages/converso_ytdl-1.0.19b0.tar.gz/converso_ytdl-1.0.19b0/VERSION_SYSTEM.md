# Version System Documentation

## Overview

**Simple. Clean. Perfect User Experience.**

The version system uses **exact tag matching**: Whatever git tag you create, that exact version is used everywhere (CLI, API, PyPI).

---

## Version Definition

**Single Source**: Git tag

**Usage**:
```bash
git tag v1.0.0           # Stable: v1.0.0 everywhere
git tag beta-v1.0.4      # Beta: beta-v1.0.4 everywhere
git tag pre-v2.0.0       # Pre-release: pre-v2.0.0 everywhere
```

---

## How It Works

### 1. Create Git Tag
```bash
git tag beta-v1.0.4
git push origin --tags
```

### 2. GitHub Actions Extracts Version
```bash
VERSION=$(python .github/scripts/extract_version.py --tag beta-v1.0.4)
# Output: beta-v1.0.4 (exact match, no transformation)
```

### 3. Updates Everywhere
- **__init__.py**: `__version__ = "beta-v1.0.4"`
- **CLI**: `converso-ytdl --version` → `converso-ytdl beta-v1.0.4`
- **API**: `GET /` returns `{"version": "beta-v1.0.4"}`
- **PyPI**: Publishes as `converso-ytdl-beta-v1.0.4`

---

## Release Types

### Stable Release
```bash
git tag v1.0.0
```
- Version everywhere: `v1.0.0`
- PyPI: Latest stable
- Prerelease flag: **false**

### Beta Release
```bash
git tag beta-v1.0.4
```
- Version everywhere: `beta-v1.0.4`
- PyPI: Pre-release (not installed by default)
- Prerelease flag: **true**

### Pre-Release
```bash
git tag pre-v2.0.0
```
- Version everywhere: `pre-v2.0.0`
- PyPI: Pre-release (not installed by default)
- Prerelease flag: **true**

---

## User Experience

Perfect, consistent experience:

```
User runs: converso-ytdl --version
Output: converso-ytdl beta-v1.0.4

User checks API: curl http://localhost:8000/
Output: {"version": "beta-v1.0.4", ...}

User installs from PyPI: pip install converso-ytdl==beta-v1.0.4
Works perfectly with exact version match
```

---

## Files Involved

| File | Role |
|------|------|
| Git Tag | Source of truth |
| `.github/scripts/extract_version.py` | Extracts exact tag |
| `.github/workflows/publish.yml` | Applies version everywhere |
| `src/converso_ytdl/__init__.py` | Updated with exact version |
| `src/converso_ytdl/cli.py` | Displays version |
| `src/converso_ytdl/api/server.py` | Returns in API |
| `pyproject.toml` | Reads from __init__.py |

---

## Release Workflow

### Step 1: Decide Version
- Stable: `v1.0.4`
- Beta: `beta-v1.0.4`
- Pre-release: `pre-v2.0.0`

### Step 2: Create Tag
```bash
git tag v1.0.4
git push origin --tags
```

### Step 3: Automatic Actions
1. GitHub Actions triggers
2. Extracts version from tag: `v1.0.4`
3. Updates `src/converso_ytdl/__init__.py`: `__version__ = "v1.0.4"`
4. Builds wheel: `converso-ytdl-v1.0.4-py3-*.whl`
5. Validates package
6. Publishes to PyPI as `v1.0.4`
7. Creates GitHub Release
8. Sets prerelease flag based on tag content

---

## Examples

### Example 1: Release Stable v1.0.4
```bash
# Just create the tag - everything else is automatic
git tag v1.0.4
git push origin --tags

# What happens:
# 1. Version → v1.0.4
# 2. PyPI → converso-ytdl v1.0.4 (latest stable)
# 3. CLI → converso-ytdl v1.0.4
# 4. API → {"version": "v1.0.4"}
```

### Example 2: Release Beta v1.1.0
```bash
git tag beta-v1.1.0
git push origin --tags

# What happens:
# 1. Version → beta-v1.1.0 (exact)
# 2. PyPI → converso-ytdl beta-v1.1.0 (marked pre-release)
# 3. Install: pip install converso-ytdl==beta-v1.1.0
# 4. CLI → converso-ytdl beta-v1.1.0
# 5. GitHub Release marked as pre-release
```

---

## Testing

### Test Version Extraction Locally
```bash
python .github/scripts/extract_version.py --tag v1.0.4
# Output: v1.0.4

python .github/scripts/extract_version.py --tag beta-v1.0.4
# Output: beta-v1.0.4
```

### Run Full Workflow Tests
```bash
python .github/scripts/test_workflow_logic.py
```

---

## PyPI Compatibility Note

**Important**: PyPI may have specific version format requirements (PEP 440). If you encounter issues with custom version formats like `beta-v1.0.4`, you can:

1. Use standard formats: `v1.0.4` (stable only)
2. Or normalize in the workflow to `1.0.4b0` (for PyPI)

The current system uses exact tag matching for best user experience. Adjust if PyPI validation issues arise.

---

## Key Principles

✅ **Single source of truth**: Git tag  
✅ **No transformation**: Exact version everywhere  
✅ **Perfect UX**: User sees same version in all places  
✅ **Simple logic**: Tag → Extract → Update → Build → Publish  
✅ **Automatic**: All done by GitHub Actions  

---

**Last Updated**: March 30, 2026  
**Status**: ✅ Production Ready
