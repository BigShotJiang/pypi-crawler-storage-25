# Security Policy

## Reporting Security Vulnerabilities

**⚠️ IMPORTANT**: Do NOT create public GitHub issues for security vulnerabilities.

If you discover a security vulnerability in Converso Media Downloader, please report it responsibly:

### How to Report

**Email**: security@converso.io

**Include**:
- Description of the vulnerability
- Affected version(s)
- Steps to reproduce (if applicable)
- Potential impact
- Suggested fix (if you have one)
- Your contact information

### What to Expect

- **Acknowledgment**: Within 24 hours
- **Initial assessment**: Within 3-5 business days  
- **Fix timeline**: Depends on severity
- **Disclosure**: Coordinated with you after fix is released
- **Credit**: Your name in security advisory (if desired)

### Severity Levels

We use CVSS 3.1 for severity assessment:

| Severity | CVSS | Response Time | Example |
|----------|------|---------------|---------|
| **Critical** | 9.0-10.0 | 24 hours | Remote code execution |
| **High** | 7.0-8.9 | 48 hours | Authentication bypass |
| **Medium** | 4.0-6.9 | 1 week | Information disclosure |
| **Low** | 0.1-3.9 | 2 weeks | Minor information leak |

---

## Supported Versions

### Security Updates

| Version | Status | Until |
|---------|--------|-------|
| 1.x.x | ✅ **Supported** | March 30, 2027 |
| 0.x.x | ❌ **Unsupported** | N/A |

Only the latest minor version receives security updates. Users should upgrade frequently.

### Python Versions

We maintain security support for:
- Python 3.8 ✅
- Python 3.9 ✅
- Python 3.10 ✅
- Python 3.11 ✅
- Python 3.12 ✅

Older Python versions are not supported.

---

## Security Best Practices

### For Users

#### 1. Keep Software Updated
```bash
# Check for updates
pip list --outdated

# Update converso-ytdl
pip install --upgrade converso-ytdl

# Update all dependencies
pip install --upgrade -r requirements.txt
```

#### 2. Input Validation
- Only download from trusted URLs
- Verify video sources before processing
- Be cautious with webhook URLs (untrusted servers)
- Don't expose API servers publicly without authentication

#### 3. Configuration Security
```python
# ❌ BAD: Credentials in code
config = DownloadConfig(
    proxy="http://user:password@proxy.com"
)

# ✅ GOOD: Use environment variables
import os
proxy = os.getenv("HTTP_PROXY")
config = DownloadConfig(proxy=proxy)
```

#### 4. File Permissions
```bash
# Download directory should have restricted permissions
chmod 700 downloads/

# Log files may contain sensitive paths
chmod 600 logs/converso_ytdl.log

# Config files should not be world-readable
chmod 600 config.json
```

#### 5. API Server Security
```python
# When running API server

# ✅ DO: Restrict to localhost
converso-ytdl-api --host 127.0.0.1 --port 8000

# ✅ DO: Use HTTPS in production
# ✅ DO: Implement authentication
# ✅ DO: Use firewall rules
# ✅ DO: Monitor access logs

# ❌ DON'T: Expose 0.0.0.0:8000 publicly
# ❌ DON'T: Use HTTP in production
# ❌ DON'T: Allow unrestricted access
```

#### 6. Dependency Management
```bash
# Check for known vulnerabilities
pip install safety
safety check

# Keep dependencies updated
pip install --upgrade pip setuptools wheel

# Use pinned versions in production
pip freeze > requirements-production.txt
```

### For Developers

#### 1. Code Review
- All code must be reviewed before merge
- Security-sensitive code gets extra scrutiny
- Type hints required
- No eval(), exec(), or pickle with untrusted data

#### 2. Input Validation
```python
# ❌ BAD: No validation
def process_url(url):
    return download(url)

# ✅ GOOD: Validate input
from urllib.parse import urlparse
import re

def process_url(url: str) -> DownloadResult:
    """Process and validate URL."""
    # Validate format
    if not isinstance(url, str):
        raise TypeError("URL must be string")
    
    # Parse and validate
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https"):
        raise ValueError("Only HTTP(S) URLs supported")
    
    return download(url)
```

#### 3. Error Handling
```python
# ❌ BAD: Expose sensitive info
except Exception as e:
    return {"error": str(e)}  # Stacktrace visible to user

# ✅ GOOD: Generic error message
except Exception as e:
    logger.error(f"Download failed: {e}")  # Log detailed info
    return {"error": "Download failed"}     # Generic message to user
```

#### 4. Logging Security
```python
# ❌ BAD: Log credentials
logger.debug(f"Connecting with password: {password}")

# ✅ GOOD: Never log secrets
logger.debug(f"Connecting to {host}")
# If debugging: use environment variable for password
```

#### 5. Dependency Security
```python
# ✅ Pin versions in pyproject.toml
[project]
dependencies = [
    "yt-dlp>=2024.1.1",
    "rich>=13.0.0",
]

# ✅ Regular updates via Dependabot
# ✅ Security scanning via bandit
# ✅ Vulnerability checking
```

#### 6. Thread Safety
```python
# ✅ DO: Use locks for shared state
import threading

self._jobs_lock = threading.Lock()
self._active_jobs = {}

def _register_job(self, job_id):
    with self._jobs_lock:
        self._active_jobs[job_id] = {...}

# ❌ DON'T: Access shared state without locking
```

---

## Security Features

### Input Validation
- URL validation with regex
- Path sanitization (prevents directory traversal)
- Configuration type checking (Pydantic)
- JSON schema validation for API requests

### Secure Defaults
- No sensitive data in logs
- No hardcoded credentials
- Output files created with restricted permissions
- Configuration files not world-readable

### Dependency Security
- Periodic security audits
- Automated dependency updates
- Known vulnerability scanning
- Version pinning for reproducibility

### API Security
- CORS validation
- Rate limiting ready
- No auth bypass possible
- Input validation on all endpoints

---

## Vulnerability Disclosure Timeline

### Process
1. **Day 0**: Vulnerability reported
2. **Day 1**: Acknowledgment sent
3. **Days 2-7**: Fix development
4. **Days 8-10**: Fix testing
5. **Day 11**: Security advisory prepared
6. **Day 12**: Fix released
7. **Day 13**: Public advisory released

### Example Advisory
```
Security Advisory: Converso Media Downloader v1.0.1

Vulnerability: Directory Traversal in Output Path
CVSS Score: 6.5 (Medium)
Affected: v1.0.0
Fixed in: v1.0.1

Description:
User-supplied output path could be exploited to write 
files outside intended directory.

Impact:
Arbitrary file write if untrusted paths accepted.

Mitigation:
- Upgrade to v1.0.1
- Validate output paths
- Use absolute paths only

Fix:
Path validation added to DownloadConfig.__post_init__()
```

---

## Security Audit

### Areas Reviewed
- [x] Input validation (URLs, paths, config)
- [x] Output encoding (preventing injection)
- [x] Dependency vulnerabilities
- [x] Authentication/authorization
- [x] Cryptography usage (if any)
- [x] Error handling (no info leaks)
- [x] Logging (no secrets)
- [x] Thread safety

### Recent Audit
**Date**: March 30, 2026  
**Result**: ✅ PASSED  
**Next Audit**: Q4 2026

---

## Compliance

### Standards
- **OWASP Top 10**: Followed
- **CWE**: Common Weakness Enumeration compliance
- **CVE**: Proper vulnerability tracking
- **CVSS**: Standard severity scoring

### Compliance Considerations
- No user data collection
- No telemetry
- No external API calls (except download sources)
- Full source availability (open source)
- Auditable logging

---

## Responsible Disclosure

### Good Faith Researchers
If you discover a vulnerability and report it responsibly, we will:
- Not pursue legal action
- Work with you on fix and timeline
- Credit you in advisory (if you wish)
- Possibly offer a bug bounty (case by case)

### Exception
If you publicly disclose before we have time to fix, we may not be able to acknowledge your contribution.

---

## Security Contacts

| Purpose | Contact |
|---------|---------|
| **Report vulnerability** | security@converso.io |
| **Security questions** | security@converso.io |
| **Code review concerns** | security@converso.io |
| **General contact** | support@converso.io |

---

## Security Resources

### External References
- [OWASP Python Security](https://owasp.org/www-community/attacks/Code_Injection)
- [CWE Top 25](https://cwe.mitre.org/top25/)
- [CVSS Calculator](https://www.first.org/cvss/calculator/3.1)
- [bandit Documentation](https://bandit.readthedocs.io/)

### Project Security Tools

#### Automated Scanning
```bash
# Code quality and security
black src/           # Formatting
isort src/          # Import sorting
flake8 src/         # Linting
mypy src/           # Type checking
bandit -r src/      # Security scan
safety check        # Dependency vulnerabilities
```

#### GitHub Actions
- **publish.yml**: Build artifact verification
- **tests.yml**: Automated security scanning (bandit)
- **Dependabot**: Automatic dependency updates

---

## FAQ

**Q: Is Converso Media Downloader secure?**  
A: Yes, to the best of our knowledge. We follow security best practices and respond to reports promptly.

**Q: Should I use this in production?**  
A: Yes, with proper configuration (firewall rules, secure defaults, etc.).

**Q: Is my data safe with the API server?**  
A: Data stays on your server (no external sends). Use HTTPS in production.

**Q: What about legal concerns (downloading videos)?**  
A: Users are responsible for following local laws and respecting copyrights.

**Q: How are dependencies verified?**  
A: Regular audits, CVSS scoring, security scanning.

**Q: What if I find a vulnerability?**  
A: Email security@converso.io immediately. Don't disclose publicly.

---

## Changelog

### v1.0.0 (Current)
- Initial security policy
- Full input validation
- Type hints throughout
- Security scanning in CI/CD
- Responsible disclosure process

### Future
- [ ] Security audit by third party
- [ ] Penetration testing
- [ ] SBOM (Software Bill of Materials)
- [ ] Bug bounty program

---

**Last Updated**: March 30, 2026  
**Version**: 1.0.0  
**Next Review**: Q4 2026
