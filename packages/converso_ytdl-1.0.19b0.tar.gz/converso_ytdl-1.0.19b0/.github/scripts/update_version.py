#!/usr/bin/env python3
"""Update __version__ in __init__.py with the version passed as argument."""

import re
import sys
import os

def update_version(version):
    """Update version in __init__.py"""
    file_path = 'src/converso_ytdl/__init__.py'
    
    try:
        with open(file_path, 'r') as f:
            content = f.read()
        
        # Update __version__ with exact version
        new_content = re.sub(
            r'__version__\s*=\s*["\']([^"\']+)["\']',
            f'__version__ = "{version}"',
            content
        )
        
        with open(file_path, 'w') as f:
            f.write(new_content)
        
        print(f"✓ Version set to: {version}")
        return 0
    except Exception as e:
        print(f"✗ Error updating version: {e}", file=sys.stderr)
        return 1

if __name__ == '__main__':
    version = os.environ.get('VERSION', 'unknown')
    sys.exit(update_version(version))
