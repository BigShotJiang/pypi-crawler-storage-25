#!/usr/bin/env python3
"""
Generate changelog from git commits between last tag and current tag.
"""

import subprocess
import sys


def run(cmd):
    return subprocess.check_output(cmd, shell=True, text=True).strip()


def get_last_tag():
    try:
        return run("git describe --tags --abbrev=0 HEAD^")
    except Exception:
        return ""


def get_commits(since_tag):
    if since_tag:
        cmd = f'git log {since_tag}..HEAD --pretty=format:"- %s (%h)"'
    else:
        cmd = 'git log --pretty=format:"- %s (%h)"'
    return run(cmd)


def main():
    current_tag = run("git describe --tags --exact-match")
    last_tag = get_last_tag()

    commits = get_commits(last_tag)

    changelog = f"# Release {current_tag}\n\n"

    if last_tag:
        changelog += f"Changes since `{last_tag}`:\n\n"
    else:
        changelog += "Initial release:\n\n"

    changelog += commits + "\n"

    with open("CHANGELOG_GENERATED.md", "w") as f:
        f.write(changelog)

    print(changelog)


if __name__ == "__main__":
    main()