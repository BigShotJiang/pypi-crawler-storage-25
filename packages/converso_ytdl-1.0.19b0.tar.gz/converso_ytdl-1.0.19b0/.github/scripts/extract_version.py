#!/usr/bin/env python3
"""
Extract and normalize version from git tag to PEP 440 format for PyPI.
Keeps the original tag for display/CLI but normalizes for wheel metadata.

Usage:
  python extract_version.py --tag TAG_NAME [--output-format {tag|pep440}]

Examples:
  python extract_version.py --tag v1.0.4        # Tag: v1.0.4, PyPI: 1.0.4
  python extract_version.py --tag beta-v1.0.4   # Tag: beta-v1.0.4, PyPI: 1.0.4b0
  python extract_version.py --tag pre-v1.0.4    # Tag: pre-v1.0.4, PyPI: 1.0.4rc0
"""

import sys
import re
import argparse


def normalize_to_pep440(tag):
    """
    Convert git tag to PEP 440 compliant version for wheel metadata.
    Preserves beta/pre-release tags as PEP 440 pre-release versions.
    """
    # Remove leading 'v' if present
    version = tag.lstrip('v')
    
    # Handle beta versions: beta-v1.0.4 or beta-1.0.4 -> 1.0.4b0
    if version.startswith('beta-'):
        version = version.replace('beta-', '', 1).lstrip('v')
        # Append b0 for beta pre-release
        return f"{version}b0"
    
    # Handle pre-release versions: pre-v1.0.4 or pre-1.0.4 -> 1.0.4rc0
    if version.startswith('pre-'):
        version = version.replace('pre-', '', 1).lstrip('v')
        # Append rc0 for release candidate
        return f"{version}rc0"
    
    # Regular version tags: v1.0.4 -> 1.0.4
    return version


def get_version_numbers(tag):
    """Extract just the version numbers from a tag."""
    # Remove prefixes like v, beta-, pre-
    clean = tag
    for prefix in ['v', 'beta-', 'pre-']:
        clean = clean.lstrip(prefix)
    clean = clean.lstrip('v')
    
    # Extract version numbers (e.g., 1.0.4 from 1.0.4-something)
    match = re.match(r'(\d+\.\d+\.\d+)', clean)
    return match.group(1) if match else clean


def main():
    """Extract version from git tag."""
    parser = argparse.ArgumentParser(
        description='Extract version from git tag and normalize for PyPI'
    )
    parser.add_argument(
        '--tag',
        required=True,
        help='Git tag name (e.g., v1.0.4, beta-v1.0.4, pre-v1.0.4)'
    )
    parser.add_argument(
        '--output-format',
        choices=['tag', 'pep440'],
        default='pep440',
        help='Output format: tag (original) or pep440 (PyPI compatible)'
    )
    
    args = parser.parse_args()
    
    if not args.tag:
        print('unknown', file=sys.stderr)
        sys.exit(1)
    
    if args.output_format == 'tag':
        # Return the original tag as-is
        print(args.tag)
    else:
        # Return PEP 440 normalized version
        version = normalize_to_pep440(args.tag)
        print(version)
    
    sys.exit(0)


if __name__ == '__main__':
    main()

