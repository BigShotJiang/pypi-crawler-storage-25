#!/usr/bin/env python3
"""
Validate package metadata before PyPI upload.
Checks wheel contents and extracts version information.

Usage:
  python validate_package.py
"""

import os
import sys
import zipfile
import subprocess


def check_with_twine():
    """Run twine check on distribution files."""
    print("🔍 Validating package metadata with twine...")
    try:
        # ✅ FIXED: Pin twine>=6.0 which supports Metadata 2.4
        # (License-Expression and License-File fields from hatchling)
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "twine>=6.0", "-q"],
            check=True,
        )

        result = subprocess.run(
            [sys.executable, "-m", "twine", "check"] +
            [os.path.join("dist/", f) for f in os.listdir("dist/")],
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            print("❌ Validation failed:")
            print(result.stdout)
            print(result.stderr)
            return False

        print("✅ Metadata validation passed")
        return True
    except Exception as e:
        print(f"❌ Error running twine: {e}")
        return False


def extract_wheel_metadata():
    """Extract and display wheel metadata."""
    print("\n📋 Package Details:")
    try:
        dist_files = [f for f in os.listdir("dist/") if f.endswith(".whl")]

        if not dist_files:
            print("❌ No wheel files found in dist/")
            return False

        print(f"📦 Found {len(dist_files)} wheel file(s)")

        for whl_file in dist_files:
            whl_path = os.path.join("dist/", whl_file)
            print(f"\n  File: {whl_file}")
            print(f"  Size: {os.path.getsize(whl_path) / 1024:.1f} KB")

            with zipfile.ZipFile(whl_path) as z:
                metadata_files = [f for f in z.namelist() if f.endswith("METADATA")]
                if metadata_files:
                    metadata = z.read(metadata_files[0]).decode()
                    for line in metadata.split("\n"):
                        if line.startswith(("Name:", "Version:", "Summary:", "License-Expression:")):
                            print(f"    {line}")

        return True
    except Exception as e:
        print(f"❌ Error extracting metadata: {e}")
        return False


def list_package_contents():
    """List package contents."""
    print("\n📦 Package Contents:")
    try:
        for filename in sorted(os.listdir("dist/")):
            filepath = os.path.join("dist/", filename)
            size = os.path.getsize(filepath) / 1024
            print(f"  {filename:<50} {size:>8.1f} KB")
        return True
    except Exception as e:
        print(f"❌ Error listing contents: {e}")
        return False


def main():
    print("=" * 70)
    print("Package Validation")
    print("=" * 70)

    success = True

    if not list_package_contents():
        success = False

    if not check_with_twine():
        success = False

    if not extract_wheel_metadata():
        success = False

    print("\n" + "=" * 70)
    if success:
        print("✅ All validations passed")
        sys.exit(0)
    else:
        print("❌ Some validations failed")
        sys.exit(1)


if __name__ == "__main__":
    main()