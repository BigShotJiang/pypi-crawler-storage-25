#!/usr/bin/env python3
"""
Test Version Extraction and Workflow Logic
Simple system: Tag is used exactly as version everywhere.

Run this locally to verify the workflow will work on GitHub Actions.
"""

import subprocess
import sys
from pathlib import Path


def test_version_extraction():
    """Test the version extraction script - uses tag exactly."""
    print("=" * 70)
    print("Testing Version Extraction (Exact Tag System)")
    print("=" * 70)
    
    test_cases = [
        ("v1.0.0", "v1.0.0", "Stable release"),
        ("beta-v1.0.0", "beta-v1.0.0", "Beta release"),
        ("pre-v1.0.0", "pre-v1.0.0", "Pre-release"),
        ("v2.1.3", "v2.1.3", "Stable with higher version"),
        ("beta-v2.1.3", "beta-v2.1.3", "Beta with higher version"),
    ]
    
    all_passed = True
    
    for tag, expected, description in test_cases:
        try:
            result = subprocess.run(
                [sys.executable, ".github/scripts/extract_version.py", "--tag", tag],
                capture_output=True,
                text=True,
            )
            actual = result.stdout.strip()
            
            if actual == expected:
                print(f"✅ {description:<35} {tag:<20} → {actual}")
            else:
                print(f"❌ {description:<35} {tag:<20} → {actual} (expected {expected})")
                all_passed = False
        except Exception as e:
            print(f"❌ {description:<35} Error: {e}")
            all_passed = False
    
    return all_passed


def test_workflow_scenarios():
    """Test the complete workflow scenarios with exact versions."""
    print("\n" + "=" * 70)
    print("Testing Workflow Scenarios")
    print("=" * 70)
    
    scenarios = [
        {
            "name": "Stable Release",
            "tag": "v1.0.0",
            "expected_version": "v1.0.0",
            "is_prerelease": False,
        },
        {
            "name": "Beta Release",
            "tag": "beta-v1.0.0",
            "expected_version": "beta-v1.0.0",
            "is_prerelease": True,
        },
        {
            "name": "Pre-Release",
            "tag": "pre-v1.0.0",
            "expected_version": "pre-v1.0.0",
            "is_prerelease": True,
        },
    ]
    
    all_passed = True
    
    for scenario in scenarios:
        print(f"\n📌 {scenario['name']}:")
        print(f"   Tag: {scenario['tag']}")
        print(f"   Expected version: {scenario['expected_version']}")
        
        # Extract version
        result = subprocess.run(
            [sys.executable, ".github/scripts/extract_version.py", "--tag", scenario["tag"]],
            capture_output=True,
            text=True,
        )
        extracted = result.stdout.strip()
        
        if extracted == scenario["expected_version"]:
            print(f"   ✅ Version extracted correctly: {extracted}")
        else:
            print(f"   ❌ Version mismatch: {extracted} (expected {scenario['expected_version']})")
            all_passed = False
        
        # Check prerelease logic
        is_prerelease = "beta" in scenario["tag"] or "pre" in scenario["tag"]
        if is_prerelease == scenario["is_prerelease"]:
            print(f"   ✅ Prerelease flag correct: {is_prerelease}")
        else:
            print(f"   ❌ Prerelease flag wrong: {is_prerelease} (expected {scenario['is_prerelease']})")
            all_passed = False
    
    return all_passed


def main():
    print("\n🧪 WORKFLOW LOGIC TEST SUITE (EXACT TAG SYSTEM)\n")
    
    results = {
        "Version Extraction": test_version_extraction(),
        "Workflow Scenarios": test_workflow_scenarios(),
    }
    
    print("\n" + "=" * 70)
    print("Test Results Summary")
    print("=" * 70)
    
    for test_name, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name:<40} {status}")
    
    all_passed = all(results.values())
    
    print("\n" + "=" * 70)
    if all_passed:
        print("🎉 All tests passed! Workflow is ready.")
        return 0
    else:
        print("⚠️  Some tests failed.")
        return 1


if __name__ == "__main__":
    sys.exit(main())
