#!/usr/bin/env python3
"""
Automatic Version Bump Tool

Simplifies version management with semantic versioning.
Updates __init__.py and provides release workflow.

Usage:
  python bump_version.py --patch        # 1.0.0 → 1.0.1
  python bump_version.py --minor        # 1.0.0 → 1.1.0
  python bump_version.py --major        # 1.0.0 → 2.0.0
  python bump_version.py --next         # Show next version without updating
  python bump_version.py --show         # Show current version
"""

import re
import sys
import argparse
from pathlib import Path
from typing import Tuple


class VersionManager:
    """Manage semantic versioning."""
    
    def __init__(self, init_file: str = "src/converso_ytdl/__init__.py"):
        self.init_file = Path(init_file)
        if not self.init_file.exists():
            raise FileNotFoundError(f"File not found: {init_file}")
        
        self.current_version = self._read_version()
    
    def _read_version(self) -> str:
        """Read current version from __init__.py."""
        with open(self.init_file) as f:
            content = f.read()
        
        match = re.search(r'__version__\s*=\s*["\']([^"\']+)["\']', content)
        if not match:
            raise ValueError(f"Could not find __version__ in {self.init_file}")
        
        return match.group(1)
    
    def _write_version(self, version: str) -> bool:
        """Write new version to __init__.py."""
        with open(self.init_file) as f:
            content = f.read()
        
        new_content = re.sub(
            r'__version__\s*=\s*["\']([^"\']+)["\']',
            f'__version__ = "{version}"',
            content
        )
        
        with open(self.init_file, 'w') as f:
            f.write(new_content)
        
        return True
    
    def parse_version(self, version: str) -> Tuple[int, int, int]:
        """Parse version string into major, minor, patch."""
        # Remove pre-release suffix (b0, a0, etc.)
        clean = re.sub(r'[a-z]+\d+$', '', version)
        parts = clean.split('.')
        
        if len(parts) != 3:
            raise ValueError(f"Invalid version format: {version}. Expected X.Y.Z")
        
        try:
            return tuple(int(p) for p in parts)
        except ValueError as e:
            raise ValueError(f"Invalid version parts: {e}")
    
    def format_version(self, major: int, minor: int, patch: int) -> str:
        """Format version tuple as string."""
        return f"{major}.{minor}.{patch}"
    
    def bump_major(self) -> str:
        """Bump major version (X.0.0)."""
        major, _, _ = self.parse_version(self.current_version)
        return self.format_version(major + 1, 0, 0)
    
    def bump_minor(self) -> str:
        """Bump minor version (0.X.0)."""
        major, minor, _ = self.parse_version(self.current_version)
        return self.format_version(major, minor + 1, 0)
    
    def bump_patch(self) -> str:
        """Bump patch version (0.0.X)."""
        major, minor, patch = self.parse_version(self.current_version)
        return self.format_version(major, minor, patch + 1)
    
    def update_version(self, new_version: str) -> bool:
        """Update version in __init__.py."""
        if self.current_version == new_version:
            print(f"⚠️  Version already {new_version}, no update needed")
            return False
        
        self._write_version(new_version)
        return True


def print_release_workflow(version: str, bump_type: str) -> None:
    """Print release workflow instructions."""
    print("\n" + "=" * 70)
    print(f"Release Workflow: Version {version}")
    print("=" * 70)
    print(f"\n📝 For STABLE release (default):\n")
    print(f"  git add src/converso_ytdl/__init__.py")
    print(f"  git commit -m 'Release v{version}'")
    print(f"  git tag v{version}")
    print(f"  git push origin main --tags")
    print(f"\n  → Published as: {version} (latest stable)")
    print(f"  → PyPI shows: No pre-release flag")
    print(f"  → Users install: pip install converso-ytdl")
    
    print(f"\n🧪 For BETA release:\n")
    print(f"  git add src/converso_ytdl/__init__.py")
    print(f"  git commit -m 'Beta release {version}'")
    print(f"  git tag beta-v{version}")
    print(f"  git push origin main --tags")
    print(f"\n  → Published as: {version}b0 (pre-release)")
    print(f"  → PyPI shows: Pre-release badge")
    print(f"  → Users install: pip install converso-ytdl=='{version}b0'")
    
    print(f"\n🔄 For PRE-RELEASE:\n")
    print(f"  git add src/converso_ytdl/__init__.py")
    print(f"  git commit -m 'Pre-release {version}'")
    print(f"  git tag pre-v{version}")
    print(f"  git push origin main --tags")
    print(f"\n  → Published as: {version}a0 (pre-release)")
    print(f"  → PyPI shows: Pre-release badge")
    print(f"  → Users install: pip install converso-ytdl=='{version}a0'")
    print("\n" + "=" * 70 + "\n")


def main():
    parser = argparse.ArgumentParser(
        description="Automatic version bump manager",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python bump_version.py --show         Show current version
  python bump_version.py --next patch   Show next patch version
  python bump_version.py --patch        Bump to next patch version & confirm
  python bump_version.py --minor        Bump to next minor version & confirm
  python bump_version.py --major        Bump to next major version & confirm
        """
    )
    
    parser.add_argument("--show", action="store_true", help="Show current version")
    parser.add_argument("--next", action="store_true", help="Show next version (without updating)")
    parser.add_argument("--patch", action="store_true", help="Bump patch version")
    parser.add_argument("--minor", action="store_true", help="Bump minor version")
    parser.add_argument("--major", action="store_true", help="Bump major version")
    parser.add_argument("--confirm", action="store_true", help="Auto-confirm update without prompting")
    parser.add_argument("--init-file", default="src/converso_ytdl/__init__.py", help="Path to __init__.py file")
    
    args = parser.parse_args()
    
    try:
        manager = VersionManager(args.init_file)
        
        # Show current version
        if args.show:
            print(f"\n📦 Current version: {manager.current_version}\n")
            return 0
        
        # Determine action
        if args.patch:
            new_version = manager.bump_patch()
            bump_type = "PATCH"
        elif args.minor:
            new_version = manager.bump_minor()
            bump_type = "MINOR"
        elif args.major:
            new_version = manager.bump_major()
            bump_type = "MAJOR"
        elif args.next:
            # Show next without specifying type - show all options
            patch = manager.bump_patch()
            minor = manager.bump_minor()
            major = manager.bump_major()
            
            print(f"\n📊 Version Options:")
            print(f"   Current:      {manager.current_version}")
            print(f"   Next patch:   {patch}   (bug fixes)")
            print(f"   Next minor:   {minor}   (new features)")
            print(f"   Next major:   {major}   (breaking changes)\n")
            return 0
        else:
            parser.print_help()
            return 1
        
        # Confirm before updating
        print(f"\n{'='*70}")
        print(f"Version Bump: {manager.current_version} → {new_version} ({bump_type})")
        print(f"{'='*70}\n")
        
        if not args.confirm:
            response = input(f"Update version to {new_version}? (y/n): ").strip().lower()
            if response != 'y':
                print("Cancelled.")
                return 1
        
        # Update version
        if manager.update_version(new_version):
            print(f"✅ Version updated to {new_version}")
            print_release_workflow(new_version, bump_type)
            return 0
        else:
            return 1
    
    except Exception as e:
        print(f"❌ Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
