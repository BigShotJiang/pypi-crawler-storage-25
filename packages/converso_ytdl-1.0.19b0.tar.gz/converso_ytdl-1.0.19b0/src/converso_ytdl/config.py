"""
Configuration and result classes for Converso Media Downloader.
"""

import json
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional


@dataclass
class DownloadConfig:
    """Unified configuration for all download operations."""
    # Output
    output_dir: str = "downloads"
    output_template: Optional[str] = None          # yt-dlp outtmpl override

    # Video
    video_container: str = "mkv"                   # mkv | mp4 | webm
    embed_thumbnail: bool = True
    embed_metadata: bool = True
    embed_chapters: bool = True
    embed_subs: bool = True
    sub_langs: str = "en,ar"                       # comma-separated
    no_subs: bool = False

    # Audio
    audio_codec: str = "wav"                       # wav|flac|mp3|aac|ogg|opus
    audio_sample_rate: int = 96000                 # Hz
    audio_bit_depth: str = "pcm_s24le"             # codec string
    audio_channels: int = 2                        # 1=mono 2=stereo

    # Upscaling
    upscale_target: Optional[str] = None           # 4k|8k|1440p|1080p|720p
    upscale_method: str = "lanczos"

    # Network
    proxy: Optional[str] = None
    rate_limit: Optional[str] = None               # e.g. "5M"
    concurrent_fragments: int = 4
    retries: int = 5
    retry_sleep: float = 3.0                       # seconds between retries

    # Batch
    batch_delay: float = 3.0                       # seconds between batch items
    stop_on_error: bool = False
    workers: int = 1                               # parallel batch workers

    # Playlist
    playlist_archive: Optional[str] = None
    playlist_start: Optional[int] = None
    playlist_end: Optional[int] = None
    playlist_items: Optional[str] = None           # e.g. "1,3,5-8"

    # Logging
    verbose: bool = False
    quiet: bool = False
    log_file: Optional[str] = None

    # Callbacks (not serialisable — set programmatically)
    progress_hook: Optional[Callable] = field(default=None, repr=False)
    post_hook: Optional[Callable] = field(default=None, repr=False)
    webhook_url: Optional[str] = None

    @classmethod
    def from_file(cls, path: str) -> "DownloadConfig":
        """Load config from a JSON file."""
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        data = json.loads(p.read_text())
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def to_file(self, path: str) -> None:
        """Persist config (excluding callables) to a JSON file."""
        d = {k: v for k, v in asdict(self).items()
             if not callable(v) and k not in ("progress_hook", "post_hook")}
        Path(path).write_text(json.dumps(d, indent=2))


@dataclass
class DownloadResult:
    """Result of a single download task."""
    job_id: str = ""
    url: str = ""
    status: str = "pending"          # pending|running|success|failed|cancelled
    output_file: Optional[str] = None
    title: Optional[str] = None
    duration: Optional[int] = None   # seconds
    filesize: Optional[int] = None   # bytes
    resolution: Optional[str] = None
    codec: Optional[str] = None
    error: Optional[str] = None
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    progress_pct: float = 0.0
    speed: Optional[str] = None
    eta: Optional[int] = None        # seconds

    def to_dict(self) -> Dict:
        return asdict(self)
