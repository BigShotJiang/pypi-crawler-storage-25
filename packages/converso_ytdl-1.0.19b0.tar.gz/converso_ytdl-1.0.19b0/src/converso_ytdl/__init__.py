"""
Converso Media Downloader
Professional-grade YouTube & media downloader from Converso Empire.

© 2025 Converso Empire
Licensed under Apache 2.0
"""

from .core import (
    MediaDownloader,
    RESOLUTION_MAP,
    AUDIO_CODECS,
    SAMPLE_RATES,
    BIT_DEPTHS,
    UPSCALE_METHODS,
    check_dependencies,
)
from .config import DownloadConfig, DownloadResult
from .cli import interactive_mode, build_parser, main

__version__ = "1.0.19b0"
__author__ = "Converso Empire"
__license__ = "Apache 2.0"

__all__ = [
    "MediaDownloader",
    "DownloadConfig",
    "DownloadResult",
    "RESOLUTION_MAP",
    "AUDIO_CODECS",
    "SAMPLE_RATES",
    "BIT_DEPTHS",
    "UPSCALE_METHODS",
    "check_dependencies",
    "interactive_mode",
    "build_parser",
    "main",
]
