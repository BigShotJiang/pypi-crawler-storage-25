"""
CLI interface for Converso Media Downloader.
Supports interactive and argument-based modes.
"""

import sys
import argparse
from datetime import datetime
from pathlib import Path
from typing import Optional

from .core import (
    MediaDownloader,
    RESOLUTION_MAP,
    AUDIO_CODECS,
    SAMPLE_RATES,
    BIT_DEPTHS,
    UPSCALE_METHODS,
    check_dependencies,
)
from .config import DownloadConfig, DownloadResult
from . import __version__

# Try importing rich for beautiful UI
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.progress import (
        Progress, BarColumn, TextColumn,
        DownloadColumn, TransferSpeedColumn, TimeRemainingColumn, SpinnerColumn
    )
    from rich.prompt import Prompt, Confirm
    from rich.rule import Rule
    from rich import box
    HAS_RICH = True
    console = Console()
except ImportError:
    HAS_RICH = False
    console = None

# Banner for interactive mode
BANNER = r"""
   ██████╗ ██████╗ ███╗   ██╗██╗   ██╗███████╗██████╗ ███████╗ ██████╗ 
  ██╔════╝██╔═══██╗████╗  ██║██║   ██║██╔════╝██╔══██╗██╔════╝██╔═══██╗
  ██║     ██║   ██║██╔██╗ ██║██║   ██║█████╗  ██████╔╝███████╗██║   ██║
  ██║     ██║   ██║██║╚██╗██║╚██╗ ██╔╝██╔══╝  ██╔══██╗╚════██║██║   ██║
  ╚██████╗╚██████╔╝██║ ╚████║ ╚████╔╝ ███████╗██║  ██║███████║╚██████╔╝
   ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝╚══════╝ ╚═════╝ 
        MEDIA DOWNLOADER  •  Converso Empire  •  v{version}
"""

AI_UPSCALE_GUIDE = """
[bold cyan]🤖 AI UPSCALING GUIDE[/bold cyan]
[dim]──────────────────────────────────────────────────────────────[/dim]

[bold]1.  Real-ESRGAN[/bold]  (Free · Open Source · GPU Required)
    [cyan]github.com/xinntao/Real-ESRGAN[/cyan]
    [dim]python inference_realesrgan.py -n RealESRGAN_x4plus -i input.mp4 -o output.mp4[/dim]

[bold]2.  Topaz Video AI[/bold]  (Paid $299 · Best Quality · GUI)
    [cyan]topazlabs.com/video-ai[/cyan]

[bold]3.  Video2X[/bold]  (Free · Open Source)
    [cyan]github.com/k4yt3x/video2x[/cyan]
    [dim]video2x -i input.mp4 -o output.mp4 -r2 4[/dim]

[bold]4.  Waifu2x[/bold]  (Free · Anime/Animation optimised)

[bold yellow]⚠  Important Facts:[/bold yellow]
  • AI upscaling [italic]cannot invent detail[/italic] that doesn't exist in the source
  • 1080p → 8K is still 1080p quality, just physically larger pixels
  • 1 hr video to 8K can take 10–50 hrs on an RTX 3090
  • Requires 16 GB+ VRAM for 8K AI upscaling
  • Output files may exceed 100 GB

[bold green]💡 Recommendation:[/bold green]
  Download highest quality (this tool does that), then upscale only if
  you truly need larger resolution for a specific purpose.
[dim]──────────────────────────────────────────────────────────────[/dim]
"""


def _print(msg: str, style: str = "") -> None:
    """Print with rich or plain text fallback."""
    if HAS_RICH and console:
        console.print(msg, style=style) if style else console.print(msg)
    else:
        import re
        clean = re.sub(r"\[/?[^\]]*\]", "", msg)
        print(clean)


def _rule(title: str = "") -> None:
    """Print a horizontal rule."""
    if HAS_RICH and console:
        console.print(Rule(title, style="cyan"))
    else:
        print(f"\n{'─'*60} {title} {'─'*60}" if title else "─"*60)


def interactive_mode(downloader: MediaDownloader) -> None:
    """Rich, menu-driven interactive interface."""

    def _header() -> None:
        if HAS_RICH:
            console.clear()
            console.print(BANNER.format(version=__version__), style="cyan bold")
            console.print(Rule(style="cyan dim"))
        else:
            print(f"\n  CONVERSO MEDIA DOWNLOADER v{__version__}\n" + "─"*60)

    def _menu() -> str:
        _print("")
        options = [
            ("[1]", "📹", "Download Video",    "Best quality MKV/MP4"),
            ("[2]", "🎵", "Download Audio",    "96kHz / 24-bit WAV (or other codec)"),
            ("[3]", "📋", "Batch Download",    "Process a list of URLs from file"),
            ("[4]", "📺", "Download Playlist", "Full YouTube / other playlist"),
            ("[5]", "🔍", "Get Video Info",    "Metadata & available formats"),
            ("[6]", "📊", "List Formats",      "All available quality levels"),
            ("[7]", "🚀", "Upscale Video",     "FFmpeg 4K/8K enhancement"),
            ("[8]", "🔬", "Analyse File",      "Inspect a local media file"),
            ("[9]", "🤖", "AI Upscaling Guide","Topaz / Real-ESRGAN guide"),
            ("[0]", "🚪", "Exit",              ""),
        ]
        if HAS_RICH:
            t = Table(box=box.SIMPLE, show_header=False, padding=(0, 1))
            t.add_column("Key",   style="bold yellow", width=4)
            t.add_column("Icon",  width=3)
            t.add_column("Action", style="bold white", width=22)
            t.add_column("Note",  style="dim", width=42)
            for row in options:
                t.add_row(*row)
            console.print(t)
            return Prompt.ask("[yellow]▶  Enter choice[/yellow]", default="0").strip()
        else:
            for k, ic, act, note in options:
                print(f"  {k}  {ic} {act:<22} {note}")
            return input("\n▶  Enter choice: ").strip()

    def _ask(prompt: str, default: str = "") -> str:
        if HAS_RICH:
            return Prompt.ask(f"[cyan]{prompt}[/cyan]", default=default).strip()
        return input(f"{prompt} [{default}]: ").strip() or default

    def _confirm(prompt: str) -> bool:
        if HAS_RICH:
            return Confirm.ask(f"[yellow]{prompt}[/yellow]")
        return input(f"{prompt} [y/N]: ").strip().lower() == "y"

    def _show_result(r: DownloadResult) -> None:
        _rule()
        if r.status == "success":
            _print(f"[bold green]✅ Success![/bold green]  {r.title or r.url}")
            if r.output_file:
                _print(f"   Saved  → [cyan]{r.output_file}[/cyan]")
        else:
            _print(f"[bold red]❌ Failed:[/bold red] {r.error}")
        _rule()

    check_dependencies(require_ffmpeg=True)

    while True:
        _header()
        choice = _menu()

        if choice == "0":
            _print("[cyan]Goodbye! 👋[/cyan]")
            break

        elif choice == "1":  # Video
            url = _ask("YouTube / media URL")
            if not url:
                continue
            upscale = _ask("Upscale after download? [4k/8k/1440p/skip]", "skip").lower()
            cfg = DownloadConfig(
                output_dir    = downloader.config.output_dir,
                upscale_target= None if upscale == "skip" else upscale,
                verbose       = downloader.config.verbose,
            )
            _rule("⬇  Downloading Video")
            r = downloader.download_video(url, cfg)
            _show_result(r)
            if r.output_file:
                data = downloader.analyze_file(r.output_file)
                if data:
                    _print(f"[green]✅ File analysis available[/green]")

        elif choice == "2":  # Audio
            url = _ask("YouTube / media URL")
            if not url:
                continue
            codec_choice = _ask("Audio format [wav/flac/mp3/aac/ogg/opus]", "wav").lower()
            sr_choice    = _ask("Sample rate [44100/48000/96000/192000]", "96000")
            bd_choice    = _ask("Bit depth [16/24/32] (WAV/FLAC only)", "24")
            cfg = DownloadConfig(
                output_dir      = downloader.config.output_dir,
                audio_codec     = codec_choice,
                audio_sample_rate= SAMPLE_RATES.get(sr_choice, 96000),
                audio_bit_depth = BIT_DEPTHS.get(bd_choice, "pcm_s24le"),
                verbose         = downloader.config.verbose,
            )
            _rule("⬇  Downloading Audio")
            r = downloader.download_audio(url, cfg)
            _show_result(r)

        elif choice == "3":  # Batch
            file_path = _ask("Path to URL list file")
            if not Path(file_path).exists():
                _print(f"[red]File not found: {file_path}[/red]")
                continue
            mode = _ask("Mode [video/audio]", "video").lower()
            urls = [l.strip() for l in Path(file_path).read_text().splitlines()
                    if l.strip() and not l.startswith("#")]
            _print(f"[green]Found {len(urls)} URLs[/green]")
            if not _confirm(f"Start batch {mode} download?"):
                continue

            def _pb(idx, total, r):
                s = "✅" if r.status == "success" else "❌"
                _print(f"  {s} [{idx}/{total}] {r.title or r.url}")

            results = downloader.batch_download(urls, mode=mode, progress_cb=_pb)
            ok  = sum(1 for r in results if r.status == "success")
            err = sum(1 for r in results if r.status == "failed")
            _rule("📊 Batch Summary")
            _print(f"  ✅ Success : [green]{ok}[/green]")
            _print(f"  ❌ Failed  : [red]{err}[/red]")
            if err:
                failed_file = f"failed_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                Path(failed_file).write_text("\n".join(r.url for r in results if r.status == "failed"))
                _print(f"  💾 Failed URLs saved → [cyan]{failed_file}[/cyan]")

        elif choice == "4":  # Playlist
            url  = _ask("Playlist URL")
            if not url:
                continue
            mode = _ask("Mode [video/audio]", "video").lower()
            _rule("⬇  Downloading Playlist")
            r = downloader.download_playlist(url, mode=mode)
            _show_result(r)

        elif choice == "5":  # Info
            url = _ask("YouTube / media URL")
            if url:
                _rule("📋 Video Info")
                try:
                    info = downloader.get_info(url)
                    dur  = info.get("duration", 0)
                    mins, secs = divmod(int(dur), 60)
                    _print(f"[cyan]Title[/cyan]: {info.get('title')}")
                    _print(f"[cyan]Channel[/cyan]: {info.get('uploader')}")
                    _print(f"[cyan]Duration[/cyan]: {mins}:{secs:02d}")
                    _print(f"[cyan]Views[/cyan]: {info.get('view_count', 0):,}")
                except Exception as e:
                    _print(f"[red]Error: {e}[/red]")

        elif choice == "6":  # Formats
            url = _ask("YouTube / media URL")
            if url:
                _rule("📊 Available Formats")
                try:
                    formats = downloader.list_formats(url)
                    if not formats:
                        _print("[yellow]No formats found.[/yellow]")
                    elif HAS_RICH:
                        t = Table(title="Available Formats", box=box.ROUNDED, border_style="cyan")
                        for col in ["ID", "Ext", "Resolution", "FPS", "VCodec", "ACodec"]:
                            t.add_column(col, style="white")
                        for f in formats[:20]:  # Show first 20
                            t.add_row(
                                str(f.get("format_id", "")),
                                f.get("ext", ""),
                                f.get("resolution", f"{f.get('width', '?')}x{f.get('height', '?')}"),
                                str(f.get("fps", "")),
                                f.get("vcodec", "none"),
                                f.get("acodec", "none"),
                            )
                        console.print(t)
                    else:
                        for f in formats[:10]:
                            _print(f"  {f.get('format_id'):>10}  {f.get('ext'):>6}  {f.get('resolution', '?')}")
                except Exception as e:
                    _print(f"[red]Error: {e}[/red]")

        elif choice == "7":  # Upscale
            src = _ask("Path to local video file")
            if not Path(src).exists():
                _print(f"[red]File not found: {src}[/red]")
                continue
            target = _ask("Target resolution [4k/8k/1440p/1080p/720p]", "4k").lower()
            method = _ask("Scaling method [lanczos/bicubic/spline/neighbor]", "lanczos").lower()
            _rule("🚀 Upscaling")
            out = downloader.upscale_video(src, target, method)
            if out:
                _print(f"[green]✅ Saved → {out}[/green]")

        elif choice == "8":  # Analyse
            src = _ask("Path to local media file")
            if Path(src).exists():
                data = downloader.analyze_file(src)
                if data:
                    _print(f"[green]✅ Analysis complete[/green]")
            else:
                _print(f"[red]File not found: {src}[/red]")

        elif choice == "9":  # AI Guide
            if HAS_RICH:
                console.print(Panel(AI_UPSCALE_GUIDE, title="🤖 AI Upscaling", border_style="magenta"))
            else:
                _print(AI_UPSCALE_GUIDE)

        if choice != "0":
            input("\n  Press Enter to return to menu…")


def build_parser() -> argparse.ArgumentParser:
    """Build argument parser for CLI."""
    p = argparse.ArgumentParser(
        prog="converso-ytdl",
        description=f"Converso Media Downloader v{__version__}",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Commands:
  video     Download best-quality video
  audio     Download professional audio (WAV/FLAC/MP3/…)
  batch     Batch-download URLs from a file
  playlist  Download an entire playlist
  info      Show metadata for a URL
  formats   List available format/quality combinations
  upscale   Upscale a local video file

Examples:
  converso-ytdl video  https://youtu.be/...
  converso-ytdl audio  https://youtu.be/...  --codec flac --sample-rate 192000
  converso-ytdl batch  -f urls.txt --mode audio --workers 2
  converso-ytdl playlist https://... --mode video --archive done.txt
  converso-ytdl upscale  ./downloads/video.mkv --target 4k
        """,
    )
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    # Global options
    g = p.add_argument_group("Global Options")
    g.add_argument("-o", "--output",     default="downloads",    help="Output directory (default: downloads)")
    g.add_argument("--proxy",                                     help="Proxy URL (http/socks5)")
    g.add_argument("--rate-limit",       metavar="RATE",          help="Download rate limit e.g. 5M")
    g.add_argument("--concurrent",       type=int, default=4,     help="Concurrent fragment downloads (default: 4)")
    g.add_argument("--retries",          type=int, default=5,     help="Retry attempts (default: 5)")
    g.add_argument("-v", "--verbose",    action="store_true",     help="Verbose logging")
    g.add_argument("-q", "--quiet",      action="store_true",     help="Suppress output")
    g.add_argument("--log-file",         metavar="FILE",          help="Log file name (written to logs/)")
    g.add_argument("--config",           metavar="FILE",          help="JSON config file")

    subs = p.add_subparsers(dest="command", metavar="<command>")

    # ── video ──────────────────────────────────────────────────────────────────
    sv = subs.add_parser("video", help="Download best-quality video")
    sv.add_argument("url",                                           help="Media URL")
    sv.add_argument("--container",   default="mkv",
                    choices=["mkv", "mp4", "webm"],                  help="Output container (default: mkv)")
    sv.add_argument("--no-subs",     action="store_true",            help="Skip subtitle embedding")
    sv.add_argument("--no-thumb",    action="store_true",            help="Skip thumbnail embedding")
    sv.add_argument("--no-chapters", action="store_true",            help="Skip chapter markers")
    sv.add_argument("--sub-langs",   default="en,ar",                help="Subtitle languages (default: en,ar)")
    sv.add_argument("-u", "--upscale",
                    choices=list(RESOLUTION_MAP.keys()),              help="Upscale after download")
    sv.add_argument("-m", "--method", default="lanczos",
                    choices=UPSCALE_METHODS,                         help="Upscale method (default: lanczos)")

    # ── audio ──────────────────────────────────────────────────────────────────
    sa = subs.add_parser("audio", help="Download professional audio")
    sa.add_argument("url",                                           help="Media URL")
    sa.add_argument("--codec",        default="wav",
                    choices=list(AUDIO_CODECS.keys()),               help="Output audio codec (default: wav)")
    sa.add_argument("--sample-rate",  default="96000",
                    choices=list(SAMPLE_RATES.keys()),               help="Sample rate Hz (default: 96000)")
    sa.add_argument("--bit-depth",    default="24",
                    choices=list(BIT_DEPTHS.keys()),                 help="PCM bit depth (default: 24 / pcm_s24le)")
    sa.add_argument("--channels",     default=2, type=int,
                    choices=[1, 2],                                  help="Audio channels 1=mono 2=stereo (default: 2)")

    # ── batch ──────────────────────────────────────────────────────────────────
    sb = subs.add_parser("batch", help="Batch download from URL file")
    sb.add_argument("-f", "--file",   required=True,                 help="Text file with URLs (one per line, # = comment)")
    sb.add_argument("--mode",         default="video",
                    choices=["video", "audio"],                      help="Download mode (default: video)")
    sb.add_argument("--workers",      type=int, default=1,           help="Parallel workers (default: 1)")
    sb.add_argument("--delay",        type=float, default=3.0,       help="Seconds between downloads (default: 3)")
    sb.add_argument("--stop-on-error",action="store_true",           help="Stop batch on first failure")
    sb.add_argument("--codec",        default="wav",
                    choices=list(AUDIO_CODECS.keys()),               help="Audio codec (if mode=audio)")
    sb.add_argument("--sample-rate",  default="96000",
                    choices=list(SAMPLE_RATES.keys()),               help="Sample rate (if mode=audio)")

    # ── playlist ───────────────────────────────────────────────────────────────
    sp = subs.add_parser("playlist", help="Download full playlist")
    sp.add_argument("url",                                           help="Playlist URL")
    sp.add_argument("--mode",         default="video",
                    choices=["video", "audio"],                      help="Download mode (default: video)")
    sp.add_argument("--archive",      metavar="FILE",                help="Archive file (skip already-downloaded)")
    sp.add_argument("--start",        type=int,                      help="Playlist start index")
    sp.add_argument("--end",          type=int,                      help="Playlist end index")
    sp.add_argument("--items",        metavar="ITEMS",               help="Playlist item spec, e.g. 1,3,5-8")

    # ── info ───────────────────────────────────────────────────────────────────
    si = subs.add_parser("info", help="Show video metadata")
    si.add_argument("url",                                           help="Media URL")

    # ── formats ────────────────────────────────────────────────────────────────
    sf = subs.add_parser("formats", help="List available formats")
    sf.add_argument("url",                                           help="Media URL")

    # ── upscale ────────────────────────────────────────────────────────────────
    su = subs.add_parser("upscale", help="Upscale local video file")
    su.add_argument("file",                                          help="Path to input video file")
    su.add_argument("--target",       default="4k",
                    choices=list(RESOLUTION_MAP.keys()),             help="Target resolution (default: 4k)")
    su.add_argument("--method",       default="lanczos",
                    choices=UPSCALE_METHODS,                         help="Scaling algorithm (default: lanczos)")

    return p


def _config_from_args(args: argparse.Namespace) -> DownloadConfig:
    """Build a DownloadConfig from parsed args."""
    if getattr(args, "config", None):
        cfg = DownloadConfig.from_file(args.config)
    else:
        cfg = DownloadConfig()

    cfg.output_dir          = args.output
    cfg.proxy               = getattr(args, "proxy", None)
    cfg.rate_limit          = getattr(args, "rate_limit", None)
    cfg.concurrent_fragments= getattr(args, "concurrent", 4)
    cfg.retries             = getattr(args, "retries", 5)
    cfg.verbose             = getattr(args, "verbose", False)
    cfg.quiet               = getattr(args, "quiet", False)
    cfg.log_file            = getattr(args, "log_file", None)

    cmd = getattr(args, "command", None)
    if cmd == "video":
        cfg.video_container  = args.container
        cfg.no_subs          = args.no_subs
        cfg.embed_thumbnail  = not args.no_thumb
        cfg.embed_chapters   = not args.no_chapters
        cfg.sub_langs        = args.sub_langs
        cfg.upscale_target   = args.upscale
        cfg.upscale_method   = args.method
    elif cmd == "audio":
        cfg.audio_codec      = args.codec
        cfg.audio_sample_rate= SAMPLE_RATES.get(args.sample_rate, 96000)
        cfg.audio_bit_depth  = BIT_DEPTHS.get(args.bit_depth, "pcm_s24le")
        cfg.audio_channels   = args.channels
    elif cmd == "batch":
        cfg.batch_delay      = args.delay
        cfg.workers          = args.workers
        cfg.stop_on_error    = args.stop_on_error
        if getattr(args, "codec", None):
            cfg.audio_codec  = args.codec
        if getattr(args, "sample_rate", None):
            cfg.audio_sample_rate = SAMPLE_RATES.get(args.sample_rate, 96000)
    elif cmd == "playlist":
        cfg.playlist_archive = getattr(args, "archive", None)
        cfg.playlist_start   = getattr(args, "start", None)
        cfg.playlist_end     = getattr(args, "end", None)
        cfg.playlist_items   = getattr(args, "items", None)

    return cfg


def _args_mode(args: argparse.Namespace) -> None:
    """Execute the requested command from parsed arguments."""
    cfg        = _config_from_args(args)
    downloader = MediaDownloader(cfg)
    cmd        = args.command

    def _ok(r: DownloadResult) -> None:
        if r.status == "success":
            _print(f"[green]✅ {r.title or r.url}[/green]")
            if r.output_file:
                _print(f"   → [cyan]{r.output_file}[/cyan]")
        else:
            _print(f"[red]❌ {r.error}[/red]")
            sys.exit(1)

    if cmd == "video":
        _rule(f"⬇  Video  {args.url}")
        r = downloader.download_video(args.url, cfg)
        _ok(r)

    elif cmd == "audio":
        _rule(f"⬇  Audio  {args.url}")
        r = downloader.download_audio(args.url, cfg)
        _ok(r)

    elif cmd == "batch":
        fp = Path(args.file)
        if not fp.exists():
            _print(f"[red]File not found: {fp}[/red]")
            sys.exit(1)
        urls = [l.strip() for l in fp.read_text().splitlines()
                if l.strip() and not l.startswith("#")]
        _print(f"[cyan]Batch: {len(urls)} URLs  mode={args.mode}[/cyan]")

        def _pb(idx, total, r):
            s = "✅" if r.status == "success" else "❌"
            _print(f"  {s} [{idx:>3}/{total}] {r.title or r.url}")

        results = downloader.batch_download(urls, mode=args.mode, config=cfg, progress_cb=_pb)
        ok  = sum(1 for r in results if r.status == "success")
        err = sum(1 for r in results if r.status == "failed")
        _rule("📊 Batch Summary")
        _print(f"  ✅ {ok}/{len(results)} succeeded")
        _print(f"  ❌ {err}/{len(results)} failed")
        if err:
            ff = f"failed_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
            Path(ff).write_text("\n".join(r.url for r in results if r.status == "failed"))
            _print(f"  💾 Failed URLs → [cyan]{ff}[/cyan]")
        sys.exit(0 if err == 0 else 1)

    elif cmd == "playlist":
        _rule(f"⬇  Playlist  {args.url}")
        r = downloader.download_playlist(args.url, mode=args.mode, config=cfg)
        _ok(r)

    elif cmd == "info":
        try:
            info = downloader.get_info(args.url)
            dur  = info.get("duration", 0)
            mins, secs = divmod(int(dur), 60)
            _print(f"[cyan]Title[/cyan]: {info.get('title')}")
            _print(f"[cyan]Channel[/cyan]: {info.get('uploader')}")
            _print(f"[cyan]Duration[/cyan]: {mins}:{secs:02d}")
        except Exception as e:
            _print(f"[red]Error: {e}[/red]")
            sys.exit(1)

    elif cmd == "formats":
        try:
            formats = downloader.list_formats(args.url)
            _print(f"[cyan]Found {len(formats)} formats[/cyan]")
            for f in formats[:10]:
                _print(f"  {f.get('format_id'):>10}  {f.get('ext'):>6}  {f.get('resolution', '?')}")
        except Exception as e:
            _print(f"[red]Error: {e}[/red]")
            sys.exit(1)

    elif cmd == "upscale":
        if not Path(args.file).exists():
            _print(f"[red]File not found: {args.file}[/red]")
            sys.exit(1)
        out = downloader.upscale_video(args.file, args.target, args.method)
        if out:
            _print(f"[green]✅ Saved → {out}[/green]")
        else:
            sys.exit(1)


def main() -> None:
    """Entry point for CLI."""
    if len(sys.argv) > 1:
        parser = build_parser()
        args   = parser.parse_args()
        if not args.command:
            parser.print_help()
            sys.exit(0)
        _args_mode(args)
    else:
        cfg        = DownloadConfig()
        downloader = MediaDownloader(cfg)
        interactive_mode(downloader)


if __name__ == "__main__":
    main()
