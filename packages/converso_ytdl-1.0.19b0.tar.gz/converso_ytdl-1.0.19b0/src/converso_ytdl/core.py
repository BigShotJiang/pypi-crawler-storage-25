"""
Core media downloader engine powering Converso Media Downloader.
"""

import os
import sys
import json
import time
import shutil
import logging
import threading
import uuid
import subprocess
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple
from concurrent.futures import ThreadPoolExecutor, as_completed
from queue import Queue, Empty

try:
    import yt_dlp
except ImportError:
    print("❌ yt-dlp not found. Install: pip install yt-dlp")
    sys.exit(1)

from .config import DownloadConfig, DownloadResult


# Constants
RESOLUTION_MAP = {
    "4k":    "3840:2160",
    "8k":    "7680:4320",
    "1440p": "2560:1440",
    "1080p": "1920:1080",
    "720p":  "1280:720",
}

SAMPLE_RATES = {
    "44100":  44100,
    "48000":  48000,
    "88200":  88200,
    "96000":  96000,
    "192000": 192000,
}

BIT_DEPTHS = {
    "16": "pcm_s16le",
    "24": "pcm_s24le",
    "32": "pcm_s32le",
}

AUDIO_CODECS = {
    "wav":  "wav",
    "flac": "flac",
    "mp3":  "mp3",
    "aac":  "aac",
    "ogg":  "vorbis",
    "opus": "opus",
}

UPSCALE_METHODS = ["lanczos", "bicubic", "spline", "neighbor", "sinc", "gauss"]

LOG_DIR = Path("logs")


def _setup_logger(name: str = "converso", verbose: bool = False,
                  log_file: Optional[str] = None) -> logging.Logger:
    """Set up logger with console and optional file output."""
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    level = logging.DEBUG if verbose else logging.INFO
    logger.setLevel(level)
    fmt = logging.Formatter(
        "%(asctime)s [%(levelname)-8s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    ch = logging.StreamHandler(sys.stderr)
    ch.setLevel(level)
    ch.setFormatter(fmt)
    logger.addHandler(ch)
    if log_file:
        LOG_DIR.mkdir(exist_ok=True)
        fh = logging.FileHandler(LOG_DIR / log_file, encoding="utf-8")
        fh.setLevel(logging.DEBUG)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


def check_dependencies(require_ffmpeg: bool = True) -> bool:
    """Check for required system dependencies."""
    missing = []
    if not shutil.which("ffmpeg") and require_ffmpeg:
        missing.append("ffmpeg")
    if not shutil.which("ffprobe") and require_ffmpeg:
        missing.append("ffprobe")
    if missing:
        raise RuntimeError(
            f"Missing system dependencies: {', '.join(missing)}. "
            "Install: Ubuntu/Debian (apt install ffmpeg), macOS (brew install ffmpeg), "
            "Windows (https://ffmpeg.org/download.html)"
        )
    return True


class MediaDownloader:
    """
    Enterprise-grade media downloader using yt-dlp.
    Thread-safe. Suitable for direct use or via API.
    
    © 2025 Converso Empire
    Licensed under Apache 2.0
    """

    def __init__(self, config: Optional[DownloadConfig] = None):
        self.config = config or DownloadConfig()
        self.logger = _setup_logger(
            verbose=self.config.verbose,
            log_file=self.config.log_file
        )
        Path(self.config.output_dir).mkdir(parents=True, exist_ok=True)
        self._active_jobs: Dict[str, DownloadResult] = {}
        self._lock = threading.Lock()

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _outtmpl(self, subdir: Optional[str] = None) -> str:
        if self.config.output_template:
            return self.config.output_template
        base = Path(self.config.output_dir)
        if subdir:
            base = base / subdir
        return str(base / "%(title)s.%(ext)s")

    def _make_progress_hook(self, result: DownloadResult) -> Callable:
        def hook(d: Dict) -> None:
            status = d.get("status")
            if status == "downloading":
                result.status   = "running"
                result.speed    = d.get("_speed_str", "")
                total           = d.get("total_bytes") or d.get("total_bytes_estimate", 0)
                downloaded      = d.get("downloaded_bytes", 0)
                result.progress_pct = (downloaded / total * 100) if total else 0
                result.eta      = d.get("eta")
                if self.config.progress_hook:
                    self.config.progress_hook(result)
            elif status == "finished":
                result.output_file = d.get("filename") or d.get("info_dict", {}).get("_filename")
                result.progress_pct = 100.0
            elif status == "error":
                result.status = "failed"
                result.error  = str(d.get("error", "Unknown error"))
        return hook

    def _base_ydl_opts(self, result: DownloadResult) -> Dict:
        opts: Dict[str, Any] = {
            "quiet":            self.config.quiet,
            "verbose":          self.config.verbose,
            "no_warnings":      False,
            "retries":          self.config.retries,
            "fragment_retries": self.config.retries,
            "progress_hooks":   [self._make_progress_hook(result)],
        }
        if self.config.proxy:
            opts["proxy"] = self.config.proxy
        if self.config.rate_limit:
            opts["ratelimit"] = self.config.rate_limit
        return opts

    def _register(self, result: DownloadResult) -> None:
        with self._lock:
            self._active_jobs[result.job_id] = result

    def _finalise(self, result: DownloadResult, success: bool, error: str = "") -> DownloadResult:
        result.status      = "success" if success else "failed"
        result.finished_at = datetime.utcnow().isoformat()
        if error:
            result.error = error
        if self.config.post_hook:
            try:
                self.config.post_hook(result)
            except Exception as e:
                self.logger.warning("Post-hook error: %s", e)
        return result

    # ── Info / Formats ─────────────────────────────────────────────────────────

    def get_info(self, url: str) -> Dict:
        """Return raw yt-dlp info dict for a URL."""
        opts = {"quiet": True, "no_warnings": True, "noplaylist": True}
        self.logger.debug("Fetching info: %s", url)
        with yt_dlp.YoutubeDL(opts) as ydl:
            return ydl.extract_info(url, download=False)

    def list_formats(self, url: str) -> List[Dict]:
        """Return list of available format dicts."""
        info = self.get_info(url)
        return info.get("formats", [])

    # ── Video Download ─────────────────────────────────────────────────────────

    def download_video(self, url: str, config: Optional[DownloadConfig] = None) -> DownloadResult:
        """Download best-quality video + audio and merge."""
        cfg    = config or self.config
        result = DownloadResult(
            job_id=str(uuid.uuid4()),
            url=url,
            started_at=datetime.utcnow().isoformat()
        )
        self._register(result)
        self.logger.info("Starting video download: %s", url)

        # Format selector: prefer VP9/AV1 + Opus, then H.264 + AAC, then best
        fmt = (
            "bestvideo[ext=webm][vcodec^=vp9]+bestaudio[ext=webm][acodec=opus]"
            "/bestvideo[ext=webm][vcodec^=av01]+bestaudio[ext=webm][acodec=opus]"
            "/bestvideo[ext=mp4]+bestaudio[ext=m4a]"
            "/bestvideo+bestaudio/best"
        )

        opts = self._base_ydl_opts(result)
        opts.update({
            "format":               fmt,
            "merge_output_format":  cfg.video_container,
            "outtmpl":              self._outtmpl(),
            "noplaylist":           True,
            "concurrent_fragment_downloads": cfg.concurrent_fragments,
            "embedthumbnail":       cfg.embed_thumbnail,
            "addmetadata":          cfg.embed_metadata,
            "embed_chapters":       cfg.embed_chapters,
        })
        if cfg.embed_subs and not cfg.no_subs:
            opts.update({
                "writesubtitles":  True,
                "subtitleslangs":  cfg.sub_langs.split(","),
                "subtitlesformat": "srt",
                "embedsubtitles":  True,
            })

        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                result.title    = info.get("title")
                result.duration = info.get("duration")
                h = info.get("height", 0)
                result.resolution = (
                    "8K" if h >= 4320 else "4K" if h >= 2160 else
                    "1440p" if h >= 1440 else "1080p" if h >= 1080 else
                    "720p" if h >= 720 else "SD"
                )
                result.codec = info.get("vcodec", "")
            self.logger.info("Video download complete: %s", result.title)
            result = self._finalise(result, True)

            # Upscale if requested
            if cfg.upscale_target and result.output_file:
                self.upscale_video(result.output_file, cfg.upscale_target, cfg.upscale_method)

        except yt_dlp.utils.DownloadError as e:
            self.logger.error("Download error: %s", e)
            result = self._finalise(result, False, str(e))
        except Exception as e:
            self.logger.exception("Unexpected error during video download")
            result = self._finalise(result, False, str(e))

        return result

    # ── Audio Download ─────────────────────────────────────────────────────────

    def download_audio(self, url: str, config: Optional[DownloadConfig] = None) -> DownloadResult:
        """Download best audio and convert to specified format."""
        cfg    = config or self.config
        result = DownloadResult(
            job_id=str(uuid.uuid4()),
            url=url,
            started_at=datetime.utcnow().isoformat()
        )
        self._register(result)
        self.logger.info("Starting audio download: %s", url)

        target_codec = AUDIO_CODECS.get(cfg.audio_codec, "wav")
        is_wav_like  = target_codec in ("wav", "flac")

        postprocessors: List[Dict] = [{
            "key":            "FFmpegExtractAudio",
            "preferredcodec": target_codec,
        }]

        # Extra FFmpeg args for professional WAV/FLAC
        postprocessor_args: List[str] = []
        if is_wav_like:
            postprocessor_args = [
                "-ar", str(cfg.audio_sample_rate),
                "-ac", str(cfg.audio_channels),
                "-acodec", cfg.audio_bit_depth,
            ]
        elif target_codec == "mp3":
            postprocessor_args = ["-q:a", "0"]  # VBR best quality
        elif target_codec in ("aac", "opus"):
            postprocessor_args = ["-b:a", "320k"]

        opts = self._base_ydl_opts(result)
        opts.update({
            "format":              "bestaudio/best",
            "outtmpl":             self._outtmpl(),
            "noplaylist":          True,
            "postprocessors":      postprocessors,
            "postprocessor_args":  postprocessor_args,
            "writethumbnail":      False,
            "embedthumbnail":      False,
            "addmetadata":         False,
            "writeinfojson":       False,
        })

        try:
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(url, download=True)
                result.title    = info.get("title")
                result.duration = info.get("duration")
                result.codec    = target_codec
            self.logger.info("Audio download complete: %s", result.title)
            result = self._finalise(result, True)
        except yt_dlp.utils.DownloadError as e:
            self.logger.error("Audio download error: %s", e)
            result = self._finalise(result, False, str(e))
        except Exception as e:
            self.logger.exception("Unexpected error during audio download")
            result = self._finalise(result, False, str(e))

        return result

    # ── Playlist Download ──────────────────────────────────────────────────────

    def download_playlist(self, url: str, mode: str = "video",
                          config: Optional[DownloadConfig] = None) -> DownloadResult:
        """Download an entire playlist in video or audio mode."""
        cfg    = config or self.config
        result = DownloadResult(
            job_id=str(uuid.uuid4()),
            url=url,
            started_at=datetime.utcnow().isoformat()
        )
        self._register(result)
        self.logger.info("Starting playlist download: %s [mode=%s]", url, mode)

        sub_opts = deepcopy(cfg)
        sub_opts.output_template = str(
            Path(cfg.output_dir) / "%(playlist_title)s" / "%(playlist_index)s - %(title)s.%(ext)s"
        )

        if mode == "audio":
            base_opts = self._base_ydl_opts(result)
            base_opts.update({
                "format":             "bestaudio/best",
                "outtmpl":            sub_opts.output_template,
                "postprocessors":     [{"key": "FFmpegExtractAudio", "preferredcodec": AUDIO_CODECS.get(cfg.audio_codec, "wav")}],
                "postprocessor_args": ["-ar", str(cfg.audio_sample_rate), "-ac", str(cfg.audio_channels), "-acodec", cfg.audio_bit_depth],
            })
        else:
            base_opts = self._base_ydl_opts(result)
            base_opts.update({
                "format":              "bestvideo+bestaudio/best",
                "merge_output_format": cfg.video_container,
                "outtmpl":             sub_opts.output_template,
                "embedthumbnail":      cfg.embed_thumbnail,
                "addmetadata":         cfg.embed_metadata,
            })

        if cfg.playlist_archive:
            base_opts["download_archive"] = cfg.playlist_archive
        if cfg.playlist_start:
            base_opts["playliststart"] = cfg.playlist_start
        if cfg.playlist_end:
            base_opts["playlistend"] = cfg.playlist_end
        if cfg.playlist_items:
            base_opts["playlist_items"] = cfg.playlist_items

        try:
            with yt_dlp.YoutubeDL(base_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                result.title = info.get("title") or info.get("playlist_title")
            result = self._finalise(result, True)
        except Exception as e:
            self.logger.exception("Playlist download error")
            result = self._finalise(result, False, str(e))

        return result

    # ── Batch Download ─────────────────────────────────────────────────────────

    def batch_download(self, urls: List[str], mode: str = "video",
                       config: Optional[DownloadConfig] = None,
                       progress_cb: Optional[Callable[[int, int, DownloadResult], None]] = None
                       ) -> List[DownloadResult]:
        """
        Download multiple URLs sequentially (workers=1) or in parallel.
        progress_cb(index, total, result) is called after each item.
        """
        cfg     = config or self.config
        results: List[DownloadResult] = []
        total   = len(urls)
        self.logger.info("Batch download: %d URLs [mode=%s, workers=%d]", total, mode, cfg.workers)

        def _process(idx_url: Tuple[int, str]) -> DownloadResult:
            idx, url = idx_url
            self.logger.info("[%d/%d] %s", idx + 1, total, url)
            if mode == "audio":
                r = self.download_audio(url, cfg)
            else:
                r = self.download_video(url, cfg)
            if progress_cb:
                try:
                    progress_cb(idx + 1, total, r)
                except Exception:
                    pass
            if idx + 1 < total and cfg.batch_delay > 0:
                time.sleep(cfg.batch_delay)
            return r

        if cfg.workers > 1:
            with ThreadPoolExecutor(max_workers=cfg.workers) as pool:
                futures = {pool.submit(_process, (i, u)): i for i, u in enumerate(urls)}
                for f in as_completed(futures):
                    r = f.result()
                    results.append(r)
                    if cfg.stop_on_error and r.status == "failed":
                        pool.shutdown(wait=False, cancel_futures=True)
                        break
        else:
            for i, url in enumerate(urls):
                r = _process((i, url))
                results.append(r)
                if cfg.stop_on_error and r.status == "failed":
                    self.logger.warning("Stopping batch on error (--stop-on-error).")
                    break

        ok  = [r for r in results if r.status == "success"]
        err = [r for r in results if r.status == "failed"]
        self.logger.info("Batch complete: %d ok, %d failed", len(ok), len(err))
        return results

    # ── Upscaler ──────────────────────────────────────────────────────────────

    def upscale_video(self, file_path: str, target: str = "4k",
                      method: str = "lanczos") -> Optional[str]:
        """Upscale a local video using FFmpeg (traditional, not AI)."""
        if not shutil.which("ffmpeg"):
            self.logger.error("ffmpeg not found; cannot upscale.")
            return None

        resolution = RESOLUTION_MAP.get(target)
        if not resolution:
            self.logger.error("Unknown target resolution: %s", target)
            return None

        src    = Path(file_path)
        dst    = src.parent / f"{src.stem}_upscaled_{target}{src.suffix}"
        self.logger.info("Upscaling %s → %s (%s, %s)", src.name, target, resolution, method)

        cmd = [
            "ffmpeg", "-y",
            "-i", str(src),
            "-vf", f"scale={resolution}:flags={method}",
            "-c:v", "libx265",
            "-crf", "18",
            "-preset", "medium",
            "-c:a", "copy",
            "-movflags", "+faststart",
            str(dst),
        ]
        try:
            subprocess.run(cmd, check=True,
                           stdout=subprocess.DEVNULL if not self.config.verbose else None,
                           stderr=subprocess.DEVNULL if not self.config.verbose else None)
            self.logger.info("Upscale complete: %s", dst)
            return str(dst)
        except Exception as e:
            self.logger.error("Upscale failed: %s", e)
            return None

    # ── Analysis ──────────────────────────────────────────────────────────────

    def analyze_file(self, file_path: str) -> Optional[Dict]:
        """Run ffprobe analysis on a local media file."""
        if not shutil.which("ffprobe"):
            self.logger.warning("ffprobe not found; skipping analysis.")
            return None
        cmd = [
            "ffprobe", "-v", "quiet",
            "-print_format", "json",
            "-show_format", "-show_streams",
            file_path,
        ]
        try:
            out = subprocess.run(cmd, capture_output=True, text=True, check=True)
            return json.loads(out.stdout)
        except Exception as e:
            self.logger.warning("ffprobe error: %s", e)
            return None

    # ── Job Access ────────────────────────────────────────────────────────────

    def get_job(self, job_id: str) -> Optional[DownloadResult]:
        """Retrieve a download result by job ID."""
        return self._active_jobs.get(job_id)

    def list_jobs(self) -> List[DownloadResult]:
        """Get all job results."""
        with self._lock:
            return list(self._active_jobs.values())
