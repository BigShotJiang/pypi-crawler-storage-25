"""
FastAPI REST server for Converso Media Downloader.

All download operations are asynchronous and tracked as Jobs.
"""

import os
import sys
import json
import uuid
import logging
import threading
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

try:
    from fastapi import FastAPI, HTTPException, Query, status
    from fastapi.middleware.cors import CORSMiddleware
    from fastapi.responses import FileResponse
    from pydantic import BaseModel, Field, validator
    import uvicorn
except ImportError:
    print("❌ FastAPI/Uvicorn not found. Install: pip install fastapi uvicorn")
    sys.exit(1)

try:
    import requests as _req_lib
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

from .. import __version__
from ..core import (
    MediaDownloader,
    RESOLUTION_MAP,
    AUDIO_CODECS,
    SAMPLE_RATES,
    BIT_DEPTHS,
    UPSCALE_METHODS,
)
from ..config import DownloadConfig, DownloadResult

# Logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)-8s] %(name)s: %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("converso-api")


# ─── In-Memory Job Store ───────────────────────────────────────────────────────

class JobStore:
    """Thread-safe job storage (use Redis/Postgres for production)."""
    
    def __init__(self) -> None:
        self._jobs: Dict[str, DownloadResult] = {}
        self._lock = threading.Lock()

    def put(self, result: DownloadResult) -> None:
        with self._lock:
            self._jobs[result.job_id] = result

    def get(self, job_id: str) -> Optional[DownloadResult]:
        return self._jobs.get(job_id)

    def all(self) -> List[DownloadResult]:
        with self._lock:
            return list(self._jobs.values())

    def delete(self, job_id: str) -> bool:
        with self._lock:
            if job_id in self._jobs:
                del self._jobs[job_id]
                return True
            return False

    def count(self) -> Dict[str, int]:
        jobs = self.all()
        return {
            "total":     len(jobs),
            "pending":   sum(1 for j in jobs if j.status == "pending"),
            "running":   sum(1 for j in jobs if j.status == "running"),
            "success":   sum(1 for j in jobs if j.status == "success"),
            "failed":    sum(1 for j in jobs if j.status == "failed"),
            "cancelled": sum(1 for j in jobs if j.status == "cancelled"),
        }


JOBS = JobStore()

# Shared downloader
_downloader: Optional[MediaDownloader] = None


def get_downloader(output_dir: str = "downloads") -> MediaDownloader:
    global _downloader
    if _downloader is None:
        _downloader = MediaDownloader(DownloadConfig(output_dir=output_dir))
    return _downloader


# ─── Pydantic Request/Response Models ─────────────────────────────────────────

class GlobalOpts(BaseModel):
    output_dir:           str            = Field("downloads", description="Output directory")
    proxy:                Optional[str]  = Field(None,        description="Proxy URL (http/socks5)")
    rate_limit:           Optional[str]  = Field(None,        description="Rate limit e.g. '5M'")
    concurrent_fragments: int            = Field(4,           ge=1, le=16)
    retries:              int            = Field(5,           ge=0, le=20)
    webhook_url:          Optional[str]  = Field(None,        description="URL to POST job result JSON when done")


class VideoRequest(GlobalOpts):
    url:             str  = Field(..., description="Media URL")
    container:       str  = Field("mkv", description="Output container: mkv | mp4 | webm")
    embed_thumbnail: bool = Field(True)
    embed_metadata:  bool = Field(True)
    embed_chapters:  bool = Field(True)
    embed_subs:      bool = Field(True)
    sub_langs:       str  = Field("en,ar")
    no_subs:         bool = Field(False)
    upscale_target:  Optional[str] = Field(None, description="4k | 8k | 1440p | 1080p | 720p")
    upscale_method:  str  = Field("lanczos")

    @validator("container")
    def _validate_container(cls, v):
        assert v in ("mkv", "mp4", "webm"), "container must be mkv, mp4, or webm"
        return v

    @validator("upscale_target")
    def _validate_upscale(cls, v):
        if v and v not in RESOLUTION_MAP:
            raise ValueError(f"upscale_target must be one of {list(RESOLUTION_MAP.keys())}")
        return v


class AudioRequest(GlobalOpts):
    url:          str = Field(..., description="Media URL")
    codec:        str = Field("wav", description="Output codec: wav | flac | mp3 | aac | ogg | opus")
    sample_rate:  str = Field("96000", description="Sample rate Hz: 44100|48000|88200|96000|192000")
    bit_depth:    str = Field("24",    description="PCM bit depth: 16 | 24 | 32")
    channels:     int = Field(2,       ge=1, le=2, description="1=mono  2=stereo")

    @validator("codec")
    def _val_codec(cls, v):
        assert v in AUDIO_CODECS, f"codec must be one of {list(AUDIO_CODECS.keys())}"
        return v

    @validator("sample_rate")
    def _val_sr(cls, v):
        assert v in SAMPLE_RATES, f"sample_rate must be one of {list(SAMPLE_RATES.keys())}"
        return v

    @validator("bit_depth")
    def _val_bd(cls, v):
        assert v in BIT_DEPTHS, f"bit_depth must be one of {list(BIT_DEPTHS.keys())}"
        return v


class BatchRequest(GlobalOpts):
    urls:          List[str] = Field(..., min_items=1, description="List of media URLs")
    mode:          str       = Field("video", description="video | audio")
    workers:       int       = Field(1, ge=1, le=8,  description="Parallel download workers")
    delay:         float     = Field(3.0, ge=0,      description="Seconds between downloads")
    stop_on_error: bool      = Field(False)
    codec:         str       = Field("wav")
    sample_rate:   str       = Field("96000")


class PlaylistRequest(GlobalOpts):
    url:             str            = Field(..., description="Playlist URL")
    mode:            str            = Field("video", description="video | audio")
    playlist_start:  Optional[int]  = Field(None)
    playlist_end:    Optional[int]  = Field(None)
    playlist_items:  Optional[str]  = Field(None, description="e.g. '1,3,5-8'")
    archive:         Optional[str]  = Field(None, description="Archive file path")


class UpscaleRequest(BaseModel):
    file_path:   str = Field(..., description="Absolute or relative path to local video file")
    target:      str = Field("4k",      description="4k | 8k | 1440p | 1080p | 720p")
    method:      str = Field("lanczos", description="lanczos | bicubic | spline | neighbor")
    webhook_url: Optional[str] = Field(None)

    @validator("target")
    def _val_target(cls, v):
        assert v in RESOLUTION_MAP
        return v

    @validator("method")
    def _val_method(cls, v):
        assert v in UPSCALE_METHODS
        return v


class JobResponse(BaseModel):
    job_id:       str
    status:       str
    url:          Optional[str]
    title:        Optional[str]
    output_file:  Optional[str]
    progress_pct: float
    speed:        Optional[str]
    eta:          Optional[int]
    error:        Optional[str]
    started_at:   Optional[str]
    finished_at:  Optional[str]
    resolution:   Optional[str]
    codec:        Optional[str]
    duration:     Optional[int]
    filesize:     Optional[int]


class BatchJobResponse(BaseModel):
    batch_id:    str
    job_ids:     List[str]
    total:       int
    message:     str


class HealthResponse(BaseModel):
    status:      str
    version:     str
    jobs:        Dict[str, int]
    timestamp:   str


# ─── FastAPI App ───────────────────────────────────────────────────────────────

def create_app() -> FastAPI:
    """Create and configure FastAPI application."""
    
    app = FastAPI(
        title       = "Converso Media Downloader API",
        description = (
            "REST API for Converso Media Downloader — professional YouTube & media downloading.\n\n"
            "All download operations are asynchronous. Submit a request → receive a `job_id` "
            "→ poll `GET /api/v1/jobs/{job_id}` for progress & result.\n\n"
            "Optionally supply a `webhook_url` to receive a POST callback on completion."
        ),
        version     = __version__,
        docs_url    = "/docs",
        redoc_url   = "/redoc",
        openapi_url = "/openapi.json",
        contact     = {"name": "Converso Empire"},
        license_info= {"name": "Apache 2.0"},
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _result_to_response(r: DownloadResult) -> JobResponse:
        return JobResponse(**r.to_dict())

    def _cfg_from_global(req: GlobalOpts) -> DownloadConfig:
        return DownloadConfig(
            output_dir           = req.output_dir,
            proxy                = req.proxy,
            rate_limit           = req.rate_limit,
            concurrent_fragments = req.concurrent_fragments,
            retries              = req.retries,
            webhook_url          = req.webhook_url,
        )

    def _fire_webhook(webhook_url: Optional[str], result: DownloadResult) -> None:
        if not webhook_url or not HAS_REQUESTS:
            return
        try:
            _req_lib.post(webhook_url, json=result.to_dict(), timeout=10)
            logger.info("Webhook fired → %s  job=%s", webhook_url, result.job_id)
        except Exception as e:
            logger.warning("Webhook failed: %s", e)

    # ── Routes ────────────────────────────────────────────────────────────────

    @app.get("/", include_in_schema=False)
    async def root():
        return {"message": f"Converso Media Downloader API v{__version__}  •  /docs for Swagger"}

    @app.get(
        "/health",
        response_model=HealthResponse,
        summary="Health Check",
        tags=["System"],
    )
    async def health():
        return HealthResponse(
            status    = "ok",
            version   = __version__,
            jobs      = JOBS.count(),
            timestamp = datetime.utcnow().isoformat(),
        )

    # ── Video Info / Formats ───────────────────────────────────────────────────

    @app.get(
        "/api/v1/info",
        summary="Get Video Metadata",
        tags=["Media Info"],
    )
    async def get_info(url: str = Query(..., description="Media URL")):
        """Return metadata for a URL (title, duration, uploader, upload_date, etc.)."""
        try:
            dl   = get_downloader()
            info = dl.get_info(url)
            dur  = info.get("duration", 0)
            return {
                "title":        info.get("title"),
                "uploader":     info.get("uploader"),
                "duration_sec": dur,
                "duration_fmt": f"{dur // 60}:{dur % 60:02d}",
                "view_count":   info.get("view_count"),
                "upload_date":  info.get("upload_date"),
                "webpage_url":  info.get("webpage_url", url),
                "thumbnail":    info.get("thumbnail"),
                "description":  (info.get("description") or "")[:500],
            }
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    @app.get(
        "/api/v1/formats",
        summary="List Available Formats",
        tags=["Media Info"],
    )
    async def list_formats(url: str = Query(..., description="Media URL")):
        """Return all available format/quality combinations for a URL."""
        try:
            dl      = get_downloader()
            formats = dl.list_formats(url)
            result  = []
            for f in formats:
                size = f.get("filesize") or f.get("filesize_approx") or 0
                result.append({
                    "format_id":  f.get("format_id"),
                    "ext":        f.get("ext"),
                    "resolution": f.get("resolution", f"{f.get('width', '?')}x{f.get('height', '?')}"),
                    "fps":        f.get("fps"),
                    "vcodec":     f.get("vcodec"),
                    "acodec":     f.get("acodec"),
                    "filesize_mb":round(size / (1024 ** 2), 1) if size else None,
                    "note":       f.get("format_note", ""),
                })
            return {"url": url, "formats": result, "count": len(result)}
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))

    # ── Download Jobs ──────────────────────────────────────────────────────────

    @app.post(
        "/api/v1/jobs/video",
        status_code=status.HTTP_202_ACCEPTED,
        summary="Start Video Download Job",
        tags=["Jobs"],
    )
    async def start_video_download(req: VideoRequest):
        """Enqueue a best-quality video download."""
        cfg = _cfg_from_global(req)
        cfg.video_container  = req.container
        cfg.embed_thumbnail  = req.embed_thumbnail
        cfg.embed_metadata   = req.embed_metadata
        cfg.embed_chapters   = req.embed_chapters
        cfg.embed_subs       = req.embed_subs
        cfg.no_subs          = req.no_subs
        cfg.sub_langs        = req.sub_langs
        cfg.upscale_target   = req.upscale_target
        cfg.upscale_method   = req.upscale_method

        dl     = get_downloader(req.output_dir)
        result = DownloadResult(
            job_id=str(uuid.uuid4()),
            url=req.url,
            started_at=datetime.utcnow().isoformat()
        )
        JOBS.put(result)

        def _run():
            r = dl.download_video(req.url, cfg)
            result.__dict__.update(r.__dict__)
            JOBS.put(result)
            _fire_webhook(req.webhook_url, result)

        threading.Thread(target=_run, daemon=True).start()

        return {"job_id": result.job_id, "status": "pending",
                "message": f"Video download queued for {req.url}"}

    @app.post(
        "/api/v1/jobs/audio",
        status_code=status.HTTP_202_ACCEPTED,
        summary="Start Audio Download Job",
        tags=["Jobs"],
    )
    async def start_audio_download(req: AudioRequest):
        """Enqueue a professional audio download."""
        cfg = _cfg_from_global(req)
        cfg.audio_codec       = req.codec
        cfg.audio_sample_rate = SAMPLE_RATES[req.sample_rate]
        cfg.audio_bit_depth   = BIT_DEPTHS[req.bit_depth]
        cfg.audio_channels    = req.channels

        dl     = get_downloader(req.output_dir)
        result = DownloadResult(
            job_id=str(uuid.uuid4()),
            url=req.url,
            started_at=datetime.utcnow().isoformat()
        )
        JOBS.put(result)

        def _run():
            r = dl.download_audio(req.url, cfg)
            result.__dict__.update(r.__dict__)
            JOBS.put(result)
            _fire_webhook(req.webhook_url, result)

        threading.Thread(target=_run, daemon=True).start()

        return {"job_id": result.job_id, "status": "pending",
                "message": f"Audio download queued for {req.url}"}

    @app.post(
        "/api/v1/jobs/batch",
        status_code=status.HTTP_202_ACCEPTED,
        summary="Start Batch Download Job",
        tags=["Jobs"],
    )
    async def start_batch_download(req: BatchRequest):
        """Enqueue a batch of URLs (video or audio mode)."""
        cfg = _cfg_from_global(req)
        cfg.workers          = req.workers
        cfg.batch_delay      = req.delay
        cfg.stop_on_error    = req.stop_on_error
        cfg.audio_codec      = req.codec
        cfg.audio_sample_rate= SAMPLE_RATES.get(req.sample_rate, 96000)

        dl        = get_downloader(req.output_dir)
        batch_id  = str(uuid.uuid4())
        results   = [DownloadResult(
            job_id=str(uuid.uuid4()),
            url=u,
            started_at=datetime.utcnow().isoformat()
        ) for u in req.urls]
        for r in results:
            JOBS.put(r)

        def _run():
            real = dl.batch_download(req.urls, mode=req.mode, config=cfg)
            for placeholder, real_r in zip(results, real):
                placeholder.__dict__.update(real_r.__dict__)
                JOBS.put(placeholder)
            _fire_webhook(req.webhook_url, DownloadResult(
                job_id=batch_id,
                status="success" if all(r.status == "success" for r in results) else "failed",
                title=f"Batch of {len(results)} items",
            ))

        threading.Thread(target=_run, daemon=True).start()

        return BatchJobResponse(
            batch_id = batch_id,
            job_ids  = [r.job_id for r in results],
            total    = len(results),
            message  = f"Batch of {len(results)} {req.mode} downloads queued",
        )

    @app.post(
        "/api/v1/jobs/playlist",
        status_code=status.HTTP_202_ACCEPTED,
        summary="Start Playlist Download Job",
        tags=["Jobs"],
    )
    async def start_playlist_download(req: PlaylistRequest):
        """Enqueue an entire playlist download (video or audio mode)."""
        cfg = _cfg_from_global(req)
        cfg.playlist_archive = req.archive
        cfg.playlist_start   = req.playlist_start
        cfg.playlist_end     = req.playlist_end
        cfg.playlist_items   = req.playlist_items

        dl     = get_downloader(req.output_dir)
        result = DownloadResult(
            job_id=str(uuid.uuid4()),
            url=req.url,
            started_at=datetime.utcnow().isoformat()
        )
        JOBS.put(result)

        def _run():
            r = dl.download_playlist(req.url, mode=req.mode, config=cfg)
            result.__dict__.update(r.__dict__)
            JOBS.put(result)
            _fire_webhook(req.webhook_url, result)

        threading.Thread(target=_run, daemon=True).start()

        return {"job_id": result.job_id, "status": "pending",
                "message": f"Playlist download queued: {req.url}"}

    @app.post(
        "/api/v1/jobs/upscale",
        status_code=status.HTTP_202_ACCEPTED,
        summary="Start Upscale Job",
        tags=["Jobs"],
    )
    async def start_upscale(req: UpscaleRequest):
        """Enqueue a FFmpeg upscale of a local video file."""
        if not Path(req.file_path).exists():
            raise HTTPException(status_code=404, detail=f"File not found: {req.file_path}")

        dl     = get_downloader()
        result = DownloadResult(
            job_id=str(uuid.uuid4()),
            url=req.file_path,
            started_at=datetime.utcnow().isoformat()
        )
        JOBS.put(result)

        def _run():
            result.status = "running"
            JOBS.put(result)
            out = dl.upscale_video(req.file_path, req.target, req.method)
            result.status      = "success" if out else "failed"
            result.output_file = out
            result.finished_at = datetime.utcnow().isoformat()
            JOBS.put(result)
            _fire_webhook(req.webhook_url, result)

        threading.Thread(target=_run, daemon=True).start()

        return {"job_id": result.job_id, "status": "pending",
                "message": f"Upscale to {req.target} queued for {req.file_path}"}

    # ── Job Management ─────────────────────────────────────────────────────────

    @app.get(
        "/api/v1/jobs",
        summary="List All Jobs",
        tags=["Jobs"],
    )
    async def list_jobs(
        status_filter: Optional[str] = Query(None, alias="status",
                                             description="Filter by status: pending|running|success|failed")
    ):
        """List all jobs in the in-memory store."""
        jobs = JOBS.all()
        if status_filter:
            jobs = [j for j in jobs if j.status == status_filter]
        return {
            "count": len(jobs),
            "jobs":  [_result_to_response(j).dict() for j in jobs],
        }

    @app.get(
        "/api/v1/jobs/{job_id}",
        response_model=JobResponse,
        summary="Get Job Status & Result",
        tags=["Jobs"],
    )
    async def get_job(job_id: str):
        """Retrieve full status, progress, and result for a job."""
        r = JOBS.get(job_id)
        if not r:
            raise HTTPException(status_code=404, detail=f"Job not found: {job_id}")
        return _result_to_response(r)

    @app.delete(
        "/api/v1/jobs/{job_id}",
        status_code=status.HTTP_200_OK,
        summary="Delete / Cancel Job Record",
        tags=["Jobs"],
    )
    async def delete_job(job_id: str):
        """Remove a job from the store."""
        if not JOBS.delete(job_id):
            raise HTTPException(status_code=404, detail=f"Job not found: {job_id}")
        return {"deleted": True, "job_id": job_id}

    @app.delete(
        "/api/v1/jobs",
        status_code=status.HTTP_200_OK,
        summary="Purge Completed Jobs",
        tags=["Jobs"],
    )
    async def purge_jobs(
        statuses: str = Query("success,failed",
                              description="Comma-separated statuses to purge")
    ):
        """Remove finished jobs from the store to free memory."""
        target = set(s.strip() for s in statuses.split(","))
        to_delete = [j.job_id for j in JOBS.all() if j.status in target]
        for jid in to_delete:
            JOBS.delete(jid)
        return {"purged": len(to_delete), "statuses": list(target)}

    # ── File Serving ───────────────────────────────────────────────────────────

    @app.get(
        "/api/v1/jobs/{job_id}/download",
        summary="Download Completed File",
        tags=["Jobs"],
    )
    async def download_result_file(job_id: str):
        """Stream the completed output file for a successful job."""
        r = JOBS.get(job_id)
        if not r:
            raise HTTPException(status_code=404, detail="Job not found")
        if r.status != "success":
            raise HTTPException(status_code=409, detail=f"Job status is '{r.status}', not 'success'")
        if not r.output_file or not Path(r.output_file).exists():
            raise HTTPException(status_code=404, detail="Output file not found on disk")
        return FileResponse(r.output_file, filename=Path(r.output_file).name)

    return app


def main() -> None:
    """Server entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        prog="converso-ytdl-api",
        description="Converso Media Downloader — REST API Server",
    )
    parser.add_argument("--host",    default="0.0.0.0",         help="Bind host (default: 0.0.0.0)")
    parser.add_argument("--port",    type=int, default=8000,     help="Bind port (default: 8000)")
    parser.add_argument("--reload",  action="store_true",        help="Enable auto-reload (dev only)")
    parser.add_argument("--workers", type=int, default=1,        help="Uvicorn worker processes (default: 1)")
    parser.add_argument("--log-level", default="info",
                        choices=["debug", "info", "warning", "error"],
                        help="Uvicorn log level (default: info)")
    args = parser.parse_args()

    print(f"""
  ╔══════════════════════════════════════════════════════╗
  ║   Converso Media Downloader API  v{__version__:<15}  ║
  ║   Swagger UI  →  http://{args.host}:{args.port}/docs         ║
  ║   ReDoc       →  http://{args.host}:{args.port}/redoc        ║
  ║   OpenAPI     →  http://{args.host}:{args.port}/openapi.json ║
  ╚══════════════════════════════════════════════════════╝
""")

    app = create_app()
    uvicorn.run(
        app,
        host      = args.host,
        port      = args.port,
        reload    = args.reload,
        workers   = args.workers,
        log_level = args.log_level,
    )


if __name__ == "__main__":
    main()
