"""
FastAPI REST server for Converso Media Downloader.
"""

from .server import create_app, main

__all__ = ["create_app", "main"]
