# Code of Conduct

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our community a harassment-free experience for everyone, regardless of age, body size, visible or invisible disability, ethnicity, sex characteristics, gender identity and expression, level of experience, education, socio-economic status, nationality, personal appearance, race, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

---

## Our Standards

Examples of behavior that contributes to a positive environment for our community include:

✅ **DO**
- Demonstrating empathy and kindness toward other people
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive criticism
- Accepting responsibility and apologizing to those affected by our mistakes
- Focusing on what is best not just for us as individuals, but for the overall community
- Using inclusive and welcoming language
- Assuming good intent from contributors
- Asking questions rather than making accusations
- Celebrating others' contributions and successes
- Helping newer community members

❌ **DON'T**
- The use of sexualized language or imagery, and sexual attention or advances of any kind
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information, such as a physical or email address, without their explicit permission
- Other conduct which could reasonably be considered inappropriate in a professional setting
- Dismissing or minimizing the concerns of contributors
- Gatekeeping or excluding people from community spaces
- Making assumptions about someone's identity or experience
- Unwelcome conduct of a sexual nature
- Deliberate intimidation or threatening behavior

---

## Enforcement Responsibilities

Community leaders are responsible for clarifying and enforcing our standards of acceptable behavior and will take appropriate and fair corrective action in response to any behavior that they deem inappropriate, threatening, offensive, or harmful.

Community leaders have the right and responsibility to remove, edit, or reject comments, commits, code, wiki edits, issues, and other contributions that are not aligned to this Code of Conduct, and will communicate reasons for moderation decisions when appropriate.

---

## Scope

This Code of Conduct applies within all community spaces, and also applies when an individual is officially representing the community in public spaces. Examples of representing our community include using an official e-mail address, posting via an official social media account, or acting as an appointed representative at an online or offline event.

---

## Enforcement

### Reporting Violations

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the community leaders responsible for enforcement at **[conduct@converso.io](mailto:conduct@converso.io)**.

All complaints will be reviewed and investigated promptly and fairly.

When reporting, please include:
- Description of the behavior
- Where it occurred
- Who was involved
- When it happened
- Any additional context

**All reports will be kept confidential.**

### Investigation Process

1. **Initial Response** (24 hours)
   - Acknowledge receipt of report
   - Confidentiality confirmed
   - Initial assessment begins

2. **Investigation** (3-5 business days)
   - Gather information from all parties
   - Review relevant communication
   - Document findings

3. **Decision** (5-7 business days)
   - Determine if violation occurred
   - Decide appropriate action
   - Notify all parties

4. **Appeal** (14 days)
   - Parties may appeal decision
   - Separate reviewer handles appeal
   - Final decision is made

---

## Enforcement Guidelines

Community leaders will follow these Community Impact Guidelines in determining the consequences for any action they deem in violation of this Code of Conduct:

### 1. Correction

**Community Impact**: Use of inappropriate language or other behavior deemed unprofessional or unwelcome in the community.

**Consequence**: A private, written warning from community leaders, providing clarity around the nature of the violation and an explanation of why the behavior was inappropriate. A public apology may be requested.

### 2. Warning

**Community Impact**: A violation through a single incident or series of actions.

**Consequence**: A warning with consequences for continued behavior. No interaction with the people involved, including unsolicited interaction with those enforcing the Code of Conduct, for a specified period of time. This includes avoiding interactions in community spaces as well as external channels like social media. Violating these terms may lead to a temporary or permanent ban.

### 3. Temporary Ban

**Community Impact**: A serious violation of community standards, including sustained inappropriate behavior.

**Consequence**: A temporary ban from any sort of interaction or public communication with the community for a specified period of time. No public or private interaction with the people involved, including unsolicited interaction with those enforcing the Code of Conduct, is allowed during this period. Violating these terms may lead to a permanent ban.

### 4. Permanent Ban

**Community Impact**: Demonstrating a pattern of violation of community standards, including sustained inappropriate behavior, harassment of an individual, or aggression toward or disparagement of classes of individuals.

**Consequence**: A permanent ban from any sort of public interaction within the project community.

---

## Appeal Process

If you believe a decision was made in error, you may appeal:

1. **Submit appeal** to **[conduct@converso.io](mailto:conduct@converso.io)** within 14 days
2. **Include**:
   - Original decision you're appealing
   - Reason you believe it was in error
   - Any new information
3. **Separate reviewer** will evaluate
4. **Final decision** is binding

---

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org), version 2.0, available at https://www.contributor-covenant.org/version/2_0/code_of_conduct.html.

Community Impact Guidelines were inspired by [Mozilla's code of conduct enforcement ladder](https://github.com/mozilla/diversity).

---

## Questions?

If you have questions about this Code of Conduct, please email **[conduct@converso.io](mailto:conduct@converso.io)**.

---

**Effective Date**: March 30, 2026  
**Version**: 1.0.0
