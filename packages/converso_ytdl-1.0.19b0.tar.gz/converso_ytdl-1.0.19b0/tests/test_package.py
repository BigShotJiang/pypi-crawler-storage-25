"""
Basic tests for Converso Media Downloader package structure.
"""

import pytest
from converso_ytdl import (
    MediaDownloader,
    DownloadConfig,
    DownloadResult,
    AUDIO_CODECS,
    RESOLUTION_MAP,
)


def test_imports():
    """Test that all main imports work correctly."""
    assert MediaDownloader is not None
    assert DownloadConfig is not None
    assert DownloadResult is not None
    assert len(AUDIO_CODECS) > 0
    assert len(RESOLUTION_MAP) > 0


def test_config_creation():
    """Test DownloadConfig instantiation."""
    config = DownloadConfig()
    assert config.output_dir == "downloads"
    assert config.audio_sample_rate == 96000
    assert config.video_container == "mkv"


def test_config_custom():
    """Test DownloadConfig with custom values."""
    config = DownloadConfig(
        output_dir="my_downloads",
        audio_codec="flac",
        audio_sample_rate=192000,
    )
    assert config.output_dir == "my_downloads"
    assert config.audio_codec == "flac"
    assert config.audio_sample_rate == 192000


def test_result_creation():
    """Test DownloadResult instantiation."""
    result = DownloadResult(
        job_id="test-123",
        url="https://youtu.be/test",
        status="success",
    )
    assert result.job_id == "test-123"
    assert result.status == "success"
    assert result.progress_pct == 0.0


def test_result_to_dict():
    """Test DownloadResult serialization."""
    result = DownloadResult(
        job_id="test-456",
        url="https://example.com/video",
        status="running",
        progress_pct=50.0,
    )
    data = result.to_dict()
    assert isinstance(data, dict)
    assert data["job_id"] == "test-456"
    assert data["progress_pct"] == 50.0


def test_downloader_creation():
    """Test MediaDownloader instantiation."""
    config = DownloadConfig()
    downloader = MediaDownloader(config)
    assert downloader.config == config
    assert downloader.logger is not None


def test_resolution_map():
    """Test that resolution mappings are available."""
    assert RESOLUTION_MAP["4k"] == "3840:2160"
    assert RESOLUTION_MAP["1080p"] == "1920:1080"
    assert RESOLUTION_MAP["720p"] == "1280:720"


def test_audio_codecs():
    """Test that audio codecs are available."""
    assert "wav" in AUDIO_CODECS
    assert "flac" in AUDIO_CODECS
    assert "mp3" in AUDIO_CODECS
    assert "aac" in AUDIO_CODECS
    assert "opus" in AUDIO_CODECS


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
