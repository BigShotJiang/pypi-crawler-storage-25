# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'GP_regressorui.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QDoubleSpinBox, QFrame,
    QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QSpinBox, QTextEdit, QVBoxLayout, QWidget)

class Ui_Form(object):
    def setupUi(self, Form):
        if not Form.objectName():
            Form.setObjectName(u"Form")
        Form.resize(999, 759)
        self.verticalLayout_2 = QVBoxLayout(Form)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.frame_29 = QFrame(Form)
        self.frame_29.setObjectName(u"frame_29")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_29.sizePolicy().hasHeightForWidth())
        self.frame_29.setSizePolicy(sizePolicy)
        self.frame_29.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_29.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout = QHBoxLayout(self.frame_29)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.frame_30 = QFrame(self.frame_29)
        self.frame_30.setObjectName(u"frame_30")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame_30.sizePolicy().hasHeightForWidth())
        self.frame_30.setSizePolicy(sizePolicy1)
        self.frame_30.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_30.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.frame_30)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.frame_40 = QFrame(self.frame_30)
        self.frame_40.setObjectName(u"frame_40")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.frame_40.sizePolicy().hasHeightForWidth())
        self.frame_40.setSizePolicy(sizePolicy2)
        self.frame_40.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_40.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_27 = QHBoxLayout(self.frame_40)
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.widget_10 = QWidget(self.frame_40)
        self.widget_10.setObjectName(u"widget_10")
        sizePolicy1.setHeightForWidth(self.widget_10.sizePolicy().hasHeightForWidth())
        self.widget_10.setSizePolicy(sizePolicy1)
        self.horizontalLayout_28 = QHBoxLayout(self.widget_10)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.pushButton_7 = QPushButton(self.widget_10)
        self.pushButton_7.setObjectName(u"pushButton_7")
        self.pushButton_7.setMinimumSize(QSize(46, 46))
        self.pushButton_7.setMaximumSize(QSize(60, 16777215))
        icon = QIcon()
        icon.addFile(u"../../../ui/icons/folder.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_7.setIcon(icon)
        self.pushButton_7.setIconSize(QSize(30, 30))

        self.horizontalLayout_28.addWidget(self.pushButton_7)

        self.label_27 = QLabel(self.widget_10)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setMinimumSize(QSize(2, 33))
        self.label_27.setMaximumSize(QSize(16777215, 33))
        self.label_27.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_28.addWidget(self.label_27)


        self.horizontalLayout_27.addWidget(self.widget_10)

        self.label_22 = QLabel(self.frame_40)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setMinimumSize(QSize(100, 0))
        self.label_22.setMaximumSize(QSize(100, 16777215))
        font = QFont()
        font.setFamilies([u"Oswald"])
        font.setPointSize(15)
        self.label_22.setFont(font)
        self.label_22.setTextFormat(Qt.TextFormat.PlainText)
        self.label_22.setScaledContents(False)

        self.horizontalLayout_27.addWidget(self.label_22)


        self.verticalLayout_3.addWidget(self.frame_40)

        self.frame_31 = QFrame(self.frame_30)
        self.frame_31.setObjectName(u"frame_31")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(1)
        sizePolicy3.setHeightForWidth(self.frame_31.sizePolicy().hasHeightForWidth())
        self.frame_31.setSizePolicy(sizePolicy3)
        self.frame_31.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_31.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_31.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.frame_31)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.frame_6 = QFrame(self.frame_31)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setStyleSheet(u"background-color: rgb(223, 223, 223);")
        self.frame_6.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_6)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.label_28 = QLabel(self.frame_6)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setMinimumSize(QSize(300, 0))
        self.label_28.setMaximumSize(QSize(100, 16777215))
        self.label_28.setFont(font)
        self.label_28.setTextFormat(Qt.TextFormat.PlainText)
        self.label_28.setScaledContents(False)

        self.horizontalLayout_2.addWidget(self.label_28)

        self.frame_39 = QFrame(self.frame_6)
        self.frame_39.setObjectName(u"frame_39")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.frame_39.sizePolicy().hasHeightForWidth())
        self.frame_39.setSizePolicy(sizePolicy4)
        self.frame_39.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_39.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_26 = QHBoxLayout(self.frame_39)
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_26 = QLabel(self.frame_39)
        self.label_26.setObjectName(u"label_26")
        font1 = QFont()
        font1.setFamilies([u"Oswald"])
        font1.setPointSize(10)
        self.label_26.setFont(font1)

        self.horizontalLayout_26.addWidget(self.label_26)

        self.pushButton_6 = QPushButton(self.frame_39)
        self.pushButton_6.setObjectName(u"pushButton_6")
        self.pushButton_6.setMinimumSize(QSize(30, 30))
        self.pushButton_6.setMaximumSize(QSize(40, 40))
        icon1 = QIcon()
        icon1.addFile(u"../../../ui/icons/run.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_6.setIcon(icon1)
        self.pushButton_6.setIconSize(QSize(30, 30))

        self.horizontalLayout_26.addWidget(self.pushButton_6)


        self.horizontalLayout_2.addWidget(self.frame_39)


        self.verticalLayout_4.addWidget(self.frame_6)

        self.frame_32 = QFrame(self.frame_31)
        self.frame_32.setObjectName(u"frame_32")
        sizePolicy3.setHeightForWidth(self.frame_32.sizePolicy().hasHeightForWidth())
        self.frame_32.setSizePolicy(sizePolicy3)
        self.frame_32.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_32.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout = QVBoxLayout(self.frame_32)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.label_21 = QLabel(self.frame_32)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setMinimumSize(QSize(100, 0))
        self.label_21.setMaximumSize(QSize(16777215, 16777215))
        self.label_21.setFont(font)
        self.label_21.setTextFormat(Qt.TextFormat.PlainText)
        self.label_21.setScaledContents(False)

        self.verticalLayout.addWidget(self.label_21)

        self.widget_7 = QWidget(self.frame_32)
        self.widget_7.setObjectName(u"widget_7")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy5.setHorizontalStretch(1)
        sizePolicy5.setVerticalStretch(1)
        sizePolicy5.setHeightForWidth(self.widget_7.sizePolicy().hasHeightForWidth())
        self.widget_7.setSizePolicy(sizePolicy5)
        self.horizontalLayout_21 = QHBoxLayout(self.widget_7)
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.pushButton_5 = QPushButton(self.widget_7)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setMinimumSize(QSize(46, 46))
        self.pushButton_5.setMaximumSize(QSize(60, 16777215))
        self.pushButton_5.setIcon(icon)
        self.pushButton_5.setIconSize(QSize(30, 30))

        self.horizontalLayout_21.addWidget(self.pushButton_5)

        self.label_23 = QLabel(self.widget_7)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setMinimumSize(QSize(2, 33))
        self.label_23.setMaximumSize(QSize(16777215, 33))
        self.label_23.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_21.addWidget(self.label_23)


        self.verticalLayout.addWidget(self.widget_7)


        self.verticalLayout_4.addWidget(self.frame_32)


        self.verticalLayout_3.addWidget(self.frame_31)

        self.frame_41 = QFrame(self.frame_30)
        self.frame_41.setObjectName(u"frame_41")
        sizePolicy3.setHeightForWidth(self.frame_41.sizePolicy().hasHeightForWidth())
        self.frame_41.setSizePolicy(sizePolicy3)
        self.frame_41.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_41.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_41.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.frame_41)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.frame_7 = QFrame(self.frame_41)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setStyleSheet(u"background-color: rgb(223, 223, 223);")
        self.frame_7.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_7.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_7)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.label_29 = QLabel(self.frame_7)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setMinimumSize(QSize(300, 0))
        self.label_29.setMaximumSize(QSize(100, 16777215))
        self.label_29.setFont(font)
        self.label_29.setTextFormat(Qt.TextFormat.PlainText)
        self.label_29.setScaledContents(False)

        self.horizontalLayout_3.addWidget(self.label_29)

        self.frame_42 = QFrame(self.frame_7)
        self.frame_42.setObjectName(u"frame_42")
        sizePolicy4.setHeightForWidth(self.frame_42.sizePolicy().hasHeightForWidth())
        self.frame_42.setSizePolicy(sizePolicy4)
        self.frame_42.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_42.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_30 = QHBoxLayout(self.frame_42)
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.label_30 = QLabel(self.frame_42)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setFont(font1)

        self.horizontalLayout_30.addWidget(self.label_30)

        self.pushButton_8 = QPushButton(self.frame_42)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setMinimumSize(QSize(30, 30))
        self.pushButton_8.setMaximumSize(QSize(40, 40))
        self.pushButton_8.setIcon(icon1)
        self.pushButton_8.setIconSize(QSize(30, 30))

        self.horizontalLayout_30.addWidget(self.pushButton_8)


        self.horizontalLayout_3.addWidget(self.frame_42)


        self.verticalLayout_6.addWidget(self.frame_7)

        self.frame_43 = QFrame(self.frame_41)
        self.frame_43.setObjectName(u"frame_43")
        sizePolicy3.setHeightForWidth(self.frame_43.sizePolicy().hasHeightForWidth())
        self.frame_43.setSizePolicy(sizePolicy3)
        self.frame_43.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_43.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.frame_43)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_32 = QLabel(self.frame_43)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setMinimumSize(QSize(100, 0))
        self.label_32.setMaximumSize(QSize(90000, 16777215))
        self.label_32.setFont(font)
        self.label_32.setTextFormat(Qt.TextFormat.PlainText)
        self.label_32.setScaledContents(False)

        self.verticalLayout_5.addWidget(self.label_32)

        self.widget_11 = QWidget(self.frame_43)
        self.widget_11.setObjectName(u"widget_11")
        sizePolicy5.setHeightForWidth(self.widget_11.sizePolicy().hasHeightForWidth())
        self.widget_11.setSizePolicy(sizePolicy5)
        self.horizontalLayout_34 = QHBoxLayout(self.widget_11)
        self.horizontalLayout_34.setObjectName(u"horizontalLayout_34")
        self.pushButton_9 = QPushButton(self.widget_11)
        self.pushButton_9.setObjectName(u"pushButton_9")
        self.pushButton_9.setMinimumSize(QSize(46, 46))
        self.pushButton_9.setMaximumSize(QSize(60, 16777215))
        self.pushButton_9.setIcon(icon)
        self.pushButton_9.setIconSize(QSize(30, 30))

        self.horizontalLayout_34.addWidget(self.pushButton_9)

        self.label_31 = QLabel(self.widget_11)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setMinimumSize(QSize(2, 33))
        self.label_31.setMaximumSize(QSize(16777215, 33))
        self.label_31.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_34.addWidget(self.label_31)


        self.verticalLayout_5.addWidget(self.widget_11)


        self.verticalLayout_6.addWidget(self.frame_43)


        self.verticalLayout_3.addWidget(self.frame_41)


        self.horizontalLayout.addWidget(self.frame_30)

        self.frame = QFrame(self.frame_29)
        self.frame.setObjectName(u"frame")
        sizePolicy1.setHeightForWidth(self.frame.sizePolicy().hasHeightForWidth())
        self.frame.setSizePolicy(sizePolicy1)
        self.frame.setMinimumSize(QSize(0, 0))
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_11 = QVBoxLayout(self.frame)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.frame_38 = QFrame(self.frame)
        self.frame_38.setObjectName(u"frame_38")
        sizePolicy1.setHeightForWidth(self.frame_38.sizePolicy().hasHeightForWidth())
        self.frame_38.setSizePolicy(sizePolicy1)
        self.frame_38.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_38.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_26 = QVBoxLayout(self.frame_38)
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.widget_9 = QWidget(self.frame_38)
        self.widget_9.setObjectName(u"widget_9")
        sizePolicy6 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy6.setHorizontalStretch(0)
        sizePolicy6.setVerticalStretch(0)
        sizePolicy6.setHeightForWidth(self.widget_9.sizePolicy().hasHeightForWidth())
        self.widget_9.setSizePolicy(sizePolicy6)
        self.widget_9.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_25 = QHBoxLayout(self.widget_9)
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.label_25 = QLabel(self.widget_9)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setFont(font1)

        self.horizontalLayout_25.addWidget(self.label_25)


        self.verticalLayout_26.addWidget(self.widget_9)

        self.textEdit_3 = QTextEdit(self.frame_38)
        self.textEdit_3.setObjectName(u"textEdit_3")
        sizePolicy7 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy7.setHorizontalStretch(0)
        sizePolicy7.setVerticalStretch(2)
        sizePolicy7.setHeightForWidth(self.textEdit_3.sizePolicy().hasHeightForWidth())
        self.textEdit_3.setSizePolicy(sizePolicy7)
        self.textEdit_3.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_3.setReadOnly(True)

        self.verticalLayout_26.addWidget(self.textEdit_3)


        self.verticalLayout_11.addWidget(self.frame_38)

        self.frame_33 = QFrame(self.frame)
        self.frame_33.setObjectName(u"frame_33")
        sizePolicy2.setHeightForWidth(self.frame_33.sizePolicy().hasHeightForWidth())
        self.frame_33.setSizePolicy(sizePolicy2)
        self.frame_33.setMinimumSize(QSize(0, 0))
        self.frame_33.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_33.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_36 = QHBoxLayout(self.frame_33)
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.frame_44 = QFrame(self.frame_33)
        self.frame_44.setObjectName(u"frame_44")
        self.frame_44.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_44.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_44.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_24 = QVBoxLayout(self.frame_44)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.frame_47 = QFrame(self.frame_44)
        self.frame_47.setObjectName(u"frame_47")
        sizePolicy4.setHeightForWidth(self.frame_47.sizePolicy().hasHeightForWidth())
        self.frame_47.setSizePolicy(sizePolicy4)
        self.frame_47.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_47.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_33 = QVBoxLayout(self.frame_47)
        self.verticalLayout_33.setObjectName(u"verticalLayout_33")
        self.frame_51 = QFrame(self.frame_47)
        self.frame_51.setObjectName(u"frame_51")
        self.frame_51.setStyleSheet(u"")
        self.frame_51.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_51.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_37 = QHBoxLayout(self.frame_51)
        self.horizontalLayout_37.setObjectName(u"horizontalLayout_37")
        self.gaussian_checkbox_2 = QCheckBox(self.frame_51)
        self.gaussian_checkbox_2.setObjectName(u"gaussian_checkbox_2")
        self.gaussian_checkbox_2.setEnabled(True)
        font2 = QFont()
        font2.setFamilies([u"Oswald"])
        font2.setPointSize(9)
        self.gaussian_checkbox_2.setFont(font2)
        self.gaussian_checkbox_2.setAutoFillBackground(False)
        self.gaussian_checkbox_2.setIconSize(QSize(30, 30))
        self.gaussian_checkbox_2.setCheckable(True)
        self.gaussian_checkbox_2.setChecked(True)
        self.gaussian_checkbox_2.setTristate(False)

        self.horizontalLayout_37.addWidget(self.gaussian_checkbox_2)


        self.verticalLayout_33.addWidget(self.frame_51)

        self.frame_52 = QFrame(self.frame_47)
        self.frame_52.setObjectName(u"frame_52")
        self.frame_52.setStyleSheet(u"")
        self.frame_52.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_52.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_38 = QHBoxLayout(self.frame_52)
        self.horizontalLayout_38.setObjectName(u"horizontalLayout_38")
        self.laplacian_checkbox_2 = QCheckBox(self.frame_52)
        self.laplacian_checkbox_2.setObjectName(u"laplacian_checkbox_2")
        self.laplacian_checkbox_2.setEnabled(True)
        self.laplacian_checkbox_2.setFont(font2)
        self.laplacian_checkbox_2.setAutoFillBackground(False)
        self.laplacian_checkbox_2.setIconSize(QSize(30, 30))
        self.laplacian_checkbox_2.setCheckable(True)
        self.laplacian_checkbox_2.setTristate(False)

        self.horizontalLayout_38.addWidget(self.laplacian_checkbox_2)


        self.verticalLayout_33.addWidget(self.frame_52)

        self.frame_53 = QFrame(self.frame_47)
        self.frame_53.setObjectName(u"frame_53")
        self.frame_53.setStyleSheet(u"")
        self.frame_53.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_53.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_39 = QHBoxLayout(self.frame_53)
        self.horizontalLayout_39.setObjectName(u"horizontalLayout_39")
        self.mattern52_checkbox_2 = QCheckBox(self.frame_53)
        self.mattern52_checkbox_2.setObjectName(u"mattern52_checkbox_2")
        self.mattern52_checkbox_2.setEnabled(True)
        self.mattern52_checkbox_2.setFont(font2)
        self.mattern52_checkbox_2.setAutoFillBackground(False)
        self.mattern52_checkbox_2.setIconSize(QSize(30, 30))
        self.mattern52_checkbox_2.setCheckable(True)
        self.mattern52_checkbox_2.setTristate(False)

        self.horizontalLayout_39.addWidget(self.mattern52_checkbox_2)


        self.verticalLayout_33.addWidget(self.frame_53)


        self.verticalLayout_24.addWidget(self.frame_47)

        self.label_34 = QLabel(self.frame_44)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setMaximumSize(QSize(16777215, 100))
        self.label_34.setFont(font1)

        self.verticalLayout_24.addWidget(self.label_34, 0, Qt.AlignmentFlag.AlignHCenter)


        self.horizontalLayout_36.addWidget(self.frame_44)

        self.frame_45 = QFrame(self.frame_33)
        self.frame_45.setObjectName(u"frame_45")
        sizePolicy1.setHeightForWidth(self.frame_45.sizePolicy().hasHeightForWidth())
        self.frame_45.setSizePolicy(sizePolicy1)
        self.frame_45.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_45.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_27 = QVBoxLayout(self.frame_45)
        self.verticalLayout_27.setObjectName(u"verticalLayout_27")
        self.widget_13 = QWidget(self.frame_45)
        self.widget_13.setObjectName(u"widget_13")
        sizePolicy3.setHeightForWidth(self.widget_13.sizePolicy().hasHeightForWidth())
        self.widget_13.setSizePolicy(sizePolicy3)
        self.widget_13.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_8 = QVBoxLayout(self.widget_13)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.checkBox_8 = QCheckBox(self.widget_13)
        self.checkBox_8.setObjectName(u"checkBox_8")
        font3 = QFont()
        font3.setFamilies([u"Oswald"])
        self.checkBox_8.setFont(font3)

        self.verticalLayout_8.addWidget(self.checkBox_8)

        self.checkBox_9 = QCheckBox(self.widget_13)
        self.checkBox_9.setObjectName(u"checkBox_9")
        self.checkBox_9.setFont(font3)

        self.verticalLayout_8.addWidget(self.checkBox_9)

        self.frame_4 = QFrame(self.widget_13)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.frame_4)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.label_3 = QLabel(self.frame_4)
        self.label_3.setObjectName(u"label_3")

        self.verticalLayout_9.addWidget(self.label_3)

        self.spinBox_2 = QSpinBox(self.frame_4)
        self.spinBox_2.setObjectName(u"spinBox_2")
        self.spinBox_2.setMaximum(999)

        self.verticalLayout_9.addWidget(self.spinBox_2)


        self.verticalLayout_8.addWidget(self.frame_4)

        self.frame_5 = QFrame(self.widget_13)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_5.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_10 = QVBoxLayout(self.frame_5)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.label_4 = QLabel(self.frame_5)
        self.label_4.setObjectName(u"label_4")

        self.verticalLayout_10.addWidget(self.label_4)

        self.doubleSpinBox_2 = QDoubleSpinBox(self.frame_5)
        self.doubleSpinBox_2.setObjectName(u"doubleSpinBox_2")
        self.doubleSpinBox_2.setMinimum(0.010000000000000)
        self.doubleSpinBox_2.setMaximum(1.000000000000000)
        self.doubleSpinBox_2.setSingleStep(0.050000000000000)
        self.doubleSpinBox_2.setValue(0.700000000000000)

        self.verticalLayout_10.addWidget(self.doubleSpinBox_2)


        self.verticalLayout_8.addWidget(self.frame_5)


        self.verticalLayout_27.addWidget(self.widget_13)

        self.frame_54 = QFrame(self.frame_45)
        self.frame_54.setObjectName(u"frame_54")
        self.frame_54.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_54.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_54.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_40 = QHBoxLayout(self.frame_54)
        self.horizontalLayout_40.setObjectName(u"horizontalLayout_40")
        self.model_installed_4 = QCheckBox(self.frame_54)
        self.model_installed_4.setObjectName(u"model_installed_4")
        self.model_installed_4.setEnabled(False)
        self.model_installed_4.setFont(font2)
        self.model_installed_4.setAutoFillBackground(False)
        self.model_installed_4.setIconSize(QSize(30, 30))
        self.model_installed_4.setCheckable(False)
        self.model_installed_4.setTristate(False)

        self.horizontalLayout_40.addWidget(self.model_installed_4)


        self.verticalLayout_27.addWidget(self.frame_54)

        self.frame_55 = QFrame(self.frame_45)
        self.frame_55.setObjectName(u"frame_55")
        self.frame_55.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_55.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_55.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_41 = QHBoxLayout(self.frame_55)
        self.horizontalLayout_41.setObjectName(u"horizontalLayout_41")
        self.checkpoints_downloaded_4 = QCheckBox(self.frame_55)
        self.checkpoints_downloaded_4.setObjectName(u"checkpoints_downloaded_4")
        self.checkpoints_downloaded_4.setEnabled(False)
        self.checkpoints_downloaded_4.setFont(font2)
        self.checkpoints_downloaded_4.setAutoFillBackground(False)
        self.checkpoints_downloaded_4.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_4.setCheckable(False)
        self.checkpoints_downloaded_4.setTristate(False)

        self.horizontalLayout_41.addWidget(self.checkpoints_downloaded_4)


        self.verticalLayout_27.addWidget(self.frame_55)


        self.horizontalLayout_36.addWidget(self.frame_45)


        self.verticalLayout_11.addWidget(self.frame_33)


        self.horizontalLayout.addWidget(self.frame)


        self.verticalLayout_2.addWidget(self.frame_29)


        self.retranslateUi(Form)

        QMetaObject.connectSlotsByName(Form)
    # setupUi

    def retranslateUi(self, Form):
        Form.setWindowTitle(QCoreApplication.translate("Form", u"Form", None))
        self.pushButton_7.setText("")
        self.label_27.setText("")
        self.label_22.setText(QCoreApplication.translate("Form", u"*Targets file", None))
        self.label_28.setText(QCoreApplication.translate("Form", u"Embeddings (Single file)", None))
        self.label_26.setText(QCoreApplication.translate("Form", u"RUN", None))
        self.pushButton_6.setText("")
        self.label_21.setText(QCoreApplication.translate("Form", u"Model Embeddings", None))
        self.pushButton_5.setText("")
        self.label_23.setText("")
        self.label_29.setText(QCoreApplication.translate("Form", u"Embeddings (Batch)", None))
        self.label_30.setText(QCoreApplication.translate("Form", u"RUN", None))
        self.pushButton_8.setText("")
        self.label_32.setText(QCoreApplication.translate("Form", u"Root", None))
        self.pushButton_9.setText("")
        self.label_31.setText("")
        self.label_25.setText(QCoreApplication.translate("Form", u"Status Console", None))
        self.textEdit_3.setHtml(QCoreApplication.translate("Form", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.gaussian_checkbox_2.setText(QCoreApplication.translate("Form", u"Gaussian", None))
        self.laplacian_checkbox_2.setText(QCoreApplication.translate("Form", u"Laplacian", None))
        self.mattern52_checkbox_2.setText(QCoreApplication.translate("Form", u"Matern52", None))
        self.label_34.setText(QCoreApplication.translate("Form", u"Kernel Type", None))
        self.checkBox_8.setText(QCoreApplication.translate("Form", u"Compute RMSE", None))
        self.checkBox_9.setText(QCoreApplication.translate("Form", u"Split data", None))
        self.label_3.setText(QCoreApplication.translate("Form", u"Number of splits", None))
        self.label_4.setText(QCoreApplication.translate("Form", u"Training ratio", None))
        self.model_installed_4.setText(QCoreApplication.translate("Form", u"Model installed", None))
        self.checkpoints_downloaded_4.setText(QCoreApplication.translate("Form", u"Checkpoints Downloaded", None))
    # retranslateUi

