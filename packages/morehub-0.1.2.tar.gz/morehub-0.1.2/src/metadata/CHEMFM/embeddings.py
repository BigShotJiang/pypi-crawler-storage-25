#!/usr/bin/env python
"""Generate ChemFM embeddings under MoreHub CLI-v2 protocol."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
from typing import Any, Dict, List, Tuple

# Keep Hugging Face caches in this workspace instead of user-level home cache.
_SCRIPT_DIR = Path(__file__).resolve().parent
_WORKSPACE_CACHE_DIR = _SCRIPT_DIR / ".cache" / "huggingface"
_WORKSPACE_CACHE_DIR.mkdir(parents=True, exist_ok=True)
os.environ.setdefault("HF_HOME", str(_WORKSPACE_CACHE_DIR))
os.environ.setdefault("HF_HUB_CACHE", str(_WORKSPACE_CACHE_DIR / "hub"))
os.environ.setdefault("HUGGINGFACE_HUB_CACHE", str(_WORKSPACE_CACHE_DIR / "hub"))
os.environ.setdefault("TRANSFORMERS_CACHE", str(_WORKSPACE_CACHE_DIR / "transformers"))

import numpy as np
import torch
from tqdm import tqdm
from transformers import AutoModel, AutoTokenizer

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


VARIANT_SOURCES: Dict[str, Dict[str, str]] = {
    "chemfm-1b": {
        "repo_id": "ChemFM/ChemFM-1B",
        "local_dir": "ChemFM-1B",
    },
    "chemfm-3b": {
        "repo_id": "ChemFM/ChemFM-3B",
        "local_dir": "ChemFM-3B",
    },
    "chemfmv2-20m": {
        "repo_id": "ChemFM/ChemFMv2-20M",
        "local_dir": "ChemFMv2-20M",
    },
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Encode molecules with ChemFM and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file (.txt or .csv)")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--variant",
        default="chemfm-1b",
        choices=sorted(VARIANT_SOURCES.keys()),
        help="ChemFM checkpoint variant",
    )
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--normalize", action="store_true", help="Apply L2 normalization")
    return parser.parse_args()


def masked_mean_pool(last_hidden_state: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    mask = attention_mask.unsqueeze(-1).to(last_hidden_state.dtype)
    masked_hidden = last_hidden_state * mask
    summed = masked_hidden.sum(dim=1)
    counts = mask.sum(dim=1).clamp(min=1e-9)
    return summed / counts


def extract_embeddings(
    smiles_list: List[str],
    model: Any,
    tokenizer: Any,
    device: torch.device,
    batch_size: int,
    max_length: int,
) -> np.ndarray:
    chunks: List[np.ndarray] = []

    for start in tqdm(range(0, len(smiles_list), batch_size), desc="Extracting embeddings"):
        batch_smiles = smiles_list[start : start + batch_size]

        inputs = tokenizer(
            batch_smiles,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_length,
        )

        inputs.pop("token_type_ids", None)
        inputs = {key: value.to(device) for key, value in inputs.items()}

        with torch.no_grad():
            outputs = model(**inputs)

        if not hasattr(outputs, "last_hidden_state") or outputs.last_hidden_state is None:
            raise RuntimeError(
                "Selected model did not return last_hidden_state. "
                "Use a base ChemFM model compatible with AutoModel."
            )

        pooled = masked_mean_pool(outputs.last_hidden_state, inputs["attention_mask"])
        chunks.append(np.asarray(pooled.detach().cpu().tolist(), dtype=np.float32))

    if not chunks:
        return np.empty((0, 0), dtype=np.float32)
    return np.vstack(chunks)


def resolve_model_source(script_dir: Path, variant: str) -> Tuple[str, bool, str]:
    if variant not in VARIANT_SOURCES:
        raise ValueError("Unsupported variant: %s" % variant)

    entry = VARIANT_SOURCES[variant]
    repo_id = entry["repo_id"]
    local_dir = (script_dir / ".cache" / "huggingface" / entry["local_dir"]).resolve()

    if local_dir.exists():
        return str(local_dir), True, repo_id
    return repo_id, False, repo_id


def l2_normalize(vectors: np.ndarray) -> np.ndarray:
    if vectors.size == 0:
        return vectors
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return (vectors / norms).astype(np.float32, copy=False)


def main() -> None:
    args = parse_args()

    input_path = Path(args.file).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError("Input file not found: %s" % input_path)

    output_dir = Path(args.output_dir).expanduser().resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    lines = load_input_lines(input_path)
    records, failures = preprocess_lines(
        lines=lines,
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )
    if not records:
        raise ValueError("No valid molecules remained after preprocessing.")

    smiles_list = [record["smiles"] for record in records]

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    model_source, local_only, repo_id = resolve_model_source(_SCRIPT_DIR, args.variant)

    tokenizer = AutoTokenizer.from_pretrained(model_source, local_files_only=local_only)
    if tokenizer.pad_token is None:
        if tokenizer.eos_token is None:
            raise RuntimeError(
                "Tokenizer has neither pad_token nor eos_token, so batch padding cannot be set safely."
            )
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModel.from_pretrained(model_source, local_files_only=local_only)
    model.config.pad_token_id = tokenizer.pad_token_id
    model.to(device)
    model.eval()

    embeddings = extract_embeddings(
        smiles_list=smiles_list,
        model=model,
        tokenizer=tokenizer,
        device=device,
        batch_size=args.batch_size,
        max_length=args.max_length,
    )

    if args.normalize:
        embeddings = l2_normalize(embeddings)

    np.save(npy_path, embeddings)
    write_mapping_csv(map_path, records)

    if failures:
        write_failures_csv(failures_path, failures)
    elif failures_path.exists():
        failures_path.unlink()

    print("Saved embeddings to: %s" % npy_path)
    print("variant=%s" % args.variant)
    print("n_samples=%d" % len(records))
    print("embedding_shape=%s" % (embeddings.shape,))
    print("Model source: %s (local_files_only=%s)" % (model_source, local_only))
    if not local_only:
        print("Model repo id: %s" % repo_id)


if __name__ == "__main__":
    main()
