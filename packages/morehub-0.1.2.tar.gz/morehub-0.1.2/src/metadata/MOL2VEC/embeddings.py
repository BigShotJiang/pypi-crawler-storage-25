#!/usr/bin/env python
"""Generate Mol2Vec embeddings under MoreHub CLI-v2 protocol."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, List, Optional

import numpy as np
from gensim.models import word2vec
from mol2vec.features import mol2alt_sentence, mol2sentence, sentences2vec
from rdkit import Chem

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Encode molecules with Mol2Vec and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file (.txt or .csv)")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--model-path",
        default=None,
        help="Optional path to pretrained Mol2Vec model (.pkl)",
    )
    parser.add_argument("--radius", type=int, default=1, help="Morgan radius for Mol2Vec sentence extraction")
    parser.add_argument("--unseen", default="UNK", help="Token used for unseen substructures")
    parser.add_argument("--normalize", action="store_true", help="Apply L2 normalization")
    return parser.parse_args()


def _resolve_default_model_path(script_dir: Path) -> Path:
    candidates = [
        (script_dir / ".repo" / "mol2vec" / "examples" / "models" / "model_300dim.pkl").resolve(),
        (script_dir / "mol2vec" / "examples" / "models" / "model_300dim.pkl").resolve(),
        (script_dir / "examples" / "models" / "model_300dim.pkl").resolve(),
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(
        "Mol2Vec model file not found. Expected one of:\n%s"
        % "\n".join(str(path) for path in candidates)
    )


def _load_mol2vec_model(model_path: Path):
    if not model_path.exists():
        raise FileNotFoundError("Model file not found: %s" % model_path)

    try:
        return word2vec.Word2Vec.load(str(model_path))
    except Exception:
        return word2vec.Word2VecKeyedVectors.load_word2vec_format(str(model_path), binary=True)


def _mol_from_smiles(smiles: str):
    text = str(smiles).strip()
    if not text:
        return None
    try:
        return Chem.MolFromSmiles(text)
    except Exception:
        return None


def _mol_to_sentence(mol: Any, radius: int):
    if mol is None:
        return None
    try:
        if int(radius) == 1:
            return mol2alt_sentence(mol, radius)
        return mol2sentence(mol, radius)
    except Exception:
        return None


def _sentence_to_embedding(sentence: Any, model: Any, unseen: str) -> Optional[np.ndarray]:
    if sentence is None or len(sentence) == 0:
        return None

    vectors = sentences2vec([sentence], model, unseen=unseen)
    if vectors is None or len(vectors) == 0:
        return None
    return np.asarray(vectors[0], dtype=np.float32)


def _l2_normalize(vectors: np.ndarray) -> np.ndarray:
    if vectors.size == 0:
        return vectors
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return (vectors / norms).astype(np.float32, copy=False)


def _vector_size(model: Any) -> int:
    if hasattr(model, "wv"):
        return int(model.wv.vector_size)
    return int(model.vector_size)


def main() -> None:
    args = parse_args()

    input_path = Path(args.file).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError("Input file not found: %s" % input_path)

    output_dir = Path(args.output_dir).expanduser().resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    script_dir = Path(__file__).resolve().parent
    model_path = Path(args.model_path).expanduser().resolve() if args.model_path else _resolve_default_model_path(script_dir)

    records, failures = preprocess_lines(
        lines=load_input_lines(input_path),
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )
    if not records:
        raise ValueError("No valid molecules remained after preprocessing")

    model = _load_mol2vec_model(model_path)
    target_dim = _vector_size(model)

    kept_records: List[dict] = []
    embeddings: List[np.ndarray] = []

    for record in records:
        smiles = str(record.get("smiles", "")).strip()
        mol = _mol_from_smiles(smiles)
        if mol is None:
            failures.append(
                {
                    "original_line": str(record.get("original_line", "")),
                    "input_text": record.get("input_text", ""),
                    "reason": "invalid_smiles",
                }
            )
            continue

        sentence = _mol_to_sentence(mol, radius=args.radius)
        if sentence is None:
            failures.append(
                {
                    "original_line": str(record.get("original_line", "")),
                    "input_text": record.get("input_text", ""),
                    "reason": "sentence_generation_failed",
                }
            )
            continue

        emb = _sentence_to_embedding(sentence, model=model, unseen=args.unseen)
        if emb is None:
            failures.append(
                {
                    "original_line": str(record.get("original_line", "")),
                    "input_text": record.get("input_text", ""),
                    "reason": "embedding_generation_failed",
                }
            )
            continue

        if emb.shape[0] != target_dim:
            failures.append(
                {
                    "original_line": str(record.get("original_line", "")),
                    "input_text": record.get("input_text", ""),
                    "reason": "unexpected_embedding_dim",
                }
            )
            continue

        kept_records.append(record)
        embeddings.append(emb)

    if not embeddings:
        raise ValueError("No valid molecule embeddings were produced")

    matrix = np.vstack(embeddings).astype(np.float32, copy=False)
    if args.normalize:
        matrix = _l2_normalize(matrix)

    np.save(str(npy_path), matrix)
    write_mapping_csv(map_path, kept_records)

    if failures:
        write_failures_csv(failures_path, failures)
    elif failures_path.exists():
        failures_path.unlink()

    print("Saved embeddings to: %s" % npy_path)
    print("Embeddings shape: %s" % (matrix.shape,))
    print("Model source: %s" % model_path)


if __name__ == "__main__":
    main()
