from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List

import numpy as np

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_DIR = SCRIPT_DIR / ".repo" / "MOLR"
SRC_DIR = REPO_DIR / "src"

if not SRC_DIR.exists():
    raise FileNotFoundError(
        f"MOLR source directory not found at {SRC_DIR}. Ensure setup completed successfully."
    )

if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

try:
    from featurizer import MolEFeaturizer
except Exception as exc:
    raise ImportError(
        "Could not import MolEFeaturizer from MOLR repository. "
        "Ensure setup completed successfully and dependencies are installed."
    ) from exc

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


def _resolve_variant(variant: str) -> str:
    normalized = str(variant).strip().lower()
    allowed = {"gcn_1024", "gat_1024", "sage_1024", "tag_1024"}
    if normalized not in allowed:
        raise ValueError(f"Unknown MOLR variant '{variant}'. Expected one of: {sorted(allowed)}")
    return normalized


def _build_featurizer(variant: str) -> tuple[MolEFeaturizer, Path]:
    model_path = REPO_DIR / "saved" / variant
    if not model_path.exists():
        raise FileNotFoundError(
            f"MOLR checkpoint directory not found at {model_path}. "
            "Ensure repository artifacts are present."
        )
    featurizer = MolEFeaturizer(path_to_model=str(model_path))
    return featurizer, model_path


def _flags_to_bool_list(flags, expected_count: int) -> List[bool]:
    if flags is None:
        return [True] * expected_count

    try:
        values = list(flags)
    except TypeError:
        return [True] * expected_count

    if len(values) != expected_count:
        return [True] * expected_count

    normalized: List[bool] = []
    for value in values:
        if isinstance(value, (bool, np.bool_)):
            normalized.append(bool(value))
        elif isinstance(value, (int, np.integer)):
            normalized.append(bool(int(value)))
        elif isinstance(value, str):
            normalized.append(value.strip().lower() in {"1", "true", "t", "yes", "y", "ok"})
        else:
            normalized.append(bool(value))
    return normalized


def _l2_normalize(embeddings: np.ndarray) -> np.ndarray:
    if embeddings.size == 0:
        return embeddings
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return embeddings / norms


def main() -> None:
    parser = argparse.ArgumentParser(description="Encode molecules with MOLR and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--variant",
        default="gcn_1024",
        choices=["gcn_1024", "gat_1024", "sage_1024", "tag_1024"],
        help="MOLR submodel checkpoint",
    )
    parser.add_argument("--batch-size", type=int, default=512, help="Batch size for featurizer.transform")
    parser.add_argument(
        "--normalize",
        action="store_true",
        help="Apply L2 normalization to output embeddings",
    )
    args = parser.parse_args()

    variant = _resolve_variant(args.variant)
    input_path = Path(args.file).resolve()
    output_dir = Path(args.output_dir).resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    lines = load_input_lines(input_path)
    records, failures = preprocess_lines(
        lines,
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )

    if not records:
        np.save(str(npy_path), np.empty((0, 0), dtype=np.float32))
        write_mapping_csv(map_path, [])
        write_failures_csv(failures_path, failures)
        print("No valid molecules after preprocessing. Saved empty outputs.", file=sys.stderr)
        return

    featurizer, model_path = _build_featurizer(variant)

    kept_records: List[dict] = []
    embedding_chunks: List[np.ndarray] = []

    batch_size = max(1, int(args.batch_size))
    for start in range(0, len(records), batch_size):
        batch_records = records[start : start + batch_size]
        batch_smiles = [record["smiles"] for record in batch_records]

        try:
            batch_embeddings, batch_flags = featurizer.transform(batch_smiles)
        except Exception as exc:
            reason = f"molr_transform_failed:{exc}"
            for record in batch_records:
                failures.append(
                    {
                        "original_line": str(record.get("original_line", "")),
                        "input_text": record.get("input_text", ""),
                        "reason": reason,
                    }
                )
            continue

        batch_embeddings_np = np.asarray(batch_embeddings, dtype=np.float32)
        if batch_embeddings_np.ndim == 1:
            batch_embeddings_np = batch_embeddings_np.reshape(1, -1)

        keep_mask = _flags_to_bool_list(batch_flags, len(batch_records))
        keep_indices = [index for index, flag in enumerate(keep_mask) if flag]

        for index, keep in enumerate(keep_mask):
            if keep:
                continue
            record = batch_records[index]
            failures.append(
                {
                    "original_line": str(record.get("original_line", "")),
                    "input_text": record.get("input_text", ""),
                    "reason": "molr_transform_flag_false",
                }
            )

        if batch_embeddings_np.shape[0] == len(batch_records):
            if keep_indices:
                embedding_chunks.append(batch_embeddings_np[keep_indices])
                kept_records.extend(batch_records[index] for index in keep_indices)
        elif batch_embeddings_np.shape[0] == len(keep_indices):
            if keep_indices:
                embedding_chunks.append(batch_embeddings_np)
                kept_records.extend(batch_records[index] for index in keep_indices)
        elif batch_embeddings_np.shape[0] == 0 and not keep_indices:
            continue
        else:
            raise RuntimeError(
                "Unexpected transform output size from MOLR: "
                f"embeddings_rows={batch_embeddings_np.shape[0]}, input_rows={len(batch_records)}, "
                f"flagged_success={len(keep_indices)}"
            )

    if embedding_chunks:
        embeddings = np.concatenate(embedding_chunks, axis=0).astype(np.float32, copy=False)
    else:
        embeddings = np.empty((0, 0), dtype=np.float32)

    if embeddings.shape[0] != len(kept_records):
        raise RuntimeError(
            "Embedding row count does not match kept record count: "
            f"{embeddings.shape[0]} vs {len(kept_records)}"
        )

    if args.normalize and embeddings.size:
        embeddings = _l2_normalize(embeddings).astype(np.float32, copy=False)

    np.save(str(npy_path), embeddings)
    write_mapping_csv(map_path, kept_records)
    write_failures_csv(failures_path, failures)

    print(f"Saved embeddings to {npy_path} with shape {embeddings.shape}.")
    print(f"Saved row mapping to {map_path}.")
    if failures:
        print(f"Saved {len(failures)} failed rows to {failures_path}.")
    print(f"Model source: {model_path} (variant={variant})")


if __name__ == "__main__":
    main()