﻿from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, List

import numpy as np
import torch

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_DIR = SCRIPT_DIR / ".repo" / "COATI"

if not REPO_DIR.exists():
    raise FileNotFoundError(
        f"COATI repository directory not found at {REPO_DIR}. Ensure setup completed successfully."
    )

if str(REPO_DIR) not in sys.path:
    sys.path.insert(0, str(REPO_DIR))

try:
    from coati.models.io import load_e3gnn_smiles_clip_e2e
except Exception as exc:
    raise ImportError(
        "Could not import load_e3gnn_smiles_clip_e2e from COATI repository. "
        "Ensure setup completed successfully."
    ) from exc

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from embeddings_preprocess import (  # noqa: E402
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


MODEL_DOC_URIS = {
    "grande_closed": "s3://terray-public/models/grande_closed.pkl",
    "tall_closed": "s3://terray-public/models/tall_closed.pkl",
    "grade_closed_fp": "s3://terray-public/models/grade_closed_fp.pkl",
    "barlow_closed_fp": "s3://terray-public/models/barlow_closed_fp.pkl",
    "barlow_closed": "s3://terray-public/models/barlow_closed.pkl",
    "autoreg_only": "s3://terray-public/models/autoreg_only.pkl",
    "barlow_venti": "s3://terray-public/models/barlow_venti.pkl",
    "grande_open": "s3://terray-public/models/grande_open.pkl",
    "selfies_barlow": "s3://terray-public/models/selfies_barlow.pkl",
}


def _resolve_variant(value: str) -> str:
    variant = str(value).strip().lower()
    if variant not in MODEL_DOC_URIS:
        raise ValueError(f"Unsupported COATI variant '{value}'. Expected one of: {sorted(MODEL_DOC_URIS)}")
    return variant


def _resolve_device(device_arg: str) -> torch.device:
    normalized = str(device_arg).strip().lower()
    if normalized == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if normalized not in {"cpu", "cuda"}:
        raise ValueError(f"Unsupported device: {device_arg}")
    if normalized == "cuda" and not torch.cuda.is_available():
        print("CUDA requested but unavailable; falling back to CPU.", file=sys.stderr)
        return torch.device("cpu")
    return torch.device(normalized)


def _resolve_doc_url(variant: str, model_path: str | None) -> str:
    if model_path:
        explicit = Path(model_path).expanduser().resolve()
        if not explicit.exists():
            raise FileNotFoundError(f"COATI model path does not exist: {explicit}")
        return str(explicit)

    expected_name = Path(MODEL_DOC_URIS[variant]).name
    local_cache = SCRIPT_DIR / ".cache" / expected_name
    if local_cache.exists():
        return str(local_cache)

    # Fallback for direct local runs when cache download has not occurred yet.
    return MODEL_DOC_URIS[variant]


def _load_coati_model(variant: str, device: torch.device, model_path: str | None):
    doc_url = _resolve_doc_url(variant, model_path)
    encoder, tokenizer = load_e3gnn_smiles_clip_e2e(
        freeze=True,
        device=device,
        doc_url=doc_url,
    )
    if hasattr(encoder, "eval"):
        encoder.eval()
    return encoder, tokenizer, doc_url


def _embed_batch(
    encoder: Any,
    tokenizer: Any,
    molecules: List[str],
    device: torch.device,
) -> torch.Tensor:
    if tokenizer is not None and hasattr(tokenizer, "batch_smiles") and hasattr(encoder, "encode_tokens"):
        token_indices, _ = tokenizer.batch_smiles(molecules, device=str(device))
        output = encoder.encode_tokens(token_indices=token_indices, tokenizer=tokenizer)
        if torch.is_tensor(output):
            return output

    for method_name in [
        "embed_smiles",
        "encode_smiles",
        "smiles_to_embedding",
        "encode_molecules",
        "encode_batch",
    ]:
        if not hasattr(encoder, method_name):
            continue
        method = getattr(encoder, method_name)
        for call in (
            lambda: method(molecules),
            lambda: method(molecules, tokenizer=tokenizer),
            lambda: method(molecules, tokenizer),
        ):
            try:
                output = call()
            except TypeError:
                continue
            if torch.is_tensor(output):
                return output

    raise RuntimeError("Could not find a native COATI embedding method that returns a tensor.")


def _normalize_embedding_shape(embeddings: torch.Tensor, expected_rows: int) -> np.ndarray:
    emb = embeddings
    if emb.ndim == 3:
        if emb.shape[0] == 1:
            emb = emb.squeeze(0)
        elif emb.shape[1] == 1:
            emb = emb.squeeze(1)

    if emb.ndim != 2:
        raise RuntimeError(f"Unexpected embedding shape: {tuple(emb.shape)}")

    if emb.shape[0] != expected_rows:
        raise RuntimeError(
            f"COATI returned {emb.shape[0]} embeddings for a batch of {expected_rows} molecules."
        )

    return emb.detach().cpu().numpy().astype(np.float32, copy=False)


def _l2_normalize(embeddings: np.ndarray) -> np.ndarray:
    if embeddings.size == 0:
        return embeddings
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return embeddings / norms


def _failure_from_record(record: dict[str, Any], reason: str) -> dict[str, Any]:
    failure = {
        "original_line": str(record.get("original_line", "")),
        "input_text": record.get("input_text", ""),
        "reason": reason,
    }
    if "source_type" in record:
        failure["source_type"] = record.get("source_type")
    if "source_header" in record:
        failure["source_header"] = record.get("source_header")
    if "source_row" in record:
        failure["source_row"] = record.get("source_row")
    return failure


def main() -> None:
    parser = argparse.ArgumentParser(description="Encode molecules with COATI and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--variant",
        default="grande_closed",
        choices=sorted(MODEL_DOC_URIS.keys()),
        help="COATI submodel variant",
    )
    parser.add_argument("--model-path", default=None, help="Optional explicit checkpoint path")
    parser.add_argument("--batch-size", type=int, default=64, help="Batch size")
    parser.add_argument(
        "--device",
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help="Inference device",
    )
    parser.add_argument(
        "--normalize",
        action="store_true",
        help="Apply L2 normalization to embeddings",
    )
    args = parser.parse_args()

    variant = _resolve_variant(args.variant)
    device = _resolve_device(args.device)
    batch_size = max(1, int(args.batch_size))

    input_path = Path(args.file).resolve()
    output_dir = Path(args.output_dir).resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    lines = load_input_lines(input_path)
    records, failures = preprocess_lines(
        lines,
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )

    if not records:
        np.save(str(npy_path), np.empty((0, 0), dtype=np.float32))
        write_mapping_csv(map_path, [])
        write_failures_csv(failures_path, failures)
        print("No valid molecules after preprocessing. Saved empty outputs.", file=sys.stderr)
        return

    encoder, tokenizer, doc_url = _load_coati_model(variant, device=device, model_path=args.model_path)

    kept_records: List[dict[str, Any]] = []
    chunks: List[np.ndarray] = []

    with torch.no_grad():
        for start in range(0, len(records), batch_size):
            batch_records = records[start : start + batch_size]
            model_inputs = [str(record["model_input"]) for record in batch_records]
            try:
                raw_embeddings = _embed_batch(encoder, tokenizer, model_inputs, device)
                batch_embeddings = _normalize_embedding_shape(raw_embeddings, expected_rows=len(batch_records))
            except Exception as exc:
                reason = f"coati_embed_failed:{exc}"
                for record in batch_records:
                    failures.append(_failure_from_record(record, reason))
                continue

            chunks.append(batch_embeddings)
            kept_records.extend(batch_records)

    if chunks:
        embeddings = np.concatenate(chunks, axis=0).astype(np.float32, copy=False)
    else:
        embeddings = np.empty((0, 0), dtype=np.float32)

    if args.normalize and embeddings.size:
        embeddings = _l2_normalize(embeddings).astype(np.float32, copy=False)

    np.save(str(npy_path), embeddings)
    write_mapping_csv(map_path, kept_records)
    write_failures_csv(failures_path, failures)

    print(f"Saved embeddings to {npy_path} with shape {embeddings.shape}.")
    print(f"Saved row mapping to {map_path}.")
    if failures:
        print(f"Saved {len(failures)} failed rows to {failures_path}.")
    print(f"Model source: {doc_url} (variant={variant})")


if __name__ == "__main__":
    main()
