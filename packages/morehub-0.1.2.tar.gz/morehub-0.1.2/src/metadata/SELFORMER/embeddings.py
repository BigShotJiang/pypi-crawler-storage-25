#!/usr/bin/env python
"""Generate SELFormer embeddings under MoreHub CLI-v2 protocol."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
from tqdm import tqdm
from transformers import RobertaConfig, RobertaModel, RobertaTokenizer

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


MODEL_DIR_CANDIDATES: Dict[str, List[Tuple[str, ...]]] = {
    "selformer": [
        (".cache", "bundles", "SELFormer", "SELFormer"),
        (".cache", "bundles", "SELFormer"),
        ("SELFormer", "SELFormer"),
        ("SELFormer",),
    ],
    "selformer-lite": [
        (".cache", "bundles", "SELFormer-Lite", "SELFormer-Lite"),
        (".cache", "bundles", "SELFormer-Lite"),
        ("SELFormer-Lite", "SELFormer-Lite"),
        ("SELFormer-Lite",),
    ],
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Encode molecules with SELFormer and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file (.txt or .csv)")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--variant",
        default="selformer-lite",
        choices=["selformer", "selformer-lite"],
        help="SELFormer model variant",
    )
    parser.add_argument("--model-dir", default=None, help="Optional explicit model directory override")
    parser.add_argument("--tokenizer-dir", default=None, help="Optional explicit tokenizer directory override")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--normalize", action="store_true", help="Apply L2 normalization")
    return parser.parse_args()


def mean_pool(last_hidden_state: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    mask = attention_mask.unsqueeze(-1).to(last_hidden_state.dtype)
    masked_hidden = last_hidden_state * mask
    summed = masked_hidden.sum(dim=1)
    counts = mask.sum(dim=1).clamp(min=1e-9)
    return summed / counts


def _candidate_dirs(script_dir: Path, variant: str) -> List[Path]:
    result: List[Path] = []
    for parts in MODEL_DIR_CANDIDATES.get(variant, []):
        result.append((script_dir.joinpath(*parts)).resolve())
    return result


def _looks_like_model_dir(path: Path) -> bool:
    if not path.exists() or not path.is_dir():
        return False
    has_config = (path / "config.json").exists()
    has_weights = (path / "pytorch_model.bin").exists() or (path / "model.safetensors").exists()
    has_tokenizer = (path / "tokenizer_config.json").exists() or (path / "vocab.json").exists()
    return has_config and (has_weights or has_tokenizer)


def resolve_model_and_tokenizer_dirs(
    script_dir: Path,
    variant: str,
    model_dir_arg: Optional[str],
    tokenizer_dir_arg: Optional[str],
) -> Tuple[Path, Path]:
    if model_dir_arg:
        model_dir = Path(model_dir_arg).expanduser().resolve()
    else:
        candidates = _candidate_dirs(script_dir, variant)
        found = next((candidate for candidate in candidates if _looks_like_model_dir(candidate)), None)
        if found is None:
            raise FileNotFoundError(
                "Could not locate SELFormer model directory for variant '%s'. Checked:\n%s"
                % (variant, "\n".join(str(candidate) for candidate in candidates))
            )
        model_dir = found

    tokenizer_dir = Path(tokenizer_dir_arg).expanduser().resolve() if tokenizer_dir_arg else model_dir

    if not model_dir.exists():
        raise FileNotFoundError("Model directory not found: %s" % model_dir)
    if not tokenizer_dir.exists():
        raise FileNotFoundError("Tokenizer directory not found: %s" % tokenizer_dir)

    return model_dir, tokenizer_dir


def load_model_and_tokenizer(model_dir: Path, tokenizer_dir: Path, device: torch.device) -> Tuple[Any, Any]:
    config = RobertaConfig.from_pretrained(str(model_dir))
    model = RobertaModel.from_pretrained(str(model_dir), config=config)
    tokenizer = RobertaTokenizer.from_pretrained(str(tokenizer_dir))

    model.to(device)
    model.eval()
    return model, tokenizer


@torch.no_grad()
def extract_embeddings(
    selfies_list: List[str],
    model: Any,
    tokenizer: Any,
    device: torch.device,
    batch_size: int,
    max_length: int,
) -> np.ndarray:
    chunks: List[np.ndarray] = []

    for start in tqdm(range(0, len(selfies_list), batch_size), desc="Extracting embeddings"):
        batch_selfies = selfies_list[start : start + batch_size]

        inputs = tokenizer(
            batch_selfies,
            return_tensors="pt",
            padding=True,
            truncation=True,
            max_length=max_length,
        )
        inputs.pop("token_type_ids", None)
        inputs = {key: value.to(device) for key, value in inputs.items()}

        outputs = model(**inputs)
        if not hasattr(outputs, "last_hidden_state") or outputs.last_hidden_state is None:
            raise RuntimeError("Model did not return last_hidden_state.")

        pooled = mean_pool(outputs.last_hidden_state, inputs["attention_mask"])
        chunks.append(np.asarray(pooled.detach().cpu().tolist(), dtype=np.float32))

    if not chunks:
        return np.empty((0, 0), dtype=np.float32)
    return np.vstack(chunks)


def l2_normalize(vectors: np.ndarray) -> np.ndarray:
    if vectors.size == 0:
        return vectors
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return (vectors / norms).astype(np.float32, copy=False)


def main() -> None:
    args = parse_args()

    input_path = Path(args.file).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError("Input file not found: %s" % input_path)

    output_dir = Path(args.output_dir).expanduser().resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    records, failures = preprocess_lines(
        lines=load_input_lines(input_path),
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )
    if not records:
        raise ValueError("No valid molecules remained after preprocessing.")

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    script_dir = Path(__file__).resolve().parent
    model_dir, tokenizer_dir = resolve_model_and_tokenizer_dirs(
        script_dir=script_dir,
        variant=args.variant,
        model_dir_arg=args.model_dir,
        tokenizer_dir_arg=args.tokenizer_dir,
    )

    model, tokenizer = load_model_and_tokenizer(model_dir=model_dir, tokenizer_dir=tokenizer_dir, device=device)

    selfies_list = [str(record["model_input"]) for record in records]
    embeddings = extract_embeddings(
        selfies_list=selfies_list,
        model=model,
        tokenizer=tokenizer,
        device=device,
        batch_size=args.batch_size,
        max_length=args.max_length,
    )

    if args.normalize:
        embeddings = l2_normalize(embeddings)

    np.save(npy_path, embeddings)
    write_mapping_csv(map_path, records)

    if failures:
        write_failures_csv(failures_path, failures)
    elif failures_path.exists():
        failures_path.unlink()

    print("Saved embeddings to: %s" % npy_path)
    print("variant=%s" % args.variant)
    print("n_samples=%d" % len(records))
    print("embedding_shape=%s" % (embeddings.shape,))
    print("Model dir: %s" % model_dir)
    print("Tokenizer dir: %s" % tokenizer_dir)


if __name__ == "__main__":
    main()
