#!/usr/bin/env python
"""Generate GEM embeddings under MoreHub CLI-v2 protocol."""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Encode molecules with GEM and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file (.txt or .csv)")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")

    parser.add_argument(
        "--repo-root",
        default=None,
        help="Optional PaddleHelix repo root. Defaults to model .repo/PaddleHelix.",
    )
    parser.add_argument(
        "--encoder-config",
        default=None,
        help="Optional path to geognn_l8.json encoder config.",
    )
    parser.add_argument(
        "--checkpoint",
        default=None,
        help="Optional path to helixfold-single.pdparams.",
    )
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--num-workers", type=int, default=1)
    parser.add_argument(
        "--device",
        default="auto",
        help="Paddle device: auto|cpu|gpu|gpu:0",
    )
    parser.add_argument(
        "--normalize",
        action="store_true",
        help="Apply L2 normalization to output embeddings.",
    )
    return parser.parse_args()


def configure_runtime_environment(script_dir: Path) -> None:
    """Set writable runtime directories for Paddle defaults."""
    default_paddle_home = script_dir / ".paddlehome"
    os.environ.setdefault("PADDLE_HOME", str(default_paddle_home))
    Path(os.environ["PADDLE_HOME"]).mkdir(parents=True, exist_ok=True)

    home_path = Path(os.environ.get("HOME", str(Path.home()))).expanduser()
    legacy_cache = home_path / ".cache" / "paddle"
    try:
        legacy_cache.mkdir(parents=True, exist_ok=True)
    except Exception:
        os.environ["HOME"] = str(script_dir)
        fallback_cache = script_dir / ".cache" / "paddle"
        fallback_cache.mkdir(parents=True, exist_ok=True)


def _as_repo_root(path: Path) -> Optional[Path]:
    if (path / "pahelix").is_dir():
        return path
    if (path / "PaddleHelix" / "pahelix").is_dir():
        return path / "PaddleHelix"
    return None


def resolve_paddlehelix_root(repo_root_arg: Optional[str], script_dir: Path) -> Path:
    if repo_root_arg:
        resolved = _as_repo_root(Path(repo_root_arg).expanduser().resolve())
        if resolved is None:
            raise FileNotFoundError(
                "Could not find PaddleHelix from --repo-root=%r. "
                "Expected <path>/pahelix or <path>/PaddleHelix/pahelix." % repo_root_arg
            )
        return resolved

    preferred = script_dir / ".repo" / "PaddleHelix"
    resolved = _as_repo_root(preferred)
    if resolved is not None:
        return resolved

    for candidate in [script_dir] + list(script_dir.parents):
        resolved = _as_repo_root(candidate)
        if resolved is not None:
            return resolved

    raise FileNotFoundError(
        "Could not auto-detect PaddleHelix repo root. Pass --repo-root explicitly."
    )


def default_encoder_config_path(repo_root: Path) -> Path:
    return (
        repo_root
        / "apps"
        / "pretrained_compound"
        / "ChemRL"
        / "GEM"
        / "model_configs"
        / "geognn_l8.json"
    )


def default_checkpoint_path(script_dir: Path) -> Path:
    return script_dir / ".cache" / "helixfold-single.pdparams"


def read_encoder_config(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_encoder_state_dict(compound_encoder: Any, checkpoint_path: Path, paddle_module: Any) -> None:
    checkpoint = paddle_module.load(str(checkpoint_path))

    candidates: List[Tuple[str, Dict[str, Any]]] = []
    if isinstance(checkpoint, dict):
        candidates.append(("checkpoint", checkpoint))
        for key in ("state_dict", "model_state_dict", "model", "compound_encoder", "encoder"):
            value = checkpoint.get(key)
            if isinstance(value, dict):
                candidates.append((key, value))
    else:
        raise TypeError("Unsupported checkpoint format from %s" % checkpoint_path)

    errors: List[str] = []
    for source_name, state_dict in candidates:
        try:
            compound_encoder.set_state_dict(state_dict)
            return
        except Exception as exc:
            errors.append("%s: direct load failed (%s)" % (source_name, exc))

        stripped = {
            key[len("compound_encoder.") :]: value
            for key, value in state_dict.items()
            if key.startswith("compound_encoder.")
        }
        if not stripped:
            continue
        try:
            compound_encoder.set_state_dict(stripped)
            return
        except Exception as exc:
            errors.append("%s: stripped prefix load failed (%s)" % (source_name, exc))

    raise RuntimeError(
        "Failed to load checkpoint into GeoGNN encoder from %s.\n%s"
        % (checkpoint_path, "\n".join(errors))
    )


def build_inference_collate_fn(
    atom_names: Sequence[str],
    bond_names: Sequence[str],
    bond_float_names: Sequence[str],
    bond_angle_float_names: Sequence[str],
    pgl_module: Any,
):
    class GemInferenceCollateFn(object):
        def _flat_shapes(self, feat_dict: Dict[str, np.ndarray]) -> None:
            for key in feat_dict:
                feat_dict[key] = feat_dict[key].reshape([-1])

        def __call__(self, data_list: Sequence[Dict[str, Any]]):
            atom_bond_graph_list = []
            bond_angle_graph_list = []
            for data in data_list:
                atom_bond_graph = pgl_module.Graph(
                    num_nodes=len(data[atom_names[0]]),
                    edges=data["edges"],
                    node_feat={name: data[name].reshape([-1, 1]) for name in atom_names},
                    edge_feat={
                        name: data[name].reshape([-1, 1])
                        for name in list(bond_names) + list(bond_float_names)
                    },
                )
                bond_angle_graph = pgl_module.Graph(
                    num_nodes=len(data["edges"]),
                    edges=data["BondAngleGraph_edges"],
                    node_feat={},
                    edge_feat={
                        name: data[name].reshape([-1, 1]) for name in bond_angle_float_names
                    },
                )
                atom_bond_graph_list.append(atom_bond_graph)
                bond_angle_graph_list.append(bond_angle_graph)

            atom_bond_graph = pgl_module.Graph.batch(atom_bond_graph_list)
            bond_angle_graph = pgl_module.Graph.batch(bond_angle_graph_list)

            self._flat_shapes(atom_bond_graph.node_feat)
            self._flat_shapes(atom_bond_graph.edge_feat)
            self._flat_shapes(bond_angle_graph.node_feat)
            self._flat_shapes(bond_angle_graph.edge_feat)

            return atom_bond_graph, bond_angle_graph

    return GemInferenceCollateFn()


def _failure_from_record(record: Dict[str, Any], reason: str) -> Dict[str, Any]:
    failure = {
        "original_line": str(record.get("original_line", "")),
        "input_text": record.get("input_text", ""),
        "reason": reason,
    }
    if "source_type" in record:
        failure["source_type"] = record.get("source_type")
    if "source_header" in record:
        failure["source_header"] = record.get("source_header")
    if "source_row" in record:
        failure["source_row"] = record.get("source_row")
    return failure


def _resolve_device(device_arg: str) -> str:
    normalized = str(device_arg).strip().lower()
    if normalized in {"auto", ""}:
        return "gpu" if os.environ.get("CUDA_VISIBLE_DEVICES", "") != "" else "cpu"
    return normalized


def _l2_normalize(vectors: np.ndarray) -> np.ndarray:
    if vectors.size == 0:
        return vectors
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return vectors / norms


def main() -> None:
    args = parse_args()

    input_path = Path(args.file).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError("Input file not found: %s" % input_path)

    output_dir = Path(args.output_dir).expanduser().resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    script_dir = Path(__file__).resolve().parent
    configure_runtime_environment(script_dir)

    repo_root = resolve_paddlehelix_root(args.repo_root, script_dir)
    sys.path.insert(0, str(repo_root))

    import paddle
    import pgl
    from rdkit.Chem import AllChem

    from pahelix.datasets.inmemory_dataset import InMemoryDataset
    from pahelix.model_zoo.gem_model import GeoGNNModel
    from pahelix.utils.compound_tools import mol_to_geognn_graph_data_MMFF3d

    device = _resolve_device(args.device)
    try:
        paddle.set_device(device)
    except Exception:
        if device != "cpu":
            paddle.set_device("cpu")
            device = "cpu"
        else:
            raise

    encoder_config_path = (
        Path(args.encoder_config).expanduser().resolve()
        if args.encoder_config
        else default_encoder_config_path(repo_root)
    )
    if not encoder_config_path.is_file():
        raise FileNotFoundError("Encoder config not found: %s" % encoder_config_path)

    checkpoint_path = (
        Path(args.checkpoint).expanduser().resolve()
        if args.checkpoint
        else default_checkpoint_path(script_dir)
    )
    if not checkpoint_path.is_file():
        raise FileNotFoundError("Checkpoint not found: %s" % checkpoint_path)

    lines = load_input_lines(input_path)
    records, failures = preprocess_lines(
        lines=lines,
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )
    if not records:
        raise ValueError("No valid molecules remained after preprocessing.")

    graph_data_list: List[Dict[str, Any]] = []
    graph_records: List[Dict[str, Any]] = []
    for record in records:
        mol = AllChem.MolFromSmiles(record["smiles"])
        if mol is None:
            failures.append(_failure_from_record(record, "gem_mol_from_smiles_failed"))
            continue
        data = mol_to_geognn_graph_data_MMFF3d(mol)
        if data is None:
            failures.append(_failure_from_record(record, "gem_graph_build_failed"))
            continue
        graph_data_list.append(data)
        graph_records.append(record)

    if not graph_data_list:
        raise ValueError("No valid molecules remained after GEM graph conversion.")

    encoder_config = read_encoder_config(encoder_config_path)
    compound_encoder = GeoGNNModel(encoder_config)
    load_encoder_state_dict(compound_encoder, checkpoint_path, paddle)
    compound_encoder.eval()

    collate_fn = build_inference_collate_fn(
        atom_names=encoder_config["atom_names"],
        bond_names=encoder_config["bond_names"],
        bond_float_names=encoder_config["bond_float_names"],
        bond_angle_float_names=encoder_config["bond_angle_float_names"],
        pgl_module=pgl,
    )
    dataset = InMemoryDataset(data_list=graph_data_list)
    data_loader = dataset.get_data_loader(
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        shuffle=False,
        collate_fn=collate_fn,
    )

    chunks: List[np.ndarray] = []
    with paddle.no_grad():
        for atom_bond_graph, bond_angle_graph in data_loader:
            atom_bond_graph = atom_bond_graph.tensor()
            bond_angle_graph = bond_angle_graph.tensor()
            _, _, graph_repr = compound_encoder(atom_bond_graph, bond_angle_graph)
            chunks.append(np.asarray(graph_repr.numpy(), dtype="float32"))

    embeddings = np.concatenate(chunks, axis=0) if chunks else np.empty((0, 0), dtype="float32")
    if args.normalize:
        embeddings = _l2_normalize(embeddings).astype("float32", copy=False)

    np.save(npy_path, embeddings)
    write_mapping_csv(map_path, graph_records)

    if failures:
        write_failures_csv(failures_path, failures)
    elif failures_path.exists():
        failures_path.unlink()

    print("Repo root: %s" % repo_root)
    print("Encoder config: %s" % encoder_config_path)
    print("Checkpoint: %s" % checkpoint_path)
    print("Input file: %s" % input_path)
    print("Output embeddings: %s" % npy_path)
    print("Output mapping: %s" % map_path)
    if failures:
        print("Output failures: %s" % failures_path)
    print("Valid molecules: %d" % len(graph_records))
    print("Filtered molecules: %d" % len(failures))
    print("Embeddings shape: %s" % (embeddings.shape,))
    print("Model source: %s (local_files_only=True)" % checkpoint_path)


if __name__ == "__main__":
    main()
