from __future__ import annotations

import argparse
import csv
import glob
import importlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from typing import Any, Dict, List, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader
from torch_geometric.nn import global_mean_pool

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)

SCRIPT_DIR = Path(__file__).resolve().parent
REPO_DIR = SCRIPT_DIR / ".repo" / "GRAPHFP"
MOL_DIR = REPO_DIR / "mol"
PREPROCESS_SCRIPT = MOL_DIR / "prepare_data_old.py"
VOCAB_FILE = MOL_DIR / "vocab.txt"


def _resolve_device(device_arg: str) -> torch.device:
    normalized = str(device_arg).strip().lower()
    if normalized == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if normalized not in {"cpu", "cuda"}:
        raise ValueError("Unsupported device: %s" % device_arg)
    if normalized == "cuda" and not torch.cuda.is_available():
        print("CUDA requested but unavailable; falling back to CPU.", file=sys.stderr)
        return torch.device("cpu")
    return torch.device(normalized)


def _resolve_variant(variant: str) -> str:
    normalized = str(variant).strip().lower()
    allowed = {"gin_c", "gin_cp", "gin_cpf"}
    if normalized not in allowed:
        raise ValueError("Unsupported GraphFP variant '%s'." % variant)
    return normalized


def _choose_checkpoint(variant: str) -> Path:
    pretrain_dir = MOL_DIR / "pretrain"
    if not pretrain_dir.exists():
        raise FileNotFoundError("GraphFP pretrain directory not found: %s" % pretrain_dir)

    if variant == "gin_c":
        path = pretrain_dir / "GIN_C.pth"
        if path.exists():
            return path
        raise FileNotFoundError("Requested GIN_C checkpoint not found: %s" % path)

    if variant == "gin_cpf":
        exact = pretrain_dir / "GIN_CPF_01.pth"
        if exact.exists():
            return exact
        matches = sorted(glob.glob(str(pretrain_dir / "GIN_CPF*.pth")))
        if matches:
            return Path(matches[-1]).resolve()
        raise FileNotFoundError("Requested GIN_CPF checkpoint not found in %s" % pretrain_dir)

    exact = pretrain_dir / "GIN_CP_03.pth"
    if exact.exists():
        return exact
    matches = sorted(glob.glob(str(pretrain_dir / "GIN_CP*.pth")))
    if matches:
        return Path(matches[-1]).resolve()
    raise FileNotFoundError("Requested GIN_CP checkpoint not found in %s" % pretrain_dir)


def _import_graphfp_components() -> Tuple[Any, Any, Any]:
    if not MOL_DIR.exists():
        raise FileNotFoundError("GraphFP mol directory not found at %s" % MOL_DIR)

    mol_dir_str = str(MOL_DIR)
    if mol_dir_str not in sys.path:
        sys.path.insert(0, mol_dir_str)

    old_cwd = os.getcwd()
    try:
        os.chdir(mol_dir_str)
        train_mod = importlib.import_module("downstream_old")
        prep_mod = importlib.import_module("prepare_data_old")
    finally:
        os.chdir(old_cwd)

    return train_mod.GIN, prep_mod.MoleculePretrainDataset, prep_mod.mol_frag_collate


def _run_preprocess(temp_csv: Path, processed_root: Path) -> None:
    if not PREPROCESS_SCRIPT.exists():
        raise FileNotFoundError("prepare_data_old.py not found at %s" % PREPROCESS_SCRIPT)
    if not VOCAB_FILE.exists():
        raise FileNotFoundError("vocab.txt not found at %s" % VOCAB_FILE)

    processed_root.mkdir(parents=True, exist_ok=True)
    cmd = [
        sys.executable,
        str(PREPROCESS_SCRIPT),
        "--root",
        str(processed_root),
        "--data_file_path",
        str(temp_csv),
        "--smiles_column",
        "smiles",
        "--vocab_file_path",
        str(VOCAB_FILE),
    ]
    subprocess.run(cmd, cwd=str(MOL_DIR), check=True)


def _write_smiles_csv(path: Path, smiles: List[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["smiles"])
        for value in smiles:
            writer.writerow([value])


def _load_encoders(checkpoint_path: Path, device: torch.device) -> Tuple[Any, Any, bool]:
    GNN, _, _ = _import_graphfp_components()

    mol_encoder = GNN(num_layer=5, emb_dim=300, drop_ratio=0, atom=True)
    frag_encoder = GNN(num_layer=2, emb_dim=300, drop_ratio=0, atom=False)
    frag_encoder.embedding = torch.nn.Embedding(908, 300)

    checkpoint_data = torch.load(str(checkpoint_path), map_location="cpu")
    if not isinstance(checkpoint_data, dict):
        raise ValueError("Unexpected checkpoint format: %s" % checkpoint_path)

    use_frag_encoder = False
    if "mol_gnn" in checkpoint_data and "frag_gnn" in checkpoint_data:
        mol_encoder.load_state_dict(checkpoint_data["mol_gnn"])
        frag_encoder.load_state_dict(checkpoint_data["frag_gnn"])
        use_frag_encoder = True
    elif "gnn" in checkpoint_data:
        mol_encoder.load_state_dict(checkpoint_data["gnn"])
    else:
        raise KeyError(
            "Unsupported checkpoint keys %s for %s"
            % (list(checkpoint_data.keys()), checkpoint_path)
        )

    mol_encoder = mol_encoder.to(device).eval()
    frag_encoder = frag_encoder.to(device).eval()
    return mol_encoder, frag_encoder, use_frag_encoder


def _compute_embeddings(
    processed_root: Path,
    checkpoint_path: Path,
    fusion: str,
    batch_size: int,
    device: torch.device,
    normalize: bool,
) -> np.ndarray:
    _, MoleculePretrainDataset, mol_frag_collate = _import_graphfp_components()

    dataset = MoleculePretrainDataset(root=str(processed_root))
    if len(dataset) == 0:
        return np.empty((0, 0), dtype=np.float32)

    loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, collate_fn=mol_frag_collate)

    mol_encoder, frag_encoder, use_frag_encoder = _load_encoders(checkpoint_path, device)

    chunks: List[np.ndarray] = []
    with torch.no_grad():
        for batch in loader:
            batch = batch.to(device)

            mol_node_repr = mol_encoder(batch.x, batch.edge_index, batch.edge_attr)
            mol_emb = global_mean_pool(mol_node_repr, batch.node_batch)

            if use_frag_encoder:
                frag_node_repr = frag_encoder(batch.frag.squeeze(-1), batch.frag_edge_index, None)
                frag_emb = global_mean_pool(frag_node_repr, batch.frag_batch)
            else:
                frag_emb = torch.zeros_like(mol_emb)

            if fusion == "concat":
                fused = torch.cat([mol_emb, frag_emb], dim=-1)
            else:
                fused = (mol_emb + frag_emb) / 2.0

            if normalize:
                fused = torch.nn.functional.normalize(fused, dim=-1)

            chunks.append(fused.detach().cpu().numpy().astype(np.float32, copy=False))

    if not chunks:
        return np.empty((0, 0), dtype=np.float32)
    return np.concatenate(chunks, axis=0)


def _failure_from_record(record: Dict[str, Any], reason: str) -> Dict[str, Any]:
    failure = {
        "original_line": str(record.get("original_line", "")),
        "input_text": record.get("input_text", ""),
        "reason": reason,
    }
    if "source_type" in record:
        failure["source_type"] = record.get("source_type")
    if "source_header" in record:
        failure["source_header"] = record.get("source_header")
    if "source_row" in record:
        failure["source_row"] = record.get("source_row")
    return failure


def main() -> None:
    parser = argparse.ArgumentParser(description="Encode molecules with GraphFP and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--variant",
        default="gin_cp",
        choices=["gin_c", "gin_cp", "gin_cpf"],
        help="GraphFP checkpoint variant",
    )
    parser.add_argument(
        "--fusion",
        default="concat",
        choices=["concat", "avg"],
        help="How to merge molecular and fragment encoders",
    )
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument(
        "--device",
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help="Inference device",
    )
    parser.add_argument(
        "--normalize",
        action="store_true",
        help="Apply L2 normalization to embeddings",
    )
    args = parser.parse_args()

    variant = _resolve_variant(args.variant)
    device = _resolve_device(args.device)

    input_path = Path(args.file).resolve()
    output_dir = Path(args.output_dir).resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    lines = load_input_lines(input_path)
    records, failures = preprocess_lines(
        lines,
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )

    if not records:
        np.save(str(npy_path), np.empty((0, 0), dtype=np.float32))
        write_mapping_csv(map_path, [])
        write_failures_csv(failures_path, failures)
        print("No valid molecules after preprocessing. Saved empty outputs.", file=sys.stderr)
        return

    smiles_values = [record["smiles"] for record in records]
    checkpoint_path = _choose_checkpoint(variant)

    with tempfile.TemporaryDirectory(prefix="graphfp_pre_", dir=str(output_dir)) as temp_dir:
        temp_root = Path(temp_dir)
        temp_csv = temp_root / "graphfp_input.csv"
        processed_root = temp_root / "processed"
        _write_smiles_csv(temp_csv, smiles_values)
        _run_preprocess(temp_csv=temp_csv, processed_root=processed_root)
        embeddings = _compute_embeddings(
            processed_root=processed_root,
            checkpoint_path=checkpoint_path,
            fusion=args.fusion,
            batch_size=max(1, int(args.batch_size)),
            device=device,
            normalize=bool(args.normalize),
        )

    if embeddings.shape[0] > len(records):
        raise RuntimeError(
            "GraphFP returned more embeddings than input records: %d > %d"
            % (embeddings.shape[0], len(records))
        )

    kept_records = list(records)
    if embeddings.shape[0] < len(records):
        kept_records = records[: embeddings.shape[0]]
        for record in records[embeddings.shape[0] :]:
            failures.append(_failure_from_record(record, "graphfp_missing_after_preprocess"))

    np.save(str(npy_path), embeddings)
    write_mapping_csv(map_path, kept_records)
    write_failures_csv(failures_path, failures)

    print("Saved embeddings to %s with shape %s." % (npy_path, embeddings.shape))
    print("Saved row mapping to %s." % map_path)
    if failures:
        print("Saved %d failed rows to %s." % (len(failures), failures_path))
    print("Model source: %s (variant=%s)" % (checkpoint_path, variant))


if __name__ == "__main__":
    main()
