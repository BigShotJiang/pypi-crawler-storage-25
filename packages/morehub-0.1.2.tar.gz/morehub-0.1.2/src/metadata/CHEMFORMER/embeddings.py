#!/usr/bin/env python
"""Generate ChemFormer embeddings under MoreHub CLI-v2 protocol."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch

from importlib.abc import Loader, MetaPathFinder
from importlib.machinery import ModuleSpec

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


class _DeepspeedShimLoader(Loader):
    """Provide placeholder objects for checkpoints that reference DeepSpeed."""

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        module.__dict__.setdefault("__path__", [])
        module.__dict__.setdefault("__all__", [])
        module.__dict__.setdefault("__version__", "0.0-shim")

        def __getattr__(name):
            placeholder = type(
                name,
                (),
                {
                    "__module__": module.__name__,
                    "__init__": lambda self, *args, **kwargs: None,
                    "__repr__": lambda self: "<%s.%s shim>" % (module.__name__, name),
                },
            )
            setattr(module, name, placeholder)
            return placeholder

        module.__getattr__ = __getattr__


class _DeepspeedShimFinder(MetaPathFinder):
    """Intercept DeepSpeed imports so old checkpoints can be loaded."""

    def find_spec(self, fullname, path, target=None):
        if fullname == "deepspeed" or fullname.startswith("deepspeed."):
            return ModuleSpec(fullname, _DeepspeedShimLoader(), is_package=True)
        return None


if not any(isinstance(finder, _DeepspeedShimFinder) for finder in sys.meta_path):
    sys.meta_path.insert(0, _DeepspeedShimFinder())


try:
    from molbart.models.transformer_models import BARTModel
    from molbart.utils.tokenizers import ChemformerTokenizer
except Exception as exc:
    raise ImportError(
        "Could not import ChemFormer modules from molbart. Ensure editable install completed successfully."
    ) from exc


VARIANT_TO_SUBDIR: Dict[str, Tuple[str, ...]] = {
    "pretrained/combined-large": ("pre-trained", "combined-large"),
    "pretrained/combined": ("pre-trained", "combined"),
    "pretrained/augment": ("pre-trained", "augment"),
    "pretrained/mask": ("pre-trained", "mask"),
    "finetuned/uspto_sep": ("fined-tuned", "uspto_sep"),
    "finetuned/uspto_mixed": ("fined-tuned", "uspto_mixed"),
    "finetuned/uspto_50": ("fined-tuned", "uspto_50"),
    "randinit/uspto_sep": ("rand_init_downstream", "uspto_sep"),
    "randinit/uspto_50": ("rand_init_downstream", "uspto_50"),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Encode molecules with ChemFormer and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file (.txt or .csv)")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")
    parser.add_argument(
        "--variant",
        default="pretrained/combined",
        choices=sorted(VARIANT_TO_SUBDIR.keys()),
        help="ChemFormer checkpoint variant",
    )
    parser.add_argument(
        "--model-root",
        default=None,
        help="Optional checkpoint root override (contains pre-trained/, fined-tuned/, rand_init_downstream/)",
    )
    parser.add_argument("--vocab-path", default=None, help="Optional path to vocabulary JSON")
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])
    parser.add_argument("--normalize", action="store_true", help="Apply L2 normalization")
    return parser.parse_args()


def _resolve_repo_dir(script_dir: Path) -> Path:
    candidates = [
        (script_dir / ".repo" / "Chemformer").resolve(),
        (script_dir / "Chemformer").resolve(),
    ]
    for candidate in candidates:
        if candidate.exists() and candidate.is_dir():
            return candidate
    raise FileNotFoundError(
        "ChemFormer repository directory not found. Expected one of:\n%s"
        % "\n".join(str(path) for path in candidates)
    )


def _resolve_model_root(script_dir: Path, model_root_arg: Optional[str]) -> Path:
    if model_root_arg:
        root = Path(model_root_arg).expanduser().resolve()
    else:
        root = (script_dir / "models" / "models").resolve()
    if not root.exists():
        raise FileNotFoundError(
            "ChemFormer checkpoint root not found at %s. "
            "Place manually downloaded checkpoints under models/CHEMFORMER/models/models."
            % root
        )
    return root


def _resolve_model_dir(model_root: Path, variant: str) -> Path:
    subdir = VARIANT_TO_SUBDIR.get(variant)
    if subdir is None:
        raise ValueError("Unsupported ChemFormer variant: %s" % variant)
    model_dir = model_root.joinpath(*subdir)
    if not model_dir.exists():
        raise FileNotFoundError("ChemFormer variant directory not found: %s" % model_dir)
    return model_dir


def _find_checkpoint_file(model_dir: Path) -> Path:
    checkpoints = sorted(model_dir.glob("*.ckpt"))
    if not checkpoints:
        raise FileNotFoundError("No .ckpt file found in %s" % model_dir)
    if len(checkpoints) > 1:
        print("Warning: multiple checkpoints found in %s. Using %s" % (model_dir, checkpoints[0]))
    return checkpoints[0]


def _maybe_patch_checkpoint(ckpt_path: Path) -> Path:
    patched_path = ckpt_path.with_name("%s_v2%s" % (ckpt_path.stem, ckpt_path.suffix))
    if patched_path.exists():
        return patched_path

    ckpt = torch.load(str(ckpt_path), map_location="cpu")
    if (
        isinstance(ckpt, dict)
        and isinstance(ckpt.get("hyper_parameters"), dict)
        and "vocab_size" in ckpt["hyper_parameters"]
        and "vocabulary_size" not in ckpt["hyper_parameters"]
    ):
        ckpt["hyper_parameters"]["vocabulary_size"] = ckpt["hyper_parameters"].pop("vocab_size")
        torch.save(ckpt, str(patched_path))
        print("Patched checkpoint written to: %s" % patched_path)
        return patched_path
    return ckpt_path


def _variant_uses_downstream_vocab(variant: str) -> bool:
    return variant.startswith("finetuned/") or variant.startswith("randinit/")


def _resolve_vocab_path(repo_dir: Path, variant: str, vocab_path_arg: Optional[str]) -> Path:
    if vocab_path_arg:
        vocab_path = Path(vocab_path_arg).expanduser().resolve()
        if not vocab_path.exists():
            raise FileNotFoundError("Vocabulary file not found: %s" % vocab_path)
        return vocab_path

    default_name = "bart_vocab_downstream.json" if _variant_uses_downstream_vocab(variant) else "bart_vocab.json"
    vocab_path = (repo_dir / default_name).resolve()
    if not vocab_path.exists():
        raise FileNotFoundError("Vocabulary file not found: %s" % vocab_path)
    return vocab_path


def _build_tokenizer(vocab_path: Path):
    try:
        return ChemformerTokenizer(str(vocab_path))
    except TypeError:
        try:
            return ChemformerTokenizer(vocab_path=str(vocab_path))
        except TypeError as exc:
            raise RuntimeError("Could not initialize ChemformerTokenizer with expected signatures") from exc


def _get_pad_token_id(tokenizer) -> int:
    for attr in ["pad_token_idx", "pad_token_id"]:
        if hasattr(tokenizer, attr):
            value = getattr(tokenizer, attr)
            if value is not None:
                return int(value)

    for attr in ["token_to_id", "vocab", "_vocabulary"]:
        if hasattr(tokenizer, attr):
            mapping = getattr(tokenizer, attr)
            if isinstance(mapping, dict):
                for key in ["<PAD>", "[PAD]", "PAD", "<pad>"]:
                    if key in mapping:
                        return int(mapping[key])

    raise RuntimeError("Could not determine pad token id from tokenizer")


def _normalize_token_ids(ids: Any) -> List[int]:
    if isinstance(ids, torch.Tensor):
        return [int(item) for item in ids.reshape(-1).tolist()]

    if hasattr(ids, "tolist") and not isinstance(ids, (list, tuple)):
        ids = ids.tolist()

    if isinstance(ids, (list, tuple)):
        if len(ids) == 1 and isinstance(ids[0], (list, tuple, torch.Tensor)):
            return _normalize_token_ids(ids[0])
        if ids and all(isinstance(item, (int, np.integer)) for item in ids):
            return [int(item) for item in ids]

    return [int(item) for item in ids]


def _encode_smiles_batch(tokenizer, smiles_batch: List[str]) -> Tuple[torch.Tensor, torch.Tensor]:
    if hasattr(tokenizer, "encode"):
        token_id_lists = [_normalize_token_ids(tokenizer.encode(smiles)) for smiles in smiles_batch]
    elif hasattr(tokenizer, "tokenize") and hasattr(tokenizer, "convert_tokens_to_ids"):
        token_id_lists = []
        for smiles in smiles_batch:
            tokens = tokenizer.tokenize(smiles)
            token_ids = tokenizer.convert_tokens_to_ids(tokens)
            token_id_lists.append(_normalize_token_ids(token_ids))
    else:
        raise RuntimeError("Tokenizer does not expose a recognized encode/tokenize API")

    pad_id = _get_pad_token_id(tokenizer)
    max_len = max(len(ids) for ids in token_id_lists)
    batch_size = len(token_id_lists)

    encoder_input = torch.full((max_len, batch_size), pad_id, dtype=torch.long)
    encoder_pad_mask = torch.ones((max_len, batch_size), dtype=torch.bool)

    for col, ids in enumerate(token_id_lists):
        seq_len = len(ids)
        encoder_input[:seq_len, col] = torch.tensor(ids, dtype=torch.long)
        encoder_pad_mask[:seq_len, col] = False

    return encoder_input, encoder_pad_mask


def _masked_mean_pool(memory: torch.Tensor, pad_mask: torch.Tensor) -> torch.Tensor:
    valid_mask = (~pad_mask).unsqueeze(-1).to(memory.dtype)
    masked_memory = memory * valid_mask
    summed = masked_memory.sum(dim=0)
    counts = valid_mask.sum(dim=0).clamp(min=1e-9)
    return summed / counts


@torch.no_grad()
def _extract_embeddings(
    smiles_list: List[str],
    model: Any,
    tokenizer: Any,
    device: torch.device,
    batch_size: int,
) -> np.ndarray:
    chunks: List[np.ndarray] = []

    for start in range(0, len(smiles_list), batch_size):
        batch_smiles = smiles_list[start : start + batch_size]

        encoder_input, encoder_pad_mask = _encode_smiles_batch(tokenizer, batch_smiles)
        encoder_input = encoder_input.to(device)
        encoder_pad_mask = encoder_pad_mask.to(device)

        memory = model.encode({"encoder_input": encoder_input, "encoder_pad_mask": encoder_pad_mask})
        pooled = _masked_mean_pool(memory, encoder_pad_mask)
        chunks.append(np.asarray(pooled.detach().cpu().tolist(), dtype=np.float32))

    if not chunks:
        return np.empty((0, 0), dtype=np.float32)
    return np.vstack(chunks)


def _l2_normalize(vectors: np.ndarray) -> np.ndarray:
    if vectors.size == 0:
        return vectors
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    norms[norms == 0.0] = 1.0
    return (vectors / norms).astype(np.float32, copy=False)


def main() -> None:
    args = parse_args()

    script_dir = Path(__file__).resolve().parent
    repo_dir = _resolve_repo_dir(script_dir)
    model_root = _resolve_model_root(script_dir, args.model_root)
    variant_dir = _resolve_model_dir(model_root, args.variant)
    ckpt_path = _maybe_patch_checkpoint(_find_checkpoint_file(variant_dir))
    vocab_path = _resolve_vocab_path(repo_dir, args.variant, args.vocab_path)

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    input_path = Path(args.file).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError("Input file not found: %s" % input_path)

    output_dir = Path(args.output_dir).expanduser().resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    records, failures = preprocess_lines(
        lines=load_input_lines(input_path),
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )
    if not records:
        raise ValueError("No valid molecules remained after preprocessing")

    tokenizer = _build_tokenizer(vocab_path)
    model = BARTModel.load_from_checkpoint(str(ckpt_path), decode_sampler=None, map_location=device)
    model.to(device)
    model.eval()

    smiles_list = [str(record["model_input"]) for record in records]
    embeddings = _extract_embeddings(
        smiles_list=smiles_list,
        model=model,
        tokenizer=tokenizer,
        device=device,
        batch_size=max(1, int(args.batch_size)),
    )

    if args.normalize:
        embeddings = _l2_normalize(embeddings)

    np.save(str(npy_path), embeddings)
    write_mapping_csv(map_path, records)

    if failures:
        write_failures_csv(failures_path, failures)
    elif failures_path.exists():
        failures_path.unlink()

    print("Saved embeddings to %s with shape %s." % (npy_path, embeddings.shape))
    print("variant=%s" % args.variant)
    print("checkpoint=%s" % ckpt_path)
    print("vocabulary=%s" % vocab_path)


if __name__ == "__main__":
    main()
