#!/usr/bin/env python
"""Generate SimSon embeddings under MoreHub CLI-v2 protocol."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
from tokenizers import Tokenizer

from embeddings_preprocess import (
    load_input_lines,
    preprocess_lines,
    resolve_output_paths,
    write_failures_csv,
    write_mapping_csv,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Encode molecules with SimSon and save embeddings")
    parser.add_argument("--file", required=True, help="Path to input file (.txt or .csv)")
    parser.add_argument(
        "--input-format",
        default="selfies",
        choices=["selfies", "smiles"],
        help="Format of rows in input file",
    )
    parser.add_argument(
        "--model-input-type",
        default="smiles",
        choices=["selfies", "smiles"],
        help="Expected model input type from metadata",
    )
    parser.add_argument("--output-dir", default=".", help="Directory to write outputs")
    parser.add_argument("--output-stem", default="embeddings", help="Base output filename stem")

    parser.add_argument("--repo-root", default=None, help="Optional path to cloned SimSon repository")
    parser.add_argument(
        "--checkpoint",
        default=None,
        help="Optional path to pretrained checkpoint file",
    )
    parser.add_argument(
        "--tokenizer",
        default=None,
        help="Optional path to tokenizer JSON file",
    )
    parser.add_argument("--batch-size", type=int, default=128)
    parser.add_argument("--device", default="auto", choices=["auto", "cpu", "cuda"])

    embedding_group = parser.add_mutually_exclusive_group()
    embedding_group.add_argument(
        "--use-projected",
        dest="embedding_type",
        action="store_const",
        const="projected",
        help="Use projected embeddings (linear output)",
    )
    embedding_group.add_argument(
        "--use-pooled",
        dest="embedding_type",
        action="store_const",
        const="pooled",
        help="Use pooled embeddings (encoder pooled output)",
    )
    parser.set_defaults(embedding_type="projected")

    return parser.parse_args()


def resolve_repo_root(repo_root_arg: Optional[str], script_dir: Path) -> Path:
    if repo_root_arg:
        repo_root = Path(repo_root_arg).expanduser().resolve()
        if not repo_root.exists():
            raise FileNotFoundError("Repo root not found: %s" % repo_root)
        return repo_root

    repo_root = (script_dir / ".repo" / "SimSon").resolve()
    if not repo_root.exists():
        raise FileNotFoundError("SimSon repository not found: %s" % repo_root)
    return repo_root


def resolve_checkpoint_path(checkpoint_arg: Optional[str], script_dir: Path) -> Path:
    if checkpoint_arg:
        path = Path(checkpoint_arg).expanduser().resolve()
    else:
        path = (script_dir / ".cache" / "pretrained_best_model.pth").resolve()
    if not path.exists():
        raise FileNotFoundError("Checkpoint not found: %s" % path)
    return path


def resolve_tokenizer_path(tokenizer_arg: Optional[str], script_dir: Path) -> Path:
    if tokenizer_arg:
        path = Path(tokenizer_arg).expanduser().resolve()
    else:
        path = (script_dir / ".cache" / "pubchem_part_tokenizer.json").resolve()
    if not path.exists():
        raise FileNotFoundError("Tokenizer not found: %s" % path)
    return path


def load_simson_components(repo_root: Path) -> Tuple[Any, Any, Any]:
    repo_root_str = str(repo_root)
    if repo_root_str not in sys.path:
        sys.path.insert(0, repo_root_str)

    try:
        from SimSon.config import get_Config  # type: ignore
        from SimSon.model import Xtransformer_Encoder, global_ap  # type: ignore
        return get_Config, Xtransformer_Encoder, global_ap
    except ImportError:
        package_dir = repo_root / "SimSon"
        package_dir_str = str(package_dir)
        if package_dir_str not in sys.path:
            sys.path.insert(0, package_dir_str)
        from config import get_Config  # type: ignore
        from model import Xtransformer_Encoder, global_ap  # type: ignore
        return get_Config, Xtransformer_Encoder, global_ap


def load_simson_config(get_config_fn: Any) -> Any:
    old_argv = sys.argv[:]
    sys.argv = [old_argv[0]]
    try:
        return get_config_fn()
    finally:
        sys.argv = old_argv


def _failure_from_record(record: Dict[str, Any], reason: str) -> Dict[str, Any]:
    failure = {
        "original_line": str(record.get("original_line", "")),
        "input_text": record.get("input_text", ""),
        "reason": reason,
    }
    if "source_type" in record:
        failure["source_type"] = record.get("source_type")
    if "source_header" in record:
        failure["source_header"] = record.get("source_header")
    if "source_row" in record:
        failure["source_row"] = record.get("source_row")
    return failure


def tokenize_records(
    records: List[Dict[str, Any]],
    tokenizer_path: Path,
    max_len: int,
) -> Tuple[torch.Tensor, List[Dict[str, Any]], List[Dict[str, Any]]]:
    tokenizer = Tokenizer.from_file(str(tokenizer_path))

    token_ids: List[List[int]] = []
    valid_records: List[Dict[str, Any]] = []
    failures: List[Dict[str, Any]] = []

    for record in records:
        smiles = str(record.get("smiles", "")).strip()
        if not smiles:
            failures.append(_failure_from_record(record, "empty_smiles"))
            continue

        try:
            enc = tokenizer.encode(smiles)
            ids = list(enc.ids)
        except Exception:
            failures.append(_failure_from_record(record, "tokenization_failed"))
            continue

        if len(ids) > max_len:
            ids = ids[:max_len]
        elif len(ids) < max_len:
            ids = ids + [0] * (max_len - len(ids))

        token_ids.append(ids)
        valid_records.append(record)

    if not token_ids:
        raise ValueError("No valid molecules were tokenized.")

    tokens = torch.tensor(token_ids, dtype=torch.long)
    return tokens, valid_records, failures


def load_encoder(
    simson_args: Any,
    checkpoint_path: Path,
    device: torch.device,
    encoder_cls: Any,
) -> Any:
    model = encoder_cls(simson_args).to(device)
    state = torch.load(str(checkpoint_path), map_location=device)
    if isinstance(state, dict):
        if "state_dict" in state:
            state = state["state_dict"]
        elif "model_state_dict" in state:
            state = state["model_state_dict"]
    model.load_state_dict(state)
    model.eval()
    return model


@torch.no_grad()
def extract_embeddings(
    model: Any,
    tokens: torch.Tensor,
    device: torch.device,
    batch_size: int,
    global_ap_fn: Any,
) -> Tuple[np.ndarray, np.ndarray]:
    pooled_all: List[torch.Tensor] = []
    projected_all: List[torch.Tensor] = []

    for start in range(0, len(tokens), batch_size):
        batch = tokens[start : start + batch_size].to(device)
        mask = batch.gt(0).bool()

        seq = model.encoder(batch, mask=mask)
        pooled = global_ap_fn(seq)
        projected = model.linear(pooled)

        pooled_all.append(pooled.cpu())
        projected_all.append(projected.cpu())

    pooled = torch.cat(pooled_all, dim=0).numpy().astype(np.float32, copy=False)
    projected = torch.cat(projected_all, dim=0).numpy().astype(np.float32, copy=False)
    return pooled, projected


def main() -> None:
    args = parse_args()

    input_path = Path(args.file).expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError("Input file not found: %s" % input_path)

    output_dir = Path(args.output_dir).expanduser().resolve()
    npy_path, map_path, failures_path = resolve_output_paths(output_dir, args.output_stem)

    script_dir = Path(__file__).resolve().parent
    repo_root = resolve_repo_root(args.repo_root, script_dir)
    checkpoint_path = resolve_checkpoint_path(args.checkpoint, script_dir)
    tokenizer_path = resolve_tokenizer_path(args.tokenizer, script_dir)

    get_config, encoder_cls, global_ap_fn = load_simson_components(repo_root)
    simson_args = load_simson_config(get_config)

    max_len = int(getattr(simson_args, "max_len", 128))

    lines = load_input_lines(input_path)
    records, failures = preprocess_lines(
        lines=lines,
        input_format=args.input_format,
        model_input_type=args.model_input_type,
    )
    if not records:
        raise ValueError("No valid molecules remained after preprocessing.")

    tokens, valid_records, token_failures = tokenize_records(
        records=records,
        tokenizer_path=tokenizer_path,
        max_len=max_len,
    )
    failures.extend(token_failures)

    if args.device == "auto":
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    else:
        device = torch.device(args.device)

    model = load_encoder(
        simson_args=simson_args,
        checkpoint_path=checkpoint_path,
        device=device,
        encoder_cls=encoder_cls,
    )

    pooled, projected = extract_embeddings(
        model=model,
        tokens=tokens,
        device=device,
        batch_size=args.batch_size,
        global_ap_fn=global_ap_fn,
    )

    embeddings = projected if args.embedding_type == "projected" else pooled

    np.save(npy_path, embeddings)
    write_mapping_csv(map_path, valid_records)

    if failures:
        write_failures_csv(failures_path, failures)
    elif failures_path.exists():
        failures_path.unlink()

    print("Saved NumPy embeddings to: %s" % npy_path)
    print("embedding_type=%s" % args.embedding_type)
    print("n_samples=%d" % len(valid_records))
    print("embedding_shape=%s" % (embeddings.shape,))
    print("Repository source: %s" % repo_root)
    print("Checkpoint source: %s" % checkpoint_path)
    print("Tokenizer source: %s" % tokenizer_path)


if __name__ == "__main__":
    main()
