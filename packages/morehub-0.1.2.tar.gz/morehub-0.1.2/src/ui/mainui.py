# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainui.ui'
##
## Created by: Qt User Interface Compiler version 6.10.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QAction, QBrush, QColor, QConicalGradient,
    QCursor, QFont, QFontDatabase, QGradient,
    QIcon, QImage, QKeySequence, QLinearGradient,
    QPainter, QPalette, QPixmap, QRadialGradient,
    QTransform)
from PySide6.QtWidgets import (QApplication, QCheckBox, QFrame, QHBoxLayout,
    QLabel, QMainWindow, QMenu, QMenuBar,
    QPushButton, QRadioButton, QSizePolicy, QStatusBar,
    QTabWidget, QTextEdit, QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1181, 834)
        self.actionNew = QAction(MainWindow)
        self.actionNew.setObjectName(u"actionNew")
        self.actionLoad = QAction(MainWindow)
        self.actionLoad.setObjectName(u"actionLoad")
        self.actionGP_Regression = QAction(MainWindow)
        self.actionGP_Regression.setObjectName(u"actionGP_Regression")
        self.actionNew_Data_Setup = QAction(MainWindow)
        self.actionNew_Data_Setup.setObjectName(u"actionNew_Data_Setup")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.tabWidget = QTabWidget(self.centralwidget)
        self.tabWidget.setObjectName(u"tabWidget")
        font = QFont()
        font.setFamilies([u"Nirmala UI"])
        font.setPointSize(12)
        font.setBold(True)
        font.setStrikeOut(False)
        self.tabWidget.setFont(font)
        self.tabWidget.setStyleSheet(u"background-color: rgb(170, 170, 170);")
        self.tabWidget.setTabPosition(QTabWidget.TabPosition.North)
        self.tabWidget.setTabShape(QTabWidget.TabShape.Rounded)
        self.tabWidget.setIconSize(QSize(16, 16))
        self.tabWidget.setElideMode(Qt.TextElideMode.ElideNone)
        self.tabWidget.setUsesScrollButtons(True)
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.verticalLayout_11 = QVBoxLayout(self.tab)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.frame_12 = QFrame(self.tab)
        self.frame_12.setObjectName(u"frame_12")
        sizePolicy = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_12.sizePolicy().hasHeightForWidth())
        self.frame_12.setSizePolicy(sizePolicy)
        self.frame_12.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_12.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_6 = QHBoxLayout(self.frame_12)
        self.horizontalLayout_6.setObjectName(u"horizontalLayout_6")
        self.frame_11 = QFrame(self.frame_12)
        self.frame_11.setObjectName(u"frame_11")
        sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy1.setHorizontalStretch(1)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame_11.sizePolicy().hasHeightForWidth())
        self.frame_11.setSizePolicy(sizePolicy1)
        self.frame_11.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_11.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_10 = QVBoxLayout(self.frame_11)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.frame = QFrame(self.frame_11)
        self.frame.setObjectName(u"frame")
        self.frame.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.frame)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.frame_27 = QFrame(self.frame)
        self.frame_27.setObjectName(u"frame_27")
        self.frame_27.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_27.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_17 = QHBoxLayout(self.frame_27)
        self.horizontalLayout_17.setObjectName(u"horizontalLayout_17")
        self.label_19 = QLabel(self.frame_27)
        self.label_19.setObjectName(u"label_19")
        font1 = QFont()
        font1.setFamilies([u"Oswald"])
        font1.setPointSize(15)
        font1.setBold(False)
        self.label_19.setFont(font1)
        self.label_19.setTextFormat(Qt.TextFormat.PlainText)
        self.label_19.setScaledContents(False)

        self.horizontalLayout_17.addWidget(self.label_19)

        self.label = QLabel(self.frame_27)
        self.label.setObjectName(u"label")
        font2 = QFont()
        font2.setFamilies([u"Oswald"])
        font2.setPointSize(10)
        self.label.setFont(font2)

        self.horizontalLayout_17.addWidget(self.label)


        self.verticalLayout_3.addWidget(self.frame_27)

        self.widget = QWidget(self.frame)
        self.widget.setObjectName(u"widget")
        sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Preferred)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(1)
        sizePolicy2.setHeightForWidth(self.widget.sizePolicy().hasHeightForWidth())
        self.widget.setSizePolicy(sizePolicy2)
        self.horizontalLayout = QHBoxLayout(self.widget)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.pushButton = QPushButton(self.widget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setMinimumSize(QSize(46, 46))
        self.pushButton.setMaximumSize(QSize(60, 16777215))
        icon = QIcon()
        icon.addFile(u"icons/folder.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton.setIcon(icon)
        self.pushButton.setIconSize(QSize(30, 30))

        self.horizontalLayout.addWidget(self.pushButton)

        self.label_2 = QLabel(self.widget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setMinimumSize(QSize(2, 33))
        self.label_2.setMaximumSize(QSize(16777215, 33))
        self.label_2.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout.addWidget(self.label_2)


        self.verticalLayout_3.addWidget(self.widget)


        self.verticalLayout_10.addWidget(self.frame)

        self.frame_10 = QFrame(self.frame_11)
        self.frame_10.setObjectName(u"frame_10")
        self.frame_10.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_10.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_5 = QHBoxLayout(self.frame_10)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.frame_2 = QFrame(self.frame_10)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_2.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.frame_2)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.label_3 = QLabel(self.frame_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setFont(font2)

        self.verticalLayout_5.addWidget(self.label_3, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_2 = QWidget(self.frame_2)
        self.widget_2.setObjectName(u"widget_2")
        sizePolicy2.setHeightForWidth(self.widget_2.sizePolicy().hasHeightForWidth())
        self.widget_2.setSizePolicy(sizePolicy2)
        self.widget_2.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_4 = QVBoxLayout(self.widget_2)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.radioButton = QRadioButton(self.widget_2)
        self.radioButton.setObjectName(u"radioButton")
        font3 = QFont()
        font3.setFamilies([u"Oswald"])
        self.radioButton.setFont(font3)

        self.verticalLayout_4.addWidget(self.radioButton)

        self.radioButton_2 = QRadioButton(self.widget_2)
        self.radioButton_2.setObjectName(u"radioButton_2")
        self.radioButton_2.setFont(font3)

        self.verticalLayout_4.addWidget(self.radioButton_2)


        self.verticalLayout_5.addWidget(self.widget_2)


        self.horizontalLayout_5.addWidget(self.frame_2)

        self.frame_5 = QFrame(self.frame_10)
        self.frame_5.setObjectName(u"frame_5")
        sizePolicy1.setHeightForWidth(self.frame_5.sizePolicy().hasHeightForWidth())
        self.frame_5.setSizePolicy(sizePolicy1)
        self.frame_5.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_5.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.frame_5)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.frame_3 = QFrame(self.frame_5)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_3.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_3.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_3)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.model_installed = QCheckBox(self.frame_3)
        self.model_installed.setObjectName(u"model_installed")
        self.model_installed.setEnabled(False)
        font4 = QFont()
        font4.setFamilies([u"Oswald"])
        font4.setPointSize(9)
        self.model_installed.setFont(font4)
        self.model_installed.setAutoFillBackground(False)
        self.model_installed.setIconSize(QSize(30, 30))
        self.model_installed.setCheckable(False)
        self.model_installed.setTristate(False)

        self.horizontalLayout_2.addWidget(self.model_installed)


        self.verticalLayout_7.addWidget(self.frame_3)

        self.frame_6 = QFrame(self.frame_5)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_6.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_6.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_6)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.checkpoints_downloaded = QCheckBox(self.frame_6)
        self.checkpoints_downloaded.setObjectName(u"checkpoints_downloaded")
        self.checkpoints_downloaded.setEnabled(False)
        self.checkpoints_downloaded.setFont(font4)
        self.checkpoints_downloaded.setAutoFillBackground(False)
        self.checkpoints_downloaded.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded.setCheckable(False)
        self.checkpoints_downloaded.setTristate(False)

        self.horizontalLayout_3.addWidget(self.checkpoints_downloaded)


        self.verticalLayout_7.addWidget(self.frame_6)


        self.horizontalLayout_5.addWidget(self.frame_5)


        self.verticalLayout_10.addWidget(self.frame_10)


        self.horizontalLayout_6.addWidget(self.frame_11)

        self.frame_4 = QFrame(self.frame_12)
        self.frame_4.setObjectName(u"frame_4")
        sizePolicy1.setHeightForWidth(self.frame_4.sizePolicy().hasHeightForWidth())
        self.frame_4.setSizePolicy(sizePolicy1)
        self.frame_4.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_4.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.frame_4)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.widget_3 = QWidget(self.frame_4)
        self.widget_3.setObjectName(u"widget_3")
        sizePolicy3 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.widget_3.sizePolicy().hasHeightForWidth())
        self.widget_3.setSizePolicy(sizePolicy3)
        self.widget_3.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_7 = QHBoxLayout(self.widget_3)
        self.horizontalLayout_7.setObjectName(u"horizontalLayout_7")
        self.label_9 = QLabel(self.widget_3)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setFont(font2)

        self.horizontalLayout_7.addWidget(self.label_9)

        self.frame_13 = QFrame(self.widget_3)
        self.frame_13.setObjectName(u"frame_13")
        sizePolicy4 = QSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.frame_13.sizePolicy().hasHeightForWidth())
        self.frame_13.setSizePolicy(sizePolicy4)
        self.frame_13.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_13.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_8 = QHBoxLayout(self.frame_13)
        self.horizontalLayout_8.setObjectName(u"horizontalLayout_8")
        self.label_4 = QLabel(self.frame_13)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setFont(font2)

        self.horizontalLayout_8.addWidget(self.label_4)

        self.pushButton_2 = QPushButton(self.frame_13)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setMinimumSize(QSize(30, 30))
        self.pushButton_2.setMaximumSize(QSize(40, 40))
        icon1 = QIcon()
        icon1.addFile(u"icons/run.png", QSize(), QIcon.Mode.Normal, QIcon.State.Off)
        self.pushButton_2.setIcon(icon1)
        self.pushButton_2.setIconSize(QSize(30, 30))

        self.horizontalLayout_8.addWidget(self.pushButton_2)


        self.horizontalLayout_7.addWidget(self.frame_13)


        self.verticalLayout_6.addWidget(self.widget_3)

        self.textEdit = QTextEdit(self.frame_4)
        self.textEdit.setObjectName(u"textEdit")
        sizePolicy5 = QSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        sizePolicy5.setHorizontalStretch(0)
        sizePolicy5.setVerticalStretch(2)
        sizePolicy5.setHeightForWidth(self.textEdit.sizePolicy().hasHeightForWidth())
        self.textEdit.setSizePolicy(sizePolicy5)
        self.textEdit.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit.setReadOnly(True)

        self.verticalLayout_6.addWidget(self.textEdit)


        self.horizontalLayout_6.addWidget(self.frame_4)


        self.verticalLayout_11.addWidget(self.frame_12)

        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.verticalLayout_20 = QVBoxLayout(self.tab_2)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.frame_14 = QFrame(self.tab_2)
        self.frame_14.setObjectName(u"frame_14")
        sizePolicy.setHeightForWidth(self.frame_14.sizePolicy().hasHeightForWidth())
        self.frame_14.setSizePolicy(sizePolicy)
        self.frame_14.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_14.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_9 = QHBoxLayout(self.frame_14)
        self.horizontalLayout_9.setObjectName(u"horizontalLayout_9")
        self.frame_15 = QFrame(self.frame_14)
        self.frame_15.setObjectName(u"frame_15")
        sizePolicy1.setHeightForWidth(self.frame_15.sizePolicy().hasHeightForWidth())
        self.frame_15.setSizePolicy(sizePolicy1)
        self.frame_15.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_15.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_12 = QVBoxLayout(self.frame_15)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.frame_16 = QFrame(self.frame_15)
        self.frame_16.setObjectName(u"frame_16")
        self.frame_16.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_16.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_16.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_13 = QVBoxLayout(self.frame_16)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.frame_28 = QFrame(self.frame_16)
        self.frame_28.setObjectName(u"frame_28")
        self.frame_28.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_28.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_18 = QHBoxLayout(self.frame_28)
        self.horizontalLayout_18.setObjectName(u"horizontalLayout_18")
        self.label_20 = QLabel(self.frame_28)
        self.label_20.setObjectName(u"label_20")
        font5 = QFont()
        font5.setFamilies([u"Oswald"])
        font5.setPointSize(15)
        self.label_20.setFont(font5)
        self.label_20.setTextFormat(Qt.TextFormat.PlainText)
        self.label_20.setScaledContents(False)

        self.horizontalLayout_18.addWidget(self.label_20)

        self.label_10 = QLabel(self.frame_28)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setFont(font2)

        self.horizontalLayout_18.addWidget(self.label_10)


        self.verticalLayout_13.addWidget(self.frame_28)

        self.widget_4 = QWidget(self.frame_16)
        self.widget_4.setObjectName(u"widget_4")
        sizePolicy2.setHeightForWidth(self.widget_4.sizePolicy().hasHeightForWidth())
        self.widget_4.setSizePolicy(sizePolicy2)
        self.horizontalLayout_10 = QHBoxLayout(self.widget_4)
        self.horizontalLayout_10.setObjectName(u"horizontalLayout_10")
        self.pushButton_3 = QPushButton(self.widget_4)
        self.pushButton_3.setObjectName(u"pushButton_3")
        self.pushButton_3.setMinimumSize(QSize(46, 46))
        self.pushButton_3.setMaximumSize(QSize(60, 16777215))
        self.pushButton_3.setIcon(icon)
        self.pushButton_3.setIconSize(QSize(30, 30))

        self.horizontalLayout_10.addWidget(self.pushButton_3)

        self.label_11 = QLabel(self.widget_4)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setMinimumSize(QSize(2, 33))
        self.label_11.setMaximumSize(QSize(16777215, 33))
        self.label_11.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_10.addWidget(self.label_11)


        self.verticalLayout_13.addWidget(self.widget_4)


        self.verticalLayout_12.addWidget(self.frame_16)

        self.frame_17 = QFrame(self.frame_15)
        self.frame_17.setObjectName(u"frame_17")
        self.frame_17.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_17.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_11 = QHBoxLayout(self.frame_17)
        self.horizontalLayout_11.setObjectName(u"horizontalLayout_11")
        self.frame_18 = QFrame(self.frame_17)
        self.frame_18.setObjectName(u"frame_18")
        self.frame_18.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_18.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_18.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_14 = QVBoxLayout(self.frame_18)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.label_12 = QLabel(self.frame_18)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setFont(font2)

        self.verticalLayout_14.addWidget(self.label_12, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_5 = QWidget(self.frame_18)
        self.widget_5.setObjectName(u"widget_5")
        sizePolicy2.setHeightForWidth(self.widget_5.sizePolicy().hasHeightForWidth())
        self.widget_5.setSizePolicy(sizePolicy2)
        self.widget_5.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_15 = QVBoxLayout(self.widget_5)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.radioButton_3 = QRadioButton(self.widget_5)
        self.radioButton_3.setObjectName(u"radioButton_3")
        self.radioButton_3.setFont(font3)

        self.verticalLayout_15.addWidget(self.radioButton_3)

        self.radioButton_4 = QRadioButton(self.widget_5)
        self.radioButton_4.setObjectName(u"radioButton_4")
        self.radioButton_4.setFont(font3)

        self.verticalLayout_15.addWidget(self.radioButton_4)


        self.verticalLayout_14.addWidget(self.widget_5)


        self.horizontalLayout_11.addWidget(self.frame_18)

        self.frame_19 = QFrame(self.frame_17)
        self.frame_19.setObjectName(u"frame_19")
        sizePolicy1.setHeightForWidth(self.frame_19.sizePolicy().hasHeightForWidth())
        self.frame_19.setSizePolicy(sizePolicy1)
        self.frame_19.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_19.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_16 = QVBoxLayout(self.frame_19)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.frame_20 = QFrame(self.frame_19)
        self.frame_20.setObjectName(u"frame_20")
        self.frame_20.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_20.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_20.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_12 = QHBoxLayout(self.frame_20)
        self.horizontalLayout_12.setObjectName(u"horizontalLayout_12")
        self.model_installed_2 = QCheckBox(self.frame_20)
        self.model_installed_2.setObjectName(u"model_installed_2")
        self.model_installed_2.setEnabled(False)
        self.model_installed_2.setFont(font4)
        self.model_installed_2.setAutoFillBackground(False)
        self.model_installed_2.setIconSize(QSize(30, 30))
        self.model_installed_2.setCheckable(False)
        self.model_installed_2.setTristate(False)

        self.horizontalLayout_12.addWidget(self.model_installed_2)


        self.verticalLayout_16.addWidget(self.frame_20)

        self.frame_21 = QFrame(self.frame_19)
        self.frame_21.setObjectName(u"frame_21")
        self.frame_21.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_21.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_21.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_13 = QHBoxLayout(self.frame_21)
        self.horizontalLayout_13.setObjectName(u"horizontalLayout_13")
        self.checkpoints_downloaded_2 = QCheckBox(self.frame_21)
        self.checkpoints_downloaded_2.setObjectName(u"checkpoints_downloaded_2")
        self.checkpoints_downloaded_2.setEnabled(False)
        self.checkpoints_downloaded_2.setFont(font4)
        self.checkpoints_downloaded_2.setAutoFillBackground(False)
        self.checkpoints_downloaded_2.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_2.setCheckable(False)
        self.checkpoints_downloaded_2.setTristate(False)

        self.horizontalLayout_13.addWidget(self.checkpoints_downloaded_2)


        self.verticalLayout_16.addWidget(self.frame_21)


        self.horizontalLayout_11.addWidget(self.frame_19)


        self.verticalLayout_12.addWidget(self.frame_17)


        self.horizontalLayout_9.addWidget(self.frame_15)

        self.frame_22 = QFrame(self.frame_14)
        self.frame_22.setObjectName(u"frame_22")
        sizePolicy1.setHeightForWidth(self.frame_22.sizePolicy().hasHeightForWidth())
        self.frame_22.setSizePolicy(sizePolicy1)
        self.frame_22.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_22.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_17 = QVBoxLayout(self.frame_22)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.widget_6 = QWidget(self.frame_22)
        self.widget_6.setObjectName(u"widget_6")
        sizePolicy3.setHeightForWidth(self.widget_6.sizePolicy().hasHeightForWidth())
        self.widget_6.setSizePolicy(sizePolicy3)
        self.widget_6.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_14 = QHBoxLayout(self.widget_6)
        self.horizontalLayout_14.setObjectName(u"horizontalLayout_14")
        self.label_13 = QLabel(self.widget_6)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setFont(font2)

        self.horizontalLayout_14.addWidget(self.label_13)

        self.frame_23 = QFrame(self.widget_6)
        self.frame_23.setObjectName(u"frame_23")
        sizePolicy4.setHeightForWidth(self.frame_23.sizePolicy().hasHeightForWidth())
        self.frame_23.setSizePolicy(sizePolicy4)
        self.frame_23.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_23.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_15 = QHBoxLayout(self.frame_23)
        self.horizontalLayout_15.setObjectName(u"horizontalLayout_15")
        self.label_14 = QLabel(self.frame_23)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setFont(font2)

        self.horizontalLayout_15.addWidget(self.label_14)

        self.pushButton_4 = QPushButton(self.frame_23)
        self.pushButton_4.setObjectName(u"pushButton_4")
        self.pushButton_4.setMinimumSize(QSize(30, 30))
        self.pushButton_4.setMaximumSize(QSize(40, 40))
        self.pushButton_4.setIcon(icon1)
        self.pushButton_4.setIconSize(QSize(30, 30))

        self.horizontalLayout_15.addWidget(self.pushButton_4)


        self.horizontalLayout_14.addWidget(self.frame_23)


        self.verticalLayout_17.addWidget(self.widget_6)

        self.textEdit_2 = QTextEdit(self.frame_22)
        self.textEdit_2.setObjectName(u"textEdit_2")
        sizePolicy5.setHeightForWidth(self.textEdit_2.sizePolicy().hasHeightForWidth())
        self.textEdit_2.setSizePolicy(sizePolicy5)
        self.textEdit_2.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_2.setReadOnly(True)

        self.verticalLayout_17.addWidget(self.textEdit_2)


        self.horizontalLayout_9.addWidget(self.frame_22)


        self.verticalLayout_20.addWidget(self.frame_14)

        self.tabWidget.addTab(self.tab_2, "")
        self.tab_3 = QWidget()
        self.tab_3.setObjectName(u"tab_3")
        self.verticalLayout_29 = QVBoxLayout(self.tab_3)
        self.verticalLayout_29.setObjectName(u"verticalLayout_29")
        self.frame_29 = QFrame(self.tab_3)
        self.frame_29.setObjectName(u"frame_29")
        sizePolicy.setHeightForWidth(self.frame_29.sizePolicy().hasHeightForWidth())
        self.frame_29.setSizePolicy(sizePolicy)
        self.frame_29.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_29.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_19 = QHBoxLayout(self.frame_29)
        self.horizontalLayout_19.setObjectName(u"horizontalLayout_19")
        self.frame_30 = QFrame(self.frame_29)
        self.frame_30.setObjectName(u"frame_30")
        sizePolicy1.setHeightForWidth(self.frame_30.sizePolicy().hasHeightForWidth())
        self.frame_30.setSizePolicy(sizePolicy1)
        self.frame_30.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_30.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_21 = QVBoxLayout(self.frame_30)
        self.verticalLayout_21.setObjectName(u"verticalLayout_21")
        self.frame_31 = QFrame(self.frame_30)
        self.frame_31.setObjectName(u"frame_31")
        self.frame_31.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_31.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_31.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_22 = QVBoxLayout(self.frame_31)
        self.verticalLayout_22.setObjectName(u"verticalLayout_22")
        self.frame_32 = QFrame(self.frame_31)
        self.frame_32.setObjectName(u"frame_32")
        self.frame_32.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_32.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_20 = QHBoxLayout(self.frame_32)
        self.horizontalLayout_20.setObjectName(u"horizontalLayout_20")
        self.label_21 = QLabel(self.frame_32)
        self.label_21.setObjectName(u"label_21")
        self.label_21.setFont(font5)
        self.label_21.setTextFormat(Qt.TextFormat.PlainText)
        self.label_21.setScaledContents(False)

        self.horizontalLayout_20.addWidget(self.label_21)

        self.label_22 = QLabel(self.frame_32)
        self.label_22.setObjectName(u"label_22")
        self.label_22.setFont(font2)

        self.horizontalLayout_20.addWidget(self.label_22)


        self.verticalLayout_22.addWidget(self.frame_32)

        self.widget_7 = QWidget(self.frame_31)
        self.widget_7.setObjectName(u"widget_7")
        sizePolicy2.setHeightForWidth(self.widget_7.sizePolicy().hasHeightForWidth())
        self.widget_7.setSizePolicy(sizePolicy2)
        self.horizontalLayout_21 = QHBoxLayout(self.widget_7)
        self.horizontalLayout_21.setObjectName(u"horizontalLayout_21")
        self.pushButton_5 = QPushButton(self.widget_7)
        self.pushButton_5.setObjectName(u"pushButton_5")
        self.pushButton_5.setMinimumSize(QSize(46, 46))
        self.pushButton_5.setMaximumSize(QSize(60, 16777215))
        self.pushButton_5.setIcon(icon)
        self.pushButton_5.setIconSize(QSize(30, 30))

        self.horizontalLayout_21.addWidget(self.pushButton_5)

        self.label_23 = QLabel(self.widget_7)
        self.label_23.setObjectName(u"label_23")
        self.label_23.setMinimumSize(QSize(2, 33))
        self.label_23.setMaximumSize(QSize(16777215, 33))
        self.label_23.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_21.addWidget(self.label_23)


        self.verticalLayout_22.addWidget(self.widget_7)


        self.verticalLayout_21.addWidget(self.frame_31)

        self.frame_33 = QFrame(self.frame_30)
        self.frame_33.setObjectName(u"frame_33")
        self.frame_33.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_33.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_22 = QHBoxLayout(self.frame_33)
        self.horizontalLayout_22.setObjectName(u"horizontalLayout_22")
        self.frame_34 = QFrame(self.frame_33)
        self.frame_34.setObjectName(u"frame_34")
        self.frame_34.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_34.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_34.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_23 = QVBoxLayout(self.frame_34)
        self.verticalLayout_23.setObjectName(u"verticalLayout_23")
        self.label_24 = QLabel(self.frame_34)
        self.label_24.setObjectName(u"label_24")
        self.label_24.setFont(font2)

        self.verticalLayout_23.addWidget(self.label_24, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_8 = QWidget(self.frame_34)
        self.widget_8.setObjectName(u"widget_8")
        sizePolicy2.setHeightForWidth(self.widget_8.sizePolicy().hasHeightForWidth())
        self.widget_8.setSizePolicy(sizePolicy2)
        self.widget_8.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_24 = QVBoxLayout(self.widget_8)
        self.verticalLayout_24.setObjectName(u"verticalLayout_24")
        self.radioButton_5 = QRadioButton(self.widget_8)
        self.radioButton_5.setObjectName(u"radioButton_5")
        self.radioButton_5.setFont(font3)

        self.verticalLayout_24.addWidget(self.radioButton_5)

        self.radioButton_6 = QRadioButton(self.widget_8)
        self.radioButton_6.setObjectName(u"radioButton_6")
        self.radioButton_6.setFont(font3)

        self.verticalLayout_24.addWidget(self.radioButton_6)


        self.verticalLayout_23.addWidget(self.widget_8)


        self.horizontalLayout_22.addWidget(self.frame_34)

        self.frame_35 = QFrame(self.frame_33)
        self.frame_35.setObjectName(u"frame_35")
        sizePolicy1.setHeightForWidth(self.frame_35.sizePolicy().hasHeightForWidth())
        self.frame_35.setSizePolicy(sizePolicy1)
        self.frame_35.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_35.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_25 = QVBoxLayout(self.frame_35)
        self.verticalLayout_25.setObjectName(u"verticalLayout_25")
        self.frame_46 = QFrame(self.frame_35)
        self.frame_46.setObjectName(u"frame_46")
        sizePolicy4.setHeightForWidth(self.frame_46.sizePolicy().hasHeightForWidth())
        self.frame_46.setSizePolicy(sizePolicy4)
        self.frame_46.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_46.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_32 = QVBoxLayout(self.frame_46)
        self.verticalLayout_32.setObjectName(u"verticalLayout_32")
        self.frame_50 = QFrame(self.frame_46)
        self.frame_50.setObjectName(u"frame_50")
        self.frame_50.setStyleSheet(u"")
        self.frame_50.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_50.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_32 = QHBoxLayout(self.frame_50)
        self.horizontalLayout_32.setObjectName(u"horizontalLayout_32")
        self.checkBox_10 = QCheckBox(self.frame_50)
        self.checkBox_10.setObjectName(u"checkBox_10")
        self.checkBox_10.setEnabled(True)
        self.checkBox_10.setFont(font4)
        self.checkBox_10.setAutoFillBackground(False)
        self.checkBox_10.setIconSize(QSize(30, 30))
        self.checkBox_10.setCheckable(True)
        self.checkBox_10.setTristate(False)

        self.horizontalLayout_32.addWidget(self.checkBox_10)


        self.verticalLayout_32.addWidget(self.frame_50)

        self.frame_49 = QFrame(self.frame_46)
        self.frame_49.setObjectName(u"frame_49")
        self.frame_49.setStyleSheet(u"")
        self.frame_49.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_49.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_31 = QHBoxLayout(self.frame_49)
        self.horizontalLayout_31.setObjectName(u"horizontalLayout_31")
        self.checkBox_9 = QCheckBox(self.frame_49)
        self.checkBox_9.setObjectName(u"checkBox_9")
        self.checkBox_9.setEnabled(True)
        self.checkBox_9.setFont(font4)
        self.checkBox_9.setAutoFillBackground(False)
        self.checkBox_9.setIconSize(QSize(30, 30))
        self.checkBox_9.setCheckable(True)
        self.checkBox_9.setTristate(False)

        self.horizontalLayout_31.addWidget(self.checkBox_9)


        self.verticalLayout_32.addWidget(self.frame_49)

        self.frame_48 = QFrame(self.frame_46)
        self.frame_48.setObjectName(u"frame_48")
        self.frame_48.setStyleSheet(u"")
        self.frame_48.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_48.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_29 = QHBoxLayout(self.frame_48)
        self.horizontalLayout_29.setObjectName(u"horizontalLayout_29")
        self.checkBox_8 = QCheckBox(self.frame_48)
        self.checkBox_8.setObjectName(u"checkBox_8")
        self.checkBox_8.setEnabled(True)
        self.checkBox_8.setFont(font4)
        self.checkBox_8.setAutoFillBackground(False)
        self.checkBox_8.setIconSize(QSize(30, 30))
        self.checkBox_8.setCheckable(True)
        self.checkBox_8.setChecked(True)
        self.checkBox_8.setTristate(False)

        self.horizontalLayout_29.addWidget(self.checkBox_8)


        self.verticalLayout_32.addWidget(self.frame_48)


        self.verticalLayout_25.addWidget(self.frame_46, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_36 = QFrame(self.frame_35)
        self.frame_36.setObjectName(u"frame_36")
        self.frame_36.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_36.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_36.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_23 = QHBoxLayout(self.frame_36)
        self.horizontalLayout_23.setObjectName(u"horizontalLayout_23")
        self.model_installed_3 = QCheckBox(self.frame_36)
        self.model_installed_3.setObjectName(u"model_installed_3")
        self.model_installed_3.setEnabled(False)
        self.model_installed_3.setFont(font4)
        self.model_installed_3.setAutoFillBackground(False)
        self.model_installed_3.setIconSize(QSize(30, 30))
        self.model_installed_3.setCheckable(False)
        self.model_installed_3.setTristate(False)

        self.horizontalLayout_23.addWidget(self.model_installed_3)


        self.verticalLayout_25.addWidget(self.frame_36)

        self.frame_37 = QFrame(self.frame_35)
        self.frame_37.setObjectName(u"frame_37")
        self.frame_37.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_37.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_37.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_24 = QHBoxLayout(self.frame_37)
        self.horizontalLayout_24.setObjectName(u"horizontalLayout_24")
        self.checkpoints_downloaded_3 = QCheckBox(self.frame_37)
        self.checkpoints_downloaded_3.setObjectName(u"checkpoints_downloaded_3")
        self.checkpoints_downloaded_3.setEnabled(False)
        self.checkpoints_downloaded_3.setFont(font4)
        self.checkpoints_downloaded_3.setAutoFillBackground(False)
        self.checkpoints_downloaded_3.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_3.setCheckable(False)
        self.checkpoints_downloaded_3.setTristate(False)

        self.horizontalLayout_24.addWidget(self.checkpoints_downloaded_3)


        self.verticalLayout_25.addWidget(self.frame_37)


        self.horizontalLayout_22.addWidget(self.frame_35)


        self.verticalLayout_21.addWidget(self.frame_33)


        self.horizontalLayout_19.addWidget(self.frame_30)

        self.frame_38 = QFrame(self.frame_29)
        self.frame_38.setObjectName(u"frame_38")
        sizePolicy1.setHeightForWidth(self.frame_38.sizePolicy().hasHeightForWidth())
        self.frame_38.setSizePolicy(sizePolicy1)
        self.frame_38.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_38.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_26 = QVBoxLayout(self.frame_38)
        self.verticalLayout_26.setObjectName(u"verticalLayout_26")
        self.widget_9 = QWidget(self.frame_38)
        self.widget_9.setObjectName(u"widget_9")
        sizePolicy3.setHeightForWidth(self.widget_9.sizePolicy().hasHeightForWidth())
        self.widget_9.setSizePolicy(sizePolicy3)
        self.widget_9.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_25 = QHBoxLayout(self.widget_9)
        self.horizontalLayout_25.setObjectName(u"horizontalLayout_25")
        self.label_25 = QLabel(self.widget_9)
        self.label_25.setObjectName(u"label_25")
        self.label_25.setFont(font2)

        self.horizontalLayout_25.addWidget(self.label_25)

        self.frame_39 = QFrame(self.widget_9)
        self.frame_39.setObjectName(u"frame_39")
        sizePolicy4.setHeightForWidth(self.frame_39.sizePolicy().hasHeightForWidth())
        self.frame_39.setSizePolicy(sizePolicy4)
        self.frame_39.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_39.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_26 = QHBoxLayout(self.frame_39)
        self.horizontalLayout_26.setObjectName(u"horizontalLayout_26")
        self.label_26 = QLabel(self.frame_39)
        self.label_26.setObjectName(u"label_26")
        self.label_26.setFont(font2)

        self.horizontalLayout_26.addWidget(self.label_26)

        self.pushButton_6 = QPushButton(self.frame_39)
        self.pushButton_6.setObjectName(u"pushButton_6")
        self.pushButton_6.setMinimumSize(QSize(30, 30))
        self.pushButton_6.setMaximumSize(QSize(40, 40))
        self.pushButton_6.setIcon(icon1)
        self.pushButton_6.setIconSize(QSize(30, 30))

        self.horizontalLayout_26.addWidget(self.pushButton_6)


        self.horizontalLayout_25.addWidget(self.frame_39)


        self.verticalLayout_26.addWidget(self.widget_9)

        self.textEdit_3 = QTextEdit(self.frame_38)
        self.textEdit_3.setObjectName(u"textEdit_3")
        sizePolicy5.setHeightForWidth(self.textEdit_3.sizePolicy().hasHeightForWidth())
        self.textEdit_3.setSizePolicy(sizePolicy5)
        self.textEdit_3.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_3.setReadOnly(True)

        self.verticalLayout_26.addWidget(self.textEdit_3)


        self.horizontalLayout_19.addWidget(self.frame_38)


        self.verticalLayout_29.addWidget(self.frame_29)

        self.tabWidget.addTab(self.tab_3, "")
        self.tab_4 = QWidget()
        self.tab_4.setObjectName(u"tab_4")
        self.verticalLayout_39 = QVBoxLayout(self.tab_4)
        self.verticalLayout_39.setObjectName(u"verticalLayout_39")
        self.frame_43 = QFrame(self.tab_4)
        self.frame_43.setObjectName(u"frame_43")
        sizePolicy.setHeightForWidth(self.frame_43.sizePolicy().hasHeightForWidth())
        self.frame_43.setSizePolicy(sizePolicy)
        self.frame_43.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_43.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_27 = QHBoxLayout(self.frame_43)
        self.horizontalLayout_27.setObjectName(u"horizontalLayout_27")
        self.frame_44 = QFrame(self.frame_43)
        self.frame_44.setObjectName(u"frame_44")
        sizePolicy1.setHeightForWidth(self.frame_44.sizePolicy().hasHeightForWidth())
        self.frame_44.setSizePolicy(sizePolicy1)
        self.frame_44.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_44.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_30 = QVBoxLayout(self.frame_44)
        self.verticalLayout_30.setObjectName(u"verticalLayout_30")
        self.frame_45 = QFrame(self.frame_44)
        self.frame_45.setObjectName(u"frame_45")
        self.frame_45.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_45.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_45.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_31 = QVBoxLayout(self.frame_45)
        self.verticalLayout_31.setObjectName(u"verticalLayout_31")
        self.frame_47 = QFrame(self.frame_45)
        self.frame_47.setObjectName(u"frame_47")
        self.frame_47.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_47.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_28 = QHBoxLayout(self.frame_47)
        self.horizontalLayout_28.setObjectName(u"horizontalLayout_28")
        self.label_31 = QLabel(self.frame_47)
        self.label_31.setObjectName(u"label_31")
        self.label_31.setFont(font5)
        self.label_31.setTextFormat(Qt.TextFormat.PlainText)
        self.label_31.setScaledContents(False)

        self.horizontalLayout_28.addWidget(self.label_31)

        self.label_32 = QLabel(self.frame_47)
        self.label_32.setObjectName(u"label_32")
        self.label_32.setFont(font2)

        self.horizontalLayout_28.addWidget(self.label_32)


        self.verticalLayout_31.addWidget(self.frame_47)

        self.widget_10 = QWidget(self.frame_45)
        self.widget_10.setObjectName(u"widget_10")
        sizePolicy2.setHeightForWidth(self.widget_10.sizePolicy().hasHeightForWidth())
        self.widget_10.setSizePolicy(sizePolicy2)
        self.horizontalLayout_33 = QHBoxLayout(self.widget_10)
        self.horizontalLayout_33.setObjectName(u"horizontalLayout_33")
        self.pushButton_7 = QPushButton(self.widget_10)
        self.pushButton_7.setObjectName(u"pushButton_7")
        self.pushButton_7.setMinimumSize(QSize(46, 46))
        self.pushButton_7.setMaximumSize(QSize(60, 16777215))
        self.pushButton_7.setIcon(icon)
        self.pushButton_7.setIconSize(QSize(30, 30))

        self.horizontalLayout_33.addWidget(self.pushButton_7)

        self.label_33 = QLabel(self.widget_10)
        self.label_33.setObjectName(u"label_33")
        self.label_33.setMinimumSize(QSize(2, 33))
        self.label_33.setMaximumSize(QSize(16777215, 33))
        self.label_33.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_33.addWidget(self.label_33)


        self.verticalLayout_31.addWidget(self.widget_10)


        self.verticalLayout_30.addWidget(self.frame_45)

        self.frame_51 = QFrame(self.frame_44)
        self.frame_51.setObjectName(u"frame_51")
        self.frame_51.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_51.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_34 = QHBoxLayout(self.frame_51)
        self.horizontalLayout_34.setObjectName(u"horizontalLayout_34")
        self.frame_52 = QFrame(self.frame_51)
        self.frame_52.setObjectName(u"frame_52")
        self.frame_52.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_52.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_52.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_33 = QVBoxLayout(self.frame_52)
        self.verticalLayout_33.setObjectName(u"verticalLayout_33")
        self.label_34 = QLabel(self.frame_52)
        self.label_34.setObjectName(u"label_34")
        self.label_34.setFont(font2)

        self.verticalLayout_33.addWidget(self.label_34, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_11 = QWidget(self.frame_52)
        self.widget_11.setObjectName(u"widget_11")
        sizePolicy2.setHeightForWidth(self.widget_11.sizePolicy().hasHeightForWidth())
        self.widget_11.setSizePolicy(sizePolicy2)
        self.widget_11.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_34 = QVBoxLayout(self.widget_11)
        self.verticalLayout_34.setObjectName(u"verticalLayout_34")
        self.radioButton_7 = QRadioButton(self.widget_11)
        self.radioButton_7.setObjectName(u"radioButton_7")
        self.radioButton_7.setFont(font3)

        self.verticalLayout_34.addWidget(self.radioButton_7)

        self.radioButton_8 = QRadioButton(self.widget_11)
        self.radioButton_8.setObjectName(u"radioButton_8")
        self.radioButton_8.setFont(font3)

        self.verticalLayout_34.addWidget(self.radioButton_8)


        self.verticalLayout_33.addWidget(self.widget_11)


        self.horizontalLayout_34.addWidget(self.frame_52)

        self.frame_53 = QFrame(self.frame_51)
        self.frame_53.setObjectName(u"frame_53")
        sizePolicy1.setHeightForWidth(self.frame_53.sizePolicy().hasHeightForWidth())
        self.frame_53.setSizePolicy(sizePolicy1)
        self.frame_53.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_53.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_35 = QVBoxLayout(self.frame_53)
        self.verticalLayout_35.setObjectName(u"verticalLayout_35")
        self.frame_54 = QFrame(self.frame_53)
        self.frame_54.setObjectName(u"frame_54")
        self.frame_54.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_54.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_54.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_35 = QHBoxLayout(self.frame_54)
        self.horizontalLayout_35.setObjectName(u"horizontalLayout_35")
        self.model_installed_4 = QCheckBox(self.frame_54)
        self.model_installed_4.setObjectName(u"model_installed_4")
        self.model_installed_4.setEnabled(False)
        self.model_installed_4.setFont(font4)
        self.model_installed_4.setAutoFillBackground(False)
        self.model_installed_4.setIconSize(QSize(30, 30))
        self.model_installed_4.setCheckable(False)
        self.model_installed_4.setTristate(False)

        self.horizontalLayout_35.addWidget(self.model_installed_4)


        self.verticalLayout_35.addWidget(self.frame_54)

        self.frame_55 = QFrame(self.frame_53)
        self.frame_55.setObjectName(u"frame_55")
        self.frame_55.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_55.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_55.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_36 = QHBoxLayout(self.frame_55)
        self.horizontalLayout_36.setObjectName(u"horizontalLayout_36")
        self.checkpoints_downloaded_4 = QCheckBox(self.frame_55)
        self.checkpoints_downloaded_4.setObjectName(u"checkpoints_downloaded_4")
        self.checkpoints_downloaded_4.setEnabled(False)
        self.checkpoints_downloaded_4.setFont(font4)
        self.checkpoints_downloaded_4.setAutoFillBackground(False)
        self.checkpoints_downloaded_4.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_4.setCheckable(False)
        self.checkpoints_downloaded_4.setTristate(False)

        self.horizontalLayout_36.addWidget(self.checkpoints_downloaded_4)


        self.verticalLayout_35.addWidget(self.frame_55)


        self.horizontalLayout_34.addWidget(self.frame_53)


        self.verticalLayout_30.addWidget(self.frame_51)


        self.horizontalLayout_27.addWidget(self.frame_44)

        self.frame_56 = QFrame(self.frame_43)
        self.frame_56.setObjectName(u"frame_56")
        sizePolicy1.setHeightForWidth(self.frame_56.sizePolicy().hasHeightForWidth())
        self.frame_56.setSizePolicy(sizePolicy1)
        self.frame_56.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_56.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_36 = QVBoxLayout(self.frame_56)
        self.verticalLayout_36.setObjectName(u"verticalLayout_36")
        self.widget_12 = QWidget(self.frame_56)
        self.widget_12.setObjectName(u"widget_12")
        sizePolicy3.setHeightForWidth(self.widget_12.sizePolicy().hasHeightForWidth())
        self.widget_12.setSizePolicy(sizePolicy3)
        self.widget_12.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_37 = QHBoxLayout(self.widget_12)
        self.horizontalLayout_37.setObjectName(u"horizontalLayout_37")
        self.label_35 = QLabel(self.widget_12)
        self.label_35.setObjectName(u"label_35")
        self.label_35.setFont(font2)

        self.horizontalLayout_37.addWidget(self.label_35)

        self.frame_57 = QFrame(self.widget_12)
        self.frame_57.setObjectName(u"frame_57")
        sizePolicy4.setHeightForWidth(self.frame_57.sizePolicy().hasHeightForWidth())
        self.frame_57.setSizePolicy(sizePolicy4)
        self.frame_57.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_57.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_38 = QHBoxLayout(self.frame_57)
        self.horizontalLayout_38.setObjectName(u"horizontalLayout_38")
        self.label_36 = QLabel(self.frame_57)
        self.label_36.setObjectName(u"label_36")
        self.label_36.setFont(font2)

        self.horizontalLayout_38.addWidget(self.label_36)

        self.pushButton_8 = QPushButton(self.frame_57)
        self.pushButton_8.setObjectName(u"pushButton_8")
        self.pushButton_8.setMinimumSize(QSize(30, 30))
        self.pushButton_8.setMaximumSize(QSize(40, 40))
        self.pushButton_8.setIcon(icon1)
        self.pushButton_8.setIconSize(QSize(30, 30))

        self.horizontalLayout_38.addWidget(self.pushButton_8)


        self.horizontalLayout_37.addWidget(self.frame_57)


        self.verticalLayout_36.addWidget(self.widget_12)

        self.textEdit_4 = QTextEdit(self.frame_56)
        self.textEdit_4.setObjectName(u"textEdit_4")
        sizePolicy5.setHeightForWidth(self.textEdit_4.sizePolicy().hasHeightForWidth())
        self.textEdit_4.setSizePolicy(sizePolicy5)
        self.textEdit_4.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_4.setReadOnly(True)

        self.verticalLayout_36.addWidget(self.textEdit_4)


        self.horizontalLayout_27.addWidget(self.frame_56)


        self.verticalLayout_39.addWidget(self.frame_43)

        self.tabWidget.addTab(self.tab_4, "")
        self.tab_5 = QWidget()
        self.tab_5.setObjectName(u"tab_5")
        self.verticalLayout_2 = QVBoxLayout(self.tab_5)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.frame_61 = QFrame(self.tab_5)
        self.frame_61.setObjectName(u"frame_61")
        sizePolicy.setHeightForWidth(self.frame_61.sizePolicy().hasHeightForWidth())
        self.frame_61.setSizePolicy(sizePolicy)
        self.frame_61.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_61.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_40 = QHBoxLayout(self.frame_61)
        self.horizontalLayout_40.setObjectName(u"horizontalLayout_40")
        self.frame_62 = QFrame(self.frame_61)
        self.frame_62.setObjectName(u"frame_62")
        sizePolicy1.setHeightForWidth(self.frame_62.sizePolicy().hasHeightForWidth())
        self.frame_62.setSizePolicy(sizePolicy1)
        self.frame_62.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_62.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_40 = QVBoxLayout(self.frame_62)
        self.verticalLayout_40.setObjectName(u"verticalLayout_40")
        self.frame_63 = QFrame(self.frame_62)
        self.frame_63.setObjectName(u"frame_63")
        self.frame_63.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_63.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_63.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_41 = QVBoxLayout(self.frame_63)
        self.verticalLayout_41.setObjectName(u"verticalLayout_41")
        self.frame_64 = QFrame(self.frame_63)
        self.frame_64.setObjectName(u"frame_64")
        self.frame_64.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_64.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_41 = QHBoxLayout(self.frame_64)
        self.horizontalLayout_41.setObjectName(u"horizontalLayout_41")
        self.label_41 = QLabel(self.frame_64)
        self.label_41.setObjectName(u"label_41")
        self.label_41.setFont(font5)
        self.label_41.setTextFormat(Qt.TextFormat.PlainText)
        self.label_41.setScaledContents(False)

        self.horizontalLayout_41.addWidget(self.label_41)

        self.label_42 = QLabel(self.frame_64)
        self.label_42.setObjectName(u"label_42")
        self.label_42.setFont(font2)

        self.horizontalLayout_41.addWidget(self.label_42)


        self.verticalLayout_41.addWidget(self.frame_64)

        self.widget_13 = QWidget(self.frame_63)
        self.widget_13.setObjectName(u"widget_13")
        sizePolicy2.setHeightForWidth(self.widget_13.sizePolicy().hasHeightForWidth())
        self.widget_13.setSizePolicy(sizePolicy2)
        self.horizontalLayout_42 = QHBoxLayout(self.widget_13)
        self.horizontalLayout_42.setObjectName(u"horizontalLayout_42")
        self.pushButton_9 = QPushButton(self.widget_13)
        self.pushButton_9.setObjectName(u"pushButton_9")
        self.pushButton_9.setMinimumSize(QSize(46, 46))
        self.pushButton_9.setMaximumSize(QSize(60, 16777215))
        self.pushButton_9.setIcon(icon)
        self.pushButton_9.setIconSize(QSize(30, 30))

        self.horizontalLayout_42.addWidget(self.pushButton_9)

        self.label_43 = QLabel(self.widget_13)
        self.label_43.setObjectName(u"label_43")
        self.label_43.setMinimumSize(QSize(2, 33))
        self.label_43.setMaximumSize(QSize(16777215, 33))
        self.label_43.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_42.addWidget(self.label_43)


        self.verticalLayout_41.addWidget(self.widget_13)


        self.verticalLayout_40.addWidget(self.frame_63)

        self.frame_65 = QFrame(self.frame_62)
        self.frame_65.setObjectName(u"frame_65")
        self.frame_65.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_65.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_43 = QHBoxLayout(self.frame_65)
        self.horizontalLayout_43.setObjectName(u"horizontalLayout_43")
        self.frame_66 = QFrame(self.frame_65)
        self.frame_66.setObjectName(u"frame_66")
        self.frame_66.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_66.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_66.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_42 = QVBoxLayout(self.frame_66)
        self.verticalLayout_42.setObjectName(u"verticalLayout_42")
        self.label_44 = QLabel(self.frame_66)
        self.label_44.setObjectName(u"label_44")
        self.label_44.setFont(font2)

        self.verticalLayout_42.addWidget(self.label_44, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_14 = QWidget(self.frame_66)
        self.widget_14.setObjectName(u"widget_14")
        sizePolicy2.setHeightForWidth(self.widget_14.sizePolicy().hasHeightForWidth())
        self.widget_14.setSizePolicy(sizePolicy2)
        self.widget_14.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_43 = QVBoxLayout(self.widget_14)
        self.verticalLayout_43.setObjectName(u"verticalLayout_43")
        self.radioButton_9 = QRadioButton(self.widget_14)
        self.radioButton_9.setObjectName(u"radioButton_9")
        self.radioButton_9.setFont(font3)

        self.verticalLayout_43.addWidget(self.radioButton_9)

        self.radioButton_10 = QRadioButton(self.widget_14)
        self.radioButton_10.setObjectName(u"radioButton_10")
        self.radioButton_10.setFont(font3)

        self.verticalLayout_43.addWidget(self.radioButton_10)


        self.verticalLayout_42.addWidget(self.widget_14)


        self.horizontalLayout_43.addWidget(self.frame_66)

        self.frame_67 = QFrame(self.frame_65)
        self.frame_67.setObjectName(u"frame_67")
        sizePolicy1.setHeightForWidth(self.frame_67.sizePolicy().hasHeightForWidth())
        self.frame_67.setSizePolicy(sizePolicy1)
        self.frame_67.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_67.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_44 = QVBoxLayout(self.frame_67)
        self.verticalLayout_44.setObjectName(u"verticalLayout_44")
        self.frame_68 = QFrame(self.frame_67)
        self.frame_68.setObjectName(u"frame_68")
        self.frame_68.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_68.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_68.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_44 = QHBoxLayout(self.frame_68)
        self.horizontalLayout_44.setObjectName(u"horizontalLayout_44")
        self.model_installed_5 = QCheckBox(self.frame_68)
        self.model_installed_5.setObjectName(u"model_installed_5")
        self.model_installed_5.setEnabled(False)
        self.model_installed_5.setFont(font4)
        self.model_installed_5.setAutoFillBackground(False)
        self.model_installed_5.setIconSize(QSize(30, 30))
        self.model_installed_5.setCheckable(False)
        self.model_installed_5.setTristate(False)

        self.horizontalLayout_44.addWidget(self.model_installed_5)


        self.verticalLayout_44.addWidget(self.frame_68)

        self.frame_69 = QFrame(self.frame_67)
        self.frame_69.setObjectName(u"frame_69")
        self.frame_69.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_69.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_69.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_45 = QHBoxLayout(self.frame_69)
        self.horizontalLayout_45.setObjectName(u"horizontalLayout_45")
        self.checkpoints_downloaded_5 = QCheckBox(self.frame_69)
        self.checkpoints_downloaded_5.setObjectName(u"checkpoints_downloaded_5")
        self.checkpoints_downloaded_5.setEnabled(False)
        self.checkpoints_downloaded_5.setFont(font4)
        self.checkpoints_downloaded_5.setAutoFillBackground(False)
        self.checkpoints_downloaded_5.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_5.setCheckable(False)
        self.checkpoints_downloaded_5.setTristate(False)

        self.horizontalLayout_45.addWidget(self.checkpoints_downloaded_5)


        self.verticalLayout_44.addWidget(self.frame_69)


        self.horizontalLayout_43.addWidget(self.frame_67)


        self.verticalLayout_40.addWidget(self.frame_65)


        self.horizontalLayout_40.addWidget(self.frame_62)

        self.frame_70 = QFrame(self.frame_61)
        self.frame_70.setObjectName(u"frame_70")
        sizePolicy1.setHeightForWidth(self.frame_70.sizePolicy().hasHeightForWidth())
        self.frame_70.setSizePolicy(sizePolicy1)
        self.frame_70.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_70.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_45 = QVBoxLayout(self.frame_70)
        self.verticalLayout_45.setObjectName(u"verticalLayout_45")
        self.widget_15 = QWidget(self.frame_70)
        self.widget_15.setObjectName(u"widget_15")
        sizePolicy3.setHeightForWidth(self.widget_15.sizePolicy().hasHeightForWidth())
        self.widget_15.setSizePolicy(sizePolicy3)
        self.widget_15.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_46 = QHBoxLayout(self.widget_15)
        self.horizontalLayout_46.setObjectName(u"horizontalLayout_46")
        self.label_45 = QLabel(self.widget_15)
        self.label_45.setObjectName(u"label_45")
        self.label_45.setFont(font2)

        self.horizontalLayout_46.addWidget(self.label_45)

        self.frame_71 = QFrame(self.widget_15)
        self.frame_71.setObjectName(u"frame_71")
        sizePolicy4.setHeightForWidth(self.frame_71.sizePolicy().hasHeightForWidth())
        self.frame_71.setSizePolicy(sizePolicy4)
        self.frame_71.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_71.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_47 = QHBoxLayout(self.frame_71)
        self.horizontalLayout_47.setObjectName(u"horizontalLayout_47")
        self.label_46 = QLabel(self.frame_71)
        self.label_46.setObjectName(u"label_46")
        self.label_46.setFont(font2)

        self.horizontalLayout_47.addWidget(self.label_46)

        self.pushButton_10 = QPushButton(self.frame_71)
        self.pushButton_10.setObjectName(u"pushButton_10")
        self.pushButton_10.setMinimumSize(QSize(30, 30))
        self.pushButton_10.setMaximumSize(QSize(40, 40))
        self.pushButton_10.setIcon(icon1)
        self.pushButton_10.setIconSize(QSize(30, 30))

        self.horizontalLayout_47.addWidget(self.pushButton_10)


        self.horizontalLayout_46.addWidget(self.frame_71)


        self.verticalLayout_45.addWidget(self.widget_15)

        self.textEdit_5 = QTextEdit(self.frame_70)
        self.textEdit_5.setObjectName(u"textEdit_5")
        sizePolicy5.setHeightForWidth(self.textEdit_5.sizePolicy().hasHeightForWidth())
        self.textEdit_5.setSizePolicy(sizePolicy5)
        self.textEdit_5.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_5.setReadOnly(True)

        self.verticalLayout_45.addWidget(self.textEdit_5)


        self.horizontalLayout_40.addWidget(self.frame_70)


        self.verticalLayout_2.addWidget(self.frame_61)

        self.tabWidget.addTab(self.tab_5, "")
        self.tab_6 = QWidget()
        self.tab_6.setObjectName(u"tab_6")
        self.verticalLayout_8 = QVBoxLayout(self.tab_6)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.frame_72 = QFrame(self.tab_6)
        self.frame_72.setObjectName(u"frame_72")
        sizePolicy.setHeightForWidth(self.frame_72.sizePolicy().hasHeightForWidth())
        self.frame_72.setSizePolicy(sizePolicy)
        self.frame_72.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_72.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_48 = QHBoxLayout(self.frame_72)
        self.horizontalLayout_48.setObjectName(u"horizontalLayout_48")
        self.frame_73 = QFrame(self.frame_72)
        self.frame_73.setObjectName(u"frame_73")
        sizePolicy1.setHeightForWidth(self.frame_73.sizePolicy().hasHeightForWidth())
        self.frame_73.setSizePolicy(sizePolicy1)
        self.frame_73.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_73.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_46 = QVBoxLayout(self.frame_73)
        self.verticalLayout_46.setObjectName(u"verticalLayout_46")
        self.frame_74 = QFrame(self.frame_73)
        self.frame_74.setObjectName(u"frame_74")
        self.frame_74.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_74.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_74.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_47 = QVBoxLayout(self.frame_74)
        self.verticalLayout_47.setObjectName(u"verticalLayout_47")
        self.frame_75 = QFrame(self.frame_74)
        self.frame_75.setObjectName(u"frame_75")
        self.frame_75.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_75.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_49 = QHBoxLayout(self.frame_75)
        self.horizontalLayout_49.setObjectName(u"horizontalLayout_49")
        self.label_47 = QLabel(self.frame_75)
        self.label_47.setObjectName(u"label_47")
        self.label_47.setFont(font5)
        self.label_47.setTextFormat(Qt.TextFormat.PlainText)
        self.label_47.setScaledContents(False)

        self.horizontalLayout_49.addWidget(self.label_47)

        self.label_48 = QLabel(self.frame_75)
        self.label_48.setObjectName(u"label_48")
        self.label_48.setFont(font2)

        self.horizontalLayout_49.addWidget(self.label_48)


        self.verticalLayout_47.addWidget(self.frame_75)

        self.widget_16 = QWidget(self.frame_74)
        self.widget_16.setObjectName(u"widget_16")
        sizePolicy2.setHeightForWidth(self.widget_16.sizePolicy().hasHeightForWidth())
        self.widget_16.setSizePolicy(sizePolicy2)
        self.horizontalLayout_50 = QHBoxLayout(self.widget_16)
        self.horizontalLayout_50.setObjectName(u"horizontalLayout_50")
        self.pushButton_11 = QPushButton(self.widget_16)
        self.pushButton_11.setObjectName(u"pushButton_11")
        self.pushButton_11.setMinimumSize(QSize(46, 46))
        self.pushButton_11.setMaximumSize(QSize(60, 16777215))
        self.pushButton_11.setIcon(icon)
        self.pushButton_11.setIconSize(QSize(30, 30))

        self.horizontalLayout_50.addWidget(self.pushButton_11)

        self.label_49 = QLabel(self.widget_16)
        self.label_49.setObjectName(u"label_49")
        self.label_49.setMinimumSize(QSize(2, 33))
        self.label_49.setMaximumSize(QSize(16777215, 33))
        self.label_49.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_50.addWidget(self.label_49)


        self.verticalLayout_47.addWidget(self.widget_16)


        self.verticalLayout_46.addWidget(self.frame_74)

        self.frame_76 = QFrame(self.frame_73)
        self.frame_76.setObjectName(u"frame_76")
        self.frame_76.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_76.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_51 = QHBoxLayout(self.frame_76)
        self.horizontalLayout_51.setObjectName(u"horizontalLayout_51")
        self.frame_77 = QFrame(self.frame_76)
        self.frame_77.setObjectName(u"frame_77")
        self.frame_77.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_77.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_77.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_48 = QVBoxLayout(self.frame_77)
        self.verticalLayout_48.setObjectName(u"verticalLayout_48")
        self.label_50 = QLabel(self.frame_77)
        self.label_50.setObjectName(u"label_50")
        self.label_50.setFont(font2)

        self.verticalLayout_48.addWidget(self.label_50, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_17 = QWidget(self.frame_77)
        self.widget_17.setObjectName(u"widget_17")
        sizePolicy2.setHeightForWidth(self.widget_17.sizePolicy().hasHeightForWidth())
        self.widget_17.setSizePolicy(sizePolicy2)
        self.widget_17.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_49 = QVBoxLayout(self.widget_17)
        self.verticalLayout_49.setObjectName(u"verticalLayout_49")
        self.radioButton_11 = QRadioButton(self.widget_17)
        self.radioButton_11.setObjectName(u"radioButton_11")
        self.radioButton_11.setFont(font3)

        self.verticalLayout_49.addWidget(self.radioButton_11)

        self.radioButton_12 = QRadioButton(self.widget_17)
        self.radioButton_12.setObjectName(u"radioButton_12")
        self.radioButton_12.setFont(font3)

        self.verticalLayout_49.addWidget(self.radioButton_12)


        self.verticalLayout_48.addWidget(self.widget_17)


        self.horizontalLayout_51.addWidget(self.frame_77)

        self.frame_78 = QFrame(self.frame_76)
        self.frame_78.setObjectName(u"frame_78")
        sizePolicy1.setHeightForWidth(self.frame_78.sizePolicy().hasHeightForWidth())
        self.frame_78.setSizePolicy(sizePolicy1)
        self.frame_78.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_78.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_50 = QVBoxLayout(self.frame_78)
        self.verticalLayout_50.setObjectName(u"verticalLayout_50")
        self.frame_79 = QFrame(self.frame_78)
        self.frame_79.setObjectName(u"frame_79")
        self.frame_79.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_79.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_79.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_52 = QHBoxLayout(self.frame_79)
        self.horizontalLayout_52.setObjectName(u"horizontalLayout_52")
        self.model_installed_6 = QCheckBox(self.frame_79)
        self.model_installed_6.setObjectName(u"model_installed_6")
        self.model_installed_6.setEnabled(False)
        self.model_installed_6.setFont(font4)
        self.model_installed_6.setAutoFillBackground(False)
        self.model_installed_6.setIconSize(QSize(30, 30))
        self.model_installed_6.setCheckable(False)
        self.model_installed_6.setTristate(False)

        self.horizontalLayout_52.addWidget(self.model_installed_6)


        self.verticalLayout_50.addWidget(self.frame_79)

        self.frame_80 = QFrame(self.frame_78)
        self.frame_80.setObjectName(u"frame_80")
        self.frame_80.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_80.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_80.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_53 = QHBoxLayout(self.frame_80)
        self.horizontalLayout_53.setObjectName(u"horizontalLayout_53")
        self.checkpoints_downloaded_6 = QCheckBox(self.frame_80)
        self.checkpoints_downloaded_6.setObjectName(u"checkpoints_downloaded_6")
        self.checkpoints_downloaded_6.setEnabled(False)
        self.checkpoints_downloaded_6.setFont(font4)
        self.checkpoints_downloaded_6.setAutoFillBackground(False)
        self.checkpoints_downloaded_6.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_6.setCheckable(False)
        self.checkpoints_downloaded_6.setTristate(False)

        self.horizontalLayout_53.addWidget(self.checkpoints_downloaded_6)


        self.verticalLayout_50.addWidget(self.frame_80)


        self.horizontalLayout_51.addWidget(self.frame_78)


        self.verticalLayout_46.addWidget(self.frame_76)


        self.horizontalLayout_48.addWidget(self.frame_73)

        self.frame_81 = QFrame(self.frame_72)
        self.frame_81.setObjectName(u"frame_81")
        sizePolicy1.setHeightForWidth(self.frame_81.sizePolicy().hasHeightForWidth())
        self.frame_81.setSizePolicy(sizePolicy1)
        self.frame_81.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_81.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_51 = QVBoxLayout(self.frame_81)
        self.verticalLayout_51.setObjectName(u"verticalLayout_51")
        self.widget_18 = QWidget(self.frame_81)
        self.widget_18.setObjectName(u"widget_18")
        sizePolicy3.setHeightForWidth(self.widget_18.sizePolicy().hasHeightForWidth())
        self.widget_18.setSizePolicy(sizePolicy3)
        self.widget_18.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_54 = QHBoxLayout(self.widget_18)
        self.horizontalLayout_54.setObjectName(u"horizontalLayout_54")
        self.label_51 = QLabel(self.widget_18)
        self.label_51.setObjectName(u"label_51")
        self.label_51.setFont(font2)

        self.horizontalLayout_54.addWidget(self.label_51)

        self.frame_82 = QFrame(self.widget_18)
        self.frame_82.setObjectName(u"frame_82")
        sizePolicy4.setHeightForWidth(self.frame_82.sizePolicy().hasHeightForWidth())
        self.frame_82.setSizePolicy(sizePolicy4)
        self.frame_82.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_82.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_55 = QHBoxLayout(self.frame_82)
        self.horizontalLayout_55.setObjectName(u"horizontalLayout_55")
        self.label_52 = QLabel(self.frame_82)
        self.label_52.setObjectName(u"label_52")
        self.label_52.setFont(font2)

        self.horizontalLayout_55.addWidget(self.label_52)

        self.pushButton_12 = QPushButton(self.frame_82)
        self.pushButton_12.setObjectName(u"pushButton_12")
        self.pushButton_12.setMinimumSize(QSize(30, 30))
        self.pushButton_12.setMaximumSize(QSize(40, 40))
        self.pushButton_12.setIcon(icon1)
        self.pushButton_12.setIconSize(QSize(30, 30))

        self.horizontalLayout_55.addWidget(self.pushButton_12)


        self.horizontalLayout_54.addWidget(self.frame_82)


        self.verticalLayout_51.addWidget(self.widget_18)

        self.textEdit_6 = QTextEdit(self.frame_81)
        self.textEdit_6.setObjectName(u"textEdit_6")
        sizePolicy5.setHeightForWidth(self.textEdit_6.sizePolicy().hasHeightForWidth())
        self.textEdit_6.setSizePolicy(sizePolicy5)
        self.textEdit_6.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_6.setReadOnly(True)

        self.verticalLayout_51.addWidget(self.textEdit_6)


        self.horizontalLayout_48.addWidget(self.frame_81)


        self.verticalLayout_8.addWidget(self.frame_72)

        self.tabWidget.addTab(self.tab_6, "")
        self.tab_7 = QWidget()
        self.tab_7.setObjectName(u"tab_7")
        self.verticalLayout_9 = QVBoxLayout(self.tab_7)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.frame_40 = QFrame(self.tab_7)
        self.frame_40.setObjectName(u"frame_40")
        sizePolicy.setHeightForWidth(self.frame_40.sizePolicy().hasHeightForWidth())
        self.frame_40.setSizePolicy(sizePolicy)
        self.frame_40.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_40.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_30 = QHBoxLayout(self.frame_40)
        self.horizontalLayout_30.setObjectName(u"horizontalLayout_30")
        self.frame_41 = QFrame(self.frame_40)
        self.frame_41.setObjectName(u"frame_41")
        sizePolicy1.setHeightForWidth(self.frame_41.sizePolicy().hasHeightForWidth())
        self.frame_41.setSizePolicy(sizePolicy1)
        self.frame_41.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_41.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_27 = QVBoxLayout(self.frame_41)
        self.verticalLayout_27.setObjectName(u"verticalLayout_27")
        self.frame_42 = QFrame(self.frame_41)
        self.frame_42.setObjectName(u"frame_42")
        self.frame_42.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_42.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_42.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_28 = QVBoxLayout(self.frame_42)
        self.verticalLayout_28.setObjectName(u"verticalLayout_28")
        self.frame_58 = QFrame(self.frame_42)
        self.frame_58.setObjectName(u"frame_58")
        self.frame_58.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_58.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_39 = QHBoxLayout(self.frame_58)
        self.horizontalLayout_39.setObjectName(u"horizontalLayout_39")
        self.label_27 = QLabel(self.frame_58)
        self.label_27.setObjectName(u"label_27")
        self.label_27.setFont(font5)
        self.label_27.setTextFormat(Qt.TextFormat.PlainText)
        self.label_27.setScaledContents(False)

        self.horizontalLayout_39.addWidget(self.label_27)

        self.label_28 = QLabel(self.frame_58)
        self.label_28.setObjectName(u"label_28")
        self.label_28.setFont(font2)

        self.horizontalLayout_39.addWidget(self.label_28)


        self.verticalLayout_28.addWidget(self.frame_58)

        self.widget_19 = QWidget(self.frame_42)
        self.widget_19.setObjectName(u"widget_19")
        sizePolicy2.setHeightForWidth(self.widget_19.sizePolicy().hasHeightForWidth())
        self.widget_19.setSizePolicy(sizePolicy2)
        self.horizontalLayout_56 = QHBoxLayout(self.widget_19)
        self.horizontalLayout_56.setObjectName(u"horizontalLayout_56")
        self.pushButton_13 = QPushButton(self.widget_19)
        self.pushButton_13.setObjectName(u"pushButton_13")
        self.pushButton_13.setMinimumSize(QSize(46, 46))
        self.pushButton_13.setMaximumSize(QSize(60, 16777215))
        self.pushButton_13.setIcon(icon)
        self.pushButton_13.setIconSize(QSize(30, 30))

        self.horizontalLayout_56.addWidget(self.pushButton_13)

        self.label_29 = QLabel(self.widget_19)
        self.label_29.setObjectName(u"label_29")
        self.label_29.setMinimumSize(QSize(2, 33))
        self.label_29.setMaximumSize(QSize(16777215, 33))
        self.label_29.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_56.addWidget(self.label_29)


        self.verticalLayout_28.addWidget(self.widget_19)


        self.verticalLayout_27.addWidget(self.frame_42)

        self.frame_59 = QFrame(self.frame_41)
        self.frame_59.setObjectName(u"frame_59")
        self.frame_59.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_59.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_57 = QHBoxLayout(self.frame_59)
        self.horizontalLayout_57.setObjectName(u"horizontalLayout_57")
        self.frame_60 = QFrame(self.frame_59)
        self.frame_60.setObjectName(u"frame_60")
        self.frame_60.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_60.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_60.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_37 = QVBoxLayout(self.frame_60)
        self.verticalLayout_37.setObjectName(u"verticalLayout_37")
        self.label_30 = QLabel(self.frame_60)
        self.label_30.setObjectName(u"label_30")
        self.label_30.setFont(font2)

        self.verticalLayout_37.addWidget(self.label_30, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_20 = QWidget(self.frame_60)
        self.widget_20.setObjectName(u"widget_20")
        sizePolicy2.setHeightForWidth(self.widget_20.sizePolicy().hasHeightForWidth())
        self.widget_20.setSizePolicy(sizePolicy2)
        self.widget_20.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_38 = QVBoxLayout(self.widget_20)
        self.verticalLayout_38.setObjectName(u"verticalLayout_38")
        self.radioButton_13 = QRadioButton(self.widget_20)
        self.radioButton_13.setObjectName(u"radioButton_13")
        self.radioButton_13.setFont(font3)

        self.verticalLayout_38.addWidget(self.radioButton_13)

        self.radioButton_14 = QRadioButton(self.widget_20)
        self.radioButton_14.setObjectName(u"radioButton_14")
        self.radioButton_14.setFont(font3)

        self.verticalLayout_38.addWidget(self.radioButton_14)


        self.verticalLayout_37.addWidget(self.widget_20)


        self.horizontalLayout_57.addWidget(self.frame_60)

        self.frame_83 = QFrame(self.frame_59)
        self.frame_83.setObjectName(u"frame_83")
        sizePolicy1.setHeightForWidth(self.frame_83.sizePolicy().hasHeightForWidth())
        self.frame_83.setSizePolicy(sizePolicy1)
        self.frame_83.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_83.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_52 = QVBoxLayout(self.frame_83)
        self.verticalLayout_52.setObjectName(u"verticalLayout_52")
        self.frame_84 = QFrame(self.frame_83)
        self.frame_84.setObjectName(u"frame_84")
        sizePolicy4.setHeightForWidth(self.frame_84.sizePolicy().hasHeightForWidth())
        self.frame_84.setSizePolicy(sizePolicy4)
        self.frame_84.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_84.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_53 = QVBoxLayout(self.frame_84)
        self.verticalLayout_53.setObjectName(u"verticalLayout_53")
        self.radioButton_15 = QRadioButton(self.frame_84)
        self.radioButton_15.setObjectName(u"radioButton_15")

        self.verticalLayout_53.addWidget(self.radioButton_15)

        self.radioButton_16 = QRadioButton(self.frame_84)
        self.radioButton_16.setObjectName(u"radioButton_16")

        self.verticalLayout_53.addWidget(self.radioButton_16)

        self.radioButton_17 = QRadioButton(self.frame_84)
        self.radioButton_17.setObjectName(u"radioButton_17")

        self.verticalLayout_53.addWidget(self.radioButton_17)


        self.verticalLayout_52.addWidget(self.frame_84, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_88 = QFrame(self.frame_83)
        self.frame_88.setObjectName(u"frame_88")
        self.frame_88.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_88.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_88.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_61 = QHBoxLayout(self.frame_88)
        self.horizontalLayout_61.setObjectName(u"horizontalLayout_61")
        self.model_installed_7 = QCheckBox(self.frame_88)
        self.model_installed_7.setObjectName(u"model_installed_7")
        self.model_installed_7.setEnabled(False)
        self.model_installed_7.setFont(font4)
        self.model_installed_7.setAutoFillBackground(False)
        self.model_installed_7.setIconSize(QSize(30, 30))
        self.model_installed_7.setCheckable(False)
        self.model_installed_7.setTristate(False)

        self.horizontalLayout_61.addWidget(self.model_installed_7)


        self.verticalLayout_52.addWidget(self.frame_88)

        self.frame_89 = QFrame(self.frame_83)
        self.frame_89.setObjectName(u"frame_89")
        self.frame_89.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_89.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_89.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_62 = QHBoxLayout(self.frame_89)
        self.horizontalLayout_62.setObjectName(u"horizontalLayout_62")
        self.checkpoints_downloaded_7 = QCheckBox(self.frame_89)
        self.checkpoints_downloaded_7.setObjectName(u"checkpoints_downloaded_7")
        self.checkpoints_downloaded_7.setEnabled(False)
        self.checkpoints_downloaded_7.setFont(font4)
        self.checkpoints_downloaded_7.setAutoFillBackground(False)
        self.checkpoints_downloaded_7.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_7.setCheckable(False)
        self.checkpoints_downloaded_7.setTristate(False)

        self.horizontalLayout_62.addWidget(self.checkpoints_downloaded_7)


        self.verticalLayout_52.addWidget(self.frame_89)


        self.horizontalLayout_57.addWidget(self.frame_83)


        self.verticalLayout_27.addWidget(self.frame_59)


        self.horizontalLayout_30.addWidget(self.frame_41)

        self.frame_90 = QFrame(self.frame_40)
        self.frame_90.setObjectName(u"frame_90")
        sizePolicy1.setHeightForWidth(self.frame_90.sizePolicy().hasHeightForWidth())
        self.frame_90.setSizePolicy(sizePolicy1)
        self.frame_90.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_90.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_54 = QVBoxLayout(self.frame_90)
        self.verticalLayout_54.setObjectName(u"verticalLayout_54")
        self.widget_21 = QWidget(self.frame_90)
        self.widget_21.setObjectName(u"widget_21")
        sizePolicy3.setHeightForWidth(self.widget_21.sizePolicy().hasHeightForWidth())
        self.widget_21.setSizePolicy(sizePolicy3)
        self.widget_21.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_63 = QHBoxLayout(self.widget_21)
        self.horizontalLayout_63.setObjectName(u"horizontalLayout_63")
        self.label_37 = QLabel(self.widget_21)
        self.label_37.setObjectName(u"label_37")
        self.label_37.setFont(font2)

        self.horizontalLayout_63.addWidget(self.label_37)

        self.frame_91 = QFrame(self.widget_21)
        self.frame_91.setObjectName(u"frame_91")
        sizePolicy4.setHeightForWidth(self.frame_91.sizePolicy().hasHeightForWidth())
        self.frame_91.setSizePolicy(sizePolicy4)
        self.frame_91.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_91.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_64 = QHBoxLayout(self.frame_91)
        self.horizontalLayout_64.setObjectName(u"horizontalLayout_64")
        self.label_38 = QLabel(self.frame_91)
        self.label_38.setObjectName(u"label_38")
        self.label_38.setFont(font2)

        self.horizontalLayout_64.addWidget(self.label_38)

        self.pushButton_14 = QPushButton(self.frame_91)
        self.pushButton_14.setObjectName(u"pushButton_14")
        self.pushButton_14.setMinimumSize(QSize(30, 30))
        self.pushButton_14.setMaximumSize(QSize(40, 40))
        self.pushButton_14.setIcon(icon1)
        self.pushButton_14.setIconSize(QSize(30, 30))

        self.horizontalLayout_64.addWidget(self.pushButton_14)


        self.horizontalLayout_63.addWidget(self.frame_91)


        self.verticalLayout_54.addWidget(self.widget_21)

        self.textEdit_7 = QTextEdit(self.frame_90)
        self.textEdit_7.setObjectName(u"textEdit_7")
        sizePolicy5.setHeightForWidth(self.textEdit_7.sizePolicy().hasHeightForWidth())
        self.textEdit_7.setSizePolicy(sizePolicy5)
        self.textEdit_7.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_7.setReadOnly(True)

        self.verticalLayout_54.addWidget(self.textEdit_7)


        self.horizontalLayout_30.addWidget(self.frame_90)


        self.verticalLayout_9.addWidget(self.frame_40)

        self.tabWidget.addTab(self.tab_7, "")
        self.tab_8 = QWidget()
        self.tab_8.setObjectName(u"tab_8")
        self.verticalLayout_18 = QVBoxLayout(self.tab_8)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.frame_85 = QFrame(self.tab_8)
        self.frame_85.setObjectName(u"frame_85")
        sizePolicy.setHeightForWidth(self.frame_85.sizePolicy().hasHeightForWidth())
        self.frame_85.setSizePolicy(sizePolicy)
        self.frame_85.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_85.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_58 = QHBoxLayout(self.frame_85)
        self.horizontalLayout_58.setObjectName(u"horizontalLayout_58")
        self.frame_86 = QFrame(self.frame_85)
        self.frame_86.setObjectName(u"frame_86")
        sizePolicy1.setHeightForWidth(self.frame_86.sizePolicy().hasHeightForWidth())
        self.frame_86.setSizePolicy(sizePolicy1)
        self.frame_86.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_86.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_55 = QVBoxLayout(self.frame_86)
        self.verticalLayout_55.setObjectName(u"verticalLayout_55")
        self.frame_87 = QFrame(self.frame_86)
        self.frame_87.setObjectName(u"frame_87")
        self.frame_87.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_87.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_87.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_56 = QVBoxLayout(self.frame_87)
        self.verticalLayout_56.setObjectName(u"verticalLayout_56")
        self.frame_92 = QFrame(self.frame_87)
        self.frame_92.setObjectName(u"frame_92")
        self.frame_92.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_92.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_59 = QHBoxLayout(self.frame_92)
        self.horizontalLayout_59.setObjectName(u"horizontalLayout_59")
        self.label_53 = QLabel(self.frame_92)
        self.label_53.setObjectName(u"label_53")
        self.label_53.setFont(font5)
        self.label_53.setTextFormat(Qt.TextFormat.PlainText)
        self.label_53.setScaledContents(False)

        self.horizontalLayout_59.addWidget(self.label_53)

        self.label_54 = QLabel(self.frame_92)
        self.label_54.setObjectName(u"label_54")
        self.label_54.setFont(font2)

        self.horizontalLayout_59.addWidget(self.label_54)


        self.verticalLayout_56.addWidget(self.frame_92)

        self.widget_22 = QWidget(self.frame_87)
        self.widget_22.setObjectName(u"widget_22")
        sizePolicy2.setHeightForWidth(self.widget_22.sizePolicy().hasHeightForWidth())
        self.widget_22.setSizePolicy(sizePolicy2)
        self.horizontalLayout_60 = QHBoxLayout(self.widget_22)
        self.horizontalLayout_60.setObjectName(u"horizontalLayout_60")
        self.pushButton_15 = QPushButton(self.widget_22)
        self.pushButton_15.setObjectName(u"pushButton_15")
        self.pushButton_15.setMinimumSize(QSize(46, 46))
        self.pushButton_15.setMaximumSize(QSize(60, 16777215))
        self.pushButton_15.setIcon(icon)
        self.pushButton_15.setIconSize(QSize(30, 30))

        self.horizontalLayout_60.addWidget(self.pushButton_15)

        self.label_55 = QLabel(self.widget_22)
        self.label_55.setObjectName(u"label_55")
        self.label_55.setMinimumSize(QSize(2, 33))
        self.label_55.setMaximumSize(QSize(16777215, 33))
        self.label_55.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_60.addWidget(self.label_55)


        self.verticalLayout_56.addWidget(self.widget_22)


        self.verticalLayout_55.addWidget(self.frame_87)

        self.frame_93 = QFrame(self.frame_86)
        self.frame_93.setObjectName(u"frame_93")
        self.frame_93.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_93.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_65 = QHBoxLayout(self.frame_93)
        self.horizontalLayout_65.setObjectName(u"horizontalLayout_65")
        self.frame_94 = QFrame(self.frame_93)
        self.frame_94.setObjectName(u"frame_94")
        self.frame_94.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_94.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_94.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_57 = QVBoxLayout(self.frame_94)
        self.verticalLayout_57.setObjectName(u"verticalLayout_57")
        self.label_56 = QLabel(self.frame_94)
        self.label_56.setObjectName(u"label_56")
        self.label_56.setFont(font2)

        self.verticalLayout_57.addWidget(self.label_56, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_23 = QWidget(self.frame_94)
        self.widget_23.setObjectName(u"widget_23")
        sizePolicy2.setHeightForWidth(self.widget_23.sizePolicy().hasHeightForWidth())
        self.widget_23.setSizePolicy(sizePolicy2)
        self.widget_23.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_58 = QVBoxLayout(self.widget_23)
        self.verticalLayout_58.setObjectName(u"verticalLayout_58")
        self.radioButton_18 = QRadioButton(self.widget_23)
        self.radioButton_18.setObjectName(u"radioButton_18")
        self.radioButton_18.setFont(font3)

        self.verticalLayout_58.addWidget(self.radioButton_18)

        self.radioButton_19 = QRadioButton(self.widget_23)
        self.radioButton_19.setObjectName(u"radioButton_19")
        self.radioButton_19.setFont(font3)

        self.verticalLayout_58.addWidget(self.radioButton_19)


        self.verticalLayout_57.addWidget(self.widget_23)


        self.horizontalLayout_65.addWidget(self.frame_94)

        self.frame_95 = QFrame(self.frame_93)
        self.frame_95.setObjectName(u"frame_95")
        sizePolicy1.setHeightForWidth(self.frame_95.sizePolicy().hasHeightForWidth())
        self.frame_95.setSizePolicy(sizePolicy1)
        self.frame_95.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_95.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_59 = QVBoxLayout(self.frame_95)
        self.verticalLayout_59.setObjectName(u"verticalLayout_59")
        self.frame_96 = QFrame(self.frame_95)
        self.frame_96.setObjectName(u"frame_96")
        self.frame_96.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_96.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_96.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_66 = QHBoxLayout(self.frame_96)
        self.horizontalLayout_66.setObjectName(u"horizontalLayout_66")
        self.model_installed_8 = QCheckBox(self.frame_96)
        self.model_installed_8.setObjectName(u"model_installed_8")
        self.model_installed_8.setEnabled(False)
        self.model_installed_8.setFont(font4)
        self.model_installed_8.setAutoFillBackground(False)
        self.model_installed_8.setIconSize(QSize(30, 30))
        self.model_installed_8.setCheckable(False)
        self.model_installed_8.setTristate(False)

        self.horizontalLayout_66.addWidget(self.model_installed_8)


        self.verticalLayout_59.addWidget(self.frame_96)

        self.frame_97 = QFrame(self.frame_95)
        self.frame_97.setObjectName(u"frame_97")
        self.frame_97.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_97.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_97.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_67 = QHBoxLayout(self.frame_97)
        self.horizontalLayout_67.setObjectName(u"horizontalLayout_67")
        self.checkpoints_downloaded_8 = QCheckBox(self.frame_97)
        self.checkpoints_downloaded_8.setObjectName(u"checkpoints_downloaded_8")
        self.checkpoints_downloaded_8.setEnabled(False)
        self.checkpoints_downloaded_8.setFont(font4)
        self.checkpoints_downloaded_8.setAutoFillBackground(False)
        self.checkpoints_downloaded_8.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_8.setCheckable(False)
        self.checkpoints_downloaded_8.setTristate(False)

        self.horizontalLayout_67.addWidget(self.checkpoints_downloaded_8)


        self.verticalLayout_59.addWidget(self.frame_97)


        self.horizontalLayout_65.addWidget(self.frame_95)


        self.verticalLayout_55.addWidget(self.frame_93)


        self.horizontalLayout_58.addWidget(self.frame_86)

        self.frame_98 = QFrame(self.frame_85)
        self.frame_98.setObjectName(u"frame_98")
        sizePolicy1.setHeightForWidth(self.frame_98.sizePolicy().hasHeightForWidth())
        self.frame_98.setSizePolicy(sizePolicy1)
        self.frame_98.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_98.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_60 = QVBoxLayout(self.frame_98)
        self.verticalLayout_60.setObjectName(u"verticalLayout_60")
        self.widget_24 = QWidget(self.frame_98)
        self.widget_24.setObjectName(u"widget_24")
        sizePolicy3.setHeightForWidth(self.widget_24.sizePolicy().hasHeightForWidth())
        self.widget_24.setSizePolicy(sizePolicy3)
        self.widget_24.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_68 = QHBoxLayout(self.widget_24)
        self.horizontalLayout_68.setObjectName(u"horizontalLayout_68")
        self.label_57 = QLabel(self.widget_24)
        self.label_57.setObjectName(u"label_57")
        self.label_57.setFont(font2)

        self.horizontalLayout_68.addWidget(self.label_57)

        self.frame_99 = QFrame(self.widget_24)
        self.frame_99.setObjectName(u"frame_99")
        sizePolicy4.setHeightForWidth(self.frame_99.sizePolicy().hasHeightForWidth())
        self.frame_99.setSizePolicy(sizePolicy4)
        self.frame_99.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_99.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_69 = QHBoxLayout(self.frame_99)
        self.horizontalLayout_69.setObjectName(u"horizontalLayout_69")
        self.label_58 = QLabel(self.frame_99)
        self.label_58.setObjectName(u"label_58")
        self.label_58.setFont(font2)

        self.horizontalLayout_69.addWidget(self.label_58)

        self.pushButton_16 = QPushButton(self.frame_99)
        self.pushButton_16.setObjectName(u"pushButton_16")
        self.pushButton_16.setMinimumSize(QSize(30, 30))
        self.pushButton_16.setMaximumSize(QSize(40, 40))
        self.pushButton_16.setIcon(icon1)
        self.pushButton_16.setIconSize(QSize(30, 30))

        self.horizontalLayout_69.addWidget(self.pushButton_16)


        self.horizontalLayout_68.addWidget(self.frame_99)


        self.verticalLayout_60.addWidget(self.widget_24)

        self.textEdit_8 = QTextEdit(self.frame_98)
        self.textEdit_8.setObjectName(u"textEdit_8")
        sizePolicy5.setHeightForWidth(self.textEdit_8.sizePolicy().hasHeightForWidth())
        self.textEdit_8.setSizePolicy(sizePolicy5)
        self.textEdit_8.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_8.setReadOnly(True)

        self.verticalLayout_60.addWidget(self.textEdit_8)


        self.horizontalLayout_58.addWidget(self.frame_98)


        self.verticalLayout_18.addWidget(self.frame_85)

        self.tabWidget.addTab(self.tab_8, "")
        self.tab_9 = QWidget()
        self.tab_9.setObjectName(u"tab_9")
        self.verticalLayout_19 = QVBoxLayout(self.tab_9)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.frame_100 = QFrame(self.tab_9)
        self.frame_100.setObjectName(u"frame_100")
        sizePolicy.setHeightForWidth(self.frame_100.sizePolicy().hasHeightForWidth())
        self.frame_100.setSizePolicy(sizePolicy)
        self.frame_100.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_100.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_70 = QHBoxLayout(self.frame_100)
        self.horizontalLayout_70.setObjectName(u"horizontalLayout_70")
        self.frame_101 = QFrame(self.frame_100)
        self.frame_101.setObjectName(u"frame_101")
        sizePolicy1.setHeightForWidth(self.frame_101.sizePolicy().hasHeightForWidth())
        self.frame_101.setSizePolicy(sizePolicy1)
        self.frame_101.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_101.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_61 = QVBoxLayout(self.frame_101)
        self.verticalLayout_61.setObjectName(u"verticalLayout_61")
        self.frame_102 = QFrame(self.frame_101)
        self.frame_102.setObjectName(u"frame_102")
        self.frame_102.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_102.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_102.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_62 = QVBoxLayout(self.frame_102)
        self.verticalLayout_62.setObjectName(u"verticalLayout_62")
        self.frame_103 = QFrame(self.frame_102)
        self.frame_103.setObjectName(u"frame_103")
        self.frame_103.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_103.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_71 = QHBoxLayout(self.frame_103)
        self.horizontalLayout_71.setObjectName(u"horizontalLayout_71")
        self.label_39 = QLabel(self.frame_103)
        self.label_39.setObjectName(u"label_39")
        self.label_39.setFont(font5)
        self.label_39.setTextFormat(Qt.TextFormat.PlainText)
        self.label_39.setScaledContents(False)

        self.horizontalLayout_71.addWidget(self.label_39)

        self.label_40 = QLabel(self.frame_103)
        self.label_40.setObjectName(u"label_40")
        self.label_40.setFont(font2)

        self.horizontalLayout_71.addWidget(self.label_40)


        self.verticalLayout_62.addWidget(self.frame_103)

        self.widget_25 = QWidget(self.frame_102)
        self.widget_25.setObjectName(u"widget_25")
        sizePolicy2.setHeightForWidth(self.widget_25.sizePolicy().hasHeightForWidth())
        self.widget_25.setSizePolicy(sizePolicy2)
        self.horizontalLayout_72 = QHBoxLayout(self.widget_25)
        self.horizontalLayout_72.setObjectName(u"horizontalLayout_72")
        self.pushButton_17 = QPushButton(self.widget_25)
        self.pushButton_17.setObjectName(u"pushButton_17")
        self.pushButton_17.setMinimumSize(QSize(46, 46))
        self.pushButton_17.setMaximumSize(QSize(60, 16777215))
        self.pushButton_17.setIcon(icon)
        self.pushButton_17.setIconSize(QSize(30, 30))

        self.horizontalLayout_72.addWidget(self.pushButton_17)

        self.label_59 = QLabel(self.widget_25)
        self.label_59.setObjectName(u"label_59")
        self.label_59.setMinimumSize(QSize(2, 33))
        self.label_59.setMaximumSize(QSize(16777215, 33))
        self.label_59.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_72.addWidget(self.label_59)


        self.verticalLayout_62.addWidget(self.widget_25)


        self.verticalLayout_61.addWidget(self.frame_102)

        self.frame_104 = QFrame(self.frame_101)
        self.frame_104.setObjectName(u"frame_104")
        self.frame_104.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_104.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_73 = QHBoxLayout(self.frame_104)
        self.horizontalLayout_73.setObjectName(u"horizontalLayout_73")
        self.frame_105 = QFrame(self.frame_104)
        self.frame_105.setObjectName(u"frame_105")
        self.frame_105.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_105.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_105.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_63 = QVBoxLayout(self.frame_105)
        self.verticalLayout_63.setObjectName(u"verticalLayout_63")
        self.label_60 = QLabel(self.frame_105)
        self.label_60.setObjectName(u"label_60")
        self.label_60.setFont(font2)

        self.verticalLayout_63.addWidget(self.label_60, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_26 = QWidget(self.frame_105)
        self.widget_26.setObjectName(u"widget_26")
        sizePolicy2.setHeightForWidth(self.widget_26.sizePolicy().hasHeightForWidth())
        self.widget_26.setSizePolicy(sizePolicy2)
        self.widget_26.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_64 = QVBoxLayout(self.widget_26)
        self.verticalLayout_64.setObjectName(u"verticalLayout_64")
        self.radioButton_20 = QRadioButton(self.widget_26)
        self.radioButton_20.setObjectName(u"radioButton_20")
        self.radioButton_20.setFont(font3)

        self.verticalLayout_64.addWidget(self.radioButton_20)

        self.radioButton_21 = QRadioButton(self.widget_26)
        self.radioButton_21.setObjectName(u"radioButton_21")
        self.radioButton_21.setFont(font3)

        self.verticalLayout_64.addWidget(self.radioButton_21)


        self.verticalLayout_63.addWidget(self.widget_26)


        self.horizontalLayout_73.addWidget(self.frame_105)

        self.frame_106 = QFrame(self.frame_104)
        self.frame_106.setObjectName(u"frame_106")
        sizePolicy1.setHeightForWidth(self.frame_106.sizePolicy().hasHeightForWidth())
        self.frame_106.setSizePolicy(sizePolicy1)
        self.frame_106.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_106.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_65 = QVBoxLayout(self.frame_106)
        self.verticalLayout_65.setObjectName(u"verticalLayout_65")
        self.frame_107 = QFrame(self.frame_106)
        self.frame_107.setObjectName(u"frame_107")
        sizePolicy4.setHeightForWidth(self.frame_107.sizePolicy().hasHeightForWidth())
        self.frame_107.setSizePolicy(sizePolicy4)
        self.frame_107.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_107.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_66 = QVBoxLayout(self.frame_107)
        self.verticalLayout_66.setObjectName(u"verticalLayout_66")
        self.radioButton_22 = QRadioButton(self.frame_107)
        self.radioButton_22.setObjectName(u"radioButton_22")

        self.verticalLayout_66.addWidget(self.radioButton_22)

        self.radioButton_23 = QRadioButton(self.frame_107)
        self.radioButton_23.setObjectName(u"radioButton_23")

        self.verticalLayout_66.addWidget(self.radioButton_23)

        self.radioButton_25 = QRadioButton(self.frame_107)
        self.radioButton_25.setObjectName(u"radioButton_25")

        self.verticalLayout_66.addWidget(self.radioButton_25)

        self.radioButton_26 = QRadioButton(self.frame_107)
        self.radioButton_26.setObjectName(u"radioButton_26")

        self.verticalLayout_66.addWidget(self.radioButton_26)

        self.radioButton_27 = QRadioButton(self.frame_107)
        self.radioButton_27.setObjectName(u"radioButton_27")

        self.verticalLayout_66.addWidget(self.radioButton_27)

        self.radioButton_28 = QRadioButton(self.frame_107)
        self.radioButton_28.setObjectName(u"radioButton_28")

        self.verticalLayout_66.addWidget(self.radioButton_28)


        self.verticalLayout_65.addWidget(self.frame_107, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_108 = QFrame(self.frame_106)
        self.frame_108.setObjectName(u"frame_108")
        self.frame_108.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_108.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_108.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_74 = QHBoxLayout(self.frame_108)
        self.horizontalLayout_74.setObjectName(u"horizontalLayout_74")
        self.model_installed_9 = QCheckBox(self.frame_108)
        self.model_installed_9.setObjectName(u"model_installed_9")
        self.model_installed_9.setEnabled(False)
        self.model_installed_9.setFont(font4)
        self.model_installed_9.setAutoFillBackground(False)
        self.model_installed_9.setIconSize(QSize(30, 30))
        self.model_installed_9.setCheckable(False)
        self.model_installed_9.setTristate(False)

        self.horizontalLayout_74.addWidget(self.model_installed_9)


        self.verticalLayout_65.addWidget(self.frame_108)

        self.frame_109 = QFrame(self.frame_106)
        self.frame_109.setObjectName(u"frame_109")
        self.frame_109.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_109.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_109.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_75 = QHBoxLayout(self.frame_109)
        self.horizontalLayout_75.setObjectName(u"horizontalLayout_75")
        self.checkpoints_downloaded_9 = QCheckBox(self.frame_109)
        self.checkpoints_downloaded_9.setObjectName(u"checkpoints_downloaded_9")
        self.checkpoints_downloaded_9.setEnabled(False)
        self.checkpoints_downloaded_9.setFont(font4)
        self.checkpoints_downloaded_9.setAutoFillBackground(False)
        self.checkpoints_downloaded_9.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_9.setCheckable(False)
        self.checkpoints_downloaded_9.setTristate(False)

        self.horizontalLayout_75.addWidget(self.checkpoints_downloaded_9)


        self.verticalLayout_65.addWidget(self.frame_109)


        self.horizontalLayout_73.addWidget(self.frame_106)


        self.verticalLayout_61.addWidget(self.frame_104)


        self.horizontalLayout_70.addWidget(self.frame_101)

        self.frame_110 = QFrame(self.frame_100)
        self.frame_110.setObjectName(u"frame_110")
        sizePolicy1.setHeightForWidth(self.frame_110.sizePolicy().hasHeightForWidth())
        self.frame_110.setSizePolicy(sizePolicy1)
        self.frame_110.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_110.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_67 = QVBoxLayout(self.frame_110)
        self.verticalLayout_67.setObjectName(u"verticalLayout_67")
        self.widget_27 = QWidget(self.frame_110)
        self.widget_27.setObjectName(u"widget_27")
        sizePolicy3.setHeightForWidth(self.widget_27.sizePolicy().hasHeightForWidth())
        self.widget_27.setSizePolicy(sizePolicy3)
        self.widget_27.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_76 = QHBoxLayout(self.widget_27)
        self.horizontalLayout_76.setObjectName(u"horizontalLayout_76")
        self.label_61 = QLabel(self.widget_27)
        self.label_61.setObjectName(u"label_61")
        self.label_61.setFont(font2)

        self.horizontalLayout_76.addWidget(self.label_61)

        self.frame_111 = QFrame(self.widget_27)
        self.frame_111.setObjectName(u"frame_111")
        sizePolicy4.setHeightForWidth(self.frame_111.sizePolicy().hasHeightForWidth())
        self.frame_111.setSizePolicy(sizePolicy4)
        self.frame_111.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_111.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_77 = QHBoxLayout(self.frame_111)
        self.horizontalLayout_77.setObjectName(u"horizontalLayout_77")
        self.label_62 = QLabel(self.frame_111)
        self.label_62.setObjectName(u"label_62")
        self.label_62.setFont(font2)

        self.horizontalLayout_77.addWidget(self.label_62)

        self.pushButton_18 = QPushButton(self.frame_111)
        self.pushButton_18.setObjectName(u"pushButton_18")
        self.pushButton_18.setMinimumSize(QSize(30, 30))
        self.pushButton_18.setMaximumSize(QSize(40, 40))
        self.pushButton_18.setIcon(icon1)
        self.pushButton_18.setIconSize(QSize(30, 30))

        self.horizontalLayout_77.addWidget(self.pushButton_18)


        self.horizontalLayout_76.addWidget(self.frame_111)


        self.verticalLayout_67.addWidget(self.widget_27)

        self.textEdit_9 = QTextEdit(self.frame_110)
        self.textEdit_9.setObjectName(u"textEdit_9")
        sizePolicy5.setHeightForWidth(self.textEdit_9.sizePolicy().hasHeightForWidth())
        self.textEdit_9.setSizePolicy(sizePolicy5)
        self.textEdit_9.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_9.setReadOnly(True)

        self.verticalLayout_67.addWidget(self.textEdit_9)


        self.horizontalLayout_70.addWidget(self.frame_110)


        self.verticalLayout_19.addWidget(self.frame_100)

        self.tabWidget.addTab(self.tab_9, "")
        self.tab_10 = QWidget()
        self.tab_10.setObjectName(u"tab_10")
        self.verticalLayout_74 = QVBoxLayout(self.tab_10)
        self.verticalLayout_74.setObjectName(u"verticalLayout_74")
        self.frame_112 = QFrame(self.tab_10)
        self.frame_112.setObjectName(u"frame_112")
        sizePolicy.setHeightForWidth(self.frame_112.sizePolicy().hasHeightForWidth())
        self.frame_112.setSizePolicy(sizePolicy)
        self.frame_112.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_112.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_78 = QHBoxLayout(self.frame_112)
        self.horizontalLayout_78.setObjectName(u"horizontalLayout_78")
        self.frame_113 = QFrame(self.frame_112)
        self.frame_113.setObjectName(u"frame_113")
        sizePolicy1.setHeightForWidth(self.frame_113.sizePolicy().hasHeightForWidth())
        self.frame_113.setSizePolicy(sizePolicy1)
        self.frame_113.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_113.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_68 = QVBoxLayout(self.frame_113)
        self.verticalLayout_68.setObjectName(u"verticalLayout_68")
        self.frame_114 = QFrame(self.frame_113)
        self.frame_114.setObjectName(u"frame_114")
        self.frame_114.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_114.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_114.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_69 = QVBoxLayout(self.frame_114)
        self.verticalLayout_69.setObjectName(u"verticalLayout_69")
        self.frame_115 = QFrame(self.frame_114)
        self.frame_115.setObjectName(u"frame_115")
        self.frame_115.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_115.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_79 = QHBoxLayout(self.frame_115)
        self.horizontalLayout_79.setObjectName(u"horizontalLayout_79")
        self.label_63 = QLabel(self.frame_115)
        self.label_63.setObjectName(u"label_63")
        self.label_63.setFont(font5)
        self.label_63.setTextFormat(Qt.TextFormat.PlainText)
        self.label_63.setScaledContents(False)

        self.horizontalLayout_79.addWidget(self.label_63)

        self.label_64 = QLabel(self.frame_115)
        self.label_64.setObjectName(u"label_64")
        self.label_64.setFont(font2)

        self.horizontalLayout_79.addWidget(self.label_64)


        self.verticalLayout_69.addWidget(self.frame_115)

        self.widget_28 = QWidget(self.frame_114)
        self.widget_28.setObjectName(u"widget_28")
        sizePolicy2.setHeightForWidth(self.widget_28.sizePolicy().hasHeightForWidth())
        self.widget_28.setSizePolicy(sizePolicy2)
        self.horizontalLayout_80 = QHBoxLayout(self.widget_28)
        self.horizontalLayout_80.setObjectName(u"horizontalLayout_80")
        self.pushButton_19 = QPushButton(self.widget_28)
        self.pushButton_19.setObjectName(u"pushButton_19")
        self.pushButton_19.setMinimumSize(QSize(46, 46))
        self.pushButton_19.setMaximumSize(QSize(60, 16777215))
        self.pushButton_19.setIcon(icon)
        self.pushButton_19.setIconSize(QSize(30, 30))

        self.horizontalLayout_80.addWidget(self.pushButton_19)

        self.label_65 = QLabel(self.widget_28)
        self.label_65.setObjectName(u"label_65")
        self.label_65.setMinimumSize(QSize(2, 33))
        self.label_65.setMaximumSize(QSize(16777215, 33))
        self.label_65.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_80.addWidget(self.label_65)


        self.verticalLayout_69.addWidget(self.widget_28)


        self.verticalLayout_68.addWidget(self.frame_114)

        self.frame_116 = QFrame(self.frame_113)
        self.frame_116.setObjectName(u"frame_116")
        self.frame_116.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_116.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_81 = QHBoxLayout(self.frame_116)
        self.horizontalLayout_81.setObjectName(u"horizontalLayout_81")
        self.frame_117 = QFrame(self.frame_116)
        self.frame_117.setObjectName(u"frame_117")
        self.frame_117.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_117.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_117.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_70 = QVBoxLayout(self.frame_117)
        self.verticalLayout_70.setObjectName(u"verticalLayout_70")
        self.label_66 = QLabel(self.frame_117)
        self.label_66.setObjectName(u"label_66")
        self.label_66.setFont(font2)

        self.verticalLayout_70.addWidget(self.label_66, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_29 = QWidget(self.frame_117)
        self.widget_29.setObjectName(u"widget_29")
        sizePolicy2.setHeightForWidth(self.widget_29.sizePolicy().hasHeightForWidth())
        self.widget_29.setSizePolicy(sizePolicy2)
        self.widget_29.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_71 = QVBoxLayout(self.widget_29)
        self.verticalLayout_71.setObjectName(u"verticalLayout_71")
        self.radioButton_24 = QRadioButton(self.widget_29)
        self.radioButton_24.setObjectName(u"radioButton_24")
        self.radioButton_24.setFont(font3)

        self.verticalLayout_71.addWidget(self.radioButton_24)

        self.radioButton_29 = QRadioButton(self.widget_29)
        self.radioButton_29.setObjectName(u"radioButton_29")
        self.radioButton_29.setFont(font3)

        self.verticalLayout_71.addWidget(self.radioButton_29)


        self.verticalLayout_70.addWidget(self.widget_29)


        self.horizontalLayout_81.addWidget(self.frame_117)

        self.frame_118 = QFrame(self.frame_116)
        self.frame_118.setObjectName(u"frame_118")
        sizePolicy1.setHeightForWidth(self.frame_118.sizePolicy().hasHeightForWidth())
        self.frame_118.setSizePolicy(sizePolicy1)
        self.frame_118.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_118.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_72 = QVBoxLayout(self.frame_118)
        self.verticalLayout_72.setObjectName(u"verticalLayout_72")
        self.frame_119 = QFrame(self.frame_118)
        self.frame_119.setObjectName(u"frame_119")
        self.frame_119.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_119.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_119.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_82 = QHBoxLayout(self.frame_119)
        self.horizontalLayout_82.setObjectName(u"horizontalLayout_82")
        self.model_installed_10 = QCheckBox(self.frame_119)
        self.model_installed_10.setObjectName(u"model_installed_10")
        self.model_installed_10.setEnabled(False)
        self.model_installed_10.setFont(font4)
        self.model_installed_10.setAutoFillBackground(False)
        self.model_installed_10.setIconSize(QSize(30, 30))
        self.model_installed_10.setCheckable(False)
        self.model_installed_10.setTristate(False)

        self.horizontalLayout_82.addWidget(self.model_installed_10)


        self.verticalLayout_72.addWidget(self.frame_119)

        self.frame_120 = QFrame(self.frame_118)
        self.frame_120.setObjectName(u"frame_120")
        self.frame_120.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_120.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_120.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_83 = QHBoxLayout(self.frame_120)
        self.horizontalLayout_83.setObjectName(u"horizontalLayout_83")
        self.checkpoints_downloaded_10 = QCheckBox(self.frame_120)
        self.checkpoints_downloaded_10.setObjectName(u"checkpoints_downloaded_10")
        self.checkpoints_downloaded_10.setEnabled(False)
        self.checkpoints_downloaded_10.setFont(font4)
        self.checkpoints_downloaded_10.setAutoFillBackground(False)
        self.checkpoints_downloaded_10.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_10.setCheckable(False)
        self.checkpoints_downloaded_10.setTristate(False)

        self.horizontalLayout_83.addWidget(self.checkpoints_downloaded_10)


        self.verticalLayout_72.addWidget(self.frame_120)


        self.horizontalLayout_81.addWidget(self.frame_118)


        self.verticalLayout_68.addWidget(self.frame_116)


        self.horizontalLayout_78.addWidget(self.frame_113)

        self.frame_121 = QFrame(self.frame_112)
        self.frame_121.setObjectName(u"frame_121")
        sizePolicy1.setHeightForWidth(self.frame_121.sizePolicy().hasHeightForWidth())
        self.frame_121.setSizePolicy(sizePolicy1)
        self.frame_121.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_121.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_73 = QVBoxLayout(self.frame_121)
        self.verticalLayout_73.setObjectName(u"verticalLayout_73")
        self.widget_30 = QWidget(self.frame_121)
        self.widget_30.setObjectName(u"widget_30")
        sizePolicy3.setHeightForWidth(self.widget_30.sizePolicy().hasHeightForWidth())
        self.widget_30.setSizePolicy(sizePolicy3)
        self.widget_30.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_84 = QHBoxLayout(self.widget_30)
        self.horizontalLayout_84.setObjectName(u"horizontalLayout_84")
        self.label_67 = QLabel(self.widget_30)
        self.label_67.setObjectName(u"label_67")
        self.label_67.setFont(font2)

        self.horizontalLayout_84.addWidget(self.label_67)

        self.frame_122 = QFrame(self.widget_30)
        self.frame_122.setObjectName(u"frame_122")
        sizePolicy4.setHeightForWidth(self.frame_122.sizePolicy().hasHeightForWidth())
        self.frame_122.setSizePolicy(sizePolicy4)
        self.frame_122.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_122.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_85 = QHBoxLayout(self.frame_122)
        self.horizontalLayout_85.setObjectName(u"horizontalLayout_85")
        self.label_68 = QLabel(self.frame_122)
        self.label_68.setObjectName(u"label_68")
        self.label_68.setFont(font2)

        self.horizontalLayout_85.addWidget(self.label_68)

        self.pushButton_20 = QPushButton(self.frame_122)
        self.pushButton_20.setObjectName(u"pushButton_20")
        self.pushButton_20.setMinimumSize(QSize(30, 30))
        self.pushButton_20.setMaximumSize(QSize(40, 40))
        self.pushButton_20.setIcon(icon1)
        self.pushButton_20.setIconSize(QSize(30, 30))

        self.horizontalLayout_85.addWidget(self.pushButton_20)


        self.horizontalLayout_84.addWidget(self.frame_122)


        self.verticalLayout_73.addWidget(self.widget_30)

        self.textEdit_10 = QTextEdit(self.frame_121)
        self.textEdit_10.setObjectName(u"textEdit_10")
        sizePolicy5.setHeightForWidth(self.textEdit_10.sizePolicy().hasHeightForWidth())
        self.textEdit_10.setSizePolicy(sizePolicy5)
        self.textEdit_10.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_10.setReadOnly(True)

        self.verticalLayout_73.addWidget(self.textEdit_10)


        self.horizontalLayout_78.addWidget(self.frame_121)


        self.verticalLayout_74.addWidget(self.frame_112)

        self.tabWidget.addTab(self.tab_10, "")
        self.tab_11 = QWidget()
        self.tab_11.setObjectName(u"tab_11")
        self.verticalLayout_82 = QVBoxLayout(self.tab_11)
        self.verticalLayout_82.setObjectName(u"verticalLayout_82")
        self.frame_123 = QFrame(self.tab_11)
        self.frame_123.setObjectName(u"frame_123")
        sizePolicy.setHeightForWidth(self.frame_123.sizePolicy().hasHeightForWidth())
        self.frame_123.setSizePolicy(sizePolicy)
        self.frame_123.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_123.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_86 = QHBoxLayout(self.frame_123)
        self.horizontalLayout_86.setObjectName(u"horizontalLayout_86")
        self.frame_124 = QFrame(self.frame_123)
        self.frame_124.setObjectName(u"frame_124")
        sizePolicy1.setHeightForWidth(self.frame_124.sizePolicy().hasHeightForWidth())
        self.frame_124.setSizePolicy(sizePolicy1)
        self.frame_124.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_124.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_75 = QVBoxLayout(self.frame_124)
        self.verticalLayout_75.setObjectName(u"verticalLayout_75")
        self.frame_125 = QFrame(self.frame_124)
        self.frame_125.setObjectName(u"frame_125")
        self.frame_125.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_125.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_125.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_76 = QVBoxLayout(self.frame_125)
        self.verticalLayout_76.setObjectName(u"verticalLayout_76")
        self.frame_126 = QFrame(self.frame_125)
        self.frame_126.setObjectName(u"frame_126")
        self.frame_126.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_126.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_87 = QHBoxLayout(self.frame_126)
        self.horizontalLayout_87.setObjectName(u"horizontalLayout_87")
        self.label_69 = QLabel(self.frame_126)
        self.label_69.setObjectName(u"label_69")
        self.label_69.setFont(font5)
        self.label_69.setTextFormat(Qt.TextFormat.PlainText)
        self.label_69.setScaledContents(False)

        self.horizontalLayout_87.addWidget(self.label_69)

        self.label_70 = QLabel(self.frame_126)
        self.label_70.setObjectName(u"label_70")
        self.label_70.setFont(font2)

        self.horizontalLayout_87.addWidget(self.label_70)


        self.verticalLayout_76.addWidget(self.frame_126)

        self.widget_31 = QWidget(self.frame_125)
        self.widget_31.setObjectName(u"widget_31")
        sizePolicy2.setHeightForWidth(self.widget_31.sizePolicy().hasHeightForWidth())
        self.widget_31.setSizePolicy(sizePolicy2)
        self.horizontalLayout_88 = QHBoxLayout(self.widget_31)
        self.horizontalLayout_88.setObjectName(u"horizontalLayout_88")
        self.pushButton_21 = QPushButton(self.widget_31)
        self.pushButton_21.setObjectName(u"pushButton_21")
        self.pushButton_21.setMinimumSize(QSize(46, 46))
        self.pushButton_21.setMaximumSize(QSize(60, 16777215))
        self.pushButton_21.setIcon(icon)
        self.pushButton_21.setIconSize(QSize(30, 30))

        self.horizontalLayout_88.addWidget(self.pushButton_21)

        self.label_71 = QLabel(self.widget_31)
        self.label_71.setObjectName(u"label_71")
        self.label_71.setMinimumSize(QSize(2, 33))
        self.label_71.setMaximumSize(QSize(16777215, 33))
        self.label_71.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_88.addWidget(self.label_71)


        self.verticalLayout_76.addWidget(self.widget_31)


        self.verticalLayout_75.addWidget(self.frame_125)

        self.frame_127 = QFrame(self.frame_124)
        self.frame_127.setObjectName(u"frame_127")
        self.frame_127.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_127.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_89 = QHBoxLayout(self.frame_127)
        self.horizontalLayout_89.setObjectName(u"horizontalLayout_89")
        self.frame_128 = QFrame(self.frame_127)
        self.frame_128.setObjectName(u"frame_128")
        self.frame_128.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_128.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_128.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_77 = QVBoxLayout(self.frame_128)
        self.verticalLayout_77.setObjectName(u"verticalLayout_77")
        self.label_72 = QLabel(self.frame_128)
        self.label_72.setObjectName(u"label_72")
        self.label_72.setFont(font2)

        self.verticalLayout_77.addWidget(self.label_72, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_32 = QWidget(self.frame_128)
        self.widget_32.setObjectName(u"widget_32")
        sizePolicy2.setHeightForWidth(self.widget_32.sizePolicy().hasHeightForWidth())
        self.widget_32.setSizePolicy(sizePolicy2)
        self.widget_32.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_78 = QVBoxLayout(self.widget_32)
        self.verticalLayout_78.setObjectName(u"verticalLayout_78")
        self.radioButton_30 = QRadioButton(self.widget_32)
        self.radioButton_30.setObjectName(u"radioButton_30")
        self.radioButton_30.setFont(font3)

        self.verticalLayout_78.addWidget(self.radioButton_30)

        self.radioButton_31 = QRadioButton(self.widget_32)
        self.radioButton_31.setObjectName(u"radioButton_31")
        self.radioButton_31.setFont(font3)

        self.verticalLayout_78.addWidget(self.radioButton_31)


        self.verticalLayout_77.addWidget(self.widget_32)


        self.horizontalLayout_89.addWidget(self.frame_128)

        self.frame_129 = QFrame(self.frame_127)
        self.frame_129.setObjectName(u"frame_129")
        sizePolicy1.setHeightForWidth(self.frame_129.sizePolicy().hasHeightForWidth())
        self.frame_129.setSizePolicy(sizePolicy1)
        self.frame_129.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_129.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_79 = QVBoxLayout(self.frame_129)
        self.verticalLayout_79.setObjectName(u"verticalLayout_79")
        self.frame_130 = QFrame(self.frame_129)
        self.frame_130.setObjectName(u"frame_130")
        sizePolicy4.setHeightForWidth(self.frame_130.sizePolicy().hasHeightForWidth())
        self.frame_130.setSizePolicy(sizePolicy4)
        self.frame_130.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_130.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_80 = QVBoxLayout(self.frame_130)
        self.verticalLayout_80.setObjectName(u"verticalLayout_80")
        self.radioButton_32 = QRadioButton(self.frame_130)
        self.radioButton_32.setObjectName(u"radioButton_32")

        self.verticalLayout_80.addWidget(self.radioButton_32)

        self.radioButton_33 = QRadioButton(self.frame_130)
        self.radioButton_33.setObjectName(u"radioButton_33")

        self.verticalLayout_80.addWidget(self.radioButton_33)

        self.radioButton_34 = QRadioButton(self.frame_130)
        self.radioButton_34.setObjectName(u"radioButton_34")

        self.verticalLayout_80.addWidget(self.radioButton_34)


        self.verticalLayout_79.addWidget(self.frame_130, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_131 = QFrame(self.frame_129)
        self.frame_131.setObjectName(u"frame_131")
        self.frame_131.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_131.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_131.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_90 = QHBoxLayout(self.frame_131)
        self.horizontalLayout_90.setObjectName(u"horizontalLayout_90")
        self.model_installed_11 = QCheckBox(self.frame_131)
        self.model_installed_11.setObjectName(u"model_installed_11")
        self.model_installed_11.setEnabled(False)
        self.model_installed_11.setFont(font4)
        self.model_installed_11.setAutoFillBackground(False)
        self.model_installed_11.setIconSize(QSize(30, 30))
        self.model_installed_11.setCheckable(False)
        self.model_installed_11.setTristate(False)

        self.horizontalLayout_90.addWidget(self.model_installed_11)


        self.verticalLayout_79.addWidget(self.frame_131)

        self.frame_132 = QFrame(self.frame_129)
        self.frame_132.setObjectName(u"frame_132")
        self.frame_132.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_132.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_132.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_91 = QHBoxLayout(self.frame_132)
        self.horizontalLayout_91.setObjectName(u"horizontalLayout_91")
        self.checkpoints_downloaded_11 = QCheckBox(self.frame_132)
        self.checkpoints_downloaded_11.setObjectName(u"checkpoints_downloaded_11")
        self.checkpoints_downloaded_11.setEnabled(False)
        self.checkpoints_downloaded_11.setFont(font4)
        self.checkpoints_downloaded_11.setAutoFillBackground(False)
        self.checkpoints_downloaded_11.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_11.setCheckable(False)
        self.checkpoints_downloaded_11.setTristate(False)

        self.horizontalLayout_91.addWidget(self.checkpoints_downloaded_11)


        self.verticalLayout_79.addWidget(self.frame_132)


        self.horizontalLayout_89.addWidget(self.frame_129)


        self.verticalLayout_75.addWidget(self.frame_127)


        self.horizontalLayout_86.addWidget(self.frame_124)

        self.frame_133 = QFrame(self.frame_123)
        self.frame_133.setObjectName(u"frame_133")
        sizePolicy1.setHeightForWidth(self.frame_133.sizePolicy().hasHeightForWidth())
        self.frame_133.setSizePolicy(sizePolicy1)
        self.frame_133.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_133.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_81 = QVBoxLayout(self.frame_133)
        self.verticalLayout_81.setObjectName(u"verticalLayout_81")
        self.widget_33 = QWidget(self.frame_133)
        self.widget_33.setObjectName(u"widget_33")
        sizePolicy3.setHeightForWidth(self.widget_33.sizePolicy().hasHeightForWidth())
        self.widget_33.setSizePolicy(sizePolicy3)
        self.widget_33.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_92 = QHBoxLayout(self.widget_33)
        self.horizontalLayout_92.setObjectName(u"horizontalLayout_92")
        self.label_73 = QLabel(self.widget_33)
        self.label_73.setObjectName(u"label_73")
        self.label_73.setFont(font2)

        self.horizontalLayout_92.addWidget(self.label_73)

        self.frame_134 = QFrame(self.widget_33)
        self.frame_134.setObjectName(u"frame_134")
        sizePolicy4.setHeightForWidth(self.frame_134.sizePolicy().hasHeightForWidth())
        self.frame_134.setSizePolicy(sizePolicy4)
        self.frame_134.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_134.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_93 = QHBoxLayout(self.frame_134)
        self.horizontalLayout_93.setObjectName(u"horizontalLayout_93")
        self.label_74 = QLabel(self.frame_134)
        self.label_74.setObjectName(u"label_74")
        self.label_74.setFont(font2)

        self.horizontalLayout_93.addWidget(self.label_74)

        self.pushButton_22 = QPushButton(self.frame_134)
        self.pushButton_22.setObjectName(u"pushButton_22")
        self.pushButton_22.setMinimumSize(QSize(30, 30))
        self.pushButton_22.setMaximumSize(QSize(40, 40))
        self.pushButton_22.setIcon(icon1)
        self.pushButton_22.setIconSize(QSize(30, 30))

        self.horizontalLayout_93.addWidget(self.pushButton_22)


        self.horizontalLayout_92.addWidget(self.frame_134)


        self.verticalLayout_81.addWidget(self.widget_33)

        self.textEdit_11 = QTextEdit(self.frame_133)
        self.textEdit_11.setObjectName(u"textEdit_11")
        sizePolicy5.setHeightForWidth(self.textEdit_11.sizePolicy().hasHeightForWidth())
        self.textEdit_11.setSizePolicy(sizePolicy5)
        self.textEdit_11.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_11.setReadOnly(True)

        self.verticalLayout_81.addWidget(self.textEdit_11)


        self.horizontalLayout_86.addWidget(self.frame_133)


        self.verticalLayout_82.addWidget(self.frame_123)

        self.tabWidget.addTab(self.tab_11, "")
        self.tab_12 = QWidget()
        self.tab_12.setObjectName(u"tab_12")
        self.verticalLayout_90 = QVBoxLayout(self.tab_12)
        self.verticalLayout_90.setObjectName(u"verticalLayout_90")
        self.frame_135 = QFrame(self.tab_12)
        self.frame_135.setObjectName(u"frame_135")
        sizePolicy.setHeightForWidth(self.frame_135.sizePolicy().hasHeightForWidth())
        self.frame_135.setSizePolicy(sizePolicy)
        self.frame_135.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_135.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_94 = QHBoxLayout(self.frame_135)
        self.horizontalLayout_94.setObjectName(u"horizontalLayout_94")
        self.frame_136 = QFrame(self.frame_135)
        self.frame_136.setObjectName(u"frame_136")
        sizePolicy1.setHeightForWidth(self.frame_136.sizePolicy().hasHeightForWidth())
        self.frame_136.setSizePolicy(sizePolicy1)
        self.frame_136.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_136.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_83 = QVBoxLayout(self.frame_136)
        self.verticalLayout_83.setObjectName(u"verticalLayout_83")
        self.frame_137 = QFrame(self.frame_136)
        self.frame_137.setObjectName(u"frame_137")
        self.frame_137.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_137.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_137.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_84 = QVBoxLayout(self.frame_137)
        self.verticalLayout_84.setObjectName(u"verticalLayout_84")
        self.frame_138 = QFrame(self.frame_137)
        self.frame_138.setObjectName(u"frame_138")
        self.frame_138.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_138.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_95 = QHBoxLayout(self.frame_138)
        self.horizontalLayout_95.setObjectName(u"horizontalLayout_95")
        self.label_75 = QLabel(self.frame_138)
        self.label_75.setObjectName(u"label_75")
        self.label_75.setFont(font5)
        self.label_75.setTextFormat(Qt.TextFormat.PlainText)
        self.label_75.setScaledContents(False)

        self.horizontalLayout_95.addWidget(self.label_75)

        self.label_76 = QLabel(self.frame_138)
        self.label_76.setObjectName(u"label_76")
        self.label_76.setFont(font2)

        self.horizontalLayout_95.addWidget(self.label_76)


        self.verticalLayout_84.addWidget(self.frame_138)

        self.widget_34 = QWidget(self.frame_137)
        self.widget_34.setObjectName(u"widget_34")
        sizePolicy2.setHeightForWidth(self.widget_34.sizePolicy().hasHeightForWidth())
        self.widget_34.setSizePolicy(sizePolicy2)
        self.horizontalLayout_96 = QHBoxLayout(self.widget_34)
        self.horizontalLayout_96.setObjectName(u"horizontalLayout_96")
        self.pushButton_23 = QPushButton(self.widget_34)
        self.pushButton_23.setObjectName(u"pushButton_23")
        self.pushButton_23.setMinimumSize(QSize(46, 46))
        self.pushButton_23.setMaximumSize(QSize(60, 16777215))
        self.pushButton_23.setIcon(icon)
        self.pushButton_23.setIconSize(QSize(30, 30))

        self.horizontalLayout_96.addWidget(self.pushButton_23)

        self.label_77 = QLabel(self.widget_34)
        self.label_77.setObjectName(u"label_77")
        self.label_77.setMinimumSize(QSize(2, 33))
        self.label_77.setMaximumSize(QSize(16777215, 33))
        self.label_77.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_96.addWidget(self.label_77)


        self.verticalLayout_84.addWidget(self.widget_34)


        self.verticalLayout_83.addWidget(self.frame_137)

        self.frame_139 = QFrame(self.frame_136)
        self.frame_139.setObjectName(u"frame_139")
        self.frame_139.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_139.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_97 = QHBoxLayout(self.frame_139)
        self.horizontalLayout_97.setObjectName(u"horizontalLayout_97")
        self.frame_140 = QFrame(self.frame_139)
        self.frame_140.setObjectName(u"frame_140")
        self.frame_140.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_140.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_140.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_85 = QVBoxLayout(self.frame_140)
        self.verticalLayout_85.setObjectName(u"verticalLayout_85")
        self.label_78 = QLabel(self.frame_140)
        self.label_78.setObjectName(u"label_78")
        self.label_78.setFont(font2)

        self.verticalLayout_85.addWidget(self.label_78, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_35 = QWidget(self.frame_140)
        self.widget_35.setObjectName(u"widget_35")
        sizePolicy2.setHeightForWidth(self.widget_35.sizePolicy().hasHeightForWidth())
        self.widget_35.setSizePolicy(sizePolicy2)
        self.widget_35.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_86 = QVBoxLayout(self.widget_35)
        self.verticalLayout_86.setObjectName(u"verticalLayout_86")
        self.radioButton_35 = QRadioButton(self.widget_35)
        self.radioButton_35.setObjectName(u"radioButton_35")
        self.radioButton_35.setFont(font3)

        self.verticalLayout_86.addWidget(self.radioButton_35)

        self.radioButton_36 = QRadioButton(self.widget_35)
        self.radioButton_36.setObjectName(u"radioButton_36")
        self.radioButton_36.setFont(font3)

        self.verticalLayout_86.addWidget(self.radioButton_36)


        self.verticalLayout_85.addWidget(self.widget_35)


        self.horizontalLayout_97.addWidget(self.frame_140)

        self.frame_141 = QFrame(self.frame_139)
        self.frame_141.setObjectName(u"frame_141")
        sizePolicy1.setHeightForWidth(self.frame_141.sizePolicy().hasHeightForWidth())
        self.frame_141.setSizePolicy(sizePolicy1)
        self.frame_141.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_141.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_87 = QVBoxLayout(self.frame_141)
        self.verticalLayout_87.setObjectName(u"verticalLayout_87")
        self.frame_142 = QFrame(self.frame_141)
        self.frame_142.setObjectName(u"frame_142")
        sizePolicy4.setHeightForWidth(self.frame_142.sizePolicy().hasHeightForWidth())
        self.frame_142.setSizePolicy(sizePolicy4)
        self.frame_142.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_142.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_88 = QVBoxLayout(self.frame_142)
        self.verticalLayout_88.setObjectName(u"verticalLayout_88")
        self.radioButton_37 = QRadioButton(self.frame_142)
        self.radioButton_37.setObjectName(u"radioButton_37")

        self.verticalLayout_88.addWidget(self.radioButton_37)

        self.radioButton_38 = QRadioButton(self.frame_142)
        self.radioButton_38.setObjectName(u"radioButton_38")

        self.verticalLayout_88.addWidget(self.radioButton_38)


        self.verticalLayout_87.addWidget(self.frame_142, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_146 = QFrame(self.frame_141)
        self.frame_146.setObjectName(u"frame_146")
        self.frame_146.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_146.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_146.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_101 = QHBoxLayout(self.frame_146)
        self.horizontalLayout_101.setObjectName(u"horizontalLayout_101")
        self.model_installed_12 = QCheckBox(self.frame_146)
        self.model_installed_12.setObjectName(u"model_installed_12")
        self.model_installed_12.setEnabled(False)
        self.model_installed_12.setFont(font4)
        self.model_installed_12.setAutoFillBackground(False)
        self.model_installed_12.setIconSize(QSize(30, 30))
        self.model_installed_12.setCheckable(False)
        self.model_installed_12.setTristate(False)

        self.horizontalLayout_101.addWidget(self.model_installed_12)


        self.verticalLayout_87.addWidget(self.frame_146)

        self.frame_147 = QFrame(self.frame_141)
        self.frame_147.setObjectName(u"frame_147")
        self.frame_147.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_147.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_147.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_102 = QHBoxLayout(self.frame_147)
        self.horizontalLayout_102.setObjectName(u"horizontalLayout_102")
        self.checkpoints_downloaded_12 = QCheckBox(self.frame_147)
        self.checkpoints_downloaded_12.setObjectName(u"checkpoints_downloaded_12")
        self.checkpoints_downloaded_12.setEnabled(False)
        self.checkpoints_downloaded_12.setFont(font4)
        self.checkpoints_downloaded_12.setAutoFillBackground(False)
        self.checkpoints_downloaded_12.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_12.setCheckable(False)
        self.checkpoints_downloaded_12.setTristate(False)

        self.horizontalLayout_102.addWidget(self.checkpoints_downloaded_12)


        self.verticalLayout_87.addWidget(self.frame_147)


        self.horizontalLayout_97.addWidget(self.frame_141)


        self.verticalLayout_83.addWidget(self.frame_139)


        self.horizontalLayout_94.addWidget(self.frame_136)

        self.frame_148 = QFrame(self.frame_135)
        self.frame_148.setObjectName(u"frame_148")
        sizePolicy1.setHeightForWidth(self.frame_148.sizePolicy().hasHeightForWidth())
        self.frame_148.setSizePolicy(sizePolicy1)
        self.frame_148.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_148.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_89 = QVBoxLayout(self.frame_148)
        self.verticalLayout_89.setObjectName(u"verticalLayout_89")
        self.widget_36 = QWidget(self.frame_148)
        self.widget_36.setObjectName(u"widget_36")
        sizePolicy3.setHeightForWidth(self.widget_36.sizePolicy().hasHeightForWidth())
        self.widget_36.setSizePolicy(sizePolicy3)
        self.widget_36.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_103 = QHBoxLayout(self.widget_36)
        self.horizontalLayout_103.setObjectName(u"horizontalLayout_103")
        self.label_79 = QLabel(self.widget_36)
        self.label_79.setObjectName(u"label_79")
        self.label_79.setFont(font2)

        self.horizontalLayout_103.addWidget(self.label_79)

        self.frame_149 = QFrame(self.widget_36)
        self.frame_149.setObjectName(u"frame_149")
        sizePolicy4.setHeightForWidth(self.frame_149.sizePolicy().hasHeightForWidth())
        self.frame_149.setSizePolicy(sizePolicy4)
        self.frame_149.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_149.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_104 = QHBoxLayout(self.frame_149)
        self.horizontalLayout_104.setObjectName(u"horizontalLayout_104")
        self.label_80 = QLabel(self.frame_149)
        self.label_80.setObjectName(u"label_80")
        self.label_80.setFont(font2)

        self.horizontalLayout_104.addWidget(self.label_80)

        self.pushButton_24 = QPushButton(self.frame_149)
        self.pushButton_24.setObjectName(u"pushButton_24")
        self.pushButton_24.setMinimumSize(QSize(30, 30))
        self.pushButton_24.setMaximumSize(QSize(40, 40))
        self.pushButton_24.setIcon(icon1)
        self.pushButton_24.setIconSize(QSize(30, 30))

        self.horizontalLayout_104.addWidget(self.pushButton_24)


        self.horizontalLayout_103.addWidget(self.frame_149)


        self.verticalLayout_89.addWidget(self.widget_36)

        self.textEdit_12 = QTextEdit(self.frame_148)
        self.textEdit_12.setObjectName(u"textEdit_12")
        sizePolicy5.setHeightForWidth(self.textEdit_12.sizePolicy().hasHeightForWidth())
        self.textEdit_12.setSizePolicy(sizePolicy5)
        self.textEdit_12.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_12.setReadOnly(True)

        self.verticalLayout_89.addWidget(self.textEdit_12)


        self.horizontalLayout_94.addWidget(self.frame_148)


        self.verticalLayout_90.addWidget(self.frame_135)

        self.tabWidget.addTab(self.tab_12, "")
        self.tab_13 = QWidget()
        self.tab_13.setObjectName(u"tab_13")
        self.verticalLayout_98 = QVBoxLayout(self.tab_13)
        self.verticalLayout_98.setObjectName(u"verticalLayout_98")
        self.frame_143 = QFrame(self.tab_13)
        self.frame_143.setObjectName(u"frame_143")
        sizePolicy.setHeightForWidth(self.frame_143.sizePolicy().hasHeightForWidth())
        self.frame_143.setSizePolicy(sizePolicy)
        self.frame_143.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_143.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_98 = QHBoxLayout(self.frame_143)
        self.horizontalLayout_98.setObjectName(u"horizontalLayout_98")
        self.frame_144 = QFrame(self.frame_143)
        self.frame_144.setObjectName(u"frame_144")
        sizePolicy1.setHeightForWidth(self.frame_144.sizePolicy().hasHeightForWidth())
        self.frame_144.setSizePolicy(sizePolicy1)
        self.frame_144.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_144.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_91 = QVBoxLayout(self.frame_144)
        self.verticalLayout_91.setObjectName(u"verticalLayout_91")
        self.frame_145 = QFrame(self.frame_144)
        self.frame_145.setObjectName(u"frame_145")
        self.frame_145.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_145.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_145.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_92 = QVBoxLayout(self.frame_145)
        self.verticalLayout_92.setObjectName(u"verticalLayout_92")
        self.frame_150 = QFrame(self.frame_145)
        self.frame_150.setObjectName(u"frame_150")
        self.frame_150.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_150.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_99 = QHBoxLayout(self.frame_150)
        self.horizontalLayout_99.setObjectName(u"horizontalLayout_99")
        self.label_81 = QLabel(self.frame_150)
        self.label_81.setObjectName(u"label_81")
        self.label_81.setFont(font5)
        self.label_81.setTextFormat(Qt.TextFormat.PlainText)
        self.label_81.setScaledContents(False)

        self.horizontalLayout_99.addWidget(self.label_81)

        self.label_82 = QLabel(self.frame_150)
        self.label_82.setObjectName(u"label_82")
        self.label_82.setFont(font2)

        self.horizontalLayout_99.addWidget(self.label_82)


        self.verticalLayout_92.addWidget(self.frame_150)

        self.widget_37 = QWidget(self.frame_145)
        self.widget_37.setObjectName(u"widget_37")
        sizePolicy2.setHeightForWidth(self.widget_37.sizePolicy().hasHeightForWidth())
        self.widget_37.setSizePolicy(sizePolicy2)
        self.horizontalLayout_100 = QHBoxLayout(self.widget_37)
        self.horizontalLayout_100.setObjectName(u"horizontalLayout_100")
        self.pushButton_25 = QPushButton(self.widget_37)
        self.pushButton_25.setObjectName(u"pushButton_25")
        self.pushButton_25.setMinimumSize(QSize(46, 46))
        self.pushButton_25.setMaximumSize(QSize(60, 16777215))
        self.pushButton_25.setIcon(icon)
        self.pushButton_25.setIconSize(QSize(30, 30))

        self.horizontalLayout_100.addWidget(self.pushButton_25)

        self.label_83 = QLabel(self.widget_37)
        self.label_83.setObjectName(u"label_83")
        self.label_83.setMinimumSize(QSize(2, 33))
        self.label_83.setMaximumSize(QSize(16777215, 33))
        self.label_83.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_100.addWidget(self.label_83)


        self.verticalLayout_92.addWidget(self.widget_37)


        self.verticalLayout_91.addWidget(self.frame_145)

        self.frame_151 = QFrame(self.frame_144)
        self.frame_151.setObjectName(u"frame_151")
        self.frame_151.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_151.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_105 = QHBoxLayout(self.frame_151)
        self.horizontalLayout_105.setObjectName(u"horizontalLayout_105")
        self.frame_152 = QFrame(self.frame_151)
        self.frame_152.setObjectName(u"frame_152")
        self.frame_152.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_152.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_152.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_93 = QVBoxLayout(self.frame_152)
        self.verticalLayout_93.setObjectName(u"verticalLayout_93")
        self.label_84 = QLabel(self.frame_152)
        self.label_84.setObjectName(u"label_84")
        self.label_84.setFont(font2)

        self.verticalLayout_93.addWidget(self.label_84, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_38 = QWidget(self.frame_152)
        self.widget_38.setObjectName(u"widget_38")
        sizePolicy2.setHeightForWidth(self.widget_38.sizePolicy().hasHeightForWidth())
        self.widget_38.setSizePolicy(sizePolicy2)
        self.widget_38.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_94 = QVBoxLayout(self.widget_38)
        self.verticalLayout_94.setObjectName(u"verticalLayout_94")
        self.radioButton_39 = QRadioButton(self.widget_38)
        self.radioButton_39.setObjectName(u"radioButton_39")
        self.radioButton_39.setFont(font3)

        self.verticalLayout_94.addWidget(self.radioButton_39)

        self.radioButton_40 = QRadioButton(self.widget_38)
        self.radioButton_40.setObjectName(u"radioButton_40")
        self.radioButton_40.setFont(font3)

        self.verticalLayout_94.addWidget(self.radioButton_40)


        self.verticalLayout_93.addWidget(self.widget_38)


        self.horizontalLayout_105.addWidget(self.frame_152)

        self.frame_153 = QFrame(self.frame_151)
        self.frame_153.setObjectName(u"frame_153")
        sizePolicy1.setHeightForWidth(self.frame_153.sizePolicy().hasHeightForWidth())
        self.frame_153.setSizePolicy(sizePolicy1)
        self.frame_153.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_153.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_95 = QVBoxLayout(self.frame_153)
        self.verticalLayout_95.setObjectName(u"verticalLayout_95")
        self.frame_154 = QFrame(self.frame_153)
        self.frame_154.setObjectName(u"frame_154")
        sizePolicy4.setHeightForWidth(self.frame_154.sizePolicy().hasHeightForWidth())
        self.frame_154.setSizePolicy(sizePolicy4)
        self.frame_154.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_154.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_96 = QVBoxLayout(self.frame_154)
        self.verticalLayout_96.setObjectName(u"verticalLayout_96")
        self.radioButton_41 = QRadioButton(self.frame_154)
        self.radioButton_41.setObjectName(u"radioButton_41")

        self.verticalLayout_96.addWidget(self.radioButton_41)

        self.radioButton_42 = QRadioButton(self.frame_154)
        self.radioButton_42.setObjectName(u"radioButton_42")

        self.verticalLayout_96.addWidget(self.radioButton_42)

        self.radioButton_43 = QRadioButton(self.frame_154)
        self.radioButton_43.setObjectName(u"radioButton_43")

        self.verticalLayout_96.addWidget(self.radioButton_43)

        self.radioButton_44 = QRadioButton(self.frame_154)
        self.radioButton_44.setObjectName(u"radioButton_44")

        self.verticalLayout_96.addWidget(self.radioButton_44)


        self.verticalLayout_95.addWidget(self.frame_154, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_155 = QFrame(self.frame_153)
        self.frame_155.setObjectName(u"frame_155")
        self.frame_155.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_155.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_155.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_106 = QHBoxLayout(self.frame_155)
        self.horizontalLayout_106.setObjectName(u"horizontalLayout_106")
        self.model_installed_13 = QCheckBox(self.frame_155)
        self.model_installed_13.setObjectName(u"model_installed_13")
        self.model_installed_13.setEnabled(False)
        self.model_installed_13.setFont(font4)
        self.model_installed_13.setAutoFillBackground(False)
        self.model_installed_13.setIconSize(QSize(30, 30))
        self.model_installed_13.setCheckable(False)
        self.model_installed_13.setTristate(False)

        self.horizontalLayout_106.addWidget(self.model_installed_13)


        self.verticalLayout_95.addWidget(self.frame_155)

        self.frame_156 = QFrame(self.frame_153)
        self.frame_156.setObjectName(u"frame_156")
        self.frame_156.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_156.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_156.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_107 = QHBoxLayout(self.frame_156)
        self.horizontalLayout_107.setObjectName(u"horizontalLayout_107")
        self.checkpoints_downloaded_13 = QCheckBox(self.frame_156)
        self.checkpoints_downloaded_13.setObjectName(u"checkpoints_downloaded_13")
        self.checkpoints_downloaded_13.setEnabled(False)
        self.checkpoints_downloaded_13.setFont(font4)
        self.checkpoints_downloaded_13.setAutoFillBackground(False)
        self.checkpoints_downloaded_13.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_13.setCheckable(False)
        self.checkpoints_downloaded_13.setTristate(False)

        self.horizontalLayout_107.addWidget(self.checkpoints_downloaded_13)


        self.verticalLayout_95.addWidget(self.frame_156)


        self.horizontalLayout_105.addWidget(self.frame_153)


        self.verticalLayout_91.addWidget(self.frame_151)


        self.horizontalLayout_98.addWidget(self.frame_144)

        self.frame_157 = QFrame(self.frame_143)
        self.frame_157.setObjectName(u"frame_157")
        sizePolicy1.setHeightForWidth(self.frame_157.sizePolicy().hasHeightForWidth())
        self.frame_157.setSizePolicy(sizePolicy1)
        self.frame_157.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_157.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_97 = QVBoxLayout(self.frame_157)
        self.verticalLayout_97.setObjectName(u"verticalLayout_97")
        self.widget_39 = QWidget(self.frame_157)
        self.widget_39.setObjectName(u"widget_39")
        sizePolicy3.setHeightForWidth(self.widget_39.sizePolicy().hasHeightForWidth())
        self.widget_39.setSizePolicy(sizePolicy3)
        self.widget_39.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_108 = QHBoxLayout(self.widget_39)
        self.horizontalLayout_108.setObjectName(u"horizontalLayout_108")
        self.label_85 = QLabel(self.widget_39)
        self.label_85.setObjectName(u"label_85")
        self.label_85.setFont(font2)

        self.horizontalLayout_108.addWidget(self.label_85)

        self.frame_158 = QFrame(self.widget_39)
        self.frame_158.setObjectName(u"frame_158")
        sizePolicy4.setHeightForWidth(self.frame_158.sizePolicy().hasHeightForWidth())
        self.frame_158.setSizePolicy(sizePolicy4)
        self.frame_158.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_158.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_109 = QHBoxLayout(self.frame_158)
        self.horizontalLayout_109.setObjectName(u"horizontalLayout_109")
        self.label_86 = QLabel(self.frame_158)
        self.label_86.setObjectName(u"label_86")
        self.label_86.setFont(font2)

        self.horizontalLayout_109.addWidget(self.label_86)

        self.pushButton_26 = QPushButton(self.frame_158)
        self.pushButton_26.setObjectName(u"pushButton_26")
        self.pushButton_26.setMinimumSize(QSize(30, 30))
        self.pushButton_26.setMaximumSize(QSize(40, 40))
        self.pushButton_26.setIcon(icon1)
        self.pushButton_26.setIconSize(QSize(30, 30))

        self.horizontalLayout_109.addWidget(self.pushButton_26)


        self.horizontalLayout_108.addWidget(self.frame_158)


        self.verticalLayout_97.addWidget(self.widget_39)

        self.textEdit_13 = QTextEdit(self.frame_157)
        self.textEdit_13.setObjectName(u"textEdit_13")
        sizePolicy5.setHeightForWidth(self.textEdit_13.sizePolicy().hasHeightForWidth())
        self.textEdit_13.setSizePolicy(sizePolicy5)
        self.textEdit_13.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_13.setReadOnly(True)

        self.verticalLayout_97.addWidget(self.textEdit_13)


        self.horizontalLayout_98.addWidget(self.frame_157)


        self.verticalLayout_98.addWidget(self.frame_143)

        self.tabWidget.addTab(self.tab_13, "")
        self.tab_14 = QWidget()
        self.tab_14.setObjectName(u"tab_14")
        self.verticalLayout_106 = QVBoxLayout(self.tab_14)
        self.verticalLayout_106.setObjectName(u"verticalLayout_106")
        self.frame_159 = QFrame(self.tab_14)
        self.frame_159.setObjectName(u"frame_159")
        sizePolicy.setHeightForWidth(self.frame_159.sizePolicy().hasHeightForWidth())
        self.frame_159.setSizePolicy(sizePolicy)
        self.frame_159.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_159.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_110 = QHBoxLayout(self.frame_159)
        self.horizontalLayout_110.setObjectName(u"horizontalLayout_110")
        self.frame_160 = QFrame(self.frame_159)
        self.frame_160.setObjectName(u"frame_160")
        sizePolicy1.setHeightForWidth(self.frame_160.sizePolicy().hasHeightForWidth())
        self.frame_160.setSizePolicy(sizePolicy1)
        self.frame_160.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_160.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_99 = QVBoxLayout(self.frame_160)
        self.verticalLayout_99.setObjectName(u"verticalLayout_99")
        self.frame_161 = QFrame(self.frame_160)
        self.frame_161.setObjectName(u"frame_161")
        self.frame_161.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_161.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_161.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_100 = QVBoxLayout(self.frame_161)
        self.verticalLayout_100.setObjectName(u"verticalLayout_100")
        self.frame_162 = QFrame(self.frame_161)
        self.frame_162.setObjectName(u"frame_162")
        self.frame_162.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_162.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_111 = QHBoxLayout(self.frame_162)
        self.horizontalLayout_111.setObjectName(u"horizontalLayout_111")
        self.label_87 = QLabel(self.frame_162)
        self.label_87.setObjectName(u"label_87")
        self.label_87.setFont(font5)
        self.label_87.setTextFormat(Qt.TextFormat.PlainText)
        self.label_87.setScaledContents(False)

        self.horizontalLayout_111.addWidget(self.label_87)

        self.label_88 = QLabel(self.frame_162)
        self.label_88.setObjectName(u"label_88")
        self.label_88.setFont(font2)

        self.horizontalLayout_111.addWidget(self.label_88)


        self.verticalLayout_100.addWidget(self.frame_162)

        self.widget_40 = QWidget(self.frame_161)
        self.widget_40.setObjectName(u"widget_40")
        sizePolicy2.setHeightForWidth(self.widget_40.sizePolicy().hasHeightForWidth())
        self.widget_40.setSizePolicy(sizePolicy2)
        self.horizontalLayout_112 = QHBoxLayout(self.widget_40)
        self.horizontalLayout_112.setObjectName(u"horizontalLayout_112")
        self.pushButton_27 = QPushButton(self.widget_40)
        self.pushButton_27.setObjectName(u"pushButton_27")
        self.pushButton_27.setMinimumSize(QSize(46, 46))
        self.pushButton_27.setMaximumSize(QSize(60, 16777215))
        self.pushButton_27.setIcon(icon)
        self.pushButton_27.setIconSize(QSize(30, 30))

        self.horizontalLayout_112.addWidget(self.pushButton_27)

        self.label_89 = QLabel(self.widget_40)
        self.label_89.setObjectName(u"label_89")
        self.label_89.setMinimumSize(QSize(2, 33))
        self.label_89.setMaximumSize(QSize(16777215, 33))
        self.label_89.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_112.addWidget(self.label_89)


        self.verticalLayout_100.addWidget(self.widget_40)


        self.verticalLayout_99.addWidget(self.frame_161)

        self.frame_163 = QFrame(self.frame_160)
        self.frame_163.setObjectName(u"frame_163")
        self.frame_163.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_163.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_113 = QHBoxLayout(self.frame_163)
        self.horizontalLayout_113.setObjectName(u"horizontalLayout_113")
        self.frame_164 = QFrame(self.frame_163)
        self.frame_164.setObjectName(u"frame_164")
        self.frame_164.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_164.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_164.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_101 = QVBoxLayout(self.frame_164)
        self.verticalLayout_101.setObjectName(u"verticalLayout_101")
        self.label_90 = QLabel(self.frame_164)
        self.label_90.setObjectName(u"label_90")
        self.label_90.setFont(font2)

        self.verticalLayout_101.addWidget(self.label_90, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_41 = QWidget(self.frame_164)
        self.widget_41.setObjectName(u"widget_41")
        sizePolicy2.setHeightForWidth(self.widget_41.sizePolicy().hasHeightForWidth())
        self.widget_41.setSizePolicy(sizePolicy2)
        self.widget_41.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_102 = QVBoxLayout(self.widget_41)
        self.verticalLayout_102.setObjectName(u"verticalLayout_102")
        self.radioButton_45 = QRadioButton(self.widget_41)
        self.radioButton_45.setObjectName(u"radioButton_45")
        self.radioButton_45.setFont(font3)

        self.verticalLayout_102.addWidget(self.radioButton_45)

        self.radioButton_46 = QRadioButton(self.widget_41)
        self.radioButton_46.setObjectName(u"radioButton_46")
        self.radioButton_46.setFont(font3)

        self.verticalLayout_102.addWidget(self.radioButton_46)


        self.verticalLayout_101.addWidget(self.widget_41)


        self.horizontalLayout_113.addWidget(self.frame_164)

        self.frame_165 = QFrame(self.frame_163)
        self.frame_165.setObjectName(u"frame_165")
        sizePolicy1.setHeightForWidth(self.frame_165.sizePolicy().hasHeightForWidth())
        self.frame_165.setSizePolicy(sizePolicy1)
        self.frame_165.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_165.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_103 = QVBoxLayout(self.frame_165)
        self.verticalLayout_103.setObjectName(u"verticalLayout_103")
        self.frame_166 = QFrame(self.frame_165)
        self.frame_166.setObjectName(u"frame_166")
        sizePolicy4.setHeightForWidth(self.frame_166.sizePolicy().hasHeightForWidth())
        self.frame_166.setSizePolicy(sizePolicy4)
        self.frame_166.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_166.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_104 = QVBoxLayout(self.frame_166)
        self.verticalLayout_104.setObjectName(u"verticalLayout_104")
        self.radioButton_47 = QRadioButton(self.frame_166)
        self.radioButton_47.setObjectName(u"radioButton_47")

        self.verticalLayout_104.addWidget(self.radioButton_47)

        self.radioButton_48 = QRadioButton(self.frame_166)
        self.radioButton_48.setObjectName(u"radioButton_48")

        self.verticalLayout_104.addWidget(self.radioButton_48)

        self.radioButton_49 = QRadioButton(self.frame_166)
        self.radioButton_49.setObjectName(u"radioButton_49")

        self.verticalLayout_104.addWidget(self.radioButton_49)


        self.verticalLayout_103.addWidget(self.frame_166, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_167 = QFrame(self.frame_165)
        self.frame_167.setObjectName(u"frame_167")
        self.frame_167.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_167.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_167.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_114 = QHBoxLayout(self.frame_167)
        self.horizontalLayout_114.setObjectName(u"horizontalLayout_114")
        self.model_installed_14 = QCheckBox(self.frame_167)
        self.model_installed_14.setObjectName(u"model_installed_14")
        self.model_installed_14.setEnabled(False)
        self.model_installed_14.setFont(font4)
        self.model_installed_14.setAutoFillBackground(False)
        self.model_installed_14.setIconSize(QSize(30, 30))
        self.model_installed_14.setCheckable(False)
        self.model_installed_14.setTristate(False)

        self.horizontalLayout_114.addWidget(self.model_installed_14)


        self.verticalLayout_103.addWidget(self.frame_167)

        self.frame_168 = QFrame(self.frame_165)
        self.frame_168.setObjectName(u"frame_168")
        self.frame_168.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_168.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_168.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_115 = QHBoxLayout(self.frame_168)
        self.horizontalLayout_115.setObjectName(u"horizontalLayout_115")
        self.checkpoints_downloaded_14 = QCheckBox(self.frame_168)
        self.checkpoints_downloaded_14.setObjectName(u"checkpoints_downloaded_14")
        self.checkpoints_downloaded_14.setEnabled(False)
        self.checkpoints_downloaded_14.setFont(font4)
        self.checkpoints_downloaded_14.setAutoFillBackground(False)
        self.checkpoints_downloaded_14.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_14.setCheckable(False)
        self.checkpoints_downloaded_14.setTristate(False)

        self.horizontalLayout_115.addWidget(self.checkpoints_downloaded_14)


        self.verticalLayout_103.addWidget(self.frame_168)


        self.horizontalLayout_113.addWidget(self.frame_165)


        self.verticalLayout_99.addWidget(self.frame_163)


        self.horizontalLayout_110.addWidget(self.frame_160)

        self.frame_169 = QFrame(self.frame_159)
        self.frame_169.setObjectName(u"frame_169")
        sizePolicy1.setHeightForWidth(self.frame_169.sizePolicy().hasHeightForWidth())
        self.frame_169.setSizePolicy(sizePolicy1)
        self.frame_169.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_169.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_105 = QVBoxLayout(self.frame_169)
        self.verticalLayout_105.setObjectName(u"verticalLayout_105")
        self.widget_42 = QWidget(self.frame_169)
        self.widget_42.setObjectName(u"widget_42")
        sizePolicy3.setHeightForWidth(self.widget_42.sizePolicy().hasHeightForWidth())
        self.widget_42.setSizePolicy(sizePolicy3)
        self.widget_42.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_116 = QHBoxLayout(self.widget_42)
        self.horizontalLayout_116.setObjectName(u"horizontalLayout_116")
        self.label_91 = QLabel(self.widget_42)
        self.label_91.setObjectName(u"label_91")
        self.label_91.setFont(font2)

        self.horizontalLayout_116.addWidget(self.label_91)

        self.frame_170 = QFrame(self.widget_42)
        self.frame_170.setObjectName(u"frame_170")
        sizePolicy4.setHeightForWidth(self.frame_170.sizePolicy().hasHeightForWidth())
        self.frame_170.setSizePolicy(sizePolicy4)
        self.frame_170.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_170.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_117 = QHBoxLayout(self.frame_170)
        self.horizontalLayout_117.setObjectName(u"horizontalLayout_117")
        self.label_92 = QLabel(self.frame_170)
        self.label_92.setObjectName(u"label_92")
        self.label_92.setFont(font2)

        self.horizontalLayout_117.addWidget(self.label_92)

        self.pushButton_28 = QPushButton(self.frame_170)
        self.pushButton_28.setObjectName(u"pushButton_28")
        self.pushButton_28.setMinimumSize(QSize(30, 30))
        self.pushButton_28.setMaximumSize(QSize(40, 40))
        self.pushButton_28.setIcon(icon1)
        self.pushButton_28.setIconSize(QSize(30, 30))

        self.horizontalLayout_117.addWidget(self.pushButton_28)


        self.horizontalLayout_116.addWidget(self.frame_170)


        self.verticalLayout_105.addWidget(self.widget_42)

        self.textEdit_14 = QTextEdit(self.frame_169)
        self.textEdit_14.setObjectName(u"textEdit_14")
        sizePolicy5.setHeightForWidth(self.textEdit_14.sizePolicy().hasHeightForWidth())
        self.textEdit_14.setSizePolicy(sizePolicy5)
        self.textEdit_14.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_14.setReadOnly(True)

        self.verticalLayout_105.addWidget(self.textEdit_14)


        self.horizontalLayout_110.addWidget(self.frame_169)


        self.verticalLayout_106.addWidget(self.frame_159)

        self.tabWidget.addTab(self.tab_14, "")
        self.tab_15 = QWidget()
        self.tab_15.setObjectName(u"tab_15")
        self.verticalLayout_113 = QVBoxLayout(self.tab_15)
        self.verticalLayout_113.setObjectName(u"verticalLayout_113")
        self.frame_171 = QFrame(self.tab_15)
        self.frame_171.setObjectName(u"frame_171")
        sizePolicy.setHeightForWidth(self.frame_171.sizePolicy().hasHeightForWidth())
        self.frame_171.setSizePolicy(sizePolicy)
        self.frame_171.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_171.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_118 = QHBoxLayout(self.frame_171)
        self.horizontalLayout_118.setObjectName(u"horizontalLayout_118")
        self.frame_172 = QFrame(self.frame_171)
        self.frame_172.setObjectName(u"frame_172")
        sizePolicy1.setHeightForWidth(self.frame_172.sizePolicy().hasHeightForWidth())
        self.frame_172.setSizePolicy(sizePolicy1)
        self.frame_172.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_172.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_107 = QVBoxLayout(self.frame_172)
        self.verticalLayout_107.setObjectName(u"verticalLayout_107")
        self.frame_173 = QFrame(self.frame_172)
        self.frame_173.setObjectName(u"frame_173")
        self.frame_173.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_173.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_173.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_108 = QVBoxLayout(self.frame_173)
        self.verticalLayout_108.setObjectName(u"verticalLayout_108")
        self.frame_174 = QFrame(self.frame_173)
        self.frame_174.setObjectName(u"frame_174")
        self.frame_174.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_174.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_119 = QHBoxLayout(self.frame_174)
        self.horizontalLayout_119.setObjectName(u"horizontalLayout_119")
        self.label_93 = QLabel(self.frame_174)
        self.label_93.setObjectName(u"label_93")
        self.label_93.setFont(font5)
        self.label_93.setTextFormat(Qt.TextFormat.PlainText)
        self.label_93.setScaledContents(False)

        self.horizontalLayout_119.addWidget(self.label_93)

        self.label_94 = QLabel(self.frame_174)
        self.label_94.setObjectName(u"label_94")
        self.label_94.setFont(font2)

        self.horizontalLayout_119.addWidget(self.label_94)


        self.verticalLayout_108.addWidget(self.frame_174)

        self.widget_43 = QWidget(self.frame_173)
        self.widget_43.setObjectName(u"widget_43")
        sizePolicy2.setHeightForWidth(self.widget_43.sizePolicy().hasHeightForWidth())
        self.widget_43.setSizePolicy(sizePolicy2)
        self.horizontalLayout_120 = QHBoxLayout(self.widget_43)
        self.horizontalLayout_120.setObjectName(u"horizontalLayout_120")
        self.pushButton_29 = QPushButton(self.widget_43)
        self.pushButton_29.setObjectName(u"pushButton_29")
        self.pushButton_29.setMinimumSize(QSize(46, 46))
        self.pushButton_29.setMaximumSize(QSize(60, 16777215))
        self.pushButton_29.setIcon(icon)
        self.pushButton_29.setIconSize(QSize(30, 30))

        self.horizontalLayout_120.addWidget(self.pushButton_29)

        self.label_95 = QLabel(self.widget_43)
        self.label_95.setObjectName(u"label_95")
        self.label_95.setMinimumSize(QSize(2, 33))
        self.label_95.setMaximumSize(QSize(16777215, 33))
        self.label_95.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_120.addWidget(self.label_95)


        self.verticalLayout_108.addWidget(self.widget_43)


        self.verticalLayout_107.addWidget(self.frame_173)

        self.frame_175 = QFrame(self.frame_172)
        self.frame_175.setObjectName(u"frame_175")
        self.frame_175.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_175.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_121 = QHBoxLayout(self.frame_175)
        self.horizontalLayout_121.setObjectName(u"horizontalLayout_121")
        self.frame_176 = QFrame(self.frame_175)
        self.frame_176.setObjectName(u"frame_176")
        self.frame_176.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_176.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_176.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_109 = QVBoxLayout(self.frame_176)
        self.verticalLayout_109.setObjectName(u"verticalLayout_109")
        self.label_96 = QLabel(self.frame_176)
        self.label_96.setObjectName(u"label_96")
        self.label_96.setFont(font2)

        self.verticalLayout_109.addWidget(self.label_96, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_44 = QWidget(self.frame_176)
        self.widget_44.setObjectName(u"widget_44")
        sizePolicy2.setHeightForWidth(self.widget_44.sizePolicy().hasHeightForWidth())
        self.widget_44.setSizePolicy(sizePolicy2)
        self.widget_44.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_110 = QVBoxLayout(self.widget_44)
        self.verticalLayout_110.setObjectName(u"verticalLayout_110")
        self.radioButton_50 = QRadioButton(self.widget_44)
        self.radioButton_50.setObjectName(u"radioButton_50")
        self.radioButton_50.setFont(font3)

        self.verticalLayout_110.addWidget(self.radioButton_50)

        self.radioButton_51 = QRadioButton(self.widget_44)
        self.radioButton_51.setObjectName(u"radioButton_51")
        self.radioButton_51.setFont(font3)

        self.verticalLayout_110.addWidget(self.radioButton_51)


        self.verticalLayout_109.addWidget(self.widget_44)


        self.horizontalLayout_121.addWidget(self.frame_176)

        self.frame_177 = QFrame(self.frame_175)
        self.frame_177.setObjectName(u"frame_177")
        sizePolicy1.setHeightForWidth(self.frame_177.sizePolicy().hasHeightForWidth())
        self.frame_177.setSizePolicy(sizePolicy1)
        self.frame_177.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_177.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_111 = QVBoxLayout(self.frame_177)
        self.verticalLayout_111.setObjectName(u"verticalLayout_111")
        self.frame_178 = QFrame(self.frame_177)
        self.frame_178.setObjectName(u"frame_178")
        self.frame_178.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_178.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_178.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_122 = QHBoxLayout(self.frame_178)
        self.horizontalLayout_122.setObjectName(u"horizontalLayout_122")
        self.model_installed_15 = QCheckBox(self.frame_178)
        self.model_installed_15.setObjectName(u"model_installed_15")
        self.model_installed_15.setEnabled(False)
        self.model_installed_15.setFont(font4)
        self.model_installed_15.setAutoFillBackground(False)
        self.model_installed_15.setIconSize(QSize(30, 30))
        self.model_installed_15.setCheckable(False)
        self.model_installed_15.setTristate(False)

        self.horizontalLayout_122.addWidget(self.model_installed_15)


        self.verticalLayout_111.addWidget(self.frame_178)

        self.frame_179 = QFrame(self.frame_177)
        self.frame_179.setObjectName(u"frame_179")
        self.frame_179.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_179.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_179.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_123 = QHBoxLayout(self.frame_179)
        self.horizontalLayout_123.setObjectName(u"horizontalLayout_123")
        self.checkpoints_downloaded_15 = QCheckBox(self.frame_179)
        self.checkpoints_downloaded_15.setObjectName(u"checkpoints_downloaded_15")
        self.checkpoints_downloaded_15.setEnabled(False)
        self.checkpoints_downloaded_15.setFont(font4)
        self.checkpoints_downloaded_15.setAutoFillBackground(False)
        self.checkpoints_downloaded_15.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_15.setCheckable(False)
        self.checkpoints_downloaded_15.setTristate(False)

        self.horizontalLayout_123.addWidget(self.checkpoints_downloaded_15)


        self.verticalLayout_111.addWidget(self.frame_179)


        self.horizontalLayout_121.addWidget(self.frame_177)


        self.verticalLayout_107.addWidget(self.frame_175)


        self.horizontalLayout_118.addWidget(self.frame_172)

        self.frame_180 = QFrame(self.frame_171)
        self.frame_180.setObjectName(u"frame_180")
        sizePolicy1.setHeightForWidth(self.frame_180.sizePolicy().hasHeightForWidth())
        self.frame_180.setSizePolicy(sizePolicy1)
        self.frame_180.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_180.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_112 = QVBoxLayout(self.frame_180)
        self.verticalLayout_112.setObjectName(u"verticalLayout_112")
        self.widget_45 = QWidget(self.frame_180)
        self.widget_45.setObjectName(u"widget_45")
        sizePolicy3.setHeightForWidth(self.widget_45.sizePolicy().hasHeightForWidth())
        self.widget_45.setSizePolicy(sizePolicy3)
        self.widget_45.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_124 = QHBoxLayout(self.widget_45)
        self.horizontalLayout_124.setObjectName(u"horizontalLayout_124")
        self.label_97 = QLabel(self.widget_45)
        self.label_97.setObjectName(u"label_97")
        self.label_97.setFont(font2)

        self.horizontalLayout_124.addWidget(self.label_97)

        self.frame_181 = QFrame(self.widget_45)
        self.frame_181.setObjectName(u"frame_181")
        sizePolicy4.setHeightForWidth(self.frame_181.sizePolicy().hasHeightForWidth())
        self.frame_181.setSizePolicy(sizePolicy4)
        self.frame_181.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_181.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_125 = QHBoxLayout(self.frame_181)
        self.horizontalLayout_125.setObjectName(u"horizontalLayout_125")
        self.label_98 = QLabel(self.frame_181)
        self.label_98.setObjectName(u"label_98")
        self.label_98.setFont(font2)

        self.horizontalLayout_125.addWidget(self.label_98)

        self.pushButton_30 = QPushButton(self.frame_181)
        self.pushButton_30.setObjectName(u"pushButton_30")
        self.pushButton_30.setMinimumSize(QSize(30, 30))
        self.pushButton_30.setMaximumSize(QSize(40, 40))
        self.pushButton_30.setIcon(icon1)
        self.pushButton_30.setIconSize(QSize(30, 30))

        self.horizontalLayout_125.addWidget(self.pushButton_30)


        self.horizontalLayout_124.addWidget(self.frame_181)


        self.verticalLayout_112.addWidget(self.widget_45)

        self.textEdit_15 = QTextEdit(self.frame_180)
        self.textEdit_15.setObjectName(u"textEdit_15")
        sizePolicy5.setHeightForWidth(self.textEdit_15.sizePolicy().hasHeightForWidth())
        self.textEdit_15.setSizePolicy(sizePolicy5)
        self.textEdit_15.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_15.setReadOnly(True)

        self.verticalLayout_112.addWidget(self.textEdit_15)


        self.horizontalLayout_118.addWidget(self.frame_180)


        self.verticalLayout_113.addWidget(self.frame_171)

        self.tabWidget.addTab(self.tab_15, "")
        self.tab_16 = QWidget()
        self.tab_16.setObjectName(u"tab_16")
        self.verticalLayout_120 = QVBoxLayout(self.tab_16)
        self.verticalLayout_120.setObjectName(u"verticalLayout_120")
        self.frame_182 = QFrame(self.tab_16)
        self.frame_182.setObjectName(u"frame_182")
        sizePolicy.setHeightForWidth(self.frame_182.sizePolicy().hasHeightForWidth())
        self.frame_182.setSizePolicy(sizePolicy)
        self.frame_182.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_182.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_126 = QHBoxLayout(self.frame_182)
        self.horizontalLayout_126.setObjectName(u"horizontalLayout_126")
        self.frame_183 = QFrame(self.frame_182)
        self.frame_183.setObjectName(u"frame_183")
        sizePolicy1.setHeightForWidth(self.frame_183.sizePolicy().hasHeightForWidth())
        self.frame_183.setSizePolicy(sizePolicy1)
        self.frame_183.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_183.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_114 = QVBoxLayout(self.frame_183)
        self.verticalLayout_114.setObjectName(u"verticalLayout_114")
        self.frame_184 = QFrame(self.frame_183)
        self.frame_184.setObjectName(u"frame_184")
        self.frame_184.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_184.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_184.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_115 = QVBoxLayout(self.frame_184)
        self.verticalLayout_115.setObjectName(u"verticalLayout_115")
        self.frame_185 = QFrame(self.frame_184)
        self.frame_185.setObjectName(u"frame_185")
        self.frame_185.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_185.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_127 = QHBoxLayout(self.frame_185)
        self.horizontalLayout_127.setObjectName(u"horizontalLayout_127")
        self.label_99 = QLabel(self.frame_185)
        self.label_99.setObjectName(u"label_99")
        self.label_99.setFont(font5)
        self.label_99.setTextFormat(Qt.TextFormat.PlainText)
        self.label_99.setScaledContents(False)

        self.horizontalLayout_127.addWidget(self.label_99)

        self.label_100 = QLabel(self.frame_185)
        self.label_100.setObjectName(u"label_100")
        self.label_100.setFont(font2)

        self.horizontalLayout_127.addWidget(self.label_100)


        self.verticalLayout_115.addWidget(self.frame_185)

        self.widget_46 = QWidget(self.frame_184)
        self.widget_46.setObjectName(u"widget_46")
        sizePolicy2.setHeightForWidth(self.widget_46.sizePolicy().hasHeightForWidth())
        self.widget_46.setSizePolicy(sizePolicy2)
        self.horizontalLayout_128 = QHBoxLayout(self.widget_46)
        self.horizontalLayout_128.setObjectName(u"horizontalLayout_128")
        self.pushButton_31 = QPushButton(self.widget_46)
        self.pushButton_31.setObjectName(u"pushButton_31")
        self.pushButton_31.setMinimumSize(QSize(46, 46))
        self.pushButton_31.setMaximumSize(QSize(60, 16777215))
        self.pushButton_31.setIcon(icon)
        self.pushButton_31.setIconSize(QSize(30, 30))

        self.horizontalLayout_128.addWidget(self.pushButton_31)

        self.label_101 = QLabel(self.widget_46)
        self.label_101.setObjectName(u"label_101")
        self.label_101.setMinimumSize(QSize(2, 33))
        self.label_101.setMaximumSize(QSize(16777215, 33))
        self.label_101.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_128.addWidget(self.label_101)


        self.verticalLayout_115.addWidget(self.widget_46)


        self.verticalLayout_114.addWidget(self.frame_184)

        self.frame_186 = QFrame(self.frame_183)
        self.frame_186.setObjectName(u"frame_186")
        self.frame_186.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_186.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_129 = QHBoxLayout(self.frame_186)
        self.horizontalLayout_129.setObjectName(u"horizontalLayout_129")
        self.frame_187 = QFrame(self.frame_186)
        self.frame_187.setObjectName(u"frame_187")
        self.frame_187.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_187.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_187.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_116 = QVBoxLayout(self.frame_187)
        self.verticalLayout_116.setObjectName(u"verticalLayout_116")
        self.label_102 = QLabel(self.frame_187)
        self.label_102.setObjectName(u"label_102")
        self.label_102.setFont(font2)

        self.verticalLayout_116.addWidget(self.label_102, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_47 = QWidget(self.frame_187)
        self.widget_47.setObjectName(u"widget_47")
        sizePolicy2.setHeightForWidth(self.widget_47.sizePolicy().hasHeightForWidth())
        self.widget_47.setSizePolicy(sizePolicy2)
        self.widget_47.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_117 = QVBoxLayout(self.widget_47)
        self.verticalLayout_117.setObjectName(u"verticalLayout_117")
        self.radioButton_52 = QRadioButton(self.widget_47)
        self.radioButton_52.setObjectName(u"radioButton_52")
        self.radioButton_52.setFont(font3)

        self.verticalLayout_117.addWidget(self.radioButton_52)

        self.radioButton_53 = QRadioButton(self.widget_47)
        self.radioButton_53.setObjectName(u"radioButton_53")
        self.radioButton_53.setFont(font3)

        self.verticalLayout_117.addWidget(self.radioButton_53)


        self.verticalLayout_116.addWidget(self.widget_47)


        self.horizontalLayout_129.addWidget(self.frame_187)

        self.frame_188 = QFrame(self.frame_186)
        self.frame_188.setObjectName(u"frame_188")
        sizePolicy1.setHeightForWidth(self.frame_188.sizePolicy().hasHeightForWidth())
        self.frame_188.setSizePolicy(sizePolicy1)
        self.frame_188.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_188.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_118 = QVBoxLayout(self.frame_188)
        self.verticalLayout_118.setObjectName(u"verticalLayout_118")
        self.frame_189 = QFrame(self.frame_188)
        self.frame_189.setObjectName(u"frame_189")
        self.frame_189.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_189.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_189.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_130 = QHBoxLayout(self.frame_189)
        self.horizontalLayout_130.setObjectName(u"horizontalLayout_130")
        self.model_installed_16 = QCheckBox(self.frame_189)
        self.model_installed_16.setObjectName(u"model_installed_16")
        self.model_installed_16.setEnabled(False)
        self.model_installed_16.setFont(font4)
        self.model_installed_16.setAutoFillBackground(False)
        self.model_installed_16.setIconSize(QSize(30, 30))
        self.model_installed_16.setCheckable(False)
        self.model_installed_16.setTristate(False)

        self.horizontalLayout_130.addWidget(self.model_installed_16)


        self.verticalLayout_118.addWidget(self.frame_189)

        self.frame_190 = QFrame(self.frame_188)
        self.frame_190.setObjectName(u"frame_190")
        self.frame_190.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_190.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_190.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_131 = QHBoxLayout(self.frame_190)
        self.horizontalLayout_131.setObjectName(u"horizontalLayout_131")
        self.checkpoints_downloaded_16 = QCheckBox(self.frame_190)
        self.checkpoints_downloaded_16.setObjectName(u"checkpoints_downloaded_16")
        self.checkpoints_downloaded_16.setEnabled(False)
        self.checkpoints_downloaded_16.setFont(font4)
        self.checkpoints_downloaded_16.setAutoFillBackground(False)
        self.checkpoints_downloaded_16.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_16.setCheckable(False)
        self.checkpoints_downloaded_16.setTristate(False)

        self.horizontalLayout_131.addWidget(self.checkpoints_downloaded_16)


        self.verticalLayout_118.addWidget(self.frame_190)


        self.horizontalLayout_129.addWidget(self.frame_188)


        self.verticalLayout_114.addWidget(self.frame_186)


        self.horizontalLayout_126.addWidget(self.frame_183)

        self.frame_191 = QFrame(self.frame_182)
        self.frame_191.setObjectName(u"frame_191")
        sizePolicy1.setHeightForWidth(self.frame_191.sizePolicy().hasHeightForWidth())
        self.frame_191.setSizePolicy(sizePolicy1)
        self.frame_191.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_191.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_119 = QVBoxLayout(self.frame_191)
        self.verticalLayout_119.setObjectName(u"verticalLayout_119")
        self.widget_48 = QWidget(self.frame_191)
        self.widget_48.setObjectName(u"widget_48")
        sizePolicy3.setHeightForWidth(self.widget_48.sizePolicy().hasHeightForWidth())
        self.widget_48.setSizePolicy(sizePolicy3)
        self.widget_48.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_132 = QHBoxLayout(self.widget_48)
        self.horizontalLayout_132.setObjectName(u"horizontalLayout_132")
        self.label_103 = QLabel(self.widget_48)
        self.label_103.setObjectName(u"label_103")
        self.label_103.setFont(font2)

        self.horizontalLayout_132.addWidget(self.label_103)

        self.frame_192 = QFrame(self.widget_48)
        self.frame_192.setObjectName(u"frame_192")
        sizePolicy4.setHeightForWidth(self.frame_192.sizePolicy().hasHeightForWidth())
        self.frame_192.setSizePolicy(sizePolicy4)
        self.frame_192.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_192.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_133 = QHBoxLayout(self.frame_192)
        self.horizontalLayout_133.setObjectName(u"horizontalLayout_133")
        self.label_104 = QLabel(self.frame_192)
        self.label_104.setObjectName(u"label_104")
        self.label_104.setFont(font2)

        self.horizontalLayout_133.addWidget(self.label_104)

        self.pushButton_32 = QPushButton(self.frame_192)
        self.pushButton_32.setObjectName(u"pushButton_32")
        self.pushButton_32.setMinimumSize(QSize(30, 30))
        self.pushButton_32.setMaximumSize(QSize(40, 40))
        self.pushButton_32.setIcon(icon1)
        self.pushButton_32.setIconSize(QSize(30, 30))

        self.horizontalLayout_133.addWidget(self.pushButton_32)


        self.horizontalLayout_132.addWidget(self.frame_192)


        self.verticalLayout_119.addWidget(self.widget_48)

        self.textEdit_16 = QTextEdit(self.frame_191)
        self.textEdit_16.setObjectName(u"textEdit_16")
        sizePolicy5.setHeightForWidth(self.textEdit_16.sizePolicy().hasHeightForWidth())
        self.textEdit_16.setSizePolicy(sizePolicy5)
        self.textEdit_16.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_16.setReadOnly(True)

        self.verticalLayout_119.addWidget(self.textEdit_16)


        self.horizontalLayout_126.addWidget(self.frame_191)


        self.verticalLayout_120.addWidget(self.frame_182)

        self.tabWidget.addTab(self.tab_16, "")
        self.tab_17 = QWidget()
        self.tab_17.setObjectName(u"tab_17")
        self.verticalLayout_128 = QVBoxLayout(self.tab_17)
        self.verticalLayout_128.setObjectName(u"verticalLayout_128")
        self.frame_193 = QFrame(self.tab_17)
        self.frame_193.setObjectName(u"frame_193")
        sizePolicy.setHeightForWidth(self.frame_193.sizePolicy().hasHeightForWidth())
        self.frame_193.setSizePolicy(sizePolicy)
        self.frame_193.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_193.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_134 = QHBoxLayout(self.frame_193)
        self.horizontalLayout_134.setObjectName(u"horizontalLayout_134")
        self.frame_194 = QFrame(self.frame_193)
        self.frame_194.setObjectName(u"frame_194")
        sizePolicy1.setHeightForWidth(self.frame_194.sizePolicy().hasHeightForWidth())
        self.frame_194.setSizePolicy(sizePolicy1)
        self.frame_194.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_194.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_121 = QVBoxLayout(self.frame_194)
        self.verticalLayout_121.setObjectName(u"verticalLayout_121")
        self.frame_195 = QFrame(self.frame_194)
        self.frame_195.setObjectName(u"frame_195")
        self.frame_195.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_195.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_195.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_122 = QVBoxLayout(self.frame_195)
        self.verticalLayout_122.setObjectName(u"verticalLayout_122")
        self.frame_196 = QFrame(self.frame_195)
        self.frame_196.setObjectName(u"frame_196")
        self.frame_196.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_196.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_135 = QHBoxLayout(self.frame_196)
        self.horizontalLayout_135.setObjectName(u"horizontalLayout_135")
        self.label_105 = QLabel(self.frame_196)
        self.label_105.setObjectName(u"label_105")
        self.label_105.setFont(font5)
        self.label_105.setTextFormat(Qt.TextFormat.PlainText)
        self.label_105.setScaledContents(False)

        self.horizontalLayout_135.addWidget(self.label_105)

        self.label_106 = QLabel(self.frame_196)
        self.label_106.setObjectName(u"label_106")
        self.label_106.setFont(font2)

        self.horizontalLayout_135.addWidget(self.label_106)


        self.verticalLayout_122.addWidget(self.frame_196)

        self.widget_49 = QWidget(self.frame_195)
        self.widget_49.setObjectName(u"widget_49")
        sizePolicy2.setHeightForWidth(self.widget_49.sizePolicy().hasHeightForWidth())
        self.widget_49.setSizePolicy(sizePolicy2)
        self.horizontalLayout_136 = QHBoxLayout(self.widget_49)
        self.horizontalLayout_136.setObjectName(u"horizontalLayout_136")
        self.pushButton_33 = QPushButton(self.widget_49)
        self.pushButton_33.setObjectName(u"pushButton_33")
        self.pushButton_33.setMinimumSize(QSize(46, 46))
        self.pushButton_33.setMaximumSize(QSize(60, 16777215))
        self.pushButton_33.setIcon(icon)
        self.pushButton_33.setIconSize(QSize(30, 30))

        self.horizontalLayout_136.addWidget(self.pushButton_33)

        self.label_107 = QLabel(self.widget_49)
        self.label_107.setObjectName(u"label_107")
        self.label_107.setMinimumSize(QSize(2, 33))
        self.label_107.setMaximumSize(QSize(16777215, 33))
        self.label_107.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_136.addWidget(self.label_107)


        self.verticalLayout_122.addWidget(self.widget_49)


        self.verticalLayout_121.addWidget(self.frame_195)

        self.frame_197 = QFrame(self.frame_194)
        self.frame_197.setObjectName(u"frame_197")
        self.frame_197.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_197.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_137 = QHBoxLayout(self.frame_197)
        self.horizontalLayout_137.setObjectName(u"horizontalLayout_137")
        self.frame_198 = QFrame(self.frame_197)
        self.frame_198.setObjectName(u"frame_198")
        self.frame_198.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_198.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_198.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_123 = QVBoxLayout(self.frame_198)
        self.verticalLayout_123.setObjectName(u"verticalLayout_123")
        self.label_108 = QLabel(self.frame_198)
        self.label_108.setObjectName(u"label_108")
        self.label_108.setFont(font2)

        self.verticalLayout_123.addWidget(self.label_108, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_50 = QWidget(self.frame_198)
        self.widget_50.setObjectName(u"widget_50")
        sizePolicy2.setHeightForWidth(self.widget_50.sizePolicy().hasHeightForWidth())
        self.widget_50.setSizePolicy(sizePolicy2)
        self.widget_50.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_124 = QVBoxLayout(self.widget_50)
        self.verticalLayout_124.setObjectName(u"verticalLayout_124")
        self.radioButton_54 = QRadioButton(self.widget_50)
        self.radioButton_54.setObjectName(u"radioButton_54")
        self.radioButton_54.setFont(font3)

        self.verticalLayout_124.addWidget(self.radioButton_54)

        self.radioButton_55 = QRadioButton(self.widget_50)
        self.radioButton_55.setObjectName(u"radioButton_55")
        self.radioButton_55.setFont(font3)

        self.verticalLayout_124.addWidget(self.radioButton_55)


        self.verticalLayout_123.addWidget(self.widget_50)


        self.horizontalLayout_137.addWidget(self.frame_198)

        self.frame_199 = QFrame(self.frame_197)
        self.frame_199.setObjectName(u"frame_199")
        sizePolicy1.setHeightForWidth(self.frame_199.sizePolicy().hasHeightForWidth())
        self.frame_199.setSizePolicy(sizePolicy1)
        self.frame_199.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_199.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_125 = QVBoxLayout(self.frame_199)
        self.verticalLayout_125.setObjectName(u"verticalLayout_125")
        self.frame_200 = QFrame(self.frame_199)
        self.frame_200.setObjectName(u"frame_200")
        sizePolicy4.setHeightForWidth(self.frame_200.sizePolicy().hasHeightForWidth())
        self.frame_200.setSizePolicy(sizePolicy4)
        self.frame_200.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_200.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_126 = QVBoxLayout(self.frame_200)
        self.verticalLayout_126.setObjectName(u"verticalLayout_126")
        self.radioButton_56 = QRadioButton(self.frame_200)
        self.radioButton_56.setObjectName(u"radioButton_56")

        self.verticalLayout_126.addWidget(self.radioButton_56)

        self.radioButton_57 = QRadioButton(self.frame_200)
        self.radioButton_57.setObjectName(u"radioButton_57")

        self.verticalLayout_126.addWidget(self.radioButton_57)

        self.radioButton_58 = QRadioButton(self.frame_200)
        self.radioButton_58.setObjectName(u"radioButton_58")

        self.verticalLayout_126.addWidget(self.radioButton_58)


        self.verticalLayout_125.addWidget(self.frame_200, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_201 = QFrame(self.frame_199)
        self.frame_201.setObjectName(u"frame_201")
        self.frame_201.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_201.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_201.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_138 = QHBoxLayout(self.frame_201)
        self.horizontalLayout_138.setObjectName(u"horizontalLayout_138")
        self.model_installed_17 = QCheckBox(self.frame_201)
        self.model_installed_17.setObjectName(u"model_installed_17")
        self.model_installed_17.setEnabled(False)
        self.model_installed_17.setFont(font4)
        self.model_installed_17.setAutoFillBackground(False)
        self.model_installed_17.setIconSize(QSize(30, 30))
        self.model_installed_17.setCheckable(False)
        self.model_installed_17.setTristate(False)

        self.horizontalLayout_138.addWidget(self.model_installed_17)


        self.verticalLayout_125.addWidget(self.frame_201)

        self.frame_202 = QFrame(self.frame_199)
        self.frame_202.setObjectName(u"frame_202")
        self.frame_202.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_202.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_202.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_139 = QHBoxLayout(self.frame_202)
        self.horizontalLayout_139.setObjectName(u"horizontalLayout_139")
        self.checkpoints_downloaded_17 = QCheckBox(self.frame_202)
        self.checkpoints_downloaded_17.setObjectName(u"checkpoints_downloaded_17")
        self.checkpoints_downloaded_17.setEnabled(False)
        self.checkpoints_downloaded_17.setFont(font4)
        self.checkpoints_downloaded_17.setAutoFillBackground(False)
        self.checkpoints_downloaded_17.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_17.setCheckable(False)
        self.checkpoints_downloaded_17.setTristate(False)

        self.horizontalLayout_139.addWidget(self.checkpoints_downloaded_17)


        self.verticalLayout_125.addWidget(self.frame_202)


        self.horizontalLayout_137.addWidget(self.frame_199)


        self.verticalLayout_121.addWidget(self.frame_197)


        self.horizontalLayout_134.addWidget(self.frame_194)

        self.frame_203 = QFrame(self.frame_193)
        self.frame_203.setObjectName(u"frame_203")
        sizePolicy1.setHeightForWidth(self.frame_203.sizePolicy().hasHeightForWidth())
        self.frame_203.setSizePolicy(sizePolicy1)
        self.frame_203.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_203.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_127 = QVBoxLayout(self.frame_203)
        self.verticalLayout_127.setObjectName(u"verticalLayout_127")
        self.widget_51 = QWidget(self.frame_203)
        self.widget_51.setObjectName(u"widget_51")
        sizePolicy3.setHeightForWidth(self.widget_51.sizePolicy().hasHeightForWidth())
        self.widget_51.setSizePolicy(sizePolicy3)
        self.widget_51.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_140 = QHBoxLayout(self.widget_51)
        self.horizontalLayout_140.setObjectName(u"horizontalLayout_140")
        self.label_109 = QLabel(self.widget_51)
        self.label_109.setObjectName(u"label_109")
        self.label_109.setFont(font2)

        self.horizontalLayout_140.addWidget(self.label_109)

        self.frame_204 = QFrame(self.widget_51)
        self.frame_204.setObjectName(u"frame_204")
        sizePolicy4.setHeightForWidth(self.frame_204.sizePolicy().hasHeightForWidth())
        self.frame_204.setSizePolicy(sizePolicy4)
        self.frame_204.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_204.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_141 = QHBoxLayout(self.frame_204)
        self.horizontalLayout_141.setObjectName(u"horizontalLayout_141")
        self.label_110 = QLabel(self.frame_204)
        self.label_110.setObjectName(u"label_110")
        self.label_110.setFont(font2)

        self.horizontalLayout_141.addWidget(self.label_110)

        self.pushButton_34 = QPushButton(self.frame_204)
        self.pushButton_34.setObjectName(u"pushButton_34")
        self.pushButton_34.setMinimumSize(QSize(30, 30))
        self.pushButton_34.setMaximumSize(QSize(40, 40))
        self.pushButton_34.setIcon(icon1)
        self.pushButton_34.setIconSize(QSize(30, 30))

        self.horizontalLayout_141.addWidget(self.pushButton_34)


        self.horizontalLayout_140.addWidget(self.frame_204)


        self.verticalLayout_127.addWidget(self.widget_51)

        self.textEdit_17 = QTextEdit(self.frame_203)
        self.textEdit_17.setObjectName(u"textEdit_17")
        sizePolicy5.setHeightForWidth(self.textEdit_17.sizePolicy().hasHeightForWidth())
        self.textEdit_17.setSizePolicy(sizePolicy5)
        self.textEdit_17.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_17.setReadOnly(True)

        self.verticalLayout_127.addWidget(self.textEdit_17)


        self.horizontalLayout_134.addWidget(self.frame_203)


        self.verticalLayout_128.addWidget(self.frame_193)

        self.tabWidget.addTab(self.tab_17, "")
        self.tab_18 = QWidget()
        self.tab_18.setObjectName(u"tab_18")
        self.verticalLayout_136 = QVBoxLayout(self.tab_18)
        self.verticalLayout_136.setObjectName(u"verticalLayout_136")
        self.frame_205 = QFrame(self.tab_18)
        self.frame_205.setObjectName(u"frame_205")
        sizePolicy.setHeightForWidth(self.frame_205.sizePolicy().hasHeightForWidth())
        self.frame_205.setSizePolicy(sizePolicy)
        self.frame_205.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_205.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_142 = QHBoxLayout(self.frame_205)
        self.horizontalLayout_142.setObjectName(u"horizontalLayout_142")
        self.frame_206 = QFrame(self.frame_205)
        self.frame_206.setObjectName(u"frame_206")
        sizePolicy1.setHeightForWidth(self.frame_206.sizePolicy().hasHeightForWidth())
        self.frame_206.setSizePolicy(sizePolicy1)
        self.frame_206.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_206.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_129 = QVBoxLayout(self.frame_206)
        self.verticalLayout_129.setObjectName(u"verticalLayout_129")
        self.frame_207 = QFrame(self.frame_206)
        self.frame_207.setObjectName(u"frame_207")
        self.frame_207.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_207.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_207.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_130 = QVBoxLayout(self.frame_207)
        self.verticalLayout_130.setObjectName(u"verticalLayout_130")
        self.frame_208 = QFrame(self.frame_207)
        self.frame_208.setObjectName(u"frame_208")
        self.frame_208.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_208.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_143 = QHBoxLayout(self.frame_208)
        self.horizontalLayout_143.setObjectName(u"horizontalLayout_143")
        self.label_111 = QLabel(self.frame_208)
        self.label_111.setObjectName(u"label_111")
        self.label_111.setFont(font5)
        self.label_111.setTextFormat(Qt.TextFormat.PlainText)
        self.label_111.setScaledContents(False)

        self.horizontalLayout_143.addWidget(self.label_111)

        self.label_112 = QLabel(self.frame_208)
        self.label_112.setObjectName(u"label_112")
        self.label_112.setFont(font2)

        self.horizontalLayout_143.addWidget(self.label_112)


        self.verticalLayout_130.addWidget(self.frame_208)

        self.widget_52 = QWidget(self.frame_207)
        self.widget_52.setObjectName(u"widget_52")
        sizePolicy2.setHeightForWidth(self.widget_52.sizePolicy().hasHeightForWidth())
        self.widget_52.setSizePolicy(sizePolicy2)
        self.horizontalLayout_144 = QHBoxLayout(self.widget_52)
        self.horizontalLayout_144.setObjectName(u"horizontalLayout_144")
        self.pushButton_35 = QPushButton(self.widget_52)
        self.pushButton_35.setObjectName(u"pushButton_35")
        self.pushButton_35.setMinimumSize(QSize(46, 46))
        self.pushButton_35.setMaximumSize(QSize(60, 16777215))
        self.pushButton_35.setIcon(icon)
        self.pushButton_35.setIconSize(QSize(30, 30))

        self.horizontalLayout_144.addWidget(self.pushButton_35)

        self.label_113 = QLabel(self.widget_52)
        self.label_113.setObjectName(u"label_113")
        self.label_113.setMinimumSize(QSize(2, 33))
        self.label_113.setMaximumSize(QSize(16777215, 33))
        self.label_113.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_144.addWidget(self.label_113)


        self.verticalLayout_130.addWidget(self.widget_52)


        self.verticalLayout_129.addWidget(self.frame_207)

        self.frame_209 = QFrame(self.frame_206)
        self.frame_209.setObjectName(u"frame_209")
        self.frame_209.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_209.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_145 = QHBoxLayout(self.frame_209)
        self.horizontalLayout_145.setObjectName(u"horizontalLayout_145")
        self.frame_210 = QFrame(self.frame_209)
        self.frame_210.setObjectName(u"frame_210")
        self.frame_210.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_210.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_210.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_131 = QVBoxLayout(self.frame_210)
        self.verticalLayout_131.setObjectName(u"verticalLayout_131")
        self.label_114 = QLabel(self.frame_210)
        self.label_114.setObjectName(u"label_114")
        self.label_114.setFont(font2)

        self.verticalLayout_131.addWidget(self.label_114, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_53 = QWidget(self.frame_210)
        self.widget_53.setObjectName(u"widget_53")
        sizePolicy2.setHeightForWidth(self.widget_53.sizePolicy().hasHeightForWidth())
        self.widget_53.setSizePolicy(sizePolicy2)
        self.widget_53.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_132 = QVBoxLayout(self.widget_53)
        self.verticalLayout_132.setObjectName(u"verticalLayout_132")
        self.radioButton_59 = QRadioButton(self.widget_53)
        self.radioButton_59.setObjectName(u"radioButton_59")
        self.radioButton_59.setFont(font3)

        self.verticalLayout_132.addWidget(self.radioButton_59)

        self.radioButton_60 = QRadioButton(self.widget_53)
        self.radioButton_60.setObjectName(u"radioButton_60")
        self.radioButton_60.setFont(font3)

        self.verticalLayout_132.addWidget(self.radioButton_60)


        self.verticalLayout_131.addWidget(self.widget_53)


        self.horizontalLayout_145.addWidget(self.frame_210)

        self.frame_211 = QFrame(self.frame_209)
        self.frame_211.setObjectName(u"frame_211")
        sizePolicy1.setHeightForWidth(self.frame_211.sizePolicy().hasHeightForWidth())
        self.frame_211.setSizePolicy(sizePolicy1)
        self.frame_211.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_211.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_133 = QVBoxLayout(self.frame_211)
        self.verticalLayout_133.setObjectName(u"verticalLayout_133")
        self.frame_212 = QFrame(self.frame_211)
        self.frame_212.setObjectName(u"frame_212")
        sizePolicy4.setHeightForWidth(self.frame_212.sizePolicy().hasHeightForWidth())
        self.frame_212.setSizePolicy(sizePolicy4)
        self.frame_212.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_212.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_134 = QVBoxLayout(self.frame_212)
        self.verticalLayout_134.setObjectName(u"verticalLayout_134")
        self.radioButton_61 = QRadioButton(self.frame_212)
        self.radioButton_61.setObjectName(u"radioButton_61")

        self.verticalLayout_134.addWidget(self.radioButton_61)

        self.radioButton_62 = QRadioButton(self.frame_212)
        self.radioButton_62.setObjectName(u"radioButton_62")

        self.verticalLayout_134.addWidget(self.radioButton_62)

        self.radioButton_63 = QRadioButton(self.frame_212)
        self.radioButton_63.setObjectName(u"radioButton_63")

        self.verticalLayout_134.addWidget(self.radioButton_63)


        self.verticalLayout_133.addWidget(self.frame_212, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_213 = QFrame(self.frame_211)
        self.frame_213.setObjectName(u"frame_213")
        self.frame_213.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_213.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_213.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_146 = QHBoxLayout(self.frame_213)
        self.horizontalLayout_146.setObjectName(u"horizontalLayout_146")
        self.model_installed_18 = QCheckBox(self.frame_213)
        self.model_installed_18.setObjectName(u"model_installed_18")
        self.model_installed_18.setEnabled(False)
        self.model_installed_18.setFont(font4)
        self.model_installed_18.setAutoFillBackground(False)
        self.model_installed_18.setIconSize(QSize(30, 30))
        self.model_installed_18.setCheckable(False)
        self.model_installed_18.setTristate(False)

        self.horizontalLayout_146.addWidget(self.model_installed_18)


        self.verticalLayout_133.addWidget(self.frame_213)

        self.frame_214 = QFrame(self.frame_211)
        self.frame_214.setObjectName(u"frame_214")
        self.frame_214.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_214.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_214.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_147 = QHBoxLayout(self.frame_214)
        self.horizontalLayout_147.setObjectName(u"horizontalLayout_147")
        self.checkpoints_downloaded_18 = QCheckBox(self.frame_214)
        self.checkpoints_downloaded_18.setObjectName(u"checkpoints_downloaded_18")
        self.checkpoints_downloaded_18.setEnabled(False)
        self.checkpoints_downloaded_18.setFont(font4)
        self.checkpoints_downloaded_18.setAutoFillBackground(False)
        self.checkpoints_downloaded_18.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_18.setCheckable(False)
        self.checkpoints_downloaded_18.setTristate(False)

        self.horizontalLayout_147.addWidget(self.checkpoints_downloaded_18)


        self.verticalLayout_133.addWidget(self.frame_214)


        self.horizontalLayout_145.addWidget(self.frame_211)


        self.verticalLayout_129.addWidget(self.frame_209)


        self.horizontalLayout_142.addWidget(self.frame_206)

        self.frame_215 = QFrame(self.frame_205)
        self.frame_215.setObjectName(u"frame_215")
        sizePolicy1.setHeightForWidth(self.frame_215.sizePolicy().hasHeightForWidth())
        self.frame_215.setSizePolicy(sizePolicy1)
        self.frame_215.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_215.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_135 = QVBoxLayout(self.frame_215)
        self.verticalLayout_135.setObjectName(u"verticalLayout_135")
        self.widget_54 = QWidget(self.frame_215)
        self.widget_54.setObjectName(u"widget_54")
        sizePolicy3.setHeightForWidth(self.widget_54.sizePolicy().hasHeightForWidth())
        self.widget_54.setSizePolicy(sizePolicy3)
        self.widget_54.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_148 = QHBoxLayout(self.widget_54)
        self.horizontalLayout_148.setObjectName(u"horizontalLayout_148")
        self.label_115 = QLabel(self.widget_54)
        self.label_115.setObjectName(u"label_115")
        self.label_115.setFont(font2)

        self.horizontalLayout_148.addWidget(self.label_115)

        self.frame_216 = QFrame(self.widget_54)
        self.frame_216.setObjectName(u"frame_216")
        sizePolicy4.setHeightForWidth(self.frame_216.sizePolicy().hasHeightForWidth())
        self.frame_216.setSizePolicy(sizePolicy4)
        self.frame_216.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_216.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_149 = QHBoxLayout(self.frame_216)
        self.horizontalLayout_149.setObjectName(u"horizontalLayout_149")
        self.label_116 = QLabel(self.frame_216)
        self.label_116.setObjectName(u"label_116")
        self.label_116.setFont(font2)

        self.horizontalLayout_149.addWidget(self.label_116)

        self.pushButton_36 = QPushButton(self.frame_216)
        self.pushButton_36.setObjectName(u"pushButton_36")
        self.pushButton_36.setMinimumSize(QSize(30, 30))
        self.pushButton_36.setMaximumSize(QSize(40, 40))
        self.pushButton_36.setIcon(icon1)
        self.pushButton_36.setIconSize(QSize(30, 30))

        self.horizontalLayout_149.addWidget(self.pushButton_36)


        self.horizontalLayout_148.addWidget(self.frame_216)


        self.verticalLayout_135.addWidget(self.widget_54)

        self.textEdit_18 = QTextEdit(self.frame_215)
        self.textEdit_18.setObjectName(u"textEdit_18")
        sizePolicy5.setHeightForWidth(self.textEdit_18.sizePolicy().hasHeightForWidth())
        self.textEdit_18.setSizePolicy(sizePolicy5)
        self.textEdit_18.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_18.setReadOnly(True)

        self.verticalLayout_135.addWidget(self.textEdit_18)


        self.horizontalLayout_142.addWidget(self.frame_215)


        self.verticalLayout_136.addWidget(self.frame_205)

        self.tabWidget.addTab(self.tab_18, "")
        self.tab_19 = QWidget()
        self.tab_19.setObjectName(u"tab_19")
        self.verticalLayout_144 = QVBoxLayout(self.tab_19)
        self.verticalLayout_144.setObjectName(u"verticalLayout_144")
        self.frame_217 = QFrame(self.tab_19)
        self.frame_217.setObjectName(u"frame_217")
        sizePolicy.setHeightForWidth(self.frame_217.sizePolicy().hasHeightForWidth())
        self.frame_217.setSizePolicy(sizePolicy)
        self.frame_217.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_217.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_150 = QHBoxLayout(self.frame_217)
        self.horizontalLayout_150.setObjectName(u"horizontalLayout_150")
        self.frame_218 = QFrame(self.frame_217)
        self.frame_218.setObjectName(u"frame_218")
        sizePolicy1.setHeightForWidth(self.frame_218.sizePolicy().hasHeightForWidth())
        self.frame_218.setSizePolicy(sizePolicy1)
        self.frame_218.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_218.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_137 = QVBoxLayout(self.frame_218)
        self.verticalLayout_137.setObjectName(u"verticalLayout_137")
        self.frame_219 = QFrame(self.frame_218)
        self.frame_219.setObjectName(u"frame_219")
        self.frame_219.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_219.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_219.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_138 = QVBoxLayout(self.frame_219)
        self.verticalLayout_138.setObjectName(u"verticalLayout_138")
        self.frame_220 = QFrame(self.frame_219)
        self.frame_220.setObjectName(u"frame_220")
        self.frame_220.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_220.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_151 = QHBoxLayout(self.frame_220)
        self.horizontalLayout_151.setObjectName(u"horizontalLayout_151")
        self.label_117 = QLabel(self.frame_220)
        self.label_117.setObjectName(u"label_117")
        self.label_117.setFont(font5)
        self.label_117.setTextFormat(Qt.TextFormat.PlainText)
        self.label_117.setScaledContents(False)

        self.horizontalLayout_151.addWidget(self.label_117)

        self.label_118 = QLabel(self.frame_220)
        self.label_118.setObjectName(u"label_118")
        self.label_118.setFont(font2)

        self.horizontalLayout_151.addWidget(self.label_118)


        self.verticalLayout_138.addWidget(self.frame_220)

        self.widget_55 = QWidget(self.frame_219)
        self.widget_55.setObjectName(u"widget_55")
        sizePolicy2.setHeightForWidth(self.widget_55.sizePolicy().hasHeightForWidth())
        self.widget_55.setSizePolicy(sizePolicy2)
        self.horizontalLayout_152 = QHBoxLayout(self.widget_55)
        self.horizontalLayout_152.setObjectName(u"horizontalLayout_152")
        self.pushButton_37 = QPushButton(self.widget_55)
        self.pushButton_37.setObjectName(u"pushButton_37")
        self.pushButton_37.setMinimumSize(QSize(46, 46))
        self.pushButton_37.setMaximumSize(QSize(60, 16777215))
        self.pushButton_37.setIcon(icon)
        self.pushButton_37.setIconSize(QSize(30, 30))

        self.horizontalLayout_152.addWidget(self.pushButton_37)

        self.label_119 = QLabel(self.widget_55)
        self.label_119.setObjectName(u"label_119")
        self.label_119.setMinimumSize(QSize(2, 33))
        self.label_119.setMaximumSize(QSize(16777215, 33))
        self.label_119.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_152.addWidget(self.label_119)


        self.verticalLayout_138.addWidget(self.widget_55)


        self.verticalLayout_137.addWidget(self.frame_219)

        self.frame_221 = QFrame(self.frame_218)
        self.frame_221.setObjectName(u"frame_221")
        self.frame_221.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_221.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_153 = QHBoxLayout(self.frame_221)
        self.horizontalLayout_153.setObjectName(u"horizontalLayout_153")
        self.frame_222 = QFrame(self.frame_221)
        self.frame_222.setObjectName(u"frame_222")
        self.frame_222.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_222.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_222.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_139 = QVBoxLayout(self.frame_222)
        self.verticalLayout_139.setObjectName(u"verticalLayout_139")
        self.label_120 = QLabel(self.frame_222)
        self.label_120.setObjectName(u"label_120")
        self.label_120.setFont(font2)

        self.verticalLayout_139.addWidget(self.label_120, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_56 = QWidget(self.frame_222)
        self.widget_56.setObjectName(u"widget_56")
        sizePolicy2.setHeightForWidth(self.widget_56.sizePolicy().hasHeightForWidth())
        self.widget_56.setSizePolicy(sizePolicy2)
        self.widget_56.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_140 = QVBoxLayout(self.widget_56)
        self.verticalLayout_140.setObjectName(u"verticalLayout_140")
        self.radioButton_64 = QRadioButton(self.widget_56)
        self.radioButton_64.setObjectName(u"radioButton_64")
        self.radioButton_64.setFont(font3)

        self.verticalLayout_140.addWidget(self.radioButton_64)

        self.radioButton_65 = QRadioButton(self.widget_56)
        self.radioButton_65.setObjectName(u"radioButton_65")
        self.radioButton_65.setFont(font3)

        self.verticalLayout_140.addWidget(self.radioButton_65)


        self.verticalLayout_139.addWidget(self.widget_56)


        self.horizontalLayout_153.addWidget(self.frame_222)

        self.frame_223 = QFrame(self.frame_221)
        self.frame_223.setObjectName(u"frame_223")
        sizePolicy1.setHeightForWidth(self.frame_223.sizePolicy().hasHeightForWidth())
        self.frame_223.setSizePolicy(sizePolicy1)
        self.frame_223.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_223.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_141 = QVBoxLayout(self.frame_223)
        self.verticalLayout_141.setObjectName(u"verticalLayout_141")
        self.frame_224 = QFrame(self.frame_223)
        self.frame_224.setObjectName(u"frame_224")
        sizePolicy4.setHeightForWidth(self.frame_224.sizePolicy().hasHeightForWidth())
        self.frame_224.setSizePolicy(sizePolicy4)
        self.frame_224.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_224.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_142 = QVBoxLayout(self.frame_224)
        self.verticalLayout_142.setObjectName(u"verticalLayout_142")
        self.radioButton_66 = QRadioButton(self.frame_224)
        self.radioButton_66.setObjectName(u"radioButton_66")

        self.verticalLayout_142.addWidget(self.radioButton_66)

        self.radioButton_67 = QRadioButton(self.frame_224)
        self.radioButton_67.setObjectName(u"radioButton_67")

        self.verticalLayout_142.addWidget(self.radioButton_67)


        self.verticalLayout_141.addWidget(self.frame_224, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_225 = QFrame(self.frame_223)
        self.frame_225.setObjectName(u"frame_225")
        self.frame_225.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_225.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_225.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_154 = QHBoxLayout(self.frame_225)
        self.horizontalLayout_154.setObjectName(u"horizontalLayout_154")
        self.model_installed_19 = QCheckBox(self.frame_225)
        self.model_installed_19.setObjectName(u"model_installed_19")
        self.model_installed_19.setEnabled(False)
        self.model_installed_19.setFont(font4)
        self.model_installed_19.setAutoFillBackground(False)
        self.model_installed_19.setIconSize(QSize(30, 30))
        self.model_installed_19.setCheckable(False)
        self.model_installed_19.setTristate(False)

        self.horizontalLayout_154.addWidget(self.model_installed_19)


        self.verticalLayout_141.addWidget(self.frame_225)

        self.frame_226 = QFrame(self.frame_223)
        self.frame_226.setObjectName(u"frame_226")
        self.frame_226.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_226.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_226.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_155 = QHBoxLayout(self.frame_226)
        self.horizontalLayout_155.setObjectName(u"horizontalLayout_155")
        self.checkpoints_downloaded_19 = QCheckBox(self.frame_226)
        self.checkpoints_downloaded_19.setObjectName(u"checkpoints_downloaded_19")
        self.checkpoints_downloaded_19.setEnabled(False)
        self.checkpoints_downloaded_19.setFont(font4)
        self.checkpoints_downloaded_19.setAutoFillBackground(False)
        self.checkpoints_downloaded_19.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_19.setCheckable(False)
        self.checkpoints_downloaded_19.setTristate(False)

        self.horizontalLayout_155.addWidget(self.checkpoints_downloaded_19)


        self.verticalLayout_141.addWidget(self.frame_226)


        self.horizontalLayout_153.addWidget(self.frame_223)


        self.verticalLayout_137.addWidget(self.frame_221)


        self.horizontalLayout_150.addWidget(self.frame_218)

        self.frame_227 = QFrame(self.frame_217)
        self.frame_227.setObjectName(u"frame_227")
        sizePolicy1.setHeightForWidth(self.frame_227.sizePolicy().hasHeightForWidth())
        self.frame_227.setSizePolicy(sizePolicy1)
        self.frame_227.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_227.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_143 = QVBoxLayout(self.frame_227)
        self.verticalLayout_143.setObjectName(u"verticalLayout_143")
        self.widget_57 = QWidget(self.frame_227)
        self.widget_57.setObjectName(u"widget_57")
        sizePolicy3.setHeightForWidth(self.widget_57.sizePolicy().hasHeightForWidth())
        self.widget_57.setSizePolicy(sizePolicy3)
        self.widget_57.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_156 = QHBoxLayout(self.widget_57)
        self.horizontalLayout_156.setObjectName(u"horizontalLayout_156")
        self.label_121 = QLabel(self.widget_57)
        self.label_121.setObjectName(u"label_121")
        self.label_121.setFont(font2)

        self.horizontalLayout_156.addWidget(self.label_121)

        self.frame_228 = QFrame(self.widget_57)
        self.frame_228.setObjectName(u"frame_228")
        sizePolicy4.setHeightForWidth(self.frame_228.sizePolicy().hasHeightForWidth())
        self.frame_228.setSizePolicy(sizePolicy4)
        self.frame_228.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_228.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_157 = QHBoxLayout(self.frame_228)
        self.horizontalLayout_157.setObjectName(u"horizontalLayout_157")
        self.label_122 = QLabel(self.frame_228)
        self.label_122.setObjectName(u"label_122")
        self.label_122.setFont(font2)

        self.horizontalLayout_157.addWidget(self.label_122)

        self.pushButton_38 = QPushButton(self.frame_228)
        self.pushButton_38.setObjectName(u"pushButton_38")
        self.pushButton_38.setMinimumSize(QSize(30, 30))
        self.pushButton_38.setMaximumSize(QSize(40, 40))
        self.pushButton_38.setIcon(icon1)
        self.pushButton_38.setIconSize(QSize(30, 30))

        self.horizontalLayout_157.addWidget(self.pushButton_38)


        self.horizontalLayout_156.addWidget(self.frame_228)


        self.verticalLayout_143.addWidget(self.widget_57)

        self.textEdit_19 = QTextEdit(self.frame_227)
        self.textEdit_19.setObjectName(u"textEdit_19")
        sizePolicy5.setHeightForWidth(self.textEdit_19.sizePolicy().hasHeightForWidth())
        self.textEdit_19.setSizePolicy(sizePolicy5)
        self.textEdit_19.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_19.setReadOnly(True)

        self.verticalLayout_143.addWidget(self.textEdit_19)


        self.horizontalLayout_150.addWidget(self.frame_227)


        self.verticalLayout_144.addWidget(self.frame_217)

        self.tabWidget.addTab(self.tab_19, "")
        self.tab_20 = QWidget()
        self.tab_20.setObjectName(u"tab_20")
        self.verticalLayout_152 = QVBoxLayout(self.tab_20)
        self.verticalLayout_152.setObjectName(u"verticalLayout_152")
        self.frame_229 = QFrame(self.tab_20)
        self.frame_229.setObjectName(u"frame_229")
        sizePolicy.setHeightForWidth(self.frame_229.sizePolicy().hasHeightForWidth())
        self.frame_229.setSizePolicy(sizePolicy)
        self.frame_229.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_229.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_158 = QHBoxLayout(self.frame_229)
        self.horizontalLayout_158.setObjectName(u"horizontalLayout_158")
        self.frame_230 = QFrame(self.frame_229)
        self.frame_230.setObjectName(u"frame_230")
        sizePolicy1.setHeightForWidth(self.frame_230.sizePolicy().hasHeightForWidth())
        self.frame_230.setSizePolicy(sizePolicy1)
        self.frame_230.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_230.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_145 = QVBoxLayout(self.frame_230)
        self.verticalLayout_145.setObjectName(u"verticalLayout_145")
        self.frame_231 = QFrame(self.frame_230)
        self.frame_231.setObjectName(u"frame_231")
        self.frame_231.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_231.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_231.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_146 = QVBoxLayout(self.frame_231)
        self.verticalLayout_146.setObjectName(u"verticalLayout_146")
        self.frame_232 = QFrame(self.frame_231)
        self.frame_232.setObjectName(u"frame_232")
        self.frame_232.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_232.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_159 = QHBoxLayout(self.frame_232)
        self.horizontalLayout_159.setObjectName(u"horizontalLayout_159")
        self.label_123 = QLabel(self.frame_232)
        self.label_123.setObjectName(u"label_123")
        self.label_123.setFont(font5)
        self.label_123.setTextFormat(Qt.TextFormat.PlainText)
        self.label_123.setScaledContents(False)

        self.horizontalLayout_159.addWidget(self.label_123)

        self.label_124 = QLabel(self.frame_232)
        self.label_124.setObjectName(u"label_124")
        self.label_124.setFont(font2)

        self.horizontalLayout_159.addWidget(self.label_124)


        self.verticalLayout_146.addWidget(self.frame_232)

        self.widget_58 = QWidget(self.frame_231)
        self.widget_58.setObjectName(u"widget_58")
        sizePolicy2.setHeightForWidth(self.widget_58.sizePolicy().hasHeightForWidth())
        self.widget_58.setSizePolicy(sizePolicy2)
        self.horizontalLayout_160 = QHBoxLayout(self.widget_58)
        self.horizontalLayout_160.setObjectName(u"horizontalLayout_160")
        self.pushButton_39 = QPushButton(self.widget_58)
        self.pushButton_39.setObjectName(u"pushButton_39")
        self.pushButton_39.setMinimumSize(QSize(46, 46))
        self.pushButton_39.setMaximumSize(QSize(60, 16777215))
        self.pushButton_39.setIcon(icon)
        self.pushButton_39.setIconSize(QSize(30, 30))

        self.horizontalLayout_160.addWidget(self.pushButton_39)

        self.label_125 = QLabel(self.widget_58)
        self.label_125.setObjectName(u"label_125")
        self.label_125.setMinimumSize(QSize(2, 33))
        self.label_125.setMaximumSize(QSize(16777215, 33))
        self.label_125.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_160.addWidget(self.label_125)


        self.verticalLayout_146.addWidget(self.widget_58)


        self.verticalLayout_145.addWidget(self.frame_231)

        self.frame_233 = QFrame(self.frame_230)
        self.frame_233.setObjectName(u"frame_233")
        self.frame_233.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_233.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_161 = QHBoxLayout(self.frame_233)
        self.horizontalLayout_161.setObjectName(u"horizontalLayout_161")
        self.frame_234 = QFrame(self.frame_233)
        self.frame_234.setObjectName(u"frame_234")
        self.frame_234.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_234.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_234.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_147 = QVBoxLayout(self.frame_234)
        self.verticalLayout_147.setObjectName(u"verticalLayout_147")
        self.label_126 = QLabel(self.frame_234)
        self.label_126.setObjectName(u"label_126")
        self.label_126.setFont(font2)

        self.verticalLayout_147.addWidget(self.label_126, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_59 = QWidget(self.frame_234)
        self.widget_59.setObjectName(u"widget_59")
        sizePolicy2.setHeightForWidth(self.widget_59.sizePolicy().hasHeightForWidth())
        self.widget_59.setSizePolicy(sizePolicy2)
        self.widget_59.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_148 = QVBoxLayout(self.widget_59)
        self.verticalLayout_148.setObjectName(u"verticalLayout_148")
        self.radioButton_68 = QRadioButton(self.widget_59)
        self.radioButton_68.setObjectName(u"radioButton_68")
        self.radioButton_68.setFont(font3)

        self.verticalLayout_148.addWidget(self.radioButton_68)

        self.radioButton_69 = QRadioButton(self.widget_59)
        self.radioButton_69.setObjectName(u"radioButton_69")
        self.radioButton_69.setFont(font3)

        self.verticalLayout_148.addWidget(self.radioButton_69)


        self.verticalLayout_147.addWidget(self.widget_59)


        self.horizontalLayout_161.addWidget(self.frame_234)

        self.frame_235 = QFrame(self.frame_233)
        self.frame_235.setObjectName(u"frame_235")
        sizePolicy1.setHeightForWidth(self.frame_235.sizePolicy().hasHeightForWidth())
        self.frame_235.setSizePolicy(sizePolicy1)
        self.frame_235.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_235.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_149 = QVBoxLayout(self.frame_235)
        self.verticalLayout_149.setObjectName(u"verticalLayout_149")
        self.frame_236 = QFrame(self.frame_235)
        self.frame_236.setObjectName(u"frame_236")
        sizePolicy4.setHeightForWidth(self.frame_236.sizePolicy().hasHeightForWidth())
        self.frame_236.setSizePolicy(sizePolicy4)
        self.frame_236.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_236.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_150 = QVBoxLayout(self.frame_236)
        self.verticalLayout_150.setObjectName(u"verticalLayout_150")
        self.radioButton_70 = QRadioButton(self.frame_236)
        self.radioButton_70.setObjectName(u"radioButton_70")

        self.verticalLayout_150.addWidget(self.radioButton_70)

        self.radioButton_75 = QRadioButton(self.frame_236)
        self.radioButton_75.setObjectName(u"radioButton_75")

        self.verticalLayout_150.addWidget(self.radioButton_75)

        self.radioButton_71 = QRadioButton(self.frame_236)
        self.radioButton_71.setObjectName(u"radioButton_71")

        self.verticalLayout_150.addWidget(self.radioButton_71)

        self.radioButton_78 = QRadioButton(self.frame_236)
        self.radioButton_78.setObjectName(u"radioButton_78")

        self.verticalLayout_150.addWidget(self.radioButton_78)

        self.radioButton_77 = QRadioButton(self.frame_236)
        self.radioButton_77.setObjectName(u"radioButton_77")

        self.verticalLayout_150.addWidget(self.radioButton_77)

        self.radioButton_76 = QRadioButton(self.frame_236)
        self.radioButton_76.setObjectName(u"radioButton_76")

        self.verticalLayout_150.addWidget(self.radioButton_76)

        self.radioButton_74 = QRadioButton(self.frame_236)
        self.radioButton_74.setObjectName(u"radioButton_74")

        self.verticalLayout_150.addWidget(self.radioButton_74)

        self.radioButton_73 = QRadioButton(self.frame_236)
        self.radioButton_73.setObjectName(u"radioButton_73")

        self.verticalLayout_150.addWidget(self.radioButton_73)

        self.radioButton_72 = QRadioButton(self.frame_236)
        self.radioButton_72.setObjectName(u"radioButton_72")

        self.verticalLayout_150.addWidget(self.radioButton_72)


        self.verticalLayout_149.addWidget(self.frame_236, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_237 = QFrame(self.frame_235)
        self.frame_237.setObjectName(u"frame_237")
        self.frame_237.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_237.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_237.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_162 = QHBoxLayout(self.frame_237)
        self.horizontalLayout_162.setObjectName(u"horizontalLayout_162")
        self.model_installed_20 = QCheckBox(self.frame_237)
        self.model_installed_20.setObjectName(u"model_installed_20")
        self.model_installed_20.setEnabled(False)
        self.model_installed_20.setFont(font4)
        self.model_installed_20.setAutoFillBackground(False)
        self.model_installed_20.setIconSize(QSize(30, 30))
        self.model_installed_20.setCheckable(False)
        self.model_installed_20.setTristate(False)

        self.horizontalLayout_162.addWidget(self.model_installed_20)


        self.verticalLayout_149.addWidget(self.frame_237)

        self.frame_238 = QFrame(self.frame_235)
        self.frame_238.setObjectName(u"frame_238")
        self.frame_238.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_238.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_238.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_163 = QHBoxLayout(self.frame_238)
        self.horizontalLayout_163.setObjectName(u"horizontalLayout_163")
        self.checkpoints_downloaded_20 = QCheckBox(self.frame_238)
        self.checkpoints_downloaded_20.setObjectName(u"checkpoints_downloaded_20")
        self.checkpoints_downloaded_20.setEnabled(False)
        self.checkpoints_downloaded_20.setFont(font4)
        self.checkpoints_downloaded_20.setAutoFillBackground(False)
        self.checkpoints_downloaded_20.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_20.setCheckable(False)
        self.checkpoints_downloaded_20.setTristate(False)

        self.horizontalLayout_163.addWidget(self.checkpoints_downloaded_20)


        self.verticalLayout_149.addWidget(self.frame_238)


        self.horizontalLayout_161.addWidget(self.frame_235)


        self.verticalLayout_145.addWidget(self.frame_233)


        self.horizontalLayout_158.addWidget(self.frame_230)

        self.frame_239 = QFrame(self.frame_229)
        self.frame_239.setObjectName(u"frame_239")
        sizePolicy1.setHeightForWidth(self.frame_239.sizePolicy().hasHeightForWidth())
        self.frame_239.setSizePolicy(sizePolicy1)
        self.frame_239.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_239.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_151 = QVBoxLayout(self.frame_239)
        self.verticalLayout_151.setObjectName(u"verticalLayout_151")
        self.widget_60 = QWidget(self.frame_239)
        self.widget_60.setObjectName(u"widget_60")
        sizePolicy3.setHeightForWidth(self.widget_60.sizePolicy().hasHeightForWidth())
        self.widget_60.setSizePolicy(sizePolicy3)
        self.widget_60.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_164 = QHBoxLayout(self.widget_60)
        self.horizontalLayout_164.setObjectName(u"horizontalLayout_164")
        self.label_127 = QLabel(self.widget_60)
        self.label_127.setObjectName(u"label_127")
        self.label_127.setFont(font2)

        self.horizontalLayout_164.addWidget(self.label_127)

        self.frame_240 = QFrame(self.widget_60)
        self.frame_240.setObjectName(u"frame_240")
        sizePolicy4.setHeightForWidth(self.frame_240.sizePolicy().hasHeightForWidth())
        self.frame_240.setSizePolicy(sizePolicy4)
        self.frame_240.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_240.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_165 = QHBoxLayout(self.frame_240)
        self.horizontalLayout_165.setObjectName(u"horizontalLayout_165")
        self.label_128 = QLabel(self.frame_240)
        self.label_128.setObjectName(u"label_128")
        self.label_128.setFont(font2)

        self.horizontalLayout_165.addWidget(self.label_128)

        self.pushButton_40 = QPushButton(self.frame_240)
        self.pushButton_40.setObjectName(u"pushButton_40")
        self.pushButton_40.setMinimumSize(QSize(30, 30))
        self.pushButton_40.setMaximumSize(QSize(40, 40))
        self.pushButton_40.setIcon(icon1)
        self.pushButton_40.setIconSize(QSize(30, 30))

        self.horizontalLayout_165.addWidget(self.pushButton_40)


        self.horizontalLayout_164.addWidget(self.frame_240)


        self.verticalLayout_151.addWidget(self.widget_60)

        self.textEdit_20 = QTextEdit(self.frame_239)
        self.textEdit_20.setObjectName(u"textEdit_20")
        sizePolicy5.setHeightForWidth(self.textEdit_20.sizePolicy().hasHeightForWidth())
        self.textEdit_20.setSizePolicy(sizePolicy5)
        self.textEdit_20.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_20.setReadOnly(True)

        self.verticalLayout_151.addWidget(self.textEdit_20)


        self.horizontalLayout_158.addWidget(self.frame_239)


        self.verticalLayout_152.addWidget(self.frame_229)

        self.tabWidget.addTab(self.tab_20, "")
        self.tab_21 = QWidget()
        self.tab_21.setObjectName(u"tab_21")
        self.verticalLayout_159 = QVBoxLayout(self.tab_21)
        self.verticalLayout_159.setObjectName(u"verticalLayout_159")
        self.frame_241 = QFrame(self.tab_21)
        self.frame_241.setObjectName(u"frame_241")
        sizePolicy.setHeightForWidth(self.frame_241.sizePolicy().hasHeightForWidth())
        self.frame_241.setSizePolicy(sizePolicy)
        self.frame_241.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_241.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_166 = QHBoxLayout(self.frame_241)
        self.horizontalLayout_166.setObjectName(u"horizontalLayout_166")
        self.frame_242 = QFrame(self.frame_241)
        self.frame_242.setObjectName(u"frame_242")
        sizePolicy1.setHeightForWidth(self.frame_242.sizePolicy().hasHeightForWidth())
        self.frame_242.setSizePolicy(sizePolicy1)
        self.frame_242.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_242.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_153 = QVBoxLayout(self.frame_242)
        self.verticalLayout_153.setObjectName(u"verticalLayout_153")
        self.frame_243 = QFrame(self.frame_242)
        self.frame_243.setObjectName(u"frame_243")
        self.frame_243.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_243.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_243.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_154 = QVBoxLayout(self.frame_243)
        self.verticalLayout_154.setObjectName(u"verticalLayout_154")
        self.frame_244 = QFrame(self.frame_243)
        self.frame_244.setObjectName(u"frame_244")
        self.frame_244.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_244.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_167 = QHBoxLayout(self.frame_244)
        self.horizontalLayout_167.setObjectName(u"horizontalLayout_167")
        self.label_129 = QLabel(self.frame_244)
        self.label_129.setObjectName(u"label_129")
        self.label_129.setFont(font5)
        self.label_129.setTextFormat(Qt.TextFormat.PlainText)
        self.label_129.setScaledContents(False)

        self.horizontalLayout_167.addWidget(self.label_129)

        self.label_130 = QLabel(self.frame_244)
        self.label_130.setObjectName(u"label_130")
        self.label_130.setFont(font2)

        self.horizontalLayout_167.addWidget(self.label_130)


        self.verticalLayout_154.addWidget(self.frame_244)

        self.widget_61 = QWidget(self.frame_243)
        self.widget_61.setObjectName(u"widget_61")
        sizePolicy2.setHeightForWidth(self.widget_61.sizePolicy().hasHeightForWidth())
        self.widget_61.setSizePolicy(sizePolicy2)
        self.horizontalLayout_168 = QHBoxLayout(self.widget_61)
        self.horizontalLayout_168.setObjectName(u"horizontalLayout_168")
        self.pushButton_41 = QPushButton(self.widget_61)
        self.pushButton_41.setObjectName(u"pushButton_41")
        self.pushButton_41.setMinimumSize(QSize(46, 46))
        self.pushButton_41.setMaximumSize(QSize(60, 16777215))
        self.pushButton_41.setIcon(icon)
        self.pushButton_41.setIconSize(QSize(30, 30))

        self.horizontalLayout_168.addWidget(self.pushButton_41)

        self.label_131 = QLabel(self.widget_61)
        self.label_131.setObjectName(u"label_131")
        self.label_131.setMinimumSize(QSize(2, 33))
        self.label_131.setMaximumSize(QSize(16777215, 33))
        self.label_131.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_168.addWidget(self.label_131)


        self.verticalLayout_154.addWidget(self.widget_61)


        self.verticalLayout_153.addWidget(self.frame_243)

        self.frame_245 = QFrame(self.frame_242)
        self.frame_245.setObjectName(u"frame_245")
        self.frame_245.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_245.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_169 = QHBoxLayout(self.frame_245)
        self.horizontalLayout_169.setObjectName(u"horizontalLayout_169")
        self.frame_246 = QFrame(self.frame_245)
        self.frame_246.setObjectName(u"frame_246")
        self.frame_246.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_246.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_246.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_155 = QVBoxLayout(self.frame_246)
        self.verticalLayout_155.setObjectName(u"verticalLayout_155")
        self.label_132 = QLabel(self.frame_246)
        self.label_132.setObjectName(u"label_132")
        self.label_132.setFont(font2)

        self.verticalLayout_155.addWidget(self.label_132, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_62 = QWidget(self.frame_246)
        self.widget_62.setObjectName(u"widget_62")
        sizePolicy2.setHeightForWidth(self.widget_62.sizePolicy().hasHeightForWidth())
        self.widget_62.setSizePolicy(sizePolicy2)
        self.widget_62.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_156 = QVBoxLayout(self.widget_62)
        self.verticalLayout_156.setObjectName(u"verticalLayout_156")
        self.radioButton_79 = QRadioButton(self.widget_62)
        self.radioButton_79.setObjectName(u"radioButton_79")
        self.radioButton_79.setFont(font3)

        self.verticalLayout_156.addWidget(self.radioButton_79)

        self.radioButton_80 = QRadioButton(self.widget_62)
        self.radioButton_80.setObjectName(u"radioButton_80")
        self.radioButton_80.setFont(font3)

        self.verticalLayout_156.addWidget(self.radioButton_80)


        self.verticalLayout_155.addWidget(self.widget_62)


        self.horizontalLayout_169.addWidget(self.frame_246)

        self.frame_247 = QFrame(self.frame_245)
        self.frame_247.setObjectName(u"frame_247")
        sizePolicy1.setHeightForWidth(self.frame_247.sizePolicy().hasHeightForWidth())
        self.frame_247.setSizePolicy(sizePolicy1)
        self.frame_247.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_247.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_157 = QVBoxLayout(self.frame_247)
        self.verticalLayout_157.setObjectName(u"verticalLayout_157")
        self.frame_248 = QFrame(self.frame_247)
        self.frame_248.setObjectName(u"frame_248")
        self.frame_248.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_248.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_248.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_170 = QHBoxLayout(self.frame_248)
        self.horizontalLayout_170.setObjectName(u"horizontalLayout_170")
        self.model_installed_21 = QCheckBox(self.frame_248)
        self.model_installed_21.setObjectName(u"model_installed_21")
        self.model_installed_21.setEnabled(False)
        self.model_installed_21.setFont(font4)
        self.model_installed_21.setAutoFillBackground(False)
        self.model_installed_21.setIconSize(QSize(30, 30))
        self.model_installed_21.setCheckable(False)
        self.model_installed_21.setTristate(False)

        self.horizontalLayout_170.addWidget(self.model_installed_21)


        self.verticalLayout_157.addWidget(self.frame_248)

        self.frame_249 = QFrame(self.frame_247)
        self.frame_249.setObjectName(u"frame_249")
        self.frame_249.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_249.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_249.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_171 = QHBoxLayout(self.frame_249)
        self.horizontalLayout_171.setObjectName(u"horizontalLayout_171")
        self.checkpoints_downloaded_21 = QCheckBox(self.frame_249)
        self.checkpoints_downloaded_21.setObjectName(u"checkpoints_downloaded_21")
        self.checkpoints_downloaded_21.setEnabled(False)
        self.checkpoints_downloaded_21.setFont(font4)
        self.checkpoints_downloaded_21.setAutoFillBackground(False)
        self.checkpoints_downloaded_21.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_21.setCheckable(False)
        self.checkpoints_downloaded_21.setTristate(False)

        self.horizontalLayout_171.addWidget(self.checkpoints_downloaded_21)


        self.verticalLayout_157.addWidget(self.frame_249)


        self.horizontalLayout_169.addWidget(self.frame_247)


        self.verticalLayout_153.addWidget(self.frame_245)


        self.horizontalLayout_166.addWidget(self.frame_242)

        self.frame_250 = QFrame(self.frame_241)
        self.frame_250.setObjectName(u"frame_250")
        sizePolicy1.setHeightForWidth(self.frame_250.sizePolicy().hasHeightForWidth())
        self.frame_250.setSizePolicy(sizePolicy1)
        self.frame_250.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_250.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_158 = QVBoxLayout(self.frame_250)
        self.verticalLayout_158.setObjectName(u"verticalLayout_158")
        self.widget_63 = QWidget(self.frame_250)
        self.widget_63.setObjectName(u"widget_63")
        sizePolicy3.setHeightForWidth(self.widget_63.sizePolicy().hasHeightForWidth())
        self.widget_63.setSizePolicy(sizePolicy3)
        self.widget_63.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_172 = QHBoxLayout(self.widget_63)
        self.horizontalLayout_172.setObjectName(u"horizontalLayout_172")
        self.label_133 = QLabel(self.widget_63)
        self.label_133.setObjectName(u"label_133")
        self.label_133.setFont(font2)

        self.horizontalLayout_172.addWidget(self.label_133)

        self.frame_251 = QFrame(self.widget_63)
        self.frame_251.setObjectName(u"frame_251")
        sizePolicy4.setHeightForWidth(self.frame_251.sizePolicy().hasHeightForWidth())
        self.frame_251.setSizePolicy(sizePolicy4)
        self.frame_251.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_251.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_173 = QHBoxLayout(self.frame_251)
        self.horizontalLayout_173.setObjectName(u"horizontalLayout_173")
        self.label_134 = QLabel(self.frame_251)
        self.label_134.setObjectName(u"label_134")
        self.label_134.setFont(font2)

        self.horizontalLayout_173.addWidget(self.label_134)

        self.pushButton_42 = QPushButton(self.frame_251)
        self.pushButton_42.setObjectName(u"pushButton_42")
        self.pushButton_42.setMinimumSize(QSize(30, 30))
        self.pushButton_42.setMaximumSize(QSize(40, 40))
        self.pushButton_42.setIcon(icon1)
        self.pushButton_42.setIconSize(QSize(30, 30))

        self.horizontalLayout_173.addWidget(self.pushButton_42)


        self.horizontalLayout_172.addWidget(self.frame_251)


        self.verticalLayout_158.addWidget(self.widget_63)

        self.textEdit_21 = QTextEdit(self.frame_250)
        self.textEdit_21.setObjectName(u"textEdit_21")
        sizePolicy5.setHeightForWidth(self.textEdit_21.sizePolicy().hasHeightForWidth())
        self.textEdit_21.setSizePolicy(sizePolicy5)
        self.textEdit_21.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_21.setReadOnly(True)

        self.verticalLayout_158.addWidget(self.textEdit_21)


        self.horizontalLayout_166.addWidget(self.frame_250)


        self.verticalLayout_159.addWidget(self.frame_241)

        self.tabWidget.addTab(self.tab_21, "")
        self.tab_22 = QWidget()
        self.tab_22.setObjectName(u"tab_22")
        self.verticalLayout_167 = QVBoxLayout(self.tab_22)
        self.verticalLayout_167.setObjectName(u"verticalLayout_167")
        self.frame_252 = QFrame(self.tab_22)
        self.frame_252.setObjectName(u"frame_252")
        sizePolicy.setHeightForWidth(self.frame_252.sizePolicy().hasHeightForWidth())
        self.frame_252.setSizePolicy(sizePolicy)
        self.frame_252.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_252.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_174 = QHBoxLayout(self.frame_252)
        self.horizontalLayout_174.setObjectName(u"horizontalLayout_174")
        self.frame_253 = QFrame(self.frame_252)
        self.frame_253.setObjectName(u"frame_253")
        sizePolicy1.setHeightForWidth(self.frame_253.sizePolicy().hasHeightForWidth())
        self.frame_253.setSizePolicy(sizePolicy1)
        self.frame_253.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_253.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_160 = QVBoxLayout(self.frame_253)
        self.verticalLayout_160.setObjectName(u"verticalLayout_160")
        self.frame_254 = QFrame(self.frame_253)
        self.frame_254.setObjectName(u"frame_254")
        self.frame_254.setStyleSheet(u"background-color: rgb(177, 177, 177);")
        self.frame_254.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_254.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_161 = QVBoxLayout(self.frame_254)
        self.verticalLayout_161.setObjectName(u"verticalLayout_161")
        self.frame_255 = QFrame(self.frame_254)
        self.frame_255.setObjectName(u"frame_255")
        self.frame_255.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_255.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_175 = QHBoxLayout(self.frame_255)
        self.horizontalLayout_175.setObjectName(u"horizontalLayout_175")
        self.label_135 = QLabel(self.frame_255)
        self.label_135.setObjectName(u"label_135")
        self.label_135.setFont(font5)
        self.label_135.setTextFormat(Qt.TextFormat.PlainText)
        self.label_135.setScaledContents(False)

        self.horizontalLayout_175.addWidget(self.label_135)

        self.label_136 = QLabel(self.frame_255)
        self.label_136.setObjectName(u"label_136")
        self.label_136.setFont(font2)

        self.horizontalLayout_175.addWidget(self.label_136)


        self.verticalLayout_161.addWidget(self.frame_255)

        self.widget_64 = QWidget(self.frame_254)
        self.widget_64.setObjectName(u"widget_64")
        sizePolicy2.setHeightForWidth(self.widget_64.sizePolicy().hasHeightForWidth())
        self.widget_64.setSizePolicy(sizePolicy2)
        self.horizontalLayout_176 = QHBoxLayout(self.widget_64)
        self.horizontalLayout_176.setObjectName(u"horizontalLayout_176")
        self.pushButton_43 = QPushButton(self.widget_64)
        self.pushButton_43.setObjectName(u"pushButton_43")
        self.pushButton_43.setMinimumSize(QSize(46, 46))
        self.pushButton_43.setMaximumSize(QSize(60, 16777215))
        self.pushButton_43.setIcon(icon)
        self.pushButton_43.setIconSize(QSize(30, 30))

        self.horizontalLayout_176.addWidget(self.pushButton_43)

        self.label_137 = QLabel(self.widget_64)
        self.label_137.setObjectName(u"label_137")
        self.label_137.setMinimumSize(QSize(2, 33))
        self.label_137.setMaximumSize(QSize(16777215, 33))
        self.label_137.setStyleSheet(u"background-color: rgb(220,220, 220);")

        self.horizontalLayout_176.addWidget(self.label_137)


        self.verticalLayout_161.addWidget(self.widget_64)


        self.verticalLayout_160.addWidget(self.frame_254)

        self.frame_256 = QFrame(self.frame_253)
        self.frame_256.setObjectName(u"frame_256")
        self.frame_256.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_256.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_177 = QHBoxLayout(self.frame_256)
        self.horizontalLayout_177.setObjectName(u"horizontalLayout_177")
        self.frame_257 = QFrame(self.frame_256)
        self.frame_257.setObjectName(u"frame_257")
        self.frame_257.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_257.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_257.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_162 = QVBoxLayout(self.frame_257)
        self.verticalLayout_162.setObjectName(u"verticalLayout_162")
        self.label_138 = QLabel(self.frame_257)
        self.label_138.setObjectName(u"label_138")
        self.label_138.setFont(font2)

        self.verticalLayout_162.addWidget(self.label_138, 0, Qt.AlignmentFlag.AlignHCenter)

        self.widget_65 = QWidget(self.frame_257)
        self.widget_65.setObjectName(u"widget_65")
        sizePolicy2.setHeightForWidth(self.widget_65.sizePolicy().hasHeightForWidth())
        self.widget_65.setSizePolicy(sizePolicy2)
        self.widget_65.setStyleSheet(u"background-color: rgb(140, 140, 140);")
        self.verticalLayout_163 = QVBoxLayout(self.widget_65)
        self.verticalLayout_163.setObjectName(u"verticalLayout_163")
        self.radioButton_81 = QRadioButton(self.widget_65)
        self.radioButton_81.setObjectName(u"radioButton_81")
        self.radioButton_81.setFont(font3)

        self.verticalLayout_163.addWidget(self.radioButton_81)

        self.radioButton_82 = QRadioButton(self.widget_65)
        self.radioButton_82.setObjectName(u"radioButton_82")
        self.radioButton_82.setFont(font3)

        self.verticalLayout_163.addWidget(self.radioButton_82)


        self.verticalLayout_162.addWidget(self.widget_65)


        self.horizontalLayout_177.addWidget(self.frame_257)

        self.frame_258 = QFrame(self.frame_256)
        self.frame_258.setObjectName(u"frame_258")
        sizePolicy1.setHeightForWidth(self.frame_258.sizePolicy().hasHeightForWidth())
        self.frame_258.setSizePolicy(sizePolicy1)
        self.frame_258.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_258.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_164 = QVBoxLayout(self.frame_258)
        self.verticalLayout_164.setObjectName(u"verticalLayout_164")
        self.frame_259 = QFrame(self.frame_258)
        self.frame_259.setObjectName(u"frame_259")
        sizePolicy4.setHeightForWidth(self.frame_259.sizePolicy().hasHeightForWidth())
        self.frame_259.setSizePolicy(sizePolicy4)
        self.frame_259.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_259.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_165 = QVBoxLayout(self.frame_259)
        self.verticalLayout_165.setObjectName(u"verticalLayout_165")
        self.radioButton_83 = QRadioButton(self.frame_259)
        self.radioButton_83.setObjectName(u"radioButton_83")

        self.verticalLayout_165.addWidget(self.radioButton_83)

        self.radioButton_84 = QRadioButton(self.frame_259)
        self.radioButton_84.setObjectName(u"radioButton_84")

        self.verticalLayout_165.addWidget(self.radioButton_84)

        self.radioButton_85 = QRadioButton(self.frame_259)
        self.radioButton_85.setObjectName(u"radioButton_85")

        self.verticalLayout_165.addWidget(self.radioButton_85)

        self.radioButton_86 = QRadioButton(self.frame_259)
        self.radioButton_86.setObjectName(u"radioButton_86")

        self.verticalLayout_165.addWidget(self.radioButton_86)

        self.radioButton_87 = QRadioButton(self.frame_259)
        self.radioButton_87.setObjectName(u"radioButton_87")

        self.verticalLayout_165.addWidget(self.radioButton_87)

        self.radioButton_88 = QRadioButton(self.frame_259)
        self.radioButton_88.setObjectName(u"radioButton_88")

        self.verticalLayout_165.addWidget(self.radioButton_88)

        self.radioButton_89 = QRadioButton(self.frame_259)
        self.radioButton_89.setObjectName(u"radioButton_89")

        self.verticalLayout_165.addWidget(self.radioButton_89)

        self.radioButton_90 = QRadioButton(self.frame_259)
        self.radioButton_90.setObjectName(u"radioButton_90")

        self.verticalLayout_165.addWidget(self.radioButton_90)

        self.radioButton_91 = QRadioButton(self.frame_259)
        self.radioButton_91.setObjectName(u"radioButton_91")

        self.verticalLayout_165.addWidget(self.radioButton_91)


        self.verticalLayout_164.addWidget(self.frame_259, 0, Qt.AlignmentFlag.AlignHCenter)

        self.frame_260 = QFrame(self.frame_258)
        self.frame_260.setObjectName(u"frame_260")
        self.frame_260.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_260.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_260.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_178 = QHBoxLayout(self.frame_260)
        self.horizontalLayout_178.setObjectName(u"horizontalLayout_178")
        self.model_installed_22 = QCheckBox(self.frame_260)
        self.model_installed_22.setObjectName(u"model_installed_22")
        self.model_installed_22.setEnabled(False)
        self.model_installed_22.setFont(font4)
        self.model_installed_22.setAutoFillBackground(False)
        self.model_installed_22.setIconSize(QSize(30, 30))
        self.model_installed_22.setCheckable(False)
        self.model_installed_22.setTristate(False)

        self.horizontalLayout_178.addWidget(self.model_installed_22)


        self.verticalLayout_164.addWidget(self.frame_260)

        self.frame_261 = QFrame(self.frame_258)
        self.frame_261.setObjectName(u"frame_261")
        self.frame_261.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_261.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_261.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_179 = QHBoxLayout(self.frame_261)
        self.horizontalLayout_179.setObjectName(u"horizontalLayout_179")
        self.checkpoints_downloaded_22 = QCheckBox(self.frame_261)
        self.checkpoints_downloaded_22.setObjectName(u"checkpoints_downloaded_22")
        self.checkpoints_downloaded_22.setEnabled(False)
        self.checkpoints_downloaded_22.setFont(font4)
        self.checkpoints_downloaded_22.setAutoFillBackground(False)
        self.checkpoints_downloaded_22.setIconSize(QSize(30, 30))
        self.checkpoints_downloaded_22.setCheckable(False)
        self.checkpoints_downloaded_22.setTristate(False)

        self.horizontalLayout_179.addWidget(self.checkpoints_downloaded_22)


        self.verticalLayout_164.addWidget(self.frame_261)


        self.horizontalLayout_177.addWidget(self.frame_258)


        self.verticalLayout_160.addWidget(self.frame_256)


        self.horizontalLayout_174.addWidget(self.frame_253)

        self.frame_262 = QFrame(self.frame_252)
        self.frame_262.setObjectName(u"frame_262")
        sizePolicy1.setHeightForWidth(self.frame_262.sizePolicy().hasHeightForWidth())
        self.frame_262.setSizePolicy(sizePolicy1)
        self.frame_262.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_262.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_166 = QVBoxLayout(self.frame_262)
        self.verticalLayout_166.setObjectName(u"verticalLayout_166")
        self.widget_66 = QWidget(self.frame_262)
        self.widget_66.setObjectName(u"widget_66")
        sizePolicy3.setHeightForWidth(self.widget_66.sizePolicy().hasHeightForWidth())
        self.widget_66.setSizePolicy(sizePolicy3)
        self.widget_66.setMinimumSize(QSize(0, 50))
        self.horizontalLayout_180 = QHBoxLayout(self.widget_66)
        self.horizontalLayout_180.setObjectName(u"horizontalLayout_180")
        self.label_139 = QLabel(self.widget_66)
        self.label_139.setObjectName(u"label_139")
        self.label_139.setFont(font2)

        self.horizontalLayout_180.addWidget(self.label_139)

        self.frame_263 = QFrame(self.widget_66)
        self.frame_263.setObjectName(u"frame_263")
        sizePolicy4.setHeightForWidth(self.frame_263.sizePolicy().hasHeightForWidth())
        self.frame_263.setSizePolicy(sizePolicy4)
        self.frame_263.setFrameShape(QFrame.Shape.StyledPanel)
        self.frame_263.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_181 = QHBoxLayout(self.frame_263)
        self.horizontalLayout_181.setObjectName(u"horizontalLayout_181")
        self.label_140 = QLabel(self.frame_263)
        self.label_140.setObjectName(u"label_140")
        self.label_140.setFont(font2)

        self.horizontalLayout_181.addWidget(self.label_140)

        self.pushButton_44 = QPushButton(self.frame_263)
        self.pushButton_44.setObjectName(u"pushButton_44")
        self.pushButton_44.setMinimumSize(QSize(30, 30))
        self.pushButton_44.setMaximumSize(QSize(40, 40))
        self.pushButton_44.setIcon(icon1)
        self.pushButton_44.setIconSize(QSize(30, 30))

        self.horizontalLayout_181.addWidget(self.pushButton_44)


        self.horizontalLayout_180.addWidget(self.frame_263)


        self.verticalLayout_166.addWidget(self.widget_66)

        self.textEdit_22 = QTextEdit(self.frame_262)
        self.textEdit_22.setObjectName(u"textEdit_22")
        sizePolicy5.setHeightForWidth(self.textEdit_22.sizePolicy().hasHeightForWidth())
        self.textEdit_22.setSizePolicy(sizePolicy5)
        self.textEdit_22.setStyleSheet(u"background-color: rgb(229, 229, 229);")
        self.textEdit_22.setReadOnly(True)

        self.verticalLayout_166.addWidget(self.textEdit_22)


        self.horizontalLayout_174.addWidget(self.frame_262)


        self.verticalLayout_167.addWidget(self.frame_252)

        self.tabWidget.addTab(self.tab_22, "")

        self.verticalLayout.addWidget(self.tabWidget)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 1181, 33))
        self.menuFile = QMenu(self.menubar)
        self.menuFile.setObjectName(u"menuFile")
        self.menuBenchmarks = QMenu(self.menubar)
        self.menuBenchmarks.setObjectName(u"menuBenchmarks")
        self.menuData = QMenu(self.menubar)
        self.menuData.setObjectName(u"menuData")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.menubar.addAction(self.menuFile.menuAction())
        self.menubar.addAction(self.menuBenchmarks.menuAction())
        self.menubar.addAction(self.menuData.menuAction())
        self.menuFile.addAction(self.actionNew)
        self.menuFile.addAction(self.actionLoad)
        self.menuBenchmarks.addAction(self.actionGP_Regression)
        self.menuData.addAction(self.actionNew_Data_Setup)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(21)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.actionNew.setText(QCoreApplication.translate("MainWindow", u"New..", None))
        self.actionLoad.setText(QCoreApplication.translate("MainWindow", u"Load", None))
        self.actionGP_Regression.setText(QCoreApplication.translate("MainWindow", u"GP Regression", None))
        self.actionNew_Data_Setup.setText(QCoreApplication.translate("MainWindow", u"New Data Setup", None))
        self.label_19.setText(QCoreApplication.translate("MainWindow", u"Clamp", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton.setText("")
        self.label_2.setText("")
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_2.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_2.setText("")
        self.textEdit.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"clamp", None))
        self.label_20.setText(QCoreApplication.translate("MainWindow", u"MolBERT", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_3.setText("")
        self.label_11.setText("")
        self.label_12.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_3.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_4.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_2.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_2.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_14.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_4.setText("")
        self.textEdit_2.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"molbert", None))
        self.label_21.setText(QCoreApplication.translate("MainWindow", u"GROVER", None))
        self.label_22.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_5.setText("")
        self.label_23.setText("")
        self.label_24.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_5.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_6.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.checkBox_10.setText(QCoreApplication.translate("MainWindow", u"Use Grover Large", None))
        self.checkBox_9.setText(QCoreApplication.translate("MainWindow", u"Use Bonds", None))
        self.checkBox_8.setText(QCoreApplication.translate("MainWindow", u"Use Atoms", None))
        self.model_installed_3.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_3.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_25.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_26.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_6.setText("")
        self.textEdit_3.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_3), QCoreApplication.translate("MainWindow", u"Grover", None))
        self.label_31.setText(QCoreApplication.translate("MainWindow", u"Mat", None))
        self.label_32.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_7.setText("")
        self.label_33.setText("")
        self.label_34.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_7.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_8.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_4.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_4.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_35.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_36.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_8.setText("")
        self.textEdit_4.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_4), QCoreApplication.translate("MainWindow", u"Mat", None))
        self.label_41.setText(QCoreApplication.translate("MainWindow", u"RMat", None))
        self.label_42.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_9.setText("")
        self.label_43.setText("")
        self.label_44.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_9.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_10.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_5.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_5.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_45.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_46.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_10.setText("")
        self.textEdit_5.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_5), QCoreApplication.translate("MainWindow", u"RMat", None))
        self.label_47.setText(QCoreApplication.translate("MainWindow", u"SelfiesTed", None))
        self.label_48.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_11.setText("")
        self.label_49.setText("")
        self.label_50.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_11.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_12.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_6.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_6.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_51.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_52.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_12.setText("")
        self.textEdit_6.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_6), QCoreApplication.translate("MainWindow", u"SelfiesTed", None))
        self.label_27.setText(QCoreApplication.translate("MainWindow", u"ChemBERTa", None))
        self.label_28.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_13.setText("")
        self.label_29.setText("")
        self.label_30.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_13.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_14.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_15.setText(QCoreApplication.translate("MainWindow", u"Use model: Zinc-base-v1", None))
        self.radioButton_16.setText(QCoreApplication.translate("MainWindow", u"Use model: 77M-MTR", None))
        self.radioButton_17.setText(QCoreApplication.translate("MainWindow", u"Use model: 77M-MLM", None))
        self.model_installed_7.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_7.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_37.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_38.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_14.setText("")
        self.textEdit_7.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_7), QCoreApplication.translate("MainWindow", u"ChemBERTa", None))
        self.label_53.setText(QCoreApplication.translate("MainWindow", u"Graphormer", None))
        self.label_54.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_15.setText("")
        self.label_55.setText("")
        self.label_56.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_18.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_19.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_8.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_8.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_57.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_58.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_16.setText("")
        self.textEdit_8.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_8), QCoreApplication.translate("MainWindow", u"Graphormer", None))
        self.label_39.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen", None))
        self.label_40.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_17.setText("")
        self.label_59.setText("")
        self.label_60.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_20.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_21.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_22.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_32M_SMILES_AtomWise", None))
        self.radioButton_23.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_157M_SMILES_AtomWise", None))
        self.radioButton_25.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_300M_SMILES_AtomWise", None))
        self.radioButton_26.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_32M_SMILES_BPE", None))
        self.radioButton_27.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_157M_SMILES_BPE", None))
        self.radioButton_28.setText(QCoreApplication.translate("MainWindow", u"NovoMolGen_300M_SMILES_BPE", None))
        self.model_installed_9.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_9.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_61.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_62.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_18.setText("")
        self.textEdit_9.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_9), QCoreApplication.translate("MainWindow", u"NovoMolGen", None))
        self.label_63.setText(QCoreApplication.translate("MainWindow", u"MolFormer", None))
        self.label_64.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_19.setText("")
        self.label_65.setText("")
        self.label_66.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_24.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_29.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_10.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_10.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_67.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_68.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_20.setText("")
        self.textEdit_10.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_10), QCoreApplication.translate("MainWindow", u"MolFormer", None))
        self.label_69.setText(QCoreApplication.translate("MainWindow", u"Molgen", None))
        self.label_70.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_21.setText("")
        self.label_71.setText("")
        self.label_72.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_30.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_31.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_32.setText(QCoreApplication.translate("MainWindow", u"MolGen-large", None))
        self.radioButton_33.setText(QCoreApplication.translate("MainWindow", u"MolGen-large-opt", None))
        self.radioButton_34.setText(QCoreApplication.translate("MainWindow", u"MolGen-7b", None))
        self.model_installed_11.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_11.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_73.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_74.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_22.setText("")
        self.textEdit_11.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_11), QCoreApplication.translate("MainWindow", u"Molgen", None))
        self.label_75.setText(QCoreApplication.translate("MainWindow", u"MolCLR", None))
        self.label_76.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_23.setText("")
        self.label_77.setText("")
        self.label_78.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_35.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_36.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_37.setText(QCoreApplication.translate("MainWindow", u"GIN", None))
        self.radioButton_38.setText(QCoreApplication.translate("MainWindow", u"GCN", None))
        self.model_installed_12.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_12.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_79.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_80.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_24.setText("")
        self.textEdit_12.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_12), QCoreApplication.translate("MainWindow", u"MolCLR", None))
        self.label_81.setText(QCoreApplication.translate("MainWindow", u"MolR", None))
        self.label_82.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_25.setText("")
        self.label_83.setText("")
        self.label_84.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_39.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_40.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_41.setText(QCoreApplication.translate("MainWindow", u"gcn_1024", None))
        self.radioButton_42.setText(QCoreApplication.translate("MainWindow", u"gat_1024", None))
        self.radioButton_43.setText(QCoreApplication.translate("MainWindow", u"sage_1024", None))
        self.radioButton_44.setText(QCoreApplication.translate("MainWindow", u"tag_1024", None))
        self.model_installed_13.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_13.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_85.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_86.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_26.setText("")
        self.textEdit_13.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_13), QCoreApplication.translate("MainWindow", u"MolR", None))
        self.label_87.setText(QCoreApplication.translate("MainWindow", u"GraphFP", None))
        self.label_88.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_27.setText("")
        self.label_89.setText("")
        self.label_90.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_45.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_46.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_47.setText(QCoreApplication.translate("MainWindow", u"GIN_C", None))
        self.radioButton_48.setText(QCoreApplication.translate("MainWindow", u"GIN_CP", None))
        self.radioButton_49.setText(QCoreApplication.translate("MainWindow", u"GIN_CPF", None))
        self.model_installed_14.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_14.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_91.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_92.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_28.setText("")
        self.textEdit_14.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_14), QCoreApplication.translate("MainWindow", u"GraphFP", None))
        self.label_93.setText(QCoreApplication.translate("MainWindow", u"Gem", None))
        self.label_94.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_29.setText("")
        self.label_95.setText("")
        self.label_96.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_50.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_51.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_15.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_15.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_97.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_98.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_30.setText("")
        self.textEdit_15.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_15), QCoreApplication.translate("MainWindow", u"Gem", None))
        self.label_99.setText(QCoreApplication.translate("MainWindow", u"SimSon", None))
        self.label_100.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_31.setText("")
        self.label_101.setText("")
        self.label_102.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_52.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_53.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_16.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_16.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_103.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_104.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_32.setText("")
        self.textEdit_16.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_16), QCoreApplication.translate("MainWindow", u"SimSon", None))
        self.label_105.setText(QCoreApplication.translate("MainWindow", u"ChemFM", None))
        self.label_106.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_33.setText("")
        self.label_107.setText("")
        self.label_108.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_54.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_55.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_56.setText(QCoreApplication.translate("MainWindow", u"ChemFM-1B", None))
        self.radioButton_57.setText(QCoreApplication.translate("MainWindow", u"ChemFM-3B", None))
        self.radioButton_58.setText(QCoreApplication.translate("MainWindow", u"ChemFMv2-20M", None))
        self.model_installed_17.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_17.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_109.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_110.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_34.setText("")
        self.textEdit_17.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_17), QCoreApplication.translate("MainWindow", u"ChemFM", None))
        self.label_111.setText(QCoreApplication.translate("MainWindow", u"ChemGPT", None))
        self.label_112.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_35.setText("")
        self.label_113.setText("")
        self.label_114.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_59.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_60.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_61.setText(QCoreApplication.translate("MainWindow", u"ChemGPT-4.7M", None))
        self.radioButton_62.setText(QCoreApplication.translate("MainWindow", u"ChemGPT-19M", None))
        self.radioButton_63.setText(QCoreApplication.translate("MainWindow", u"ChemGPT-1.2B", None))
        self.model_installed_18.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_18.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_115.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_116.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_36.setText("")
        self.textEdit_18.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_18), QCoreApplication.translate("MainWindow", u"ChemGPT", None))
        self.label_117.setText(QCoreApplication.translate("MainWindow", u"SelFormer", None))
        self.label_118.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_37.setText("")
        self.label_119.setText("")
        self.label_120.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_64.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_65.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_66.setText(QCoreApplication.translate("MainWindow", u"SELFormer", None))
        self.radioButton_67.setText(QCoreApplication.translate("MainWindow", u"SELFormer-Lite", None))
        self.model_installed_19.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_19.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_121.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_122.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_38.setText("")
        self.textEdit_19.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_19), QCoreApplication.translate("MainWindow", u"SelFormer", None))
        self.label_123.setText(QCoreApplication.translate("MainWindow", u"ChemFormer", None))
        self.label_124.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_39.setText("")
        self.label_125.setText("")
        self.label_126.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_68.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_69.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_70.setText(QCoreApplication.translate("MainWindow", u"pre-trained-combined-large", None))
        self.radioButton_75.setText(QCoreApplication.translate("MainWindow", u"pre-trained-mask", None))
        self.radioButton_71.setText(QCoreApplication.translate("MainWindow", u"pre-trained-combined", None))
        self.radioButton_78.setText(QCoreApplication.translate("MainWindow", u"pre-trained-augment", None))
        self.radioButton_77.setText(QCoreApplication.translate("MainWindow", u"fined-tuned-uspto_sep", None))
        self.radioButton_76.setText(QCoreApplication.translate("MainWindow", u"fined-tuned-uspto_mixed", None))
        self.radioButton_74.setText(QCoreApplication.translate("MainWindow", u"fined-tuned-uspto_50", None))
        self.radioButton_73.setText(QCoreApplication.translate("MainWindow", u"rand_init_downstream-uspto_sep", None))
        self.radioButton_72.setText(QCoreApplication.translate("MainWindow", u"rand_init_downstream-uspto_50", None))
        self.model_installed_20.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_20.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_127.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_128.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_40.setText("")
        self.textEdit_20.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_20), QCoreApplication.translate("MainWindow", u"ChemFormer", None))
        self.label_129.setText(QCoreApplication.translate("MainWindow", u"Mol2Vec", None))
        self.label_130.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_41.setText("")
        self.label_131.setText("")
        self.label_132.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_79.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_80.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.model_installed_21.setText(QCoreApplication.translate("MainWindow", u"Model installed", None))
        self.checkpoints_downloaded_21.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_133.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_134.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_42.setText("")
        self.textEdit_21.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_21), QCoreApplication.translate("MainWindow", u"Mol2Vec", None))
        self.label_135.setText(QCoreApplication.translate("MainWindow", u"Coati", None))
        self.label_136.setText(QCoreApplication.translate("MainWindow", u"Select your file", None))
        self.pushButton_43.setText("")
        self.label_137.setText("")
        self.label_138.setText(QCoreApplication.translate("MainWindow", u"Format", None))
        self.radioButton_81.setText(QCoreApplication.translate("MainWindow", u"SMILES", None))
        self.radioButton_82.setText(QCoreApplication.translate("MainWindow", u"SELFIES", None))
        self.radioButton_83.setText(QCoreApplication.translate("MainWindow", u"grande_closed", None))
        self.radioButton_84.setText(QCoreApplication.translate("MainWindow", u"tall_closed", None))
        self.radioButton_85.setText(QCoreApplication.translate("MainWindow", u"grade_closed_fp", None))
        self.radioButton_86.setText(QCoreApplication.translate("MainWindow", u"barlow_closed_fp", None))
        self.radioButton_87.setText(QCoreApplication.translate("MainWindow", u"barlow_closed", None))
        self.radioButton_88.setText(QCoreApplication.translate("MainWindow", u"autoreg_only", None))
        self.radioButton_89.setText(QCoreApplication.translate("MainWindow", u"barlow_venti", None))
        self.radioButton_90.setText(QCoreApplication.translate("MainWindow", u"grande_open", None))
        self.radioButton_91.setText(QCoreApplication.translate("MainWindow", u"selfies_barlow", None))
        self.model_installed_22.setText(QCoreApplication.translate("MainWindow", u"Models installed", None))
        self.checkpoints_downloaded_22.setText(QCoreApplication.translate("MainWindow", u"Checkpoints Downloaded", None))
        self.label_139.setText(QCoreApplication.translate("MainWindow", u"Status Console", None))
        self.label_140.setText(QCoreApplication.translate("MainWindow", u"RUN", None))
        self.pushButton_44.setText("")
        self.textEdit_22.setHtml(QCoreApplication.translate("MainWindow", u"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><meta charset=\"utf-8\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"hr { height: 1px; border-width: 0; }\n"
"li.unchecked::marker { content: \"\\2610\"; }\n"
"li.checked::marker { content: \"\\2612\"; }\n"
"</style></head><body style=\" font-family:'Segoe UI'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8.25pt;\"><br /></p></body></html>", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_22), QCoreApplication.translate("MainWindow", u"Coati", None))
        self.menuFile.setTitle(QCoreApplication.translate("MainWindow", u"File", None))
        self.menuBenchmarks.setTitle(QCoreApplication.translate("MainWindow", u"Benchmarks", None))
        self.menuData.setTitle(QCoreApplication.translate("MainWindow", u"Data", None))
    # retranslateUi

