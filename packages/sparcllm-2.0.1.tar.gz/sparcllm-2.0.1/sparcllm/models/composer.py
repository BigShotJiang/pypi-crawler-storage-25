"""Pure-Python model composition services."""

from __future__ import annotations

from merge_lora_svf import merge_modules_in_memory
from sparcllm.config import ComposeRequest


class ModelComposer:
    """Composes base, SVF and LoRA components without shelling out."""

    @staticmethod
    def compose(request: ComposeRequest):
        mode = request.mode
        if mode not in {"both", "lora_only", "svf_only", "none"}:
            raise ValueError(f"Invalid mode '{mode}'.")

        return merge_modules_in_memory(
            base_model_id=request.base_model_id,
            lora_adapter_path=request.lora_adapter_path,
            svf_params_path=request.svf_params_path,
            svd_params_path=request.svd_params_path,
            device=request.device,
            lora_only=mode == "lora_only",
            svf_only=mode == "svf_only",
            both=mode == "both",
            none=mode == "none",
        )
