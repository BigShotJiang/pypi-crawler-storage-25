"""Higher-level workflow objects for production-like usage."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Optional

from .config import ComposeRequest, MergeConfig, OrthogonalTrainingConfig, SVDConfig, SVFTrainingConfig
from .evaluators import EvaluationEngine
from .runner import CommandRunner
from .trainers import OrthogonalTrainingService, SVDService, SVFTrainingService


@dataclass
class ExperimentReport:
    executed_stages: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    metrics: Dict[str, float] = field(default_factory=dict)


class SPARCExperiment:
    """Orchestrates stages with explicit lifecycle and report object."""

    def __init__(self, project_root: str | Path = ".") -> None:
        self.project_root = Path(project_root).resolve()
        runner = CommandRunner(project_root=self.project_root)
        self.svd_service = SVDService(runner)
        self.svf_service = SVFTrainingService(runner)
        self.orthogonal_service = OrthogonalTrainingService(runner)
        self.eval_engine = EvaluationEngine()

    def run(
        self,
        svd_cfg: Optional[SVDConfig] = None,
        svf_cfg: Optional[SVFTrainingConfig] = None,
        orthogonal_cfg: Optional[OrthogonalTrainingConfig] = None,
        merge_cfg: Optional[MergeConfig] = None,
    ) -> ExperimentReport:
        report = ExperimentReport()

        if svd_cfg:
            self.svd_service.run(svd_cfg)
            report.executed_stages.append("svd")
            report.notes.append(f"SVD file target: {svd_cfg.output_file}")

        if svf_cfg:
            self.svf_service.run(svf_cfg)
            report.executed_stages.append("svf")

        if orthogonal_cfg:
            self.orthogonal_service.run(orthogonal_cfg)
            report.executed_stages.append("orthogonal")

        if merge_cfg:
            request = ComposeRequest(
                base_model_id=merge_cfg.base_model_id,
                lora_adapter_path=merge_cfg.lora_adapter_path,
                svf_params_path=merge_cfg.svf_params_path,
                svd_params_path=merge_cfg.svd_params_path,
                device=merge_cfg.device,
                mode=merge_cfg.mode,
            )
            report.metrics = self.eval_engine.evaluate(
                request=request,
                knowledge_dataset_file=merge_cfg.knowledge_dataset_file,
                task_names=[] if merge_cfg.skip_task_eval else merge_cfg.task_names,
                run_knowledge_eval=not merge_cfg.skip_knowledge_eval,
            )
            report.executed_stages.append("evaluation")

        return report
