"""Public API for the SPARC-LLM framework package."""

from .config import (
    ComposeRequest,
    MergeConfig,
    OrthogonalTrainingConfig,
    SVDConfig,
    SVFTrainingConfig,
)

__all__ = [
    "ComposeRequest",
    "MergeConfig",
    "ModelMergerEvaluator",
    "OrthogonalLoRATrainer",
    "OrthogonalTrainingConfig",
    "PlotService",
    "SPARCPipeline",
    "SVDConfig",
    "SVDDecomposer",
    "SVFTrainer",
    "SVFTrainingConfig",
    "SPARCExperiment",
    "ExperimentReport",
]


def __getattr__(name: str):
    if name in {
        "ModelMergerEvaluator",
        "OrthogonalLoRATrainer",
        "SPARCPipeline",
        "SVDDecomposer",
        "SVFTrainer",
    }:
        from .pipeline import (
            ModelMergerEvaluator,
            OrthogonalLoRATrainer,
            SPARCPipeline,
            SVDDecomposer,
            SVFTrainer,
        )

        mapping = {
            "ModelMergerEvaluator": ModelMergerEvaluator,
            "OrthogonalLoRATrainer": OrthogonalLoRATrainer,
            "SPARCPipeline": SPARCPipeline,
            "SVDDecomposer": SVDDecomposer,
            "SVFTrainer": SVFTrainer,
        }
        return mapping[name]
    if name in {"SPARCExperiment", "ExperimentReport"}:
        from .workflows import ExperimentReport, SPARCExperiment

        mapping = {
            "SPARCExperiment": SPARCExperiment,
            "ExperimentReport": ExperimentReport,
        }
        return mapping[name]
    if name == "PlotService":
        from .reporting import PlotService

        return PlotService
    raise AttributeError(name)
