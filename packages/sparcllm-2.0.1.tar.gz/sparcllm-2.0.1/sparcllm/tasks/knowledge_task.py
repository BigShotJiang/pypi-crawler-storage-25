import pandas as pd
from datasets import Dataset
import fishfarm
import vllm
from fishfarm.models.vllm_model import VLLMModel
from fishfarm.tasks.base import TaskResult
from typing import Sequence, Optional
import ast # Import the ast module for safe literal evaluation

from .base import Task, get_download_dir, LLAMA3_COT

# Helper class for evaluation. Its job is to take a set of samples,
# get the model's generated answer, and check if it's correct.
class KnowledgeEvaluationTask(fishfarm.tasks.base.Task):
    def __init__(self, samples: Sequence[dict], context_messages: Sequence[fishfarm.Message]):
        self.samples = list(samples)
        self.context_messages = context_messages

    @property
    def num_samples(self) -> int:
        return len(self.samples)

    def evaluate(self, model: fishfarm.Model, sample_ids: Optional[Sequence[int]] = None) -> TaskResult:
        if sample_ids is None:
            sample_ids = range(len(self.samples))
        
        samples_to_eval = [self.samples[i] for i in sample_ids]

        requests = []
        for sample in samples_to_eval:
            question = sample['text'].split('\nAnswer:')[0].replace('Question: ', '').strip()
            messages = list(self.context_messages)
            messages.append(fishfarm.Message(role="user", content=question))
            requests.append(fishfarm.models.GenerationRequest(messages=messages, max_tokens=64))

        sample_details = []
        for sample, result in zip(samples_to_eval, model.generate(requests)):
            output = result.generation.strip().lower()
            
            # Safely parse the string representation of the list
            try:
                possible_answers = ast.literal_eval(sample['possible_answers'])
            except (ValueError, SyntaxError):
                possible_answers = []

            # Check if any of the possible answers is in the model's output
            is_correct = any(answer.lower() in output for answer in possible_answers)

            sample_details.append(
                dict(
                    problem=sample['text'].split('\nAnswer:')[0],
                    output=result.generation.strip(),
                    possible_answers=possible_answers, # Log all possibilities
                    prediction=result.generation.strip(),
                    correct=is_correct,
                )
            )

        correct_count = sum(1 for sd in sample_details if sd["correct"])
        accuracy = correct_count / len(sample_details) if sample_details else 0.0
        
        return TaskResult(aggregate_metrics={"acc": accuracy}, sample_details=sample_details)

# This is the main Task class that Hydra uses to manage the experiment
class KnowledgeTask(Task):
    def __init__(self, dataset_file="knowledge_injection_data/labeled_finetuning_data.csv"):
        self.model_to_template = {"meta-llama/Llama-3.1-8B-Instruct": None}
        self.system_msg = "Answer the following question."
        self.target_metric_train = "acc"
        self.target_metric_valid = "acc"
        self.target_metric_test = "acc"
        self.target_metric_transfer = "acc"
        self.has_training_split = True
        self.has_transfer_split = True # We will use the transfer slot for the 'Unknown' evaluation
        
        # Store dataset file for logging
        self.dataset_file = dataset_file
        
        # Load your labeled dataset
        print(f"Loading dataset from: {dataset_file}")
        df = pd.read_csv(dataset_file)
        self.full_dataset = Dataset.from_pandas(df)
        
        # Store dataset composition for easy access
        self.dataset_composition = {
            'total_samples': len(df),
            'unknown_facts_count': len(df[df['Category'] == 'Unknown']),
            'highly_known_facts_count': len(df[df['Category'] == 'HighlyKnown']),
        }
        uk_count = self.dataset_composition['unknown_facts_count']
        hk_count = self.dataset_composition['highly_known_facts_count']
        self.dataset_composition['uk_to_hk_ratio'] = f"1:{hk_count/uk_count:.1f}" if uk_count > 0 else "1:0"

    def get_train_data(self):
        """
        Provides the data for the training loop.
        """
        train_data = self.full_dataset
        train_size = len(train_data)
        
        train_indices = list(range(train_size))
        valid_indices = list(range(train_size))

        print(f"INFO: Using all {len(train_indices)} samples for training.")
        return train_data, train_indices, valid_indices

    def get_evaluator(self):
        """
        This sets up the FINAL evaluation sets after training is complete.
        """
        # 1. Validation Evaluator (for standard logging, we use the whole set)
        all_samples_evaluator = KnowledgeEvaluationTask(
            samples=list(self.full_dataset),
            context_messages=[fishfarm.Message("system", self.system_msg)]
        )

        # 2. 'HighlyKnown' Evaluator (for measuring Catastrophic Forgetting)
        highly_known_samples = self.full_dataset.filter(lambda x: x['Category'] == 'HighlyKnown')
        highly_known_evaluator = KnowledgeEvaluationTask(
            samples=list(highly_known_samples),
            context_messages=[fishfarm.Message("system", self.system_msg)]
        )

        # 3. 'Unknown' Evaluator (for measuring Knowledge Acquisition)
        unknown_samples = self.full_dataset.filter(lambda x: x['Category'] == 'Unknown')
        unknown_evaluator = KnowledgeEvaluationTask(
            samples=list(unknown_samples),
            context_messages=[fishfarm.Message("system", self.system_msg)]
        )

        # train_eval -> The full dataset (for validation logging)
        # test_eval -> The 'HighlyKnown' set (Catastrophic Forgetting)
        # transfer_eval -> The 'Unknown' set (Knowledge Acquisition)
        return all_samples_evaluator, highly_known_evaluator, unknown_evaluator

    def get_rewards(self, res):
        """
        Provides the +1/-1 reward signal for the reinforcement learning loop.
        """
        return [1.0 if x["correct"] else -1.0 for x in res.sample_details]

    def get_prompt(self, tokenizer, samples, ix, model_id):
        """
        This prompt ONLY provides the question for the RL step.
        """
        chat_template = self.model_to_template[model_id]
        context_msg = {"role": "system", "content": self.system_msg}
        
        full_text = samples['text'][ix]
        question = full_text.split('\nAnswer:')[0].replace('Question: ', '').strip()

        user_msg = {"role": "user", "content": question}
        
        prompt = tokenizer.apply_chat_template(
            conversation=[context_msg, user_msg],
            chat_template=chat_template,
            tokenize=False,
            add_generation_prompt=True,
        )
        return prompt

    def get_vllm_model(self, model_id) -> VLLMModel:
        # Boilerplate VLLM setup
        model = vllm.LLM(
            model_id, max_model_len=1024, gpu_memory_utilization=0.8,
            enforce_eager=True, dtype="bfloat16", # download_dir=get_download_dir()
        )
        chat_template = self.model_to_template[model_id]
        m = model.llm_engine.model_executor.driver_worker.model_runner.model
        for _, param in m.named_parameters():
            param.requires_grad = False
        return VLLMModel(
            model,
            sampling_params=vllm.SamplingParams(temperature=0, top_p=1, max_tokens=64),
            chat_template=chat_template,
        )