"""Unified plotting service for SPARC-LLM experiment outputs."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List


class PlotService:
    """Generate figures from framework output files."""

    @staticmethod
    def _ensure_output_dir(output_dir: str | Path) -> Path:
        out = Path(output_dir)
        out.mkdir(parents=True, exist_ok=True)
        return out

    @staticmethod
    def _load_json(path: str | Path):
        with Path(path).open("r", encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _plt():
        try:
            import matplotlib.pyplot as plt
        except Exception as exc:  # pragma: no cover
            raise RuntimeError(
                "matplotlib is required for plotting. Install dependencies with "
                "`pip install -r requirements.txt` or `pip install matplotlib`."
            ) from exc
        return plt

    @staticmethod
    def plot_orthogonal_training_history(training_history_file: str | Path, output_dir: str | Path = "plots") -> Dict[str, str]:
        data = PlotService._load_json(training_history_file)
        out_dir = PlotService._ensure_output_dir(output_dir)
        plt = PlotService._plt()

        epochs = [row["epoch"] for row in data]
        total = [row["losses"]["total"] for row in data]
        sft = [row["losses"]["sft"] for row in data]
        ip = [row["losses"]["ip"] for row in data]
        ortho = [row["losses"]["ortho"] for row in data]

        plt.figure(figsize=(10, 6))
        plt.plot(epochs, total, label="total", linewidth=2)
        plt.plot(epochs, sft, label="sft", linewidth=2)
        plt.plot(epochs, ip, label="ip", linewidth=2)
        plt.plot(epochs, ortho, label="ortho", linewidth=2)
        plt.xlabel("Epoch")
        plt.ylabel("Loss")
        plt.title("Orthogonal Training Losses")
        plt.grid(True, linestyle=":", alpha=0.6)
        plt.legend()
        plt.tight_layout()
        out_file = out_dir / "orthogonal_training_losses.png"
        plt.savefig(out_file, dpi=200)
        plt.close()
        return {"orthogonal_training_losses": str(out_file)}

    @staticmethod
    def _load_training_log_jsonl(path: str | Path) -> List[dict]:
        entries: List[dict] = []
        p = Path(path)
        content = p.read_text(encoding="utf-8")
        for line in content.splitlines():
            s = line.strip()
            if not s:
                continue
            if s.startswith("{"):
                entries.append(json.loads(s))
        if entries:
            return entries

        decoder = json.JSONDecoder()
        idx = 0
        while idx < len(content):
            while idx < len(content) and content[idx].isspace():
                idx += 1
            if idx >= len(content):
                break
            obj, next_idx = decoder.raw_decode(content, idx)
            if isinstance(obj, dict):
                entries.append(obj)
            idx = next_idx
        return entries

    @staticmethod
    def plot_lora_training_log(training_log_file: str | Path, output_dir: str | Path = "plots") -> Dict[str, str]:
        rows = PlotService._load_training_log_jsonl(training_log_file)
        out_dir = PlotService._ensure_output_dir(output_dir)
        plt = PlotService._plt()

        epochs = [row.get("epoch") for row in rows if row.get("epoch") is not None]
        unknown_acc = [row.get("unknown_accuracy") for row in rows if row.get("epoch") is not None]
        known_acc = [row.get("highly_known_accuracy") for row in rows if row.get("epoch") is not None]
        train_loss = [row.get("train_loss") for row in rows if row.get("epoch") is not None]

        fig, axes = plt.subplots(1, 3, figsize=(16, 4.5))
        axes[0].plot(epochs, unknown_acc, marker="o")
        axes[0].set_title("Unknown Accuracy")
        axes[0].set_xlabel("Epoch")
        axes[0].set_ylabel("Accuracy")
        axes[0].grid(True, linestyle=":", alpha=0.5)

        axes[1].plot(epochs, known_acc, marker="s")
        axes[1].set_title("HighlyKnown Accuracy")
        axes[1].set_xlabel("Epoch")
        axes[1].set_ylabel("Accuracy")
        axes[1].grid(True, linestyle=":", alpha=0.5)

        axes[2].plot(epochs, train_loss, marker="^")
        axes[2].set_title("Train Loss")
        axes[2].set_xlabel("Epoch")
        axes[2].set_ylabel("Loss")
        axes[2].grid(True, linestyle=":", alpha=0.5)

        fig.tight_layout()
        out_file = out_dir / "lora_training_curves.png"
        fig.savefig(out_file, dpi=200)
        plt.close(fig)
        return {"lora_training_curves": str(out_file)}

    @staticmethod
    def plot_merge_results(results_json_file: str | Path, output_dir: str | Path = "plots") -> Dict[str, str]:
        payload = PlotService._load_json(results_json_file)
        out_dir = PlotService._ensure_output_dir(output_dir)
        plt = PlotService._plt()
        metrics = payload.get("results", payload)

        keys = []
        vals = []
        for key, value in metrics.items():
            if isinstance(value, (int, float)):
                keys.append(key)
                vals.append(value)

        plt.figure(figsize=(max(8, len(keys) * 0.6), 5))
        plt.bar(keys, vals)
        plt.xticks(rotation=45, ha="right")
        plt.ylabel("Metric value")
        plt.title("Merge/Evaluation Metrics")
        plt.tight_layout()
        out_file = out_dir / "merge_results_metrics.png"
        plt.savefig(out_file, dpi=200)
        plt.close()
        return {"merge_results_metrics": str(out_file)}
