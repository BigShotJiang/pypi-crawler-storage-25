"""CLI entrypoint for the SPARC framework package."""

from __future__ import annotations

import argparse
import json

from .config import MergeConfig, OrthogonalTrainingConfig, SVDConfig, SVFTrainingConfig
from .pipeline import ModelMergerEvaluator
from .reporting import PlotService
from .workflows import SPARCExperiment


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="sparcllm", description="SPARC-LLM framework CLI")
    sub = parser.add_subparsers(dest="command", required=True)

    svd_parser = sub.add_parser("decompose", help="Run SVD decomposition stage")
    svd_parser.add_argument("--model-id", required=True)
    svd_parser.add_argument("--output-file", required=True)

    svf_parser = sub.add_parser("train-svf", help="Run SVF training stage")
    svf_parser.add_argument("--base-model-key", default="llama3i8b")
    svf_parser.add_argument("--mode", default="training")
    svf_parser.add_argument("--optimization", default="reinforce")

    ortho_parser = sub.add_parser("train-orthogonal", help="Run orthogonal LoRA stage")
    ortho_parser.add_argument("--base-model-key", default="llama3i8b")
    ortho_parser.add_argument("--svf-checkpoint-path", required=True)
    ortho_parser.add_argument("--knowledge-dataset-file", required=True)
    ortho_parser.add_argument("--run-name")
    ortho_parser.add_argument("--num-epochs", type=int, default=10)
    ortho_parser.add_argument("--batch-size", type=int, default=8)
    ortho_parser.add_argument("--lr", type=float, default=2e-4)
    ortho_parser.add_argument("--lambda-ip", type=float, default=0.0)
    ortho_parser.add_argument("--lambda-ortho", type=float, default=100.0)

    eval_parser = sub.add_parser("evaluate", help="Run merge + evaluation")
    eval_parser.add_argument("--base-model-id", required=True)
    eval_parser.add_argument("--device", default="cuda:0")
    eval_parser.add_argument("--mode", default="both", choices=["both", "lora_only", "svf_only", "none"])
    eval_parser.add_argument("--knowledge-dataset-file", default="knowledge_injection_data/500UK_3rHK.csv")
    eval_parser.add_argument("--task-names", nargs="+", default=["gsm8k"])
    eval_parser.add_argument("--lora-adapter-path")
    eval_parser.add_argument("--svf-params-path")
    eval_parser.add_argument("--svd-params-path")
    eval_parser.add_argument("--skip-knowledge-eval", action="store_true")
    eval_parser.add_argument("--skip-task-eval", action="store_true")

    run_parser = sub.add_parser("run", help="Run full/partial experiment workflow")
    run_parser.add_argument("--project-root", default=".")
    run_parser.add_argument("--with-svd", action="store_true")
    run_parser.add_argument("--with-svf", action="store_true")
    run_parser.add_argument("--with-orthogonal", action="store_true")
    run_parser.add_argument("--with-eval", action="store_true")
    run_parser.add_argument("--model-id", default="meta-llama/Llama-3.1-8B-Instruct")
    run_parser.add_argument("--svd-output-file", default="svd_parameters/llama3.1_decomposed_params.pt")
    run_parser.add_argument("--base-model-key", default="llama3i8b")
    run_parser.add_argument("--svf-mode", default="training")
    run_parser.add_argument("--optimization", default="reinforce")
    run_parser.add_argument("--svf-checkpoint-path")
    run_parser.add_argument("--knowledge-dataset-file")
    run_parser.add_argument("--lora-adapter-path")
    run_parser.add_argument("--svf-params-path")
    run_parser.add_argument("--svd-params-path")
    run_parser.add_argument("--eval-mode", default="both", choices=["both", "lora_only", "svf_only", "none"])
    run_parser.add_argument("--task-names", nargs="+", default=["gsm8k"])

    plot_parser = sub.add_parser("plot", help="Generate plots from output files")
    plot_parser.add_argument(
        "--kind",
        required=True,
        choices=["orthogonal_history", "lora_training_log", "merge_results"],
        help="Which output format to plot",
    )
    plot_parser.add_argument("--input-file", required=True, help="Input JSON/JSONL file")
    plot_parser.add_argument("--output-dir", default="plots", help="Where to save generated plots")

    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "decompose":
        experiment = SPARCExperiment()
        report = experiment.run(
            svd_cfg=SVDConfig(model_id=args.model_id, output_file=args.output_file),
        )
        print(json.dumps(report.__dict__, indent=2))
    elif args.command == "train-svf":
        experiment = SPARCExperiment()
        report = experiment.run(
            svf_cfg=SVFTrainingConfig(
                base_model_key=args.base_model_key,
                mode=args.mode,
                optimization=args.optimization,
            ),
        )
        print(json.dumps(report.__dict__, indent=2))
    elif args.command == "train-orthogonal":
        experiment = SPARCExperiment()
        report = experiment.run(
            orthogonal_cfg=OrthogonalTrainingConfig(
                base_model_key=args.base_model_key,
                svf_checkpoint_path=args.svf_checkpoint_path,
                knowledge_dataset_file=args.knowledge_dataset_file,
                run_name=args.run_name,
                num_epochs=args.num_epochs,
                batch_size=args.batch_size,
                lr=args.lr,
                lambda_ip=args.lambda_ip,
                lambda_ortho=args.lambda_ortho,
            ),
        )
        print(json.dumps(report.__dict__, indent=2))
    elif args.command == "evaluate":
        config = MergeConfig(
            base_model_id=args.base_model_id,
            lora_adapter_path=args.lora_adapter_path,
            svf_params_path=args.svf_params_path,
            svd_params_path=args.svd_params_path,
            device=args.device,
            mode=args.mode,
            knowledge_dataset_file=args.knowledge_dataset_file,
            task_names=args.task_names,
            skip_knowledge_eval=args.skip_knowledge_eval,
            skip_task_eval=args.skip_task_eval,
        )
        ModelMergerEvaluator(config=config).evaluate()
    elif args.command == "run":
        experiment = SPARCExperiment(project_root=args.project_root)
        report = experiment.run(
            svd_cfg=(
                SVDConfig(model_id=args.model_id, output_file=args.svd_output_file)
                if args.with_svd
                else None
            ),
            svf_cfg=(
                SVFTrainingConfig(
                    base_model_key=args.base_model_key,
                    mode=args.svf_mode,
                    optimization=args.optimization,
                )
                if args.with_svf
                else None
            ),
            orthogonal_cfg=(
                OrthogonalTrainingConfig(
                    base_model_key=args.base_model_key,
                    svf_checkpoint_path=args.svf_checkpoint_path,
                    knowledge_dataset_file=args.knowledge_dataset_file,
                )
                if args.with_orthogonal and args.svf_checkpoint_path and args.knowledge_dataset_file
                else None
            ),
            merge_cfg=(
                MergeConfig(
                    base_model_id=args.model_id,
                    lora_adapter_path=args.lora_adapter_path,
                    svf_params_path=args.svf_params_path,
                    svd_params_path=args.svd_params_path,
                    mode=args.eval_mode,
                    knowledge_dataset_file=args.knowledge_dataset_file
                    or "knowledge_injection_data/500UK_3rHK.csv",
                    task_names=args.task_names,
                )
                if args.with_eval
                else None
            ),
        )
        print(json.dumps(report.__dict__, indent=2))
    elif args.command == "plot":
        if args.kind == "orthogonal_history":
            out = PlotService.plot_orthogonal_training_history(
                training_history_file=args.input_file,
                output_dir=args.output_dir,
            )
        elif args.kind == "lora_training_log":
            out = PlotService.plot_lora_training_log(
                training_log_file=args.input_file,
                output_dir=args.output_dir,
            )
        else:
            out = PlotService.plot_merge_results(
                results_json_file=args.input_file,
                output_dir=args.output_dir,
            )
        print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
