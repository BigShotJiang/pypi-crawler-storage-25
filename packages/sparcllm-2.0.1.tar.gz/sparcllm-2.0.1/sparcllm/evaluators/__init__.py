"""Evaluation layer for SPARC-LLM."""

from .engine import EvaluationEngine

__all__ = ["EvaluationEngine"]
