"""Evaluation engine using internal service layers."""

from __future__ import annotations

import gc
from typing import Dict

import torch

from sparcllm.datasets import TaskRegistry
from sparcllm.models.composer import ComposeRequest, ModelComposer

from .vllm_weights import load_hf_params_to_vllm


class EvaluationEngine:
    def evaluate(
        self,
        request: ComposeRequest,
        knowledge_dataset_file: str,
        task_names: list[str],
        run_knowledge_eval: bool = True,
    ) -> Dict[str, float]:
        model = ModelComposer.compose(request)
        results: Dict[str, float] = {}

        if run_knowledge_eval:
            knowledge_task = TaskRegistry.create_knowledge_task(knowledge_dataset_file)
            knowledge_vllm = knowledge_task.get_vllm_model(model_id=request.base_model_id)
            load_hf_params_to_vllm(model.state_dict(), knowledge_vllm.llm)
            all_eval, known_eval, unknown_eval = knowledge_task.get_evaluator()
            _ = all_eval
            if unknown_eval is not None:
                results["knowledge_unknown_acc"] = unknown_eval.evaluate(knowledge_vllm).aggregate_metrics.get("acc")
            if known_eval is not None:
                results["knowledge_known_acc"] = known_eval.evaluate(knowledge_vllm).aggregate_metrics.get("acc")
            del knowledge_vllm
            gc.collect()
            torch.cuda.empty_cache()

        for name in task_names:
            task = TaskRegistry.create_task(name)
            vllm_model = task.get_vllm_model(model_id=request.base_model_id)
            load_hf_params_to_vllm(model.state_dict(), vllm_model.llm)
            evaluators = task.get_evaluator()
            test_eval = evaluators[1] if len(evaluators) > 1 else evaluators[0]
            result = test_eval.evaluate(vllm_model).aggregate_metrics
            results[f"{name}_acc"] = result.get("acc")
            del vllm_model
            gc.collect()
            torch.cuda.empty_cache()

        del model
        gc.collect()
        torch.cuda.empty_cache()
        return results
