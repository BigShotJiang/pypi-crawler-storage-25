"""High-level sklearn-inspired API for SPARC-LLM."""

from __future__ import annotations

import os
from dataclasses import asdict
from pathlib import Path
from typing import Dict, Optional

from .base import BaseEstimator
from .config import ComposeRequest, MergeConfig, OrthogonalTrainingConfig, SVDConfig, SVFTrainingConfig
from .runner import CommandRunner
from .trainers import OrthogonalTrainingService, SVDService, SVFTrainingService


class SVDDecomposer(BaseEstimator):
    def __init__(self, config: SVDConfig, project_root: str | Path = ".") -> None:
        self.config = config
        self.project_root = str(project_root)
        self._runner = CommandRunner(project_root=project_root)

    def fit(self) -> "SVDDecomposer":
        SVDService(self._runner).run(self.config)
        return self


class SVFTrainer(BaseEstimator):
    def __init__(self, config: SVFTrainingConfig, project_root: str | Path = ".") -> None:
        self.config = config
        self.project_root = str(project_root)
        self._runner = CommandRunner(project_root=project_root)

    def fit(self) -> "SVFTrainer":
        SVFTrainingService(self._runner).run(self.config)
        return self


class OrthogonalLoRATrainer(BaseEstimator):
    def __init__(self, config: OrthogonalTrainingConfig, project_root: str | Path = ".") -> None:
        self.config = config
        self.project_root = str(project_root)
        self._runner = CommandRunner(project_root=project_root)

    def fit(self) -> "OrthogonalLoRATrainer":
        OrthogonalTrainingService(self._runner).run(self.config)
        return self


class ModelMergerEvaluator(BaseEstimator):
    def __init__(self, config: MergeConfig, project_root: str | Path = ".") -> None:
        self.config = config
        self.project_root = str(project_root)
        self._runner = CommandRunner(project_root=project_root)
        from .evaluators import EvaluationEngine

        self._engine = EvaluationEngine()

    def evaluate(self) -> Dict[str, float]:
        cfg = self.config
        request = ComposeRequest(
            base_model_id=cfg.base_model_id,
            lora_adapter_path=cfg.lora_adapter_path,
            svf_params_path=cfg.svf_params_path,
            svd_params_path=cfg.svd_params_path,
            device=cfg.device,
            mode=cfg.mode,
        )
        task_names = [] if cfg.skip_task_eval else cfg.task_names
        results = self._engine.evaluate(
            request=request,
            knowledge_dataset_file=cfg.knowledge_dataset_file,
            task_names=task_names,
            run_knowledge_eval=not cfg.skip_knowledge_eval,
        )
        return results


class SPARCPipeline(BaseEstimator):
    """Orchestrates the full SPARC pipeline with clean object API."""

    def __init__(
        self,
        svd: Optional[SVDConfig] = None,
        svf: Optional[SVFTrainingConfig] = None,
        orthogonal: Optional[OrthogonalTrainingConfig] = None,
        merge: Optional[MergeConfig] = None,
        project_root: str | Path = ".",
    ) -> None:
        self.svd = svd
        self.svf = svf
        self.orthogonal = orthogonal
        self.merge = merge
        self.project_root = str(project_root)

    def run(self, run_svd: bool = True, run_svf: bool = True, run_orthogonal: bool = True, run_eval: bool = True):
        if run_svd and self.svd is not None:
            SVDDecomposer(self.svd, project_root=self.project_root).fit()
        if run_svf and self.svf is not None:
            SVFTrainer(self.svf, project_root=self.project_root).fit()
        if run_orthogonal and self.orthogonal is not None:
            OrthogonalLoRATrainer(self.orthogonal, project_root=self.project_root).fit()
        if run_eval and self.merge is not None:
            return ModelMergerEvaluator(self.merge, project_root=self.project_root).evaluate()
        return None

    def to_dict(self) -> Dict[str, dict]:
        return {
            "svd": asdict(self.svd) if self.svd else {},
            "svf": asdict(self.svf) if self.svf else {},
            "orthogonal": asdict(self.orthogonal) if self.orthogonal else {},
            "merge": asdict(self.merge) if self.merge else {},
            "project_root": os.path.abspath(self.project_root),
        }
