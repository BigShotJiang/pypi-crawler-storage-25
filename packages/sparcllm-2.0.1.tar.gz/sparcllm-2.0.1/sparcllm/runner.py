"""Command runner used by framework classes."""

from __future__ import annotations

import shlex
import subprocess
from pathlib import Path
from typing import Iterable, List, Optional


class CommandRunner:
    """Runs project entrypoints with consistent logging and errors."""

    def __init__(self, project_root: str | Path):
        self.project_root = Path(project_root).resolve()

    def run(self, args: Iterable[str], env: Optional[dict] = None) -> subprocess.CompletedProcess:
        cmd: List[str] = list(args)
        printable = " ".join(shlex.quote(arg) for arg in cmd)
        print(f"[sparcllm] Running: {printable}")
        result = subprocess.run(
            cmd,
            cwd=str(self.project_root),
            env=env,
            text=True,
            capture_output=True,
            check=False,
        )
        if result.returncode != 0:
            raise RuntimeError(
                "Command failed with non-zero exit code.\n"
                f"Command: {printable}\n"
                f"Return code: {result.returncode}\n"
                f"STDOUT:\n{result.stdout}\n"
                f"STDERR:\n{result.stderr}"
            )
        return result
