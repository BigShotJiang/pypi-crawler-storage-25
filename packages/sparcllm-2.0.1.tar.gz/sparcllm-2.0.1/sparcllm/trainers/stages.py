"""Training services wrapping project entrypoints."""

from __future__ import annotations

import sys

from sparcllm.config import OrthogonalTrainingConfig, SVDConfig, SVFTrainingConfig
from sparcllm.runner import CommandRunner


class SVDService:
    def __init__(self, runner: CommandRunner) -> None:
        self.runner = runner

    def run(self, cfg: SVDConfig) -> None:
        self.runner.run(
            [
                sys.executable,
                "decompose_svd.py",
                "--model_id",
                cfg.model_id,
                "--output_file",
                cfg.output_file,
            ]
        )


class SVFTrainingService:
    def __init__(self, runner: CommandRunner) -> None:
        self.runner = runner

    def run(self, cfg: SVFTrainingConfig) -> None:
        args = [
            sys.executable,
            "svd_reinforce_hydra.py",
            f"base_model@_global_={cfg.base_model_key}",
            f"mode@_global_={cfg.mode}",
            f"optimization@_global_={cfg.optimization}",
        ]
        args.extend(f"{k}={v}" for k, v in cfg.extra_overrides.items())
        self.runner.run(args)


class OrthogonalTrainingService:
    def __init__(self, runner: CommandRunner) -> None:
        self.runner = runner

    def run(self, cfg: OrthogonalTrainingConfig) -> None:
        lora_targets = "[" + ",".join(f"'{name}'" for name in cfg.lora_target_modules) + "]"
        args = [
            sys.executable,
            "orthogonal_learning_hydra.py",
            f"base_model@_global_={cfg.base_model_key}",
            f"svf_checkpoint_path={cfg.svf_checkpoint_path}",
            f"out_dir={cfg.out_dir}",
            f"seed={cfg.seed}",
            f"num_epochs={cfg.num_epochs}",
            f"batch_size={cfg.batch_size}",
            f"lr={cfg.lr}",
            f"weight_decay={cfg.weight_decay}",
            f"lambda_ip={cfg.lambda_ip}",
            f"lambda_ortho={cfg.lambda_ortho}",
            f"k_critical_vectors={cfg.k_critical_vectors}",
            f"orthogonality_loss_version={cfg.orthogonality_loss_version}",
            f"lora.r={cfg.lora_r}",
            f"lora.lora_alpha={cfg.lora_alpha}",
            f"lora.lora_dropout={cfg.lora_dropout}",
            f"lora.target_modules={lora_targets}",
            f"skill_task_loader._target_={cfg.skill_task_class}",
            f"knowledge_task_loader._target_={cfg.knowledge_task_class}",
            f"knowledge_task_loader.dataset_file={cfg.knowledge_dataset_file}",
            f"wandb_log={str(cfg.wandb_log).lower()}",
            f"wandb_project={cfg.wandb_project}",
        ]
        if cfg.run_name:
            args.append(f"run_name={cfg.run_name}")
        args.extend(f"{k}={v}" for k, v in cfg.extra_overrides.items())
        self.runner.run(args)
