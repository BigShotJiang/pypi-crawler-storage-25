"""Dataset/task access layer for SPARC-LLM."""

from .registry import TaskRegistry

__all__ = ["TaskRegistry"]
