"""Central registry to resolve task objects."""

from __future__ import annotations

from typing import Any, Dict, Type

_TASK_CLASSES: Dict[str, Type] | None = None


def _task_classes() -> Dict[str, Type]:
    global _TASK_CLASSES
    if _TASK_CLASSES is None:
        from sparcllm.tasks import AI2ArcTask, ClsTask, Gsm8kTask, MathTask, Mbpp2Task

        _TASK_CLASSES = {
            "gsm8k": Gsm8kTask,
            "arc": AI2ArcTask,
            "math": MathTask,
            "mbpp2": Mbpp2Task,
            "cls": ClsTask,
        }
    return _TASK_CLASSES


class TaskRegistry:
    @classmethod
    def create_task(cls, name: str) -> Any:
        key = name.strip().lower()
        tasks = _task_classes()
        if key not in tasks:
            raise ValueError(f"Unknown task '{name}'. Valid keys: {sorted(tasks.keys())}")
        return tasks[key]()

    @staticmethod
    def create_knowledge_task(dataset_file: str) -> Any:
        from sparcllm.tasks import KnowledgeTask

        return KnowledgeTask(dataset_file)
