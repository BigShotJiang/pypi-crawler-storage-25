"""Typed configuration objects for SPARC-LLM stages."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


@dataclass
class SVDConfig:
    model_id: str = "meta-llama/Llama-3.1-8B-Instruct"
    output_file: str = "svd_parameters/llama3.1_decomposed_params.pt"


@dataclass
class SVFTrainingConfig:
    base_model_key: str = "llama3i8b"
    mode: str = "training"
    optimization: str = "reinforce"
    extra_overrides: Dict[str, str] = field(default_factory=dict)


@dataclass
class OrthogonalTrainingConfig:
    base_model_key: str = "llama3i8b"
    svf_checkpoint_path: str = "svf_adapters/gsm_131224_policy_params.pt"
    out_dir: str = "results_orthogonal"
    run_name: Optional[str] = None
    seed: int = 42
    num_epochs: int = 10
    batch_size: int = 8
    lr: float = 2e-4
    weight_decay: float = 0.01
    lambda_ip: float = 0.0
    lambda_ortho: float = 100.0
    k_critical_vectors: int = 64
    orthogonality_loss_version: str = "uniform"
    lora_r: int = 16
    lora_alpha: int = 32
    lora_dropout: float = 0.05
    lora_target_modules: List[str] = field(
        default_factory=lambda: ["mlp.gate_proj", "mlp.up_proj", "mlp.down_proj"]
    )
    knowledge_dataset_file: str = "knowledge_injection_data/500UK_3rHK.csv"
    skill_task_class: str = "sparcllm.tasks.Gsm8kTask"
    knowledge_task_class: str = "sparcllm.tasks.KnowledgeTask"
    wandb_log: bool = False
    wandb_project: str = "orthogonal-learning"
    extra_overrides: Dict[str, str] = field(default_factory=dict)


@dataclass
class MergeConfig:
    base_model_id: str = "meta-llama/Llama-3.1-8B-Instruct"
    lora_adapter_path: Optional[str] = None
    svf_params_path: Optional[str] = None
    svd_params_path: Optional[str] = None
    device: str = "cuda:0"
    mode: str = "both"  # one of: both, lora_only, svf_only, none
    knowledge_dataset_file: str = "knowledge_injection_data/500UK_3rHK.csv"
    task_names: List[str] = field(default_factory=lambda: ["gsm8k"])
    skip_knowledge_eval: bool = False
    skip_task_eval: bool = False


@dataclass
class ComposeRequest:
    base_model_id: str
    lora_adapter_path: Optional[str]
    svf_params_path: Optional[str]
    svd_params_path: Optional[str]
    device: str
    mode: str
