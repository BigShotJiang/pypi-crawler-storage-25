"""Small sklearn-inspired base class utilities."""

from __future__ import annotations

from dataclasses import asdict, is_dataclass
from typing import Any, Dict


class BaseEstimator:
    """Lightweight sklearn-like estimator API."""

    def get_params(self, deep: bool = True) -> Dict[str, Any]:
        params: Dict[str, Any] = {}
        for name, value in self.__dict__.items():
            if name.startswith("_"):
                continue
            if is_dataclass(value):
                params[name] = asdict(value) if deep else value
            else:
                params[name] = value
        return params

    def set_params(self, **params: Any) -> "BaseEstimator":
        for key, value in params.items():
            if not hasattr(self, key):
                raise ValueError(f"Unknown parameter '{key}' for {self.__class__.__name__}.")
            setattr(self, key, value)
        return self
