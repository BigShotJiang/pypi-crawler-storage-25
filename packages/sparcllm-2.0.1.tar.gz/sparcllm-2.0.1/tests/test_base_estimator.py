from dataclasses import dataclass

from sparcllm.base import BaseEstimator


@dataclass
class DummyConfig:
    alpha: int = 1


class DummyEstimator(BaseEstimator):
    def __init__(self):
        self.config = DummyConfig()
        self.name = "demo"
        self._private = "skip"


def test_get_params_excludes_private():
    est = DummyEstimator()
    params = est.get_params()
    assert "_private" not in params
    assert params["name"] == "demo"
    assert params["config"]["alpha"] == 1


def test_set_params_updates_known_fields():
    est = DummyEstimator()
    est.set_params(name="updated")
    assert est.name == "updated"
