import json
from pathlib import Path

import pytest

pytest.importorskip("matplotlib")

from sparcllm.reporting import PlotService


def test_plot_orthogonal_training_history(tmp_path: Path):
    input_file = tmp_path / "training_history.json"
    input_file.write_text(
        json.dumps(
            [
                {"epoch": 1, "losses": {"total": 2.0, "sft": 1.0, "ip": 0.2, "ortho": 0.8}},
                {"epoch": 2, "losses": {"total": 1.5, "sft": 0.9, "ip": 0.1, "ortho": 0.5}},
            ]
        ),
        encoding="utf-8",
    )
    out = PlotService.plot_orthogonal_training_history(input_file, tmp_path)
    assert Path(out["orthogonal_training_losses"]).exists()


def test_plot_lora_training_log(tmp_path: Path):
    input_file = tmp_path / "training_log.json"
    input_file.write_text(
        "\n".join(
            [
                json.dumps(
                    {
                        "epoch": 1,
                        "unknown_accuracy": 0.3,
                        "highly_known_accuracy": 0.7,
                        "train_loss": 2.5,
                    }
                ),
                json.dumps(
                    {
                        "epoch": 2,
                        "unknown_accuracy": 0.4,
                        "highly_known_accuracy": 0.72,
                        "train_loss": 2.1,
                    }
                ),
            ]
        ),
        encoding="utf-8",
    )
    out = PlotService.plot_lora_training_log(input_file, tmp_path)
    assert Path(out["lora_training_curves"]).exists()


def test_plot_merge_results(tmp_path: Path):
    input_file = tmp_path / "results.json"
    input_file.write_text(
        json.dumps({"results": {"gsm8k_acc": 0.45, "arc_acc": 0.38}}),
        encoding="utf-8",
    )
    out = PlotService.plot_merge_results(input_file, tmp_path)
    assert Path(out["merge_results_metrics"]).exists()
