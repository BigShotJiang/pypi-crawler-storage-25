from sparcllm.config import ComposeRequest, MergeConfig, SVDConfig


def test_svd_config_defaults():
    cfg = SVDConfig()
    assert "svd_parameters" in cfg.output_file


def test_merge_config_defaults():
    cfg = MergeConfig()
    assert cfg.mode == "both"
    assert cfg.task_names


def test_compose_request_mode_roundtrip():
    req = ComposeRequest(
        base_model_id="x",
        lora_adapter_path=None,
        svf_params_path=None,
        svd_params_path=None,
        device="cpu",
        mode="none",
    )
    assert req.mode == "none"
