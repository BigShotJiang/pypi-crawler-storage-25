"""LocalFirst MCP Server."""
from __future__ import annotations
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def create_mcp_server():
    try:
        from fastmcp import FastMCP
    except ImportError:
        raise ImportError("fastmcp required. Install with: pip install localfirst[mcp]")

    mcp = FastMCP("localfirst")

    @mcp.tool()
    def localfirst_prep(
        task: str,
        repo_path: Optional[str] = None,
        extra_context: Optional[str] = None,
        output_format: str = "compact",
    ) -> str:
        """Prepare context + routing decision for a coding task."""
        import subprocess
        repo = Path(repo_path or ".").resolve()
        args = ["localfirst", "prep", task, "--repo", str(repo), "--output", output_format]
        if extra_context:
            args += ["--context", extra_context]
        result = subprocess.run(args, capture_output=True, text=True, cwd=str(repo))
        return result.stdout or result.stderr

    @mcp.tool()
    def localfirst_route(task: str, repo_path: Optional[str] = None) -> str:
        """Show routing decision without running."""
        import subprocess
        repo = Path(repo_path or ".").resolve()
        result = subprocess.run(["localfirst", "route", task, "--repo", str(repo)],
                                capture_output=True, text=True)
        return result.stdout

    @mcp.tool()
    def localfirst_status(repo_path: Optional[str] = None) -> str:
        """Show LocalFirst status."""
        import subprocess
        result = subprocess.run(["localfirst", "check"], capture_output=True, text=True)
        return result.stdout

    return mcp


def run_stdio() -> None:
    mcp = create_mcp_server()
    mcp.run(transport="stdio")


def run_http(port: int = 8765) -> None:
    mcp = create_mcp_server()
    mcp.run(transport="sse", port=port)
