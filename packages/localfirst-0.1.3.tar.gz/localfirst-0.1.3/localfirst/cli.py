"""
LocalFirst CLI.

Commands:
    localfirst init     — Setup: hardware detection, Ollama, config
    localfirst prep     — Prepare context + route task
    localfirst route    — Show routing decision for a task
    localfirst stats    — Show token savings
    localfirst bench    — Benchmark savings on this repo
    localfirst mcp      — MCP server commands
    localfirst check    — Check tool availability
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import box

app = typer.Typer(
    name="localfirst",
    help="Your hardware runs first. Cloud is the exception, not the rule.",
    add_completion=False,
    no_args_is_help=True,
)
console = Console()

VERSION = "0.1.3"


def _setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(level=level, format="%(levelname)s %(name)s: %(message)s")


# ── init ─────────────────────────────────────────────────────────────────────

@app.command()
def init(
    repo: Annotated[Optional[Path], typer.Argument(help="Repo path (default: cwd)")] = None,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip prompts")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Initialize LocalFirst: detect hardware, setup Ollama, create config."""
    _setup_logging(verbose)
    from localfirst.hardware import detect_hardware
    from localfirst.ollama import OllamaClient, get_install_instructions, RECOMMENDED_MODELS
    from localfirst.config import init_config

    repo_path = (repo or Path.cwd()).resolve()

    console.print()
    console.print("[bold]LocalFirst Setup[/bold]")
    console.print("[dim]Your hardware runs first. Cloud is the exception.[/dim]")
    console.print()

    # Hardware detection
    console.print("🔍 Detecting hardware...")
    hw = detect_hardware()
    console.print(f"   CPU:  [cyan]{hw.cpu_name[:50]}[/cyan]")
    console.print(f"   RAM:  [cyan]{hw.ram_gb:.0f}GB[/cyan]")
    if hw.gpu_name:
        console.print(f"   GPU:  [cyan]{hw.gpu_name}[/cyan]" + (f" ({hw.gpu_vram_gb:.0f}GB VRAM)" if hw.gpu_vram_gb else ""))
    console.print()

    # Ollama check
    client = OllamaClient()
    ollama_running = asyncio.run(client.is_running())
    worker_model = None

    if ollama_running:
        console.print("✓ [green]Ollama is running[/green]")
        installed_models = asyncio.run(client.list_models())
        recommended = hw.recommended_model

        # Check if recommended model is already installed
        already_installed = any(recommended.split(":")[0] in m for m in installed_models)

        if already_installed:
            console.print(f"✓ [green]Model ready:[/green] {recommended}")
            worker_model = recommended
        else:
            console.print(f"   Recommended model: [cyan]{recommended}[/cyan] ({hw.recommended_model_size})")

            if not yes:
                pull = typer.confirm(f"   Pull {recommended} now?", default=True)
            else:
                pull = True

            if pull:
                console.print(f"   Pulling {recommended}...")
                success = asyncio.run(client.pull_model(recommended))
                if success:
                    console.print(f"   ✓ [green]{recommended} ready[/green]")
                    worker_model = recommended
                else:
                    console.print(f"   [yellow]Pull failed. You can try manually: ollama pull {recommended}[/yellow]")
    else:
        console.print("✗ [yellow]Ollama not found[/yellow]")
        install_cmd = get_install_instructions(hw.platform)
        console.print(f"   Install: [dim]{install_cmd}[/dim]")
        console.print(f"   Then: [dim]ollama pull {hw.recommended_model}[/dim]")
        console.print()
        console.print("   [dim]Continuing without local model — tasks will route to cloud.[/dim]")

    console.print()

    # Create config
    config_path = init_config(repo_path, worker_model=worker_model)
    console.print(f"✓ Config: [dim]{config_path}[/dim]")
    console.print()

    if worker_model:
        console.print("[bold green]Ready![/bold green] Local model active.")
        console.print(f"   Worker: [cyan]{worker_model}[/cyan] (free, local)")
        console.print(f"   Planner: [cyan]claude-haiku[/cyan]")
        console.print(f"   Coder: [cyan]claude-sonnet[/cyan]")
    else:
        console.print("[bold]Ready![/bold] Cloud routing active.")
        console.print("   Install Ollama for local model support.")

    console.print()
    console.print('Run [bold cyan]localfirst prep "your task"[/bold cyan] to get started.')


# ── prep ─────────────────────────────────────────────────────────────────────

@app.command()
def prep(
    task: Annotated[str, typer.Argument(help="Task description")],
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    context: Annotated[Optional[str], typer.Option("--context", "-c")] = None,
    output: Annotated[str, typer.Option("--output", "-o")] = "compact",
    route_only: Annotated[bool, typer.Option("--route-only", help="Show routing decision only")] = False,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Prepare context for a task and route to the right model."""
    _setup_logging(verbose)

    repo_path = (repo or Path.cwd()).resolve()

    from localfirst.config import load_config
    from localfirst.router import Router
    from localfirst.token_counter import TokenCounter, RunStats, calculate_savings

    import time
    import uuid

    config = load_config(repo_root=repo_path)
    router = Router(config)

    # Step 1: Build context pack (LAO core)
    try:
        from lao.core.runner import run_prep
        from lao.models import TaskInput
    except ImportError:
        # Fallback: call lao CLI
        _prep_via_cli(task, repo_path, context, output)
        return

    console.print()
    start = time.monotonic()

    task_input = TaskInput(task=task, repo_path=repo_path)
    if context:
        task_input.extra_context = context

    pack, report, pack_path, _ = run_prep(task_input, silent=True)

    duration_ms = (time.monotonic() - start) * 1000

    # Step 2: Route
    decision = router.route(task, context_tokens=pack.optimized_token_estimate)

    if route_only:
        _show_routing_decision(decision, pack)
        return

    # Step 3: Display
    _show_prep_result(pack, report, decision, output)

    # Step 3b: Run worker if applicable
    if decision.layer.value == "worker" and config.get("worker", {}).get("enabled"):
        _run_worker(task, pack, config)

    # Step 4: Track
    counter = TokenCounter(repo_path)
    savings = calculate_savings(
        pack.optimized_token_estimate,
        report.repo_total_tokens or 0,
        decision.model,
    )
    counter.record(RunStats(
        run_id=str(uuid.uuid4())[:8],
        task=task[:200],
        timestamp=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
        routing_layer=decision.layer.value,
        model=decision.model,
        tokens_local=pack.optimized_token_estimate if decision.is_local else 0,
        tokens_cloud=0 if decision.is_local else pack.optimized_token_estimate,
        tokens_repo_total=report.repo_total_tokens or 0,
        cost_usd=decision.estimated_cost_usd,
        cost_saved_usd=savings,
        duration_ms=duration_ms,
    ))


def _prep_via_cli(task: str, repo: Path, context: Optional[str], output: str) -> None:
    """Fallback: call lao CLI directly."""
    import subprocess
    args = ["lao", "prep", task, "--repo", str(repo), "--output", output]
    if context:
        args += ["--context", context]
    subprocess.run(args)


def _show_routing_decision(decision, pack) -> None:
    console.print()
    console.print(f"  Route:   [bold]{decision.display}[/bold]")
    console.print(f"  Reason:  [dim]{decision.reason}[/dim]")
    console.print(f"  Tokens:  [cyan]{pack.optimized_token_estimate:,}[/cyan]")
    if decision.estimated_cost_usd > 0:
        console.print(f"  Cost:    [yellow]~${decision.estimated_cost_usd:.4f}[/yellow]")
    else:
        console.print(f"  Cost:    [green]$0.00 (local)[/green]")
    console.print()


def _show_prep_result(pack, report, decision, output_format: str) -> None:
    from lao.output.compact import render_compact
    from lao.output.display import print_prep_result as print_pack_summary

    if output_format == "compact":
        text = render_compact(pack, report)
        # Add routing info
        route_line = f"ROUTE:{decision.layer.value.upper()} MODEL:{decision.model}"
        if decision.is_local:
            route_line += " COST:$0.00"
        else:
            route_line += f" COST:~${decision.estimated_cost_usd:.4f}"
        console.print(text)
        console.print(route_line)
    else:
        print_pack_summary(pack, report)
        console.print()
        console.print(f"  → Route: [bold]{decision.display}[/bold]")


# ── route ─────────────────────────────────────────────────────────────────────



def _run_worker(task: str, pack, config: dict) -> None:
    """Run task via local Ollama model using httpx sync."""
    import httpx
    model = config["worker"]["model"]
    ollama_url = config["worker"].get("ollama_url", "http://localhost:11434")

    context_text = ""
    for sf in pack.selected_files[:5]:
        try:
            text = sf.file.path.read_text(encoding="utf-8", errors="ignore")[:2000]
            context_text += f"\n--- {sf.file.relative_path} ---\n{text}\n"
        except Exception:
            pass

    messages = [{"role": "user", "content": f"{task}\n\nContext:\n{context_text}"}]
    console.print(f"[dim]Running on {model} locally...[/dim]")

    try:
        with httpx.Client(timeout=120) as client:
            r = client.post(
                f"{ollama_url}/api/chat",
                json={"model": model, "messages": messages, "stream": False,
                      "options": {"temperature": 0.1, "num_predict": 2000}},
            )
            response = r.json().get("message", {}).get("content", "")
    except Exception as e:
        console.print(f"[yellow]Worker error: {e}[/yellow]")
        return

    if response:
        console.print()
        console.rule(f"[bold green]Worker Response ({model})[/bold green]")
        console.print(response)
        console.print()
    else:
        console.print("[yellow]Worker returned empty response.[/yellow]")


@app.command()
def route(
    task: Annotated[str, typer.Argument(help="Task to classify")],
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Show routing decision for a task without running it."""
    _setup_logging(verbose)
    repo_path = (repo or Path.cwd()).resolve()

    from localfirst.config import load_config
    from localfirst.router import Router

    config = load_config(repo_root=repo_path)
    router = Router(config)
    decision = router.route(task)

    console.print()
    console.rule("[bold]Routing Decision[/bold]")
    console.print()
    console.print(f"  Task:    [dim]{task}[/dim]")
    console.print(f"  Layer:   [bold]{decision.layer.value}[/bold]")
    console.print(f"  Model:   [cyan]{decision.model}[/cyan]")
    console.print(f"  Reason:  [dim]{decision.reason}[/dim]")
    if decision.is_local:
        console.print(f"  Cost:    [bold green]$0.00 (local)[/bold green]")
    else:
        console.print(f"  Cost:    ~${decision.estimated_cost_usd:.4f} per task")
    console.print()


# ── stats ─────────────────────────────────────────────────────────────────────

@app.command()
def stats(
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    days: Annotated[int, typer.Option("--days", "-d")] = 7,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Show token usage and cost savings."""
    _setup_logging(verbose)
    repo_path = (repo or Path.cwd()).resolve()

    from localfirst.token_counter import TokenCounter

    counter = TokenCounter(repo_path)
    summary = counter.weekly_summary(days=days)

    if summary.runs == 0:
        console.print("[dim]No runs recorded yet. Run 'localfirst prep' first.[/dim]")
        return

    console.print()
    console.rule(f"[bold]Last {days} Days[/bold]")
    console.print()
    console.print(f"  Tasks prepared:   [cyan]{summary.runs}[/cyan]")
    console.print(f"  Local handling:   [bold green]{summary.local_pct:.0f}%[/bold green] of tasks")
    console.print(f"  Tokens local:     [cyan]{summary.tokens_local:,}[/cyan] [dim](free)[/dim]")
    console.print(f"  Tokens cloud:     [cyan]{summary.tokens_cloud:,}[/cyan]")
    console.print(f"  Tokens saved:     [cyan]{summary.tokens_saved:,}[/cyan]")
    console.print()
    console.print(f"  Cost paid:        [yellow]${summary.cost_usd:.2f}[/yellow]")
    console.print(f"  Cost saved:       [bold green]${summary.cost_saved_usd:.2f}[/bold green]")
    console.print()


# ── bench ─────────────────────────────────────────────────────────────────────

@app.command()
def bench(
    repo: Annotated[Optional[Path], typer.Option("--repo", "-r")] = None,
    model: Annotated[str, typer.Option("--model", "-m")] = "claude-sonnet-4-6",
    tasks: Annotated[int, typer.Option("--tasks", "-t")] = 20,
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Benchmark token savings vs sending full repo to cloud."""
    _setup_logging(verbose)

    # Delegate to lao bench if available, otherwise basic version
    import subprocess
    repo_path = (repo or Path.cwd()).resolve()
    result = subprocess.run(
        ["lao", "bench", "--repo", str(repo_path), "--model", model, "--tasks", str(tasks)],
        capture_output=False
    )


# ── check ─────────────────────────────────────────────────────────────────────

@app.command()
def check(
    verbose: Annotated[bool, typer.Option("--verbose", "-v")] = False,
) -> None:
    """Check tool availability and configuration."""
    _setup_logging(verbose)
    import asyncio
    from localfirst.hardware import detect_hardware
    from localfirst.ollama import OllamaClient

    console.print()
    console.print(f"[bold]LocalFirst[/bold] v{VERSION}")
    console.print()

    # Hardware
    hw = detect_hardware()
    console.print("[bold]Hardware:[/bold]")
    console.print(f"  RAM:  [cyan]{hw.ram_gb:.0f}GB[/cyan]")
    console.print(f"  CPU:  [dim]{hw.cpu_name[:60]}[/dim]")
    if hw.gpu_name:
        console.print(f"  GPU:  [cyan]{hw.gpu_name}[/cyan]")
    console.print()

    # Tools
    console.print("[bold]Tools:[/bold]")
    import shutil
    for binary, name in [("rg", "ripgrep"), ("gitleaks", "gitleaks"), ("ollama", "Ollama")]:
        if shutil.which(binary):
            console.print(f"  ✓ [green]{name}[/green]")
        else:
            console.print(f"  ✗ [yellow]{name}[/yellow]")

    # Ollama models
    client = OllamaClient()
    if asyncio.run(client.is_running()):
        models = asyncio.run(client.list_models())
        console.print()
        console.print("[bold]Local models:[/bold]")
        for m in models:
            console.print(f"  ✓ [green]{m}[/green]")
        if not models:
            console.print("  [dim]No models installed[/dim]")

    console.print()


# ── version ───────────────────────────────────────────────────────────────────

@app.command()
def version() -> None:
    """Show version."""
    console.print(f"localfirst v{VERSION}")


# ── mcp ───────────────────────────────────────────────────────────────────────

mcp_app = typer.Typer(help="MCP server commands.")
app.add_typer(mcp_app, name="mcp")


@mcp_app.command("start")
def mcp_start(
    http: Annotated[bool, typer.Option("--http")] = False,
    port: Annotated[int, typer.Option("--port")] = 8765,
) -> None:
    """Start MCP server (stdio or HTTP)."""
    from localfirst.mcp.server import run_stdio, run_http
    if http:
        run_http(port)
    else:
        run_stdio()


@mcp_app.command("config")
def mcp_config() -> None:
    """Show MCP configuration snippet."""
    import sys
    executable = sys.executable.replace("python", "localfirst").replace("python3", "localfirst")

    console.print()
    console.print("[bold]Claude Code (.claude/settings.json):[/bold]")
    config = {
        "mcpServers": {
            "localfirst": {
                "command": executable,
                "args": ["mcp", "start"]
            }
        }
    }
    import json
    console.print(json.dumps(config, indent=2))
    console.print()


if __name__ == "__main__":
    app()
