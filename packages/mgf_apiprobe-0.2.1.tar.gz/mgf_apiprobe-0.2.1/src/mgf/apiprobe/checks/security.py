"""Security checks — TLS hygiene + secret-echo.

See: ``DESIGN.md`` §7.5.

4 checks, all with ``RootCause.PROVIDER_SECURITY``:

  - ``MissingHsts``                — HTTPS endpoint without Strict-Transport-Security
  - ``MissingContentTypeOptions``  — no ``X-Content-Type-Options: nosniff``
  - ``MissingFrameOptions``        — no ``X-Frame-Options`` AND no CSP frame-ancestors
  - ``BodyEchoesSecret``           — request Authorization header value appears in response body

The hygiene checks fire only on responses that look like they're
serving content to a browser (HTML or JSON for SPAs). API-only
responses where the headers are less load-bearing get a pass via the
opt-in design — checks are disabled per-probe via tags or via
``Suite.severity_overrides``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

from mgf.apiprobe.core.check import Check
from mgf.apiprobe.core.finding import RootCause, Severity

if TYPE_CHECKING:
    from collections.abc import Iterable

    from mgf.apiprobe.core.context import Context
    from mgf.apiprobe.core.finding import Finding
    from mgf.apiprobe.core.probe import Probe
    from mgf.apiprobe.core.response import Response


class MissingHsts(Check):
    """HTTPS endpoint without ``Strict-Transport-Security`` header."""

    code: ClassVar[str] = "security.headers.missing-hsts"
    severity_default: ClassVar[Severity] = Severity.WARN
    root_cause_default: ClassVar[RootCause] = RootCause.PROVIDER_SECURITY

    def run(
        self,
        probe: Probe,
        response: Response,
        ctx: Context,
    ) -> Iterable[Finding]:
        if not response.url.startswith("https://"):
            return
        if response.header("Strict-Transport-Security") is not None:
            return
        yield self.finding(
            probe_id=probe.probe_id,
            message="HTTPS response missing Strict-Transport-Security header.",
            evidence={"url": response.url},
            remediation=(
                "Provider should set Strict-Transport-Security on every "
                "HTTPS response. Recommended: max-age=31536000; "
                "includeSubDomains."
            ),
            threat_refs=("OWASP-API-7",),
        )


class MissingContentTypeOptions(Check):
    """Response missing ``X-Content-Type-Options: nosniff``."""

    code: ClassVar[str] = "security.headers.missing-content-type-options"
    severity_default: ClassVar[Severity] = Severity.WARN
    root_cause_default: ClassVar[RootCause] = RootCause.PROVIDER_SECURITY

    def run(
        self,
        probe: Probe,
        response: Response,
        ctx: Context,
    ) -> Iterable[Finding]:
        v = response.header("X-Content-Type-Options")
        if v is not None and v.lower() == "nosniff":
            return
        yield self.finding(
            probe_id=probe.probe_id,
            message=(
                "Response missing 'X-Content-Type-Options: nosniff' header."
            ),
            evidence={
                "url": response.url,
                "actual": v,
            },
            remediation=(
                "Provider should set X-Content-Type-Options: nosniff on "
                "every response to disable MIME-sniffing in browsers."
            ),
            threat_refs=("OWASP-API-7",),
        )


class MissingFrameOptions(Check):
    """Response missing ``X-Frame-Options`` AND no CSP ``frame-ancestors``."""

    code: ClassVar[str] = "security.headers.missing-frame-options"
    severity_default: ClassVar[Severity] = Severity.INFO
    root_cause_default: ClassVar[RootCause] = RootCause.PROVIDER_SECURITY

    def run(
        self,
        probe: Probe,
        response: Response,
        ctx: Context,
    ) -> Iterable[Finding]:
        if response.header("X-Frame-Options") is not None:
            return
        csp = response.header("Content-Security-Policy") or ""
        if "frame-ancestors" in csp.lower():
            return
        yield self.finding(
            probe_id=probe.probe_id,
            message=(
                "Response has neither X-Frame-Options nor "
                "Content-Security-Policy: frame-ancestors."
            ),
            evidence={"url": response.url, "csp": csp or None},
            remediation=(
                "Set Content-Security-Policy: frame-ancestors 'self' or "
                "X-Frame-Options: DENY (the former supersedes the latter "
                "in modern browsers but both are widely supported)."
            ),
            threat_refs=("OWASP-API-7",),
        )


class BodyEchoesSecret(Check):
    """Request Authorization header value appears verbatim in the response body.

    A common provider bug: error responses include the request that
    failed, leaking the bearer token / API key into logs and clients
    that print response bodies. This check is a safety net — its
    findings should be CRITICAL because they imply credentials may
    already be in shared infrastructure (request bins, log indexers).
    """

    code: ClassVar[str] = "security.body.echoes-secret"
    severity_default: ClassVar[Severity] = Severity.CRITICAL
    root_cause_default: ClassVar[RootCause] = RootCause.PROVIDER_SECURITY

    # Minimum length of an Authorization value before we look for it
    # in the body. Below this, false positives (e.g., the literal
    # string "Bearer" appearing in normal copy) drown the signal.
    _MIN_SECRET_LENGTH: ClassVar[int] = 8

    def run(
        self,
        probe: Probe,
        response: Response,
        ctx: Context,
    ) -> Iterable[Finding]:
        if not response.body:
            return
        # Find any Authorization-style header the probe sent.
        for name, value in probe.headers:
            if name.lower() != "authorization":
                continue
            # Strip the scheme prefix (Bearer / Basic / etc.) and use
            # the credential portion only — the scheme word IS expected
            # to appear in error messages.
            secret = value.split(" ", 1)[-1]
            if len(secret) < self._MIN_SECRET_LENGTH:
                continue
            if secret.encode("utf-8") in response.body:
                yield self.finding(
                    probe_id=probe.probe_id,
                    message=(
                        "Response body contains the verbatim Authorization "
                        "credential the probe sent. Treat the credential as "
                        "compromised."
                    ),
                    evidence={
                        "url": response.url,
                        "header_sent": name,
                        # Do NOT include the secret itself in evidence;
                        # the finding is about the LEAK and the evidence
                        # would compound it.
                        "secret_length": len(secret),
                    },
                    remediation=(
                        "Rotate the credential immediately. Investigate "
                        "the provider's error-response shape; common "
                        "culprit is dumping the original request payload "
                        "in 4xx errors."
                    ),
                    threat_refs=("CWE-200", "OWASP-API-2"),
                )


__all__ = [
    "BodyEchoesSecret",
    "MissingContentTypeOptions",
    "MissingFrameOptions",
    "MissingHsts",
]
