"""``mgf.apiprobe.checks`` — the default check catalogue.

See: ``DESIGN.md`` §7 (check catalogue). Currently ships 18 checks
across 5 categories. The full ~100-check catalogue lands
progressively in future versions.

Each check declares a stable ``code`` (public contract per SP-AP-03);
the codes shipped here CANNOT be renamed or removed in 0.x without a
breaking-change minor bump.

The :data:`DEFAULT_CHECKS` aggregate is the suite's "off-the-shelf"
list. Consumers can::

    suite = Suite(probes=[...], checks=DEFAULT_CHECKS)

or curate manually for tighter scope::

    from mgf.apiprobe.checks import StatusUnexpected, MissingRequestId
    suite = Suite(probes=[...], checks=[StatusUnexpected(), MissingRequestId()])
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from mgf.apiprobe.checks.contract import (
    ContentTypeJsonExpected,
    ContentTypeMissing,
    HeaderMissing,
    Server5xx,
    StatusUnexpected,
)
from mgf.apiprobe.checks.observability import (
    MissingRateLimitHeaders,
    MissingRequestId,
    MissingServerHeader,
)
from mgf.apiprobe.checks.quality import (
    BodySizeOverBudget,
    LatencyOverBudget,
    LatencySuspiciousZero,
)
from mgf.apiprobe.checks.schema import (
    BodyEmptyOnSuccess,
    BodyInvalidJson,
    SchemaShapeMismatch,
)
from mgf.apiprobe.checks.security import (
    BodyEchoesSecret,
    MissingContentTypeOptions,
    MissingFrameOptions,
    MissingHsts,
)

if TYPE_CHECKING:
    from mgf.apiprobe.core.check import Check

# The off-the-shelf catalogue. Order matters for report stability —
# group by category, then by severity within category. Consumers
# wanting deterministic ordering can rely on this tuple's contents.
DEFAULT_CHECKS: tuple[Check, ...] = (
    # Contract — most foundational; runs first so downstream checks
    # don't fire on responses that are wrong-shape at the top level.
    StatusUnexpected(),
    Server5xx(),
    HeaderMissing(),
    ContentTypeMissing(),
    ContentTypeJsonExpected(),
    # Schema — depends on body being parseable, runs after contract.
    SchemaShapeMismatch(),
    BodyInvalidJson(),
    BodyEmptyOnSuccess(),
    # Quality — non-functional.
    LatencyOverBudget(),
    LatencySuspiciousZero(),
    BodySizeOverBudget(),
    # Security — header hygiene + secret-echo.
    MissingHsts(),
    MissingContentTypeOptions(),
    MissingFrameOptions(),
    BodyEchoesSecret(),
    # Observability.
    MissingRequestId(),
    MissingRateLimitHeaders(),
    MissingServerHeader(),
)

__all__ = [
    "DEFAULT_CHECKS",
    "BodyEchoesSecret",
    "BodyEmptyOnSuccess",
    "BodyInvalidJson",
    "BodySizeOverBudget",
    "ContentTypeJsonExpected",
    "ContentTypeMissing",
    "HeaderMissing",
    "LatencyOverBudget",
    "LatencySuspiciousZero",
    "MissingContentTypeOptions",
    "MissingFrameOptions",
    "MissingHsts",
    "MissingRateLimitHeaders",
    "MissingRequestId",
    "MissingServerHeader",
    "SchemaShapeMismatch",
    "Server5xx",
    "StatusUnexpected",
]
