"""``Finding`` — the structured result of a check failure.

See: ``DESIGN.md`` §3.2 (the Finding shape table) and §3.2.1 (the
``RootCause`` taxonomy).

A check that detects an issue yields one or more ``Finding`` objects.
The shape is deliberately rigid: every public field is part of the
contract. ``code`` in particular is a public identifier — once a check
publishes its code, renaming or removing it is a breaking change
(rule SP-AP-03 in ``docs/standards/SCOPE.md``).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class Severity(StrEnum):
    """Finding severity. CI exit policy keys off the highest severity.

    Default policy: ``critical`` fails the suite (exit non-zero),
    ``warn`` is reported, ``info`` is reported quietly. Suites can
    promote / demote per-code via ``Suite.severity_overrides``
    (DESIGN.md §3.2.2). Promotion is logged at INFO with
    ``audit=true`` per the DESIGN — making a thing fail more often
    deserves a paper trail.

    String-valued so ``json.dumps`` produces stable values; sorting
    callers should rely on the explicit ordering helper, not enum
    member order.
    """

    INFO = "info"
    WARN = "warn"
    CRITICAL = "critical"


# Total ordering on Severity for "≥ X" comparisons (e.g., the suite's
# fail-on-severity threshold). Defined out-of-class to avoid mypy's
# warnings on str-Enum comparison overloads.
_SEVERITY_ORDER: dict[Severity, int] = {
    Severity.INFO: 0,
    Severity.WARN: 1,
    Severity.CRITICAL: 2,
}


def severity_at_least(actual: Severity, threshold: Severity) -> bool:
    """Return True if ``actual`` is at or above ``threshold``.

    Used by the suite-exit-code translator: if any finding has
    ``severity_at_least(f.severity, settings.fail_on_severity)``, the
    suite exits non-zero.
    """
    return _SEVERITY_ORDER[actual] >= _SEVERITY_ORDER[threshold]


class RootCause(StrEnum):
    """Failure attribution per DESIGN.md §3.2.1.

    Every Finding carries one. Dashboards aggregate by RootCause to
    answer questions like "where are our failures coming from this
    week" — provider quality, our suite's bugs, network flakes,
    drift, etc.

    A check declares a default RootCause; an individual finding can
    override (e.g. a generic latency check defaults to
    ``PROVIDER_QUALITY`` but escalates to ``NETWORK`` if latency was
    zero / negative — implying the response never arrived).
    """

    NETWORK = "network"
    """Connection refused, DNS, TLS handshake, timeout. The probe never got a real response."""

    AUTH = "auth"
    """401/403 in a flow that should be authenticated; token expiry, scope mismatch."""

    RATE_LIMIT = "rate_limit"
    """429 / Retry-After. Suite was throttled."""

    PROVIDER_5XX = "provider_5xx"
    """Provider returned 5xx. Their fault until proven otherwise."""

    PROVIDER_CONTRACT = "provider_contract"
    """4xx/2xx with shape violations — provider's schema lies or has drifted."""

    PROVIDER_QUALITY = "provider_quality"
    """Latency, headers-case, missing trace id — non-functional."""

    PROVIDER_SECURITY = "provider_security"
    """Secret echo, weak headers, error leaks."""

    PROVIDER_OBSERVABILITY = "provider_observability"
    """Missing request id, missing rate-limit headers."""

    CLIENT_REQUEST_SHAPE = "client_request_shape"
    """Our probe sent the wrong shape (mutation tests find these on purpose)."""

    CASSETTE_DRIFT = "cassette_drift"
    """Replay differs from cassette. (Surfaces in v0.3+ when replay lands.)"""

    SPEC_DRIFT = "spec_drift"
    """Spec disagrees with reality. (Surfaces in v0.4+ when drift detection lands.)"""

    SUITE_LOGIC = "suite_logic"
    """Suite itself has a bug — extraction failed, scenario state corrupt."""

    INFRASTRUCTURE = "infrastructure"
    """Harness/runtime issue (plugin load failure, transport error not attributable to provider)."""

    UNKNOWN = "unknown"
    """Use sparingly; the harness logs at WARN when this is emitted so the taxonomy can be refined."""


@dataclass(frozen=True, slots=True)
class Finding:
    """One structured finding. Frozen — checks emit; consumers read.

    All public fields are part of the v0.1 contract. ``since`` is set
    by the replay subsystem (v0.3+) when the finding is correlated to
    a cassette baseline; v0.1 always leaves it ``None``.

    Minimal example::

        Finding(
            code="contract.status.unexpected",
            severity=Severity.CRITICAL,
            root_cause=RootCause.PROVIDER_CONTRACT,
            message="Expected status 200, got 500.",
            evidence={"expected": 200, "actual": 500},
            remediation="Check provider service health; retry after 30s.",
        )
    """

    code: str
    """Stable dotted lowercase identifier. Public contract per SP-AP-03."""

    severity: Severity
    """info / warn / critical — see :class:`Severity`."""

    root_cause: RootCause
    """Failure attribution — see :class:`RootCause`."""

    message: str
    """Human-readable, one sentence, ends with a period (rule EH-09)."""

    evidence: dict[str, Any] = field(default_factory=dict)
    """Machine-readable JSON-able dict. Status, headers, body diff, expected/actual."""

    remediation: str = ""
    """Actionable next step. May be empty for findings that speak for themselves."""

    probe_id: str | None = None
    """Identifier of the producing probe. Set by the suite when it dispatches checks."""

    threat_refs: tuple[str, ...] = ()
    """Optional mappings to OWASP API Top 10, CWE IDs, etc."""

    tags: tuple[str, ...] = ()
    """Optional tags inherited from the probe + check (read/write, public/private, ...)."""

    since: str | None = None
    """First seen in cassette ID, when known. Set by the replay subsystem (v0.3+)."""


__all__ = [
    "Finding",
    "RootCause",
    "Severity",
    "severity_at_least",
]
