"""``Context`` — run-scoped variable + factory bag.

See: ``DESIGN.md`` §3.4 (Context). v0.1 is minimal — a frozen mapping
of variables. Scenarios (v0.2) extend with extracted-value mutation
(``ctx.set(name, value)`` from ``Probe.extract``); factories +
``{{factory:name}}`` template filter land alongside.

The frozen v0.1 shape suffices for single-probe runs where the user
seeds a few values up front.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Mapping


@dataclass(frozen=True, slots=True)
class Context:
    """Run-scoped variable bag.

    ``variables`` is wrapped in :class:`types.MappingProxyType` for
    immutability — checks reading the context can't accidentally
    mutate it. Construct fresh contexts per suite run::

        ctx = Context.with_variables({"user_id": "abc-123", "tenant": "acme"})
    """

    variables: Mapping[str, Any] = field(default_factory=lambda: MappingProxyType({}))

    @classmethod
    def empty(cls) -> Context:
        """Return an empty context. Convenience for v0.1 single-probe runs."""
        return cls()

    @classmethod
    def with_variables(cls, variables: Mapping[str, Any]) -> Context:
        """Return a context seeded with ``variables`` (copied + frozen)."""
        return cls(variables=MappingProxyType(dict(variables)))

    def get(self, name: str, default: Any = None) -> Any:
        """Look up a variable. Returns ``default`` if absent."""
        return self.variables.get(name, default)


__all__ = ["Context"]
