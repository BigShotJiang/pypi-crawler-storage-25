"""``Suite`` — the run orchestrator.

See: ``DESIGN.md`` §3.5 (Suite as primitive) + §6 (async layering).

A Suite holds a tuple of probes + a tuple of checks + a settings
object. Calling :meth:`run` executes every probe (concurrently up to
``settings.max_concurrency``), runs each probe's response through the
check chain, and aggregates the findings into a :class:`Report`.

The Suite consumes a :class:`Transport` via dependency injection —
defaults to the httpx-backed transport when not provided. Tests
inject stub transports; replay (v0.3) injects a cassette-backed
transport.

v0.1 surface (HANDOFF.md §6 cut):
  - sequential probe ordering preserved per-probe
  - concurrent probe execution capped by settings.max_concurrency
  - severity_overrides applied per-finding (DESIGN.md §3.2.2)
  - transport errors yield a synthetic Finding with RootCause.NETWORK
  - filter probes by tags (only_tags / exclude_tags)

Deferred:
  - Scenarios (multi-probe with shared Context mutation) — v0.2
  - Severity promotion audit logging — v0.4
  - Replay/cassette transport injection — v0.3
"""

from __future__ import annotations

import asyncio
import logging
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from mgf.apiprobe.core.context import Context
from mgf.apiprobe.core.finding import Finding, RootCause, Severity
from mgf.apiprobe.core.report import Report
from mgf.apiprobe.exceptions import TransportError

if TYPE_CHECKING:
    from collections.abc import Iterable, Sequence

    from mgf.apiprobe.config import ApiprobeSettings
    from mgf.apiprobe.core.check import Check
    from mgf.apiprobe.core.probe import Probe
    from mgf.apiprobe.core.transport import Transport


_LOGGER = logging.getLogger("mgf.apiprobe.suite")


class Suite:
    """A collection of probes + checks + an execution model.

    Construct with positional or keyword args::

        suite = Suite(
            probes=[probe1, probe2],
            checks=DEFAULT_CHECKS,
            settings=ApiprobeSettings(max_concurrency=4),
        )
        report = await suite.run(transport=my_transport)

    The Suite is itself stateless: ``run()`` may be called multiple
    times, each producing a fresh Report.
    """

    def __init__(
        self,
        *,
        probes: Sequence[Probe],
        checks: Sequence[Check],
        settings: ApiprobeSettings | None = None,
        severity_overrides: dict[str, Severity] | None = None,
    ) -> None:
        from mgf.apiprobe.config import ApiprobeSettings

        self.probes: tuple[Probe, ...] = tuple(probes)
        self.checks: tuple[Check, ...] = tuple(checks)
        self.settings: ApiprobeSettings = settings or ApiprobeSettings()
        self.severity_overrides: dict[str, Severity] = dict(severity_overrides or {})

    async def run(
        self,
        *,
        transport: Transport,
        context: Context | None = None,
        only_tags: Iterable[str] | None = None,
        exclude_tags: Iterable[str] | None = None,
    ) -> Report:
        """Execute every probe and return the :class:`Report`.

        ``transport`` is required — there's no implicit default in
        v0.1. Consumers building production suites pass an
        :class:`mgf.apiprobe.transport.HttpxTransport`; tests pass
        stubs that subclass :class:`Transport`.

        ``only_tags`` and ``exclude_tags`` filter the probe list
        before execution. Empty / ``None`` means "no filter on this
        side"; both filters can combine.
        """
        ctx = context or Context.empty()
        only = frozenset(only_tags) if only_tags else None
        exclude = frozenset(exclude_tags) if exclude_tags else None

        probes_to_run = [p for p in self.probes if _passes_tag_filter(p, only, exclude)]

        started_at = datetime.now(UTC)
        semaphore = asyncio.Semaphore(self.settings.max_concurrency)

        async def _execute(probe: Probe) -> tuple[list[Finding], bool]:
            async with semaphore:
                return await self._run_one_probe(probe, ctx, transport)

        results = await asyncio.gather(*(_execute(p) for p in probes_to_run))
        finished_at = datetime.now(UTC)

        all_findings: list[Finding] = []
        transport_errors = 0
        for findings, had_transport_error in results:
            all_findings.extend(findings)
            if had_transport_error:
                transport_errors += 1

        return Report(
            findings=tuple(all_findings),
            started_at=started_at,
            finished_at=finished_at,
            probe_count=len(probes_to_run),
            transport_errors=transport_errors,
        )

    async def _run_one_probe(
        self,
        probe: Probe,
        ctx: Context,
        transport: Transport,
    ) -> tuple[list[Finding], bool]:
        """Send one probe + run the checks; return (findings, had_transport_error).

        Transport-level failures yield a single synthetic Finding with
        ``RootCause.NETWORK`` and DO NOT run the check chain (a probe
        with no Response can't be checked).
        """
        try:
            response = await transport.send(probe, ctx)
        except TransportError as exc:
            _LOGGER.warning("probe %s transport error: %s", probe.probe_id, exc)
            return (
                [
                    Finding(
                        code="transport.network.failure",
                        severity=Severity.CRITICAL,
                        root_cause=RootCause.NETWORK,
                        message=f"Transport failed: {exc.cause}.",
                        evidence={"url": exc.url, "cause": exc.cause},
                        remediation=(
                            "Verify the URL resolves, the TLS chain is "
                            "valid, and the provider is reachable. "
                            "Check the harness's network egress rules."
                        ),
                        probe_id=probe.probe_id,
                    )
                ],
                True,
            )

        findings: list[Finding] = []
        for check in self.checks:
            for finding in check.run(probe, response, ctx):
                findings.append(self._apply_severity_override(finding))
        return findings, False

    def _apply_severity_override(self, finding: Finding) -> Finding:
        """Apply ``severity_overrides`` per-finding-code.

        DESIGN.md §3.2.2: suites can promote/demote any check's
        default severity. v0.1 applies the override blindly; the
        audit-trail logging on promotion is deferred.
        """
        override = self.severity_overrides.get(finding.code)
        if override is None or override is finding.severity:
            return finding
        # Frozen dataclass — return a new instance with severity replaced.
        from dataclasses import replace

        return replace(finding, severity=override)


def _passes_tag_filter(
    probe: Probe,
    only: frozenset[str] | None,
    exclude: frozenset[str] | None,
) -> bool:
    if exclude and any(t in exclude for t in probe.tags):
        return False
    if only is None:
        return True
    return any(t in only for t in probe.tags)


__all__ = ["Suite"]
