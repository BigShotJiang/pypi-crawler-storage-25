"""Tests for ``mgf.apiprobe.core.finding``."""

from __future__ import annotations

import dataclasses

import pytest

from mgf.apiprobe.core.finding import (
    Finding,
    RootCause,
    Severity,
    severity_at_least,
)


class TestSeverity:
    def test_string_values_are_stable(self) -> None:
        # These string values are public — JSON output relies on them.
        assert Severity.INFO.value == "info"
        assert Severity.WARN.value == "warn"
        assert Severity.CRITICAL.value == "critical"

    @pytest.mark.parametrize(
        ("actual", "threshold", "expected"),
        [
            (Severity.INFO, Severity.INFO, True),
            (Severity.WARN, Severity.INFO, True),
            (Severity.CRITICAL, Severity.INFO, True),
            (Severity.INFO, Severity.WARN, False),
            (Severity.WARN, Severity.WARN, True),
            (Severity.CRITICAL, Severity.WARN, True),
            (Severity.WARN, Severity.CRITICAL, False),
            (Severity.CRITICAL, Severity.CRITICAL, True),
        ],
    )
    def test_severity_at_least(
        self,
        actual: Severity,
        threshold: Severity,
        expected: bool,
    ) -> None:
        assert severity_at_least(actual, threshold) is expected


class TestRootCause:
    def test_all_design_taxonomy_present(self) -> None:
        # DESIGN.md §3.2.1 lists 14 categories; this test pins the
        # set so adding/removing one is a deliberate change.
        expected = {
            "network",
            "auth",
            "rate_limit",
            "provider_5xx",
            "provider_contract",
            "provider_quality",
            "provider_security",
            "provider_observability",
            "client_request_shape",
            "cassette_drift",
            "spec_drift",
            "suite_logic",
            "infrastructure",
            "unknown",
        }
        actual = {rc.value for rc in RootCause}
        assert actual == expected


class TestFinding:
    def test_minimal_construction(self) -> None:
        f = Finding(
            code="contract.status.unexpected",
            severity=Severity.CRITICAL,
            root_cause=RootCause.PROVIDER_CONTRACT,
            message="Expected status 200, got 500.",
        )
        assert f.code == "contract.status.unexpected"
        assert f.severity is Severity.CRITICAL
        assert f.root_cause is RootCause.PROVIDER_CONTRACT
        # Defaults
        assert f.evidence == {}
        assert f.remediation == ""
        assert f.probe_id is None
        assert f.threat_refs == ()
        assert f.tags == ()
        assert f.since is None

    def test_full_construction(self) -> None:
        f = Finding(
            code="header.request-id.missing",
            severity=Severity.WARN,
            root_cause=RootCause.PROVIDER_OBSERVABILITY,
            message="Response missing X-Request-Id header.",
            evidence={"headers": {"content-type": "application/json"}},
            remediation="Provider should add X-Request-Id to every response.",
            probe_id="list-users",
            threat_refs=("OWASP-API-9",),
            tags=("READ", "PUBLIC"),
        )
        assert f.evidence["headers"]["content-type"] == "application/json"
        assert f.threat_refs == ("OWASP-API-9",)

    def test_is_frozen(self) -> None:
        f = Finding(
            code="x",
            severity=Severity.INFO,
            root_cause=RootCause.UNKNOWN,
            message="x.",
        )
        with pytest.raises(dataclasses.FrozenInstanceError):
            f.code = "y"  # type: ignore[misc]
