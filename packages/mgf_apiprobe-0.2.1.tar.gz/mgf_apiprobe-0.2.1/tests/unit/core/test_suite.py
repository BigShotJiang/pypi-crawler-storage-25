"""Tests for ``mgf.apiprobe.core.suite``.

These tests use stub :class:`Transport` implementations defined inline
— no httpx, no respx. The httpx-backed transport gets its own tests
in Phase 1.6b.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, ClassVar

import pytest

from mgf.apiprobe.checks.contract import StatusUnexpected
from mgf.apiprobe.checks.observability import MissingRequestId
from mgf.apiprobe.config import ApiprobeSettings
from mgf.apiprobe.core.check import Check
from mgf.apiprobe.core.finding import RootCause, Severity
from mgf.apiprobe.core.probe import Probe
from mgf.apiprobe.core.response import Response
from mgf.apiprobe.core.suite import Suite
from mgf.apiprobe.core.tag import Tag
from mgf.apiprobe.core.transport import Transport
from mgf.apiprobe.exceptions import TransportError

if TYPE_CHECKING:
    from collections.abc import Iterable

    from mgf.apiprobe.core.context import Context
    from mgf.apiprobe.core.finding import Finding


# ---------------------------------------------------------------------------
# Stub transports.
# ---------------------------------------------------------------------------


class StubTransport(Transport):
    """Returns a pre-canned response for every probe."""

    def __init__(
        self,
        *,
        status: int = 200,
        body: bytes = b"",
        headers: dict[str, str] | None = None,
        elapsed_ms: float = 12.5,
    ) -> None:
        self.status = status
        self.body = body
        self.headers = headers or {}
        self.elapsed_ms = elapsed_ms
        self.calls: list[Probe] = []

    async def send(self, probe: Probe, ctx: Context) -> Response:
        self.calls.append(probe)
        return Response(
            url=probe.absolute_url(),
            status=self.status,
            headers=self.headers,
            body=self.body,
            elapsed_ms=self.elapsed_ms,
        )


class FailingTransport(Transport):
    """Raises TransportError for every probe."""

    async def send(self, probe: Probe, ctx: Context) -> Response:
        raise TransportError(url=probe.absolute_url(), cause="DNS NXDOMAIN")


class CountingCheck(Check):
    """Records every (probe, response) it sees and yields no finding."""

    code: ClassVar[str] = "test.counter"
    severity_default: ClassVar[Severity] = Severity.INFO
    root_cause_default: ClassVar[RootCause] = RootCause.UNKNOWN

    def __init__(self) -> None:
        self.calls: list[tuple[str | None, int]] = []

    def run(
        self,
        probe: Probe,
        response: Response,
        ctx: Context,
    ) -> Iterable[Finding]:
        self.calls.append((probe.probe_id, response.status))
        return ()


# ---------------------------------------------------------------------------
# Tests.
# ---------------------------------------------------------------------------


class TestSuiteConstruction:
    def test_defaults(self) -> None:
        suite = Suite(probes=[], checks=[])
        assert suite.probes == ()
        assert suite.checks == ()
        assert isinstance(suite.settings, ApiprobeSettings)
        assert suite.severity_overrides == {}

    def test_explicit_settings(self) -> None:
        s = ApiprobeSettings(max_concurrency=2)
        suite = Suite(probes=[], checks=[], settings=s)
        assert suite.settings is s


@pytest.mark.asyncio
class TestSuiteRun:
    async def test_empty_suite_produces_empty_report(self) -> None:
        suite = Suite(probes=[], checks=[])
        report = await suite.run(transport=StubTransport())
        assert report.findings == ()
        assert report.probe_count == 0
        assert report.transport_errors == 0

    async def test_single_probe_no_findings(self) -> None:
        probe = Probe.get("https://x/y").id("p1").expect_status(200)
        suite = Suite(probes=[probe], checks=[StatusUnexpected()])
        transport = StubTransport(status=200)
        report = await suite.run(transport=transport)
        assert report.findings == ()
        assert report.probe_count == 1
        assert len(transport.calls) == 1

    async def test_single_probe_with_finding(self) -> None:
        probe = Probe.get("https://x/y").id("p1").expect_status(200)
        suite = Suite(probes=[probe], checks=[StatusUnexpected()])
        report = await suite.run(transport=StubTransport(status=500))
        assert len(report.findings) == 1
        assert report.findings[0].code == "contract.status.unexpected"
        assert report.findings[0].probe_id == "p1"

    async def test_multiple_probes_run_concurrently(self) -> None:
        probes = [Probe.get(f"https://x/{i}").id(f"p{i}") for i in range(5)]
        check = CountingCheck()
        suite = Suite(probes=probes, checks=[check])
        report = await suite.run(transport=StubTransport())
        assert report.probe_count == 5
        assert len(check.calls) == 5
        assert {c[0] for c in check.calls} == {f"p{i}" for i in range(5)}

    async def test_concurrency_capped_by_settings(self) -> None:
        # Hard to assert concurrency directly without timing flakiness;
        # confirm at least that max_concurrency=1 still produces a
        # complete report (sequential execution).
        probes = [Probe.get(f"https://x/{i}").id(f"p{i}") for i in range(3)]
        suite = Suite(
            probes=probes,
            checks=[CountingCheck()],
            settings=ApiprobeSettings(max_concurrency=1),
        )
        report = await suite.run(transport=StubTransport())
        assert report.probe_count == 3


@pytest.mark.asyncio
class TestTransportErrorHandling:
    async def test_transport_error_yields_synthetic_finding(self) -> None:
        probe = Probe.get("https://x/y").id("p1")
        suite = Suite(probes=[probe], checks=[StatusUnexpected()])
        report = await suite.run(transport=FailingTransport())
        assert len(report.findings) == 1
        f = report.findings[0]
        assert f.code == "transport.network.failure"
        assert f.severity is Severity.CRITICAL
        assert f.root_cause is RootCause.NETWORK
        assert f.probe_id == "p1"
        assert "DNS NXDOMAIN" in f.evidence["cause"]

    async def test_transport_error_skips_check_chain(self) -> None:
        # Without a Response, checks can't run. The synthetic Finding
        # is the only output.
        probe = Probe.get("https://x/y").id("p1")
        check = CountingCheck()
        suite = Suite(probes=[probe], checks=[check])
        report = await suite.run(transport=FailingTransport())
        assert len(report.findings) == 1
        assert check.calls == []  # Check NOT called.

    async def test_transport_errors_counted(self) -> None:
        probes = [Probe.get(f"https://x/{i}").id(f"p{i}") for i in range(3)]
        suite = Suite(probes=probes, checks=[])
        report = await suite.run(transport=FailingTransport())
        assert report.transport_errors == 3


@pytest.mark.asyncio
class TestSeverityOverrides:
    async def test_demote_critical_to_warn(self) -> None:
        probe = Probe.get("https://x/y").id("p1").expect_status(200)
        suite = Suite(
            probes=[probe],
            checks=[StatusUnexpected()],
            severity_overrides={"contract.status.unexpected": Severity.WARN},
        )
        report = await suite.run(transport=StubTransport(status=500))
        assert len(report.findings) == 1
        assert report.findings[0].severity is Severity.WARN

    async def test_no_override_leaves_default(self) -> None:
        probe = Probe.get("https://x/y").id("p1").expect_status(200)
        suite = Suite(probes=[probe], checks=[StatusUnexpected()])
        report = await suite.run(transport=StubTransport(status=500))
        assert report.findings[0].severity is Severity.CRITICAL

    async def test_override_for_unrelated_code_no_effect(self) -> None:
        probe = Probe.get("https://x/y").id("p1").expect_status(200)
        suite = Suite(
            probes=[probe],
            checks=[StatusUnexpected()],
            severity_overrides={"some.other.code": Severity.WARN},
        )
        report = await suite.run(transport=StubTransport(status=500))
        assert report.findings[0].severity is Severity.CRITICAL


@pytest.mark.asyncio
class TestTagFiltering:
    async def test_only_tags(self) -> None:
        p_read = Probe.get("https://x/r").id("read").with_tags(Tag.READ)
        p_write = Probe.post("https://x/w").id("write").with_tags(Tag.WRITE)
        suite = Suite(probes=[p_read, p_write], checks=[CountingCheck()])
        report = await suite.run(transport=StubTransport(), only_tags={"read"})
        assert report.probe_count == 1

    async def test_exclude_tags(self) -> None:
        p_read = Probe.get("https://x/r").id("read").with_tags(Tag.READ)
        p_write = Probe.post("https://x/w").id("write").with_tags(Tag.WRITE, Tag.UNSAFE)
        suite = Suite(probes=[p_read, p_write], checks=[CountingCheck()])
        report = await suite.run(transport=StubTransport(), exclude_tags={"unsafe"})
        assert report.probe_count == 1

    async def test_exclude_overrides_only(self) -> None:
        # A probe matching only_tags can still be excluded.
        p = Probe.get("https://x/y").id("p1").with_tags(Tag.READ, Tag.UNSAFE)
        suite = Suite(probes=[p], checks=[CountingCheck()])
        report = await suite.run(
            transport=StubTransport(),
            only_tags={"read"},
            exclude_tags={"unsafe"},
        )
        assert report.probe_count == 0

    async def test_no_filter_runs_all(self) -> None:
        probes = [Probe.get(f"https://x/{i}").id(f"p{i}") for i in range(3)]
        suite = Suite(probes=probes, checks=[CountingCheck()])
        report = await suite.run(transport=StubTransport())
        assert report.probe_count == 3


@pytest.mark.asyncio
class TestCheckChain:
    async def test_multiple_checks_all_run(self) -> None:
        probe = (
            Probe.get("https://x/y")
            .id("p1")
            .expect_status(200)
            .expect_header("X-Request-Id")
        )
        # 500 response with no X-Request-Id → both checks fire.
        suite = Suite(
            probes=[probe],
            checks=[StatusUnexpected(), MissingRequestId()],
        )
        report = await suite.run(transport=StubTransport(status=500))
        codes = {f.code for f in report.findings}
        assert "contract.status.unexpected" in codes
        assert "observability.headers.missing-request-id" in codes
