"""Tests for CLI-daemon integration and graceful degradation.

Tasks 4.7 and 4.8 of the daemon sprint.  Tests DsmClient against a real
DsmDaemon, and verifies fallback behavior when the daemon is unavailable.
Uses tmp_path for socket and registry isolation; asyncio.run() wrappers
(no pytest-asyncio).
"""

from __future__ import annotations

import asyncio
import functools
import json
from pathlib import Path

import pytest

from dsm.cli import DsmClient, _registry_fallback
from dsm.daemon import DsmDaemon
from dsm.registry import ContainerRegistry


# ── Helpers ──────────────────────────────────────────────────────────────────


async def _run_in_thread(fn, *args, **kwargs):
    """Run a blocking function in a thread so the event loop stays free."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, functools.partial(fn, *args, **kwargs))


async def _start_daemon(tmp_path: Path) -> DsmDaemon:
    """Create, start, and return a daemon using tmp_path for isolation."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
    await daemon.start()
    return daemon


# ── Task 4.7: CLI with daemon running ────────────────────────────────────────


def test_client_status(tmp_path: Path):
    """DsmClient connects and sends status, gets a valid response."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    result = client.send("status")
                    assert "pid" in result
                    assert "uptime" in result
                    assert "containers" in result
                    assert "forwards" in result

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_client_register_then_list(tmp_path: Path):
    """Register a container via client, then list it back."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    # Register
                    reg_result = client.send(
                        "register_container",
                        container="webapp",
                        container_id="deadbeef",
                        ip="172.17.0.5",
                    )
                    assert reg_result["container_name"] == "webapp"
                    assert reg_result["container_id"] == "deadbeef"
                    assert reg_result["container_ip"] == "172.17.0.5"

                    # List
                    containers = client.send("list_containers")
                    assert len(containers) == 1
                    assert containers[0]["container_name"] == "webapp"

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_client_context_manager(tmp_path: Path):
    """DsmClient works as a context manager (connect/close)."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    result = client.send("status")
                    assert isinstance(result["containers"], int)

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_client_send_shutdown(tmp_path: Path):
    """Sending shutdown via client causes the daemon to stop."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        sock_path = daemon.socket_path

        def _do():
            client = DsmClient(sock_path)
            client.connect()
            try:
                client.send("shutdown")
            finally:
                client.close()

        await _run_in_thread(_do)

        # Give the daemon time to shut down
        await asyncio.sleep(0.3)
        assert not sock_path.exists()

    asyncio.run(_run())


def test_client_multiple_commands_same_connection(tmp_path: Path):
    """Client can send multiple commands on a single connection."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    # First command
                    status = client.send("status")
                    assert status["containers"] == 0

                    # Register
                    client.send(
                        "register_container",
                        container="svc1",
                        container_id="aaa",
                        ip="10.0.0.1",
                    )

                    # Second status — should now show 1 container
                    status2 = client.send("status")
                    assert status2["containers"] == 1

                    # List
                    containers = client.send("list_containers")
                    assert len(containers) == 1

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


def test_client_error_response(tmp_path: Path):
    """Client raises RuntimeError when daemon returns an error."""

    async def _run():
        daemon = await _start_daemon(tmp_path)
        try:
            def _do():
                with DsmClient(daemon.socket_path) as client:
                    try:
                        client.send("get_container")
                        raise AssertionError("Expected RuntimeError")
                    except RuntimeError as exc:
                        assert "Daemon error" in str(exc)

            await _run_in_thread(_do)
        finally:
            await daemon.stop()

    asyncio.run(_run())


# ── Task 4.8: Graceful degradation ──────────────────────────────────────────


def test_client_connect_nonexistent_socket(tmp_path: Path):
    """Connecting to a non-existent socket raises ConnectionError."""
    bad_sock = tmp_path / "nonexistent.sock"
    client = DsmClient(bad_sock)
    with pytest.raises(ConnectionError, match="Cannot connect"):
        client.connect()


def test_client_context_manager_nonexistent_socket(tmp_path: Path):
    """Context manager raises ConnectionError for non-existent socket."""
    bad_sock = tmp_path / "nonexistent.sock"
    with pytest.raises(ConnectionError, match="Cannot connect"):
        with DsmClient(bad_sock) as client:
            client.send("status")


def test_client_send_without_connect():
    """Calling send before connect raises ConnectionError."""
    client = DsmClient(Path("/tmp/no-such.sock"))
    with pytest.raises(ConnectionError, match="Not connected"):
        client.send("status")


def test_registry_fallback_reads_disk(tmp_path: Path, monkeypatch):
    """_registry_fallback loads persisted container data from disk."""
    reg_dir = tmp_path / "registry"
    monkeypatch.setattr("dsm.cli.REGISTRY_DIR", reg_dir)

    # Pre-populate registry on disk
    registry = ContainerRegistry(reg_dir)
    registry.load()
    registry.register("myapp", "abc123", "10.0.0.5")
    registry.persist("myapp")

    # Now use the fallback function
    fallback_reg = _registry_fallback()
    entries = fallback_reg.list()
    assert len(entries) == 1
    assert entries[0].container_name == "myapp"
    assert entries[0].container_id == "abc123"
    assert entries[0].container_ip == "10.0.0.5"


def test_registry_fallback_empty_dir(tmp_path: Path, monkeypatch):
    """_registry_fallback returns empty list when no containers on disk."""
    reg_dir = tmp_path / "registry"
    monkeypatch.setattr("dsm.cli.REGISTRY_DIR", reg_dir)

    fallback_reg = _registry_fallback()
    assert fallback_reg.list() == []


def test_registry_fallback_multiple_containers(tmp_path: Path, monkeypatch):
    """_registry_fallback loads multiple containers from disk."""
    reg_dir = tmp_path / "registry"
    monkeypatch.setattr("dsm.cli.REGISTRY_DIR", reg_dir)

    # Pre-populate
    registry = ContainerRegistry(reg_dir)
    registry.load()
    registry.register("web", "id1", "10.0.0.1")
    registry.register("api", "id2", "10.0.0.2")
    registry.register("db", "id3", "10.0.0.3")
    registry.persist_all()

    fallback_reg = _registry_fallback()
    entries = fallback_reg.list()
    assert len(entries) == 3
    names = {e.container_name for e in entries}
    assert names == {"web", "api", "db"}
