"""Tests for container registry CRUD and persistence (dsm.registry module)."""

import json
from pathlib import Path

import pytest

from dsm.registry import ContainerEntry, ContainerRegistry, ForwardInfo, PortInfo


# ── Helpers ──────────────────────────────────────────────────────────────────


def _make_registry(tmp_path: Path) -> ContainerRegistry:
    """Create a registry backed by a temp directory."""
    reg = ContainerRegistry(tmp_path / "registry")
    reg.load()
    return reg


def _register_sample(reg: ContainerRegistry, name: str = "web") -> ContainerEntry:
    """Register a sample container and return the entry."""
    return reg.register(name, f"sha256:{name}", f"172.17.0.{hash(name) % 250 + 2}")


# ── CRUD: register / get ─────────────────────────────────────────────────────


def test_register_and_get(tmp_path: Path):
    reg = _make_registry(tmp_path)
    entry = reg.register("web", "sha256:abc", "172.17.0.2")

    assert entry.container_name == "web"
    assert entry.container_id == "sha256:abc"
    assert entry.container_ip == "172.17.0.2"
    assert entry.status == "running"
    assert entry.created_at is not None
    assert entry.ports == []
    assert entry.forwards == []

    fetched = reg.get("web")
    assert fetched is entry


def test_get_missing_returns_none(tmp_path: Path):
    reg = _make_registry(tmp_path)
    assert reg.get("nonexistent") is None


# ── CRUD: list ───────────────────────────────────────────────────────────────


def test_list_returns_all(tmp_path: Path):
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:a", "172.17.0.2")
    reg.register("db", "sha256:b", "172.17.0.3")
    reg.register("cache", "sha256:c", "172.17.0.4")

    entries = reg.list()
    names = {e.container_name for e in entries}
    assert names == {"web", "db", "cache"}


def test_list_empty(tmp_path: Path):
    reg = _make_registry(tmp_path)
    assert reg.list() == []


# ── CRUD: update ─────────────────────────────────────────────────────────────


def test_update_fields(tmp_path: Path):
    reg = _make_registry(tmp_path)
    entry = reg.register("web", "sha256:abc", "172.17.0.2")
    old_updated_at = entry.updated_at

    updated = reg.update("web", status="stopped", container_ip="172.17.0.99")

    assert updated.status == "stopped"
    assert updated.container_ip == "172.17.0.99"
    assert updated.updated_at >= old_updated_at
    # Original object is mutated in place
    assert reg.get("web") is updated


def test_update_nonexistent_raises(tmp_path: Path):
    reg = _make_registry(tmp_path)
    with pytest.raises(KeyError):
        reg.update("ghost", status="stopped")


def test_update_invalid_field_raises(tmp_path: Path):
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:abc", "172.17.0.2")
    with pytest.raises(AttributeError, match="no field"):
        reg.update("web", bogus_field="nope")


# ── CRUD: remove ─────────────────────────────────────────────────────────────


def test_remove(tmp_path: Path):
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:abc", "172.17.0.2")
    reg.persist("web")

    reg.remove("web")

    assert reg.get("web") is None
    assert not (tmp_path / "registry" / "web.json").exists()


def test_remove_nonexistent_is_noop(tmp_path: Path):
    reg = _make_registry(tmp_path)
    # Should not raise
    reg.remove("ghost")


# ── Persistence round-trip ───────────────────────────────────────────────────


def test_persist_and_reload(tmp_path: Path):
    reg = _make_registry(tmp_path)
    entry = reg.register("web", "sha256:abc", "172.17.0.2")
    entry.ports = [PortInfo(port=8080, bind_address="0.0.0.0", protocol="tcp")]
    entry.forwards = [ForwardInfo(container_port=8080, host_port=8080, socat_pid=12345)]
    reg.persist("web")

    # Create a completely new registry on the same directory
    reg2 = ContainerRegistry(tmp_path / "registry")
    reg2.load()

    loaded = reg2.get("web")
    assert loaded is not None
    assert loaded.container_name == "web"
    assert loaded.container_id == "sha256:abc"
    assert loaded.container_ip == "172.17.0.2"
    assert loaded.status == "running"
    assert loaded.created_at == entry.created_at
    assert loaded.updated_at == entry.updated_at
    assert len(loaded.ports) == 1
    assert loaded.ports[0].port == 8080
    assert loaded.ports[0].bind_address == "0.0.0.0"
    assert loaded.ports[0].protocol == "tcp"
    assert len(loaded.forwards) == 1
    assert loaded.forwards[0].container_port == 8080
    assert loaded.forwards[0].host_port == 8080
    assert loaded.forwards[0].socat_pid == 12345
    assert loaded.forwards[0].alive is True


def test_persist_multiple_and_reload(tmp_path: Path):
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:a", "172.17.0.2")
    reg.register("db", "sha256:b", "172.17.0.3")
    reg.persist_all()

    reg2 = ContainerRegistry(tmp_path / "registry")
    reg2.load()

    names = {e.container_name for e in reg2.list()}
    assert names == {"web", "db"}


# ── from_dict: missing optional fields ───────────────────────────────────────


def test_container_entry_from_dict_missing_optional_fields():
    """ports and forwards are optional in persisted JSON."""
    data = {
        "container_name": "web",
        "container_id": "sha256:abc",
        "container_ip": "172.17.0.2",
        "status": "running",
        "created_at": "2026-01-01T00:00:00+00:00",
        "updated_at": "2026-01-01T00:00:00+00:00",
    }
    entry = ContainerEntry.from_dict(data)
    assert entry.ports == []
    assert entry.forwards == []


def test_forward_info_from_dict_missing_alive():
    """alive defaults to True when missing from dict."""
    data = {
        "container_port": 8080,
        "host_port": 8080,
        "socat_pid": 999,
    }
    info = ForwardInfo.from_dict(data)
    assert info.alive is True


# ── Atomic write behavior ────────────────────────────────────────────────────


def test_persist_no_tmp_files_remain(tmp_path: Path):
    """After persist, no .tmp files should remain in the registry directory."""
    reg = _make_registry(tmp_path)
    reg.register("web", "sha256:abc", "172.17.0.2")
    reg.register("db", "sha256:def", "172.17.0.3")
    reg.persist_all()

    registry_dir = tmp_path / "registry"
    tmp_files = list(registry_dir.glob("*.tmp"))
    assert tmp_files == [], f"Leftover .tmp files: {tmp_files}"


def test_persist_writes_valid_json(tmp_path: Path):
    """The JSON file on disk should be valid JSON after persist."""
    reg = _make_registry(tmp_path)
    entry = reg.register("web", "sha256:abc", "172.17.0.2")
    entry.ports = [PortInfo(port=3000, bind_address="0.0.0.0", protocol="tcp")]
    reg.persist("web")

    json_path = tmp_path / "registry" / "web.json"
    assert json_path.exists()

    with open(json_path) as fh:
        data = json.load(fh)

    assert data["container_name"] == "web"
    assert data["container_id"] == "sha256:abc"
    assert len(data["ports"]) == 1
    assert data["ports"][0]["port"] == 3000


def test_persist_all_writes_all_entries(tmp_path: Path):
    """persist_all should write one JSON file per registered container."""
    reg = _make_registry(tmp_path)
    names = ["alpha", "bravo", "charlie"]
    for i, name in enumerate(names):
        reg.register(name, f"sha256:{name}", f"172.17.0.{i + 2}")

    reg.persist_all()

    registry_dir = tmp_path / "registry"
    json_files = {p.stem for p in registry_dir.glob("*.json")}
    assert json_files == set(names)
