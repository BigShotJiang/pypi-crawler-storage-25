"""Integration tests for daemon lifecycle and lazy-start.

Tasks 5.1 and 5.2 of the daemon sprint.  End-to-end tests that exercise
the real DsmDaemon and DsmClient together — no mocks.  Uses tmp_path for
socket and registry isolation; asyncio.run() wrappers (no pytest-asyncio).
"""

from __future__ import annotations

import asyncio
import functools
import json
import os
import threading
from pathlib import Path

import pytest

from dsm.cli import DsmClient, ensure_daemon_running
from dsm.daemon import DsmDaemon
from dsm.registry import ContainerRegistry


# ── Helpers ──────────────────────────────────────────────────────────────────


async def _send_recv(socket_path: Path, request: dict) -> dict:
    """Connect, send a single NDJSON request, read one response, close."""
    reader, writer = await asyncio.open_unix_connection(str(socket_path))
    payload = json.dumps(request).encode() + b"\n"
    writer.write(payload)
    await writer.drain()
    line = await asyncio.wait_for(reader.readline(), timeout=5)
    writer.close()
    await writer.wait_closed()
    return json.loads(line)


async def _start_daemon(tmp_path: Path) -> DsmDaemon:
    """Create, start, and return a daemon using tmp_path for isolation."""
    sock = tmp_path / "dsm.sock"
    reg_dir = tmp_path / "registry"
    daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
    await daemon.start()
    return daemon


async def _run_in_thread(fn, *args, **kwargs):
    """Run a blocking function in a thread so the event loop stays free."""
    loop = asyncio.get_running_loop()
    return await loop.run_in_executor(None, functools.partial(fn, *args, **kwargs))


# ── Task 5.1: Full daemon lifecycle ─────────────────────────────────────────


def test_full_daemon_lifecycle(tmp_path: Path):
    """End-to-end: start, register, verify, list, status, shutdown, persist, reload."""

    async def _run():
        sock = tmp_path / "dsm.sock"
        reg_dir = tmp_path / "registry"

        # 1. Start DsmDaemon
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        await daemon.start()

        try:
            # 2. Register a container via DsmClient (in thread — it's synchronous)
            def _register():
                with DsmClient(sock) as client:
                    return client.send(
                        "register_container",
                        container="integration-web",
                        container_id="int-abc123",
                        ip="10.0.0.42",
                    )

            reg_result = await _run_in_thread(_register)
            assert reg_result["container_name"] == "integration-web"
            assert reg_result["container_id"] == "int-abc123"

            # 3. Verify registry JSON file exists on disk
            reg_file = reg_dir / "integration-web.json"
            assert reg_file.exists(), "Registry file should exist after register"

            # 4. Send list_containers, verify the container appears
            def _list():
                with DsmClient(sock) as client:
                    return client.send("list_containers")

            containers = await _run_in_thread(_list)
            assert len(containers) == 1
            assert containers[0]["container_name"] == "integration-web"

            # 5. Send status, verify container count
            def _status():
                with DsmClient(sock) as client:
                    return client.send("status")

            status = await _run_in_thread(_status)
            assert status["containers"] == 1

        finally:
            # 6. Send shutdown
            def _shutdown():
                client = DsmClient(sock)
                client.connect()
                try:
                    client.send("shutdown")
                finally:
                    client.close()

            await _run_in_thread(_shutdown)

        # Give daemon time to complete shutdown
        await asyncio.sleep(0.5)

        # 7. Verify socket removed
        assert not sock.exists(), "Socket should be removed after shutdown"

        # 8. Verify registry file persisted on disk (survives daemon stop)
        reg_file = reg_dir / "integration-web.json"
        assert reg_file.exists(), "Registry file should survive daemon shutdown"
        data = json.loads(reg_file.read_text())
        assert data["container_name"] == "integration-web"
        assert data["container_id"] == "int-abc123"
        assert data["container_ip"] == "10.0.0.42"

        # 9. Start a NEW daemon on same paths, verify it loads the persisted registry
        daemon2 = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        await daemon2.start()

        try:
            def _list_after_reload():
                with DsmClient(sock) as client:
                    return client.send("list_containers")

            containers2 = await _run_in_thread(_list_after_reload)
            assert len(containers2) == 1
            assert containers2[0]["container_name"] == "integration-web"
            assert containers2[0]["container_id"] == "int-abc123"
        finally:
            await daemon2.stop()

    asyncio.run(_run())


# ── Task 5.2: Lazy start via ensure_daemon_running ──────────────────────────


def test_ensure_daemon_running_spawns_in_thread(tmp_path: Path):
    """ensure_daemon_running starts a daemon when no socket exists.

    Instead of spawning a real subprocess (fragile in CI), we start the
    daemon in-process on a background thread and verify that
    ensure_daemon_running succeeds once the socket appears.
    """

    async def _run():
        sock = tmp_path / "dsm.sock"
        reg_dir = tmp_path / "registry"

        # Confirm no socket exists yet
        assert not sock.exists()

        # Start daemon in a background thread (simulates the subprocess)
        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)
        daemon_started = asyncio.Event()

        async def _run_daemon():
            await daemon.start()
            daemon_started.set()
            assert daemon._stop_event is not None
            await daemon._stop_event.wait()

        daemon_task = asyncio.create_task(_run_daemon())
        await daemon_started.wait()

        try:
            # Now ensure_daemon_running should succeed (socket exists)
            def _ensure():
                ensure_daemon_running(socket_path=sock)

            await _run_in_thread(_ensure)

            # Verify we can actually communicate
            def _status():
                with DsmClient(sock) as client:
                    return client.send("status")

            status = await _run_in_thread(_status)
            assert "pid" in status
            assert "containers" in status
        finally:
            await daemon.stop()
            daemon_task.cancel()
            try:
                await daemon_task
            except asyncio.CancelledError:
                pass

    asyncio.run(_run())


def test_ensure_daemon_running_connect_retry(tmp_path: Path):
    """ensure_daemon_running retries until the socket appears.

    Starts a daemon with a small delay to exercise the retry logic.
    """

    async def _run():
        sock = tmp_path / "dsm.sock"
        reg_dir = tmp_path / "registry"

        daemon = DsmDaemon(socket_path=sock, registry_dir=reg_dir)

        async def _delayed_start():
            """Start the daemon after a short delay to exercise retry."""
            await asyncio.sleep(0.3)
            await daemon.start()
            assert daemon._stop_event is not None
            await daemon._stop_event.wait()

        daemon_task = asyncio.create_task(_delayed_start())

        try:
            # ensure_daemon_running will fail the first _try_daemon_connect
            # but succeed after retries once the daemon starts
            def _ensure():
                ensure_daemon_running(socket_path=sock)

            await _run_in_thread(_ensure)

            # Verify communication works
            def _status():
                with DsmClient(sock) as client:
                    return client.send("status")

            status = await _run_in_thread(_status)
            assert status["containers"] == 0
        finally:
            await daemon.stop()
            daemon_task.cancel()
            try:
                await daemon_task
            except asyncio.CancelledError:
                pass

    asyncio.run(_run())
