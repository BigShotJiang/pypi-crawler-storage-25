"""Port detection and forwarding for dsm containers.

Detects listening ports inside Docker containers and forwards them to the host
using socat. This enables access to services running inside containers that were
created without port mappings (i.e., containers using `docker exec` transport).

## Platform Support

This module implements a Linux-native backend:

- **Detection**: Reads /proc/$PID/net/tcp directly from the host filesystem.
  The container's init PID exposes its network namespace under /proc/$PID/net/.
  This is a zero-overhead file read (~0.1ms).

- **Forwarding**: Runs `socat` on the host, forwarding from a host port to the
  container's bridge IP. Container IPs are directly routable on Linux.

## macOS / Windows (Docker Desktop) — Not Yet Implemented

Both detection and forwarding differ on Docker Desktop because containers run
inside a LinuxKit (macOS) or WSL2 (Windows) VM:

### Detection changes required:
- /proc/$PID/net/tcp is NOT accessible from the host (PID lives in the VM).
- Must use `docker exec <container> cat /proc/net/tcp` instead.
- Alternative: `docker exec ss -tlnp` if ss is available in the image.
- Performance impact: ~50-100ms per exec vs ~0.1ms for direct /proc read.

### Forwarding changes required:
- Container IPs (172.x.x.x) are NOT routable from the macOS/Windows host.
- Options:
  A. `docker exec socat` inside the container (most portable, requires socat
     in the container image).
  B. Sidecar container: `docker run --network container:<name> -p host:port`
     (no image changes, but heavier).
  C. Docker Desktop's built-in port forwarding API (undocumented, version-
     dependent — not recommended).
- Recommended: Option A for portability.

### Abstraction seam:
To add macOS/Windows support, implement a new backend class conforming to the
same interface as the functions below. The CLI layer (cli.py) calls only the
public API functions and does not depend on Linux-specific internals:
  - scan_container_ports(container_name) -> list[ListeningPort]
  - start_forward(container_name, container_port, host_port) -> ForwardHandle
  - stop_forward(handle) -> None
  - list_forwards(container_name) -> list[ForwardHandle]
"""

from __future__ import annotations

import asyncio
import logging
import socket
import subprocess
import struct
from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Awaitable, Union

logger = logging.getLogger(__name__)


# ── Data types ────────────────────────────────────────────────────────────────


@dataclass
class ListeningPort:
    """A port in LISTEN state detected inside a container."""
    port: int
    bind_address: str  # "0.0.0.0" or "127.0.0.1" or ipv6 equivalent
    protocol: str = "tcp"  # "tcp" or "tcp6"


@dataclass
class ForwardHandle:
    """Tracks a live socat forwarding process."""
    container_name: str
    container_port: int
    host_port: int
    process: subprocess.Popen | None = field(default=None, repr=False)

    @property
    def alive(self) -> bool:
        return self.process is not None and self.process.poll() is None


@dataclass
class PortChange:
    """A detected change in a container's listening ports."""
    container_name: str
    port: ListeningPort
    action: str  # "added" or "removed"
    forward: ForwardHandle | None = None  # the auto-created or stopped forward


# Callback can be sync or async
PortChangeCallback = Callable[[list[PortChange]], Union[None, Awaitable[None]]]

# Bind addresses considered loopback (not forwardable from host)
_LOOPBACK_ADDRESSES = {"127.0.0.1", "::1"}


# ── Port scanning ─────────────────────────────────────────────────────────────
#
# Linux-only: reads /proc/$PID/net/tcp from the host.
# macOS/Windows: replace with `docker exec <container> cat /proc/net/tcp`.


# Ephemeral port range — filter these out to avoid false positives from client
# connections. Default Linux range; could read /proc/sys/net/ipv4/ip_local_port_range.
EPHEMERAL_PORT_MIN = 32768
EPHEMERAL_PORT_MAX = 60999

# /proc/net/tcp state codes
TCP_LISTEN = "0A"


def get_container_pid(container_name: str) -> int:
    """Get the init PID of a running container via docker inspect.

    Linux-only: this PID is used to access /proc/$PID/net/tcp on the host.
    macOS/Windows: PID lives inside VM, not useful for host /proc access.
    """
    result = subprocess.run(
        ["docker", "inspect", "--format", "{{.State.Pid}}", container_name],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"Container '{container_name}' not found or not running")
    pid = int(result.stdout.strip())
    if pid == 0:
        raise RuntimeError(f"Container '{container_name}' is not running (pid=0)")
    return pid


def parse_proc_net_tcp(content: str) -> list[ListeningPort]:
    """Parse /proc/net/tcp or /proc/net/tcp6 content into ListeningPort entries.

    Pure function — no I/O, fully testable.

    Format per line (after header):
      sl  local_address:port  rem_address:port  st  ...
    Where local_address is hex-encoded (little-endian for IPv4), port is hex,
    and st is the TCP state (0A = LISTEN).
    """
    ports = []
    lines = content.strip().splitlines()
    if not lines:
        return ports

    for line in lines[1:]:  # skip header
        parts = line.strip().split()
        if len(parts) < 4:
            continue

        local_addr_hex, port_hex = parts[1].split(":")
        state = parts[3]

        if state != TCP_LISTEN:
            continue

        port = int(port_hex, 16)

        # Skip ephemeral ports (client connections that happen to be in LISTEN
        # briefly, or SO_REUSEADDR artifacts)
        if EPHEMERAL_PORT_MIN <= port <= EPHEMERAL_PORT_MAX:
            continue

        bind_address = _decode_address(local_addr_hex)
        protocol = "tcp6" if len(local_addr_hex) > 8 else "tcp"

        ports.append(ListeningPort(port=port, bind_address=bind_address, protocol=protocol))

    return ports


def _decode_address(hex_addr: str) -> str:
    """Decode hex address from /proc/net/tcp format.

    IPv4: 8 hex chars, little-endian 32-bit integer.
      "0100007F" -> 127.0.0.1
      "00000000" -> 0.0.0.0

    IPv6: 32 hex chars, four little-endian 32-bit words.
      "00000000000000000000000000000000" -> ::
      "00000000000000000000FFFF0100007F" -> ::ffff:127.0.0.1
    """
    if len(hex_addr) == 8:
        # IPv4: little-endian 32-bit
        addr_int = struct.unpack("=I", bytes.fromhex(hex_addr))[0]
        return socket.inet_ntoa(struct.pack("!I", addr_int))
    elif len(hex_addr) == 32:
        # IPv6: four little-endian 32-bit words
        words = [
            struct.unpack("=I", bytes.fromhex(hex_addr[i:i+8]))[0]
            for i in range(0, 32, 8)
        ]
        addr_bytes = b"".join(struct.pack("!I", w) for w in words)
        return socket.inet_ntop(socket.AF_INET6, addr_bytes)
    else:
        return hex_addr  # unexpected format, return raw


def scan_container_ports(container_name: str) -> list[ListeningPort]:
    """Detect all listening TCP ports inside a container.

    Linux-only: reads /proc/$PID/net/tcp and /proc/$PID/net/tcp6 from the host.
    macOS/Windows: replace body with `docker exec <container> cat /proc/net/tcp`.
    """
    pid = get_container_pid(container_name)

    ports: list[ListeningPort] = []
    for filename in ("tcp", "tcp6"):
        proc_path = Path(f"/proc/{pid}/net/{filename}")
        if proc_path.exists():
            content = proc_path.read_text()
            ports.extend(parse_proc_net_tcp(content))

    # Deduplicate: tcp6 with IPv4-mapped addresses may duplicate tcp entries
    seen: set[tuple[int, str]] = set()
    unique: list[ListeningPort] = []
    for p in ports:
        key = (p.port, _normalize_bind(p.bind_address))
        if key not in seen:
            seen.add(key)
            unique.append(p)

    return unique


def _normalize_bind(addr: str) -> str:
    """Normalize bind addresses for dedup. Maps IPv4-mapped IPv6 to IPv4."""
    if addr.startswith("::ffff:"):
        return addr[7:]  # "::ffff:0.0.0.0" -> "0.0.0.0"
    if addr == "::":
        return "0.0.0.0"
    return addr


# ── Port forwarding ───────────────────────────────────────────────────────────
#
# Linux-only: runs socat on the host, forwarding to container's bridge IP.
# macOS/Windows: container IPs not routable — use docker exec socat in container,
# or a sidecar container approach. See module docstring for details.


def get_container_ip(container_name: str) -> str:
    """Get the bridge network IP of a running container.

    Linux-only: this IP is directly routable from the host.
    macOS/Windows: returns an IP inside the VM, not routable from the host.
    """
    result = subprocess.run(
        ["docker", "inspect", "--format",
         "{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}",
         container_name],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"Container '{container_name}' not found")
    ip = result.stdout.strip()
    if not ip:
        raise RuntimeError(f"Container '{container_name}' has no IP address")
    return ip


def find_available_host_port(preferred: int, max_attempts: int = 100) -> int:
    """Find an available host port, starting from preferred and incrementing.

    Follows the VS Code pattern: try the same port number first, then increment.
    """
    for offset in range(max_attempts):
        port = preferred + offset
        if port > 65535:
            break
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("", port))
                return port
        except OSError:
            continue
    raise RuntimeError(f"No available port found starting from {preferred}")


def start_forward(
    container_name: str,
    container_port: int,
    host_port: int | None = None,
    registry: Any = None,
) -> ForwardHandle:
    """Start forwarding a container port to the host via socat.

    Linux-only: spawns `socat TCP-LISTEN:$host,fork,reuseaddr TCP:$ip:$port`.
    macOS/Windows: would need `docker exec socat` inside the container instead.

    If an alive forward already exists for the same container:port, returns it
    without spawning a new socat process (dedup guard).

    Args:
        container_name: Docker container name.
        container_port: Port listening inside the container.
        host_port: Desired host port. If None or unavailable, auto-selects.
        registry: Optional ContainerRegistry. If provided, persists ForwardInfo.

    Returns:
        ForwardHandle tracking the socat process.
    """
    # Dedup guard: return existing alive forward for this container:port
    existing = _active_forwards.get(container_name, [])
    for handle in existing:
        if handle.container_port == container_port and handle.alive:
            logger.debug(
                "Forward already active for %s:%d -> host:%d, skipping",
                container_name, container_port, handle.host_port,
            )
            return handle

    # Clean up dead forwards for this container:port before creating a new one
    dead = [h for h in existing if h.container_port == container_port and not h.alive]
    for h in dead:
        existing.remove(h)

    container_ip = get_container_ip(container_name)

    # Find available host port
    preferred = host_port if host_port is not None else container_port
    actual_host_port = find_available_host_port(preferred)

    proc = subprocess.Popen(
        [
            "socat",
            f"TCP-LISTEN:{actual_host_port},fork,reuseaddr",
            f"TCP:{container_ip}:{container_port}",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )

    handle = ForwardHandle(
        container_name=container_name,
        container_port=container_port,
        host_port=actual_host_port,
        process=proc,
    )

    # Register in module-level dict (backward compat for standalone use)
    _active_forwards.setdefault(container_name, []).append(handle)

    # Persist to registry if provided
    if registry is not None:
        _update_registry_forward(registry, handle, add=True)

    return handle


def stop_forward(
    handle: ForwardHandle,
    registry: Any = None,
) -> None:
    """Stop a socat forwarding process and remove from registry."""
    if handle.process is not None:
        handle.process.terminate()
        try:
            handle.process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            handle.process.kill()
            handle.process.wait()

    # Remove from module-level registry
    container_forwards = _active_forwards.get(handle.container_name, [])
    _active_forwards[handle.container_name] = [
        h for h in container_forwards if h is not handle
    ]

    # Update persistent registry if provided
    if registry is not None:
        _update_registry_forward(registry, handle, add=False)


def _update_registry_forward(
    registry: Any,
    handle: ForwardHandle,
    add: bool,
) -> None:
    """Add or remove a ForwardInfo in the persistent registry entry."""
    from dsm.registry import ForwardInfo

    entry = registry.get(handle.container_name)
    if entry is None:
        return

    if add:
        socat_pid = handle.process.pid if handle.process else 0
        info = ForwardInfo(
            container_port=handle.container_port,
            host_port=handle.host_port,
            socat_pid=socat_pid,
            alive=True,
        )
        entry.forwards.append(info)
    else:
        entry.forwards = [
            f for f in entry.forwards
            if f.container_port != handle.container_port
        ]

    try:
        registry.persist(handle.container_name)
    except (KeyError, OSError):
        pass


# ── Forward registry ──────────────────────────────────────────────────────────

_active_forwards: dict[str, list[ForwardHandle]] = {}


def list_forwards(container_name: str | None = None) -> list[ForwardHandle]:
    """List active forwards, optionally filtered by container.

    Prunes dead socat processes before returning.
    """
    if container_name is not None:
        forwards = _active_forwards.get(container_name, [])
    else:
        forwards = [h for hs in _active_forwards.values() for h in hs]

    # Prune dead processes
    alive = [h for h in forwards if h.alive]
    dead = [h for h in forwards if not h.alive]
    for h in dead:
        container_forwards = _active_forwards.get(h.container_name, [])
        _active_forwards[h.container_name] = [f for f in container_forwards if f is not h]

    return alive


def clear_forwards() -> None:
    """Stop all active forwards. Used for cleanup."""
    for container_forwards in list(_active_forwards.values()):
        for handle in list(container_forwards):
            stop_forward(handle)
    _active_forwards.clear()


# ── Port watcher ──────────────────────────────────────────────────────────────


class PortWatcher:
    """Background watcher that polls containers for port changes and auto-forwards.

    Uses asyncio tasks to poll /proc/$PID/net/tcp every `interval` seconds,
    diffs against previous state, and automatically starts/stops socat forwards.

    Usage:
        watcher = PortWatcher(["dsm_myproject"], on_change=my_callback)
        await watcher.start()
        # ... watcher runs as asyncio task ...
        await watcher.stop()

    For daemon integration, pass an on_change callback to receive PortChange
    events when ports are added or removed. The callback can be sync or async.
    """

    def __init__(
        self,
        containers: list[str] | None = None,
        interval: float = 2.0,
        on_change: PortChangeCallback | None = None,
        exclude_ports: set[int] | None = None,
        registry: Any = None,
    ):
        self._containers: list[str] = list(containers) if containers else []
        self._interval = interval
        self._on_change = on_change
        self._exclude_ports = exclude_ports or set()
        self._previous: dict[str, set[tuple[int, str]]] = {}
        self._container_ips: dict[str, str] = {}
        self._task: asyncio.Task | None = None
        self._stop_event: asyncio.Event | None = None
        self._registry = registry

    @property
    def running(self) -> bool:
        return self._task is not None and not self._task.done()

    async def start(self) -> None:
        """Start the background polling task."""
        if self.running:
            return
        self._stop_event = asyncio.Event()
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        """Stop the polling task and clean up all forwards."""
        if self._stop_event is not None:
            self._stop_event.set()
        if self._task is not None:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None
        clear_forwards()
        self._previous.clear()
        self._container_ips.clear()

    def add_container(self, name: str) -> None:
        """Add a container to the watch list."""
        if name not in self._containers:
            self._containers.append(name)

    def remove_container(self, name: str) -> None:
        """Remove a container from the watch list and clean up its forwards."""
        if name in self._containers:
            self._containers.remove(name)
        # Clean up state
        self._cleanup_container(name)

    def _cleanup_container(self, name: str) -> None:
        """Remove all state and forwards for a container."""
        for handle in list(list_forwards(name)):
            stop_forward(handle, registry=self._registry)
        self._previous.pop(name, None)
        self._container_ips.pop(name, None)

    async def _run(self) -> None:
        """Main polling loop — runs as an asyncio task."""
        assert self._stop_event is not None
        loop = asyncio.get_running_loop()
        logger.info("PortWatcher started, watching %d containers: %s",
                     len(self._containers), self._containers)
        while not self._stop_event.is_set():
            containers = list(self._containers)
            for name in containers:
                if self._stop_event.is_set():
                    return
                try:
                    # Run blocking _poll_container in executor to avoid blocking event loop
                    await loop.run_in_executor(None, self._poll_container, name)
                except Exception:
                    logger.exception("poll failed for container %s", name)
            # Wait for interval or stop
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=self._interval)
                return  # stop_event was set
            except asyncio.TimeoutError:
                pass  # interval elapsed, poll again

    def _poll_container(self, name: str) -> None:
        """Single poll cycle for one container: scan, diff, forward/unforward.

        This runs in a thread executor since it does blocking I/O (subprocess,
        /proc reads). The on_change callback is fired here; if it's async, we
        schedule it on the event loop.
        """
        changes: list[PortChange] = []

        # Scan current ports
        try:
            current_ports = scan_container_ports(name)
            logger.debug("scanned %s: %d ports", name, len(current_ports))
        except RuntimeError as exc:
            logger.debug("scan failed for %s: %s", name, exc)
            # Container gone — build removal changes before cleanup
            if name in self._previous:
                removed = self._previous[name]
                changes.extend(self._make_removed_changes(name, removed))
                # Now clean up (stops forwards, clears state)
                self._cleanup_container(name)
                if changes and self._on_change is not None:
                    self._fire_callback(changes)
            return

        # Check for container restart (IP change)
        try:
            current_ip = get_container_ip(name)
        except RuntimeError:
            return

        if name in self._container_ips and self._container_ips[name] != current_ip:
            logger.info(
                "Container %s restarted (%s -> %s), re-establishing forwards",
                name, self._container_ips[name], current_ip,
            )
            # Stop all existing forwards — IPs are stale
            for handle in list(list_forwards(name)):
                stop_forward(handle, registry=self._registry)
            # Clear previous state so all current ports are treated as new
            self._previous.pop(name, None)

        self._container_ips[name] = current_ip

        # Build current state as set of (port, normalized_bind)
        current_set: set[tuple[int, str]] = set()
        current_by_key: dict[tuple[int, str], ListeningPort] = {}
        for lp in current_ports:
            key = (lp.port, _normalize_bind(lp.bind_address))
            current_set.add(key)
            current_by_key[key] = lp

        previous_set = self._previous.get(name, set())

        # Diff
        added = current_set - previous_set
        removed = previous_set - current_set

        # Auto-forward new ports
        for key in added:
            lp = current_by_key[key]
            normalized = _normalize_bind(lp.bind_address)

            if normalized in _LOOPBACK_ADDRESSES:
                logger.debug("Skipping loopback port %d on %s", lp.port, name)
                changes.append(PortChange(name, lp, "added", forward=None))
                continue

            if lp.port in self._exclude_ports:
                logger.debug("Skipping excluded port %d on %s", lp.port, name)
                continue

            try:
                handle = start_forward(name, lp.port, registry=self._registry)
                changes.append(PortChange(name, lp, "added", forward=handle))
            except Exception as e:
                logger.warning("Failed to forward port %d on %s: %s", lp.port, name, e)
                changes.append(PortChange(name, lp, "added", forward=None))

        # Auto-unforward removed ports
        changes.extend(self._make_removed_changes(name, removed))

        # Update state
        self._previous[name] = current_set

        # Fire callback
        if changes and self._on_change is not None:
            self._fire_callback(changes)

    def _fire_callback(self, changes: list[PortChange]) -> None:
        """Fire the on_change callback, handling both sync and async callbacks."""
        try:
            result = self._on_change(changes)  # type: ignore[misc]
            # If the callback is async, schedule it on the event loop
            if asyncio.iscoroutine(result):
                loop = asyncio.get_event_loop()
                asyncio.run_coroutine_threadsafe(result, loop)
        except Exception:
            logger.exception("on_change callback failed")

    def _make_removed_changes(
        self, name: str, removed: set[tuple[int, str]]
    ) -> list[PortChange]:
        """Stop forwards for removed ports and build PortChange list."""
        changes: list[PortChange] = []
        forwards = list_forwards(name)
        forward_by_port = {h.container_port: h for h in forwards}

        for port_num, bind_addr in removed:
            lp = ListeningPort(port=port_num, bind_address=bind_addr)
            handle = forward_by_port.get(port_num)
            if handle is not None:
                stop_forward(handle, registry=self._registry)
            changes.append(PortChange(name, lp, "removed", forward=handle))

        return changes
