---
name: sync-specs-with-code
description: "Synchronize specs with code — generate if missing, detect drift and update if existing"
---

# Sync Specs with Code

Ensure specs reflect the current codebase. If no specs exist, generate all 7 primary document types. If specs exist, detect drift and regenerate only what changed.

## Decision Logic

1. Check `.organon/specs/` for existing spec files.
2. **No specs exist** → run full generation (see Workflow below).
3. **Specs exist** → run incremental sync:
   - Read the alignment manifest's `surfaces.specs.git_head`
   - Compare to current `git rev-parse HEAD`
   - If same → specs are fresh, report "Specs in sync" and exit
   - If different → identify changed source files, match to specs, regenerate stale ones

## Constraints

- **Never hand-write a contract the framework auto-generates.** The framework knows things the agent cannot reliably reconstruct: middleware order, response serialization, implicit routes. Errors here propagate to tests and waste debugging cycles. Use the extraction script.
- **Generated specs are drafts.** Always flag uncertain mappings with `# TODO: verify` and tell the user what needs review.
- **Capture what IS, not what SHOULD BE.** Specs describe the current codebase. Do not invent requirements.
- **Every contract endpoint must appear in a workflow.** After generating all workflows, cross-check against the contract. Uncovered endpoints are gaps that must be resolved before delivery.

## Incremental Sync

The default mode when specs already exist. Skips unchanged specs and only regenerates what drifted.

### How incremental works

1. **Check for existing specs** in `.organon/specs/`. If none exist, fall through to
   full generation.

2. **Identify changed source files.** Read the alignment manifest's
   `surfaces.specs.git_head` to get the last-generated commit. Run:
   ```bash
   git diff <last_head> HEAD --name-only
   ```
   This gives the list of source files that changed since specs were last generated.

3. **Match changed files to specs.** Read each existing `.workflow.yaml` and
   `.model.yaml` file's `source` frontmatter field. If a spec's source file appears
   in the changed-files list, that spec needs regeneration. Also recompute
   `source_hash` and compare — if the hash matches despite the file being in the
   diff (e.g., whitespace-only change), skip it.

4. **Regenerate only affected specs.** For each stale workflow or model spec, re-read
   the source file and rewrite the spec with updated content and `source_hash`.

5. **Skip cross-cutting specs.** Invariants, decisions, quality, services, and
   contract are only regenerated during full runs. They change rarely and have no
   clean file-level source mapping.

6. **Skip contract cross-check** in incremental mode — it requires the full workflow
   set and contract to be current.

7. **Report** which specs were regenerated, which were skipped (hash matched), and
   which are cross-cutting (deferred to full run). Suggest a full run if it's been
   a while.

### When to use full vs incremental

- **Full:** First generation (no specs exist), periodic ground-truth pass, after major refactors,
  when cross-cutting specs (invariants, decisions, quality) may have changed
- **Incremental:** Default when specs already exist — during active development when code drifts

## Workflow (Full Generation)

### 1. Scan the codebase and project docs

**Code scan** — identify:
- **Models** -- classes with fields (dataclasses, Pydantic, ORM models, TypeScript interfaces)
- **Workflows** -- three kinds:
  1. **State-machine**: fields with bounded sets of named values where code transitions between them. Look for any field with enum-like values and transition logic, not just fields named `status`.
  2. **Existential lifecycle**: entities created/destroyed via API with no explicit state field.
  3. **Query operations**: endpoint groups that read/compute without mutating state — search, summarize, export, reports. These are real user workflows: set up data, query it, refine, paginate.
- **Invariants** -- validation rules, guard clauses, cross-field constraints, uniqueness constraints, authorization checks
- **Config and dependencies** -- `pyproject.toml`, `package.json`, `Cargo.toml`, CI configs, test configs

**Docs scan** — read project documentation for user stories and usage patterns that code doesn't encode:
- `README.md`, `docs/`, user guides, API docs, developer guides
- These reveal multi-step user journeys, query workflows, and design rationale
- The contract gives the complete endpoint list; docs give the user stories that group endpoints into workflows; code gives implementation details

Ask the user which modules/features to generate specs for if not specified.

### 2. Extract contract (API spec)

Run the extraction script:
```bash
python .organon/defaults/scripts/specs/extract_openapi.py <project_dir>
```

If extraction succeeds, save output to `.organon/specs/openapi.json`.

If extraction fails, read the error message. For frameworks without auto-generation (plain Flask, raw Express), extract from route decorators and request/response models manually and mark the output with `# HAND-WRITTEN -- no framework auto-generation available`.

For non-HTTP projects: extract module exports to `exports.yaml` or CLI structure to `cli.yaml`. Skip if no API surface exists.

### 3. Generate YAML specs

For each spec type, read the template first, then fill it from code analysis:

- **Model** (`.model.yaml`): template at `.organon/defaults/templates/files/specs/model.yaml`
- **Workflow** (`.workflow.yaml`): template at `.organon/defaults/templates/files/specs/workflow.yaml` — use the unified `steps:` format. Each step is one API operation. Steps that change state include `state_change:` with `from:` and `to:`. Steps that don't (queries) omit `state_change:`. Optionally list `states:` for documentation when the workflow tracks state values. For each step with an `api:` section, also capture error responses by inspecting the code's exception handlers, HTTPException raises, and IntegrityError catches. Add an `errors:` list to the step with status codes the code actually returns on failure (e.g., `errors: [{status: 409, condition: "duplicate name"}]`).

  **Multi-source state changes:** When a step can be triggered from multiple
  source states (e.g., cancel allowed from queued, idle, or processing), use
  `from: [queued, idle, processing]` — not just the single most common source.
  Check the code's transition table, guard conditions, and preconditions to
  find all valid source states.

  **Implicit/internal transitions:** Code often defines transitions that have
  no API endpoint — error paths (processing → failed), background completions
  (processing → idle), timeouts. Look for these in transition tables, error
  handlers, background task callbacks, and state machine definitions. Emit
  them as workflow steps with no `api:` section and a `trigger: internal`
  field (e.g., `{name: task-error, trigger: internal, state_change: {from: processing, to: failed}, description: "Background process fails"}`).
  Every state reachable in the code must be reachable in the workflow.
- **Invariants** (`.invariants.yaml`): template at `.organon/defaults/templates/files/specs/invariants.yaml`

**Source hashing:** For each workflow and model spec, compute `source_hash` before
writing. The `source` frontmatter field names the source file. Run:
```bash
python3 .organon/defaults/scripts/specs/compute_source_hash.py <source_file>
```
Write the 16-char hex result into the `source_hash` frontmatter field. This enables
incremental generation on future runs.

Before writing rationale fields, read `references/rationale-guide.md` for calibration on when rationale is needed vs. when to omit it.

### 4. Generate markdown specs

- **Decisions** (`decisions.md`): template at `.organon/defaults/templates/files/specs/decisions.md`. Populate from config files, dependency files, README, project docs, and code structure.
- **Quality** (`quality.md`): template at `.organon/defaults/templates/files/specs/quality.md`. Populate from test configs, CI configs, monitoring setup. Sparse content is fine for early-stage projects -- use `<!-- TODO: define -->` for undiscoverable sections.

### 4b. Generate service definitions

- **Services** (`services.yaml`): template at `.organon/defaults/templates/files/specs/services.yaml`. Scan docker-compose.yml, .env files, Makefile targets, and code imports to identify services (databases, APIs, external dependencies). For each service, capture the start/stop commands, health check URL, required env vars, and port. `/sync-tests-with-specs` reads this to manage the test environment lifecycle.

### 5. Cross-check workflows against contract

After generating all workflows, verify contract coverage:

1. List every endpoint from the contract (openapi.json or equivalent)
2. List every endpoint referenced in workflow step `api:` sections
3. Identify uncovered endpoints — those in the contract but not in any workflow

For each uncovered endpoint, resolve it:
- **Add to an existing workflow** if it logically belongs (e.g., a GET detail endpoint belongs in the entity's lifecycle workflow)
- **Create a new workflow** if the endpoints form a coherent group (e.g., search endpoints → search workflow)
- **Flag as SPEC GAP** only if the endpoint cannot be meaningfully grouped — add `# SPEC GAP: endpoint /path not covered by any workflow`

Report the coverage result: X/Y endpoints covered, with details on uncovered ones.

### 6. Capture screenshots (optional)

If the app has a UI and is running, capture key screens to `.organon/specs/screenshots/`. Skip if not running.

### 7. Validate

Run the validation script against all generated specs:
```bash
python .organon/defaults/scripts/specs/validate_specs.py .organon/specs/
```

If validation fails, fix the issues and re-validate. Do not deliver specs that fail validation.

### 8. Report results

List all generated files by type. Include contract coverage (X/Y endpoints in workflows). Highlight areas needing manual review. Note any types skipped and why.

### 9. Update alignment manifest

Read `.organon/alignment-manifest.json`. Update:
- `surfaces.specs.last_checked`: current ISO 8601 timestamp
- `surfaces.specs.git_head`: current `git rev-parse HEAD`
- `surfaces.specs.checks.coverage.primary`: `model_count`, `workflow_count`, `invariant_count`, `decisions_exists`, `quality_exists`, `contract_exists`, `screenshots_count`
- `surfaces.specs.checks.coverage.contract_endpoints`: `total`, `covered_by_workflows`, `uncovered`
- `surfaces.specs.checks.coverage.derived`: leave unchanged (handled by `/derive-views-from-specs`)
- `surfaces.specs.status`: `"aligned"` if all discoverable types covered and all contract endpoints in workflows, `"gaps"` otherwise
- Append to `skill_runs`: `{"skill": "sync-specs-with-code", "ran_at": "<ISO 8601>", "git_head": "<commit>", "surfaces_updated": ["specs"], "mode": "full|incremental", "summary": "<one-line result>"}`
- Truncate `skill_runs` to last 20 entries

If manifest doesn't exist, create it with only this skill's entry populated. Other surfaces marked as `"unchecked"`.
