# Rationale Guide

When writing invariants and transitions, every assertion falls into one of two categories:

**Transcribed from code** -- you found the exact behavior implemented (an explicit guard, a status code return, a validation check). Write the assertion without rationale.

**Inferred beyond code** -- you're asserting something based on best practices, naming conventions, or architectural patterns that isn't explicitly enforced. Add a `rationale:` field explaining:

- What you observed in the code
- What you asserted beyond what the code does
- Why you believe the assertion should hold

## Common cases requiring rationale

- **Error codes** where no explicit guard returns that code
- **Invariants** about behavior you expect but didn't find enforced
- **Workflow transitions** with preconditions not checked in code
- **Security/authorization** rules with no explicit middleware or guard

## Calibration

False positives (unnecessary rationale on a transcribed assertion) are harmless. False negatives (unverified claims without rationale) cause test failures that waste cycles debugging phantom requirements. When uncertain, add the rationale.
