---
name: release-check
description: Check if the project is ready for a release. Assess uncommitted changes, test status, changelog, version, and what has changed since the last tag. Safe to run repeatedly.
---

Assess whether this project is ready for a new release. Report a clear status for each check.

## Checks to perform

### 1. Working tree status

- Are there uncommitted changes? Untracked files that should be committed?
- Report: clean or dirty (list what's dirty)

### 2. Tests

- Detect test framework: pytest (Python), jest/vitest (Node), go test (Go), etc.
- Run the test suite
- Report: passing, failing (with summary), or no tests found

### 3. What changed since last release

- Find last version tag: `git describe --tags --abbrev=0`
- Count commits since: `git rev-list <tag>..HEAD --count`
- Summarize changes: `git log <tag>..HEAD --oneline`
- Categorize: features, fixes, chores, breaking changes
- Report: number of commits, high-level summary

### 4. Version consistency

- Check that the version in the project file (pyproject.toml, package.json) matches the last tag, or is already bumped
- If version matches last tag and there are new commits, suggest what the next version should be based on the changes (patch for fixes, minor for features, major for breaking)

### 5. Changelog status

- Does CHANGELOG.md exist?
- Is there content under `[Unreleased]`?
- If there are commits since last tag but nothing under Unreleased, flag it

### 6. Branch status

- What branch are we on?
- Is it up to date with the remote? Ahead/behind?
- Are there open PRs that should be merged first?

## Output format

Present results as a checklist:

```
## Release Readiness

- [x] Working tree clean
- [x] Tests passing (44/44)
- [ ] Changelog needs update (12 commits since v0.2.0, nothing under Unreleased)
- [x] Version: 0.2.0 (suggest 0.3.0 — new features)
- [x] Branch: main, up to date with origin

### Changes since v0.2.0 (12 commits)
- feat: add config system for container sessions
- feat: container reuse logic
- fix: remove anthropic key auto-injection
...

### Recommendation
Ready to release after updating changelog. Suggested version: 0.3.0 (minor — new features added)
```

## Important

- This is a read-only check. Do NOT modify any files.
- Do NOT commit, tag, or push anything.
- If tests take more than 2 minutes, skip and note it.
- Use `gh pr list` to check for open PRs if gh is available, skip silently if not.
