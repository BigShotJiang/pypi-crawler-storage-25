---
name: merge-sprint-specs
description: "Guide merge workflow for sprint overlay specs into project specs"
---

# Merge Sprint Specs

Guide the merge workflow for sprint overlay specs: preview, review conflicts, resolve, apply.

## Workflow

1. **Detect sprint specs**:
   - Check current sprint directory for `specs/` subdirectory
   - If not found, inform user no overlay specs exist

2. **Preview merge**:
   - Run `organon admin merge-preview` or use `preview_spec_merge` MCP tool
   - Display additions, modifications, conflicts, and reference errors

3. **Review results**:
   - For each addition: confirm new specs/entities/fields are intentional
   - For each modification: verify changes are correct
   - For each conflict: explain what differs and why

4. **Resolve conflicts** (if any):
   - For each conflict, present base and overlay values
   - Help user decide which value to keep
   - Update overlay YAML files to resolve conflicts
   - Re-run preview to confirm clean merge

5. **Apply merge**:
   - Run `organon admin merge-apply` to write merged specs to `.organon/specs/`
   - Or run with `--dry-run` first for final verification
   - Confirm files written successfully

## When to Use

- Near sprint completion when sprint has `specs/` directory
- When completion gate reports spec merge conflicts
- When manually reviewing spec changes before merging

## Output Format

```
## Merge Preview

Additions: N
- [models] checkout: New entity 'Product'

Modifications: N
- [states] order: Added 'cancelled' to states

Conflicts: N
- [models] checkout [version]: base="1.0" overlay="2.0"

Reference Errors: N

Status: Clean merge / N conflict(s) to resolve
```

### Final Step: Update alignment manifest

Read `.organon/alignment-manifest.json`. Update the `surfaces.specs` entry:
- Set `surfaces.specs.last_checked` to current ISO 8601 timestamp
- Set `surfaces.specs.git_head` to current `git rev-parse HEAD`
- Set `surfaces.specs.status` to `"aligned"` if merge was clean and applied, `"gaps"` if conflicts remain or merge was not applied
- Append to `skill_runs` array: `{"skill": "merge-sprint-specs", "ran_at": "<ISO 8601>", "git_head": "<commit>", "surfaces_updated": ["specs"], "summary": "<one-line result>"}`
- Truncate `skill_runs` to last 20 entries
Write the updated manifest.

If manifest doesn't exist, create it with only this skill's entry populated. Other surfaces marked as `"unchecked"`.

### Suggested Next Skill

After merging specs, the Specs→Docs edge likely drifted. Suggest running `/sync-docs-with-specs` to ensure documentation reflects the merged spec changes.
