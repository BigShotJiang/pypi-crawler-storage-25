---
name: checkpoint
description: "Clean working directory — commit, verify build, flag stale docs, remove artifacts, update sprint status"
---

# Checkpoint

Ensure the repo is clean and consistent after a chunk of work. Smaller than a release, bigger than a commit — this is "make sure I didn't leave a mess."

**When to run:** End of work session, after completing a logical unit, before switching context, before handoff, after messy exploration/debugging.

## Workflow

### Step 1: Git hygiene

1. Run `git status` to see all uncommitted changes and untracked files
2. Run `git diff --stat` to understand scope of changes
3. Categorize changes:
   - **Source code** — should be committed
   - **Generated/runtime files** — should be gitignored or cleaned up (e.g., `__pycache__`, `.pyc`, `.organon/logs/`, `.organon/cache/`)
   - **Temporary/scratch files** — ask user before deleting
   - **Sensitive files** — warn if `.env`, credentials, keys are staged
4. If there are uncommitted source changes:
   - Review the diff to write an accurate commit message
   - Stage relevant files (NOT runtime data or artifacts)
   - Commit with a descriptive message following the project's commit conventions
   - Push to remote
5. If working tree is already clean, report "Working tree clean" and continue

### Step 2: Build verification

Run quick checks to catch broken state. Stop on first failure category and report.

Detect the project type and run appropriate smoke checks:

1. **Python** — If `pyproject.toml` exists, find the main package and run `python -c "import <package>"` to verify imports resolve. If it fails, report which import is broken.
2. **Node/TypeScript** — If `tsconfig.json` exists, run `npx tsc --noEmit` to verify TypeScript compiles. Report any type errors.
3. **Lint** — Run `make lint` if available. Report violations but don't auto-fix (that changes code after we just committed).

Report: all passing, or list of failures with file:line references.

**Important:** Do NOT run the full test suite — that's `/sync-tests-with-specs`. This is a quick smoke check only.

### Step 3: Doc sync check

Flag documentation that may be stale. Do NOT auto-update — just report.

1. **STRUCTURE.md** — Compare the directory tree in STRUCTURE.md against actual filesystem. Flag:
   - Directories/files that exist but aren't listed
   - Entries that reference files that no longer exist
   - Only check top-level and one level deep, not exhaustive
2. **CLAUDE.md** — Check that file paths referenced in CLAUDE.md still exist. Flag any broken references.
3. **README.md** — If it exists, check that commands in code blocks (e.g., `make dev`, `make test`) are still valid Makefile targets.

Report: list of stale references, or "Docs look current."

If stale docs are found, suggest the appropriate skill: `/sync-docs-with-specs` or `/sync-docs-with-specs`.

### Step 4: Clean up artifacts

Look for common debris and remove it. Ask before deleting anything ambiguous.

**Auto-clean (no confirmation needed):**
- `__pycache__/` directories
- `.pyc` files
- `.pytest_cache/`
- `node_modules/.cache/`
- Empty directories in temp/scratch locations

**Flag for user (don't auto-delete):**
- Files with `TODO`, `FIXME`, `HACK`, `XXX` that were added in this session's changes
- Debug print statements (`print(`, `console.log(`) in committed source files — warn but don't remove
- Orphaned test files (test files for source files that no longer exist)
- Untracked files that aren't gitignored — ask if they should be committed or ignored

Report: what was cleaned, what was flagged.

### Step 5: Sprint context

Only applies if there's an active sprint (check `.organon/current-context.json` and sprint directories).

1. Read current sprint context
2. Check if any tasks were worked on this session (by comparing committed file changes against sprint plan task files)
3. If tasks were completed, suggest updating their status via `update_task_status` MCP tool
4. If sprint work happened but task status is stale, report the mismatch

Report: sprint status summary, or "No active sprint."

## Output Format

```
## Checkpoint Report

### Git
- [x] Committed: "feat: add URL+depth crawl scraper" (6 files, +200/-92)
- [x] Pushed to origin/main

### Build
- [x] Backend imports OK
- [x] Frontend TypeScript OK
- [ ] Lint: 2 warnings in service.py (line 45: unused import, line 112: line too long)

### Docs
- [x] STRUCTURE.md current
- [ ] CLAUDE.md references `docs/design/foo.md` which doesn't exist

### Artifacts
- [x] Cleaned 3 __pycache__ directories
- Flagged: `image.png` in project root — commit, gitignore, or delete?

### Sprint
- No active sprint

### Suggested next steps
- Fix lint warnings
- Run `/sync-docs-with-specs` to refresh STRUCTURE.md
```

## Rules

- **Never auto-fix code** — this skill reports, it doesn't modify source. Code changes need review.
- **Always commit before other steps** — so build verification and doc checks reflect the committed state.
- **Be concise** — this is a checklist, not a narrative. One line per item.
- **Don't block on warnings** — report them and move on. The user decides what to fix.
