# Alignment Report Format

## Report Template

```
## Alignment Report

**Git HEAD:** <short hash>
**Last full scan:** <timestamp>

| Surface | Status | Last Checked | Details |
|---------|--------|-------------|---------|
| Code    | —      | (source of truth) | <N> modules, <N> files |
| Docs    | <status> | <time> | <one-line summary of findings> |
| Specs   | <status> | <time> | <one-line summary of findings> |
| Tests   | <status> | <time> | <one-line summary of findings> |

### Suggested Actions
1. <most important action, with skill name to run>
2. <second action>
3. <third action>
```

## Status Display

- `aligned` → "Aligned"
- `gaps` → "Gaps"
- `none` → "None"
- `unchecked` → "Unchecked"
- Code surface always shows "—" (it is the source of truth)

## Details Column Examples

- Docs aligned: "CLAUDE.md complete, STRUCTURE.md current, disclosure chain valid"
- Docs gaps: "CLAUDE.md missing Architecture section, STRUCTURE.md stale"
- Specs none: "No specs exist. 5 domain entities found in code."
- Specs gaps: "3 workflows, 2 models, no Decisions doc. Derived views missing."
- Specs aligned: "3 workflows, 2 models, 1 invariant, Decisions, Quality, Contract. Derived views fresh."
- Tests none: "No test files found."
- Tests gaps: "3 test files, but 2 spec workflows have no tests"

## Suggested Actions

Derive from the findings. Common suggestions:
- Docs gaps (CLAUDE.md) → "Add missing sections to CLAUDE.md" or "Run /align again after approving doc updates"
- Docs gaps (STRUCTURE.md missing/stale/TODO) → "Run /sync-docs-with-specs to generate meaningful descriptions"
- Specs none → "Run /sync-specs-with-code to create specs for N domain entities"
- Specs gaps (missing primary types) → "Run /sync-specs-with-code to cover missing types"
- Missing Decisions → "Run /sync-specs-with-code — no Decisions doc found"
- Missing Quality → "Run /sync-specs-with-code — no Quality doc found"
- Missing Contract → "Run /sync-specs-with-code — no Contract/API spec found"
- Derived views stale → "Run /derive-views-from-specs — source specs changed since last derivation"
- Derived views missing → "Run /derive-views-from-specs to generate State, Architecture, and User Stories views"
- Tests none → "Run /sync-tests-with-specs after specs exist"
- Tests gaps → "Run /sync-tests-with-specs to cover N workflows without tests"
- All aligned → "No action needed. All surfaces aligned."

## Fast Path

When manifest is fresh (git HEAD unchanged), report from cached state. Note at top:
"Manifest is fresh (git HEAD unchanged since last /align). Reporting cached state."
