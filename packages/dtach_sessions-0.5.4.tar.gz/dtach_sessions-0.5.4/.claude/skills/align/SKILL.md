---
name: align
description: "Single entry point for all project alignment — scan surfaces, detect drift, update docs, write manifest"
---

# Align

Assess alignment across all four project surfaces (code, docs, specs, tests), detect drift, update documentation when warranted, and write a persistent manifest for incremental re-checks.

Two operating states:
- **No manifest:** Full scan of all surfaces. Build manifest. Report alignment state.
- **Manifest exists:** Compare git HEAD against manifest. Re-scan only stale surfaces. Update manifest. Report.

## Prerequisites

- `.organon/` directory exists (`organon init` has been run)
- Git repository initialized

## Workflow

### Step 0: Check working directory

Run `git status --porcelain`.

- If empty → proceed.
- If not empty → warn the user: "Working directory has uncommitted changes. Results may not reflect the committed state. Commit first, or proceed anyway?" Wait for user response. If user says proceed, continue. If user says commit, stop and let them commit.

### Step 1: Check for manifest

Read `.organon/alignment-manifest.json`.

**Path A — No manifest:**

Skip to Step 2. All four surfaces will be scanned.

**Path B — Manifest exists:**

1. Read the manifest JSON.
2. Run `git rev-parse HEAD` to get the current commit hash.
3. Compare against `manifest.git_head`.

**If same** → all surfaces are fresh. Skip to Step 5 (report from manifest data). This is the fast path — no scanning needed.

**If different** → determine which surfaces are stale:
1. Run `git diff <manifest.git_head> HEAD --name-only` to get the list of changed files.
2. For each changed file, map it to a surface using `manifest.surface_paths`:
   - File starts with any path in `surface_paths.code` → code surface stale
   - File starts with any path in `surface_paths.specs` → specs surface stale
   - File starts with any path in `surface_paths.tests` → tests surface stale
   - File matches any path in `surface_paths.docs` → docs surface stale
3. If code surface is stale, mark docs and specs stale too (code is source of truth — downstream surfaces need re-checking).
4. Proceed to Step 2, scanning only stale surfaces.

### Step 2: Scan surfaces

For each surface being scanned (all four if no manifest, only stale surfaces if manifest exists):

#### Code surface

Perform an exhaustive codebase inventory. Do not summarize or skip items.

- **Directories:** List every top-level and second-level directory. Note purpose of each.
- **Services/modules:** Identify all services, packages, or modules. Check every subdirectory.
- **Scripts:** Find executable or runnable scripts — check `scripts/`, `bin/`, project root for common extensions (`.sh`, `.py`, `.ps1`, `.rb`, `.js`, `.ts`, `.mjs`) and files with shebang lines. List every one.
- **Configs:** Find all config files (yaml, json, toml, ini, env) and note what they configure.
- **Dependencies:** Check `pyproject.toml`, `package.json`, `requirements.txt`, `Cargo.toml`, `go.mod` for stack info.
- **Infrastructure:** Docker files, compose files, Makefiles, CI configs.
- **Tests directory structure:** Note test directories and frameworks used (this feeds into the tests surface scan).

On first run, record `surface_paths.code` in the manifest (e.g., `["src/"]`). On subsequent runs, use existing `surface_paths.code`.

#### Docs surface

1. **Read root CLAUDE.md.** Classify state:
   - **Empty:** No project content (placeholder or just the `@.organon/CLAUDE.md` reference)
   - **Partial:** Some sections exist but required template sections are missing
   - **Complete:** All required template sections present

2. **If partial or complete:** Read the section template at `.organon/defaults/templates/files/claude-md-sections.md`. For each section defined in the template, check whether it exists in CLAUDE.md and whether its content is accurate against the code inventory. Identify:
   - Template sections present with content
   - Template sections missing or empty
   - Custom sections (headings not in the template) — record their names

3. **Compute `file_hash`:** SHA-256 hash of CLAUDE.md content.

4. **Read `.organon/CLAUDE.md`.** Check framework version and content is current.

5. **Read `.organon/STRUCTURE.md`** (if it exists). Compare mapped directories against actual directory layout from code inventory. Also check whether semantic sections (Purpose, Module Responsibilities, Integration Points, Development Status) contain real content or TODO placeholders. Classify as:
   - `missing` — file doesn't exist
   - `stale` — directory tree doesn't match actual layout, OR semantic sections contain TODO placeholders
   - `current` — tree matches layout AND semantic sections have real content

6. **Check progressive disclosure chain:** Verify all three files exist and reference each other correctly:
   - `CLAUDE.md` contains `@.organon/CLAUDE.md`
   - `.organon/CLAUDE.md` references `.organon/STRUCTURE.md`
   - `.organon/STRUCTURE.md` exists and reflects actual layout

Record findings in manifest under `surfaces.docs.checks`.

#### Specs surface

1. Check `.organon/specs/` directory.
2. If no spec files exist → record `status: "none"`, done.
3. If specs exist, count files by the 9 document types:

   **Primary types (7):**
   - Workflow (`*.workflow.yaml`) — what the system does
   - Model (`*.model.yaml`) — what the data looks like
   - Invariants (`*.invariant.yaml`) — what must always be true
   - Decisions (`*.decisions.md`) — how it's built (tech stack, architecture, rationale)
   - Quality (`*.quality.md`) — how well it must perform (SLAs, performance, security)
   - Contract/API Spec (`openapi.json`, `*.contract.*`) — what the system exposes
   - Screenshots (`screenshots/` directory) — what the UI looks like

   **Derived types (2):** Check `.organon/specs/derived/`
   - State (`derived/*.state.md`) — joint cross-entity state machines, derived from Workflows
   - Architecture (`derived/*.architecture.md`) — runtime topology, derived from Decisions + STRUCTURE.md + Contract + Model

   **Derived view freshness:** For each derived view, read frontmatter `source_hash`. Compute the current hash of all files listed in `derived_from`. If hashes differ, the derived view is stale.

4. Record coverage using the primary/derived schema in manifest under `surfaces.specs.checks.coverage`.
5. If `/validate-specs` has been run previously (check `skill_runs` in manifest), record validity status. Otherwise mark validity as `unchecked`.

Also verify document categories are organized correctly:
- **Navigational:** `CLAUDE.md`, `.organon/CLAUDE.md`, `STRUCTURE.md`
- **Project:** The 9 types above (in `.organon/specs/`, `.organon/specs/derived/`)
- **Sprint:** `.organon/sprints/`
- **Framework:** `.organon/defaults/`, `.claude/skills/`
- **Working:** `.organon/dev-docs/`

#### Tests surface

1. Count test files across all test directories.
2. If no test files exist → record `status: "none"`, done.
3. If tests exist:
   - If specs exist: check which spec-defined workflows have corresponding test files
   - Record `workflows_with_tests` and `workflows_without_tests`
4. If `/sync-tests-with-specs` has been run previously (check `skill_runs` in manifest), read its results and record in `surfaces.tests.checks.gap_analysis`. Otherwise leave gap_analysis fields as null.

### Step 3: Merge and update docs (if needed)

Execute this step only if ALL of the following are true:
- Docs surface was scanned in Step 2
- CLAUDE.md state is `empty` or `partial`, OR content updates are warranted (template sections missing or stale content detected)

**Merge semantics:**

1. Read the full content of CLAUDE.md.
2. Read the section template: `.organon/defaults/templates/files/claude-md-sections.md`
3. Classify every existing section in CLAUDE.md:

   - **Template section with existing content:** Compare against code inventory. Identify items to add (new directories, new modules, changed commands). Do NOT remove existing content. Flag contradictions (content in CLAUDE.md that conflicts with code inventory) as conflicts for user review.
   - **Template section with no content or missing entirely:** Generate from code inventory.
   - **Custom section (heading not in template):** Preserve in place, in its current position. Never modify. Record the heading name in manifest `custom_sections` list.

4. **Present proposed changes to the user.** Show:
   - Sections to create (list heading names and summarize content)
   - Sections to augment (show specific additions, not full section rewrites)
   - Conflicts found (content that contradicts code inventory — show both sides)
   - Custom sections preserved (list heading names)

5. **Wait for user confirmation.** Apply changes only after the user approves. If the user rejects specific changes, apply only the approved ones.

**Rules for merge:**
- Use exact heading names from the template. Do not rename, reorder, or nest differently.
- The `@.organon/CLAUDE.md` reference must be present in root CLAUDE.md.
- The `## Organon` section is managed by `organon init` — do not regenerate it.
- Conditional sections (Key Patterns, Scripts, Data) — include only when relevant content exists in the code inventory.
- Content must be factual — derived from code, not assumed. If unsure about a directory's purpose, state what files it contains.

### Step 4: Write manifest

Build or update the `.organon/alignment-manifest.json` file.

Read the manifest schema from `references/manifest-schema.json`. Use that structure exactly.

**Rules:**
- `version` starts at 1. Increment only on breaking schema changes.
- `git_head` is always `git rev-parse HEAD` at time of check.
- `status` values: `aligned` (no gaps found), `gaps` (issues detected), `unchecked` (never checked), `none` (surface doesn't exist — e.g., no specs).
- `surface_paths` recorded on first scan, reused on subsequent runs.
- `skill_runs` is append-only. Truncate to the last 20 entries.
- Write to `.organon/alignment-manifest.json.tmp`, then rename (atomic write).

**Setting surface status:**
- All checks pass → `aligned`
- Any check finds missing content, staleness, or drift → `gaps`
- Not scanned and no prior data → `unchecked`
- No files at all → `none`

### Step 5: Report

Read `references/report-format.md` for the table format, status display rules, details column examples, and suggested action patterns. Present the alignment state to the user using that format.

### Step 6: Commit (if changes were made)

If Step 3 produced changes to CLAUDE.md or other docs:
- First run: `docs: Bootstrap project documentation via /align`
- Update run: `docs: Update project documentation via /align`

If only the manifest was written/updated (no doc changes):
- Do not commit. The manifest tracks state and will be committed with the next substantive change, or the user can commit it separately.

## Final Step: Update alignment manifest

This skill writes the manifest itself (Step 4), so this step is inherently satisfied. Append to `skill_runs`:

```json
{
  "skill": "align",
  "ran_at": "<ISO 8601>",
  "git_head": "<current commit hash>",
  "surfaces_updated": ["<list of surfaces that were scanned>"],
  "summary": "<one-line: e.g., 'Full scan: docs gaps, specs none, tests none' or 'Incremental: docs re-scanned, aligned'>"
}
```

Truncate `skill_runs` to the last 20 entries.

## Output

Report to the user:
- Which path was taken (full scan / incremental / fast path)
- Alignment state table (Step 5 format)
- If docs were updated: what changed and why
- Suggested next actions with specific skill names
