---
name: sync-docs-with-specs
description: "Synchronize docs with specs — update STRUCTURE.md, check docs vs specs bidirectionally, fix drift"
---

# Sync Docs with Specs

Ensure documentation reflects the current codebase and specs. Three phases: update project structure, check alignment between docs and specs, fix drift.

## Decision Logic

1. **STRUCTURE.md stale or missing?** → Phase 1 (update structure from code).
2. **Specs exist?** → Phase 2 (check docs against specs bidirectionally).
3. **Gaps or contradictions found?** → Phase 3 (report and fix).

If specs don't exist, stop and suggest `/sync-specs-with-code` first.
If no docs exist, stop and suggest `/align` first.

---

## Phase 1: Update STRUCTURE.md

Update `.organon/STRUCTURE.md` with both the current directory layout and meaningful descriptions of what each part of the project does. The directory tree comes from scanning the filesystem; the descriptions come from reading the code.

### Prerequisites

- `.organon/` directory exists (`organon init` has been run)
- `.organon/STRUCTURE.md` exists (created by `organon init` or `organon structure generate .`)

If STRUCTURE.md doesn't exist, run `organon admin structure generate .` first to create the scaffold, then proceed.

### Step 1.1: Read current state

1. Read `.organon/STRUCTURE.md` to understand what exists.
2. Read `.organon/config.yaml` for project configuration.
3. Run `git rev-parse HEAD` for manifest tracking.

### Step 1.2: Update directory tree

Try `organon admin structure update .` to regenerate the Directory Structure section from the actual filesystem. This preserves any existing manual sections while updating the tree to reflect current layout.

If the CLI command is not available, scan the filesystem directly: list directories respecting `.gitignore` and `.organon_ignore`, build the ASCII tree, and update the Directory Structure section in STRUCTURE.md manually.

Read the updated `.organon/STRUCTURE.md` to get the fresh tree.

### Step 1.3: Inventory the codebase

For each significant directory in the tree (top-level and important second-level directories):

1. **Read key files** — entry points, `__init__.py`, `index.*`, README, main modules. Read enough to understand the directory's purpose, not every file.
2. **Identify responsibilities** — what does this directory own? What domain concepts live here?
3. **Identify integration points** — what does it import from or export to other directories? What external services does it talk to?

Use subagents for parallel exploration when the project has multiple independent services or modules.

### Step 1.4: Generate semantic sections

Write meaningful content for each section:

#### Purpose

One to three sentences describing what the project is, what it does, and its primary technology stack. Derived from:
- `pyproject.toml`, `package.json`, or equivalent for project metadata
- Root README if it exists
- The code inventory from Step 1.3

Do NOT use placeholder text. If you cannot determine the purpose, state what the project contains factually.

#### Navigation

List the key files a new developer should read first to understand the project, with one-line descriptions of what each file tells them. Include:
- CLAUDE.md (project instructions)
- Main entry points
- Configuration files that define behavior
- Any architecture or design docs

#### Module Responsibilities

For each significant directory, write 1-2 sentences describing:
- What it owns (domain concepts, functionality)
- Its role in the system

Format as a definition list:
```
**directory/** — What it does. What domain concepts it owns.
```

Group by logical layer if the project has clear layers (e.g., API, services, data, infrastructure).

#### Integration Points

Describe how the major parts connect:
- Service-to-service communication (HTTP, gRPC, message queues)
- Shared data stores
- Import dependencies between modules
- External service integrations
- Build/deploy relationships

#### Development Status

Describe the current state:
- Which parts are actively developed vs stable vs deprecated
- Any significant work in progress (check for active sprints in `.organon/sprints/`)
- Known gaps or incomplete areas visible from the code

### Step 1.5: Present and apply

1. Show the user the proposed STRUCTURE.md content in full.
2. Highlight what changed from the previous version (new sections filled in, descriptions updated, tree changes).
3. Wait for user confirmation before writing.
4. Apply approved changes to `.organon/STRUCTURE.md`.

Commit with: `docs: Update STRUCTURE.md via /sync-docs-with-specs`

---

## Phase 2: Check Docs against Specs

Verify alignment between specs and docs in both directions: do docs describe what specs define, and do doc claims have backing specs?

### Step 2.1: Read all spec files

Scan `.organon/specs/` for spec files by type:
- **Model specs** (`.model.yaml`): entities, fields, relationships, constraints
- **Workflow specs** (`.workflow.yaml`): workflow names, steps, transitions
- **Contract specs** (`.contracts.yaml`): API endpoints, methods, paths, parameters
- **State specs** (`.states.yaml`): state machines, states, transitions
- **Invariant specs** (`.invariants.yaml`): global invariants, domain rules

Build an inventory of spec-defined behaviors:
- Entity names and their key fields
- Workflow names and their step sequences
- API endpoints with methods and paths
- State machine names with their states and transitions
- Invariants and domain rules

### Step 2.2: Read all doc files

Scan project documentation:
- `CLAUDE.md` (root) — project overview, features, architecture
- `.organon/CLAUDE.md` — framework instructions
- `.organon/STRUCTURE.md` — directory map
- `docs/` directory (if exists) — user guides, API docs, reference
- `.organon/defaults/docs/` — framework docs
- Any other `.md` files in project root or docs directories

Extract documented behaviors:
- Feature claims ("supports X", "provides Y")
- API descriptions (endpoints, parameters, responses)
- Entity/model descriptions
- Workflow descriptions
- State/lifecycle descriptions
- Architecture claims

### Step 2.3: Specs-to-Docs check (is every spec reflected in docs?)

For each spec-defined behavior, check if docs describe it:

- **Entities** from model specs — mentioned and described in docs?
- **Workflows** from workflow specs — documented somewhere?
- **API endpoints** from contract specs — described in API docs or CLAUDE.md?
- **State machines** from state specs — states and transitions documented?
- **Invariants** from invariant specs — domain rules reflected in docs?

Classify each finding:
- **Documented**: Spec behavior is described in docs (cite file and section)
- **Missing**: Spec behavior has no corresponding documentation
- **Partial**: Docs mention the entity/workflow but omit key details from the spec

### Step 2.4: Docs-to-Specs check (is every doc claim backed by a spec?)

For each doc claim about system behavior, check if a spec covers it:

- **Feature claims** in CLAUDE.md — backed by a model, workflow, or contract spec?
- **API descriptions** — consistent with contract specs (methods, paths, parameters match)?
- **Entity descriptions** — match model spec fields and constraints?
- **Workflow descriptions** — match workflow spec steps and ordering?
- **State descriptions** — match state spec transitions?

Classify each finding:
- **Backed**: Doc claim has a corresponding spec (cite spec file)
- **Unbacked**: Doc claim describes behavior with no spec coverage
- **Contradicted**: Doc claim conflicts with what the spec defines (detail the contradiction)

---

## Phase 3: Report and Fix

### Step 3.1: Report

Present findings from both phases:

```
## Docs-Specs Alignment Report

**STRUCTURE.md:** current | stale | missing
**Specs scanned:** N files (M entities, W workflows, E endpoints, S state machines)
**Docs scanned:** N files

### Specs Not in Docs (spec-defined but undocumented)
- [entity-name] from path/to/spec.model.yaml — not mentioned in any doc
- [workflow-name] from path/to/spec.workflow.yaml — partially documented in CLAUDE.md (missing steps 3-5)

### Doc Claims Without Specs (documented but no spec)
- [claim] in CLAUDE.md line N — "supports batch processing" — no spec covers this
- [claim] in docs/api.md line N — describes /api/v2/export endpoint — no contract spec

### Contradictions (docs and specs disagree)
- [entity.field] docs say "optional" but spec.model.yaml defines it as required
- [workflow] docs describe 3 steps but spec.workflow.yaml defines 5 steps

### Aligned (both directions covered)
- [entity-name] — spec: path/to/spec.model.yaml, docs: CLAUDE.md ## Architecture

### Summary
| Direction | Aligned | Gaps | Contradictions |
|-----------|---------|------|----------------|
| Specs -> Docs | N | N | N |
| Docs -> Specs | N | N | N |
```

### Step 3.2: Fix

For each gap or contradiction:
- **Missing doc for a spec:** Propose specific doc content to add, with target file and section.
- **Unbacked doc claim:** Suggest creating a spec via `/sync-specs-with-code`, or removing the stale doc claim.
- **Contradictions:** Present both sides, propose resolution. Apply with user confirmation.

### Suggested Next Actions

Based on findings:
- **Unbacked doc claims?** `/sync-specs-with-code` to create specs for documented features
- **Contradictions fixed?** Re-run `/sync-docs-with-specs` to verify
- **Spec validity concerns?** `/validate-specs` to validate spec file format

---

## Final Step: Update alignment manifest

Read `.organon/alignment-manifest.json`. Update:

**`surfaces.docs` update:**
- Set `last_checked` to current ISO 8601 timestamp
- Set `git_head` to current `git rev-parse HEAD`
- Set `checks.structure_md.state` to `"current"` or `"stale"` based on Phase 1
- Set `checks.structure_md.directories_mapped` to the count of directories in the tree
- Set `status` to `aligned` if no gaps or contradictions, `gaps` otherwise

**`surfaces.specs` update:**
- Set `last_checked` to current ISO 8601 timestamp
- Set `git_head` to current `git rev-parse HEAD`
- Set `status` to `aligned` if no gaps or contradictions in Docs->Specs direction, `gaps` otherwise

**`skill_runs` append:**
```json
{
  "skill": "sync-docs-with-specs",
  "ran_at": "<ISO 8601>",
  "git_head": "<commit hash>",
  "surfaces_updated": ["docs", "specs"],
  "summary": "STRUCTURE.md <state>, N aligned, N spec gaps, N doc gaps, N contradictions"
}
```

Truncate `skill_runs` to the last 20 entries.

Write the updated manifest. If the manifest doesn't exist, create it with `docs` and `specs` entries populated from this run and all other surfaces marked as `"unchecked"`.
