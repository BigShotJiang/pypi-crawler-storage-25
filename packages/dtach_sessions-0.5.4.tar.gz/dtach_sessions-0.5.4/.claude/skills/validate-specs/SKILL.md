---
name: validate-specs
description: "Validate spec file consistency — all 9 document types"
---

# Validate Specs

Validate all 9 spec document types in `.organon/specs/` for format, required fields, cross-reference consistency, and derived-view freshness.

## Document Types

| Category | Type | File Pattern |
|----------|------|-------------|
| Primary YAML | Model | `*.model.yaml` |
| Primary YAML | Workflow | `*.workflow.yaml` |
| Primary YAML | Invariants | `*.invariants.yaml` |
| Primary Markdown | Decisions | `*.decisions.md` |
| Primary Markdown | Quality | `*.quality.md` |
| Primary Other | Contract/API | `openapi.json`, `openapi.yaml`, `exports.yaml`, `cli.yaml` |
| Primary Other | Screenshots | `screenshots/` directory |
| Derived | State View | `derived/*.state.md` |
| Derived | Architecture View | `derived/*.architecture.md` |

## Workflow

1. **Locate spec files**:
   - Look in `.organon/specs/` for all document types:
     - `*.model.yaml`, `*.workflow.yaml`, `*.invariants.yaml`
     - `*.decisions.md`, `*.quality.md`
     - `openapi.json`, `openapi.yaml`, `exports.yaml`, `cli.yaml`
     - `screenshots/` directory
     - `derived/*.state.md`, `derived/*.architecture.md`
   - Categorize each file by type

2. **Validate primary specs** — run the validation script:
   ```bash
   python3 .organon/defaults/scripts/specs/validate_specs.py .organon/specs/
   ```
   This checks YAML schemas (required fields, correct types, flat list structures), markdown frontmatter and sections, and basic cross-references. Report its output.

   **Additionally validate** what the script doesn't cover:
   - **Contract/API specs**: `openapi.json` or `openapi.yaml` must have `openapi` (version), `info`, `paths`
   - **Screenshots** (informational only): check if `screenshots/` exists, list files
   - **Derived views** (`derived/*.state.md`, `derived/*.architecture.md`):
     - Frontmatter required: `type: derived`, `kind`, `derived_from`, `source_hash`, `last_derived`
     - Verify each `derived_from` file exists
     - Verify freshness: `python3 .organon/defaults/scripts/specs/compute_source_hash.py <files>` (pass files in `derived_from` order), compare to stored `source_hash`

3. **Check cross-references**:
   - WorkflowSpec.entity matches an entity in a model spec
   - Workflow transition triggers that reference API endpoints exist in contract spec
   - RelationshipDef.target entities exist in other model specs
   - Derived view `derived_from` source files exist
   - Derived view `source_hash` matches current source content (freshness check)

4. **Report results**:
   - List all specs found with pass/fail status
   - Detail any parse errors, missing fields, or broken references
   - Suggest fixes for each issue

## Output Format

```
## Spec Validation Report

### Primary YAML Specs
| File | Status | Issues |
|------|--------|--------|
| app.model.yaml | ✓ valid | — |
| app.workflow.yaml | ✗ invalid | Missing field 'steps' |
| app.invariants.yaml | ✓ valid | — |

### Primary Markdown Specs
| File | Status | Issues |
|------|--------|--------|
| project.decisions.md | ✓ valid | — |
| project.quality.md | ✗ invalid | Missing section 'Observability' |

### Contract/API Specs
| File | Status | Issues |
|------|--------|--------|
| openapi.yaml | ✓ valid | — |

### Screenshots
Directory: screenshots/ — 3 files found

### Derived Views
| File | Status | Freshness | Issues |
|------|--------|-----------|--------|
| derived/app.state.md | ✓ valid | ✓ fresh | — |
| derived/system.architecture.md | ✓ valid | ✗ stale | source_hash mismatch |

### Summary
Total: 8 specs found | Valid: 6 | Invalid: 1 | Stale: 1

### Cross-Reference Summary
- Workflow references: valid
- Invariant entity references: valid
- Derived source files: valid
- Derived freshness: 1 stale
```

### Final Step: Update alignment manifest

Read `.organon/alignment-manifest.json`. Update the relevant surface entry:
- Set `surfaces.specs.last_checked` to current ISO 8601 timestamp
- Set `surfaces.specs.git_head` to current `git rev-parse HEAD`
- Update `surfaces.specs.checks.validity` with this run's results:
  - `status`: `"valid"` if all specs passed, `"invalid"` if any failed
  - `error_count`: number of validation errors found
  - `last_tool`: `"validate-specs"`
- Set `surfaces.specs.status` to `"aligned"` if valid with no errors, `"gaps"` if errors found
- Append to `skill_runs` array: `{"skill": "validate-specs", "ran_at": "<ISO 8601>", "git_head": "<commit>", "surfaces_updated": ["specs"], "summary": "<one-line result>"}`
- Truncate `skill_runs` to last 20 entries
Write the updated manifest.

If manifest doesn't exist, create it with only this skill's entry populated. Other surfaces marked as `"unchecked"`.
