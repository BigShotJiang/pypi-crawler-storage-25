---
name: review-sprint
description: "Verify internal coherence across sprint documents - requirements through plan"
---

# Review Sprint

Verify that a sprint's documents are internally coherent — that each phase builds correctly on the previous one with no gaps, contradictions, or unsupported claims.

## When to Use

- After sprint planning is complete (all docs written)
- Before transitioning to sprint execution
- When a sprint feels "off" but you can't pinpoint why

## Workflow

### Step 1: Load all sprint documents

Read all documents in the sprint directory:
- requirements.md
- research.md
- architecture.md (if present)
- design.md (if present)
- spec.md
- plan.md
- specs/ overlay files (if present)

### Step 2: Requirements → Research traceability

For each requirement in requirements.md:
- Is it addressed in research.md? (investigated, not just repeated)
- Are there research findings with no corresponding requirement? (scope creep or missing requirement)
- Are open questions from requirements answered in research?

Report:
- Requirements with no research coverage
- Research topics with no requirement origin
- Unanswered open questions

### Step 3: Research → Architecture traceability

For each research finding:
- Does architecture.md make decisions informed by it?
- Are there architectural decisions with no research backing? (unsupported assumptions)
- Do constraints discovered in research appear as constraints in architecture?

Report:
- Research findings ignored by architecture
- Architectural decisions with no research basis
- Constraints discovered but not addressed

### Step 4: Architecture → Spec traceability

For each architectural decision:
- Is it reflected in spec.md? (interfaces, contracts, data structures)
- Are there spec items with no architectural basis?
- Do module boundaries in architecture match component boundaries in spec?

Report:
- Architectural decisions not reflected in spec
- Spec items with no architectural justification
- Boundary mismatches

### Step 5: Spec → Plan traceability

For each spec item (interface, contract, data structure):
- Is there a task in plan.md that implements it?
- Are there plan tasks with no spec basis? (undocumented work)
- Do file paths in plan match module structure from architecture?

Report:
- Spec items with no implementation task
- Plan tasks with no spec basis
- File path inconsistencies with architecture

### Step 6: Overlay specs → Plan consistency (if overlay specs exist)

For each entity/endpoint/state in overlay specs:
- Is there a plan task that creates or modifies the corresponding code?
- Do overlay spec field types match what the plan describes?
- Are new dependencies in overlay specs reflected in plan tasks?

Report:
- Overlay spec changes with no plan task
- Plan tasks that should produce overlay spec changes but don't

### Step 7: Internal plan consistency

Check plan.md against the plan-review checklist:
- File operations: no conflicts, no duplicates
- Dependencies: correct phase ordering
- Test coverage: code changes have tests
- Commit boundaries: atomic and testable

This overlaps with the plan-review workflow — run it only if plan-review was not already performed.

## Output Format

```
## Sprint Coherence Review: [Sprint Name]

### Traceability Summary

| Link | Coverage | Gaps |
|------|----------|------|
| Requirements → Research | X/Y covered | list gaps |
| Research → Architecture | X/Y covered | list gaps |
| Architecture → Spec | X/Y covered | list gaps |
| Spec → Plan | X/Y covered | list gaps |
| Overlay Specs → Plan | X/Y covered | list gaps |

### Gaps Found

#### [Gap type]: [Description]
- **Source:** [document and item]
- **Expected in:** [document where it should appear]
- **Impact:** [what breaks if not addressed]
- **Suggested fix:** [specific action]

### Contradictions Found

#### [Contradiction]: [Description]
- **Document A says:** [claim]
- **Document B says:** [conflicting claim]
- **Resolution:** [which is correct, or needs discussion]

### Assessment

- **Coherence:** Strong | Has Gaps | Needs Rework
- **Gaps found:** N
- **Contradictions found:** N
- **Ready for execution:** Yes | No — [reason]
```

## Key Principles

- **Be adversarial** — Look for what's missing, not what's present
- **Trace forward** — Every requirement should flow through to a plan task
- **Trace backward** — Every plan task should trace back to a requirement
- **Flag, don't fix** — Report gaps; don't silently fill them in
- **Specificity over generality** — "Task 3.2 has no spec basis" not "some tasks lack spec coverage"

### Final Step: Update alignment manifest

Read `.organon/alignment-manifest.json`. Update `skill_runs` only (sprint coherence is not a surface):
- Append to `skill_runs` array: `{"skill": "review-sprint", "ran_at": "<ISO 8601>", "git_head": "<git rev-parse HEAD>", "surfaces_updated": [], "summary": "<one-line coherence assessment, e.g. 'Strong coherence, 2 minor gaps found'>"}`
- Truncate `skill_runs` to last 20 entries
Write the updated manifest.

If manifest doesn't exist, create it with only the `skill_runs` entry populated. All surfaces marked as `"unchecked"`.
