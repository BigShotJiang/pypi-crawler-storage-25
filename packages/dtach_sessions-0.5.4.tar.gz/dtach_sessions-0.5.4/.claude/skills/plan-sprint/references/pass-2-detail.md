# Pass 2: Detail

Expand the phase structure from Pass 1 into a complete plan.md with full task metadata. This is Pass 2 of three-pass planning.

## When to Use

- After Pass 1 (Structure) has produced an approved phase structure
- The phase structure is either in the conversation history or saved in a file

## Prerequisites

- Sprint exists with documents (requirements.md, spec.md, architecture.md at minimum)
- Phase structure from Pass 1 is available (approved by user)
- Sprint status is Created or Next

## Workflow

### Step 1: Load inputs

1. **Read the plan template:** `defaults/templates/files/sprints/plan.md`
   - Note the required sections: `## Overview`, `## Workflow`, `## Tasks`, `## Completion Criteria`
   - Note the exact heading hierarchy: `## Tasks` > `### Phase N:` > `#### Task N.M:`
   - Note all required task fields: Type, Status, Dependencies, Files, Context, Description, Commit

2. **Read the phase structure** from Pass 1 (in conversation history or file)

3. **Read sprint documents** for context on file paths, interfaces, and scope:
   - `kickoff.md` (if exists)
   - `requirements.md`
   - `research.md`
   - `architecture.md`
   - `spec.md`

4. **Collect task types** from the phase structure and read corresponding workflow definitions from `defaults/definitions/workflows/` for any types that need guidance (implement, test, document, etc.)

### Step 2: Expand each task

For each high-level task in the phase structure, create a full task entry:

```markdown
#### Task N.M: <Title>

- **Type:** implement | test | document | research | design | specify | debug | refactor | review
- **Status:** pending
- **Dependencies:** none | [N.K, N.J] | [Phase N]
- **Files:**
  - Create: <exact/path/to/new/file>
  - Modify: <exact/path/to/existing/file>
  - Delete: <exact/path/to/removed/file>
- **Context:** [spec.md§Section Name](spec.md#section-name), [architecture.md§Section](architecture.md#section)
- **Description:** <What this task accomplishes — one or two sentences>
- **Commit:**
```

Rules for expansion:
- **File paths must be exact.** Use real paths from the codebase, not placeholders. Check architecture.md and spec.md for module structure.
- **Dependencies must reference real task IDs.** Use `[N.M]` format for task dependencies, `[Phase N]` for phase dependencies, or `none`.
- **Context links must use proper markdown.** Format: `[doc.md§Section](doc.md#anchor)` pointing to sprint doc sections.
- **One task = one commit boundary.** Each task should be a single atomic, testable commit.
- **Create before import.** If task B imports from task A's file, B must depend on A.
- **Include `__init__.py` files.** Every new Python package directory needs one.
- **Tests reference code.** Test tasks must depend on the implementation tasks they test.

### Step 3: Write plan.md

Write the complete plan.md in the sprint directory following the template structure exactly:

```markdown
# Implementation Plan: <Sprint Name>

**Created:** <today's date>
**Started:** [Date when sprint execution begins]
**Sprint:** <Sprint Name> (number assigned when started)

## Overview

<Brief summary of sprint goals and deliverables — 2-4 sentences>

## Workflow

This sprint follows the workflow-task model:
- Planning Level: Research → Design → Spec → Plan (this document)
- Development Level: Implement → Test → Review → Document

## Tasks

### Phase 1: <Name>

**Status:** pending
**Dependencies:** none

#### Task 1.1: <Title>
...

## Completion Criteria

This sprint is complete when:

- [ ] All tasks completed with commit hashes
- [ ] All tests passing
- [ ] Documentation complete
- [ ] Sprint status updated to Completed

## Notes

<Task format reference, orchestration notes>
```

### Step 4: Verify structural compliance

Before finishing, verify the written plan.md against the template:

- [ ] `## Overview` section exists and is not empty
- [ ] `## Workflow` section exists
- [ ] `## Tasks` section exists with `### Phase` subsections
- [ ] Every task uses `#### Task N.M:` heading format
- [ ] Every task has all required fields: Type, Status, Dependencies, Files, Context, Description, Commit
- [ ] `## Completion Criteria` section exists with checkboxes
- [ ] Task IDs are sequential within phases (1.1, 1.2, ... 2.1, 2.2, ...)
- [ ] All Status fields are `pending`
- [ ] All Commit fields are empty

Fix any violations before reporting.

### Step 5: Report

Report to the user:
- Plan written to: `.organon/sprints/<Name>_Created/plan.md`
- Total phases and tasks
- Any concerns about scope or complexity
- Proceed to Pass 3 (Review) to validate the plan before execution.

## Output

- Complete plan.md written to the sprint directory
- Structurally compliant with the plan template
- Ready for Pass 3 validation
