# Pass 3: Review

Validate a completed plan.md against the plan-review checklist. This is Pass 3 of three-pass planning — the final gate before execution.

## When to Use

- After Pass 2 (Detail) has written plan.md
- Before transitioning to sprint execution
- When a plan has been manually written and needs validation

## Prerequisites

- Sprint exists with a complete plan.md
- Sprint status is Created, Planned, or Next

## Workflow

### Step 1: Load inputs

1. **Read the plan-review workflow:** `defaults/definitions/workflows/plan-review.md`
2. **Read the completed plan.md** from the sprint directory
3. **Read the plan template:** `defaults/templates/files/sprints/plan.md`
4. **Read sprint documents** for cross-reference validation:
   - `requirements.md`, `spec.md`, `architecture.md`

### Step 2: Run review checks

Read `references/review-checklist.md` for the full checklist with 8 categories:
structural compliance, file operations, test coverage, documentation,
dependency order, commit boundaries, completeness, and scope.

Run each check against plan.md. Record pass/fail with specific issue locations.

### Step 3: Report and fix

Present results:

```markdown
## Plan Review Results

**Sprint:** <name>
**Reviewed:** <today's date>

### Issues Found

#### [Category]: [Description]
- **Location:** Task N.M or Phase N
- **Problem:** <what's wrong>
- **Fix:** <specific action to take>

### Summary

| Check | Result |
|-------|--------|
| Structural compliance | Pass/Fail (N issues) |
| File operations | Pass/Fail (N issues) |
| Test coverage | Pass/Fail (N issues) |
| Documentation | Pass/Fail (N issues) |
| Dependency order | Pass/Fail (N issues) |
| Commit boundaries | Pass/Fail (N issues) |
| Completeness | Pass/Fail (N issues) |
| Scope | Pass/Fail (N issues) |

**Total issues:** N
**Blocking issues:** N (must fix before execution)
**Warnings:** N (should fix, not blocking)
```

If issues exist:
1. Present each issue with its proposed fix
2. Ask user to confirm fixes
3. Apply fixes to plan.md
4. Re-run the failed checks to verify fixes

### Step 4: Mark plan as reviewed

After all issues are resolved (or user accepts warnings), append to plan.md:

```markdown
## Plan Review

**Reviewed:** <today's date>

- [x] Structural compliance verified
- [x] File operations reviewed (no conflicts)
- [x] Test coverage reviewed (all code has tests)
- [x] Documentation reviewed (all changes documented)
- [x] Dependencies reviewed (correct order, no circular deps)
- [x] Commit boundaries reviewed (atomic commits)
- [x] Completeness reviewed (no missing steps)
- [x] Scope reviewed (estimates realistic)

**Plan Status:** Ready for implementation
```

### Step 5: Transition

Report: plan review complete, issues resolved, suggest sprint execution.
