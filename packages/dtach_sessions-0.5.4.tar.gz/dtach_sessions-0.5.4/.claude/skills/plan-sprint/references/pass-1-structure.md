# Pass 1: Structure

Produce a phase structure from sprint documents. This is Pass 1 of three-pass planning: organize work into logical phases with high-level tasks, without writing full task detail.

## When to Use

- After sprint documents are written (requirements.md, research.md, architecture.md, spec.md)
- As the first step of plan creation
- Before Pass 2 (Detail)

## Prerequisites

- Sprint exists (check with `list_sprints()` or search `.organon/sprints/`)
- At minimum, requirements.md and spec.md exist in the sprint directory
- Sprint status is Created or Next

## Workflow

### Step 1: Identify the sprint

If the user specifies a sprint, use it. Otherwise:
- Call `list_sprints()` to find active sprints
- If multiple Created/Next sprints exist, ask the user which one
- Read the sprint directory path

### Step 2: Read sprint documents

Read all available documents in the sprint directory, in order:

1. `kickoff.md` (if exists) — context, decisions, scope
2. `requirements.md` — stakeholder needs, success criteria
3. `research.md` — technical landscape, existing patterns
4. `design.md` (if exists) — UI/UX decisions
5. `architecture.md` — structure, module organization
6. `spec.md` — contracts, interfaces, data structures

Note which documents are missing — these gaps may affect plan quality.

### Step 3: Identify work units

From the sprint documents, identify the major logical work units:

- Each significant module, component, or feature is a candidate phase
- Group related work: creation of a module + its tests + its docs can be one phase, or split if large
- Consider natural ordering: foundation before features, features before integration, integration before polish
- Look for explicit phase suggestions in architecture.md or spec.md

### Step 4: Produce phase structure

For each phase, write:

```markdown
### Phase N: <Name>

**Goal:** <One sentence describing what this phase accomplishes>
**Dependencies:** none | [Phase M, Phase K]

Tasks:
- <Task description> (type: implement)
- <Task description> (type: implement)
- <Task description> (type: test)
- <Task description> (type: document)
```

Rules:
- Phase names should be descriptive: "Core Parser", "CLI Integration", "Test Coverage" — not "Phase 1", "Setup"
- Each task is one line with a type tag
- Task types: implement, test, document, research, design, specify, plan, debug, refactor, review
- Include test tasks for each implementation phase
- Include documentation tasks where user-facing changes occur
- Mark phase dependencies explicitly
- Order phases so dependencies flow forward (no phase depends on a later phase)

### Step 5: Review for completeness

Before presenting, verify:

- [ ] Every requirement from requirements.md maps to at least one task
- [ ] Every spec item from spec.md maps to at least one task
- [ ] Every implementation task has a corresponding test task (same phase or later)
- [ ] Documentation tasks exist for user-facing changes
- [ ] Phase dependencies form a DAG (no circular dependencies)
- [ ] No phase has more than 10-12 tasks (split if larger)

### Step 6: Present for review

Present the phase structure to the user. Do NOT write plan.md yet.

Report:
- Number of phases and total tasks
- Any sprint documents that were missing
- Any requirements or spec items that were difficult to map
- Suggested changes or concerns about scope

Wait for user feedback. Iterate on the structure if needed.

After approval, proceed to Pass 2 (Detail) to expand this into a full plan.md with task metadata.

## Output

- Phase structure with high-level tasks presented to the user (not written to a file)
- Ready for Pass 2 to expand into full plan.md
