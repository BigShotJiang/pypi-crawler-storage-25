# Spec Awareness

During sprint planning, load existing project specs, identify which specs are affected by the planned work, author overlay YAML files, and validate with merge preview.

## Workflow

1. **Load existing specs**:
   - Read specs from `.organon/specs/` using SpecParser
   - Or use `preview_spec_merge` MCP tool to understand current spec state
   - List all spec types: models, states, contracts, workflows, invariants

2. **Identify affected specs**:
   - Based on sprint requirements, determine which existing specs will change
   - Identify new specs that need to be created
   - Map planned features to spec types:
     - New entities/fields -> model specs
     - New states/transitions -> state specs
     - New API endpoints -> contract specs
     - New user flows -> workflow specs
     - New business rules -> invariant specs

3. **Author overlay YAML**:
   - Create `specs/` directory in sprint directory
   - Write overlay YAML files with only the changes (additions/modifications)
   - Follow naming convention: `{name}.{type}.yaml`
   - Include only changed/new elements, not the entire base spec

4. **Validate with preview**:
   - Run `organon admin merge-preview` or `preview_spec_merge` MCP tool
   - Verify additions and modifications are correct
   - Check for unintended conflicts
   - Verify cross-references are valid

5. **Iterate**:
   - Fix any conflicts or reference errors in overlay YAML
   - Re-run preview until clean
   - Document spec changes in sprint architecture/design docs

### Final Step: Update alignment manifest

Read `.organon/alignment-manifest.json`. Update the `surfaces.specs` entry:
- Set `surfaces.specs.last_checked` to current ISO 8601 timestamp
- Set `surfaces.specs.git_head` to current `git rev-parse HEAD`
- Set `surfaces.specs.status` to `"gaps"` (overlay specs created but not yet merged)
- Append to `skill_runs` array: `{"skill": "plan-with-specs", "ran_at": "<ISO 8601>", "git_head": "<commit>", "surfaces_updated": ["specs"], "summary": "<one-line result>"}`
- Truncate `skill_runs` to last 20 entries
Write the updated manifest.

If manifest doesn't exist, create it with only this skill's entry populated. Other surfaces marked as `"unchecked"`.

## When to Use

- During sprint planning phases (requirements, architecture, design)
- When planning features that affect domain models, APIs, or workflows
- To ensure planned work is consistent with existing specifications

## Spec File Naming

```
sprint-dir/specs/
  checkout.model.yaml      # Domain model changes
  order.states.yaml        # State machine changes
  api.contracts.yaml       # API contract changes
  checkout.workflow.yaml   # Workflow changes
  order.invariants.yaml    # Invariant changes
```
