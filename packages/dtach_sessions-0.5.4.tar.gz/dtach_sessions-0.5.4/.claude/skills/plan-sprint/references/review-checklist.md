# Plan Review Checklist

Run each check against plan.md. Report pass/fail with specific issue locations.

## Structural Compliance

- [ ] Required sections exist: `## Overview`, `## Workflow`, `## Tasks`, `## Completion Criteria`
- [ ] Heading hierarchy: `## Tasks` > `### Phase N: Name` > `#### Task N.M: Title`
- [ ] Every task has all required fields: Type, Status, Dependencies, Files, Context, Description, Commit
- [ ] Task IDs are sequential (1.1, 1.2, ... 2.1, 2.2, ...)
- [ ] All Status fields are `pending`
- [ ] All Commit fields are empty
- [ ] Completion Criteria has `[ ]` checkboxes

## File Operations

- [ ] No file created in multiple tasks (duplicates)
- [ ] No file deleted then referenced by a later task
- [ ] No file both created and modified in the same task (should be just Create)
- [ ] Every new Python package directory has `__init__.py` planned
- [ ] All imports reference files that exist or are created by earlier tasks

How: List all Create, Modify, Delete operations. Check for overlaps and ordering conflicts.

## Test Coverage

- [ ] Every Create/Modify of a `.py` source file has a corresponding test file Create/Modify
- [ ] No test references code from a task that hasn't completed yet (dependency check)
- [ ] Test tasks depend on their corresponding implementation tasks

How: List all code file operations. For each, verify a matching test file operation exists.

## Documentation

- [ ] New modules have documentation tasks planned
- [ ] New CLI commands or MCP tools have reference doc updates planned
- [ ] Changes to project structure plan STRUCTURE.md update
- [ ] Changes to agent guidance plan CLAUDE.md update

How: List all new user-facing or agent-facing features. Verify documentation tasks exist.

## Dependency Order

- [ ] No phase uses code from a later phase
- [ ] Within each phase, tasks are ordered logically (create before modify, code before tests)
- [ ] No circular dependencies between tasks
- [ ] Phase dependencies form a DAG
- [ ] Dependencies match module structure from architecture.md

How: Build a dependency graph from task Dependencies fields. Verify it is a DAG.

## Commit Boundaries

- [ ] Each task forms a cohesive, atomic unit of work
- [ ] No partial features split across unrelated tasks
- [ ] Each task's tests could pass after that task completes
- [ ] Unrelated changes are in separate tasks

## Completeness

- [ ] Every requirement from requirements.md maps to at least one task
- [ ] Every spec item from spec.md maps to at least one task
- [ ] No tasks reference nonexistent sprint doc sections in Context fields
- [ ] `__init__.py` files included for new packages
- [ ] New dependencies added to pyproject.toml if needed
- [ ] Configuration changes planned if needed
- [ ] Error handling considered

## Scope

- [ ] No phase has more than 10-12 tasks (suggest splitting)
- [ ] Total task count is realistic for the sprint scope
- [ ] Dependencies don't create an unnecessarily long critical path
