---
name: plan-sprint
description: "Three-pass sprint planning — structure phases, detail tasks, validate plan — with spec awareness"
---

# Plan Sprint

Create a structured implementation plan for a sprint through three passes: structure (organize work into phases), detail (expand tasks with metadata), and review (validate plan). Each pass runs in a subagent with clean context.

## Prerequisites

- Sprint exists (check with `list_sprints()` or search `.organon/sprints/`)
- At minimum, requirements.md and spec.md exist in the sprint directory
- Sprint status is Created or Next

## Workflow

### Step 0: Load specs for awareness

If `.organon/specs/` exists and contains spec files, read `references/spec-awareness.md` and follow its workflow:
1. Load existing specs from `.organon/specs/`
2. Identify which specs will be affected by the planned work
3. Prepare overlay YAML awareness for the planning passes

This context feeds into all three passes so they account for spec impacts.

### Step 1: Pass 1 — Structure

**Goal:** Organize work into logical phases with high-level tasks.

Launch a subagent with instructions to read `references/pass-1-structure.md` and execute it against the sprint directory.

The subagent:
1. Reads all sprint documents (kickoff.md, requirements.md, research.md, design.md, architecture.md, spec.md)
2. Identifies major work units
3. Produces a phase structure with high-level tasks and type tags
4. Presents the structure for review

**Parent review:** Confirm phase breakdown makes sense, adjust scope if needed.

### Step 2: Pass 2 — Detail

**Goal:** Expand high-level tasks into structured tasks with explicit metadata.

Launch a subagent with instructions to read `references/pass-2-detail.md` and execute it against the sprint directory, using the approved phase structure from Pass 1.

The subagent:
1. Loads planning rules from `defaults/definitions/workflows/`
2. For each high-level task, creates structured task entries with: Type, Status, Dependencies, Files, Context, Description, Commit
3. Writes complete plan.md to the sprint directory

**Parent review:** Confirm task granularity, file operations, and dependencies.

### Step 3: Pass 3 — Review

**Goal:** Validate plan for conflicts, dependencies, completeness, and template compliance.

Launch a subagent with instructions to read `references/pass-3-review.md` and execute it against the sprint directory.

The subagent:
1. Checks template compliance against `defaults/templates/files/sprints/plan.md`
2. Reads review checklist from `references/review-checklist.md`
3. Validates: file operations, test coverage, documentation, dependencies, commit boundaries, completeness, scope, format
4. Fixes any issues found
5. Marks plan as reviewed

**Parent review:** Confirm review findings are addressed.

## Subagent Invocation Pattern

Each pass runs in a fresh subagent with clean context. This avoids context pollution from the broader planning conversation:

```
Parent conversation (has full user context)
  |
  |-- launches subagent: "Read references/pass-1-structure.md and execute for sprint X"
  |     Subagent loads reference doc, reads sprint docs, writes output, returns
  |     Parent reviews output with user
  |
  |-- launches subagent: "Read references/pass-2-detail.md and execute for sprint X"
  |     Subagent loads reference doc, reads phase structure + sprint docs, writes plan.md, returns
  |     Parent reviews output with user
  |
  |-- launches subagent: "Read references/pass-3-review.md and execute for sprint X"
  |     Subagent loads reference doc, reads plan.md, validates, fixes issues, returns
  |     Parent reviews output with user
  |
  v
  Transition to sprint execution
```

## Output

- Complete, validated plan.md in the sprint directory
- All tasks have explicit metadata (Type, Dependencies, Files, Context)
- Plan passes review checklist
- Ready for sprint execution
