---
name: derive-views-from-specs
description: "Derive state machine and architecture views from specs — no source code access"
---

# Derive State and Architecture Views from Specs

Analyze spec files and project structure to produce derived views:
a **state spec** (joint cross-entity state machines from workflows) and an
**architecture view** (runtime topology from decisions, structure, contracts,
and models).

These derived docs are verification artifacts — "here's what we inferred from
the specs and project structure, does it look right?" They are persisted in
git for versioning and diff-based review.

## Input

Read from `.organon/specs/` (the standard location per CLAUDE.md File Locations):
- `.workflow.yaml` files (at least one required)
- `.model.yaml` files for referenced entities
- `*.decisions.md` for tech stack and architecture choices
- Contract/API spec files (`openapi.json`, `openapi.yaml`)
- `.organon/STRUCTURE.md` for project directory layout

Output to `.organon/specs/derived/`.

## Constraints

**CRITICAL: You must NOT read any application source code.**

You have access to ONLY:
1. The spec files in `.organon/specs/`
2. `.organon/STRUCTURE.md` (project directory layout)
3. General knowledge of the tech stack if a decisions doc is present

If information is missing from the specs, add a `# SPEC GAP: <description>`
comment in the derived doc. These gaps tell us what's missing from the
source materials.

## Workflow

### Step 1: Read all source materials

Read every file in `.organon/specs`:
- Parse `.workflow.yaml` files — three formats may appear:
  - **Unified** (`steps:` list): each step may have `state_change: {from, to}` and `api:` section
  - **Legacy state-machine** (`states:` + `transitions:`): explicit state machine
  - **Legacy query** (`operations:` list): stateless API operations
- Parse `.model.yaml` files — understand entity fields, status values, relationships
- Parse `.contract.yaml` or `openapi.*` files — understand API surface

Read project-level files:
- Decisions markdown (e.g., `docs/decisions.md`, `.organon/dev-docs/decisions.md`) — tech stack, architecture choices
- `.organon/STRUCTURE.md` — project directory layout and component organization

### Step 2: Derive State Spec

Identify **joint cross-entity state machines** from workflow specs. The goal is to
capture coordinated state transitions across multiple entities — not per-model
status enums (those belong in the model spec).

**Discovery depends on workflow format:**

**Unified format** (`steps:`): scan each step's `state_change:` field. Collect all
`from` and `to` values. The workflow's `entity:` and `field:` frontmatter tell you
which entity and field these states belong to.

**Legacy state-machine format** (`states:` + `transitions:`): use `states:` directly
as state values, `transitions:` as the state machine edges.

**Legacy query format** (`operations:`): no state transitions — skip for state derivation.

**For each entity with state-carrying fields:**

1. Collect all state values from the workflow (from state_change, states, or transitions)
2. Build a state machine:
   - **States**: all unique values (include `(none)` or `null` for existential lifecycles)
   - **Transitions**: each step with `state_change` (or each legacy transition) defines an edge
   - **Trigger**: the step name or API call that causes the transition
   - **Initial state**: the `default` value from the model spec if declared; otherwise,
     infer from the workflow — a state that appears only as `from` in the first step
     but never as any step's `to` is a candidate initial state. For existential
     lifecycles, `(none)` or `null` is the initial state.
   - **Terminal states**: states that appear as `to` but never as `from` in any
     forward-progressing step
3. Cross-reference with the model spec: if the model declares a `values` list for
   this field, identify any values that don't appear in any workflow (orphan states)
4. **Group entities that co-transition.** When a single step changes state on
   multiple entities simultaneously, group them — capture illegal joint states

Write the state spec using the template from `.organon/defaults/templates/files/specs/derived/state.md`. All `derived_from` paths must be relative to the `derived/` directory (use `../` prefix).

### Step 3: Derive Architecture View

Synthesize a runtime topology from four sources:

1. **Decisions doc** — tech stack choices, framework selections, architectural patterns
2. **STRUCTURE.md** — project directory layout showing components and their organization
3. **Contract/API spec** — endpoints, protocols, communication interfaces
4. **Model specs** — data entities, their relationships, storage implications

**Generate the architecture view covering:**

- **System Overview** — one paragraph: what this system is and does
- **Services & Components** — each service/component: name, responsibility, technology, home directory
- **Communication** — how services talk: HTTP, WebSocket, message queues, shared DB, etc.
- **Data Flow** — how data moves through the system for key workflows
- **Deployment** — how the system is deployed: containers, cloud services, infrastructure

Write the architecture view using the template from `.organon/defaults/templates/files/specs/derived/architecture.md`. All `derived_from` paths must be relative to the `derived/` directory (use `../` prefix).

### Step 3b: Derive User Stories

Project user stories from workflow specs. Each workflow becomes one or more stories
that describe what a user does and why.

**For each workflow spec:**

1. Read the workflow's `entity:`, `field:`, and `steps:` (or legacy `transitions:`/`operations:`)
2. Construct a user story:
   - **Actor**: infer from the API pattern (admin, user, system) or use "user" as default
   - **Action**: the workflow's primary purpose (create, process, search, manage)
   - **Outcome**: what the user achieves when the workflow completes
   - **Steps**: map each workflow step to a numbered narrative step with its endpoint
   - **Preconditions**: from step `preconditions:` fields
   - **Endpoints used**: all `api.path` values from steps

3. Query workflows may produce multiple stories (e.g., search → "find documents",
   "refine search results", "paginate through results")

Write the user-stories view using the template from
`.organon/defaults/templates/files/specs/derived/user-stories.md`.

**Preserve the Developer Stories section** — only overwrite the Generated Stories section.
If the file exists, read it first and keep everything after `## Developer Stories`.

### Step 4: Compute source hashes and write derived files

Create the `derived/` directory if needed.

For each derived file (state, architecture, user-stories):

1. **Decide the `derived_from` file list** — the source files this view was built from.
   Use paths relative to `derived/` (with `../` prefix).

2. **Check freshness first.** If the derived file already exists, read its
   `source_hash` and recompute from the current source files. If hashes match,
   **skip regeneration** — the derived view is still fresh. Report it as skipped.

3. **Compute the hash BEFORE writing the file.** Run:
   ```bash
   python3 .organon/defaults/scripts/specs/compute_source_hash.py <file1> <file2> ...
   ```
   Pass the **absolute or working-directory-relative paths** to the actual source files
   (e.g., `.organon/specs/document.model.yaml`), in the same order as `derived_from`.
   Capture the 16-character hex output — this is the `source_hash` value.

4. **Write the derived file** with the computed `source_hash` in the frontmatter.

This order matters: if you write the file first with a placeholder hash and
then compute it, you'll forget to update it or get the wrong value. Compute
first, write once.

### Step 5: Report

**Drift check:** Read the alignment manifest's `surfaces.specs.git_head` and
compare to current `git rev-parse HEAD`. If they match, report: "No code
changes since spec generation — SPEC GAPs indicate generate-specs missed
something (SPEC-SKILL gaps)." If code changed: "Code changed since spec
generation — SPEC GAPs may indicate genuine drift."

Summarize:
- Drift check result
- Number of entity groups, states, and transitions in each state machine
- Any illegal joint states identified
- Architecture view: number of services/components, communication patterns
- User stories: number of stories generated, number of developer-authored stories preserved
- Any orphan states (in model but not in any workflow)
- Any SPEC GAP comments (with drift attribution)
- Any inconsistencies found (e.g., unreachable states, transitions with no matching step)

### Final Step: Update alignment manifest

Read `.organon/alignment-manifest.json`. Update the relevant surface entry:
- Set `surfaces.specs.last_checked` to current ISO 8601 timestamp
- Set `surfaces.specs.git_head` to current `git rev-parse HEAD`
- Update `surfaces.specs.checks.derived` with this run's results:
  - `state_count`: number of `*.state.md` files written
  - `state_fresh`: boolean — true if source_hash matches current workflow content
  - `architecture_exists`: boolean — true if architecture view was written
  - `architecture_fresh`: boolean — true if source_hash matches current source content
  - `user_stories_exists`: boolean — true if user-stories view was written
  - `user_stories_fresh`: boolean — true if source_hash matches current workflow content
  - `last_derived`: current ISO 8601 timestamp
- Append to `skill_runs` array: `{"skill": "derive-views-from-specs", "ran_at": "<ISO 8601>", "git_head": "<commit>", "surfaces_updated": ["specs"], "summary": "<one-line result>"}`
- Truncate `skill_runs` to last 20 entries
Write the updated manifest.

If manifest doesn't exist, create it with only this skill's entry populated. Other surfaces marked as `"unchecked"`.
