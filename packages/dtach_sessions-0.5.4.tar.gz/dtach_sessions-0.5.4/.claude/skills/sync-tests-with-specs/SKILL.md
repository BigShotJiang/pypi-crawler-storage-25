---
name: sync-tests-with-specs
description: "Synchronize tests with specs — generate if missing, run if present, classify and fix gaps"
---

# Sync Tests with Specs

Ensure tests reflect the current specs. Three phases run in sequence: generate tests if missing, run tests if present, analyze and fix gaps if failures found.

## Decision Logic

1. Check `.organon/tests/` for existing test files.
2. **No tests exist** → Phase 1 (generate from specs).
3. **Tests exist** → Phase 2 (run tests).
4. **Tests failed or SPEC GAP comments found** → Phase 3 (analyze and fix gaps).

If specs don't exist, stop and suggest `/sync-specs-with-code` first.

---

## Phase 1: Generate Tests from Specs

Generate pytest integration tests from specification files only. Tests validate
that code implements what specs describe. Reading source code or existing tests
would make tests track implementation instead of specs — they would stop
detecting drift between the two surfaces.

### Constraints

**No reading source code.** Tests derived from specs detect when code drifts
from the spec. Tests derived from code just confirm what code already does.

**No reading existing tests.** Each generation is a clean projection from specs.
When tests fail, Phase 3 classifies whether the spec, code, or skill
needs fixing — then you regenerate clean.

**No hardcoded URLs or credentials.** Tests run in CI where endpoints and auth
come from environment variables. Use `os.environ["TEST_BASE_URL"]` or the
`base_url` conftest fixture. This applies to ALL HTTP clients including
unauthenticated ones in security tests.

**No per-file fixture duplication.** Shared fixtures (`client`, `base_url`)
belong in `conftest.py` only. Test files consume them via pytest injection.

**Spec gaps are feedback, not errors.** When information is missing from specs,
add `# SPEC GAP: <description>` and make your best assumption. These gaps
improve future spec quality.

### Incremental Mode

When the user says "incremental" or specs have `source_hash` fields, use
incremental test generation. This regenerates only tests for specs that changed.

#### How incremental works

1. **Check for existing tests** in `.organon/tests/`. If none exist, fall through
   to full generation.

2. **Identify changed specs.** For each `.workflow.yaml` and `.model.yaml` in
   `.organon/specs/`, read the `source_hash` field and recompute from the source
   file:
   ```bash
   python3 .organon/defaults/scripts/specs/compute_source_hash.py <source_file>
   ```
   If the stored hash matches the current hash, the spec hasn't changed.

3. **Determine which tests to regenerate:**
   - If a **workflow spec** changed → regenerate its `test_<workflow_id>.py`
   - If a **model spec** changed → regenerate tests for all workflows referencing
     that entity (check workflow `entity:` frontmatter)
   - If **contract** (`openapi.json`) changed → regenerate all tests (response
     schemas are shared across all test assertions)
   - If **invariants, decisions, or quality** changed → regenerate all tests
     (these are cross-cutting)
   - If nothing changed → report "all tests current" and exit

4. **Delete only affected test files** (not the whole directory). Keep `conftest.py`
   unless fixtures need updating (model change or contract change).

5. **Read specs and generate** only the affected test files, following the same
   rules as full generation.

6. **Validate and report** as usual, noting which tests were regenerated vs skipped.

#### When to use full vs incremental

- **Full:** First generation (no tests exist), after major spec overhaul, when cross-cutting specs
  changed, periodic ground-truth pass
- **Incremental:** Default when tests already exist — during active development after `/sync-specs-with-code` incremental run

### Workflow (Full Generation)

1. **Clean previous output.** Delete `.organon/tests/` if it exists. Every run
   is a clean projection from specs — previous tests must not be read into
   context where they contaminate output.
   ```bash
   rm -rf .organon/tests/
   ```

2. **Read all spec files** from `.organon/specs/`:
   - `.workflow.yaml` — blocks, compositions, entry/exit states, API calls
   - `.model.yaml` — entity fields, types, status values
   - `.invariants.yaml` — cross-cutting rules all tests should validate
   - `*.decisions.md` — tech stack, lifecycle phase, test framework, async patterns
   - `*.quality.md` — performance budgets, SLA targets, security requirements
   - `openapi.json` — request/response schemas, endpoint details

3. **Extract test environment config** from workflow spec `test_environment`
   section: `base_url`, `auth`, `fixtures`, `polling`, `cleanup`. Use these
   values directly — do not guess configuration when the spec provides it.

4. **Resolve dependencies.** If workflows have `depends_on` sections, read
   `references/dependency-fixtures.md` for the verify-then-fallback pattern.

5. **Map workflows to tests.** Three formats may appear — handle all:

   **Unified format** (has `steps:`):
   - Each step with `api:` becomes an HTTP call
   - Steps with `state_change:` assert the state transition occurred
   - Steps without `state_change:` are queries — assert on response content
   - `preconditions:` tell you what fixtures to set up first
   - Test both happy path (full step sequence) and error cases

   **Legacy state-machine format** (has `states:` + `transitions:`):
   - Each transition with an API trigger becomes an HTTP call
   - Entry/exit states become assertions
   - Guard conditions become separate error-response tests

   **Legacy query format** (has `operations:`):
   - Each operation becomes a test that sets up known DB state via fixtures,
     calls the endpoint, and asserts on the response
   - Preconditions in the operation tell you what fixtures to create first
   - Test both positive cases (data exists, query matches) and empty cases
     (no matches, empty collection)

6. **Build assertions from contracts.** If `openapi.json` exists, read
   `references/contract-assertions.md` for status codes, required parameters,
   required body fields, and coverage checks.

   **The contract is authoritative for response shapes.** When a workflow
   step describes a response and `openapi.json` also defines a schema for
   that endpoint, use the contract's schema for test assertions — not the
   workflow description. The workflow says what happens; the contract says
   the exact field names, types, and structure. Match the endpoint by
   method + path, then read the response schema for that status code.

7. **Build assertions from quality specs.** If `*.quality.md` exists, read
   `references/quality-assertions.md` for performance, SLA, and security tests.

8. **Write test files** to `.organon/tests/` as `test_<workflow_id>.py` with
   conftest.py for shared fixtures. Include file header:
   ```python
   """Integration tests for <workflow name>.
   Generated from: <workflow file> on <date>
   Spec gaps marked with # SPEC GAP comments.
   """
   ```

9. **Validate.** Run: `python .organon/defaults/scripts/tests/validate_tests.py .organon/tests/`
   If validation fails, fix issues and re-validate.

10. **Report** results: compositions tested, SPEC GAP count with details,
   contract coverage (X/Y endpoints), quality assertions added.

### Test Style

- pytest by default; use decisions doc framework if specified
- `httpx` or `requests` per decisions doc tech stack
- Async patterns from decisions doc (pytest-asyncio if asyncio specified)
- Names: `test_<composition_name>`
- HTTP-only — never import application code
- Bounded retry loops with timeout for polling blocks
- All shared fixtures in conftest.py

### Example

Given a workflow step:
```yaml
steps:
  - name: register-file
    api:
      method: POST
      path: /api/documents
      request:
        body:
          file_path: "{file_path}"
          process: false
      response:
        status: 201
        body:
          document.status: registered
    state_change:
      from: (none)
      to: registered
```

Generate:
```python
response = client.post("/api/documents", json={
    "file_path": file_path,
    "process": False,
})
assert response.status_code == 201
data = response.json()
assert data["document"]["status"] == "registered"
document_id = data["document"]["id"]
```

After generation, proceed to Phase 2.

---

## Phase 2: Run Tests

Execute integration tests in `.organon/tests/` against the project's
services. Reads `services.yaml` for service definitions — the project
declares how to start/stop services, this skill executes those commands.

### Step 1: Check for tests

Look for test files in `.organon/tests/`. If none exist, report
"No tests found" and run Phase 1 (generate).

### Step 2: Read service definitions

Read `.organon/specs/services.yaml`. This file defines every service
the tests need — start command, stop command, health check URL, required
env vars, and port.

If `services.yaml` doesn't exist, report:
"No service definitions found. Run `/sync-specs-with-code` to create
.organon/specs/services.yaml, or create it manually from the template
at .organon/defaults/templates/files/specs/services.yaml."

### Step 3: Check environment variables

For each service in services.yaml, check that required env vars are set.
Report any missing vars. If critical vars are missing (e.g., database URL),
warn but continue — the service's start command may set them.

### Step 4: Start services

For each service in services.yaml, in order:

1. **Check if already running** — hit the health check URL. If healthy
   and it's the correct app (response contains `health.expect` string),
   mark as "already running" and skip to next service.

2. **Check port conflict** — if the health check fails but the port is
   in use (different app), report the conflict and stop. Don't start
   a service on a port that's already occupied by something else.

3. **Start the service** — run the `start` command from the project root
   as a background process. Capture PID.
   ```bash
   cd <project_root> && <service.start> &
   SERVICE_PID=$!
   ```

4. **Wait for healthy** — poll `health.url` every `health.interval`
   seconds, up to `health.timeout` seconds. If it doesn't come up,
   kill the process and report startup failure with any stderr output.

5. **Verify correct app** — confirm the health response contains
   `health.expect`. If not, kill the process and report that the
   wrong application started.

Record PIDs of services this skill started (not pre-existing ones).

### Step 5: Pre-flight report

Before running tests, report:
- Services status (started by skill vs already running)
- Health check results per service
- Env vars: set vs missing
- `TEST_BASE_URL` value being used

### Step 6: Run tests

Set `TEST_BASE_URL` from the first service's health URL (or from env
if already set). Run:
```bash
TEST_BASE_URL=<url> pytest .organon/tests/ -v
```

Capture full output.

### Step 7: Tear down

For each service this skill started (has a PID), in reverse order:

1. If the service has a `stop` command, run it
2. If no `stop` command, kill the process and its children
3. Verify the port is released

Services that were already running before Step 4 are left untouched.

### Step 8: Report results

Report:
- Total tests, passed, failed, skipped, errors
- For each failure: test name, assertion that failed, actual vs expected
- **Drift check:** Compare the manifest's `surfaces.specs.git_head` to
  current HEAD. If they match, state: "No code changes since spec generation
  — all failures are skill gaps (SPEC-SKILL or TEST-SKILL)." If code
  changed, state: "Code changed since spec generation — failures may be
  genuine drift."

**CRITICAL: Do NOT modify test files.** Tests in `.organon/tests/` are
generated artifacts. If tests fail, the fix goes into specs or the skill,
not the test files. Report failures and proceed to Phase 3.

If all tests pass and no SPEC GAP comments exist, skip Phase 3.

---

## Phase 3: Analyze and Fix Gaps

Collect and classify specification gaps surfaced by test generation,
derivation, and contract/workflow cross-referencing. Classify each gap by
**where the fix goes** — not what's abstractly wrong. Produce a structured
report for human review, then fix approved skill gaps with user confirmation.

### Step 0: Drift check

Before collecting or classifying any gaps, determine whether code has changed
since specs were generated:

1. Read `.organon/alignment-manifest.json` → `surfaces.specs.git_head`
2. Run `git rev-parse HEAD`
3. If they match: **no-drift mode**. APP and CONTRACT categories are
   **forbidden**. Every gap is either SPEC-SKILL or TEST-SKILL. Period.
   A spec that is "silent" or "ambiguous" about a behavior is a spec that
   sync-specs-with-code failed to capture — that is SPEC-SKILL, not APP.

Report drift status as the first line of the gap report.

### Step 1: Collect gaps

Scan for `# SPEC GAP` comments (and "SPEC GAP:" in derived markdown):

1. All `test_*.py` files in `tests_dir`
2. All `*.state.md` files in `.organon/specs/derived/`
3. All `*.workflow.yaml` files in `.organon/specs` (gaps in `notes:` fields)
4. Read contract/API spec files in `.organon/specs`
5. Cross-reference every endpoint in the contract against all
   `*.workflow.yaml` files (check `steps:` entries, legacy `transitions:`
   triggers, or `operations:` — all three formats may exist):
   - Endpoint not in any workflow → SPEC-SKILL gap
   - Workflow API call not in contract → CONTRACT gap

For each gap, extract: source file, gap text, related workflow.

### Step 2: Classify each gap

Read `references/gap-classification.md` for the 6 categories and their criteria.
Assign each gap to exactly one category.

**In no-drift mode (Step 0):** Do not use APP or CONTRACT. If a spec is missing
information about how the code behaves, that is SPEC-SKILL — sync-specs-with-code
should have captured it. If a test asserts something the spec doesn't say,
that is TEST-SKILL.

### Step 3: Cross-reference with prior rounds

If a `tracker` path is provided:
1. Read the tracker document
2. Mark each gap as: **NEW**, **RECURRING**, or **VARIANT** of a prior pattern

### Step 4: Propose actions (FORMAT gaps only)

For each FORMAT gap, draft a concrete proposal:
- What it enables
- Proposed YAML structure
- Impact on existing specs
- Impact on skills

### Step 5: Produce the report

Read `references/report-template.md` for the output structure. Populate it with classified gaps.

### Step 6: Present for review

Present the report. Ask which gaps to fix.

### Step 7: Fix (with user confirmation)

**SPEC-SKILL gaps:** Read target skill's SKILL.md, propose instruction change, show diff.

**TEST-SKILL gaps:** Read target skill's SKILL.md, propose instruction change, show diff.

**APP and CONTRACT gaps:** Report only — developer decides.

**ENVIRONMENT gaps:** Report only — resolved manually.

**FORMAT gaps:** Report only — design decisions needed.

Commit approved skill changes with: `fix: Update [skill] from alignment gap analysis`

### Design Principles

- **Analyze then fix.** Analysis is read-only; fixes require user approval.
- **Classify by fix location.** Every category answers "where does the fix go?"
- **Track convergence.** Cross-referencing with prior rounds makes convergence visible.
- **Propose concretely.** Skill fixes show actual diffs. FORMAT proposals show actual YAML.

---

## Final Step: Update alignment manifest

Read `.organon/alignment-manifest.json`. Update:
- `surfaces.tests.last_checked`: current ISO 8601
- `surfaces.tests.git_head`: current `git rev-parse HEAD`
- `surfaces.tests.checks.spec_coverage`: `workflows_with_tests`, `workflows_without_tests`
- `surfaces.tests.checks.execution`: `last_run`, `total`, `passed`, `failed`, `skipped`, `errors`
- `surfaces.tests.checks.gap_analysis`: gap counts per category (if Phase 3 ran)
- `surfaces.tests.status`: `"aligned"` if all passed with no gaps, `"gaps"` otherwise
- Append to `skill_runs`: `{"skill": "sync-tests-with-specs", "ran_at": "<ISO 8601>", "git_head": "<commit>", "surfaces_updated": ["tests"], "summary": "<one-line result>"}`
- Truncate `skill_runs` to last 20 entries

Write the updated manifest. If manifest doesn't exist, create it with only this skill's entry populated.
