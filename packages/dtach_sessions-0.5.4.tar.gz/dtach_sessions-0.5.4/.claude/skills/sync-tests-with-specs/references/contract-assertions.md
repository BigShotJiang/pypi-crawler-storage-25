# Contract-Driven Assertions

When `openapi.json` is present in `.organon/specs/`, use it as the source of
truth for HTTP assertions. This prevents the common failure mode where tests
assume 200 for everything and fail on 201/204 responses.

## Response Status Codes

For each API call in a test, look up the endpoint in the contract and use the
documented success response code:
- POST often returns 201 (Created), not 200
- DELETE typically returns 204 (No Content)
- PUT/PATCH may return 200 or 204

Do not assume 200 for all operations. The contract is the authority.

## Required Query Parameters

For each endpoint, check if the contract defines required query parameters
(`required: true` or `Query(...)` in the schema). Include all required
parameters in test calls.

Missing required params cause 422 responses that look like test failures but
are really missing test setup — these are among the hardest failures to
diagnose because the error cascades.

## Required Request Body Fields

For each POST/PUT/PATCH call — including fixture setup calls like creating test
entities — look up the request body schema in the contract. Include ALL
required fields.

A missing required field causes 422 and cascades to every test that depends on
the fixture. This is especially important for conftest fixtures that create
shared test data: one missing field breaks the entire test suite.

## Coverage Check

After generating all tests, verify endpoint coverage:

1. Build a list of all endpoints defined in the contract (method + path)
2. Check which endpoints are exercised by at least one generated test
3. For each untested endpoint, add a comment at the bottom of the test file:
   ```python
   # SPEC GAP: no workflow covers endpoint POST /api/foo
   # SPEC GAP: no workflow covers endpoint DELETE /api/bar/{id}
   ```

These gaps indicate workflows that should be specified to achieve full contract
coverage. Include the coverage ratio (X of Y endpoints tested) in the report.
