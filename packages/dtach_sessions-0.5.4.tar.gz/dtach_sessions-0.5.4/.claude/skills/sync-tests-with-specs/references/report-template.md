# Gap Analysis Report Template

Use this structure for the gap analysis report output.

```markdown
## Gap Analysis Report

**Workflow(s) analyzed:** ...
**Test files scanned:** ...
**Derived docs scanned:** ...
**Tracker cross-referenced:** yes/no

### Summary

| Category    | New | Recurring | Variant | Total |
|-------------|-----|-----------|---------|-------|
| SPEC-SKILL  |     |           |         |       |
| TEST-SKILL  |     |           |         |       |
| APP         |     |           |         |       |
| CONTRACT    |     |           |         |       |
| ENVIRONMENT |     |           |         |       |
| FORMAT      |     |           |         |       |

### SPEC-SKILL Gaps (fix in generate-specs / derive-specs)

#### GAP-SS1: [short name]
- **Source:** [file:line]
- **Status:** NEW / RECURRING / VARIANT of [prior gap]
- **Description:** ...
- **Skill:** [generate-specs | derive-specs]
- **Fix:** [what the skill should capture that it missed]

### TEST-SKILL Gaps (fix in generate-tests / run-tests)

#### GAP-TS1: [short name]
- **Source:** [file:line]
- **Status:** NEW / RECURRING
- **Description:** ...
- **Skill:** [generate-tests | run-tests]
- **Fix:** [what the skill should do differently]

### APP Gaps (fix in project application code)

#### GAP-APP1: [short name]
- **Source:** [file:line]
- **Status:** NEW / VARIANT of [pattern]
- **Description:** ...
- **Fix:** [what the app should change]

### CONTRACT Gaps (fix in project openapi.json / contract spec)

#### GAP-CT1: [short name]
- **Source:** [file:line]
- **Status:** NEW / VARIANT of [pattern]
- **Description:** ...
- **Fix:** [what to add/change in the contract]

### ENVIRONMENT Gaps (fix in project infra + organon environment surface)

#### GAP-ENV1: [short name]
- **Source:** [file:line]
- **Status:** NEW / RECURRING
- **Description:** ...
- **Fix:** [what service/config is missing]

### FORMAT Gaps (fix in spec schema definition — should be rare)

#### GAP-FMT1: [short name]
- **Source:** [file:line]
- **Status:** NEW / RECURRING
- **Description:** ...
- **Proposed extension:**
  ```yaml
  # how the new YAML structure would look
  ```
- **Impact on existing specs:** ...
- **Impact on skills:** ...

### Recommended Next Steps

1. [Ordered list of recommended actions, grouped by fix location]
2. [...]
```
