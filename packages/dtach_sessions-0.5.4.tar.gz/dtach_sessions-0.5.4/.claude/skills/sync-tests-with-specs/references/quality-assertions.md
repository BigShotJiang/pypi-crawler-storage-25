# Quality-Driven Assertions

When `*.quality.md` files exist in `.organon/specs/`, extract testable
requirements and add assertions to relevant test functions.

## Performance Budgets

If response time targets are specified (e.g., "p95 < 200ms"), add timing
assertions to relevant test functions. Use generous margins for CI environments
(2.5x the target is a reasonable default):

```python
import time
start = time.monotonic()
response = client.get("/api/search", params={"q": query})
elapsed = time.monotonic() - start
assert response.status_code == 200
# Quality: p95 response time target < 200ms
assert elapsed < 0.5, f"Response took {elapsed:.3f}s, budget is 200ms (using 2.5x margin for test)"
```

## SLA Targets

If availability or throughput SLAs exist, add comments noting the expected
performance characteristics on relevant tests:

```python
# SLA: 99.9% availability, 1000 req/s throughput target
```

These are not assertable in a single test run but serve as documentation for
load testing follow-up.

## Security Requirements

If authentication or authorization requirements are specified, add test
scenarios for:

- **Unauthenticated access returns 401** — call protected endpoints without
  auth headers
- **Unauthorized role access returns 403** — call endpoints with insufficient
  permissions
- **Required headers/tokens are validated** — verify the API rejects malformed
  auth

All security test HTTP clients must use the same `base_url` source as
authenticated clients (conftest fixture or env var). Never hardcode URLs.
