# Gap Classification Guide

Assign each gap to exactly one category based on **where the fix goes**.
The category name tells you who owns the fix — not what's wrong abstractly.

## Drift Check (do this first)

Before classifying gaps, check whether code has changed since specs were generated:

1. Read the alignment manifest's `surfaces.specs.git_head`
2. Compare to current `git rev-parse HEAD`
3. If they match (or no code files changed in the diff), **there is no drift**.

**When there is no drift**, APP and CONTRACT categories are impossible. Every
test failure is either SPEC-SKILL (generate-specs misread the code) or
TEST-SKILL (generate-tests misread the specs). Do not classify gaps as APP
or CONTRACT in a no-drift scenario — the specs were just generated from
the code, so any mismatch is a skill error.

APP and CONTRACT gaps only exist when code has changed since specs were
last generated — meaning real drift occurred between the surfaces.

Report the drift status at the top of the gap report: "Drift check: no code
changes since spec generation (git HEAD matches)" or "Drift check: N files
changed since spec generation — APP/CONTRACT gaps possible."

## SPEC-SKILL

A spec-generating skill (`/sync-specs-with-code` or `/derive-views-from-specs`) didn't capture enough detail from the code. The spec is incomplete or imprecise because the skill that wrote it missed something.

This includes:
- Missing workflow steps for API endpoints (the skill should have found them)
- Missing field annotations (internal-only, unobservable, cascade behavior)
- Ambiguous behavior not captured (edge cases, error responses, event formats)
- Underspecified transitions or state interactions

Fix goes in: the skill definition (`.claude/skills/sync-specs-with-code/` or `.claude/skills/derive-views-from-specs/`)

## TEST-SKILL

`/sync-tests-with-specs` produced wrong output. The specs are correct but the test generation or execution skill mishandled them.

This includes:
- Duplicate fixtures that shadow conftest
- Tests that don't match the contract response schemas
- Missing pre-flight checks in run-tests
- Incorrect test structure or assertions

Fix goes in: the skill definition (`.claude/skills/sync-tests-with-specs/`)

## APP

The application code has a real bug or the OpenAPI contract doesn't match what the app actually does. The specs correctly describe expected behavior but the code diverges.

This includes:
- 500 errors where a proper error code should be returned
- Missing error response codes in OpenAPI
- Behavioral mismatches (spec says 409, app returns 200)
- Missing validation or error handling

Fix goes in: the project's application code or OpenAPI spec

## CONTRACT

The OpenAPI/contract spec is incomplete or inaccurate as a description of the API. The app behaves correctly but the contract doesn't document it.

This includes:
- Missing response codes (404, 409) for documented endpoints
- Missing field constraints (minLength, required)
- Undocumented query parameters or headers

Fix goes in: the project's openapi.json / contract spec

## ENVIRONMENT

Tests can't run because services, API keys, or infrastructure aren't configured. This is not a spec, test, or code problem — it's a missing runtime dependency.

This includes:
- External service not configured (LLM provider, document conversion)
- Missing API keys or environment variables
- Wrong backend on the test port
- Cascade failures from infrastructure unavailability

Fix goes in: project infrastructure + organon's environment surface (see backlog #060)

## FORMAT

The spec schema itself cannot express something it needs to. This is rare and should decline over time. Use only when none of the above categories apply — the format genuinely lacks a field or structure.

Fix goes in: the spec format definition (schema changes, new field types)
