# Dependency Fixture Resolution

When a workflow spec has a `depends_on` section, it declares preconditions from
other workflows that must be satisfied before tests can run. Each dependency
becomes a session-scoped pytest fixture.

## The Verify-Then-Fallback Pattern

For each dependency:

1. **Read the `verify` block** — an API call that checks if the precondition
   already exists (e.g., "is there an indexed document?")
2. **Read the `fallback_composition`** — names a composition from the referenced
   workflow that can produce the needed state if verification fails
3. **Read the referenced workflow file** to understand the fallback composition's
   steps

## Generating the Fixture

Generate a **session-scoped** pytest fixture for each dependency that:
- First runs the verify check (fast — just an API call)
- If verification succeeds, returns the existing resource ID
- If verification fails, runs the fallback composition steps to create the state
- Uses polling from the referenced workflow's `test_environment.polling` if the
  fallback involves async operations

```python
# NOTE: Field names, query params, and response paths below are illustrative.
# Always derive these from the actual workflow spec's verify block,
# entry_state/exit_state, and response body fields.
@pytest.fixture(scope="session")
def indexed_document_id(client):
    """Ensure an indexed document exists. Reuse if available."""
    # verify block from depends_on determines the API call and check
    resp = client.get("/api/documents", params={"status": "indexed", "limit": 1})
    items = resp.json().get("items", [])
    if items:
        return items[0]["id"]
    # Fallback: run fallback_composition steps from depends_on
    resp = client.post("/api/documents", json={"file_path": "...", "process": True})
    doc_id = resp.json()["document"]["id"]
    # poll until the verify condition is met...
    return doc_id
```

## Missing Referenced Workflows

If the referenced workflow file is not in `.organon/specs/`, add a `# SPEC GAP`
comment and generate the fixture based only on what the `depends_on` section
provides. Do not read source code to fill in the gap.

## Placement

Dependency fixtures belong in `conftest.py` since they are shared across test
files. Per-file test modules consume them via pytest injection.
