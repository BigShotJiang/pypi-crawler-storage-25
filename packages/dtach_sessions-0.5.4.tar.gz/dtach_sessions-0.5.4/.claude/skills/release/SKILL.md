---
name: release
description: Create a new release - bump version, update changelog, commit, tag, and push. Works across Python (pyproject.toml) and Node (package.json) projects.
argument-hint: "[major|minor|patch]"
---

Create a new release for this project.

## Arguments

`$ARGUMENTS` should be one of: `major`, `minor`, `patch`. If not provided, default to `patch`. Only prompt the user if the changes since the last release clearly warrant a minor or major bump (new features → minor, breaking changes → major) — in that case, suggest the appropriate level and confirm.

## Steps

### 0. Pre-release check

Before anything else, these checks MUST pass. Stop and tell the user if any fail:
- **Must be on main branch.** Releases only happen from main. If on another branch, stop immediately.
- **Working tree must be clean.** No uncommitted or untracked changes.
- **Must be up to date with origin.** Run `git fetch origin` then check if behind. If behind, stop.
- **Tests must pass.** Run the test suite. If any fail, stop.
- **Push the tag explicitly** after commit: `git push origin v<version>` (do not rely on `--follow-tags`).

### 1. Detect project type and current version

- Check for `pyproject.toml` (Python) or `package.json` (Node.js)
- Read the current version number
- Determine the new version by bumping the specified part (major/minor/patch)

### 2. Gather changes since last release

- Find the last version tag: `git describe --tags --abbrev=0`
- Get commit log since that tag: `git log <last-tag>..HEAD --oneline`
- If no previous tag, use all commits
- Summarize changes into categories: Added, Changed, Fixed, Removed (only include categories that have entries)

### 3. Update CHANGELOG.md

- If `CHANGELOG.md` exists, add a new version section under `[Unreleased]`
- Use [Keep a Changelog](https://keepachangelog.com) format
- Update the comparison links at the bottom of the file
- If no CHANGELOG.md exists, create one with the standard format

### 4. Bump version

- **Python (pyproject.toml):** Update the `version` field
- **Node (package.json):** Update the `version` field
- Do NOT run `npm version` or any other tool that auto-commits

### 5. Show the user what will be committed

- Display the version bump (old -> new)
- Display the changelog entry
- Display all files that will be committed
- Ask for confirmation before proceeding

### 6. Commit, tag, and push

Only after user confirms:

```
git add CHANGELOG.md <version-file>
git commit -m "release: v<new-version>"
git tag v<new-version>
git push origin main
git push origin v<new-version>
```

### 7. Verify publish workflow triggered

After pushing, check if a CI publish workflow exists (`.github/workflows/publish.yml` or similar).

- The workflow triggers on tag push (`push: tags: ['v*']`), so the tag push in step 6 already triggered it.
- No GitHub Release, `gh` CLI, or API token is needed — SSH-based tag push is sufficient.
- Tell the user the publish workflow should now be running and they can check the Actions tab on GitHub.

## Important

- Never skip the confirmation step
- The tag format is always `v` prefixed (e.g., `v0.3.0`)
- Do not include commit hashes in the changelog
- Keep changelog entries concise - one line per change, focused on what changed for users
- If there are uncommitted changes, warn the user and stop - do not release with dirty working tree
