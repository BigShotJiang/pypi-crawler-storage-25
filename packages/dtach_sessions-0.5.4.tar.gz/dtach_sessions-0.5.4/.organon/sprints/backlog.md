# Project Backlog

Rough ideas and future work not yet scoped into sprints.

## Instructions

**Lifecycle:**
1. **Quick Reference** - Pending items not yet assigned to a sprint
2. **Planned** - Items assigned to a sprint (Created/Planned/Current status)
3. **Completed** - Items with completed sprints
4. **Details** - Full descriptions for all items (searchable reference)

**Workflow:**
- Add new ideas to Quick Reference with [#NNN] ID and brief description
- When creating sprint, move item from Quick Reference to Planned
- When sprint completes, move item from Planned to Completed with sprint/commit info
- Always add/update Details section for new items

**Numbering:**
- Ordinals (1, 2, 3...) renumber automatically in Quick Reference
- IDs [#NNN] are immutable and never change
- Gaps in ID sequence show completed work

## Quick Reference (Pending)

1. [#001] **Example Item**: Brief description of a potential feature or task

## Planned

- None yet

## Completed

- None yet

## Details

### [#001] Example Item

**Description:**
Replace this with actual backlog items for your project.

**Notes:**
- You can delete this example once you add your first real backlog item
