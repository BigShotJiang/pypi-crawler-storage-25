# Specification: Daemon

**Created:** 2026-04-11
**Sprint:** daemon

## Summary

Defines the contracts for the daemon process, NDJSON protocol, container registry schema, and library client API. These are the interfaces — implementation details are left to the plan.

## Dependencies

This phase depends on:
- [Requirements](requirements.md)
- [Architecture](architecture.md)

**Information needed from prior phases:**
- From [Requirements](requirements.md): Features, success criteria
- From [Architecture](architecture.md): Module boundaries, class names

## Technical Specifications

### Protocol (NDJSON over Unix Socket)

Request format:
```json
{"cmd": "<command>", "id": "<optional-request-id>", ...params}
```

Response format:
```json
{"id": "<request-id>", "result": <data>, "error": null}
{"id": "<request-id>", "result": null, "error": "<message>"}
```

Event format (on subscribed connections):
```json
{"id": "<subscription-id>", "event": "<event-type>", "data": {...}}
```

Framing: newline-delimited (`\n`). One JSON object per line. UTF-8.

### Commands

| Command | Params | Response |
|---------|--------|----------|
| `list_containers` | — | `[ContainerEntry, ...]` |
| `get_container` | `container` | `ContainerEntry` |
| `register_container` | `container`, `container_id`, `ip` | `ContainerEntry` |
| `list_ports` | `container` (optional) | `[PortInfo, ...]` |
| `list_forwards` | `container` (optional) | `[ForwardInfo, ...]` |
| `start_forward` | `container`, `port`, `host_port` (optional) | `ForwardInfo` |
| `stop_forward` | `container`, `port` | `null` |
| `watch` | `container` (optional) | Switches to event mode |
| `unwatch` | — | Stops events, back to request/response |
| `status` | — | `{daemon_pid, uptime, containers, forwards}` |
| `shutdown` | — | Daemon exits cleanly |

### Event Types

| Event | Data |
|-------|------|
| `port_added` | `{container, port, bind, protocol, forward: ForwardInfo|null}` |
| `port_removed` | `{container, port, forward: ForwardInfo|null}` |
| `container_restart` | `{container, old_ip, new_ip}` |
| `forward_died` | `{container, port, host_port, pid}` |

### Data Models

```python
@dataclass
class ContainerEntry:
    container_name: str
    container_id: str
    container_ip: str
    status: str  # "running", "stopped", "unknown"
    created_at: str  # ISO 8601
    updated_at: str  # ISO 8601
    ports: list[PortInfo]
    forwards: list[ForwardInfo]

@dataclass
class PortInfo:
    port: int
    bind_address: str
    protocol: str  # "tcp" or "tcp6"

@dataclass
class ForwardInfo:
    container_port: int
    host_port: int
    socat_pid: int
    alive: bool
```

### Registry Persistence

File: `~/.dsm/registry/{container_name}.json`

```json
{
  "container_name": "dsm_web",
  "container_id": "abc123...",
  "container_ip": "172.17.0.2",
  "status": "running",
  "created_at": "2026-04-11T10:00:00Z",
  "updated_at": "2026-04-11T10:23:45Z",
  "ports": [
    {"port": 8787, "bind_address": "0.0.0.0", "protocol": "tcp"}
  ],
  "forwards": [
    {"container_port": 8787, "host_port": 8787, "socat_pid": 12345}
  ]
}
```

Atomic write: write to `{name}.json.tmp`, then `os.rename` to `{name}.json`.

### API/Interface Design

```python
# daemon.py
class DsmDaemon:
    def __init__(self, socket_path: Path, registry_dir: Path): ...
    async def start(self) -> None: ...
    async def stop(self) -> None: ...
    async def handle_client(self, reader: StreamReader, writer: StreamWriter) -> None: ...

# registry.py
class ContainerRegistry:
    def __init__(self, registry_dir: Path): ...
    def load(self) -> None: ...
    def get(self, container_name: str) -> ContainerEntry | None: ...
    def list(self) -> list[ContainerEntry]: ...
    def register(self, container_name: str, container_id: str, ip: str) -> ContainerEntry: ...
    def update(self, container_name: str, **fields) -> ContainerEntry: ...
    def remove(self, container_name: str) -> None: ...
    def persist(self, container_name: str) -> None: ...
    def persist_all(self) -> None: ...

# client (in cli.py or separate client.py)
class DsmClient:
    def __init__(self, socket_path: Path): ...
    def connect(self) -> None: ...
    def send(self, cmd: str, **params) -> dict: ...
    def close(self) -> None: ...

def ensure_daemon_running(socket_path: Path) -> None:
    """Lazy-start: try connect, spawn if needed, retry."""
    ...
```

### Examples

```python
# CLI usage: dsm ports
client = DsmClient(Path("~/.dsm/dsm.sock").expanduser())
client.connect()
result = client.send("list_forwards")
for fwd in result:
    print(f"  {fwd['container_port']} -> localhost:{fwd['host_port']}")
client.close()

# Library usage: ui_coder subscribing to events
client = DsmClient(socket_path)
client.connect()
client.send("watch", container="dsm_web")
# client now receives events on the same connection
```

## Overlay Specs

No existing specs to overlay — specs directory is empty.

## Validation Criteria

```bash
# Daemon starts and accepts connections
dsm daemon start
dsm daemon status  # shows pid, uptime

# Registry populated after container creation
dsm container myrepo
ls ~/.dsm/registry/dsm_myrepo.json  # exists

# Ports visible from CLI
dsm ports  # shows forwarded ports (reads from daemon)

# Graceful shutdown
dsm daemon stop  # kills socat, persists state, removes socket

# Degraded mode (no daemon)
kill $(dsm daemon status | grep pid)
dsm ports  # reads from disk, shows last-known state
```
