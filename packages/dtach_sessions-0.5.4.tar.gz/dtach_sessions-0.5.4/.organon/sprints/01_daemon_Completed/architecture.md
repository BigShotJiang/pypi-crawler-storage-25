# Architecture: Daemon

**Created:** 2026-04-11
**Sprint:** daemon

## Summary

Adds one new module (`daemon.py`), one new module (`registry.py`), and refactors `ports.py` to use asyncio. CLI becomes a thin client. No new dependencies.

## Dependencies

This phase depends on:
- [Requirements](requirements.md)

**Information needed from prior phases:**
- From [Requirements](requirements.md): Features, scope, success criteria

**Information provided to next phases:**
- To [Specification](spec.md): Module boundaries, class names, file paths
- To [Plan](plan.md): Implementation scaffolding order

## Class Structure

### New Classes

**`daemon.py`:**
- `DsmDaemon` — Main daemon class. Owns the asyncio event loop, Unix socket server, registry, and port watcher tasks.
- `ClientConnection` — Represents a connected client (CLI or library). Handles request/response and event subscriptions.

**`registry.py`:**
- `ContainerRegistry` — In-memory container state backed by per-container JSON files. Single writer. Atomic persistence.
- `ContainerEntry` — Dataclass for per-container state (name, id, ip, status, ports, forwards).

### Modified Classes

**`ports.py`:**
- `PortWatcher` — Refactored from threading to asyncio. Same detection logic, new execution model.
- Forward registry (`_active_forwards`) — Moved into `ContainerRegistry` as the authoritative store.

**`cli.py`:**
- Port commands (`cmd_ports`, `cmd_forward`, `cmd_unforward`) — Become daemon clients.
- New `cmd_daemon` — Start/stop/status subcommand.
- `ensure_container` — Calls registry after container creation.

## Module Organization

**New files:**
- `src/dsm/daemon.py` — Daemon process, socket server, client handling
- `src/dsm/registry.py` — Container registry, persistence, entry dataclass

**Modified files:**
- `src/dsm/ports.py` — Asyncio port watcher, remove in-process forward registry
- `src/dsm/cli.py` — Daemon client integration, new daemon subcommand, ensure_container registry call

**Runtime paths:**
- `~/.dsm/dsm.sock` — Daemon Unix socket
- `~/.dsm/registry/*.json` — Per-container state files

## Non-Functional Requirements

- **Zero dependencies:** stdlib only (asyncio, json, subprocess, socket, os)
- **Startup time:** Daemon starts in <500ms
- **Memory:** <20MB RSS for typical usage (5-10 containers)
- **Latency:** CLI command round-trip <50ms via socket
- **Crash safety:** Atomic writes prevent corrupted registry files
- **Backward compatible:** Existing `~/.dsm/` session metadata unchanged

## Scaffolding Plan

1. **Registry first** — `registry.py` with `ContainerEntry` and `ContainerRegistry`. Pure data + persistence. Testable in isolation.
2. **Daemon core** — `daemon.py` with socket server and NDJSON protocol. Uses registry.
3. **Port watcher asyncio** — Refactor `PortWatcher` to asyncio tasks. Wire into daemon.
4. **CLI integration** — Client connection from CLI. Lazy start. Daemon subcommand.
5. **Testing** — Integration tests with real daemon process.

## Project Documentation Impact

**Review:** No existing docs/design.md or docs/architecture.md in this project.

**Impact:**
- `.organon/STRUCTURE.md` — Add daemon.py, registry.py modules and ~/.dsm/registry/ path
- `.organon/CLAUDE.md` — No changes needed (project-level, not framework)

**Reconciliation plan:** Update STRUCTURE.md after implementation completes.
