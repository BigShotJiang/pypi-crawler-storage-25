# Requirements: Daemon Architecture

**Created:** 2026-04-11
**Sprint:** daemon

## Summary

Add a lightweight daemon process (`dsmd`) to dsm that provides single-process coordination for container state, port watching, and event delivery. The daemon eliminates race conditions from filesystem-based coordination, enables continuous port monitoring, and provides push notifications to consumers like ui_coder.

## Dependencies

This phase depends on:
- None (first phase in planning sequence)

**Information needed from prior phases:**
- Design rationale: `.organon/dev-docs/design/daemon-architecture.md`
- Origin analysis: `ui_coder:.organon/dev-docs/design/dsm-ui-coder-architecture.md`

**Information provided to next phases:**
- To [Architecture](architecture.md): Component boundaries, NFRs
- To [Specification](spec.md): Protocol contracts, registry schema
- To [Plan](plan.md): Scope boundaries

## Goals

### Primary Goal
Introduce a daemon process that is the single owner of container state, port watchers, and socat process lifecycle — eliminating all multi-process coordination problems.

### Secondary Goals
- **Container registry:** Track all containers dsm creates, regardless of creation path (CLI or library)
- **Persistent port state:** Forward state visible to any process (CLI, ui_coder, other consumers)
- **Push events:** Consumers subscribe to port changes instead of polling

## Features

### Feature 1: Daemon Process
**What:** asyncio-based daemon listening on `~/.dsm/dsm.sock`
**Details:** Single event loop hosting port watchers as asyncio tasks, client connections, and child process management (socat). NDJSON protocol over Unix socket.
**Integration:** CLI and library become thin clients that talk to the daemon.

### Feature 2: Container Registry
**What:** Persistent per-container JSON files in `~/.dsm/registry/`
**Details:** `ensure_container()` creates/updates registry entries. Daemon is single writer at runtime. CLI reads from disk when daemon is down (degraded mode).
**Integration:** Replaces the session-only metadata model for container tracking.

### Feature 3: CLI Integration
**What:** CLI commands (`dsm ports`, `dsm forward`, etc.) become daemon clients
**Details:** Connect to socket, send command, print result. Lazy-start daemon if not running. Graceful degradation to disk reads.
**Integration:** Existing CLI commands gain daemon awareness; new `dsm daemon` subcommand.

### Feature 4: Event Subscription
**What:** Persistent socket connections with push notifications
**Details:** Clients send `{"cmd": "watch", "container": "name"}`, daemon pushes `{"event": "port_added", ...}` on changes.
**Integration:** ui_coder subscribes via dsm library instead of running its own PortWatcher.

## Success Criteria

### For Feature 1 (Daemon)
- [ ] Daemon starts on `dsm daemon start` and listens on Unix socket
- [ ] Daemon lazy-starts on first CLI command if not running
- [ ] Daemon handles SIGTERM/SIGINT with clean shutdown (kills socat, persists state)
- [ ] Port watchers run as asyncio tasks inside daemon
- [ ] Zero new dependencies (stdlib only)

### For Feature 2 (Registry)
- [ ] `ensure_container()` creates registry entry in `~/.dsm/registry/`
- [ ] Registry entries use atomic writes (write temp + rename)
- [ ] `dsm ls` shows all registered containers (not just session-attached)
- [ ] Registry survives daemon restart

### For Feature 3 (CLI)
- [ ] `dsm ports` reads from daemon (or disk fallback)
- [ ] `dsm forward/unforward` delegates to daemon
- [ ] `dsm daemon start|stop|status` works
- [ ] CLI auto-starts daemon on first use

### For Feature 4 (Events)
- [ ] Client can subscribe to port changes via persistent connection
- [ ] Daemon pushes events on port add/remove
- [ ] Multiple concurrent subscribers supported

## Project Documentation Impact

### Project Specs Affected
- [ ] `.organon/specs/` — New specs for daemon protocol, registry schema, container lifecycle

### CLAUDE.md Sections Affected
- [ ] Architecture / service descriptions — daemon component
- [ ] Directory map / file locations — `~/.dsm/registry/`, `dsm.sock`

### Other Project Docs
- [ ] `.organon/STRUCTURE.md` — new module `daemon.py`, new directory `registry/`

## Scope

### In Scope
**Must Have:**
- Daemon process with asyncio event loop and Unix socket
- Container registry with persistent JSON files
- CLI integration (lazy start, daemon commands, fallback)
- Port watcher migration from threads to asyncio tasks
- Graceful shutdown with state persistence

**Should Have:**
- Event subscription (watch command with push)
- `dsm daemon status` with health info

### Out of Scope
- systemd/launchd integration (future work)
- macOS/Windows support (existing limitation)
- ui_coder changes (separate repo, separate sprint)
- Container lifecycle management beyond registration (stop/remove stay as-is)

### Open Questions
- Should `dsm daemon` be a hidden subcommand or visible?
- What's the checkpoint interval for periodic state persistence? (proposed: 30s)
