# Implementation Plan: Daemon

**Created:** 2026-04-11
**Started:** 2026-04-11
**Sprint:** 01_daemon

## Overview

Add a lightweight asyncio daemon process to dsm that provides single-process coordination for container state, port watching, and event delivery over a Unix socket with NDJSON protocol. The daemon eliminates race conditions from filesystem-based coordination, enables continuous port monitoring, and provides push notifications to consumers. Implementation introduces two new modules (`registry.py`, `daemon.py`), refactors `ports.py` from threading to asyncio, and integrates the CLI as a thin daemon client with graceful degradation.

## Workflow

This sprint follows the workflow-task model:
- Planning Level: Research → Design → Spec → Plan (this document)
- Development Level: Implement → Test → Review → Document

## Tasks

### Phase 1: Container Registry

**Status:** completed
**Dependencies:** none

#### Task 1.1: ContainerEntry and data model dataclasses

- **Type:** implement
- **Status:** completed
- **Dependencies:** none
- **Files:**
  - Create: src/dsm/registry.py
- **Context:** [spec.md§Data Models](spec.md#data-models), [architecture.md§Class Structure](architecture.md#class-structure)
- **Description:** Create registry.py with ContainerEntry, PortInfo, and ForwardInfo dataclasses matching the spec. Include JSON serialization (to_dict/from_dict) for persistence.
- **Commit:** phase-1

#### Task 1.2: ContainerRegistry class

- **Type:** implement
- **Status:** completed
- **Dependencies:** [1.1]
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [spec.md§API/Interface Design](spec.md#apiinterface-design), [architecture.md§Scaffolding Plan](architecture.md#scaffolding-plan)
- **Description:** Implement ContainerRegistry with load, get, list, register, update, remove, persist, and persist_all methods. In-memory dict backed by per-container JSON files in the registry directory.
- **Commit:** phase-1

#### Task 1.3: Atomic write persistence

- **Type:** implement
- **Status:** completed
- **Dependencies:** [1.2]
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [spec.md§Registry Persistence](spec.md#registry-persistence), [research.md§State persistence](research.md#industry-patterns)
- **Description:** Implement atomic write for persist method: write to {name}.json.tmp then os.rename to {name}.json. Ensures crash safety — no corrupted registry files.
- **Commit:** phase-1

#### Task 1.4: Registry directory auto-creation

- **Type:** implement
- **Status:** completed
- **Dependencies:** [1.2]
- **Files:**
  - Modify: src/dsm/registry.py
- **Context:** [architecture.md§Module Organization](architecture.md#module-organization)
- **Description:** Create ~/.dsm/registry/ on first use if it does not exist (mkdir -p equivalent). Called from ContainerRegistry.__init__ or load.
- **Commit:** phase-1

#### Task 1.5: Test registry CRUD and persistence round-trip

- **Type:** test
- **Status:** completed
- **Dependencies:** [1.3, 1.4]
- **Files:**
  - Create: tests/test_registry.py
- **Context:** [spec.md§Data Models](spec.md#data-models), [spec.md§Registry Persistence](spec.md#registry-persistence)
- **Description:** Test register/get/list/update/remove operations and verify persistence round-trip: register a container, persist, create a new ContainerRegistry pointing at the same directory, load, and verify data matches.
- **Commit:** phase-1

#### Task 1.6: Test atomic write behavior

- **Type:** test
- **Status:** completed
- **Dependencies:** [1.3]
- **Files:**
  - Modify: tests/test_registry.py
- **Context:** [spec.md§Registry Persistence](spec.md#registry-persistence)
- **Description:** Test that persist writes to a temp file then renames. Verify that a partially written file does not corrupt the registry (simulate by checking no .tmp files remain after successful persist).
- **Commit:** phase-1

### Phase 2: Daemon Core

**Status:** completed
**Dependencies:** [Phase 1]

#### Task 2.1: DsmDaemon class with asyncio event loop and Unix socket server

- **Type:** implement
- **Status:** completed
- **Dependencies:** [1.2]
- **Files:**
  - Create: src/dsm/daemon.py
- **Context:** [spec.md§API/Interface Design](spec.md#apiinterface-design), [architecture.md§Class Structure](architecture.md#class-structure)
- **Description:** Implement DsmDaemon with __init__(socket_path, registry_dir), async start() that creates an asyncio Unix socket server and runs the event loop, and async stop() that closes connections and cleans up the socket file.
- **Commit:**

#### Task 2.2: NDJSON request/response protocol

- **Type:** implement
- **Status:** completed
- **Dependencies:** [2.1]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [spec.md§Protocol (NDJSON over Unix Socket)](spec.md#protocol-ndjson-over-unix-socket)
- **Description:** Implement NDJSON framing: read lines from StreamReader, parse as JSON, dispatch by "cmd" field, write JSON response + newline to StreamWriter. Handle malformed input with error responses.
- **Commit:**

#### Task 2.3: ClientConnection with request dispatch

- **Type:** implement
- **Status:** completed
- **Dependencies:** [2.2]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [spec.md§Commands](spec.md#commands), [architecture.md§Class Structure](architecture.md#class-structure)
- **Description:** Implement ClientConnection class that wraps reader/writer and dispatches commands: list_containers, get_container, register_container, status, shutdown. Each command handler reads from or writes to the ContainerRegistry.
- **Commit:**

#### Task 2.4: Signal handling and clean shutdown

- **Type:** implement
- **Status:** completed
- **Dependencies:** [2.1]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [requirements.md§Feature 1: Daemon Process](requirements.md#feature-1-daemon-process)
- **Description:** Add SIGTERM and SIGINT handlers via loop.add_signal_handler that trigger clean shutdown: persist registry, stop port watchers, terminate socat processes, remove socket file.
- **Commit:**

#### Task 2.5: Event subscription (watch/unwatch)

- **Type:** implement
- **Status:** completed
- **Dependencies:** [2.3]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [spec.md§Commands](spec.md#commands), [spec.md§Event Types](spec.md#event-types)
- **Description:** Implement watch and unwatch commands on ClientConnection. Track subscribed clients per container. Add broadcast_event method on DsmDaemon that sends NDJSON event lines to all subscribers matching the container filter.
- **Commit:**

#### Task 2.6: Test daemon start/stop lifecycle and socket cleanup

- **Type:** test
- **Status:** completed
- **Dependencies:** [2.4]
- **Files:**
  - Create: tests/test_daemon.py
- **Context:** [spec.md§API/Interface Design](spec.md#apiinterface-design)
- **Description:** Test that DsmDaemon.start creates the socket file, accepts a connection, and DsmDaemon.stop removes the socket file. Verify clean shutdown on SIGTERM signal.
- **Commit:**

#### Task 2.7: Test NDJSON protocol round-trip

- **Type:** test
- **Status:** completed
- **Dependencies:** [2.3]
- **Files:**
  - Modify: tests/test_daemon.py
- **Context:** [spec.md§Protocol (NDJSON over Unix Socket)](spec.md#protocol-ndjson-over-unix-socket)
- **Description:** Test sending a JSON command over a Unix socket connection and receiving a JSON response. Verify status command returns daemon info. Verify malformed JSON returns an error response.
- **Commit:**

### Phase 3: Port Watcher Migration

**Status:** completed
**Dependencies:** [Phase 2]

#### Task 3.1: Refactor PortWatcher from daemon thread to asyncio task

- **Type:** refactor
- **Status:** completed
- **Dependencies:** [2.1]
- **Files:**
  - Modify: src/dsm/ports.py
- **Context:** [architecture.md§Modified Classes](architecture.md#modified-classes), [research.md§Python Implementation](research.md#python-implementation)
- **Description:** Rewrite PortWatcher to use asyncio: replace threading.Thread with asyncio.create_task, replace threading.Event with asyncio.Event, replace threading.Lock with asyncio logic. Keep the same detection logic (scan_container_ports) and diff algorithm. The public interface (start/stop/add_container/remove_container) becomes async.
- **Commit:**

#### Task 3.2: Wire port watcher into DsmDaemon

- **Type:** implement
- **Status:** completed
- **Dependencies:** [3.1]
- **Files:**
  - Modify: src/dsm/daemon.py
  - Modify: src/dsm/ports.py
- **Context:** [architecture.md§Scaffolding Plan](architecture.md#scaffolding-plan)
- **Description:** DsmDaemon creates one PortWatcher task per registered container on start. When a container is registered via register_container command, start a watcher for it. On stop, cancel all watcher tasks.
- **Commit:**

#### Task 3.3: Move _active_forwards into ContainerRegistry

- **Type:** refactor
- **Status:** completed
- **Dependencies:** [3.1, 1.2]
- **Files:**
  - Modify: src/dsm/ports.py
  - Modify: src/dsm/registry.py
- **Context:** [architecture.md§Modified Classes](architecture.md#modified-classes), [spec.md§Data Models](spec.md#data-models)
- **Description:** Remove the module-level _active_forwards dict from ports.py. Store forward state (ForwardInfo) in ContainerEntry.forwards within the ContainerRegistry. Update start_forward and stop_forward to accept a registry parameter and update the entry.
- **Commit:**

#### Task 3.4: Forward management commands

- **Type:** implement
- **Status:** completed
- **Dependencies:** [3.3, 2.3]
- **Files:**
  - Modify: src/dsm/daemon.py
- **Context:** [spec.md§Commands](spec.md#commands)
- **Description:** Add command handlers for start_forward, stop_forward, list_forwards, and list_ports in ClientConnection. These delegate to ports.py functions and update the registry.
- **Commit:**

#### Task 3.5: Emit port events to subscribers

- **Type:** implement
- **Status:** completed
- **Dependencies:** [3.2, 2.5]
- **Files:**
  - Modify: src/dsm/daemon.py
  - Modify: src/dsm/ports.py
- **Context:** [spec.md§Event Types](spec.md#event-types)
- **Description:** Wire the PortWatcher on_change callback to DsmDaemon.broadcast_event. Translate PortChange objects into spec-defined event types (port_added, port_removed, forward_died) and push to subscribed clients.
- **Commit:**

#### Task 3.6: Test port watcher asyncio task

- **Type:** test
- **Status:** completed
- **Dependencies:** [3.1]
- **Files:**
  - Create: tests/test_port_watcher_async.py
- **Context:** [architecture.md§Modified Classes](architecture.md#modified-classes)
- **Description:** Test the refactored async PortWatcher: verify it starts as an asyncio task, polls containers, and can be stopped cleanly. Test the diff logic with mock /proc data (using parse_proc_net_tcp which is a pure function).
- **Commit:**

### Phase 4: CLI Integration

**Status:** completed
**Dependencies:** [Phase 3]

#### Task 4.1: DsmClient sync wrapper

- **Type:** implement
- **Status:** completed
- **Dependencies:** [2.2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [spec.md§API/Interface Design](spec.md#apiinterface-design), [spec.md§Examples](spec.md#examples)
- **Description:** Implement DsmClient class in cli.py with connect, send(cmd, **params), and close methods. Synchronous wrapper: opens Unix socket, writes NDJSON request, reads NDJSON response, returns parsed dict.
- **Commit:**

#### Task 4.2: ensure_daemon_running with lazy start

- **Type:** implement
- **Status:** completed
- **Dependencies:** [4.1]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [spec.md§API/Interface Design](spec.md#apiinterface-design), [research.md§Socket activation / lazy start](research.md#industry-patterns)
- **Description:** Implement ensure_daemon_running: try connect to socket, if fails spawn daemon as background process (subprocess.Popen with daemon.py entry point), retry connect with backoff. Used before every CLI command that needs the daemon.
- **Commit:**

#### Task 4.3: Refactor port commands to use DsmClient

- **Type:** refactor
- **Status:** completed
- **Dependencies:** [4.1, 3.4]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [architecture.md§Modified Classes](architecture.md#modified-classes), [requirements.md§Feature 3: CLI Integration](requirements.md#feature-3-cli-integration)
- **Description:** Refactor cmd_ports, cmd_forward, and cmd_unforward to use DsmClient instead of calling ports.py functions directly. Connect to daemon, send the appropriate command, format and print the response.
- **Commit:**

#### Task 4.4: Disk-read fallback when daemon not running

- **Type:** implement
- **Status:** completed
- **Dependencies:** [4.3]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [requirements.md§Feature 3: CLI Integration](requirements.md#feature-3-cli-integration), [spec.md§Validation Criteria](spec.md#validation-criteria)
- **Description:** When daemon connection fails (after lazy-start attempt), fall back to reading ~/.dsm/registry/*.json directly for read-only commands (list_containers, list_ports, list_forwards). Write commands (forward/unforward) print an error asking user to start daemon.
- **Commit:**

#### Task 4.5: cmd_daemon subcommand (start/stop/status)

- **Type:** implement
- **Status:** completed
- **Dependencies:** [4.2]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [requirements.md§Feature 1: Daemon Process](requirements.md#feature-1-daemon-process), [spec.md§Commands](spec.md#commands)
- **Description:** Add dsm daemon subcommand with start (spawn daemon), stop (send shutdown command), and status (send status command, print pid/uptime/container count/forward count).
- **Commit:**

#### Task 4.6: Update ensure_container to register in registry

- **Type:** implement
- **Status:** completed
- **Dependencies:** [4.1]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [requirements.md§Feature 2: Container Registry](requirements.md#feature-2-container-registry), [architecture.md§Modified Classes](architecture.md#modified-classes)
- **Description:** After ensure_container creates or starts a container, send a register_container command to the daemon (or write directly to registry if daemon is not running). Pass container_name, container_id, and container_ip.
- **Commit:**

#### Task 4.7: Test CLI with daemon running

- **Type:** test
- **Status:** completed
- **Dependencies:** [4.3, 4.5, 4.9]
- **Files:**
  - Create: tests/test_cli_daemon.py
- **Context:** [spec.md§Validation Criteria](spec.md#validation-criteria)
- **Description:** Integration test: start a daemon, run CLI commands (dsm daemon status, dsm ports) via subprocess, verify output format and correctness. Stop daemon and verify clean shutdown.
- **Commit:**

#### Task 4.8: Test CLI graceful degradation

- **Type:** test
- **Status:** completed
- **Dependencies:** [4.4]
- **Files:**
  - Modify: tests/test_cli_daemon.py
- **Context:** [requirements.md§Feature 3: CLI Integration](requirements.md#feature-3-cli-integration)
- **Description:** Test that CLI commands work (degraded) when daemon is not running: pre-populate ~/.dsm/registry/ with JSON files, run dsm ports, verify it reads from disk and shows last-known state.
- **Commit:**

#### Task 4.9: Update dsm ls to read from registry

- **Type:** implement
- **Status:** completed
- **Dependencies:** [4.1]
- **Files:**
  - Modify: src/dsm/cli.py
- **Context:** [requirements.md§Feature 2: Container Registry](requirements.md#feature-2-container-registry)
- **Description:** Update cmd_ls to list containers from the daemon (via list_containers command) or fall back to reading ~/.dsm/registry/*.json directly when daemon is not running. Shows all registered containers, not just session-attached ones.
- **Commit:**

### Phase 5: Integration Testing and Documentation

**Status:** completed
**Dependencies:** [Phase 4]

#### Task 5.1: Integration test: full daemon lifecycle

- **Type:** test
- **Status:** completed
- **Dependencies:** [Phase 4]
- **Files:**
  - Create: tests/test_integration_daemon.py
- **Context:** [spec.md§Validation Criteria](spec.md#validation-criteria), [requirements.md§Success Criteria](requirements.md#success-criteria)
- **Description:** End-to-end test: start daemon, register a container, verify registry file created, send list_containers, verify response, send shutdown, verify socket removed and registry persisted.
- **Commit:**

#### Task 5.2: Integration test: lazy start

- **Type:** test
- **Status:** completed
- **Dependencies:** [4.2]
- **Files:**
  - Modify: tests/test_integration_daemon.py
- **Context:** [research.md§Socket activation / lazy start](research.md#industry-patterns)
- **Description:** Test that ensure_daemon_running spawns the daemon when no socket exists, and that a subsequent CLI command succeeds without manual daemon start.
- **Commit:**

#### Task 5.3: Update STRUCTURE.md

- **Type:** document
- **Status:** completed
- **Dependencies:** [Phase 4]
- **Files:**
  - Modify: .organon/STRUCTURE.md
- **Context:** [architecture.md§Project Documentation Impact](architecture.md#project-documentation-impact)
- **Description:** Add daemon.py and registry.py to the module listing in STRUCTURE.md. Add ~/.dsm/registry/ and ~/.dsm/dsm.sock to the runtime paths section. Update module responsibilities.
- **Commit:**

## Commit Conventions

Sprint work uses format: `feat(sprint-NN):`, `fix(sprint-NN):`, `docs(sprint-NN):`, `test(sprint-NN):`

Examples:
```bash
feat(sprint-NN): Implement container registry with atomic persistence
feat(sprint-NN): Add daemon core with Unix socket server
refactor(sprint-NN): Migrate PortWatcher from threading to asyncio
feat(sprint-NN): Integrate CLI as daemon client with lazy start
test(sprint-NN): Add daemon integration tests
docs(sprint-NN): Update STRUCTURE.md with daemon modules
```

## Completion Criteria

This sprint is complete when:

- [ ] All Phase 1-5 tasks checked off with commit hashes
- [ ] All tests passing (pytest)
- [ ] Container registry persists and loads correctly
- [ ] Daemon starts, serves commands, and shuts down cleanly
- [ ] Port watcher runs as asyncio tasks inside daemon
- [ ] CLI commands delegate to daemon with disk-read fallback
- [ ] `dsm ls` shows all registered containers from registry
- [ ] Lazy start works (daemon spawned on first CLI use)
- [ ] STRUCTURE.md updated
- [ ] Sprint status updated to Completed

## Notes

**Task Format:**

- **Phase ID:** Integer (1, 2, 3, ...)
- **Task ID:** Phase.Task format (1.1, 1.2, 2.1, ...)
- **Type:** implement | test | document | research | design | specify | plan | debug | refactor | review
- **Status:** pending | in_progress | completed | failed
- **Dependencies:** Task IDs [1.1, 1.2] or Phase IDs [Phase 1] or "none"
- **Files:** Actions on files (Create/Modify/Delete with paths)
- **Context:** Proper markdown links to sprint docs, e.g., [spec.md§Section Name](spec.md#section-name)
- **Description:** Human-readable task description
- **Commit:** Git commit hash (populated after execution)

**Orchestration:**

This structured format enables sub-agent orchestration:
- Parser extracts phases and tasks with metadata
- Dependency resolver determines execution order
- Orchestrator launches sub-agents for parallel task execution
- Progress tracker updates status and commit hashes

**See:** `.organon/defaults/docs/user-guide/orchestration.md` for usage guide

## Plan Review

**Reviewed:** 2026-04-11

- [x] Structural compliance verified
- [x] File operations reviewed (no conflicts)
- [x] Test coverage reviewed (all code has tests)
- [x] Documentation reviewed (all changes documented)
- [x] Dependencies reviewed (correct order, no circular deps)
- [x] Commit boundaries reviewed (atomic commits)
- [x] Completeness reviewed (no missing steps)
- [x] Scope reviewed (estimates realistic)

**Plan Status:** Ready for implementation

---
Created: 2026-04-11
Sprint: daemon
