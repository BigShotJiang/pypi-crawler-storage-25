# Kickoff: Daemon

**Created:** 2026-04-11
**Sprint:** daemon

## Context

This sprint emerged from a design session in ui_coder that started with a port forwarding problem and uncovered fundamental architectural gaps in the dsm/ui_coder boundary. The full arc is documented in `ui_coder:.organon/dev-docs/design/dsm-ui-coder-architecture.md`.

## What Was Discussed

1. **4 architectural gaps identified** — ensure_container doesn't create registry metadata, forward state is in-process only, no watcher coordination, ambiguous container lifecycle ownership.

2. **Daemon vs filesystem coordination** — Filesystem-based PID files and lock files are inherently racy (stale PIDs, race conditions, no crash cleanup). The user confirmed daemon is the right path.

3. **What the daemon provides** — Exactly three things filesystem + CLI cannot: (a) single-process coordination (one ordered event stream, no races), (b) liveness (watching for port changes, container restarts, socat deaths), (c) push notifications to consumers.

4. **Layering decision** — dsm owns containers and infrastructure state. ui_coder is a consumer. The daemon makes that ownership real.

5. **Research** — Three parallel research agents surveyed Unix daemon/CLI patterns, Python daemon implementations, and state management. Consensus: asyncio + Unix socket + NDJSON, lazy start, file-per-container registry, ~300-500 lines.

## Decisions Made

- Daemon and CLI (not either/or) — CLI is the user interface, daemon is the runtime
- asyncio event loop, not threading — fits event-driven model
- NDJSON over Unix socket — simplest proven protocol
- Lazy start (spawn on first CLI use) — zero operational overhead
- File-per-container JSON in `~/.dsm/registry/` — Docker's own pattern
- Socket liveness check over PID files
- Zero new dependencies
- ui_coder changes are out of scope (separate repo)

## Design Rationale

Written to `.organon/dev-docs/design/daemon-architecture.md`.
