# Research: Daemon

**Created:** 2026-04-11
**Sprint:** daemon

## Summary

Research into Unix daemon/CLI patterns, Python daemon implementations, and state management strategies. Concluded: asyncio Unix socket server with NDJSON protocol, lazy start, file-per-container registry with atomic writes.

## Dependencies

This phase depends on:
- [Requirements](requirements.md)

**Information provided to next phases:**
- To [Architecture](architecture.md): Proven patterns, technology choices
- To [Specification](spec.md): Protocol conventions, state format

## Problem Statement

dsm's port forwarding system needs a long-lived process to coordinate container state, watch for port changes, and serve state to multiple consumers. Filesystem-based coordination (PID files, lock files) fails due to races, stale state, and no crash cleanup.

## Investigation

### Existing Code Review

`ports.py` (578 lines) implements:
- Port scanning via `/proc/$PID/net/tcp` (Linux-native, zero overhead)
- socat-based forwarding with `subprocess.Popen`
- `PortWatcher` as a daemon thread polling every 2s
- In-process `_active_forwards` dict (not shared across processes)

`cli.py` `ensure_container()` (line 427) creates containers but writes no registry metadata. Only the CLI session path (`dsm container`) creates `meta.json`.

### Industry Patterns

**Socket activation / lazy start:**
- Docker: systemd socket activation (`docker.socket` + `docker.service`)
- gpg-agent, ssh-agent: socket activation on modern systems
- Simplest: try connect → spawn if fails → retry. No systemd required.

**Protocol:**
- Docker: HTTP over Unix socket (heavy)
- Core Lightning, Suricata: JSON-RPC 2.0 over Unix sockets
- Simplest: newline-delimited JSON (NDJSON) — no framing, human-readable

**State persistence:**
- Docker: JSON metadata per container in `/var/lib/docker/containers/`
- Redis: AOF + RDB snapshots
- Simplest for <50 entries: file-per-container JSON with atomic write (temp + rename)

**Liveness detection:**
- Socket connect attempt (proves responsiveness) preferred over PID files (go stale)

### Python Implementation

**asyncio** is the clear choice:
- `asyncio.start_unix_server()` — zero dependencies, built-in
- `StreamReader`/`StreamWriter` for line-delimited JSON
- Port watchers as `asyncio.create_task()` (not threads)
- Signal handlers via `loop.add_signal_handler()`
- Estimated: ~300-500 lines total

**Daemonizing:** Don't. Modern approach is foreground process managed by systemd or spawned by CLI. Skip python-daemon/double-fork entirely.

### Constraints and Requirements

- Zero new dependencies (Python 3.12+ stdlib only)
- Backward compatible with existing `~/.dsm/` session metadata
- Must support graceful degradation (CLI works without daemon)

## Findings

1. **Daemon provides exactly three things** files cannot: single-process coordination, liveness (watching), and push notifications.
2. **asyncio + Unix socket + NDJSON** is the simplest proven stack for a Python daemon.
3. **Lazy start** (spawn on first CLI use) eliminates operational overhead of managing a service.
4. **File-per-container JSON** with atomic writes is how Docker itself stores container metadata.
5. **Socket liveness** (try connect) is more reliable than PID files.

## Open Questions

- Checkpoint interval for periodic persistence (proposed: 30s)
- Whether `dsm daemon` should be a visible or hidden subcommand

## Next Steps

Architecture and specification documents capture the structural decisions. Plan will sequence the implementation.
