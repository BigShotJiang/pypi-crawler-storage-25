---
type: decisions
project: dsm
lifecycle_phase: Alpha
last_updated: "2026-04-13"
---

## Tech Stack

- **Python 3.12+** — single-language codebase, stdlib-only runtime. No external dependencies for the core package. Chosen for rapid development and broad deployment compatibility.
- **hatchling** — build backend. Lightweight, PEP 517 compliant.
- **uv** — package/env manager. Fast, replaces pip+venv.
- **pytest** — test framework. Standard Python testing.

## Architecture

- **CLI + daemon model** — CLI handles user-facing commands synchronously. Daemon runs as async background process for continuous operations (port watching, event broadcasting).
- **Unix socket IPC** — CLI communicates with daemon via Unix domain socket using NDJSON protocol. Simple, zero-dependency, debuggable with netcat.
- **Per-container JSON registry** — each container's state stored as a separate JSON file in ~/.dsm/registry/. Atomic writes prevent corruption. Survives daemon restarts.
- **Session-as-directory** — each session gets ~/.dsm/{slug}/ with meta.json and socket/logs. Simple filesystem-based state with no database.

## Libraries & Dependencies

Zero runtime dependencies — stdlib only. This is a deliberate constraint:
- Ensures `pipx install` works without dependency conflicts
- Reduces attack surface
- Makes the tool portable to any Python 3.12+ environment

Dev dependencies: pytest only.

External tool dependencies (not Python packages):
- **Docker** — container management
- **dtach** — terminal session detachment (like tmux/screen but minimal)
- **socat** — port forwarding via TCP proxy
- **git** — worktree management
- **ssh** — remote session transport

## Patterns & Conventions

- **NDJSON protocol** — one JSON object per newline for all daemon communication. Supports request/response and streaming events (watch/unwatch).
- **3-tier worktree strategy** — when creating worktrees, tries: (1) track remote branch, (2) checkout existing local branch, (3) create new branch. Handles all common git states without user intervention.
- **Best-effort daemon registration** — container creation doesn't fail if daemon is unreachable. Falls back to direct disk writes.
- **Config profiles** — named configurations support different development contexts (default, minimal, isolated, coder-ui).
- **Agent context injection** — containers receive CLAUDE.md with networking info and DSM environment variables for tool integration.

## Lifecycle Phase

Alpha — building fast, breaking changes acceptable. Focus on core functionality (sessions, port forwarding, worktree isolation). No backward compatibility guarantees yet.
