---
type: quality
project: dsm
last_updated: "2026-04-13"
---

## Performance

- Port scanning via /proc/net/tcp: ~0.1ms per container (direct file read, no subprocess)
- PortWatcher poll interval: 2 seconds default
- Daemon socket timeout: 5 seconds for client connections
- socat forward startup: synchronous subprocess spawn
<!-- TODO: define p50/p95 targets for CLI command latency -->

## Scalability

- Designed for single-developer workstation use
- Typical load: 1-5 concurrent containers, 1-20 forwarded ports
- Registry is per-container JSON files — scales with filesystem, no contention
<!-- TODO: define upper bounds for container/forward counts -->

## Availability

- Daemon auto-starts when CLI needs it (ensure_daemon_running with 6 retries, 0.5s backoff)
- CLI falls back to direct disk registry reads when daemon unavailable
- Graceful shutdown on SIGTERM/SIGINT — persists all state before exit
<!-- TODO: define recovery behavior for orphaned socat processes -->

## Security

- No authentication on Unix socket (localhost only, standard for dev tools)
- Config env vars expanded from host environment — ${VAR} must be set or hard fail
- SSH authorized_keys mounted read-only into containers
- Anthropic API key discovery searches env, config files, and shell rc files
<!-- TODO: define policy for credential handling in agent-context CLAUDE.md -->

## Observability

- Daemon logs to ~/.dsm/daemon.log (Python logging, INFO level)
- Session output captured to ~/.dsm/{id}/output.log via script command
- PortWatcher logs port adds/removes at DEBUG, errors at WARNING
- No structured metrics or tracing currently
<!-- TODO: define log rotation policy -->
