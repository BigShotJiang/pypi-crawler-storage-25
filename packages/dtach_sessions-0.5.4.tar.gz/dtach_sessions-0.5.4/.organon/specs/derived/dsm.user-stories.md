---
type: derived
kind: user-stories
derived_from:
  - ../container-lifecycle.workflow.yaml
  - ../local-session.workflow.yaml
  - ../ssh-session.workflow.yaml
  - ../port-forwarding.workflow.yaml
  - ../daemon-protocol.workflow.yaml
  - ../worktree.workflow.yaml
source_hash: 820efe4db7f88ab3
last_derived: "2026-04-13"
---

## Generated Stories

<!-- This section is overwritten on each re-derive. Do not edit manually. -->

### Create Container Development Session

**As a** developer, **I want to** spin up an isolated container session for a repository branch, **so that** I can develop and run AI agents in a sandboxed environment with automatic port forwarding.

**Steps:**
1. Run `dsm container -t TITLE REPO_PATH BRANCH` — CLI validates repo, loads config profile
2. CLI creates git worktree on host for the specified branch
3. CLI runs `docker run` with workspace mount, volumes, ports, env vars, agent context
4. CLI registers container with daemon for port watching
5. CLI execs into container with default command (claude --dangerously-skip-permissions)

**Preconditions:** Repository path exists and is a git repo. Docker is running.
**CLI commands:** `dsm container`

### Resume Existing Session

**As a** developer, **I want to** reattach to a previously created session, **so that** I can continue where I left off without losing context.

**Steps:**
1. Run `dsm resume ID` — CLI finds session by ID (prefix match)
2. For containers: if dead, recreate with original settings; if alive, exec into it
3. For local/ssh: if socket dead, recreate with original command/cwd; if alive, dtach -a

**Preconditions:** Session metadata exists in ~/.dsm/{id}/meta.json.
**CLI commands:** `dsm resume`

### Create Local Terminal Session

**As a** developer, **I want to** create a persistent local terminal session, **so that** I can run long-running commands that survive terminal disconnection.

**Steps:**
1. Run `dsm local -t "Title" -- command...` — CLI slugifies title, creates session directory
2. CLI launches command via dtach with output capture
3. Session persists across terminal close; resume with `dsm resume`

**Preconditions:** dtach is installed. Command is specified.
**CLI commands:** `dsm local`

### Create SSH Remote Session

**As a** developer, **I want to** create a persistent SSH session to a remote host, **so that** I can maintain long-running remote connections with keepalive and reattach support.

**Steps:**
1. Run `dsm ssh HOST` — CLI resolves host aliases, adds keepalive options
2. CLI launches SSH via dtach with output capture
3. Session persists; resume with `dsm resume`

**Preconditions:** dtach is installed. Remote host is reachable.
**CLI commands:** `dsm ssh`

### Monitor Container Ports in Real-Time

**As a** developer, **I want** ports opened inside my container to be automatically forwarded to the host, **so that** I can access development services without manual port mapping.

**Steps:**
1. Container is registered with daemon (happens automatically on `dsm container`)
2. PortWatcher polls /proc/net/tcp every 2 seconds
3. New non-loopback ports are auto-forwarded via socat
4. Removed ports have their forwards auto-cleaned up
5. Subscribe to real-time events via daemon `watch` command

**Preconditions:** Daemon is running. Container is registered.
**CLI commands:** (automatic — daemon-managed)

### Query Daemon Status and Container Info

**As a** developer, **I want to** list containers, ports, and forwards managed by the daemon, **so that** I can understand what's running and diagnose forwarding issues.

**Steps:**
1. `dsm list` — shows all sessions plus registry-only containers
2. Daemon `status` command — returns PID, uptime, container count, forward count
3. Daemon `list_ports` / `list_forwards` — returns detected ports and active forwards

**Preconditions:** None for `dsm list` (falls back to disk). Daemon running for daemon commands.
**CLI commands:** `dsm list`

### Clean Up Dead Sessions

**As a** developer, **I want to** remove all dead sessions in one command, **so that** I don't accumulate stale session directories and stopped containers.

**Steps:**
1. Run `dsm clean` — iterates all sessions, checks liveness
2. Dead container sessions: stop and remove Docker container, delete session directory
3. Dead local/ssh sessions: delete session directory

**Preconditions:** None.
**CLI commands:** `dsm clean`

## Developer Stories

<!-- This section is preserved across re-derives. Add human-authored stories here. -->
