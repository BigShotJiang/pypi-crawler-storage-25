---
type: derived
kind: state
derived_from:
  - ../container-lifecycle.workflow.yaml
  - ../local-session.workflow.yaml
  - ../ssh-session.workflow.yaml
  - ../port-forwarding.workflow.yaml
  - ../daemon-protocol.workflow.yaml
  - ../worktree.workflow.yaml
  - ../container-entry.model.yaml
source_hash: f280272689be0a42
last_derived: "2026-04-13"
---

## Container State Machine

The ContainerEntry model has an explicit `status` field with values `[running, stopped, unknown]`. Container state transitions are driven by Docker lifecycle operations and daemon registration.

### States

| State | Owner | Description |
|-------|-------|-------------|
| `(none)` | Container | Container does not exist |
| `running` | ContainerEntry | Docker container is running, registered in daemon |
| `stopped` | ContainerEntry | Container exists but not running (exited, paused) |
| `unknown` | ContainerEntry | Container status cannot be determined |

### Transitions

| From | To | Trigger | Workflow |
|------|----|---------|----------|
| `(none)` | `running` | create-container | container-lifecycle |
| `stopped` | `running` | reuse-existing (docker start) | container-lifecycle |
| `running` | `running` | reuse-existing (already running) | container-lifecycle |
| `running` | `(none)` | remove-session (docker rm -f) | container-lifecycle |
| `stopped` | `(none)` | clean-dead (docker rm -f) | container-lifecycle |
| `running` | `stopped` | Docker stops externally | (external) |
| `(none)` | `running` | resume-container (recreate dead) | container-lifecycle |

### Illegal Joint States

- A container in `running` state with no matching daemon PortWatcher entry — the daemon should always track running containers. However, best-effort registration means this can transiently occur.
- A container in `(none)` state with an active ForwardInfo — forwards should be cleaned up when the container is removed. PortWatcher handles this via handle-container-gone.

### Orphan States

- `unknown` — declared in model but no workflow explicitly transitions to or from this state. # SPEC GAP: "unknown" status appears in model values but has no workflow trigger

---

## Session State Machine

Sessions (local, ssh, container) use a filesystem-based existence model. No explicit status field — status is derived from socket/container liveness.

### States

| State | Owner | Description |
|-------|-------|-------------|
| `(none)` | Session | Session does not exist |
| `live` | Session | dtach socket is alive (local/ssh) or container is running |
| `dead` | Session | dtach socket is gone or container is stopped |

### Transitions

| From | To | Trigger | Workflow |
|------|----|---------|----------|
| `(none)` | `live` | create-local / create-ssh / create-container | local-session / ssh-session / container-lifecycle |
| `live` | `dead` | Process exits or container stops | (external) |
| `dead` | `live` | resume (recreates session/container) | local-session / container-lifecycle |
| `dead` | `(none)` | clean-dead / remove-session | container-lifecycle / local-session |
| `live` | `(none)` | remove-session | container-lifecycle |

### Illegal Joint States

- A session directory existing without meta.json — load_meta returns None and the session is ignored.
- Multiple sessions with the same ID — prevented by unique_id() slug dedup (SESSION-01 invariant).

---

## Port Forward State Machine

Port forwards are existential — they exist while socat is running and cease when terminated. Managed by PortWatcher auto-forwarding or manual daemon commands.

### States

| State | Owner | Description |
|-------|-------|-------------|
| `(none)` | PortForward | No forward exists for this container:port |
| `active` | ForwardHandle | socat process is running, traffic is forwarded |

### Transitions

| From | To | Trigger | Workflow |
|------|----|---------|----------|
| `(none)` | `active` | auto-forward-new-port | port-forwarding |
| `(none)` | `active` | manual-start-forward | port-forwarding |
| `active` | `(none)` | auto-unforward-removed-port | port-forwarding |
| `active` | `(none)` | manual-stop-forward | port-forwarding |
| `active` | `(none)` | handle-container-restart (stale IPs) | port-forwarding |
| `active` | `(none)` | handle-container-gone | port-forwarding |

### Illegal Joint States

- Two active forwards for the same container:port — start_forward appends to _active_forwards without dedup check. # SPEC GAP: no explicit guard against duplicate forwards for the same port
- An active forward with a dead socat process — list_forwards() prunes dead processes, but between prune cycles a stale handle could exist transiently.
