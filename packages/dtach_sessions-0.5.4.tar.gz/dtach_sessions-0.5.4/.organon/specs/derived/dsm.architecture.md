---
type: derived
kind: architecture
derived_from:
  - ../decisions.md
  - ../../STRUCTURE.md
  - ../cli.contract.yaml
  - ../container-entry.model.yaml
  - ../port-info.model.yaml
  - ../forward-info.model.yaml
  - ../session.model.yaml
  - ../services.yaml
source_hash: 2df8a0911d5304dd
last_derived: "2026-04-13"
---

## System Overview

dsm (dtach session manager) is a command-line tool for creating and managing persistent detachable terminal sessions across local, SSH, and Docker container environments. It consists of a CLI front-end and an async daemon back-end connected via Unix socket IPC. The daemon provides automatic port forwarding for containerized services and real-time event broadcasting to subscribed clients.

## Services & Components

### CLI (`src/dsm/cli.py`)

- **Responsibility:** User-facing command dispatch, session lifecycle management, Docker orchestration, git worktree setup, config profile loading
- **Technology:** Python 3.12+ stdlib, argparse, subprocess
- **Communication:** Sends NDJSON commands to daemon via Unix socket (DsmClient). Falls back to direct disk I/O when daemon unavailable.

### Daemon (`src/dsm/daemon.py`)

- **Responsibility:** Long-running background process. Manages container registry, dispatches NDJSON commands, broadcasts events to subscribers, orchestrates PortWatcher.
- **Technology:** Python asyncio, Unix domain socket server
- **Communication:** Listens on `~/.dsm/dsm.sock`. Speaks NDJSON request/response and streaming events.

### Port Module (`src/dsm/ports.py`)

- **Responsibility:** Port detection inside containers (via /proc/net/tcp), socat-based port forwarding, PortWatcher background polling.
- **Technology:** Linux /proc filesystem, socat subprocess, asyncio tasks
- **Communication:** Called by daemon. Runs blocking I/O in executor threads.

### Registry (`src/dsm/registry.py`)

- **Responsibility:** Persistent container metadata. CRUD operations on ContainerEntry, PortInfo, ForwardInfo.
- **Technology:** Python dataclasses, JSON file storage
- **Communication:** In-process library. Atomic file writes (tmp + rename).

## Communication

```
User ──► CLI ──► DsmDaemon (Unix socket, NDJSON)
                    │
                    ├──► ContainerRegistry (in-process, JSON files)
                    │
                    └──► PortWatcher (asyncio task)
                              │
                              ├──► /proc/$PID/net/tcp (file read)
                              ├──► docker inspect (subprocess)
                              └──► socat (subprocess, long-running)

CLI ──► Docker (subprocess: run, exec, start, stop, rm, inspect)
CLI ──► dtach (execvp: session create/resume)
CLI ──► git (subprocess: worktree, clone, ls-remote)
```

- **CLI ↔ Daemon:** NDJSON over Unix domain socket (`~/.dsm/dsm.sock`). Request: `{"cmd": "...", ...}`. Response: `{"id": null, "result": ..., "error": ...}`. Events: `{"id": "...", "event": "...", "data": {...}}`.
- **CLI ↔ Docker:** Direct subprocess calls for container lifecycle.
- **CLI ↔ dtach:** `os.execvp` replaces the CLI process with dtach for session management.
- **Daemon ↔ Containers:** `docker exec` and `docker inspect` for port scanning and IP resolution.
- **Daemon ↔ Host:** socat processes for TCP port forwarding from host to container bridge IP.

## Data Flow

### Container Session Creation

1. CLI validates repo path, loads config profile
2. CLI builds Docker run command (workspace mount, volumes, ports, env vars, agent context)
3. CLI calls `docker run` to create container
4. CLI registers container with daemon via `register_container` NDJSON command
5. Daemon adds container to PortWatcher
6. PortWatcher begins polling /proc/$PID/net/tcp every 2 seconds
7. When ports detected, PortWatcher auto-starts socat forwards
8. Daemon broadcasts `port_added` events to subscribers
9. CLI execs into container with `docker exec`

### Port Auto-Forwarding

1. PortWatcher polls /proc/$PID/net/tcp for each watched container
2. Diffs current ports against previous scan
3. For new non-loopback ports: spawns `socat TCP-LISTEN:$host,fork,reuseaddr TCP:$ip:$port`
4. For removed ports: terminates socat process
5. Updates registry (ForwardInfo) and fires on_change callback
6. Daemon translates PortChange events to `port_added`/`port_removed` and broadcasts

## Deployment

- **Single host:** dsm is a local development tool. CLI and daemon run on the same machine.
- **No containers for dsm itself:** dsm runs natively on the host. It manages Docker containers for the user's development sessions.
- **Package distribution:** Published to PyPI via GitHub Actions on version tags. Installed via `pipx install dtach-sessions` or `uv tool install dtach-sessions`.
- **Runtime directories:**
  - `~/.dsm/` — sessions, config, daemon socket, registry, agent context
  - `~/.dsm/dsm.sock` — daemon Unix socket
  - `~/.dsm/registry/` — per-container JSON state files
- **External dependencies:** Docker, dtach, socat, git must be installed on the host.
- **Platform:** Linux only (port detection via /proc). # SPEC GAP: macOS/Windows support documented as "not yet implemented" in decisions but no timeline or spec
