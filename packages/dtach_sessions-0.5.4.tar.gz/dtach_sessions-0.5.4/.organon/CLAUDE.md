# Organon - Agent Instructions

Organon is project lifecycle infrastructure for AI-assisted development. It maintains alignment across four project surfaces — **specs, code, docs, and tests** — and provides the tools to detect and fix drift between them. Everything lives in the `.organon/` directory.

## How Organon Works

**Alignment is the core concern.** Four surfaces must stay in sync: specs define what the system should do, code implements it, tests verify it, docs describe it. When any surface drifts from the others, organon provides skills to detect the gap and fix it. Every skill serves one or more alignment edges between these surfaces.

**Specs use a 7+3 document model.** 7 primary types are generated from code (Workflow, Model, Invariants, Decisions, Quality, Contract, Screenshots) and 3 derived views are projected from primaries (State, Architecture, User Stories). All documents fall into 5 categories: Navigational (CLAUDE.md, STRUCTURE.md), Project (the 9 spec types), Sprint (plans, backlog), Framework (organon's own docs), and Working (dev-docs). Detail: `.organon/defaults/docs/user-guide/specs.md`

**`/align` is the single entry point.** It scans all alignment edges, builds (or updates) the alignment manifest at `.organon/alignment-manifest.json`, and reports where drift exists. The manifest is the persistent artifact — it records what was scanned, what drifted, and when. Subsequent `/align` calls read the manifest for an instant report and only re-scan stale surfaces.

**Skills follow analyze/report/fix.** Each skill analyzes alignment between surfaces, reports what's drifted, and fixes it (with user confirmation). Granular skills write their results back to the manifest when they complete. After a skill completes, suggest the logical next skill if adjacent edges likely drifted. Common chains follow paths through the alignment graph:
- **Assess all surfaces:** `/align` (all edges, builds manifest)
- **Ensure specs match code:** `/sync-specs-with-code` → `/validate-specs` (Code ↔ Specs)
- **Ensure docs match specs:** `/sync-docs-with-specs` (Specs ↔ Docs, Code ↔ Docs, STRUCTURE.md)
- **Ensure tests match specs:** `/sync-tests-with-specs` (generate tests, run them, classify gaps, iterate until converged)
- **Derive views from specs:** `/derive-views-from-specs` (State from Workflows, Architecture from Decisions+STRUCTURE+Contract+Model)
- **After sprint completion:** `/review-sprint` → `/merge-sprint-specs` → `/sync-docs-with-specs` (Sprint → Specs → Docs)
- **Sprint planning:** `/plan-sprint` (three-pass planning with spec awareness)

**Sprints structure larger work.** When work needs planning — multiple components, architectural decisions, research — capture conversational context and create a sprint via MCP tools (`create_sprint`). The planning pass uses `/plan-sprint` (three passes: structure, detail, review). Sprint execution then works through the plan. Sprints are the primary cause of drift: they change code, which puts it out of alignment with specs, docs, and tests. The sprint completion flow restores alignment.

**MCP tools are the runtime.** Prefer MCP tools over CLI commands for all programmatic operations — they're faster, return structured data, and track efficiency metrics. The CLI is for human use or operations not covered by MCP tools.

## Common Scenarios

- **Starting any project?** `/align` to assess all surfaces and build the alignment manifest, then `/sync-specs-with-code` to capture current state as specs (all 7 primary types).
- **Medium-complexity work?** Create a mini sprint — single doc in `.organon/mini-sprints/`. Read work mode: `.organon/defaults/definitions/work-modes/mini-sprint.md`
- **Starting structured work?** Capture context conversationally, create sprint via `create_sprint()`, then `/plan-sprint` (three passes: structure, detail, review).
- **Continuing a sprint?** `list_sprints()` to find it, then read sprint execution work mode: `.organon/defaults/definitions/work-modes/sprint-execution.md`
- **Quick fix or simple change?** Just do it — follow the standards below, commit with the right prefix.
- **Checking project health?** `/align` — reads manifest for instant report, re-scans only stale surfaces.
- **Specs out of sync?** `get_alignment_report()` to find gaps, then `/sync-tests-with-specs` to classify and fix.

## What's Available

### MCP Tools (always available)

Sprint management:
- `create_sprint`, `list_sprints`, `update_sprint_status`
- `parse_sprint_plan`, `get_executable_tasks`, `update_task_status`, `get_sprint_section`
- `get_current_sprint_context`, `get_all_sprints_summary`

Backlog: `list_backlog_items`, `get_backlog_item`

Queries: `query_workflows`, `query_work_modes`

Alignment & status: `get_alignment_report`, `get_project_status`

Specs: `preview_spec_merge`

Context tracking: `update_workflow_context`, `log_workflow_event`

**Reference:** `.organon/defaults/docs/reference/mcp-reference.md`

### Skills (user-invoked via /skill-name)

**12 skills in 3 categories:**

| Category | Skills |
|----------|--------|
| Alignment (6) | `/align`, `/sync-specs-with-code`, `/validate-specs`, `/derive-views-from-specs`, `/sync-tests-with-specs`, `/sync-docs-with-specs` |
| Sprint lifecycle (3) | `/plan-sprint`, `/review-sprint`, `/merge-sprint-specs` |
| Dev workflow (3) | `/checkpoint`, `/release`, `/release-check` |

### CLI (human use or via Bash)

`organon init`, `organon sprints`, `organon projects`, `organon logs`, `organon admin` (validate, align-scan, merge, structure, rules, archive, status)

**Reference:** `.organon/defaults/docs/reference/cli.md`

### Workflow Definitions (task-type guidance during sprint execution)

Each task type has a workflow guide: research, requirements, design, architecture, specify, implement, test, review, refactor, document, plan, plan-review, debug, doc-sync

**Location:** `.organon/defaults/definitions/workflows/`

## Structured Work

For work beyond quick ad-hoc tasks, organon provides three work modes:

**Mini Sprint** — Single-document tracking for medium-complexity work. Multiple steps, may span conversations, but doesn't need full sprint ceremony.
- Create a file in `.organon/mini-sprints/` using the template
- One doc covers description, thinking, plan, and log
- Read the full process: `.organon/defaults/definitions/work-modes/mini-sprint.md`

**Sprint Planning** — Creates a structured implementation plan through iterative research, design, and specification.
- Capture conversational context and create the sprint via `create_sprint()` MCP tool
- Planning pass: `/plan-sprint` (three passes: structure, detail, review)
- Read the full process: `.organon/defaults/definitions/work-modes/sprint-planning.md`

**Sprint Execution** — Executes the plan task-by-task with dependency tracking, parallel subagents, and status updates.
- Check if sprint exists: `list_sprints()` or search `.organon/sprints/`
- Read the full process: `.organon/defaults/definitions/work-modes/sprint-execution.md`

**Sprint status lifecycle:** Created → Next → Current → Completed | Paused

**Sprint guide:** `.organon/defaults/docs/user-guide/sprints.md`
**Backlog guide:** `.organon/defaults/docs/user-guide/backlog.md`

## Standards

Use the 4C's for all work:
- **Correct:** Work fulfills the objective
- **Concise:** Fewest words required to fulfill the other C's
- **Coherent:** Sound reasoning, clear in content and structure
- **Consistent:** No contradictions

**Implementation rules:**
- **NEVER** create mocks, stubs, placeholders, or fallbacks that return fake data
- **ALWAYS** implement the real solution OR fail explicitly with a clear error message
- Test before claiming it works
- Lean testing: golden master snapshots, integration workflows, unit tests for pure functions only
- Icons only for ✓ and ✗

**Commit format:**
- Sprint work: `feat(sprint-NN): Description`
- Non-sprint: `bugfix:`, `docs:`, `chore:`, `refactor:`, `feat:`

**Context tracking:** Call `update_workflow_context` MCP tool when starting or switching work.

## File Locations

- **This file:** `.organon/CLAUDE.md`
- **Alignment manifest:** `.organon/alignment-manifest.json`
- **Project config:** `.organon/config.yaml`
- **Mini sprints:** `.organon/mini-sprints/`
- **Sprints:** `.organon/sprints/`
- **Backlog:** `.organon/sprints/backlog.md`
- **Specs (primary):** `.organon/specs/`
- **Specs (derived):** `.organon/specs/derived/`
- **Validation rules:** `.organon/rules/`
- **Dev docs:** `.organon/dev-docs/` (analysis, archive, incidents, reference, research)
- **Framework user guides:** `.organon/defaults/docs/user-guide/`
- **Framework reference:** `.organon/defaults/docs/reference/`
- **Work mode definitions:** `.organon/defaults/definitions/work-modes/`
- **Workflow definitions:** `.organon/defaults/definitions/workflows/`
- **Structure map:** `.organon/STRUCTURE.md`
- **Workflow tracking:** `.organon/current-context.json`
- **Alignment architecture:** `.organon/dev-docs/design-alignment-architecture.md`
