# dsm - Structure Manifest

## Purpose

dtach session manager — a Python CLI tool for creating and managing persistent detachable terminal sessions across local, SSH, and Docker container environments. Provides a background daemon for automatic port forwarding and container lifecycle management. Zero runtime dependencies (stdlib only).

## Navigation

- **CLAUDE.md** — Project instructions, architecture overview, development commands
- **.organon/CLAUDE.md** — Organon framework instructions and alignment workflow
- **src/dsm/cli.py** — CLI entry point and all user-facing commands
- **src/dsm/daemon.py** — Async daemon with NDJSON protocol
- **config.example.json** — Configuration profiles reference
- **pyproject.toml** — Project metadata, dependencies, entry point

## Directory Structure

```
dsm/
├── .claude/
│   └── skills/                       # 12 Claude Code alignment and dev workflow skills
├── .github/
│   └── workflows/                    # CI — PyPI publish on version tags
├── .organon/                         # Organon project workspace
│   ├── config.yaml                       # Organon project configuration
│   ├── CLAUDE.md                         # Framework instructions
│   ├── STRUCTURE.md                      # This file
│   ├── defaults/                         # Reference templates, definitions, docs
│   ├── dev-docs/
│   │   └── design/                       # Design documents (daemon architecture)
│   ├── mini-sprints/                     # Medium-complexity work tracking
│   ├── rules/                            # Validation rules
│   │   ├── backlog/                          # Backlog format rules
│   │   ├── git_hygiene/                      # Git hygiene checks
│   │   └── python/                           # Python and FastAPI rules
│   ├── specs/                            # Spec documents (7 primary types)
│   │   └── derived/                          # State, architecture, user-stories views
│   └── sprints/                          # Sprint planning and execution
│       └── 01_daemon_Completed/              # Completed daemon implementation sprint
├── src/
│   └── dsm/                          # Main Python package
│       ├── __init__.py
│       ├── cli.py                        # CLI entry point (1600+ lines)
│       ├── daemon.py                     # Async daemon (539 lines)
│       ├── ports.py                      # Port detection and forwarding (651 lines)
│       └── registry.py                   # Persistent container registry (208 lines)
└── tests/                            # pytest test suite (6 modules, 147 tests)
    ├── test_cli_daemon.py
    ├── test_config.py
    ├── test_daemon.py
    ├── test_integration_daemon.py
    ├── test_ports.py
    └── test_registry.py
```

## Module Responsibilities

**src/dsm/cli.py** — CLI entry point. Argument parsing, session lifecycle (create/resume/list/clean/rm), Docker orchestration (container creation, worktree setup, volume/port/env building), config profiles, DsmClient (synchronous NDJSON over Unix socket), daemon lazy-start, SSH alias management, agent context injection.

**src/dsm/daemon.py** — Background daemon. Async Unix socket server, NDJSON command dispatch (11 commands), event subscriptions (watch/unwatch), PortWatcher integration, container registry management, graceful shutdown with state persistence.

**src/dsm/registry.py** — Persistent container state. ContainerEntry, PortInfo, ForwardInfo dataclasses. Per-container JSON files with atomic writes (tmp + rename). CRUD operations on in-memory dict backed by ~/.dsm/registry/.

**src/dsm/ports.py** — Port detection and forwarding. Reads /proc/$PID/net/tcp for container port scanning, socat-based TCP forwarding, PortWatcher background polling (2s interval), auto-forward/unforward on port changes, container restart detection via IP change.

## Runtime Paths

- `~/.dsm/dsm.sock` — Daemon Unix socket
- `~/.dsm/registry/` — Per-container JSON files (persistent across daemon restarts)
- `~/.dsm/config.json` — User configuration (named profiles)
- `~/.dsm/{session-id}/` — Session directories (meta.json, socket, output.log)
- `~/.dsm/aliases.json` — SSH host aliases
- `~/.dsm/agent-context/` — Generated CLAUDE.md files mounted into containers
- `~/.dsm/daemon.log` — Daemon log output

## Integration Points

- CLI commands connect to the daemon via DsmClient over the Unix socket
- If the daemon is unreachable, CLI falls back to reading registry JSON files from disk
- `ensure_daemon_running` spawns the daemon as `sys.executable -m dsm.daemon` if no socket exists
- PortWatcher runs inside the daemon and broadcasts port change events to subscribed clients
- Container creation injects DSM environment variables and agent context CLAUDE.md
- Git worktrees created on host (for standard/bare repos) and inside containers (via docker exec)

## Development Status

Active development. Daemon sprint (01) completed — full daemon with port forwarding, registry, and event subscriptions. Current version: 0.4.0. Published to PyPI via GitHub Actions. Platform: Linux only (macOS/Windows port detection not yet implemented).
