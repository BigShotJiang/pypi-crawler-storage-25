# {{cookiecutter.project_name}} - Repository Structure

**Type:** Full Stack Web Application
**Purpose:** {{cookiecutter.project_description}}

## Navigation

### Key Files
- **CLAUDE.md** - Project standards and agent instructions (start here)
- **README.md** - Setup and usage guide
- **This file** - Directory structure and navigation

### Quick Links
- Backend: `backend/src/{{cookiecutter.project_slug}}/`
- Frontend: `frontend/src/`
- API Docs: `http://localhost:8000/docs` (when running)
- Frontend Dev: `http://localhost:5173` (when running)

## Directory Structure

```
{{cookiecutter.project_slug}}/
├── backend/                            # FastAPI application
│   ├── src/{{cookiecutter.project_slug}}/
│   │   ├── api/                       # API route handlers
│   │   ├── models/                    # Database models (SQLAlchemy)
│   │   ├── services/                  # Business logic
│   │   ├── core/                      # Config, dependencies, utilities
│   │   └── main.py                    # Application entry point
│   ├── tests/                         # Backend tests
│   ├── alembic/                       # Database migrations
│   ├── pyproject.toml                 # Python dependencies
│   └── README.md                      # Backend documentation
│
├── frontend/                           # React application
│   ├── src/
│   │   ├── components/                # Reusable React components
│   │   ├── pages/                     # Page components
│   │   ├── hooks/                     # Custom React hooks
│   │   ├── lib/                       # Utilities and helpers
│   │   ├── App.tsx                    # Main app component
│   │   ├── main.tsx                   # Entry point
│   │   └── index.css                  # Global styles
│   ├── public/                        # Static assets
│   ├── package.json                   # Node dependencies
│   ├── vite.config.ts                 # Vite configuration
│   ├── tsconfig.json                  # TypeScript configuration
│   └── README.md                      # Frontend documentation
│
├── dev-docs/                          # Development documentation
│   └── sprints/                       # Sprint planning and tracking
│
├── CLAUDE.md                          # Organon agent instructions
├── STRUCTURE.md                       # This file
├── README.md                          # Project overview and setup
├── .gitignore                         # Git ignore patterns
{% if cookiecutter.include_docker == 'y' -%}
├── docker-compose.yml                 # Container orchestration
├── Dockerfile.backend                 # Backend container
└── Dockerfile.frontend                # Frontend container
{% endif -%}
```

## Module Responsibilities

### Backend (`backend/src/{{cookiecutter.project_slug}}/`)

**main.py** - Application entry
- FastAPI app initialization
- Middleware configuration (CORS, etc.)
- Router inclusion
- Startup/shutdown events

**api/** - API Routes
- REST endpoint definitions
- Request/response validation (Pydantic)
- Route organization by feature

**models/** - Database Models
- SQLAlchemy ORM models
- Database table definitions
- Relationships and constraints

**services/** - Business Logic
- Core application logic
- Database operations
- External API integrations

**core/** - Configuration & Utilities
- Settings management (pydantic-settings)
- Database connection handling
- Dependency injection
- Shared utilities

### Frontend (`frontend/src/`)

**components/** - React Components
- Reusable UI components
- Component-specific styles
- shadcn/ui components

**pages/** - Page Components
- Top-level page components
- Route-specific views
- Page layouts

**hooks/** - Custom Hooks
- Reusable React hooks
- State management
- Side effect handling

**lib/** - Utilities
- Helper functions
- API client
- Type definitions

### Development Documentation (`dev-docs/`)

**sprints/** - Sprint Tracking
- Sprint planning documents
- Implementation tracking
- Retrospectives

## Development Workflow

### Backend Development
1. Activate virtual environment
2. Run migrations: `uv run alembic upgrade head`
3. Start server: `uv run uvicorn {{cookiecutter.project_slug}}.main:app --reload`
4. Access API docs: `http://localhost:8000/docs`

### Frontend Development
1. Install dependencies: `npm install`
2. Start dev server: `npm run dev`
3. Access frontend: `http://localhost:5173`

### Database Migrations
1. Make model changes in `backend/src/{{cookiecutter.project_slug}}/models/`
2. Generate migration: `uv run alembic revision --autogenerate -m "description"`
3. Review generated migration in `backend/alembic/versions/`
4. Apply migration: `uv run alembic upgrade head`

### Testing
- Backend: `cd backend && uv run pytest`
- Frontend: `cd frontend && npm test`

## Integration Points

### API Communication
- Frontend calls backend via `/api` prefix
- Vite proxy configured for development
- Production uses environment variable `VITE_API_URL`

### Database
{% if cookiecutter.use_postgresql == 'y' -%}
- PostgreSQL database
{% else -%}
- SQLite database (development)
{% endif -%}
- Async SQLAlchemy for database operations
- Alembic for schema migrations

### Authentication (when implemented)
- JWT-based authentication
- Token storage in frontend (localStorage or cookies)
- Protected routes and API endpoints

## Organon Integration

This project uses Organon for development workflow management:

```bash
# Create sprints
organon sprints create <number> <name>

# List sprints
organon sprints list

# Scan codebase
organon scan .

# Validate structure
organon validate .
```

See `CLAUDE.md` for detailed development standards and sprint workflows.

---

**Version:** {{cookiecutter.version}}
