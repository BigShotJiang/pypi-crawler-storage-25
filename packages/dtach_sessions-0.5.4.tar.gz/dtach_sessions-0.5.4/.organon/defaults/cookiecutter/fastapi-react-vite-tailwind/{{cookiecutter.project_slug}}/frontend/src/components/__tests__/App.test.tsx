import { describe, it, expect } from 'vitest'
import { render, screen } from '@testing-library/react'
import App from '../../App'

describe('App', () => {
  it('renders project name', () => {
    render(<App />)
    const heading = screen.getByRole('heading', { level: 1 })
    expect(heading).toBeInTheDocument()
    expect(heading).toHaveTextContent('{{cookiecutter.project_name}}')
  })

  it('renders project description', () => {
    render(<App />)
    expect(screen.getByText('{{cookiecutter.project_description}}')).toBeInTheDocument()
  })

  it('renders home page content', () => {
    render(<App />)
    // Verify the main container structure
    const container = screen.getByRole('heading').closest('div')
    expect(container).toHaveClass('text-center')
  })
})
