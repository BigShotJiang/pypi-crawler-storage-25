"""Tests for health check endpoints."""
import pytest
from fastapi.testclient import TestClient


def test_health_check(client: TestClient):
    """Test health check endpoint returns healthy status."""
    response = client.get("/api/health")

    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert "service" in data


def test_health_check_structure(client: TestClient):
    """Test health check response has correct structure."""
    response = client.get("/api/health")
    data = response.json()

    # Verify required fields
    assert isinstance(data, dict)
    assert "status" in data
    assert "service" in data

    # Verify field types
    assert isinstance(data["status"], str)
    assert isinstance(data["service"], str)
