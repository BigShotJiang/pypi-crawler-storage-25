# {{cookiecutter.project_name}}

{{cookiecutter.project_description}}

## Tech Stack

### Backend
- **FastAPI** - Modern Python web framework
- **SQLAlchemy** - ORM with async support
- **Alembic** - Database migrations
{% if cookiecutter.use_postgresql == 'y' -%}
- **PostgreSQL** - Production database
{% else -%}
- **SQLite** - Development database
{% endif -%}
- **Pydantic** - Data validation
- **uvicorn** - ASGI server

### Frontend
- **Vite** - Build tool
- **React** - UI library
- **TypeScript** - Type safety
- **shadcn/ui** - Component library
- **TanStack Query** - Data fetching
- **React Router** - Routing

## Project Structure

```
{{cookiecutter.project_slug}}/
├── backend/                    # FastAPI application
│   ├── src/{{cookiecutter.project_slug}}/
│   │   ├── api/               # API routes
│   │   ├── models/            # Database models
│   │   ├── services/          # Business logic
│   │   ├── core/              # Config, dependencies
│   │   └── main.py            # Application entry
│   ├── tests/                 # Backend tests
│   ├── alembic/               # Database migrations
│   └── pyproject.toml         # Python dependencies
├── frontend/                   # React application
│   ├── src/
│   │   ├── components/        # React components
│   │   ├── pages/             # Page components
│   │   ├── hooks/             # Custom hooks
│   │   ├── lib/               # Utilities
│   │   └── App.tsx            # App entry
│   ├── public/                # Static assets
│   └── package.json           # Node dependencies
├── dev-docs/sprints/          # Sprint tracking
{% if cookiecutter.include_docker == 'y' -%}
├── docker-compose.yml         # Container orchestration
{% endif -%}
├── CLAUDE.md                  # Organon agent instructions
└── STRUCTURE.md               # Navigation guide
```

## Setup

### Prerequisites
- Python {{cookiecutter.python_version}}+
- Node.js 18+
- uv (recommended) or pip
{% if cookiecutter.use_postgresql == 'y' -%}
- PostgreSQL 14+
{% endif -%}

### Installation

#### Backend Setup

```bash
cd backend

# Using uv (recommended)
uv sync

# Or using pip
pip install -e .

# Run database migrations
uv run alembic upgrade head

# Start development server
uv run uvicorn {{cookiecutter.project_slug}}.main:app --reload
```

Backend will be available at `http://localhost:8000`
API documentation at `http://localhost:8000/docs`

#### Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

Frontend will be available at `http://localhost:5173`

{% if cookiecutter.include_docker == 'y' -%}
### Docker Setup

```bash
# Build and start all services
docker-compose up --build

# Stop services
docker-compose down
```

Services:
- Backend: `http://localhost:8000`
- Frontend: `http://localhost:5173`
{% if cookiecutter.use_postgresql == 'y' -%}
- PostgreSQL: `localhost:5432`
{% endif -%}
{% endif -%}

## Development

### Backend Development

```bash
# Run tests
uv run pytest

# Type checking
uv run mypy src

# Linting
uv run ruff check src

# Format code
uv run ruff format src

# Create new migration
uv run alembic revision --autogenerate -m "description"

# Apply migrations
uv run alembic upgrade head
```

### Frontend Development

```bash
# Run tests
npm test

# Type checking
npm run type-check

# Linting
npm run lint

# Format code
npm run format

# Build for production
npm run build
```

## Environment Variables

Create `.env` files in backend and frontend directories:

### Backend `.env`
```bash
# Database
{% if cookiecutter.use_postgresql == 'y' -%}
DATABASE_URL=postgresql://user:password@localhost:5432/{{cookiecutter.project_slug}}
{% else -%}
DATABASE_URL=sqlite:///./{{cookiecutter.project_slug}}.db
{% endif -%}

# API Keys (example)
# ANTHROPIC_API_KEY=your_key_here
# OPENAI_API_KEY=your_key_here

# Security
SECRET_KEY=your-secret-key-change-in-production
DEBUG=true

# CORS
CORS_ORIGINS=http://localhost:5173,http://localhost:3000
```

### Frontend `.env`
```bash
VITE_API_URL=http://localhost:8000
```

## API Endpoints

### Core Endpoints
- `GET /api/health` - Health check
- `GET /api/docs` - API documentation (Swagger UI)
- `GET /api/redoc` - API documentation (ReDoc)

### Example Endpoints
- `GET /api/items` - List items
- `POST /api/items` - Create item
- `GET /api/items/{id}` - Get item
- `PUT /api/items/{id}` - Update item
- `DELETE /api/items/{id}` - Delete item

## Organon Integration

This project is integrated with Organon for sprint management:

```bash
# Create a new sprint
organon sprints create <number> <name>

# List sprints
organon sprints list

# Scan codebase
organon scan .

# Validate structure
organon validate .
```

See `CLAUDE.md` for detailed development standards and workflows.

## Testing

### Backend Tests
```bash
cd backend
uv run pytest
uv run pytest --cov=src  # With coverage
```

### Frontend Tests
```bash
cd frontend
npm test
npm test -- --coverage  # With coverage
```

## Deployment

### Production Build

```bash
# Build frontend
cd frontend
npm run build

# Backend uses uvicorn in production mode
cd backend
uv run uvicorn {{cookiecutter.project_slug}}.main:app --host 0.0.0.0 --port 8000
```

{% if cookiecutter.include_docker == 'y' -%}
### Docker Deployment

```bash
# Build for production
docker-compose -f docker-compose.prod.yml up --build -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```
{% endif -%}

## Contributing

1. Create a feature branch
2. Make changes following the code style
3. Write/update tests
4. Update documentation
5. Submit pull request

## License

{{cookiecutter.project_name}} - Copyright (c) 2025 {{cookiecutter.author_name}}

---

**Built with Organon** - Project lifecycle management framework
