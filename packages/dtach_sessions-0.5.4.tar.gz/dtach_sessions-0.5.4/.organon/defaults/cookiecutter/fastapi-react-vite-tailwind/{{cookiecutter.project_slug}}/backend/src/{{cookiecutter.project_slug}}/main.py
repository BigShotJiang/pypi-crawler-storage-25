"""Main FastAPI application."""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from {{cookiecutter.project_slug}}.core.config import settings
from {{cookiecutter.project_slug}}.api import health

app = FastAPI(
    title="{{cookiecutter.project_name}} API",
    description="{{cookiecutter.project_description}}",
    version="{{cookiecutter.version}}",
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router, prefix="/api", tags=["health"])


@app.on_event("startup")
async def startup_event() -> None:
    """Initialize application on startup."""
    pass


@app.on_event("shutdown")
async def shutdown_event() -> None:
    """Cleanup on shutdown."""
    pass
