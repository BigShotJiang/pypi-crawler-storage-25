"""Pytest configuration and fixtures."""
import pytest
from fastapi.testclient import TestClient

from {{cookiecutter.project_slug}}.main import app


@pytest.fixture
def client():
    """Create a test client."""
    return TestClient(app)
