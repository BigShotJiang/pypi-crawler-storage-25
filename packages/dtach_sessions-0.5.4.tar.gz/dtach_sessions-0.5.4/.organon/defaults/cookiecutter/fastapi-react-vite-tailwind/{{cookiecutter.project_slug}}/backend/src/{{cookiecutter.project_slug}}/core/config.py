"""Application configuration."""
from typing import List

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings."""

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=True)

    # API Settings
    API_V1_STR: str = "/api"
    PROJECT_NAME: str = "{{cookiecutter.project_name}}"
    VERSION: str = "{{cookiecutter.version}}"

    # CORS
    CORS_ORIGINS: List[str] = ["http://localhost:5173", "http://localhost:3000"]

    # Database
{% if cookiecutter.use_postgresql == 'y' -%}
    DATABASE_URL: str = "postgresql+asyncpg://user:password@localhost:5432/{{cookiecutter.project_slug}}"
{% else -%}
    DATABASE_URL: str = "sqlite+aiosqlite:///./{{cookiecutter.project_slug}}.db"
{% endif -%}

    # Security
    SECRET_KEY: str = "change-this-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # Debug
    DEBUG: bool = False


settings = Settings()
