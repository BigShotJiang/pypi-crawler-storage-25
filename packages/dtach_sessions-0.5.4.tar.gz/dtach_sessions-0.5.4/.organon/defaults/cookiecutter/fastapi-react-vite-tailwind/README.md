# FastAPI + React Cookiecutter Template

Organon-enabled project template for building modern full-stack web applications with FastAPI backend and React frontend.

## Features

### Backend (FastAPI)
- ✓ FastAPI with async SQLAlchemy
- ✓ Alembic database migrations
- ✓ Pydantic settings management
- ✓ CORS middleware configured
- ✓ Health check endpoint
- ✓ pytest testing setup
- ✓ PostgreSQL or SQLite support

### Frontend (React + TypeScript)
- ✓ Vite build tool
- ✓ React 18 with TypeScript
- ✓ Tailwind CSS configured
- ✓ TanStack Query for data fetching
- ✓ React Router for routing
- ✓ Path aliasing (@/ imports)
- ✓ ESLint and Prettier

### Development Tools
- ✓ Docker Compose for full stack
- ✓ Hot reload for both backend and frontend
- ✓ Organized project structure
- ✓ Organon integration (CLAUDE.md, sprints/)
- ✓ Comprehensive .gitignore

## Prerequisites

- **uv** or **pip** (Python package manager)
- **Node.js** 18+ and npm
- **Docker** and Docker Compose (optional, for containerized development)
- **Cookiecutter** (`pip install cookiecutter`)

## Usage

### Generate a New Project

```bash
# From the organon repository
cd /path/to/organon

# Using organon CLI (if implemented)
uv run organon project create python-fastapi-react MyProject

# Or using cookiecutter directly
cookiecutter defaults/cookiecutter/python-fastapi-react
```

### Cookiecutter Prompts

You'll be asked to provide:

| Variable | Description | Default |
|----------|-------------|---------|
| `project_name` | Human-readable project name | "My Project" |
| `project_slug` | Python package name (auto-generated) | `my_project` |
| `project_description` | Short description | "A FastAPI + React application..." |
| `author_name` | Your name | "Your Name" |
| `author_email` | Your email | "you@example.com" |
| `version` | Initial version | "0.1.0" |
| `python_version` | Python version | "3.10" |
| `use_postgresql` | Use PostgreSQL instead of SQLite | "n" |
| `include_docker` | Include Docker configuration | "y" |
| `include_audio_transcription` | Include audio features | "n" |

### After Generation

```bash
cd <project_slug>

# Backend setup
cd backend
uv sync                        # Install dependencies
uv run alembic upgrade head    # Run migrations
uv run pytest                  # Run tests
uv run uvicorn <project_slug>.main:app --reload

# Frontend setup (in a new terminal)
cd frontend
npm install                    # Install dependencies
npm run dev                    # Start development server

# Or use Docker Compose
docker-compose up --build
```

## Project Structure

Generated projects follow this structure:

```
<project_slug>/
├── backend/                    # FastAPI application
│   ├── src/<project_slug>/
│   │   ├── api/               # API routes
│   │   ├── models/            # Database models
│   │   ├── services/          # Business logic
│   │   ├── core/              # Config, dependencies
│   │   └── main.py            # Application entry
│   ├── tests/                 # Backend tests
│   ├── alembic/               # Database migrations
│   └── pyproject.toml         # Python dependencies
│
├── frontend/                   # React application
│   ├── src/
│   │   ├── components/        # React components
│   │   ├── pages/             # Page components
│   │   ├── hooks/             # Custom hooks
│   │   ├── lib/               # Utilities
│   │   └── App.tsx            # App entry
│   ├── package.json           # Node dependencies
│   └── vite.config.ts         # Vite configuration
│
├── dev-docs/sprints/          # Sprint tracking
├── docker-compose.yml         # Container orchestration
├── CLAUDE.md                  # Organon agent instructions
└── STRUCTURE.md               # Navigation guide
```

## Development Workflow

### Backend Development
```bash
cd backend

# Create a new migration
uv run alembic revision --autogenerate -m "description"

# Apply migrations
uv run alembic upgrade head

# Run tests
uv run pytest

# Run with hot reload
uv run uvicorn <project_slug>.main:app --reload
```

### Frontend Development
```bash
cd frontend

# Start dev server
npm run dev

# Build for production
npm run build

# Type checking
npm run type-check

# Linting
npm run lint

# Format code
npm run format
```

### Docker Development
```bash
# Start all services
docker-compose up

# Rebuild after changes
docker-compose up --build

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

## Organon Integration

Generated projects are Organon-enabled:

```bash
# Create sprints
organon sprints create <number> <name>

# List sprints
organon sprints list

# Scan codebase
organon scan .

# Validate structure
organon validate .
```

See `CLAUDE.md` in generated projects for development standards.

## Customization

### Modifying the Template

Edit files in `defaults/cookiecutter/python-fastapi-react/{{cookiecutter.project_slug}}/`:

- Add/remove dependencies in `pyproject.toml` and `package.json`
- Modify configurations in `vite.config.ts`, `tsconfig.json`, etc.
- Update `CLAUDE.md` for project-specific standards
- Add more example code in `api/`, `components/`, etc.

### Template Variables

Use Jinja2 syntax for template variables:
- `{{cookiecutter.variable_name}}` - Simple variable substitution
- `{% if cookiecutter.use_postgresql == 'y' %}...{% endif %}` - Conditional blocks
- See `cookiecutter.json` for available variables

## Testing the Template

```bash
# Generate a test project
cookiecutter defaults/cookiecutter/python-fastapi-react --no-input

# Test backend
cd my_project/backend
uv sync
uv run pytest

# Test frontend
cd ../frontend
npm install
npm run build

# Test Docker
cd ..
docker-compose up --build
```

## Examples

### With PostgreSQL
```bash
cookiecutter defaults/cookiecutter/python-fastapi-react \
  project_name="My App" \
  use_postgresql=y
```

### Minimal (SQLite, No Docker)
```bash
cookiecutter defaults/cookiecutter/python-fastapi-react \
  project_name="Simple API" \
  include_docker=n
```

## Troubleshooting

### Common Issues

**Backend won't start:**
- Check `DATABASE_URL` in `.env`
- Run migrations: `uv run alembic upgrade head`
- Verify Python version matches `pyproject.toml`

**Frontend build fails:**
- Clear `node_modules/` and reinstall: `rm -rf node_modules && npm install`
- Check Node version: `node --version` (should be 18+)
- Verify all dependencies installed

**Docker issues:**
- Rebuild images: `docker-compose build --no-cache`
- Check ports not in use: `lsof -i :8000` and `lsof -i :5173`
- View container logs: `docker-compose logs backend` or `frontend`

## Contributing

To improve this template:

1. Make changes in `defaults/cookiecutter/python-fastapi-react/`
2. Test template generation
3. Update this README
4. Submit a pull request

## License

Generated projects are licensed according to your specifications.
This template is part of the Organon project.

---

**Built with Organon** - Project lifecycle management framework
**Version**: 1.0.0
**Last Updated**: 2025-10-14
