"""Main FastAPI application."""

from fastapi import FastAPI

app = FastAPI(
    title="{{ cookiecutter.project_name }}",
    description="{{ cookiecutter.description }}",
    version="0.1.0",
)


@app.get("/")
async def root():
    """Root endpoint."""
    return {"message": "Welcome to {{ cookiecutter.project_name }}"}


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}
