# {{ cookiecutter.project_name }}

{{ cookiecutter.description }}

## Quick Start

### Installation

```bash
# Install dependencies
uv sync

# Run development server
uv run uvicorn {{ cookiecutter.package_name }}.main:app --reload
```

### Testing

```bash
# Run tests
uv run pytest

# Run with coverage
uv run pytest --cov={{ cookiecutter.package_name }}
```

### Development

```bash
# Lint code
uv run ruff check .

# Type check
uv run mypy {{ cookiecutter.package_name }}
```

## Project Structure

See `STRUCTURE.md` for detailed project layout.

## Documentation

- API docs available at `/docs` when running
- See `docs/` for additional documentation

## Author

{{ cookiecutter.author_name }} <{{ cookiecutter.author_email }}>
