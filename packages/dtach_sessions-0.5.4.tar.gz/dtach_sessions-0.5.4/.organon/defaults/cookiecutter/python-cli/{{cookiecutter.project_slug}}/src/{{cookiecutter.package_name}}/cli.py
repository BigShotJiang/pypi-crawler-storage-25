"""Command-line interface for {{ cookiecutter.project_name }}."""

import click

from {{ cookiecutter.package_name }} import __version__


@click.group()
@click.version_option(version=__version__)
def main():
    """{{ cookiecutter.project_name }} - {{ cookiecutter.description }}"""
    pass


@main.command()
@click.argument("name", default="World")
def hello(name: str):
    """Say hello to NAME."""
    click.echo(f"Hello, {name}!")


@main.command()
def info():
    """Show tool information."""
    click.echo(f"{{ cookiecutter.project_name }} v{__version__}")
    click.echo(f"{{ cookiecutter.description }}")


if __name__ == "__main__":
    main()
