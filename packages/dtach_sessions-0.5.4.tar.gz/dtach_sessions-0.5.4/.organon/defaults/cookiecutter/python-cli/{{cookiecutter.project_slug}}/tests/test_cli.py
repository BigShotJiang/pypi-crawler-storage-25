"""Tests for CLI."""

from click.testing import CliRunner

from {{ cookiecutter.package_name }}.cli import main


def test_hello_default():
    """Test hello command with default argument."""
    runner = CliRunner()
    result = runner.invoke(main, ["hello"])
    assert result.exit_code == 0
    assert "Hello, World!" in result.output


def test_hello_with_name():
    """Test hello command with custom name."""
    runner = CliRunner()
    result = runner.invoke(main, ["hello", "Alice"])
    assert result.exit_code == 0
    assert "Hello, Alice!" in result.output


def test_info():
    """Test info command."""
    runner = CliRunner()
    result = runner.invoke(main, ["info"])
    assert result.exit_code == 0
    assert "{{ cookiecutter.project_name }}" in result.output
