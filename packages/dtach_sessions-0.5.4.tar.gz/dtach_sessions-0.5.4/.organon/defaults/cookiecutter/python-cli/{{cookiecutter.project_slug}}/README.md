# {{ cookiecutter.project_name }}

{{ cookiecutter.description }}

## Quick Start

### Installation

```bash
# Install dependencies
uv sync

# Install CLI tool
uv pip install -e .
```

### Usage

```bash
# Run the CLI
{{ cookiecutter.command_name }} --help
```

### Testing

```bash
# Run tests
uv run pytest

# Run with coverage
uv run pytest --cov={{ cookiecutter.package_name }}
```

### Development

```bash
# Lint code
uv run ruff check .

# Type check
uv run mypy {{ cookiecutter.package_name }}
```

## Project Structure

See `STRUCTURE.md` for detailed project layout.

## Author

{{ cookiecutter.author_name }} <{{ cookiecutter.author_email }}>
