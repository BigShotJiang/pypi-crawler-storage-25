# Usage Example

This document demonstrates how to use the cookiecutter-python-tauri template to create a new project.

## Quick Start

### 1. Install Prerequisites

```bash
# Install cookiecutter
pip install cookiecutter

# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### 2. Generate Project

```bash
# From organon repository root
cd /Users/psulin/organon
cookiecutter templates/cookiecutter-python-tauri
```

### 3. Answer Prompts

Example interaction:

```
project_name [My Project]: Photo Gallery
project_slug [photo_gallery]:
project_short_description [A Python + React + Tauri desktop application]: A desktop app for organizing and viewing photos
app_display_name [Photo Gallery]:
author_name [Your Name]: John Doe
author_email [you@example.com]: john@example.com
python_version [3.11]:
backend_port [58123]:
frontend_port [8000]:
use_qdrant [yes]: yes
use_ml_models [yes]: yes
ml_framework [pytorch]: pytorch
open_source_license [MIT]: MIT
```

### 4. Set Up Generated Project

```bash
cd photo_gallery

# Install dependencies
make install

# Verify environment
make dev-check
```

Expected output:
```
==================================
  Development Environment Check
==================================

1. Running Processes:
   ○ No development processes running

2. Port Status:
   ✓ Port 58123 (backend): FREE
   ✓ Port 8000 (frontend): FREE

==================================
  Summary
==================================
Status: READY

Action: You can run 'make dev-tauri' or 'make dev'
```

### 5. Run Development Server

```bash
# Start Tauri desktop app
make dev-tauri
```

This will:
1. Start the FastAPI backend on port 58123
2. Wait for backend to be ready
3. Launch Tauri dev mode with native window
4. Open DevTools automatically (in debug mode)

### 6. Test the Application

The app should open in a native window showing:
- Project name: "Photo Gallery"
- Description: "A desktop app for organizing and viewing photos"
- API Status: "Connected"
- Running mode: "Tauri"

Click "Check Connection" to verify backend connectivity.

### 7. Make Changes

**Edit backend:**
```bash
# Edit src/backend/api/main.py
# Changes will auto-reload thanks to uvicorn --reload
```

**Edit frontend:**
```bash
# Edit src/frontend/src/App.tsx
# Changes will hot-reload thanks to Vite HMR
```

### 8. Clean Up

```bash
# Stop all processes and clean locks
make dev-clean
```

## Example Projects

### Minimal REST API App

```bash
cookiecutter templates/cookiecutter-python-tauri

# Prompts:
project_name: Simple API
use_qdrant: no
use_ml_models: no
```

### ML-Powered Desktop App

```bash
cookiecutter templates/cookiecutter-python-tauri

# Prompts:
project_name: ML Classifier
use_ml_models: yes
ml_framework: pytorch
use_qdrant: no
```

### Vector Search Application (Qdrant)

```bash
cookiecutter templates/cookiecutter-python-tauri

# Prompts:
project_name: Semantic Search
use_qdrant: yes
use_ml_models: yes
ml_framework: pytorch
```

## Next Steps After Generation

1. **Read the generated README.md** - Project-specific documentation
2. **Customize config/default.yaml** - Adjust ports, paths, etc.
3. **Add your business logic** - Create routes, services, models
4. **Build frontend UI** - Add React components and pages
5. **Write tests** - Add pytest tests in tests/
6. **Build for distribution** - `make build-tauri` when ready

## Testing the Template Itself

To test template changes:

```bash
# Generate test project
cookiecutter templates/cookiecutter-python-tauri

# Use test values
project_name: Template Test
project_slug: template_test
# ... other defaults

# Install and verify
cd template_test
make install
make dev-check
make dev-tauri

# Clean up test project
cd ..
rm -rf template_test
```

## Troubleshooting

### Template Generation Fails

Check cookiecutter is installed:
```bash
pip install --upgrade cookiecutter
```

### Post-Generation Hook Fails

Check Python version:
```bash
python --version  # Should be 3.11+
```

### Dev Commands Don't Work

Check prerequisites:
```bash
# Check uv
uv --version

# Check tmux (optional)
tmux -V

# Check Node.js
node --version  # Should be 16+

# Check Rust
rustc --version
```

### Project Won't Run

```bash
# Verify environment
make dev-check

# Clean any existing processes
make dev-clean

# Try again
make dev-tauri
```

## Template Customization

To customize the template for your organization:

1. Edit `cookiecutter.json` to add/remove variables
2. Update template files in `{{cookiecutter.project_slug}}/`
3. Modify `hooks/post_gen_project.py` for custom setup
4. Update `README.md` with your guidelines
5. Test thoroughly before publishing

## Support

- Template issues: Open issue in organon repository
- Generated project issues: See project README.md
- Tauri docs: https://tauri.app
- FastAPI docs: https://fastapi.tiangolo.com
- React docs: https://react.dev
