#!/usr/bin/env python
"""
Post-generation hook for cookiecutter-python-tauri template.
Runs after project generation to set up additional files and directories.
"""
import os
import shutil
from pathlib import Path

PROJECT_DIRECTORY = Path.cwd()

def create_empty_files():
    """Create empty __init__.py files and placeholder directories."""
    empty_files = [
        "src/__init__.py",
    ]

    for file_path in empty_files:
        full_path = PROJECT_DIRECTORY / file_path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.touch()

def create_data_directories():
    """Create runtime data directories."""
    directories = [
        "data",
        "logs-archive",
        "src-tauri/binaries",
        "src-tauri/icons",
    ]

    for directory in directories:
        (PROJECT_DIRECTORY / directory).mkdir(parents=True, exist_ok=True)
        # Create .gitkeep to preserve empty directories (except icons)
        if "icons" not in directory:
            gitkeep = PROJECT_DIRECTORY / directory / ".gitkeep"
            gitkeep.touch()

def create_placeholder_icons():
    """Create placeholder icon files for Tauri."""
    icons_dir = PROJECT_DIRECTORY / "src-tauri" / "icons"

    # Minimal 1x1 PNG (valid PNG header + 1 pixel + end marker)
    minimal_png = bytes([
        0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,  # PNG signature
        0x00, 0x00, 0x00, 0x0d,  # IHDR length
        0x49, 0x48, 0x44, 0x52,  # IHDR type
        0x00, 0x00, 0x00, 0x01,  # width: 1
        0x00, 0x00, 0x00, 0x01,  # height: 1
        0x08, 0x06, 0x00, 0x00, 0x00,  # bit depth, color type, etc.
        0x1f, 0x15, 0xc4, 0x89,  # CRC
        0x00, 0x00, 0x00, 0x0a,  # IDAT length
        0x49, 0x44, 0x41, 0x54,  # IDAT type
        0x78, 0x9c, 0x63, 0x00, 0x01, 0x00, 0x00, 0x05, 0x00, 0x01,  # data
        0x0d, 0x0a, 0x2d, 0xb4,  # CRC
        0x00, 0x00, 0x00, 0x00,  # IEND length
        0x49, 0x45, 0x4e, 0x44,  # IEND type
        0xae, 0x42, 0x60, 0x82   # CRC
    ])

    # Write icon files
    (icons_dir / "icon.png").write_bytes(minimal_png)
    (icons_dir / "icon.ico").write_bytes(minimal_png)
    (icons_dir / "icon.icns").write_bytes(minimal_png)

def make_scripts_executable():
    """Make shell scripts executable."""
    scripts = [
        "start_tauri_dev.sh",
    ]

    for script in scripts:
        script_path = PROJECT_DIRECTORY / script
        if script_path.exists():
            os.chmod(script_path, 0o755)

def remove_optional_files():
    """Remove files not needed based on cookiecutter choices."""
    use_qdrant = "{{ cookiecutter.use_qdrant }}"

    # Add conditional file removal logic here if needed
    # For example:
    # if use_qdrant == "no":
    #     # Remove Qdrant-related files
    #     pass

def main():
    """Run all post-generation tasks."""
    print("Running post-generation setup...")

    create_empty_files()
    print("✓ Created empty files")

    create_data_directories()
    print("✓ Created data directories")

    create_placeholder_icons()
    print("✓ Created placeholder icons")

    make_scripts_executable()
    print("✓ Made scripts executable")

    remove_optional_files()
    print("✓ Cleaned up optional files")

    print("\n" + "="*60)
    print("🎉 Project '{{ cookiecutter.project_slug }}' created successfully!")
    print("="*60)
    print("\nNext steps:")
    print("  1. cd {{ cookiecutter.project_slug }}")
    print("  2. make install")
    print("  3. make dev-check")
    print("  4. make dev-tauri")
    print("\nFor more information, see README.md")
    print()

if __name__ == "__main__":
    main()
