# Cookiecutter Python + React + Tauri Template

A production-ready cookiecutter template for building cross-platform desktop applications with Python backend, React frontend, and Tauri native packaging.

## Features

- **Python FastAPI Backend** - Modern async Python web framework
- **React + TypeScript Frontend** - Type-safe React with Material-UI components
- **Tauri Desktop App** - Native desktop packaging for macOS, Windows, and Linux
- **Development Tools** - Comprehensive Makefile with dev commands
- **Optional Qdrant Integration** - Vector database for semantic search (based on production implementation)
- **Optional ML Support** - PyTorch integration for machine learning projects
- **Production Ready** - Includes build scripts, CI/CD configs, and distribution tools

## Architecture

```
┌─────────────────────────────────────────┐
│         TAURI DESKTOP APP               │
│  ┌───────────────────────────────────┐  │
│  │   REACT FRONTEND (Port 8000)      │  │
│  │   - Material-UI components        │  │
│  │   - Axios for API calls           │  │
│  └───────────────┬───────────────────┘  │
│                  │                       │
│  ┌───────────────▼───────────────────┐  │
│  │  FASTAPI BACKEND (Port 58123)     │  │
│  │  - REST API                       │  │
│  │  - PyInstaller sidecar            │  │
│  └───────────────────────────────────┘  │
└─────────────────────────────────────────┘
```

## Prerequisites

- Python 3.11+
- Node.js 16+
- Rust and Cargo (for Tauri)
- uv (Python package manager): `curl -LsSf https://astral.sh/uv/install.sh | sh`
- cookiecutter: `pip install cookiecutter`
- tmux (optional, for dev mode)

## Quick Start

### 1. Generate Project from Template

```bash
# From the organon repository root
cookiecutter templates/cookiecutter-python-tauri

# Or from GitHub (when published)
cookiecutter gh:yourusername/cookiecutter-python-tauri
```

You'll be prompted for:
- `project_name` - Display name (e.g., "My App")
- `project_slug` - Package name (e.g., "my_app")
- `project_short_description` - One-line description
- `author_name` - Your name
- `author_email` - Your email
- `python_version` - Python version (default: 3.11)
- `backend_port` - Backend API port (default: 58123)
- `frontend_port` - Frontend dev port (default: 8000)
- `use_qdrant` - Include Qdrant vector database? (yes/no)
- `use_ml_models` - Include ML framework? (yes/no)
- `ml_framework` - Which ML framework? (pytorch/none)
- `open_source_license` - License type

### 2. Set Up Generated Project

```bash
cd <project_slug>

# Install all dependencies
make install

# Verify environment
make dev-check
```

### 3. Run Development Server

```bash
# Option 1: Tauri desktop app (recommended)
make dev-tauri

# Option 2: Web mode with tmux
make dev

# Option 3: Separate terminals
make dev-backend    # Terminal 1
make dev-frontend   # Terminal 2
```

### 4. Build Distribution

```bash
# Build Tauri desktop app
make build-tauri

# Output: src-tauri/target/release/bundle/macos/YourApp.app
```

## Template Structure

```
cookiecutter-python-tauri/
├── cookiecutter.json           # Template configuration
├── hooks/
│   └── post_gen_project.py    # Post-generation setup
├── README.md                   # This file
└── {{cookiecutter.project_slug}}/
    ├── src/
    │   ├── backend/            # Python FastAPI backend
    │   │   ├── api/
    │   │   │   └── main.py    # FastAPI app
    │   │   ├── models/        # Data models
    │   │   └── services/      # Business logic
    │   └── frontend/          # React frontend
    │       ├── src/
    │       │   ├── App.tsx    # Main React component
    │       │   └── main.tsx   # Entry point
    │       ├── package.json
    │       └── vite.config.ts
    ├── src-tauri/             # Tauri configuration
    │   ├── src/
    │   │   ├── lib.rs         # Tauri app logic
    │   │   └── main.rs        # Entry point
    │   ├── Cargo.toml
    │   └── tauri.conf.json
    ├── config/
    │   └── default.yaml       # App configuration
    ├── scripts/               # Development scripts
    ├── tests/                 # Test files
    ├── Makefile               # Development commands
    ├── pyproject.toml         # Python dependencies
    └── README.md              # Project README
```

## Makefile Commands

The generated project includes a comprehensive Makefile with these commands:

### Setup
- `make install` - Install all dependencies
- `make install-backend` - Install Python dependencies only
- `make install-frontend` - Install Node dependencies only

### Development
- `make dev` - Run backend + frontend in tmux
- `make dev-backend` - Run FastAPI backend only
- `make dev-frontend` - Run React frontend only
- `make dev-tauri` - Run Tauri desktop app
- `make dev-status` - Check running servers
- `make dev-clean` - Kill all processes and clean locks
- `make dev-check` - Verify environment status

### Log Management
- `make dev-tauri-logs` - Stream Tauri logs
- `make logs-status` - Show log file status
- `make logs-tail` - Show last 50 lines
- `make logs-clear` - Clear all logs
- `make logs-archive` - Archive logs with timestamp

### Code Quality
- `make test` - Run tests
- `make lint` - Run linters
- `make format` - Format code

### Build & Distribution
- `make build-tauri` - Build Tauri desktop app
- `make build-sidecar` - Build Python backend binary

### Cleanup
- `make clean` - Remove generated files and caches

## Configuration

Generated projects use YAML configuration in `config/default.yaml`:

```yaml
api:
  host: "0.0.0.0"
  port: 58123
  cors_origins:
    - "http://localhost:8000"
    - "http://127.0.0.1:8000"
    - "tauri://localhost"

storage:  # If vector_db enabled
  qdrant_path: "~/Library/Application Support/YourApp/qdrant"
  data_path: "~/Library/Application Support/YourApp/data"

logging:
  level: "INFO"
```

## Key Features

### Port Configuration
- Backend uses **port 58123** (non-standard to avoid conflicts)
- Frontend dev uses **port 8000**
- Ports are configurable via cookiecutter prompts

### Development Modes
1. **Tauri Dev Mode** - Native window with hot reload (recommended for testing)
2. **Web Dev Mode** - Browser-based with tmux process management
3. **Separate Terminals** - Manual control of backend/frontend

### Environment Detection
Frontend automatically detects runtime environment:
```typescript
const isTauri = typeof window !== 'undefined' && '__TAURI__' in window
const API_BASE = isTauri ? 'http://127.0.0.1:58123' : ''
```

### Python Path Management
Makefile automatically sets `PYTHONPATH` for correct module imports:
```makefile
PYTHON_ENV := PYTHONPATH=$(PWD) HF_HUB_DISABLE_PROGRESS_BARS=1
```

### Process Management
`make dev-clean` performs comprehensive cleanup:
- Kills tmux sessions
- Terminates processes by name
- Frees up ports
- Clears lock files (for vector DBs)
- Detects wedged processes (macOS cargo issue)

## Customization

### Adding Backend Routes

Create new route file in `src/backend/api/`:
```python
# src/backend/api/routes.py
from fastapi import APIRouter

router = APIRouter()

@router.get("/custom")
async def custom_endpoint():
    return {"message": "Custom route"}
```

Include in `main.py`:
```python
from .routes import router
app.include_router(router, prefix="/api")
```

### Adding Frontend Components

Create components in `src/frontend/src/components/`:
```tsx
// src/frontend/src/components/MyComponent.tsx
export const MyComponent = () => {
  return <div>My Component</div>
}
```

### Adding Dependencies

**Python:**
```bash
uv add package-name
```

**Node:**
```bash
cd src/frontend && npm install package-name
```

## Distribution

### Building Tauri App

```bash
make build-tauri
```

This creates:
- **macOS**: `src-tauri/target/release/bundle/macos/YourApp.app`
- **Windows**: `src-tauri/target/release/bundle/msi/YourApp.msi`
- **Linux**: `src-tauri/target/release/bundle/deb/YourApp.deb`

### Distribution Size
- Tauri app: ~50MB
- Includes Python backend as sidecar binary
- No Python installation required on target machine

## Troubleshooting

### Port Already in Use
```bash
make dev-clean  # Comprehensive cleanup
# Or manually:
lsof -ti:58123 | xargs kill -9
```

### Module Not Found
Ensure `PYTHONPATH` is set:
```bash
export PYTHONPATH=$(pwd)
make dev-backend
```

### Tauri Build Fails
Update Rust:
```bash
rustup update stable
```

Clear Cargo cache:
```bash
cargo clean
```

### Frontend Can't Reach Backend
Check Vite proxy configuration in `src/frontend/vite.config.ts`:
```typescript
proxy: {
  '/api': {
    target: 'http://localhost:58123',
    changeOrigin: true,
  }
}
```

## Best Practices

1. **Always use `make dev-check`** before starting development
2. **Use `make dev-clean`** instead of manual process killing
3. **Test in Tauri mode** before releasing (web mode differs)
4. **Keep PYTHONPATH set** in shell profile for convenience
5. **Use tmux for background servers** or run in separate terminals

## Examples

### Basic REST API App
```bash
cookiecutter templates/cookiecutter-python-tauri
# Choose: use_qdrant=no, use_ml_models=no
```

### ML-Powered App
```bash
cookiecutter templates/cookiecutter-python-tauri
# Choose: use_ml_models=yes, ml_framework=pytorch, use_qdrant=no
```

### Vector Search App (Qdrant-based)
```bash
cookiecutter templates/cookiecutter-python-tauri
# Choose: use_qdrant=yes, use_ml_models=yes
```

## Based On

This template is based on the **Image Organizer** project, which demonstrates:
- Production-ready async pipeline architecture
- SQLite state tracking for crash recovery
- Hybrid vector + keyword search
- Background processing with progress tracking
- Professional Tauri packaging

See the original project for a complete reference implementation.

## Contributing

Contributions welcome! To modify this template:

1. Clone organon repository
2. Edit files in `templates/cookiecutter-python-tauri/`
3. Test with `cookiecutter templates/cookiecutter-python-tauri`
4. Submit PR

## License

MIT License - use freely for commercial and personal projects.

## Author

Template created by extracting patterns from the Image Organizer project.

## Support

For issues or questions:
- Open an issue in the organon repository
- See generated project README for project-specific help
- Check Tauri documentation: https://tauri.app
- Check FastAPI documentation: https://fastapi.tiangolo.com
