# {{cookiecutter.app_display_name}}

{{cookiecutter.project_short_description}}

## Tech Stack

**Backend:**
- FastAPI for REST API
{% if cookiecutter.use_qdrant == "yes" -%}
- Qdrant for vector storage
{% endif -%}
{% if cookiecutter.use_ml_models == "yes" -%}
- {{cookiecutter.ml_framework|capitalize}} for ML models
{% endif -%}
- Python {{cookiecutter.python_version}}+
- uv for dependency management

**Frontend:**
- React with TypeScript
- Material-UI (MUI) components
- Vite build system

**Desktop:**
- Tauri 2.0 (native desktop app framework)

## Installation

### Prerequisites
- Python {{cookiecutter.python_version}}+
- Node.js 16+
- Rust and Cargo (for Tauri)
- uv (Python package manager)

### Installation

```bash
# Install all dependencies
make install
```

## Usage

### Development

```bash
# Run both backend and frontend (recommended)
make dev

# Or run separately:
make dev-backend    # FastAPI server on port {{cookiecutter.backend_port}}
make dev-frontend   # React app on port {{cookiecutter.frontend_port}}

# Run Tauri desktop app in dev mode
make dev-tauri
```

### Check environment status

```bash
# Verify environment is ready
make dev-check

# Check running servers
make dev-status

# Clean up all processes
make dev-clean
```

## Configuration

Edit `config/default.yaml`:

```yaml
api:
  host: "0.0.0.0"
  port: {{cookiecutter.backend_port}}
  cors_origins:
    - "http://localhost:{{cookiecutter.frontend_port}}"
    - "http://127.0.0.1:{{cookiecutter.frontend_port}}"
    - "tauri://localhost"
```

## Project Structure

```
{{cookiecutter.project_slug}}/
├── src/
│   ├── backend/              # Python FastAPI backend
│   │   ├── api/              # REST API endpoints
│   │   ├── models/           # Data models
│   │   └── services/         # Business logic
│   └── frontend/             # React frontend
│       └── src/              # React source code
├── src-tauri/                # Tauri desktop app
│   ├── src/                  # Rust source code
│   └── binaries/             # Backend sidecar binary
├── config/
│   └── default.yaml          # Configuration
├── scripts/                  # Development scripts
├── tests/                    # Test files
├── Makefile                  # Development commands
└── pyproject.toml            # Python dependencies
```

## Development Commands

```bash
make install          # Install all dependencies
make dev              # Run backend + frontend (tmux)
make dev-backend      # Run FastAPI only
make dev-frontend     # Run React only
make dev-tauri        # Run Tauri desktop app
make dev-check        # Check environment status
make dev-clean        # Kill all processes and clean locks
make test             # Run tests
make lint             # Run linters
make format           # Format code
make build-tauri      # Build Tauri desktop app
make clean            # Remove caches
```

## Build & Distribution

### Development
```bash
make dev-tauri        # Tauri app with hot reload
```

### Production
```bash
make build-tauri      # Build production .app bundle
```

Output: `src-tauri/target/release/bundle/macos/{{cookiecutter.app_display_name}}.app`

## License

{% if cookiecutter.open_source_license != "No license" -%}
{{cookiecutter.open_source_license}}
{% else -%}
Proprietary
{% endif -%}

## Author

{{cookiecutter.author_name}} <{{cookiecutter.author_email}}>
