import { useState, useEffect } from 'react'
import { ThemeProvider, createTheme } from '@mui/material/styles'
import { CssBaseline, Container, Typography, Box, Button } from '@mui/material'
import axios from 'axios'

const theme = createTheme({
  palette: {
    mode: 'light',
  },
})

// Detect if running in Tauri
const isTauri = typeof window !== 'undefined' && '__TAURI__' in window

// API base URL
const API_BASE = isTauri ? 'http://127.0.0.1:{{cookiecutter.backend_port}}' : ''

// Create axios instance
const api = axios.create({
  baseURL: API_BASE,
})

function App() {
  const [apiStatus, setApiStatus] = useState<string>('Checking...')
  const [appInfo, setAppInfo] = useState<any>(null)

  useEffect(() => {
    checkHealth()
    fetchInfo()
  }, [])

  const checkHealth = async () => {
    try {
      const response = await api.get('/api/health')
      setApiStatus(response.data.status === 'healthy' ? 'Connected' : 'Unknown')
    } catch (error) {
      setApiStatus('Disconnected')
      console.error('Health check failed:', error)
    }
  }

  const fetchInfo = async () => {
    try {
      const response = await api.get('/api/info')
      setAppInfo(response.data)
    } catch (error) {
      console.error('Failed to fetch info:', error)
    }
  }

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <Container maxWidth="lg">
        <Box sx={{ my: 4 }}>
          <Typography variant="h2" component="h1" gutterBottom>
            {appInfo?.name || '{{cookiecutter.app_display_name}}'}
          </Typography>
          <Typography variant="h5" component="h2" gutterBottom color="text.secondary">
            {appInfo?.description || '{{cookiecutter.project_short_description}}'}
          </Typography>
          <Box sx={{ mt: 4 }}>
            <Typography variant="body1">
              API Status: <strong>{apiStatus}</strong>
            </Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
              Running in {isTauri ? 'Tauri' : 'Browser'} mode
            </Typography>
          </Box>
          <Box sx={{ mt: 4 }}>
            <Button variant="contained" onClick={checkHealth}>
              Check Connection
            </Button>
          </Box>
        </Box>
      </Container>
    </ThemeProvider>
  )
}

export default App
