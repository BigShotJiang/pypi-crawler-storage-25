"""{{cookiecutter.project_slug}} backend package."""
