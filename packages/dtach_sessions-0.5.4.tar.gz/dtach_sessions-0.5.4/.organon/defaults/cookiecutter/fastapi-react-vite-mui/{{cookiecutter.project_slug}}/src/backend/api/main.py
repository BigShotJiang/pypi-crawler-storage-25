"""
FastAPI application entry point.
"""
import logging
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import yaml

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Load configuration
config_path = Path("config/default.yaml")
with open(config_path) as f:
    config = yaml.safe_load(f)

# Create FastAPI app
app = FastAPI(
    title="{{cookiecutter.app_display_name}} API",
    description="{{cookiecutter.project_short_description}}",
    version="0.1.0"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=config["api"]["cors_origins"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy"}

@app.get("/api/info")
async def get_info():
    """Get application information."""
    return {
        "name": "{{cookiecutter.app_display_name}}",
        "version": "0.1.0",
        "description": "{{cookiecutter.project_short_description}}"
    }

# Import and include additional routers here
# Example:
# from .routes import router
# app.include_router(router, prefix="/api")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host=config["api"]["host"],
        port=config["api"]["port"]
    )
