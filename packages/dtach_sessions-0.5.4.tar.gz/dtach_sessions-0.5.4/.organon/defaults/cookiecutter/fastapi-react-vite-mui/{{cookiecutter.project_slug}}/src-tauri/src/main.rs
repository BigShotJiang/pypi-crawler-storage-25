// Prevents console window from appearing on Windows
#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

fn main() {
    {{cookiecutter.project_slug|replace('-', '_')}}_lib::run()
}
