#!/bin/bash
# Start Tauri development mode with backend
# This script ensures the backend is running before starting Tauri

set -e

echo "Starting {{cookiecutter.app_display_name}} in development mode..."
echo ""

# Check if backend is running
if lsof -ti:{{cookiecutter.backend_port}} >/dev/null 2>&1; then
    echo "✓ Backend is already running on port {{cookiecutter.backend_port}}"
else
    echo "Starting backend..."
    PYTHONPATH=$(pwd) uv run uvicorn src.backend.api.main:app --port {{cookiecutter.backend_port}} &
    BACKEND_PID=$!
    echo "Backend started with PID $BACKEND_PID"

    # Wait for backend to be ready
    echo "Waiting for backend to be ready..."
    for i in {1..30}; do
        if curl -s http://127.0.0.1:{{cookiecutter.backend_port}}/api/health >/dev/null 2>&1; then
            echo "✓ Backend is ready"
            break
        fi
        sleep 0.5
    done
fi

echo ""
echo "Starting Tauri..."
cd src-tauri && npx @tauri-apps/cli dev
