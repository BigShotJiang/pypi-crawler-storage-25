"""{{cookiecutter.project_name}} backend package."""

__version__ = "{{cookiecutter.version}}"
