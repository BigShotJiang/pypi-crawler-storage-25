"""Database models package."""
{% if cookiecutter.database != "none" %}
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()
{% endif %}
