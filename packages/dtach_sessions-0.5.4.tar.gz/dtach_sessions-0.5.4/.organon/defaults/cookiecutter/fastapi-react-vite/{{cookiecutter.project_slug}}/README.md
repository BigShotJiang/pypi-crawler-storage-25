# {{cookiecutter.project_name}}

{{cookiecutter.project_description}}

## Tech Stack

**Backend:**
- Python {{cookiecutter.python_version}}+
- FastAPI 0.104+
- Uvicorn (ASGI server)
- Pydantic 2.5+ (validation)
{% if cookiecutter.database != "none" -%}
- SQLAlchemy 2.0+ ({{cookiecutter.database}})
{% if cookiecutter.include_alembic == "yes" -%}
- Alembic (migrations)
{% endif -%}
{% endif %}

**Frontend:**
- React 18.2
- TypeScript 5.2
- Vite 5.0 (build tool)
{% if cookiecutter.ui_framework == "mui" -%}
- Material-UI 5.14 (component library)
- Emotion (CSS-in-JS)
{% elif cookiecutter.ui_framework == "tailwind" -%}
- TailwindCSS 3.3 (utility-first CSS)
{% elif cookiecutter.ui_framework == "radix+tailwind" -%}
- Radix UI (headless components)
- TailwindCSS 3.3 (utility-first CSS)
{% endif -%}
- React Router 6.20
- Axios 1.6
{% if cookiecutter.ui_framework != "mui" -%}
- TanStack Query 5.12 (data fetching)
{% endif %}

**Testing:**
- Backend: pytest + httpx
- Frontend: Vitest + Testing Library

{% if cookiecutter.include_tauri == "yes" -%}
**Desktop:**
- Tauri 2.x (native desktop wrapper)
- PyInstaller 6.0 (backend sidecar)

{% endif -%}
**Development:**
- uv (Python package manager)
- Comprehensive Makefile
- Docker Compose deployment
- Claude Code integration hooks

## Prerequisites

- Python {{cookiecutter.python_version}}+
- Node.js 18+
- [uv](https://github.com/astral-sh/uv) (Python package manager)
- tmux (for running dev servers in background)
{% if cookiecutter.include_tauri == "yes" -%}
- Rust/Cargo (for Tauri builds)
{% endif -%}
{% if cookiecutter.database == "postgresql" -%}
- PostgreSQL 15+ (or use Docker Compose)
{% endif %}

## Quick Start

### 1. Install Dependencies

```bash
make install
```

This installs both Python and Node dependencies.

### 2. Verify Environment

```bash
make dev-check
```

Checks for:
- Running processes
- Port availability (backend: {{cookiecutter.backend_port}}, frontend: {{cookiecutter.frontend_port}})
- Environment readiness

### 3. Start Development

{% if cookiecutter.include_tauri == "yes" -%}
**Desktop App (Tauri):**
```bash
make dev-tauri
```

**Web Only:**
{% endif -%}
```bash
make dev
```

This starts both backend and frontend in a tmux session.

**Separate servers:**
```bash
# Terminal 1
make dev-backend

# Terminal 2
make dev-frontend
```

### 4. Access Application

{% if cookiecutter.include_tauri == "yes" -%}
- **Desktop:** Launches automatically with `make dev-tauri`
{% endif -%}
- **Frontend:** http://localhost:{{cookiecutter.frontend_port}}
- **Backend API:** http://localhost:{{cookiecutter.backend_port}}
- **API Docs:** http://localhost:{{cookiecutter.backend_port}}/docs

## Development Commands

### Setup
```bash
make install          # Install all dependencies
make install-backend  # Install Python dependencies only
make install-frontend # Install Node dependencies only
```

### Development
```bash
make dev              # Run backend + frontend (tmux)
make dev-backend      # Run FastAPI backend
make dev-frontend     # Run React frontend
{% if cookiecutter.include_tauri == "yes" -%}
make dev-tauri        # Run Tauri desktop app
{% endif -%}
make dev-status       # Check running servers
make dev-check        # Environment readiness check
make dev-clean        # Kill all dev processes
```

{% if cookiecutter.include_tauri == "yes" -%}
### Log Management
```bash
make logs-watch       # Stream logs in real-time
make logs-status      # Show log file status
make logs-tail        # Show last 50 lines
make logs-clear       # Clear all logs
make logs-archive     # Archive logs with timestamp
```

{% endif -%}
### Testing
```bash
make test             # Run all tests
make test-backend     # Run backend tests only
make test-frontend    # Run frontend tests only
```

### Code Quality
```bash
make lint             # Run linters (ruff + eslint)
make format           # Format code (black + prettier)
```

### Build
```bash
{% if cookiecutter.include_tauri == "yes" -%}
make build-tauri      # Build desktop app
make build-sidecar    # Build Python backend sidecar
{% else -%}
make build            # Build frontend for production
{% endif -%}
```

### Cleanup
```bash
make clean            # Remove generated files
```

## Project Structure

```
{{cookiecutter.project_slug}}/
├── src/
│   ├── backend/              # Python backend
│   │   ├── api/              # FastAPI routes
│   │   │   └── main.py       # App entry point
│   │   ├── models/           # Database models
│   │   └── services/         # Business logic
│   └── frontend/             # React frontend
│       ├── src/
│       │   ├── App.tsx       # Main component
│       │   └── main.tsx      # Entry point
│       ├── package.json
│       └── vite.config.ts
{% if cookiecutter.include_tauri == "yes" -%}
├── src-tauri/                # Tauri desktop wrapper
│   ├── src/                  # Rust code
│   ├── Cargo.toml
│   └── tauri.conf.json
{% endif -%}
├── config/
│   └── default.yaml          # App configuration
├── tests/                    # Backend tests
│   ├── conftest.py
│   └── test_health.py
{% if cookiecutter.include_alembic == "yes" -%}
├── alembic/                  # Database migrations
│   ├── versions/
│   └── env.py
├── alembic.ini
{% endif -%}
├── .claude/
│   └── hooks/                # Claude Code hooks
├── Makefile                  # Development commands
├── pyproject.toml            # Python config
├── docker-compose.yml        # Docker deployment
└── README.md
```

## Configuration

Edit `config/default.yaml` to configure:
- Server host/port
{% if cookiecutter.database != "none" -%}
- Database connection
{% endif -%}
- CORS origins
- Application settings

## Docker Deployment

Start all services:
```bash
docker-compose up -d
```

Services:
{% if cookiecutter.database == "postgresql" -%}
- PostgreSQL (port 5432)
{% endif -%}
- Backend (port {{cookiecutter.backend_port}})
- Frontend (port {{cookiecutter.frontend_port}})

{% if cookiecutter.database != "none" and cookiecutter.include_alembic == "yes" -%}
## Database Migrations

**Create migration:**
```bash
uv run alembic revision --autogenerate -m "description"
```

**Apply migrations:**
```bash
uv run alembic upgrade head
```

**Rollback:**
```bash
uv run alembic downgrade -1
```

{% endif -%}
## Testing

**Backend:**
```bash
make test-backend
# or
uv run pytest
```

**Frontend:**
```bash
make test-frontend
# or
cd src/frontend && npm test
```

## Troubleshooting

**Port already in use:**
```bash
make dev-check  # Show what's running
make dev-clean  # Kill all processes
```

**Dependencies out of sync:**
```bash
make clean
make install
```

{% if cookiecutter.include_tauri == "yes" -%}
**Tauri build errors:**
```bash
cd src-tauri
cargo clean
cd ..
make build-tauri
```

{% endif -%}
## License

{% if cookiecutter.open_source_license == "MIT" -%}
MIT License - see LICENSE file for details
{% elif cookiecutter.open_source_license == "BSD-3-Clause" -%}
BSD 3-Clause License - see LICENSE file for details
{% elif cookiecutter.open_source_license == "Apache-2.0" -%}
Apache License 2.0 - see LICENSE file for details
{% elif cookiecutter.open_source_license == "GPL-3.0" -%}
GPL 3.0 License - see LICENSE file for details
{% else -%}
All rights reserved
{% endif %}

## Author

{{cookiecutter.author_name}} <{{cookiecutter.author_email}}>
