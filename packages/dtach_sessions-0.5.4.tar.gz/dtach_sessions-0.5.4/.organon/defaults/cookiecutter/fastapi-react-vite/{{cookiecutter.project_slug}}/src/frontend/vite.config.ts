import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    host: '{{cookiecutter.frontend_port == "8005" and "127.0.0.1" or "0.0.0.0"}}',
    port: {{cookiecutter.frontend_port}},
    strictPort: true,
    proxy: {
      '/api': {
        target: 'http://localhost:{{cookiecutter.backend_port}}',
        changeOrigin: true,
      },
    },
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
  },
})
