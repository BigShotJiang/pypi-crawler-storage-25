import { useState, useEffect } from 'react'
{% if cookiecutter.ui_framework == "mui" -%}
import { Container, Typography, Box, Button } from '@mui/material'
{% endif %}

function App() {
  const [health, setHealth] = useState<string>('Checking...')

  useEffect(() => {
    fetch('/api/health')
      .then(res => res.json())
      .then(data => setHealth(data.status))
      .catch(() => setHealth('Error'))
  }, [])

  return (
{% if cookiecutter.ui_framework == "mui" -%}
    <Container maxWidth="md">
      <Box sx={{ my: 4 }}>
        <Typography variant="h2" component="h1" gutterBottom>
          {{cookiecutter.project_name}}
        </Typography>
        <Typography variant="body1" gutterBottom>
          {{cookiecutter.project_description}}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Backend Health: {health}
        </Typography>
      </Box>
    </Container>
{% else -%}
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-lg shadow-md p-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">
          {{cookiecutter.project_name}}
        </h1>
        <p className="text-gray-600 mb-4">
          {{cookiecutter.project_description}}
        </p>
        <div className="text-sm text-gray-500">
          Backend Health: <span className={health === 'healthy' ? 'text-green-600' : 'text-red-600'}>{health}</span>
        </div>
      </div>
    </div>
{% endif -%}
  )
}

export default App
