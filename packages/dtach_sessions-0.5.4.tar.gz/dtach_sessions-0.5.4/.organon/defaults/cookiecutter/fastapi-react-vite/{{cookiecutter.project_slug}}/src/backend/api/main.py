"""FastAPI application entry point."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="{{cookiecutter.project_name}}",
    description="{{cookiecutter.project_description}}",
    version="{{cookiecutter.version}}",
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:{{cookiecutter.frontend_port}}", "http://127.0.0.1:{{cookiecutter.frontend_port}}"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    """Root endpoint."""
    return {"message": "{{cookiecutter.project_name}} API", "version": "{{cookiecutter.version}}"}


@app.get("/api/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}
