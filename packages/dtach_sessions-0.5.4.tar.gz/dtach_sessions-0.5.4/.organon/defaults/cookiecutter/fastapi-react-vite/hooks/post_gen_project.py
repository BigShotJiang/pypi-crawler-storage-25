#!/usr/bin/env python3
"""
Post-generation hook for fastapi-react-vite template.

Cleans up conditional files and sets permissions.
"""

import os
import shutil
from pathlib import Path


def remove_if_exists(path: Path):
    """Remove file or directory if it exists."""
    if path.is_file():
        path.unlink()
        print(f"Removed: {path}")
    elif path.is_dir():
        shutil.rmtree(path)
        print(f"Removed: {path}/")


def main():
    """Post-generation cleanup."""
    project_root = Path.cwd()

    # Conditional: Tauri files
    if "{{ cookiecutter.include_tauri }}" != "yes":
        print("\nRemoving Tauri files (include_tauri=no)...")
        remove_if_exists(project_root / "src-tauri")
        remove_if_exists(project_root / "start_tauri_dev.sh")

    # Conditional: Alembic files
    if "{{ cookiecutter.include_alembic }}" != "yes":
        print("\nRemoving Alembic files (include_alembic=no)...")
        remove_if_exists(project_root / "alembic")
        remove_if_exists(project_root / "alembic.ini")

    # Conditional: Tailwind config (mui doesn't use Tailwind)
    if "{{ cookiecutter.ui_framework }}" == "mui":
        print("\nRemoving Tailwind files (ui_framework=mui)...")
        remove_if_exists(project_root / "src" / "frontend" / "tailwind.config.js")
        remove_if_exists(project_root / "src" / "frontend" / "postcss.config.js")

    # Make scripts executable
    scripts = [
        project_root / "start_tauri_dev.sh",
        project_root / ".claude" / "hooks" / "user-prompt-submit",
    ]

    print("\nSetting executable permissions...")
    for script in scripts:
        if script.exists():
            script.chmod(0o755)
            print(f"Made executable: {script}")

    print("\n✓ Post-generation cleanup complete!")
    print(f"\nNext steps:")
    print(f"  cd {project_root.name}")
    print(f"  make install")
    print(f"  make dev-check")
    {% if cookiecutter.include_tauri == "yes" -%}
    print(f"  make dev-tauri")
    {% else -%}
    print(f"  make dev")
    {% endif %}


if __name__ == "__main__":
    main()
