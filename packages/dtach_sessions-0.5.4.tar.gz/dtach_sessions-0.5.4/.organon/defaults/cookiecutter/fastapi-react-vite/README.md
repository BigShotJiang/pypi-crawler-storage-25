# FastAPI + React + Vite Unified Template

A unified cookiecutter template for creating full-stack applications with FastAPI backend and React frontend. Supports both web and desktop deployments with multiple UI framework options.

## Features

- **Flexible UI Framework:** Choose between Radix UI + Tailwind, Tailwind only, or Material-UI
- **Optional Desktop Support:** Add Tauri for native desktop apps
- **Database Options:** PostgreSQL, SQLite, or none
- **Optional Migrations:** Alembic support for database schema management
- **Comprehensive Makefile:** Rich development commands for all workflows
- **Full Testing Setup:** pytest for backend, Vitest for frontend
- **Docker Deployment:** Complete docker-compose setup
- **Claude Code Integration:** Built-in hooks for AI-assisted development

## Quick Start

```bash
# Install cookiecutter if you haven't
pip install cookiecutter

# Generate project
cookiecutter /path/to/fastapi-react-vite

# Follow the prompts to configure your project
```

## Template Options

### Required Options

- **project_name:** Display name (e.g., "My Project")
- **project_slug:** Package name (auto-generated from project_name)
- **project_description:** Brief description
- **author_name:** Your name
- **author_email:** Your email
- **version:** Initial version (default: 0.1.0)
- **python_version:** Python version (default: 3.11)
- **backend_port:** Backend port (default: 8000)
- **frontend_port:** Frontend port (default: 5173)

### UI Framework

Choose one:
- **radix+tailwind:** Radix UI components + TailwindCSS (headless components with full styling control)
- **tailwind:** TailwindCSS only (utility-first CSS, build your own components)
- **mui:** Material-UI (complete component library with CSS-in-JS)

### Desktop Support

- **include_tauri:** yes/no
  - **yes:** Adds Tauri wrapper, Rust/Cargo files, PyInstaller sidecar, desktop-specific Makefile targets
  - **no:** Web-only application

### Database

Choose one:
- **postgresql:** PostgreSQL with asyncpg driver
- **sqlite:** SQLite with aiosqlite driver
- **none:** No database (API-only backend)

### Migrations

- **include_alembic:** yes/no
  - **yes:** Adds Alembic for database migrations (requires database != none)
  - **no:** Manual database schema management

### License

Choose one:
- MIT
- BSD-3-Clause
- Apache-2.0
- GPL-3.0
- No license

## Example Configurations

### Web App with Radix + Tailwind

```bash
cookiecutter /path/to/template --no-input \
  project_name="My Web App" \
  ui_framework=radix+tailwind \
  include_tauri=no \
  database=postgresql \
  include_alembic=yes
```

Generates:
- React + Radix UI + Tailwind frontend
- FastAPI backend with PostgreSQL
- Alembic migrations
- Docker Compose deployment
- Web-focused Makefile targets

### Desktop App with Material-UI

```bash
cookiecutter /path/to/template --no-input \
  project_name="My Desktop App" \
  ui_framework=mui \
  include_tauri=yes \
  database=sqlite \
  include_alembic=no
```

Generates:
- React + Material-UI frontend
- FastAPI backend with SQLite
- Tauri desktop wrapper
- PyInstaller backend sidecar
- Desktop-specific Makefile targets

### API-Only with Tailwind Frontend

```bash
cookiecutter /path/to/template --no-input \
  project_name="My API" \
  ui_framework=tailwind \
  include_tauri=no \
  database=none \
  include_alembic=no
```

Generates:
- React + Tailwind frontend
- FastAPI backend (no database)
- Docker Compose deployment
- Minimal configuration

## Generated Project Structure

### Always Included

```
project_slug/
├── src/
│   ├── backend/              # FastAPI backend
│   │   ├── api/
│   │   ├── models/
│   │   └── services/
│   └── frontend/             # React frontend
│       ├── src/
│       ├── package.json
│       └── vite.config.ts
├── config/
│   └── default.yaml
├── tests/                    # Backend tests
├── .claude/hooks/            # Claude Code integration
├── Makefile                  # ALWAYS included
├── pyproject.toml
├── docker-compose.yml
├── .gitignore
└── README.md
```

### Conditional: Tauri (include_tauri=yes)

```
├── src-tauri/                # Rust code
│   ├── src/
│   ├── Cargo.toml
│   └── tauri.conf.json
└── start_tauri_dev.sh        # Dev startup script
```

### Conditional: Alembic (include_alembic=yes)

```
├── alembic/                  # Migration scripts
│   ├── versions/
│   └── env.py
└── alembic.ini
```

### Conditional: UI Framework

**radix+tailwind or tailwind:**
```
src/frontend/
├── tailwind.config.js
├── postcss.config.js
└── src/index.css            # Tailwind imports
```

**mui:**
```
src/frontend/
└── src/
    ├── index.css            # No Tailwind
    └── App.tsx              # MUI components
```

## Development Workflow

After generating a project:

1. **Install dependencies:**
   ```bash
   make install
   ```

2. **Check environment:**
   ```bash
   make dev-check
   ```

3. **Start development:**
   ```bash
   # Desktop (if include_tauri=yes)
   make dev-tauri

   # Web only
   make dev
   ```

4. **Run tests:**
   ```bash
   make test
   ```

See generated README.md in your project for complete commands.

## Makefile Targets

The template ALWAYS includes a comprehensive Makefile with:

### Core Targets (All Configurations)
- `make install` - Install all dependencies
- `make dev` - Start backend + frontend in tmux
- `make dev-backend` - Start FastAPI only
- `make dev-frontend` - Start React only
- `make dev-status` - Check running servers
- `make dev-check` - Environment readiness check
- `make dev-clean` - Kill all processes
- `make test` - Run all tests
- `make lint` - Run linters
- `make format` - Format code
- `make clean` - Remove generated files

### Desktop-Specific (include_tauri=yes)
- `make dev-tauri` - Start Tauri desktop app
- `make dev-tauri-logs` - Stream Tauri logs
- `make logs-watch` - Watch logs in real-time
- `make logs-archive` - Archive logs
- `make build-sidecar` - Build Python backend sidecar
- `make build-tauri` - Build desktop app

### Web-Only (include_tauri=no)
- `make build` - Build frontend for production

## UI Framework Comparison

| Feature | radix+tailwind | tailwind | mui |
|---------|---------------|----------|-----|
| **Philosophy** | Headless + utility CSS | Pure utility CSS | Complete component library |
| **Components** | Radix UI (accessible) | Build your own | Pre-built MUI components |
| **Styling** | Tailwind utilities | Tailwind utilities | CSS-in-JS (Emotion) |
| **Customization** | Full control | Full control | Theme-based |
| **Bundle Size** | Medium | Smallest | Largest |
| **Learning Curve** | Medium | Low | Medium |
| **Accessibility** | Excellent (Radix) | Manual | Good (MUI) |

**Recommendation:**
- **radix+tailwind:** Best for custom designs requiring accessibility
- **tailwind:** Best for maximum control and minimal bundle size
- **mui:** Best for rapid prototyping with consistent design

## Database Options

### PostgreSQL
- Production-ready relational database
- Requires PostgreSQL 15+ installed or Docker
- Async driver (asyncpg)
- Best for: Multi-user apps, complex queries

### SQLite
- Lightweight file-based database
- No external dependencies
- Async driver (aiosqlite)
- Best for: Single-user apps, simple storage

### None
- No database layer
- Pure API or static content
- Best for: Microservices, API gateways

## Migration Strategy

- **include_alembic=yes:** Automatic schema versioning, team-friendly, production-ready
- **include_alembic=no:** Manual schema management, simpler setup, suitable for prototypes

## Requirements

### All Projects
- Python 3.11+
- Node.js 18+
- uv (Python package manager)
- tmux (for `make dev`)

### Desktop Projects (include_tauri=yes)
- Rust/Cargo (for Tauri)
- PyInstaller (installed automatically)

### PostgreSQL Projects (database=postgresql)
- PostgreSQL 15+ OR Docker

## Post-Generation

After running cookiecutter, the template automatically:
1. Removes conditional files based on your choices
2. Makes scripts executable (start_tauri_dev.sh, hooks)
3. Creates necessary directories

No manual cleanup required.

## Troubleshooting

### Issue: Tauri files not generated
**Cause:** include_tauri=no
**Solution:** Regenerate with include_tauri=yes

### Issue: Alembic commands fail
**Cause:** include_alembic=no or database=none
**Solution:** Regenerate with include_alembic=yes and database!=none

### Issue: Tailwind not working with MUI
**Cause:** ui_framework=mui (Tailwind not included)
**Solution:** Use ui_framework=tailwind or radix+tailwind

### Issue: Make targets not found
**Cause:** Makefile not generated (shouldn't happen)
**Solution:** Makefile is ALWAYS included; check template integrity

## Template Maintenance

This template merges best features from:
- **fastapi-react-vite-mui** (Makefile, Tauri, desktop workflow)
- **fastapi-react-vite-tailwind** (Docker, testing, Alembic)

Maintained by: Organon project
Version: 2.0.0

## License

This template is part of the Organon project.
