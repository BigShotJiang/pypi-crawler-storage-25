# Workflow System

This guide explains Organon's workflow-task model for organizing all development work.

## Overview

Organon uses a **workflow-task model** where all work follows one of four workflows, each composed of smaller task types. Sprints are one type of workflow.

## The Four Workflows

### 1. Conversation

**Purpose:** Discussion and planning without file changes

**Structure:** No files created, tracked only in `.organon/current-context.json`

**When to use:**
- Exploratory discussions
- Planning conversations
- Architecture debates
- Clarifying requirements
- Analyzing trade-offs

**Examples:**
- "How should we approach this feature?"
- "What are the pros and cons of approach A vs B?"
- "Help me understand the codebase structure"

**Note:** Does not update `.organon/current-context.json` until producing concrete work

**Work-mode:** `defaults/definitions/work-modes/conversation.md`

### 2. Ad-Hoc Task

**Purpose:** Quick work requiring minimal planning

**Structure:** No formal structure, just commit messages

**When to use:**
- Less than 2 hours of work
- Minimal planning needed
- Simple changes

**Examples:**
- Bug fixes
- Documentation updates
- Dependency updates
- Small refactorings

**Available workflow types:** implement, fix, test, document

**Work-mode:** `defaults/definitions/work-modes/ad-hoc-task.md`

### 3. Sprint Planning

**Purpose:** Create implementation plan for larger work

**Structure:** Sprint directory or file (Regular or Mini)
- **Regular:** `.organon/sprints/NN_Name_Status/` (4 files)
- **Mini:** `.organon/sprints/NN_Name_Status.md` (sections)

**When to use:**
- Planning phase of sprint work
- Before starting implementation
- Need to research, design, and specify before coding

**Available workflow types:** requirements, research, design, architecture, specify, plan

**Work-mode:**
- `defaults/definitions/work-modes/sprint-planning.md`

**See also:** [Sprint Development Process](sprints.md)

### 4. Sprint Execution

**Purpose:** Execute implementation plan

**Structure:** Same sprint directory/file from planning phase

**When to use:**
- Implementation phase of sprint work
- After planning is complete
- Following established plan

**Available workflow types:** implement, test, review, document

**Work-mode:**
- `defaults/definitions/work-modes/sprint-execution.md`

**See also:** [Sprint Development Process](sprints.md)

## Workflow Phases

All workflows follow these phases (may skip some):

### Planning Level

Creates the workflow (what will be done):

```
Requirements → Research → Design (optional, UI only) → Architecture → Spec → Plan
```

**Characteristics:**
- Iterative: cycle between phases as needed
- Output: plan.md (or Plan section) with task checklist
- This process creates the workflow that will be executed
- Design phase is OPTIONAL - skip for backend-only/infrastructure work

**Phases:**
1. **Requirements** - Define stakeholder needs and success criteria (first phase, no prior dependencies)
2. **Research** - Investigate technical landscape and existing patterns (provides backing information)
3. **Design** - OPTIONAL: UI/UX decisions only (visual design, layout, components - skip for non-UI work)
4. **Architecture** - Define structure and module organization (WHERE code lives, not WHAT's inside)
5. **Spec** - Define technical contracts and APIs (WHAT's inside - data structures, signatures, schemas)
6. **Plan** - Create detailed task checklist

### Development Level

Executes the workflow (actually doing the work):

```
Implement → Test → Review → Document
```

**Characteristics:**
- Follow tasks in plan
- Track commits: `- [x] Task (commit: a1b2c3d)`
- Can cycle back to Planning if assumptions wrong

**Phases:**
1. **Implement** - Write the code
2. **Test** - Verify behavior
3. **Review** - Check quality
4. **Document** - Update documentation

## Workflow Types

Available workflow types across all work-modes (see `defaults/definitions/workflows/*.md` for details):

### Planning Workflows
- **requirements** - Define what we're building (what/why)
- **research** - Investigate, analyze, understand (how)
- **design** - Make approach decisions
- **architecture** - Define structural design (classes, modules, project doc impact)
- **specify** - Define technical contracts/APIs
- **plan** - Create task checklist

### Development Workflows
- **implement** - Write code
- **test** - Verify behavior
- **review** - Check quality
- **document** - Update docs

### Special Workflows
- **debug** - Systematically debug issues
- **refactor** - Improve code structure

## Choosing the Right Workflow

Use this decision tree:

```
Does this require file changes?
├─ NO → Conversation workflow
└─ YES → Will it take more than 2 hours?
    ├─ NO → Ad-Hoc Task workflow
    └─ YES → Sprint workflow
        ├─ Simple → Mini Sprint (single file)
        └─ Complex → Regular Sprint (directory)
```

### Examples

**Conversation:**
- User: "Should we use REST or GraphQL?"
- User: "Explain how authentication works in this codebase"

**Ad-Hoc Task:**
- "Fix the broken link in README"
- "Update dependencies to latest versions"
- "Add type hints to utils.py"

**Mini Sprint:**
- "Refactor authentication module to use new pattern"
- "Add export functionality to reports"

**Regular Sprint:**
- "Implement complete user authentication system"
- "Migrate from REST to GraphQL"
- "Add multi-tenant support"

## Commit Conventions

### Sprint Work

Use sprint prefix for all sprint-related commits:

```bash
feat(sprint-05): Implement user authentication
fix(sprint-05): Resolve race condition in auth
docs(sprint-05): Update API documentation
test(sprint-05): Add integration tests for auth
refactor(sprint-05): Simplify token validation
```

### Non-Sprint Work

Use descriptive prefixes without sprint reference:

```bash
bugfix: Fix null pointer in parser
hotfix: Patch security vulnerability
docs: Update README installation steps
chore: Update dependencies
refactor: Simplify authentication logic
test: Add unit tests for validator
```

## Work-Mode and Workflow Definitions

All work-mode definitions are located in `defaults/definitions/work-modes/`:

- `conversation.md` - Conversation work-mode
- `ad-hoc-task.md` - Ad-hoc task work-mode
- `sprint-planning.md` - Sprint planning work-mode
- `sprint-execution.md` - Sprint execution work-mode

Workflow type definitions are in `defaults/definitions/workflows/`:
- `research.md`, `design.md`, `specify.md`, `plan.md`
- `implement.md`, `test.md`, `review.md`, `document.md`
- `debug.md`, `refactor.md`

## State Tracking

All workflows are tracked in `.organon/current-context.json` via the `update_workflow_context` MCP tool:

```json
{
  "workflow": "sprint-execution",
  "sprint_id": "16_ClaudeMdRefactor",
  "task_type": "document",
  "task_description": "Creating user guides",
  "updated_at": "2025-10-15T10:30:00-04:00"
}
```

**Examples:**
```json
// Conversation
{"workflow": "conversation", "task_description": "Discussing architecture options"}

// Ad-hoc task
{"workflow": "ad-hoc-task", "task_type": "implement", "task_description": "Updating to Python 3.12"}

// Sprint execution
{"workflow": "sprint-execution", "sprint_id": "16_ClaudeMdRefactor", "task_type": "document", "task_description": "Creating user guides"}
```

## Legacy Mode-Based Workflows

The older mode-based system (Development/Research/Review/Debug) has been replaced by the workflow-task model described above.

**For reference:** Debug Mode rules still apply when debugging:
- Visibility first (capture ALL logs before attempting fixes)
- Evidence-based fixes (every fix based on log evidence)
- Maximum 3 attempts (no endless blind iteration)
- Systematic isolation (verify components work standalone)
