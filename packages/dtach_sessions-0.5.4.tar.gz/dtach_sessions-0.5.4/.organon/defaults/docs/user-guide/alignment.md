# Alignment

This guide covers how Organon keeps four project surfaces in sync: **code, specs, docs, and tests**.

## Why Alignment Matters

Code is the source of truth for what exists. Specs define what should exist. Tests verify it. Docs describe it. When any surface drifts from the others, the project becomes unreliable — docs claim features that don't work, tests verify stale behavior, specs describe things that were never built.

Sprint work is the primary cause of drift. A sprint changes code, which immediately puts it out of alignment with specs, docs, and tests. Ad-hoc fixes, dependency updates, and the passage of time also cause drift.

## The Alignment Graph

```
        Specs
       /     \
      /       \
   Code ——— Tests
      \       /
       \     /
        Docs
```

Four surfaces, six edges. Each edge is an alignment relationship that can drift independently.

## The 9-Type Document Model

The specs surface uses a document model organized into 7 primary types and 3 derived views.

### Primary Types (agent-generated from code)

| # | Type | Format | Purpose |
|---|------|--------|---------|
| 1 | Workflow | YAML | What the system does — multi-step user flows |
| 2 | Model | YAML | What the data looks like — entities, fields, constraints |
| 3 | Invariants | YAML | What must always be true — cross-cutting rules |
| 4 | Decisions | Structured markdown | How it's built — tech stack, patterns, lifecycle phase |
| 5 | Quality | Structured markdown | Quality attributes — NFRs, SLAs, performance targets |
| 6 | Contract | OpenAPI / equivalent | What the system exposes — API surface extracted from code |
| 7 | Screenshots | Images | Visual regression baselines |

### Derived Types (projected from primaries)

| # | Type | Format | Derived From |
|---|------|--------|-------------|
| 8 | State | Structured markdown | Workflows (joint cross-entity state machines) |
| 9 | Architecture | Structured markdown | Decisions + STRUCTURE.md + Contract + Model |
| 10 | User Stories | Structured markdown | Workflows (narrative user journeys) |

Derived types include lineage frontmatter (`derived_from`, `source_hash`, `last_derived`) so staleness is detectable.

### 5 Document Categories

All project documentation falls into five categories:

1. **Navigational** — CLAUDE.md, .organon/CLAUDE.md, STRUCTURE.md (progressive disclosure chain)
2. **Project** — The 9 spec types above that define application correctness
3. **Sprint** — Temporary work docs + backlog (kickoff, requirements, research, design, plan, spec overlays)
4. **Framework** — Organon's own docs (skills, workflows, work modes, templates, rules, guides)
5. **Working** — Dev-docs (research, analysis, incidents)

### How the 9 Types Map to Alignment Edges

| Edge | Primary Types | Derived Types |
|------|--------------|---------------|
| Code ↔ Specs | Workflow, Model, Invariants, Contract, Decisions, Quality, Screenshots | State, Architecture |
| Specs ↔ Tests | Workflow (step coverage), Contract (endpoint coverage), Invariants (rule verification) | State (transition coverage) |
| Specs ↔ Docs | All 9 types inform doc accuracy | — |
| Code ↔ Docs | Contract (API docs), Model (data docs) | Architecture (system overview docs) |

**Detail:** `.organon/defaults/docs/user-guide/spec-formats.md`
**Schema reference:** `.organon/defaults/docs/reference/spec-schemas.md`

## The Manifest

**File:** `.organon/alignment-manifest.json`

The manifest is Organon's persistent record of alignment state. It tracks:

- **When each surface was last checked** and what the git HEAD was at that time
- **Surface status** — `aligned`, `gaps`, `unchecked`, or `none`
- **Detailed check results** per surface (doc completeness, spec coverage, test gaps)
- **Surface paths** — which directories map to which surface (auto-detected on first scan, configurable via `alignment.surfaces.<surface>.paths` in config)
- **Skill run history** — which skills ran, when, and what they updated

### Staleness Detection

The manifest records `git_head` (the commit hash at time of last check). On the next `/align` run, if HEAD has changed, Organon maps changed files to surfaces via `surface_paths` and marks affected surfaces as stale. Only stale surfaces get re-scanned.

The manifest is checked into version control. A new contributor cloning the repo gets the last-known alignment picture.

## `/align` — The Entry Point

`/align` is the single entry point for all alignment work. It handles two states:

### No Manifest (First Run)

Full scan of all four surfaces:
1. Inventories code structure
2. Assesses doc completeness (CLAUDE.md, STRUCTURE.md, progressive disclosure chain)
3. Counts and validates specs (all 9 types)
4. Checks test coverage
5. Creates the manifest with results
6. Generates or augments CLAUDE.md content

### Manifest Exists (Subsequent Runs)

Staleness check:
1. Compares manifest's `git_head` against current HEAD
2. If unchanged — reports cached state instantly (no scanning)
3. If changed — maps changed files to surfaces, re-scans only stale surfaces
4. Updates manifest with new results

### Merge Semantics for CLAUDE.md

When `/align` updates CLAUDE.md, it preserves existing content:
- **Template sections with content:** Augments (adds missing items), never replaces. Flags contradictions for user review.
- **Template sections without content:** Generates from code inventory.
- **Custom sections (not in template):** Preserves in place, never modifies.

### Precondition

`/align` expects a clean working directory (`git status --porcelain` returns empty). If the working directory is dirty, it warns and asks whether to proceed.

## Conversational Kickoff

When a conversation reaches the point where work should become a sprint, the agent captures context conversationally:

1. Scans conversation for decisions, scope, technical approach, open questions
2. Creates the sprint via `create_sprint(name, status="Created")`
3. Writes `kickoff.md` into the sprint directory with structured captures
4. Transitions to sprint planning mode

The planning pass (`/plan-sprint` — three passes: structure, detail, review) then builds the implementation plan.

## Skill Composition Patterns

Skills compose because surfaces overlap. Fixing drift on one surface often reveals drift on adjacent surfaces. After any skill completes, consider whether adjacent edges likely drifted.

### Code Changed

```
/align                 (detect which docs are stale from code changes)
  → /sync-docs-with-specs  (verify docs match specs, update STRUCTURE.md)
```

### Specs Needed

```
/sync-specs-with-code  (create all 7 primary types from code)
  → /validate-specs    (validate all 9 types against code)
```

### Derived Views Stale

```
/derive-views-from-specs  (regenerate State from Workflows, Architecture from Decisions+STRUCTURE+Contract+Model)
```

### Tests Needed

```
/sync-tests-with-specs  (generate tests from specs, run them, classify gaps, iterate)
```

### Sprint Completed

```
/review-sprint          (check sprint coherence)
  → /merge-sprint-specs (merge overlay specs into base)
  → /sync-docs-with-specs  (verify docs match merged specs)
```

### Docs-Specs Consistency

```
/sync-docs-with-specs   (verify docs reflect specs and specs cover doc claims)
```

### Full Health Check

```
/align           (scan all surfaces, build/update manifest)
  → run recommended granular skills for any surfaces with gaps
```

## Context Management Between Skills

Every skill reads its inputs from files (specs, manifest, code, test output) — not from conversation context. This means you can clear context between most skill invocations without losing information. Clearing context between skills reduces noise and improves skill adherence.

**Clear context between skills that have no conversation dependency:**

```
/sync-docs-with-specs      → clear
/sync-specs-with-code      → clear
/derive-views-from-specs   → clear
```

**Keep context when the next skill benefits from reviewing prior output:**

```
/sync-tests-with-specs handles the full generate → run → analyze cycle internally
```

The principle: if the next skill's *file inputs* are sufficient, clear. If human judgment in the next step benefits from seeing the prior skill's conversational output, keep context.

## Specs vs Docs

Both specs and docs describe the system, but they serve different purposes:

| | Specs | Docs |
|--|-------|------|
| **Format** | Machine-readable (YAML, OpenAPI, markdown with frontmatter) | Human-readable markdown |
| **Purpose** | Define contracts — what the system promises to do | Describe the system — what it is and how to use it |
| **Verifiable** | Yes — can be checked against code and tests | Partially — can check factual claims, not prose quality |
| **Authority** | Formal source of truth for behavior | Accessibility layer for navigation and understanding |

When specs and docs disagree, specs are right (or need updating). Docs are the accessibility layer built on top of specs.

`/sync-docs-with-specs` verifies this relationship in both directions:
- Do docs reflect what specs define? (entities, workflows, API endpoints)
- Do specs cover what docs claim? (feature claims backed by specs)

## Manifest Integration

Granular skills write their results back to the manifest after completing their workflow. This makes subsequent `/align` runs faster — surfaces that were recently checked by a granular skill don't need re-scanning.

| Skill | Manifest Section Updated |
|-------|--------------------------|
| `/sync-specs-with-code` | `surfaces.specs.checks.coverage` |
| `/validate-specs` | `surfaces.specs.checks.validity` |
| `/derive-views-from-specs` | `surfaces.specs.checks.derived` |
| `/sync-tests-with-specs` | `surfaces.tests.checks.spec_coverage`, `surfaces.tests.checks.gap_analysis` |
| `/sync-docs-with-specs` | `surfaces.docs.checks.claude_md` |
| `/merge-sprint-specs` | `surfaces.specs` (post-merge state) |
| `/review-sprint` | `skill_runs` only |

If the manifest doesn't exist when a granular skill runs, it creates one with only its own entry populated and other surfaces marked `unchecked`.

Every skill also appends to `skill_runs` (capped at 20 entries), recording what ran, when, and which surfaces were updated.
