# Backlog Management

This guide covers backlog management in Organon, from adding ideas to tracking completion.

## What is the Backlog?

The project backlog (`.organon/sprints/backlog.md`) is a lightweight repository for rough ideas and future work not yet scoped into sprints. It uses a dual numbering system and three-section structure for efficient tracking and reference.

**Key principles:**
- Keep lightweight - detailed planning happens in sprint files
- Dual numbering enables both sequential scanning and stable references
- Three sections (Quick Reference, Completed, Details) optimize for different use cases

## Dual Numbering System

Each backlog item has two identifiers:

### Ordinal Position (N)

**Format:** 1, 2, 3, 4...
**Purpose:** Sequential scanning and quick reference
**Behavior:** Changes when items are added/removed

```markdown
1. [#001] **First Item**: Description
2. [#002] **Second Item**: Description
3. [#003] **Third Item**: Description
```

**Use for:**
- Quick scanning: "What's item 2?"
- Prioritization: "Let's work on item 1 next"
- Natural language: "Start with the first three items"

### Immutable ID (#NNN)

**Format:** #001, #002, #003...
**Purpose:** Stable references across conversations and time
**Behavior:** Never changes once assigned

```markdown
- [#005] **Feature Name** - Sprint 12 (commit a1b2c3d)
```

**Use for:**
- Stable references: "Work on backlog #005"
- Tracking: Item #005 stays #005 even after other items are removed
- History: "What happened to #003?" (check Completed section)

### Assignment Rules

- IDs are assigned sequentially when items are created
- Next ID = highest existing ID + 1
- IDs are never reused
- Both ordinals and IDs resolve to the same item during querying

## Three-Section Structure

### Quick Reference

**Purpose:** Fast scanning of pending work

```markdown
## Quick Reference

**Pending items** (ordinal numbering, scans cleanly):

1. [#001] **Item One**: Short one-line description
2. [#002] **Item Two**: Another brief description
3. [#003] **Item Three**: Quick summary of the idea
```

**Guidelines:**
- One-line descriptions only
- Ordinals (1, 2, 3...) for easy scanning
- Immutable IDs [#NNN] for stable reference
- Keep in priority order (most important first)

### Completed

**Purpose:** Track finished work with sprint and commit references

```markdown
## Completed

**Finished items** (immutable IDs for stable references):

- [#000] **Example Completed Item** - Sprint 15 (commit a1b2c3d)
- [#042] **Authentication System** - Sprint 18 (commit e4f5g6h)
```

**Guidelines:**
- Shows immutable ID only (no ordinals)
- Includes sprint number and commit hash
- Most recent completions first
- Details remain in Details section for searchability

### Details

**Purpose:** Full descriptions for context and searchability

```markdown
## Details

### 1. [#001] Item One

Optional detailed description explaining:
- Context and motivation
- Implementation approach
- Deliverables
- Trade-offs
- Dependencies

### 2. [#002] Item Two

More detailed description...

### [#000] Example Completed Item

Historical details for completed work remain searchable here.
```

**Guidelines:**
- Matches ordinal from Quick Reference for pending items
- Completed items lose ordinals, keep only immutable ID
- Full descriptions (context, approach, trade-offs, dependencies)
- Optional but recommended for complex items
- Historical details preserved for completed items

## Workflow Operations

### Adding a New Item

1. **Assign next immutable ID:**
   ```markdown
   # Find highest ID in backlog (e.g., #005)
   # Next ID = #006
   ```

2. **Add to Quick Reference:**
   ```markdown
   ## Quick Reference

   1. [#001] **Existing Item**: Description
   2. [#002] **Another Item**: Description
   3. [#006] **New Item**: Brief description  # New item added
   ```

3. **Add to Details section:**
   ```markdown
   ## Details

   ### 3. [#006] New Item

   Detailed description explaining context, approach, deliverables, etc.
   ```

### Moving Item to Completion

When a backlog item is implemented in a sprint:

1. **Remove from Quick Reference:**
   ```markdown
   ## Quick Reference

   1. [#001] **Item One**: Description
   # Item #006 removed
   2. [#002] **Item Two**: Description  # Renumbered from 3
   ```

2. **Add to Completed section:**
   ```markdown
   ## Completed

   - [#006] **Item Name** - Sprint 16 (commit a1b2c3d)  # Added with sprint and commit
   - [#000] **Previous Item** - Sprint 15 (commit e4f5g6h)
   ```

3. **Update Details section:**
   ```markdown
   ## Details

   ### 1. [#001] Item One
   Details for pending item...

   ### 2. [#002] Item Two  # Renumbered from 3
   Details for pending item...

   ### [#006] Item Name  # Ordinal removed, ID preserved
   Historical details remain searchable.
   ```

### Reprioritizing Items

Change order in Quick Reference (ordinals update, IDs stay constant):

```markdown
# Before
1. [#001] **Low Priority**: Description
2. [#005] **High Priority**: Description

# After (swapped priority)
1. [#005] **High Priority**: Description  # Ordinal changed, ID unchanged
2. [#001] **Low Priority**: Description   # Ordinal changed, ID unchanged
```

Update ordinals in Details section to match.

## MCP Tools

Organon provides MCP tools for token-efficient backlog queries:

### list_backlog_items

List backlog items with filtering:

```python
# List all pending items
list_backlog_items(status="pending")

# List completed items
list_backlog_items(status="completed")

# List all items
list_backlog_items()
```

**Returns:**
```json
{
  "items": [
    {
      "id": "001",
      "ordinal": 1,
      "title": "Item One",
      "description": "Brief description",
      "status": "pending"
    }
  ],
  "count": 1
}
```

**Token savings:** ~75% vs reading full backlog.md

### get_backlog_item

Get detailed information for specific item:

```python
# By immutable ID
get_backlog_item(identifier="#005")

# By ordinal position
get_backlog_item(identifier="3")
```

**Returns:**
```json
{
  "id": "005",
  "ordinal": 3,
  "title": "Item Title",
  "description": "Brief description",
  "details": "Full detailed description...",
  "status": "pending"
}
```

**Token savings:** ~85% vs reading full backlog.md

## Validation Rules

Backlog format is validated by `backlog.format` rule:

### Required Sections

- `## Quick Reference`
- `## Completed`
- `## Details`

### Dual Numbering

All Quick Reference items must have format:
```markdown
N. [#XXX] **Title**: Description
```

Where:
- N = ordinal (1, 2, 3...)
- XXX = immutable ID (001, 002, 003...)

### No Duplicate IDs

Each immutable ID must be unique across all sections.

### Details Consistency

Every item in Quick Reference must have corresponding Details section.

### Running Validation

```bash
# Validate backlog format
organon validate --rule backlog.format

# Validate all rules including backlog
organon validate
```

## Best Practices

### When to Use Backlog

**Use backlog for:**
- Rough ideas not yet scoped
- Future work requiring research
- Low-priority enhancements
- Ideas from conversations
- Technical debt items

**Don't use backlog for:**
- Well-scoped work (create sprint instead)
- Active work (should be in sprint)
- Urgent bugs (ad-hoc task or sprint)

### Sizing Items

Keep items small enough to scope into single sprint:
- If item requires multiple sprints, break into smaller items
- If scoping is unclear, item belongs in backlog
- When ready to scope, move to sprint planning

### Maintenance

**Regular cleanup:**
- Archive or remove stale items quarterly
- Consolidate duplicate items
- Update priorities based on project goals
- Review completed items for patterns

**Don't over-plan:**
- Brief descriptions in Quick Reference
- Detailed context in Details section only when helpful
- Deep planning happens in sprint files, not backlog

### Integration with Sprints

**Backlog → Sprint workflow:**

1. Review backlog item (#005)
2. Create sprint: `organon sprints create --name "FeatureName"`
3. During sprint planning, reference backlog item in requirements
4. When sprint completes, move backlog item to Completed section

**Sprint → Backlog workflow:**

1. During sprint, discover new work
2. Add to backlog with next ID
3. Continue with original sprint
4. New backlog item can be sprint later

## CLI Commands

```bash
# Query backlog (via MCP tools)
# Use via Claude Code agent:
# "List pending backlog items"
# "Show details for backlog #005"

# Validate backlog format
organon validate --rule backlog.format

# Initialize backlog in new project
organon init  # Creates .organon/sprints/backlog.md from template
```

## Template

Backlog template location:
- Package: `defaults/templates/files/backlog.md`
- Project: `.organon/defaults/templates/files/backlog.md` (copied on init)

Created automatically by `organon init` at `.organon/sprints/backlog.md`.

## Examples

### Simple Backlog

```markdown
# Project Backlog

## Quick Reference

1. [#001] **Dark Mode**: Add dark mode toggle to settings
2. [#002] **Export Feature**: Export data to CSV/JSON formats
3. [#003] **Notification System**: In-app notifications for events

## Completed

- [#000] **User Authentication** - Sprint 12 (commit a1b2c3d)

## Details

### 1. [#001] Dark Mode

Add dark mode toggle in application settings. Should persist user preference and apply theme-aware styling to all components.

### 2. [#002] Export Feature

Users need ability to export their data in multiple formats (CSV, JSON). Include filtering and date range selection.

### 3. [#003] Notification System

Implement in-app notification system for important events. Include notification center, read/unread tracking, and preferences.

### [#000] User Authentication

JWT-based authentication with login, registration, password reset. Completed in Sprint 12.
```

### Complex Backlog with Many Items

```markdown
# Project Backlog

## Quick Reference

**Pending items:**

1. [#015] **API Rate Limiting**: Implement rate limiting for public API
2. [#018] **Search Improvements**: Add fuzzy search and filters
3. [#022] **Mobile App**: Create mobile companion app
4. [#023] **Performance Monitoring**: Add APM integration
5. [#024] **Bulk Operations**: Support bulk import/export

## Completed

- [#021] **Caching Layer** - Sprint 18 (commit e4f5g6h)
- [#019] **Email Templates** - Sprint 17 (commit c2d3e4f)
- [#016] **User Roles** - Sprint 16 (commit a1b2c3d)

## Details

### 1. [#015] API Rate Limiting

Implement rate limiting for public API endpoints to prevent abuse. Use token bucket algorithm, configure limits per endpoint and user tier. Track usage metrics for capacity planning.

### 2. [#018] Search Improvements

Current search is exact match only. Add fuzzy search using Elasticsearch or similar, advanced filters (date range, categories, tags), search result ranking. Consider search analytics.

### 3. [#022] Mobile App

Create mobile companion app for iOS/Android. Core features: authentication, data sync, push notifications. Consider React Native for code sharing.

### 4. [#023] Performance Monitoring

Integrate APM tool (DataDog, New Relic, or self-hosted) for performance monitoring. Track request latency, error rates, database query performance. Set up alerting.

### 5. [#024] Bulk Operations

Add bulk import/export capabilities. Support CSV/JSON formats, validation, error reporting, background processing for large datasets.

### [#021] Caching Layer

Redis-based caching layer implemented in Sprint 18. Reduced API response times by 60%.

### [#019] Email Templates

Email template system with support for transactional emails (welcome, password reset, notifications). Completed Sprint 17.

### [#016] User Roles

Role-based access control (admin, editor, viewer) with permission system. Completed Sprint 16.
```

## See Also

- `.organon/defaults/docs/user-guide/sprints.md` - Sprint workflow and lifecycle
- `.organon/defaults/docs/reference/mcp-tools.md` - Complete MCP tool reference
- `.organon/defaults/docs/reference/validation-rules.md` - Validation rule documentation
- `.organon/defaults/templates/files/backlog.md` - Backlog template
