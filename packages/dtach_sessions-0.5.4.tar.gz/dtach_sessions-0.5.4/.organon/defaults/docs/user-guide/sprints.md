# Sprint Development Process

This guide covers the complete sprint lifecycle in Organon, from planning to completion.

## Sprint Numbering

**CRITICAL RULE:** Sprint numbers represent **execution order** (when started), not creation order.

### Format

`NN_Name_Status` where:
- **NN**: Sequential number based on **when sprint is started** (not created)
- **Name**: CamelCase description
- **Status**: Created | Next | Current | Completed | Paused

### Sprint Lifecycle

#### 1. Creation (Planning)

Create sprint with name only - NO number yet:

```bash
# Using organon CLI
organon sprints create --name "FeatureName"

# Or manually create
.organon/sprints/FeatureName_Created.md  # Mini sprint
.organon/sprints/FeatureName_Created/    # Regular sprint
```

- Format: `Name_Created/` or `Name_Created.md`
- Set **Created** timestamp
- Status: Created (planning in progress or complete, working on requirements → plan)
- Sprint remains in Created status until ready to queue for execution

#### 2. Queue (Optional)

Mark as next sprint to start:

```bash
# Rename file/directory
mv FeatureName_Created.md FeatureName_Next.md
```

- Rename: `Name_Created` → `Name_Next`
- Status: Next (queued to start, but still no number)
- Only one sprint should be "Next" at a time

#### 3. Start (Execution)

Assign number when actually starting work:

```bash
# Rename to add number
mv FeatureName_Next.md 16_FeatureName_Current.md
```

- Rename: `Name_Next` → `NN_Name_Current` (or `Name_Created` → `NN_Name_Current` if skipping Next)
- Set **Started** timestamp (this determines the number)
- Status: Current
- Number = count of all started sprints + 1

#### 4. Completion

Mark as completed:

```bash
# Rename to mark completed
mv 16_FeatureName_Current.md 16_FeatureName_Completed.md
```

- Rename: `NN_Name_Current` → `NN_Name_Completed`
- Status: Completed

### Examples

```
# Created (planning in progress or complete)
.organon/sprints/TestingWorkflows_Created.md

# Next (queued to start - still no number)
.organon/sprints/TestingWorkflows_Next.md

# Started (assigned number 15)
.organon/sprints/15_TestingWorkflows_Current.md

# Completed
.organon/sprints/15_TestingWorkflows_Completed.md
```

### Status Meanings

- **Created**: Sprint planning in progress or complete, not yet queued (can have multiple)
- **Next**: Sprint is queued to be started next (should only have one)
- **Current**: Sprint is actively being worked on (has number)
- **Paused**: Sprint temporarily stopped (has number)
- **Completed**: Sprint finished (has number)

### Rationale

- Sprint numbers reflect actual execution sequence
- Can plan multiple sprints without numbering conflicts
- "Next" status clarifies which sprint is queued
- Started timestamp provides explicit ordering
- Allows decimal numbering (5.1, 5.2) for parallel work in branches

## Sprint Structure Types

### Regular Sprint (Directory)

For large or complex work requiring multiple days:

```
.organon/sprints/NN_Name_Status/
├── research.md    # Investigation and analysis
├── design.md      # Architecture decisions
├── spec.md        # Technical specifications
├── plan.md        # Task checklist with commit tracking
└── specs/         # Overlay spec YAML files (optional)
```

The optional `specs/` subdirectory holds overlay spec files that describe additions or modifications to base specs in `.organon/specs/`. These are merged into the base on sprint completion using `organon admin merge-apply`. See `.organon/defaults/docs/user-guide/spec-formats.md` for details on overlay specs.

**When to use:**
- Multiple days of work
- Significant planning needed
- Complex implementation requiring detailed specs

### Mini Sprint (Single File)

For medium-sized work (half-day to 2 days):

```markdown
# Mini Sprint: Name

**Created:** 2025-10-15
**Started:** 2025-10-15
**Status:** Current
**Number:** 16
**Type:** Mini Sprint

## Requirements
[What we're building - goals, features, success criteria]

## Research
[Investigation and analysis]

## Design
[Approach decisions and trade-offs]

## Architecture
[Structural design - classes, modules, project doc impact]

## Spec
[Technical specifications]

## Plan
- [ ] Task 1 (commit: )
- [ ] Task 2 (commit: )

## Notes
[Additional context]
```

**When to use:**
- Half-day to 2 days of work
- Moderate planning needed
- Less complex than regular sprint

**Decision:** Developer choice based on complexity (no formal rules)

## Working in a Sprint

### Phase 1: Planning Level

Create the workflow by filling in planning documents:

1. **Requirements** - What we're building and why
   - What are we building?
   - What are the goals and success criteria?
   - What's in/out of scope?

2. **Research** - Problem statement, investigation, findings
   - What problem are we solving?
   - What have we learned?
   - What are the constraints?

3. **Design** - Approach decisions and trade-offs
   - What's the overall approach?
   - What design decisions did we make?
   - What alternatives did we consider?

4. **Architecture** - Structural design
   - What classes/modules are needed?
   - What are the NFRs (performance, security)?
   - **Review project docs** (docs/design.md, docs/architecture.md)
   - What needs to change in project-level docs?

5. **Spec** - Technical specifications, APIs, examples
   - What are the technical details?
   - What are the interfaces/contracts?
   - What are concrete examples?

6. **Plan** - Task checklist using three-pass planning
   - **Pass 1:** Structure Planning (15-30 min)
     - Create phases with high-level tasks
     - Tag task types (implement, test, document, etc.)
   - **Pass 2:** Detail Planning (30-60 min)
     - Expand to explicit subtasks
     - Use workflow planning rules from `defaults/definitions/workflows/`
   - **Pass 3:** Review & Refinement (15-30 min, REQUIRED)
     - Validate using `defaults/definitions/workflows/plan-review.md` checklist

Mark plan as reviewed before transitioning to Development Level.

### Phase 2: Development Level

Execute the workflow by following the plan:

1. **Work through tasks** - Follow task order in plan.md
2. **Mark completed tasks** - Update with commit hash:
   ```markdown
   - [x] Implement authentication (commit: a1b2c3d)
   ```
3. **Commit with convention**:
   ```bash
   git commit -m "feat(sprint-16): Implement authentication"
   ```
4. **Cycle back if needed** - Return to Planning if assumptions change

### Completing Tasks

Required steps before declaring any task/phase complete:

1. Implement the work
2. Commit the implementation
3. Update sprint plan.md with commit hash: `- [x] Task (commit: a1b2c3d)`
4. Commit the documentation update
5. THEN declare task/phase complete

Never require reminders to update sprint documentation.

### Completing the Sprint

Before marking sprint as completed:

- ✓ All tasks checked off in plan
- ✓ All commits tracked with hashes
- ✓ Tests passing
- ✓ Documentation updated
- ✓ Rename: `NN_Name_Current/` → `NN_Name_Completed/`

## Using the CLI

```bash
# Create new sprint
organon sprints create --name "FeatureName"

# List sprints
organon sprints list
organon sprints list --status Current

# Update sprint status
organon sprints update-status .organon/sprints/16_Feature_Current Completed
```

## Templates

Sprint file templates:
- Regular sprint: `defaults/templates/files/sprints/regular/` (4 files)
- Mini sprint: `defaults/templates/files/sprints/mini-sprint.md`
- Plan template: `defaults/templates/files/sprints/plan.md`

Work-mode definitions:
- `defaults/definitions/work-modes/sprint-planning.md` - Planning work-mode
- `defaults/definitions/work-modes/sprint-execution.md` - Execution work-mode
