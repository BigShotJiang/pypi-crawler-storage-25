# Spec Schema Reference

Technical schema reference for all 9 spec types in `.organon/specs/`.

## YAML Primary Types

All YAML specs use a flat, one-file-per-entity structure with a common header pattern: `type`, entity/scope identifier, `source`, `last_updated`.

### ModelSpec (`.model.yaml`)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | yes | Must be `model` |
| `entity` | string | yes | Entity name (e.g., "User") |
| `source` | string | no | Source file path |
| `last_updated` | string | no | ISO 8601 date |
| `fields` | list[FieldDef] | yes | Field definitions |
| `relationships` | list[RelationshipDef] | no | Entity relationships |

**FieldDef:**

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `name` | string | yes | — | Field name |
| `type` | string | yes | — | Field type (uuid, string, int, decimal, datetime, list[T]) |
| `constraints` | list[string] | no | [] | Constraint descriptions |
| `format` | string | no | null | Format hint (e.g., "email") |
| `default` | any | no | null | Default value |
| `values` | list[string] | no | null | Allowed values (enum) |
| `note` | string | no | null | Additional context |

**RelationshipDef:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `name` | string | yes | Relationship name |
| `target` | string | yes | Target entity |
| `type` | string | yes | Relationship type (one-to-many, many-to-one, etc.) |
| `back_populates` | string | no | Inverse relationship name |
| `cascade` | string | no | Cascade behavior (e.g., "all, delete-orphan") |
| `constraints` | list[string] | no | Relationship constraints |
| `note` | string | no | Additional context |

### WorkflowSpec (`.workflow.yaml`)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | yes | Must be `workflow` |
| `entity` | string | yes | Entity whose lifecycle this tracks |
| `field` | string | yes | Field that carries state (e.g., "status") |
| `source` | string | no | Source file path |
| `last_updated` | string | no | ISO 8601 date |
| `states` | list[StateDef] | yes | State definitions |
| `transitions` | list[TransitionDef] | yes | Transition definitions |

**StateDef:**

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `name` | string | yes | — | State name |
| `description` | string | no | — | What this state means |
| `initial` | bool | no | false | Whether this is the initial state |
| `terminal` | bool | no | false | Whether this is a terminal state |

**TransitionDef:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `from` | string | yes | Source state |
| `to` | string | yes | Target state |
| `trigger` | string | yes | What causes this transition |
| `side_effects` | list[string] | no | Effects of the transition |
| `preconditions` | list[string] | no | Conditions required before transition |
| `note` | string | no | Additional operational context |
| `rationale` | string | no | Why this transition exists or why preconditions were asserted — design intent vs observed code behavior |

### InvariantsSpec (`.invariants.yaml`)

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | yes | Must be `invariants` |
| `scope` | string | yes | Scope (e.g., "application", "module") |
| `source` | string | no | Source directory |
| `last_updated` | string | no | ISO 8601 date |
| `invariants` | list[InvariantDef] | yes | Invariant rules |

**InvariantDef:**

| Field | Type | Required | Default | Description |
|-------|------|----------|---------|-------------|
| `id` | string | yes | — | Invariant ID (e.g., "AUTH-01") |
| `rule` | string | yes | — | Rule description |
| `enforced_by` | string | yes | — | Where/how the rule is enforced |
| `severity` | string | no | critical | critical, high, medium, low |
| `rationale` | string | no | null | Why this rule was asserted — what was observed in code vs what was inferred from standards or best practices |

## Markdown Primary Types

### Decisions (`.decisions.md`)

**Frontmatter (required):**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | yes | Must be `decisions` |
| `project` | string | yes | Project name |
| `lifecycle_phase` | string | yes | Design, Alpha, Beta, or Production |
| `last_updated` | string | yes | ISO 8601 datetime |

**Body sections:** Tech Stack, Architecture, Libraries & Dependencies, Patterns & Conventions, Lifecycle Phase.

### Quality (`.quality.md`)

**Frontmatter (required):**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | yes | Must be `quality` |
| `project` | string | yes | Project name |
| `last_updated` | string | yes | ISO 8601 datetime |

**Body sections:** Performance, Scalability, Availability, Security, Observability.

## Contract Type

### OpenAPI Spec (`openapi.json` / `openapi.yaml`)

Standard OpenAPI 3.x specification. No custom schema — follows the [OpenAPI Specification](https://spec.openapis.org/oas/v3.1.0).

Extracted from code by `/sync-specs-with-code`. Validated against Workflow step references by `/validate-specs`.

## Screenshots Type

Image files (PNG) in `screenshots/` subdirectory. No schema — presence and visual diff are the validation mechanism.

## Derived Types

Both derived types use the same frontmatter structure for lineage tracking.

**Frontmatter (required):**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `type` | string | yes | Must be `derived` |
| `derived_from` | list[string] | yes | Source file paths |
| `source_hash` | string | yes | Combined hash of source files |
| `last_derived` | string | yes | ISO 8601 datetime |

### State (`derived/*.state.md`)

**Derived from:** Workflow specs.

**Body sections:** Entity group name as H2, then States (all observed states across entity group), Transitions (legal transitions with source workflow reference), Illegal Joint States (forbidden combinations with rationale).

### Architecture (`derived/*.architecture.md`)

**Derived from:** Decisions spec + STRUCTURE.md + Contract spec + Model specs.

**Body sections:** System Overview, Services & Components, Communication, Data Flow, Deployment.

## File Naming Conventions

| Type | Pattern | Example |
|------|---------|---------|
| Model | `{domain}.model.yaml` | `checkout.model.yaml` |
| Workflow | `{domain}.workflow.yaml` | `checkout.workflow.yaml` |
| Invariants | `{domain}.invariants.yaml` | `checkout.invariants.yaml` |
| Decisions | `{domain}.decisions.md` | `app.decisions.md` |
| Quality | `{domain}.quality.md` | `app.quality.md` |
| Contract | `openapi.json` or `openapi.yaml` | `openapi.json` |
| Screenshots | `screenshots/{name}.png` | `screenshots/dashboard.png` |
| State (derived) | `derived/{group}.state.md` | `derived/checkout-payment.state.md` |
| Architecture (derived) | `derived/{name}.architecture.md` | `derived/system.architecture.md` |

Multiple specs can share the same domain prefix (e.g., `checkout`) to indicate they describe the same domain.

## Cross-Reference Validation

| Reference | Source | Target |
|-----------|--------|--------|
| `WorkflowSpec.entity` | WorkflowSpec | ModelSpec entity |
| `TransitionDef.trigger` endpoint refs | WorkflowSpec | Contract endpoints |
| `InvariantDef.enforced_by` | InvariantsSpec | Source file paths |
| `RelationshipDef.target` | ModelSpec | Other ModelSpec entities |
| `derived_from` paths | Derived specs | Primary spec files |

Run `/validate-specs` to validate all cross-references.

**User guide:** `.organon/defaults/docs/user-guide/spec-formats.md`
**Alignment guide:** `.organon/defaults/docs/user-guide/alignment.md`
