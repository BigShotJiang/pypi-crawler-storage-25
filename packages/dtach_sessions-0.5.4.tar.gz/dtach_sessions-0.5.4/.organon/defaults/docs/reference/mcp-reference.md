# MCP Reference

Reference documentation for Organon's MCP (Model Context Protocol) server and tools.

## Overview

The Organon MCP server exposes sprint management and codebase analysis functionality to AI agents.

## Configuration

Add to `~/.config/claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "organon": {
      "command": "uv",
      "args": [
        "run",
        "--directory",
        "/absolute/path/to/organon",
        "organon-mcp"
      ]
    }
  }
}
```

## Server

### Starting the Server

```bash
# Via Claude Desktop/Code (automatic with config)
# Or manually:
uv run organon-mcp
```

### Server Information

- **Protocol:** MCP (Model Context Protocol)
- **Transport:** stdio
- **Python Module:** `organon.mcp_server`

## Available Tools

### `create_sprint`

Create a new sprint with standard structure.

**Parameters:**
- `number` (string, required) - Sprint number (e.g., "01", "05")
- `name` (string, required) - Sprint name in CamelCase
- `status` (string, optional) - Initial status (default: "Pending")

**Returns:**
```json
{
  "success": true,
  "sprint_path": ".organon/sprints/NN_Name_Status/",
  "files_created": [
    "research.md",
    "design.md",
    "spec.md",
    "plan.md"
  ]
}
```

**Example:**
```json
{
  "number": "08",
  "name": "AddExportFeature",
  "status": "Current"
}
```

### `list_sprints`

List all sprints, optionally filtered by status.

**Parameters:**
- `status` (string, optional) - Filter by status

**Returns:**
```json
{
  "success": true,
  "sprints": [
    {
      "number": "05",
      "name": "WorkflowStructureDesign",
      "status": "Completed",
      "path": ".organon/sprints/05_WorkflowStructureDesign_Completed.md",
      "type": "mini"
    },
    {
      "number": "06",
      "name": "CodebaseScannerEnhancements",
      "status": "Current",
      "path": ".organon/sprints/06_CodebaseScannerEnhancements_Current/",
      "type": "regular"
    }
  ],
  "count": 2
}
```

**Example:**
```json
{
  "status": "Current"
}
```

### `update_sprint_status`

Update the status of an existing sprint.

**Parameters:**
- `sprint_path` (string, required) - Path to sprint directory or file
- `new_status` (string, required) - New status value

**Returns:**
```json
{
  "success": true,
  "old_path": ".organon/sprints/08_AddExportFeature_Current/",
  "new_path": ".organon/sprints/08_AddExportFeature_Completed/",
  "status_updated": true
}
```

**Example:**
```json
{
  "sprint_path": ".organon/sprints/08_AddExportFeature_Current",
  "new_status": "Completed"
}
```

### `list_backlog_items`

List backlog items with optional filtering by status.

**Token Savings:** ~75% vs reading full backlog.md

**Parameters:**
- `status` (string, optional) - Filter by status: "pending" or "completed"

**Returns:**
```json
{
  "success": true,
  "items": [
    {
      "id": "001",
      "ordinal": 1,
      "title": "Item One",
      "description": "Short one-line description",
      "status": "pending"
    },
    {
      "id": "002",
      "ordinal": 2,
      "title": "Item Two",
      "description": "Another brief description",
      "status": "pending"
    }
  ],
  "count": 2
}
```

**Example:**
```json
{
  "status": "pending"
}
```

**Efficiency Logging:**
Automatically logs to `.organon/efficiency.jsonl`:
```json
{
  "operation": "list_backlog_items",
  "tokens_saved": 1250,
  "tokens_used": 320,
  "savings_percent": 79.6
}
```

### `get_backlog_item`

Get detailed information for specific backlog item by immutable ID or ordinal position.

**Token Savings:** ~85% vs reading full backlog.md

**Parameters:**
- `identifier` (string, required) - Immutable ID (e.g., "#005") or ordinal position (e.g., "3")

**Returns:**
```json
{
  "success": true,
  "item": {
    "id": "005",
    "ordinal": 3,
    "title": "Item Title",
    "description": "Brief description",
    "details": "Optional detailed description explaining context, motivation, implementation approach, deliverables, trade-offs, etc.",
    "status": "pending"
  }
}
```

**Example:**
```json
{
  "identifier": "#005"
}
```

or

```json
{
  "identifier": "3"
}
```

**Efficiency Logging:**
Automatically logs to `.organon/efficiency.jsonl`:
```json
{
  "operation": "get_backlog_item",
  "tokens_saved": 1480,
  "tokens_used": 230,
  "savings_percent": 86.5
}
```

### `analyze_workflow_logs`

Analyze Claude Code workflow logs for tool usage patterns.

**Parameters:**
- `logs_dir` (string, optional) - Path to .claude directory (default: ~/.claude)
- `output_format` (string, optional) - Output format: "json" or "summary" (default: "json")

**Returns:**
```json
{
  "success": true,
  "format": "json",
  "analysis": {
    "analysis_type": "tool_usage",
    "summary": {
      "total_tool_calls": 45,
      "total_errors": 2,
      "unique_tools": 6,
      "error_rate": 0.044,
      "user_messages": 12
    },
    "tool_usage": {
      "Bash": {"count": 15, "errors": 1, "commands": ["ls -la", "git status"]},
      "Read": {"count": 20, "errors": 0, "commands": []},
      "Edit": {"count": 10, "errors": 1, "commands": []}
    }
  }
}
```

**Example:**
```json
{
  "output_format": "summary"
}
```

### `analyze_conversations`

Analyze conversation history for workflow patterns.

**Parameters:**
- `project_filter` (string, optional) - Filter by project name (e.g., "organon")
- `output_format` (string, optional) - Output format: "json" or "summary" (default: "json")
- `logs_dir` (string, optional) - Path to .claude directory (default: ~/.claude)

**Returns:**
```json
{
  "success": true,
  "format": "json",
  "conversations_analyzed": 5,
  "tool_calls_found": 150,
  "analysis": {
    "analysis_type": "tool_usage",
    "summary": {
      "total_tool_calls": 150,
      "total_errors": 3,
      "unique_tools": 8,
      "error_rate": 0.02
    },
    "tool_usage": {
      "Read": {"count": 45, "errors": 0},
      "Bash": {"count": 35, "errors": 2},
      "Edit": {"count": 30, "errors": 1}
    }
  }
}
```

**Example:**
```json
{
  "project_filter": "organon",
  "output_format": "json"
}
```

### `query_workflows` (Sprint 10)

Query workflow templates by category or scenario with automatic efficiency tracking.

**Token Savings:** 75-99% vs reading all workflows

**Parameters:**
- `category` (string, optional) - Filter by category (e.g., "sprint", "development", "debug")
- `scenario` (string, optional) - Search keyword (e.g., "bug", "refactor", "test")
- `include_description` (boolean, optional) - Include full description (default: true)

**Returns:**
```json
{
  "success": true,
  "workflows": [
    {
      "name": "Workflow: Debug Application",
      "path": "src/organon/templates/workflows/debug/debug-application.md",
      "category": "debug",
      "description": "Systematic debugging workflow...",
      "when_to_use": "Application failures, unexpected behavior",
      "tokens": 1451,
      "prerequisites": ["Project CLAUDE.md", "Observability setup"],
      "process_steps": ["Visibility First", "Check Observability", "Reproduce", "Isolate", "Fix", "Verify"]
    }
  ],
  "total_count": 1
}
```

**Example:**
```json
{
  "category": "debug",
  "include_description": true
}
```

**Efficiency Logging:**
Automatically logs to `.organon/efficiency.jsonl`:
```json
{
  "operation": "query_workflows",
  "tokens_saved": 15082,
  "tokens_used": 131,
  "savings_percent": 99.14
}
```

### `query_tasks` (Sprint 10)

Query task templates with automatic efficiency tracking.

**Token Savings:** 67-99% vs reading all tasks

**Parameters:**
- `related_to` (string, optional) - Search keyword (e.g., "test", "document", "implement")
- `include_description` (boolean, optional) - Include full description (default: true)

**Returns:**
```json
{
  "success": true,
  "tasks": [
    {
      "name": "Test Task",
      "path": "src/organon/templates/tasks/test.md",
      "description": "Verify functionality through systematic testing",
      "tokens": 1987
    }
  ],
  "total_count": 1
}
```

**Example:**
```json
{
  "related_to": "test"
}
```

### `get_all_sprints_summary` (Sprint 10)

Get summary of all sprints with progress tracking.

**Token Savings:** 60-96% vs reading all sprint files

**Parameters:**
- `status` (string, optional) - Filter by status (Current, Completed, Paused, Pending)

**Returns:**
```json
{
  "success": true,
  "sprints": [
    {
      "number": 10,
      "name": "IntelligentMCPQueryLayer",
      "status": "Pending",
      "path": ".organon/sprints/10_IntelligentMCPQueryLayer_Pending",
      "total_tasks": 53,
      "completed_tasks": 47,
      "in_progress_tasks": 1,
      "next_task": "Write integration tests",
      "last_commit": "84f9c8f",
      "tokens": 12450
    }
  ],
  "total_count": 1
}
```

**Example:**
```json
{
  "status": "Current"
}
```

### `get_current_sprint_context` (Sprint 10)

Get comprehensive context for current sprint with aggregated data.

**Token Savings:** 60-80% vs reading all files separately

**Parameters:** None

**Returns:**
```json
{
  "success": true,
  "sprint_context": {
    "summary": {
      "number": 10,
      "name": "IntelligentMCPQueryLayer",
      "status": "Current",
      "total_tasks": 53,
      "completed_tasks": 47
    },
    "research_findings": [
      "Templates already exist (14 workflows, 11 tasks)",
      "Token efficiency critical (60-84% savings possible)"
    ],
    "design_decisions": [
      "Use in-memory caching for metadata",
      "JSONL format for efficiency logs",
      "Session correlation via session_id"
    ],
    "spec_summary": "Implement intelligent MCP query layer...",
    "plan_tasks": [
      {
        "description": "Create templates module structure",
        "status": "completed",
        "commit": "04f5d26"
      }
    ],
    "recent_commits": [
      "04f5d26 feat(sprint-10): Implement TemplateMetadata"
    ]
  }
}
```

## Response Format

All tools return JSON with the following structure:

**Success Response:**
```json
{
  "success": true,
  "data": { ... }
}
```

**Error Response:**
```json
{
  "success": false,
  "error": "Error message describing what went wrong"
}
```

## Error Handling

Common errors and their meanings:

- **"Sprint directory not found"** - Sprint path doesn't exist
- **"Invalid sprint number format"** - Number must be 2 digits (01, 02, etc.)
- **"Invalid status"** - Status must be Current, Completed, Paused, or Pending
- **"Sprint already exists"** - Cannot create duplicate sprint number
- **"File I/O error"** - Permission or filesystem error

## Best Practices

### For Agent Developers

1. **Always check `success` field** in responses
2. **Handle errors gracefully** - show error message to user
3. **Use absolute paths** when providing sprint_path parameter
4. **Validate sprint number format** before calling create_sprint (2 digits)
5. **Filter by status** when listing sprints to reduce context
6. **Use query tools for efficiency** - Prefer query_workflows/query_tasks over reading all files
7. **Monitor efficiency** - Check `.organon/efficiency.jsonl` for token savings

### For MCP Tool Developers

See [Developer Guide - Adding MCP Tools](../developer-guide.md#adding-mcp-tools) for implementation guidelines.

## Debugging

### Check Server Status

```bash
# Run server manually to see output
uv run organon-mcp
```

### Check Configuration

Verify configuration file location and format:
- **macOS:** `~/.config/claude/claude_desktop_config.json`
- **Linux:** `~/.config/claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

### Check Logs

Claude Desktop/Code logs may contain MCP server errors. Log location varies by platform.

## Extending MCP Tools

To add new MCP tools, see [Developer Guide - Adding MCP Tools](../developer-guide.md#adding-mcp-tools).

## Efficiency Tracking

All Sprint 10 query tools automatically log efficiency metrics. See [Efficiency Tracking Reference](efficiency-tracking.md) for details.

**Key Features:**
- Automatic token savings calculation
- Session correlation for timeline analysis
- JSONL logging to `.organon/efficiency.jsonl`
- CLI commands for viewing metrics

**View Efficiency:**
```bash
organon logs metrics --by-operation
```

---

## Alignment & Status Tools

### get_alignment_report

```
get_alignment_report(scope: str = "full") -> JSON
```

Run alignment scan between specs, tests, and code. Returns alignment score, gap summary, and gap details.

**Parameters:**
- `scope` (string, optional): `"full"` for complete scan, `"sprint"` for scoped to recent changes. Default: `"full"`.

**Response:**
```json
{
  "success": true,
  "score": 0.85,
  "summary": {"untested": 2, "unimplemented": 1},
  "gap_count": 3,
  "gaps": [
    {
      "gap_type": "untested",
      "severity": "warning",
      "source": ".organon/specs/checkout.workflow.yaml",
      "message": "Workflow 'WF-001' has no test",
      "suggested_action": "Create test for workflow WF-001"
    }
  ]
}
```

### get_project_status

```
get_project_status() -> JSON
```

Get project health summary including alignment score, spec coverage, and sprint history.

**Response:**
```json
{
  "success": true,
  "alignment_score": 0.85,
  "alignment_gaps": 3,
  "last_alignment_scan": "2026-03-10T...",
  "spec_count": {"model": 2, "states": 1, "contracts": 1},
  "sprint_history": [
    {"name": "DocDrivenDev", "completed": "...", "alignment_score": 0.9}
  ]
}
```

---

**Last Updated:** 2026-03-10 (Sprint 33 - DocDrivenDev)
