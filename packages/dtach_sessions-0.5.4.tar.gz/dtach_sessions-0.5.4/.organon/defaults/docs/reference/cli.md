# Organon CLI Reference

Complete command reference for the `organon` CLI tool.

## Core Commands

Essential commands for project initialization and MCP setup.

### organon init

```bash
organon init
```

Initialize .organon directory structure in the current directory. Creates configuration files, default templates, skills, and directory structure.

**Options:**
- `--force` - Overwrite existing .organon directory
- `--update` - Add missing files without overwriting existing ones
- `--no-mcp` - Skip MCP server configuration

**Example:**
```bash
cd my-project
organon init
```

**Creates:**
- `.organon/config.yaml` - Project configuration
- `.organon/defaults/` - Reference templates and definitions
- `.organon/rules/` - Custom validation rules
- `.organon/sprints/` - Sprint directory structure
- `.organon/STRUCTURE.md` - Generated directory map
- `.claude/skills/` - Claude Code skills (align, generate-specs, check-docs, etc.)
- `.organon/specs/` - Directory for spec files
- `CLAUDE.md` - Root file referencing `.organon/CLAUDE.md`
- `.mcp.json` - MCP server configuration
- `.gitignore` updates for .organon runtime data

**Next steps after init:**
1. Restart Claude Code (to load MCP server)
2. Run `/align` to scan your project and build the alignment manifest
3. Edit `.organon/config.yaml` to configure your project

---

### organon setup-mcp

```bash
organon setup-mcp [--scope user|project]
```

Register organon MCP server with Claude Code configuration.

**Options:**
- `--scope user` (default) - Available across all projects
- `--scope project` - Available only in current project

**Examples:**
```bash
# Register for all projects (user scope)
organon setup-mcp

# Register for current project only
organon setup-mcp --scope project
```

**See:** `MCP_SETUP.md` for detailed setup and troubleshooting.

---

## Project Management

Commands for creating and managing projects from cookiecutter templates.

### organon projects create

```bash
organon projects create <template> [--output-dir DIR] [--no-input]
```

Create new project from cookiecutter template.

**Arguments:**
- `<template>` - Template name from `organon projects list`

**Options:**
- `--output-dir DIR` - Output directory (default: current directory)
- `--no-input` - Skip interactive prompts, use template defaults

**Examples:**
```bash
# Create project interactively
organon projects create python-package

# Create with defaults in specific directory
organon projects create python-package --output-dir ./my-project --no-input
```

---

### organon projects list

```bash
organon projects list [--verbose]
```

List available cookiecutter project templates.

**Options:**
- `--verbose` - Show template descriptions

**Examples:**
```bash
# List template names
organon projects list

# List with descriptions
organon projects list --verbose
```

---

## Sprint Management

Commands for managing sprint lifecycle.

### organon sprints create

```bash
organon sprints create <name>
```

Create new sprint directory with planning documents.

**Arguments:**
- `<name>` - Sprint name (e.g., "FeatureName")

**Examples:**
```bash
# Create new sprint
organon sprints create AuthenticationRefactor

# Sprint created at: .organon/sprints/AuthenticationRefactor_Created/
```

**Creates:**
- `requirements.md` - Sprint requirements
- `research.md` - Research phase
- `design.md` - Design phase
- `architecture.md` - Architecture phase
- `spec.md` - Technical specification
- `plan.md` - Implementation plan

---

### organon sprints list

```bash
organon sprints list [--status STATUS]
```

List all sprints, optionally filtered by status.

**Options:**
- `--status STATUS` - Filter by status: Created, Next, Current, Completed, Paused

**Examples:**
```bash
# List all sprints
organon sprints list

# List only current sprints
organon sprints list --status Current

# List completed sprints
organon sprints list --status Completed
```

---

### organon sprints update-status

```bash
organon sprints update-status <path> <status>
```

Update sprint status and rename directory accordingly.

**Arguments:**
- `<path>` - Path to sprint directory
- `<status>` - New status: Created, Next, Current, Completed, Paused

**Examples:**
```bash
# Move sprint to Current status
organon sprints update-status .organon/sprints/AuthenticationRefactor_Created Current

# Renames to: .organon/sprints/31_AuthenticationRefactor_Current/
# (Number auto-assigned when status changes to Current)

# Complete sprint
organon sprints update-status .organon/sprints/31_AuthenticationRefactor_Current Completed
```

**Status Workflow:**
- Created → Next → Current → Completed
- Can pause at any stage: any-status → Paused

---

## Logs & Metrics

Commands for log streaming and efficiency metrics tracking.

### organon logs stream

```bash
organon logs stream [--follow] [--session ID]
```

Stream Claude Code conversation logs.

**Options:**
- `--follow, -f` - Follow log output (like `tail -f`)
- `--session ID` - Filter by session ID

**Examples:**
```bash
# Stream all logs
organon logs stream

# Follow log output continuously
organon logs stream --follow

# Stream specific session
organon logs stream --session abc123
```

---

### organon logs metrics show

```bash
organon logs metrics show [--format FORMAT]
```

Display efficiency metrics summary showing token savings from MCP operations.

**Options:**
- `--format FORMAT` - Output format: `table` (default) or `json`

**Examples:**
```bash
# Show metrics as table
organon logs metrics show

# Export as JSON
organon logs metrics show --format json
```

**Metrics Tracked:**
- Token savings per MCP operation
- Operation counts
- Average tokens saved per operation
- Total efficiency gains

---

### organon logs metrics clear

```bash
organon logs metrics clear
```

Clear efficiency metrics log. Prompts for confirmation before clearing.

**Example:**
```bash
organon logs metrics clear
# Prompt: Clear all metrics data? [y/N]
```

---

## Insights

Commands for workflow insights and log analysis.

### organon insights analyze

```bash
organon insights analyze <log_file> [--with-metrics]
```

Analyze conversation logs and generate workflow insights.

**Arguments:**
- `<log_file>` - Path to log file to analyze

**Options:**
- `--with-metrics` - Correlate with efficiency metrics

**Examples:**
```bash
# Analyze conversation log
organon insights analyze .claude/comprehensive-hook-log.jsonl

# Analyze with metrics correlation
organon insights analyze .claude/comprehensive-hook-log.jsonl --with-metrics
```

---

### organon insights timeline

```bash
organon insights timeline --session <id>
```

Show unified timeline for session combining logs and metrics.

**Options:**
- `--session ID` (required) - Session ID to analyze

**Example:**
```bash
organon insights timeline --session abc123
```

---

## Administration

Administrative and maintenance commands for project management.

### organon admin scan

```bash
organon admin scan [path] [--json]
```

Scan directory and build project index for validation and analysis.

**Arguments:**
- `[path]` - Directory to scan (default: current directory)

**Options:**
- `--json` - Output as JSON for scripting

**Examples:**
```bash
# Scan current directory
organon admin scan

# Scan specific directory
organon admin scan /path/to/project

# Get JSON output
organon admin scan . --json
```

**Output Includes:**
- Detected projects
- File and directory counts
- Git repository status
- Project structure summary

---

### organon admin validate

```bash
organon admin validate [path] [--config FILE]
```

Validate project structure against dynamic rule system.

**Arguments:**
- `[path]` - Directory to validate (default: current directory)

**Options:**
- `--config FILE` - Use specific config file (default: `.organon/config.yaml`)

**Examples:**
```bash
# Validate current directory
organon admin validate

# Validate specific directory
organon admin validate /path/to/project

# Use custom config
organon admin validate . --config custom-config.yaml
```

**Validates:**
- Directory structure rules
- File presence rules
- Content pattern rules
- Custom validation rules

---

### organon admin validate-templates

```bash
organon admin validate-templates [path] [--verbose]
```

Validate document content against template frontmatter structures.

**Arguments:**
- `[path]` - Directory to validate (default: `.organon`)

**Options:**
- `--verbose` - Show detailed validation output

**Examples:**
```bash
# Validate templates in .organon directory (default)
organon admin validate-templates

# Validate with detailed output
organon admin validate-templates --verbose

# Validate specific directory
organon admin validate-templates ./path/to/docs --verbose
```

**Validates:**
- Required sections present
- Section ordering correct
- Content patterns match specifications
- Frontmatter validation rules

---

### organon admin update-defaults

```bash
organon admin update-defaults [category] [--dry-run] [--apply]
```

Sync `.organon/defaults/` with latest package files.

**Arguments:**
- `[category]` - Component to update: `rules`, `templates`, `definitions`, `all` (default)

**Options:**
- `--dry-run` - Preview changes without applying (default behavior)
- `--apply` - Apply changes (required to make changes)

**Examples:**
```bash
# Preview all updates (dry-run)
organon admin update-defaults

# Preview specific component
organon admin update-defaults rules

# Apply all updates
organon admin update-defaults --apply

# Apply specific component
organon admin update-defaults templates --apply
```

**How It Works:**
1. Compares project `.organon/defaults/` with package `defaults/`
2. Uses hash-based diff to detect changes
3. Shows unified diff output
4. Applies updates only with `--apply` flag

**Safety:**
- Dry-run by default (shows diff without applying)
- Only updates `.organon/defaults/` directory
- Does not modify custom `.organon/rules/` or project files
- Version controlled, reviewable via git diff

---

### organon admin structure generate

```bash
organon admin structure generate <path> [--output FILE]
```

Generate new STRUCTURE.md file documenting directory structure.

**Arguments:**
- `<path>` - Directory to generate structure for

**Options:**
- `--output FILE` - Output file path (default: `<path>/STRUCTURE.md`)

**Examples:**
```bash
# Generate in current directory
organon admin structure generate .

# Generate for specific directory
organon admin structure generate /path/to/project

# Custom output location
organon admin structure generate . --output docs/structure.md
```

---

### organon admin structure update

```bash
organon admin structure update <path>
```

Update existing STRUCTURE.md, preserving manual sections.

**Arguments:**
- `<path>` - Directory containing STRUCTURE.md

**Examples:**
```bash
# Update STRUCTURE.md in current directory
organon admin structure update .

# Update specific directory
organon admin structure update /path/to/project
```

**Behavior:**
- Regenerates automated sections
- Preserves manual annotations
- Maintains custom formatting in manual sections

---

### organon admin rules list

```bash
organon admin rules list [--verbose]
```

Display all available validation rules.

**Options:**
- `--verbose, -v` - Show detailed rule descriptions and parameters

**Examples:**
```bash
# List rule names
organon admin rules list

# List with descriptions
organon admin rules list --verbose
```

---

### organon admin rules validate

```bash
organon admin rules validate
```

Validate rule definitions (checks functions exist, signatures correct).

**Example:**
```bash
organon admin rules validate
```

**Validates:**
- Rule functions exist
- Function signatures match expectations
- Rule parameters are valid
- Rule configurations are correct

---

### organon admin archive backlog

```bash
organon admin archive backlog
```

Move completed backlog items from `backlog.md` to archive.

**Example:**
```bash
organon admin archive backlog
```

**Behavior:**
- Moves completed items to `.organon/dev-docs/archive/backlog-archive.md`
- Preserves item IDs and metadata
- Updates backlog.md with only pending/active items

---

### organon admin align-scan

```bash
organon admin align-scan [PATH] [--scope sprint|full] [--format text|json]
```

Run alignment scan between specs, tests, and code. Detects 6 gap types and computes an alignment score.

**Options:**
- `--scope sprint|full` - Scan scope (default: full)
- `--format text|json` - Output format (default: text)

**Example:**
```bash
organon admin align-scan .
organon admin align-scan . --scope sprint --format json
```

**Output:** Alignment score, gap summary by type, and detailed gap list with suggested actions.

---

### organon admin merge-preview

```bash
organon admin merge-preview [SPRINT_PATH] [--base-dir DIR] [--format text|json]
```

Preview merge of sprint overlay specs into base specs. Shows additions, modifications, conflicts, and reference errors that would result from the merge.

**Arguments:**
- `[SPRINT_PATH]` - Path to sprint directory (default: auto-detected from `.organon/current-context.json`)

**Options:**
- `--base-dir DIR` - Base specs directory (default: `.organon/specs/`)
- `--format text|json` - Output format (default: text)

**Exit codes:** 0 for clean merge, 1 if conflicts or reference errors exist.

**Examples:**
```bash
# Preview using current sprint context
organon admin merge-preview

# Preview specific sprint
organon admin merge-preview .organon/sprints/34_DocLifecycle_Current

# JSON output
organon admin merge-preview --base-dir .organon/specs/ --format json
```

---

### organon admin merge-apply

```bash
organon admin merge-apply [SPRINT_PATH] [--base-dir DIR] [--dry-run]
```

Apply merge of sprint overlay specs into base specs. Runs preview first, then writes merged YAML to base-dir if no conflicts exist.

**Arguments:**
- `[SPRINT_PATH]` - Path to sprint directory (default: auto-detected from `.organon/current-context.json`)

**Options:**
- `--base-dir DIR` - Base specs directory (default: `.organon/specs/`)
- `--dry-run` - Preview only, do not write files

**Examples:**
```bash
# Apply merge for current sprint
organon admin merge-apply

# Apply merge for specific sprint
organon admin merge-apply .organon/sprints/34_DocLifecycle_Current

# Dry run (preview without writing)
organon admin merge-apply --dry-run
```

---

### organon admin status

```bash
organon admin status [PATH]
```

Print project health summary including alignment score, validation status, spec coverage, and sprint history.

**Example:**
```bash
organon admin status .
```

**Output:** Alignment score, gap count, spec file counts by type, and recent sprint history.

---

## Global Options

All commands support:

- `--help` - Show command help
- `--version` - Show organon version

**Examples:**
```bash
# Show help for any command
organon --help
organon projects --help
organon admin structure --help

# Show version
organon --version
```

---

## Configuration

Commands use configuration from:

1. `--config FILE` flag (if provided)
2. `.organon/config.yaml` in target directory
3. `.organon/config.yaml` in current directory (fallback)

See `.organon/defaults/docs/user-guide/configuration.md` for config file format.

---

## Migration Guide

If you're upgrading from an earlier version, see `docs/migration/cli-reorganization.md` for:
- Complete command mapping (old → new)
- Migration strategies
- Breaking changes explained

---

## Getting Help

### Command-Specific Help

```bash
# See all top-level commands
organon --help

# See commands in a group
organon projects --help
organon logs --help
organon admin --help

# See subgroup commands
organon logs metrics --help
organon admin structure --help
organon admin rules --help

# See specific command help
organon projects create --help
organon logs metrics show --help
```

### Documentation

- **Quick Start:** `README.md`
- **MCP Setup:** `MCP_SETUP.md`
- **User Guides:** `.organon/defaults/docs/user-guide/`
- **Migration Guide:** `docs/migration/cli-reorganization.md`

---

**Last Updated:** 2025-11-12
**Sprint:** 30_CLICommandReorganization_Current
