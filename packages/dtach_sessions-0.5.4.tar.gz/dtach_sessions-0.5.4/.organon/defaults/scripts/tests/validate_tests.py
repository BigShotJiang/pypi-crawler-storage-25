#!/usr/bin/env python3
"""Validate generated test files for common issues.

Checks syntax, banned imports, hardcoded URLs, test function presence,
and duplicate fixtures across files.

Usage:
    python validate_tests.py [tests_dir]

    tests_dir defaults to .organon/tests/

Outputs a structured JSON report to stdout.
Exit code 0 if all valid, 1 if any invalid.
"""

import json
import py_compile
import re
import sys
from pathlib import Path

# Known-safe import prefixes: stdlib + common test libraries
# Uses sys.stdlib_module_names (Python 3.10+) at runtime, with fallback
try:
    _STDLIB = sys.stdlib_module_names
except AttributeError:
    # Python < 3.10 fallback — cover the common ones
    _STDLIB = {
        "abc", "asyncio", "base64", "bisect", "calendar", "collections",
        "contextlib", "copy", "csv", "dataclasses", "datetime", "decimal",
        "difflib", "enum", "functools", "glob", "hashlib", "heapq", "hmac",
        "html", "http", "inspect", "io", "itertools", "json", "logging",
        "math", "operator", "os", "pathlib", "pickle", "platform", "pprint",
        "random", "re", "secrets", "shutil", "signal", "socket", "sqlite3",
        "ssl", "statistics", "string", "struct", "subprocess", "sys",
        "tempfile", "textwrap", "threading", "time", "traceback", "typing",
        "unittest", "urllib", "uuid", "warnings", "xml", "zipfile",
    }

SAFE_PREFIXES = _STDLIB | {
    "pytest", "httpx", "requests", "conftest", "_pytest", "__future__",
}

# Hardcoded localhost URLs
HARDCODED_URL_PATTERN = re.compile(
    r"""(?:"|')https?://(?:localhost|127\.0\.0\.1)(?::\d+)?[^"']*(?:"|')"""
)

# Fixture definition
FIXTURE_DEF_PATTERN = re.compile(r"@pytest\.fixture.*\ndef\s+(\w+)\s*\(")

# Test function definition — module-level or inside a class
TEST_FUNC_PATTERN = re.compile(r"^\s*(?:async\s+)?def\s+test_\w+\s*\(", re.MULTILINE)


def validate_syntax(filepath: Path) -> list[str]:
    """Check that the file compiles without syntax errors."""
    issues = []
    try:
        py_compile.compile(str(filepath), doraise=True)
    except py_compile.PyCompileError as e:
        issues.append(f"Syntax error: {e}")
    return issues


def validate_no_app_imports(filepath: Path, content: str) -> list[str]:
    """Check that no application code is imported (tests must be HTTP-only)."""
    issues = []
    for lineno, line in enumerate(content.splitlines(), 1):
        stripped = line.strip()
        if stripped.startswith("#"):
            continue

        # Extract the top-level module name from import statements
        m = re.match(r"^from\s+([\w]+)", stripped)
        if not m:
            m = re.match(r"^import\s+([\w]+)", stripped)
        if not m:
            continue

        module = m.group(1)
        if module not in SAFE_PREFIXES:
            issues.append(
                f"Line {lineno}: possible application import: {stripped!r}. "
                f"Tests must be HTTP-only — no application code imports."
            )
    return issues


def validate_no_hardcoded_urls(filepath: Path, content: str) -> list[str]:
    """Check for hardcoded localhost URLs (should use fixtures/env vars)."""
    issues = []
    # Pattern for env var default usage: os.environ.get("...", "http://...")
    env_default_pattern = re.compile(r"os\.environ\.get\(")
    for lineno, line in enumerate(content.splitlines(), 1):
        stripped = line.strip()
        # Skip comments and docstrings
        if stripped.startswith("#"):
            continue
        matches = HARDCODED_URL_PATTERN.findall(line)
        for match in matches:
            # Allow in comments and SPEC GAP annotations
            if "# " in line and line.index("# ") < line.index(match):
                continue
            # Allow as default value in os.environ.get() calls
            if env_default_pattern.search(line):
                continue
            issues.append(
                f"Line {lineno}: hardcoded URL {match}. "
                f"Use base_url fixture or os.environ['TEST_BASE_URL']."
            )
    return issues


def validate_has_tests(filepath: Path, content: str) -> list[str]:
    """Check that the file contains at least one test function."""
    issues = []
    # conftest.py files don't need test functions
    if filepath.name == "conftest.py":
        return issues
    if not TEST_FUNC_PATTERN.search(content):
        issues.append(
            "No test functions found (expected def test_* or async def test_*)."
        )
    return issues


def collect_fixtures(filepath: Path, content: str) -> dict[str, str]:
    """Collect fixture definitions from a file. Returns {name: filepath}."""
    fixtures = {}
    for match in FIXTURE_DEF_PATTERN.finditer(content):
        fixtures[match.group(1)] = str(filepath)
    return fixtures


def validate_no_duplicate_fixtures(
    all_fixtures: dict[str, list[str]],
) -> list[str]:
    """Check for fixture definitions that appear in multiple files.

    Shared fixtures should only be defined in conftest.py.
    """
    issues = []
    for name, files in all_fixtures.items():
        if len(files) > 1:
            locations = ", ".join(files)
            issues.append(
                f"Fixture '{name}' defined in {len(files)} files: {locations}. "
                f"Shared fixtures belong in conftest.py only."
            )
    return issues


def validate_file(filepath: Path) -> dict:
    """Validate a single test file.

    Returns {"file": str, "status": "valid"|"invalid", "issues": [str]}.
    """
    result = {"file": str(filepath), "status": "valid", "issues": []}

    try:
        content = filepath.read_text()
    except OSError as e:
        result["status"] = "invalid"
        result["issues"].append(f"Could not read file: {e}")
        return result

    # Syntax check
    result["issues"].extend(validate_syntax(filepath))

    # App import check
    result["issues"].extend(validate_no_app_imports(filepath, content))

    # Hardcoded URL check
    result["issues"].extend(validate_no_hardcoded_urls(filepath, content))

    # Test function presence check
    result["issues"].extend(validate_has_tests(filepath, content))

    if result["issues"]:
        result["status"] = "invalid"

    return result


def main() -> int:
    tests_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".organon/tests")
    tests_dir = tests_dir.resolve()

    if not tests_dir.is_dir():
        print(f"Error: {tests_dir} is not a directory", file=sys.stderr)
        return 1

    results = []
    has_invalid = False
    all_fixtures: dict[str, list[str]] = {}

    # Validate each Python file
    for py_file in sorted(tests_dir.glob("*.py")):
        result = validate_file(py_file)
        results.append(result)
        if result["status"] == "invalid":
            has_invalid = True

        # Collect fixtures for cross-file duplicate check
        try:
            content = py_file.read_text()
            for name, location in collect_fixtures(py_file, content).items():
                all_fixtures.setdefault(name, []).append(location)
        except OSError:
            pass

    # Cross-file duplicate fixture check
    dup_issues = validate_no_duplicate_fixtures(all_fixtures)
    if dup_issues:
        results.append({
            "file": "(cross-file fixtures)",
            "status": "invalid",
            "issues": dup_issues,
        })
        has_invalid = True

    # Output report
    if not results:
        print(json.dumps({
            "summary": "No test files found",
            "tests_dir": str(tests_dir),
            "results": [],
        }, indent=2))
        return 0

    valid_count = sum(1 for r in results if r["status"] == "valid")
    invalid_count = sum(1 for r in results if r["status"] == "invalid")

    report = {
        "summary": f"{valid_count} valid, {invalid_count} invalid",
        "tests_dir": str(tests_dir),
        "results": results,
    }

    print(json.dumps(report, indent=2))
    return 1 if has_invalid else 0


if __name__ == "__main__":
    sys.exit(main())
