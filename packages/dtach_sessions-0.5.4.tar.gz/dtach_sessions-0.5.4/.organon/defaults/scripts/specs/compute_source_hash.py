#!/usr/bin/env python3
"""Compute a source hash from a list of files.

Concatenates file contents in the order given, computes SHA-256,
and returns the first 16 hex characters. This is the canonical
hash used in derived spec `source_hash` fields and verified by
/validate-specs.

Usage:
    python compute_source_hash.py file1 file2 ...

Outputs the 16-character hex hash to stdout.
"""

import hashlib
import sys
from pathlib import Path


def compute_hash(files: list[Path]) -> str:
    """Concatenate file contents in order, return first 16 hex chars of SHA-256."""
    h = hashlib.sha256()
    for f in files:
        h.update(f.read_bytes())
    return h.hexdigest()[:16]


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: compute_source_hash.py file1 file2 ...", file=sys.stderr)
        return 1

    files = []
    for arg in sys.argv[1:]:
        p = Path(arg)
        if not p.is_file():
            print(f"Error: {arg} is not a file", file=sys.stderr)
            return 1
        files.append(p)

    print(compute_hash(files))
    return 0


if __name__ == "__main__":
    sys.exit(main())
