#!/usr/bin/env python3
"""Validate spec files against their schemas.

Checks YAML specs for required fields and correct types, markdown specs for
required frontmatter and sections, and cross-references between specs.

Usage:
    python validate_specs.py [specs_dir]

    specs_dir defaults to .organon/specs/

Outputs a structured report to stdout.
Exit code 0 if all valid, 1 if any invalid.
"""

import json
import re
import sys
from pathlib import Path

import yaml

# --- Schema definitions (source of truth) ---

YAML_SCHEMAS = {
    "model": {
        "required_frontmatter": {
            "type": {"value": "model"},
            "entity": {"type": str},
        },
        "required_sections": {
            "fields": {
                "type": list,
                "item_required": ["name", "type"],
            },
        },
    },
    "workflow": {
        "required_frontmatter": {
            "type": {"value": "workflow"},
            "entity": {"type": str},
            "field": {"type": str},
        },
        # Workflows have two valid shapes:
        #   State-machine/lifecycle: states + transitions
        #   Query: operations
        # Validated in validate_yaml_spec with custom logic, not here.
        "required_sections": {},
    },
    "invariants": {
        "required_frontmatter": {
            "type": {"value": "invariants"},
            "scope": {"type": str},
        },
        "required_sections": {
            "invariants": {
                "type": list,
                "item_required": ["id", "rule", "enforced_by"],
            },
        },
    },
    "services": {
        "required_frontmatter": {
            "type": {"value": "services"},
        },
        "required_sections": {
            "services": {
                "type": list,
                "item_required": ["name", "start", "health"],
            },
        },
    },
}

MD_SCHEMAS = {
    "decisions": {
        "required_frontmatter": ["type", "project", "lifecycle_phase", "last_updated"],
        "frontmatter_values": {"type": "decisions"},
        "required_sections": [
            "Tech Stack",
            "Architecture",
            "Libraries & Dependencies",
            "Patterns & Conventions",
            "Lifecycle Phase",
        ],
    },
    "quality": {
        "required_frontmatter": ["type", "project", "last_updated"],
        "frontmatter_values": {"type": "quality"},
        "required_sections": [
            "Performance",
            "Scalability",
            "Availability",
            "Security",
            "Observability",
        ],
    },
}


def parse_yaml_with_frontmatter(content: str) -> tuple[dict, dict]:
    """Parse a YAML file that has --- frontmatter --- followed by body content.

    Returns (frontmatter_dict, body_dict).
    """
    # Split on --- delimiters
    parts = content.split("---")
    if len(parts) < 3:
        # Try parsing as plain YAML
        data = yaml.safe_load(content) or {}
        # If the whole file is one YAML doc, frontmatter fields are top-level
        # keys that match schema frontmatter, body is everything else
        return data, data

    frontmatter = yaml.safe_load(parts[1]) or {}
    body_text = "---".join(parts[2:])
    body = yaml.safe_load(body_text) or {}

    return frontmatter, body


def parse_md_frontmatter(content: str) -> tuple[dict, str]:
    """Parse markdown frontmatter and body.

    Returns (frontmatter_dict, body_text).
    """
    if not content.startswith("---"):
        return {}, content

    parts = content.split("---", 2)
    if len(parts) < 3:
        return {}, content

    frontmatter = yaml.safe_load(parts[1]) or {}
    body = parts[2]
    return frontmatter, body


def validate_yaml_spec(filepath: Path, content: str) -> dict:
    """Validate a YAML spec file against its schema.

    Returns {"file": str, "status": "valid"|"invalid", "issues": [str]}.
    """
    result = {"file": str(filepath), "status": "valid", "issues": []}

    try:
        frontmatter, body = parse_yaml_with_frontmatter(content)
    except yaml.YAMLError as e:
        result["status"] = "invalid"
        result["issues"].append(f"YAML parse error: {e}")
        return result

    # Determine spec type
    spec_type = frontmatter.get("type")
    if not spec_type:
        result["status"] = "invalid"
        result["issues"].append("Missing 'type' in frontmatter")
        return result

    schema = YAML_SCHEMAS.get(spec_type)
    if not schema:
        result["status"] = "invalid"
        result["issues"].append(f"Unknown spec type: {spec_type}")
        return result

    # Validate frontmatter
    for field, rules in schema["required_frontmatter"].items():
        if field not in frontmatter:
            result["issues"].append(f"Missing required frontmatter field: {field}")
            continue
        value = frontmatter[field]
        if "value" in rules and value != rules["value"]:
            result["issues"].append(
                f"Field '{field}' must be '{rules['value']}', got '{value}'"
            )
        if "type" in rules and not isinstance(value, rules["type"]):
            result["issues"].append(
                f"Field '{field}' must be {rules['type'].__name__}, "
                f"got {type(value).__name__}"
            )

    # Validate body sections
    for section_name, section_rules in schema["required_sections"].items():
        if section_name not in body:
            result["issues"].append(f"Missing required section: {section_name}")
            continue

        section_data = body[section_name]

        if section_rules["type"] is list:
            if not isinstance(section_data, list):
                result["issues"].append(
                    f"Section '{section_name}' must be a list, "
                    f"got {type(section_data).__name__}"
                )
                continue

            if not section_data:
                result["issues"].append(f"Section '{section_name}' is empty")
                continue

            # Validate each item has required fields
            for i, item in enumerate(section_data):
                if not isinstance(item, dict):
                    result["issues"].append(
                        f"{section_name}[{i}]: expected a mapping, "
                        f"got {type(item).__name__}"
                    )
                    continue
                for req_field in section_rules["item_required"]:
                    if req_field not in item:
                        result["issues"].append(
                            f"{section_name}[{i}]: missing required field '{req_field}'"
                        )

    # Workflow-specific validation: must have one of three shapes:
    #   1. steps (unified format — preferred)
    #   2. states + transitions (legacy state-machine format)
    #   3. operations (legacy query format)
    if spec_type == "workflow":
        has_steps = "steps" in body and isinstance(body.get("steps"), list)
        has_states = "states" in body and isinstance(body.get("states"), list)
        has_transitions = "transitions" in body and isinstance(body.get("transitions"), list)
        has_operations = "operations" in body and isinstance(body.get("operations"), list)

        if has_steps:
            # Unified format — validate steps
            if not body["steps"]:
                result["issues"].append("Section 'steps' is empty")
            else:
                for i, item in enumerate(body["steps"]):
                    if not isinstance(item, dict):
                        result["issues"].append(
                            f"steps[{i}]: expected a mapping, got {type(item).__name__}"
                        )
                        continue
                    if "name" not in item:
                        result["issues"].append(
                            f"steps[{i}]: missing required field 'name'"
                        )
                    # state_change, if present, needs from and to
                    sc = item.get("state_change")
                    if sc is not None and isinstance(sc, dict):
                        for f in ("from", "to"):
                            if f not in sc:
                                result["issues"].append(
                                    f"steps[{i}].state_change: missing required field '{f}'"
                                )
        elif has_states or has_transitions:
            # Legacy state-machine/lifecycle workflow — require both
            if not has_states:
                result["issues"].append("Missing required section: states")
            elif not body["states"]:
                result["issues"].append("Section 'states' is empty")
            else:
                for i, item in enumerate(body["states"]):
                    if isinstance(item, dict) and "name" not in item:
                        result["issues"].append(f"states[{i}]: missing required field 'name'")
            if not has_transitions:
                result["issues"].append("Missing required section: transitions")
            elif not body["transitions"]:
                result["issues"].append("Section 'transitions' is empty")
            else:
                for i, item in enumerate(body["transitions"]):
                    if isinstance(item, dict):
                        for f in ("from", "to", "trigger"):
                            if f not in item:
                                result["issues"].append(
                                    f"transitions[{i}]: missing required field '{f}'"
                                )
        elif has_operations:
            # Legacy query workflow — validate operations
            if not body["operations"]:
                result["issues"].append("Section 'operations' is empty")
            else:
                for i, item in enumerate(body["operations"]):
                    if isinstance(item, dict):
                        for f in ("name", "api"):
                            if f not in item:
                                result["issues"].append(
                                    f"operations[{i}]: missing required field '{f}'"
                                )
                    else:
                        result["issues"].append(
                            f"operations[{i}]: expected a mapping, got {type(item).__name__}"
                        )
        else:
            result["issues"].append(
                "Workflow must have steps, (states + transitions), or operations"
            )

    if result["issues"]:
        result["status"] = "invalid"

    return result


def validate_md_spec(filepath: Path, content: str) -> dict:
    """Validate a markdown spec file against its schema.

    Returns {"file": str, "status": "valid"|"invalid", "issues": [str]}.
    """
    result = {"file": str(filepath), "status": "valid", "issues": []}

    frontmatter, body = parse_md_frontmatter(content)

    # Determine spec type from frontmatter or filename
    spec_type = frontmatter.get("type")
    if not spec_type:
        # Try to infer from filename
        name = filepath.stem.lower()
        if "decision" in name:
            spec_type = "decisions"
        elif "quality" in name:
            spec_type = "quality"
        else:
            result["status"] = "invalid"
            result["issues"].append(
                "Missing 'type' in frontmatter and could not infer from filename"
            )
            return result

    schema = MD_SCHEMAS.get(spec_type)
    if not schema:
        # Not a markdown spec type we validate
        return result

    # Validate frontmatter fields
    for field in schema["required_frontmatter"]:
        if field not in frontmatter:
            result["issues"].append(f"Missing required frontmatter field: {field}")

    # Validate frontmatter values
    for field, expected in schema.get("frontmatter_values", {}).items():
        if field in frontmatter and frontmatter[field] != expected:
            result["issues"].append(
                f"Field '{field}' must be '{expected}', got '{frontmatter[field]}'"
            )

    # Validate required sections (markdown headings)
    for section in schema["required_sections"]:
        # Look for ## Section Name (level 2 heading)
        pattern = rf"^##\s+{re.escape(section)}\s*$"
        if not re.search(pattern, body, re.MULTILINE):
            result["issues"].append(f"Missing required section: ## {section}")

    if result["issues"]:
        result["status"] = "invalid"

    return result


def check_cross_references(results: list[dict], specs_dir: Path) -> list[str]:
    """Check cross-references between spec files.

    Currently checks:
    - Workflow entity references match a model entity
    - Invariant scope is a valid value
    """
    issues = []

    # Collect model entities
    model_entities = set()
    workflow_entities = set()

    for yaml_file in specs_dir.glob("*.yaml"):
        try:
            content = yaml_file.read_text()
            frontmatter, _ = parse_yaml_with_frontmatter(content)
            spec_type = frontmatter.get("type")
            entity = frontmatter.get("entity")

            if spec_type == "model" and entity:
                model_entities.add(entity)
            elif spec_type == "workflow" and entity:
                workflow_entities.add(entity)
        except (yaml.YAMLError, OSError):
            continue

    # Check workflow entities have corresponding models
    for entity in workflow_entities:
        if entity not in model_entities:
            issues.append(
                f"Cross-reference: workflow entity '{entity}' has no matching model spec"
            )

    return issues


def main() -> int:
    specs_dir = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".organon/specs")
    specs_dir = specs_dir.resolve()

    if not specs_dir.is_dir():
        print(f"Error: {specs_dir} is not a directory", file=sys.stderr)
        return 1

    results = []
    has_invalid = False

    # Validate YAML specs
    for yaml_file in sorted(specs_dir.glob("*.yaml")):
        try:
            content = yaml_file.read_text()
        except OSError as e:
            results.append({
                "file": str(yaml_file),
                "status": "invalid",
                "issues": [f"Could not read file: {e}"],
            })
            has_invalid = True
            continue

        result = validate_yaml_spec(yaml_file, content)
        results.append(result)
        if result["status"] == "invalid":
            has_invalid = True

    # Validate markdown specs
    for md_file in sorted(specs_dir.glob("*.md")):
        try:
            content = md_file.read_text()
        except OSError as e:
            results.append({
                "file": str(md_file),
                "status": "invalid",
                "issues": [f"Could not read file: {e}"],
            })
            has_invalid = True
            continue

        result = validate_md_spec(md_file, content)
        results.append(result)
        if result["status"] == "invalid":
            has_invalid = True

    # Cross-reference checks
    xref_issues = check_cross_references(results, specs_dir)
    if xref_issues:
        results.append({
            "file": "(cross-references)",
            "status": "invalid",
            "issues": xref_issues,
        })
        has_invalid = True

    # Output report
    if not results:
        print(json.dumps({
            "summary": "No spec files found",
            "specs_dir": str(specs_dir),
            "results": [],
        }, indent=2))
        return 0

    valid_count = sum(1 for r in results if r["status"] == "valid")
    invalid_count = sum(1 for r in results if r["status"] == "invalid")

    report = {
        "summary": f"{valid_count} valid, {invalid_count} invalid",
        "specs_dir": str(specs_dir),
        "results": results,
    }

    print(json.dumps(report, indent=2))
    return 1 if has_invalid else 0


if __name__ == "__main__":
    sys.exit(main())
