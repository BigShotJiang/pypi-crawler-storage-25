#!/usr/bin/env python3
"""Extract OpenAPI spec from a project's web framework.

Detects the framework from dependency files (pyproject.toml, package.json, etc.),
attempts programmatic extraction by importing the app, and falls back to fetching
from a running server.

Usage:
    python extract_openapi.py <project_dir>

Outputs OpenAPI JSON to stdout on success.
Exits with code 1 and an error message on failure.
"""

import json
import os
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path


def detect_framework(project_dir: Path) -> dict:
    """Detect the web framework and language from dependency files.

    Returns a dict with keys: framework, language, app_module (if detectable).
    """
    result = {"framework": None, "language": None, "app_module": None}

    # Python: check pyproject.toml, requirements.txt in root and common subdirs
    python_deps = ""
    search_dirs = [project_dir] + [
        d for d in project_dir.iterdir()
        if d.is_dir() and d.name in ("backend", "server", "api", "app", "src")
    ]
    for search_dir in search_dirs:
        pyproject = search_dir / "pyproject.toml"
        requirements = search_dir / "requirements.txt"
        if pyproject.exists():
            python_deps += "\n" + pyproject.read_text()
        if requirements.exists():
            python_deps += "\n" + requirements.read_text()

    if python_deps:
        result["language"] = "python"
        deps_lower = python_deps.lower()
        if "fastapi" in deps_lower:
            result["framework"] = "fastapi"
            result["app_module"] = _find_fastapi_app(project_dir)
        elif "django" in deps_lower and "rest_framework" in deps_lower:
            result["framework"] = "django-rest"
        elif "django" in deps_lower:
            result["framework"] = "django"
        elif "flask" in deps_lower and "apispec" in deps_lower:
            result["framework"] = "flask-apispec"
        elif "flask" in deps_lower:
            result["framework"] = "flask"
        if result["framework"]:
            return result

    # JavaScript/TypeScript: check package.json
    package_json = project_dir / "package.json"
    if package_json.exists():
        try:
            pkg = json.loads(package_json.read_text())
            all_deps = {}
            all_deps.update(pkg.get("dependencies", {}))
            all_deps.update(pkg.get("devDependencies", {}))
            result["language"] = "javascript"

            if "swagger-jsdoc" in all_deps:
                result["framework"] = "express-swagger"
            elif "express" in all_deps:
                result["framework"] = "express"
            elif "fastify" in all_deps:
                result["framework"] = "fastify"
            elif "@nestjs/core" in all_deps:
                result["framework"] = "nestjs"

            if result["framework"]:
                return result
        except (json.JSONDecodeError, OSError):
            pass

    # Rust: check Cargo.toml
    cargo_toml = project_dir / "Cargo.toml"
    if cargo_toml.exists():
        cargo_text = cargo_toml.read_text().lower()
        result["language"] = "rust"
        if "actix-web" in cargo_text:
            result["framework"] = "actix"
        elif "axum" in cargo_text:
            result["framework"] = "axum"
        elif "rocket" in cargo_text:
            result["framework"] = "rocket"
        if result["framework"]:
            return result

    # Go: check go.mod
    go_mod = project_dir / "go.mod"
    if go_mod.exists():
        go_text = go_mod.read_text().lower()
        result["language"] = "go"
        if "gin-gonic" in go_text:
            result["framework"] = "gin"
        elif "gorilla/mux" in go_text:
            result["framework"] = "gorilla"
        elif "echo" in go_text:
            result["framework"] = "echo"
        if result["framework"]:
            return result

    return result


def _find_fastapi_app(project_dir: Path) -> str | None:
    """Search for the FastAPI app instance in common locations.

    Searches both root and common subdirectories (backend/, server/, api/).
    """
    # Search root and common backend subdirectories
    search_roots = [project_dir] + [
        d for d in project_dir.iterdir()
        if d.is_dir() and d.name in ("backend", "server", "api", "app")
    ]

    for root in search_roots:
        candidates = [
            "main.py",
            "app/main.py",
            "src/main.py",
            "app.py",
        ]

        # Check pyproject.toml in this root for package name
        pyproject = root / "pyproject.toml"
        if pyproject.exists():
            content = pyproject.read_text()
            for line in content.splitlines():
                stripped = line.strip()
                if stripped.startswith("name") and "=" in stripped:
                    pkg_name = stripped.split("=", 1)[1].strip().strip('"').strip("'")
                    pkg_name = pkg_name.replace("-", "_")
                    candidates.insert(0, f"src/{pkg_name}/main.py")
                    candidates.insert(1, f"{pkg_name}/main.py")

        for candidate in candidates:
            filepath = root / candidate
            if filepath.exists():
                try:
                    text = filepath.read_text()
                    if "FastAPI" in text:
                        # Convert file path to module path
                        module = candidate.replace("/", ".").removesuffix(".py")
                        return module
                except OSError:
                    continue

    return None


def extract_fastapi(project_dir: Path, app_module: str | None) -> str | None:
    """Extract OpenAPI from a FastAPI app by importing it."""
    if not app_module:
        return None

    # Try common app variable names
    for var in ("app", "application"):
        script = (
            f"import sys; sys.path.insert(0, '{project_dir}'); "
            f"sys.path.insert(0, '{project_dir / 'src'}'); "
            f"from {app_module} import {var}; "
            f"import json; print(json.dumps({var}.openapi(), indent=2))"
        )
        try:
            result = subprocess.run(
                [sys.executable, "-c", script],
                capture_output=True,
                text=True,
                timeout=30,
                cwd=str(project_dir),
            )
            if result.returncode == 0 and result.stdout.strip():
                # Validate it's actual JSON
                json.loads(result.stdout)
                return result.stdout.strip()
        except (subprocess.TimeoutExpired, json.JSONDecodeError):
            continue

    return None


def extract_django_rest(project_dir: Path) -> str | None:
    """Extract OpenAPI from Django REST Framework."""
    # Find Django settings module
    manage_py = project_dir / "manage.py"
    if not manage_py.exists():
        return None

    text = manage_py.read_text()
    settings_module = None
    for line in text.splitlines():
        if "DJANGO_SETTINGS_MODULE" in line and "=" in line:
            # Extract the settings module from the line
            parts = line.split("=")
            if len(parts) >= 2:
                settings_module = parts[-1].strip().strip("'\"").rstrip(")")
                break

    if not settings_module:
        return None

    script = (
        f"import os; os.environ.setdefault('DJANGO_SETTINGS_MODULE', '{settings_module}'); "
        f"import sys; sys.path.insert(0, '{project_dir}'); "
        f"import django; django.setup(); "
        f"from rest_framework.schemas.openapi import SchemaGenerator; "
        f"import json; "
        f"generator = SchemaGenerator(title='API'); "
        f"schema = generator.get_schema(); "
        f"print(json.dumps(schema, indent=2, default=str))"
    )
    try:
        result = subprocess.run(
            [sys.executable, "-c", script],
            capture_output=True,
            text=True,
            timeout=30,
            cwd=str(project_dir),
        )
        if result.returncode == 0 and result.stdout.strip():
            json.loads(result.stdout)
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, json.JSONDecodeError):
        pass

    return None


def extract_express_swagger(project_dir: Path) -> str | None:
    """Extract OpenAPI from Express + swagger-jsdoc."""
    # Look for swagger config file
    candidates = ["swagger.js", "swagger.ts", "src/swagger.js", "src/swagger.ts",
                   "config/swagger.js", "config/swagger.ts"]

    swagger_file = None
    for candidate in candidates:
        path = project_dir / candidate
        if path.exists():
            swagger_file = candidate
            break

    if not swagger_file:
        return None

    module_path = swagger_file.removesuffix(".js").removesuffix(".ts")
    script = f"const spec = require('./{module_path}'); console.log(JSON.stringify(spec, null, 2))"

    try:
        result = subprocess.run(
            ["node", "-e", script],
            capture_output=True,
            text=True,
            timeout=30,
            cwd=str(project_dir),
        )
        if result.returncode == 0 and result.stdout.strip():
            json.loads(result.stdout)
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, json.JSONDecodeError, FileNotFoundError):
        pass

    return None


def fetch_from_server(framework: str | None) -> str | None:
    """Try to fetch OpenAPI spec from a running server."""
    # Common OpenAPI endpoints by framework
    endpoints = [
        "http://localhost:8000/openapi.json",   # FastAPI default
        "http://localhost:8000/api/schema/",     # Django REST
        "http://localhost:3000/api-docs/swagger.json",  # Express swagger-ui
        "http://localhost:3000/swagger.json",    # Express alt
        "http://localhost:5000/openapi.json",    # Flask
        "http://localhost:8080/openapi.json",    # Generic
    ]

    # Prioritize based on framework
    if framework == "fastapi":
        endpoints.insert(0, "http://localhost:8000/openapi.json")
    elif framework == "django-rest":
        endpoints.insert(0, "http://localhost:8000/api/schema/")
    elif framework in ("express", "express-swagger"):
        endpoints.insert(0, "http://localhost:3000/api-docs/swagger.json")

    for url in endpoints:
        try:
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with urllib.request.urlopen(req, timeout=5) as resp:
                data = resp.read().decode("utf-8")
                # Validate it's JSON
                json.loads(data)
                return data
        except (urllib.error.URLError, OSError, json.JSONDecodeError, ValueError):
            continue

    return None


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: extract_openapi.py <project_dir>", file=sys.stderr)
        return 1

    project_dir = Path(sys.argv[1]).resolve()
    if not project_dir.is_dir():
        print(f"Error: {project_dir} is not a directory", file=sys.stderr)
        return 1

    # Step 1: Detect framework
    info = detect_framework(project_dir)

    if not info["framework"]:
        print(
            f"Error: Could not detect a supported web framework in {project_dir}. "
            f"Looked for dependency files (pyproject.toml, package.json, Cargo.toml, go.mod) "
            f"containing FastAPI, Django REST, Flask, Express, or similar frameworks.",
            file=sys.stderr,
        )
        return 1

    print(f"Detected framework: {info['framework']} ({info['language']})", file=sys.stderr)

    # Step 2: Try programmatic extraction
    spec = None

    if info["framework"] == "fastapi":
        spec = extract_fastapi(project_dir, info.get("app_module"))
    elif info["framework"] == "django-rest":
        spec = extract_django_rest(project_dir)
    elif info["framework"] == "express-swagger":
        spec = extract_express_swagger(project_dir)

    if spec:
        print(spec)
        return 0

    print(
        f"Programmatic extraction failed for {info['framework']}. "
        f"Trying to fetch from running server...",
        file=sys.stderr,
    )

    # Step 3: Try fetching from running server
    spec = fetch_from_server(info["framework"])
    if spec:
        print(spec)
        return 0

    # Step 4: Fail explicitly
    print(
        f"Error: Could not extract OpenAPI spec from {info['framework']} project.\n"
        f"  - Programmatic extraction failed (app may have import errors or missing deps)\n"
        f"  - No running server responded with an OpenAPI spec\n"
        f"\n"
        f"To resolve:\n"
        f"  1. Fix any import errors and re-run this script, or\n"
        f"  2. Start the app and re-run this script, or\n"
        f"  3. For frameworks without auto-generation, the agent must extract the contract manually",
        file=sys.stderr,
    )
    return 1


if __name__ == "__main__":
    sys.exit(main())
