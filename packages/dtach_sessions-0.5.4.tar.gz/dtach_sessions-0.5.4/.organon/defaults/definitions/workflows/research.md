# Research Workflow

## When to Use This Workflow

Use research when you need to:
- Investigate existing system implementation
- Analyze existing code and patterns
- Understand technical landscape
- Identify constraints and conventions
- Explore technical options
- Review prior art or existing solutions

Research follows Requirements and backs decisions across all phases.

## Dependencies

**Required prior phases:** Requirements

**Information consumed:**
- From Requirements: Features to investigate, scope boundaries

**Information produced:**
- For Architecture: Existing patterns, technical constraints, similar implementations
- For Specification: API conventions, data format standards
- For all phases: Technical backing information for decisions

**Key principle:** Research provides backing information; decisions happen in domain-specific phases.

## Inputs

- Problem statement or feature request
- Access to codebase
- Documentation (if available)
- Stakeholder requirements (if applicable)

## Process

### 1. Define Research Questions

Start by articulating what you need to understand:
- What problem are we solving?
- What constraints exist?
- What patterns are already in use?
- What dependencies or systems are involved?
- What are the edge cases?

Document these questions in the Research section.

### 2. Explore Codebase

Use appropriate tools to investigate:

```bash
# Find relevant files
glob "**/*auth*"  # Example: finding authentication-related code

# Search for patterns
grep "class.*Service"  # Example: finding service classes

# Read key files
# Use Read tool on files you discovered

# Check git history
git log --oneline --grep="feature-name"
git blame path/to/file.py
```

### 3. Analyze Findings

- Identify existing patterns and conventions
- Note architectural decisions
- Document dependencies and relationships
- Capture examples of similar work
- List potential approaches

### 4. Document Discoveries

Write findings in research.md (or Research section):
- What you learned
- Existing patterns to follow
- Constraints discovered
- Relevant code examples
- Related work or prior art
- Open questions for design phase

### 5. Identify Gaps

Note what you still don't know:
- What requires design decisions
- What needs technical specification
- What assumptions need validation
- What risks or unknowns exist

## Outputs

- **Research document** (research.md or Research section) containing:
  - Problem analysis
  - Existing code review
  - Patterns and conventions
  - Constraints and requirements
  - Related work
  - Open questions for design

## Common Pitfalls

- **Analysis paralysis** - Don't try to understand everything; focus on what's needed
- **Skipping documentation** - Capture findings as you go; don't rely on memory
- **Missing constraints** - Check for non-functional requirements (performance, security, etc.)
- **Ignoring prior art** - Look for similar features or patterns already in the codebase
- **Lack of examples** - Concrete code examples are more valuable than abstract descriptions

## Validation

Research is complete when you can answer:

- ✓ What problem are we solving?
- ✓ What are the key constraints?
- ✓ What patterns should we follow?
- ✓ What are the main technical considerations?
- ✓ What questions need design decisions?

You should feel ready to move to the Design workflow with solid understanding of the problem space.

## Integration with Work Modes

**In Sprint-Execution Work Mode:**
- Create `docs/sprints/NN_Name_Status/research.md`
- Document all findings there

**In One-Off-Task Work Mode:**
- Usually skip formal research
- Quick investigation (< 5 minutes) if needed

## Tips

- Use TODO comments to mark areas needing investigation
- Take screenshots of relevant UI or diagrams if helpful
- Link to external resources (docs, issues, design docs)
- Use code examples from codebase to illustrate patterns
- Note your search queries so others can reproduce your research
