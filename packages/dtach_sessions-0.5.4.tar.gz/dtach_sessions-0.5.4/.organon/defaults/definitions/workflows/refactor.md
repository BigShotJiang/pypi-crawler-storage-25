# Refactor Workflow

## When to Use This Workflow

Use refactor when you need to:
- Improve code structure without changing behavior
- Reduce code duplication
- Simplify complex code
- Improve performance
- Update to use new patterns
- Improve maintainability

Refactor can happen during implementation or as dedicated work.

## Inputs

- Existing code to improve
- Understanding of current behavior
- Project standards (from CLAUDE.md)
- Tests (if they exist)

## Process

### 1. Understand Current Behavior

Before changing anything:

```python
# Read the code
def complex_function(data, mode, options=None):
    # ... 100 lines of complex logic ...
```

**Questions to answer:**
- What does this code do?
- What are the inputs and outputs?
- What edge cases does it handle?
- What are the dependencies?

### 2. Write Tests (Golden Master)

**If no tests exist, create Golden Master tests first:**

```python
def test_complex_function_golden_master(snapshot):
    """Golden master test for complex_function behavior."""

    # Test various inputs
    test_cases = [
        ({"key": "value"}, "mode1", None),
        ({"key": "value"}, "mode2", {"opt": True}),
        ({"nested": {"data": "test"}}, "mode1", None),
    ]

    results = []
    for data, mode, options in test_cases:
        result = complex_function(data, mode, options)
        results.append(result)

    # First run creates snapshot, subsequent runs compare
    snapshot.assert_match(results, "complex_function_outputs.json")
```

**Why Golden Master:**
- Captures current behavior completely
- Doesn't require understanding internals
- Catches any behavior changes during refactor

### 3. Run Tests to Establish Baseline

```bash
uv run pytest tests/test_complex.py::test_complex_function_golden_master
```

Tests should pass. If they fail, fix the test setup before refactoring.

### 4. Identify Refactoring Opportunities

**Common patterns:**

**Code duplication:**
```python
# BEFORE: Duplicated logic
def process_user(user):
    if user.email:
        user.email = user.email.lower().strip()
    if user.username:
        user.username = user.username.lower().strip()

def process_group(group):
    if group.name:
        group.name = group.name.lower().strip()
    if group.display_name:
        group.display_name = group.display_name.lower().strip()
```

**Long functions:**
```python
# BEFORE: 150-line function doing many things
def process_request(request):
    # Validation (30 lines)
    # Authentication (40 lines)
    # Business logic (50 lines)
    # Response formatting (30 lines)
```

**Complex conditionals:**
```python
# BEFORE: Deeply nested conditions
if user.is_admin or (user.is_moderator and user.has_permission("edit")):
    if resource.is_public or resource.owner == user:
        if not resource.is_locked:
            # ... do something ...
```

**Magic numbers/strings:**
```python
# BEFORE: Magic values
if user.role == "admin" or user.role == "superadmin":
    timeout = 7200  # What is this number?
```

### 5. Refactor Incrementally

**Make small changes, test after each:**

**Step 1: Extract duplicated code**
```python
# AFTER: Extract common logic
def normalize_string(value: str | None) -> str | None:
    """Normalize string to lowercase and trim whitespace."""
    return value.lower().strip() if value else None

def process_user(user):
    user.email = normalize_string(user.email)
    user.username = normalize_string(user.username)

def process_group(group):
    group.name = normalize_string(group.name)
    group.display_name = normalize_string(group.display_name)
```

**Run tests:**
```bash
uv run pytest tests/test_complex.py
```

Tests should still pass.

**Step 2: Break down long functions**
```python
# AFTER: Split into focused functions
def process_request(request):
    """Process incoming request."""
    validate_request(request)
    user = authenticate_user(request)
    result = execute_business_logic(request, user)
    return format_response(result)

def validate_request(request):
    """Validate request data."""
    # 30 lines of validation

def authenticate_user(request):
    """Authenticate user from request."""
    # 40 lines of auth logic

def execute_business_logic(request, user):
    """Execute core business logic."""
    # 50 lines of business logic

def format_response(result):
    """Format result as HTTP response."""
    # 30 lines of formatting
```

**Run tests again:**
```bash
uv run pytest tests/test_complex.py
```

**Step 3: Simplify conditionals**
```python
# AFTER: Extract condition logic
def user_can_edit(user, resource):
    """Check if user can edit resource."""
    has_role = user.is_admin or (user.is_moderator and user.has_permission("edit"))
    has_access = resource.is_public or resource.owner == user
    is_editable = not resource.is_locked

    return has_role and has_access and is_editable

# Usage
if user_can_edit(user, resource):
    # ... do something ...
```

**Run tests again.**

**Step 4: Replace magic values**
```python
# AFTER: Named constants
# At module level
ADMIN_ROLES = {"admin", "superadmin"}
EXTENDED_SESSION_TIMEOUT = 7200  # 2 hours in seconds
DEFAULT_SESSION_TIMEOUT = 3600   # 1 hour in seconds

# Usage
if user.role in ADMIN_ROLES:
    timeout = EXTENDED_SESSION_TIMEOUT
else:
    timeout = DEFAULT_SESSION_TIMEOUT
```

**Run tests after each change.**

### 6. Improve Type Safety

Add or improve type hints:

```python
# BEFORE: No types
def process_data(data, options):
    # ... implementation ...

# AFTER: Clear types
def process_data(
    data: dict[str, Any],
    options: ProcessOptions | None = None
) -> ProcessResult:
    # ... implementation ...
```

Run type checker:
```bash
uv run mypy src/
```

### 7. Add Documentation

Update docstrings and comments:

```python
def normalize_string(value: str | None) -> str | None:
    """
    Normalize string to lowercase and trim whitespace.

    Used for user input normalization (emails, usernames, etc.)
    to ensure consistent storage and comparison.

    Args:
        value: String to normalize, or None

    Returns:
        Normalized string, or None if input was None

    Example:
        >>> normalize_string("  Alice@Example.COM  ")
        'alice@example.com'
    """
    return value.lower().strip() if value else None
```

### 8. Run Full Validation

After all refactoring:

```bash
# Run all tests
uv run pytest

# Run linting
uv run ruff check .

# Run type checking
uv run mypy src/

# Run project validation
project-steward validate project .
```

All checks should pass.

### 9. Review Changes

Compare before and after:

```bash
git diff
```

**Check:**
- Is code more readable?
- Is duplication reduced?
- Are functions focused (single responsibility)?
- Are complex conditionals simplified?
- Are magic values replaced with named constants?
- Do tests still pass?

### 10. Commit Refactoring

```bash
git add .
git commit -m "refactor: Simplify user validation logic

- Extract normalize_string() for common string processing
- Break process_request() into focused functions
- Replace magic values with named constants
- Add type hints for better safety

All existing tests pass."
```

## Outputs

- Improved code structure
- Same behavior (tests still pass)
- Better readability
- Reduced duplication
- Updated type hints
- Updated documentation
- Commit with refactoring changes

## Common Pitfalls

- **Changing behavior** - Refactor should not change what code does
- **No tests** - Refactoring without tests is rewriting
- **Too large** - Trying to refactor everything at once
- **Breaking tests** - Tests failing after refactor means behavior changed
- **Over-abstraction** - Creating unnecessary layers
- **Perfect is enemy of good** - Don't try to make code perfect

## Validation

Refactor is complete when:

- ✓ Tests pass (behavior unchanged)
- ✓ Code is more readable
- ✓ Duplication reduced
- ✓ Functions focused on single responsibility
- ✓ Type hints added/improved
- ✓ Documentation updated
- ✓ Linting passes
- ✓ Type checking passes
- ✓ Committed

## Integration with Work Modes

**During implementation:**
If you notice code that needs refactoring:

1. **Minor**: Refactor immediately as part of current task
2. **Major**: Add to plan.md as separate refactor task

**Dedicated refactoring sprint:**
If codebase needs significant cleanup:

1. Create sprint (regular or mini)
2. Research: Identify areas needing refactoring
3. Design: Plan refactoring approach
4. Spec: Define target structure
5. Plan: Break down refactoring into tasks
6. Implement: Refactor incrementally with tests

## Refactoring Patterns

**Extract Function:**
```python
# BEFORE
def process():
    # Complex logic block 1
    # ...
    # Complex logic block 2
    # ...

# AFTER
def process():
    handle_block_1()
    handle_block_2()
```

**Extract Variable:**
```python
# BEFORE
if user.role == "admin" or (user.role == "moderator" and user.active):
    # ...

# AFTER
is_privileged_user = (
    user.role == "admin" or
    (user.role == "moderator" and user.active)
)
if is_privileged_user:
    # ...
```

**Replace Conditional with Polymorphism:**
```python
# BEFORE
def calculate_price(item):
    if item.type == "book":
        return item.base_price * 0.9
    elif item.type == "electronics":
        return item.base_price * 1.1
    else:
        return item.base_price

# AFTER
class Book:
    def calculate_price(self):
        return self.base_price * 0.9

class Electronics:
    def calculate_price(self):
        return self.base_price * 1.1

class Item:
    def calculate_price(self):
        return self.base_price
```

**Introduce Parameter Object:**
```python
# BEFORE
def create_user(name, email, role, department, location, manager):
    # ...

# AFTER
@dataclass
class UserData:
    name: str
    email: str
    role: str
    department: str
    location: str
    manager: str

def create_user(user_data: UserData):
    # ...
```

## When NOT to Refactor

**Don't refactor when:**
- Code works and is clear enough
- You don't understand what it does
- No tests exist (write Golden Master first)
- Code will be replaced soon
- Refactoring is just rearranging (no real improvement)
- Under tight deadline (refactor later)

## Performance Refactoring

If refactoring for performance:

1. **Profile first** - Identify actual bottlenecks
2. **Benchmark before** - Measure current performance
3. **Refactor** - Make performance improvement
4. **Benchmark after** - Verify improvement
5. **Document** - Explain optimization in comments

```python
# Before profiling
import cProfile
cProfile.run('expensive_function()')

# After refactoring
def expensive_function():
    """
    Process data efficiently.

    Performance: ~100ms for 10k items (was 5000ms before optimization)
    Optimization: Using dict lookup instead of list iteration
    """
    # Use O(1) dict lookup instead of O(n) list iteration
    lookup = {item.id: item for item in items}
    return [lookup[id] for id in target_ids]
```

## Tips

- **Start small** - Refactor one thing at a time
- **Test constantly** - Run tests after every change
- **Use version control** - Commit working states frequently
- **Read the book** - "Refactoring" by Martin Fowler
- **Follow project patterns** - Look at well-written code in the project
- **Don't mix changes** - Don't add features while refactoring
- **Keep diffs small** - Easier to review and revert
- **Trust the tests** - If tests pass, behavior is preserved
