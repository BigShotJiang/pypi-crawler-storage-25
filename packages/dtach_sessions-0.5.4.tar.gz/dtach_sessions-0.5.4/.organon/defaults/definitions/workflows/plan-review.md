# Plan Review Workflow

## When to Use This Workflow

Use plan-review after completing detail planning (Pass 2) to validate your sprint plan before beginning implementation. This is the final step of the Planning Level.

## Purpose

Catch conflicts, missing dependencies, incomplete steps, and scope issues before implementation starts. A 15-30 minute review can save hours or days of rework.

## Inputs

- Complete plan.md with phases, tasks, and explicit subtasks
- Understanding of file structure from research/design/spec

## Review Checklist

### 1. File Operations Review

Check for conflicts and completeness in file operations:

**Conflicts:**
- [ ] No file created in multiple places
- [ ] No file deleted then referenced later
- [ ] No file both created and edited in same commit (should be just "Create")

**Completeness:**
- [ ] Every new Python module directory has `__init__.py` planned
- [ ] Every new package has tests/ directory with `__init__.py`
- [ ] All imports reference files that will exist at that point in plan

**How to check:**
1. Extract all "Create" operations → list of new files
2. Extract all "Edit" operations → list of modified files
3. Extract all "Delete" operations → list of removed files
4. Check for overlaps and conflicts

### 2. Test Coverage Review

Ensure every code change has corresponding tests:

- [ ] Every "Create X.py" has "Create test_X.py" or "Edit test_X.py"
- [ ] Every "Edit X.py" has "Edit test_X.py" (unless purely refactoring with no behavior change)
- [ ] Every task with code changes includes "Run: uv run pytest ..." step
- [ ] No tests reference code not yet created

**How to check:**
1. List all code file creates/edits
2. For each, verify corresponding test file operation exists
3. Verify test run command exists in same task

### 3. Documentation Review

Ensure user-facing and agent-facing changes are documented:

- [ ] New modules documented in .organon/defaults/docs/reference/
- [ ] New CLI commands documented in .organon/defaults/docs/user-guide/index.md or README.md
- [ ] New MCP tools documented in .organon/defaults/docs/reference/mcp-reference.md
- [ ] Changes to project structure plan to update STRUCTURE.md
- [ ] Changes to agent guidance plan to update CLAUDE.md

**How to check:**
1. List all new user-facing features (CLI, API)
2. Verify documentation updates planned
3. List all new agent-relevant features (MCP, structure)
4. Verify CLAUDE.md/STRUCTURE.md updates planned

### 4. Dependency Order Review

Ensure phases and tasks are ordered by dependencies:

- [ ] No phase uses code from later phase
- [ ] Within each task, subtasks ordered logically (create before edit, code before tests)
- [ ] No circular dependencies between modules
- [ ] Dependencies match what's described in design.md

**How to check:**
1. For each phase, list what it creates
2. For each phase, list what it imports/uses
3. Verify used items created in earlier phases
4. Draw dependency graph if complex

### 5. Commit Boundary Review

Ensure each commit is atomic and testable:

- [ ] Each task (commit boundary) includes all related changes
- [ ] No partial features split across commits
- [ ] Each commit's tests would pass (code + tests + test run all in same commit)
- [ ] Unrelated changes separated into different commits

**How to check:**
1. For each task with (commit: ) marker
2. Verify all subtasks form cohesive unit
3. Verify tests can run and pass
4. Look for unrelated changes that should be separate commits

### 6. Completeness Review

Check for commonly missing steps:

- [ ] Git operations: Are any new files in .gitignore? Should they be tracked?
- [ ] Dependencies: New Python packages added to pyproject.toml?
- [ ] Configuration: New config options added to .organon/config.yaml schema?
- [ ] Migrations: Any existing data that needs migration?
- [ ] Error handling: Are error cases considered?
- [ ] Logging: Is observability planned for new features?

**Common missing items:**
- `__init__.py` files
- Test fixtures or test data files
- Configuration file updates
- Schema updates
- Migration scripts
- Error messages

### 7. Scope & Estimation Review

Validate time estimates are still realistic:

- [ ] Each phase estimate realistic given detailed subtasks
- [ ] No phase has too many tasks (>10-12 subtasks suggests splitting)
- [ ] No single task has too many subtasks (>8-10 suggests breaking down)
- [ ] Total sprint estimate matches sum of phases
- [ ] Dependencies don't create unrealistic critical path

**How to check:**
1. Count subtasks per task
2. Count tasks per phase
3. Estimate time per subtask type (Create: 15-30min, Edit: 10-20min, Test: 20-40min)
4. Compare to phase estimates
5. Adjust if mismatch

## Common Issues Found During Review

### Issue: Files Created Multiple Times
```markdown
Phase 1:
- [ ] Create metadata system
  - [ ] Create src/organon/templates/metadata.py

Phase 2:
- [ ] Create context system
  - [ ] Create src/organon/templates/metadata.py  ← DUPLICATE!
```
**Fix:** Merge into one task or change second to "Edit"

### Issue: Missing __init__.py
```markdown
- [ ] Create package
  - [ ] Create src/organon/templates/metadata.py
  ← Missing: Create src/organon/templates/__init__.py
```
**Fix:** Add `__init__.py` creation

### Issue: Test Before Code
```markdown
- [ ] Add feature
  - [ ] Create tests/test_feature.py
  - [ ] Create src/feature.py  ← WRONG ORDER!
```
**Fix:** Create code before tests

### Issue: Missing Test Run
```markdown
- [ ] Implement feature
  - [ ] Create src/feature.py
  - [ ] Create tests/test_feature.py
  ← Missing: Run pytest
```
**Fix:** Add test execution step

### Issue: Orphaned Documentation
```markdown
Phase 3:
- [ ] Update docs
  - [ ] Edit .organon/defaults/docs/reference/metadata.md
  ← But metadata.py created in Phase 1, should doc update be there?
```
**Fix:** Move doc update to phase where feature is implemented

### Issue: Dependency Violation
```markdown
Phase 1:
- [ ] Create feature A (imports from B)

Phase 2:
- [ ] Create feature B  ← Used by A but created after!
```
**Fix:** Swap phase order

### Issue: Atomic Commit Violation
```markdown
- [ ] Add feature (commit: )
  - [ ] Create src/feature.py
  - [ ] Create tests/test_feature.py
  - [ ] Run: uv run pytest tests/test_feature.py
  - [ ] Refactor unrelated module  ← Doesn't belong!
```
**Fix:** Move unrelated change to separate task

## Outputs

- Validated plan.md with issues resolved
- Confidence that plan is complete and executable
- Clear understanding of dependencies and order
- Realistic time estimates

## When Review is Complete

Mark plan.md as reviewed:

```markdown
## Plan Review

**Reviewed:** YYYY-MM-DD
**Issues Found:** N
**Issues Resolved:** N

- [x] File operations reviewed (no conflicts)
- [x] Test coverage reviewed (all code has tests)
- [x] Documentation reviewed (all changes documented)
- [x] Dependencies reviewed (correct order)
- [x] Commit boundaries reviewed (atomic commits)
- [x] Completeness reviewed (no missing steps)
- [x] Scope reviewed (estimates realistic)

**Plan Status:** Ready for implementation
```

## Integration with Work Modes

**In Planning Level:**
```
Research → Design → Spec → Plan (Pass 1: Structure) → Plan (Pass 2: Details) → Plan (Pass 3: Review) → DONE
```

**After review passes:**
- Transition to Development Level
- Update sprint status from Created/Next to Current
- Begin implementation following plan.md

## Tips

- **Take your time** - Rushing review defeats the purpose
- **Use a fresh perspective** - Review after a break if possible
- **Check systematically** - Don't skip checklist items
- **Fix issues now** - Don't defer to "figure out during implementation"
- **Update estimates** - If scope grew, adjust phase estimates
- **Document assumptions** - If uncertain, note in plan.md

## Red Flags

Signs the plan needs major revision:

- More than 5-6 conflicts found
- Phase dependencies form cycles
- Time estimates doubled after review
- Many "TODO: figure this out" items
- Uncertainty about file structure
- Missing major components from spec

If you see these, consider returning to Design or Spec phase before finalizing plan.
