# Review Workflow

## When to Use This Workflow

Use review when you need to:
- Check code quality
- Verify standards compliance
- Validate implementation against spec
- Catch issues before merge
- Ensure tests are adequate
- Review documentation completeness

Review is typically done after implementation and testing in the Development Level.

## Inputs

- Implemented code
- Tests
- Specification (from spec.md or Spec section)
- Project standards (from CLAUDE.md)
- Plan checklist (from plan.md or Plan section)

## Process

### 1. Review Against Spec

Verify implementation matches specification:

**Checklist:**
- ✓ All specified functions/methods implemented?
- ✓ Signatures match spec (parameters, return types)?
- ✓ Edge cases handled as specified?
- ✓ Error handling matches spec?
- ✓ Examples from spec actually work?

**Example:**
```python
# Spec says:
def authenticate_user(username: str, password: str, *, remember_me: bool = False) -> AuthResult

# Implementation should match exactly:
def authenticate_user(username: str, password: str, *, remember_me: bool = False) -> AuthResult:
    # ... implementation ...
```

### 2. Check Standards Compliance

Verify code follows project CLAUDE.md:

**For Python:**
- ✓ Uses src layout?
- ✓ Type hints on all functions?
- ✓ Docstrings on public functions?
- ✓ Follows naming conventions?
- ✓ Uses uv for dependencies?
- ✓ Passes ruff linting?
- ✓ Passes mypy type checking?

**For TypeScript:**
- ✓ Type annotations present?
- ✓ ESLint passes?
- ✓ Follows project patterns?

**For all projects:**
- ✓ No prohibited patterns (mocks, stubs, placeholders, fallbacks with fake data)?
- ✓ Logging included for debugging?
- ✓ Error handling explicit (no silent failures)?

### 3. Run Validation Tools

Execute project-specific checks:

```bash
# Python projects
uv run ruff check .
uv run mypy src/
uv run pytest
project-steward validate project .

# TypeScript projects
bun run lint
bun run typecheck
bun run test

# Rust projects
cargo clippy
cargo test
cargo fmt --check
```

Fix any issues found.

### 4. Review Test Coverage

Verify tests are adequate:

**Checklist:**
- ✓ Happy path tested?
- ✓ Edge cases tested?
- ✓ Error handling tested?
- ✓ Integration points tested?
- ✓ All tests passing?

**Not required:**
- 100% coverage (test what matters)
- Tests for trivial code
- Mocks or stubs

### 5. Check Observability

Verify code can be debugged:

**Checklist:**
- ✓ Logging added at key points?
- ✓ Error messages are clear?
- ✓ Important state changes logged?
- ✓ Follows project log format?

**Example:**
```python
logger.debug(f"Authenticating user: {username}")
# ... authentication logic ...
logger.info(f"User {username} authenticated successfully")
```

### 6. Review Documentation

Check documentation is updated:

**For new features:**
- ✓ README updated with usage examples?
- ✓ CLAUDE.md updated if new patterns introduced?
- ✓ API documentation generated (if applicable)?
- ✓ STRUCTURE.md still accurate?

**For bug fixes:**
- ✓ Comments explain non-obvious fixes?
- ✓ Known issues updated if relevant?

### 7. Verify Plan Completion

Check all tasks in plan.md completed:

```markdown
## Plan

- [x] Implement authentication service (commit: a1b2c3d) ✓
- [x] Add authentication tests (commit: e4f5g6h) ✓
- [x] Update documentation (commit: i7j8k9l) ✓
```

All tasks should be checked off with commit IDs.

### 8. Self-Review Checklist

Go through this checklist:

**Code Quality:**
- [ ] Code is readable and maintainable
- [ ] No unnecessary complexity
- [ ] Follows DRY principle (Don't Repeat Yourself)
- [ ] Functions are focused (single responsibility)
- [ ] Variable/function names are clear

**Correctness:**
- [ ] Implements spec correctly
- [ ] Handles edge cases
- [ ] No obvious bugs
- [ ] Logic is sound

**Standards:**
- [ ] Follows project CLAUDE.md
- [ ] No prohibited patterns
- [ ] Linting passes
- [ ] Type checking passes (if applicable)

**Testing:**
- [ ] Tests exist and pass
- [ ] Tests cover important cases
- [ ] Tests are maintainable

**Observability:**
- [ ] Logging included
- [ ] Error messages are clear
- [ ] Can be debugged

**Documentation:**
- [ ] README updated (if needed)
- [ ] Code comments explain why (not what)
- [ ] Examples work

### 9. Review Commit Messages

Check commit messages follow convention:

**Good messages:**
```bash
feat(sprint-05): Implement user authentication service
fix(sprint-05): Resolve race condition in token generation
docs(sprint-05): Update README with auth examples
test(sprint-05): Add integration tests for auth flow
```

**Bad messages:**
```bash
Update stuff
Fix bug
WIP
asdf
```

### 10. Final Validation

Before considering review complete:

```bash
# Clean build
rm -rf dist/ build/ *.egg-info/
uv run pytest

# Or for TypeScript
rm -rf dist/ node_modules/.cache/
bun run test

# Structure validation
project-steward validate project .
```

All checks should pass.

## Outputs

- Code that passes all checks
- Tests that pass
- Documentation that is complete and accurate
- Commit messages that follow conventions
- Validation tools all passing

## Common Pitfalls

- **Skipping linters** - "It looks fine" is not good enough
- **Not running tests** - Always run full test suite
- **Ignoring documentation** - Future you will be frustrated
- **No self-review** - Catching your own issues before others do
- **Assuming compliance** - Actually check CLAUDE.md standards
- **Missing edge cases** - Review spec for all cases
- **Vague commits** - Fix commit messages before merging

## Validation

Review is complete when:

- ✓ Implementation matches spec
- ✓ All validation tools pass (linting, type checking, tests)
- ✓ Project standards followed
- ✓ Tests adequate
- ✓ Logging included
- ✓ Documentation updated
- ✓ All plan tasks complete
- ✓ Commit messages follow convention

## Integration with Work Modes

**Self-review (most common):**
1. Complete implementation and tests
2. Run review checklist
3. Fix any issues
4. Mark review task complete in plan.md

**Peer review (for complex changes):**
1. Push changes to branch
2. Create pull request
3. Another developer reviews using this checklist
4. Address feedback
5. Merge when approved

**In sprint:**
Review is typically a task in plan.md:
```markdown
- [x] Implement authentication service (commit: a1b2c3d)
- [x] Add authentication tests (commit: e4f5g6h)
- [x] Update documentation (commit: i7j8k9l)
- [ ] Review and validate implementation (commit: )
```

## Tips

- **Review in stages** - Don't try to check everything at once
- **Use automation** - Let tools catch standard issues
- **Read your own code** - Pretend someone else wrote it
- **Check examples** - Actually run code from docs/README
- **Look for patterns** - If you wrote similar code 3 times, extract a function
- **Be critical** - Better to catch issues now than later
- **Fix as you find** - Don't defer fixes
- **Use project-steward** - `project-steward validate project .` catches many issues

## Review Anti-Patterns

**Things that indicate problems:**

**Code smells:**
- Very long functions (>50 lines)
- Deeply nested conditionals (>3 levels)
- Many parameters (>5)
- Repeated code
- Unclear names
- Comments explaining what (should explain why)

**Testing smells:**
- No edge case tests
- Tests that always pass
- Slow tests (>1 second for unit tests)
- Brittle tests (break when implementation changes)

**Documentation smells:**
- Out of sync with code
- No examples
- Only describing what (not why or how)
- Assumes too much knowledge

## Automated Review Tools

**For Python:**
```bash
# Linting
uv run ruff check .

# Type checking
uv run mypy src/

# Testing
uv run pytest --cov

# Project structure
project-steward validate project .
```

**For TypeScript:**
```bash
# Linting
bun run lint

# Type checking
bun run typecheck

# Testing
bun run test
```

**For Rust:**
```bash
# Linting
cargo clippy

# Formatting
cargo fmt --check

# Testing
cargo test
```

## When to Ask for Help

Request peer review when:
- Architectural changes affecting multiple systems
- Security-critical code
- Complex algorithms
- New patterns being introduced
- Unsure about implementation approach
- Change is high-risk

## Pull Request Review

If reviewing someone else's code:

1. **Understand the goal** - What is this PR trying to accomplish?
2. **Check the spec** - Does implementation match design?
3. **Run the code** - Don't just read it
4. **Run the tests** - Do they pass? Are they adequate?
5. **Check standards** - CLAUDE.md compliance
6. **Look for issues** - Security, performance, maintainability
7. **Be constructive** - Suggest improvements, don't just criticize
8. **Approve or request changes** - Be clear about what's blocking

Use this task template as a review checklist for PRs.
