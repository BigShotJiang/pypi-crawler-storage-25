# Design Workflow (Optional - UI Only)

## When to Use This Workflow

Use design when your sprint includes user interface work requiring:
- Visual design (colors, fonts, typography)
- Layout and spacing decisions
- UI component selection
- Visual hierarchy
- Interaction patterns
- Responsive design considerations

**SKIP THIS PHASE** for backend-only, infrastructure, or non-UI work.

Design maps to the work of a UI/UX designer, not software architecture decisions.

## Dependencies

**Required prior phases:** Requirements, Research (optional)

**Information consumed:**
- From Requirements: User needs, interaction flows
- From Research: Existing UI patterns in codebase

**Information produced:**
- For Specification: UI component APIs, prop specifications
- For Plan: UI implementation tasks

## Inputs

- User interface requirements
- Brand guidelines (if applicable)
- Existing design system or UI patterns
- User flows and interaction requirements

## Process

### 1. Review UI Requirements

From requirements.md:
- What UI elements are needed?
- What user interactions must be supported?
- Any existing patterns to follow?

### 2. Define Visual Design

Specify:
- Color palette (primary, secondary, accent colors)
- Typography (fonts, sizes, weights)
- Spacing system (margins, padding)
- Border and shadow styles

### 3. Layout Design

Define:
- Component layouts
- Responsive breakpoints
- Grid systems
- Container structures

### 4. Component Selection

Choose:
- Which UI components to use (existing or new)
- Component hierarchy
- Reusable patterns

### 5. Document Design Decisions

For each major design choice:
- What was decided
- Why this approach
- Alternatives considered
- Impact on user experience

## Outputs

- **Design document** (design.md) containing:
  - Visual design specifications (colors, fonts, spacing)
  - Layout definitions
  - Component selections
  - Design decisions with rationale
  - Mockups or wireframes (optional)

## Common Pitfalls

- **Architecture confusion** - Don't describe software structure here; that's Architecture phase
- **Over-specifying** - Focus on design system decisions, not pixel-perfect specs
- **Missing rationale** - Document WHY decisions were made
- **Ignoring existing patterns** - Check codebase for established UI patterns

## Validation

Design is complete when you can answer:

- ✓ What are the key visual design elements (colors, fonts, spacing)?
- ✓ What layout approach will be used?
- ✓ Which UI components are needed?
- ✓ Why were these design choices made?

## Integration with Work Modes

**In Sprint Planning Work Mode:**
- Create `.organon/sprints/NN_Name_Status/design.md` only if UI work
- Optional phase - skip if no UI work
- May run in parallel with Architecture for full-stack features

**In One-Off-Task Work Mode:**
- Usually skip
- Quick design decisions inline

## Tips

- Reference existing design system if available
- Include visual examples or links
- Document accessibility considerations
- Consider responsive design needs
- Keep it focused on visual/UX decisions
