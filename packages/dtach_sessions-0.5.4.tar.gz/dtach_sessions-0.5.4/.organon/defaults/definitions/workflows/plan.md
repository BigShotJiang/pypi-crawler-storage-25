# Plan Workflow

## When to Use This Workflow

Use plan when you need to:
- Create a concrete task checklist for implementation
- Break down design into actionable steps
- Define work sequence
- Set up commit tracking
- Transition from Planning Level to Development Level

Plan is the final workflow in the Planning Level of a sprint and produces the workflow for execution.

## Inputs

- Research findings (understanding of problem)
- Design decisions (approach and architecture)
- Technical specifications (contracts and APIs)
- Understanding of scope and complexity

## Process

### 1. Review Planning Artifacts

Review what was created during planning:
- Research: What did we learn?
- Design: What approach did we choose?
- Spec: What are we building exactly?

### 2. Identify Implementation Tasks

Break down the work into concrete, actionable tasks:

**Good tasks:**
- ✓ "Implement authentication service class"
- ✓ "Add JWT token generation and validation"
- ✓ "Create database migration for users table"
- ✓ "Add authentication endpoint to API"
- ✓ "Write tests for authentication flow"
- ✓ "Update documentation with auth examples"

**Bad tasks (too vague):**
- ✗ "Do authentication"
- ✗ "Finish the feature"
- ✗ "Write code"

### 3. Sequence Tasks

Order tasks logically:
1. Foundation first (data models, core logic)
2. Integration second (APIs, commands)
3. Testing third (unit tests, integration tests)
4. Documentation fourth (README, CLAUDE.md)

Consider dependencies:
- Database migrations before code that uses them
- Core logic before tests
- Implementation before documentation

### 4. Estimate Scope

For each task, consider:
- Is this a single commit or multiple?
- Can this be done in one sitting?
- Does this depend on other tasks?

Break large tasks into smaller ones:
- ✗ "Implement entire authentication system"
- ✓ "Implement password hashing utility"
- ✓ "Implement user authentication logic"
- ✓ "Implement session management"
- ✓ "Implement token generation"

### 5. Create Checklist

Write the task list in plan.md (or Plan section):

```markdown
## Plan

### Foundation
- [ ] Create User data model (commit: )
- [ ] Create AuthResult data model (commit: )
- [ ] Implement password hashing utility (commit: )
- [ ] Create database migration for users table (commit: )

### Core Logic
- [ ] Implement authenticate_user function (commit: )
- [ ] Implement token generation (commit: )
- [ ] Implement token validation (commit: )
- [ ] Add rate limiting for failed attempts (commit: )

### Integration
- [ ] Add POST /api/auth/login endpoint (commit: )
- [ ] Add POST /api/auth/logout endpoint (commit: )
- [ ] Add authentication middleware (commit: )

### Testing
- [ ] Write unit tests for password hashing (commit: )
- [ ] Write unit tests for authentication logic (commit: )
- [ ] Write integration tests for auth endpoints (commit: )

### Documentation
- [ ] Update README with authentication section (commit: )
- [ ] Add authentication examples to CLAUDE.md (commit: )
- [ ] Update API documentation (commit: )
```

### 6. Add Metadata (Optional)

For complex sprints, add extra information:

```markdown
- [ ] Implement authentication service (commit: ) [3h] [core]
- [ ] Add rate limiting (commit: ) [1h] [security]
- [ ] Write integration tests (commit: ) [2h] [testing]
```

### 7. Identify Risks

Note potential blockers or unknowns:

```markdown
## Potential Blockers

- Redis setup might be needed for rate limiting
- Database migration needs coordination with other branches
- JWT library choice needs validation
```

## Outputs

- **Plan document** (plan.md or Plan section) containing:
  - Concrete task checklist
  - Logical task sequence
  - Commit tracking placeholders: `(commit: )`
  - Potential blockers or risks
  - Estimated completion (optional)

## Common Pitfalls

- **Tasks too vague** - "Do the thing" is not actionable
- **Tasks too large** - Each task should be one focused commit
- **Wrong sequence** - Dependencies out of order
- **Missing steps** - Forgetting testing, documentation, or validation
- **No commit tracking** - Missing `(commit: )` placeholders
- **Too detailed** - Don't specify every line of code, just major steps
- **No flexibility** - Plan is a guide, not a contract; expect to adjust

## Validation

Plan is complete when you can answer:

- ✓ What are the concrete implementation tasks?
- ✓ In what order should they be done?
- ✓ Can each task be completed in a single commit?
- ✓ Have we included testing and documentation?
- ✓ What might block progress?

You should feel ready to start implementing immediately.

## Integration with Work Modes

**In Sprint-Execution Work Mode:**
- Create `docs/sprints/NN_Name_Status/plan.md`
- This is the transition point: Planning Level → Development Level

**In One-Off-Task Work Mode:**
- Mental plan or simple `task.yaml` checklist
- Usually skip formal plan.md

## During Implementation

As you complete tasks:

1. **Mark task in progress:**
```markdown
- [x] Implement authentication service (commit: ) ← working on this
- [ ] Add rate limiting (commit: )
```

2. **Implement and commit:**
```bash
# Write code, test, validate
git add .
git commit -m "feat(sprint-05): Implement authentication service"
```

3. **Add commit ID:**
```markdown
- [x] Implement authentication service (commit: a1b2c3d)
- [ ] Add rate limiting (commit: )
```

4. **Move to next task**

## Adjusting the Plan

Plans change during implementation. Common adjustments:

**Discovering new tasks:**
```markdown
- [x] Implement authentication service (commit: a1b2c3d)
- [ ] Fix race condition in token generation (commit: ) ← added during implementation
- [ ] Add rate limiting (commit: )
```

**Splitting tasks:**
```markdown
- [x] Implement authentication service - core (commit: a1b2c3d)
- [x] Implement authentication service - error handling (commit: e4f5g6h)
- [ ] Add rate limiting (commit: )
```

**Cycling back to design:**
```markdown
## Notes

During implementation of rate limiting, discovered that Redis approach won't work
with our deployment model. Need to return to Design section and choose alternative
approach (database-based rate limiting).

[Updated Design section with new approach]

Updated tasks:
- [ ] Create rate_limit_attempts table migration (commit: )
- [ ] Implement database-based rate limiting (commit: )
```

## Tips

- Start each task with tests (TDD approach) if appropriate
- Keep commits focused (one task = one commit ideal)
- Update plan as you go, don't wait until end
- If stuck on a task for >2 hours, document blocker and move on
- Add commit IDs immediately after committing
- Review completed tasks before marking sprint complete
