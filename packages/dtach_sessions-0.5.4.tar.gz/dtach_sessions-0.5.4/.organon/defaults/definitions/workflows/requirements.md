# Requirements Workflow

## When to Use This Workflow

Use requirements when you need to:
- Define what stakeholders need
- Capture user stories
- Document non-functional requirements (NFRs)
- Set success criteria
- Establish project scope

Requirements is the first workflow in the Planning Level of a sprint.

## Dependencies

**Required prior phases:** None (first phase)

**Information consumed:**
- User requests
- Stakeholder needs
- Business goals

**Information produced:**
- For Research: Features to investigate, constraints to validate
- For Architecture: NFR targets (performance, security, scalability)
- For Specification: Expected behaviors and validation rules
- For Plan: Scope boundaries

## Inputs

- User requests or feature descriptions
- Business goals and objectives
- Stakeholder constraints
- Existing requirements documentation

## Process

### 1. Identify Stakeholder Needs

Gather what users/stakeholders actually need:
- User stories (As a [user], I want [feature] so that [benefit])
- Feature requests with descriptions
- Business objectives

### 2. Document Non-Functional Requirements

Capture quality attributes:
- Performance targets (response time, throughput)
- Security requirements (authentication, authorization, data protection)
- Scalability needs (concurrent users, data volume)
- Reliability expectations (uptime, error rates)
- Maintainability goals

### 3. Define Success Criteria

How will we know we're done:
- Measurable acceptance criteria
- Testable conditions
- Observable outcomes

### 4. Establish Scope

Clear boundaries:
- What's included (must-have, should-have)
- What's explicitly excluded
- Dependencies on other work
- Assumptions to validate

### 5. Consider Sequence Diagrams (Optional)

For complex user interactions:
- May include high-level sequence diagrams showing user flows
- More detailed sequence diagrams belong in Specification phase
- Use sparingly - only when user interaction flow is complex

## Outputs

- **Requirements document** (requirements.md) containing:
  - User stories or feature descriptions
  - Non-functional requirements
  - Success criteria
  - Scope (in/out)
  - Sequence diagrams (optional, high-level only)

## Common Pitfalls

- **Solution-focused requirements** - Describing HOW instead of WHAT
- **Missing NFRs** - Focusing only on features, ignoring performance/security
- **Vague success criteria** - Can't measure if requirement is met
- **Scope creep** - Not explicitly excluding things
- **Assumption confusion** - Mixing assumptions with requirements

## Validation

Requirements is complete when you can answer:

- ✓ What problem are we solving for whom?
- ✓ What are the must-have features?
- ✓ What are the non-functional requirements?
- ✓ How will we know we're successful?
- ✓ What's in and out of scope?

## Integration with Work Modes

**In Sprint Planning Work Mode:**
- Create `.organon/sprints/NN_Name_Status/requirements.md`
- First phase of planning sequence
- May cycle back from Research if requirements need refinement

**In One-Off-Task Work Mode:**
- Usually skip formal requirements
- Mental clarity on what to achieve

## Tips

- Use concrete examples in user stories
- Make NFRs measurable (numbers, not "fast")
- Reference similar features already in codebase
- Validate assumptions early with stakeholders
- Keep focused on WHAT, not HOW
