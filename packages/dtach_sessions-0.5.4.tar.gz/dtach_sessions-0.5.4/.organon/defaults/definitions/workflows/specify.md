# Specify Workflow

## When to Use This Workflow

Use specify when you need to:
- Define technical contracts and APIs (signatures, not implementations)
- Specify data structures and formats (schemas, not logic)
- Document interface signatures (what to call, not how it works)
- Provide usage examples (how to CALL the API, not how to IMPLEMENT it)
- Define edge cases and error handling (what errors mean, not error handling code)
- Create technical reference for implementation (contracts to implement, not the implementation itself)

**CRITICAL: Specifications define WHAT to build and HOW TO USE IT, not HOW TO IMPLEMENT IT.**

Specify typically follows Design in the Planning Level of a sprint.

## Dependencies

**Required prior phases:** Requirements, Research, Architecture

**Information consumed:**
- From Requirements: Expected behaviors, validation rules
- From Research: API conventions, data format standards
- From Architecture: Component/module/class names, file locations

**Information produced:**
- For Plan: Specific APIs to implement, contracts to fulfill
- Implementation contracts (what to build)

**Key focus:** HOW to call components, WHAT's inside them.

## Inputs

- Design decisions (from design.md or Design section)
- Architectural approach
- Integration plan
- Understanding of requirements

## Process

### 1. Review Design

Start by reviewing design decisions:
- What components are we building?
- What interfaces do they need?
- How do they interact?

### 2. Define Interfaces

Specify technical contracts:

**Example:** Function signatures
```python
def authenticate_user(
    username: str,
    password: str,
    *,
    remember_me: bool = False
) -> AuthResult:
    """
    Authenticate user with credentials.

    Args:
        username: User's login name
        password: Plain text password (will be hashed)
        remember_me: If True, extend session duration to 30 days

    Returns:
        AuthResult with token and user info

    Raises:
        AuthenticationError: If credentials are invalid
        RateLimitError: If too many failed attempts
    """
```

**Example:** API endpoints
```
POST /api/auth/login
Request:
  {
    "username": "alice",
    "password": "secret123",
    "remember_me": false
  }

Response (200 OK):
  {
    "token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
    "user": {
      "id": 42,
      "username": "alice",
      "roles": ["user", "admin"]
    }
  }

Response (401 Unauthorized):
  {
    "error": "invalid_credentials",
    "message": "Username or password incorrect"
  }
```

### 3. Sequence Diagrams

For complex multi-component interactions:

**When to include:**
- Multiple APIs need to be called in sequence
- Complex orchestration across components
- Non-obvious interaction flows

**How to document:**
- Show API calls between components
- Include request/response data shapes
- Document error flows
- Reference architecture components by name

**Example:**
```
User -> AuthService: authenticate(username, password)
AuthService -> Database: query_user(username)
Database -> AuthService: User data
AuthService -> TokenService: generate_token(user)
TokenService -> AuthService: JWT token
AuthService -> User: AuthResult(token, user)
```

**Placement rationale:** Sequence diagrams show "HOW to call multiple APIs in sequence" which is interface-level documentation. Architecture shows WHAT components exist, Specification shows HOW to use them (including orchestration).

### 4. Specify Data Structures

**All data structures belong in Specification** - this is the complete contract.

Define:
- Data classes/models with required fields
- Database schemas
- API request/response formats
- Validation rules

**What goes here vs Architecture:**
- Architecture: "User module exists in auth/models.py"
- Specification: "User class has fields: id, username, email, password_hash"

Architecture defines WHERE, Specification defines WHAT's INSIDE.

Define data formats:

**Example:** Data classes
```python
@dataclass
class AuthResult:
    """Result of authentication attempt."""
    token: str
    user: User
    expires_at: datetime

@dataclass
class User:
    """User account information."""
    id: int
    username: str
    email: str
    roles: list[str]
    created_at: datetime
```

**Example:** Database schema
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
```

### 5. Document Edge Cases

Specify behavior for:
- Empty or null inputs
- Invalid data formats
- Permission denied scenarios
- Rate limiting
- Concurrent access
- System failures

**Example:**
```markdown
## Edge Cases

**Empty username:**
- Raise `ValueError("Username cannot be empty")`

**Invalid password format:**
- Raise `ValueError("Password must be at least 8 characters")`

**Account locked (too many failed attempts):**
- Raise `RateLimitError("Account locked for 15 minutes")`
- Log security event
- Send notification to user email

**Database unavailable:**
- Raise `ServiceUnavailableError("Authentication service temporarily unavailable")`
- Return HTTP 503
```

### 6. Provide Examples

Include concrete usage examples:

**Example:**
```python
# Successful authentication
result = authenticate_user("alice", "secret123", remember_me=True)
print(f"Token: {result.token}")
print(f"User: {result.user.username}")

# Handle authentication failure
try:
    result = authenticate_user("bob", "wrong")
except AuthenticationError as e:
    print(f"Login failed: {e}")
```

### 7. Specify Error Handling

Define error types and handling:

```python
class AuthenticationError(Exception):
    """Base class for authentication errors."""

class InvalidCredentialsError(AuthenticationError):
    """Username or password incorrect."""

class AccountLockedError(AuthenticationError):
    """Too many failed login attempts."""

class RateLimitError(AuthenticationError):
    """Rate limit exceeded."""
```

### 8. Define Validation Rules

Specify what constitutes valid input:

```markdown
## Validation Rules

**Username:**
- 3-32 characters
- Alphanumeric plus underscore and hyphen
- Case-insensitive
- Must be unique

**Password:**
- Minimum 8 characters
- At least one uppercase letter
- At least one number
- At least one special character
```

## Outputs

- **Specification document** (spec.md or Spec section) containing:
  - API contracts (functions, methods, endpoints)
  - Data structures and formats
  - Edge cases and error handling
  - Concrete code examples
  - Validation rules
  - Integration examples

## Common Pitfalls

- **WRITING IMPLEMENTATION CODE** - NEVER write function bodies, logic, or complete implementations. Only write signatures, schemas, and usage examples.
- **Too abstract** - Spec should have concrete signatures and schemas (not vague descriptions)
- **Over-specifying** - Don't specify HOW to implement, just WHAT the contract is
- **Missing edge cases** - Not thinking through error scenarios
- **No usage examples** - Examples showing how to CALL the API clarify intent better than prose
- **Incomplete signatures** - Missing type hints, return types, or exceptions
- **Vague errors** - Not specifying what errors mean or when they're raised
- **Skipping validation** - Not defining what "valid" means

**Remember:** If you're writing `if`, `for`, `while`, `try/except` blocks, or any logic - STOP. That's implementation code, not specification.

## Validation

Specification is complete when you can answer:

- ✓ What are the exact function/method signatures?
- ✓ What data structures are needed?
- ✓ How are edge cases handled?
- ✓ What errors can occur and what do they mean?
- ✓ What does valid input look like?
- ✓ How is this used in practice? (examples)

You should feel confident that someone could implement this without asking clarifying questions.

## Integration with Work Modes

**In Sprint-Execution Work Mode:**
- Create `docs/sprints/NN_Name_Status/spec.md`
- Document all specifications there
- May need to update Design if specs reveal issues

**In One-Off-Task Work Mode:**
- Usually skip formal specification
- Inline code comments may be sufficient

## Tips

- Use actual code snippets, not pseudocode
- Include both success and failure examples
- Reference similar APIs already in the codebase
- Think through the developer experience (DX)
- Consider backwards compatibility if applicable
- Use type hints (Python), TypeScript interfaces, or equivalent
- Specify units for numeric values (seconds, bytes, etc.)
- Define abbreviations and terminology
