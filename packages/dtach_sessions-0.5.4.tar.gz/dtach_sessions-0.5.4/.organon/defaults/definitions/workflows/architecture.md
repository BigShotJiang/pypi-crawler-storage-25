# Workflow: Architecture

## When to Use This Workflow

Use architecture workflow when:
- Design phase identified new classes, modules, or layers
- Non-functional requirements need explicit design
- Clear scaffolding plan needed before implementation

**Skip if:** Design concluded "leverage existing infrastructure" with no structural changes.

## Dependencies

**Required prior phases:** Requirements, Research, [Design if UI work]

**Information consumed:**
- From Requirements: Features, NFRs (performance, security, scalability)
- From Research: Existing patterns, technical constraints, project architecture
- From Design: UI components (if UI work)

**Information produced:**
- For Specification: Component/module/class names, file locations
- For Plan: Implementation scaffolding order

**Key focus:** WHERE code lives, not WHAT's inside it (that's Specification).

## Inputs

From design.md:
- Selected approach and rationale
- Integration points identified
- Quality attributes defined

## Process

1. **Review project docs:** Read docs/design.md and docs/architecture.md (if exists) to understand current architecture
2. **Assess scope:** Does design require new structure? If minimal, write brief architecture.md
3. **Class structure:** Define new classes, responsibilities, relationships (if any)
4. **Module organization:** Identify files to create/modify
   - New files needed
   - Existing files to modify
   - Module/package structure

   **Examples:**
   - "Create auth/service.py with AuthService class"
   - "Create auth/models.py for authentication domain"
   - "Modify api/routes.py to add auth endpoints"

   Note: File organization, not file contents (contents are in Specification).
5. **NFRs:** Define performance, security, scalability needs (or inherit from existing)
6. **Scaffolding plan:** Define implementation phases
7. **Document impact:** Identify what needs to change in project-level docs

## Outputs

architecture.md containing:
- Summary (always)
- Class Structure (brief if none)
- Module Organization (file lists)
- NFRs (explicit or inherited)
- Scaffolding Plan (phases)
- Project Documentation Impact (what needs updating in docs/)

## Sizing Guidance

Write only what's needed. No architectural changes? Say so briefly (10-20 lines total).

**5-minute read test:** Can someone understand the structural decisions in 5 minutes?

If no:
- Sprint too large? (Split it)
- Over-documenting? (Focus on new structure, not existing systems)
- Genuinely complex? (Rare but valid)

**Example minimal architecture.md:**

```markdown
## Summary
No architectural changes. Uses existing template system.

## Class Structure
No new classes.

## Module Organization
New files: src/templates/requirements.md
Modified: src/mcp_server/tools.py (add function)

## Non-Functional Requirements
Inherits from existing system.

## Scaffolding Plan
Phase 1: Create templates
Phase 2: Add MCP tool function

## Project Documentation Impact
Review: Consulted docs/design.md
Impact: No changes to project-level docs (adds sprint templates only)
Reconciliation plan: N/A
```

## Common Pitfalls

- Documenting existing architecture in detail (focus on NEW structure)
- Conflating architecture with design (design = approach, architecture = structure)
- Over-detailing before implementation (enough to guide, not every detail)
- Skipping architecture when new structure exists

## Validation

Before finalizing:
- [ ] Reviewed project-level docs/design.md and docs/architecture.md
- [ ] Clearly stated architectural impact (could be "none")
- [ ] Identified files/modules affected
- [ ] Avoided describing existing architecture
- [ ] Documented impact on project-level docs
- [ ] Passes 5-minute read test
- [ ] Someone can understand structural changes from this document

## Integration with Work Modes

- Sprint planning: After design.md, before spec.md
- References design decisions
- Guides spec.md implementation details

## Tips

- If design.md said "use existing X," your architecture.md should be brief
- New classes/modules deserve detail, no changes deserve brevity
- NFRs can inherit from existing system if unchanged
- Scaffolding plan guides implementation order, not exhaustive task list
- Always review project docs first - ensures alignment and identifies doc updates needed
- Document reconciliation happens after implementation (plan it during architecture phase)
- If no project doc changes needed, explicitly state that
