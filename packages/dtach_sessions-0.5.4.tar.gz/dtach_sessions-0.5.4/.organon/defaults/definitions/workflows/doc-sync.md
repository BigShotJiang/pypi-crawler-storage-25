# Documentation Sync Workflow

## When to Use This Workflow

Use doc-sync when you need to:
- Ensure documentation reflects current codebase structure
- Verify module listings match actual directories
- Check that path references in docs are valid
- Update stale references after refactoring
- Sync README/CLAUDE.md after significant changes
- Fix broken documentation links

Doc-sync is typically done after:
- Major refactoring
- Directory restructuring
- Module additions or removals
- Significant feature additions
- Sprint completion

## Inputs

- Current codebase structure
- README.md files
- CLAUDE.md files
- STRUCTURE.md files
- Sprint documentation
- Recent commits showing structural changes

## Process

### 1. Scan Current Structure

Use organon tools to understand current state:

```bash
# Build index of current structure
organon scan .

# List all detected projects
organon list-projects .

# Validate against rules
organon validate .

# Validate template structure
organon validate-templates .
```

Take note of:
- What modules/directories exist
- What projects are detected
- Current validation state

### 2. Check README Module Listings

**For each README.md in the codebase:**

Compare documented modules against actual structure:

```markdown
# In README.md, look for sections like:

## Modules

### Scanner Module
Scans and indexes codebases...

### Validator Module
Validates project structure...
```

**Verify:**
- ✓ Listed modules exist as directories?
- ✓ Module descriptions match what code actually does?
- ✓ New modules documented?
- ✓ Deleted modules removed from docs?
- ✓ Examples still work?

**Update:**
- Add missing modules
- Remove references to deleted modules
- Update descriptions to match current implementation
- Fix or update examples

### 3. Validate CLAUDE.md Path References

**For each CLAUDE.md file:**

Extract and verify all path references:

```bash
# Find path references in CLAUDE.md
grep -E "(see|See|located|Location:|path:|directory:)" CLAUDE.md
grep -E "^\s*-.*/" CLAUDE.md
```

**Common patterns to check:**
```markdown
- See: templates/workflows/development/
- Tests located at: tests/integration/
- Configuration: config/settings.yaml
- Documentation: .organon/defaults/docs/user-guide/index.md
```

**For each reference:**
- ✓ Does the path exist?
- ✓ Is it the correct path (not moved)?
- ✓ Does the file/directory serve the documented purpose?

**Update:**
- Fix paths that moved during refactoring
- Remove references to deleted paths
- Add references to new important paths
- Update relative paths if directory structure changed

### 4. Check Cross-References

Look for references between documents:

```markdown
# Example cross-references
See sprint documentation in `.organon/sprints/05_Name/`
Workflow definitions in `templates/workflows/`
Design principles in `docs/design.md`
```

**Verify:**
- ✓ Cross-referenced documents exist?
- ✓ Links point to current locations?
- ✓ Referenced content is still relevant?

**Update:**
- Fix broken cross-references
- Update section references if documents restructured
- Add new relevant cross-references

### 5. Validate Code Examples

For any code examples in documentation:

```python
# Example from README
from organon import scanner

result = scanner.scan(".")
print(result)
```

**Verify:**
- ✓ Import paths still correct?
- ✓ Function signatures unchanged?
- ✓ Example still runs without errors?
- ✓ Output still matches what's documented?

**Update:**
- Fix import paths after refactoring
- Update function calls if signatures changed
- Update expected output if behavior changed
- Add new examples for new features

### 6. Check STRUCTURE.md Accuracy

If project has STRUCTURE.md files:

```bash
# Regenerate to see changes
organon structure generate .

# Or update existing
organon structure update .
```

**Compare:**
- Current STRUCTURE.md
- Actual directory structure
- Any manual annotations to preserve

**Update:**
- Regenerate if significantly out of date
- Update manually if small changes
- Preserve manual annotations and explanations

### 7. Review Sprint Documentation

For completed sprints:

**Check:**
- ✓ References to implementation still valid?
- ✓ File paths mentioned still correct?
- ✓ Architectural decisions still reflected in code?

**Update:**
- Add notes if implementation evolved from plan
- Update paths if files moved
- Link to related documentation

### 8. Verify Tool Commands

Documentation often includes tool commands:

```bash
# Check commands still work
uv run organon scan .
uv run organon validate .
pytest tests/
```

**Verify:**
- ✓ Commands use correct syntax?
- ✓ Options still valid?
- ✓ Output format unchanged?

**Update:**
- Fix command syntax if tools changed
- Update options if flags renamed
- Update output examples if format changed

### 9. Check Configuration References

Documentation referencing config:

```yaml
# Example config reference
config:
  templates_dir: templates/schemas/
  rules_dir: rules/
```

**Verify:**
- ✓ Config paths correct?
- ✓ Config keys still valid?
- ✓ Default values documented accurately?

**Update:**
- Fix config paths after restructuring
- Update keys if configuration changed
- Document new configuration options

### 10. Update Observability Documentation

If CLAUDE.md has observability section:

```yaml
observability:
  logs:
    location: "logs/organon.log"
  debug_mode:
    command: "DEBUG=1 organon scan"
```

**Verify:**
- ✓ Log locations correct?
- ✓ Debug commands still work?
- ✓ Environment variables valid?

**Update:**
- Fix log paths if changed
- Update debug commands if interface changed
- Document new observability features

## Outputs

- Updated README.md files with accurate module listings
- Updated CLAUDE.md files with valid path references
- Fixed cross-references between documents
- Working code examples
- Accurate STRUCTURE.md files
- Valid configuration references
- Commits with sync changes

## Common Pitfalls

- **Assuming docs are correct** - Always verify against actual code
- **Not testing examples** - Examples that don't work are worse than no examples
- **Missing new features** - Document new modules/features added
- **Preserving stale info** - Remove references to deleted code
- **Not checking recursively** - Check all CLAUDE.md files, not just root
- **Forgetting sprint docs** - Update sprint documentation too
- **Breaking links** - Verify links work after path changes

## Validation

Documentation sync is complete when:

- ✓ All modules in README exist and descriptions are accurate
- ✓ All path references in CLAUDE.md are valid
- ✓ Cross-references between documents work
- ✓ Code examples run without errors
- ✓ STRUCTURE.md reflects current layout
- ✓ Configuration references are correct
- ✓ Tool commands work as documented
- ✓ No broken links
- ✓ Changes committed

## Integration with Work Modes

**After refactoring:**
```markdown
## Plan
- [x] Refactor scanner module structure (commit: a1b2c3d)
- [x] Update tests (commit: e4f5g6h)
- [ ] Sync documentation (commit: )
```

**After sprint completion:**
```markdown
## Plan
- [x] Complete all implementation tasks (commit: ...)
- [x] Update user-facing documentation (commit: ...)
- [ ] Sync technical documentation (commit: )
```

**Standalone doc-sync sprint:**
For major refactoring or when docs drift significantly:
```markdown
# Mini Sprint: Documentation Sync

## Plan
- [ ] Scan and catalog current structure (commit: )
- [ ] Update all README files (commit: )
- [ ] Validate all CLAUDE.md references (commit: )
- [ ] Fix broken examples (commit: )
- [ ] Update STRUCTURE.md files (commit: )
```

## Tips

- **Use tools first** - `organon scan` and `organon list-projects` show current reality
- **Grep for paths** - Find all path references quickly with grep
- **Test examples** - Actually run code snippets from docs
- **Check recent commits** - See what changed structurally
- **Start at root** - Work from root CLAUDE.md down to module docs
- **Batch similar updates** - Fix all path references in one pass
- **Document as you find** - Don't defer documentation during implementation

## Tools for Doc Sync

**Structure scanning:**
```bash
# See current structure
organon scan .
organon list-projects .

# Validate structure
organon validate .
organon validate-templates .
```

**Find path references:**
```bash
# In CLAUDE.md files
grep -r "templates/" **/*.md
grep -r "docs/" **/*.md
grep -r "See:" **/*.md

# Find broken links (basic check)
find . -name "*.md" -exec grep -l "\[.*\](.*)" {} \;
```

**Check module existence:**
```bash
# List actual directories
ls -d src/*/

# Compare with documented modules in README
grep "^###" README.md
```

**Verify examples:**
```bash
# Extract and test code examples
# (Manual process - copy examples and run them)
```

## When This Task Is Most Valuable

**Critical after:**
- Directory reorganization
- Module renames or moves
- Splitting monolithic modules
- Merging related modules
- Extracting shared libraries
- Major refactoring

**Less critical for:**
- Internal implementation changes (no structural change)
- Bug fixes that don't change interfaces
- Adding new functions to existing modules

**Proactive sync:**
- End of each sprint (quick check)
- Before major releases
- When onboarding new team members
- After several weeks of rapid development

## Documentation Sync vs Document Task

**Use doc-sync when:**
- Verifying docs match current structure
- Fixing broken references after changes
- Ensuring paths are valid
- Catching documentation drift

**Use document when:**
- Adding documentation for new features
- Writing initial documentation
- Adding usage examples
- Documenting new patterns

**Often both are needed:**
```markdown
## Plan
- [x] Implement new feature (commit: a1b2c3d)
- [x] Document new feature (commit: e4f5g6h)      ← document task
- [ ] Sync existing docs (commit: )              ← doc-sync task
```

## Why This Is a Task, Not a Tool

Documentation sync requires **judgment** that tools cannot provide:

**Tools can check:**
- ✓ Does path exist? (file system check)
- ✓ Does module exist? (directory check)
- ✓ Are there broken links? (link validation)

**Only agents/humans can judge:**
- Does description accurately reflect implementation?
- Is the documentation complete?
- Is the example still relevant?
- Should this be documented differently?
- Does this match recent architectural changes?

This task guides the agent through systematic verification while leaving judgment calls to intelligence rather than automation.
