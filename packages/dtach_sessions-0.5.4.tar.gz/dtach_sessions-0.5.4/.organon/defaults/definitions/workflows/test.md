# Test Workflow

## When to Use This Workflow

Use test when you need to:
- Verify code behavior
- Write automated tests
- Create test fixtures
- Validate implementation matches spec
- Ensure code doesn't break in the future (regression testing)
- Test edge cases and error handling

Test is typically done during or after implementation in the Development Level.

## Inputs

- Implemented code
- Specification (from spec.md or Spec section)
- Understanding of edge cases
- Project testing standards

## Process

### 1. Understand Testing Strategy

Check project CLAUDE.md for testing approach:

**Lean testing strategy** (Organon standard):
- **Golden Master snapshots** - For complex outputs
- **Integration tests** - For workflows and CLI commands
- **Unit tests** - For pure functions only

**Not required:**
- Mocks or stubs (implement real thing or skip test)
- 100% coverage (test what matters)
- Tests for trivial code (getters, setters)

### 2. Choose Test Type

**Golden Master (snapshot tests):**
Use for complex outputs that are hard to specify but easy to verify visually:

```python
def test_format_project_report(snapshot):
    """Test project report formatting."""
    project = load_test_project()
    report = format_project_report(project)

    # First run creates snapshot, subsequent runs compare
    snapshot.assert_match(report, "project_report.txt")
```

**Integration tests:**
Use for workflows, CLI commands, end-to-end scenarios:

```python
def test_authentication_workflow():
    """Test complete authentication flow."""
    # Create test user
    user = create_test_user("alice", "password123")

    # Authenticate
    result = authenticate_user("alice", "password123")

    # Verify token works
    user_info = validate_token(result.token)
    assert user_info.username == "alice"

    # Cleanup
    delete_test_user(user)
```

**Unit tests:**
Use for pure functions (no I/O, no side effects):

```python
def test_hash_password():
    """Test password hashing."""
    password = "secret123"
    hashed = hash_password(password)

    assert hashed != password  # Not plain text
    assert verify_password(password, hashed)  # Can verify
    assert not verify_password("wrong", hashed)  # Rejects wrong password
```

### 3. Test Happy Path

Start with successful scenarios:

```python
def test_authenticate_user_success():
    """Test successful authentication."""
    # Setup
    user = create_test_user("alice", "password123")

    # Execute
    result = authenticate_user("alice", "password123")

    # Verify
    assert result.token is not None
    assert result.user.username == "alice"
    assert result.expires_at > datetime.utcnow()

    # Cleanup
    delete_test_user(user)
```

### 4. Test Edge Cases

Test boundary conditions and special cases:

```python
def test_authenticate_user_empty_username():
    """Test authentication with empty username."""
    with pytest.raises(ValueError, match="Username cannot be empty"):
        authenticate_user("", "password123")

def test_authenticate_user_empty_password():
    """Test authentication with empty password."""
    with pytest.raises(ValueError, match="Password cannot be empty"):
        authenticate_user("alice", "")

def test_authenticate_user_invalid_credentials():
    """Test authentication with wrong password."""
    user = create_test_user("alice", "correct_password")

    with pytest.raises(InvalidCredentialsError):
        authenticate_user("alice", "wrong_password")

    delete_test_user(user)

def test_authenticate_user_nonexistent_user():
    """Test authentication with non-existent username."""
    with pytest.raises(InvalidCredentialsError):
        authenticate_user("nonexistent", "password123")
```

### 5. Test Error Handling

Verify errors are raised correctly:

```python
def test_rate_limiting():
    """Test rate limiting after failed attempts."""
    user = create_test_user("alice", "correct_password")

    # Make multiple failed attempts
    for _ in range(5):
        with pytest.raises(InvalidCredentialsError):
            authenticate_user("alice", "wrong_password")

    # Next attempt should be rate limited
    with pytest.raises(RateLimitError, match="Account locked"):
        authenticate_user("alice", "wrong_password")

    delete_test_user(user)
```

### 6. Use Fixtures for Setup

Avoid repetitive setup code:

```python
import pytest

@pytest.fixture
def test_user():
    """Create a test user for authentication tests."""
    user = create_test_user("alice", "password123")
    yield user
    delete_test_user(user)

def test_authenticate_user_success(test_user):
    """Test successful authentication."""
    result = authenticate_user("alice", "password123")
    assert result.user.username == "alice"

def test_authenticate_user_invalid_password(test_user):
    """Test authentication with wrong password."""
    with pytest.raises(InvalidCredentialsError):
        authenticate_user("alice", "wrong_password")
```

### 7. Test Integration Points

Test how components work together:

```python
def test_authentication_api_endpoint():
    """Test authentication through API."""
    # Create test client
    client = TestClient(app)

    # Create test user
    user = create_test_user("alice", "password123")

    # Make API request
    response = client.post("/api/auth/login", json={
        "username": "alice",
        "password": "password123"
    })

    # Verify response
    assert response.status_code == 200
    data = response.json()
    assert "token" in data
    assert data["user"]["username"] == "alice"

    # Cleanup
    delete_test_user(user)
```

### 8. Run Tests

Verify tests pass:

```bash
# Run all tests
uv run pytest

# Run specific test file
uv run pytest tests/test_auth.py

# Run specific test
uv run pytest tests/test_auth.py::test_authenticate_user_success

# Run with coverage
uv run pytest --cov=src/auth
```

## Outputs

- Test files (typically in `tests/` directory)
- All tests passing
- Coverage report (optional, if project requires)
- Updated plan.md with commit ID

## Common Pitfalls

- **Testing implementation details** - Test behavior, not internals
- **Brittle tests** - Tests that break when implementation changes (but behavior doesn't)
- **Incomplete edge cases** - Missing error scenarios
- **No cleanup** - Tests leaving data behind
- **Slow tests** - Integration tests that don't need to be
- **Over-mocking** - Creating fake objects instead of testing real code
- **Under-testing** - Only testing happy path
- **No assertions** - Tests that don't actually verify anything

## Validation

Testing is complete when:

- ✓ Happy path tested
- ✓ Edge cases tested (empty inputs, invalid data, etc.)
- ✓ Error handling tested
- ✓ Integration points tested (if applicable)
- ✓ All tests passing
- ✓ Tests committed
- ✓ Plan.md updated with commit ID

## Integration with Work Modes

**Test-Driven Development (TDD) approach:**
1. Write failing test (based on spec)
2. Implement code to make test pass
3. Refactor if needed
4. Commit both test and implementation

**Test-After approach:**
1. Implement code
2. Write tests to verify behavior
3. Fix any issues found
4. Commit implementation and tests separately or together

**In sprint:**
- Tests are often a separate task in plan.md
- Or combined with implementation task
- Update plan.md when tests committed

## Tips

- **Start with integration tests** - They catch more issues
- **Use fixtures** - Avoid repetitive setup/teardown
- **Test one thing per test** - Focused tests are easier to debug
- **Name tests descriptively** - `test_auth_with_empty_username` not `test_auth_1`
- **Avoid hardcoded values** - Use constants or fixtures
- **Test error messages** - They're part of the interface
- **Keep tests fast** - Slow tests won't be run
- **Don't test framework code** - Test your code, not libraries
- **Use parametrize for similar tests:**

```python
@pytest.mark.parametrize("username,password,expected_error", [
    ("", "password", "Username cannot be empty"),
    ("alice", "", "Password cannot be empty"),
    ("alice", "short", "Password must be at least 8 characters"),
])
def test_authentication_validation(username, password, expected_error):
    with pytest.raises(ValueError, match=expected_error):
        authenticate_user(username, password)
```

## Testing Standards

**For Python projects:**
- Framework: pytest
- Fixtures: Use pytest fixtures
- Assertions: Use assert statements
- Snapshots: Use pytest-snapshot or syrupy

**For TypeScript projects:**
- Framework: Vitest or Jest
- Mocking: Avoid if possible
- Assertions: Use expect() API

**For Rust projects:**
- Framework: Built-in testing (`#[test]`)
- Fixtures: Use setup/teardown functions
- Assertions: Use assert! macros

## When to Skip Tests

It's okay to skip tests for:
- Trivial getters/setters
- Configuration loading
- Prototype/experimental code
- One-off scripts
- Code that will be replaced soon

But always test:
- Core business logic
- Error handling
- Edge cases
- Public APIs
- Security-critical code
