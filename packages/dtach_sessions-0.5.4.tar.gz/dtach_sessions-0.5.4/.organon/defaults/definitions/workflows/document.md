# Document Workflow

## When to Use This Workflow

Use document when you need to:
- Update README with new features
- Add usage examples
- Update CLAUDE.md with new patterns
- Update STRUCTURE.md after changes
- Write API documentation
- Add code comments for complex logic
- Document configuration or deployment

Document is typically done after implementation in the Development Level.

## Inputs

- Implemented code
- Specification (from spec.md or Spec section)
- Project CLAUDE.md (to understand existing patterns)
- README (to update)

## Process

### 1. Determine What to Document

**Update README when:**
- Adding new features or commands
- Changing installation or setup
- Adding new dependencies
- Changing CLI interface
- Adding configuration options

**Update CLAUDE.md when:**
- Introducing new patterns
- Adding observability setup
- Changing build/test commands
- Adding new integration patterns
- Updating standards or conventions

**Update STRUCTURE.md when:**
- Adding new directories
- Reorganizing code
- Adding new major components

**Add code comments when:**
- Logic is non-obvious
- Workarounds for bugs or limitations
- Performance optimizations
- Security considerations
- Algorithm explanations

### 2. Update README

Follow README standards from global CLAUDE.md:

**Good README structure:**
```markdown
# Project Name

Brief description of what this project does (1-2 sentences).

## Installation

```bash
# Actual tested commands
cd tools/my-tool
uv sync
```

## Usage

```bash
# Real examples with expected output
uv run my-tool --help

# Output:
# Usage: my-tool [OPTIONS] COMMAND
# ...
```

## Modules

### Core Module
Description of what it does, with real implementation details

```python
from my_tool import core

result = core.process_data("input.txt")
print(result)
```

### CLI Module
Description of CLI commands with examples

```bash
my-tool analyze --input data.csv --output report.json
```

## Dependencies

- Python 3.11+
- uv (package manager)
- Redis (for caching)

## Development

```bash
# Run tests
uv run pytest

# Run linting
uv run ruff check .

# Run type checking
uv run mypy src/
```
```

**README Anti-Patterns (avoid these):**
- ✗ Marketing fluff ("revolutionary", "cutting-edge")
- ✗ Features section that duplicates Modules section
- ✗ Vague descriptions ("quality scoring" without explaining how)
- ✗ Examples that don't work
- ✗ No output examples
- ✗ Assuming user knowledge

### 3. Update CLAUDE.md

**Add to CLAUDE.md when introducing new patterns:**

```markdown
## Project Info

- **Type:** CLI Tool
- **Language:** Python 3.11
- **Package Manager:** uv
- **Entry Point:** src/my_tool/cli.py

## Standards

Inherits from: /monorepo-root/CLAUDE.md

### New Pattern: Authentication Service

When adding authentication to features:

```python
from my_tool.auth import authenticate_user

# Always use context manager for auth
with authenticate_user(username, password) as user:
    # User is authenticated for this block
    perform_authorized_action(user)
# Auth token automatically cleaned up
```

## Observability

observability:
  logs:
    location: "logs/my-tool.log"
    format: "structured JSON"

  debug_mode:
    command: "DEBUG=1 uv run my-tool"
    environment:
      - DEBUG: Enable debug logging
      - LOG_LEVEL: Override log level (DEBUG, INFO, WARN, ERROR)

## Testing

- Framework: pytest
- Run: `uv run pytest`
- Coverage: `uv run pytest --cov`
- Snapshots: Using syrupy for golden master tests
```

### 4. Update STRUCTURE.md

When structure changes, regenerate or update:

```bash
# If using project-steward
project-steward generate structure-manifest .

# Or update manually
```

**STRUCTURE.md format:**
```markdown
# Project Structure

## Directory Layout

```
src/my_tool/
├── __init__.py           # Package exports
├── cli.py                # CLI entry point
├── core/                 # Core business logic
│   ├── processor.py      # Data processing
│   └── validator.py      # Input validation
├── auth/                 # Authentication (NEW)
│   ├── service.py        # Auth service
│   └── tokens.py         # JWT token handling
└── utils/               # Shared utilities
```

## Navigation

- **Entry point:** src/my_tool/cli.py
- **Core logic:** src/my_tool/core/
- **Tests:** tests/
- **Documentation:** README.md, CLAUDE.md
```

### 5. Add Code Comments

**When to comment:**
- Non-obvious logic
- Workarounds or hacks
- Performance optimizations
- Security considerations
- Complex algorithms

**Good comments:**
```python
# Use Redis for session storage because:
# 1. Allows session sharing across multiple instances
# 2. Automatic expiration (TTL)
# 3. Fast lookups (O(1))
session_store = RedisStore(ttl=3600)

# HACK: Work around bug in library v2.3
# See: https://github.com/lib/lib/issues/123
# Remove when upgrading to v2.4+
if library_version == "2.3":
    result = workaround_function()

# Performance: Cache expensive computation
# Reduces API calls from ~1000/min to ~10/min
@lru_cache(maxsize=128)
def get_user_permissions(user_id: int) -> set[str]:
    return fetch_from_api(user_id)
```

**Bad comments:**
```python
# Bad: Describes what (code already shows this)
# Increment counter
counter += 1

# Bad: Obvious
# Get user
user = get_user(user_id)

# Bad: Out of date
# Returns True if valid  (function now returns User object)
def validate_user(user_id):
    return User(...)
```

### 6. Write Usage Examples

**Examples should:**
- Actually work (test them!)
- Show common use cases
- Include expected output
- Be copy-pasteable

**Good example:**
```markdown
## Authentication Example

```python
from my_tool.auth import authenticate_user

# Authenticate user
result = authenticate_user("alice", "password123")
print(f"Token: {result.token}")
print(f"Expires: {result.expires_at}")

# Output:
# Token: eyJ0eXAiOiJKV1QiLCJhbGc...
# Expires: 2025-10-10 15:30:00
```

**Bad example:**
```markdown
## Authentication

You can authenticate users.

```python
# Authenticate
result = auth(user, pass)
# Do something with result
```
```

### 7. Document Configuration

If adding configuration options:

```markdown
## Configuration

Create `config.yaml`:

```yaml
auth:
  # Session duration in seconds (default: 3600)
  session_duration: 7200

  # Maximum failed login attempts (default: 5)
  max_failed_attempts: 3

  # Enable two-factor authentication (default: false)
  enable_2fa: true
```

Or use environment variables:

```bash
# Session duration in seconds
export AUTH_SESSION_DURATION=7200

# Maximum failed login attempts
export AUTH_MAX_FAILED_ATTEMPTS=3

# Enable two-factor authentication
export AUTH_ENABLE_2FA=true
```
```

### 8. Update Backlog (If Applicable)

If this sprint implements a backlog item, update `.organon/sprints/backlog.md`:

**When sprint completes:**
1. Check if sprint name references a backlog item ID (e.g., Sprint implements #011)
2. Move item from `## Planned (In Sprint)` to `## Completed`
3. Update format: `- [#NNN] **Title** (Sprint NN_Name, commit hash)`
4. Keep item in `## Details` section (remains searchable)

**Example:**
```markdown
## Planned (In Sprint)

- [#011] **Code Symbol Index** (Sprint: 22_SymbolIndex_Current)

## Completed

- [#011] **Code Symbol Index** (Sprint 22_SymbolIndex, commit a1b2c3d)
```

**Note:** When backlog lifecycle tools (#027) are implemented, this will be automated via MCP tool.

### 9. Update API Documentation

If project has API documentation:

```python
def authenticate_user(
    username: str,
    password: str,
    *,
    remember_me: bool = False
) -> AuthResult:
    """
    Authenticate user with credentials.

    This function validates user credentials and generates a JWT token
    for subsequent API calls. Failed attempts are rate-limited.

    Args:
        username: User's login name (3-32 alphanumeric characters)
        password: Plain text password (will be hashed before comparison)
        remember_me: If True, extend session duration to 30 days (default: 1 day)

    Returns:
        AuthResult containing:
            - token (str): JWT token for authentication
            - user (User): User account information
            - expires_at (datetime): Token expiration time

    Raises:
        ValueError: If username or password is empty
        InvalidCredentialsError: If credentials are incorrect
        AccountLockedError: If account is locked due to failed attempts
        RateLimitError: If rate limit exceeded

    Example:
        >>> result = authenticate_user("alice", "secret123")
        >>> print(result.token)
        eyJ0eXAiOiJKV1QiLCJhbGc...

        >>> # With remember_me
        >>> result = authenticate_user("alice", "secret123", remember_me=True)
        >>> print(result.expires_at)
        2025-11-09 10:30:00

    See Also:
        - validate_token(): Verify JWT token
        - logout_user(): Invalidate token
    """
```

## Outputs

- Updated README (if applicable)
- Updated CLAUDE.md (if applicable)
- Updated STRUCTURE.md (if applicable)
- Code comments added (if needed)
- Updated API documentation (if applicable)
- Working examples
- Commit with documentation changes

## Common Pitfalls

- **Examples don't work** - Always test your examples
- **No output shown** - Users want to see what commands produce
- **Out of date** - Documentation doesn't match code
- **Too much** - Over-documenting obvious code
- **Too little** - No examples or usage guidance
- **Wrong audience** - README assumes expert knowledge
- **Marketing speak** - Focus on what it does, not hyperbole

## Validation

Documentation is complete when:

- ✓ README updated (if feature is user-facing)
- ✓ CLAUDE.md updated (if new patterns introduced)
- ✓ STRUCTURE.md accurate (if structure changed)
- ✓ Examples actually work (tested)
- ✓ Code comments explain why (not what)
- ✓ API documentation complete (if public API)
- ✓ No broken links
- ✓ **Backlog updated** (if sprint implemented backlog item - move from Planned to Completed)
- ✓ Committed

## Integration with Work Modes

**In sprint:**
Documentation is typically a task in plan.md:
```markdown
- [x] Implement authentication service (commit: a1b2c3d)
- [x] Add authentication tests (commit: e4f5g6h)
- [ ] Update documentation (commit: )
```

**What to update:**
1. Check if README needs updates
2. Check if CLAUDE.md needs updates
3. Check if STRUCTURE.md needs regeneration
4. Add code comments if needed
5. Commit documentation changes
6. Update plan.md with commit ID

## Tips

- **Test examples** - Copy-paste them and run them
- **Show output** - Users want to see what happens
- **Use real values** - Not "foo" and "bar"
- **Link to related docs** - Help users find more info
- **Update as you code** - Don't defer documentation
- **Be concise** - Respect reader's time
- **Use code blocks** - With proper syntax highlighting
- **Include troubleshooting** - Common issues and solutions

## Documentation Tools

**Generate STRUCTURE.md:**
```bash
project-steward generate structure-manifest .
```

**Check for broken links:**
```bash
# For markdown files
grep -r "\[.*\](.*)" . | # Find links
# Verify they point to real files
```

**Generate API docs (Python):**
```bash
# Using docstrings and sphinx
uv run sphinx-build -b html docs/ docs/_build/

# Or pdoc
uv run pdoc --html src/my_tool/
```

## Documentation Standards

From global CLAUDE.md:

**README Requirements:**
- Write for engineers
- Explain what code actually does
- Real CLI examples with outputs
- No marketing fluff
- Use "Modules" section instead of "Features"
- Include concrete dependencies
- Include installation steps
- Include usage examples

**Icons:**
- Only use ✗ (red X) and ✓ (green checkmark)
- No other icons in docs or logs
