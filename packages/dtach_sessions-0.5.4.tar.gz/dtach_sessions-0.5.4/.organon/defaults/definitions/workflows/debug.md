# Debug Workflow

## When to Use This Workflow

Use debug when you need to:
- Fix application failures
- Investigate unexpected behavior
- Resolve errors or exceptions
- Diagnose performance issues
- Find root cause of bugs

Debug can happen during implementation or after deployment.

## Inputs

- Failing code or application
- Error messages or stack traces
- Project CLAUDE.md (observability section)
- Understanding of expected behavior

## Process

### 1. Visibility First

**ALWAYS capture full information before attempting fixes:**

```bash
# Read project CLAUDE.md for observability setup
cat path/to/CLAUDE.md | grep -A 20 "Observability"

# Enable debug mode (check CLAUDE.md for command)
DEBUG=1 uv run my-tool command

# Or with environment variables
export LOG_LEVEL=DEBUG
export DEBUG=*
uv run my-tool command

# Capture full output
uv run my-tool command > output.log 2>&1
```

**Capture:**
- Full error messages
- Complete stack traces
- All log output
- Input data that caused failure
- Environment information

### 2. Reproduce Reliably

Create minimal reproduction:

```python
# Minimal script to reproduce issue
from my_tool import failing_function

# Exact input that causes failure
result = failing_function("problematic-input")
```

**Requirements:**
- Reproduction is deterministic (fails every time)
- Minimal (remove unrelated code)
- Self-contained (can run standalone)

### 3. Read the Error Message

**Read the ENTIRE error message, carefully:**

```
Traceback (most recent call last):
  File "src/my_tool/processor.py", line 45, in process_data
    result = transform(data)
  File "src/my_tool/transform.py", line 23, in transform
    return data["key"]["nested"]
KeyError: 'nested'
```

**What this tells us:**
- Error type: `KeyError`
- Missing key: `'nested'`
- Location: `transform.py`, line 23
- Code: `data["key"]["nested"]`
- **Root cause**: `data["key"]` exists but doesn't have `"nested"` key

### 4. Check Logs

Review logs at appropriate level:

```bash
# Check application logs
tail -f logs/my-tool.log

# Search for errors
grep "ERROR" logs/my-tool.log

# Check for warnings before error
grep -B 10 "ERROR" logs/my-tool.log
```

**What to look for:**
- Errors or warnings before failure
- State changes leading to failure
- Input values
- Timing information

### 5. Isolate the Problem

Test components standalone:

```python
# Test failing function in isolation
from my_tool.transform import transform

# Test with known good input
good_data = {"key": {"nested": "value"}}
result = transform(good_data)
print(f"Good input works: {result}")

# Test with failing input
bad_data = {"key": {}}
try:
    result = transform(bad_data)
except KeyError as e:
    print(f"Fails on missing key: {e}")
```

**Isolation strategies:**
- Test function with known good input
- Test function with failing input
- Remove dependencies (mock external services)
- Simplify inputs
- Test each component separately

### 6. Form Hypothesis

Based on evidence, hypothesize root cause:

**Example:**
```
Evidence:
- Error: KeyError: 'nested'
- Location: data["key"]["nested"]
- Logs show: data = {"key": {}}

Hypothesis:
Input data is missing the "nested" key. Likely caused by
upstream function not populating it in all cases.

Prediction:
If we check calling code, we'll find cases where "nested"
is not set in data["key"].
```

### 7. Test Hypothesis

Verify hypothesis before fixing:

```python
# Add logging to test hypothesis
def transform(data):
    logger.debug(f"transform called with: {data}")
    logger.debug(f"data['key'] contains: {data['key']}")

    if "nested" not in data["key"]:
        logger.warning("Missing 'nested' key in data['key']")

    return data["key"]["nested"]
```

Run again and check logs confirm hypothesis.

### 8. Implement Evidence-Based Fix

**Only fix based on evidence:**

```python
# Fix: Handle missing key
def transform(data):
    """Transform data with nested key."""

    if "key" not in data:
        raise ValueError("Missing required 'key' in data")

    if "nested" not in data["key"]:
        raise ValueError("Missing required 'nested' in data['key']")

    return data["key"]["nested"]
```

Or if missing key should be handled gracefully:

```python
def transform(data):
    """Transform data with optional nested key."""
    return data.get("key", {}).get("nested", None)
```

### 9. Verify Fix

Confirm fix resolves issue:

```bash
# Test with original failing input
uv run my-tool command --input failing-input.txt

# Should now either:
# 1. Work correctly, OR
# 2. Fail with clear error message
```

### 10. Add Regression Test

Prevent issue from returning:

```python
def test_transform_with_missing_nested_key():
    """Test transform handles missing nested key."""
    data = {"key": {}}  # Missing 'nested' key

    with pytest.raises(ValueError, match="Missing required 'nested'"):
        transform(data)
```

## Outputs

- Root cause identified
- Fix implemented
- Fix verified
- Regression test added
- Commit with fix and test

## Common Pitfalls

- **Blind iteration** - Making random changes without evidence
- **Skipping visibility** - Not capturing logs before fixing
- **Not reading errors** - Skimming error messages
- **Guessing** - Fixing based on intuition instead of evidence
- **Over-fixing** - Changing multiple things at once
- **No verification** - Not confirming fix works
- **No test** - Missing regression test

## Validation

Debug is complete when:

- ✓ Root cause identified (with evidence)
- ✓ Fix implemented and tested
- ✓ Original failing case now works
- ✓ Regression test added
- ✓ No new issues introduced
- ✓ Committed

## Maximum 3 Attempts Rule

**If not fixed after 3 systematic attempts:**

1. **Document what you tried:**
```markdown
## Debug Session

### Attempt 1
- Hypothesis: Missing 'nested' key
- Fix: Added validation
- Result: Still failing with different error

### Attempt 2
- Hypothesis: Data corruption upstream
- Fix: Added data validation earlier
- Result: Found data is valid, issue elsewhere

### Attempt 3
- Hypothesis: Race condition in caching
- Fix: Added locking
- Result: Still fails intermittently
```

2. **Ask for help:**
- Document findings
- Share reproduction steps
- Provide logs
- Explain what you tried

**Don't waste time on endless iteration.**

## Integration with Work Modes

**During implementation:**
If you discover a bug while implementing:

1. **Minor bug**: Fix immediately and continue
2. **Major bug**: Add to plan.md as new task

**After deployment:**
If bug is reported:

1. Create bug report (issue, ticket, or sprint task)
2. Follow debug process
3. Implement fix
4. Add regression test
5. Commit with `bugfix:` or `fix(sprint-XX):` prefix

## Debug Mode Protocol

**From project CLAUDE.md observability section:**

Every project must document:
- How to enable debug mode
- Where logs are written
- What log levels exist
- What environment variables control logging

**Example:**
```bash
# Enable debug logging
DEBUG=1 uv run my-tool command

# Set log level
LOG_LEVEL=DEBUG uv run my-tool command

# Write logs to file
LOG_FILE=debug.log uv run my-tool command
```

## Systematic Debugging Checklist

Use this checklist for every debugging session:

- [ ] Read project CLAUDE.md observability section
- [ ] Enable debug mode
- [ ] Capture full error output
- [ ] Create minimal reproduction
- [ ] Read entire error message
- [ ] Check logs around failure time
- [ ] Test components in isolation
- [ ] Form hypothesis based on evidence
- [ ] Test hypothesis (add logging if needed)
- [ ] Implement evidence-based fix
- [ ] Verify fix works
- [ ] Add regression test
- [ ] Commit fix and test

## Common Bug Patterns

**Null/None errors:**
```python
# Problem
result = data["key"]  # KeyError if missing

# Fix
result = data.get("key")  # Returns None if missing
if result is None:
    raise ValueError("Missing required 'key'")
```

**Race conditions:**
```python
# Problem
if not os.path.exists(file_path):
    create_file(file_path)  # Race: file might be created between check and create

# Fix (atomic operation)
try:
    with open(file_path, "x") as f:  # "x" fails if file exists
        f.write(content)
except FileExistsError:
    pass  # File already exists, that's fine
```

**Type errors:**
```python
# Problem
result = process(data)  # Returns None on error

# Fix
result = process(data)
if result is None:
    raise ProcessingError("Failed to process data")
```

**Off-by-one errors:**
```python
# Problem
for i in range(len(items)):
    process(items[i], items[i + 1])  # IndexError on last item

# Fix
for i in range(len(items) - 1):
    process(items[i], items[i + 1])
```

## Tools for Debugging

**Python:**
```python
# Interactive debugger
import pdb; pdb.set_trace()

# Or use ipdb
import ipdb; ipdb.set_trace()

# Logging
import logging
logger = logging.getLogger(__name__)
logger.debug(f"Variable value: {x}")
```

**TypeScript:**
```typescript
// Console logging
console.debug("Variable value:", x);

// Debugger
debugger;
```

**Bash:**
```bash
# Debug mode
set -x  # Print commands before execution

# Error checking
set -e  # Exit on error

# Both
set -ex
```

## Tips

- **Logs are truth** - Add logging liberally during debug
- **Binary search** - Comment out half the code to isolate issue
- **Fresh eyes** - Take a break if stuck
- **Rubber duck** - Explain problem out loud
- **Check assumptions** - Verify "obvious" things
- **Read docs** - Library might behave differently than expected
- **Check git history** - When did this break?
- **Test on clean state** - Clear caches, restart services
