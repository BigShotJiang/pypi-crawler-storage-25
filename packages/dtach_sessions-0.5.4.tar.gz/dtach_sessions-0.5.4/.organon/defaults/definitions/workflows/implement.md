# Implement Workflow

## When to Use This Workflow

Use implement when you need to:
- Write production code
- Follow the plan from Planning Level
- Translate specifications into working software
- Create new functionality
- Modify existing code

Implement is the primary workflow in the Development Level of a sprint.

## Inputs

- Plan with concrete task checklist (from plan.md or Plan section)
- Specifications (from spec.md or Spec section)
- Design decisions (from design.md or Design section)
- Understanding of existing codebase patterns

## Process

### 1. Review Current Task

Before writing code:
- Read the task in plan.md
- Review relevant specs
- Understand acceptance criteria
- Check for dependencies

### 2. Set Up Context

Load necessary information:
- Read project CLAUDE.md for standards
- Review existing similar code
- Understand integration points
- Check observability requirements

### 3. Follow Project Standards

Adhere to project conventions:

**For Python projects:**
```python
# Use src layout
src/package_name/
  __init__.py
  module.py

# Type hints
def process_data(input: str, max_size: int = 1000) -> ProcessResult:
    ...

# Docstrings
def authenticate(username: str, password: str) -> AuthResult:
    """
    Authenticate user with credentials.

    Args:
        username: User's login name
        password: Plain text password

    Returns:
        AuthResult with token and user info

    Raises:
        AuthenticationError: If credentials invalid
    """
```

**For TypeScript projects:**
```typescript
// Use interfaces
interface User {
  id: number;
  username: string;
  email: string;
}

// Type everything
function authenticate(
  username: string,
  password: string
): Promise<AuthResult> {
  // ...
}
```

### 4. Implement Incrementally

Write code in small steps:

1. **Start simple** - Get basic case working first
2. **Add error handling** - Handle edge cases
3. **Add logging** - Enable debugging
4. **Add validation** - Check inputs
5. **Refine** - Improve code quality

### 5. Follow Spec Exactly

Implement what was specified:

**From spec:**
```python
def authenticate_user(
    username: str,
    password: str,
    *,
    remember_me: bool = False
) -> AuthResult:
```

**Implementation:**
```python
def authenticate_user(
    username: str,
    password: str,
    *,
    remember_me: bool = False
) -> AuthResult:
    """Authenticate user with credentials."""

    # Validate inputs
    if not username:
        raise ValueError("Username cannot be empty")
    if not password:
        raise ValueError("Password cannot be empty")

    # Find user
    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise InvalidCredentialsError("Invalid username or password")

    # Check password
    if not verify_password(password, user.password_hash):
        log_failed_attempt(username)
        raise InvalidCredentialsError("Invalid username or password")

    # Generate token
    token_duration = timedelta(days=30 if remember_me else 1)
    token = generate_jwt_token(user, expires_in=token_duration)

    # Return result
    return AuthResult(
        token=token,
        user=user,
        expires_at=datetime.utcnow() + token_duration
    )
```

### 6. Add Observability

Enable debugging from the start:

```python
import logging

logger = logging.getLogger(__name__)

def authenticate_user(...) -> AuthResult:
    logger.debug(f"Authenticating user: {username}")

    # ... authentication logic ...

    logger.info(f"User {username} authenticated successfully")
    return result
```

### 7. Handle Errors Explicitly

No silent failures:

```python
# ✓ GOOD - Explicit error
if not user:
    raise InvalidCredentialsError("Invalid username or password")

# ✗ BAD - Silent failure
if not user:
    return None
```

### 8. Test As You Go

Verify each piece works:

```python
# Quick manual test
if __name__ == "__main__":
    result = authenticate_user("alice", "test123")
    print(f"Token: {result.token}")
```

Or run proper tests:
```bash
uv run pytest tests/test_auth.py::test_authenticate_user
```

### 9. Commit When Complete

Once the task works:

```bash
# Stage changes
git add src/auth/service.py

# Commit with convention
git commit -m "feat(sprint-05): Implement user authentication service"

# Add commit ID to plan
# In plan.md: - [x] Implement authentication service (commit: a1b2c3d)
```

## Outputs

- Working code that matches specification
- Code following project standards
- Observability (logging) included
- Error handling included
- Git commit
- Updated plan.md with commit ID

## Common Pitfalls

- **Deviating from spec** - Implementing something different than specified
- **No error handling** - Only coding happy path
- **No logging** - Making code impossible to debug
- **Violating standards** - Ignoring project CLAUDE.md conventions
- **Over-engineering** - Adding features not in spec
- **Under-engineering** - Skipping edge cases or validation
- **No testing** - Not verifying code works
- **Vague commits** - Commit messages that don't describe what changed

## Validation

Implementation is complete when:

- ✓ Code matches specification
- ✓ All edge cases handled
- ✓ Error handling included
- ✓ Logging added for debugging
- ✓ Code follows project standards
- ✓ Manual test passes (or tests pass)
- ✓ Changes committed
- ✓ Plan.md updated with commit ID

## Integration with Work Modes

**During sprint implementation:**
1. Check plan.md for next task
2. Mark task in progress
3. Implement following spec
4. Test implementation
5. Commit changes
6. Update plan.md with commit ID
7. Move to next task

**If implementation reveals issues:**
- Design flaw → Cycle back to Design section
- Unclear spec → Update Spec section
- Missing research → Add to Research section
- Document in Notes section

## Tips

- **Read CLAUDE.md first** - Every project has specific standards
- **Follow existing patterns** - Look for similar code in codebase
- **Start with types/interfaces** - Define data structures first
- **Add logging liberally** - Future you will thank present you
- **Test edge cases** - Empty inputs, null values, concurrent access
- **Keep commits focused** - One task = one commit
- **Update plan immediately** - Don't batch commit IDs
- **Ask for help** - If stuck >2 hours, document blocker and ask

## ABSOLUTE PROHIBITIONS

**NEVER create:**
- ✗ Mocks (fake objects pretending to be real)
- ✗ Stubs (hardcoded return values)
- ✗ Placeholders (temporary "TODO" implementations)
- ✗ Fallbacks (return fake data when real implementation fails)

**Example violations:**
```python
# ✗ WRONG - Stub/Mock/Placeholder
def get_user_data(user_id: int) -> dict:
    return {"id": 1, "name": "Test User"}  # Fake data!

# ✓ CORRECT - Real implementation or explicit failure
def get_user_data(user_id: int) -> dict:
    user = db.query(User).get(user_id)
    if not user:
        raise UserNotFoundError(f"User {user_id} not found")
    return user.to_dict()

# ✓ ALSO CORRECT - Not implemented yet
def get_user_data(user_id: int) -> dict:
    raise NotImplementedError("User data fetching not yet implemented")
```

**Always:**
- ✓ Implement the real thing OR
- ✓ Fail explicitly with clear error message
- ✓ If you cannot implement, say so - DO NOT FAKE IT

## Debugging During Implementation

If code doesn't work:

1. **Check logs** - Did you add logging? What do they say?
2. **Verify inputs** - Are inputs what you expect?
3. **Isolate problem** - Test component standalone
4. **Read error messages** - Fully, carefully
5. **Check assumptions** - Are specs/design correct?

See `templates/tasks/debug.md` for systematic debugging approach.
