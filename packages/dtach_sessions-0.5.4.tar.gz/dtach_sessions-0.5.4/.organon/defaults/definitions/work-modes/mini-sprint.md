# Mini Sprint Work Mode

## Objective

Execute medium-complexity work with persistent tracking in a single document. Bigger than ad hoc (needs planning, spans multiple conversations or steps), smaller than a full sprint (doesn't need separate phase docs or formal planning passes).

## When to Use

- Work has multiple steps that benefit from a written plan
- Thinking/research needs to be captured (not just the final commit)
- Work may span multiple conversations or context clears
- Complexity or depth warrants a persistent artifact beyond git commits
- But: doesn't need separate requirements/research/architecture/spec files
- But: doesn't need MCP-tracked sprint lifecycle or numbered sequencing

**Don't use for:**
- Simple, contained changes (use ad hoc)
- Work requiring architectural decisions across multiple systems (use full sprint)
- Work where three-pass planning and formal review add value (use full sprint)

## How It Works

### Starting a Mini Sprint

1. Create the file: `.organon/mini-sprints/{descriptive-slug}.md`
2. Use the template: `.organon/defaults/templates/files/sprints/mini-sprint.md.template`
3. Fill in Description — what we're doing and why (2-5 sentences)
4. Fill in as much Thinking and Plan as you have at the start

### Working a Mini Sprint

- **Thinking section** captures research, design decisions, and rationale as you go. Write it progressively — add findings as you discover them, not all upfront.
- **Plan section** is a simple checklist. Update it as tasks complete. Add tasks if scope grows.
- **Log section** captures decisions, blockers, and notes chronologically. Prefix entries with the date.
- Read and update the file at the start of each conversation that continues the work.
- Commit the mini sprint file alongside code changes.

### Completing a Mini Sprint

1. All plan tasks checked off
2. Update status to `Completed` in the header
3. Final commit includes the completed mini sprint doc

## Typical Flow

```
Create doc → fill description + initial thinking → write plan →
  execute tasks (updating doc as you go) → mark complete
```

## Escalate to Full Sprint When

- Plan grows beyond ~10 tasks
- Multiple independent workstreams emerge that need parallel tracking
- Architectural decisions need formal specification
- Work affects specs that need overlay YAML authored via `/plan-sprint`

## Constraints

- One file per mini sprint — all thinking, planning, and notes in one place
- No MCP sprint tools needed (no create_sprint, no update_task_status)
- No sprint number assignment
- Commit format: use standard non-sprint prefixes (`feat:`, `refactor:`, etc.)
- The mini sprint doc is the persistent artifact — keep it updated
