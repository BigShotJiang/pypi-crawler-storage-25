# Ad-Hoc Task Workflow

## Objective

Execute quick, standalone work (< 2 hours) without sprint structure.

## Available Tasks

- **implement** - Write code
- **fix** - Bug fix
- **update** - Documentation/dependency update
- **refactor** - Quick structural improvement

## Typical Flow

```
(quick analysis) → implement → test → commit
```

## When to Use

- Bug fixes (< 1 hour)
- Documentation updates
- Dependency updates
- Simple feature additions
- Configuration changes
- Formatting/linting fixes

**Don't use for:**
- Work requiring significant planning
- Architectural changes
- Multi-component features
- Anything > 2 hours

## Constraints

- No sprint documentation needed
- Git commit is the documentation
- Test appropriately (manual often sufficient)
- Use commit conventions (bugfix:, docs:, chore:, refactor:, feat:)

## Escalate to Mini Sprint When

- Work has multiple steps that benefit from a written plan
- Thinking/research needs to be captured beyond git commits
- Work may span multiple conversations
- But doesn't need formal sprint planning phases

→ `defaults/definitions/work-modes/mini-sprint.md`

## Escalate to Full Sprint When

- Need architectural decisions across multiple systems
- Work requires separate research/design/spec phases
- Multiple independent workstreams need parallel tracking

## Commit Conventions

```bash
bugfix: Fix null pointer in authentication handler
docs: Update installation instructions in README
chore: Update Python dependencies to latest versions
refactor: Simplify error handling in API client
feat: Add --verbose flag to CLI
```
