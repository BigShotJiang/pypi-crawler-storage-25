# Sprint Planning Work Mode

## Objective

Create structured implementation plan through iterative research, design, and specification. Produces plan.md with explicit file operations, dependencies, and metadata enabling sub-agent orchestration and parallel execution.

## Entry Point: Conversational Kickoff

Sprint planning begins conversationally. The agent captures the user's intent, scope, and constraints from conversation context, then creates the sprint:
1. Creates the sprint via `create_sprint(name, status="Created")`
2. Writes `kickoff.md` to the sprint directory — a concise summary of what was discussed and decided
3. Sets up the sprint directory structure

After kickoff, the planning workflow proceeds through research and specification phases, then three planning passes via `/plan-sprint`.

## Planning Workflow Sequence

0. **Read Project Docs** - Before writing any sprint docs, read the project's existing documentation:
   - `CLAUDE.md` — understand project conventions, architecture pointers, and navigation
   - `docs/` — read relevant specs, design docs, and developer guides
   - `STRUCTURE.md` — understand file organization
   - This ensures sprint docs build on (not duplicate or contradict) existing knowledge
   - Sprint specs should be written as **overlays** that extend project-level docs, not standalone rewrites
1. **Requirements** (requirements.md) - Define stakeholder needs and success criteria
2. **Research** (research.md) - Investigate technical landscape and existing patterns
3. **Design** (design.md) - OPTIONAL: UI/UX decisions (skip for non-UI work)
4. **Architecture** (architecture.md) - Define structure and module organization
5. **Specification** (spec.md) - Define contracts and interfaces (NOT implementation)
6. **Plan** (plan.md) - Three-pass planning via subagent skills (see below)
7. **Plan Review** - Validate plan for conflicts and completeness (required before execution)

Call `update_workflow_context` MCP tool every interaction to track progress.

Iterative: cycle between phases as you discover new information.

## Document Sizing Principle

**5-minute read test:** Can someone read and understand this document in 5 minutes?

If no, either:
1. The sprint is too large (split it)
2. You're over-documenting (focus on decisions, not descriptions)

**No lower bound.** Brevity is clarity. No architectural changes? Say so in a few lines.

**Anti-patterns:**
- Describing existing systems instead of new decisions
- Repeating content from previous phases
- Filling space to meet imagined requirements

This applies to all planning documents: requirements, research, design, architecture, spec.

## Format

Tasks with explicit file operations, dependencies, and metadata in a phase-task hierarchy.
- Template: `defaults/templates/files/sprints/plan.md`

**Example:**
```markdown
### Phase 1: Setup

**Status:** pending
**Dependencies:** none

#### Task 1.1: Create project structure

- **Type:** implement
- **Status:** pending
- **Dependencies:** none
- **Files:**
  - Create: src/__init__.py
  - Create: tests/__init__.py
- **Context:** spec.md#project-structure
- **Description:** Initialize Python package structure
- **Commit:**

#### Task 1.2: Add configuration

- **Type:** implement
- **Status:** pending
- **Dependencies:** [1.1]
- **Files:**
  - Create: src/config.py
  - Modify: src/__init__.py
- **Context:** spec.md#configuration
- **Description:** Configuration management system
- **Commit:**
```

## Documentation Format

All sprints use directory structure:
```
.organon/sprints/NN_Name_Current/
  kickoff.md
  requirements.md
  research.md
  design.md
  architecture.md
  spec.md
  plan.md
```

## Agent Workflow Checklist

### Before Finalizing Any Planning Document
- [ ] Does length match actual complexity/changes?
- [ ] Did I avoid documenting existing systems in detail?
- [ ] Passes 5-minute read test? (Can someone understand in 5 minutes?)
- [ ] Focused on decisions, not documentation?

## Three-Pass Planning via `/plan-sprint`

The three planning passes are implemented as passes within `/plan-sprint`, designed for **subagent invocation**. Each pass runs in a fresh subagent with clean context, reads the sprint documents it needs, produces its output, and returns. The parent agent reviews each result before proceeding.

This pattern keeps each pass focused: the subagent loads only the pass instructions and sprint docs, avoiding context pollution from the broader conversation.

### Pass 1: Structure Planning

**Invocation:** Parent launches subagent → subagent invokes Pass 1 of `/plan-sprint` → returns phase structure for review

**Goal:** Organize work into logical phases with high-level tasks

**Process:**
1. Review requirements.md, research.md, design.md, architecture.md, spec.md
2. Identify major logical work units (phases)
3. For each phase:
   - Write clear phase name and goal
   - Estimate time
   - List high-level tasks
   - Tag task types needed (implement, test, document, etc.)
   - Identify phase dependencies
4. Review phases for completeness and logical flow

**Output:** Phase structure with high-level tasks

**Parent review:** Confirm phase breakdown makes sense, adjust scope if needed, then proceed to Pass 2.

### Pass 2: Detail Planning

**Invocation:** Parent launches subagent → subagent invokes Pass 2 of `/plan-sprint` → returns full plan

**Goal:** Expand high-level tasks into structured tasks with explicit metadata

**Process:**
1. Collect all unique task types from Pass 1
2. Load corresponding planning rules from `defaults/definitions/workflows/`
3. For each high-level task, create structured task entry with metadata:
   - **Task ID:** Phase.Task format (1.1, 1.2, 2.1, ...)
   - **Type:** implement | test | document | research | design | etc.
   - **Status:** pending (all tasks start as pending)
   - **Dependencies:** Task IDs [1.1, 1.2] or Phase IDs [Phase 1] or "none"
   - **Files:** Explicit file operations (Create/Modify/Delete with paths)
   - **Context:** References to spec.md, design.md sections
   - **Description:** Brief task description (what this accomplishes)
   - **Commit:** Empty (populated during execution)

**Key principles:**
- Be explicit: Specify exact file paths and operations
- Use action verbs in Files section: Create, Modify, Delete
- Include all discipline steps: code → tests → docs
- Think dependencies: create files before importing
- One task = one commit boundary
- Mark tasks that can run in parallel (no dependencies)

**Output:** Complete plan.md with explicit, actionable tasks and metadata

**Parent review:** Confirm task granularity, file operations, and dependencies before proceeding to Pass 3.

**Example expansion:**
```markdown
### Phase 1: Core Implementation

**Status:** pending
**Dependencies:** none

#### Task 1.1: Create TemplateMetadata class

- **Type:** implement
- **Status:** pending
- **Dependencies:** none
- **Files:**
  - Create: src/organon/templates/__init__.py
  - Create: src/organon/templates/metadata.py
- **Context:** spec.md#metadata-extraction
- **Description:** Implement TemplateMetadata class for loading and querying template metadata
- **Commit:**

#### Task 1.2: Add metadata tests

- **Type:** test
- **Status:** pending
- **Dependencies:** [1.1]
- **Files:**
  - Create: tests/test_template_metadata.py
- **Context:** spec.md#validation
- **Description:** Unit tests for TemplateMetadata class
- **Commit:**

#### Task 1.3: Document metadata API

- **Type:** document
- **Status:** pending
- **Dependencies:** [1.1]
- **Files:**
  - Modify: .organon/defaults/docs/reference/templates.md
- **Context:** design.md#api-documentation
- **Description:** Add TemplateMetadata API documentation with examples
- **Commit:**
```

### Pass 3: Review & Refinement **REQUIRED**

**Invocation:** Parent launches subagent → subagent invokes Pass 3 of `/plan-sprint` → returns reviewed plan

**Goal:** Validate plan for conflicts, dependencies, completeness, and template compliance

**Process:**
1. **Template compliance check (CRITICAL):**
   - Read template: `defaults/templates/files/sprints/plan.md`
   - Verify plan structure matches template EXACTLY:
     - Required sections exist: `## Overview`, `## Workflow`, `## Tasks`, `## Completion Criteria`
     - Correct heading hierarchy:
       - `## Tasks` (parent section)
       - `### Phase N: Name` (under Tasks)
       - `#### Task N.M: Title` (under Phases)
     - Completion Criteria has `[ ]` checkboxes for tracking
   - Fix any structural violations before proceeding

2. Read `defaults/definitions/workflows/plan-review.md` for systematic checklist

3. Run all review checks:
   - File operations (no conflicts, no duplicates)
   - Test coverage (all code has tests)
   - Documentation (all changes documented)
   - Dependencies (correct phase/task order, no circular deps)
   - Commit boundaries (atomic, testable commits)
   - Completeness (no missing files)
   - Scope (estimates still realistic)
   - Format validation (frontmatter, task IDs, required fields)

4. Fix any issues found

5. Mark plan as reviewed

**Output:** Validated, conflict-free plan matching template structure, ready for execution

**Parent review:** Confirm review findings are addressed, then transition to execution.

## Subagent Invocation Pattern

The three passes of `/plan-sprint` are designed for subagent invocation. The pattern:

```
Parent conversation (has full user context)
  |
  |-- launches subagent: "Invoke Pass 1 of /plan-sprint for sprint X"
  |     Subagent loads pass instructions, reads sprint docs, writes output, returns
  |     Parent reviews output with user
  |
  |-- launches subagent: "Invoke Pass 2 of /plan-sprint for sprint X"
  |     Subagent loads pass instructions, reads phase structure + sprint docs, writes plan.md, returns
  |     Parent reviews output with user
  |
  |-- launches subagent: "Invoke Pass 3 of /plan-sprint for sprint X"
  |     Subagent loads pass instructions, reads plan.md, validates, fixes issues, returns
  |     Parent reviews output with user
  |
  v
  Transition to sprint execution
```

**Why subagents:** Each pass gets clean context with only the pass instructions and sprint documents. This avoids context pollution from the broader planning conversation, which can be lengthy after research and specification phases. The parent retains full conversation context for user interaction and review.

## When to Cycle Back

Return to earlier tasks when:

- **Back to research:** Implementation reveals unknown behavior, assumptions incorrect
- **Back to design:** Chosen approach doesn't work, new requirements discovered
- **Back to spec:** API contracts need adjustment, edge cases discovered

Document cycles in Notes section.

## Transition to Execution

Move to sprint-execution work mode when:
- plan.md has structured hierarchy with complete task metadata
- Plan passed review (Pass 3 of `/plan-sprint` complete)
- All file operations explicit and validated
- All task metadata complete (Type, Dependencies, Files, Context)

## Sprint Numbering

Format: `NN_Name_Status`
- **NN**: Sequential number assigned when sprint STARTS (not created)
- **Name**: CamelCase description
- **Status**: Created | Next | Current | Completed | Paused

Lifecycle:
1. Create: `Name_Created` (no number yet) — via conversational kickoff + `create_sprint()`
2. Queue: `Name_Next` (queued but not started)
3. Start: `NN_Name_Current` (assign number when work begins)
4. Complete: `NN_Name_Completed`

## Commit Conventions

```bash
docs(sprint-NN): Complete research phase
docs(sprint-NN): Design architecture decisions
docs(sprint-NN): Define API specifications
docs(sprint-NN): Create implementation plan
```

During execution, commits tracked as:
```markdown
- **Commit:** a1b2c3d
```

## Orchestration

Detailed plans enable sub-agent orchestration:
- Parser extracts phases and tasks with metadata
- Dependency resolver determines execution order
- Orchestrator launches sub-agents for parallel task execution
- Progress tracker updates status and commit hashes

**See:** `.organon/defaults/docs/user-guide/orchestration.md` for complete orchestration guide

## See Also

- `sprint-execution.md` - Execute sprints
- `.organon/defaults/docs/user-guide/sprints.md` - Complete sprint lifecycle guide
- `.organon/defaults/docs/user-guide/orchestration.md` - Orchestration system guide
- `defaults/templates/files/sprints/plan.md` - Plan template
- `defaults/definitions/workflows/plan-review.md` - Plan review checklist
