# Conversation Workflow

## Objective

Default workflow for exploratory discussion, planning, and clarification when not actively executing sprint or one-off work.

## Available Tasks

- **discuss-approach** - Exploring options, evaluating trade-offs
- **clarify-requirements** - Understanding what's needed
- **answer-question** - Providing information about code/docs/concepts
- **analyze-code** - Reading and explaining existing code

## Constraints

- Keep responses concise (1-3 paragraphs unless detail requested)
- Ask clarifying questions when intent unclear
- Map to concrete workflow (sprint/one-off) when work begins
- No implementation unless explicitly requested
- No task tracking needed (no TodoWrite)

## Typical Flow

```
User question → Identify task → Provide concise answer → Map to workflow if work emerges
```

## When to Transition

**Move to ad-hoc workflow when:**
- Quick implementation requested (< 2 hours)
- Single file change
- Simple bug fix or docs update

**Move to mini sprint when:**
- Work has multiple steps that benefit from a plan
- Thinking needs to persist across conversations
- More than ad hoc, less than full sprint ceremony

**Move to full sprint when:**
- Work requires formal planning (research/design/spec phases)
- Multiple components affected with complex dependencies
- Architectural decisions needed

## Examples

**discuss-approach:**
- "Should we use workflow A or B for this feature?"
- "What are the trade-offs of this design?"

**clarify-requirements:**
- "What exactly should this function do?"
- "Do you want X or Y behavior?"

**answer-question:**
- "What does this code do?"
- "Where is feature X implemented?"

**analyze-code:**
- "Explain how the validator works"
- "Show me the workflow loading logic"
