# Sprint Execution Work Mode

## Objective

Execute validated implementation plan from sprint-planning work mode manually, task-by-task. Follow structured plan, track commits, and update documentation.

## Available Tasks

- **implement** - Write code following the plan
- **test** - Verify behavior, write tests, run validation
- **review** - Check quality, adherence to standards, code review
- **document** - Update documentation, README, CLAUDE.md, STRUCTURE.md
- **debug** - Systematically debug issues discovered during implementation
- **refactor** - Improve code structure while maintaining behavior

## Typical Flow

```
Parse Plan → Execute Phase 1 → Execute Phase 2 → ... → Complete Sprint
```

Within each phase: Execute tasks sequentially or in parallel where dependencies allow.

## Prerequisites

- Completed sprint-planning work mode
- plan.md exists with structured task hierarchy
- Plan passed review (three-pass planning complete)
- All file operations explicit and ready to execute
- All task metadata complete (Type, Status, Dependencies, Files, Context)

## Documentation Format

Work from plan.md in sprint directory:
```
.organon/sprints/NN_Name_Current/
  requirements.md
  research.md
  design.md (optional for non-UI work)
  architecture.md
  spec.md
  plan.md
```

Template: `.organon/defaults/templates/files/sprints/plan.md`

## Manual Execution Process

### 1. Parse Plan

Use `parse_sprint_plan` MCP tool to understand the task structure:
- Extracts phases with dependencies
- Extracts tasks with metadata (Type, Status, Dependencies, Files, Context, Description)
- Shows task relationships

```python
parse_sprint_plan(sprint_path: str) -> SprintPlan
```

### 2. Get Executable Tasks

Use `get_executable_tasks` to find tasks ready to execute:
- Returns tasks with all dependencies satisfied
- Respects phase boundaries (Phase N must complete before Phase N+1)
- Can filter by specific phase

```python
get_executable_tasks(sprint_path: str, phase_id: int = None) -> List[Task]
```

### 3. Execute Tasks Using Subagents

**ALWAYS use subagents for task execution.** Launch tasks in parallel when dependencies allow.

For each task or group of parallel tasks:

1. **Identify executable tasks**
   - Use `get_executable_tasks` to find tasks with satisfied dependencies
   - Group tasks with no mutual dependencies for parallel execution

2. **Launch subagent(s)**
   - Use Task tool with `subagent_type="general-purpose"` (or appropriate specialized type)
   - For parallel execution: Launch multiple Task tools in single message
   - Pass task details in prompt:
     - Task ID and description
     - Files to create/modify (from task metadata)
     - Context references to read (spec.md, architecture.md sections)
     - Workflow to follow (`.organon/defaults/definitions/workflows/{task_type}.md`)

3. **Subagent executes work**
   - Reads referenced sprint docs for context
   - Follows workflow definition for task type
   - Performs file operations (Create/Modify/Delete)
   - Tests implementation
   - Reports completion back to you

4. **Update task status**
   ```python
   update_task_status(sprint_path: str, task_id: str, status: str, commit: str = None)
   ```
   - Status: `pending` → `in_progress` → `completed` | `failed`
   - Commit hash added when phase completes

5. **Continue until phase complete**
   - After phase tasks complete, create ONE commit for entire phase
   - Update phase-level commit hash in plan.md
   - Move to next phase

### Task Completion Requirements

Before declaring any task complete:
1. Implement the work
2. Test the implementation
3. Commit the changes
4. Update task status with `update_task_status` MCP tool
5. THEN move to next task

Never skip status updates or commit documentation.

## Working Through Tasks

**Example flow for Phase 1 with parallel task execution:**

```markdown
1. Get all executable tasks in Phase 1:
   get_executable_tasks(".organon/sprints/17_Auth_Current", phase_id=1)
   → Returns tasks 1.1, 1.2, 1.3 (1.1 and 1.3 have no dependencies, 1.2 depends on 1.1)

2. Launch parallel subagents for independent tasks (1.1 and 1.3):
   - Task tool #1: Execute task 1.1 (Create src/auth/user.py)
   - Task tool #2: Execute task 1.3 (Create src/auth/utils.py)
   - Both read their context sections and workflow definitions
   - Both implement, test, and report back

3. Update status for completed tasks:
   update_task_status(".organon/sprints/17_Auth_Current", "1.1", "completed")
   update_task_status(".organon/sprints/17_Auth_Current", "1.3", "completed")

4. Launch subagent for task 1.2 (dependency 1.1 now satisfied):
   - Task tool: Execute task 1.2 (Modify src/main.py)
   - Reads context and implements

5. Update status:
   update_task_status(".organon/sprints/17_Auth_Current", "1.2", "completed")

6. Phase 1 complete - Create single commit:
   git commit -m "feat(sprint-17): Complete Phase 1 - User authentication foundation"

7. Update phase commit hash in plan.md

8. Move to Phase 2:
   get_executable_tasks(".organon/sprints/17_Auth_Current", phase_id=2)
```

## MCP Tools Reference

### parse_sprint_plan
Parse structured plan.md into SprintPlan with phases and tasks.
```python
parse_sprint_plan(sprint_path: str) -> SprintPlan
```

### get_executable_tasks
Get tasks ready to execute (dependencies satisfied).
```python
get_executable_tasks(sprint_path: str, phase_id: int = None) -> List[Task]
```

### update_task_status
Update task status and commit hash in plan.md.
```python
update_task_status(sprint_path: str, task_id: str, status: str, commit: str = None) -> None
```

### get_sprint_section
Extract specific section from sprint document.
```python
get_sprint_section(sprint_path: str, file: str, section: str) -> str
```

## Tips for Efficient Execution

1. **Always use subagents** - Launch Task tool for ALL task execution
2. **Maximize parallelism** - Launch multiple subagents in single message when dependencies allow
3. **Read sprint docs first** - requirements.md, research.md, design.md, spec.md give full context
4. **Follow task metadata** - Files, Context, and Description tell subagents exactly what to do
5. **Use workflow definitions** - Each task type has a workflow guide in `.organon/defaults/definitions/workflows/`
6. **Test before completing phase** - Verify all phase tasks work before creating phase commit
7. **Update status immediately** - Update task status after each subagent completes
8. **Check dependencies** - Use `get_executable_tasks` to find what's ready for parallel execution
9. **Phase-level commits** - One commit per phase, not per task

## Sprint Completion: Update Project Docs

After all phases are complete and before marking the sprint as Completed:

1. **Merge sprint docs into project docs** — Sprint specs are overlays on project-level documentation. Merge relevant content:
   - Update `CLAUDE.md` if the sprint introduced new conventions, file locations, or navigation entries
   - Update `STRUCTURE.md` if new directories or key files were added
   - Update `docs/` specs and guides if the sprint extended or changed documented behavior
   - Update `.organon/defaults/docs/developer-guide/` if new patterns or standards were established

2. **Run `/sync-docs-with-specs`** (if available) — Validate that project docs are consistent with specs after merging

3. **Final commit** — Commit doc updates separately:
   ```bash
   docs(sprint-NN): Merge sprint docs into project documentation
   ```

4. **Mark sprint complete** — Update sprint status to Completed

**Key principle:** Sprint knowledge should not be trapped in sprint directories. After completion, the project docs should be the single source of truth.

## Critical Reminders

- **Always use subagents** - Use Task tool with appropriate subagent_type for ALL tasks
- **Parallel task processing** - Launch multiple subagents in parallel when tasks have no dependencies
- **Update status after every task** - Use `update_task_status` MCP tool
- **Phase-level commits** - One commit per phase containing all phase work, not per-task commits
- **Test before declaring complete** - Verify implementation works
- **Follow the plan** - Don't deviate from task specifications
- **Update project docs on completion** - Merge sprint knowledge into project-level documentation
