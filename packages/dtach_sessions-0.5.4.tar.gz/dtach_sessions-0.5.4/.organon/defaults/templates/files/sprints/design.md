---
validation:
  required_sections:
    - name: "## Summary"
      description: "High-level design approach overview"
      allow_empty: false
      order: 1
    - name: "## Architecture Overview"
      description: "High-level architecture description"
      allow_empty: false
      order: 2
    - name: "## Design Decisions"
      description: "Documented design decisions with rationale"
      allow_empty: false
      order: 3
    - name: "## Component Design"
      description: "Detailed component design"
      allow_empty: false
      order: 4
    - name: "## Integration Points"
      description: "System integration points"
      allow_empty: false
      order: 5
  optional_sections:
    - "### Decision 1"
    - "### Decision 2"
  content_patterns:
    - section: "## Summary"
      pattern: ".{{20,}}"
      description: "Summary must have content"
    - section: "## Architecture Overview"
      pattern: ".{{50,}}"
      description: "Architecture Overview must have substantial content"
    - section: "## Design Decisions"
      pattern: "###.*Decision|\\*\\*Context:\\*\\*|\\*\\*Decision:\\*\\*"
      description: "Design Decisions must document decisions with context"
# Sizing: Single approach? Brief rationale. Complex trade-offs? Detail each decision. 5-minute read test.
---
# Design: {name} (Optional - UI Only)

**Created:** {date}
**Started:** [Date when sprint execution begins - determines sprint number]
**Sprint:** {name} (number assigned when started)

**Note:** This phase is OPTIONAL. Only create this file if your sprint includes user interface work (visual design, layout, component selection). Skip for backend-only, infrastructure, or non-UI work.

## Summary

[1-3 sentence overview of UI design approach and key decisions]

## Dependencies

This phase depends on:
- [Requirements](requirements.md)
- [Research](research.md) (optional)

**Information needed from prior phases:**
- From [Requirements](requirements.md): User needs, interaction flows
- From [Research](research.md): Existing UI patterns in codebase

**Information provided to next phases:**
- To [Specification](spec.md): UI component APIs, prop specifications
- To [Plan](plan.md): UI implementation tasks

## Architecture Overview

[High-level architecture description]

This document is part of the Planning Level workflow:
Requirements → Research → Design (this document) → Architecture → Spec → Plan

## Design Decisions

### Decision 1: [Title]

**Context:** [Why this decision is needed]

**Options Considered:**
1. Option A - [pros/cons]
2. Option B - [pros/cons]

**Decision:** [Chosen option and rationale]

## Component Design

[Detailed design of major components]

## Integration Points

[How this integrates with existing systems]

---
Created: {date}
Sprint: {number:02d}_{name}
