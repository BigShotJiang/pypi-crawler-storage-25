---
validation:
  required_sections:
    - name: "## Summary"
      description: "High-level specification overview"
      allow_empty: false
      order: 1
    - name: "## Technical Specifications"
      description: "Concrete technical specifications"
      allow_empty: false
      order: 2
    - name: "## Validation Criteria"
      description: "How to verify implementation is correct"
      allow_empty: false
      order: 3
  optional_sections:
    - "### API/Interface Design"
    - "### Data Models"
    - "### Examples"
  content_patterns:
    - section: "## Summary"
      pattern: ".{{20,}}"
      description: "Summary must have content"
    - section: "## Technical Specifications"
      pattern: ".{{100,}}"
      description: "Technical Specifications must have detailed content"
    - section: "## Validation Criteria"
      pattern: ".{{20,}}"
      description: "Validation Criteria must specify how to verify implementation"
# Sizing: Detailed SPECIFICATIONS (signatures, schemas, contracts) - NOT implementations.
# Target: 300-500 lines. NEVER exceed 800 lines. Apply 5-minute read test.
# CRITICAL: Include function signatures, data schemas, API contracts, usage examples.
# NEVER: Include implementation code, logic, complete function bodies, helper functions.
---
# Specification: {name}

**Created:** {date}
**Started:** [Date when sprint execution begins - determines sprint number]
**Sprint:** {name} (number assigned when started)

## Summary

[1-3 sentence overview: what interfaces/contracts this spec defines, NOT how they're implemented]

This document is part of the Planning Level workflow:
Requirements → Research → Design → Architecture → Spec (this document) → Plan

## Dependencies

This phase depends on:
- [Requirements](requirements.md)
- [Research](research.md)
- [Architecture](architecture.md)

**Information needed from prior phases:**
- From [Requirements](requirements.md): Expected behaviors, validation rules, project docs affected
- From [Research](research.md): API conventions, data format standards
- From [Architecture](architecture.md): Component/module/class names, file locations

**IMPORTANT:** Before writing specs, read the existing project specs in `.organon/specs/`. This sprint's overlay specs must be consistent with and build upon them.

**Information provided to next phases:**
- To [Plan](plan.md): Specific APIs to implement, contracts to fulfill, overlay specs to merge
- Implementation contracts (what to build)

## Technical Specifications

### API/Interface Design

[Function signatures, class interfaces, method signatures - NO implementation code]

Example:
```python
def process_data(input: dict) -> Result:
    """Process input data and return result."""
    # Signature only - implementation goes in actual code
```

### Data Models

[Schema definitions, dataclass structures, validation rules - structure only, no logic]

Example:
```python
@dataclass
class User:
    id: int
    name: str
    email: str
    # Schema definition only
```

### Examples

[USAGE examples showing how to CALL the APIs - NOT how to implement them]

Example:
```python
# How to USE the API (correct)
result = process_data({"key": "value"})
print(result.status)

# NOT how to implement process_data() - that's implementation code
```

## Overlay Specs

List the overlay spec files this sprint will produce in the `specs/` subdirectory. These merge into `.organon/specs/` on sprint completion.

- [ ] `specs/[name].model.yaml` — [what entities/fields change]
- [ ] `specs/[name].contracts.yaml` — [what endpoints change]
- [ ] `specs/[name].states.yaml` — [what state machines change]

Use `/plan-sprint` to generate these from the technical specifications above.

## Validation Criteria

[How to verify the implementation is correct - test commands, assertions, expected behavior]

Example:
```bash
# Run this to verify
python -m pytest tests/test_feature.py
# Expected: All tests pass
```

---
Created: {date}
Sprint: {number:02d}_{name}
