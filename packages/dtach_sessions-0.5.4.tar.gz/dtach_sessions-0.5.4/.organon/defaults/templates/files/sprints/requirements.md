---
validation:
  required_sections:
    - name: "## Summary"
      description: "High-level what/why overview"
      allow_empty: false
      order: 1
    - name: "## Goals"
      description: "What we're trying to accomplish"
      allow_empty: false
      order: 2
    - name: "## Features"
      description: "Specific features to implement"
      allow_empty: false
      order: 3
    - name: "## Success Criteria"
      description: "How we know we're done"
      allow_empty: false
      order: 4
    - name: "## Project Documentation Impact"
      description: "Which project-level docs this sprint affects"
      allow_empty: false
      order: 5
    - name: "## Scope"
      description: "What's in/out of scope"
      allow_empty: false
      order: 6
# Sizing: Write what's needed. 5-minute read test: Can someone understand the requirements in 5 minutes?
# No lower bound (brevity is good). Anti-pattern: Describing solutions instead of requirements.
---
# Requirements: [Sprint Name]

**Created:** [Date]
**Sprint:** [SprintID]

## Summary
[1-3 sentence overview of what this sprint accomplishes]

## Dependencies

This phase depends on:
- None (first phase in planning sequence)

**Information needed from prior phases:**
- User requests
- Stakeholder needs
- Business goals

**Information provided to next phases:**
- To [Research](research.md): Features to investigate, constraints to validate
- To [Architecture](architecture.md): NFR targets (performance, security, scalability)
- To [Specification](spec.md): Expected behaviors and validation rules
- To [Plan](plan.md): Scope boundaries

## Goals
### Primary Goal
[Main objective]

### Secondary Goals
[Supporting objectives by feature area]

## Features
### Feature 1: [Name]
**What:** [Brief description]
**Sections/Details:** [Key aspects]
**Integration:** [How it fits with existing system]

[Repeat for each feature]

## Success Criteria
### For Feature 1
- [ ] [Specific measurable criterion]
[Repeat per feature]

## Project Documentation Impact

Identify which project-level documents this sprint will affect. Read each before planning.

### Project Specs Affected
- [ ] `.organon/specs/` — List specific spec files that will change or be created
  - [e.g., `identity.model.yaml` — new fields, `api.contracts.yaml` — new endpoints]

### CLAUDE.md Sections Affected
- [ ] Architecture / service descriptions
- [ ] Directory map / file locations
- [ ] Tech stack / dependencies
- [ ] Scripts / commands
- [ ] Other: [specify]

### Other Project Docs
- [ ] `README.md` — [what changes]
- [ ] `docs/design/` — [what changes]
- [ ] Other: [specify]

## Scope
### In Scope
**Must Have:** [Core deliverables]
**Should Have:** [Important but not blocking]

### Out of Scope
[Explicitly excluded items]

### Open Questions
[Questions to resolve during planning]
