---
validation:
  required_sections:
    - name: "## Summary"
      description: "High-level research findings overview"
      allow_empty: false
      order: 1
    - name: "## Problem Statement"
      description: "Description of the problem being solved"
      allow_empty: false
      order: 2
    - name: "## Investigation"
      description: "Research findings and context"
      allow_empty: false
      order: 3
    - name: "## Findings"
      description: "Key insights and conclusions"
      allow_empty: false
      order: 4
    - name: "## Open Questions"
      description: "Questions for design phase"
      allow_empty: true
      order: 5
    - name: "## Next Steps"
      description: "Workflow progression notes"
      allow_empty: false
      order: 6
  optional_sections:
    - "### Existing Code Review"
    - "### Constraints and Requirements"
    - "### Related Work"
  content_patterns:
    - section: "## Summary"
      pattern: ".{{20,}}"
      description: "Summary must have content"
    - section: "## Problem Statement"
      pattern: "\\[.+\\]|\\w{{10,}}"
      description: "Problem Statement must have content (not just placeholder)"
    - section: "## Investigation"
      pattern: ".{{50,}}"
      description: "Investigation must document findings"
    - section: "## Findings"
      pattern: ".{{20,}}"
      description: "Findings must summarize insights"
# Sizing: 5-minute read test. Focus on findings, not exhaustive documentation.
---
# Research: {name}

**Created:** {date}
**Started:** [Date when sprint execution begins - determines sprint number]
**Sprint:** {name} (number assigned when started)

## Summary

[1-3 sentence overview of research findings and key insights]

## Dependencies

This phase depends on:
- [Requirements](requirements.md)

**Information needed from prior phases:**
- From [Requirements](requirements.md): Features to investigate, scope boundaries

**Information provided to next phases:**
- To [Architecture](architecture.md): Existing patterns, technical constraints, similar implementations
- To [Specification](spec.md): API conventions, data format standards
- To all phases: Technical backing information for decisions

## Problem Statement

[Describe the problem this sprint addresses]

## Investigation

[Document research findings, existing code analysis, and context]

### Existing Code Review

[What patterns, code, or systems are relevant?]

### Constraints and Requirements

[What limitations or requirements exist?]

### Related Work

[Similar features or patterns in the codebase]

## Findings

[Summarize key insights and conclusions]

## Open Questions

[Questions that need to be addressed in design phase]

## Next Steps

This is part of the Planning Level workflow:
- Requirements → Research (this document) → Design → Architecture → Spec → Plan → Implementation

See requirements.md for scope, design.md for approach, architecture.md for structure, and spec.md for technical specifications.

---
Created: {date}
Sprint: {number:02d}_{name}
