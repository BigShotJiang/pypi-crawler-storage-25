---
validation:
  required_sections:
    - name: "## Overview"
      description: "Brief description of implementation"
      allow_empty: false
      order: 1
    - name: "## Workflow"
      description: "Workflow-task model reference"
      allow_empty: false
      order: 2
    - name: "## Tasks"
      description: "Structured phase-task hierarchy"
      allow_empty: false
      order: 3
    - name: "## Completion Criteria"
      description: "Sprint completion requirements"
      allow_empty: false
      order: 4
  optional_sections:
    - "## Commit Conventions"
    - "## Notes"
  content_patterns:
    - section: "## Tasks"
      pattern: "### Phase \\d+:"
      description: "Tasks must be organized into phases"
    - section: "## Tasks"
      pattern: "#### Task \\d+\\.\\d+:"
      description: "Tasks must use hierarchical ID format (Phase.Task)"
---
# Implementation Plan: {name}

**Created:** {date}
**Started:** [Date when sprint execution begins - determines sprint number]
**Sprint:** {name} (number assigned when started)

## Overview

[Brief description of what will be implemented. This should be a concise summary of the sprint goals and deliverables.]

## Workflow

This sprint follows the workflow-task model:
- Planning Level: Research → Design → Spec → Plan (this document)
- Development Level: Implement → Test → Review → Document

## Tasks

### Phase 1: Foundation

**Status:** pending
**Dependencies:** none

#### Task 1.1: Example Foundation Task

- **Type:** implement
- **Status:** pending
- **Dependencies:** none
- **Files:**
  - Create: src/example/module.py
- **Context:** [spec.md§Data Models](spec.md#data-models), [design.md§Architecture](design.md#architecture)
- **Description:** Brief description of what this task accomplishes
- **Commit:**

#### Task 1.2: Another Foundation Task

- **Type:** implement
- **Status:** pending
- **Dependencies:** [1.1]
- **Files:**
  - Modify: src/example/module.py
- **Context:** [spec.md§API Design](spec.md#api-design)
- **Description:** Brief description building on task 1.1
- **Commit:**

### Phase 2: Core Implementation

**Status:** pending
**Dependencies:** [Phase 1]

#### Task 2.1: Core Feature

- **Type:** implement
- **Status:** pending
- **Dependencies:** [1.1, 1.2]
- **Files:**
  - Create: src/example/feature.py
- **Context:** [spec.md§Core Functionality](spec.md#core-functionality)
- **Description:** Implement main feature functionality
- **Commit:**

#### Task 2.2: Integration

- **Type:** implement
- **Status:** pending
- **Dependencies:** [2.1]
- **Files:**
  - Modify: src/example/main.py
- **Context:** [design.md§Integration Points](design.md#integration-points)
- **Description:** Integrate feature with existing system
- **Commit:**

### Phase 3: Testing

**Status:** pending
**Dependencies:** [Phase 2]

#### Task 3.1: Unit Tests

- **Type:** test
- **Status:** pending
- **Dependencies:** [2.1]
- **Files:**
  - Create: tests/example/test_feature.py
- **Context:** [spec.md§Validation Requirements](spec.md#validation-requirements)
- **Description:** Unit tests for core feature
- **Commit:**

#### Task 3.2: Integration Tests

- **Type:** test
- **Status:** pending
- **Dependencies:** [2.2, 3.1]
- **Files:**
  - Create: tests/example/test_integration.py
- **Context:** [spec.md§Integration Validation](spec.md#integration-validation)
- **Description:** End-to-end integration tests
- **Commit:**

### Phase 4: Documentation

**Status:** pending
**Dependencies:** [Phase 3]

#### Task 4.1: Code Documentation

- **Type:** document
- **Status:** pending
- **Dependencies:** [2.1, 2.2]
- **Files:**
  - Modify: src/example/feature.py
  - Modify: src/example/module.py
- **Context:** none
- **Description:** Add docstrings and inline comments
- **Commit:**

#### Task 4.2: User Guide

- **Type:** document
- **Status:** pending
- **Dependencies:** [4.1]
- **Files:**
  - Create: .organon/defaults/docs/user-guide/feature.md
- **Context:** none
- **Description:** User-facing documentation with examples
- **Commit:**

## Commit Conventions

Sprint work uses format: `feat(sprint-NN):`, `fix(sprint-NN):`, `docs(sprint-NN):`, `test(sprint-NN):`

Examples:
```bash
feat(sprint-NN): Implement feature X
fix(sprint-NN): Resolve issue in Y
docs(sprint-NN): Update documentation
test(sprint-NN): Add integration tests
```

## Completion Criteria

This sprint is complete when:

- [ ] All Phase 1-4 tasks checked off with commit hashes
- [ ] All tests passing (pytest with coverage)
- [ ] Code reviewed for quality and standards compliance
- [ ] Documentation complete (code docs and user guide)
- [ ] Sprint status updated to Completed

## Notes

**Task Format:**

- **Phase ID:** Integer (1, 2, 3, ...)
- **Task ID:** Phase.Task format (1.1, 1.2, 2.1, ...)
- **Type:** implement | test | document | research | design | specify | plan | debug | refactor | review
- **Status:** pending | in_progress | completed | failed
- **Dependencies:** Task IDs [1.1, 1.2] or Phase IDs [Phase 1] or "none"
- **Files:** Actions on files (Create/Modify/Delete with paths)
- **Context:** Proper markdown links to sprint docs, e.g., [spec.md§Section Name](spec.md#section-name)
- **Description:** Human-readable task description
- **Commit:** Git commit hash (populated after execution)

**Orchestration:**

This structured format enables sub-agent orchestration:
- Parser extracts phases and tasks with metadata
- Dependency resolver determines execution order
- Orchestrator launches sub-agents for parallel task execution
- Progress tracker updates status and commit hashes

**See:** `.organon/defaults/docs/user-guide/orchestration.md` for usage guide

---
Created: {date}
Sprint: {name}
