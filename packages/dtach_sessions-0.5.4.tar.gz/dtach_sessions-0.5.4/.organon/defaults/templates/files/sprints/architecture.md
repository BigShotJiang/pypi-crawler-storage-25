---
validation:
  required_sections:
    - name: "## Summary"
      description: "High-level architecture overview"
      allow_empty: false
      order: 1
    - name: "## Class Structure"
      description: "Class hierarchy and responsibilities"
      allow_empty: false
      order: 2
    - name: "## Module Organization"
      description: "File/module structure"
      allow_empty: false
      order: 3
    - name: "## Non-Functional Requirements"
      description: "NFRs and quality attributes"
      allow_empty: false
      order: 4
    - name: "## Scaffolding Plan"
      description: "Implementation scaffolding approach"
      allow_empty: false
      order: 5
    - name: "## Project Documentation Impact"
      description: "Changes needed to project-level design/architecture docs"
      allow_empty: false
      order: 6
# Sizing: No architectural changes? Brief statement (could be 10-20 lines total).
# Major structural changes? Detail the structure. 5-minute read test applies.
# Anti-pattern: Describing existing architecture instead of new decisions.
---
# Architecture: [Sprint Name]

**Created:** [Date]
**Sprint:** [SprintID]

## Summary
[Brief architecture overview - could be "No changes, uses existing X" or detailed structural description]

## Dependencies

This phase depends on:
- [Requirements](requirements.md)
- [Research](research.md)
- [Design](design.md) (if UI work)

**Information needed from prior phases:**
- From [Requirements](requirements.md): Features, NFRs (performance, security, scalability)
- From [Research](research.md): Existing patterns, technical constraints, project architecture
- From [Design](design.md): UI components (if UI work)

**Information provided to next phases:**
- To [Specification](spec.md): Component/module/class names, file locations
- To [Plan](plan.md): Implementation scaffolding order

## Class Structure
[New classes, responsibilities, relationships OR "No new classes"]

## Module Organization
**New files:** [List]
**Modified files:** [List]
[OR detailed module structure if complex]

## Non-Functional Requirements
[Performance, security, scalability requirements OR "Inherits from existing system"]

## Scaffolding Plan
[Implementation phases/order]

## Project Documentation Impact

**Review:** Consulted docs/design.md and docs/architecture.md (if exists)

**Impact:**
- docs/design.md: [Changes needed OR "No changes required"]
- docs/architecture.md: [Changes needed OR "No changes required"]
- Other docs: [List any other project docs that need updates]

**Reconciliation plan:** [When and how to update project docs - typically after implementation completes]
