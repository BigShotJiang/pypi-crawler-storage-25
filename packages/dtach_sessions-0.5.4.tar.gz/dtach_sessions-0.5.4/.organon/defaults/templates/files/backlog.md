# Project Backlog

Rough ideas and future work not yet scoped into sprints.

## Instructions

- Add items to Quick Reference with dual numbering format: `N. [#XXX] **Title**: Description`
- N = Ordinal position (1, 2, 3...) - renumbers when items move
- XXX = Immutable ID (001, 002, 003...) - never changes, assigned sequentially
- Add detailed descriptions in Details section (optional but recommended)
- When complete: Move to Completed section with format `- [#XXX] **Title** - Sprint NN (commit hash)`
- Keep lightweight - detailed planning happens in sprint files

## Quick Reference

**Pending items** (ordinal numbering, scans cleanly):

1. [#001] **Item One**: Short one-line description
2. [#002] **Item Two**: Another brief description
3. [#003] **Item Three**: Quick summary of the idea

## Completed

**Finished items** (immutable IDs for stable references):

- [#000] **Example Completed Item** - Sprint 15 (commit a1b2c3d)

## Details

### 1. [#001] Item One

Optional detailed description explaining the context, motivation, implementation approach, deliverables, trade-offs, etc.

### 2. [#002] Item Two

More details about this item if needed.

### 3. [#003] Item Three

Additional context for this backlog item.

### [#000] Example Completed Item

Historical details for completed work remain searchable here.

---

**Format Notes:**
- **Quick Reference**: Ordinals (1, 2, 3) provide clean sequential scanning
- **Immutable IDs**: [#NNN] never change, enabling stable references ("work on backlog #005")
- **Dual lookup**: Both "item 3" and "#003" resolve to the same backlog item
- **Completed section**: Shows what's been accomplished with sprint and commit tracking
- **Details section**: Full descriptions for all items (pending and completed) for searchability
