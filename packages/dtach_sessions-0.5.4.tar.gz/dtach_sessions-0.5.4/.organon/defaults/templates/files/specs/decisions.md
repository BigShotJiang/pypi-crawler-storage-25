---
type: decisions
project: <project name>
lifecycle_phase: Design | Alpha | Beta | Production
last_updated: <ISO 8601>
---

## Tech Stack

<Language, framework, database, cache, message queue, etc. With rationale for each choice.>

## Architecture

<Component structure, service boundaries, async/sync choices, deployment model.>

## Libraries & Dependencies

<Key libraries and why they were chosen over alternatives.>

## Patterns & Conventions

<Architectural patterns (repository pattern, event sourcing, etc.), naming conventions, error handling strategy.>

## Lifecycle Phase

<Current phase and what that means for agent behavior:>
<- Design: explore, no code yet>
<- Alpha: build fast, breaking changes free>
<- Beta: respect patterns, flag inconsistencies>
<- Production: backward compat required>
