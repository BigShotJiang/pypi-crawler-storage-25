---
type: quality
project: <project name>
last_updated: <ISO 8601>
---

## Performance

<Response time budgets (p50, p95, p99), throughput targets, resource limits.>

## Scalability

<Concurrent users, data volume, growth expectations.>

## Availability

<Uptime SLA, failover requirements, recovery time objectives.>

## Security

<Auth model, encryption requirements, data handling, compliance (GDPR, SOC2, etc.).>

## Observability

<Logging, metrics, tracing requirements.>
