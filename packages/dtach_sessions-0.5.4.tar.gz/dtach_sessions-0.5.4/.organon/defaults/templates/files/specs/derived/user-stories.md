---
type: derived
kind: user-stories
derived_from:
  - ../<workflow-file.yaml>
source_hash: <combined hash>
last_derived: <ISO 8601>
---

## Generated Stories

<!-- This section is overwritten on each re-derive. Do not edit manually. -->

### <Story Name>

**As a** <actor>, **I want to** <action>, **so that** <outcome>.

**Steps:**
1. <step from workflow> — `<HTTP method> <endpoint path>`
2. ...

**Preconditions:** <what must be true before this story can execute>
**Endpoints used:** <list of API paths>

## Developer Stories

<!-- This section is preserved across re-derives. Add human-authored stories here. -->
