---
type: derived
kind: state
derived_from:
  - ../<workflow-file.yaml>
source_hash: <combined hash>
last_derived: <ISO 8601>
---

## <Entity Group> State Machine

### States

<All observed states across the entity group, with which entity owns each.>

### Transitions

<Legal transitions with source workflow reference.>

### Illegal Joint States

<State combinations that should never occur, with rationale.>
