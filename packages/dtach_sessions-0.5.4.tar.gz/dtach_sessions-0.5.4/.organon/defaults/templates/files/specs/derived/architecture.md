---
type: derived
kind: architecture
derived_from:
  - ../<decisions-file.md>
  - ../../STRUCTURE.md
  - ../<contract-spec>
  - ../<model-files.yaml>
source_hash: <combined hash>
last_derived: <ISO 8601>
---

## System Overview

<One paragraph: what this system is and does.>

## Services & Components

<Each service/component: name, responsibility, technology, home directory.>

## Communication

<How services talk: HTTP, WebSocket, message queues, shared DB, etc.>

## Data Flow

<How data moves through the system for key workflows.>

## Deployment

<How the system is deployed: containers, cloud services, infrastructure.>
