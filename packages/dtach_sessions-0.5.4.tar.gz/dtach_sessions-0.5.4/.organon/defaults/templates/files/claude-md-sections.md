# CLAUDE.md Section Template

Defines the standard section structure for project CLAUDE.md files. Bootstrap produces this structure; sprint doc merges target it.

## Section Definitions

### 1. Project Overview (required)

**Heading:** `# {Project Name}`

One paragraph: what the project does, who it's for, and its primary value. Derived from code, not marketing.

### 2. Architecture Overview (required)

**Heading:** `## Architecture`

Services, modules, and their relationships. Include:
- Major components and what they do
- How they communicate (APIs, events, shared DB, etc.)
- Key architectural patterns (e.g., multi-tenancy, event sourcing)

### 3. Tech Stack (required)

**Heading:** `## Tech Stack`

Languages, frameworks, databases, infrastructure. Include versions when they matter.

### 4. Development Commands (required)

**Heading:** `## Development`

How to set up, run, test, and deploy. Real commands from Makefile, package.json, scripts, etc.

Subsections as needed:
- `### Setup` — prerequisites and installation
- `### Running` — how to start the application
- `### Testing` — how to run tests
- `### Deployment` — how to deploy (if applicable)

### 5. Directory Map (required)

**Heading:** `## Directory Map`

Every significant directory with its purpose. Use tree or list format. This is the primary navigation reference.

### 6. Key Patterns (optional)

**Heading:** `## Key Patterns`

Architectural patterns, conventions, or non-obvious design decisions found in the code. Only include if the project has patterns worth documenting (e.g., specific endpoint conventions, state machine patterns, multi-tenancy approach).

### 7. Scripts (conditional)

**Heading:** `## Scripts`

Every script file with a one-line description. Required if the project has scripts/ or bin/ directories.

### 8. Data and Fixtures (conditional)

**Heading:** `## Data`

Fixture files, seed data, migrations, config files. Required if the project has significant data files.

### 9. Implementation Standards (required)

**Heading:** `## Standards`

Project-specific coding standards, testing approach, and constraints. Include:
- Code style and conventions
- Testing strategy
- Commit message format

### 10. Organon Navigation (required, managed by organon)

**Heading:** `## Organon`

Organon-specific navigation and workflow instructions. This section is managed by `organon init` and should not be manually edited. Includes:
- Work mode references
- Workflow context tracking
- Sprint quick reference
- File location pointers for `.organon/` structure

## Rules

- **Required** sections must always be present. Bootstrap generates them; sprint merges must not remove them.
- **Conditional** sections are included when the project has relevant content.
- **Optional** sections are included when they add value.
- Section order should follow the numbering above (overview first, organon last).
- Content must be factual — derived from code analysis, not assumed.
- `/align` populates all sections from codebase inventory. Sprint merges update specific sections affected by the sprint.
- The `## Organon` section is the only section managed by tooling. All other sections are project-specific and maintained through `/align` + sprint merges.

## Merge Semantics

When `/align` or any tool updates CLAUDE.md, it follows these rules:

1. **Template sections with existing content:** Compare scanned results against existing content. Augment (add missing items) but do not replace existing content. Flag contradictions as conflicts for user review.
2. **Template sections with no content:** Generate from code inventory. Fill the section using the same analysis as `/align`'s initial scan.
3. **Custom sections (not in template):** Preserve in place. Record in manifest as `custom_sections`. Never modify or reorder.

**Conflict handling:** When scanned content contradicts existing content (e.g., a dependency was removed but is still listed), present both versions to the user with context and let them decide. Do not silently overwrite.

**Augment, not replace:** Adding a new API endpoint to Architecture is augmentation. Changing an endpoint's description is a potential conflict. Removing a listed endpoint that no longer exists is a conflict requiring review.

**Manifest tracking:** After merge, the manifest records which sections were augmented, which were generated fresh, and which custom sections were preserved. This provides an audit trail for CLAUDE.md changes.

## Sprint Merge Guidance

When merging sprint docs into CLAUDE.md after sprint completion:

1. **Identify affected sections** — Which CLAUDE.md sections does the sprint's work touch?
2. **Update, don't append** — Modify existing section content to reflect the new state, don't add a "Sprint N changes" block.
3. **Preserve structure** — Keep the section order and headings. Add new subsections only if the sprint introduced a genuinely new category.
4. **Remove sprint-specific language** — The merged content should read as current truth, not as a changelog.
5. **Follow merge semantics** — Apply the augment-not-replace rules above. Sprint merges are a specific case of the general merge semantics.
