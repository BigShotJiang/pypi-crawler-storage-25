---
validation:
  required_sections:
    - name: "## Objective"
      description: "Primary purpose and goal of this work mode"
      allow_empty: false
      order: 1
    - name: "## Available Tasks"
      description: "Workflows that can be used in this work mode"
      allow_empty: false
      order: 2
    - name: "## Typical Flow"
      description: "Common progression through workflows"
      allow_empty: false
      order: 3
  optional_sections:
    - "## Prerequisites"
    - "## Documentation Format"
    - "## Working Through Tasks"
    - "## Task Completion Requirements"
    - "## When to Cycle Back"
    - "## Commit Conventions"
    - "## Completing Work"
    - "## Debug Mode"
    - "## When to Transition"
    - "## Examples"
    - "## Constraints"
  content_patterns:
    - section: "## Objective"
      pattern: "\\w{20,}"
      description: "Must clearly describe the work mode's purpose"
    - section: "## Available Tasks"
      pattern: "\\w{10,}"
      description: "Must list workflows available in this mode"
---
# {Work Mode Name} Work Mode

## Objective

[Describe the primary purpose and goal of this work mode.]

## Available Tasks

- **workflow-name** - Brief description of when to use this workflow

## Typical Flow

```
workflow1 → workflow2 → workflow3
```

[Describe the common progression through workflows in this work mode.]

## Commit Conventions

[Optional: Define commit message format for this work mode]

```bash
type(scope): Description
```
