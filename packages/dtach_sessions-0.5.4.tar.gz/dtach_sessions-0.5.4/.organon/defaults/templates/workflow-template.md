---
validation:
  required_sections:
    - name: "## When to Use This Workflow"
      description: "Situations where this workflow should be applied"
      allow_empty: false
      order: 1
    - name: "## Inputs"
      description: "Information and artifacts needed to begin this workflow"
      allow_empty: false
      order: 2
    - name: "## Process"
      description: "Step-by-step procedure for executing this workflow"
      allow_empty: false
      order: 3
    - name: "## Outputs"
      description: "Expected deliverables and artifacts produced"
      allow_empty: false
      order: 4
    - name: "## Common Pitfalls"
      description: "Frequent mistakes and how to avoid them"
      allow_empty: false
      order: 5
    - name: "## Validation"
      description: "Criteria for validating workflow completion"
      allow_empty: false
      order: 6
    - name: "## Integration with Work Modes"
      description: "How this workflow fits into different work modes"
      allow_empty: false
      order: 7
    - name: "## Tips"
      description: "Best practices and recommendations"
      allow_empty: false
      order: 8
  optional_sections:
    - "### Substep heading"
  content_patterns:
    - section: "## When to Use This Workflow"
      pattern: "\\w{20,}"
      description: "Must describe use cases with specific examples"
    - section: "## Process"
      pattern: "###.+"
      description: "Must contain numbered substep headings"
---
# {Workflow Name} Workflow

## When to Use This Workflow

[Describe situations where this workflow should be applied. Include specific use cases and examples.]

## Inputs

[List information, artifacts, and prerequisites needed to begin this workflow.]

## Process

### 1. First Step

[Describe the first step in detail]

### 2. Second Step

[Describe the second step in detail]

## Outputs

[Describe the expected deliverables and artifacts produced by this workflow.]

## Common Pitfalls

[Document frequent mistakes and how to avoid them.]

## Validation

[Define criteria for validating that this workflow was completed successfully.]

## Integration with Work Modes

**In Sprint-Execution Work Mode:**
[How this workflow is used during sprint execution]

**In One-Off-Task Work Mode:**
[How this workflow is used for quick tasks]

**In Sprint-Planning Work Mode:**
[How this workflow is used during planning]

## Tips

[Best practices and recommendations for executing this workflow effectively.]
