# DSM vs Workmux Comparison

Workmux (github.com/raine/workmux) is the closest competitor to DSM. Both are worktree-centric session managers for AI coding agents. This document captures the architectural differences, relative strengths, and gaps.

## Core Architecture

| | DSM | Workmux |
|---|---|---|
| **Language** | Python (stdlib only) | Rust |
| **Atomic unit** | Docker container + worktree | tmux window + worktree |
| **Session primitive** | Container (docker exec) + dtach | tmux/Zellij/WezTerm/kitty window |
| **Daemon** | Yes (async, Unix socket, NDJSON) | No |
| **State persistence** | Registry (JSON per container) + session dirs | State files in `~/.local/state/workmux/` |

DSM treats the container as the session boundary. Workmux treats the terminal multiplexer window as the session boundary, with containers as an optional sandbox layer.

## Isolation Model

### DSM

Container boundary provides filesystem, process, and network isolation by default. Every session runs inside a Docker container with explicit bind mounts:
- `/workspace` (repo root)
- `/worktrees` (worktree home)
- `/mnt/{repo}` (additional repos, configurable access)
- `~/.ssh` (read-only)

No defense-in-depth for host-exec scenarios. No network restriction layer. Assumes the agent is trusted within its container.

### Workmux

Three-tier isolation, each opt-in:

1. **No sandbox (default):** Agent cwd is set to the worktree directory. No enforcement -- agent can `cd ..` and access anything on the host.

2. **Container sandbox (Docker/Podman/Apple Container):** Only the worktree, `.git` common dir, and main worktree are bind-mounted. Ephemeral containers (`--rm`). Network restrictions via iptables + allowlist HTTPS proxy.

3. **Lima VM sandbox:** Full QEMU/VZ virtual machine per project. Persistent VMs, broader mounts (all worktrees share one VM), machine-level isolation.

Additional security layers:
- **Host-exec sandbox:** When container agents proxy commands back to the host, `sandbox-exec` (macOS) or `bwrap` (Linux) restricts filesystem access. If bwrap is not installed on Linux, host-exec is refused entirely (fail-closed).
- **Global-only config:** Security-sensitive settings (`host_commands`, `network`, `extra_mounts`) can only be set in global config -- a malicious `.workmux.yaml` in a cloned repo cannot weaken the sandbox.
- **Hook safety:** Pre-merge/pre-remove hooks are force-skipped for sandbox-triggered operations to prevent hook injection from a compromised guest.
- **Agent credentials** are mounted to `/tmp/.claude`, not the real `$HOME`.

## Feature Comparison

### Where DSM Wins

**Automatic port forwarding.** DSM's daemon runs a `PortWatcher` that polls `/proc/net/tcp` inside containers, detects new listening ports in real-time, and auto-creates `socat` forwards. Workmux has no built-in port forwarding -- users must script deterministic port offsets manually.

**Container lifecycle management.** DSM owns the full container lifecycle: create, start, stop, remove, health monitoring, layout validation, auto-recreation of stale containers. Workmux's container sandbox is ephemeral and single-use per session.

**Remote/SSH sessions.** DSM supports SSH sessions natively (`dsm ssh HOST`) with keepalive, alias management, and dtach-based persistence. Workmux is local-only.

**Daemon architecture.** DSM's daemon provides centralized state management, event subscriptions, port watching, and concurrent operation serialization (per-container locks). Workmux has no daemon -- each CLI invocation is stateless.

**Agent context injection.** DSM generates a `CLAUDE.md` file per container with networking info, workspace layout, mounted repos, and custom instructions, then bind-mounts it into the container. Workmux passes prompts via CLI flags (`--prompt`, `--prompt-file`), which is less structured.

### Where Workmux Wins

**Multi-agent orchestration.** Workmux supports 7+ agents (Claude, Gemini, Codex, Copilot, OpenCode, Pi, Kiro) and can run them in parallel across branches: `-a claude -a gemini --count N --foreach`. DSM targets Claude Code only.

**TUI dashboard.** Workmux provides a full terminal UI with live agent preview, diff viewer, patch mode, input mode, sorting/filtering, and a persistent tmux sidebar showing agent statuses. DSM is CLI-only with `dsm list`.

**Built-in merge workflow.** `workmux merge` supports squash, rebase, stacked PRs (`--into`), and auto-cleanup. DSM has no merge workflow (delegates to UI Coder).

**Session resurrection.** `workmux resurrect` restores windows after tmux/system crashes by detecting worktrees with active agent state files. DSM can recreate dead containers on resume but doesn't preserve conversation state.

**Deeper sandbox security.** Workmux's multi-layer isolation (container + host-exec sandbox + network proxy + global-only config enforcement) provides defense-in-depth that DSM doesn't attempt.

**File operations on worktree creation.** Workmux auto-copies `.env` files and symlinks `node_modules` into new worktrees via config, solving the gitignored-files problem. DSM doesn't handle this.

### Comparable / Neutral

| Feature | DSM | Workmux |
|---|---|---|
| Worktree creation strategy | 3-tier fallback (track remote, use local, create new) | Similar, with slugified handles |
| Config profiles | Named profiles in `~/.dsm/config.json` | Two-level YAML (global + project `.workmux.yaml`) |
| Lifecycle hooks | None | `post_create`, `pre_merge`, `pre_remove` |
| Branch naming | Direct branch name | Slugified handles (`feature/auth` -> `feature-auth`) |

## Architectural Trade-offs

### Container-first (DSM) vs Worktree-first (Workmux)

DSM's container-first approach means isolation is always-on and uniform. Every session gets the same guarantees regardless of config. The cost: container startup latency, Docker dependency, and complexity in bridging host/container git state (container-created worktrees have `.git` files pointing to container paths that don't resolve on the host).

Workmux's worktree-first approach means zero isolation overhead by default. Sandboxing is opt-in and configurable per the threat model. The cost: without sandbox enabled, there's no isolation at all -- an agent can access the entire host filesystem.

### Daemon (DSM) vs Stateless CLI (Workmux)

DSM's daemon enables features that a stateless CLI cannot: real-time port detection, event subscriptions, concurrent operation serialization, and centralized registry. The cost: daemon lifecycle management, socket communication overhead, and state consistency challenges (TOCTOU races, stale registry entries).

Workmux avoids daemon complexity by relying on tmux as the persistent state layer and the filesystem for everything else. The cost: no real-time port forwarding, no centralized state, and tmux/Zellij dependency.

## Gaps to Consider

From Workmux, DSM could learn:
1. **Multi-agent support** -- abstract the agent layer so other tools beyond Claude Code can use DSM containers
2. **TUI dashboard** -- real-time session monitoring beyond `dsm list`
3. **Merge workflow** -- built-in merge/cleanup instead of delegating to UI Coder
4. **Network restrictions** -- iptables + allowlist proxy for sandboxed containers
5. **Host-exec sandboxing** -- `bwrap`/`sandbox-exec` for commands proxied back to host
6. **Gitignored file handling** -- auto-copy/symlink `.env`, `node_modules` on worktree creation
