# dsm Daemon Architecture

**Date:** 2026-04-11
**Status:** Approved design
**Context:** Port forwarding implementation exposed coordination gaps between dsm and ui_coder. This document captures the design rationale and architecture for adding a daemon to dsm.

## Problem

dsm manages Docker containers, sessions, and port forwarding. The port forwarding system (PortWatcher) needs a long-lived process to detect ports, manage socat processes, and serve state to multiple consumers (CLI, ui_coder). Today dsm is CLI-only — each invocation is independent, state lives in-process or on disk, and nothing watches between commands.

Three attempts to solve this without a daemon all fail:

1. **In-process state** (current) — PortWatcher runs in `dsm ports --watch` foreground. Forward registry is a module-level dict. Other processes (ui_coder, other CLI invocations) can't see it. Two watchers for the same container create duplicate socat processes.

2. **Filesystem coordination** — Write PIDs and forward state to disk. Multiple processes read/write shared files. Fails because: stale PIDs (process dies, PID recycled), race conditions (two processes check "no lock" simultaneously), no crash cleanup (orphaned socat processes, stale lock files). Works 95% of the time, mysterious bugs the other 5%.

3. **ui_coder as de facto daemon** — ui_coder runs long-lived, so let it own watchers for its containers. But dsm must also work without ui_coder, breaking the "dsm owns containers" principle. Two owners = back to coordination problems.

## Why a Daemon

The daemon provides exactly three things that filesystem + CLI cannot:

### 1. Single-process coordination
One ordered event stream. No races on shared state. One process writes the container registry, manages socat processes, and decides what to forward. This eliminates every coordination problem above — not by adding locking, but by removing concurrency.

### 2. Liveness
A CLI exits after each command. Nobody watches for:
- A new port appearing in a container
- A container restarting (new IP breaks existing socat forwards)
- A socat process dying

Without the daemon, port forwarding only works while `dsm ports --watch` runs in a terminal. With it, ports are watched as long as the daemon is up.

### 3. Push notifications
Consumers (ui_coder) get told when something changes instead of polling the filesystem and diffing state. The daemon pushes events to connected clients over persistent socket connections.

**Everything else — the registry, the port state, the container metadata — is just data on disk that the daemon happens to be the single writer for (which circles back to point 1).**

## Architecture

### Layers

```
dsm daemon (dsmd)
  Owns:
  ├── Container registry (track all containers, regardless of creation path)
  ├── Port detection (PortWatcher as asyncio tasks)
  ├── Port forwarding (socat lifecycle)
  └── State persistence (atomic JSON writes to disk)

dsm CLI
  Thin client:
  ├── Connects to daemon via Unix socket
  ├── Sends JSON commands, prints results
  ├── Lazy-starts daemon if not running
  └── Falls back to reading disk state if daemon unavailable

ui_coder (consumer)
  ├── Calls dsm library functions (which talk to daemon)
  ├── Subscribes to port change events via persistent connection
  ├── Surfaces state to user (artifacts, API, UI)
  └── Never calls Docker directly
```

### Daemon Core

- **Event loop:** `asyncio.start_unix_server()` — zero dependencies, handles concurrent clients
- **Socket:** `~/.dsm/dsm.sock`
- **Protocol:** Newline-delimited JSON (NDJSON) over Unix socket
  - Request/response for commands: `{"cmd": "list_ports", "container": "dsm_web"}\n`
  - Persistent connections for event subscriptions: `{"cmd": "watch", "container": "dsm_web"}\n`
  - Push events on subscribed connections: `{"event": "port_added", "port": 8787, ...}\n`
- **Port watchers:** asyncio tasks (not threads) polling `/proc/net/tcp` per container
- **Child processes:** socat managed via `subprocess.Popen()`, PIDs tracked in registry
- **Shutdown:** `SIGTERM`/`SIGINT` handlers — kill socat processes, persist state, close socket

### Container Registry

```
~/.dsm/registry/
  dsm_web.json
  dsm_api.json
```

Per-container file:
```json
{
  "container_name": "dsm_web",
  "container_id": "abc123...",
  "container_ip": "172.17.0.2",
  "status": "running",
  "created_at": "2026-04-11T10:00:00Z",
  "updated_at": "2026-04-11T10:23:45Z",
  "ports": [
    {"port": 8787, "bind": "0.0.0.0", "protocol": "tcp"}
  ],
  "forwards": [
    {"container_port": 8787, "host_port": 8787, "socat_pid": 12345}
  ]
}
```

- **Write-on-change** with atomic writes (`write temp -> os.rename`)
- **In-memory cache** in daemon, disk is persistence layer
- Daemon is single writer at runtime; CLI reads from disk when daemon is down

### Daemon Lifecycle

- **Start:** Lazy — CLI tries `connect(~/.dsm/dsm.sock)`, if `ECONNREFUSED`/`ENOENT`, spawns daemon, retries
- **Liveness check:** Socket connect attempt (not PID files — socket proves responsiveness)
- **Stop:** `dsm daemon stop` sends shutdown command via socket
- **Crash recovery:** Next CLI command spawns new daemon; daemon loads registry from disk on startup, validates socat PIDs against `/proc/$PID/cmdline`
- **No systemd required** initially — daemon respawns on next CLI call

### Graceful Degradation

When daemon is not running:
- `dsm ports` reads last-known state from `~/.dsm/registry/*.json`, validates socat PIDs
- `dsm ls` reads session metadata (unchanged from today)
- `ensure_container()` creates containers and writes registry entry directly
- Port watching and auto-forwarding are unavailable (daemon-only features)

## Constraints

1. **Zero new dependencies** — stdlib asyncio, json, subprocess, socket only
2. **One daemon process** — lock via socket bind (second bind fails with EADDRINUSE)
3. **One watcher per container** — daemon is the single watcher owner
4. **Backward compatible** — existing `~/.dsm/` session metadata unchanged; registry is additive
5. **ui_coder never calls Docker directly** — all container operations through dsm

## Decision Log

| Decision | Rationale |
|----------|-----------|
| Daemon over filesystem coordination | Eliminates races, enables liveness and push — the three things files can't do |
| asyncio over threading | Fits event-driven model; port watchers and client handling in one loop |
| NDJSON over HTTP/gRPC | Simplest protocol that works; human-readable; no framing overhead |
| Lazy start over systemd | Zero operational overhead; daemon is invisible infrastructure |
| Socket liveness over PID files | Socket proves daemon is responsive, not just alive |
| File-per-container over SQLite | Inspectable, atomic-writable, no dependency; <50 entries |
| Graceful degradation | Daemon enhances but isn't required for basic operations |

## References

- Origin: `/home/pjsulin/repos/dev/ui_coder/.organon/dev-docs/design/dsm-ui-coder-architecture.md`
- Port forwarding research: `ui_coder:.organon/dev-docs/research/dynamic-port-forwarding.md`
- Pattern precedents: Docker (dockerd/docker), gpg-agent, ssh-agent, Redis
