"""Integration tests for container registry workflow.
Generated from: container-entry.model.yaml, container-lifecycle.workflow.yaml on 2026-04-13
Spec gaps marked with # SPEC GAP comments.

Tests validate registry CRUD operations and persistence behavior.
"""

import json
from pathlib import Path

from dsm.registry import ContainerRegistry, ContainerEntry, PortInfo, ForwardInfo


class TestRegistryLifecycle:
    """Validate registry operations match container-lifecycle spec."""

    def test_register_creates_running_entry(self, registry_dir):
        """register() creates entry with status='running' per spec."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        entry = reg.register("ct1", "id1", "10.0.0.1")
        assert entry.status == "running"
        assert entry.container_name == "ct1"
        assert entry.container_id == "id1"
        assert entry.container_ip == "10.0.0.1"
        assert entry.created_at is not None
        assert entry.updated_at is not None

    def test_get_returns_registered_entry(self, registry_dir):
        """get() returns registered entry."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        reg.register("ct1", "id1", "10.0.0.1")
        entry = reg.get("ct1")
        assert entry is not None
        assert entry.container_name == "ct1"

    def test_get_returns_none_for_missing(self, registry_dir):
        """get() returns None for unregistered container."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        assert reg.get("nonexistent") is None

    def test_list_returns_all_entries(self, registry_dir):
        """list() returns all registered entries."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        reg.register("ct1", "id1", "10.0.0.1")
        reg.register("ct2", "id2", "10.0.0.2")
        entries = reg.list()
        assert len(entries) == 2
        names = {e.container_name for e in entries}
        assert names == {"ct1", "ct2"}

    def test_remove_deletes_entry_and_file(self, registry_dir):
        """remove() deletes entry from memory and disk per spec."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        reg.register("ct1", "id1", "10.0.0.1")
        reg.persist("ct1")
        assert (registry_dir / "ct1.json").exists()

        reg.remove("ct1")
        assert reg.get("ct1") is None
        assert not (registry_dir / "ct1.json").exists()

    def test_update_bumps_updated_at(self, registry_dir):
        """update() modifies fields and bumps updated_at."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        entry = reg.register("ct1", "id1", "10.0.0.1")
        original_updated = entry.updated_at

        import time
        time.sleep(0.01)  # ensure timestamp differs

        reg.update("ct1", status="stopped")
        assert entry.status == "stopped"
        assert entry.updated_at != original_updated

    def test_persist_and_load_roundtrip(self, registry_dir):
        """persist/load roundtrip preserves all data."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        entry = reg.register("ct1", "id1", "10.0.0.1")
        entry.ports.append(PortInfo(port=8080, bind_address="0.0.0.0", protocol="tcp"))
        entry.forwards.append(ForwardInfo(container_port=8080, host_port=8080, socat_pid=1234))
        reg.persist("ct1")

        # Load in a new registry instance
        reg2 = ContainerRegistry(registry_dir)
        reg2.load()
        entry2 = reg2.get("ct1")
        assert entry2 is not None
        assert entry2.container_name == "ct1"
        assert len(entry2.ports) == 1
        assert entry2.ports[0].port == 8080
        assert len(entry2.forwards) == 1
        assert entry2.forwards[0].container_port == 8080

    def test_load_creates_directory_if_missing(self, tmp_path):
        """load() creates registry_dir if it doesn't exist."""
        new_dir = tmp_path / "nonexistent" / "registry"
        reg = ContainerRegistry(new_dir)
        reg.load()
        assert new_dir.exists()
