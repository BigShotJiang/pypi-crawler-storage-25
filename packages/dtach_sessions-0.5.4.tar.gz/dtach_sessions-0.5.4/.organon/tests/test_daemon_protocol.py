"""Integration tests for daemon NDJSON protocol.
Generated from: daemon-protocol.workflow.yaml on 2026-04-13
Spec gaps marked with # SPEC GAP comments.

Tests validate the daemon command dispatch, NDJSON request/response format,
and event subscription behavior as described in the daemon-protocol spec.
"""

import asyncio
import json

from dsm.daemon import DsmDaemon


async def _send_recv(reader, writer, cmd: str, **params) -> dict:
    """Send a NDJSON command and read the response."""
    request = {"cmd": cmd}
    request.update(params)
    writer.write(json.dumps(request).encode() + b"\n")
    await writer.drain()
    line = await asyncio.wait_for(reader.readline(), timeout=5.0)
    return json.loads(line)


class TestDaemonProtocol:
    """Verify daemon command dispatch matches daemon-protocol.workflow.yaml spec."""

    def test_status_returns_pid_uptime_counts(self, socket_path, registry_dir):
        """status command returns pid, uptime, containers, forwards."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                resp = await _send_recv(reader, writer, "status")
                assert resp["error"] is None
                result = resp["result"]
                assert "pid" in result
                assert "uptime" in result
                assert "containers" in result
                assert "forwards" in result
                assert isinstance(result["pid"], int)
                assert isinstance(result["uptime"], (int, float))
                assert isinstance(result["containers"], int)
                assert isinstance(result["forwards"], int)
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_list_containers_empty(self, socket_path, registry_dir):
        """list_containers returns empty list when no containers registered."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                resp = await _send_recv(reader, writer, "list_containers")
                assert resp["error"] is None
                assert resp["result"] == []
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_register_and_get_container(self, socket_path, registry_dir):
        """register_container creates entry, get_container retrieves it.
        Validates container, container_id, ip params per spec."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))

                # Register
                resp = await _send_recv(
                    reader, writer, "register_container",
                    container="test_container",
                    container_id="abc123",
                    ip="172.17.0.2",
                )
                assert resp["error"] is None
                entry = resp["result"]
                assert entry["container_name"] == "test_container"
                assert entry["container_id"] == "abc123"
                assert entry["container_ip"] == "172.17.0.2"
                assert entry["status"] == "running"

                # Get
                resp = await _send_recv(
                    reader, writer, "get_container",
                    container="test_container",
                )
                assert resp["error"] is None
                assert resp["result"]["container_name"] == "test_container"

                # List
                resp = await _send_recv(reader, writer, "list_containers")
                assert resp["error"] is None
                assert len(resp["result"]) == 1

                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_register_missing_params_returns_error(self, socket_path, registry_dir):
        """register_container with missing params returns error per spec preconditions."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                resp = await _send_recv(
                    reader, writer, "register_container",
                    container="test",
                    # Missing container_id and ip
                )
                assert resp["error"] is not None
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_get_nonexistent_container_returns_error(self, socket_path, registry_dir):
        """get_container for missing container returns error."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                resp = await _send_recv(
                    reader, writer, "get_container",
                    container="nonexistent",
                )
                assert resp["error"] is not None
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_unknown_command_returns_error(self, socket_path, registry_dir):
        """Unknown command returns error per DAEMON-03 invariant."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                resp = await _send_recv(reader, writer, "nonexistent_command")
                assert resp["error"] is not None
                assert "unknown command" in resp["error"]
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_invalid_json_returns_error(self, socket_path, registry_dir):
        """Invalid JSON request returns error per DAEMON-03 invariant."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                writer.write(b"not valid json\n")
                await writer.drain()
                line = await asyncio.wait_for(reader.readline(), timeout=5.0)
                resp = json.loads(line)
                assert resp["error"] is not None
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_missing_cmd_field_returns_error(self, socket_path, registry_dir):
        """Request without cmd field returns error."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                writer.write(json.dumps({"foo": "bar"}).encode() + b"\n")
                await writer.drain()
                line = await asyncio.wait_for(reader.readline(), timeout=5.0)
                resp = json.loads(line)
                assert resp["error"] is not None
                assert "cmd" in resp["error"].lower() or "missing" in resp["error"].lower()
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_watch_subscribe_and_unwatch(self, socket_path, registry_dir):
        """watch command adds subscriber, unwatch removes it."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))

                resp = await _send_recv(reader, writer, "watch")
                assert resp["error"] is None
                assert resp["result"]["subscribed"] is True

                resp = await _send_recv(reader, writer, "unwatch")
                assert resp["error"] is None
                assert resp["result"]["subscribed"] is False

                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_shutdown_closes_daemon(self, socket_path, registry_dir):
        """shutdown command triggers graceful stop."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            reader, writer = await asyncio.open_unix_connection(str(socket_path))
            resp = await _send_recv(reader, writer, "shutdown")
            assert resp["error"] is None
            # Daemon should stop shortly — wait for socket to close
            await asyncio.sleep(0.5)
            writer.close()

        asyncio.run(_test())

    def test_list_ports_empty(self, socket_path, registry_dir):
        """list_ports returns empty list with no containers."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                resp = await _send_recv(reader, writer, "list_ports")
                assert resp["error"] is None
                assert resp["result"] == []
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())

    def test_list_forwards_empty(self, socket_path, registry_dir):
        """list_forwards returns empty list with no containers."""
        async def _test():
            daemon = DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)
            await daemon.start()
            try:
                reader, writer = await asyncio.open_unix_connection(str(socket_path))
                resp = await _send_recv(reader, writer, "list_forwards")
                assert resp["error"] is None
                assert resp["result"] == []
                writer.close()
                await writer.wait_closed()
            finally:
                await daemon.stop()

        asyncio.run(_test())
