"""Integration tests for project invariants.
Generated from: dsm.invariants.yaml on 2026-04-13
Spec gaps marked with # SPEC GAP comments.

Tests validate the 12 invariants defined in the invariants spec.
"""

import json
import os
import struct
import tempfile
from pathlib import Path

from dsm.registry import ContainerRegistry, ContainerEntry, PortInfo, ForwardInfo
from dsm.ports import parse_proc_net_tcp, ListeningPort, _normalize_bind


class TestRegistryInvariants:
    """REG-01: Atomic writes, REG-02: Container name sanitization."""

    def test_reg01_atomic_write_creates_tmp_then_renames(self, registry_dir):
        """REG-01: Registry writes use atomic rename (write to .tmp, then os.rename)."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        reg.register("test_container", "abc123", "172.17.0.2")
        reg.persist("test_container")

        # Final file should exist, tmp should not
        assert (registry_dir / "test_container.json").exists()
        assert not (registry_dir / "test_container.json.tmp").exists()

        # File should be valid JSON
        with open(registry_dir / "test_container.json") as f:
            data = json.load(f)
        assert data["container_name"] == "test_container"

    def test_reg01_persist_all_writes_all_entries(self, registry_dir):
        """REG-01: persist_all writes every entry atomically."""
        reg = ContainerRegistry(registry_dir)
        reg.load()
        reg.register("c1", "id1", "10.0.0.1")
        reg.register("c2", "id2", "10.0.0.2")
        reg.persist_all()

        assert (registry_dir / "c1.json").exists()
        assert (registry_dir / "c2.json").exists()


class TestPortInvariants:
    """PORT-01 through PORT-04: Port filtering and normalization."""

    def test_port01_ephemeral_ports_filtered(self):
        """PORT-01: Ephemeral ports (32768-60999) filtered from scan results."""
        # Build a /proc/net/tcp line with port 40000 (ephemeral) in LISTEN state
        # Port 40000 = 0x9C40, addr 0.0.0.0 = 00000000
        content = (
            "  sl  local_address rem_address   st tx_queue ...\n"
            "   0: 00000000:9C40 00000000:0000 0A 00000000:00000000 00:00000000 00000000\n"
        )
        result = parse_proc_net_tcp(content)
        assert len(result) == 0, "Ephemeral port 40000 should be filtered"

    def test_port01_non_ephemeral_ports_kept(self):
        """PORT-01: Non-ephemeral ports are kept."""
        # Port 8080 = 0x1F90
        content = (
            "  sl  local_address rem_address   st tx_queue ...\n"
            "   0: 00000000:1F90 00000000:0000 0A 00000000:00000000 00:00000000 00000000\n"
        )
        result = parse_proc_net_tcp(content)
        assert len(result) == 1
        assert result[0].port == 8080

    def test_port02_loopback_normalized(self):
        """PORT-02: Loopback addresses detected correctly."""
        # 127.0.0.1 in little-endian hex = 0100007F
        content = (
            "  sl  local_address rem_address   st tx_queue ...\n"
            "   0: 0100007F:1F90 00000000:0000 0A 00000000:00000000 00:00000000 00000000\n"
        )
        result = parse_proc_net_tcp(content)
        assert len(result) == 1
        assert result[0].bind_address == "127.0.0.1"

    def test_port03_non_listen_states_filtered(self):
        """Ports not in LISTEN state (0A) are filtered."""
        # State 01 = ESTABLISHED (not LISTEN)
        content = (
            "  sl  local_address rem_address   st tx_queue ...\n"
            "   0: 00000000:1F90 00000000:0000 01 00000000:00000000 00:00000000 00000000\n"
        )
        result = parse_proc_net_tcp(content)
        assert len(result) == 0

    def test_port04_ipv4_mapped_ipv6_normalized(self):
        """PORT-04: IPv4-mapped IPv6 addresses normalized to prevent duplicates."""
        assert _normalize_bind("::ffff:0.0.0.0") == "0.0.0.0"
        assert _normalize_bind("::ffff:127.0.0.1") == "127.0.0.1"
        assert _normalize_bind("::") == "0.0.0.0"
        assert _normalize_bind("0.0.0.0") == "0.0.0.0"


class TestEnvInvariants:
    """ENV-01: Config env var expansion."""

    def test_env01_unset_var_causes_exit(self):
        """ENV-01: ${VAR} references to unset vars cause sys.exit(1)."""
        from dsm.cli import expand_env_vars
        import sys

        # Remove the var if it exists
        os.environ.pop("__DSM_TEST_UNSET_VAR__", None)

        with pytest.raises(SystemExit) as exc_info:
            expand_env_vars({"KEY": "${__DSM_TEST_UNSET_VAR__}"})
        assert exc_info.value.code == 1

    def test_env01_set_var_expands(self):
        """ENV-01: ${VAR} references to set vars expand correctly."""
        from dsm.cli import expand_env_vars

        os.environ["__DSM_TEST_VAR__"] = "hello"
        try:
            result = expand_env_vars({"KEY": "${__DSM_TEST_VAR__}"})
            assert result["KEY"] == "hello"
        finally:
            del os.environ["__DSM_TEST_VAR__"]


class TestSessionInvariants:
    """SESSION-01: Session ID uniqueness."""

    def test_session01_unique_id_dedup(self, tmp_path):
        """SESSION-01: Slug collision resolved by appending -N suffix."""
        from dsm.cli import unique_id, DSM_DIR

        # Temporarily override DSM_DIR
        import dsm.cli as cli_mod
        original_dsm_dir = cli_mod.DSM_DIR
        cli_mod.DSM_DIR = tmp_path

        try:
            (tmp_path / "test-slug").mkdir()
            result = unique_id("test-slug")
            assert result == "test-slug-2"

            (tmp_path / "test-slug-2").mkdir()
            result = unique_id("test-slug")
            assert result == "test-slug-3"
        finally:
            cli_mod.DSM_DIR = original_dsm_dir


import pytest
