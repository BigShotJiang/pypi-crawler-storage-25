"""Shared fixtures for spec-derived integration tests.
Generated from: .organon/specs/ on 2026-04-13
"""

import asyncio
import json
import tempfile
from pathlib import Path

import pytest


@pytest.fixture
def tmp_dir(tmp_path):
    """Provide a temporary directory for registry and socket files."""
    return tmp_path


@pytest.fixture
def registry_dir(tmp_dir):
    """Provide a temporary registry directory."""
    d = tmp_dir / "registry"
    d.mkdir()
    return d


@pytest.fixture
def socket_path(tmp_dir):
    """Provide a temporary socket path."""
    return tmp_dir / "dsm.sock"


@pytest.fixture
def registry(registry_dir):
    """Provide a loaded ContainerRegistry instance."""
    from dsm.registry import ContainerRegistry
    reg = ContainerRegistry(registry_dir)
    reg.load()
    return reg


@pytest.fixture
def daemon(socket_path, registry_dir):
    """Provide a DsmDaemon instance (not started)."""
    from dsm.daemon import DsmDaemon
    return DsmDaemon(socket_path=socket_path, registry_dir=registry_dir)


@pytest.fixture
def run_daemon(daemon):
    """Start the daemon, yield it, then stop it."""
    async def _run():
        await daemon.start()
        return daemon

    loop = asyncio.new_event_loop()
    loop.run_until_complete(_run())
    yield daemon
    loop.run_until_complete(daemon.stop())
    loop.close()
