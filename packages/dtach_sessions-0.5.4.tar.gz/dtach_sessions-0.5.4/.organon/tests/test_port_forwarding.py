"""Integration tests for port forwarding workflow.
Generated from: port-forwarding.workflow.yaml on 2026-04-13
Spec gaps marked with # SPEC GAP comments.

Tests validate port scanning behavior (parse_proc_net_tcp) and
forwarding invariants as described in the port-forwarding spec.
"""

from dsm.ports import (
    parse_proc_net_tcp,
    ListeningPort,
    ForwardHandle,
    PortChange,
    _normalize_bind,
    find_available_host_port,
    EPHEMERAL_PORT_MIN,
    EPHEMERAL_PORT_MAX,
)


class TestScanPorts:
    """Validate scan-ports step from port-forwarding.workflow.yaml."""

    def test_parses_listen_state_only(self):
        """Only ports in LISTEN state (0A) are returned."""
        content = (
            "  sl  local_address rem_address   st\n"
            "   0: 00000000:1F90 00000000:0000 0A\n"  # LISTEN - port 8080
            "   1: 00000000:0050 00000000:0000 01\n"  # ESTABLISHED - port 80
        )
        result = parse_proc_net_tcp(content)
        assert len(result) == 1
        assert result[0].port == 8080

    def test_parses_bind_address(self):
        """Correctly decodes hex bind addresses."""
        # 0.0.0.0 = 00000000
        content = (
            "  sl  local_address rem_address   st\n"
            "   0: 00000000:0050 00000000:0000 0A\n"
        )
        result = parse_proc_net_tcp(content)
        assert result[0].bind_address == "0.0.0.0"

    def test_parses_loopback_address(self):
        """127.0.0.1 decoded from little-endian hex 0100007F."""
        content = (
            "  sl  local_address rem_address   st\n"
            "   0: 0100007F:0050 00000000:0000 0A\n"
        )
        result = parse_proc_net_tcp(content)
        assert result[0].bind_address == "127.0.0.1"

    def test_filters_ephemeral_range(self):
        """Ports in ephemeral range (32768-60999) are excluded."""
        # Port 32768 = 0x8000 (ephemeral min)
        content = (
            "  sl  local_address rem_address   st\n"
            "   0: 00000000:8000 00000000:0000 0A\n"
        )
        result = parse_proc_net_tcp(content)
        assert len(result) == 0

    def test_keeps_non_ephemeral(self):
        """Ports below ephemeral range are kept."""
        # Port 8080 = 0x1F90 (non-ephemeral)
        content = (
            "  sl  local_address rem_address   st\n"
            "   0: 00000000:1F90 00000000:0000 0A\n"
        )
        result = parse_proc_net_tcp(content)
        assert len(result) == 1
        assert result[0].port == 8080

    def test_empty_content_returns_empty(self):
        """Empty /proc/net/tcp content returns no ports."""
        assert parse_proc_net_tcp("") == []

    def test_header_only_returns_empty(self):
        """Header-only content returns no ports."""
        content = "  sl  local_address rem_address   st\n"
        assert parse_proc_net_tcp(content) == []

    def test_multiple_ports(self):
        """Multiple listening ports are all returned."""
        content = (
            "  sl  local_address rem_address   st\n"
            "   0: 00000000:0050 00000000:0000 0A\n"  # port 80
            "   1: 00000000:1F90 00000000:0000 0A\n"  # port 8080
            "   2: 00000000:0BB8 00000000:0000 0A\n"  # port 3000
        )
        result = parse_proc_net_tcp(content)
        ports = {p.port for p in result}
        assert ports == {80, 8080, 3000}

    def test_protocol_detection(self):
        """tcp6 lines (32-char hex addr) get protocol='tcp6'."""
        # IPv6 :: (all zeros, 32 hex chars) port 8080
        content = (
            "  sl  local_address rem_address   st\n"
            "   0: 00000000000000000000000000000000:1F90 00000000000000000000000000000000:0000 0A\n"
        )
        result = parse_proc_net_tcp(content)
        assert len(result) == 1
        assert result[0].protocol == "tcp6"


class TestNormalizeBind:
    """Validate PORT-04 IPv4-mapped IPv6 normalization."""

    def test_ipv4_mapped_ipv6(self):
        assert _normalize_bind("::ffff:0.0.0.0") == "0.0.0.0"

    def test_ipv6_any(self):
        assert _normalize_bind("::") == "0.0.0.0"

    def test_ipv4_passthrough(self):
        assert _normalize_bind("0.0.0.0") == "0.0.0.0"
        assert _normalize_bind("127.0.0.1") == "127.0.0.1"


class TestPortChangeDataModel:
    """Validate PortChange structure from spec."""

    def test_port_change_fields(self):
        """PortChange has container_name, port, action, forward fields."""
        lp = ListeningPort(port=8080, bind_address="0.0.0.0")
        change = PortChange(
            container_name="test",
            port=lp,
            action="added",
            forward=None,
        )
        assert change.container_name == "test"
        assert change.port.port == 8080
        assert change.action == "added"
        assert change.forward is None

    def test_forward_handle_alive(self):
        """ForwardHandle.alive is True when process is running, False when None."""
        handle = ForwardHandle(
            container_name="test",
            container_port=8080,
            host_port=8080,
            process=None,
        )
        assert handle.alive is False


class TestFindAvailablePort:
    """Validate host port selection from spec: 'try same port, then increment'."""

    def test_returns_preferred_when_available(self):
        """Preferred port returned when available."""
        # Port 19999 is unlikely to be in use
        port = find_available_host_port(19999)
        assert port >= 19999

    def test_increments_on_conflict(self):
        """Port increments when preferred is taken."""
        import socket
        # Bind a port to create a conflict
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(("", 0))
            occupied_port = s.getsockname()[1]
            # Ask for the occupied port
            found = find_available_host_port(occupied_port)
            assert found > occupied_port
