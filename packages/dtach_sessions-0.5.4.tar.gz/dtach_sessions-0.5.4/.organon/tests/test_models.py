"""Integration tests for data models.
Generated from: container-entry.model.yaml, port-info.model.yaml,
forward-info.model.yaml, session.model.yaml on 2026-04-13
Spec gaps marked with # SPEC GAP comments.

Tests validate model serialization/deserialization matches spec field definitions.
"""

import json
from datetime import datetime, timezone

from dsm.registry import ContainerEntry, PortInfo, ForwardInfo


class TestContainerEntryModel:
    """Validate ContainerEntry fields match container-entry.model.yaml spec."""

    def test_fields_match_spec(self):
        """All spec-defined fields are present in ContainerEntry."""
        now = datetime.now(timezone.utc).isoformat()
        entry = ContainerEntry(
            container_name="test",
            container_id="abc123",
            container_ip="172.17.0.2",
            status="running",
            created_at=now,
            updated_at=now,
            ports=[],
            forwards=[],
        )
        d = entry.to_dict()
        # Verify all spec fields exist
        assert "container_name" in d
        assert "container_id" in d
        assert "container_ip" in d
        assert "status" in d
        assert "created_at" in d
        assert "updated_at" in d
        assert "ports" in d
        assert "forwards" in d

    def test_status_values(self):
        """Status field accepts spec-defined values: running, stopped, unknown."""
        now = datetime.now(timezone.utc).isoformat()
        for status in ("running", "stopped", "unknown"):
            entry = ContainerEntry(
                container_name="test",
                container_id="abc",
                container_ip="10.0.0.1",
                status=status,
                created_at=now,
                updated_at=now,
            )
            assert entry.status == status

    def test_roundtrip_serialization(self):
        """to_dict/from_dict roundtrip preserves all fields."""
        now = datetime.now(timezone.utc).isoformat()
        original = ContainerEntry(
            container_name="test_ct",
            container_id="abc123def",
            container_ip="172.17.0.5",
            status="running",
            created_at=now,
            updated_at=now,
            ports=[PortInfo(port=8080, bind_address="0.0.0.0", protocol="tcp")],
            forwards=[ForwardInfo(container_port=8080, host_port=8080, socat_pid=1234, alive=True)],
        )
        d = original.to_dict()
        restored = ContainerEntry.from_dict(d)
        assert restored.container_name == original.container_name
        assert restored.container_id == original.container_id
        assert restored.container_ip == original.container_ip
        assert restored.status == original.status
        assert len(restored.ports) == 1
        assert restored.ports[0].port == 8080
        assert len(restored.forwards) == 1
        assert restored.forwards[0].container_port == 8080

    def test_json_serialization(self):
        """Entries serialize to valid JSON (for registry persistence)."""
        now = datetime.now(timezone.utc).isoformat()
        entry = ContainerEntry(
            container_name="test",
            container_id="abc",
            container_ip="10.0.0.1",
            status="running",
            created_at=now,
            updated_at=now,
        )
        json_str = json.dumps(entry.to_dict())
        parsed = json.loads(json_str)
        assert parsed["container_name"] == "test"


class TestPortInfoModel:
    """Validate PortInfo fields match port-info.model.yaml spec."""

    def test_fields_match_spec(self):
        """All spec-defined fields present: port, bind_address, protocol."""
        pi = PortInfo(port=8080, bind_address="0.0.0.0", protocol="tcp")
        d = pi.to_dict()
        assert d["port"] == 8080
        assert d["bind_address"] == "0.0.0.0"
        assert d["protocol"] == "tcp"

    def test_protocol_values(self):
        """Protocol accepts spec-defined values: tcp, tcp6."""
        for proto in ("tcp", "tcp6"):
            pi = PortInfo(port=80, bind_address="0.0.0.0", protocol=proto)
            assert pi.protocol == proto

    def test_roundtrip(self):
        """to_dict/from_dict roundtrip preserves all fields."""
        original = PortInfo(port=3000, bind_address="127.0.0.1", protocol="tcp6")
        restored = PortInfo.from_dict(original.to_dict())
        assert restored.port == original.port
        assert restored.bind_address == original.bind_address
        assert restored.protocol == original.protocol


class TestForwardInfoModel:
    """Validate ForwardInfo fields match forward-info.model.yaml spec."""

    def test_fields_match_spec(self):
        """All spec-defined fields present: container_port, host_port, socat_pid, alive."""
        fi = ForwardInfo(container_port=8080, host_port=8080, socat_pid=1234, alive=True)
        d = fi.to_dict()
        assert d["container_port"] == 8080
        assert d["host_port"] == 8080
        assert d["socat_pid"] == 1234
        assert d["alive"] is True

    def test_alive_default_true(self):
        """alive defaults to True per spec."""
        fi = ForwardInfo(container_port=80, host_port=80, socat_pid=1)
        assert fi.alive is True

    def test_roundtrip(self):
        """to_dict/from_dict roundtrip preserves all fields."""
        original = ForwardInfo(container_port=3000, host_port=3001, socat_pid=999, alive=False)
        restored = ForwardInfo.from_dict(original.to_dict())
        assert restored.container_port == original.container_port
        assert restored.host_port == original.host_port
        assert restored.socat_pid == original.socat_pid
        assert restored.alive == original.alive
