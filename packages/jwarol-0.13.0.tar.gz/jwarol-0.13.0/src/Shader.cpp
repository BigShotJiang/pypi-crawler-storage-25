#include "../include/Shader.hpp"
#include "../include/GLFunctions.hpp"
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <vector>

static std::string readLog(std::vector<char>& buf) {
    return buf.empty() ? "unknown error" : std::string(buf.data());
}

static void checkShaderCompile(unsigned int shader, const std::string& name) {
    GLint success = 0;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
    if (!success) {
        GLint logLen = 0;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logLen);
        std::vector<char> log(logLen > 0 ? logLen : 1, '\0');
        if (logLen > 0) glGetShaderInfoLog(shader, logLen, NULL, log.data());
        throw std::runtime_error(name + " shader compilation failed:\n" + readLog(log));
    }
}

static void checkProgramLink(unsigned int program) {
    GLint success = 0;
    glGetProgramiv(program, GL_LINK_STATUS, &success);
    if (!success) {
        GLint logLen = 0;
        glGetProgramiv(program, GL_INFO_LOG_LENGTH, &logLen);
        std::vector<char> log(logLen > 0 ? logLen : 1, '\0');
        if (logLen > 0) glGetProgramInfoLog(program, logLen, NULL, log.data());
        throw std::runtime_error("program linking failed:\n" + readLog(log));
    }
}

AuraShader::AuraShader(const std::string& vSrc, const std::string& fSrc) {
    const char* vPtr = vSrc.c_str();
    const char* fPtr = fSrc.c_str();

    unsigned int vShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vShader, 1, &vPtr, NULL);
    glCompileShader(vShader);
    checkShaderCompile(vShader, "vertex");

    unsigned int fShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fShader, 1, &fPtr, NULL);
    glCompileShader(fShader);
    checkShaderCompile(fShader, "fragment");

    programID = glCreateProgram();
    glAttachShader(programID, vShader);
    glAttachShader(programID, fShader);
    glLinkProgram(programID);
    checkProgramLink(programID);
}

AuraShader AuraShader::fromFile(const std::string& vertPath, const std::string& fragPath) {
    std::ifstream vFile(vertPath);
    if (!vFile.is_open())
        throw std::runtime_error("cannot open vertex shader file: " + vertPath);

    std::ifstream fFile(fragPath);
    if (!fFile.is_open())
        throw std::runtime_error("cannot open fragment shader file: " + fragPath);

    std::stringstream vSS, fSS;
    vSS << vFile.rdbuf();
    fSS << fFile.rdbuf();

    std::string vSrc = vSS.str();
    std::string fSrc = fSS.str();

    if (vSrc.empty())
        throw std::runtime_error("vertex shader file is empty: " + vertPath);
    if (fSrc.empty())
        throw std::runtime_error("fragment shader file is empty: " + fragPath);

    return AuraShader(vSrc, fSrc);
}

AuraShader AuraShader::fromSingleFile(const std::string& filepath) {
    std::ifstream file(filepath);
    if (!file.is_open())
        throw std::runtime_error("cannot open shader file: " + filepath);

    std::string line, vSrc, fSrc;
    std::string* target = nullptr;

    while (std::getline(file, line)) {
        if (line.find("#shader") != std::string::npos) {
            if (line.find("vertex") != std::string::npos)
                target = &vSrc;
            else if (line.find("fragment") != std::string::npos || line.find("pixel") != std::string::npos)
                target = &fSrc;
        } else if (target) {
            *target += line + "\n";
        }
    }

    if (vSrc.empty())
        throw std::runtime_error("no vertex shader (#shader vertex) found in: " + filepath);
    if (fSrc.empty())
        throw std::runtime_error("no fragment shader (#shader fragment) found in: " + filepath);

    return AuraShader(vSrc, fSrc);
}

void AuraShader::use() { glUseProgram(programID); }