#include "../include/GameObject.hpp"
#include "../include/Texture.hpp"

GameObject::GameObject(float x, float y, float w, float h)
    : x(x), y(y), w(w), h(h), active(true), r(1), g(1), b(1), tex(nullptr) {}

void GameObject::update(float dt) {}
void GameObject::draw(void* renderer) {}

void GameObject::set_texture(Texture& t) { tex = &t; }
Rect GameObject::get_rect() const { return {x, y, w, h}; }
bool GameObject::contains_point(float px, float py) const {
    return px >= x && px <= x + w && py >= y && py <= y + h;
}

Player::Player(float x, float y, float w, float h)
    : GameObject(x, y, w, h), speed(200.0f) {}

void Player::update(float dt) {}
void Player::draw(void* renderer) {}

Character::Character(float x, float y, float w, float h)
    : GameObject(x, y, w, h), hp(100.0f) {}

void Character::update(float dt) {}
void Character::draw(void* renderer) {}

GUI::GUI(float x, float y, float w, float h)
    : GameObject(x, y, w, h) {}

void GUI::draw(void* renderer) {}

Detail::Detail(float x, float y, float w, float h)
    : GameObject(x, y, w, h), alpha(1.0f) {}

void Detail::draw(void* renderer) {}
