#include "../include/Sprite.hpp"
#include "../include/Texture.hpp"
#include "../include/Renderer.hpp"
#include <algorithm>

Animation::Animation() : speed(0.1f), loop(true) {}

void Animation::add_frame(int index) { frames.push_back(index); }

void Animation::from_range(int start, int end) {
    frames.clear();
    for (int i = start; i <= end; i++) frames.push_back(i);
}

int Animation::size() const { return (int)frames.size(); }

Animation Animation::generate(const std::string& type, int count) {
    Animation a;
    a.speed = 0.15f;
    if (type == "idle") {
        a.from_range(0, std::min(count - 1, 2));
        a.speed = 0.3f;
    } else if (type == "walk") {
        a.from_range(0, std::min(count - 1, 3));
        a.speed = 0.1f;
    } else if (type == "run") {
        a.from_range(0, std::min(count - 1, 3));
        a.speed = 0.06f;
    } else if (type == "jump") {
        a.add_frame(0);
        a.speed = 0.2f;
        a.loop = false;
    } else {
        for (int i = 0; i < std::min(count, 4); i++)
            a.frames.push_back(i);
    }
    return a;
}

Sprite::Sprite()
    : texture(nullptr), cols(1), rows(1), frameW(0), frameH(0),
      currentFrame(0), timer(0), speed(0.1f), playing(true), loop(true),
      anim(nullptr), animFrame(0) {}

void Sprite::set_texture(Texture* tex, int c, int r) {
    texture = tex;
    cols = c;
    rows = r;
    frameW = tex->getWidth() / c;
    frameH = tex->getHeight() / r;
}

void Sprite::set_animation(Animation* a) { anim = a; }

void Sprite::update(float dt) {
    if (!playing) return;
    timer += dt;
    float spd = anim ? anim->speed : speed;
    bool lp = anim ? anim->loop : loop;
    if (timer >= spd) {
        timer = 0;
        currentFrame++;
        int maxFrames = anim ? (int)anim->frames.size() : (cols * rows);
        if (currentFrame >= maxFrames) {
            if (lp) currentFrame = 0;
            else { currentFrame = maxFrames - 1; playing = false; }
        }
    }
}

void Sprite::play() { playing = true; }
void Sprite::stop() { playing = false; }
void Sprite::reset() { currentFrame = 0; timer = 0; playing = true; }

int Sprite::get_frame_count() const { return cols * rows; }

void Sprite::get_uv(int frame, float& u0, float& v0, float& u1, float& v1) const {
    int realFrame = frame;
    if (anim && !anim->frames.empty())
        realFrame = anim->frames[std::min(frame, (int)anim->frames.size() - 1)];
    int fx = realFrame % cols;
    int fy = realFrame / cols;
    float fw = 1.0f / cols;
    float fh = 1.0f / rows;
    u0 = fx * fw;
    v0 = fy * fh;
    u1 = (fx + 1) * fw;
    v1 = (fy + 1) * fh;
}

void Sprite::draw_at(void* renderer, float x, float y, float w, float h) {
    if (!texture) return;
    float u0, v0, u1, v1;
    get_uv(currentFrame, u0, v0, u1, v1);
    ((Renderer*)renderer)->draw_sprite_frame(*texture, x, y, w, h, u0, v0, u1, v1);
}
