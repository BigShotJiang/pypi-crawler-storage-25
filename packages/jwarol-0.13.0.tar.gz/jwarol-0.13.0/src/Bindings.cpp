#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include "../include/Window.hpp"
#include "../include/Shader.hpp"
#include "../include/GLFunctions.hpp"
#include "../include/Math.hpp"
#include "../include/Input.hpp"
#include "../include/Clock.hpp"
#include "../include/Physics.hpp"
#include "../include/Renderer.hpp"
#include "../include/Texture.hpp"
#include "../include/Sound.hpp"
#include "../include/GameObject.hpp"
#include "../include/Camera.hpp"
#include "../include/Sprite.hpp"
#include "../include/DetailGroup.hpp"
#include "../include/Anim2D.hpp"

namespace py = pybind11;

PYBIND11_MODULE(jwarol, m) {
    m.def("init_graphics", &LoadGLFunctions);

    py::class_<Vec2>(m, "Vec2")
        .def(py::init<float, float>())
        .def_readwrite("x", &Vec2::x)
        .def_readwrite("y", &Vec2::y)
        .def("__add__", [](const Vec2& a, const Vec2& b) { return a + b; })
        .def("__sub__", [](const Vec2& a, const Vec2& b) { return a - b; })
        .def("__mul__", [](const Vec2& a, float s) { return a * s; });

    py::class_<Rect>(m, "Rect")
        .def(py::init<float, float, float, float>())
        .def("intersects", &Rect::intersects)
        .def("contains", &Rect::contains)
        .def_readwrite("x", &Rect::x)
        .def_readwrite("y", &Rect::y)
        .def_readwrite("w", &Rect::w)
        .def_readwrite("h", &Rect::h);

    py::class_<AuraWindow>(m, "Window")
        .def(py::init<int, int, const std::string&>())
        .def("poll_events", &AuraWindow::pollEvents)
        .def("clear", &AuraWindow::clear)
        .def("swap_buffers", &AuraWindow::swapBuffers)
        .def_property_readonly("is_open", &AuraWindow::isOpen);

    py::class_<InputManager>(m, "Input")
        .def(py::init<>())
        .def("update", &InputManager::update)
        .def("is_down", &InputManager::isDown)
        .def("is_pressed", &InputManager::isPressed)
        .def("is_released", &InputManager::isReleased);

    py::class_<Clock>(m, "Clock")
        .def(py::init<>())
        .def("tick", &Clock::tick);

    py::class_<PhysicsPoint>(m, "Point")
        .def_readwrite("pos", &PhysicsPoint::pos)
        .def_readwrite("pinned", &PhysicsPoint::pinned)
        .def_readwrite("enabled", &PhysicsPoint::enabled);

    py::enum_<BodyType>(m, "BodyType")
        .value("DYNAMIC", BodyType::DYNAMIC)
        .value("STATIC", BodyType::STATIC)
        .value("KINEMATIC", BodyType::KINEMATIC);

    py::class_<PhysicsBody>(m, "Body")
        .def(py::init<>())
        .def_readwrite("pos", &PhysicsBody::pos)
        .def_readwrite("size", &PhysicsBody::size)
        .def_readwrite("velocity", &PhysicsBody::velocity)
        .def_readwrite("type", &PhysicsBody::type)
        .def_readwrite("enabled", &PhysicsBody::enabled)
        .def("apply_force", &PhysicsBody::applyForce);

    py::class_<PhysicsWorld>(m, "World")
        .def(py::init<>())
        .def_readwrite("gravity", &PhysicsWorld::gravity)
        .def("add_point", &PhysicsWorld::addPoint)
        .def("step", &PhysicsWorld::step)
        .def("add_body", (void(PhysicsWorld::*)(float,float,float,float,BodyType))&PhysicsWorld::addBody,
            py::arg("x"), py::arg("y"), py::arg("w"), py::arg("h"),
            py::arg("type") = BodyType::DYNAMIC)
        .def("add_body_obj", (int(PhysicsWorld::*)(const PhysicsBody&))&PhysicsWorld::addBody)
        .def("remove_body", &PhysicsWorld::removeBody)
        .def_readwrite("points", &PhysicsWorld::points)
        .def_readwrite("bodies", &PhysicsWorld::bodies);

    py::class_<AuraShader>(m, "Shader")
        .def(py::init<const std::string&, const std::string&>())
        .def("use", &AuraShader::use)
        .def_static("from_file", &AuraShader::fromFile)
        .def_static("from_single_file", &AuraShader::fromSingleFile);

    py::class_<Texture>(m, "Texture")
        .def(py::init<>())
        .def(py::init<const std::string&>())
        .def(py::init([](int w, int h, std::string data, int ch) {
            return new Texture(w, h, (const unsigned char*)data.data(), ch);
        }), py::arg("width"), py::arg("height"),
            py::arg("data"), py::arg("channels") = 4)
        .def("load", &Texture::load)
        .def("from_data", &Texture::fromData)
        .def("bind", &Texture::bind, py::arg("slot") = 0)
        .def("overlay", &Texture::overlay,
            py::arg("other"), py::arg("x"), py::arg("y"),
            py::arg("alpha") = 1.0f)
        .def_property_readonly("width", &Texture::getWidth)
        .def_property_readonly("height", &Texture::getHeight)
        .def("is_supported", &Texture::isSupported)
        .def_static("load_all", &Texture::loadAll)
        .def_static("encrypt", &Texture::encrypt)
        .def_static("load_encrypted", &Texture::load_encrypted);

    py::class_<Sound>(m, "Sound")
        .def(py::init<const std::string&>())
        .def("play", &Sound::play)
        .def("stop", &Sound::stop)
        .def("set_volume", &Sound::set_volume)
        .def("is_playing", &Sound::is_playing)
        .def_static("play_file", &Sound::play_file);

    py::class_<GameObject>(m, "Object")
        .def(py::init<float, float, float, float>(),
            py::arg("x")=0, py::arg("y")=0, py::arg("w")=0, py::arg("h")=0)
        .def_readwrite("x", &GameObject::x)
        .def_readwrite("y", &GameObject::y)
        .def_readwrite("w", &GameObject::w)
        .def_readwrite("h", &GameObject::h)
        .def_readwrite("active", &GameObject::active)
        .def_readwrite("r", &GameObject::r)
        .def_readwrite("g", &GameObject::g)
        .def_readwrite("b", &GameObject::b)
        .def("update", &GameObject::update)
        .def("set_texture", &GameObject::set_texture)
        .def("get_rect", &GameObject::get_rect)
        .def("contains_point", &GameObject::contains_point);

    py::class_<Player, GameObject>(m, "Player")
        .def(py::init<float, float, float, float>(),
            py::arg("x")=0, py::arg("y")=0, py::arg("w")=0, py::arg("h")=0)
        .def_readwrite("speed", &Player::speed)
        .def("update", &Player::update);

    py::class_<Character, GameObject>(m, "Character")
        .def(py::init<float, float, float, float>(),
            py::arg("x")=0, py::arg("y")=0, py::arg("w")=0, py::arg("h")=0)
        .def_readwrite("hp", &Character::hp)
        .def("update", &Character::update);

    py::class_<GUI, GameObject>(m, "GUI")
        .def(py::init<float, float, float, float>(),
            py::arg("x")=0, py::arg("y")=0, py::arg("w")=0, py::arg("h")=0)
        .def_readwrite("text", &GUI::text);

    py::class_<Detail, GameObject>(m, "Detail")
        .def(py::init<float, float, float, float>(),
            py::arg("x")=0, py::arg("y")=0, py::arg("w")=0, py::arg("h")=0)
        .def_readwrite("alpha", &Detail::alpha);

    py::class_<Camera>(m, "Camera")
        .def(py::init<float, float>(),
            py::arg("width"), py::arg("height"))
        .def_readwrite("x", &Camera::x)
        .def_readwrite("y", &Camera::y)
        .def_readwrite("w", &Camera::w)
        .def_readwrite("h", &Camera::h)
        .def_readwrite("zoom", &Camera::zoom)
        .def_readwrite("smooth", &Camera::smooth)
        .def("follow", &Camera::follow)
        .def("unfollow", &Camera::unfollow)
        .def("update", &Camera::update)
        .def("apply_to", &Camera::apply_to);

    py::class_<Animation>(m, "Animation")
        .def(py::init<>())
        .def_readwrite("speed", &Animation::speed)
        .def_readwrite("loop", &Animation::loop)
        .def("add_frame", &Animation::add_frame)
        .def("from_range", &Animation::from_range)
        .def("size", &Animation::size)
        .def_static("generate", &Animation::generate);

    py::class_<Sprite>(m, "Sprite")
        .def(py::init<>())
        .def_readwrite("currentFrame", &Sprite::currentFrame)
        .def_readwrite("speed", &Sprite::speed)
        .def_readwrite("playing", &Sprite::playing)
        .def_readwrite("loop", &Sprite::loop)
        .def("set_texture", &Sprite::set_texture)
        .def("set_animation", &Sprite::set_animation)
        .def("update", &Sprite::update)
        .def("play", &Sprite::play)
        .def("stop", &Sprite::stop)
        .def("reset", &Sprite::reset)
        .def("draw_at", &Sprite::draw_at,
            py::arg("renderer"), py::arg("x"), py::arg("y"),
            py::arg("w"), py::arg("h"));

    py::class_<DetailGroup>(m, "DetailGroup")
        .def(py::init<>())
        .def("set_culling", &DetailGroup::set_culling)
        .def("get_culling", &DetailGroup::get_culling)
        .def("set_max_distance", &DetailGroup::set_max_distance)
        .def("get_max_distance", &DetailGroup::get_max_distance)
        .def("set_texture", &DetailGroup::set_texture,
            py::arg("texture"), py::arg("cols") = 1, py::arg("rows") = 1)
        .def("add", &DetailGroup::add,
            py::arg("x"), py::arg("y"), py::arg("w"), py::arg("h"),
            py::arg("r") = 1.0f, py::arg("g") = 1.0f,
            py::arg("b") = 1.0f, py::arg("a") = 1.0f)
        .def("add_uv", &DetailGroup::add_uv,
            py::arg("x"), py::arg("y"), py::arg("w"), py::arg("h"),
            py::arg("u0"), py::arg("v0"), py::arg("u1"), py::arg("v1"),
            py::arg("r") = 1.0f, py::arg("g") = 1.0f,
            py::arg("b") = 1.0f, py::arg("a") = 1.0f)
        .def("add_frame", &DetailGroup::add_frame,
            py::arg("x"), py::arg("y"), py::arg("w"), py::arg("h"),
            py::arg("col"), py::arg("row"),
            py::arg("r") = 1.0f, py::arg("g") = 1.0f,
            py::arg("b") = 1.0f, py::arg("a") = 1.0f)
        .def("clear", &DetailGroup::clear)
        .def("draw", &DetailGroup::draw,
            py::arg("cam_x"), py::arg("cam_y"),
            py::arg("view_w"), py::arg("view_h"))
        .def("count", &DetailGroup::count);

    py::class_<Renderer>(m, "Renderer")
        .def(py::init<float, float>())
        .def("draw_rect", &Renderer::draw_rect)
        .def("draw_texture", &Renderer::draw_texture,
            py::arg("tex"), py::arg("x"), py::arg("y"),
            py::arg("w"), py::arg("h"), py::arg("alpha") = 1.0f)
        .def("draw_texture_ex", &Renderer::draw_texture_ex,
            py::arg("tex"), py::arg("x"), py::arg("y"),
            py::arg("w"), py::arg("h"),
            py::arg("sx"), py::arg("sy"), py::arg("sw"), py::arg("sh"),
            py::arg("alpha") = 1.0f)
        .def("set_camera", &Renderer::set_camera)
        .def("is_visible", &Renderer::is_visible);

    py::class_<Bone2D>(m, "Bone2D")
        .def(py::init<>())
        .def_readwrite("name", &Bone2D::name)
        .def_readwrite("parent", &Bone2D::parent)
        .def_readwrite("x", &Bone2D::x)
        .def_readwrite("y", &Bone2D::y)
        .def_readwrite("rotation", &Bone2D::rotation)
        .def_readwrite("sx", &Bone2D::sx)
        .def_readwrite("sy", &Bone2D::sy);

    py::class_<SkeletonData>(m, "SkeletonData")
        .def(py::init<>())
        .def_readwrite("bones", &SkeletonData::bones)
        .def("add_bone", &SkeletonData::add_bone)
        .def("index_of", &SkeletonData::index_of);

    py::class_<BoneKeyframe>(m, "BoneKeyframe")
        .def(py::init<>())
        .def_readwrite("time", &BoneKeyframe::time)
        .def_readwrite("x", &BoneKeyframe::x)
        .def_readwrite("y", &BoneKeyframe::y)
        .def_readwrite("rotation", &BoneKeyframe::rotation)
        .def_readwrite("sx", &BoneKeyframe::sx)
        .def_readwrite("sy", &BoneKeyframe::sy);

    py::class_<BoneTrack>(m, "BoneTrack")
        .def(py::init<>())
        .def_readwrite("bone_index", &BoneTrack::bone_index)
        .def_readwrite("keyframes", &BoneTrack::keyframes);

    py::class_<SkeletalAnimation>(m, "SkeletalAnimation")
        .def(py::init<>())
        .def_readwrite("name", &SkeletalAnimation::name)
        .def_readwrite("duration", &SkeletalAnimation::duration)
        .def_readwrite("speed", &SkeletalAnimation::speed)
        .def_readwrite("loop", &SkeletalAnimation::loop)
        .def_readwrite("tracks", &SkeletalAnimation::tracks);

    py::class_<BoneAttachment>(m, "BoneAttachment")
        .def(py::init<>())
        .def_readwrite("bone_index", &BoneAttachment::bone_index)
        .def_readwrite("ox", &BoneAttachment::ox)
        .def_readwrite("oy", &BoneAttachment::oy)
        .def_readwrite("w", &BoneAttachment::w)
        .def_readwrite("h", &BoneAttachment::h)
        .def_readwrite("u0", &BoneAttachment::u0)
        .def_readwrite("v0", &BoneAttachment::v0)
        .def_readwrite("u1", &BoneAttachment::u1)
        .def_readwrite("v1", &BoneAttachment::v1);

    py::class_<AnimatedSprite2D>(m, "AnimatedSprite2D")
        .def(py::init<>())
        .def_readwrite("skeleton", &AnimatedSprite2D::skeleton)
        .def_readwrite("attachments", &AnimatedSprite2D::attachments)
        .def_readwrite("current_anim", &AnimatedSprite2D::current_anim)
        .def_readwrite("current_time", &AnimatedSprite2D::current_time)
        .def_readwrite("speed", &AnimatedSprite2D::speed)
        .def_readwrite("playing", &AnimatedSprite2D::playing)
        .def("set_texture", &AnimatedSprite2D::set_texture)
        .def("add_animation", &AnimatedSprite2D::add_animation)
        .def("play", &AnimatedSprite2D::play)
        .def("stop", &AnimatedSprite2D::stop)
        .def("update", &AnimatedSprite2D::update)
        .def("draw", &AnimatedSprite2D::draw,
            py::arg("renderer"), py::arg("x"), py::arg("y"),
            py::arg("scale") = 1.0f)
        .def_static("from_blender", &AnimatedSprite2D::from_blender,
            py::arg("json_path"), py::arg("tex_path"));
}
