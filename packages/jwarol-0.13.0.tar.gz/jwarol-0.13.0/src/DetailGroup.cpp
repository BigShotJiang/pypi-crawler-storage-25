#include "../include/DetailGroup.hpp"
#include "../include/Texture.hpp"
#include "../include/GLFunctions.hpp"
#include <GL/gl.h>
#include <cmath>

static const char* dVS = R"(
#version 330 core
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec4 aColor;
layout(location = 2) in vec2 aTex;
out vec4 vColor;
out vec2 vTex;
uniform int uUseTex;
void main() {
    gl_Position = vec4(aPos, 0.0, 1.0);
    vColor = aColor;
    vTex = aTex;
}
)";

static const char* dFS = R"(
#version 330 core
in vec4 vColor;
in vec2 vTex;
out vec4 FragColor;
uniform int uUseTex;
uniform sampler2D uTex;
void main() {
    if (uUseTex == 1)
        FragColor = texture(uTex, vTex) * vColor;
    else
        FragColor = vColor;
}
)";

DetailGroup::DetailGroup()
    : cullingEnabled(true), maxDistance(0), atlas(nullptr),
      atlasCols(1), atlasRows(1), useTexture(false),
      glReady(false), vao(0), vbo(0), program(0) {}

DetailGroup::~DetailGroup() {
    if (glReady) {
        glDeleteProgram(program);
        glDeleteBuffers(1, &vbo);
        glDeleteVertexArrays(1, &vao);
    }
}

void DetailGroup::initGL() {
    unsigned int vs = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vs, 1, &dVS, NULL);
    glCompileShader(vs);

    unsigned int fs = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fs, 1, &dFS, NULL);
    glCompileShader(fs);

    program = glCreateProgram();
    glAttachShader(program, vs);
    glAttachShader(program, fs);
    glLinkProgram(program);

    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glReady = true;
}

void DetailGroup::set_culling(bool enabled) { cullingEnabled = enabled; }
bool DetailGroup::get_culling() const { return cullingEnabled; }

void DetailGroup::set_max_distance(float dist) { maxDistance = dist; }
float DetailGroup::get_max_distance() const { return maxDistance; }

void DetailGroup::set_texture(Texture& tex, int cols, int rows) {
    atlas = &tex;
    atlasCols = cols;
    atlasRows = rows;
    useTexture = true;
}

void DetailGroup::add(float x, float y, float w, float h,
                       float r, float g, float b, float a) {
    Instance inst;
    inst.x = x; inst.y = y; inst.w = w; inst.h = h;
    inst.u0 = 0; inst.v0 = 0; inst.u1 = 1; inst.v1 = 1;
    inst.r = r; inst.g = g; inst.b = b; inst.a = a;
    inst.hasTex = false;
    instances.push_back(inst);
}

void DetailGroup::add_uv(float x, float y, float w, float h,
                          float u0, float v0, float u1, float v1,
                          float r, float g, float b, float a) {
    Instance inst;
    inst.x = x; inst.y = y; inst.w = w; inst.h = h;
    inst.u0 = u0; inst.v0 = v0; inst.u1 = u1; inst.v1 = v1;
    inst.r = r; inst.g = g; inst.b = b; inst.a = a;
    inst.hasTex = true;
    instances.push_back(inst);
}

void DetailGroup::add_frame(float x, float y, float w, float h,
                             int frameCol, int frameRow,
                             float r, float g, float b, float a) {
    float fw = 1.0f / atlasCols;
    float fh = 1.0f / atlasRows;
    float u0 = frameCol * fw;
    float v0 = frameRow * fh;
    float u1 = (frameCol + 1) * fw;
    float v1 = (frameRow + 1) * fh;
    add_uv(x, y, w, h, u0, v0, u1, v1, r, g, b, a);
}

void DetailGroup::clear() { instances.clear(); }

int DetailGroup::count() const { return (int)instances.size(); }

void DetailGroup::draw(float camX, float camY, float viewW, float viewH) {
    if (instances.empty()) return;
    if (!glReady) initGL();

    float distSq = maxDistance > 0 ? maxDistance * maxDistance : 0;

    std::vector<float> verts;
    verts.reserve(instances.size() * 6 * 8);

    for (auto& inst : instances) {
        float vx = inst.x - camX;
        float vy = inst.y - camY;

        if (cullingEnabled) {
            if (vx + inst.w < -viewW || vx > viewW ||
                vy + inst.h < -viewH || vy > viewH) continue;
        }

        if (maxDistance > 0) {
            float cx = vx + inst.w * 0.5f;
            float cy = vy + inst.h * 0.5f;
            if (cx * cx + cy * cy > distSq) continue;
        }

        float x0 = vx, y0 = vy;
        float x1 = vx + inst.w, y1 = vy + inst.h;
        float u0 = inst.u0, v0 = inst.v0;
        float u1 = inst.u1, v1 = inst.v1;
        float r = inst.r, g = inst.g, b = inst.b, a = inst.a;

        float q[] = {
            x0, y0, r, g, b, a, u0, v0,
            x1, y0, r, g, b, a, u1, v0,
            x0, y1, r, g, b, a, u0, v1,
            x1, y0, r, g, b, a, u1, v0,
            x1, y1, r, g, b, a, u1, v1,
            x0, y1, r, g, b, a, u0, v1,
        };
        verts.insert(verts.end(), q, q + 48);
    }

    if (verts.empty()) return;

    int totalVerts = (int)verts.size() / 8;

    glUseProgram(program);
    glUniform1i(glGetUniformLocation(program, "uUseTex"), useTexture ? 1 : 0);
    if (useTexture && atlas) {
        glUniform1i(glGetUniformLocation(program, "uTex"), 0);
        atlas->bind(0);
    }

    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, verts.size() * sizeof(float), verts.data(), GL_DYNAMIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, false, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 4, GL_FLOAT, false, 8 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, 2, GL_FLOAT, false, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glDrawArrays(GL_TRIANGLES, 0, totalVerts);
}
