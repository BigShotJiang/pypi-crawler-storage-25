#include "../include/Camera.hpp"
#include "../include/Renderer.hpp"
#include "../include/GameObject.hpp"
#include <algorithm>

Camera::Camera(float viewW, float viewH)
    : x(0), y(0), w(viewW), h(viewH), zoom(1.0f), smooth(0.1f), target(nullptr) {}

void Camera::follow(GameObject* obj) { target = obj; }

void Camera::unfollow() { target = nullptr; }

void Camera::update(float dt) {
    if (target && target->active) {
        float tx = target->x + target->w * 0.5f - w * 0.5f;
        float ty = target->y + target->h * 0.5f - h * 0.5f;
        float t = std::min(1.0f, smooth * dt * 60.0f);
        x += (tx - x) * t;
        y += (ty - y) * t;
    }
}

void Camera::apply_to(void* renderer) {
    ((Renderer*)renderer)->set_camera(x, y);
}
