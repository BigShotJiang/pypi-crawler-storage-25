#include "../include/Renderer.hpp"
#include "../include/Texture.hpp"
#include "../include/GLFunctions.hpp"
#include <GL/gl.h>

static unsigned int compileShader(const char* src, unsigned int type) {
    unsigned int shader = glCreateShader(type);
    glShaderSource(shader, 1, &src, NULL);
    glCompileShader(shader);
    return shader;
}

static unsigned int linkProgram(unsigned int vShader, unsigned int fShader) {
    unsigned int prog = glCreateProgram();
    glAttachShader(prog, vShader);
    glAttachShader(prog, fShader);
    glLinkProgram(prog);
    return prog;
}

Renderer::Renderer(float width, float height) : screenW(width), screenH(height), camX(0), camY(0) {
    glGenVertexArrays(1, &rectVAO);
    glGenBuffers(1, &rectVBO);

    glGenVertexArrays(1, &texVAO);
    glGenBuffers(1, &texVBO);

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    const char* texVS = R"(
#version 330 core
layout(location = 0) in vec2 aPos;
layout(location = 1) in vec2 aTex;
out vec2 vTex;
void main() {
    gl_Position = vec4(aPos, 0.0, 1.0);
    vTex = aTex;
}
)";
    const char* texFS = R"(
#version 330 core
in vec2 vTex;
out vec4 FragColor;
uniform sampler2D uTex;
uniform float uAlpha;
void main() {
    FragColor = texture(uTex, vTex) * uAlpha;
}
)";
    unsigned int vs = compileShader(texVS, GL_VERTEX_SHADER);
    unsigned int fs = compileShader(texFS, GL_FRAGMENT_SHADER);
    texProgram = linkProgram(vs, fs);

    const char* rectVS = R"(
#version 330 core
layout(location = 0) in vec3 aPos;
void main() {
    gl_Position = vec4(aPos, 1.0);
}
)";
    const char* rectFS = R"(
#version 330 core
uniform vec4 uColor;
out vec4 FragColor;
void main() {
    FragColor = uColor;
}
)";
    vs = compileShader(rectVS, GL_VERTEX_SHADER);
    fs = compileShader(rectFS, GL_FRAGMENT_SHADER);
    rectProgram = linkProgram(vs, fs);
}

Renderer::~Renderer() {
    glDeleteProgram(texProgram);
    glDeleteProgram(rectProgram);
    glDeleteBuffers(1, &rectVBO);
    glDeleteVertexArrays(1, &rectVAO);
    glDeleteBuffers(1, &texVBO);
    glDeleteVertexArrays(1, &texVAO);
}

void Renderer::set_camera(float x, float y) { camX = x; camY = y; }
float Renderer::get_cam_x() const { return camX; }
float Renderer::get_cam_y() const { return camY; }
bool Renderer::is_visible(float x, float y, float w, float h) const {
    return x + w > camX && x < camX + screenW && y + h > camY && y < camY + screenH;
}

void Renderer::draw_rect(float x, float y, float w, float h, float r, float g, float b) {
    if (!is_visible(x, y, w, h)) return;
    float vx = x - camX, vy = y - camY;
    float vertices[] = {
        vx,   vy,   0.0f,
        vx+w, vy,   0.0f,
        vx+w, vy+h, 0.0f,
        vx,   vy+h, 0.0f
    };

    glUseProgram(rectProgram);
    int colorLoc = glGetUniformLocation(rectProgram, "uColor");
    glUniform4f(colorLoc, r, g, b, 1.0f);

    glBindVertexArray(rectVAO);
    glBindBuffer(GL_ARRAY_BUFFER, rectVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, false, 3 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
}

void Renderer::draw_texture(Texture& tex, float x, float y, float w, float h, float alpha) {
    if (!is_visible(x, y, w, h)) return;
    float vx = x - camX, vy = y - camY;
    float vertices[] = {
        vx,   vy,   0.0f, 0.0f,
        vx+w, vy,   1.0f, 0.0f,
        vx+w, vy+h, 1.0f, 1.0f,
        vx,   vy+h, 0.0f, 1.0f
    };

    glUseProgram(texProgram);
    glUniform1f(glGetUniformLocation(texProgram, "uAlpha"), alpha);

    tex.bind(0);
    int texLoc = glGetUniformLocation(texProgram, "uTex");
    glUniform1i(texLoc, 0);

    glBindVertexArray(texVAO);
    glBindBuffer(GL_ARRAY_BUFFER, texVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_DYNAMIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, false, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, false, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
}

void Renderer::draw_texture_ex(Texture& tex, float x, float y, float w, float h,
                                float sx, float sy, float sw, float sh, float alpha) {
    if (!is_visible(x, y, w, h)) return;
    float tw = (float)tex.getWidth();
    float th = (float)tex.getHeight();
    float u0 = sx / tw, v0 = sy / th;
    float u1 = (sx + sw) / tw, v1 = (sy + sh) / th;
    float vx = x - camX, vy = y - camY;

    float vertices[] = {
        vx,   vy,   u0, v0,
        vx+w, vy,   u1, v0,
        vx+w, vy+h, u1, v1,
        vx,   vy+h, u0, v1
    };

    glUseProgram(texProgram);
    glUniform1f(glGetUniformLocation(texProgram, "uAlpha"), alpha);

    tex.bind(0);
    glUniform1i(glGetUniformLocation(texProgram, "uTex"), 0);

    glBindVertexArray(texVAO);
    glBindBuffer(GL_ARRAY_BUFFER, texVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_DYNAMIC_DRAW);

    glVertexAttribPointer(0, 2, GL_FLOAT, false, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, false, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
}

void Renderer::draw_sprite_frame(Texture& tex, float x, float y, float w, float h,
                                  float u0, float v0, float u1, float v1) {
    if (!is_visible(x, y, w, h)) return;
    float vx = x - camX, vy = y - camY;
    float verts[] = {
        vx,   vy,   u0, v0,
        vx+w, vy,   u1, v0,
        vx+w, vy+h, u1, v1,
        vx,   vy+h, u0, v1
    };

    glUseProgram(texProgram);
    glUniform1f(glGetUniformLocation(texProgram, "uAlpha"), 1.0f);
    tex.bind(0);
    glUniform1i(glGetUniformLocation(texProgram, "uTex"), 0);

    glBindVertexArray(texVAO);
    glBindBuffer(GL_ARRAY_BUFFER, texVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_DYNAMIC_DRAW);
    glVertexAttribPointer(0, 2, GL_FLOAT, false, 4 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, 2, GL_FLOAT, false, 4 * sizeof(float), (void*)(2 * sizeof(float)));
    glEnableVertexAttribArray(1);
    glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
}
