#include "../include/Anim2D.hpp"
#include "../include/Texture.hpp"
#include "../include/Renderer.hpp"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cmath>

int SkeletonData::add_bone(const std::string& name, int parent) {
    Bone2D b;
    b.name = name;
    b.parent = parent;
    bones.push_back(b);
    return (int)bones.size() - 1;
}

int SkeletonData::index_of(const std::string& name) const {
    for (size_t i = 0; i < bones.size(); i++)
        if (bones[i].name == name) return (int)i;
    return -1;
}

void SkeletonData::compute_world(std::vector<Mat3>& out) const {
    out.resize(bones.size());
    for (size_t i = 0; i < bones.size(); i++) {
        Mat3 local = Mat3::from_translate(bones[i].x, bones[i].y)
                   * Mat3::from_rotate(bones[i].rotation)
                   * Mat3::from_scale(bones[i].sx, bones[i].sy);
        int p = bones[i].parent;
        if (p >= 0 && p < (int)i)
            out[i] = out[p] * local;
        else
            out[i] = local;
    }
}

static float lerp(float a, float b, float t) { return a + (b - a) * t; }

static int find_keyframe(const std::vector<BoneKeyframe>& kfs, float t) {
    if (kfs.empty()) return -1;
    if (t <= kfs[0].time) return 0;
    if (t >= kfs.back().time) return (int)kfs.size() - 2;
    for (size_t i = 0; i < kfs.size() - 1; i++)
        if (t >= kfs[i].time && t < kfs[i + 1].time) return (int)i;
    return (int)kfs.size() - 2;
}

void BoneTrack::evaluate(float t, bool loop, BoneKeyframe& out) const {
    if (keyframes.empty()) return;
    float dur = keyframes.back().time;
    if (loop && dur > 0) t = fmod(t, dur);
    t = std::max(0.0f, std::min(t, dur));
    int idx = find_keyframe(keyframes, t);
    if (idx < 0 || idx >= (int)keyframes.size() - 1) {
        out = keyframes.empty() ? BoneKeyframe() : keyframes.back();
        return;
    }
    const BoneKeyframe& a = keyframes[idx];
    const BoneKeyframe& b = keyframes[idx + 1];
    float span = b.time - a.time;
    float f = (span > 0) ? (t - a.time) / span : 0;
    out.time = t;
    out.x = lerp(a.x, b.x, f);
    out.y = lerp(a.y, b.y, f);
    out.rotation = lerp(a.rotation, b.rotation, f);
    out.sx = lerp(a.sx, b.sx, f);
    out.sy = lerp(a.sy, b.sy, f);
}

void SkeletalAnimation::evaluate(float t, std::vector<Mat3>& out_pose, const SkeletonData& skel) const {
    out_pose.resize(skel.bones.size());
    for (size_t i = 0; i < skel.bones.size(); i++) {
        float bx = skel.bones[i].x;
        float by = skel.bones[i].y;
        float br = skel.bones[i].rotation;
        float bsx = skel.bones[i].sx;
        float bsy = skel.bones[i].sy;
        for (const auto& tr : tracks) {
            if (tr.bone_index == (int)i) {
                BoneKeyframe kf;
                tr.evaluate(t, loop, kf);
                bx += kf.x; by += kf.y;
                br += kf.rotation;
                bsx *= kf.sx; bsy *= kf.sy;
                break;
            }
        }
        Mat3 local = Mat3::from_translate(bx, by)
                   * Mat3::from_rotate(br)
                   * Mat3::from_scale(bsx, bsy);
        int p = skel.bones[i].parent;
        if (p >= 0 && p < (int)i)
            out_pose[i] = out_pose[p] * local;
        else
            out_pose[i] = local;
    }
}

AnimatedSprite2D::AnimatedSprite2D()
    : texture(nullptr), current_anim(-1), current_time(0),
      speed(1.0f), playing(true), anim_loop(true) {}

void AnimatedSprite2D::set_texture(Texture* tex) { texture = tex; }

int AnimatedSprite2D::add_animation(const SkeletalAnimation& anim) {
    animations.push_back(anim);
    return (int)animations.size() - 1;
}

bool AnimatedSprite2D::play(const std::string& name) {
    for (size_t i = 0; i < animations.size(); i++) {
        if (animations[i].name == name) {
            current_anim = (int)i;
            current_time = 0;
            playing = true;
            anim_loop = animations[i].loop;
            return true;
        }
    }
    return false;
}

void AnimatedSprite2D::stop() {
    playing = false;
    current_time = 0;
}

void AnimatedSprite2D::update(float dt) {
    if (!playing || current_anim < 0) return;
    auto& anim = animations[current_anim];
    float spd = anim.speed * speed;
    if (spd <= 0) return;
    current_time += dt * spd;
    float dur = anim.duration;
    if (dur <= 0) return;
    if (current_time >= dur) {
        if (anim.loop)
            current_time = fmod(current_time, dur);
        else {
            current_time = dur;
            playing = false;
        }
    }
    anim.evaluate(current_time, bone_poses, skeleton);
}

void AnimatedSprite2D::draw(Renderer* renderer, float x, float y, float scale) {
    if (!texture || current_anim < 0) return;
    if (bone_poses.empty()) return;
    for (auto& att : attachments) {
        if (att.bone_index < 0 || att.bone_index >= (int)bone_poses.size()) continue;
        float px = att.ox, py = att.oy;
        bone_poses[att.bone_index].transform(px, py);
        float fx = x + px * scale;
        float fy = y + py * scale;
        float fw = att.w * scale;
        float fh = att.h * scale;
        renderer->draw_sprite_frame(*texture, fx, fy, fw, fh,
                                    att.u0, att.v0, att.u1, att.v1);
    }
}

static std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    size_t b = s.find_last_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    return s.substr(a, b - a + 1);
}

static std::string read_file(const std::string& path) {
    std::ifstream f(path);
    if (!f.is_open()) return "";
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

static std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> parts;
    std::string cur;
    for (char c : s) {
        if (c == delim) {
            if (!cur.empty()) { parts.push_back(cur); cur.clear(); }
        } else cur += c;
    }
    if (!cur.empty()) parts.push_back(cur);
    return parts;
}

static std::string extract_json_string(const std::string& s, size_t& pos) {
    if (pos >= s.size() || s[pos] != '"') return "";
    pos++;
    std::string val;
    while (pos < s.size() && s[pos] != '"') {
        if (s[pos] == '\\' && pos + 1 < s.size()) { pos++; val += s[pos]; }
        else val += s[pos];
        pos++;
    }
    if (pos < s.size()) pos++;
    return val;
}

static float extract_json_number(const std::string& s, size_t& pos) {
    while (pos < s.size() && (s[pos] == ' ' || s[pos] == '\t' || s[pos] == '\n' || s[pos] == '\r')) pos++;
    size_t start = pos;
    bool dot = false;
    while (pos < s.size()) {
        if (s[pos] == '.') { dot = true; pos++; }
        else if (s[pos] >= '0' && s[pos] <= '9') pos++;
        else if (s[pos] == '-' && pos == start) pos++;
        else break;
    }
    if (pos == start) return 0;
    std::string num = s.substr(start, pos - start);
    return dot ? std::stof(num) : (float)std::stoi(num);
}

static void skip_json_ws(const std::string& s, size_t& pos) {
    while (pos < s.size() && (s[pos] == ' ' || s[pos] == '\t' || s[pos] == '\n' || s[pos] == '\r')) pos++;
}
static bool expect_char(const std::string& s, size_t& pos, char c) {
    skip_json_ws(s, pos);
    if (pos < s.size() && s[pos] == c) { pos++; return true; }
    return false;
}

AnimatedSprite2D* AnimatedSprite2D::from_blender(const std::string& json_path, const std::string& tex_path) {
    std::string data = read_file(json_path);
    if (data.empty()) return nullptr;

    auto* as = new AnimatedSprite2D();
    size_t p = 0;
    skip_json_ws(data, p);
    if (p >= data.size() || data[p] != '{') { delete as; return nullptr; }
    p++;

    while (p < data.size()) {
        skip_json_ws(data, p);
        if (data[p] == '}') break;
        std::string key = extract_json_string(data, p);
        skip_json_ws(data, p);
        if (p < data.size() && data[p] == ':') p++;

        if (key == "skeleton") {
            skip_json_ws(data, p);
            if (data[p] == '{') p++;
            while (p < data.size()) {
                skip_json_ws(data, p);
                if (data[p] == '}') { p++; break; }
                std::string sk = extract_json_string(data, p);
                skip_json_ws(data, p); if (data[p] == ':') p++;
                if (sk == "bones") {
                    skip_json_ws(data, p);
                    if (data[p] == '[') p++;
                    while (p < data.size()) {
                        skip_json_ws(data, p);
                        if (data[p] == ']') { p++; break; }
                        if (data[p] == '{') {
                            Bone2D bone;
                            size_t ob = p + 1;
                            while (ob < data.size()) {
                                skip_json_ws(data, ob);
                                if (data[ob] == '}') { ob++; break; }
                                std::string bk = extract_json_string(data, ob);
                                skip_json_ws(data, ob); if (data[ob] == ':') ob++;
                                if (bk == "name") bone.name = extract_json_string(data, ob);
                                else if (bk == "parent") bone.parent = (int)extract_json_number(data, ob);
                                else if (bk == "x") bone.x = extract_json_number(data, ob);
                                else if (bk == "y") bone.y = extract_json_number(data, ob);
                                else if (bk == "rotation") bone.rotation = extract_json_number(data, ob);
                                else if (bk == "sx") bone.sx = extract_json_number(data, ob);
                                else if (bk == "sy") bone.sy = extract_json_number(data, ob);
                                else { while (ob < data.size() && data[ob] != ',' && data[ob] != '}') ob++; if (data[ob] == ',') ob++; }
                                skip_json_ws(data, ob);
                                if (ob < data.size() && data[ob] == ',') ob++;
                            }
                            as->skeleton.bones.push_back(bone);
                            p = ob;
                        } else { p++; }
                        skip_json_ws(data, p);
                        if (p < data.size() && data[p] == ',') p++;
                    }
                } else { while (p < data.size() && data[p] != ',' && data[p] != '}') p++; if (data[p] == ',') p++; }
            }
        } else if (key == "attachments") {
            skip_json_ws(data, p);
            if (data[p] == '[') p++;
            while (p < data.size()) {
                skip_json_ws(data, p);
                if (data[p] == ']') { p++; break; }
                if (data[p] == '{') {
                    BoneAttachment att;
                    size_t oa = p + 1;
                    while (oa < data.size()) {
                        skip_json_ws(data, oa);
                        if (data[oa] == '}') { oa++; break; }
                        std::string ak = extract_json_string(data, oa);
                        skip_json_ws(data, oa); if (data[oa] == ':') oa++;
                        if (ak == "bone") {
                            std::string bn = extract_json_string(data, oa);
                            att.bone_index = as->skeleton.index_of(bn);
                        } else if (ak == "ox") att.ox = extract_json_number(data, oa);
                        else if (ak == "oy") att.oy = extract_json_number(data, oa);
                        else if (ak == "w") att.w = extract_json_number(data, oa);
                        else if (ak == "h") att.h = extract_json_number(data, oa);
                        else if (ak == "u0") att.u0 = extract_json_number(data, oa);
                        else if (ak == "v0") att.v0 = extract_json_number(data, oa);
                        else if (ak == "u1") att.u1 = extract_json_number(data, oa);
                        else if (ak == "v1") att.v1 = extract_json_number(data, oa);
                        else { while (oa < data.size() && data[oa] != ',' && data[oa] != '}') oa++; if (data[oa] == ',') oa++; }
                        skip_json_ws(data, oa);
                        if (oa < data.size() && data[oa] == ',') oa++;
                    }
                    as->attachments.push_back(att);
                    p = oa;
                } else p++;
                skip_json_ws(data, p);
                if (p < data.size() && data[p] == ',') p++;
            }
        } else if (key == "animations") {
            skip_json_ws(data, p);
            if (data[p] == '{') p++;
            while (p < data.size()) {
                skip_json_ws(data, p);
                if (data[p] == '}') { p++; break; }
                SkeletalAnimation anim;
                anim.name = extract_json_string(data, p);
                skip_json_ws(data, p); if (data[p] == ':') p++;
                skip_json_ws(data, p);
                if (data[p] == '{') p++;
                while (p < data.size()) {
                    skip_json_ws(data, p);
                    if (data[p] == '}') { p++; break; }
                    std::string ak = extract_json_string(data, p);
                    skip_json_ws(data, p); if (data[p] == ':') p++;
                    if (ak == "duration") anim.duration = extract_json_number(data, p);
                    else if (ak == "speed") anim.speed = extract_json_number(data, p);
                    else if (ak == "loop") {
                        skip_json_ws(data, p);
                        if (p < data.size() && data[p] == 't') { anim.loop = true; p += 4; }
                        else if (p < data.size() && data[p] == 'f') { anim.loop = false; p += 5; }
                    } else if (ak == "tracks") {
                        skip_json_ws(data, p);
                        if (data[p] == '{') p++;
                        while (p < data.size()) {
                            skip_json_ws(data, p);
                            if (data[p] == '}') { p++; break; }
                            std::string bname = extract_json_string(data, p);
                            skip_json_ws(data, p); if (data[p] == ':') p++;
                            skip_json_ws(data, p);
                            if (data[p] == '{') p++;
                            BoneTrack track;
                            track.bone_index = as->skeleton.index_of(bname);
                            while (p < data.size()) {
                                skip_json_ws(data, p);
                                if (data[p] == '}') { p++; break; }
                                std::string prop = extract_json_string(data, p);
                                skip_json_ws(data, p); if (data[p] == ':') p++;
                                skip_json_ws(data, p);
                                if (data[p] == '[') p++;
                                while (p < data.size()) {
                                    skip_json_ws(data, p);
                                    if (data[p] == ']') { p++; break; }
                                    if (data[p] == '{') {
                                        BoneKeyframe kf;
                                        size_t ok = p + 1;
                                        while (ok < data.size()) {
                                            skip_json_ws(data, ok);
                                            if (data[ok] == '}') { ok++; break; }
                                            std::string kk = extract_json_string(data, ok);
                                            skip_json_ws(data, ok); if (data[ok] == ':') ok++;
                                            if (kk == "t") kf.time = extract_json_number(data, ok);
                                            else if (kk == "v") {
                                                float val = extract_json_number(data, ok);
                                                if (prop == "x") kf.x = val;
                                                else if (prop == "y") kf.y = val;
                                                else if (prop == "rotate") kf.rotation = val;
                                                else if (prop == "sx") kf.sx = val;
                                                else if (prop == "sy") kf.sy = val;
                                            }
                                            else { while (ok < data.size() && data[ok] != ',' && data[ok] != '}') ok++; if (data[ok] == ',') ok++; }
                                            skip_json_ws(data, ok);
                                            if (ok < data.size() && data[ok] == ',') ok++;
                                        }
                                        track.keyframes.push_back(kf);
                                        p = ok;
                                    } else p++;
                                    skip_json_ws(data, p);
                                    if (p < data.size() && data[p] == ',') p++;
                                }
                                skip_json_ws(data, p);
                                if (p < data.size() && data[p] == ',') p++;
                            }
                            if (track.bone_index >= 0)
                                anim.tracks.push_back(track);
                            skip_json_ws(data, p);
                            if (p < data.size() && data[p] == ',') p++;
                        }
                    } else { while (p < data.size() && data[p] != ',' && data[p] != '}') p++; if (data[p] == ',') p++; }
                    skip_json_ws(data, p);
                    if (p < data.size() && data[p] == ',') p++;
                }
                as->animations.push_back(anim);
                skip_json_ws(data, p);
                if (p < data.size() && data[p] == ',') p++;
            }
        } else {
            skip_json_ws(data, p);
            if (data[p] == '{' || data[p] == '[') {
                int depth = 1;
                p++;
                while (p < data.size() && depth > 0) {
                    if (data[p] == '{' || data[p] == '[') depth++;
                    else if (data[p] == '}' || data[p] == ']') depth--;
                    p++;
                }
            } else {
                while (p < data.size() && data[p] != ',' && data[p] != '}') p++;
            }
        }
        skip_json_ws(data, p);
        if (p < data.size() && data[p] == ',') p++;
    }

    if (tex_path.find(".png") != std::string::npos || tex_path.find(".jpg") != std::string::npos || tex_path.find(".bmp") != std::string::npos) {
        auto* tex = new Texture(tex_path);
        as->set_texture(tex);
    } else {
        auto* tex = new Texture(tex_path);
        as->set_texture(tex);
    }

    return as;
}
