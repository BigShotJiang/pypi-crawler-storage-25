#include "../include/Sound.hpp"
#include <windows.h>
#include <string>
#include <stdexcept>

#pragma comment(lib, "winmm.lib")

static int soundCounter = 0;

Sound::Sound(const std::string& filepath) : path(filepath), loaded(false) {
    alias = "snd" + std::to_string(soundCounter++);
    std::string cmd = "open \"" + path + "\" type waveaudio alias " + alias;
    if (mciSendStringA(cmd.c_str(), NULL, 0, NULL) != 0)
        throw std::runtime_error("cannot open sound file: " + path);
    loaded = true;
}

Sound::~Sound() {
    if (loaded) {
        mciSendStringA(("close " + alias).c_str(), NULL, 0, NULL);
    }
}

void Sound::play() {
    if (loaded)
        mciSendStringA(("play " + alias + " from 0").c_str(), NULL, 0, NULL);
}

void Sound::stop() {
    if (loaded)
        mciSendStringA(("stop " + alias).c_str(), NULL, 0, NULL);
}

void Sound::set_volume(int vol) {
    if (loaded) {
        std::string cmd = "setaudio " + alias + " volume to " + std::to_string(vol);
        mciSendStringA(cmd.c_str(), NULL, 0, NULL);
    }
}

bool Sound::is_playing() {
    if (!loaded) return false;
    char buf[32] = {0};
    mciSendStringA(("status " + alias + " mode").c_str(), buf, sizeof(buf), NULL);
    return std::string(buf) == "playing";
}

void Sound::play_file(const std::string& filepath) {
    mciSendStringA("close tmp_snd", NULL, 0, NULL);
    std::string cmd = "open \"" + filepath + "\" type waveaudio alias tmp_snd";
    if (mciSendStringA(cmd.c_str(), NULL, 0, NULL) == 0)
        mciSendStringA("play tmp_snd from 0", NULL, 0, NULL);
}
