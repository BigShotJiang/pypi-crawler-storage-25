#pragma once
#include <string>

class AuraShader {
public:
    unsigned int programID;
    AuraShader(const std::string& vSrc, const std::string& fSrc);
    void use();
    static AuraShader fromFile(const std::string& vertPath, const std::string& fragPath);
    static AuraShader fromSingleFile(const std::string& filepath);
};