#pragma once
#include <string>
#include "Math.hpp"

class Texture;

class GameObject {
public:
    float x, y, w, h;
    bool active;
    float r, g, b;
    Texture* tex;

    GameObject(float x=0, float y=0, float w=0, float h=0);
    virtual ~GameObject() = default;
    virtual void update(float dt);
    virtual void draw(void* renderer);
    void set_texture(Texture& t);
    Rect get_rect() const;
    bool contains_point(float px, float py) const;
};

class Player : public GameObject {
public:
    float speed;
    Player(float x=0, float y=0, float w=0, float h=0);
    void update(float dt) override;
    void draw(void* renderer) override;
};

class Character : public GameObject {
public:
    float hp;
    Character(float x=0, float y=0, float w=0, float h=0);
    void update(float dt) override;
    void draw(void* renderer) override;
};

class GUI : public GameObject {
public:
    std::string text;
    GUI(float x=0, float y=0, float w=0, float h=0);
    void draw(void* renderer) override;
};

class Detail : public GameObject {
public:
    float alpha;
    Detail(float x=0, float y=0, float w=0, float h=0);
    void draw(void* renderer) override;
};
